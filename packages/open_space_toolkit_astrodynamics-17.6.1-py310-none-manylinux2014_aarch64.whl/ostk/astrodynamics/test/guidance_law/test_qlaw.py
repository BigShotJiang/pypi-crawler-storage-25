# Apache License 2.0

import pytest

import numpy as np

from ostk.physics.time import Instant
from ostk.physics.coordinate import Frame
from ostk.physics.coordinate import Position
from ostk.physics.coordinate import Velocity
from ostk.physics.unit import Derived
from ostk.physics.environment.gravitational import Earth as EarthGravitationalModel
from ostk.physics.time import Instant
from ostk.physics.unit import Length
from ostk.physics.unit import Angle


from ostk.astrodynamics.trajectory.orbit.model.kepler import COE
from ostk.astrodynamics import GuidanceLaw
from ostk.astrodynamics.guidance_law import QLaw
from ostk.astrodynamics.trajectory import State


@pytest.fixture
def target_COE() -> COE:
    return COE(
        Length.meters(42000.0e3),
        0.01,
        Angle.degrees(0.05),
        Angle.degrees(0.0),
        Angle.degrees(0.0),
        Angle.degrees(0.0),
    )


@pytest.fixture
def gravitational_parameter() -> Derived:
    return Derived(
        3.986004418e14,
        EarthGravitationalModel.EGM2008.gravitational_parameter.get_unit(),
    )


@pytest.fixture
def parameters() -> QLaw.Parameters:
    return QLaw.Parameters(
        element_weights={
            COE.Element.SemiMajorAxis: (1.0, 100.0),
            COE.Element.Eccentricity: (1.0, 1e-3),
        },
        m=5,
        n=6,
        r=7,
        b=0.08,
        k=9,
        periapsis_weight=0.1,
        minimum_periapsis_radius=Length.kilometers(7000.0),
        absolute_effectivity_threshold=0.2,
        relative_effectivity_threshold=0.3,
    )


@pytest.fixture
def gradient_strategy() -> QLaw.GradientStrategy:
    return QLaw.GradientStrategy.FiniteDifference


@pytest.fixture
def q_law(
    target_COE: COE,
    gravitational_parameter: Derived,
    parameters: QLaw.Parameters,
    gradient_strategy: QLaw.GradientStrategy,
) -> QLaw:
    return QLaw(
        target_coe=target_COE,
        gravitational_parameter=gravitational_parameter,
        parameters=parameters,
        coe_domain=QLaw.COEDomain.Osculating,
        gradient_strategy=gradient_strategy,
    )


@pytest.fixture
def thrust_acceleration() -> float:
    return 1.0 / 300.0


@pytest.fixture
def frame() -> Frame:
    return Frame.GCRF()


@pytest.fixture
def position_coordinates() -> list[float]:
    return [6930000.0, 0.0, 0.0]


@pytest.fixture
def velocity_coordinates() -> list[float]:
    return [0.0, 7621.89248591193, 6.65135764404186]


@pytest.fixture
def instant() -> Instant:
    return Instant.J2000()


@pytest.fixture
def position(frame: Frame, position_coordinates: list[float]) -> Position:
    return Position.meters(position_coordinates, frame)


@pytest.fixture
def velocity(frame: Frame, velocity_coordinates: list[float]) -> Velocity:
    return Velocity.meters_per_second(velocity_coordinates, frame)


@pytest.fixture
def state(instant: Instant, position: Position, velocity: Velocity) -> State:
    return State(instant=instant, position=position, velocity=velocity)


class TestQLawParameters:
    def test_constructors(self, parameters: QLaw.Parameters):
        assert parameters is not None
        assert isinstance(parameters, QLaw.Parameters)

    def test_getters(self, parameters: QLaw.Parameters):
        assert parameters.get_control_weights() is not None
        assert parameters.get_convergence_thresholds() is not None
        assert parameters.m == 5
        assert parameters.n == 6
        assert parameters.r == 7
        assert parameters.b == 0.08
        assert parameters.k == 9
        assert parameters.periapsis_weight == 0.1
        assert parameters.get_minimum_periapsis_radius() == Length.kilometers(7000.0)
        assert parameters.absolute_effectivity_threshold == 0.2
        assert parameters.relative_effectivity_threshold == 0.3


class TestQLaw:
    def test_constructors(
        self,
        target_COE: COE,
        gravitational_parameter: Derived,
        parameters: QLaw.Parameters,
        gradient_strategy: QLaw.GradientStrategy,
    ):
        qlaw: QLaw = QLaw(
            target_coe=target_COE,
            gravitational_parameter=gravitational_parameter,
            parameters=parameters,
            coe_domain=QLaw.COEDomain.BrouwerLyddaneMeanLong,
            gradient_strategy=gradient_strategy,
        )

        assert qlaw is not None
        assert isinstance(qlaw, QLaw)
        assert isinstance(qlaw, GuidanceLaw)

    def test_getters(self, q_law: QLaw):
        assert q_law.get_parameters() is not None
        assert q_law.get_target_coe() is not None
        assert q_law.get_gradient_strategy() is not None
        assert q_law.get_coe_domain() is not None

    def test_calculate_thrust_acceleration_at(
        self,
        q_law: QLaw,
        position_coordinates: list[float],
        velocity_coordinates: list[float],
        thrust_acceleration: float,
        instant: Instant,
        frame: Frame,
    ):
        assert pytest.approx(
            q_law.calculate_thrust_acceleration_at(
                instant=instant,
                position_coordinates=position_coordinates,
                velocity_coordinates=velocity_coordinates,
                thrust_acceleration=thrust_acceleration,
                output_frame=frame,
            )
        ) == np.array([0.0, 0.0033333320640941645, 2.9088817174504986e-06])

    def test_compute_effectivity(
        self,
        q_law: QLaw,
        state: State,
        thrust_acceleration: float,
    ):
        assert (
            q_law.compute_effectivity(
                state=state,
                thrust_acceleration=thrust_acceleration,
            )
            is not None
        )

        assert (
            q_law.compute_effectivity(
                state=state,
                thrust_acceleration=thrust_acceleration,
                discretization_step_count=15,
            )
            is not None
        )

    def test_compute_orbital_elements_maximal_change(
        self,
        q_law: QLaw,
        thrust_acceleration: float,
    ):
        coe_vector = np.array([42000.0e3, 0.01, 0.001, 0.0, 0.0])
        result = q_law.compute_orbital_elements_maximal_change(
            coe_vector=coe_vector,
            thrust_acceleration=thrust_acceleration,
        )
        assert result is not None
        assert result.shape == (5,)

    def test_compute_q(
        self,
        q_law: QLaw,
        thrust_acceleration: float,
    ):
        coe_vector = np.array([42000.0e3, 0.01, 0.001, 0.0, 0.0])
        result = q_law.compute_q(
            coe_vector=coe_vector,
            thrust_acceleration=thrust_acceleration,
        )
        assert result is not None
        assert isinstance(result, float)

    def test_compute_d_q_d_oe(
        self,
        q_law: QLaw,
        thrust_acceleration: float,
    ):
        coe_vector = np.array([42000.0e3, 0.01, 0.001, 0.0, 0.0])
        result = q_law.compute_d_q_d_oe(
            coe_vector=coe_vector,
            thrust_acceleration=thrust_acceleration,
        )
        assert result is not None
        assert result.shape == (5,)

    def test_compute_thrust_direction(
        self,
        q_law: QLaw,
        thrust_acceleration: float,
    ):
        coe_vector = np.array([42000.0e3, 0.01, 0.001, 0.0, 0.0, 0.0])
        result = q_law.compute_thrust_direction(
            coe_vector=coe_vector,
            thrust_acceleration=thrust_acceleration,
        )
        assert result is not None
        assert result.shape == (3,)

    def test_compute_d_oe_d_f(
        self,
        gravitational_parameter: Derived,
    ):
        coe_vector = np.array([42000.0e3, 0.01, 0.001, 0.0, 0.0, 0.0])
        result = QLaw.compute_d_oe_d_f(
            coe_vector=coe_vector,
            gravitational_parameter=gravitational_parameter,
        )
        assert result is not None
        assert result.shape == (5, 3)

    def test_theta_rh_to_gcrf(
        self,
        position_coordinates: list[float],
        velocity_coordinates: list[float],
    ):
        result = QLaw.theta_rh_to_gcrf(
            position_coordinates=np.array(position_coordinates),
            velocity_coordinates=np.array(velocity_coordinates),
        )
        assert result is not None
        assert result.shape == (3, 3)
