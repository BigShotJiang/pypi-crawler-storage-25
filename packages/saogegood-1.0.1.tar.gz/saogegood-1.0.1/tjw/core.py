class tjw_class:
    def helloworld(self, name: str = "tjw"):
        return f"hello [{name}]!"


def hello(name: str = "tjw"):
    return f"hello {name}!"