import argparse

from tjw.core import tjw_class, hello

tjw = tjw_class()


def main():
    parser = argparse.ArgumentParser(description='fw-pip-test 命令行工具')
    subparsers = parser.add_subparsers(dest='command', help='可用命令')

    # helloworld 命令
    helloworld_parser = subparsers.add_parser('helloworld', help='输出问候信息')
    helloworld_parser.add_argument('--name', default='tjw', help='问候对象名称')

    # add_one 命令
    add_one_parser = subparsers.add_parser('add_one', help='对数值加1')
    add_one_parser.add_argument('number', type=float, help='要加1的数值')

    args = parser.parse_args()

    if args.command == 'helloworld':
        print(tjw.helloworld(name=args.name))
    elif args.command == 'add_one':
        result = hello(args.number)
        print(f"结果: {result}")
    else:
        parser.print_help()


if __name__ == '__main__':
    main()
