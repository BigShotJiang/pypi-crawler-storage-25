import os
from ezdeploy_cli.analyzer import analyze_project, resolve_requirements
from ezdeploy_cli.generator import generate_requirements_txt


def test_generate_requirements(tmp_path):
    # Point analyzer at the sample project we added
    project_dir = os.path.join(os.path.dirname(__file__), "sample_project")
    analysis = analyze_project(project_dir)
    reqs = resolve_requirements(analysis['imports'])

    out_dir = tmp_path
    req_path = generate_requirements_txt(reqs, directory=str(out_dir))

    with open(req_path, 'r', encoding='utf-8') as f:
        content = f.read()

    # Basic sanity checks
    assert "fastapi" in content
    assert "joblib" in content
    assert "pandas" in content
    assert "numpy" in content
    # Ensure not every package gets permissive placeholder unless unresolved
    assert ">=0.0.1" in content or "==" in content

