import ast
import os
import sys

# Common import name to PyPI package name mapping for fallbacks
COMMON_MAPPING = {
    "cv2": "opencv-python",
    "pd": "pandas",
    "np": "numpy",
    "PIL": "Pillow",
    "sklearn": "scikit-learn",
    "yaml": "PyYAML",
    "fastapi": "fastapi",
    "uvicorn": "uvicorn",
    "joblib": "joblib",
    "pydantic": "pydantic"
}

# ============================================================================
# System-Level Dependency Detection
# Maps Python imports to required Linux (apt-get) packages
# ============================================================================

SYSTEM_DEPS_MAP = {
    # OpenCV family — the #1 cause of ML container crashes
    "cv2": ["libgl1-mesa-glx", "libglib2.0-0", "libsm6", "libxext6", "libxrender-dev"],
    "PIL": ["libjpeg-dev", "zlib1g-dev"],
    "Pillow": ["libjpeg-dev", "zlib1g-dev"],
    # Audio processing
    "soundfile": ["libsndfile1"],
    "librosa": ["libsndfile1", "ffmpeg"],
    "torchaudio": ["libsndfile1", "sox", "ffmpeg"],
    # Scientific / HPC
    "scipy": ["libopenblas-dev", "gfortran"],
    "numpy": ["libopenblas-dev"],
    "sklearn": ["libopenblas-dev", "gfortran"],
    # Database connectors
    "psycopg2": ["libpq-dev"],
    "pyodbc": ["unixodbc-dev"],
    "mysqlclient": ["default-libmysqlclient-dev"],
    # Compilation / Build
    "bitsandbytes": ["build-essential"],
    "flash_attn": ["build-essential", "git"],
    "deepspeed": ["build-essential", "git", "libaio-dev"],
    "auto_gptq": ["build-essential"],
    "triton": ["build-essential"],
    # XML / Parsing
    "lxml": ["libxml2-dev", "libxslt1-dev"],
    # Crypto
    "cryptography": ["libffi-dev", "libssl-dev"],
    # Misc
    "h5py": ["libhdf5-dev"],
    "pygraphviz": ["graphviz", "graphviz-dev"],
}

# Libraries that require the FULL CUDA Toolkit (nvidia/cuda:...-devel) instead of runtime
CUDA_DEVEL_TRIGGERS = {
    "flash_attn", "flash-attn", "deepspeed", "auto_gptq", "auto-gptq",
    "triton", "bitsandbytes", "xformers",
}

try:
    from importlib.metadata import packages_distributions, version, PackageNotFoundError, distribution
    HAS_PACKAGES_DISTRIBUTIONS = True
except ImportError:
    HAS_PACKAGES_DISTRIBUTIONS = False

class CodebaseAnalyzer(ast.NodeVisitor):
    def __init__(self):
        self.imports = set()
        self.has_fastapi = False
        self.has_flask = False
        self.has_streamlit = False
        self.has_gradio = False
        self.entrypoint_found = False
        self.main_block_found = False
        self.detected_port = None

    def visit_Import(self, node):
        for alias in node.names:
            top_level = alias.name.split('.')[0]
            self.imports.add(top_level)
        self.generic_visit(node)

    def visit_ImportFrom(self, node):
        if node.module:
            top_level = node.module.split('.')[0]
            self.imports.add(top_level)
        self.generic_visit(node)

    def visit_Call(self, node):
        # Look for FastAPI() or Flask(__name__)
        if isinstance(node.func, ast.Name):
            if node.func.id == "FastAPI":
                self.has_fastapi = True
                self.entrypoint_found = True
            elif node.func.id == "Flask":
                self.has_flask = True
                self.entrypoint_found = True
        elif isinstance(node.func, ast.Attribute):
            # Detect uvicorn.run(..., port=XXXX) or app.run(port=XXXX)
            if node.func.attr == "run":
                if isinstance(node.func.value, ast.Name):
                    if node.func.value.id == "uvicorn":
                        self.entrypoint_found = True
                    # Generic app.run() — Flask style
                    self.entrypoint_found = True
                # Extract port= keyword argument
                self._extract_port_from_call(node)
        self.generic_visit(node)

    def _extract_port_from_call(self, node):
        """Extract port number from keyword arguments like port=8000."""
        for kw in node.keywords:
            if kw.arg == "port":
                if isinstance(kw.value, ast.Constant) and isinstance(kw.value.value, int):
                    self.detected_port = kw.value.value
                elif isinstance(kw.value, ast.Name):
                    # port=PORT — we can't resolve variables, skip
                    pass

    def visit_If(self, node):
        # Look for if __name__ == "__main__":
        if isinstance(node.test, ast.Compare):
            left = node.test.left
            if isinstance(left, ast.Name) and left.id == "__name__":
                for op, right in zip(node.test.ops, node.test.comparators):
                    if isinstance(op, ast.Eq) and isinstance(right, ast.Constant) and right.value == "__main__":
                        self.main_block_found = True
                        self.entrypoint_found = True
        self.generic_visit(node)

def analyze_project(directory: str = ".") -> dict:
    """
    Perform deep analysis of the project to find imports, frameworks, entrypoints,
    system dependencies, and port configuration.
    """
    all_imports = set()
    entrypoints = []
    detected_port = None
    
    # Files to ignore
    ignore_dirs = {".git", "venv", "env", "__pycache__", "node_modules", ".ezdeploy"}
    
    for root, dirs, files in os.walk(directory):
        # In-place modification of dirs to skip ignored ones
        dirs[:] = [d for d in dirs if d not in ignore_dirs and not d.startswith('.')]
        
        for file in files:
            if file.endswith(".py"):
                path = os.path.join(root, file)
                try:
                    with open(path, "r", encoding="utf-8") as f:
                        content = f.read()
                        tree = ast.parse(content, filename=path)
                        analyzer = CodebaseAnalyzer()
                        analyzer.visit(tree)
                        all_imports.update(analyzer.imports)
                        
                        if analyzer.entrypoint_found:
                            entrypoints.append({
                                "path": os.path.relpath(path, directory).replace("\\", "/"),
                                "framework": "fastapi" if analyzer.has_fastapi else "flask" if analyzer.has_flask else "streamlit" if analyzer.has_streamlit else "gradio" if analyzer.has_gradio else "python",
                                "has_main": analyzer.main_block_found
                            })
                        
                        # Capture detected port (first wins)
                        if analyzer.detected_port and detected_port is None:
                            detected_port = analyzer.detected_port
                except Exception:
                    pass

    # Filter imports
    stdlib = sys.stdlib_module_names if hasattr(sys, 'stdlib_module_names') else set()
    third_party = {imp for imp in all_imports if imp not in stdlib and imp != "__main__"}
    
    # Detect system-level dependencies based on imports
    system_deps = set()
    needs_cuda_devel = False
    for imp in all_imports:
        if imp in SYSTEM_DEPS_MAP:
            system_deps.update(SYSTEM_DEPS_MAP[imp])
        if imp in CUDA_DEVEL_TRIGGERS or imp.replace("_", "-") in CUDA_DEVEL_TRIGGERS:
            needs_cuda_devel = True

    # Choose best entrypoint (prefer FastAPI/Flask over raw main)
    best_entrypoint = None
    if entrypoints:
        # Sort so that FastAPI/Flask are preferred over generic main
        entrypoints.sort(key=lambda x: (x['framework'] != 'python', x['has_main']), reverse=True)
        best_entrypoint = entrypoints[0]
    else:
        # Fallback: look for common names
        for folder in ["", "src", "app"]:
            for name in ["main.py", "app.py", "run.py"]:
                p = os.path.join(directory, folder, name)
                if os.path.exists(p):
                    best_entrypoint = {"path": os.path.relpath(p, directory).replace("\\", "/"), "framework": "python", "has_main": True}
                    break
            if best_entrypoint: break

    return {
        "imports": third_party,
        "entrypoint": best_entrypoint,
        "framework": best_entrypoint['framework'] if best_entrypoint else "python",
        "detected_port": detected_port,
        "system_deps": sorted(system_deps),
        "needs_cuda_devel": needs_cuda_devel,
    }

def _is_valid_version(v: str) -> bool:
    """A lightweight sanity check for version strings (PEP 440-ish)."""
    if not isinstance(v, str) or not v:
        return False
    # common invalid markers
    invalid_markers = ["0.0.0", "0.0.1", "unknown", "-"]
    if v in invalid_markers:
        return False
    # rough numeric check: starts with digit
    return v[0].isdigit()


def _resolve_from_distribution_name(dist_name: str) -> str | None:
    """Attempt to get version for a distribution name using importlib.metadata.version.
    Returns None if not found or version seems invalid.
    """
    try:
        v = version(dist_name)
        if _is_valid_version(v):
            return v
    except Exception:
        return None

    return None


def resolve_requirements(third_party_imports: set, project_env: str | None = None) -> dict:
    """Map imported module names to PyPI package versions with improved fallbacks.

    - If project_env (path to venv) is supplied, resolution prefers that environment.
    - Uses packages_distributions reverse mapping when available.
    - Uses COMMON_MAPPING and conservative fallbacks.
    - Never silently overwrite a good version with a permissive placeholder.
    """
    requirements = {}
    pkg_dists = {}

    if HAS_PACKAGES_DISTRIBUTIONS:
        try:
            pkg_dists = packages_distributions()
        except Exception:
            pkg_dists = {}

    for imp in sorted(third_party_imports):
        if imp.startswith('_'):
            continue

        resolved = None

        # 1) Try mapping via packages_distributions reverse lookup (top-level import -> package)
        packages = pkg_dists.get(imp) if pkg_dists else None
        if packages:
            # Prefer a distribution that actually claims the top-level package in its top_level.txt
            preferred_pkg = None
            for pkg in packages:
                try:
                    # Prefer an exact package name match first
                    if pkg.lower() == imp.lower():
                        preferred_pkg = pkg
                        break

                    dist = distribution(pkg)
                    top_text = None
                    try:
                        top_text = dist.read_text('top_level.txt')
                    except Exception:
                        top_text = None

                    if top_text:
                        tops = {l.strip() for l in top_text.splitlines() if l.strip()}
                        # If the import name appears in top_level.txt prefer it unless an exact
                        # distribution name match was found earlier.
                        if imp in tops and not preferred_pkg:
                            preferred_pkg = pkg
                            # do not break; continue searching for an exact distribution name match
                except Exception:
                    # ignore distribution read errors and continue
                    continue

            # If we found a preferred package use it; else fall back to first resolvable package
            candidates = [preferred_pkg] if preferred_pkg else packages
            for pkg in candidates:
                if not pkg:
                    continue
                v = _resolve_from_distribution_name(pkg)
                if v:
                    requirements[pkg] = v
                    resolved = True
                    break

        if resolved:
            continue

        # 2) Common mapping (aliases)
        if imp in COMMON_MAPPING:
            pkg_name = COMMON_MAPPING[imp]
            v = _resolve_from_distribution_name(pkg_name)
            if v:
                requirements[pkg_name] = v
                continue
            else:
                # Last attempt: keep the mapping but mark as unresolved (use permissive spec)
                requirements[pkg_name] = ">=0.0.1"
                continue

        # 3) Try the import name itself as a distribution
        v = _resolve_from_distribution_name(imp)
        if v:
            requirements[imp] = v
            continue

        # 4) As a final fallback, add permissive, but only for names that look like packages
        # (avoid adding placeholders for single-letter or clearly internal imports)
        if len(imp) > 1:
            requirements[imp] = ">=0.0.1"

    return requirements
