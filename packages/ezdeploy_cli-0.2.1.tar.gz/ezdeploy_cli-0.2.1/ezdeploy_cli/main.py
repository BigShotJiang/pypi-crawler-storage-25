import argparse
import subprocess
import os
import sys

from .detector import get_system_context, export_env_json
from .analyzer import analyze_project, resolve_requirements
from .generator import generate_requirements_txt, generate_dockerfile


def run_git_push():
    """Commit new files and push them to the repository."""
    print("[EzDeployCLI] Auto-push flag detected. Committing and pushing locally generated files...")
    try:
        # Check if it's a git repo
        subprocess.run(["git", "status"], check=True, capture_output=True)
        
        # Add generated files
        subprocess.run(["git", "set-local-config", "core.autocrlf", "false"], check=False) # Fix potential line ending issues
        subprocess.run(["git", "add", "requirements.txt", "Dockerfile"], check=True)
        
        # Commit
        subprocess.run(["git", "commit", "-m", "chore: setup production environment via EzDeployCLI"], check=True)
        
        # Push
        print("[EzDeployCLI] Pushing to origin...")
        subprocess.run(["git", "push"], check=True)
        print("[EzDeployCLI] Successfully pushed files to GitHub!")
        
    except subprocess.CalledProcessError as e:
        print(f"[EzDeployCLI] Git operation failed. Are you in a git repository with an origin set? Error: {e}")
    except FileNotFoundError:
        print("[EzDeployCLI] Git command not found. Please install git.")


def run_scan():
    """
    Scan the environment and export ezdeploy_env.json.
    This is the primary command for users on Colab, RunPod, or local machines.
    The JSON file is uploaded to the EzDeploy Web UI to auto-fill the deployment wizard.
    """
    print("\n[EzDeployCLI] 🚀 Starting deep environment scan...\n")
    
    # 1. System Detection
    context = get_system_context()
    print(f"  ▸ OS:       {context['os']}")
    print(f"  ▸ Python:   {context['local_python']} → Production Target: {context['python_version']}")
    cuda_str = context['cuda_version'] if context['cuda_version'] else 'None (CPU only)'
    print(f"  ▸ CUDA:     {cuda_str}")
    if context.get('gpu_name'):
        print(f"  ▸ GPU:      {context['gpu_name']}")
    if context.get('compute_capability'):
        print(f"  ▸ SM (Compute Capability): {context['compute_capability']}")
    print()
    
    # 2. Codebase Analysis 
    print("[EzDeployCLI] 🔍 Scanning project structure and imports...")
    analysis = analyze_project(".")
    
    if analysis['entrypoint']:
        ep = analysis['entrypoint']
        print(f"  ▸ Detected Entrypoint: {ep['path']} ({ep['framework']})")
    else:
        print("  ▸ Warning: No clear entrypoint detected. Using defaults.")
    
    if analysis.get('detected_port'):
        print(f"  ▸ Detected Port: {analysis['detected_port']}")
    
    if analysis.get('system_deps'):
        print(f"  ▸ Required System Packages: {', '.join(analysis['system_deps'])}")

    if analysis.get('needs_cuda_devel'):
        print(f"  ▸ ⚠️  Needs CUDA Devel image (detected: flash-attn, deepspeed, or similar)")

    print()
        
    # 3. Resolve exact package versions
    print("[EzDeployCLI] 📦 Resolving exact dependency versions...")
    exact_reqs = resolve_requirements(analysis['imports'])
    print(f"  ▸ Resolved {len(exact_reqs)} packages.\n")
    
    # 4. Export ezdeploy_env.json
    json_path = export_env_json(context, analysis, exact_reqs)
    print(f"[EzDeployCLI] ✅ Written {json_path}")
    
    print("\n" + "─" * 60)
    print("[EzDeployCLI] ✨ Environment scan complete!")
    print()
    print("  Next steps:")
    print("  1. Download 'ezdeploy_env.json' from this environment")
    print("  2. Go to EzDeploy Web UI → Deployment Wizard")
    print("  3. Upload the JSON file to auto-fill your environment settings")
    print("  4. Review, tweak if needed, and deploy!")
    print("─" * 60 + "\n")


def run_detect(push: bool = False):
    """Legacy detect command — generates requirements.txt + Dockerfile."""
    print("\n[EzDeployCLI] 🚀 Starting deep environment analysis...")
    
    # 1. System Detection
    context = get_system_context()
    print(f"  -> OS: {context['os']}")
    print(f"  -> Local Python: {context['local_python']} (Production Target: {context['python_version']})")
    print(f"  -> CUDA: {context['cuda_version'] if context['cuda_version'] else 'None'}\n")
    
    # 2. Codebase Analysis 
    print("[EzDeployCLI] 🔍 Scanning project structure and imports...")
    analysis = analyze_project(".")
    
    if analysis['entrypoint']:
        print(f"  -> Detected Entrypoint: {analysis['entrypoint']['path']} ({analysis['entrypoint']['framework']})")
    else:
        print("  -> Warning: No clear entrypoint detected. Using defaults.")
        
    print("[EzDeployCLI] 📦 Resolving exact dependency versions...")
    exact_reqs = resolve_requirements(analysis['imports'])
    print(f"  -> Resolved {len(exact_reqs)} packages.\n")
    
    # 3. File Generation
    req_path = generate_requirements_txt(exact_reqs)
    print(f"[EzDeployCLI] ✅ Written {req_path}")
    
    docker_path = generate_dockerfile(context, analysis)
    print(f"[EzDeployCLI] ✅ Written {docker_path}")
    print("\n[EzDeployCLI] ✨ Production environment setup complete!")
    
    # 4. Optional Push
    if push:
        print("\n")
        run_git_push()


def main():
    parser = argparse.ArgumentParser(description="EzDeployCLI: High-Precision Environment Analyzer")
    subparsers = parser.add_subparsers(dest="command", required=True)
    
    # Scan command (NEW — primary command)
    subparsers.add_parser(
        "scan",
        help="Scan environment and export ezdeploy_env.json for the EzDeploy Web UI."
    )
    
    # Detect command (legacy — generates Dockerfile too)
    detect_parser = subparsers.add_parser("detect", help="[Legacy] Detect env and generate optimized requirements.txt and Dockerfile.")
    detect_parser.add_argument("--push", action="store_true", help="Automatically commit and push the generated files to git.")
    
    # Alias
    subparsers.add_parser("detect&&push", help="Alias for 'detect --push'")

    args = parser.parse_args()

    if args.command == "scan":
        run_scan()
    elif args.command in ["detect", "detect&&push"]:
        should_push = getattr(args, 'push', False) or args.command == "detect&&push"
        run_detect(push=should_push)
            
if __name__ == "__main__":
    main()
