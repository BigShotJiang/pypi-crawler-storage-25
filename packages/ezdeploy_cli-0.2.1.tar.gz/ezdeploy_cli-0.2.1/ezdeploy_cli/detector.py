import platform
import sys
import subprocess
import json
import os

def detect_os() -> str:
    """Detect the operating system."""
    system = platform.system()
    if system == "Darwin":
        return "macOS"
    return system

def detect_python_version() -> str:
    """Detect the current local Python version (major.minor.micro)."""
    return f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"

def detect_python_version_short() -> str:
    """Detect the current local Python version (major.minor)."""
    return f"{sys.version_info.major}.{sys.version_info.minor}"

def get_stable_python_version(detected_ver: str) -> str:
    """
    Map experimental/unstable local versions to the latest stable production version.
    Current Stable Target: 3.11/3.12
    """
    try:
        parts = detected_ver.split('.')
        major, minor = int(parts[0]), int(parts[1])
        # If user is on 3.13 or 3.14+, fallback to 3.11 (highly stable for ML) or 3.12
        if major == 3 and minor >= 13:
            return "3.11" 
        return f"{major}.{minor}"
    except:
        return "3.11"

def detect_cuda_version() -> str | None:
    """Detect the CUDA version available in the environment.
    
    Checks multiple sources in order of reliability:
    1. nvcc --version (most reliable — proves CUDA Toolkit is installed)
    2. nvidia-smi (proves driver is installed, shows max supported CUDA)
    3. torch.version.cuda (if PyTorch is available)
    """
    # 1. Try nvcc (CUDA Toolkit compiler)
    try:
        result = subprocess.run(["nvcc", "--version"], capture_output=True, text=True, check=True)
        for line in result.stdout.split("\n"):
            if "release" in line:
                return line.split("release")[1].split(",")[0].strip()
    except: pass
    
    # 2. Try nvidia-smi
    try:
        result = subprocess.run(["nvidia-smi"], capture_output=True, text=True, check=True)
        for line in result.stdout.split("\n"):
            if "CUDA Version:" in line:
                return line.split("CUDA Version:")[1].split()[0].strip()
    except: pass

    # 3. Fallback to torch if installed
    try:
        import torch
        if torch.cuda.is_available():
            return torch.version.cuda
    except: pass
    return None

def detect_gpu_name() -> str | None:
    """Detect the name of the GPU (e.g., 'NVIDIA A100-SXM4-40GB')."""
    try:
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"],
            capture_output=True, text=True, check=True
        )
        name = result.stdout.strip().split('\n')[0].strip()
        return name if name else None
    except: pass
    
    try:
        import torch
        if torch.cuda.is_available():
            return torch.cuda.get_device_name(0)
    except: pass
    return None

def detect_compute_capability() -> str | None:
    """Detect the GPU Compute Capability (SM version, e.g., '8.0' for A100)."""
    try:
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=compute_cap", "--format=csv,noheader"],
            capture_output=True, text=True, check=True
        )
        cap = result.stdout.strip().split('\n')[0].strip()
        return cap if cap else None
    except: pass
    
    try:
        import torch
        if torch.cuda.is_available():
            major, minor = torch.cuda.get_device_capability(0)
            return f"{major}.{minor}"
    except: pass
    return None

def get_system_context() -> dict:
    """Get full system context with production recommendations."""
    local_python = detect_python_version()
    return {
        "os": detect_os(),
        "local_python": local_python,
        "python_version": get_stable_python_version(local_python),
        "cuda_version": detect_cuda_version(),
        "gpu_name": detect_gpu_name(),
        "compute_capability": detect_compute_capability(),
    }

def export_env_json(
    system_context: dict,
    project_analysis: dict,
    requirements: dict,
    directory: str = "."
) -> str:
    """
    Export the full environment analysis as ezdeploy_env.json.
    
    This is the file the user downloads and uploads to the EzDeploy Web UI
    to auto-fill the deployment wizard with exact environment details.
    """
    env_data = {
        "_version": "1.0",
        "_generator": "EzDeployCLI",
        "python": {
            "version": system_context.get("local_python"),
            "stable_target": system_context.get("python_version"),
        },
        "cuda": {
            "version": system_context.get("cuda_version"),
            "gpu_name": system_context.get("gpu_name"),
            "compute_capability": system_context.get("compute_capability"),
        },
        "project": {
            "framework": project_analysis.get("framework"),
            "entrypoint": project_analysis.get("entrypoint", {}).get("path") if project_analysis.get("entrypoint") else None,
            "detected_port": project_analysis.get("detected_port"),
            "needs_cuda_devel": project_analysis.get("needs_cuda_devel", False),
        },
        "system_packages": project_analysis.get("system_deps", []),
        "packages": {
            pkg: ver for pkg, ver in sorted(requirements.items())
        },
    }
    
    path = os.path.join(directory, "ezdeploy_env.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(env_data, f, indent=2, ensure_ascii=False)
    
    return path
