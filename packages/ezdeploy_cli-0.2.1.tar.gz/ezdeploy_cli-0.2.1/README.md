# EzDeploy CLI

A lightweight, zero-dependency local environment auto-detector for the EzDeploy platform.

The EzDeploy CLI tool is designed to be installed locally in your development environment (like your VS Code terminal). It intelligenty analyzes your current local environment, matching your OS, Python version, CUDA drivers, and exact code imports to generate perfectly locked base files for cloud deployment. 

## Installation

Install directly via `pip` inside your active virtual environment or terminal:

```bash
pip install ezdeploy-cli
```

*(Note: The package is incredibly lightweight and utilizes only native Python standard libraries so it won't bloat your environment).*

## Usage

Navigate to the root directory of your Python project in your terminal:

```bash
cd /path/to/my/project
```

### 1. Simple Environment Scan (Recommended)
To scan your environment and generate a deployment metadata file (`ezdeploy_env.json`) that you can upload to the EzDeploy Web UI:

```bash
EzDeployCLI scan
```
- Scans `nvcc`, `nvidia-smi` and local `torch` logic to find your exact CUDA drivers and GPU hardware.
- Resolves your exact minor Python version (e.g., `3.11.8`).
- Uses AST parsing to trace the exact libraries and system-level binaries (like `libgl1`) your code needs.
- **Outputs:** `ezdeploy_env.json`.

### 2. Full Local Detection
To generate a production-ready `Dockerfile` and `requirements.txt` directly on your machine:

```bash
EzDeployCLI detect
```

### 3. Detect & Auto-Push
Generate the files and automatically push them to your repository in a single command:

```bash
EzDeployCLI detect --push
```

## Connect to EzDeploy Cloud

The `scan` command is the most powerful way to use EzDeploy:
1. Run `EzDeployCLI scan` in your development environment (Local, Colab, or RunPod).
2. Download/Copy the generated `ezdeploy_env.json`.
3. Open the [EzDeploy Console](https://ezdeploy.oryvoai.com/console).
4. In the Deployment Wizard, upload the JSON file.
5. EzDeploy will auto-populate every setting (Python, CUDA, Ports, and System Packages) to match your environment exactly, ensuring your deployment works on the first try!

