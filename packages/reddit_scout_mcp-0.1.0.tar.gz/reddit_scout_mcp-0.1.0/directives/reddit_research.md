# Reddit Research MCP — Directive

## What it is
An MCP server that gives Claude structured, credibility-scored access to Reddit discussions.
Beats Google's AI overview by: multi-pass search, thread-deep reading (not just OPs), credibility weighting, rolling time filters, and explicit counter-evidence surfacing.

## Tools
- `research_topic_tool(query, subreddits?, since, depth)` — multi-pass research, returns consensus + minority view + cited posts
- `compare_tool(subjects[], dimensions?, subreddits?)` — sequential side-by-side comparison
- `find_dissent_tool(claim)` — actively searches for posts contradicting a claim
- `get_thread_tool(url_or_id, include_replies, max_depth)` — full thread with nested replies, tombstones filtered

## Result envelope
All tools return: `{ok, data, summary_text, partial_failures: [{subreddit, reason}], error, metadata}`
- `summary_text` is always plain-English, readable without inspecting data
- `partial_failures` is populated per-subreddit when a subreddit errors, not a global fail
- `verdict` is one of: `clear_consensus` / `minority_view_notable` / `no_clear_majority`

## Credibility formula
`score = 0.4*karma_bucket + 0.3*account_age_bucket + 0.2*flair_exists + 0.1*post_recency`
- `karma_bucket`: log10 scale, 100k karma = 1.0
- `account_age_bucket`: 5 years = 1.0. Posts from <30-day accounts are flagged `new_account_flag: true`
- `post_recency`: 1.0 = today, 0.0 = 365+ days ago

## Time filtering
Uses explicit `created_utc` post-filter, not Reddit's `t=` param (which rounds to calendar boundaries).
Default window: rolling 12 months from query time.

## Architecture (3-layer)
- **Transport**: `server.py` — FastMCP stdio, tool registration only
- **Service**: `reddit_tools.py` — search, fetch, credibility scoring, consensus logic
- **Domain**: `credibility.py`, `schemas.py` — pure functions, testable in isolation

## Setup
1. Create a Reddit app at reddit.com/prefs/apps (type: script)
2. Add to `.env`:
   ```
   REDDIT_CLIENT_ID=xxx
   REDDIT_CLIENT_SECRET=xxx
   REDDIT_USER_AGENT=reddit-research-mcp by u/<your_username>
   ```
3. Run smoke test: `python reddit_research/execution/smoke_test.py`
4. If smoke test passes, add to `.mcp.json` (see README)

## Known limitation
Reddit consensus can be confidently wrong on niche topics (supplement dosing, legal advice, finance specifics).
This tool surfaces what Reddit says, not what is true. High credibility score means the poster is established — not that they are correct.

## Error handling
- Deleted/removed threads: detected by `author is None` + tombstone text, returned as `TOMBSTONE` error
- Per-subreddit failures: added to `partial_failures`, other subreddits continue
- Rate limits (429): PRAW built-in throttling handles this; do not retry manually
- No posts found: returns structured error with plain-English message, not exception
