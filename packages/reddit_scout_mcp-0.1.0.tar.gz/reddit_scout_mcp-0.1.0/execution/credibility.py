import math
import time


def score_post_dict(post: dict) -> tuple[float, int]:
    """
    score = 0.4*karma_bucket + 0.3*account_age_bucket + 0.2*flair_exists + 0.1*post_recency
    Returns (score, account_age_days). Arctic Shift posts are dicts.
    """
    now = time.time()

    # karma bucket: log10 scale, 100k = 1.0
    karma = (post.get("author_comment_karma") or 0) + (post.get("author_link_karma") or 0)
    karma_bucket = min(1.0, math.log10(max(karma, 1)) / 5)

    # account age bucket: 5 years = 1.0
    author_created = post.get("author_created_utc") or 0
    account_age_days = int((now - author_created) / 86400) if author_created else 0
    age_bucket = min(1.0, account_age_days / 1825)

    # flair
    flair_exists = 1.0 if post.get("author_flair_text") else 0.0

    # post recency: 1.0 = today, 0.0 = 365+ days ago
    post_age_days = max(0, (now - (post.get("created_utc") or now)) / 86400)
    recency = max(0.0, 1.0 - (post_age_days / 365))

    score = 0.4 * karma_bucket + 0.3 * age_bucket + 0.2 * flair_exists + 0.1 * recency
    return round(score, 3), account_age_days
