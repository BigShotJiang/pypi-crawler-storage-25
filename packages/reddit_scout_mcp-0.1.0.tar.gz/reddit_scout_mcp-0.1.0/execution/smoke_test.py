"""
Run before using the MCP server.
Proves Arctic Shift API + all tool functions work end-to-end. No auth required.
Usage: python reddit_research/execution/smoke_test.py
"""
import sys
import os
import time

sys.path.insert(0, os.path.dirname(__file__))
os.chdir(os.path.dirname(__file__))

print("=== Reddit Research MCP — Smoke Test ===\n")

print("[1/4] Testing Arctic Shift connectivity...")
import httpx
try:
    r = httpx.get("https://arctic-shift.photon-reddit.com/api/posts/search",
                  params={"query": "test", "subreddit": "cars", "limit": 1}, timeout=10)
    r.raise_for_status()
    print(f"PASS: Arctic Shift reachable (status {r.status_code})\n")
except Exception as e:
    print(f"FAIL: {e}")
    sys.exit(1)

print("[2/4] Testing research_topic (cold, real query)...")
from reddit_tools import research_topic
start = time.time()
result = research_topic("Honda CR-V 2024 reliability", since="12m", depth=2)
elapsed = time.time() - start

if not result["ok"]:
    print(f"FAIL: {result['error']}")
    sys.exit(1)

sources = result["metadata"].get("sources_count", 0)
verdict = result["data"].get("verdict", "unknown")
print(f"PASS: {sources} posts | verdict={verdict} | {elapsed:.1f}s cold")
print(f"  summary: {result['summary_text'][:120]}")
if elapsed > 15:
    print(f"  WARNING: exceeded 15s SLA ({elapsed:.1f}s)")
if sources < 15:
    print(f"  WARNING: fewer than 15 posts ({sources})")
print()

print("[3/4] Testing find_dissent...")
from reddit_tools import find_dissent
result2 = find_dissent("Honda CR-V 2024 is reliable")
if not result2["ok"]:
    print(f"FAIL: {result2['error']}")
    sys.exit(1)
dissent_count = len(result2["data"].get("dissent_posts", []))
print(f"PASS: {dissent_count} dissent posts found")
print(f"  summary: {result2['summary_text'][:120]}\n")

print("[4/4] Testing get_thread (live Reddit post)...")
from reddit_tools import get_thread
result3 = get_thread("https://www.reddit.com/r/cars/comments/1sovlt3/", include_replies=False)
if result3 is None:
    print("FAIL: get_thread returned None unexpectedly")
    sys.exit(1)
err_code = (result3.get("error") or {}).get("code")
if err_code not in (None, "NOT_FOUND", "TOMBSTONE"):
    print(f"FAIL: unexpected error — {result3.get('error')}")
    sys.exit(1)
print(f"PASS: get_thread returned cleanly (ok={result3['ok']})\n")

print("=== All checks passed. MCP server is ready. ===")
print("\nRestart Claude Code to load the reddit-research MCP tools.")
