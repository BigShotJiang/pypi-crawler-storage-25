from typing import Any

def envelope(data=None, summary_text="", partial_failures=None, error=None, metadata=None):
    return {
        "ok": error is None,
        "data": data,
        "summary_text": summary_text,
        "partial_failures": partial_failures or [],
        "error": error,
        "metadata": metadata or {},
    }

def post_shape(post_id, title, url, score, upvote_ratio, created_utc,
               subreddit, credibility_score, account_age_days, flair):
    return {
        "id": post_id,
        "title": title,
        "url": url,
        "score": score,
        "upvote_ratio": upvote_ratio,
        "created_utc": created_utc,
        "subreddit": subreddit,
        "flair": flair,
    }
