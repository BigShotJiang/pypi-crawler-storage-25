from mcp.server.fastmcp import FastMCP
from .reddit_tools import research_topic, compare, find_dissent, get_thread

mcp = FastMCP("reddit-scout")


@mcp.tool()
def research_topic_tool(
    query: str,
    subreddits: list[str] | None = None,
    since: str = "12m",
    depth: int = 2,
) -> dict:
    """
    Research what Reddit says about a topic. Returns structured verdict, highly-upvoted
    posts, controversial posts, and cited sources from the last 12 months by default.
    since: rolling window — '1m', '3m', '6m', '12m', '2y'
    depth: 1 = single pass, 2 = multi-pass (recommended)
    """
    return research_topic(query, subreddits=subreddits, since=since, depth=depth)


@mcp.tool()
def compare_tool(
    subjects: list[str],
    dimensions: list[str] | None = None,
    subreddits: list[str] | None = None,
) -> dict:
    """
    Compare multiple subjects side-by-side using Reddit research.
    Example: compare_tool(subjects=["Honda CR-V 2024", "Toyota RAV4 2024"])
    """
    return compare(subjects, dimensions=dimensions, subreddits=subreddits)


@mcp.tool()
def find_dissent_tool(claim: str, context: str | None = None) -> dict:
    """
    Actively search for Reddit posts that contradict or warn against a claim.
    Use this to surface counterarguments before making a decision.
    Example: find_dissent_tool(claim="Honda CR-V 2024 is reliable")
    """
    return find_dissent(claim, context=context)


@mcp.tool()
def get_thread_tool(
    url_or_id: str,
    include_replies: bool = True,
    max_depth: int = 3,
) -> dict:
    """
    Fetch a full Reddit thread with top comments.
    url_or_id: full Reddit URL or post ID (e.g. 'abc123')
    """
    return get_thread(url_or_id, include_replies=include_replies, max_depth=max_depth)


def main():
    mcp.run()


if __name__ == "__main__":
    main()
