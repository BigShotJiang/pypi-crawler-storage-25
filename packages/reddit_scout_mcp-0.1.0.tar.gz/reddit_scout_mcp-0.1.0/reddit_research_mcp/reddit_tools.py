import time
from datetime import datetime, timezone

import httpx

from .schemas import post_shape, envelope
from .credibility import score_post_dict

ARCTIC_BASE = "https://arctic-shift.photon-reddit.com/api"
HEADERS = {"User-Agent": "reddit-research-mcp/1.0"}

STOPWORDS = {
    "a", "an", "the", "and", "or", "but", "in", "on", "at", "to", "for",
    "of", "with", "is", "it", "i", "my", "me", "do", "be", "was", "are",
    "should", "would", "could", "want", "wait", "buy", "get", "have", "has",
    "what", "how", "why", "when", "who", "not", "no", "yes", "just", "so",
    "this", "that", "from", "if", "will", "can", "its", "any", "all",
}

def _key_terms(query: str) -> list[str]:
    """Extract meaningful keywords from a query for relevance filtering."""
    words = query.lower().replace("?", "").replace(",", "").split()
    return [w for w in words if len(w) > 3 and w not in STOPWORDS]


def _search_terms(key_terms: list[str]) -> list[str]:
    """Strip years/numbers from key terms for the Reddit search query.
    Years like 2024/2025 OR-match millions of unrelated posts."""
    return [t for t in key_terms if not t.isdigit()]


def _is_relevant(post: dict, key_terms: list[str], min_matches: int = 1) -> bool:
    """Check if a post title contains enough query keywords. Title-only to avoid
    incidental selftext matches (e.g. a car accident video that happens to be a CR-V)."""
    if not key_terms:
        return True
    title = post.get("title", "").lower()
    matches = sum(1 for term in key_terms if term in title)
    return matches >= min_matches


GENERIC_SUBS = {"AskReddit", "NoStupidQuestions", "answers"}

def _is_generic_topic(subs: list[str]) -> bool:
    return set(subs) == GENERIC_SUBS

DISSENT_PREFIXES = [
    "problem with", "issues with", "don't buy", "avoid", "regret buying",
    "disappointed", "failed", "broke", "worst", "overrated", "not worth",
    "should i return", "bad experience", "stay away", "warning",
]

ROLLING_WINDOW_SECS = {
    "1m":  30 * 86400,
    "3m":  90 * 86400,
    "6m": 180 * 86400,
    "12m": 365 * 86400,
    "2y":  730 * 86400,
}


def _cutoff_ts(since: str) -> int:
    window = ROLLING_WINDOW_SECS.get(since, ROLLING_WINDOW_SECS["12m"])
    return int(time.time() - window)


def _auto_subreddits(query: str) -> list[str]:
    q = query.lower()
    if any(w in q for w in ["car", "suv", "truck", "honda", "toyota", "bmw", "ford"]):
        return ["cars", "whatcarshouldibuy", "askcarsales", "mechanics", "cartalk", "Honda"]
    if any(w in q for w in ["stock", "invest", "etf", "market", "crypto"]):
        return ["investing", "personalfinance", "stocks", "wallstreetbets"]
    if any(w in q for w in ["laptop", "phone", "gpu", "pc", "monitor"]):
        return ["hardware", "techsupport", "buildapc", "gadgets"]
    if any(w in q for w in ["job", "career", "salary", "interview", "resume"]):
        return ["cscareerquestions", "careerguidance", "jobs"]
    return ["AskReddit", "NoStupidQuestions", "answers"]


def _search_reddit(query: str, cutoff: int, limit=50, subreddits: list[str] = None, key_terms: list[str] = None) -> tuple[list, list]:
    """Site-wide search using Reddit's public JSON API. No auth required."""
    posts = []
    failures = []

    # time bucket: map rolling window to Reddit's t= param (best effort)
    now = time.time()
    age_days = (now - cutoff) / 86400
    if age_days <= 32:   t_val = "month"
    elif age_days <= 95: t_val = "3m"  # Reddit doesn't have 3m, fall back to year
    elif age_days <= 185: t_val = "6m"
    else: t_val = "year"

    try:
        with httpx.Client(headers=HEADERS, timeout=20) as client:
            params = {
                "q": query,
                "sort": "relevance",
                "t": t_val,
                "limit": min(limit, 100),
            }
            # restrict to subreddits if caller wants it (comma-joined)
            if subreddits:
                params["restrict_sr"] = "true"
                params["q"] = f"{query} subreddit:{'+'.join(subreddits)}"

            resp = client.get("https://www.reddit.com/search.json", params=params)
            resp.raise_for_status()

            terms = key_terms or _key_terms(query)
            for child in resp.json().get("data", {}).get("children", []):
                p = child.get("data", {})
                if p.get("created_utc", 0) < cutoff:
                    continue
                if _is_tombstone(p):
                    continue
                if not _is_relevant(p, terms):
                    continue
                posts.append(p)
    except Exception as e:
        failures.append({"subreddit": "reddit.com", "reason": str(e)})

    return posts, failures


def _search_arctic(query: str, subreddits: list[str], cutoff: int, limit=50) -> tuple[list, list]:
    """Arctic Shift fallback for subreddit-specific deep search."""
    posts = []
    failures = []
    with httpx.Client(headers=HEADERS, timeout=15) as client:
        for sub in subreddits:
            try:
                resp = client.get(f"{ARCTIC_BASE}/posts/search", params={
                    "query": query,
                    "subreddit": sub,
                    "after": str(cutoff),
                    "limit": limit,
                    "sort": "desc",
                })
                resp.raise_for_status()
                for p in resp.json().get("data", []):
                    if p.get("created_utc", 0) < cutoff:
                        continue
                    if _is_tombstone(p):
                        continue
                    posts.append(p)
            except Exception as e:
                failures.append({"subreddit": sub, "reason": str(e)})
    return posts, failures


def _is_tombstone(post: dict) -> bool:
    selftext = post.get("selftext", "")
    author = post.get("author", "")
    return selftext in ("[deleted]", "[removed]") and author in ("[deleted]", "")


def _format_post(p: dict) -> dict:
    cred_score, age_days = score_post_dict(p)
    return post_shape(
        post_id=p.get("id", ""),
        title=p.get("title", ""),
        url=f"https://reddit.com{p.get('permalink', '')}" if p.get("permalink") else p.get("url", ""),
        score=p.get("score", 0),
        upvote_ratio=p.get("upvote_ratio"),
        created_utc=datetime.fromtimestamp(p.get("created_utc", 0), tz=timezone.utc).isoformat(),
        subreddit=p.get("subreddit", ""),
        credibility_score=cred_score,
        account_age_days=age_days,
        flair=p.get("author_flair_text"),
    )


def _build_consensus(posts: list) -> tuple[str, list, list]:
    if not posts:
        return "mixed", [], []

    high = [p for p in posts if p.get("upvote_ratio", 0.5) >= 0.75]
    low  = [p for p in posts if p.get("upvote_ratio", 0.5) <  0.75]
    total = len(posts)

    if len(high) / total >= 0.6:
        verdict = "broadly_positive"
    elif len(low) / total >= 0.6:
        verdict = "broadly_critical"
    else:
        verdict = "mixed"

    return verdict, high[:5], low[:5]


def research_topic(query: str, subreddits=None, since="12m", depth=2) -> dict:
    cutoff = _cutoff_ts(since)
    all_failures = []

    terms = _key_terms(query)
    # Strip years for both search query AND relevance filtering
    # Years like 2024/2025 appear in millions of unrelated posts
    filter_terms = _search_terms(terms)
    search_query = " ".join(filter_terms) if filter_terms else " ".join(terms) if terms else query

    # pass 1: site-wide search with cleaned query + year-free filter
    posts, failures = _search_reddit(search_query, cutoff, limit=100, subreddits=subreddits, key_terms=filter_terms)
    all_failures.extend(failures)

    if depth >= 2 and posts:
        # Second pass: search for the same topic but sorted by new — catches recent posts
        # Always use the original filter_terms to stay on topic
        more, more_f = _search_reddit(search_query, cutoff, limit=50, subreddits=subreddits, key_terms=filter_terms)
        all_failures.extend(more_f)
        existing = {p.get("id") for p in posts}
        posts.extend(p for p in more if p.get("id") not in existing)

    if not posts:
        return envelope(
            error={"message": f"No posts found for '{query}' in last {since}. Try broader terms.", "code": "NO_RESULTS"},
            partial_failures=all_failures,
        )

    posts.sort(key=lambda p: p.get("score", 0), reverse=True)
    verdict, consensus_posts, dissent_posts = _build_consensus(posts)

    formatted       = [_format_post(p) for p in posts[:20]]
    consensus_fmt   = [_format_post(p) for p in consensus_posts]
    dissent_fmt     = [_format_post(p) for p in dissent_posts]

    oldest = min(p.get("created_utc", time.time()) for p in posts)
    oldest_date = datetime.fromtimestamp(oldest, tz=timezone.utc).strftime("%Y-%m-%d")

    if verdict == "broadly_positive":
        summary = f"Reddit is broadly positive on '{query}' ({len(consensus_posts)} of {len(posts)} posts highly upvoted). Top take: \"{consensus_posts[0].get('title', '')}\"" if consensus_posts else f"Broadly positive across {len(posts)} posts."
    elif verdict == "broadly_critical":
        summary = f"Reddit leans critical on '{query}' — most posts are controversial or low-rated. Check cited posts before deciding."
    else:
        summary = f"Reddit is mixed on '{query}' with no clear signal ({len(posts)} posts across {len(set(p.get('subreddit','') for p in posts))} subreddits)."

    if all_failures:
        summary += f" Note: {len(all_failures)} search(es) failed — {all_failures[0]['reason'][:60]}."

    subreddits_found = list({p.get("subreddit", "") for p in posts if p.get("subreddit")})
    return envelope(
        data={
            "verdict": verdict,
            "highly_upvoted": consensus_fmt,
            "controversial": dissent_fmt,
            "cited_posts": formatted,
            "subreddits_found": subreddits_found,
            "split": {"highly_upvoted": len(consensus_posts), "controversial": len(dissent_posts), "total": len(posts)},
        },
        summary_text=summary,
        partial_failures=all_failures,
        metadata={
            "queried_at": datetime.now(timezone.utc).isoformat(),
            "sources_count": len(posts),
            "oldest_source_date": oldest_date,
            "time_window_applied": since,
            "subreddits_found": subreddits_found,
        },
    )


def compare(subjects: list, dimensions=None, subreddits=None) -> dict:
    results = {}
    all_failures = []
    for subject in subjects:
        r = research_topic(subject, subreddits=subreddits)
        results[subject] = r
        all_failures.extend(r.get("partial_failures", []))

    verdicts = {
        s: results[s].get("data", {}).get("verdict", "unknown") if results[s].get("ok") else "error"
        for s in subjects
    }
    comparison_text = " vs ".join(f"{s} ({verdicts[s]})" for s in subjects)

    return envelope(
        data={"subjects": results, "verdicts": verdicts},
        summary_text=f"Comparison: {comparison_text}",
        partial_failures=all_failures,
        metadata={"queried_at": datetime.now(timezone.utc).isoformat()},
    )


def find_dissent(claim: str, context=None) -> dict:
    cutoff = _cutoff_ts("12m")
    all_failures = []
    dissent_posts = []
    seen_ids = set()

    for prefix in DISSENT_PREFIXES[:6]:
        posts, failures = _search_reddit(f"{prefix} {claim}", cutoff, limit=25)
        all_failures.extend(failures)
        for p in posts:
            if p.get("id") not in seen_ids:
                dissent_posts.append(p)
                seen_ids.add(p.get("id"))

    dissent_posts.sort(key=lambda p: p.get("score", 0), reverse=True)
    formatted = [_format_post(p) for p in dissent_posts[:15]]

    if not formatted:
        return envelope(
            data={"dissent_posts": []},
            summary_text=f"No notable dissent found for '{claim}' in the last 12 months.",
            partial_failures=all_failures,
        )

    summary = f"Found {len(formatted)} posts contradicting or warning about '{claim}'. Top concern: \"{dissent_posts[0].get('title', '')}\""
    return envelope(
        data={"dissent_posts": formatted},
        summary_text=summary,
        partial_failures=all_failures,
        metadata={"queried_at": datetime.now(timezone.utc).isoformat(), "sources_count": len(formatted)},
    )


def get_thread(url_or_id: str, include_replies=True, max_depth=3) -> dict:
    """Uses Reddit's public JSON API (no auth required) for full thread fetch."""
    try:
        if url_or_id.startswith("http"):
            base = url_or_id.rstrip("/")
            json_url = base + ".json"
        else:
            json_url = f"https://www.reddit.com/comments/{url_or_id}.json"

        with httpx.Client(headers=HEADERS, timeout=15) as client:
            resp = client.get(json_url, params={"limit": 50, "depth": max_depth})

        if resp.status_code == 404:
            return envelope(error={"message": "Thread not found — may have been deleted.", "code": "NOT_FOUND"})
        resp.raise_for_status()

        listing = resp.json()
        post_data = listing[0]["data"]["children"][0]["data"]

        if post_data.get("author") in ("[deleted]", None) and post_data.get("selftext") in ("[deleted]", "[removed]"):
            return envelope(error={"message": "Thread deleted or removed — no recoverable content.", "code": "TOMBSTONE"})

        comments = []
        if include_replies and len(listing) > 1:
            for child in listing[1]["data"]["children"]:
                c = child.get("data", {})
                if not c.get("body") or c["body"] in ("[deleted]", "[removed]"):
                    continue
                comments.append({
                    "id": c.get("id"),
                    "author": c.get("author", "[deleted]"),
                    "body": c["body"][:1000],
                    "score": c.get("score", 0),
                    "created_utc": datetime.fromtimestamp(c.get("created_utc", 0), tz=timezone.utc).isoformat(),
                })

        cred, age = score_post_dict(post_data)
        return envelope(
            data={
                "id": post_data.get("id"),
                "title": post_data.get("title"),
                "url": f"https://reddit.com{post_data.get('permalink', '')}",
                "score": post_data.get("score", 0),
                "upvote_ratio": post_data.get("upvote_ratio"),
                "created_utc": datetime.fromtimestamp(post_data.get("created_utc", 0), tz=timezone.utc).isoformat(),
                "subreddit": post_data.get("subreddit"),
                "selftext": post_data.get("selftext", "")[:2000] or None,
                "credibility_score": cred,
                "top_comments": comments,
            },
            summary_text=f"Thread: \"{post_data.get('title')}\" — {len(comments)} comments retrieved from r/{post_data.get('subreddit')}.",
            metadata={"queried_at": datetime.now(timezone.utc).isoformat()},
        )
    except Exception as e:
        return envelope(error={"message": f"Could not fetch thread: {e}", "code": "FETCH_ERROR"})
