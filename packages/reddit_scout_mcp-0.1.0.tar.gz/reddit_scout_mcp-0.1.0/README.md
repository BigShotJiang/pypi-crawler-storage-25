# reddit-research-mcp

Gives Claude structured access to Reddit discussions — no API key required.

Better than Google's AI overview: multi-pass search, full thread reading, time-aware filtering, explicit counter-evidence surfacing.

## Quickstart (uvx — no install needed)

Add to your Claude Code `.mcp.json`:

```json
{
  "mcpServers": {
    "reddit-research": {
      "command": "uvx",
      "args": ["reddit-research-mcp"]
    }
  }
}
```

Restart Claude Code. Done.

## Quickstart (pip)

```bash
pip install reddit-research-mcp
```

```json
{
  "mcpServers": {
    "reddit-research": {
      "command": "reddit-research-mcp"
    }
  }
}
```

## Tools

| Tool | What it does |
|---|---|
| `research_topic` | Multi-pass search, returns verdict + highly-upvoted + controversial posts |
| `compare` | Side-by-side Reddit sentiment for 2+ subjects |
| `find_dissent` | Actively surfaces posts that contradict a claim |
| `get_thread` | Fetches a full thread with top comments |

## Output shape

```json
{
  "ok": true,
  "summary_text": "Reddit is broadly positive on '...' — ...",
  "data": {
    "verdict": "broadly_positive | broadly_critical | mixed",
    "highly_upvoted": [...],
    "controversial": [...],
    "cited_posts": [...],
    "split": { "highly_upvoted": 5, "controversial": 2, "total": 93 }
  }
}
```

Each post: `id`, `title`, `url`, `score`, `upvote_ratio`, `created_utc`, `subreddit`, `flair`

## Parameters

`research_topic(query, since="12m", depth=2)`
- `since`: `"1m"` `"3m"` `"6m"` `"12m"` `"2y"`
- `depth`: `1` = single pass, `2` = multi-pass (recommended)

## Caveats

- No auth required — uses Reddit's public JSON API + Arctic Shift
- Reddit consensus can be confidently wrong on medical, legal, and finance topics
- This tool surfaces what Reddit says, not what is true
