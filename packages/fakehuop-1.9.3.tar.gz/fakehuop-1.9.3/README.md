# Sample Package

This is a simple Python package published to PyPI.

## Installation

pip install sample-package

## Usage

from sample_package import add, greet

print(add(2,3))
print(greet("Mayank"))