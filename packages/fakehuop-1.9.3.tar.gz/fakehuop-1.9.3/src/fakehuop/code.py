from groq import Groq

# your API key
client = Groq(api_key="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")

MODEL = "openai/gpt-oss-20b"   # change here if needed



def code(prompt):
    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "user", "content": prompt}
        ]
    )

    return response.choices[0].message.content



if __name__ == "__main__":
    user_prompt = input("You: ")
    answer = code(user_prompt)
    print("\nLLM:", answer, "\n")