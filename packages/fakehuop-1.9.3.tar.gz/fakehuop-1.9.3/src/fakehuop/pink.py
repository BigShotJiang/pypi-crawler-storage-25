from groq import Groq

# your API key
client = Groq(api_key="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")

MODEL = "openai/gpt-oss-20b"   # change here if needed



def pink(prompt):
    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "user", "content": prompt}
        ]
    )

    return response.choices[0].message.content



if __name__ == "__main__":
    user_prompt = input("You: ")
    answer = pink(user_prompt)
    print("\nLLM:", answer, "\n")