from groq import Groq

# your API key
client = Groq(api_key="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")

MODEL = "openai/gpt-oss-20b"   # change here if needed



def dropnull(prompt):
    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "user", "content": prompt}
        ]
    )

    return response.choices[0].message.content



if __name__ == "__main__":
    user_prompt = input("You: ")
    answer = koko(user_prompt)
    print("\nLLM:", answer, "\n")