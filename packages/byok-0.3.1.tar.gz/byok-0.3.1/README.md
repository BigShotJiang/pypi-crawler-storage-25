# BYO PYTHON SDK for BYOK

Official Python SDK for BYO — BYOK (Bring Your Own Key).

## Installation

```bash
pip install byok
```

## Quick Start

```python
import os
from byo import BYOK

byok = BYOK(api_key=os.environ["BYOK_API_KEY"])

# Proxy an OpenAI request
openai = byok.openai(ref_id="customer_123")
response = openai.responses.create(
    model="gpt-4.1",
    input="Hello from BYOK!"
)
print(response)
```

## OpenAI

### Responses API

```python
openai = byok.openai(ref_id="customer_123")
response = openai.responses.create(model="gpt-4.1", input="What is BYOK?")
```

### Chat Completions API

```python
openai = byok.openai(ref_id="customer_123")
response = openai.chat.completions.create(
    model="gpt-4.1",
    messages=[{"role": "user", "content": "Hello!"}]
)
```

## Anthropic

### Messages API

```python
claude = byok.anthropic(ref_id="customer_123")
response = claude.messages.create(
    model="claude-sonnet-4-20250514",
    max_tokens=1024,
    messages=[{"role": "user", "content": "Hello!"}]
)
```

## Google AI Studio

### Generate Content

```python
gemini = byok.google(ref_id="customer_123")
response = gemini.generate_content.create(
    model="gemini-2.0-flash",
    contents=[{"parts": [{"text": "Hello!"}]}]
)
```

## Azure OpenAI

### Chat Completions

```python
azure = byok.azure_openai(ref_id="customer_123")
response = azure.chat.completions.create(
    model="gpt-4",
    messages=[{"role": "user", "content": "Hello!"}]
)
```

Azure OpenAI requires `provider_config` when connecting the key:

```python
byok.keys.connect(
    provider="azure-openai",
    ref_id="customer_123",
    provider_key="your-azure-api-key",
    provider_config={
        "baseUrl": "https://your-resource.openai.azure.com",
        "deploymentName": "gpt-4",
    },
)
```

## AWS Bedrock

### Converse

```python
bedrock = byok.bedrock(ref_id="customer_123")
response = bedrock.converse.create(
    modelId="anthropic.claude-3-haiku-20240307-v1:0",
    messages=[{"role": "user", "content": [{"text": "Hello!"}]}]
)
```

AWS Bedrock requires `provider_config` when connecting the key:

```python
byok.keys.connect(
    provider="bedrock",
    ref_id="customer_123",
    provider_key="your-aws-secret-access-key",
    provider_config={
        "accessKeyId": "AKIA...",
        "region": "us-east-1",
    },
)
```

## Key Management

```python
# Connect a provider key
byok.keys.connect(
    provider="openai",
    ref_id="customer_123",
    provider_key="sk-..."
)

# Validate a stored key
result = byok.keys.validate(provider="openai", ref_id="customer_123")

# Revoke a stored key
byok.keys.revoke(provider="openai", ref_id="customer_123")
```

## Error Handling

```python
from byo import BYOK, BYOKError, AuthenticationError

try:
    response = openai.responses.create(model="gpt-4.1", input="Hello")
except AuthenticationError:
    print("Invalid API key")
except BYOKError as e:
    print(f"Error {e.status_code}: {e.message}")
```

## License

[FSL-1.1-MIT](LICENSE)