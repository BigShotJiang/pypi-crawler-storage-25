from __future__ import annotations

import os
from typing import Any

import httpx

from byo.errors import BYOKError, AuthenticationError, ProviderError

DEFAULT_BASE_URL = os.environ.get("BYO_BASE_URL") or (
    "https://api.usebyo.com"
    if os.environ.get("NODE_ENV") == "production"
    else "http://localhost:3000"
)


class BYOK:
    def __init__(self, api_key: str, base_url: str = DEFAULT_BASE_URL):
        if not api_key:
            raise AuthenticationError("API key is required")
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._client = httpx.Client(
            base_url=self._base_url,
            headers={
                "Authorization": f"Bearer {self._api_key}",
                "Content-Type": "application/json",
            },
            timeout=60.0,
        )
        self.keys = KeysClient(self._client)
        self.mcp = McpClient(self._client)

    def openai(self, *, ref_id: str) -> OpenAIClient:
        return OpenAIClient(self._client, ref_id)

    def anthropic(self, *, ref_id: str) -> AnthropicClient:
        return AnthropicClient(self._client, ref_id)

    def google(self, *, ref_id: str) -> GoogleClient:
        return GoogleClient(self._client, ref_id)

    def azure_openai(self, *, ref_id: str) -> AzureOpenAIClient:
        return AzureOpenAIClient(self._client, ref_id)

    def bedrock(self, *, ref_id: str) -> BedrockClient:
        return BedrockClient(self._client, ref_id)

    def stripe(self, *, ref_id: str) -> StripeClient:
        return StripeClient(self._client, ref_id)

    def planetscale(self, *, ref_id: str) -> PlanetScaleClient:
        return PlanetScaleClient(self._client, ref_id)

    def openai_compatible(self, *, ref_id: str, provider: str = "openai") -> dict[str, Any]:
        """Returns config kwargs for ``openai.OpenAI(**config)``."""
        headers: dict[str, str] = {"X-BYO-Ref-Id": ref_id}
        if provider != "openai":
            headers["X-BYO-Provider"] = provider
        return {
            "base_url": f"{self._base_url}/v1",
            "api_key": self._api_key,
            "default_headers": headers,
        }

    def close(self):
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()


class _McpToolsClient:
    def __init__(self, client: httpx.Client):
        self._client = client

    def list(self, *, limit: int | None = None, offset: int | None = None) -> dict:
        params: dict[str, str] = {}
        if limit is not None:
            params["limit"] = str(limit)
        if offset is not None:
            params["offset"] = str(offset)
        return _request(self._client, "GET", "/mcp/tools", params=params)

    def create(
        self,
        *,
        name: str,
        description: str,
        method: str,
        path: str,
        input_schema: dict[str, Any],
    ) -> dict:
        return _request(self._client, "POST", "/mcp/tools", json={
            "name": name,
            "description": description,
            "method": method,
            "path": path,
            "inputSchema": input_schema,
        })

    def update(self, tool_id: str, **kwargs: Any) -> dict:
        body: dict[str, Any] = {}
        if "description" in kwargs:
            body["description"] = kwargs["description"]
        if "method" in kwargs:
            body["method"] = kwargs["method"]
        if "path" in kwargs:
            body["path"] = kwargs["path"]
        if "input_schema" in kwargs:
            body["inputSchema"] = kwargs["input_schema"]
        return _request(self._client, "PATCH", f"/mcp/tools/{tool_id}", json=body)

    def delete(self, tool_id: str) -> dict:
        return _request(self._client, "DELETE", f"/mcp/tools/{tool_id}")

    def import_spec(self, *, spec: str, confirm: bool = False) -> dict:
        qs = "?confirm=true" if confirm else ""
        return _request(self._client, "POST", f"/mcp/tools/import{qs}", json={"spec": spec})


class _McpTokensClient:
    def __init__(self, client: httpx.Client):
        self._client = client

    def create(
        self,
        *,
        ref_id: str,
        name: str | None = None,
        tool_ids: list[str] | None = None,
    ) -> dict:
        body: dict[str, Any] = {"refId": ref_id}
        if name is not None:
            body["name"] = name
        if tool_ids is not None:
            body["toolIds"] = tool_ids
        return _request(self._client, "POST", "/mcp/tokens", json=body)

    def list(self, *, limit: int | None = None, offset: int | None = None) -> dict:
        params: dict[str, str] = {}
        if limit is not None:
            params["limit"] = str(limit)
        if offset is not None:
            params["offset"] = str(offset)
        return _request(self._client, "GET", "/mcp/tokens", params=params)

    def revoke(self, token_id: str) -> dict:
        return _request(self._client, "DELETE", f"/mcp/tokens/{token_id}")


class _McpConfigClient:
    def __init__(self, client: httpx.Client):
        self._client = client

    def get(self) -> dict:
        return _request(self._client, "GET", "/mcp/config")

    def update(
        self,
        *,
        base_url: str | None = None,
        auth_header: str | None = None,
        auth_value: str | None = None,
    ) -> dict:
        body: dict[str, Any] = {}
        if base_url is not None:
            body["baseUrl"] = base_url
        if auth_header is not None:
            body["authHeader"] = auth_header
        if auth_value is not None:
            body["authValue"] = auth_value
        return _request(self._client, "PATCH", "/mcp/config", json=body)


class McpClient:
    def __init__(self, client: httpx.Client):
        self._client = client
        self.tools = _McpToolsClient(client)
        self.tokens = _McpTokensClient(client)
        self.config = _McpConfigClient(client)

    def enable(self) -> dict:
        return _request(self._client, "POST", "/mcp/enable")

    def disable(self) -> dict:
        return _request(self._client, "POST", "/mcp/disable")


class KeysClient:
    def __init__(self, client: httpx.Client):
        self._client = client

    def connect(
        self,
        *,
        provider: str,
        ref_id: str,
        provider_key: str,
        provider_config: dict[str, Any] | None = None,
    ) -> dict:
        body: dict[str, Any] = {
            "provider": provider,
            "refId": ref_id,
            "providerKey": provider_key,
        }
        if provider_config is not None:
            body["providerConfig"] = provider_config
        return _request(self._client, "POST", "/keys/connect", json=body)

    def validate(self, *, provider: str, ref_id: str) -> dict:
        return _request(self._client, "POST", "/keys/validate", json={
            "provider": provider,
            "refId": ref_id,
        })

    def revoke(self, *, provider: str, ref_id: str) -> dict:
        return _request(self._client, "DELETE", "/keys/revoke", json={
            "provider": provider,
            "refId": ref_id,
        })


class OpenAIClient:
    def __init__(self, client: httpx.Client, ref_id: str):
        self.responses = _OpenAIResponses(client, ref_id)
        self.chat = _OpenAIChat(client, ref_id)


class _OpenAIChat:
    def __init__(self, client: httpx.Client, ref_id: str):
        self.completions = _OpenAIChatCompletions(client, ref_id)


class _OpenAIResponses:
    def __init__(self, client: httpx.Client, ref_id: str):
        self._client = client
        self._ref_id = ref_id

    def create(self, **kwargs) -> dict:
        resp = _request(self._client, "POST", "/proxy/openai/responses", json={
            "refId": self._ref_id,
            "providerPayload": kwargs,
        })
        return _extract_proxy_data(resp)


class _OpenAIChatCompletions:
    def __init__(self, client: httpx.Client, ref_id: str):
        self._client = client
        self._ref_id = ref_id

    def create(self, **kwargs) -> dict:
        resp = _request(self._client, "POST", "/proxy/openai/chat/completions", json={
            "refId": self._ref_id,
            "providerPayload": kwargs,
        })
        return _extract_proxy_data(resp)


class AnthropicClient:
    def __init__(self, client: httpx.Client, ref_id: str):
        self.messages = _AnthropicMessages(client, ref_id)


class _AnthropicMessages:
    def __init__(self, client: httpx.Client, ref_id: str):
        self._client = client
        self._ref_id = ref_id

    def create(self, **kwargs) -> dict:
        resp = _request(self._client, "POST", "/proxy/anthropic/messages", json={
            "refId": self._ref_id,
            "providerPayload": kwargs,
        })
        return _extract_proxy_data(resp)


class GoogleClient:
    def __init__(self, client: httpx.Client, ref_id: str):
        self.generate_content = _GoogleGenerateContent(client, ref_id)


class _GoogleGenerateContent:
    def __init__(self, client: httpx.Client, ref_id: str):
        self._client = client
        self._ref_id = ref_id

    def create(self, **kwargs) -> dict:
        resp = _request(self._client, "POST", "/proxy/google/generateContent", json={
            "refId": self._ref_id,
            "providerPayload": kwargs,
        })
        return _extract_proxy_data(resp)


class AzureOpenAIClient:
    def __init__(self, client: httpx.Client, ref_id: str):
        self.chat = _AzureOpenAIChat(client, ref_id)


class _AzureOpenAIChat:
    def __init__(self, client: httpx.Client, ref_id: str):
        self.completions = _AzureOpenAIChatCompletions(client, ref_id)


class _AzureOpenAIChatCompletions:
    def __init__(self, client: httpx.Client, ref_id: str):
        self._client = client
        self._ref_id = ref_id

    def create(self, **kwargs) -> dict:
        resp = _request(self._client, "POST", "/proxy/azure-openai/chat/completions", json={
            "refId": self._ref_id,
            "providerPayload": kwargs,
        })
        return _extract_proxy_data(resp)


class BedrockClient:
    def __init__(self, client: httpx.Client, ref_id: str):
        self.converse = _BedrockConverse(client, ref_id)


class _BedrockConverse:
    def __init__(self, client: httpx.Client, ref_id: str):
        self._client = client
        self._ref_id = ref_id

    def create(self, **kwargs) -> dict:
        resp = _request(self._client, "POST", "/proxy/bedrock/converse", json={
            "refId": self._ref_id,
            "providerPayload": kwargs,
        })
        return _extract_proxy_data(resp)


class _StripePassthrough:
    def __init__(self, client: httpx.Client, ref_id: str):
        self._client = client
        self._ref_id = ref_id

    def send(self, method: str, path: str, params: dict[str, Any] | None = None) -> dict:
        resp = _request(self._client, "POST", "/proxy/stripe/passthrough", json={
            "refId": self._ref_id,
            "providerPayload": {"method": method, "path": path, "params": params or {}},
        })
        return _extract_proxy_data(resp)


class _StripeResource:
    def __init__(self, pt: _StripePassthrough, resource: str):
        self._pt = pt
        self._resource = resource

    def create(self, **kwargs) -> dict:
        return self._pt.send("POST", f"/v1/{self._resource}", kwargs)

    def retrieve(self, id: str) -> dict:
        return self._pt.send("GET", f"/v1/{self._resource}/{id}")

    def update(self, id: str, **kwargs) -> dict:
        return self._pt.send("POST", f"/v1/{self._resource}/{id}", kwargs)

    def list(self, **kwargs) -> dict:
        return self._pt.send("GET", f"/v1/{self._resource}", kwargs or None)

    def delete(self, id: str) -> dict:
        return self._pt.send("DELETE", f"/v1/{self._resource}/{id}")


class _StripeChargesResource(_StripeResource):
    def capture(self, id: str, **kwargs) -> dict:
        return self._pt.send("POST", f"/v1/charges/{id}/capture", kwargs or None)


class _StripePaymentIntentsResource(_StripeResource):
    def confirm(self, id: str, **kwargs) -> dict:
        return self._pt.send("POST", f"/v1/payment_intents/{id}/confirm", kwargs or None)

    def capture(self, id: str, **kwargs) -> dict:
        return self._pt.send("POST", f"/v1/payment_intents/{id}/capture", kwargs or None)

    def cancel(self, id: str, **kwargs) -> dict:
        return self._pt.send("POST", f"/v1/payment_intents/{id}/cancel", kwargs or None)


class _StripePaymentMethodsResource(_StripeResource):
    def attach(self, id: str, **kwargs) -> dict:
        return self._pt.send("POST", f"/v1/payment_methods/{id}/attach", kwargs)

    def detach(self, id: str) -> dict:
        return self._pt.send("POST", f"/v1/payment_methods/{id}/detach")


class _StripeInvoicesResource(_StripeResource):
    def finalize_invoice(self, id: str, **kwargs) -> dict:
        return self._pt.send("POST", f"/v1/invoices/{id}/finalize", kwargs or None)

    def pay(self, id: str, **kwargs) -> dict:
        return self._pt.send("POST", f"/v1/invoices/{id}/pay", kwargs or None)

    def void_invoice(self, id: str) -> dict:
        return self._pt.send("POST", f"/v1/invoices/{id}/void")


class _StripeCheckoutSessionsResource(_StripeResource):
    def expire(self, id: str) -> dict:
        return self._pt.send("POST", f"/v1/checkout/sessions/{id}/expire")


class _StripePayoutsResource(_StripeResource):
    def cancel(self, id: str) -> dict:
        return self._pt.send("POST", f"/v1/payouts/{id}/cancel")


class _StripeSetupIntentsResource(_StripeResource):
    def confirm(self, id: str, **kwargs) -> dict:
        return self._pt.send("POST", f"/v1/setup_intents/{id}/confirm", kwargs or None)

    def cancel(self, id: str) -> dict:
        return self._pt.send("POST", f"/v1/setup_intents/{id}/cancel")


class _StripeDisputesResource(_StripeResource):
    def close(self, id: str) -> dict:
        return self._pt.send("POST", f"/v1/disputes/{id}/close")


class StripeClient:
    def __init__(self, client: httpx.Client, ref_id: str):
        pt = _StripePassthrough(client, ref_id)
        self.charges = _StripeChargesResource(pt, "charges")
        self.payment_intents = _StripePaymentIntentsResource(pt, "payment_intents")
        self.payment_methods = _StripePaymentMethodsResource(pt, "payment_methods")
        self.customers = _StripeResource(pt, "customers")
        self.subscriptions = _StripeResource(pt, "subscriptions")
        self.products = _StripeResource(pt, "products")
        self.prices = _StripeResource(pt, "prices")
        self.invoices = _StripeInvoicesResource(pt, "invoices")
        self.checkout_sessions = _StripeCheckoutSessionsResource(pt, "checkout/sessions")
        self.refunds = _StripeResource(pt, "refunds")
        self.payouts = _StripePayoutsResource(pt, "payouts")
        self.setup_intents = _StripeSetupIntentsResource(pt, "setup_intents")
        self.disputes = _StripeDisputesResource(pt, "disputes")
        self.balance = _StripeBalanceResource(pt)
        self.request = pt


class _StripeBalanceResource:
    def __init__(self, pt: _StripePassthrough):
        self._pt = pt

    def retrieve(self) -> dict:
        return self._pt.send("GET", "/v1/balance")


class PlanetScaleClient:
    def __init__(self, client: httpx.Client, ref_id: str):
        self.execute = _PlanetScaleExecute(client, ref_id)


class _PlanetScaleExecute:
    def __init__(self, client: httpx.Client, ref_id: str):
        self._client = client
        self._ref_id = ref_id

    def create(self, *, query: str, params: list | None = None, **kwargs) -> dict:
        payload: dict[str, Any] = {"query": query, **kwargs}
        if params is not None:
            payload["params"] = params
        resp = _request(self._client, "POST", "/proxy/planetscale/execute", json={
            "refId": self._ref_id,
            "providerPayload": payload,
        })
        return _extract_proxy_data(resp)


def _extract_proxy_data(resp: dict) -> dict:
    if not resp.get("success", True):
        error_data = resp.get("data", {})
        if isinstance(error_data, dict):
            msg = error_data.get("error", error_data)
            if isinstance(msg, dict):
                msg = msg.get("message", str(msg))
        else:
            msg = str(error_data)
        raise ProviderError(str(msg), status_code=resp.get("statusCode"))
    return resp.get("data", resp)


def _request(client: httpx.Client, method: str, path: str, **kwargs) -> dict:
    resp = client.request(method, path, **kwargs)
    if resp.status_code == 401:
        raise AuthenticationError()
    try:
        data = resp.json()
    except Exception:
        text = resp.text[:200] if resp.text else f"Request failed ({resp.status_code})"
        raise BYOKError(text, status_code=resp.status_code)
    if not resp.is_success:
        msg = data.get("message", "Request failed") if isinstance(data, dict) else str(data)
        raise BYOKError(msg, status_code=resp.status_code)
    return data
