from __future__ import annotations


class BYOKError(Exception):
    def __init__(self, message: str, status_code: int | None = None, code: str | None = None):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.code = code


class AuthenticationError(BYOKError):
    def __init__(self, message: str = "Invalid or missing API key"):
        super().__init__(message, status_code=401, code="AUTHENTICATION_ERROR")


class ProviderError(BYOKError):
    def __init__(self, message: str, status_code: int | None = None):
        super().__init__(message, status_code=status_code, code="PROVIDER_ERROR")
