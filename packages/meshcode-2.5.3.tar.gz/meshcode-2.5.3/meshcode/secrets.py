"""OS keychain wrapper for MeshCode credentials.

The user's MeshCode api key (mc_xxx) is sensitive and used to be stored
in plain text at ~/.meshcode/credentials.json AND baked into every
~/meshcode/<workspace>/.mcp.json AND passed through env vars to the
MCP server subprocess (visible in `ps eauxww`). That was the equivalent
of leaving your password in ~/Desktop/pass.txt + photocopying it on
every wall.

1.4.1+ stores api keys in the OS keychain via the `keyring` library:

    macOS    → /usr/bin/security (Keychain Access)
    Linux    → libsecret / kwallet (SecretService)
    Windows  → Credential Manager (wincred)
    Fallback → encrypted file via keyrings.cryptfile if no native backend

The MCP server config files (.mcp.json) no longer contain the api key —
they only contain a `MESHCODE_KEYCHAIN_PROFILE` env var that names the
keychain entry to look up at boot time. The api key never appears in
the filesystem, never in process env, never in `ps e`.

Profile naming convention:
    "default"                    — the user's primary api key (used for owned meshworks)
    "mesh:<project>:<agent>"     — a per-agent scoped key (used for friend invites)

The "default" profile is the one set by `meshcode login`. The
per-agent profiles are set by `meshcode join <invite-token>` (Phase 7B).

Backwards compatibility:
- migrate_legacy_credentials() reads ~/.meshcode/credentials.json on
  first 1.4.1 startup and moves it to keychain, then shreds the file.
- get_api_key() falls back to credentials.json if keychain is unavailable
  AND the file still exists. This keeps existing installs from breaking
  if their OS doesn't have a usable keyring backend.
"""
from __future__ import annotations

import json
import os
import secrets as _stdlib_secrets
import sys
from pathlib import Path
from typing import Optional, Dict, Any

SERVICE_NAME = "meshcode"
DEFAULT_PROFILE = "default"
LEGACY_CREDS_FILE = Path.home() / ".meshcode" / "credentials.json"


# ============================================================
# Keyring backend probe
# ============================================================

_KEYRING_AVAILABLE: Optional[bool] = None
_KEYRING_BACKEND_NAME: Optional[str] = None


def _probe_keyring() -> bool:
    """Check whether the keyring library has a usable backend on this OS.

    Returns True if we can read+write keychain entries. Caches the result.
    """
    global _KEYRING_AVAILABLE, _KEYRING_BACKEND_NAME
    if _KEYRING_AVAILABLE is not None:
        return _KEYRING_AVAILABLE
    try:
        import keyring  # type: ignore
        from keyring.errors import KeyringError  # type: ignore
        backend = keyring.get_keyring()
        _KEYRING_BACKEND_NAME = type(backend).__name__
        # Some installs report a "fail" backend on headless Linux. Probe with a
        # write+read+delete round trip on a sentinel key.
        sentinel_key = "meshcode_probe_sentinel"
        sentinel_val = "ok"
        try:
            keyring.set_password(SERVICE_NAME, sentinel_key, sentinel_val)
            got = keyring.get_password(SERVICE_NAME, sentinel_key)
            keyring.delete_password(SERVICE_NAME, sentinel_key)
            _KEYRING_AVAILABLE = (got == sentinel_val)
        except KeyringError:
            _KEYRING_AVAILABLE = False
        except Exception:
            _KEYRING_AVAILABLE = False
    except ImportError:
        _KEYRING_AVAILABLE = False
        _KEYRING_BACKEND_NAME = "(keyring not installed)"
    except Exception:
        # Defensive: a broken Win32 Credential Manager, locked profile,
        # or weird security policy can make even keyring.get_keyring()
        # raise. Never let it bubble up — secrets module must always
        # import cleanly so the MCP server can boot.
        _KEYRING_AVAILABLE = False
        _KEYRING_BACKEND_NAME = "(keyring probe failed)"
    return _KEYRING_AVAILABLE


def keyring_status() -> Dict[str, Any]:
    """Return a small status dict for diagnostics."""
    available = _probe_keyring()
    return {
        "available": available,
        "backend": _KEYRING_BACKEND_NAME or "(unknown)",
    }


# ============================================================
# Profile index — what profiles exist in keychain
# ============================================================
#
# OS keychains let us SET and GET by (service, username) but listing all
# usernames under a service is backend-specific (and often unavailable).
# We keep a small JSON index at ~/.meshcode/profiles.json that lists which
# profile names exist. This is metadata only — the index never contains
# any secret values, just names. Mode 600.

PROFILE_INDEX = Path.home() / ".meshcode" / "profiles.json"


def _load_index() -> Dict[str, Any]:
    if not PROFILE_INDEX.exists():
        return {"profiles": {}}
    try:
        return json.loads(PROFILE_INDEX.read_text(encoding="utf-8"))
    except Exception:
        return {"profiles": {}}


def _save_index(idx: Dict[str, Any]) -> None:
    PROFILE_INDEX.parent.mkdir(parents=True, exist_ok=True)
    tmp = PROFILE_INDEX.with_suffix(".tmp")
    tmp.write_text(json.dumps(idx, indent=2), encoding="utf-8")
    try:
        os.chmod(tmp, 0o600)
    except Exception:
        pass
    tmp.replace(PROFILE_INDEX)


def _index_set(profile: str, meta: Dict[str, Any]) -> None:
    idx = _load_index()
    idx.setdefault("profiles", {})[profile] = meta
    _save_index(idx)


def _index_remove(profile: str) -> None:
    idx = _load_index()
    if profile in idx.get("profiles", {}):
        del idx["profiles"][profile]
        _save_index(idx)


def list_profiles() -> Dict[str, Dict[str, Any]]:
    """Return all known keychain profiles with their metadata."""
    return _load_index().get("profiles", {})


# ============================================================
# Get / set / delete api key
# ============================================================

def set_api_key(api_key: str, profile: str = DEFAULT_PROFILE,
                meta: Optional[Dict[str, Any]] = None) -> bool:
    """Store api_key under (SERVICE_NAME, profile) in the OS keychain.

    Returns True on success. On failure, falls back to writing a mode-600
    file at ~/.meshcode/credentials.<profile>.json (only as a last resort
    when no keychain is available — prints a warning).
    """
    if not api_key or not isinstance(api_key, str):
        return False

    if _probe_keyring():
        try:
            import keyring  # type: ignore
            keyring.set_password(SERVICE_NAME, profile, api_key)
            _index_set(profile, {"backend": _KEYRING_BACKEND_NAME, **(meta or {})})
            return True
        except Exception as e:
            print(f"[meshcode] WARNING: keychain write failed ({e}); falling back to file", file=sys.stderr)

    # Fallback: mode-600 JSON file (legacy path, secured)
    fallback_path = Path.home() / ".meshcode" / f"credentials.{profile}.json"
    fallback_path.parent.mkdir(parents=True, exist_ok=True)
    fallback_path.write_text(json.dumps({"api_key": api_key, **(meta or {})}, indent=2), encoding="utf-8")
    try:
        os.chmod(fallback_path, 0o600)
    except Exception:
        pass
    _index_set(profile, {"backend": "file-fallback", **(meta or {})})
    return True


def get_api_key(profile: str = DEFAULT_PROFILE) -> Optional[str]:
    """Read api_key from the OS keychain (or fallback file).

    Resolution order:
    1. Keychain entry (SERVICE_NAME, profile)
    2. ~/.meshcode/credentials.<profile>.json (fallback file from set_api_key)
    3. ~/.meshcode/credentials.json (legacy pre-1.4.1 file, default profile only)
    """
    if _probe_keyring():
        try:
            import keyring  # type: ignore
            val = keyring.get_password(SERVICE_NAME, profile)
            if val:
                return val
        except Exception:
            pass

    # Fallback file for this profile
    fallback_path = Path.home() / ".meshcode" / f"credentials.{profile}.json"
    if fallback_path.exists():
        try:
            data = json.loads(fallback_path.read_text(encoding="utf-8"))
            if isinstance(data, dict) and data.get("api_key"):
                return data["api_key"]
        except Exception:
            pass

    # Legacy pre-1.4.1 path: only valid for the default profile
    if profile == DEFAULT_PROFILE and LEGACY_CREDS_FILE.exists():
        try:
            data = json.loads(LEGACY_CREDS_FILE.read_text(encoding="utf-8"))
            if isinstance(data, dict) and data.get("api_key"):
                return data["api_key"]
        except Exception:
            pass

    return None


def delete_api_key(profile: str = DEFAULT_PROFILE) -> bool:
    """Remove the keychain entry + any fallback file for this profile."""
    ok = False
    if _probe_keyring():
        try:
            import keyring  # type: ignore
            from keyring.errors import PasswordDeleteError  # type: ignore
            try:
                keyring.delete_password(SERVICE_NAME, profile)
                ok = True
            except PasswordDeleteError:
                pass
        except Exception:
            pass

    fallback_path = Path.home() / ".meshcode" / f"credentials.{profile}.json"
    if fallback_path.exists():
        try:
            _shred_file(fallback_path)
            ok = True
        except Exception:
            pass

    _index_remove(profile)
    return ok


# ============================================================
# Shred (overwrite + unlink) — for migration of plain text files
# ============================================================

def _shred_file(path: Path, passes: int = 3) -> None:
    """Overwrite the file with random bytes then unlink it.

    Not a guarantee against forensic recovery on SSDs (TRIM, wear leveling),
    but raises the bar significantly compared to a plain unlink.
    """
    if not path.exists():
        return
    try:
        size = path.stat().st_size
        if size > 0:
            with open(path, "r+b") as f:
                for _ in range(passes):
                    f.seek(0)
                    f.write(_stdlib_secrets.token_bytes(size))
                    f.flush()
                    try:
                        os.fsync(f.fileno())
                    except Exception:
                        pass
    finally:
        try:
            path.unlink()
        except Exception:
            pass


# ============================================================
# Migration: pre-1.4.1 ~/.meshcode/credentials.json → keychain
# ============================================================

MIGRATION_FLAG = Path.home() / ".meshcode" / ".migrated_to_keychain"


def migrate_legacy_credentials() -> bool:
    """One-shot migration: move plain-text credentials.json to the OS keychain
    and shred the original file. Idempotent — safe to call on every CLI start.

    Returns True if a migration ran this call, False if nothing to do.
    """
    if MIGRATION_FLAG.exists():
        return False
    if not LEGACY_CREDS_FILE.exists():
        # Nothing to migrate, but still drop the flag so we don't re-check forever
        try:
            MIGRATION_FLAG.parent.mkdir(parents=True, exist_ok=True)
            MIGRATION_FLAG.write_text("no legacy file", encoding="utf-8")
        except Exception:
            pass
        return False

    try:
        data = json.loads(LEGACY_CREDS_FILE.read_text(encoding="utf-8"))
    except Exception:
        return False
    api_key = (data or {}).get("api_key") if isinstance(data, dict) else None
    if not api_key:
        return False

    meta = {k: v for k, v in data.items() if k != "api_key"} if isinstance(data, dict) else {}
    ok = set_api_key(api_key, profile=DEFAULT_PROFILE, meta=meta)
    if not ok:
        # Don't shred the legacy file if the migration failed — user would
        # be locked out. Leave it in place and try again next run.
        return False

    # Migration succeeded — shred the plain-text file
    _shred_file(LEGACY_CREDS_FILE)

    try:
        MIGRATION_FLAG.parent.mkdir(parents=True, exist_ok=True)
        MIGRATION_FLAG.write_text(json.dumps({
            "migrated_at_unix": int(__import__("time").time()),
            "backend": _KEYRING_BACKEND_NAME or "(unknown)",
        }), encoding="utf-8")
    except Exception:
        pass

    print("[meshcode] ✓ Migrated your api key from plain text to OS keychain.", file=sys.stderr)
    print(f"[meshcode]   Backend: {_KEYRING_BACKEND_NAME or '(file fallback)'}", file=sys.stderr)
    print("[meshcode]   The old ~/.meshcode/credentials.json has been shredded.", file=sys.stderr)
    return True
