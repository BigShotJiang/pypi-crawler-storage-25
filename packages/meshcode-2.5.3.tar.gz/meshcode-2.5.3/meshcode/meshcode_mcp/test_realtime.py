"""Tests for the Realtime listener — verifies WebSocket connect, subscribe,
INSERT event handling, and queue draining.
"""
import asyncio
import os
import time
import unittest

from . import backend as be
from .realtime import RealtimeListener, WEBSOCKETS_AVAILABLE

TEST_PROJECT = f"mcp-rt-test-{int(time.time())}"
TEST_AGENT = "rt-listener"
SENDER = "rt-sender"


@unittest.skipUnless(WEBSOCKETS_AVAILABLE, "websockets package not installed")
class RealtimeTests(unittest.TestCase):
    project_id = None

    @classmethod
    def setUpClass(cls):
        cls.project_id = be.get_project_id(TEST_PROJECT)
        be.register_agent(TEST_PROJECT, TEST_AGENT, "Realtime test target")
        be.register_agent(TEST_PROJECT, SENDER, "Realtime test sender")

    @classmethod
    def tearDownClass(cls):
        be._request("DELETE", f"mc_projects?id=eq.{cls.project_id}")

    def test_listener_connects_and_receives(self):
        """Connect listener, send message via REST, verify it lands in the queue."""
        async def run():
            received = []

            async def callback(msg):
                received.append(msg)

            listener = RealtimeListener(
                supabase_url=be.SUPABASE_URL,
                supabase_key=be.SUPABASE_KEY,
                project_id=self.project_id,
                agent_name=TEST_AGENT,
                notify_callback=callback,
            )
            await listener.start()

            # Wait for the WebSocket connection to be established
            for _ in range(20):
                if listener.is_connected:
                    break
                await asyncio.sleep(0.5)
            self.assertTrue(listener.is_connected, "Listener failed to connect")

            # Give Phoenix a moment to process the join + subscribe
            await asyncio.sleep(2)

            # Send a message via REST (simulates another agent)
            be.send_message(self.project_id, SENDER, TEST_AGENT, {"need": "rt-test"})

            # Wait up to 10s for the message to arrive via Realtime
            for _ in range(20):
                if listener.queue:
                    break
                await asyncio.sleep(0.5)

            await listener.stop()

            # Verify it landed in the queue
            self.assertGreater(len(listener.queue) + len(received), 0,
                               "Listener did not receive any messages")
            if listener.queue:
                msg = listener.queue[0]
                self.assertEqual(msg.get("from"), SENDER)
                self.assertEqual(msg.get("payload", {}).get("need"), "rt-test")

        asyncio.run(run())

    def test_drain_clears_queue(self):
        """drain() returns and clears the queue."""
        listener = RealtimeListener(
            supabase_url=be.SUPABASE_URL,
            supabase_key=be.SUPABASE_KEY,
            project_id=self.project_id,
            agent_name=TEST_AGENT,
        )
        listener.queue.append({"from": "x", "payload": {}})
        listener.queue.append({"from": "y", "payload": {}})
        drained = listener.drain()
        self.assertEqual(len(drained), 2)
        self.assertEqual(len(listener.queue), 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
