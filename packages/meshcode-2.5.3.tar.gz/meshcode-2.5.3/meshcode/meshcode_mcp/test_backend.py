"""Tests for meshcode_mcp backend helpers (stdlib only — no pytest)."""
import json
import os
import sys
import time
import unittest

# Use service role key for testing
os.environ.setdefault("SUPABASE_URL", "https://wwgzzmydrwrjgaebspdo.supabase.co")

# Test against an isolated project
TEST_PROJECT = f"mcp-test-{int(time.time())}"
TEST_AGENT_A = "test-agent-a"
TEST_AGENT_B = "test-agent-b"

from . import backend as be  # noqa: E402


class BackendTests(unittest.TestCase):
    project_id = None

    @classmethod
    def setUpClass(cls):
        cls.project_id = be.get_project_id(TEST_PROJECT)
        assert cls.project_id, "Failed to create test project"

    @classmethod
    def tearDownClass(cls):
        # Cleanup: delete the test project (cascades to agents + messages)
        from urllib.parse import quote
        be._request("DELETE", f"mc_projects?id=eq.{cls.project_id}")

    def test_01_register_agent_a(self):
        result = be.register_agent(TEST_PROJECT, TEST_AGENT_A, "Test agent A")
        self.assertTrue(result.get("registered"), f"Register failed: {result}")
        self.assertEqual(result.get("agent_name"), TEST_AGENT_A)

    def test_02_register_agent_b(self):
        result = be.register_agent(TEST_PROJECT, TEST_AGENT_B, "Test agent B")
        self.assertTrue(result.get("registered"))

    def test_03_send_message(self):
        result = be.send_message(
            self.project_id, TEST_AGENT_A, TEST_AGENT_B,
            {"need": "test message", "priority": "normal"},
        )
        self.assertTrue(result.get("sent"))
        self.assertIsNotNone(result.get("msg_id"))

    def test_04_count_pending(self):
        pending = be.count_pending(self.project_id, TEST_AGENT_B)
        self.assertGreaterEqual(pending, 1, "Expected at least 1 pending message")

    def test_05_read_inbox(self):
        messages = be.read_inbox(self.project_id, TEST_AGENT_B)
        self.assertGreaterEqual(len(messages), 1)
        msg = messages[0]
        self.assertEqual(msg["from_agent"], TEST_AGENT_A)
        self.assertEqual(msg["payload"]["need"], "test message")

    def test_06_inbox_empty_after_read(self):
        # After read, pending should be 0 (the auto-ACK goes back to A, not B)
        pending = be.count_pending(self.project_id, TEST_AGENT_B)
        self.assertEqual(pending, 0)

    def test_07_get_board(self):
        agents = be.get_board(self.project_id)
        names = [a["name"] for a in agents]
        self.assertIn(TEST_AGENT_A, names)
        self.assertIn(TEST_AGENT_B, names)

    def test_08_set_status(self):
        result = be.set_status(self.project_id, TEST_AGENT_A, "working", "running tests")
        self.assertTrue(result.get("ok"), f"set_status failed: {result}")

    def test_09_heartbeat(self):
        result = be.heartbeat(self.project_id, TEST_AGENT_A)
        self.assertEqual(result.get("status"), "alive")

    def test_10_get_history(self):
        history = be.get_history(self.project_id, limit=10)
        self.assertGreaterEqual(len(history), 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
