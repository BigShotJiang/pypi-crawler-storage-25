"""Static-analysis test: every name used inside with_working_status must exist.

This is the test that catches the _PROCESSING_COOLDOWN_S class of bugs —
references to variables that were never defined.  It parses server.py's AST
and checks that every Name node inside the wrapper functions resolves to a
local, global, or builtin in the module.

Run:  python -m pytest meshcode/meshcode_mcp/test_server_wrapper.py -v
  or: python -m unittest meshcode.meshcode_mcp.test_server_wrapper
"""
import ast
import builtins
import os
import unittest

_SERVER_PATH = os.path.join(os.path.dirname(__file__), "server.py")


def _get_module_globals(tree: ast.Module) -> set[str]:
    """Collect all names assigned/imported at module level."""
    names = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                names.add(alias.asname or alias.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom):
            for alias in node.names:
                names.add(alias.asname or alias.name)
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            names.add(node.name)
        elif isinstance(node, ast.ClassDef):
            names.add(node.name)
        elif isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name):
                    names.add(target.id)
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            names.add(node.target.id)
        elif isinstance(node, ast.AugAssign) and isinstance(node.target, ast.Name):
            names.add(node.target.id)
    # builtins
    names.update(dir(builtins))
    return names


def _collect_names_in_func(func_node: ast.AST) -> set[str]:
    """All Name.id references inside a function body."""
    refs = set()
    for node in ast.walk(func_node):
        if isinstance(node, ast.Name):
            refs.add(node.id)
    return refs


def _collect_locals(func_node: ast.AST) -> set[str]:
    """Names assigned, declared global, or used as parameters inside a function."""
    local = set()
    for node in ast.walk(func_node):
        if isinstance(node, ast.Global):
            local.update(node.names)
        elif isinstance(node, ast.Assign):
            for t in node.targets:
                if isinstance(t, ast.Name):
                    local.add(t.id)
        elif isinstance(node, ast.arg):
            local.add(node.arg)
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            local.add(node.name)
            for arg in node.args.args:
                local.add(arg.arg)
            if node.args.vararg:
                local.add(node.args.vararg.arg)
            if node.args.kwarg:
                local.add(node.args.kwarg.arg)
    return local


class ServerWrapperNamesTest(unittest.TestCase):
    """Verify no undefined names inside with_working_status."""

    def test_no_undefined_names_in_wrapper(self):
        with open(_SERVER_PATH) as f:
            tree = ast.parse(f.read(), _SERVER_PATH)

        module_globals = _get_module_globals(tree)

        # Find the with_working_status function
        wrapper_func = None
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef) and node.name == "with_working_status":
                wrapper_func = node
                break

        self.assertIsNotNone(wrapper_func, "with_working_status not found in server.py")

        # Check every nested function inside with_working_status
        for node in ast.walk(wrapper_func):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                if node.name == "with_working_status":
                    continue  # skip the outer function itself
                refs = _collect_names_in_func(node)
                locals_ = _collect_locals(node)
                # Add the outer function's params and locals too
                outer_locals = _collect_locals(wrapper_func)
                allowed = module_globals | locals_ | outer_locals

                undefined = refs - allowed
                self.assertEqual(
                    undefined,
                    set(),
                    f"Undefined names in {node.name}() inside with_working_status: "
                    f"{undefined}. These will cause NameError at runtime.",
                )


if __name__ == "__main__":
    unittest.main()
