"""MeshCode MCP server — exposes meshcode tools to MCP clients (Claude Code, etc)."""
__version__ = "1.0.0"
