"""Mesh Protocol v2 — compressed wire format helpers.

See docs/MESH_PROTOCOL_V2.md for the full spec.
"""
from typing import Any, Dict

# Top-level v1 → v2 keys
TOP_V1_TO_V2 = {
    "from_agent": "f",
    "type": "t",
    "payload": "p",
    "read": "r",
}

TOP_V2_TO_V1 = {v: k for k, v in TOP_V1_TO_V2.items()}

# Action codes (v1 type → v2 t)
TYPE_V1_TO_V2 = {
    "msg": "M",
    "ack": "A",
    "broadcast": "B",
    "query": "Q",
    "reply": "R",
    "fyi": "F",
    "kill": "K",
    "sleep": "S",
    "wake": "W",
    "warning": "W!",
}

TYPE_V2_TO_V1 = {v: k for k, v in TYPE_V1_TO_V2.items()}

# Inner payload v1 → v2 keys
PAYLOAD_V1_TO_V2 = {
    "need": "n",
    "done": "d",
    "fyi": "m",
    "result": "r",
    "files": "fl",
    "priority": "pr",
    "blocked": "b",
    "need_from": "nf",
    "task_id": "ti",
    "ref": "rf",
    "text": "tx",
}

PAYLOAD_V2_TO_V1 = {v: k for k, v in PAYLOAD_V1_TO_V2.items()}

# Priority shortening
PRIORITY_V1_TO_V2 = {"high": "H", "normal": "N", "low": "L", "urgent": "U"}
PRIORITY_V2_TO_V1 = {v: k for k, v in PRIORITY_V1_TO_V2.items()}


def is_v2(payload: Any) -> bool:
    """Heuristic check: does this dict use v2 short keys?"""
    if not isinstance(payload, dict):
        return False
    short_keys = {"n", "d", "m", "r", "fl", "pr", "b", "nf", "ti", "rf", "tx"}
    return any(k in payload for k in short_keys) and not any(
        k in payload for k in PAYLOAD_V1_TO_V2.keys()
    )


def payload_to_v2(payload: Dict) -> Dict:
    """Compress an inner payload from v1 keys to v2 short keys.

    Drops null/empty values, shortens priority enums.
    """
    if not isinstance(payload, dict):
        return payload
    out: Dict[str, Any] = {}
    for k, v in payload.items():
        if v is None or v == "" or v == [] or v == {}:
            continue
        new_k = PAYLOAD_V1_TO_V2.get(k, k)
        if new_k == "pr" and isinstance(v, str):
            out[new_k] = PRIORITY_V1_TO_V2.get(v.lower(), v)
        else:
            out[new_k] = v
    return out


def payload_from_v2(payload: Dict) -> Dict:
    """Expand a v2 payload back to v1 long keys."""
    if not isinstance(payload, dict):
        return payload
    out: Dict[str, Any] = {}
    for k, v in payload.items():
        new_k = PAYLOAD_V2_TO_V1.get(k, k)
        if new_k == "priority" and isinstance(v, str):
            out[new_k] = PRIORITY_V2_TO_V1.get(v, v)
        else:
            out[new_k] = v
    return out


def message_to_v2(msg: Dict) -> Dict:
    """Compress a full message {from, to, type, payload, ...} to v2."""
    out: Dict[str, Any] = {}
    if "from_agent" in msg:
        out["f"] = msg["from_agent"]
    if "to_agent" in msg:
        out["to"] = msg["to_agent"]
    if "type" in msg:
        out["t"] = TYPE_V1_TO_V2.get(msg["type"], msg["type"])
    if "payload" in msg:
        out["p"] = payload_to_v2(msg["payload"])
    for k in ("id", "ref", "ts", "created_at"):
        if k in msg and msg[k]:
            out[k] = msg[k]
    return out


def message_from_v2(msg: Dict) -> Dict:
    """Expand a v2 message back to v1 form."""
    out: Dict[str, Any] = {}
    if "f" in msg:
        out["from_agent"] = msg["f"]
    if "to" in msg:
        out["to_agent"] = msg["to"]
    if "t" in msg:
        out["type"] = TYPE_V2_TO_V1.get(msg["t"], msg["t"])
    if "p" in msg:
        out["payload"] = payload_from_v2(msg["p"])
    for k in ("id", "ref", "ts", "created_at"):
        if k in msg and msg[k]:
            out[k] = msg[k]
    return out
