#!/usr/bin/env python3
"""
Cross-platform install/uninstall for the meshcode launcher daemon.

macOS   -> launchd (~/Library/LaunchAgents/io.meshcode.launcher.plist)
Linux   -> systemd --user (~/.config/systemd/user/meshcode-launcher.service)
Windows -> Task Scheduler (MeshcodeLauncher task, logon trigger)
"""
from __future__ import annotations

import json
import os
import platform
import subprocess
import sys
import time
from pathlib import Path

HOME = Path.home()
STATE_DIR = HOME / ".meshcode"
STATE_DIR.mkdir(parents=True, exist_ok=True)
LOG_FILE = STATE_DIR / "launcher.log"
ERR_FILE = STATE_DIR / "launcher.err"
PID_FILE = STATE_DIR / "launcher.pid"

LABEL_MAC = "io.meshcode.launcher"
PLIST_PATH = HOME / "Library" / "LaunchAgents" / f"{LABEL_MAC}.plist"

SYSTEMD_UNIT = HOME / ".config" / "systemd" / "user" / "meshcode-launcher.service"

WIN_TASK_NAME = "MeshcodeLauncher"
WIN_XML_PATH = STATE_DIR / "MeshcodeLauncher.xml"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _py() -> str:
    return sys.executable or "python3"


def _detect_os() -> str:
    s = platform.system().lower()
    if s == "darwin":
        return "mac"
    if s == "linux":
        return "linux"
    if s == "windows":
        return "windows"
    return s


def _run(cmd: list[str], check: bool = False) -> tuple[int, str, str]:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if check and r.returncode != 0:
            print(f"[launcher] {' '.join(cmd)}\n{r.stderr}", file=sys.stderr)
        return r.returncode, r.stdout, r.stderr
    except Exception as e:
        return 1, "", str(e)


# ---------------------------------------------------------------------------
# macOS — launchd
# ---------------------------------------------------------------------------
def _repo_root() -> Path:
    return Path(__file__).resolve().parent.parent


def _plist_xml() -> str:
    py = _py()
    repo = _repo_root()
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>{LABEL_MAC}</string>
  <key>ProgramArguments</key>
  <array>
    <string>{py}</string>
    <string>-m</string>
    <string>meshcode.launcher</string>
    <string>run</string>
  </array>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>ThrottleInterval</key><integer>5</integer>
  <key>StandardOutPath</key><string>{LOG_FILE}</string>
  <key>StandardErrorPath</key><string>{ERR_FILE}</string>
  <key>WorkingDirectory</key><string>{repo}</string>
  <key>EnvironmentVariables</key>
  <dict>
    <key>PATH</key><string>/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin</string>
    <key>HOME</key><string>{HOME}</string>
    <key>PYTHONPATH</key><string>{repo}</string>
    <key>PYTHONUNBUFFERED</key><string>1</string>
    <key>PYTHONIOENCODING</key><string>utf-8</string>
    <key>LANG</key><string>en_US.UTF-8</string>
    <key>LC_ALL</key><string>en_US.UTF-8</string>
  </dict>
</dict>
</plist>
"""


def mac_install() -> int:
    PLIST_PATH.parent.mkdir(parents=True, exist_ok=True)
    PLIST_PATH.write_text(_plist_xml())
    print(f"[launcher] wrote {PLIST_PATH}")
    # Unload first if already loaded (ignore errors)
    _run(["launchctl", "unload", str(PLIST_PATH)])
    rc, _, err = _run(["launchctl", "load", "-w", str(PLIST_PATH)], check=True)
    if rc != 0:
        print(f"[launcher] launchctl load failed: {err}", file=sys.stderr)
        return rc
    print("[launcher] launchd job loaded")
    time.sleep(1.5)
    mac_status()
    return 0


def mac_uninstall() -> int:
    if PLIST_PATH.exists():
        _run(["launchctl", "unload", str(PLIST_PATH)])
        PLIST_PATH.unlink()
        print(f"[launcher] removed {PLIST_PATH}")
    else:
        print("[launcher] plist not present")
    return 0


def mac_start() -> int:
    rc, _, _ = _run(["launchctl", "start", LABEL_MAC])
    return rc


def mac_stop() -> int:
    rc, _, _ = _run(["launchctl", "stop", LABEL_MAC])
    return rc


def mac_status() -> int:
    rc, out, _ = _run(["launchctl", "list", LABEL_MAC])
    if rc == 0:
        print(out.strip() or "(loaded, no details)")
    else:
        print("[launcher] not loaded")
    _print_pidfile()
    return rc


# ---------------------------------------------------------------------------
# Linux — systemd --user
# ---------------------------------------------------------------------------
def _systemd_unit() -> str:
    py = _py()
    repo = _repo_root()
    return f"""[Unit]
Description=MeshCode realtime launcher daemon
After=network-online.target

[Service]
Type=simple
Environment=PYTHONPATH={repo}
WorkingDirectory={repo}
ExecStart={py} -m meshcode.launcher run
Restart=on-failure
RestartSec=5
StandardOutput=append:{LOG_FILE}
StandardError=append:{ERR_FILE}

[Install]
WantedBy=default.target
"""


def linux_install() -> int:
    SYSTEMD_UNIT.parent.mkdir(parents=True, exist_ok=True)
    SYSTEMD_UNIT.write_text(_systemd_unit())
    print(f"[launcher] wrote {SYSTEMD_UNIT}")
    _run(["systemctl", "--user", "daemon-reload"])
    rc, _, err = _run(["systemctl", "--user", "enable", "--now", "meshcode-launcher.service"])
    if rc != 0:
        print(f"[launcher] systemctl enable failed: {err}", file=sys.stderr)
        return rc
    print("[launcher] systemd unit enabled + started")
    return 0


def linux_uninstall() -> int:
    _run(["systemctl", "--user", "disable", "--now", "meshcode-launcher.service"])
    if SYSTEMD_UNIT.exists():
        SYSTEMD_UNIT.unlink()
        print(f"[launcher] removed {SYSTEMD_UNIT}")
    _run(["systemctl", "--user", "daemon-reload"])
    return 0


def linux_start() -> int:
    return _run(["systemctl", "--user", "start", "meshcode-launcher.service"])[0]


def linux_stop() -> int:
    return _run(["systemctl", "--user", "stop", "meshcode-launcher.service"])[0]


def linux_status() -> int:
    rc, out, _ = _run(["systemctl", "--user", "status", "meshcode-launcher.service"])
    print(out)
    _print_pidfile()
    return rc


# ---------------------------------------------------------------------------
# Windows — Task Scheduler
# ---------------------------------------------------------------------------
def _windows_xml() -> str:
    pyw = _py()
    if pyw.lower().endswith("python.exe"):
        pyw = pyw[:-10] + "pythonw.exe"
    user = os.environ.get("USERNAME", "")
    return f"""<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.4" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo>
    <Description>MeshCode realtime launcher daemon</Description>
  </RegistrationInfo>
  <Triggers>
    <LogonTrigger>
      <Enabled>true</Enabled>
    </LogonTrigger>
  </Triggers>
  <Principals>
    <Principal id="Author">
      <UserId>{user}</UserId>
      <LogonType>InteractiveToken</LogonType>
    </Principal>
  </Principals>
  <Settings>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <AllowHardTerminate>true</AllowHardTerminate>
    <StartWhenAvailable>true</StartWhenAvailable>
    <RestartOnFailure>
      <Interval>PT1M</Interval>
      <Count>999</Count>
    </RestartOnFailure>
  </Settings>
  <Actions Context="Author">
    <Exec>
      <Command>{pyw}</Command>
      <Arguments>-m meshcode.launcher run</Arguments>
    </Exec>
  </Actions>
</Task>
"""


def windows_install() -> int:
    WIN_XML_PATH.write_text(_windows_xml(), encoding="utf-16")
    print(f"[launcher] wrote {WIN_XML_PATH}")
    rc, _, err = _run([
        "schtasks.exe", "/Create", "/TN", WIN_TASK_NAME,
        "/XML", str(WIN_XML_PATH), "/F",
    ])
    if rc != 0:
        print(f"[launcher] schtasks create failed: {err}", file=sys.stderr)
        return rc
    _run(["schtasks.exe", "/Run", "/TN", WIN_TASK_NAME])
    print("[launcher] task scheduled + started")
    return 0


def windows_uninstall() -> int:
    _run(["schtasks.exe", "/End", "/TN", WIN_TASK_NAME])
    rc, _, _ = _run(["schtasks.exe", "/Delete", "/TN", WIN_TASK_NAME, "/F"])
    if WIN_XML_PATH.exists():
        WIN_XML_PATH.unlink()
    return rc


def windows_start() -> int:
    return _run(["schtasks.exe", "/Run", "/TN", WIN_TASK_NAME])[0]


def windows_stop() -> int:
    return _run(["schtasks.exe", "/End", "/TN", WIN_TASK_NAME])[0]


def windows_status() -> int:
    rc, out, _ = _run(["schtasks.exe", "/Query", "/TN", WIN_TASK_NAME, "/V", "/FO", "LIST"])
    print(out or "[launcher] task not found")
    _print_pidfile()
    return rc


# ---------------------------------------------------------------------------
# Shared utils
# ---------------------------------------------------------------------------
def _print_pidfile() -> None:
    if not PID_FILE.exists():
        print("[launcher] no pid file yet (daemon may still be starting)")
        return
    try:
        data = json.loads(PID_FILE.read_text())
        pid = data.get("pid")
        started = data.get("started_at") or 0
        last = data.get("last_event_at")
        uptime = int(time.time() - started) if started else 0
        print(f"[launcher] pid={pid} uptime={uptime}s "
              f"last_event={'never' if not last else f'{int(time.time()-last)}s ago'}")
    except Exception as e:
        print(f"[launcher] pid-file unreadable: {e}")


def tail_logs(follow: bool = False) -> int:
    if not LOG_FILE.exists():
        print(f"[launcher] no log file at {LOG_FILE}")
        return 0
    if not follow:
        try:
            lines = LOG_FILE.read_text().splitlines()[-80:]
            print("\n".join(lines))
        except Exception as e:
            print(f"[launcher] read log failed: {e}")
            return 1
        return 0
    rc, _, _ = _run(["tail", "-n", "40", "-f", str(LOG_FILE)])
    return rc


def send_test_message() -> int:
    """Smoke-test: send a mesh message and watch launcher log for wake."""
    try:
        os_type = _detect_os()
        if os_type == "mac":
            mac_status()
        elif os_type == "linux":
            linux_status()
        # Snapshot log size, send a test message via comms_v4, wait, diff.
        before = LOG_FILE.stat().st_size if LOG_FILE.exists() else 0
        py = _py()
        repo_root = Path(__file__).resolve().parent.parent
        comms_path = repo_root / "comms_v4.py"
        if not comms_path.exists():
            comms_path = Path(__file__).resolve().parent / "comms_v4.py"
        print(f"[launcher] sending test message via {comms_path}")
        _run([py, str(comms_path), "send", "launcher-test",
              "test-harness:launcher-probe", "hello from launcher test"])
        time.sleep(4)
        after = LOG_FILE.stat().st_size if LOG_FILE.exists() else 0
        if after > before:
            tail = LOG_FILE.read_text()[before:]
            print("[launcher] NEW LOG LINES:")
            print(tail)
            return 0
        print("[launcher] no new log lines — daemon may not have received the event")
        return 1
    except Exception as e:
        print(f"[launcher] test failed: {e}")
        return 1


# ---------------------------------------------------------------------------
# Dispatcher
# ---------------------------------------------------------------------------
def dispatch(action: str) -> int:
    os_type = _detect_os()
    table = {
        "mac": {
            "install": mac_install, "uninstall": mac_uninstall,
            "start": mac_start, "stop": mac_stop,
            "restart": lambda: (mac_stop(), mac_start())[1],
            "status": mac_status,
        },
        "linux": {
            "install": linux_install, "uninstall": linux_uninstall,
            "start": linux_start, "stop": linux_stop,
            "restart": lambda: (linux_stop(), linux_start())[1],
            "status": linux_status,
        },
        "windows": {
            "install": windows_install, "uninstall": windows_uninstall,
            "start": windows_start, "stop": windows_stop,
            "restart": lambda: (windows_stop(), windows_start())[1],
            "status": windows_status,
        },
    }
    if os_type not in table:
        print(f"[launcher] unsupported OS: {os_type}", file=sys.stderr)
        return 2
    fns = table[os_type]
    if action not in fns:
        print(f"[launcher] unknown action: {action}", file=sys.stderr)
        return 2
    return int(fns[action]() or 0)


def main(argv: list[str] | None = None) -> int:
    argv = list(argv if argv is not None else sys.argv[1:])
    if not argv:
        print("usage: meshcode launcher {install|uninstall|start|stop|restart|status|logs|test}")
        return 2
    action = argv[0]
    if action == "logs":
        return tail_logs(follow=("-f" in argv[1:]))
    if action == "test":
        return send_test_message()
    return dispatch(action)


if __name__ == "__main__":
    sys.exit(main())
