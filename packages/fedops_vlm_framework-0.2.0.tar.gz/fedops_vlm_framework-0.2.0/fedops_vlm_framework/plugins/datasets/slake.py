"""SLAKE dataset plugin — mdwiratathya/SLAKE-vqa-english.

SLAKE (Structured Language and Knowledge Enhanced) is a medical VQA dataset
covering multiple organs and imaging modalities (X-ray, MRI, CT).
We use the English-only HuggingFace version with embedded PIL images.

HuggingFace: mdwiratathya/SLAKE-vqa-english
Columns: image (JpegImageFile), question (str), answer (str)
Splits: train (4919), validation (1053), test (1061)
"""

from collections.abc import Callable
from typing import Any

from datasets import Dataset, load_dataset

from fedops_vlm_framework.core.dataset import get_vlm_collate_fn


class SLAKEDatasetPlugin:
    """SLAKE medical VQA dataset plugin (English, embedded images).

    Covers brain/chest/abdomen across X-ray, CT, and MRI. Answers include
    both closed-set (yes/no) and open-ended forms (~4.9K train, ~1K test).

    HuggingFace: mdwiratathya/SLAKE-vqa-english
    Columns: image, question, answer

    To use: set dataset.plugin = "slake" in pyproject.toml.
    """

    name = "slake"
    hf_dataset = "mdwiratathya/SLAKE-vqa-english"

    def describe(self) -> str:
        return (
            "SLAKE — medical VQA (English, ~4.9K train / 1K test). "
            "Covers brain/chest/abdomen across X-ray, CT, MRI modalities."
        )

    def load_partition(
        self,
        partition_id: int,
        num_partitions: int,
        split: str = "train",
    ) -> Dataset:
        """Load one shard of SLAKE.

        Returns Dataset with columns: image, question, answer.
        """
        actual_split = {"train": "train", "test": "test", "validation": "validation"}.get(split, "train")
        ds = load_dataset(self.hf_dataset, split=actual_split, trust_remote_code=True)
        return ds.shard(num_shards=num_partitions, index=partition_id, contiguous=True)

    def get_collate_fn(self, processor: Any, max_length: int) -> Callable:
        return get_vlm_collate_fn(processor, max_length)
