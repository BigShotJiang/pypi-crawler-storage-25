"""VQAv2 dataset plugin — lmms-lab/VQAv2.

  train split → "validation"  (~39K samples, ground-truth answers available)
  test  split → "testdev"     (held-out, never seen during training)
"""

from collections.abc import Callable
from typing import Any

from datasets import Dataset, load_dataset

from fedops_vlm_framework.core.dataset import get_vlm_collate_fn


class VQAv2DatasetPlugin:
    """General-purpose VQA dataset plugin.

    HuggingFace: lmms-lab/VQAv2
      train → "validation" split (~39K samples)
      test  → "testdev" split    (held-out, untouched during FL)

    Columns: image, question, answer
    """

    name = "vqav2"
    hf_dataset = "lmms-lab/VQAv2"
    _SPLIT_MAP = {"train": "validation", "test": "testdev", "validation": "validation"}

    def describe(self) -> str:
        return "VQAv2 — ~39K train (validation split), testdev held-out for post-FL eval."

    def load_partition(
        self,
        partition_id: int,
        num_partitions: int,
        split: str = "train",
    ) -> Dataset:
        actual_split = self._SPLIT_MAP.get(split, split)
        ds = load_dataset(self.hf_dataset, split=actual_split)
        ds = self._normalize(ds)
        return ds.shard(num_shards=num_partitions, index=partition_id, contiguous=True)

    @staticmethod
    def _normalize(ds: Dataset) -> Dataset:
        def _fix(sample):
            answer = sample.get("multiple_choice_answer") or ""
            if not answer:
                answers = sample.get("answers", [])
                answer = answers[0]["answer"] if answers else ""
            return {"answer": str(answer).strip()}
        ds = ds.map(_fix)
        keep = {"image", "question", "answer"}
        return ds.remove_columns([c for c in ds.column_names if c not in keep])

    def get_collate_fn(self, processor: Any, max_length: int) -> Callable:
        return get_vlm_collate_fn(processor, max_length)

