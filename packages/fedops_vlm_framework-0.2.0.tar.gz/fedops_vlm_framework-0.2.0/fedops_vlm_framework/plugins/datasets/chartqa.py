"""ChartQA dataset plugin — HuggingFaceM4/ChartQA.

Chart understanding is a natural FL use case: financial institutions, research labs,
and news organizations all produce charts but cannot share proprietary data centrally.

ChartQA contains ~20K chart images with short human/augmented Q&A pairs.
Answers are short (numbers, "yes/no", brief phrases) — ideal for exact-match eval.

HuggingFace: HuggingFaceM4/ChartQA
Columns: image, query (→question), label (list→answer)
Splits: train (~18K), val (~1.25K), test (~2.5K)
"""

from collections.abc import Callable
from typing import Any

from datasets import Dataset, load_dataset

from fedops_vlm_framework.core.dataset import get_vlm_collate_fn


class ChartQADatasetPlugin:
    """Chart understanding VQA dataset plugin.

    ChartQA covers bar, line, pie charts from financial reports, scientific papers,
    and news. Answers are short numerical or categorical values — exact-match friendly.

    HuggingFace: HuggingFaceM4/ChartQA
    Columns after normalization: image, question, answer

    To use: set dataset.plugin = "chartqa" in pyproject.toml.
    """

    name = "chartqa"
    hf_dataset = "HuggingFaceM4/ChartQA"

    def describe(self) -> str:
        return (
            "ChartQA — ~20K chart images (bar/line/pie) with short Q&A. "
            "Finance/science charts; answers are numbers or brief phrases."
        )

    def load_partition(
        self,
        partition_id: int,
        num_partitions: int,
        split: str = "train",
    ) -> Dataset:
        """Load one IID shard of ChartQA.

        Returns Dataset with columns: image, question, answer.
        ChartQA uses 'query' and 'label' (list) which are normalized here.
        """
        ds = load_dataset(self.hf_dataset, split=split)
        ds = self._normalize(ds)
        return ds.shard(num_shards=num_partitions, index=partition_id, contiguous=True)

    @staticmethod
    def _normalize(ds: Dataset) -> Dataset:
        def _fix(sample):
            label = sample.get("label", "")
            if isinstance(label, list):
                label = label[0] if label else ""
            return {"answer": str(label).strip()}

        ds = ds.rename_column("query", "question")
        ds = ds.map(_fix)
        keep = {"image", "question", "answer"}
        ds = ds.remove_columns([c for c in ds.column_names if c not in keep])
        return ds

    def get_collate_fn(self, processor: Any, max_length: int) -> Callable:
        return get_vlm_collate_fn(processor, max_length)
