"""PathVQA dataset plugin — flaviagiammarino/path-vqa.

Pathology-focused VQA: microscopy and histology images with yes/no and
open-ended clinical questions. Covers gross pathology, cytology, and
histopathology — a distinct imaging modality from radiology (VQA-RAD).

HuggingFace: flaviagiammarino/path-vqa
Columns: image, question, answer
Splits: train (~19.7K), test (~6.7K)
"""

from collections.abc import Callable
from typing import Any

from datasets import Dataset, load_dataset

from fedops_vlm_framework.core.dataset import ensure_standard_columns, get_vlm_collate_fn, load_partition


class PathVQADatasetPlugin:
    """Pathology-focused VQA dataset plugin.

    PathVQA contains histology and microscopy images paired with clinical
    questions. ~76% yes/no questions, ~24% open-ended. Distinct visual
    domain from radiology — useful for cross-domain non-IID FL experiments.

    HuggingFace: flaviagiammarino/path-vqa
    Columns after normalization: image, question, answer

    To use: set dataset.plugin = "path_vqa" in pyproject.toml.
    """

    name = "path_vqa"
    hf_dataset = "flaviagiammarino/path-vqa"

    def describe(self) -> str:
        return (
            "PathVQA — ~19.7K pathology/histology images with yes-no and "
            "open-ended clinical questions. Microscopy and gross pathology."
        )

    def load_partition(
        self,
        partition_id: int,
        num_partitions: int,
        split: str = "train",
    ) -> Dataset:
        """Load one IID partition of PathVQA.

        Returns Dataset with columns: image, question, answer.
        """
        if split != "train":
            # FederatedDataset only supports train — load test/val directly
            ds = load_dataset(self.hf_dataset, split=split, trust_remote_code=True)
            ds = ensure_standard_columns(ds)
            return ds.shard(num_shards=num_partitions, index=partition_id, contiguous=True)
        return load_partition(
            partition_id=partition_id,
            num_partitions=num_partitions,
            dataset_name=self.hf_dataset,
            split=split,
        )

    def get_collate_fn(self, processor: Any, max_length: int) -> Callable:
        return get_vlm_collate_fn(processor, max_length)
