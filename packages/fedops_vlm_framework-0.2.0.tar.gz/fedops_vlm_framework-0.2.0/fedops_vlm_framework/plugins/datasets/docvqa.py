"""DocVQA dataset plugin — ds4sd/DocVQA.

Document understanding is a natural FL use case: law firms, hospitals, and
government bodies all process sensitive documents but cannot share them centrally.

DocVQA contains ~50K document images (contracts, forms, letters, reports) with
span-extraction Q&A. Answers are short text spans — exact-match friendly.

HuggingFace: ds4sd/DocVQA
Columns: image, question, answers (list→answer)
Splits: train (~39K), validation (~5.3K), test (~5.2K — labels withheld on benchmark)
"""

from collections.abc import Callable
from typing import Any

from datasets import Dataset, load_dataset

from fedops_vlm_framework.core.dataset import get_vlm_collate_fn


class DocVQADatasetPlugin:
    """Document VQA dataset plugin.

    DocVQA covers business letters, contracts, forms, invoices, and reports.
    Answers are short extracted text spans — ideal for English document understanding.

    HuggingFace: ds4sd/DocVQA
    Columns after normalization: image, question, answer

    To use: set dataset.plugin = "docvqa" in pyproject.toml.
    """

    name = "docvqa"
    hf_dataset = "lmms-lab/DocVQA"

    def describe(self) -> str:
        return (
            "DocVQA — ~50K document images (contracts, forms, letters) with span Q&A. "
            "Legal/business FL use case; English, exact-match friendly."
        )

    def load_partition(
        self,
        partition_id: int,
        num_partitions: int,
        split: str = "train",
    ) -> Dataset:
        """Load one IID shard of DocVQA.

        Returns Dataset with columns: image, question, answer.
        DocVQA 'answers' is a list; first element is taken as the canonical answer.
        """
        actual_split = "validation" if split == "train" else split
        ds = load_dataset(self.hf_dataset, "DocVQA", split=actual_split)
        ds = self._normalize(ds)
        return ds.shard(num_shards=num_partitions, index=partition_id, contiguous=True)

    @staticmethod
    def _normalize(ds: Dataset) -> Dataset:
        def _fix(sample):
            answers = sample.get("answers", sample.get("answer", ""))
            if isinstance(answers, list):
                answers = answers[0] if answers else ""
            return {"answer": str(answers).strip()}

        ds = ds.map(_fix)
        keep = {"image", "question", "answer"}
        ds = ds.remove_columns([c for c in ds.column_names if c not in keep])
        return ds

    def get_collate_fn(self, processor: Any, max_length: int) -> Callable:
        return get_vlm_collate_fn(processor, max_length)
