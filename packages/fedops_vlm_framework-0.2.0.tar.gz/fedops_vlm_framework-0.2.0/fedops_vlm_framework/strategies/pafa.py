"""PAFAStrategy — Pair-Aware Federated Aggregation.

Published as part of fedops-vlm-framework. In conf/config.yaml set:

    server:
      strategy:
        _target_: fedops_vlm_framework.strategies.PAFAStrategy
        pafa_lora_floor: 0.0

Or use the standalone PAFA.py (included in FedopsTune zip downloads):

    server:
      strategy:
        _target_: PAFA.PAFAStrategy
        pafa_lora_floor: 0.0

Both are identical in behaviour.

--- Component-aware mode (recommended) ---
Run  python generate_paramshape.py  once before training.
This creates parameter_names.json next to server_main.py.
When found, PAFA solves two separate QPs each round:

    min_w   w^T D^c w
    s.t.    sum(w) = 1
            w_i >= floor_c * p_i

where D^c[i,j] = 1 - cos(delta_i^c, delta_j^c) is the pairwise
gradient dissimilarity for component c and p_i = N_i/N are data weights.

Per-round gradient statistics prove the PAFA convergence theorem:
    lambda_lora : mean pairwise cosine dissimilarity for LoRA updates
    lambda_proj : mean pairwise cosine dissimilarity for projector updates
    lambda_flat : what flat (non-component-aware) aggregation sees
    cgh         : |lambda_lora - lambda_proj|  (Component Gradient
                  Heterogeneity). CGH > 0 means flat aggregation incurs
                  avoidable convergence overhead — PAFA exploits this.

Stats are written to gradient_stats.json in save_dir (default: same
directory as parameter_names.json, or cwd if none found).

--- Flat mode (fallback) ---
Without parameter_names.json, a single flat QP over all parameters.

Both modes fall back to data-proportional FedAvg if scipy is missing
or the QP solver fails to converge.
"""

import json
import logging
import os
from typing import Dict, List, Optional, Tuple, Union

import numpy as np
from flwr.common import (
    FitRes,
    Parameters,
    Scalar,
    ndarrays_to_parameters,
    parameters_to_ndarrays,
)
from flwr.server.client_proxy import ClientProxy
from flwr.server.strategy import FedAvg

logger = logging.getLogger(__name__)


# ── helpers ───────────────────────────────────────────────────────────────────

def _flatten(arrays: List[np.ndarray]) -> np.ndarray:
    """Flatten a list of numpy arrays into a single float32 vector."""
    return np.concatenate([a.ravel().astype(np.float32) for a in arrays])


def _build_dissimilarity_matrix(vecs: List[np.ndarray]) -> np.ndarray:
    """Build n×n cosine dissimilarity matrix D[i,j] = 1 - cos(v_i, v_j)."""
    n = len(vecs)
    D = np.zeros((n, n), dtype=np.float64)
    norms = np.array([np.linalg.norm(v) for v in vecs], dtype=np.float64)
    for i in range(n):
        for j in range(i + 1, n):
            if norms[i] > 1e-10 and norms[j] > 1e-10:
                cos_ij = float(
                    np.dot(vecs[i].astype(np.float64), vecs[j].astype(np.float64))
                    / (norms[i] * norms[j])
                )
                cos_ij = float(np.clip(cos_ij, -1.0, 1.0))
                D[i, j] = D[j, i] = 1.0 - cos_ij
            else:
                D[i, j] = D[j, i] = 1.0
    return D


def _mean_lambda(D: np.ndarray) -> float:
    """Mean off-diagonal = expected pairwise gradient dissimilarity (λ_c).

    Appears in the PAFA convergence bound:
        O(1/T + λ_c · σ²_c)
    When λ_lora ≠ λ_proj, flat aggregation mixes two different variance
    sources and incurs a strictly looser bound — PAFA avoids this.
    """
    n = D.shape[0]
    if n <= 1:
        return 0.0
    mask = ~np.eye(n, dtype=bool)
    return float(D[mask].mean())


def _solve_qp_weights(
    vecs: List[np.ndarray],
    data_weights: np.ndarray,
    floor: float,
    label: str = "",
    D: Optional[np.ndarray] = None,
) -> np.ndarray:
    """Solve  min_w w^T D w  s.t. sum(w)=1, w_i >= floor*p_i  via SLSQP.

    Pass a pre-computed D to avoid recomputing it when also tracking λ.
    Falls back to data-proportional (FedAvg) weights on any failure.
    """
    try:
        from scipy.optimize import minimize
    except ImportError:
        logger.warning("[PAFA%s] scipy not installed — using data-proportional weights", label)
        return data_weights / data_weights.sum()

    n = len(vecs)
    if D is None:
        D = _build_dissimilarity_matrix(vecs)

    if D.max() < 1e-8:
        return data_weights / data_weights.sum()

    D_reg = D + 1e-8 * np.eye(n)

    def obj(w):
        return float(w @ D_reg @ w)

    def jac(w):
        return 2.0 * (D_reg @ w)

    p = data_weights / data_weights.sum()
    lb = floor * p
    bounds = [(float(max(0.0, lb[i])), 1.0) for i in range(n)]
    constraints = [{"type": "eq", "fun": lambda w: w.sum() - 1.0}]

    w0 = 0.7 * p + 0.3 * np.ones(n) / n
    w0 = np.maximum(w0, lb)
    w0 /= w0.sum()

    result = minimize(obj, w0, jac=jac, method="SLSQP",
                      bounds=bounds, constraints=constraints,
                      options={"ftol": 1e-10, "maxiter": 500})

    if result.success or result.status == 0:
        w = np.clip(result.x, 0.0, 1.0)
        s = w.sum()
        if s > 1e-12:
            return w / s

    logger.warning("[PAFA%s] QP did not converge (%s) — using data-proportional weights",
                   label, result.message)
    return data_weights / data_weights.sum()


def _resolve_paths(save_dir: Optional[str]) -> tuple[Optional[str], Optional[str]]:
    """Find parameter_names.json and resolve gradient_stats.json path.

    Search order:
      1. save_dir (if provided)
      2. Directory of the __main__ script (server_main.py when running FedOps)
      3. Current working directory
    Returns (names_file_path, stats_file_path) or (None, None) if not found.
    """
    candidates: list[str] = []
    if save_dir:
        candidates.append(os.path.abspath(save_dir))
    try:
        import __main__
        if hasattr(__main__, "__file__") and __main__.__file__:
            candidates.append(os.path.dirname(os.path.abspath(__main__.__file__)))
    except Exception:
        pass
    candidates.append(os.getcwd())

    for d in candidates:
        names_path = os.path.join(d, "parameter_names.json")
        if os.path.exists(names_path):
            return names_path, os.path.join(d, "gradient_stats.json")
    return None, None


# ── strategy ──────────────────────────────────────────────────────────────────

class PAFAStrategy(FedAvg):
    """Pair-Aware Federated Aggregation — component-aware QP aggregation.

    Drop-in replacement for FedAvg. Solves separate quadratic programs for
    LoRA and projector parameter updates each round, exploiting the fact that
    these two VLM components have structurally different gradient variance
    under cross-domain heterogeneity (Component Gradient Heterogeneity, CGH).

    Args:
        pafa_lora_floor: Minimum weight floor as a fraction of each client's
            data-proportional weight, applied to the LoRA QP. Projector floor
            is always 1/n_clients (dynamic, requires no hand-tuning).
            Values in [0, 1]. Default: 0.0 (no floor).
        save_dir: Directory to write gradient_stats.json. If None, searches
            the __main__ script dir and then cwd for parameter_names.json
            and writes stats alongside it.
        All other keyword arguments are forwarded to FedAvg.__init__.
    """

    def __init__(
        self,
        *,
        pafa_lora_floor: float = 0.0,
        save_dir: Optional[str] = None,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.pafa_floor = float(pafa_lora_floor)
        self._grad_stats: List[dict] = []

        self._lora_indices: Optional[List[int]] = None
        self._proj_indices: Optional[List[int]] = None
        self._stats_file: Optional[str] = None

        names_file, self._stats_file = _resolve_paths(save_dir)

        if names_file is not None:
            with open(names_file) as f:
                names = json.load(f)
            self._lora_indices = [i for i, n in enumerate(names) if "lora_" in n]
            self._proj_indices = [i for i, n in enumerate(names) if "multi_modal_projector" in n]
            logger.info(
                "[PAFA] Component-aware mode: %d LoRA + %d projector indices — "
                "lora_floor=%.4f  proj_floor=1/n_clients",
                len(self._lora_indices), len(self._proj_indices), self.pafa_floor,
            )
            logger.info("[PAFA] Gradient stats → %s", self._stats_file)
        else:
            logger.info(
                "[PAFA] Flat mode (parameter_names.json not found) — floor=%.4f. "
                "Run generate_paramshape.py for component-aware QP + CGH tracking.",
                self.pafa_floor,
            )

        logger.info("[PAFA] Strategy initialised (fedops-vlm-framework)")

    # ------------------------------------------------------------------
    def aggregate_fit(
        self,
        server_round: int,
        results: List[Tuple[ClientProxy, FitRes]],
        failures: List[Union[Tuple[ClientProxy, FitRes], BaseException]],
    ) -> Tuple[Optional[Parameters], Dict[str, Scalar]]:

        if not results:
            return None, {}

        clients_arrays: List[List[np.ndarray]] = [
            parameters_to_ndarrays(fit_res.parameters) for _, fit_res in results
        ]
        num_examples = np.array(
            [max(fit_res.num_examples, 1) for _, fit_res in results], dtype=np.float64
        )
        data_weights = num_examples / num_examples.sum()
        n_clients = len(results)
        n_arrays = len(clients_arrays[0])

        # ── Component-aware: separate QPs for LoRA and projector ──────
        if (self._lora_indices and self._proj_indices
                and len(self._lora_indices) + len(self._proj_indices) <= n_arrays):

            lora_vecs = [_flatten([arrays[i] for i in self._lora_indices])
                         for arrays in clients_arrays]
            proj_vecs = [_flatten([arrays[i] for i in self._proj_indices])
                         for arrays in clients_arrays]

            # Build D matrices once — reuse for both QP solve and λ tracking
            D_lora = _build_dissimilarity_matrix(lora_vecs)
            D_proj = _build_dissimilarity_matrix(proj_vecs)

            lambda_lora = _mean_lambda(D_lora)
            lambda_proj = _mean_lambda(D_proj)

            flat_vecs = [np.concatenate([lv, pv]) for lv, pv in zip(lora_vecs, proj_vecs)]
            lambda_flat = _mean_lambda(_build_dissimilarity_matrix(flat_vecs))

            cgh = abs(lambda_lora - lambda_proj)

            proj_floor = 1.0 / n_clients
            lora_w = _solve_qp_weights(lora_vecs, data_weights,
                                       floor=self.pafa_floor, label="/LoRA", D=D_lora)
            proj_w = _solve_qp_weights(proj_vecs, data_weights,
                                       floor=proj_floor, label="/Proj", D=D_proj)

            logger.info(
                "[PAFA Round %d] λ_lora=%.4f  λ_proj=%.4f  λ_flat=%.4f  CGH=%.4f\n"
                "                LoRA  weights=%s\n"
                "                Proj  weights=%s\n"
                "                data_props  =%s",
                server_round,
                lambda_lora, lambda_proj, lambda_flat, cgh,
                np.array2string(lora_w, precision=3, suppress_small=True),
                np.array2string(proj_w, precision=3, suppress_small=True),
                np.array2string(data_weights, precision=3, suppress_small=True),
            )

            self._grad_stats.append({
                "round":        server_round,
                "lambda_lora":  float(lambda_lora),
                "lambda_proj":  float(lambda_proj),
                "lambda_flat":  float(lambda_flat),
                "cgh":          float(cgh),
                "lora_weights": lora_w.tolist(),
                "proj_weights": proj_w.tolist(),
                "data_weights": data_weights.tolist(),
            })

            lora_set = set(self._lora_indices)
            proj_set = set(self._proj_indices)
            aggregated: List[np.ndarray] = []
            for idx in range(n_arrays):
                w = lora_w if idx in lora_set else proj_w if idx in proj_set else data_weights
                agg = sum(w[i] * clients_arrays[i][idx].astype(np.float32)
                          for i in range(n_clients))
                aggregated.append(agg)

        # ── Flat fallback: single QP over all params ──────────────────
        else:
            vecs = [_flatten(arrays) for arrays in clients_arrays]
            D_flat = _build_dissimilarity_matrix(vecs)
            lambda_flat = _mean_lambda(D_flat)
            weights = _solve_qp_weights(vecs, data_weights,
                                        floor=self.pafa_floor, label="", D=D_flat)
            logger.info(
                "[PAFA Round %d] flat λ=%.4f  weights=%s  (data_props=%s)",
                server_round, lambda_flat,
                np.array2string(weights, precision=3, suppress_small=True),
                np.array2string(data_weights, precision=3, suppress_small=True),
            )
            self._grad_stats.append({
                "round":        server_round,
                "lambda_flat":  float(lambda_flat),
                "weights":      weights.tolist(),
                "data_weights": data_weights.tolist(),
            })
            aggregated = [
                sum(weights[i] * clients_arrays[i][idx].astype(np.float32)
                    for i in range(n_clients))
                for idx in range(n_arrays)
            ]

        # Write gradient stats after every round
        if self._stats_file:
            try:
                with open(self._stats_file, "w") as f:
                    json.dump(self._grad_stats, f, indent=2)
            except Exception as exc:
                logger.warning("[PAFA] Could not write gradient_stats.json: %s", exc)

        parameters_aggregated = ndarrays_to_parameters(aggregated)

        metrics_aggregated: Dict[str, Scalar] = {}
        if self.fit_metrics_aggregation_fn:
            fit_metrics = [(fit_res.num_examples, fit_res.metrics) for _, fit_res in results]
            metrics_aggregated = self.fit_metrics_aggregation_fn(fit_metrics)

        return parameters_aggregated, metrics_aggregated
