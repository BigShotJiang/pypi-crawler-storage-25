"""Shared dataset utilities for federated VLM fine-tuning."""

import ast
from collections.abc import Callable
import json
import os
import tempfile
from typing import Optional

import torch
from datasets import Dataset, load_dataset
from PIL import Image

# flwr_datasets imports matplotlib internally; ensure a writable config dir.
if "MPLCONFIGDIR" not in os.environ:
    default_mpl_dir = os.path.expanduser("~/.config/matplotlib")
    if not os.path.isdir(default_mpl_dir) or not os.access(default_mpl_dir, os.W_OK):
        fallback_mpl_dir = os.path.join(tempfile.gettempdir(), "matplotlib")
        os.makedirs(fallback_mpl_dir, exist_ok=True)
        os.environ["MPLCONFIGDIR"] = fallback_mpl_dir

from flwr_datasets import FederatedDataset
from flwr_datasets.partitioner import IidPartitioner

# FDS cache keyed by (dataset_name, num_partitions) — one per unique dataset.
_FDS: dict = {}

# Datasets that must be loaded directly (not via FederatedDataset).
DIRECT_DATASET_LOAD = {
    "HuggingFaceM4/ChartQA",
    "ds4sd/DocVQA",
}


def _pick_column_name(dataset: Dataset, candidates: list[str]) -> Optional[str]:
    for name in candidates:
        if name in dataset.column_names:
            return name
    return None


def _normalize_answer_value(value) -> str:
    """Convert heterogeneous answer objects into a plain string."""
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, list):
        for item in value:
            text = _normalize_answer_value(item)
            if text:
                return text
        return ""
    if isinstance(value, dict):
        for key in ("answer", "text", "label", "value"):
            if key in value:
                text = _normalize_answer_value(value[key])
                if text:
                    return text
        return ""
    return str(value).strip()


def _explode_qa_pairs(dataset: Dataset, image_key: str) -> Dataset:
    """Expand document-level qa_pairs into row-level image/question/answer samples."""

    def _batched_expand(batch):
        out_images, out_questions, out_answers = [], [], []
        for image_obj, qa_pairs in zip(batch[image_key], batch["qa_pairs"]):
            if isinstance(qa_pairs, str):
                try:
                    qa_pairs = json.loads(qa_pairs)
                except Exception:
                    try:
                        qa_pairs = ast.literal_eval(qa_pairs)
                    except Exception:
                        qa_pairs = []
            if not isinstance(qa_pairs, list):
                continue
            for pair in qa_pairs:
                question = ""
                answer_obj = None
                if isinstance(pair, dict):
                    question = str(
                        pair.get("question")
                        or pair.get("query")
                        or pair.get("prompt")
                        or pair.get("q")
                        or ""
                    ).strip()
                    answer_obj = (
                        pair.get("answer") if "answer" in pair
                        else pair.get("answers") if "answers" in pair
                        else pair.get("response") if "response" in pair
                        else pair.get("a")
                    )
                elif isinstance(pair, (list, tuple)) and len(pair) >= 2:
                    question = str(pair[0]).strip()
                    answer_obj = pair[1]

                answer = _normalize_answer_value(answer_obj)
                if not question or not answer:
                    continue
                out_images.append(image_obj)
                out_questions.append(question)
                out_answers.append(answer)
        return {"image": out_images, "question": out_questions, "answer": out_answers}

    return dataset.map(
        _batched_expand,
        batched=True,
        remove_columns=dataset.column_names,
        desc="Exploding qa_pairs",
    )


def ensure_standard_columns(dataset: Dataset) -> Dataset:
    """Normalize any VQA-style dataset to standard image/question/answer columns.

    Handles:
    - Column aliasing (instruction→question, caption→answer, etc.)
    - DocVQA qa_pairs explosion
    - answers (list) → answer (str) normalization
    - Image classification fallback (label → question+answer)
    """
    image_key = _pick_column_name(dataset, ["image", "images"])
    question_key = _pick_column_name(
        dataset, ["question", "instruction", "prompt", "query", "text"]
    )
    answer_key = _pick_column_name(dataset, ["answer", "response", "output", "caption"])
    label_key = _pick_column_name(dataset, ["label", "labels", "class", "category"])

    if image_key is not None and "qa_pairs" in dataset.column_names and answer_key is None:
        return _explode_qa_pairs(dataset, image_key=image_key)

    if answer_key is None and "answers" in dataset.column_names:
        dataset = dataset.map(
            lambda sample: {"answer": _normalize_answer_value(sample["answers"])},
            desc="Normalizing answers column",
        )
        answer_key = "answer"

    missing = []
    if image_key is None:
        missing.append("image")
    if question_key is None and label_key is None:
        missing.append("question")
    if answer_key is None and label_key is None:
        missing.append("answer")
    if missing:
        raise ValueError(
            "Dataset must provide multimodal columns. Missing canonical fields: "
            + ", ".join(missing)
        )

    if image_key != "image":
        dataset = dataset.rename_column(image_key, "image")
    if question_key is not None and question_key != "question":
        dataset = dataset.rename_column(question_key, "question")
    if answer_key is not None and answer_key != "answer":
        dataset = dataset.rename_column(answer_key, "answer")

    if (question_key is None or answer_key is None) and label_key is not None:
        if label_key != "label":
            dataset = dataset.rename_column(label_key, "label")

        def _from_label(sample):
            return {
                "question": "What class is shown in this image?",
                "answer": str(sample["label"]),
            }

        dataset = dataset.map(_from_label)

    keep = {"image", "question", "answer"}
    drop_cols = [col for col in dataset.column_names if col not in keep]
    if drop_cols:
        dataset = dataset.remove_columns(drop_cols)
    return dataset


def load_partition(
    partition_id: int,
    num_partitions: int,
    dataset_name: str,
    split: str = "train",
) -> Dataset:
    """Load and normalize one IID partition from a HuggingFace dataset.

    Uses FederatedDataset for standard datasets, direct load for special ones.
    Always returns a dataset with columns: image, question, answer.
    """
    global _FDS

    if dataset_name in DIRECT_DATASET_LOAD:
        dataset = load_dataset(dataset_name, split=split)
        dataset = ensure_standard_columns(dataset)
        return dataset.shard(
            num_shards=num_partitions,
            index=partition_id,
            contiguous=True,
        )

    cache_key = (dataset_name, num_partitions)
    if cache_key not in _FDS:
        partitioner = IidPartitioner(num_partitions=num_partitions)
        _FDS[cache_key] = FederatedDataset(
            dataset=dataset_name, partitioners={"train": partitioner}
        )

    if split != "train":
        raise ValueError("FederatedDataset scaffold supports split='train' only.")

    dataset = _FDS[cache_key].load_partition(partition_id, "train")
    return ensure_standard_columns(dataset)


def get_vlm_collate_fn(processor, max_length: int) -> Callable:
    """Build a multimodal collate function for image+text supervised fine-tuning.

    Images are resized to 224x224 to keep token count and VRAM tractable.
    Uses processor.apply_chat_template() when available, falls back to a
    simple <image>\\nQuestion: ...\\nAnswer: ... format.
    Labels set to -100 on padding tokens (ignored in cross-entropy loss).
    """

    def _prepare_image(image_obj):
        if isinstance(image_obj, Image.Image):
            return image_obj.convert("RGB").resize((224, 224))
        return image_obj

    def _build_prompt(question: str, answer: str) -> str:
        question = str(question).strip()
        answer = str(answer).strip()
        if hasattr(processor, "apply_chat_template"):
            conversation = [
                {
                    "role": "user",
                    "content": [
                        {"type": "image"},
                        {"type": "text", "text": question},
                    ],
                },
                {
                    "role": "assistant",
                    "content": [{"type": "text", "text": answer}],
                },
            ]
            try:
                return processor.apply_chat_template(
                    conversation,
                    tokenize=False,
                    add_generation_prompt=False,
                )
            except Exception:
                pass
        return f"<image>\nQuestion: {question}\nAnswer: {answer}"

    def collate_fn(examples: list[dict]) -> dict[str, torch.Tensor]:
        images = [_prepare_image(ex["image"]) for ex in examples]
        prompts = [_build_prompt(ex["question"], ex["answer"]) for ex in examples]

        batch = processor(
            images=images,
            text=prompts,
            padding=True,
            truncation=False,
            return_tensors="pt",
        )

        if "input_ids" in batch:
            labels = batch["input_ids"].clone()
            pad_token_id = getattr(processor.tokenizer, "pad_token_id", None)
            if pad_token_id is not None:
                labels[labels == pad_token_id] = -100
            batch["labels"] = labels

        return batch

    return collate_fn
