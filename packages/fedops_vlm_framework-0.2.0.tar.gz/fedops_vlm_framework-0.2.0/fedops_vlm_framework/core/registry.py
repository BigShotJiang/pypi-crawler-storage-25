"""Central plugin registry."""

from fedops_vlm_framework.plugins.datasets.chartqa import ChartQADatasetPlugin
from fedops_vlm_framework.plugins.datasets.docvqa import DocVQADatasetPlugin
from fedops_vlm_framework.plugins.datasets.path_vqa import PathVQADatasetPlugin
from fedops_vlm_framework.plugins.datasets.slake import SLAKEDatasetPlugin
from fedops_vlm_framework.plugins.datasets.vqav2 import VQAv2DatasetPlugin
from fedops_vlm_framework.plugins.datasets.vqa_rad import VQARadDatasetPlugin
from fedops_vlm_framework.plugins.deploy.mlc_compatible import (
    MlcCompatibleDeploymentPlugin,
)
from fedops_vlm_framework.plugins.deploy.onevision_research import (
    OneVisionResearchDeploymentPlugin,
)
from fedops_vlm_framework.plugins.models.onevision import OneVisionModelPlugin
from fedops_vlm_framework.plugins.models.phiva import PhivaModelPlugin

MODEL_PLUGINS = {
    "onevision": OneVisionModelPlugin(),
    "phiva": PhivaModelPlugin(),
}

DATASET_PLUGINS = {
    "vqav2": VQAv2DatasetPlugin(),
    "vqa_rad": VQARadDatasetPlugin(),
    "path_vqa": PathVQADatasetPlugin(),
    "slake": SLAKEDatasetPlugin(),
    "chartqa": ChartQADatasetPlugin(),
    "docvqa": DocVQADatasetPlugin(),
}

DEPLOYMENT_PLUGINS = {
    "mlc_compatible": MlcCompatibleDeploymentPlugin(),
    "onevision_research": OneVisionResearchDeploymentPlugin(),
}
