# Copyright (C) 2023 - 2026 ANSYS, Inc. and/or its affiliates.
# SPDX-License-Identifier: MIT
#
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from pyedb.dotnet.database.cell.layout_obj import LayoutObj
from pyedb.generic.product_property import EMProperties


class Connectable(LayoutObj):
    """Manages EDB functionalities for a connectable object."""

    def __init__(self, pedb, edb_object):
        super().__init__(pedb, edb_object)

    @property
    def net(self):
        """Net Object.

        Returns
        -------
        :class:`pyedb.dotnet.database.edb_data.nets_data.EDBNetsData`
        """
        from pyedb.dotnet.database.edb_data.nets_data import EDBNetsData

        return EDBNetsData(self._edb_object.GetNet(), self._pedb)

    @net.setter
    def net(self, value):
        """Set net."""
        net = self._pedb.nets[value]
        self._edb_object.SetNet(net.net_object)

    @property
    def net_name(self):
        """Get the primitive layer name.


        Returns
        -------
        str
        """
        net = self._edb_object.GetNet()
        if net.IsNull():
            return ""
        else:
            return net.GetName()

    @net_name.setter
    def net_name(self, name):
        if name in self._pedb.nets.netlist:
            obj = self._pedb.nets.nets[name].net_object
            self._edb_object.SetNet(obj)
        else:
            raise ValueError(f"Net {name} not found.")

    @property
    def component(self):
        """Component connected to this object.

        Returns
        -------
        :class:`dotnet.database.edb_data.nets_data.EDBComponent`
        """
        return self._pedb.layout.find_component_by_name(self.component_name) if self.component_name else ""

    @component.setter
    def component(self, value):
        self._edb_object.SetGroup(self._pedb.components.instances[value]._edb_object)

    @property
    def component_name(self):
        """Get the name of the component connected to this object."""
        comp = self._edb_object.GetComponent()
        if comp.IsNull():
            return ""
        else:
            return comp.GetName()

    def get_connected_objects(self):
        """Get connected objects.

        Returns
        -------
        list
        """
        return self._pedb.get_connected_objects(self._layout_obj_instance)

    def get_connected_object_id_set(self):
        """Produce a list of all geometries physically connected to a given layout object.

        Returns
        -------
        list
            Found connected objects IDs with Layout object.
        """
        layoutInst = self._edb_object.GetLayout().GetLayoutInstance()
        layoutObjInst = layoutInst.GetLayoutObjInstance(self._edb_object, None)  # 2nd arg was []
        return [loi.GetLayoutObj().GetId() for loi in layoutInst.GetConnectedObjects(layoutObjInst).Items]

    def get_em_properties(self) -> EMProperties:
        pid = self._pedb.core.ProductId.Designer
        flag, em_string = self._edb_object.GetProductProperty(pid, 18, "")
        if flag:
            if em_string:
                return EMProperties.from_em_string(em_string)
            else:
                return EMProperties()
        else:
            raise RuntimeError("Failed to get EM properties for padstack instance {}.".format(self.name))

    def set_em_properties(self, em_properties: EMProperties):
        pid = self._pedb.core.ProductId.Designer
        em_string = em_properties.to_em_string()
        return self._edb_object.SetProductProperty(pid, 18, em_string)

    @property
    def dcir_equipotential_region(self) -> bool:
        """Get or set whether this primitive or padstack instance has a DCIR equipotential region. If this padstack
        instance has pads on multiple layers, the region is set on top layer.
        """
        emp = self.get_em_properties()
        return emp.properties.dcir_equipotential_region

    @dcir_equipotential_region.setter
    def dcir_equipotential_region(self, value: bool):
        emp = self.get_em_properties()
        emp.properties.dcir_equipotential_region = value
        self.set_em_properties(emp)
