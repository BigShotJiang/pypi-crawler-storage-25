# Copyright (C) 2023 - 2026 ANSYS, Inc. and/or its affiliates.
# SPDX-License-Identifier: MIT
#
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from __future__ import absolute_import, annotations

from typing import TYPE_CHECKING, Union

from ansys.edb.core.layer.layer import LayerType as CoreLayerType
from ansys.edb.core.layer.stackup_layer import (
    EtchNetClass as CoreEtchNetClass,
    RoughnessRegion as CoreRoughnessRegion,
    StackupLayer as CoreStackupLayer,
)
from ansys.edb.core.utility.value import Value as CoreValue

if TYPE_CHECKING:
    from pyedb.grpc.database.layout.layout import Layout
from pyedb.grpc.database.utility.value import Value

_mapping_layer_type = {
    "signal": CoreLayerType.SIGNAL_LAYER,
    "dielectric": CoreLayerType.DIELECTRIC_LAYER,
    "wirebond": CoreLayerType.WIREBOND_LAYER,
}

_mapping_rougness_location = {
    "top": CoreRoughnessRegion.TOP,
    "bottom": CoreRoughnessRegion.BOTTOM,
    "side": CoreRoughnessRegion.SIDE,
}

_mapping_etch_net_class = {
    "all_nets": CoreEtchNetClass.ETCH_ALL_NETS,
    "no_power_ground": CoreEtchNetClass.NO_ETCH_POWER_GROUND,
}


class StackupLayer:
    def __init__(self, pedb, core=None):
        self.core = core
        self._pedb = pedb

    @property
    def _stackup_layer_mapping(self):
        return {
            "conducting_layer": CoreLayerType.CONDUCTING_LAYER,
            "silkscreen_layer": CoreLayerType.SILKSCREEN_LAYER,
            "solder_mask_layer": CoreLayerType.SOLDER_MASK_LAYER,
            "solder_paste_layer": CoreLayerType.SOLDER_PASTE_LAYER,
            "glue_layer": CoreLayerType.GLUE_LAYER,
            "wirebond_layer": CoreLayerType.WIREBOND_LAYER,
            "user_layer": CoreLayerType.USER_LAYER,
            "siwave_hfss_solver_regions": CoreLayerType.SIWAVE_HFSS_SOLVER_REGIONS,
        }

    @classmethod
    def create(
        cls,
        layout: Layout,
        name: str,
        layer_type: str = "signal",
        thickness: Union[str, float] = "17um",
        elevation: Union[str, float] = 0.0,
        material: str = "copper",
    ) -> StackupLayer:
        layer = CoreStackupLayer.create(
            name=name,
            layer_type=_mapping_layer_type[layer_type],
            thickness=layout._pedb._value_setter(thickness),
            elevation=layout._pedb._value_setter(elevation),
            material=material,
        )
        return cls(layout._pedb, layer)

    @property
    def id(self):
        """Layer ID.

        Returns
        -------
        int
            Layer ID.
        """
        return self.core.id

    @property
    def type(self) -> str:
        """Layer type.

        Returns
        -------
        str
            Layer name.
        """
        return self.core.type.name.lower().split("_")[0]

    @type.setter
    def type(self, value):
        if value in self._stackup_layer_mapping:
            self.core.type = value

    def update(self, **kwargs):
        for k, v in kwargs.items():
            if k in dir(self):
                self.__setattr__(k, v)
            elif k == "roughness":
                self.roughness_enabled = v["enabled"]
                if "top" in v:
                    top_roughness = v["top"]
                    if top_roughness:
                        if top_roughness["model"] == "huray":
                            nodule_radius = top_roughness["nodule_radius"]
                            surface_ratio = top_roughness["surface_ratio"]
                            self.assign_roughness_model(
                                model_type="huray",
                                huray_radius=nodule_radius,
                                huray_surface_ratio=surface_ratio,
                                apply_on_surface="top",
                            )
                        elif top_roughness["model"] == "groisse":
                            roughness = top_roughness["roughness"]
                            self.assign_roughness_model(
                                model_type="groisse", groisse_roughness=roughness, apply_on_surface="top"
                            )
                    if "bottom" in v:
                        bottom_roughness = v["bottom"]
                        if bottom_roughness:
                            if bottom_roughness["model"] == "huray":
                                nodule_radius = bottom_roughness["nodule_radius"]
                                surface_ratio = bottom_roughness["surface_ratio"]
                                self.assign_roughness_model(
                                    model_type="huray",
                                    huray_radius=nodule_radius,
                                    huray_surface_ratio=surface_ratio,
                                    apply_on_surface="bottom",
                                )
                            elif bottom_roughness["model"] == "groisse":
                                roughness = bottom_roughness["roughness"]
                                self.assign_roughness_model(
                                    model_type="groisse", groisse_roughness=roughness, apply_on_surface="bottom"
                                )
                    if "side" in v:
                        side_roughness = v["side"]
                        if side_roughness:
                            if side_roughness["model"] == "huray":
                                nodule_radius = side_roughness["nodule_radius"]
                                surface_ratio = side_roughness["surface_ratio"]
                                self.assign_roughness_model(
                                    model_type="huray",
                                    huray_radius=nodule_radius,
                                    huray_surface_ratio=surface_ratio,
                                    apply_on_surface="side",
                                )
                            elif side_roughness["model"] == "groisse":
                                roughness = side_roughness["roughness"]
                                self.assign_roughness_model(
                                    model_type="groisse", groisse_roughness=roughness, apply_on_surface="side"
                                )

            elif k == "etching":
                self.etch_factor_enabled = v["enabled"]
                self.etch_factor = float(v["factor"])
            else:
                self._pedb.logger.error(f"{k} is not a valid layer attribute")

    def _create(self, layer_type):
        if layer_type in self._stackup_layer_mapping:
            layer_type = self._stackup_layer_mapping[layer_type]
            self._edb_object = CoreStackupLayer.create(
                self.name,
                layer_type,
                0.0,
                0.0,
                "copper",
            )

    @property
    def lower_elevation(self) -> float:
        """Lower elevation.

        Returns
        -------
        float
            Lower elevation.
        """
        return Value(self.core.lower_elevation, self._pedb.active_cell)

    @lower_elevation.setter
    def lower_elevation(self, value):
        if self._pedb.stackup.mode == "overlapping":
            self.core.lower_elevation = self._pedb._value_setter(value)

    @property
    def fill_material(self) -> Union[str, None]:
        """The layer's fill material.

        Returns
        -------
        str
            Material name.
        """
        if self.type == "signal":
            return self.core.get_fill_material()
        else:
            return None

    @fill_material.setter
    def fill_material(self, value):
        self.core.set_fill_material(value)

    @property
    def upper_elevation(self) -> float:
        """Upper elevation.

        Returns
        -------
        float
            Upper elevation.
        """
        return Value(self.core.upper_elevation, self._pedb.active_cell)

    @property
    def is_negative(self) -> bool:
        """Determine whether this layer is a negative layer.

        Returns
        -------
        bool
            True if this layer is a negative layer, False otherwise.
        """
        return self.core.negative

    @property
    def name(self) -> str:
        """Layer name.

        Returns
        -------
        str
            Layer name.

        """
        return self.core.name

    @name.setter
    def name(self, value):
        self.core.name = value

    @is_negative.setter
    def is_negative(self, value):
        """Layer negative.

        Returns
        -------
        bool

        """
        self.core.negative = value

    @property
    def is_stackup_layer(self) -> bool:
        """Testing if layer is stackup layer.

        Returns
        -------
        `True` if layer type is "signal" or "dielectric".
        """
        if self.type in ["signal", "dielectric", "via", "wirebond"]:
            return True
        return False

    @property
    def material(self) -> str:
        """Material.

        Returns
        -------
        str
            Material name.
        """
        return self.core.get_material()

    @material.setter
    def material(self, name):
        self.core.set_material(name)

    @property
    def conductivity(self) -> float:
        """Material conductivity.

        Returns
        -------
        float
            Material conductivity value.
        """
        if self.material in self._pedb.materials.materials:
            condcutivity = self._pedb.materials[self.material].conductivity
            return condcutivity if condcutivity else 0.0
        return 0.0

    @property
    def permittivity(self) -> float:
        """Material permittivity.

        Returns
        -------
        float
            Material permittivity value.
        """
        if self.material in self._pedb.materials.materials:
            permittivity = self._pedb.materials[self.material].permittivity
            return permittivity if permittivity else 1.0
        return 1.0

    @property
    def loss_tangent(self) -> float:
        """Material loss_tangent.

        Returns
        -------
        float
            Material loss tangent value.
        """
        if self.material in self._pedb.materials.materials:
            loss_tangent = self._pedb.materials[self.material].dielectric_loss_tangent
            return loss_tangent if loss_tangent else 0.0
        return 0.0

    @property
    def dielectric_fill(self) -> Union[str, None]:
        """Material name of the layer dielectric fill.

        Returns
        -------
        str
            Material name.
        """
        if self.type == "signal":
            return self.core.get_fill_material()
        else:
            return None

    @dielectric_fill.setter
    def dielectric_fill(self, name):
        if self.type == "signal":
            self.core.set_fill_material(name)
        else:
            pass

    @property
    def thickness(self) -> float:
        """Layer thickness.

        Returns
        -------
        float
            Layer thickness.
        """
        return Value(self.core.thickness, self._pedb.active_cell)

    @thickness.setter
    def thickness(self, value):
        self.core.thickness = self._pedb._value_setter(value)

    @property
    def etch_factor_enabled(self) -> bool:
        """Layer etching factor enable flag.

        Returns
        -------
        bool
            Etching factor flag.
        """
        return self.core.etch_factor_enabled

    @etch_factor_enabled.setter
    def etch_factor_enabled(self, value):
        self.core.etch_factor_enabled = value

    @property
    def etch_factor(self) -> float:
        """Layer etching factor.

        Returns
        -------
        float
            Etching factor value.
        """
        return Value(self.core.etch_factor, self._pedb.active_cell)

    @etch_factor.setter
    def etch_factor(self, value):
        try:
            if not value:
                self.core.etch_factor_enabled = False
            else:
                self.core.etch_factor_enabled = True
                self.core.etch_factor = self._pedb._value_setter(value)
        except RuntimeError:
            pass

    @property
    def etch_net_class(self) -> str:
        """
        Retrieve net class name where etching is enabled.

        Returns
        -------
        str
            Net class on which etching is applied. Supported values `no_power_ground`, `all_nets`.
        """
        reverse_mapping = {v: k for k, v in _mapping_etch_net_class.items()}
        return reverse_mapping.get(self.core.etch_net_class, "all_nets")

    @etch_net_class.setter
    def etch_net_class(self, etch_net_class: str):
        if isinstance(etch_net_class, str):
            core_value = _mapping_etch_net_class.get(etch_net_class, _mapping_etch_net_class.get("all_nets"))
            self.core.etch_net_class = core_value
        else:
            self.core.etch_net_class = etch_net_class

    @property
    def top_hallhuray_nodule_radius(self) -> float:
        """Huray model nodule radius on layer top.

        Returns
        -------
        float
            Nodule radius value.
        """
        if self.roughness_enabled:
            # grpc crashes if roughness is not enabled. check issue #711 on pyedb-core
            if not self.top_rouhness_model_type == "huray":
                self._pedb.logger.warning("Top surface roughness model is not Huray, cannot get nodule radius value.")
                return 0.0
            top_roughness_model = self.core.get_roughness_model(CoreRoughnessRegion.TOP)
            return self._pedb.value(top_roughness_model[0])
        else:
            return 0.0

    @top_hallhuray_nodule_radius.setter
    def top_hallhuray_nodule_radius(self, value: float):
        if not self.roughness_enabled:
            self.roughness_enabled = True
        self.assign_roughness_model(model_type="huray", huray_radius=value, apply_on_surface="top")

    @property
    def top_hallhuray_surface_ratio(self) -> float:
        """Huray model surface ratio on layer top.

        Returns
        -------
        float
            Surface ratio.
        """
        if self.roughness_enabled:
            if not self.top_rouhness_model_type == "huray":
                self._pedb.logger.warning("Top surface roughness model is not Huray, cannot get surface ratio value.")
                return 0.0
            top_roughness_model = self.core.get_roughness_model(CoreRoughnessRegion.TOP)
            return self._pedb.value(top_roughness_model[1])
        else:
            # grpc crashes if roughness is not enabled. Check issue #711 on pyedb-core
            return 0.0

    @top_hallhuray_surface_ratio.setter
    def top_hallhuray_surface_ratio(self, value: float):
        if not self.roughness_enabled:
            self.roughness_enabled = True
        self.assign_roughness_model(model_type="huray", huray_surface_ratio=value, apply_on_surface="top")

    @property
    def bottom_hallhuray_nodule_radius(self) -> float:
        """Huray model nodule radius on layer bottom.

        Returns
        -------
        float
            Nodule radius.
        """
        if self.roughness_enabled:
            if not self.bottom_rouhness_model_type == "huray":
                self._pedb.logger.warning(
                    "Bottom surface roughness model is not Huray, cannot get nodule radius value."
                )
                return 0.0
            bottom_roughness_model = self.core.get_roughness_model(CoreRoughnessRegion.BOTTOM)
            return self._pedb.value(bottom_roughness_model[0])
        else:
            # grpc crashes if roughness is not enabled. Check issue #711 on pyedb-core
            return 0.0

    @bottom_hallhuray_nodule_radius.setter
    def bottom_hallhuray_nodule_radius(self, value):
        if not self.roughness_enabled:
            self.roughness_enabled = True
        self.assign_roughness_model(model_type="huray", huray_radius=value, apply_on_surface="bottom")

    @property
    def bottom_hallhuray_surface_ratio(self) -> float:
        """Huray model surface ratio on layer bottom.

        Returns
        -------
        float
            Surface ratio value.
        """
        if self.roughness_enabled:
            if not self.bottom_rouhness_model_type == "huray":
                self._pedb.logger.warning(
                    "Bottom surface roughness model is not Huray, cannot get surface ratio value."
                )
                return 0.0
            bottom_roughness_model = self.core.get_roughness_model(CoreRoughnessRegion.BOTTOM)
            return self._pedb.value(bottom_roughness_model[1])
        else:
            # grpc crashes if roughness is not enabled. Check issue #711 on pyedb-core
            return 0.0

    @bottom_hallhuray_surface_ratio.setter
    def bottom_hallhuray_surface_ratio(self, value):
        if not self.roughness_enabled:
            self.roughness_enabled = True
        self.assign_roughness_model(model_type="huray", huray_surface_ratio=value, apply_on_surface="bottom")

    @property
    def side_hallhuray_nodule_radius(self) -> float:
        """Huray model nodule radius on layer sides.

        Returns
        -------
        float
            Nodule radius value.

        """
        # grpc crashes if roughness is not enabled. Check issue #711 on pyedb-core
        if self.roughness_enabled:
            if not self.side_rouhness_model_type == "huray":
                self._pedb.logger.warning("Side surface roughness model is not Huray, cannot get nodule radius value.")
                return 0.0
            side_roughness_model = self.core.get_roughness_model(CoreRoughnessRegion.SIDE)
            return self._pedb.value(side_roughness_model[0])
        else:
            return 0.0

    @side_hallhuray_nodule_radius.setter
    def side_hallhuray_nodule_radius(self, value):
        if not self.roughness_enabled:
            self.roughness_enabled = True
        self.assign_roughness_model(model_type="huray", huray_radius=value, apply_on_surface="side")

    @property
    def side_hallhuray_surface_ratio(self) -> float:
        """Huray model surface ratio on layer sides.

        Returns
        -------
        float
            surface ratio.
        """
        # grpc crashes if roughness is not enabled. Check issue #711 on pyedb-core
        if self.roughness_enabled:
            if not self.side_rouhness_model_type == "huray":
                self._pedb.logger.warning("Side surface roughness model is not Huray, cannot get surface ratio value.")
                return 0.0
            side_roughness_model = self.core.get_roughness_model(CoreRoughnessRegion.SIDE)
            return self._pedb.value(side_roughness_model[1])
        else:
            return 0.0

    @side_hallhuray_surface_ratio.setter
    def side_hallhuray_surface_ratio(self, value):
        if not self.roughness_enabled:
            self.roughness_enabled = True
        self.assign_roughness_model(model_type="huray", huray_surface_ratio=value, apply_on_surface="side")

    @property
    def top_groisse_roughness(self) -> float:
        """Groisse model on layer top.

        Returns
        -------
        float
            Roughness value.
        """
        # grpc crashes if rouhgness is not enabled. Check issue #711 on pyedb-core
        if self.roughness_enabled:
            if not self.top_rouhness_model_type == "groisse":
                self._pedb.logger.warning("Top surface roughness model is not Groisse, cannot get roughness value.")
                return 0.0
            top_roughness = self.core.get_roughness_model(CoreRoughnessRegion.TOP)
            return self._pedb.value(top_roughness)
        else:
            return 0.0

    @top_groisse_roughness.setter
    def top_groisse_roughness(self, value):
        if not self.roughness_enabled:
            # make sure roughness is enabled to prevent crash. check issue #711 on pyedb-core
            self.roughness_enabled = True
        self.assign_roughness_model(model_type="groisse", groisse_roughness=value, apply_on_surface="top")

    @property
    def bottom_groisse_roughness(self) -> float:
        """Groisse model on layer bottom.

        Returns
        -------
        float
            Roughness value.
        """
        # grpc crashes if rouhgness is not enabled. Check issue #711 on pyedb-core
        if self.roughness_enabled:
            if not self.bottom_rouhness_model_type == "groisse":
                self._pedb.logger.warning("Bottom surface roughness model is not Groisse, cannot get roughness value.")
                return 0.0
            bottom_roughness = self.core.get_roughness_model(CoreRoughnessRegion.BOTTOM)
            return self._pedb.value(bottom_roughness)
        else:
            return 0.0

    @bottom_groisse_roughness.setter
    def bottom_groisse_roughness(self, value):
        if not self.roughness_enabled:
            # make sure roughness is enabled to prevent crash. check issue #711 on pyedb-core
            self.roughness_enabled = True
        self.assign_roughness_model(model_type="groisse", groisse_roughness=value, apply_on_surface="bottom")

    @property
    def side_groisse_roughness(self) -> float:
        """Groisse model on layer bottom.

        Returns
        -------
        float
            Roughness value.
        """
        # grpc crashes if rouhgness is not enabled. Check issue #711 on pyedb-core
        if self.roughness_enabled:
            if not self.side_rouhness_model_type == "groisse":
                self._pedb.logger.warning("Side surface roughness model is not Groisse, cannot get roughness value.")
                return 0.0
            bottom_roughness = self.core.get_roughness_model(CoreRoughnessRegion.SIDE)
            return self._pedb.value(bottom_roughness)
        else:
            return 0.0

    @side_groisse_roughness.setter
    def side_groisse_roughness(self, value):
        if not self.roughness_enabled:
            # make sure roughness is enabled to prevent crash. check issue #711 on pyedb-core
            self.roughness_enabled = True
        self.assign_roughness_model(model_type="groisse", groisse_roughness=value, apply_on_surface="side")

    @property
    def color(self) -> tuple[int, int, int]:
        """Layer color.

        Returns
        -------
        str
            Layer color in hex format.
        """
        return self.core.color

    @color.setter
    def color(self, value):
        self.core.color = value

    @property
    def transparency(self) -> int:
        """Layer transparency.

        Returns
        -------
        float
            Layer transparency value between 0 and 100.
        """
        return self.core.transparency

    @transparency.setter
    def transparency(self, value):
        self.core.transparency = value

    @property
    def top_rouhness_model_type(self) -> str:
        """Roughness model type on layer top.

        Returns
        -------
        str
            Roughness model type. Options are "huray", "groisse", or "none".
        """
        return self.get_roughness_model_type(location="top")

    @property
    def bottom_rouhness_model_type(self) -> str:
        """Roughness model type on layer bottom.

        Returns
        -------
        str
            Roughness model type. Options are "huray", "groisse", or "none".
        """
        return self.get_roughness_model_type(location="bottom")

    @property
    def side_rouhness_model_type(self) -> str:
        """Roughness model type on layer sides.

        Returns
        -------
        str
            Roughness model type. Options are "huray", "groisse", or "none".
        """
        return self.get_roughness_model_type(location="side")

    def get_roughness_model_type(self, location=None) -> str:
        """Roughness model type.

        Parameters
        ----------
        location : str, optional
            Location of roughness model. The default is None, which returns the roughness model type on the top surface.
            Options are "top", "bottom", "side".

        Returns
        -------
        str
            Roughness model type. Options are "huray", "groisse", or "none".
        """
        if self.roughness_enabled:
            if location.lower() in _mapping_rougness_location:
                location = _mapping_rougness_location[location.lower()]
                roughness_model = self.core.get_roughness_model(location)
                if isinstance(roughness_model, tuple):
                    return "huray"
                elif isinstance(roughness_model, CoreValue | Value):
                    return "groisse"
        return "none"

    @property
    def roughness_enabled(self) -> bool:
        """Roughness model enabled status.

        Returns
        -------
        bool
            True if roughness model is enabled, False otherwise.
        """
        return self.core.roughness_enabled

    @roughness_enabled.setter
    def roughness_enabled(self, value):
        try:
            self.core.roughness_enabled = value
        except RuntimeError:
            pass

    def assign_roughness_model(
        self,
        model_type="huray",
        huray_radius="0.5um",
        huray_surface_ratio="2.9",
        groisse_roughness="1um",
        apply_on_surface="all",
    ) -> bool:
        """Assign roughness model on this layer.

        Parameters
        ----------
        model_type : str, optional
            Type of roughness model. The default is ``"huray"``. Options are ``"huray"``, ``"groisse"``.
        huray_radius : str, float, optional
            Radius of huray model. The default is ``"0.5um"``.
        huray_surface_ratio : str, float, optional.
            Surface ratio of huray model. The default is ``"2.9"``.
        groisse_roughness : str, float, optional
            Roughness of groisse model. The default is ``"1um"``.
        apply_on_surface : str, optional.
            Where to assign roughness model. The default is ``"all"``. Options are ``"top"``, ``"bottom"``,
             ``"side"``.

        Returns
        -------
        bool
        """
        regions = []
        if self.type == "signal":
            self.roughness_enabled = True
            if apply_on_surface == "all":
                regions = [CoreRoughnessRegion.TOP, CoreRoughnessRegion.BOTTOM, CoreRoughnessRegion.SIDE]
            elif apply_on_surface == "top":
                regions = [CoreRoughnessRegion.TOP]
            elif apply_on_surface == "bottom":
                regions = [CoreRoughnessRegion.BOTTOM]
            elif apply_on_surface == "side":
                regions = [CoreRoughnessRegion.SIDE]
            self.core.roughness_enabled = True
            for r in regions:
                if model_type == "huray":
                    model = (Value(huray_radius), Value(huray_surface_ratio))
                else:
                    model = Value(groisse_roughness)
                self.core.set_roughness_model(model, r)
            if [
                self.core.get_roughness_model(CoreRoughnessRegion.TOP),
                self.core.get_roughness_model(CoreRoughnessRegion.BOTTOM),
                self.core.get_roughness_model(CoreRoughnessRegion.SIDE),
            ]:
                return True
        self._pedb.logger.warning(f"Layer {self.name} roughness model can be assigned only on signal layers.")
        return False

    @property
    def properties(self) -> dict[str, dict[str, str]] | bool:
        data = {"name": self.core.name, "type": self.type, "color": self.color}
        if self.type == "signal" or self.type == "dielectric":
            data["material"] = self.material
            data["thickness"] = self.thickness
        if self.type == "signal":
            data["fill_material"] = self.fill_material
        roughness = {"top": {}, "bottom": {}, "side": {}}
        if self.top_hallhuray_nodule_radius:
            roughness["top"]["model"] = "huray"
            roughness["top"]["nodule_radius"] = str(self.top_hallhuray_nodule_radius)
            roughness["top"]["surface_ratio"] = str(self.top_hallhuray_surface_ratio)

        elif self.top_groisse_roughness:
            roughness["top"]["model"] = "groisse"
            roughness["top"]["roughness"] = str(self.top_groisse_roughness)

        if self.bottom_hallhuray_nodule_radius:
            roughness["bottom"]["model"] = "huray"
            roughness["bottom"]["nodule_radius"] = str(self.bottom_hallhuray_nodule_radius)
            roughness["bottom"]["surface_ratio"] = str(self.bottom_hallhuray_surface_ratio)

        elif self.bottom_groisse_roughness:
            roughness["bottom"]["model"] = "groisse"
            roughness["bottom"]["roughness"] = str(self.bottom_groisse_roughness)

        if self.side_hallhuray_nodule_radius:
            roughness["side"]["model"] = "huray"
            roughness["side"]["nodule_radius"] = str(self.side_hallhuray_nodule_radius)
            roughness["side"]["surface_ratio"] = str(self.side_hallhuray_surface_ratio)

        elif self.side_groisse_roughness:
            roughness["side"]["model"] = "groisse"
            roughness["side"]["roughness"] = str(self.side_groisse_roughness)

        if roughness["top"] or roughness["bottom"] or roughness["side"]:
            roughness["enabled"] = True
        else:
            roughness["enabled"] = False
        data["roughness"] = roughness
        data["etching"] = {"enabled": self.etch_factor_enabled, "factor": self.etch_factor}
        return data

    def _json_format(self):
        dict_out = {
            "color": self.color,
            "dielectric_fill": self.dielectric_fill,
            "etch_factor": self.etch_factor,
            "material": self.material,
            "loss_tangent": self.loss_tangent,
            "permittivity": self.permittivity,
            "conductivity": self.conductivity,
            "zones": self.core.zones,
            "transparency": self.core.transparency,
            "name": self.name,
            "roughness_enabled": self.roughness_enabled,
            "thickness": self.thickness,
            "lower_elevation": self.lower_elevation,
            "upper_elevation": self.upper_elevation,
            "type": self.type,
            "top_hallhuray_nodule_radius": self.top_hallhuray_nodule_radius,
            "top_hallhuray_surface_ratio": self.top_hallhuray_surface_ratio,
            "side_hallhuray_nodule_radius": self.side_hallhuray_nodule_radius,
            "side_hallhuray_surface_ratio": self.side_hallhuray_surface_ratio,
            "bottom_hallhuray_nodule_radius": self.bottom_hallhuray_nodule_radius,
            "bottom_hallhuray_surface_ratio": self.bottom_hallhuray_surface_ratio,
        }
        return dict_out

    def _load_layer(self, layer):
        if layer:
            self.color = layer["color"]
            self.type = layer["type"]
            if isinstance(layer["material"], str):
                self.material = layer["material"]
            else:
                material_data = layer["material"]
                if material_data is not None:
                    material_name = layer["material"]["name"]
                    self._pedb.materials.add_material(material_name, **material_data)
                    self.material = material_name
            if layer["dielectric_fill"]:
                if isinstance(layer["dielectric_fill"], str):
                    self.dielectric_fill = layer["dielectric_fill"]
                else:
                    dielectric_data = layer["dielectric_fill"]
                    if dielectric_data is not None:
                        self._pedb.materials.add_material(**dielectric_data)
                    self.dielectric_fill = layer["dielectric_fill"]["name"]
            self.thickness = layer["thickness"]
            self.etch_factor = layer["etch_factor"]
            self.roughness_enabled = layer["roughness_enabled"]
            if self.roughness_enabled:
                self.top_hallhuray_nodule_radius = layer["top_hallhuray_nodule_radius"]
                self.top_hallhuray_surface_ratio = layer["top_hallhuray_surface_ratio"]
                self.assign_roughness_model(
                    "huray",
                    layer["top_hallhuray_nodule_radius"],
                    layer["top_hallhuray_surface_ratio"],
                    apply_on_surface="top",
                )
                self.bottom_hallhuray_nodule_radius = layer["bottom_hallhuray_nodule_radius"]
                self.bottom_hallhuray_surface_ratio = layer["bottom_hallhuray_surface_ratio"]
                self.assign_roughness_model(
                    "huray",
                    layer["bottom_hallhuray_nodule_radius"],
                    layer["bottom_hallhuray_surface_ratio"],
                    apply_on_surface="bottom",
                )
                self.side_hallhuray_nodule_radius = layer["side_hallhuray_nodule_radius"]
                self.side_hallhuray_surface_ratio = layer["side_hallhuray_surface_ratio"]
                self.assign_roughness_model(
                    "huray",
                    layer["side_hallhuray_nodule_radius"],
                    layer["side_hallhuray_surface_ratio"],
                    apply_on_surface="side",
                )
