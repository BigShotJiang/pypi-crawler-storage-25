# Copyright (C) 2023 - 2026 ANSYS, Inc. and/or its affiliates.
# SPDX-License-Identifier: MIT
#
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# -*- coding: utf-8 -*-
from __future__ import absolute_import

import ast
import codecs
from collections import OrderedDict
import csv
import datetime
import difflib
import fnmatch
import math
import os
from pathlib import Path
import re
import secrets
import string
import sys
import tempfile
import time
from typing import IO, TYPE_CHECKING, Any
import xml.etree.ElementTree as ET  # nosec B405

from pyedb.generic.constants import CSS4_COLORS
from pyedb.generic.settings import settings

# Backwards-compatible re-exports (decorators were moved to pyedb.misc.decorators)
from pyedb.misc.decorators import deprecate_argument_name, deprecated, deprecated_class, execution_timer

if TYPE_CHECKING:
    import pandas as pd


__all__ = [
    "installed_ansys_em_versions",
    "deprecate_argument_name",
    "execution_timer",
]

is_linux = os.name == "posix"
is_windows = not is_linux
_pythonver = sys.version_info[0]

# FIXME: Some of the functions in this module are not used or not often.
# Consider removing them if they are not needed.


class GrpcApiError(Exception):
    """Error raised when a gRPC API call fails."""

    pass


def installed_ansys_em_versions() -> dict[str, str]:
    """Retrieve paths of installed ANSYS EM versions.

    Scan the environment variables and return a dict of the form
    {version: installation_path} for every ANSYS EM release found.
    Versions are ordered from the oldest to the latest (latest appears last).

    Returns
    -------
    Dict[str, str]
        Dictionary of the form {version: installation_path} for every ANSYS EM release found.
    """
    pattern = re.compile(r"^ANSYSEM_ROOT(\d{3})$", re.IGNORECASE)

    versions = {}
    for key, value in os.environ.items():
        m = pattern.match(key)
        if m:
            version = m.group(1)
            versions[version] = value.rstrip(os.sep)

    # sort ascending so the latest is last
    return dict(sorted(versions.items(), key=lambda kv: int(kv[0])))


@deprecated("Please use pathlib.Path.stem to get the filename without its extension.")
def get_filename_without_extension(path: str | Path) -> str:
    """Get the filename without its extension.

    Parameters
    ----------
    path : str or Path
        Path of the file.

    Returns
    -------
    str
       Name for the file, excluding its extension.
    """
    return Path(path).stem


def env_path(input_version: str) -> str:
    """Get the path of the version environment variable for an AEDT version.

    Parameters
    ----------
    input_version : str
        AEDT version.

    Returns
    -------
    str
        Path for the version environment variable.

    Examples
    --------
    >>> env_path_student("2021.2")
    "C:/Program Files/ANSYSEM/ANSYSEM2021.2/Win64"
    """
    try:
        return os.getenv(
            "ANSYSEM_ROOT{0}{1}".format(
                get_version_and_release(input_version)[0], get_version_and_release(input_version)[1]
            ),
            "",
        )
    except TypeError as e:
        raise Exception(
            "The edb version is not provided and can't be inferred from the environment variables. "
            "Please provide the version as an argument."
        ) from e


def get_version_and_release(input_version: str) -> tuple[int, int]:
    """Get the version and release numbers for an AEDT version.

    Parameters
    ----------
    input_version : str
        AEDT version.

    Returns
    -------
    tuple[int, int]
        Tuple containing the version and release numbers.
    """
    version = int(input_version[2:4])
    release = int(input_version[5])
    if version < 20:
        if release < 3:
            version -= 1
        else:
            release -= 2
    return (version, release)


def env_value(input_version: str) -> str:
    """Get the name of the version environment variable for an AEDT version.

    Parameters
    ----------
    input_version : str
        AEDT version.

    Returns
    -------
    str
        Name for the version environment variable.

    Examples
    --------
    >>> env_value("2021.2")
    "ANSYSEM_ROOT211"
    """
    return "ANSYSEM_ROOT{0}{1}".format(
        get_version_and_release(input_version)[0], get_version_and_release(input_version)[1]
    )


def generate_unique_name(rootname: str, suffix: str = "", n: int = 6) -> str:
    """Generate a new name given a root name and optional suffix.

    Parameters
    ----------
    rootname : str
        Root name to add random characters to.
    suffix : str
        Suffix to add. The default is ``""``.
    n : int
        Number of random characters to add to the name. The default value is ``6``.

    Returns
    -------
    str
        Newly generated name.
    """
    char_set = string.ascii_uppercase + string.digits
    name = "".join(secrets.choice(char_set) for _ in range(n))
    unique_name = rootname + "_" + name
    if suffix:
        unique_name += "_" + suffix
    return unique_name


@deprecated("Please use pathlib.Path.as_posix() to normalize path separators.")
def normalize_path(path_in: str, sep: str | None = None) -> str:
    """Normalize path separators.

    Parameters
    ----------
    path_in : str
        Path to normalize.
    sep : str, optional
        Separator. Default is ``None``, in which case the system separator is used.

    Returns
    -------
    str
        Path normalized to new separator.
    """
    if sep is None:
        sep = os.sep
    return path_in.replace("\\", sep).replace("/", sep)


def check_numeric_equivalence(a: int | float, b: int | float, relative_tolerance: float = 1e-7) -> bool:
    """Check if two numeric values are equivalent to within a relative tolerance.

    Parameters
    ----------
    a : int, float
        Reference value to compare to.
    b : int, float
        Secondary value for the comparison.
    relative_tolerance : float, optional
        Relative tolerance for the equivalence test. The difference is relative to the first value.
        The default is ``1e-7``.

    Returns
    -------
    bool
        ``True`` if the two passed values are equivalent.
    """
    if abs(a) > 0.0:
        reldiff = abs(a - b) / a
    else:
        reldiff = abs(b)
    return True if reldiff < relative_tolerance else False


def check_and_download_file(local_path: str, remote_path: str, overwrite: bool = True) -> str:
    """Check if a file is remote and either download it or return the path.

    Parameters
    ----------
    local_path : str
        Local path to save the file to.
    remote_path : str
        Path to the remote file.
    overwrite : bool
        Whether to overwrite the file if it already exits locally.
        The default is ``True``.

    Returns
    -------
    str
    """
    if settings.remote_rpc_session:
        remote_path = remote_path.replace("\\", "/") if remote_path[0] != "\\" else remote_path
        settings.remote_rpc_session.filemanager.download_file(remote_path, local_path, overwrite=overwrite)
        return local_path
    return remote_path


def check_if_path_exists(path: str) -> bool:
    """Check whether a path exists or not local or remote machine (for remote sessions only).

    Parameters
    ----------
    path : str
        Local or remote path to check.

    Returns
    -------
    bool
    """
    if settings.remote_rpc_session:
        return settings.remote_rpc_session.filemanager.pathexists(path)
    return os.path.exists(path)


def check_and_download_folder(local_path: str, remote_path: str, overwrite: bool = True) -> str:
    """Check if a folder is remote and either download it or return the path.

    Parameters
    ----------
    local_path : str
        Local path to save the folder to.
    remote_path : str
        Path to the remote folder.
    overwrite : bool
        Whether to overwrite the folder if it already exits locally.
        The default is ``True``.

    Returns
    -------
    str
    """
    if settings.remote_rpc_session:
        remote_path = remote_path.replace("\\", "/") if remote_path[0] != "\\" else remote_path
        settings.remote_rpc_session.filemanager.download_folder(remote_path, local_path, overwrite=overwrite)
        return local_path
    return remote_path


def open_file(file_path: str, file_options: str = "r") -> IO[Any]:  # pragma: no cover
    """Open a file and return the object.

    Parameters
    ----------
    file_path : str
        Full absolute path to the file (either local or remote).
    file_options : str, optional
        Options for opening the file.

    Returns
    -------
    IO[Any]
        Opened file.
    """
    file_path = file_path.replace("\\", "/") if file_path[0] != "\\" else file_path
    dir_name = os.path.dirname(file_path)
    if "r" in file_options:
        if os.path.exists(file_path):
            return open(file_path, file_options)
        elif settings.remote_rpc_session and settings.remote_rpc_session.filemanager.pathexists(
            file_path
        ):  # pragma: no cover
            local_file = os.path.join(tempfile.gettempdir(), os.path.split(file_path)[-1])
            settings.remote_rpc_session.filemanager.download_file(file_path, local_file)
            return open(local_file, file_options)
    elif os.path.exists(dir_name):
        return open(file_path, file_options)
    else:
        settings.logger.error("The file or folder %s does not exist", dir_name)


def get_string_version(input_version: float | int | str) -> str:
    """Convert an input version to a string representation.

    Parameters
    ----------
    input_version : float | int | str
        Input version to convert.

    Returns
    -------
    str
        String representation of the input version.
    """
    output_version = input_version
    if isinstance(input_version, float):
        output_version = str(input_version)
        if len(output_version) == 4:
            output_version = "20" + output_version
    elif isinstance(input_version, int):
        output_version = str(input_version)
        output_version = "20{}.{}".format(output_version[:2], output_version[-1])
    elif isinstance(input_version, str):
        if len(input_version) == 3:
            output_version = "20{}.{}".format(input_version[:2], input_version[-1])
        elif len(input_version) == 4:
            output_version = "20" + input_version
    return output_version


def env_path_student(input_version: str) -> str:
    """Get the path of the version environment variable for an AEDT student version.

    Parameters
    ----------
    input_version : str
       AEDT student version.

    Returns
    -------
    str
        Path for the student version environment variable.

    Examples
    --------
    >>> env_path_student("2021.2")
    "C:/Program Files/ANSYSEM/ANSYSEM2021.2/Win64"
    """
    return os.getenv(
        "ANSYSEMSV_ROOT{0}{1}".format(
            get_version_and_release(input_version)[0], get_version_and_release(input_version)[1]
        ),
        "",
    )


def env_value_student(input_version: str) -> str:
    """Get the name of the version environment variable for an AEDT student version.

    Parameters
    ----------
    input_version : str
        AEDT student version.

    Returns
    -------
    str
         Name for the student version environment variable.

    Examples
    --------
    >>> env_value_student("2021.2")
    "ANSYSEMSV_ROOT211"
    """
    return "ANSYSEMSV_ROOT{0}{1}".format(
        get_version_and_release(input_version)[0], get_version_and_release(input_version)[1]
    )


def generate_unique_folder_name(rootname: str | None = None, folder_name: str | None = None) -> str:  # pragma: no cover
    """Generate a new AEDT folder name given a rootname.

    Parameters
    ----------
    rootname : str, optional
        Root name for the new folder. The default is ``None``.
    folder_name : str, optional
        Name for the new AEDT folder if one must be created. The default is ``None``.

    Returns
    -------
    str
    """
    if not rootname:
        if settings.remote_rpc_session:
            rootname = settings.remote_rpc_session_temp_folder
        else:
            rootname = tempfile.gettempdir()
    if folder_name is None:
        folder_name = generate_unique_name("pyedb_prj", n=3)
    temp_folder = os.path.join(rootname, folder_name)
    if settings.remote_rpc_session and not settings.remote_rpc_session.filemanager.pathexists(temp_folder):
        settings.remote_rpc_session.filemanager.makedirs(temp_folder)
    elif not os.path.exists(temp_folder):
        os.makedirs(temp_folder)

    return temp_folder


def generate_unique_project_name(
    rootname: str | None = None,
    folder_name: str | None = None,
    project_name: str | None = None,
    project_format: str = "aedt",
) -> str:
    """Generate a new AEDT project name given a rootname.

    Parameters
    ----------
    rootname : str, optional
        Root name where the new project is to be created. The default is ``None``.
    folder_name : str, optional
        Name of the folder to create. The default is ``None``, in which case a random folder
        is created. Use ``""`` if you do not want to create a subfolder.
    project_name : str, optional
        Name for the project. The default is ``None``, in which case a random project is
        created. If a project with this name already exists, a new suffix is added.
    project_format : str, optional
        Project format. The default is ``"aedt"``. Options are ``"aedt"`` and ``"aedb"``.

    Returns
    -------
    str
    """
    if not project_name:
        project_name = generate_unique_name("Project", n=3)
    name_with_ext = project_name + "." + project_format
    folder_path = generate_unique_folder_name(rootname, folder_name=folder_name)
    prj = os.path.join(folder_path, name_with_ext)
    if check_if_path_exists(prj):
        name_with_ext = generate_unique_name(project_name, n=3) + "." + project_format
        prj = os.path.join(folder_path, name_with_ext)
    return prj


def _retry_ntimes(n: int, function: callable, *args: Any, **kwargs: Any) -> None:
    """Retry a function several times.

    Parameters
    ----------
    n : int
        The number of retries.
    function : function
        Function to retry.
    *args : tuple
        Arguments for the function.
    **kwargs : dict
        Keyword arguments for the function.

    Returns
    -------
    None
    """
    func_name = None
    if function.__name__ == "InvokeAedtObjMethod":
        func_name = args[1]
    retry = 0
    ret_val = None
    inclusion_list = [
        "CreateVia",
        "PasteDesign",
        "Paste",
        "PushExcitations",
        "Rename",
        "RestoreProjectArchive",
        "ImportGerber",
    ]
    # if func_name and func_name not in inclusion_list and not func_name.startswith("Get"):
    if func_name and func_name not in inclusion_list:
        n = 1
    while retry < n:
        try:
            ret_val = function(*args, **kwargs)
        except:
            retry += 1
            time.sleep(settings.retry_n_times_time_interval)
        else:
            return ret_val
    if retry == n:
        if "__name__" in dir(function):
            raise AttributeError("Error in Executing Method {}.".format(function.__name__))
        else:
            raise AttributeError("Error in Executing Method.")


@deprecated("Please use time.perf_counter() or time.process_time() for timing functions.")
def time_fn(fn: callable, *args: Any, **kwargs: Any) -> Any:  # pragma: no cover
    """Time the execution of a function.

    Parameters
    ----------
    fn : callable
        Function to time.
    *args : tuple
        Arguments for the function.
    **kwargs : dict
        Keyword arguments for the function.

    Returns
    -------
    Any
        The result of the function.
    """
    start = datetime.datetime.now()
    results = fn(*args, **kwargs)
    end = datetime.datetime.now()
    fn_name = fn.__module__ + "." + fn.__name__
    delta = (end - start).microseconds * 1e-6
    print(fn_name + ": " + str(delta) + "s")
    return results


@deprecated("Please use math.isclose for comparing floating point numbers.")
def isclose(a: float, b: float, rel_tol: float = 1e-9, abs_tol: float = 0.0) -> bool:
    """Determine whether two floating point numbers are close in value.

    Parameters
    ----------
    a : float
        First number to compare.
    b : float
        Second number to compare.
    rel_tol : float, optional
        Relative tolerance. The default is 1e-9.
    abs_tol : float, optional
        Absolute tolerance. The default is 0.0.

    Returns
    -------
    bool
        ``True`` if the numbers are close, ``False`` otherwise.
    """
    return abs(a - b) <= max(rel_tol * max(abs(a), abs(b)), abs_tol)


def is_number(a: Any) -> bool:
    """Whether the input is a number or a string that can be converted to a number.

    Parameters
    ----------
    a : Any
        Input to check.
    Returns
    -------
    bool
        ``True`` if the input is a number or a string that can be converted to a number, ``False`` otherwise.
    """
    if isinstance(a, float) or isinstance(a, int):
        return True
    elif isinstance(a, str):
        try:
            float(a)
            return True
        except ValueError:
            return False
    else:
        return False


def is_array(a: Any) -> bool:  # pragma: no cover
    """Whether the input is a list or a string that can be converted to a list.

    Parameters
    ----------
    a : Any
        Input to check.

    Returns
    -------
    bool
        ``True`` if the input is a list or a string that can be converted to a list, ``False`` otherwise.
    """
    try:
        v = list(ast.literal_eval(a))
    except (ValueError, TypeError, NameError, SyntaxError):
        return False
    else:
        if type(v) is list:
            return True
        else:
            return False


def is_project_locked(project_path: str) -> bool:
    """Check if an AEDT project lock file exists.

    Parameters
    ----------
    project_path : str
        Path for the AEDT project.

    Returns
    -------
    bool
        ``True`` when successful, ``False`` when failed.
    """
    return check_if_path_exists(project_path + ".lock")


def remove_project_lock(project_path: str) -> bool:  # pragma: no cover
    """Check if an AEDT project exists and try to remove the lock file.

    .. note::
       This operation is risky because the file could be opened in another AEDT instance.

    Parameters
    ----------
    project_path : str
        Path for the AEDT project.

    Returns
    -------
    bool
        ``True`` when successful, ``False`` when failed.
    """
    if os.path.exists(project_path + ".lock"):
        os.remove(project_path + ".lock")
    return True


@deprecated("Please use pandas.read_csv for reading CSV files.")
def read_csv(filename: str, encoding: str = "utf-8") -> list:  # pragma: no cover
    """Read information from a CSV file and return a list.

    Parameters
    ----------
    filename : str
            Full path and name for the CSV file.
    encoding : str, optional
            File encoding for the CSV file. The default is ``"utf-8"``.

    Returns
    -------
    list

    """

    lines = []
    with codecs.open(filename, "rb", encoding) as csvfile:
        reader = csv.reader(csvfile, delimiter=",")
        for row in reader:
            lines.append(row)
    return lines


@deprecated("Please use pandas.read_csv for reading CSV files.")
def read_csv_pandas(filename: str, encoding: str = "utf-8") -> "pd.DataFrame":  # pragma: no cover
    """Read information from a CSV file and return a list.

    Parameters
    ----------
    filename : str
            Full path and name for the CSV file.
    encoding : str, optional
            File encoding for the CSV file. The default is ``"utf-8"``.

    Returns
    -------
    :class:`pandas.DataFrame`

    """
    try:
        import pandas as pd
    except ImportError:
        raise ImportError(
            "Pandas library is required for workflow. "
            "Please install it using 'pip install pyedb[analysis]' or 'pip install pandas'."
        )

    return pd.read_csv(filename, encoding=encoding, header=0, na_values=".")


@deprecated("Please use open() for reading TAB files.")
def read_tab(filename: str) -> list:  # pragma: no cover
    """Read information from a TAB file and return a list.

    Parameters
    ----------
    filename : str
            Full path and name for the TAB file.

    Returns
    -------
    list

    """
    with open(filename) as my_file:
        lines = my_file.readlines()
    return lines


@deprecated("Please use pandas.read_excel for reading XLSX files.")
def read_xlsx(filename: str) -> list:  # pragma: no cover
    """Read information from an XLSX file and return a list.

    Parameters
    ----------
    filename : str
            Full path and name for the XLSX file.

    Returns
    -------
    list

    """
    try:
        import pandas as pd
    except ImportError:
        raise ImportError(
            "Pandas library is required for workflow. "
            "Please install it using 'pip install pyedb[analysis]' or 'pip install pandas'."
        )

    lines = pd.read_excel(filename)
    return lines


@deprecated("Please handle CSV files using the csv module or pandas, depending on your needs.")
def write_csv(
    output: str, list_data: list, delimiter: str = ",", quotechar: str = "|", quoting: int = csv.QUOTE_MINIMAL
) -> bool:  # pragma: no cover
    """Write a list to a CSV file.

    Parameters
    ----------
    output : str
        Full path and name for the output CSV file.
    list_data : list
        List of data to write to the CSV file.
    delimiter : str, optional
        Character to use for separating fields. The default is ``","``.
    quotechar : str, optional
        Character to use for quoting fields. The default is ``"|"``.
    quoting : int, optional
        Control when quotes should be generated by the csv writer.
        The default is ``csv.QUOTE_MINIMAL``.

    Returns
    -------
    bool
        ``True`` when successful, ``False`` when failed.
    """
    f = open(output, "w", newline="")
    writer = csv.writer(f, delimiter=delimiter, quotechar=quotechar, quoting=quoting)
    for data in list_data:
        writer.writerow(data)
    f.close()
    return True


@deprecated("Please handle filtering of your own data.")
def filter_tuple(value: tuple, search_key1: str, search_key2: str) -> bool:  # pragma: no cover
    """Filter a tuple of two elements with two search keywords.

    Parameters
    ----------
    value : tuple
        Tuple to filter.
    search_key1 : str
        First search keyword.
    search_key2 : str
        Second search keyword.

    Returns
    -------
    bool
        ``True`` if the tuple matches the search keywords, ``False`` otherwise.
    """
    ignore_case = True

    def _create_pattern(k1, k2):
        k1a = re.sub(r"\?", r".", k1)
        k1b = re.sub(r"\*", r".*?", k1a)
        k2a = re.sub(r"\?", r".", k2)
        k2b = re.sub(r"\*", r".*?", k2a)
        pattern = r".*\({},{}\)".format(k1b, k2b)
        return pattern

    if ignore_case:
        compiled_re = re.compile(_create_pattern(search_key1, search_key2), re.IGNORECASE)
    else:
        compiled_re = re.compile(_create_pattern(search_key1, search_key2))

    m = compiled_re.search(value)
    if m:
        return True
    return False


@deprecated("Please handle filtering of your own data.")
def filter_string(value: str, search_key1: str) -> bool:  # pragma: no cover
    """Filter a string.

    Parameters
    ----------
    value : str
        String to filter.
    search_key1 : str
        Search keyword.

    Returns
    -------
    bool
        ``True`` if the string matches the search keyword, ``False`` otherwise.
    """
    ignore_case = True

    def _create_pattern(k1):
        k1a = re.sub(r"\?", r".", k1.replace("\\", "\\\\"))
        k1b = re.sub(r"\*", r".*?", k1a)
        pattern = r"^{}$".format(k1b)
        return pattern

    if ignore_case:
        compiled_re = re.compile(_create_pattern(search_key1), re.IGNORECASE)
    else:
        compiled_re = re.compile(_create_pattern(search_key1))  # pragma: no cover

    m = compiled_re.search(value)
    if m:
        return True
    return False


def recursive_glob(startpath: str, filepattern: str) -> list:  # pragma: no cover
    """Get a list of files matching a pattern, searching recursively from a start path.

    Parameters
    ----------
    startpath : str
        Starting path (directory).
    filepattern : str
        Fnmatch-style filename pattern.

    Returns
    -------
    list
        List of matching file paths.
    """
    if settings.remote_rpc_session:
        files = []
        for i in settings.remote_rpc_session.filemanager.listdir(startpath):
            if settings.remote_rpc_session.filemanager.isdir(os.path.join(startpath, i)):
                files.extend(recursive_glob(os.path.join(startpath, i), filepattern))
            elif fnmatch.fnmatch(i, filepattern):
                files.append(os.path.join(startpath, i))
        return files
    else:
        return [
            os.path.join(dirpath, filename)
            for dirpath, _, filenames in os.walk(startpath)
            for filename in filenames
            if fnmatch.fnmatch(filename, filepattern)
        ]


@deprecated("Please handle sorting of your own data.")
def number_aware_string_key(s: str) -> tuple:  # pragma: no cover
    """Get a key for sorting strings that treats embedded digit sequences as integers.

    Parameters
    ----------
    s : str
        String to calculate the key from.

    Returns
    -------
    tuple
        Tuple of key entries.
    """

    def is_digit(c):
        return "0" <= c and c <= "9"

    result = []
    i = 0
    while i < len(s):
        if is_digit(s[i]):
            j = i + 1
            while j < len(s) and is_digit(s[j]):
                j += 1
            key = int(s[i:j])
            result.append(key)
            i = j
        else:
            j = i + 1
            while j < len(s) and not is_digit(s[j]):
                j += 1
            key = s[i:j]
            result.append(key)
            i = j
    return tuple(result)


@deprecated("This function is for internal use only and may be renamed.")
def compute_fft(time_vals: "pd.Series", value: "pd.Series") -> tuple:  # pragma: no cover
    """Compute FFT of input transient data.

    Parameters
    ----------
    time_vals : pandas.Series
        Time values for the transient data.
    value : pandas.Series
        Values for the transient data.

    Returns
    -------
    tuple
        Frequency and Values.
    """
    import numpy as np

    deltaT = time_vals[-1] - time_vals[0]
    num_points = len(time_vals)
    valueFFT = np.fft.fft(value, num_points)
    Npoints = int(len(valueFFT) / 2)
    valueFFT = valueFFT[1 : Npoints + 1]
    valueFFT = valueFFT / len(valueFFT)
    n = np.arange(num_points)
    freq = n / deltaT
    return freq, valueFFT


# NOTE: Not used in pyedb, should this function be removed ?
def parse_excitation_file(
    file_name: str,
    is_time_domain: bool = True,
    x_scale: float = 1,
    y_scale: float = 1,
    impedance: float = 50,
    data_format: str = "Power",
    encoding: str = "utf-8",
    out_mag: str = "Voltage",
) -> tuple[list[float], list[float], list[float]]:  # pragma: no cover
    """Parse a csv file and convert data in list that can be applied to Hfss and Hfss3dLayout sources.

    Parameters
    ----------
    file_name : str
        Full name of the input file.
    is_time_domain : bool, optional
        Either if the input data is Time based or Frequency Based.
        Frequency based data are Mag/Phase (deg). Default is ``True``.
    x_scale : float, optional
        Scaling factor for x axis. Default is ``1``.
    y_scale : float, optional
        Scaling factor for y axis. Default is ``1``.
    impedance : float, optional
        Excitation impedance. Default is ``50``.
    data_format : str, optional
        Either `"Power"`, `"Current"` or `"Voltage"`. Default is ``"Power"``.
    encoding : str, optional
        Csv file encoding. Default is ``"utf-8"``.
    out_mag : str, optional
        Output magnitude format. It can be `"Voltage"` or `"Power"` depending on Hfss solution.
        Default is ``"Voltage"``.

    Returns
    -------
    tuple[list[float], list[float], list[float]]
        Frequency, magnitude and phase.
    """
    import numpy as np

    try:
        import pandas as pd
    except ImportError:
        raise ImportError(
            "Pandas library is required. Please install it using 'pip install pyedb[analysis]' or 'pip install pandas'."
        )

    df = pd.read_csv(file_name, encoding=encoding, header=0, na_values=".")

    if is_time_domain:
        time = df[df.keys()[0]].values * x_scale
        val = df[df.keys()[1]].values * y_scale
        freq, fval = compute_fft(time, val)

        if data_format.lower() == "current":
            if out_mag == "Voltage":
                fval = fval * impedance
            else:
                fval = fval * fval * impedance
        elif data_format.lower() == "voltage":
            if out_mag == "Power":
                fval = fval * fval / impedance
        else:
            if out_mag == "Voltage":
                fval = np.sqrt(fval * impedance)
        mag = list(np.abs(fval))
        phase = [math.atan2(j, i) * 180 / math.pi for i, j in zip(list(fval.real), list(fval.imag))]

    else:
        freq = list(df[df.keys()[0]].values * x_scale)
        if data_format.lower() == "current":
            mag = df[df.keys()[1]].values * df[df.keys()[1]].values * impedance * y_scale * y_scale
        elif data_format.lower() == "voltage":
            mag = df[df.keys()[1]].values * df[df.keys()[1]].values / impedance * y_scale * y_scale
        else:
            mag = df[df.keys()[1]].values * y_scale
        mag = list(mag)
        phase = list(df[df.keys()[2]].values)
    return freq, mag, phase


# NOTE: Not used in pyedb, should this function be removed ?
def tech_to_control_file(tech_path: str, unit: str = "nm", control_path: str | None = None) -> str:  # pragma: no cover
    """Convert a TECH file to an XML file for use in a GDS or DXF import.

    Parameters
    ----------
    tech_path : str
        Full path to the TECH file.
    unit : str, optional
        Tech units. If specified in tech file this parameter will not be used. Default is ``"nm"``.
    control_path : str, optional
        Path for outputting the XML file. Default is ``None``.

    Returns
    -------
    str
        Out xml file.
    """
    result = []
    with open(tech_path) as f:
        vals = list(CSS4_COLORS.values())
        id_layer = 0
        for line in f:
            line_split = line.split()
            if len(line_split) == 5:
                layerID, layer_name, _, elevation, layer_height = line.split()
                x = '      <Layer Color="{}" GDSIIVia="{}" Name="{}" TargetLayer="{}" Thickness="{}"'.format(
                    vals[id_layer],
                    "true" if layer_name.lower().startswith("v") else "false",
                    layerID,
                    layer_name,
                    layer_height,
                )
                x += ' Type="conductor"/>'
                result.append(x)
                id_layer += 1
            elif len(line_split) > 1 and "UNIT" in line_split[0]:
                unit = line_split[1]
    if not control_path:
        control_path = os.path.splitext(tech_path)[0] + ".xml"
    with open(control_path, "w") as f:
        f.write('<?xml version="1.0" encoding="UTF-8" standalone="no" ?>\n')
        f.write('    <c:Control xmlns:c="http://www.ansys.com/control" schemaVersion="1.0">\n')
        f.write("\n")
        f.write('      <Stackup schemaVersion="1.0">\n')
        f.write('        <Layers LengthUnit="{}">\n'.format(unit))
        for res in result:
            f.write(res + "\n")

        f.write("    </Layers>\n")
        f.write("  </Stackup>\n")
        f.write("\n")
        f.write('  <ImportOptions Flatten="true" GDSIIConvertPolygonToCircles="false" ImportDummyNet="true"/>\n')
        f.write("\n")
        f.write("</c:Control>\n")

    return control_path


@deprecated_class()
class PropsManager(object):
    """Class for managing properties of an object."""

    def __getitem__(self, item):  # pragma: no cover
        """Get the `self.props` key value.

        Parameters
        ----------
        item : str
            Key to search
        """
        item_split = item.split("/")
        if len(item_split) == 1:
            item_split = item_split[0].split("__")
        props = self.props
        found_el = []
        matching_percentage = 1
        while matching_percentage >= 0.4:
            for item_value in item_split:
                found_el = self._recursive_search(props, item_value, matching_percentage)
                # found_el = difflib.get_close_matches(item_value, list(props.keys()), 1, matching_percentage)
                if found_el:
                    props = found_el[1][found_el[2]]
                    # props = props[found_el[0]]
            if found_el:
                return props
            else:
                matching_percentage -= 0.02
        self._app.logger.warning("Key %s not found.Check one of available keys in self.available_properties", item)
        return None

    def __setitem__(self, key, value):  # pragma: no cover
        """Set the `self.props` key value.

        Parameters
        ----------
        key : str
            Key to apply.
        value : int, float, bool, str, dict
            Value to apply.
        """
        item_split = key.split("/")
        if len(item_split) == 1:
            item_split = item_split[0].split("__")
        found_el = []
        props = self.props
        matching_percentage = 1
        key_path = []
        while matching_percentage >= 0.4:
            for item_value in item_split:
                found_el = self._recursive_search(props, item_value, matching_percentage)
                if found_el:
                    props = found_el[1][found_el[2]]
                    key_path.append(found_el[2])
            if found_el:
                if matching_percentage < 1:
                    self._app.logger.info(
                        "Key %s matched internal key '%s' with confidence of %s.",
                        key,
                        "/".join(key_path),
                        round(matching_percentage * 100),
                    )
                matching_percentage = 0

            else:
                matching_percentage -= 0.02
        if found_el:
            found_el[1][found_el[2]] = value
            self.update()
        else:
            props[key] = value
            self.update()
            self._app.logger.warning("Key %s not found. Trying to applying new key ", key)

    def _recursive_search(self, dict_in, key="", matching_percentage=0.8):  # pragma: no cover
        f = difflib.get_close_matches(key, list(dict_in.keys()), 1, matching_percentage)
        if f:
            return True, dict_in, f[0]
        else:
            for v in list(dict_in.values()):
                if isinstance(v, (dict, OrderedDict)):
                    out_val = self._recursive_search(v, key, matching_percentage)
                    if out_val:
                        return out_val
                elif isinstance(v, list) and isinstance(v[0], (dict, OrderedDict)):
                    for val in v:
                        out_val = self._recursive_search(val, key, matching_percentage)
                        if out_val:
                            return out_val
        return False

    def _recursive_list(self, dict_in, prefix=""):  # pragma: no cover
        available_list = []
        for k, v in dict_in.items():
            if prefix:
                name = prefix + "/" + k
            else:
                name = k
            available_list.append(name)
            if isinstance(v, (dict, OrderedDict)):
                available_list.extend(self._recursive_list(v, name))
        return available_list

    @property
    def available_properties(self):  # pragma: no cover
        """Available properties.

        Returns
        -------
        list
        """
        if self.props:
            return self._recursive_list(self.props)
        return []

    def update(self):
        """Update method."""
        pass


clamp = lambda n, minn, maxn: max(min(maxn, n), minn)
rgb_color_codes = {
    "Black": (0, 0, 0),
    "Green": (0, 128, 0),
    "White": (255, 255, 255),
    "Red": (255, 0, 0),
    "Lime": (0, 255, 0),
    "Blue": (0, 0, 255),
    "Yellow": (255, 255, 0),
    "Cyan": (0, 255, 255),
    "Magenta": (255, 0, 255),
    "Silver": (192, 192, 192),
    "Gray": (128, 128, 128),
    "Maroon": (128, 0, 0),
    "Olive": (128, 128, 0),
    "Purple": (128, 0, 128),
    "Teal": (0, 128, 128),
    "Navy": (0, 0, 128),
    "copper": (184, 115, 51),
    "stainless steel": (224, 223, 219),
}


@deprecated("Please use pip directly for installing packages.")
def install_with_pip(
    package_name: str, package_path: str | None = None, upgrade: bool = False, uninstall: bool = False
):  # pragma: no cover
    """Install a new package using pip.

    This method is useful for installing a package from the AEDT Console without launching the Python environment.

    .. warning::
        Do not execute this function with untrusted function argument, environment
        variables or pyedb global settings.
        See the :ref:`security guide<ref_security_consideration>` for details.

    Parameters
    ----------
    package_name : str
        Name of the package to install.
    package_path : str, optional
        Path for the GitHub package to download and install. For example, ``git+https://.....``.
    upgrade : bool, optional
        Whether to upgrade the package. The default is ``False``.
    uninstall : bool, optional
        Whether to install the package or uninstall the package. The default is ``False``.
    """
    import subprocess  # nosec B404

    if not package_name or not isinstance(package_name, str):
        raise ValueError("A valid package name must be provided.")

    executable = sys.executable
    commands = []
    if uninstall:
        commands.append([executable, "-m", "pip", "uninstall", "--yes", package_name])
    else:
        if package_path and upgrade:
            commands.append([executable, "-m", "pip", "uninstall", "--yes", package_name])
            command = [executable, "-m", "pip", "install", package_path]
        else:
            command = [executable, "-m", "pip", "install", package_name]
        if upgrade:
            command.append("-U")

        commands.append(command)

    for command in commands:
        try:
            subprocess.run(command, check=True)  # nosec
        except subprocess.CalledProcessError as e:  # nosec
            raise RuntimeError("An error occurred while installing with pip") from e


class Help:  # pragma: no cover
    """Class for opening online help resources for PyEDB."""

    def __init__(self) -> None:
        self._base_path = "https://edb.docs.pyansys.com/version/stable"
        self.browser = "default"

    def _launch_ur(self, url: str) -> None:
        """Launch a URL in the default web browser or a specified browser."""
        import webbrowser

        if self.browser != "default":
            webbrowser.get(self.browser).open_new_tab(url)
        else:
            webbrowser.open_new_tab(url)

    def search(self, keywords: str | list, app_name: str | None = None, search_in_examples_only: bool = False) -> None:
        """Search for one or more keywords.

        Parameters
        ----------
        keywords : str or list
            Keywords to search for.
        app_name : str, optional
            Name of a PyEDB app. The default is ``None``.
        search_in_examples_only : bool, optional
            Whether to search for the one or more keywords only in the PyEDB examples.
            The default is ``False``.
        """
        if isinstance(keywords, str):
            keywords = [keywords]
        if search_in_examples_only:
            keywords.append("This example")
        if app_name:
            keywords.append(app_name)
        url = self._base_path + "/search.html?q={}".format("+".join(keywords))
        self._launch_ur(url)

    def getting_started(self) -> None:
        """Open the PyEDB User guide page."""
        url = self._base_path + "/user_guide/index.html"
        self._launch_ur(url)

    def examples(self) -> None:
        """Open the PyEDB Examples page."""
        url = self._base_path + "/examples/index.html"
        self._launch_ur(url)

    def github(self) -> None:
        """Open the PyEDB GitHub page."""
        url = "https://github.com/ansys/pyedb"
        self._launch_ur(url)

    def changelog(self, release: str | None = None) -> None:
        """Open the PyEDB GitHub Changelog for a given release.

        Parameters
        ----------
        release : str, optional
            Release to get the changelog for. For example, ``"0.6.70"``. The default is ``None``.
        """
        if release is None:
            from pyedb import __version__ as release
        url = "https://github.com/ansys/pyedb/releases/tag/v" + release
        self._launch_ur(url)

    def issues(self) -> None:
        """Open the PyEDB GitHub Issues page."""
        url = "https://github.com/ansys/pyedb/issues"
        self._launch_ur(url)

    def ansys_forum(self) -> None:
        """Open the PyEDB GitHub Issues page."""
        url = "https://discuss.ansys.com/discussions/tagged/pyedb"
        self._launch_ur(url)

    def developer_forum(self) -> None:
        """Open the Discussions page on the Ansys Developer site."""
        url = "https://developer.ansys.com/"
        self._launch_ur(url)


online_help = Help()
