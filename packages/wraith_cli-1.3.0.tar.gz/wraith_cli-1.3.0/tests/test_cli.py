from unittest.mock import ANY, patch

from typer.testing import CliRunner

from wraith_cli.main import app

runner = CliRunner()


def test_version_callback():
    """Test the --version callback."""
    result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    assert "Wraith CLI v" in result.stdout


def test_main_no_command():
    """Test invoking the app with no command to show the welcome screen."""
    with patch("wraith_cli.main.print_wraith_welcome") as mock_welcome:
        result = runner.invoke(app, [])
        assert result.exit_code == 0
        mock_welcome.assert_called_once()


# --- 1. Status Command Tests ---


def test_status_online(monkeypatch):
    """Test status when OpenViking is 200 OK."""
    with patch("requests.get") as mock_get:
        mock_get.return_value.status_code = 200
        result = runner.invoke(app, ["status"])
        assert result.exit_code == 0
        assert "🟢 OpenViking: Online" in result.stdout


def test_status_offline():
    """Test status when OpenViking connection fails."""
    with patch("requests.get") as mock_get:
        mock_get.side_effect = Exception("Connection Refused")
        result = runner.invoke(app, ["status"])
        assert result.exit_code == 0
        assert "🔴 OpenViking: Offline" in result.stdout


def test_status_warning():
    """Test status when OpenViking returns a non-200 status code."""
    with patch("requests.get") as mock_get:
        mock_get.return_value.status_code = 500
        result = runner.invoke(app, ["status"])
        assert result.exit_code == 0
        assert "🟡 OpenViking: Warning (500)" in result.stdout


# --- Update Command Tests ---


@patch("subprocess.run")
@patch("wraith_cli.qol.get_latest_version")
@patch("wraith_cli.main.get_local_version")
def test_update_new_version(mock_local, mock_remote, mock_run):
    """Test update when a new version is available."""
    mock_local.return_value = "0.1.0"
    mock_remote.return_value = "0.2.0"
    result = runner.invoke(app, ["update"])
    assert result.exit_code == 0
    assert "✨ New version available: 0.2.0 (Local: 0.1.0)" in result.stdout
    mock_run.assert_called_with(["uv", "tool", "upgrade", "wraith-cli"])


@patch("wraith_cli.qol.get_latest_version")
@patch("wraith_cli.main.get_local_version")
def test_update_already_current(mock_local, mock_remote):
    """Test update when the tool is already up to date."""
    mock_local.return_value = "0.2.0"
    mock_remote.return_value = "0.2.0"
    result = runner.invoke(app, ["update"])
    assert result.exit_code == 0
    assert "✅ Wraith is up to date (v0.2.0)" in result.stdout


@patch("wraith_cli.qol.get_latest_version")
def test_update_failure(mock_remote):
    """Test update when there's an error checking the version."""
    mock_remote.side_effect = Exception("Network Error")
    result = runner.invoke(app, ["update"])
    assert result.exit_code == 0
    assert "❌ Update check failed: Network Error" in result.stdout


# --- 2. PS Command Tests for Docker processes ---


@patch("subprocess.run")
def test_ps_standard(mock_run):
    """Test the standard ps output format."""
    result = runner.invoke(app, ["ps"])
    assert result.exit_code == 0

    # Get the actual list of arguments passed to subprocess.run
    args = mock_run.call_args[0][0]

    # Join them into one string so we can check for substrings
    full_command = " ".join(args)

    assert "docker" in full_command
    assert "{{.Image}}" in full_command


@patch("subprocess.run")
def test_ps_docker_error(mock_run):
    """Test ps command when Docker is not running."""
    mock_run.return_value.returncode = 1
    result = runner.invoke(app, ["ps"])
    assert result.exit_code == 0
    assert "❌ Docker is not running or accessible." in result.stdout


@patch("subprocess.run")
def test_ps_all_flag(mock_run):
    """Test the simple/project ps output format."""
    result = runner.invoke(app, ["ps", "--all"])
    assert result.exit_code == 0

    args = mock_run.call_args[0][0]
    full_command = " ".join(args)

    assert "-a" in full_command


# --- Tail Command Tests ---


@patch("wraith_cli.qol.run_tail")
def test_tail_success(mock_run_tail, tmp_path):
    """Test tail command with a path argument."""
    mock_run_tail.return_value = True
    result = runner.invoke(app, ["tail", "gitea", "--path", str(tmp_path)])
    assert result.exit_code == 0
    assert f"🔍 Searching for gitea in {tmp_path}..." in result.stdout
    mock_run_tail.assert_called_with("gitea", tmp_path)


@patch("wraith_cli.qol.run_tail")
def test_tail_failure(mock_run_tail):
    """Test tail command when docker-compose.yml is not found."""
    mock_run_tail.return_value = False
    result = runner.invoke(app, ["tail", "gitea"])
    assert result.exit_code == 1
    assert "No docker-compose.yml found" in result.stdout


# --- 3. Runner Reset Tests ---


def test_runner_reset_no_env(monkeypatch):
    """Test safety check when env var is missing."""
    # We patch the global GITEA_PATH in the module
    with patch("wraith_cli.main.GITEA_PATH", None):
        result = runner.invoke(app, ["runner-reset"])
        assert result.exit_code == 1
        assert "GITEA_COMPOSE_PATH not set" in result.stdout


@patch("wraith_cli.main.Path.exists")
def test_runner_reset_no_compose(mock_exists):
    """Test failure when directory exists but docker-compose.yml doesn't."""
    with patch("wraith_cli.main.GITEA_PATH", "/tmp/fake-path"):
        # First check (docker_file.exists) returns False
        mock_exists.return_value = False
        result = runner.invoke(app, ["runner-reset"])
        assert result.exit_code == 1
        assert "❌ Compose file not found" in result.stdout


@patch("subprocess.run")
@patch("wraith_cli.main.Path.exists")
def test_runner_reset_success(mock_exists, mock_run):
    """Test full successful reset flow."""
    with patch("wraith_cli.main.GITEA_PATH", "/tmp/fake-path"):
        # Mocking Path.exists to return True for both the yaml and .runner file
        mock_exists.return_value = True

        result = runner.invoke(app, ["runner-reset"])

        assert result.exit_code == 0
        assert "🚀 Restarting Runner..." in result.stdout
        # Verify subprocess was called for stop, rm, and up
        assert mock_run.call_count >= 2


# --- Test: Spawn Command Success ---
@patch("wraith_cli.main.GITEA_API_URL", "https://fake-gitea")
@patch("wraith_cli.main.GITEA_TOKEN", "fake_token")
@patch("wraith_cli.main.GITEA_TEMPLATE_URL", "https://fake-gitea/template.git")
@patch("wraith_cli.repo_make.clone_and_bleach")
@patch("wraith_cli.repo_make.create_gitea_repo")
@patch("wraith_cli.repo_make.init_and_push")
def test_spawn_success(mock_init, mock_create, mock_clone):
    # Setup mock returns - simulating the HTTPS URL returned by the API
    mock_create.return_value = "https://fake-gitea/new/repo.git"

    # Simulate user running: wraith spawn my-new-api
    result = runner.invoke(app, ["spawn", "my-new-api"])

    # Assertions
    assert result.exit_code == 0
    assert "Success!" in result.stdout
    assert "my-new-api" in result.stdout

    # Verify our Engine Room was called with the right arguments
    # This includes the token, silly!
    # We use ANY for the path because it's a dynamic Path object
    mock_clone.assert_called_once_with(
        "https://fake-gitea/template.git", ANY, "fake_token"
    )
    mock_create.assert_called_once_with(
        "my-new-api", "https://fake-gitea", "fake_token"
    )
    mock_init.assert_called_once_with(
        ANY, "https://fake-gitea/new/repo.git", "fake_token"
    )


@patch("wraith_cli.main.GITEA_API_URL", "https://fake-gitea")
@patch("wraith_cli.main.GITEA_TOKEN", "fake_token")
@patch("wraith_cli.main.GITEA_TEMPLATE_URL", "https://fake-gitea/template.git")
@patch("wraith_cli.repo_make.clone_and_bleach")
def test_spawn_file_exists_error(mock_clone):
    """Test spawn command when the target directory already exists."""
    mock_clone.side_effect = FileExistsError(
        "Directory 'test-repo' already exists."
    )
    result = runner.invoke(app, ["spawn", "test-repo"])
    assert result.exit_code == 1
    assert "❌ Error: Directory 'test-repo' already exists." in result.stdout


@patch("wraith_cli.main.GITEA_API_URL", "https://fake-gitea")
@patch("wraith_cli.main.GITEA_TOKEN", "fake_token")
@patch("wraith_cli.main.GITEA_TEMPLATE_URL", "https://fake-gitea/template.git")
@patch("wraith_cli.repo_make.clone_and_bleach")
@patch("wraith_cli.repo_make.create_gitea_repo")
def test_spawn_critical_failure(mock_create, mock_clone):
    """Test spawn command with a generic critical failure."""
    # This test will have mock_clone run successfully
    # then mock_create will fail.
    mock_create.side_effect = Exception("API is down")
    result = runner.invoke(app, ["spawn", "test-repo"])
    assert result.exit_code == 1
    assert "❌ Critical Failure: API is down" in result.stdout


# --- Test: Spawn Command Missing Env Vars ---
# We patch the variables in main.py to None to trigger the error check
@patch("wraith_cli.main.GITEA_API_URL", None)
@patch("wraith_cli.main.GITEA_TOKEN", None)
@patch("wraith_cli.main.GITEA_TEMPLATE_URL", None)
def test_spawn_missing_env_vars():
    result = runner.invoke(app, ["spawn", "my-new-api"])

    # Should fail and exit gracefully
    assert result.exit_code == 1
    assert "Missing Environment Variables" in result.stdout


# --- Shield Command Tests ---


@patch("wraith_cli.shield.get_scrutiny_health")
def test_logs_health(mock_health):
    """Test logs command with --health flag."""
    result = runner.invoke(app, ["logs", "--health"])
    assert result.exit_code == 0
    assert "Polling Bare-Metal SMART data via Scrutiny" in result.stdout
    mock_health.assert_called_once()


def test_logs_default():
    """Test logs command with no flags."""
    result = runner.invoke(app, ["logs"])
    assert result.exit_code == 0
    assert "Use 'wraith tail <service>'" in result.stdout


@patch("wraith_cli.shield.get_tailscale_mesh")
def test_mesh(mock_mesh):
    """Test the mesh command."""
    result = runner.invoke(app, ["mesh"])
    assert result.exit_code == 0
    assert "Querying Ghost Mesh (Tailscale)..." in result.stdout
    mock_mesh.assert_called_once()


@patch("wraith_cli.shield.run_security_audit")
def test_audit(mock_audit):
    """Test the audit command."""
    result = runner.invoke(app, ["audit"])
    assert result.exit_code == 0
    assert "Initiating Sovereign Security Audit..." in result.stdout
    mock_audit.assert_called_once()
