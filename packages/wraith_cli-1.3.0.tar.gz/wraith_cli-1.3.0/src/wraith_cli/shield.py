import json
import os
import subprocess
import requests
from rich.table import Table

# Pull from .env, fallback to the Ghost Stack default port
SCRUTINY_URL = os.getenv("SCRUTINY_URL", "http://127.0.0.1:8090")

def get_scrutiny_health() -> Table:
    """Fetches SMART data from the Scrutiny API and formats it.

    Returns:
        Table: A rich Table object containing device health information.
    """
    table = Table(
        title="Scrutiny SMART Health",
        border_style="bright_black",
        header_style="bold green",
    )
    table.add_column("Device")
    table.add_column("Capacity")
    table.add_column("Temp")
    table.add_column("Status")

    try:
        # Scrutiny summary API endpoint
        response = requests.get(f"{SCRUTINY_URL}/api/summary", timeout=5)
        response.raise_for_status()
        data = response.json()
        
        devices = data.get("data", {}).get("summary", {})
        if not devices:
            table.add_row("No devices found.", "-", "-", "-")
            return table

        for wwn, device in devices.items():
            name = device.get("device", {}).get("name", "Unknown")
            capacity_bytes = device.get("device", {}).get("capacity", 0)
            capacity_tb = f"{(capacity_bytes / (10**12)):.1f} TB" if capacity_bytes else "Unknown"
            
            temp = str(device.get("smart", {}).get("temp", "N/A")) + "°C"
            status = device.get("smart", {}).get("status", "Unknown")
            
            # Sovereign styling for status
            status_color = "green" if status.lower() == "passed" else "red"
            formatted_status = f"[{status_color}]{status.upper()}[/{status_color}]"
            
            table.add_row(name, capacity_tb, temp, formatted_status)
            
    except requests.exceptions.RequestException as e:
        table.add_row(f"[red]API Error: {e}[/red]", "-", "-", "-")

    return table


def get_tailscale_mesh() -> Table:
    """Pulls Tailscale status via JSON and formats active peers.

    Returns:
        Table: A rich Table object containing Tailscale mesh peer status.
    """
    table = Table(
        title="Ghost Mesh (Tailscale)",
        border_style="bright_black",
        header_style="bold green",
    )
    table.add_column("Hostname")
    table.add_column("Tailscale IP")
    table.add_column("OS")
    table.add_column("Status")

    try:
        result = subprocess.run(
            ["tailscale", "status", "--json"],
            capture_output=True,
            text=True,
            check=True,
        )
        data = json.loads(result.stdout)
        
        peers = data.get("Peer", {})
        for peer_id, peer_data in peers.items():
            hostname = peer_data.get("HostName", "Unknown")
            ip = peer_data.get("TailscaleIPs", ["Unknown"])[0]
            os_name = peer_data.get("OS", "Unknown")
            is_online = peer_data.get("Online", False)

            status_str = (
                "[green]Online[/green]"
                if is_online
                else "[bright_black]Offline[/bright_black]"
            )

            table.add_row(hostname, ip, os_name, status_str)
            
    except Exception as e:
        table.add_row(f"[red]Mesh Error: {e}[/red]", "-", "-", "-")

    return table


def run_security_audit() -> Table:
    """Checks for containers running as root or highly exposed ports.

    Returns:
        Table: A rich Table object with security audit results.
    """
    table = Table(
        title="Sovereign Security Audit",
        border_style="bright_black",
        header_style="bold green",
    )
    table.add_column("Container")
    table.add_column("User")
    table.add_column("Exposed Ports")
    table.add_column("Verdict")

    try:
        # Get all running container IDs
        ps_result = subprocess.run(
            ["docker", "ps", "-q"],
            capture_output=True,
            text=True,
            check=True,
        )
        container_ids = [cid for cid in ps_result.stdout.split("\n") if cid]

        if not container_ids:
            table.add_row("No running containers.", "-", "-", "-")
            return table

        # Inspect all at once
        inspect_result = subprocess.run(
            ["docker", "inspect"] + container_ids,
            capture_output=True,
            text=True,
            check=True,
        )
        containers = json.loads(inspect_result.stdout)

        for c in containers:
            name = c["Name"].lstrip("/")
            
            # Check User
            user = c["Config"].get("User", "")
            if not user or user == "0" or user == "root":
                user_disp = "[red]ROOT[/red]"
                is_root = True
            else:
                user_disp = f"[green]{user}[/green]"
                is_root = False
                
            # Check Ports (Simplified: grabs bindings)
            ports = c["NetworkSettings"].get("Ports", {})
            exposed = []
            for port, bindings in ports.items():
                if bindings:
                    for b in bindings:
                        host_ip = b.get("HostIp", "")
                        host_port = b.get("HostPort", "")
                        # Flag if exposed globally (0.0.0.0) vs. locally.
                        if host_ip == "0.0.0.0" or host_ip == "":
                            exposed.append(
                                f"[yellow]{host_port}->{port} (Global)[/yellow]"
                            )
                        else:
                            exposed.append(f"{host_port}->{port}")
            
            port_disp = ", ".join(exposed) if exposed else "Internal Only"
            
            # Determine Verdict
            if is_root and "Global" in port_disp:
                verdict = "[red]CRITICAL: Root + Global Port[/red]"
            elif is_root:
                verdict = "[yellow]WARNING: Root Context[/yellow]"
            elif "Global" in port_disp:
                verdict = "[yellow]WARNING: Global Exposure[/yellow]"
            else:
                verdict = "[green]SECURE[/green]"

            table.add_row(name, user_disp, port_disp, verdict)

    except Exception as e:
        table.add_row(f"[red]Audit Error: {e}[/red]", "-", "-", "-")

    return table
