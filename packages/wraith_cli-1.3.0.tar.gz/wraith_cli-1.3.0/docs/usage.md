# 📖 Operational Usage Guide

**Wraith** is designed to be intuitive and fast. Make a coffee, grab a Hob-Nob, and put down your glass rectangle — it's time to orchestrate.

---

## 🕹️ Core Commands

### 1. The Global Manifest

To see all available commands, options, and the Sovereign splash screen:

```bash
wraith --help
```

### 2. The Ghost Factory (Scaffolding)

This is the flagship feature. Instead of manual setup, we spawn. This command clones your template, bleaches the history, provisions a Gitea repo, and pushes the initial commit in one atomic action.

```bash
wraith spawn <project-name>
```

> **Pro Tip:** Ensure your `GITEA_TOKEN` is set in your `.env` to avoid the manual
> password hang.

### 3. Stack Observability

Monitor your Sovereign containers without leaving the terminal.

- **Process List:** `wraith ps` — Shows names, status, and images in Sovereign Dark style.
- **Live Logs:** `wraith tail <service-name>` — Tails logs for a specific container.
- **Heartbeat:** `wraith status` — Checks if the OpenViking API is responding.

---

## 🛠️ Maintenance & Defence

### 🔄 Staying Current

Wraith is self-aware. To check for updates on PyPI and upgrade via `uv`:

```bash
wraith update
```

### 🧹 Runner Recovery

If a Gitea Action Runner hangs or goes "Offline" in the UI, use the nuclear option to wipe its registration and restart the service:

```bash
wraith runner-reset
```

> *Note: Requires `GITEA_COMPOSE_PATH` to be defined.*

---

## 🔐 Configuration

Wraith prioritises environment variables for security. You can define these in a `.env` file in your project root or your global shell profile.

| Variable               | Description                                          | Required For   |
|------------------------|------------------------------------------------------|----------------|
| `GITEA_API_URL`        | Your Gitea instance (e.g., `https://git.domain.com`) | `spawn`        |
| `GITEA_TOKEN`          | Your Personal Access Token (PAT)                     | `spawn`        |
| `GITEA_TEMPLATE_URL`   | HTTPS URL of your source `ghost-template`            | `spawn`        |
| `WRAITH_COMPOSE_PATH`  | Path to your main stack directory                    | `ps`, `tail`   |
| `VIKING_BASE_URL`      | Heartbeat monitoring endpoint                        | `status`       |

---

## ⌨️ Advanced Flags

| Flag                                    | Description                              |
|-----------------------------------------|------------------------------------------|
| `wraith --version`                      | Print the current installed version.     |
| `wraith ps --all`                       | Show all containers, including stopped.  |
| `wraith tail <svc> --path /custom/path` | Override the default Compose path.       |
