from typing import Any, Dict


class Payins:
    """Create and manage payins (payment requests)."""

    def __init__(self, client):
        self._client = client

    def create(
        self,
        amount: str,
        external_ref: str = None,
        expires_in_seconds: int = None,
        metadata: Dict[str, Any] = None,
        success_url: str = None,
        cancel_url: str = None,
        sandbox: bool = False,
        payment_method: str = None,
        currency: str = None,
        customer_name: str = None,
        customer_email: str = None,
        customer_phone: str = None,
        operator_code: str = None,
    ) -> dict:
        """
        Create a new payin (payment request).

        Args:
            amount: Amount (USDT for crypto; multiples of 5 XOF for CARD / MOBILE_MONEY)
            external_ref: Your internal order/reference ID
            expires_in_seconds: Custom expiry in seconds (minimum 900)
            metadata: Arbitrary metadata stored with the payin
            success_url: URL to redirect customer after confirmed payment
            cancel_url: URL to redirect customer if payment expires
            sandbox: Set to True for test mode
            payment_method: "USDT_TRC20" (default), "CARD" (hosted card
                payment), or "MOBILE_MONEY" (payin sans redirection)
            currency: "USDT_TRC20", "XOF", "USD", or "EUR"
            customer_name: Customer full name
            customer_email: Customer email address
            customer_phone: Customer phone (E.164). Required for MOBILE_MONEY.
            operator_code: Override the mobile-money operator detected from
                the phone prefix (e.g. "ORANGE_BF", "MTN_CI"). Ignored for
                non-MOBILE_MONEY rails.

        Returns:
            Dict with transactionId, amount, status, paymentMethod and —
            depending on rail — one of:
              USDT_TRC20:   address, qrCodeUrl, paymentUrl
              CARD:         hostedPaymentUrl
              MOBILE_MONEY: nextStep ("otp" | "approval"), operatorCode,
                            instruction ({fr, en})
        """
        body = {"amount": amount}
        if external_ref is not None:
            body["externalRef"] = external_ref
        if expires_in_seconds is not None:
            body["expiresInSeconds"] = expires_in_seconds
        if metadata is not None:
            body["metadata"] = metadata
        if success_url is not None:
            body["successUrl"] = success_url
        if cancel_url is not None:
            body["cancelUrl"] = cancel_url
        if payment_method is not None:
            body["paymentMethod"] = payment_method
        if currency is not None:
            body["currency"] = currency
        if customer_name is not None:
            body["customerName"] = customer_name
        if customer_email is not None:
            body["customerEmail"] = customer_email
        if customer_phone is not None:
            body["customerPhone"] = customer_phone
        if operator_code is not None:
            body["operatorCode"] = operator_code

        params = {"sandbox": "true"} if sandbox else None
        res = self._client.post("/payments", json=body, params=params)
        return res["data"]

    def get(self, payin_id: str) -> dict:
        """
        Get a payin by ID.

        Returns:
            Dict with id, address, amount, amountReceived, status, paymentUrl, etc.
        """
        res = self._client.get(f"/payments/{payin_id}")
        return res["data"]

    def list(
        self,
        page: int = None,
        limit: int = None,
        status=None,
        currency: str = None,
        cursor: str = None,
        sort: str = None,
        from_date: str = None,
        to_date: str = None,
    ) -> dict:
        """
        List payins with optional filters.

        Args:
            status: Filter by status (e.g. "CONFIRMED") or list of statuses
            currency: Filter by currency (e.g. "USDT_TRC20")
            cursor: Cursor for pagination
            sort: Sort order (e.g. "createdAt:desc")
            from_date: Start date (ISO 8601)
            to_date: End date (ISO 8601)

        Returns:
            Dict with "items" (list) and "total" (int).
        """
        status_value = ",".join(status) if isinstance(status, list) else status
        params = {"page": page, "limit": limit, "status": status_value, "currency": currency}
        if cursor:
            params["cursor"] = cursor
        if sort:
            params["sort"] = sort
        if from_date:
            params["from"] = from_date
        if to_date:
            params["to"] = to_date
        res = self._client.get("/payments", params=params)
        return res["data"]

    def simulate(self, payin_id: str) -> dict:
        """Simulate payin confirmation (sandbox only)."""
        res = self._client.post(f"/sandbox/payments/{payin_id}/simulate")
        return res["data"]

    def submit_otp(self, payin_id: str, otp: str) -> dict:
        """
        Submit the OTP a customer received by SMS for a MOBILE_MONEY pay-in
        created on an OTP-mode operator (Orange Money BF, Orange Money CI).
        Call this after create() returns nextStep == "otp".

        Args:
            payin_id: Transaction id returned by create().
            otp: 4-8 digit code the customer received by SMS.

        Returns:
            Dict with transactionId and status (always AWAITING_PAYMENT;
            the final CONFIRMED arrives via webhook).
        """
        res = self._client.post(f"/payins/{payin_id}/submit-otp", json={"otp": otp})
        return res["data"]
