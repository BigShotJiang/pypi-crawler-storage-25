"""Text injection into terminal."""
