"""Audio capture and processing."""
