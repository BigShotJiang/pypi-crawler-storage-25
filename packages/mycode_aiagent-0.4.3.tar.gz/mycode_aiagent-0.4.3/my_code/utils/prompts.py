STYLE_EXTRACTION_PROMPT = """\
You are a code style analyst. Analyze the following Python source file and return a JSON object describing its style. Be precise and concise.

Return ONLY valid JSON with this exact schema:
{{
  "naming": {{
    "functions": "<snake_case|camelCase|PascalCase|other>",
    "classes": "<snake_case|camelCase|PascalCase|other>",
    "variables": "<snake_case|camelCase|PascalCase|other>",
    "constants": "<UPPER_SNAKE_CASE|other>",
    "notes": "<any notable patterns, e.g. verb_noun for functions, single-letter loop vars, etc.>"
  }},
  "structure": {{
    "import_style": "<grouped|flat|alphabetical|none>",
    "class_method_order": "<init_first|alphabetical|public_then_private|none>",
    "preferred_length": "<short|medium|long>",
    "module_layout": "<description of top-level ordering>"
  }},
  "comments": {{
    "docstring_style": "<Google|NumPy|reStructuredText|plain|none>",
    "inline_density": "<sparse|moderate|heavy|none>",
    "docstring_sections": [<list of sections used, e.g. "Args", "Returns", "Raises", "Example">]
  }},
  "representative_snippets": [<1-3 short verbatim code snippets that best show the style>]
}}

Source file ({filename}):
```python
{source}
```
"""

STYLE_MERGE_PROMPT = """\
You are a code style analyst. Update the current style profile by merging in a new file observation.

Rules:
- Where they agree, keep the value.
- Where they disagree, pick the more consistent value.
- Keep representative_snippets to the 3 best examples total.
- Return ONLY valid JSON using the same schema.

Current profile:
{profile}

New observation ({filename}):
{observation}
"""

CODE_GENERATION_PROMPT = """\
You are an expert Python developer. Write code that matches the style profile below exactly.

Style profile:
{style_profile}

Task:
{task}

Rules:
- Match naming conventions, docstring style, and comment density from the profile exactly.
- Follow the module and class structure patterns.
- Use the representative snippets as a style reference.
- Return ONLY the Python code, no explanation.
"""
