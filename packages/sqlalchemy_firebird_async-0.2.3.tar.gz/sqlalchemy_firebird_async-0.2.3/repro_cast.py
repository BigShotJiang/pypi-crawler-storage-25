import firebird.driver as driver
import os

user = os.environ.get("ISC_USER", "sysdba")
password = os.environ.get("ISC_PASSWORD", "masterkey")
host = os.environ.get("ISC_HOST", "localhost")
database = os.environ.get("ISC_DATABASE", "/tmp/test.fdb")

dsn = f"{host}:{database}"

print(f"Connecting to {dsn} with user {user}...")

try:
    con = driver.connect(dsn, user=user, password=password)
    cur = con.cursor()
    
    # Test CAST with TIMESTAMP(6)
    sql = "SELECT CAST('2023-01-01 10:00:00' AS TIMESTAMP(6)) FROM RDB$DATABASE"
    print(f"Executing: {sql}")
    cur.execute(sql)
    print("Success!")
    
    con.close()
except Exception as e:
    print(f"Failed: {e}")