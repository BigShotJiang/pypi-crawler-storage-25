# midiano
## Comprehensive Python package for MIDI music anomalies detection and features analysis

***

## Installation

```sh
!pip install midiano
```

***

## Use as follows

```python
...
```

***

## Attribution

* midicap was passionately vibe-coded with [Z AI](https://chat.z.ai/)
* Artwork is a courtesy of [Microsoft Copilot](https://copilot.microsoft.com/) 

***

### Project Los Angeles
### Tegridy Code 2026
