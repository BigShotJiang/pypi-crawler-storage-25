"""SDK exceptions."""

from __future__ import annotations

from .types import HTTPValidationError


class APIError(Exception):
    """Raised when the API returns a non-2xx status code."""

    def __init__(self, status_code: int, detail: str) -> None:
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"HTTP {status_code}: {detail}")


class NotFoundError(APIError):
    """Raised on HTTP 404."""

    def __init__(self, detail: str = "Not found") -> None:
        super().__init__(404, detail)


class ValidationError(APIError):
    """Raised on HTTP 422 with structured validation errors."""

    def __init__(self, errors: HTTPValidationError) -> None:
        self.errors = errors
        messages = "; ".join(f"{'.'.join(str(l) for l in e.loc)}: {e.msg}" for e in errors.detail)
        super().__init__(422, messages or "Validation error")
