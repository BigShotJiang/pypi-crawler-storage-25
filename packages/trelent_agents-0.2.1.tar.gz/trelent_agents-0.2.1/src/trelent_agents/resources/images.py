"""Images resource."""

from __future__ import annotations

from .._base import BaseResource
from ..types import RegistryImage

_SCOPE_LIST = "AgentOrchestrator:images:list"


class ImagesResource(BaseResource):

    def list(self) -> list[RegistryImage]:
        resp = self._get("/images", scope=_SCOPE_LIST)
        return [RegistryImage.model_validate(i) for i in resp.json()]
