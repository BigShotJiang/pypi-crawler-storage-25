"""Agents resource."""

from __future__ import annotations

from .._base import BaseResource
from ..types import Agent, AgentCreate


class AgentsResource(BaseResource):

    def register(self, image: str) -> Agent:
        body = AgentCreate(image=image)
        resp = self._session.post(self._url("/agents"), data=body.model_dump_json())
        self._raise_for_status(resp)
        return Agent.model_validate(resp.json())

    def list(self, image: str | None = None) -> list[Agent]:
        params = {}
        if image is not None:
            params["image"] = image
        resp = self._session.get(self._url("/agents"), params=params)
        self._raise_for_status(resp)
        return [Agent.model_validate(a) for a in resp.json()]

    def get(self, agent_id: str) -> Agent:
        resp = self._session.get(self._url(f"/agents/{agent_id}"))
        self._raise_for_status(resp)
        return Agent.model_validate(resp.json())

    def get_by_image(self, image: str) -> Agent | None:
        agents = self.list(image=image)
        return agents[0] if agents else None
