class BanterError(Exception):
    pass


class HTTPException(BanterError):

    def __init__(self, status, code, message, method="", path=""):
        self.status = status
        self.code = code
        self.message = message
        self.method = method
        self.path = path
        if method and path:
            super().__init__(f"{method} {path} -> {status} {code}: {message}")
        else:
            super().__init__(f"{status} {code}: {message}")


class Forbidden(HTTPException):
    pass


class NotFound(HTTPException):
    pass


class RateLimited(HTTPException):

    def __init__(self, status, code, message, retry_after, method="", path=""):
        super().__init__(status, code, message, method=method, path=path)
        self.retry_after = retry_after


class GatewayError(BanterError):
    pass


class LoginFailure(BanterError):
    pass


class MissingPermissions(BanterError):

    def __init__(self, missing):
        self.missing = missing
        names = ", ".join(missing) if missing else "unknown"
        super().__init__(f"Missing permissions: {names}")