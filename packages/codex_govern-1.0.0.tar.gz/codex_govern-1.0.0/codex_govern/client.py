"""
codex-govern — Drop-in AI governance SDK for Python.

Usage:
    from codex_govern import CodexGovern

    govern = CodexGovern(
        base_url="https://codexdominion-api-718436124481.us-central1.run.app",
        token="your-jwt-token",
    )

    result = govern.chat(
        messages=[{"role": "user", "content": "Summarize this report."}],
    )

    print(result["choices"][0]["message"]["content"])   # AI response
    print(result["governance"]["live"])                 # True = real model call
    print(result["governance"]["checksumSha256"])       # SHA-256 evidence hash
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

import requests


class CodexGovernError(Exception):
    """Error from the CodexDominion Governance Gateway."""

    def __init__(self, message: str, status: int, body: Any = None):
        super().__init__(message)
        self.status = status
        self.body = body


class CodexGovern:
    """
    Drop-in AI governance client.

    Routes AI calls through the CodexDominion Governance Gateway:
    Policy evaluation → Model execution → Evidence generation → Audit trail.
    """

    def __init__(
        self,
        base_url: str,
        token: str,
        default_model: str = "gpt-4o-mini",
        default_mission: str = "CHAT_COMPLETION",
        timeout: int = 30,
    ):
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.default_model = default_model
        self.default_mission = default_mission
        self.timeout = timeout
        self._session = requests.Session()
        self._session.headers.update(
            {
                "Content-Type": "application/json",
            }
        )

    # ─── Core: Governed Chat ──────────────────────────────────────────────

    def chat(
        self,
        messages: List[Dict[str, str]],
        model: Optional[str] = None,
        mission: Optional[str] = None,
        provider: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Send a governed chat completion request.

        Routes through: Policy Engine → Model Execution → Evidence Generation.

        Args:
            messages: List of chat messages [{"role": "user", "content": "..."}]
            model: Model identifier (default: gpt-4o-mini)
            mission: Mission type for governance classification
            provider: Provider override (auto-detected from model if omitted)
            temperature: Temperature (0-2)
            max_tokens: Max tokens for response
            metadata: Additional metadata for the governance record

        Returns:
            Governed chat response with choices, usage, and governance metadata.
        """
        payload: Dict[str, Any] = {
            "model": model or self.default_model,
            "messages": messages,
            "mission": mission or self.default_mission,
        }
        if provider is not None:
            payload["provider"] = provider
        if temperature is not None:
            payload["temperature"] = temperature
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens
        if metadata is not None:
            payload["metadata"] = metadata

        return self._post("/api/v1/gateway/governed/chat", payload)

    # ─── Convenience: Quick Ask ───────────────────────────────────────────

    def ask(
        self,
        prompt: str,
        model: Optional[str] = None,
        mission: Optional[str] = None,
        system_prompt: Optional[str] = None,
    ) -> str:
        """
        Quick governed chat — pass a prompt string, get the response string.

        Args:
            prompt: User prompt
            model: Model identifier
            mission: Mission type
            system_prompt: Optional system prompt

        Returns:
            The assistant's response content.
        """
        messages: List[Dict[str, str]] = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        result = self.chat(messages=messages, model=model, mission=mission)
        return result["choices"][0]["message"]["content"]

    # ─── Gateway Info ─────────────────────────────────────────────────────

    def stats(self) -> Dict[str, Any]:
        """Get gateway traffic statistics."""
        return self._get("/api/v1/gateway/stats")

    def models(self) -> List[Dict[str, Any]]:
        """Get available models and their live/simulated status."""
        return self._get("/api/v1/gateway/models")

    def requests(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Get recent gateway requests."""
        return self._get(f"/api/v1/gateway/requests?limit={limit}")

    # ─── Auth ─────────────────────────────────────────────────────────────

    def set_token(self, token: str) -> None:
        """Update the auth token."""
        self.token = token

    def login(self, email: str, password: str) -> Dict[str, Any]:
        """
        Login and store the token automatically.

        Returns:
            Auth response with accessToken and user info.
        """
        result = self._post(
            "/api/v1/auth/login",
            {"email": email, "password": password},
        )
        self.token = result["accessToken"]
        return result

    # ─── Internal ─────────────────────────────────────────────────────────

    def _get(self, path: str) -> Any:
        resp = self._session.get(
            f"{self.base_url}{path}",
            headers={"Authorization": f"Bearer {self.token}"},
            timeout=self.timeout,
        )
        if not resp.ok:
            raise CodexGovernError(
                f"{resp.status_code} {resp.reason}",
                resp.status_code,
                resp.text,
            )
        return resp.json()

    def _post(self, path: str, body: Any) -> Any:
        resp = self._session.post(
            f"{self.base_url}{path}",
            headers={"Authorization": f"Bearer {self.token}"},
            json=body,
            timeout=self.timeout,
        )
        if not resp.ok:
            raise CodexGovernError(
                f"{resp.status_code} {resp.reason}",
                resp.status_code,
                resp.text,
            )
        return resp.json()
