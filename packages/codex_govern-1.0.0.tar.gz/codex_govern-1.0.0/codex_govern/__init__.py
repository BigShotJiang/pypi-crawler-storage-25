"""
codex-govern — Govern any AI call in 2 lines.
Drop-in governance for OpenAI, Anthropic, Google, and any LLM.
"""

from codex_govern.client import CodexGovern, CodexGovernError

__all__ = ["CodexGovern", "CodexGovernError"]
__version__ = "1.0.0"
