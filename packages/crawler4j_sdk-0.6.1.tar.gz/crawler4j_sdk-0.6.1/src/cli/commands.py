"""CLI commands for crawler4j SDK module projects."""

from __future__ import annotations

import argparse
import ast
import asyncio
import importlib
import importlib.util
import inspect
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import tomllib
import urllib.error
import urllib.request
import zipfile
from pathlib import Path
from typing import Any

import yaml
from crawler4j_contracts import EnvSelectorSpec, PageSpec, TaskSpec, WorkflowSpec
from crawler4j_contracts.hosted_ui import normalize_page_schema

from crawler4j_sdk._version import (
    get_compatible_contracts_dependency_spec,
    get_compatible_sdk_dependency_spec,
)
from crawler4j_sdk.cli.templates import (
    HOOK_NAMES,
    MODEL_GITIGNORE_TEMPLATE,
    MODEL_HOOKS_INIT_TEMPLATE,
    MODEL_MANIFEST_TEMPLATE,
    MODEL_MODULE_INIT,
    MODEL_PAGES_INIT_TEMPLATE,
    MODEL_PROJECT_PYPROJECT,
    MODEL_PROJECT_README,
    MODEL_SELECTORS_INIT_TEMPLATE,
    MODEL_TEST_TASK_TEMPLATE,
    RANDOM_READY_SELECTOR_TEMPLATE,
    RETURN_NONE_SELECTOR_TEMPLATE,
    SCRIPT_TEMPLATE,
    WORKFLOW_TEMPLATE,
    render_hook_template,
    render_page_template,
    render_selector_template,
)


DEFAULT_PYTHON_VERSION = "3.12"
DEFAULT_MODULE_VERSION = "0.1.0"
NAME_RE = re.compile(r"^[a-z][a-z0-9_]*$")
SEMVER_RE = re.compile(
    r"^v?"
    r"(?P<major>0|[1-9]\d*)\."
    r"(?P<minor>0|[1-9]\d*)\."
    r"(?P<patch>0|[1-9]\d*)"
    r"(?:-(?P<prerelease>[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?"
    r"(?:\+(?P<build>[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?$"
)
REPO_RE = re.compile(r"^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$")
GITHUB_TOKEN_ENV_VARS = ("CRAWLER4J_GITHUB_TOKEN", "GITHUB_TOKEN", "GH_TOKEN")
LEGACY_HOSTED_UI_PATHS: tuple[tuple[str, str], ...] = (
    ("ui", "dir"),
    ("config_schema.json", "file"),
    ("strategy.yaml", "file"),
)
REQUIRED_RUNTIME_API = "core-native-v1"


class CLIError(RuntimeError):
    """Raised when a CLI action cannot be completed safely."""


def to_display_name(name: str) -> str:
    """Convert an identifier to a readable title."""
    return name.replace("_", " ").replace("-", " ").title()


def is_valid_name(name: str) -> bool:
    """Validate importable module-style identifiers."""
    return bool(NAME_RE.match(str(name or "").strip()))


def is_valid_semver(version: str) -> bool:
    """Validate semantic version strings accepted by module manifests."""
    try:
        _parse_semver(version)
    except CLIError:
        return False
    return True


def is_valid_repo(repo: str) -> bool:
    """Validate GitHub owner/repo notation."""
    return bool(REPO_RE.match(str(repo or "").strip()))


def _resolve_github_token(explicit_token: str | None = None) -> str | None:
    token = str(explicit_token or "").strip()
    if token:
        return token
    for env_name in GITHUB_TOKEN_ENV_VARS:
        value = str(os.getenv(env_name, "") or "").strip()
        if value:
            return value
    return None


def _github_headers(*, accept: str, github_token: str | None = None) -> dict[str, str]:
    headers = {
        "Accept": accept,
        "User-Agent": "crawler4j-sdk-cli",
    }
    token = _resolve_github_token(github_token)
    if token:
        headers["Authorization"] = f"Bearer {token}"
    return headers


def _read_http_error_message(exc: urllib.error.HTTPError) -> str:
    try:
        payload = exc.read().decode("utf-8").strip()
    except Exception:
        payload = ""
    if payload:
        try:
            body = json.loads(payload)
        except Exception:
            return payload
        if isinstance(body, dict):
            message = str(body.get("message", "") or "").strip()
            if message:
                return message
        return payload
    return str(exc.reason or exc)


def _print_error(message: str) -> None:
    print(f"❌ {message}")


def _print_success(message: str) -> None:
    print(f"✅ {message}")


def _write_text(path: Path, content: str, *, force: bool = False) -> None:
    if path.exists() and not force:
        raise CLIError(f"文件已存在，拒绝覆盖: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def _ensure_package_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)
    init_file = path / "__init__.py"
    if not init_file.exists():
        init_file.write_text("", encoding="utf-8")


def find_module_root(start: Path | None = None) -> Path | None:
    """Locate the nearest parent directory containing module.yaml."""
    current = (start or Path.cwd()).resolve()
    for candidate in [current, *current.parents]:
        if (candidate / "module.yaml").is_file():
            return candidate
    return None


def require_module_root(start: Path | None = None) -> Path:
    """Require the current working directory to be inside a module project."""
    module_root = find_module_root(start)
    if module_root:
        return module_root
    raise CLIError("当前目录不在模块项目中，找不到 module.yaml")


def load_manifest(module_root: Path) -> dict[str, Any]:
    """Load module.yaml as a mutable dictionary."""
    manifest_path = module_root / "module.yaml"
    data = yaml.safe_load(manifest_path.read_text(encoding="utf-8")) or {}
    if not isinstance(data, dict):
        raise CLIError("module.yaml 顶层必须是 YAML 映射对象")
    return data


def save_manifest(module_root: Path, manifest: dict[str, Any]) -> None:
    """Persist a manifest dictionary back to module.yaml."""
    manifest_path = module_root / "module.yaml"
    manifest_path.write_text(
        yaml.safe_dump(manifest, allow_unicode=True, sort_keys=False),
        encoding="utf-8",
    )


def _module_display_name(module_root: Path, manifest: dict[str, Any]) -> str:
    """Resolve the human-facing module display name."""
    display_name = str(manifest.get("display_name", "") or "").strip()
    if display_name:
        return display_name
    module_name = str(manifest.get("name", "") or "").strip() or module_root.name
    return to_display_name(module_name)


def _resolve_module_import_name(module_root: Path, manifest: dict[str, Any] | None = None) -> str:
    module_name = str((manifest or {}).get("name", "") or "").strip()
    if module_name:
        return module_name
    return module_root.name


def _load_project_version(pyproject_path: Path) -> str:
    try:
        with pyproject_path.open("rb") as fh:
            payload = tomllib.load(fh)
    except FileNotFoundError as exc:
        raise CLIError(f"缺少文件: {pyproject_path}") from exc
    except tomllib.TOMLDecodeError as exc:
        raise CLIError(f"pyproject.toml 解析失败: {pyproject_path}") from exc

    project = payload.get("project")
    if not isinstance(project, dict):
        raise CLIError("pyproject.toml 缺少 [project] 配置")

    version = str(project.get("version", "") or "").strip()
    if not version:
        raise CLIError("pyproject.toml [project].version 不能为空")
    return version


def _set_project_version(pyproject_path: Path, version: str) -> None:
    text = pyproject_path.read_text(encoding="utf-8")
    lines = text.splitlines()
    in_project = False
    replaced = False

    for index, line in enumerate(lines):
        stripped = line.strip()
        if stripped.startswith("[") and stripped.endswith("]"):
            in_project = stripped == "[project]"
            continue
        if in_project and stripped.startswith("version"):
            indent = line[: len(line) - len(line.lstrip())]
            lines[index] = f'{indent}version = "{version}"'
            replaced = True
            break

    if not replaced:
        raise CLIError("pyproject.toml [project] 缺少 version 声明")

    rendered = "\n".join(lines)
    if text.endswith("\n"):
        rendered += "\n"
    pyproject_path.write_text(rendered, encoding="utf-8")


def _list_python_modules(package_dir: Path, *, recursive: bool = False) -> list[str]:
    if not package_dir.exists():
        return []
    paths = package_dir.rglob("*.py") if recursive else package_dir.glob("*.py")
    return sorted(
        ".".join(path.relative_to(package_dir).with_suffix("").parts)
        for path in paths
        if path.name != "__init__.py"
        and not path.name.startswith("_")
        and not any(part.startswith("_") for part in path.relative_to(package_dir).parts[:-1])
    )


def _page_owner_label(page_module_name: str) -> str:
    return f"pages/{page_module_name.replace('.', '/')}.py"


def _normalize_page_group(group: str | None) -> str:
    normalized_group = str(group or "").strip()
    if not normalized_group:
        return ""
    if "/" in normalized_group or "\\" in normalized_group or "." in normalized_group:
        raise CLIError("页面分组名必须是单层小写 snake_case")
    if not is_valid_name(normalized_group):
        raise CLIError("页面分组名必须是单层小写 snake_case")
    return normalized_group


def _page_source_relative_path(page_id: str, *, group: str | None = None) -> Path:
    normalized_page_id = str(page_id or "").strip()
    normalized_group = _normalize_page_group(group)
    if not normalized_group:
        return Path("pages") / f"{normalized_page_id}.py"

    prefix = f"{normalized_group}_"
    file_stem = normalized_page_id
    if normalized_page_id.startswith(prefix):
        candidate = normalized_page_id[len(prefix) :].strip()
        if candidate:
            file_stem = candidate
    return Path("pages") / normalized_group / f"{file_stem}.py"


def _manifest_default_workflow(manifest: dict[str, Any]) -> str:
    return str(manifest.get("default_workflow", "") or "").strip()


def _load_yaml_mapping(path: Path) -> dict[str, Any]:
    payload = yaml.safe_load(path.read_text(encoding="utf-8"))
    if payload is None:
        return {}
    if not isinstance(payload, dict):
        raise CLIError(f"YAML 文件必须是映射对象: {path}")
    return payload


def _normalize_ui_pages(manifest: dict[str, Any]) -> list[dict[str, Any]]:
    ui_extension = manifest.setdefault("ui_extension", {})
    if not isinstance(ui_extension, dict):
        raise CLIError("module.yaml.ui_extension 必须是映射对象")
    pages = ui_extension.setdefault("pages", [])
    if not isinstance(pages, list):
        raise CLIError("module.yaml.ui_extension.pages 必须是数组")
    return pages


def _normalize_data_section(manifest: dict[str, Any]) -> dict[str, Any]:
    data = manifest.setdefault("data", {})
    if not isinstance(data, dict):
        raise CLIError("module.yaml.data 必须是映射对象")
    for section in ("resources", "views", "queries", "seeds"):
        value = data.setdefault(section, [])
        if not isinstance(value, list):
            raise CLIError(f"module.yaml.data.{section} 必须是数组")
    return data


def _manifest_data_entries(manifest: dict[str, Any], section: str) -> list[dict[str, Any]]:
    data = _normalize_data_section(manifest)
    entries = data[section]
    assert isinstance(entries, list)
    return entries


def _manifest_resource_entry(manifest: dict[str, Any], resource_id: str) -> dict[str, Any] | None:
    normalized_resource_id = str(resource_id or "").strip()
    for item in _manifest_data_entries(manifest, "resources"):
        if isinstance(item, dict) and str(item.get("id", "") or "").strip() == normalized_resource_id:
            return item
    return None


def _append_unique_data_entry(manifest: dict[str, Any], section: str, entry_id: str, payload: dict[str, Any]) -> None:
    entries = _manifest_data_entries(manifest, section)
    normalized_entry_id = str(entry_id or "").strip()
    for item in entries:
        if isinstance(item, dict) and str(item.get("id", "") or "").strip() == normalized_entry_id:
            raise CLIError(f"module.yaml.data.{section} 已存在同名条目: {normalized_entry_id}")
    entries.append(payload)


def _validate_sql_file(module_root: Path, relative_path: str, *, expected_prefix: str) -> str | None:
    normalized = str(relative_path or "").strip()
    if not normalized:
        return "SQL 文件路径不能为空"
    if not normalized.startswith(expected_prefix):
        return f"SQL 文件必须位于 {expected_prefix}"
    target = (module_root / normalized).resolve()
    if not str(target).startswith(str(module_root.resolve())):
        return f"SQL 文件路径越界: {relative_path}"
    if not target.is_file():
        return f"找不到 SQL 文件: {relative_path}"
    sql = target.read_text(encoding="utf-8").strip()
    if not sql:
        return f"SQL 文件为空: {relative_path}"
    if ";" in sql:
        return f"SQL 文件必须只包含单条语句: {relative_path}"
    if re.search(r"\b(insert|update|delete|drop|alter|attach|detach|pragma|create|replace)\b", sql, re.IGNORECASE):
        return f"SQL 文件包含被禁止的关键字: {relative_path}"
    if not re.match(r"^\s*(with\b|select\b)", sql, flags=re.IGNORECASE):
        return f"SQL 文件必须以 SELECT / WITH 开头: {relative_path}"
    return None


def _validate_sql_placeholders(sql: str, source_resource_ids: list[str], *, owner_label: str) -> str | None:
    placeholder_re = re.compile(r"\{\{resource:([a-z][a-z0-9_]*)\}\}")
    sql_ref_re = re.compile(r"\b(?:from|join)\s+([^\s,()]+)", re.IGNORECASE)
    placeholders = placeholder_re.findall(sql)
    if not placeholders:
        return f"{owner_label} 必须至少引用一个 {{resource:<id>}} 占位符"
    for token in sql_ref_re.findall(sql):
        if not placeholder_re.fullmatch(token):
            return f"{owner_label} 的 FROM/JOIN 只允许引用 {{resource:<id>}} 占位符"
    if set(placeholders) != set(source_resource_ids):
        return f"{owner_label} 的 SQL 占位符必须与 source_resource_ids 完全一致"
    return None


def _collect_data_contract_errors(module_root: Path, manifest: dict[str, Any]) -> list[str]:
    data = manifest.get("data")
    if not isinstance(data, dict):
        return ["module.yaml 缺少 data"]

    errors: list[str] = []
    resources = data.get("resources")
    views = data.get("views")
    queries = data.get("queries")
    seeds = data.get("seeds")
    if not isinstance(resources, list):
        errors.append("module.yaml.data.resources 必须是数组")
        resources = []
    if not isinstance(views, list):
        errors.append("module.yaml.data.views 必须是数组")
        views = []
    if not isinstance(queries, list):
        errors.append("module.yaml.data.queries 必须是数组")
        queries = []
    if not isinstance(seeds, list):
        errors.append("module.yaml.data.seeds 必须是数组")
        seeds = []

    allowed_resource_keys = {
        "id",
        "storage_mode",
        "record_key_field",
        "schema",
        "indexes",
        "cleanup_policy",
        "joins",
    }
    resource_map: dict[str, dict[str, Any]] = {}
    for item in resources:
        if not isinstance(item, dict):
            errors.append("data.resources 中的每一项都必须是对象")
            continue
        unknown_keys = sorted(set(item) - allowed_resource_keys)
        if unknown_keys:
            errors.append("data.resources 包含不支持的字段: " + ", ".join(unknown_keys))
        resource_id = str(item.get("id", "") or "").strip()
        if not is_valid_name(resource_id):
            errors.append(f"无效的 data.resources[].id: {resource_id or '<empty>'}")
            continue
        if resource_id in resource_map:
            errors.append(f"data.resources[].id 重复: {resource_id}")
            continue
        resource_map[resource_id] = item
        storage_mode = str(item.get("storage_mode", "managed_dataset") or "managed_dataset").strip().lower()
        if storage_mode not in {"managed_dataset", "custom_table"}:
            errors.append(f"data.resources[{resource_id}].storage_mode 不支持: {storage_mode}")
        schema = item.get("schema")
        columns = schema.get("columns") if isinstance(schema, dict) else None
        if not isinstance(columns, list) or not columns:
            errors.append(f"data.resources[{resource_id}].schema.columns 不能为空")
        joins = item.get("joins") or []
        if storage_mode != "custom_table" and joins:
            errors.append(f"data.resources[{resource_id}].joins 只允许 custom_table 声明")

    for resource_id, item in resource_map.items():
        joins = item.get("joins") or []
        if not isinstance(joins, list):
            errors.append(f"data.resources[{resource_id}].joins 必须是数组")
            continue
        for join in joins:
            if not isinstance(join, dict):
                errors.append(f"data.resources[{resource_id}].joins 中的每一项都必须是对象")
                continue
            target = str(join.get("target") or "").strip()
            if not is_valid_name(target):
                errors.append(f"data.resources[{resource_id}].joins[].target 必须是小写 snake_case")
                continue
            target_resource = resource_map.get(target)
            if not target_resource:
                errors.append(f"data.resources[{resource_id}].joins 引用了未声明资源: {target}")
                continue
            if str(target_resource.get("storage_mode", "managed_dataset")).strip().lower() != "custom_table":
                errors.append(f"data.resources[{resource_id}].joins 只允许连接 custom_table: {target}")
            on = join.get("on")
            if not isinstance(on, dict) or not on:
                errors.append(f"data.resources[{resource_id}].joins[{target}].on 不能为空")

    for item in views:
        if not isinstance(item, dict):
            errors.append("data.views 中的每一项都必须是对象")
            continue
        view_id = str(item.get("id", "") or "").strip()
        if not is_valid_name(view_id):
            errors.append(f"无效的 data.views[].id: {view_id or '<empty>'}")
            continue
        source_resource_ids = [
            str(raw or "").strip()
            for raw in (item.get("source_resource_ids") or [])
            if str(raw or "").strip()
        ]
        if not source_resource_ids:
            errors.append(f"data.views[{view_id}].source_resource_ids 不能为空")
            continue
        for resource_id in source_resource_ids:
            resource = resource_map.get(resource_id)
            if not resource:
                errors.append(f"data.views[{view_id}] 引用了未声明资源: {resource_id}")
                continue
            if str(resource.get("storage_mode", "managed_dataset")).strip().lower() != "custom_table":
                errors.append(f"data.views[{view_id}] 只允许引用 custom_table 资源: {resource_id}")
        sql_file = str(item.get("sql_file", "") or "").strip()
        error = _validate_sql_file(module_root, sql_file, expected_prefix="data/sql/views/")
        if error:
            errors.append(error)
        else:
            sql = (module_root / sql_file).read_text(encoding="utf-8").strip()
            placeholder_error = _validate_sql_placeholders(
                sql,
                source_resource_ids,
                owner_label=f"data.views[{view_id}]",
            )
            if placeholder_error:
                errors.append(placeholder_error)

    for item in queries:
        if not isinstance(item, dict):
            errors.append("data.queries 中的每一项都必须是对象")
            continue
        query_id = str(item.get("id", "") or "").strip()
        if not is_valid_name(query_id):
            errors.append(f"无效的 data.queries[].id: {query_id or '<empty>'}")
            continue
        source_resource_ids = [
            str(raw or "").strip()
            for raw in (item.get("source_resource_ids") or [])
            if str(raw or "").strip()
        ]
        if not source_resource_ids:
            errors.append(f"data.queries[{query_id}].source_resource_ids 不能为空")
            continue
        for resource_id in source_resource_ids:
            resource = resource_map.get(resource_id)
            if not resource:
                errors.append(f"data.queries[{query_id}] 引用了未声明资源: {resource_id}")
                continue
            if str(resource.get("storage_mode", "managed_dataset")).strip().lower() != "custom_table":
                errors.append(f"data.queries[{query_id}] 只允许引用 custom_table 资源: {resource_id}")
        sql_file = str(item.get("sql_file", "") or "").strip()
        error = _validate_sql_file(module_root, sql_file, expected_prefix="data/sql/queries/")
        if error:
            errors.append(error)
        else:
            sql = (module_root / sql_file).read_text(encoding="utf-8").strip()
            placeholder_error = _validate_sql_placeholders(
                sql,
                source_resource_ids,
                owner_label=f"data.queries[{query_id}]",
            )
            if placeholder_error:
                errors.append(placeholder_error)

    for item in seeds:
        if not isinstance(item, dict):
            errors.append("data.seeds 中的每一项都必须是对象")
            continue
        seed_id = str(item.get("id", "") or "").strip()
        if not is_valid_name(seed_id):
            errors.append(f"无效的 data.seeds[].id: {seed_id or '<empty>'}")
            continue
        resource_id = str(item.get("resource_id", "") or "").strip()
        if resource_id not in resource_map:
            errors.append(f"data.seeds[{seed_id}] 引用了未声明资源: {resource_id or '<empty>'}")
        seed_file = str(item.get("file", "") or "").strip()
        if not seed_file.startswith("data/seeds/"):
            errors.append(f"data.seeds[{seed_id}].file 必须位于 data/seeds/")
            continue
        target = (module_root / seed_file).resolve()
        if not str(target).startswith(str(module_root.resolve())):
            errors.append(f"data.seeds[{seed_id}].file 路径越界: {seed_file}")
            continue
        if not target.is_file():
            errors.append(f"找不到种子文件: {seed_file}")
            continue
        try:
            payload = json.loads(target.read_text(encoding='utf-8'))
        except json.JSONDecodeError:
            errors.append(f"种子文件不是合法 JSON: {seed_file}")
            continue
        if not isinstance(payload, list) or any(not isinstance(row, dict) for row in payload):
            errors.append(f"种子文件必须是对象数组 JSON: {seed_file}")

    return errors


def _manifest_ui_extension(manifest: dict[str, Any]) -> dict[str, Any] | None:
    ui_extension = manifest.get("ui_extension")
    if ui_extension is None:
        return None
    if not isinstance(ui_extension, dict):
        raise CLIError("module.yaml.ui_extension 必须是映射对象")
    return ui_extension


def _manifest_ui_pages(manifest: dict[str, Any]) -> list[dict[str, Any]]:
    ui_extension = _manifest_ui_extension(manifest)
    if ui_extension is None:
        return []
    pages = ui_extension.get("pages")
    if pages is None:
        return []
    if not isinstance(pages, list):
        raise CLIError("module.yaml.ui_extension.pages 必须是数组")
    return [item for item in pages if isinstance(item, dict)]

def _normalize_config_defaults(manifest: dict[str, Any]) -> dict[str, Any]:
    config_defaults = manifest.setdefault("config_defaults", {})
    if config_defaults is None:
        config_defaults = {}
        manifest["config_defaults"] = config_defaults
    if not isinstance(config_defaults, dict):
        raise CLIError("config_defaults 必须是 YAML 映射对象")
    module_defaults = config_defaults.setdefault("module", {})
    workflow_defaults = config_defaults.setdefault("workflows", {})
    if not isinstance(module_defaults, dict):
        raise CLIError("config_defaults.module 必须是 YAML 映射对象")
    if not isinstance(workflow_defaults, dict):
        raise CLIError("config_defaults.workflows 必须是 YAML 映射对象")
    return config_defaults


def _manifest_workflows(manifest: dict[str, Any]) -> list[dict[str, Any]]:
    workflows = manifest.setdefault("workflows", [])
    if not isinstance(workflows, list):
        raise CLIError("module.yaml.workflows 必须是数组")
    return workflows


def _manifest_workflow_names(manifest: dict[str, Any]) -> list[str]:
    names: list[str] = []
    for item in _manifest_workflows(manifest):
        if isinstance(item, dict):
            name = str(item.get("name", "")).strip()
            if name:
                names.append(name)
    return names


def _is_known_hook(name: str) -> bool:
    return name in HOOK_NAMES


def _safe_run(cmd: list[str], *, cwd: Path) -> None:
    subprocess.run(cmd, cwd=str(cwd), check=True, capture_output=True)


def _run_async(awaitable):
    return asyncio.run(awaitable)


def _purge_module_namespace(module_name: str) -> None:
    prefix = f"{module_name}."
    for loaded_name in list(sys.modules):
        if loaded_name == module_name or loaded_name.startswith(prefix):
            sys.modules.pop(loaded_name, None)


def _import_module_root(module_root: Path, module_name: str) -> Any:
    package_init = module_root / "__init__.py"
    if not package_init.exists():
        raise FileNotFoundError(package_init)

    existing = sys.modules.get(module_name)
    existing_file = getattr(existing, "__file__", "") if existing else ""
    same_origin = bool(existing_file) and Path(existing_file).resolve() == package_init.resolve()
    if same_origin:
        return existing
    if existing:
        _purge_module_namespace(module_name)

    importlib.invalidate_caches()
    spec = importlib.util.spec_from_file_location(
        module_name,
        package_init,
        submodule_search_locations=[str(module_root)],
    )
    if spec is None or spec.loader is None:
        raise ImportError(f"无法从 `{module_root}` 构建模块加载规格")

    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def _import_module_child(module_root: Path, module_name: str, subpackage: str, name: str) -> Any:
    _import_module_root(module_root, module_name)
    return importlib.import_module(f"{module_name}.{subpackage}.{name}")


def _validate_exported_spec(
    module: Any,
    export_name: str,
    spec_type: type[Any],
    *,
    owner_label: str,
) -> str | None:
    exported = getattr(module, export_name, None)
    if not isinstance(exported, spec_type):
        return f"{owner_label} 缺少 {export_name}，或类型不是 {spec_type.__name__}"
    return None


def _validate_task_module(module_root: Path, module_name: str, task_name: str) -> list[str]:
    owner_label = f"tasks/{task_name}.py"
    try:
        module = _import_module_child(module_root, module_name, "tasks", task_name)
    except Exception as exc:
        return [f"{owner_label} 无法导入: {exc.__class__.__name__}: {exc}"]

    errors: list[str] = []
    spec_error = _validate_exported_spec(module, "TASK", TaskSpec, owner_label=owner_label)
    if spec_error:
        errors.append(spec_error)
    elif str(module.TASK.name or "").strip() != task_name:
        errors.append(f"{owner_label} 的 TASK.name 必须与文件名一致: {task_name}")

    execute = getattr(module, "execute", None)
    if execute is None or not callable(execute):
        errors.append(f"{owner_label} 缺少可调用导出: execute")
    return errors


def _validate_workflow_module(module_root: Path, module_name: str, workflow_name: str) -> list[str]:
    owner_label = f"workflows/{workflow_name}.py"
    try:
        module = _import_module_child(module_root, module_name, "workflows", workflow_name)
    except Exception as exc:
        return [f"{owner_label} 无法导入: {exc.__class__.__name__}: {exc}"]

    errors: list[str] = []
    spec_error = _validate_exported_spec(module, "WORKFLOW", WorkflowSpec, owner_label=owner_label)
    if spec_error:
        errors.append(spec_error)
    elif str(module.WORKFLOW.name or "").strip() != workflow_name:
        errors.append(f"{owner_label} 的 WORKFLOW.name 必须与文件名一致: {workflow_name}")

    run_func = getattr(module, "run", None)
    if run_func is None or not callable(run_func):
        errors.append(f"{owner_label} 缺少可调用导出: run")
    return errors


def _validate_hook_module(module_root: Path, module_name: str, hook_name: str) -> list[str]:
    owner_label = f"hooks/{hook_name}.py"
    try:
        module = _import_module_child(module_root, module_name, "hooks", hook_name)
    except Exception as exc:
        return [f"{owner_label} 无法导入: {exc.__class__.__name__}: {exc}"]
    handle = getattr(module, "handle", None)
    if handle is None or not callable(handle):
        return [f"{owner_label} 缺少可调用导出: handle"]
    return []


def _validate_selector_module(module_root: Path, module_name: str, selector_name: str) -> list[str]:
    owner_label = f"env_selectors/{selector_name}.py"
    try:
        module = _import_module_child(module_root, module_name, "env_selectors", selector_name)
    except Exception as exc:
        return [f"{owner_label} 无法导入: {exc.__class__.__name__}: {exc}"]

    errors: list[str] = []
    spec_error = _validate_exported_spec(module, "SELECTOR", EnvSelectorSpec, owner_label=owner_label)
    if spec_error:
        errors.append(spec_error)
    elif str(module.SELECTOR.name or "").strip() != selector_name:
        errors.append(f"{owner_label} 的 SELECTOR.name 必须与文件名一致: {selector_name}")

    select = getattr(module, "select", None)
    if select is None or not callable(select):
        errors.append(f"{owner_label} 缺少可调用导出: select")
    return errors


def _validate_page_module(
    module_root: Path,
    module_name: str,
    page_name: str,
) -> tuple[list[str], str | None, dict[str, Any] | None]:
    owner_label = _page_owner_label(page_name)
    try:
        module = _import_module_child(module_root, module_name, "pages", page_name)
    except Exception as exc:
        return [f"{owner_label} 无法导入: {exc.__class__.__name__}: {exc}"], None, None

    errors: list[str] = []
    spec_error = _validate_exported_spec(module, "PAGE", PageSpec, owner_label=owner_label)
    if spec_error:
        return [spec_error], None, None

    page_spec = module.PAGE
    page_id = str(page_spec.id or "").strip()
    if not is_valid_name(page_id):
        errors.append(f"{owner_label} 的 PAGE.id 必须是小写 snake_case: {page_id or '<empty>'}")
        return errors, None, None

    try:
        schema = normalize_page_schema(page_id, dict(page_spec.schema or {}))
    except ValueError as exc:
        errors.append(f"宿主页 {page_id} schema 无效: {exc}")
        return errors, None, None

    load_handler_name = str(schema.get("load_handler", "") or "").strip()
    load_handler = getattr(module, load_handler_name, None)
    if load_handler is None or not callable(load_handler):
        errors.append(f"宿主页 {page_id} 的 load_handler 未在 {owner_label} 中定义: {load_handler_name}")
    elif inspect.iscoroutinefunction(load_handler):
        errors.append(f"宿主页 {page_id} 的 load_handler 必须是同步函数: {load_handler_name}")

    errors.extend(_validate_inline_table_handlers(module, page_id, schema, owner_label=owner_label))
    return errors, page_id, schema


def _render_yaml(data: Any) -> str:
    return yaml.safe_dump(data, allow_unicode=True, sort_keys=False).strip() or "{}"


def _parse_semver(version: str) -> tuple[int, int, int, tuple[str, ...]]:
    match = SEMVER_RE.match(str(version or "").strip())
    if not match:
        raise CLIError(f"无效的版本号: {version}")

    prerelease = tuple((match.group("prerelease") or "").split(".")) if match.group("prerelease") else ()
    for identifier in prerelease:
        if identifier.isdigit() and len(identifier) > 1 and identifier.startswith("0"):
            raise CLIError(f"无效的版本号: {version}")

    return (
        int(match.group("major")),
        int(match.group("minor")),
        int(match.group("patch")),
        prerelease,
    )


def _compare_versions(left: str, right: str) -> int:
    left_major, left_minor, left_patch, left_prerelease = _parse_semver(left)
    right_major, right_minor, right_patch, right_prerelease = _parse_semver(right)

    left_base = (left_major, left_minor, left_patch)
    right_base = (right_major, right_minor, right_patch)
    if left_base < right_base:
        return -1
    if left_base > right_base:
        return 1

    if not left_prerelease and not right_prerelease:
        return 0
    if not left_prerelease:
        return 1
    if not right_prerelease:
        return -1

    for left_identifier, right_identifier in zip(left_prerelease, right_prerelease):
        if left_identifier == right_identifier:
            continue

        left_numeric = left_identifier.isdigit()
        right_numeric = right_identifier.isdigit()
        if left_numeric and right_numeric:
            left_number = int(left_identifier)
            right_number = int(right_identifier)
            if left_number < right_number:
                return -1
            if left_number > right_number:
                return 1
            continue
        if left_numeric != right_numeric:
            return -1 if left_numeric else 1
        if left_identifier < right_identifier:
            return -1
        return 1

    if len(left_prerelease) < len(right_prerelease):
        return -1
    if len(left_prerelease) > len(right_prerelease):
        return 1
    return 0


def _load_host_runtime() -> dict[str, Any]:
    try:
        from src.core.persistence import init_database
        from src.core.mms import get_module_registry, get_module_release_service
        from src.core.debug import ensure_vscode_attach_config
    except ImportError as exc:  # pragma: no cover - depends on runtime environment
        raise CLIError(
            "当前环境缺少 crawler4j 宿主运行时；host 命令只能在安装了 crawler4j 客户端的环境里使用"
        ) from exc

    runtime: dict[str, Any] = {
        "init_database": init_database,
        "get_module_registry": get_module_registry,
        "get_module_release_service": get_module_release_service,
        "ensure_vscode_attach_config": ensure_vscode_attach_config,
    }
    return runtime


def _init_host_runtime(runtime: dict[str, Any]) -> None:
    runtime["init_database"]()


def _detect_install_source(source: str) -> tuple[str, str | Path]:
    source_path = Path(source).expanduser()
    if source_path.exists():
        resolved = source_path.resolve()
        if resolved.is_dir():
            return "dir", resolved
        if resolved.suffix.lower() == ".zip":
            return "zip", resolved
        return "file", resolved
    return "repo", source


def _print_preview(
    *,
    source_label: str,
    manifest: Any,
    warnings: list[str] | None = None,
    archive_path: Path | None = None,
    release: Any | None = None,
) -> None:
    print(f"安装来源: {source_label}")
    print(f"模块名: {getattr(manifest, 'name', '')}")
    print(f"版本: {getattr(manifest, 'version', '')}")
    print(f"仓库: {getattr(getattr(manifest, 'upgrade_source', None), 'repo', '')}")
    if archive_path:
        print(f"安装包: {archive_path}")
    if release:
        print(f"Release 版本: {getattr(release, 'version', '')}")
        print(f"Release 页面: {getattr(release, 'html_url', '')}")
    if warnings:
        print("警告:")
        for item in warnings:
            print(f"  - {item}")


def _print_module_info(module: Any) -> None:
    manifest = getattr(module, "manifest", None)
    print(f"模块名: {getattr(module, 'name', '')}")
    print(f"版本: {getattr(manifest, 'version', '') if manifest else ''}")
    print(f"来源: {getattr(getattr(module, 'source', None), 'value', getattr(module, 'source', ''))}")
    print(f"路径: {getattr(module, 'path', '')}")


def _validate_ui_extension(manifest: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    ui_extension = manifest.get("ui_extension")
    if ui_extension is None:
        return errors
    if not isinstance(ui_extension, dict):
        return ["ui_extension 必须是 YAML 映射对象"]

    unknown_keys = sorted(set(ui_extension) - {"pages"})
    if unknown_keys:
        errors.append("ui_extension 包含不支持的字段: " + ", ".join(unknown_keys))

    pages = ui_extension.get("pages")
    if pages is None:
        return errors
    if not isinstance(pages, list):
        errors.append("ui_extension.pages 必须是数组")
        return errors

    seen_ids: set[str] = set()
    for item in pages:
        if not isinstance(item, dict):
            errors.append("ui_extension.pages 里的每一项都必须是对象")
            continue

        unknown_keys = sorted(set(item) - {"id", "label", "icon"})
        if unknown_keys:
            page_label = str(item.get("id", "") or "").strip() or "<empty>"
            errors.append(
                f"ui_extension.pages[{page_label}] 包含不支持的字段: {', '.join(unknown_keys)}"
            )

        page_id = str(item.get("id", "") or "").strip()
        if not is_valid_name(page_id):
            errors.append(f"无效的 ui_extension.pages[].id: {page_id or '<empty>'}")
            continue
        if page_id in seen_ids:
            errors.append(f"ui_extension.pages[].id 重复: {page_id}")
        seen_ids.add(page_id)

        label = str(item.get("label", "") or "").strip()
        if not label:
            errors.append(f"ui_extension.pages[{page_id}].label 不能为空")
    return errors


def _collect_legacy_hosted_ui_errors(module_root: Path) -> list[str]:
    errors: list[str] = []
    for relative_path, expected_kind in LEGACY_HOSTED_UI_PATHS:
        candidate = module_root / relative_path
        if not candidate.exists():
            continue
        if expected_kind == "dir":
            if candidate.is_dir():
                errors.append(f"残留旧 UI 目录: {relative_path}/")
            else:
                errors.append(f"残留旧 UI 路径: {relative_path}")
            continue
        if candidate.is_file():
            errors.append(f"残留旧 UI 文件: {relative_path}")
        else:
            errors.append(f"残留旧 UI 路径: {relative_path}")
    return errors


def collect_structure_errors(module_root: Path, manifest: dict[str, Any]) -> list[str]:
    """Collect structure-level validation errors."""
    errors: list[str] = []

    required_files = ["module.yaml", "__init__.py"]
    required_dirs = ["tasks", "workflows"]
    for name in required_files:
        if not (module_root / name).exists():
            errors.append(f"缺少关键文件: {name}")
    for name in required_dirs:
        if not (module_root / name).is_dir():
            errors.append(f"缺少关键目录: {name}/")

    if not str(manifest.get("name", "")).strip():
        errors.append("module.yaml 缺少 name")
    if str(manifest.get("runtime_api", "")).strip() != REQUIRED_RUNTIME_API:
        errors.append(f"module.yaml.runtime_api 必须是 {REQUIRED_RUNTIME_API}")
    if "sdk_version_range" in manifest:
        errors.append("module.yaml 不再允许声明 sdk_version_range")

    workflow_names = _manifest_workflow_names(manifest)
    if not workflow_names:
        errors.append("module.yaml.workflows 不能为空")
    else:
        for workflow_name in workflow_names:
            if not is_valid_name(workflow_name):
                errors.append(f"无效的 workflow 名称: {workflow_name}")
                continue
            if not (module_root / "workflows" / f"{workflow_name}.py").exists():
                errors.append(f"module.yaml 声明的 workflow 缺少源码文件: workflows/{workflow_name}.py")

    default_workflow = _manifest_default_workflow(manifest)
    if not default_workflow:
        errors.append("module.yaml 缺少 default_workflow")
    elif default_workflow not in workflow_names:
        errors.append(f"default_workflow 未在 module.yaml.workflows 中声明: {default_workflow}")

    declared = set(workflow_names)
    files = set(_list_python_modules(module_root / "workflows"))
    for extra in sorted(files - declared):
        errors.append(f"workflows/{extra}.py 未写入 module.yaml.workflows")

    errors.extend(_validate_ui_extension(manifest))
    errors.extend(_collect_data_contract_errors(module_root, manifest))
    errors.extend(_collect_legacy_hosted_ui_errors(module_root))
    return errors


def collect_release_errors(module_root: Path, manifest: dict[str, Any]) -> list[str]:
    """Collect release-readiness validation errors."""
    errors = collect_structure_errors(module_root, manifest)

    version = str(manifest.get("version", "") or "").strip()
    if not is_valid_semver(version):
        errors.append(f"module.yaml.version 不是合法版本号: {version or '<empty>'}")

    upgrade_source = manifest.get("upgrade_source")
    if not isinstance(upgrade_source, dict):
        errors.append("module.yaml.upgrade_source 必须是 YAML 映射对象")
    else:
        source_type = str(upgrade_source.get("type", "") or "").strip()
        repo = str(upgrade_source.get("repo", "") or "").strip()
        if source_type != "github_release":
            errors.append("upgrade_source.type 目前必须是 github_release")
        if not is_valid_repo(repo):
            errors.append("upgrade_source.repo 必须是 owner/repo 形式")

    try:
        config_defaults = _normalize_config_defaults(dict(manifest))
        declared_workflows = set(_manifest_workflow_names(manifest))
        for workflow_name in config_defaults["workflows"]:
            if workflow_name not in declared_workflows:
                errors.append(f"config_defaults.workflows 包含未声明的 workflow: {workflow_name}")
    except CLIError as exc:
        errors.append(str(exc))

    pyproject_path = module_root / "pyproject.toml"
    if pyproject_path.exists():
        try:
            project_version = _load_project_version(pyproject_path)
        except CLIError as exc:
            errors.append(str(exc))
        else:
            if project_version != version:
                errors.append(
                    "pyproject.toml [project].version 必须与 module.yaml.version 一致: "
                    f"{project_version} != {version}"
                )

    module_name = str(manifest.get("name", "")).strip()
    if module_name and not is_valid_name(module_name):
        errors.append("module.yaml.name 必须是可导入的 snake_case 包名")
    return errors


def collect_full_errors(module_root: Path, manifest: dict[str, Any]) -> list[str]:
    """Collect importability and runtime-level validation errors."""
    errors = collect_release_errors(module_root, manifest)
    if errors:
        return errors

    module_name = _resolve_module_import_name(module_root, manifest)
    try:
        _import_module_root(module_root, module_name)
    except Exception as exc:  # pragma: no cover - exercised by tests via failure paths
        return [f"模块无法导入: {exc.__class__.__name__}: {exc}"]

    for task_name in _list_python_modules(module_root / "tasks"):
        errors.extend(_validate_task_module(module_root, module_name, task_name))

    workflow_names = _manifest_workflow_names(manifest)
    for workflow_name in workflow_names:
        errors.extend(_validate_workflow_module(module_root, module_name, workflow_name))

    for hook_name in _list_python_modules(module_root / "hooks"):
        errors.extend(_validate_hook_module(module_root, module_name, hook_name))

    selector_files = _list_python_modules(module_root / "env_selectors")
    for selector_name in selector_files:
        errors.extend(_validate_selector_module(module_root, module_name, selector_name))
        try:
            _import_module_child(module_root, module_name, "env_selectors", selector_name)
        except Exception:
            continue

    declared_pages = {
        str(item.get("id", "")).strip()
        for item in _manifest_ui_pages(manifest)
        if str(item.get("id", "")).strip()
    }
    discovered_pages: dict[str, str] = {}
    for page_name in _list_python_modules(module_root / "pages", recursive=True):
        page_errors, page_id, schema = _validate_page_module(module_root, module_name, page_name)
        errors.extend(page_errors)
        if not page_id or not schema:
            continue
        owner_label = _page_owner_label(page_name)
        previous_owner = discovered_pages.get(page_id)
        if previous_owner and previous_owner != owner_label:
            errors.append(f"宿主页 {page_id} 重复定义: {previous_owner}、{owner_label}")
            continue
        discovered_pages[page_id] = owner_label

    missing_pages = sorted(declared_pages - set(discovered_pages))
    errors.extend(
        f"module.yaml.ui_extension.pages 声明的宿主页缺少页面文件: {page_id}"
        for page_id in missing_pages
    )
    errors.extend(_collect_legacy_db_tool_usage_errors(module_root))
    errors.extend(_collect_removed_task_context_usage_errors(module_root))

    return errors


def _iter_module_python_trees(module_root: Path):
    for path in sorted(module_root.rglob("*.py")):
        relative = path.relative_to(module_root)
        if any(part in {".venv", "__pycache__", ".pytest_cache", ".ruff_cache"} for part in relative.parts):
            continue
        text = path.read_text(encoding="utf-8")
        try:
            tree = ast.parse(text, filename=str(path))
        except SyntaxError:
            continue
        yield relative, tree


def _collect_legacy_db_tool_usage_errors(module_root: Path) -> list[str]:
    errors: list[str] = []
    for relative, tree in _iter_module_python_trees(module_root):
        legacy_calls = sorted(
            (node.args[0].lineno for node in ast.walk(tree) if _is_legacy_db_tool_call(node)),
            key=int,
        )
        errors.extend(
            f"{relative}:{line_no} 使用了已删除的旧数据库工具入口；请改用 ctx.db fluent API"
            for line_no in legacy_calls
        )
    return errors


def _is_legacy_db_tool_call(node: ast.AST) -> bool:
    if not isinstance(node, ast.Call):
        return False
    if not isinstance(node.func, ast.Attribute) or node.func.attr not in {"call", "has_tool"}:
        return False
    if not isinstance(node.func.value, ast.Attribute) or node.func.value.attr != "tools":
        return False
    if not node.args:
        return False
    first_arg = node.args[0]
    return isinstance(first_arg, ast.Constant) and isinstance(first_arg.value, str) and first_arg.value.startswith("db.")


def _collect_removed_task_context_usage_errors(module_root: Path) -> list[str]:
    errors: list[str] = []
    for relative, tree in _iter_module_python_trees(module_root):
        captured_data_accesses = sorted(
            (node.lineno for node in ast.walk(tree) if _is_removed_captured_data_access(node)),
            key=int,
        )
        errors.extend(
            f"{relative}:{line_no} 使用了已删除的 ctx.captured_data；临时状态请用 ctx.state，任务输出请返回 TaskResult.data"
            for line_no in captured_data_accesses
        )
    return errors


def _is_removed_captured_data_access(node: ast.AST) -> bool:
    return isinstance(node, ast.Attribute) and node.attr == "captured_data"


def _iter_inline_tables(children: list[dict[str, Any]]) -> list[dict[str, Any]]:
    tables: list[dict[str, Any]] = []
    for child in children:
        if not isinstance(child, dict):
            continue
        if str(child.get("type") or "") == "DataTable":
            tables.append(child)
            continue
        nested = child.get("children")
        if isinstance(nested, list):
            tables.extend(_iter_inline_tables(nested))
    return tables


def _validate_inline_table_handlers(
    owner_module: Any,
    page_id: str,
    page_schema: dict[str, Any],
    *,
    owner_label: str,
) -> list[str]:
    errors: list[str] = []
    children = page_schema.get("children")
    if not isinstance(children, list):
        return errors
    for table_schema in _iter_inline_tables(children):
        data_source = table_schema.get("data_source")
        if not isinstance(data_source, dict):
            continue
        if str(data_source.get("type") or "").strip().lower() != "query_handler":
            continue
        handler_name = str(data_source.get("handler") or "").strip()
        if not handler_name:
            continue
        table_id = str(table_schema.get("table_id") or "").strip()
        error = _validate_runtime_handler(
            owner_module,
            owner_label=f"{owner_label} 的内联表格 {table_id or '<empty>'}",
            handler_field="data_source.handler",
            handler_name=handler_name,
            runtime_call_label="(context, table_id, query, params)",
            call_args=(table_id, {}, None),
        )
        if error:
            errors.append(error)
    return errors


def _validate_runtime_handler(
    owner_module: Any,
    *,
    owner_label: str,
    handler_field: str,
    handler_name: str,
    runtime_call_label: str,
    call_args: tuple[Any, ...],
) -> str | None:
    handler = getattr(owner_module, handler_name, None)
    if handler is None or not callable(handler):
        return f"{owner_label} 的 {handler_field} 未定义: {handler_name}"
    handler_call = getattr(handler, "__call__", None)
    if inspect.iscoroutinefunction(handler) or inspect.iscoroutinefunction(handler_call):
        return f"{owner_label} 的 {handler_field} 必须是同步函数: {handler_name}"
    try:
        signature = inspect.signature(handler)
    except (TypeError, ValueError) as exc:
        return f"{owner_label} 的 {handler_field} 无法解析签名: {handler_name} ({exc})"
    try:
        signature.bind(object(), *call_args)
    except TypeError:
        return (
            f"{owner_label} 的 {handler_field} 签名不兼容，"
            f"运行时会按 {runtime_call_label} 调用: {handler_name}"
        )
    return None


def cmd_data_list(args: argparse.Namespace) -> int:
    del args
    module_root = require_module_root()
    manifest = load_manifest(module_root)
    data = _normalize_data_section(manifest)
    for section in ("resources", "views", "queries", "seeds"):
        entries = data[section]
        labels = ", ".join(str(item.get("id", "")) for item in entries if isinstance(item, dict) and item.get("id"))
        print(f"{section}: {labels or '(无)'}")
    return 0


def cmd_data_resource_create(args: argparse.Namespace) -> int:
    module_root = require_module_root()
    resource_id = str(args.name or "").strip()
    if not is_valid_name(resource_id):
        _print_error("资源名必须是小写 snake_case")
        return 1
    storage_mode = str(args.storage_mode or "managed_dataset").strip().lower()
    if storage_mode not in {"managed_dataset", "custom_table"}:
        _print_error("storage_mode 只支持 managed_dataset/custom_table")
        return 1
    record_key_field = str(args.record_key_field or "id").strip()
    if not is_valid_name(record_key_field):
        _print_error("record_key_field 必须是小写 snake_case")
        return 1

    manifest = load_manifest(module_root)
    try:
        payload: dict[str, Any] = {
            "id": resource_id,
            "storage_mode": storage_mode,
            "record_key_field": record_key_field,
            "indexes": {},
            "cleanup_policy": "drop_table" if storage_mode == "custom_table" else "delete_rows",
        }
        if storage_mode == "custom_table":
            payload["schema"] = {
                "version": 1,
                "columns": [
                    {"key": record_key_field, "type": "text", "required": True},
                ],
            }
        else:
            payload["schema"] = {
                "version": 1,
                "columns": [
                    {"key": record_key_field, "type": "text", "required": True},
                ],
            }
        _append_unique_data_entry(manifest, "resources", resource_id, payload)
        save_manifest(module_root, manifest)
    except CLIError as exc:
        _print_error(str(exc))
        return 1

    _print_success(f"已登记数据资源: {resource_id}")
    return 0


def cmd_data_view_create(args: argparse.Namespace) -> int:
    module_root = require_module_root()
    view_id = str(args.name or "").strip()
    if not is_valid_name(view_id):
        _print_error("视图名必须是小写 snake_case")
        return 1
    source_ids = [str(item or "").strip() for item in list(args.source or []) if str(item or "").strip()]
    if not source_ids or any(not is_valid_name(item) for item in source_ids):
        _print_error("--source 至少提供一个已注册资源 ID，且必须是小写 snake_case")
        return 1

    manifest = load_manifest(module_root)
    first_resource = _manifest_resource_entry(manifest, source_ids[0])
    if first_resource is None:
        _print_error(f"未找到资源: {source_ids[0]}")
        return 1
    if str(first_resource.get("storage_mode") or "managed_dataset").strip().lower() != "custom_table":
        _print_error(f"视图只能建立在 custom_table 资源上: {source_ids[0]}")
        return 1
    for resource_id in source_ids[1:]:
        resource = _manifest_resource_entry(manifest, resource_id)
        if resource is None:
            _print_error(f"未找到资源: {resource_id}")
            return 1
        if str(resource.get("storage_mode") or "managed_dataset").strip().lower() != "custom_table":
            _print_error(f"视图只能建立在 custom_table 资源上: {resource_id}")
            return 1

    record_key_field = str(first_resource.get("record_key_field") or "id").strip() or "id"
    sql_path = f"data/sql/views/{view_id}.sql"
    sql_template = f"SELECT {record_key_field}\nFROM {{{{resource:{source_ids[0]}}}}}\n"

    try:
        _write_text(module_root / sql_path, sql_template, force=args.force)
        _append_unique_data_entry(
            manifest,
            "views",
            view_id,
            {
                "id": view_id,
                "view_kind": "sql_view",
                "source_resource_ids": source_ids,
                "sql_file": sql_path,
                "columns": [
                    {
                        "name": record_key_field,
                        "type": "text",
                        "nullable": False,
                        "filterable": True,
                        "sortable": True,
                    }
                ],
                "cleanup_policy": "drop_view",
                "schema_version": 1,
            },
        )
        save_manifest(module_root, manifest)
    except CLIError as exc:
        _print_error(str(exc))
        return 1

    _print_success(f"已创建视图骨架: {view_id}")
    return 0


def cmd_data_query_create(args: argparse.Namespace) -> int:
    module_root = require_module_root()
    query_id = str(args.name or "").strip()
    if not is_valid_name(query_id):
        _print_error("查询名必须是小写 snake_case")
        return 1
    source_ids = [str(item or "").strip() for item in list(args.source or []) if str(item or "").strip()]
    if not source_ids or any(not is_valid_name(item) for item in source_ids):
        _print_error("--source 至少提供一个已注册资源 ID，且必须是小写 snake_case")
        return 1

    manifest = load_manifest(module_root)
    first_resource = _manifest_resource_entry(manifest, source_ids[0])
    if first_resource is None:
        _print_error(f"未找到资源: {source_ids[0]}")
        return 1
    if str(first_resource.get("storage_mode") or "managed_dataset").strip().lower() != "custom_table":
        _print_error(f"命名查询只能建立在 custom_table 资源上: {source_ids[0]}")
        return 1
    for resource_id in source_ids[1:]:
        resource = _manifest_resource_entry(manifest, resource_id)
        if resource is None:
            _print_error(f"未找到资源: {resource_id}")
            return 1
        if str(resource.get("storage_mode") or "managed_dataset").strip().lower() != "custom_table":
            _print_error(f"命名查询只能建立在 custom_table 资源上: {resource_id}")
            return 1

    record_key_field = str(first_resource.get("record_key_field") or "id").strip() or "id"
    sql_path = f"data/sql/queries/{query_id}.sql"
    sql_template = (
        f"SELECT {record_key_field}\n"
        f"FROM {{{{resource:{source_ids[0]}}}}}\n"
        f"WHERE {record_key_field} = :{record_key_field}\n"
        "LIMIT 1\n"
    )
    try:
        _write_text(module_root / sql_path, sql_template, force=args.force)
        _append_unique_data_entry(
            manifest,
            "queries",
            query_id,
            {
                "id": query_id,
                "source_resource_ids": source_ids,
                "sql_file": sql_path,
                "params": [
                    {"name": record_key_field, "type": "text", "required": True},
                ],
                "columns": [
                    {"name": record_key_field, "type": "text", "nullable": False},
                ],
            },
        )
        save_manifest(module_root, manifest)
    except CLIError as exc:
        _print_error(str(exc))
        return 1

    _print_success(f"已创建命名查询骨架: {query_id}")
    return 0


def cmd_data_seed_create(args: argparse.Namespace) -> int:
    module_root = require_module_root()
    seed_id = str(args.name or "").strip()
    if not is_valid_name(seed_id):
        _print_error("种子名必须是小写 snake_case")
        return 1
    resource_id = str(args.resource or "").strip()
    if not is_valid_name(resource_id):
        _print_error("--resource 必须是已注册资源 ID")
        return 1

    manifest = load_manifest(module_root)
    resource = _manifest_resource_entry(manifest, resource_id)
    if resource is None:
        _print_error(f"未找到资源: {resource_id}")
        return 1

    seed_path = f"data/seeds/{seed_id}.json"
    payload = []
    if str(resource.get("storage_mode") or "").strip().lower() == "custom_table":
        payload = [{str(resource.get("record_key_field") or "id"): "sample-id"}]

    try:
        _write_text(module_root / seed_path, json.dumps(payload, ensure_ascii=False, indent=2) + "\n", force=args.force)
        _append_unique_data_entry(
            manifest,
            "seeds",
            seed_id,
            {
                "id": seed_id,
                "resource_id": resource_id,
                "file": seed_path,
                "format": "json",
                "mode": str(args.mode or "replace_if_empty").strip().lower(),
            },
        )
        save_manifest(module_root, manifest)
    except CLIError as exc:
        _print_error(str(exc))
        return 1

    _print_success(f"已创建种子骨架: {seed_id}")
    return 0


def _run_check(level: str, module_root: Path) -> int:
    manifest = load_manifest(module_root)
    if level == "structure":
        errors = collect_structure_errors(module_root, manifest)
    elif level == "release":
        errors = collect_release_errors(module_root, manifest)
    elif level == "full":
        errors = collect_full_errors(module_root, manifest)
    else:  # pragma: no cover - parser guards this
        raise CLIError(f"未知校验级别: {level}")

    if errors:
        _print_error(f"{level} 校验失败")
        for item in errors:
            print(f"  - {item}")
        return 1

    _print_success(f"{level} 校验通过")
    return 0


def _archive_members(module_root: Path, archive_root: str) -> list[tuple[Path, str]]:
    ignored_dirs = {
        ".git",
        ".idea",
        ".venv",
        ".vscode",
        ".pytest_cache",
        ".mypy_cache",
        ".ruff_cache",
        "__pycache__",
        "build",
        "dist",
    }
    ignored_files = {".DS_Store"}
    members: list[tuple[Path, str]] = []
    for path in module_root.rglob("*"):
        relative = path.relative_to(module_root)
        if any(part in ignored_dirs for part in relative.parts):
            continue
        if any(part.endswith(".egg-info") for part in relative.parts):
            continue
        if path.is_dir():
            continue
        if path.name in ignored_files:
            continue
        if path.suffix in {".pyc", ".pyo"}:
            continue
        arcname = f"{archive_root}/{relative.as_posix()}"
        members.append((path, arcname))
    return members


def _validate_archive_structure(archive_path: Path) -> tuple[str, list[str]]:
    with zipfile.ZipFile(archive_path, "r") as zf:
        names = [name for name in zf.namelist() if name and not name.startswith("__MACOSX/")]
        roots = {name.split("/", 1)[0] for name in names if "/" in name}
        if len(roots) != 1:
            raise CLIError("ZIP 包结构无效，应仅包含一个根目录")
        root_dir = roots.pop()
        if f"{root_dir}/module.yaml" not in names:
            raise CLIError("ZIP 包缺少根目录下的 module.yaml")
        return root_dir, names


def _extract_archive_to_temp(archive_path: Path) -> Path:
    temp_dir = Path(tempfile.mkdtemp(prefix="crawler4j_sdk_verify_"))
    with zipfile.ZipFile(archive_path, "r") as zf:
        zf.extractall(temp_dir)
    root_dir, _ = _validate_archive_structure(archive_path)
    return temp_dir / root_dir


def _fetch_latest_release(
    repo: str,
    *,
    allow_prerelease: bool = False,
    github_token: str | None = None,
) -> dict[str, Any]:
    request = urllib.request.Request(
        f"https://api.github.com/repos/{repo}/releases",
        headers=_github_headers(
            accept="application/vnd.github+json",
            github_token=github_token,
        ),
    )
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        message = _read_http_error_message(exc)
        raise CLIError(f"GitHub 请求失败 ({exc.code}): {message}") from exc

    if not isinstance(payload, list) or not payload:
        raise CLIError(f"仓库 {repo} 没有可用的 GitHub Release")

    for item in payload:
        if not isinstance(item, dict) or item.get("draft"):
            continue
        if item.get("prerelease") and not allow_prerelease:
            continue
        assets = item.get("assets") or []
        zip_assets = [
            asset
            for asset in assets
            if isinstance(asset, dict)
            and str(asset.get("name", "")).lower().endswith(".zip")
            and asset.get("browser_download_url")
        ]
        if len(zip_assets) != 1:
            raise CLIError("每个 Release 必须且只能上传一个 ZIP 安装包")
        tag = str(item.get("tag_name", "") or item.get("name", "") or "").strip().lstrip("v")
        if not is_valid_semver(tag):
            raise CLIError(f"Release 版本号无效: {tag or '<empty>'}")
        return {
            "version": tag,
            "tag_name": str(item.get("tag_name", "") or "").strip(),
            "title": str(item.get("name", "") or item.get("tag_name", "") or "").strip(),
            "published_at": str(item.get("published_at", "") or "").strip(),
            "asset_name": str(zip_assets[0].get("name", "") or "").strip(),
            "asset_download_url": str(zip_assets[0].get("browser_download_url", "") or "").strip(),
            "asset_api_url": str(zip_assets[0].get("url", "") or "").strip(),
            "html_url": str(item.get("html_url", "") or "").strip(),
        }

    if allow_prerelease:
        raise CLIError(f"仓库 {repo} 没有可用的 GitHub Release")
    raise CLIError(f"仓库 {repo} 没有稳定版 GitHub Release")


def cmd_module_init(args: argparse.Namespace) -> int:
    """Initialize a new module project."""
    module_name = str(args.name or "").strip()
    repo = str(args.repo or "").strip()
    if not is_valid_name(module_name):
        _print_error("模块名必须是小写 snake_case，并且能作为 Python 包名导入")
        return 1
    if not is_valid_repo(repo):
        _print_error("`--repo` 必须是 owner/repo 形式")
        return 1
    if not is_valid_name(args.workflow_name):
        _print_error("默认工作流名必须是小写 snake_case")
        return 1
    if not is_valid_semver(args.version):
        _print_error("模块版本必须是合法语义化版本号")
        return 1

    output_dir = Path(args.output).expanduser().resolve() if args.output else Path.cwd() / module_name
    if output_dir.exists() and not output_dir.is_dir():
        _print_error(f"目标路径不是目录: {output_dir}")
        return 1
    if output_dir.exists() and any(output_dir.iterdir()) and not args.force:
        _print_error(f"目标目录已存在且非空: {output_dir}")
        return 1

    display_name = args.display_name or to_display_name(module_name)
    description = args.description or f"{display_name} 模块"
    workflow_display_name = args.workflow_display_name or to_display_name(args.workflow_name)
    workflow_description = args.workflow_description or f"{workflow_display_name} 工作流"
    contracts_dependency_spec = get_compatible_contracts_dependency_spec()
    sdk_dependency_spec = get_compatible_sdk_dependency_spec()

    output_dir.mkdir(parents=True, exist_ok=True)
    for subdir in [
        "tasks",
        "workflows",
        "pages",
        "hooks",
        "env_selectors",
        "tests",
        "data",
        "data/sql",
        "data/sql/views",
        "data/sql/queries",
        "data/seeds",
    ]:
        (output_dir / subdir).mkdir(parents=True, exist_ok=True)

    try:
        _write_text(
            output_dir / "pyproject.toml",
            MODEL_PROJECT_PYPROJECT.format(
                project_name=module_name,
                version=args.version,
                display_name=display_name,
                python_version=args.python_version,
                contracts_dependency_spec=contracts_dependency_spec,
                sdk_dependency_spec=sdk_dependency_spec,
            ),
            force=args.force,
        )
        _write_text(
            output_dir / "README.md",
            MODEL_PROJECT_README.format(display_name=display_name),
            force=args.force,
        )
        _write_text(
            output_dir / "__init__.py",
            MODEL_MODULE_INIT.format(display_name=display_name),
            force=args.force,
        )
        _write_text(
            output_dir / "tasks" / "__init__.py",
            "",
            force=args.force,
        )
        _write_text(
            output_dir / "workflows" / "__init__.py",
            "",
            force=args.force,
        )
        _write_text(
            output_dir / "pages" / "__init__.py",
            MODEL_PAGES_INIT_TEMPLATE,
            force=args.force,
        )
        _write_text(
            output_dir / "hooks" / "__init__.py",
            MODEL_HOOKS_INIT_TEMPLATE,
            force=args.force,
        )
        _write_text(
            output_dir / "env_selectors" / "__init__.py",
            MODEL_SELECTORS_INIT_TEMPLATE,
            force=args.force,
        )
        _write_text(
            output_dir / "module.yaml",
            MODEL_MANIFEST_TEMPLATE.format(
                module_name=module_name,
                version=args.version,
                display_name=display_name,
                description=description,
                repo=repo,
                workflow_name=args.workflow_name,
                workflow_display_name=workflow_display_name,
                workflow_description=workflow_description,
            ),
            force=args.force,
        )
        _write_text(
            output_dir / "tasks" / "example_task.py",
            SCRIPT_TEMPLATE.format(
                name="example_task",
                display_name="示例任务",
                description="示例任务脚本",
            ),
            force=args.force,
        )
        _write_text(
            output_dir / "workflows" / f"{args.workflow_name}.py",
            WORKFLOW_TEMPLATE.format(
                name=args.workflow_name,
                display_name=workflow_display_name,
                description=workflow_description,
            ),
            force=args.force,
        )
        for hook_name in HOOK_NAMES:
            _write_text(
                output_dir / "hooks" / f"{hook_name}.py",
                render_hook_template(hook_name),
                force=args.force,
            )
        _write_text(
            output_dir / "env_selectors" / "return_none.py",
            RETURN_NONE_SELECTOR_TEMPLATE,
            force=args.force,
        )
        _write_text(
            output_dir / "env_selectors" / "random_ready.py",
            RANDOM_READY_SELECTOR_TEMPLATE,
            force=args.force,
        )
        _write_text(output_dir / "tests" / "test_tasks.py", MODEL_TEST_TASK_TEMPLATE, force=args.force)
        _write_text(output_dir / "tests" / "__init__.py", "", force=args.force)
        _write_text(output_dir / ".gitignore", MODEL_GITIGNORE_TEMPLATE, force=args.force)
        _write_text(output_dir / ".python-version", f"{args.python_version}\n", force=args.force)
    except CLIError as exc:
        _print_error(str(exc))
        return 1

    try:
        if not args.no_git:
            _safe_run(["git", "init"], cwd=output_dir)
        if not args.no_install:
            _safe_run(["uv", "sync"], cwd=output_dir)
    except (subprocess.CalledProcessError, FileNotFoundError) as exc:
        _print_error(f"自动初始化失败: {exc}")
        return 1

    _print_success(f"已初始化模块项目: {output_dir}")
    print("  - 命令入口: `crawler4j module show`")
    print("  - 新建任务: `crawler4j task create <name>`")
    print("  - 新建工作流: `crawler4j workflow create <name>`")
    print("  - 新建页面: `crawler4j page create <page_id>`")
    print("  - 新建 Hook: `crawler4j hook create <hook_name>`")
    print("  - 新建选择器: `crawler4j env-selector create <name>`")
    print("  - 新建数据资源: `crawler4j data resource create <name>`")
    print("  - 新建命名查询: `crawler4j data query create <name> --source <resource>`")
    print("  - 完整校验: `crawler4j check full`")
    return 0


def cmd_module_show(args: argparse.Namespace) -> int:
    """Show the current module summary."""
    del args
    module_root = require_module_root()
    manifest = load_manifest(module_root)
    hosted_pages = _manifest_ui_pages(manifest)
    workflow_names = _manifest_workflow_names(manifest)
    default_workflow = _manifest_default_workflow(manifest) or (workflow_names[0] if workflow_names else "")

    print(f"模块目录: {module_root}")
    print(f"模块名: {manifest.get('name', '')}")
    print(f"运行时协议: {manifest.get('runtime_api', '')}")
    print(f"版本: {manifest.get('version', '')}")
    print(f"仓库: {(manifest.get('upgrade_source') or {}).get('repo', '')}")
    print(f"默认工作流: {default_workflow}")
    print(f"任务: {', '.join(_list_python_modules(module_root / 'tasks')) or '(无)'}")
    print(f"工作流: {', '.join(workflow_names) or '(无)'}")
    print(
        "宿主页: "
        + (
            ", ".join(str(item.get("id", "")) for item in hosted_pages if item.get("id"))
            or "(无)"
        )
    )
    data = manifest.get("data") if isinstance(manifest.get("data"), dict) else {}
    for section in ("resources", "views", "queries", "seeds"):
        items = data.get(section)
        count = len(items) if isinstance(items, list) else 0
        print(f"数据 {section}: {count}")
    return 0


def cmd_module_set_repo(args: argparse.Namespace) -> int:
    """Set manifest upgrade_source.repo."""
    module_root = require_module_root()
    if not is_valid_repo(args.repo):
        _print_error("仓库必须是 owner/repo 形式")
        return 1
    manifest = load_manifest(module_root)
    upgrade_source = manifest.setdefault("upgrade_source", {})
    if not isinstance(upgrade_source, dict):
        _print_error("module.yaml.upgrade_source 必须是映射对象")
        return 1
    upgrade_source["type"] = "github_release"
    upgrade_source["repo"] = args.repo
    upgrade_source.setdefault("allow_prerelease", False)
    save_manifest(module_root, manifest)
    _print_success(f"已设置升级仓库: {args.repo}")
    return 0


def cmd_module_set_version(args: argparse.Namespace) -> int:
    """Set manifest version."""
    module_root = require_module_root()
    if not is_valid_semver(args.version):
        _print_error("版本号必须是合法语义化版本")
        return 1
    try:
        _set_project_version(module_root / "pyproject.toml", args.version)
    except CLIError as exc:
        _print_error(str(exc))
        return 1
    manifest = load_manifest(module_root)
    manifest["version"] = args.version
    save_manifest(module_root, manifest)
    _print_success(f"已设置模块版本: {args.version}")
    return 0


def cmd_module_set_default_workflow(args: argparse.Namespace) -> int:
    """Set module.yaml.default_workflow."""
    module_root = require_module_root()
    manifest = load_manifest(module_root)
    workflow_name = str(args.workflow or "").strip()
    if workflow_name not in _manifest_workflow_names(manifest):
        _print_error(f"未声明的 workflow: {workflow_name}")
        return 1
    manifest["default_workflow"] = workflow_name
    save_manifest(module_root, manifest)
    _print_success(f"已设置默认工作流: {workflow_name}")
    return 0


def cmd_module_repair_init(args: argparse.Namespace) -> int:
    """Rebuild the module root __init__.py from the current standard template."""
    del args
    module_root = require_module_root()
    manifest = load_manifest(module_root)
    try:
        _write_text(
            module_root / "__init__.py",
            MODEL_MODULE_INIT.format(display_name=_module_display_name(module_root, manifest)),
            force=True,
        )
    except CLIError as exc:
        _print_error(str(exc))
        return 1
    _print_success("已重建模块根包文件: __init__.py")
    return 0


def cmd_task_create(args: argparse.Namespace) -> int:
    """Create a task script under tasks/."""
    module_root = require_module_root()
    name = str(args.name or "").strip()
    if not is_valid_name(name):
        _print_error("任务名必须是小写 snake_case")
        return 1
    try:
        _write_text(
            module_root / "tasks" / f"{name}.py",
            SCRIPT_TEMPLATE.format(
                name=name,
                display_name=to_display_name(name),
                description=f"{to_display_name(name)} 任务",
            ),
            force=args.force,
        )
    except CLIError as exc:
        _print_error(str(exc))
        return 1
    _print_success(f"已创建任务脚本: tasks/{name}.py")
    return 0


def cmd_task_list(args: argparse.Namespace) -> int:
    """List task scripts in the current module."""
    del args
    module_root = require_module_root()
    tasks = _list_python_modules(module_root / "tasks")
    print("\n".join(tasks) if tasks else "(无任务)")
    return 0


def cmd_workflow_create(args: argparse.Namespace) -> int:
    """Create a workflow file and register it in module.yaml."""
    module_root = require_module_root()
    name = str(args.name or "").strip()
    if not is_valid_name(name):
        _print_error("工作流名必须是小写 snake_case")
        return 1
    manifest = load_manifest(module_root)
    try:
        _write_text(
            module_root / "workflows" / f"{name}.py",
            WORKFLOW_TEMPLATE.format(
                name=name,
                display_name=args.display_name or to_display_name(name),
                description=args.description or f"{to_display_name(name)} 工作流",
            ),
            force=args.force,
        )
    except CLIError as exc:
        _print_error(str(exc))
        return 1

    workflows = _manifest_workflows(manifest)
    if not any(isinstance(item, dict) and item.get("name") == name for item in workflows):
        workflows.append(
            {
                "name": name,
                "display_name": args.display_name or to_display_name(name),
                "description": args.description or f"{to_display_name(name)} 工作流",
            }
        )
    if not _manifest_default_workflow(manifest):
        manifest["default_workflow"] = name
    save_manifest(module_root, manifest)
    _print_success(f"已创建工作流: workflows/{name}.py")
    return 0


def cmd_workflow_list(args: argparse.Namespace) -> int:
    """List workflows declared in module.yaml."""
    del args
    module_root = require_module_root()
    manifest = load_manifest(module_root)
    names = _manifest_workflow_names(manifest)
    print("\n".join(names) if names else "(无工作流)")
    return 0


def cmd_page_create(args: argparse.Namespace) -> int:
    """Create a hosted page scaffold inside pages/ and optionally add it to navigation."""
    module_root = require_module_root()
    name = str(args.name or "").strip()
    if not is_valid_name(name):
        _print_error("页面名必须是小写 snake_case")
        return 1
    try:
        page_relative_path = _page_source_relative_path(name, group=getattr(args, "group", None))
    except CLIError as exc:
        _print_error(str(exc))
        return 1

    manifest = load_manifest(module_root)
    ui_errors = _validate_ui_extension(manifest)
    if ui_errors:
        _print_error("module.yaml.ui_extension 不符合 Hosted UI V1 契约")
        for item in ui_errors:
            print(f"  - {item}")
        return 1
    legacy_ui_errors = _collect_legacy_hosted_ui_errors(module_root)
    if legacy_ui_errors:
        _print_error("检测到旧 Hosted UI 产物，请先移除后再创建宿主页")
        for item in legacy_ui_errors:
            print(f"  - {item}")
        return 1
    _ensure_package_dir(module_root / "pages")
    no_menu = bool(getattr(args, "no_menu", False))
    if not no_menu:
        pages = _normalize_ui_pages(manifest)
        existing_page = next(
            (item for item in pages if isinstance(item, dict) and item.get("id") == name),
            None,
        )
        if existing_page is not None:
            if not args.force:
                _print_error(f"页面入口已存在: {name}")
                return 1
            existing_page["label"] = args.display_name or to_display_name(name)
            existing_page["icon"] = "📄"
        else:
            pages.append(
                {
                    "id": name,
                    "label": args.display_name or to_display_name(name),
                    "icon": "📄",
                }
            )
    try:
        _write_text(
            module_root / page_relative_path,
            render_page_template(
                page_id=name,
                display_name=args.display_name or to_display_name(name),
                description=args.description or f"{to_display_name(name)} 宿主页",
            ),
            force=args.force,
        )
    except CLIError as exc:
        _print_error(str(exc))
        return 1

    if not no_menu:
        save_manifest(module_root, manifest)
    _print_success(f"已创建宿主页骨架: {page_relative_path.as_posix()}")
    return 0


def cmd_page_list(args: argparse.Namespace) -> int:
    """List left-menu hosted pages declared in module.yaml."""
    del args
    module_root = require_module_root()
    manifest = load_manifest(module_root)
    pages = [str(item.get("id", "")) for item in _manifest_ui_pages(manifest) if item.get("id")]
    print("\n".join(pages) if pages else "(无页面)")
    return 0


def cmd_env_selector_create(args: argparse.Namespace) -> int:
    """Create a new env-selector module under env_selectors/."""
    module_root = require_module_root()
    name = str(args.name or "").strip()
    force = bool(getattr(args, "force", False))
    if not is_valid_name(name):
        _print_error("环境选择器名必须是小写 snake_case")
        return 1
    _ensure_package_dir(module_root / "env_selectors")
    selector_path = module_root / "env_selectors" / f"{name}.py"
    if selector_path.exists() and not force:
        _print_error(f"环境选择器已存在: {name}")
        return 1
    try:
        _write_text(
            selector_path,
            render_selector_template(
                name=name,
                display_name=args.display_name or to_display_name(name),
                description=args.description or f"{to_display_name(name)} 环境选择器",
            ),
            force=force,
        )
    except CLIError as exc:
        _print_error(str(exc))
        return 1
    _print_success(f"已创建环境选择器: env_selectors/{name}.py")
    return 0


def cmd_env_selector_list(args: argparse.Namespace) -> int:
    """List env-selector declarations."""
    del args
    module_root = require_module_root()
    manifest = load_manifest(module_root)
    module_name = _resolve_module_import_name(module_root, manifest)
    selectors: list[str] = []
    for selector_name in _list_python_modules(module_root / "env_selectors"):
        try:
            module = _import_module_child(module_root, module_name, "env_selectors", selector_name)
        except Exception as exc:
            _print_error(f"读取环境选择器失败: {exc.__class__.__name__}: {exc}")
            return 1
        selector = getattr(module, "SELECTOR", None)
        if not isinstance(selector, EnvSelectorSpec):
            _print_error(f"env_selectors/{selector_name}.py 缺少 SELECTOR")
            return 1
        selectors.append(selector.name)

    print("\n".join(selectors) if selectors else "(无环境选择器)")
    return 0


def cmd_hook_create(args: argparse.Namespace) -> int:
    """Create or refresh a lifecycle hook scaffold under hooks/."""
    module_root = require_module_root()
    name = str(args.name or "").strip()
    force = bool(getattr(args, "force", False))
    if not _is_known_hook(name):
        _print_error("Hook 名必须是标准生命周期入口之一")
        return 1

    _ensure_package_dir(module_root / "hooks")

    try:
        _write_text(
            module_root / "hooks" / f"{name}.py",
            render_hook_template(name),
            force=force,
        )
    except CLIError as exc:
        _print_error(str(exc))
        return 1

    _print_success(f"已创建 Hook 骨架: hooks/{name}.py")
    return 0


def cmd_hook_list(args: argparse.Namespace) -> int:
    """List lifecycle hook files in hooks/."""
    del args
    module_root = require_module_root()
    hooks = _list_python_modules(module_root / "hooks")
    print("\n".join(hooks) if hooks else "(无 Hook)")
    return 0


def cmd_config_show(args: argparse.Namespace) -> int:
    """Show config_defaults from module.yaml."""
    del args
    module_root = require_module_root()
    manifest = load_manifest(module_root)
    config_defaults = manifest.get("config_defaults") or {"module": {}, "workflows": {}}
    print(_render_yaml(config_defaults))
    return 0


def cmd_config_set_module(args: argparse.Namespace) -> int:
    """Set module-level default config from a YAML file."""
    module_root = require_module_root()
    manifest = load_manifest(module_root)
    config_defaults = _normalize_config_defaults(manifest)
    config_defaults["module"] = _load_yaml_mapping(Path(args.file).expanduser().resolve())
    save_manifest(module_root, manifest)
    _print_success("已更新模块级默认配置")
    return 0


def cmd_config_set_workflow(args: argparse.Namespace) -> int:
    """Set workflow-level default config from a YAML file."""
    module_root = require_module_root()
    manifest = load_manifest(module_root)
    workflow_name = str(args.workflow or "").strip()
    if workflow_name not in _manifest_workflow_names(manifest):
        _print_error(f"未声明的 workflow: {workflow_name}")
        return 1
    config_defaults = _normalize_config_defaults(manifest)
    config_defaults["workflows"][workflow_name] = _load_yaml_mapping(
        Path(args.file).expanduser().resolve()
    )
    save_manifest(module_root, manifest)
    _print_success(f"已更新工作流默认配置: {workflow_name}")
    return 0


def cmd_config_lint(args: argparse.Namespace) -> int:
    """Validate config_defaults structure and workflow references."""
    del args
    module_root = require_module_root()
    manifest = load_manifest(module_root)
    config_defaults = manifest.get("config_defaults", {})
    test_manifest = dict(manifest)
    test_manifest["config_defaults"] = config_defaults
    errors = collect_release_errors(module_root, test_manifest)
    config_errors = [item for item in errors if item.startswith("config_defaults")]
    if config_errors:
        _print_error("默认配置校验失败")
        for item in config_errors:
            print(f"  - {item}")
        return 1
    _print_success("默认配置校验通过")
    return 0


def cmd_package_build(args: argparse.Namespace) -> int:
    """Build an installable single-root ZIP package for the current module."""
    module_root = require_module_root()
    if _run_check("full", module_root) != 0:
        return 1

    manifest = load_manifest(module_root)
    archive_root = _resolve_module_import_name(module_root, manifest)
    version = str(manifest.get("version", "") or "").strip()
    output = (
        Path(args.output).expanduser().resolve()
        if args.output
        else module_root / "dist" / f"{archive_root}-{version}.zip"
    )
    output.parent.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for source, arcname in _archive_members(module_root, archive_root):
            zf.write(source, arcname)

    try:
        _validate_archive_structure(output)
    except CLIError as exc:
        _print_error(str(exc))
        return 1

    _print_success(f"已生成安装包: {output}")
    return 0


def cmd_package_verify(args: argparse.Namespace) -> int:
    """Verify a ZIP package follows the expected module archive layout."""
    archive_path = Path(args.archive).expanduser().resolve()
    if not archive_path.exists():
        _print_error(f"找不到 ZIP 文件: {archive_path}")
        return 1

    extracted_root: Path | None = None
    try:
        _validate_archive_structure(archive_path)
        extracted_root = _extract_archive_to_temp(archive_path)
        manifest = load_manifest(extracted_root)
        errors = collect_full_errors(extracted_root, manifest)
    except (CLIError, zipfile.BadZipFile) as exc:
        _print_error(str(exc))
        return 1
    finally:
        if extracted_root:
            shutil.rmtree(extracted_root.parent, ignore_errors=True)

    if errors:
        _print_error("ZIP 校验失败")
        for item in errors:
            print(f"  - {item}")
        return 1

    _print_success("ZIP 校验通过")
    return 0


def cmd_release_status(args: argparse.Namespace) -> int:
    """Show local release readiness for the current module."""
    del args
    module_root = require_module_root()
    manifest = load_manifest(module_root)
    errors = collect_release_errors(module_root, manifest)
    archive_root = _resolve_module_import_name(module_root, manifest)
    version = str(manifest.get("version", "") or "").strip()
    repo = str((manifest.get("upgrade_source") or {}).get("repo", "") or "").strip()
    archive_path = module_root / "dist" / f"{archive_root}-{version}.zip"

    print(f"模块: {manifest.get('name', '')}")
    print(f"版本: {version}")
    print(f"仓库: {repo or '(未设置)'}")
    print(f"安装包: {archive_path if archive_path.exists() else '(未构建)'}")
    if errors:
        print("发布状态: BLOCKED")
        for item in errors:
            print(f"  - {item}")
        return 1

    print("发布状态: READY")
    return 0


def cmd_release_check_remote(args: argparse.Namespace) -> int:
    """Compare local manifest version against the latest GitHub Release."""
    module_root = require_module_root()
    manifest = load_manifest(module_root)
    repo = str((manifest.get("upgrade_source") or {}).get("repo", "") or "").strip()
    if not is_valid_repo(repo):
        _print_error("module.yaml.upgrade_source.repo 不是合法的 owner/repo")
        return 1

    allow_prerelease = bool((manifest.get("upgrade_source") or {}).get("allow_prerelease", False))
    local_version = str(manifest.get("version", "") or "").strip()
    try:
        remote = _fetch_latest_release(
            repo,
            allow_prerelease=allow_prerelease,
            github_token=getattr(args, "github_token", None),
        )
    except (CLIError, urllib.error.URLError) as exc:
        _print_error(f"远端版本检查失败: {exc}")
        return 1

    relation = "equal"
    if _compare_versions(local_version, remote["version"]) < 0:
        relation = "behind"
    elif _compare_versions(local_version, remote["version"]) > 0:
        relation = "ahead"

    print(f"本地版本: {local_version}")
    print(f"远端版本: {remote['version']}")
    print(f"Release: {remote['title'] or remote['tag_name']}")
    print(f"安装包: {remote['asset_name']}")
    print(f"状态: {relation}")
    return 0


def cmd_release_publish(args: argparse.Namespace) -> int:
    """Publish the local ZIP asset to a GitHub Release via gh CLI."""
    module_root = require_module_root()
    manifest = load_manifest(module_root)
    archive_root = _resolve_module_import_name(module_root, manifest)
    repo = str((manifest.get("upgrade_source") or {}).get("repo", "") or "").strip()
    version = str(manifest.get("version", "") or "").strip()
    if not is_valid_repo(repo):
        _print_error("module.yaml.upgrade_source.repo 不是合法的 owner/repo")
        return 1
    if not is_valid_semver(version):
        _print_error("module.yaml.version 不是合法语义化版本")
        return 1

    tag = args.tag or f"v{version}"
    title = args.title or tag
    archive_path = (
        Path(args.archive).expanduser().resolve()
        if args.archive
        else module_root / "dist" / f"{archive_root}-{version}.zip"
    )

    if args.rebuild or not archive_path.exists():
        build_result = cmd_package_build(argparse.Namespace(output=str(archive_path)))
        if build_result != 0:
            return build_result
    elif cmd_package_verify(argparse.Namespace(archive=str(archive_path))) != 0:
        return 1

    if args.notes and args.notes_file:
        _print_error("`--notes` 和 `--notes-file` 不能同时使用")
        return 1

    notes_args: list[str] = []
    if args.notes:
        notes_args = ["--notes", args.notes]
    elif args.notes_file:
        notes_args = ["--notes-file", str(Path(args.notes_file).expanduser().resolve())]

    view_cmd = ["gh", "release", "view", tag, "--repo", repo]
    create_cmd = [
        "gh",
        "release",
        "create",
        tag,
        str(archive_path),
        "--repo",
        repo,
        "--title",
        title,
        *notes_args,
    ]
    upload_cmd = [
        "gh",
        "release",
        "upload",
        tag,
        str(archive_path),
        "--repo",
        repo,
        "--clobber",
    ]
    if args.prerelease:
        create_cmd.append("--prerelease")

    if args.dry_run:
        print("将执行以下命令：")
        print("  " + " ".join(view_cmd))
        print("  " + " ".join(create_cmd))
        print("  " + " ".join(upload_cmd))
        return 0

    try:
        view_result = subprocess.run(view_cmd, check=False, capture_output=True, text=True)
        publish_cmd = upload_cmd if view_result.returncode == 0 else create_cmd
        subprocess.run(publish_cmd, check=True, capture_output=True, text=True)
    except FileNotFoundError:
        _print_error("未找到 `gh` 命令；请先安装 GitHub CLI 并完成登录")
        return 1
    except subprocess.CalledProcessError as exc:
        _print_error(exc.stderr.strip() or exc.stdout.strip() or str(exc))
        return 1

    _print_success(f"已发布 Release 资产: {repo} {tag}")
    return 0


def cmd_host_devlink_add(args: argparse.Namespace) -> int:
    """Register a local module path as a dev link in the host runtime."""
    runtime = _load_host_runtime()
    _init_host_runtime(runtime)
    registry = runtime["get_module_registry"]()
    module = registry.register_dev_link(Path(args.module_root).expanduser().resolve())
    _print_success("已注册 DevLink 模块")
    _print_module_info(module)
    return 0


def cmd_host_devlink_remove(args: argparse.Namespace) -> int:
    """Remove a dev link from the host runtime."""
    runtime = _load_host_runtime()
    _init_host_runtime(runtime)
    registry = runtime["get_module_registry"]()
    removed = registry.remove_dev_link(args.module_name)
    if not removed:
        _print_error(f"找不到 DevLink 模块: {args.module_name}")
        return 1
    _print_success(f"已移除 DevLink: {args.module_name}")
    return 0


def cmd_host_devlink_list(args: argparse.Namespace) -> int:
    """List host dev links."""
    del args
    runtime = _load_host_runtime()
    _init_host_runtime(runtime)
    registry = runtime["get_module_registry"]()
    links = list(registry.list_dev_links())
    if not links:
        print("(无 DevLink)")
        return 0
    for item in links:
        print(f"{item.module_name}\t{item.source_path}")
    return 0


def cmd_host_install_preview(args: argparse.Namespace) -> int:
    """Preview installing a local ZIP or GitHub repo into the host runtime."""
    runtime = _load_host_runtime()
    _init_host_runtime(runtime)
    registry = runtime["get_module_registry"]()
    service = runtime["get_module_release_service"]()
    source_kind, source_value = _detect_install_source(args.source)

    if source_kind == "dir":
        _print_error("目录源码请走 `crawler4j host devlink add <module_root>`，不要走 install")
        return 1
    if source_kind == "file":
        _print_error("install 目前只支持 ZIP 安装包或 GitHub 仓库")
        return 1

    try:
        if source_kind == "zip" and args.skip_remote_check:
            manifest, warnings = registry.validate_source(source_value)
            _print_preview(
                source_label="本地 ZIP（跳过远端仓库校验）",
                manifest=manifest,
                warnings=warnings,
                archive_path=Path(source_value),
            )
            return 0

        if source_kind == "zip":
            preview = _run_async(
                service.prepare_local_install(
                    source_value,
                    github_token=getattr(args, "github_token", None),
                )
            )
        else:
            preview = _run_async(
                service.prepare_github_install(
                    str(source_value),
                    github_token=getattr(args, "github_token", None),
                )
            )
    except Exception as exc:
        _print_error(str(exc))
        return 1

    _print_preview(
        source_label=preview.source_label,
        manifest=preview.manifest,
        warnings=list(preview.warnings),
        archive_path=preview.archive_path,
        release=preview.release,
    )
    return 0


def cmd_host_install_apply(args: argparse.Namespace) -> int:
    """Install a local ZIP or GitHub repo into the host runtime."""
    runtime = _load_host_runtime()
    _init_host_runtime(runtime)
    registry = runtime["get_module_registry"]()
    service = runtime["get_module_release_service"]()
    source_kind, source_value = _detect_install_source(args.source)

    if source_kind == "dir":
        _print_error("目录源码请走 `crawler4j host devlink add <module_root>`，不要走 install")
        return 1
    if source_kind == "file":
        _print_error("install 目前只支持 ZIP 安装包或 GitHub 仓库")
        return 1

    try:
        if source_kind == "zip" and args.skip_remote_check:
            module = registry.install(source_value)
        elif source_kind == "zip":
            preview = _run_async(
                service.prepare_local_install(
                    source_value,
                    github_token=getattr(args, "github_token", None),
                )
            )
            module = registry.install(preview.archive_path or source_value)
        else:
            preview = _run_async(
                service.prepare_github_install(
                    str(source_value),
                    github_token=getattr(args, "github_token", None),
                )
            )
            module = registry.install(preview.archive_path)
    except Exception as exc:
        _print_error(str(exc))
        return 1

    _print_success("模块安装完成")
    _print_module_info(module)
    return 0


def cmd_host_upgrade_check(args: argparse.Namespace) -> int:
    """Check whether an installed external module has a newer GitHub Release."""
    runtime = _load_host_runtime()
    _init_host_runtime(runtime)
    registry = runtime["get_module_registry"]()
    service = runtime["get_module_release_service"]()
    module = registry.get_module(args.module_name)
    if not module:
        _print_error(f"找不到模块: {args.module_name}")
        return 1

    try:
        update_info = _run_async(
            service.check_for_update(
                module,
                github_token=getattr(args, "github_token", None),
            )
        )
    except Exception as exc:
        _print_error(str(exc))
        return 1

    print(f"模块名: {update_info.module_name}")
    print(f"当前版本: {update_info.current_version}")
    print(f"远端版本: {update_info.latest_version}")
    print(f"是否可升级: {'yes' if update_info.has_update else 'no'}")
    if update_info.release:
        print(f"Release 页面: {update_info.release.html_url}")
        print(f"安装包: {update_info.release.asset_name}")
    if update_info.error:
        print(f"错误: {update_info.error}")
        return 1
    return 0


def cmd_host_upgrade_preview(args: argparse.Namespace) -> int:
    """Preview upgrading an installed module from GitHub Release."""
    runtime = _load_host_runtime()
    _init_host_runtime(runtime)
    registry = runtime["get_module_registry"]()
    service = runtime["get_module_release_service"]()
    module = registry.get_module(args.module_name)
    if not module:
        _print_error(f"找不到模块: {args.module_name}")
        return 1

    try:
        preview = _run_async(
            service.prepare_module_upgrade(
                module,
                github_token=getattr(args, "github_token", None),
            )
        )
    except Exception as exc:
        _print_error(str(exc))
        return 1

    _print_preview(
        source_label=preview.source_label,
        manifest=preview.manifest,
        warnings=list(preview.warnings),
        archive_path=preview.archive_path,
        release=preview.release,
    )
    return 0


def cmd_host_upgrade_apply(args: argparse.Namespace) -> int:
    """Download and install the newer GitHub Release for an external module."""
    runtime = _load_host_runtime()
    _init_host_runtime(runtime)
    registry = runtime["get_module_registry"]()
    service = runtime["get_module_release_service"]()
    module = registry.get_module(args.module_name)
    if not module:
        _print_error(f"找不到模块: {args.module_name}")
        return 1

    try:
        preview = _run_async(
            service.prepare_module_upgrade(
                module,
                github_token=getattr(args, "github_token", None),
            )
        )
        installed = _run_async(service.apply_module_upgrade(module, preview))
    except Exception as exc:
        _print_error(str(exc))
        return 1

    _print_success("模块升级完成")
    _print_module_info(installed)
    return 0


def cmd_host_debug_config(args: argparse.Namespace) -> int:
    """Generate or update a VS Code attach configuration for module debugging."""
    runtime = _load_host_runtime()
    source_path = (
        Path(args.module_root).expanduser().resolve()
        if args.module_root
        else require_module_root()
    )
    launch_path = runtime["ensure_vscode_attach_config"](
        source_path,
        host=args.host,
        port=args.port,
        configuration_name=args.configuration_name,
    )
    _print_success(f"已生成 VS Code 调试配置: {launch_path}")
    return 0


def cmd_check_structure(args: argparse.Namespace) -> int:
    """Run structure-level validation."""
    del args
    return _run_check("structure", require_module_root())


def cmd_check_release(args: argparse.Namespace) -> int:
    """Run release-level validation."""
    del args
    return _run_check("release", require_module_root())


def cmd_check_full(args: argparse.Namespace) -> int:
    """Run full validation including importability."""
    del args
    return _run_check("full", require_module_root())


def build_parser() -> argparse.ArgumentParser:
    """Build the top-level CLI parser."""
    parser = argparse.ArgumentParser(
        prog="crawler4j",
        description="Crawler4j SDK 模块工程 CLI",
    )
    subparsers = parser.add_subparsers(dest="command")

    module_parser = subparsers.add_parser(
        "module",
        help="模块项目操作：初始化、查看和修改 module.yaml 关键字段",
    )
    module_sub = module_parser.add_subparsers(dest="action")

    module_init = module_sub.add_parser(
        "init",
        help="初始化一个新的模块项目，生成 core-native-v1 标准骨架与 module.yaml",
    )
    module_init.add_argument("name", help="模块包名，必须是 snake_case")
    module_init.add_argument("--repo", required=True, help="升级源 GitHub 仓库，格式 owner/repo")
    module_init.add_argument("--output", help="输出目录，默认在当前目录下创建同名目录")
    module_init.add_argument("--display-name", help="模块显示名")
    module_init.add_argument("--description", help="模块说明")
    module_init.add_argument("--version", default=DEFAULT_MODULE_VERSION, help="模块版本号")
    module_init.add_argument("--workflow-name", default="main_workflow", help="初始工作流名")
    module_init.add_argument("--workflow-display-name", help="初始工作流显示名")
    module_init.add_argument("--workflow-description", help="初始工作流说明")
    module_init.add_argument("--python-version", default=DEFAULT_PYTHON_VERSION, help="目标 Python 版本")
    module_init.add_argument("--no-git", action="store_true", help="不要执行 git init")
    module_init.add_argument("--no-install", action="store_true", help="不要执行 uv sync")
    module_init.add_argument("--force", action="store_true", help="允许覆盖脚手架管理文件")
    module_init.set_defaults(func=cmd_module_init)

    module_show = module_sub.add_parser(
        "show",
        help="显示当前模块的版本、仓库、默认工作流和宿主页入口",
    )
    module_show.set_defaults(func=cmd_module_show)

    module_repair_init = module_sub.add_parser(
        "repair-init",
        help="按当前标准模板重建模块根 __init__.py，不修改其他脚手架文件",
    )
    module_repair_init.set_defaults(func=cmd_module_repair_init)

    data_parser = subparsers.add_parser(
        "data",
        help="数据契约操作：维护 module.yaml.data 以及 data/sql、data/seeds 脚手架",
    )
    data_sub = data_parser.add_subparsers(dest="action")

    data_list = data_sub.add_parser(
        "list",
        help="列出当前模块已声明的数据资源、视图、命名查询和种子",
    )
    data_list.set_defaults(func=cmd_data_list)

    data_resource = data_sub.add_parser(
        "resource",
        help="创建并登记 module.yaml.data.resources 条目",
    )
    data_resource_sub = data_resource.add_subparsers(dest="subaction")
    data_resource_create = data_resource_sub.add_parser(
        "create",
        help="创建一个数据资源骨架",
    )
    data_resource_create.add_argument("name", help="资源名，snake_case")
    data_resource_create.add_argument(
        "--storage-mode",
        default="managed_dataset",
        help="存储模式：managed_dataset 或 custom_table",
    )
    data_resource_create.add_argument(
        "--record-key-field",
        default="id",
        help="记录主键字段，默认 id",
    )
    data_resource_create.set_defaults(func=cmd_data_resource_create)

    data_view = data_sub.add_parser(
        "view",
        help="创建并登记 module.yaml.data.views 条目及 SQL 文件",
    )
    data_view_sub = data_view.add_subparsers(dest="subaction")
    data_view_create = data_view_sub.add_parser(
        "create",
        help="创建一个数据库视图骨架",
    )
    data_view_create.add_argument("name", help="视图名，snake_case")
    data_view_create.add_argument(
        "--source",
        action="append",
        required=True,
        help="来源资源 ID，可重复传入多个；仅支持 custom_table",
    )
    data_view_create.add_argument("--force", action="store_true", help="允许覆盖已有 SQL 文件")
    data_view_create.set_defaults(func=cmd_data_view_create)

    data_query = data_sub.add_parser(
        "query",
        help="创建并登记 module.yaml.data.queries 条目及 SQL 文件",
    )
    data_query_sub = data_query.add_subparsers(dest="subaction")
    data_query_create = data_query_sub.add_parser(
        "create",
        help="创建一个命名查询骨架",
    )
    data_query_create.add_argument("name", help="查询名，snake_case")
    data_query_create.add_argument(
        "--source",
        action="append",
        required=True,
        help="来源资源 ID，可重复传入多个；仅支持 custom_table",
    )
    data_query_create.add_argument("--force", action="store_true", help="允许覆盖已有 SQL 文件")
    data_query_create.set_defaults(func=cmd_data_query_create)

    data_seed = data_sub.add_parser(
        "seed",
        help="创建并登记 module.yaml.data.seeds 条目及种子文件",
    )
    data_seed_sub = data_seed.add_subparsers(dest="subaction")
    data_seed_create = data_seed_sub.add_parser(
        "create",
        help="创建一个种子文件骨架",
    )
    data_seed_create.add_argument("name", help="种子名，snake_case")
    data_seed_create.add_argument("--resource", required=True, help="目标资源 ID")
    data_seed_create.add_argument(
        "--mode",
        default="replace_if_empty",
        choices=["replace", "replace_if_empty"],
        help="导入模式",
    )
    data_seed_create.add_argument("--force", action="store_true", help="允许覆盖已有种子文件")
    data_seed_create.set_defaults(func=cmd_data_seed_create)

    module_set = module_sub.add_parser(
        "set",
        help="修改 module.yaml 中的关键字段",
    )
    module_set_sub = module_set.add_subparsers(dest="field")

    module_set_repo = module_set_sub.add_parser(
        "repo",
        help="设置 module.yaml.upgrade_source.repo",
    )
    module_set_repo.add_argument("repo", help="GitHub 仓库，格式 owner/repo")
    module_set_repo.set_defaults(func=cmd_module_set_repo)

    module_set_version = module_set_sub.add_parser(
        "version",
        help="设置 module.yaml.version",
    )
    module_set_version.add_argument("version", help="语义化版本号")
    module_set_version.set_defaults(func=cmd_module_set_version)

    module_set_default_workflow = module_set_sub.add_parser(
        "default-workflow",
        help="设置 module.yaml.default_workflow",
    )
    module_set_default_workflow.add_argument("workflow", help="已声明的 workflow 名称")
    module_set_default_workflow.set_defaults(func=cmd_module_set_default_workflow)

    task_parser = subparsers.add_parser(
        "task",
        help="任务脚本操作：在 tasks/ 下创建或列出 TASK/execute 文件",
    )
    task_sub = task_parser.add_subparsers(dest="action")
    task_create = task_sub.add_parser(
        "create",
        help="创建一个新的 TASK/execute 文件，不会修改 module.yaml",
    )
    task_create.add_argument("name", help="任务名，snake_case")
    task_create.add_argument("--force", action="store_true", help="允许覆盖已有文件")
    task_create.set_defaults(func=cmd_task_create)
    task_list = task_sub.add_parser("list", help="列出 tasks/ 下的任务脚本")
    task_list.set_defaults(func=cmd_task_list)

    workflow_parser = subparsers.add_parser(
        "workflow",
        help="工作流操作：创建 workflow 文件并维护 module.yaml.workflows",
    )
    workflow_sub = workflow_parser.add_subparsers(dest="action")
    workflow_create = workflow_sub.add_parser(
        "create",
        help="创建工作流文件，并把 workflow 注册进 module.yaml",
    )
    workflow_create.add_argument("name", help="工作流名，snake_case")
    workflow_create.add_argument("--display-name", help="工作流显示名")
    workflow_create.add_argument("--description", help="工作流说明")
    workflow_create.add_argument("--force", action="store_true", help="允许覆盖已有文件")
    workflow_create.set_defaults(func=cmd_workflow_create)
    workflow_list = workflow_sub.add_parser("list", help="列出 module.yaml 中声明的工作流")
    workflow_list.set_defaults(func=cmd_workflow_list)

    page_parser = subparsers.add_parser(
        "page",
        help="宿主页操作：在 pages/ 生成 hosted page 骨架并按需维护 ui_extension.pages",
    )
    page_sub = page_parser.add_subparsers(dest="action")
    page_create = page_sub.add_parser(
        "create",
        help="创建一个宿主页骨架；默认注册到左侧菜单，可用 --no-menu 只创建可路由页面",
    )
    page_create.add_argument("name", help="页面名，snake_case")
    page_create.add_argument("--group", help="可选源码分组目录，单层 snake_case；例如 account")
    page_create.add_argument("--no-menu", action="store_true", help="只创建页面文件，不写入左侧菜单配置")
    page_create.add_argument("--display-name", help="页面显示名")
    page_create.add_argument("--description", help="页面说明")
    page_create.add_argument("--force", action="store_true", help="允许覆盖已有文件")
    page_create.set_defaults(func=cmd_page_create)
    page_list = page_sub.add_parser("list", help="列出 ui_extension.pages 中的左侧菜单入口")
    page_list.set_defaults(func=cmd_page_list)

    selector_parser = subparsers.add_parser(
        "env-selector",
        help="环境选择器操作：在 env_selectors/ 中声明 SELECTOR/select 文件",
    )
    selector_sub = selector_parser.add_subparsers(dest="action")
    selector_create = selector_sub.add_parser(
        "create",
        help="创建一个环境选择策略文件，用于 ATM 的“选择环境”模式",
    )
    selector_create.add_argument("name", help="选择器名，snake_case")
    selector_create.add_argument("--display-name", help="显示名")
    selector_create.add_argument("--description", help="说明")
    selector_create.add_argument("--force", action="store_true", help="允许覆盖已有文件")
    selector_create.set_defaults(func=cmd_env_selector_create)
    selector_list = selector_sub.add_parser("list", help="列出模块声明的环境选择器")
    selector_list.set_defaults(func=cmd_env_selector_list)

    hook_parser = subparsers.add_parser(
        "hook",
        help="生命周期 Hook 操作：在 hooks/ 中生成标准 Hook 文件",
    )
    hook_sub = hook_parser.add_subparsers(dest="action")
    hook_create = hook_sub.add_parser(
        "create",
        help="创建或重建一个标准生命周期 Hook 文件",
    )
    hook_create.add_argument("name", choices=HOOK_NAMES, help="Hook 名")
    hook_create.add_argument("--force", action="store_true", help="允许覆盖已有文件")
    hook_create.set_defaults(func=cmd_hook_create)
    hook_list = hook_sub.add_parser("list", help="列出 hooks/ 下已有的 Hook 文件")
    hook_list.set_defaults(func=cmd_hook_list)

    config_parser = subparsers.add_parser(
        "config",
        help="默认配置操作：管理 module.yaml.config_defaults",
    )
    config_sub = config_parser.add_subparsers(dest="action")
    config_show = config_sub.add_parser("show", help="显示 config_defaults 当前内容")
    config_show.set_defaults(func=cmd_config_show)
    config_set = config_sub.add_parser(
        "set",
        help="从 YAML 文件写入模块级或工作流级默认配置",
    )
    config_set_sub = config_set.add_subparsers(dest="scope")
    config_set_module = config_set_sub.add_parser(
        "module",
        help="把 YAML 文件写入 config_defaults.module",
    )
    config_set_module.add_argument("--file", required=True, help="YAML 文件路径")
    config_set_module.set_defaults(func=cmd_config_set_module)
    config_set_workflow = config_set_sub.add_parser(
        "workflow",
        help="把 YAML 文件写入 config_defaults.workflows.<workflow>",
    )
    config_set_workflow.add_argument("workflow", help="已声明的 workflow 名称")
    config_set_workflow.add_argument("--file", required=True, help="YAML 文件路径")
    config_set_workflow.set_defaults(func=cmd_config_set_workflow)
    config_lint = config_sub.add_parser(
        "lint",
        help="校验 config_defaults 的 YAML 结构和 workflow 引用是否正确",
    )
    config_lint.set_defaults(func=cmd_config_lint)

    package_parser = subparsers.add_parser(
        "package",
        help="安装包操作：构建或校验单根目录 ZIP 模块安装包",
    )
    package_sub = package_parser.add_subparsers(dest="action")
    package_build = package_sub.add_parser(
        "build",
        help="构建正式安装 ZIP；会先执行 release 级校验",
    )
    package_build.add_argument("--output", help="输出 ZIP 路径，默认 dist/<module>-<version>.zip")
    package_build.set_defaults(func=cmd_package_build)
    package_verify = package_sub.add_parser(
        "verify",
        help="校验已有 ZIP 是否符合模块安装包结构",
    )
    package_verify.add_argument("archive", help="待校验的 ZIP 文件")
    package_verify.set_defaults(func=cmd_package_verify)

    release_parser = subparsers.add_parser(
        "release",
        help="发布链路检查：看本地发布就绪状态，或对比远端 GitHub Release 版本",
    )
    release_sub = release_parser.add_subparsers(dest="action")
    release_status = release_sub.add_parser(
        "status",
        help="显示本地发布就绪状态，包括 repo、version、安装包和 release 校验结果",
    )
    release_status.set_defaults(func=cmd_release_status)
    release_remote = release_sub.add_parser(
        "check-remote",
        help="查询 GitHub Release 最新版本，并和本地 module.yaml.version 对比",
    )
    release_remote.add_argument(
        "--github-token",
        help="GitHub Token；不传则回退到 CRAWLER4J_GITHUB_TOKEN / GITHUB_TOKEN / GH_TOKEN",
    )
    release_remote.set_defaults(func=cmd_release_check_remote)
    release_publish = release_sub.add_parser(
        "publish",
        help="使用 GitHub CLI 把本地 ZIP 安装包发布到 GitHub Release",
    )
    release_publish.add_argument("--archive", help="待发布的 ZIP 路径，默认 dist/<module>-<version>.zip")
    release_publish.add_argument("--tag", help="Release tag，默认 v<version>")
    release_publish.add_argument("--title", help="Release 标题，默认与 tag 相同")
    release_publish.add_argument("--notes", help="Release notes 文本")
    release_publish.add_argument("--notes-file", help="Release notes 文件路径")
    release_publish.add_argument("--prerelease", action="store_true", help="以 prerelease 形式创建 Release")
    release_publish.add_argument("--rebuild", action="store_true", help="发布前强制重新构建 ZIP")
    release_publish.add_argument("--dry-run", action="store_true", help="只打印将要执行的 gh 命令")
    release_publish.set_defaults(func=cmd_release_publish)

    host_parser = subparsers.add_parser(
        "host",
        help="宿主桥接命令：通过 crawler4j-sdk CLI 操作宿主的 DevLink、安装、升级和调试配置",
    )
    host_sub = host_parser.add_subparsers(dest="action")

    host_devlink = host_sub.add_parser(
        "devlink",
        help="管理宿主侧 DevLink 模块注册",
    )
    host_devlink_sub = host_devlink.add_subparsers(dest="subaction")
    host_devlink_add = host_devlink_sub.add_parser(
        "add",
        help="把本地模块目录注册成宿主 DevLink",
    )
    host_devlink_add.add_argument("module_root", help="模块根目录路径")
    host_devlink_add.set_defaults(func=cmd_host_devlink_add)
    host_devlink_remove = host_devlink_sub.add_parser(
        "remove",
        help="移除宿主里的 DevLink 注册",
    )
    host_devlink_remove.add_argument("module_name", help="模块名")
    host_devlink_remove.set_defaults(func=cmd_host_devlink_remove)
    host_devlink_list = host_devlink_sub.add_parser(
        "list",
        help="列出宿主当前的 DevLink 模块",
    )
    host_devlink_list.set_defaults(func=cmd_host_devlink_list)

    host_install = host_sub.add_parser(
        "install",
        help="预览或执行宿主模块安装，来源可以是本地 ZIP 或 GitHub owner/repo",
    )
    host_install_sub = host_install.add_subparsers(dest="subaction")
    host_install_preview = host_install_sub.add_parser(
        "preview",
        help="只做安装预检，不实际安装",
    )
    host_install_preview.add_argument("source", help="ZIP 路径或 GitHub owner/repo")
    host_install_preview.add_argument(
        "--skip-remote-check",
        action="store_true",
        help="本地 ZIP 预览时跳过 upgrade_source.repo 的远端可达性校验",
    )
    host_install_preview.add_argument(
        "--github-token",
        help="GitHub Token；用于私有仓库安装或 ZIP 远端仓库校验",
    )
    host_install_preview.set_defaults(func=cmd_host_install_preview)
    host_install_apply = host_install_sub.add_parser(
        "apply",
        help="执行安装",
    )
    host_install_apply.add_argument("source", help="ZIP 路径或 GitHub owner/repo")
    host_install_apply.add_argument(
        "--skip-remote-check",
        action="store_true",
        help="本地 ZIP 安装时跳过 upgrade_source.repo 的远端可达性校验",
    )
    host_install_apply.add_argument(
        "--github-token",
        help="GitHub Token；用于私有仓库安装或 ZIP 远端仓库校验",
    )
    host_install_apply.set_defaults(func=cmd_host_install_apply)

    host_upgrade = host_sub.add_parser(
        "upgrade",
        help="检查、预览或执行正式安装模块的 GitHub Release 升级",
    )
    host_upgrade_sub = host_upgrade.add_subparsers(dest="subaction")
    host_upgrade_check = host_upgrade_sub.add_parser(
        "check",
        help="检查已安装模块是否有新版本",
    )
    host_upgrade_check.add_argument("module_name", help="已安装模块名")
    host_upgrade_check.add_argument(
        "--github-token",
        help="GitHub Token；不传则回退到环境变量",
    )
    host_upgrade_check.set_defaults(func=cmd_host_upgrade_check)
    host_upgrade_preview = host_upgrade_sub.add_parser(
        "preview",
        help="下载并预览升级包，但不安装",
    )
    host_upgrade_preview.add_argument("module_name", help="已安装模块名")
    host_upgrade_preview.add_argument(
        "--github-token",
        help="GitHub Token；不传则回退到环境变量",
    )
    host_upgrade_preview.set_defaults(func=cmd_host_upgrade_preview)
    host_upgrade_apply = host_upgrade_sub.add_parser(
        "apply",
        help="下载并安装升级包",
    )
    host_upgrade_apply.add_argument("module_name", help="已安装模块名")
    host_upgrade_apply.add_argument(
        "--github-token",
        help="GitHub Token；不传则回退到环境变量",
    )
    host_upgrade_apply.set_defaults(func=cmd_host_upgrade_apply)

    host_debug = host_sub.add_parser(
        "debug",
        help="生成宿主调试配置。当前 CLI 只负责 VS Code attach 配置，不直接托管调试会话生命周期",
    )
    host_debug_sub = host_debug.add_subparsers(dest="subaction")
    host_debug_config = host_debug_sub.add_parser(
        "config",
        help="为模块目录生成或更新 .vscode/launch.json 的 debugpy attach 配置",
    )
    host_debug_config.add_argument("--module-root", help="模块根目录，默认使用当前模块目录")
    host_debug_config.add_argument("--host", default="127.0.0.1", help="debugpy 监听地址")
    host_debug_config.add_argument("--port", type=int, default=5678, help="debugpy 监听端口")
    host_debug_config.add_argument(
        "--configuration-name",
        default="Attach to Crawler4j",
        help="VS Code 配置名称",
    )
    host_debug_config.set_defaults(func=cmd_host_debug_config)

    check_parser = subparsers.add_parser(
        "check",
        help="模块完整性校验：structure 只看骨架，release 看发布前提，full 再做导入校验",
    )
    check_sub = check_parser.add_subparsers(dest="level")
    check_structure = check_sub.add_parser(
        "structure",
        help="检查 module.yaml、core-native-v1 目录结构、workflow 声明和 UI 入口格式",
    )
    check_structure.set_defaults(func=cmd_check_structure)
    check_release = check_sub.add_parser(
        "release",
        help="在 structure 基础上继续检查 version、upgrade_source.repo、config_defaults 等发布前提",
    )
    check_release.set_defaults(func=cmd_check_release)
    check_full = check_sub.add_parser(
        "full",
        help="在 release 基础上再尝试导入模块文件并校验 TASK/WORKFLOW/SELECTOR/PAGE 导出，作为完整 gate",
    )
    check_full.set_defaults(func=cmd_check_full)

    return parser


def main(argv: list[str] | None = None) -> int:
    """Entry point for the crawler4j CLI."""
    parser = build_parser()
    args = parser.parse_args(argv)
    if not getattr(args, "command", None):
        parser.print_help()
        return 0
    if not hasattr(args, "func"):
        parser.print_help()
        return 2
    try:
        return int(args.func(args))
    except CLIError as exc:
        _print_error(str(exc))
        return 1


if __name__ == "__main__":
    sys.exit(main())
