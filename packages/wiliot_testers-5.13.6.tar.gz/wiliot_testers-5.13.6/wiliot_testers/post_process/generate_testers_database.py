"""
Copyright (c) 2016- 2025, Wiliot Ltd. All rights reserved.

Redistribution and use of the Software in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
  this list of conditions and the following disclaimer.

  2. Redistributions in binary form, except as used in conjunction with
  Wiliot's Pixel in a product or a Software update for such product, must reproduce
  the above copyright notice, this list of conditions and the following disclaimer in
  the documentation and/or other materials provided with the distribution.

  3. Neither the name nor logo of Wiliot, nor the names of the Software's contributors,
  may be used to endorse or promote products or services derived from this Software,
  without specific prior written permission.

  4. This Software, with or without modification, must only be used in conjunction
  with Wiliot's Pixel or with Wiliot's cloud service.

  5. If any Software is provided in binary form under this license, you must not
  do any of the following:
  (a) modify, adapt, translate, or create a derivative work of the Software; or
  (b) reverse engineer, decompile, disassemble, decrypt, or otherwise attempt to
  discover the source code or non-literal aspects (such as the underlying structure,
  sequence, organization, ideas, or algorithms) of the Software.

  6. If you create a derivative work and/or improvement of any Software, you hereby
  irrevocably grant each of Wiliot and its corporate affiliates a worldwide, non-exclusive,
  royalty-free, fully paid-up, perpetual, irrevocable, assignable, sublicensable
  right and license to reproduce, use, make, have made, import, distribute, sell,
  offer for sale, create derivative works of, modify, translate, publicly perform
  and display, and otherwise commercially exploit such derivative works and improvements
  (as applicable) in conjunction with Wiliot's products and services.

  7. You represent and warrant that you are not a resident of (and will not use the
  Software in) a country that the U.S. government has embargoed for use of the Software,
  nor are you named on the U.S. Treasury Department’s list of Specially Designated
  Nationals or any other applicable trade sanctioning regulations of any jurisdiction.
  You must not transfer, export, re-export, import, re-import or divert the Software
  in violation of any export or re-export control laws and regulations (such as the
  United States' ITAR, EAR, and OFAC regulations), as well as any applicable import
  and use restrictions, all as then in effect

THIS SOFTWARE IS PROVIDED BY WILIOT "AS IS" AND "AS AVAILABLE", AND ANY EXPRESS
OR IMPLIED WARRANTIES OR CONDITIONS, INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED
WARRANTIES OR CONDITIONS OF MERCHANTABILITY, SATISFACTORY QUALITY, NONINFRINGEMENT,
QUIET POSSESSION, FITNESS FOR A PARTICULAR PURPOSE, AND TITLE, ARE DISCLAIMED.
IN NO EVENT SHALL WILIOT, ANY OF ITS CORPORATE AFFILIATES OR LICENSORS, AND/OR
ANY CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES, FOR THE COST OF PROCURING SUBSTITUTE GOODS OR SERVICES,
FOR ANY LOSS OF USE OR DATA OR BUSINESS INTERRUPTION, AND/OR FOR ANY ECONOMIC LOSS
(SUCH AS LOST PROFITS, REVENUE, ANTICIPATED SAVINGS). THE FOREGOING SHALL APPLY:
(A) HOWEVER CAUSED AND REGARDLESS OF THE THEORY OR BASIS LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE);
(B) EVEN IF ANYONE IS ADVISED OF THE POSSIBILITY OF ANY DAMAGES, LOSSES, OR COSTS; AND
(C) EVEN IF ANY REMEDY FAILS OF ITS ESSENTIAL PURPOSE.
"""
from wiliot_testers.post_process.modules.association_and_verification_post_process import \
    AssociationAndVerificationPostProcess
from wiliot_testers.post_process.modules.offline_test_post_process import OfflineTestPostProcess
from wiliot_testers.post_process.modules.sample_test_post_process import SampleTestPostProcess
from wiliot_testers.post_process.modules.yield_test_post_process import YieldTestPostProcess
from wiliot_testers.post_process.modules.conversion_yield_test_post_process import ConversionYieldTestPostProcess
from wiliot_testers.post_process.utils.post_process_tools import calculate_run_time

process_type_mapping = {
    'offline_test': OfflineTestPostProcess,
    'sample_test': SampleTestPostProcess,
    'yield_test': YieldTestPostProcess,
    'conversion_yield_test': ConversionYieldTestPostProcess,
    'association_and_verification_test': AssociationAndVerificationPostProcess
    }

@calculate_run_time
def generate_testers_database(run_data=None, packet_data=None, decoded_data=None,
                              process_type=None, manufacturing_ver=None, tester_run_id=None, wafer_sort_data=None,
                              is_test_mode=False):
    """
    This function run the specific process on a list of cakes according to the process type.
    For all processes, first a basic process of combining PixieAnalyzer output with the raw data is done.
    :param run_data:
    :type run_data: dict
    :param decoded_data:
    :type decoded_data: PacketList or DecryptedPacketList
    :param process_type:
    :type process_type: str
    :param tester_run_id: the unique run id received by the cloud
    :type tester_run_id: int
    :return: results
    :rtype: dict
    """

    if decoded_data is None or len(decoded_data) == 0 or packet_data is None:
        return None, None, None, None, None, None

    pp_class = process_type_mapping.get(process_type)
    if pp_class is None:
        raise Exception('the selected process type ({}) is not supported! '
                        'please select one of the following '
                        '{}'.format(process_type, list(process_type_mapping.keys())))
    pp = pp_class(
        run_data=run_data,
        packet_data=packet_data,
        decoded_packet_list=decoded_data,
        process_type=process_type,
        manufacturing_ver=manufacturing_ver,
        tester_run_id=tester_run_id,
        wafer_sort_data=wafer_sort_data,
        is_test_mode=is_test_mode
    )
    return pp.generate_testers_database()
