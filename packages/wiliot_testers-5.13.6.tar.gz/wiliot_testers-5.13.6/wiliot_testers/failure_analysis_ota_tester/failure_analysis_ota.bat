@echo off
REM cd ..
setlocal enableextensions
for /f "tokens=*" %%a in (
'python -c "import wiliot_testers as _; print(_.__file__)"'
) do (
set pyPath=%%a\..
)
cd %pyPath%\failure_analysis_ota_tester
:loop
python failure_analysis_ota_gui_main.py
IF "%ERRORLEVEL%"=="1" goto loop
echo %ERRORLEVEL%
pause