"""Simple JS REPL."""

import argparse
import json
import logging
import readline  # Infects input() at import. (pylint: disable=unused-import)

from wasmjs import wasmjs


def main():  # pylint: disable=missing-docstring
    parser = argparse.ArgumentParser()
    parser.add_argument('-v', '--verbose', action='store_true')
    args = parser.parse_args()

    logging.basicConfig(
        format='%(asctime)s %(levelname)s %(threadName)s %(filename)s:%(lineno)s] %(message)s',
        level=args.verbose and logging.DEBUG or logging.INFO)

    js = wasmjs.WasmJS()

    while True:
        try:
            line = input('>>> ')
        except EOFError:
            print()
            break
        except KeyboardInterrupt:
            print()
            continue

        try:
            print(json.dumps(js.eval(line)))
        except wasmjs.InterpreterError as e:
            print(e.__cause__)
            print('!!! The interpreter may now be unstable !!!')
        except wasmjs.JSError as e:
            print(e)
            if e.stack:
                print(e.stack, end='')


if __name__ == '__main__':
    main()
