# This file is overwritten at build time by the CI pipeline.
# The version is derived from the GitHub release tag.
# For local development, this fallback is used.
__version__ = "v2.0.0rc136"
