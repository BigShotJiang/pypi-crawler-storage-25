import os
from typing import Any

from fissionbox.cli.utils.config_store import load_cli_config
from fissionbox.core.client.connection import Connection
from fissionbox.core.client.client import Client
from fissionbox.core.client.document import DocumentClient
from fissionbox.core.client.account import AccountClient


DEFAULT_FISSIONBOX_HOST = "https://api.beta.fissionbox.ai"
DEFAULT_FISSIONBOX_API_KEY = ""
DEFAULT_PLATFORM_HOST = "https://api.beta.platform.fissionbox.ai"
DEFAULT_AUTH_HOST = "https://www.beta.platform.fissionbox.ai"
NAMESPACE_ENV_NAME = "FISSIONBOX_NAMESPACE_ID"
NAMESPACE_CONFIG_KEY = "default_namespace_id"
FISSIONBOX_NAMESPACE_HEADER = "X-FissionBox-Namespace-Id"


def _load_runtime_config() -> dict[str, Any]:
    return load_cli_config()


def _config_or_env(
    env_name: str,
    *,
    config_key: str | None = None,
    default: str = "",
) -> str:
    config = _load_runtime_config()
    env_value = os.getenv(env_name)
    if env_value is not None:
        return env_value

    config_value = config.get(config_key or env_name.lower())
    if not config_value:
        return default
    return str(config_value)


def get_fissionbox_host() -> str:
    return _config_or_env("FISSIONBOX_HOST", config_key="fissionbox_host", default=DEFAULT_FISSIONBOX_HOST)


def get_fissionbox_api_key() -> str:
    return os.getenv("FISSIONBOX_API_KEY", DEFAULT_FISSIONBOX_API_KEY)


def get_platform_host() -> str:
    return _config_or_env(
        "FISSIONBOX_PLATFORM_HOST",
        config_key="platform_host",
        default=DEFAULT_PLATFORM_HOST,
    )


def get_auth_host() -> str:
    return _config_or_env(
        "FISSIONBOX_AUTH_HOST",
        config_key="auth_host",
        default=DEFAULT_AUTH_HOST,
    )


def get_platform_api_key() -> str:
    return _config_or_env("FISSIONBOX_PLATFORM_API_KEY", config_key="platform_api_key")


def get_platform_user_token() -> str:
    return _config_or_env("FISSIONBOX_PLATFORM_USER_TOKEN", config_key="platform_user_token")


def get_default_namespace_id() -> str:
    return _config_or_env(NAMESPACE_ENV_NAME, config_key=NAMESPACE_CONFIG_KEY)


def resolve_namespace_id(namespace_id: str | None) -> str:
    resolved_namespace_id = namespace_id or get_default_namespace_id()
    if resolved_namespace_id:
        return resolved_namespace_id
    raise ValueError(
        "Workspace namespace ID is required. Pass --namespace-id or set a default with `fissionbox namespace use --namespace-id=<id>`.",
    )


def _build_platform_connection() -> Connection:
    platform_api_key = get_platform_api_key()
    platform_user_token = get_platform_user_token()
    auth_token = platform_api_key or platform_user_token
    auth_header_name = "x-api-key" if platform_api_key else "Authorization"
    auth_scheme = "" if platform_api_key else "Bearer"
    return Connection(
        host=get_platform_host(),
        auth_token=auth_token,
        auth_header_name=auth_header_name,
        auth_scheme=auth_scheme,
    )


def _build_direct_fissionbox_connection() -> Connection:
    return Connection(
        host=get_fissionbox_host(),
        auth_token=get_fissionbox_api_key(),
    )


def get_direct_fissionbox_connection() -> Connection:
    return _build_direct_fissionbox_connection()


def get_platform_connection() -> Connection:
    return _build_platform_connection()


def get_platform_user_connection() -> Connection:
    return Connection(
        host=get_platform_host(),
        auth_token=get_platform_user_token(),
        auth_header_name="Authorization",
        auth_scheme="Bearer",
    )


def get_namespace_scoped_fissionbox_connection(namespace_id: str) -> Connection:
    if get_platform_user_token():
        return Connection(
            host=get_fissionbox_host(),
            auth_token=get_platform_user_token(),
            auth_header_name="Authorization",
            auth_scheme="Bearer",
            default_headers={FISSIONBOX_NAMESPACE_HEADER: namespace_id},
        )

    if get_platform_api_key():
        session_response = get_platform_connection().request(
            "POST",
            "/sessions",
            json={
                "service": "fissionbox",
                "namespaceId": namespace_id,
            },
        )
        session_token = session_response.json()["token"]
        return Connection(
            host=get_fissionbox_host(),
            auth_token=session_token,
            auth_header_name="Authorization",
            auth_scheme="Bearer",
            default_headers={FISSIONBOX_NAMESPACE_HEADER: namespace_id},
        )

    return get_direct_fissionbox_connection()


def get_namespace_client(namespace_id: str) -> Client:
    return Client(connection=get_namespace_scoped_fissionbox_connection(namespace_id))


def get_document_client(namespace_id: str) -> DocumentClient:
    return DocumentClient(get_namespace_scoped_fissionbox_connection(namespace_id))


def get_account_client() -> AccountClient:
    return AccountClient(get_platform_user_connection())
