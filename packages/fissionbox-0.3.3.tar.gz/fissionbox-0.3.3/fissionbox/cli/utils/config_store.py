import json
from pathlib import Path
from typing import Any, Dict


CONFIG_DIR = Path.home() / ".fissionbox"
CONFIG_PATH = CONFIG_DIR / "config.json"


def load_cli_config() -> Dict[str, Any]:
    if not CONFIG_PATH.exists():
        return {}
    try:
        return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_cli_config(data: Dict[str, Any]) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")


def update_cli_config(**updates: Any) -> Dict[str, Any]:
    config = load_cli_config()
    for key, value in updates.items():
        if value is None:
            config.pop(key, None)
        else:
            config[key] = value
    save_cli_config(config)
    return config
