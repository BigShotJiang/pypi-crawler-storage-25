from argparse import ArgumentParser, Namespace
import json
import os

from fissionbox.cli.utils.env import get_document_client, resolve_namespace_id


def register(parser: ArgumentParser) -> None:
    """Register commands for the document namespace."""
    subparsers = parser.add_subparsers(dest="command", required=True)

    upload_parser = subparsers.add_parser("upload", help="Upload source document files")
    upload_parser.add_argument("--namespace-id", type=str, default=None, help="Workspace namespace ID")
    upload_parser.add_argument("--path", type=str, required=True, help="Path to a document file or folder")

    process_parser = subparsers.add_parser("process", help="Process an uploaded source document")
    process_parser.add_argument("--namespace-id", type=str, default=None, help="Workspace namespace ID")
    process_parser.add_argument("--source-path", type=str, required=True, help="Stored source asset path")
    process_parser.add_argument("--name", type=str, default=None, help="Saved document name")
    process_parser.add_argument("--schema-json", type=json.loads, default=None, help="Extraction schema as inline JSON")
    process_parser.add_argument("--schema-file", type=str, default=None, help="Path to extraction schema JSON file")
    process_parser.add_argument("--extract-diagrams", action="store_true", help="Extract diagrams when available")
    process_parser.add_argument(
        "--response-detail",
        choices=["full", "extracted_only"],
        default="full",
        help="Response detail mode",
    )

    run_parser = subparsers.add_parser("run", help="Upload a local document and process it")
    run_parser.add_argument("--namespace-id", type=str, default=None, help="Workspace namespace ID")
    run_parser.add_argument("--path", type=str, required=True, help="Path to a local document file")
    run_parser.add_argument("--name", type=str, default=None, help="Saved document name")
    run_parser.add_argument("--schema-json", type=json.loads, default=None, help="Extraction schema as inline JSON")
    run_parser.add_argument("--schema-file", type=str, default=None, help="Path to extraction schema JSON file")
    run_parser.add_argument("--extract-diagrams", action="store_true", help="Extract diagrams when available")
    run_parser.add_argument(
        "--response-detail",
        choices=["full", "extracted_only"],
        default="full",
        help="Response detail mode",
    )

    list_parser = subparsers.add_parser("list", help="List saved processed documents")
    list_parser.add_argument("--namespace-id", type=str, default=None, help="Workspace namespace ID")
    list_parser.add_argument("--page", type=int, default=0, help="Page index")
    list_parser.add_argument("--size", type=int, default=50, help="Page size")

    export_chunks_parser = subparsers.add_parser("export-chunks", help="Export saved chunks for a processed document")
    export_chunks_parser.add_argument("--namespace-id", type=str, default=None, help="Workspace namespace ID")
    export_chunks_parser.add_argument("--id", type=str, required=True, help="Saved document artifact ID")
    export_chunks_parser.add_argument("--output", type=str, required=True, help="Output file path")


def _resolve_schema(args: Namespace):
    if args.schema_json and args.schema_file:
        raise ValueError("Use either --schema-json or --schema-file, not both.")
    if args.schema_file:
        with open(args.schema_file, "r", encoding="utf-8") as handle:
            return json.load(handle)
    return args.schema_json


def main(args: Namespace) -> None:
    namespace_id = resolve_namespace_id(getattr(args, "namespace_id", None))
    client = get_document_client(namespace_id)
    if args.command == "upload":
        if os.path.isdir(args.path):
            yes = input(
                f"The path {args.path} is a directory. Do you want to upload all supported documents in this folder? (y/n): "
            )
            if yes.lower() != "y":
                print("Upload cancelled.")
                return
            response = client.upload_folder(namespace_id, args.path)
        else:
            response = {args.path: client.upload(namespace_id, args.path)}
        print(json.dumps(response, indent=2))
        return

    if args.command == "process":
        response = client.process(
            namespace_id=namespace_id,
            source_path=args.source_path,
            name=args.name,
            extraction_schema=_resolve_schema(args),
            extract_diagrams=args.extract_diagrams,
            response_detail=args.response_detail,
        )
        print(json.dumps(response, indent=2))
        return

    if args.command == "run":
        response = client.run(
            namespace_id=namespace_id,
            path=args.path,
            name=args.name,
            extraction_schema=_resolve_schema(args),
            extract_diagrams=args.extract_diagrams,
            response_detail=args.response_detail,
        )
        print(json.dumps(response, indent=2))
        return

    if args.command == "list":
        response = client.list(namespace_id, page=args.page, size=args.size)
        print(json.dumps(response, indent=2))
        return

    if args.command == "export-chunks":
        output = client.export_chunks(namespace_id, args.id, args.output)
        print(json.dumps({"output": output}, indent=2))
        return

    print(f"Unknown command: {args.command}")
