from argparse import ArgumentParser, Namespace
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import threading
import time
import webbrowser
from urllib.parse import urlencode, urlparse, parse_qs

from fissionbox.cli.utils.config_store import CONFIG_PATH, load_cli_config, update_cli_config
from fissionbox.cli.utils.env import get_auth_host, get_default_namespace_id, get_fissionbox_host, get_platform_connection, get_platform_host


SUCCESS_HTML = """
<html>
  <body style="font-family: sans-serif; padding: 2rem;">
    <h2>FissionBox CLI login complete</h2>
    <p>You can return to the terminal now.</p>
  </body>
</html>
"""


def register(parser: ArgumentParser) -> None:
    """Register commands for CLI authentication."""
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("login", help="Log in through the local app and store a CLI token")
    subparsers.add_parser("status", help="Show the current CLI auth status")
    subparsers.add_parser("logout", help="Clear saved CLI auth tokens")


def _login() -> None:
    auth_host = get_auth_host()
    platform_host = get_platform_host()
    token_holder: dict[str, str] = {}

    class CallbackHandler(BaseHTTPRequestHandler):
        def do_GET(self):
            parsed = urlparse(self.path)
            if parsed.path != "/callback":
                self.send_response(404)
                self.end_headers()
                return
            params = parse_qs(parsed.query)
            token_holder["token"] = params.get("token", [""])[0]
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(SUCCESS_HTML.encode("utf-8"))

        def log_message(self, format, *args):
            return

    server = HTTPServer(("127.0.0.1", 0), CallbackHandler)
    port = server.server_port
    callback_url = f"http://127.0.0.1:{port}/callback"
    login_url = (
        f"{auth_host.rstrip('/')}/auth/login?"
        + urlencode({"returnTo": callback_url})
    )

    thread = threading.Thread(target=server.handle_request, daemon=True)
    thread.start()
    print(f"Opening browser for login at {auth_host} ...")
    webbrowser.open(login_url)

    timeout_at = time.time() + 180
    while time.time() < timeout_at and not token_holder.get("token"):
        time.sleep(0.2)
    server.server_close()

    token = token_holder.get("token")
    if not token:
        raise TimeoutError("Login timed out before the CLI received a token.")

    update_cli_config(
        auth_host=auth_host,
        platform_host=platform_host,
        platform_user_token=token,
    )
    print(json.dumps({
        "status": "ok",
        "auth_host": auth_host,
        "platform_host": platform_host,
        "stored_config": str(CONFIG_PATH),
    }, indent=2))


def main(args: Namespace) -> None:
    if args.command == "login":
        _login()
        return

    if args.command == "status":
        config = load_cli_config()
        connection = get_platform_connection()
        auth_host = get_auth_host()
        fissionbox_host = get_fissionbox_host()
        platform_host = get_platform_host()
        print(json.dumps({
            "auth_host": auth_host,
            "platform_host": platform_host,
            "fissionbox_host": fissionbox_host,
            "default_namespace_id": get_default_namespace_id() or None,
            "has_platform_api_key": bool(config.get("platform_api_key")),
            "has_platform_user_token": bool(config.get("platform_user_token")),
            "config_path": str(CONFIG_PATH),
            "auth_header": connection._auth_header_name,
        }, indent=2))
        return

    if args.command == "logout":
        update_cli_config(platform_user_token=None, platform_api_key=None)
        print(json.dumps({"status": "logged_out"}, indent=2))
        return

    print(f"Unknown command: {args.command}")
