from argparse import ArgumentParser, Namespace
import json

from fissionbox.cli.utils.config_store import CONFIG_PATH, update_cli_config
from fissionbox.cli.utils.env import get_default_namespace_id


def register(parser: ArgumentParser) -> None:
    """Register commands for default namespace management."""
    subparsers = parser.add_subparsers(dest="command", required=True)

    current_parser = subparsers.add_parser("current", help="Show the current default namespace")
    current_parser.add_argument("--json", action="store_true", help="Print the result as JSON")

    use_parser = subparsers.add_parser("use", help="Set the current default namespace")
    use_parser.add_argument("--namespace-id", type=str, required=True, help="Workspace namespace ID")

    subparsers.add_parser("clear", help="Clear the current default namespace")


def main(args: Namespace) -> None:
    if args.command == "current":
        namespace_id = get_default_namespace_id()
        payload = {
            "namespace_id": namespace_id or None,
            "config_path": str(CONFIG_PATH),
        }
        if getattr(args, "json", False):
            print(json.dumps(payload, indent=2))
        elif namespace_id:
            print(namespace_id)
        else:
            print("No default namespace configured.")
        return

    if args.command == "use":
        update_cli_config(default_namespace_id=args.namespace_id)
        print(json.dumps({
            "status": "ok",
            "namespace_id": args.namespace_id,
            "config_path": str(CONFIG_PATH),
        }, indent=2))
        return

    if args.command == "clear":
        update_cli_config(default_namespace_id=None)
        print(json.dumps({
            "status": "cleared",
            "config_path": str(CONFIG_PATH),
        }, indent=2))
        return

    print(f"Unknown command: {args.command}")
