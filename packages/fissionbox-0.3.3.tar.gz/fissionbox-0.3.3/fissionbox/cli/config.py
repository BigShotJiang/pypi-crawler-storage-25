import os
from fissionbox.cli.utils.config_store import load_cli_config


CLI_CONFIG = load_cli_config()
DEFAULT_FISSIONBOX_HOST = "https://api.beta.fissionbox.ai"
DEFAULT_PLATFORM_HOST = "https://api.beta.platform.fissionbox.ai"
DEFAULT_AUTH_HOST = "https://www.beta.platform.fissionbox.ai"


def _config_or_env(
    env_name: str,
    *,
    config_key: str,
    default: str,
) -> str:
    env_value = os.getenv(env_name)
    if env_value is not None:
        return env_value

    config_value = CLI_CONFIG.get(config_key)
    if not config_value:
        return default
    return str(config_value)

FISSIONBOX_HOST = os.getenv("FISSIONBOX_HOST", DEFAULT_FISSIONBOX_HOST)
FISSIONBOX_API_KEY = os.getenv("FISSIONBOX_API_KEY", "")

FISSIONBOX_PLATFORM_HOST = _config_or_env(
    "FISSIONBOX_PLATFORM_HOST",
    config_key="platform_host",
    default=DEFAULT_PLATFORM_HOST,
)
FISSIONBOX_AUTH_HOST = _config_or_env(
    "FISSIONBOX_AUTH_HOST",
    config_key="auth_host",
    default=DEFAULT_AUTH_HOST,
)
FISSIONBOX_PLATFORM_API_KEY = os.getenv(
    "FISSIONBOX_PLATFORM_API_KEY",
    CLI_CONFIG.get("platform_api_key", ""),
)
FISSIONBOX_PLATFORM_USER_TOKEN = os.getenv(
    "FISSIONBOX_PLATFORM_USER_TOKEN",
    CLI_CONFIG.get("platform_user_token", ""),
)
