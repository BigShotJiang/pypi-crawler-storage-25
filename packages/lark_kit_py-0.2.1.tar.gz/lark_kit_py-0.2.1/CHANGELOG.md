# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.0] - 2026-04-24

### Added

- `create_client()` and `create_ws_client()` with HTTPS proxy support
- `get_tenant_access_token()` with local cache and 5-minute early expiry
- IM module: `send`, `reply`, `reply_card`, `reply_markdown`, `send_card`, `patch`, `add_reaction`, `remove_reaction`, `download_image`, `download_file`
- Card module: `build`, `header`, `footer`, `collapsible`, `build_markdown_card`, `build_task_panel_card`, `build_thinking_panel`
- Card optimize: `optimize_for_card`, `truncate_safely`, `extract_code_blocks`, `restore_code_blocks`, `demote_headings`
- CardKit module: full lifecycle (create → stream → close), `FlushController`, async mutex
- Document module: create via Block API and MCP, `batch_create_blocks` with 429 retry, `resolve_images`, `cleanup_old_documents`
- Format module: `markdown_to_blocks`, `parse_inline_text`, Markdown parsers (table, callout, todo, equation, list)
- Bot module: `create_bot()` with `BotContext` (reply, reply_markdown, reply_card, add_reaction, download_resource)
- Constants: `BlockType`, `FontColor`, `FontBgColor`, `CalloutColorMap`, `LanguageMap`
- Utils: magic-byte MIME detection
