#!/usr/bin/env python3
"""Check Python dependencies for updates and create GitHub issues.

Reads pyproject.toml for dependencies, checks PyPI for latest versions,
and creates GitHub issues for major/minor updates.

Usage:
    GITHUB_TOKEN=xxx python scripts/deps_check.py
"""

import json
import os
import re
import subprocess
import sys
import urllib.request
from pathlib import Path


def parse_dependencies(pyproject_path: str) -> dict[str, str]:
    """Parse dependencies from pyproject.toml, returning {name: current_spec}."""
    content = Path(pyproject_path).read_text()

    # Find [project] dependencies block
    in_deps = False
    deps: dict[str, str] = {}

    for line in content.splitlines():
        stripped = line.strip()

        if stripped == "dependencies = [":
            in_deps = True
            continue

        if in_deps:
            if stripped == "]":
                break
            # Parse lines like: '    "lark-oapi>=1.4",'
            match = re.match(r'^\s*"([^">=<!~]+)([><=!~].+)?",?\s*$', stripped)
            if match:
                name = match.group(1).strip()
                version_spec = (match.group(2) or "").strip().rstrip(",")
                deps[name] = version_spec

    return deps


def extract_current_version(version_spec: str) -> str | None:
    """Extract the minimum version from a version specifier like '>=1.4'."""
    match = re.match(r">=\s*([0-9][0-9a-zA-Z.*-]*)", version_spec)
    if match:
        return match.group(1)
    return None


def get_latest_version_pypi(package: str) -> str | None:
    """Get the latest stable version from PyPI JSON API."""
    url = f"https://pypi.org/pypi/{package}/json"
    try:
        req = urllib.request.Request(url, headers={"Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read())
            return data["info"]["version"]
    except Exception as e:
        print(f"  Warning: could not fetch {package} from PyPI: {e}", file=sys.stderr)
        return None


def parse_version(version: str) -> list[int]:
    """Parse a version string into a list of ints for comparison."""
    parts = []
    for part in version.split("."):
        # Handle pre-release suffixes like "1.0.0a1"
        num_match = re.match(r"(\d+)", part)
        if num_match:
            parts.append(int(num_match.group(1)))
    return parts


def version_bump_type(current: str, latest: str) -> str | None:
    """Determine if the update is major, minor, or patch. Returns None if not an update."""
    cur_parts = parse_version(current)
    lat_parts = parse_version(latest)

    # Pad to same length
    max_len = max(len(cur_parts), len(lat_parts))
    cur_parts += [0] * (max_len - len(cur_parts))
    lat_parts += [0] * (max_len - len(lat_parts))

    if lat_parts[0] > cur_parts[0]:
        return "major"
    if len(lat_parts) > 1 and lat_parts[1] > cur_parts[1]:
        return "minor"
    # It's at least a patch update if versions differ
    if lat_parts != cur_parts:
        return "patch"
    return None


def github_api(
    method: str,
    path: str,
    token: str,
    repo: str,
    data: dict | None = None,
) -> dict | list | None:
    """Make a GitHub API request."""
    url = f"https://api.github.com/repos/{repo}{path}"
    headers = {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github+json",
    }
    body = json.dumps(data).encode() if data else None
    req = urllib.request.Request(url, data=body, headers=headers, method=method)

    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            if resp.status == 204:
                return None
            return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        print(f"  GitHub API error: {e.code} {e.reason}", file=sys.stderr)
        return None


def find_existing_issue(token: str, repo: str, package: str) -> int | None:
    """Find an open deps-update issue for the given package."""
    result = github_api(
        "GET",
        f"/issues?state=open&labels=deps-update&per_page=100",
        token,
        repo,
    )
    if not result:
        return None

    for issue in result:
        title: str = issue.get("title", "")
        if package.lower() in title.lower():
            return issue["number"]
    return None


def close_old_issues(token: str, repo: str, package: str) -> None:
    """Close existing deps-update issues for the given package."""
    issue_number = find_existing_issue(token, repo, package)
    if issue_number:
        github_api(
            "PATCH",
            f"/issues/{issue_number}",
            token,
            repo,
            {"state": "closed", "state_reason": "completed"},
        )
        print(f"  Closed old issue #{issue_number}")


def create_issue(
    token: str,
    repo: str,
    package: str,
    current: str,
    latest: str,
    bump: str,
) -> None:
    """Create a GitHub issue for the dependency update."""
    title = f"deps: {package} {current} -> {latest} ({bump})"
    body = f"""## Dependency Update

| Field | Value |
|-------|-------|
| Package | `{package}` |
| Current | `{current}` |
| Latest | `{latest}` |
| Type | {bump} |

### Action Required

Update `{package}` in `pyproject.toml` and `pixi.toml`, then run tests.

```bash
# Update in pyproject.toml and pixi.toml manually, then:
pixi install
pixi run test
```

---
*This issue was created automatically by the dependency check workflow.*
"""

    github_api(
        "POST",
        "/issues",
        token,
        repo,
        {
            "title": title,
            "body": body,
            "labels": ["deps-update"],
        },
    )
    print(f"  Created issue: {title}")


def main() -> None:
    token = os.environ.get("GITHUB_TOKEN")
    if not token:
        print("Error: GITHUB_TOKEN environment variable is required", file=sys.stderr)
        sys.exit(1)

    repo = os.environ.get("GITHUB_REPOSITORY", "suj1e/lark-kit-py")
    script_dir = Path(__file__).resolve().parent
    project_root = script_dir.parent
    pyproject_path = project_root / "pyproject.toml"

    if not pyproject_path.exists():
        print(f"Error: {pyproject_path} not found", file=sys.stderr)
        sys.exit(1)

    deps = parse_dependencies(str(pyproject_path))
    print(f"Checking {len(deps)} dependencies...")

    updates_found = 0

    for package, version_spec in sorted(deps.items()):
        current = extract_current_version(version_spec)
        if not current:
            print(f"  {package}: skipping (complex spec: {version_spec})")
            continue

        latest = get_latest_version_pypi(package)
        if not latest:
            print(f"  {package}: could not determine latest version")
            continue

        bump = version_bump_type(current, latest)
        if not bump:
            print(f"  {package}: up to date ({current})")
            continue

        print(f"  {package}: {current} -> {latest} ({bump})")

        if bump in ("major", "minor"):
            close_old_issues(token, repo, package)
            create_issue(token, repo, package, current, latest, bump)
            updates_found += 1
        else:
            print(f"    (patch update, skipping issue creation)")

    print(f"\nDone. {updates_found} major/minor updates found.")


if __name__ == "__main__":
    main()
