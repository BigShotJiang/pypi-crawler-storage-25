from __future__ import annotations

import time

import httpx

_cached_token: str | None = None
_token_expires_at: float = 0


async def get_tenant_access_token(app_id: str, app_secret: str) -> str:
    """Get a tenant access token, using cached value if still valid."""
    global _cached_token, _token_expires_at

    now = time.time()
    if _cached_token and now < _token_expires_at:
        return _cached_token

    async with httpx.AsyncClient() as http:
        res = await http.post(
            "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
            json={"app_id": app_id, "app_secret": app_secret},
        )
    data = res.json()
    if data.get("code") != 0:
        raise RuntimeError(f"Failed to get tenant access token: {data.get('msg')}")

    _cached_token = data["tenant_access_token"]
    _token_expires_at = now + data["expire"] - 300  # expire 5 minutes early
    return _cached_token


def invalidate_token_cache() -> None:
    """Clear the cached token, forcing a refresh on next request."""
    global _cached_token, _token_expires_at
    _cached_token = None
    _token_expires_at = 0
