"""MIME type detection utilities.

Detect image types from file header magic bytes.
Ported from lark-kit-ts utils/mime.ts.
"""

from __future__ import annotations


def detect_image_mime(buffer: bytes) -> str | None:
    """Detect image MIME type from file header magic bytes.

    Supported formats:
    - PNG:  89504E47
    - JPEG: FFD8FF
    - GIF:  47494638
    - WebP: 52494646 ... 57454250 (RIFF...WEBP)

    Args:
        buffer: File content bytes (at least 12 bytes for WebP detection).

    Returns:
        MIME type string, or ``None`` if the format is not recognized.
    """
    if len(buffer) < 4:
        return None

    hex4 = buffer[:4].hex().lower()

    # PNG: 89 50 4E 47
    if hex4 == "89504e47":
        return "image/png"

    # JPEG: FF D8 FF
    if hex4.startswith("ffd8ff"):
        return "image/jpeg"

    # GIF: 47 49 46 38 ("GIF8")
    if hex4.startswith("47494638"):
        return "image/gif"

    # WebP: "RIFF" (52494646) at offset 0 + "WEBP" at offset 8
    if hex4 == "52494646" and len(buffer) >= 12:
        webp_tag = buffer[8:12]
        if webp_tag == b"WEBP":
            return "image/webp"

    return None
