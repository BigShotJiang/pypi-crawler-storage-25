"""Utility functions."""

from __future__ import annotations

from .mime import detect_image_mime

__all__ = ["detect_image_mime"]
