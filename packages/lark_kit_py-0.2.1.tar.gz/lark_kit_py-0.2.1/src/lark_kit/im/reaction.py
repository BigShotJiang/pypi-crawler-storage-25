"""IM message reaction module.

Provides functions for adding and removing emoji reactions on Feishu/Lark
messages.
"""

from __future__ import annotations

import logging

import lark_oapi as lark
from lark_oapi.api.im.v1 import (
    CreateMessageReactionRequest,
    CreateMessageReactionRequestBody,
    DeleteMessageReactionRequest,
    Emoji,
)

logger = logging.getLogger(__name__)

__all__ = [
    "add_reaction",
    "remove_reaction",
]


def add_reaction(client: lark.Client, message_id: str, emoji: str) -> str:
    """Add an emoji reaction to a message.

    Parameters
    ----------
    client:
        Lark SDK client.
    message_id:
        The message ID to react to.
    emoji:
        Emoji token, e.g. ``"Typing"``, ``"OK"``, ``"DONE"``.

    Returns
    -------
    str
        The ``reaction_id`` (for later removal), or an empty string on
        failure.
    """
    request = (
        CreateMessageReactionRequest.builder()
        .message_id(message_id)
        .request_body(
            CreateMessageReactionRequestBody.builder()
            .reaction_type(Emoji.builder().emoji_type(emoji).build())
            .build()
        )
        .build()
    )
    resp = client.im.v1.message_reaction.create(request)

    if not resp.success():
        logger.warning(
            "add_reaction failed: code=%s msg=%s",
            resp.code,
            resp.msg,
        )
        return ""

    return resp.data.reaction_id or ""


def remove_reaction(
    client: lark.Client,
    message_id: str,
    reaction_id: str,
) -> None:
    """Remove an emoji reaction from a message."""
    request = (
        DeleteMessageReactionRequest.builder()
        .message_id(message_id)
        .reaction_id(reaction_id)
        .build()
    )
    resp = client.im.v1.message_reaction.delete(request)

    if not resp.success():
        logger.warning(
            "remove_reaction failed: code=%s msg=%s",
            resp.code,
            resp.msg,
        )
