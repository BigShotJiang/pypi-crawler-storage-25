"""IM module -- unified messaging interface for Feishu/Lark.

Provides a bound ``im(client)`` factory that returns a :class:`MessageOps`
object, as well as direct re-exports of all underlying functions.

Usage::

    from lark_kit.im import im

    ops = im(client)
    msg_id = ops.send(chat_id, "Hello, world!")
    await ops.add_reaction(msg_id, "OK")
"""

from __future__ import annotations

from types import SimpleNamespace
from typing import Any

import lark_oapi as lark

from .message import (
    send_text,
    reply_text,
    reply_card,
    patch_card,
    send_card,
    get_message,
    send_card_message,
    reply_markdown,
    send_card_to_chat,
)
from .reaction import (
    add_reaction,
    remove_reaction,
)
from .resource import (
    download_image,
    download_file,
)

__all__ = [
    # Factory
    "im",
    "MessageOps",
    # message
    "send_text",
    "reply_text",
    "reply_card",
    "patch_card",
    "send_card",
    "get_message",
    "send_card_message",
    "reply_markdown",
    "send_card_to_chat",
    # reaction
    "add_reaction",
    "remove_reaction",
    # resource
    "download_image",
    "download_file",
]


class MessageOps:
    """Bound messaging operations tied to a single Lark client.

    Obtain an instance via the :func:`im` factory.
    """

    __slots__ = ("_client",)

    def __init__(self, client: lark.Client) -> None:
        self._client = client

    # ── Message send / reply ──────────────────────────────────────

    def send(self, chat_id: str, text: str) -> str:
        """Send plain text.  Returns ``message_id``."""
        return send_text(self._client, chat_id, text)

    def send_card(self, chat_id: str, card_json: dict[str, Any]) -> str:
        """Send an interactive card.  Returns ``message_id``."""
        return send_card(self._client, chat_id, card_json)

    def send_card_to_chat(self, chat_id: str, markdown: str) -> str:
        """Build a Markdown card and send it to a chat."""
        return send_card_to_chat(self._client, chat_id, markdown)

    def reply(self, chat_id: str, root_msg_id: str, text: str) -> str:
        """Reply with text (wrapped in a Markdown card).  Returns ``message_id``."""
        return reply_text(self._client, chat_id, root_msg_id, text)

    def reply_card(self, chat_id: str, root_msg_id: str, card_json: dict[str, Any]) -> str:
        """Reply with an interactive card.  Returns ``message_id``."""
        return reply_card(self._client, chat_id, root_msg_id, card_json)

    def reply_markdown(self, chat_id: str, root_msg_id: str, markdown: str) -> str:
        """Build a Markdown card and reply.  Returns ``message_id``."""
        return reply_markdown(self._client, chat_id, root_msg_id, markdown)

    def patch(self, msg_id: str, card_json: dict[str, Any]) -> None:
        """Patch (update) an existing message's card content."""
        return patch_card(self._client, msg_id, card_json)

    def get(self, message_id: str) -> Any:
        """Get message content by ID."""
        return get_message(self._client, message_id)

    def send_card_message(
        self,
        chat_id: str,
        root_msg_id: str,
        content: str,
        *,
        thinking: str | None = None,
        card_title: str | None = None,
    ) -> str:
        """Send a card message with sanitize + optimize + text fallback."""
        return send_card_message(
            self._client,
            chat_id,
            root_msg_id,
            content,
            thinking=thinking,
            card_title=card_title,
        )

    # ── Reactions ─────────────────────────────────────────────────

    def add_reaction(self, message_id: str, emoji: str) -> str:
        """Add an emoji reaction.  Returns ``reaction_id``."""
        return add_reaction(self._client, message_id, emoji)

    def remove_reaction(self, message_id: str, reaction_id: str) -> None:
        """Remove an emoji reaction."""
        return remove_reaction(self._client, message_id, reaction_id)

    # ── Resource downloads ────────────────────────────────────────

    def download_image(self, message_id: str, image_key: str) -> tuple[str, str] | None:
        """Download an image.  Returns ``(base64, media_type)`` or ``None``."""
        return download_image(self._client, message_id, image_key)

    def download_file(
        self,
        message_id: str,
        file_key: str,
        temp_dir: str | None = None,
        filename: str | None = None,
    ) -> Any:
        """Download a file to the local filesystem."""
        return download_file(self._client, message_id, file_key, temp_dir, filename)


def im(client: lark.Client) -> MessageOps:
    """Create a bound messaging operations object.

    Usage::

        ops = im(client)
        msg_id = ops.send(chat_id, "Hello")
        ops.add_reaction(msg_id, "OK")
    """
    return MessageOps(client=client)
