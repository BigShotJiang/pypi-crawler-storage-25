"""IM resource download module.

Provides functions for downloading images and files from Feishu/Lark
messages, including MIME type detection via magic bytes.
"""

from __future__ import annotations

import base64
import logging
import os
import tempfile
import time
import re
from typing import Any

import lark_oapi as lark
from lark_oapi.api.im.v1 import GetMessageResourceRequest

from ..types import DownloadedFile

logger = logging.getLogger(__name__)

__all__ = [
    "download_image",
    "download_file",
]


# ── MIME detection (magic bytes) ─────────────────────────────────────


def _detect_image_mime(header_hex: str) -> str:
    """Detect image MIME type from the first few bytes (as hex string)."""
    if header_hex.startswith("89504e47"):
        return "image/png"
    if header_hex.startswith("47494638"):
        return "image/gif"
    if header_hex.startswith("52494646"):
        return "image/webp"
    # JPEG: FFD8FF
    if header_hex.startswith("ffd8ff"):
        return "image/jpeg"
    return "image/jpeg"


# Mapping of file extensions to MIME types.
_MIME_MAP: dict[str, str] = {
    # Documents
    "pdf": "application/pdf",
    "doc": "application/msword",
    "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "xls": "application/vnd.ms-excel",
    "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "ppt": "application/vnd.ms-powerpoint",
    "pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    # Text
    "txt": "text/plain",
    "md": "text/markdown",
    "csv": "text/csv",
    "json": "application/json",
    "xml": "application/xml",
    "yaml": "application/x-yaml",
    "yml": "application/x-yaml",
    # Code
    "js": "application/javascript",
    "ts": "application/typescript",
    "py": "text/x-python",
    "java": "text/x-java",
    "go": "text/x-go",
    "rs": "text/x-rust",
    "c": "text/x-c",
    "cpp": "text/x-c++",
    "h": "text/x-c",
    "hpp": "text/x-c++",
    "sh": "application/x-sh",
    "bash": "application/x-sh",
    # Archives
    "zip": "application/zip",
    "tar": "application/x-tar",
    "gz": "application/gzip",
    "rar": "application/vnd.rar",
    "7z": "application/x-7z-compressed",
    # Web
    "html": "text/html",
    "css": "text/css",
}


def _detect_mime_by_extension(filename: str) -> str:
    """Detect MIME type from file extension."""
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    return _MIME_MAP.get(ext, "application/octet-stream")


# ── Image download ───────────────────────────────────────────────────


def download_image(
    client: lark.Client,
    message_id: str,
    image_key: str,
) -> tuple[str, str] | None:
    """Download an image from a Feishu/Lark message.

    Parameters
    ----------
    client:
        Lark SDK client.
    message_id:
        The message that contains the image.
    image_key:
        The ``image_key`` identifier (e.g. ``img_xxx``).

    Returns
    -------
    tuple[str, str] | None
        ``(base64_data, media_type)`` on success, or ``None`` on failure.
    """
    try:
        request = (
            GetMessageResourceRequest.builder()
            .message_id(message_id)
            .file_key(image_key)
            .type("image")
            .build()
        )
        resp = client.im.v1.message_resource.get(request)

        if not resp.success():
            logger.warning(
                "download_image failed: code=%s msg=%s",
                resp.code,
                resp.msg,
            )
            return None

        # resp.file is a file-like object (IO[Any])
        data = resp.file.read()
        if isinstance(data, memoryview):
            data = bytes(data)

        b64 = base64.b64encode(data).decode("ascii")
        header_hex = data[:4].hex()
        media_type = _detect_image_mime(header_hex)

        return (b64, media_type)
    except Exception:
        logger.debug("download_image error", exc_info=True)
        return None


# ── File download ────────────────────────────────────────────────────


def download_file(
    client: lark.Client,
    message_id: str,
    file_key: str,
    temp_dir: str | None = None,
    filename: str | None = None,
) -> DownloadedFile | None:
    """Download a file from a Feishu/Lark message to the local filesystem.

    Parameters
    ----------
    client:
        Lark SDK client.
    message_id:
        The message that contains the file.
    file_key:
        The ``file_key`` identifier.
    temp_dir:
        Directory to save the file in.  Defaults to the system temp dir.
    filename:
        Desired filename (used for MIME detection and safe naming).  Defaults
        to ``file_<timestamp>``.

    Returns
    -------
    DownloadedFile | None
        Metadata about the downloaded file, or ``None`` on failure.
    """
    try:
        directory = temp_dir or tempfile.gettempdir()
        name = filename or f"file_{int(time.time() * 1000)}"

        # Ensure the target directory exists
        os.makedirs(directory, exist_ok=True)

        # Download the resource
        request = (
            GetMessageResourceRequest.builder()
            .message_id(message_id)
            .file_key(file_key)
            .type("file")
            .build()
        )
        resp = client.im.v1.message_resource.get(request)

        if not resp.success():
            logger.warning(
                "download_file failed: code=%s msg=%s",
                resp.code,
                resp.msg,
            )
            return None

        data = resp.file.read()
        if isinstance(data, memoryview):
            data = bytes(data)

        # Generate a safe, unique filename
        timestamp = int(time.time() * 1000)
        safe_name = re.sub(r"[^a-zA-Z0-9._\-]", "_", name)
        unique_name = f"{timestamp}_{safe_name}"
        filepath = os.path.join(directory, unique_name)

        with open(filepath, "wb") as f:
            f.write(data)

        mime_type = _detect_mime_by_extension(name)

        return DownloadedFile(
            filepath=filepath,
            filename=name,
            size=len(data),
            mime_type=mime_type,
            file_key=file_key,
        )
    except Exception:
        logger.debug("download_file error", exc_info=True)
        return None
