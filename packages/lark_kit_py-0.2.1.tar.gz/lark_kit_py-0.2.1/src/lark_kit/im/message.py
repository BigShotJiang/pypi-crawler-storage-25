"""IM message operations module.

Provides functions for sending, replying, patching, and retrieving Feishu/Lark
messages.  Ported from the TypeScript lark-kit-ts ``im/message.ts``.
"""

from __future__ import annotations

import json
import logging
from typing import Any

import lark_oapi as lark
from lark_oapi.api.im.v1 import (
    CreateMessageRequest,
    CreateMessageRequestBody,
    GetMessageRequest,
    PatchMessageRequest,
    PatchMessageRequestBody,
    ReplyMessageRequest,
    ReplyMessageRequestBody,
)

from ..card.builder import build_markdown_card, CardBuildOptions
from ..card.optimize import optimize_for_card
from ..format.sanitize import sanitize_content, format_warnings

logger = logging.getLogger(__name__)

__all__ = [
    "send_text",
    "reply_text",
    "reply_card",
    "patch_card",
    "send_card",
    "get_message",
    "send_card_message",
    "reply_markdown",
    "send_card_to_chat",
]


# ── Internal helpers ──────────────────────────────────────────────────


def _log_api_error(action: str, resp: lark.BaseResponse) -> None:
    """Log a failed API call."""
    logger.warning(
        "%s failed: code=%s msg=%s",
        action,
        resp.code,
        resp.msg,
    )


# ── Core message operations ──────────────────────────────────────────


def send_text(client: lark.Client, chat_id: str, text: str) -> str:
    """Send a plain-text message to a chat.

    Returns the ``message_id`` of the new message, or an empty string on
    failure.
    """
    request = (
        CreateMessageRequest.builder()
        .receive_id_type("chat_id")
        .request_body(
            CreateMessageRequestBody.builder()
            .receive_id(chat_id)
            .msg_type("text")
            .content(json.dumps({"text": text}))
            .build()
        )
        .build()
    )
    resp = client.im.v1.message.create(request)

    if not resp.success():
        _log_api_error("send_text", resp)
        return ""

    return resp.data.message_id or ""


def reply_text(
    client: lark.Client,
    chat_id: str,  # noqa: ARG001 – kept for API parity with TS version
    root_msg_id: str,
    text: str,
) -> str:
    """Reply with text wrapped in a Markdown card.

    Returns the ``message_id`` of the reply, or an empty string on failure.
    """
    card = build_markdown_card(text)
    return reply_card(client, chat_id, root_msg_id, card)


def reply_card(
    client: lark.Client,
    chat_id: str,  # noqa: ARG001 – kept for API parity with TS version
    root_msg_id: str,
    card_json: dict[str, Any],
) -> str:
    """Reply with an interactive card.

    Returns the ``message_id`` of the reply, or an empty string on failure.
    """
    request = (
        ReplyMessageRequest.builder()
        .message_id(root_msg_id)
        .request_body(
            ReplyMessageRequestBody.builder()
            .content(json.dumps(card_json))
            .msg_type("interactive")
            .reply_in_thread(False)
            .build()
        )
        .build()
    )
    resp = client.im.v1.message.reply(request)

    if not resp.success():
        _log_api_error("reply_card", resp)
        return ""

    return resp.data.message_id or ""


def patch_card(
    client: lark.Client,
    msg_id: str,
    card_json: dict[str, Any],
) -> None:
    """Patch (update) an existing message's card content."""
    request = (
        PatchMessageRequest.builder()
        .message_id(msg_id)
        .request_body(
            PatchMessageRequestBody.builder()
            .content(json.dumps(card_json))
            .build()
        )
        .build()
    )
    resp = client.im.v1.message.patch(request)

    if not resp.success():
        _log_api_error("patch_card", resp)


def send_card(
    client: lark.Client,
    chat_id: str,
    card_json: dict[str, Any],
) -> str:
    """Send an interactive card to a chat.

    Returns the ``message_id`` of the new message, or an empty string on
    failure.
    """
    request = (
        CreateMessageRequest.builder()
        .receive_id_type("chat_id")
        .request_body(
            CreateMessageRequestBody.builder()
            .receive_id(chat_id)
            .msg_type("interactive")
            .content(json.dumps(card_json))
            .build()
        )
        .build()
    )
    resp = client.im.v1.message.create(request)

    if not resp.success():
        _log_api_error("send_card", resp)
        return ""

    return resp.data.message_id or ""


def get_message(client: lark.Client, message_id: str) -> Any:
    """Get message content by ID.

    Returns the response data object, or ``None`` on failure.
    """
    request = GetMessageRequest.builder().message_id(message_id).build()
    resp = client.im.v1.message.get(request)

    if not resp.success():
        _log_api_error("get_message", resp)
        return None

    return resp.data


# ── Composite send (sanitize + optimize + fallback) ──────────────────


def send_card_message(
    client: lark.Client,
    chat_id: str,
    root_msg_id: str,
    content: str,
    *,
    thinking: str | None = None,
    card_title: str | None = None,
    **kwargs: Any,  # noqa: ARG001 – reserved for future options
) -> str:
    """Send a card message with sanitization, optimization, and text fallback.

    Pipeline:
    1. ``sanitize_content`` – filter blob URLs and external images
    2. ``optimize_for_card`` – demote headings for Lark card rendering
    3. Build a Markdown card and reply
    4. On card failure, fall back to plain text

    Returns the ``message_id``, or an empty string on failure.
    """
    # 1. Sanitize
    result = sanitize_content(content)
    final_content = result.content
    if result.warnings:
        final_content += format_warnings(result.warnings)

    # 2. Try card reply
    try:
        optimized = optimize_for_card(final_content)
        card = build_markdown_card(
            optimized,
            [],
            CardBuildOptions(
                thinking=thinking,
                card_title=card_title,
            ),
        )
        msg_id = reply_card(client, chat_id, root_msg_id, card)
        if msg_id:
            return msg_id
    except Exception:
        logger.debug("Card reply failed, falling back to plain text", exc_info=True)

    # 3. Fallback to plain text reply
    request = (
        ReplyMessageRequest.builder()
        .message_id(root_msg_id)
        .request_body(
            ReplyMessageRequestBody.builder()
            .content(json.dumps({"text": final_content}))
            .msg_type("text")
            .reply_in_thread(False)
            .build()
        )
        .build()
    )
    resp = client.im.v1.message.reply(request)

    if not resp.success():
        _log_api_error("send_card_message (text fallback)", resp)
        return ""

    return resp.data.message_id or ""


# ── Convenience methods ──────────────────────────────────────────────


def reply_markdown(
    client: lark.Client,
    chat_id: str,
    root_msg_id: str,
    markdown: str,
) -> str:
    """Build a Markdown card and reply.

    Returns the ``message_id``, or an empty string on failure.
    """
    card = build_markdown_card(markdown)
    return reply_card(client, chat_id, root_msg_id, card)


def send_card_to_chat(
    client: lark.Client,
    chat_id: str,
    markdown: str,
) -> str:
    """Build a Markdown card and send it to a chat.

    Returns the ``message_id``, or an empty string on failure.
    """
    card = build_markdown_card(markdown)
    return send_card(client, chat_id, card)
