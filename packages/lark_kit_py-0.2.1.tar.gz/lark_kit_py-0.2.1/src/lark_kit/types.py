from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal


@dataclass
class ClientResult:
    """Result of creating a Feishu/Lark client."""

    client: Any  # lark_oapi.Client
    get_token: Any  # Callable[[], Awaitable[str]]


@dataclass
class DownloadedFile:
    """Metadata for a downloaded file."""

    filepath: str
    filename: str
    size: int
    mime_type: str
    file_key: str


TaskPanelStatus = Literal["running", "completed", "failed", "stopped"]


@dataclass
class TaskPanelCardOptions:
    """Options for building a task panel card."""

    description: str
    status: TaskPanelStatus
    summary: str | None = None
    last_tool_name: str | None = None
    elapsed_seconds: int | None = None
    tokens: int | None = None
    header_icon_img_key: str | None = None


@dataclass
class CardBuildOptions:
    """Options for building a card with thinking/reasoning state."""

    thinking: str | None = None
    thinking_in_progress: bool | None = None
    reasoning_elapsed_ms: int | None = None
    card_title: str | None = None


@dataclass
class HeaderOptions:
    """Options for card header."""

    title: str
    subtitle: str | None = None
    template: str | None = None
    icon_img_key: str | None = None
    icon_token: str | None = None
    tags: list[dict[str, str]] | None = None


@dataclass
class FooterStats:
    """Statistics displayed in card footer."""

    input_tokens: int | None = None
    output_tokens: int | None = None
    tool_count: int | None = None
    duration: int | None = None


@dataclass
class DocumentRecord:
    """A record of a created document."""

    id: str
    created_at: int


@dataclass
class DocCreateOptions:
    """Options for creating a document."""

    via_mcp: bool = False
    meta: dict[str, str] | None = None


@dataclass
class DocCreateResult:
    """Result of creating a document."""

    url: str
    id: str
    warnings: list[str] = field(default_factory=list)
