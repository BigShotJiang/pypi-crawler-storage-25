"""Image resolution module.

Download external images in Markdown, upload them to Feishu, and replace
URLs with Feishu internal ``img_xxx`` format keys.

Processing flow:
1. Extract code blocks (protect code content)
2. Scan for ``![alt](https?://...)`` patterns
3. Serially download + upload (to avoid rate limits)
4. Replace URL -> img_xxx
5. Restore code blocks

Failed images retain their original URLs; downstream ``sanitize_content``
degrades them to links.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from urllib.parse import urlparse

import httpx

from ..card.optimize import extract_code_blocks, restore_code_blocks

# ── Constants ───────────────────────────────────────────────────

IMAGE_UPLOAD_URL = "https://open.feishu.cn/open-apis/im/v1/images"
MAX_IMAGE_SIZE = 10 * 1024 * 1024  # 10 MB
DOWNLOAD_TIMEOUT_MS = 10_000  # 10 s

# Feishu/Lark internal CDN domains — these images need auth, external access fails
INTERNAL_DOMAINS = ("feishucdn.com", "larksuitecdn.com", "feishu.cn", "larksuite.com")

# ── Types ───────────────────────────────────────────────────


@dataclass
class ImageResolveResult:
    """Result of resolving external images."""

    content: str
    uploaded: int = 0
    failed: int = 0


# ── Main function ───────────────────────────────────────────────────


async def resolve_images(markdown: str, token: str) -> ImageResolveResult:
    """Resolve external images in Markdown: download, upload to Feishu, replace URLs."""
    # 1. Extract code blocks, protecting internal content
    text, codes = extract_code_blocks(markdown)

    uploaded = 0
    failed = 0
    result = text

    # 2. Collect all images to process (exclude already-resolved img_ keys, non-http)
    image_re = re.compile(r"!\[([^\]]*)\]\((https?://[^)]+)\)", re.IGNORECASE)
    matches: list[tuple[str, str, str]] = [(m.group(0), m.group(1), m.group(2)) for m in image_re.finditer(text)]

    if not matches:
        return ImageResolveResult(content=restore_code_blocks(text, codes))

    print(f"[IMAGE] Found {len(matches)} external image(s), resolving...", flush=True)

    # 3. Serially process each image
    for full, alt, url in matches:
        # Skip Feishu/Lark internal CDN images (need auth, can't download)
        try:
            hostname = urlparse(url).hostname or ""
            if any(hostname == d or hostname.endswith(f".{d}") for d in INTERNAL_DOMAINS):
                print(f"[IMAGE] Skipped (internal CDN): {url[:80]}", flush=True)
                continue
        except Exception:
            pass  # URL parse failure, try downloading anyway

        try:
            # Download
            buf = await _download_external_image(url)
            if buf is None:
                failed += 1
                continue

            # Upload to Feishu
            image_key = await _upload_image_to_feishu(buf, token)
            if image_key is None:
                failed += 1
                continue

            # Replace URL -> img_xxx
            result = result.replace(full, f"![{alt}]({image_key})", 1)
            uploaded += 1
        except Exception as error:
            print(f"[IMAGE] Failed to resolve {url[:80]}: {error}", flush=True)
            failed += 1

    # 4. Restore code blocks
    final_content = restore_code_blocks(result, codes)

    if uploaded > 0 or failed > 0:
        print(f"[IMAGE] Resolution complete: {uploaded} uploaded, {failed} failed", flush=True)

    return ImageResolveResult(content=final_content, uploaded=uploaded, failed=failed)


# ── Image download ───────────────────────────────────────────────────


async def _download_external_image(url: str) -> bytes | None:
    """Download an external image with timeout and size checks."""
    try:
        async with httpx.AsyncClient(timeout=DOWNLOAD_TIMEOUT_MS / 1000) as http:
            res = await http.get(
                url,
                headers={"User-Agent": "lark-kit-py/1.0"},
            )

        if res.status_code >= 400:
            print(f"[IMAGE] Download failed: {res.status_code} {url[:80]}", flush=True)
            return None

        buf = res.content

        if len(buf) > MAX_IMAGE_SIZE:
            print(
                f"[IMAGE] Too large: {len(buf) / 1024 / 1024:.1f}MB "
                f"(max {MAX_IMAGE_SIZE / 1024 / 1024:.0f}MB) {url[:80]}",
                flush=True,
            )
            return None

        if len(buf) < 100:
            print(f"[IMAGE] Too small: {len(buf)} bytes, likely not an image {url[:80]}", flush=True)
            return None

        return buf
    except httpx.TimeoutException:
        print(f"[IMAGE] Download timeout ({DOWNLOAD_TIMEOUT_MS}ms): {url[:80]}", flush=True)
        return None
    except Exception as error:
        print(f"[IMAGE] Download error: {url[:80]} {error}", flush=True)
        return None


# ── Image upload ───────────────────────────────────────────────────


async def _upload_image_to_feishu(buf: bytes, token: str) -> str | None:
    """Upload image to Feishu.

    API: POST /open-apis/im/v1/images
    Content-Type: multipart/form-data
    Form: image_type=message, image=<binary>
    """
    try:
        # Detect image type from header bytes
        header = buf[:4].hex()
        if header.startswith("89504e47"):
            media_type, ext = "image/png", "png"
        elif header.startswith("47494638"):
            media_type, ext = "image/gif", "gif"
        elif header.startswith("52494646"):
            media_type, ext = "image/webp", "webp"
        elif header.startswith("00000100"):
            media_type, ext = "image/ico", "ico"
        else:
            media_type, ext = "image/jpeg", "jpg"

        async with httpx.AsyncClient() as http:
            res = await http.post(
                IMAGE_UPLOAD_URL,
                headers={"Authorization": f"Bearer {token}"},
                data={"image_type": "message"},
                files={"image": (f"image.{ext}", buf, media_type)},
            )

        if res.status_code >= 400:
            print(f"[IMAGE] Upload API error: {res.status_code} {res.text[:200]}", flush=True)
            return None

        data = res.json()

        if data.get("code") != 0:
            print(f"[IMAGE] Upload failed ({data.get('code')}): {data.get('msg')}", flush=True)
            return None

        image_key = (data.get("data") or {}).get("image_key")
        if not image_key:
            print("[IMAGE] No image_key in upload response", flush=True)
            return None

        size_kb = len(buf) // 1024
        print(f"[IMAGE] Uploaded: {image_key} ({media_type}, {size_kb}KB)", flush=True)
        return image_key
    except Exception as error:
        print(f"[IMAGE] Upload error: {error}", flush=True)
        return None
