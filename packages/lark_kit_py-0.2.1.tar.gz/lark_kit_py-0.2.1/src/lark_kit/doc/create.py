"""Document creation module.

Provides the ability to create Feishu cloud documents via the Block API, including:
- Document creation
- Batch block writing (50 per batch, 429 exponential backoff retry)
- Callout two-step creation
"""

from __future__ import annotations

import asyncio

import httpx

from ..format import BlockType, CalloutCreateData, DocumentBlockItem, parse_inline_text
from ..types import DocCreateOptions, DocCreateResult

# ── Constants ───────────────────────────────────────────────────

BATCH_SIZE = 50
DOCX_API_BASE = "https://open.feishu.cn/open-apis/docx/v1/documents"


# ── Response parsing ───────────────────────────────────────────────────


async def _safe_json_parse(res: httpx.Response, context: str) -> dict:
    """Safely parse an HTTP response as JSON.

    Checks HTTP status code and attempts JSON parsing; raises an error with
    context information on failure.
    """
    text = res.text
    if res.status_code >= 400:
        raise RuntimeError(f"{context} failed ({res.status_code}): {text[:200]}")
    try:
        return res.json()
    except Exception:
        raise RuntimeError(f"{context} returned non-JSON: {text[:200]}")


# ── Document creation ───────────────────────────────────────────────────


async def create_document(
    token: str,
    title: str,
    blocks: list[DocumentBlockItem],
    options: DocCreateOptions | None = None,
) -> DocCreateResult:
    """Create a Feishu cloud document and write content via the Block API.

    Write flow (strict ordering):
    1. Create an empty document
    2. Simple blocks are batch-written via the children API
    3. Tables are degraded to code blocks (block API does not support table creation via children)
    4. Callouts are created via multi-step children API
    """
    # 1. Create empty document
    async with httpx.AsyncClient() as http:
        create_res = await http.post(
            DOCX_API_BASE,
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            },
            json={"title": title},
        )

    create_data = await _safe_json_parse(create_res, "Create document")
    doc_id = (create_data.get("data") or {}).get("document", {}).get("document_id")

    if not doc_id:
        raise RuntimeError("Failed to create document: no document_id returned")

    # 2. Strictly ordered block writing
    simple_batch: list[dict] = []
    is_first_batch = True
    batch_index = 0
    write_warnings: list[str] = []

    async def flush_simple_batch() -> None:
        nonlocal simple_batch, is_first_batch, batch_index
        if not simple_batch:
            return
        batch_index += 1
        index = 0 if is_first_batch else -1
        batch_types = [b.get("block_type") for b in simple_batch]

        try:
            await batch_create_blocks(token, doc_id, doc_id, simple_batch, index)
            is_first_batch = False
        except Exception as error:
            err_msg = f"Batch {batch_index} write failed ({len(simple_batch)} blocks), skipped"
            print(f"[DOC] {err_msg}: {error}", flush=True)
            print(f"[DOC] Block types: {batch_types}", flush=True)
            write_warnings.append(err_msg)
        finally:
            simple_batch = []

    for i, item in enumerate(blocks):
        item_type = item.get("type")

        if item_type == "simple":
            simple_batch.append(item["block"])
            if len(simple_batch) >= BATCH_SIZE:
                await flush_simple_batch()

        elif item_type == "table":
            await flush_simple_batch()
            # block API does not support table creation via children (API 9499), degrade to code block
            table_prop = item["data"]["property"]
            raw_md = item["data"].get("raw_markdown", "")
            row_size = table_prop.get("row_size", "?")
            col_size = table_prop.get("column_size", "?")
            write_warnings.append(f"Table render failed ({row_size} rows x {col_size} cols)")
            fallback_content = (
                f"Table render failed ({row_size} rows x {col_size} cols), raw content:\n{raw_md}"
                if raw_md
                else f"Table render failed ({row_size} rows x {col_size} cols)"
            )
            simple_batch.append({
                "block_type": BlockType["CODE"],
                "code": {
                    "style": {"language": 1, "wrap": True},
                    "elements": [{"text_run": {"content": fallback_content}}],
                },
            })

        elif item_type == "callout":
            await flush_simple_batch()
            try:
                await create_callout_via_children(token, doc_id, item["data"])
            except Exception as error:
                print(f"[DOC] Callout creation failed at item {i}: {error}", flush=True)
                write_warnings.append("Callout render failed")
                # Degrade to quote block
                simple_batch.append({
                    "block_type": BlockType["QUOTE"],
                    "quote": {"elements": [{"text_run": {"content": "\n".join(item["data"]["text_lines"])}}]},
                })

    # Flush remaining simple blocks
    await flush_simple_batch()

    return DocCreateResult(
        url=f"https://feishu.cn/docx/{doc_id}",
        id=doc_id,
        warnings=write_warnings,
    )


# ── Batch block writing ───────────────────────────────────────────────────


async def batch_create_blocks(
    token: str,
    doc_id: str,
    parent_id: str,
    children: list[dict],
    index: int = 0,
) -> list[str]:
    """Batch create document blocks (children API).

    - Max 50 blocks per batch
    - 429 rate limit: exponential backoff retry (2s * attempt), max 3 retries

    Returns list of server-assigned block_id values.
    """
    url = f"{DOCX_API_BASE}/{doc_id}/blocks/{parent_id}/children"
    max_retries = 3

    for attempt in range(1, max_retries + 1):
        async with httpx.AsyncClient() as http:
            res = await http.post(
                url,
                headers={
                    "Authorization": f"Bearer {token}",
                    "Content-Type": "application/json",
                },
                json={"children": children, "index": index},
            )

        # Rate limit: exponential backoff retry
        if res.status_code == 429 and attempt < max_retries:
            delay = attempt * 2
            print(
                f"[DOC] Rate limited (429), retry {attempt}/{max_retries} after {delay}s",
                flush=True,
            )
            await asyncio.sleep(delay)
            continue

        data = await _safe_json_parse(res, "Batch create blocks")

        if data.get("code") != 0:
            print(f"[DOC] API error response: {data}", flush=True)
            raise RuntimeError(f"Write content failed ({data.get('code')}): {data.get('msg')}")

        return [
            c.get("block_id", "")
            for c in (data.get("data", {}).get("children") or [])
            if c.get("block_id")
        ]

    raise RuntimeError("Write content failed after rate limit retries")


# ── Callout creation ───────────────────────────────────────────────────


async def create_callout_via_children(
    token: str,
    doc_id: str,
    callout_data: CalloutCreateData,
) -> None:
    """Create a callout via multi-step children API.

    Step 1: Create callout container block
    Step 2: Create text child blocks as callout children
    """
    # Step 1: Create callout container block
    callout_block: dict = {
        "block_type": BlockType["CALLOUT"],
        "callout": callout_data.callout,
    }

    callout_ids = await batch_create_blocks(token, doc_id, doc_id, [callout_block], -1)
    callout_id = callout_ids[0] if callout_ids else None
    if not callout_id:
        raise RuntimeError("Failed to get callout block_id")

    # Step 2: Create text child blocks
    if callout_data.text_lines:
        text_blocks: list[dict] = [
            {
                "block_type": BlockType["TEXT"],
                "text": {"elements": parse_inline_text(line)},
            }
            for line in callout_data.text_lines
        ]
        await batch_create_blocks(token, doc_id, callout_id, text_blocks, -1)
