"""doc module entry point -- document operations factory.

Provides a unified document operations interface:
- create: create cloud documents (MCP first + Block API fallback)
- cleanup: clean up old documents
- resolve_images: resolve and upload external images
"""

from __future__ import annotations

from typing import Any, Awaitable, Callable

from ..types import DocCreateOptions, DocCreateResult
from .cleanup import cleanup_old_documents, register_document
from .create import batch_create_blocks, create_callout_via_children, create_document, _safe_json_parse
from .create_mcp import create_doc_via_mcp
from .image import ImageResolveResult, resolve_images

__all__ = [
    "doc",
    "DocOps",
    # sub-module re-exports
    "create_document",
    "batch_create_blocks",
    "create_callout_via_children",
    "_safe_json_parse",
    "create_doc_via_mcp",
    "cleanup_old_documents",
    "register_document",
    "resolve_images",
    "ImageResolveResult",
    "load_doc_registry",
    "save_doc_registry",
    "get_doc_registry_path",
    "get_oldest_documents",
    "remove_document_record",
]


# Re-export registry helpers under public names for convenience
from .cleanup import (
    _get_doc_registry_path as get_doc_registry_path,
    _get_oldest_documents as get_oldest_documents,
    _load_doc_registry as load_doc_registry,
    _remove_document_record as remove_document_record,
    _save_doc_registry as save_doc_registry,
)


class DocOps:
    """High-level document operations bound to a client and token provider."""

    def __init__(self, client: Any, get_token: Callable[[], Awaitable[str]]) -> None:
        self._client = client
        self._get_token = get_token

    async def create(
        self,
        title: str,
        blocks: list[dict],
        options: DocCreateOptions | None = None,
    ) -> DocCreateResult:
        """Create a cloud document."""
        token = await self._get_token()
        profile = "default"
        via_mcp = False

        if options:
            via_mcp = options.via_mcp
            if options.meta and "profile" in options.meta:
                profile = options.meta["profile"]

        # MCP path: try MCP first, fallback to Block API
        if via_mcp:
            try:
                result = await create_doc_via_mcp(token, title, "")
                register_document(result["id"], profile)
                return DocCreateResult(url=result["url"], id=result["id"])
            except Exception as error:
                print(f"[DOC] MCP creation failed, falling back to block API: {error}", flush=True)

        # Block API path
        result = await create_document(token, title, blocks, options)
        register_document(result.id, profile)
        return result

    async def cleanup(self, max_docs: int, profile: str = "default") -> dict:
        """Clean up old documents exceeding the retention limit."""
        token = await self._get_token()
        return await cleanup_old_documents(token, max_docs, profile)

    async def resolve_images(self, markdown: str) -> ImageResolveResult:
        """Resolve external images in Markdown and upload to Feishu."""
        token = await self._get_token()
        return await resolve_images(markdown, token)


def doc(client: Any, *, get_token: Callable[[], Awaitable[str]]) -> DocOps:
    """Create a document operations instance.

    Args:
        client: lark Client instance (kept for future extension).
        get_token: Async callable returning a tenant access token.

    Returns:
        A ``DocOps`` instance.
    """
    return DocOps(client=client, get_token=get_token)
