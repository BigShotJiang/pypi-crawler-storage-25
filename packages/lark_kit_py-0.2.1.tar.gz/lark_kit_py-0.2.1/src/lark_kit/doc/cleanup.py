"""Document registry and cleanup module.

Locally track created documents (separate file per profile), supporting:
- Document registration
- Querying oldest documents by creation time
- Batch cleanup of documents exceeding a retention limit
- Removing individual document records
"""

from __future__ import annotations

import json
import os
import pathlib
import time

import httpx

from ..types import DocumentRecord

# ── Constants ───────────────────────────────────────────────────

DOC_REGISTRY_DIR = pathlib.Path.home() / ".lark-kit-ts"
DRIVE_API_BASE = "https://open.feishu.cn/open-apis/drive/v1/files"


# ── Registry path ───────────────────────────────────────────────────


def _get_doc_registry_path(profile: str) -> pathlib.Path:
    """Return the registry file path for the given profile."""
    if not profile or profile == "default":
        return DOC_REGISTRY_DIR / "doc-registry.json"
    return DOC_REGISTRY_DIR / f"doc-registry-{profile}.json"


# ── Registry read/write ───────────────────────────────────────────────────


def _load_doc_registry(profile: str) -> list[DocumentRecord]:
    """Load the document registry. Returns an empty list on failure."""
    try:
        file_path = _get_doc_registry_path(profile)
        if file_path.exists():
            raw = json.loads(file_path.read_text(encoding="utf-8"))
            return [DocumentRecord(id=r["id"], created_at=r["createdAt"]) for r in raw]
    except Exception:
        pass
    return []


def _save_doc_registry(profile: str, records: list[DocumentRecord]) -> None:
    """Save the document registry, creating the directory if necessary."""
    DOC_REGISTRY_DIR.mkdir(parents=True, exist_ok=True)
    file_path = _get_doc_registry_path(profile)
    data = [{"id": r.id, "createdAt": r.created_at} for r in records]
    file_path.write_text(json.dumps(data, indent=2), encoding="utf-8")


# ── Document registration ───────────────────────────────────────────────────


def register_document(doc_id: str, profile: str = "default") -> None:
    """Register a newly created document in the local registry."""
    records = _load_doc_registry(profile)
    records.append(DocumentRecord(id=doc_id, created_at=int(time.time() * 1000)))
    _save_doc_registry(profile, records)


# ── Document query ───────────────────────────────────────────────────


def _get_oldest_documents(profile: str, keep_count: int) -> list[DocumentRecord]:
    """Return documents exceeding the retention limit, oldest first."""
    records = _load_doc_registry(profile)
    sorted_docs = sorted(records, key=lambda r: r.created_at)
    if len(sorted_docs) <= keep_count:
        return []
    return sorted_docs[: len(sorted_docs) - keep_count]


def _remove_document_record(doc_id: str, profile: str) -> None:
    """Remove a single document record from the registry."""
    records = _load_doc_registry(profile)
    filtered = [r for r in records if r.id != doc_id]
    _save_doc_registry(profile, filtered)


# ── Batch cleanup ───────────────────────────────────────────────────


async def cleanup_old_documents(
    token: str,
    max_docs: int,
    profile: str = "default",
) -> dict:
    """Clean up old documents.

    Uses the local registry to track documents, sorts by creation time, and
    deletes documents exceeding the retention limit.

    Note: the docx API has no DELETE endpoint; we use the drive API instead.

    Returns:
        dict with ``deleted`` and ``failed`` counts.
    """
    result = {"deleted": 0, "failed": 0}

    try:
        to_delete = _get_oldest_documents(profile, max_docs)

        for doc in to_delete:
            try:
                async with httpx.AsyncClient() as http:
                    res = await http.delete(
                        f"{DRIVE_API_BASE}/{doc.id}",
                        params={"type": "docx"},
                        headers={"Authorization": f"Bearer {token}"},
                    )

                if res.status_code >= 400:
                    text = res.text[:200]
                    raise RuntimeError(f"HTTP {res.status_code}: {text}")

                delete_data = res.json()

                # Only remove record on confirmed success (code=0)
                # or document already gone (1061003 / 1061007)
                code = delete_data.get("code")
                if code in (0, 1061003, 1061007):
                    result["deleted"] += 1
                    _remove_document_record(doc.id, profile)
                else:
                    result["failed"] += 1
                    print(f"[CLEANUP] Failed to delete {doc.id}: {delete_data}", flush=True)
            except Exception as error:
                result["failed"] += 1
                print(f"[CLEANUP] Network error deleting {doc.id}: {error}", flush=True)
    except Exception as error:
        print(f"[CLEANUP] Error: {error}", flush=True)

    return result
