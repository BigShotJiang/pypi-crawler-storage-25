"""MCP document creation module.

Create documents via the Feishu MCP service (server handles markdown -> block
conversion, including tables, callouts, etc.).

Reference: https://github.com/larksuite/cli (X-Lark-MCP-TAT auth, JSON-RPC protocol)
"""

from __future__ import annotations

import uuid

import httpx

# ── Constants ───────────────────────────────────────────────────

MCP_ENDPOINT = "https://mcp.feishu.cn/mcp"


# ── MCP document creation ───────────────────────────────────────────────────


async def create_doc_via_mcp(
    token: str,
    title: str,
    markdown: str,
) -> dict:
    """Create a document via the Feishu MCP service.

    Sends a JSON-RPC request to the MCP endpoint using X-Lark-MCP-TAT auth.
    The MCP server handles markdown -> block conversion (including tables,
    callouts, and other complex blocks).

    Returns:
        dict with keys ``url`` and ``id``.
    """
    body = {
        "jsonrpc": "2.0",
        "id": str(uuid.uuid4()),
        "method": "tools/call",
        "params": {
            "name": "create-doc",
            "arguments": {"title": title, "markdown": markdown},
        },
    }

    async with httpx.AsyncClient() as http:
        res = await http.post(
            MCP_ENDPOINT,
            headers={
                "Content-Type": "application/json",
                "X-Lark-MCP-TAT": token,
                "X-Lark-MCP-Allowed-Tools": "create-doc",
            },
            json=body,
        )

    if res.status_code >= 400:
        raise RuntimeError(f"MCP HTTP {res.status_code}: {res.text[:200]}")

    data = res.json()

    if data.get("error"):
        err = data["error"]
        raise RuntimeError(f"MCP error ({err.get('code')}): {err.get('message')}")

    content = None
    result_items = (data.get("result") or {}).get("content") or []
    if result_items:
        content = result_items[0].get("text")

    if not content:
        raise RuntimeError("MCP response missing content")

    import json

    doc_info = json.loads(content)

    doc_id = doc_info.get("doc_id")
    if not doc_id:
        raise RuntimeError(f"MCP did not return doc_id: {doc_info.get('message', content)}")

    return {
        "url": doc_info.get("doc_url", f"https://feishu.cn/docx/{doc_id}"),
        "id": doc_id,
    }
