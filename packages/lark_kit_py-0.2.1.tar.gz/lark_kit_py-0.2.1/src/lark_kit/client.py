from __future__ import annotations

import os

import lark_oapi as lark

from .token import get_tenant_access_token
from .types import ClientResult

# Re-export lark_oapi so users can ``from lark_kit.client import lark``
__all__ = ["create_client", "create_ws_client", "lark"]


def create_client(*, app_id: str, app_secret: str) -> ClientResult:
    """Create a Feishu/Lark API client with token management.

    Returns a :class:`ClientResult` containing the SDK client and an async
    callable that resolves to a valid tenant access token.
    """
    client = lark.Client.builder().app_id(app_id).app_secret(app_secret).build()
    return ClientResult(
        client=client,
        get_token=lambda: get_tenant_access_token(app_id, app_secret),
    )


def create_ws_client(*, app_id: str, app_secret: str) -> lark.ws.Client:
    """Create a WebSocket client for receiving Feishu/Lark events.

    Reads ``https_proxy`` / ``HTTPS_PROXY`` from the environment and configures
    the underlying websockets connection to go through the proxy when set.
    """
    proxy_url = os.environ.get("https_proxy") or os.environ.get("HTTPS_PROXY")

    kwargs: dict = {
        "app_id": app_id,
        "app_secret": app_secret,
    }

    if proxy_url:
        # websockets library supports proxy via ``proxy`` parameter on connect
        # The lark-oapi ws.Client passes extra kwargs through; we set it on
        # the websockets connection by monkey-patching the endpoint resolution.
        # Since lark-oapi ws.Client doesn't natively expose a proxy param,
        # we patch the module-level websockets.connect default.
        import websockets

        _original_connect = websockets.connect

        def _proxied_connect(*args, **ws_kwargs):
            ws_kwargs.setdefault("proxy", proxy_url)
            return _original_connect(*args, **ws_kwargs)

        # This is a temporary measure; the patch is active for the lifetime
        # of the returned client.  A cleaner approach would be contributed
        # upstream to lark-oapi.
        websockets.connect = _proxied_connect

    return lark.ws.Client(**kwargs)
