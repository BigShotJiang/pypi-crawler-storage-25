"""FlushController -- throttled buffer with gap detection and heartbeat.

Core mechanism (ported from lark-kit-ts/src/cardkit/flush.ts):

- Mutex guard prevents concurrent flushes.
- Adaptive delay: ``delay = max(0, min_interval - elapsed)``.
- Long-gap detection: 2 s without new content -> force flush remaining buffer.
- Heartbeat: 15 s without a flush -> force flush even if buffer unchanged,
  preventing CardKit streaming-mode timeout on the server side.

Lifecycle: ``start()`` -> ``[append() -> do_flush()]*`` -> ``stop()``
"""

from __future__ import annotations

import asyncio
import time
from collections.abc import Awaitable, Callable

# -- Constants -----------------------------------------------------------------

# 2 seconds without new content -> force flush.
LONG_GAP_S = 2.0

# Check for long gap every 500 ms.
GAP_CHECK_INTERVAL_S = 0.5

# 15 seconds without a flush -> heartbeat flush (prevents CardKit stream timeout).
HEARTBEAT_S = 15.0


class FlushController:
    """Throttled buffer controller.

    Callers append text via :meth:`append` and the controller invokes
    ``on_flush`` at controlled intervals with the accumulated buffer.
    """

    def __init__(
        self,
        min_interval_ms: int,
        on_flush: Callable[[str], Awaitable[None]],
        on_error: Callable[[BaseException], None] | None = None,
    ) -> None:
        self._min_interval: float = min_interval_ms / 1000.0
        self._on_flush = on_flush
        self._on_error = on_error

        self._buffer: str = ""
        self._sent_length: int = 0
        self._flushing: bool = False  # mutex lock
        self._stopped: bool = False
        self._started: bool = False
        self._last_flush_time: float = 0.0
        self._last_append_time: float = 0.0

        self._flush_task: asyncio.Task[None] | None = None  # scheduled delayed flush
        self._tasks: list[asyncio.Task[None]] = []  # background loops

    # -- Public API --------------------------------------------------------

    def append(self, text: str) -> None:
        """Append text to the buffer."""
        if self._stopped:
            return
        self._buffer += text
        self._last_append_time = time.monotonic()
        self._schedule_flush()

    def start(self) -> None:
        """Start long-gap detection and heartbeat loops."""
        if self._started:
            return
        self._started = True
        self._last_append_time = time.monotonic()
        self._last_flush_time = time.monotonic()
        self._tasks.append(asyncio.create_task(self._gap_check_loop()))
        self._tasks.append(asyncio.create_task(self._heartbeat_loop()))

    def stop(self) -> None:
        """Stop all background tasks and cancel pending flushes.

        After this, :meth:`append` becomes a no-op.  The caller is
        responsible for flushing any remaining buffer content.
        """
        self._stopped = True
        if self._flush_task is not None:
            self._flush_task.cancel()
            self._flush_task = None
        for t in self._tasks:
            t.cancel()
        self._tasks.clear()

    async def flush(self) -> None:
        """Force an immediate flush (even if buffer is empty).

        Useful for status changes where the caller needs to push current
        content right away.
        """
        await self._do_flush(force=True)

    def get_buffer(self) -> str:
        """Get the current buffer content."""
        return self._buffer

    # -- Internal: scheduling ----------------------------------------------

    def _schedule_flush(self) -> None:
        if self._flush_task is not None or self._stopped:
            return

        elapsed = time.monotonic() - self._last_flush_time
        delay = max(0.0, self._min_interval - elapsed)

        async def _timed_flush() -> None:
            self._flush_task = None
            await self._do_flush(force=False)

        self._flush_task = asyncio.create_task(_delayed(delay, _timed_flush()))

    # -- Internal: flush execution -----------------------------------------

    async def _do_flush(self, *, force: bool) -> None:
        if self._flushing or self._stopped:
            return
        if not force and len(self._buffer) <= self._sent_length:
            return

        self._flushing = True
        try:
            await self._on_flush(self._buffer)
            if not force:
                self._sent_length = len(self._buffer)
            self._last_flush_time = time.monotonic()
        except BaseException as exc:
            if self._on_error is not None:
                self._on_error(exc)
            self.stop()
            return
        finally:
            self._flushing = False

        # New content may have arrived during the flush -- keep scheduling.
        if not self._stopped and len(self._buffer) > self._sent_length:
            self._schedule_flush()

    # -- Internal: background loops ----------------------------------------

    async def _gap_check_loop(self) -> None:
        """Periodically check for long gaps (2 s without new content)."""
        try:
            while not self._stopped:
                await asyncio.sleep(GAP_CHECK_INTERVAL_S)
                if self._stopped or self._flushing:
                    continue
                now = time.monotonic()

                # 2 s long gap: force flush when there is unsent content.
                if now - self._last_append_time > LONG_GAP_S:
                    if len(self._buffer) > self._sent_length:
                        await self._do_flush(force=False)
        except asyncio.CancelledError:
            pass

    async def _heartbeat_loop(self) -> None:
        """Force a flush every 15 s even if buffer is unchanged."""
        try:
            while not self._stopped:
                await asyncio.sleep(HEARTBEAT_S)
                if self._stopped or self._flushing:
                    continue
                if time.monotonic() - self._last_flush_time > HEARTBEAT_S:
                    await self._do_flush(force=True)
        except asyncio.CancelledError:
            pass


# -- Helpers -------------------------------------------------------------------

async def _delayed(seconds: float, coro: Awaitable[None]) -> None:
    """Await *seconds* then await the given coroutine."""
    if seconds > 0:
        await asyncio.sleep(seconds)
    await coro
