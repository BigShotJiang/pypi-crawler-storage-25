"""CardKit module -- streaming card controller.

Single-card architecture aligned with the Feishu/Lark official openclaw
approach. One card message is maintained throughout the lifecycle and
updated via the CardKit API to produce a typewriter effect.

State machine: idle -> creating -> streaming -> completed / aborted

API call chain (via Lark SDK):

1. ``client.cardkit.v1.card.acreate()``         -> create card entity
2. ``client.im.v1.message.areply({card_id})``   -> send card reference into chat
3. ``client.cardkit.v1.card_element.acontent()`` -> streaming typewriter
4. ``client.cardkit.v1.card.asettings()``        -> disable streaming_mode
5. ``client.cardkit.v1.card.aupdate()``          -> final card content update

Ported from lark-kit-ts/src/cardkit/index.ts.
"""

from __future__ import annotations

import json
import sys
from dataclasses import dataclass, field
from typing import Any

import lark_oapi as lark
from lark_oapi.api.cardkit.v1 import (
    Card as CardModel,
    CreateCardRequest,
    CreateCardRequestBody,
    ContentCardElementRequest,
    ContentCardElementRequestBody,
    SettingsCardRequest,
    SettingsCardRequestBody,
    UpdateCardRequest,
    UpdateCardRequestBody,
)
from lark_oapi.api.im.v1 import (
    ReplyMessageRequest,
    ReplyMessageRequestBody,
)

from ..card.builder import (
    HeaderOptions,
    HeaderTag,
    build_header,
    build_footer_markdown,
)
from ..card.optimize import optimize_for_card, truncate_safely
from ..card.thinking import build_thinking_panel, format_duration
from ..format.thinking import strip_thinking
from .flush import FlushController
from .mutex import create_mutex

__all__ = [
    # Factory
    "cardkit",
    "CardKitOps",
    "CardEntity",
    "CreateOptions",
    "CompleteOptions",
    "CardKitApiError",
    # Re-exports
    "FlushController",
]

# -- Constants -----------------------------------------------------------------

TRUNCATE_LIMIT = 4000
DEFAULT_FLUSH_INTERVAL_MS = 300

_STREAM_ELEMENT_ID = "streaming_content"


# -- State machine -------------------------------------------------------------

type Phase = str  # "idle" | "creating" | "streaming" | "completed" | "aborted"


# -- CardKit API Error --------------------------------------------------------


class CardKitApiError(Exception):
    """Error returned by the CardKit API."""

    def __init__(self, code: int, msg: str, context: str) -> None:
        super().__init__(f"{context} failed ({code}): {msg}")
        self.name = "CardKitApiError"
        self.code = code

    @property
    def is_rate_limit(self) -> bool:
        return self.code == 230020

    @property
    def is_table_limit(self) -> bool:
        return self.code in (230099, 11310)


def _check_card_kit_error(response: Any, context: str) -> CardKitApiError | None:
    """Check an SDK response for a non-zero error code."""
    code = getattr(response, "code", None)
    if code is not None and code != 0:
        msg = getattr(response, "msg", "unknown") or "unknown"
        return CardKitApiError(code, msg, context)
    return None


# -- Public types --------------------------------------------------------------


@dataclass
class CompleteOptions:
    """Options for the ``complete()`` step."""

    metadata: str | None = None
    thinking: str | None = None
    reasoning_elapsed_ms: float | None = None
    card_title: str | None = None
    stats: Stats | None = None
    header_icon_img_key: str | None = None


@dataclass
class Stats:
    """Structured statistics shown in the final card header/footer."""

    model: str | None = None
    input_tokens: int | None = None
    output_tokens: int | None = None
    duration: float | None = None
    tool_count: int | None = None


@dataclass
class CreateOptions:
    """Options for ``create()``."""

    streaming: bool = True
    card_title: str | None = None
    header_icon_img_key: str | None = None


@dataclass
class CardEntity:
    """Card entity returned by ``create()``."""

    card_id: str
    msg_id: str | None = None


# -- Internal per-card state ---------------------------------------------------


@dataclass
class _CardState:
    phase: Phase
    card_id: str
    card_title: str
    header_icon_img_key: str | None
    streaming: bool
    sequence: int
    status_text: str
    flush_ctrl: FlushController | None
    with_mutex: Any  # Callable[[Callable[[], Awaitable[T]]], Awaitable[T]]
    stream_element_id: str = _STREAM_ELEMENT_ID


# -- Factory -------------------------------------------------------------------


class CardKitOps:
    """Operations returned by the :func:`cardkit` factory.

    Create / sendRef / write / close / update / complete operations that
    mirror the original CardKitController but are card-ID-oriented rather
    than tied to a single card lifecycle.
    """

    __slots__ = ("_client", "_cards")

    def __init__(self, client: lark.Client) -> None:
        self._client = client
        self._cards: dict[str, _CardState] = {}

    def _get_state(self, card_id: str, context: str) -> _CardState:
        state = self._cards.get(card_id)
        if state is None:
            raise ValueError(
                f'CardKit: unknown card_id "{card_id}" ({context})'
            )
        return state

    # -- create ---------------------------------------------------------------

    async def create(self, options: CreateOptions | None = None) -> CardEntity:
        """Create a card entity (optionally in streaming mode)."""
        if options is None:
            options = CreateOptions()

        streaming = options.streaming
        card_title = options.card_title or ""
        header_icon_img_key = options.header_icon_img_key
        stream_element_id = _STREAM_ELEMENT_ID

        card_json: dict[str, Any] = {
            "schema": "2.0",
            "config": {
                **({"streaming_mode": True, "update_multi": True} if streaming else {}),
                "wide_screen_mode": True,
                "width_mode": "fill",
            },
            "summary": {
                "content": "\U0001f916 Thinking\u2026",
                "i18n_content": {
                    "zh_cn": "\U0001f916 \u601d\u8003\u4e2d\u2026",
                    "en_us": "\U0001f916 Thinking\u2026",
                },
            },
            "body": {
                "elements": [
                    {
                        "tag": "markdown",
                        "content": "",
                        "element_id": stream_element_id,
                    },
                ],
            },
        }

        if card_title:
            card_json["header"] = build_header(
                HeaderOptions(
                    title=card_title,
                    subtitle="Thinking\u2026" if streaming else None,
                    template="indigo",
                    icon_img_key=header_icon_img_key,
                )
            )

        # Build SDK request
        body = CreateCardRequestBody.builder() \
            .type("card_json") \
            .data(json.dumps(card_json)) \
            .build()
        request = CreateCardRequest.builder() \
            .request_body(body) \
            .build()

        res = await self._client.cardkit.v1.card.acreate(request)

        err = _check_card_kit_error(res, "Create card")
        if err:
            print(f"[CARDKIT] {err}", file=sys.stderr)
            raise err

        card_id = res.data.card_id if res.data else None
        if not card_id:
            raw = json.dumps(res.__dict__)[:500] if res else "empty"
            print(f"[CARDKIT] Create card response: {raw}", file=sys.stderr)
            raise RuntimeError("CardKit: no card_id in response")

        # Initialize per-card state
        with_mutex = create_mutex()
        state = _CardState(
            phase="streaming" if streaming else "completed",
            card_id=card_id,
            card_title=card_title,
            header_icon_img_key=header_icon_img_key,
            streaming=streaming,
            sequence=0,
            status_text="",
            flush_ctrl=None,
            with_mutex=with_mutex,
            stream_element_id=stream_element_id,
        )

        if streaming:
            state.flush_ctrl = FlushController(
                min_interval_ms=DEFAULT_FLUSH_INTERVAL_MS,
                on_flush=lambda content: self._perform_flush(card_id, content),
                on_error=lambda error: print(
                    f"[CARDKIT] Flush failed: {error}", file=sys.stderr
                ),
            )
            state.flush_ctrl.start()

        self._cards[card_id] = state
        print(f"[CARDKIT] Card created: {card_id}", file=sys.stderr)
        return CardEntity(card_id=card_id)

    # -- sendRef --------------------------------------------------------------

    async def send_ref(
        self, chat_id: str, root_msg_id: str, card_id: str
    ) -> str:
        """Send a card reference into a chat by replying to an existing message."""
        self._get_state(card_id, "sendRef")

        body = ReplyMessageRequestBody.builder() \
            .content(json.dumps({"type": "card", "data": {"card_id": card_id}})) \
            .msg_type("interactive") \
            .build()
        request = ReplyMessageRequest.builder() \
            .message_id(root_msg_id) \
            .request_body(body) \
            .build()

        res = await self._client.im.v1.message.areply(request)

        msg_id = ""
        if res.data and res.data.message_id:
            msg_id = res.data.message_id

        return msg_id

    # -- write ----------------------------------------------------------------

    async def write(self, card_id: str, content: str) -> None:
        """Stream text to the card (typewriter effect). Must call create() first."""
        state = self._get_state(card_id, "write")

        if (
            state.phase in ("completed", "aborted")
            or not state.streaming
            or state.flush_ctrl is None
        ):
            return

        state.flush_ctrl.append(content)

    # -- close ----------------------------------------------------------------

    async def close(
        self, card_id: str, *, summary: str | None = None
    ) -> None:
        """Close streaming mode and optionally set a summary."""
        state = self._get_state(card_id, "close")

        if not state.streaming:
            return

        # Stop the flush controller first.
        if state.flush_ctrl is not None:
            state.flush_ctrl.stop()

        async def _close() -> None:
            state.sequence += 1
            await self._close_streaming_mode(state, summary)

        await state.with_mutex(_close)
        state.streaming = False
        state.phase = "completed"

    # -- update ---------------------------------------------------------------

    async def update(self, card_id: str, card_json: dict[str, Any]) -> None:
        """Replace the entire card content with the given JSON object."""
        state = self._get_state(card_id, "update")

        async def _update() -> None:
            state.sequence += 1
            await self._update_card(state, card_json)

        await state.with_mutex(_update)

    # -- complete -------------------------------------------------------------

    async def complete(
        self,
        card_id: str,
        final_content: str,
        options: CompleteOptions | None = None,
    ) -> None:
        """Convenience: close streaming mode + update with final card content.

        Builds the final card JSON internally using the provided content and
        options, then performs the two-step close (settings -> card.update)
        aligned with the openclaw-lark approach.
        """
        if options is None:
            options = CompleteOptions()

        state = self._get_state(card_id, "complete")

        # Stop flushing.
        if state.flush_ctrl is not None:
            state.flush_ctrl.stop()
        state.status_text = ""

        if state.phase == "completed":
            return

        # Build the final card JSON.
        optimized = optimize_for_card(final_content)
        pre_truncated = (
            truncate_safely(optimized, TRUNCATE_LIMIT)
            if len(optimized) > TRUNCATE_LIMIT
            else optimized
        )

        extra_elements = _build_thinking_elements(
            options.thinking,
            options.reasoning_elapsed_ms,
        )

        final_card_json = self._build_final_card(
            state, pre_truncated, extra_elements, options.stats
        )

        # Two-step close aligned with openclaw-lark:
        # 1. close streaming_mode  2. update card content
        async def _close_and_update() -> None:
            state.sequence += 1
            summary = (
                None
                if options.stats
                else (options.metadata if options.metadata else None)
            )
            await self._close_streaming_mode(state, summary)
            state.sequence += 1
            await self._update_card(state, final_card_json)

        await state.with_mutex(_close_and_update)
        state.streaming = False
        state.phase = "completed"

    # -- Internal helpers -----------------------------------------------------

    async def _perform_flush(self, card_id: str, content: str) -> None:
        """Perform a streaming content flush for the given card."""
        state = self._cards.get(card_id)
        if state is None or state.phase != "streaming" or not state.streaming:
            return

        display_content = content
        # Default: strip thinking tags for streaming display.
        display_content = strip_thinking(display_content)

        # Prepend tool/status text.
        if state.status_text:
            display_content = f"{state.status_text}\n\n{display_content}"

        if not display_content.strip():
            return

        # Truncate then optimize, avoiding useless regex on oversized content.
        pre_truncated = (
            truncate_safely(display_content, TRUNCATE_LIMIT)
            if len(display_content) > TRUNCATE_LIMIT
            else display_content
        )
        optimized = optimize_for_card(pre_truncated)

        async def _flush() -> None:
            state.sequence += 1
            body = ContentCardElementRequestBody.builder() \
                .content(optimized) \
                .sequence(state.sequence) \
                .build()
            request = ContentCardElementRequest.builder() \
                .card_id(state.card_id) \
                .element_id(state.stream_element_id) \
                .request_body(body) \
                .build()

            res = await self._client.cardkit.v1.card_element.acontent(request)

            err = _check_card_kit_error(res, "Stream update")
            if err:
                print(f"[CARDKIT] {err}", file=sys.stderr)
                raise err

        await state.with_mutex(_flush)

    async def _close_streaming_mode(
        self, state: _CardState, summary_content: str | None = None
    ) -> None:
        """Close streaming mode on a card (step 1 of the two-step close)."""
        summary = summary_content or "\u2705 Claude \u00b7 Conversation complete"

        settings_data = json.dumps({
            "streaming_mode": False,
            "summary": {
                "content": summary,
                "i18n_content": {"zh_cn": summary, "en_us": summary},
            },
        })

        body = SettingsCardRequestBody.builder() \
            .settings(settings_data) \
            .sequence(state.sequence) \
            .build()
        request = SettingsCardRequest.builder() \
            .card_id(state.card_id) \
            .request_body(body) \
            .build()

        res = await self._client.cardkit.v1.card.asettings(request)

        err = _check_card_kit_error(res, "Close streaming")
        if err:
            print(f"[CARDKIT] {err}", file=sys.stderr)

    async def _update_card(
        self, state: _CardState, card_json: dict[str, Any]
    ) -> None:
        """Update the entire card content (step 2 of the two-step close)."""
        card_model = CardModel.builder() \
            .type("card_json") \
            .data(json.dumps(card_json)) \
            .build()
        body = UpdateCardRequestBody.builder() \
            .card(card_model) \
            .sequence(state.sequence) \
            .build()
        request = UpdateCardRequest.builder() \
            .card_id(state.card_id) \
            .request_body(body) \
            .build()

        res = await self._client.cardkit.v1.card.aupdate(request)

        err = _check_card_kit_error(res, "Card update")
        if err:
            print(f"[CARDKIT] {err}", file=sys.stderr)
            raise err

    @staticmethod
    def _build_final_card(
        state: _CardState,
        content: str,
        extra_elements: list[dict[str, Any]] | None = None,
        stats: Stats | None = None,
    ) -> dict[str, Any]:
        """Build the final card JSON with header, body elements, optional footer."""
        elements: list[dict[str, Any]] = [
            *(extra_elements or []),
            {
                "tag": "markdown",
                "content": content,
                "element_id": state.stream_element_id,
            },
        ]

        # Footer stats.
        if stats is not None:
            footer = build_footer_markdown(
                _FooterStatsAdapter(
                    input_tokens=stats.input_tokens,
                    output_tokens=stats.output_tokens,
                    tool_count=stats.tool_count,
                    duration=stats.duration,
                )
            )
        else:
            footer = None
        if footer:
            elements.append({"tag": "hr"})
            elements.append({"tag": "markdown", "content": footer})

        card_json: dict[str, Any] = {
            "schema": "2.0",
            "config": {
                "wide_screen_mode": True,
                "width_mode": "fill",
            },
            "body": {"elements": elements},
        }

        if state.card_title:
            tags: list[HeaderTag] = []
            if stats and stats.model:
                tags.append(HeaderTag(text=stats.model, color="blue"))
            if stats:
                total_tokens = (stats.input_tokens or 0) + (stats.output_tokens or 0)
                if total_tokens > 0:
                    tags.append(
                        HeaderTag(text=f"{total_tokens:,} tokens", color="turquoise")
                    )
                if stats.duration is not None:
                    tags.append(
                        HeaderTag(
                            text=format_duration(stats.duration), color="orange"
                        )
                    )

            card_json["header"] = build_header(
                HeaderOptions(
                    title=state.card_title,
                    subtitle="Done",
                    template="green",
                    icon_img_key=state.header_icon_img_key,
                    tags=tags,
                )
            )

        return card_json


# -- Internal helpers (module level) -------------------------------------------


@dataclass
class _FooterStatsAdapter:
    """Adapter matching the FooterStats interface from card.builder."""

    input_tokens: int | None = None
    output_tokens: int | None = None
    tool_count: int | None = None
    duration: float | None = None


def _build_thinking_elements(
    thinking: str | None = None,
    reasoning_elapsed_ms: float | None = None,
) -> list[dict[str, Any]]:
    """Build thinking collapsible-panel elements.

    Returns ``[]`` when no thinking content is provided.
    """
    if not thinking:
        return []
    return build_thinking_panel(
        _ThinkingPanelAdapter(
            thinking=thinking,
            reasoning_elapsed_ms=reasoning_elapsed_ms,
        )
    )


@dataclass
class _ThinkingPanelAdapter:
    """Internal adapter matching ThinkingPanelOptions interface."""

    thinking: str
    reasoning_elapsed_ms: float | None = None


# -- Module-level factory ------------------------------------------------------


def cardkit(client: lark.Client) -> CardKitOps:
    """Create a :class:`CardKitOps` instance bound to the given Lark client.

    Usage::

        ops = cardkit(client)
        entity = await ops.create(CreateOptions(card_title="My Card"))
        msg_id = await ops.send_ref(chat_id, root_msg_id, entity.card_id)
        await ops.write(entity.card_id, "Hello, world!")
        await ops.complete(entity.card_id, "Done!", CompleteOptions())
    """
    return CardKitOps(client=client)
