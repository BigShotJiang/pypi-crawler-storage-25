"""Mutual-exclusion lock for serializing async operations.

Prevents concurrent API calls from interleaving -- e.g. CardKit
sequence numbers must be strictly ordered, so every mutating call
(stream-update, settings, card-update) runs inside ``with_mutex``.

Ported from lark-kit-ts/src/cardkit/mutex.ts.
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from typing import TypeVar

T = TypeVar("T")


def create_mutex():
    """Create an async mutex guard.

    Usage::

        with_mutex = create_mutex()
        result = await with_mutex(lambda: do_something())

    Every call waits for the previous one to settle before executing.
    The returned coroutine resolves/rejects with the inner fn's result.

    Implementation uses :class:`asyncio.Lock` for simplicity.
    """
    lock = asyncio.Lock()

    async def with_mutex(fn: Callable[[], Awaitable[T]]) -> T:
        async with lock:
            return await fn()

    return with_mutex
