"""
format 模块 - Markdown -> 飞书文档块转换引擎

提供 Markdown 到飞书文档块的完整转换能力，包括：
- 常量定义（块类型、颜色枚举、语言映射）
- 内容清理（blob URL、外部图片）
- Thinking 标签解析
- 文档块构建器
- Markdown 解析器
- 文档转换入口
"""

from __future__ import annotations

# ── 常量 ───────────────────────────────────────────────────

from .constants import (
    BlockType,
    FontColor,
    FontBgColor,
    CalloutBgColor,
    CalloutBorderColor,
    CalloutColorMap,
    CalloutType,
    FontColorNameMap,
    FontBgColorNameMap,
    LanguageMap,
    EXTERNAL_IMAGE_EMOJI,
    AlignType,
)

# ── 内容清理 ───────────────────────────────────────────────────

from .sanitize import (
    SanitizeResult,
    sanitize_content,
    format_warnings,
)

# ── Thinking 解析 ───────────────────────────────────────────────────

from .thinking import (
    ThinkingResult,
    parse_thinking,
    strip_thinking,
)

# ── 构建器 ───────────────────────────────────────────────────

from .builder import (
    TextElementStyle,
    TextElement,
    EquationElement,
    Block,
    CalloutCreateData,
    CellData,
    TableCreateData,
    CellMerge,
    TableCell,
    TableData,
    DocumentBlockItem,
    DocumentBlockItemSimple,
    DocumentBlockItemTable,
    DocumentBlockItemCallout,
    parse_inline_text,
    build_text_block,
    build_heading_block,
    build_code_block,
    build_bullet_block,
    build_ordered_block,
    build_quote_block,
    build_todo_block,
    build_equation_block,
    build_callout_block,
    build_divider_block,
    build_image_block,
    build_table_block,
)

# ── 解析器 ───────────────────────────────────────────────────

from .parser import (
    TableParseResult,
    TodoParseResult,
    EquationParseResult,
    CalloutParseResult,
    CodeBlockStartResult,
    BulletListParseResult,
    OrderedListParseResult,
    parse_table,
    parse_todo,
    parse_block_equation,
    parse_inline_equation,
    parse_callout,
    parse_heading,
    is_code_block_start,
    is_code_block_end,
    is_quote,
    is_bullet_list,
    parse_bullet_list,
    is_ordered_list,
    parse_ordered_list,
    is_divider,
    count_tables,
)

# ── 文档转换 ───────────────────────────────────────────────────

from .document import (
    DocumentMeta,
    MarkdownToBlocksResult,
    markdown_to_blocks,
)

__all__ = [
    # constants
    "BlockType",
    "FontColor",
    "FontBgColor",
    "CalloutBgColor",
    "CalloutBorderColor",
    "CalloutColorMap",
    "CalloutType",
    "FontColorNameMap",
    "FontBgColorNameMap",
    "LanguageMap",
    "EXTERNAL_IMAGE_EMOJI",
    "AlignType",
    # sanitize
    "SanitizeResult",
    "sanitize_content",
    "format_warnings",
    # thinking
    "ThinkingResult",
    "parse_thinking",
    "strip_thinking",
    # builder types
    "TextElementStyle",
    "TextElement",
    "EquationElement",
    "Block",
    "CalloutCreateData",
    "CellData",
    "TableCreateData",
    "CellMerge",
    "TableCell",
    "TableData",
    "DocumentBlockItem",
    "DocumentBlockItemSimple",
    "DocumentBlockItemTable",
    "DocumentBlockItemCallout",
    # builder functions
    "parse_inline_text",
    "build_text_block",
    "build_heading_block",
    "build_code_block",
    "build_bullet_block",
    "build_ordered_block",
    "build_quote_block",
    "build_todo_block",
    "build_equation_block",
    "build_callout_block",
    "build_divider_block",
    "build_image_block",
    "build_table_block",
    # parser types
    "TableParseResult",
    "TodoParseResult",
    "EquationParseResult",
    "CalloutParseResult",
    "CodeBlockStartResult",
    "BulletListParseResult",
    "OrderedListParseResult",
    # parser functions
    "parse_table",
    "parse_todo",
    "parse_block_equation",
    "parse_inline_equation",
    "parse_callout",
    "parse_heading",
    "is_code_block_start",
    "is_code_block_end",
    "is_quote",
    "is_bullet_list",
    "parse_bullet_list",
    "is_ordered_list",
    "parse_ordered_list",
    "is_divider",
    "count_tables",
    # document
    "DocumentMeta",
    "MarkdownToBlocksResult",
    "markdown_to_blocks",
]
