from __future__ import annotations

"""
Thinking 标签解析模块

处理 Claude 扩展思考输出的 <thinking>...</thinking> 标签
支持流式场景中的不完整标签（未闭合的 thinking 块）
"""

import re
from dataclasses import dataclass


@dataclass
class ThinkingResult:
    """提取的思考结果。"""

    # 提取的思考内容
    thinking: str
    # 去除思考标签后的正文内容
    content: str
    # 是否存在未闭合的 thinking 块（流式输出中）
    is_thinking: bool


def parse_thinking(text: str) -> ThinkingResult:
    """
    解析文本中的 <thinking> 标签

    处理逻辑：
    1. 提取所有完整的 <thinking>...</thinking> 块
    2. 检测未闭合的 <thinking> 块（流式场景）
    3. 返回分离后的 thinking 和 content
    """
    thinking = ""
    content = text

    # 提取所有完整的 <thinking>...</thinking> 块
    def _extract_thinking(match: re.Match[str]) -> str:
        nonlocal thinking
        thinking += match.group(1)
        return ""

    content = re.sub(r"<thinking>([\s\S]*?)</thinking>", _extract_thinking, content)

    # 检测未闭合的 thinking 块
    is_thinking = False
    open_idx = content.find("<thinking>")
    if open_idx != -1:
        thinking += content[open_idx + len("<thinking>"):]
        content = content[:open_idx]
        is_thinking = True

    return ThinkingResult(
        thinking=thinking.strip(),
        content=content.strip(),
        is_thinking=is_thinking,
    )


def strip_thinking(text: str) -> str:
    """
    移除文本中的所有 thinking 标签

    用于 thinking_enabled=false 时，完全过滤思考内容
    """
    result = text
    # 移除完整的 <thinking>...</thinking> 块
    result = re.sub(r"<thinking>[\s\S]*?</thinking>", "", result)
    # 移除未闭合的 <thinking> 块
    result = re.sub(r"<thinking>[\s\S]*$", "", result)
    return result.strip()
