from __future__ import annotations

"""
飞书文档处理模块
将 Markdown 转换为飞书文档块
"""

import re
from dataclasses import dataclass, field
from typing import Any

from .builder import (
    Block,
    CalloutCreateData,
    TableCreateData,
    DocumentBlockItem,
    DocumentBlockItemSimple,
    DocumentBlockItemTable,
    DocumentBlockItemCallout,
    build_text_block,
    build_heading_block,
    build_code_block,
    build_bullet_block,
    build_ordered_block,
    build_quote_block,
    build_todo_block,
    build_equation_block,
    build_callout_block,
    build_divider_block,
    build_image_block,
    build_table_block,
)
from .parser import (
    parse_table,
    parse_todo,
    parse_block_equation,
    parse_callout,
    parse_heading,
    is_code_block_start,
    is_code_block_end,
    is_divider,
    is_bullet_list,
    is_ordered_list,
    parse_bullet_list,
    parse_ordered_list,
)
from .sanitize import sanitize_content


# ── 文档元数据 ───────────────────────────────────────────────────


@dataclass
class DocumentMeta:
    """文档元数据（可选，用于构建文档头部信息）。"""

    fields: dict[str, str] = field(default_factory=dict)


# ── 主转换函数 ───────────────────────────────────────────────────


@dataclass
class MarkdownToBlocksResult:
    items: list[DocumentBlockItem]
    warnings: list[str] = field(default_factory=list)


def markdown_to_blocks(markdown: str) -> MarkdownToBlocksResult:
    """
    将 Markdown 文本转换为飞书文档块

    返回 DocumentBlockItem[] 保持原始顺序，区分简单块和需要 Descendants API 的复杂块
    """
    items: list[DocumentBlockItem] = []

    # 1. 内容清理
    sanitize_result = sanitize_content(markdown)
    sanitized_markdown = sanitize_result.content
    warnings = sanitize_result.warnings
    if warnings:
        print(f"[WARN] Content sanitization: {', '.join(warnings)}")

    # 2. 按行处理
    lines = sanitized_markdown.split("\n")
    current_para: list[str] = []
    in_code_block = False
    code_content: list[str] = []
    code_lang = ""

    def flush_para() -> None:
        if current_para:
            content = "\n".join(current_para).strip()
            if content:
                items.append(DocumentBlockItemSimple(block=build_text_block(content)))
            current_para.clear()

    i = 0
    while i < len(lines):
        line = lines[i]

        # --- 代码块处理 ---
        if in_code_block:
            if is_code_block_end(line):
                items.append(DocumentBlockItemSimple(block=build_code_block("\n".join(code_content), code_lang)))
                in_code_block = False
                code_content = []
                code_lang = ""
            else:
                code_content.append(line)
            i += 1
            continue

        code_start = is_code_block_start(line)
        if code_start.is_start:
            flush_para()
            in_code_block = True
            code_lang = code_start.lang
            code_content = []
            i += 1
            continue

        # --- 块级公式 ---
        equation_result = parse_block_equation(lines, i)
        if equation_result:
            flush_para()
            items.append(DocumentBlockItemSimple(block=build_equation_block(equation_result.result.latex)))
            i = equation_result.end_index + 1
            continue

        # --- 高亮块（需要 Descendants API） ---
        callout_result = parse_callout(lines, i)
        if callout_result:
            flush_para()
            callout_type = callout_result.result.type
            callout_content = callout_result.result.content
            items.append(DocumentBlockItemCallout(
                data=build_callout_block(callout_type, "\n".join(callout_content)),
            ))
            i = callout_result.end_index + 1
            continue

        # --- 表格（需要 Descendants API） ---
        table_result = parse_table(lines, i)
        if table_result:
            flush_para()
            table_block = build_table_block(table_result.data)
            # 保留原始 Markdown，用于表格写入失败时的降级显示
            table_block.raw_markdown = "\n".join(lines[i: table_result.end_index + 1])
            items.append(DocumentBlockItemTable(data=table_block))
            i = table_result.end_index + 1
            continue

        # --- 任务列表 ---
        todo_result = parse_todo(line)
        if todo_result:
            flush_para()
            items.append(DocumentBlockItemSimple(block=build_todo_block(todo_result.content, todo_result.checked)))
            i += 1
            continue

        # --- 标题 ---
        heading_level = parse_heading(line)
        if heading_level > 0:
            flush_para()
            content = line[heading_level + 1:].strip()
            items.append(DocumentBlockItemSimple(block=build_heading_block(heading_level, content)))
            i += 1
            continue

        # --- 分割线 ---
        if is_divider(line):
            flush_para()
            items.append(DocumentBlockItemSimple(block=build_divider_block()))
            i += 1
            continue

        # --- 引用块 ---
        if line.strip().startswith("> "):
            flush_para()
            quote_content = line.strip()[2:]
            if not re.match(r"^\[!\w+\]", quote_content):
                items.append(DocumentBlockItemSimple(block=build_quote_block(quote_content)))
            i += 1
            continue

        # --- 无序列表（支持嵌套层级） ---
        if is_bullet_list(line):
            flush_para()
            parsed = parse_bullet_list(line)
            if parsed:
                items.append(DocumentBlockItemSimple(block=build_bullet_block(parsed.content, parsed.level)))
            i += 1
            continue

        # --- 有序列表（支持嵌套层级） ---
        if is_ordered_list(line):
            flush_para()
            parsed = parse_ordered_list(line)
            if parsed:
                items.append(DocumentBlockItemSimple(block=build_ordered_block(parsed.content, parsed.level)))
            i += 1
            continue

        # --- 图片（img_xxx 格式，已由 ImageResolver 处理） ---
        img_match = re.match(r"^!\[([^\]]*)\]\((img_[^)]+)\)$", line.strip(), re.IGNORECASE)
        if img_match:
            flush_para()
            items.append(DocumentBlockItemSimple(block=build_image_block(img_match.group(2))))
            i += 1
            continue

        # --- 空行（段落分隔符） ---
        if line.strip() == "":
            flush_para()
            i += 1
            continue

        # --- 普通段落 ---
        current_para.append(line)
        i += 1

    # 处理剩余段落
    flush_para()

    return MarkdownToBlocksResult(items=items, warnings=warnings)
