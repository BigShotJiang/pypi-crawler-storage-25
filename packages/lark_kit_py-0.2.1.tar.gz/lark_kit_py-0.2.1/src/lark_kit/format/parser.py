from __future__ import annotations

"""
Markdown 解析器
解析表格、任务列表、公式、高亮块等
"""

import re
from dataclasses import dataclass
from typing import Any

from .constants import CalloutType
from .builder import TableCell, CellMerge, TableData


# ── 表格解析 ───────────────────────────────────────────────────


def _parse_alignment(cell: str) -> str:
    """
    解析表格对齐方式
    :--- 左对齐, :---: 居中, ---: 右对齐
    """
    trimmed = cell.strip()
    left = trimmed.startswith(":")
    right = trimmed.endswith(":")
    if left and right:
        return "center"
    if right:
        return "right"
    return "left"


def _parse_cell_html(cell: str) -> TableCell:
    """
    解析单元格中的 HTML 标签
    支持 <td colspan="2"> 和 <td rowspan="2">
    """
    trimmed = cell.strip()

    # 匹配 <td colspan="2" rowspan="1">content</td> 或 <td>content</td>
    td_match = re.match(r"^<td\s+([^>]*)>([\s\S]*)<\/td>$", trimmed, re.IGNORECASE)
    if td_match:
        attrs = td_match.group(1)
        content = td_match.group(2).strip()

        result = TableCell(content=content)
        merge_colspan = 1
        merge_rowspan = 1
        has_merge = False

        # 解析 colspan
        colspan_match = re.search(r'colspan\s*=\s*["\']?(\d+)["\']?', attrs, re.IGNORECASE)
        if colspan_match:
            colspan = int(colspan_match.group(1))
            if colspan > 1:
                merge_colspan = colspan
                has_merge = True

        # 解析 rowspan
        rowspan_match = re.search(r'rowspan\s*=\s*["\']?(\d+)["\']?', attrs, re.IGNORECASE)
        if rowspan_match:
            rowspan = int(rowspan_match.group(1))
            if rowspan > 1:
                merge_rowspan = rowspan
                has_merge = True

        if has_merge:
            result.merge = CellMerge(colspan=merge_colspan, rowspan=merge_rowspan)

        return result

    # 普通 Markdown 单元格
    return TableCell(content=trimmed)


def _parse_table_row(line: str) -> list[TableCell] | None:
    """解析表格行。"""
    trimmed = line.strip()
    if not trimmed.startswith("|") or not trimmed.endswith("|"):
        return None

    cells = trimmed[1:-1].split("|")
    return [_parse_cell_html(cell) for cell in cells]


def _is_table_separator(line: str) -> bool:
    """检查是否为表格分隔行。"""
    trimmed = line.strip()
    if not trimmed.startswith("|") or not trimmed.endswith("|"):
        return False

    cells = [c.strip() for c in trimmed[1:-1].split("|")]
    return all(bool(re.match(r"^:?-+:?$", cell)) for cell in cells)


@dataclass
class TableParseResult:
    data: TableData
    end_index: int


def parse_table(lines: list[str], start_index: int) -> TableParseResult | None:
    """
    解析 Markdown 表格
    支持：
    - 标准 Markdown 表格
    - HTML colspan/rowspan: <td colspan="2">content</td>

    返回表格数据和结束行索引，如果不是表格返回 None
    """
    if start_index >= len(lines):
        return None

    # 第一行必须是表头
    header_row = _parse_table_row(lines[start_index])
    if not header_row or len(header_row) == 0:
        return None

    # 第二行必须是分隔符
    if start_index + 1 >= len(lines):
        return None
    if not _is_table_separator(lines[start_index + 1]):
        return None

    # 解析对齐方式
    separator_line = lines[start_index + 1].strip()
    separator_cells = [c.strip() for c in separator_line[1:-1].split("|")]
    alignments = [_parse_alignment(c) for c in separator_cells]

    # 对齐方式解析（飞书 table_cell create API 不支持 align，保留解析但不使用）
    _ = alignments

    rows: list[list[TableCell]] = [header_row]
    column_count = len(header_row)

    # 解析数据行
    end_index = start_index + 2
    while end_index < len(lines):
        row = _parse_table_row(lines[end_index])
        if row is None:
            break

        # 补齐列数
        while len(row) < column_count:
            row.append(TableCell(content=""))
        rows.append(row[:column_count])
        end_index += 1

    return TableParseResult(
        data=TableData(rows=rows),
        end_index=end_index - 1,
    )


# ── 任务列表解析 ───────────────────────────────────────────────────


@dataclass
class TodoParseResult:
    content: str
    checked: bool


def parse_todo(line: str) -> TodoParseResult | None:
    """
    解析任务列表
    - [ ] 未完成
    - [x] 已完成
    """
    match = re.match(r"^\s*[-*]\s+\[([ xX])\]\s+(.+)$", line)
    if not match:
        return None

    return TodoParseResult(
        checked=match.group(1).lower() == "x",
        content=match.group(2).strip(),
    )


# ── 数学公式解析 ───────────────────────────────────────────────────


@dataclass
class EquationParseResult:
    latex: str
    inline: bool


@dataclass
class _BlockEquationResult:
    result: EquationParseResult
    end_index: int


def parse_block_equation(lines: list[str], start_index: int) -> _BlockEquationResult | None:
    """解析块级公式 $$...$$ 。"""
    line = lines[start_index].strip()

    # 单行公式：$$E = mc^2$$
    single_line_match = re.match(r"^\$\$([^$]+)\$\$$", line)
    if single_line_match:
        return _BlockEquationResult(
            result=EquationParseResult(latex=single_line_match.group(1).strip(), inline=False),
            end_index=start_index,
        )

    # 多行公式：$$ 开头
    if line != "$$":
        return None

    latex_lines: list[str] = []
    end_index = start_index + 1

    while end_index < len(lines):
        if lines[end_index].strip() == "$$":
            return _BlockEquationResult(
                result=EquationParseResult(latex="\n".join(latex_lines), inline=False),
                end_index=end_index,
            )
        latex_lines.append(lines[end_index])
        end_index += 1

    return None


@dataclass
class _InlineEquationResult:
    latex: str
    remaining: str


def parse_inline_equation(text: str) -> _InlineEquationResult | None:
    """解析行内公式 $...$。"""
    match = re.match(r"^\$([^$]+)\$", text)
    if not match:
        return None

    return _InlineEquationResult(
        latex=match.group(1).strip(),
        remaining=text[match.end():],
    )


# ── 高亮块解析 ───────────────────────────────────────────────────


@dataclass
class CalloutParseResult:
    type: CalloutType
    content: list[str]


@dataclass
class _CalloutParseOutput:
    result: CalloutParseResult
    end_index: int


def parse_callout(lines: list[str], start_index: int) -> _CalloutParseOutput | None:
    """
    解析高亮块
    > [!NOTE]
    > 这是一个提示

    > [!WARNING]
    > 这是一个警告
    """
    line = lines[start_index].strip()

    # 匹配 > [!TYPE]
    header_match = re.match(r"^>\s*\[!(\w+)\]\s*$", line)
    if not header_match:
        return None

    callout_type = header_match.group(1).upper()
    content: list[str] = []
    end_index = start_index + 1

    # 收集后续的引用行
    while end_index < len(lines):
        next_line = lines[end_index].strip()
        if next_line.startswith("> "):
            content.append(next_line[2:])
            end_index += 1
        elif next_line == ">":
            end_index += 1
        else:
            break

    return _CalloutParseOutput(
        result=CalloutParseResult(type=callout_type, content=content),
        end_index=end_index - 1,
    )


# ── 辅助函数 ───────────────────────────────────────────────────


def parse_heading(line: str) -> int:
    """
    检测标题级别
    返回标题级别 (1-6)，0 表示不是标题
    """
    match = re.match(r"^(#{1,6})\s", line)
    return len(match.group(1)) if match else 0


@dataclass
class CodeBlockStartResult:
    is_start: bool
    lang: str


def is_code_block_start(line: str) -> CodeBlockStartResult:
    """检测是否为代码块开始。"""
    match = re.match(r"^```(\w*)", line)
    if match:
        return CodeBlockStartResult(is_start=True, lang=match.group(1) or "")
    return CodeBlockStartResult(is_start=False, lang="")


def is_code_block_end(line: str) -> bool:
    """检测是否为代码块结束。"""
    return line.strip() == "```"


def is_quote(line: str) -> bool:
    """检测是否为引用块。"""
    return line.strip().startswith("> ")


def is_bullet_list(line: str) -> bool:
    """检测是否为无序列表。"""
    return bool(re.match(r"^(\s*)[-*]\s+", line)) and not parse_todo(line)


@dataclass
class BulletListParseResult:
    content: str
    level: int


def parse_bullet_list(line: str) -> BulletListParseResult | None:
    """
    解析无序列表（含缩进层级）
    返回内容文本和层级（0-based，最多 2 级）
    """
    match = re.match(r"^(\s*)[-*]\s+(.+)$", line)
    if not match or parse_todo(line):
        return None
    indent = len(match.group(1))
    level = min(indent // 2, 2)  # 每 2 空格一级，最多 2 级
    return BulletListParseResult(content=match.group(2).strip(), level=level)


def is_ordered_list(line: str) -> bool:
    """检测是否为有序列表。"""
    return bool(re.match(r"^(\s*)(\d+)\.\s+", line))


@dataclass
class OrderedListParseResult:
    content: str
    level: int


def parse_ordered_list(line: str) -> OrderedListParseResult | None:
    """
    解析有序列表（含缩进层级）
    返回内容文本和层级（0-based，最多 2 级）
    """
    match = re.match(r"^(\s*)(\d+)\.\s+(.+)$", line)
    if not match:
        return None
    indent = len(match.group(1))
    level = min(indent // 2, 2)  # 每 2 空格一级，最多 2 级
    return OrderedListParseResult(content=match.group(3).strip(), level=level)


def is_divider(line: str) -> bool:
    """检测是否为分割线。"""
    trimmed = line.strip()
    return trimmed == "---" or trimmed == "***" or trimmed == "___"


# ── 表格计数 ───────────────────────────────────────────────────


def count_tables(markdown: str) -> int:
    """
    统计 Markdown 中的表格数量（排除代码块内的伪表格）
    """
    # 1. 移除代码块，避免代码块内的 | 被误判
    code_block_re = re.compile(r"```[\s\S]*?```")
    inline_code_re = re.compile(r"`[^`]+`")
    clean_md = inline_code_re.sub("", code_block_re.sub("", markdown))

    # 2. 复用 parse_table 逻辑统计表格数量
    lines = clean_md.split("\n")
    count = 0
    i = 0

    while i < len(lines):
        result = parse_table(lines, i)
        if result:
            count += 1
            i = result.end_index + 1
        else:
            i += 1

    return count
