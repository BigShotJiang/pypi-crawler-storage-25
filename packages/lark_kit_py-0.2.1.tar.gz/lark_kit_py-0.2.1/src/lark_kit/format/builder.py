from __future__ import annotations

"""
飞书文档块构建器

所有数据结构严格对齐 @larksuiteoapi/node-sdk 类型定义
"""

import re
from dataclasses import dataclass, field
from typing import Any, Union

from .constants import (
    BlockType,
    CalloutColorMap,
    CalloutType,
    FontBgColor,
    FontBgColorNameMap,
    FontColor,
    FontColorNameMap,
    LanguageMap,
)


# ── 类型定义 ───────────────────────────────────────────────────


@dataclass
class TextElementStyle:
    """text_element_style（对齐 SDK）样式属性嵌套在 text_run 内部。"""

    bold: bool | None = None
    italic: bool | None = None
    underline: bool | None = None
    strikethrough: bool | None = None
    inline_code: bool | None = None
    text_color: int | None = None
    background_color: int | None = None
    link: dict[str, str] | None = None  # {"url": "..."}

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {}
        if self.bold is not None:
            d["bold"] = self.bold
        if self.italic is not None:
            d["italic"] = self.italic
        if self.underline is not None:
            d["underline"] = self.underline
        if self.strikethrough is not None:
            d["strikethrough"] = self.strikethrough
        if self.inline_code is not None:
            d["inline_code"] = self.inline_code
        if self.text_color is not None:
            d["text_color"] = self.text_color
        if self.background_color is not None:
            d["background_color"] = self.background_color
        if self.link is not None:
            d["link"] = self.link
        return d


@dataclass
class TextElement:
    """TextElement（对齐 SDK）只有一个可选的 text_run 属性。"""

    content: str = ""
    style: TextElementStyle | None = None

    def to_dict(self) -> dict[str, Any]:
        run: dict[str, Any] = {"content": self.content}
        if self.style is not None:
            d = self.style.to_dict()
            if d:
                run["text_element_style"] = d
        return {"text_run": run}


@dataclass
class EquationElement:
    """公式元素。"""

    latex: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {"equation": {"content": self.latex}}


@dataclass
class Block:
    """普通文档块（用于 children API 直接写入）。"""

    block_type: int
    # 各类块属性（按类型使用）
    text: dict[str, Any] | None = None
    heading1: dict[str, Any] | None = None
    heading2: dict[str, Any] | None = None
    heading3: dict[str, Any] | None = None
    heading4: dict[str, Any] | None = None
    heading5: dict[str, Any] | None = None
    heading6: dict[str, Any] | None = None
    heading7: dict[str, Any] | None = None
    heading8: dict[str, Any] | None = None
    heading9: dict[str, Any] | None = None
    bullet: dict[str, Any] | None = None
    ordered: dict[str, Any] | None = None
    code: dict[str, Any] | None = None
    quote: dict[str, Any] | None = None
    todo: dict[str, Any] | None = None
    equation: dict[str, Any] | None = None
    divider: dict[str, Any] | None = None
    image: dict[str, Any] | None = None
    callout: dict[str, Any] | None = None
    table: dict[str, Any] | None = None
    table_cell: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"block_type": self.block_type}
        for attr in (
            "text", "heading1", "heading2", "heading3", "heading4",
            "heading5", "heading6", "heading7", "heading8", "heading9",
            "bullet", "ordered", "code", "quote", "todo", "equation",
            "divider", "image", "callout", "table", "table_cell",
        ):
            val = getattr(self, attr)
            if val is not None:
                d[attr] = val
        return d


# ── 复杂块类型（用于多步 children API 创建） ────────────────────────


@dataclass
class CalloutCreateData:
    """高亮块创建数据，只携带结构化数据，block_id 由服务端分配。"""

    callout: dict[str, int]  # {background_color, border_color}
    text_lines: list[str]
    raw_markdown: str | None = None


@dataclass
class CellData:
    """单元格数据。"""

    content: str
    merge: dict[str, int] | None = None  # {row_span, col_span}


@dataclass
class TableCreateData:
    """表格创建数据，只携带结构化数据，block_id 由服务端分配。"""

    property: dict[str, Any]  # {row_size, column_size, column_width, merge_info?}
    cells: list[CellData]
    raw_markdown: str | None = None


@dataclass
class CellMerge:
    """单元格合并信息。"""

    colspan: int
    rowspan: int


@dataclass
class TableCell:
    """表格单元格。"""

    content: str
    merge: CellMerge | None = None


@dataclass
class TableData:
    """表格数据。"""

    rows: list[list[TableCell]]


@dataclass
class DocumentBlockItemSimple:
    """简单文档块条目。"""

    type: str = "simple"  # always "simple"
    block: Block = field(default_factory=lambda: Block(block_type=0))


@dataclass
class DocumentBlockItemTable:
    """表格文档块条目。"""

    type: str = "table"  # always "table"
    data: TableCreateData = field(default_factory=lambda: TableCreateData(property={}, cells=[]))


@dataclass
class DocumentBlockItemCallout:
    """高亮块文档块条目。"""

    type: str = "callout"  # always "callout"
    data: CalloutCreateData = field(default_factory=lambda: CalloutCreateData(callout={}, text_lines=[]))


DocumentBlockItem = Union[DocumentBlockItemSimple, DocumentBlockItemTable, DocumentBlockItemCallout]


# ── 颜色映射 ───────────────────────────────────────────────────


def _rgb_to_hue(r: float, g: float, b: float) -> float:
    """RGB 转 HSL 色相值（0-360）。"""
    mx = max(r, g, b)
    mn = min(r, g, b)

    if mx == mn:
        return 0  # 灰色，无色相

    d = mx - mn
    if mx == r:
        h = ((g - b) / d + (6 if g < b else 0)) / 6
    elif mx == g:
        h = ((b - r) / d + 2) / 6
    else:
        h = ((r - g) / d + 4) / 6
    return h * 360


def _hex_to_font_color(hex_str: str) -> int:
    """将 Hex 颜色值近似匹配到飞书 FontColor 枚举。通过 HSL 色相区间分配到最近的 7 种颜色。"""
    try:
        h = hex_str.lstrip("#")
        # 扩展 3 位 hex 到 6 位
        if len(h) == 3:
            h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2]
        if len(h) != 6:
            return FontColor["GRAY"]

        r = int(h[0:2], 16) / 255
        g = int(h[2:4], 16) / 255
        b = int(h[4:6], 16) / 255
        hue = _rgb_to_hue(r, g, b)

        # 检查是否接近灰色（低饱和度）
        mx = max(r, g, b)
        mn = min(r, g, b)
        lightness = (mx + mn) / 2
        denominator = 1 - abs(2 * lightness - 1)
        saturation = (mx - mn) / denominator if denominator != 0 else 0
        if saturation < 0.15:
            return FontColor["GRAY"]

        # 按色相区间分配
        if hue < 15 or hue >= 345:
            return FontColor["PINK"]    # Pink/Red
        if hue < 45:
            return FontColor["ORANGE"]  # Orange
        if hue < 75:
            return FontColor["YELLOW"]  # Yellow
        if hue < 165:
            return FontColor["GREEN"]   # Green
        if hue < 255:
            return FontColor["BLUE"]    # Blue
        if hue < 285:
            return FontColor["PURPLE"]  # Purple
        return FontColor["GRAY"]
    except Exception:
        return FontColor["GRAY"]


def _hex_to_font_bg_color(hex_str: str) -> int:
    """将 Hex 颜色值近似匹配到飞书 FontBgColor 枚举。通过明度区分 light (1-7) 和 dark (8-14) 变体。"""
    try:
        h = hex_str.lstrip("#")
        if len(h) == 3:
            h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2]
        if len(h) != 6:
            return FontBgColor["LIGHT_GRAY"]

        r = int(h[0:2], 16) / 255
        g = int(h[2:4], 16) / 255
        b = int(h[4:6], 16) / 255

        hue = _rgb_to_hue(r, g, b)
        lightness = (max(r, g, b) + min(r, g, b)) / 2
        is_dark = lightness < 0.5

        # 按色相 + 明度分配
        if hue < 15 or hue >= 345:
            return FontBgColor["DARK_PINK"] if is_dark else FontBgColor["LIGHT_PINK"]
        if hue < 45:
            return FontBgColor["DARK_ORANGE"] if is_dark else FontBgColor["LIGHT_ORANGE"]
        if hue < 75:
            return FontBgColor["DARK_YELLOW"] if is_dark else FontBgColor["LIGHT_YELLOW"]
        if hue < 165:
            return FontBgColor["DARK_GREEN"] if is_dark else FontBgColor["LIGHT_GREEN"]
        if hue < 255:
            return FontBgColor["DARK_BLUE"] if is_dark else FontBgColor["LIGHT_BLUE"]
        if hue < 285:
            return FontBgColor["DARK_PURPLE"] if is_dark else FontBgColor["LIGHT_PURPLE"]
        return FontBgColor["DARK_GRAY"] if is_dark else FontBgColor["LIGHT_GRAY"]
    except Exception:
        return FontBgColor["LIGHT_GRAY"]


def _parse_css_to_font_color(value: str) -> int | None:
    """解析 CSS 颜色值为飞书 FontColor 数字枚举。支持颜色名（red）和 Hex（#FF0000）。"""
    trimmed = value.strip().lower()
    if trimmed.startswith("#"):
        return _hex_to_font_color(trimmed)
    return FontColorNameMap.get(trimmed)


def _parse_css_to_font_bg_color(value: str) -> int | None:
    """解析 CSS 颜色值为飞书 FontBgColor 数字枚举。支持颜色名（lightgreen）和 Hex（#90EE90）。"""
    trimmed = value.strip().lower()
    if trimmed.startswith("#"):
        return _hex_to_font_bg_color(trimmed)
    return FontBgColorNameMap.get(trimmed)


def _parse_style_colors(style: str) -> dict[str, int]:
    """
    解析 style 属性中的颜色
    支持：color:red, background-color:yellow, color:#FF0000
    返回飞书数字枚举值
    """
    result: dict[str, int] = {}

    color_match = re.search(r"color\s*:\s*([^;]+)", style, re.IGNORECASE)
    bg_color_match = re.search(r"background-color\s*:\s*([^;]+)", style, re.IGNORECASE)

    if color_match:
        color = _parse_css_to_font_color(color_match.group(1))
        if color is not None:
            result["textColor"] = color
        else:
            print(f'[format] 无法映射颜色值: "{color_match.group(1)}"')

    if bg_color_match:
        color = _parse_css_to_font_bg_color(bg_color_match.group(1))
        if color is not None:
            result["bgColor"] = color
        else:
            print(f'[format] 无法映射背景色值: "{bg_color_match.group(1)}"')

    return result


# ── 内联格式解析 ───────────────────────────────────────────────────


def _unescape(s: str) -> str:
    return re.sub(r"\\([<>*_~`\[\]])", r"\1", s)


# Pattern definitions for inline text parsing
_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    (re.compile(r"\\([<>*_~`\[\]])"), "escape"),
    (re.compile(r"<u>([^<]*)</u>", re.IGNORECASE), "underline"),
    (re.compile(r"""<span\s+style\s*=\s*["']([^"']+)["']\s*>([^<]*)</span>""", re.IGNORECASE), "span"),
    (re.compile(r"\*\*([^*]+)\*\*"), "bold"),
    (re.compile(r"(?:\*([^*]+)\*|_([^_]+)_)"), "italic"),
    (re.compile(r"`([^`]+)`"), "code"),
    (re.compile(r"~~([^~]+)~~"), "strikethrough"),
    (re.compile(r"\[([^\]]+)\]\(([^)]+)\)"), "link"),
]


def parse_inline_text(text: str) -> list[TextElement]:
    """
    解析内联 Markdown 和 HTML 格式

    输出严格对齐飞书 SDK 的 TextElement 结构：
    - 所有样式属性放在 text_run.text_element_style 内
    - 链接通过 text_element_style.link 实现
    - 行内代码通过 text_element_style.inline_code 布尔值实现
    - 颜色为数字枚举值
    """
    elements: list[TextElement] = []
    remaining = text

    while remaining:
        earliest_match: dict[str, Any] | None = None

        for regex, pat_type in _PATTERNS:
            match = regex.search(remaining)
            if match and (earliest_match is None or match.start() < earliest_match["index"]):
                element: TextElement
                if pat_type == "escape":
                    element = TextElement(content=match.group(1))
                elif pat_type == "underline":
                    element = TextElement(
                        content=_unescape(match.group(1)),
                        style=TextElementStyle(underline=True),
                    )
                elif pat_type == "span":
                    colors = _parse_style_colors(match.group(1))
                    style = TextElementStyle()
                    if "textColor" in colors:
                        style.text_color = colors["textColor"]
                    if "bgColor" in colors:
                        style.background_color = colors["bgColor"]
                    has_style = style.text_color is not None or style.background_color is not None
                    element = TextElement(
                        content=_unescape(match.group(2)),
                        style=style if has_style else None,
                    )
                elif pat_type == "bold":
                    element = TextElement(
                        content=_unescape(match.group(1)),
                        style=TextElementStyle(bold=True),
                    )
                elif pat_type == "italic":
                    element = TextElement(
                        content=_unescape(match.group(1) or match.group(2)),
                        style=TextElementStyle(italic=True),
                    )
                elif pat_type == "code":
                    element = TextElement(
                        content=_unescape(match.group(1)),
                        style=TextElementStyle(inline_code=True),
                    )
                elif pat_type == "strikethrough":
                    element = TextElement(
                        content=_unescape(match.group(1)),
                        style=TextElementStyle(strikethrough=True),
                    )
                elif pat_type == "link":
                    element = TextElement(
                        content=_unescape(match.group(1)),
                        style=TextElementStyle(link={"url": match.group(2)}),
                    )
                else:
                    continue

                earliest_match = {
                    "index": match.start(),
                    "length": len(match.group(0)),
                    "element": element,
                }

        if earliest_match is not None and earliest_match["index"] == 0:
            elements.append(earliest_match["element"])
            remaining = remaining[earliest_match["length"]:]
        elif earliest_match is not None:
            plain_text = remaining[: earliest_match["index"]]
            if plain_text:
                elements.append(TextElement(content=_unescape(plain_text)))
            elements.append(earliest_match["element"])
            remaining = remaining[earliest_match["index"] + earliest_match["length"]:]
        else:
            if remaining:
                elements.append(TextElement(content=_unescape(remaining)))
            break

    # 过滤掉 content 为空的 text_run（避免 API 校验失败）
    return [e for e in elements if e.content != ""]


# ── 块构建函数 ───────────────────────────────────────────────────


def _elements_to_dicts(elements: list[TextElement]) -> list[dict[str, Any]]:
    """将 TextElement 列表转为 SDK 所需的 dict 列表。"""
    return [e.to_dict() for e in elements]


def build_text_block(content: str) -> Block:
    return Block(
        block_type=BlockType["TEXT"],
        text={"elements": _elements_to_dicts(parse_inline_text(content))},
    )


def build_heading_block(level: int, content: str) -> Block:
    block_types = [
        BlockType["HEADING1"], BlockType["HEADING2"], BlockType["HEADING3"],
        BlockType["HEADING4"], BlockType["HEADING5"], BlockType["HEADING6"],
        BlockType["HEADING7"], BlockType["HEADING8"], BlockType["HEADING9"],
    ]
    properties = [
        "heading1", "heading2", "heading3", "heading4",
        "heading5", "heading6", "heading7", "heading8", "heading9",
    ]

    index = min(level - 1, 8)
    elements = _elements_to_dicts(parse_inline_text(content))
    block = Block(block_type=block_types[index])
    setattr(block, properties[index], {"elements": elements})
    return block


def build_code_block(code: str, lang: str = "") -> Block:
    lang_id = LanguageMap.get(lang.lower(), 1)
    return Block(
        block_type=BlockType["CODE"],
        code={
            "style": {"language": lang_id, "wrap": True},
            "elements": [TextElement(content=code).to_dict()],
        },
    )


def build_bullet_block(content: str, level: int = 0) -> Block:
    bullet_data: dict[str, Any] = {"elements": _elements_to_dicts(parse_inline_text(content))}
    if level > 0:
        bullet_data["level"] = level
    return Block(
        block_type=BlockType["BULLET"],
        bullet=bullet_data,
    )


def build_ordered_block(content: str, level: int = 0) -> Block:
    ordered_data: dict[str, Any] = {"elements": _elements_to_dicts(parse_inline_text(content))}
    if level > 0:
        ordered_data["level"] = level
    return Block(
        block_type=BlockType["ORDERED"],
        ordered=ordered_data,
    )


def build_quote_block(content: str) -> Block:
    return Block(
        block_type=BlockType["QUOTE"],
        quote={"elements": _elements_to_dicts(parse_inline_text(content))},
    )


def build_todo_block(content: str, checked: bool) -> Block:
    return Block(
        block_type=BlockType["TODO"],
        todo={
            "style": {"done": checked},
            "elements": _elements_to_dicts(parse_inline_text(content)),
        },
    )


def build_equation_block(latex: str) -> Block:
    return Block(
        block_type=BlockType["EQUATION"],
        equation={
            "elements": [{"equation": {"content": latex}}],
        },
    )


def build_callout_block(callout_type: CalloutType, content: str) -> CalloutCreateData:
    """构建高亮块数据（用于多步 children API 创建）。"""
    colors = CalloutColorMap[callout_type]
    text_lines = content.split("\n")
    return CalloutCreateData(
        callout={"background_color": colors["bg"], "border_color": colors["border"]},
        text_lines=text_lines,
    )


def build_divider_block() -> Block:
    return Block(
        block_type=BlockType["DIVIDER"],
        divider={},
    )


def build_image_block(image_key: str) -> Block:
    return Block(
        block_type=BlockType["IMAGE"],
        image={"token": image_key},
    )


# ── 表格构建 ───────────────────────────────────────────────────


def _calculate_text_width(text: str) -> int:
    """计算字符串显示宽度（中文算 2，英文算 1）。"""
    width = 0
    for char in text:
        if re.match(r"[\u4e00-\u9fff\u3000-\u303f\uff00-\uffef]", char):
            width += 2
        else:
            width += 1
    return width


def build_table_block(data: TableData) -> TableCreateData:
    """构建表格创建数据（用于多步 children API 创建）。"""
    rows = data.rows

    if not rows or not rows[0]:
        return TableCreateData(
            property={"row_size": 0, "column_size": 0, "column_width": []},
            cells=[],
        )

    row_size = len(rows)
    column_size = len(rows[0])
    merge_info: list[dict[str, int]] = []

    # 追踪被合并的单元格位置
    merged_cells: set[str] = set()

    # 收集所有单元格数据（按行优先顺序）
    cells: list[CellData] = []

    for row_index in range(len(rows)):
        for col_index in range(len(rows[row_index])):
            cell = rows[row_index][col_index]
            key = f"{row_index}-{col_index}"

            # 被合并的单元格作为占位
            if key in merged_cells:
                cells.append(CellData(content=""))
                continue

            # 处理合并
            if cell.merge and (cell.merge.colspan > 1 or cell.merge.rowspan > 1):
                merge_info.append({
                    "row_span": cell.merge.rowspan or 1,
                    "col_span": cell.merge.colspan or 1,
                })

                # 标记被合并的单元格
                row_span = cell.merge.rowspan or 1
                col_span = cell.merge.colspan or 1
                for r in range(row_index, min(row_index + row_span, len(rows))):
                    for c in range(col_index, min(col_index + col_span, len(rows[r]))):
                        if r != row_index or c != col_index:
                            merged_cells.add(f"{r}-{c}")

            cell_merge = None
            if cell.merge and (cell.merge.colspan > 1 or cell.merge.rowspan > 1):
                cell_merge = {"row_span": cell.merge.rowspan or 1, "col_span": cell.merge.colspan or 1}

            cells.append(CellData(content=cell.content.strip(), merge=cell_merge))

    # 计算每列最大宽度（基于总可用宽度 720px 按比例分配）
    TOTAL_WIDTH = 720
    MIN_COL_WIDTH = 60
    column_widths: list[int] = []
    column_text_widths: list[int] = []

    for col_index in range(column_size):
        max_text_width = 0
        for row_index in range(len(rows)):
            if col_index < len(rows[row_index]):
                cell = rows[row_index][col_index]
                width = _calculate_text_width(cell.content)
                colspan = cell.merge.colspan if cell.merge else 1
                if colspan == 1:
                    max_text_width = max(max_text_width, width)
        column_text_widths.append(max(max_text_width, 3))  # 最少 3 个字符宽度

    # 按比例分配总宽度
    total_text_width = sum(column_text_widths)
    if total_text_width == 0:
        # 所有列为空时均分宽度
        equal_width = max(TOTAL_WIDTH // len(column_text_widths), MIN_COL_WIDTH)
        column_widths = [equal_width] * len(column_text_widths)
    else:
        for text_width in column_text_widths:
            proportional = round((text_width / total_text_width) * TOTAL_WIDTH)
            column_widths.append(max(proportional, MIN_COL_WIDTH))

    # 如果总宽度超出 TOTAL_WIDTH（由 MIN_COL_WIDTH 导致），按比例缩减
    total_allocated = sum(column_widths)
    if total_allocated > TOTAL_WIDTH:
        column_widths = [
            max(round(w * TOTAL_WIDTH / total_allocated), MIN_COL_WIDTH)
            for w in column_widths
        ]

    property_data: dict[str, Any] = {
        "row_size": row_size,
        "column_size": column_size,
        "column_width": column_widths,
    }
    if merge_info:
        property_data["merge_info"] = merge_info

    return TableCreateData(
        property=property_data,
        cells=cells,
    )
