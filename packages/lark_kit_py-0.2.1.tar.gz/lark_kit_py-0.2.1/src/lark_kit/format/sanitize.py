from __future__ import annotations

"""
内容清理模块
处理 blob url、外部图片等无效内容
使用代码块保护机制，避免误伤代码块内的内容
"""

import re
from dataclasses import dataclass, field

from .constants import EXTERNAL_IMAGE_EMOJI

# ── 代码块保护 ───────────────────────────────────────────────────

CODE_PLACEHOLDER_PREFIX = "\x00CODE_"
CODE_PLACEHOLDER_SUFFIX = "\x00"


@dataclass
class _ExtractedCode:
    placeholder: str
    content: str


def _extract_code_blocks(text: str) -> tuple[str, list[_ExtractedCode]]:
    """提取代码块，替换为占位符。返回替换后的文本和提取的代码块列表。"""
    codes: list[_ExtractedCode] = []
    result = text
    index = 0

    def _replace_code(match: re.Match[str]) -> str:
        nonlocal index
        placeholder = f"{CODE_PLACEHOLDER_PREFIX}{index}{CODE_PLACEHOLDER_SUFFIX}"
        codes.append(_ExtractedCode(placeholder=placeholder, content=match.group(0)))
        index += 1
        return placeholder

    # 匹配 ```lang\n...\n``` 代码块（包括单行）
    result = re.sub(r"(```[^\n]*\n)([\s\S]*?)(```)", _replace_code, result)

    return result, codes


def _restore_code_blocks(text: str, codes: list[_ExtractedCode]) -> str:
    """恢复代码块占位符为原始内容。"""
    result = text
    for code in codes:
        result = result.replace(code.placeholder, code.content)
    return result


# ── 公共接口 ───────────────────────────────────────────────────


@dataclass
class SanitizeResult:
    content: str
    warnings: list[str] = field(default_factory=list)


def sanitize_content(content: str) -> SanitizeResult:
    """
    清理内容中的无效 URL
    1. blob: URL - 完全移除
    2. 外部图片 URL - 转为链接 + emoji

    代码块内的内容受保护，不会被误处理
    """
    warnings: list[str] = []

    # 0. 提取代码块，保护内部内容不被误处理
    text, codes = _extract_code_blocks(content)
    processed = text

    # 1. 处理 blob URL
    blob_matches = re.findall(r"!\[[^\]]*\]\(blob:[^)]+\)", processed, re.IGNORECASE)
    if blob_matches:
        print(f"[WARN] Filtered {len(blob_matches)} blob URL image(s)")

        # 移除 Markdown 图片 ![...](blob:...)
        processed = re.sub(r"!\[[^\]]*\]\(blob:[^)]+\)", "", processed, flags=re.IGNORECASE)

        # 保留文字，移除 blob 链接 [...](blob:...)
        processed = re.sub(r"\[([^\]]+)\]\(blob:[^)]+\)", r"\1", processed, flags=re.IGNORECASE)

        # 移除独立的 blob URL
        processed = re.sub(r"blob:https?:\/\/[^\s\)]+", "", processed, flags=re.IGNORECASE)

        warnings.append(f"已过滤 {len(blob_matches)} 个无效图片")

    # 2. 处理外部图片（非 blob: 的 https?:// 图片）
    # 飞书卡片/文档不支持外部图片 URL，转为普通链接
    external_img_matches = re.findall(r"!\[([^\]]*)\]\((https?:\/\/[^)]+)\)", processed, re.IGNORECASE)
    if external_img_matches:
        print(f"[WARN] Converting {len(external_img_matches)} external image URL(s) to links")

        # 转换：![alt](https://...) -> [alt](https://...) 🖼️
        def _replace_external_img(match: re.Match[str]) -> str:
            alt = match.group(1)
            url = match.group(2)
            display_text = alt or "图片"
            return f"[{display_text}]({url}) {EXTERNAL_IMAGE_EMOJI}"

        processed = re.sub(
            r"!\[([^\]]*)\]\((https?:\/\/[^)]+)\)",
            _replace_external_img,
            processed,
            flags=re.IGNORECASE,
        )

        warnings.append(f"已转换 {len(external_img_matches)} 个外部图片为链接")

    # 3. 恢复代码块
    processed = _restore_code_blocks(processed, codes)

    return SanitizeResult(content=processed, warnings=warnings)


def format_warnings(warnings: list[str]) -> str:
    """格式化警告消息。"""
    if not warnings:
        return ""
    return "\n\n（" + "，".join(warnings) + "）"
