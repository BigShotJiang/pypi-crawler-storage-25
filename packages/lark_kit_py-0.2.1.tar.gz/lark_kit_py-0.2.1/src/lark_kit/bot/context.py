"""BotContext -- per-event context object for bot handlers.

Wraps common operations so event handlers do not need to interact
with the raw SDK API directly.

Usage::

    bot.on("im.message.receive_v1", async def handle(ctx, data):
        await ctx.reply("Got it!")
    )
"""

from __future__ import annotations

from typing import Any, Awaitable, Callable

from ..im import MessageOps


class BotContext:
    """Per-event context with convenience methods for message handling."""

    __slots__ = (
        "_client",
        "_get_token",
        "_im_ops",
        "message_id",
        "chat_id",
        "chat_type",
        "content",
        "message_type",
        "sender_open_id",
        "parent_id",
        "_root_msg_id",
    )

    def __init__(
        self,
        client: Any,
        get_token: Callable[[], Awaitable[str]],
        im_ops: MessageOps,
        event_data: dict,
    ) -> None:
        self._client = client
        self._get_token = get_token
        self._im_ops = im_ops

        # Parse event data
        message = event_data.get("message", {})
        sender = event_data.get("sender", {})
        sender_id = sender.get("sender_id", {})

        self.message_id: str = message.get("message_id", "")
        self.chat_id: str = message.get("chat_id", "")
        self.chat_type: str = message.get("chat_type", "")
        self.content: str = message.get("content", "")
        self.message_type: str = message.get("message_type", "")
        self.sender_open_id: str = sender_id.get("open_id", "")
        self.parent_id: str | None = message.get("parent_id")
        self._root_msg_id: str = message.get("message_id", "")

    # ── Token access ─────────────────────────────────────────────

    async def get_token(self) -> str:
        """Return a valid tenant access token."""
        return await self._get_token()

    # ── Quick replies ────────────────────────────────────────────

    async def reply(self, text: str) -> str:
        """Reply with plain text (wrapped in a Markdown card).  Returns ``message_id``."""
        return self._im_ops.reply(self.chat_id, self._root_msg_id, text)

    async def reply_markdown(self, markdown: str) -> str:
        """Reply with a Markdown card.  Returns ``message_id``."""
        return self._im_ops.reply_markdown(self.chat_id, self._root_msg_id, markdown)

    async def reply_card(self, card_json: dict[str, Any]) -> str:
        """Reply with an interactive card.  Returns ``message_id``."""
        return self._im_ops.reply_card(self.chat_id, self._root_msg_id, card_json)

    # ── Reactions ────────────────────────────────────────────────

    async def add_reaction(self, emoji: str) -> str:
        """Add an emoji reaction to the current message.  Returns ``reaction_id``."""
        return self._im_ops.add_reaction(self.message_id, emoji)

    async def remove_reaction(self, reaction_id: str) -> None:
        """Remove an emoji reaction from the current message."""
        return self._im_ops.remove_reaction(self.message_id, reaction_id)

    # ── Resource downloads ───────────────────────────────────────

    async def download_resource(
        self,
        resource_type: str,
        key: str,
        temp_dir: str | None = None,
    ) -> Any:
        """Download a resource attached to the current message.

        Args:
            resource_type: ``"image"`` or ``"file"``.
            key: Image key or file key.
            temp_dir: Directory to save downloaded files (only for ``"file"``).

        Returns:
            For ``"image"``: ``(base64, media_type)`` tuple or ``None``.
            For ``"file"``: :class:`DownloadedFile` dataclass.
        """
        if resource_type == "image":
            return self._im_ops.download_image(self.message_id, key)
        return self._im_ops.download_file(self.message_id, key, temp_dir, key)
