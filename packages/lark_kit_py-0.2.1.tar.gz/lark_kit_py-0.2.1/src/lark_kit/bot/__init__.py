"""Bot module -- WebSocket bot abstraction for Feishu/Lark events.

Combines WSClient + EventDispatcherHandler + IM operations into a
concise Bot API::

    from lark_kit import create_bot

    bot = create_bot(app_id="...", app_secret="...")

    @bot.on("im.message.receive_v1")
    async def handle(ctx, data):
        await ctx.reply("Hello!")

    bot.start()
"""

from __future__ import annotations

import asyncio
from typing import Any, Awaitable, Callable

import lark_oapi as lark
from lark_oapi.event.dispatcher_handler import EventDispatcherHandler

from ..client import create_client
from ..im import im
from .context import BotContext

__all__ = ["Bot", "BotContext", "EventHandler", "create_bot"]

EventHandler = Callable[[BotContext, dict], Awaitable[None]]


class Bot:
    """Feishu/Lark WebSocket bot.

    Use :func:`create_bot` to obtain an instance.
    """

    def __init__(self, app_id: str, app_secret: str) -> None:
        self._app_id = app_id
        self._app_secret = app_secret
        self._handlers: dict[str, list[EventHandler]] = {}

    def on(
        self,
        event: str,
        handler: EventHandler | None = None,
    ) -> EventHandler | None:
        """Register an event handler.

        Can be used as a plain call or as a decorator::

            # Plain call
            bot.on("im.message.receive_v1", my_handler)

            # Decorator
            @bot.on("im.message.receive_v1")
            async def my_handler(ctx, data):
                ...

        Args:
            event: Event type string, e.g. ``"im.message.receive_v1"``.
            handler: Async handler ``(ctx, data) -> None``.
                If ``None``, returns a decorator.
        """
        if handler is None:
            # Decorator usage: @bot.on("im.message.receive_v1")
            def decorator(fn: EventHandler) -> EventHandler:
                self._handlers.setdefault(event, []).append(fn)
                return fn

            return decorator

        # Direct call usage: bot.on("im.message.receive_v1", fn)
        self._handlers.setdefault(event, []).append(handler)
        return None

    def start(self) -> None:
        """Start the bot -- connect WebSocket and listen for events.

        Creates the Lark client, builds an event dispatcher that routes
        events to the registered handlers (wrapping each event into a
        :class:`BotContext`), and starts the WebSocket client.

        This method blocks and runs the event loop internally.
        """
        # Create client and bound IM operations
        client_result = create_client(app_id=self._app_id, app_secret=self._app_secret)
        im_ops = im(client_result.client)
        get_token = client_result.get_token

        # Build event dispatcher
        dispatcher_builder = EventDispatcherHandler.builder("", "")

        for event, handler_list in self._handlers.items():

            def _make_callback(
                handlers: list[EventHandler],
                evt: str,
            ) -> Callable[[Any], None]:
                """Create a dispatcher callback that wraps handlers with BotContext."""

                def _dispatch(data: Any) -> None:
                    # data is a CustomizedEvent with .header and .event (dict)
                    event_dict = _extract_event_dict(data)

                    ctx = BotContext(
                        client=client_result.client,
                        get_token=get_token,
                        im_ops=im_ops,
                        event_data=event_dict,
                    )

                    async def _run_handlers() -> None:
                        for handler in handlers:
                            try:
                                await handler(ctx, event_dict)
                            except Exception as exc:
                                print(f"[BOT] Error in handler for \"{evt}\": {exc}")

                    # The lark-oapi dispatcher callback is synchronous.
                    # Schedule the async handler on the running event loop.
                    try:
                        loop = asyncio.get_event_loop()
                        if loop.is_running():
                            asyncio.ensure_future(_run_handlers())
                        else:
                            loop.run_until_complete(_run_handlers())
                    except RuntimeError:
                        loop = asyncio.new_event_loop()
                        asyncio.set_event_loop(loop)
                        loop.run_until_complete(_run_handlers())

                return _dispatch

            callback = _make_callback(handler_list, event)
            dispatcher_builder.register_p2_customized_event(event, callback)

        event_handler = dispatcher_builder.build()

        # Create WS client with the event handler and start (blocking)
        ws_client = lark.ws.Client(
            app_id=self._app_id,
            app_secret=self._app_secret,
            event_handler=event_handler,
        )
        ws_client.start()


def _extract_event_dict(data: Any) -> dict:
    """Extract the event payload as a plain dict from a lark-oapi event object.

    ``CustomizedEvent`` (used by ``register_p2_customized_event``) has an
    ``.event`` attribute that is already a plain ``dict``.

    If the data is a more specific model (e.g. ``P2ImMessageReceiveV1``),
    its ``.event`` is a typed model that we convert recursively.
    """
    if isinstance(data, dict):
        return data

    # CustomizedEvent / P2ImMessageReceiveV1 both have .event
    event = getattr(data, "event", None)
    if event is None:
        return {"message": {}, "sender": {}}

    if isinstance(event, dict):
        return event

    # Typed model -- convert recursively
    return _model_to_dict(event)


def _model_to_dict(obj: Any) -> dict:
    """Recursively convert a lark-oapi model to a plain dict."""
    if isinstance(obj, dict):
        return obj
    result: dict = {}
    for key, value in obj.__dict__.items():
        if value is None:
            continue
        if hasattr(value, "__dict__") and not isinstance(value, (str, list, dict)):
            result[key] = _model_to_dict(value)
        elif isinstance(value, list):
            result[key] = [
                _model_to_dict(item) if hasattr(item, "__dict__") and not isinstance(item, (str, dict)) else item
                for item in value
            ]
        else:
            result[key] = value
    return result


def create_bot(*, app_id: str, app_secret: str) -> Bot:
    """Create a :class:`Bot` instance.

    Args:
        app_id: Feishu/Lark application ID.
        app_secret: Feishu/Lark application secret.

    Returns:
        A configured :class:`Bot` ready to register handlers and start.
    """
    return Bot(app_id=app_id, app_secret=app_secret)
