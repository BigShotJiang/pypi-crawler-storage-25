"""Time formatting and Thinking card element builder.

Unified collapsible thinking panel for CardKit and Update modes,
aligned with the collapsible_panel approach in openclaw-lark.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .optimize import truncate_safely

# -- Constants ----------------------------------------------------------------

"""Thinking content truncation threshold (character count)."""
THINKING_OVERFLOW_TRUNCATE = 3000


# -- Time formatting ----------------------------------------------------------


def format_duration(seconds: float) -> str:
    """Format seconds as '3.2s' or '1m 23s'."""
    if seconds < 60:
        return f"{seconds:.1f}s"
    minutes = int(seconds // 60)
    remain_sec = round(seconds % 60)
    return f"{minutes}m {remain_sec}s"


def format_reasoning_duration(ms: float) -> str:
    """Format milliseconds as '3.2s' or '1m 23s'."""
    return format_duration(ms / 1000)


# -- Thinking collapsible panel -----------------------------------------------


@dataclass
class ThinkingPanelOptions:
    """Options for building a thinking collapsible panel."""

    thinking: str
    reasoning_elapsed_ms: float | None = None


def build_thinking_panel(options: ThinkingPanelOptions) -> list[dict[str, Any]]:
    """Build a thinking collapsible panel element (collapsible_panel).

    Returns [collapsible_panel, hr], which can be spread directly into a card elements array.
    Shared by both CardKit and Update modes to avoid duplication.
    """
    truncated_thinking = (
        truncate_safely(options.thinking, THINKING_OVERFLOW_TRUNCATE, "\n...")
        if len(options.thinking) > THINKING_OVERFLOW_TRUNCATE
        else options.thinking
    )

    dur_label = f" {format_reasoning_duration(options.reasoning_elapsed_ms)}" if options.reasoning_elapsed_ms else ""

    return [
        {
            "tag": "collapsible_panel",
            "expanded": False,
            "background_style": "wathet",
            "header": {
                "title": {
                    "tag": "markdown",
                    "content": f"\U0001f4ad Thought{dur_label}",
                    "i18n_content": {
                        "zh_cn": f"\U0001f4ad \u601d\u8003{dur_label}",
                        "en_us": f"\U0001f4ad Thought{dur_label}",
                    },
                },
                "vertical_align": "center",
                "icon": {
                    "tag": "standard_icon",
                    "token": "down-small-ccm_outlined",
                    "size": "16px 16px",
                },
                "icon_position": "follow_text",
                "icon_expanded_angle": -180,
            },
            "border": {"color": "grey", "corner_radius": "5px"},
            "vertical_spacing": "8px",
            "padding": "8px 8px 8px 8px",
            "elements": [
                {
                    "tag": "markdown",
                    "content": truncated_thinking,
                    "text_size": "notation",
                },
            ],
        },
        {"tag": "hr"},
    ]
