"""Lark card builder module.

Provides builders for Header, Footer, Markdown cards, task panel cards,
and a convenience ``build()`` function that composes them.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Literal

from .optimize import optimize_for_card
from .thinking import build_thinking_panel, format_duration

# -- Constants ----------------------------------------------------------------

DEFAULT_ICON_TOKEN = "larkcommunity_colorful"

# -- Type definitions ---------------------------------------------------------


@dataclass
class HeaderTag:
    """A tag displayed in the card header."""

    text: str
    color: str


@dataclass
class HeaderOptions:
    """Options for building a card header."""

    title: str
    subtitle: str | None = None
    template: str | None = None
    icon_img_key: str | None = None
    icon_token: str | None = None
    tags: list[HeaderTag] | None = None


@dataclass
class FooterStats:
    """Statistics shown in the card footer."""

    input_tokens: int | None = None
    output_tokens: int | None = None
    tool_count: int | None = None
    duration: float | None = None


@dataclass
class CardBuildOptions:
    """Options for building a Markdown card."""

    thinking: str | None = None
    thinking_in_progress: bool | None = None
    reasoning_elapsed_ms: float | None = None
    card_title: str | None = None


TaskPanelStatus = Literal["running", "completed", "failed", "stopped"]


@dataclass
class TaskPanelCardOptions:
    """Options for building a task panel card."""

    description: str
    status: TaskPanelStatus
    summary: str | None = None
    last_tool_name: str | None = None
    elapsed_seconds: float | None = None
    tokens: int | None = None
    header_icon_img_key: str | None = None


@dataclass
class BuildOptions:
    """Options for the convenience ``build()`` function."""

    content: str
    title: str | None = None
    subtitle: str | None = None
    template: str | None = None
    icon_img_key: str | None = None
    icon_token: str | None = None
    tags: list[HeaderTag] | None = None
    footer: FooterStats | None = None
    thinking: str | None = None
    thinking_in_progress: bool | None = None
    reasoning_elapsed_ms: float | None = None


# -- Content sanitization (local) ---------------------------------------------

_EXTERNAL_IMAGE_EMOJI = "\U0001f5bc\ufe0f"


def _sanitize_content(content: str) -> tuple[str, list[str]]:
    """Sanitize content by removing invalid URLs.

    1. blob: URLs - fully removed
    2. External image URLs - converted to links + emoji

    Code blocks are protected from accidental modification.
    """
    from .optimize import extract_code_blocks, restore_code_blocks

    warnings: list[str] = []

    # 0. Extract code blocks to protect them
    text, codes = extract_code_blocks(content)
    processed = text

    # 1. Handle blob URLs
    blob_matches = re.findall(r"!\[[^\]]*\]\(blob:[^)]+\)", processed, re.IGNORECASE)
    if blob_matches:
        # Remove Markdown images ![...](blob:...)
        processed = re.sub(r"!\[[^\]]*\]\(blob:[^)]+\)", "", processed, flags=re.IGNORECASE)
        # Keep text, remove blob links [...](blob:...)
        processed = re.sub(r"\[([^\]]+)\]\(blob:[^)]+\)", r"\1", processed, flags=re.IGNORECASE)
        # Remove standalone blob URLs
        processed = re.sub(r"blob:https?://[^\s)]+", "", processed, flags=re.IGNORECASE)
        warnings.append(f"\u5df2\u8fc7\u6ee4 {len(blob_matches)} \u4e2a\u65e0\u6548\u56fe\u7247")

    # 2. Handle external images (non-blob https?:// images)
    external_img_matches = re.findall(r"!\[([^\]]*)\]\((https?://[^)]+)\)", processed, re.IGNORECASE)
    if external_img_matches:
        # Convert: ![alt](https://...) -> [alt](https://...) <emoji>
        def _replace_external_img(match: re.Match[str]) -> str:
            alt = match.group(1)
            url = match.group(2)
            display_text = alt or "\u56fe\u7247"
            return f"[{display_text}]({url}) {_EXTERNAL_IMAGE_EMOJI}"

        processed = re.sub(
            r"!\[([^\]]*)\]\((https?://[^)]+)\)",
            _replace_external_img,
            processed,
            flags=re.IGNORECASE,
        )
        warnings.append(f"\u5df2\u8f6c\u6362 {len(external_img_matches)} \u4e2a\u5916\u90e8\u56fe\u7247\u4e3a\u94fe\u63a5")

    # 3. Restore code blocks
    processed = restore_code_blocks(processed, codes)

    return processed, warnings


def _format_warnings(warnings: list[str]) -> str:
    """Format warning messages for display in cards."""
    if not warnings:
        return ""
    return "\n\n\uff08" + "\uff0c".join(warnings) + "\uff09"


# -- Header builder -----------------------------------------------------------


def build_header(options: HeaderOptions) -> dict[str, Any]:
    """Build a card header element."""
    header: dict[str, Any] = {
        "title": {"tag": "plain_text", "content": options.title},
        "template": options.template or "blue",
    }

    if options.subtitle:
        header["subtitle"] = {"tag": "plain_text", "content": options.subtitle}

    if options.icon_img_key:
        header["icon"] = {"tag": "custom_icon", "img_key": options.icon_img_key}
    else:
        header["icon"] = {
            "tag": "standard_icon",
            "token": options.icon_token or DEFAULT_ICON_TOKEN,
        }

    if options.tags:
        header["text_tag_list"] = [
            {
                "tag": "text_tag",
                "text": {"tag": "plain_text", "content": t.text},
                "color": t.color,
            }
            for t in options.tags[:3]
        ]

    return header


# -- Footer builder -----------------------------------------------------------


def build_footer_markdown(stats: FooterStats) -> str | None:
    """Build footer statistics Markdown text.

    Returns grey-colored token/tool/duration stats, or ``None`` if no content.
    """
    parts: list[str] = []

    if stats.input_tokens is not None:
        parts.append(f"\U0001f4e5 {stats.input_tokens:,}")
    if stats.output_tokens is not None:
        parts.append(f"\U0001f4e4 {stats.output_tokens:,}")
    if stats.tool_count is not None and stats.tool_count > 0:
        parts.append(f"\U0001f527 {stats.tool_count}")

    if not parts:
        return None

    return f"<font color='grey'>{' · '.join(parts)}</font>"


# -- Markdown card ------------------------------------------------------------


def build_markdown_card(
    markdown: str,
    warnings: list[str] | None = None,
    options: CardBuildOptions | None = None,
) -> dict[str, Any]:
    """Build a Markdown card JSON.

    Supports an optional thinking collapsible section:
    - ``thinking_in_progress``: streaming intermediate state, shows "thinking..." prompt
    - ``thinking``: completed state, shows a collapsible thinking panel
    """
    if warnings is None:
        warnings = []

    content = markdown
    if warnings:
        content += _format_warnings(warnings)

    elements: list[dict[str, Any]] = []

    # Thinking section
    if options and options.thinking_in_progress:
        elements.append({"tag": "markdown", "content": "\U0001f4ad \u601d\u8003\u4e2d..."})
    elif options and options.thinking:
        elements.extend(
            build_thinking_panel(
                _ThinkingPanelAdapter(
                    thinking=options.thinking,
                    reasoning_elapsed_ms=options.reasoning_elapsed_ms,
                )
            )
        )

    elements.append({"tag": "markdown", "content": content})

    card: dict[str, Any] = {
        "schema": "2.0",
        "config": {"wide_screen_mode": True},
        "body": {"elements": elements},
    }

    if options and options.card_title:
        card["header"] = {
            "title": {"tag": "plain_text", "content": options.card_title},
            "template": "blue",
        }

    return card


# -- Task panel card ----------------------------------------------------------

_STATUS_TEMPLATE: dict[str, dict[str, str]] = {
    "running": {"color": "turquoise", "icon": "\U0001f504", "label": "Running"},
    "completed": {"color": "green", "icon": "\u2705", "label": "Completed"},
    "failed": {"color": "red", "icon": "\u274c", "label": "Failed"},
    "stopped": {"color": "grey", "icon": "\u23f9", "label": "Stopped"},
}


def build_task_panel_card(options: TaskPanelCardOptions) -> dict[str, Any]:
    """Build a task panel card (for sub-agent status display)."""
    st = _STATUS_TEMPLATE[options.status]

    elements: list[dict[str, Any]] = []

    # Status line
    status_parts: list[str] = [f"**{st['icon']} {st['label']}**"]
    if options.last_tool_name and options.status == "running":
        status_parts.append(f"Tool: `{options.last_tool_name}`")
    elements.append({"tag": "markdown", "content": " · ".join(status_parts)})

    # Content area (no hr)
    has_content = options.summary and options.summary not in ("Done", "Aborted")
    if has_content:
        assert options.summary is not None
        summary_text = options.summary[:3000] + "..." if len(options.summary) > 3000 else options.summary
        elements.append({"tag": "markdown", "content": summary_text})
    elif options.status == "running":
        elements.append({"tag": "markdown", "content": "Processing..."})

    # Footer (all statuses)
    footer_parts: list[str] = []
    if options.elapsed_seconds is not None:
        footer_parts.append(f"\u23f1 {format_duration(options.elapsed_seconds)}")
    if options.status != "running" and options.tokens is not None:
        footer_parts.append(f"\U0001fa99 {options.tokens:,} tokens")
    if footer_parts:
        elements.append(
            {"tag": "markdown", "content": f"<font color='grey'>{' · '.join(footer_parts)}</font>"}
        )

    # Header (fixed title, no tags)
    icon: dict[str, Any]
    if options.header_icon_img_key:
        icon = {"tag": "custom_icon", "img_key": options.header_icon_img_key}
    else:
        icon = {"tag": "standard_icon", "token": DEFAULT_ICON_TOKEN}

    return {
        "schema": "2.0",
        "config": {"wide_screen_mode": True},
        "header": {
            "title": {"tag": "plain_text", "content": "\U0001f916 Sub Agent"},
            "subtitle": {"tag": "plain_text", "content": options.description},
            "template": st["color"],
            "icon": icon,
        },
        "body": {"elements": elements},
    }


# -- Convenience build function -----------------------------------------------

# Adapter to reuse ThinkingPanelOptions dataclass from thinking.py
@dataclass
class _ThinkingPanelAdapter:
    """Internal adapter matching ThinkingPanelOptions interface."""

    thinking: str
    reasoning_elapsed_ms: float | None = None


def build(options: BuildOptions) -> dict[str, Any]:
    """Convenience builder: compose header / body / footer / thinking into a full card.

    Automatically handles:
    - Content sanitization and optimization (optimize_for_card)
    - Thinking collapsible panel
    - Footer statistics row
    """
    # 1. Sanitize & optimize content
    sanitized, warnings = _sanitize_content(options.content)
    optimized = optimize_for_card(sanitized)
    body_text = optimized
    if warnings:
        body_text += _format_warnings(warnings)

    # 2. Build elements
    elements: list[dict[str, Any]] = []

    # Thinking section
    if options.thinking_in_progress:
        elements.append({"tag": "markdown", "content": "\U0001f4ad \u601d\u8003\u4e2d..."})
    elif options.thinking:
        elements.extend(
            build_thinking_panel(
                _ThinkingPanelAdapter(
                    thinking=options.thinking,
                    reasoning_elapsed_ms=options.reasoning_elapsed_ms,
                )
            )
        )

    # Body
    elements.append({"tag": "markdown", "content": body_text})

    # Footer
    if options.footer:
        footer_md = build_footer_markdown(options.footer)
        if footer_md:
            elements.append({"tag": "hr"})
            elements.append({"tag": "markdown", "content": footer_md})

    # 3. Assemble card
    card: dict[str, Any] = {
        "schema": "2.0",
        "config": {"wide_screen_mode": True},
        "body": {"elements": elements},
    }

    if options.title:
        card["header"] = build_header(
            HeaderOptions(
                title=options.title,
                subtitle=options.subtitle,
                template=options.template,
                icon_img_key=options.icon_img_key,
                icon_token=options.icon_token,
                tags=options.tags,
            )
        )

    return card
