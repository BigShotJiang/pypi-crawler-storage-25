"""Lark card module.

Provides Markdown optimization, thinking panel, and card building capabilities.
"""

# -- Optimization pipeline --
from .optimize import (
    ExtractedCode,
    extract_code_blocks,
    restore_code_blocks,
    demote_headings,
    truncate_safely,
    optimize_for_card,
)

# -- Thinking collapsible panel & time formatting --
from .thinking import (
    THINKING_OVERFLOW_TRUNCATE,
    ThinkingPanelOptions,
    format_duration,
    format_reasoning_duration,
    build_thinking_panel,
)

# -- Card builders --
from .builder import (
    HeaderTag,
    HeaderOptions,
    FooterStats,
    CardBuildOptions,
    TaskPanelStatus,
    TaskPanelCardOptions,
    BuildOptions,
    build_header,
    build_footer_markdown,
    build_markdown_card,
    build_task_panel_card,
    build,
)

__all__ = [
    # optimize
    "ExtractedCode",
    "extract_code_blocks",
    "restore_code_blocks",
    "demote_headings",
    "truncate_safely",
    "optimize_for_card",
    # thinking
    "THINKING_OVERFLOW_TRUNCATE",
    "ThinkingPanelOptions",
    "format_duration",
    "format_reasoning_duration",
    "build_thinking_panel",
    # builder
    "HeaderTag",
    "HeaderOptions",
    "FooterStats",
    "CardBuildOptions",
    "TaskPanelStatus",
    "TaskPanelCardOptions",
    "BuildOptions",
    "build_header",
    "build_footer_markdown",
    "build_markdown_card",
    "build_task_panel_card",
    "build",
]
