"""Card Markdown optimization pipeline.

Lark cards have limited Markdown rendering:
- Only H4 (####) and H5 (#####) headings are supported
- External image URLs are not supported (only img_xxx format)
- Code block content should not be misinterpreted by other processing logic

This module provides a pipeline to adapt generic Markdown to card-friendly format.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

# -- Code block protection ---------------------------------------------------

CODE_PLACEHOLDER_PREFIX = "\x00CODE_"
CODE_PLACEHOLDER_SUFFIX = "\x00"

# Regex matching ```lang\\n...\\n``` code blocks (including single-line)
_CODE_BLOCK_RE = re.compile(r"(```[^\n]*\n)([\s\S]*?)(```)")


@dataclass
class ExtractedCode:
    """A code block extracted and replaced with a placeholder."""

    placeholder: str
    content: str


def extract_code_blocks(text: str) -> tuple[str, list[ExtractedCode]]:
    """Extract code blocks and replace them with placeholders.

    Returns the text with placeholders and a list of extracted code blocks.
    """
    codes: list[ExtractedCode] = []
    index = 0

    def _replace(match: re.Match[str]) -> str:
        nonlocal index
        open_tag = match.group(1)
        content = match.group(2)
        close_tag = match.group(3)
        placeholder = f"{CODE_PLACEHOLDER_PREFIX}{index}{CODE_PLACEHOLDER_SUFFIX}"
        codes.append(ExtractedCode(placeholder=placeholder, content=open_tag + content + close_tag))
        index += 1
        return placeholder

    result = _CODE_BLOCK_RE.sub(_replace, text)
    return result, codes


def restore_code_blocks(text: str, codes: list[ExtractedCode]) -> str:
    """Restore code block placeholders back to their original content."""
    result = text
    for code in codes:
        result = result.replace(code.placeholder, code.content)
    return result


# -- Heading demotion ---------------------------------------------------------


def demote_headings(text: str) -> str:
    """Demote Markdown headings to levels supported by Lark cards.

    Applied in TS order:
    1. H1: # -> ####
    2. H2: ## -> #####
    3. H3-H6: ###/####/#####/###### -> #####

    Note: H1 is demoted twice (step 1 -> ####, step 3 -> #####),
    matching the original TS behavior.
    """
    # H1: # Title -> #### Title
    text = re.sub(r"^#(\s)", "####\\1", text, flags=re.MULTILINE)
    # H2: ## Title -> ##### Title
    text = re.sub(r"^##(\s)", "#####\\1", text, flags=re.MULTILINE)
    # H3-H6: ###/####/#####/###### -> ##### (all demoted to H5)
    text = re.sub(r"^#{3,6}(\s)", "#####\\1", text, flags=re.MULTILINE)
    return text


# -- Safe truncation ----------------------------------------------------------


def truncate_safely(text: str, limit: int, suffix: str = "\n\n...") -> str:
    """Safely truncate Markdown content.

    Avoids truncating in the middle of code blocks or tables:
    1. Detects unclosed code blocks (odd number of ```) -> falls back to before the code block
    2. Detects unclosed tables -> falls back to before the table
    3. Edge case (code block takes most of the content) -> close the code block then truncate
    """
    if len(text) <= limit:
        return text

    truncated = text[:limit]

    # Detect unclosed code blocks
    code_block_count = truncated.count("```")
    if code_block_count % 2 != 0:
        last_code_start = truncated.rfind("```")
        if last_code_start > limit * 0.5:
            # Code block occupies the latter half, fall back to before it
            truncated = text[:last_code_start].rstrip()
        else:
            # Code block takes most of the content, close it
            truncated = truncated + "\n```"

    # Detect unclosed tables
    lines = truncated.split("\n")
    last_lines = lines[-5:]
    in_table = any(line.strip().startswith("|") for line in last_lines)
    if in_table:
        # Find the blank line before the table started
        table_start = len(lines) - 1
        while table_start >= 0 and lines[table_start].strip() != "" and not lines[table_start].strip().startswith("|"):
            table_start -= 1
        # Fall back to before the table
        safe_end = table_start
        while safe_end > 0 and lines[safe_end - 1].strip() == "":
            safe_end -= 1
        if safe_end > limit * 0.3:
            truncated = "\n".join(lines[:safe_end]).rstrip()

    return truncated + suffix


# -- Main optimization function -----------------------------------------------


def optimize_for_card(markdown: str) -> str:
    """Optimize Markdown content for Lark card rendering.

    Pipeline order:
    1. Extract code blocks (protect code content from being misprocessed)
    2. Demote headings (H1-H6 -> H4/H5)
    3. Restore code blocks
    """
    # 1. Extract code blocks
    text, codes = extract_code_blocks(markdown)

    # 2. Demote headings
    optimized = demote_headings(text)

    # 3. Restore code blocks
    optimized = restore_code_blocks(optimized, codes)

    return optimized
