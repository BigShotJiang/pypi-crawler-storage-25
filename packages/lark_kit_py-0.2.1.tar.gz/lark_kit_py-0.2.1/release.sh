#!/usr/bin/env bash
set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

info()    { echo -e "${CYAN}ℹ${NC}  $1"; }
success() { echo -e "${GREEN}✅${NC} $1"; }
warn()    { echo -e "${YELLOW}⚠${NC}  $1"; }
error()   { echo -e "${RED}❌${NC} $1"; exit 1; }
dim()     { echo -e "\033[0;37m$1\033[0m"; }

# Help function
show_help() {
  echo ""
  echo -e "${CYAN}lark-kit-py 发布脚本${NC}"
  echo ""
  echo "用法: ./release.sh [patch|minor|major]"
  echo ""
  echo "参数:"
  echo "  patch   修复版本 (0.1.2 → 0.1.3)"
  echo "  minor   功能版本 (0.1.2 → 0.2.0)"
  echo "  major   主版本   (0.1.2 → 1.0.0)"
  echo ""
  echo "选项:"
  echo "  -h, --help   显示帮助信息"
  echo ""
  echo "示例:"
  echo "  ./release.sh patch   # 发布修复版本"
  echo "  ./release.sh minor   # 发布功能版本"
  echo "  ./release.sh major   # 发布主版本"
  echo ""
  exit 0
}

# Show help if requested
if [[ "$1" == "-h" || "$1" == "--help" ]]; then
  show_help
fi

# Check for uncommitted changes
if [[ -n $(git status --porcelain) ]]; then
  error "有未提交的更改，请先提交"
fi

# Get current version from pyproject.toml
CURRENT_VERSION=$(grep '^version = ' pyproject.toml | head -1 | sed 's/version = "\(.*\)"/\1/')
info "当前版本: v${CURRENT_VERSION}"

# Get version bump type
BUMP_TYPE=${1:-patch}
if [[ "$BUMP_TYPE" != "patch" && "$BUMP_TYPE" != "minor" && "$BUMP_TYPE" != "major" ]]; then
  error "用法: ./release.sh [patch|minor|major]"
fi

# Calculate new version
IFS='.' read -r MAJOR MINOR PATCH <<< "$CURRENT_VERSION"
case "$BUMP_TYPE" in
  patch) PATCH=$((PATCH + 1)) ;;
  minor) MINOR=$((MINOR + 1)); PATCH=0 ;;
  major) MAJOR=$((MAJOR + 1)); MINOR=0; PATCH=0 ;;
esac
NEW_VERSION="${MAJOR}.${MINOR}.${PATCH}"
info "新版本: v${NEW_VERSION}"

# Confirm
echo ""
read -rp "  确认发布 v${NEW_VERSION}? (y/n): " CONFIRM
if [[ "$CONFIRM" != "y" && "$CONFIRM" != "Y" ]]; then
  info "已取消"
  exit 0
fi
echo ""

# Update pyproject.toml version
info "更新 pyproject.toml..."
sed -i "s/^version = \"${CURRENT_VERSION}\"/version = \"${NEW_VERSION}\"/" pyproject.toml

# Update pixi.toml version
info "更新 pixi.toml..."
sed -i "s/^version = \"${CURRENT_VERSION}\"/version = \"${NEW_VERSION}\"/" pixi.toml

# Commit changes
info "提交更改..."
git add pyproject.toml pixi.toml CHANGELOG.md
git commit -m "chore: release v${NEW_VERSION}"

# Create tag
info "创建 tag v${NEW_VERSION}..."
git tag v${NEW_VERSION}

# Push
info "推送到远程..."
git push origin main --tags

# Create GitHub Release
info "创建 GitHub Release..."
if gh release create v${NEW_VERSION} --title "v${NEW_VERSION}" --generate-notes 2>/dev/null; then
  echo ""
  echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
  success "发布完成!"
  echo ""
  dim "GitHub Actions 会自动发布到 PyPI"
  echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
  echo ""
else
  echo ""
  echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
  warn "创建 GitHub Release 失败"
  warn "可能原因："
  warn "  1. gh 未安装"
  warn "  2. gh 未认证 (运行 gh auth login)"
  warn "  3. 网络问题"
  echo ""
  dim "请手动创建: https://github.com/suj1e/lark-kit-py/releases/new"
  echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
  echo ""
fi
