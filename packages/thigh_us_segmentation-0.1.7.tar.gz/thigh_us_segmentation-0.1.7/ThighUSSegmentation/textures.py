from pathlib import Path
import logging
import warnings
import numpy as np
import pandas as pd
import SimpleITK as sitk

# Intentamos importar PyRadiomics de forma segura al cargar el módulo
try:
    from radiomics import featureextractor
    HAS_RADIOMICS = True
except ImportError:
    featureextractor = None
    HAS_RADIOMICS = False

logger = logging.getLogger(__name__)

def build_radiomics_extractor(
    bin_width: int = 5,
    force_2d: bool = True,
    force_2d_dimension: int = 0,
    normalize: bool = False,
    normalize_scale: int = 1,
    distances: list[int] | None = None,
):
    """
    Configura el extractor de PyRadiomics para el recto femoral.
    """
    if not HAS_RADIOMICS:
        raise ImportError(
            "PyRadiomics no está instalado. "
            "Por favor, instálalo en tu entorno con: pip install pyradiomics==3.0.1"
        )

    if distances is None:
        distances = [8]
    
    settings = {
        "binWidth": bin_width,
        "force2D": force_2d,
        "force2Ddimension": force_2d_dimension,
        "normalize": normalize,
        "normalizeScale": normalize_scale,
        "distances": distances,
    }

    # Al estar HAS_RADIOMICS validado, podemos usar featureextractor con seguridad
    extractor = featureextractor.RadiomicsFeatureExtractor(**settings)

    extractor.disableAllFeatures()

    extractor.enableFeaturesByName(
        firstorder=[
            "Mean",
            "Variance",
            "Kurtosis",
        ],
        glcm=[
            "Contrast",
            "Correlation",
            "JointEnergy",
            "JointEntropy",
            "Idm",
        ],
    )

    return extractor


def extract_rectus_femoral_mask(
    label_image: sitk.Image,
    rectus_label: int = 3,
    min_pixels: int = 20,
) -> sitk.Image:
    """
    Extrae la máscara binaria del recto femoral a partir de la segmentación.
    """
    label_arr = sitk.GetArrayFromImage(label_image)
    rf_mask = (label_arr == rectus_label).astype(np.uint8)

    if np.sum(rf_mask) < min_pixels:
        raise ValueError(
            f"La máscara del recto femoral es demasiado pequeña: "
            f"{np.sum(rf_mask)} píxeles"
        )

    mask_sitk = sitk.GetImageFromArray(rf_mask)
    mask_sitk.CopyInformation(label_image)

    return mask_sitk


def extract_textures_dataframe(
    image_path: str,
    mask_path: str,
    case_id: str | None = None,
    rectus_label: int = 3,
    min_pixels: int = 20,
) -> pd.DataFrame:
    """
    Calcula las texturas del recto femoral y devuelve un DataFrame.
    """
    # Verificación de dependencia antes de procesar
    if not HAS_RADIOMICS:
        raise ImportError(
            "PyRadiomics no está instalado. Instala la librería para usar esta función."
        )

    image_path = Path(image_path)
    mask_path = Path(mask_path)

    if not image_path.exists():
        raise FileNotFoundError(f"No existe la imagen: {image_path}")

    if not mask_path.exists():
        raise FileNotFoundError(f"No existe la máscara: {mask_path}")

    if case_id is None:
        case_id = mask_path.name.replace(".nii.gz", "").replace(".mha", "")

    logger.info(f"Leyendo imagen: {image_path}")
    img_sitk = sitk.ReadImage(str(image_path))

    logger.info(f"Leyendo máscara: {mask_path}")
    lab_sitk = sitk.ReadImage(str(mask_path))

    if img_sitk.GetSize() != lab_sitk.GetSize():
        raise ValueError(
            f"La imagen y la máscara no tienen el mismo tamaño: "
            f"image={img_sitk.GetSize()}, mask={lab_sitk.GetSize()}"
        )

    mask_sitk = extract_rectus_femoral_mask(
        label_image=lab_sitk,
        rectus_label=rectus_label,
        min_pixels=min_pixels,
    )

    # Construcción y ejecución del extractor
    extractor = build_radiomics_extractor()
    features = extractor.execute(img_sitk, mask_sitk)

    row = {
        "case_id": case_id,
        "rf_mean": features.get("original_firstorder_Mean"),
        "rf_std": np.sqrt(features.get("original_firstorder_Variance", 0)),
        "rf_kurtosis": features.get("original_firstorder_Kurtosis"),
        "glcm_contrast_d8": features.get("original_glcm_Contrast"),
        "glcm_correlation_d8": features.get("original_glcm_Correlation"),
        "glcm_energy_d8": features.get("original_glcm_JointEnergy"),
        "glcm_entropy_d8": features.get("original_glcm_JointEntropy"),
        "glcm_homogeneity_d8": features.get("original_glcm_Idm"),
    }

    return pd.DataFrame([row])