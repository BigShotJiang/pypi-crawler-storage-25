import asyncio
from openai import AsyncOpenAI

async def main():
    client = AsyncOpenAI()
    response = await client.chat.completions.create(
        model="gpt-4.1-mini",
        max_tokens=64,
        messages=[{"role": "user", "content": "Say, Hi!"}],
    )
    print(response.choices[0].message.content)

asyncio.run(main())
