import asyncio
from univllm import UniversalLLMClient

async def main():
    client = UniversalLLMClient()
    response = await client.complete(
        model="claude-haiku-4-5-20251001",
        messages=[{"role": "user", "content": "Say, Hi!"}],
    )
    print(response.content)

asyncio.run(main())
