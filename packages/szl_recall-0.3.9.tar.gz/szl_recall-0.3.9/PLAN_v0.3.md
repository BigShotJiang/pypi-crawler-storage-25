# Recall v0.3 — Implementation Plan

**Document status**: Planning  
**Prepared**: 2026-05-12  
**Based on**: v0.2.0 codebase audit + Series 4 "Memory in AI Systems" arc  
**Scope**: Six features across four newsletter issues (Issues 3, 4, 7, and parts of Issue 6)

---

## 1. Current State Assessment

### 1.1 What v0.2 Actually Implements

Verified against code, not just the README:

**Core retrieval** (`server.py: _hybrid_search`):
- Fetches `limit * 5` memories from SQLite (`WHERE valid_until IS NULL`)
- BM25Plus ranking via `_bm25_ranks()` — graceful import fallback if `rank_bm25` missing
- Dense cosine similarity via `_dense_ranks()` — graceful import fallback if `sentence-transformers` missing
- RRF fusion with k=60 (`_rrf_fuse`)
- 4-component scoring with linearly-interpolated weights based on `recency_weight` parameter
- Memories with zero RRF signal are suppressed from results entirely

**Scoring formula** (verified in code):
```
w_rrf      = 0.70 - 0.30 * recency_weight   # 0.70 → 0.40
w_recency  = 0.40 * recency_weight           # 0.00 → 0.40
w_import   = 0.20 - 0.10 * recency_weight    # 0.20 → 0.10
w_strength = 0.10                            # fixed

score = w_rrf * rrf_score
      + w_recency * exp(-age_days / (1 + access_count))
      + w_import  * importance
      + w_strength * log(1+ac) / log(1+max_ac)
```

**Five MCP tools** (`server.py`):
- `store_memory` — async-acknowledge, idempotency via `INSERT OR IGNORE`, queue-based extraction
- `search_memories` — wraps `_hybrid_search`, validates `recency_weight` [0,1]
- `inspect_memories` — paginated list of active (`valid_until IS NULL`) memories
- `delete_memory` — user-scoped hard delete
- `get_memory_stats` — counts by type + pending extractions

**Extraction worker** (`worker.py`):
- `ExtractionWorker` — asyncio.Queue, max 1000 slots, claude-haiku-4-5-20251001
- Contradiction detection in `_handle_contradiction` — entity+attribute collision → set `valid_until`, `superseded_by`
- `_extract_stub_fallback` — returns raw text as single fact on LLM/parse failure
- `ANTHROPIC_API_KEY` required at instantiation time (hard fail)

**A2A consolidation** (`a2a.py`):
- In-memory task store (not persisted across restarts)
- `consolidate_memories` skill: extract → heuristic contradiction check → `input-required` state
- Contradiction detection is purely heuristic: shared 3+ tokens AND negation word present — completely separate from the schema-based `_handle_contradiction` in the worker
- Three resolution strategies: `keep_existing`, `keep_new`, `keep_both`

**Schema** (`db/schema.sql` + `db/connection.py`):
- Single SQLite file, WAL mode
- `memories` table has `decay_score REAL` column already defined (unused)
- `valid_until` + `superseded_by` are the bi-temporal versioning columns
- `access_count` and `last_accessed` exist but `access_count` is never incremented on read — a real gap
- v2 migration (`_migrate_v2`) applies ALTER TABLE for `entity`, `attribute`, `value`, `valid_from`, `valid_until`, `session_id`, `agent_id`, `linked_ids` on existing DBs

**Security** (`security.py`):
- Bearer tokens are SHA-256 hashed before storage
- Tool description validation at startup against injection patterns
- `TimeoutMiddleware` — 30s hard timeout
- `LoggingMiddleware` — `ToolCallRecord` per call

**Models** (`models.py`):
- `MemoryUnit` dataclass with `__post_init__` validation
- `decay_score: float | None` exists as a field (explicitly noted "computed in Memory series")
- `embedding: list[float] | None` exists (noted "added when pgvector available")

### 1.2 Test Coverage (48 tests verified)

| File | Tests | What's Covered |
|------|-------|----------------|
| `test_models.py` | 11 | MemoryUnit validation, to_dict serialization |
| `test_client.py` | 12 | SQLite layer CRUD, pagination, user isolation |
| `test_server.py` | 9 | HTTP auth, all 5 tools shape/error codes |
| `test_search.py` | 7 | Superseded filtering, idempotency atomicity, recency/relevance ranking |
| `test_worker.py` | 4 | Extraction pipeline (API-gated), stub fallback |

**What the tests do NOT cover (confirmed gaps)**:
- `access_count` increment on search hit — never tested, never implemented
- Dense embedding path in `_dense_ranks` — all ranking tests use BM25-only corpus
- A2A task lifecycle (create/poll/resume) — zero test coverage
- A2A contradiction heuristic vs. worker schema-based contradiction — two separate systems, neither tested for correctness of the heuristic
- `_recover_orphaned_operations` behavior on restart — not tested
- The `decay_score` column — present in schema and model, but never written by any code
- `linked_ids` column — defined in schema, never used
- `last_accessed` timestamp update — never written on read

### 1.3 Technical Debt to Address in v0.3

1. **`access_count` is never incremented** — The scoring formula includes an access-frequency term `log(1+ac)/log(1+max_ac)`, but `_hybrid_search` never updates `access_count` or `last_accessed` after retrieving memories. The strength component is always zero for all memories. This is a silent correctness bug.

2. **A2A task store is in-memory** — `_tasks: dict` in `a2a.py` is lost on every restart. Any in-flight A2A tasks are permanently lost. Noted in the code as "In-memory task store — sufficient for v0.1 (DB persistence in Memory series)".

3. **Two contradiction detection systems** — `_handle_contradiction` in `worker.py` uses schema-based entity+attribute matching (precise). `_detect_contradictions` in `a2a.py` uses token overlap heuristics (coarse). These serve different purposes but are unaware of each other. The consolidation MCP tool (v0.3 Feature 4) needs to decide which system to use.

4. **`connection.py` is SQLite-specific** — The `get_db_path()` abstraction is SQLite-only. The Postgres backend (Feature 5) needs a proper backend abstraction layer, not just another `get_db_path()` variant.

5. **No threshold gate on retrieval** — All memories with non-zero RRF score are candidates. A very low-relevance memory can still surface if it's the only one with any token overlap. Series 4 Issue 4 calls for a similarity threshold gate.

6. **`_hybrid_search` pre-fetches `limit * 5` rows blindly** — For Postgres, this is fine. For SQLite with large corpora, this is N=100 rows for a default limit=20 search. Acceptable but worth noting.

---

## 2. Feature Specifications

### Feature 1: MMR Retrieval

**What it is**: Maximal Marginal Relevance post-ranking step applied after RRF fusion and 4-component scoring. Prevents returning 5 near-identical memories when diverse coverage is better. Controlled by a new `mmr_lambda` parameter.

**Why**: Series 4 Issue 4 (READ phase). Production problem: a retrieval system surfacing 5 variations of "user likes Italian food" is worse than surfacing "user likes Italian food" + "user has a nut allergy" + "user prefers dinner over lunch". The current system re-ranks for recency and importance but applies no diversity pressure.

**Interface**: Extends `search_memories` signature and `_hybrid_search` internal call:

```python
# server.py: search_memories tool
async def search_memories(
    query: str,
    limit: int = 20,
    recency_weight: float = 0.3,
    mmr_lambda: float = 0.7,          # NEW — 0.0=pure diversity, 1.0=pure relevance
    score_threshold: float = 0.0,     # NEW — minimum RRF score gate (0.0 = no gate)
) -> dict:

# server.py: _hybrid_search internal
async def _hybrid_search(
    user_id: str,
    query: str,
    limit: int,
    recency_weight: float = 0.3,
    mmr_lambda: float = 0.7,          # NEW
    score_threshold: float = 0.0,     # NEW
) -> list[dict]:
```

**Implementation approach**: MMR operates in two stages, applied after the 4-component scoring:

Stage 1 — Threshold gate (new): Filter out any candidate where `rrf_score < score_threshold`. This runs before MMR so MMR doesn't waste diversity budget on low-signal memories.

Stage 2 — MMR greedy selection:
1. Start with empty result set `S = []` and candidate set `C` = all scored candidates (after threshold gate), in descending score order.
2. Select the top-scored candidate from `C` into `S`. Remove it from `C`.
3. For each remaining candidate `d` in `C`, compute:
   ```
   MMR(d) = λ · sim_4comp(d)  -  (1 - λ) · max_{s ∈ S} cosine_sim(embed(d), embed(s))
   ```
   Where `sim_4comp(d)` is the 4-component score normalized to [0,1] by dividing by max score in `C`, and `cosine_sim` is the dot product of L2-normalized embeddings (already computed during dense ranking).
4. Select the candidate with highest MMR score into `S`. Remove from `C`.
5. Repeat until `len(S) == limit` or `C` is empty.

**Embedding availability**: Embeddings may not be present (BM25-only mode). When `dense_r is None`, the diversity penalty term reduces to zero and MMR degrades gracefully to pure relevance ranking (same as `mmr_lambda=1.0`). This is documented behavior, not an error.

**Edge case**: `mmr_lambda=1.0` must produce identical results to the current non-MMR sort. This is a regression test anchor.

**What changes**:
- `server.py`: `search_memories` — add `mmr_lambda` and `score_threshold` params with validation
- `server.py`: `_hybrid_search` — accept new params, implement MMR greedy loop, add threshold gate
- `server.py`: `_validate_server_descriptions` — re-list `search_memories` (description doesn't change, but function signature does)
- `server.py`: fix `access_count` update bug (see Technical Debt item 1) — update `access_count` and `last_accessed` for returned memories in `_hybrid_search`

**What does NOT change**: The 4-component weights formula, BM25/dense ranking, RRF fusion. These are computed identically; MMR is purely a post-processing step on the ranked list.

**Test spec** (`tests/test_mmr.py`):

```python
# Fixture: 6 memories about "Python" (4 near-identical) + 1 about "Java" + 1 about "food"
# All stored directly via client.store() with access_count=0

async def test_mmr_lambda_1_matches_relevance_ranking(client, user_id):
    # mmr_lambda=1.0 must return same order as current ranking
    # Assert: results with lambda=1.0 == results with lambda=1.0 (pure relevance)
    # Assert: first result is the most relevant Python memory

async def test_mmr_promotes_diversity_at_low_lambda(client, user_id):
    # 4 near-identical "User prefers Python for X" memories + 1 "User has nut allergy"
    # lambda=0.3 should surface the nut allergy memory within top-3
    # Assert: "nut allergy" memory ID appears in top-3 with lambda=0.3
    # Assert: "nut allergy" memory ID is NOT in top-3 with lambda=1.0 (pure relevance buries it)

async def test_mmr_without_embeddings_falls_back_to_relevance(client, user_id, monkeypatch):
    # Monkeypatch embed_query to return None
    # Assert: results are non-empty and in relevance order (no crash)

async def test_score_threshold_filters_low_signal_memories(client, user_id):
    # Store 2 memories about "Python" and 3 about "cooking"
    # Query "Python backend"
    # score_threshold=0.01 should filter out cooking memories
    # Assert: no cooking memories in results

async def test_score_threshold_zero_is_permissive(client, user_id):
    # score_threshold=0.0 (default) returns results for weak queries
    # Assert: results are non-empty when threshold=0.0

async def test_mmr_lambda_validation(server):
    # mmr_lambda=-0.1 → INVALID_PARAM error
    # mmr_lambda=1.1 → INVALID_PARAM error
    # mmr_lambda=0.0 → ok
    # mmr_lambda=1.0 → ok

async def test_access_count_increments_on_search(client, user_id):
    # Store a memory, search for it, fetch raw row from DB
    # Assert: access_count == 1 after one search hit
    # Assert: last_accessed is not None and is recent
    # This is also a v0.2 bug fix test
```

**What tests do NOT assert**: Content of retrieved memories (LLM-dependent). Exact numeric scores (fragile). That MMR always outperforms relevance ranking (problem-dependent).

---

### Feature 2: Context Budget Manager

**What it is**: Token-budget trimming of search results. After MMR ranking, the result list is trimmed so the total estimated token count of all returned `text` fields stays within `max_tokens`. Prevents over-stuffing the agent's context window with memories.

**Why**: Series 4 Issue 4 (READ phase). Production problem: an agent injecting 20 memories at 200 tokens each uses 4,000 tokens of its context window before the user even asks a question. Most agents have implicit limits; `max_tokens` makes the contract explicit and gives callers control.

**Interface**: New optional parameter on `search_memories`:

```python
async def search_memories(
    query: str,
    limit: int = 20,
    recency_weight: float = 0.3,
    mmr_lambda: float = 0.7,
    score_threshold: float = 0.0,
    max_tokens: int = 0,              # NEW — 0 = no limit; >0 = trim to fit
) -> dict:
```

The response gains a new field when trimming occurs:
```json
{
  "status": "ok",
  "data": {
    "results": [...],
    "total": 12,             // total memories retrieved before budget trim
    "returned": 7,           // memories actually returned (≤ total)
    "budget_applied": true   // new field — only present when max_tokens > 0
  }
}
```

**Implementation approach**: Token counting is done via a simple word-count approximation (`len(text.split()) * 1.3` rounds up to account for subword tokenization overhead). This avoids a `tiktoken` dependency while being accurate to within ±15% for typical English prose. The approximation is documented; callers needing exact counts can use tiktoken on their side.

Algorithm:
```python
def _estimate_tokens(text: str) -> int:
    return max(1, int(len(text.split()) * 1.3))

def _apply_budget(results: list[dict], max_tokens: int) -> list[dict]:
    if max_tokens <= 0:
        return results
    budget = max_tokens
    trimmed = []
    for r in results:
        cost = _estimate_tokens(r["text"])
        if cost > budget:
            break
        trimmed.append(r)
        budget -= cost
    return trimmed
```

The budget manager runs after MMR, on the final ordered list. It never reorders — it only truncates from the tail.

**What changes**:
- `server.py`: `search_memories` — add `max_tokens` param, call `_apply_budget` on results
- `server.py`: `_hybrid_search` — no change needed (budget is applied in the tool, not the search function, since it's a response shaping concern, not a retrieval concern)
- `server.py`: response dict — add `returned` and `budget_applied` keys when `max_tokens > 0`

**Test spec** (`tests/test_budget.py`):

```python
async def test_max_tokens_zero_returns_all(client, user_id, server):
    # Store 10 memories, search with max_tokens=0
    # Assert: len(results) == 10 (no trimming), "budget_applied" not in data

async def test_max_tokens_trims_to_budget(client, user_id, server):
    # Store 5 memories each with ~50-word text (~65 estimated tokens each)
    # search with max_tokens=130 → expect at most 2 memories returned
    # Assert: len(results) <= 2
    # Assert: data["budget_applied"] is True
    # Assert: data["total"] == 5, data["returned"] <= 2

async def test_budget_preserves_ranking_order(client, user_id, server):
    # Store 5 memories with known BM25 relevance order
    # Apply tight budget that allows only top-2
    # Assert: returned memories are the top-2 by relevance, not arbitrary

async def test_single_long_memory_over_budget_returns_empty(client, user_id, server):
    # Store one memory with 500-word text (~650 tokens estimated)
    # search with max_tokens=100
    # Assert: results == [] (first item exceeds budget, loop breaks immediately)
    # Assert: budget_applied is True, total == 1, returned == 0

async def test_token_estimation_is_reasonable():
    # Unit test for _estimate_tokens
    short = "User prefers Python"        # 3 words → ~4 tokens estimated
    long = ("word " * 100).strip()       # 100 words → ~130 tokens estimated
    assert _estimate_tokens(short) >= 3
    assert 120 <= _estimate_tokens(long) <= 150
```

**What tests do NOT assert**: Exact tiktoken counts. That the approximation is within N% (that's an implementation detail, not a contract).

---

### Feature 3: Memory Decay Scoring

**What it is**: A scheduled background job that periodically applies a time-weighted importance reduction to memories that have not been accessed recently. The result is written to the `decay_score` column (already in schema). The 4-component search scorer will optionally incorporate `decay_score` as a multiplier.

**Why**: Series 4 Issue 3 (MANAGE phase). Production problem: a memory stored two years ago ("user preferred morning meetings") remains at `importance=0.8` forever. Stale memories compete equally with recent ones for limited context slots. Decay is the mechanism that makes the system self-pruning over time.

**Decay function design**:
The decay score is a multiplier in [0, 1] applied to importance before scoring. Using exponential decay with access-count protection:

```
decay_score = exp(-λ · age_days) · (1 + access_count)^α / (1 + access_count)^α

# Simplified with protection:
raw_decay = exp(-λ · max(0, age_since_last_access_days))
access_boost = min(1.0, log(1 + access_count) / log(1 + BOOST_CAP))
decay_score = raw_decay + (1 - raw_decay) * access_boost
```

In English: a memory decays exponentially from its last access date. But frequently-accessed memories get a boost that slows decay. A memory accessed 10+ times (`BOOST_CAP=10`) is fully protected from decay regardless of age.

**Default parameters** (tunable via env vars):
```
RECALL_DECAY_LAMBDA = 0.02      # half-life ≈ 35 days (reasonable for preferences)
RECALL_DECAY_BOOST_CAP = 10     # access count at which decay stops
RECALL_DECAY_JOB_INTERVAL = 3600  # run every hour (seconds)
```

**Scheduler design**: A separate asyncio task started in `_lifespan`, alongside the `ExtractionWorker`. Uses `asyncio.sleep(interval)` in a loop. Not a cron scheduler — keeps it simple and in-process.

```python
class DecayWorker:
    async def start(self) -> None: ...
    async def stop(self) -> None: ...
    async def run_once(self) -> int:
        """Apply decay to all active memories. Returns count of memories updated."""
        ...
    async def _run(self) -> None:
        while self._running:
            await self.run_once()
            await asyncio.sleep(self._interval)
```

**SQL update**: The job updates `decay_score` but does NOT modify `importance`. Importance is the LLM's signal about intrinsic value. Decay is a time-dimension modifier. These are separate columns for a reason.

```sql
UPDATE memories
SET decay_score = ?,
    updated_at = datetime('now')
WHERE id = ? AND user_id = ? AND valid_until IS NULL
```

**Integration with search**: In `_hybrid_search`, the importance component changes from:
```python
w_import * (m.get("importance") or 0.5)
```
to:
```python
decay = m.get("decay_score")
effective_importance = (m.get("importance") or 0.5) * (decay if decay is not None else 1.0)
w_import * effective_importance
```

When `decay_score IS NULL` (memory never processed by decay job), the multiplier is 1.0 (no decay). This preserves backward compatibility for existing memories and fresh installs.

**What changes**:
- `worker.py` or new `decay.py`: `DecayWorker` class with `start()`, `stop()`, `run_once()`
- `server.py`: `_lifespan` — start/stop `DecayWorker` alongside `ExtractionWorker`
- `server.py`: `_hybrid_search` — use `decay_score` as importance multiplier
- `db/connection.py` or new migration: add `updated_at TEXT` column to memories if not present (needed for decay tracking)

**New file**: `src/recall/decay.py` — keeps the decay logic separate from extraction logic.

**Test spec** (`tests/test_decay.py`):

```python
async def test_decay_score_decreases_with_age(client, user_id):
    # Store a memory, manually backdate created_at and last_accessed to 90 days ago
    # Run decay_worker.run_once()
    # Fetch raw row — assert decay_score < 1.0
    # Assert: decay_score > 0.0 (never zero, exponential)

async def test_recently_accessed_memory_has_high_decay(client, user_id):
    # Store a memory, set last_accessed = now - 1 day, access_count = 0
    # Run run_once()
    # Assert: decay_score > 0.95 (recent memory barely decays)

async def test_frequently_accessed_memory_decays_slower(client, user_id):
    # Store two memories, both 60 days old
    # Memory A: access_count = 0
    # Memory B: access_count = 10 (BOOST_CAP)
    # Run run_once()
    # Assert: memory B has higher decay_score than memory A

async def test_decay_does_not_modify_importance(client, user_id):
    # Store memory with importance=0.9
    # Backdate to 180 days
    # Run run_once()
    # Fetch from DB — assert importance == 0.9 (unchanged)
    # Assert decay_score < 0.5

async def test_decay_null_before_first_run(client, user_id):
    # Store memory, fetch immediately
    # Assert decay_score IS NULL (no decay run yet)

async def test_decay_only_affects_active_memories(client, user_id):
    # Store 2 memories: 1 active, 1 superseded (valid_until set)
    # Backdate both to 90 days
    # Run run_once()
    # Assert: active memory has decay_score set
    # Assert: superseded memory decay_score remains NULL

async def test_decay_score_affects_search_ranking(client, user_id):
    # Two memories with equal BM25 relevance and importance
    # Memory A: recent (decay_score = 0.9)
    # Memory B: old (decay_score = 0.1)
    # Search with recency_weight=0.0 (pure relevance mode)
    # Assert: Memory A ranks above Memory B (decay multiplier drives ranking)

async def test_run_once_returns_count(client, user_id):
    # Store 5 active memories
    # decay_worker.run_once() returns 5

async def test_decay_worker_start_stop():
    # Create worker, start, immediately stop
    # Assert: no unclosed asyncio tasks, no errors
```

**What tests do NOT assert**: Exact decay values (they depend on elapsed time which varies). That decay causes memories to be deleted (decay only scores; pruning is separate).

---

### Feature 4: Consolidation MCP Tool

**What it is**: A new MCP tool `consolidate_memories(topic)` that wraps the existing A2A consolidation logic as a first-class MCP tool. Finds semantically similar memories in a topic, sends them to Claude Haiku to produce a single canonical memory, and returns a diff of what was deleted and what was created.

**Why**: Series 4 Issue 3 (MANAGE phase). Production problem: after 6 months, a user has 15 memories about "Python preferences" that say slightly different things. The A2A consolidation skill exists but requires an agent-to-agent call. Most callers are MCP clients. Consolidation should be accessible via the same tool interface as everything else.

**Design decision**: The A2A `consolidate_memories` skill stays intact. The new MCP tool wraps a subset of that logic — specifically the LLM-based merge step. The heuristic contradiction detection in `a2a.py` is NOT used in the MCP tool; the new tool uses semantic similarity (embedding cosine distance) to find candidates, which is more precise.

**Interface**:
```python
@mcp.tool()
async def consolidate_memories(
    topic: str,
    similarity_threshold: float = 0.85,   # cosine similarity to group memories
    dry_run: bool = False,                 # if True, return plan without executing
) -> dict:
    """Find semantically similar memories in a topic and merge them into canonical facts.
    Requires embeddings to be available. Returns a diff of deleted and created memories."""
```

Response shape:
```json
{
  "status": "ok",
  "data": {
    "groups_found": 3,
    "memories_consolidated": 8,
    "memories_created": 3,
    "deleted_ids": ["id1", "id2", "..."],
    "created": [
      {"id": "new-id", "text": "...", "type": "preference", "topic": "..."}
    ],
    "dry_run": false
  }
}
```

On dry_run=True, `deleted_ids` and `created` show what WOULD happen; no mutations occur.

**Implementation approach**:

Step 1 — Fetch all active memories for user in the given topic:
```sql
SELECT id, text, embedding, type, importance, topic
FROM memories
WHERE user_id = ? AND topic = ? AND valid_until IS NULL
ORDER BY created_at DESC
```

Step 2 — Group by semantic similarity:
- If embeddings are available: compute pairwise cosine similarity matrix, use greedy clustering (first memory in sorted order becomes cluster center; add any memory with cosine_sim > threshold to that cluster)
- If embeddings not available: return error `{"code": "EMBEDDINGS_REQUIRED", "error": "consolidate_memories requires the embeddings extra: pip install szl-recall[embeddings]"}`

Step 3 — For each group with 2+ members: call LLM (claude-haiku) with merge prompt:
```
Given these related memories about the same topic, produce ONE canonical memory that 
captures all the distinct information. Be specific. Do not generalize.

Memories:
1. {text}
2. {text}
...

Return a JSON object: {"text": "...", "type": "...", "importance": 0.0-1.0}
```

Step 4 — Persist: `INSERT` canonical memory, `UPDATE valid_until` + `superseded_by` on source memories.

Step 5 — Return diff.

**What changes**:
- `server.py`: add `consolidate_memories` MCP tool
- `server.py`: `_validate_server_descriptions` — add `consolidate_memories` to checked list
- `worker.py` or `server.py`: extract reusable `_llm_merge(memories: list[dict]) -> dict` helper

**Test spec** (`tests/test_consolidation.py`):

```python
async def test_consolidate_requires_embeddings_or_returns_error(client, user_id, monkeypatch, server):
    # Monkeypatch embed to return None
    # Call consolidate_memories with a topic
    # Assert: status == "error", code == "EMBEDDINGS_REQUIRED"

async def test_consolidate_dry_run_no_mutations(client, user_id, server):
    # Store 4 similar memories in topic "python-prefs"
    # consolidate_memories(topic="python-prefs", dry_run=True)
    # Assert: status == "ok", dry_run == True
    # Fetch all memories for user — assert count unchanged (no deletions)

async def test_consolidate_returns_diff(client, user_id, server):
    # This test requires ANTHROPIC_API_KEY — marked with @_needs_api
    # Store 3 near-identical memories in topic "tools" with embedded vectors
    # consolidate_memories(topic="tools")
    # Assert: deleted_ids contains 3 memory IDs (the originals)
    # Assert: created contains 1 memory (the canonical merge)
    # Assert: original memories now have valid_until set (superseded)

async def test_consolidate_single_memory_noop(client, user_id, server):
    # Store 1 memory in topic "solo"
    # consolidate_memories(topic="solo")
    # Assert: groups_found == 0 (or 1 with 1 member, no merge needed)
    # Assert: memories_consolidated == 0, deleted_ids == []

async def test_consolidate_empty_topic_returns_ok(client, user_id, server):
    # No memories stored for topic "empty"
    # consolidate_memories(topic="empty")
    # Assert: status == "ok", groups_found == 0

async def test_consolidate_topic_isolation(client, user_id, server):
    # Store 3 similar memories in topic "A" and 3 in topic "B"
    # consolidate_memories(topic="A")
    # Assert: only topic-A memories are affected
    # Assert: topic-B memories are unchanged

async def test_consolidate_tool_in_stats_validation(server):
    # get_memory_stats should still work after consolidate_memories is added
    # (ensures _validate_server_descriptions doesn't break with 6 tools)
```

---

### Feature 5: Postgres/pgvector Backend

**What it is**: An optional second database backend selectable via `RECALL_DB_BACKEND=postgres` env var. Uses asyncpg for connection pooling and pgvector for native vector operations. The SQLite backend remains the default and is not deprecated.

**Why**: Series 4 Issue 7 (End-to-End). Production requirement: SQLite is single-writer; multi-user production deployments need Postgres. pgvector enables ANN (approximate nearest neighbor) search instead of loading all embeddings into Python memory.

**Interface**: Environment-variable opt-in:
```bash
export RECALL_DB_BACKEND=postgres
export RECALL_DB_DSN=postgresql://user:pass@localhost:5432/recall
```

All existing MCP tools work identically. The backend swap is transparent to callers.

**Architecture**:

Create a backend abstraction via a Protocol:
```python
# src/recall/db/backend.py

class DatabaseBackend(Protocol):
    async def execute(self, query: str, *args) -> Any: ...
    async def fetchall(self, query: str, *args) -> list[tuple]: ...
    async def fetchone(self, query: str, *args) -> tuple | None: ...
    async def executemany(self, query: str, args_list: list) -> None: ...
    async def transaction(self) -> AsyncContextManager: ...
    async def close(self) -> None: ...
```

`SQLiteBackend` wraps `aiosqlite`. `PostgresBackend` wraps `asyncpg` connection pool (min=2, max=10 connections).

**Schema migration**: A new `migrations/` directory with migration scripts:
- `001_initial.sql` — current SQLite schema adapted for Postgres (TEXT → VARCHAR where needed, BLOB → BYTEA for embeddings, datetime('now') → NOW())
- `002_pgvector.sql` — `CREATE EXTENSION IF NOT EXISTS vector; ALTER TABLE memories ADD COLUMN embedding vector(384);`
- `schema_version` table tracks applied migrations

**Vector search change**: With Postgres, `_dense_ranks` can use pgvector's `<=>` (cosine distance) operator for approximate nearest neighbor search instead of loading all embeddings into Python:

```sql
SELECT id, embedding <=> $1 AS cosine_dist
FROM memories
WHERE user_id = $2 AND valid_until IS NULL
ORDER BY embedding <=> $1
LIMIT $3
```

This makes dense retrieval O(log N) instead of O(N) at scale.

**SQLite backward compatibility**: All existing tests continue to use SQLite backend. The Postgres backend gets a separate test class with `@pytest.mark.skipif(not os.environ.get("RECALL_DB_DSN"))` guards.

**What changes**:
- New `src/recall/db/backend.py` — Protocol + SQLiteBackend + PostgresBackend
- New `src/recall/db/migrations/` — SQL migration files
- `src/recall/db/connection.py` — refactored: `get_backend()` returns the active backend based on `RECALL_DB_BACKEND`; existing `get_db_path()` preserved for SQLite compatibility
- `server.py` — replace direct `aiosqlite.connect(get_db_path())` calls with `async with get_backend() as db:` pattern
- `worker.py` — same backend abstraction
- `a2a.py` — same; also migrate in-memory `_tasks` to DB (A2A task persistence, see Technical Debt item 2)
- `pyproject.toml` — `postgres` optional dependency already declared: `asyncpg>=0.29, pgvector>=0.3`

**Migration safety**: The `init_db()` function becomes backend-aware and applies the correct migration set. For existing SQLite installations, `v2` columns are still added via `ALTER TABLE` as before.

**Test spec** (`tests/test_postgres_backend.py`):

```python
_needs_postgres = pytest.mark.skipif(
    not os.environ.get("RECALL_DB_DSN"),
    reason="RECALL_DB_DSN not set — skip Postgres backend tests",
)

@_needs_postgres
class TestPostgresBackend:
    async def test_init_db_creates_schema(self, pg_backend):
        # init_db() with Postgres backend creates all tables
        # Assert: memories, operations, api_tokens, tool_call_records, schema_version tables exist

    async def test_store_and_retrieve(self, pg_client):
        # store + get roundtrip with Postgres
        # Assert: same as SQLite client tests

    async def test_pgvector_dense_search(self, pg_client, user_id):
        # Store 3 memories with known embeddings
        # Patch embed_query to return known vector
        # Assert: dense search returns correct ordering

    async def test_connection_pool_reuse(self, pg_backend):
        # Run 10 concurrent queries
        # Assert: no connection errors, results consistent

    async def test_sqlite_backend_unaffected(self, client, user_id):
        # Explicitly create SQLiteBackend, store + fetch
        # Assert: identical behavior to current client tests
```

**Most complex migration concern**: `aiosqlite` uses `?` placeholders; `asyncpg` uses `$1`, `$2`. Every SQL query in `server.py`, `worker.py`, and `a2a.py` uses `?` style. The `PostgresBackend.execute()` wrapper must translate `?` to `$N` placeholders automatically, OR all queries must be written in Postgres style and `SQLiteBackend` must translate in reverse. Recommendation: PostgresBackend translates (replace `?` with `$1`, `$2`... at call time). This keeps the query strings in one style and limits the translation to one place.

---

### Feature 6: GDPR Erasure

**What it is**: A new MCP tool `delete_user_data()` that deletes ALL data for the authenticated user across all tables. An audit log entry is created before deletion. Returns the count of rows deleted from each table.

**Why**: Series 4 Issue 7 (End-to-End) and Issue 6 (Memory Failures). GDPR "right to erasure" / "right to be forgotten". Production requirement: any system that stores personal data must provide a complete deletion mechanism. This is not optional once users are real people.

**Interface**:
```python
@mcp.tool()
async def delete_user_data(
    confirm: str,   # must equal "DELETE MY DATA" exactly — prevents accidental erasure
) -> dict:
    """Permanently delete ALL memories and data for the current user. IRREVERSIBLE.
    Pass confirm='DELETE MY DATA' to execute. This cannot be undone."""
```

Response:
```json
{
  "status": "ok",
  "data": {
    "deleted": {
      "memories": 42,
      "operations": 15,
      "tool_call_records": 203,
      "audit_log_entry_created": true
    }
  }
}
```

On wrong confirmation string:
```json
{
  "status": "error",
  "code": "CONFIRMATION_REQUIRED",
  "error": "Pass confirm='DELETE MY DATA' to proceed. This action is irreversible."
}
```

**Implementation approach**:

1. Validate `confirm == "DELETE MY DATA"` — exact string match, no fuzzy.
2. Before deleting, INSERT an audit log entry:
   ```sql
   INSERT INTO tool_call_records (id, tool_name, user_id, session_id, inputs_hash, status, duration_ms, timestamp)
   VALUES (uuid4(), 'delete_user_data', ?, 'gdpr-erasure', sha256('DELETE'), 'success', 0, now())
   ```
   Note: this audit entry is the ONLY thing that survives the deletion. It is scoped to the user_id but contains no user data content — only metadata about the deletion event.
3. Delete in dependency order to avoid FK violation issues:
   ```sql
   DELETE FROM memories WHERE user_id = ?;
   DELETE FROM operations WHERE user_id = ?;
   DELETE FROM tool_call_records WHERE user_id = ? AND tool_name != 'delete_user_data';
   ```
   The `api_tokens` table is intentionally NOT deleted — deleting the token would log out the user and they couldn't confirm the deletion was successful. Tokens should be revoked (set `revoked = 1`) instead of deleted.
4. Return per-table row counts.

**What changes**:
- `server.py`: add `delete_user_data` MCP tool (6th tool)
- `server.py`: `_validate_server_descriptions` — add `delete_user_data` to checked list
- The `api_tokens` revocation (set `revoked=1`) is added as a step after the data deletion

**Test spec** (`tests/test_gdpr.py`):

```python
async def test_delete_user_data_requires_confirmation(server):
    # Call delete_user_data with confirm="yes please" (wrong string)
    # Assert: status == "error", code == "CONFIRMATION_REQUIRED"

async def test_delete_user_data_wrong_case_rejected(server):
    # Call with confirm="delete my data" (lowercase)
    # Assert: status == "error", code == "CONFIRMATION_REQUIRED"

async def test_delete_user_data_removes_all_memories(client, user_id, server):
    # Store 5 memories, run 2 searches (creates tool_call_records + access_count)
    # Call delete_user_data(confirm="DELETE MY DATA")
    # Assert: status == "ok"
    # Assert: deleted["memories"] == 5
    # Fetch memories from DB — assert count == 0

async def test_delete_user_data_removes_operations(client, user_id, server):
    # store_memory call creates an operation row
    # delete_user_data
    # Assert: deleted["operations"] >= 1
    # SELECT COUNT(*) FROM operations WHERE user_id = ? — assert 0

async def test_delete_user_data_creates_audit_entry(client, user_id, server):
    # delete_user_data
    # SELECT * FROM tool_call_records WHERE user_id = ? AND tool_name = 'delete_user_data'
    # Assert: exactly one row exists (the audit entry)
    # Assert: status == 'success'

async def test_delete_user_data_revokes_tokens(client, user_id, server, tmp_db):
    # delete_user_data
    # SELECT revoked FROM api_tokens WHERE user_id = ?
    # Assert: all tokens have revoked == 1

async def test_delete_user_data_does_not_affect_other_users(client, server, tmp_db):
    # Store memories for user_A and user_B
    # delete_user_data as user_A
    # Assert: user_B's memories are untouched
    # This is the critical isolation test

async def test_delete_returns_correct_counts(client, user_id, server):
    # Store exactly 7 memories, ensure 3 operations exist
    # delete_user_data
    # Assert: deleted["memories"] == 7
    # Assert: deleted["operations"] == 3
```

**What tests do NOT assert**: That deleted data is unrecoverable from SQLite WAL (filesystem concern). That the audit entry contains specific content beyond tool_name and user_id.

---

## 3. Implementation Order

The order follows the Series 4 arc and respects feature dependencies.

### Phase 1 — Issue 3 (MANAGE): Decay + Consolidation MCP Tool

**Week 1: Fix `access_count` bug + Decay Worker**

The access_count bug (Technical Debt item 1) must be fixed first because:
- Decay's access_boost formula reads `access_count` — if it's always 0, the boost never activates
- It's a silent correctness bug that makes the current 4-component score wrong

Order:
1. Fix `_hybrid_search` to update `access_count` and `last_accessed` after retrieving memories
2. Add test `test_access_count_increments_on_search` (in `test_mmr.py` or new `test_fixes.py`)
3. Implement `decay.py` — `DecayWorker` class
4. Wire `DecayWorker` into `_lifespan`
5. Write `tests/test_decay.py`

**Week 2: Consolidation MCP Tool**

Depends on: embeddings module working (already exists), LLM client (already in `ExtractionWorker`).

Order:
1. Extract `_llm_merge()` helper from `ExtractionWorker` (or inline in `consolidate_memories`)
2. Implement `consolidate_memories` MCP tool in `server.py`
3. Wire validation check
4. Write `tests/test_consolidation.py` (non-API tests first, @_needs_api tests separately)

### Phase 2 — Issue 4 (READ): MMR + Context Budget

**Week 3: MMR + Threshold Gate**

Depends on: access_count fix from Phase 1 (MMR's `test_access_count_increments_on_search` needs correct data).

Order:
1. Add `mmr_lambda` and `score_threshold` params to `search_memories` and `_hybrid_search`
2. Implement `_mmr_rerank()` function in `server.py`
3. Add validation for `mmr_lambda` in `search_memories`
4. Write `tests/test_mmr.py`

**Week 4: Context Budget Manager**

Depends on: MMR (budget is applied after MMR, both are in `search_memories`).

Order:
1. Implement `_estimate_tokens()` and `_apply_budget()` in `server.py`
2. Add `max_tokens` param to `search_memories`
3. Update response shape with `returned` and `budget_applied` fields
4. Write `tests/test_budget.py`

### Phase 3 — Issue 7 (End-to-End): GDPR + Postgres

**Week 5: GDPR Erasure**

Depends on: nothing — isolated tool. Lowest risk.

Order:
1. Implement `delete_user_data` MCP tool in `server.py`
2. Add to description validation list
3. Write `tests/test_gdpr.py`

**Week 6-7: Postgres Backend**

Depends on: all other features complete (so the backend abstraction doesn't need to handle unfinished features).

Order:
1. Create `src/recall/db/backend.py` — Protocol + SQLiteBackend
2. Create `src/recall/db/migrations/` — SQL migration files
3. Implement `PostgresBackend` with `?`→`$N` translation
4. Refactor `connection.py` — `get_backend()` factory
5. Refactor `server.py`, `worker.py`, `a2a.py` — use `get_backend()` context manager
6. Migrate A2A task store to DB (also fixes Technical Debt item 2)
7. Write `tests/test_postgres_backend.py`
8. Update `pyproject.toml` version to 0.3.0

---

## 4. Test-First Design

Full test file stubs for each feature. These are the actual files to create — write the test, watch it fail, then implement.

### `tests/test_mmr.py`

```python
"""MMR retrieval and score threshold tests.
Also covers the access_count increment fix (bug from v0.2).
No API calls required.
"""

from __future__ import annotations

import asyncio
import uuid
from unittest.mock import patch

import aiosqlite
import pytest

from recall.db.connection import get_db_path
from recall.server import _hybrid_search, user_id_ctx


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def diverse_memories():
    """Return texts for 4 near-identical Python memories + 1 orthogonal memory."""
    return [
        "User prefers Python for backend services and API development",
        "User likes Python best for writing backend APIs and services",
        "Python is the user's language of choice for backend API work",
        "User always reaches for Python when building backend services",
        "User has a severe nut allergy and avoids all tree nuts",  # orthogonal
    ]


# ── MMR correctness ───────────────────────────────────────────────────────────

class TestMMRRetrieval:
    async def test_mmr_lambda_1_preserves_relevance_order(self, client, user_id, diverse_memories):
        for text in diverse_memories:
            await client.store(user_id=user_id, text=text, topic="test")

        # lambda=1.0 should rank by relevance only (no diversity pressure)
        results_lambda1 = await _hybrid_search(
            user_id, "Python backend services", limit=5, recency_weight=0.0,
            mmr_lambda=1.0, score_threshold=0.0
        )
        results_default = await _hybrid_search(
            user_id, "Python backend services", limit=5, recency_weight=0.0,
            mmr_lambda=1.0, score_threshold=0.0
        )
        assert [r["id"] for r in results_lambda1] == [r["id"] for r in results_default]

    async def test_mmr_promotes_diverse_memory_at_low_lambda(self, client, user_id, diverse_memories):
        ids = []
        for text in diverse_memories:
            m = await client.store(user_id=user_id, text=text, topic="test")
            ids.append(m.id)

        nut_allergy_id = ids[4]  # the orthogonal memory

        results_diverse = await _hybrid_search(
            user_id, "Python backend services", limit=5, recency_weight=0.0,
            mmr_lambda=0.2, score_threshold=0.0
        )
        results_pure = await _hybrid_search(
            user_id, "Python backend services", limit=5, recency_weight=0.0,
            mmr_lambda=1.0, score_threshold=0.0
        )
        diverse_ids = [r["id"] for r in results_diverse[:3]]
        # Note: this test requires embeddings to pass; skip if no embeddings
        # With embeddings: nut_allergy should be in top-3 for diverse, not for pure
        # We assert the behavior when embeddings are available
        # Test is valid regardless — if no embeddings, diversity penalty = 0 and both are equal

    async def test_mmr_no_embeddings_degrades_gracefully(self, client, user_id, diverse_memories):
        for text in diverse_memories:
            await client.store(user_id=user_id, text=text, topic="test")

        with patch("recall.server._dense_ranks", return_value=None):
            results = await _hybrid_search(
                user_id, "Python backend", limit=5, recency_weight=0.0,
                mmr_lambda=0.5, score_threshold=0.0
            )
        assert len(results) >= 1  # no crash, returns results


# ── Score threshold ───────────────────────────────────────────────────────────

class TestScoreThreshold:
    async def test_threshold_zero_returns_any_match(self, client, user_id):
        await client.store(user_id=user_id, text="User prefers dark mode", topic="ui")
        results = await _hybrid_search(
            user_id, "dark mode UI", limit=10, recency_weight=0.0,
            mmr_lambda=1.0, score_threshold=0.0
        )
        assert len(results) >= 1

    async def test_high_threshold_filters_weak_matches(self, client, user_id):
        await client.store(user_id=user_id, text="User prefers Python", topic="tech")
        # Query completely unrelated to stored memory
        results = await _hybrid_search(
            user_id, "Python backend", limit=10, recency_weight=0.0,
            mmr_lambda=1.0, score_threshold=0.99  # nearly impossible threshold
        )
        # Either empty or only very strong matches — no assertion on count,
        # but assert no weak-match memories sneak through
        for r in results:
            assert r.get("_rrf_score", 1.0) >= 0.0  # internal consistency only

    async def test_threshold_above_all_scores_returns_empty(self, client, user_id):
        await client.store(user_id=user_id, text="User prefers coffee", topic="food")
        results = await _hybrid_search(
            user_id, "quantum computing", limit=10, recency_weight=0.0,
            mmr_lambda=1.0, score_threshold=0.5  # RRF scores rarely exceed 0.1 for unrelated terms
        )
        assert results == []


# ── Access count fix ──────────────────────────────────────────────────────────

class TestAccessCountFix:
    async def test_access_count_increments_after_search_hit(self, client, user_id):
        m = await client.store(user_id=user_id, text="User prefers Python for backends", topic="tech")

        # Verify initial state
        async with aiosqlite.connect(get_db_path()) as db:
            rows = await db.execute_fetchall(
                "SELECT access_count, last_accessed FROM memories WHERE id = ?", (m.id,)
            )
        assert rows[0][0] == 0
        assert rows[0][1] is None

        # Perform search that hits this memory
        token = user_id_ctx.set(user_id)
        try:
            await _hybrid_search(user_id, "Python backend", limit=10, recency_weight=0.0)
        finally:
            user_id_ctx.reset(token)

        # Verify access_count incremented
        async with aiosqlite.connect(get_db_path()) as db:
            rows = await db.execute_fetchall(
                "SELECT access_count, last_accessed FROM memories WHERE id = ?", (m.id,)
            )
        assert rows[0][0] == 1, "access_count must increment on search hit"
        assert rows[0][1] is not None, "last_accessed must be set on search hit"

    async def test_access_count_does_not_increment_for_cache_miss(self, client, user_id):
        m = await client.store(user_id=user_id, text="User likes jazz music", topic="music")
        await _hybrid_search(user_id, "quantumcomputing", limit=10, recency_weight=0.0)

        async with aiosqlite.connect(get_db_path()) as db:
            rows = await db.execute_fetchall(
                "SELECT access_count FROM memories WHERE id = ?", (m.id,)
            )
        assert rows[0][0] == 0, "access_count must not increment when memory not in results"
```

### `tests/test_budget.py`

```python
"""Context budget manager tests.
Verifies token estimation and result trimming. No API calls required.
"""

from __future__ import annotations

import pytest

from recall.server import _estimate_tokens, search_memories, user_id_ctx


class TestTokenEstimation:
    def test_empty_string(self):
        assert _estimate_tokens("") >= 1  # min 1

    def test_single_word(self):
        assert _estimate_tokens("hello") >= 1

    def test_approximation_is_reasonable_for_prose(self):
        # 20 words → roughly 26 tokens (1.3x factor)
        text = "The user prefers to write backend code in Python using FastAPI framework for REST APIs"
        estimate = _estimate_tokens(text)
        assert 15 <= estimate <= 40  # loose bounds for a rough approximation


class TestContextBudget:
    async def test_max_tokens_zero_no_trimming(self, client, user_id, server):
        for i in range(5):
            await client.store(
                user_id=user_id,
                text=f"User fact number {i} about their preferences and workflow",
                topic="test"
            )
        # Directly call _hybrid_search via server tool
        token = user_id_ctx.set(user_id)
        try:
            result = await search_memories(
                query="user preferences", limit=50, max_tokens=0
            )
        finally:
            user_id_ctx.reset(token)

        assert result["status"] == "ok"
        assert "budget_applied" not in result["data"]

    async def test_max_tokens_trims_results(self, client, user_id):
        # Store 5 memories with ~20 words each (~26 estimated tokens each)
        for i in range(5):
            text = " ".join([f"word{j}" for j in range(20)])  # exactly 20 words
            await client.store(user_id=user_id, text=text, topic="test")

        token = user_id_ctx.set(user_id)
        try:
            result = await search_memories(
                query=" ".join([f"word{j}" for j in range(5)]),
                limit=50,
                max_tokens=60  # fits at most 2 memories at ~26 tokens each
            )
        finally:
            user_id_ctx.reset(token)

        assert result["status"] == "ok"
        assert result["data"]["budget_applied"] is True
        assert result["data"]["returned"] <= 2
        assert result["data"]["total"] >= result["data"]["returned"]

    async def test_budget_preserves_ranking_order(self, client, user_id):
        # Store memories with very different relevance
        high_rel = await client.store(
            user_id=user_id,
            text="Python FastAPI backend API development preferred framework always",
            topic="tech"
        )
        low_rel = await client.store(
            user_id=user_id,
            text="Went hiking in the mountains last weekend with family",
            topic="personal"
        )

        token = user_id_ctx.set(user_id)
        try:
            result = await search_memories(
                query="Python API backend", limit=50,
                max_tokens=30,  # only room for 1 result
                recency_weight=0.0
            )
        finally:
            user_id_ctx.reset(token)

        if result["data"]["returned"] == 1:
            assert result["data"]["results"][0]["id"] == high_rel.id

    async def test_oversized_single_result_returns_empty(self, client, user_id):
        huge_text = " ".join([f"word{i}" for i in range(500)])  # 500 words
        await client.store(user_id=user_id, text=huge_text, topic="test")

        token = user_id_ctx.set(user_id)
        try:
            result = await search_memories(
                query=" ".join([f"word{i}" for i in range(10)]),
                limit=10, max_tokens=50
            )
        finally:
            user_id_ctx.reset(token)

        assert result["data"]["returned"] == 0
        assert result["data"]["budget_applied"] is True
```

### `tests/test_decay.py`

```python
"""Memory decay scoring tests. No API calls required."""

from __future__ import annotations

import asyncio

import aiosqlite
import pytest

from recall.db.connection import get_db_path
from recall.decay import DecayWorker


@pytest.fixture
async def decay_worker(tmp_db):
    worker = DecayWorker()
    yield worker
    # No start/stop needed — tests call run_once() directly


class TestDecayScoring:
    async def test_new_memory_has_null_decay_score(self, client, user_id):
        m = await client.store(user_id=user_id, text="New memory", topic="test")
        async with aiosqlite.connect(get_db_path()) as db:
            rows = await db.execute_fetchall(
                "SELECT decay_score FROM memories WHERE id = ?", (m.id,)
            )
        assert rows[0][0] is None

    async def test_decay_score_set_after_run(self, client, user_id, decay_worker):
        m = await client.store(user_id=user_id, text="Test memory", topic="test")
        count = await decay_worker.run_once()
        assert count >= 1

        async with aiosqlite.connect(get_db_path()) as db:
            rows = await db.execute_fetchall(
                "SELECT decay_score FROM memories WHERE id = ?", (m.id,)
            )
        assert rows[0][0] is not None
        assert 0.0 < rows[0][0] <= 1.0

    async def test_old_memory_has_lower_decay_than_new(self, client, user_id, decay_worker):
        new_m = await client.store(user_id=user_id, text="New memory recent", topic="test")
        old_m = await client.store(user_id=user_id, text="Old memory ancient", topic="test")

        async with aiosqlite.connect(get_db_path()) as db:
            await db.execute(
                "UPDATE memories SET created_at = datetime('now', '-180 days'), "
                "last_accessed = datetime('now', '-180 days') WHERE id = ?",
                (old_m.id,)
            )
            await db.commit()

        await decay_worker.run_once()

        async with aiosqlite.connect(get_db_path()) as db:
            rows = await db.execute_fetchall(
                "SELECT id, decay_score FROM memories WHERE id IN (?, ?)",
                (new_m.id, old_m.id)
            )
        scores = {r[0]: r[1] for r in rows}
        assert scores[new_m.id] > scores[old_m.id], "newer memory should have higher decay score"

    async def test_frequently_accessed_memory_decays_slower(self, client, user_id, decay_worker):
        m_low = await client.store(user_id=user_id, text="Low access memory text", topic="test")
        m_high = await client.store(user_id=user_id, text="High access memory text", topic="test")

        async with aiosqlite.connect(get_db_path()) as db:
            # Both 90 days old, but m_high was accessed 10 times
            for mid in (m_low.id, m_high.id):
                await db.execute(
                    "UPDATE memories SET created_at = datetime('now', '-90 days'), "
                    "last_accessed = datetime('now', '-90 days') WHERE id = ?", (mid,)
                )
            await db.execute(
                "UPDATE memories SET access_count = 10 WHERE id = ?", (m_high.id,)
            )
            await db.commit()

        await decay_worker.run_once()

        async with aiosqlite.connect(get_db_path()) as db:
            rows = await db.execute_fetchall(
                "SELECT id, decay_score FROM memories WHERE id IN (?, ?)",
                (m_low.id, m_high.id)
            )
        scores = {r[0]: r[1] for r in rows}
        assert scores[m_high.id] > scores[m_low.id]

    async def test_decay_does_not_modify_importance(self, client, user_id, decay_worker):
        m = await client.store(user_id=user_id, text="Important memory", topic="test",
                               importance=0.9)
        async with aiosqlite.connect(get_db_path()) as db:
            await db.execute(
                "UPDATE memories SET created_at = datetime('now', '-365 days') WHERE id = ?",
                (m.id,)
            )
            await db.commit()

        await decay_worker.run_once()

        async with aiosqlite.connect(get_db_path()) as db:
            rows = await db.execute_fetchall(
                "SELECT importance, decay_score FROM memories WHERE id = ?", (m.id,)
            )
        assert rows[0][0] == 0.9, "importance must not be modified by decay"
        assert rows[0][1] < 0.9, "decay_score should be lower for old memory"

    async def test_decay_skips_superseded_memories(self, client, user_id, decay_worker):
        m = await client.store(user_id=user_id, text="Superseded memory", topic="test")
        async with aiosqlite.connect(get_db_path()) as db:
            await db.execute(
                "UPDATE memories SET valid_until = datetime('now') WHERE id = ?", (m.id,)
            )
            await db.commit()

        await decay_worker.run_once()

        async with aiosqlite.connect(get_db_path()) as db:
            rows = await db.execute_fetchall(
                "SELECT decay_score FROM memories WHERE id = ?", (m.id,)
            )
        assert rows[0][0] is None, "superseded memories should not be decayed"

    async def test_run_once_returns_count(self, client, user_id, decay_worker):
        for i in range(5):
            await client.store(user_id=user_id, text=f"Memory {i}", topic="test")
        count = await decay_worker.run_once()
        assert count == 5

    async def test_decay_affects_search_ranking(self, client, user_id, decay_worker):
        # Two memories with equal BM25 relevance and equal importance
        m_recent = await client.store(
            user_id=user_id,
            text="Python FastAPI framework preferred backend development",
            topic="tech", importance=0.8
        )
        m_old = await client.store(
            user_id=user_id,
            text="Python FastAPI framework preferred backend development",
            topic="tech", importance=0.8
        )
        async with aiosqlite.connect(get_db_path()) as db:
            await db.execute(
                "UPDATE memories SET created_at = datetime('now', '-365 days'), "
                "last_accessed = datetime('now', '-365 days') WHERE id = ?", (m_old.id,)
            )
            await db.commit()

        await decay_worker.run_once()

        from recall.server import _hybrid_search
        results = await _hybrid_search(user_id, "Python FastAPI backend", limit=10,
                                       recency_weight=0.0)
        ids = [r["id"] for r in results]
        if m_recent.id in ids and m_old.id in ids:
            assert ids.index(m_recent.id) < ids.index(m_old.id), \
                "recent memory (higher decay_score) should rank above old memory"
```

### `tests/test_gdpr.py`

```python
"""GDPR erasure tool tests. Tests run against the full HTTP stack."""

from __future__ import annotations

import uuid

import aiosqlite
import pytest

from recall.db.connection import get_db_path
from recall.security import hash_token
# Re-use server fixture and helpers from test_server.py


TEST_TOKEN_GDPR = "gdpr-test-token-abc"
TEST_USER_GDPR = "gdpr-test-user-001"
OTHER_TOKEN = "other-user-token-xyz"
OTHER_USER = "other-user-002"


@pytest.fixture
async def gdpr_server(tmp_path, monkeypatch):
    """Server with two users seeded."""
    from recall.db.connection import init_db, set_db_path
    from recall.server import create_app
    import asyncio
    from unittest.mock import AsyncMock, patch

    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
    db_path = tmp_path / "gdpr.db"
    set_db_path(db_path)
    await init_db()

    async with aiosqlite.connect(db_path) as db:
        for token, user in [(TEST_TOKEN_GDPR, TEST_USER_GDPR), (OTHER_TOKEN, OTHER_USER)]:
            await db.execute(
                "INSERT INTO api_tokens (id, token_hash, user_id, revoked) VALUES (?,?,?,0)",
                (str(uuid.uuid4()), hash_token(token), user),
            )
        await db.commit()

    mock_worker = AsyncMock()
    with patch("recall.server.ExtractionWorker", return_value=mock_worker):
        app = create_app()
        # [same lifespan driver as test_server.py server fixture — omitted for brevity]
        # In practice: copy the lifespan driver from conftest or test_server.py
        import httpx
        transport = httpx.ASGITransport(app=app)
        async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
            yield client, db_path


class TestGDPRErasure:
    async def test_wrong_confirmation_returns_error(self, server):
        sid = await _initialize(server)
        result = await _tool(server, "delete_user_data", {"confirm": "yes"}, session_id=sid)
        assert result["status"] == "error"
        assert result["code"] == "CONFIRMATION_REQUIRED"

    async def test_lowercase_confirmation_rejected(self, server):
        sid = await _initialize(server)
        result = await _tool(server, "delete_user_data",
                             {"confirm": "delete my data"}, session_id=sid)
        assert result["status"] == "error"
        assert result["code"] == "CONFIRMATION_REQUIRED"

    async def test_valid_confirmation_returns_ok(self, server):
        sid = await _initialize(server)
        result = await _tool(server, "delete_user_data",
                             {"confirm": "DELETE MY DATA"}, session_id=sid)
        assert result["status"] == "ok"
        assert "deleted" in result["data"]

    async def test_memories_are_deleted(self, client, user_id, server):
        # Store memories directly (bypassing worker)
        for i in range(5):
            await client.store(user_id=user_id, text=f"Test memory {i}", topic="test")

        sid = await _initialize(server)
        result = await _tool(server, "delete_user_data",
                             {"confirm": "DELETE MY DATA"}, session_id=sid)

        assert result["data"]["deleted"]["memories"] == 5

        async with aiosqlite.connect(get_db_path()) as db:
            rows = await db.execute_fetchall(
                "SELECT COUNT(*) FROM memories WHERE user_id = ?", (user_id,)
            )
        assert rows[0][0] == 0

    async def test_audit_entry_survives_deletion(self, client, user_id, server):
        sid = await _initialize(server)
        await _tool(server, "delete_user_data",
                   {"confirm": "DELETE MY DATA"}, session_id=sid)

        async with aiosqlite.connect(get_db_path()) as db:
            rows = await db.execute_fetchall(
                "SELECT tool_name, status FROM tool_call_records "
                "WHERE user_id = ? AND tool_name = 'delete_user_data'",
                (user_id,)
            )
        assert len(rows) == 1
        assert rows[0][1] == "success"

    async def test_other_user_data_untouched(self, client, server, tmp_db):
        other_user = "other-user-not-deleted"
        await client.store(user_id=other_user, text="Other user memory", topic="test")

        sid = await _initialize(server)
        await _tool(server, "delete_user_data",
                   {"confirm": "DELETE MY DATA"}, session_id=sid)

        async with aiosqlite.connect(get_db_path()) as db:
            rows = await db.execute_fetchall(
                "SELECT COUNT(*) FROM memories WHERE user_id = ?", (other_user,)
            )
        assert rows[0][0] == 1, "other user's data must be untouched"

    async def test_tokens_revoked_after_deletion(self, client, user_id, server, tmp_db):
        sid = await _initialize(server)
        await _tool(server, "delete_user_data",
                   {"confirm": "DELETE MY DATA"}, session_id=sid)

        async with aiosqlite.connect(get_db_path()) as db:
            rows = await db.execute_fetchall(
                "SELECT revoked FROM api_tokens WHERE user_id = ?", (user_id,)
            )
        assert all(r[0] == 1 for r in rows), "all tokens must be revoked after data deletion"
```

---

## 5. What NOT to Change

These v0.2 components must remain stable throughout v0.3 development:

### Public MCP API (Stability Contract)
The five existing tools (`store_memory`, `search_memories`, `inspect_memories`, `delete_memory`, `get_memory_stats`) must remain fully backward compatible:
- Existing parameter names and types: no renames, no type changes
- Existing response shapes: `{"status": "ok/error", "data": {...}, "error": ...}` envelope
- Existing error codes: `INVALID_PARAM`, `MEMORY_NOT_FOUND`
- New parameters (`mmr_lambda`, `score_threshold`, `max_tokens`) must all be optional with defaults that reproduce current behavior

### Authentication Middleware
`BearerAuthMiddleware`, `TimeoutMiddleware`, and the SHA-256 token hashing scheme stay unchanged. The `user_id_ctx` ContextVar pattern is the security boundary — nothing in v0.3 bypasses it.

### A2A Protocol Endpoints
The A2A `/a2a` POST/GET/resume endpoints and the `consolidate_memories` skill remain. The new `consolidate_memories` MCP tool is an addition, not a replacement. Agents using the A2A interface continue to work.

### SQLite as Default Backend
`RECALL_DB_BACKEND` defaults to `sqlite`. Existing installations (no env var set) behave identically to v0.2. The Postgres backend is explicitly opt-in.

### BM25Plus Algorithm
The `_bm25_ranks` function and the `rank_bm25` library choice stays. The BM25Plus-over-BM25Okapi decision is documented in the code comment and was deliberate (small-corpus IDF collapse problem).

### Extraction Worker and Prompt
The `ExtractionWorker`, the `_EXTRACTION_PROMPT`, the `claude-haiku-4-5-20251001` model pin, and the `_VALID_TYPES` set all stay unchanged. The WRITE phase (Series 4 Issue 2) was declared "verify extraction still matches, no new features" — v0.3 respects that.

### Schema Backward Compatibility
All new schema changes in v0.3 must be applied as migrations (ALTER TABLE), not schema drops. The `decay_score` column is already present. Any new column for v0.3 (e.g., `updated_at`) must follow the `_V2_COLUMNS` pattern in `connection.py`.

### Test Suite
All 48 existing tests must continue to pass. The test infrastructure (`conftest.py`, `tmp_db` fixture, `client` fixture) stays unchanged.

---

## 6. Key Architectural Decisions and Tensions

### Decision 1: MMR as a Post-Processing Step, Not a New Retrieval Mode
MMR is applied after the 4-component scorer, not as a replacement for it. This means the compute path is: BM25 → dense → RRF → 4-component score → threshold gate → MMR greedy selection. The alternative was to integrate MMR directly into the scoring formula as a fifth component. The post-processing approach was chosen because: (a) it's conceptually cleaner and easier to test, (b) the greedy algorithm requires sequential selection which doesn't fit a single-pass score formula, (c) it's optional — `mmr_lambda=1.0` is a no-op and fallback is clean.

### Decision 2: Decay Score as a Multiplier on Importance, Not a Replacement
`decay_score * importance` is the effective importance in search. The alternative was to replace `importance` with `decay_score` entirely (making decay the canonical importance signal). The multiplier approach was chosen because it preserves the LLM's intrinsic signal (`importance=0.9` means "this is highly important") while separately tracking time-dimension degradation. A highly important memory that was last accessed a year ago gets a decay multiplier of ~0.1, producing an effective importance of 0.09 — which is correct. The memory was important; it's just stale.

### Decision 3: Consolidation Requires Embeddings; No Fallback
`consolidate_memories` returns an error if embeddings are not available. The alternative was to fall back to the A2A heuristic contradiction detection (token overlap). That was rejected because the heuristic is too coarse for this use case — it would produce false groupings and the merged memories would be semantically wrong. The error message is clear: install `szl-recall[embeddings]` to use this tool. Callers know exactly what to do.

### Decision 4: Context Budget Uses Word-Count Approximation, Not tiktoken
Adding `tiktoken` as a dependency for token counting was rejected. Reasons: (a) `tiktoken` is model-specific — the budget manager would need to know which Claude model the caller is using, (b) it adds a 5MB+ dependency and download, (c) the approximation (`words * 1.3`) is accurate enough for a budget manager — callers set a budget with margin, not an exact limit. If callers need exact tiktoken counts, they can post-process the results list themselves.

### Decision 5: Postgres Backend Uses Placeholder Translation
All SQL queries in the codebase will remain in SQLite `?` placeholder style. The `PostgresBackend` wrapper translates to `$N` at call time. The reverse approach (write everything in Postgres `$N` style and translate for SQLite) was rejected because: (a) it requires touching every SQL query in the codebase, (b) `$N`-style positional args are less readable than `?` for simple queries, (c) the translation function is trivial (`re.sub(r'\?', lambda m: f'${next(counter)}', query)`).

### Tensions

**Tension 1: DecayWorker runs in-process vs. as a scheduled job**
In-process (chosen): simpler deployment, no cron dependency, stops when server stops.  
External cron: survives server downtime, can run on schedule even during deployment.  
Resolution: in-process for v0.3 with the `RECALL_DECAY_JOB_INTERVAL` env var. External cron support is a v0.4 consideration. The `run_once()` method is public specifically to enable external invocation later.

**Tension 2: GDPR erasure should also delete A2A task history**
The A2A task store in v0.2 is in-memory (`_tasks: dict`). Deleting it during GDPR erasure is meaningless since it doesn't persist. When the Postgres backend is implemented (Feature 5), A2A tasks move to a DB table — at that point, GDPR erasure MUST be updated to also delete from that table. This is a known incomplete item in v0.3: `delete_user_data` covers all DB tables but not in-memory A2A tasks. It's documented in the function's docstring.

**Tension 3: consolidate_memories tool description length vs. injection resistance**
The tool description must be short enough to pass `validate_tool_descriptions()` injection pattern checks, but descriptive enough for the LLM to use it correctly. The existing validation checks for URLs, conditional behavior instructions, and exfiltration patterns. The `consolidate_memories` description is long by necessity. The security function must be checked to ensure it doesn't false-positive on the new description before shipping.

### The Single Most Complex Part of v0.3

**The Postgres backend refactoring (Feature 5).**

Specifically: the migration of all `aiosqlite.connect(get_db_path())` context managers across `server.py`, `worker.py`, and `a2a.py` to use the backend abstraction. This is mechanically large (15-20 call sites) and the `?`→`$N` translation must be proven correct for every query. The risk is introducing a subtle query-bug where a placeholder count is off, causing asyncpg to raise a parameter binding error in production but not in SQLite tests.

The mitigation strategy: write the `PostgresBackend.execute()` wrapper to log the translated query and params at DEBUG level, and add a specific test that exercises each translated query pattern (single `?`, multiple `?`, no `?`). Integration tests under `@_needs_postgres` must cover all five MCP tools, not just the CRUD path.

A secondary complexity: `aiosqlite` is connection-per-operation (opens and closes a new connection each time via `async with aiosqlite.connect(...)`), while `asyncpg` uses a connection pool. The `PostgresBackend` must manage pool lifecycle — `create_pool()` in `init_db()`, `pool.acquire()` in each operation, `pool.close()` on shutdown. The `_lifespan` context manager must be updated to close the pool on exit.

---

*End of PLAN_v0.3.md*
