# pyarrlib

A small Python utility library for working with arrays and nested array structures.

This project provides simple helper functions for reversing arrays, computing numeric aggregates, and traversing nested sequences to count or flatten leaf values.

## Features

- `reverse_arr(array)`: reverse a sequence
- `sum_arr(array)`: compute the sum of numeric values
- `multiplication_arr(array)`: compute the product of numeric values
- `leafs(array)`: flatten nested integer arrays
- `num_of_leafs(array)`: count integer leaf nodes in nested arrays
- `len_arr(array)`: count all scalar leaves in nested arrays

## Installation

From the repository root, install in editable mode:

```bash
python -m pip install -e .
```

If you prefer not to install, you can run code directly from this project by ensuring the repository root is on `PYTHONPATH`.

## Usage

```python
from scr import reverse_arr, sum_arr, multiplication_arr, leafs, num_of_leafs, len_arr, ArrayTypeError

print(reverse_arr([1, 'hello', 3, True]))
# [True, 3, 'hello', 1]

print(sum_arr([1, 5, 4, 3, 8]))
# 21

print(multiplication_arr([4, 1, 2, 5, 7]))
# 280

nested = [[1, 2, [3]], [4, [5, 6]]]
print(leafs(nested))
# [1, 2, 3, 4, 5, 6]
print(num_of_leafs(nested))
# 6
print(len_arr(nested))
# 6
```

## API Reference

### `reverse_arr(array)`

Return a new sequence with the elements in reverse order.

### `sum_arr(array)`

Return the sum of numeric values in the array.

If a non-numeric element is encountered, the function returns the sentinel class `ArrayTypeError`.

### `multiplication_arr(array)`

Return the product of numeric values in the array.

If a non-numeric element is found, the function returns `ArrayTypeError`.

### `leafs(array)`

Return a flat list containing all integer leaf values from a nested array structure.

### `num_of_leafs(array)`

Count integer leaf nodes recursively in a nested array structure.

### `len_arr(array)`

Count all scalar leaf values in a nested array structure. Supported scalar types include `int`, `str`, `float`, and `bool`.

## Running the included checks

The repository includes a simple assertion-based test file.

```bash
python tests/test.py
```

## Project structure

- `pyproject.toml` – package metadata and build configuration
- `README.md` – project documentation
- `scr/arrpy.py` – array utility functions and error type
- `scr/multidim_arr.py` – nested array traversal functions
- `tests/test.py` – example assertions covering core behavior

## License

This project is licensed under MIT.
