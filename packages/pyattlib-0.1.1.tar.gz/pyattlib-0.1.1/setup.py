import setuptools
with open("README.md", "r", encoding="utf-8") as f: 
    text = f.read()
setuptools.setup(
    name="pyattlib",
    version="0.1.1",
    author="Sasha Yuvko",
    description="this module can help you work with arrays",
    long_description=text,           
    long_description_content_type="text/markdown",
    package=setuptools.find_packages(),
    python_requires=">=3.8"
)