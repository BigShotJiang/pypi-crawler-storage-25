from ..scr.multidim_arr import *
from ..scr.arrpy import *

assert num_of_leafs([[[[2]], [4, [5, 6, [6], 6, 6, 6], 7]], [2, 4, 5, 6, 6, 6,  6, 6, 7]]) == 18        
assert num_of_leafs([[1, 2, 3], [1, 2, 3]]) == 6

assert len_arr([[1, 2, 3], [1, 2, 3]]) == 6
assert len_arr([[[12], [32, 54, [3], 5], 63, 6], [54, [43, 54, 65, 43, [1, 54, 6], 54], 64]])


assert reverse_arr([1, "hello", 3, True]) == [True, 3, "hello", 1]
assert sum_arr([1, 5, 4, 3, 8]) == 21
assert sum_arr(['int', 43, True]) == ArrayTypeError

assert multiplication_arr([4, 1, 2, 5, 7]) == 280
assert multiplication_arr(['int', 43, True]) == ArrayTypeError