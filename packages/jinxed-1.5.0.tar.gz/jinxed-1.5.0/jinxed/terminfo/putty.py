"""
putty terminal info

Revision: 1.1247
Source: https://invisible-mirror.net/archives/ncurses/current/ncurses.tar.gz

This file is derived from the ncurses terminfo database, which is
distributed under the MIT/X11 license.  See LICENSE.ncurses.
"""

# flake8: noqa: E501
# pylint: disable=line-too-long

BOOL_CAPS = [
    'am',      # (auto_right_margin) terminal has automatic margins
    'bce',     # (back_color_erase) screen erased with background color
    'bw',      # (auto_left_margin) cub1 wraps from column 0 to last column
    'ccc',     # (can_change) terminal can re-define existing colors
    'hs',      # (has_status_line) has extra status line
    'mir',     # (move_insert_mode) safe to move while in insert mode
    'msgr',    # (move_standout_mode) safe to move while in standout mode
    'xenl',    # (eat_newline_glitch) newline ignored after 80 cols (concept)
    'xon',     # (xon_xoff) terminal uses xon/xoff handshaking
]

NUM_CAPS = {
    'colors': 8,    # (max_colors) maximum number of colors on screen
    'it': 8,        # (init_tabs) tabs initially every # spaces
    'pairs': 64,    # (max_pairs) maximum number of color-pairs on the screen
}

STR_CAPS = {
    'acsc': b'``aaffggjjkkllmmnnooppqqrrssttuuvvwwxxyyzz{{||}}~~',
    'bel': b'\a',
    'blink': b'\x1b[5m',
    'bold': b'\x1b[1m',
    'cbt': b'\x1b[Z',
    'civis': b'\x1b[?25l',
    'clear': b'\x1b[H\x1b[J',
    'cnorm': b'\x1b[?25h',
    'cr': b'\r',
    'csr': b'\x1b[%i%p1%d;%p2%dr',
    'cub': b'\x1b[%p1%dD',
    'cub1': b'\b',
    'cud': b'\x1b[%p1%dB',
    'cud1': b'\x1bD',
    'cuf': b'\x1b[%p1%dC',
    'cuf1': b'\x1b[C',
    'cup': b'\x1b[%i%p1%d;%p2%dH',
    'cuu': b'\x1b[%p1%dA',
    'cuu1': b'\x1bM',
    'dch': b'\x1b[%p1%dP',
    'dch1': b'\x1b[P',
    'dim': b'\x1b[2m',
    'dispc': b'%?%p1%{8}%=%t\x1b%%G\xe2\x97\x98\x1b%%@%e%p1%{10}%=%t\x1b%%G\xe2\x97\x99\x1b%%@%e%p1%{12}%=%t\x1b%%G\xe2\x99\x00\x1b%%@%e%p1%{13}%=%t\x1b%%G\xe2\x99\xaa\x1b%%@%e%p1%{14}%=%t\x1b%%G\xe2\x99\xab\x1b%%@%e%p1%{15}%=%t\x1b%%G\xe2\x98\xbc\x1b%%@%e%p1%{27}%=%t\x1b%%G\xe2\x86\x90\x1b%%@%e%p1%{155}%=%t\x1b%%G\xe0\x82\xa2\x1b%%@%e%p1%c%;',
    'dl': b'\x1b[%p1%dM',
    'dl1': b'\x1b[M',
    'dsl': b'\x1b]0;\a',
    'ech': b'\x1b[%p1%dX',
    'ed': b'\x1b[J',
    'el': b'\x1b[K',
    'el1': b'\x1b[1K',
    'enacs': b'',
    'flash': b'\x1b[?5h\x1b[?5l',
    'fsl': b'\a',
    'home': b'\x1b[H',
    'hpa': b'\x1b[%i%p1%dG',
    'ht': b'\t',
    'hts': b'\x1bH',
    'il': b'\x1b[%p1%dL',
    'il1': b'\x1b[L',
    'ind': b'\n',
    'indn': b'\x1b[%p1%dS',
    'initc': b'\x1b]P%p1%x%p2%{255}%*%{1000}%/%02x%p3%{255}%*%{1000}%/%02x%p4%{255}%*%{1000}%/%02x',
    'is2': b'\x1b7\x1b[r\x1b[m\x1b[?7h\x1b[?1;4;6l\x1b[4l\x1b8\x1b>\x1b]R',
    'ka1': b'\x1bOw',
    'ka3': b'\x1bOy',
    'kb2': b'\x1bOu',
    'kbs': b'\x7f',
    'kc1': b'\x1bOq',
    'kc3': b'\x1bOs',
    'kcbt': b'\x1b[Z',
    'kcub1': b'\x1bOD',
    'kcud1': b'\x1bOB',
    'kcuf1': b'\x1bOC',
    'kcuu1': b'\x1bOA',
    'kdch1': b'\x1b[3~',
    'kend': b'\x1b[4~',
    'kent': b'\x1bOM',
    'kf1': b'\x1b[11~',
    'kf10': b'\x1b[21~',
    'kf11': b'\x1b[23~',
    'kf12': b'\x1b[24~',
    'kf13': b'\x1b[25~',
    'kf14': b'\x1b[26~',
    'kf15': b'\x1b[28~',
    'kf16': b'\x1b[29~',
    'kf17': b'\x1b[31~',
    'kf18': b'\x1b[32~',
    'kf19': b'\x1b[33~',
    'kf2': b'\x1b[12~',
    'kf20': b'\x1b[34~',
    'kf3': b'\x1b[13~',
    'kf4': b'\x1b[14~',
    'kf5': b'\x1b[15~',
    'kf6': b'\x1b[17~',
    'kf7': b'\x1b[18~',
    'kf8': b'\x1b[19~',
    'kf9': b'\x1b[20~',
    'khome': b'\x1b[1~',
    'kich1': b'\x1b[2~',
    'kind': b'\x1b[B',
    'kmous': b'\x1b[<',
    'knp': b'\x1b[6~',
    'kpp': b'\x1b[5~',
    'kri': b'\x1b[A',
    'kspd': b'\x1a',
    'nel': b'\r\n',
    'oc': b'\x1b]R',
    'op': b'\x1b[39;49m',
    'rc': b'\x1b8',
    'rep': b'%p1%c\x1b[%p2%{1}%-%db',
    'rev': b'\x1b[7m',
    'ri': b'\x1bM',
    'rin': b'\x1b[%p1%dT',
    'rmacs': b'',
    'rmam': b'\x1b[?7l',
    'rmcup': b'\x1b[?1049l',
    'rmir': b'\x1b[4l',
    'rmkx': b'\x1b[?1l\x1b>',
    'rmpch': b'\x1b[10m',
    'rmso': b'\x1b[27m',
    'rmul': b'\x1b[24m',
    'rs2': b'\x1b<\x1b["p\x1b[50;6"p\x1bc\x1b[?3l\x1b]R\x1b[?1000l',
    's0ds': b'',
    's1ds': b'',
    's2ds': b'\x1b[12m',
    'sc': b'\x1b7',
    'setab': b'\x1b[4%p1%dm',
    'setaf': b'\x1b[3%p1%dm',
    'sgr': b'\x1b[0%?%p1%p6%|%t;1%;%?%p2%t;4%;%?%p1%p3%|%t;7%;%?%p4%t;5%;%?%p5%t;2%;m',
    'sgr0': b'\x1b[m',
    'smacs': b'',
    'smam': b'\x1b[?7h',
    'smcup': b'\x1b[?1049h',
    'smir': b'\x1b[4h',
    'smkx': b'\x1b[?1h\x1b=',
    'smpch': b'\x1b[11m',
    'smso': b'\x1b[7m',
    'smul': b'\x1b[4m',
    'tbc': b'\x1b[3g',
    'tsl': b'\x1b]0;',
    'u6': b'\x1b[%i%d;%dR',
    'u7': b'\x1b[6n',
    'u8': b'\x1b[?6c',
    'u9': b'\x1b[c',
    'vpa': b'\x1b[%i%p1%dd',
}
