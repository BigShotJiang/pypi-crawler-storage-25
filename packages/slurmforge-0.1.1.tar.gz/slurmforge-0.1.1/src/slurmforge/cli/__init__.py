"""CLI subcommands for slurmforge."""
