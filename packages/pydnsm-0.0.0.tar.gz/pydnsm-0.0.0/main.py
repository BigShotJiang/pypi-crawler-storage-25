def main():
    print("Hello from szn-sdn-storageclient!")


if __name__ == "__main__":
    main()
