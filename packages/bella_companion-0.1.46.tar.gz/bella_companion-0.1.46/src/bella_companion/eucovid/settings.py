from pathlib import Path

from bella_companion.settings import settings

BEAST_CONFIGS_DIR = Path(__file__).parent / "beast_configs"
DATA_DIR = Path(__file__).parent / "data"
MSA_FILE = Path(__file__).parent / "msa.fasta"
N_SEEDS = 3

COLORS = {
    "China": "#F0E442",
    "France": "#009E73",
    "Germany": "#D55E00",
    "Italy": "#E69F00",
    "OtherEU": "#56B4E9",
}
COUNTRIES = list(COLORS.keys())
N_COUNTRIES = len(COUNTRIES)

CHANGE_TIMES = ["2020-03-01", "2020-02-01", "2020-01-01"]

N_CASES = [80814, 716, 847, 5883, 3054]
"""Number of confirmed cases in each country before 2020-03-08, derived from ECDC data."""

BELLA_CONFIGS = settings.bella_model_configs["BELLA-3"]
