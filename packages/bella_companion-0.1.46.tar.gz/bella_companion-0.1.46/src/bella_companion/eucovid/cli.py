from argparse import ArgumentParser

from bella_companion.eucovid.run import run_eucovid


def register_eucovid_cli(eucovid_parser: ArgumentParser):
    eucovid_subparsers = eucovid_parser.add_subparsers(dest="subcommand", required=True)

    eucovid_subparsers.add_parser(
        "run", help="Run BEAST2 analyses on empirical eucovid datasets."
    ).set_defaults(func=run_eucovid)
