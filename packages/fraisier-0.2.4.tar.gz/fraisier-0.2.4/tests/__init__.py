"""Fraisier test suite."""
