"""
RewardGuard Premium — Session visualization.

Requires matplotlib::

    pip install matplotlib

Usage::

    from rewardguard_premium import AutoMonitor
    from rewardguard_premium.plot import plot_session

    monitor = AutoMonitor(expected={"task": 0.7, "safety": 0.3})
    # ... training loop ...
    plot_session(monitor)
    # or save:
    plot_session(monitor, save_path="session_report.png")
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from .PremiumCore import AutoMonitor


_FLAG_COLORS = {
    "ok": "#2ecc71",
    "warning": "#f39c12",
    "critical": "#e74c3c",
}
_COMPONENT_PALETTE = [
    "#3498db", "#9b59b6", "#1abc9c", "#e67e22",
    "#e91e63", "#00bcd4", "#8bc34a", "#ff5722",
]


def plot_session(
    monitor: "AutoMonitor",
    title: Optional[str] = None,
    save_path: Optional[str] = None,
    show: bool = True,
) -> None:
    """
    Plot a three-panel session report for a :class:`~rewardguard_premium.AutoMonitor`.

    Top panel    — Alignment score over time (0 = fully misaligned, 1 = aligned),
                   shaded regions mark warning / critical thresholds.
    Middle panel — Per-component reward ratio over time (rolling window).
    Bottom panel — Z-scores and current weight multipliers for the latest snapshot.

    Args:
        monitor:    A :class:`~rewardguard_premium.AutoMonitor` after at least one
                    post-baseline step.
        title:      Optional chart title.
        save_path:  If provided, save the figure to this path.
        show:       Call ``plt.show()`` after rendering (default True).

    Raises:
        ImportError: If matplotlib is not installed.
        ValueError:  If no post-baseline snapshots are available yet.
    """
    try:
        import matplotlib.pyplot as plt
        import matplotlib.patches as mpatches
        import numpy as np
    except ImportError as exc:
        raise ImportError(
            "matplotlib is required for plot_session. "
            "Install it with: pip install matplotlib"
        ) from exc

    snapshots = monitor.snapshots
    if not snapshots:
        raise ValueError(
            "No post-baseline snapshots available. "
            "The monitor needs to complete its warm-up before plotting."
        )

    steps = [s.step for s in snapshots]
    alignment_scores = [s.alignment_score for s in snapshots]
    drift_velocities = [s.drift_velocity for s in snapshots]
    flags = [s.flag for s in snapshots]

    components = sorted(snapshots[0].component_ratios.keys())
    comp_colors = {c: _COMPONENT_PALETTE[i % len(_COMPONENT_PALETTE)] for i, c in enumerate(components)}

    latest = snapshots[-1]

    fig, axes = plt.subplots(3, 1, figsize=(13, 11), gridspec_kw={"height_ratios": [3, 2.5, 2]})
    fig.patch.set_facecolor("#1a1a2e")
    for ax in axes:
        ax.set_facecolor("#16213e")
        ax.tick_params(colors="#cccccc")
        ax.xaxis.label.set_color("#cccccc")
        ax.yaxis.label.set_color("#cccccc")
        ax.title.set_color("#eeeeee")
        for spine in ax.spines.values():
            spine.set_edgecolor("#444466")

    # ---------------------------------------------------------------
    # Panel 1: Alignment score + drift
    # ---------------------------------------------------------------
    ax1 = axes[0]

    # Threshold bands
    ax1.axhspan(0.0, 0.5, color="#e74c3c", alpha=0.07, label="Critical zone")
    ax1.axhspan(0.5, 0.75, color="#f39c12", alpha=0.07, label="Warning zone")
    ax1.axhline(0.75, color="#f39c12", linewidth=0.6, linestyle="--", alpha=0.5)
    ax1.axhline(0.50, color="#e74c3c", linewidth=0.6, linestyle="--", alpha=0.5)

    # Color the line segments by flag
    for i in range(1, len(steps)):
        color = _FLAG_COLORS.get(flags[i], "#cccccc")
        ax1.plot(steps[i - 1:i + 1], alignment_scores[i - 1:i + 1],
                 color=color, linewidth=1.8, alpha=0.9)

    # Scatter dots colored by flag
    dot_colors = [_FLAG_COLORS.get(f, "#cccccc") for f in flags]
    ax1.scatter(steps, alignment_scores, c=dot_colors, s=10, zorder=5, alpha=0.7)

    ax1.set_ylim(-0.05, 1.05)
    ax1.set_ylabel("Alignment Score", color="#cccccc")
    ax1.set_title("Alignment Score Over Time", color="#eeeeee", fontsize=11)

    legend_patches = [
        mpatches.Patch(color=_FLAG_COLORS["ok"], label="OK"),
        mpatches.Patch(color=_FLAG_COLORS["warning"], label="Warning"),
        mpatches.Patch(color=_FLAG_COLORS["critical"], label="Critical"),
    ]
    ax1.legend(handles=legend_patches, loc="lower left",
               facecolor="#22224a", edgecolor="#555577", labelcolor="#cccccc", fontsize=8)

    # Latest score annotation
    last_color = _FLAG_COLORS.get(latest.flag, "#cccccc")
    ax1.annotate(
        f"  {latest.alignment_score:.3f}",
        xy=(steps[-1], alignment_scores[-1]),
        color=last_color, fontsize=9, va="center",
    )

    # ---------------------------------------------------------------
    # Panel 2: Component ratios over time
    # ---------------------------------------------------------------
    ax2 = axes[1]

    for comp in components:
        ratios = [s.component_ratios.get(comp, 0.0) for s in snapshots]
        expected_pct = monitor._expected.get(comp, 0.0) * 100  # type: ignore[attr-defined]
        color = comp_colors[comp]
        ax2.plot(steps, ratios, color=color, linewidth=1.6, label=comp, alpha=0.9)
        ax2.axhline(expected_pct, color=color, linewidth=0.8, linestyle=":", alpha=0.5)

    ax2.set_ylabel("Ratio (%)", color="#cccccc")
    ax2.set_title("Component Ratios (solid = actual, dotted = expected)", color="#eeeeee", fontsize=11)
    ax2.legend(facecolor="#22224a", edgecolor="#555577", labelcolor="#cccccc", fontsize=8,
               loc="upper right", ncol=min(4, len(components)))

    # ---------------------------------------------------------------
    # Panel 3: Z-scores + weights (latest snapshot)
    # ---------------------------------------------------------------
    ax3 = axes[2]

    z_scores = [latest.z_scores.get(c, 0.0) for c in components]
    weight_vals = [monitor.weights.get(c, 1.0) for c in components]

    x = np.arange(len(components))
    bar_w = 0.35

    z_colors = [
        _FLAG_COLORS["critical"] if abs(z) > 3.75
        else _FLAG_COLORS["warning"] if abs(z) > 2.5
        else _FLAG_COLORS["ok"]
        for z in z_scores
    ]
    w_colors = [
        _FLAG_COLORS["critical"] if w >= 4.5 or w <= 0.15
        else _FLAG_COLORS["warning"] if w >= 2.0 or w <= 0.5
        else _FLAG_COLORS["ok"]
        for w in weight_vals
    ]

    ax3.bar(x - bar_w / 2, z_scores, bar_w, color=z_colors, alpha=0.85, label="Z-score")

    ax3_r = ax3.twinx()
    ax3_r.set_facecolor("#16213e")
    ax3_r.tick_params(colors="#cccccc")
    ax3_r.yaxis.label.set_color("#9b59b6")
    ax3_r.bar(x + bar_w / 2, weight_vals, bar_w, color=w_colors, alpha=0.55, label="Weight ×")
    ax3_r.axhline(1.0, color="#aaaacc", linewidth=0.8, linestyle="--")
    ax3_r.set_ylabel("Weight multiplier (×)", color="#9b59b6", fontsize=9)

    ax3.axhline(0, color="#555577", linewidth=0.8)
    ax3.set_xticks(x)
    ax3.set_xticklabels(components, color="#dddddd")
    ax3.set_ylabel("Z-score (σ)", color="#cccccc")
    ax3.set_title(
        f"Latest Snapshot — step {latest.step}  |  flag: {latest.flag.upper()}  |  "
        f"drift: {latest.drift_velocity:+.5f}",
        color="#eeeeee", fontsize=10,
    )

    z_patch = mpatches.Patch(color="#555577", alpha=0.85, label="Z-score")
    w_patch = mpatches.Patch(color="#9b59b6", alpha=0.55, label="Weight ×")
    ax3.legend(handles=[z_patch, w_patch], facecolor="#22224a",
               edgecolor="#555577", labelcolor="#cccccc", fontsize=8)

    # ---------------------------------------------------------------
    # Overall title
    # ---------------------------------------------------------------
    overall_score = latest.alignment_score
    chart_title = (
        title
        or f"RewardGuard Premium — {len(snapshots)} post-baseline steps  "
           f"|  alignment: {overall_score:.3f}  |  {latest.flag.upper()}"
    )
    fig.suptitle(chart_title, color="#ffffff", fontsize=13, y=1.01)

    plt.tight_layout()

    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight", facecolor=fig.get_facecolor())
    if show:
        plt.show()
    plt.close(fig)
