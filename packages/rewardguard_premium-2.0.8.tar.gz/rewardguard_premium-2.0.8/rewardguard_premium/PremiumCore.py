"""
RewardGuard Premium — Advanced reward monitoring with auto-correction.
=======================================================================

Extends the free Monitor with:

* **Baseline learning** — a configurable warm-up window where the monitor
  learns the "normal" ratio for your environment before raising alerts.
* **Z-score detection** — flags deviations measured in standard deviations
  from the learned baseline, not against a flat threshold.
* **0–1 alignment score** — a continuous score (sigmoid-mapped from the
  max z-score) that you can log to TensorBoard, WandB, or any metric sink.
* **Drift velocity** — a rolling regression slope over recent alignment
  scores that distinguishes a worsening trend from a transient spike.
* **Auto-correction** — adjusts per-component reward weight multipliers
  when flagged, with configurable confidence thresholds and correction rate.
* **Framework callbacks** — built-in callbacks for WandB, TensorBoard, and
  Stable-Baselines3; accepts any callable as a custom callback.
* **Persistence** — save / load full monitoring state so a run can be
  resumed or post-processed.
* **Export** — ``to_dict()``, ``to_json()``, ``to_csv()`` for downstream
  analysis.
"""

from __future__ import annotations

import csv
import io
import json
import logging
import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Union

import numpy as np

# Extend the free Monitor — premium is a strict superset of the free API.
from rewardguard.Core import Monitor as _FreeMonitor, AnalysisResult

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------


@dataclass
class AlignmentSnapshot:
    """
    A point-in-time alignment measurement produced after each step once
    the baseline warm-up is complete.

    Attributes:
        step: Global step index when this snapshot was taken.
        alignment_score: 0.0 (fully misaligned) → 1.0 (fully aligned).
        component_ratios: Rolling-window percentage share of each component.
        z_scores: Per-component deviation from baseline (standard deviations).
        drift_velocity: Slope of alignment score over the last ``drift_window``
            steps. Negative → worsening, positive → recovering.
        flag: ``"ok"`` / ``"warning"`` / ``"critical"``.
        corrections_applied: Mapping of component → new weight for any
            automatic corrections applied at this step.
    """

    step: int
    alignment_score: float
    component_ratios: Dict[str, float]
    z_scores: Dict[str, float]
    drift_velocity: float
    flag: str
    corrections_applied: Dict[str, float] = field(default_factory=dict)
    # Components that have been near-zero for starvation_window consecutive steps.
    # A non-empty list is a strong reward-hacking signal.
    starvation_alerts: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "step": self.step,
            "alignment_score": self.alignment_score,
            "component_ratios": self.component_ratios,
            "z_scores": self.z_scores,
            "drift_velocity": self.drift_velocity,
            "flag": self.flag,
            "corrections_applied": dict(self.corrections_applied),
            "starvation_alerts": list(self.starvation_alerts),
        }


# ---------------------------------------------------------------------------
# AutoMonitor
# ---------------------------------------------------------------------------


class AutoMonitor(_FreeMonitor):
    """
    Premium in-loop reward monitor with statistical detection and
    auto-correction.

    Drop-in replacement for the free :class:`~rewardguard.Monitor`; every
    method from the free API works unchanged.

    Example::

        from rewardguard_premium import AutoMonitor

        monitor = AutoMonitor(
            expected={"task": 0.7, "safety": 0.3},
            baseline_steps=500,
            auto_correct=True,
        )

        for episode in range(num_episodes):
            for step in range(max_steps):
                rewards = env.step(action)
                snapshot = monitor.step(rewards)

                if snapshot and snapshot.flag == "critical":
                    # Apply corrected weights to the environment
                    env.set_reward_weights(monitor.weights)

        monitor.save("run_state.json")
        print(monitor.to_csv())

    Args:
        expected: Target distribution (same as free Monitor).
        tolerance: Percentage-point tolerance for the free-tier ``check()``
            method (default 5 pp).  Does **not** affect z-score detection.
        window: Rolling window for percentage computation (default 200 steps).
        max_history: Hard cap on stored raw steps (default 100 000).
        baseline_steps: Steps collected before z-score detection activates.
            During this warm-up the monitor returns ``None`` from ``step()``.
            (default: 300).
        z_threshold: Z-score at which the alignment score equals 0.5 and the
            component is considered flagged (default: 2.5 σ).
        sigmoid_steepness: Controls how sharply the alignment score drops
            around the z_threshold (default: 1.2).
        auto_correct: If ``True``, adjust ``weights`` automatically whenever
            a component is flagged and the confidence window is satisfied
            (default: ``True``).
        correction_rate: Fraction of the required correction applied per
            auto-correct call.  Lower → smoother but slower convergence
            (default: 0.2).
        min_confidence_steps: Minimum post-baseline steps before the first
            automatic correction is allowed (default: 50).
        drift_window: Number of recent snapshots used to estimate drift
            velocity (default: 30).
        callbacks: List of callables invoked with the :class:`AlignmentSnapshot`
            after each post-baseline step.  Built-in helpers:
            :func:`make_wandb_callback`, :func:`make_tensorboard_callback`,
            :func:`make_sb3_callback`.
    """

    def __init__(
        self,
        expected: Dict[str, float],
        *,
        # Inherited free params
        tolerance: float = 5.0,
        window: int = 200,
        max_history: int = 100_000,
        # Premium params
        baseline_steps: int = 300,
        z_threshold: Union[float, Dict[str, float]] = 2.5,
        sigmoid_steepness: float = 1.2,
        auto_correct: bool = True,
        correction_rate: float = 0.2,
        correction_rate_decay: float = 0.0,
        min_confidence_steps: int = 50,
        drift_window: int = 30,
        starvation_window: int = 20,
        starvation_threshold: float = 1.0,
        callbacks: Optional[List[Callable[[AlignmentSnapshot], None]]] = None,
    ) -> None:
        # License is verified here (deferred from import time) so that
        # `import rewardguard_premium` works offline without credentials.
        from .license import verify_license
        verify_license()

        # Pre-check: confirm the user has at least the minimum credits required
        # to start any analysis before the warm-up even begins.
        from .credits_api import CREDITS_MIN_ANALYSIS, check_credits
        check_credits(CREDITS_MIN_ANALYSIS)

        super().__init__(
            expected=expected,
            tolerance=tolerance,
            window=window,
            max_history=max_history,
        )
        self._baseline_steps = baseline_steps
        self._sigmoid_k = sigmoid_steepness
        self._auto_correct = auto_correct
        self._correction_rate = correction_rate
        self._correction_rate_decay = correction_rate_decay
        self._min_confidence_steps = min_confidence_steps
        self._drift_window = drift_window
        self._callbacks: List[Callable[[AlignmentSnapshot], None]] = callbacks or []

        # Per-component z_threshold: accept a single float (applied to all)
        # or a dict of per-component thresholds for asymmetric sensitivity.
        if isinstance(z_threshold, dict):
            self._z_threshold: float = min(z_threshold.values()) if z_threshold else 2.5
            self._z_thresholds: Dict[str, float] = dict(z_threshold)
        else:
            self._z_threshold = float(z_threshold)
            self._z_thresholds = {}  # empty → use _z_threshold for all

        # Starvation detection: flag components that stay near-zero for too long
        self._starvation_window = starvation_window
        self._starvation_threshold = starvation_threshold
        self._starvation_counts: Dict[str, int] = {k: 0 for k in self._expected}

        # Per-component reward weight multipliers (start at 1.0)
        self._weights: Dict[str, float] = {k: 1.0 for k in self._expected}

        # Baseline statistics computed after warm-up
        self._baseline_means: Dict[str, float] = {}
        self._baseline_stds: Dict[str, float] = {}
        self._baseline_complete: bool = False

        # Ratio snapshots taken during warm-up for baseline computation
        # Taken every _SNAPSHOT_INTERVAL steps to avoid high overhead.
        self._SNAPSHOT_INTERVAL: int = 10
        self._baseline_snapshots: List[Dict[str, float]] = []

        # Post-baseline alignment history
        self._snapshots: List[AlignmentSnapshot] = []
        self._post_baseline_steps: int = 0

        # Track whether usage has been reported to avoid double-billing.
        self._usage_reported: bool = False

        # Register a best-effort atexit handler so credits are deducted even
        # when the caller does not use the context manager and does not call
        # report_usage() explicitly.  The handler is a no-op if report_usage()
        # was already called earlier (e.g. via __exit__ or manually).
        import atexit
        atexit.register(self.report_usage)

    # ------------------------------------------------------------------
    # Public API (overrides free step())
    # ------------------------------------------------------------------

    def step(  # type: ignore[override]
        self,
        rewards: Dict[str, float],
        episode_done: bool = False,
    ) -> Optional[AlignmentSnapshot]:
        """
        Record a step and return an :class:`AlignmentSnapshot` once the
        baseline warm-up is complete.

        The snapshot is ``None`` during the first ``baseline_steps`` steps.
        After that every call returns a snapshot with an updated alignment
        score, z-scores, and (if ``auto_correct=True``) any corrections
        applied.

        Args:
            rewards: Raw component values for this step.  The monitor
                **applies current weight multipliers before recording**,
                so the analysis always reflects the weighted signal.
            episode_done: Ignored (accepted for API compatibility).

        Returns:
            :class:`AlignmentSnapshot` or ``None`` during warm-up.
        """
        # Apply current weights to the raw rewards before recording
        weighted = {k: v * self._weights.get(k, 1.0) for k, v in rewards.items()}
        # Delegate raw storage to the free Monitor
        super().step(weighted, episode_done=episode_done)

        # --- Warm-up phase ---
        if self._step_count <= self._baseline_steps:
            if self._step_count % self._SNAPSHOT_INTERVAL == 0:
                snap = self._compute_percentages()
                if snap:
                    self._baseline_snapshots.append(snap)
            if self._step_count == self._baseline_steps:
                self._compute_baseline()
            return None

        # --- Detection phase ---
        self._post_baseline_steps += 1
        snapshot = self._build_snapshot()
        self._snapshots.append(snapshot)

        # Auto-correct if flagged and past confidence window
        if (
            self._auto_correct
            and snapshot.flag in ("warning", "critical")
            and self._post_baseline_steps >= self._min_confidence_steps
        ):
            self._apply_corrections(snapshot)

        # Fire user-supplied callbacks
        for cb in self._callbacks:
            try:
                cb(snapshot)
            except Exception:
                logger.warning(
                    "RewardGuard: callback %r raised an exception — "
                    "check your callback implementation.",
                    cb, exc_info=True,
                )

        return snapshot

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def weights(self) -> Dict[str, float]:
        """
        Current per-component reward weight multipliers.

        Apply these to your reward function to account for detected
        imbalances::

            env.set_reward_weights(monitor.weights)
        """
        return dict(self._weights)

    @property
    def alignment_score(self) -> float:
        """
        Most recent alignment score in [0, 1].

        Returns 1.0 (fully aligned) during warm-up since no deviation
        has been detected yet.
        """
        return self._snapshots[-1].alignment_score if self._snapshots else 1.0

    @property
    def is_baseline_complete(self) -> bool:
        """``True`` once the warm-up window has been filled."""
        return self._baseline_complete

    @property
    def snapshots(self) -> List[AlignmentSnapshot]:
        """All post-baseline :class:`AlignmentSnapshot` objects (read-only copy)."""
        return list(self._snapshots)

    # ------------------------------------------------------------------
    # Export / persistence
    # ------------------------------------------------------------------

    def to_dict(self) -> Dict[str, Any]:
        """Serialize full monitoring state to a plain dict."""
        return {
            "version": 1,
            "step_count": self._step_count,
            "post_baseline_steps": self._post_baseline_steps,
            "baseline_complete": self._baseline_complete,
            "baseline_means": self._baseline_means,
            "baseline_stds": self._baseline_stds,
            "weights": self._weights,
            "expected": self._expected,
            "alignment_score": self.alignment_score,
            "snapshots": [s.to_dict() for s in self._snapshots],
        }

    def to_json(self, path: Optional[str] = None) -> str:
        """
        Serialize state to JSON.

        Args:
            path: If provided, write the JSON to this file path.

        Returns:
            JSON string.
        """
        data = json.dumps(self.to_dict(), indent=2)
        if path:
            Path(path).write_text(data, encoding="utf-8")
        return data

    def to_csv(self, path: Optional[str] = None) -> str:
        """
        Export snapshot history as CSV (one row per detection-phase step).

        Columns: ``step``, ``alignment_score``, ``flag``, ``drift_velocity``,
        then ``ratio_<comp>`` and ``z_<comp>`` for every component.

        Args:
            path: If provided, write the CSV to this file path.

        Returns:
            CSV string.
        """
        if not self._snapshots:
            return ""

        comps = sorted(self._snapshots[0].component_ratios.keys())
        fieldnames = ["step", "alignment_score", "flag", "drift_velocity", "starvation_alerts"]
        for c in comps:
            fieldnames += [f"ratio_{c}", f"z_{c}"]

        buf = io.StringIO()
        writer = csv.DictWriter(buf, fieldnames=fieldnames, lineterminator="\n")
        writer.writeheader()
        for s in self._snapshots:
            row: Dict[str, Any] = {
                "step": s.step,
                "alignment_score": f"{s.alignment_score:.6f}",
                "flag": s.flag,
                "drift_velocity": f"{s.drift_velocity:.6f}",
                "starvation_alerts": "|".join(s.starvation_alerts),
            }
            for c in comps:
                row[f"ratio_{c}"] = f"{s.component_ratios.get(c, 0.0):.4f}"
                row[f"z_{c}"] = f"{s.z_scores.get(c, 0.0):.4f}"
            writer.writerow(row)

        output = buf.getvalue()
        if path:
            Path(path).write_text(output, encoding="utf-8")
        return output

    def save(self, path: str) -> None:
        """
        Save full monitoring state to disk as JSON.

        The saved state can be restored with :meth:`load`.

        Args:
            path: Destination file path (e.g. ``"run_42_state.json"``).
        """
        self.to_json(path)
        logger.info("RewardGuard state saved to %s", path)

    @classmethod
    def load(cls, path: str, **kwargs: Any) -> "AutoMonitor":
        """
        Restore a previously saved monitoring state.

        All constructor keyword arguments (``baseline_steps``,
        ``z_threshold``, etc.) can be overridden via ``kwargs``.

        Args:
            path: Path to a JSON file saved by :meth:`save`.
            **kwargs: Optional overrides for constructor parameters.

        Returns:
            A fully restored :class:`AutoMonitor`.
        """
        # Fix #5: re-verify license here so that subprocesses or workers that
        # call load() directly (without a fresh package import) are still gated.
        from .license import verify_license
        verify_license()

        data = json.loads(Path(path).read_text(encoding="utf-8"))
        expected = data["expected"]

        # Warn if components in the saved state differ from the current config
        saved_comps = set(expected.keys())
        kwarg_expected = kwargs.get("expected", {})
        if kwarg_expected:
            current_comps = set(kwarg_expected.keys())
            if saved_comps != current_comps:
                logger.warning(
                    "RewardGuard: loaded state has components %s but current config has %s. "
                    "Baseline statistics may be inconsistent — consider re-running the warm-up.",
                    sorted(saved_comps), sorted(current_comps),
                )

        monitor = cls(expected=expected, **kwargs)
        monitor._step_count = data["step_count"]
        monitor._post_baseline_steps = data["post_baseline_steps"]
        monitor._baseline_complete = data["baseline_complete"]
        monitor._baseline_means = data["baseline_means"]
        monitor._baseline_stds = data["baseline_stds"]
        monitor._weights = data["weights"]
        for s in data.get("snapshots", []):
            monitor._snapshots.append(
                AlignmentSnapshot(
                    step=s["step"],
                    alignment_score=s["alignment_score"],
                    component_ratios=s["component_ratios"],
                    z_scores=s["z_scores"],
                    drift_velocity=s["drift_velocity"],
                    flag=s["flag"],
                    corrections_applied=s["corrections_applied"],
                )
            )
        logger.info(
            "RewardGuard state loaded from %s (%d snapshots, step %d)",
            path,
            len(monitor._snapshots),
            monitor._step_count,
        )
        return monitor

    def print_report(self) -> None:
        """Print an enhanced premium report including alignment score and z-scores."""
        # Free-tier balance report
        super().print_report()

        if not self._snapshots:
            print("  [Premium] Baseline warm-up not yet complete.\n")
            return

        latest = self._snapshots[-1]
        print("=" * 60)
        print("PREMIUM ALIGNMENT REPORT")
        print("=" * 60)
        print(f"\n  Alignment score   : {latest.alignment_score:.3f}  ({latest.flag.upper()})")
        print(f"  Drift velocity    : {latest.drift_velocity:+.5f} (negative = worsening)")
        print(f"  Post-baseline steps: {self._post_baseline_steps}")
        print(f"  Corrections applied (total): "
              f"{sum(1 for s in self._snapshots if s.corrections_applied)}")
        print(f"\n  Current weights:")
        for comp, w in sorted(self._weights.items()):
            direction = " (reduced)" if w < 1.0 else " (boosted)" if w > 1.0 else ""
            print(f"    {comp}: {w:.4f}{direction}")
        print(f"\n  Z-scores (latest):")
        for comp in sorted(latest.z_scores):
            z = latest.z_scores[comp]
            thr = self._get_z_threshold(comp)
            severity = (
                " ***CRITICAL***" if abs(z) > thr * 1.5
                else " **WARNING**" if abs(z) > thr
                else ""
            )
            thr_label = f" [threshold: {thr:.1f}σ]" if self._z_thresholds else ""
            print(f"    {comp}: {z:+.2f}σ{severity}{thr_label}")

        if latest.starvation_alerts:
            print(f"\n  *** STARVATION ALERTS: {', '.join(latest.starvation_alerts)} ***")
            print(f"      These components have been near-zero for {self._starvation_window}+ steps.")
            print(f"      Possible reward hacking — agent may be ignoring these components.")

        print("=" * 60 + "\n")

    # ------------------------------------------------------------------
    # Credits reporting
    # ------------------------------------------------------------------

    def report_usage(self, description: str = "") -> dict:
        """
        Report credits consumed by this analysis session to the RewardGuard API.

        Should be called once after the training loop finishes.  Calling it
        more than once on the same monitor instance is safe — subsequent calls
        are silently ignored.

        If this monitor is used as a context manager (``with AutoMonitor(...) as m``),
        :meth:`report_usage` is called automatically on a clean exit.

        Credits are computed as 1 credit per post-baseline step, clamped to
        ``[500, 50 000]``.  If the baseline warm-up never completed (zero
        post-baseline steps), no credits are deducted.

        Args:
            description: Human-readable label for the transaction log.
                Defaults to ``"Premium analysis (<N> steps)"``.

        Returns:
            dict with ``credits_spent`` and ``credits_balance`` on success,
            or an empty dict if there were no post-baseline steps or the
            request could not be completed.

        Example::

            monitor = AutoMonitor(expected={"task": 0.7, "safety": 0.3})
            for step in range(total_steps):
                monitor.step(rewards[step])
            monitor.report_usage("CartPole-v1 PPO run")
        """
        if self._usage_reported:
            logger.debug(
                "RewardGuard: usage already reported for this session — skipping."
            )
            return {}

        if self._post_baseline_steps == 0:
            logger.debug(
                "RewardGuard: no post-baseline steps recorded — skipping credit deduction."
            )
            self._usage_reported = True
            return {}

        from .credits_api import compute_credits, deduct_credits

        credits = compute_credits(self._post_baseline_steps)
        desc = (
            description.strip()
            if description.strip()
            else f"Premium analysis ({self._post_baseline_steps:,} steps)"
        )

        result = deduct_credits(credits, desc)
        self._usage_reported = True
        return result

    # ------------------------------------------------------------------
    # Context manager support
    # ------------------------------------------------------------------

    def __enter__(self) -> "AutoMonitor":
        """
        Enter the context manager.

        Allows the pattern::

            with AutoMonitor(expected={"task": 0.7, "safety": 0.3}) as monitor:
                for step in range(total_steps):
                    monitor.step(rewards[step])
            # Credits are reported automatically on clean exit.
        """
        return self

    def __exit__(
        self,
        exc_type: Optional[type],
        exc_val: Optional[BaseException],
        exc_tb: Optional[object],
    ) -> None:
        """
        Exit the context manager.

        Calls :meth:`report_usage` automatically on a clean exit (no exception).
        If the loop was interrupted by an exception, credits are NOT deducted
        since the analysis did not complete normally.
        """
        if exc_type is None and not self._usage_reported and self._post_baseline_steps > 0:
            self.report_usage()
        return None  # never suppress exceptions

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _get_z_threshold(self, comp: str) -> float:
        """Return the z-score threshold for ``comp``, honouring per-component overrides."""
        return self._z_thresholds.get(comp, self._z_threshold)

    def _detect_starvation(self, current_ratios: Dict[str, float]) -> List[str]:
        """
        Update consecutive near-zero counters and return components that have
        been starved (ratio < ``starvation_threshold``) for at least
        ``starvation_window`` consecutive post-baseline steps.
        """
        alerts: List[str] = []
        for comp, expected_pct in self._expected.items():
            if expected_pct <= 0:
                continue
            ratio = current_ratios.get(comp, 0.0)
            if ratio < self._starvation_threshold:
                self._starvation_counts[comp] = self._starvation_counts.get(comp, 0) + 1
            else:
                self._starvation_counts[comp] = 0

            if self._starvation_counts.get(comp, 0) >= self._starvation_window:
                alerts.append(comp)

        if alerts:
            logger.warning(
                "RewardGuard: component starvation detected at step %d — "
                "%s have been near-zero for %d+ consecutive steps. "
                "Possible reward hacking.",
                self._step_count, alerts, self._starvation_window,
            )
        return alerts

    def _compute_baseline(self) -> None:
        """
        Compute mean and std of each component's rolling ratio from the
        snapshots collected during warm-up.
        """
        if not self._baseline_snapshots:
            # Fallback: use current percentages with generous uncertainty.
            # Guard against calling _compute_percentages() before any steps
            # have been recorded (e.g. baseline_steps=0 edge case).
            if not self._step_count:
                logger.warning(
                    "RewardGuard: _compute_baseline called with no recorded steps — "
                    "skipping baseline setup."
                )
                self._baseline_complete = True
                return
            current = self._compute_percentages()
            self._baseline_means = dict(current)
            self._baseline_stds = {k: max(v * 0.15, 1.0) for k, v in current.items()}
            self._baseline_complete = True
            return

        all_comps: set = set()
        for snap in self._baseline_snapshots:
            all_comps.update(snap.keys())

        for comp in all_comps:
            vals = np.array(
                [s.get(comp, 0.0) for s in self._baseline_snapshots], dtype=float
            )
            self._baseline_means[comp] = float(np.mean(vals))
            # Enforce a minimum std so we never divide by zero and avoid
            # extreme z-scores from trivially small variance.
            self._baseline_stds[comp] = float(max(np.std(vals), 1.0))

        self._baseline_complete = True
        logger.info(
            "RewardGuard baseline established after %d steps: %s",
            self._baseline_steps,
            {k: f"{self._baseline_means[k]:.1f}±{self._baseline_stds[k]:.1f}"
             for k in self._baseline_means},
        )

    def _build_snapshot(self) -> AlignmentSnapshot:
        """Build an :class:`AlignmentSnapshot` for the current step."""
        current_ratios = self._compute_percentages()

        # --- Z-scores ---
        z_scores: Dict[str, float] = {}
        for comp, ratio in current_ratios.items():
            mean = self._baseline_means.get(comp, ratio)
            std = self._baseline_stds.get(comp, max(ratio * 0.15, 1.0))
            z_scores[comp] = (ratio - mean) / std

        # --- Alignment score ---
        max_abs_z = max((abs(z) for z in z_scores.values()), default=0.0)
        alignment_score = 1.0 / (
            1.0 + math.exp(self._sigmoid_k * (max_abs_z - self._z_threshold))
        )

        # --- Flag (per-component z_threshold aware) ---
        any_critical = any(
            abs(z) > self._get_z_threshold(comp) * 1.5
            for comp, z in z_scores.items()
        )
        any_warning = any(
            abs(z) > self._get_z_threshold(comp)
            for comp, z in z_scores.items()
        )
        if alignment_score > 0.75 and not any_critical and not any_warning:
            flag = "ok"
        elif alignment_score > 0.50 and not any_critical:
            flag = "warning"
        else:
            flag = "critical"

        # --- Drift velocity ---
        drift_velocity = self._compute_drift_velocity()

        # --- Starvation detection ---
        starvation_alerts = self._detect_starvation(current_ratios)
        if starvation_alerts and flag == "ok":
            flag = "warning"  # escalate if starvation detected but score looks fine

        return AlignmentSnapshot(
            step=self._step_count,
            alignment_score=float(alignment_score),
            component_ratios=current_ratios,
            z_scores=z_scores,
            drift_velocity=drift_velocity,
            flag=flag,
            starvation_alerts=starvation_alerts,
        )

    def _compute_drift_velocity(self) -> float:
        """
        Compute the slope of alignment score over the last ``drift_window``
        snapshots via linear regression.

        Returns 0.0 if there are fewer than 3 snapshots.
        """
        if len(self._snapshots) < 3:
            return 0.0

        recent = self._snapshots[-self._drift_window :]
        scores = np.array([s.alignment_score for s in recent], dtype=float)
        x = np.arange(len(scores), dtype=float)
        # polyfit degree-1 → [slope, intercept]
        slope: float = float(np.polyfit(x, scores, 1)[0])
        return slope

    def _apply_corrections(self, snapshot: AlignmentSnapshot) -> None:
        """
        Adjust per-component weights for flagged components.

        Components whose current ratio exceeds the expected ratio get their
        weight reduced; under-represented components get it raised.
        Only components with |z| > per-component z_threshold are corrected.

        Correction rate decays over post-baseline steps when
        ``correction_rate_decay > 0`` to prevent oscillation in mature runs.
        """
        # Effective rate decreases as the run matures (1/(1 + decay * steps)).
        # When decay=0 (default), this is always correction_rate unchanged.
        effective_rate = self._correction_rate / (
            1.0 + self._correction_rate_decay * self._post_baseline_steps
        )

        for comp, z in snapshot.z_scores.items():
            if abs(z) <= self._get_z_threshold(comp):
                continue

            expected_pct = self._expected.get(comp, 0.0)
            current_pct = snapshot.component_ratios.get(comp, 0.0)

            if expected_pct == 0:
                continue

            current_weight = self._weights.get(comp, 1.0)

            if current_pct == 0:
                # Component completely absent — apply a strong fixed boost.
                # We can't compute expected/0, so double the weight each correction.
                new_weight = min(current_weight * 2.0, 20.0)
            else:
                correction_factor = expected_pct / current_pct
                new_weight = current_weight * (
                    1.0 + (correction_factor - 1.0) * effective_rate
                )

            # Hard limits: never let a weight go below 0.05 or above 20.0
            new_weight = round(max(0.05, min(new_weight, 20.0)), 4)
            self._weights[comp] = new_weight
            snapshot.corrections_applied[comp] = new_weight

        if snapshot.corrections_applied:
            logger.info(
                "RewardGuard auto-corrected weights at step %d: %s",
                snapshot.step,
                snapshot.corrections_applied,
            )


# ---------------------------------------------------------------------------
# Callback factories
# ---------------------------------------------------------------------------


def make_wandb_callback(
    run: Any = None,
    prefix: str = "rewardguard",
) -> Callable[[AlignmentSnapshot], None]:
    """
    Return a callback that logs each :class:`AlignmentSnapshot` to Weights &
    Biases.

    Requires ``wandb`` to be installed (``pip install wandb``).

    Args:
        run: A ``wandb.Run`` object.  If ``None``, uses the currently active
            run (``wandb.run``).
        prefix: Metric name prefix (default ``"rewardguard"``).

    Example::

        import wandb
        from rewardguard_premium import AutoMonitor, make_wandb_callback

        wandb.init(project="my-rl-run")
        monitor = AutoMonitor(
            expected={"task": 0.7, "safety": 0.3},
            callbacks=[make_wandb_callback()],
        )
    """
    try:
        import wandb as _wandb
    except ImportError as exc:
        raise ImportError(
            "wandb is required for make_wandb_callback. "
            "Install it with: pip install wandb"
        ) from exc

    def callback(snapshot: AlignmentSnapshot) -> None:
        active_run = run or _wandb.run
        if active_run is None:
            return
        metrics: Dict[str, Any] = {
            f"{prefix}/alignment_score": snapshot.alignment_score,
            f"{prefix}/drift_velocity": snapshot.drift_velocity,
            f"{prefix}/flag": snapshot.flag,
        }
        for comp, ratio in snapshot.component_ratios.items():
            metrics[f"{prefix}/ratio/{comp}"] = ratio
        for comp, z in snapshot.z_scores.items():
            metrics[f"{prefix}/z_score/{comp}"] = z
        active_run.log(metrics, step=snapshot.step)

    return callback


def make_tensorboard_callback(
    writer: Any,
    prefix: str = "rewardguard",
) -> Callable[[AlignmentSnapshot], None]:
    """
    Return a callback that logs each :class:`AlignmentSnapshot` to
    TensorBoard.

    Requires ``tensorboard`` (``pip install tensorboard``) or any
    ``SummaryWriter``-compatible writer.

    Args:
        writer: A ``torch.utils.tensorboard.SummaryWriter`` or compatible.
        prefix: Tag prefix for all logged scalars (default ``"rewardguard"``).

    Example::

        from torch.utils.tensorboard import SummaryWriter
        from rewardguard_premium import AutoMonitor, make_tensorboard_callback

        writer = SummaryWriter("runs/my_run")
        monitor = AutoMonitor(
            expected={"task": 0.7, "safety": 0.3},
            callbacks=[make_tensorboard_callback(writer)],
        )
    """

    def callback(snapshot: AlignmentSnapshot) -> None:
        step = snapshot.step
        writer.add_scalar(f"{prefix}/alignment_score", snapshot.alignment_score, step)
        writer.add_scalar(f"{prefix}/drift_velocity", snapshot.drift_velocity, step)
        for comp, ratio in snapshot.component_ratios.items():
            writer.add_scalar(f"{prefix}/ratio/{comp}", ratio, step)
        for comp, z in snapshot.z_scores.items():
            writer.add_scalar(f"{prefix}/z_score/{comp}", z, step)

    return callback


def make_sb3_callback(
    monitor: AutoMonitor,
    log_prefix: str = "rewardguard",
) -> Any:
    """
    Return a Stable-Baselines3 ``BaseCallback`` subclass that integrates
    ``monitor`` into an SB3 training loop.

    Requires ``stable_baselines3`` (``pip install stable-baselines3``).

    The callback calls ``monitor.step(infos[i]["reward_components"])`` for
    every environment step, where ``infos`` is the SB3 info dict.  Your
    environment must include a ``"reward_components"`` key in its info dict.

    Args:
        monitor: A configured :class:`AutoMonitor` instance.
        log_prefix: Prefix for SB3 logger keys (default ``"rewardguard"``).

    Example::

        from stable_baselines3 import PPO
        from rewardguard_premium import AutoMonitor, make_sb3_callback

        monitor = AutoMonitor(expected={"task": 0.7, "safety": 0.3})
        cb = make_sb3_callback(monitor)
        model = PPO("MlpPolicy", env)
        model.learn(total_timesteps=500_000, callback=cb)
    """
    try:
        from stable_baselines3.common.callbacks import BaseCallback
    except ImportError as exc:
        raise ImportError(
            "stable_baselines3 is required for make_sb3_callback. "
            "Install it with: pip install stable-baselines3"
        ) from exc

    class _RGCallback(BaseCallback):
        def __init__(self, _monitor: AutoMonitor, _prefix: str) -> None:
            super().__init__(verbose=0)
            self._monitor = _monitor
            self._prefix = _prefix
            self._missing_key_warned: bool = False

        def _on_step(self) -> bool:
            infos = self.locals.get("infos", [])
            for info in infos:
                components = info.get("reward_components")
                if components:
                    snapshot = self._monitor.step(components)
                    if snapshot and self.logger:
                        self.logger.record(
                            f"{self._prefix}/alignment_score",
                            snapshot.alignment_score,
                        )
                        self.logger.record(
                            f"{self._prefix}/flag",
                            0 if snapshot.flag == "ok"
                            else 1 if snapshot.flag == "warning"
                            else 2,
                        )
            # Warn once if no env in the batch provided reward_components.
            if infos and not self._missing_key_warned:
                if not any(info.get("reward_components") for info in infos):
                    self._missing_key_warned = True
                    logger.warning(
                        "RewardGuard: none of the step infos contain 'reward_components'. "
                        "The monitor is not receiving any data. Ensure your environment "
                        "sets info['reward_components'] = {'component': value, ...} "
                        "inside its step() method."
                    )
            return True

    return _RGCallback(monitor, log_prefix)


# ---------------------------------------------------------------------------
# Convenience functions
# ---------------------------------------------------------------------------


def create_monitor(
    expected: Dict[str, float],
    **kwargs: Any,
) -> AutoMonitor:
    """
    Convenience constructor for :class:`AutoMonitor`.

    Equivalent to ``AutoMonitor(expected, **kwargs)`` — provided so that
    users familiar with the free ``rg.Monitor(expected)`` style have a
    natural premium analogue.
    """
    return AutoMonitor(expected=expected, **kwargs)
