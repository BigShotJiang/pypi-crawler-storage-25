#!/usr/bin/env python3
"""
rewardguard-premium CLI.

Commands:
    login   — sign in to your RewardGuard account and save session
    logout  — sign out and remove saved session
    status  — show current session and subscription status
"""

import argparse
import sys


def cmd_login(args: argparse.Namespace) -> int:
    """Sign in to a RewardGuard account."""
    from .license import _prompt_login, _save_session, clear_session, LicenseError

    # Clear any existing session so the prompt always runs fresh
    clear_session()

    try:
        access_token, refresh_token, has_premium = _prompt_login()
    except LicenseError as exc:
        print(f"\nError: {exc}", file=sys.stderr)
        return 1

    _save_session(access_token, refresh_token)
    print("\nSigned in successfully!")

    if has_premium:
        print("Premium subscription: active")
    else:
        print("Premium subscription: none")
        print("Subscribe at: https://rewardguard.ai/premium")

    return 0


def cmd_logout(args: argparse.Namespace) -> int:
    """Sign out and remove the saved session."""
    from .license import clear_session

    clear_session()
    print("Signed out. Session removed.")
    return 0


def cmd_status(args: argparse.Namespace) -> int:
    """Show current session and subscription status."""
    from .license import _load_session, _http, _api_url

    session = _load_session()
    if not session:
        print("Not signed in.")
        print("Run `rewardguard-premium login` to sign in.")
        return 1

    try:
        me = _http("GET", f"{_api_url()}/auth/me", token=session["access_token"])
    except Exception as exc:
        print(f"Could not reach server: {exc}", file=sys.stderr)
        print("You may still be able to use the package in offline mode.")
        return 1

    if not me.get("success"):
        print("Session is expired or invalid.")
        print("Run `rewardguard-premium login` to sign in again.")
        return 1

    user = me["data"]["user"]
    print(f"Signed in as : {user['name']} ({user['email']})")
    if user.get("has_premium"):
        print("Subscription  : premium (active)")
    else:
        print("Subscription  : none")
        print("Subscribe at  : https://rewardguard.ai/premium")

    return 0


def main() -> None:
    """Entry point for the ``rewardguard-premium`` CLI command."""
    parser = argparse.ArgumentParser(
        prog="rewardguard-premium",
        description="RewardGuard Premium — account management CLI.",
    )
    parser.add_argument("--version", action="version", version="%(prog)s 2.0.0")

    sub = parser.add_subparsers(dest="command", metavar="<command>")
    sub.required = True

    sub.add_parser("login", help="Sign in to your RewardGuard account.").set_defaults(
        func=cmd_login
    )
    sub.add_parser("logout", help="Sign out and remove saved session.").set_defaults(
        func=cmd_logout
    )
    sub.add_parser("status", help="Show current session and subscription status.").set_defaults(
        func=cmd_status
    )

    args = parser.parse_args()
    sys.exit(args.func(args))


if __name__ == "__main__":
    main()
