"""
RewardGuard Premium — Account authentication module.

Instead of a static license key, users sign in with their RewardGuard account.
The session is saved to ~/.rewardguard/session.json and refreshed automatically,
so sign-in is only required once per machine.

Sign-in flow
------------
1. Load ``~/.rewardguard/session.json`` (if it exists and passes HMAC check).
2. Call ``GET /auth/me`` with the saved access token.
3. If the access token is expired (401), call ``POST /api/cli/refresh``.
4. If no valid session at all, prompt for email + password interactively
   (or read ``REWARDGUARD_EMAIL`` / ``REWARDGUARD_PASSWORD`` env vars for CI).
5. Confirm the account has ``has_premium == True``.
6. Cache the result in-process for up to ``_CACHE_TTL_SECONDS`` — then
   re-verified automatically on the next call.

CI / automated environments
----------------------------
Preferred (no password exposure)::

    export REWARDGUARD_API_TOKEN='your-api-token'   # generated on rewardguard.ai

Fallback (email + password)::

    export REWARDGUARD_EMAIL='you@example.com'
    export REWARDGUARD_PASSWORD='...'

To sign in ahead of time::

    rewardguard-premium login

To sign out::

    rewardguard-premium logout
"""

from __future__ import annotations

import getpass
import hashlib
import hmac
import json
import logging
import os
import sys
import time
import urllib.parse
from pathlib import Path
from typing import Optional, Tuple

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Public API surface
# ---------------------------------------------------------------------------
__all__ = ["LicenseError", "verify_license", "clear_session"]

# ---------------------------------------------------------------------------
# In-process cache — re-verified after _CACHE_TTL_SECONDS.
# ---------------------------------------------------------------------------
_verified: Optional[bool] = None
_verification_data: Optional[dict] = None
_verified_at: Optional[float] = None

_CACHE_TTL_SECONDS = 4 * 60 * 60  # 4 hours — re-check after this window

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
_DEFAULT_API_URL = "https://rewardguard.dev"
_ALLOWED_API_HOSTS = {"rewardguard.dev", "www.rewardguard.dev"}
_SESSION_FILE = Path.home() / ".rewardguard" / "session.json"
_OFFLINE_GRACE_SECONDS = 24 * 60 * 60  # 24 hours

# Embedded seed for machine-specific HMAC key derivation.
# The actual signing key is derived at runtime by mixing this seed with a
# stable machine identifier — so even if the seed is extracted from bytecode,
# a session.json cannot be forged or ported to a different host.
_SESSION_KEY_SEED = (
    b"\x4a\x8f\x2c\x71\xe3\x95\xb0\x6d\x17\xac\x53\xe8\x29\x0b\xf4\x7e"
    b"\xd6\x3a\x1c\x88\x5f\x42\xe0\x9b\x73\xcd\x16\x8a\x47\xf2\x05\x3b"
    b"\xc1\x7d\x4e\x99\x06\xba\x38\x2f\x8c\x51\xd0\xe7\x14\xab\x60\x9f"
    b"\x3e\x72\x05\xcc\xa8\x1b\xd4\x67\xf9\x2a\x84\x0e\x35\x7b\xc3\x58"
)


def _machine_id() -> bytes:
    """Return a stable, machine-specific identifier.

    Prefers ``/etc/machine-id`` (Linux/systemd) which survives hostname
    renames. Falls back to a SHA-256 hash of hostname + platform info.
    """
    for path in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
        try:
            mid = Path(path).read_text(encoding="utf-8").strip().encode("utf-8")
            if mid:
                return mid
        except OSError:
            pass
    # Fallback: stable-ish hash of host metadata
    import platform
    import socket
    raw = f"{socket.gethostname()}\x00{platform.node()}\x00{platform.machine()}\x00{platform.system()}"
    return hashlib.sha256(raw.encode("utf-8")).digest()


def _derive_session_key() -> bytes:
    """Derive a machine-specific HMAC key via HKDF-Extract (two HMAC rounds).

    Binding the key to the machine prevents session.json from being copied
    to another host to bypass authentication.
    """
    # HKDF-Extract: prk = HMAC-SHA256(salt=machine_id, ikm=seed)
    prk = hmac.new(_machine_id(), _SESSION_KEY_SEED, hashlib.sha256).digest()
    # HKDF-Expand T(1): okm = HMAC-SHA256(prk, 0x01)
    return hmac.new(prk, b"\x01", hashlib.sha256).digest()


# Derived once at import time — cheap (two HMAC-SHA256 calls).
_SESSION_HMAC_KEY: bytes = _derive_session_key()


# ---------------------------------------------------------------------------
# Public exception
# ---------------------------------------------------------------------------


class LicenseError(Exception):
    """Raised when authentication fails or the account has no active premium subscription."""

    pass


# ---------------------------------------------------------------------------
# Session HMAC helpers
# ---------------------------------------------------------------------------


def _sign_session(data: dict) -> str:
    """Return HMAC-SHA256 hex digest over session fields (excluding 'sig' itself)."""
    payload = json.dumps(
        {k: v for k, v in data.items() if k != "sig"},
        sort_keys=True,
    ).encode("utf-8")
    return hmac.new(_SESSION_HMAC_KEY, payload, hashlib.sha256).hexdigest()


# ---------------------------------------------------------------------------
# Session helpers
# ---------------------------------------------------------------------------


def _api_url() -> str:
    """Return the hardcoded official API URL.

    The REWARDGUARD_API_URL override has been intentionally removed to
    prevent redirection to a rogue server that always returns has_premium=true.
    """
    return _DEFAULT_API_URL


def _load_session() -> Optional[dict]:
    """Load and verify saved session from disk.

    Returns None if the file is missing, unreadable, or the HMAC
    signature does not match (tampered or foreign-machine file).
    """
    if not _SESSION_FILE.exists():
        return None
    try:
        data = json.loads(_SESSION_FILE.read_text(encoding="utf-8"))
        if not (data.get("access_token") and data.get("refresh_token")):
            return None
        stored_sig = data.get("sig", "")
        expected_sig = _sign_session(data)
        if not hmac.compare_digest(stored_sig, expected_sig):
            logger.warning(
                "RewardGuard: session file signature is invalid — discarding. "
                "Run `rewardguard-premium login` to re-authenticate."
            )
            return None
        return data
    except (OSError, json.JSONDecodeError, ValueError):
        pass
    return None


def _save_session(access_token: str, refresh_token: str) -> None:
    """Persist session tokens, timestamp, and HMAC signature to disk."""
    if not refresh_token:
        # Guard: never write a session without a refresh token — a session
        # without one can't be renewed, causing an immediate re-login next run.
        logger.debug("RewardGuard: skipping session save — refresh token is empty.")
        return
    _SESSION_FILE.parent.mkdir(parents=True, exist_ok=True)
    session: dict = {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "last_verified_at": int(time.time()),
    }
    session["sig"] = _sign_session(session)
    _SESSION_FILE.write_text(
        json.dumps(session, indent=2),
        encoding="utf-8",
    )
    try:
        _SESSION_FILE.chmod(0o600)
    except OSError:
        pass  # Windows doesn't support chmod — silently ignore


def _offline_grace_ok(session: dict) -> bool:
    """Return True if the last successful online verification is within the grace period."""
    last_verified = session.get("last_verified_at")
    if not isinstance(last_verified, (int, float)):
        return False
    return (time.time() - last_verified) < _OFFLINE_GRACE_SECONDS


def clear_session() -> None:
    """Delete the saved session. Called by ``rewardguard-premium logout``."""
    global _verified, _verification_data, _verified_at
    _verified = None
    _verification_data = None
    _verified_at = None
    if _SESSION_FILE.exists():
        try:
            _SESSION_FILE.unlink()
        except OSError:
            pass


# ---------------------------------------------------------------------------
# HTTP helpers
# ---------------------------------------------------------------------------


def _http(
    method: str,
    url: str,
    payload: Optional[dict] = None,
    token: Optional[str] = None,
) -> dict:
    """
    Make an HTTP request and return the parsed JSON body.

    Only allows connections to the official rewardguard.ai domain.
    Retries once on transient network errors (URLError) with a 2-second delay.
    HTTP-level errors (4xx, 5xx) are not retried.
    """
    import json as _json
    import urllib.error
    import urllib.request

    parsed = urllib.parse.urlparse(url)
    if parsed.netloc not in _ALLOWED_API_HOSTS:
        raise LicenseError(
            f"Blocked request to unauthorized host '{parsed.netloc}'. "
            "Only rewardguard.ai is permitted."
        )

    headers: dict = {"User-Agent": "rewardguard-premium/2.0"}
    if payload is not None:
        headers["Content-Type"] = "application/json"
    if token:
        headers["Authorization"] = f"Bearer {token}"

    body = _json.dumps(payload).encode("utf-8") if payload is not None else None
    req = urllib.request.Request(url, data=body, headers=headers, method=method)

    last_exc: Exception = RuntimeError("unreachable")
    for attempt in range(2):
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                return _json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            # HTTP errors are authoritative — don't retry.
            try:
                return _json.loads(exc.read().decode("utf-8"))
            except Exception:
                raise exc
        except urllib.error.URLError as exc:
            last_exc = exc
            if attempt == 0:
                logger.debug("RewardGuard: transient network error (%s), retrying in 2 s…", exc)
                time.sleep(2)

    raise last_exc


# ---------------------------------------------------------------------------
# Auth operations
# ---------------------------------------------------------------------------


def _check_access_token(access_token: str) -> Optional[bool]:
    """
    Call ``GET /auth/me`` and return ``has_premium``.

    Returns None if the token is rejected (expired / invalid),
    so the caller can fall through to refresh.
    Raises on network error.
    """
    body = _http("GET", f"{_api_url()}/auth/me", token=access_token)
    if not body.get("success"):
        return None
    user = body.get("data", {}).get("user", {})
    return bool(user.get("has_premium", False))


def _do_refresh(refresh_token: str) -> Optional[Tuple[str, str, bool]]:
    """
    Call ``POST /api/cli/refresh``.

    Returns ``(access_token, refresh_token, has_premium)`` or None if the
    refresh token is expired or invalid.
    Raises on network error or malformed server response.
    """
    body = _http("POST", f"{_api_url()}/api/cli/refresh", {"refresh_token": refresh_token})
    if not body.get("success"):
        return None
    data = body.get("data", {})
    new_access = data.get("access_token")
    new_refresh = data.get("refresh_token")
    if not new_access or not new_refresh:
        raise LicenseError(
            "RewardGuard server returned a malformed refresh response. "
            "Please try again or run `rewardguard-premium login`."
        )
    return new_access, new_refresh, bool(data.get("has_premium", False))


def _do_login(email: str, password: str) -> Tuple[str, str, bool]:
    """
    Call ``POST /api/cli/login``.

    Returns ``(access_token, refresh_token, has_premium)``.
    Raises ``LicenseError`` on auth failure or network error.
    """
    try:
        body = _http("POST", f"{_api_url()}/api/cli/login", {"email": email, "password": password})
    except Exception as exc:
        raise LicenseError(
            f"Could not reach RewardGuard servers ({exc}).\n"
            "Check your internet connection and try again."
        ) from exc

    if not body.get("success"):
        raise LicenseError(f"Sign-in failed: {body.get('error', 'Invalid email or password.')}")

    data = body.get("data", {})
    new_access = data.get("access_token")
    new_refresh = data.get("refresh_token")
    if not new_access or not new_refresh:
        raise LicenseError("RewardGuard server returned a malformed login response.")
    return new_access, new_refresh, bool(data.get("has_premium", False))


def _prompt_login() -> Tuple[str, str, bool]:
    """
    Prompt for email + password (or read from env vars for non-interactive use).

    Returns ``(access_token, refresh_token, has_premium)``.
    Raises ``LicenseError`` on failure.
    """
    # Non-interactive path: CI / automated environments
    email = os.environ.get("REWARDGUARD_EMAIL", "").strip()
    password = os.environ.get("REWARDGUARD_PASSWORD", "").strip()

    if email and password:
        return _do_login(email, password)

    # Interactive path
    print(
        "\nRewardGuard Premium — Sign in to your account",
        file=sys.stderr,
    )
    print(
        "  Visit https://rewardguard.dev to create an account\n",
        file=sys.stderr,
    )
    try:
        email = input("  Email: ").strip()
        password = getpass.getpass("  Password: ")
    except (KeyboardInterrupt, EOFError):
        print(file=sys.stderr)
        raise LicenseError(
            "Sign-in cancelled.\n\n"
            "Tip: run `rewardguard-premium login` once before importing the package."
        )

    return _do_login(email, password)


# ---------------------------------------------------------------------------
# Main entry point — called on package import via __init__.py
# ---------------------------------------------------------------------------


def verify_license(force: bool = False) -> dict:
    """
    Verify the user is signed in and has an active premium subscription.

    Results are cached in-process for up to ``_CACHE_TTL_SECONDS`` (4 hours),
    after which the next call re-verifies online automatically.
    Pass ``force=True`` to bypass the cache immediately (e.g. in tests).

    CI / non-interactive use: set ``REWARDGUARD_API_TOKEN`` to a token
    generated on rewardguard.ai — no password is ever read or stored.

    Returns:
        dict with keys ``valid`` (bool) and ``has_premium`` (bool).

    Raises:
        LicenseError: If not signed in, credentials are invalid, or the
            account has no active premium subscription.
    """
    global _verified, _verification_data, _verified_at

    # Honour the in-process cache while it is still fresh.
    cache_fresh = (
        _verified_at is not None
        and (time.time() - _verified_at) < _CACHE_TTL_SECONDS
    )

    if not force and _verified is not None and cache_fresh:
        if not _verified:
            raise LicenseError(_verification_data.get("reason", "Authentication required."))
        return _verification_data

    # Cache is stale or absent — reset and re-verify.
    _verified = None
    _verification_data = None
    _verified_at = None

    # --- CI fast path: direct API token (safer than REWARDGUARD_PASSWORD) ---
    api_token = os.environ.get("REWARDGUARD_API_TOKEN", "").strip()
    if api_token:
        try:
            has_premium = _check_access_token(api_token)
        except Exception as exc:
            raise LicenseError(
                f"Could not verify REWARDGUARD_API_TOKEN ({exc}).\n"
                "Check your internet connection and confirm the token is valid."
            ) from exc
        if not has_premium:
            _verified = False
            _verified_at = time.time()
            reason = (
                "REWARDGUARD_API_TOKEN is invalid or the account has no active "
                "premium subscription.\n\nSubscribe at: https://rewardguard.dev/premium"
            )
            _verification_data = {"valid": False, "reason": reason}
            raise LicenseError(reason)
        _verified = True
        _verified_at = time.time()
        _verification_data = {"valid": True, "has_premium": True, "plan": "premium"}
        logger.debug("RewardGuard: premium verified via API token")
        return _verification_data

    # --- Normal session-based flow ---
    session = _load_session()
    access_token: Optional[str] = session.get("access_token") if session else None
    refresh_token: Optional[str] = session.get("refresh_token") if session else None
    has_premium: Optional[bool] = None

    # Step 1: try saved access token
    if access_token:
        try:
            has_premium = _check_access_token(access_token)
        except Exception as exc:
            if session and _offline_grace_ok(session):
                logger.warning(
                    "RewardGuard: could not reach server (%s). "
                    "Running in offline mode (last verified within grace period).",
                    exc,
                )
                _verified = True
                _verified_at = time.time()
                _verification_data = {"valid": True, "has_premium": True, "plan": "premium", "offline": True}
                return _verification_data
            raise LicenseError(
                "RewardGuard servers are unreachable and your offline grace period has expired.\n"
                "Please connect to the internet and try again."
            ) from exc

    # Step 2: try refresh token
    if has_premium is None and refresh_token:
        try:
            result = _do_refresh(refresh_token)
        except LicenseError:
            raise
        except Exception as exc:
            if session and _offline_grace_ok(session):
                logger.warning(
                    "RewardGuard: could not reach server during refresh (%s). "
                    "Running in offline mode (last verified within grace period).",
                    exc,
                )
                _verified = True
                _verified_at = time.time()
                _verification_data = {"valid": True, "has_premium": True, "plan": "premium", "offline": True}
                return _verification_data
            raise LicenseError(
                "RewardGuard servers are unreachable and your offline grace period has expired.\n"
                "Please connect to the internet and try again."
            ) from exc

        if result:
            access_token, refresh_token, has_premium = result
            _save_session(access_token, refresh_token)

    # Step 3: interactive login
    if has_premium is None:
        try:
            access_token, refresh_token, has_premium = _prompt_login()
        except LicenseError:
            _verified = False
            _verified_at = time.time()
            _verification_data = {"valid": False, "reason": "Authentication required."}
            raise
        _save_session(access_token, refresh_token)
        print("  Signed in successfully!\n", file=sys.stderr)
    elif access_token and has_premium and refresh_token:
        # Online verification succeeded — slide the grace period window forward.
        _save_session(access_token, refresh_token)

    # Step 4: confirm premium status
    if not has_premium:
        _verified = False
        _verified_at = time.time()
        reason = (
            "Your RewardGuard account does not have an active premium subscription.\n\n"
            "Subscribe at: https://rewardguard.dev/premium"
        )
        _verification_data = {"valid": False, "reason": reason}
        raise LicenseError(reason)

    _verified = True
    _verified_at = time.time()
    _verification_data = {"valid": True, "has_premium": True, "plan": "premium"}
    logger.debug("RewardGuard: premium account verified")
    return _verification_data
