"""
RewardGuard Premium — Credits API client.

Provides functions to pre-check and report credit usage via the RewardGuard API.
Called by AutoMonitor at the start and end of each analysis session.

Pre-check flow (before analysis):
    credits_api.check_credits(CREDITS_MIN_ANALYSIS)
    → GET /api/credits/check?required_credits=<n>
    → raises InsufficientCreditsError if balance is too low

Post-analysis report (after analysis):
    credits_api.deduct_credits(amount, description)
    → POST /api/credits/deduct {amount, description}
    → logs a warning but does NOT block if the request fails (fail-open)

Credit formula:
    compute_credits(post_baseline_steps)
    → 1 credit per post-baseline step, clamped to
      [CREDITS_MIN_ANALYSIS, CREDITS_MAX_ANALYSIS].

This aligns with the standard tier examples published on rewardguard.dev/premium:
    ~500 steps  → 500 credits  (e.g. simple Snake environment)
    ~2 000 steps → 2 000 credits (e.g. Atari game)
    ~10 000 steps → 10 000 credits (e.g. robotics task)
    ~50 000 steps → 50 000 credits (e.g. multi-agent environment)
"""

from __future__ import annotations

import logging
import os
from typing import Optional

from .license import LicenseError, _api_url, _http, _load_session

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Public API surface
# ---------------------------------------------------------------------------
__all__ = [
    "InsufficientCreditsError",
    "check_credits",
    "deduct_credits",
    "compute_credits",
    "CREDITS_MIN_ANALYSIS",
    "CREDITS_MAX_ANALYSIS",
]

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# Minimum credits required to start any analysis.
CREDITS_MIN_ANALYSIS: int = 500

# Maximum credits that can be deducted for a single analysis session.
CREDITS_MAX_ANALYSIS: int = 50_000


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class InsufficientCreditsError(LicenseError):
    """
    Raised when the user does not have enough credits to run a premium analysis.

    Attributes:
        balance: The user's current credit balance.
        required: The minimum credits required.
    """

    def __init__(self, balance: int, required: int) -> None:
        self.balance = balance
        self.required = required
        super().__init__(
            f"Insufficient credits: you need at least {required:,} credits "
            f"but your current balance is {balance:,}.\n"
            "Top up at: https://rewardguard.dev/premium"
        )


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _get_access_token() -> Optional[str]:
    """
    Return the current access token.

    Checks ``REWARDGUARD_API_TOKEN`` env var first (CI / non-interactive),
    then falls back to the saved session file written by
    ``rewardguard-premium login``.

    Returns None if the user is not signed in.
    """
    token = os.environ.get("REWARDGUARD_API_TOKEN", "").strip()
    if token:
        return token
    session = _load_session()
    if session:
        return session.get("access_token")
    return None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def check_credits(required: int) -> dict:
    """
    Verify the signed-in user has enough credits to start an analysis.

    Calls ``GET /api/credits/check?required_credits=<required>``.

    On network failure, logs a warning and returns without raising — the
    analysis is allowed to proceed (fail-open) so transient outages don't
    block users who genuinely have credits.

    Args:
        required: Minimum credits needed (use ``CREDITS_MIN_ANALYSIS`` for
            the default pre-check before any analysis starts).

    Returns:
        dict with keys:
            ``has_enough`` (bool)
            ``credits_balance`` (int, or -1 if the balance could not be read)
            ``required`` (int)

    Raises:
        InsufficientCreditsError: Balance is confirmed insufficient.
        LicenseError: User is not signed in at all (no token available).
    """
    token = _get_access_token()
    if not token:
        raise LicenseError(
            "Not signed in to RewardGuard. "
            "Run `rewardguard-premium login` to authenticate."
        )

    url = f"{_api_url()}/api/credits/check?required_credits={required}"
    try:
        body = _http("GET", url, token=token)
    except Exception as exc:
        logger.warning(
            "RewardGuard: credits pre-check could not reach server (%s). "
            "Proceeding with analysis — your balance will be checked on deduction.",
            exc,
        )
        return {"has_enough": True, "credits_balance": -1, "required": required}

    if not body.get("success"):
        logger.warning(
            "RewardGuard: credits pre-check returned an error: %s",
            body.get("error"),
        )
        # Non-authoritative failure — proceed rather than block.
        return {"has_enough": True, "credits_balance": -1, "required": required}

    data = body.get("data", {})
    balance: int = data.get("credits_balance", 0)
    has_enough: bool = data.get("has_enough", True)

    if not has_enough:
        raise InsufficientCreditsError(balance=balance, required=required)

    logger.debug(
        "RewardGuard: credit pre-check passed (balance=%d, required=%d).",
        balance,
        required,
    )
    return {"has_enough": True, "credits_balance": balance, "required": required}


def deduct_credits(amount: int, description: str) -> dict:
    """
    Report credits consumed by a completed analysis session.

    Calls ``POST /api/credits/deduct`` with ``amount`` and ``description``.

    This is best-effort and fail-open: if the request fails due to a
    network error, a warning is logged but no exception is raised, so
    the caller's training loop is never interrupted by a billing call.

    Args:
        amount: Credits consumed (from :func:`compute_credits`).
        description: Human-readable label for the transaction log
            (e.g. ``"Premium analysis (2 000 steps)"``).

    Returns:
        dict with ``credits_spent`` and ``credits_balance`` on success,
        or an empty dict if the request could not be completed.
    """
    if amount <= 0:
        logger.debug("RewardGuard: skipping credit deduction — amount is %d.", amount)
        return {}

    token = _get_access_token()
    if not token:
        logger.warning(
            "RewardGuard: cannot report credit usage — not signed in."
        )
        return {}

    url = f"{_api_url()}/api/credits/deduct"
    try:
        body = _http(
            "POST",
            url,
            payload={"amount": amount, "description": description},
            token=token,
        )
    except Exception as exc:
        logger.warning(
            "RewardGuard: failed to report credit usage (%s). "
            "Credits may not have been deducted from your balance.",
            exc,
        )
        return {}

    if not body.get("success"):
        logger.warning(
            "RewardGuard: credit deduction returned an error: %s",
            body.get("error"),
        )
        return {}

    data = body.get("data", {})
    logger.info(
        "RewardGuard: %d credits deducted. Remaining balance: %d.",
        data.get("credits_spent", amount),
        data.get("credits_balance", -1),
    )
    return data


def compute_credits(post_baseline_steps: int) -> int:
    """
    Calculate credits consumed based on post-baseline steps analyzed.

    Formula: 1 credit per step, clamped to
    ``[CREDITS_MIN_ANALYSIS, CREDITS_MAX_ANALYSIS]``.

    Args:
        post_baseline_steps: Steps recorded after the baseline warm-up.

    Returns:
        Credits to deduct (always in ``[500, 50_000]``).
    """
    return max(CREDITS_MIN_ANALYSIS, min(CREDITS_MAX_ANALYSIS, post_baseline_steps))
