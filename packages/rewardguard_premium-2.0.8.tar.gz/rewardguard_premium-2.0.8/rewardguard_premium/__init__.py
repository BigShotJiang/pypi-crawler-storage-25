"""
RewardGuard Premium — Auto-tuning Reward System
================================================

Premium version with automatic reward rebalancing, statistical alignment
detection, live monitoring, and continuous alignment enforcement.

Requires a valid RewardGuard Premium license.
Set your license key via:

    export REWARDGUARD_LICENSE_KEY='your-key-here'

Or save it to ``~/.rewardguard/license``.

Purchase at: https://rewardguard.dev/premium

Quick start::

    from rewardguard_premium import AutoMonitor

    monitor = AutoMonitor(
        expected={"task": 0.7, "safety": 0.3},
        baseline_steps=500,
        auto_correct=True,
    )

    for episode in range(num_episodes):
        for step in range(max_steps):
            r_task, r_safety = env.step(action)
            snapshot = monitor.step({"task": r_task, "safety": r_safety})

            if snapshot:
                # Apply auto-corrected weights back to the environment
                if snapshot.corrections_applied:
                    env.set_reward_weights(monitor.weights)

    monitor.save("run_state.json")
    monitor.print_report()
"""

__version__ = "2.0.3"
__author__ = "RewardGuard Team"
__email__ = "support@rewardguard.dev"
__license__ = "Proprietary"

# ---------------------------------------------------------------------------
# License is verified lazily inside AutoMonitor.__init__, not at import time.
# This allows offline imports, type-checking, and testing without credentials.
# ---------------------------------------------------------------------------
from .license import LicenseError, verify_license, clear_session  # noqa: E402
from .credits_api import InsufficientCreditsError  # noqa: E402

# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------
from .PremiumCore import (  # noqa: E402, F401
    # Primary class
    AutoMonitor,
    # Data structure
    AlignmentSnapshot,
    # Callback factories
    make_wandb_callback,
    make_tensorboard_callback,
    make_sb3_callback,
    # Convenience
    create_monitor,
)
from .plot import plot_session  # noqa: E402, F401

__all__ = [
    "__version__",
    # Primary class
    "AutoMonitor",
    # Data structure
    "AlignmentSnapshot",
    # Callback factories
    "make_wandb_callback",
    "make_tensorboard_callback",
    "make_sb3_callback",
    # Convenience
    "create_monitor",
    # License / session
    "LicenseError",
    "InsufficientCreditsError",
    "clear_session",
    # Visualization
    "plot_session",
]
