from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.post_verify_labels_files_body import PostVerifyLabelsFilesBody
from ...models.post_verify_labels_json_body import PostVerifyLabelsJsonBody
from ...models.post_verify_labels_response_200 import PostVerifyLabelsResponse200
from ...models.post_verify_labels_response_400 import PostVerifyLabelsResponse400
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: PostVerifyLabelsFilesBody | PostVerifyLabelsJsonBody | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/verify/labels",
    }

    if isinstance(body, PostVerifyLabelsFilesBody):
        if not isinstance(body, Unset):
            _kwargs["files"] = body.to_multipart()

        headers["Content-Type"] = "multipart/form-data"
    if isinstance(body, PostVerifyLabelsJsonBody):
        if not isinstance(body, Unset):
            _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> PostVerifyLabelsResponse200 | PostVerifyLabelsResponse400 | None:
    if response.status_code == 200:
        response_200 = PostVerifyLabelsResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = PostVerifyLabelsResponse400.from_dict(response.json())

        return response_400

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[PostVerifyLabelsResponse200 | PostVerifyLabelsResponse400]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PostVerifyLabelsFilesBody | PostVerifyLabelsJsonBody | Unset = UNSET,
) -> Response[PostVerifyLabelsResponse200 | PostVerifyLabelsResponse400]:
    """Detect image labels

     Detect objects and scenes in an image. Accepts multipart (image file) or JSON (base64 string). 2
    credits per call.

    Args:
        body (PostVerifyLabelsFilesBody | Unset):
        body (PostVerifyLabelsJsonBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostVerifyLabelsResponse200 | PostVerifyLabelsResponse400]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: PostVerifyLabelsFilesBody | PostVerifyLabelsJsonBody | Unset = UNSET,
) -> PostVerifyLabelsResponse200 | PostVerifyLabelsResponse400 | None:
    """Detect image labels

     Detect objects and scenes in an image. Accepts multipart (image file) or JSON (base64 string). 2
    credits per call.

    Args:
        body (PostVerifyLabelsFilesBody | Unset):
        body (PostVerifyLabelsJsonBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostVerifyLabelsResponse200 | PostVerifyLabelsResponse400
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PostVerifyLabelsFilesBody | PostVerifyLabelsJsonBody | Unset = UNSET,
) -> Response[PostVerifyLabelsResponse200 | PostVerifyLabelsResponse400]:
    """Detect image labels

     Detect objects and scenes in an image. Accepts multipart (image file) or JSON (base64 string). 2
    credits per call.

    Args:
        body (PostVerifyLabelsFilesBody | Unset):
        body (PostVerifyLabelsJsonBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostVerifyLabelsResponse200 | PostVerifyLabelsResponse400]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: PostVerifyLabelsFilesBody | PostVerifyLabelsJsonBody | Unset = UNSET,
) -> PostVerifyLabelsResponse200 | PostVerifyLabelsResponse400 | None:
    """Detect image labels

     Detect objects and scenes in an image. Accepts multipart (image file) or JSON (base64 string). 2
    credits per call.

    Args:
        body (PostVerifyLabelsFilesBody | Unset):
        body (PostVerifyLabelsJsonBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostVerifyLabelsResponse200 | PostVerifyLabelsResponse400
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
