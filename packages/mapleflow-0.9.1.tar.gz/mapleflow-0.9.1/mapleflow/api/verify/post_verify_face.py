from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.post_verify_face_files_body import PostVerifyFaceFilesBody
from ...models.post_verify_face_json_body import PostVerifyFaceJsonBody
from ...models.post_verify_face_response_200 import PostVerifyFaceResponse200
from ...models.post_verify_face_response_400 import PostVerifyFaceResponse400
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: PostVerifyFaceFilesBody | PostVerifyFaceJsonBody | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/verify/face",
    }

    if isinstance(body, PostVerifyFaceFilesBody):
        if not isinstance(body, Unset):
            _kwargs["files"] = body.to_multipart()

        headers["Content-Type"] = "multipart/form-data"
    if isinstance(body, PostVerifyFaceJsonBody):
        if not isinstance(body, Unset):
            _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> PostVerifyFaceResponse200 | PostVerifyFaceResponse400 | None:
    if response.status_code == 200:
        response_200 = PostVerifyFaceResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = PostVerifyFaceResponse400.from_dict(response.json())

        return response_400

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[PostVerifyFaceResponse200 | PostVerifyFaceResponse400]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PostVerifyFaceFilesBody | PostVerifyFaceJsonBody | Unset = UNSET,
) -> Response[PostVerifyFaceResponse200 | PostVerifyFaceResponse400]:
    """Compare two faces

     Compare two faces and return similarity score. Accepts multipart (image1, image2 files) or JSON
    (base64 strings). 2 credits per call.

    Args:
        body (PostVerifyFaceFilesBody | Unset):
        body (PostVerifyFaceJsonBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostVerifyFaceResponse200 | PostVerifyFaceResponse400]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: PostVerifyFaceFilesBody | PostVerifyFaceJsonBody | Unset = UNSET,
) -> PostVerifyFaceResponse200 | PostVerifyFaceResponse400 | None:
    """Compare two faces

     Compare two faces and return similarity score. Accepts multipart (image1, image2 files) or JSON
    (base64 strings). 2 credits per call.

    Args:
        body (PostVerifyFaceFilesBody | Unset):
        body (PostVerifyFaceJsonBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostVerifyFaceResponse200 | PostVerifyFaceResponse400
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PostVerifyFaceFilesBody | PostVerifyFaceJsonBody | Unset = UNSET,
) -> Response[PostVerifyFaceResponse200 | PostVerifyFaceResponse400]:
    """Compare two faces

     Compare two faces and return similarity score. Accepts multipart (image1, image2 files) or JSON
    (base64 strings). 2 credits per call.

    Args:
        body (PostVerifyFaceFilesBody | Unset):
        body (PostVerifyFaceJsonBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostVerifyFaceResponse200 | PostVerifyFaceResponse400]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: PostVerifyFaceFilesBody | PostVerifyFaceJsonBody | Unset = UNSET,
) -> PostVerifyFaceResponse200 | PostVerifyFaceResponse400 | None:
    """Compare two faces

     Compare two faces and return similarity score. Accepts multipart (image1, image2 files) or JSON
    (base64 strings). 2 credits per call.

    Args:
        body (PostVerifyFaceFilesBody | Unset):
        body (PostVerifyFaceJsonBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostVerifyFaceResponse200 | PostVerifyFaceResponse400
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
