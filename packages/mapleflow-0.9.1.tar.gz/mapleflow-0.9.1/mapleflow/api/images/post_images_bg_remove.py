from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.post_images_bg_remove_files_body import PostImagesBgRemoveFilesBody
from ...models.post_images_bg_remove_json_body import PostImagesBgRemoveJsonBody
from ...models.post_images_bg_remove_response_200 import PostImagesBgRemoveResponse200
from ...models.post_images_bg_remove_response_400 import PostImagesBgRemoveResponse400
from ...models.post_images_bg_remove_response_502 import PostImagesBgRemoveResponse502
from ...models.post_images_bg_remove_response_504 import PostImagesBgRemoveResponse504
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: PostImagesBgRemoveFilesBody | PostImagesBgRemoveJsonBody | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/images/bg-remove",
    }

    if isinstance(body, PostImagesBgRemoveFilesBody):
        if not isinstance(body, Unset):
            _kwargs["files"] = body.to_multipart()

        headers["Content-Type"] = "multipart/form-data"
    if isinstance(body, PostImagesBgRemoveJsonBody):
        if not isinstance(body, Unset):
            _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    PostImagesBgRemoveResponse200
    | PostImagesBgRemoveResponse400
    | PostImagesBgRemoveResponse502
    | PostImagesBgRemoveResponse504
    | None
):
    if response.status_code == 200:
        response_200 = PostImagesBgRemoveResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = PostImagesBgRemoveResponse400.from_dict(response.json())

        return response_400

    if response.status_code == 502:
        response_502 = PostImagesBgRemoveResponse502.from_dict(response.json())

        return response_502

    if response.status_code == 504:
        response_504 = PostImagesBgRemoveResponse504.from_dict(response.json())

        return response_504

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    PostImagesBgRemoveResponse200
    | PostImagesBgRemoveResponse400
    | PostImagesBgRemoveResponse502
    | PostImagesBgRemoveResponse504
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PostImagesBgRemoveFilesBody | PostImagesBgRemoveJsonBody | Unset = UNSET,
) -> Response[
    PostImagesBgRemoveResponse200
    | PostImagesBgRemoveResponse400
    | PostImagesBgRemoveResponse502
    | PostImagesBgRemoveResponse504
]:
    """Remove image background

     Remove background from an image. Accepts file upload, base64, or URL. 5 credits per call. Currently
    disabled.

    Args:
        body (PostImagesBgRemoveFilesBody | Unset):
        body (PostImagesBgRemoveJsonBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostImagesBgRemoveResponse200 | PostImagesBgRemoveResponse400 | PostImagesBgRemoveResponse502 | PostImagesBgRemoveResponse504]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: PostImagesBgRemoveFilesBody | PostImagesBgRemoveJsonBody | Unset = UNSET,
) -> (
    PostImagesBgRemoveResponse200
    | PostImagesBgRemoveResponse400
    | PostImagesBgRemoveResponse502
    | PostImagesBgRemoveResponse504
    | None
):
    """Remove image background

     Remove background from an image. Accepts file upload, base64, or URL. 5 credits per call. Currently
    disabled.

    Args:
        body (PostImagesBgRemoveFilesBody | Unset):
        body (PostImagesBgRemoveJsonBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostImagesBgRemoveResponse200 | PostImagesBgRemoveResponse400 | PostImagesBgRemoveResponse502 | PostImagesBgRemoveResponse504
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PostImagesBgRemoveFilesBody | PostImagesBgRemoveJsonBody | Unset = UNSET,
) -> Response[
    PostImagesBgRemoveResponse200
    | PostImagesBgRemoveResponse400
    | PostImagesBgRemoveResponse502
    | PostImagesBgRemoveResponse504
]:
    """Remove image background

     Remove background from an image. Accepts file upload, base64, or URL. 5 credits per call. Currently
    disabled.

    Args:
        body (PostImagesBgRemoveFilesBody | Unset):
        body (PostImagesBgRemoveJsonBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostImagesBgRemoveResponse200 | PostImagesBgRemoveResponse400 | PostImagesBgRemoveResponse502 | PostImagesBgRemoveResponse504]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: PostImagesBgRemoveFilesBody | PostImagesBgRemoveJsonBody | Unset = UNSET,
) -> (
    PostImagesBgRemoveResponse200
    | PostImagesBgRemoveResponse400
    | PostImagesBgRemoveResponse502
    | PostImagesBgRemoveResponse504
    | None
):
    """Remove image background

     Remove background from an image. Accepts file upload, base64, or URL. 5 credits per call. Currently
    disabled.

    Args:
        body (PostImagesBgRemoveFilesBody | Unset):
        body (PostImagesBgRemoveJsonBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostImagesBgRemoveResponse200 | PostImagesBgRemoveResponse400 | PostImagesBgRemoveResponse502 | PostImagesBgRemoveResponse504
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
