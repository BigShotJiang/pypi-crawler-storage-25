from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.post_ai_chat_body import PostAiChatBody
from ...models.post_ai_chat_response_200 import PostAiChatResponse200
from ...models.post_ai_chat_response_400 import PostAiChatResponse400
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: PostAiChatBody | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/ai/chat",
    }

    if not isinstance(body, Unset):
        _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> PostAiChatResponse200 | PostAiChatResponse400 | None:
    if response.status_code == 200:
        response_200 = PostAiChatResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = PostAiChatResponse400.from_dict(response.json())

        return response_400

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[PostAiChatResponse200 | PostAiChatResponse400]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PostAiChatBody | Unset = UNSET,
) -> Response[PostAiChatResponse200 | PostAiChatResponse400]:
    """Chat completion

     Generate chat completions.

    | Model | Credits |
    |---|---|
    | `llama-3.2-1b` | 1 |
    | `llama-3.2-3b` | 1 |
    | `llama-3.1-8b` | 1 |
    | `llama-groq` | 1 |
    | `gemini-flash-lite` | 1 |
    | `gpt-oss-20b` | 1 |
    | `phi-2` | 1 |
    | `mistral-7b` | 1 |
    | `claude-3-haiku` | 1 |
    | `gemini-2.0-flash` | 1 |
    | `gpt-4.1-nano` | 1 |
    | `gpt-4.1-mini` | 1 |
    | `gpt-4o-mini` | 1 |
    | `gemini-flash` | 1 |
    | `llama-70b` | 1 |
    | `llama-3.3-70b-cf` | 1 |
    | `deepseek-r1-32b` | 1 |
    | `claude-haiku` | 1 |
    | `gpt-oss-120b` | 1 |
    | `grok-fast` | 1 |
    | `grok-3-mini` | 1 |
    | `gpt-4.1` | 1 |
    | `gpt-4o` | 1 |
    | `o4-mini` | 1 |
    | `o3-mini` | 1 |
    | `claude-sonnet` | 1 |

    Args:
        body (PostAiChatBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostAiChatResponse200 | PostAiChatResponse400]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: PostAiChatBody | Unset = UNSET,
) -> PostAiChatResponse200 | PostAiChatResponse400 | None:
    """Chat completion

     Generate chat completions.

    | Model | Credits |
    |---|---|
    | `llama-3.2-1b` | 1 |
    | `llama-3.2-3b` | 1 |
    | `llama-3.1-8b` | 1 |
    | `llama-groq` | 1 |
    | `gemini-flash-lite` | 1 |
    | `gpt-oss-20b` | 1 |
    | `phi-2` | 1 |
    | `mistral-7b` | 1 |
    | `claude-3-haiku` | 1 |
    | `gemini-2.0-flash` | 1 |
    | `gpt-4.1-nano` | 1 |
    | `gpt-4.1-mini` | 1 |
    | `gpt-4o-mini` | 1 |
    | `gemini-flash` | 1 |
    | `llama-70b` | 1 |
    | `llama-3.3-70b-cf` | 1 |
    | `deepseek-r1-32b` | 1 |
    | `claude-haiku` | 1 |
    | `gpt-oss-120b` | 1 |
    | `grok-fast` | 1 |
    | `grok-3-mini` | 1 |
    | `gpt-4.1` | 1 |
    | `gpt-4o` | 1 |
    | `o4-mini` | 1 |
    | `o3-mini` | 1 |
    | `claude-sonnet` | 1 |

    Args:
        body (PostAiChatBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostAiChatResponse200 | PostAiChatResponse400
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PostAiChatBody | Unset = UNSET,
) -> Response[PostAiChatResponse200 | PostAiChatResponse400]:
    """Chat completion

     Generate chat completions.

    | Model | Credits |
    |---|---|
    | `llama-3.2-1b` | 1 |
    | `llama-3.2-3b` | 1 |
    | `llama-3.1-8b` | 1 |
    | `llama-groq` | 1 |
    | `gemini-flash-lite` | 1 |
    | `gpt-oss-20b` | 1 |
    | `phi-2` | 1 |
    | `mistral-7b` | 1 |
    | `claude-3-haiku` | 1 |
    | `gemini-2.0-flash` | 1 |
    | `gpt-4.1-nano` | 1 |
    | `gpt-4.1-mini` | 1 |
    | `gpt-4o-mini` | 1 |
    | `gemini-flash` | 1 |
    | `llama-70b` | 1 |
    | `llama-3.3-70b-cf` | 1 |
    | `deepseek-r1-32b` | 1 |
    | `claude-haiku` | 1 |
    | `gpt-oss-120b` | 1 |
    | `grok-fast` | 1 |
    | `grok-3-mini` | 1 |
    | `gpt-4.1` | 1 |
    | `gpt-4o` | 1 |
    | `o4-mini` | 1 |
    | `o3-mini` | 1 |
    | `claude-sonnet` | 1 |

    Args:
        body (PostAiChatBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostAiChatResponse200 | PostAiChatResponse400]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: PostAiChatBody | Unset = UNSET,
) -> PostAiChatResponse200 | PostAiChatResponse400 | None:
    """Chat completion

     Generate chat completions.

    | Model | Credits |
    |---|---|
    | `llama-3.2-1b` | 1 |
    | `llama-3.2-3b` | 1 |
    | `llama-3.1-8b` | 1 |
    | `llama-groq` | 1 |
    | `gemini-flash-lite` | 1 |
    | `gpt-oss-20b` | 1 |
    | `phi-2` | 1 |
    | `mistral-7b` | 1 |
    | `claude-3-haiku` | 1 |
    | `gemini-2.0-flash` | 1 |
    | `gpt-4.1-nano` | 1 |
    | `gpt-4.1-mini` | 1 |
    | `gpt-4o-mini` | 1 |
    | `gemini-flash` | 1 |
    | `llama-70b` | 1 |
    | `llama-3.3-70b-cf` | 1 |
    | `deepseek-r1-32b` | 1 |
    | `claude-haiku` | 1 |
    | `gpt-oss-120b` | 1 |
    | `grok-fast` | 1 |
    | `grok-3-mini` | 1 |
    | `gpt-4.1` | 1 |
    | `gpt-4o` | 1 |
    | `o4-mini` | 1 |
    | `o3-mini` | 1 |
    | `claude-sonnet` | 1 |

    Args:
        body (PostAiChatBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostAiChatResponse200 | PostAiChatResponse400
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
