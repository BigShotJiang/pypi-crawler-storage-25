from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.post_ai_embeddings_body import PostAiEmbeddingsBody
from ...models.post_ai_embeddings_response_200 import PostAiEmbeddingsResponse200
from ...models.post_ai_embeddings_response_400 import PostAiEmbeddingsResponse400
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: PostAiEmbeddingsBody | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/ai/embeddings",
    }

    if not isinstance(body, Unset):
        _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> PostAiEmbeddingsResponse200 | PostAiEmbeddingsResponse400 | None:
    if response.status_code == 200:
        response_200 = PostAiEmbeddingsResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = PostAiEmbeddingsResponse400.from_dict(response.json())

        return response_400

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[PostAiEmbeddingsResponse200 | PostAiEmbeddingsResponse400]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PostAiEmbeddingsBody | Unset = UNSET,
) -> Response[PostAiEmbeddingsResponse200 | PostAiEmbeddingsResponse400]:
    """Text embeddings

     Generate vector embeddings from text.

    | Model | Credits |
    |---|---|
    | `bge-base-en` | 1 |

    Args:
        body (PostAiEmbeddingsBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostAiEmbeddingsResponse200 | PostAiEmbeddingsResponse400]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: PostAiEmbeddingsBody | Unset = UNSET,
) -> PostAiEmbeddingsResponse200 | PostAiEmbeddingsResponse400 | None:
    """Text embeddings

     Generate vector embeddings from text.

    | Model | Credits |
    |---|---|
    | `bge-base-en` | 1 |

    Args:
        body (PostAiEmbeddingsBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostAiEmbeddingsResponse200 | PostAiEmbeddingsResponse400
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PostAiEmbeddingsBody | Unset = UNSET,
) -> Response[PostAiEmbeddingsResponse200 | PostAiEmbeddingsResponse400]:
    """Text embeddings

     Generate vector embeddings from text.

    | Model | Credits |
    |---|---|
    | `bge-base-en` | 1 |

    Args:
        body (PostAiEmbeddingsBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostAiEmbeddingsResponse200 | PostAiEmbeddingsResponse400]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: PostAiEmbeddingsBody | Unset = UNSET,
) -> PostAiEmbeddingsResponse200 | PostAiEmbeddingsResponse400 | None:
    """Text embeddings

     Generate vector embeddings from text.

    | Model | Credits |
    |---|---|
    | `bge-base-en` | 1 |

    Args:
        body (PostAiEmbeddingsBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostAiEmbeddingsResponse200 | PostAiEmbeddingsResponse400
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
