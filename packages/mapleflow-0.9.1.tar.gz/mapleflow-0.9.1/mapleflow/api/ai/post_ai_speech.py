from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.post_ai_speech_body import PostAiSpeechBody
from ...models.post_ai_speech_response_200 import PostAiSpeechResponse200
from ...models.post_ai_speech_response_400 import PostAiSpeechResponse400
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: PostAiSpeechBody | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/ai/speech",
    }

    if not isinstance(body, Unset):
        _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> PostAiSpeechResponse200 | PostAiSpeechResponse400 | None:
    if response.status_code == 200:
        response_200 = PostAiSpeechResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = PostAiSpeechResponse400.from_dict(response.json())

        return response_400

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[PostAiSpeechResponse200 | PostAiSpeechResponse400]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PostAiSpeechBody | Unset = UNSET,
) -> Response[PostAiSpeechResponse200 | PostAiSpeechResponse400]:
    """Text-to-speech

     Convert text to speech audio.

    | Model | Credits |
    |---|---|
    | `aura` | 2 |

    Args:
        body (PostAiSpeechBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostAiSpeechResponse200 | PostAiSpeechResponse400]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: PostAiSpeechBody | Unset = UNSET,
) -> PostAiSpeechResponse200 | PostAiSpeechResponse400 | None:
    """Text-to-speech

     Convert text to speech audio.

    | Model | Credits |
    |---|---|
    | `aura` | 2 |

    Args:
        body (PostAiSpeechBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostAiSpeechResponse200 | PostAiSpeechResponse400
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PostAiSpeechBody | Unset = UNSET,
) -> Response[PostAiSpeechResponse200 | PostAiSpeechResponse400]:
    """Text-to-speech

     Convert text to speech audio.

    | Model | Credits |
    |---|---|
    | `aura` | 2 |

    Args:
        body (PostAiSpeechBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostAiSpeechResponse200 | PostAiSpeechResponse400]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: PostAiSpeechBody | Unset = UNSET,
) -> PostAiSpeechResponse200 | PostAiSpeechResponse400 | None:
    """Text-to-speech

     Convert text to speech audio.

    | Model | Credits |
    |---|---|
    | `aura` | 2 |

    Args:
        body (PostAiSpeechBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostAiSpeechResponse200 | PostAiSpeechResponse400
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
