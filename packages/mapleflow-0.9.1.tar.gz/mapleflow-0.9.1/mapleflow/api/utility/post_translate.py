from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.post_translate_body import PostTranslateBody
from ...models.post_translate_response_200 import PostTranslateResponse200
from ...models.post_translate_response_400 import PostTranslateResponse400
from ...models.post_translate_response_402 import PostTranslateResponse402
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: PostTranslateBody | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/translate",
    }

    if not isinstance(body, Unset):
        _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    PostTranslateResponse200
    | PostTranslateResponse400
    | PostTranslateResponse402
    | None
):
    if response.status_code == 200:
        response_200 = PostTranslateResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = PostTranslateResponse400.from_dict(response.json())

        return response_400

    if response.status_code == 402:
        response_402 = PostTranslateResponse402.from_dict(response.json())

        return response_402

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    PostTranslateResponse200 | PostTranslateResponse400 | PostTranslateResponse402
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PostTranslateBody | Unset = UNSET,
) -> Response[
    PostTranslateResponse200 | PostTranslateResponse400 | PostTranslateResponse402
]:
    """Translate text

     Translate text between languages. Pricing: 1 credit per 300 characters (rounded up, minimum 1
    credit). Supports 75+ languages with auto-detection.

    Args:
        body (PostTranslateBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostTranslateResponse200 | PostTranslateResponse400 | PostTranslateResponse402]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: PostTranslateBody | Unset = UNSET,
) -> (
    PostTranslateResponse200
    | PostTranslateResponse400
    | PostTranslateResponse402
    | None
):
    """Translate text

     Translate text between languages. Pricing: 1 credit per 300 characters (rounded up, minimum 1
    credit). Supports 75+ languages with auto-detection.

    Args:
        body (PostTranslateBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostTranslateResponse200 | PostTranslateResponse400 | PostTranslateResponse402
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: PostTranslateBody | Unset = UNSET,
) -> Response[
    PostTranslateResponse200 | PostTranslateResponse400 | PostTranslateResponse402
]:
    """Translate text

     Translate text between languages. Pricing: 1 credit per 300 characters (rounded up, minimum 1
    credit). Supports 75+ languages with auto-detection.

    Args:
        body (PostTranslateBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostTranslateResponse200 | PostTranslateResponse400 | PostTranslateResponse402]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: PostTranslateBody | Unset = UNSET,
) -> (
    PostTranslateResponse200
    | PostTranslateResponse400
    | PostTranslateResponse402
    | None
):
    """Translate text

     Translate text between languages. Pricing: 1 credit per 300 characters (rounded up, minimum 1
    credit). Supports 75+ languages with auto-detection.

    Args:
        body (PostTranslateBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostTranslateResponse200 | PostTranslateResponse400 | PostTranslateResponse402
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
