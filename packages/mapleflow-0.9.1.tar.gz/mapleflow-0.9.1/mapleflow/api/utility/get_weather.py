from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_weather_response_200 import GetWeatherResponse200
from ...models.get_weather_response_400 import GetWeatherResponse400
from ...models.get_weather_response_404 import GetWeatherResponse404
from ...models.get_weather_response_502 import GetWeatherResponse502
from ...models.get_weather_units import GetWeatherUnits
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    location: str | Unset = UNSET,
    lat: str | Unset = UNSET,
    lon: str | Unset = UNSET,
    units: GetWeatherUnits | Unset = GetWeatherUnits.METRIC,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["location"] = location

    params["lat"] = lat

    params["lon"] = lon

    json_units: str | Unset = UNSET
    if not isinstance(units, Unset):
        json_units = units.value

    params["units"] = json_units

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/weather",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    GetWeatherResponse200
    | GetWeatherResponse400
    | GetWeatherResponse404
    | GetWeatherResponse502
    | None
):
    if response.status_code == 200:
        response_200 = GetWeatherResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = GetWeatherResponse400.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = GetWeatherResponse404.from_dict(response.json())

        return response_404

    if response.status_code == 502:
        response_502 = GetWeatherResponse502.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    GetWeatherResponse200
    | GetWeatherResponse400
    | GetWeatherResponse404
    | GetWeatherResponse502
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    location: str | Unset = UNSET,
    lat: str | Unset = UNSET,
    lon: str | Unset = UNSET,
    units: GetWeatherUnits | Unset = GetWeatherUnits.METRIC,
) -> Response[
    GetWeatherResponse200
    | GetWeatherResponse400
    | GetWeatherResponse404
    | GetWeatherResponse502
]:
    """Get current weather

     Get current weather for a location. Provide a city name or lat/lon coordinates. Costs 1 credit per
    request.

    Args:
        location (str | Unset): City name Example: Toronto.
        lat (str | Unset): Latitude Example: 43.65.
        lon (str | Unset): Longitude Example: -79.38.
        units (GetWeatherUnits | Unset): Unit system Default: GetWeatherUnits.METRIC. Example:
            metric.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetWeatherResponse200 | GetWeatherResponse400 | GetWeatherResponse404 | GetWeatherResponse502]
    """

    kwargs = _get_kwargs(
        location=location,
        lat=lat,
        lon=lon,
        units=units,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    location: str | Unset = UNSET,
    lat: str | Unset = UNSET,
    lon: str | Unset = UNSET,
    units: GetWeatherUnits | Unset = GetWeatherUnits.METRIC,
) -> (
    GetWeatherResponse200
    | GetWeatherResponse400
    | GetWeatherResponse404
    | GetWeatherResponse502
    | None
):
    """Get current weather

     Get current weather for a location. Provide a city name or lat/lon coordinates. Costs 1 credit per
    request.

    Args:
        location (str | Unset): City name Example: Toronto.
        lat (str | Unset): Latitude Example: 43.65.
        lon (str | Unset): Longitude Example: -79.38.
        units (GetWeatherUnits | Unset): Unit system Default: GetWeatherUnits.METRIC. Example:
            metric.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetWeatherResponse200 | GetWeatherResponse400 | GetWeatherResponse404 | GetWeatherResponse502
    """

    return sync_detailed(
        client=client,
        location=location,
        lat=lat,
        lon=lon,
        units=units,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    location: str | Unset = UNSET,
    lat: str | Unset = UNSET,
    lon: str | Unset = UNSET,
    units: GetWeatherUnits | Unset = GetWeatherUnits.METRIC,
) -> Response[
    GetWeatherResponse200
    | GetWeatherResponse400
    | GetWeatherResponse404
    | GetWeatherResponse502
]:
    """Get current weather

     Get current weather for a location. Provide a city name or lat/lon coordinates. Costs 1 credit per
    request.

    Args:
        location (str | Unset): City name Example: Toronto.
        lat (str | Unset): Latitude Example: 43.65.
        lon (str | Unset): Longitude Example: -79.38.
        units (GetWeatherUnits | Unset): Unit system Default: GetWeatherUnits.METRIC. Example:
            metric.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetWeatherResponse200 | GetWeatherResponse400 | GetWeatherResponse404 | GetWeatherResponse502]
    """

    kwargs = _get_kwargs(
        location=location,
        lat=lat,
        lon=lon,
        units=units,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    location: str | Unset = UNSET,
    lat: str | Unset = UNSET,
    lon: str | Unset = UNSET,
    units: GetWeatherUnits | Unset = GetWeatherUnits.METRIC,
) -> (
    GetWeatherResponse200
    | GetWeatherResponse400
    | GetWeatherResponse404
    | GetWeatherResponse502
    | None
):
    """Get current weather

     Get current weather for a location. Provide a city name or lat/lon coordinates. Costs 1 credit per
    request.

    Args:
        location (str | Unset): City name Example: Toronto.
        lat (str | Unset): Latitude Example: 43.65.
        lon (str | Unset): Longitude Example: -79.38.
        units (GetWeatherUnits | Unset): Unit system Default: GetWeatherUnits.METRIC. Example:
            metric.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetWeatherResponse200 | GetWeatherResponse400 | GetWeatherResponse404 | GetWeatherResponse502
    """

    return (
        await asyncio_detailed(
            client=client,
            location=location,
            lat=lat,
            lon=lon,
            units=units,
        )
    ).parsed
