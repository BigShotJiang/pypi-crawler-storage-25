from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_currency_response_200 import GetCurrencyResponse200
from ...models.get_currency_response_400 import GetCurrencyResponse400
from ...models.get_currency_response_404 import GetCurrencyResponse404
from ...models.get_currency_response_502 import GetCurrencyResponse502
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    from_: str,
    to: str,
    amount: str | Unset = "1",
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["from"] = from_

    params["to"] = to

    params["amount"] = amount

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/currency",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    GetCurrencyResponse200
    | GetCurrencyResponse400
    | GetCurrencyResponse404
    | GetCurrencyResponse502
    | None
):
    if response.status_code == 200:
        response_200 = GetCurrencyResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = GetCurrencyResponse400.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = GetCurrencyResponse404.from_dict(response.json())

        return response_404

    if response.status_code == 502:
        response_502 = GetCurrencyResponse502.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    GetCurrencyResponse200
    | GetCurrencyResponse400
    | GetCurrencyResponse404
    | GetCurrencyResponse502
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    from_: str,
    to: str,
    amount: str | Unset = "1",
) -> Response[
    GetCurrencyResponse200
    | GetCurrencyResponse400
    | GetCurrencyResponse404
    | GetCurrencyResponse502
]:
    """Convert currency

     Convert between currencies using live exchange rates. 1 credit per request. 160+ currencies
    supported.

    Args:
        from_ (str): Source currency code (ISO 4217) Example: USD.
        to (str): Target currency code (ISO 4217) Example: EUR.
        amount (str | Unset): Amount to convert Default: '1'. Example: 100.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetCurrencyResponse200 | GetCurrencyResponse400 | GetCurrencyResponse404 | GetCurrencyResponse502]
    """

    kwargs = _get_kwargs(
        from_=from_,
        to=to,
        amount=amount,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    from_: str,
    to: str,
    amount: str | Unset = "1",
) -> (
    GetCurrencyResponse200
    | GetCurrencyResponse400
    | GetCurrencyResponse404
    | GetCurrencyResponse502
    | None
):
    """Convert currency

     Convert between currencies using live exchange rates. 1 credit per request. 160+ currencies
    supported.

    Args:
        from_ (str): Source currency code (ISO 4217) Example: USD.
        to (str): Target currency code (ISO 4217) Example: EUR.
        amount (str | Unset): Amount to convert Default: '1'. Example: 100.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetCurrencyResponse200 | GetCurrencyResponse400 | GetCurrencyResponse404 | GetCurrencyResponse502
    """

    return sync_detailed(
        client=client,
        from_=from_,
        to=to,
        amount=amount,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    from_: str,
    to: str,
    amount: str | Unset = "1",
) -> Response[
    GetCurrencyResponse200
    | GetCurrencyResponse400
    | GetCurrencyResponse404
    | GetCurrencyResponse502
]:
    """Convert currency

     Convert between currencies using live exchange rates. 1 credit per request. 160+ currencies
    supported.

    Args:
        from_ (str): Source currency code (ISO 4217) Example: USD.
        to (str): Target currency code (ISO 4217) Example: EUR.
        amount (str | Unset): Amount to convert Default: '1'. Example: 100.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetCurrencyResponse200 | GetCurrencyResponse400 | GetCurrencyResponse404 | GetCurrencyResponse502]
    """

    kwargs = _get_kwargs(
        from_=from_,
        to=to,
        amount=amount,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    from_: str,
    to: str,
    amount: str | Unset = "1",
) -> (
    GetCurrencyResponse200
    | GetCurrencyResponse400
    | GetCurrencyResponse404
    | GetCurrencyResponse502
    | None
):
    """Convert currency

     Convert between currencies using live exchange rates. 1 credit per request. 160+ currencies
    supported.

    Args:
        from_ (str): Source currency code (ISO 4217) Example: USD.
        to (str): Target currency code (ISO 4217) Example: EUR.
        amount (str | Unset): Amount to convert Default: '1'. Example: 100.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetCurrencyResponse200 | GetCurrencyResponse400 | GetCurrencyResponse404 | GetCurrencyResponse502
    """

    return (
        await asyncio_detailed(
            client=client,
            from_=from_,
            to=to,
            amount=amount,
        )
    ).parsed
