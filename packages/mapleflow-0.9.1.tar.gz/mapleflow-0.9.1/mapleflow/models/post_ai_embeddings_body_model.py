from enum import Enum


class PostAiEmbeddingsBodyModel(str, Enum):
    BGE_BASE_EN = "bge-base-en"

    def __str__(self) -> str:
        return str(self.value)
