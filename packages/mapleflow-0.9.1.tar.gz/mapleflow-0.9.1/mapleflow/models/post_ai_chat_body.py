from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.post_ai_chat_body_model import PostAiChatBodyModel
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.post_ai_chat_body_messages_item import PostAiChatBodyMessagesItem


T = TypeVar("T", bound="PostAiChatBody")


@_attrs_define
class PostAiChatBody:
    """
    Attributes:
        messages (list[PostAiChatBodyMessagesItem]): Array of chat messages
        model (PostAiChatBodyModel | Unset): Model name Default: PostAiChatBodyModel.LLAMA_3_2_1B. Example:
            llama-3.2-1b.
        max_tokens (float | Unset): Maximum tokens to generate Default: 1024.0.
    """

    messages: list[PostAiChatBodyMessagesItem]
    model: PostAiChatBodyModel | Unset = PostAiChatBodyModel.LLAMA_3_2_1B
    max_tokens: float | Unset = 1024.0
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        messages = []
        for messages_item_data in self.messages:
            messages_item = messages_item_data.to_dict()
            messages.append(messages_item)

        model: str | Unset = UNSET
        if not isinstance(self.model, Unset):
            model = self.model.value

        max_tokens = self.max_tokens

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "messages": messages,
            }
        )
        if model is not UNSET:
            field_dict["model"] = model
        if max_tokens is not UNSET:
            field_dict["max_tokens"] = max_tokens

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.post_ai_chat_body_messages_item import PostAiChatBodyMessagesItem

        d = dict(src_dict)
        messages = []
        _messages = d.pop("messages")
        for messages_item_data in _messages:
            messages_item = PostAiChatBodyMessagesItem.from_dict(messages_item_data)

            messages.append(messages_item)

        _model = d.pop("model", UNSET)
        model: PostAiChatBodyModel | Unset
        if isinstance(_model, Unset):
            model = UNSET
        else:
            model = PostAiChatBodyModel(_model)

        max_tokens = d.pop("max_tokens", UNSET)

        post_ai_chat_body = cls(
            messages=messages,
            model=model,
            max_tokens=max_tokens,
        )

        post_ai_chat_body.additional_properties = d
        return post_ai_chat_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
