from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="PostTranslateBody")


@_attrs_define
class PostTranslateBody:
    """
    Attributes:
        text (str): Text to translate Example: Hello, world!.
        to (str): Target language code (ISO 639-1) Example: es.
        from_ (str | Unset): Source language code (ISO 639-1) or 'auto' Default: 'auto'. Example: auto.
        model (str | Unset): Model (only 'auto' supported) Example: auto.
    """

    text: str
    to: str
    from_: str | Unset = "auto"
    model: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        text = self.text

        to = self.to

        from_ = self.from_

        model = self.model

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "text": text,
                "to": to,
            }
        )
        if from_ is not UNSET:
            field_dict["from"] = from_
        if model is not UNSET:
            field_dict["model"] = model

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        text = d.pop("text")

        to = d.pop("to")

        from_ = d.pop("from", UNSET)

        model = d.pop("model", UNSET)

        post_translate_body = cls(
            text=text,
            to=to,
            from_=from_,
            model=model,
        )

        post_translate_body.additional_properties = d
        return post_translate_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
