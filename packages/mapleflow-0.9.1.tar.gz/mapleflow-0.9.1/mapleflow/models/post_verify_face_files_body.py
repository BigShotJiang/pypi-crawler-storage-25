from __future__ import annotations

from collections.abc import Mapping
from io import BytesIO
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, File, FileTypes, Unset

T = TypeVar("T", bound="PostVerifyFaceFilesBody")


@_attrs_define
class PostVerifyFaceFilesBody:
    """
    Attributes:
        image1 (File | Unset):
        image2 (File | Unset):
    """

    image1: File | Unset = UNSET
    image2: File | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        image1: FileTypes | Unset = UNSET
        if not isinstance(self.image1, Unset):
            image1 = self.image1.to_tuple()

        image2: FileTypes | Unset = UNSET
        if not isinstance(self.image2, Unset):
            image2 = self.image2.to_tuple()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if image1 is not UNSET:
            field_dict["image1"] = image1
        if image2 is not UNSET:
            field_dict["image2"] = image2

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        if not isinstance(self.image1, Unset):
            files.append(("image1", self.image1.to_tuple()))

        if not isinstance(self.image2, Unset):
            files.append(("image2", self.image2.to_tuple()))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        _image1 = d.pop("image1", UNSET)
        image1: File | Unset
        if isinstance(_image1, Unset):
            image1 = UNSET
        else:
            image1 = File(payload=BytesIO(_image1))

        _image2 = d.pop("image2", UNSET)
        image2: File | Unset
        if isinstance(_image2, Unset):
            image2 = UNSET
        else:
            image2 = File(payload=BytesIO(_image2))

        post_verify_face_files_body = cls(
            image1=image1,
            image2=image2,
        )

        post_verify_face_files_body.additional_properties = d
        return post_verify_face_files_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
