from enum import Enum


class PostAiSpeechBodyModel(str, Enum):
    AURA = "aura"

    def __str__(self) -> str:
        return str(self.value)
