from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="PostVerifyFaceJsonBody")


@_attrs_define
class PostVerifyFaceJsonBody:
    """
    Attributes:
        image1 (str): Base64-encoded image Example: <base64>.
        image2 (str): Base64-encoded image Example: <base64>.
    """

    image1: str
    image2: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        image1 = self.image1

        image2 = self.image2

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "image1": image1,
                "image2": image2,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        image1 = d.pop("image1")

        image2 = d.pop("image2")

        post_verify_face_json_body = cls(
            image1=image1,
            image2=image2,
        )

        post_verify_face_json_body.additional_properties = d
        return post_verify_face_json_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
