from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.post_ai_images_body_model import PostAiImagesBodyModel
from ..types import UNSET, Unset

T = TypeVar("T", bound="PostAiImagesBody")


@_attrs_define
class PostAiImagesBody:
    """
    Attributes:
        prompt (str): Image prompt Example: A sunset over mountains.
        model (PostAiImagesBodyModel | Unset): Model name Default: PostAiImagesBodyModel.FLUX_SCHNELL. Example: flux-
            schnell.
        num_steps (float | Unset): Number of inference steps Default: 4.0.
    """

    prompt: str
    model: PostAiImagesBodyModel | Unset = PostAiImagesBodyModel.FLUX_SCHNELL
    num_steps: float | Unset = 4.0
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        prompt = self.prompt

        model: str | Unset = UNSET
        if not isinstance(self.model, Unset):
            model = self.model.value

        num_steps = self.num_steps

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "prompt": prompt,
            }
        )
        if model is not UNSET:
            field_dict["model"] = model
        if num_steps is not UNSET:
            field_dict["num_steps"] = num_steps

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        prompt = d.pop("prompt")

        _model = d.pop("model", UNSET)
        model: PostAiImagesBodyModel | Unset
        if isinstance(_model, Unset):
            model = UNSET
        else:
            model = PostAiImagesBodyModel(_model)

        num_steps = d.pop("num_steps", UNSET)

        post_ai_images_body = cls(
            prompt=prompt,
            model=model,
            num_steps=num_steps,
        )

        post_ai_images_body.additional_properties = d
        return post_ai_images_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
