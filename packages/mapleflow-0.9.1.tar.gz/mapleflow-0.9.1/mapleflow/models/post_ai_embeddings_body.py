from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.post_ai_embeddings_body_model import PostAiEmbeddingsBodyModel
from ..types import UNSET, Unset

T = TypeVar("T", bound="PostAiEmbeddingsBody")


@_attrs_define
class PostAiEmbeddingsBody:
    """
    Attributes:
        text (list[str] | str): Text or array of texts to embed Example: Hello world.
        model (PostAiEmbeddingsBodyModel | Unset): Model name Default: PostAiEmbeddingsBodyModel.BGE_BASE_EN. Example:
            bge-base-en.
    """

    text: list[str] | str
    model: PostAiEmbeddingsBodyModel | Unset = PostAiEmbeddingsBodyModel.BGE_BASE_EN
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        text: list[str] | str
        if isinstance(self.text, list):
            text = self.text

        else:
            text = self.text

        model: str | Unset = UNSET
        if not isinstance(self.model, Unset):
            model = self.model.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "text": text,
            }
        )
        if model is not UNSET:
            field_dict["model"] = model

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_text(data: object) -> list[str] | str:
            try:
                if not isinstance(data, list):
                    raise TypeError()
                text_type_1 = cast(list[str], data)

                return text_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | str, data)

        text = _parse_text(d.pop("text"))

        _model = d.pop("model", UNSET)
        model: PostAiEmbeddingsBodyModel | Unset
        if isinstance(_model, Unset):
            model = UNSET
        else:
            model = PostAiEmbeddingsBodyModel(_model)

        post_ai_embeddings_body = cls(
            text=text,
            model=model,
        )

        post_ai_embeddings_body.additional_properties = d
        return post_ai_embeddings_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
