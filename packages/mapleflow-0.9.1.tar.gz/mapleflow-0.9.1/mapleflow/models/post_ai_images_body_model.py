from enum import Enum


class PostAiImagesBodyModel(str, Enum):
    FLUX_DEV = "flux-dev"
    FLUX_SCHNELL = "flux-schnell"

    def __str__(self) -> str:
        return str(self.value)
