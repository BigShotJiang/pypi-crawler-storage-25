# mapleflow

Official Python SDK for the [MapleFlow](https://mapleflow.io) API platform. Auto-generated from OpenAPI spec using [openapi-python-client](https://github.com/openapi-generators/openapi-python-client).

## Install

```bash
pip install mapleflow
```

## Quick Start

```python
from mapleflow import Client

client = Client(
    base_url="https://mapleflow.io",
    headers={"X-API-Key": "sk_live_..."},
)
```

## Regenerate SDK

```bash
openapi-python-client generate --path ../../src/openapi.json --config config.yml --meta none --overwrite
```

## License

MIT
