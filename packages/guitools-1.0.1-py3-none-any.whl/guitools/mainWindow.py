

from typing import Callable
from PySide6.QtGui import QResizeEvent
from PySide6.QtWidgets import QMainWindow, QWidget
from .customWidgets.loadingOverlay import LoadingOverlayApp
from .customWidgets.tableWidget import TableWidget
from .customWidgets.webEngineView import WebEngineView
from .filters import CustomFilters


class MainWindow(QMainWindow):
    """
    Extended main window with custom functionalities.
    
    This class extends QMainWindow to provide additional features such as
    loading overlays, resize event connections, and WebEngineView initialization.
    """

    class CustomFilters(CustomFilters):
        """Custom event filters for the main window."""
        ...

    def __init__(self, *args, **kwargs) -> None:
        """
        Initialize the MainWindow.
        
        Args:
            *args: Variable length argument list passed to QMainWindow.
            **kwargs: Arbitrary keyword arguments passed to QMainWindow.
        """
        super().__init__(*args, **kwargs)
        # List of resize callbacks, now per instance
        self.resizedConnections: list[Callable[[], None]] = []
        self.loadingOverlayApp: LoadingOverlayApp | None = None

    # ---------------- Overlay ----------------
    def initLoadingOverlayApp(self, pid: int) -> None:
        """
        Initialize the loading overlay for the application.
        
        This method creates a LoadingOverlayApp instance if one doesn't exist.
        The overlay is used to display loading indicators over the main window.
        
        Args:
            pid: Process ID for the loading overlay.
        """
        if not self.loadingOverlayApp:
            self.loadingOverlayApp = LoadingOverlayApp(pid)

    def showLoadingOverlay(self, text: str = "") -> None:
        """
        Show the loading overlay.
        
        This method displays the loading overlay positioned over the main window.
        If the overlay hasn't been initialized, this method does nothing.
        
        Args:
            text: Optional text to display in the loading overlay.
                 Defaults to an empty string.
        """
        if not self.loadingOverlayApp:
            return
        
        # Global coordinates of the main window
        global_pos = self.mapToGlobal(self.rect().topLeft())
        x, y = global_pos.x(), global_pos.y()
        width, height = self.width(), self.height()
        self.loadingOverlayApp.start(x, y, width, height, text=text)

    def hideLoadingOverlay(self) -> None:
        """
        Hide the loading overlay.
        
        This method stops and hides the loading overlay if it exists.
        """
        if self.loadingOverlayApp:
            self.loadingOverlayApp.stop()

    def initWebEngineView(self) -> bool:
        """
        Initialize WebEngineView in the first layout found.
        
        This method searches through child widgets to find the first widget
        with a layout, then initializes a WebEngineView by temporarily
        adding and removing it from the layout. This is used to ensure
        WebEngine components are properly initialized.
        
        Returns:
            True if WebEngineView was successfully initialized, False otherwise.
        """
        for child in self.children():
            if isinstance(child, QWidget):
                layout = child.layout()
                if layout is not None:
                    webView = WebEngineView()
                    layout.addWidget(webView)
                    layout.removeWidget(webView)
                    webView.deleteLater()
                    return True
        return False
    
    def resizeEvent(self, a0: QResizeEvent) -> None:
        """
        Handle window resize events.
        
        This method is called when the window is resized. It updates table
        widget headers and calls all registered resize connection callbacks.
        
        Args:
            a0: The QResizeEvent containing information about the resize.
        """
        try:
            TableWidget.Headers.updateResize()
            for connection in self.resizedConnections:
                try:
                    connection()
                except:
                    ...
        except Exception as ex:
            print('resizeEvent', ex)

        return super().resizeEvent(a0)

    def resizeConnect(self, func: Callable[[], None]) -> None:
        """
        Connect a function to the resize event.
        
        This method registers a callback function that will be called whenever
        the window is resized. Each function is only added once, even if
        called multiple times.
        
        Args:
            func: A callable function that takes no arguments and returns None.
                 This function will be called on every window resize event.
        """
        if func not in self.resizedConnections:
            self.resizedConnections.append(func)

