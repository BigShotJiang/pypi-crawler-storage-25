
"""
Module for generating project templates using guitools.
"""
import shutil
from pathlib import Path
from typing import Optional


def getTemplatePath() -> Path:
    """
    Get the template directory path.

    Returns:
        Absolute path to the template directory.
    """
    # Try using importlib.resources (Python 3.9+, recommended modern way)
    try:
        from importlib import resources
        # For Python 3.9+
        if hasattr(resources, 'files'):
            templateTraversable = resources.files('guitools') / 'template'
            # Convert to Path
            templatePath = Path(str(templateTraversable))
            if templatePath.exists():
                return templatePath
    except (ImportError, Exception):
        pass

    # Try using pkg_resources (compatibility with older versions)
    try:
        import pkg_resources
        templateDirectory = Path(pkg_resources.resource_filename('guitools', 'template'))
        if templateDirectory.exists():
            return templateDirectory
    except (ImportError, Exception):
        pass

    # Fallback: use relative path to current file (works in development)
    currentFilePath = Path(__file__).resolve()
    guitoolsDirectory = currentFilePath.parent
    templateDirectory = guitoolsDirectory / 'template'
    return templateDirectory


def createTemplate(
    destination: str,
    projectName: Optional[str] = None,
    overwrite: bool = False
) -> bool:
    """
    Create a new project based on the guitools template.

    Args:
        destination: Path to the directory where the template will be created.
        projectName: Project name (optional, directory name will be used if not provided).
        overwrite: If True, overwrites the directory if it already exists.

    Returns:
        True if template was created successfully, False otherwise.

    Raises:
        ValueError: If destination directory already exists and overwrite is False.
        FileNotFoundError: If template is not found.
    """
    destinationPath = Path(destination).resolve()
    templatePath = getTemplatePath()

    # Check if template exists
    if not templatePath.exists():
        raise FileNotFoundError(
            f"Template not found at: {templatePath}"
        )

    # Check if destination directory already exists
    if destinationPath.exists():
        if not overwrite:
            raise ValueError(
                f"Directory '{destinationPath}' already exists. "
                "Use overwrite=True to overwrite."
            )
        # Remove existing directory if overwrite is True
        shutil.rmtree(destinationPath)

    # Create destination directory if it doesn't exist
    destinationPath.parent.mkdir(parents=True, exist_ok=True)

    # Copy template to destination
    try:
        shutil.copytree(
            templatePath,
            destinationPath,
            ignore=shutil.ignore_patterns('__pycache__', '*.pyc', '.git')
        )
        print(f"✓ Template created successfully at: {destinationPath}")
        return True
    except Exception as exception:
        print(f"✗ Error creating template: {str(exception)}")
        return False


def mainCli() -> int:
    """
    Main function for command line usage.

    Returns:
        Exit code (0 for success, 1 for error).
    """
    import argparse

    argumentParser = argparse.ArgumentParser(
        description='Create a new project based on the guitools template.',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  guitools-create my-project
  guitools-create /path/to/my-project
  guitools-create my-project --overwrite
        """
    )

    argumentParser.add_argument(
        'destination',
        type=str,
        help='Path to the directory where the template will be created'
    )

    argumentParser.add_argument(
        '--overwrite',
        action='store_true',
        help='Overwrite directory if it already exists'
    )

    parsedArgs = argumentParser.parse_args()

    try:
        wasSuccessful = createTemplate(
            destination=parsedArgs.destination,
            overwrite=parsedArgs.overwrite
        )
        if wasSuccessful:
            print(f"\nNext steps:")
            print(f"  1. Navigate to directory: {Path(parsedArgs.destination).resolve()}")
            print(f"  2. Install necessary dependencies")
            print(f"  3. Run: python main.py")
        return 0 if wasSuccessful else 1
    except Exception as exception:
        print(f"Error: {str(exception)}")
        return 1


def main_cli() -> int:
    """Setuptools console_scripts entry point (snake_case)."""
    return mainCli()


if __name__ == '__main__':
    import sys
    sys.exit(mainCli())
