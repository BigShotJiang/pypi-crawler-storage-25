

from PySide6.QtCore import QObject, QEvent
from PySide6.QtWidgets import QWidget
from ..style import Styles, Global


class CustomFilters(QObject):
    """
    Custom event filter for context menus.
    
    This filter intercepts context menu events and applies custom styling,
    particularly for dark theme icons. It caches modified icons to improve
    performance by processing them only once.
    """
    icons: dict[int, object] = {}  # Cache for modified icons

    def eventFilter(self, obj: QWidget, event: QEvent) -> bool:
        """
        Filter context menu events and apply styles.
        
        This method intercepts context menu events and creates a standard
        context menu. For dark themes, it processes and caches menu action
        icons to ensure proper styling. The modified menu is then displayed
        at the event's global position.
        
        Args:
            obj: The widget that the event is being filtered for.
            event: The event being filtered.
        
        Returns:
            True if the context menu was successfully created and displayed,
            False if no menu could be created or an error occurred.
        """
        if event.type() != QEvent.Type.ContextMenu:
            return super().eventFilter(obj, event)

        obj.blockSignals(True)
        menu = None

        try:
            # Try to create the standard context menu
            if hasattr(obj, "createStandardContextMenu"):
                menu = obj.createStandardContextMenu()
            else:
                parent = obj.parentWidget()
                if parent and hasattr(parent, "createStandardContextMenu"):
                    menu = parent.createStandardContextMenu()

            if not menu:
                return False  # No menu was created, do nothing

            # Process icons once and reuse them
            if Global.theme == Styles.TypeTheme.dark:
                for action in menu.actions():
                    icon = action.icon()
                    if not icon.isNull():
                        icon_hash = icon.cacheKey()
                        if icon_hash not in self.icons:
                            self.icons[icon_hash] = icon
                        action.setIcon(self.icons[icon_hash])

            # Display the modified menu
            menu.exec(event.globalPos())
            return True
        except:
            return False
        finally:
            obj.blockSignals(False)

