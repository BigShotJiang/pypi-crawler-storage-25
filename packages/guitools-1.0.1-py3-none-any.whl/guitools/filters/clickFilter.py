

from PySide6.QtCore import QObject, QEvent
from PySide6.QtWidgets import QFrame, QLabel, QWidget


class ClickFilter(QObject):
    """
    Event filter to block clicks on QFrame and QLabel widgets.
    
    This filter intercepts mouse button events (press, double-click, and release)
    for QFrame and QLabel widgets and blocks them, preventing these widgets
    from receiving click events.
    """
    
    def __init__(self, *args, **kwargs) -> None:
        """
        Initialize the ClickFilter.
        
        Args:
            *args: Variable length argument list passed to QObject.
            **kwargs: Arbitrary keyword arguments passed to QObject.
        """
        super().__init__(*args, **kwargs)
        
    def eventFilter(self, obj: QObject | QWidget, event: QEvent) -> bool:
        """
        Filter events for QFrame and QLabel widgets.
        
        This method intercepts mouse button events (press, double-click, release)
        and blocks them if the target object is a QFrame or QLabel.
        
        Args:
            obj: The object that the event is being filtered for.
            event: The event being filtered.
        
        Returns:
            True if the event should be blocked (for QFrame/QLabel mouse events),
            otherwise returns the result of the parent class eventFilter.
        """
        event_type = event.type()
        if event_type in (QEvent.Type.MouseButtonPress, QEvent.Type.MouseButtonDblClick, QEvent.Type.MouseButtonRelease):
            if isinstance(obj, (QFrame, QLabel)):
                return True
        return super().eventFilter(obj, event)

