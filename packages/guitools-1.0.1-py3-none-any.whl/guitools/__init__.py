# coding: utf-8
"""guitools — Qt utilities built on PySide6.

Recommended: explicit subpackage imports
(``from guitools.utils import Utils``, ``from guitools.core import ClickFilter, MainWindow``,
``from guitools.style import Styles``, ``from guitools.thread import Thread``,
``from guitools.customWidgets import ComboBox``).

``Utils`` is also re-exported from ``guitools.core`` for compatibility.
You may import several symbols from the package root (``Msg``, ``Styles``, ``Utils``, etc.).

Modules not listed in ``__all__`` are not considered a stable public API unless
documented otherwise.
"""
from __future__ import annotations

from .animation import Animation
from .mainWindow import MainWindow
from .filters import ClickFilter
from .utils import GUIUtils
from .memoryManager import MemoryManager
from .msg import Msg
from .notification import Notification
from .style import Styles
from .templateGenerator import createTemplate
from .thread import Thread
from .layout import Layout
from .dialog import Dialog

__all__ = [
    'Animation',
    'ClickFilter',
    'Dialog',
    'Layout',
    'MainWindow',
    'MemoryManager',
    'Msg',
    'Notification',
    'Styles',
    'GUIUtils',
    'createTemplate',
    'Thread'
]