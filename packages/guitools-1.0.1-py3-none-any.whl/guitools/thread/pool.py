

import queue
from typing import Callable
from PySide6.QtCore import (
    QObject,
    QThreadPool,
    Signal,
    Slot,
    QTimer,
    QCoreApplication
)
from .base import Worker, WorkerResponse


class Processing(QObject):
    """
    Processing using QThreadPool for function execution.
    """
    targetCallbackSignal = Signal(object)
    
    def __init__(self, target: Callable, updateFunc: Callable | None = None, callback: Callable | None = None, interval: int = 1, globalInstance: bool = False, wait: bool = False, initialize: bool = True) -> None:
        """
        Initialize Processing.
        
        Args:
            target: Target function to execute.
            updateFunc: Optional update function to call periodically. Defaults to None.
            callback: Optional callback function for results. Defaults to None.
            interval: Update interval in seconds. Defaults to 1.
            globalInstance: Whether to use global thread pool instance. Defaults to False.
            wait: Whether to wait for completion. Defaults to False.
            initialize: Whether to start immediately. Defaults to True.
        """
        application = QCoreApplication.instance()
        super().__init__(parent=application)
        self.target = target
        self.updateFunc = updateFunc
        self.callback = callback
        self.interval = interval * 1000  

        if globalInstance:
            self.threadpool = QThreadPool.globalInstance()
        else:
            self.threadpool = QThreadPool()

        if callback:
            self.targetCallbackSignal.connect(self.callback)

        if initialize:
            self.start()
            if wait:
                self.threadpool.waitForDone()
                    
        if self.updateFunc and not wait:
            self.timer = QTimer()
            self.timer.timeout.connect(self.updateFunc)
            self.timer.start(self.interval)

    def start(self) -> None:
        """
        Start processing.
        """
        targetWorker = Worker(self.target)
        targetWorker.signals.result.connect(self.handleResult)
        targetWorker.signals.finished.connect(self.deleteLater)
        self.threadpool.start(targetWorker)

    @Slot(object)
    def handleResult(self, result: WorkerResponse) -> None:
        """
        Handle worker result.
        
        Args:
            result: WorkerResponse object with result or error.
        """
        self.targetCallbackSignal.emit(result)


class Multiprocessing(QObject):
    """
    Multiprocessing using QThreadPool for parallel execution.
    """
    finalSignal = Signal()
    targetCallbackSignal = Signal(object)

    def __init__(self, args: list, target: Callable, targetCallback: Callable | None = None, finalCallback: Callable | None = None, maxThreads: int = 5, globalInstance: bool = False, wait: bool = False, initialize: bool = True) -> None:
        """
        Initialize Multiprocessing.
        
        Args:
            args: List of arguments to process.
            target: Target function to execute.
            targetCallback: Optional callback for each result. Defaults to None.
            finalCallback: Optional callback when all tasks complete. Defaults to None.
            maxThreads: Maximum number of threads. Defaults to 5.
            globalInstance: Whether to use global thread pool instance. Defaults to False.
            wait: Whether to wait for completion. Defaults to False.
            initialize: Whether to start immediately. Defaults to True.
        """
        application = QCoreApplication.instance()
        super().__init__(parent=application)
        self.target = target
        self.finalCallback = finalCallback
        self.targetCallback = targetCallback
        self.maxThreads = maxThreads

        self.taskQueue = queue.Queue()
        for taskArg in args:
            self.taskQueue.put(taskArg)

        if globalInstance:
            self.threadpool = QThreadPool.globalInstance()
        else:
            self.threadpool = QThreadPool()
        self.threadpool.setMaxThreadCount(maxThreads)

        self.activeThreads = 0

        if finalCallback:
            self.finalSignal.connect(self.finalCallback)
        if targetCallback:
            self.targetCallbackSignal.connect(self.targetCallback)

        if initialize:
            self.start()
            if wait:
                self.threadpool.waitForDone()

    def start(self) -> None:
        """
        Start multiprocessing.
        """
        for _ in range(min(self.maxThreads, self.taskQueue.qsize())):
            self.startNextTask()

    def startNextTask(self) -> None:
        """
        Start the next task in the queue.
        """
        if not self.taskQueue.empty():
            taskArg = self.taskQueue.get()
            taskWorker = Worker(self.target, taskArg)

            taskWorker.signals.result.connect(self.handleResult)
            taskWorker.signals.finished.connect(self.handleFinished)

            self.activeThreads += 1
            self.threadpool.start(taskWorker)

    @Slot(object)
    def handleResult(self, result: WorkerResponse) -> None:
        """
        Handle result from each worker.
        
        Args:
            result: WorkerResponse object with result or error.
        """
        self.targetCallbackSignal.emit(result)

    @Slot()
    def handleFinished(self) -> None:
        """
        Handle worker completion and start next task.
        """
        self.activeThreads -= 1
        if not self.taskQueue.empty():
            self.startNextTask()
        elif self.activeThreads == 0:
            self.finalSignal.emit()
            self.deleteLater()

