

import asyncio
import traceback
from typing import Callable, TypeVar, Generic, Optional
from functools import partial
from PySide6.QtCore import QObject, QRunnable, Signal

T = TypeVar("T")


class WorkerResponse(Generic[T]):
    """
    Generic worker response with result or error.
    """
    def __init__(self, result: Optional[T] = None, error: Optional[Exception] = None):
        """
        Initialize WorkerResponse.
        
        Args:
            result: Optional result value. Defaults to None.
            error: Optional exception. Defaults to None.
        """
        self.result: Optional[T] = result
        self.error: Optional[Exception] = error
        self.traceback: Optional[str] = traceback.format_exc() if error else None

    @property
    def success(self) -> bool:
        """
        Check if the worker execution was successful.
        
        Returns:
            True if no error occurred, False otherwise.
        """
        return self.error is None


class WorkerSignals(QObject):
    """
    Signals for communication between worker and main thread.
    """
    result = Signal(object)
    finished = Signal()


class Worker(QRunnable):
    """
    Base worker using QThreadPool for execution of synchronous and asynchronous functions.
    """
    def __init__(self, func: Callable | partial, *arg) -> None:
        """
        Initialize Worker.
        
        Args:
            func: Function or partial to execute.
            *arg: Variable arguments to pass to the function.
        """
        super().__init__()
        self.func = func
        self.arg = arg
        self.signals = WorkerSignals()
        self.isAsync: bool = False

    def run(self) -> None:
        """
        Execute the worker function.
        """
        if isinstance(self.func, partial):
            self.isAsync = asyncio.iscoroutinefunction(self.func.func)
        else:
            self.isAsync = asyncio.iscoroutinefunction(self.func)

        try:
            if self.isAsync:
                eventLoop = asyncio.new_event_loop()
                asyncio.set_event_loop(eventLoop)
                functionResult = eventLoop.run_until_complete(self.func(self.arg[0])) if self.arg else eventLoop.run_until_complete(self.func())
                eventLoop.close()
            else:
                functionResult = self.func(self.arg[0]) if self.arg else self.func()
            workerResponse = WorkerResponse(result=functionResult)
        except Exception as exception:
            workerResponse = WorkerResponse(result=None, error=exception)

        self.signals.result.emit(workerResponse)
        self.signals.finished.emit()

