

import threading
import asyncio
import inspect
from PySide6.QtCore import QTimer, QObject, Signal
from threading import Event
from queue import Queue
from functools import partial


class Thread(object):
    """
    Main class for thread management.
    """

    @staticmethod
    def new(targetFunction: object, **kwargs) -> 'Thread.Processing':
        """
        Convenience method to create a Processing instance.
        
        Args:
            targetFunction: Target function to execute.
            **kwargs: Additional keyword arguments.
        
        Returns:
            Thread.Processing instance.
        """
        return Thread.Processing(targetFunction, **kwargs)

    @staticmethod
    def isThreadAlive() -> bool:
        """
        Check if there are non-daemon threads running.
        
        Returns:
            True if non-daemon threads are alive, False otherwise.
        """
        for currentThread in threading.enumerate():
            if currentThread.is_alive() and currentThread != threading.current_thread():
                if not currentThread.daemon and currentThread.name != ['ThreadPoolExecutor-0_0']:
                    if 'asyncio_' not in currentThread.name and 'ThreadPoolExecutor-' not in currentThread.name:
                        print(currentThread.name)
                        return True
        return False

    class Processing(QObject):
        """
        Processing of a single function in a separate thread.
        """
        signalFunctionExecuted = Signal()

        def __init__(self, targetFunction: object, updateFunction: object | None = None, callbackFunction: object | None = None, daemon: bool = True, interval: int = 1000, resultToCallback: bool = False, initialize: bool = True, wait: bool = False) -> None:
            """
            Initialize Processing.
            
            Args:
                targetFunction: Target function to execute.
                updateFunction: Optional update function to call periodically. Defaults to None.
                callbackFunction: Optional callback function. Defaults to None.
                daemon: Whether thread is daemon. Defaults to True.
                interval: Update interval in milliseconds. Defaults to 1000.
                resultToCallback: Whether to pass result to callback. Defaults to False.
                initialize: Whether to start immediately. Defaults to True.
                wait: Whether to wait for completion. Defaults to False.
            """
            super().__init__()

            self.signalFunctionExecuted.connect(lambda: self.threadFinished())
            self.targetFunction = targetFunction
            self.resultTarget = None
            self.updateFunction = updateFunction
            self.callbackFunction = callbackFunction
            self.interval = interval
            self.resultToCallback = resultToCallback
            
            if isinstance(targetFunction, partial):
                self.isAsync = inspect.iscoroutinefunction(targetFunction.func)
            else:
                self.isAsync = inspect.iscoroutinefunction(targetFunction)
         
            if self.updateFunction:
                self.timer = QTimer()
                self.timer.timeout.connect(self.executeUpdateFunction)

            self.thread: threading.Thread | None = None
            self.daemon = daemon

            if initialize:
                self.start()

            if wait:
                self.join()

        def executeUpdateFunction(self) -> None:
            """
            Execute the update function.
            """
            if self.updateFunction:
                self.updateFunction()

        def start(self) -> None:
            """
            Start the thread.
            """
            if self.isAsync:
                self.thread = threading.Thread(target=asyncio.run, args=(self.asyncExecuteTargetFunction(),))
            else:
                self.thread = threading.Thread(target=self.executeTargetFunction)
            self.thread.daemon = self.daemon
            self.thread.start()
            
            if self.updateFunction:
                self.timer.start(self.interval)

        def executeTargetFunction(self) -> None:
            """
            Execute the target function synchronously.
            """
            self.resultTarget = self.targetFunction()

            try:
                self.signalFunctionExecuted.emit()
            except: 
                ...

        async def asyncExecuteTargetFunction(self) -> None:
            """
            Execute the target function asynchronously.
            """
            self.resultTarget = await self.targetFunction()

            try:
                self.signalFunctionExecuted.emit()
            except: 
                ...

        def threadFinished(self) -> None:
            """
            Callback when thread finishes.
            """
            if self.updateFunction:
                self.timer.disconnect()
                self.timer.stop()
            if self.callbackFunction:
                if self.resultToCallback:
                    self.callbackFunction(self.resultTarget)
                else:
                    self.callbackFunction()

            self.thread = None

        def isAlive(self) -> bool:
            """
            Check if thread is alive.
            
            Returns:
                True if thread is alive, False otherwise.
            """
            if self.thread:
                return self.thread.is_alive()
            return False

        def join(self) -> None:
            """
            Wait for thread to finish.
            """
            if self.thread:
                self.thread.join()

    class Multiprocessing(object):
        """
        Parallel processing of multiple functions.
        """

        def __init__(self, listaArgs: list, targetFunction: object, updateFunction: object | None = None, callbackFunction: object | None = None, callbackTask: object | None = None, daemon: bool = True, interval: int = 1000, nThreads: int = 5, wait: bool = False, initialize: bool = True) -> None:
            """
            Initialize Multiprocessing.
            
            Args:
                listaArgs: List of arguments to process.
                targetFunction: Target function to execute.
                updateFunction: Optional update function. Defaults to None.
                callbackFunction: Optional callback for each task. Defaults to None.
                callbackTask: Optional callback when all tasks complete. Defaults to None.
                daemon: Whether threads are daemon. Defaults to True.
                interval: Update interval in milliseconds. Defaults to 1000.
                nThreads: Number of threads. Defaults to 5.
                wait: Whether to wait for completion. Defaults to False.
                initialize: Whether to start immediately. Defaults to True.
            """
            self.typeArgs = str
            if listaArgs:
                self.typeArgs = type(listaArgs[0])

            self.event = Event()
            self.targetFunction = targetFunction
            self.updateFunction = updateFunction
            self.callbackFunction = callbackFunction
            self.callbackTask = callbackTask
            self._alreadyCallCallbackTask = False
            self.interval = interval
            self.daemon = daemon
            
            if isinstance(targetFunction, partial):
                self.isAsync = inspect.iscoroutinefunction(targetFunction.func)
            else:
                self.isAsync = inspect.iscoroutinefunction(targetFunction)
         
            self.taskQueue = Queue(maxsize=len(listaArgs) + 1)
            for taskArg in listaArgs:
                self.taskQueue.put(taskArg)

            self.event.set()
            self.taskQueue.put('Kill')

            if len(listaArgs) < nThreads:
                nThreads = len(listaArgs)

            self.threads = self.getPool(nThreads)
            if initialize:
                self.start()

            if wait:
                self.join()

        def start(self) -> None:
            """
            Start all threads.
            """
            [thread.start() for thread in self.threads]

        def join(self) -> None:
            """
            Wait for all threads to finish.
            """
            [thread.join() for thread in self.threads]

        def runCallbackTask(self) -> None:
            """
            Execute callback when all threads finish.
            """
            for thread in self.threads:
                if thread.isAlive():
                    return

            if self.callbackTask and not self._alreadyCallCallbackTask:
                self.callbackTask()
                self._alreadyCallCallbackTask = True

        def getPool(self, numThreads: int) -> list['Thread.Multiprocessing.ThreadedFunctionRunner']:
            """
            Get a pool of n threads.
            
            Args:
                numThreads: Number of threads to create.
            
            Returns:
                List of ThreadedFunctionRunner instances.
            """
            return [self.ThreadedFunctionRunner(
                event=self.event,
                queue=self.taskQueue,
                targetFunction=self.targetFunction,
                updateFunction=self.updateFunction,
                callbackFunction=self.callbackFunction,
                daemon=self.daemon,
                interval=self.interval,
                isAsync=self.isAsync,
                callbackTask=self.runCallbackTask
            ) for _ in range(numThreads)]

        class ThreadedFunctionRunner(QObject):
            """
            Function runner in thread for multiprocessing.
            """
            signalFunctionExecuted = Signal(object)

            def __init__(self, event: Event, queue: Queue, targetFunction: object, updateFunction: object | None, callbackFunction: object | None, daemon: bool, interval: int, isAsync: bool, callbackTask: object) -> None:
                """
                Initialize ThreadedFunctionRunner.
                
                Args:
                    event: Event for synchronization.
                    queue: Queue for task distribution.
                    targetFunction: Target function to execute.
                    updateFunction: Optional update function. Defaults to None.
                    callbackFunction: Optional callback function. Defaults to None.
                    daemon: Whether thread is daemon.
                    interval: Update interval in milliseconds.
                    isAsync: Whether function is async.
                    callbackTask: Callback task function.
                """
                super().__init__()
                
                self.signalFunctionExecuted.connect(self.threadFinished)
                self.event = event
                self.queue = queue
                self.targetFunction = targetFunction
                self.updateFunction = updateFunction
                self.callbackFunction = callbackFunction
                self.interval = interval
                self.stopped = False
                self.daemon = daemon
                self.isAsync = isAsync
                self.callbackTask = callbackTask

                if self.updateFunction:
                    self.timer = QTimer()
                    self.timer.timeout.connect(self.executeUpdateFunction)

                self.runnerThread: threading.Thread | None = None
             
            def executeUpdateFunction(self) -> None:
                """
                Execute the update function.
                """
                if self.updateFunction and self.runnerThread and hasattr(self.runnerThread, 'args'):
                    self.updateFunction(*self.runnerThread.args)

            def start(self) -> None:
                """
                Start the runner.
                """
                if self.isAsync:
                    self.runnerThread = self.AsyncWorker(self.asyncExecuteTargetFunction, self.queue, self.event)
                else:
                    self.runnerThread = self.Worker(self.executeTargetFunction, self.queue, self.event)
                self.runnerThread.daemon = self.daemon
                self.runnerThread.start()
               
                if self.updateFunction:
                    self.timer.start(self.interval)

            def join(self) -> None:
                """
                Wait for runner to finish.
                """
                if self.runnerThread:
                    self.runnerThread.join()

            def isAlive(self) -> bool:
                """
                Check if runner is alive.
                
                Returns:
                    True if runner is alive, False otherwise.
                """
                if self.runnerThread:
                    return self.runnerThread.is_alive()
                return False

            async def asyncExecuteTargetFunction(self, *args) -> None:
                """
                Execute the target function asynchronously.
                
                Args:
                    *args: Variable arguments for the function.
                """
                functionResult = await self.targetFunction(*args)
                if functionResult:
                    if type(functionResult) != list and type(functionResult) != tuple:
                        functionResult = [functionResult]
                    self.signalFunctionExecuted.emit(*functionResult)
                else:
                    functionArgs = args
                    if type(functionArgs) != list and type(functionArgs) != tuple:
                        functionArgs = [functionArgs]
                    self.signalFunctionExecuted.emit(*functionArgs)

            def executeTargetFunction(self, *args) -> None:
                """
                Execute the target function synchronously.
                
                Args:
                    *args: Variable arguments for the function.
                """
                functionResult = self.targetFunction(*args)
                if functionResult:
                    if type(functionResult) != list and type(functionResult) != tuple:
                        functionResult = [functionResult]
                    self.signalFunctionExecuted.emit(*functionResult)
                else:
                    functionArgs = args
                    if type(functionArgs) != list and type(functionArgs) != tuple:
                        functionArgs = [functionArgs]
                    self.signalFunctionExecuted.emit(*functionArgs)

            def threadFinished(self, *args) -> None:
                """
                Callback when thread finishes.
                
                Args:
                    *args: Variable arguments from function execution.
                """
                if self.updateFunction:
                    self.timer.disconnect()
                    self.timer.stop()
                if self.callbackFunction:
                    self.callbackFunction(*args)
                self.runnerThread = None
                self.callbackTask()

            class AsyncWorker(threading.Thread):
                """
                Async worker for thread processing.
                """
                def __init__(self, asyncTargetFunction: object, queue: Queue, event: Event) -> None:
                    """
                    Initialize AsyncWorker.
                    
                    Args:
                        asyncTargetFunction: Async target function.
                        queue: Queue for task distribution.
                        event: Event for synchronization.
                    """
                    super().__init__()
                    self.asyncTargetFunction = asyncTargetFunction
                    self.queue = queue
                    self.event = event
                    self._stopped = False
                    self.args: list = []

                async def asyncRun(self) -> None:
                    """
                    Execute the async loop.
                    """
                    self.event.wait()
                    while not self.queue.empty():
                        task = self.queue.get()

                        if task == 'Kill':
                            self.queue.put(task)
                            self._stopped = True
                            break

                        if isinstance(task, (list, tuple)):
                            self.args = task
                        else:
                            self.args = [task]

                        await self.asyncTargetFunction(*self.args)

                def run(self) -> None:
                    """
                    Start the async loop.
                    """
                    asyncio.run(self.asyncRun())

            class Worker(threading.Thread):
                """
                Synchronous worker for thread processing.
                """
                def __init__(self, targetFunction: object, queue: Queue, event: Event) -> None:
                    """
                    Initialize Worker.
                    
                    Args:
                        targetFunction: Target function to execute.
                        queue: Queue for task distribution.
                        event: Event for synchronization.
                    """
                    super().__init__()
                    self.targetFunction = targetFunction
                    self.queue = queue
                    self.event = event
                    self._stopped = False
                    self.args: list = []

                def run(self) -> None:
                    """
                    Execute the processing loop.
                    """
                    self.event.wait()
                    while not self.queue.empty():
                        task = self.queue.get()

                        if task == 'Kill':
                            self.queue.put(task)
                            self._stopped = True
                            break
                   
                        if isinstance(task, (list, tuple)):
                            self.args = task
                        else:
                            self.args = [task]

                        self.targetFunction(*self.args)

