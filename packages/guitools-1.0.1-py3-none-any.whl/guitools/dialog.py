
from PySide6.QtWidgets import QFileDialog, QWidget
from PySide6.QtCore import QStandardPaths
import pathlib, os

class Dialog(object):
    """
    Dialog utilities for file and directory selection.
    """

    class Extensions(object):
        """
        File extension constants for dialogs.
        """
        PY_FILE = "Arquivos python (*.py)"

        VB_FILE = "Arquivos vb.net (*.vb)"

        CS_FILE = "Arquivos c# (*.cs)"

        PDF_FILE = "Arquivos PDF (*.pdf)"

        ALL_FILE = "Todos os arquivos (*)"

        PY_PROJ = "Projetos python (*.pyproj)"

        VB_PROJ = "Projetos python (*.vbproj)"

        CS_PROJ = "Projetos python (*.csproj)"

        SLN = "Solutions (*.sln)"

        @classmethod
        def get(cls, file: str) -> str:
            """
            Get extension filter string based on file extension.
            
            Args:
                file: File path or name.
            
            Returns:
                Extension filter string.
            """
            if file.endswith(".cs"):
                return cls.CS_FILE
            elif file.endswith(".vb"):
                return cls.VB_FILE
            elif file.endswith(".py"):
                return cls.PY_FILE
            return cls.ALL_FILE

    @staticmethod
    def saveFileName(parent: QWidget, title: str, extensao: str, name: str = "", initialDir: str | None = None) -> tuple[str, str]:
        """
        Show save file dialog.
        
        Args:
            parent: Parent widget.
            title: Dialog title.
            extensao: File extension filter.
            name: Default file name. Defaults to "".
            initialDir: Initial directory. Defaults to None (uses Desktop).
        
        Returns:
            Tuple of (selected file path, selected filter).
        """
        fileDialog = QFileDialog()
        if not initialDir:
            initialDir = QStandardPaths.writableLocation(QStandardPaths.StandardLocation.DesktopLocation)
        fileDialog.setDirectory(initialDir)

        dialogOptions = fileDialog.options()
        return fileDialog.getSaveFileName(parent, title, name, extensao, options=dialogOptions)

    @staticmethod
    def openFileName(parent: QWidget, title: str, extensions: list[str] = [Extensions.ALL_FILE], useFilter: bool = False, multipleSelection: bool = False, initialDir: str | None = None) -> tuple[str, str] | tuple[list[str], str]:
        """
        Show open file dialog.
        
        Args:
            parent: Parent widget.
            title: Dialog title.
            extensions: List of extension filters. Defaults to [Extensions.ALL_FILE].
            useFilter: Whether to use combined filter. Defaults to False.
            multipleSelection: Whether to allow multiple file selection. Defaults to False.
            initialDir: Initial directory. Defaults to None (uses Desktop).
        
        Returns:
            Tuple of (selected file path(s), selected filter) or (list of paths, filter) if multipleSelection.
        """
        fileDialog = QFileDialog()
        if not initialDir:
            initialDir = QStandardPaths.writableLocation(QStandardPaths.StandardLocation.DesktopLocation)
        fileDialog.setDirectory(initialDir)

        dialogOptions = fileDialog.options()
        fileDialog.setFileMode(QFileDialog.FileMode.ExistingFiles)
    
        openFileFunction = fileDialog.getOpenFileNames if multipleSelection else fileDialog.getOpenFileName

        if useFilter:
            # Define filter to accept multiple extensions
            combinedFilter = "Arquivos ("
            for extension in extensions:
                extensionPart = extension.split("(")[1].replace(")", "")
                combinedFilter += f"{extensionPart};"
            combinedFilter += ')'
    
            return openFileFunction(parent, title, "", combinedFilter, options=dialogOptions)
        else:
            return openFileFunction(parent, title, "", ";;".join(extensions), options=dialogOptions)

    @staticmethod
    def openDirectory(parent: QWidget, title: str, initialDir: str | None = None, name: str = "") -> str:
        """
        Show open directory dialog.
        
        Args:
            parent: Parent widget.
            title: Dialog title.
            initialDir: Initial directory. Defaults to None (uses Desktop).
            name: Default directory name. Defaults to "".
        
        Returns:
            Selected directory path.
        """
        fileDialog = QFileDialog()
        fileDialog.setFileMode(QFileDialog.FileMode.Directory)

        if not initialDir:
            initialDir = QStandardPaths.writableLocation(QStandardPaths.StandardLocation.DesktopLocation)

        fileDialog.setDirectory(initialDir)
        dialogOptions = fileDialog.options()
        
        return fileDialog.getExistingDirectory(parent, title, name, options=dialogOptions)

    @staticmethod
    def extensions(types: list[dict[str, str]]) -> list[str]:
        """
        Create extension filter list from type definitions.
        
        Args:
            types: List of dictionaries with 'title' and 'extension' keys.
                   Example: [{'title': 'Arquivos python', 'extension': 'py'}, ...]
        
        Returns:
            List of extension filter strings.
        """
        return [f"{extensionType['title']} (*.{extensionType['extension']})" for extensionType in types]

    @staticmethod
    def extension(title: str, extension: str) -> str:
        """
        Create extension filter string.
        
        Args:
            title: Filter title.
            extension: File extension.
        
        Returns:
            Extension filter string.
        """
        return f"{title} (*.{extension})"

    @staticmethod
    def isForbiddenFolder(folder: str) -> bool:
        """
        Check if a folder is forbidden (root drive or system default folders).
        
        Args:
            folder: Folder path to check.
        
        Returns:
            True if folder is forbidden, False otherwise.
        """
        normalizedFolderPath = os.path.normpath(folder)
        
        # Block root drives (C:\, D:\ etc.)
        if pathlib.Path(normalizedFolderPath).parent == pathlib.Path(normalizedFolderPath):
            return True

        # Block system default folders
        systemForbiddenLocations = [
            QStandardPaths.writableLocation(QStandardPaths.StandardLocation.DesktopLocation),
            QStandardPaths.writableLocation(QStandardPaths.StandardLocation.DocumentsLocation),
            QStandardPaths.writableLocation(QStandardPaths.StandardLocation.DownloadLocation),
            QStandardPaths.writableLocation(QStandardPaths.StandardLocation.PicturesLocation),
            QStandardPaths.writableLocation(QStandardPaths.StandardLocation.MusicLocation),
            QStandardPaths.writableLocation(QStandardPaths.StandardLocation.MoviesLocation),
            QStandardPaths.writableLocation(QStandardPaths.StandardLocation.HomeLocation)
        ]

        normalizedFolderPathLower = normalizedFolderPath.lower()
        for systemLocation in systemForbiddenLocations:
            if os.path.normpath(systemLocation).lower() == normalizedFolderPathLower:
                return True

        return False
