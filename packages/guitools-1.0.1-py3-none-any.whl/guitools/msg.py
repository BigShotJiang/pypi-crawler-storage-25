

from PySide6.QtWidgets import QMessageBox, QApplication
from PySide6.QtGui import QIcon


def clearFocus() -> None:
    """
    Clear focus from the currently focused widget.
    """
    focusedWidget = QApplication.focusWidget()
    if focusedWidget:
        focusedWidget.clearFocus()

class Msg(object):
    """
    Message box utilities for displaying information, errors, confirmations, and choices.
    """

    WindowIcon : QIcon = None

    @classmethod
    def getIcon(cls, windowIcon: QIcon | None) -> QIcon:
        """
        Get icon for message box, using provided icon, class icon, or default.
        
        Args:
            windowIcon: Optional window icon. Defaults to None.
        
        Returns:
            QIcon to use for the message box.
        """
        if not windowIcon:
            if cls.WindowIcon:
                return cls.WindowIcon
            from .style import Styles

            return Styles.Resources.miniLogo.original()
        return windowIcon

    @staticmethod
    def pNowrap(text: str) -> str:
        """
        Wrap text in HTML paragraph with no-wrap style.
        
        Args:
            text: Text to wrap.
        
        Returns:
            HTML formatted string with no-wrap style.
        """
        return f"<p style='white-space: nowrap;'> {text} </p>"
        
    @classmethod
    def information(cls, texto: str, texto2: str | None = None, windowIcon: QIcon | None = None) -> None:
        """
        Show information message box.
        
        Args:
            texto: Main message text.
            texto2: Optional informative text. Defaults to None.
            windowIcon: Optional window icon. Defaults to None.
        """
        clearFocus()
        messageBox = QMessageBox()
        messageBox.setWindowTitle('Information')
        messageBox.setWindowIcon(cls.getIcon(windowIcon))
        messageBox.setIcon(QMessageBox.Icon.Information)
        messageBox.setText(texto)
        messageBox.setInformativeText(texto2)
        messageBox.exec()

    @classmethod
    def error(cls, texto: str, texto2: str | None = None, windowIcon: QIcon | None = None) -> None:
        """
        Show error message box.
        
        Args:
            texto: Main error message text.
            texto2: Optional informative text. Defaults to None.
            windowIcon: Optional window icon. Defaults to None.
        """
        clearFocus()
        messageBox = QMessageBox()
        messageBox.setWindowTitle('Error')
        messageBox.setWindowIcon(cls.getIcon(windowIcon))
        messageBox.setIcon(QMessageBox.Icon.Critical)
        messageBox.setText(texto)
        messageBox.setInformativeText(texto2)
        messageBox.exec()

    @classmethod
    def confirmation(cls, textoButaoS: str, texto: str, texto2: str | None = None, windowIcon: QIcon | None = None) -> bool | None:
        """
        Show confirmation message box with Yes/No buttons.
        
        Args:
            textoButaoS: Text for the Yes button.
            texto: Main message text.
            texto2: Optional informative text. Defaults to None.
            windowIcon: Optional window icon. Defaults to None.
        
        Returns:
            True if Yes was clicked, None otherwise.
        """
        clearFocus()
        messageBox = QMessageBox()
        messageBox.setWindowTitle('Information')
        messageBox.setWindowIcon(cls.getIcon(windowIcon))

        messageBox.setIcon(QMessageBox.Icon.Information)
        messageBox.setText(texto)
        messageBox.setInformativeText(texto2)
        messageBox.setStandardButtons(QMessageBox.StandardButton.Yes | 
                         QMessageBox.StandardButton.No)

        noButton = messageBox.button(QMessageBox.StandardButton.No)
        yesButton = messageBox.button(QMessageBox.StandardButton.Yes)
        yesButton.setText(textoButaoS)
   
        noButton.setText("Ok")

        userResponse = messageBox.exec()

        if userResponse == QMessageBox.StandardButton.Yes:
            return True
        return None

    @classmethod
    def choice(cls, textoButaoS: str, texto: str, texto2: str | None = None, windowIcon: QIcon | None = None) -> bool | None:
        """
        Show choice message box with Yes/Cancel buttons.
        
        Args:
            textoButaoS: Text for the Yes button.
            texto: Main message text.
            texto2: Optional informative text. Defaults to None.
            windowIcon: Optional window icon. Defaults to None.
        
        Returns:
            True if Yes was clicked, None otherwise.
        """
        clearFocus()
        messageBox = QMessageBox()
        messageBox.setWindowTitle('Choice')
        messageBox.setWindowIcon(cls.getIcon(windowIcon))
        messageBox.setIcon(QMessageBox.Icon.Question)
        messageBox.setText(texto)
        messageBox.setInformativeText(texto2)
        messageBox.setStandardButtons(QMessageBox.StandardButton.Yes | 
                         QMessageBox.StandardButton.No)

        cancelButton = messageBox.button(QMessageBox.StandardButton.No)
        yesButton = messageBox.button(QMessageBox.StandardButton.Yes)
        yesButton.setText(textoButaoS)
        cancelButton.setText("Cancel")

        userResponse = messageBox.exec()

        if userResponse == QMessageBox.StandardButton.Yes:
            return True
        return None


