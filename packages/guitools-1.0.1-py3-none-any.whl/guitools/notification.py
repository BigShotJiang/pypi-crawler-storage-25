
from .style import Styles
from PySide6.QtGui import  QIcon
import io
import PIL.Image as Image
from os import path, makedirs
from winotify import audio
from winotify import Notification as WinNotification
from tempfile import gettempdir
from PySide6.QtCore import Qt, QTimer, QPropertyAnimation, QRect, QEasingCurve, QSize, QObject, SignalInstance, QBuffer, QIODevice, QEvent, QPoint
from PySide6.QtWidgets import QLabel, QHBoxLayout, QPushButton, QWidget, QVBoxLayout, QFrame, QApplication, QMainWindow, QDockWidget
from typing import Literal, Callable
from enum import Enum
from .customWidgets.resizeLabel import ResizeLabel
from pydantic import BaseModel, Field
from datetime import datetime
from uuid import uuid4

class SystemNotificationData(object):
    """
    System notification data container.
    """
    def __init__(self, imageName: str, callableIcon: Callable) -> None:
        """
        Initialize SystemNotificationData.
        
        Args:
            imageName: Name of the image file.
            callableIcon: Callable that returns the icon.
        """
        self.imageName = imageName
        self.callableIcon = callableIcon

dataNotification = {'Standard': SystemNotificationData('LogoStandard', Styles.Resources.miniLogo.original)}

class Notification(QObject):
    """
    Notification system for displaying system and application notifications.
    """

    class NotificationType(Enum):
        """
        Notification type enumeration.
        """
        Information  = 'information'
        Error = 'error'
        Success = 'success'
        System = 'system'

    class NotificationData(BaseModel):
        """
        Notification data model.
        """
        guid : str = Field(..., description="Unique identifier")
        date : datetime = Field(..., description="Notification date")
        local : str = Field(..., description="Notification location")
        title : str = Field(..., description="Notification title")
        message : str = Field(..., description="Notification message")
        type : str = Field(..., description="Notification type")

    @classmethod
    def createData(cls, local: str, title: str, message: str, type: str) -> 'Notification.NotificationData':
        """
        Create notification data object.
        
        Args:
            local: Notification location.
            title: Notification title.
            message: Notification message.
            type: Notification type.
        
        Returns:
            NotificationData object.
        """
        return cls.NotificationData(guid=f'notification-{uuid4()}', date=datetime.now(), local=local, title=title, message=message, type=type)

    signalNotification: SignalInstance | None = None
    class Widget(QWidget):
        """
        Notification widget for displaying application notifications.
        """

        class StyleSheet(Styles.Standard.StyleSheet):
            """
            Stylesheet for notification widget.
            """
            def __init__(self, color: Styles.Color | str = Styles.Color.division) -> None:
                """
                Initialize StyleSheet.
                
                Args:
                    color: Border color. Defaults to Styles.Color.division.
                """
                super().__init__()
                self.borderColor: Styles.Color | str = color

            def style(self) -> str:
                """
                Generate stylesheet string.
                
                Returns:
                    Complete stylesheet string.
                """
                notificationStyle = f'''
                #NotificationWidget {{border: 1px solid {self.borderColor}}}
                #NotificationWidget, #NotificationWidget QLabel, #NotificationWidget QFrame {{background-color: {Styles.Color.primary}; border-radius: 10px;}}
                {Styles.button(transparent=True)}
                '''

                return f'{Styles.standard()} {notificationStyle}'
          
        def __init__(self, title: str, message: str, duration: int, type_: 'Notification.NotificationType', targetWidget: QWidget | None = None) -> None:
            """
            Initialize Notification Widget.
            
            Args:
                title: Notification title.
                message: Notification message.
                duration: Display duration in milliseconds.
                type_: Notification type.
                targetWidget: Optional target widget. Defaults to None.
            """
            super().__init__(None)
            self.mouseOver = False
            self.targetWidget = targetWidget
            self.parentWidget = self.getParentWidget()
            self.topWindow = self.parentWidget.window()
          
            # Install event filters
            self.topWindow.installEventFilter(self)
            self.destroyed.connect(lambda obj=self: self.topWindow.removeEventFilter(obj))
            if self.targetWidget:
                self.targetWidget.installEventFilter(self)
                self.destroyed.connect(lambda obj=self: self.targetWidget.removeEventFilter(obj))
        
            # ------------------------------------------------------------------
            # Visual configuration
            # ------------------------------------------------------------------
            self.setParent(self.topWindow)
            self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Tool)
            self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
            self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)

            self.isHidden = False
            self.visibleTime = 0
            self.duration = duration

            # Structure
            notificationFrame = QFrame(self)
            notificationFrame.setObjectName("NotificationWidget")

            mainLayout = QVBoxLayout(notificationFrame)
            mainLayout.setContentsMargins(10, 10, 10, 10)
            mainLayout.setSpacing(5)

            titleLayout = QHBoxLayout()
            titleLabel = QLabel(title)
            titleLabel.setStyleSheet('font: 63 12pt "Segoe UI Semibold"')
            titleLayout.addWidget(titleLabel)

            closeButton = QPushButton()
            closeButton.setFixedSize(20, 20)
            closeButton.setIconSize(QSize(12, 12))
            closeButton.setCursor(Qt.CursorShape.PointingHandCursor)
            Styles.setIcon(closeButton, Styles.Resources.close.gray, Styles.Resources.close.theme)
            closeButton.clicked.connect(self.close)
            titleLayout.addWidget(closeButton)

            mainLayout.addLayout(titleLayout)

            messageLabel = ResizeLabel(message)
            messageLabel.setMaximumWidth(800)
            mainLayout.addWidget(messageLabel)

            containerLayout = QVBoxLayout(self)
            containerLayout.setContentsMargins(0, 0, 0, 0)
            containerLayout.addWidget(notificationFrame)

            borderColor = Styles.Color.division
            if type_.value == Notification.NotificationType.Error.value:
                borderColor = 'rgba(255, 0, 0, 0.3)'
            elif type_.value == Notification.NotificationType.Success.value:
                borderColor = 'rgba(0, 255, 0, 0.3)'

            Styles.setWidgetStyleTheme(self.StyleSheet(borderColor), self)

            self.adjustSize()

            # ------------------------------------------------------------------
            # Animations and timer
            # ------------------------------------------------------------------
            self.initAnimations()

            self.timer = QTimer(self)
            self.timer.timeout.connect(self.tick)
            self.timer.start(1000)

            # Show notification
            self.updatePosition()
            self.startOpeningAnimation()
            self.raise_()

            if self.targetWidget and not self.targetWidget.isVisible():
                self.hide()
            else:
                self.show()

        # ----------------------------------------------------------------------
        # Get parent widget
        # ----------------------------------------------------------------------
        def getParentWidget(self) -> QWidget | None:
            """
            Get the parent widget for the notification.
            
            Returns:
                Parent widget or None if not found.
            """
            application = QApplication.instance()
            if not application:
                return None
            
            foundDockWidget: QDockWidget | None = None
            foundMainWindow: QMainWindow | None = None
            for topLevelWidget in application.topLevelWidgets():
                if isinstance(topLevelWidget, QDockWidget):
                    foundDockWidget = topLevelWidget
                if isinstance(topLevelWidget, QMainWindow):
                    centralWidget = topLevelWidget.centralWidget()
                    if centralWidget:
                        foundMainWindow = centralWidget
                    foundMainWindow = topLevelWidget
                    break
            
            if foundDockWidget and foundDockWidget.isActiveWindow():
                return foundDockWidget
            elif foundDockWidget and foundDockWidget.isVisible() and foundMainWindow and not foundMainWindow.isActiveWindow():
                return foundDockWidget
            return foundMainWindow

        # ----------------------------------------------------------------------
        # Event filters
        # ----------------------------------------------------------------------
        def eventFilter(self, watched: QObject, event: QEvent) -> bool:
            """
            Filter events for the notification widget.
            
            Args:
                watched: The object being watched.
                event: The event.
            
            Returns:
                True if event was handled, False otherwise.
            """
            if watched == self.topWindow:
                if event.type() in (QEvent.Type.Resize, QEvent.Type.Move):
                    self.updatePosition()
                elif event.type() == QEvent.Type.Show and not self.targetWidget:
                    self.show()
                    self.updatePosition()
                elif event.type() == QEvent.Type.Hide and not self.targetWidget:
                    self.hide()
            elif self.targetWidget and watched == self.targetWidget:
                if event.type() == QEvent.Type.Show:
                    self.show()
                    self.updatePosition()
                elif event.type() == QEvent.Type.Hide:
                    self.hide()
          
            return super().eventFilter(watched, event)

        # ----------------------------------------------------------------------
        # Animations
        # ----------------------------------------------------------------------
        def initAnimations(self) -> None:
            """
            Initialize opening and closing animations.
            """
            self.openingAnimation = QPropertyAnimation(self, b"geometry")
            self.openingAnimation.setDuration(600)
            self.openingAnimation.setEasingCurve(QEasingCurve.Type.OutCubic)

            self.closingAnimation = QPropertyAnimation(self, b"windowOpacity")
            self.closingAnimation.setDuration(500)
            self.closingAnimation.setEasingCurve(QEasingCurve.Type.OutQuad)
            self.closingAnimation.finished.connect(self.deleteLater)

        def startOpeningAnimation(self) -> None:
            """
            Start the opening animation.
            """
            parentGeometry = self.topWindow.geometry()
            xPosition = parentGeometry.x() + (parentGeometry.width() - self.width()) // 2
            yPosition = parentGeometry.y() + 10 
            self.move(xPosition, parentGeometry.y() - 10)

            # Configure entry animation: slide down from top to correct position
            notificationWidth = min(self.geometry().width(), 600)
            finalRect = QRect(xPosition, yPosition, notificationWidth, self.geometry().height())
            startRect = QRect(xPosition, parentGeometry.y() - 10, notificationWidth, self.geometry().height())
            self.setGeometry(startRect)

            self.openingAnimation.setStartValue(startRect)
            self.openingAnimation.setEndValue(finalRect)
            self.openingAnimation.start()

        def startClosingAnimation(self) -> None:
            """
            Start the closing animation.
            """
            self.closingAnimation.setStartValue(1.0)
            self.closingAnimation.setEndValue(0.0)
            self.closingAnimation.start()

        def close(self) -> None:
            """
            Close the notification with animation.
            """
            self.startClosingAnimation()

        # ----------------------------------------------------------------------
        # Mouse events
        # ----------------------------------------------------------------------
        def enterEvent(self, event: QEvent) -> None:
            """
            Handle mouse enter event.
            
            Args:
                event: Mouse enter event.
            """
            self.mouseOver = True
            return super().enterEvent(event)

        def leaveEvent(self, event: QEvent) -> None:
            """
            Handle mouse leave event.
            
            Args:
                event: Mouse leave event.
            """
            self.mouseOver = False
            return super().leaveEvent(event)

        # ----------------------------------------------------------------------
        # Visible time control
        # ----------------------------------------------------------------------
        def tick(self) -> None:
            """
            Timer tick handler for auto-closing notification.
            """
            if self.isVisible():
                self.visibleTime += 1000
                if self.visibleTime >= self.duration and not self.mouseOver:
                    self.startClosingAnimation()

        # ----------------------------------------------------------------------
        # Positioning
        # ----------------------------------------------------------------------
        def updatePosition(self) -> None:
            """
            Update notification position relative to parent window.
            """
            # Get global position of topWindow
            parentGeometry = self.topWindow.geometry()
            xPosition = parentGeometry.x() + (parentGeometry.width() - self.width()) // 2
            yPosition = parentGeometry.y() + 20 
            self.move(xPosition, yPosition)
            self.adjustSize()
               

    @classmethod
    def convertIconToImg(cls, icon: QIcon, savePath: str | None = None, saveName: str = "image", size: QSize | None = None, fmt: str = "png") -> None:
        """
        Convert QIcon to image file.
        
        Args:
            icon: Icon to convert.
            savePath: Optional save path. Defaults to None.
            saveName: Image file name. Defaults to "image".
            size: Optional icon size. Defaults to None.
            fmt: Image format. Defaults to "png".
        """
        if size is None:
            size = icon.availableSizes()[0]
    
        iconPixmap = icon.pixmap(size)
    
        # Convert QPixmap to QImage to preserve transparency
        qImage = iconPixmap.toImage()
    
        # Create buffer to save image as bytes
        imageBuffer = QBuffer()
        imageBuffer.open(QIODevice.OpenModeFlag.WriteOnly)
        qImage.save(imageBuffer, fmt)
        imageBuffer.close()
    
        # Create PIL image from bytes
        pilImage = Image.open(io.BytesIO(imageBuffer.data()))
    
        if savePath:
            pilImage.save(path.join(savePath, f"{saveName}.{fmt}"))
        else:
            pilImage.save(f"{saveName}.{fmt}")

    @classmethod
    def setSystemData(cls, appName: str, imageName: str, callableIcon: Callable) -> None:
        """
        Set system notification data for an app.
        
        Args:
            appName: Application name.
            imageName: Image file name.
            callableIcon: Callable that returns the icon.
        """
        dataNotification[appName] = SystemNotificationData(imageName, callableIcon)

    @classmethod
    def system(cls, *, local: str, title: str, message: str, duration: Literal["short", "long"] = "short", appName: str = 'GUIAppStandard', register: bool = True) -> None:
        """
        Show system notification (Windows toast).
        
        Args:
            local: Notification location.
            title: Notification title.
            message: Notification message.
            duration: Notification duration. Defaults to "short".
            appName: Application name. Defaults to 'GUIAppStandard'.
            register: Whether to register notification. Defaults to True.
        """
        if cls.signalNotification and register:
            cls.signalNotification.emit(cls.createData(local, title, message, cls.NotificationType.System.value))
        tempDirectory = gettempdir()
        tempFolderPath = path.join(tempDirectory, 'GUIApps')

        if not path.exists(tempFolderPath):
            makedirs(tempFolderPath)

        if appName in dataNotification:
            notificationData = dataNotification[appName]
        else:
            notificationData = dataNotification['Standard']

        tempImagePath = path.join(tempFolderPath, f"{notificationData.imageName}.png")
        if not path.exists(tempImagePath):
            try:
                notificationIcon = notificationData.callableIcon()
                cls.convertIconToImg(notificationIcon, savePath=tempFolderPath, saveName=notificationData.imageName, fmt='png')
            except Exception as exception:
                print(exception)
                ...
            if not path.exists(tempImagePath):
                tempImagePath = ""

        systemToast = WinNotification(app_id=appName,
                                 title=title,
                            msg=message,
                            duration=duration,
                            icon=tempImagePath
                            )
        systemToast.set_audio(audio.Default, loop=False)
        #toast.add_actions(label="Click here", launch="https://google.com")
        systemToast.show()

    @classmethod
    def information(cls, *, local: str, title: str, message: str, duration: int = 5000, register: bool = False, targetWidget: QWidget | None = None) -> None:
        """
        Show information notification.
        
        Args:
            local: Notification location.
            title: Notification title.
            message: Notification message.
            duration: Display duration in milliseconds. Defaults to 5000.
            register: Whether to register notification. Defaults to False.
            targetWidget: Optional target widget. Defaults to None.
        """
        if cls.signalNotification and register:
            cls.signalNotification.emit(cls.createData(local, title, message, cls.NotificationType.Information.value))
        cls.Widget(title, message, duration, cls.NotificationType.Information, targetWidget)

    @classmethod
    def error(cls, *, local: str, title: str, message: str, duration: int = 5000, register: bool = True, targetWidget: QWidget | None = None) -> None:
        """
        Show error notification.
        
        Args:
            local: Notification location.
            title: Notification title.
            message: Notification message.
            duration: Display duration in milliseconds. Defaults to 5000.
            register: Whether to register notification. Defaults to True.
            targetWidget: Optional target widget. Defaults to None.
        """
        if cls.signalNotification and register:
            cls.signalNotification.emit(cls.createData(local, title, message, cls.NotificationType.Error.value))
        cls.Widget(title, message, duration, cls.NotificationType.Error, targetWidget)

    @classmethod
    def success(cls, *, local: str, title: str, message: str, duration: int = 5000, register: bool = True, targetWidget: QWidget | None = None) -> None:
        """
        Show success notification.
        
        Args:
            local: Notification location.
            title: Notification title.
            message: Notification message.
            duration: Display duration in milliseconds. Defaults to 5000.
            register: Whether to register notification. Defaults to True.
            targetWidget: Optional target widget. Defaults to None.
        """
        if cls.signalNotification and register:
            cls.signalNotification.emit(cls.createData(local, title, message, cls.NotificationType.Success.value))
        cls.Widget(title, message, duration, cls.NotificationType.Success, targetWidget)