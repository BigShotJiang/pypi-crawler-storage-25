
import sys
from PySide6.QtWidgets import QApplication, QSplashScreen
from PySide6.QtCore import QEvent
from guitools.msg import Msg
from guitools.notification import Notification
from guitools.thread import Thread
from .views.main import MainView
from .controllers.main import MainController
from asyncslot import AsyncSlotRunner

class Window(MainView, MainController):

    def __init__(self, app : QApplication, splash : QSplashScreen | None, *args, obj=None, **kwargs):
          super(Window, self).__init__(*args, **kwargs)
          with AsyncSlotRunner():
               self.setupUi(self)

               filters = self.CustomFilters()
               app.installEventFilter(filters)
               #self.initLoadingOverlayApp(os.getpid())
               self.init()
               self.resize(1200, 700)
               if splash:
                    splash.finish(self)
               self.showMaximized()
               self.clearFocus()
               
               sys.exit(app.exec())
   
    def closeEvent(self, event : QEvent):
          if Thread.isThreadAlive():
               Notification.information(
                    "Background Processes",
                    "There are processes running in the background. Please wait a moment before closing the application."
               )
               event.ignore()
          else:
               if Msg.choice(
                    "Exit",
                    "Are you sure you want to exit the application?"
               ):
                    for widget in QApplication.topLevelWidgets():
                         if widget is not self: 
                              widget.close()
                    event.accept()
               else:
                    event.ignore()