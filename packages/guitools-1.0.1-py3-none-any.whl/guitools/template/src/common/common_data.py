from pydantic import BaseModel
from typing import Union, Any, Optional, Set, Literal, Type
from pydantic import BaseModel, Field, ConfigDict, PrivateAttr
from pathlib import Path
import json
from datetime import datetime
from dataclasses import asdict
from abc import ABC
import copy

class AppSettings(BaseModel):
    ApiKey : str = ""

class EnvVarKeys:
    app_settings = 'AppSettings'