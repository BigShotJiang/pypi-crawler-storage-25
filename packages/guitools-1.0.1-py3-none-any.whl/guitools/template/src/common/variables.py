
from guitools.utils import Utils
from .common_data import AppSettings

class GlobalApp:

    name = "Template"

    @staticmethod
    def window():
        from ..window import Window
        mainWindow : Window = Utils.mainWindow()
        return mainWindow
    
    class Data(object):
        app_settings : AppSettings = AppSettings(ApiKey="")
