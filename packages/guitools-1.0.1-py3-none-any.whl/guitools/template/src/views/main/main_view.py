
from guitools import MainWindow
from guitools.msg import Msg
from guitools.style import Global as GlobalStyles
from guitools.style import Styles
from .styles import CentralwidgetStyleSheet
from .ui.UiMain import Ui_MainWindow
from ...models import localDatabase
from PySide6.QtCore import Signal, Qt
from PySide6.QtWidgets import QVBoxLayout, QLabel, QSizePolicy, QWidget
from guitools import Notification
from ...common.variables import GlobalApp
from datetime import datetime

class MainView(MainWindow, Ui_MainWindow):

     class TabWidgetCornerWidgetFiles(QWidget):
          def __init__(self, parent=None):
               super().__init__(parent=parent)

               layout = QVBoxLayout()
               layout.setContentsMargins(10, 0, 5, 5)
               layout.setSpacing(0)

               label_versions = QLabel("Files")
               label_versions.setStyleSheet('font: 10pt "Segoe UI";')

               # Let the label expand horizontally
               label_versions.setSizePolicy(QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred))
               label_versions.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)

               layout.addWidget(label_versions)
               layout.addStretch()  # Optional: extra vertical fill
               self.setLayout(layout)

               # Let this corner widget expand horizontally too
               self.setSizePolicy(QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred))


     signal_update_model = Signal(str, bool)
     signal_update_agent = Signal()
     signal_update_agent_model = Signal(object, bool)
     signal_update_toos = Signal()
     signal_update_mcp = Signal(str, bool)
     signal_update_database = Signal(str, bool)
     loaded = Signal()
     def setupUi(self, MainWindow):
          super().setupUi(MainWindow)

          GlobalStyles.theme = localDatabase.get_theme()

          Notification.setSystemData(GlobalApp.name, "agent_flow", Styles.Resources.agent_flow.blue)
          self.setWindowIcon(Styles.Resources.agent_flow.original())
          Msg.WindowIcon = Styles.Resources.agent_flow.original()

          company_name = "Virtualnauta"
          slogan = "Innovating the Future of Technology"
          label_text = (
               f"<p style='font-size:14px;'>"
               f"<strong>{company_name}</strong> &copy; {datetime.now().year} - {slogan}"
               f"</p>"
          )

          self.label_company.setText(label_text)

          self.frame_menu_lateral.close()

          Styles.setIcon_toggle_theme(self.btn_tema)
          Styles.setWidgetStyleTheme(CentralwidgetStyleSheet(), self)
          self.clearFocus()

     def toggle_theme(self):
          theme = Styles.opposite_theme()
          Styles.load(theme)
          localDatabase.update_theme(theme)
          Styles.setIcon_toggle_theme(self.btn_tema)

