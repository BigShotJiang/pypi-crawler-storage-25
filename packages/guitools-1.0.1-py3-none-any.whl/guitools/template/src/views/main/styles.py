
from guitools.style import Styles


class VarStyles:
     divisao_folder = "rgba(245, 200, 95, 0.25)"
     divisao_file = "rgba(0, 170, 255, 0.25)"

class HeaderViewStyleSheet(Styles.headerView):
    def __init__(self):
        super().__init__()
        self.section_horizontal_pushButton.backgroundColor = self.section_horizontal.backgroundColor

class TreeViewStyleSheet(Styles.treeView):
    def __init__(self):
        super().__init__()
        self.pushButtonHover = self.PushButtonHover()
      
    class PushButtonHover(Styles.StyleSheet):
        def __init__(self, prefix=""):
            super().__init__('QPushButton:hover', f"{prefix} QTreeView")
            self.backgroundColor = Styles.Property.BackgroundColor('transparent')
            self.border = Styles.Property.Border(color='transparent')

    class PushButton(Styles.StyleSheet):
        def __init__(self, prefix=""):
            super().__init__('QPushButton', f"{prefix} QTreeView")
            self.border = Styles.Property.Border(radius=0)
            self.margin = Styles.Property.Margin(value=0)

class TabWidgetStyleSheet(Styles.tabWidget):
    def __init__(self):
        super().__init__()
        self.pane.border = Styles.Property.Border(color=Styles.Color.division, topLeftRadius=0, topRightRadius=0, bottomLeftRadius=5, bottomRightRadius=5, top=1)
        self.tab_bar.left.value = 10

Styles.Standard.button = Styles.button(transparent=True)
Styles.Standard.headerView = HeaderViewStyleSheet()
Styles.Standard.tabWidget = TabWidgetStyleSheet()
Styles.Standard.treeView = TreeViewStyleSheet()

class CentralwidgetStyleSheet(Styles.WidgetStyleSheet):
     def __init__(self):
          super().__init__()

     def style(self):

          style = f'''
               #frame_main, #frame_menu_lateral {{border-top: 1px solid {Styles.Color.division} ; border-radius: 0px;}}
               #frame_menu_lateral {{border-right: 1px solid {Styles.Color.division} ; border-radius: 0px; background-color: {Styles.Color.Menu.background }; }}
               #frame_menu_lateral QFrame {{background-color: {Styles.Color.Menu.background };}}
               #frame_footer {{border-top: 1px solid {Styles.Color.division} ; border-radius: 0px; background-color: {Styles.Color.primary};}}
               #frame_footer QFrame {{background-color: {Styles.Color.primary};}}
               #frame_btn_save {{ border-left: 1px solid {Styles.Color.division.verticalGradient([0, 0.1, 0.9, 1])} border-radius: 0px;}}
          '''

          return f'{Styles.standard()} {style}'

