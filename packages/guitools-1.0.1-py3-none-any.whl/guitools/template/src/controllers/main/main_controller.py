
from ...common.variables import GlobalApp
from ...models import asyncLocalDatabase
from ...views.main import MainView
from typing import Union
from guitools.customWidgets import SideBar
from guitools.style import Styles
import asyncio
from asyncslot import asyncSlot
import os

Self = Union['MainController', MainView]

class MainController(object):

     def init(self : Self):
          self.loaded.connect(self.load)

          self.create_side_bar()
          asyncSlot(self.async_load_data)()
          self.btn_tema.clicked.connect(self.toggle_theme)

     def load(self):
          ...

     async def async_load_data(self : Self):

          if asyncLocalDatabase.is_new_database:
               try:
                    ...
               except Exception as ex:
                    print(str(ex))
   
          app_settings = await asyncLocalDatabase.get_app_settings()
          GlobalApp.Data.app_settings = app_settings
    
     def create_side_bar(self : Self):

          self.side_bar = SideBar(self.frame_menu_lateral, self.stackedWidget, Styles.Resources.miniLogo.original, False)
          self.side_bar.setTitle('<span style="color: rgb(28,124,188);">Agent</span><span style="color: rgb(132,188,228);">Flow</span>') 

          #self.page_example = self.side_bar.addPage(self.callable_page_example, "Example", Styles.Resources.miniLogo.gray, Styles.Resources.miniLogo.blue, expandable=True)
      
          self.side_bar.setIcon(Styles.Resources.miniLogo.original())
          

     def callable_page_example(self):
          from ..example.example_controller import ExampleView, ExampleController
          return ExampleView, ExampleController
     
