
from dapper_sqls.sqlite import BaseAsyncLocalDatabase
from sqlalchemy import select, insert, outerjoin
from .tables import Tables
from ...common.common_data import EnvVarKeys, AppSettings, ModelLLM, MCPServerModel,AgentModel, ToolModel
import json
from collections import defaultdict

class AsyncLocalDatabase(BaseAsyncLocalDatabase):
     def __init__(self, app_name: str, path : str, is_new_database : bool, insistent_tables : list[str]):
          super().__init__(app_name, path, is_new_database, insistent_tables)

     async def get_app_settings(self):
          data = await self.get_var(EnvVarKeys.app_settings)
          if data:
               return AppSettings(**json.loads(data))
          return AppSettings()

