
from dapper_sqls.sqlite import DataBaseInstall
from .local import LocalDatabase
from .async_local import AsyncLocalDatabase
from .tables import Tables, TableChat
from os import path, getcwd

db_path = path.join(getcwd(), 'db', "virtualnauta")

installer = DataBaseInstall('agent_flow', tables=Tables, path_local_database=path.join(getcwd(), 'db'),database_name=f"virtualnautaAI", database_folder_name = 'virtualnauta')
localDatabase : LocalDatabase = installer.instance(LocalDatabase)
asyncLocalDatabase  : AsyncLocalDatabase = installer.instance(AsyncLocalDatabase)
