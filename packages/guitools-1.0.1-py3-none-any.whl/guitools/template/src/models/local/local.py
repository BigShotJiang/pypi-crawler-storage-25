
from dapper_sqls.sqlite import BaseLocalDatabase, safe_sqlite_operation
from ...common.common_data import EnvVarKeys, AppSettings, ModelLLM, MCPServerModel, AgentModel, ToolModel
import json
from sqlalchemy import insert, delete, update, select, outerjoin
from .tables import Tables
from collections import defaultdict

class LocalDatabase(BaseLocalDatabase):

     def __init__(self, app_name : str, path : str, is_new_database : bool, insistent_tables : list[str]):
          super().__init__(app_name, path, is_new_database, insistent_tables)

     def get_app_settings(self):
          data = self.get_var(EnvVarKeys.app_settings)
          if data:
               return AppSettings(**json.loads(data))
          return AppSettings()
     
     def update_app_settings(self, app_settings : AppSettings):
          self.update_var(EnvVarKeys.app_settings, json.dumps(app_settings.model_dump()))

