
from dapper_sqls.sqlite import BaseTables 
from sqlalchemy import Table, Integer, Column, String, Boolean, MetaData, DateTime, func, ForeignKey

class Tables(BaseTables):

    models_llms = Table(
        'models_llms',
        BaseTables.meta_data,
        Column('id', Integer, primary_key=True),
        Column('App', String), 
        Column('Name', String, unique=True), 
        Column('BaseUrl', String, nullable=True),
        Column('Provider', String),
        Column('ParallelToolCalls', Boolean),
        Column('Temperature', String),
        Column('TopP', String),
        Column('PresencePenalty', String),
        Column('FrequencyPenalty', String),
        Column('MaxTokens', String)
    )

    mcp_servers = Table(
        'mcp_servers',
        BaseTables.meta_data,
        Column('id', Integer, primary_key=True),
        Column('App', String), 
        Column('Name', String, unique=True), 
        Column('Url', String),
        Column('ApiKey', String, nullable=True), 
        Column('Token', String, nullable=True), 
        Column('Category', String)
    )

    agents = Table(
        'agents',
        BaseTables.meta_data,
        Column('id', Integer, primary_key=True),
        Column('App', String), 
        Column('Name', String), 
        Column('Slug', String),
        Column('Guid', String, unique=True),
        Column('Instructions', String),
        Column('Variables', String),
        Column('Category', String),
        Column('Model', String),
        Column('MCPServers', String),
        Column('UpdatedAt', DateTime, server_default=func.now(), onupdate=func.now()),
    )

    sub_agent = Table(
        'sub_agent',
        BaseTables.meta_data,
        Column('id', Integer, primary_key=True),
        Column('App', String), 
        Column('AgentGuid', String),
        Column('Name', String), 
        Column('Slug', String),
        Column('Guid', String, unique=True),
        Column('Instructions', String),
        Column('Model', String),
        Column('HandoffDescription', String),
        Column('Variables', String),
        Column('MCPServers', String),
        Column('UpdatedAt', DateTime, server_default=func.now(), onupdate=func.now()),
    )

    agent_tools = Table(
        'agent_tools',
        BaseTables.meta_data,
        Column('id', Integer, primary_key=True),
        Column('App', String), 
        Column('AgentGuid', String, unique=True),
        Column('DalleTool', String),
        Column('VisionTool', String),
        Column('OcrTool', String),
        Column('WebSearchTool', String),
        Column('DataBaseTool', String),
        Column('UpdatedAt', DateTime, server_default=func.now(), onupdate=func.now()),
    )


class TableChat:
    meta_data = MetaData()

    chat_messages = Table(
        'chat_messages',
        meta_data,
        Column('id', Integer, primary_key=True),
        Column('Discontinued', Boolean, nullable=True),
        Column('App', String), 
        Column('Guid', String, unique=True),
        Column('ParentGuid', Integer, ForeignKey('chat_messages.Guid'), nullable=True),
        Column('UserId', String), 
        Column('ResponseId', Integer), 
        Column('AudioId', String, nullable=True),
        Column('UserInput', String),
        Column('AgentOutput', String),
        Column('Message', String),
        Column('Success', String),
        Column('Cancelled', String),
        Column('Date', String),
    )
    
    chat_auth = Table(
        'chat_auth',
        meta_data,
        Column('id', Integer, primary_key=True),
        Column('DataBase', String),
        Column('Column', String),
        Column('Value', String),
        Column('App', String)
    )

    chat_login = Table(
        'chat_login',
        meta_data,
        Column('id', Integer, primary_key=True),
        Column('Value', String),
        Column('App', String)
    )
    
    