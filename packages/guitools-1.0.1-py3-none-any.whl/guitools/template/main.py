                                           
import sys                                                
from PySide6.QtWidgets import QApplication, QSplashScreen 
from PySide6.QtGui import QPixmap                         
import os  

if __name__ == '__main__':                                
    application = QApplication(sys.argv)                  
    splash_path = None                                    
    splash = None                                         
    if os.path.exists("img/logo.png"):                    
        splash_path = "img/logo.png"                      
    elif os.path.exists("_internal/img/logo.png"):        
        splash_path = "_internal/img/logo.png"            
    if splash_path:                                       
        splash_pix = QPixmap(splash_path)                 
        splash = QSplashScreen(splash_pix)                
        splash.show()                                     
    from src import Window                                
    Window(application, splash)