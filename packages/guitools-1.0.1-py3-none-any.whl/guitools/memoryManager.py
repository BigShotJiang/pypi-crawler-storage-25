

import gc
from PySide6.QtWidgets import QWidget, QLayout

class MemoryManager:
    """
    Memory management utilities for widgets and variables.
    """
    def __init__(self) -> None:
        """
        Initialize MemoryManager.
        """
        self.trackedVariables: dict[str, object] = {}

    def trackVariable(self, name: str, variable: object) -> None:
        """
        Store a reference to a variable for easier removal later.
        
        Args:
            name: Variable name.
            variable: Variable object to track.
        """
        self.trackedVariables[name] = variable

    def removeVariable(self, name: str) -> None:
        """
        Remove a tracked variable and clean up memory.
        
        Args:
            name: Variable name to remove.
        """
        if name in self.trackedVariables:
            del self.trackedVariables[name]
            gc.collect()

    def clearVariables(self) -> None:
        """
        Remove all tracked variables and clean up memory.
        """
        self.trackedVariables.clear()
        gc.collect()

    def removeWidget(self, widget: QWidget) -> None:
        """
        Remove a widget from the interface and clean up memory.
        
        Args:
            widget: Widget to remove.
        """
        if widget is not None:
            widget.setParent(None)
            widget.deleteLater()
            #gc.collect()

    def clearLayout(self, layout: QLayout, removeItems: bool = False) -> None:
        """
        Remove all widgets from a layout and clean up memory.
        
        Args:
            layout: Layout to clear.
            removeItems: Whether to remove items. Defaults to False.
        """
        if layout:
            while layout.count():
                layoutItem = layout.takeAt(0)
                itemWidget = layoutItem.widget()
                if itemWidget is not None:
                    self.removeWidget(itemWidget)
                else:
                    if removeItems:
                        layout.removeItem(layoutItem)

    def freeMemory(self) -> None:
        """
        Force garbage collection to free memory.
        """
        gc.collect()
    