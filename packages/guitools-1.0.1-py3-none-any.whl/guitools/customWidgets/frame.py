
from PySide6.QtWidgets import QFrame, QStackedWidget, QPushButton, QVBoxLayout, QHBoxLayout, QSplitter, QTextBrowser, QTextEdit, QLineEdit
from PySide6.QtCore import Qt, SignalInstance
from ..style import Styles

class Frame(object):
    """
    Utility class for frame-related operations.
    """

    class Expandable:
        """
        A class that makes a frame expandable/collapsible within a stacked widget.
        
        This allows a frame to be toggled between its normal position and a maximized
        view within a stacked widget, with optional signals for maximizing and minimizing.
        """
        def __init__(self, frame: QFrame, stackedWidget: QStackedWidget, btnToggle: QPushButton, contentsMargins: list[int] = [0, 0, 0, 0], maximizing: SignalInstance | None = None, minimizing: SignalInstance | None = None) -> None:
            """
            Initialize the Expandable frame wrapper.
            
            Args:
                frame: The QFrame to make expandable.
                stackedWidget: The QStackedWidget to use for expansion.
                btnToggle: The button that toggles expansion.
                contentsMargins: Margins for the expanded page. Defaults to [0, 0, 0, 0].
                maximizing: Signal to emit when maximizing. Defaults to None.
                minimizing: Signal to emit when minimizing. Defaults to None.
            """
            self.frame: QFrame = frame
            self.stackedWidget: QStackedWidget = stackedWidget
            self.btnToggle: QPushButton = btnToggle
            self.originalContentsMargins = frame.layout().contentsMargins()
            self.contentsMargins: list[int] = contentsMargins
            self.maximizing: SignalInstance | None = maximizing
            self.minimizing: SignalInstance | None = minimizing

            self.pageExpand = QFrame()
            self.pageExpand.setObjectName('PageToggleExpand')
            expandLayout = QVBoxLayout(self.pageExpand)
            expandLayout.setContentsMargins(*self.contentsMargins)
            
            # Detect the parent's layout or splitter
            parentWidget = frame.parentWidget()
            self.parentWidget: QSplitter | QVBoxLayout | QHBoxLayout = parentWidget
            if not isinstance(parentWidget, QSplitter):
                self.parentWidget = parentWidget.layout()
            self.index = self.parentWidget.indexOf(self.frame)
        
            # Connect the button to the toggle method
            btnToggle.clicked.connect(lambda: self.toggle())
            Styles.setIcon(self.btnToggle, Styles.Resources.fullScreen.gray, Styles.Resources.fullScreen.select)
            self.btnToggle.setCursor(Qt.CursorShape.PointingHandCursor)

        def toggle(self) -> None:
            """
            Toggle between expanded and collapsed states.
            """
            self.btnToggle.leaveEvent(None)

            if self.pageExpand == self.stackedWidget.currentWidget():
                if self.minimizing:
                    self.minimizing.emit()
                Styles.setIcon(self.btnToggle, Styles.Resources.fullScreen.gray, Styles.Resources.fullScreen.select)

                self.pageExpand.layout().removeWidget(self.frame)
                self.frame.setParent(None)

                self.parentWidget.insertWidget(self.index, self.frame)

                self.frame.layout().setContentsMargins(self.originalContentsMargins)
                self.stackedWidget.removeWidget(self.pageExpand)
                self.pageExpand.setParent(None)
            else:
                if self.maximizing:
                    self.maximizing.emit()
                Styles.setIcon(self.btnToggle, Styles.Resources.exitFullScreen.gray, Styles.Resources.exitFullScreen.select)

                self.parentWidget.removeWidget(self.frame)
                self.frame.setParent(None)

                self.pageExpand.layout().addWidget(self.frame)
                self.frame.layout().setContentsMargins(0,0,0,0)

                self.stackedWidget.addWidget(self.pageExpand)
                self.stackedWidget.setCurrentWidget(self.pageExpand)

                self.focusFirstInput()

        def focusFirstInput(self) -> None:
            """
            Focus the first input widget found in the frame.
            """
            for widgetClass in [QTextEdit, QLineEdit, QTextBrowser]:
                inputWidget = self.frame.findChild(widgetClass)
                if inputWidget:
                    inputWidget.setFocus()
                    break