

from PySide6.QtWidgets import QComboBox, QHBoxLayout
from .base import DataUpdate
from .types import TypeComboBox
from .utils import ignoreWheelEvent, addData, updateData, update
from .standard import ComboBoxCheckable, ComboBoxUncheck
from .checkable import CheckableComboBox

class ComboBox:
    """
    Main ComboBox class that groups all combo box functionalities.
    
    This class provides static methods and nested classes for working with
    various types of combo boxes, including checkable, uncheckable, and
    custom implementations.
    """

    class Checkable(ComboBoxCheckable):
        ...

    class Uncheck(ComboBoxUncheck):
        ...
    
    class TypeComboBox(TypeComboBox):
        """Combo box type enumeration."""
        ...

    class DataUpdate(DataUpdate):
        """Data structure for updating combo box items."""
        ...

    @staticmethod
    def ignoreWheelEvent(comboBox: QComboBox) -> None:
        """
        Configure a combo box to ignore wheel events.
        
        Args:
            comboBox: The combo box to configure.
        """
        ignoreWheelEvent(comboBox)

    @staticmethod
    def addData(comboBox: QComboBox, newData: DataUpdate) -> None:
        """
        Add items from a DataUpdate object to a combo box.
        
        Args:
            comboBox: The combo box to add items to.
            newData: The DataUpdate object containing items to add.
        """
        addData(comboBox, newData)

    @staticmethod
    def updateData(comboBox: QComboBox, newData: DataUpdate, itemSelectAll: bool = False, forceUpdate: bool = False) -> None:
        """
        Update combo box items from a DataUpdate object.
        
        Args:
            comboBox: The combo box to update.
            newData: The DataUpdate object containing the new items.
            itemSelectAll: Whether the combo box has a select all item at index 0.
                         Defaults to False.
            forceUpdate: If True, clear all items before adding new ones.
                        Defaults to False.
        """
        updateData(comboBox, newData, itemSelectAll, forceUpdate)

    @staticmethod
    def update(comboBox: QComboBox, newData: list[str] | dict[str], itemSelectAll: bool = False) -> None:
        """
        Update combo box items from a list or dictionary.
        
        Args:
            comboBox: The combo box to update.
            newData: Either a list of text strings or a dictionary mapping text to icons.
            itemSelectAll: Whether the combo box has a select all item at index 0.
                         Defaults to False.
        """
        update(comboBox, newData, itemSelectAll)

    @classmethod
    def New(cls, typeComboBox: TypeComboBox, horizontalLayout: QHBoxLayout, fixedText: str | None = None, size: int | None = None) -> ComboBoxCheckable | ComboBoxUncheck:
        """
        Create a new combo box instance and add it to a layout.
        
        Args:
            typeComboBox: The type of combo box to create (Checkable or Uncheck).
            horizontalLayout: The layout to add the combo box to.
            fixedText: Optional fixed text to display in the combo box.
                     Defaults to None.
            size: Optional fixed width for the combo box. Defaults to None.
        
        Returns:
            The created combo box instance (ComboBoxCheckable or ComboBoxUncheck).
        """
        if typeComboBox == TypeComboBox.Checkable:
            comboBox = ComboBoxCheckable()
        else:
            comboBox = ComboBoxUncheck()

        if fixedText:
            comboBox.setFixedText(fixedText)

        if size:
            comboBox.setMaximumWidth(size)
            comboBox.setMinimumWidth(size)

        horizontalLayout.addWidget(comboBox)
        return comboBox

__all__ = [
    'ComboBox',
    'CheckableComboBox',
    'ComboBoxCheckable',
    'ComboBoxUncheck',
    'DataUpdate',
    'TypeComboBox',
]

