

class TypeComboBox:
    """
    Enumeration of combo box types.
    
    This class provides constants for different types of combo boxes
    that can be created using the ComboBox.New() method.
    """
    
    Checkable = "Checkable"
    """Checkable combo box type with selectable items."""
    
    Uncheck = 'Uncheck'
    """Uncheckable combo box type with toggleable items."""

