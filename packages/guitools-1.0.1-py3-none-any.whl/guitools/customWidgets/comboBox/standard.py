

from PySide6.QtWidgets import QWidget
from PySide6.QtCore import Qt, QEvent, QObject
from PySide6.QtGui import QStandardItem, QIcon, QMouseEvent
from typing import Any, Callable
from .base import CustomQComboBox

class ComboBoxCheckable(CustomQComboBox):
    """
    Checkable combo box with support for fixed text, select all item, and toggle callbacks.
    
    This combo box extends CustomQComboBox to provide checkable items with
    features like a fixed display text, a "select all" item, and custom
    toggle item callbacks.
    """
    
    def __init__(self, parent: QWidget | None = None) -> None:
        """
        Initialize the ComboBoxCheckable.
        
        Args:
            parent: The parent widget for this combo box. Defaults to None.
        """
        self._fixedText: str = ""
        self._fixedIcon: QIcon | None = None
        self._itemSelectAll: bool = False
        CustomQComboBox.__init__(self, parent)

    @property
    def itemSelectAll(self) -> bool:
        """
        Get whether the select all item is enabled.
        
        Returns:
            True if select all item is enabled, False otherwise.
        """
        return self._itemSelectAll

    @itemSelectAll.setter
    def itemSelectAll(self, value: bool) -> None:
        """
        Set whether the select all item is enabled.
        
        Args:
            value: True to enable select all item, False to disable.
        """
        self._itemSelectAll = value

    def setFixedText(self, textFixed: str, textItemSelectAll: str = 'Todos') -> None:
        """
        Set a fixed text to display and optionally add a select all item.
        
        Args:
            textFixed: The fixed text to display in the combo box.
            textItemSelectAll: Text for the select all item. Defaults to 'Todos'.
        """
        self._fixedText = textFixed
        if textFixed.strip():
            self.insertItem(0, textItemSelectAll)
            self._itemSelectAll = True
            if self.model().item(0):
                self.model().item(0).setCheckState(Qt.CheckState.Checked)

    def setFixedIcon(self, icon: QIcon) -> None:
        """
        Set a fixed icon for the first item.
        
        Args:
            icon: The icon to set for the first item.
        """
        self._fixedIcon = icon

    def removeFixedIcon(self, icon: QIcon) -> None:
        """
        Remove the fixed icon from the first item.
        
        Args:
            icon: Unused parameter (kept for API compatibility).
        """
        self._fixedIcon = None

    def removeFixedText(self, textItemSelectAll: str = 'Todos') -> None:
        """
        Remove the fixed text and select all item.
        
        Args:
            textItemSelectAll: Text of the select all item to remove. Defaults to 'Todos'.
        """
        if self.itemText(0) == textItemSelectAll:
            self.removeItem(0)
            self._itemSelectAll = False

    def setItemSelectAll(self, textItem: str = 'Todos', checked: bool = True) -> None:
        """
        Add or update the select all item.
        
        Args:
            textItem: Text for the select all item. Defaults to 'Todos'.
            checked: Whether the select all item should be checked. Defaults to True.
        """
        self.insertItem(0, textItem)
        self._itemSelectAll = True
        if self.model().item(0):
            self.model().item(0).setCheckState(Qt.CheckState.Checked if checked else Qt.CheckState.Unchecked)

    def itemSelectAllCheckState(self) -> bool:
        """
        Get the check state of the select all item.
        
        Returns:
            True if the select all item is checked, False otherwise.
            Returns False if select all item is not enabled.
        """
        if self._itemSelectAll:
            if self.model().item(0):
                isChecked = True if self.model().item(0).checkState() == Qt.CheckState.Checked else False
                return isChecked
        return False

    def setItemCheckState(self, itemText: str, shouldCheck: bool) -> bool:
        """
        Set the check state of an item by its text.
        
        Args:
            itemText: The text of the item to update.
            shouldCheck: True to check the item, False to uncheck it.
        
        Returns:
            True if the item was found and updated, False otherwise.
        """
        itemIndex = self.findText(itemText, Qt.MatchFlag.MatchFixedString)
        item = self.model().item(itemIndex)
        if item:
            self.model().item(itemIndex).setCheckState(Qt.CheckState.Checked if shouldCheck else Qt.CheckState.Unchecked)
            self.updateText()
        return bool(item)

    def setItemsCheckState(self, itemTexts: list[str], shouldCheck: bool) -> None:
        """
        Set the check state of multiple items by their texts.
        
        Args:
            itemTexts: List of item texts to update.
            shouldCheck: True to check the items, False to uncheck them.
        """
        for itemText in itemTexts:
            self.setItemCheckState(itemText, shouldCheck)

    def setItemCheckStateFromData(self, itemData: Any, shouldCheck: bool) -> bool:
        """
        Set the check state of an item by its associated data.
        
        Args:
            itemData: The data associated with the item to update.
            shouldCheck: True to check the item, False to uncheck it.
        
        Returns:
            True if the item was found and updated, False otherwise.
        """
        itemIndex = self.findData(itemData)
        item = self.model().item(itemIndex)
        if item:
            self.model().item(itemIndex).setCheckState(Qt.CheckState.Checked if shouldCheck else Qt.CheckState.Unchecked)
            self.updateText()
        return bool(item)

    def setItemsCheckStateFromData(self, dataList: list[Any], shouldCheck: bool) -> None:
        """
        Set the check state of multiple items by their associated data.
        
        Args:
            dataList: List of data objects associated with items to update.
            shouldCheck: True to check the items, False to uncheck them.
        """
        for itemData in dataList:
            self.setItemCheckStateFromData(itemData, shouldCheck)

    def setToggleItem(self, toggleItemCallback: Callable[[str, bool], None]) -> None:
        """
        Set a callback function to be called when an item is toggled.
        
        Args:
            toggleItemCallback: Function to call when an item is toggled.
                               Receives the item text and new check state as parameters.
        """
        def onToggleItem(standardItem: QStandardItem) -> None:
            if toggleItemCallback:
                if self._itemSelectAll and standardItem.row() == 0:
                    return
                isChecked = True if self.model().item(standardItem.row()).checkState() == Qt.CheckState.Checked else False
                toggleItemCallback(self.itemText(standardItem.row()), isChecked)

            self.updateText()

        # Update the text when an item is toggled
        self.model().dataChanged.connect(onToggleItem)

    def eventFilter(self, obj: QObject, event: QEvent | QMouseEvent) -> bool:
        """
        Filter events to handle popup show/hide and item toggling.
        
        Args:
            obj: The object that the event is being filtered for.
            event: The event being filtered.
        
        Returns:
            True if the event was handled, False otherwise.
        """
        if event.type() == QEvent.Type.MouseButtonDblClick:
            return True

        if obj == self.lineEdit():
            if event.type() == QEvent.Type.MouseButtonPress:
                if self.closeOnLineEditClick:
                    self.hidePopup()
                else:
                    self.showPopup()
                return True
            return False

        if obj == self.view().viewport():
            model = self.model()
            if event.type() == QEvent.Type.MouseButtonRelease:
                itemIndex = self.view().indexAt(event.position().toPoint())
                item = model.item(itemIndex.row())
                if item.checkState() == Qt.CheckState.Checked:
                    item.setCheckState(Qt.CheckState.Unchecked)
                    if itemIndex.row() == 0 and self._itemSelectAll:
                        for i in range(model.rowCount()):
                            if i != 0:
                                model.item(i).setCheckState(Qt.CheckState.Unchecked)
                    elif itemIndex.row() != 0 and self._itemSelectAll:
                        if model.item(0).checkState() == Qt.CheckState.Checked:
                            model.item(0).setCheckState(Qt.CheckState.Unchecked)
                else:
                    item.setCheckState(Qt.CheckState.Checked)
                    if itemIndex.row() == 0 and self._itemSelectAll:
                        for i in range(model.rowCount()):
                            if i != 0:
                                model.item(i).setCheckState(Qt.CheckState.Checked)
                self.updateText()
                return True
        return False

    def updateText(self) -> None:
        """
        Update the displayed text based on checked items or fixed text.
        
        If fixed text is set, displays that text. Otherwise, collects all
        checked items (excluding select all if enabled), formats them into
        lines of 4 words each, and updates both the line edit text and tooltip.
        """
        if self._fixedText.strip():
            displayText = self._fixedText.strip()
            if self._fixedIcon:
                self.setItemIcon(0, self._fixedIcon)
            self.setToolTip("")
        else:
            checkedTexts = []
            for i in range(self.model().rowCount()):
                if self._itemSelectAll and i == 0:
                    pass
                else:
                    if self.model().item(i).checkState() == Qt.CheckState.Checked:
                        checkedTexts.append(self.model().item(i).text())

            displayText = ", ".join(checkedTexts)
            # Split text into words
            words = displayText.split()

            # Regroup words into groups of 4, separated by line breaks
            textLines = [" ".join(words[i:i + 4]) for i in range(0, len(words), 4)]

            # Join lines with line breaks
            formattedText = "\n".join(textLines)

            # Set tooltip with formatted text
            self.setToolTip(formattedText)

        self.lineEdit().setText(str(displayText))

    def insertItem(self, index: int, itemText: str, itemData: Any = None) -> None:
        """
        Insert an item at a specific index in the combo box.
        
        If select all is enabled and the select all item is checked,
        the new item will also be checked automatically.
        
        Args:
            index: The index at which to insert the item.
            itemText: The text to display for the item.
            itemData: Optional data to associate with the item.
                     If None, the text will be used as data. Defaults to None.
        """
        item = QStandardItem()
        item.setText(str(itemText))
        if itemData is None:
            item.setData(itemText)
        else:
            item.setData(itemData)

        item.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsUserCheckable)
        item.setData(Qt.CheckState.Unchecked, Qt.ItemDataRole.CheckStateRole)

        if self._itemSelectAll:
            if self.model().item(0):
                if self.model().item(0).checkState() == Qt.CheckState.Checked:
                    item.setCheckState(Qt.CheckState.Checked)

        self.model().insertRow(index, item)

    def addItem(self, *args: Any) -> None:
        data: Any = None
        icon: QIcon | None = None
        if len(args) == 1:
            text = args[0]
        elif len(args) == 2:
            text = args[0]
            data = args[1]
        elif len(args) == 3:
            icon = args[0]
            text = args[1]
            data = args[2]

        item = QStandardItem()
        item.setText(str(text))
        if data is None:
            item.setData(text)
        else:
            item.setData(data)
        if icon:
            item.setIcon(icon)

        item.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsUserCheckable)
        item.setData(Qt.CheckState.Unchecked, Qt.ItemDataRole.CheckStateRole)

        if self._itemSelectAll:
            if self.model().item(0):
                if self.model().item(0).checkState() == Qt.CheckState.Checked:
                    item.setCheckState(Qt.CheckState.Checked)

        self.model().appendRow(item)

    def findData(self, data: Any, role: Any = ..., flags: Any = ...) -> int:
        for i in range(self.model().rowCount()):
            if self.model().item(i).data() == data:
                return i
        return -1

    def currentData(self) -> list[Any]:
        """
        Get the data of all currently checked items.
        
        Returns:
            A list of data objects associated with checked items.
            The select all item is excluded if enabled.
        """
        selectedData: list[Any] = []
        for i in range(self.model().rowCount()):
            if self._itemSelectAll and i == 0:
                pass
            else:
                if self.model().item(i).checkState() == Qt.CheckState.Checked:
                    selectedData.append(self.model().item(i).data())
        return selectedData


class ComboBoxUncheck(CustomQComboBox):
    """
    Combo box with uncheckable items and fixed text support.
    
    This combo box extends CustomQComboBox to provide items that can be
    unchecked and maintains a fixed display text that cannot be changed
    by user input.
    """
    
    def __init__(self, parent: QWidget | None = None) -> None:
        """
        Initialize the ComboBoxUncheck.
        
        Args:
            parent: The parent widget for this combo box. Defaults to None.
        """
        self.fixedText: str = ""
        CustomQComboBox.__init__(self, parent)

    def onTextChanged(self) -> None:
        """
        Handle text change events to maintain fixed text.
        
        If the text differs from the fixed text, it is reset to the fixed text.
        """
        if self.lineEdit().text != self.fixedText:
            self.lineEdit().setText(str(self.fixedText))

    def setFixedText(self, textFixed: str) -> None:
        """
        Set a fixed text that cannot be changed by user input.
        
        Args:
            textFixed: The fixed text to display in the combo box.
        """
        self.fixedText = textFixed.strip()
        self.lineEdit().setText(str(self.fixedText))
        self.lineEdit().textChanged.connect(self.onTextChanged)

    def toggleItem(self, itemText: str) -> None:
        """
        Toggle the check state of an item by its text.
        
        This method should be overridden by setToggleItem callback.
        
        Args:
            itemText: The text of the item to toggle.
        """
        ...

    def setToggleItem(self, toggleItemCallback: Callable[[str], None]) -> None:
        """
        Set a callback function to be called when an item is toggled.
        
        Args:
            toggleItemCallback: Function to call when an item is toggled.
                               Receives the item text as a parameter.
        """
        self.toggleItem = toggleItemCallback
        self.model().dataChanged.connect(self.updateText)

    def eventFilter(self, obj: QObject, event: QEvent) -> bool:
        """
        Filter events to handle popup show/hide and item toggling.
        
        Args:
            obj: The object that the event is being filtered for.
            event: The event being filtered.
        
        Returns:
            True if the event was handled, False otherwise.
        """
        if obj == self.lineEdit():
            if event.type() == QEvent.Type.MouseButtonPress:
                if self.closeOnLineEditClick:
                    self.hidePopup()
                else:
                    self.showPopup()
                return True
            return False

        if obj == self.view().viewport():
            if event.type() == QEvent.Type.MouseButtonPress:
                itemIndex = self.view().indexAt(event.pos())
                self.toggleItem(self.itemText(itemIndex.row()))
                return True

        return False

    def updateText(self) -> None:
        """
        Update the displayed text.
        
        This method is a placeholder and should be overridden if needed.
        """
        ...

    def addItem(self, *args: Any) -> None:
        """
        Add an item to the combo box.
        
        Accepts 1, 2, or 3 arguments:
        - 1 arg: text
        - 2 args: text, data
        - 3 args: icon, text, data
        
        Args:
            *args: Variable arguments for item creation.
        """
        itemData: Any = None
        itemIcon: QIcon | None = None
        if len(args) == 1:
            itemText = args[0]
        elif len(args) == 2:
            itemText = args[0]
            itemData = args[1]
        elif len(args) == 3:
            itemIcon = args[0]
            itemText = args[1]
            itemData = args[2]

        item = QStandardItem()
        item.setText(str(itemText))
        if itemData is None:
            item.setData(itemText)
        else:
            item.setData(itemData)
        if itemIcon:
            item.setIcon(itemIcon)

        item.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsUserCheckable)
        item.setData(Qt.CheckState.Checked, Qt.ItemDataRole.CheckStateRole)

        self.model().appendRow(item)
        self.lineEdit().setText(str(self.fixedText))

    def findData(self, itemData: Any, role: Any = ..., flags: Any = ...) -> int:
        """
        Find the index of an item by its associated data.
        
        Args:
            itemData: The data to search for.
            role: Unused parameter (kept for API compatibility).
            flags: Unused parameter (kept for API compatibility).
        
        Returns:
            The index of the item if found, -1 otherwise.
        """
        for i in range(self.model().rowCount()):
            if self.model().item(i).data() == itemData:
                return i
        return -1

    def currentData(self) -> list[Any]:
        """
        Get the data of all currently checked items.
        
        Returns:
            A list of data objects associated with checked items.
        """
        selectedData: list[Any] = []
        for i in range(self.model().rowCount()):
            if self.model().item(i).checkState() == Qt.CheckState.Checked:
                selectedData.append(self.model().item(i).data())
        return selectedData

