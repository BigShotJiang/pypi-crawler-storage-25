

from PySide6.QtWidgets import QComboBox
from PySide6.QtGui import QIcon
from .base import DataUpdate

def ignoreWheelEvent(comboBox: QComboBox) -> None:
    """
    Configure a combo box to ignore wheel events.
    
    Args:
        comboBox: The combo box to configure.
    """
    comboBox.wheelEvent = lambda event: event.ignore()

def addData(comboBox: QComboBox, newData: DataUpdate) -> None:
    """
    Add items from a DataUpdate object to a combo box.
    
    Args:
        comboBox: The combo box to add items to.
        newData: The DataUpdate object containing items to add.
    """
    if newData:
        # Add new items to the ComboBox
        for item in newData.items:
            if item.icon:
                comboBox.addItem(item.icon, str(item.text), item.data)
            else:
                comboBox.addItem(str(item.text), item.data)

def updateData(comboBox: QComboBox, newData: DataUpdate, itemSelectAll: bool = False, forceUpdate: bool = False) -> None:
    """
    Update combo box items from a DataUpdate object, adding new items and removing old ones.
    
    Args:
        comboBox: The combo box to update.
        newData: The DataUpdate object containing the new items.
        itemSelectAll: Whether the combo box has a select all item at index 0.
                     Defaults to False.
        forceUpdate: If True, clear all items before adding new ones.
                    Defaults to False.
    """
    allItems = [] if forceUpdate else [comboBox.itemText(i) for i in range(comboBox.count())]
    if forceUpdate:
        comboBox.clear()

    # Create a list of strings from the new data
    newDataStr = [str(item.text) for item in newData.items]

    if allItems != newDataStr:
        if not newDataStr:
            if itemSelectAll:
                while comboBox.count() > 1:
                    for index in range(comboBox.count()):
                        if index != 0:
                            comboBox.removeItem(index)
            else:
                while comboBox.count():
                    for index in range(comboBox.count()):
                        comboBox.removeItem(index)
        else:
            for item in newData.items:
                if item.text not in allItems:
                    if item.icon:
                        comboBox.addItem(item.icon, str(item.text), item.data)
                    else:
                        comboBox.addItem(str(item.text), item.data)

            for index, existingItem in enumerate(allItems):
                if existingItem not in newDataStr:
                    if itemSelectAll:
                        if index != 0:
                            comboBox.removeItem(index)
                        else:
                            if not comboBox.itemSelectAll:
                                comboBox.removeItem(index)
                    else:
                        comboBox.removeItem(index)
    else:
        for index, item in enumerate(newData.items):
            if item.icon:
                comboBox.setItemIcon(index, item.icon)
            else:
                comboBox.setItemIcon(index, QIcon(None))
            comboBox.setItemData(index, item.data)

def update(comboBox: QComboBox, newData: list[str] | dict[str, QIcon], itemSelectAll: bool = False) -> None:
    """
    Update combo box items from a list or dictionary, adding new items and removing old ones.
    
    Args:
        comboBox: The combo box to update.
        newData: Either a list of text strings or a dictionary mapping text to icons.
        itemSelectAll: Whether the combo box has a select all item at index 0.
                     Defaults to False.
    """
    allItems = [comboBox.itemText(i) for i in range(comboBox.count())]

    newDataStr = []
    for data in newData:
        newDataStr.append(str(data))

    if allItems != newDataStr:
        if not newDataStr:
            if itemSelectAll:
                while comboBox.count() > 1:
                    for index in range(comboBox.count()):
                        if index != 0:
                            comboBox.removeItem(index)
            else:
                while comboBox.count():
                    for index in range(comboBox.count()):
                        comboBox.removeItem(index)
        else:
            for data in newDataStr:
                if data not in allItems:
                    if type(newData) == list:
                        comboBox.addItem(data)
                    else:
                        comboBox.addItem(newData[data], data)

            for index, existingItem in enumerate(allItems):
                if existingItem not in newDataStr:
                    if itemSelectAll:
                        if index != 0:
                            comboBox.removeItem(index)
                        else:
                            if not comboBox.itemSelectAll:
                                comboBox.removeItem(index)
                    else:
                        comboBox.removeItem(index)

