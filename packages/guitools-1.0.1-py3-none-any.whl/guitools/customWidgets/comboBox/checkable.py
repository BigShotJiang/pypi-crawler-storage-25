

from PySide6.QtWidgets import (
    QComboBox, QWidget, QListWidget, QListWidgetItem,
    QVBoxLayout, QHBoxLayout, QLineEdit, QPushButton, QFrame, QCheckBox, QWidgetAction, QSizePolicy, QLabel
)
from typing import Callable
from PySide6.QtCore import Qt, QEvent, QCoreApplication, QObject
from PySide6.QtGui import QKeyEvent, QMouseEvent
from pydantic import BaseModel
from ...style import Styles
from ..menu.menu import Menu

class StyleSheetMenu(Styles.menu):
    """
    Custom style sheet for the combo box menu.
    
    This class extends Styles.menu to provide a custom style for the
    checkable combo box dropdown menu with specific border and background settings.
    """
    
    def __init__(self):
        """
        Initialize the StyleSheetMenu with custom styling.
        """
        super().__init__(height=230)
        self.menu.border = Styles.Property.Border(color=Styles.Color.Widget.focusBorder, bottom_left_radius=5, bottom_right_radius=0, top_left_radius=0, top_right_radius=0)
        self.menu.backgroundColor.value = Styles.Color.Widget.background

class CustomMenu(Menu):
    """
    Custom menu that handles Alt key events.
    
    This menu extends the base Menu class to accept Alt key presses
    without triggering default menu behavior.
    """
    
    def keyPressEvent(self, keyEvent: QKeyEvent) -> None:
        """
        Handle key press events, specifically accepting Alt key.
        
        Args:
            keyEvent: The key event containing information about the pressed key.
        """
        if keyEvent.key() == Qt.Key.Key_Alt:
            keyEvent.accept()
        else:
            super().keyPressEvent(keyEvent)

class CheckableComboBox(QComboBox):
    """
    ComboBox widget with checkable items and custom popup.
    
    This combo box allows users to select multiple items by checking them.
    It includes features like single selection mode, mandatory selection,
    text masking, and a custom popup widget with add/remove functionality.
    """
    
    class DataItem(BaseModel):
        """
        Data model for combo box items.
        
        Attributes:
            text: The text to display for the item.
            check: Whether the item is checked by default.
        """
        text: str
        check: bool

    def __init__(self, initialCheckItem: bool = True, placeholderCombo: str = '', placeholderNewItem: str = '', singleSelection: bool = False, mandatorySelection: bool = False, maskText: bool = False, *, parent: QWidget | None = None) -> None:
        """
        Initialize the CheckableComboBox.
        
        Args:
            initialCheckItem: Whether new items should be checked by default.
                           Defaults to True.
            placeholderCombo: Placeholder text for the combo box line edit.
                            Defaults to an empty string.
            placeholderNewItem: Placeholder text for the new item input field.
                              Defaults to an empty string.
            singleSelection: If True, only one item can be selected at a time.
                           Defaults to False.
            mandatorySelection: If True, at least one item must always be selected.
                              Defaults to False.
            maskText: If True, selected text will be masked (e.g., for passwords).
                     Defaults to False.
            parent: The parent widget for this combo box. Defaults to None.
        """
        super().__init__(parent)
        self.singleSelection: bool = singleSelection
        self.mandatorySelection: bool = mandatorySelection
        self.maskText: bool = maskText
        self.setProperty("popup_open", False)
        self.initialCheckItem: bool = initialCheckItem
        self.setEditable(True)
        self.lineEdit().setReadOnly(True)
        if placeholderCombo.strip():
            self.lineEdit().setPlaceholderText(placeholderCombo)
        self.placeholderNewItem: str = placeholderNewItem
        self.lineEdit().installEventFilter(self)
        self.setInsertPolicy(QComboBox.InsertPolicy.NoInsert)

        self.menu = CustomMenu(self, parent=self)
        self.menu.aboutToHide.connect(self.onMenuAboutToHide)
        self.menu.aboutToShow.connect(self.onMenuAboutToShow)
        self.popupWidget = CustomPopup(self)
        self.popupAction = QWidgetAction(self)
        self.popupAction.setDefaultWidget(self.popupWidget)
        self.menu.addAction(self.popupAction)

        Styles.setWidgetStyleTheme(StyleSheetMenu(), self.menu)

    def validateNewItem(self, text: str) -> bool:
        """
        Validate if a new item text is valid.
        
        Args:
            text: The text to validate.
        
        Returns:
            True if the text is not empty after stripping whitespace, False otherwise.
        """
        return text.strip()

    def wheelEvent(self, wheelEvent: QEvent) -> None:
        """
        Ignore wheel events to prevent accidental scrolling.
        
        Args:
            wheelEvent: The wheel event to ignore.
        """
        wheelEvent.ignore()

    def eventFilter(self, obj: QObject, event: QEvent) -> bool:
        """
        Filter events to handle line edit clicks.
        
        Args:
            obj: The object that the event is being filtered for.
            event: The event being filtered.
        
        Returns:
            True if the event was handled, False otherwise.
        """
        if obj == self.lineEdit() and event.type() == QEvent.Type.MouseButtonPress:
            self.showPopup()
            return True
        return super().eventFilter(obj, event)

    def _addItem(self, dataItem: DataItem | dict) -> None:
        """
        Internal method to add an item to the combo box model.
        
        Args:
            dataItem: The data item to add, either as a DataItem instance or a dictionary.
        """
        if isinstance(dataItem, dict):
            dataItem = self.DataItem(**dataItem)
        super().addItem(dataItem.text)
        itemIndex = self.count() - 1
        self.setItemData(itemIndex, Qt.CheckState.Checked if dataItem.check else Qt.CheckState.Unchecked, Qt.ItemDataRole.CheckStateRole)

    def _addItems(self, *dataItems: DataItem | list[dict]) -> None:
        """
        Internal method to add multiple items to the combo box model.
        
        Args:
            *dataItems: Variable number of data items to add.
        """
        for dataItem in dataItems:
            self._addItem(dataItem)

    def addItem(self, dataItem: DataItem | dict) -> None:
        """
        Add a single item to the combo box.
        
        Args:
            dataItem: The data item to add, either as a DataItem instance or a dictionary.
        """
        self.popupWidget.addDataItem(dataItem)

    def addItems(self, *dataItems: DataItem | dict) -> None:
        """
        Add multiple items to the combo box.
        
        Args:
            *dataItems: Variable number of data items to add.
        """
        for dataItem in dataItems:
            self.addItem(dataItem)
        QCoreApplication.processEvents()
        self.updateText()

    def clear(self) -> None:
        """
        Clear all items from the combo box and popup widget.
        """
        super().clear()
        self.popupWidget.listWidget.clear()
        self.updateText()

    def hidePopup(self) -> None:
        """
        Hide the popup menu and update the display text.
        """
        self.menu.hide()
        self.updateText()

    def onMenuAboutToShow(self) -> None:
        """
        Handle the menu about to show event.
        
        Updates the widget style and sets focus to the line edit in the popup.
        """
        if not self.menu._block_events:
            self.setProperty("popup_open", True)
            self.style().unpolish(self)
            self.style().polish(self)
            self.update()
            self.popupWidget.lineEdit.setFocus()

    def onMenuAboutToHide(self) -> None:
        """
        Handle the menu about to hide event.
        
        Updates the widget style when the popup is closed.
        """
        if not self.menu._block_events:
            self.setProperty("popup_open", False)
            self.style().unpolish(self)
            self.style().polish(self)
            self.update()

    def showPopup(self) -> None:
        """
        Show the popup menu at the correct position and size.
        """
        QCoreApplication.processEvents()
        bottomPoint = self.rect().bottomLeft()
        globalPoint = self.mapToGlobal(bottomPoint)

        menuHeight = self.menu.sizeHint().height()
        menuWidth = self.geometry().width()

        self.popupAction.defaultWidget().setFixedSize(menuWidth - 2, menuHeight - 2)

        self.menu._exec(globalPoint, menuWidth, menuHeight)

    def maskedText(self, text: str, lastVisible: int = 5, masked: str = '*') -> str:
        """
        Mask text, showing only the last N characters.
        
        Args:
            text: The text to mask.
            lastVisible: Number of characters to keep visible at the end.
                        Defaults to 5.
            masked: Character to use for masking. Defaults to '*'.
        
        Returns:
            The masked text string.
        """
        if len(text) > lastVisible:
            maskedText = masked * (len(text) - lastVisible) + text[-lastVisible:]
        else:
            maskedText = text

        return maskedText

    def updateText(self) -> None:
        """
        Update the displayed text based on checked items.
        
        Collects all checked items, optionally masks them, formats them
        into lines of 4 words each, and updates both the line edit text
        and tooltip.
        """
        checkedTexts = []
        for i in range(self.model().rowCount()):
            item = self.model().item(i)
            if item.checkState() == Qt.CheckState.Checked:
                itemText = item.text()
                if self.maskText:
                    itemText = self.maskedText(itemText)
                checkedTexts.append(itemText)
        displayText = ", ".join(checkedTexts)
        words = displayText.split()
        textLines = [" ".join(words[i:i + 4]) for i in range(0, len(words), 4)]
        formattedText = "\n".join(textLines)
        self.setToolTip(formattedText)
        self.lineEdit().setText(str(displayText))

    def getItemsData(self) -> list['DataItem']:
        """
        Get all items data as a list of DataItem objects.
        
        Returns:
            A list of DataItem objects representing all items in the combo box.
        """
        itemsData: list[CheckableComboBox.DataItem] = []
        for i in range(self.model().rowCount()):
            checkState = self.model().item(i).checkState()
            itemsData.append(self.DataItem(text=self.model().item(i).text(), check=True if checkState == Qt.CheckState.Checked else False))
        return itemsData


class ListItemWidget(QWidget):
    """
    Widget representing a single item in the checkable combo box list.
    
    This widget displays a checkbox with text and a remove button,
    allowing users to check/uncheck items and remove them from the list.
    """
    
    def __init__(self, text: str, checkState: Qt.CheckState, checkCallback: Callable[[Qt.CheckState], None], parent: QWidget | None = None) -> None:
        """
        Initialize the ListItemWidget.
        
        Args:
            text: The text to display next to the checkbox.
            checkState: The initial check state of the checkbox.
            checkCallback: Callback function to execute when the check state changes.
            parent: The parent widget for this item widget. Defaults to None.
        """
        super().__init__(parent)
        self.text: str = text
        self.checkCallback: Callable[[Qt.CheckState], None] = checkCallback
        self.ignoreCheckCallback: bool = False

        self.checkbox = QCheckBox(text, self)
        if not isinstance(checkState, Qt.CheckState):
            checkState = Qt.CheckState(checkState)
        self.checkbox.setCheckState(checkState)
        self.checkbox.stateChanged.connect(self.onStateChanged)

        self.remove_button = QPushButton(self)
        self.remove_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.remove_button.setObjectName('BtnDelete')
        self.remove_button.setSizePolicy(QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed))
        Styles.setIcon(self.remove_button, Styles.Resources.trash.gray, Styles.Resources.trash.original)

        itemLayout = QHBoxLayout(self)
        itemLayout.setContentsMargins(0, 0, 0, 0)
        itemLayout.addWidget(self.checkbox)
        itemLayout.addStretch()
        itemLayout.addWidget(self.remove_button)
        self.setLayout(itemLayout)

    def mousePressEvent(self, mouseEvent: QMouseEvent) -> None:
        """
        Handle mouse press events to toggle checkbox state.
        
        Args:
            mouseEvent: The mouse event containing information about the click.
        """
        if not self.remove_button.underMouse():
            newState = (
                Qt.CheckState.Unchecked
                if self.checkbox.checkState() == Qt.CheckState.Checked
                else Qt.CheckState.Checked
            )
            self.checkbox.setCheckState(newState)
        super().mousePressEvent(mouseEvent)

    def onStateChanged(self, state: int) -> None:
        """
        Handle checkbox state change events.
        
        Args:
            state: The new check state as an integer.
        """
        if not self.ignoreCheckCallback:
            self.checkCallback(Qt.CheckState(state))


class CustomPopup(QFrame):
    """
    Custom popup frame for the checkable combo box.
    
    This popup contains a list widget for displaying items and an input field
    with a button for adding new items. It handles item management, selection,
    and removal.
    """
    
    class StyleSheet(Styles.Standard.StyleSheet):
        """
        Custom style sheet for the popup widget.
        """
        
        def __init__(self):
            """
            Initialize the StyleSheet.
            """
            super().__init__()

        def style(self) -> str:
            """
            Generate the style sheet string for the popup.
            
            Returns:
                The CSS style sheet string.
            """
            listView = Styles.listView()
            listView.listView.add_additional_style('border: 0px solid;')
            return f'''
                QFrame, QCheckBox {{background-color: {Styles.Color.table}}}
                QFrame {{{Styles.Property.Border(bottom_left_radius=5, bottom_right_radius=0, top_left_radius=0, top_right_radius=0)}}}
                {Styles.button(prefix='#BtnAdd').styleSheet(use_class_name=False)}
                {Styles.button(prefix='#BtnDelete', transparent=True, hover=True).styleSheet(use_class_name=False)}
                {listView}
            '''

    def __init__(self, parentComboBox: CheckableComboBox):
        """
        Initialize the CustomPopup.
        
        Args:
            parentComboBox: The parent CheckableComboBox that owns this popup.
        """
        super().__init__(parentComboBox, Qt.WindowType.Popup)
        self.parentComboBox = parentComboBox
        self.setWindowFlags(Qt.WindowType.Popup)
        self.installEventFilter(self)

        # Widgets
        self.listWidget = QListWidget(self)
        self.listWidget.setSelectionMode(QListWidget.SelectionMode.NoSelection)

        self.lineEdit = QLineEdit(self)
        if parentComboBox.placeholderNewItem.strip():
            self.lineEdit.setPlaceholderText(parentComboBox.placeholderNewItem)
        self.lineEdit.returnPressed.connect(self.onAddClicked)

        self.addButton = QPushButton(self)
        self.addButton.setCursor(Qt.CursorShape.PointingHandCursor)
        self.addButton.setObjectName('BtnAdd')
        self.addButton.setSizePolicy(QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed))
        self.addButton.clicked.connect(self.onAddClicked)
        Styles.setIcon(self.addButton, Styles.Resources.add.gray, Styles.Resources.add.select)

        # Bottom layout
        bottomWidget = QFrame(self)
        bottomLayout = QHBoxLayout(bottomWidget)
        bottomLayout.setContentsMargins(2, 2, 2, 2)
        bottomLayout.addWidget(self.addButton)
        bottomLayout.addWidget(self.lineEdit)

        # Main layout
        mainLayout = QVBoxLayout(self)
        mainLayout.setContentsMargins(2, 2, 2, 0)
        mainLayout.setSpacing(0)
        mainLayout.addWidget(bottomWidget)
        mainLayout.addWidget(self.listWidget)
        self.setLayout(mainLayout)

        Styles.setWidgetStyleTheme(self.StyleSheet(), self)

    def eventFilter(self, obj: QObject, event: QEvent) -> bool:
        """
        Filter events to prevent popup closing with Enter/Return and block clicks on frames/labels.
        
        Args:
            obj: The object that the event is being filtered for.
            event: The event being filtered.
        
        Returns:
            True if the event was handled and should be blocked, False otherwise.
        """
        eventType = event.type()
        if eventType in (QEvent.Type.MouseButtonPress, QEvent.Type.MouseButtonDblClick, QEvent.Type.MouseButtonRelease):
            if isinstance(obj, (QFrame, QLabel)):
                return True
        if eventType == QEvent.Type.KeyPress:
            if event.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
                if self.focusWidget() == self.lineEdit:
                    self.lineEdit.returnPressed.emit()
                return True
        return super().eventFilter(obj, event)

    def addDataItem(self, dataItem: CheckableComboBox.DataItem) -> None:
        """
        Add a single DataItem to both the ComboBox and listWidget.
        
        Prevents duplicates (case-insensitive) and creates a ListItemWidget
        for the item in the popup list.
        
        Args:
            dataItem: The data item to add.
        """
        # Prevent duplicates (case-insensitive)
        existingItems = [self.parentComboBox.itemText(i).strip().lower() for i in range(self.parentComboBox.count())]
        if dataItem.text.lower() in existingItems:
            return

        # Add to ComboBox
        self.parentComboBox._addItem(dataItem)

        # Add to listWidget
        listItem = QListWidgetItem(self.listWidget)
        itemWidget = ListItemWidget(
            dataItem.text,
            Qt.CheckState.Checked if dataItem.check else Qt.CheckState.Unchecked,
            checkCallback=lambda state, itemText=dataItem.text: self.onItemCheckedByText(itemText, state),
            parent=self.listWidget
        )
        itemWidget.remove_button.clicked.connect(lambda _, itemText=dataItem.text: self.removeItemByText(itemText))
        listItem.setSizeHint(itemWidget.sizeHint())
        self.listWidget.addItem(listItem)
        self.listWidget.setItemWidget(listItem, itemWidget)

    def addDataItems(self, dataItems: list[CheckableComboBox.DataItem]) -> None:
        """
        Add multiple DataItems at once.
        
        Args:
            dataItems: List of data items to add.
        """
        for dataItem in dataItems:
            self.addDataItem(dataItem)

    def onAddClicked(self) -> None:
        """
        Handle the add button click or Enter key press.
        
        Validates the input text, creates a new DataItem, adds it to the combo box,
        clears the input field, and updates the display text.
        """
        inputText = self.lineEdit.text().strip()
        if not inputText:
            return

        if self.parentComboBox.validateNewItem(inputText):
            shouldCheck = self.parentComboBox.initialCheckItem
            if self.parentComboBox.mandatorySelection and self.parentComboBox.count() == 0:
                shouldCheck = True

            newDataItem = CheckableComboBox.DataItem(text=inputText, check=shouldCheck)
            self.addDataItem(newDataItem)

            self.lineEdit.clear()
            self.parentComboBox.updateText()

        self.lineEdit.setFocus()

    def onItemCheckedByText(self, itemText: str, state: Qt.CheckState) -> None:
        """
        Handle item check state change by text identifier.
        
        Updates the combo box item data based on the check state change.
        Handles single selection mode and mandatory selection requirements.
        
        Args:
            itemText: The text of the item that was checked/unchecked.
            state: The new check state.
        """
        itemIndex = self.findIndexByText(itemText)
        if itemIndex == -1:
            return

        if self.parentComboBox.singleSelection:
            if self.parentComboBox.mandatorySelection and state == Qt.CheckState.Unchecked:
                # Keep it selected
                listItem = self.listWidget.item(itemIndex)
                itemWidget: ListItemWidget = self.listWidget.itemWidget(listItem)
                itemWidget.checkbox.setCheckState(Qt.CheckState.Checked)
                self.parentComboBox.setItemData(itemIndex, Qt.CheckState.Checked, Qt.ItemDataRole.CheckStateRole)
                return

            if state == Qt.CheckState.Checked:
                # Uncheck others
                for i in range(self.listWidget.count()):
                    if i != itemIndex:
                        listItem = self.listWidget.item(i)
                        itemWidget: ListItemWidget = self.listWidget.itemWidget(listItem)
                        itemWidget.ignoreCheckCallback = True
                        itemWidget.checkbox.setCheckState(Qt.CheckState.Unchecked)
                        self.parentComboBox.setItemData(i, Qt.CheckState.Unchecked, Qt.ItemDataRole.CheckStateRole)
                        itemWidget.ignoreCheckCallback = False

        self.parentComboBox.setItemData(itemIndex, state, Qt.ItemDataRole.CheckStateRole)
        self.parentComboBox.updateText()

    def removeItemByText(self, itemText: str) -> None:
        """
        Remove an item from both ComboBox and listWidget by its text.
        
        If mandatory selection is required and the removed item was selected,
        automatically selects the first remaining item.
        
        Args:
            itemText: The text of the item to remove.
        """
        itemIndex = self.findIndexByText(itemText)
        if itemIndex == -1:
            return

        requiresSelection = False
        if self.parentComboBox.singleSelection and self.parentComboBox.mandatorySelection:
            requiresSelection = (
                self.parentComboBox.itemData(itemIndex, Qt.ItemDataRole.CheckStateRole)
                == Qt.CheckState.Checked
            )

        # Remove from ComboBox
        self.parentComboBox.removeItem(itemIndex)

        # Remove from listWidget
        listItem = self.listWidget.takeItem(itemIndex)
        del listItem

        # Reassign selection if necessary
        if requiresSelection and self.parentComboBox.count() > 0:
            firstItem = self.listWidget.item(0)
            if firstItem:
                itemWidget: ListItemWidget = self.listWidget.itemWidget(firstItem)
                itemWidget.ignoreCheckCallback = True
                itemWidget.checkbox.setCheckState(Qt.CheckState.Checked)
                self.parentComboBox.setItemData(0, Qt.CheckState.Checked, Qt.ItemDataRole.CheckStateRole)
                itemWidget.ignoreCheckCallback = False

        # Update text and sizes only
        self.parentComboBox.updateText()

    def findIndexByText(self, itemText: str) -> int:
        """
        Find the index of an item by its text.
        
        Args:
            itemText: The text to search for.
        
        Returns:
            The index of the item if found, -1 otherwise.
        """
        for i in range(self.parentComboBox.count()):
            if self.parentComboBox.itemText(i).strip() == itemText.strip():
                return i
        return -1

