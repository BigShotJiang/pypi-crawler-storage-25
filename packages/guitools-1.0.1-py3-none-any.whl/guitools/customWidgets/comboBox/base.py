

from typing import Any
from PySide6.QtWidgets import QComboBox, QWidget
from PySide6.QtCore import QTimerEvent
from PySide6.QtGui import QIcon, QResizeEvent

class DataUpdate(object):
    """
    Data structure for updating combo box items.
    
    This class provides a convenient way to collect and manage items
    (text, icon, and data) before adding them to a combo box.
    """
    
    class Item:
        """
        Represents a single combo box item with text, icon, and optional data.
        
        Attributes:
            text: The text to display for the item.
            icon: Optional icon to display with the item.
            data: Optional data associated with the item.
        """
        
        def __init__(self, text: str, icon: QIcon | None = None, data: Any = ...) -> None:
            """
            Initialize the Item.
            
            Args:
                text: The text to display for the item.
                icon: Optional icon to display with the item. Defaults to None.
                data: Optional data associated with the item. Defaults to Ellipsis.
            """
            self.text: str = text
            self.icon: QIcon | None = icon
            self.data: Any = data

    def __init__(self) -> None:
        """
        Initialize the DataUpdate with an empty items list.
        """
        self.items: list[DataUpdate.Item] = []

    def append(self, text: str, icon: QIcon | None = None, data: Any = ...) -> None:
        """
        Append a new item to the items list.
        
        Args:
            text: The text to display for the item.
            icon: Optional icon to display with the item. Defaults to None.
            data: Optional data associated with the item. Defaults to Ellipsis.
        """
        newItem = self.Item(text, icon, data)
        self.items.append(newItem)

class CustomQComboBox(QComboBox):
    """
    Base custom QComboBox with readonly editable line edit.
    
    This combo box extends QComboBox to provide a readonly editable field
    that can display custom text. It handles popup show/hide behavior and
    prevents wheel events from affecting the combo box.
    """
    
    def __init__(self, parent: QWidget | None = None) -> None:
        """
        Initialize the CustomQComboBox.
        
        Args:
            parent: The parent widget for this combo box. Defaults to None.
        """
        super().__init__(parent)
        self.wheelEvent = lambda event: event.ignore()
        
        # Make the combo editable to set a custom text, but readonly
        self.setEditable(True)
        self.lineEdit().setReadOnly(True)
        self.lineEdit().selectionChanged.connect(lambda: self.lineEdit().setSelection(0, 0))
        
        # Hide and show popup when clicking the line edit
        self.lineEdit().installEventFilter(self)
        self.closeOnLineEditClick: bool = False

        # Prevent popup from closing when clicking on an item
        self.view().viewport().installEventFilter(self)

    def resizeEvent(self, resizeEvent: QResizeEvent) -> None:
        """
        Handle resize events to update text display.
        
        Args:
            resizeEvent: The resize event containing information about the resize.
        """
        # Recompute text to elide as needed
        self.updateText()
        super().resizeEvent(resizeEvent)

    def showPopup(self) -> None:
        """
        Show the popup and enable close on line edit click.
        """
        super().showPopup()
        # When the popup is displayed, a click on the lineedit should close it
        self.closeOnLineEditClick = True

    def hidePopup(self) -> None:
        """
        Hide the popup, start a timer to prevent immediate reopening, and update text.
        """
        super().hidePopup()
        # Used to prevent immediate reopening when clicking on the lineEdit
        self.startTimer(100)
        # Refresh the display text when closing
        self.updateText()

    def timerEvent(self, timerEvent: QTimerEvent) -> None:
        """
        Handle timer events to re-enable line edit clicks.
        
        Args:
            timerEvent: The timer event containing the timer ID.
        """
        # After timeout, kill timer, and reenable click on line edit
        self.killTimer(timerEvent.timerId())
        self.closeOnLineEditClick = False

    def addItems(self, texts: list[str], dataList: list[Any] | None = None) -> None:
        """
        Add multiple items to the combo box.
        
        Args:
            texts: List of text strings to add as items.
            dataList: Optional list of data objects to associate with each item.
                    If provided, must have the same length as texts.
                    Defaults to None.
        """
        for i, text in enumerate(texts):
            try:
                itemData = dataList[i] if dataList else None
            except (TypeError, IndexError):
                itemData = None
            self.addItem(text, itemData)

