

import string
import random
from PySide6.QtWidgets import QStyledItemDelegate, QStyleOptionViewItem
from PySide6.QtCore import QModelIndex
from PySide6 import QtCore

def randomString(length: int) -> str:
    """
    Generate a random string of lowercase letters.
    
    Args:
        length: The length of the string to generate.
    
    Returns:
        A random string of the specified length.
    """
    # Choose from all lowercase letters
    letters = string.ascii_lowercase
    return ''.join(random.choice(letters) for i in range(length))

class AlignDelegate(QStyledItemDelegate):
    """
    A delegate that centers the alignment of items in a table.
    """
    def initStyleOption(self, option: QStyleOptionViewItem, index: QModelIndex) -> None:
        """
        Initialize the style option with center alignment.
        
        Args:
            option: The style option to initialize.
            index: The model index of the item.
        """
        super(AlignDelegate, self).initStyleOption(option, index)
        option.displayAlignment = QtCore.Qt.AlignmentFlag.AlignCenter

