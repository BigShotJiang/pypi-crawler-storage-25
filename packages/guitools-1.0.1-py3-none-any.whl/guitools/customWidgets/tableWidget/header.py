

from typing import Any
from PySide6.QtWidgets import QHeaderView, QLabel, QPushButton, QSpinBox, QDoubleSpinBox, QCheckBox, QSizePolicy, QAbstractSpinBox, QComboBox, QTableWidget, QWidget
from PySide6.QtCore import Qt, Signal, QEvent
from PySide6 import QtCore
from functools import partial
from .model import TableModel
from .data import QDataHeader
from ..comboBox import ComboBox
from ...style import Styles
from ..composite import IconCheckBox

class HorizontalHeader(QHeaderView):
    """
    A custom horizontal header view for QTableWidget with support for custom widgets.
    
    This header allows placing various widgets (labels, buttons, combo boxes, etc.)
    in the header cells, providing enhanced functionality for filtering and interaction.
    """
    loading = Signal()
    
    def __init__(self, dataHeaders: list[dict[str, Any]], parent: QTableWidget | None = None) -> None:
        """
        Initialize the HorizontalHeader.
        
        Args:
            dataHeaders: List of dictionaries defining header items.
            parent: The parent QTableWidget. Defaults to None.
        """
        import pandas as pd
        super(HorizontalHeader, self).__init__(QtCore.Qt.Orientation.Horizontal, parent)
        self.loaded: bool = False
        self.setSectionsMovable(False)
        columnCount = parent.columnCount() if parent else 0
        self.itens: list[QWidget] = []
        if len(dataHeaders) < columnCount:
            while len(dataHeaders) < columnCount:
                dataHeaders.append(QDataHeader.HeaderItem("", ""))

        self.dataHeaders: list[dict[str, Any]] = dataHeaders
        self.sectionResized.connect(self.handleSectionResized)
        self.sectionMoved.connect(self.handleSectionMoved)
        
        headerData = pd.DataFrame([
          [i for i in range(columnCount)],
        ], columns=['' for i in range(columnCount)], index=[])

        self.setModel(TableModel(headerData))
        self.setSectionResizeMode(QHeaderView.ResizeMode.Fixed)
       
     
    def cellHeader(self, column: int) -> QWidget | None:
        """
        Get the widget for a specific header column.
        
        Args:
            column: The column index.
        
        Returns:
            The widget at the specified column, or None if not found.
        """
        return self.itens[column] if len(self.itens) > column else None

    def updateComboBoxUncheck(self, column: int, data: list[str]) -> None:
        """
        Update the data for an uncheck combo box in the header.
        
        Args:
            column: The column index.
            data: The new data list for the combo box.
        """
        if self.itens:
            headerItem = self.itens[column]
            ComboBox.update(headerItem, data)
        if self.dataHeaders:
            self.dataHeaders[column]['dados'] = data

    def updateComboBoxCheckable(self, column: int, data: list[str]) -> None:
        """
        Update the data for a checkable combo box in the header.
        
        Args:
            column: The column index.
            data: The new data list for the combo box.
        """
        if self.itens:
            headerItem = self.itens[column]
            ComboBox.update(headerItem, data, True)
        if self.dataHeaders:
            self.dataHeaders[column]['dados'] = data

    def updateStyleSheetHeaderItem(self, styleSheet: str) -> None:
        """
        Update the style sheet for all filter header items.
        
        Args:
            styleSheet: The CSS style sheet string to apply.
        """
        for i, headerData in enumerate(self.dataHeaders):
            if headerData['type'] == 'HeaderItemFilter':
                if self.itens:
                  headerItem = self.itens[i]
                  headerItem.setStyleSheet(styleSheet)
                  headerData['styleSheet'] = styleSheet

    def showEvent(self, showEvent: QEvent) -> None:
        """
        Handle the show event, creating header widgets as needed.
        
        Args:
            showEvent: The show event.
        """
        for i in range(self.count()):

            headerData = self.dataHeaders[i]
            if i < len(self.itens):
                headerItem = self.itens[i]
            else:
                headerItem = None
                if headerData['type'] == 'HeaderItem' or headerData['type'] == 'HeaderItemFilter':
                    headerItem = QLabel(self)
                    headerItem.setStyleSheet(headerData['styleSheet'] + '''
                        QLabel{ 
                            background-color: 'transparent';
                         }
                     ''')
                    headerItem.setText(headerData['text'])
                    if headerData['icon'] is not None:
                        headerIcon = headerData['icon']
                        headerItem.setPixmap(headerIcon.toPixmap(headerData['icon_size']))
                    self.itens.append(headerItem)

                elif headerData['type'] == 'QWidget':
                    headerItem = headerData['func_create_widget'](parent=self)
                    self.itens.append(headerItem)
  
                elif headerData['type'] == 'QPushButton':
                    headerItem = QPushButton(self)
                    headerItem.setText(headerData['text'])
                    headerItem.setEnabled(headerData['enabled'])
                    if headerData['style']:
                        headerItem.setStyleSheet(headerData['style'])
                    if headerData['func']:
                        headerItem.clicked.connect(headerData['func'])
                    if headerData['icon_data']:
                        iconData: Styles.Resources.Data = headerData['icon_data']
                        Styles.setIcon(headerItem, iconData.callableIcon, iconData.hoverCallableIcon, iconData.pixmapSize)
                    elif headerData['icon']:
                        try:
                            headerItem.setIcon(headerData['icon'])
                        except Exception:
                            pass

                    self.itens.append(headerItem)

                elif headerData['type'] == 'QSpinBox':
                    headerItem = QSpinBox(self)
                    headerItem.setMinimum(headerData['minimum'])
                    if headerData['func']:
                        headerItem.editingFinished.connect(headerData['func'])
                    if headerData['maximum'] != None:
                        headerItem.setMaximum(headerData['maximum'])
                    if headerData['value'] != None:
                        headerItem.setValue(headerData['value'])
                    self.itens.append(headerItem)

                elif headerData['type'] == 'QDoubleSpinBox':
                    headerItem = QDoubleSpinBox(self)
                    stepType = QAbstractSpinBox.StepType.AdaptiveDecimalStepType
                    headerItem.setStepType(stepType)
                    headerItem.setDecimals(headerData['decimals'])
                    headerItem.setMinimum(headerData['minimum'])
                    if headerData['maximum'] != None:
                         headerItem.setMaximum(headerData['maximum'])
                    if headerData['func']:
                        headerItem.editingFinished.connect(headerData['func'])
                    if headerData['value'] != None:
                        headerItem.setValue(headerData['value'])
                    self.itens.append(headerItem)

                elif headerData['type'] == 'QCheckBox':
                    headerItem = QCheckBox(self)
                    checkboxSizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
                    headerItem.setSizePolicy(checkboxSizePolicy)
                    headerItem.setText(headerData['text'])
                    headerItem.setChecked(headerData['checked'])
                    if headerData['func']:
                        toggleCallback = lambda value, headerItem = headerItem, func = headerData['func'] : func(headerItem)
                        headerItem.toggled.connect(toggleCallback)
                    if headerData['toolTip'] != None:
                        toolTipText: str = headerData['toolTip'] 
                        headerItem.setToolTip(toolTipText if toolTipText.strip() else headerData['text'])
                    
                    self.itens.append(headerItem)

                elif headerData['type'] == 'IconQCheckBox':
                    headerItem = IconCheckBox(headerData['text'], headerData['icon'], parent=self, spacing=headerData['spacing'])
                    headerItem.checkbox.setChecked(headerData['checked'])
                    if headerData['func']:
                        toggleCallback = lambda value, headerItem = headerItem, func = headerData['func'] : func(headerItem)
                        headerItem.checkbox.toggled.connect(toggleCallback)

                    self.itens.append(headerItem)

                elif headerData['type'] == 'ComboBoxUncheck':
                    headerItem = ComboBox.ComboBoxUncheck(self)
                    headerItem.setFixedText(headerData['text'])
                    if isinstance(headerData['dados'], list) or isinstance(headerData['dados'], dict):
                        ComboBox.update(headerItem, headerData['dados'], headerData['itemSelectAll'])
                    else:
                        ComboBox.updateData(headerItem, headerData['dados'], headerData['itemSelectAll'])
                    ComboBox.ignoreWheelEvent(headerItem)
                    if headerData['func']:
                        headerItem.setToggleItem(headerData['func'])
                    self.itens.append(headerItem)

                elif headerData['type'] == 'CheckBoxCheckable':

                    headerItem = ComboBox.ComboBoxCheckable(self)
                    headerItem.setFixedText(headerData['text'])
                    if isinstance(headerData['dados'], list) or isinstance(headerData['dados'], dict):
                        ComboBox.update(headerItem, headerData['dados'], headerData['itemSelectAll'])
                    else:
                        ComboBox.updateData(headerItem, headerData['dados'], headerData['itemSelectAll'])
                    if headerData['icon']:
                        headerItem.setFixedIcon(headerData['icon'])

                    ComboBox.ignoreWheelEvent(headerItem)
                    if headerData['func']:
                        headerItem.setToggleItem(headerData['func'])
                    self.itens.append(headerItem)

                elif headerData['type'] == 'QComboBox':
                    headerItem = QComboBox(self)
                    if isinstance(headerData['dados'], list) or isinstance(headerData['dados'], dict):
                        ComboBox.update(headerItem, headerData['dados'])
                    else:
                        ComboBox.updateData(headerItem, headerData['dados'])

                    headerItem.setFocusPolicy(Qt.FocusPolicy.NoFocus)
                    ComboBox.ignoreWheelEvent(headerItem)
                    if headerData['dados']:
                        headerItem.setCurrentIndex(headerData['index'])
                    if headerData['func']:
                        headerItem.currentIndexChanged.connect(partial(headerData['func'], combo_box=headerItem))
                    self.itens.append(headerItem)

                headerItem.setGeometry(self.sectionViewportPosition(i), 0, self.sectionSize(i), self.height())
                headerItem.show()

        if len(self.itens) > self.count():
            for i in range(self.count(), len(self.itens)):
                self.itens[i].deleteLater()

        super(HorizontalHeader, self).showEvent(showEvent)

        if not self.loaded:
            self.loading.emit()
            self.loaded = True

    def handleSectionResized(self, sectionIndex: int = 0) -> None:
        """
        Handle section resize events, updating widget positions.
        
        Args:
            sectionIndex: The section index that was resized. Defaults to 0.
        """
        if self.itens:
            for i in range(self.count()):
                visualIdx = self.visualIndex(i)
                logicalIdx = self.logicalIndex(visualIdx)
                self.itens[i].setGeometry(self.sectionViewportPosition(logicalIdx), 0, self.sectionSize(logicalIdx), self.height())

    def handleSectionMoved(self, sectionIndex: int, oldVisualIndex: int, newVisualIndex: int) -> None:
        """
        Handle section move events, updating widget positions.
        
        Args:
            sectionIndex: The section index that was moved.
            oldVisualIndex: The old visual index.
            newVisualIndex: The new visual index.
        """
        for i in range(min(oldVisualIndex, newVisualIndex), self.count()):
            logicalIdx = self.logicalIndex(i)
            self.itens[i].setGeometry(self.sectionViewportPosition(logicalIdx), 0, self.sectionSize(logicalIdx), self.height())
 
    def fixItemsPositions(self) -> None:
        """
        Fix the positions of all header items.
        """
        if self.itens:
            for i in range(self.count()):
                self.itens[i].setGeometry(self.sectionViewportPosition(i), 0, self.sectionSize(i), self.height())

