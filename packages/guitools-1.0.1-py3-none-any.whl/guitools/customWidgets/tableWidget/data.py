

from typing import Any, Callable
from PySide6.QtWidgets import QTableWidget, QWidget
from PySide6.QtGui import QIcon
from PySide6 import QtCore
from .utils import randomString
from ..comboBox import ComboBox
from ...style import Styles

class QData(object):
    """
    Factory class for creating data dictionaries for table widgets.
    
    This class provides static methods to create data dictionaries that define
    how cells should be rendered in a QTableWidget.
    """

    @staticmethod
    def pushButton(text: str, func: Callable[[], None] | None = None, enabled: bool = True, icon: QIcon | None = None, iconData: Styles.Resources.Data | None = None, style: str | None = None) -> dict[str, Any]:
        """
        Create a data dictionary for a QPushButton cell.
        
        Args:
            text: The button text.
            func: The callback function to execute on click. Defaults to None.
            enabled: Whether the button is enabled. Defaults to True.
            icon: The button icon. Defaults to None.
            iconData: Icon data from Styles.Resources. Defaults to None.
            style: Custom CSS style string. Defaults to None.
        
        Returns:
            A dictionary defining the push button cell.
        """
        return {'type': 'QPushButton', 'id': f'QPushButton_{randomString(10)}', 'text': str(text), 'func': func, 'enabled': enabled, 'icon': icon, 'icon_data': iconData, 'style': style}

    @staticmethod
    def spinBox(func: Callable[[], None] | None = None, minimum: int = 0, value: int | None = None, maximum: int | None = None) -> dict[str, Any]:
        """
        Create a data dictionary for a QSpinBox cell.
        
        Args:
            func: The callback function to execute on editing finished. Defaults to None.
            minimum: The minimum value. Defaults to 0.
            value: The initial value. Defaults to None.
            maximum: The maximum value. Defaults to None.
        
        Returns:
            A dictionary defining the spin box cell.
        """
        return {'type': 'QSpinBox', 'id': f'QSpinBox_{randomString(10)}', 'func': func, 'minimum': minimum, 'value': value, 'maximum': maximum}
    
    @staticmethod
    def doubleSpinBox(func: Callable[[], None] | None = None, minimum: float = 0.0, decimals: int = 2, singleStep: float = 1.00, value: int | None = None, maximum: int | None = None) -> dict[str, Any]:
        """
        Create a data dictionary for a QDoubleSpinBox cell.
        
        Args:
            func: The callback function to execute on editing finished. Defaults to None.
            minimum: The minimum value. Defaults to 0.0.
            decimals: The number of decimal places. Defaults to 2.
            singleStep: The step size. Defaults to 1.00.
            value: The initial value. Defaults to None.
            maximum: The maximum value. Defaults to None.
        
        Returns:
            A dictionary defining the double spin box cell.
        """
        return {'type': 'QDoubleSpinBox', 'id': f'QDoubleSpinBox_{randomString(10)}', 'func': func, 'minimum': minimum, 'decimals': decimals, 'single_step': singleStep, 'value': value, 'maximum': maximum}

    @staticmethod
    def checkbox(text: str, func: Callable[[], None] | None = None, checked: bool = False, toolTip: str | None = "") -> dict[str, Any]:
        """
        Create a data dictionary for a QCheckBox cell.
        
        Args:
            text: The checkbox text.
            func: The callback function to execute on toggle. Defaults to None.
            checked: Whether the checkbox is initially checked. Defaults to False.
            toolTip: The tooltip text. Defaults to "".
        
        Returns:
            A dictionary defining the checkbox cell.
        """
        return {'type': 'QCheckBox', 'id': f'QCheckBox_{randomString(10)}', 'text': str(text), 'func': func, 'checked': checked, 'toolTip': toolTip}

    @staticmethod
    def iconCheckBox(text: str, func: Callable[[], None] | None = None, checked: bool = False, icon: QIcon | None = None, spacing: int | None = None) -> dict[str, Any]:
        """
        Create a data dictionary for an IconCheckBox cell.
        
        Args:
            text: The checkbox text.
            func: The callback function to execute on toggle. Defaults to None.
            checked: Whether the checkbox is initially checked. Defaults to False.
            icon: The icon to display. Defaults to None.
            spacing: The spacing between icon and text. Defaults to None.
        
        Returns:
            A dictionary defining the icon checkbox cell.
        """
        return {'type': 'IconQCheckBox', 'id': f'IconQCheckBox_{randomString(10)}', 'text': str(text), 'func': func, 'checked': checked, 'icon': icon, 'spacing': spacing}

    @staticmethod
    def comboBox(func: Callable[[], None] | None = None, dados: list[str] | ComboBox.DataUpdate = [], index: int = 0) -> dict[str, Any]:
        """
        Create a data dictionary for a QComboBox cell.
        
        Args:
            func: The callback function to execute on selection change. Defaults to None.
            dados: The data for the combo box (list or DataUpdate). Defaults to [].
            index: The initial selected index. Defaults to 0.
        
        Returns:
            A dictionary defining the combo box cell.
        """
        return {'type': 'QComboBox', 'id': f'QComboBox_{randomString(10)}', 'func': func, 'dados': dados, 'index': index}

    @staticmethod
    def comboBoxUncheck(text: str, func: Callable[[], None] | None = None, dados: list[str] = [], itemSelectAll: bool = False) -> dict[str, Any]:
        """
        Create a data dictionary for a ComboBoxUncheck cell.
        
        Args:
            text: The fixed text for the combo box.
            func: The callback function to execute on toggle. Defaults to None.
            dados: The data for the combo box. Defaults to [].
            itemSelectAll: Whether to include a "Select All" item. Defaults to False.
        
        Returns:
            A dictionary defining the uncheck combo box cell.
        """
        return {'type': 'ComboBoxUncheck', 'id': f'ComboBoxUncheck_{randomString(10)}', 'text': str(text), 'func': func, 'dados': dados}

    @staticmethod
    def comboBoxCheckable(text: str, func: Callable[[], None] | None = None, dados: list[str] = [], itemSelectAll: bool = False, icon: QIcon | None = None) -> dict[str, Any]:
        """
        Create a data dictionary for a CheckBoxCheckable (checkable combo box) cell.
        
        Args:
            text: The fixed text for the combo box.
            func: The callback function to execute on toggle. Defaults to None.
            dados: The data for the combo box. Defaults to [].
            itemSelectAll: Whether to include a "Select All" item. Defaults to False.
            icon: The icon to display. Defaults to None.
        
        Returns:
            A dictionary defining the checkable combo box cell.
        """
        return {'type': 'CheckBoxCheckable', 'id': f'CheckBoxCheckable_{randomString(10)}', 'text': str(text), 'func': func, 'dados': dados, 'itemSelectAll': itemSelectAll, 'icon': icon}
 
    @staticmethod
    def customWidget(funcCreateWidget: Callable[[], QWidget]) -> dict[str, Any]:
        """
        Create a data dictionary for a custom QWidget cell.
        
        Args:
            funcCreateWidget: A callable that returns a QWidget instance.
        
        Returns:
            A dictionary defining the custom widget cell.
        """
        return {'type': 'QWidget', 'id': f'QWidget_{randomString(10)}', 'func_create_widget': funcCreateWidget}


class QDataRow(QData):
    """
    Factory class for creating data dictionaries for table row cells.
    
    Extends QData with additional methods specific to row cells.
    """

    @staticmethod
    def iconLabelpushButton(text: str, pushButtonFunc: Callable[[], None], pushButtonIconData: Styles.Resources.Data | None = None, labelIconData: Styles.Resources.Data | None = None, iconSize: int = 16, margins: tuple[int, int, int, int] = (0, 0, 0, 0)) -> dict[str, Any]:
        """
        Create a data dictionary for an IconLabelPushButton cell.
        
        Args:
            text: The label text.
            pushButtonFunc: The callback function for the push button.
            pushButtonIconData: Icon data for the push button. Defaults to None.
            labelIconData: Icon data for the label. Defaults to None.
            iconSize: The size of the icons. Defaults to 16.
            margins: The margins (left, top, right, bottom). Defaults to (0, 0, 0, 0).
        
        Returns:
            A dictionary defining the icon label push button cell.
        """
        return {'type': 'IconLabelPushButton', 'id': f'IconLabel_{randomString(10)}', 'text': str(text), 'pushButton_func': pushButtonFunc, 'pushButton_icon_data': pushButtonIconData, 'label_icon_data': labelIconData, 'icon_size': iconSize, 'margins': margins}

    @staticmethod
    def iconLabel(text: str, icon: QIcon | None = None, iconData: Styles.Resources.Data | None = None, iconSize: int = 16, margins: tuple[int, int, int, int] = (0, 0, 0, 0)) -> dict[str, Any]:
        """
        Create a data dictionary for an IconLabel cell.
        
        Args:
            text: The label text.
            icon: The icon to display. Defaults to None.
            iconData: Icon data from Styles.Resources. Defaults to None.
            iconSize: The size of the icon. Defaults to 16.
            margins: The margins (left, top, right, bottom). Defaults to (0, 0, 0, 0).
        
        Returns:
            A dictionary defining the icon label cell.
        """
        return {'type': 'IconLabel', 'id': f'IconLabel_{randomString(10)}', 'text': str(text), 'icon': icon, 'icon_data': iconData, 'icon_size': iconSize, 'margins': margins}

    @staticmethod
    def label(text: str, icon: QIcon | None = None, iconSize: int = 16, funcDoubleClick: Callable[[], None] | None = None, cursorPointer: bool = False, alignment: QtCore.Qt.AlignmentFlag | None = None, styleSheet: str = "") -> dict[str, Any]:
        """
        Create a data dictionary for a QLabel cell.
        
        Args:
            text: The label text.
            icon: The icon to display. Defaults to None.
            iconSize: The size of the icon. Defaults to 16.
            funcDoubleClick: Callback function for double-click event. Defaults to None.
            cursorPointer: Whether to show pointer cursor. Defaults to False.
            alignment: The text alignment. Defaults to None.
            styleSheet: Custom CSS style string. Defaults to "".
        
        Returns:
            A dictionary defining the label cell.
        """
        return {'type': 'QLabel', 'id': f'QLabel_{randomString(10)}', 'text': str(text), 'icon': icon, 'icon_size': iconSize, "func_double_click": funcDoubleClick, "cursor_pointer": cursorPointer, "alignment": alignment, "style_sheet": styleSheet}

    @staticmethod
    def stateLabel(style: str, size: int = 10) -> dict[str, Any]:
        """
        Create a data dictionary for a StateLabel cell.
        
        Args:
            style: The CSS style string for the label.
            size: The fixed size (width and height) of the label. Defaults to 10.
        
        Returns:
            A dictionary defining the state label cell.
        """
        return {'type': 'StateLabel', 'id': f'StateLabel_{randomString(10)}', 'style': str(style), 'size': size}

    @staticmethod
    def tableWidgetItem(text: str, alignment: QtCore.Qt.AlignmentFlag = QtCore.Qt.AlignmentFlag.AlignVCenter, editable: bool = True, *foreground: int) -> dict[str, Any]:
        """
        Create a data dictionary for a QTableWidgetItem cell.
        
        Args:
            text: The item text.
            alignment: The text alignment. Defaults to AlignVCenter.
            editable: Whether the item is editable. Defaults to True.
            *foreground: RGB values for the foreground color.
        
        Returns:
            A dictionary defining the table widget item cell.
        """
        return {'type': 'QTableWidgetItem', 'text': str(text), 'alignment': alignment, 'editable': editable, 'foreground': foreground if foreground else None}

    @staticmethod
    def lineEdit(text: str, readOnly: bool = False, maxLength: int | None = None) -> dict[str, Any]:
        """
        Create a data dictionary for a QLineEdit cell.
        
        Args:
            text: The initial text.
            readOnly: Whether the line edit is read-only. Defaults to False.
            maxLength: The maximum length of the text. Defaults to None.
        
        Returns:
            A dictionary defining the line edit cell.
        """
        return {'type': 'QLineEdit', 'id': f'QLineEdit_{randomString(10)}', 'text': str(text), 'readOnly': readOnly, 'MaxLength': maxLength}

    @staticmethod
    def progressBar(value: int = 0, format: str = "") -> dict[str, Any]:
        """
        Create a data dictionary for a QProgressBar cell.
        
        Args:
            value: The progress value (0-100). Defaults to 0.
            format: The format string for the progress bar. Defaults to "".
        
        Returns:
            A dictionary defining the progress bar cell.
        """
        return {'type': 'QProgressBar', 'id': f'QProgressBar{randomString(10)}', 'value': value, 'format': format}

    @staticmethod
    def cellNone() -> dict[str, None]:
        """
        Create a data dictionary for an empty cell.
        
        Returns:
            A dictionary defining an empty cell.
        """
        return {'type': None}


class QDataHeader(QData):
    """
    Factory class for creating data dictionaries for table header items.
    
    Extends QData with methods specific to header cells.
    """

    @staticmethod
    def HeaderItem(text: str, styleSheet: str = "", alignment: QtCore.Qt.AlignmentFlag = QtCore.Qt.AlignmentFlag.AlignLeft, icon: QIcon | None = None, iconSize: int = 16) -> dict[str, Any]:
        """
        Create a data dictionary for a header item.
        
        Args:
            text: The header text.
            styleSheet: Custom CSS style string. Defaults to "".
            alignment: The text alignment. Defaults to AlignLeft.
            icon: The icon to display. Defaults to None.
            iconSize: The size of the icon. Defaults to 16.
        
        Returns:
            A dictionary defining the header item.
        """
        return {'type': 'HeaderItem', 'styleSheet': styleSheet, 'text': str(text), 'alignment': alignment, 'icon': icon, 'icon_size': iconSize}

    @staticmethod
    def HeaderItemFilter(text: str, styleSheet: str = "", alignment: QtCore.Qt.AlignmentFlag = QtCore.Qt.AlignmentFlag.AlignLeft) -> dict[str, Any]:
        """
        Create a data dictionary for a filterable header item.
        
        Args:
            text: The header text.
            styleSheet: Custom CSS style string. Defaults to "".
            alignment: The text alignment. Defaults to AlignLeft.
        
        Returns:
            A dictionary defining the filterable header item.
        """
        return {'type': 'HeaderItemFilter', 'styleSheet': styleSheet, 'text': str(text), 'alignment': alignment}


class QDataTable(object):
    """
    A data structure for managing table data using numpy arrays.
    
    This class stores table data in a numpy array and provides methods
    to add rows and manage the table structure.
    """
   
    def __init__(self, tableWidget: QTableWidget) -> None:
        """
        Initialize the QDataTable.
        
        Args:
            tableWidget: The QTableWidget this data table is associated with.
        """
        import numpy as np
        self.array = np.zeros((0, tableWidget.columnCount()), np.dtype(dict))
        self.tableWidget: QTableWidget = tableWidget

    @property
    def rowCount(self) -> int:
        """
        Get the number of rows in the data table.
        
        Returns:
            The number of rows.
        """
        return self.array.shape[0]

    @rowCount.setter
    def rowCount(self, value: int) -> None:
        """
        Set the number of rows (not implemented).
        
        Args:
            value: The desired number of rows.
        """
        ...

    def addRow(self, row: int, column: int, dataRow: dict[str, Any]) -> None:
        """
        Add or update a cell in the data table.
        
        Args:
            row: The row index.
            column: The column index.
            dataRow: The data dictionary for the cell.
        """
        import numpy as np
        rowDifference = row - self.array.shape[0] + 1
        if rowDifference > 0:
            for index in range(rowDifference):
                newRow = []
                for i in range(self.array.shape[1]):
                    newRow.append(QDataRow.cellNone())

                newRowArray = np.array(newRow)
                
                self.array = np.vstack((self.array, newRowArray))
                self.array[row, column] = dataRow
        else:
            self.array[row, column] = dataRow


class QDataTableRow(object):
    """
    A data structure for managing a single row of table data.
    
    This class stores data for a single row in a numpy array.
    """
   
    def __init__(self, tableWidget: QTableWidget, row: int) -> None:
        """
        Initialize the QDataTableRow.
        
        Args:
            tableWidget: The QTableWidget this row belongs to.
            row: The row index in the table.
        """
        import numpy as np
        self.array = np.zeros((0, tableWidget.columnCount()), np.dtype(dict))
        self.row: int = row
        self.tableWidget: QTableWidget = tableWidget

    @property
    def rowCount(self) -> int:
        """
        Get the number of rows (always 1 for a single row).
        
        Returns:
            The number of rows (1).
        """
        return self.array.shape[0]

    @rowCount.setter
    def rowCount(self, value: int) -> None:
        """
        Set the number of rows (not implemented).
        
        Args:
            value: The desired number of rows.
        """
        ...

    def addItem(self, column: int, dataRow: dict[str, Any]) -> None:
        """
        Add or update a cell in the row.
        
        Args:
            column: The column index.
            dataRow: The data dictionary for the cell.
        """
        import numpy as np
        rowDifference = 0 - self.array.shape[0] + 1
        if rowDifference > 0:
            for index in range(rowDifference):
                newRow = []
                for i in range(self.array.shape[1]):
                    newRow.append(QDataRow.cellNone())

                newRowArray = np.array(newRow)
                
                self.array = np.vstack((self.array, newRowArray))
                self.array[0, column] = dataRow
        else:
            self.array[0, column] = dataRow

