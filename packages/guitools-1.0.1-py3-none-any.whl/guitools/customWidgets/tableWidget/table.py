

from PySide6.QtWidgets import (QHeaderView, QTableWidget, QApplication, QTableWidgetItem, QTreeWidget, QProgressBar, QLineEdit,
                             QPushButton, QSpinBox, QDoubleSpinBox, QCheckBox, QAbstractSpinBox, QComboBox, QWidget)
from PySide6.QtGui import QBrush, QColor
from PySide6 import QtCore
from PySide6.QtCore import QSize, Qt
from functools import partial
from typing import TypeVar, overload, Type, Any, Callable
from time import sleep

from .utils import randomString, AlignDelegate
from .data import QData, QDataRow, QDataHeader, QDataTable, QDataTableRow
from .header import HorizontalHeader
from ..comboBox import ComboBox
from ...thread import Thread
from ...style import Styles
from ..composite import IconLabelPushButton, IconLabel, IconCheckBox
from ..base import StateLabel, Label

T = TypeVar('T')


class TableWidget(object):
    """
    A utility class for managing QTableWidget functionality.
    
    This class provides static methods and nested classes for working with
    QTableWidget instances, including cell widgets, headers, and data management.
    """

    class Headers(object):
        """
        A class for managing multiple horizontal headers globally.
        """
        headersList = []

        @classmethod
        def updateResize(cls) -> None:
            """
            Update resize for all registered headers, removing invalid ones.
            """
            deletedHeaders = []
            for header in cls.headersList:
                try:
                    header.handleSectionResized()
                except Exception:
                    deletedHeaders.append(header)
            for deletedHeader in deletedHeaders:
                cls.headersList.remove(deletedHeader)

        @classmethod
        def updateStyleSheetHeaderItem(cls, styleSheet: str) -> None:
            """
            Update the style sheet for all filter header items in all registered headers.
            
            Args:
                styleSheet: The CSS style sheet string to apply.
            """
            for header in cls.headersList:
                header.updateStyleSheetHeaderItem(styleSheet)

    @staticmethod
    def updateResize(tableWidget: QTableWidget) -> None:
        """
        Force a resize update of the table widget.
        
        Args:
            tableWidget: The QTableWidget to update.
        """
        tableWidget.resize(QSize(tableWidget.width() - 1, tableWidget.height()))
        tableWidget.resize(QSize(tableWidget.width() + 1, tableWidget.height()))

    @staticmethod
    def actionTogglingVerticalScroll(tableWidget: QTableWidget, action: Callable[[bool], None]) -> None:
        """
        Execute an action based on whether vertical scrolling is needed.
        
        Args:
            tableWidget: The QTableWidget to check.
            action: Callback function that receives a boolean indicating if scrolling is needed.
        """
        totalHeight = sum(tableWidget.rowHeight(row) for row in range(tableWidget.rowCount()))
        if totalHeight > tableWidget.viewport().height():
            action(True)
        else:
            action(False)

    @staticmethod
    def actionTogglingHorizontalScroll(tableWidget: QTableWidget, action: Callable[[bool], None]) -> None:
        """
        Execute an action based on whether horizontal scrolling is needed.
        
        Args:
            tableWidget: The QTableWidget to check.
            action: Callback function that receives a boolean indicating if scrolling is needed.
        """
        totalWidth = sum(tableWidget.columnWidth(col) for col in range(tableWidget.columnCount()))
        if totalWidth > tableWidget.viewport().width():
            action(True)
        else:
            action(False)

  
    class QDataTable(QDataTable):
        ...

    class QDataTableRow(QDataTableRow):
        ...

    class QDataHeader(QDataHeader):
        ...
        
    class QDataRow(QDataRow):
        ...


    class CellWidget:
        """
        Utility class for managing cell widgets in a table.
        """

        @staticmethod
        def update(tableWidget: QTableWidget, data: dict[str, Any], row: int, column: int, updateResize: bool = True) -> None:
            """
            Update a cell widget or item in the table.
            
            Args:
                tableWidget: The QTableWidget to update.
                data: Dictionary defining the cell data.
                row: The row index.
                column: The column index.
                updateResize: Whether to update the table resize. Defaults to True.
            """
            cellWidget = tableWidget.cellWidget(row, column)
            cellItem = tableWidget.item(row, column)
            
            if cellWidget:
                if data['type'] != None:
                    TableWidget.addItem(tableWidget, row, column, data)
                else:
                    tableWidget.removeCellWidget(row, column)

            if cellItem:
                if data['type'] != None:
                    TableWidget.addItem(tableWidget, row, column, data)
                else:
                    tableWidget.takeItem(row, column)

            if not cellWidget and not cellItem:
                if data['type'] != None:
                    TableWidget.addItem(tableWidget, row, column, data)

            if updateResize:
                TableWidget.updateResize(tableWidget)

        @overload
        @staticmethod
        def widget(tableWidget: QTableWidget, row: int, column: int) -> QWidget:
            """
            Get the widget at the specified cell.
            
            Args:
                tableWidget: The QTableWidget.
                row: The row index.
                column: The column index.
            
            Returns:
                The widget at the specified cell.
            """
            pass

        @overload
        @staticmethod
        def widget(type: Type[T], tableWidget: QTableWidget, row: int, column: int) -> T:
            """
            Get the widget at the specified cell with type checking.
            
            Args:
                type: The expected widget type.
                tableWidget: The QTableWidget.
                row: The row index.
                column: The column index.
            
            Returns:
                The widget at the specified cell, cast to the specified type.
            """
            pass

        def widget(*args):
            """
            Get the widget at the specified cell (implementation).
            
            Returns:
                The widget at the specified cell.
            """
            typeIndex = -1
            if len(args) == 4:
                typeIndex = 0
            tableWidget = args[typeIndex + 1]
            row = args[typeIndex + 2] 
            column = args[typeIndex + 3] 
            return tableWidget.cellWidget(row, column)

        @staticmethod
        def enabled(tableWidget: QTableWidget, enabled: bool, ignoreRows: list[int] = [], ignoreColumn: list[int] = []) -> None:
            """
            Enable or disable all cell widgets, optionally ignoring specific rows and columns.
            
            Args:
                tableWidget: The QTableWidget to update.
                enabled: Whether to enable or disable the widgets.
                ignoreRows: List of row indices to ignore. Defaults to [].
                ignoreColumn: List of column indices to ignore. Defaults to [].
            """
            for column in range(tableWidget.columnCount()):
                if column not in ignoreColumn:
                    for row in range(tableWidget.rowCount()):
                        if row not in ignoreRows:
                            cellWidget = tableWidget.cellWidget(row, column)
                            if cellWidget:
                                tableWidget.cellWidget(row, column).setEnabled(enabled)

        @staticmethod
        def enabledRow(tableWidget: QTableWidget, enabled: bool, row: int, ignoreColumns: list[int] = []) -> None:
            """
            Enable or disable all cell widgets in a specific row.
            
            Args:
                tableWidget: The QTableWidget to update.
                enabled: Whether to enable or disable the widgets.
                row: The row index.
                ignoreColumns: List of column indices to ignore. Defaults to [].
            """
            for column in range(tableWidget.columnCount()):
                if column not in ignoreColumns:
                    cellWidget = tableWidget.cellWidget(row, column)
                    if cellWidget:
                        tableWidget.cellWidget(row, column).setEnabled(enabled)

        @staticmethod
        def enabledColumn(tableWidget: QTableWidget, enabled: bool, column: int, ignoreRows: list[int] = []) -> None:
            """
            Enable or disable all cell widgets in a specific column.
            
            Args:
                tableWidget: The QTableWidget to update.
                enabled: Whether to enable or disable the widgets.
                column: The column index.
                ignoreRows: List of row indices to ignore. Defaults to [].
            """
            for row in range(tableWidget.rowCount()):
                if row not in ignoreRows:
                    cellWidget = tableWidget.cellWidget(row, column)
                    if cellWidget:
                        tableWidget.cellWidget(row, column).setEnabled(enabled)

        @staticmethod
        def singleSelectionCheckBox(tableWidget: QTableWidget, currentCheckBox: QCheckBox, column: int) -> None:
            """
            Ensure only one checkbox is selected in a column (single selection mode).
            
            Args:
                tableWidget: The QTableWidget.
                currentCheckBox: The currently checked checkbox.
                column: The column index.
            """
            if currentCheckBox.isChecked():
                for row in range(tableWidget.rowCount()):
                   checkBox = TableWidget.CellWidget.widget(QCheckBox, tableWidget, row, column)
                   if checkBox:
                       if checkBox != currentCheckBox:
                           if checkBox.isChecked():
                               checkBox.setChecked(False)


        @staticmethod
        def getSelectedCheckBox(tableWidget: QTableWidget, column: int) -> QCheckBox | None:
            """
            Get the selected checkbox in a column.
            
            Args:
                tableWidget: The QTableWidget.
                column: The column index.
            
            Returns:
                The selected checkbox, or None if none is selected.
            """
            for row in range(tableWidget.rowCount()):
                checkBox = TableWidget.CellWidget.widget(QCheckBox, tableWidget, row, column)
                if checkBox:
                    if checkBox.isChecked():
                        return checkBox
            return None

        @classmethod
        def copyOnCellDoubleClick(cls, tableWidget: QTableWidget, foregroundColor: tuple[int, int, int] = (73, 145, 246)) -> None:
            """
            Enable copying cell content on double-click.
            
            Args:
                tableWidget: The QTableWidget to enable copying for.
                foregroundColor: RGB color tuple for visual feedback. Defaults to (73, 145, 246).
            """
            tableWidget.cellDoubleClicked.connect(partial(cls.copyCellContent, tableWidget=tableWidget, foregroundColor=foregroundColor))

        @staticmethod
        def copyCellContent(row: int, column: int, tableWidget: QTableWidget, foregroundColor: tuple[int, int, int] = (73, 145, 246)) -> None:
            """
            Copy the content of a cell to the clipboard with visual feedback.
            
            Args:
                row: The row index.
                column: The column index.
                tableWidget: The QTableWidget.
                foregroundColor: RGB color tuple for visual feedback. Defaults to (73, 145, 246).
            """
            # Check if the cell exists in the QTableWidget
            if tableWidget.item(row, column):
                cellItem = tableWidget.item(row, column)
          
                originalForeground = cellItem.foreground()
                cellItem.setForeground(QColor(*foregroundColor))
                cellContent = cellItem.text()

                # Copy the cell content to the clipboard
                QApplication.clipboard().setText(cellContent)

                def restoreColor() -> None:
                    sleep(1)
                    cellItem.setForeground(originalForeground)
                Thread.new(restoreColor)

    @staticmethod
    def alignCenterItems(tableWidget: QTableWidget, listIndex: list[int] = [], resizeModeStretch: bool = True) -> None:
        """
        Align items to center in specified columns.
        
        Args:
            tableWidget: The QTableWidget to update.
            listIndex: List of column indices to align. If empty, aligns all columns. Defaults to [].
            resizeModeStretch: Whether to set resize mode to stretch. Defaults to True.
        """
        columnIndices = listIndex if listIndex else [index for index in range(tableWidget.columnCount())]
        for columnIndex in columnIndices:
            alignDelegate = AlignDelegate(tableWidget)
            tableWidget.setItemDelegateForColumn(columnIndex, alignDelegate)
            if resizeModeStretch:
                tableWidget.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)

    class CellData(object):
        """
        Data class representing a cell in the table.
        """
        def __init__(self, widget: QWidget | QTableWidgetItem, row: int, column: int):
            """
            Initialize the CellData.
            
            Args:
                widget: The widget or item in the cell.
                row: The row index.
                column: The column index.
            """
            self.widget = widget
            self.type = type(widget)
            self.row = row
            self.column = column

    @classmethod
    def getDataColumn(cls, tableWidget: QTableWidget, column: int) -> list[CellData | None]:
        """
        Get all cell data for a specific column.
        
        Args:
            tableWidget: The QTableWidget.
            column: The column index.
        
        Returns:
            A list of CellData objects or None for empty cells.
        """
        columnData = []
        for row in range(tableWidget.rowCount()):
            cellItem = tableWidget.item(row, column)
            if cellItem:
                columnData.append(cls.CellData(cellItem, row, column))
            else:
                cellWidget = tableWidget.cellWidget(row, column)
                if cellWidget:
                    columnData.append(cls.CellData(cellWidget, row, column))
                else:
                    columnData.append(None)
        return columnData

    @classmethod
    def getDataRow(cls, tableWidget: QTableWidget, row: int) -> list[CellData | None]:
        """
        Get all cell data for a specific row.
        
        Args:
            tableWidget: The QTableWidget.
            row: The row index.
        
        Returns:
            A list of CellData objects or None for empty cells.
        """
        rowData = []
        for column in range(tableWidget.columnCount()):
            cellItem = tableWidget.item(row, column)
            if cellItem:
                rowData.append(cls.CellData(cellItem, row, column))
            else:
                cellWidget = tableWidget.cellWidget(row, column)
                if cellWidget:
                    rowData.append(cls.CellData(cellWidget, row, column))
                else:
                    rowData.append(None)
        return rowData
  
    class SetHorizontalHeader(object):
        """
        Wrapper class for setting a custom horizontal header on a table widget.
        """

        def __init__(self, tableWidget: QTableWidget, dataHeaders: list[dict[str, Any]]) -> None:
            """
            Initialize the SetHorizontalHeader.
            
            Args:
                tableWidget: The QTableWidget to set the header on.
                dataHeaders: List of dictionaries defining header items.
            """
            self.tableWidget: QTableWidget = tableWidget
            tableWidget.setHorizontalHeader(HorizontalHeader(dataHeaders, tableWidget))
            tableWidget.scrollContentsBy = self.scrollContentsBy
            TableWidget.Headers.headersList.append(tableWidget.horizontalHeader())

        def scrollContentsBy(self, dx: int, dy: int) -> None:
            """
            Handle scroll events and update header item positions.
            
            Args:
                dx: Horizontal scroll delta.
                dy: Vertical scroll delta.
            """
            QTableWidget.scrollContentsBy(self.tableWidget, dx, dy)
            if dx != 0:
                self.tableWidget.horizontalHeader().fixItemsPositions()


    class Header(object):
        """
        Wrapper class for accessing and manipulating table headers.
        """

        def __init__(self, tableWidget: QTableWidget | QTreeWidget) -> None:
            """
            Initialize the Header wrapper.
            
            Args:
                tableWidget: The QTableWidget or QTreeWidget.
            """
            self.tableWidget: QTableWidget | QTreeWidget = tableWidget
            if isinstance(tableWidget, QTreeWidget):
                 self.horizontalHeader = self.tableWidget.header()
            else:
                self.horizontalHeader = self.tableWidget.horizontalHeader()

        def updateResize(self) -> None:
            """
            Update the header resize.
            """
            self.horizontalHeader.handleSectionResized()

        def fixItemsPositions(self) -> None:
            """
            Fix the positions of all header items.
            """
            self.horizontalHeader.fixItemsPositions()
          
        def updateComboBoxUncheck(self, column: int, data: list[str]) -> None:
            """
            Update the data for an uncheck combo box in the header.
            
            Args:
                column: The column index.
                data: The new data list.
            """
            self.horizontalHeader.updateComboBoxUncheck(column, data)

        def updateComboBoxCheckable(self, column: int, data: list[str]) -> None:
            """
            Update the data for a checkable combo box in the header.
            
            Args:
                column: The column index.
                data: The new data list.
            """
            self.horizontalHeader.updateComboBoxCheckable(column, data)

        def updateStyleHeaderItemFilter(self, column: int, value: int) -> None:
            """
            Update the style of a filter header item based on the filter value.
            
            Args:
                column: The column index.
                value: The filter value (count of active filters).
            """
            headerLabel = self.horizontalHeader.cellHeader(column)
            if headerLabel:
                activatedStyle = f'''
                    background-color: {Styles.appColor()};
                    border-radius: 8px;
                    color: rgb(0, 0, 0);
                    font: 10pt "Segoe UI";
                    margin: 3px;
                '''

                disabledStyle = '''
                    font: 10pt "Segoe UI";
                    background-color: transparent;
                    color: transparent;
                    margin: 3px;
                '''
          
                if int(value) > 0:
                    headerLabel.setStyleSheet(activatedStyle)
                else:
                    headerLabel.setStyleSheet(disabledStyle)

                headerLabel.setText(str(value))

        @staticmethod
        def toggleCheckBoxInTable(checkBox: QCheckBox, tableWidget: QTableWidget, tableColumn: int) -> None:
            """
            Toggle all checkboxes in a column to match the header checkbox state.
            
            Args:
                checkBox: The header checkbox that was toggled.
                tableWidget: The QTableWidget.
                tableColumn: The column index.
            """
            if checkBox.text() != "ignore_event":
                isChecked = checkBox.isChecked()
                for row in range(tableWidget.rowCount()):
                    rowCheckBox = TableWidget.CellWidget.widget(QCheckBox, tableWidget, row, tableColumn)
                    if rowCheckBox:
                        if isChecked != rowCheckBox.isChecked():
                            rowCheckBox.setChecked(isChecked)

        @staticmethod
        def toggleIconCheckBoxInTable(iconCheckBox: IconCheckBox, tableWidget: QTableWidget, tableColumn: int) -> None:
            """
            Toggle all icon checkboxes in a column to match the header checkbox state.
            
            Args:
                iconCheckBox: The header icon checkbox that was toggled.
                tableWidget: The QTableWidget.
                tableColumn: The column index.
            """
            if iconCheckBox.checkbox.text() != "ignore_event":
                isChecked = iconCheckBox.checkbox.isChecked()
                for row in range(tableWidget.rowCount()):
                    rowIconCheckBox = TableWidget.CellWidget.widget(IconCheckBox, tableWidget, row, tableColumn)
                    if rowIconCheckBox:
                        if isChecked != rowIconCheckBox.checkbox.isChecked():
                            rowIconCheckBox.checkbox.setChecked(isChecked)

        @overload
        def widget(self, column: int) -> QWidget:
            """
            Get the widget at the specified header column.
            
            Args:
                column: The column index.
            
            Returns:
                The widget at the specified column.
            """
            pass

        @overload
        def widget(self, type: Type[T], column: int) -> T:
            """
            Get the widget at the specified header column with type checking.
            
            Args:
                type: The expected widget type.
                column: The column index.
            
            Returns:
                The widget at the specified column, cast to the specified type.
            """
            pass

        def widget(self, *args):
            """
            Get the widget at the specified header column (implementation).
            
            Returns:
                The widget at the specified column.
            """
            column = args[0] if len(args) == 1 else args[1]
            return self.horizontalHeader.cellHeader(column)

        def enabled(self, enabled: bool, columns: int | list[int] = None):
            """
            Enable or disable header widgets in specified columns.
            
            Args:
                enabled: Whether to enable or disable the widgets.
                columns: Column index or list of column indices. If None, applies to all columns.
            """
            if isinstance(columns, str):
                columns = [columns]
            if not columns:
                columns = list(range(self.tableWidget.columnCount()))
            for columnIndex in columns:
                headerWidget = self.horizontalHeader.cellHeader(columnIndex)
                if headerWidget:
                    self.horizontalHeader.cellHeader(columnIndex).setEnabled(enabled)
    
    @staticmethod
    def setHorizontalHeaderItem(tableWidget: QTableWidget, column: int, text: str, alignment: QtCore.Qt.AlignmentFlag = QtCore.Qt.AlignmentFlag.AlignVCenter) -> None:
        """
        Set the text and alignment for a horizontal header item.
        
        Args:
            tableWidget: The QTableWidget.
            column: The column index.
            text: The header text.
            alignment: The text alignment. Defaults to AlignVCenter.
        """
        if tableWidget.horizontalHeaderItem(column).text() != str(text):
            tableWidget.setHorizontalHeaderItem(column, QTableWidgetItem(str(text)))
            tableWidget.horizontalHeaderItem(column).setTextAlignment(alignment)
           
    @staticmethod
    def setForegroundItem(item: QTableWidgetItem, *rgb: int) -> None:
        """
        Set the foreground color of a table item.
        
        Args:
            item: The QTableWidgetItem.
            *rgb: RGB color values.
        """
        item.setForeground(QBrush(QColor(*rgb)))

    @staticmethod
    def setForegroundRow(tableWidget: QTableWidget, row: int, *rgb: int) -> None:
        """
        Set the foreground color for all items in a row.
        
        Args:
            tableWidget: The QTableWidget.
            row: The row index.
            *rgb: RGB color values.
        """
        for column in range(tableWidget.columnCount()):
            rowItem = tableWidget.item(row, column)
            if rowItem:
                rowItem.setForeground(QBrush(QColor(*rgb)))

    @classmethod
    def addItem(cls, tableWidget: QTableWidget, row: int, column: int, dataRow: dict[str, Any]) -> None:
        """
        Add an item or widget to a specific cell in the table.
        
        Args:
            tableWidget: The QTableWidget to add the item to.
            row: The row index.
            column: The column index.
            dataRow: Dictionary defining the cell data and type.
        """
        uniqueId = f'id###id{randomString(10)}'
        if dataRow['type'] == 'QTableWidgetItem':
            newItem = QTableWidgetItem(str(dataRow['text']))
            newItem.setTextAlignment(dataRow['alignment'])
            if not dataRow['editable']:
                newItem.setFlags(Qt.ItemFlag.ItemIsSelectable | Qt.ItemFlag.ItemIsEnabled)
        
            if dataRow['foreground']:
                cls.setForegroundItem(newItem, *dataRow['foreground'])
            tableWidget.setItem(row, column, newItem)

        elif dataRow['type'] == 'QWidget':
            customWidget = dataRow['func_create_widget']()
            customWidget.setObjectName(f"{dataRow['id']}{uniqueId}")
            tableWidget.setCellWidget(row, column, customWidget)

        elif dataRow['type'] == 'IconLabelPushButton':
            iconLabelPushButton = IconLabelPushButton(str(dataRow['text']), dataRow['pushButton_func'], dataRow['pushButton_icon_data'], dataRow['label_icon_data'], dataRow['icon_size'], dataRow['margins'], tableWidget)
            iconLabelPushButton.setObjectName(f"{dataRow['id']}{uniqueId}")
            tableWidget.setCellWidget(row, column, iconLabelPushButton)

        elif dataRow['type'] == 'IconLabel':
            iconLabel = IconLabel(str(dataRow['text']), dataRow['icon'], dataRow['icon_data'], dataRow['icon_size'], dataRow['margins'], tableWidget)
            iconLabel.setObjectName(f"{dataRow['id']}{uniqueId}")
            tableWidget.setCellWidget(row, column, iconLabel)

        elif dataRow['type'] == 'StateLabel':
            stateLabel = StateLabel(dataRow['style'], dataRow['size'], tableWidget)
            stateLabel.setObjectName(f"{dataRow['id']}{uniqueId}")
            tableWidget.setCellWidget(row, column, stateLabel)

        elif dataRow['type'] == 'QLabel':
            label = Label(dataRow['text'], dataRow['func_double_click'], tableWidget)
            if dataRow['alignment']:
                label.setAlignment(dataRow['alignment']) 
            if dataRow['icon']:
                iconPixmap = dataRow['icon'].pixmap(dataRow['icon_size'], dataRow['icon_size']) 
                label.setPixmap(iconPixmap)

            if dataRow['cursor_pointer']:
                label.setCursor(Qt.CursorShape.PointingHandCursor)

            label.setStyleSheet(f"{dataRow['style_sheet']}; background-color: 'transparent'")
            label.setObjectName(f"{dataRow['id']}{uniqueId}")
            tableWidget.setCellWidget(row, column, label)
    
        elif dataRow['type'] == 'QPushButton':
            pushButton = QPushButton(dataRow['text'], parent=tableWidget)
            pushButton.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            pushButton.setObjectName(f"{dataRow['id']}{uniqueId}")
            pushButton.setEnabled(dataRow['enabled'])
            if dataRow['style']:
                    pushButton.setStyleSheet(dataRow['style'])
            if dataRow['func']:
                pushButton.clicked.connect(dataRow['func'])

            if dataRow['icon_data']:
                iconData: Styles.Resources.Data = dataRow['icon_data']
                Styles.setIcon(pushButton, iconData.callableIcon, iconData.hoverCallableIcon, iconData.pixmapSize)
            elif dataRow['icon']:
                pushButton.setIcon(dataRow['icon'])

            tableWidget.setCellWidget(row, column, pushButton)

        elif dataRow['type'] == 'QSpinBox':
            spinBox = QSpinBox(tableWidget)
            spinBox.setObjectName(f"{dataRow['id']}{uniqueId}")
            spinBox.setMinimum(dataRow['minimum'])
            if dataRow['maximum'] != None:
                spinBox.setMaximum(dataRow['maximum'])
            if dataRow['func']:
                spinBox.editingFinished.connect(dataRow['func'])
            if dataRow['value'] != None:
                spinBox.setValue(dataRow['value'])
            tableWidget.setCellWidget(row, column, spinBox)

        elif dataRow['type'] == 'QDoubleSpinBox':
            doubleSpinBox = QDoubleSpinBox(tableWidget)
            doubleSpinBox.setObjectName(f"{dataRow['id']}{uniqueId}")
            stepType = QAbstractSpinBox.StepType.AdaptiveDecimalStepType
            doubleSpinBox.setStepType(stepType)
            doubleSpinBox.setDecimals(dataRow['decimals'])
            doubleSpinBox.setMinimum(dataRow['minimum'])
            doubleSpinBox.setSingleStep(dataRow['single_step'])
            if dataRow['maximum'] != None:
                doubleSpinBox.setMaximum(dataRow['maximum'])
            if dataRow['func']:
                doubleSpinBox.editingFinished.connect(dataRow['func'])
            if dataRow['value'] != None:
                doubleSpinBox.setValue(dataRow['value'])
            tableWidget.setCellWidget(row, column, doubleSpinBox)

        elif dataRow['type'] == 'QCheckBox':
            checkBox = QCheckBox(dataRow['text'])
            checkBox.setObjectName(f"{dataRow['id']}{uniqueId}")
            checkBox.setChecked(dataRow['checked'])
            if dataRow['func']:
                toggleCallback = lambda value, checkBox = checkBox, func = dataRow['func'] : func(checkBox)
                checkBox.toggled.connect(toggleCallback)
            if dataRow['toolTip'] != None:
                    toolTipText: str = dataRow['toolTip'] 
                    checkBox.setToolTip(toolTipText if toolTipText.strip() else dataRow['text'])
                    
            tableWidget.setCellWidget(row, column, checkBox)

        elif dataRow['type'] == 'IconQCheckBox':
            iconCheckBox = IconCheckBox(dataRow['text'], dataRow['icon'], spacing=dataRow['spacing'])
            iconCheckBox.setObjectName(f"{dataRow['id']}{uniqueId}")
            iconCheckBox.checkbox.setChecked(dataRow['checked'])
            if dataRow['func']:
                toggleCallback = lambda value, iconCheckBox = iconCheckBox, func = dataRow['func'] : func(iconCheckBox)
                iconCheckBox.checkbox.toggled.connect(toggleCallback)

            tableWidget.setCellWidget(row, column, iconCheckBox)

        elif dataRow['type'] == 'ComboBoxUncheck':
            comboBox = ComboBox.ComboBoxUncheck()
            comboBox.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            comboBox.setObjectName(f"{dataRow['id']}{uniqueId}")
            comboBox.setFixedText(dataRow['text'])
            if type(dataRow['dados']) == ComboBox.DataUpdate:
                ComboBox.updateData(comboBox, dataRow['dados'], dataRow['itemSelectAll'])
            else:
                ComboBox.update(comboBox, dataRow['dados'])
            ComboBox.ignoreWheelEvent(comboBox)
            if dataRow['func']:
                comboBox.setToggleItem(dataRow['func'])
            tableWidget.setCellWidget(row, column, comboBox)

        elif dataRow['type'] == 'QComboBox':
            comboBox = QComboBox()
            comboBox.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            comboBox.setObjectName(f"{dataRow['id']}{uniqueId}")
            ComboBox.ignoreWheelEvent(comboBox)
            if type(dataRow['dados']) == ComboBox.DataUpdate:
                ComboBox.updateData(comboBox, dataRow['dados'])
            else:
                ComboBox.update(comboBox, dataRow['dados'])
            if dataRow['dados']:
                    comboBox.setCurrentIndex(dataRow['index'])

            if dataRow['func']:
                comboBox.currentIndexChanged.connect(partial(dataRow['func'], combo_box=comboBox))
            iconSize = QtCore.QSize()
            iconSize.setHeight(15)
            iconSize.setWidth(15)
            comboBox.setIconSize(iconSize)
            tableWidget.setCellWidget(row, column, comboBox)

        elif dataRow['type'] == 'QLineEdit':
            lineEdit = QLineEdit()
            if dataRow.get('MaxLength'):
                lineEdit.setMaxLength(dataRow['MaxLength'])
            lineEdit.setObjectName(f"{dataRow['id']}{uniqueId}")
            lineEdit.setReadOnly(dataRow['readOnly'])
            lineEdit.setText(dataRow['text'])
            tableWidget.setCellWidget(row, column, lineEdit)

        elif dataRow['type'] == 'QProgressBar':
            progressBar = QProgressBar(tableWidget)
            progressBar.setValue(dataRow['value'])
            progressBar.setFormat(dataRow['format'])
            tableWidget.setCellWidget(row, column, progressBar)


    @classmethod
    def update(cls, dataTable: QDataTable, forceUpdate: bool = False, updateResize: bool = False) -> None:
        """
        Update the table widget with data from a QDataTable.
        
        Args:
            dataTable: The QDataTable containing the data to update.
            forceUpdate: Whether to clear contents before updating. Defaults to False.
            updateResize: Whether to update the table resize. Defaults to False.
        """
        tableWidget = dataTable.tableWidget

        if forceUpdate:
            tableWidget.clearContents()
            tableWidget.setRowCount(0)

        if dataTable.rowCount:

            tableWidget.setRowCount(dataTable.rowCount)
       
            for column in range(tableWidget.columnCount()):
                for row in range(dataTable.rowCount):
                    cellWidget = tableWidget.cellWidget(row, column)
                    cellItem = tableWidget.item(row, column)
                    
                    if cellWidget:
                        newData: dict[str, Any] = dataTable.array[row, column]
                        if newData['type'] != None:
                            newId = newData.get('id')
                            if newId and str(newId) != str(cellWidget.objectName().split('id###id')[0]):
                                cls.addItem(tableWidget, row, column, newData)
                            elif not newId:
                                cls.addItem(tableWidget, row, column, newData)
                        else:
                            tableWidget.removeCellWidget(row, column)

                    if cellItem:
                        newData = dataTable.array[row, column]
                        if newData['type'] != None:
                            if str(newData['text']) != cellItem.text():
                               cls.addItem(tableWidget, row, column, newData)
                        else:
                            tableWidget.takeItem(row, column)

                    if not cellWidget and not cellItem:
                        try:
                            newData = dataTable.array[row, column]
                            cls.addItem(tableWidget, row, column, newData)
                        except Exception:
                            pass
        else:
            tableWidget.setRowCount(0)

        if updateResize:
            TableWidget.updateResize(tableWidget)

    @classmethod
    def addDataTable(cls, dataTable: QDataTable, updateResize: bool = False) -> None:
        """
        Add rows from a QDataTable to the existing table widget.
        
        Args:
            dataTable: The QDataTable containing the data to add.
            updateResize: Whether to update the table resize. Defaults to False.
        """
        tableWidget = dataTable.tableWidget
        
        if dataTable.rowCount:
            currentRowCount = tableWidget.rowCount()
            tableWidget.setRowCount(currentRowCount + dataTable.rowCount)
       
            for column in range(tableWidget.columnCount()):
                for row in range(dataTable.rowCount):
                    try:
                        newData = dataTable.array[row, column]
                        cls.addItem(tableWidget, row + currentRowCount, column, newData)
                    except Exception:
                        pass
        if updateResize:
            TableWidget.updateResize(tableWidget)

    @classmethod
    def insertRow(cls, dataRow: QDataTableRow) -> None:
        """
        Insert a new row at the beginning of the table.
        
        Args:
            dataRow: The QDataTableRow containing the row data.
        """
        tableWidget = dataRow.tableWidget
        tableWidget.insertRow(0)

        if dataRow.rowCount:
            for column in range(tableWidget.columnCount()):
                    try:
                        newData = dataRow.array[0, column]
                        cls.addItem(tableWidget, dataRow.row, column, newData)
                    except Exception:
                        pass

    @classmethod
    def toggleCheckBoxInHeader(cls, checkBox: QCheckBox, tableWidget: QTableWidget, tableColumn: int, headerColumn: int) -> None:
        """
        Update the header checkbox state based on all checkboxes in the column.
        
        Args:
            checkBox: The checkbox that was toggled.
            tableWidget: The QTableWidget.
            tableColumn: The column index in the table.
            headerColumn: The column index in the header.
        """
        headerCheckBox = cls.Header(tableWidget).widget(QCheckBox, headerColumn)
        isChecked = checkBox.isChecked()
        originalText = headerCheckBox.text()
        headerCheckBox.setText("ignore_event")
        if not isChecked:
            if headerCheckBox.isChecked():
                headerCheckBox.setChecked(False)
            headerCheckBox.setText(originalText)
            return
        checkResults = []
        for row in range(tableWidget.rowCount()):
                rowCheckBox = cls.CellWidget.widget(QCheckBox, tableWidget, row, tableColumn)
                if rowCheckBox:
                    checkResults.append(rowCheckBox.isChecked())
        if False not in checkResults:
            if not headerCheckBox.isChecked():
                headerCheckBox.setChecked(True)

        headerCheckBox.setText(originalText)

    @classmethod
    def toggleIconCheckBoxInHeader(cls, iconCheckBox: IconCheckBox, tableWidget: QTableWidget, tableColumn: int, headerColumn: int) -> None:
        """
        Update the header icon checkbox state based on all icon checkboxes in the column.
        
        Args:
            iconCheckBox: The icon checkbox that was toggled.
            tableWidget: The QTableWidget.
            tableColumn: The column index in the table.
            headerColumn: The column index in the header.
        """
        headerIconCheckBox = cls.Header(tableWidget).widget(IconCheckBox, headerColumn)
        headerCheckBox = headerIconCheckBox.checkbox
        isChecked = iconCheckBox.checkbox.isChecked()

        originalText = headerCheckBox.text()
        headerCheckBox.setText("ignore_event")
        if not isChecked:
            if headerCheckBox.isChecked():
                headerCheckBox.setChecked(False)
            headerCheckBox.setText(originalText)
            return
        checkResults = []
        for row in range(tableWidget.rowCount()):
                rowIconCheckBox = cls.CellWidget.widget(IconCheckBox, tableWidget, row, tableColumn)
                if rowIconCheckBox:
                    checkResults.append(rowIconCheckBox.checkbox.isChecked())
        if False not in checkResults:
            if not headerCheckBox.isChecked():
                headerCheckBox.setChecked(True)

        headerCheckBox.setText(originalText)

    @classmethod
    def alignHeaders(cls, tableWidget: QTableWidget, alignment: Qt.AlignmentFlag = Qt.AlignmentFlag.AlignLeft) -> None:
        """
        Set the alignment for all header items.
        
        Args:
            tableWidget: The QTableWidget.
            alignment: The alignment flag. Defaults to AlignLeft.
        """
        columnCount = tableWidget.columnCount()
        for columnIndex in range(columnCount):
            headerItem = tableWidget.horizontalHeaderItem(columnIndex)
            if headerItem:
                headerItem.setTextAlignment(alignment | Qt.AlignmentFlag.AlignVCenter)

