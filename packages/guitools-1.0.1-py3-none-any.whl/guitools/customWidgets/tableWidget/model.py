

from typing import Any
import pandas as pd
from PySide6.QtCore import QModelIndex
from PySide6 import QtCore

class TableModel(QtCore.QAbstractTableModel):
    """
    A table model that wraps a pandas DataFrame for use with QHeaderView.
    """

    def __init__(self, data: pd.DataFrame) -> None:
        """
        Initialize the TableModel.
        
        Args:
            data: The pandas DataFrame to use as the data source.
        """
        super(TableModel, self).__init__()
        self._data: pd.DataFrame = data

    def data(self, index: QModelIndex, role: int) -> str | None:
        """
        Get the data for the given index and role.
        
        Args:
            index: The model index.
            role: The data role.
        
        Returns:
            The data as a string, or None if not applicable.
        """
        if role == QtCore.Qt.ItemDataRole.DisplayRole:
            cellValue = self._data.iloc[index.row(), index.column()]
            return str(cellValue)
        return None

    def rowCount(self, index: QModelIndex = QModelIndex()) -> int:
        """
        Get the number of rows in the model.
        
        Args:
            index: The parent index. Defaults to an empty QModelIndex.
        
        Returns:
            The number of rows.
        """
        return self._data.shape[0]

    def columnCount(self, index: QModelIndex = QModelIndex()) -> int:
        """
        Get the number of columns in the model.
        
        Args:
            index: The parent index. Defaults to an empty QModelIndex.
        
        Returns:
            The number of columns.
        """
        return self._data.shape[1]

    def headerData(self, section: int, orientation: QtCore.Qt.Orientation, role: int) -> str | None:
        """
        Get the header data for the given section, orientation, and role.
        
        Args:
            section: The index of the column/row.
            orientation: The orientation (horizontal or vertical).
            role: The data role.
        
        Returns:
            The header data as a string, or None if not applicable.
        """
        if role == QtCore.Qt.ItemDataRole.DisplayRole:
            if orientation == QtCore.Qt.Orientation.Horizontal:
                return str(self._data.columns[section])

            if orientation == QtCore.Qt.Orientation.Vertical:
                return str(self._data.index[section])
        return None

