

from PySide6.QtWidgets import QPushButton, QTextEdit, QFrame, QVBoxLayout, QHBoxLayout, QLabel
from PySide6.QtCore import QObject, QEvent
from pydantic import BaseModel
from typing import Callable
from .menu import Menu
from ...style import Styles

class ClickFilter(QObject):
    """
    Event filter to block clicks on QFrame and QLabel widgets.
    """
    
    def __init__(self, *args, **kwargs) -> None:
        """
        Initialize the ClickFilter.
        
        Args:
            *args: Variable length argument list passed to QObject.
            **kwargs: Arbitrary keyword arguments passed to QObject.
        """
        super().__init__(*args, **kwargs)
        
    def eventFilter(self, obj: QObject, event: QEvent) -> bool:
        """
        Filter events to block clicks on frames and labels.
        
        Args:
            obj: The object that the event is being filtered for.
            event: The event being filtered.
        
        Returns:
            True if the event should be blocked, False otherwise.
        """
        eventType = event.type()
        if eventType == QEvent.Type.MouseButtonPress or eventType == QEvent.Type.MouseButtonDblClick or eventType == QEvent.Type.MouseButtonRelease:
            if isinstance(obj, (QFrame, QLabel)):
                return True
        return super().eventFilter(obj, event)
    
CLICK_FILTER = ClickFilter()

class MenuTextEditVariables(Menu):
    """
    Menu for inserting variables into a text edit widget.
    
    This menu displays a list of variables that can be inserted into a QTextEdit
    at the cursor position, with automatic spacing handling.
    """

    class VariableModel(BaseModel):
        """
        Data model for a variable.
        
        Attributes:
            text: The display text for the variable.
            variable: The variable name to insert.
        """
        text: str
        variable: str

    class CustomAction(Menu.CustomWidgetAction):
        """
        Custom action that displays a list of variables as buttons.
        """

        class StyleSheet(Styles.Standard.StyleSheet):
            """
            Style sheet for the variable menu.
            """
            
            def __init__(self):
                """
                Initialize the StyleSheet.
                """
                super().__init__()

            def style(self) -> str:
                """
                Generate the style sheet string.
                
                Returns:
                    The CSS style sheet string.
                """
                buttonStyle = Styles.button()
                buttonStyle.button.add_additional_style(f'text-align: left; {Styles.Property.FontSegoeUI(10)}')

                return f'''
                     {Styles.standard()}
                     QFrame {{{Styles.Property.BackgroundColor(Styles.Color.table)}}}
                     {buttonStyle}
                     '''
        
        def __init__(self, callableClose: Callable[[], None], textEdit: QTextEdit, variables: list['MenuTextEditVariables.VariableModel'], title: str) -> None:
            """
            Initialize the CustomAction.
            
            Args:
                callableClose: Callback function to close the menu.
                textEdit: The text edit widget to insert variables into.
                variables: List of variable models to display.
                title: Title text to display at the top of the menu.
            """
            super().__init__(None)
            self.callableClose: Callable[[], None] = callableClose
            self.textEdit: QTextEdit = textEdit
            self.variables: list['MenuTextEditVariables.VariableModel'] = variables
            mainLayout = QVBoxLayout()
            mainLayout.setContentsMargins(5, 5, 5, 5)
            mainLayout.setSpacing(5)

            headerLayout = QHBoxLayout()
            headerLayout.setContentsMargins(5, 0, 0, 0)
            headerLayout.setSpacing(5)
            titleLabel = QLabel(title)
            titleLabel.setStyleSheet('font: 63 13pt "Segoe UI Semibold"')
            
            mainLayout.addWidget(titleLabel)

            for variable in self.variables:
                variableButton = QPushButton(variable.text)
                variableButton.clicked.connect(lambda _, var=variable: self.insertVariable(var))
                mainLayout.addWidget(variableButton)

            containerWidget = QFrame()
            containerWidget.setLayout(mainLayout)
            containerWidget.installEventFilter(CLICK_FILTER)
            Styles.setWidgetStyleTheme(self.StyleSheet(), containerWidget)
            self.setDefaultWidget(containerWidget)

        def insertVariable(self, variable: 'MenuTextEditVariables.VariableModel') -> None:
            """
            Insert a variable into the text edit at the cursor position.
            
            Args:
                variable: The variable model to insert.
            """
            textCursor = self.textEdit.textCursor()
            
            if textCursor.hasSelection():
                textCursor.insertText(f' {{{variable.variable}}} ')
            else:
                textBeforeCursor = textCursor.document().toPlainText()[:textCursor.position()]
                textAfterCursor = textCursor.document().toPlainText()[textCursor.position():]

                spacePrefix = ''
                spaceSuffix = ''
                if textBeforeCursor and textBeforeCursor[-1] not in (' ', '\n'):
                    spacePrefix = ' '
                if textAfterCursor and textAfterCursor[0] not in (' ', '\n'):
                    spaceSuffix = ' '
                textCursor.insertText(f'{spacePrefix}{{{variable.variable}}}{spaceSuffix}')
            
            self.textEdit.setTextCursor(textCursor)
            self.callableClose()
          
    def __init__(self, widget: QPushButton, textEdit: QTextEdit, variables: list[VariableModel], title: str = 'Variables') -> None:
        """
        Initialize the MenuTextEditVariables.
        
        Args:
            widget: The button widget that triggers the menu.
            textEdit: The text edit widget to insert variables into.
            variables: List of variable models to display in the menu.
            title: Title text for the menu. Defaults to 'Variables'.
        """
        super().__init__(widget)
        widget.clicked.connect(self.showBottomRight)
        self.customAction = self.CustomAction(self.close, textEdit, variables, title)
        self.addAction(self.customAction)
        Styles.setWidgetStyleTheme(Styles.menu(), self)

