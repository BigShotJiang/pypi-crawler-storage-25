
from PySide6.QtWidgets import QMenu, QWidgetAction, QApplication, QPushButton, QWidget, QLabel
from PySide6.QtCore import QCoreApplication, Qt, QPoint, QEvent
from PySide6.QtGui import QMouseEvent, QKeyEvent
from ...style.widgets import WidgetsTheme

class Menu(QMenu):
    """
    Extended QMenu with custom positioning and widget integration.
    
    This menu extends QMenu to provide various positioning methods,
    widget integration, and custom event handling for checkable actions.
    """

    def __init__(self, widget: QPushButton | QLabel | QWidget | None = None, parent: QWidget | None = None) -> None:
        """
        Initialize the Menu.
        
        Args:
            widget: Optional widget to associate with the menu (e.g., button that triggers it).
                  Defaults to None.
            parent: The parent widget for this menu. Defaults to None.
        """
        super().__init__(parent)
        self.widget: QPushButton | QLabel | QWidget | None = widget

        if isinstance(widget, QPushButton):
            widget.setCursor(Qt.CursorShape.PointingHandCursor)

        self.closeOnStateChange: bool = False
        self.isOpen: bool = False
        self._blockEvents: bool = False
        self.aboutToHide.connect(self.onMenuAboutToHide)
        self.aboutToShow.connect(self.onMenuAboutToShow)

    def keyPressEvent(self, keyEvent: QKeyEvent) -> None:
        """
        Handle key press events, accepting Alt key to prevent menu activation.
        
        Args:
            keyEvent: The key event containing information about the pressed key.
        """
        if keyEvent.key() == Qt.Key.Key_Alt:
            keyEvent.accept()  
        else:
            super().keyPressEvent(keyEvent)

    def onMenuAboutToShow(self) -> None:
        """
        Handle menu about to show event.
        
        Updates the open state and widget focus/icon state if events are not blocked.
        """
        if not self._blockEvents:
            self.isOpen = True
            if self.widget:
                if isinstance(self.widget, QPushButton):
                    WidgetsTheme.toggleIconActive(self.widget)
                self.widget.setFocus()
       
    def onMenuAboutToHide(self) -> None:
        """
        Handle menu about to hide event.
        
        Updates the open state and widget focus/icon state if events are not blocked.
        """
        if not self._blockEvents:
            self.isOpen = False
            if self.widget:
                if isinstance(self.widget, QPushButton):
                    WidgetsTheme.toggleIconActive(self.widget)
                self.widget.clearFocus()

    def _exec(self, position: QPoint, width: int, height: int) -> None:
        """
        _exec the menu at the specified position with given dimensions.
        
        Args:
            position: The global position where the menu should appear.
            width: The width of the menu in pixels.
            height: The height of the menu in pixels.
        """
        
        self._blockEvents = True
        self.setFixedSize(0, 0)
        self.move(QPoint(-1, -1))
        self.show()
        QCoreApplication.processEvents()
        self.close()
        self.setFixedSize(width, height)
        self._blockEvents = False
        self.exec(position)

    def event(self, event: QEvent | QMouseEvent) -> bool:
        """
        Handle events, specifically managing checkable action toggling.
        
        Args:
            event: The event to handle.
        
        Returns:
            True if the event was handled, False otherwise.
        """
        if event.type() == QEvent.Type.MouseButtonRelease:
            if not self.closeOnStateChange:
                globalPosition = event.globalPosition().toPoint()
                localPosition = self.mapFromGlobal(globalPosition)
                if self.geometry().contains(globalPosition):
                        clickedAction = self.actionAt(localPosition)
                        if clickedAction and clickedAction.isCheckable():
                            if clickedAction:
                                clickedAction.setChecked(not clickedAction.isChecked())
                            return False

        return super().event(event)
      
    def showNearWidget(self, targetWidget: QWidget, margin: int = 20) -> None:
        """
        Show the menu positioned and sized relative to the given target widget with a specified margin.

        Args:
            targetWidget: The widget relative to which the menu should be positioned and sized.
            margin: The margin to apply around the menu. Defaults to 20 pixels.
        """
        QCoreApplication.processEvents()
        # Get the geometry of the target widget
        widgetGeometry = targetWidget.geometry()
        widgetGlobalPos = targetWidget.mapToGlobal(widgetGeometry.topLeft())  # Convert to global coordinates
        widgetX = widgetGlobalPos.x()
        widgetY = widgetGlobalPos.y()
        widgetWidth = widgetGeometry.width()
        widgetHeight = widgetGeometry.height()

        # Calculate new size and position with margin
        menuWidth = max(0, widgetWidth - 2 * margin)
        menuHeight = max(0, widgetHeight - 2 * margin)
        positionX = widgetX + margin
        positionY = widgetY + margin

        menuActions = self.actions()
        if len(menuActions) == 1:
            singleAction = menuActions[0]
            if isinstance(singleAction, QWidgetAction):
                singleAction.defaultWidget().setFixedSize(menuWidth - 2, menuHeight - 2)

        # Show the menu
        self._exec(QPoint(positionX, positionY), menuWidth, menuHeight)

    def showFullscreen(self, percentageScreenAvailable: float = 0.95) -> None:
        """
        Show the menu in fullscreen mode, centered on the screen.
        
        Args:
            percentageScreenAvailable: Percentage of available screen to use (0.0 to 1.0).
                                     Defaults to 0.95.
        """
        QCoreApplication.processEvents()
        activeWindow = QCoreApplication.instance().activeWindow()
        if activeWindow:
            if percentageScreenAvailable > 1 or percentageScreenAvailable < 0:
                percentageScreenAvailable = 0.95
            screen = activeWindow.windowHandle().screen()
            availableGeometry = screen.availableGeometry()
            availableWidth = availableGeometry.width()
            availableHeight = availableGeometry.height()
            menuWidth = int(availableWidth * percentageScreenAvailable)
            menuHeight = int(availableHeight * percentageScreenAvailable)

            # Calculate the position to center the menu
            centerX = int((availableWidth - menuWidth) / 2 + availableGeometry.left())
            centerY = int((availableHeight - menuHeight) / 2 + availableGeometry.top())

            menuActions = self.actions()
            if len(menuActions) == 1:
                singleAction = menuActions[0]
                if isinstance(singleAction, QWidgetAction):
                     singleAction.defaultWidget().setFixedSize(menuWidth - 2, menuHeight - 2)

            self._exec(QPoint(centerX, centerY), menuWidth, menuHeight)
        else:
            print('Animation: Active window not found')

    def showLeft(self, widgetLeftEdge: QWidget | None = None, widgetForHeight: QWidget | None = None, additionalWidthRight: int = 0, marginLeft: int = 4, marginRight: int = 4) -> None:
        """
        Show the menu to the left of the widget.
        
        Args:
            widgetLeftEdge: Optional widget to use as the left edge reference.
                          Defaults to None.
            widgetForHeight: Optional widget to use for height calculation.
                           Defaults to None.
            additionalWidthRight: Additional width to add to the right. Defaults to 0.
            marginLeft: Left margin in pixels. Defaults to 4.
            marginRight: Right margin in pixels. Defaults to 4.
        """
        QCoreApplication.processEvents()
        if not self.widget:
            return self.show()
        
        # Set default width and height based on menu size
        menuHeight = self.sizeHint().height()
        menuWidth = self.sizeHint().width()
        widgetGeometry = self.widget.geometry()

        # Get the top-left point of the widget
        localPoint = self.widget.rect().topLeft()

        # Adjust width based on widgetLeftEdge
        if widgetLeftEdge:
            leftEdgePosition = widgetLeftEdge.geometry().left()
            # Update menu width according to widgetLeftEdge
            menuWidth = widgetGeometry.left() - leftEdgePosition + widgetGeometry.width()
            menuWidth = (menuWidth + additionalWidthRight) - marginLeft 
            menuWidth = menuWidth - self.widget.width()

        localPoint.setX(localPoint.x() - marginRight - menuWidth)  # Adjust to position menu to the left
        globalPoint = self.widget.mapToGlobal(localPoint)
            
        # Adjust height based on widgetForHeight
        if widgetForHeight:
            bottomEdgeHeight = widgetForHeight.geometry().height()
            # Update menu height based on widgetForHeight
            menuHeight = bottomEdgeHeight - widgetGeometry.top()

        # Adjust internal menu widgets if necessary
        for action in self.actions():
            if isinstance(action, self.CustomWidgetAction) or isinstance(action, QWidgetAction):
                action.defaultWidget().setFixedSize(menuWidth - 2, menuHeight - 2)

        globalPoint.setY(globalPoint.y())  # Adjust to display menu below

        self._exec(globalPoint, menuWidth, menuHeight)

    def showBottomLeft(self, widgetLeftEdge: QWidget | None = None, widgetForHeight: QWidget | None = None, additionalWidthRight: int = 0, marginLeft: int = 0, marginRight: int = 0, marginTop: int = 4, marginBottom: int = 4) -> None:
        """
        Show the menu at the bottom-left of the widget.
        
        Args:
            widgetLeftEdge: Optional widget to use as the left edge reference.
                          Defaults to None.
            widgetForHeight: Optional widget to use for height calculation.
                           Defaults to None.
            additionalWidthRight: Additional width to add to the right. Defaults to 0.
            marginLeft: Left margin in pixels. Defaults to 0.
            marginRight: Right margin in pixels. Defaults to 0.
            marginTop: Top margin in pixels. Defaults to 4.
            marginBottom: Bottom margin in pixels. Defaults to 4.
        """
        QCoreApplication.processEvents()
        if not self.widget:
            return self.show()
        # Set default width and height based on menu size
        menuHeight = self.sizeHint().height()
        menuWidth = self.sizeHint().width()
        widgetGeometry = self.widget.geometry()

        # Get the bottom-right point of the widget
        localPoint = self.widget.rect().bottomRight()

        # Adjust width based on widgetLeftEdge
        if widgetLeftEdge:
            leftEdgePosition = widgetLeftEdge.geometry().left()
            # Update menu width according to widgetLeftEdge
            menuWidth = widgetGeometry.left() - leftEdgePosition + widgetGeometry.width()
            menuWidth = (menuWidth + additionalWidthRight) - (marginLeft + marginRight)

        localPoint.setX(localPoint.x() - marginLeft - menuWidth)  # Adjust to position menu to the left
        globalPoint = self.widget.mapToGlobal(localPoint)
            
        # Adjust height based on widgetForHeight
        if widgetForHeight:
            bottomEdgeHeight = widgetForHeight.geometry().height()
            # Update menu height based on widgetForHeight
            menuHeight = bottomEdgeHeight - widgetGeometry.top()

        # Adjust internal menu widgets if necessary
        for action in self.actions():
            if isinstance(action, self.CustomWidgetAction) or isinstance(action, QWidgetAction):
                action.defaultWidget().setFixedSize(menuWidth - 2, menuHeight - 2)

        # Get screen height
        screenHeight = QApplication.primaryScreen().geometry().height()

        # Check if there is enough space below the widget for the menu
        if globalPoint.y() + menuHeight > screenHeight:
            # If not enough space, display menu above the widget
            localPoint = self.widget.rect().topLeft()
            globalPoint = self.widget.mapToGlobal(localPoint)
            globalPoint.setY(globalPoint.y() - menuHeight - marginTop)  # Adjust to display menu above
        else:
            globalPoint.setY(globalPoint.y() + marginBottom)  # Adjust to display menu below

        # Display the menu
        self._exec(globalPoint, menuWidth, menuHeight)

    def showMenuOverWidget(self, targetWidget: QWidget) -> None:
        """
        Show the menu positioned exactly over the target widget.
        
        Args:
            targetWidget: The widget to position the menu over.
        """
        QCoreApplication.processEvents()
        if not self.widget:
            return self.show()
        # Get the global position of the widget (relative to screen)
        widgetGlobalPosition = targetWidget.mapToGlobal(targetWidget.rect().topLeft())
        
        # Get widget size
        targetWidgetWidth = targetWidget.width()
        targetWidgetHeight = targetWidget.height()

        # Adjust internal menu widgets if necessary
        for action in self.actions():
            if isinstance(action, self.CustomWidgetAction) or isinstance(action, QWidgetAction):
                action.defaultWidget().setFixedSize(targetWidgetWidth - 2, targetWidgetHeight - 2)
        
        # Show menu at widget position
        self._exec(widgetGlobalPosition, targetWidgetWidth, targetWidgetHeight)


    def showBottomRight(self, widgetRightEdge: QWidget | None = None, widgetForHeight: QWidget | None = None, additionalWidthLeft: int = 0, marginLeft: int = 0, marginRight: int = 0, marginTop: int = 4, marginBottom: int = 4) -> None:
        """
        Show the menu at the bottom-right of the widget.
        
        Args:
            widgetRightEdge: Optional widget to use as the right edge reference.
                           Defaults to None.
            widgetForHeight: Optional widget to use for height calculation.
                           Defaults to None.
            additionalWidthLeft: Additional width to add to the left. Defaults to 0.
            marginLeft: Left margin in pixels. Defaults to 0.
            marginRight: Right margin in pixels. Defaults to 0.
            marginTop: Top margin in pixels. Defaults to 4.
            marginBottom: Bottom margin in pixels. Defaults to 4.
        """
        QCoreApplication.processEvents()
        if not self.widget:
            return self.show()
        # Get the bottom-left point of the widget
        localPoint = self.widget.rect().bottomLeft()
        localPoint.setX((localPoint.x() - additionalWidthLeft) + marginLeft)
        globalPoint = self.widget.mapToGlobal(localPoint)

        # Set default width and height based on menu size
        menuHeight = self.sizeHint().height()
        menuWidth = self.sizeHint().width()
        widgetGeometry = self.widget.geometry()

        # Adjust width based on widgetRightEdge
        if widgetRightEdge:
            rightEdgeWidth = widgetRightEdge.geometry().width()

            # Update menu width according to widgetRightEdge
            menuWidth = rightEdgeWidth - widgetGeometry.right() + widgetGeometry.width()
            menuWidth = (menuWidth + additionalWidthLeft) - (marginRight + marginLeft)

        # Adjust height based on widgetForHeight
        if widgetForHeight:
            bottomEdgeHeight = widgetForHeight.geometry().height()

            # Update menu height based on widgetForHeight
            menuHeight = bottomEdgeHeight - widgetGeometry.bottom()

        # Adjust internal menu widgets if necessary
        for action in self.actions():
            if isinstance(action, self.CustomWidgetAction) or isinstance(action, QWidgetAction):
                action.defaultWidget().setFixedSize(menuWidth - 2, menuHeight - 2)

        # Get screen height
        screenHeight = QApplication.primaryScreen().geometry().height()

        # Check if there is enough space below the widget for the menu
        if globalPoint.y() + menuHeight > screenHeight:
            # If not enough space, display menu above the widget
            localPoint = self.widget.rect().topLeft()
            localPoint.setX((localPoint.x() - additionalWidthLeft) + marginLeft)
            globalPoint = self.widget.mapToGlobal(localPoint)
            globalPoint.setY(globalPoint.y() - menuHeight - marginTop)  # Adjust to display menu above
        else:
            globalPoint.setY(globalPoint.y() + marginBottom)  # Adjust to display menu below

        self._exec(globalPoint, menuWidth, menuHeight)

    def showTopLeft(self, widgetLeftEdge: QWidget | None = None, widgetForHeight: QWidget | None = None, additionalWidthRight: int = 0, marginLeft: int = 0, marginRight: int = 0, marginTop: int = 4, marginBottom: int = 4) -> None:
        """
        Show the menu at the top-left of the widget.
        
        Args:
            widgetLeftEdge: Optional widget to use as the left edge reference.
                          Defaults to None.
            widgetForHeight: Optional widget to use for height calculation.
                           Defaults to None.
            additionalWidthRight: Additional width to add to the right. Defaults to 0.
            marginLeft: Left margin in pixels. Defaults to 0.
            marginRight: Right margin in pixels. Defaults to 0.
            marginTop: Top margin in pixels. Defaults to 4.
            marginBottom: Bottom margin in pixels. Defaults to 4.
        """
        QCoreApplication.processEvents()
        if not self.widget:
            return self.show()
        # Set default width and height based on menu size
        menuHeight = self.sizeHint().height()
        menuWidth = self.sizeHint().width()
        widgetGeometry = self.widget.geometry()

        # Get the bottom-right point of the widget
        localPoint = self.widget.rect().bottomRight()

        # Adjust width based on widgetLeftEdge
        if widgetLeftEdge:
            leftEdgePosition = widgetLeftEdge.geometry().left()
            # Update menu width according to widgetLeftEdge
            menuWidth = widgetGeometry.left() - leftEdgePosition + widgetGeometry.width()
            menuWidth = (menuWidth + additionalWidthRight) - (marginLeft + marginRight)

        localPoint.setX(localPoint.x() - marginLeft - menuWidth)  # Adjust to position menu to the left
        localPoint.setY(localPoint.y() - self.widget.height())
        globalPoint = self.widget.mapToGlobal(localPoint)
            
        # Adjust height based on widgetForHeight
        if widgetForHeight:
            bottomEdgeHeight = widgetForHeight.geometry().height()
            # Update menu height based on widgetForHeight
            menuHeight = bottomEdgeHeight - widgetGeometry.top()

        # Adjust internal menu widgets if necessary
        for action in self.actions():
            if isinstance(action, self.CustomWidgetAction) or isinstance(action, QWidgetAction):
                action.defaultWidget().setFixedSize(menuWidth - 2, menuHeight - 2)

        globalPoint.setY(globalPoint.y() - menuHeight - marginTop)  # Adjust to display menu above
       
        # Display the menu
        self._exec(globalPoint, menuWidth, menuHeight)

    def showTopRight(self, widgetRightEdge: QWidget | None = None, widgetForHeight: QWidget | None = None, additionalWidthLeft: int = 0, marginLeft: int = 0, marginRight: int = 0, marginTop: int = 4, marginBottom: int = 4) -> None:
        """
        Show the menu at the top-right of the widget.
        
        Args:
            widgetRightEdge: Optional widget to use as the right edge reference.
                           Defaults to None.
            widgetForHeight: Optional widget to use for height calculation.
                           Defaults to None.
            additionalWidthLeft: Additional width to add to the left. Defaults to 0.
            marginLeft: Left margin in pixels. Defaults to 0.
            marginRight: Right margin in pixels. Defaults to 0.
            marginTop: Top margin in pixels. Defaults to 4.
            marginBottom: Bottom margin in pixels. Defaults to 4.
        """
        QCoreApplication.processEvents()
        if not self.widget:
            return self.show()
        # Get the top-left point of the widget
        localPoint = self.widget.rect().topLeft()
        localPoint.setX((localPoint.x() - additionalWidthLeft) + marginLeft)
        globalPoint = self.widget.mapToGlobal(localPoint)

        # Set default width and height based on menu size
        menuHeight = self.sizeHint().height()
        menuWidth = self.sizeHint().width()
        widgetGeometry = self.widget.geometry()

        # Adjust width based on widgetRightEdge
        if widgetRightEdge:
            rightEdgeWidth = widgetRightEdge.geometry().width()

            # Update menu width according to widgetRightEdge
            menuWidth = rightEdgeWidth - widgetGeometry.right() + widgetGeometry.width() 
            menuWidth = (menuWidth + additionalWidthLeft) - (marginRight + marginLeft)

        # Adjust height based on widgetForHeight
        if widgetForHeight:
            bottomEdgeHeight = widgetForHeight.geometry().height()

            # Update menu height based on widgetForHeight
            menuHeight = bottomEdgeHeight - widgetGeometry.top()

        # Adjust internal menu widgets if necessary
        for action in self.actions():
            if isinstance(action, self.CustomWidgetAction) or isinstance(action, QWidgetAction):
                action.defaultWidget().setFixedSize(menuWidth - 2, menuHeight - 2)

        # Check if there is enough space above the widget for the menu
        if globalPoint.y() - menuHeight < 0:
            # If not enough space, display menu below the widget
            localPoint = self.widget.rect().bottomLeft()
            localPoint.setX((localPoint.x() - additionalWidthLeft) + marginLeft)
            globalPoint = self.widget.mapToGlobal(localPoint)
            globalPoint.setY(globalPoint.y() + marginBottom)  # Adjust to display menu below
        else:
            globalPoint.setY(globalPoint.y() - menuHeight - marginTop)  # Adjust to display menu above

        # Display the menu
        self._exec(globalPoint, menuWidth, menuHeight)

    class CustomWidgetAction(QWidgetAction):
        """
        Custom widget action for use in menus.
        """
        
        def __init__(self, parent: QWidget | None = None) -> None:
            """
            Initialize the CustomWidgetAction.
            
            Args:
                parent: The parent widget. Defaults to None.
            """
            super().__init__(parent)
         
        

