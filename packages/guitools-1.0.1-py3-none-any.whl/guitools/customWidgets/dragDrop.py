

from PySide6.QtWidgets import QWidget, QHBoxLayout, QVBoxLayout, QLabel, QFrame, QSizePolicy
from PySide6.QtCore import Qt, Signal, QMimeData, SignalInstance, QEvent
from PySide6.QtGui import QDrag, QPixmap, QDragEnterEvent, QDragMoveEvent, QDropEvent, QMouseEvent
from ..style import Styles
from typing import Type, TypeVar
T = TypeVar('T')
           
class DragDrop(QWidget):
    """
    A widget that supports drag and drop reordering of items.
    
    This widget allows items to be reordered by dragging them,
    emitting a swap signal when items are moved.
    """
        
    class DragItem(QFrame):
        """
        A draggable item within a DragDrop widget.
        
        Each DragItem contains a drag handle and a content widget,
        and can be dragged to reorder items in the parent DragDrop widget.
        """
        def __init__(self, swap: SignalInstance, index: int, contentWidget: QWidget) -> None:
            """
            Initialize the DragItem.
            
            Args:
                swap: Signal instance to emit when items are swapped.
                index: The initial index of this item.
                contentWidget: The widget to display as content.
            """
            super().__init__()
            self._widget: QWidget = contentWidget
            self.swap: SignalInstance = swap
            self.current: int = index
            self.setAcceptDrops(True)
            self.setContentsMargins(0, 0, 0, 0)

            # Layout for the DragItem
            itemLayout = QHBoxLayout(self)
            itemLayout.setContentsMargins(5, 0, 0, 0)
            itemLayout.setSpacing(5)

            # Drag handle label
            self.dragLabel = QLabel(self)
            self.dragLabel.setFixedSize(16, 16)
            self.dragLabel.setAlignment(Qt.AlignmentFlag.AlignCenter)
            Styles.setIcon(self.dragLabel, Styles.Resources.dragDrop.gray, Styles.Resources.dragDrop.select, 16)

            # Custom content passed to DragItem
            itemLayout.addWidget(self.dragLabel, alignment=Qt.AlignmentFlag.AlignVCenter)
            itemLayout.addWidget(contentWidget)
            self.setLayout(itemLayout)
            self.setSizePolicy(QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed))

        def widget(self, type: Type[T] = QWidget) -> T:
            """
            Get the content widget.
            
            Args:
                type: The expected widget type. Defaults to QWidget.
            
            Returns:
                The content widget.
            """
            return self._widget
            
        def dragEnterEvent(self, dragEnterEvent: QDragEnterEvent) -> None:
            """
            Handle drag enter events.
            
            Args:
                dragEnterEvent: The drag enter event.
            """
            if dragEnterEvent.mimeData().hasText():
                dragEnterEvent.acceptProposedAction()
            else:
                dragEnterEvent.ignore()

        def dragMoveEvent(self, dragMoveEvent: QDragMoveEvent) -> None:
            """
            Handle drag move events.
            
            Args:
                dragMoveEvent: The drag move event.
            """
            if dragMoveEvent.mimeData().hasText():
                dragMoveEvent.acceptProposedAction()
            else:
                dragMoveEvent.ignore()

        def dropEvent(self, dropEvent: QDropEvent) -> None:
            """
            Handle drop events, emitting swap signal.
            
            Args:
                dropEvent: The drop event.
            """
            sourcePosition = int(dropEvent.mimeData().text())
            currentPosition = self.current
            self.swap.emit(*sorted([sourcePosition, currentPosition]))

        def mouseMoveEvent(self, mouseEvent: QMouseEvent) -> None:
            """
            Handle mouse move events to initiate dragging.
            
            Args:
                mouseEvent: The mouse move event.
            """
            if self.dragLabel.geometry().contains(mouseEvent.pos()):
                drag = QDrag(self)
                mimeData = QMimeData()
                mimeData.setText(str(self.current))

                dragPixmap = QPixmap(self.size())
                self.render(dragPixmap)
                mimeData.setImageData(dragPixmap)
                drag.setMimeData(mimeData)
                drag.setPixmap(dragPixmap)
                drag.setHotSpot(mouseEvent.pos())  # Set the drag hot spot
                drag.exec(Qt.DropAction.MoveAction)

    swap = Signal(int, int)

    def __init__(self, *, parent: QWidget | None = None) -> None:
        """
        Initialize the DragDrop widget.
        
        Args:
            parent: The parent widget. Defaults to None.
        """
        super().__init__(parent)
        self.contents = QWidget()
        self.contents.setSizePolicy(QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed))
        self.setSizePolicy(QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed))
        self.contents.setContentsMargins(0, 0, 0, 0)
        self.vlayout = QVBoxLayout(self)
        self.vlayout.setContentsMargins(0, 0, 0, 0)
        self.vlayout.setSpacing(5)
        self.setAcceptDrops(True)
        self.swap.connect(self.swapWidgets)

    def addDragItem(self, contentWidget: QWidget) -> DragItem:
        """
        Add a new draggable item to the widget.
        
        Args:
            contentWidget: The widget to display as content.
        
        Returns:
            The created DragItem instance.
        """
        itemIndex = self.vlayout.count()
        dragItem = self.DragItem(self.swap, itemIndex, contentWidget)
        self.vlayout.addWidget(dragItem) 
        return dragItem
    
    def removeDragItem(self, dragItem: QWidget) -> None:
        """
        Remove a drag item from the widget and update remaining indices.
        
        Args:
            dragItem: The drag item widget to remove.
        """
        # Check if the item is present in the layout
        itemIndex = -1
        for i in range(self.vlayout.count()):
            if self.vlayout.itemAt(i).widget() == dragItem:
                itemIndex = i
                break

        if itemIndex == -1:
            return  # If the item is not in the layout, do nothing

        # Remove the widget from the layout
        itemWidget = self.vlayout.itemAt(itemIndex).widget()
        self.vlayout.removeWidget(itemWidget)
        itemWidget.deleteLater()  # Ensure the widget is deleted from memory

        # Update the indices of remaining widgets
        for i in range(itemIndex, self.vlayout.count()):
            remainingItem = self.vlayout.itemAt(i).widget()
            if isinstance(remainingItem, self.DragItem):
                remainingItem.current = i


    def swapWidgets(self, pos1: int, pos2: int) -> None:
        """
        Swap two widgets at the specified positions.
        
        Args:
            pos1: The first position index.
            pos2: The second position index.
        """
        widget1 = self.vlayout.itemAt(pos1).widget()
        widget2 = self.vlayout.itemAt(pos2).widget()
        widget1.current, widget2.current = widget2.current, widget1.current
        self.vlayout.removeWidget(widget1)
        self.vlayout.removeWidget(widget2)
        self.vlayout.insertWidget(pos1, widget2)
        self.vlayout.insertWidget(pos2, widget1)

    def dragEnterEvent(self, dragEnterEvent: QDragEnterEvent) -> None:
        """
        Handle drag enter events.
        
        Args:
            dragEnterEvent: The drag enter event.
        """
        if dragEnterEvent.mimeData().hasText():
            dragEnterEvent.acceptProposedAction()
        else:
            dragEnterEvent.ignore()

    def dragMoveEvent(self, dragMoveEvent: QDragMoveEvent) -> None:
        """
        Handle drag move events.
        
        Args:
            dragMoveEvent: The drag move event.
        """
        if dragMoveEvent.mimeData().hasText():
            dragMoveEvent.acceptProposedAction()
        else:
            dragMoveEvent.ignore()

    def dropEvent(self, dropEvent: QDropEvent) -> None:
        """
        Handle drop events.
        
        Args:
            dropEvent: The drop event.
        """
        dropEvent.acceptProposedAction()