

from PySide6.QtWidgets import QTextEdit, QWidget
from PySide6.QtCore import Signal, QMimeData, QEvent

class AutoResizingTextEdit(QTextEdit):
    """
    A QTextEdit that automatically adjusts its height based on content.
    
    This widget automatically resizes vertically to fit its content,
    with configurable minimum and maximum height constraints.
    """
    imagePasted = Signal(object)
    heightChanged = Signal(int)
    
    def __init__(self, minLines: int = 3, maxHeight: int | None = None) -> None:
        """
        Initialize the AutoResizingTextEdit.
        
        Args:
            minLines: Minimum number of lines to display. Defaults to 3.
            maxHeight: Maximum height in pixels. If None, no maximum is set. Defaults to None.
        """
        super().__init__()

        self.lineHeight: int = 21  # Height of a QLineEdit
        self.minHeight: int = self.lineHeight * minLines  # Adjustable minimum height
        self.maxHeight: int | None = maxHeight
        self.currentHeight: int = self.minHeight
        self.setMinimumHeight(self.minHeight)
        if maxHeight:
            self.setMaximumHeight(maxHeight)  # Set maximum height to prevent indefinite growth
            
        self.textChanged.connect(self.adjustHeight)  # Adjust height when text changes
        self.adjustHeight()  # Adjust initial height

    def insertFromMimeData(self, source: QMimeData) -> None:
        """
        Handle paste operations, emitting signals for images and URLs.
        
        Args:
            source: The MIME data to insert.
        """
        # URLs
        if source.hasUrls():
            for url in source.urls():
                localPath = url.toLocalFile()
                if localPath:
                    self.imagePasted.emit(localPath)
                else:
                    urlString = url.toString()
                    self.imagePasted.emit(urlString)
                       
        # Image
        elif source.hasImage():
            imageData = source.imageData()
            self.imagePasted.emit(imageData)
        else:
            super().insertFromMimeData(source)

    def showEvent(self, showEvent: QEvent) -> None:
        """
        Handle the show event, adjusting height when the widget becomes visible.
        
        Args:
            showEvent: The show event.
        """
        self.adjustHeight()
        return super().showEvent(showEvent)

    def adjustHeight(self) -> None:
        """
        Adjust the height of the QTextEdit based on content growth or reduction.
        
        If empty, maintains the defined minimum height. Only updates and emits
        the heightChanged signal if the height actually changes.
        """
        documentHeight = self.document().size().height() 
        calculatedHeight = max(self.minHeight, int(documentHeight))

        if self.maxHeight:
            calculatedHeight = min(self.maxHeight, calculatedHeight)

        if calculatedHeight != self.currentHeight:  # Only update and emit signal if changed
            parentWidget = self.parentWidget()
            if parentWidget:
                parentWidget.setUpdatesEnabled(False)

            self.setFixedHeight(calculatedHeight)
            self.currentHeight = calculatedHeight
            self.heightChanged.emit(calculatedHeight)  

            if parentWidget:
                parentWidget.setUpdatesEnabled(True)

