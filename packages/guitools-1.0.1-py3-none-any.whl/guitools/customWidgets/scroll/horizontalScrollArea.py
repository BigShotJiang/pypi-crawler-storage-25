

from PySide6.QtWidgets import QScrollArea, QHBoxLayout, QWidget, QFrame, QSizePolicy
from PySide6.QtCore import Qt

class HorizontalScrollArea(QScrollArea):
    """
    A custom QScrollArea that provides horizontal scrolling functionality.
    
    This widget creates a scrollable area with a horizontal layout, allowing
    widgets to be added and scrolled horizontally. Vertical scrolling is disabled.
    """
    
    def __init__(self, *, margins: list[int] = [0, 0, 0, 0], contentMargins: list[int] = [10, 10, 10, 10],
            spacing: int = 0, contentSpacing: int = 20, parent: QWidget | None = None) -> None:
        """
        Initialize the HorizontalScrollArea.
        
        Args:
            margins: Margins for the main content widget layout (left, top, right, bottom).
                    Defaults to [0, 0, 0, 0].
            contentMargins: Margins for the scroll layout (left, top, right, bottom).
                           Defaults to [10, 10, 10, 10].
            spacing: Spacing between widgets in the main content widget layout. Defaults to 0.
            contentSpacing: Spacing between widgets in the scroll layout. Defaults to 20.
            parent: The parent widget. Defaults to None.
        """
        super().__init__(parent)

        # Main content widget
        contentWidget = QWidget()
        contentWidgetLayout = QHBoxLayout(contentWidget)
        contentWidgetLayout.setContentsMargins(*margins)
        contentWidgetLayout.setSpacing(spacing)

        self.setWidget(contentWidget)
        self.setWidgetResizable(True)

        # Scroll layout for adding items (horizontal)
        self.scrollLayout = QHBoxLayout()
        self.scrollLayout.setContentsMargins(*contentMargins)
        self.scrollLayout.setSpacing(contentSpacing)
        self.scrollLayout.setAlignment(Qt.AlignmentFlag.AlignLeft)

        # Content frame that holds the layout
        contentFrame = QFrame()
        contentFrame.setLayout(self.scrollLayout)

        # Add the content frame to the main content widget
        contentWidgetLayout.addWidget(contentFrame)

        # Set minimum width for content frame to prevent extra scroll space
        contentFrame.setSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        # Enable horizontal scroll only
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

    def addItem(self, widget: QWidget) -> None:
        """
        Add a new widget to the horizontal scroll area layout.
        
        Args:
            widget: The widget to add to the scroll area.
        """
        widget.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Expanding)
        self.scrollLayout.addWidget(widget)

