

from PySide6.QtWidgets import QTreeWidgetItem, QWidget, QVBoxLayout, QPushButton, QTreeWidget, QAbstractItemView
from PySide6.QtCore import QSize, QCoreApplication, Qt, QEvent, QTimer, SignalInstance, Signal, QObject
from ..style import Styles
from .menu.menu import Menu
from pydantic import BaseModel

class Data(BaseModel):
    """
    Data model for allowed selectable items in a tree widget.
    """
    column : int 
    role : int 
    values : list[object]

class WidgetVisibilityWatcher(QObject):
    """
    Watches a widget for visibility changes and emits a signal when first shown.
    """

    def __init__(self, widget: QWidget, signalUpdate: SignalInstance) -> None:
        """
        Initialize the WidgetVisibilityWatcher.
        
        Args:
            widget: The widget to watch.
            signalUpdate: Signal to emit when widget becomes visible.
        """
        super().__init__(widget)
        self.widget: QWidget = widget
        self.signalUpdate: SignalInstance = signalUpdate
        self.load: bool = False
        self.widget.installEventFilter(self) 

    def eventFilter(self, obj: QObject, event: QEvent) -> bool:
        """
        Filter events to detect when the widget is first shown.
        
        Args:
            obj: The object being watched.
            event: The event.
        
        Returns:
            True if the event was handled, False otherwise.
        """
        if obj == self.widget and event.type() == QEvent.Type.Show and not self.load:
            self.load = True
            self.signalUpdate.emit()  
        return super().eventFilter(obj, event)

class TreeWidget(QTreeWidget):
     """
     An enhanced QTreeWidget with custom selection, scrolling, and widget management.
     
     Supports locked selection, allowed selectable items, custom scroll amounts,
     and automatic widget size updates.
     """
     signalUpdate = Signal()
     def __init__(self, *, scrollAmount: int | None = None, parent: QWidget | None = None) -> None:
          """
          Initialize the TreeWidget.
          
          Args:
              scrollAmount: Custom scroll amount for wheel events. If None, uses default. Defaults to None.
              parent: The parent widget. Defaults to None.
          """
          super().__init__(parent)
          self._selectionLocked: bool = False
          self.allowedSelectableData: list[Data] = []
          self.scrollAmount: int | None = scrollAmount
          self.itemRuleWithWidget: int = 1212
          if scrollAmount:
               self.setAutoScroll(False)
               self.setHorizontalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
               self.setVerticalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
          self.signalUpdate.connect(self.countSignals)

          self.signalCount: int = 0
          self.signalTimer = QTimer()
          self.signalTimer.setSingleShot(True)
          self.signalTimer.timeout.connect(self.processSignalBatch)

     def countSignals(self) -> None:
          """
          Count signals and start batch processing timer if not already active.
          """
          self.signalCount += 1

          if not self.signalTimer.isActive():
               self.signalTimer.start(100)  

     def processSignalBatch(self) -> None:
          """
          Process a batch of signals and update tree widgets.
          """
          self.signalCount = 0
          self.updateTreeWidgets()

     def setItemWidget(self, item: QTreeWidgetItem, column: int, widget: QWidget) -> None:
          WidgetVisibilityWatcher(widget, self.signalUpdate)
          return super().setItemWidget(item, column, widget)

     def clear(self) -> None:
          self.allowedSelectableData.clear()
          for i in reversed(range(self.topLevelItemCount())):
               item = self.topLevelItem(i)
               self.removeTopLevelItem(item)

     def wheelEvent(self, wheelEvent) -> None:
          """
          Control scroll behavior when using the mouse wheel.
          
          Args:
              wheelEvent: The wheel event.
          """
          if self.scrollAmount:
               if wheelEvent.angleDelta().y() > 0:
                    self.verticalScrollBar().setValue(self.verticalScrollBar().value() - self.scrollAmount)  # Scroll up faster
               else:
                    self.verticalScrollBar().setValue(self.verticalScrollBar().value() + self.scrollAmount)  # Scroll down faster
               wheelEvent.accept()
          else:
               super().wheelEvent(wheelEvent)

     def setSelectionLocked(self, locked: bool) -> None:
          """
          Set whether selection is locked.
          
          Args:
              locked: Whether to lock selection.
          """
          self._selectionLocked = locked

     def setAllowedSelectableData(self, column: int, role: int, value: object) -> None:
          """
          Add allowed selectable data for a specific column and role.
          
          Args:
              column: The column index.
              role: The data role.
              value: The allowed value.
          """
          for data in self.allowedSelectableData:
               if data.column == column and data.role == role:
                    if value not in data.values:
                         data.values.append(value)
                    return
          self.allowedSelectableData.append(Data(column=column, role=role, values=[value]))

     def isAllowedItem(self, item: QTreeWidgetItem) -> bool:
          """
          Check if an item is allowed to be selected.
          
          Args:
              item: The item to check.
          
          Returns:
              True if the item is allowed, False otherwise.
          """
          for data in self.allowedSelectableData:
               itemValue = item.data(data.column, data.role)
               if itemValue in data.values:
                    return True
          return False

     def mousePressEvent(self, mouseEvent) -> None:
          """
          Handle mouse press events with selection locking.
          
          Args:
              mouseEvent: The mouse press event.
          """
          if self._selectionLocked:
               item = self.itemAt(mouseEvent.pos())
               if item is not None and (item.flags() & Qt.ItemFlag.ItemIsSelectable) and not self.isAllowedItem(item):
                    mouseEvent.ignore()
                    return
          super().mousePressEvent(mouseEvent)

     def mouseMoveEvent(self, mouseEvent) -> None:
          """
          Handle mouse move events with selection locking.
          
          Args:
              mouseEvent: The mouse move event.
          """
          if self._selectionLocked:
               mouseEvent.ignore()
               return
          super().mouseMoveEvent(mouseEvent)

     def keyPressEvent(self, keyEvent) -> None:
          """
          Handle key press events with selection locking.
          
          Args:
              keyEvent: The key press event.
          """
          if self._selectionLocked and keyEvent.key() in (Qt.Key.Key_Up, Qt.Key.Key_Down, Qt.Key.Key_Left, Qt.Key.Key_Right):
               keyEvent.ignore()
               return
          super().keyPressEvent(keyEvent)

     def getExpandedItems(self) -> list[QTreeWidgetItem]:
          """
          Get all expanded items in the QTreeWidget.
          
          Returns:
              A list of all expanded items.
          """
          expandedItems: list[QTreeWidgetItem] = []

          def findExpandedItems(item: QTreeWidgetItem) -> None:
               if item.isExpanded():
                    expandedItems.append(item)
               for i in range(item.childCount()):
                    findExpandedItems(item.child(i))

          for i in range(self.topLevelItemCount()):
               findExpandedItems(self.topLevelItem(i))

          return expandedItems
    
     def updateTreeWidgets(self) -> None:
          """
          Update all tree widgets and resize columns.
          """
          allItems = self.getAllItems(self)
          for item in allItems:
               self.updateTreeWidget(item)

          for columnIndex in range(self.columnCount()):
               self.resizeColumnToContents(columnIndex)
          self.viewport().update() 

     def updateTreeWidget(self, item: QTreeWidgetItem) -> None:
          """
          Update the size of widgets in a tree item.
          
          Args:
              item: The tree item to update.
          """
          if item.data(0, self.itemRuleWithWidget):
               return
          
          wasUpdated = False
          for columnIndex in range(self.columnCount()):
               itemWidget: QWidget = self.itemWidget(item, columnIndex)
               if itemWidget is not None:
                    if not itemWidget.isVisible():
                         break
                    wasUpdated = True
                    itemWidget.adjustSize()  
                    itemWidget.updateGeometry() 
                    widgetHeight = itemWidget.height()
                    itemSizeHint = item.sizeHint(columnIndex)
                    if itemSizeHint.height() != widgetHeight:
                         item.setSizeHint(columnIndex, QSize(itemSizeHint.width(), widgetHeight))
          if wasUpdated:
               item.setData(0, self.itemRuleWithWidget, True)

     def clearSelection(self):
          """
          Clear the selection safely with updates disabled.
          """
          try:
               self.setUpdatesEnabled(False)
               self.blockSignals(True)
               super().clearSelection()
               self.blockSignals(False)
               self.setUpdatesEnabled(True)
               QCoreApplication.processEvents()
          except Exception:
            pass

     def getTopLevelItems(self) -> list[QTreeWidgetItem]:
        """
        Get all top-level items.
        
        Returns:
            A list of all top-level items.
        """
        topItems = [self.topLevelItem(i) for i in range(self.topLevelItemCount())]
        return topItems
     
     def removeTopLevelItem(self, item: QTreeWidgetItem) -> None:
          """
          Remove a top-level item and its children correctly.
          
          Args:
              item: The top-level item to remove.
          """
          if item:
               for i in reversed(range(item.childCount())):
                    childItem = item.child(i)
                    childWidget = self.itemWidget(childItem, 0)
                    if childWidget:
                         childWidget.deleteLater()
                    item.removeChild(childItem)
                    del childItem
               itemIndex = self.indexOfTopLevelItem(item)
               self.takeTopLevelItem(itemIndex)
               del item

     @staticmethod
     def toggleExpand(item: QTreeWidgetItem, column: int, *, fixedColumn: int | None = None, role: int = 1000) -> None:
          expand: bool = item.data(column if fixedColumn == None else fixedColumn, role)
          if expand:
               item.setExpanded(not item.isExpanded())

     @staticmethod
     def allToggleExpand(item: QTreeWidgetItem) -> None:
          item.setExpanded(not item.isExpanded())

     @staticmethod
     def getAllChildren(item: QTreeWidgetItem) -> list[QTreeWidgetItem]:
        """
        Return a list of all child items of 'item', including all descendants.

        Args:
            item: The initial QTreeWidgetItem.
        
        Returns:
            List of QTreeWidgetItem.
        """
        children: list[QTreeWidgetItem] = []
        itemStack = [item]

        while itemStack:
               currentItem = itemStack.pop()
               childCount = currentItem.childCount()
               for i in range(childCount):
                    childItem = currentItem.child(i)
                    children.append(childItem)
                    itemStack.append(childItem)
        return children
     
     @staticmethod
     def getTexts(items: list[QTreeWidgetItem], column: int) -> list[str]:
          texts = [item.text(column) for item in items]
          return texts

     @classmethod
     def getAllItems(cls, tree: QTreeWidget, topLevel: bool = True) -> list[QTreeWidgetItem]:
          items = []
          for i in range(tree.topLevelItemCount()):
               item = tree.topLevelItem(i)
               if topLevel:
                    items.append(item)
               items.extend(cls.getAllChildren(item)) 
          return items
     
     @classmethod
     def getAllData(cls, tree: QTreeWidget, column: int = 0, role: int = 0, topLevel: bool = True) -> list[object]:
          items = cls.getAllItems(tree, topLevel)
          data = [item.data(column, role) for item in items]
          return [d for d in data if d is not None]
        
     @classmethod
     def findItemByData(cls, tree: QTreeWidget, dataValue: object, column: int = 0, role: int = 0, topLevel: bool = True) -> QTreeWidgetItem | None:
          for i in range(tree.topLevelItemCount()):
               item = tree.topLevelItem(i)
               if topLevel and item.data(column, role) == dataValue:
                    return item
               items = cls.getAllChildren(item)
               for subItem in items:
                    if subItem.data(column, role) == dataValue:
                         return subItem
          return None
     
     def findTopLevelItemByText(self, text: str) -> QTreeWidgetItem | None:
          for index in range(self.topLevelItemCount()):
               item = self.topLevelItem(index)
               if item.text(0) == text:
                    return item
          return None
     
     @staticmethod
     def setItemNotSelectable(item: QTreeWidgetItem) -> None:
          item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsSelectable)

     @staticmethod
     def setItemSpanned(item: QTreeWidgetItem, alignCenter: bool = True) -> None:
          item.setFirstColumnSpanned(True)  
          if alignCenter:
               item.setTextAlignment(0, Qt.AlignmentFlag.AlignCenter)

     @classmethod
     def disableItems(cls, treeWidget: QTreeWidget) -> None:
          """
          Disable all items and their widgets in a tree widget.
          
          Args:
              treeWidget: The tree widget.
          """
          for i in range(treeWidget.topLevelItemCount()):
               topItem = treeWidget.topLevelItem(i)
               cls.disableItemAndWidgets(treeWidget, topItem)
               for j in range(topItem.childCount()):
                    childItem = topItem.child(j)
                    cls.disableItemAndWidgets(treeWidget, childItem)
                    
     @classmethod
     def enableItems(cls, treeWidget: QTreeWidget) -> None:
          """
          Enable all items and their widgets in a tree widget.
          
          Args:
              treeWidget: The tree widget.
          """
          for i in range(treeWidget.topLevelItemCount()):
               topItem = treeWidget.topLevelItem(i)
               cls.enableItemAndWidgets(treeWidget, topItem)
               for j in range(topItem.childCount()):
                    childItem = topItem.child(j)
                    cls.enableItemAndWidgets(treeWidget, childItem)

     @classmethod
     def disableItemAndWidgets(cls, treeWidget: QTreeWidget, item: QTreeWidgetItem) -> None:
          """
          Disable an item and its widgets.
          
          Args:
              treeWidget: The tree widget.
              item: The item to disable.
          """
          item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEnabled)
          for columnIndex in range(treeWidget.columnCount()):
               itemWidget = treeWidget.itemWidget(item, columnIndex)
               if itemWidget:
                    itemWidget.setDisabled(True)

     @classmethod
     def enableItemAndWidgets(cls, treeWidget: QTreeWidget, item: QTreeWidgetItem) -> None:
          """
          Enable an item and its widgets.
          
          Args:
              treeWidget: The tree widget.
              item: The item to enable.
          """
          item.setFlags(item.flags() | Qt.ItemFlag.ItemIsEnabled)
          for columnIndex in range(treeWidget.columnCount()):
               itemWidget = treeWidget.itemWidget(item, columnIndex)
               if itemWidget:
                    itemWidget.setDisabled(False)

     @staticmethod
     def disableTreeItem(treeWidget: QTreeWidget, item: QTreeWidgetItem) -> None:
          """
          Disable a tree item and its widgets.
          
          Args:
              treeWidget: The tree widget.
              item: The item to disable.
          """
          item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEnabled)
          for columnIndex in range(treeWidget.columnCount()):
               itemWidget = treeWidget.itemWidget(item, columnIndex)
               if itemWidget:
                    itemWidget.setDisabled(True)

     @staticmethod
     def enableTreeItem(treeWidget: QTreeWidget, item: QTreeWidgetItem) -> None:
          """
          Enable a tree item and its widgets.
          
          Args:
              treeWidget: The tree widget.
              item: The item to enable.
          """
          item.setFlags(item.flags() | Qt.ItemFlag.ItemIsEnabled)
          for columnIndex in range(treeWidget.columnCount()):
               itemWidget = treeWidget.itemWidget(item, columnIndex)
               if itemWidget:
                    itemWidget.setDisabled(False)

     @staticmethod
     def selectItem(treeWidget: QTreeWidget, item: QTreeWidgetItem, scrollToItem: bool = True) -> None:
          """
          Select an item and optionally scroll to it.
          
          Args:
              treeWidget: The tree widget.
              item: The item to select.
              scrollToItem: Whether to scroll to the item. Defaults to True.
          """
          if scrollToItem:
               parentItem = item.parent()
               while parentItem:
                    parentItem.setExpanded(True)
                    parentItem = parentItem.parent()
          
          item.setSelected(True)
          if scrollToItem:
               treeWidget.scrollToItem(item)

     def filterItems(self, searchText: str) -> None:
          """
          Filter items based on search text.
          
          Args:
              searchText: The text to search for.
          """
          normalizedSearchText = searchText.lower().strip()

          topLevelItems = TreeWidget.getTopLevelItems(self)

          def filterRecursive(item: QTreeWidgetItem, searchText: str) -> bool:
               hasMatch = searchText in item.text(0).lower()

               matchingChildren = []
               for i in range(item.childCount()):
                    childItem = item.child(i)
                    if filterRecursive(childItem, searchText):
                         matchingChildren.append(childItem)

               # If the item has a widget → ignore direct filter
               hasWidget = self.itemWidget(item, 0) is not None

               if not hasWidget:
                    if hasMatch and not matchingChildren:
                         # Special case: match only by item text
                         item.setHidden(False)
                         # Make all children visible
                         for i in range(item.childCount()):
                              childItem = item.child(i)
                              if self.itemWidget(childItem, 0) is None:  # Only change if it doesn't have a widget
                                   childItem.setHidden(False)
                    else:
                         # Normal: visible if it or any child matches
                         item.setHidden(not (hasMatch or bool(matchingChildren)))

               return hasMatch or bool(matchingChildren)

          for topItem in topLevelItems:
               filterRecursive(topItem, normalizedSearchText)

     class WidgetOptions(QWidget):
          """
          A widget that displays a menu button for tree items.
          
          The button is shown when the item is selected or when the mouse enters the widget.
          """

          def __init__(self, treeItem: QTreeWidgetItem, parent: QWidget | None = None) -> None:
               """
               Initialize the WidgetOptions.
               
               Args:
                   treeItem: The tree item this widget is associated with.
                   parent: The parent widget. Defaults to None.
               """
               super().__init__(parent)
               self.treeItem: QTreeWidgetItem = treeItem
               self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
               self._menu: Menu | None = None
               containerLayout = QVBoxLayout(self)
               containerLayout.setContentsMargins(0,0,0,0)
               self.button = QPushButton()
               self.button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
               self.button.setIconSize(QSize(14, 14))
               self.button.setCursor(Qt.CursorShape.PointingHandCursor)
               Styles.setIcon(self.button, Styles.Resources.threePoint.gray, Styles.Resources.threePoint.theme)
               self.button.setVisible(False)  # Initially hidden
               containerLayout.addWidget(self.button)
               self.setLayout(containerLayout)

               # Connect selection change to update button visibility
               parentTreeWidget = self.treeItem.treeWidget()
               if parentTreeWidget:
                    parentTreeWidget.itemSelectionChanged.connect(self.updateButtonVisibility)

          def setMenu(self, menu: Menu) -> None:
               """
               Set the menu to display when the button is clicked.
               
               Args:
                   menu: The menu to set.
               """
               if not self._menu:
                    self._menu = menu
                    self._menu.aboutToHide.connect(self.onMenuAboutToHide)
               else:
                    self._menu = menu
                    self._menu.aboutToHide.disconnect(self.onMenuAboutToHide)
                    self._menu.aboutToHide.connect(self.onMenuAboutToHide)

          def onMenuAboutToHide(self) -> None:
               """
               Handle menu about to hide event.
               """
               parentTreeWidget = self.treeItem.treeWidget()
               if parentTreeWidget and self.treeItem not in parentTreeWidget.selectedItems():
                    self.button.setVisible(False)

          def updateButtonVisibility(self) -> None:
               """
               Update button visibility based on item selection.
               """
               parentTreeWidget = self.treeItem.treeWidget()
               if parentTreeWidget:
                    isSelected = self.treeItem in parentTreeWidget.selectedItems()
                    self.button.setVisible(isSelected)
                    
          def enterEvent(self, enterEvent) -> None:
               """
               Handle mouse enter event.
               
               Args:
                   enterEvent: The enter event.
               """
               self.button.setVisible(True)
               super().enterEvent(enterEvent)

          def leaveEvent(self, leaveEvent) -> None:
               """
               Handle mouse leave event.
               
               Args:
                   leaveEvent: The leave event.
               """
               parentTreeWidget = self.treeItem.treeWidget()
               if parentTreeWidget and self.treeItem not in parentTreeWidget.selectedItems():
                    if self._menu:
                         if self._menu.isOpen:
                              self.button.setVisible(False)
                    else:
                         self.button.setVisible(False)
               super().leaveEvent(leaveEvent)

