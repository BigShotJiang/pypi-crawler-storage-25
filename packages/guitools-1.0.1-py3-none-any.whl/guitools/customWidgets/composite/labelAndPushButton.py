

from typing import Callable
from PySide6.QtWidgets import QHBoxLayout, QLabel, QPushButton, QSizePolicy, QWidget
from ...style import Styles

class LabelAndPushButton(QWidget):
    """
    Composite widget combining a label and a push button.
    
    This widget displays a text label and a push button in a horizontal layout.
    The push button can optionally have an icon.
    """
    
    def __init__(self, labelText: str, pushButtonFunc: Callable[[], None], iconData: Styles.Resources.Data | None = None, parent: QWidget | None = None) -> None:
        """
        Initialize the LabelAndPushButton widget.
        
        Args:
            labelText: The text to display in the label.
            pushButtonFunc: Callback function to execute when the push button is clicked.
            iconData: Optional icon data for the push button. Defaults to None.
            parent: The parent widget for this widget. Defaults to None.
        """
        super().__init__(parent)

        self.label = QLabel()
        self.label.setText(labelText)
        self.label.setSizePolicy(QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred))
        self.pushButton = QPushButton()
        self.pushButton.clicked.connect(pushButtonFunc)

        if iconData:
            Styles.setIcon(self.pushButton, iconData.callableIcon, iconData.hoverCallableIcon, iconData.pixmapSize)
        self.pushButton.setSizePolicy(QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Preferred))
        containerLayout = QHBoxLayout()
        containerLayout.addWidget(self.label)
        containerLayout.addWidget(self.pushButton)
        containerLayout.setContentsMargins(0, 0, 0, 0)
        self.setLayout(containerLayout)

