

from PySide6.QtWidgets import QHBoxLayout, QLabel, QCheckBox, QSizePolicy, QWidget
from PySide6.QtGui import QIcon

class IconCheckBox(QWidget):
    """
    Composite widget combining an icon and a checkbox.
    
    This widget displays an optional icon and a checkbox with text in a
    horizontal layout. The icon can be updated dynamically.
    """
    
    def __init__(self, text: str, icon: QIcon | None = None, iconSize: int = 16, margins: list[int] = [0, 0, 0, 0], spacing: int | None = None, parent: QWidget | None = None) -> None:
        """
        Initialize the IconCheckBox widget.
        
        Args:
            text: The text to display next to the checkbox.
            icon: Optional QIcon to display. Defaults to None.
            iconSize: Size of the icon in pixels. Defaults to 16.
            margins: List of margins [left, top, right, bottom] for the layout.
                    Defaults to [0, 0, 0, 0].
            spacing: Optional spacing between widgets. If None, uses default spacing.
                    Defaults to None.
            parent: The parent widget for this widget. Defaults to None.
        """
        super().__init__(parent)
    
        self.margins: list[int] = margins
        containerLayout = QHBoxLayout()

        self.icon_label = QLabel()
        self.checkbox = QCheckBox(text)
        iconSizePolicy = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Preferred)
        self.icon_label.setSizePolicy(iconSizePolicy)
        if icon:
            iconPixmap = icon.pixmap(iconSize, iconSize)
            self.icon_label.setPixmap(iconPixmap)
            containerLayout.addWidget(self.icon_label)

        if spacing is not None:
            containerLayout.setSpacing(0)
        containerLayout.setContentsMargins(*margins)
        containerLayout.addWidget(self.checkbox)
    
        self.setStyleSheet('''
                    background-color: 'transparent';
        ''')

        self.setLayout(containerLayout)

    def setIcon(self, icon: QIcon, iconSize: int = 16) -> None:
        """
        Update the icon displayed in the widget.
        
        Args:
            icon: The QIcon to display.
            iconSize: Size of the icon in pixels. Defaults to 16.
        """
        iconPixmap = icon.pixmap(iconSize, iconSize)  
        self.icon_label.setPixmap(iconPixmap)
        updatedLayout = QHBoxLayout()
        updatedLayout.setContentsMargins(*self.margins)
        updatedLayout.addWidget(self.icon_label)
        updatedLayout.addWidget(self.checkbox)
        self.setLayout(updatedLayout)

