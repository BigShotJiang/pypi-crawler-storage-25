

from typing import Callable
from PySide6.QtWidgets import QHBoxLayout, QLabel, QPushButton, QSizePolicy, QWidget
from ...style import Styles

class IconLabelPushButton(QWidget):
    """
    Composite widget combining an icon label, text label, and push button.
    
    This widget displays an optional icon, a text label, and a push button
    in a horizontal layout. The icon can change based on selection state.
    """
    
    def __init__(self, text: str, pushButtonFunc: Callable[[], None], pushButtonIconData: Styles.Resources.Data | None = None, labelIconData: Styles.Resources.Data | None = None, iconSize: int = 16, margins: tuple[int, int, int, int] = (0, 0, 0, 0), parent: QWidget | None = None) -> None:
        """
        Initialize the IconLabelPushButton widget.
        
        Args:
            text: The text to display in the label.
            pushButtonFunc: Callback function to execute when the push button is clicked.
            pushButtonIconData: Optional icon data for the push button.
                              Defaults to None.
            labelIconData: Optional icon data for the label icon.
                          Defaults to None.
            iconSize: Size of the icons in pixels. Defaults to 16.
            margins: Tuple of margins (left, top, right, bottom) for the layout.
                    Defaults to (0, 0, 0, 0).
            parent: The parent widget for this widget. Defaults to None.
        """
        super().__init__(parent)
        self.selected: bool = False
        containerLayout = QHBoxLayout()
        containerLayout.setContentsMargins(*margins)
        self.icon_label = QLabel()
        self.label_text = QLabel()
        self.label_text.setText(text)
        self.label_text.setSizePolicy(QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding))
        self.icon_label.setSizePolicy(QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Expanding))
        self.pushButton = QPushButton()
        self.pushButton.setMinimumWidth(40)
        self.pushButton.setSizePolicy(QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Expanding))
        self.pushButton.clicked.connect(pushButtonFunc)
        self.labelIconData: Styles.Resources.Data | None = labelIconData
        self.iconSize: int = iconSize

        if labelIconData:
            Styles.setIcon(self.icon_label, labelIconData.callableIcon, labelIconData.callableIcon, iconSize)
            containerLayout.addWidget(self.icon_label)
    
        if pushButtonIconData:
            Styles.setIcon(self.pushButton, pushButtonIconData.callableIcon, pushButtonIconData.hoverCallableIcon, pushButtonIconData.pixmapSize)

        buttonStyle = Styles.button(transparent=True)
        buttonStyle.button.border.radius = 2
        Styles.setWidgetStyleTheme(buttonStyle, self.pushButton)


        containerLayout.addWidget(self.label_text)
        containerLayout.addWidget(self.pushButton)

        self.setStyleSheet('''
                    background-color: 'transparent';
        ''')

        self.setLayout(containerLayout)

    def selectionChanged(self, selected: bool) -> None:
        """
        Update the icon based on selection state.
        
        Args:
            selected: True if the widget is selected, False otherwise.
        """
        if self.labelIconData:
            if selected != self.selected:
                self.icon_label.setPixmap(self.labelIconData.hoverCallableIcon().toPixmap() if selected else self.labelIconData.callableIcon.toPixmap())
        self.selected = selected

