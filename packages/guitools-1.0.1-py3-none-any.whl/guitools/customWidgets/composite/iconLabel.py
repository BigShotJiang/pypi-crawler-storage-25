

from PySide6.QtWidgets import QHBoxLayout, QLabel, QSizePolicy, QWidget
from PySide6.QtGui import QIcon
from ...style import Styles

class IconLabel(QWidget):
    """
    Composite widget combining an icon and a text label.
    
    This widget displays an optional icon and a text label in a horizontal layout.
    The icon can be provided as a QIcon or Styles.Resources.Data, and can change
    based on selection state.
    """
    
    def __init__(self, text: str, icon: QIcon | None = None, iconData: Styles.Resources.Data | None = None, iconSize: int = 16, margins: tuple[int, int, int, int] = (0, 0, 0, 0), parent: QWidget | None = None) -> None:
        """
        Initialize the IconLabel widget.
        
        Args:
            text: The text to display in the label.
            icon: Optional QIcon to display. Defaults to None.
            iconData: Optional icon data from Styles.Resources.Data.
                     Defaults to None.
            iconSize: Size of the icon in pixels. Defaults to 16.
            margins: Tuple of margins (left, top, right, bottom) for the layout.
                    Defaults to (0, 0, 0, 0).
            parent: The parent widget for this widget. Defaults to None.
        """
        super().__init__(parent)
        self.selected: bool = False
        self.icon: QIcon | None = icon
        self.iconData: Styles.Resources.Data | None = iconData
        self.iconSize: int = iconSize
        containerLayout = QHBoxLayout()
        containerLayout.setContentsMargins(*margins)
        self.icon_label = QLabel()
        self.label_text = QLabel()
        self.label_text.setText(text)
        iconSizePolicy = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Preferred)
        self.icon_label.setSizePolicy(iconSizePolicy)

        if iconData:
            Styles.setIcon(self.icon_label, iconData.callableIcon, iconData.hoverCallableIcon, iconSize)
        elif icon:
            self.updateIcon(icon, iconSize)

        containerLayout.addWidget(self.icon_label)
        containerLayout.addWidget(self.label_text)
        self.setStyleSheet('''
                    background-color: 'transparent';
        ''')

        self.setLayout(containerLayout)

    def updateIcon(self, icon: QIcon, iconSize: int = 16) -> None:
        """
        Update the icon displayed in the label.
        
        Args:
            icon: The QIcon to display.
            iconSize: Size of the icon in pixels. Defaults to 16.
        """
        if icon:
            iconPixmap = icon.pixmap(iconSize, iconSize)
            self.icon_label.setPixmap(iconPixmap)

    def selectionChanged(self, selected: bool) -> None:
        """
        Update the icon based on selection state.
        
        Args:
            selected: True if the widget is selected, False otherwise.
        """
        if self.iconData:
            if selected != self.selected:
                self.icon_label.setPixmap(self.iconData.hoverCallableIcon().toPixmap() if selected else self.iconData.callableIcon.toPixmap())
        self.selected = selected

