

from typing import Callable
from PySide6.QtWidgets import QWidget, QCheckBox, QComboBox, QHBoxLayout, QSizePolicy
from ..comboBox.base import DataUpdate
from ..comboBox.utils import ignoreWheelEvent, updateData

class CheckBoxAndComboBox(QWidget):
    """
    Composite widget combining a checkbox and a combo box.
    
    This widget displays a checkbox and a combo box in a horizontal layout.
    Both widgets can have callback functions connected to their events.
    """
    
    def __init__(self, checkBoxText: str, comboBoxData: DataUpdate, checked: bool = False, checkBoxFunc: Callable[[bool], None] | None = None, comboBoxFunc: Callable[[int], None] | None = None, indexComboBox: int = 0, parent: QWidget | None = None) -> None:
        """
        Initialize the CheckBoxAndComboBox widget.
        
        Args:
            checkBoxText: The text to display next to the checkbox.
            comboBoxData: DataUpdate object containing items for the combo box.
            checked: Whether the checkbox should be checked initially.
                    Defaults to False.
            checkBoxFunc: Optional callback function for checkbox toggle events.
                        Receives the checked state as a parameter. Defaults to None.
            comboBoxFunc: Optional callback function for combo box activation events.
                         Receives the selected index as a parameter. Defaults to None.
            indexComboBox: Initial selected index for the combo box. Defaults to 0.
            parent: The parent widget for this widget. Defaults to None.
        """
        super().__init__(parent)

        self.comboBox = QComboBox()
        updateData(self.comboBox, comboBoxData)
        if comboBoxData.items:
            self.comboBox.setCurrentIndex(indexComboBox)
        self.checkBox = QCheckBox()
        self.checkBox.setText(checkBoxText)
        self.checkBox.setChecked(checked)
        self.checkBox.setSizePolicy(QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed))
        self.comboBox.setSizePolicy(QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred))

        ignoreWheelEvent(self.comboBox)

        if checkBoxFunc:
            self.checkBox.toggled.connect(checkBoxFunc)
        if comboBoxFunc:
            self.comboBox.activated.connect(comboBoxFunc)

        containerLayout = QHBoxLayout()
        containerLayout.addWidget(self.checkBox)
        containerLayout.addWidget(self.comboBox)
        containerLayout.setContentsMargins(0, 0, 0, 0)
        containerLayout.setSpacing(0)
        self.setLayout(containerLayout)

