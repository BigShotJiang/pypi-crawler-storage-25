
from PySide6.QtWidgets import QWidget, QVBoxLayout
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtWebEngineCore import QWebEngineSettings
from PySide6.QtWebEngineCore import QWebEngineDownloadRequest
from PySide6.QtCore import QUrl, QFileInfo, QCoreApplication
from ..dialog import Dialog
from ..notification import Notification
import os


class _QWebEngineView(QWebEngineView):
    """
    Internal QWebEngineView subclass: downloads, load visibility, and settings.
    Used only inside :class:`WebEngineView`.
    """

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent=parent)
        self.isLoaded: bool = False
        self._fileName: str = ""
        self.settings().setAttribute(QWebEngineSettings.WebAttribute.PluginsEnabled, True)
        self.settings().setAttribute(QWebEngineSettings.WebAttribute.PdfViewerEnabled, True)
        self.settings().setAttribute(QWebEngineSettings.WebAttribute.JavascriptEnabled, True)

        pageProfile = self.page().profile()
        pageProfile.downloadRequested.connect(self.onDownloadRequested)

        self.setUrl(QUrl("https://example.com"))
        self.close()
        self.loadFinished.connect(self.onLoadFinished)

    def onLoadFinished(self) -> None:
        """Show the view the first time a load completes."""
        if not self.isLoaded:
            self.show()
            self.isLoaded = True

    def onDownloadRequested(self, downloadRequest: QWebEngineDownloadRequest) -> None:
        """Prompt for a save path and accept the download."""
        downloadPath = downloadRequest.url().path()
        fileSuffix = QFileInfo(downloadPath).suffix()

        savePath, _ = Dialog.saveFileName(
            QCoreApplication.instance().activeWindow(),
            "Save File",
            "*." + fileSuffix,
            self._fileName,
        )

        if savePath:
            downloadRequest.stateChanged.connect(lambda: self.onDownloadStateChanged(downloadRequest))
            downloadRequest.setDownloadDirectory(os.path.dirname(savePath))
            downloadRequest.setDownloadFileName(os.path.basename(savePath))
            downloadRequest.accept()

    def onDownloadStateChanged(self, downloadRequest: QWebEngineDownloadRequest) -> None:
        """Notify when a download completes, fails, or is cancelled."""
        if downloadRequest.state() == QWebEngineDownloadRequest.DownloadState.DownloadCompleted:
            downloadPath = os.path.normpath(
                os.path.join(downloadRequest.downloadDirectory(), downloadRequest.downloadFileName())
            )
            Notification.success('Download', f"Download finished: {downloadPath}")
        elif downloadRequest.state() == QWebEngineDownloadRequest.DownloadState.DownloadInterrupted:
            Notification.error('Download', "Download interrupted")
        elif downloadRequest.state() == QWebEngineDownloadRequest.DownloadState.DownloadCancelled:
            Notification.error('Download', "Download cancelled")


class WebEngineView(QWidget):
    """
    QWidget wrapper around the internal QWebEngineView with helpers to set URLs.
    """

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._layout = QVBoxLayout(self)
        self._layout.setContentsMargins(0, 0, 0, 0)
        self._engine = _QWebEngineView()
        self._layout.addWidget(self._engine)

    def setUrlFromLocalFile(self, url: str) -> None:
        """Load a URL from a local filesystem path."""
        self._engine._fileName = os.path.basename(url)
        return self._engine.setUrl(QUrl.fromLocalFile(url))

    def setUrl(self, url: str) -> None:
        """Load a URL from a string."""
        self._engine._fileName = ""
        return self._engine.setUrl(QUrl(url))
