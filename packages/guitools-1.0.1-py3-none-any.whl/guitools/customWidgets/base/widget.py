

from PySide6.QtWidgets import QHBoxLayout, QWidget

class Widget(QWidget):
    """
    Extended QWidget with transparent background and horizontal layout.
    
    This class extends QWidget to provide a container widget with a transparent
    background and a horizontal layout that can optionally contain a child widget.
    """
    
    def __init__(self, *, children: QWidget | None = None, parent: QWidget | None = None) -> None:
        """
        Initialize the Widget container.
        
        Args:
            children: Optional child widget to add to the container's layout.
                    If None, the container will be empty. Defaults to None.
            parent: The parent widget for this container. Defaults to None.
        """
        super().__init__(parent)
        containerLayout = QHBoxLayout()
        containerLayout.setContentsMargins(0, 0, 0, 0)
        if children is not None:
            containerLayout.addWidget(children)
        self.setStyleSheet("background-color: 'transparent';")
        self.setLayout(containerLayout)

