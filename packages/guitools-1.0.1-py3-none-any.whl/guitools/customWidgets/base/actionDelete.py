

from PySide6.QtWidgets import QHBoxLayout, QPushButton, QWidget, QWidgetAction
from ...style import Styles
from typing import Callable

class ActionDelete(QWidgetAction):
    """
    Widget action that provides a delete button with icon.
    
    This class extends QWidgetAction to create a delete action with a button
    that can be added to menus or toolbars. The button includes a delete icon
    and can execute a custom callback function when clicked.
    """
    
    def __init__(self, parent: QWidget, actionDelete: Callable[[], None] | None = None, text: str = "Delete") -> None:
        """
        Initialize the ActionDelete widget action.
        
        Args:
            parent: The parent widget for this action.
            actionDelete: Optional callback function to execute when the delete
                        button is clicked. If None, no action will be performed.
            text: The text to display on the delete button. Defaults to "Delete".
        """
        super().__init__(parent)
        self.btnDelete = QPushButton(text)
        Styles.setIcon(self.btnDelete, Styles.Resources.trash.gray, Styles.Resources.trash.theme)
        Styles.setWidgetStyleTheme(Styles.button(transparent=True), self.btnDelete)
        self.actionDelete: Callable[[], None] | None = actionDelete
        self.btnDelete.clicked.connect(self.delete)
        containerWidget = QWidget()
        containerLayout = QHBoxLayout()
        containerLayout.setContentsMargins(0, 0, 0, 0)
        containerLayout.addWidget(self.btnDelete)
        containerWidget.setLayout(containerLayout)
        self.setDefaultWidget(containerWidget)

    def delete(self) -> None:
        """
        Execute the delete action callback.
        
        This method is called when the delete button is clicked. It executes
        the callback function if one was provided during initialization.
        """
        if self.actionDelete is not None:
            self.actionDelete()

