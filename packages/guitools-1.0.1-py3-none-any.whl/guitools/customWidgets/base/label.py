

from PySide6.QtWidgets import QLabel, QWidget
from PySide6.QtGui import QMouseEvent
from typing import Callable

class Label(QLabel):
    """
    Extended QLabel with double-click callback support.
    
    This class extends QLabel to add functionality for handling double-click
    events with a custom callback function.
    """
    
    def __init__(self, text: str = '', funcDoubleClick: Callable[[], None] | None = None, parent: QWidget | None = None) -> None:
        """
        Initialize the Label widget.
        
        Args:
            text: The text to display in the label. Defaults to an empty string.
            funcDoubleClick: Optional callback function to execute when the label
                           is double-clicked. If None, no action will be performed.
            parent: The parent widget for this label. Defaults to None.
        """
        super().__init__(text, parent)
        self.funcDoubleClick: Callable[[], None] | None = funcDoubleClick

    def mouseDoubleClickEvent(self, mouseEvent: QMouseEvent) -> None:
        """
        Handle mouse double-click events.
        
        This method is called when the label is double-clicked. It executes
        the callback function if one was provided during initialization.
        
        Args:
            mouseEvent: The mouse event containing information about the double-click.
        """
        if self.funcDoubleClick:
            self.funcDoubleClick()

