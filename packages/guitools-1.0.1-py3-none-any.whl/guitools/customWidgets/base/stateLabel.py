

from PySide6.QtWidgets import QHBoxLayout, QLabel, QSizePolicy, QWidget

class StateLabel(QWidget):
    """
    Widget that displays a state indicator as a colored label.
    
    This widget creates a square label with a fixed size that can be styled
    to indicate different states (e.g., online/offline, active/inactive).
    The label is contained within a transparent widget with a horizontal layout.
    """
    
    def __init__(self, style: str = "", size: int = 10, parent: QWidget | None = None) -> None:
        """
        Initialize the StateLabel widget.
        
        Args:
            style: CSS style sheet string to apply to the state label.
                 This is typically used to set the background color or border
                 to indicate the state. Defaults to an empty string.
            size: The size (width and height) of the state indicator in pixels.
                 Defaults to 10.
            parent: The parent widget for this state label. Defaults to None.
        """
        super().__init__(parent)
        containerLayout = QHBoxLayout()
        containerLayout.setContentsMargins(0, 0, 0, 0)
        self.label = QLabel()
        labelSizePolicy = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self.label.setSizePolicy(labelSizePolicy)
        containerLayout.addWidget(self.label)
        self.label.setMaximumSize(size, size)
        self.label.setMinimumSize(size, size)
        self.label.setStyleSheet(style)
        self.setStyleSheet('''
                    background-color: 'transparent';
        ''')

        self.setLayout(containerLayout)

