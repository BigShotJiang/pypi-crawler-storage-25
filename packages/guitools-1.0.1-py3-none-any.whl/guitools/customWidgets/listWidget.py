
from PySide6.QtWidgets import QListWidget, QListWidgetItem

class ListWidget(object):
    """
    Utility class for QListWidget operations.
    
    Provides static methods for updating, selecting, and retrieving items
    from QListWidget instances.
    """
    
    @staticmethod
    def update(listWidget: QListWidget, newData: list[str]) -> None:
        """
        Update the list widget with new data, adding and removing items as needed.
        
        Args:
            listWidget: The QListWidget to update.
            newData: The new list of strings to display.
        """
        allItems = [listWidget.item(i).text() for i in range(listWidget.count())]
      
        if allItems != newData:

            for itemText in newData:
                if itemText not in allItems:
                    listWidget.addItem(itemText)

            for index, itemText in enumerate(allItems):
                if itemText not in newData:
                    listWidget.takeItem(index)

    @staticmethod
    def selectItem(listWidget: QListWidget, itemText: str) -> None:
        """
        Select an item in the list widget by its text.
        
        Args:
            listWidget: The QListWidget.
            itemText: The text of the item to select.
        """
        allItems = [listWidget.item(i) for i in range(listWidget.count())]
        for item in allItems:
            if item.text() == itemText:
                if listWidget.currentRow() != -1:
                    if listWidget.currentItem().text() != itemText:
                        listWidget.setCurrentItem(item)
                else:
                    listWidget.setCurrentItem(item)

    @staticmethod
    def getCurrentItem(listWidget: QListWidget) -> QListWidgetItem | None:
        """
        Get the currently selected item from the list widget.
        
        Args:
            listWidget: The QListWidget.
        
        Returns:
            The current item, or None if no item is selected.
        """
        if listWidget.currentRow() != -1:
            return listWidget.currentItem()
        else:
            return None

    @classmethod
    def getCurrentItemSeveral(cls, *listWidgets: QListWidget) -> QListWidgetItem | None:
        """
        Get the current item from the first list widget that has a selection.
        
        Args:
            *listWidgets: Variable number of QListWidget instances to check.
        
        Returns:
            The current item from the first widget with a selection, or None if none have a selection.
        """
        for listWidget in listWidgets:
             currentItem = cls.getCurrentItem(listWidget)
             if currentItem:
                return currentItem
        return None



