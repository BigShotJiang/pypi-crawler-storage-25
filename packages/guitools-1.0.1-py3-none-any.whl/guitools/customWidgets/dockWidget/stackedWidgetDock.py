

from PySide6.QtWidgets import QStackedWidget, QWidget, QPushButton, QVBoxLayout
from PySide6.QtGui import QCloseEvent, QIcon
from PySide6.QtCore import Qt, QCoreApplication
from .base import BaseDockWidget

class StackedWidgetDock(BaseDockWidget):
    """
    Dock widget that can be embedded in a QStackedWidget.
    
    This dock widget can be added to a stacked widget and supports
    detaching/reattaching functionality.
    """
    
    def __init__(self, *, stackedWidget: QStackedWidget, widget: QWidget, btnMaximize: QPushButton, docTitle: str, icon: QIcon) -> None:
        """
        Initialize the StackedWidgetDock.
        
        Args:
            stackedWidget: The QStackedWidget to add this dock widget to.
            widget: The widget to display in the dock.
            btnMaximize: Button to trigger dock toggle.
            docTitle: The title to display in the dock widget window when detached.
            icon: Icon for the dock widget window.
        """
        super().__init__(docTitle)

        self.page = QWidget()
        self.btnMaximize: QPushButton = btnMaximize
        self.btnMaximize.setCursor(Qt.CursorShape.PointingHandCursor)
        from ...style import Styles
        Styles.setIcon(self.btnMaximize, Styles.Resources.maximize.gray, Styles.Resources.maximize.select)
        self.btnMaximize.clicked.connect(self.toggleDock)

        self.setWindowIcon(icon)
        self.stackedWidget = stackedWidget

        self.setWindowFlags(Qt.WindowType.CustomizeWindowHint | Qt.WindowType.Widget | Qt.WindowType.WindowMinimizeButtonHint |
                            Qt.WindowType.WindowMaximizeButtonHint | Qt.WindowType.WindowCloseButtonHint)

        self.setWidget(widget)

        pageLayout = QVBoxLayout(self.page)
        pageLayout.addWidget(self)
        pageLayout.setContentsMargins(0, 0, 0, 0)

        self.stackedWidget.addWidget(self.page)

        self.setTitleBarWidget(self.TitleWidget(self))
        self.installEventFilter(self)
        
        self.connectWidgetSignals(widget)
        self.applyStyleSheet(widget)

    def activate(self) -> None:
        """
        Activate the dock widget.
        
        If the widget is attached to a stacked widget, switches to its page.
        If detached, shows and activates the window.
        """
        if self.parent() is not None:
            self.stackedWidget.setCurrentWidget(self.page)
        else:
            if self.isHidden():
                self.show()
                self.setWindowState((self.windowState() & ~Qt.WindowState.WindowMinimized) | Qt.WindowState.WindowActive)
                self.activateWindow()
            else:
                self.setWindowState((self.windowState() & ~Qt.WindowState.WindowMinimized) | Qt.WindowState.WindowActive)
                self.activateWindow()

    def updateTitle(self, docTitle: str) -> None:
        """
        Update the dock widget title.
        
        Args:
            docTitle: The new title for the dock widget window.
        """
        self.setWindowTitle(docTitle)

    def updateIconData(self, icon: QIcon) -> None:
        """
        Update the dock widget icon.
        
        Args:
            icon: The new icon for the dock widget window.
        """
        self.setWindowIcon(icon)

    def isDock(self) -> bool:
        """
        Check if the dock widget is currently detached.
        
        Returns:
            True if the dock widget is detached (has no parent), False otherwise.
        """
        return self.parent() is None

    def toggleDock(self) -> None:
        """
        Toggle between docked and detached states.
        """
        if self.isDock():
            self.restoreDock()
        else:
            self.removeDock()

    def removeDock(self) -> None:
        """
        Remove the dock widget from the stacked widget and show it as a separate window.
        """
        self.detaching.emit()
        self.setParent(None)
        self.btnMaximize.close()
        pageIndex = self.stackedWidget.indexOf(self.page)
        if pageIndex != -1:
            self.stackedWidget.removeWidget(self.page)
            self.show()
        self.detached.emit()

    def restoreDock(self) -> None:
        """
        Restore the dock widget back into the stacked widget.
        """
        self.reattaching.emit()
        self.page.layout().addWidget(self)
        self.btnMaximize.show()
        self.stackedWidget.addWidget(self.page)
        self.reattached.emit()
        self.show()
        QCoreApplication.processEvents()

    def show(self) -> None:
        """
        Show the dock widget and center it on screen.
        
        Returns:
            The result of the parent class show() method.
        """
        self.resize(1200, 700)
        self.center()
        return super().show()

    def closeEvent(self, closeEvent: QCloseEvent) -> None:
        """
        Handle close events by restoring the dock instead of closing.
        
        Args:
            closeEvent: The close event.
        """
        self.restoreDock()
        closeEvent.ignore()

    def deleteLater(self) -> None:
        """
        Clean up resources before deletion.
        
        Returns:
            The result of the parent class deleteLater() method.
        """
        self.page.setParent(None)
        self.page.deleteLater()
        return super().deleteLater()

