
from .tabWidgetDock import TabWidgetDock
from .stackedWidgetDock import StackedWidgetDock
from .splitterDock import SplitterDock

class DockWidget:
    """
    Main class that groups the three types of DockWidget.
    
    This class provides nested classes for different dock widget implementations:
    - TabWidgetDock: For dock widgets embedded in QTabWidget
    - StackedWidgetDock: For dock widgets embedded in QStackedWidget
    - SplitterDock: For dock widgets embedded in QSplitter
    """
    
    class TabWidgetDock(TabWidgetDock):
        """Dock widget for QTabWidget."""
        ...
    
    class StackedWidgetDock(StackedWidgetDock):
        """Dock widget for QStackedWidget."""
        ...
    
    class SplitterDock(SplitterDock):
        """Dock widget for QSplitter."""
        ...

__all__ = [
    'DockWidget',
    'TabWidgetDock',
    'StackedWidgetDock',
    'SplitterDock',
]

