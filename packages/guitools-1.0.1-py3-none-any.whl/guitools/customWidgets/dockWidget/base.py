

from typing import Callable
from PySide6.QtWidgets import QWidget, QDockWidget, QApplication, QMainWindow
from PySide6.QtCore import QEvent, QObject, SignalInstance, Signal
from PySide6.QtGui import QResizeEvent
from ...style import Styles

class WidgetVisibilityWatcher(QObject):
    """
    Event filter that watches for widget visibility changes.
    
    This class monitors a widget and emits a signal when the widget is shown.
    """
    
    def __init__(self, widget: QWidget) -> None:
        """
        Initialize the WidgetVisibilityWatcher.
        
        Args:
            widget: The widget to monitor for visibility changes.
        """
        super().__init__(widget)
        self.widget: QWidget = widget
        self.widget.installEventFilter(self)

    def eventFilter(self, obj: QObject, event: QEvent) -> bool:
        """
        Filter events to detect when the widget is shown.
        
        Args:
            obj: The object that the event is being filtered for.
            event: The event being filtered.
        
        Returns:
            False to allow the event to continue processing.
        """
        if obj == self.widget and event.type() == QEvent.Type.Show:
            self.widget.showing.emit()
        return super().eventFilter(obj, event)

class BaseDockWidget(QDockWidget):
    """
    Base class with common functionality for all dock widgets.
    
    This class provides signals for resize, detach, and reattach events,
    along with utility methods for centering, connecting signals, and
    applying stylesheets.
    """
    
    resized = Signal()
    """Signal emitted when the dock widget is resized."""
    
    detached = Signal()
    """Signal emitted when the dock widget is detached."""
    
    reattached = Signal()
    """Signal emitted when the dock widget is reattached."""
    
    detaching = Signal()
    """Signal emitted when the dock widget is about to be detached."""
    
    reattaching = Signal()
    """Signal emitted when the dock widget is about to be reattached."""

    class StyleSheet(Styles.Standard.StyleSheet):
        """
        Style sheet for the dock widget.
        """
        
        def __init__(self):
            """
            Initialize the StyleSheet.
            """
            super().__init__()

        def style(self) -> str:
            """
            Get the style sheet string.
            
            Returns:
                The style sheet string.
            """
            return Styles.standard()

    class TitleWidget(QWidget):
        """
        Custom title bar widget for the dock widget.
        """
        
        def __init__(self, dockWidget: QDockWidget, parent: QWidget | None = None) -> None:
            """
            Initialize the TitleWidget.
            
            Args:
                dockWidget: The dock widget this title bar belongs to.
                parent: The parent widget. Defaults to None.
            """
            super().__init__(parent)
            self.dock: QDockWidget = dockWidget

    def resizeEvent(self, resizeEvent: QResizeEvent) -> None:
        """
        Handle resize events.
        
        Args:
            resizeEvent: The resize event containing information about the resize.
        """
        self.resized.emit()
        return super().resizeEvent(resizeEvent)

    def resizeConnect(self, func: Callable[[], None]) -> None:
        """
        Connect a function to the resize signal.
        
        Args:
            func: A callable function that takes no arguments and returns None.
                 This function will be called when the dock widget is resized.
        """
        self.resized.connect(func)

    def mainWindow(self) -> QMainWindow | None:
        """
        Get the main window of the application.
        
        Returns:
            The main QMainWindow instance, or None if not found.
        """
        app = QApplication.instance()

        if not app:
            return None

        if isinstance(app, QMainWindow):
            return app

        for widget in app.topLevelWidgets():
            if isinstance(widget, QMainWindow):
                return widget
        return None

    def center(self) -> None:
        """
        Center the window on the current screen.
        
        If the dock widget is detached, this method centers it on the screen
        where the main window is located.
        """
        mainWindow = self.mainWindow()
        if not mainWindow:
            return
            
        currentScreen = QApplication.screenAt(mainWindow.geometry().center())

        if currentScreen is None:
            currentScreen = QApplication.primaryScreen()

        screenGeometry = currentScreen.geometry()

        centerX = (screenGeometry.width() - self.width()) // 2 + screenGeometry.x()
        centerY = (screenGeometry.height() - self.height()) // 2 + screenGeometry.y()

        self.move(centerX, centerY)

    def eventFilter(self, obj: QObject, event: QEvent) -> bool:
        """
        Filter events to prevent double-click on non-client area.
        
        Args:
            obj: The object that the event is being filtered for.
            event: The event being filtered.
        
        Returns:
            True to block the event, False otherwise.
        """
        if event.type() == QEvent.Type.NonClientAreaMouseButtonDblClick:
            return True
        return super().eventFilter(obj, event)

    def connectWidgetSignals(self, widget: QWidget) -> None:
        """
        Connect widget signals if they exist.
        
        This method connects the dock widget's signals to corresponding
        signals in the provided widget, if they exist. It also sets up
        a visibility watcher if the widget has a 'showing' signal.
        
        Args:
            widget: The widget to connect signals from.
        """
        if hasattr(widget, 'detached'):
            self.detached.connect(widget.detached)
        if hasattr(widget, 'reattached'):
            self.reattached.connect(widget.reattached)
        if hasattr(widget, 'detaching'):
            self.detaching.connect(widget.detaching)
        if hasattr(widget, 'reattaching'):
            self.reattaching.connect(widget.reattaching)
        if hasattr(widget, 'showing'):
            if isinstance(widget.showing, SignalInstance):
                WidgetVisibilityWatcher(widget)

    def applyStyleSheet(self, widget: QWidget) -> None:
        """
        Apply the style sheet to the dock widget.
        
        If the widget has a custom style sheet attribute, it will be
        applied to the dock widget's style sheet.
        
        Args:
            widget: The widget that may contain custom style sheet information.
        """
        styleSheet = self.StyleSheet()
        if hasattr(widget, 'customStyleSheet'):
            setattr(styleSheet, 'widgetCustomStyleSheet', widget.customStyleSheet)
        Styles.setWidgetStyleTheme(styleSheet, self)

