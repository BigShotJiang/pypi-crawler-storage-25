

from PySide6.QtWidgets import QSplitter, QWidget, QPushButton, QVBoxLayout
from PySide6.QtGui import QCloseEvent, QIcon, QAction
from PySide6.QtCore import Qt, QCoreApplication
from .base import BaseDockWidget
from ...style import Styles

class SplitterDock(BaseDockWidget):
    """
    Dock widget that can be embedded in a QSplitter.
    
    This dock widget can be added to a splitter and supports detaching/reattaching
    while maintaining splitter sizes.
    """
    
    def __init__(self, *, splitter: QSplitter, widget: QWidget, btnMaximize: QPushButton | QAction, docTitle: str, icon: QIcon, sizes: list[int] = []) -> None:
        """
        Initialize the SplitterDock.
        
        Args:
            splitter: The QSplitter to add this dock widget to.
            widget: The widget to display in the dock.
            btnMaximize: Button or action to trigger dock toggle.
            docTitle: The title to display in the dock widget window when detached.
            icon: Icon for the dock widget window.
            sizes: List of sizes for the splitter when restored. Defaults to empty list.
        """
        super().__init__(docTitle)

        self.page = QWidget()
        self.sizes: list[int] = sizes
        self.btnMaximize: QPushButton | QAction = btnMaximize

        if isinstance(btnMaximize, QPushButton):
            self.btnMaximize.setCursor(Qt.CursorShape.PointingHandCursor)
            Styles.setIcon(self.btnMaximize, Styles.Resources.maximize.gray, Styles.Resources.maximize.select)
            self.btnMaximize.clicked.connect(self.toggleDock)
        elif isinstance(btnMaximize, QAction):
            self.btnMaximize.triggered.connect(self.toggleDock)
            self.btnMaximize.setIcon(Styles.Resources.maximize.gray())

        self.setWindowIcon(icon)
        self.splitter = splitter
        self.dockMode: bool = False

        self.setWindowFlags(Qt.WindowType.CustomizeWindowHint | Qt.WindowType.Widget | Qt.WindowType.WindowMinimizeButtonHint |
                            Qt.WindowType.WindowMaximizeButtonHint | Qt.WindowType.WindowCloseButtonHint)

        self.setWidget(widget)

        pageLayout = QVBoxLayout(self.page)
        pageLayout.addWidget(self)
        pageLayout.setContentsMargins(0, 0, 0, 0)

        self.splitter.addWidget(self.page)

        self.setTitleBarWidget(self.TitleWidget(self))
        self.installEventFilter(self)
        
        self.connectWidgetSignals(widget)
        self.applyStyleSheet(widget)

    def activate(self) -> None:
        """
        Activate the dock widget.
        
        If detached, shows and activates the window.
        """
        if self.parent() is None:
            if self.isHidden():
                self.show()
                self.setWindowState((self.windowState() & ~Qt.WindowState.WindowMinimized) | Qt.WindowState.WindowActive)
                self.activateWindow()
            else:
                self.setWindowState((self.windowState() & ~Qt.WindowState.WindowMinimized) | Qt.WindowState.WindowActive)
                self.activateWindow()

    def updateTitle(self, docTitle: str) -> None:
        """
        Update the dock widget title.
        
        Args:
            docTitle: The new title for the dock widget window.
        """
        self.setWindowTitle(docTitle)

    def updateIconData(self, icon: QIcon) -> None:
        """
        Update the dock widget icon.
        
        Args:
            icon: The new icon for the dock widget window.
        """
        self.setWindowIcon(icon)

    def isDock(self) -> bool:
        """
        Check if the dock widget is currently detached.
        
        Returns:
            True if the dock widget is detached (has no parent), False otherwise.
        """
        return self.parent() is None

    def toggleDock(self) -> None:
        """
        Toggle between docked and detached states.
        """
        if self.isDock():
            self.restoreDock()
        else:
            self.removeDock()

    def removeDock(self) -> None:
        """
        Remove the dock widget from the splitter and show it as a separate window.
        """
        self.dockMode = True
        self.detaching.emit()
        self.setParent(None)
        if isinstance(self.btnMaximize, QPushButton):
            self.btnMaximize.close()

        self.page.setParent(None)
        self.show()
        self.detached.emit()

    def restoreDock(self) -> None:
        """
        Restore the dock widget back into the splitter.
        """
        self.reattaching.emit()
        self.page.layout().addWidget(self)
        if isinstance(self.btnMaximize, QPushButton):
            self.btnMaximize.show()
        self.splitter.addWidget(self.page)
        if self.sizes:
            self.splitter.setSizes(self.sizes)
        self.reattached.emit()
        self.show()
        QCoreApplication.processEvents()
        self.dockMode = False

    def show(self) -> None:
        """
        Show the dock widget and center it on screen.
        
        Returns:
            The result of the parent class show() method.
        """
        self.resize(1200, 700)
        self.center()
        return super().show()

    def closeEvent(self, closeEvent: QCloseEvent) -> None:
        """
        Handle close events by restoring the dock instead of closing.
        
        Args:
            closeEvent: The close event.
        """
        self.restoreDock()
        closeEvent.ignore()

    def deleteLater(self) -> None:
        """
        Clean up resources before deletion.
        
        Returns:
            The result of the parent class deleteLater() method.
        """
        self.page.setParent(None)
        self.page.deleteLater()
        return super().deleteLater()

