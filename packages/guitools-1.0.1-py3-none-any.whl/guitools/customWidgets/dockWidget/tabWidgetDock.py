

from typing import Any, Callable
from PySide6.QtWidgets import QTabWidget, QWidget, QPushButton, QTabBar, QVBoxLayout
from PySide6.QtGui import QCloseEvent
from PySide6.QtCore import Qt, QSize, QCoreApplication, QTimer, Signal
from .base import BaseDockWidget
from ...style import Styles
from ..loadingOverlay import LoadingWidget

class TabWidgetDock(BaseDockWidget):
    """
    Dock widget that can be embedded in a QTabWidget.
    
    This dock widget can be added as a tab in a tab widget and supports
    lazy loading, detaching/reattaching, and optional delete functionality.
    """
    
    initialized = Signal()
    """Signal emitted when the widget is initialized and ready."""

    def __init__(self, *, tabWidget: QTabWidget, widgetCallable: Callable[[], QWidget] | QWidget, tabTitle: str, docTitle: str, iconData: Styles.Resources.Data, insertPosition: int | None = None, deleteEnabled: bool = False, showLoading: bool = True) -> None:
        """
        Initialize the TabWidgetDock.
        
        Args:
            tabWidget: The QTabWidget to add this dock widget to.
            widgetCallable: Either a callable that returns a QWidget, or a QWidget instance.
                          If a callable, the widget will be loaded lazily.
            tabTitle: The title to display in the tab.
            docTitle: The title to display in the dock widget window when detached.
            iconData: Icon data for the tab and window icon.
            insertPosition: Optional position to insert the tab. If None, appends to the end.
                          Defaults to None.
            deleteEnabled: Whether to show a delete button on the tab. Defaults to False.
            showLoading: Whether to show a loading overlay while loading the widget.
                       Defaults to True.
        """
        super().__init__(docTitle)
        tabWidget.setIconSize(QSize(20, 20))
        self.tab = QWidget()
        self._widgetCallable: Callable[[], QWidget] | QWidget = widgetCallable
        self.loaded: bool = not isinstance(widgetCallable, Callable)

        self.tabTitle: str = tabTitle
        self.icon = iconData.callableIcon()
        self.setWindowIcon(iconData.hoverCallableIcon())
        self.iconData: Styles.Resources.Data = iconData
        self.tabWidget = tabWidget
        self.deleteEnabled: bool = deleteEnabled

        self.setWindowFlags(Qt.WindowType.CustomizeWindowHint | Qt.WindowType.Widget | Qt.WindowType.WindowMinimizeButtonHint |
                            Qt.WindowType.WindowMaximizeButtonHint | Qt.WindowType.WindowCloseButtonHint)

        tabLayout = QVBoxLayout(self.tab)
        tabLayout.addWidget(self)
        tabLayout.setContentsMargins(0, 0, 0, 0)

        tabIcon = iconData.hoverCallableIcon() if tabWidget.count() == 0 else self.icon
        if insertPosition is not None:
            self.tabIndex: int = self.tabWidget.insertTab(insertPosition, self.tab, tabIcon, tabTitle)
        else:
            self.tabIndex: int = self.tabWidget.addTab(self.tab, tabIcon, tabTitle)

        self.setTitleBarWidget(self.TitleWidget(self))
        self.installEventFilter(self)

        self.connTabChanged = tabWidget.currentChanged.connect(self.toggleTab)

        self.addToggleButton()

        self._showLoading: bool = showLoading and not self.loaded

        if self._showLoading:
            widgetLoading = LoadingWidget(self)
            self.setWidget(widgetLoading)

        if self.loaded:
            self.setupLoadedWidget(widgetCallable)
        else:
            Styles.setWidgetStyleTheme(self.StyleSheet(), self)
            if tabWidget.count() == 1:
                self.load()

    def setupLoadedWidget(self, widget: QWidget) -> None:
        """
        Set up a widget that is already loaded.
        
        Args:
            widget: The widget to set up.
        """
        self.connectWidgetSignals(widget)

        styleSheet = self.StyleSheet()
        if hasattr(widget, 'customStyleSheet'):
            setattr(styleSheet, 'widgetCustomStyleSheet', widget.customStyleSheet)

        if self.deleteEnabled:
            if hasattr(widget, 'delete'):
                self._btnDelete.clicked.connect(widget.delete)
        Styles.setWidgetStyleTheme(styleSheet, self)
        self.setWidget(widget)
        self.initialized.emit()

    def load(self) -> None:
        """
        Load the widget lazily.
        
        If the widget was provided as a callable, this method calls it
        to create the widget and sets it up. If a loading overlay was
        shown, it is hidden after loading.
        """
        if not self.loaded:
            self.loaded = True
            if self._showLoading:
                QCoreApplication.processEvents()

            widget = self._widgetCallable() if isinstance(self._widgetCallable, Callable) else self._widgetCallable

            self.connectWidgetSignals(widget)

            styleSheet = self.StyleSheet()
            if hasattr(widget, 'customStyleSheet'):
                setattr(styleSheet, 'widgetCustomStyleSheet', widget.customStyleSheet)

            if self.deleteEnabled:
                if hasattr(widget, 'delete'):
                    self._btnDelete.clicked.connect(widget.delete)

            Styles.setWidgetStyleTheme(styleSheet, self)
            self.setWidget(widget)
            mainWindow = self.mainWindow()
            if mainWindow:
                mainWindow.hideLoadingOverlay()
            self.initialized.emit()

    def activate(self) -> None:
        """
        Activate the dock widget.
        
        If the widget is attached to a tab widget, switches to its tab.
        If detached, shows and activates the window.
        """
        if self.parent() is not None:
            self.tabWidget.setCurrentWidget(self.tab)
        else:
            if self.isHidden():
                self.show()
                self.setWindowState((self.windowState() & ~Qt.WindowState.WindowMinimized) | Qt.WindowState.WindowActive)
                self.activateWindow()
            else:
                self.setWindowState((self.windowState() & ~Qt.WindowState.WindowMinimized) | Qt.WindowState.WindowActive)
                self.activateWindow()
        QTimer.singleShot(2, self.load) if self._showLoading else self.load()

    def updateTitle(self, tabTitle: str, docTitle: str) -> None:
        """
        Update the tab and dock widget titles.
        
        Args:
            tabTitle: The new title for the tab.
            docTitle: The new title for the dock widget window.
        """
        self.tabTitle = tabTitle
        self.setWindowTitle(docTitle)
        tabIndex = self.tabWidget.indexOf(self.tab)
        if tabIndex != -1:
            self.tabWidget.setTabText(tabIndex, tabTitle)

    def updateIconData(self, iconData: Styles.Resources.Data) -> None:
        """
        Update the icon data for the tab and window.
        
        Args:
            iconData: The new icon data to use.
        """
        self.iconData = iconData
        self.icon = iconData.callableIcon()
        self.setWindowIcon(iconData.hoverCallableIcon())
        self.toggleTab()

    def toggleTab(self, *args: Any) -> None:
        """
        Toggle the tab icon based on whether it's the current tab.
        
        Args:
            *args: Variable arguments (unused, kept for signal compatibility).
        """
        tabPosition = self.tabWidget.indexOf(self.tab)
        if tabPosition != -1:
            if self.tabWidget.currentWidget() == self.tab:
                self.tabWidget.setTabIcon(tabPosition, self.iconData.hoverCallableIcon())
                QTimer.singleShot(2, self.load) if self._showLoading else self.load()
            else:
                self.tabWidget.setTabIcon(tabPosition, self.iconData.callableIcon())

    def setEnabledDelete(self, enabled: bool) -> None:
        """
        Enable or disable the delete button on the tab.
        
        Args:
            enabled: True to show the delete button, False to hide it.
        """
        tabIndex = self.tabWidget.indexOf(self.tab)
        self.deleteEnabled = enabled
        if self.parent() is not None:
            if enabled:
                self._btnDelete = QPushButton()
                if hasattr(self.widget(), 'delete') and self.loaded:
                    self._btnDelete.clicked.connect(self.widget().delete)
                self._btnDelete.setIconSize(QSize(14, 14))
                self._btnDelete.setCursor(Qt.CursorShape.PointingHandCursor)
                Styles.setIcon(self._btnDelete, Styles.Resources.trash.gray, Styles.Resources.trash.original)
                self.tabWidget.tabBar().setTabButton(tabIndex, QTabBar.ButtonPosition.RightSide, self._btnDelete)
            else:
                self._btnDelete = self.tabWidget.tabBar().tabButton(tabIndex, QTabBar.ButtonPosition.RightSide)
                if self._btnDelete:
                    self._btnDelete.setParent(None)

    def addToggleButton(self) -> None:
        """
        Add toggle buttons (maximize and optionally delete) to the tab bar.
        """
        tabIndex = self.tabWidget.indexOf(self.tab)
        if self.deleteEnabled:
            self._btnDelete = QPushButton()
            if hasattr(self.widget(), 'delete') and self.loaded:
                self._btnDelete.clicked.connect(self.widget().delete)
            self._btnDelete.setIconSize(QSize(14, 14))
            self._btnDelete.setCursor(Qt.CursorShape.PointingHandCursor)
            Styles.setIcon(self._btnDelete, Styles.Resources.trash.gray, Styles.Resources.trash.original)
            self.tabWidget.tabBar().setTabButton(tabIndex, QTabBar.ButtonPosition.RightSide, self._btnDelete)

        btnMaximize = QPushButton()
        btnMaximize.setIconSize(QSize(14, 14))
        btnMaximize.setCursor(Qt.CursorShape.PointingHandCursor)

        Styles.setIcon(btnMaximize, Styles.Resources.maximize.gray, Styles.Resources.maximize.theme)
        btnMaximize.clicked.connect(self.toggleDock)
        self.tabWidget.tabBar().setTabButton(tabIndex, QTabBar.ButtonPosition.LeftSide, btnMaximize)

    def toggleDock(self) -> None:
        """
        Toggle between docked and detached states.
        """
        if self.parent() is not None:
            self.removeDock()
        else:
            self.restoreDock()

    def removeDock(self) -> None:
        """
        Remove the dock widget from the tab widget and show it as a separate window.
        """
        self.detaching.emit()
        self.setParent(None)
        tabIndex = self.tabWidget.indexOf(self.tab)
        if tabIndex != -1:
            self.tabWidget.removeTab(tabIndex)
            self.show()
        self.detached.emit()
        QTimer.singleShot(2, self.load) if self._showLoading else self.load()

    def restoreDock(self) -> None:
        """
        Restore the dock widget back into the tab widget.
        """
        self.reattaching.emit()
        self.tab.layout().addWidget(self)
        self.tabWidget.insertTab(self.tabIndex, self.tab, self.icon, self.tabTitle)
        self.addToggleButton()
        self.reattached.emit()
        self.show()

    def show(self) -> None:
        """
        Show the dock widget and center it on screen.
        
        Returns:
            The result of the parent class show() method.
        """
        self.resize(1200, 700)
        self.center()
        return super().show()

    def closeEvent(self, closeEvent: QCloseEvent) -> None:
        """
        Handle close events by restoring the dock instead of closing.
        
        Args:
            closeEvent: The close event.
        """
        self.restoreDock()
        closeEvent.ignore()

    def deleteLater(self) -> None:
        """
        Clean up resources before deletion.
        
        Returns:
            The result of the parent class deleteLater() method.
        """
        self.tab.setParent(None)
        self.tab.deleteLater()
        self.tabWidget.disconnect(self.connTabChanged)
        return super().deleteLater()

