

from PySide6.QtWidgets import QApplication, QPlainTextEdit, QWidget, QTextEdit
from PySide6.QtGui import QTextOption, QWheelEvent, QTextCursor, QKeyEvent, QPainter, QTextCharFormat, QColor
from PySide6.QtCore import Qt, QRect, QSize, Slot
from enum import Enum
from typing import Union
import os
from ...style.widgets.theme import WidgetsTheme, BaseColor
from .highlighters import (
    PythonSyntaxHighlighter,
    VbNetSyntaxHighlighter,
    CSyntaxHighlighter,
    JsonSyntaxHighlighter,
    SqlSyntaxHighlighter,
    XmlHtmlSyntaxHighlighter,
    GenericSyntaxHighlighter,
)

class CodeEditor(QPlainTextEdit):
    """
    Code editor widget with syntax highlighting, line numbers, and indent guides.
    
    This editor extends QPlainTextEdit to provide features like syntax highlighting
    for multiple languages, line number display, automatic indentation, and
    visual indent guides.
    """
    
    class Language(Enum):
        """
        Enumeration of supported programming languages.
        """
        txt = 0
        generic = 1
        python = 2
        vb = 3
        csharp = 4
        json = 5
        XmlHtml = 6
        sql = 7

    def __init__(self, language: Language = Language.txt, adjustHeight: bool = False, content: str | None = None, readOnly: bool = False, indentWidth: int = 5, useSpaces: bool = True) -> None:
        """
        Initialize the CodeEditor.
        
        Args:
            language: The programming language for syntax highlighting.
                    Defaults to Language.txt.
            adjustHeight: Whether to automatically adjust height based on content.
                         Defaults to False.
            content: Initial text content to display. Defaults to None.
            readOnly: Whether the editor should be read-only. Defaults to False.
            indentWidth: Number of spaces or tabs for indentation. Defaults to 5.
            useSpaces: Whether to use spaces (True) or tabs (False) for indentation.
                      Defaults to True.
        """
        super().__init__()
        self.adjustHeight: bool = adjustHeight
        self.language: self.Language = language

        self.indentWidth: int = indentWidth
        self.useSpaces: bool = useSpaces
        self.indentGuideColor = BaseColor.division
        self.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)
        self.setWordWrapMode(QTextOption.WrapMode.NoWrap)

        self.setTabStopDistance(indentWidth * self.fontMetrics().horizontalAdvance(' '))

        self.lineNumberArea = LineNumberArea(self)
        self.blockCountChanged.connect(self.updateLineNumberAreaWidth)
        self.updateRequest.connect(self.updateLineNumberArea)
        self.cursorPositionChanged.connect(self.highlightCurrentLine)
        self.updateLineNumberAreaWidth(0)

        self.highlighter = None
        self.setLanguage(language)
        self.setReadOnly(readOnly)
        if not readOnly:
            self.highlightCurrentLine()

        self.currentFontSize: int = self.font().pointSize()
        self.setWordWrapMode(QTextOption.WrapMode.NoWrap)

        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        if adjustHeight:
            self.textChanged.connect(self.autoResize)
            self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        else:
            self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)

        if content:
            self.setPlainText(content)

        WidgetsTheme.setCodeEditorWidget(self)

    def setLanguage(self, language: Language) -> None:
        """
        Set the programming language and apply appropriate syntax highlighting.
        
        Args:
            language: The programming language to set.
        """
        self.language = language

        if language == self.Language.txt:
            self.highlighter = None
        elif language == self.Language.python:
            self.highlighter = PythonSyntaxHighlighter(self.document())
        elif language == self.Language.vb:
            self.highlighter = VbNetSyntaxHighlighter(self.document())
        elif language == self.Language.csharp:
            self.highlighter = CSyntaxHighlighter(self.document())
        elif language == self.Language.json:
            self.highlighter = JsonSyntaxHighlighter(self.document())
        elif language == self.Language.XmlHtml:
            self.highlighter = XmlHtmlSyntaxHighlighter(self.document())
        elif language == self.Language.generic:
            self.highlighter = GenericSyntaxHighlighter(self.document())
        elif language == self.Language.sql:
            self.highlighter = SqlSyntaxHighlighter(self.document())
    
    @classmethod
    def detectLanguageFromFilename(cls, filename: str, default: Union['CodeEditor.Language', None] = None) -> 'CodeEditor.Language':
        """
        Detect the programming language based on the file extension.

        Args:
            filename (str): The name of the file.
            default (CodeEditor.Language, optional): The language to return if no match is found.
                Defaults to Language.generic.

        Returns:
            CodeEditor.Language: The detected language enum value, or the default if unknown.
        """
        fileExtension = os.path.basename(filename).lower()

        if fileExtension.endswith('.py'):
            return cls.Language.python
        elif fileExtension.endswith('.vb'):
            return cls.Language.vb
        elif fileExtension.endswith('.cs'):
            return cls.Language.csharp
        elif fileExtension.endswith('.json'):
            return cls.Language.json
        elif fileExtension.endswith(('.xml', '.html', '.htm')):
            return cls.Language.XmlHtml
        elif fileExtension.endswith('.txt'):
            return cls.Language.txt
        elif fileExtension.endswith('.sql'):
            return cls.Language.sql

        if default is None:
            default = cls.Language.generic
        return default

    def toggleAdjustHeight(self, adjustHeight: bool) -> None:
        """
        Toggle automatic height adjustment based on content.
        
        Args:
            adjustHeight: True to enable automatic height adjustment, False to disable.
        """
        self.adjustHeight = adjustHeight
        try:
            self.textChanged.disconnect(self.autoResize)
        except:
            pass

        if adjustHeight:
            self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
            self.textChanged.connect(self.autoResize)
            self.autoResize()
        else:
            self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
            self.setFixedHeight(self.sizeHint().height())
            self.setMaximumHeight(16777215)
            self.setMinimumHeight(0)

    def appendText(self, textToAppend: str) -> None:
        """
        Append text to the end of the document.
        
        Args:
            textToAppend: The text to append.
        """
        if not textToAppend:
            return

        textCursor = self.textCursor()
        textCursor.movePosition(QTextCursor.MoveOperation.End)

        normalizedText = textToAppend.replace('\r\n', '\n').replace('\r', '\n')
        textCursor.insertText(normalizedText)
        self.setTextCursor(textCursor)

    def removeBlankLinesAtEnd(self) -> None:
        """
        Remove all blank lines at the end of the document.
        """
        document = self.document()
        textCursor = QTextCursor(document)

        textCursor.movePosition(QTextCursor.MoveOperation.End)

        while textCursor.block().position() > 0:
            blockText = textCursor.block().text()

            if blockText.strip() == '':
                textCursor.select(QTextCursor.SelectionType.BlockUnderCursor)
                textCursor.removeSelectedText()
                textCursor.deleteChar()
                textCursor.movePosition(QTextCursor.MoveOperation.PreviousBlock)
            else:
                break

    def setPlainText(self, text: str | None) -> None:
        """
        Set the plain text content and clear extra selections.
        
        Args:
            text: The text to set, or None to clear.
        """
        super().setPlainText(text)
        self.setExtraSelections([])

    def copy(self) -> None:
        """
        Copy all text to the clipboard.
        """
        clipboard = QApplication.clipboard()
        clipboard.setText(self.toPlainText())

    def autoResize(self) -> None:
        """
        Automatically resize the editor height based on content.
        
        This method calculates the total height needed for all blocks
        and sets the fixed height accordingly.
        """
        if not self.adjustHeight:
            return

        document = self.document()
        documentLayout = document.documentLayout()

        totalHeight = 0
        block = document.firstBlock()
        if block.isValid():
            totalHeight += documentLayout.blockBoundingRect(block).height()
        while block.isValid():
            totalHeight += documentLayout.blockBoundingRect(block).height()
            block = block.next()

        contentMargins = self.contentsMargins()
        totalHeight += contentMargins.top() + contentMargins.bottom()

        self.setFixedHeight(totalHeight)

    def highlighting(self) -> None:
        """
        Refresh syntax highlighting while preserving scroll positions.
        """
        if self.highlighter:
            verticalScrollPosition = self.verticalScrollBar().value()
            horizontalScrollPosition = self.horizontalScrollBar().value()

            codeText = self.toPlainText()
            self.clear()
            self.highlighter.highlighting()
            self.setPlainText(codeText)

            self.verticalScrollBar().setValue(verticalScrollPosition)
            self.horizontalScrollBar().setValue(horizontalScrollPosition)

    def wheelEvent(self, wheelEvent: QWheelEvent) -> None:
        """
        Handle wheel events for font size adjustment with Ctrl modifier.
        
        Args:
            wheelEvent: The wheel event containing information about the scroll.
        """
        if wheelEvent.modifiers() == Qt.KeyboardModifier.ControlModifier:
            if wheelEvent.angleDelta().y() > 0:
                self.currentFontSize += 1
            else:
                self.currentFontSize -= 1

            if self.currentFontSize < 1:
                self.currentFontSize = 1

            self.setStyleSheet(f'font: {self.currentFontSize}pt "Segoe UI"')
            wheelEvent.accept()
        else:
            super().wheelEvent(wheelEvent)

    def keyPressEvent(self, keyEvent: QKeyEvent) -> None:
        """
        Handle key press events for indentation and auto-indent on Enter.
        
        Args:
            keyEvent: The key event containing information about the pressed key.
        """
        textCursor = self.textCursor()
        indentString = ' ' * self.indentWidth if self.useSpaces else '\t'

        if keyEvent.key() == Qt.Key.Key_Tab:
            if textCursor.hasSelection():
                self.indentSelectedLines(textCursor, indentString, includeLastLine=True)
            else:
                super().keyPressEvent(keyEvent)

        elif keyEvent.key() == Qt.Key.Key_Backtab:
            if textCursor.hasSelection():
                self.unindentSelectedLines(textCursor, includeLastLine=True)

        elif keyEvent.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            blockText = textCursor.block().text()
            leadingSpaces = len(blockText) - len(blockText.lstrip(' '))
            currentIndent = blockText[:leadingSpaces]

            super().keyPressEvent(keyEvent)
            textCursor.insertText(currentIndent)

        else:
            super().keyPressEvent(keyEvent)

    def indentSelectedLines(self, textCursor: QTextCursor, indentString: str, includeLastLine: bool = False) -> None:
        """
        Indent all selected lines by adding the indent string at the beginning.
        
        Args:
            textCursor: The text cursor with the selection.
            indentString: The string to use for indentation (spaces or tab).
            includeLastLine: Whether to include the last line if cursor is at block start.
                           Defaults to False.
        """
        textCursor.beginEditBlock()
        selectionStart = textCursor.selectionStart()
        selectionEnd = textCursor.selectionEnd()

        textCursor.setPosition(selectionStart)
        textCursor.movePosition(QTextCursor.MoveOperation.StartOfBlock)
        startBlock = textCursor.block()

        textCursor.setPosition(selectionEnd)
        if includeLastLine or not textCursor.atBlockStart():
            endBlock = textCursor.block()
        else:
            endBlock = textCursor.block().previous()

        currentBlock = startBlock
        while currentBlock.isValid():
            blockCursor = QTextCursor(currentBlock)
            blockCursor.insertText(indentString)
            if currentBlock == endBlock:
                break
            currentBlock = currentBlock.next()

        textCursor.endEditBlock()

    def unindentSelectedLines(self, textCursor: QTextCursor, includeLastLine: bool = False) -> None:
        """
        Unindent all selected lines by removing leading tabs or spaces.
        
        Args:
            textCursor: The text cursor with the selection.
            includeLastLine: Whether to include the last line if cursor is at block start.
                           Defaults to False.
        """
        textCursor.beginEditBlock()
        selectionStart = textCursor.selectionStart()
        selectionEnd = textCursor.selectionEnd()
        textCursor.setPosition(selectionStart)
        startBlock = textCursor.block()

        textCursor.setPosition(selectionEnd)
        if includeLastLine and textCursor.atBlockStart() and selectionEnd != selectionStart:
            textCursor.movePosition(QTextCursor.MoveOperation.PreviousBlock)
        endBlock = textCursor.block()

        currentBlock = startBlock
        while True:
            blockCursor = QTextCursor(currentBlock)
            blockText = currentBlock.text()
            if blockText.startswith('\t'):
                blockCursor.deleteChar()
            elif blockText.startswith(' ' * self.indentWidth):
                for _ in range(self.indentWidth):
                    blockCursor.deleteChar()
            elif blockText.startswith(' '):
                blockCursor.deleteChar()
            if currentBlock == endBlock:
                break
            currentBlock = currentBlock.next()

        textCursor.endEditBlock()

    def paintEvent(self, paintEvent) -> None:
        """
        Paint indent guide lines for visual indentation assistance.
        
        Args:
            paintEvent: The paint event.
        """
        super().paintEvent(paintEvent)
        painter = QPainter(self.viewport())
        painter.setPen(self.indentGuideColor.QColor)

        fontMetrics = self.fontMetrics()
        spaceWidth = fontMetrics.horizontalAdvance(' ')
        indentPixel = spaceWidth * self.indentWidth

        currentBlock = self.firstVisibleBlock()
        contentOffset = self.contentOffset()
        viewportRect = self.viewport().rect()

        guideOffset = 3
        scrollX = self.horizontalScrollBar().value()

        while currentBlock.isValid():
            blockGeometry = self.blockBoundingGeometry(currentBlock).translated(contentOffset)
            blockTop = round(blockGeometry.top())
            blockBottom = round(blockGeometry.bottom())

            if blockBottom < 0:
                currentBlock = currentBlock.next()
                continue
            if blockTop > viewportRect.bottom():
                break

            blockText = currentBlock.text()
            isBlankLine = not blockText.strip()
            currentIndentPx = 0

            if isBlankLine:
                lookaheadBlock = currentBlock.next()
                while lookaheadBlock.isValid() and not lookaheadBlock.text().strip():
                    lookaheadBlock = lookaheadBlock.next()
                if lookaheadBlock.isValid():
                    nextBlockText = lookaheadBlock.text()
                    leadingSpaces = len(nextBlockText) - len(nextBlockText.lstrip(' '))
                    currentIndentPx = leadingSpaces * spaceWidth if leadingSpaces else 0
                else:
                    currentIndentPx = 0
            else:
                leadingSpaces = len(blockText) - len(blockText.lstrip(' '))
                currentIndentPx = leadingSpaces * spaceWidth

            if not isBlankLine or currentIndentPx > 0:
                indentLevel = 0
                while indentLevel * indentPixel < currentIndentPx:
                    guideX = indentLevel * indentPixel + guideOffset - scrollX
                    if 0 <= guideX <= viewportRect.width():
                        painter.drawLine(guideX, blockTop, guideX, blockBottom)
                    indentLevel += 1

            currentBlock = currentBlock.next()

        painter.end()

    def lineNumberAreaWidth(self) -> int:
        """
        Calculate the width needed for the line number area.
        
        Returns:
            The width in pixels needed to display line numbers.
        """
        digitCount = len(str(max(1, self.blockCount())))
        areaWidth = self.fontMetrics().horizontalAdvance('9') * digitCount + 10
        return areaWidth

    def updateLineNumberAreaWidth(self, _: int) -> None:
        """
        Update the viewport margins to accommodate the line number area.
        
        Args:
            _: Unused parameter (kept for signal compatibility).
        """
        self.setViewportMargins(self.lineNumberAreaWidth(), 0, 0, 0)

    @Slot(QRect, int)
    def updateLineNumberArea(self, updateRect: QRect, scrollDelta: int) -> None:
        """
        Update the line number area when the editor is scrolled or updated.
        
        Args:
            updateRect: The rectangle that needs to be updated.
            scrollDelta: The vertical scroll delta. If non-zero, scrolls the area.
        """
        if scrollDelta:
            self.lineNumberArea.scroll(0, scrollDelta)
        else:
            self.lineNumberArea.update(0, updateRect.y(), self.lineNumberArea.width(), updateRect.height())
        if updateRect.contains(self.viewport().rect()):
            self.updateLineNumberAreaWidth(0)

    def currentLineNumber(self) -> int:
        """
        Get the current line number (0-based).
        
        Returns:
            The line number of the current cursor position.
        """
        return self.textCursor().blockNumber()

    def resizeEvent(self, resizeEvent) -> None:
        """
        Handle resize events to update line number area geometry.
        
        Args:
            resizeEvent: The resize event.
        """
        super().resizeEvent(resizeEvent)
        if self.adjustHeight:
            self.autoResize()
        contentsRect = self.contentsRect()
        self.lineNumberArea.setGeometry(QRect(contentsRect.left(), contentsRect.top(), self.lineNumberAreaWidth(), contentsRect.height()))

    def highlightCurrentLine(self) -> None:
        """
        Highlight the line containing the cursor.
        """
        if not self.isReadOnly():
            if self.document().isEmpty():
                self.setExtraSelections([])
                return
            extraSelections = []
            lineSelection = QTextEdit.ExtraSelection()
            baseColor = self.palette().color(self.backgroundRole())
            brightness = 0.299 * baseColor.red() + 0.587 * baseColor.green() + 0.114 * baseColor.blue()
            darkenFactor = 102 if brightness > 128 else 110
            darkerColor = baseColor.darker(darkenFactor)
            lineSelection.format.setBackground(darkerColor)
            lineSelection.format.setProperty(QTextCharFormat.Property.FullWidthSelection, True)
            lineSelection.cursor = self.textCursor()
            lineSelection.cursor.clearSelection()
            extraSelections.append(lineSelection)
            self.setExtraSelections(extraSelections)

    def lineNumberAreaPaintEvent(self, paintEvent) -> None:
        """
        Paint the line numbers in the line number area.
        
        Args:
            paintEvent: The paint event containing the area to paint.
        """
        painter = QPainter(self.lineNumberArea)
        painter.fillRect(paintEvent.rect(), QColor(0, 0, 0, 0))

        currentBlock = self.firstVisibleBlock()
        blockNumber = currentBlock.blockNumber()
        blockTop = int(self.blockBoundingGeometry(currentBlock).translated(self.contentOffset()).top())
        blockBottom = blockTop + int(self.blockBoundingRect(currentBlock).height())

        currentLineNumber = self.currentLineNumber()

        while currentBlock.isValid() and blockTop <= paintEvent.rect().bottom():
            if currentBlock.isVisible() and blockBottom >= paintEvent.rect().top():
                lineNumberText = str(blockNumber + 1)

                if blockNumber == currentLineNumber:
                    lineColor = BaseColor.Reverse.primary.fromQColor(230)
                else:
                    lineColor = BaseColor.Reverse.primary.fromQColor(130)

                painter.setPen(lineColor)

                rightMargin = 10
                painter.drawText(0, blockTop, self.lineNumberArea.width() - rightMargin,
                                self.fontMetrics().height(), Qt.AlignmentFlag.AlignRight, lineNumberText)

            currentBlock = currentBlock.next()
            blockTop = blockBottom
            blockBottom = blockTop + int(self.blockBoundingRect(currentBlock).height())
            blockNumber += 1


class LineNumberArea(QWidget):
    """
    Widget that displays line numbers for the code editor.
    
    This widget is positioned to the left of the editor viewport and
    displays line numbers that correspond to the code blocks.
    """
    
    def __init__(self, editor: CodeEditor) -> None:
        """
        Initialize the LineNumberArea.
        
        Args:
            editor: The CodeEditor instance this line number area belongs to.
        """
        super().__init__(editor)
        self.codeEditor: CodeEditor = editor

    def sizeHint(self) -> QSize:
        """
        Get the preferred size for the line number area.
        
        Returns:
            A QSize with the calculated width and zero height.
        """
        return QSize(self.codeEditor.lineNumberAreaWidth(), 0)

    def paintEvent(self, paintEvent) -> None:
        """
        Delegate painting to the code editor's line number paint method.
        
        Args:
            paintEvent: The paint event.
        """
        self.codeEditor.lineNumberAreaPaintEvent(paintEvent)

