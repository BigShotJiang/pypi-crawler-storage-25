

from PySide6.QtWidgets import QApplication, QTextBrowser, QSizePolicy, QTextEdit
from PySide6.QtGui import QTextOption, QWheelEvent, QMouseEvent
from PySide6.QtCore import Qt, QUrl
from enum import Enum
import re
import tempfile
import os
import markdown
from typing import TYPE_CHECKING
from ...style.widgets.theme import WidgetsTheme
from .highlighters.terminal import TerminalSyntaxHighlighter
from .highlighters.braces import BracesHighlighter

if TYPE_CHECKING:
    from PySide6.QtWidgets import QTextEdit, QTextBrowser

class TextEditor(QTextBrowser):
    """
    Text editor widget with support for Markdown rendering and terminal syntax highlighting.
    
    This editor extends QTextBrowser to provide features like Markdown rendering,
    terminal syntax highlighting, automatic height adjustment, and custom mouse handling.
    """
    
    class Type(Enum):
        """
        Enumeration of text editor types.
        """
        Nothing = 'Nothing'
        Markdown = 'Markdown'
        Terminal = 'Terminal'

    def __init__(self, type: Type = Type.Markdown, adjustHeight: bool = False, content: str | None = None, readOnly: bool = False, wrapParagraphs: bool = False, mousePressParent: bool = False) -> None:
        """
        Initialize the TextEditor.
        
        Args:
            type: The type of text editor (Nothing, Markdown, or Terminal).
                 Defaults to Type.Markdown.
            adjustHeight: Whether to automatically adjust height based on content.
                         Defaults to False.
            content: Initial HTML or Markdown content to display. Defaults to None.
            readOnly: Whether the editor should be read-only. Defaults to False.
            wrapParagraphs: Whether to wrap paragraphs. Defaults to False.
            mousePressParent: Whether to forward mouse press events to parent widget.
                            Defaults to False.
        """
        super().__init__()
        self.adjustHeight: bool = adjustHeight
        self.wrapParagraphs: bool = wrapParagraphs
        self.type: self.Type = type
        self.mousePressParent: bool = mousePressParent

        if mousePressParent:
            self.setContextMenuPolicy(Qt.ContextMenuPolicy.NoContextMenu)
        self.setTabStopDistance(4 * self.fontMetrics().horizontalAdvance(' '))
        if type == self.Type.Terminal:
            self.highlighter = TerminalSyntaxHighlighter(self.document())
            WidgetsTheme.setCodeEditorWidget(self)
        else:
            self.highlighter = None

        self.setOpenExternalLinks(True)
        self.setReadOnly(readOnly)

        self.currentFontSize: int = self.font().pointSize()
        self.setWordWrapMode(QTextOption.WrapMode.NoWrap)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)

        if adjustHeight:
            self.textChanged.connect(self.autoResize)
            self.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Minimum)
            self.document().setTextWidth(self.viewport().width())
            self.autoResize()

        if content:
            self.setHtml(content)

    def resizeEvent(self, resizeEvent) -> None:
        """
        Handle resize events to update document width and auto-resize.
        
        Args:
            resizeEvent: The resize event.
        """
        super().resizeEvent(resizeEvent)
        self.document().setTextWidth(self.viewport().width())
        self.autoResize()

    def autoResize(self) -> None:
        """
        Automatically resize the editor height based on document content.
        """
        if self.adjustHeight:
            self.document().setTextWidth(self.viewport().width())
            contentMargins = self.contentsMargins()
            totalHeight = int(self.document().size().height() + contentMargins.top() + contentMargins.bottom())

            scrollbarHeight = self.horizontalScrollBar().sizeHint().height()
            totalHeight += scrollbarHeight
            self.setFixedHeight(totalHeight)

    def toggleAdjustHeight(self, adjustHeight: bool) -> None:
        """
        Toggle automatic height adjustment based on content.
        
        Args:
            adjustHeight: True to enable automatic height adjustment, False to disable.
        """
        self.adjustHeight = adjustHeight
        try:
            self.textChanged.disconnect(self.autoResize)
        except TypeError:
            pass
        if adjustHeight:
            self.textChanged.connect(self.autoResize)
            self.autoResize()

    def wrapText(self, text: str, maxLength: int) -> str:
        """
        Wrap text while preserving Markdown formatting tokens.
        
        Args:
            text: The text to wrap.
            maxLength: Maximum line length in characters.
        
        Returns:
            The wrapped text with preserved Markdown tokens.
        """
        wrappedLines = []
        markdownPattern = re.compile(r"(\*\*.*?\*\*|`.*?`|\*.*?\*)")

        for paragraph in text.strip().split("\n\n"):
            tokens = markdownPattern.split(paragraph)
            currentLine = ""

            for token in tokens:
                if markdownPattern.match(token):
                    if len(currentLine) + len(token) + 1 > maxLength:
                        wrappedLines.append(currentLine)
                        currentLine = token
                    else:
                        currentLine += " " + token if currentLine else token
                else:
                    for word in token.split():
                        if len(currentLine) + len(word) + 1 > maxLength:
                            wrappedLines.append(currentLine)
                            currentLine = word
                        else:
                            currentLine += " " + word if currentLine else word

            if currentLine:
                wrappedLines.append(currentLine)

        return "\n\n".join(wrappedLines)

    def setSourceWithContent(self, content: str) -> None:
        """
        Set the source content by creating a temporary file.
        
        Args:
            content: The Markdown content to set.
        """
        with tempfile.NamedTemporaryFile(delete=False, suffix=".md", mode='w', encoding='utf-8') as tempFile:
            tempFile.write(content)
            tempFilePath = tempFile.name
        super().setSource(QUrl.fromLocalFile(tempFilePath))
        os.remove(tempFilePath)

    def setHtml(self, content: str) -> None:
        """
        Set HTML content, optionally converting from Markdown.
        
        Args:
            content: HTML content or Markdown content (if type is Markdown).
        """
        if self.type == self.Type.Markdown:
            normalizedContent = re.sub(r'(?<!\n)\n([ \t]*[*\-])', r'\n\n\1', content)
            htmlBody = markdown.markdown(
                normalizedContent,
                extensions=[
                    "extra",
                    "codehilite",
                    "toc",
                    "sane_lists",
                    "smarty",
                    "admonition",
                    "attr_list",
                    "def_list",
                    "footnotes",
                    "abbr",
                ],
                output_format="html5"
            )
        else:
            htmlBody = content

        css = """
            <style>
            body {
                margin: 0;
                padding: 0;
            }

            h1, h2, h3, h4, h5, h6 {
                font-weight: 600;
                margin-top: 1em;
                margin-bottom: 0.5em;
            }

            a {
                color: #1E88E5;
                text-decoration: none;
            }
            a:hover {
                text-decoration: underline;
            }

            code {
                font-family: 'Courier New', monospace;
                background-color: rgba(128, 128, 128, 0.15);
                padding: 2px 4px;
                border-radius: 4px;
            }

            pre {
                background-color: rgba(128, 128, 128, 0.1);
                padding: 10px;
                overflow: auto;
                border-radius: 6px;
                margin: 1em 0;
            }

            pre code {
                background: none;
                padding: 0;
                display: block;
            }

            ul, ol {
                margin-left: 1.2em;
                padding-left: 0.8em;
            }

            blockquote {
                margin: 1em 0;
                padding-left: 1em;
                border-left: 3px solid rgba(128, 128, 128, 0.3);
            }

            table {
                border-collapse: collapse;
                width: 100%;
            }

            table, th, td {
                border: 1px solid rgba(128, 128, 128, 0.3);
            }

            th, td {
                padding: 6px;
                text-align: left;
            }
            </style>
        """

        fullHtml = f"<html><head>{css}</head><body>{htmlBody}</body></html>"
        super().setHtml(fullHtml)

    def setMarkdown(self, markdownText: str) -> None:
        """
        Set Markdown content (converted to HTML).
        
        Args:
            markdownText: The Markdown text to set.
        """
        return self.setHtml(markdownText)

    def setPlainText(self, plainText: str) -> None:
        """
        Set plain text content (treated as HTML).
        
        Args:
            plainText: The plain text to set.
        """
        return self.setHtml(plainText)

    def copy(self) -> None:
        """
        Copy all text to the clipboard.
        """
        clipboard = QApplication.clipboard()
        clipboard.setText(self.toPlainText())

    def highlighting(self) -> None:
        """
        Refresh syntax highlighting while preserving scroll positions.
        """
        if self.highlighter:
            verticalScrollPosition = self.verticalScrollBar().value()
            horizontalScrollPosition = self.horizontalScrollBar().value()

            codeText = self.toPlainText()
            self.clear()
            self.highlighter.highlighting()
            self.setPlainText(codeText)

            self.verticalScrollBar().setValue(verticalScrollPosition)
            self.horizontalScrollBar().setValue(horizontalScrollPosition)

    def wheelEvent(self, wheelEvent: QWheelEvent) -> None:
        """
        Handle wheel events for font size adjustment with Ctrl modifier.
        
        Args:
            wheelEvent: The wheel event containing information about the scroll.
        """
        if wheelEvent.modifiers() == Qt.KeyboardModifier.ControlModifier:
            if wheelEvent.angleDelta().y() > 0:
                self.currentFontSize += 1
            else:
                self.currentFontSize -= 1

            if self.currentFontSize < 1:
                self.currentFontSize = 1

            self.setStyleSheet(f'font: {self.currentFontSize}pt "Segoe UI"')
            wheelEvent.accept()
        else:
            super().wheelEvent(wheelEvent)

    def mousePressEvent(self, mouseEvent: QMouseEvent) -> None:
        """
        Handle mouse press events, optionally forwarding to parent.
        
        Args:
            mouseEvent: The mouse event.
        """
        if not self.mousePressParent:
            return super().mousePressEvent(mouseEvent)

        parentWidget = self.parentWidget()
        if parentWidget:
            forwardedEvent = QMouseEvent(mouseEvent.type(), mouseEvent.position(), mouseEvent.scenePosition(), mouseEvent.globalPosition(),
                                    Qt.MouseButton.LeftButton, Qt.MouseButton.LeftButton, mouseEvent.modifiers())
            QApplication.postEvent(parentWidget, forwardedEvent)
        else:
            super().mousePressEvent(mouseEvent)

    @classmethod
    def applyBracesHighlighter(cls, textWidget: QTextEdit | QTextBrowser, bracesTypes: list[BracesHighlighter.BracesType] = [], validateWordList: bool = False, validateIdentifier: bool = False) -> BracesHighlighter:
        """
        Apply a braces highlighter to a text widget.
        
        Args:
            textWidget: The text widget to apply the highlighter to.
            bracesTypes: List of brace types to highlight. Defaults to empty list.
            validateWordList: Whether to validate against a word list. Defaults to False.
            validateIdentifier: Whether to validate identifiers. Defaults to False.
        
        Returns:
            The created BracesHighlighter instance.
        """
        highlighter = BracesHighlighter(textWidget.document(), bracesTypes, validateWordList, validateIdentifier)
        setattr(textWidget, "highlighter", highlighter)
        return highlighter

