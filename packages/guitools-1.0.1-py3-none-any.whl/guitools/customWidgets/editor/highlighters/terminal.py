

from PySide6.QtGui import QSyntaxHighlighter, QTextCharFormat, QColor
from PySide6.QtCore import QRegularExpression
from ....style.utils import TypeTheme, Global

class TerminalSyntaxHighlighter(QSyntaxHighlighter):
    """
    Syntax highlighter for terminal/command line output.
    
    This highlighter provides syntax highlighting for terminal text including
    numbers, command options, environment variables, and commands.
    """
    
    def __init__(self, document):
        """
        Initialize the TerminalSyntaxHighlighter.
        
        Args:
            document: The QTextDocument to apply highlighting to.
        """
        super().__init__(document)
        self.highlighting_rules = []
        self.highlighting()

    def highlighting(self) -> None:
        """
        Set up terminal syntax highlighting rules.
        """
        self.highlighting_rules.clear()
        isDarkTheme = Global.theme == TypeTheme.dark

        # Numbers
        number_format = QTextCharFormat()
        number_format.setForeground(QColor("#B5CEA8" if Global.theme == TypeTheme.dark else "#006400"))
        self.highlighting_rules.append((QRegularExpression(r"\b[+-]?[0-9]+[lL]?\b"), number_format))
        self.highlighting_rules.append((QRegularExpression(r"\b[+-]?0[xX][0-9A-Fa-f]+\b"), number_format))
        self.highlighting_rules.append((QRegularExpression(r"\b[+-]?[0-9]+\.[0-9]*([eE][+-]?[0-9]+)?\b"), number_format))

        # Options (e.g., -h, --help)
        option_format = QTextCharFormat()
        option_format.setForeground(QColor("#C586C0" if isDarkTheme else "#7B68EE"))
        self.highlighting_rules.append((QRegularExpression(r"\s--?[a-zA-Z0-9-]+"), option_format))

        # Variables (e.g., $HOME, $(pwd))
        variable_format = QTextCharFormat()
        variable_format.setForeground(QColor("#4EC9B0" if isDarkTheme else "#008B8B"))
        self.highlighting_rules.append((QRegularExpression(r"\$\w+"), variable_format))
        self.highlighting_rules.append((QRegularExpression(r"\$\([^)]+\)"), variable_format))

        # Command (first word of line)
        command_format = QTextCharFormat()
        command_format.setForeground(QColor("#569CD6" if isDarkTheme else "#00008B"))
        self.highlighting_rules.append((QRegularExpression(r"^\s*[+-]?[0-9]+"), command_format))

    def highlightBlock(self, text: str) -> None:
        """
        Apply highlighting to a block of text.
        
        Args:
            text: The text block to highlight.
        """
        for pattern, format in self.highlighting_rules:
            matchIterator = pattern.globalMatch(text)
            while matchIterator.hasNext():
                match = matchIterator.next()
                self.setFormat(match.capturedStart(), match.capturedLength(), format)

