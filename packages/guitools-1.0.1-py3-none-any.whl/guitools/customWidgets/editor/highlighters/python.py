

from PySide6.QtGui import QTextCharFormat, QColor, QTextDocument
from PySide6.QtCore import QRegularExpression
from ....style.utils import TypeTheme, Global
from .base import BaseQSyntaxHighlighter

class PythonSyntaxHighlighter(BaseQSyntaxHighlighter):
    """
    Syntax highlighter for Python programming language.
    
    This highlighter provides syntax highlighting for Python code including keywords,
    decorators, numbers, functions, classes, type hints, operators, and built-in functions.
    """
    
    def __init__(self, document: QTextDocument):
        """
        Initialize the PythonSyntaxHighlighter.
        
        Args:
            document: The QTextDocument to apply highlighting to.
        """
        single_patterns = [
            QRegularExpression(r'"[^"\\]*(\\.[^"\\]*)*"'),
            QRegularExpression(r"'[^'\\]*(\\.[^'\\]*)*'")
        ]
        super().__init__(document, single_patterns, "'''", '"""', r"#.*")

    def highlighting(self) -> None:
        """
        Set up Python syntax highlighting rules.
        """
        self.highlighting_rules.clear()
        super().highlighting()

        # Keywords
        keyword_format = QTextCharFormat()
        keyword_format.setForeground(QColor("#569CD6" if Global.theme == TypeTheme.dark else "#00008B"))

        # Decorators
        decorator_format = QTextCharFormat()
        decorator_format.setForeground(QColor("#DCDCAA" if Global.theme == TypeTheme.dark else "#B8860B"))
        self.highlighting_rules.append((QRegularExpression(r"@\w+"), decorator_format))

        # Numbers
        number_format = QTextCharFormat()
        number_format.setForeground(QColor("#B5CEA8" if Global.theme == TypeTheme.dark else "#006400"))
        self.highlighting_rules.append((QRegularExpression(r"\b[+-]?[0-9]+[lL]?\b"), number_format))
        self.highlighting_rules.append((QRegularExpression(r"\b[+-]?0[xX][0-9A-Fa-f]+\b"), number_format))
        self.highlighting_rules.append((QRegularExpression(r"\b[+-]?[0-9]+\.[0-9]*([eE][+-]?[0-9]+)?\b"), number_format))

        # Functions
        function_format = QTextCharFormat()
        function_format.setForeground(QColor("#DCDCAA" if Global.theme == TypeTheme.dark else "#FF0000"))
        self.highlighting_rules.append((QRegularExpression(r"\bdef\s+\w+\b"), function_format))
        self.highlighting_rules.append((QRegularExpression(r"\b\w+(?=\()"), function_format))

        # Decorators
        self.highlighting_rules.append((QRegularExpression(r'@\w+'), function_format))

        # Class
        class_format = QTextCharFormat()
        class_format.setForeground(QColor("#4EC9B0" if Global.theme == TypeTheme.dark else "#008B8B"))
        self.highlighting_rules.append((QRegularExpression(r"class\s+\w+\s*\(([^)]+)\)"), class_format))

        # Parameter types after ":"
        self.highlighting_rules.append((QRegularExpression(r":\s*([A-Za-z_][A-Za-z0-9_]*)(?=\s*[,)|=])"), class_format))

        # Operators
        operator_format = QTextCharFormat()
        operator_format.setForeground(QColor("#D4D4D4" if Global.theme == TypeTheme.dark else "#808080"))
        operators = [
            r"\+", r"-", r"\*", r"/", r"//", r"%", r"\*\*", r"=", r"\+=", r"-=", r"\*=", r"/=", r"%=", r"&=", r"\|=", r"\^=",
            r">>", r"<<", r"==", r"!=", r"<", r">", r"<=", r">=", r"\(", r"\)", r"\[", r"\]", r"\{", r"\}", r"\.", r",", r":",
            r";", r"\?", r"@", r"&", r"\|", r"~", r"^", r"<<", r">>", r"\\"
        ]
        self.highlighting_rules += [(QRegularExpression(operatorPattern), operator_format) for operatorPattern in operators]

        keywords = [
            'and', 'as', 'assert', 'async', 'await', 'break', 'class', 'continue', 'def',
            'del', 'elif', 'else', 'except', 'False', 'finally', 'for', 'from', 'global',
            'if', 'import', 'in', 'is', 'lambda', 'None', 'nonlocal', 'not', 'or', 'pass',
            'raise', 'return', 'True', 'try', 'while', 'with', 'yield', 'self', 'cls'
        ]

        self.highlighting_rules += [(QRegularExpression(f"\\b{keyword}\\b"), keyword_format) for keyword in keywords]

        # Built-in functions
        builtin_format = QTextCharFormat()
        builtin_format.setForeground(QColor("#C586C0" if Global.theme == TypeTheme.dark else "#7B68EE"))
        builtinFunctions = [
            'abs', 'dict', 'help', 'min', 'setattr', 'all', 'dir', 'hex', 'next', 'slice',
            'any', 'divmod', 'id', 'object', 'sorted', 'ascii', 'enumerate', 'input', 'oct',
            'staticmethod', 'bin', 'eval', 'int', 'open', 'str', 'bool', 'exec', 'isinstance',
            'ord', 'sum', 'bytearray', 'filter', 'issubclass', 'pow', 'super', 'bytes', 'float',
            'iter', 'print', 'tuple', 'callable', 'format', 'len', 'property', 'type', 'chr',
            'frozenset', 'list', 'range', 'vars', 'classmethod', 'getattr', 'locals', 'repr',
            'zip', 'compile', 'globals', 'map', 'reversed', '__import__', 'complex', 'hasattr',
            'max', 'round', 'delattr', 'hash', 'memoryview', 'set'
        ]
        self.highlighting_rules += [(QRegularExpression(f"\\b{builtin}\\b"), builtin_format) for builtin in builtinFunctions]

