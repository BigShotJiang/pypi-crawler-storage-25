

from PySide6.QtGui import QSyntaxHighlighter, QTextCharFormat, QColor
from PySide6.QtCore import QRegularExpression
from ....style.utils import TypeTheme, Global

class XmlHtmlSyntaxHighlighter(QSyntaxHighlighter):
    """
    Syntax highlighter for XML and HTML markup languages.
    
    This highlighter provides syntax highlighting for XML/HTML files including
    tags, attributes, attribute values, punctuation, comments, entities, and doctype declarations.
    """
    
    def __init__(self, document):
        """
        Initialize the XmlHtmlSyntaxHighlighter.
        
        Args:
            document: The QTextDocument to apply highlighting to.
        """
        super().__init__(document)
        self.highlighting_rules = []
        self.highlighting()

    def highlighting(self) -> None:
        """
        Set up XML/HTML syntax highlighting rules.
        """
        self.highlighting_rules.clear()

        # Tags (blue)
        tag_format = QTextCharFormat()
        tag_format.setForeground(QColor("#569CD6" if Global.theme == TypeTheme.dark else "#00008B"))
        self.highlighting_rules.append((QRegularExpression(r"</?\b\w+"), tag_format))

        # Attributes (green)
        attribute_format = QTextCharFormat()
        attribute_format.setForeground(QColor("#B5CEA8" if Global.theme == TypeTheme.dark else "#006400"))
        self.highlighting_rules.append((QRegularExpression(r'\b\w+(?=\=)'), attribute_format))

        # Attribute values (red)
        value_format = QTextCharFormat()
        value_format.setForeground(QColor("#CE9178" if Global.theme == TypeTheme.dark else "#8B0000"))
        self.highlighting_rules.append((QRegularExpression(r'\".*?\"'), value_format))

        # Punctuation symbols (gray)
        punctuation_format = QTextCharFormat()
        punctuation_format.setForeground(QColor("#D4D4D4" if Global.theme == TypeTheme.dark else "#808080"))
        self.highlighting_rules.append((QRegularExpression(r"[<>/=]"), punctuation_format))

        # Comments (dark gray)
        comment_format = QTextCharFormat()
        comment_format.setForeground(QColor("#6A9955" if Global.theme == TypeTheme.dark else "#808080"))
        self.highlighting_rules.append((QRegularExpression(r'<!--[\s\S]*?-->'), comment_format))

        # HTML entities (orange)
        entity_format = QTextCharFormat()
        entity_format.setForeground(QColor("#D7BA7D" if Global.theme == TypeTheme.dark else "#FF4500"))
        self.highlighting_rules.append((QRegularExpression(r"&\w+;"), entity_format))

        # HTML Doctype (purple)
        doctype_format = QTextCharFormat()
        doctype_format.setForeground(QColor("#C586C0" if Global.theme == TypeTheme.dark else "#800080"))
        self.highlighting_rules.append((QRegularExpression(r"<!DOCTYPE.*?>"), doctype_format))

    def highlightBlock(self, text: str) -> None:
        """
        Apply highlighting to a block of text.
        
        Args:
            text: The text block to highlight.
        """
        for pattern, format in self.highlighting_rules:
            regularExpression = pattern.globalMatch(text)
            while regularExpression.hasNext():
                match = regularExpression.next()
                self.setFormat(match.capturedStart(), match.capturedLength(), format)

