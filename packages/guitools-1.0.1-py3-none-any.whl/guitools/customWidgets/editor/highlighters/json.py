

from PySide6.QtGui import QSyntaxHighlighter, QTextCharFormat, QColor
from PySide6.QtCore import QRegularExpression
from ....style.utils import TypeTheme, Global

class JsonSyntaxHighlighter(QSyntaxHighlighter):
    """
    Syntax highlighter for JSON format.
    
    This highlighter provides syntax highlighting for JSON files, including
    keys, values, numbers, booleans, nulls, and brackets.
    """
    
    def __init__(self, document):
        """
        Initialize the JsonSyntaxHighlighter.
        
        Args:
            document: The QTextDocument to apply highlighting to.
        """
        super().__init__(document)
        self.highlighting_rules = []
        self.highlighting()

    def highlighting(self) -> None:
        """
        Set up JSON syntax highlighting rules.
        """
        self.highlighting_rules.clear()

        # Numbers (green)
        number_format = QTextCharFormat()
        number_format.setForeground(QColor("#B5CEA8" if Global.theme == TypeTheme.dark else "#006400"))
        self.highlighting_rules.append((QRegularExpression(r"\b[+-]?[0-9]+(\.[0-9]+)?\b"), number_format))

        # Format for JSON keys (blue)
        key_format = QTextCharFormat()
        key_format.setForeground(QColor("#9CDCFE" if Global.theme == TypeTheme.dark else "#4682B4"))
        self.highlighting_rules.append((QRegularExpression(r'\".*?\"(?=\s*:)'), key_format))

        # Format for JSON values (red)
        value_format = QTextCharFormat()
        value_format.setForeground(QColor("#CE9178" if Global.theme == TypeTheme.dark else "#8B0000"))
        self.highlighting_rules.append((QRegularExpression(r'(?<=:\s)\".*?\"'), value_format))

        # Booleans and Nulls (blue)
        bool_null_format = QTextCharFormat()
        bool_null_format.setForeground(QColor("#569CD6" if Global.theme == TypeTheme.dark else "#00008B"))
        self.highlighting_rules.append((QRegularExpression(r"\b(true|false|null)\b"), bool_null_format))

        # Curly braces `{}` (darker blue)
        brace_format = QTextCharFormat()
        brace_format.setForeground(QColor("#569CD6" if Global.theme == TypeTheme.dark else "#00008B"))
        self.highlighting_rules.append((QRegularExpression(r"[\{\}]"), brace_format))

        # Square brackets `[]` (lilac)
        bracket_format = QTextCharFormat()
        bracket_format.setForeground(QColor("#C586C0" if Global.theme == TypeTheme.dark else "#7B68EE"))
        self.highlighting_rules.append((QRegularExpression(r"[\[\]]"), bracket_format))

    def highlightBlock(self, text: str) -> None:
        """
        Apply highlighting to a block of text.
        
        Args:
            text: The text block to highlight.
        """
        for pattern, format in self.highlighting_rules:
            regularExpression = pattern.globalMatch(text)
            while regularExpression.hasNext():
                match = regularExpression.next()
                self.setFormat(match.capturedStart(), match.capturedLength(), format)

