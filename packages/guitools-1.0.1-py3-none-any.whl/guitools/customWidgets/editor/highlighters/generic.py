

from PySide6.QtGui import QSyntaxHighlighter, QTextCharFormat, QColor
from PySide6.QtCore import QRegularExpression
from ....style.utils import TypeTheme, Global

class GenericSyntaxHighlighter(QSyntaxHighlighter):
    """
    Generic syntax highlighter for multiple programming languages.
    
    This highlighter provides common syntax highlighting patterns that work
    across many programming languages, including keywords, functions, classes,
    strings, numbers, comments, and operators.
    """
    
    def __init__(self, document):
        """
        Initialize the GenericSyntaxHighlighter.

        Args:
            document: QTextDocument associated with the QTextEdit.
        """
        super().__init__(document)
        self.multi_line_string_format = QTextCharFormat()
        self.highlighting_rules = []
        self.highlighting()

    def highlighting(self) -> None:
        """
        Set up generic highlighting rules that can match common syntax across many programming languages.
        """
        self.highlighting_rules.clear()
        self.multi_line_string_format.setForeground(QColor("#CE9178" if Global.theme == TypeTheme.dark else "#8B0000"))

        # Generic keyword format
        keyword_format = QTextCharFormat()
        keyword_format.setForeground(QColor("#569CD6" if Global.theme == TypeTheme.dark else "#00008B"))

        # Generic function and class format
        function_format = QTextCharFormat()
        function_format.setForeground(QColor("#DCDCAA" if Global.theme == TypeTheme.dark else "#B8860B"))

        class_format = QTextCharFormat()
        class_format.setForeground(QColor("#4EC9B0" if Global.theme == TypeTheme.dark else "#008B8B"))

        # String format (single, double, multiline)
        string_format = QTextCharFormat()
        string_format.setForeground(QColor("#CE9178" if Global.theme == TypeTheme.dark else "#8B0000"))

        # Number format
        number_format = QTextCharFormat()
        number_format.setForeground(QColor("#B5CEA8" if Global.theme == TypeTheme.dark else "#006400"))

        # Comment format with theme support
        comment_format = QTextCharFormat()
        comment_format.setForeground(QColor("#6A9955" if Global.theme == TypeTheme.dark else "#228B22"))

        # Operator format
        operator_format = QTextCharFormat()
        operator_format.setForeground(QColor("#D4D4D4" if Global.theme == TypeTheme.dark else "#808080"))

        # Adding generic regex rules for common elements
        keywords = [
            "using", "from", "if", "else", "for", "while", "return", "class", "def", "function", "import",
            "export", "try", "catch", "finally", "switch", "case", "break", "continue", "true",
            "false", "null", "undefined", "new", "delete", "this", "super", "public", "private",
            "protected", "static", "void", "var", "let", "const", "async", "await", "yield",
            "throw", "lambda"
        ]

        # Numbers: integers, floats, hexadecimal
        self.highlighting_rules.append((QRegularExpression(r"\b[+-]?[0-9]+[lL]?\b"), number_format))
        self.highlighting_rules.append((QRegularExpression(r"\b[+-]?0[xX][0-9A-Fa-f]+\b"), number_format))
        self.highlighting_rules.append((QRegularExpression(r"\b[+-]?[0-9]+\.[0-9]*([eE][+-]?[0-9]+)?\b"), number_format))

        # Functions and classes
        self.highlighting_rules.append((QRegularExpression(r"\b\w+\s*(?=\()", QRegularExpression.PatternOption.CaseInsensitiveOption), function_format))
        self.highlighting_rules.append((QRegularExpression(r"\bclass\s+\w+\b", QRegularExpression.PatternOption.CaseInsensitiveOption), class_format))
        self.highlighting_rules.append((QRegularExpression(r"\bdef\s+\w+\b", QRegularExpression.PatternOption.CaseInsensitiveOption), function_format))

        # Operators: common across languages
        operators = [
            r"\+", r"-", r"\*", r"/", r"//", r"%", r"\*\*", r"=", r"\+=", r"-=", r"\*=", r"/=", r"%=",
            r"&=", r"\|=", r"\^=", r">>", r"<<", r"==", r"!=", r"<", r">", r"<=", r">=", r"\(", r"\)", r"\[", r"\]",
            r"\{", r"\}", r"\.", r",", r":", r";", r"\?", r"@", r"&", r"\|", r"~", r"^", r"\\", r"->"
        ]
        self.highlighting_rules += [(QRegularExpression(op), operator_format) for op in operators]

        # Use case-insensitive regex pattern for keywords
        self.highlighting_rules += [(QRegularExpression(f"\\b{keyword}\\b", QRegularExpression.PatternOption.CaseInsensitiveOption), keyword_format) for keyword in keywords]

        # Strings: single, double, triple quotes
        self.highlighting_rules.append((QRegularExpression(r'"[^"\\]*(\\.[^"\\]*)*"', QRegularExpression.PatternOption.CaseInsensitiveOption), string_format))
        self.highlighting_rules.append((QRegularExpression(r"'[^'\\]*(\\.[^'\\]*)*'", QRegularExpression.PatternOption.CaseInsensitiveOption), string_format))

        # Comments: single line (//, #) and multi-line (/* */)
        self.highlighting_rules.append((QRegularExpression(r"//.*", QRegularExpression.PatternOption.CaseInsensitiveOption), comment_format))
        self.highlighting_rules.append((QRegularExpression(r"#.*", QRegularExpression.PatternOption.CaseInsensitiveOption), comment_format))
        self.highlighting_rules.append((QRegularExpression(r"/\*[\s\S]*?\*/", QRegularExpression.PatternOption.CaseInsensitiveOption), comment_format))

    def highlightBlock(self, text: str) -> None:
        """
        Apply the defined highlighting rules to the given text block.

        Args:
            text: The text block to highlight.
        """
        for pattern, format in self.highlighting_rules:
            regularExpression = QRegularExpression(pattern)
            matchIterator = regularExpression.globalMatch(text)
            while matchIterator.hasNext():
                match = matchIterator.next()
                self.setFormat(match.capturedStart(), match.capturedLength(), format)

