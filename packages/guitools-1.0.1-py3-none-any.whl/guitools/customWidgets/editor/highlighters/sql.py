

from PySide6.QtGui import QSyntaxHighlighter, QTextCharFormat, QColor
from PySide6.QtCore import QRegularExpression
from ....style.utils import TypeTheme, Global

class SqlSyntaxHighlighter(QSyntaxHighlighter):
    """
    Syntax highlighter for SQL programming language.
    
    This highlighter provides syntax highlighting for SQL code including keywords,
    operators, numbers, strings, functions, bracket identifiers, and comments.
    """
    
    def __init__(self, document):
        """
        Initialize the SqlSyntaxHighlighter.
        
        Args:
            document: The QTextDocument to apply highlighting to.
        """
        super().__init__(document)
        self.highlighting_rules = []
        self.highlighting()

    def highlighting(self) -> None:
        """
        Set up SQL syntax highlighting rules.
        """
        self.highlighting_rules.clear()

        isDarkTheme = getattr(Global, "theme", None) == TypeTheme.dark

        # Main keywords (blue)
        keyword_format = QTextCharFormat()
        keyword_format.setForeground(QColor("#569CD6" if isDarkTheme else "#0000CD"))
        mainKeywords = [
            "SELECT", "FROM", "WHERE", "GROUP", "BY", "ORDER", "HAVING",
            "INSERT", "INTO", "VALUES", "UPDATE", "SET", "DELETE",
            "CREATE", "TABLE", "DROP", "ALTER", "ADD",
            "DISTINCT", "TOP", "OFFSET", "FETCH", "NEXT", "ROWS", "ONLY"
        ]
        mainPattern = r"\b(" + "|".join(mainKeywords) + r")\b"
        self.highlighting_rules.append(
            (QRegularExpression(mainPattern, QRegularExpression.PatternOption.CaseInsensitiveOption), keyword_format)
        )

        # Logical and structural keywords/operators (gray)
        gray_format = QTextCharFormat()
        gray_format.setForeground(QColor("#808080" if isDarkTheme else "#696969"))
        grayKeywords = [
            "AND", "OR", "NOT", "NULL", "JOIN", "LEFT", "RIGHT", "INNER", "OUTER",
            "FULL", "CROSS", "ON", "IN", "IS", "LIKE", "BETWEEN", "EXISTS"
        ]
        grayPattern = r"\b(" + "|".join(grayKeywords) + r")\b"
        self.highlighting_rules.append(
            (QRegularExpression(grayPattern, QRegularExpression.PatternOption.CaseInsensitiveOption), gray_format)
        )

        # Operators (=, <, >, <>, !=, etc.)
        self.highlighting_rules.append(
            (QRegularExpression(r"(=|<>|!=|<=|>=|<|>)"), gray_format)
        )

        # Numbers
        number_format = QTextCharFormat()
        number_format.setForeground(QColor("#B5CEA8" if isDarkTheme else "#006400"))
        self.highlighting_rules.append((QRegularExpression(r"\b[+-]?[0-9]+(\.[0-9]+)?\b"), number_format))

        # Strings (red)
        string_format = QTextCharFormat()
        string_format.setForeground(QColor("#CE9178" if isDarkTheme else "#8B0000"))
        self.highlighting_rules.append((QRegularExpression(r"'([^']|'')*'"), string_format))

        # Functions (COUNT, SUM, etc.)
        function_format = QTextCharFormat()
        function_format.setForeground(QColor("#DCDCAA" if isDarkTheme else "#B8860B"))
        sqlFunctions = [
            "COUNT", "MAX", "MIN", "AVG", "SUM", "LEN", "UPPER", "LOWER",
            "CONVERT", "CAST", "ISNULL", "COALESCE", "GETDATE", "DATEADD", "DATEDIFF"
        ]
        functionPattern = r"\b(" + "|".join(sqlFunctions) + r")(?=\s*\()"
        self.highlighting_rules.append(
            (QRegularExpression(functionPattern, QRegularExpression.PatternOption.CaseInsensitiveOption), function_format)
        )

        # Identifiers in brackets [table], [column]
        bracket_format = QTextCharFormat()
        bracket_format.setForeground(QColor("#9CDCFE" if isDarkTheme else "#006699"))
        self.highlighting_rules.append((QRegularExpression(r"\[[^\]]+\]"), bracket_format))

        # Comments
        comment_format = QTextCharFormat()
        comment_format.setForeground(QColor("#6A9955" if isDarkTheme else "#008000"))
        self.highlighting_rules.append((QRegularExpression(r"--[^\n]*"), comment_format))

        # Multi-line comments /* ... */
        multiline_comment_format = QTextCharFormat()
        multiline_comment_format.setForeground(QColor("#6A9955" if isDarkTheme else "#008000"))
        self.comment_start = QRegularExpression(r"/\*")
        self.comment_end = QRegularExpression(r"\*/")
        self.multiline_comment_format = multiline_comment_format

    def highlightBlock(self, text: str) -> None:
        """
        Apply highlighting to a block of text.
        
        Args:
            text: The text block to highlight.
        """
        # Apply single-line rules
        for pattern, format in self.highlighting_rules:
            regularExpression = pattern.globalMatch(text)
            while regularExpression.hasNext():
                match = regularExpression.next()
                self.setFormat(match.capturedStart(), match.capturedLength(), format)

        # Handle multi-line comments
        self.setCurrentBlockState(0)
        startIndex = 0
        if self.previousBlockState() != 1:
            commentMatch = self.comment_start.match(text)
            startIndex = commentMatch.capturedStart() if commentMatch.hasMatch() else -1

        while startIndex >= 0:
            commentMatch = self.comment_end.match(text, startIndex)
            endIndex = commentMatch.capturedEnd() if commentMatch.hasMatch() else -1
            commentLength = (len(text) - startIndex) if endIndex == -1 else (endIndex - startIndex)
            self.setFormat(startIndex, commentLength, self.multiline_comment_format)
            if endIndex == -1:
                self.setCurrentBlockState(1)
                break
            else:
                commentMatch = self.comment_start.match(text, endIndex)
                startIndex = commentMatch.capturedStart() if commentMatch.hasMatch() else -1

