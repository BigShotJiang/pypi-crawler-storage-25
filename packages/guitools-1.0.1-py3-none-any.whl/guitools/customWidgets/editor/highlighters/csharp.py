

from PySide6.QtGui import QTextCharFormat, QColor, QTextDocument
from PySide6.QtCore import QRegularExpression
from ....style.utils import TypeTheme, Global
from .base import BaseQSyntaxHighlighter

class CSyntaxHighlighter(BaseQSyntaxHighlighter):
    """
    Syntax highlighter for C# programming language.
    
    This highlighter provides syntax highlighting for C# code including keywords,
    types, numbers, functions, classes, and operators.
    """
    
    def __init__(self, document):
        """
        Initialize the CSyntaxHighlighter.
        
        Args:
            document: The QTextDocument to apply highlighting to.
        """
        single_patterns = [
            QRegularExpression(r'"[^"\\]*(\\.[^"\\]*)*"'),
            QRegularExpression(r"'[^'\\]*(\\.[^'\\]*)*'")
        ]
        super().__init__(document, single_patterns, "/*", '*/', r"//.*")

    def highlighting(self) -> None:
        """
        Set up C# syntax highlighting rules.
        """
        self.highlighting_rules.clear()
        super().highlighting()

        # Keywords
        keyword_format = QTextCharFormat()
        keyword_format.setForeground(QColor("#569CD6" if Global.theme == TypeTheme.dark else "#00008B"))
        keywords = [
            "abstract", "as", "base", "bool", "break", "byte", "case", "catch", "char", "checked", "class", "const", "continue",
            "decimal", "default", "delegate", "do", "double", "else", "enum", "event", "explicit", "extern", "false", "finally",
            "fixed", "float", "for", "foreach", "goto", "if", "implicit", "in", "int", "interface", "internal", "is", "lock",
            "long", "namespace", "new", "null", "object", "operator", "out", "override", "params", "private", "protected",
            "public", "readonly", "ref", "return", "sbyte", "sealed", "short", "sizeof", "stackalloc", "static", "string",
            "struct", "switch", "this", "throw", "true", "try", "typeof", "uint", "ulong", "unchecked", "unsafe", "ushort",
            "using", "virtual", "void", "volatile", "while"
        ]
        self.highlighting_rules += [(QRegularExpression(f"\\b{keyword}\\b"), keyword_format) for keyword in keywords]

        # Types (int, float, etc.)
        type_format = QTextCharFormat()
        type_format.setForeground(QColor("#4EC9B0" if Global.theme == TypeTheme.dark else "#008B8B"))
        typeNames = ["int", "float", "double", "string", "char", "bool", "object", "void", "var"]
        self.highlighting_rules += [(QRegularExpression(f"\\b{typeName}\\b"), type_format) for typeName in typeNames]

        # Numbers
        number_format = QTextCharFormat()
        number_format.setForeground(QColor("#B5CEA8" if Global.theme == TypeTheme.dark else "#006400"))
        self.highlighting_rules.append((QRegularExpression(r"\b[+-]?[0-9]+(\.[0-9]+)?\b"), number_format))

        # Functions and Methods
        function_format = QTextCharFormat()
        function_format.setForeground(QColor("#DCDCAA" if Global.theme == TypeTheme.dark else "#FF0000"))
        self.highlighting_rules.append((QRegularExpression(r"\b\w+(?=\()"), function_format))

        # Class and Struct definitions
        class_format = QTextCharFormat()
        class_format.setForeground(QColor("#4EC9B0" if Global.theme == TypeTheme.dark else "#008B8B"))
        self.highlighting_rules.append((QRegularExpression(r"\bclass\s+\w+\b"), class_format))
        self.highlighting_rules.append((QRegularExpression(r"\bstruct\s+\w+\b"), class_format))

        # Operators
        operator_format = QTextCharFormat()
        operator_format.setForeground(QColor("#D4D4D4" if Global.theme == TypeTheme.dark else "#808080"))
        operators = [
            r"\+", r"-", r"\*", r"/", r"//", r"%", r"\*\*", r"=", r"\+=", r"-=", r"\*=", r"/=", r"%=", r"&=", r"\|=", r"\^=",
            r">>", r"<<", r"==", r"!=", r"<", r">", r"<=", r">=", r"\(", r"\)", r"\[", r"\]", r"\{", r"\}", r"\.", r",", r":",
            r";", r"\?", r"@", r"&", r"\|", r"~", r"^", r"<<", r">>", r"\\"
        ]
        self.highlighting_rules += [(QRegularExpression(operatorPattern), operator_format) for operatorPattern in operators]

