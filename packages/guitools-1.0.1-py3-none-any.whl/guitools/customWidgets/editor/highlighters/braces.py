

from PySide6.QtGui import QSyntaxHighlighter, QTextCharFormat, QColor
from PySide6.QtCore import QRegularExpression
from enum import Enum
from ....style import Styles
import re

class BracesHighlighter(QSyntaxHighlighter):
    """
    Syntax highlighter for brace-enclosed content with validation.
    
    This highlighter can validate identifiers and check against a word list,
    applying different colors based on validation results.
    """
    
    class BracesType(Enum):
        """
        Enumeration of brace types supported for highlighting.
        """
        CURLY = r'\{(.*?)\}'
        SQUARE = r'\[(.*?)\]'
        ROUND = r'\((.*?)\)'
        ANGLE = r'\<(.*?)\>'

    def __init__(self, document, braces_types=[], validate_word_list=False, validate_identifier=False):
        """
        Initialize the BracesHighlighter.
        
        Args:
            document: The QTextDocument to apply highlighting to.
            braces_types: List of brace types to highlight. Defaults to [BracesType.CURLY].
            validate_word_list: Whether to validate words against a list. Defaults to False.
            validate_identifier: Whether to validate that content is a valid identifier.
                               Defaults to False.
        """
        super().__init__(document)

        self.validate_word_list = validate_word_list
        self.validate_identifier = validate_identifier
        self.list_words = []
        self.color_word_in_list = QColor(Styles.appColor())
        self.color_word_outside_list = QColor("red")
        self.block_signals = False

        if not braces_types:
            braces_types = [self.BracesType.CURLY]

        self.patterns = [re.compile(brace_type.value) for brace_type in braces_types]

        self.brace_format_in_list = QTextCharFormat()
        self.brace_format_in_list.setForeground(self.color_word_in_list)

        self.brace_format_outside_list = QTextCharFormat()
        self.brace_format_outside_list.setForeground(self.color_word_outside_list)

    def updateListWords(self, new_list_words: list[str]) -> None:
        """
        Update the list of allowed words and reapply highlighting.
        
        Args:
            new_list_words: New list of words to validate against.
        """
        self.list_words = new_list_words
        self.rehighlight()

    def highlightBlock(self, text: str) -> None:
        """
        Apply highlighting to a block of text.
        
        Args:
            text: The text block to highlight.
        """
        if self.block_signals:
            return

        for pattern in self.patterns:
            for match in pattern.finditer(text):
                matchedWord = match.group(1)

                if matchedWord.isidentifier() or not self.validate_identifier:
                    if self.validate_word_list:
                        if matchedWord in self.list_words:
                            wordStartIndex = match.start(1)
                            self.setFormat(wordStartIndex, len(matchedWord), self.brace_format_in_list)
                        else:
                            wordStartIndex = match.start(1)
                            self.setFormat(wordStartIndex, len(matchedWord), self.brace_format_outside_list)
                    else:
                        wordStartIndex = match.start(1)
                        self.setFormat(wordStartIndex, len(matchedWord), self.brace_format_in_list)
                else:
                    wordStartIndex = match.start(1)
                    self.setFormat(wordStartIndex, len(matchedWord), self.brace_format_outside_list)

    @classmethod
    def formatText(cls, text: str, patterns: list[re.Pattern] = [re.compile(r'{(.*?)}')], color_word_identifier=Styles.Color.blue, color_word_not_identifier='red') -> str:
        """
        Format text by highlighting brace-enclosed content with HTML spans.
        
        Args:
            text: The text to format.
            patterns: List of regex patterns to match. Defaults to curly braces pattern.
            color_word_identifier: Color for valid identifiers. Defaults to Styles.Color.blue.
            color_word_not_identifier: Color for invalid identifiers. Defaults to 'red'.
        
        Returns:
            The formatted text with HTML span tags for colored content.
        """
        def replaceWord(match):
            word: str = match.group(1)
            fullMatch = match.group(0)
            openDelimiter = fullMatch[0] if len(fullMatch) > 0 else ''
            closeDelimiter = fullMatch[-1] if len(fullMatch) > 1 else ''

            if word.isidentifier():
                return f'{openDelimiter}<span style="color:{color_word_identifier};">{word}</span>{closeDelimiter}'
            else:
                return f'{openDelimiter}<span style="color:{color_word_not_identifier};">{word}</span>{closeDelimiter}'

        formattedText = text
        for pattern in patterns:
            formattedText = pattern.sub(replaceWord, formattedText)

        return formattedText

