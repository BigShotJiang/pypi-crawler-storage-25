

from PySide6.QtGui import QSyntaxHighlighter, QTextCharFormat, QColor
from PySide6.QtCore import QRegularExpression
from ....style.utils import TypeTheme, Global

class VbNetSyntaxHighlighter(QSyntaxHighlighter):
    """
    Syntax highlighter for VB.NET programming language.
    
    This highlighter provides syntax highlighting for VB.NET code including keywords,
    attributes, numbers, functions, classes, operators, and built-in functions.
    """
    
    def __init__(self, document):
        """
        Initialize the VbNetSyntaxHighlighter.
        
        Args:
            document: The QTextDocument to apply highlighting to.
        """
        super().__init__(document)
        self.highlighting_rules = []
        self.highlighting()

    def highlighting(self) -> None:
        """
        Set up VB.NET syntax highlighting rules.
        """
        self.highlighting_rules.clear()

        # Keywords
        keyword_format = QTextCharFormat()
        keyword_format.setForeground(QColor("#569CD6" if Global.theme == TypeTheme.dark else "#00008B"))

        # Decorators or Attributes
        attribute_format = QTextCharFormat()
        attribute_format.setForeground(QColor("#DCDCAA" if Global.theme == TypeTheme.dark else "#B8860B"))
        self.highlighting_rules.append((QRegularExpression(r"<\w+>"), attribute_format))

        # Numbers
        number_format = QTextCharFormat()
        number_format.setForeground(QColor("#B5CEA8" if Global.theme == TypeTheme.dark else "#006400"))
        self.highlighting_rules.append((QRegularExpression(r"\b[+-]?[0-9]+(\.[0-9]+)?\b"), number_format))

        # Functions and Subroutines
        function_format = QTextCharFormat()
        function_format.setForeground(QColor("#DCDCAA" if Global.theme == TypeTheme.dark else "#FF0000"))
        self.highlighting_rules.append((QRegularExpression(r"\b(Sub|Function)\s+\w+\b"), function_format))
        self.highlighting_rules.append((QRegularExpression(r"\b\w+(?=\()"), function_format))

        # Classes and Structures
        class_format = QTextCharFormat()
        class_format.setForeground(QColor("#4EC9B0" if Global.theme == TypeTheme.dark else "#008B8B"))
        self.highlighting_rules.append((QRegularExpression(r"\b(Class|Structure|Enum|Module)\s+\w+\b"), class_format))

        # Operators
        operator_format = QTextCharFormat()
        operator_format.setForeground(QColor("#D4D4D4" if Global.theme == TypeTheme.dark else "#808080"))
        operators = [
            r"\+", r"-", r"\*", r"/", r"\\", r"Mod", r"^", r"=", r"<", r">", r"<=", r">=", r"<>", r"Not", r"And", r"Or",
            r"Xor", r"Is", r"Like", r"&", r"\(", r"\)", r"\[", r"\]", r"\{", r"\}", r"\.", r",", r":", r";"
        ]
        self.highlighting_rules += [(QRegularExpression(operatorPattern), operator_format) for operatorPattern in operators]

        # VB.NET Keywords
        vbKeywords = [
            "Dim", "As", "Public", "Private", "Protected", "Friend", "Static", "Shared", "ReadOnly", "WriteOnly", "Const",
            "Option", "Strict", "Infer", "Explicit", "On", "Off", "If", "Then", "Else", "ElseIf", "End", "Select", "Case",
            "For", "Each", "To", "Next", "Do", "While", "Loop", "Until", "With", "Try", "Catch", "Finally", "Throw",
            "Return", "Exit", "Continue", "Goto", "True", "False", "Nothing", "New", "Set", "Get", "Property", "Inherits",
            "Implements", "Overrides", "Overloads", "MustOverride", "NotInheritable", "NotOverridable", "Partial", "Imports"
        ]
        self.highlighting_rules += [(QRegularExpression(f"\\b{keyword}\\b"), keyword_format) for keyword in vbKeywords]

        # Built-in functions
        builtin_format = QTextCharFormat()
        builtin_format.setForeground(QColor("#C586C0" if Global.theme == TypeTheme.dark else "#7B68EE"))

        builtinFunctions = [
            "MsgBox", "InputBox", "IsNothing", "IsDBNull", "Len", "UCase", "LCase", "Mid", "Replace", "Trim", "Split",
            "Join", "InStr", "Format", "Val", "Chr", "Asc", "DateAdd", "DateDiff", "DatePart", "DateSerial", "DateValue",
            "TimeSerial", "TimeValue", "Now", "Today", "CDate", "CInt", "CLng", "CStr", "CType", "CDbl", "CDec", "CSng"
        ]
        self.highlighting_rules += [(QRegularExpression(f"\\b{builtin}\\b"), builtin_format) for builtin in builtinFunctions]

        # Strings
        string_format = QTextCharFormat()
        string_format.setForeground(QColor("#CE9178" if Global.theme == TypeTheme.dark else "#8B0000"))
        self.highlighting_rules.append((QRegularExpression(r'"[^"\\]*(\\.[^"\\]*)*"'), string_format))

        # Comments
        comment_format = QTextCharFormat()
        comment_format.setForeground(QColor("#6A9955" if Global.theme == TypeTheme.dark else "#228B22"))
        self.highlighting_rules.append((QRegularExpression(r"'.*"), comment_format))

    def highlightBlock(self, text: str) -> None:
        """
        Apply highlighting to a block of text.
        
        Args:
            text: The text block to highlight.
        """
        for pattern, format in self.highlighting_rules:
            regularExpression = pattern.globalMatch(text)
            while regularExpression.hasNext():
                match = regularExpression.next()
                self.setFormat(match.capturedStart(), match.capturedLength(), format)

