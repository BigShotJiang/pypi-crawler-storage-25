

from PySide6.QtGui import QSyntaxHighlighter, QTextCharFormat, QColor, QTextDocument
from PySide6.QtCore import QRegularExpression
from ....style.utils import TypeTheme, Global

class BaseQSyntaxHighlighter(QSyntaxHighlighter):
    """
    Base syntax highlighter with support for single and triple-quoted strings.
    
    This class provides the foundation for language-specific syntax highlighters,
    handling string highlighting (both single and triple-quoted) and comments.
    """
    
    def __init__(self, document: QTextDocument, single_patterns: list[QRegularExpression], triple_single: str, triple_double: str, comment_pattern: str):
        """
        Initialize the BaseQSyntaxHighlighter.
        
        Args:
            document: The QTextDocument to apply highlighting to.
            single_patterns: List of regular expressions for single-quoted strings.
            triple_single: Triple single-quote delimiter (e.g., three single quotes).
            triple_double: Triple double-quote delimiter (e.g., three double quotes).
            comment_pattern: Regular expression pattern for comments.
        """
        super().__init__(document)
        self.highlighting_rules = []
        self.single_patterns = single_patterns
        self.triple_single = triple_single
        self.triple_double = triple_double
        
        # Comments
        self.comment_pattern = QRegularExpression(comment_pattern)
        
        self.highlighting()

    def highlighting(self) -> None:
        """
        Initialize highlighting formats for strings, multi-line strings, and comments.
        """
        self.string_format = QTextCharFormat()
        self.string_format.setForeground(QColor("#CE9178" if Global.theme == TypeTheme.dark else "#8B0000"))
        self.multi_format = QTextCharFormat(self.string_format)
        self.comment_format = QTextCharFormat()
        self.comment_format.setForeground(QColor("#6A9955" if Global.theme == TypeTheme.dark else "#228B22"))

    def highlightBlock(self, text: str) -> None:
        """
        Apply syntax highlighting to a block of text.
        
        Args:
            text: The text block to highlight.
        """
        for pattern, format in self.highlighting_rules:
            matchIterator = pattern.globalMatch(text)
            while matchIterator.hasNext():
                match = matchIterator.next()
                self.setFormat(match.capturedStart(), match.capturedLength(), format)

        # 1) Identify single strings, but not parts of triple-quoted strings
        singleStringRanges = []
        textMask = list(text)
        for singlePattern in self.single_patterns:
            patternIterator = singlePattern.globalMatch(text)
            while patternIterator.hasNext():
                match = patternIterator.next()
                startPos, matchLength = match.capturedStart(), match.capturedLength()
                quoteChar = text[startPos]
                # Check context to avoid triple quotes
                if text[startPos:startPos+3] in (self.triple_single, self.triple_double):
                    continue
                if startPos > 0 and text[startPos-1] == quoteChar:
                    continue
                endPos = startPos + matchLength
                if endPos < len(text) and text[endPos] == quoteChar:
                    continue
                # Mark single string
                self.setFormat(startPos, matchLength, self.string_format)
                singleStringRanges.append((startPos, endPos))
                for i in range(startPos, endPos): 
                    textMask[i] = ' '
        maskedText = ''.join(textMask)

        # 2) Find all triple quotes
        tripleQuotes = []
        for delimiter in (self.triple_single, self.triple_double):
            index = maskedText.find(delimiter)
            searchStart = 0
            while index != -1:
                tripleQuotes.append((index, delimiter))
                searchStart = index + 3
                index = maskedText.find(delimiter, searchStart)
        tripleQuotes.sort(key=lambda x: x[0])

        # 3) Handle previous block state
        previousState = self.previousBlockState()
        pendingDelimiter = self.triple_single if previousState == 1 else self.triple_double if previousState == 2 else None
        currentState = 0
        quoteIndex = 0
        # If pending, find closing delimiter
        if pendingDelimiter:
            while quoteIndex < len(tripleQuotes) and tripleQuotes[quoteIndex][1] != pendingDelimiter: 
                quoteIndex += 1
            if quoteIndex < len(tripleQuotes):
                # Close
                self.setFormat(0, tripleQuotes[quoteIndex][0] + 3, self.multi_format)
                quoteIndex += 1
            else:
                self.setFormat(0, len(text), self.multi_format)
                self.setCurrentBlockState(1 if pendingDelimiter == self.triple_single else 2)
                return

        # 4) Pair remaining triple quotes
        while quoteIndex + 1 < len(tripleQuotes):
            position1, delimiter1 = tripleQuotes[quoteIndex]
            # Find pair
            pairIndex = quoteIndex + 1
            while pairIndex < len(tripleQuotes) and tripleQuotes[pairIndex][1] != delimiter1: 
                pairIndex += 1
            if pairIndex < len(tripleQuotes):
                tripleLength = tripleQuotes[pairIndex][0] - position1 + 3
                self.setFormat(position1, tripleLength, self.multi_format)
                quoteIndex = pairIndex + 1
            else:
                break

        # 5) Opening without closing
        if quoteIndex < len(tripleQuotes):
            position1, delimiter1 = tripleQuotes[quoteIndex]
            self.setFormat(position1, len(text) - position1, self.multi_format)
            currentState = 1 if delimiter1 == self.triple_single else 2
        else:
            currentState = 0
        self.setCurrentBlockState(currentState)

        commentIterator = self.comment_pattern.globalMatch(text)
        while commentIterator.hasNext():
            commentMatch = commentIterator.next()
            commentStart, commentLength = commentMatch.capturedStart(), commentMatch.capturedLength()
            # Only apply if not inside a string
            isInsideString = any(commentStart >= startRange and commentStart < endRange for startRange, endRange in singleStringRanges)
            if not isInsideString and self.format(commentStart).foreground() != self.multi_format.foreground():
                self.setFormat(commentStart, commentLength, self.comment_format)

