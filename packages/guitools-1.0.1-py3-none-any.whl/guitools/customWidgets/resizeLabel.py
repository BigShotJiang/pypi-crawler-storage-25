from PySide6.QtWidgets import QSizePolicy, QLabel, QFrame, QVBoxLayout, QApplication
from PySide6.QtGui import QTextDocument
from PySide6.QtCore import Qt
import markdown
import webbrowser

class ResizeLabel(QFrame):
    """
    A QFrame containing a QLabel that automatically adjusts its size.
    
    Supports markdown rendering and link activation, with configurable
    word wrap and text interaction options.
    """

    def __init__(self, text: str = "", useMarkdown: bool = False, wordWrap: bool = True, textBrowserInteraction: bool = True, margins: list[int] = [0,0,0,0]) -> None:
        """
        Initialize the ResizeLabel.
        
        Args:
            text: The initial text to display. Defaults to "".
            useMarkdown: Whether to render text as markdown. Defaults to False.
            wordWrap: Whether to enable word wrapping. Defaults to True.
            textBrowserInteraction: Whether to enable text browser interaction. Defaults to True.
            margins: Layout margins (left, top, right, bottom). Defaults to [0,0,0,0].
        """
        super().__init__()
        self.label = QLabel("", self)
        self.label.linkActivated.connect(self.openLink)
        self._document = QTextDocument()
        
        if wordWrap:
            self.label.setWordWrap(True)

        if textBrowserInteraction:
            self.label.setTextInteractionFlags(
                Qt.TextInteractionFlag.TextBrowserInteraction |
                Qt.TextInteractionFlag.LinksAccessibleByMouse
            )
            
        containerLayout = QVBoxLayout(self)
        containerLayout.setContentsMargins(*margins)
        containerLayout.setSpacing(0)
        containerLayout.addWidget(self.label)
        self.setText(text, useMarkdown)
        self.setSizePolicy(QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed))

    def openLink(self, url: str) -> None:
        """
        Open a URL in the default web browser.
        
        Args:
            url: The URL to open.
        """
        webbrowser.open(url)

    def copy(self) -> None:
        """
        Copy the label text to the clipboard.
        """
        clipboard = QApplication.clipboard()
        clipboard.setText(self._document.toPlainText())
      
    def setText(self, text: str, useMarkdown: bool = False) -> None:
        """
        Set the text content of the label.
        
        Args:
            text: The text to display.
            useMarkdown: Whether to render text as markdown. Defaults to False.
        """
        if useMarkdown:
            htmlContent = markdown.markdown(text.strip())
            self._document.setHtml(htmlContent)
            self.label.setText(htmlContent)
        else:
            self._document.setPlainText(text)
            self.label.setText(text)
        self.adjustSize()

    def adjustSize(self) -> None:
        """
        Adjust the size of the label and frame to fit the content.
        
        Returns:
            The result of the parent's adjustSize method.
        """
        self.label.adjustSize() 
        return super().adjustSize()
    
 