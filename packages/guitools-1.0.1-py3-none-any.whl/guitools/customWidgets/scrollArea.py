

from PySide6.QtWidgets import QScrollArea, QWidget, QHBoxLayout, QVBoxLayout, QLabel
from PySide6.QtCore import Qt, Signal, QMimeData, SignalInstance, QCoreApplication
from PySide6.QtGui import QDrag, QPixmap, QDragEnterEvent, QDragMoveEvent, QDropEvent, QMouseEvent
from ..style import Styles

class DragItem(QWidget):
    """
    A draggable item widget for use within a ScrollArea.DragDrop.
    
    Each DragItem contains a drag handle and a content widget,
    and can be dragged to reorder items.
    """
    def __init__(self, swap: SignalInstance, index: int, contentWidget: QWidget) -> None:
        """
        Initialize the DragItem.
        
        Args:
            swap: Signal instance to emit when items are swapped.
            index: The initial index of this item.
            contentWidget: The widget to display as content.
        """
        super().__init__()
        self.swap: SignalInstance = swap
        self.current: int = index
        self.setAcceptDrops(True)
        self.setContentsMargins(0, 0, 0, 0)

        # Layout for the DragItem
        itemLayout = QHBoxLayout(self)
        itemLayout.setContentsMargins(0, 0, 0, 0)
        itemLayout.setSpacing(5)

        # Drag handle label
        self.dragLabel = QLabel(self)
        self.dragLabel.setFixedSize(16, 16)
        self.dragLabel.setAlignment(Qt.AlignmentFlag.AlignCenter)

        Styles.setIcon(self.dragLabel, Styles.Resources.dragDrop.gray,Styles.Resources.dragDrop.select, 16)

        # Custom content passed to DragItem
        itemLayout.addWidget(self.dragLabel, alignment=Qt.AlignmentFlag.AlignVCenter)
        itemLayout.addWidget(contentWidget)
        self.setLayout(itemLayout)
        
    def dragEnterEvent(self, dragEnterEvent: QDragEnterEvent) -> None:
        """
        Handle drag enter events.
        
        Args:
            dragEnterEvent: The drag enter event.
        """
        if dragEnterEvent.mimeData().hasText():
            dragEnterEvent.acceptProposedAction()
        else:
            dragEnterEvent.ignore()

    def dragMoveEvent(self, dragMoveEvent: QDragMoveEvent) -> None:
        """
        Handle drag move events.
        
        Args:
            dragMoveEvent: The drag move event.
        """
        if dragMoveEvent.mimeData().hasText():
            dragMoveEvent.acceptProposedAction()
        else:
            dragMoveEvent.ignore()

    def dropEvent(self, dropEvent: QDropEvent) -> None:
        """
        Handle drop events, emitting swap signal.
        
        Args:
            dropEvent: The drop event.
        """
        sourcePosition = int(dropEvent.mimeData().text())
        currentPosition = self.current
        self.swap.emit(*sorted([sourcePosition, currentPosition]))

    def mouseMoveEvent(self, mouseEvent: QMouseEvent) -> None:
        """
        Handle mouse move events to initiate dragging.
        
        Args:
            mouseEvent: The mouse move event.
        """
        if self.dragLabel.geometry().contains(mouseEvent.pos()):
            drag = QDrag(self)
            mimeData = QMimeData()
            mimeData.setText(str(self.current))

            dragPixmap = QPixmap(self.size())
            self.render(dragPixmap)
            mimeData.setImageData(dragPixmap)
            drag.setMimeData(mimeData)
            drag.setPixmap(dragPixmap)
            drag.setHotSpot(mouseEvent.pos())  # Set the drag hot spot
            drag.exec(Qt.DropAction.MoveAction)
           
class ScrollArea(object):
    """
    Utility class for scroll area operations.
    """

    class DragDrop(QScrollArea):
        """
        A scroll area that supports drag and drop reordering of items.
        
        This scroll area allows items to be reordered by dragging them,
        emitting a swap signal when items are moved.
        """
        swap = Signal(int, int)

        def __init__(self, *, adjustHeight: bool = False, parent: QWidget | None = None) -> None:
            """
            Initialize the DragDrop scroll area.
            
            Args:
                adjustHeight: Whether to automatically adjust height. Defaults to False.
                parent: The parent widget. Defaults to None.
            """
            super().__init__(parent)
            self._adjustHeight: bool = adjustHeight
            self.setWidgetResizable(True)
            self.contents = QWidget()
            self.contents.setContentsMargins(0, 0, 0, 0)
            self.setWidget(self.contents)
            self.layout = QVBoxLayout(self.contents)
            self.setAcceptDrops(True)
            self.swap.connect(self.swapWidgets)

        def adjustHeight(self, minHeight: int = 0, maxHeight: int = 0) -> None:
            """
            Adjust the height of the scroll area based on content.
            
            Args:
                minHeight: Minimum height. Defaults to 0.
                maxHeight: Maximum height. If 0, no maximum is set. Defaults to 0.
            """
            self.adjustSize()
            currentHeight = self.size().height()
            calculatedHeight = currentHeight + self.contentsMargins().top() + self.contentsMargins().bottom()
        
            calculatedHeight += self.horizontalScrollBar().maximum()

            newHeight = int(calculatedHeight)
        
            if newHeight < minHeight:
                newHeight = minHeight
            if newHeight > maxHeight and maxHeight > 0:
                newHeight = maxHeight

            self.setFixedHeight(newHeight)
           

        def addDragItem(self, contentWidget: QWidget) -> DragItem:
            """
            Add a new draggable item to the scroll area.
            
            Args:
                contentWidget: The widget to display as content.
            
            Returns:
                The created DragItem instance.
            """
            itemIndex = self.layout.count()
            dragItem = DragItem(self.swap, itemIndex, contentWidget)
            self.layout.addWidget(dragItem) 
            if itemIndex == 0 and self._adjustHeight:
                QCoreApplication.processEvents()
            if self._adjustHeight:
                self.adjustHeight()
            return dragItem

        def swapWidgets(self, pos1: int, pos2: int) -> None:
            """
            Swap two widgets at the specified positions.
            
            Args:
                pos1: The first position index.
                pos2: The second position index.
            """
            widget1 = self.layout.itemAt(pos1).widget()
            widget2 = self.layout.itemAt(pos2).widget()
            widget1.current, widget2.current = widget2.current, widget1.current
            self.layout.removeWidget(widget1)
            self.layout.removeWidget(widget2)
            self.layout.insertWidget(pos1, widget2)
            self.layout.insertWidget(pos2, widget1)

        def dragEnterEvent(self, dragEnterEvent: QDragEnterEvent) -> None:
            """
            Handle drag enter events.
            
            Args:
                dragEnterEvent: The drag enter event.
            """
            if dragEnterEvent.mimeData().hasText():
                dragEnterEvent.acceptProposedAction()
            else:
                dragEnterEvent.ignore()

        def dragMoveEvent(self, dragMoveEvent: QDragMoveEvent) -> None:
            """
            Handle drag move events.
            
            Args:
                dragMoveEvent: The drag move event.
            """
            if dragMoveEvent.mimeData().hasText():
                dragMoveEvent.acceptProposedAction()
            else:
                dragMoveEvent.ignore()

        def dropEvent(self, dropEvent: QDropEvent) -> None:
            """
            Handle drop events.
            
            Args:
                dropEvent: The drop event.
            """
            dropEvent.acceptProposedAction()