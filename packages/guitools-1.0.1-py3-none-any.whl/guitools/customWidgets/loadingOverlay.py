

from PySide6.QtWidgets import QWidget, QLabel, QVBoxLayout,  QGraphicsOpacityEffect, QApplication, QFrame
from PySide6.QtCore import Qt, QTimer, QEvent, QPropertyAnimation, Slot, QSize
from PySide6.QtGui import QPainter, QColor, QPen
import sys
import multiprocessing
import psutil
from ..style.utils import Global

class LoadingWidget(QWidget):
    """
    A loading widget with a spinner animation.
    """

    class SpinnerWidget(QWidget):
        """
        A spinner widget that displays an animated loading indicator.
        """
        def __init__(self, parent: QWidget, baseSize: int = 64, lines: int = 12, color: str | None = None) -> None:
            """
            Initialize the SpinnerWidget.
            
            Args:
                parent: The parent widget.
                baseSize: Base size for the spinner. Defaults to 64.
                lines: Number of lines in the spinner. Defaults to 12.
                color: Color for the spinner. If None, uses Global.appColor. Defaults to None.
            """
            super().__init__(parent)
            
            self._lines: int = lines
            self._current: int = 0
            self._color: QColor = QColor(color if color else Global.appColor)
            self._baseSize: int = baseSize  # Reference size
    
            # Initialize with baseSize
            self.setFixedSize(baseSize, baseSize)


        def resizeForParent(self, parentSize: QSize) -> None:
            """
            Dynamically adjust the spinner size based on the parent.
            
            Args:
                parentSize: The size of the parent widget.
            """
            side = min(parentSize.width(), parentSize.height())
            calculatedSize = max(46, int(side * 0.13))  # Occupies ~13% of the smaller side
            self.setFixedSize(calculatedSize, calculatedSize)
            self.update()

        def paintEvent(self, paintEvent) -> None:
            """
            Paint the spinner animation.
            
            Args:
                paintEvent: The paint event.
            """
            painter = QPainter(self)
            painter.setRenderHint(QPainter.RenderHint.Antialiasing)
            w, h = self.width(), self.height()
            painter.translate(w / 2, h / 2)

            radius = min(w, h) / 2 - 4
            inner = radius * 0.5
            lineLength = radius - inner
            penWidth = max(2, int(radius * 0.12))

            for i in range(self._lines):
                painter.save()
                angle = 360 * i / self._lines
                painter.rotate(angle)

                idx = (i + self._current) % self._lines
                alpha = 40 + int(215 * idx / max(1, self._lines - 1))

                color = QColor(self._color)
                color.setAlpha(alpha)

                pen = QPen(color)
                pen.setWidth(penWidth)
                pen.setCapStyle(Qt.PenCapStyle.RoundCap)
                painter.setPen(pen)
                painter.drawLine(0, -inner, 0, -inner - lineLength)
                painter.restore()

    def __init__(self, parent: QWidget, baseSize: int = 64, lines: int = 12, color: str | None = None) -> None:
        """
        Initialize the LoadingWidget.
        
        Args:
            parent: The parent widget.
            baseSize: Base size for the spinner. Defaults to 64.
            lines: Number of lines in the spinner. Defaults to 12.
            color: Color for the spinner. If None, uses Global.appColor. Defaults to None.
        """
        super().__init__(parent)
        self.widgetParent: QWidget = parent

        self.spinner = self.SpinnerWidget(self, baseSize=baseSize, lines=lines, color=color)

        containerLayout = QVBoxLayout(self)
        containerLayout.addWidget(self.spinner, alignment=Qt.AlignmentFlag.AlignCenter)
        containerLayout.setContentsMargins(0, 0, 0, 0)
        self.setLayout(containerLayout)

    def showEvent(self, showEvent) -> None:
        """
        Handle the show event, resizing the spinner for the parent.
        
        Args:
            showEvent: The show event.
        """
        self.spinner.resizeForParent(self.widgetParent.size())
        return super().showEvent(showEvent)

class SpinnerWidget(QWidget):
    """
    A standalone spinner widget with animation support.
    """
    def __init__(self, baseSize: int = 64, lines: int = 12, color: str | None = None, parent: QWidget | None = None) -> None:
        """
        Initialize the SpinnerWidget.
        
        Args:
            baseSize: Base size for the spinner. Defaults to 64.
            lines: Number of lines in the spinner. Defaults to 12.
            color: Color for the spinner. If None, uses Global.appColor. Defaults to None.
            parent: The parent widget. Defaults to None.
        """
        super().__init__(parent)

        self._lines: int = lines
        self._current: int = 0
        self._color: QColor = QColor(color if color else Global.appColor)
        self._baseSize: int = baseSize  # Reference size
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._rotate)

        # Initialize with baseSize
        self.setFixedSize(baseSize, baseSize)

    def resizeForParent(self, parentSize: QSize) -> None:
        """
        Dynamically adjust the spinner size based on the parent.
        
        Args:
            parentSize: The size of the parent widget.
        """
        side = min(parentSize.width(), parentSize.height())
        calculatedSize = max(46, int(side * 0.13))  # Occupies ~13% of the smaller side
        self.setFixedSize(calculatedSize, calculatedSize)
        self.update()

    def start(self) -> None:
        """
        Start the spinner animation.
        """
        if not self._timer.isActive():
            self._timer.start(80)
        self.update()

    def stop(self) -> None:
        """
        Stop the spinner animation.
        """
        if self._timer.isActive():
            self._timer.stop()
        self.update()

    @Slot()
    def _rotate(self) -> None:
        """
        Rotate the spinner to the next frame.
        """
        self._current = (self._current + 1) % self._lines
        self.update()

    def paintEvent(self, paintEvent) -> None:
        """
        Paint the spinner animation.
        
        Args:
            paintEvent: The paint event.
        """
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()
        painter.translate(w / 2, h / 2)

        radius = min(w, h) / 2 - 4
        inner = radius * 0.5
        lineLength = radius - inner
        penWidth = max(2, int(radius * 0.12))

        for i in range(self._lines):
            painter.save()
            angle = 360 * i / self._lines
            painter.rotate(angle)

            idx = (i + self._current) % self._lines
            alpha = 40 + int(215 * idx / max(1, self._lines - 1))

            color = QColor(self._color)
            color.setAlpha(alpha)

            pen = QPen(color)
            pen.setWidth(penWidth)
            pen.setCapStyle(Qt.PenCapStyle.RoundCap)
            painter.setPen(pen)
            painter.drawLine(0, -inner, 0, -inner - lineLength)
            painter.restore()

class LoadingOverlay(QWidget):
    """
    A loading overlay widget that displays a spinner and optional text over a parent widget.
    """
    def __init__(self, parentWidget: QWidget, backdrop: int = 20) -> None:
        """
        Initialize the LoadingOverlay.
        
        Args:
            parentWidget: The parent widget to overlay.
            backdrop: Backdrop opacity (0-255). Defaults to 20.
        """
        super().__init__(parentWidget)
        self._parent: QWidget = parentWidget
        self._active: bool = False
        self._backdropColor = self.parseBackdrop(backdrop)

        self.setWindowFlags(Qt.WindowType.Widget | Qt.WindowType.FramelessWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)

        mainLayout = QVBoxLayout(self)
        mainLayout.setContentsMargins(0, 0, 0, 0)
        mainLayout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        innerWidget = QWidget(self)
        innerWidget.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        innerLayout = QVBoxLayout(innerWidget)
        innerLayout.setContentsMargins(12, 12, 12, 12)
        innerLayout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        # Responsive spinner
        self.spinner = SpinnerWidget(parent=innerWidget)
        innerLayout.addWidget(self.spinner, 0, Qt.AlignmentFlag.AlignCenter)

        # Responsive label
        self.label = QLabel("", innerWidget)
        self.label.setStyleSheet(f"color: {Global.appColor}; margin-top: 8px; background: transparent;")
        self.label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label.hide()
        innerLayout.addWidget(self.label, 0, Qt.AlignmentFlag.AlignCenter)

        mainLayout.addWidget(innerWidget, 0, Qt.AlignmentFlag.AlignCenter)

        if parentWidget:
            self.setGeometry(0, 0, parentWidget.width(), parentWidget.height())
            parentWidget.installEventFilter(self)

        self._effect = QGraphicsOpacityEffect(self)
        self.setGraphicsEffect(self._effect)
        self._anim = QPropertyAnimation(self._effect, b"opacity", self)
        self._anim.setDuration(200)

        self.hide()

    def parseBackdrop(self, backdrop: int) -> QColor:
        """
        Parse backdrop value into a QColor.
        
        Args:
            backdrop: Backdrop opacity value.
        
        Returns:
            A QColor with the parsed backdrop color.
        """
        backdropColor = (0, 0, 0, backdrop)
        red, green, blue, alpha = map(float, backdropColor)
        if 0.0 <= alpha <= 1.0:
            alpha = int(alpha * 255)
        else:
            alpha = int(alpha)
        red, green, blue = int(red), int(green), int(blue)
        return QColor(red, green, blue, max(0, min(255, alpha)))

    def paintEvent(self, paintEvent) -> None:
        """
        Paint the backdrop.
        
        Args:
            paintEvent: The paint event.
        """
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.fillRect(self.rect(), self._backdropColor)
        super().paintEvent(paintEvent)

    def eventFilter(self, watched: QWidget, event: QEvent) -> bool:
        """
        Filter events to handle parent resize and move.
        
        Args:
            watched: The widget being watched.
            event: The event.
        
        Returns:
            True if the event was handled, False otherwise.
        """
        if watched is self._parent:
            if event.type() in (QEvent.Type.Resize, QEvent.Type.Move):
                self.setGeometry(0, 0, self._parent.width(), self._parent.height())
                self.updateResponsiveness()
        return super().eventFilter(watched, event)

    def updateResponsiveness(self) -> None:
        """
        Dynamically update spinner and label based on parent size.
        """
        if self._parent:
            parentSize = self._parent.size()
            self.spinner.resizeForParent(parentSize)

    def start(self, text: str = "", withFade: bool = True) -> None:
        """
        Start the loading overlay.
        
        Args:
            text: Optional text to display. Defaults to "".
            withFade: Whether to fade in. Defaults to True.
        """
        if not self._active:
            self._active = True
            if self._parent:
                self.setGeometry(0, 0, self._parent.width(), self._parent.height())
            self.raise_()
            self.show()

            if text.strip():
                self.label.setText(text.strip())
                self.label.show()
            else:
                self.label.hide()

            self.updateResponsiveness()
            self.spinner.start()

            if withFade:
                self._anim.stop()
                self._anim.setStartValue(0.0)
                self._anim.setEndValue(1.0)
                self._anim.start()
            else:
                self._effect.setOpacity(1.0)

    def stop(self, withFade: bool = True) -> None:
        """
        Stop the loading overlay.
        
        Args:
            withFade: Whether to fade out. Defaults to True.
        """
        self._active = False
        if withFade:
            self._anim.stop()
            self._anim.setStartValue(self._effect.opacity())
            self._anim.setEndValue(0.0)

            def onFinished() -> None:
                self._anim.finished.disconnect(onFinished)
                self.spinner.stop()
                self.hide()

            self._anim.finished.connect(onFinished)
            self._anim.start()
        else:
            self.spinner.stop()
            self.hide()

    def delete(self, withFade: bool = True) -> None:
        """
        Delete the loading overlay.
        
        Args:
            withFade: Whether to fade out before deleting. Defaults to True.
        """
        self.stop(withFade)
        self.setParent(None)
        self.deleteLater()

def overlayProcess(pipeConn, mainPid: int, backdrop: int = 20) -> None:
    """
    Process function for running the loading overlay in a separate process.
    
    Args:
        pipeConn: The pipe connection for receiving commands.
        mainPid: The process ID of the main application.
        backdrop: Backdrop opacity (0-255). Defaults to 20.
    """
    app = QApplication([])

    overlay = LoadingOverlay(parentWidget=None, backdrop=backdrop)
    overlay.setWindowFlags(Qt.FramelessWindowHint | Qt.Tool | Qt.WindowStaysOnTopHint)
    overlay.setAttribute(Qt.WA_TranslucentBackground)
    overlay.setAttribute(Qt.WA_TransparentForMouseEvents)
 
    overlay.show()

    overlayRequested = False

    def checkPipe() -> None:
        """
        Check for commands from the pipe connection.
        """
        nonlocal overlayRequested

        if not isProcessAlive(mainPid):
            print('LoadingOverlayApp closed')
            app.quit()
            return

        while pipeConn.poll():
            command = pipeConn.recv()
            action = command.get("action")
            if action == "show":
                geometry = command["geometry"]
                text = command.get("text", "")
                overlay.setGeometry(*geometry)
                overlay.spinner.resizeForParent(QSize(geometry[2], geometry[3]))
                overlay.start(text=text)
                overlayRequested = True
            elif action == "hide":
                overlay.stop()
                overlayRequested = False
            elif action == "exit":
                app.quit()

        if overlayRequested and isMainActive(mainPid):
            if not overlay.isVisible():
                overlay.show()
        else:
            overlay.hide()

    def isProcessAlive(pid: int) -> bool:
        """
        Check if a process is alive.
        
        Args:
            pid: The process ID to check.
        
        Returns:
            True if the process is alive, False otherwise.
        """
        return psutil.pid_exists(pid)

    def isMainActive(pid: int) -> bool:
        """
        Check if the main process is active (foreground on Windows).
        
        Args:
            pid: The process ID to check.
        
        Returns:
            True if the process is active, False otherwise.
        """
        if sys.platform != "win32":
            return True
        try:
            import win32gui
            import win32process
            foregroundWindow = win32gui.GetForegroundWindow()
            _, foregroundPid = win32process.GetWindowThreadProcessId(foregroundWindow)
            return foregroundPid == pid
        except Exception:
            return True

    # Timer to check for pipe messages
    checkTimer = QTimer()
    checkTimer.timeout.connect(checkPipe)
    checkTimer.start(50)

    sys.exit(app.exec())

# ---------------- Overlay Wrapper ----------------
class LoadingOverlayApp:
    """
    A wrapper class for managing a loading overlay in a separate process.
    """
    def __init__(self, mainPid: int, backdrop: int = 20) -> None:
        """
        Initialize the LoadingOverlayApp.
        
        Args:
            mainPid: The process ID of the main application.
            backdrop: Backdrop opacity (0-255). Defaults to 20.
        """
        self._parentConn, childConn = multiprocessing.Pipe()
        self._proc = multiprocessing.Process(
            target=overlayProcess, args=(childConn, mainPid, backdrop), daemon=True
        )
        self._proc.start()

    def start(self, x: int, y: int, width: int, height: int, text: str = "Loading...") -> None:
        """
        Start the loading overlay at the specified position and size.
        
        Args:
            x: X position.
            y: Y position.
            width: Width of the overlay.
            height: Height of the overlay.
            text: Text to display. Defaults to "Loading...".
        """
        self._parentConn.send({"action": "show", "geometry": (x, y, width, height), "text": text})

    def stop(self) -> None:
        """
        Stop the loading overlay.
        """
        self._parentConn.send({"action": "hide"})

    def close(self) -> None:
        """
        Close the loading overlay and terminate the process.
        """
        self._parentConn.send({"action": "exit"})
        self._proc.join()
