# coding: utf-8
"""
Custom Qt widgets.

Import from this package directly, e.g. ``from guitools.customWidgets import ComboBox``.
"""
from __future__ import annotations

from .base import ActionDelete, Label, StateLabel, Widget
from .comboBox import CheckableComboBox, ComboBox
from .composite import (
    CheckBoxAndComboBox,
    IconCheckBox,
    IconLabel,
    IconLabelPushButton,
    LabelAndPushButton,
)
from .dockWidget import DockWidget, SplitterDock, StackedWidgetDock, TabWidgetDock
from .dragDrop import DragDrop
from .editor import CodeEditor, TextEditor
from .frame import Frame
from .lineEdit import LineEditPassWord, TextMasker
from .listWidget import ListWidget
from .loadingOverlay import LoadingOverlay, LoadingOverlayApp, LoadingWidget
from .menu import Menu, MenuTextEditVariables
from .resizeLabel import ResizeLabel
from .scroll import HorizontalScrollArea, VerticalScrollArea
from .scrollArea import DragItem, ScrollArea
from .sideBar import SideBar
from .tableWidget import TableWidget
from .textEdit import AutoResizingTextEdit
from .treeWidget import TreeWidget
from .webEngineView import WebEngineView

__all__ = [
    'ActionDelete',
    'AutoResizingTextEdit',
    'CheckableComboBox',
    'CheckBoxAndComboBox',
    'CodeEditor',
    'ComboBox',
    'DockWidget',
    'DragDrop',
    'DragItem',
    'Frame',
    'HorizontalScrollArea',
    'IconCheckBox',
    'IconLabel',
    'IconLabelPushButton',
    'Label',
    'LabelAndPushButton',
    'LineEditPassWord',
    'ListWidget',
    'LoadingOverlay',
    'LoadingOverlayApp',
    'LoadingWidget',
    'Menu',
    'MenuTextEditVariables',
    'ResizeLabel',
    'ScrollArea',
    'SideBar',
    'SplitterDock',
    'StackedWidgetDock',
    'StateLabel',
    'TableWidget',
    'TabWidgetDock',
    'TextEditor',
    'TextMasker',
    'TreeWidget',
    'VerticalScrollArea',
    'WebEngineView',
    'Widget',
]
