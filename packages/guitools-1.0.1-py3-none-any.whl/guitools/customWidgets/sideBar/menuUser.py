
from PySide6.QtCore import Signal
from PySide6.QtWidgets import QFrame, QPushButton, QVBoxLayout
from ...style import Styles
from ..menu.menu import Menu
from .utils import ClickFilter
from ..resizeLabel import ResizeLabel

CLICK_FILTER = ClickFilter()

class CustomMenuUser(Menu):
    """
    A custom menu widget for displaying user information and logout functionality.
    """
    
    class CustomWidgetAction(Menu.CustomWidgetAction):
        """
        Custom widget action for the user menu.
        """
        
        class StyleSheet(Styles.Standard.StyleSheet):
            """
            Style sheet for the user menu widget.
            """
            def __init__(self) -> None:
                """
                Initialize the StyleSheet.
                """
                super().__init__()
                         
            def style(self) -> str:
                """
                Generate the style sheet string.
                
                Returns:
                    The CSS style sheet string.
                """
                style = f'''
                {Styles.standard()}
                #FrameFooter {{ border-top: 1px solid {Styles.Color.division.horizontalGradient([0, 0.1, 0.9, 1])}; border-top-right-radius: 0px; border-top-left-radius: 0px;}}
                {Styles.button(prefix="#BtnLogOut").styleSheet(use_class_name=False)}
                '''
                return style

        signalLogOut = Signal()
        
        def __init__(self) -> None:
            """
            Initialize the CustomWidgetAction.
            """
            super().__init__(None)
            mainLayout = QVBoxLayout()
            mainLayout.setContentsMargins(5,5,5,5)
            mainLayout.setSpacing(5)

            self.resizeLabel = ResizeLabel(use_markdown=True)

            frameFooter = QFrame()
            frameFooter.setObjectName("FrameFooter")
            footerLayout = QVBoxLayout(frameFooter)
            footerLayout.setContentsMargins(0, 5, 0, 0)

            logoutButton = QPushButton(" Log-out")
            logoutButton.setObjectName('BtnLogOut')
            logoutButton.clicked.connect(self.signalLogOut.emit)
            footerLayout.addWidget(logoutButton)

            mainLayout.addWidget(self.resizeLabel)
            mainLayout.addWidget(frameFooter)
    
            containerWidget = QFrame()
            containerWidget.setLayout(mainLayout)
            containerWidget.installEventFilter(CLICK_FILTER)
            Styles.setWidgetStyleTheme(self.StyleSheet(), containerWidget)
            self.setDefaultWidget(containerWidget)

        def setDataUser(self, userName: str, userId: str) -> None:
            """
            Set the user data to display in the menu.
            
            Args:
                userName: The name of the user.
                userId: The ID of the user.
            """
            htmlText = f"""
            <ul>
                 <li style='white-space: nowrap;'><span style="font-weight: 600;">Id:</span> {userId}</li>
                 <li><span style="font-weight: 600;">User Name:</span> {userName}</li>
            </ul>
            """
        
            self.resizeLabel.setText(htmlText, True)

    def __init__(self, widget: QPushButton) -> None:
        """
        Initialize the CustomMenuUser.
        
        Args:
            widget: The button widget that triggers the menu.
        """
        super().__init__(widget)
        self.customWidgetAction = self.CustomWidgetAction()
        self.addAction(self.customWidgetAction)
        widget.clicked.connect(self.showTopRight)
        Styles.setWidgetStyleTheme(Styles.menu(), self)
        self.customWidgetAction.signalLogOut.connect(self.close)

    def setDataUser(self, userName: str, userId: str) -> None:
        """
        Set the user data to display in the menu.
        
        Args:
            userName: The name of the user.
            userId: The ID of the user.
        """
        self.customWidgetAction.setDataUser(userName, userId)
