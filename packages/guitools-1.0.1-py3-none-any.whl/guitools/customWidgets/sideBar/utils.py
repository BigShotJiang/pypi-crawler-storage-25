
from typing import Any, Callable, Union, Type, TypeVar
from PySide6.QtCore import QObject, QEvent, QSize, Qt, Signal, SignalInstance
from PySide6.QtWidgets import QPushButton, QWidget, QStackedWidget, QFrame, QLabel, QHBoxLayout, QSizePolicy, QSpacerItem, QMainWindow, QApplication
from ...style import Styles
from ..dockWidget import StackedWidgetDock
from ...thread.pool import Processing
from ...thread.base import WorkerResponse

ViewT = TypeVar('ViewT', bound=object)
ControllerT = TypeVar('ControllerT', bound=object)

def createMvcInstance(
    className: str,
    view: Type[ViewT],
    controller: Type[ControllerT],
    *args: Any, **kwargs: Any
) -> Union[ViewT, ControllerT]:
    """
    Create a dynamic MVC instance by combining a view and controller class.
    
    Args:
        className: The name for the dynamically created class.
        view: The view class to inherit from.
        controller: The controller class to inherit from.
        *args: Positional arguments to pass to the constructor.
        **kwargs: Keyword arguments to pass to the constructor.
    
    Returns:
        An instance of the dynamically created class that inherits from both view and controller.
    """
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        view.__init__(self)
        controller.__init__(self, self, *args, **kwargs)
    
    bases = (view, controller)
    DynamicClass = type(className, bases, {'__init__': __init__})
    return DynamicClass(*args, **kwargs)

class ClickFilter(QObject):
    """
    Event filter that executes an action on mouse button press.
    """
    action: Callable[[], None] | None = None
    
    def eventFilter(self, watchedObject: QObject, event: QEvent) -> bool:
        """
        Filter events to execute action on mouse button press.
        
        Args:
            watchedObject: The object for which the event was generated.
            event: The event that occurred.
        
        Returns:
            True if the event was handled, False otherwise.
        """
        if event.type() == QEvent.Type.MouseButtonPress:
            if self.action:
                self.action()
            return True
        return super().eventFilter(watchedObject, event)
    
class FrameStyleSheet(Styles.WidgetStyleSheet):
    """
    Style sheet for frame widgets in the sidebar.
    """
    def __init__(self, *, selected: bool = False, prefix: str = "") -> None:
        """
        Initialize the FrameStyleSheet.
        
        Args:
            selected: Whether the frame is in selected state. Defaults to False.
            prefix: CSS selector prefix. Defaults to "".
        """
        super().__init__(f"{prefix} QFrame")
        self.frame = self.Frame(selected=selected, prefix=prefix)
        self.widget = self.Widget(selected=selected, prefix=prefix)
        self.hoverWidget = self.HoverWidget(selected=selected, prefix=prefix)
        self.hoverLabel = self.HoverLabel(selected=selected, prefix=prefix)

    class Frame(Styles.StyleSheet):
        """
        Style for the frame element.
        """
        def __init__(self, *, selected: bool = False, prefix: str = "") -> None:
            super().__init__('QFrame', prefix)
            self.textAlign = Styles.Property.TextAlign('left')
            self.font = Styles.Property.FontSegoeUI(12)
            if selected:
                self.color = Styles.Property.Color(Styles.appColor())
                self.backgroundColor = Styles.Property.BackgroundColor(Styles.Color.Menu.Button.hoverBackground.rgba)
                self.border = Styles.Property.Border(radius=6, color=Styles.Color.Menu.Button.hoverBorder.rgba)
            else:
                self.backgroundColor = Styles.Property.BackgroundColor('transparent')
                self.color = Styles.Property.Color(Styles.Color.Reverse.primary)
                self.border = Styles.Property.Border(radius=6, color='transparent')

    class Widget(Styles.StyleSheet):
        """
        Style for widget elements within the frame.
        """
        def __init__(self, *, selected: bool = False, prefix: str = "") -> None:
            """
            Initialize the Widget style.
            
            Args:
                selected: Whether the widget is in selected state. Defaults to False.
                prefix: CSS selector prefix. Defaults to "".
            """
            super().__init__('QFrame QWidget', prefix)
            self.border = Styles.Property.Border(width=0)
            if selected:
                self.color = Styles.Property.Color(Styles.appColor())
                self.backgroundColor = Styles.Property.BackgroundColor(Styles.Color.Menu.Button.hoverBackground.rgba)
            else:
                self.backgroundColor = Styles.Property.BackgroundColor('transparent')
                self.color = Styles.Property.Color(Styles.Color.Reverse.primary)
           
    class HoverWidget(Styles.StyleSheet):
        """
        Style for widget hover state.
        """
        def __init__(self, *, selected: bool = False, prefix: str = "") -> None:
            """
            Initialize the HoverWidget style.
            
            Args:
                selected: Whether the widget is in selected state. Defaults to False.
                prefix: CSS selector prefix. Defaults to "".
            """
            super().__init__('QWidget:hover', prefix)
            if selected:
                self.backgroundColor = Styles.Property.BackgroundColor(Styles.Color.Menu.Button.hoverBackground.rgba)
            else:
                self.backgroundColor = Styles.Property.BackgroundColor(Styles.Color.Menu.Button.pressedBackground.rgba)

    class HoverLabel(Styles.StyleSheet):
        """
        Style for label hover state.
        """
        def __init__(self, *, selected: bool = False, prefix: str = "") -> None:
            """
            Initialize the HoverLabel style.
            
            Args:
                selected: Whether the label is in selected state. Defaults to False.
                prefix: CSS selector prefix. Defaults to "".
            """
            super().__init__('QLabel:hover', prefix)
            if selected:
                self.backgroundColor = Styles.Property.BackgroundColor(Styles.Color.Menu.Button.hoverBackground.rgba)
            else:
                self.backgroundColor = Styles.Property.BackgroundColor(Styles.Color.Menu.Button.pressedBackground.rgba)

class Page(QFrame):
    """
    A page widget for the sidebar navigation.
    
    This widget represents a single page in the sidebar, with support for
    lazy loading, expandable dock widgets, and icon toggling.
    """
    clicked = Signal()
    initialized = Signal()

    def __init__(self, app: QMainWindow, widgetCallable: Callable[[], QWidget] | QWidget, stackedWidget: QStackedWidget, text: str, callableIcon: Callable[[], Any], selectedCallableIcon: Callable[[], Any], iconSize: int = 18, expandable: bool = False) -> None:
        """
        Initialize the Page widget.
        
        Args:
            app: The main window instance.
            widgetCallable: Callable that returns the widget for the page, or a QWidget instance.
            stackedWidget: The QStackedWidget to manage page navigation.
            text: The text label for the page.
            callableIcon: Callable that returns the icon for the unselected state.
            selectedCallableIcon: Callable that returns the icon for the selected state.
            iconSize: The size of the icon. Defaults to 18.
            expandable: Whether the page can be expanded into a dock widget. Defaults to False.
        """
        super().__init__(None)
        self._app: QMainWindow = app
        self.text: str = text
        self.setToolTip(text)
        self.showing: SignalInstance | None = None
        self.selected: bool = False
        self.expandable: bool = expandable
        self.loaded: bool = not isinstance(widgetCallable, Callable)
        self.widgetCallable: Callable[[], QWidget] | QWidget = widgetCallable
        self.stackedWidget = stackedWidget
        self.dynamicPage: QWidget | None = None
        self.callableIcon: Callable[[], Any] = callableIcon
        self.selectedCallableIcon: Callable[[], Any] = selectedCallableIcon
        self.iconSize: int = iconSize
        self._initialArgs: tuple = ()
        self._initialKwargs: dict = {}
        
        pageLayout = QHBoxLayout(self)
        pageLayout.setContentsMargins(0, 0, 0, 0)
        pageLayout.setSpacing(5) 

        self.labelIcon = QLabel()
        self.labelIcon.setFixedSize(38, 36)  
        self.labelIcon.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self.labelIcon.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.labelText = QLabel(text)
        self.labelText.setSizePolicy(QSizePolicy.Policy.MinimumExpanding, QSizePolicy.Policy.Fixed)
        self.labelText.setVisible(False)  

        if self.expandable:
            self.btnMaximize = QPushButton()
            self.btnMaximize.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
            self.btnMaximize.setIconSize(QSize(14, 14))
            self.btnMaximize.setCursor(Qt.CursorShape.PointingHandCursor)
            Styles.setIcon(self.btnMaximize, Styles.Resources.maximize.gray, Styles.Resources.maximize.theme)
            self.btnMaximize.hide()

        self.spacer = QSpacerItem(1, 1, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        pageLayout.addWidget(self.labelIcon, alignment=Qt.AlignmentFlag.AlignLeft)
        pageLayout.addWidget(self.labelText, alignment=Qt.AlignmentFlag.AlignLeft)
        pageLayout.addItem(self.spacer)
        if self.expandable:
            pageLayout.addWidget(self.btnMaximize)

        self.setFixedHeight(36)

        if self.loaded:
            self.dynamicPage = widgetCallable
            self.loadPage()

    def toggleIcon(self, selected: bool) -> None:
        """
        Toggle the icon between selected and unselected states.
        
        Args:
            selected: Whether the page is selected.
        """
        self.selected = selected
        if selected:
            self.labelIcon.setPixmap(self.selectedCallableIcon().toPixmap(self.iconSize))
        else:
            self.labelIcon.setPixmap(self.callableIcon().toPixmap(self.iconSize))

    def detached(self) -> None:
        """
        Handle the event when the page is detached from the sidebar.
        """
        if self.selected:
            self.stackedWidget.setCurrentIndex(0)
      
    def reattached(self) -> None:
        """
        Handle the event when the page is reattached to the sidebar.
        """
        if self.selected:
            self.stackedWidget.setCurrentWidget(self.stackedWidgetDock.page)
        self.btnMaximize.close()

    def loadPage(self, response: WorkerResponse | None = None) -> None:
        """
        Load the page widget, either synchronously or asynchronously.
        
        Args:
            response: Optional worker response if loading asynchronously. Defaults to None.
        """
        if response and not response.success:
            print(response.traceback)
        else:
            try:
                if not self.dynamicPage:
                    if response:
                        self.dynamicPage = createMvcInstance('DynamicPage', *response.result, *self._initialArgs, **self._initialKwargs)
                    else:
                        self.dynamicPage = self.widgetCallable if not isinstance(self.widgetCallable, Callable) else self.widgetCallable()
                if hasattr(self.dynamicPage, 'showing'):
                    if isinstance(self.dynamicPage.showing, SignalInstance):
                        self.showing = self.dynamicPage.showing
                if self.expandable:
                    self.stackedWidgetDock = StackedWidgetDock(stackedWidget=self.stackedWidget, widget=self.dynamicPage, icon=self.selectedCallableIcon(), docTitle=self.labelText.text(),
                                                                        btnMaximize=self.btnMaximize)
                    self.stackedWidgetDock.detached.connect(self.detached)
                    self.stackedWidgetDock.reattached.connect(self.reattached)
                else:
                    self.stackedWidget.addWidget(self.dynamicPage)
                if self.selected:
                    if self.expandable:
                        self.stackedWidgetDock.activate()
                    else:
                        self.stackedWidget.setCurrentWidget(self.dynamicPage)
                if self.dynamicPage:
                    if self.showing:
                        self.showing.emit()
                self.initialized.emit()
            except Exception as ex:
                print(str(ex))
            
    def createPage(self, *args: Any, **kwargs: Any) -> None:
        """
        Create the page widget asynchronously.
        
        Args:
            *args: Positional arguments to pass to the widget constructor.
            **kwargs: Keyword arguments to pass to the widget constructor.
        """
        self._initialArgs = args
        self._initialKwargs = kwargs
        Processing(self.widgetCallable, callback=self.loadPage)
      
    def showPage(self, *args: Any, **kwargs: Any) -> None:
        """
        Show the page widget, loading it if necessary.
        
        Args:
            *args: Positional arguments to pass to the widget constructor.
            **kwargs: Keyword arguments to pass to the widget constructor.
        """
        if not self.loaded:
            self.loaded = True
            self.createPage(*args, **kwargs)
        if self.dynamicPage:
            if self.showing:
                self.showing.emit()
            if self.expandable:
                if self.stackedWidgetDock.isDock():
                    self.stackedWidget.setCurrentIndex(0)
                self.stackedWidgetDock.activate()
            else:
                self.stackedWidget.setCurrentWidget(self.dynamicPage)
        else:
            self.stackedWidget.setCurrentIndex(1)

    def mousePressEvent(self, mouseEvent) -> None:
        """
        Handle mouse press events.
        
        Args:
            mouseEvent: The mouse event.
        """
        self.clicked.emit()
        return super().mousePressEvent(mouseEvent)

    def enterEvent(self, enterEvent) -> None:
        """
        Handle mouse enter events.
        
        Args:
            enterEvent: The enter event.
        """
        if self.expandable:
            if self.labelText.isVisible() and self.loaded and not self.stackedWidgetDock.isDock():
                self.btnMaximize.show()
        return super().enterEvent(enterEvent)
    
    def leaveEvent(self, leaveEvent) -> None:
        """
        Handle mouse leave events.
        
        Args:
            leaveEvent: The leave event.
        """
        if self.expandable:
            self.btnMaximize.close()
        return super().leaveEvent(leaveEvent)