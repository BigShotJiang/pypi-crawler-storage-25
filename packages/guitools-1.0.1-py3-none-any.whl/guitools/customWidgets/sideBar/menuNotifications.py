
from functools import partial
from PySide6.QtWidgets import QFrame, QPushButton, QWidget, QWidgetAction, QTreeWidget, QHBoxLayout, QSizePolicy, QVBoxLayout, QLabel, QHeaderView, QAbstractItemView, QTreeWidgetItem, QMainWindow, QApplication
from ...style import Styles
from ..menu.menu import Menu
from PySide6.QtCore import QSize, Qt,  QCoreApplication,  SignalInstance, QPoint, QTimer, Signal
from ...notification import Notification
from ..editor import TextEditor
import locale
from datetime import datetime
from ..treeWidget import TreeWidget
from .utils import ClickFilter

CLICK_FILTER = ClickFilter()

class CustomMenuNotification(Menu):
    """
    A custom menu widget for displaying and managing notifications.
    """

    class CustomWidgetAction(Menu.CustomWidgetAction):
        """
        Custom widget action for the notification menu.
        """
         
        class CustomTreeWidget(TreeWidget):
            """
            Custom tree widget for displaying notifications in a hierarchical structure.
            """

            class NotificationItem(QFrame):
                """
                Widget representing a single notification item.
                """

                class StyleSheet(Styles.Standard.StyleSheet):
                    """
                    Style sheet for the notification item.
                    """
                    def __init__(self) -> None:
                        """
                        Initialize the StyleSheet.
                        """
                        super().__init__()

                    def style(self) -> str:
                        """
                        Generate the style sheet string.
                        
                        Returns:
                            The CSS style sheet string.
                        """
                        textBrowser = Styles.textBrowser()
                        textBrowser.textBrowser.backgroundColor.value = Styles.Color.primary
                        textBrowser.scrollBarHorizontal.backgroundColor.value = Styles.Color.primary
                        textBrowser.scrollBarVertical.backgroundColor.value = Styles.Color.primary

                        style = f'''
                            #NotificationItem, #NotificationItem QFrame {{background-color: {Styles.Color.primary}}}
                            {textBrowser}
                        '''
                        return style

                def __init__(self, data: Notification.NotificationData, *, parent: QWidget | None = None) -> None:
                    """
                    Initialize the NotificationItem.
                    
                    Args:
                        data: The notification data to display.
                        parent: The parent widget. Defaults to None.
                    """
                    super().__init__(parent=parent)
                    self.setObjectName("NotificationItem")
                    self.data: Notification.NotificationData = data
                    self.guids: list[str] = [data.guid]

                    # ======= HEADER =======
                    headerLayout = QHBoxLayout()
                    headerLayout.setContentsMargins(5, 0, 0, 0)
                    self.btnDelete = QPushButton()
                    self.btnDelete.setSizePolicy(QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed))
                    self.btnDelete.setIconSize(QSize(12, 12))
                    self.btnDelete.setFixedHeight(20)
                    self.btnDelete.setCursor(Qt.CursorShape.PointingHandCursor)
                    Styles.setIcon(self.btnDelete, Styles.Resources.close.gray, Styles.Resources.close.theme)
                    headerLayout.addWidget(self.formatDateLabel(data.date))
                    headerLayout.addWidget(self.btnDelete)

                    # ======= TITLE AREA =======
                    titleLayout = QHBoxLayout()
                    titleLayout.setContentsMargins(0, 0, 0, 0)
                    titleLayout.setSpacing(4)

                    self.titleOriginal: str = data.title
                    self.labelTitle = QLabel(self.titleOriginal)
                    self.labelTitle.setStyleSheet('font: 63 12pt "Segoe UI Semibold"')

                    # Counter label for multiple notifications
                    self.labelCount = QLabel("")
                    self.labelCount.setStyleSheet('font: 9pt "Segoe UI"; color: gray')
                    self.labelCount.setVisible(False)  # Hidden when there is only 1

                    titleLayout.addWidget(self.labelTitle)
                    titleLayout.addWidget(self.labelCount)
                    titleLayout.addStretch()

                    # ======= MAIN LAYOUT =======
                    mainLayout = QVBoxLayout()
                    mainLayout.setContentsMargins(5, 0, 0, 0)
                    mainLayout.setSpacing(0)
                    mainLayout.addLayout(titleLayout)

                    self.viewer = TextEditor(adjustHeight=True, content=data.message, readOnly=True)
                    mainLayout.addWidget(self.viewer)

                    containerLayout = QVBoxLayout()
                    containerLayout.setContentsMargins(5, 5, 5, 5)
                    containerLayout.setSpacing(0)
                    containerLayout.addLayout(headerLayout)
                    containerLayout.addLayout(mainLayout)
                    self.setLayout(containerLayout)

                    self.btnDelete.setVisible(False)
                    Styles.setWidgetStyleTheme(self.StyleSheet(), self)

                # =====================================================
                #  UPDATE METHODS
                # =====================================================
                def addGuid(self, guid: str, date: datetime) -> None:
                    """
                    Add a new GUID and update the counter and date if necessary.
                    
                    Args:
                        guid: The GUID to add.
                        date: The date of the notification.
                    """
                    if guid not in self.guids:
                        self.guids.append(guid)
                        self.updateCountLabel()
                    if date > self.data.date:
                        self.data.date = date
                        self.updateDateLabel()

                def updateCountLabel(self) -> None:
                    """
                    Update the small label with the number of notifications.
                    """
                    count = len(self.guids)
                    if count > 1:
                        self.labelCount.setText(f"(x{count})")
                        self.labelCount.setVisible(True)
                    else:
                        self.labelCount.clear()
                        self.labelCount.setVisible(False)

                # =====================================================
                #  DATE LABEL
                # =====================================================
                def formatDateLabel(self, date: datetime) -> QLabel:
                    """
                    Format and create a date label based on the notification date.
                    
                    Args:
                        date: The date to format.
                    
                    Returns:
                        A QLabel with the formatted date.
                    """
                    locale.setlocale(locale.LC_TIME)
                    today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
                    formattedDate = date.replace(hour=0, minute=0, second=0, microsecond=0)
                    daysDelta = (today - formattedDate).days

                    if daysDelta == 0:
                        self.labelDate = QLabel(date.strftime("%H:%M"))
                    elif daysDelta == 1:
                        self.labelDate = QLabel("Yesterday")
                    elif 1 < daysDelta <= 7:
                        self.labelDate = QLabel(date.strftime("%A"))
                    else:
                        self.labelDate = QLabel(date.strftime("%Y-%m-%d"))

                    self.labelDate.setStyleSheet('font: 10pt "Segoe UI"')
                    self.labelDate.setFixedHeight(20)
                    return self.labelDate

                def updateDateLabel(self) -> None:
                    """
                    Update the date label with the current notification date.
                    """
                    locale.setlocale(locale.LC_TIME)
                    today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
                    formattedDate = self.data.date.replace(hour=0, minute=0, second=0, microsecond=0)
                    daysDelta = (today - formattedDate).days

                    if daysDelta == 0:
                        self.labelDate.setText(self.data.date.strftime("%H:%M"))
                    elif daysDelta == 1:
                        self.labelDate.setText("Yesterday")
                    elif 1 < daysDelta <= 7:
                        self.labelDate.setText(self.data.date.strftime("%A"))
                    else:
                        self.labelDate.setText(self.data.date.strftime("%Y-%m-%d"))

                # =====================================================
                #  HOVER EVENTS
                # =====================================================
                def enterEvent(self, enterEvent) -> None:
                    """
                    Handle mouse enter events.
                    
                    Args:
                        enterEvent: The enter event.
                    """
                    self.btnDelete.setVisible(True)
                    super().enterEvent(enterEvent)

                def leaveEvent(self, leaveEvent) -> None:
                    """
                    Handle mouse leave events.
                    
                    Args:
                        leaveEvent: The leave event.
                    """
                    self.btnDelete.setVisible(False)
                    super().leaveEvent(leaveEvent)

            signalDelete = Signal(object)
            
            def __init__(self, signalNotification: SignalInstance, signalDeleteNotification: SignalInstance, *, parent: QWidget | None = None) -> None:
                """
                Initialize the CustomTreeWidget.
                
                Args:
                    signalNotification: Signal instance for new notifications.
                    signalDeleteNotification: Signal instance for deleted notifications.
                    parent: The parent widget. Defaults to None.
                """
                super().__init__(scrollAmount=40, parent=parent)
                self.itemClicked.connect(self.toggleExpand)
                Notification.signalNotification = signalNotification
                Notification.signalNotification.connect(self.newNotification)
                self.signalDeleteNotification = signalDeleteNotification
                self.signalDelete.connect(self.deleteNotification)
                self.timer = QTimer()
                self.timer.timeout.connect(self.updateDates)
                thirtyMinutesMs = 30 * 60 * 1000
                self.timer.start(thirtyMinutesMs)
                self.iconCategory = Styles.Resources.category.gray()
                self.setColumnCount(1)
                treeHeader = self.header()
                treeHeader.setVisible(False)
                treeHeader.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
                self.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
                self.setHorizontalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
                self.setVerticalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
                self.setSizePolicy(QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding))

            def updateDates(self) -> None:
                """
                Update date labels for all notification items.
                """
                notificationItems = self.getAllNotificationItems()
                for notificationItem in notificationItems:
                    notificationItem.updateDateLabel()

            def getAllNotificationItems(self) -> list['CustomMenuNotification.CustomWidgetAction.CustomTreeWidget.NotificationItem']:
                """
                Get all notification items from the tree widget.
                
                Returns:
                    A list of all NotificationItem instances in the tree.
                """
                notificationItems: list[CustomMenuNotification.CustomWidgetAction.CustomTreeWidget.NotificationItem] = []

                # Iterate through all top-level items
                for i in range(self.topLevelItemCount()):
                    topLevelItem = self.topLevelItem(i)

                    # Iterate through all children of the top-level item
                    for j in range(topLevelItem.childCount()):
                        childItem = topLevelItem.child(j)

                        # Get the widget associated with column 0
                        itemWidget = self.itemWidget(childItem, 0)
                        if itemWidget:
                            # Search for NotificationItem within the QFrame
                            for k in range(itemWidget.layout().count()):
                                childWidget = itemWidget.layout().itemAt(k).widget()
                                if isinstance(childWidget, self.NotificationItem):
                                    notificationItems.append(childWidget)

                return notificationItems

            def newNotification(self, data: Notification.NotificationData) -> None:
                """
                Add a new notification to the tree widget.
                
                Args:
                    data: The notification data to add.
                """
                localItem: QTreeWidgetItem | None = None
                for i in range(self.topLevelItemCount()):
                    topLevelItem = self.topLevelItem(i)
                    if topLevelItem:
                        if topLevelItem.text(0) == data.local:
                            localItem = topLevelItem
                if not localItem:
                    localItem = self.addItemLocal(data.local)

                self.addItemWidget(localItem, data)
                localItem.setExpanded(True)

            def deleteNotification(self, item: QTreeWidgetItem) -> None:
                """
                Delete a notification item.
                
                Args:
                    item: The tree widget item to delete.
                """
                parentItem = item.parent()
                itemWidget = self.itemWidget(item, 0)
                if not itemWidget:
                    return

                notificationWidget = None
                for i in range(itemWidget.layout().count()):
                    childWidget = itemWidget.layout().itemAt(i).widget()
                    if isinstance(childWidget, self.NotificationItem):
                        notificationWidget = childWidget
                        break

                if notificationWidget:
                    self.removeItemWidget(item, 0)
                    itemWidget.deleteLater()

                    if parentItem:
                        parentItem.removeChild(item)
                        if parentItem.childCount() == 0:
                            topIndex = self.indexOfTopLevelItem(parentItem)
                            if topIndex != -1:
                                self.takeTopLevelItem(topIndex)

                    self.signalDeleteNotification.emit(notificationWidget.guids)

            def clear(self) -> None:
                """
                Clear all items from the tree widget recursively.
                """
                for i in range(self.topLevelItemCount() - 1, -1, -1): 
                    topLevelItem = self.topLevelItem(i)
                    self.removeItemRecursive(topLevelItem)
                return super().clear()
            
            def removeItemRecursive(self, item: QTreeWidgetItem) -> None:
                """
                Recursively remove an item and all its children.
                
                Args:
                    item: The tree widget item to remove.
                """
                for i in range(item.childCount() - 1, -1, -1):  
                    childItem = item.child(i)
                    self.removeItemRecursive(childItem)
                
                itemWidget = self.itemWidget(item, 0)
                if itemWidget:
                    self.removeItemWidget(item, 0)
                    itemWidget.deleteLater()
                
                parentItem = item.parent()
                if parentItem:
                    parentItem.removeChild(item)
                else:
                    topIndex = self.indexOfTopLevelItem(item)
                    if topIndex != -1:
                        self.takeTopLevelItem(topIndex)

            def load(self, notifications: list[Notification.NotificationData]) -> None:
                """
                Load notifications into the tree widget, grouped by location.
                
                Args:
                    notifications: List of notification data to load.
                """
                notificationsByLocation: dict[str, list[Notification.NotificationData]] = {}
                for notificationData in notifications:
                    locationList: list[Notification.NotificationData] = notificationsByLocation.get(notificationData.local, [])
                    locationList.append(notificationData)
                    notificationsByLocation[notificationData.local] = locationList

                for location, notificationList in notificationsByLocation.items():
                    locationItem = self.addItemLocal(location)
                    for notificationData in notificationList:
                        self.addItemWidget(locationItem, notificationData)
                    locationItem.setExpanded(True)

            def addItemWidget(self, itemLocal: QTreeWidgetItem, data: Notification.NotificationData) -> None:
                """
                Add a notification widget to a location item, or merge with existing if message matches.
                
                Args:
                    itemLocal: The location item to add the notification to.
                    data: The notification data to add.
                """
                existingItem = None
                for j in range(itemLocal.childCount()):
                    childItem = itemLocal.child(j)
                    childWidget = self.itemWidget(childItem, 0)
                    if childWidget:
                        for k in range(childWidget.layout().count()):
                            nestedWidget = childWidget.layout().itemAt(k).widget()
                            if isinstance(nestedWidget, self.NotificationItem):
                                # If the message is equal, merge
                                if nestedWidget.data.message.strip() == data.message.strip():
                                    existingItem = (childItem, nestedWidget)
                                    break
                    if existingItem:
                        break

                if existingItem:
                    _, notificationWidget = existingItem
                    notificationWidget.addGuid(data.guid, data.date)
                    return  # Don't create new item

                # Create new item if no match found
                notificationItem = QTreeWidgetItem(itemLocal)
                itemFrame = QFrame()
                itemFrame.setObjectName('FrameItem')
                itemLayout = QHBoxLayout(itemFrame)
                itemLayout.setContentsMargins(0, 5, 5, 5)
                notificationWidget = self.NotificationItem(data)
                itemLayout.addWidget(notificationWidget)

                notificationWidget.btnDelete.clicked.connect(
                    partial(self.signalDelete.emit, notificationItem)
                )

                self.setItemWidget(notificationItem, 0, itemFrame)


            def toggleExpand(self, item: QTreeWidgetItem) -> None:
                """
                Toggle the expanded state of a location item.
                
                Args:
                    item: The tree widget item to toggle.
                """
                isLocation: bool = item.data(0, 1000)
                if isLocation:
                        item.setExpanded(not item.isExpanded())

            def addItemLocal(self, local: str) -> QTreeWidgetItem:
                """
                Add a location item to the tree widget.
                
                Args:
                    local: The location name.
                
                Returns:
                    The created location item.
                """
                categoryItem = QTreeWidgetItem([local])
                self.addTopLevelItem(categoryItem)
                categoryItem.setData(0, 1000, True)
                categoryItem.setIcon(0, self.iconCategory)
                categoryItem.setFlags(categoryItem.flags() & ~Qt.ItemFlag.ItemIsSelectable)
                return categoryItem

        class StyleSheet(Styles.Standard.StyleSheet):
            """
            Style sheet for the notification menu widget.
            """
            def __init__(self) -> None:
                """
                Initialize the StyleSheet.
                """
                super().__init__()

            def style(self) -> str:
                """
                Generate the style sheet string.
                
                Returns:
                    The CSS style sheet string.
                """
                style = f'''
                    {Styles.standard()}
                    #LabelTitle {{font: 63 15pt "Segoe UI Semibold"; background-color: {Styles.Color.Menu.background}}}
                    #CustomActionNotification, #FrameItem, #FrameHeader {{background-color: {Styles.Color.Menu.background}}}
                    #FrameHeader {{border-radius: 0px; border-bottom: 1px solid {Styles.Color.division.horizontalGradient([0, 0.3, 0.7, 1])}}}
                    #CustomActionNotification {{border-radius: 0px;}}
                    {Styles.treeView(singleBackgroundColor=Styles.Color.Menu.background)}
                '''

                return style
               
        def __init__(self, signalNotification: SignalInstance, signalDeleteNotification: SignalInstance, signalClearNotification: SignalInstance, *, parent: QWidget | None = None) -> None:
            """
            Initialize the CustomWidgetAction.
            
            Args:
                signalNotification: Signal instance for new notifications.
                signalDeleteNotification: Signal instance for deleted notifications.
                signalClearNotification: Signal instance for clearing all notifications.
                parent: The parent widget. Defaults to None.
            """
            super().__init__(parent=parent)
            containerWidget = QFrame()
            containerWidget.installEventFilter(CLICK_FILTER)
            containerWidget.setObjectName("CustomActionNotification")
            titleLabel = QLabel()
            titleLabel.setText("Notifications")
            titleLabel.setObjectName("LabelTitle")
            clearButton = QPushButton()
            clearButton.setToolTip('Clear all notifications')
            clearButton.setSizePolicy(QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed))
            clearButton.clicked.connect(signalClearNotification.emit)
            clearButton.setCursor(Qt.CursorShape.PointingHandCursor)
            Styles.setIcon(clearButton, Styles.Resources.clear.gray, Styles.Resources.clear.theme)
            headerFrame = QFrame()
            headerFrame.setObjectName('FrameHeader')
            headerLayout = QHBoxLayout(headerFrame)
            headerLayout.addWidget(titleLabel)
            headerLayout.addWidget(clearButton)
            headerLayout.setContentsMargins(5,5,5,5)
            
            mainLayout = QVBoxLayout(containerWidget)
            mainLayout.setContentsMargins(0,0,0,0)
            mainLayout.setSpacing(0)
            mainLayout.addWidget(headerFrame)

            self.treeWidget = self.CustomTreeWidget(signalNotification, signalDeleteNotification)
            signalClearNotification.connect(self.treeWidget.clear)
            mainLayout.addWidget(self.treeWidget)
            Styles.setWidgetStyleTheme(self.StyleSheet(), containerWidget)
            self.setDefaultWidget(containerWidget)

        def load(self, notifications: list[Notification.NotificationData]) -> None:
            """
            Load notifications into the tree widget.
            
            Args:
                notifications: List of notification data to load.
            """
            self.treeWidget.load(notifications)

    def __init__(self, widget: QPushButton, signalNotification: SignalInstance, signalDeleteNotification: SignalInstance, signalClearNotification: SignalInstance, *, parent: QWidget | None = None) -> None:
        """
        Initialize the CustomMenuNotification.
        
        Args:
            widget: The button widget that triggers the menu.
            signalNotification: Signal instance for new notifications.
            signalDeleteNotification: Signal instance for deleted notifications.
            signalClearNotification: Signal instance for clearing all notifications.
            parent: The parent widget. Defaults to None.
        """
        super().__init__(widget, parent)
        self.customWidgetAction = self.CustomWidgetAction(signalNotification, signalDeleteNotification, signalClearNotification)
        self.addAction(self.customWidgetAction)

        widget.clicked.connect(self.showRight)
        menuStyles = Styles.menu()
        menuStyles.item.margin = None
        menuStyles.item.padding = None
        menuStyles.menu.backgroundColor.value = Styles.Color.Menu.background
        menuStyles.menu.border = Styles.Property.Border(color=Styles.Color.division, left=0, bottom=0, top=0, right=1, radius=0)
        Styles.setWidgetStyleTheme(menuStyles, self)

    def setShowRight(self) -> None:
        """
        Set the menu to show on the right side of the widget.
        """
        self.widget.clicked.disconnect()
        self.widget.clicked.connect(self.showRight)

    def setShowOverWidget(self, targetWidget: QWidget, right: bool = False) -> None:
        """
        Set the menu to show over a target widget.
        
        Args:
            targetWidget: The widget to show the menu over.
            right: Whether to align the menu to the right. Defaults to False.
        """
        self.widget.clicked.disconnect()
        self.widget.clicked.connect(partial(self.showOverWidget, targetWidget, right))
    
    def load(self, notifications: list[Notification.NotificationData]) -> None:
        """
        Load notifications into the menu.
        
        Args:
            notifications: List of notification data to load.
        """
        self.customWidgetAction.load(notifications)

    def execute(self, point: QPoint, width: int, height: int) -> None:
        """
        Execute the menu at the specified position and size.
        
        Args:
            point: The position to show the menu.
            width: The width of the menu.
            height: The height of the menu.
        """
        self.setFixedSize(0, 0)
        self.move(QPoint(-1, -1))
        self.show()
        QCoreApplication.processEvents()
        self.close()
        self.setFixedSize(width, height)
        self.exec(point)

    def showRight(self) -> None:
        """
        Show the menu to the right of the widget.
        """
        QCoreApplication.processEvents()
        # Get the geometry of the target widget
        parentWidgetGeometry = self.widget.parentWidget().geometry()
        parentWidgetGlobalPos = self.widget.parentWidget().mapToGlobal(parentWidgetGeometry.topLeft())  # Convert to global coordinates
        menuX = parentWidgetGlobalPos.x() + self.widget.geometry().right() 
        menuY = parentWidgetGlobalPos.y() 

        parentWidgetHeight = parentWidgetGeometry.height()

        menuWidth = 600
        menuHeight = parentWidgetHeight
        menuHeight = menuHeight - 1
        positionX = menuX + 12
        positionY = menuY - 1

        # Adjust size of the default widget if the menu has a single QWidgetAction
        menuActions = self.actions()
        if len(menuActions) == 1:
            menuAction = menuActions[0]
            if isinstance(menuAction, QWidgetAction):
                menuAction.defaultWidget().setFixedSize(menuWidth - 3, menuHeight)

        # Show the menu
        self.execute(QPoint(positionX, positionY), menuWidth, menuHeight)

    def mainWindow(self) -> QMainWindow | None:
        """
        Get the main window instance.
        
        Returns:
            The QMainWindow instance, or None if not found.
        """
        application = QApplication.instance()
    
        if not application:
            return None
        
        if isinstance(application, QMainWindow):
            return application
        
        for widget in application.topLevelWidgets():
            if isinstance(widget, QMainWindow):
                return widget
        return None
   
    def showOverWidget(self, targetWidget: QWidget, right: bool = False) -> None:
        """
        Show the menu over a target widget.
        
        Args:
            targetWidget: The widget to show the menu over.
            right: Whether to align the menu to the right. Defaults to False.
        """
        QCoreApplication.processEvents()
    
        targetWidgetGeometry = targetWidget.geometry()
        targetWidgetGlobalPos = targetWidget.mapToGlobal(targetWidgetGeometry.topLeft()) 
        targetWidgetX = targetWidgetGlobalPos.x()
        targetWidgetY = targetWidgetGlobalPos.y()
        targetWidgetHeight = targetWidgetGeometry.height()
        targetWidgetWidth = targetWidgetGeometry.width()

        mainWindowInstance = self.mainWindow()
        currentScreen = QApplication.screenAt(mainWindowInstance.geometry().center())
        
        if currentScreen is None:
            currentScreen = QApplication.primaryScreen()

        screenGeometry = currentScreen.geometry()

        screenWidth = screenGeometry.width()
        menuWidth = max(600, screenWidth // 2)
        menuWidth = min(menuWidth, targetWidget.width() - 20)
        menuHeight = max(0, targetWidgetHeight - (2 * 10))
        
        positionY = targetWidgetY + 10
        if right:
            positionX = targetWidgetX + targetWidgetWidth - menuWidth - 10
        else:
            positionX = targetWidgetX + 10
      
        menuActions = self.actions()
        if len(menuActions) == 1:
            menuAction = menuActions[0]
            if isinstance(menuAction, QWidgetAction):
                menuAction.defaultWidget().setFixedSize(menuWidth - 2, menuHeight - 2)

        self.execute(QPoint(positionX, positionY), menuWidth, menuHeight)
