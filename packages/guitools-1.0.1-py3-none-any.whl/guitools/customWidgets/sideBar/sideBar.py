
from functools import partial
from .view import Ui_FrameSideBar
from PySide6.QtWidgets import QFrame, QWidget, QLabel, QStackedWidget, QVBoxLayout, QMainWindow, QApplication
from ...style import Styles
from ...animation import Animation
from PySide6.QtCore import QSize, Qt, Signal, QTimer
from PySide6.QtGui import QCursor, QIcon
from typing import Callable, Any
from ...notification import Notification
from .utils import ClickFilter, Page, FrameStyleSheet
from ..loadingOverlay import LoadingWidget

CLICK_FILTER = ClickFilter()

from .menuNotifications import CustomMenuNotification
from .menuUser import CustomMenuUser

class SideBar(Ui_FrameSideBar, QFrame):
    """
    A sidebar widget that provides navigation functionality with expandable/collapsible pages.
    
    This widget displays a sidebar with pages, notifications, and user menu options.
    It supports toggling between expanded and collapsed states.
    """
    
    class WidgetStyleSheet(Styles.WidgetStyleSheet):
        """
        Custom style sheet for the sidebar widget.
        """
        def __init__(self, action: Callable[[], None]) -> None:
            """
            Initialize the WidgetStyleSheet.
            
            Args:
                action: Callback function to execute when style is applied.
            """
            super().__init__()
            self.action: Callable[[], None] = action

        def style(self) -> str:
            """
            Generate the style sheet string.
            
            Returns:
                The CSS style sheet string.
            """
            self.action()
            style = f'''
                #frame_logo, #frame_separator {{ border-bottom: 1px solid {Styles.Color.division}; border-radius: 0px;}}
                {Styles.button(transparent=True, hover=False, prefix="#btn_notifications, #btn_user").styleSheet()}
            '''
            return f'{style}'

    signalNotification = Signal(Notification.NotificationData)
    signalDeleteNotification = Signal(object)
    signalClearNotification = Signal()
    
    def __init__(self, parent: QWidget, stackedWidget: QStackedWidget, callableIconPageStandard: Callable[[], Any], displayNotifications: bool = True) -> None:
        """
        Initialize the SideBar.
        
        Args:
            parent: The parent widget to contain the sidebar.
            stackedWidget: The QStackedWidget to manage page navigation.
            callableIconPageStandard: Callable that returns the icon for the standard page.
            displayNotifications: Whether to display the notifications button. Defaults to True.
        """
        super().__init__(None)
        super().setupUi(self)
        self.app = self.mainWindow()
        self.appTitle: str = self.app.windowTitle()
        self.opened: bool = False
        self.userName: str = "User"
        self.widgetParent: QWidget = parent
        self.widgetParent.layout().addWidget(self)
        self.stackedWidget = stackedWidget
        self.whideIcon: QIcon | None = None
        self.whideIconSize = QSize(40, 40)
        self.icon: QIcon | None = None
        self.iconSize = QSize(40, 40)
        self.pages: list[Page] = []
        self._labelsSection: list[QLabel] = []
        
        self.label_logo.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self.label_logo.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.label_text_logo.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.btn_toggle.setIcon(Styles.Resources.separatorLeft.gray())
        self.btn_toggle.clicked.connect(self.toggle)
        
        self.btn_user.close()
        self.btn_notifications.setVisible(displayNotifications)
        if displayNotifications:
            Styles.setIcon(self.btn_notifications, Styles.Resources.notification.gray, Styles.Resources.notification.select)
            self.menuNotification = CustomMenuNotification(self.btn_notifications, self.signalNotification, self.signalDeleteNotification, self.signalClearNotification)

        self.widgetStandard = QLabel()
        self.widgetStandard.setPixmap(callableIconPageStandard().toPixmap(300))
        self.widgetStandard.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.stackedWidget.addWidget(self.widgetStandard)
        self.stackedWidget.setCurrentWidget(self.widgetStandard)

        self.widgetLoading = LoadingWidget(self.stackedWidget)
        self.stackedWidget.addWidget(self.widgetLoading)
   
        Styles.setWidgetStyleTheme(self.WidgetStyleSheet(self.updateBtnsStyles), self)

    def setUserData(self, userName: str, userId: str) -> None:
        """
        Set user data and display the user menu button.
        
        Args:
            userName: The name of the user.
            userId: The ID of the user.
        """
        self.btn_user.show()
        Styles.setIcon(self.btn_user, Styles.Resources.user.gray, Styles.Resources.user.select)
        self.menuUser = CustomMenuUser(self.btn_user)
        self.userName = userName
        self.menuUser.setDataUser(userName, userId)

    def setIcon(self, icon: QIcon, sizeW: int = 40, sizeH: int = 40) -> None:
        """
        Set the sidebar icon.
        
        Args:
            icon: The icon to display.
            sizeW: The width of the icon. Defaults to 40.
            sizeH: The height of the icon. Defaults to 40.
        """
        self.icon = icon
        self.iconSize = QSize(sizeW, sizeH)
        self.label_logo.setPixmap(icon.pixmap(self.iconSize))
      
    def setWhideIcon(self, icon: QIcon, sizeW: int = 40, sizeH: int = 40) -> None:
        """
        Set the wide icon (displayed when sidebar is expanded).
        
        Args:
            icon: The wide icon to display when expanded.
            sizeW: The width of the icon. Defaults to 40.
            sizeH: The height of the icon. Defaults to 40.
        """
        self.whideIcon = icon
        self.whideIconSize = QSize(sizeW, sizeH)
        
    def setIconAction(self, action: Callable[[], None]) -> None:
        """
        Set the action to execute when the logo or text logo is clicked.
        
        Args:
            action: The callback function to execute on click.
        """
        logoClickFilter = ClickFilter(self.label_logo)
        logoClickFilter.action = action
        self.label_logo.installEventFilter(logoClickFilter)
        textLogoClickFilter = ClickFilter(self.label_text_logo)
        textLogoClickFilter.action = action
        self.label_text_logo.installEventFilter(textLogoClickFilter)

    def setTitle(self, title: str) -> None:
        """
        Set the sidebar title text.
        
        Args:
            title: The title text to display.
        """
        self.label_text_logo.setText(title)

    def addPage(self, callablePage: Callable[[], QWidget], text: str, callableIcon: Callable[[], Any], selectedCallableIcon: Callable[[], Any], iconSize: int = 18, expandable: bool = False) -> Page:
        """
        Add a new page to the sidebar.
        
        Args:
            callablePage: Callable that returns the widget for the page, or a QWidget instance.
            text: The text label for the page.
            callableIcon: Callable that returns the icon for the unselected state.
            selectedCallableIcon: Callable that returns the icon for the selected state.
            iconSize: The size of the icon. Defaults to 18.
            expandable: Whether the page can be expanded into a dock widget. Defaults to False.
        
        Returns:
            The created Page instance.
        """
        styleNormal = FrameStyleSheet()
        page = Page(self.app, callablePage, self.stackedWidget, text, callableIcon, selectedCallableIcon, iconSize, expandable)
        page.setStyleSheet(styleNormal.styleSheet())
        page.clicked.connect(partial(self.select, pageSelect=page))
        self.frame_side_bar_btns.layout().addWidget(page)
        self.pages.append(page)
        return page
    
    def mainWindow(self) -> QMainWindow | None:
        """
        Get the main window instance.
        
        Returns:
            The QMainWindow instance, or None if not found.
        """
        application = QApplication.instance()
    
        if not application:
            return None
        
        if isinstance(application, QMainWindow):
            return application
        
        for widget in application.topLevelWidgets():
            if isinstance(widget, QMainWindow):
                return widget
        return None
    
    def addSeparator(self) -> None:
        """
        Add a visual separator to the sidebar.
        """
        separatorFrame = QFrame()
        separatorLayout = QVBoxLayout(separatorFrame)
        separatorLayout.setContentsMargins(0, 5, 0, 5)
        separatorLine = QFrame()
        separatorLine.setObjectName('frame_separator')
        separatorLine.setFixedHeight(1)
        separatorLayout.addWidget(separatorLine)
        self.frame_side_bar_btns.layout().addWidget(separatorFrame)

    def addSection(self, title: str) -> None:
        """
        Add a section title to the sidebar.
        
        Args:
            title: The title text for the section.
        """
        titleLabel = QLabel(title)
        if self.opened:
            titleLabel.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        else:
            titleLabel.setAlignment(Qt.AlignmentFlag.AlignCenter)
        titleLabel.setStyleSheet('font-size: 10px;')
        self.frame_side_bar_btns.layout().addWidget(titleLabel)
        self._labelsSection.append(titleLabel)

    def toggle(self) -> None:
        """
        Toggle the sidebar between expanded and collapsed states.
        """
        if self.opened:
            Animation.minimumWidth(self.widgetParent, 250, 60)
            if self.whideIcon:
                self.label_logo.setMinimumWidth(40)
                self.label_logo.setPixmap(self.icon.pixmap(self.iconSize))
            QTimer.singleShot(500, self.toggleAlignTexts)
            for page in self.pages:
                page.setToolTip(page.text)
        else:
            styleSelected = FrameStyleSheet(selected=True)
            styleNormal = FrameStyleSheet()
            Animation.minimumWidth(self.widgetParent, 60, 250)
            for page in self.pages:
                if page.selected:
                    page.setStyleSheet(styleSelected.styleSheet())
                else:
                    page.setStyleSheet(styleNormal.styleSheet())

            buttonToggleStyle = Styles.buttonMenu()
            buttonToggleStyle.button.font.size = 10
            buttonToggleStyle.button.color.value = Styles.Color.Reverse.primary.fromRgba(200)

            self.btn_toggle.setStyleSheet(buttonToggleStyle.styleSheet())
            self.btn_toggle.setText("  Hide side panel")
            self.btn_notifications.setStyleSheet(buttonToggleStyle.styleSheet())
            self.btn_notifications.setText("  Notifications")
            self.btn_user.setStyleSheet(buttonToggleStyle.styleSheet())
            self.btn_user.setText(f"  {self.userName}")
            if self.whideIcon:
                self.label_logo.setMinimumWidth(230)
                self.label_logo.setPixmap(self.whideIcon.pixmap(self.whideIconSize))
            for label in self._labelsSection:
                label.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
            for page in self.pages:
                page.setToolTip("")
        self.opened = not self.opened 
        QTimer.singleShot(200, self.toggleVisibleTexts)

    def toggleAlignTexts(self) -> None:
        """
        Align section labels to center when sidebar is collapsed.
        """
        for label in self._labelsSection:
            label.setAlignment(Qt.AlignmentFlag.AlignCenter)

    def toggleVisibleTexts(self) -> None:
        """
        Toggle visibility of page text labels based on sidebar state.
        """
        for page in self.pages:
            page.labelText.setVisible(self.opened)

    def select(self, pageSelect: Page, *args: Any) -> None:
        """
        Select a page and update the UI accordingly.
        
        Args:
            pageSelect: The page to select.
            *args: Additional arguments to pass to the page's showPage method.
        """
        if not self.opened:
            self.btn_toggle.setText("")
            self.btn_notifications.setText("")
            self.btn_user.setText("")

        self.app.setWindowTitle(f'{self.appTitle} | {pageSelect.text}')

        styleSelected = FrameStyleSheet(selected=True)
        styleNormal = FrameStyleSheet()

        buttonToggleStyle = Styles.buttonMenu(padding=self.opened)
        buttonToggleStyle.button.font.size = 10
        buttonToggleStyle.button.color.value = Styles.Color.Reverse.primary.fromRgba(200)

        self.btn_toggle.setStyleSheet(buttonToggleStyle.styleSheet())
        self.btn_notifications.setStyleSheet(buttonToggleStyle.styleSheet())
        self.btn_user.setStyleSheet(buttonToggleStyle.styleSheet())
        for page in self.pages:
            if pageSelect == page:
                page.setStyleSheet(styleSelected.styleSheet())
                page.toggleIcon(True)
            else:
                page.toggleIcon(False)
                page.setStyleSheet(styleNormal.styleSheet())
        pageSelect.showPage(*args)
                
    def updateBtnsStyles(self) -> None:
        """
        Update button styles based on current state.
        """
        styleSelected = FrameStyleSheet(selected=True)
        styleNormal = FrameStyleSheet()

        buttonToggleStyle = Styles.buttonMenu(padding=self.opened)
        buttonToggleStyle.button.font.size = 10
        buttonToggleStyle.button.color.value = Styles.Color.Reverse.primary.fromRgba(200)

        self.btn_toggle.setStyleSheet(buttonToggleStyle.styleSheet())
        self.btn_notifications.setStyleSheet(buttonToggleStyle.styleSheet())
        self.btn_user.setStyleSheet(buttonToggleStyle.styleSheet())
        for page in self.pages:
            if page.selected:
                page.toggleIcon(True)
                page.setStyleSheet(styleSelected.styleSheet())
            else:
                page.toggleIcon(False)
                page.setStyleSheet(styleNormal.styleSheet())


