

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QLineEdit, QPushButton, QStyle
from PySide6.QtGui import QResizeEvent
from ...style import Styles

class LineEditPassWord(QLineEdit):
    """
    Password line edit with toggle visibility button.
    
    This widget extends QLineEdit to provide a password input field with
    a button that allows users to toggle between showing and hiding the password.
    """
    
    def __init__(self) -> None:
        """
        Initialize the LineEditPassWord widget.
        """
        super().__init__()

        # Icons for password visibility toggle
        self.iconEyeSlah = Styles.Resources.eyeSlah.gray()  # Hidden icon
        self.iconEye = Styles.Resources.eye.gray()            # Visible icon

        # Default mode: hidden password
        self.setEchoMode(QLineEdit.EchoMode.Password)
        self.isPasswordVisible: bool = False

        # Create button inside QLineEdit
        self.button = QPushButton(self)
        self.button.setIcon(self.iconEyeSlah)
        self.button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.button.setFlat(True)
        self.button.setToolTip("Show password")
        self.button.clicked.connect(self.togglePasswordVisibility)

        # Set internal margins
        self.frameWidth: int = self.style().pixelMetric(QStyle.PixelMetric.PM_DefaultFrameWidth)
        self.updateButtonPosition()

    def resizeEvent(self, resizeEvent: QResizeEvent) -> None:
        """
        Keep the button aligned and matching QLineEdit height.
        
        Args:
            resizeEvent: The resize event containing information about the resize.
        """
        self.updateButtonPosition()
        super().resizeEvent(resizeEvent)

    def updateButtonPosition(self) -> None:
        """
        Reposition and resize the button to match the line edit height.
        """
        buttonHeight = self.height() - 2
        self.button.setFixedSize(buttonHeight, buttonHeight)
        self.setTextMargins(0, 0, buttonHeight + self.frameWidth, 0)
        self.button.move(self.width() - buttonHeight - self.frameWidth, (self.height() - buttonHeight) // 2)

    def togglePasswordVisibility(self) -> None:
        """
        Toggle password visibility between hidden and visible.
        
        Changes the echo mode and updates the button icon and tooltip accordingly.
        """
        if self.isPasswordVisible:
            # Hide password
            self.setEchoMode(QLineEdit.EchoMode.Password)
            self.button.setIcon(self.iconEyeSlah)
            self.button.setToolTip("Show password")
        else:
            # Show password
            self.setEchoMode(QLineEdit.EchoMode.Normal)
            self.button.setIcon(self.iconEye)
            self.button.setToolTip("Hide password")

        self.isPasswordVisible = not self.isPasswordVisible

