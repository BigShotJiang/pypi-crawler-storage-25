

from PySide6.QtWidgets import QLineEdit
from PySide6.QtGui import QFocusEvent

class TextMasker:
    """
    Generic class for masking text in QLineEdit, showing only the last characters when not in focus.
    
    This class provides functionality to mask sensitive text (like passwords or tokens)
    by showing only the last N characters when the line edit loses focus, and showing
    the full text when it gains focus.
    """
    
    def __init__(self, lineEdit: QLineEdit, text: str = '', lastVisible: int = 5, maskedChar: str = '*') -> None:
        """
        Initialize the TextMasker.
        
        Args:
            lineEdit: The QLineEdit widget to apply masking to.
            text: Initial text to mask. Defaults to empty string.
            lastVisible: Number of characters to keep visible at the end.
                        Defaults to 5.
            maskedChar: Character to use for masking. Defaults to '*'.
        """
        self.lineEdit: QLineEdit = lineEdit
        self.originalText: str = text
        self.lastVisible: int = lastVisible
        self.maskedChar: str = maskedChar

        if text.strip():
            self.setMaskedText()

        # Connect focus events
        self.lineEdit.focusInEvent = self.onFocusInEvent
        self.lineEdit.focusOutEvent = self.onFocusOutEvent
        # Use textEdited instead of textChanged
        self.lineEdit.textEdited.connect(self.onUpdateText)

    def maskedText(self, text: str) -> str:
        """
        Generate the masked text.
        
        Args:
            text: The text to mask.
        
        Returns:
            The masked text string showing only the last N characters.
        """
        if len(text) > self.lastVisible:
            return self.maskedChar * (len(text) - self.lastVisible) + text[-self.lastVisible:]
        return text

    def updateText(self, newText: str) -> None:
        """
        Update the original text.
        
        Args:
            newText: The new text to set as the original text.
        """
        self.originalText = newText
        self.lineEdit.blockSignals(True)
        if self.lineEdit.hasFocus():
            self.lineEdit.setText(newText)
        else:
            self.setMaskedText()
        self.lineEdit.blockSignals(False)

    def setMaskedText(self) -> None:
        """
        Set the masked text in the line edit.
        """
        maskedTextValue = self.maskedText(self.originalText)
        self.lineEdit.setText(maskedTextValue)

    def onFocusInEvent(self, focusEvent: QFocusEvent) -> None:
        """
        Show the full text when the line edit receives focus.
        
        Args:
            focusEvent: The focus event.
        """
        self.lineEdit.setText(self.originalText)
        QLineEdit.focusInEvent(self.lineEdit, focusEvent)

    def onFocusOutEvent(self, focusEvent: QFocusEvent) -> None:
        """
        Mask the text when the line edit loses focus.
        
        Args:
            focusEvent: The focus event.
        """
        self.setMaskedText()
        QLineEdit.focusOutEvent(self.lineEdit, focusEvent)

    def onUpdateText(self, editedText: str) -> None:
        """
        Update the original text when the user edits (or pastes) in the line edit.
        
        Args:
            editedText: The new text from the line edit.
        """
        self.originalText = editedText

