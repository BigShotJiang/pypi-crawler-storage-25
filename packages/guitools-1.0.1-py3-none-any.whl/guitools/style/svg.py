# -*- coding: latin -*-
from PySide6.QtGui import QImage, QPainter, QPixmap, QPainter, QIcon
from PySide6.QtSvg import QSvgRenderer, QSvgGenerator
from PySide6.QtCore import QSize, QByteArray, Qt
from os import path

class Icon(QIcon):
    """
    Extended QIcon with additional pixmap conversion methods.
    """

    def toPixmap(self, size: int | None = None) -> QPixmap:
        """
        Convert icon to pixmap.
        
        Args:
            size: Optional size for the pixmap. Defaults to None.
        
        Returns:
            QPixmap object.
        """
        if size:
            return self.pixmap(size)
        defaultSize = (32, 32)
        if self.availableSizes():
            defaultSize = self.availableSizes()[0]
        return self.pixmap(defaultSize)
    
class SVG(object):
    """
    Utility class for SVG operations.
    """

    @staticmethod
    def stringToIcon(svgString: str, size: QSize) -> Icon:
        """
        Convert SVG string to Icon.
        
        Args:
            svgString: SVG content as string.
            size: Size for the icon.
        
        Returns:
            Icon object.
        """
        svgByteArray = QByteArray(svgString.encode('utf-8'))
        svgRenderer = QSvgRenderer(svgByteArray)
        iconPixmap = QPixmap(size)
        iconPixmap.fill(Qt.GlobalColor.transparent) 
        svgPainter = QPainter(iconPixmap)
        svgRenderer.render(svgPainter)
        svgPainter.end()
        return Icon(iconPixmap)

    @staticmethod
    def imageToStringSvg(imagePath: str, outputSvg: str, title: str | None = None, description: str | None = None) -> str:
        """
        Convert an image file to SVG string.
        
        Args:
            imagePath: Path to the source image file.
            outputSvg: Path to the output SVG file.
            title: Optional title for the SVG. Defaults to None.
            description: Optional description for the SVG. Defaults to None.
        
        Returns:
            SVG content as string, or empty string if image doesn't exist.
        
        Raises:
            ValueError: If the image cannot be loaded.
        """
        if path.exists(imagePath):
            # Load the image
            sourceImage = QImage(imagePath)
            if sourceImage.isNull():
                raise ValueError(f"Error loading PNG image: {imagePath}")

            # Configure the SVG generator
            svgGenerator = QSvgGenerator()
            svgGenerator.setFileName(outputSvg)
            svgGenerator.setSize(sourceImage.size())
            svgGenerator.setViewBox(sourceImage.rect())
            svgGenerator.setTitle(title)
            svgGenerator.setDescription(description)

            # Render the image to SVG using QPainter
            svgPainter = QPainter(svgGenerator)
            svgPainter.drawImage(0, 0, sourceImage)
            svgPainter.end()
            
            # Read the SVG file content
            with open(outputSvg, "r", encoding="utf-8") as svgFile:
                svgFileContent = svgFile.read()

            # Return the SVG content as string
            return svgFileContent
        return ""