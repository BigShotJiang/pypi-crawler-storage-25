from .base import BaseWidgetStyleSheet, BaseStyleSheet, BaseColor, BaseProperty
from .button import ButtonStyleSheet
from .tabBar import TabBarStyleSheet

class TabWidgetStyleSheet(BaseWidgetStyleSheet):
    """
    Stylesheet for QTabWidget widget.
    """
    def __init__(self, prefix: str = "") -> None:
        """
        Initialize the TabWidgetStyleSheet.
        
        Args:
            prefix: The CSS selector prefix. Defaults to "".
        """
        super().__init__(f"{prefix} QTabWidget")
        self.pane = self.Pane(prefix)
        self.tab = TabBarStyleSheet(prefix)
        self.tabBar = self.TabBar(prefix)

    class TabBar(BaseStyleSheet):
        """
        TabWidget tab bar stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the TabBar stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QTabWidget::tab-bar', prefix)
            self.left = BaseProperty.Left(0)
  
    class Pane(BaseStyleSheet):
        """
        TabWidget pane stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the Pane stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QTabWidget::pane', prefix)
            self.border = BaseProperty.Border(color=BaseColor.division, topRightRadius=5, bottomLeftRadius=5, bottomRightRadius=5, topLeftRadius=0)
            self.top = BaseProperty.Top(-1)
            self.background = BaseProperty.Background(BaseColor.primary)
            
    class South(BaseWidgetStyleSheet):
        """
        TabWidget stylesheet for tabs positioned at the bottom (south).
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the South stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__(f"{prefix} QTabWidget")
            self.tabBar = self.TabBar(prefix)
            self.tabBarFrame = self.TabBarFrame(prefix)
            self.pane = self.Pane(prefix)
            self.tabFirst = self.TabFirst(prefix)
            self.tabOnlyOne = self.TabOnlyOne(prefix)
            self.tabLast = self.TabLast(prefix)
            self.tab = self.Tab(prefix)
            self.tabSelected = self.TabSelected(prefix)
            self.tabBarButton = self.TabBarButton(prefix)
            

        class TabBar(BaseStyleSheet):
            """
            TabWidget south tab bar stylesheet.
            """
            def __init__(self, prefix: str = "") -> None:
                """
                Initialize the TabBar stylesheet.
                
                Args:
                    prefix: The CSS selector prefix. Defaults to "".
                """
                super().__init__('QTabWidget QTabBar', prefix)
                self.border = BaseProperty.Border(topRightRadius=5, topLeftRadius=5, bottomRightRadius=5, bottomLeftRadius=0)

        class TabBarFrame(BaseStyleSheet):
            """
            TabWidget south tab bar frame stylesheet.
            """
            def __init__(self, prefix: str = "") -> None:
                """
                Initialize the TabBarFrame stylesheet.
                
                Args:
                    prefix: The CSS selector prefix. Defaults to "".
                """
                super().__init__('QTabWidget QTabBar QWidget', prefix)
                self.border = BaseProperty.Border(topRightRadius=5, topLeftRadius=5, bottomRightRadius=5, bottomLeftRadius=0)

        class Pane(BaseStyleSheet):
            """
            TabWidget south pane stylesheet.
            """
            def __init__(self, prefix: str = "") -> None:
                """
                Initialize the Pane stylesheet.
                
                Args:
                    prefix: The CSS selector prefix. Defaults to "".
                """
                super().__init__('QTabWidget::pane', prefix)
                self.border = BaseProperty.Border(color=BaseColor.division, topRightRadius=5, topLeftRadius=5, bottomRightRadius=5, bottomLeftRadius=0)
                self.top = BaseProperty.Top(0)
                self.bottom = BaseProperty.Bottom(-1)
                self.background = BaseProperty.Background(BaseColor.primary)

        class TabFirst(BaseStyleSheet):
            """
            TabWidget south first tab stylesheet.
            """
            def __init__(self, prefix: str = "") -> None:
                """
                Initialize the TabFirst stylesheet.
                
                Args:
                    prefix: The CSS selector prefix. Defaults to "".
                """
                super().__init__('QTabWidget QTabBar::tab:first', prefix)
                self.border = BaseProperty.Border(color=BaseColor.division, bottomLeftRadius=5, topLeftRadius=0, topRightRadius=0, bottomRightRadius=0)

        class TabOnlyOne(BaseStyleSheet):
            """
            TabWidget south tab when only one tab exists stylesheet.
            """
            def __init__(self, prefix: str = "") -> None:
                """
                Initialize the TabOnlyOne stylesheet.
                
                Args:
                    prefix: The CSS selector prefix. Defaults to "".
                """
                super().__init__('QTabWidget QTabBar::tab:only-one', prefix)
                self.border = BaseProperty.Border(color=BaseColor.division, bottomLeftRadius=5, bottomRightRadius=5, topLeftRadius=0, topRightRadius=0)

        class TabLast(BaseStyleSheet):
            """
            TabWidget south last tab stylesheet.
            """
            def __init__(self, prefix: str = "") -> None:
                """
                Initialize the TabLast stylesheet.
                
                Args:
                    prefix: The CSS selector prefix. Defaults to "".
                """
                super().__init__('QTabWidget QTabBar::tab:last', prefix)
                self.border = BaseProperty.Border(color=BaseColor.division, bottomRightRadius=5, topRightRadius=0, bottomLeftRadius=0, topLeftRadius=0)

        class Tab(BaseStyleSheet):
            """
            TabWidget south tab base stylesheet.
            """
            def __init__(self, prefix: str = "") -> None:
                """
                Initialize the Tab stylesheet.
                
                Args:
                    prefix: The CSS selector prefix. Defaults to "".
                """
                super().__init__('QTabWidget QTabBar::tab', prefix)
                self.border = BaseProperty.Border(color=BaseColor.division)
                self.padding = BaseProperty.Padding(left=5, right=5, top=1, bottom=3)
                self.background = BaseProperty.Background(BaseColor.secondary)
                self.bottom = BaseProperty.Bottom(0)
                self.top = BaseProperty.Top(0)
                self.font = BaseProperty.Font("Segoe UI Semibold", "63 12")

        class TabSelected(BaseStyleSheet):
            """
            TabWidget south tab selected state stylesheet.
            """
            def __init__(self, prefix: str = "") -> None:
                """
                Initialize the TabSelected stylesheet.
                
                Args:
                    prefix: The CSS selector prefix. Defaults to "".
                """
                super().__init__('QTabWidget QTabBar::tab:selected', prefix)
                self.background = BaseProperty.Background(BaseColor.primary)
                self.margin = BaseProperty.Margin(top=-1, bottom=0)

        class TabBarButton(ButtonStyleSheet):
            """
            TabWidget south tab bar button stylesheet.
            """
            def __init__(self, prefix: str = "") -> None:
                """
                Initialize the TabBarButton stylesheet.
                
                Args:
                    prefix: The CSS selector prefix. Defaults to "".
                """
                super().__init__(transparent=True, hover=False, prefix=f"{prefix} QTabWidget QTabBar::tab")



