from .base import BaseWidgetStyleSheet, BaseStyleSheet, BaseColor, BaseProperty
from .button import ButtonStyleSheet

class TabBarStyleSheet(BaseWidgetStyleSheet):
    """
    Stylesheet for QTabBar widget.
    """
    def __init__(self, prefix: str = "") -> None:
        """
        Initialize the TabBarStyleSheet.
        
        Args:
            prefix: The CSS selector prefix. Defaults to "".
        """
        super().__init__(f"{prefix} QTabBar")
        self.tabBar = self.TabBar(prefix)
        self.tabBarFrame = self.TabBarFrame(prefix)
        self.pane = self.Pane(prefix)
        self.tabFirst = self.TabFirst(prefix)
        self.tabOnlyOne = self.TabOnlyOne(prefix)
        self.tabLast = self.TabLast(prefix)
        self.tab = self.Tab(prefix)
        self.tabSelected = self.TabSelected(prefix)
        self.tabBarButton = self.TabBarButton(prefix)
       
    class TabBar(BaseStyleSheet):
        """
        TabBar base stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the TabBar stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QTabBar', prefix)
            self.border = BaseProperty.Border(topRightRadius=5, bottomLeftRadius=5, bottomRightRadius=5, topLeftRadius=0)
            self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.primary)

    class TabBarFrame(BaseStyleSheet):
        """
        TabBar frame stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the TabBarFrame stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QTabBar QWidget', prefix)
            self.border = BaseProperty.Border(topRightRadius=5, bottomLeftRadius=5, bottomRightRadius=5, topLeftRadius=0)

    class Pane(BaseStyleSheet):
        """
        TabBar pane stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the Pane stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('pane', prefix)
            self.border = BaseProperty.Border(color=BaseColor.division, topRightRadius=5, bottomLeftRadius=5, bottomRightRadius=5, topLeftRadius=0)
            self.top = BaseProperty.Top(-1)
            self.background = BaseProperty.Background(BaseColor.primary)

    class TabFirst(BaseStyleSheet):
        """
        TabBar first tab stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the TabFirst stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QTabBar::tab:first', prefix)
            self.border = BaseProperty.Border(color=BaseColor.division, topLeftRadius=5, topRightRadius=0, bottomLeftRadius=0, bottomRightRadius=0)

    class TabOnlyOne(BaseStyleSheet):
        """
        TabBar tab when only one tab exists stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the TabOnlyOne stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QTabBar::tab:only-one', prefix)
            self.border = BaseProperty.Border(color=BaseColor.division, topLeftRadius=5, topRightRadius=5, bottomLeftRadius=0, bottomRightRadius=0)

    class TabLast(BaseStyleSheet):
        """
        TabBar last tab stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the TabLast stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QTabBar::tab:last', prefix)
            self.border = BaseProperty.Border(color=BaseColor.division, topRightRadius=5, topLeftRadius=0, bottomRightRadius=0, bottomLeftRadius=0)

    class Tab(BaseStyleSheet):
        """
        TabBar tab base stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the Tab stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QTabBar::tab', prefix)
            self.border = BaseProperty.Border(top=1, right=1, left=1, bottom=1, color=BaseColor.division)
            self.padding = BaseProperty.Padding(left=5, right=5, top=2, bottom=2)
            self.background = BaseProperty.Background(BaseColor.secondary)
            self.font = BaseProperty.Font("Segoe UI Semibold", "63 12")
            self.height = BaseProperty.Height(value=30)
           
    class TabSelected(BaseStyleSheet):
        """
        TabBar tab selected state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the TabSelected stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QTabBar::tab:selected', prefix)
            self.background = BaseProperty.Background(BaseColor.primary)
            self.border = BaseProperty.Border(bottom=1, color=BaseColor.primary)
            self.color = BaseProperty.Color(BaseColor.Reverse.selected)

    class TabBarButton(ButtonStyleSheet):
        """
        TabBar button stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the TabBarButton stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__(transparent=True, hover=False, prefix=f"{prefix} QTabBar::tab")
   
    