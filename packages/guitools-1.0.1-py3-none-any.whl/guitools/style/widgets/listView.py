from .base import BaseWidgetStyleSheet, BaseStyleSheet, BaseColor, BaseProperty
from .checkBox import indicatorStyleCheet
from .scrollBar import ScrollBarStyleSheet
from ..utils import Global

class ListViewStyleCheet(BaseWidgetStyleSheet):
    """
    Stylesheet for QListView widget.
    """
    def __init__(self, prefix: str = "") -> None:
        """
        Initialize the ListViewStyleCheet.
        
        Args:
            prefix: The CSS selector prefix. Defaults to "".
        """
        super().__init__(f"{prefix} QListView")
        self.listView = self.ListView(prefix)
        self.item = self.Item(prefix)
        self.itemHover = self.ItemHover(prefix)
        self.itemSelected = self.ItemSelected(prefix)
        self.itemSelectedHover = self.ItemSelectedHover(prefix)
        self.indicator = self.Indicator(prefix)
        self.scrollBar = self.ScrollBar(prefix)
        self.scrollBarHorizontal = self.ScrollBarHorizontal(prefix)
        self.scrollBarVertical = self.ScrollBarVertical(prefix)

    class ScrollBar(BaseStyleSheet):
        """
        ListView scrollbar stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the ScrollBar stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QListView QScrollBar', prefix)
            self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.table)

    class ScrollBarHorizontal(ScrollBarStyleSheet.Horizontal):
        """
        ListView horizontal scrollbar stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the ScrollBarHorizontal stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__(f'{prefix} QListView')
            self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.table)
            self.border.radius = 0

    class ScrollBarVertical(ScrollBarStyleSheet.Vertical):
        """
        ListView vertical scrollbar stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the ScrollBarVertical stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__(f'{prefix} QListView')
            self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.table)
            self.border.radius = 0

    class ListView(BaseStyleSheet):
        """
        ListView base stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the ListView stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QListView', prefix)
            self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.table)
            self.padding = BaseProperty.Padding(value=2)

    class Item(BaseStyleSheet):
        """
        ListView item stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the Item stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QListView::item', prefix)
            self.height = BaseProperty.Height(value=30)
            self.padding = BaseProperty.Padding(value=0)
            self.border = BaseProperty.Border(width=0)

    class ItemHover(BaseStyleSheet):
        """
        ListView item hover state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the ItemHover stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QListView::item:hover', prefix)
            self.border = BaseProperty.Border(width=0)
            self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.secondary.fromRgba(120))

    class ItemSelected(BaseStyleSheet):
        """
        ListView item selected state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the ItemSelected stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QListView::item:selected', prefix)
            self.border = BaseProperty.Border(width=0)
            self.color = BaseProperty.Color(Global.appColor)
            self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.secondary)

    class ItemSelectedHover(BaseStyleSheet):
        """
        ListView item selected and hover state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the ItemSelectedHover stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QListView::item:selected:hover', prefix)
            self.border = BaseProperty.Border(width=0)
            self.color = BaseProperty.Color(Global.appColor)
            self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.secondary)

    class Indicator(indicatorStyleCheet):
        """
        ListView indicator stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the Indicator stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QListView", prefix)







