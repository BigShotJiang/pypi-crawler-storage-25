from .base import BaseWidgetStyleSheet, BaseStyleSheet, BaseColor, BaseProperty
from ..utils import Global

class ButtonMenuStyleSheet(BaseWidgetStyleSheet):
    """
    Stylesheet for menu button widgets (QPushButton in menu context).
    """
    def __init__(self, *, transparent: bool = True, selected: bool = False, padding: bool = True, height: int = 36, prefix: str = "") -> None:
        """
        Initialize the ButtonMenuStyleSheet.
        
        Args:
            transparent: Whether the button is transparent. Defaults to True.
            selected: Whether the button is selected. Defaults to False.
            padding: Whether to apply padding. Defaults to True.
            height: Button height in pixels. Defaults to 36.
            prefix: The CSS selector prefix. Defaults to "".
        """
        super().__init__(f"{prefix} QPushButton")
        self.button = self.Button(transparent=transparent, selected=selected, padding=padding, height=height, prefix=prefix)
        self.hover = self.Hover(selected=selected, prefix=prefix)
        self.pressed = self.Pressed(selected=selected, prefix=prefix)
        self.checked = self.Checked(selected=selected, prefix=prefix)
        self.checkedHover = self.CheckedHover(selected=selected, prefix=prefix)
        
    class Button(BaseStyleSheet):
        """
        Menu button base stylesheet.
        """
        def __init__(self, *, height: int = 36, transparent: bool = True, selected: bool = False, padding: bool = True, prefix: str = "") -> None:
            """
            Initialize the Button stylesheet.
            
            Args:
                height: Button height in pixels. Defaults to 36.
                transparent: Whether the button is transparent. Defaults to True.
                selected: Whether the button is selected. Defaults to False.
                padding: Whether to apply padding. Defaults to True.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QPushButton', prefix)
            self.padding = BaseProperty.Padding(left=9, right=9) if padding else None
            self.textAlign = BaseProperty.TextAlign('left')
            self.border = BaseProperty.Border(radius=6, color='transparent')
            self.font = BaseProperty.FontSegoeUI(12)
            if transparent:
                self.backgroundColor = BaseProperty.BackgroundColor('transparent')
            else:
                self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.primary)
            if selected:
                self.color = BaseProperty.Color(Global.appColor)
                self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.Menu.Button.hoverBackground.rgba)
                self.border = BaseProperty.Border(radius=6, color=BaseColor.Menu.Button.hoverBorder.rgba)
            else:
                self.color = BaseProperty.Color(BaseColor.Reverse.primary)
            self.height = BaseProperty.Height(value=height)

    class Hover(BaseStyleSheet):
        """
        Menu button hover state stylesheet.
        """
        def __init__(self, *, selected: bool = False, prefix: str = "") -> None:
            """
            Initialize the Hover stylesheet.
            
            Args:
                selected: Whether the button is selected. Defaults to False.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QPushButton:hover', prefix)
            if selected:
                self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.Menu.Button.hoverBackground.rgba)
                self.border = BaseProperty.Border(color=BaseColor.Menu.Button.hoverBorder)
            else:
                self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.Menu.Button.pressedBackground.rgba)
                self.border = BaseProperty.Border(color=BaseColor.Menu.Button.pressedBorder)

    class Pressed(BaseStyleSheet):
        """
        Menu button pressed state stylesheet.
        """
        def __init__(self, *, selected: bool = False, prefix: str = "") -> None:
            """
            Initialize the Pressed stylesheet.
            
            Args:
                selected: Whether the button is selected. Defaults to False.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QPushButton:pressed', prefix)
            if selected:
                self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.Menu.Button.hoverBackground.rgba)
                self.border = BaseProperty.Border(color=BaseColor.Menu.Button.hoverBorder)
            else:
                self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.Menu.Button.pressedBackground.fromRgba(200))
                self.border = BaseProperty.Border(color=BaseColor.Menu.Button.pressedBorder.fromRgba(200))

    class Checked(BaseStyleSheet):
        """
        Menu button checked state stylesheet.
        """
        def __init__(self, *, selected: bool = False, prefix: str = "") -> None:
            """
            Initialize the Checked stylesheet.
            
            Args:
                selected: Whether the button is selected. Defaults to False.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QPushButton:checked ', prefix)
            if selected:
                self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.Menu.Button.hoverBackground.rgba)
                self.border = BaseProperty.Border(color=BaseColor.Menu.Button.hoverBorder)
            else:
                self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.Menu.Button.pressedBackground.fromRgba(200))
                self.border = BaseProperty.Border(color=BaseColor.Menu.Button.pressedBorder.fromRgba(200))
            self.color = BaseProperty.Color(Global.appColor)

    class CheckedHover(BaseStyleSheet):
        """
        Menu button checked and hover state stylesheet.
        """
        def __init__(self, *, selected: bool = False, prefix: str = "") -> None:
            """
            Initialize the CheckedHover stylesheet.
            
            Args:
                selected: Whether the button is selected. Defaults to False.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QPushButton:checked:hover', prefix)
            if selected:
                self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.Menu.Button.hoverBackground.rgba)
                self.border = BaseProperty.Border(color=BaseColor.Menu.Button.hoverBorder)
            else:
                self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.Menu.Button.pressedBackground.fromRgba(200))
                self.border = BaseProperty.Border(color=BaseColor.Menu.Button.pressedBorder.fromRgba(200))


class ButtonStyleSheet(BaseWidgetStyleSheet):
    """
    Stylesheet for standard QPushButton widgets.
    """
    def __init__(self, *, transparent: bool = False, hover: bool = True, selected: bool = False, height: int = 25, prefix: str = "") -> None:
        """
        Initialize the ButtonStyleSheet.
        
        Args:
            transparent: Whether the button is transparent. Defaults to False.
            hover: Whether hover effects are enabled. Defaults to True.
            selected: Whether the button is selected. Defaults to False.
            height: Button height in pixels. Defaults to 25.
            prefix: The CSS selector prefix. Defaults to "".
        """
        super().__init__("QPushButton")
        self.button = self.Button(transparent=transparent, selected=selected, height=height, prefix=prefix)
        self.hover = self.Hover(transparent=transparent, hover=hover, selected=selected, prefix=prefix)
        self.pressed = self.Pressed(transparent=transparent, hover=hover, prefix=prefix)
        self.disabled = self.Disabled(transparent=transparent, selected=selected, prefix=prefix)
        self.checked = self.Checked(selected=selected, prefix=prefix)
        self.checkedHover = self.CheckedHover(selected=selected, prefix=prefix)

    class Button(BaseStyleSheet):
        """
        Button base stylesheet.
        """
        def __init__(self, *, height: int = 25, transparent: bool = False, selected: bool = False, prefix: str = "") -> None:
            """
            Initialize the Button stylesheet.
            
            Args:
                height: Button height in pixels. Defaults to 25.
                transparent: Whether the button is transparent. Defaults to False.
                selected: Whether the button is selected. Defaults to False.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QPushButton', prefix)
            self.padding = BaseProperty.Padding(left=3, right=3)
            self.color = BaseProperty.Color(BaseColor.Reverse.primary)
            self.height = BaseProperty.Height(value=height)
            self.margin = BaseProperty.Margin(value=0)
            if transparent:
                self.border = BaseProperty.Border(radius=5, color='transparent')
                self.backgroundColor = BaseProperty.BackgroundColor('transparent')
            else:
                if selected:
                    self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.Button.hoverBackground.fromRgba(200))
                    self.border = BaseProperty.Border(radius=5, color=BaseColor.Button.hoverBackground.fromRgba(200))
                    self.color = BaseProperty.Color(Global.appColor)
                else:
                    self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.Button.background.rgba)
                    self.border = BaseProperty.Border(radius=5, color=BaseColor.Button.background.rgba)

    class Checked(BaseStyleSheet):
        """
        Button checked state stylesheet.
        """
        def __init__(self, *, selected: bool = False, prefix: str = "") -> None:
            """
            Initialize the Checked stylesheet.
            
            Args:
                selected: Whether the button is selected. Defaults to False.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QPushButton:checked ', prefix)
            if selected:
                self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.Menu.Button.hoverBackground.rgba)
                self.border = BaseProperty.Border(color=BaseColor.Menu.Button.hoverBorder)
            else:
                self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.Menu.Button.pressedBackground.fromRgba(200))
                self.border = BaseProperty.Border(color=BaseColor.Menu.Button.pressedBorder.fromRgba(200))

    class CheckedHover(BaseStyleSheet):
        """
        Button checked and hover state stylesheet.
        """
        def __init__(self, *, selected: bool = False, prefix: str = "") -> None:
            """
            Initialize the CheckedHover stylesheet.
            
            Args:
                selected: Whether the button is selected. Defaults to False.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QPushButton:checked:hover', prefix)
            if selected:
                self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.Menu.Button.hoverBackground.rgba)
                self.border = BaseProperty.Border(color=BaseColor.Menu.Button.hoverBorder)
            else:
                self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.Menu.Button.pressedBackground.fromRgba(200))
                self.border = BaseProperty.Border(color=BaseColor.Menu.Button.pressedBorder.fromRgba(200))
            self.color = BaseProperty.Color(BaseColor.Reverse.selected)


    class Hover(BaseStyleSheet):
        """
        Button hover state stylesheet.
        """
        def __init__(self, *, transparent: bool = False, hover: bool = True, selected: bool = False, prefix: str = "") -> None:
            """
            Initialize the Hover stylesheet.
            
            Args:
                transparent: Whether the button is transparent. Defaults to False.
                hover: Whether hover effects are enabled. Defaults to True.
                selected: Whether the button is selected. Defaults to False.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QPushButton:hover', prefix)

            if hover or not transparent:
                if selected:
                    self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.Button.hoverBackground.fromRgba(200))
                    self.border = BaseProperty.Border(color=BaseColor.Button.hoverBorder.fromRgba(200))
                else:
                    self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.Button.hoverBackground.rgba)
                    self.border = BaseProperty.Border(color=BaseColor.Button.hoverBorder.rgba)
            else:
                self.border = BaseProperty.Border(color='transparent')

    class Pressed(BaseStyleSheet):
        """
        Button pressed state stylesheet.
        """
        def __init__(self, *, transparent: bool = False, hover: bool = True, prefix: str = "") -> None:
            """
            Initialize the Pressed stylesheet.
            
            Args:
                transparent: Whether the button is transparent. Defaults to False.
                hover: Whether hover effects are enabled. Defaults to True.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QPushButton:pressed', prefix)
            if hover or not transparent:
                self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.Button.pressedBackground.rgba)
                self.border = BaseProperty.Border(color=BaseColor.Button.pressedBorder.rgba)
            else:
                self.border = BaseProperty.Border(color='transparent')
       
    class Disabled(BaseStyleSheet):
        """
        Button disabled state stylesheet.
        """
        def __init__(self, *, transparent: bool = False, selected: bool = False, prefix: str = "") -> None:
            """
            Initialize the Disabled stylesheet.
            
            Args:
                transparent: Whether the button is transparent. Defaults to False.
                selected: Whether the button is selected. Defaults to False.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QPushButton:disabled', prefix)

            self.color = BaseProperty.Color(BaseColor.Reverse.primary.fromRgba(200))

            if transparent:
                self.border = BaseProperty.Border(color='transparent')
                self.backgroundColor = BaseProperty.BackgroundColor('transparent')
            else:
                if selected:
                    self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.Button.background.fromRgba(150))
                    self.border = BaseProperty.Border(color=BaseColor.Button.background.fromRgba(150))
                else:
                    self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.Button.background.fromRgba(100))
                    self.border = BaseProperty.Border(color=BaseColor.Button.background.fromRgba(100))
             
    
class ButtonCopyStyleSheet(BaseWidgetStyleSheet):
    """
    Stylesheet for copy button widgets (special variant of QPushButton).
    """
    def __init__(self, *, transparent: bool = False, height: int = 25, prefix: str = "") -> None:
        """
        Initialize the ButtonCopyStyleSheet.
        
        Args:
            transparent: Whether the button is transparent. Defaults to False.
            height: Button height in pixels. Defaults to 25.
            prefix: The CSS selector prefix. Defaults to "".
        """
        super().__init__(f"{prefix} QPushButton")
        self.button = self.Button(transparent=transparent, selected=False, height=height, prefix=prefix)
        self.hover = self.Hover(transparent=transparent, hover=True, selected=False, prefix=prefix)
        self.pressed = self.Pressed(transparent=transparent, prefix=prefix)
        self.disabled = self.Disabled(transparent=transparent, selected=False, prefix=prefix)
       
    class Button(ButtonStyleSheet.Button):
        """
        Copy button base stylesheet.
        """
        def __init__(self, *, height: int = 25, transparent: bool = False, selected: bool = False, prefix: str = "") -> None:
            """
            Initialize the Button stylesheet.
            
            Args:
                height: Button height in pixels. Defaults to 25.
                transparent: Whether the button is transparent. Defaults to False.
                selected: Whether the button is selected. Defaults to False.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__(height=height, transparent=transparent, selected=selected, prefix=prefix)
              
    class Hover(ButtonStyleSheet.Hover):
        """
        Copy button hover state stylesheet.
        """
        def __init__(self, *, transparent: bool = False, hover: bool = True, selected: bool = False, prefix: str = "") -> None:
            """
            Initialize the Hover stylesheet.
            
            Args:
                transparent: Whether the button is transparent. Defaults to False.
                hover: Whether hover effects are enabled. Defaults to True.
                selected: Whether the button is selected. Defaults to False.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__(transparent=transparent, hover=hover, selected=selected, prefix=prefix)

    class Disabled(ButtonStyleSheet.Disabled):
        """
        Copy button disabled state stylesheet.
        """
        def __init__(self, *, transparent: bool = False, selected: bool = False, prefix: str = "") -> None:
            """
            Initialize the Disabled stylesheet.
            
            Args:
                transparent: Whether the button is transparent. Defaults to False.
                selected: Whether the button is selected. Defaults to False.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__(transparent=transparent, selected=selected, prefix=prefix)

    class Pressed(BaseStyleSheet):
        """
        Copy button pressed state stylesheet.
        """
        def __init__(self, *, transparent: bool = False, prefix: str = "") -> None:
            """
            Initialize the Pressed stylesheet.
            
            Args:
                transparent: Whether the button is transparent. Defaults to False.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__(className='QPushButton:pressed', prefix=prefix)
            self.border = BaseProperty.Border(width=2, color=Global.appColor)
            if not transparent:
                self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.Button.pressedBackground.rgba)
                   


