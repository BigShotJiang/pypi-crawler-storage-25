from .base import BaseWidgetStyleSheet, BaseStyleSheet, BaseColor, BaseProperty, StyleSheets

class MenuStyleCheet(BaseWidgetStyleSheet):
    """
    Stylesheet for QMenu widget.
    """
    def __init__(self, width: int | None = None, height: int | None = None, backgroundColor: BaseColor = BaseColor.secondary, prefix: str = "") -> None:
        """
        Initialize the MenuStyleCheet.
        
        Args:
            width: Menu width in pixels. Defaults to None.
            height: Menu height in pixels. Defaults to None.
            backgroundColor: Background color. Defaults to BaseColor.secondary.
            prefix: The CSS selector prefix. Defaults to "".
        """
        super().__init__(f"{prefix} QMenu")
        self.base = StyleSheets.BaseStyle("QMenu")
        self.menu = self.Menu(width=width, height=height, backgroundColor=backgroundColor, prefix=prefix)
        self.item = self.Item(prefix)
        self.itemSelected = self.ItemSelected(prefix)
        self.separator = self.Separator(prefix)
       
    class Menu(BaseStyleSheet):
        """
        Menu base stylesheet.
        """
        def __init__(self, *, width: int | None = None, height: int | None = None, backgroundColor: BaseColor = BaseColor.secondary, prefix: str = "") -> None:
            """
            Initialize the Menu stylesheet.
            
            Args:
                width: Menu width in pixels. Defaults to None.
                height: Menu height in pixels. Defaults to None.
                backgroundColor: Background color. Defaults to BaseColor.secondary.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QMenu', prefix)
            self.backgroundColor = BaseProperty.BackgroundColor(backgroundColor)
            self.color = BaseProperty.Color(BaseColor.Reverse.primary)
            self.border = BaseProperty.Border(radius=5, bottomRightRadius=0, color=BaseColor.Widget.hoverBorder)
            self.font = BaseProperty.FontSegoeUI(12)

            if width != None:
                self.width = BaseProperty.Width(value=width, min=width)
            if height != None:
                self.height = BaseProperty.Height(value=height, min=height)

    class Item(BaseStyleSheet):
        """
        Menu item stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the Item stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QMenu:item', prefix)
            self.padding = BaseProperty.Padding(value=2)
            self.margin = BaseProperty.Margin(value=2)
            self.border = BaseProperty.Border(radius=5, color=BaseColor.secondary)

    class ItemSelected(BaseStyleSheet):
        """
        Menu item selected state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the ItemSelected stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QMenu::item:selected', prefix)
            self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.Button.hoverBackground)
            self.border = BaseProperty.Border(color=BaseColor.Button.hoverBorder)

    class ItemHover(BaseStyleSheet):
        """
        Menu item hover state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the ItemHover stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QMenu::item:hover', prefix)
            self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.Button.hoverBackground)
            self.border = BaseProperty.Border(color=BaseColor.Button.hoverBorder)

    class Separator(BaseStyleSheet):
        """
        Menu separator stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the Separator stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QMenu::separator', prefix)
            self.background = BaseProperty.Background(BaseColor.division)
            self.margin = BaseProperty.Margin(left=7, right=7, top=2, bottom=2)
            self.height = BaseProperty.Height(value=1)


