
from .base import BaseColor, BaseWidgetStyleSheet, BaseProperty, BaseStyleSheet, CreateStyleSheet, StyleSheets
from .comboBox import ComboBoxStyleCheet
from .scrollBar import ScrollBarStyleSheet, ScrollAreaStyleSheet
from .progressBar import ProgressBarStyleSheet
from .tableView import TableViewStyleSheet
from .treeView import TreeViewStyleSheet
from .listView import ListViewStyleCheet
from .headerView import HeaderViewStyleSheet
from .menu import MenuStyleCheet
from .checkBox import CheckBoxStyleCheet
from .lineEdit import LineEditStyleCheet
from .tabWidget import TabWidgetStyleSheet
from .tabBar import TabBarStyleSheet
from .box import SpinBoxStyleSheet, DoubleSpinBoxStyleSheet, TimeEditStyleSheet, DateTimeEditStyleSheet
from .text import TextEditStyleSheet, TextBrowserStyleSheet, PlainTextEditStyleSheet
from .button import ButtonMenuStyleSheet, ButtonStyleSheet, ButtonCopyStyleSheet
from .toolBox import ToolBoxStyleSheet
from .splitter import SplitterStyleSheet
from ..utils import Global

class Property(BaseProperty):
    """
    Property class that extends BaseProperty.
    """
    ...

class Standard:
    """
    Standard stylesheet class that loads and manages all widget stylesheets.
    """

    class StyleSheet(BaseWidgetStyleSheet):
        """
        Standard stylesheet widget.
        """
        def __init__(self):
            """
            Initialize the Standard StyleSheet.
            """
            super().__init__("Standard")

        def style(self):
            """
            Get the standard style string.
            
            Returns:
                The standard style string.
            """
            return Standard.__str__()

    menu: MenuStyleCheet
    button: ButtonStyleSheet
    buttonMenu: ButtonMenuStyleSheet
    buttonCopy: ButtonCopyStyleSheet
    scrollBar: ScrollBarStyleSheet
    scrollArea: ScrollAreaStyleSheet
    headerView: HeaderViewStyleSheet
    tableView: TableViewStyleSheet
    treeView: TreeViewStyleSheet
    lineEdit: LineEditStyleCheet
    checkBox: CheckBoxStyleCheet
    comboBox: ComboBoxStyleCheet
    textEdit: TextEditStyleSheet
    plainTextEdit: PlainTextEditStyleSheet
    textBrowser: TextBrowserStyleSheet
    spinBox: SpinBoxStyleSheet
    timeEdit: TimeEditStyleSheet
    dateTimeEdit: DateTimeEditStyleSheet
    doubleSpinBox: DoubleSpinBoxStyleSheet
    tabWidget: TabWidgetStyleSheet
    tabBar: TabBarStyleSheet
    listView: ListViewStyleCheet
    progressBar: ProgressBarStyleSheet
    toolBox: ToolBoxStyleSheet
    splitter: SplitterStyleSheet

    @classmethod
    def load(cls) -> None:
        """
        Load all widget stylesheets.
        """
        cls.menu = MenuStyleCheet()
        cls.button = ButtonStyleSheet()
        cls.buttonMenu = ButtonMenuStyleSheet()
        cls.buttonCopy = ButtonCopyStyleSheet()
        cls.scrollBar = ScrollBarStyleSheet()
        cls.scrollArea = ScrollAreaStyleSheet()
        cls.headerView = HeaderViewStyleSheet()
        cls.tableView = TableViewStyleSheet()
        cls.treeView = TreeViewStyleSheet()
        cls.lineEdit = LineEditStyleCheet()
        cls.checkBox = CheckBoxStyleCheet()
        cls.comboBox = ComboBoxStyleCheet()
        cls.textEdit = TextEditStyleSheet()
        cls.plainTextEdit = PlainTextEditStyleSheet()
        cls.textBrowser = TextBrowserStyleSheet()
        cls.spinBox = SpinBoxStyleSheet()
        cls.timeEdit = TimeEditStyleSheet()
        cls.dateTimeEdit = DateTimeEditStyleSheet()
        cls.doubleSpinBox = DoubleSpinBoxStyleSheet()
        cls.tabWidget = TabWidgetStyleSheet()
        cls.tabBar = TabBarStyleSheet()
        cls.listView = ListViewStyleCheet()
        cls.progressBar = ProgressBarStyleSheet()
        cls.toolBox = ToolBoxStyleSheet()
        cls.splitter = SplitterStyleSheet()
   
    @classmethod
    def __str__(cls):
        """
        Generate the complete stylesheet string.
        
        Returns:
            The complete stylesheet string.
        """

        indicator = CreateStyleSheet(Property.SubcontrolPosition('center', 'right'),
                                  Property.Image('arrow_down.png'),
                                  Property.Height(value=9))

        return f'''

            {StyleSheets.BaseStyle()}
            
            {cls.button}
            {cls.scrollBar}
            {cls.scrollArea}
            {cls.tableView}
            {cls.treeView}
            {cls.headerView}
            {cls.lineEdit}
            {cls.checkBox}
            {cls.comboBox}
            {cls.textEdit}
            {cls.plainTextEdit}
            {cls.textBrowser}
            {cls.spinBox}
            {cls.timeEdit}
            {cls.dateTimeEdit}
            {cls.doubleSpinBox}
            {cls.tabWidget}
            {cls.tabBar}
            {cls.listView}
            {cls.progressBar}
            {cls.toolBox}
            {cls.menu}
            
            {CreateStyleSheet(Property.BackgroundColor(BaseColor.Widget.background),
                                  Property.Color(BaseColor.Reverse.primary),
                                  Property.Border(width=0),
                                  Property.Padding(value=3)
                                  ).addClassName(
                                  "QToolButton") }

       
            QLabel {{
                selection-background-color: {BaseColor.Widget.selectedBackground};  
                selection-color: {BaseColor.Reverse.selected};            
            }}

            {indicator.addClassName("QToolButton::menu-indicator")}

            {indicator.clone(Property.Border(radius=5)).addClassName("QComboBox::drop-down", "QDateEdit::drop-down", "QToolButton::arrow")}

             {CreateStyleSheet(Property.Image('arrow_down.png', "130_130_130")).addClassName(
                "QComboBox::drop-down", "QDateEdit::drop-down", "QToolButton::arrow", suffix=":disabled")
             }
             
             {CreateStyleSheet(Property.Image('arrow_down.png')).addClassName( 
                "QComboBox::drop-down", "QDateEdit::drop-down", "QToolButton::arrow")
             }
             
             QSplitter::handle:horizontal
            {{
                background-color: qlineargradient(spread: pad, x1: 0, y1: 1, x2: 0, y2: 0,
                    stop: 0 rgba(255, 255, 255, 0),
                    stop: 0.407273 {BaseColor.secondary.rgba},
                    stop: 0.6825 {BaseColor.secondary.fromRgba(230)},
                    stop: 1 rgba(255, 255, 255, 0)
                );
                margin: 1px;
            }}

            QSplitter::handle:vertical
            {{
                background-color: qlineargradient(spread: pad, x1: 1, y1: 0, x2: 0, y2: 0,
                    stop: 0 rgba(255, 255, 255, 0),
                    stop: 0.407273 {BaseColor.secondary.rgba},
                    stop: 0.6825 {BaseColor.secondary.fromRgba(230)},
                    stop: 1 rgba(255, 255, 255, 0)
                );
                margin: 1px;
            }}

            QCalendarWidget {{
                border-radius: 0px;
                color: {Global.appColor};
                selection-color: {BaseColor.Reverse.secondary};
                selection-background-color: {BaseColor.secondary};
                border: 0px solid;
                font: 10pt "Segoe UI";
            }}

            #centralwidget {{ border-radius: 0px;}} 

            QFrame, QWidget {{outline: none;}}
            
        '''


class WidgetsStyleCheet(object):
    """
    Main class for accessing widget stylesheets and utilities.
    """

    class line(BaseWidgetStyleSheet):
        """
        Line widget stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the line stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__()
            self._prefix = prefix

        def styleSheet(self, *, useClassName: bool = True) -> str:
            """
            Generate the stylesheet string.
            
            Args:
                useClassName: Whether to use class name. Defaults to True.
            
            Returns:
                The stylesheet string.
            """
            gradientColor = BaseColor.secondary.horizontalGradient([0, 0.45, 0.55, 1]).replace(';', '')
            if self._prefix.strip():
                return f'{self._prefix} {{{Property.Border(radius=0)} {Property.BackgroundColor(gradientColor)}}}'
            return f'{Property.Border(radius=0)} {Property.BackgroundColor(gradientColor)}'
        

    class Color(BaseColor):
        """
        Color class that extends BaseColor.
        """
        ...

    class Property(BaseProperty):
        """
        Property class that extends BaseProperty.
        """
        ...

    class StyleSheet(BaseStyleSheet):
        """
        StyleSheet class that extends BaseStyleSheet.
        """
        ...

    class CreateStyleSheet(CreateStyleSheet):
        """
        CreateStyleSheet class that extends CreateStyleSheet.
        """
        ...

    class comboBox(ComboBoxStyleCheet):
        """
        ComboBox stylesheet class.
        """
        ...

    class progressBar(ProgressBarStyleSheet):
        """
        ProgressBar stylesheet class.
        """
        ...

    class scrollBar(ScrollBarStyleSheet):
        """
        ScrollBar stylesheet class.
        """
        ...

    class tableView(TableViewStyleSheet):
        """
        TableView stylesheet class.
        """
        ...

    class treeView(TreeViewStyleSheet):
        """
        TreeView stylesheet class.
        """
        ...

    class listView(ListViewStyleCheet):
        """
        ListView stylesheet class.
        """
        ...

    class headerView(HeaderViewStyleSheet):
        """
        HeaderView stylesheet class.
        """
        ...

    class menu(MenuStyleCheet):
        """
        Menu stylesheet class.
        """
        ...

    class checkBox(CheckBoxStyleCheet):
        """
        CheckBox stylesheet class.
        """
        ...

    class lineEdit(LineEditStyleCheet):
        """
        LineEdit stylesheet class.
        """
        ...

    class tabWidget(TabWidgetStyleSheet):
        """
        TabWidget stylesheet class.
        """
        ...

    class tabBar(TabBarStyleSheet):
        """
        TabBar stylesheet class.
        """
        ...

    class toolBox(ToolBoxStyleSheet):
        """
        ToolBox stylesheet class.
        """
        ...

    class spinBox(SpinBoxStyleSheet):
        """
        SpinBox stylesheet class.
        """
        ...

    class timeEdit(TimeEditStyleSheet):
        """
        TimeEdit stylesheet class.
        """
        ...

    class dateTimeEdit(DateTimeEditStyleSheet):
        """
        DateTimeEdit stylesheet class.
        """
        ...

    class doubleSpinBox(DoubleSpinBoxStyleSheet):
        """
        DoubleSpinBox stylesheet class.
        """
        ...

    class textEdit(TextEditStyleSheet):
        """
        TextEdit stylesheet class.
        """
        ...

    class plainTextEdit(PlainTextEditStyleSheet):
        """
        PlainTextEdit stylesheet class.
        """
        ...

    class textBrowser(TextBrowserStyleSheet):
        """
        TextBrowser stylesheet class.
        """
        ...

    class buttonMenu(ButtonMenuStyleSheet):
        """
        ButtonMenu stylesheet class.
        """
        ...

    class button(ButtonStyleSheet):
        """
        Button stylesheet class.
        """
        ...

    class buttonCopy(ButtonCopyStyleSheet):
        """
        ButtonCopy stylesheet class.
        """
        ...

    class splitter(SplitterStyleSheet):
        """
        Splitter stylesheet class.
        """
        ...

    class WidgetStyleSheet(BaseWidgetStyleSheet):
        """
        WidgetStyleSheet class that extends BaseWidgetStyleSheet.
        """
        ...

    class Standard(Standard):
        """
        Standard stylesheet class.
        """
        ...

    @classmethod
    def standard(cls):
        """
        Get the standard stylesheet string.
        
        Returns:
            The standard stylesheet string.
        """
        return cls.Standard.__str__()
