from .base import BaseWidgetStyleSheet, BaseStyleSheet, BaseColor, BaseProperty
from .text import TextEditStyleSheet, TextBrowserStyleSheet

class ToolBoxStyleSheet(BaseWidgetStyleSheet):
    """
    Stylesheet for QToolBox widget.
    """
    def __init__(self, prefix: str = "") -> None:
        """
        Initialize the ToolBoxStyleSheet.
        
        Args:
            prefix: The CSS selector prefix. Defaults to "".
        """
        super().__init__("QToolBox")
        self.tabHover = self.TabHover(prefix)
        self.tab = self.Tab(prefix)
        self.tabSelected = self.TabSelected(prefix)
        self.tabSelectedHover = self.TabSelectedHover(prefix)

    class Tab(BaseStyleSheet):
        """
        ToolBox tab base stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the Tab stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QToolBox::tab', prefix)
            self.border = BaseProperty.Border(color=BaseColor.division, radius=5)
            self.padding = BaseProperty.Padding(left=5, right=5)
            self.background = BaseProperty.Background(BaseColor.Widget.background)

    class TabHover(BaseStyleSheet):
        """
        ToolBox tab hover state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the TabHover stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QToolBox::tab:hover', prefix)
            self.background = BaseProperty.Background(BaseColor.Widget.hoverBackground)
            self.border = BaseProperty.Border(color=BaseColor.Widget.hoverBorder)

    class TabSelected(BaseStyleSheet):
        """
        ToolBox tab selected state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the TabSelected stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QToolBox::tab:selected', prefix)
            self.background = BaseProperty.Background(BaseColor.Widget.selectedBackground)
            self.border = BaseProperty.Border(color=BaseColor.Widget.focusBorder)

    class TabSelectedHover(BaseStyleSheet):
        """
        ToolBox tab selected and hover state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the TabSelectedHover stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QToolBox::tab:hover:selected', prefix)
            self.background = BaseProperty.Background(BaseColor.Widget.selectedBackground)
            self.border = BaseProperty.Border(color=BaseColor.Widget.focusBorder)






