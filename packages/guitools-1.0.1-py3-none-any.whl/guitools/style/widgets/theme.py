# -*- coding: latin -*-

from ..styleSheet import BaseColor
from .base import BaseWidgetStyleSheet, BaseStyleSheet
from PySide6.QtGui import QPalette, QIcon
from PySide6.QtCore import QEvent, QObject, Qt, QRect
from PySide6.QtWidgets import QWidget, QPushButton, QLabel, QTextBrowser, QTextEdit, QTreeWidget, QStyledItemDelegate
from typing import Callable
from ..utils import Global

class ThemedIconWidget(QObject):
    """
    Widget that manages themed icons that change based on hover state and theme.
    """
    def __init__(self, widget: QPushButton | QLabel, iconLeave: Callable[[], QIcon], iconEnter: Callable[[], QIcon], pixmapSize: int | None = None) -> None:
        """
        Initialize the ThemedIconWidget.
        
        Args:
            widget: The widget to apply themed icons to.
            iconLeave: Callable that returns the icon when mouse leaves.
            iconEnter: Callable that returns the icon when mouse enters.
            pixmapSize: Optional pixmap size for QLabel. Defaults to None.
        """
        super().__init__(widget)
        self.widget: QPushButton | QLabel = widget
        self.theme = Global.theme
        self.isThemed: bool = 'theme' in iconLeave.__name__.lower() or 'theme' in iconEnter.__name__.lower()
        self.active: bool = False
        self.updateData(iconLeave, iconEnter, pixmapSize)

        if isinstance(self.widget, QPushButton) and self.widget.isCheckable():
            self.widget.toggled.connect(self.onToggled)

        # Install event filter to capture enter/leave events
        self.widget.installEventFilter(self)

    def updateData(self, iconLeave: Callable[[], QIcon], iconEnter: Callable[[], QIcon], pixmapSize: int | None = None) -> None:
        """
        Update the icon data.
        
        Args:
            iconLeave: Callable that returns the icon when mouse leaves.
            iconEnter: Callable that returns the icon when mouse enters.
            pixmapSize: Optional pixmap size for QLabel. Defaults to None.
        """
        self.iconLeave: Callable[[], QIcon] = iconLeave
        self.iconEnter: Callable[[], QIcon] = iconEnter
        self.pixmapSize: int | None = pixmapSize
        self.updateIcon()

    def updateIcon(self) -> None:
        """
        Update the icon based on widget state.
        """
        if isinstance(self.widget, QPushButton) and self.widget.isCheckable():
            if self.widget.isChecked():
                self.applyIcon(self.iconEnter())
            else:
                self.applyIcon(self.iconLeave())
        else:
            self.applyIcon(self.iconLeave())
        
    def onToggled(self, checked: bool) -> None:
        """
        Handle widget toggled event.
        
        Args:
            checked: Whether the widget is checked.
        """
        if not checked and not self.widget.underMouse():
            self.applyIcon(self.iconLeave())

    def toggleActive(self) -> None:
        """
        Toggle the active state of the icon.
        """
        self.active = not self.active
        if self.active:
            self.applyIcon(self.iconEnter())
        else:
            self.applyIcon(self.iconLeave())

    def applyIcon(self, icon: QIcon) -> None:
        """
        Apply an icon to the widget.
        
        Args:
            icon: The icon to apply.
        """
        if not self.active:
            if isinstance(self.widget, QPushButton):
                self.widget.setIcon(icon)
            elif isinstance(self.widget, QLabel):
                self.widget.setPixmap(icon.toPixmap(self.pixmapSize))

    def eventFilter(self, obj: QObject, event: QEvent) -> bool:
        """
        Filter events for the widget.
        
        Args:
            obj: The object that received the event.
            event: The event.
        
        Returns:
            True if the event was handled, False otherwise.
        """
        if obj is self.widget:
            if not self.active:
                if event.type() == QEvent.Type.Enter and self.widget.isEnabled():
                    self.applyIcon(self.iconEnter())
                elif event.type() == QEvent.Type.Leave:
                    if isinstance(self.widget, QPushButton) and not self.widget.isChecked():
                        self.applyIcon(self.iconLeave())
                    elif isinstance(self.widget, QLabel):
                        self.applyIcon(self.iconLeave())
                elif obj is self.widget and event.type() == QEvent.Type.Show and self.isThemed:
                    if self.theme != Global.theme:
                        self.updateIcon()
                        self.theme = Global.theme

        return super().eventFilter(obj, event)

class ThemedWidget(QObject):
    """
    Widget that automatically updates its stylesheet when the theme changes.
    """
    def __init__(self, widget: QWidget, styleSheet: BaseWidgetStyleSheet | BaseStyleSheet) -> None:
        """
        Initialize the ThemedWidget.
        
        Args:
            widget: The widget to apply themed stylesheet to.
            styleSheet: The stylesheet to apply.
        """
        super().__init__(widget)
        self.widget: QWidget = widget
        self.theme = Global.theme
        self.styleSheet: BaseWidgetStyleSheet | BaseStyleSheet = styleSheet
        self.widget.installEventFilter(self) 

    def updateStyle(self) -> None:
        """
        Update the widget's stylesheet if the theme has changed.
        """
        if self.theme != Global.theme:
            self.widget.setStyleSheet(self.styleSheet.styleSheet())
            self.theme = Global.theme

    def eventFilter(self, obj: QObject, event: QEvent) -> bool:
        """
        Filter events for the widget.
        
        Args:
            obj: The object that received the event.
            event: The event.
        
        Returns:
            True if the event was handled, False otherwise.
        """
        if obj is self.widget and event.type() == QEvent.Type.Show:
            self.updateStyle()
        return super().eventFilter(obj, event)  
    
class ThemedTextWidget(QObject):
    """
    Widget that automatically updates text widget palette when the theme changes.
    """
    def __init__(self, widget: QTextBrowser | QTextEdit) -> None:
        """
        Initialize the ThemedTextWidget.
        
        Args:
            widget: The text widget to apply themed palette to.
        """
        super().__init__(widget)
        self.widget: QTextBrowser | QTextEdit = widget
        self.theme = None
        self.updateStyle()
        self.widget.installEventFilter(self) 

    def updateStyle(self) -> None:
        """
        Update the widget's palette if the theme has changed.
        """
        if self.theme != Global.theme:
            widgetPalette = self.widget.palette()
            widgetPalette.setColor(QPalette.ColorRole.PlaceholderText, BaseColor.placeholder.QColor)
            self.widget.setPalette(widgetPalette)
            self.theme = Global.theme

    def eventFilter(self, obj: QObject, event: QEvent) -> bool:
        """
        Filter events for the widget.
        
        Args:
            obj: The object that received the event.
            event: The event.
        
        Returns:
            True if the event was handled, False otherwise.
        """
        if obj is self.widget and event.type() == QEvent.Type.Show:
            self.updateStyle()
        return super().eventFilter(obj, event) 
    

class ThemedCodeEditor(QObject):
    """
    Widget that automatically updates code editor highlighting when the theme changes.
    """
    def __init__(self, widget: QTextBrowser | QTextEdit) -> None:
        """
        Initialize the ThemedCodeEditor.
        
        Args:
            widget: The code editor widget to apply themed highlighting to.
        """
        super().__init__(widget)
        self.widget: QTextBrowser | QTextEdit = widget
        self.theme = None
        self.update()
        self.widget.installEventFilter(self) 

    def update(self) -> None:
        """
        Update the code editor highlighting if the theme has changed.
        """
        if self.theme != Global.theme:
            if hasattr(self.widget, 'highlighting'):
                self.widget.highlighting()
            self.widget.highlightCurrentLine()
            self.theme = Global.theme

    def eventFilter(self, obj: QObject, event: QEvent) -> bool:
        """
        Filter events for the widget.
        
        Args:
            obj: The object that received the event.
            event: The event.
        
        Returns:
            True if the event was handled, False otherwise.
        """
        if obj is self.widget and event.type() == QEvent.Type.Show:
            self.update()
        return super().eventFilter(obj, event) 
    
class ThemedTreeWidget(QObject):
    """
    Widget that automatically updates tree widget alternate background when the theme changes.
    """

    class AlternateBackgroundDelegate(QStyledItemDelegate):
        """
        Delegate that paints alternate background colors for tree widget items.
        """
        def __init__(self, parent: QWidget | None = None) -> None:
            """
            Initialize the AlternateBackgroundDelegate.
            
            Args:
                parent: The parent widget. Defaults to None.
            """
            super().__init__(parent)

        def paint(self, painter, option, index) -> None:
            """
            Paint the item with alternate background if needed.
            
            Args:
                painter: The painter to use.
                option: The style option.
                index: The model index.
            """
            alternateColor = BaseColor.tableAlternate.QColor
            parentTreeWidget: QTreeWidget = option.widget
            treeItem = parentTreeWidget.itemFromIndex(index)
            shouldPaintAlternate = False

            if treeItem:
                if treeItem.parent() is None:
                    topLevelIndex = parentTreeWidget.indexOfTopLevelItem(treeItem)
                    if topLevelIndex % 2 != 0: 
                        shouldPaintAlternate = True
                else:
                    topLevelItem = treeItem
                    while topLevelItem.parent():
                        topLevelItem = topLevelItem.parent()
                    topLevelIndex = parentTreeWidget.indexOfTopLevelItem(topLevelItem)
                    if topLevelIndex % 2 != 0:
                        shouldPaintAlternate = True

            if shouldPaintAlternate:
                fullRectangle = QRect(
                    option.rect.x(),
                    option.rect.y(),
                    parentTreeWidget.viewport().width() - option.rect.x(),
                    option.rect.height()
                )
                painter.save()
                painter.fillRect(fullRectangle, alternateColor)
                painter.restore()

            super().paint(painter, option, index)

    def __init__(self, widget: QTreeWidget) -> None:
        """
        Initialize the ThemedTreeWidget.
        
        Args:
            widget: The tree widget to apply themed alternate background to.
        """
        super().__init__(widget)
        self.widget: QTreeWidget = widget
        self.widget.setItemDelegate(self.AlternateBackgroundDelegate(self.widget))
        self.theme = None
        self.widget.installEventFilter(self) 

    def update(self) -> None:
        """
        Update the tree widget viewport if the theme has changed.
        """
        if self.theme != Global.theme:
            self.widget.viewport().update()
            self.theme = Global.theme

    def eventFilter(self, obj: QObject, event: QEvent) -> bool:
        """
        Filter events for the widget.
        
        Args:
            obj: The object that received the event.
            event: The event.
        
        Returns:
            True if the event was handled, False otherwise.
        """
        if obj is self.widget and event.type() == QEvent.Type.Show:
            self.update()
        return super().eventFilter(obj, event) 

class WidgetsTheme(object):
    """
    Manager class for themed widgets that automatically update when the theme changes.
    """
    themedWidgets: list[ThemedWidget | ThemedTextWidget] = []
    themedIconWidget: list[ThemedIconWidget] = []
    themedTreeWidget: list[ThemedTreeWidget] = []
    themedCodeEditor: list[ThemedCodeEditor] = []

    @classmethod
    def setWidgetStyleTheme(cls, widget: QWidget, styleSheet: BaseWidgetStyleSheet | BaseStyleSheet) -> None:
        """
        Set a themed stylesheet for a widget.
        
        Args:
            widget: The widget to apply the stylesheet to.
            styleSheet: The stylesheet to apply.
        """
        for themedWidget in cls.themedWidgets:
            if themedWidget.widget == widget:
                if str(styleSheet) != str(themedWidget.styleSheet):
                    themedWidget.styleSheet = styleSheet
                    themedWidget.widget.setStyleSheet(str(styleSheet))
                    return
        cls.themedWidgets.append(ThemedWidget(widget, styleSheet))

    @classmethod
    def setIcon(cls, widget: QPushButton | QLabel, callableIcon: Callable, hoverCallableIcon: Callable | None = None, pixmapSize: int | None = None) -> None:
        """
        Set themed icons for a widget.
        
        Args:
            widget: The widget to apply icons to.
            callableIcon: Callable that returns the default icon.
            hoverCallableIcon: Optional callable that returns the hover icon. Defaults to None.
            pixmapSize: Optional pixmap size for QLabel. Defaults to None.
        """
        for themedIconWidget in cls.themedIconWidget:
            if themedIconWidget.widget == widget:
                themedIconWidget.updateData(callableIcon, hoverCallableIcon, pixmapSize)
                return
        cls.themedIconWidget.append(ThemedIconWidget(widget, callableIcon, hoverCallableIcon, pixmapSize))

    @classmethod
    def toggleIconActive(cls, widget: QPushButton | QLabel) -> None:
        """
        Toggle the active state of an icon widget.
        
        Args:
            widget: The widget whose icon active state should be toggled.
        """
        for themedIconWidget in cls.themedIconWidget:
            if themedIconWidget.widget == widget:
                themedIconWidget.toggleActive()

    @classmethod
    def setTreeWidgetAlternateBackgroundColor(cls, widget: QTreeWidget) -> None:
        """
        Set alternate background color for a tree widget.
        
        Args:
            widget: The tree widget to apply alternate background to.
        """
        widget.destroyed
        for themedTreeWidget in cls.themedTreeWidget:
            if themedTreeWidget.widget == widget:
                return
        cls.themedTreeWidget.append(ThemedTreeWidget(widget))

    @classmethod
    def setCodeEditorWidget(cls, widget: QWidget) -> None:
        """
        Set a code editor widget for theme updates.
        
        Args:
            widget: The code editor widget.
        """
        cls.themedCodeEditor.append(ThemedCodeEditor(widget))

    @classmethod
    def update(cls) -> None:
        """
        Update all themed widgets and remove destroyed ones.
        """
        # Filter destroyed widgets
        destroyedThemedWidgets = []
        destroyedThemedIconWidgets = []
        destroyedThemedTreeWidgets = []
        destroyedThemedCodeEditors = []
        for themedWidget in cls.themedWidgets:
            try:
                if themedWidget.widget.isVisible():
                    themedWidget.updateStyle()
            except:
                destroyedThemedWidgets.append(themedWidget)
        for destroyedWidget in destroyedThemedWidgets:
            cls.themedWidgets.remove(destroyedWidget)

        for themedIconWidget in cls.themedIconWidget:
            try:
                if themedIconWidget.widget.isVisible():
                    themedIconWidget.updateIcon()
            except:
                destroyedThemedIconWidgets.append(themedIconWidget)
        for destroyedWidget in destroyedThemedIconWidgets:
            cls.themedIconWidget.remove(destroyedWidget)

        for themedTreeWidget in cls.themedTreeWidget:
            try:
                if themedTreeWidget.widget.isVisible():
                    themedTreeWidget.update()
            except:
                destroyedThemedTreeWidgets.append(themedTreeWidget)
        for destroyedWidget in destroyedThemedTreeWidgets:
            cls.themedTreeWidget.remove(destroyedWidget)

        for themedCodeEditor in cls.themedCodeEditor:
            try:
                if themedCodeEditor.widget.isVisible():
                    themedCodeEditor.update()
            except:
                destroyedThemedCodeEditors.append(themedCodeEditor)
        for destroyedWidget in destroyedThemedCodeEditors:
            cls.themedCodeEditor.remove(destroyedWidget)