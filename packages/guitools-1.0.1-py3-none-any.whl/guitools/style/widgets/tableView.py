from .base import BaseWidgetStyleSheet, BaseStyleSheet, BaseColor, BaseProperty
from .comboBox import ComboBoxStyleCheet
from .progressBar import ProgressBarStyleSheet
from .lineEdit import LineEditStyleCheet
from .box import DoubleSpinBoxStyleSheet, SpinBoxStyleSheet
from .scrollBar import ScrollBarStyleSheet
from ..utils import Global

class BaseTableView(BaseStyleSheet):
    """
    Base stylesheet for table view widgets.
    """
    def __init__(self, className: str, prefix: str = "") -> None:
        """
        Initialize the BaseTableView.
        
        Args:
            className: The CSS class name.
            prefix: The CSS selector prefix. Defaults to "".
        """
        super().__init__(className, prefix)
        self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.table)
        self.gridlineColor = BaseProperty.Color(BaseColor.division, 'gridline')
        self.selectionColor = BaseProperty.Color(Global.appColor, 'selection')
        self.selectionBackgroundColor = BaseProperty.BackgroundColor(BaseColor.tableSelectionBackground, 'selection')
        self.border = BaseProperty.Border(radius=5)
        self.padding = BaseProperty.Padding(value=0)
        self.margin = BaseProperty.Margin(value=0)

class TableViewStyleSheet(BaseWidgetStyleSheet):
    """
    Stylesheet for QTableView widget.
    """
    def __init__(self, *, singleBackgroundColor: BaseColor | None = None, prefix: str = "") -> None:
        """
        Initialize the TableViewStyleSheet.
        
        Args:
            singleBackgroundColor: Optional single background color for all elements. Defaults to None.
            prefix: The CSS selector prefix. Defaults to "".
        """
        super().__init__(f"{prefix} QTableView")
        self.tableView = self.TableView(prefix)
        self.tableWidgetItem = self.TableWidgetItem(prefix)
        self.itemFocus = self.ItemFocus(prefix)
        self.itemHover = self.ItemHover(prefix)
        self.itemSelected = self.ItemSelected(prefix)
        self.itemAlternate = self.ItemAlternate(prefix)
        self.itemAlternateHover = self.ItemAlternateHover(prefix)
        self.itemAlternateSelectedHover = self.ItemAlternateSelectedHover(prefix)
        self.progressBar = self.ProgressBar(prefix)
        self.label = self.Label(prefix)
        self.comboBox = self.ComboBox(prefix)
        self.comboBoxAbstractItemView = self.ComboBoxAbstractItemView(prefix)
        self.comboBoxOn = self.ComboBoxOn(prefix)
        self.comboBoxHover = self.ComboBoxHover(prefix)
        self.checkBox = self.CheckBox(prefix)
        self.lineEdit = self.LineEdit(prefix)
        self.pushButton = self.PushButton(prefix)
        self.toolButton = self.ToolButton(prefix)
        self.spinBox = self.SpinBox(prefix)
        self.doubleSpinBox = self.DoubleSpinBox(prefix)

        self.scrollBarHorizontal = self.ScrollBarHorizontal(prefix)
        self.scrollBarVertical = self.ScrollBarVertical(prefix)

        if singleBackgroundColor:
            self.tableView.backgroundColor.value = singleBackgroundColor
            self.itemHover.backgroundColor.value = singleBackgroundColor
            self.itemSelected.backgroundColor.value = singleBackgroundColor
            self.itemFocus.backgroundColor.value = singleBackgroundColor
            self.itemAlternate.backgroundColor.value = singleBackgroundColor
            self.itemAlternateHover.backgroundColor.value = singleBackgroundColor
            self.itemAlternateSelectedHover.backgroundColor.value = singleBackgroundColor
            self.scrollBarHorizontal.backgroundColor.value = singleBackgroundColor
            self.scrollBarVertical.backgroundColor.value = singleBackgroundColor
        
    class ScrollBarHorizontal(ScrollBarStyleSheet.Horizontal):
        """
        TableView horizontal scrollbar stylesheet.
        """
        def __init__(self,  prefix=""):
            """
            Initialize the ScrollBarHorizontal stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__(f'{prefix} QTableView')
            self.backgroundColor.value = BaseColor.table
          
    class ScrollBarVertical(ScrollBarStyleSheet.Vertical):
        """
        TableView vertical scrollbar stylesheet.
        """
        def __init__(self,  prefix=""):
            """
            Initialize the ScrollBarVertical stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__(f'{prefix} QTableView')
            self.backgroundColor.value = BaseColor.table
          
    class TableView(BaseTableView):
        """
        TableView base stylesheet.
        """
        def __init__(self, prefix=""):
            """
            Initialize the TableView stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QTableView', prefix)
            self.addAdditionalStyle('border-collapse: collapse;')

    class ItemFocus(BaseStyleSheet):
        """
        TableView item focus state stylesheet.
        """
        def __init__(self, prefix=""):
            """
            Initialize the ItemFocus stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QTableWidget::item:focus', prefix)
            self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.tableSelectionBackground)

    class ItemAlternate(BaseStyleSheet):
        """
        TableView alternate item stylesheet.
        """
        def __init__(self, prefix=""):
            """
            Initialize the ItemAlternate stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QTableWidget::item:alternate', prefix)
            self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.tableAlternate)
  
    class ItemSelected(BaseStyleSheet):
        """
        TableView item selected state stylesheet.
        """
        def __init__(self, prefix=""):
            """
            Initialize the ItemSelected stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QTableWidget::item:selected', prefix)
            self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.tableSelectionBackground)

    class ItemAlternateHover(BaseStyleSheet):
        """
        TableView alternate item hover state stylesheet.
        """
        def __init__(self, prefix=""):
            """
            Initialize the ItemAlternateHover stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QTableWidget::item:alternate:hover', prefix)
            self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.tableAlternate)

    class ItemAlternateSelectedHover(BaseStyleSheet):
        """
        TableView alternate item selected and hover state stylesheet.
        """
        def __init__(self, prefix=""):
            """
            Initialize the ItemAlternateSelectedHover stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QTableWidget::item:alternate:selected:hover', prefix)
            self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.tableSelectionBackground)

    class ItemHover(BaseStyleSheet):
        """
        TableView item hover state stylesheet.
        """
        def __init__(self, prefix=""):
            """
            Initialize the ItemHover stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QTableWidget::item:hover', prefix)
            self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.table)

    class TableWidgetItem(BaseStyleSheet):
        """
        TableView table widget item stylesheet.
        """
        def __init__(self, prefix=""):
            """
            Initialize the TableWidgetItem stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QTableWidgetItem', prefix)
            self.margin = BaseProperty.Margin(value=0)
            self.padding = BaseProperty.Padding(value=0)
            self.backgroundColor = BaseProperty.BackgroundColor("transparent")

    class ProgressBar(ProgressBarStyleSheet.ProgressBar):
        """
        TableView progress bar stylesheet.
        """
        def __init__(self, prefix=""):
            """
            Initialize the ProgressBar stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__(f"{prefix} QTableView")
            self.height = BaseProperty.Height(max=10)
            self.margin = BaseProperty.Margin(value=5, top=10)
            self.backgroundColor = BaseProperty.BackgroundColor("transparent")

    class Label(BaseStyleSheet):
        """
        TableView label stylesheet.
        """
        def __init__(self, prefix=""):
            """
            Initialize the Label stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QLabel', f"{prefix} QTableView")
            self.backgroundColor = BaseProperty.BackgroundColor("transparent")
            self.padding = BaseProperty.Padding(left=5)

    class ComboBox(ComboBoxStyleCheet.ComboBox):
        """
        TableView combobox stylesheet.
        """
        def __init__(self, prefix=""):
            """
            Initialize the ComboBox stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__(f"{prefix} QTableView")
            self.backgroundColor = BaseProperty.BackgroundColor("transparent")
            self.border.color = "transparent"
            self.border.radius=0
            self.margin = BaseProperty.Margin(value=0)
            self.height = BaseProperty.Height(value=27, max=27)

    class ComboBoxAbstractItemView(ComboBoxStyleCheet.AbstractItemView):
        """
        TableView combobox abstract item view stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the ComboBoxAbstractItemView stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__(f"{prefix} QTableView")
            self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.table)
     

    class ComboBoxOn(ComboBoxStyleCheet.On):
        """
        TableView combobox on state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the ComboBoxOn stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__(f"{prefix} QTableView")
            self.border.color = BaseColor.Widget.focusBorder

    class ComboBoxHover(ComboBoxStyleCheet.Hover):
        """
        TableView combobox hover state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the ComboBoxHover stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__(f"{prefix} QTableView")
            self.border.color = BaseColor.Widget.hoverBorder

    class CheckBox(BaseStyleSheet):
        """
        TableView checkbox stylesheet.
        """
        def __init__(self, prefix=""):
            """
            Initialize the CheckBox stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QCheckBox', f"{prefix} QTableView")
            self.backgroundColor = BaseProperty.BackgroundColor("transparent")
            self.margin = BaseProperty.Margin(left=5, right=5)

    class PushButton(BaseStyleSheet):
        """
        TableView push button stylesheet.
        """
        def __init__(self, prefix=""):
            """
            Initialize the PushButton stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QPushButton', f"{prefix} QTableView")
            self.border = BaseProperty.Border(radius=2)
            self.margin = BaseProperty.Margin(value=2)

    class ToolButton(BaseStyleSheet):
        """
        TableView tool button stylesheet.
        """
        def __init__(self, prefix=""):
            """
            Initialize the ToolButton stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QToolButton', f"{prefix} QTableView")
            self.border = BaseProperty.Border(radius=2)
            self.margin = BaseProperty.Margin(value=2)

    class LineEdit(LineEditStyleCheet):
        """
        TableView line edit stylesheet.
        """
        def __init__(self, prefix=""):
            """
            Initialize the LineEdit stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__(prefix=f'{prefix} QTableView')
            self.lineEdit.border.radius = 0
            self.lineEdit.padding = BaseProperty.Padding(left=5, right=5)
            self.lineEdit.height = BaseProperty.Height(value=28, max=28)
            self.hover.border.radius = 0
            self.focus.border.radius = 0

    class SpinBox(SpinBoxStyleSheet):
        """
        TableView spin box stylesheet.
        """
        def __init__(self, prefix=""):
            """
            Initialize the SpinBox stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__(prefix=f'{prefix} QTableView')
            self.spinBox.border.radius = 0
            self.hover.border.radius = 0
            self.focus.border.radius = 0

    class DoubleSpinBox(DoubleSpinBoxStyleSheet):
        """
        TableView double spin box stylesheet.
        """
        def __init__(self, prefix=""):
            """
            Initialize the DoubleSpinBox stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__(prefix=f'{prefix} QTableView')
            self.doubleSpinBox.border.radius = 0
            self.hover.border.radius = 0
            self.focus.border.radius = 0
            

         