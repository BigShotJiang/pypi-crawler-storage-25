from .base import BaseWidgetStyleSheet, BaseStyleSheet, BaseColor, BaseProperty

class ProgressBarStyleSheet(BaseWidgetStyleSheet):
    """
    Stylesheet for QProgressBar widget.
    """

    def __init__(self, prefix: str = "") -> None:
        """
        Initialize the ProgressBarStyleSheet.
        
        Args:
            prefix: The CSS selector prefix. Defaults to "".
        """
        super().__init__(f"{prefix} QProgressBar")
        self.progressBar = self.ProgressBar(prefix)
        self.chunk = self.Chunk(prefix)

    class ProgressBar(BaseStyleSheet):
        """
        ProgressBar base stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the ProgressBar stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QProgressBar', prefix)
            self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.ProgressBar.background)
            self.color = BaseProperty.Color(BaseColor.Reverse.secondary)
            self.border = BaseProperty.Border(radius=3, color=BaseColor.Button.hoverBorder)
            self.textAlign = BaseProperty.TextAlign('left')

    class Chunk(BaseStyleSheet):
        """
        ProgressBar chunk (progress indicator) stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the Chunk stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QProgressBar::chunk', prefix)
            self.border = BaseProperty.Border(bottomRightRadius=2, topRightRadius=2)
            self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.ProgressBar.chunkBackground)




