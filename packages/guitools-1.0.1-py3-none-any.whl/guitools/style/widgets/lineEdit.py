from .base import BaseWidgetStyleSheet, BaseStyleSheet, BaseColor, BaseProperty

class LineEditStyleCheet(BaseWidgetStyleSheet):
    """
    Stylesheet for QLineEdit widget.
    """
    def __init__(self, prefix: str = "", *, transparent: bool = False, border: bool = True) -> None:
        """
        Initialize the LineEditStyleCheet.
        
        Args:
            prefix: The CSS selector prefix. Defaults to "".
            transparent: Whether the line edit is transparent. Defaults to False.
            border: Whether to show border. Defaults to True.
        """
        super().__init__(f"{prefix} QLineEdit")
        self.lineEdit = self.LineEdit(transparent=transparent, border=border, prefix=prefix)
        self.hover = self.Hover(border=border, prefix=prefix)
        self.focus = self.Focus(border=border, prefix=prefix)
        self.hoverFocus = self.HoverFocus(border=border, prefix=prefix)
   
    class LineEdit(BaseStyleSheet):
        """
        LineEdit base stylesheet.
        """
        def __init__(self, *, transparent: bool = False, border: bool = True, prefix: str = "") -> None:
            """
            Initialize the LineEdit stylesheet.
            
            Args:
                transparent: Whether the line edit is transparent. Defaults to False.
                border: Whether to show border. Defaults to True.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QLineEdit', prefix)
            self.padding = BaseProperty.Padding(value=0)
            if border:
                self.border = BaseProperty.Border(color=BaseColor.Widget.background, radius=5)
            else:
                self.border = BaseProperty.Border(width=0, color='transparent', radius=5)

            self.height = BaseProperty.Height(value=25)
            self.selectionColor = BaseProperty.Color(BaseColor.Reverse.primary, 'selection')
            if transparent:
                self.backgroundColor = BaseProperty.BackgroundColor('transparent')
            else:
                self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.Widget.background)
            self.selectionBackgroundColor = BaseProperty.BackgroundColor(BaseColor.Widget.selectedBackground, 'selection')
         
    class Hover(BaseStyleSheet):
        """
        LineEdit hover state stylesheet.
        """
        def __init__(self, *, border: bool = True, prefix: str = "") -> None:
            """
            Initialize the Hover stylesheet.
            
            Args:
                border: Whether to show border. Defaults to True.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QLineEdit:hover', prefix)
            if border:
                self.border = BaseProperty.Border(color=BaseColor.Widget.hoverBorder, radius=5)
            else:
                self.border = BaseProperty.Border(width=0, color='transparent', radius=5)

    class Focus(BaseStyleSheet):
        """
        LineEdit focus state stylesheet.
        """
        def __init__(self, *, border: bool = True, prefix: str = "") -> None:
            """
            Initialize the Focus stylesheet.
            
            Args:
                border: Whether to show border. Defaults to True.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QLineEdit:focus', prefix)
            if border:
                self.border = BaseProperty.Border(color=BaseColor.Widget.focusBorder)
            else:
                self.border = BaseProperty.Border(width=0, color='transparent')

    class HoverFocus(BaseStyleSheet):
        """
        LineEdit hover and focus state stylesheet.
        """
        def __init__(self, *, border: bool = True, prefix: str = "") -> None:
            """
            Initialize the HoverFocus stylesheet.
            
            Args:
                border: Whether to show border. Defaults to True.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QLineEdit:hover:focus', prefix)
            if border:
                self.border = BaseProperty.Border(color=BaseColor.Widget.focusBorder)
            else:
                self.border = BaseProperty.Border(width=0, color='transparent')

        