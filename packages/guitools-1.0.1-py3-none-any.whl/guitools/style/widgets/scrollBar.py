from .base import BaseWidgetStyleSheet, BaseStyleSheet, BaseColor, BaseProperty, StyleSheets


class ScrollBarStyleSheet(BaseWidgetStyleSheet):
    """
    Stylesheet for QScrollBar widget.
    """
    def __init__(self, prefix: str = "") -> None:
        """
        Initialize the ScrollBarStyleSheet.
        
        Args:
            prefix: The CSS selector prefix. Defaults to "".
        """
        super().__init__(f"{prefix} QScrollBar")
        self.scrollBar = self.ScrollBar(prefix)
        self.upArrowVertical = self.UpArrowVertical(prefix)
        self.downArrowVertical = self.DownArrowVertical(prefix)
        self.addPageVertical = self.AddPageVertical(prefix)
        self.subPageVertical = self.SubPageVertical(prefix)
        self.upArrowHorizontal = self.UpArrowHorizontal(prefix)
        self.downArrowHorizontal = self.DownArrowHorizontal(prefix)
        self.addPageHorizontal = self.AddPageHorizontal(prefix)
        self.subPageHorizontal = self.SubPageHorizontal(prefix)
        self.addLineHorizontal = self.AddLineHorizontal(prefix)
        self.subLineHorizontal = self.SubLineHorizontal(prefix)
        self.subLineVertical = self.SubLineVertical(prefix)
        self.addLineVertical = self.AddLineVertical(prefix)
        self.handleVertical = self.HandleVertical(prefix)
        self.handleHorizontal = self.HandleHorizontal(prefix)
        self.horizontal = self.Horizontal(prefix)
        self.vertical = self.Vertical(prefix)

    class ScrollBar(BaseStyleSheet):
        """
        ScrollBar base stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the ScrollBar stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QScrollBar', prefix)
            self.backgroundColor = BaseProperty.BackgroundColor('transparent')

    class UpArrowVertical(StyleSheets.BackgroundNone):
        """
        ScrollBar vertical up arrow stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the UpArrowVertical stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QScrollBar::up-arrow:vertical', prefix)

    class DownArrowVertical(StyleSheets.BackgroundNone):
        """
        ScrollBar vertical down arrow stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the DownArrowVertical stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QScrollBar::down-arrow:vertical', prefix)

    class AddPageVertical(StyleSheets.BackgroundNone):
        """
        ScrollBar vertical add page stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the AddPageVertical stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QScrollBar::add-page:vertical', prefix)

    class SubPageVertical(StyleSheets.BackgroundNone):
        """
        ScrollBar vertical sub page stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the SubPageVertical stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QScrollBar::sub-page:vertical', prefix)

    class UpArrowHorizontal(StyleSheets.BackgroundNone):
        """
        ScrollBar horizontal up arrow stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the UpArrowHorizontal stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QScrollBar::up-arrow:horizontal', prefix)

    class DownArrowHorizontal(StyleSheets.BackgroundNone):
        """
        ScrollBar horizontal down arrow stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the DownArrowHorizontal stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QScrollBar::down-arrow:horizontal', prefix)

    class AddPageHorizontal(StyleSheets.BackgroundNone):
        """
        ScrollBar horizontal add page stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the AddPageHorizontal stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QScrollBar::add-page:horizontal', prefix)

    class SubPageHorizontal(StyleSheets.BackgroundNone):
        """
        ScrollBar horizontal sub page stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the SubPageHorizontal stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QScrollBar::sub-page:horizontal', prefix)
       
    class AddLineHorizontal(StyleSheets.WidthAndHeight):
        """
        ScrollBar horizontal add line stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the AddLineHorizontal stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QScrollBar::add-line:horizontal', prefix)

    class SubLineHorizontal(StyleSheets.WidthAndHeight):
        """
        ScrollBar horizontal sub line stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the SubLineHorizontal stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QScrollBar::sub-line:horizontal', prefix)

    class SubLineVertical(StyleSheets.WidthAndHeight):
        """
        ScrollBar vertical sub line stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the SubLineVertical stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QScrollBar::sub-line:vertical', prefix)

    class AddLineVertical(StyleSheets.WidthAndHeight):
        """
        ScrollBar vertical add line stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the AddLineVertical stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QScrollBar::add-line:vertical', prefix)

    class HandleVertical(BaseStyleSheet):
        """
        ScrollBar vertical handle stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the HandleVertical stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QScrollBar::handle:vertical', prefix)
            self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.tertiary)
            self.height = BaseProperty.Height(min=20)
            self.border = BaseProperty.Border(radius=3)

    class HandleHorizontal(BaseStyleSheet):
        """
        ScrollBar horizontal handle stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the HandleHorizontal stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QScrollBar::handle:horizontal', prefix)
            self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.tertiary)
            self.width = BaseProperty.Width(min=20)
            self.border = BaseProperty.Border(radius=3)
           
    class Horizontal(BaseStyleSheet):
        """
        ScrollBar horizontal orientation stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the Horizontal stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QScrollBar:horizontal', prefix)
            self.height = BaseProperty.Height(value=10)
            self.backgroundColor = BaseProperty.BackgroundColor('transparent')
            self.border = BaseProperty.Border(radius=3)
            self.padding = BaseProperty.Padding(value=2)

    class Vertical(BaseStyleSheet):
        """
        ScrollBar vertical orientation stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the Vertical stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QScrollBar:vertical', prefix)
            self.width = BaseProperty.Width(value=10)
            self.backgroundColor = BaseProperty.BackgroundColor('transparent')
            self.border = BaseProperty.Border(radius=3)
            self.padding = BaseProperty.Padding(value=2)

class ScrollAreaStyleSheet(ScrollBarStyleSheet):
    """
    Stylesheet for QScrollArea widget.
    """
    def __init__(self, prefix: str = "") -> None:
        """
        Initialize the ScrollAreaStyleSheet.
        
        Args:
            prefix: The CSS selector prefix. Defaults to "".
        """
        super().__init__(f"{prefix} QScrollArea")
        self.vertical.backgroundColor.value = BaseColor.primary
        self.horizontal.backgroundColor.value = BaseColor.primary





