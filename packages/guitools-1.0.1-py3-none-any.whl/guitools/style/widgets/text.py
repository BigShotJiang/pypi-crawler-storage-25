from .base import BaseWidgetStyleSheet, BaseStyleSheet, BaseColor, BaseProperty
from .scrollBar import ScrollBarStyleSheet

class BaseTextStyleSheet(object):
    """
    Base stylesheet classes for text editing widgets.
    """
    
    class Text(BaseStyleSheet):
        """
        Base text stylesheet.
        """
        def __init__(self, className: str, border: bool, prefix: str) -> None:
            """
            Initialize the Text stylesheet.
            
            Args:
                className: The CSS class name.
                border: Whether to show border.
                prefix: The CSS selector prefix.
            """
            super().__init__(className, prefix)
            self.padding = BaseProperty.Padding(left=4)
            self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.Widget.background)
            self.selectionBackgroundColor = BaseProperty.BackgroundColor(BaseColor.Widget.selectedBackground, 'selection')
            self.selectionColor = BaseProperty.Color(BaseColor.Reverse.primary, 'selection')
            self.color = BaseProperty.Color(BaseColor.Reverse.primary)
            self.font = BaseProperty.FontSegoeUI(12)
            if border:
                self.border = BaseProperty.Border(radius=5, color='transparent', style='outset')
            else:
                 self.border = BaseProperty.Border(radius=5, style='outset', width=0)

    class Hover(BaseStyleSheet):
        """
        Base text hover state stylesheet.
        """
        def __init__(self, className: str, border: bool, prefix: str) -> None:
            """
            Initialize the Hover stylesheet.
            
            Args:
                className: The CSS class name.
                border: Whether to show border.
                prefix: The CSS selector prefix.
            """
            super().__init__(f'{className}:hover ', prefix)
            if border:
                self.border = BaseProperty.Border(color=BaseColor.Widget.hoverBorder)

    class HoverFocus(BaseStyleSheet):
        """
        Base text hover and focus state stylesheet.
        """
        def __init__(self, className: str, border: bool, prefix: str) -> None:
            """
            Initialize the HoverFocus stylesheet.
            
            Args:
                className: The CSS class name.
                border: Whether to show border.
                prefix: The CSS selector prefix.
            """
            super().__init__(f'{className}:hover:focus ', prefix)
            if border:
                self.border = BaseProperty.Border(color=BaseColor.Widget.focusBorder)

    class Focus(BaseStyleSheet):
        """
        Base text focus state stylesheet.
        """
        def __init__(self, className: str, border: bool, prefix: str) -> None:
            """
            Initialize the Focus stylesheet.
            
            Args:
                className: The CSS class name.
                border: Whether to show border.
                prefix: The CSS selector prefix.
            """
            super().__init__(f'{className}:focus ', prefix)
            if border:
                self.border = BaseProperty.Border(color=BaseColor.Widget.focusBorder)

    class ScrollBarHorizontal(ScrollBarStyleSheet.Horizontal):
        """
        Base text horizontal scrollbar stylesheet.
        """
        def __init__(self, className: str, prefix: str = "") -> None:
            """
            Initialize the ScrollBarHorizontal stylesheet.
            
            Args:
                className: The CSS class name.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__(f'{prefix} {className}')
            self.backgroundColor.value = BaseColor.table
           
    class ScrollBarVertical(ScrollBarStyleSheet.Vertical):
        """
        Base text vertical scrollbar stylesheet.
        """
        def __init__(self, className: str, prefix: str = "") -> None:
            """
            Initialize the ScrollBarVertical stylesheet.
            
            Args:
                className: The CSS class name.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__(f'{prefix} {className}')
            self.backgroundColor.value = BaseColor.table

class PlainTextEditStyleSheet(BaseWidgetStyleSheet):
    """
    Stylesheet for QPlainTextEdit widget.
    """
    def __init__(self, *, border: bool = False, prefix: str = "") -> None:
        """
        Initialize the PlainTextEditStyleSheet.
        
        Args:
            border: Whether to show border. Defaults to False.
            prefix: The CSS selector prefix. Defaults to "".
        """
        super().__init__(f"{prefix} QPlainTextEdit")
        self.plainTextEdit = self.PlainTextEdit(border=border, prefix=prefix)
        self.hover = self.Hover(border=border, prefix=prefix)
        self.focus = self.Focus(border=border, prefix=prefix)
        self.hoverFocus = self.HoverFocus(border=border, prefix=prefix)
        self.scrollBarHorizontal = self.ScrollBarHorizontal(prefix=prefix)
        self.scrollBarVertical = self.ScrollBarVertical(prefix=prefix)
     
    class PlainTextEdit(BaseTextStyleSheet.Text):
        """
        PlainTextEdit base stylesheet.
        """
        def __init__(self, *, border: bool = False, prefix: str = "") -> None:
            """
            Initialize the PlainTextEdit stylesheet.
            
            Args:
                border: Whether to show border. Defaults to False.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QPlainTextEdit", border, prefix)

    class Hover(BaseTextStyleSheet.Hover):
        """
        PlainTextEdit hover state stylesheet.
        """
        def __init__(self, *, border: bool = False, prefix: str = "") -> None:
            """
            Initialize the Hover stylesheet.
            
            Args:
                border: Whether to show border. Defaults to False.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QPlainTextEdit", border, prefix)

    class Focus(BaseTextStyleSheet.Focus):
        """
        PlainTextEdit focus state stylesheet.
        """
        def __init__(self, *, border: bool = False, prefix: str = "") -> None:
            """
            Initialize the Focus stylesheet.
            
            Args:
                border: Whether to show border. Defaults to False.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QPlainTextEdit", border, prefix)

    class HoverFocus(BaseTextStyleSheet.HoverFocus):
        """
        PlainTextEdit hover and focus state stylesheet.
        """
        def __init__(self, *, border: bool = False, prefix: str = "") -> None:
            """
            Initialize the HoverFocus stylesheet.
            
            Args:
                border: Whether to show border. Defaults to False.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QPlainTextEdit", border, prefix)

    class ScrollBarHorizontal(BaseTextStyleSheet.ScrollBarHorizontal):
        """
        PlainTextEdit horizontal scrollbar stylesheet.
        """
        def __init__(self, *, prefix: str = "") -> None:
            """
            Initialize the ScrollBarHorizontal stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QPlainTextEdit", prefix)

    class ScrollBarVertical(BaseTextStyleSheet.ScrollBarVertical):
        """
        PlainTextEdit vertical scrollbar stylesheet.
        """
        def __init__(self, *, prefix: str = "") -> None:
            """
            Initialize the ScrollBarVertical stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QPlainTextEdit", prefix)
           
class TextEditStyleSheet(BaseWidgetStyleSheet):
    """
    Stylesheet for QTextEdit widget.
    """
    def __init__(self, *, border: bool = False, prefix: str = "") -> None:
        """
        Initialize the TextEditStyleSheet.
        
        Args:
            border: Whether to show border. Defaults to False.
            prefix: The CSS selector prefix. Defaults to "".
        """
        super().__init__(f"{prefix} QTextEdit")
        self.textEdit = self.TextEdit(border=border, prefix=prefix)
        self.hover = self.Hover(border=border, prefix=prefix)
        self.focus = self.Focus(border=border, prefix=prefix)
        self.hoverFocus = self.HoverFocus(border=border, prefix=prefix)
        self.scrollBarHorizontal = self.ScrollBarHorizontal(prefix=prefix)
        self.scrollBarVertical = self.ScrollBarVertical(prefix=prefix)
     
    class TextEdit(BaseTextStyleSheet.Text):
        """
        TextEdit base stylesheet.
        """
        def __init__(self, *, border: bool = False, prefix: str = "") -> None:
            """
            Initialize the TextEdit stylesheet.
            
            Args:
                border: Whether to show border. Defaults to False.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QTextEdit", border, prefix)

    class Hover(BaseTextStyleSheet.Hover):
        """
        TextEdit hover state stylesheet.
        """
        def __init__(self, *, border: bool = False, prefix: str = "") -> None:
            """
            Initialize the Hover stylesheet.
            
            Args:
                border: Whether to show border. Defaults to False.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QTextEdit", border, prefix)

    class Focus(BaseTextStyleSheet.Focus):
        """
        TextEdit focus state stylesheet.
        """
        def __init__(self, *, border: bool = False, prefix: str = "") -> None:
            """
            Initialize the Focus stylesheet.
            
            Args:
                border: Whether to show border. Defaults to False.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QTextEdit", border, prefix)

    class HoverFocus(BaseTextStyleSheet.HoverFocus):
        """
        TextEdit hover and focus state stylesheet.
        """
        def __init__(self, *, border: bool = False, prefix: str = "") -> None:
            """
            Initialize the HoverFocus stylesheet.
            
            Args:
                border: Whether to show border. Defaults to False.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QTextEdit", border, prefix)

    class ScrollBarHorizontal(BaseTextStyleSheet.ScrollBarHorizontal):
        """
        TextEdit horizontal scrollbar stylesheet.
        """
        def __init__(self, *, prefix: str = "") -> None:
            """
            Initialize the ScrollBarHorizontal stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QTextEdit", prefix)

    class ScrollBarVertical(BaseTextStyleSheet.ScrollBarVertical):
        """
        TextEdit vertical scrollbar stylesheet.
        """
        def __init__(self, *, prefix: str = "") -> None:
            """
            Initialize the ScrollBarVertical stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QTextEdit", prefix)


class TextBrowserStyleSheet(BaseWidgetStyleSheet):
    """
    Stylesheet for QTextBrowser widget.
    """
    def __init__(self, *, border: bool = False, prefix: str = "") -> None:
        """
        Initialize the TextBrowserStyleSheet.
        
        Args:
            border: Whether to show border. Defaults to False.
            prefix: The CSS selector prefix. Defaults to "".
        """
        super().__init__(f"{prefix} QTextBrowser")
        self.textBrowser = self.TextBrowser(border=border, prefix=prefix)
        self.hover = self.Hover(border=border, prefix=prefix)
        self.focus = self.Focus(border=border, prefix=prefix)
        self.hoverFocus = self.HoverFocus(border=border, prefix=prefix)
        self.scrollBarHorizontal = self.ScrollBarHorizontal(prefix=prefix)
        self.scrollBarVertical = self.ScrollBarVertical(prefix=prefix)
   
    class TextBrowser(BaseTextStyleSheet.Text):
        """
        TextBrowser base stylesheet.
        """
        def __init__(self, *, border: bool = False, prefix: str = "") -> None:
            """
            Initialize the TextBrowser stylesheet.
            
            Args:
                border: Whether to show border. Defaults to False.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QTextBrowser", border, prefix)

    class Hover(BaseTextStyleSheet.Hover):
        """
        TextBrowser hover state stylesheet.
        """
        def __init__(self, *, border: bool = False, prefix: str = "") -> None:
            """
            Initialize the Hover stylesheet.
            
            Args:
                border: Whether to show border. Defaults to False.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QTextBrowser", border, prefix)

    class Focus(BaseTextStyleSheet.Focus):
        """
        TextBrowser focus state stylesheet.
        """
        def __init__(self, *, border: bool = False, prefix: str = "") -> None:
            """
            Initialize the Focus stylesheet.
            
            Args:
                border: Whether to show border. Defaults to False.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QTextBrowser", border, prefix)

    class HoverFocus(BaseTextStyleSheet.HoverFocus):
        """
        TextBrowser hover and focus state stylesheet.
        """
        def __init__(self, *, border: bool = False, prefix: str = "") -> None:
            """
            Initialize the HoverFocus stylesheet.
            
            Args:
                border: Whether to show border. Defaults to False.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QTextBrowser", border, prefix)

    class ScrollBarHorizontal(BaseTextStyleSheet.ScrollBarHorizontal):
        """
        TextBrowser horizontal scrollbar stylesheet.
        """
        def __init__(self, *, prefix: str = "") -> None:
            """
            Initialize the ScrollBarHorizontal stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QTextBrowser", prefix)

    class ScrollBarVertical(BaseTextStyleSheet.ScrollBarVertical):
        """
        TextBrowser vertical scrollbar stylesheet.
        """
        def __init__(self, *, prefix: str = "") -> None:
            """
            Initialize the ScrollBarVertical stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QTextBrowser", prefix)
