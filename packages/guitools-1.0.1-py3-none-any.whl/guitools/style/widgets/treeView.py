from .base import BaseWidgetStyleSheet, BaseStyleSheet, BaseColor, BaseProperty
from .checkBox import indicatorStyleCheet
from .scrollBar import ScrollBarStyleSheet

class BaseTreeView(BaseStyleSheet):
    """
    Base stylesheet for tree view widgets.
    """
    def __init__(self, className: str, prefix: str = "") -> None:
        """
        Initialize the BaseTreeView.
        
        Args:
            className: The CSS class name.
            prefix: The CSS selector prefix. Defaults to "".
        """
        super().__init__(className, prefix)
        self.font = BaseProperty.FontSegoeUI(12)
        self.border = BaseProperty.Border(radius=5)
        self.padding = BaseProperty.Padding(value=0)
        self.margin = BaseProperty.Margin(value=0)

class TreeViewStyleSheet(BaseWidgetStyleSheet):
    """
    Stylesheet for QTreeView and QTreeWidget widgets.
    """

    def __init__(self, *, prefix: str = "", singleBackgroundColor: BaseColor | None = None, scrollBarHandleColor: BaseColor | None = None) -> None:
        """
        Initialize the TreeViewStyleSheet.
        
        Args:
            prefix: The CSS selector prefix. Defaults to "".
            singleBackgroundColor: Optional single background color for all elements. Defaults to None.
            scrollBarHandleColor: Optional color for scrollbar handles. Defaults to None.
        """
        super().__init__(f"{prefix} QTreeView")
        self.widgetAction = self.WidgetAction(prefix)
        self.treeView = self.TreeView(prefix)
        self.itemOpen = self.ItemOpen(prefix)
        self.itemSelected = self.ItemSelected(prefix)
        self.itemDisabled = self.ItemDisabled(prefix)
        self.itemNotselectedDisabled = self.ItemNotselectedDisabled(prefix)
        self.itemSelectedDisabled = self.ItemSelectedDisabled(prefix)

        #self.branchHasSiblingsNotAdjoinsItem = self.BranchHasSiblingsNotAdjoinsItem()
        #self.branchHasSiblingsAdjoinsItem = self.BranchHasSiblingsAdjoinsItem()
        #self.branchHasNotSiblingsAdjoinsItem = self.BranchHasNotSiblingsAdjoinsItem()
        self.branchClosed = self.BranchClosed(prefix)
        self.branchOpen = self.BranchOpen(prefix)
      
        self.indicator = self.Indicator(prefix)
        self.label = self.Label(prefix)

        self.treeWidget = self.TreeWidget(prefix)
        self.item = self.Item(prefix)
        self.itemSelected = self.ItemSelected(prefix)
        self.itemFocus = self.ItemFocus(prefix)
        self.itemHover = self.ItemHover(prefix)
        self.itemSelectedHover = self.ItemSelectedHover(prefix)
        self.itemNotselected = self.ItemNotselected(prefix)
        self.itemNotselectedHover = self.ItemNotselectedHover(prefix)

        self.scrollBarHorizontal = self.ScrollBarHorizontal(prefix)
        self.scrollBarVertical = self.ScrollBarVertical(prefix)

        self.scrollBarHandleHorizontal = self.ScrollBarHandleHorizontal(prefix, scrollBarHandleColor)
        self.scrollBarHandleVertical = self.ScrollBarHandleVertical(prefix, scrollBarHandleColor)

        if singleBackgroundColor:
            self.treeView.backgroundColor.value = singleBackgroundColor
            self.treeWidget.backgroundColor.value = singleBackgroundColor
            self.item.backgroundColor.value = singleBackgroundColor
            self.itemHover.backgroundColor.value = singleBackgroundColor
            self.itemFocus.backgroundColor.value = singleBackgroundColor
            self.itemNotselected.backgroundColor.value = singleBackgroundColor
            self.itemNotselectedHover.backgroundColor.value = singleBackgroundColor
            self.scrollBarHorizontal.backgroundColor.value = singleBackgroundColor
            self.scrollBarVertical.backgroundColor.value = singleBackgroundColor
            self.itemDisabled.backgroundColor.value = singleBackgroundColor
            self.itemNotselectedDisabled.backgroundColor.value = singleBackgroundColor
            self.itemSelectedDisabled.backgroundColor.value = singleBackgroundColor

    class ScrollBarHorizontal(ScrollBarStyleSheet.Horizontal):
        """
        TreeView horizontal scrollbar stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the ScrollBarHorizontal stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__(f'{prefix} QTreeWidget')
            self.backgroundColor.value = BaseColor.table

    class ScrollBarVertical(ScrollBarStyleSheet.Vertical):
        """
        TreeView vertical scrollbar stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the ScrollBarVertical stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__(f'{prefix} QTreeWidget')
            self.backgroundColor.value = BaseColor.table

    class ScrollBarHandleVertical(ScrollBarStyleSheet.HandleVertical):
        """
        TreeView vertical scrollbar handle stylesheet.
        """
        def __init__(self, prefix: str = "", backgroundColor: BaseColor | None = None) -> None:
            """
            Initialize the ScrollBarHandleVertical stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
                backgroundColor: Optional background color for the handle. Defaults to None.
            """
            super().__init__(f'{prefix} QTreeWidget')
            self.backgroundColor = BaseProperty.BackgroundColor(backgroundColor if backgroundColor else BaseColor.tertiary)

    class ScrollBarHandleHorizontal(ScrollBarStyleSheet.HandleHorizontal):
        """
        TreeView horizontal scrollbar handle stylesheet.
        """
        def __init__(self, prefix: str = "", backgroundColor: BaseColor | None = None) -> None:
            """
            Initialize the ScrollBarHandleHorizontal stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
                backgroundColor: Optional background color for the handle. Defaults to None.
            """
            super().__init__(f'{prefix} QTreeWidget')
            self.backgroundColor = BaseProperty.BackgroundColor(backgroundColor if backgroundColor else BaseColor.tertiary)
           
    class Item(BaseStyleSheet):
        """
        TreeView item base stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the Item stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QTreeWidget::item', prefix)
            self.backgroundColor = BaseProperty.Background(BaseColor.table)
            self.color = BaseProperty.Color(value=BaseColor.Reverse.primary)

    class ItemDisabled(BaseStyleSheet):
        """
        TreeView item disabled state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the ItemDisabled stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QTreeWidget::item:disabled', prefix)
            self.backgroundColor = BaseProperty.Background(BaseColor.table)
            self.color = BaseProperty.Color(value=BaseColor.Reverse.primary.fromRgba(200))

    class ItemNotselectedDisabled(BaseStyleSheet):
        """
        TreeView item not selected and disabled state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the ItemNotselectedDisabled stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QTreeWidget::item:!selected:disabled', f"{prefix}")
            self.backgroundColor = BaseProperty.Background(BaseColor.table)
            self.color = BaseProperty.Color(value=BaseColor.Reverse.primary.fromRgba(200))

    class ItemSelectedDisabled(BaseStyleSheet):
        """
        TreeView item selected and disabled state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the ItemSelectedDisabled stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QTreeView:item:selected:disabled', prefix)
            self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.tableSelectionBackground)
            self.color = BaseProperty.Color(value=BaseColor.Reverse.selected)

    class ItemNotselected(BaseStyleSheet):
        """
        TreeView item not selected state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the ItemNotselected stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QTreeWidget::item:!selected', f"{prefix}")
            self.backgroundColor = BaseProperty.Background(BaseColor.table)
            self.color = BaseProperty.Color(value=BaseColor.Reverse.primary)

    class ItemNotselectedHover(BaseStyleSheet):
        """
        TreeView item not selected and hover state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the ItemNotselectedHover stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QTreeWidget::item:!selected:hover', f"{prefix}")
            self.backgroundColor = BaseProperty.Background(BaseColor.tableAlternate)

    class ItemFocus(BaseStyleSheet):
        """
        TreeView item focus state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the ItemFocus stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QTreeWidget::item:focus', prefix)
            self.backgroundColor = BaseProperty.Background(BaseColor.tableSelectionBackground)

    class ItemHover(BaseStyleSheet):
        """
        TreeView item hover state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the ItemHover stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QTreeWidget::item:hover', prefix)
            self.backgroundColor = BaseProperty.Background(BaseColor.tableAlternate)

    class ItemSelectedHover(BaseStyleSheet):
        """
        TreeView item selected and hover state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the ItemSelectedHover stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QTreeWidget::item:selected:hover', prefix)
            self.backgroundColor = BaseProperty.Background(BaseColor.tableSelectionBackground)

    class WidgetAction(BaseTreeView):
        """
        TreeView widget action stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the WidgetAction stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QTreeWidget QWidgetAction', prefix)

    class TreeWidget(BaseTreeView):
        """
        TreeView tree widget base stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the TreeWidget stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QTreeWidget', prefix)
            self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.table)

    class TreeView(BaseTreeView):
        """
        TreeView base stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the TreeView stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QTreeView', prefix)
            self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.table)

    class ItemOpen(BaseStyleSheet):
        """
        TreeView item open state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the ItemOpen stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QTreeView:item:open', prefix)
            self.color = BaseProperty.Color(value=BaseColor.Reverse.selected)

    class ItemSelected(BaseStyleSheet):
        """
        TreeView item selected state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the ItemSelected stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QTreeView:item:selected', prefix)
            self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.tableSelectionBackground)
            self.color = BaseProperty.Color(value=BaseColor.Reverse.selected)

    class Indicator(indicatorStyleCheet):
        """
        TreeView indicator stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the Indicator stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QTreeView", prefix)

    class Label(BaseStyleSheet):
        """
        TreeView label stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the Label stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QLabel', f"{prefix} QTreeView")
            self.backgroundColor = BaseProperty.BackgroundColor("transparent")
        
    class BranchHasSiblingsNotAdjoinsItem(BaseStyleSheet):
        """
        TreeView branch with siblings not adjoining item stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the BranchHasSiblingsNotAdjoinsItem stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QTreeView::branch:has-siblings:!adjoins-item', prefix)
            #self.image = f'border-image: url(:/{Icons.Name.add_suffix_theme(Icons.Name.vline)}) 0;'
               
    class BranchHasSiblingsAdjoinsItem(BaseStyleSheet):
        """
        TreeView branch with siblings adjoining item stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the BranchHasSiblingsAdjoinsItem stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QTreeView::branch:has-siblings:adjoins-item', prefix)
            #self.image = f'border-image: url(:/{Icons.Name.add_suffix_theme(Icons.Name.vline)}) 0;'
           
    class BranchHasNotSiblingsAdjoinsItem(BaseStyleSheet):
        """
        TreeView branch without siblings adjoining item stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the BranchHasNotSiblingsAdjoinsItem stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QTreeView::branch:!has-children:!has-siblings:adjoins-item', prefix)
            #self.image = f'border-image: url(:/{Icons.Name.add_suffix_theme(Icons.Name.branch_end)}) 0;'
            
    class BranchClosed(BaseStyleSheet):
        """
        TreeView closed branch stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the BranchClosed stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QTreeView::branch:closed:has-children', prefix)
            self.image = BaseProperty.Image('branch_closed.png')
            self.addAdditionalStyle("border-image: none;")

    class BranchOpen(BaseStyleSheet):
        """
        TreeView open branch stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the BranchOpen stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QTreeView::branch:open:has-children', prefix)
            self.image = BaseProperty.Image('branch_open.png')
            self.addAdditionalStyle("border-image: none;")

    



