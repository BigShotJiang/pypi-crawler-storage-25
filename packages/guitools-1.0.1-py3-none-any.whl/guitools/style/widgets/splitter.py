from .base import BaseWidgetStyleSheet, BaseStyleSheet, BaseColor, BaseProperty

class SplitterStyleSheet(BaseWidgetStyleSheet):
    """
    Stylesheet for QSplitter widget.
    
    Provides styles for horizontal and vertical splitter handles with gradient backgrounds.
    """

    def __init__(self, *, handleBackgroundColor: BaseColor = BaseColor.tertiary, prefix: str = "") -> None:
        """
        Initialize the SplitterStyleSheet.
        
        Args:
            handleBackgroundColor: Background color for the handle. Defaults to BaseColor.tertiary.
            prefix: The CSS selector prefix. Defaults to "".
        """
        super().__init__(f"{prefix} QSplitter")
        self.handleHorizontal = self.HandleHorizontal(handleBackgroundColor, prefix)
        self.handleVertical = self.HandleVertical(handleBackgroundColor, prefix)

    class HandleHorizontal(BaseStyleSheet):
        """
        Splitter horizontal handle stylesheet.
        """
        def __init__(self, handleBackgroundColor: BaseColor = BaseColor.tertiary, prefix: str = "") -> None:
            """
            Initialize the HandleHorizontal stylesheet.
            
            Args:
                handleBackgroundColor: Background color for the handle. Defaults to BaseColor.tertiary.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QSplitter::handle:horizontal', prefix)
            self.backgroundColor = BaseProperty.BackgroundColor(value=f'''
            background-color: qlineargradient(spread: pad, x1: 0, y1: 1, x2: 0, y2: 0,
                    stop: 0 rgba(255, 255, 255, 0),
                    stop: 0.407273 {BaseColor.tertiary.rgba},
                    stop: 0.6825 {BaseColor.tertiary.fromRgba(230)},
                    stop: 1 rgba(255, 255, 255, 0)
                )''')
            self.padding = BaseProperty.Padding(value=1)
            
    class HandleVertical(BaseStyleSheet):
        """
        Splitter vertical handle stylesheet.
        """
        def __init__(self, handleBackgroundColor: BaseColor = BaseColor.tertiary, prefix: str = "") -> None:
            """
            Initialize the HandleVertical stylesheet.
            
            Args:
                handleBackgroundColor: Background color for the handle. Defaults to BaseColor.tertiary.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QSplitter::handle:vertical', prefix)
            self.backgroundColor = BaseProperty.BackgroundColor(value=f'''
            background-color: qlineargradient(spread: pad, x1: 1, y1: 0, x2: 0, y2: 0,
                    stop: 0 rgba(255, 255, 255, 0),
                    stop: 0.407273 {BaseColor.tertiary.rgba},
                    stop: 0.6825 {BaseColor.tertiary.fromRgba(230)},
                    stop: 1 rgba(255, 255, 255, 0)
                )''')
            self.padding = BaseProperty.Padding(value=1)

