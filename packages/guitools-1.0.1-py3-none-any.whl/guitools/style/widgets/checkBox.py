from .base import BaseWidgetStyleSheet, BaseStyleSheet, BaseColor, BaseProperty
from ..utils import Global
from PySide6.QtGui import QColor

def fromRgba(colorStr: str, alpha: int) -> str:
    """
    Convert a color string to rgba format with a specified alpha value.
    
    Args:
        colorStr: Color string in hex, rgb, or rgba format.
        alpha: Alpha value (0-255).
    
    Returns:
        Color string in rgba format.
    """
    processedColorStr = colorStr.strip()

    # If it's hexadecimal
    if processedColorStr.startswith('#'):
        color = QColor(processedColorStr)
        return f"rgba({color.red()}, {color.green()}, {color.blue()}, {alpha})"

    # If it's rgba
    if processedColorStr.startswith('rgba'):
        colorParts = processedColorStr[processedColorStr.find('(') + 1 : processedColorStr.find(')')].split(',')
        if len(colorParts) >= 3:
            red, green, blue = [int(part.strip()) for part in colorParts[:3]]
            return f"rgba({red}, {green}, {blue}, {alpha})"

    # If it's rgb
    if processedColorStr.startswith('rgb'):
        colorParts = processedColorStr[processedColorStr.find('(') + 1 : processedColorStr.find(')')].split(',')
        if len(colorParts) >= 3:
            red, green, blue = [int(part.strip()) for part in colorParts[:3]]
            return f"rgba({red}, {green}, {blue}, {alpha})"
        
    return processedColorStr

class indicatorStyleCheet(BaseWidgetStyleSheet):
    """
    Base stylesheet for checkbox/radio button indicators.
    """
    def __init__(self, className: str, prefix: str = "") -> None:
        """
        Initialize the indicatorStyleCheet.
        
        Args:
            className: The CSS class name.
            prefix: The CSS selector prefix. Defaults to "".
        """
        super().__init__(f"{prefix} {className}")
        self.widget = self.Widget(className, prefix)
        self.indicator = self.Indicator(className, prefix)
        self.indicatorHover = self.IndicatorHover(className, prefix)
        self.indicatorChecked = self.IndicatorChecked(className, prefix)
        self.indicatorCheckedHover = self.IndicatorCheckedHover(className, prefix)

    class Widget(BaseStyleSheet):
        """
        Widget base stylesheet.
        """
        def __init__(self, className: str, prefix: str = "") -> None:
            """
            Initialize the Widget stylesheet.
            
            Args:
                className: The CSS class name.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__(className, prefix)
            self.color = BaseProperty.Color(BaseColor.Reverse.primary)
            self.font = BaseProperty.FontSegoeUI(12)
            self.height = BaseProperty.Height(value=24)

    class Indicator(BaseStyleSheet):
        """
        Indicator base stylesheet.
        """
        def __init__(self, className: str, prefix: str = "") -> None:
            """
            Initialize the Indicator stylesheet.
            
            Args:
                className: The CSS class name.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__(f'{className}::indicator', prefix)
            self.border = BaseProperty.Border(radius=4, color=BaseColor.Widget.hoverBorder)
            self.width = BaseProperty.Width(value=15)
            self.height = BaseProperty.Height(value=15)
            self.margin = BaseProperty.Margin(top=2)
            self.background = BaseProperty.Background()
            self.addAdditionalStyle('subcontrol-origin: content; subcontrol-position: center left;')
            
    class IndicatorHover(BaseStyleSheet):
        """
        Indicator hover state stylesheet.
        """
        def __init__(self, className: str, prefix: str = "") -> None:
            """
            Initialize the IndicatorHover stylesheet.
            
            Args:
                className: The CSS class name.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__(f'{className}::indicator:hover', prefix)
            self.border = BaseProperty.Border(color=BaseColor.Widget.focusBorder)
            self.background = BaseProperty.Background(BaseColor.Widget.background)

    class IndicatorCheckedHover(BaseStyleSheet):
        """
        Indicator checked and hover state stylesheet.
        """
        def __init__(self, className: str, prefix: str = "") -> None:
            """
            Initialize the IndicatorCheckedHover stylesheet.
            
            Args:
                className: The CSS class name.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__(f'{className}::indicator:hover:checked', prefix)
            self.background = BaseProperty.Background(fromRgba(Global.appColor, 230))
            self.addAdditionalStyle(f"background-image: url(:/check_alt_200_200_200.png);") 
           
    class IndicatorChecked(BaseStyleSheet):
        """
        Indicator checked state stylesheet.
        """
        def __init__(self, className: str, prefix: str = "") -> None:
            """
            Initialize the IndicatorChecked stylesheet.
            
            Args:
                className: The CSS class name.
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__(f'{className}::indicator:checked', prefix)
            self.background = BaseProperty.Background(Global.appColor)
            self.addAdditionalStyle(f"background-image: url(:/check_alt_200_200_200.png);")

class CheckBoxStyleCheet(indicatorStyleCheet):
    """
    Stylesheet for QCheckBox widget.
    """
    def __init__(self, prefix: str = "") -> None:
        """
        Initialize the CheckBoxStyleCheet.
        
        Args:
            prefix: The CSS selector prefix. Defaults to "".
        """
        super().__init__(f"QCheckBox", prefix)
        