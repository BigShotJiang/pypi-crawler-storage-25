from ..styleSheet import BaseColor, Global, TypeTheme
from abc import ABC
from os import path
import inspect
from pathlib import Path

def addSuffix(iconName : str, suffix : str) -> str:
        """
        Add a suffix to an icon filename before the extension.
        
        Args:
            iconName: The icon filename.
            suffix: The suffix to add.
        
        Returns:
            The filename with the suffix added.
        """
        fileExtension = Path(iconName).suffix
        return f"{iconName.replace(fileExtension, '')}_{suffix}{fileExtension}"

def addSuffixTheme(iconName : str) -> str:
    """
    Add a theme-based suffix to an icon filename.
    
    Args:
        iconName: The icon filename.
    
    Returns:
        The filename with the theme suffix added.
    """
    themeSuffix = "55_55_55" if Global.theme == TypeTheme.light else "200_200_200"
    fileExtension = Path(iconName).suffix
    return f"{iconName.replace(fileExtension, '')}_{themeSuffix}{fileExtension}"

class BaseBox:
    """
    Base class for CSS box properties (padding, margin, etc.).
    """
    def __init__(self, propertyName : str, value : int = None, top : int = None, bottom : int = None, left : int = None, right : int = None):
        """
        Initialize the BaseBox.
        
        Args:
            propertyName: The CSS property name (e.g., 'padding', 'margin').
            value: Uniform value for all sides. Defaults to None.
            top: Top value. Defaults to None.
            bottom: Bottom value. Defaults to None.
            left: Left value. Defaults to None.
            right: Right value. Defaults to None.
        """
        self.value = value
        self.top = top
        self.bottom = bottom
        self.right = right
        self.left = left
        self._propertyName = propertyName

    @property
    def propertyName(self) -> str:
        """
        Get the property name.
        
        Returns:
            The property name.
        """
        return self._propertyName

    def __str__(self) -> str:
        """
        Convert to CSS string.
        
        Returns:
            CSS string representation.
        """
        return f'''
            {f'{self.propertyName}: {self.value}px;' if self.value != None else ''}
            {f'{self.propertyName}-top: {self.top}px;' if self.top != None else ''}
            {f'{self.propertyName}-bottom: {self.bottom}px;' if self.bottom != None else ''}
            {f'{self.propertyName}-right: {self.right}px;' if self.right != None else ''}
            {f'{self.propertyName}-left: {self.left}px;' if self.left != None else ''}
        '''

class BaseProperty:
    """
    Base class for CSS property definitions.
    
    Provides nested classes for various CSS properties that can be used
    to build stylesheets programmatically.
    """

    class SubcontrolOrigin:
        """
        CSS subcontrol-origin property.
        """
        def __init__(self, origin : str = "content"):
            """
            Initialize the SubcontrolOrigin.
            
            Args:
                origin: The origin value. Defaults to "content".
            """
            self.origin = origin
        def __str__(self) -> str:
            """
            Convert to CSS string.
            
            Returns:
                CSS string representation.
            """
            return f"subcontrol-origin: {self.origin};"

    class SubcontrolPosition:
        """
        CSS subcontrol-position property.
        """
        def __init__(self, horizontal : str, vertical : str):
            """
            Initialize the SubcontrolPosition.
            
            Args:
                horizontal: Horizontal position.
                vertical: Vertical position.
            """
            self.horizontal = horizontal
            self.vertical = vertical
        def __str__(self) -> str:
            """
            Convert to CSS string.
            
            Returns:
                CSS string representation.
            """
            return f"subcontrol-position: {self.horizontal} {self.vertical};"


    class BackgroundColor:
        """
        CSS background-color property.
        """
        def __init__(self, value : str, prefix: str = ''):
            """
            Initialize the BackgroundColor.
            
            Args:
                value: The color value.
                prefix: Optional prefix (e.g., 'selection'). Defaults to ''.
            """
            self.value = value
            self.prefix = prefix
        def __str__(self) -> str:
            """
            Convert to CSS string.
            
            Returns:
                CSS string representation.
            """
            return f"{self.prefix}-background-color: {self.value};" if self.prefix.strip() else f"background-color: {self.value};"

    class Color:
        """
        CSS color property.
        """
        def __init__(self, value : str, prefix: str = ''):
            """
            Initialize the Color.
            
            Args:
                value: The color value.
                prefix: Optional prefix (e.g., 'selection'). Defaults to ''.
            """
            self.value = value
            self.prefix = prefix
        def __str__(self) -> str:
            """
            Convert to CSS string.
            
            Returns:
                CSS string representation.
            """
            return f"{self.prefix}-color: {self.value};" if self.prefix.strip() else f"color: {self.value};"

    class TextAlign:
        """
        CSS text-align property.
        """
        def __init__(self, value : str):
            """
            Initialize the TextAlign.
            
            Args:
                value: The alignment value (e.g., 'left', 'center', 'right').
            """
            self.value = value
        def __str__(self) -> str:
            """
            Convert to CSS string.
            
            Returns:
                CSS string representation.
            """
            return f"text-align: {self.value};"

    class Background:
        """
        CSS background property.
        """
        def __init__(self, value : str = 'transparent'):
            """
            Initialize the Background.
            
            Args:
                value: The background value. Defaults to 'transparent'.
            """
            self.value = value
        def __str__(self) -> str:
            """
            Convert to CSS string.
            
            Returns:
                CSS string representation.
            """
            return f'background: {self.value};'

    class Image:
        """
        CSS image property.
        """
        def __init__(self, iconName : str, color: str = "theme", suffix: str = ""):
            """
            Initialize the Image.
            
            Args:
                iconName: The icon filename.
                color: Color variant or "theme". Defaults to "theme".
                suffix: Additional CSS suffix. Defaults to "".
            """
            self.iconName = iconName
            self.color = color
            self.suffix = suffix
        def __str__(self) -> str:
            """
            Convert to CSS string.
            
            Returns:
                CSS string representation.
            """
            if self.color == "theme":
                processedIconName = addSuffixTheme(self.iconName)
            else:
                processedIconName = addSuffix(self.iconName, self.color)
            return f"image: url(:/{processedIconName}) {self.suffix};"
  
    class BorderImage:
        """
        CSS border-image property.
        """
        def __init__(self, iconName : str = None, color: str = "theme", suffix: str = ""):
            """
            Initialize the BorderImage.
            
            Args:
                iconName: The icon filename. Defaults to None.
                color: Color variant or "theme". Defaults to "theme".
                suffix: Additional CSS suffix. Defaults to "".
            """
            self.iconName = iconName
            self.color = color
            self.suffix = suffix
        def __str__(self) -> str:
            """
            Convert to CSS string.
            
            Returns:
                CSS string representation.
            """
            if self.iconName == None:
                return "border-image: none;"

            if self.color == "theme":
                processedIconName = addSuffixTheme(self.iconName)
            else:
                processedIconName = addSuffix(self.iconName, self.color)
            return f"border-image: url(:/{processedIconName}) {self.suffix};"

    class BackgroundImage:
        """
        CSS background-image property.
        """
        def __init__(self, iconName : str, color : str | None = "theme"):
            """
            Initialize the BackgroundImage.
            
            Args:
                iconName: The icon filename.
                color: Color variant, "theme", or None. Defaults to "theme".
            """
            self.iconName = iconName
            self.color = color
        def __str__(self) -> str:
            """
            Convert to CSS string.
            
            Returns:
                CSS string representation.
            """
            processedIconName = self.iconName
            if self.color == "theme":
                processedIconName = addSuffixTheme(self.iconName)
            elif self.color != None:
                processedIconName = addSuffix(self.iconName, self.color)
            return f"background-image: url({path.join(u':', processedIconName)});"

    class Font:
        """
        CSS font property.
        """
        def __init__(self, name : str, size : int | str):
            """
            Initialize the Font.
            
            Args:
                name: The font family name.
                size: The font size.
            """
            self.name = name
            self.size = size
        def __str__(self) -> str:
            """
            Convert to CSS string.
            
            Returns:
                CSS string representation.
            """
            return f'font: {self.size}pt "{self.name}";'

    class FontSegoeUI(Font):
        """
        Font property with Segoe UI font family.
        """
        def __init__(self, size : int):
            """
            Initialize the FontSegoeUI.
            
            Args:
                size: The font size.
            """
            super().__init__("Segoe UI", size)

    class Top:
        """
        CSS top property.
        """
        def __init__(self, value : int):
            """
            Initialize the Top.
            
            Args:
                value: The top value in pixels.
            """
            self.value = value
        def __str__(self) -> str:
            """
            Convert to CSS string.
            
            Returns:
                CSS string representation.
            """
            return f'top: {self.value}px;'
        
    class Bottom:
        """
        CSS bottom property.
        """
        def __init__(self, value : int):
            """
            Initialize the Bottom.
            
            Args:
                value: The bottom value in pixels.
            """
            self.value = value
        def __str__(self) -> str:
            """
            Convert to CSS string.
            
            Returns:
                CSS string representation.
            """
            return f'bottom: {self.value}px;'
        
    class Left:
        """
        CSS left property.
        """
        def __init__(self, value : int):
            """
            Initialize the Left.
            
            Args:
                value: The left value in pixels.
            """
            self.value = value
        def __str__(self) -> str:
            """
            Convert to CSS string.
            
            Returns:
                CSS string representation.
            """
            return f'left: {self.value}px;'
        
    class Right:
        """
        CSS right property.
        """
        def __init__(self, value : int):
            """
            Initialize the Right.
            
            Args:
                value: The right value in pixels.
            """
            self.value = value
        def __str__(self) -> str:
            """
            Convert to CSS string.
            
            Returns:
                CSS string representation.
            """
            return f'right: {self.value}px;'
        

    class Padding(BaseBox):
        """
        CSS padding property.
        """
        def __init__(self, *, value : int = None, top : int = None, bottom : int = None, left : int = None, right : int = None):
            """
            Initialize the Padding.
            
            Args:
                value: Uniform value for all sides. Defaults to None.
                top: Top padding. Defaults to None.
                bottom: Bottom padding. Defaults to None.
                left: Left padding. Defaults to None.
                right: Right padding. Defaults to None.
            """
            super().__init__('padding', value, top, bottom, left, right)

    class Margin(BaseBox):
        """
        CSS margin property.
        """
        def __init__(self, *, value : int = None, top : int = None, bottom : int = None, left : int = None, right : int = None):
            """
            Initialize the Margin.
            
            Args:
                value: Uniform value for all sides. Defaults to None.
                top: Top margin. Defaults to None.
                bottom: Bottom margin. Defaults to None.
                left: Left margin. Defaults to None.
                right: Right margin. Defaults to None.
            """
            super().__init__('margin', value, top, bottom, left, right)

    class Width:
        """
        CSS width properties (width, min-width, max-width).
        """
        def __init__(self, *, value : int = None, min : int = None, max : int = None):
            """
            Initialize the Width.
            
            Args:
                value: Width value. Defaults to None.
                min: Minimum width. Defaults to None.
                max: Maximum width. Defaults to None.
            """
            self.value = value
            self.min = min
            self.max = max

        def __str__(self) -> str:
            """
            Convert to CSS string.
            
            Returns:
                CSS string representation.
            """
            return f'''
                {f'width: {self.value}px;' if self.value != None else ''}
                {f'min-width: {self.min}px;' if self.min != None else ''}
                {f'max-width: {self.max}px;' if self.max != None else ''}
            '''

    class Height:
        """
        CSS height properties (height, min-height, max-height).
        """
        def __init__(self, *, value : int = None, min : int = None, max : int = None):
            """
            Initialize the Height.
            
            Args:
                value: Height value. Defaults to None.
                min: Minimum height. Defaults to None.
                max: Maximum height. Defaults to None.
            """
            self.value = value
            self.min = min
            self.max= max

        def __str__(self) -> str:
            """
            Convert to CSS string.
            
            Returns:
                CSS string representation.
            """
            return f'''
                {f'height: {self.value}px;' if self.value else ''}
                {f'min-height: {self.min}px;' if self.min != None else ''}
                {f'max-height: {self.max}px;' if self.max != None else ''}
            '''
 
    class Border:
        """
        CSS border properties.
        """
        def __init__(self, *, color : BaseColor | str | None | bool = None, width=1, radius : int | None = None,
                    bottom : int = None, top : int = None, left : int = None, right : int = None,
                    topLeftRadius : int = None, topRightRadius : int = None,
                    bottomLeftRadius : int = None, bottomRightRadius : int = None, style : str = None):
            """
            Initialize the Border.
            
            Args:
                color: Border color. Defaults to None.
                width: Border width. Defaults to 1.
                radius: Border radius for all corners. Defaults to None.
                bottom: Bottom border width. Defaults to None.
                top: Top border width. Defaults to None.
                left: Left border width. Defaults to None.
                right: Right border width. Defaults to None.
                topLeftRadius: Top-left corner radius. Defaults to None.
                topRightRadius: Top-right corner radius. Defaults to None.
                bottomLeftRadius: Bottom-left corner radius. Defaults to None.
                bottomRightRadius: Bottom-right corner radius. Defaults to None.
                style: Border style. Defaults to None.
            """
            self.color = color
            self.width = width
            self.bottom = bottom
            self.top = top
            self.left = left
            self.right = right

            self.radius = radius
            self.topLeftRadius = topLeftRadius
            self.topRightRadius = topRightRadius
            self.bottomLeftRadius = bottomLeftRadius
            self.bottomRightRadius = bottomRightRadius
            self.style = style

        def __str__(self) -> str:
            """
            Convert to CSS string.
            
            Returns:
                CSS string representation.
            """
            borderStyle = ""
            if self.color != None:
                if self.bottom != None:
                    borderStyle = f'border-bottom: {self.bottom}px solid {self.color if self.color else ""};'
                if self.top != None:
                    borderStyle = f'{borderStyle} border-top: {self.top}px solid {self.color if self.color else ""};'
                if self.left != None:
                    borderStyle = f'{borderStyle} border-left: {self.left}px solid {self.color if self.color else ""};'
                if self.right != None:
                    borderStyle = f'{borderStyle} border-right: {self.right}px solid {self.color if self.color else ""};'
                if self.bottom == None and self.top == None and self.left == None and self.right == None:
                    borderStyle = f'border: {self.width}px solid {self.color if self.color else ""};'
            elif self.width == 0:
                borderStyle = 'border: 0px solid;'

            return f'''
                {borderStyle}
                {f'border-radius: {self.radius}px;' if self.radius != None else ''}
                {f'border-top-left-radius: {self.topLeftRadius}px;' if self.topLeftRadius != None else ''}
                {f'border-top-right-radius: {self.topRightRadius}px;' if self.topRightRadius != None else ''}
                {f'border-bottom-left-radius: {self.bottomLeftRadius}px;' if self.bottomLeftRadius != None else ''}
                {f'border-bottom-right-radius: {self.bottomRightRadius}px;' if self.bottomRightRadius != None else ''}
                {f'border-style: {self.style};' if self.style != None else ''}
            '''

def formatWidgetStyle(style: str, prefix : str, className: str, useClassName: bool) -> str:
    """
    Format widget style with prefix and class name.
    
    Args:
        style: The CSS style string.
        prefix: The CSS selector prefix.
        className: The class name or pseudo-class/pseudo-element.
        useClassName: Whether to use the class name.
    
    Returns:
        Formatted CSS string.
    """
    # Check if className is a valid string
    if isinstance(className, str) and className.strip():
        # When useClassName is True, apply prefix and className directly
        if useClassName:
            return f'{prefix} {className} {{{style}}}'
        else:
            # Handle pseudo-elements (::) or pseudo-classes (:)
            if '::' in className:
                if prefix.strip():
                    return f'{prefix}::{className.split("::")[1]} {{{style}}}'
                return f'::{className.split("::")[1]} {{{style}}}'
            elif ':' in className:
                if prefix.strip():
                    return f'{prefix}:{className.split(":")[1]} {{{style}}}'
                return f':{className.split(":")[1]} {{{style}}}'
            # Handle compound classes or hierarchies (e.g., QTreeWidget QWidgetAction)
            else:
                return f'{prefix} {{{style}}}'

    # If className is not valid, return style with prefix only or the style itself
    if prefix.strip():
        return f'{prefix} {{{style}}}'
    return style


class BaseWidgetStyleSheet(ABC):
    """
    Base class for widget stylesheets.
    
    This class provides functionality to automatically generate stylesheets
    from class attributes and methods.
    """
    def __init__(self, className: str = "" ,*, useClassName: bool = True):
        """
        Initialize the BaseWidgetStyleSheet.
        
        Args:
            className: The CSS class name. Defaults to "".
            useClassName: Whether to use the class name. Defaults to True.
        """
        self.useClassName = useClassName
        self.className = className
        if not className.strip():
            self.useClassName = False
        elif className == 'Standard':
            self.className = ""
         
    def _getClassVariables_(classe):
        """
        Get class variables that are not methods or ignored.
        
        Args:
            classe: The class to inspect.
        
        Returns:
            List of attribute names.
        """
        ignoreList = ['additionalStyle', 'className', 'useClassName']
        attributes = [attribute for attribute in dir(classe) if not callable(getattr(classe, attribute)) and not attribute.startswith("_") and attribute not in ignoreList]
        return [attribute for attribute in attributes if not inspect.ismethod(getattr(classe, attribute)) and not inspect.isfunction(getattr(classe, attribute))]

    def _getClassMethods_(self):
        """
        Get class methods that are not private and not styleSheet.
        
        Returns:
            List of method names.
        """
        classMethods = [
        methodName for methodName, method in inspect.getmembers(self, predicate=inspect.ismethod)
        if not methodName.startswith("_") and methodName not in ['styleSheet']
        ]
        return classMethods

    def styleSheet(self, *, useClassName: bool = True) -> str:
        """
        Generate the stylesheet string from attributes and methods.
        
        Args:
            useClassName: Whether to use the class name. Defaults to True.
        
        Returns:
            The generated stylesheet string.
        """
        attributes = self._getClassVariables_()
        methods = self._getClassMethods_()
        generatedStyleSheet = ""
        for attribute in attributes:
            attributeValue = getattr(self, attribute)
            if attributeValue != None:
                if hasattr(attributeValue, 'styleSheet'):
                    generatedStyleSheet = f'{generatedStyleSheet} {attributeValue.styleSheet(useClassName=useClassName)}'

        for method in methods:
            methodFunc = getattr(self, method)
            if callable(methodFunc):
                methodResult = methodFunc()
                if isinstance(methodResult, str):
                    generatedStyleSheet = f'{generatedStyleSheet} {methodResult}'

        return generatedStyleSheet

    def __str__(self) -> str:
        """
        Convert to string representation.
        
        Returns:
            The stylesheet string.
        """
        return self.styleSheet(useClassName=self.useClassName)


class BaseStyleSheet(ABC):
    """
    Base class for stylesheet definitions.
    
    This class provides functionality to build CSS stylesheets programmatically
    with support for prefixes, class names, and additional styles.
    """
    def __init__(self, className : str = "", prefix: str = ""):
        """
        Initialize the BaseStyleSheet.
        
        Args:
            className: The CSS class name. Defaults to "".
            prefix: The CSS selector prefix. Defaults to "".
        """
        self._className = className
        self._additionalStyle = ""
        self.prefix = prefix
        self.useClassName = True

    def addAdditionalStyle(self, additionalStyle : str) -> None:
        """
        Add additional CSS style string.
        
        Args:
            additionalStyle: Additional CSS style to add.
        """
        self._additionalStyle = f'{self._additionalStyle} {additionalStyle}'

    @property
    def additionalStyle(self) -> str:
        """
        Get the additional style string.
        
        Returns:
            The additional style string.
        """
        return self._additionalStyle

    @property
    def className(self) -> str:
        """
        Get the class name.
        
        Returns:
            The class name.
        """
        return self._className

    def _getClassVariables_(self):
        """
        Get class variables that are not methods or ignored.
        
        Returns:
            List of attribute names.
        """
        ignoreList = ['additionalStyle', 'className', 'prefix', 'useClassName']
        attributes = [attribute for attribute in dir(self) if not callable(getattr(self, attribute)) and not attribute.startswith("_") and attribute not in ignoreList]
        return [attribute for attribute in attributes if not inspect.ismethod(getattr(self, attribute)) and not inspect.isfunction(getattr(self, attribute))]

    def _createInstanceOfClass_(self, className : str, useClassName : bool):
        """
        Create an instance of a nested class.
        
        Args:
            className: The name of the nested class.
            useClassName: Whether to use the class name.
        
        Returns:
            String representation of the instance, or None.
        """
        nestedClass = getattr(self, className, None)
        if nestedClass and issubclass(nestedClass, BaseStyleSheet):
            classInstance = nestedClass()
            classInstance.useClassName = useClassName
            return f'{classInstance}'

    def _getAllNestedClasses_(self):
        """
        Get all nested classes.
        
        Returns:
            List of nested class names.
        """
        nestedClasses = [cls for cls in dir(self) if inspect.isclass(getattr(self, cls)) and cls != '__class__']
        return nestedClasses

    def styleSheet(self, *, useClassName : bool = None, prefix: str = '') -> str:
        """
        Generate the stylesheet string.
        
        Args:
            useClassName: Whether to use the class name. If None, uses self.useClassName. Defaults to None.
            prefix: CSS selector prefix. If empty, uses self.prefix. Defaults to ''.
        
        Returns:
            The generated stylesheet string.
        """
        attributes = self._getClassVariables_()
        styleString = ""
        for attribute in attributes:
            attributeValue = getattr(self, attribute)
            styleString = f'{styleString} {attributeValue}'
      
        styleString = f'{styleString} {self.additionalStyle}' 
        finalPrefix = prefix if prefix.strip() else self.prefix
        finalUseClassName = useClassName if useClassName != None else self.useClassName
        if finalPrefix.strip():
            generatedStyleSheet = ""
            prefixList = finalPrefix.split(',')
            for splitPrefix in prefixList:
                if splitPrefix.strip():
                    generatedStyleSheet += f"{formatWidgetStyle(styleString, splitPrefix.strip(), self.className, finalUseClassName)}" if styleString.strip() else ''
        else:
            generatedStyleSheet = f"{formatWidgetStyle(styleString, finalPrefix, self.className, finalUseClassName)}" if styleString.strip() else ''
        return generatedStyleSheet.replace('\n', '').replace('  ', '')

    def __str__(self) -> str:
        """
        Convert to string representation.
        
        Returns:
            The stylesheet string.
        """
        return self.styleSheet()
    


class CreateStyleSheet:
    """
    A class for creating stylesheets with properties and widget selectors.
    """
    def __init__(self, *properties : BaseProperty):
        """
        Initialize the CreateStyleSheet.
        
        Args:
            *properties: Variable number of BaseProperty instances.
        """
        self._properties : list[BaseProperty] = list(properties)    
        self._widgetsName : list[str] = []
        self._widgetsId : list[str] = []

    @property
    def properties(self) -> list[BaseProperty]:
        """
        Get the list of properties.
        
        Returns:
            List of BaseProperty instances.
        """
        return self._properties

    @property
    def widgetsName(self) -> list[str]:
        """
        Get the list of widget class names.
        
        Returns:
            List of widget class names.
        """
        return self._widgetsName

    @property
    def widgetsId(self) -> list[str]:
        """
        Get the list of widget IDs.
        
        Returns:
            List of widget IDs.
        """
        return self._widgetsId

    def addProperty(self, property : BaseProperty) -> None:
        """
        Add a property to the stylesheet.
        
        Args:
            property: The BaseProperty to add.
        """
        self._properties.append(property)

    def addClassName(self, *widgets_name : str, suffix : str = '') -> str:
        """
        Add widget class names to the stylesheet.
        
        Args:
            *widgets_name: Variable number of widget class names.
            suffix: Optional suffix to append. Defaults to ''.
        
        Returns:
            The string representation of the stylesheet.
        """
        for widgetName in widgets_name:
            self._widgetsName.append(f'{widgetName}{suffix}')
        return self.__str__()

    def addIds(self, *widgets_id : str, suffix : str = '') -> str:
        """
        Add widget IDs to the stylesheet.
        
        Args:
            *widgets_id: Variable number of widget IDs.
            suffix: Optional suffix to append. Defaults to ''.
        
        Returns:
            The string representation of the stylesheet.
        """
        for widgetId in widgets_id:
            self._widgetsId.append(f'#{widgetId}{suffix}')
        return self.__str__()

    def clone(self, *properties : BaseProperty):
        """
        Returns a new instance of CreateStyleSheet with the same properties.
        
        Args:
            *properties: Additional properties to add.
        
        Returns:
            A new CreateStyleSheet instance.
        """
        newProperties = list(properties)
        newProperties.extend(self.properties)
        return self.__class__(*newProperties)

   
    def __str__(self) -> str:
        """
        Convert to CSS string representation.
        
        Returns:
            The CSS stylesheet string.
        """
        # Join widget names with commas if present
        widgetNames = ', '.join(self.widgetsName)
        widgetIds = ', '.join(self.widgetsId)

        # Combine widget names and widget IDs if present
        allWidgets = f'{widgetNames}, {widgetIds}' if widgetNames and widgetIds else widgetNames or widgetIds

        # Get string representation of each property and join results into a single string
        propertiesString = ''.join(str(prop) for prop in self.properties)

        # Return empty string if there are no widgets
        if not allWidgets or not propertiesString:
            return ''

        # Return formatted string with widgets and properties
        return f'{allWidgets} {{\n{propertiesString}\n}}'.replace('\n', '').replace('  ', '')

class StyleSheets(object):
    
    class BaseStyle(BaseStyleSheet):
        def __init__(self,  prefix=""):
            super().__init__("", prefix)
            self.base = f'''
            {CreateStyleSheet(BaseProperty.Border(radius=5), BaseProperty.Margin(value=0)).addClassName(
                f"{prefix} QFrame", f"{prefix} QWidget", f"{prefix} QWidget QFrame", f"{prefix} QFrame QWidget")
            }

            {CreateStyleSheet(BaseProperty.Color(BaseColor.Reverse.primary.fromRgba(200))).addClassName(
                f"{prefix} QFrame", f"{prefix} QWidget", f"{prefix} QWidgetAction QFrame", f"{prefix} QWidgetAction QWidget", suffix=":disabled")
            }

            {CreateStyleSheet(BaseProperty.BackgroundColor(BaseColor.primary),
                                    BaseProperty.Color(BaseColor.Reverse.primary),
                                    BaseProperty.FontSegoeUI(12),
                                    BaseProperty.Margin(value=0)).addClassName(
                                    f"{prefix} QFrame", f"{prefix} QWidget", f"{prefix} QWidgetAction QFrame", f"{prefix} QWidgetAction QWidget")}

            {CreateStyleSheet(BaseProperty.Color(BaseColor.Reverse.primary)).addClassName(f"{prefix} QLabel")
            }

            QWidget {{{BaseProperty.Border(radius=5)}}}

            QToolTip, QFrame QToolTip, QWidget QToolTip {{
                {BaseProperty.FontSegoeUI(10)}
                color: {BaseColor.Reverse.primary};
                border: 2px solid {BaseColor.division};
                padding: 3px;
                border-radius: 3px;
                background-color: {BaseColor.primary};
                opacity: 200;
            }}

            '''
            

    class BackgroundNone(BaseStyleSheet):
        def __init__(self, className : str, prefix: str = ""):
            super().__init__(className, prefix)
            self.background = BaseProperty.Background('none')

    class WidthAndHeight(BaseStyleSheet):
        def __init__(self, className : str, prefix: str = "", *, width : int = 0, minWidth : int = None, maxWidth: int = None, height : int = 0, minHeight : int = None, maxHeight : int = None):
            super().__init__(className, prefix)
            self.width = BaseProperty.Width(value=width, min=minWidth, max=maxWidth)
            self.height = BaseProperty.Height(value=height, min=minHeight, max=maxHeight)