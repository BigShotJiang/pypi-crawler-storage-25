from .base import BaseWidgetStyleSheet, BaseStyleSheet, BaseColor, BaseProperty
from .comboBox import ComboBoxStyleCheet
from .listView import ListViewStyleCheet

class GlobalVar:
    """
    Global variables for header view stylesheet.
    """
    headerViewHorizontalHeight: int = 28

class HeaderViewStyleSheet(BaseWidgetStyleSheet):
    """
    Stylesheet for QHeaderView widget.
    """

    def __init__(self, prefix: str = "") -> None:
        """
        Initialize the HeaderViewStyleSheet.
        
        Args:
            prefix: The CSS selector prefix. Defaults to "".
        """
        super().__init__(f"{prefix} QHeaderView")
        self.section = self.Section(prefix)
        self.frame = self.Frame(prefix)
        self.sectionHorizontalPushButton = self.SectionHorizontalPushButton(prefix)
        self.sectionHorizontalPushButtonHover = self.SectionHorizontalPushButtonHover(prefix)
        self.sectionHorizontalPushButtonPressed = self.SectionHorizontalPushButtonPressed(prefix)
        self.pushButton = self.PushButton(prefix)
        self.poolButton = self.ToolButton(prefix)
        self.sectionHorizontal = self.SectionHorizontal(prefix)
        self.sectionHorizontalLabel = self.SectionHorizontalLabel(prefix)
        self.sectionHorizontalComboBox = self.SectionHorizontalComboBox(prefix)
        self.sectionHorizontalListView = self.SectionHorizontalListView(prefix)
        self.sectionHorizontalOnlyOne = self.SectionHorizontalOnlyOne(prefix)
        self.sectionHorizontalFirst = self.SectionHorizontalFirst(prefix)
        self.sectionHorizontalLast = self.SectionHorizontalLast(prefix)
        self.sectionVertical = self.SectionVertical(prefix)
        self.sectionVerticalOnlyOne = self.SectionVerticalOnlyOne(prefix)
        self.sectionVerticalFirst = self.SectionVerticalFirst(prefix)
        self.sectionVerticalLast = self.SectionVerticalLast(prefix)
        self.downArrow = self.DownArrow(prefix)
        self.upArrow = self.UpArrow(prefix)

    class Section(BaseStyleSheet):
        """
        Header view section stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the Section stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QHeaderView:section', prefix)
            self.border = BaseProperty.Border(width=0, color=False)

    class Frame(BaseStyleSheet):
        """
        Header view frame stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the Frame stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QHeaderView QFrame', prefix)
            self.background = BaseProperty.Background("transparent")

    class SectionHorizontalPushButton(BaseStyleSheet):
        """
        Header view horizontal section push button stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the SectionHorizontalPushButton stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QHeaderView:section:horizontal QPushButton', prefix)
            self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.primary.fromRgba(100))
            self.border = BaseProperty.Border(radius=2)
            self.margin = BaseProperty.Margin(value=0)
            self.height = BaseProperty.Height(value=GlobalVar.headerViewHorizontalHeight-2)

    class SectionHorizontalPushButtonHover(BaseStyleSheet):
        """
        Header view horizontal section push button hover state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the SectionHorizontalPushButtonHover stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QHeaderView:section:horizontal QPushButton:hover', prefix)
            self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.primary)

    class SectionHorizontalPushButtonPressed(BaseStyleSheet):
        """
        Header view horizontal section push button pressed state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the SectionHorizontalPushButtonPressed stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QHeaderView:section:horizontal QPushButton:pressed', prefix)
            self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.secondary)

    class PushButton(BaseStyleSheet):
        """
        Header view push button stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the PushButton stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QHeaderView QPushButton', prefix)
            self.border = BaseProperty.Border(radius=2)
            self.margin = BaseProperty.Margin(value=0)

    class ToolButton(BaseStyleSheet):
        """
        Header view tool button stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the ToolButton stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QHeaderView QToolButton', prefix)
            self.border = BaseProperty.Border(radius=2)
            self.margin = BaseProperty.Margin(value=0)

    class SectionHorizontal(BaseStyleSheet):
        """
        Header view horizontal section stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the SectionHorizontal stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QHeaderView:section:horizontal', prefix)
            self.height = BaseProperty.Height(value=GlobalVar.headerViewHorizontalHeight)
            self.color = BaseProperty.Color(BaseColor.Reverse.primary)
            self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.tertiary)
            self.textAlign = BaseProperty.TextAlign('left')

    class SectionHorizontalLabel(BaseStyleSheet):
        """
        Header view horizontal section label stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the SectionHorizontalLabel stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QHeaderView:section:horizontal QLabel', prefix)
            self.border = BaseProperty.Border(radius=5)
            self.color = BaseProperty.Color(BaseColor.Reverse.primary)
            self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.tertiary)
            self.textAlign = BaseProperty.TextAlign('left')

    class SectionHorizontalComboBox(ComboBoxStyleCheet):
        """
        Header view horizontal section combobox stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the SectionHorizontalComboBox stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__(f'{prefix} QHeaderView:section:horizontal')
            self.comboBox.border = BaseProperty.Border(radius=2, color=BaseColor.tertiary)
            self.comboBox.backgroundColor = BaseProperty.BackgroundColor(BaseColor.tertiary)
            self.comboBox.height = BaseProperty.Height(value=GlobalVar.headerViewHorizontalHeight-2)
            self.abstractItemView.backgroundColor = BaseProperty.BackgroundColor(BaseColor.tertiary)
            self.on.border = BaseProperty.Border(bottomLeftRadius=0, bottomRightRadius=0, color=BaseColor.Widget.focusBorder)
            self.hover.border = BaseProperty.Border(color=BaseColor.Widget.hoverBorder)

    class SectionHorizontalListView(ListViewStyleCheet):
        """
        Header view horizontal section list view stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the SectionHorizontalListView stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__(f'{prefix} QHeaderView:section:horizontal')
    

    class SectionHorizontalOnlyOne(BaseStyleSheet):
        """
        Header view horizontal section when only one section stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the SectionHorizontalOnlyOne stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QHeaderView::section:horizontal:only-one', prefix)
            self.height = BaseProperty.Height(value=GlobalVar.headerViewHorizontalHeight)
            self.border = BaseProperty.Border(topLeftRadius=5, topRightRadius=5)

    class SectionHorizontalFirst(BaseStyleSheet):
        """
        Header view horizontal section first stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the SectionHorizontalFirst stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QHeaderView::section:horizontal:first', prefix)
            self.border = BaseProperty.Border(topLeftRadius=5, topRightRadius=0, bottomRightRadius=0, bottomLeftRadius=0)
          
    class SectionHorizontalLast(BaseStyleSheet):
        """
        Header view horizontal section last stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the SectionHorizontalLast stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QHeaderView::section:horizontal:last', prefix)
            self.height = BaseProperty.Height(value=GlobalVar.headerViewHorizontalHeight)
            self.border = BaseProperty.Border(topLeftRadius=0, topRightRadius=5, bottomRightRadius=0, bottomLeftRadius=0)
            
    class SectionVertical(BaseStyleSheet):
        """
        Header view vertical section stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the SectionVertical stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QHeaderView::section:vertical', prefix)
            self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.tertiary)
            self.color = BaseProperty.Color(BaseColor.secondary)
            self.margin = BaseProperty.Margin(left=3, right=3)
            self.width = BaseProperty.Width(value=20)

    class SectionVerticalOnlyOne(BaseStyleSheet):
        """
        Header view vertical section when only one section stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the SectionVerticalOnlyOne stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QHeaderView::section:vertical:only-one', prefix)
            self.margin = BaseProperty.Margin(top=2, bottom=2)

    class SectionVerticalFirst(BaseStyleSheet):
        """
        Header view vertical section first stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the SectionVerticalFirst stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QHeaderView::section:vertical:first', prefix)
            self.margin = BaseProperty.Margin(top=2)

    class SectionVerticalLast(BaseStyleSheet):
        """
        Header view vertical section last stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the SectionVerticalLast stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QHeaderView::section:vertical:last', prefix)
            self.margin = BaseProperty.Margin(bottom=2)

    class DownArrow(BaseStyleSheet):
        """
        Header view down arrow stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the DownArrow stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QHeaderView::down-arrow', prefix)
            self.height = BaseProperty.Height(value=12)
            self.width = BaseProperty.Width(value=12)
            self.image = BaseProperty.Image('arrow_down.png') 

    class UpArrow(BaseStyleSheet):
        """
        Header view up arrow stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the UpArrow stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QHeaderView::up-arrow', prefix)
            self.height = BaseProperty.Height(value=12)
            self.width = BaseProperty.Width(value=12)
            self.image = BaseProperty.Image('arrow_up.png')






