from .base import BaseWidgetStyleSheet, BaseStyleSheet, BaseColor, BaseProperty
from .checkBox import CheckBoxStyleCheet
from .listView import ListViewStyleCheet
from .scrollBar import ScrollBarStyleSheet
from ..utils import Global

class ComboBoxStyleCheet(BaseWidgetStyleSheet):
    """
    Stylesheet for QComboBox widget.
    """
    def __init__(self, prefix: str = "", height: int | None = 25) -> None:
        """
        Initialize the ComboBoxStyleCheet.
        
        Args:
            prefix: The CSS selector prefix. Defaults to "".
            height: ComboBox height in pixels. Defaults to 25.
        """
        super().__init__(f"{prefix} QComboBox")
        self.comboBox = self.ComboBox(prefix, height)
        self.dropDownOn = self.DropDownOn(prefix)
        self.dropDownHover = self.DropDownHover(prefix)
        self.abstractItemView = self.AbstractItemView(prefix)
        self.hover = self.Hover(prefix)
        self.on = self.On(prefix)
        self.listView = self.ListView(prefix)
        self.checkBox = self.CheckBox(prefix)
        self.scrollBarHorizontal = self.ScrollBarHorizontal(prefix)
        self.scrollBarVertical = self.ScrollBarVertical(prefix)
        self.onPopupOpen = self.OnPopupOpen(prefix)
        self.dropDownOnPopupOpen = self.DropDownOnPopupOpen(prefix=prefix)
        self.onPopupOpenUp = self.OnPopupOpenUp(prefix)
        self.dropDownOnPopupOpenUp = self.DropDownOnPopupOpenUp(prefix=prefix)
        #self.abstractItemViewSelected = self.AbstractItemViewSelected(prefix=prefix)
        #self.abstractItemViewHoverSelected = self.AbstractItemViewHoverSelected(prefix=prefix)
        self.abstractItemViewHover = self.AbstractItemViewHover(prefix=prefix)

    class ScrollBarHorizontal(ScrollBarStyleSheet.Horizontal):
        """
        ComboBox horizontal scrollbar stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the ScrollBarHorizontal stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__(f'{prefix} QComboBox')
            self.backgroundColor.value = BaseColor.Widget.background
          
    class ScrollBarVertical(ScrollBarStyleSheet.Vertical):
        """
        ComboBox vertical scrollbar stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the ScrollBarVertical stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__(f'{prefix} QComboBox')
            self.backgroundColor.value = BaseColor.Widget.background
          
    class ComboBox(BaseStyleSheet):
        """
        ComboBox base stylesheet.
        """
        def __init__(self, prefix: str = "", height: int | None = 25) -> None:
            """
            Initialize the ComboBox stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
                height: ComboBox height in pixels. Defaults to 25.
            """
            super().__init__('QComboBox', prefix)
            self.font = BaseProperty.FontSegoeUI(12)
            self.height = BaseProperty.Height(value=height, min=height, max=height)
            self.border = BaseProperty.Border(radius=5, color=BaseColor.Widget.background)
            self.padding = BaseProperty.Padding(left=2)
            self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.Widget.background)
            self.color = BaseProperty.Color(BaseColor.Reverse.primary)
            self.selectionBackgroundColor = BaseProperty.BackgroundColor(BaseColor.Widget.selectedBackground, 'selection')
            self.selectionColor = BaseProperty.Color(BaseColor.Reverse.primary, 'selection')

    class DropDownOn(BaseStyleSheet):
        """
        ComboBox drop-down button when on state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the DropDownOn stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QComboBox::drop-down:on', prefix)
            self.image = BaseProperty.Image("arrow_down.png", "73_145_246") 

    class DropDownOnPopupOpen(BaseStyleSheet):
        """
        ComboBox drop-down button when popup is open stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the DropDownOnPopupOpen stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QComboBox::drop-down[popup_open="true"]', prefix)
            self.image = BaseProperty.Image("arrow_down.png", "73_145_246") 

    class DropDownOnPopupOpenUp(BaseStyleSheet):
        """
        ComboBox drop-down button when popup is open upward stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the DropDownOnPopupOpenUp stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QComboBox::drop-down[popup_open_up="true"]', prefix)
            self.image = BaseProperty.Image("arrow_up.png", "73_145_246")

    class DropDownHover(BaseStyleSheet):
        """
        ComboBox drop-down button hover state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the DropDownHover stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QComboBox::drop-down:hover', prefix)
            self.image = BaseProperty.Image("arrow_down.png", "73_145_246")

    class AbstractItemView(BaseStyleSheet):
        """
        ComboBox abstract item view stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the AbstractItemView stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QComboBox QAbstractItemView', prefix)
            self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.Widget.background)
            self.border = BaseProperty.Border(
                color=BaseColor.Widget.focusBorder,
                bottomLeftRadius=5,
                bottomRightRadius=0,
                topLeftRadius=0,
                topRightRadius=0
            )

    class AbstractItemViewSelected(BaseStyleSheet):
        """
        ComboBox abstract item view selected state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the AbstractItemViewSelected stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QComboBox QAbstractItemView::item:selected', prefix)
            self.color = BaseProperty.Color(BaseColor.Reverse.primary)

    class AbstractItemViewHoverSelected(BaseStyleSheet):
        """
        ComboBox abstract item view hover and selected state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the AbstractItemViewHoverSelected stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QComboBox QAbstractItemView::item:hover:selected', prefix)
            self.color = BaseProperty.Color(BaseColor.Reverse.primary)

    class AbstractItemViewHover(BaseStyleSheet):
        """
        ComboBox abstract item view hover state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the AbstractItemViewHover stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QComboBox  QAbstractItemView::item:hover', prefix)
            self.color = BaseProperty.Color(Global.appColor)

    class Hover(BaseStyleSheet):
        """
        ComboBox hover state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the Hover stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QComboBox:hover', prefix)
            self.border = BaseProperty.Border(color=BaseColor.Widget.hoverBorder)

    class On(BaseStyleSheet):
        """
        ComboBox on state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the On stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QComboBox:on', prefix)
            self.border = BaseProperty.Border(color=BaseColor.Widget.focusBorder, bottomLeftRadius=0, bottomRightRadius=0)

    class OnPopupOpen(BaseStyleSheet):
        """
        ComboBox on state when popup is open stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the OnPopupOpen stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QComboBox[popup_open="true"]', prefix)
            self.border = BaseProperty.Border(color=BaseColor.Widget.focusBorder, bottomLeftRadius=0, bottomRightRadius=0)

    class OnPopupOpenUp(BaseStyleSheet):
        """
        ComboBox on state when popup is open upward stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the OnPopupOpenUp stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__('QComboBox[popup_open_up="true"]', prefix)
            self.border = BaseProperty.Border(color=BaseColor.Widget.focusBorder, topLeftRadius=0, topRightRadius=0)

    class ListView(ListViewStyleCheet):
        """
        ComboBox list view stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the ListView stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__(f"{prefix} QComboBox")

    class CheckBox(CheckBoxStyleCheet):
        """
        ComboBox checkbox stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the CheckBox stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__(f"{prefix} QComboBox")
