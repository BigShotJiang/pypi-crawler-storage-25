from .base import BaseWidgetStyleSheet, BaseStyleSheet, BaseColor, BaseProperty

class BaseBoxStyleSheet(object):
    """
    Base stylesheet classes for box-like widgets (SpinBox, TimeEdit, etc.).
    """
    
    class Box(BaseStyleSheet):
        """
        Base box stylesheet.
        """
        def __init__(self, className: str, prefix: str) -> None:
            """
            Initialize the Box stylesheet.
            
            Args:
                className: The CSS class name.
                prefix: The CSS selector prefix.
            """
            super().__init__(className, prefix)
            self.padding = BaseProperty.Padding(left=0)
            self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.Widget.background)
            self.color = BaseProperty.Color(BaseColor.Reverse.primary)
            self.selection_backgroundColor = BaseProperty.BackgroundColor(BaseColor.Widget.selectedBackground, 'selection')
            self.selection_color = BaseProperty.Color(BaseColor.Reverse.primary, 'selection')
            self.border = BaseProperty.Border(radius=5, color=BaseColor.Widget.background)
            self.height = BaseProperty.Height(value=24)

    class Hover(BaseStyleSheet):
        """
        Hover state stylesheet.
        """
        def __init__(self, className: str, prefix: str) -> None:
            """
            Initialize the Hover stylesheet.
            
            Args:
                className: The CSS class name.
                prefix: The CSS selector prefix.
            """
            super().__init__(f'{className}:hover', prefix)
            self.backgroundColor = BaseProperty.BackgroundColor(BaseColor.Widget.hoverBackground)
            self.border = BaseProperty.Border(color=BaseColor.Widget.hoverBorder)

    class Focus(BaseStyleSheet):
        """
        Focus state stylesheet.
        """
        def __init__(self, className: str, prefix: str) -> None:
            """
            Initialize the Focus stylesheet.
            
            Args:
                className: The CSS class name.
                prefix: The CSS selector prefix.
            """
            super().__init__(f'{className}:focus', prefix)
            self.border = BaseProperty.Border(color=BaseColor.Widget.focusBorder)

    class HoverFocus(BaseStyleSheet):
        """
        Hover and focus state stylesheet.
        """
        def __init__(self, className: str, prefix: str) -> None:
            """
            Initialize the HoverFocus stylesheet.
            
            Args:
                className: The CSS class name.
                prefix: The CSS selector prefix.
            """
            super().__init__(f'{className}:hover:focus', prefix)
            self.border = BaseProperty.Border(color=BaseColor.Widget.focusBorder)
          
    class DownButton(BaseStyleSheet):
        """
        Down button stylesheet.
        """
        def __init__(self, className: str, prefix: str) -> None:
            """
            Initialize the DownButton stylesheet.
            
            Args:
                className: The CSS class name.
                prefix: The CSS selector prefix.
            """
            super().__init__(f'{className}::down-button', prefix)
            self.border = BaseProperty.Border(radius=5)
            self.height = BaseProperty.Height(value=6)
            self.padding = BaseProperty.Padding(bottom=3)
            self.image = BaseProperty.Image("arrow_down.png")

    class UpButton(BaseStyleSheet):
        """
        Up button stylesheet.
        """
        def __init__(self, className: str, prefix: str) -> None:
            """
            Initialize the UpButton stylesheet.
            
            Args:
                className: The CSS class name.
                prefix: The CSS selector prefix.
            """
            super().__init__(f'{className}::up-button', prefix)
            self.border = BaseProperty.Border(radius=5)
            self.height = BaseProperty.Height(value=6)
            self.padding = BaseProperty.Padding(top=3)
            self.image = BaseProperty.Image("arrow_up.png")


    class DownButtonHover(BaseStyleSheet):
        """
        Down button hover state stylesheet.
        """
        def __init__(self, className: str, prefix: str) -> None:
            """
            Initialize the DownButtonHover stylesheet.
            
            Args:
                className: The CSS class name.
                prefix: The CSS selector prefix.
            """
            super().__init__(f'{className}::down-button:hover', prefix)
            self.height = BaseProperty.Height(value=8)
            self.padding = BaseProperty.Padding(bottom=2)
            self.image = BaseProperty.Image("arrow_down.png", "73_145_246")

    class UpButtonHover(BaseStyleSheet):
        """
        Up button hover state stylesheet.
        """
        def __init__(self, className: str, prefix: str) -> None:
            """
            Initialize the UpButtonHover stylesheet.
            
            Args:
                className: The CSS class name.
                prefix: The CSS selector prefix.
            """
            super().__init__(f'{className}::up-button:hover', prefix)
            self.height = BaseProperty.Height(value=8)
            self.padding = BaseProperty.Padding(top=2)
            self.image = BaseProperty.Image("arrow_up.png", "73_145_246")


class SpinBoxStyleSheet(BaseWidgetStyleSheet):
    """
    Stylesheet for QSpinBox widget.
    """
    def __init__(self, prefix: str = "") -> None:
        """
        Initialize the SpinBoxStyleSheet.
        
        Args:
            prefix: The CSS selector prefix. Defaults to "".
        """
        super().__init__(f"{prefix} QSpinBox")
        self.spinBox = self.SpinBox(prefix)
        self.hover = self.Hover(prefix)
        self.focus = self.Focus(prefix)
        self.hoverFocus = self.HoverFocus(prefix)
        self.downButton = self.DownButton(prefix)
        self.upButton = self.UpButton(prefix)
        self.downButtonHover = self.DownButtonHover(prefix)
        self.upButtonHover = self.UpButtonHover(prefix)
        
    class SpinBox(BaseBoxStyleSheet.Box):
        """
        SpinBox base stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the SpinBox stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QSpinBox", prefix)

    class Hover(BaseBoxStyleSheet.Hover):
        """
        SpinBox hover state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the Hover stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QSpinBox", prefix)

    class Focus(BaseBoxStyleSheet.Focus):
        """
        SpinBox focus state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the Focus stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QSpinBox", prefix)

    class HoverFocus(BaseBoxStyleSheet.HoverFocus):
        """
        SpinBox hover and focus state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the HoverFocus stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QSpinBox", prefix)
     
    class DownButton(BaseBoxStyleSheet.DownButton):
        """
        SpinBox down button stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the DownButton stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QSpinBox", prefix)

    class UpButton(BaseBoxStyleSheet.UpButton):
        """
        SpinBox up button stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the UpButton stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QSpinBox", prefix)

    class DownButtonHover(BaseBoxStyleSheet.DownButtonHover):
        """
        SpinBox down button hover state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the DownButtonHover stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QSpinBox", prefix)

    class UpButtonHover(BaseBoxStyleSheet.UpButtonHover):
        """
        SpinBox up button hover state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the UpButtonHover stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QSpinBox", prefix)


class TimeEditStyleSheet(BaseWidgetStyleSheet):
    """
    Stylesheet for QTimeEdit widget.
    """
    def __init__(self, prefix: str = "") -> None:
        """
        Initialize the TimeEditStyleSheet.
        
        Args:
            prefix: The CSS selector prefix. Defaults to "".
        """
        super().__init__(f"{prefix} QTimeEdit")
        self.timeEdit = self.TimeEdit(prefix)
        self.hover = self.Hover(prefix)
        self.focus = self.Focus(prefix)
        self.hoverFocus = self.HoverFocus(prefix)
        self.downButton = self.DownButton(prefix)
        self.upButton = self.UpButton(prefix)
        self.downButtonHover = self.DownButtonHover(prefix)
        self.upButtonHover = self.UpButtonHover(prefix)
        
    class TimeEdit(BaseBoxStyleSheet.Box):
        """
        TimeEdit base stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the TimeEdit stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QTimeEdit", prefix)

    class Hover(BaseBoxStyleSheet.Hover):
        """
        TimeEdit hover state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the Hover stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QTimeEdit", prefix)

    class Focus(BaseBoxStyleSheet.Focus):
        """
        TimeEdit focus state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the Focus stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QTimeEdit", prefix)

    class HoverFocus(BaseBoxStyleSheet.HoverFocus):
        """
        TimeEdit hover and focus state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the HoverFocus stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QTimeEdit", prefix)
     
    class DownButton(BaseBoxStyleSheet.DownButton):
        """
        TimeEdit down button stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the DownButton stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QTimeEdit", prefix)

    class UpButton(BaseBoxStyleSheet.UpButton):
        """
        TimeEdit up button stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the UpButton stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QTimeEdit", prefix)

    class DownButtonHover(BaseBoxStyleSheet.DownButtonHover):
        """
        TimeEdit down button hover state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the DownButtonHover stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QTimeEdit", prefix)

    class UpButtonHover(BaseBoxStyleSheet.UpButtonHover):
        """
        TimeEdit up button hover state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the UpButtonHover stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QTimeEdit", prefix)

class DateTimeEditStyleSheet(BaseWidgetStyleSheet):
    """
    Stylesheet for QDateTimeEdit widget.
    """
    def __init__(self, prefix: str = "") -> None:
        """
        Initialize the DateTimeEditStyleSheet.
        
        Args:
            prefix: The CSS selector prefix. Defaults to "".
        """
        super().__init__(f"{prefix} QDateTimeEdit")
        self.dateTimeEdit = self.DateTimeEdit(prefix)
        self.hover = self.Hover(prefix)
        self.focus = self.Focus(prefix)
        self.hoverFocus = self.HoverFocus(prefix)
        self.downButton = self.DownButton(prefix)
        self.upButton = self.UpButton(prefix)
        self.downButtonHover = self.DownButtonHover(prefix)
        self.upButtonHover = self.UpButtonHover(prefix)
        
    class DateTimeEdit(BaseBoxStyleSheet.Box):
        """
        DateTimeEdit base stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the DateTimeEdit stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QDateTimeEdit", prefix)

    class Hover(BaseBoxStyleSheet.Hover):
        """
        DateTimeEdit hover state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the Hover stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QDateTimeEdit", prefix)

    class Focus(BaseBoxStyleSheet.Focus):
        """
        DateTimeEdit focus state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the Focus stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QDateTimeEdit", prefix)

    class HoverFocus(BaseBoxStyleSheet.HoverFocus):
        """
        DateTimeEdit hover and focus state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the HoverFocus stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QDateTimeEdit", prefix)
     
    class DownButton(BaseBoxStyleSheet.DownButton):
        """
        DateTimeEdit down button stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the DownButton stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QDateTimeEdit", prefix)

    class UpButton(BaseBoxStyleSheet.UpButton):
        """
        DateTimeEdit up button stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the UpButton stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QDateTimeEdit", prefix)

    class DownButtonHover(BaseBoxStyleSheet.DownButtonHover):
        """
        DateTimeEdit down button hover state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the DownButtonHover stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QDateTimeEdit", prefix)

    class UpButtonHover(BaseBoxStyleSheet.UpButtonHover):
        """
        DateTimeEdit up button hover state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the UpButtonHover stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QDateTimeEdit", prefix)


class DoubleSpinBoxStyleSheet(BaseWidgetStyleSheet):
    """
    Stylesheet for QDoubleSpinBox widget.
    """
    def __init__(self, prefix: str = "") -> None:
        """
        Initialize the DoubleSpinBoxStyleSheet.
        
        Args:
            prefix: The CSS selector prefix. Defaults to "".
        """
        super().__init__(f"{prefix} QDoubleSpinBox")
        self.doubleSpinBox = self.DoubleSpinBox(prefix)
        self.hover = self.Hover(prefix)
        self.focus = self.Focus(prefix)
        self.hoverFocus = self.HoverFocus(prefix)
        self.downButton = self.DownButton(prefix)
        self.upButton = self.UpButton(prefix)
        self.downButtonHover = self.DownButtonHover(prefix)
        self.upButtonHover = self.UpButtonHover(prefix)
        
    class DoubleSpinBox(BaseBoxStyleSheet.Box):
        """
        DoubleSpinBox base stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the DoubleSpinBox stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QDoubleSpinBox", prefix)

    class Hover(BaseBoxStyleSheet.Hover):
        """
        DoubleSpinBox hover state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the Hover stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QDoubleSpinBox", prefix)

    class Focus(BaseBoxStyleSheet.Focus):
        """
        DoubleSpinBox focus state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the Focus stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QDoubleSpinBox", prefix)

    class HoverFocus(BaseBoxStyleSheet.HoverFocus):
        """
        DoubleSpinBox hover and focus state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the HoverFocus stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QDoubleSpinBox", prefix)
     
    class DownButton(BaseBoxStyleSheet.DownButton):
        """
        DoubleSpinBox down button stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the DownButton stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QDoubleSpinBox", prefix)

    class UpButton(BaseBoxStyleSheet.UpButton):
        """
        DoubleSpinBox up button stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the UpButton stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QDoubleSpinBox", prefix)

    class DownButtonHover(BaseBoxStyleSheet.DownButtonHover):
        """
        DoubleSpinBox down button hover state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the DownButtonHover stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QDoubleSpinBox", prefix)

    class UpButtonHover(BaseBoxStyleSheet.UpButtonHover):
        """
        DoubleSpinBox up button hover state stylesheet.
        """
        def __init__(self, prefix: str = "") -> None:
            """
            Initialize the UpButtonHover stylesheet.
            
            Args:
                prefix: The CSS selector prefix. Defaults to "".
            """
            super().__init__("QDoubleSpinBox", prefix)
