# -*- coding: utf-8 -*-
"""
Theme definitions (dark/light) using classes for easier maintenance.
Each color group is a class with typed attributes.
"""
from dataclasses import dataclass
from typing import Dict, Any


@dataclass(frozen=True)
class WidgetColors:
    """
    Base colors for widgets (background, hover, focus, selection).
    """
    background: str
    hoverBackground: str
    hoverBorder: str
    focusBorder: str
    selectedBackground: str


@dataclass(frozen=True)
class ButtonStateColors:
    """
    Colors for a button state (hover or pressed).
    """
    background: str
    border: str


@dataclass(frozen=True)
class ButtonColors:
    """
    Button colors (normal, hover, pressed).
    """
    background: str
    hover: ButtonStateColors
    pressed: ButtonStateColors


@dataclass(frozen=True)
class MenuButtonColors:
    """
    Menu button colors.
    """
    background: str
    hover: ButtonStateColors
    pressed: ButtonStateColors


@dataclass(frozen=True)
class MenuColors:
    """
    Menu and button colors.
    """
    background: str
    button: MenuButtonColors


@dataclass(frozen=True)
class ReverseColors:
    """
    Reverse colors (text on dark/light background).
    """
    primary: str
    secondary: str
    selected: str


@dataclass(frozen=True)
class PaletteQColor:
    """
    Named color palette (green, yellow, blue, etc.).
    """
    darkGreen: str
    lightGreen: str
    yellow: str
    blue: str
    lilac: str
    maron: str  # kept 'maron' for compatibility
    difference: str


@dataclass(frozen=True)
class ProgressBarColors:
    """
    Progress bar colors.
    """
    background: str
    chunkBackground: str


@dataclass
class ThemeDefinition:
    """
    Complete theme definition (dark or light).
    Groups widget, button, menu, reverse, qcolor, progress_bar and loose colors.
    """
    widget: WidgetColors
    button: ButtonColors
    menu: MenuColors
    reverse: ReverseColors
    qcolor: PaletteQColor
    progressBar: ProgressBarColors
    division: str
    footer: str
    shadow: str
    table: str
    tableAlternate: str
    tableSelectionBackground: str
    primary: str
    secondary: str
    tertiary: str
    placeholder: str

    def getByPath(self, *path: str) -> str:
        """
        Get a value by attribute path, e.g. ('widget', 'background').
        
        Args:
            *path: Variable number of attribute path strings.
        
        Returns:
            The value at the specified path as string.
        """
        currentObject: Any = self
        for pathKey in path:
            currentObject = getattr(currentObject, pathKey)
        return currentObject if isinstance(currentObject, str) else str(currentObject)


# --- Tema escuro ---

DARK_THEME = ThemeDefinition(
    widget=WidgetColors(
        background="rgb(27, 31, 39)",
        hoverBackground="rgb(30, 34, 43)",
        hoverBorder="rgb(64, 71, 88)",
        focusBorder="rgb(86, 96, 119)",
        selectedBackground="rgb(43, 49, 57)",
    ),
    button=ButtonColors(
        background="rgb(52, 59, 72)",
        hover=ButtonStateColors(
            background="rgb(57, 65, 80)",
            border="rgb(61, 70, 86)",
        ),
        pressed=ButtonStateColors(
            background="rgb(50, 57, 70)",
            border="rgb(57, 68, 82)",
        ),
    ),
    menu=MenuColors(
        background="rgb(20, 25, 32)",
        button=MenuButtonColors(
            background="rgb(52, 59, 72)",
            hover=ButtonStateColors(
                background="rgb(57, 65, 80)",
                border="rgb(61, 70, 86)",
            ),
            pressed=ButtonStateColors(
                background="rgb(50, 57, 70)",
                border="rgb(57, 68, 82)",
            ),
        ),
    ),
    reverse=ReverseColors(
        primary="rgb(200, 200, 200)",
        secondary="rgb(220, 220, 220)",
        selected="rgb(250, 250, 250)",
    ),
    qcolor=PaletteQColor(
        darkGreen="rgb(53,110,58)",
        lightGreen="rgb(87, 166, 74)",
        yellow="rgb(220, 219, 155)",
        blue="rgb(50, 97, 195)",
        lilac="rgb(182, 141, 213)",
        maron="rgb(214,157, 133)",
        difference="rgb(55,55, 55)",
    ),
    progressBar=ProgressBarColors(
        background="rgb(20, 24, 32)",
        chunkBackground="rgb(61, 70, 86)",
    ),
    division="rgb(44, 49, 58)",
    footer="rgb(20, 25, 32)",
    shadow="rgb(15, 15, 15)",
    table="rgb(22, 28, 35)",
    tableAlternate="rgb(15, 22, 30)",
    tableSelectionBackground="rgb(10, 15, 22)",
    primary="rgb(33, 37, 43)",
    secondary="rgb(40, 44, 52)",
    tertiary="rgb(47, 51, 59)",
    placeholder="rgb(130, 130, 130)",
)


# --- Tema claro ---

LIGHT_THEME = ThemeDefinition(
    widget=WidgetColors(
        background="rgb(245, 245, 245)",
        hoverBackground="rgb(240, 240, 240)",
        hoverBorder="rgb(200, 200, 200)",
        focusBorder="rgb(180, 180, 180)",
        selectedBackground="rgb(210, 210, 210)",
    ),
    button=ButtonColors(
        background="rgba(225, 225, 225, 220)",
        hover=ButtonStateColors(
            background="rgba(220, 220, 220, 250)",
            border="rgb(215, 215, 215)",
        ),
        pressed=ButtonStateColors(
            background="rgba(210, 210, 210, 250)",
            border="rgb(225, 225, 225)",
        ),
    ),
    menu=MenuColors(
        background="rgb(245, 245, 245)",
        button=MenuButtonColors(
            background="rgba(225, 225, 225, 220)",
            hover=ButtonStateColors(
                background="rgba(220, 220, 220, 250)",
                border="rgb(215, 215, 215)",
            ),
            pressed=ButtonStateColors(
                background="rgba(230, 230, 230, 230)",
                border="rgb(225, 225, 225)",
            ),
        ),
    ),
    reverse=ReverseColors(
        primary="rgb(60, 60, 60)",
        secondary="rgb(80, 80, 80)",
        selected="rgb(20, 20, 20)",
    ),
    qcolor=PaletteQColor(
        darkGreen="rgb(53,110,58)",
        lightGreen="rgb(87, 166, 74)",
        yellow="rgb(180, 170, 0)",
        blue="rgb(50, 97, 195)",
        lilac="rgb(200, 0, 255)",
        maron="rgb(135,70, 39)",
        difference="rgb(200,200, 200)",
    ),
    progressBar=ProgressBarColors(
        background="rgb(220, 220, 220)",
        chunkBackground="rgb(180,180,180)",
    ),
    division="rgb(225, 225, 225)",
    footer="rgb(245, 245, 245)",
    shadow="rgb(230, 230, 230)",
    table="rgb(240, 240, 240)",
    tableAlternate="rgb(235, 235, 235)",
    tableSelectionBackground="rgb(255, 255, 255)",
    primary="rgb(255, 255, 255)",
    secondary="rgb(235, 235, 235)",
    tertiary="rgb(220, 220, 220)",
    placeholder="rgb(170, 170, 170)",
)


class ThemeRegistry:
    """
    Theme registry by name. Allows getting values by path and overrides
    for setBaseStyle.
    """
    def __init__(self):
        """
        Initialize the ThemeRegistry.
        """
        self._themes: Dict[str, ThemeDefinition] = {
            "dark": DARK_THEME,
            "light": LIGHT_THEME,
        }
        self._overrides: Dict[str, Dict[str, str]] = {"dark": {}, "light": {}}

    def getTheme(self, themeName: str) -> ThemeDefinition:
        """
        Get a theme definition by name.
        
        Args:
            themeName: The theme name ('dark' or 'light').
        
        Returns:
            The ThemeDefinition object.
        """
        return self._themes[themeName]

    def getValue(self, themeName: str, *path: str) -> str:
        """
        Get value by path; overrides have priority for level 1 paths.
        
        Args:
            themeName: The theme name ('dark' or 'light').
            *path: Variable number of attribute path strings.
        
        Returns:
            The value at the specified path as string.
        """
        if len(path) == 1 and path[0] in self._overrides.get(themeName, {}):
            return self._overrides[themeName][path[0]]
        themeDefinition = self._themes[themeName]
        return themeDefinition.getByPath(*path)

    def setOverride(self, themeName: str, key: str, value: str) -> None:
        """
        Set an override (e.g., for setBaseStyle).
        
        Args:
            themeName: The theme name ('dark' or 'light').
            key: The override key.
            value: The override value.
        """
        if themeName not in self._overrides:
            self._overrides[themeName] = {}
        self._overrides[themeName][key] = value


# Global instance used by ColorTheme and setBaseStyle
registry = ThemeRegistry()
