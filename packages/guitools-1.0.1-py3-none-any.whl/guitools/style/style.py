# -*- coding: latin -*-
from .resources.QtResource import *
from PySide6.QtWidgets import QGraphicsDropShadowEffect, QPushButton, QWidget, QLabel, QMainWindow, QApplication,  QTreeWidget, QTabWidget, QTabBar
from .utils import TypeTheme, Global
from .widgets import WidgetsTheme, WidgetsStyleCheet, BaseWidgetStyleSheet, Standard
from .widgets.treeView import TreeViewStyleSheet
from .styleSheet import BaseColor, setBaseStyle, ColorTheme, RGBColor
from typing import Literal
import subprocess
from PySide6.QtCore import QSize
from .svg import SVG
from .resources import Resources
from typing import Callable
from .resources import resourcesUpdate

def mainWindow() -> QMainWindow | None:
    """
    Get the main window instance from the application.
    
    Returns:
        The main window instance, or None if not found.
    """
    application = QApplication.instance()

    if not application:
        return None
    
    if isinstance(application, QMainWindow):
        return application
    
    for topLevelWidget in application.topLevelWidgets():
        if isinstance(topLevelWidget, QMainWindow):
            return topLevelWidget
    return None

class Styles(WidgetsStyleCheet):
    """
    Main styles class that provides access to all styling functionality.
    """

    class Resources(Resources):
        """
        Resources class for managing icons and resources.
        """
        
        class Data(object):
            """
            Data class for icon resources.
            """
            def __init__(self, callableIcon: Callable, hoverCallableIcon: Callable, pixmapSize: int | None = None) -> None:
                """
                Initialize the icon data.
                
                Args:
                    callableIcon: Callable that returns the default icon.
                    hoverCallableIcon: Callable that returns the hover icon.
                    pixmapSize: Optional pixmap size. Defaults to None.
                """
                self.callableIcon: Callable = callableIcon
                self.hoverCallableIcon: Callable = hoverCallableIcon if hoverCallableIcon else callableIcon
                self.pixmapSize: int | None = pixmapSize

    class TypeTheme(TypeTheme):
        """
        TypeTheme class for theme types.
        """
        ...

    @staticmethod
    def setAppColor(color: str) -> None:
        """
        Set the application color.
        
        Args:
            color: The color string to set.
        """
        Global.appColor = color

    @staticmethod
    def appColor() -> str:
        """
        Get the application color.
        
        Returns:
            The application color string.
        """
        return Global.appColor

    @staticmethod
    def desktopTheme() -> TypeTheme:
        """
        Get the desktop theme (dark or light) from system settings.
        
        Returns:
            The desktop theme type.
        """
        try:
            commandResult = subprocess.run(
                ["gsettings", "get", "org.gnome.desktop.interface", "gtk-theme"],
                stdout=subprocess.PIPE, text=True
            )
            themeName = commandResult.stdout.strip().lower()
            return TypeTheme.dark if "dark" in themeName else TypeTheme.light
        except Exception:
            return TypeTheme.light

    @staticmethod
    def currentTheme() -> TypeTheme:
        """
        Get the current theme.
        
        Returns:
            The current theme type.
        """
        return Global.theme
    
    @staticmethod
    def resourcesUpdate(resourcesFolder: str, outputFolder: str | None = None, *, isQt: bool = False, select: tuple[int, int, int] = (73, 145, 246), dark: tuple[int, int, int] = (55, 55, 55), light: tuple[int, int, int] = (200, 200, 200), gray: tuple[int, int, int] = (130, 130, 130)) -> None:
        """
        resources Update (images/icons) with theme colors.
        
        Args:
            resourcesFolder: Path to the resources folder.
            outputFolder: Optional output folder path. Defaults to None.
            isQt: Whether to generate Qt resource file. Defaults to False.
            select: RGB tuple for select color. Defaults to (73, 145, 246).
            dark: RGB tuple for dark theme color. Defaults to (55, 55, 55).
            light: RGB tuple for light theme color. Defaults to (200, 200, 200).
            gray: RGB tuple for gray color. Defaults to (130, 130, 130).
        """
        return resourcesUpdate(resourcesFolder, outputFolder, isQt=isQt, select=select, dark=dark, light=light, gray=gray)
    
    @staticmethod
    def convertRgbRgba(rgb: str | ColorTheme | RGBColor, alpha: str) -> str:
        """
        Convert RGB color to RGBA format.
        
        Args:
            rgb: RGB color string, ColorTheme, or RGBColor object.
            alpha: Alpha channel value.
        
        Returns:
            RGBA color string.
        """
        rgbString = rgb
        if isinstance(rgb, ColorTheme | RGBColor):
            rgbString = rgb.rgb
        if 'a' not in rgbString:
            rgbString = rgbString.replace("rgb", "rgba")
        return rgbString.replace(")", f",{alpha})")

    @staticmethod
    def setBaseStyle(theme: TypeTheme, baseColor: BaseColor) -> None:
        """
        Set the base style for a theme.
        
        Args:
            theme: The theme type.
            baseColor: The base color object.
        """
        setBaseStyle(theme, baseColor)

    @classmethod 
    def oppositeTheme(cls) -> TypeTheme:
        """
        Get the opposite theme (dark if light, light if dark).
        
        Returns:
            The opposite theme type.
        """
        return cls.TypeTheme.dark if Global.theme == cls.TypeTheme.light else cls.TypeTheme.light

    @classmethod
    def load(cls, theme: str) -> None:
        """
        Load a theme and update all widgets.
        
        Args:
            theme: The theme name to load.
        """
        if theme not in cls.TypeTheme.list():
            theme = cls.TypeTheme.light

        Global.theme = theme
        Standard.load()
        WidgetsTheme.update()

    @classmethod
    def init(cls, theme: str, appColor: str | None = None) -> None:
        """
        Initialize the styles system with a theme and optional app color.
        
        Args:
            theme: The theme name to initialize.
            appColor: Optional application color. Defaults to None.
        """
        if appColor:
            Global.appColor = appColor
        Global.theme = theme
        Standard.load()
        WidgetsTheme.update()
   
    def setWidgetStyleTheme(widgetStyle: BaseWidgetStyleSheet, *widgets: QWidget) -> None:
        """
        Set a themed stylesheet for one or more widgets.
        
        Args:
            widgetStyle: The stylesheet to apply.
            *widgets: Variable number of widgets to apply the style to.
        """
        for targetWidget in widgets:
            WidgetsTheme.setWidgetStyleTheme(targetWidget, widgetStyle)
            targetWidget.setStyleSheet(str(widgetStyle))

    def setIcon(widget: QPushButton | QLabel, callableIcon: Callable, hoverCallableIcon: Callable, pixmapSize: int | None = None) -> None:
        """
        Set themed icons for a widget.
        
        Args:
            widget: The widget to apply icons to.
            callableIcon: Callable that returns the default icon.
            hoverCallableIcon: Callable that returns the hover icon.
            pixmapSize: Optional pixmap size. Defaults to None.
        """
        WidgetsTheme.setIcon(widget, callableIcon, hoverCallableIcon, pixmapSize)

    def toggleIconActive(widget: QPushButton | QLabel) -> None:
        """
        Toggle the active state of an icon widget.
        
        Args:
            widget: The widget whose icon active state should be toggled.
        """
        WidgetsTheme.toggleIconActive(widget)
        
    @classmethod
    def setIconToggleTheme(cls, widget: QPushButton) -> None:
        """
        Set icon for theme toggle button based on current theme.
        
        Args:
            widget: The button widget to set icon for.
        """
        if Global.theme == cls.TypeTheme.light:
            cls.setIcon(widget, Styles.Resources.lightMode.gray, Styles.Resources.lightMode.select)
        else:
            cls.setIcon(widget, Styles.Resources.darkMode.gray, Styles.Resources.darkMode.select)

    @classmethod
    def setTreeWidgetAlternateBackgroundColor(cls, widget: QTreeWidget, style: TreeViewStyleSheet | None = None) -> None:
        """
        Set alternate background color for a tree widget.
        
        Args:
            widget: The tree widget to apply alternate background to.
            style: Optional custom TreeViewStyleSheet. Defaults to None.
        """
        if not style:
            style = TreeViewStyleSheet(singleBackgroundColor='transparent')
            style.scrollBarHorizontal.backgroundColor.value = BaseColor.table
            style.scrollBarVertical.backgroundColor.value = BaseColor.table
            style.itemSelected.color = None

        style.item.backgroundColor = None
        style.itemNotselected.backgroundColor = None

        style.item.addAdditionalStyle('height: 30px;')
        cls.setWidgetStyleTheme(style, widget)
        WidgetsTheme.setTreeWidgetAlternateBackgroundColor(widget)

    @staticmethod
    def setupTabIcons(widget: QTabWidget | QTabBar, *data: Resources.Data) -> None:
        """
        Setup icons for tabs that change based on selection.
        
        Args:
            widget: The tab widget or tab bar.
            *data: Variable number of Resources.Data objects for each tab.
        """
        def updateTabIcons(selectedIndex: int) -> None:
            for tabIndex, resourceData in enumerate(data):
                if tabIndex == selectedIndex:
                    widget.setTabIcon(tabIndex, resourceData.hoverCallableIcon())
                else:
                    widget.setTabIcon(tabIndex, resourceData.callableIcon())
        updateTabIcons(0)
        widget.currentChanged.connect(updateTabIcons)

    @classmethod
    def createStyleWidgetSearch(cls, ids: list[str], borderSide: Literal['bottom', 'top', ''] = 'bottom', borderRadius: int = 5) -> str:
        """
        Create a stylesheet for search widget with specified IDs.
        
        Args:
            ids: List of widget IDs to style.
            borderSide: Which side to add border ('bottom', 'top', or ''). Defaults to 'bottom'.
            borderRadius: Border radius value. Defaults to 5.
        
        Returns:
            The generated stylesheet string.
        """
        styleParts = []
        elementIds = list(ids)
        styleParts.append(
            Styles.CreateStyleSheet(
                Styles.Property.Background()
            ).addIds(*elementIds)
        )

        styleParts.append(
            Styles.CreateStyleSheet(
                Styles.Property.Border(color=Styles.Color.Widget.focusBorder),
                Styles.Property.Background(value=Styles.Color.Widget.hoverBackground),
                Styles.Property.Border(radius=borderRadius)
            ).addIds(*elementIds, suffix="::hover")
        )

        for elementId in elementIds:
            styleParts.append(
                Styles.lineEdit(prefix=f"#{elementId}", transparent=True, border=False).styleSheet()
            )

        buttonSelectors = [f"#{elementId} QPushButton" for elementId in elementIds]
        styleParts.append(
            Styles.CreateStyleSheet(
                Styles.Property.Border(topRightRadius=0, bottomRightRadius=0, topLeftRadius=3, bottomLeftRadius=3)
            ).addClassName(*buttonSelectors)
        )

        if borderSide in ("top", "bottom"):
            for elementId in elementIds:
                styleParts.append(
                    f"#{elementId} {{ border-{borderSide}: 1px solid {Styles.Color.division.horizontalGradient()} border-{borderSide}-left-radius: 0px; border-{borderSide}-right-radius: 0px; }}"
                )

        return '\n'.join(styleParts)

    @classmethod
    def iconFile(cls, filePath: str):
        """
        Get an icon for a file based on its extension.
        
        Args:
            filePath: The file path to get icon for.
        
        Returns:
            The icon for the file type.
        """
        if filePath.endswith(".vb"):
            return Resources.vbFile.original()
        elif filePath.endswith(".cs"):
            return Resources.csharpFile.original() 
        elif filePath.endswith(".py"):
            return Resources.pythonFile.original() 
        elif filePath.endswith(".pdf"):
            return Resources.pdf.original() 
        elif filePath.endswith(".xlsx") or filePath.endswith(".xls"):
            return Resources.xls.original() 
        elif filePath.endswith(".json"):
            return Resources.json.gray()
        elif filePath.endswith('html'):
            svgContent = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><title>file_type_html</title><polygon points="5.902 27.201 3.655 2 28.345 2 26.095 27.197 15.985 30 5.902 27.201" style="fill:#e44f26"/><polygon points="16 27.858 24.17 25.593 26.092 4.061 16 4.061 16 27.858" style="fill:#f1662a"/><polygon points="16 13.407 11.91 13.407 11.628 10.242 16 10.242 16 7.151 15.989 7.151 8.25 7.151 8.324 7.981 9.083 16.498 16 16.498 16 13.407" style="fill:#ebebeb"/><polygon points="16 21.434 15.986 21.438 12.544 20.509 12.324 18.044 10.651 18.044 9.221 18.044 9.654 22.896 15.986 24.654 16 24.65 16 21.434" style="fill:#ebebeb"/><polygon points="15.989 13.407 15.989 16.498 19.795 16.498 19.437 20.507 15.989 21.437 15.989 24.653 22.326 22.896 22.372 22.374 23.098 14.237 23.174 13.407 22.341 13.407 15.989 13.407" style="fill:#fff"/><polygon points="15.989 7.151 15.989 9.071 15.989 10.235 15.989 10.242 23.445 10.242 23.445 10.242 23.455 10.242 23.517 9.548 23.658 7.981 23.732 7.151 15.989 7.151" style="fill:#fff"/></svg>'
            return SVG.stringToIcon(svgContent, QSize(32, 32))
        elif filePath.endswith('css'):
            svgContent = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><title>file_type_css</title><polygon points="5.902 27.201 3.656 2 28.344 2 26.095 27.197 15.985 30 5.902 27.201" style="fill:#1572b6"/><polygon points="16 27.858 24.17 25.593 26.092 4.061 16 4.061 16 27.858" style="fill:#33a9dc"/><polygon points="16 13.191 20.09 13.191 20.372 10.026 16 10.026 16 6.935 16.011 6.935 23.75 6.935 23.676 7.764 22.917 16.282 16 16.282 16 13.191" style="fill:#fff"/><polygon points="16.019 21.218 16.005 21.222 12.563 20.292 12.343 17.827 10.67 17.827 9.24 17.827 9.673 22.68 16.004 24.438 16.019 24.434 16.019 21.218" style="fill:#ebebeb"/><polygon points="19.827 16.151 19.455 20.29 16.008 21.22 16.008 24.436 22.344 22.68 22.391 22.158 22.928 16.151 19.827 16.151" style="fill:#fff"/><polygon points="16.011 6.935 16.011 8.855 16.011 10.018 16.011 10.026 8.555 10.026 8.555 10.026 8.545 10.026 8.483 9.331 8.342 7.764 8.268 6.935 16.011 6.935" style="fill:#ebebeb"/><polygon points="16 13.191 16 15.111 16 16.274 16 16.282 12.611 16.282 12.611 16.282 12.601 16.282 12.539 15.587 12.399 14.02 12.325 13.191 16 13.191" style="fill:#ebebeb"/></svg>'
            return SVG.stringToIcon(svgContent, QSize(32, 32))
        elif filePath.endswith('js'):
            svgContent = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><title>file_type_js</title><path d="M18.774,19.7a3.727,3.727,0,0,0,3.376,2.078c1.418,0,2.324-.709,2.324-1.688,0-1.173-.931-1.589-2.491-2.272l-.856-.367c-2.469-1.052-4.11-2.37-4.11-5.156,0-2.567,1.956-4.52,5.012-4.52A5.058,5.058,0,0,1,26.9,10.52l-2.665,1.711a2.327,2.327,0,0,0-2.2-1.467,1.489,1.489,0,0,0-1.638,1.467c0,1.027.636,1.442,2.1,2.078l.856.366c2.908,1.247,4.549,2.518,4.549,5.376,0,3.081-2.42,4.769-5.671,4.769a6.575,6.575,0,0,1-6.236-3.5ZM6.686,20c.538.954,1.027,1.76,2.2,1.76,1.124,0,1.834-.44,1.834-2.15V7.975h3.422V19.658c0,3.543-2.078,5.156-5.11,5.156A5.312,5.312,0,0,1,3.9,21.688Z" style="fill:#f5de19"/></svg>'
            return SVG.stringToIcon(svgContent, QSize(32, 32))
        elif filePath.endswith('.md'):
            svgContent = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><title>file_type_markdown</title><rect x="2.5" y="7.955" width="27" height="16.091" style="fill:none;stroke:#755838"/><polygon points="5.909 20.636 5.909 11.364 8.636 11.364 11.364 14.773 14.091 11.364 16.818 11.364 16.818 20.636 14.091 20.636 14.091 15.318 11.364 18.727 8.636 15.318 8.636 20.636 5.909 20.636" style="fill:#755838"/><polygon points="22.955 20.636 18.864 16.136 21.591 16.136 21.591 11.364 24.318 11.364 24.318 16.136 27.045 16.136 22.955 20.636" style="fill:#755838"/></svg>'
            return SVG.stringToIcon(svgContent, QSize(32, 32))
        elif filePath.endswith('.vcxproj'):
            svgContent = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><title>file_type_vcxproj</title><path d="M29.821,4.321,24.023,2,11.493,14.212,3.833,8.385l-1.654.837V22.8l1.644.827,7.65-5.827L24.023,30l5.8-2.321V4.321ZM4.65,19.192V12.818L8.2,15.985ZM16,15.985l7.082-5.3V21.324l-7.092-5.339Z" style="fill:#68217a"/><polygon points="15.995 15.985 23.077 10.686 23.077 21.324 15.985 15.985 15.995 15.985" style="fill:#fff"/><polygon points="4.65 19.192 4.65 12.818 8.196 15.985 4.65 19.192" style="fill:#fff"/><path d="M15.553,32a7.185,7.185,0,0,1-5.541-2.244A8.131,8.131,0,0,1,8,24.05a8.587,8.587,0,0,1,2.222-6.086,7.631,7.631,0,0,1,5.809-2.415,9.876,9.876,0,0,1,3.571.583l.955.372v6.569l-2.3-1.456a3.636,3.636,0,0,0-2-.548,2.127,2.127,0,0,0-1.684.668,2.975,2.975,0,0,0-.663,2.1,2.9,2.9,0,0,0,.62,2.008,1.918,1.918,0,0,0,1.572.618,3.976,3.976,0,0,0,2.165-.607l2.293-1.427v6.292l-.815.419A9.177,9.177,0,0,1,15.553,32Z" style="fill:#efeef0"/><polygon points="24.092 27.909 19.334 27.909 19.334 26.152 17.578 26.152 17.578 21.394 19.334 21.395 19.334 19.638 24.092 19.638 24.092 21.396 25.85 21.396 25.85 26.152 24.092 26.152 24.092 27.909" style="fill:#efeef0"/><polygon points="30.243 27.909 25.485 27.909 25.485 26.152 23.728 26.152 23.728 21.394 25.485 21.395 25.485 19.638 30.243 19.638 30.243 21.396 32 21.396 32 26.152 30.243 26.152 30.243 27.909" style="fill:#efeef0"/><path d="M19.057,29.808a7.682,7.682,0,0,1-3.5.689,5.721,5.721,0,0,1-4.436-1.759A6.657,6.657,0,0,1,9.5,24.05a7.107,7.107,0,0,1,1.817-5.06,6.162,6.162,0,0,1,4.714-1.941,8.364,8.364,0,0,1,3.026.481V20.35a5.129,5.129,0,0,0-2.8-.78,3.61,3.61,0,0,0-2.787,1.152,4.428,4.428,0,0,0-1.06,3.12,4.349,4.349,0,0,0,1,3.007,3.428,3.428,0,0,0,2.693,1.12,5.489,5.489,0,0,0,2.958-.834Z" style="fill:#984c93"/><polygon points="20.834 22.895 20.834 21.137 22.592 21.137 22.592 22.895 24.35 22.895 24.35 24.652 22.592 24.652 22.592 26.409 20.834 26.409 20.834 24.652 19.078 24.652 19.078 22.894 20.834 22.895" style="fill:#984c93"/><polygon points="26.985 22.895 26.985 21.137 28.743 21.137 28.743 22.895 30.5 22.895 30.5 24.652 28.743 24.652 28.743 26.409 26.985 26.409 26.985 24.652 25.228 24.652 25.228 22.894 26.985 22.895" style="fill:#984c93"/></svg>'
            return SVG.stringToIcon(svgContent, QSize(32, 32))
        elif filePath.endswith('.njsproj'):
            svgContent = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><title>file_type_njsproj</title><path d="M29.821,4.321,24.023,2,11.493,14.212,3.833,8.385l-1.654.837V22.8l1.644.827,7.65-5.827L24.023,30l5.8-2.321V4.321ZM4.65,19.192V12.818L8.2,15.985ZM16,15.985l7.082-5.3V21.324l-7.092-5.339Z" style="fill:#68217a"/><polygon points="15.995 15.985 23.077 10.686 23.077 21.324 15.985 15.985 15.995 15.985" style="fill:#fff"/><polygon points="4.65 19.192 4.65 12.818 8.196 15.985 4.65 19.192" style="fill:#fff"/><path d="M25.9,32.029a6.842,6.842,0,0,1-6.4-3.658l-.6-1.189,3.826-2.223A5.233,5.233,0,0,1,20.2,20.305c0-2.976,2.329-5.135,5.539-5.135a5.568,5.568,0,0,1,5.236,2.971l.661,1.163-3.277,2.105c1.895.938,3.628,2.324,3.628,5.28C31.983,29.884,29.538,32.029,25.9,32.029Zm-1.549-6.216a1.587,1.587,0,0,0,1.484.891,1.52,1.52,0,0,0,.374-.041,11.343,11.343,0,0,0-1.078-.515l-.7-.3Zm-9.319,6.21a5.77,5.77,0,0,1-5.505-3.383L8.983,27.49l4.629-2.8.716,1.268c.413.732.477.732.584.732l.075,0a2.385,2.385,0,0,0,.023-.358v-11h5.642V26.365C20.652,29.855,18.5,32.024,15.032,32.024Z" style="fill:#efeef0"/><path d="M13.1,26.649c.443.786.846,1.45,1.814,1.45.926,0,1.51-.362,1.51-1.771V16.743h2.818v9.622c0,2.918-1.711,4.247-4.209,4.247A4.375,4.375,0,0,1,10.8,28.038Z" style="fill:#83cd29"/><path d="M23.055,26.4a3.07,3.07,0,0,0,2.78,1.712c1.168,0,1.914-.584,1.914-1.39,0-.966-.767-1.309-2.052-1.871l-.7-.3c-2.034-.866-3.385-1.952-3.385-4.247,0-2.114,1.611-3.723,4.128-3.723a4.166,4.166,0,0,1,4.009,2.257l-2.195,1.409a1.917,1.917,0,0,0-1.814-1.208,1.226,1.226,0,0,0-1.349,1.208c0,.846.524,1.188,1.733,1.712l.7.3c2.395,1.027,3.747,2.074,3.747,4.428,0,2.538-1.993,3.928-4.671,3.928a5.415,5.415,0,0,1-5.136-2.882Z" style="fill:#83cd29"/></svg>'
            return SVG.stringToIcon(svgContent, QSize(32, 32))
        elif filePath.endswith('.vbproj'):
            svgContent = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><title>file_type_vbproj</title><path d="M29.821,4.321,24.023,2,11.493,14.212,3.833,8.385l-1.654.837V22.8l1.644.827,7.65-5.827L24.023,30l5.8-2.321V4.321ZM4.65,19.192V12.818L8.2,15.985ZM16,15.985l7.082-5.3V21.324l-7.092-5.339Z" style="fill:#68217a"/><polygon points="15.995 15.985 23.077 10.686 23.077 21.324 15.985 15.985 15.995 15.985" style="fill:#fff"/><polygon points="4.65 19.192 4.65 12.818 8.196 15.985 4.65 19.192" style="fill:#fff"/><polygon points="17.631 32.03 11.87 32.03 7.511 15.53 14.216 15.53 14.749 18.269 15.282 15.53 21.985 15.53 17.631 32.03" style="fill:#efeef0"/><path d="M27.556,32.03H20.245V15.53l7.37.011a4.517,4.517,0,0,1,3.24,2.115,5.032,5.032,0,0,1,.69,2.592,5.164,5.164,0,0,1-.643,2.471c-.066.114-.137.225-.21.332a4.893,4.893,0,0,1,.6.771,5.041,5.041,0,0,1,.7,2.586,5.757,5.757,0,0,1-.623,2.89,5.328,5.328,0,0,1-3.7,2.713Z" style="fill:#efeef0"/><path d="M13,17.153l1.749,8.993L16.5,17.153H20L16.5,30.407H13L9.5,17.153Z" style="fill:#00519a"/><path d="M21.745,17.153h5.7a3.032,3.032,0,0,1,2.174,1.42,3.26,3.26,0,0,1,.428,1.656,3.437,3.437,0,0,1-.428,1.651,3.119,3.119,0,0,1-1.756,1.431,3.045,3.045,0,0,1,2.2,1.426,3.282,3.282,0,0,1,.435,1.7,4.041,4.041,0,0,1-.434,2.067,3.788,3.788,0,0,1-2.624,1.9h-5.69Zm3.5,5.207h.874a1.393,1.393,0,0,0,1.213-1.528,1.374,1.374,0,0,0-1.213-1.313h-.874Zm0,5.684H26.29A1.619,1.619,0,0,0,27.74,26.3a1.6,1.6,0,0,0-1.45-1.57H25.245Z" style="fill:#00519a"/></svg>'
            return SVG.stringToIcon(svgContent, QSize(32, 32))
        elif filePath.endswith('.vbhtml.'):
            svgContent = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><title>file_type_vbhtml</title><path d="M23.844,27.692a16.332,16.332,0,0,1-6.645,1.3q-6.364,0-10.013-3.243a11.3,11.3,0,0,1-3.649-8.9A13.716,13.716,0,0,1,7.322,6.951,12.716,12.716,0,0,1,16.9,3.008a11.676,11.676,0,0,1,8.425,3.006,9.994,9.994,0,0,1,3.142,7.533,10.187,10.187,0,0,1-2.318,7.114,7.532,7.532,0,0,1-5.817,2.547,2.613,2.613,0,0,1-1.845-.642,2.323,2.323,0,0,1-.764-1.6,4.9,4.9,0,0,1-4.148,2.243,4.6,4.6,0,0,1-3.507-1.479,5.706,5.706,0,0,1-1.384-4.063,9.913,9.913,0,0,1,2.2-6.357q2.2-2.763,4.8-2.763a5.063,5.063,0,0,1,4.256,1.716l.311-1.338h2.405l-2.081,9.08a10.716,10.716,0,0,0-.352,2.243q0,.972.744.972a4.819,4.819,0,0,0,3.877-2.047,8.93,8.93,0,0,0,1.621-5.681,7.98,7.98,0,0,0-2.675-6.175,9.887,9.887,0,0,0-6.919-2.432A10.6,10.6,0,0,0,8.713,8.352a12.066,12.066,0,0,0-3.2,8.495,9.561,9.561,0,0,0,3.06,7.573q3.06,2.7,8.586,2.7a13.757,13.757,0,0,0,5.675-1.054ZM19.466,12.25a3.977,3.977,0,0,0-3.6-1.716q-1.824,0-3.263,2.23a8.726,8.726,0,0,0-1.439,4.824q0,3.635,2.905,3.635A3.771,3.771,0,0,0,16.72,20.04a6.309,6.309,0,0,0,1.7-3.2Z" style="fill:#004b96"/></svg>'
            return SVG.stringToIcon(svgContent, QSize(32, 32))
        elif filePath.endswith('.csproj'):
            svgContent = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><title>file_type_csproj</title><path d="M29.821,4.321,24.023,2,11.493,14.212,3.833,8.385l-1.654.837V22.8l1.644.827,7.65-5.827L24.023,30l5.8-2.321V4.321ZM4.65,19.192V12.818L8.2,15.985ZM16,15.985l7.082-5.3V21.324l-7.092-5.339Z" style="fill:#68217a"/><polygon points="15.995 15.985 23.077 10.686 23.077 21.324 15.985 15.985 15.995 15.985" style="fill:#fff"/><polygon points="4.65 19.192 4.65 12.818 8.196 15.985 4.65 19.192" style="fill:#fff"/><polygon points="30.089 28.175 21.345 28.174 21.345 26.259 19.43 26.257 19.43 17.516 21.344 17.517 21.342 15.604 30.087 15.604 30.087 17.519 32.001 17.519 31.999 21.346 32 21.346 32 26.261 30.088 26.261 30.089 28.175" style="fill:#efeef0"/><path d="M15.527,32A7.159,7.159,0,0,1,10,29.758a8.1,8.1,0,0,1-2-5.683,8.56,8.56,0,0,1,2.213-6.063A7.608,7.608,0,0,1,16,15.6a9.836,9.836,0,0,1,3.558.581l.956.372v6.56l-2.3-1.458a3.6,3.6,0,0,0-1.989-.544,2.117,2.117,0,0,0-1.672.662,2.957,2.957,0,0,0-.658,2.091,2.877,2.877,0,0,0,.615,2,1.9,1.9,0,0,0,1.562.614,3.968,3.968,0,0,0,2.153-.6l2.292-1.426v6.28l-.815.419A9.144,9.144,0,0,1,15.527,32Z" style="fill:#efeef0"/><path d="M22.844,17.1h1.915v1.915h1.914V17.1h1.914v1.915H30.5v1.914H28.587v1.913H30.5V24.76H28.587v1.914H26.673V24.762l-1.912,0,0,1.914H22.845V24.761l-1.915,0V22.844h1.915V20.935H20.93V19.017h1.915Zm1.915,5.744h1.914V20.932H24.759Z" style="fill:#368832"/><path d="M19.017,29.81a7.65,7.65,0,0,1-3.49.686,5.7,5.7,0,0,1-4.417-1.752A6.629,6.629,0,0,1,9.5,24.076a7.077,7.077,0,0,1,1.809-5.039A6.136,6.136,0,0,1,16,17.1a8.329,8.329,0,0,1,3.013.479v2.809a5.108,5.108,0,0,0-2.792-.777,3.6,3.6,0,0,0-2.775,1.147,4.409,4.409,0,0,0-1.055,3.107,4.331,4.331,0,0,0,1,2.994,3.413,3.413,0,0,0,2.681,1.115,5.466,5.466,0,0,0,2.945-.831Z" style="fill:#368832"/></svg>'
            return SVG.stringToIcon(svgContent, QSize(32, 32))
        elif filePath.endswith((".png", ".jpg", ".jpeg", ".gif", ".bmp", ".svg", ".tiff", ".ico", ".webp", ".psd", ".ai", ".eps")):
            svgContent = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><title>file_type_image</title><path d="M30,5.851Q30,16,30,26.149H2Q2,16,2,5.851H30" style="fill:#2dcc9f"/><path d="M24.232,8.541a2.2,2.2,0,1,0,1.127.623,2.212,2.212,0,0,0-1.127-.623" style="fill:#fff"/><path d="M18.111,20.1q-2.724-3.788-5.45-7.575Q8.619,18.147,4.579,23.766q5.449,0,10.9,0,1.316-1.832,2.634-3.663" style="fill:#fff"/><path d="M22.057,16q-2.793,3.882-5.584,7.765,5.584,0,11.169,0Q24.851,19.882,22.057,16Z" style="fill:#fff"/></svg>'
            return SVG.stringToIcon(svgContent, QSize(32, 32))
        
        return Resources.file.original()

    @classmethod
    def iconFileFromType(cls, fileType: Literal['vb', 'csharp', 'python', 'pdf', 'xlsx', 'xls', 'json'] = ""):
        """
        Get an icon for a file type.
        
        Args:
            fileType: The file type string.
        
        Returns:
            The icon for the file type.
        """
        return cls.iconFile(f'file.{fileType}')

    @classmethod
    def shadowEffect(cls, xOffset: float = 1.5, yOffset: float = 1.5, offset: float = 1.5, blurRadius: float = 15) -> QGraphicsDropShadowEffect:
        """
        Create a shadow effect for widgets.
        
        Args:
            xOffset: X offset for the shadow. Defaults to 1.5.
            yOffset: Y offset for the shadow. Defaults to 1.5.
            offset: General offset for the shadow. Defaults to 1.5.
            blurRadius: Blur radius for the shadow. Defaults to 15.
        
        Returns:
            The configured QGraphicsDropShadowEffect.
        """
        dropShadowEffect = QGraphicsDropShadowEffect()
        dropShadowEffect.setColor(cls.Color.shadow.QColor)
        dropShadowEffect.setXOffset(xOffset)
        dropShadowEffect.setYOffset(yOffset)
        dropShadowEffect.setOffset(offset)
        dropShadowEffect.setBlurRadius(blurRadius)
        return dropShadowEffect







