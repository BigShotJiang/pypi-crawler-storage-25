                                                                                             
import os  
from ..svg import SVG
from os import path
import xml.etree.ElementTree as ET
from PIL import Image
from pathlib import Path
import shutil
from PySide6.QtGui import QImage
from tempfile import gettempdir
import re
import unicodedata
import subprocess
import textwrap

def tempFolder(folder: str | None = None, folderName: str = "MyGuiTempFolder") -> str:
        """
        Create or get a temporary folder path.
        
        Args:
            folder: Optional subfolder name. Defaults to None.
            folderName: Base folder name. Defaults to "MyGuiTempFolder".
        
        Returns:
            The path to the temporary folder.
        """
        tempDir = gettempdir()
        tempPath = os.path.join(tempDir, folderName)
        if folder:
            tempPath = os.path.join(tempPath, folder)
        if not os.path.exists(tempPath):
            os.makedirs(tempPath)
        return tempPath

class ResourcesUpdate(object):
    """
    A class for updating and processing image resources.
    
    This class provides functionality to change image colors, convert images,
    and generate resource files for Qt or Python.
    """

    def __init__(self) -> None:
        """
        Initialize the ResourcesUpdate instance.
        """
        self.tempFolder = tempFolder()

    def changeImageColor(self, imagePath: str, newColor: tuple[int, int, int]) -> Image.Image:
        """
        Change the color of an image to a new color.
        
        Args:
            imagePath: Path to the image file.
            newColor: RGB tuple for the new color.
        
        Returns:
            A new Image with the changed color.
        """
        # Open the image
        sourceImage = Image.open(imagePath)
    
        # Convert to "RGBA" mode (Red, Green, Blue, Alpha)
        sourceImage = sourceImage.convert("RGBA")
    
        # Extract color channels
        redChannel, greenChannel, blueChannel, alphaChannel = sourceImage.split()
    
        # Create a new image with the new color
        newRedChannel = redChannel.point(lambda _: newColor[0])
        newGreenChannel = greenChannel.point(lambda _: newColor[1])
        newBlueChannel = blueChannel.point(lambda _: newColor[2])
    
        # Merge color channels back together
        newImage = Image.merge("RGBA", (newRedChannel, newGreenChannel, newBlueChannel, alphaChannel))
    
        return newImage

    def convert(self, filePath: str, newColor: tuple[int, int, int], suffix: str) -> str | None:
        """
        Convert an image file to a new color variant.
        
        Args:
            filePath: Path to the image file.
            newColor: RGB tuple for the new color.
            suffix: Suffix to add to the filename.
        
        Returns:
            The new filename, or None if the file doesn't exist.
        """
        if path.exists(filePath):
            convertedImage = self.changeImageColor(filePath, newColor)
            
            fileExtension = Path(filePath).suffix
            newFileName = f"{path.basename(filePath.replace(fileExtension, ''))}_{suffix}{fileExtension}"
            # Create the new filename with the color suffix

            convertedImage.save(f"{path.join(self.tempFolder, newFileName)}")
            return newFileName
        return None
    @classmethod
    def removeSpecialCharacters(cls, text: str) -> str:
        """
        Remove special characters and accents from text.
        
        Args:
            text: The text to process.
        
        Returns:
            Text without special characters and accents.
        """
        normalizedText = unicodedata.normalize('NFD', text)
        textWithoutAccents = ''.join(char for char in normalizedText if unicodedata.category(char) != 'Mn')
        return textWithoutAccents

    @classmethod
    def generateSlug(cls, name: str, lower: bool = False) -> str:
        """
        Generate a slug from a name.
        
        Args:
            name: The name to convert to a slug.
            lower: Whether to convert to lowercase. Defaults to True.
        
        Returns:
            A slug string.
        """
        processedName = cls.removeSpecialCharacters(name)
        if lower:
            slug = re.sub(r'\W+', '_', processedName.lower().strip())
        else:
            slug = re.sub(r'\W+', '_', processedName.strip())
        slug = re.sub(r'_+', '_', slug)
        slug = slug.strip('_')
        return slug
    
    @staticmethod
    def cleanFolder(folderPath: str) -> None:
        """
        Clean all files from a folder.
        
        This method checks if the folder exists and, if it does, removes all files contained in it.
        
        Args:
            folderPath: Path to the folder to clean.
        """
        if os.path.isdir(folderPath):
            for fileEntry in os.scandir(folderPath):
                if fileEntry.is_file():  # Check if it's a file before trying to remove it
                    os.remove(fileEntry.path)
        else:
            print(f'Folder: {folderPath} not found!')

    @staticmethod
    def listFiles(folderPath: str, ignoredFolders: list[str] = [], fileTypes: list[str] | tuple[str, ...] = (), ignoredFileTypes: list[str] | tuple[str, ...] = ()) -> list[str]:
        """
        List files in a folder and its subfolders.
        
        Args:
            folderPath: Path to the folder to search.
            ignoredFolders: List of folder names to ignore. Defaults to [].
            fileTypes: File extensions to include. Defaults to ().
            ignoredFileTypes: File extensions to ignore. Defaults to ().
        
        Returns:
            List of file paths.
        """
        results = []

        for currentFolder, subfolders, files in os.walk(folderPath):
            # Ignore specified folders
            subfolders[:] = [subfolder for subfolder in subfolders if subfolder not in ignoredFolders]

            for file in files:
                if not file.lower().endswith(tuple(ignoredFileTypes)) and not file.endswith(tuple(ignoredFileTypes)) and not file.upper().endswith(tuple(ignoredFileTypes)):
                    if file.lower().endswith(tuple(fileTypes)) or file.endswith(tuple(fileTypes)) or file.upper().endswith(tuple(fileTypes)):
                        filePath = f'{currentFolder}/{file}'
                        filePath = filePath.replace("\\", "/")
                        results.append(filePath)

        return results

    def update(self, resourcesFolder: str, outputFolder: str, select: tuple[int, int, int] = (76, 148, 244), dark: tuple[int, int, int] = (55, 55, 55), light: tuple[int, int, int] = (200, 200, 200), gray: tuple[int, int, int] = (130, 130, 130), isQt: bool = False) -> None:
        """
        Update image resources and generate Python or Qt files.
        
        Args:
            resourcesFolder: Path to the resources folder.
            outputFolder: Path to the output folder.
            select: RGB color for select variant. Defaults to (76, 148, 244).
            dark: RGB color for dark variant. Defaults to (55, 55, 55).
            light: RGB color for light variant. Defaults to (200, 200, 200).
            gray: RGB color for gray variant. Defaults to (130, 130, 130).
            isQt: Whether to generate Qt resource files. Defaults to False.
        """
        self.cleanFolder(self.tempFolder)

        imageExtensions = [".png", ".jpg", ".jpeg", ".gif", ".bmp"]
        imageFiles = self.listFiles(path.join(resourcesFolder), ['__pycache__'], imageExtensions)

        for imageFile in imageFiles:
            shutil.copy(imageFile, path.join(self.tempFolder, path.basename(imageFile)))

        def processImageVariants(fileResource: str) -> tuple[int, int, dict[str, str | None]]:
            """
            Process an image file and generate color variants.
            
            Args:
                fileResource: Path to the image file.
            
            Returns:
                Tuple of (width, height, variants_dict).
            """
            sourceImage = QImage(fileResource)
            imageSize = sourceImage.size()
            imageWidth, imageHeight = imageSize.width(), imageSize.height()
            colorVariants = {
                "select": self.convert(fileResource, select, "select"),
                "light":  self.convert(fileResource, light,  "light"),
                "dark":   self.convert(fileResource, dark,   "dark"),
                "gray":   self.convert(fileResource, gray,   "gray"),
            }
            return imageWidth, imageHeight, colorVariants

        # ========================== Qt Mode ==========================
        if isQt:
            rootElement = ET.Element("RCC")
            qresourceElement = ET.SubElement(rootElement, "qresource", prefix="/")

            resourceFiles = self.listFiles(self.tempFolder, ['__pycache__'], imageExtensions)
            for resourceFile in resourceFiles:
                ET.SubElement(qresourceElement, "file").text = path.basename(resourceFile)
                _, _, fileVariants = processImageVariants(resourceFile)
                for variantFileName in fileVariants.values():
                    if variantFileName:
                        ET.SubElement(qresourceElement, "file").text = variantFileName

            qrcFilePath = path.join(self.tempFolder, "QtResource.qrc")
            ET.ElementTree(rootElement).write(qrcFilePath, encoding="UTF-8", xml_declaration=True)

            runCmd(f"cd {self.tempFolder}", "pyside6-rcc QtResource.qrc -o QtResource.py")

            shutil.copy(path.join(self.tempFolder, "QtResource.py"), path.join(resourcesFolder, "QtResource.py"))
            shutil.copy(qrcFilePath, path.join(outputFolder, "QtResource.qrc"))

        # ======================== Python Mode ========================
        else:
            generatedFileContent = textwrap.dedent("""\
                # -*- coding: latin -*-
                from guitools.style.svg import SVG, Icon
                from guitools.style.utils import Global
                from PySide6.QtCore import QSize

                class Resources:
            """)

            resourceFiles = self.listFiles(self.tempFolder, ['__pycache__'], imageExtensions)
            for resourceFile in resourceFiles:
                imageWidth, imageHeight, fileVariants = processImageVariants(resourceFile)
                originalFileName = path.basename(resourceFile)
                fileNameWithoutExt = os.path.splitext(originalFileName)[0]
                outputSvgPath = path.join(self.tempFolder, "output.svg")

                svgContentData = {
                    "original": SVG.imageToStringSvg(resourceFile, outputSvgPath),
                    "select":   SVG.imageToStringSvg(path.join(self.tempFolder, fileVariants["select"]), outputSvgPath) if fileVariants["select"] else "",
                    "light":    SVG.imageToStringSvg(path.join(self.tempFolder, fileVariants["light"]),  outputSvgPath) if fileVariants["light"] else "",
                    "dark":     SVG.imageToStringSvg(path.join(self.tempFolder, fileVariants["dark"]),   outputSvgPath) if fileVariants["dark"] else "",
                    "gray":     SVG.imageToStringSvg(path.join(self.tempFolder, fileVariants["gray"]),   outputSvgPath) if fileVariants["gray"] else "",
                }

                resourceSlug = self.generateSlug(fileNameWithoutExt)

                generatedClassCode = f"""
    class {resourceSlug}:
        data = {{}}

        # SVG contents
        originalSvgContent = '''{svgContentData["original"]}'''
        selectSvgContent   = '''{svgContentData["select"]}'''
        lightSvgContent    = '''{svgContentData["light"]}'''
        darkSvgContent     = '''{svgContentData["dark"]}'''
        graySvgContent     = '''{svgContentData["gray"]}'''

        @classmethod
        def original(cls) -> Icon:
            return cls._get(cls.originalSvgContent, 'original')

        @classmethod
        def theme(cls, reverse=False) -> Icon:
            if reverse:
                return cls.dark() if Global.theme == "dark" else cls.light()
            else:
                return cls.light() if Global.theme == "dark" else cls.dark()

        @classmethod
        def select(cls) -> Icon:
            return cls._get(cls.selectSvgContent, 'select')

        @classmethod
        def light(cls) -> Icon:
            return cls._get(cls.lightSvgContent, 'light')

        @classmethod
        def dark(cls) -> Icon:
            return cls._get(cls.darkSvgContent, 'dark')

        @classmethod
        def gray(cls) -> Icon:
            return cls._get(cls.graySvgContent, 'gray')

        @classmethod
        def _get(cls, svgContent: str, key: str, width={imageWidth}, height={imageHeight}) -> Icon:
            icon = cls.data.get(key)
            if not icon:
                icon = SVG.stringToIcon(svgContent, QSize(width, height))
                cls.data[key] = icon
            return icon
                """

                generatedFileContent += "\n" + generatedClassCode

            with open(path.join(outputFolder, "resources.py"), 'w', encoding='utf-8') as outputFile:
                outputFile.write(generatedFileContent)
                
def runCmd(*commands: str, env: dict[str, str] | None = None) -> None:
    """
    Launch commands windowless and wait until finished.
    
    Args:
        *commands: Variable number of command strings to execute.
        env: Optional environment variables dictionary. Defaults to None.
    """
    tempFolderPath = tempFolder()
    commandFilePath = os.path.join(tempFolderPath, 'commands.cmd')
    if os.path.isfile(commandFilePath):
        os.remove(commandFilePath)

    commandFile = open(commandFilePath, "w")
    for commandIndex, command in enumerate(commands):
        if commandIndex == len(commands) - 1:
            commandFile.write(command)
        else:
            commandFile.write(f'{command} &&')
    commandFile.close()

    startupInfo = subprocess.STARTUPINFO()
    startupInfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    if env:
            process = subprocess.Popen([commandFilePath, "-d", "myfile.gz"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, startupinfo=startupInfo, env=env)
    else:
            process = subprocess.Popen([commandFilePath, "-d", "myfile.gz"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, startupinfo=startupInfo)

    process.wait() 
 
    if os.path.isfile(commandFilePath):
        os.remove(commandFilePath)

def resourcesUpdate(resourcesFolder: str, outputFolder: str | None = None, *, isQt: bool = False, select: tuple[int, int, int] = (73, 145, 246), dark: tuple[int, int, int] = (55, 55, 55), light: tuple[int, int, int] = (200, 200, 200), gray: tuple[int, int, int] = (130, 130, 130)) -> None:
    """
    resources Update in a folder.
    
    Args:
        resourcesFolder: Path to the resources folder.
        outputFolder: Path to the output folder. If None, uses resourcesFolder. Defaults to None.
        isQt: Whether to generate Qt resource files. Defaults to False.
        select: RGB color for select variant. Defaults to (73, 145, 246).
        dark: RGB color for dark variant. Defaults to (55, 55, 55).
        light: RGB color for light variant. Defaults to (200, 200, 200).
        gray: RGB color for gray variant. Defaults to (130, 130, 130).
    """
    resources = ResourcesUpdate()
    resources.update(resourcesFolder, outputFolder if outputFolder else resourcesFolder, select, dark, light, gray, isQt)