from .utils import TypeTheme, Global
from .theme_data import registry
from PySide6.QtGui import QColor

class RGBAColor:
    """
    RGBA color representation.
    """
    def __init__(self, rgba: str) -> None:
        """
        Initialize RGBAColor.
        
        Args:
            rgba: RGBA color string.
        """
        self._rgba = rgba

    @property
    def rgba(self) -> str:
        """
        Get the RGBA color string.
        
        Returns:
            The RGBA color string.
        """
        return self._rgba

    def __str__(self) -> str:
        """
        Get string representation.
        
        Returns:
            The RGBA color string.
        """
        return self.rgba

class RGBColor:
    """
    RGB color representation with alpha support.
    """
    def __init__(self, rgb: str, alpha: int = 255) -> None:
        """
        Initialize RGBColor.
        
        Args:
            rgb: RGB or RGBA color string.
            alpha: Alpha channel value. Defaults to 255.
        """
        if 'a' in rgb:
            rgbValueList = rgb.replace("rgba(", "").replace(")", "").split(",")[:-1]
            self._rgb = "rgb(" + ",".join(rgbValueList) + ")"
            self._rgba = RGBAColor(rgb)
        else:
            self._rgb = rgb
            self._rgba = self.fromRgba(alpha)

    @property
    def rgb(self) -> str:
        """
        Get the RGB color string.
        
        Returns:
            The RGB color string.
        """
        return self._rgb

    @property
    def rgba(self) -> RGBAColor:
        """
        Get the RGBA color object.
        
        Returns:
            The RGBA color object.
        """
        return self._rgba

    def fromRgba(self, alpha: int) -> RGBAColor:
        """
        Create an RGBA color from this RGB color with specified alpha.
        
        Args:
            alpha: Alpha channel value.
        
        Returns:
            RGBAColor object with the specified alpha.
        """
        rgbString = self.rgb
        if 'a' not in self.rgb:
            rgbString = self.rgb.replace("rgb", "rgba")
        return RGBAColor(rgbString.replace(")", f",{alpha})"))

    def __str__(self) -> str:
        """
        Get string representation.
        
        Returns:
            The RGB color string.
        """
        return self.rgb

class AlphaColorTheme:
    """
    Color theme with alpha channel support.
    """
    def __init__(self, styles: dict[str, RGBColor]) -> None:
        """
        Initialize AlphaColorTheme.
        
        Args:
            styles: Dictionary mapping theme names to RGBColor objects.
        """
        self._styles = styles

    @property
    def styles(self) -> dict[str, RGBColor]:
        """
        Get the styles dictionary.
        
        Returns:
            Dictionary mapping theme names to RGBColor objects.
        """
        return self._styles

    def __str__(self) -> str:
        """
        Get string representation for current theme.
        
        Returns:
            RGBA color string for current theme.
        """
        return str(self._styles[Global.theme].rgba)


class FromAlphaColorTheme:
    """
    Color theme with custom alpha channel.
    """
    def __init__(self, styles: dict[str, RGBColor], alpha: int) -> None:
        """
        Initialize FromAlphaColorTheme.
        
        Args:
            styles: Dictionary mapping theme names to RGBColor objects.
            alpha: Alpha channel value.
        """
        self._styles = styles
        self._alpha = alpha

    @property
    def alpha(self) -> int:
        """
        Get the alpha channel value.
        
        Returns:
            The alpha channel value.
        """
        return self._alpha

    @property
    def styles(self) -> dict[str, RGBColor]:
        """
        Get the styles dictionary.
        
        Returns:
            Dictionary mapping theme names to RGBColor objects.
        """
        return self._styles

    def __str__(self) -> str:
        """
        Get string representation for current theme with custom alpha.
        
        Returns:
            RGBA color string for current theme with custom alpha.
        """
        return str(self._styles[Global.theme].fromRgba(self._alpha))


class ColorTheme:
    """
    Color theme that adapts to current theme (dark/light).
    """
    def __init__(self, *styleProperties: str) -> None:
        """
        Initialize ColorTheme.
        
        Args:
            *styleProperties: Variable number of style property path strings.
        """
        self._styles: dict[str, RGBColor] = {}
        for themeName in TypeTheme.list():
            rgbValue = registry.getValue(themeName, *styleProperties)
            self._styles[themeName] = RGBColor(rgbValue)

        self._rgba = AlphaColorTheme(self.styles)

    @property
    def styles(self) -> dict[str, RGBColor]:
        """
        Get the styles dictionary.
        
        Returns:
            Dictionary mapping theme names to RGBColor objects.
        """
        return self._styles

    @property
    def rgb(self) -> str:
        """
        Get RGB color string for current theme.
        
        Returns:
            RGB color string.
        """
        return self._styles[Global.theme].rgb

    @property
    def rgba(self) -> AlphaColorTheme:
        """
        Get RGBA color theme object.
        
        Returns:
            AlphaColorTheme object.
        """
        return self._rgba

    def fromRgba(self, alpha: int) -> FromAlphaColorTheme:
        """
        Create a color theme with custom alpha.
        
        Args:
            alpha: Alpha channel value.
        
        Returns:
            FromAlphaColorTheme object.
        """
        return FromAlphaColorTheme(self._styles, alpha)

    def verticalGradient(self, stops: list[float] = [0, 0.407273, 0.6825, 1]) -> str:
        """
        Generate a vertical gradient string.
        
        Args:
            stops: List of gradient stop positions. Defaults to [0, 0.407273, 0.6825, 1].
        
        Returns:
            QLinearGradient CSS string for vertical gradient.
        """
        return f'''qlineargradient(spread: pad, x1: 0, y1: 1, x2: 0, y2: 0,
                    stop: {stops[0]} rgba(255, 255, 255, 0),
                    stop: {stops[1]} {self.__str__()},
                    stop: {stops[2]} {self.fromRgba(230)},
                    stop: {stops[3]} rgba(255, 255, 255, 0)
                ); '''

    def horizontalGradient(self, stops: list[float] = [0, 0.407273, 0.6825, 1]) -> str:
        """
        Generate a horizontal gradient string.
        
        Args:
            stops: List of gradient stop positions. Defaults to [0, 0.407273, 0.6825, 1].
        
        Returns:
            QLinearGradient CSS string for horizontal gradient.
        """
        return f'''qlineargradient(spread: pad, x1: 1, y1: 0, x2: 0, y2: 0,
                    stop: {stops[0]} rgba(255, 255, 255, 0),
                    stop: {stops[1]} {self.__str__()},
                    stop: {stops[2]} {self.fromRgba(230)},
                    stop: {stops[3]} rgba(255, 255, 255, 0)
                ); '''

    @property
    def QColor(self) -> QColor:
        """
        Get QColor object for current theme.
        
        Returns:
            QColor object.
        """
        red, green, blue = self.rgb.replace('rgb(', '').replace(")", "").split(",")
        return QColor(int(red), int(green), int(blue))

    def fromQColor(self, alpha: int = 255) -> QColor:
        """
        Get QColor object with custom alpha.
        
        Args:
            alpha: Alpha channel value. Defaults to 255.
        
        Returns:
            QColor object with alpha.
        """
        rgbaString = self.fromRgba(alpha).__str__().replace('rgba(', '').replace(")", "").split(",")
        red, green, blue, alphaValue = rgbaString
        return QColor(int(red), int(green), int(blue), int(alphaValue))

    def __str__(self) -> str:
        """
        Get string representation.
        
        Returns:
            RGB color string for current theme.
        """
        return self._styles[Global.theme].rgb


class IntTheme:
    """
    Integer theme that adapts to current theme (dark/light).
    """
    def __init__(self, *styleProperties: str) -> None:
        """
        Initialize IntTheme.
        
        Args:
            *styleProperties: Variable number of style property path strings.
        """
        self._styles: dict[str, int] = {}
        for themeName in TypeTheme.list():
            intValue = registry.getValue(themeName, *styleProperties)
            self._styles[themeName] = intValue

    @property
    def styles(self) -> dict[str, int]:
        """
        Get the styles dictionary.
        
        Returns:
            Dictionary mapping theme names to integer values.
        """
        return self._styles

    def __repr__(self) -> str:
        """
        Get string representation.
        
        Returns:
            String representation of integer value for current theme.
        """
        return repr(self._styles[Global.theme])

class BaseColor(object):
    """
    Base color definitions for the application theme.
    """
    division = ColorTheme('division')
    footer = ColorTheme('footer')
    primary = ColorTheme('primary')
    secondary = ColorTheme('secondary')
    tertiary = ColorTheme('tertiary')
    placeholder = ColorTheme('placeholder')
    table = ColorTheme('table')
    tableAlternate = ColorTheme('tableAlternate')
    tableSelectionBackground = ColorTheme('tableSelectionBackground')
    shadow = ColorTheme('shadow')
    darkGreen = ColorTheme('qcolor', 'darkGreen')
    lightGreen = ColorTheme('qcolor', 'lightGreen')
    yellow = ColorTheme('qcolor','yellow')
    blue = ColorTheme('qcolor', 'blue')
    lilac = ColorTheme('qcolor', 'lilac')
    maron = ColorTheme('qcolor','maron')
    
    class Widget(object):
         background = ColorTheme('widget', 'background')
         hoverBorder = ColorTheme('widget', 'hoverBorder')
         focusBorder = ColorTheme('widget', 'focusBorder')
         hoverBackground = ColorTheme('widget', 'hoverBackground')
         selectedBackground = ColorTheme('widget', "selectedBackground")

    class Button(object):
         background = ColorTheme('button', 'background')
         hoverBackground = ColorTheme('button', 'hover', 'background')
         hoverBorder = ColorTheme('button', 'hover', 'border')
         pressedBackground = ColorTheme('button','pressed', 'background')
         pressedBorder = ColorTheme('button', 'pressed', 'border')

    class Menu(object):
        background = ColorTheme('menu', 'background')
        class Button(object):
            background = ColorTheme('menu', 'button', 'background')
            hoverBackground = ColorTheme('menu','button', 'hover', 'background')
            hoverBorder = ColorTheme('menu','button', 'hover', 'border')
            pressedBackground = ColorTheme('menu','button','pressed', 'background')
            pressedBorder = ColorTheme('menu','button', 'pressed', 'border')

    class ProgressBar:
         background = ColorTheme('progressBar', 'background')
         chunkBackground = ColorTheme('progressBar', 'chunkBackground')

    class Reverse(object):
         primary = ColorTheme('reverse', 'primary')
         secondary = ColorTheme('reverse', 'secondary')
         selected = ColorTheme('reverse', 'selected')

def setBaseStyle(theme: TypeTheme, baseColor: BaseColor) -> None:
    """
    Apply color overrides to the theme from baseColor string attributes.
    
    Args:
        theme: The theme type to apply overrides to.
        baseColor: BaseColor object with color attributes.
    """
    baseColorAttributes = vars(baseColor)
    colorVariables = {
        attributeName: attributeValue
        for attributeName, attributeValue in baseColorAttributes.items()
        if isinstance(attributeValue, str) and not attributeName.startswith("_")
    }
    for variableName in colorVariables:
        if variableName != "__module__":
            registry.setOverride(theme, variableName, colorVariables[variableName])




