# -*- coding: latin -*-

class TypeTheme:
    """
    Theme type constants.
    """
    light = 'light'
    dark = 'dark'

    @classmethod
    def list(cls):
        """
        Get list of available theme types.
        
        Returns:
            List of theme type strings.
        """
        return [cls.light, cls.dark]

class Global:
    """
    Global application state.
    """
    theme : TypeTheme = TypeTheme.light
    appColor = '#4c94f4'






