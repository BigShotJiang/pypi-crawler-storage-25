# coding: utf-8
from functools import partial
from typing import Callable

from PySide6.QtCore import QCoreApplication, Qt, QTimer
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QMainWindow,
    QPushButton,
    QRadioButton,
    QScrollBar,
)

from .style import Styles


class GUIUtils:
    """Utilities for common PySide operations."""

    @staticmethod
    def updateApp() -> None:
        """
        Process pending application events.

        This method processes all pending events in the application's event queue,
        allowing the UI to update and respond to user interactions.
        """
        QCoreApplication.processEvents()

    @staticmethod
    def clearFocus() -> None:
        """
        Remove focus from the currently focused widget.

        If there is a widget currently focused, this method will clear its focus,
        effectively removing the focus indicator from the UI.
        """
        focused_widget = QApplication.focusWidget()
        if focused_widget:
            focused_widget.clearFocus()

    @staticmethod
    def copy(text: str, btn: QPushButton | None = None, icon_check=Styles.Resources.check) -> None:
        """
        Copy text to clipboard and update button icon.

        Args:
            text: The text string to be copied to the clipboard.
            btn: Optional button widget to update with a check icon temporarily.
                 If provided, the button icon will change to a check icon for 1 second,
                 then revert back to the copy icon.
            icon_check: The icon resource to use for the check indicator.
                       Defaults to Styles.Resources.check.
        """
        clipboard = QApplication.clipboard()
        clipboard.setText(text)
        if btn:
            Styles.setIcon(btn, icon_check.select, icon_check.select)
            QTimer.singleShot(
                1000,
                partial(Styles.setIcon, btn, Styles.Resources.copy.gray, Styles.Resources.copy.select),
            )

    @staticmethod
    def activeWindow() -> QMainWindow | None:
        """
        Get the currently active window of the application.

        Returns:
            The active QMainWindow instance, or None if no window is active.
        """
        return QCoreApplication.instance().activeWindow()

    @staticmethod
    def mainWindow() -> QMainWindow | None:
        """
        Get the main window of the application.

        This method searches for the main window by checking if the application
        instance itself is a QMainWindow, or by iterating through all top-level
        widgets to find a QMainWindow instance.

        Returns:
            The main QMainWindow instance, or None if no main window is found.
        """
        app = QApplication.instance()

        if not app:
            return None

        if isinstance(app, QMainWindow):
            return app

        for widget in app.topLevelWidgets():
            if isinstance(widget, QMainWindow):
                return widget

        return None

    @staticmethod
    def setupExclusiveSelection(*widgets: QCheckBox | QRadioButton) -> None:
        """
        Set up exclusive selection between widgets (CheckBox or RadioButton).

        This method configures a group of widgets so that only one can be
        selected at a time. When one widget is clicked, all others are
        automatically unchecked. It also ensures that at least one widget
        remains checked at all times.

        Args:
            *widgets: Variable number of QCheckBox or QRadioButton widgets
                     to configure for exclusive selection.
        """

        def onWidgetClicked(selectedWidget: QCheckBox | QRadioButton) -> None:
            for widget in widgets:
                if widget is not selectedWidget:
                    widget.blockSignals(True)
                    widget.setChecked(False)
                    widget.blockSignals(False)

            if not selectedWidget.isChecked():
                selectedWidget.blockSignals(True)
                selectedWidget.setChecked(True)
                selectedWidget.blockSignals(False)

        for widget in widgets:
            widget.toggled.connect(lambda _, b=widget: onWidgetClicked(b))

    @staticmethod
    def windowControl(window: QMainWindow) -> None:
        """
        Control the display and state of a window.

        This method ensures the window is visible, not minimized, and activated.
        If the window is hidden, it will be shown. The window state is set to
        active and non-minimized, and the window is brought to the front.

        Args:
            window: The QMainWindow instance to control.
        """
        if window.isHidden():
            window.show()
            window.setWindowState(
                (window.windowState() & ~Qt.WindowState.WindowMinimized) | Qt.WindowState.WindowActive
            )
            window.activateWindow()
        else:
            window.setWindowState(
                (window.windowState() & ~Qt.WindowState.WindowMinimized) | Qt.WindowState.WindowActive
            )
            window.activateWindow()

    @staticmethod
    def scrollToBottom(scroll: QScrollBar) -> None:
        """
        Scroll the scrollbar to the bottom.

        This method processes pending events first, then schedules a timer
        to set the scrollbar value to its maximum after a short delay.

        Args:
            scroll: The QScrollBar instance to scroll to the bottom.
        """
        GUIUtils.updateApp()
        QTimer.singleShot(50, lambda: scroll.setValue(scroll.maximum()))


__all__ = ['GUIUtils']
