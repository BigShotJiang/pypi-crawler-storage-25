
from enum import Enum
from PySide6.QtCore import  Qt
from PySide6.QtWidgets import QWidget, QSplitter, QVBoxLayout, QHBoxLayout
from typing import Type, TypeVar
from .memoryManager import MemoryManager

T = TypeVar('T')

class Layout(object):
    """
    Layout utilities for managing widget layouts and splitters.
    """
        
    MemoryManager = MemoryManager()

    class Size(Enum):
        """
        Size proportions for splitter widgets.
        """
        ONE_HALF = 1/2
        ONE_THIRD = 1/3
        TWO_THIRDS = 2/3
        ONE_QUARTERS = 1/4
        TWO_QUARTERS = 2/4
        THREE_QUARTERS = 3/4

    @classmethod
    def customSize(cls, frame: QWidget, sizes: list[int | Size]) -> list[int]:
        """
        Calculate custom sizes based on frame height and size proportions.
        
        Args:
            frame: Widget frame to calculate sizes for.
            sizes: List of sizes (int or Size enum).
        
        Returns:
            List of calculated integer sizes.
        """
        frameHeight = frame.height()
        calculatedSizes = []
        for sizeValue in sizes:
            if isinstance(sizeValue, cls.Size):
                calculatedSizes.append(int(frameHeight * sizeValue.value))
            else:
                calculatedSizes.append(sizeValue)
        return calculatedSizes
    
    @staticmethod
    def synchronizeSplitters(splitters: list[QSplitter]) -> None:
        """
        Synchronize multiple splitters so they move together.
        
        Args:
            splitters: List of QSplitter widgets to synchronize.
        """
        syncFlag = {'active': False} 

        def createHandler(sourceSplitter: QSplitter):
            def splitterHandler(position: int, index: int) -> None:
                if syncFlag['active']:
                    return
                syncFlag['active'] = True
                sourceSizes = sourceSplitter.sizes()
                for targetSplitter in splitters:
                    if targetSplitter is not sourceSplitter:
                        targetSplitter.setSizes(sourceSizes)
                syncFlag['active'] = False
            return splitterHandler

        for splitter in splitters:
            splitter.splitterMoved.connect(createHandler(splitter))

    @classmethod
    def splitterVertical(cls, frame: QWidget, widgets: list[QWidget], sizes: list[int | Size] | None = None) -> QSplitter:
        """
        Create a vertical splitter with widgets.
        
        Args:
            frame: Parent frame widget.
            widgets: List of widgets to add to splitter.
            sizes: Optional list of sizes. Defaults to None.
        
        Returns:
            Created QSplitter widget.
        """
        verticalSplitter = QSplitter(Qt.Orientation.Vertical)
        for widget in widgets:
            widget.setParent(verticalSplitter)
        if sizes:
            calculatedSizes = cls.customSize(frame, sizes)
            verticalSplitter.setSizes(calculatedSizes)

        frame.layout().addWidget(verticalSplitter)
        return verticalSplitter


    @classmethod
    def splitterHorizontal(cls, frame: QWidget, widgets: list[QWidget], sizes: list[int | Size] | None = None) -> QSplitter:
        """
        Create a horizontal splitter with widgets.
        
        Args:
            frame: Parent frame widget.
            widgets: List of widgets to add to splitter.
            sizes: Optional list of sizes. Defaults to None.
        
        Returns:
            Created QSplitter widget.
        """
        horizontalSplitter = QSplitter(Qt.Orientation.Horizontal)
        for widget in widgets:
            widget.setParent(horizontalSplitter)
        if sizes:
            calculatedSizes = cls.customSize(frame, sizes)
            horizontalSplitter.setSizes(calculatedSizes)

        frame.layout().addWidget(horizontalSplitter)
        return horizontalSplitter

    @classmethod
    def clear(cls, layout: QVBoxLayout | QHBoxLayout, removeItems: bool = False) -> None:
        """
        Clear all widgets from a layout.
        
        Args:
            layout: Layout to clear.
            removeItems: Whether to remove items. Defaults to False.
        """
        cls.MemoryManager.clearLayout(layout, removeItems)

    @classmethod
    def getWidgets(cls, layout: QVBoxLayout | QHBoxLayout, type: Type[T] = QWidget) -> list[T]:
        """
        Get all widgets from a layout.
        
        Args:
            layout: Layout to get widgets from.
            type: Widget type filter. Defaults to QWidget.
        
        Returns:
            List of widgets in the layout.
        """
        layoutWidgets = []
        if layout:
            for itemIndex in range(layout.count()):
                layoutItem = layout.itemAt(itemIndex)
                layoutWidget = layoutItem.widget()
                if layoutWidget:
                    layoutWidgets.append(layoutWidget)
        return layoutWidgets

    @classmethod
    def findParentByName(cls, widget: QWidget, targetName: str) -> QWidget | None:
        """
        Finds the parent widget by its object name.

        Args:
            widget (QWidget): The starting widget to begin the search from.
            targetName (str): The name of the target widget to find.

        Returns:
            QWidget | None: The found widget with the matching name, or None if not found.
        """
        # Start with the current widget's parent
        parent = widget.parentWidget()
        
        # Traverse up the widget hierarchy
        while parent is not None:
            # Check if the current parent has the target object name
            if parent.objectName() == targetName:
                return parent
            # Move up to the next parent
            parent = parent.parentWidget()
        return None

    @classmethod
    def findAllChildrenInParent(cls, widget: QWidget, targetName: str) -> list[QWidget]:
        """
        Finds the parent widget by its object name and returns all its child widgets recursively.

        Args:
            widget (QWidget): The starting widget to begin the search from.
            targetName (str): The name of the target widget to find.

        Returns:
            List[QWidget]: A list of all widgets inside the found parent, or empty list if the parent is not found.
        """
        # Start with the current widget's parent
        parent = widget.parentWidget()
        
        # Traverse up the widget hierarchy to find the parent with the matching name
        while parent is not None:
            if parent.objectName() == targetName:
                # If the parent is found, recursively find all children
                return cls.getAllChildren(parent)
            # Move up to the next parent
            parent = parent.parentWidget()
        
        return []

    @classmethod
    def getAllChildren(cls, parent: QWidget) -> list[QWidget]:
        """
        Recursively retrieves all children of a given parent widget.

        Args:
            parent (QWidget): The parent widget to search within.

        Returns:
            List[QWidget]: A list of all child widgets.
        """
        allChildren = []
        # Use findChildren to get all direct and nested children
        children = parent.findChildren(QWidget)
        
        for child in children:
            allChildren.append(child)
            # Recursively add children's children
            allChildren.extend(cls.getAllChildren(child))
        
        return allChildren



