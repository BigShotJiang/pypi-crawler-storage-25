from PySide6.QtWidgets import QWidget
from PySide6.QtCore import QPropertyAnimation, QEasingCurve, QCoreApplication


class Animation(object):
    """
    Animation utilities for widget properties.
    """
    
    @classmethod
    def minimumWidth(cls, widget: QWidget, startValue: int, endValue: int, duration: int = 500, easingCurveType: QEasingCurve.Type = QEasingCurve.Type.InOutQuart) -> None:
        """
        Animate the minimum width of a widget.
        
        Args:
            widget: The widget to animate.
            startValue: Starting width value.
            endValue: Ending width value.
            duration: Animation duration in milliseconds. Defaults to 500.
            easingCurveType: Easing curve type. Defaults to InOutQuart.
        """
        activeWindow = QCoreApplication.instance().activeWindow()
        if activeWindow:
            activeWindow.animation = QPropertyAnimation(widget, b"minimumWidth")
            activeWindow.animation.setDuration(duration)
            activeWindow.animation.setStartValue(startValue)
            activeWindow.animation.setEndValue(endValue)
            activeWindow.animation.setEasingCurve(easingCurveType)
            activeWindow.animation.start()
        else:
            print('Animation: Active window not found')



