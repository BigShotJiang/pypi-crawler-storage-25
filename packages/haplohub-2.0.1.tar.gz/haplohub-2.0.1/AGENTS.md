# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

HaploHub Python SDK - an auto-generated Python client for the HaploHub API (biomarkers, genetics, and 'omics data platform). The SDK is generated from an OpenAPI specification using `openapi-generator` with custom Mustache templates.

## Common Commands

```bash
# Install dependencies
uv sync --dev

# Run all tests
uv run pytest -v

# Run a single test file
uv run pytest test/test_cohort_api.py -v

# Run a specific test
uv run pytest test/test_cohort_api.py::TestCohortApi::test_list_cohort -v

# Format code
ruff format .

# Check formatting (CI uses this)
ruff format --check .

# Lint code
ruff check .

# Lint and auto-fix
ruff check . --fix

# Regenerate SDK from OpenAPI spec
./bin/generate.sh
```

## Architecture

This is an **auto-generated** SDK. The code in `haplohub/api/` and `haplohub/models/` is generated from `openapi.json` using OpenAPI Generator with custom templates in `template/`.

### Key Components

- **`haplohub/api_client.py`** - Core REST client handling HTTP communication, auth, and serialization
- **`haplohub/configuration.py`** - Bearer token auth configuration (Auth0JWTBearer)
- **`haplohub/api/`** - 26 API endpoint classes (one per resource type)
- **`haplohub/models/`** - 108 Pydantic v1 data models for request/response schemas
- **`haplohub/rest.py`** - Low-level REST client and `ApiException`

### Code Generation

```bash
# Regenerate from OpenAPI spec (uses Docker, defaults to prod)
./bin/generate.sh

# Regenerate from a specific URL
./bin/generate.sh https://api.stage.haplohub.com/api/v1/openapi.json

# Extract templates for customization
./bin/extract.sh
```

The OpenAPI spec is fetched from the configured URL (default: `https://api.haplohub.com/api/v1/openapi.json`). Custom Mustache templates in `template/` control the generated code format.

**Local Development Setup:**
```bash
cp .env.sample .env
# Edit .env: HAPLOHUB_API_URL=https://api.dev.haplohub.com/api/v1/openapi.json
./bin/generate.sh  # Uses URL from .env
```

**Priority order:** CLI argument > `HAPLOHUB_API_URL` env var > default (prod)

## Testing

Tests in `test/` mirror the `haplohub/` structure. Each API and model has a corresponding test file generated from templates. Tests use `pyfakefs` for filesystem mocking.

## Code Style

- Line length: 127 characters
- Double quotes for strings
- LF line endings
- Import sorting enabled (`ruff` with `extend-select = ["I"]`)
- Ignored rules: `F841` (unused variables), `E721` (type comparison)

## Pre-commit Hooks

Pre-commit runs automatically:
- `ruff format --check` on commit
- `ruff check --fix` on commit
- `pytest` on push

## CI/CD

- **On PR/push**: Lint + test across Python 3.8-3.12
- **On main push**: Build and publish to Test PyPI
- **On version tag** (`v*.*.*`): Publish to PyPI + create GitHub Release with Sigstore signatures
- **On API update** (`repository_dispatch: api-updated`): Auto-regenerate SDK and create PR

### Auto-Regenerate SDK

The SDK can be automatically regenerated when the API changes:

1. **Manual trigger**: Actions > Regenerate SDK > Run workflow (with URL input)
2. **From API repo**: Triggered via `repository_dispatch` event with `api-updated` type

**To trigger from main API repository:**
```yaml
# In API repo deployment workflow
- name: Trigger SDK Regeneration
  uses: peter-evans/repository-dispatch@v3
  with:
    token: ${{ secrets.SDK_REPO_PAT }}  # PAT with repo scope
    repository: haplotypelabs/haplohub-python
    event-type: api-updated
    client-payload: '{"api_url": "https://api.haplohub.com/api/v1/openapi.json"}'
```
