# haplohub.UploadRequestApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**cancel_upload_request**](UploadRequestApi.md#cancel_upload_request) | **POST** /api/v1/cohort/{cohort_id}/upload-request/{upload_request_id}/cancel/ | Cancel upload request
[**create_upload_request**](UploadRequestApi.md#create_upload_request) | **POST** /api/v1/cohort/{cohort_id}/upload-request/ | Create upload request
[**get_upload_request**](UploadRequestApi.md#get_upload_request) | **GET** /api/v1/cohort/{cohort_id}/upload-request/{upload_request_id}/ | Get upload request
[**list_upload_requests**](UploadRequestApi.md#list_upload_requests) | **GET** /api/v1/cohort/{cohort_id}/upload-request/ | List upload requests


# **cancel_upload_request**
> ResultResponseUploadRequestSchema cancel_upload_request(cohort_id, upload_request_id)

Cancel upload request

Cancel an active upload request. Only `new` and `pending` requests can be cancelled.

### Example

* Api Key Authentication (ApiKeyAuth):
* Bearer Authentication (JWTBearer):

```python
import haplohub
from haplohub.models.result_response_upload_request_schema import ResultResponseUploadRequestSchema
from haplohub.rest import ApiException
from pprint import pprint

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization: 
configuration = haplohub.Configuration(
    access_token=os.environ["API_KEY"]
)
# Enter a context with an instance of the API client
with haplohub.ApiClient(configuration) as api_client:
    cohort_id = 'cohort_id_example' # str | 
    upload_request_id = 'upload_request_id_example' # str | 

    try:
        # Cancel upload request
        api_response = api_client.upload_request_api.cancel_upload_request(cohort_id, upload_request_id)
        print("The response of UploadRequestApi->cancel_upload_request:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling UploadRequestApi->cancel_upload_request: %s\n" % e)
```


### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cohort_id** | **str**|  | 
 **upload_request_id** | **str**|  | 

### Return type

[**ResultResponseUploadRequestSchema**](ResultResponseUploadRequestSchema.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth), [JWTBearer](../README.md#JWTBearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**409** | Conflict |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_upload_request**
> ResultResponseCreateUploadRequestResult create_upload_request(cohort_id, create_upload_request_request)

Create upload request

Create a new upload request for a cohort and obtain signed upload links.

### Example

* Api Key Authentication (ApiKeyAuth):
* Bearer Authentication (JWTBearer):

```python
import haplohub
from haplohub.models.create_upload_request_request import CreateUploadRequestRequest
from haplohub.models.result_response_create_upload_request_result import ResultResponseCreateUploadRequestResult
from haplohub.rest import ApiException
from pprint import pprint

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization: 
configuration = haplohub.Configuration(
    access_token=os.environ["API_KEY"]
)
# Enter a context with an instance of the API client
with haplohub.ApiClient(configuration) as api_client:
    cohort_id = 'cohort_id_example' # str | 
    create_upload_request_request = haplohub.CreateUploadRequestRequest() # CreateUploadRequestRequest | 

    try:
        # Create upload request
        api_response = api_client.upload_request_api.create_upload_request(cohort_id, create_upload_request_request)
        print("The response of UploadRequestApi->create_upload_request:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling UploadRequestApi->create_upload_request: %s\n" % e)
```


### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cohort_id** | **str**|  | 
 **create_upload_request_request** | [**CreateUploadRequestRequest**](CreateUploadRequestRequest.md)|  | 

### Return type

[**ResultResponseCreateUploadRequestResult**](ResultResponseCreateUploadRequestResult.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth), [JWTBearer](../README.md#JWTBearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**403** | Forbidden |  -  |
**409** | Conflict |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_upload_request**
> ResultResponseUploadRequestSchema get_upload_request(cohort_id, upload_request_id)

Get upload request

Get an upload request by its ID.

### Example

* Api Key Authentication (ApiKeyAuth):
* Bearer Authentication (JWTBearer):

```python
import haplohub
from haplohub.models.result_response_upload_request_schema import ResultResponseUploadRequestSchema
from haplohub.rest import ApiException
from pprint import pprint

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization: 
configuration = haplohub.Configuration(
    access_token=os.environ["API_KEY"]
)
# Enter a context with an instance of the API client
with haplohub.ApiClient(configuration) as api_client:
    cohort_id = 'cohort_id_example' # str | 
    upload_request_id = 'upload_request_id_example' # str | 

    try:
        # Get upload request
        api_response = api_client.upload_request_api.get_upload_request(cohort_id, upload_request_id)
        print("The response of UploadRequestApi->get_upload_request:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling UploadRequestApi->get_upload_request: %s\n" % e)
```


### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cohort_id** | **str**|  | 
 **upload_request_id** | **str**|  | 

### Return type

[**ResultResponseUploadRequestSchema**](ResultResponseUploadRequestSchema.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth), [JWTBearer](../README.md#JWTBearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_upload_requests**
> PaginatedResponseUploadRequestSchema list_upload_requests(cohort_id, statuses=statuses, sample_ids=sample_ids)

List upload requests

List upload requests for a cohort.

### Example

* Api Key Authentication (ApiKeyAuth):
* Bearer Authentication (JWTBearer):

```python
import haplohub
from haplohub.models.paginated_response_upload_request_schema import PaginatedResponseUploadRequestSchema
from haplohub.models.upload_request_status import UploadRequestStatus
from haplohub.rest import ApiException
from pprint import pprint

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization: 
configuration = haplohub.Configuration(
    access_token=os.environ["API_KEY"]
)
# Enter a context with an instance of the API client
with haplohub.ApiClient(configuration) as api_client:
    cohort_id = 'cohort_id_example' # str | 
    statuses = [haplohub.UploadRequestStatus()] # List[UploadRequestStatus] |  (optional)
    sample_ids = ['sample_ids_example'] # List[str] |  (optional)

    try:
        # List upload requests
        api_response = api_client.upload_request_api.list_upload_requests(cohort_id, statuses=statuses, sample_ids=sample_ids)
        print("The response of UploadRequestApi->list_upload_requests:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling UploadRequestApi->list_upload_requests: %s\n" % e)
```


### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cohort_id** | **str**|  | 
 **statuses** | [**List[UploadRequestStatus]**](UploadRequestStatus.md)|  | [optional] 
 **sample_ids** | [**List[str]**](str.md)|  | [optional] 

### Return type

[**PaginatedResponseUploadRequestSchema**](PaginatedResponseUploadRequestSchema.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth), [JWTBearer](../README.md#JWTBearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

