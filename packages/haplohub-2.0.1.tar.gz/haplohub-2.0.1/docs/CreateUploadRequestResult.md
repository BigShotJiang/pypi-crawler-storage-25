# CreateUploadRequestResult


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**upload_request** | [**UploadRequestSchema**](UploadRequestSchema.md) |  | 
**upload_links** | [**List[UploadLink]**](UploadLink.md) |  | 

## Example

```python
from haplohub.models.create_upload_request_result import CreateUploadRequestResult

# TODO update the JSON string below
json = "{}"
# create an instance of CreateUploadRequestResult from a JSON string
create_upload_request_result_instance = CreateUploadRequestResult.from_json(json)
# print the JSON string representation of the object
print(CreateUploadRequestResult.to_json())

# convert the object into a dict
create_upload_request_result_dict = create_upload_request_result_instance.to_dict()
# create an instance of CreateUploadRequestResult from a dict
create_upload_request_result_from_dict = CreateUploadRequestResult.from_dict(create_upload_request_result_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


