# ClinvarTargetSchema


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **str** |  | [optional] [default to 'clinvar']
**gene_symbols** | **List[str]** |  | 
**clinical_significance** | **List[str]** |  | [optional] [default to [Pathogenic, Likely_pathogenic]]

## Example

```python
from haplohub.models.clinvar_target_schema import ClinvarTargetSchema

# TODO update the JSON string below
json = "{}"
# create an instance of ClinvarTargetSchema from a JSON string
clinvar_target_schema_instance = ClinvarTargetSchema.from_json(json)
# print the JSON string representation of the object
print(ClinvarTargetSchema.to_json())

# convert the object into a dict
clinvar_target_schema_dict = clinvar_target_schema_instance.to_dict()
# create an instance of ClinvarTargetSchema from a dict
clinvar_target_schema_from_dict = ClinvarTargetSchema.from_dict(clinvar_target_schema_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


