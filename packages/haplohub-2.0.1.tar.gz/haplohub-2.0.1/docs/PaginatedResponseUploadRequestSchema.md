# PaginatedResponseUploadRequestSchema


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **str** |  | [optional] [default to 'success']
**total_count** | **int** |  | 
**items** | [**List[UploadRequestSchema]**](UploadRequestSchema.md) |  | 

## Example

```python
from haplohub.models.paginated_response_upload_request_schema import PaginatedResponseUploadRequestSchema

# TODO update the JSON string below
json = "{}"
# create an instance of PaginatedResponseUploadRequestSchema from a JSON string
paginated_response_upload_request_schema_instance = PaginatedResponseUploadRequestSchema.from_json(json)
# print the JSON string representation of the object
print(PaginatedResponseUploadRequestSchema.to_json())

# convert the object into a dict
paginated_response_upload_request_schema_dict = paginated_response_upload_request_schema_instance.to_dict()
# create an instance of PaginatedResponseUploadRequestSchema from a dict
paginated_response_upload_request_schema_from_dict = PaginatedResponseUploadRequestSchema.from_dict(paginated_response_upload_request_schema_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


