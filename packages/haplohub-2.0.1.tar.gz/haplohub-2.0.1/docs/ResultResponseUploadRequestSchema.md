# ResultResponseUploadRequestSchema


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **str** |  | [optional] [default to 'success']
**result** | [**UploadRequestSchema**](UploadRequestSchema.md) |  | 

## Example

```python
from haplohub.models.result_response_upload_request_schema import ResultResponseUploadRequestSchema

# TODO update the JSON string below
json = "{}"
# create an instance of ResultResponseUploadRequestSchema from a JSON string
result_response_upload_request_schema_instance = ResultResponseUploadRequestSchema.from_json(json)
# print the JSON string representation of the object
print(ResultResponseUploadRequestSchema.to_json())

# convert the object into a dict
result_response_upload_request_schema_dict = result_response_upload_request_schema_instance.to_dict()
# create an instance of ResultResponseUploadRequestSchema from a dict
result_response_upload_request_schema_from_dict = ResultResponseUploadRequestSchema.from_dict(result_response_upload_request_schema_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


