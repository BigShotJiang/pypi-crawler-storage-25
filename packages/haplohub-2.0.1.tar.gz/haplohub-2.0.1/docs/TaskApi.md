# haplohub.TaskApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_task**](TaskApi.md#get_task) | **GET** /api/v1/cohort/{cohort_id}/task/{task_id}/ | Get task
[**list_tasks**](TaskApi.md#list_tasks) | **GET** /api/v1/cohort/{cohort_id}/task/ | List tasks


# **get_task**
> ResultResponseTaskSchema get_task(cohort_id, task_id)

Get task

Get task by its ID

### Example

* Api Key Authentication (ApiKeyAuth):
* Bearer Authentication (JWTBearer):

```python
import haplohub
from haplohub.models.result_response_task_schema import ResultResponseTaskSchema
from haplohub.rest import ApiException
from pprint import pprint

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization: 
configuration = haplohub.Configuration(
    access_token=os.environ["API_KEY"]
)
# Enter a context with an instance of the API client
with haplohub.ApiClient(configuration) as api_client:
    cohort_id = 'cohort_id_example' # str | 
    task_id = 'task_id_example' # str | 

    try:
        # Get task
        api_response = api_client.task_api.get_task(cohort_id, task_id)
        print("The response of TaskApi->get_task:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling TaskApi->get_task: %s\n" % e)
```


### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cohort_id** | **str**|  | 
 **task_id** | **str**|  | 

### Return type

[**ResultResponseTaskSchema**](ResultResponseTaskSchema.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth), [JWTBearer](../README.md#JWTBearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_tasks**
> PaginatedResponseTaskSchema list_tasks(cohort_id, sample_ids=sample_ids, statuses=statuses, upload_request_id=upload_request_id, sample_external_id=sample_external_id, member_external_id=member_external_id)

List tasks

List tasks for a cohort

### Example

* Api Key Authentication (ApiKeyAuth):
* Bearer Authentication (JWTBearer):

```python
import haplohub
from haplohub.models.paginated_response_task_schema import PaginatedResponseTaskSchema
from haplohub.models.task_status import TaskStatus
from haplohub.rest import ApiException
from pprint import pprint

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization: 
configuration = haplohub.Configuration(
    access_token=os.environ["API_KEY"]
)
# Enter a context with an instance of the API client
with haplohub.ApiClient(configuration) as api_client:
    cohort_id = 'cohort_id_example' # str | 
    sample_ids = ['sample_ids_example'] # List[Optional[str]] |  (optional)
    statuses = [haplohub.TaskStatus()] # List[TaskStatus] |  (optional)
    upload_request_id = 'upload_request_id_example' # str |  (optional)
    sample_external_id = 'sample_external_id_example' # str |  (optional)
    member_external_id = 'member_external_id_example' # str |  (optional)

    try:
        # List tasks
        api_response = api_client.task_api.list_tasks(cohort_id, sample_ids=sample_ids, statuses=statuses, upload_request_id=upload_request_id, sample_external_id=sample_external_id, member_external_id=member_external_id)
        print("The response of TaskApi->list_tasks:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling TaskApi->list_tasks: %s\n" % e)
```


### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cohort_id** | **str**|  | 
 **sample_ids** | [**List[Optional[str]]**](str.md)|  | [optional] 
 **statuses** | [**List[TaskStatus]**](TaskStatus.md)|  | [optional] 
 **upload_request_id** | **str**|  | [optional] 
 **sample_external_id** | **str**|  | [optional] 
 **member_external_id** | **str**|  | [optional] 

### Return type

[**PaginatedResponseTaskSchema**](PaginatedResponseTaskSchema.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth), [JWTBearer](../README.md#JWTBearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

