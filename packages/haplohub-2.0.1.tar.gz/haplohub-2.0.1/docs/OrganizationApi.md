# haplohub.OrganizationApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**haplohub_api_v1_organization_get_organization_settings**](OrganizationApi.md#haplohub_api_v1_organization_get_organization_settings) | **GET** /api/v1/organization/settings/ | Get Organization Settings
[**haplohub_api_v1_organization_sync_cors**](OrganizationApi.md#haplohub_api_v1_organization_sync_cors) | **POST** /api/v1/organization/sync-cors/ | Sync Cors
[**haplohub_api_v1_organization_update_organization_settings**](OrganizationApi.md#haplohub_api_v1_organization_update_organization_settings) | **PATCH** /api/v1/organization/settings/ | Update Organization Settings


# **haplohub_api_v1_organization_get_organization_settings**
> ResultResponseOrganizationSettingsSchema haplohub_api_v1_organization_get_organization_settings()

Get Organization Settings

### Example

* Api Key Authentication (ApiKeyAuth):
* Bearer Authentication (JWTBearer):

```python
import haplohub
from haplohub.models.result_response_organization_settings_schema import ResultResponseOrganizationSettingsSchema
from haplohub.rest import ApiException
from pprint import pprint

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization: 
configuration = haplohub.Configuration(
    access_token=os.environ["API_KEY"]
)
# Enter a context with an instance of the API client
with haplohub.ApiClient(configuration) as api_client:

    try:
        # Get Organization Settings
        api_response = api_client.organization_api.haplohub_api_v1_organization_get_organization_settings()
        print("The response of OrganizationApi->haplohub_api_v1_organization_get_organization_settings:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling OrganizationApi->haplohub_api_v1_organization_get_organization_settings: %s\n" % e)
```


### Parameters

This endpoint does not need any parameter.

### Return type

[**ResultResponseOrganizationSettingsSchema**](ResultResponseOrganizationSettingsSchema.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth), [JWTBearer](../README.md#JWTBearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **haplohub_api_v1_organization_sync_cors**
> Response2 haplohub_api_v1_organization_sync_cors()

Sync Cors

### Example

* Api Key Authentication (ApiKeyAuth):
* Bearer Authentication (JWTBearer):

```python
import haplohub
from haplohub.models.response2 import Response2
from haplohub.rest import ApiException
from pprint import pprint

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization: 
configuration = haplohub.Configuration(
    access_token=os.environ["API_KEY"]
)
# Enter a context with an instance of the API client
with haplohub.ApiClient(configuration) as api_client:

    try:
        # Sync Cors
        api_response = api_client.organization_api.haplohub_api_v1_organization_sync_cors()
        print("The response of OrganizationApi->haplohub_api_v1_organization_sync_cors:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling OrganizationApi->haplohub_api_v1_organization_sync_cors: %s\n" % e)
```


### Parameters

This endpoint does not need any parameter.

### Return type

[**Response2**](Response2.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth), [JWTBearer](../README.md#JWTBearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **haplohub_api_v1_organization_update_organization_settings**
> Response1 haplohub_api_v1_organization_update_organization_settings(update_allowed_origins_request)

Update Organization Settings

### Example

* Api Key Authentication (ApiKeyAuth):
* Bearer Authentication (JWTBearer):

```python
import haplohub
from haplohub.models.response1 import Response1
from haplohub.models.update_allowed_origins_request import UpdateAllowedOriginsRequest
from haplohub.rest import ApiException
from pprint import pprint

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization: 
configuration = haplohub.Configuration(
    access_token=os.environ["API_KEY"]
)
# Enter a context with an instance of the API client
with haplohub.ApiClient(configuration) as api_client:
    update_allowed_origins_request = haplohub.UpdateAllowedOriginsRequest() # UpdateAllowedOriginsRequest | 

    try:
        # Update Organization Settings
        api_response = api_client.organization_api.haplohub_api_v1_organization_update_organization_settings(update_allowed_origins_request)
        print("The response of OrganizationApi->haplohub_api_v1_organization_update_organization_settings:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling OrganizationApi->haplohub_api_v1_organization_update_organization_settings: %s\n" % e)
```


### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **update_allowed_origins_request** | [**UpdateAllowedOriginsRequest**](UpdateAllowedOriginsRequest.md)|  | 

### Return type

[**Response1**](Response1.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth), [JWTBearer](../README.md#JWTBearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

