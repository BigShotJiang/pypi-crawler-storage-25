# OrganizationSettingsSchema


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**allowed_origins** | **List[str]** |  | 
**synced_allowed_origins** | **List[str]** |  | 

## Example

```python
from haplohub.models.organization_settings_schema import OrganizationSettingsSchema

# TODO update the JSON string below
json = "{}"
# create an instance of OrganizationSettingsSchema from a JSON string
organization_settings_schema_instance = OrganizationSettingsSchema.from_json(json)
# print the JSON string representation of the object
print(OrganizationSettingsSchema.to_json())

# convert the object into a dict
organization_settings_schema_dict = organization_settings_schema_instance.to_dict()
# create an instance of OrganizationSettingsSchema from a dict
organization_settings_schema_from_dict = OrganizationSettingsSchema.from_dict(organization_settings_schema_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


