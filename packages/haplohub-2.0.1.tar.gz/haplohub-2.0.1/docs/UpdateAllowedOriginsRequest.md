# UpdateAllowedOriginsRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**allowed_origins** | **List[str]** |  | 

## Example

```python
from haplohub.models.update_allowed_origins_request import UpdateAllowedOriginsRequest

# TODO update the JSON string below
json = "{}"
# create an instance of UpdateAllowedOriginsRequest from a JSON string
update_allowed_origins_request_instance = UpdateAllowedOriginsRequest.from_json(json)
# print the JSON string representation of the object
print(UpdateAllowedOriginsRequest.to_json())

# convert the object into a dict
update_allowed_origins_request_dict = update_allowed_origins_request_instance.to_dict()
# create an instance of UpdateAllowedOriginsRequest from a dict
update_allowed_origins_request_from_dict = UpdateAllowedOriginsRequest.from_dict(update_allowed_origins_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


