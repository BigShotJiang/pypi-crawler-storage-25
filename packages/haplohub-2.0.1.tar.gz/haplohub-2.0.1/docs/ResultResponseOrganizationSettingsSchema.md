# ResultResponseOrganizationSettingsSchema


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **str** |  | [optional] [default to 'success']
**result** | [**OrganizationSettingsSchema**](OrganizationSettingsSchema.md) |  | 

## Example

```python
from haplohub.models.result_response_organization_settings_schema import ResultResponseOrganizationSettingsSchema

# TODO update the JSON string below
json = "{}"
# create an instance of ResultResponseOrganizationSettingsSchema from a JSON string
result_response_organization_settings_schema_instance = ResultResponseOrganizationSettingsSchema.from_json(json)
# print the JSON string representation of the object
print(ResultResponseOrganizationSettingsSchema.to_json())

# convert the object into a dict
result_response_organization_settings_schema_dict = result_response_organization_settings_schema_instance.to_dict()
# create an instance of ResultResponseOrganizationSettingsSchema from a dict
result_response_organization_settings_schema_from_dict = ResultResponseOrganizationSettingsSchema.from_dict(result_response_organization_settings_schema_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


