# UploadRequestSchema


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | 
**cohort_id** | **str** |  | 
**sample_id** | **str** |  | [optional] 
**member_id** | **str** |  | [optional] 
**task_count** | **int** |  | [optional] [default to 0]
**requested_files** | [**List[FileInfo]**](FileInfo.md) |  | [optional] [default to []]
**external_id** | **str** |  | 
**status** | **str** |  | [optional] [default to 'new']
**cancel_reason** | **str** |  | [optional] 
**file_type** | **str** |  | [optional] 
**temporal_workflow_id** | **str** |  | [optional] 
**started_at** | **datetime** |  | [optional] 
**completed_at** | **datetime** |  | [optional] 
**cancelled_at** | **datetime** |  | [optional] 
**error_message** | **str** |  | [optional] 
**created** | **datetime** |  | [optional] 
**modified** | **datetime** |  | [optional] 

## Example

```python
from haplohub.models.upload_request_schema import UploadRequestSchema

# TODO update the JSON string below
json = "{}"
# create an instance of UploadRequestSchema from a JSON string
upload_request_schema_instance = UploadRequestSchema.from_json(json)
# print the JSON string representation of the object
print(UploadRequestSchema.to_json())

# convert the object into a dict
upload_request_schema_dict = upload_request_schema_instance.to_dict()
# create an instance of UploadRequestSchema from a dict
upload_request_schema_from_dict = UploadRequestSchema.from_dict(upload_request_schema_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


