# ResultResponseTaskSchema


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **str** |  | [optional] [default to 'success']
**result** | [**TaskSchema**](TaskSchema.md) |  | 

## Example

```python
from haplohub.models.result_response_task_schema import ResultResponseTaskSchema

# TODO update the JSON string below
json = "{}"
# create an instance of ResultResponseTaskSchema from a JSON string
result_response_task_schema_instance = ResultResponseTaskSchema.from_json(json)
# print the JSON string representation of the object
print(ResultResponseTaskSchema.to_json())

# convert the object into a dict
result_response_task_schema_dict = result_response_task_schema_instance.to_dict()
# create an instance of ResultResponseTaskSchema from a dict
result_response_task_schema_from_dict = ResultResponseTaskSchema.from_dict(result_response_task_schema_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


