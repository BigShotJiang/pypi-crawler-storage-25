# VariantResultSchema


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**target** | [**TargetReferenceSchema**](TargetReferenceSchema.md) |  | 
**variant** | [**VariantSchema**](VariantSchema.md) |  | [optional] 
**samples** | [**List[SampleVariantCallSchema]**](SampleVariantCallSchema.md) |  | [optional] 
**attachments** | [**VariantAttachmentSchema**](VariantAttachmentSchema.md) |  | [optional] 
**error_message** | **str** |  | [optional] 

## Example

```python
from haplohub.models.variant_result_schema import VariantResultSchema

# TODO update the JSON string below
json = "{}"
# create an instance of VariantResultSchema from a JSON string
variant_result_schema_instance = VariantResultSchema.from_json(json)
# print the JSON string representation of the object
print(VariantResultSchema.to_json())

# convert the object into a dict
variant_result_schema_dict = variant_result_schema_instance.to_dict()
# create an instance of VariantResultSchema from a dict
variant_result_schema_from_dict = VariantResultSchema.from_dict(variant_result_schema_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


