# UploadRequestStatus


## Enum

* `NEW` (value: `'new'`)

* `PENDING` (value: `'pending'`)

* `COMPLETED` (value: `'completed'`)

* `CANCELLED` (value: `'cancelled'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


