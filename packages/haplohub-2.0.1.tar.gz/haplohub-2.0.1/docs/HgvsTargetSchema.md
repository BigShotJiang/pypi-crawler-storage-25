# HgvsTargetSchema


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **str** |  | [optional] [default to 'hgvs']
**value** | **str** |  | 

## Example

```python
from haplohub.models.hgvs_target_schema import HgvsTargetSchema

# TODO update the JSON string below
json = "{}"
# create an instance of HgvsTargetSchema from a JSON string
hgvs_target_schema_instance = HgvsTargetSchema.from_json(json)
# print the JSON string representation of the object
print(HgvsTargetSchema.to_json())

# convert the object into a dict
hgvs_target_schema_dict = hgvs_target_schema_instance.to_dict()
# create an instance of HgvsTargetSchema from a dict
hgvs_target_schema_from_dict = HgvsTargetSchema.from_dict(hgvs_target_schema_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


