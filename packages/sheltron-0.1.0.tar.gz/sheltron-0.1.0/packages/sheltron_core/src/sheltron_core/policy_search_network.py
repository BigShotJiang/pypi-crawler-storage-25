from __future__ import annotations

from dataclasses import dataclass, field
import ipaddress

from sheltron_core.policy_engine import PolicyContext
from sheltron_core.schemas import ActionRequest, Capability, PolicyResult, ResourceKind


@dataclass(slots=True)
class SearchAccessPolicy:
    max_query_chars: int = 500
    max_results: int = 10
    name: str = 'search_access'

    def evaluate(self, request: ActionRequest, context: PolicyContext) -> PolicyResult | None:
        del context
        if request.capability is not Capability.SEARCH_WEB:
            return None
        if request.resource.kind is not ResourceKind.SEARCH_QUERY:
            return None

        query = request.resource.locator
        count = request.parameters.get('count')
        provider = request.parameters.get('provider')
        backend_kind = request.parameters.get('backend_kind')
        query_chars = request.parameters.get('query_chars')
        suspicious_token_count = request.parameters.get('suspicious_token_count')
        suspicious_token_matches = request.parameters.get('suspicious_token_matches')
        private_key_markers = request.parameters.get('private_key_markers')
        details = {
            'query': query,
            'provider': provider,
            'backend_kind': backend_kind,
        }

        if not isinstance(query, str) or not query.strip():
            return PolicyResult.deny(
                self.name,
                code='search_query_missing',
                message='Web search requires a non-empty normalized query.',
                details=details,
            )
        if not isinstance(query_chars, int) or query_chars <= 0:
            return PolicyResult.deny(
                self.name,
                code='search_query_missing',
                message='Web search requires a non-empty normalized query.',
                details=details,
            )
        if query_chars > self.max_query_chars:
            return PolicyResult.deny(
                self.name,
                code='search_query_too_large',
                message='Web search queries that exceed the configured size limit are denied.',
                details={
                    **details,
                    'query_chars': query_chars,
                    'max_query_chars': self.max_query_chars,
                },
            )
        if not isinstance(count, int):
            return PolicyResult.deny(
                self.name,
                code='search_count_missing',
                message='Web search requires a normalized result count.',
                details=details,
            )
        if count < 1 or count > self.max_results:
            return PolicyResult.deny(
                self.name,
                code='search_count_invalid',
                message='Web search result counts must stay within the configured range.',
                details={**details, 'count': count, 'max_results': self.max_results},
            )
        if not isinstance(provider, str) or not provider.strip():
            return PolicyResult.deny(
                self.name,
                code='search_provider_missing',
                message='Web search requires a normalized backend provider name.',
                details=details,
            )
        if not isinstance(backend_kind, str) or not backend_kind.strip():
            return PolicyResult.deny(
                self.name,
                code='search_backend_missing',
                message='Web search requires a normalized backend kind.',
                details=details,
            )
        if isinstance(private_key_markers, (tuple, list)) and private_key_markers:
            return PolicyResult.deny(
                self.name,
                code='private_key_search_denied',
                message='Web search queries containing private key material are denied.',
                details={**details, 'private_key_markers': tuple(private_key_markers)},
            )
        if isinstance(suspicious_token_count, int) and suspicious_token_count > 0:
            return PolicyResult.require_approval(
                self.name,
                code='secret_like_search_requires_approval',
                message='Web search queries that match secret-like token patterns require explicit approval.',
                details={
                    **details,
                    'suspicious_token_count': suspicious_token_count,
                    'suspicious_token_matches': tuple(suspicious_token_matches or ()),
                },
            )
        return PolicyResult.allow(
            self.name,
            code='search_allowed',
            message='The web search request passed the current search policy.',
            details={**details, 'count': count},
        )


@dataclass(slots=True)
class NetworkAccessPolicy:
    allowed_schemes: frozenset[str] = field(default_factory=lambda: frozenset({'http', 'https'}))
    localhost_hostnames: frozenset[str] = field(
        default_factory=lambda: frozenset({'localhost', 'localhost.localdomain'})
    )
    name: str = 'network_access'

    def evaluate(self, request: ActionRequest, context: PolicyContext) -> PolicyResult | None:
        del context
        if request.capability not in {Capability.NETWORK_FETCH, Capability.NETWORK_POST}:
            return None
        if request.resource.kind is not ResourceKind.URL:
            return None

        scheme = request.parameters.get('scheme')
        hostname = request.parameters.get('hostname')
        resolved_ips = request.parameters.get('resolved_ips')
        resolution_error = request.parameters.get('resolution_error')
        credentials_present = bool(request.parameters.get('credentials_present'))
        details = {'url': request.resource.locator}

        if not isinstance(scheme, str) or not scheme:
            return PolicyResult.deny(
                self.name,
                code='url_scheme_missing',
                message='Network access requires a normalized URL scheme.',
                details=details,
            )
        if scheme not in self.allowed_schemes:
            return PolicyResult.deny(
                self.name,
                code='url_scheme_not_allowed',
                message='Only http and https URLs are allowed by the current network policy.',
                details={**details, 'scheme': scheme},
            )
        if not isinstance(hostname, str) or not hostname:
            return PolicyResult.deny(
                self.name,
                code='url_hostname_missing',
                message='Network access requires a normalized hostname.',
                details=details,
            )
        if credentials_present:
            return PolicyResult.deny(
                self.name,
                code='url_credentials_denied',
                message='Embedded URL credentials are not allowed.',
                details={**details, 'hostname': hostname},
            )
        if hostname.lower().rstrip('.') in self.localhost_hostnames or hostname.lower().endswith('.local'):
            return PolicyResult.deny(
                self.name,
                code='localhost_destination_denied',
                message='Localhost and local-domain destinations are not allowed.',
                details={**details, 'hostname': hostname},
            )
        if isinstance(resolution_error, str) and resolution_error:
            return PolicyResult.deny(
                self.name,
                code='url_resolution_failed',
                message='The network destination could not be resolved safely.',
                details={**details, 'hostname': hostname, 'resolution_error': resolution_error},
            )
        if not isinstance(resolved_ips, (tuple, list)) or not resolved_ips:
            return PolicyResult.deny(
                self.name,
                code='resolved_ips_missing',
                message='Network access requires resolved destination addresses.',
                details={**details, 'hostname': hostname},
            )

        blocked_ip = next((ip for ip in resolved_ips if self._is_blocked_ip(ip)), None)
        if blocked_ip is not None:
            return PolicyResult.deny(
                self.name,
                code='private_network_denied',
                message='Private, loopback, link-local, multicast, and reserved destinations are not allowed.',
                details={**details, 'hostname': hostname, 'ip': blocked_ip},
            )
        if request.capability is Capability.NETWORK_POST:
            return PolicyResult.require_approval(
                self.name,
                code='network_post_requires_approval',
                message='Outbound POST requests require explicit approval.',
                details={**details, 'hostname': hostname},
            )
        return PolicyResult.allow(
            self.name,
            code='network_destination_allowed',
            message='The destination URL passed the current network policy checks.',
            details={**details, 'hostname': hostname},
        )

    @staticmethod
    def _is_blocked_ip(raw_ip: str) -> bool:
        try:
            ip = ipaddress.ip_address(raw_ip)
        except ValueError:
            return True
        return (
            ip.is_private
            or ip.is_loopback
            or ip.is_link_local
            or ip.is_multicast
            or ip.is_unspecified
            or ip.is_reserved
        )
