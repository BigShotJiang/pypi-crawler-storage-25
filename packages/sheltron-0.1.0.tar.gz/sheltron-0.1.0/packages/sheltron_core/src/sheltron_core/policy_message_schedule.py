from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from sheltron_core.policy_engine import PolicyContext
from sheltron_core.schemas import ActionRequest, Capability, PolicyResult, ResourceKind


@dataclass(slots=True)
class MessageAccessPolicy:
    max_content_chars: int = 4_000
    allowed_target_locators: frozenset[str] | None = None
    name: str = 'message_access'

    def evaluate(self, request: ActionRequest, context: PolicyContext) -> PolicyResult | None:
        del context
        if request.capability is not Capability.SEND_MESSAGE:
            return None
        if request.resource.kind is not ResourceKind.MESSAGE_TARGET:
            return None

        channel = request.parameters.get('channel')
        recipient = request.parameters.get('recipient')
        content_chars = request.parameters.get('content_chars')
        media_count = request.parameters.get('media_count')
        content_redacted = bool(request.parameters.get('content_redacted'))
        default_channel = request.parameters.get('default_channel')
        default_recipient = request.parameters.get('default_recipient')
        suspicious_token_count = request.parameters.get('suspicious_token_count')
        suspicious_token_matches = request.parameters.get('suspicious_token_matches')
        private_key_markers = request.parameters.get('private_key_markers')
        default_target = None
        if isinstance(default_channel, str) and default_channel and isinstance(default_recipient, str) and default_recipient:
            default_target = f'{default_channel}:{default_recipient}'
        details = {
            'target': request.resource.locator,
            'channel': channel,
            'recipient': recipient,
        }

        if not isinstance(channel, str) or not channel:
            return PolicyResult.deny(
                self.name,
                code='message_channel_missing',
                message='Outbound messages require a normalized channel name.',
                details=details,
            )
        if not isinstance(recipient, str) or not recipient:
            return PolicyResult.deny(
                self.name,
                code='message_recipient_missing',
                message='Outbound messages require a normalized recipient.',
                details=details,
            )
        if not isinstance(content_chars, int) or content_chars <= 0:
            return PolicyResult.deny(
                self.name,
                code='message_content_missing',
                message='Outbound messages require non-empty content.',
                details=details,
            )
        if content_chars > self.max_content_chars:
            return PolicyResult.deny(
                self.name,
                code='message_too_large',
                message='Outbound messages that exceed the configured size limit are denied.',
                details={**details, 'content_chars': content_chars, 'max_content_chars': self.max_content_chars},
            )
        if not isinstance(media_count, int) or media_count < 0:
            return PolicyResult.deny(
                self.name,
                code='message_media_count_invalid',
                message='Outbound messages require a valid media count.',
                details=details,
            )
        if self.allowed_target_locators is not None and request.resource.locator not in self.allowed_target_locators:
            return PolicyResult.deny(
                self.name,
                code='message_target_not_allowlisted',
                message='The requested outbound message target is not in the configured allowlist.',
                details={
                    **details,
                    'allowed_targets': tuple(sorted(self.allowed_target_locators)),
                },
            )
        if isinstance(private_key_markers, (tuple, list)) and private_key_markers:
            return PolicyResult.deny(
                self.name,
                code='private_key_message_denied',
                message='Outbound messages containing private key material are denied.',
                details={**details, 'private_key_markers': tuple(private_key_markers)},
            )
        if not default_target:
            return PolicyResult.require_approval(
                self.name,
                code='unscoped_target_requires_approval',
                message='Sending without a default target context requires explicit approval.',
                details=details,
            )
        if media_count > 0:
            return PolicyResult.require_approval(
                self.name,
                code='message_media_requires_approval',
                message='Outbound messages with attachments require explicit approval.',
                details={**details, 'media_count': media_count},
            )
        if isinstance(suspicious_token_count, int) and suspicious_token_count > 0:
            return PolicyResult.require_approval(
                self.name,
                code='secret_like_message_requires_approval',
                message='Outbound message content matched secret-like token patterns and requires explicit approval.',
                details={
                    **details,
                    'suspicious_token_count': suspicious_token_count,
                    'suspicious_token_matches': tuple(suspicious_token_matches or ()),
                },
            )
        if content_redacted:
            return PolicyResult.require_approval(
                self.name,
                code='redacted_message_requires_approval',
                message='Outbound message content matched configured secret values and was redacted; sending requires approval.',
                details=details,
            )

        target_overridden = default_target != request.resource.locator
        if target_overridden:
            return PolicyResult.require_approval(
                self.name,
                code='nondefault_recipient_requires_approval',
                message='Sending to a non-default channel or recipient requires explicit approval.',
                details={**details, 'default_channel': default_channel, 'default_recipient': default_recipient},
            )
        return PolicyResult.allow(
            self.name,
            code='message_allowed',
            message='The outbound message matches the default target and passed the current message policy.',
            details=details,
        )


@dataclass(slots=True)
class ScheduleTaskPolicy:
    max_spawn_task_chars: int = 4_000
    max_cron_message_chars: int = 4_000
    min_cron_interval_seconds: int = 60
    allow_spawn: bool = True
    name: str = 'schedule_task_access'

    def evaluate(self, request: ActionRequest, context: PolicyContext) -> PolicyResult | None:
        del context
        if request.capability is not Capability.SCHEDULE_TASK:
            return None
        if request.resource.kind is not ResourceKind.TASK_TARGET:
            return None

        task_kind = request.parameters.get('task_kind')
        action = request.parameters.get('action')
        details = {
            'target': request.resource.locator,
            'task_kind': task_kind,
            'action': action,
        }

        if task_kind == 'spawn':
            task = request.parameters.get('task')
            task_chars = request.parameters.get('task_chars')
            if not isinstance(task, str) or not task.strip():
                return PolicyResult.deny(
                    self.name,
                    code='spawn_task_missing',
                    message='Spawn requests require a non-empty task.',
                    details=details,
                )
            if not isinstance(task_chars, int) or task_chars <= 0:
                return PolicyResult.deny(
                    self.name,
                    code='spawn_task_missing',
                    message='Spawn requests require a non-empty task.',
                    details=details,
                )
            if task_chars > self.max_spawn_task_chars:
                return PolicyResult.deny(
                    self.name,
                    code='spawn_task_too_large',
                    message='Spawn requests that exceed the configured size limit are denied.',
                    details={**details, 'task_chars': task_chars, 'max_task_chars': self.max_spawn_task_chars},
                )
            if not self.allow_spawn:
                return PolicyResult.deny(
                    self.name,
                    code='spawn_not_supported',
                    message='Background spawn is denied until spawned subagents are fully Sheltron-guarded.',
                    details=details,
                )
            return PolicyResult.require_approval(
                self.name,
                code='spawn_requires_approval',
                message='Background spawn requires explicit approval.',
                details=details,
            )

        if task_kind != 'cron':
            return PolicyResult.deny(
                self.name,
                code='task_kind_invalid',
                message='Scheduled-task requests require a recognized task kind.',
                details=details,
            )

        if action == 'list':
            return PolicyResult.allow(
                self.name,
                code='cron_list_allowed',
                message='Listing scheduled jobs is allowed.',
                details=details,
            )

        if action == 'remove':
            job_id = request.parameters.get('job_id')
            if not isinstance(job_id, str) or not job_id.strip():
                return PolicyResult.deny(
                    self.name,
                    code='cron_job_id_missing',
                    message='Removing a scheduled job requires a job id.',
                    details=details,
                )
            return PolicyResult.allow(
                self.name,
                code='cron_remove_allowed',
                message='Removing an existing scheduled job is allowed.',
                details={**details, 'job_id': job_id},
            )

        if action != 'add':
            return PolicyResult.deny(
                self.name,
                code='cron_action_invalid',
                message='Cron requests require an action of add, list, or remove.',
                details=details,
            )

        if bool(request.parameters.get('in_cron_context')):
            return PolicyResult.deny(
                self.name,
                code='cron_nested_schedule_denied',
                message='Scheduling new cron jobs from within a cron execution is denied.',
                details=details,
            )

        message = request.parameters.get('message')
        message_chars = request.parameters.get('message_chars')
        every_seconds = request.parameters.get('every_seconds')
        cron_expr = request.parameters.get('cron_expr')
        tz = request.parameters.get('tz')
        at = request.parameters.get('at')

        if not isinstance(message, str) or not message.strip():
            return PolicyResult.deny(
                self.name,
                code='cron_message_missing',
                message='Scheduling a cron job requires a non-empty reminder or task message.',
                details=details,
            )
        if not isinstance(message_chars, int) or message_chars <= 0:
            return PolicyResult.deny(
                self.name,
                code='cron_message_missing',
                message='Scheduling a cron job requires a non-empty reminder or task message.',
                details=details,
            )
        if message_chars > self.max_cron_message_chars:
            return PolicyResult.deny(
                self.name,
                code='cron_message_too_large',
                message='Scheduled-task messages that exceed the configured size limit are denied.',
                details={**details, 'message_chars': message_chars, 'max_message_chars': self.max_cron_message_chars},
            )

        schedule_count = int(isinstance(every_seconds, int)) + int(isinstance(cron_expr, str) and bool(cron_expr)) + int(
            isinstance(at, str) and bool(at)
        )
        if schedule_count != 1:
            return PolicyResult.deny(
                self.name,
                code='cron_schedule_invalid',
                message='Cron add requests require exactly one of every_seconds, cron_expr, or at.',
                details=details,
            )
        if isinstance(every_seconds, int):
            if every_seconds < self.min_cron_interval_seconds:
                return PolicyResult.deny(
                    self.name,
                    code='cron_interval_too_small',
                    message='Cron intervals below the configured minimum are denied.',
                    details={
                        **details,
                        'every_seconds': every_seconds,
                        'min_cron_interval_seconds': self.min_cron_interval_seconds,
                    },
                )
        if tz and not cron_expr:
            return PolicyResult.deny(
                self.name,
                code='cron_timezone_invalid',
                message='A cron timezone may only be used with cron_expr schedules.',
                details=details,
            )
        if isinstance(at, str):
            try:
                datetime.fromisoformat(at)
            except ValueError:
                return PolicyResult.deny(
                    self.name,
                    code='cron_at_invalid',
                    message='One-time cron schedules require a valid ISO datetime.',
                    details={**details, 'at': at},
                )

        return PolicyResult.require_approval(
            self.name,
            code='cron_add_requires_approval',
            message='Creating a scheduled job requires explicit approval.',
            details=details,
        )
