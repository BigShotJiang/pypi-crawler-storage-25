# nlsql-coder

nlsql-coder is NLSQL's coding agent, a privacy & security focused, tool-driven, workspace-aware AI system designed to help with both personal and client-based development tasks.

# Features

- User-friendly command line interface.
- Wide array of LLM/provider support acorss many cloud ecosystems, including locally hosted model support.
- Primary privacy & security focus.
- Parallel tool calling ability for speed and efficency.

# How it Works

The agent operates using a ReAct-style loop. A user submits a prompt, and the agent processes it by reasoning about the task, performing actions using available tools, and evaluating the results.

If the outcome is insufficient or incomplete, the agent continues this cycle, refining its approach and taking further actions until it can produce a final response.

# Usage

nlsql-coder is available for download via PyPI, follow the steps below to get it running on your system:

1. run `pip install nlsql-coder`
2. use the command `nlsql-coder init` to run from your CWD.

for other options or extended usage, see Arguments section below.

## Arguments

Use the `init` command to start the application from the current working directory.

| Short | Long | Description | Defaults to |
|-|-|-|-|
| `-w` | `--workspace` | The root directory of the project you want to work on. | `.` |
| `-u` | `--usage` | Displays usage data after each conversation turn (input & output tokens) | `False` |




**NOTE: nlsql-coder is still in active development - the current state of the applications does not currently reflect the README entirely.**
