from nlsql_coder.app.agent.helpers.get_agent import get_conf
from nlsql_coder.app.cli.tool_calling import call_tools
from nlsql_coder.app.cli.arg_parsing import args
from nlsql_coder.data.create_agent_md import create_md

from rich.console import Console
from rich.markdown import Markdown
from rich.live import Live
from rich.align import Align
from rich.spinner import Spinner

from prompt_toolkit import PromptSession
from prompt_toolkit.formatted_text import HTML
from prompt_toolkit.key_binding import KeyBindings

from pathlib import Path
from itertools import cycle
import time
import os

from dotenv import load_dotenv


modes = cycle(["Code", "Plan", "Auto"])
state = {
    "mode": next(modes)
}

# Key bindings - for changing agent modes (code, plan, auto)
keys = KeyBindings()

@keys.add("s-tab")
def change_mode(event):
    state["mode"] = next(modes)
    event.app.invalidate()
    

console = Console()

def get_envs():
    console.clear()

    if Path(args.workspace, ".env").exists():
        while True:
            env = console.input(
                "\n\n[bold blue].env file detected, would you like to use this? (y/n):[/bold blue] "
            )

            if env.lower() == "y":
                load_dotenv(Path(args.workspace, ".env"))
                console.clear()

                agent, _ = get_conf()

                if not agent:
                    console.print(
                        "[bold red]✕ Incorrect configuration, please enter manually...[/bold red]"
                    )
                    console.clear()
                    break

                return agent

            elif env.lower() == "n":
                console.clear()
                break

    provider = console.input(
        "\n\n[bold blue][Provider (aws/azure)]:[/bold blue] "
    ).strip().lower()

    console.clear()

    os.environ["MODEL_PROVIDER"] = provider

    QUESTIONS = {
        "aws": [
            ("MODEL_NAME", "\n[bold blue][Model name]:[/bold blue] "),
            ("AWS_ACCESS_KEY_ID", "[bold blue][Access Key ID]:[/bold blue] "),
            ("AWS_SECRET_ACCESS_KEY", "[bold blue][Secret Access Key]:[/bold blue] "),
            ("AWS_DEFAULT_REGION", "[bold blue][Region]:[/bold blue] "),
        ],

        "azure": [
            ("MODEL_NAME", "\n[bold blue][Deployment name]:[/bold blue] "),
            ("AZURE_OPENAI_API_KEY", "[bold blue][API Key]:[/bold blue] "),
            ("AZURE_OPENAI_ENDPOINT", "[bold blue][Endpoint]:[/bold blue] "),
            ("AZURE_OPENAI_API_VERSION", "[bold blue][API Version]:[/bold blue] "),
        ]
    }

    questions = QUESTIONS.get(provider)

    if not questions:
        console.print(f"[bold red]✕ Unknown provider: {provider}[/bold red]")
        return None

    answers = {}

    end = "\n\n"
    end_flag = False

    for key, prompt in questions:

        console.print(
            "\n\n[bold]To start, we need to set up your environment variables...[/bold]",
            end=end if end_flag else "\n"
        )

        value = console.input(prompt)

        console.clear()

        answers[key] = value

        end_flag = True

    console.clear()

    for key, value in answers.items():
        os.environ[key] = value

    agent, _ = get_conf()

    if agent:
        console.print(
            "\n\n[bold green]✓ Model configured successfully.[/bold green]"
        )
        time.sleep(2)
        console.clear()
        return agent

    console.print(
        "\n\n[bold red]✕ Incorrect configuration, please try again...[/bold red]"
    )

    time.sleep(2)

    console.clear()

    return None


def create_agents_md():
    console.print("\n")
    with console.status("[bold]Creating AGENTS.md file...[/bold]", spinner="dots"):
        success = create_md()
    if success == "created":
        console.print("[bold]AGENTS.md file created at project root.[/bold]")
    elif success == "exists":
        console.print("[bold]AGENTS.md file already exists at project root.[/bold]")
    elif success == "empty":
        console.print("[bold]Starting from scratch![/bold]")
    else:
        console.print("[bold]Failed to create AGENTS.md file.[/bold]")
    time.sleep(2)
    console.clear()


WELCOME_MESSAGE = """[blue bold]\n
Welcome      _   _  _      ____   ___  _     
            | \ | || |    / ___| / _ \| |    
       to   |  \| || |    \___ \| | | | |    
            | |\  || |___  ___) | |_| | |___ 
            |_| \_||_____||____/ \__\_\_____|   Coder\n\n[/blue bold]
"""

def main_loop():
    try:
        # Initial setup
        while True:
            agent = get_envs()
            if agent:
                break
        
        # Create AGENTS.md
        create_agents_md()

        #  Welcome message
        console.print(Align.center(WELCOME_MESSAGE))

        session = PromptSession(key_bindings=keys)
        def get_prompt():
            return HTML(f"\n<ansicyan>[Mode: {state['mode']}]</ansicyan><style fg='#00ff00'><b>[You]: </b></style>")
        
        # Conversation loop
        plan_confirmed = False
        usage_data = {}
        while True:

            # Print last turn's usage data tables if -u flag given
            if args.usage and usage_data:
                core_table = (
                    "| Metric | Value |\n"
                    "|--------|-------|\n"
                    f"| Input Tokens | {usage_data.get('input_tokens', 0)} |\n"
                    f"| Output Tokens | {usage_data.get('output_tokens', 0)} |\n"
                    f"| Total Tokens | {usage_data.get('total_tokens', 0)} |\n"
                    f"| Cache Read Tokens | {usage_data.get('cache_read_tokens', 0)} |\n"
                    f"| Cache Write Tokens | {usage_data.get('cache_write_tokens', 0)} |\n"
                )
                cache_details = usage_data.get("cache_details", {})
                cache_table = (
                    "| Cache TTL | Tokens |\n"
                    "|-----------|--------|\n"
                )
                if cache_details:
                    for ttl, tokens in cache_details.items():
                        cache_table += f"| {ttl} | {tokens} |\n"
                else:
                    cache_table += "| - | 0 |\n"
                console.print("[bold]\n\nUsage Data[/bold]")

                console.print(Markdown(core_table))
                console.print(Markdown(cache_table))

            message = ""
            if not plan_confirmed:
                message = session.prompt(get_prompt)
            else:
                plan_confirmed = False
            if message.lower() in ["quit", "exit"]:
                console.print("\n\n[bold purple]Goodbye[/bold purple]\n")
                break
        
            if state["mode"] == "Plan":
                message = "PLAN MODE\n" + message

            # AI model loop
            usage_data = {}
            if message:
                console.print("\n[bold cyan][Assistant]:[/bold cyan]")
            while True:
                if not message:
                    plan_confirmed = False
                    break
                found_tool_calls = False
                buffer = ""

                with Live(console=console, refresh_per_second=30, vertical_overflow="visible") as live:
                    for chunk in agent.chat(message, state["mode"]):
                        if isinstance(chunk, str):
                            # Chat messages    
                            buffer += chunk
                            live.update(Markdown(buffer))
                            if chunk == "":
                                # Tool spinner
                                live.update(Spinner("dots", f"{buffer}\n"))
                        # Tool calls
                        elif isinstance(chunk, list):
                            found_tool_calls = True
                            live.stop()
                            tool_results = call_tools(chunk, state["mode"], console)
                            feedback_result = next(
                                (result for result in tool_results if "User gave feedback:" in result["result"]),
                                None
                            )
                            if feedback_result:
                                message = tool_results
                                break
                            confirm_result = next(
                                (result for result in tool_results if result["name"] == "confirm_plan"),
                                None
                            )
                            if confirm_result:
                                action = confirm_result.get("result", "")
                            else:
                                action = ""
                            confirm_msg = (
                                    "The user has confirmed the plan. "
                                    "Proceed with completing the task automatically." \
                                    "STOP AS SOON AS YOU HAVE COMPLETED THE PLAN."
                                )
                            if action == "_auto":
                                state["mode"] = "Auto"
                                confirm_result["result"] =  confirm_msg
                                plan_confirmed = True
                            if action == "_manual":
                                state["mode"] = "Code"
                                confirm_result["result"] = confirm_msg
                                plan_confirmed = True
                            if action == "_discard":
                                agent.delete_plan()
                                confirm_result["result"] = "The user has discarded the plan."

                            message = tool_results
                        
                        # Usage datas
                        elif isinstance(chunk, dict):
                            if args.usage:
                                if not usage_data:
                                    usage_data["input_tokens"] = chunk["input_tokens"]
                                    usage_data["output_tokens"] = chunk["output_tokens"]
                                    usage_data["total_tokens"] = chunk["total_tokens"]
                                    usage_data["cache_read_tokens"] = chunk["cache_read_tokens"]
                                    usage_data["cache_write_tokens"] = chunk["cache_write_tokens"]
                                    usage_data["cache_details"] = {}
                                    for detail in chunk.get("cache_details", []):
                                        ttl = detail["ttl"]
                                        tokens = detail["inputTokens"]
                                        usage_data["cache_details"][ttl] = (
                                            usage_data["cache_details"].get(ttl, 0) + tokens
                                        )
                                else:
                                    usage_data["input_tokens"] += chunk["input_tokens"]
                                    usage_data["output_tokens"] += chunk["output_tokens"]
                                    usage_data["total_tokens"] += chunk["total_tokens"]
                                    usage_data["cache_read_tokens"] += chunk["cache_read_tokens"]
                                    usage_data["cache_write_tokens"] += chunk["cache_write_tokens"]
                                    for detail in chunk.get("cache_details", []):
                                        ttl = detail["ttl"]
                                        tokens = detail["inputTokens"]
                                        usage_data["cache_details"][ttl] = (
                                            usage_data["cache_details"].get(ttl, 0) + tokens
                                        )



                if not found_tool_calls:
                    break
    except KeyboardInterrupt:
        console.print("\n\n[bold purple]Goodbye[/bold purple]\n")
    except Exception as e:
        console.print(f"\n\n[bold red]Oh no! Something went wrong. Here's the error:\n\n{e}[/bold red]\n")
