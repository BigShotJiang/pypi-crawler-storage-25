from nlsql_coder.app.agent.tools.tool_registry import TOOL_REGISTRY
import json

allowed_reads = set()

def call_tools(tool_calls: list[dict], mode: str, console) -> list[dict]:
    try:
        tool_results = []

        for tool in tool_calls:
            tool_id = tool["toolUseId"]
            tool_name = tool["name"]
            tool_input = tool["input"]

            # Restrict tools in Plan mode
            if mode == "Plan" and tool_name not in ["read_file", "get_project_tree", "confirm_plan"]:
                tool_results.append({
                    "toolUseId": tool_id,
                    "name": tool_name,
                    "result": "error: Read only tools allowed in Plan mode.",
                    "status": "error"
                })
                continue

            auto_approved = False

            # Auto approve all tool calls if in auto mode or plan mode
            if mode == "Plan":
                auto_approved = True
            if mode == "Auto" and tool_name != "delete":
                auto_approved = True
            if mode == "Auto" and tool_name == "execute_bash_command":
                print("hit")
                if "git" in  tool_input["command"]:
                    print("again")
                    auto_approved = False
            # Auto approve previously approved file reads
            else: 
                if tool_name == "edit_file":
                    auto_approved = True
                elif tool_name == "read_file":
                    file_path = tool_input.get("file_path")

                    if file_path in allowed_reads:
                        auto_approved = True
            
            # Ask for confirmation if not auto approved
            if not auto_approved:
                console.print("[red3 bold]Confirm tool use:[/red3 bold]")
                console.print(f"[bold]\tTool: {tool_name}[/bold]")

                if tool_input:
                    console.print(f"[bold]\tInput: {tool_input}[/bold]")

                feedback = ""
                while True:
                    confirm = console.input("[bold]Confirm?[/bold] [bright_black]\\[Y] yes / \\[N] no / or type feedback to revise:[/bright_black] ").lower()

                    if confirm in ["n", "no"]:
                        tool_results.append({
                            "toolUseId": tool_id,
                            "name": tool_name,
                            "result": "error: User refused tool execution.",
                            "status": "error"
                        })
                        break

                    elif confirm in ["y", "yes"]:

                        # Save approved read_file paths
                        if tool_name == "read_file":
                            file_path = tool_input.get("file_path")
                            if file_path:
                                allowed_reads.add(file_path)

                        break

                    else:
                        feedback = confirm
                        break
                if feedback:
                    tool_results.append({
                        "toolUseId": tool_id,
                        "name": tool_name,
                        "result": f"User gave feedback: {feedback}",
                        "status": "error"
                    })
                    return tool_results

            else:
                console.print(f"[bold green]\tTool: {tool_name}\n\tInput{tool_input}[bold green]")

            # Skip execution if user denied
            if any(
                r["toolUseId"] == tool_id and r["status"] == "error"
                for r in tool_results
            ):
                continue

            # Execute tool
            tool_function = TOOL_REGISTRY.get(tool_name)

            if not tool_function:
                tool_results.append({
                    "toolUseId": tool_id,
                    "name": tool_name,
                    "result": "error: Unknown tool.",
                    "status": "error"
                })
                continue

            console.print("\n\n")
            if tool_name == "edit_file":
                result = tool_function(**tool_input, mode=mode)
            else:
                result = tool_function(**tool_input)

            if isinstance(result, dict):
                result = json.dumps(result)

            tool_results.append({
                "toolUseId": tool_id,
                "name": tool_name,
                "result": result,
                "status": "success"
            })

        return tool_results
    except Exception as e:
        raise e