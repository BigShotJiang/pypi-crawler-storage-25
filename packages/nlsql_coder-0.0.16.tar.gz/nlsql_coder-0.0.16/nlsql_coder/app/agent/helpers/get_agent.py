from pathlib import Path
from nlsql_coder.app.providers.config import ProviderConfig
from nlsql_coder.app.agent.model.agent import Agent
from nlsql_coder.app.agent.tools.tool_specs import read_file_spec, write_file_spec, get_project_tree_spec, edit_file_spec, execute_bash_command_spec, delete_spec
from nlsql_coder.app.agent.helpers.system_prompt import construct_system_prompt

def get_conf():
    agent = None
    llm = None
    provider_config = ProviderConfig()
    system_prompt = construct_system_prompt()
    tools = [read_file_spec, write_file_spec, get_project_tree_spec, edit_file_spec, execute_bash_command_spec, delete_spec]

    if provider_config.model_provider == "aws":
        from nlsql_coder.app.providers.aws.provider import AWSBedrockProvider
        model_id = provider_config.model_name
        llm = AWSBedrockProvider(model_id)
        agent = Agent(llm, system_prompt, tools)
        return agent, llm
    
    if provider_config.model_provider == "azure":
        from nlsql_coder.app.providers.azure.provider import AzureOpenAIProvider
        model_id = provider_config.model_name
        llm = AzureOpenAIProvider(model_id)
        agent = Agent(llm, system_prompt, tools)
        return agent, llm
    return None, None