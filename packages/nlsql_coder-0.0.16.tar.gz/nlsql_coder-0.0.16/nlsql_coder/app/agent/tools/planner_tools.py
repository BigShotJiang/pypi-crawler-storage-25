from prompt_toolkit import PromptSession
from prompt_toolkit.formatted_text import FormattedText
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.styles import Style

PLANNER_TOOL_REGISTRY = {}

options = [
    "Yes (auto mode)",
    "Yes (manual mode)",
    "Give feedback (type feedback, then enter)",
    "Discard plan"
]

index = 0
keys = KeyBindings()

@keys.add("s-tab")
def _(event):
    global index
    index = (index + 1) % len(options)
    event.app.invalidate()


style = Style.from_dict({
    "title": "bold cyan",
    "highlight": "bold",
})


def get_prompt():
    result = []

    result.append(("class:title", "Do you want to proceed with the plan?\n\n"))

    for i, opt in enumerate(options):
        if i == index:
            result.append(("class:highlight", f"> {opt}\n"))
        else:
            result.append(("", f"  {opt}\n"))

    result.append(("", "\nPress Shift+Tab to cycle, Enter to confirm > "))

    return FormattedText(result)


session = PromptSession(key_bindings=keys, style=style)


def confirm_plan():
    """Asks user to confirm, discard, or give feedback for their plan."""
    result = session.prompt(get_prompt)
    if "feedback" in options[index]:
        return result
    elif "auto" in options[index]:
        return "_auto"
    elif "manual" in options[index]:
        return "_manual"
    elif "Discard" in options[index]:
        return "_discard"
    

PLANNER_TOOL_REGISTRY["confirm_plan"] = confirm_plan
