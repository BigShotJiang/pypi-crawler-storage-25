"""
Tool specifications & provider convertion functions
Current tools:
    file_tools.py
        read_file(file_path: str, from_line: int = 0, to_line: int = 100)
"""
from nlsql_coder.app.providers.base import ToolSpecification, ToolSchema, ToolProperty


############### Tools Specifications ###################

read_file_spec = ToolSpecification(
    name="read_file",
    description="Reads a given file starting at from_line ending at to_line and returns its contents.",
    schema=ToolSchema(
        type="object",
        properties={
            "file_path": ToolProperty(
                type="string",
                description="Path to the file to read (relative to the workspace root)."
            ),
            "from_line": ToolProperty(
                type="integer",
                description="Line number to start reading from (1-indexed). Defaults to 1.",
                default=1
            ),
            "to_line": ToolProperty(
                type="integer",
                description="Line number to stop reading at (inclusive). Defaults to 1000.",
                default=1000
            )
        },
        required=["file_path"]
    )
)

write_file_spec = ToolSpecification(
    name="write_file",
    description="Writes the contents to a new file at the given location",
    schema=ToolSchema(
        type="object",
        properties={
            "file_path": ToolProperty(
                type="string",
                description="Path to the file to write (relative to the workspace root (must include file name))."
            ),
            "content": ToolProperty(
                type="string",
                description="The content to write to the file.",
            ),
        },
        required=["file_path", "content"]
    )
)

edit_file_spec = ToolSpecification(
    name="edit_file",
    description=(
        "Apply a precise edit to a source file. "
        "A colorized diff is printed to the terminal before writing. "
        "Use AST targets for Python files when possible — they are more robust than line numbers."
    ),
    schema=ToolSchema(
        properties={
            "filepath": ToolProperty(
                type="string",
                description="Absolute or relative path to the file to edit.",
            ),
            "operation": ToolProperty(
                type="string",
                description=(
                    "One of: replace, insert_before, insert_after, append, prepend. "
                    "replace: swap the targeted lines with content. "
                    "insert_before/after: add content without removing anything. "
                    "append/prepend: add content at end/start of file (no target needed)."
                ),
            ),
            "content": ToolProperty(
                type="string",
                description="The new source text to write. Preserve correct indentation.",
            ),
            "target_type": ToolProperty(
                type="string",
                description=(
                    "One of: line, line_range, content, ast_func, ast_class, ast_method. "
                    "line/line_range: by 1-indexed line number(s). "
                    "content: match an exact string (may span multiple lines). "
                    "ast_func/ast_class/ast_method: locate a Python AST node by name."
                ),
            ),
            "line": ToolProperty(
                type="integer",
                description="1-indexed line number. Required when target_type=line.",
            ),
            "start_line": ToolProperty(
                type="integer",
                description="1-indexed start line (inclusive). Required when target_type=line_range.",
            ),
            "end_line": ToolProperty(
                type="integer",
                description="1-indexed end line (inclusive). Required when target_type=line_range.",
            ),
            "pattern": ToolProperty(
                type="string",
                description="Exact string to locate (first match wins). Required when target_type=content.",
            ),
            "node_name": ToolProperty(
                type="string",
                description="Function, class, or method name. Required for ast_func / ast_class / ast_method.",
            ),
            "class_name": ToolProperty(
                type="string",
                description="Owning class name. Required when target_type=ast_method.",
            ),
            "description": ToolProperty(
                type="string",
                description="Short human-readable label shown in the diff header.",
            ),
        },
        required=["filepath", "operation", "content"],
    ),
)

get_project_tree_spec = ToolSpecification(
    name="get_project_tree",
    description="Gets the current project's file tree.",
    schema=ToolSchema(
        type="object",
        properties={},
        required=[]
    )
)

execute_bash_command_spec = ToolSpecification(
    name="execute_bash_command",
    description="Executes a given bash command from the root of the current workspace and returns stdout, stderr, and the exit code.",
    schema=ToolSchema(
        type="object",
        properties={
            "command": ToolProperty(
                type="string",
                description="The bash command to execute in the workspace root."
            )
        },
        required=["command"]
    )
)

delete_spec = ToolSpecification(
    name="delete",
    description="Deletes a given file or directory.",
    schema=ToolSchema(
        type="object",
        properties={
            "file_path": ToolProperty(
                type="string",
                description="Path to the file or directory to delete."
            )
        },
        required=["file_path"]
    )
)

confirm_plan_spec = ToolSpecification(
    name="confirm_plan",
    description="Asks the user whether to confirm, discard, or give feedback for their plan.",
    schema=ToolSchema(
        type="object",
        properties={},
        required=[]
    )
)
#################################################


########### Conversion functions ##################

def tool_aws_bedrock(tool: ToolSpecification):
    return {
        "toolSpec": {
            "name": tool.name,
            "description": tool.description,
            "inputSchema": {
                "json": tool.schema.serialize()
            }
        }
    }


def tool_azure_openai(tool: ToolSpecification):
    return {
        "type": "function",
        "name": tool.name,
        "description": tool.description,
        "parameters": tool.schema.serialize(),
        "additionalProperties": False
    }
