from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .client import OpenCodeClient
from .exceptions import MCPReadinessError, SessionNotFoundError, ToolNotFoundError
from .models import MCPServer, Session, ToolSchema


@dataclass(slots=True)
class SessionRecord:
    task_id: str
    session_id: str
    parent_session_id: str | None = None
    title: str | None = None


class SessionManager:
    def __init__(self, client: OpenCodeClient):
        self.client = client
        self._registry: dict[str, SessionRecord] = {}

    def create(self, task_id: str, title: str | None = None, parent_session_id: str | None = None) -> Session:
        session = self.client.create_session(title=title, parent_id=parent_session_id)
        self._registry[task_id] = SessionRecord(
            task_id=task_id,
            session_id=session.id,
            parent_session_id=parent_session_id,
            title=title,
        )
        return session

    def reuse_or_create(self, task_id: str, session_id: str | None = None, title: str | None = None) -> Session:
        if session_id:
            for record in self._registry.values():
                if record.session_id == session_id:
                    session = Session(id=session_id, title=title or record.title)
                    self._registry[task_id] = SessionRecord(task_id=task_id, session_id=session.id, title=session.title)
                    return session
            session = self.client.get_session(session_id)
            self._registry[task_id] = SessionRecord(task_id=task_id, session_id=session.id, title=session.title)
            return session
        return self.create(task_id=task_id, title=title)

    def get_record(self, task_id: str) -> SessionRecord:
        if task_id not in self._registry:
            raise SessionNotFoundError(f"No session registered for task {task_id}")
        return self._registry[task_id]

    def link_existing(self, task_id: str, session_id: str, parent_session_id: str | None = None, title: str | None = None) -> None:
        self._registry[task_id] = SessionRecord(
            task_id=task_id,
            session_id=session_id,
            parent_session_id=parent_session_id,
            title=title,
        )

    def fork(self, parent_task_id: str, child_task_id: str, message_id: str | None = None) -> Session:
        parent = self.get_record(parent_task_id)
        session = self.client.fork_session(parent.session_id, message_id=message_id)
        self._registry[child_task_id] = SessionRecord(
            task_id=child_task_id,
            session_id=session.id,
            parent_session_id=parent.session_id,
            title=session.title,
        )
        return session

    def abort(self, task_id: str) -> None:
        record = self.get_record(task_id)
        self.client.abort_session(record.session_id)

    def delete(self, task_id: str) -> None:
        record = self.get_record(task_id)
        self.client.delete_session(record.session_id)
        del self._registry[task_id]

    def list_registry(self) -> list[SessionRecord]:
        return list(self._registry.values())


class ToolManager:
    def __init__(self, client: OpenCodeClient):
        self.client = client
        self._tool_ids: list[str] | None = None
        self._tools_by_model: dict[tuple[str | None, str | None], list[ToolSchema]] = {}

    def get_tool_ids(self, refresh: bool = False) -> list[str]:
        if refresh or self._tool_ids is None:
            self._tool_ids = self.client.list_tool_ids()
        return self._tool_ids

    def get_tools(self, provider: str | None = None, model: str | None = None, refresh: bool = False) -> list[ToolSchema]:
        cache_key = (provider, model)
        if refresh or cache_key not in self._tools_by_model:
            self._tools_by_model[cache_key] = self.client.list_tools(provider=provider, model=model)
        return self._tools_by_model[cache_key]

    def resolve_allowlist(self, tools: list[str] | None, *, strict: bool = False) -> list[str] | None:
        """Return tools filtered to those actually available on the OpenCode server.

        Args:
            tools: list of tool names requested by the caller.
            strict: if True, raise ToolNotFoundError for any tool not available
                    on the server instead of silently ignoring it.
        """
        if tools is None:
            return None
        available = set(self.get_tool_ids())
        resolved = []
        missing = []
        for tool in tools:
            if tool in available:
                resolved.append(tool)
            else:
                missing.append(tool)
        if missing and strict:
            raise ToolNotFoundError(
                f"The following tools are not available on the OpenCode server: {', '.join(missing)}. "
                f"Available tools: {', '.join(sorted(available))}"
            )
        return resolved if resolved else None


class MCPManager:
    def __init__(self, client: OpenCodeClient):
        self.client = client

    def list_servers(self) -> list[MCPServer]:
        return self.client.get_mcp_status()

    def register(self, name: str, config: dict[str, Any]) -> Any:
        return self.client.register_mcp_server(name=name, config=config)

    def ensure_servers(self, required: list[str], configured_servers: dict[str, dict[str, Any]]) -> list[MCPServer]:
        available = {server.name: server for server in self.list_servers()}
        missing = [name for name in required if name not in available]
        for name in missing:
            if name not in configured_servers:
                raise MCPReadinessError(f"Required MCP server '{name}' is unavailable and not configured")
            self.register(name, configured_servers[name])
        refreshed = {server.name: server for server in self.list_servers()}
        still_missing = [name for name in required if name not in refreshed]
        if still_missing:
            raise MCPReadinessError(f"Required MCP servers unavailable after registration: {', '.join(still_missing)}")
        return [refreshed[name] for name in required]
