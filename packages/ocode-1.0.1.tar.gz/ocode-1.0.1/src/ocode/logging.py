from __future__ import annotations

import json
import logging
from typing import Any


def configure_logging(verbose: bool = False) -> None:
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.WARNING,
        format="%(message)s",
    )
    # Always silence httpx request logs unless explicitly in verbose mode
    logging.getLogger("httpx").setLevel(logging.DEBUG if verbose else logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.DEBUG if verbose else logging.WARNING)


def log_event(logger: logging.Logger, event: str, **payload: Any) -> None:
    logger.info(json.dumps({"event": event, **payload}, default=str))
