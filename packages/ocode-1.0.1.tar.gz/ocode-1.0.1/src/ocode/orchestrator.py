from __future__ import annotations

import logging
import uuid
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from typing import Any

from .client import OpenCodeClient
from .config import OpenCodeConfig
from .logging import log_event
from .managers import MCPManager, SessionManager, ToolManager
from .models import ExecutionMetadata, ExecutionResult, MultiAgentResult, StreamEvent, SubtaskTrace


@dataclass(slots=True)
class PlannedStep:
    name: str
    agent: str
    prompt_template: str
    fork_session: bool = True


class TaskPlanner:
    def __init__(self, config: OpenCodeConfig | None = None):
        self.config = config or OpenCodeConfig.from_env()

    def plan(self, prompt: str, strategy: str = "plan-explore-build-review") -> list[PlannedStep]:
        if strategy == "coordinator-specialists-synthesizer":
            return [
                PlannedStep("coordinator", "plan", "Define the execution approach for this task and call out major workstreams:\n\n{prompt}", False),
                PlannedStep("specialist-build", "build", "Implement the most important technical solution for this task:\n\n{prompt}"),
                PlannedStep("specialist-explore", "explore", "Inspect risks, dependencies, and supporting context for this task:\n\n{prompt}"),
                PlannedStep("synthesizer", "build", "Synthesize the specialist outputs into one actionable final result for:\n\n{prompt}", False),
            ]
        return [
            PlannedStep("plan", "plan", "Create a concise execution plan for this task:\n\n{prompt}", False),
            PlannedStep("explore", "explore", "Explore the workspace and relevant context for this task:\n\n{prompt}"),
            PlannedStep("build", "build", "Execute the implementation work for this task:\n\n{prompt}"),
            PlannedStep("review", "plan", "Review the implementation critically and summarize remaining risks for:\n\n{prompt}", False),
        ]


class EventStreamer:
    def __init__(self, client: OpenCodeClient):
        self.client = client

    def stream(self, limit: int | None = None) -> list[StreamEvent]:
        events: list[StreamEvent] = []
        for event in self.client.iter_events():
            events.append(event)
            if limit is not None and len(events) >= limit:
                break
        return events


class SingleAgentRunner:
    def __init__(
        self,
        client: OpenCodeClient | None = None,
        config: OpenCodeConfig | None = None,
        session_manager: SessionManager | None = None,
        tool_manager: ToolManager | None = None,
        mcp_manager: MCPManager | None = None,
    ):
        self.config = config or OpenCodeConfig.from_env()
        self.client = client or OpenCodeClient(self.config)
        self.session_manager = session_manager or SessionManager(self.client)
        self.tool_manager = tool_manager or ToolManager(self.client)
        self.mcp_manager = mcp_manager or MCPManager(self.client)
        self.logger = logging.getLogger(__name__)

    def _scoped_prompt(self, prompt: str) -> str:
        """
        Prepend project path context so the OpenCode server agent knows which
        directory to operate in.  All file/terminal operations are executed on
        the OpenCode server—not on the Python client machine.
        """
        lines = [
            f"Project path (on the OpenCode server): {self.config.project_path}",
            "All file reads/writes, terminal commands, and tool calls must target",
            "this path on the OpenCode server. Do NOT reference paths on the client.",
            "",
            prompt,
        ]
        return "\n".join(lines)

    def run(
        self,
        prompt: str,
        *,
        agent: str | None = None,
        model: str | None = None,
        session_id: str | None = None,
        title: str | None = None,
        tools: list[str] | None = None,
        mcp_servers: list[str] | None = None,
        streaming: bool | None = None,
        system: str | None = None,
        attachments: list[str] | None = None,
    ) -> ExecutionResult:
        task_id = f"task_{uuid.uuid4().hex[:12]}"
        session = self.session_manager.reuse_or_create(task_id, session_id=session_id, title=title or prompt[:80])
        requested_tools = tools if tools is not None else self.config.default_tools
        resolved_tools = self.tool_manager.resolve_allowlist(requested_tools) if requested_tools else None
        logs: list[dict[str, Any]] = []

        if mcp_servers:
            servers = self.mcp_manager.ensure_servers(mcp_servers, self.config.mcp_servers)
            logs.append({"event": "mcp.ready", "servers": [server.name for server in servers]})

        streaming_enabled = streaming if streaming is not None else self.config.streaming
        if streaming_enabled:
            logs.append({"event": "streaming.enabled", "session_id": session.id})

        selected_agent = agent or self.config.default_agent
        log_event(self.logger, "task.run", task_id=task_id, session_id=session.id, agent=selected_agent)
        scoped_prompt = self._scoped_prompt(prompt)
        message = self.client.send_message(
            session.id,
            scoped_prompt,
            agent=selected_agent,
            model=model or self.config.default_model,
            tools=resolved_tools,
            system=system,
            attachments=attachments,
        )
        logs.append({"event": "message.completed", "message_id": message.info.id})
        metadata = ExecutionMetadata(
            task_id=task_id,
            session_id=session.id,
            agent=selected_agent,
            status="completed",
            message_id=message.info.id,
            tool_events=message.tool_events,
            logs=logs,
        )
        return ExecutionResult(output=message.text_output, metadata=metadata, message=message)

    def run_async(
        self,
        prompt: str,
        *,
        agent: str | None = None,
        model: str | None = None,
        session_id: str | None = None,
        title: str | None = None,
        tools: list[str] | None = None,
    ) -> ExecutionMetadata:
        task_id = f"task_{uuid.uuid4().hex[:12]}"
        session = self.session_manager.reuse_or_create(task_id, session_id=session_id, title=title or prompt[:80])
        requested_tools = tools if tools is not None else self.config.default_tools
        resolved_tools = self.tool_manager.resolve_allowlist(requested_tools) if requested_tools else None
        selected_agent = agent or self.config.default_agent
        scoped_prompt = self._scoped_prompt(prompt)
        self.client.prompt_async(
            session.id,
            scoped_prompt,
            agent=selected_agent,
            model=model or self.config.default_model,
            tools=resolved_tools,
        )
        return ExecutionMetadata(task_id=task_id, session_id=session.id, agent=selected_agent, status="submitted")

    def run_shell(
        self,
        command: str,
        *,
        session_id: str,
        agent: str | None = None,
        model: str | None = None,
    ) -> ExecutionResult:
        # Send the command directly to the OpenCode server shell.
        # The server session already has the correct working directory.
        # We intentionally do NOT prepend `cd {client_path}` because that
        # would inject a client-side filesystem path into a server-side shell.
        message = self.client.run_shell(
            session_id,
            command,
            agent=agent or self.config.default_agent,
            model=model or self.config.default_model,
        )
        metadata = ExecutionMetadata(
            task_id=f"shell_{uuid.uuid4().hex[:12]}",
            session_id=session_id,
            agent=agent or self.config.default_agent,
            status="completed",
            message_id=message.info.id,
            tool_events=message.tool_events,
            logs=[{"event": "shell.completed", "command": command}],
        )
        return ExecutionResult(output=message.text_output, metadata=metadata, message=message)


class ResultSynthesizer:
    def synthesize(self, prompt: str, traces: list[SubtaskTrace]) -> str:
        sections = [f"Parent objective: {prompt}", "Subtask results:"]
        for trace in traces:
            sections.append(f"[{trace.agent}] {trace.output}".strip())
        return "\n\n".join(sections)


class MultiAgentRunner:
    def __init__(
        self,
        client: OpenCodeClient | None = None,
        config: OpenCodeConfig | None = None,
        session_manager: SessionManager | None = None,
        tool_manager: ToolManager | None = None,
        mcp_manager: MCPManager | None = None,
        planner: TaskPlanner | None = None,
        synthesizer: ResultSynthesizer | None = None,
    ):
        self.config = config or OpenCodeConfig.from_env()
        self.client = client or OpenCodeClient(self.config)
        self.session_manager = session_manager or SessionManager(self.client)
        self.tool_manager = tool_manager or ToolManager(self.client)
        self.mcp_manager = mcp_manager or MCPManager(self.client)
        self.planner = planner or TaskPlanner(self.config)
        self.synthesizer = synthesizer or ResultSynthesizer()
        self.single_runner = SingleAgentRunner(
            client=self.client,
            config=self.config,
            session_manager=self.session_manager,
            tool_manager=self.tool_manager,
            mcp_manager=self.mcp_manager,
        )

    def run(
        self,
        prompt: str,
        *,
        strategy: str = "plan-explore-build-review",
        session_id: str | None = None,
        title: str | None = None,
        tools: list[str] | None = None,
        mcp_servers: list[str] | None = None,
        parallel: bool = False,
    ) -> MultiAgentResult:
        parent_task_id = f"task_{uuid.uuid4().hex[:12]}"
        parent_session = self.session_manager.reuse_or_create(parent_task_id, session_id=session_id, title=title or prompt[:80])
        if mcp_servers:
            self.mcp_manager.ensure_servers(mcp_servers, self.config.mcp_servers)

        steps = self.planner.plan(prompt, strategy=strategy)
        traces: list[SubtaskTrace] = []

        def execute_step(index: int, step: PlannedStep) -> SubtaskTrace:
            child_task_id = f"{parent_task_id}_{index}_{step.name}"
            child_session = parent_session
            if step.fork_session:
                child_session = self.session_manager.fork(parent_task_id, child_task_id)
            else:
                self.session_manager.link_existing(
                    child_task_id,
                    session_id=parent_session.id,
                    title=parent_session.title,
                )
            result = self.single_runner.run(
                step.prompt_template.format(prompt=prompt),
                agent=step.agent,
                session_id=child_session.id,
                tools=tools,
                title=f"{step.name}: {prompt[:48]}",
            )
            return SubtaskTrace(
                task_id=result.metadata.task_id,
                session_id=result.metadata.session_id,
                agent=result.metadata.agent,
                prompt=step.prompt_template.format(prompt=prompt),
                output=result.output,
                message_id=result.metadata.message_id,
                status=result.metadata.status,
            )

        if parallel:
            with ThreadPoolExecutor(max_workers=min(4, len(steps))) as executor:
                futures = [executor.submit(execute_step, index, step) for index, step in enumerate(steps, start=1)]
                for future in futures:
                    traces.append(future.result())
        else:
            for index, step in enumerate(steps, start=1):
                traces.append(execute_step(index, step))

        output = self.synthesizer.synthesize(prompt, traces)
        metadata = ExecutionMetadata(
            task_id=parent_task_id,
            session_id=parent_session.id,
            agent="multi-agent",
            status="completed",
            logs=[{"event": "multi-agent.completed", "strategy": strategy, "subtasks": len(traces)}],
        )
        return MultiAgentResult(output=output, metadata=metadata, trace=traces)
