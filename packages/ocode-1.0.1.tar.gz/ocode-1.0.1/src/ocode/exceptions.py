class OpenCodeError(Exception):
    """Base error for orchestration failures."""


class OpenCodeHTTPError(OpenCodeError):
    def __init__(self, status_code: int, message: str):
        super().__init__(f"HTTP {status_code}: {message}")
        self.status_code = status_code
        self.message = message


class SessionNotFoundError(OpenCodeError):
    """Raised when referencing a session ID that does not exist."""


class MCPReadinessError(OpenCodeError):
    """Raised when a required MCP server is not available and cannot be registered."""


class TaskTimeoutError(OpenCodeError):
    """Raised when a task execution exceeds the configured timeout."""


class ToolNotFoundError(OpenCodeError):
    """Raised when a requested tool is not available on the OpenCode server."""
