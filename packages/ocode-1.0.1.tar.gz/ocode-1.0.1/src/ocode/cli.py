from __future__ import annotations

import argparse
from dataclasses import asdict, is_dataclass
import json
import os
import time as _time_module
from typing import Any

from . import __version__
from .client import OpenCodeClient
from .config import OpenCodeConfig
from .logging import configure_logging
from .managers import MCPManager, SessionManager, ToolManager
from .orchestrator import EventStreamer, MultiAgentRunner, SingleAgentRunner


# ── runtime helpers ───────────────────────────────────────────────────────────

def _build_runtime(config: OpenCodeConfig) -> dict[str, Any]:
    client = OpenCodeClient(config)
    session_manager = SessionManager(client)
    tool_manager = ToolManager(client)
    mcp_manager = MCPManager(client)
    return {
        "client": client,
        "single": SingleAgentRunner(client=client, config=config, session_manager=session_manager,
                                    tool_manager=tool_manager, mcp_manager=mcp_manager),
        "multi": MultiAgentRunner(client=client, config=config, session_manager=session_manager,
                                  tool_manager=tool_manager, mcp_manager=mcp_manager),
        "session_manager": session_manager,
        "tool_manager": tool_manager,
        "mcp_manager": mcp_manager,
        "event_streamer": EventStreamer(client),
    }


def _serializable(obj: Any) -> Any:
    if is_dataclass(obj):
        return asdict(obj)
    if isinstance(obj, list):
        return [_serializable(i) for i in obj]
    if isinstance(obj, dict):
        return {k: _serializable(v) for k, v in obj.items()}
    return obj


def _print_json(payload: Any) -> None:
    print(json.dumps(_serializable(payload), indent=2))


# ── pretty-print formatters ───────────────────────────────────────────────────

def _fmt_providers(payload: dict) -> str:
    lines = ["Providers:"]
    for p in payload.get("providers", []):
        pid = p.get("id", "")
        pname = p.get("name", pid)
        models = p.get("models", {})
        n = len(models) if isinstance(models, (dict, list)) else 0
        lines.append(f"  • {pid:<18} {pname}  ({n} models)")
    defaults = payload.get("default", {})
    if defaults:
        lines.append("\nDefaults:")
        for alias, ref in defaults.items():
            lines.append(f"  {alias:<22} {ref}")
    return "\n".join(lines)


def _fmt_models(payload: dict, provider_filter: str | None = None) -> str:
    lines = []
    for p in payload.get("providers", []):
        pid = p.get("id", "")
        if provider_filter and pid != provider_filter:
            continue
        pname = p.get("name", pid)
        models = p.get("models", {})
        lines.append(f"\n{pname} ({pid}):")
        if isinstance(models, dict):
            for mid in models:
                lines.append(f"  • {pid}/{mid}")
        elif isinstance(models, list):
            for mid in models:
                lines.append(f"  • {pid}/{mid}")
    return "\n".join(lines).strip() or "No models found."


def _fmt_agents(agents: list) -> str:
    lines = ["Agents:"]
    for a in agents:
        desc = getattr(a, "description", None) or ""
        name = getattr(a, "name", None) or ""
        lines.append(f"  • {a.id:<14} {name:<16} {desc}")
    return "\n".join(lines)


def _fmt_commands(cmds: list) -> str:
    if not cmds:
        return "No slash commands available."
    lines = ["Slash commands:"]
    for c in cmds:
        desc = c.get("description", "") if isinstance(c, dict) else ""
        name = c.get("name", str(c)) if isinstance(c, dict) else str(c)
        lines.append(f"  • /{name:<22} {desc}")
    return "\n".join(lines)


def _fmt_todos(todos: list) -> str:
    if not todos:
        return "No todos."
    lines = []
    for t in todos:
        icon = "✓" if t.get("status") == "completed" else "○"
        lines.append(f"  {icon} [{t.get('status', '?'):<10}] {t.get('content', '')}")
    return "\n".join(lines)


def _fmt_find(matches: list) -> str:
    if not matches:
        return "No matches found."
    lines = []
    for m in matches:
        path = m.get("path", "")
        line_no = m.get("line_number", "")
        content = m.get("lines", "").strip()
        lines.append(f"{path}:{line_no}  {content}")
    return "\n".join(lines)


def _fmt_sessions(sessions: list) -> str:
    if not sessions:
        return "No sessions found."
    lines = []
    lines.append(f"  {'ID':<28} {'TITLE':<30} {'DIRECTORY'}")
    lines.append(f"  {'-'*28} {'-'*30} {'-'*40}")
    for s in sessions:
        sid = getattr(s, "id", "") or ""
        title = getattr(s, "title", None) or "(untitled)"
        directory = getattr(s, "directory", None) or ""
        lines.append(f"  {sid:<28} {title:<30} {directory}")
    lines.append(f"\n  {len(sessions)} session(s)")
    return "\n".join(lines)


def _time_ago(ts: int | float | str | None) -> str:
    """Convert a unix timestamp (ms or s) to a human-readable relative string."""
    if ts is None:
        return "-"
    try:
        t = float(ts)
    except (TypeError, ValueError):
        return str(ts)
    if t > 1e10:   # milliseconds
        t /= 1000
    diff = _time_module.time() - t
    if diff < 60:
        return f"{int(diff)}s ago"
    if diff < 3600:
        return f"{int(diff / 60)}m ago"
    if diff < 86400:
        return f"{int(diff / 3600)}h ago"
    return f"{int(diff / 86400)}d ago"


def _short_path(path: str | None) -> str:
    if not path:
        return ""
    home = os.path.expanduser("~")
    if path.startswith(home):
        return "~" + path[len(home):]
    return path


def _fmt_ps(sessions: list, statuses: dict, all_sessions: bool = False) -> str:
    """Docker-ps-style table of sessions."""
    # Build status lookup: session_id -> status string
    status_map: dict[str, str] = {}
    for sid, state in statuses.items():
        if hasattr(state, "status"):
            status_map[sid] = state.status
        elif isinstance(state, dict):
            status_map[sid] = state.get("status", "idle")

    active_statuses = {"running", "active", "busy", "pending"}

    visible = sessions if all_sessions else [
        s for s in sessions
        if status_map.get(getattr(s, "id", ""), "idle").lower() in active_statuses
    ]

    if not visible:
        if all_sessions:
            return "No sessions."
        return "No active sessions.  Use 'ocode ps -a' to see all sessions."

    lines = [
        f"  {'SESSION ID':<28} {'NAME':<26} {'STATUS':<10} {'PATH':<32} CREATED",
        f"  {'-'*28} {'-'*26} {'-'*10} {'-'*32} -------",
    ]
    for s in visible:
        sid = getattr(s, "id", "") or ""
        name = (getattr(s, "title", None) or "(untitled)")[:25]
        raw = getattr(s, "raw", {}) or {}
        st = status_map.get(sid, "idle")
        path = _short_path(getattr(s, "directory", None) or raw.get("directory", ""))[:31]
        # Try all common timestamp field names (OpenCode uses 'time', 'created', 'updatedAt' etc.)
        ts = (raw.get("time") or raw.get("created") or raw.get("updated")
              or raw.get("createdAt") or raw.get("updatedAt"))
        created = _time_ago(ts)
        lines.append(f"  {sid:<28} {name:<26} {st:<10} {path:<32} {created}")
    lines.append(f"\n  {len(visible)} session(s)")
    return "\n".join(lines)


def _fmt_logs(messages: list, tail: int | None = None) -> str:
    """Format session messages like docker logs output."""
    if not messages:
        return "(no messages)"
    if tail:
        messages = messages[-tail:]
    lines = []
    for msg in messages:
        info = getattr(msg, "info", None)
        role = getattr(info, "role", "?") if info else "?"
        ts = getattr(info, "time", None) if info else None
        time_str = _time_ago(ts) if ts else ""
        text = getattr(msg, "text_output", "") or ""
        if not text.strip():
            continue
        prefix = "\033[36m[user]\033[0m     " if role == "user" else "\033[32m[assistant]\033[0m"
        lines.append(f"{prefix} {time_str}")
        # Indent multiline content
        for line in text.splitlines():
            lines.append(f"  {line}")
        lines.append("")
    return "\n".join(lines).rstrip() if lines else "(no text messages)"


# ── parser ────────────────────────────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="ocode",
        description="ocode — Python CLI for the OpenCode Agent API",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
Examples:
  ocode run "Create a hello world file"             # run task (foreground)
  ocode run -d "Build the REST API"                 # run in background (detached)
  ocode ps                                          # show active sessions
  ocode ps -a                                       # show all sessions
  ocode logs ses_abc123                             # show session output
  ocode logs ses_abc123 --follow                    # stream new messages live
  ocode stop ses_abc123                             # stop running session
  ocode rm ses_abc123                               # delete session
  ocode shell "npm test" --session ses_abc123       # run shell command
  ocode providers && ocode models --current         # inspect model config
""",
    )
    parser.add_argument("--version", "-v", action="version", version=f"ocode {__version__}")
    parser.add_argument("--verbose", action="store_true", help="Enable verbose logging")
    parser.add_argument("--json", dest="output_json", action="store_true",
                        help="Output raw JSON (for run/orchestrate/shell shows full metadata)")
    parser.add_argument("--base-url", metavar="URL", help="Override OpenCode server URL")
    parser.add_argument("--project-path", metavar="PATH", help="Override project path on the server")

    sub = parser.add_subparsers(dest="command", required=True)

    # ── version (subcommand alias) ──────────────────────────────────────
    sub.add_parser("version", help="Show ocode version")

    # ── help (subcommand alias) ─────────────────────────────────────────
    sub.add_parser("help", help="Show this help message")

    # ── run ─────────────────────────────────────────────────────────────
    run_p = sub.add_parser("run", help="Run a single-agent task")
    run_p.add_argument("prompt", help="Task description")
    run_p.add_argument("--agent", "-a", metavar="AGENT",
                       help="Agent to use: build | plan | explore")
    run_p.add_argument("--model", "-m", metavar="MODEL",
                       help="Model override, e.g. anthropic/claude-3-sonnet")
    run_p.add_argument("--session", "--session-id", "-s", dest="session_id",
                       metavar="SESSION_ID", help="Reuse an existing session")
    run_p.add_argument("--title", "-t", metavar="TITLE", help="Session title")
    run_p.add_argument("--tool", action="append", default=[], metavar="TOOL",
                       help="Restrict to specific tool (repeatable)")
    run_p.add_argument("--mcp", action="append", default=[], metavar="MCP",
                       help="Require an MCP server (repeatable)")
    run_p.add_argument("--stream", action="store_true", help="Enable SSE streaming mode")
    run_p.add_argument("--detach", "-d", dest="async_mode", action="store_true",
                       help="Detached mode: start in background, print session ID immediately")
    run_p.add_argument("--async", dest="async_mode", action="store_true",
                       help=argparse.SUPPRESS)  # legacy alias for --detach

    # ── shell ─────────────────────────────────────────────────────────────
    shell_p = sub.add_parser("shell", help="Run a shell command on the OpenCode server")
    shell_p.add_argument("command_text", help="Shell command to run (runs on server, not locally)")
    shell_p.add_argument("--session", "--session-id", "-s", dest="session_id",
                         metavar="SESSION_ID", help="Session to use (creates one if omitted)")
    shell_p.add_argument("--agent", "-a", metavar="AGENT")
    shell_p.add_argument("--model", "-m", metavar="MODEL")

    # ── orchestrate ───────────────────────────────────────────────────────
    orch_p = sub.add_parser("orchestrate", help="Run a multi-agent orchestrated task")
    orch_p.add_argument("prompt", help="Task description")
    orch_p.add_argument("--strategy", default="plan-explore-build-review",
                        choices=["plan-explore-build-review", "coordinator-specialists-synthesizer"],
                        help="Orchestration strategy (default: plan-explore-build-review)")
    orch_p.add_argument("--session", "--session-id", "-s", dest="session_id", metavar="SESSION_ID")
    orch_p.add_argument("--title", "-t", metavar="TITLE")
    orch_p.add_argument("--tool", action="append", default=[], metavar="TOOL")
    orch_p.add_argument("--mcp", action="append", default=[], metavar="MCP")
    orch_p.add_argument("--parallel", action="store_true", help="Run subtasks in parallel")

    # ── sessions ───────────────────────────────────────────────────────────
    ses_p = sub.add_parser("sessions", help="Manage OpenCode sessions")
    ses_sub = ses_p.add_subparsers(dest="sessions_command", required=True)

    ses_sub.add_parser("list", help="List all sessions (JSON)")

    ses_status = ses_sub.add_parser("status", help="Show session status")
    ses_status.add_argument("session_id", nargs="?", help="Specific session (all if omitted)")

    ses_abort = ses_sub.add_parser("abort", help="Abort a running session")
    ses_abort.add_argument("session_id")

    ses_delete = ses_sub.add_parser("delete", help="Delete a session")
    ses_delete.add_argument("session_id")

    ses_fork = ses_sub.add_parser("fork", help="Fork a session into a new one")
    ses_fork.add_argument("session_id")
    ses_fork.add_argument("--message-id", dest="message_id", metavar="MSG_ID",
                          help="Fork at a specific message")

    ses_diff = ses_sub.add_parser("diff", help="Show file diff for a session")
    ses_diff.add_argument("session_id")
    ses_diff.add_argument("--message-id", dest="message_id", metavar="MSG_ID")

    ses_todos = ses_sub.add_parser("todos", help="Show todos for a session")
    ses_todos.add_argument("session_id")

    ses_share = ses_sub.add_parser("share", help="Share a session (returns URL)")
    ses_share.add_argument("session_id")

    ses_unshare = ses_sub.add_parser("unshare", help="Remove session sharing")
    ses_unshare.add_argument("session_id")

    ses_msgs = ses_sub.add_parser("messages", help="List messages in a session (JSON)")
    ses_msgs.add_argument("session_id")

    ses_children = ses_sub.add_parser("children", help="List child sessions (JSON)")
    ses_children.add_argument("session_id")

    # ── tools ──────────────────────────────────────────────────────────────
    tools_p = sub.add_parser("tools", help="Inspect available tools on the server")
    tools_p.add_argument("--ids", action="store_true", help="List tool IDs only")
    tools_p.add_argument("--provider", metavar="PROVIDER")
    tools_p.add_argument("--model", metavar="MODEL")

    # ── mcp ────────────────────────────────────────────────────────────────
    mcp_p = sub.add_parser("mcp", help="Manage MCP servers")
    mcp_sub = mcp_p.add_subparsers(dest="mcp_command", required=True)
    mcp_sub.add_parser("list", help="List active MCP servers (JSON)")
    mcp_reg = mcp_sub.add_parser("register", help="Register an MCP server")
    mcp_reg.add_argument("name", help="Server name")
    mcp_reg.add_argument("config_json", help='Config as JSON string, e.g. \'{"command":"npx","args":["-y","@org/mcp"]}\'')

    # ── providers ──────────────────────────────────────────────────────────
    sub.add_parser("providers", help="List available AI providers")

    # ── models ─────────────────────────────────────────────────────────────
    models_p = sub.add_parser("models", help="List available models")
    models_p.add_argument("--provider", "-p", metavar="PROVIDER", help="Filter by provider ID")
    models_p.add_argument("--details", "-d", action="store_true", help="Include model details")
    models_p.add_argument("--current", "-c", action="store_true",
                          help="Show the currently active model and server defaults")

    # ── agents ─────────────────────────────────────────────────────────────
    agents_p = sub.add_parser("agents", help="List available OpenCode agents")
    agents_p.add_argument("--raw", action="store_true",
                          help="Print raw API response (useful for debugging)")

    # ── commands ───────────────────────────────────────────────────────────
    sub.add_parser("commands", help="List available slash commands")

    # ── files ──────────────────────────────────────────────────────────────
    files_p = sub.add_parser("files", help="List files on the OpenCode server")
    files_p.add_argument("--path", "-p", metavar="PATH",
                         help="Server-side path to list (defaults to OPENCODE_PROJECT_PATH)")

    # ── find ────────────────────────────────────────────────────────────
    find_p = sub.add_parser("find", help="Search file contents on the OpenCode server")
    find_p.add_argument("pattern", help="Search pattern (ripgrep syntax)")
    find_p.add_argument("--raw", action="store_true",
                        help="Print raw API response (useful for debugging)")

    # ── ps ─────────────────────────────────────────────────────────────────
    ps_p = sub.add_parser("ps", help="List sessions (like docker ps)")
    ps_p.add_argument("--all", "-a", dest="all_sessions", action="store_true",
                      help="Show all sessions (default: active only)")

    # ── rm ─────────────────────────────────────────────────────────────────
    rm_p = sub.add_parser("rm", help="Delete a session (like docker rm)")
    rm_p.add_argument("session_id", help="Session ID to delete")
    rm_p.add_argument("--force", "-f", action="store_true",
                      help="Abort first if session is running, then delete")

    # ── stop ───────────────────────────────────────────────────────────────
    stop_p = sub.add_parser("stop", help="Stop a running session (like docker stop)")
    stop_p.add_argument("session_id", help="Session ID to stop")

    # ── logs ───────────────────────────────────────────────────────────────
    logs_p = sub.add_parser("logs", help="Show session output (like docker logs)")
    logs_p.add_argument("session_id", help="Session ID")
    logs_p.add_argument("--follow", "-f", action="store_true",
                        help="Poll for new messages until Ctrl+C")
    logs_p.add_argument("--tail", "-n", type=int, default=None, metavar="N",
                        help="Show only the last N messages")
    logs_p.add_argument("--interval", type=float, default=2.0, metavar="SEC",
                        help="Polling interval in seconds for --follow (default: 2)")

    # ── stream ─────────────────────────────────────────────────────────────
    stream_p = sub.add_parser("stream", help="Read live SSE events from the server")
    stream_p.add_argument("--limit", type=int, default=10, metavar="N",
                          help="Max events to collect (default: 10)")

    return parser


# ── main ──────────────────────────────────────────────────────────────────────

def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    # version / help as subcommands (no server connection needed)
    if args.command == "version":
        print(f"ocode {__version__}")
        return 0
    if args.command == "help":
        parser.print_help()
        return 0

    config = OpenCodeConfig.from_env()
    if args.base_url:
        config.base_url = args.base_url
    if args.project_path:
        config.project_path = args.project_path
    if args.verbose:
        config.verbose = True
    configure_logging(config.verbose)

    runtime = _build_runtime(config)
    client: OpenCodeClient = runtime["client"]
    output_json: bool = args.output_json

    try:
        # ── run ──────────────────────────────────────────────────────────
        if args.command == "run":
            if args.async_mode:
                result = runtime["single"].run_async(
                    args.prompt,
                    agent=args.agent,
                    model=args.model,
                    session_id=args.session_id,
                    title=args.title,
                    tools=args.tool or None,
                )
                if output_json:
                    _print_json(result)
                else:
                    sid = getattr(result, "session_id", None) or ""
                    print(f"Session started (detached): {sid}")
                    if sid:
                        print(f"  ocode logs {sid}          # stream output")
                        print(f"  ocode ps                  # check status")
                        print(f"  ocode stop {sid}    # stop")
                return 0
            result = runtime["single"].run(
                args.prompt,
                agent=args.agent,
                model=args.model,
                session_id=args.session_id,
                title=args.title,
                tools=args.tool or None,
                mcp_servers=args.mcp or None,
                streaming=args.stream,
            )
            if output_json:
                _print_json({"output": result.output, "metadata": result.metadata})
            else:
                print(result.output)
            return 0

        # ── shell ─────────────────────────────────────────────────────────
        if args.command == "shell":
            session_id = args.session_id
            if not session_id:
                session = client.create_session(title="ocode-shell")
                session_id = session.id
                if args.verbose:
                    print(f"Created session: {session_id}")
            result = runtime["single"].run_shell(
                args.command_text,
                session_id=session_id,
                agent=args.agent,
                model=args.model,
            )
            if output_json:
                _print_json(result)
            else:
                print(result.output)
            return 0

        # ── orchestrate ───────────────────────────────────────────────────
        if args.command == "orchestrate":
            result = runtime["multi"].run(
                args.prompt,
                strategy=args.strategy,
                session_id=args.session_id,
                title=args.title,
                tools=args.tool or None,
                mcp_servers=args.mcp or None,
                parallel=args.parallel,
            )
            if output_json:
                _print_json(result)
            else:
                print(result.output)
            return 0

        # ── sessions ──────────────────────────────────────────────────────
        if args.command == "sessions":
            cmd = args.sessions_command

            if cmd == "list":
                sessions = client.list_sessions()
                if output_json:
                    _print_json(sessions)
                else:
                    print(_fmt_sessions(sessions))
                return 0

            if cmd == "status":
                status = client.get_session_status()
                _print_json(status.get(args.session_id) if args.session_id else status)
                return 0

            if cmd == "abort":
                client.abort_session(args.session_id)
                print(f"✓ Aborted {args.session_id}")
                return 0

            if cmd == "delete":
                client.delete_session(args.session_id)
                print(f"✓ Deleted {args.session_id}")
                return 0

            if cmd == "fork":
                session = client.fork_session(args.session_id,
                                              message_id=getattr(args, "message_id", None))
                if output_json:
                    _print_json(session)
                else:
                    print(f"✓ Forked → new session: {session.id}")
                return 0

            if cmd == "diff":
                diff = client.get_session_diff(args.session_id,
                                               message_id=getattr(args, "message_id", None))
                _print_json(diff)
                return 0

            if cmd == "todos":
                todos = client.get_session_todos(args.session_id)
                if output_json:
                    _print_json(todos)
                else:
                    print(_fmt_todos(todos))
                return 0

            if cmd == "share":
                data = client.share_session(args.session_id)
                url = (data or {}).get("share", {}).get("url", "")
                if output_json:
                    _print_json(data)
                else:
                    print(f"✓ Shared: {url}" if url else "✓ Shared (no URL returned)")
                return 0

            if cmd == "unshare":
                client.unshare_session(args.session_id)
                print(f"✓ Unshared {args.session_id}")
                return 0

            if cmd == "messages":
                _print_json(client.list_messages(args.session_id))
                return 0

            if cmd == "children":
                _print_json(client.get_session_children(args.session_id))
                return 0

        # ── tools ─────────────────────────────────────────────────────────
        if args.command == "tools":
            if args.ids:
                ids = client.list_tool_ids()
                if output_json:
                    _print_json(ids)
                else:
                    for tid in ids:
                        print(f"  • {tid}")
            else:
                _print_json(client.list_tools(provider=args.provider, model=args.model))
            return 0

        # ── mcp ───────────────────────────────────────────────────────────
        if args.command == "mcp":
            if args.mcp_command == "list":
                _print_json(runtime["mcp_manager"].list_servers())
                return 0
            if args.mcp_command == "register":
                _print_json(runtime["mcp_manager"].register(args.name, json.loads(args.config_json)))
                return 0

        # ── providers ─────────────────────────────────────────────────────
        if args.command == "providers":
            payload = client.get_provider_config()
            if output_json:
                _print_json(payload)
            else:
                print(_fmt_providers(payload))
            return 0

        # ── models ────────────────────────────────────────────────────────
        if args.command == "models":
            if getattr(args, "current", False):
                payload = client.get_provider_config()
                server_defaults = payload.get("default", {})
                active = config.default_model or "(not set — server will use its default)"
                if output_json:
                    _print_json({
                        "active": active,
                        "server_defaults": server_defaults,
                    })
                else:
                    print(f"Active model (OPENCODE_MODEL):  {active}")
                    if server_defaults:
                        print("\nServer defaults:")
                        for alias, ref in server_defaults.items():
                            marker = "  ◀ active" if ref == active else ""
                            print(f"  {alias:<24} {ref}{marker}")
                return 0
            payload = client.get_provider_config()
            if output_json:
                _print_json(client.list_available_models(include_details=args.details))
            else:
                print(_fmt_models(payload, provider_filter=args.provider))
            return 0


        # ── agents ────────────────────────────────────────────────────────────
        if args.command == "agents":
            if getattr(args, "raw", False):
                _print_json(client._request("GET", "/agent"))
                return 0
            agents = client.list_agents()
            if output_json:
                _print_json(agents)
            else:
                print(_fmt_agents(agents))
            return 0

        # ── commands ──────────────────────────────────────────────────────
        if args.command == "commands":
            cmds = client.list_commands()
            if output_json:
                _print_json(cmds)
            else:
                print(_fmt_commands(cmds))
            return 0

        # ── files ─────────────────────────────────────────────────────────
        if args.command == "files":
            _print_json(client.list_files(path=getattr(args, "path", None)))
            return 0

        # ── find ────────────────────────────────────────────────────────────
        if args.command == "find":
            if getattr(args, "raw", False):
                _print_json(client._request("GET", "/find", params={"pattern": args.pattern}))
                return 0
            matches = client.search(args.pattern)
            if output_json:
                _print_json(matches)
            else:
                print(_fmt_find(matches or []))
            return 0

        # ── stream ────────────────────────────────────────────────────────
        if args.command == "stream":
            _print_json(runtime["event_streamer"].stream(limit=args.limit))
            return 0

        # ── ps ────────────────────────────────────────────────────────────
        if args.command == "ps":
            sessions = client.list_sessions()
            statuses = client.get_session_status()
            if output_json:
                _print_json([{
                    "id": getattr(s, "id", ""),
                    "title": getattr(s, "title", None),
                    "directory": getattr(s, "directory", None),
                    "status": statuses.get(getattr(s, "id", ""), {}).status
                    if hasattr(statuses.get(getattr(s, "id", ""), {}), "status")
                    else statuses.get(getattr(s, "id", ""), {}).get("status", "idle")
                    if isinstance(statuses.get(getattr(s, "id", ""), {}), dict)
                    else "idle",
                } for s in sessions])
            else:
                print(_fmt_ps(sessions, statuses, all_sessions=args.all_sessions))
            return 0

        # ── rm ────────────────────────────────────────────────────────────
        if args.command == "rm":
            if getattr(args, "force", False):
                try:
                    client.abort_session(args.session_id)
                except Exception:
                    pass  # May already be stopped
            client.delete_session(args.session_id)
            print(args.session_id)
            return 0

        # ── stop ──────────────────────────────────────────────────────────
        if args.command == "stop":
            client.abort_session(args.session_id)
            print(args.session_id)
            return 0

        # ── logs ──────────────────────────────────────────────────────────
        if args.command == "logs":
            if args.follow:
                seen_ids: set[str] = set()
                print(f"Streaming logs for {args.session_id} (Ctrl+C to exit)...\n")
                try:
                    while True:
                        messages = client.list_messages(args.session_id)
                        new = [m for m in messages
                               if getattr(getattr(m, "info", None), "id", None) not in seen_ids]
                        if new:
                            print(_fmt_logs(new))
                            for m in new:
                                mid = getattr(getattr(m, "info", None), "id", None)
                                if mid:
                                    seen_ids.add(mid)
                        _time_module.sleep(args.interval)
                except KeyboardInterrupt:
                    print("\nStopped following.")
                return 0
            messages = client.list_messages(args.session_id)
            if output_json:
                _print_json(messages)
            else:
                print(_fmt_logs(messages, tail=args.tail))
            return 0

        return 1

    finally:
        client.close()
