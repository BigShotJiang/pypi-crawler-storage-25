from __future__ import annotations

from dataclasses import asdict, is_dataclass
from typing import Any

from .client import OpenCodeClient
from .config import OpenCodeConfig
from .managers import MCPManager, SessionManager, ToolManager
from .models import ExecutionMetadata, ExecutionResult, Session, StreamEvent
from .orchestrator import EventStreamer, SingleAgentRunner


class Agent:
    """High-level Python interface to the OpenCode Agent API.

    All file operations, terminal commands, and tool executions are delegated
    to the OpenCode server — nothing runs locally on the Python client machine.

    Example::

        from ocode import Agent

        agent = Agent(name="MyAgent")
        reply = agent.run("Create a hello world file")
        print(reply)
    """

    def __init__(
        self,
        name: str = "OpenCodeAgent",
        system_prompt: str | None = None,
        *,
        agent: str | None = None,
        model: str | dict[str, Any] | None = None,
        tools: list[str] | None = None,
        mcp_servers: list[str] | None = None,
        project_path: str | None = None,
        base_url: str | None = None,
        streaming: bool | None = None,
        verbose: bool | None = None,
    ):
        config = OpenCodeConfig.from_env()
        if project_path is not None:
            config.project_path = project_path
        if base_url is not None:
            config.base_url = base_url
        if streaming is not None:
            config.streaming = streaming
        if verbose is not None:
            config.verbose = verbose
        if model is not None:
            config.default_model = model
        if agent is not None:
            config.default_agent = agent
        if tools is not None:
            config.default_tools = tools

        self.name = name
        self.system_prompt = system_prompt
        self.default_mcp_servers = mcp_servers or []
        self.config = config
        self.client = OpenCodeClient(config=config)
        self.session_manager = SessionManager(self.client)
        self.tool_manager = ToolManager(self.client)
        self.mcp_manager = MCPManager(self.client)
        self.runner = SingleAgentRunner(
            client=self.client,
            config=self.config,
            session_manager=self.session_manager,
            tool_manager=self.tool_manager,
            mcp_manager=self.mcp_manager,
        )
        self.event_streamer = EventStreamer(self.client)
        self.session_id: str | None = None

    # ── lifecycle ────────────────────────────────────────────────────────────

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self.client.close()

    def __enter__(self) -> "Agent":
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    # ── model / config helpers ───────────────────────────────────────────────

    def set_model(self, model: str | dict[str, Any] | None) -> None:
        self.config.default_model = model

    # ── task execution ────────────────────────────────────────────────────────

    def run(
        self,
        user_prompt: str,
        *,
        agent: str | None = None,
        model: str | dict[str, Any] | None = None,
        tools: list[str] | None = None,
        mcp_servers: list[str] | None = None,
        session_id: str | None = None,
        return_result: bool = False,
    ) -> str | ExecutionResult:
        """Run a single-agent task. Returns plain text by default.

        Args:
            user_prompt: The task description.
            agent: OpenCode agent to use (``build``, ``plan``, ``explore``).
            model: Model override, e.g. ``"anthropic/claude-3-sonnet"``.
            tools: Restrict allowed tools to this list.
            mcp_servers: MCP servers required for this run.
            session_id: Reuse an existing session instead of creating a new one.
            return_result: Return full ``ExecutionResult`` instead of plain text.
        """
        result = self.runner.run(
            user_prompt,
            agent=agent,
            model=model,
            tools=tools,
            mcp_servers=mcp_servers or self.default_mcp_servers or None,
            session_id=session_id or self.session_id,
            title=self.name,
            system=self.system_prompt,
        )
        self.session_id = result.metadata.session_id
        return result if return_result else result.output

    def run_async(
        self,
        user_prompt: str,
        *,
        agent: str | None = None,
        model: str | dict[str, Any] | None = None,
        tools: list[str] | None = None,
        session_id: str | None = None,
    ) -> ExecutionMetadata:
        """Submit a task without waiting for the result."""
        metadata = self.runner.run_async(
            user_prompt,
            agent=agent,
            model=model,
            tools=tools,
            session_id=session_id or self.session_id,
            title=self.name,
        )
        self.session_id = metadata.session_id
        return metadata

    def run_shell(
        self,
        command: str,
        *,
        agent: str | None = None,
        model: str | dict[str, Any] | None = None,
        session_id: str | None = None,
        return_result: bool = False,
    ) -> str | ExecutionResult:
        """Run a shell command on the OpenCode server (NOT locally).

        The command is executed inside the OpenCode session shell via
        ``POST /session/:id/shell``.
        """
        sid = session_id or self.session_id
        if not sid:
            sid = self.client.create_session(title=self.name).id
            self.session_id = sid
        result = self.runner.run_shell(command, session_id=sid, agent=agent, model=model)
        return result if return_result else result.output

    # ── session management ────────────────────────────────────────────────────

    def list_sessions(self) -> list[Session]:
        """Return all sessions on the OpenCode server."""
        return self.client.list_sessions()

    def get_session_status(self) -> dict:
        """Return status map for all sessions."""
        return self.client.get_session_status()

    def create_session(self, title: str | None = None) -> Session:
        """Create a new session and attach it to this agent."""
        session = self.client.create_session(title=title or self.name)
        self.session_id = session.id
        return session

    def fork_session(self, session_id: str | None = None, message_id: str | None = None) -> Session:
        """Fork the current (or specified) session."""
        sid = session_id or self.session_id
        if not sid:
            raise ValueError("No active session to fork. Pass session_id explicitly.")
        return self.client.fork_session(sid, message_id=message_id)

    def abort_session(self, session_id: str | None = None) -> None:
        """Abort a running session."""
        sid = session_id or self.session_id
        if not sid:
            raise ValueError("No active session to abort.")
        self.client.abort_session(sid)

    def delete_session(self, session_id: str | None = None) -> None:
        """Delete a session."""
        sid = session_id or self.session_id
        if not sid:
            raise ValueError("No session to delete.")
        self.client.delete_session(sid)
        if sid == self.session_id:
            self.session_id = None

    def share_session(self, session_id: str | None = None) -> dict:
        """Share a session and return the share URL."""
        sid = session_id or self.session_id
        if not sid:
            raise ValueError("No active session.")
        return self.client.share_session(sid)

    def unshare_session(self, session_id: str | None = None) -> None:
        """Remove sharing from a session."""
        sid = session_id or self.session_id
        if not sid:
            raise ValueError("No active session.")
        self.client.unshare_session(sid)

    def get_session_diff(self, session_id: str | None = None, message_id: str | None = None) -> Any:
        """Return file diff for a session."""
        sid = session_id or self.session_id
        if not sid:
            raise ValueError("No active session.")
        return self.client.get_session_diff(sid, message_id=message_id)

    def get_todos(self, session_id: str | None = None) -> list[dict]:
        """Return todos for a session."""
        sid = session_id or self.session_id
        if not sid:
            raise ValueError("No active session.")
        return self.client.get_session_todos(sid)

    def get_messages(self, session_id: str | None = None) -> list:
        """Return messages for a session."""
        sid = session_id or self.session_id
        if not sid:
            raise ValueError("No active session.")
        return self.client.list_messages(sid)

    # ── discovery APIs ────────────────────────────────────────────────────────

    def list_models(self, include_details: bool = False) -> list[Any]:
        """Return available models from configured providers."""
        return self.client.list_available_models(include_details=include_details)

    def list_providers(self) -> dict[str, Any]:
        """Return raw provider config from the OpenCode server."""
        return self.client.get_provider_config()

    def list_agents(self) -> list:
        """Return available agent definitions."""
        return self.client.list_agents()

    def list_tools(self, *, ids_only: bool = False, provider: str | None = None, model: str | None = None) -> list:
        """Return available tools on the server."""
        if ids_only:
            return self.client.list_tool_ids()
        return self.client.list_tools(provider=provider, model=model)

    def list_commands(self) -> list:
        """Return available slash commands."""
        return self.client.list_commands()

    def list_mcp_servers(self) -> list:
        """Return active MCP servers."""
        return self.client.get_mcp_status()

    # ── file & search APIs ────────────────────────────────────────────────────

    def list_files(self, path: str | None = None) -> Any:
        """List files on the OpenCode server (not locally)."""
        return self.client.list_files(path=path)

    def get_file_content(self, path: str) -> Any:
        """Read file content from the OpenCode server."""
        return self.client.get_file_content(path)

    def get_file_status(self) -> Any:
        """Return git file status from the OpenCode server."""
        return self.client.get_file_status()

    def find_files(self, query: str, *, item_type: str | None = None, limit: int | None = None) -> Any:
        """Search for files by name on the OpenCode server."""
        return self.client.find_files(query, item_type=item_type, limit=limit)

    def find_symbols(self, query: str) -> Any:
        """Search for code symbols on the OpenCode server."""
        return self.client.find_symbols(query)

    def search(self, pattern: str) -> Any:
        """Search for a pattern inside files on the OpenCode server."""
        return self.client.search(pattern)

    # ── streaming ─────────────────────────────────────────────────────────────

    def stream(self, *, limit: int = 10) -> list[StreamEvent]:
        """Collect SSE events from the OpenCode server."""
        return self.event_streamer.stream(limit=limit)

    # ── utilities ─────────────────────────────────────────────────────────────

    @staticmethod
    def to_dict(value: Any) -> Any:
        if isinstance(value, list):
            return [Agent.to_dict(item) for item in value]
        if is_dataclass(value):
            return asdict(value)
        return value
