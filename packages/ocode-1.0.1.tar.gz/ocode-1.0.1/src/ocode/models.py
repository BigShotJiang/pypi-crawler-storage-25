from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(slots=True)
class MessageInfo:
    id: str
    role: str
    time: int | None = None


@dataclass(slots=True)
class MessagePart:
    type: str
    data: dict[str, Any]

    @property
    def text(self) -> str | None:
        return self.data.get("text")


@dataclass(slots=True)
class Message:
    info: MessageInfo
    parts: list[MessagePart]

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "Message":
        info = payload.get("info", {})
        parts = []
        for part in payload.get("parts", []):
            part_type = part.get("type", "unknown")
            parts.append(MessagePart(type=part_type, data=part))
        return cls(
            info=MessageInfo(
                id=info.get("id", ""),
                role=info.get("role", "assistant"),
                time=info.get("time"),
            ),
            parts=parts,
        )

    @property
    def text_output(self) -> str:
        return "\n".join(part.text for part in self.parts if part.type == "text" and part.text)

    @property
    def tool_events(self) -> list[dict[str, Any]]:
        return [part.data for part in self.parts if part.type in {"tool-call", "tool-result", "tool"}]


@dataclass(slots=True)
class Session:
    id: str
    title: str | None
    directory: str | None = None
    parent_id: str | None = None
    raw: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "Session":
        return cls(
            id=payload["id"],
            title=payload.get("title"),
            directory=payload.get("directory"),
            parent_id=payload.get("parentID") or payload.get("parent_id"),
            raw=payload,
        )


@dataclass(slots=True)
class SessionState:
    session_id: str
    status: str
    active_form: str | None = None


@dataclass(slots=True)
class ToolSchema:
    name: str
    description: str | None
    input_schema: dict[str, Any]


@dataclass(slots=True)
class MCPServer:
    name: str
    status: str | None
    tools: list[str] = field(default_factory=list)
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class AgentDefinition:
    id: str
    name: str | None = None
    description: str | None = None


@dataclass(slots=True)
class StreamEvent:
    type: str
    payload: dict[str, Any]


@dataclass(slots=True)
class ExecutionMetadata:
    task_id: str
    session_id: str
    agent: str
    status: str
    message_id: str | None = None
    tool_events: list[dict[str, Any]] = field(default_factory=list)
    logs: list[dict[str, Any]] = field(default_factory=list)


@dataclass(slots=True)
class ExecutionResult:
    output: str
    metadata: ExecutionMetadata
    message: Message | None = None


@dataclass(slots=True)
class SubtaskTrace:
    task_id: str
    session_id: str
    agent: str
    prompt: str
    output: str
    message_id: str | None
    status: str


@dataclass(slots=True)
class MultiAgentResult:
    output: str
    metadata: ExecutionMetadata
    trace: list[SubtaskTrace]
