from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


DEFAULT_BASE_URL = "http://localhost:4096"
DEFAULT_AGENT = "build"
DEFAULT_TIMEOUT_SECONDS = 120.0
DEFAULT_MCP_CONFIG = "mcp.json"


def load_environment_file(path: str | Path = ".env") -> None:
    env_path = Path(path)
    if not env_path.exists():
        return
    for raw_line in env_path.read_text().splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        os.environ.setdefault(key, value)


def load_json_file(path: str | Path) -> dict[str, Any]:
    json_path = Path(path)
    if not json_path.exists():
        return {}
    return json.loads(json_path.read_text())


@dataclass(slots=True)
class RetryPolicy:
    attempts: int = 3
    backoff_seconds: float = 0.5


@dataclass(slots=True)
class OpenCodeConfig:
    base_url: str = DEFAULT_BASE_URL
    project_path: str = ""
    default_model: str | None = None
    default_agent: str = DEFAULT_AGENT
    streaming: bool = False
    verbose: bool = False
    timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS
    retry_policy: RetryPolicy = field(default_factory=RetryPolicy)
    default_tools: list[str] = field(default_factory=list)
    mcp_servers: dict[str, dict[str, Any]] = field(default_factory=dict)
    mcp_config_path: str = DEFAULT_MCP_CONFIG

    @classmethod
    def from_env(cls) -> "OpenCodeConfig":
        load_environment_file(".env")
        load_environment_file(".environment")
        base_url = os.getenv("OPENCODE_SERVER") or os.getenv("OPENCODE_BASE_URL") or DEFAULT_BASE_URL
        project_path = os.getenv("OPENCODE_PROJECT_PATH", "").strip()
        if not project_path:
            raise ValueError("OPENCODE_PROJECT_PATH is required in .env")
        default_model = os.getenv("OPENCODE_MODEL")
        default_agent = os.getenv("OPENCODE_AGENT", DEFAULT_AGENT)
        streaming = os.getenv("OPENCODE_STREAMING", "false").lower() == "true"
        verbose = os.getenv("OPENCODE_VERBOSE", "false").lower() == "true"
        timeout_seconds = float(os.getenv("OPENCODE_TIMEOUT", str(DEFAULT_TIMEOUT_SECONDS)))
        attempts = int(os.getenv("OPENCODE_RETRY_ATTEMPTS", "3"))
        backoff_seconds = float(os.getenv("OPENCODE_RETRY_BACKOFF", "0.5"))
        tools = [tool for tool in os.getenv("OPENCODE_TOOLS", "").split(",") if tool]
        mcp_config_path = os.getenv("OPENCODE_MCP_CONFIG", DEFAULT_MCP_CONFIG)
        mcp_servers = load_json_file(mcp_config_path).get("servers", {})
        return cls(
            base_url=base_url,
            project_path=project_path,
            default_model=default_model,
            default_agent=default_agent,
            streaming=streaming,
            verbose=verbose,
            timeout_seconds=timeout_seconds,
            retry_policy=RetryPolicy(attempts=attempts, backoff_seconds=backoff_seconds),
            default_tools=tools,
            mcp_servers=mcp_servers,
            mcp_config_path=mcp_config_path,
        )

    @classmethod
    def from_file(cls, path: str | Path) -> "OpenCodeConfig":
        data = json.loads(Path(path).read_text())
        retry_data = data.get("retry_policy", {})
        return cls(
            base_url=data.get("base_url", DEFAULT_BASE_URL),
            project_path=data.get("project_path", ""),
            default_model=data.get("default_model"),
            default_agent=data.get("default_agent", DEFAULT_AGENT),
            streaming=data.get("streaming", False),
            verbose=data.get("verbose", False),
            timeout_seconds=data.get("timeout_seconds", DEFAULT_TIMEOUT_SECONDS),
            retry_policy=RetryPolicy(
                attempts=retry_data.get("attempts", 3),
                backoff_seconds=retry_data.get("backoff_seconds", 0.5),
            ),
            default_tools=data.get("default_tools", []),
            mcp_servers=data.get("mcp_servers", {}),
            mcp_config_path=data.get("mcp_config_path", DEFAULT_MCP_CONFIG),
        )
