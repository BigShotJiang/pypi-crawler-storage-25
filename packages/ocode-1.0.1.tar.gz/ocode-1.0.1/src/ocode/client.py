from __future__ import annotations

import json
import os
import time
from collections.abc import Iterator
from typing import Any

import httpx

from .config import OpenCodeConfig
from .exceptions import OpenCodeHTTPError
from .models import AgentDefinition, MCPServer, Message, Session, SessionState, StreamEvent, ToolSchema


def _normalize_tools(tools: list[str] | dict[str, Any] | None) -> dict[str, Any] | None:
    if tools is None:
        return None
    if isinstance(tools, dict):
        return tools
    return {tool: True for tool in tools}


def _normalize_model(model: str | dict[str, Any] | None) -> dict[str, Any] | None:
    if model is None:
        return None
    if isinstance(model, dict):
        return model
    if "/" in model:
        provider_id, model_id = model.split("/", 1)
        return {"providerID": provider_id, "modelID": model_id}
    return {"modelID": model}


class OpenCodeClient:
    def __init__(self, config: OpenCodeConfig | None = None, http_client: httpx.Client | None = None):
        self.config = config or OpenCodeConfig.from_env()
        self._client = http_client or httpx.Client(
            base_url=self.config.base_url,
            timeout=self.config.timeout_seconds,
        )

    def close(self) -> None:
        self._client.close()

    def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        last_error: Exception | None = None
        for attempt in range(1, self.config.retry_policy.attempts + 1):
            try:
                response = self._client.request(method, path, **kwargs)
                if response.status_code >= 400:
                    detail = response.text
                    try:
                        payload = response.json()
                        detail = payload.get("error", detail)
                    except json.JSONDecodeError:
                        pass
                    raise OpenCodeHTTPError(response.status_code, detail)
                if response.status_code == 204:
                    return None
                if not response.content:
                    return None
                return response.json()
            except (httpx.HTTPError, OpenCodeHTTPError) as exc:
                last_error = exc
                if attempt == self.config.retry_policy.attempts:
                    raise
                time.sleep(self.config.retry_policy.backoff_seconds * attempt)
        if last_error:
            raise last_error
        return None

    def list_sessions(self) -> list[Session]:
        return [Session.from_dict(item) for item in self._request("GET", "/session")]

    def create_session(self, title: str | None = None, parent_id: str | None = None) -> Session:
        payload = {}
        if title:
            payload["title"] = title
        if parent_id:
            payload["parentID"] = parent_id
        return Session.from_dict(self._request("POST", "/session", json=payload))

    def get_session(self, session_id: str) -> Session:
        return Session.from_dict(self._request("GET", f"/session/{session_id}"))

    def update_session(self, session_id: str, **fields: Any) -> Session:
        return Session.from_dict(self._request("PATCH", f"/session/{session_id}", json=fields))

    def delete_session(self, session_id: str) -> None:
        self._request("DELETE", f"/session/{session_id}")

    def abort_session(self, session_id: str) -> None:
        self._request("POST", f"/session/{session_id}/abort")

    def fork_session(self, session_id: str, message_id: str | None = None) -> Session:
        payload = {"messageID": message_id} if message_id else {}
        return Session.from_dict(self._request("POST", f"/session/{session_id}/fork", json=payload))

    def get_session_children(self, session_id: str) -> list[Session]:
        return [Session.from_dict(item) for item in self._request("GET", f"/session/{session_id}/children")]

    def get_session_todos(self, session_id: str) -> list[dict[str, Any]]:
        return self._request("GET", f"/session/{session_id}/todo")

    def share_session(self, session_id: str) -> dict[str, Any]:
        return self._request("POST", f"/session/{session_id}/share")

    def unshare_session(self, session_id: str) -> None:
        self._request("DELETE", f"/session/{session_id}/share")

    def get_session_diff(self, session_id: str, message_id: str | None = None) -> Any:
        params: dict[str, Any] = {}
        if message_id:
            params["messageID"] = message_id
        return self._request("GET", f"/session/{session_id}/diff", params=params)

    def revert_message(self, session_id: str, message_id: str, part_id: str | None = None) -> Any:
        payload: dict[str, Any] = {"messageID": message_id}
        if part_id:
            payload["partID"] = part_id
        return self._request("POST", f"/session/{session_id}/revert", json=payload)

    def get_session_status(self) -> dict[str, SessionState]:
        payload = self._request("GET", "/session/status")
        return {
            session_id: SessionState(
                session_id=session_id,
                status=details.get("status", "unknown"),
                active_form=details.get("activeForm"),
            )
            for session_id, details in payload.items()
        }

    def list_messages(self, session_id: str) -> list[Message]:
        return [Message.from_dict(item) for item in self._request("GET", f"/session/{session_id}/message")]

    def get_message(self, session_id: str, message_id: str) -> Message:
        return Message.from_dict(self._request("GET", f"/session/{session_id}/message/{message_id}"))

    def send_message(
        self,
        session_id: str,
        prompt: str,
        *,
        agent: str | None = None,
        model: str | dict[str, Any] | None = None,
        tools: list[str] | dict[str, Any] | None = None,
        system: str | None = None,
        message_id: str | None = None,
        attachments: list[str] | None = None,
        no_reply: bool = False,
    ) -> Message:
        parts: list[dict[str, Any]] = [{"type": "text", "text": prompt}]
        for attachment in attachments or []:
            parts.append({"type": "attach", "path": attachment})
        payload: dict[str, Any] = {"parts": parts, "noReply": no_reply}
        if agent:
            payload["agent"] = agent
        normalized_model = _normalize_model(model)
        if normalized_model:
            payload["model"] = normalized_model
        normalized_tools = _normalize_tools(tools)
        if normalized_tools:
            payload["tools"] = normalized_tools
        if system:
            payload["system"] = system
        if message_id:
            payload["messageID"] = message_id
        return Message.from_dict(self._request("POST", f"/session/{session_id}/message", json=payload))

    def prompt_async(
        self,
        session_id: str,
        prompt: str,
        *,
        agent: str | None = None,
        model: str | dict[str, Any] | None = None,
        tools: list[str] | dict[str, Any] | None = None,
    ) -> None:
        payload: dict[str, Any] = {"parts": [{"type": "text", "text": prompt}]}
        if agent:
            payload["agent"] = agent
        normalized_model = _normalize_model(model)
        if normalized_model:
            payload["model"] = normalized_model
        normalized_tools = _normalize_tools(tools)
        if normalized_tools:
            payload["tools"] = normalized_tools
        self._request("POST", f"/session/{session_id}/prompt_async", json=payload)

    def run_command(self, session_id: str, command: str, arguments: dict[str, Any] | None = None) -> Any:
        return self._request(
            "POST",
            f"/session/{session_id}/command",
            json={"command": command, "arguments": arguments or {}},
        )

    def run_shell(
        self,
        session_id: str,
        command: str,
        *,
        agent: str | None = None,
        model: str | dict[str, Any] | None = None,
    ) -> Message:
        payload = {"command": command}
        if agent:
            payload["agent"] = agent
        normalized_model = _normalize_model(model)
        if normalized_model:
            payload["model"] = normalized_model
        return Message.from_dict(self._request("POST", f"/session/{session_id}/shell", json=payload))

    def list_tool_ids(self) -> list[str]:
        payload = self._request("GET", "/experimental/tool/ids")
        if isinstance(payload, list):
            return payload
        return payload.get("ids", [])

    def list_tools(self, provider: str | None = None, model: str | None = None) -> list[ToolSchema]:
        params = {}
        if provider:
            params["provider"] = provider
        if model:
            params["model"] = model
        payload = self._request("GET", "/experimental/tool", params=params)
        return [
            ToolSchema(
                name=item["name"],
                description=item.get("description"),
                input_schema=item.get("inputSchema", {}),
            )
            for item in payload.get("tools", [])
        ]

    def list_files(self, path: str | None = None) -> Any:
        # Always use the server-side project path; never fall back to os.getcwd()
        server_path = path or self.config.project_path
        if not server_path:
            raise ValueError("path is required: set OPENCODE_PROJECT_PATH or pass path explicitly")
        return self._request("GET", "/file", params={"path": server_path})

    def get_file_content(self, path: str) -> Any:
        # Paths are resolved server-side; send as-is. If relative, OpenCode resolves
        # against the session's working directory on the server.
        return self._request("GET", "/file/content", params={"path": path})

    def get_file_status(self) -> Any:
        return self._request("GET", "/file/status")

    def find_files(
        self,
        query: str,
        *,
        item_type: str | None = None,
        directory: str | None = None,
        limit: int | None = None,
    ) -> Any:
        params: dict[str, Any] = {"query": query}
        if item_type:
            params["type"] = item_type
        # Use server-side project path; never resolve locally
        server_dir = directory or self.config.project_path
        if server_dir:
            params["directory"] = server_dir
        if limit is not None:
            params["limit"] = limit
        return self._request("GET", "/find/file", params=params)

    def find_symbols(self, query: str) -> Any:
        return self._request("GET", "/find/symbol", params={"query": query})

    def search(self, pattern: str) -> list[Any]:
        raw = self._request("GET", "/find", params={"pattern": pattern})
        # Normalise: API may return a list directly or wrap it in a dict key
        if isinstance(raw, list):
            return raw
        if isinstance(raw, dict):
            # Try common wrapper keys
            for key in ("results", "matches", "items", "data"):
                if key in raw:
                    return raw[key]
            # Dict of path->matches style (some ripgrep APIs)
            items = []
            for path, path_matches in raw.items():
                if isinstance(path_matches, list):
                    for m in path_matches:
                        if isinstance(m, dict):
                            m.setdefault("path", path)
                        items.append(m)
                else:
                    items.append({"path": path, "lines": str(path_matches)})
            return items
        return []

    def get_mcp_status(self) -> list[MCPServer]:
        payload = self._request("GET", "/mcp")
        return [
            MCPServer(name=name, status=details.get("status"), tools=details.get("tools", []), raw=details)
            for name, details in payload.items()
        ]

    def register_mcp_server(self, name: str, config: dict[str, Any]) -> Any:
        return self._request("POST", "/mcp", json={"name": name, "config": config})

    def list_commands(self) -> list[Any]:
        raw = self._request("GET", "/command")
        if isinstance(raw, dict):
            return raw.get("commands") or raw.get("items") or list(raw.values())
        return raw or []

    def get_current_path(self) -> Any:
        return self._request("GET", "/path")

    def get_current_project(self) -> Any:
        return self._request("GET", "/project/current")

    def list_agents(self) -> list[AgentDefinition]:
        raw = self._request("GET", "/agent")
        # API may return a list directly, or a dict like {"agents": [...]}
        if isinstance(raw, dict):
            items = raw.get("agents") or raw.get("items") or list(raw.values())
        else:
            items = raw or []
        result: list[AgentDefinition] = []
        for item in items:
            if not isinstance(item, dict):
                # scalar value — treat it as an ID string
                result.append(AgentDefinition(id=str(item), name=str(item)))
                continue
            # Try several common field names for the agent ID
            agent_id = (
                item.get("id")
                or item.get("agentID")
                or item.get("agent_id")
                or item.get("name")
                or item.get("slug")
                or "unknown"
            )
            result.append(AgentDefinition(
                id=agent_id,
                name=item.get("name") or item.get("title") or agent_id,
                description=item.get("description") or item.get("desc"),
            ))
        return result

    def get_provider_config(self) -> dict[str, Any]:
        return self._request("GET", "/config/providers")

    def list_available_models(self, include_details: bool = False) -> list[Any]:
        payload = self.get_provider_config()
        models: list[Any] = []
        for provider in payload.get("providers", []):
            if not self._provider_is_ready(provider):
                continue
            provider_id = provider.get("id", "")
            for model_id, details in provider.get("models", {}).items():
                model_ref = f"{provider_id}/{model_id}"
                if include_details:
                    models.append(
                        {
                            "provider": provider_id,
                            "model": model_id,
                            "ref": model_ref,
                            "name": details.get("name", model_id),
                            "status": details.get("status"),
                            "context_window": details.get("limit", {}).get("context"),
                            "raw": details,
                        }
                    )
                else:
                    models.append(model_ref)
        return models

    @staticmethod
    def _provider_is_ready(provider: dict[str, Any]) -> bool:
        env_keys = provider.get("env", [])
        options = provider.get("options", {})
        api_key = options.get("apiKey")
        if isinstance(api_key, str) and api_key.strip():
            return True
        if env_keys and all(os.getenv(key) for key in env_keys):
            return True
        return not env_keys

    def iter_events(self) -> Iterator[StreamEvent]:
        with self._client.stream("GET", "/event", headers={"Accept": "text/event-stream"}) as response:
            response.raise_for_status()
            for line in response.iter_lines():
                if not line:
                    continue
                if line.startswith("data:"):
                    payload = json.loads(line[5:].strip())
                    yield StreamEvent(type=payload.get("type", "message"), payload=payload.get("payload", {}))
