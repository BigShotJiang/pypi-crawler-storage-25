# OpenCode Orchestrator

`opencode-orchestrator` is a Python 3.11+ client wrapper for the OpenCode server. The main API is a simple `Agent` class; defaults come from `.env`, MCP definitions come from `mcp.json`, and file or shell work runs on the OpenCode server inside the configured project path.

## Features

- Defaults loaded from `.env`
- MCP server definitions loaded from `mcp.json`
- Required `OPENCODE_PROJECT_PATH` for project-scoped file and shell operations
- Simple `Agent` wrapper for server-side execution
- File, terminal, tool, streaming, and MCP usage through the OpenCode server
- Optional lower-level client and runner APIs if needed
- Shell execution via `POST /session/:id/shell`
- Optional SSE event streaming via `GET /event`
- Live examples for running against a real OpenCode server

## Install

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .
```

## Configuration

Load configuration from `.env`. MCP server definitions are loaded from `mcp.json`.

The included `.env` file sets:

```bash
OPENCODE_SERVER=http://localhost:4096
OPENCODE_PROJECT_PATH=/absolute/path/to/project
OPENCODE_MODEL=openai/gpt-5.4-mini
```

`OPENCODE_PROJECT_PATH` is required. The client uses it as the default scope for file calls and prefixes shell commands with `cd <project_path> && ...` so the code can be run from any local directory while still operating inside the intended OpenCode project.

## Minimal Usage

```python
from opencode_orchestrator import Agent

agent = Agent(
    name="MainAgent",
    system_prompt="You are a highly capable AI assistant that uses the OpenCode server.",
)

reply = agent.run(
    user_prompt="Who are you and what time is it? Do not use tools."
)
print(reply)

agent.close()
```

If you want tool access and full metadata instead of only the text response:

```python
from opencode_orchestrator import Agent

agent = Agent(agent="explore", tools=["glob", "read"])
result = agent.run("Summarize this project.", return_result=True)
print(result.output)
print(result.metadata.session_id)
agent.close()
```

Terminal execution is also minimal:

```python
from opencode_orchestrator import Agent

agent = Agent(name="TerminalAgent")
result = agent.run_shell("pwd && ls", return_result=True)
print(result.metadata.tool_events)
agent.close()
```

Available models can be listed from the already usable provider config only:

```python
from opencode_orchestrator import Agent

agent = Agent()
print(agent.list_models())
agent.close()
```

You can also pass a custom model directly, either as the default for the agent or per call:

```python
from opencode_orchestrator import Agent

agent = Agent(model="openai/gpt-5.4")
reply = agent.run("Reply in one line.")

other = agent.run(
    "Reply in one line with a different model.",
    model="openai/gpt-5.4-mini",
)

agent.close()
```

## Live Examples

These examples are intended to run against a real OpenCode server at `http://localhost:4096`.

Simple usage:

```bash
.venv/bin/python examples/simple_usage.py
```

Tool usage:

```bash
.venv/bin/python examples/tool_usage.py
```

Multiple agents:

```bash
.venv/bin/python examples/multi_agent_usage.py
```

File operations:

```bash
.venv/bin/python examples/file_operations.py
```

Terminal operations:

```bash
.venv/bin/python examples/terminal_operations.py
```

Streaming:

```bash
.venv/bin/python examples/streaming_usage.py
```

## CLI Usage

Run a single task:

```bash
opencode-orchestrator run "Create a release checklist" --agent plan
```

Run a multi-agent task:

```bash
opencode-orchestrator orchestrate "Implement and review a feature" --parallel
```

Inspect sessions:

```bash
opencode-orchestrator sessions list
opencode-orchestrator sessions status
opencode-orchestrator sessions abort ses_123
```

Inspect tools and MCP servers:

```bash
opencode-orchestrator tools --ids
opencode-orchestrator mcp list
```

Run a shell command through OpenCode:

```bash
opencode-orchestrator shell ses_123 "pytest -q"
```

Read a few streaming events:

```bash
opencode-orchestrator stream --limit 5
```

## Notes

- Defaults are taken from `.env` unless you override fields directly in `Agent(...)` or `OpenCodeConfig`.
- MCP registration settings come from `mcp.json`.
- Tool allowlists are filtered against the live tool IDs reported by the server.
- `Agent.run()` returns plain text by default so the common case stays minimal.
- `Agent.list_models()` filters the server provider config down to models that are directly usable with the currently configured credentials.
