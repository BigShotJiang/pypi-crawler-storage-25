from dataclasses import dataclass, field


@dataclass
class Entitlement:
    tool_id: str
    expires_at: int  # unix timestamp


@dataclass
class TokenPayload:
    sub: str
    exp: int
    iat: int
    jti: str
    entitlements: list[Entitlement] = field(default_factory=list)
    role: str | None = None
    is_admin: bool = False

    def has_tool_access(self, tool_id: str | int) -> bool:
        import time

        now = int(time.time())
        tool_id_str = str(tool_id)
        return any((e.tool_id == tool_id_str and e.expires_at > now) for e in self.entitlements)
