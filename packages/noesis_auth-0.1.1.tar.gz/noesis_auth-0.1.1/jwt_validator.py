import asyncio
import time
import logging
from typing import Any

import httpx
from jose import jwt, JWTError, ExpiredSignatureError
from jose.constants import ALGORITHMS

logger = logging.getLogger("auth_sdk")


class JWTValidator:
    """Validates JWTs using JWKS fetched from the Auth Center.

    Supports RS256 (via JWKS) and HS256 (via shared secret).
    When using HS256, pass the shared secret via ``hs256_secret``.
    """

    def __init__(
        self,
        jwks_url: str,
        algorithm: str = "RS256",
        cache_ttl: int = 21600,
        hs256_secret: str | None = None,
    ):
        self.jwks_url = jwks_url
        self.algorithm = algorithm
        self.cache_ttl = cache_ttl  # default 6 hours
        self.hs256_secret = hs256_secret
        self._jwks: dict[str, Any] | None = None
        self._jwks_fetched_at: float = 0

    async def _fetch_jwks(self) -> dict:
        """Fetch JWKS from the auth server with one retry on failure."""
        last_error: Exception | None = None
        for attempt in range(2):
            try:
                async with httpx.AsyncClient() as client:
                    resp = await client.get(self.jwks_url, timeout=10)
                    resp.raise_for_status()
                    return resp.json()
            except Exception as e:
                last_error = e
                if attempt == 0:
                    logger.warning("JWKS fetch attempt %d failed: %s, retrying...", attempt + 1, e)
                    await asyncio.sleep(1)
        raise RuntimeError(f"Failed to fetch JWKS from {self.jwks_url}: {last_error}") from last_error

    async def get_jwks(self) -> dict:
        now = time.time()
        if self._jwks is None or (now - self._jwks_fetched_at) > self.cache_ttl:
            try:
                self._jwks = await self._fetch_jwks()
                self._jwks_fetched_at = now
                logger.info("JWKS refreshed from %s", self.jwks_url)
            except Exception as e:
                if self._jwks is not None:
                    logger.warning("Failed to refresh JWKS, using cached: %s", e)
                else:
                    raise RuntimeError(f"Cannot validate tokens: JWKS unavailable from {self.jwks_url}") from e
        return self._jwks

    async def validate(self, token: str) -> dict:
        """Validate JWT signature and expiry. Returns decoded payload.

        Auto-detects the algorithm from the JWT header:
        - If alg=HS256 and hs256_secret is configured → symmetric validation
        - If alg=RS256 → asymmetric validation via JWKS
        - Falls back to configured self.algorithm if header detection fails
        """
        # Auto-detect algorithm from token header
        try:
            unverified_header = jwt.get_unverified_header(token)
            token_alg = unverified_header.get("alg", self.algorithm)
        except JWTError:
            token_alg = self.algorithm

        if token_alg == "HS256" and self.hs256_secret:
            # Symmetric validation — no JWKS needed
            try:
                payload = jwt.decode(
                    token,
                    self.hs256_secret,
                    algorithms=["HS256"],
                    options={"verify_aud": False},
                )
                return payload
            except ExpiredSignatureError:
                raise ValueError("Token has expired")
            except JWTError as e:
                raise ValueError(f"Token validation failed: {e}") from e

        # Asymmetric validation via JWKS
        jwks = await self.get_jwks()

        # If JWKS returns empty keys, fail explicitly (do NOT silently fall back to HS256)
        if not jwks.get("keys"):
            raise ValueError(
                "JWKS endpoint returned no keys. Cannot validate RS256 token. "
                "Check that the JWKS endpoint is correctly configured."
            )

        try:
            payload = jwt.decode(
                token,
                jwks,
                algorithms=[self.algorithm],
                options={"verify_aud": False},
            )
            return payload
        except ExpiredSignatureError:
            raise ValueError("Token has expired")
        except JWTError as e:
            raise ValueError(f"Token validation failed: {e}") from e
