from auth_sdk.client import AuthClient, AuthError, TokenResponse, RedeemResult, IntrospectResult, PKCEPair
from auth_sdk.jwt_validator import JWTValidator
from auth_sdk.models import Entitlement, TokenPayload

try:
    from auth_sdk.fastapi_middleware import AuthMiddleware, require_tool_access
except ImportError:
    # FastAPI is an optional dependency
    AuthMiddleware = None  # type: ignore[assignment, misc]
    require_tool_access = None  # type: ignore[assignment]

__version__ = "0.1.0"

__all__ = [
    "__version__",
    "AuthClient",
    "AuthError",
    "AuthMiddleware",
    "IntrospectResult",
    "JWTValidator",
    "PKCEPair",
    "RedeemResult",
    "TokenPayload",
    "TokenResponse",
    "Entitlement",
    "require_tool_access",
]
