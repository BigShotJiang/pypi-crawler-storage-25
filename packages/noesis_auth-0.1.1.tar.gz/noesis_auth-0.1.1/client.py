"""AuthClient — HTTP client for interacting with the ERP platform APIs.

Implements TODO item B1 — Python SDK AuthClient (mirrors TypeScript SDK).

Provides:
  - build_authorize_url() — OAuth2 authorization URL builder
  - exchange_code() — exchange auth code for tokens
  - refresh_token() — refresh access token
  - redeem_code() — redeem activation code
  - introspect() — introspect token
  - generate_pkce() — generate PKCE code verifier + challenge
"""

import base64
import hashlib
import os
from dataclasses import dataclass
from urllib.parse import urlencode

import httpx

from auth_sdk.models import TokenPayload


class AuthError(Exception):
    def __init__(self, message: str, code: str = "UNKNOWN", status: int = 0):
        super().__init__(message)
        self.code = code
        self.status = status


@dataclass
class TokenResponse:
    access_token: str
    token_type: str
    expires_in: int
    refresh_token: str = ""


@dataclass
class RedeemResult:
    tool_id: str
    tool_name: str
    duration_days: int
    expires_at: str  # ISO datetime string from API
    message: str = ""
    token_refresh_required: bool = True
    new_access_token: str | None = None


@dataclass
class IntrospectResult:
    active: bool
    sub: str | None = None
    exp: int | None = None
    iat: int | None = None
    jti: str | None = None
    entitlements: list[dict] | None = None


@dataclass
class PKCEPair:
    code_verifier: str
    code_challenge: str


def _base64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


class AuthClient:
    """HTTP client for AIToolCenter platform APIs."""

    def __init__(self, base_url: str, timeout: float = 10.0):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    @staticmethod
    def generate_pkce() -> PKCEPair:
        """Generate a PKCE code verifier and S256 challenge."""
        verifier_bytes = os.urandom(32)
        code_verifier = _base64url_encode(verifier_bytes)
        digest = hashlib.sha256(code_verifier.encode("ascii")).digest()
        code_challenge = _base64url_encode(digest)
        return PKCEPair(code_verifier=code_verifier, code_challenge=code_challenge)

    def build_authorize_url(
        self,
        client_id: str,
        redirect_uri: str,
        state: str | None = None,
        code_challenge: str | None = None,
    ) -> str:
        """Build the OAuth2 authorization URL."""
        params = {
            "response_type": "code",
            "client_id": client_id,
            "redirect_uri": redirect_uri,
        }
        if state:
            params["state"] = state
        if code_challenge:
            params["code_challenge"] = code_challenge
            params["code_challenge_method"] = "S256"
        return f"{self.base_url}/oauth/authorize?{urlencode(params)}"

    async def exchange_code(
        self,
        code: str,
        redirect_uri: str,
        client_id: str,
        code_verifier: str | None = None,
        client_secret: str | None = None,
    ) -> TokenResponse:
        """Exchange an authorization code for tokens."""
        data = {
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": redirect_uri,
            "client_id": client_id,
        }
        if code_verifier:
            data["code_verifier"] = code_verifier
        if client_secret:
            data["client_secret"] = client_secret

        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.post(
                    f"{self.base_url}/oauth/token",
                    data=data,
                    headers={"Content-Type": "application/x-www-form-urlencoded"},
                )
        except httpx.TimeoutException as e:
            raise AuthError(f"Request timed out: {e}", "NETWORK_ERROR") from e
        except httpx.HTTPError as e:
            raise AuthError(f"Network error: {e}", "NETWORK_ERROR") from e

        if resp.status_code != 200:
            detail = self._extract_error_detail(resp, "Code exchange failed")
            raise AuthError(detail, "TOKEN_INVALID", resp.status_code)

        return self._parse_token_response(resp)

    async def refresh_token(
        self,
        refresh_token: str,
        client_id: str | None = None,
        client_secret: str | None = None,
    ) -> TokenResponse:
        """Refresh an access token using a refresh token."""
        data = {
            "grant_type": "refresh_token",
            "refresh_token": refresh_token,
        }
        if client_id:
            data["client_id"] = client_id
        if client_secret:
            data["client_secret"] = client_secret

        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.post(
                    f"{self.base_url}/oauth/token",
                    data=data,
                    headers={"Content-Type": "application/x-www-form-urlencoded"},
                )
        except httpx.TimeoutException as e:
            raise AuthError(f"Request timed out: {e}", "NETWORK_ERROR") from e
        except httpx.HTTPError as e:
            raise AuthError(f"Network error: {e}", "NETWORK_ERROR") from e

        if resp.status_code != 200:
            detail = self._extract_error_detail(resp, "Token refresh failed")
            raise AuthError(detail, "TOKEN_INVALID", resp.status_code)

        return self._parse_token_response(resp)

    async def redeem_code(self, user_token: str, code: str) -> RedeemResult:
        """Redeem an activation code for the authenticated user."""
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.post(
                    f"{self.base_url}/api/v1/activation/redeem",
                    json={"code": code},
                    headers={
                        "Authorization": f"Bearer {user_token}",
                        "Content-Type": "application/json",
                    },
                )
        except httpx.TimeoutException as e:
            raise AuthError(f"Request timed out: {e}", "NETWORK_ERROR") from e
        except httpx.HTTPError as e:
            raise AuthError(f"Network error: {e}", "NETWORK_ERROR") from e

        if resp.status_code != 200:
            detail = self._extract_error_detail(resp, "Redemption failed")
            raise AuthError(detail, "TOKEN_INVALID", resp.status_code)

        try:
            d = resp.json()
            return RedeemResult(
                tool_id=d["tool_id"],
                tool_name=d["tool_name"],
                duration_days=d["duration_days"],
                expires_at=d["expires_at"],
                message=d.get("message", ""),
                token_refresh_required=d.get("token_refresh_required", True),
                new_access_token=d.get("new_access_token"),
            )
        except (KeyError, ValueError) as e:
            raise AuthError(f"Invalid response format: {e}", "INVALID_RESPONSE") from e

    async def introspect(
        self,
        token: str,
        client_id: str | None = None,
        client_secret: str | None = None,
    ) -> IntrospectResult:
        """Introspect a token to check if it's active."""
        data = {"token": token}
        if client_id:
            data["client_id"] = client_id
        if client_secret:
            data["client_secret"] = client_secret

        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.post(
                    f"{self.base_url}/oauth/introspect",
                    data=data,
                    headers={"Content-Type": "application/x-www-form-urlencoded"},
                )
        except httpx.TimeoutException as e:
            raise AuthError(f"Request timed out: {e}", "NETWORK_ERROR") from e
        except httpx.HTTPError as e:
            raise AuthError(f"Network error: {e}", "NETWORK_ERROR") from e

        if resp.status_code != 200:
            detail = self._extract_error_detail(resp, "Introspection failed")
            raise AuthError(detail, "TOKEN_INVALID", resp.status_code)

        try:
            d = resp.json()
            return IntrospectResult(
                active=d.get("active", False),
                sub=d.get("sub"),
                exp=d.get("exp"),
                iat=d.get("iat"),
                jti=d.get("jti"),
                entitlements=d.get("entitlements"),
            )
        except (ValueError, TypeError) as e:
            raise AuthError(f"Invalid response format: {e}", "INVALID_RESPONSE") from e

    @staticmethod
    def _extract_error_detail(resp: httpx.Response, fallback_prefix: str) -> str:
        """Extract error detail from response, handling JSON parse failures."""
        try:
            if resp.headers.get("content-type", "").startswith("application/json"):
                body = resp.json()
                return body.get("detail", f"{fallback_prefix}: {resp.status_code}")
        except Exception:
            pass
        return f"{fallback_prefix}: {resp.status_code}"

    @staticmethod
    def _parse_token_response(resp: httpx.Response) -> TokenResponse:
        """Parse token response with error handling."""
        try:
            d = resp.json()
            return TokenResponse(
                access_token=d["access_token"],
                token_type=d.get("token_type", "bearer"),
                expires_in=d.get("expires_in", 0),
                refresh_token=d.get("refresh_token", ""),
            )
        except (KeyError, ValueError) as e:
            raise AuthError(f"Invalid token response format: {e}", "INVALID_RESPONSE") from e
