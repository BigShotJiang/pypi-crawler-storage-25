import time
from typing import Callable

from fastapi import HTTPException, Request, status

from auth_sdk.jwt_validator import JWTValidator
from auth_sdk.models import Entitlement, TokenPayload


class AuthMiddleware:
    """FastAPI dependency for tool-side authentication and authorization."""

    def __init__(self, jwks_url: str, algorithm: str = "RS256", hs256_secret: str | None = None):
        self.validator = JWTValidator(
            jwks_url=jwks_url,
            algorithm=algorithm,
            hs256_secret=hs256_secret,
        )

    async def authenticate(self, request: Request) -> TokenPayload:
        """Extract and validate the bearer token, return parsed payload."""
        auth_header = request.headers.get("Authorization", "")
        if not auth_header.startswith("Bearer "):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Missing or invalid Authorization header",
            )
        token = auth_header[7:]
        try:
            raw = await self.validator.validate(token)
        except ValueError as e:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=str(e))

        entitlements = [
            Entitlement(tool_id=e["tool_id"], expires_at=e["expires_at"]) for e in raw.get("entitlements", [])
        ]
        return TokenPayload(
            sub=raw["sub"],
            exp=raw["exp"],
            iat=raw["iat"],
            jti=raw.get("jti", ""),
            entitlements=entitlements,
            role=raw.get("role"),
            is_admin=raw.get("is_admin", False),
        )

    def require_tool(self, tool_id: str | int) -> Callable:
        """FastAPI dependency that checks the user has access to a specific tool."""
        middleware = self

        async def dependency(request: Request) -> TokenPayload:
            payload = await middleware.authenticate(request)
            if not payload.has_tool_access(tool_id):
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"No access to tool {tool_id}",
                )
            return payload

        return dependency


# Module-level cache with size limit for require_tool_access()
_middleware_cache: dict[str, AuthMiddleware] = {}
_CACHE_MAX_SIZE = 64


def require_tool_access(tool_id: str | int, *, jwks_url: str = ""):
    """Convenience function that returns a FastAPI dependency for tool access verification.

    Usage:
        from auth_sdk import require_tool_access

        @app.get("/api/generate")
        async def generate(
            payload: TokenPayload = Depends(require_tool_access(1, jwks_url="https://auth.example.com/.well-known/jwks.json"))
        ):
            user_id = payload.sub
            ...
    """
    if not jwks_url:
        raise ValueError("jwks_url is required for require_tool_access()")
    if jwks_url not in _middleware_cache:
        if len(_middleware_cache) >= _CACHE_MAX_SIZE:
            # Evict oldest entry
            oldest_key = next(iter(_middleware_cache))
            del _middleware_cache[oldest_key]
        _middleware_cache[jwks_url] = AuthMiddleware(jwks_url=jwks_url)
    middleware = _middleware_cache[jwks_url]
    return middleware.require_tool(tool_id)
