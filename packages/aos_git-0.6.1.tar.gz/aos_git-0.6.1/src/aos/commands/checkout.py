import subprocess
import click
import questionary
from rich.console import Console

console = Console()


def _get_branches(include_remote: bool = True) -> tuple[list[str], str | None]:
    """로컬 + 원격 브랜치 목록을 반환한다. 현재 브랜치가 맨 앞에 온다."""
    if include_remote:
        subprocess.run(["git", "fetch", "--prune", "origin"], capture_output=True)

    cmd = ["git", "branch", "-a"] if include_remote else ["git", "branch"]
    result = subprocess.run(cmd, capture_output=True, text=True)

    current = None
    local_branches = []
    remote_branches = []

    for line in result.stdout.splitlines():
        is_current = line.startswith("*")
        name = line[2:].strip()

        if "->" in name:
            continue

        if name.startswith("remotes/origin/"):
            remote_name = name.removeprefix("remotes/origin/")
            remote_branches.append(remote_name)
        else:
            if is_current:
                current = name
            else:
                local_branches.append(name)

    # 원격에만 있는 브랜치 추출
    local_set = set(local_branches) | ({current} if current else set())
    remote_only = [b for b in remote_branches if b not in local_set]

    ordered = []
    if current:
        ordered.append(current)
    ordered.extend(local_branches)
    ordered.extend(f"origin/{b}" for b in remote_only)

    return ordered, current


def _interactive_select(branches: list[str], current: str | None) -> str | None:
    """화살표 키로 브랜치를 선택하는 인터랙티브 프롬프트를 표시한다."""
    choices = []
    for b in branches:
        if b == current:
            choices.append(questionary.Choice(title=f"* {b}  (현재)", value=b))
        elif b.startswith("origin/"):
            choices.append(questionary.Choice(title=f"  {b}  [dim](원격)[/dim]", value=b))
        else:
            choices.append(questionary.Choice(title=f"  {b}", value=b))

    selected = questionary.select(
        "전환할 브랜치를 선택하세요",
        choices=choices,
        use_indicator=True,
        style=questionary.Style([
            ("selected", "fg:#00ff87 bold"),
            ("pointer", "fg:#00ff87 bold"),
            ("highlighted", "fg:#00ff87"),
            ("answer", "fg:#00ff87 bold"),
            ("question", "bold"),
        ]),
    ).ask()

    return selected


@click.command("checkout")
@click.argument("branch", required=False, default=None)
@click.option("-b", "--new", "create", is_flag=True, default=False, help="브랜치를 새로 만들고 전환")
@click.option("--push", "auto_push", is_flag=True, default=False, help="생성 후 원격에 바로 push")
def checkout_cmd(branch: str | None, create: bool, auto_push: bool):
    """브랜치를 전환하거나 새로 만든다.

    브랜치명을 생략하면 화살표 키로 선택할 수 있습니다.
    """
    # -b 플래그: 새 브랜치 생성
    if create:
        name: str = branch or click.prompt("[aos] 새 브랜치명을 입력하세요")
        result = subprocess.run(
            ["git", "checkout", "-b", name],
            capture_output=True, text=True,
        )
        if result.returncode != 0:
            console.print(f"[red][aos] 브랜치 생성 실패: {result.stderr.strip()}[/red]")
            raise click.Abort()
        console.print(f"[green][aos] 브랜치 '{name}' 생성 및 전환 완료.[/green]")

        if auto_push:
            push_result = subprocess.run(
                ["git", "push", "-u", "origin", name],
                capture_output=True, text=True,
            )
            if push_result.returncode == 0:
                console.print(f"[green][aos] 원격에 '{name}' 브랜치 등록 완료.[/green]")
            else:
                console.print(f"[yellow][aos] 원격 push 실패 (나중에 'aos push'로 시도): {push_result.stderr.strip()}[/yellow]")
        return

    # 브랜치명이 없으면 인터랙티브 선택
    if branch is None:
        branches, current = _get_branches(include_remote=True)
        if not branches:
            console.print("[red][aos] 브랜치 목록을 가져올 수 없습니다.[/red]")
            raise click.Abort()

        selected = _interactive_select(branches, current)
        if not selected:
            console.print("[dim][aos] 취소됨.[/dim]")
            raise SystemExit(0)

        if selected == current:
            console.print(f"[dim][aos] 이미 '{current}' 브랜치에 있습니다.[/dim]")
            raise SystemExit(0)

        _do_checkout(selected)
        return

    _do_checkout(branch)


def _check_uncommitted() -> bool:
    """커밋되지 않은 변경사항이 있으면 True를 반환하고 안내 메시지를 출력한다."""
    result = subprocess.run(["git", "status", "--porcelain"], capture_output=True, text=True)
    if result.stdout.strip():
        console.print("[yellow][aos] 커밋되지 않은 변경사항이 있어 브랜치를 전환할 수 없습니다.[/yellow]")
        console.print()
        console.print("  변경사항을 먼저 처리하세요:")
        console.print("    [bold]aos add && aos commit -m '...'[/bold]  → 커밋 후 전환")
        console.print("    [bold]git stash[/bold]                        → 임시 보관 후 전환")
        console.print()
        return True
    return False


def _do_checkout(branch: str) -> None:
    """주어진 브랜치로 전환한다. origin/ 접두사가 있으면 원격 브랜치로 처리한다."""
    # origin/ 접두사가 붙은 경우: 원격 브랜치로 직접 전환
    if branch.startswith("origin/"):
        remote_branch = branch.removeprefix("origin/")
        subprocess.run(["git", "fetch", "origin"], capture_output=True)
        result = subprocess.run(
            ["git", "checkout", "-b", remote_branch, f"origin/{remote_branch}"],
            capture_output=True, text=True,
        )
        if result.returncode != 0:
            if "overwritten by checkout" in result.stderr or "local changes" in result.stderr:
                _check_uncommitted()
                raise click.Abort()
            # 이미 로컬에 있으면 그냥 체크아웃
            result = subprocess.run(
                ["git", "checkout", remote_branch],
                capture_output=True, text=True,
            )
        if result.returncode != 0:
            console.print(f"[red][aos] 브랜치 전환 실패: {result.stderr.strip()}[/red]")
            raise click.Abort()
        console.print(f"[green][aos] '{remote_branch}' 브랜치로 전환 완료.[/green]")
        return

    # 일반 로컬 브랜치 전환
    result = subprocess.run(
        ["git", "checkout", branch],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        stderr = result.stderr
        # 커밋되지 않은 변경사항 때문에 실패한 경우
        if "overwritten by checkout" in stderr or "local changes" in stderr:
            _check_uncommitted()
            raise click.Abort()
        # 로컬에 없는 브랜치일 수 있으므로 원격에서 fetch 후 재시도
        console.print(f"[cyan][aos] 원격에서 '{branch}' 브랜치를 가져오는 중...[/cyan]")
        subprocess.run(["git", "fetch", "origin"], capture_output=True)
        retry = subprocess.run(
            ["git", "checkout", "-b", branch, f"origin/{branch}"],
            capture_output=True, text=True,
        )
        if retry.returncode != 0:
            console.print(f"[red][aos] 브랜치 전환 실패: {stderr.strip()}[/red]")
            raise click.Abort()
    console.print(f"[green][aos] '{branch}' 브랜치로 전환 완료.[/green]")
