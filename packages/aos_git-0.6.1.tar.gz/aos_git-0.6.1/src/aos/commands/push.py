import subprocess
import click
from rich.console import Console

from aos.git_auth import auth_env, get_token

console = Console()


@click.command("push")
@click.option("--remote", default="origin")
@click.option("--branch", default="")
def push_cmd(remote: str, branch: str):
    """변경사항을 원격 저장소에 올린다."""
    cmd = ["git", "push", remote]
    if branch:
        cmd.append(branch)
    console.print(f"[cyan][aos] {' '.join(cmd)} 실행 중...[/cyan]")

    token = get_token(remote)
    if token:
        with auth_env(token) as env:
            result = subprocess.run(cmd, env=env)
    else:
        result = subprocess.run(cmd)

    if result.returncode == 0:
        console.print("[green][aos] 푸시 완료.[/green]")
    else:
        console.print("[red][aos] 푸시 실패. git push 출력을 확인하세요.[/red]")
        raise click.Abort()
