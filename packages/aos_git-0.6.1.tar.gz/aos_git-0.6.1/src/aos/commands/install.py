import os
import shutil
from pathlib import Path

import click
from rich.console import Console

console = Console()

_SKILL_REGISTRATION = (
    "\n# aos\n"
    "- **aos** (`~/.claude/skills/aos/SKILL.md`) "
    "- AI-powered git helper. Trigger: `/aos`\n"
    "When the user types `/aos`, invoke the Skill tool "
    'with `skill: "aos"` before doing anything else.\n'
)


def _claude_config_dir() -> Path:
    env = os.environ.get("CLAUDE_CONFIG_DIR")
    return Path(env) if env else Path.home() / ".claude"


def _install_skill_file() -> Path:
    skill_src = Path(__file__).parent.parent / "skill.md"
    if not skill_src.exists():
        console.print("[red][aos] 패키지에서 skill.md를 찾을 수 없습니다.[/red]")
        raise click.Abort()

    skill_dst = _claude_config_dir() / "skills" / "aos" / "SKILL.md"
    skill_dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy(skill_src, skill_dst)
    return skill_dst


def _register_in_claude_md() -> None:
    claude_md = _claude_config_dir() / "CLAUDE.md"
    if claude_md.exists():
        content = claude_md.read_text()
        if "# aos" in content:
            return
        claude_md.write_text(content + _SKILL_REGISTRATION)
    else:
        claude_md.parent.mkdir(parents=True, exist_ok=True)
        claude_md.write_text(_SKILL_REGISTRATION.lstrip())


def _uninstall_skill_file() -> None:
    skill_dst = _claude_config_dir() / "skills" / "aos" / "SKILL.md"
    if skill_dst.exists():
        skill_dst.unlink()
        try:
            skill_dst.parent.rmdir()
        except OSError:
            pass


def _unregister_from_claude_md() -> None:
    claude_md = _claude_config_dir() / "CLAUDE.md"
    if not claude_md.exists():
        return
    content = claude_md.read_text()
    if "# aos" not in content:
        return
    lines = content.splitlines(keepends=True)
    out, skip = [], False
    for line in lines:
        if line.strip() == "# aos":
            skip = True
        if skip:
            # blank line after the block ends the skip
            if line.strip() == "" and out and out[-1].strip() != "":
                skip = False
                continue
            continue
        out.append(line)
    claude_md.write_text("".join(out))


@click.command("install")
@click.option("--platform", default="claude", show_default=True, help="설치할 플랫폼")
def install_cmd(platform: str):
    """Claude Code에 aos skill을 전역 설치한다.

    pip install aos-git 이후 한 번만 실행하면 됩니다.
    프로젝트별 연동은 `aos claude install`을 사용하세요.
    """
    if platform != "claude":
        console.print(f"[yellow][aos] '{platform}' 플랫폼은 아직 지원되지 않습니다.[/yellow]")
        return

    skill_dst = _install_skill_file()
    console.print(f"[green][aos] skill 파일 설치 완료:[/green] {skill_dst}")

    _register_in_claude_md()
    claude_md = _claude_config_dir() / "CLAUDE.md"
    console.print(f"[green][aos] CLAUDE.md 등록 완료:[/green] {claude_md}")

    console.print(
        "\n[bold green][aos] 전역 설치 완료![/bold green]\n"
        "  Claude Code에서 [bold]/aos[/bold] 명령어로 skill을 사용할 수 있습니다.\n"
        "  프로젝트별 연동을 추가하려면 저장소 루트에서 실행하세요:\n"
        "    [bold]aos claude install[/bold]"
    )


@click.command("uninstall")
def uninstall_cmd():
    """Claude Code에서 aos skill을 전역 제거한다."""
    _uninstall_skill_file()
    _unregister_from_claude_md()
    console.print("[green][aos] 전역 제거 완료.[/green]")
