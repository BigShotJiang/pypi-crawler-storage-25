import subprocess
from pathlib import Path
import click
from rich.console import Console
from aos.config.settings import load_config
from aos.ai.factory import build_adapter
from aos.conflict.resolver import resolve_all_conflicts
from aos.git_auth import auth_env, get_token

console = Console()


def _current_branch() -> str:
    result = subprocess.run(
        ["git", "branch", "--show-current"],
        capture_output=True, text=True,
    )
    return result.stdout.strip()


@click.command("sync")
@click.option("--base", default="main", help="기준 브랜치 (기본: main)")
def sync_cmd(base: str):
    """최신 main을 현재 브랜치에 반영한다. 충돌 시 AI가 해결을 제안한다.

    병합 담당자가 main을 업데이트한 뒤, 각 팀원이 실행하면
    최신 main 위에서 계속 작업할 수 있다.
    """
    current = _current_branch()

    if current == base:
        console.print(f"[yellow][aos] 현재 '{base}' 브랜치입니다. 'aos pull'을 사용하세요.[/yellow]")
        return

    console.print(f"[cyan][aos] origin에서 최신 정보를 가져오는 중...[/cyan]")
    token = get_token("origin")
    fetch_cmd = ["git", "fetch", "origin"]
    if token:
        with auth_env(token) as env:
            fetch = subprocess.run(fetch_cmd, capture_output=True, text=True, env=env)
    else:
        fetch = subprocess.run(fetch_cmd, capture_output=True, text=True)
    if fetch.returncode != 0:
        console.print(f"[red][aos] fetch 실패: {fetch.stderr}[/red]")
        raise click.Abort()

    merge_target = f"origin/{base}"
    console.print(f"[cyan][aos] '{current}' 브랜치에 '{merge_target}' 반영 중...[/cyan]")
    result = subprocess.run(["git", "merge", merge_target], capture_output=True, text=True)
    console.print(result.stdout)

    if result.returncode == 0:
        console.print(f"[green][aos] 완료. '{current}' 브랜치가 최신 '{base}' 기준으로 업데이트됐습니다.[/green]")
        return

    if "CONFLICT" in result.stdout or "conflict" in result.stderr.lower():
        console.print(f"[yellow][aos] 충돌이 감지되었습니다. AI 해결을 시도합니다...[/yellow]")
        try:
            cfg = load_config()
            adapter = build_adapter(cfg)
        except ValueError as e:
            console.print(f"[red][aos] {e}[/red]")
            raise click.Abort()

        repo_root = Path.cwd()
        all_resolved = resolve_all_conflicts(repo_root, adapter, cfg.behavior)
        if all_resolved:
            subprocess.run(["git", "add", "-A"], capture_output=True)
            commit_msg = f"sync with {base}"
            commit = subprocess.run(
                ["git", "commit", "-m", commit_msg],
                capture_output=True, text=True,
            )
            if commit.returncode == 0:
                console.print(f"[green][aos] 모든 충돌 해결 및 커밋 완료: '{commit_msg}'[/green]")
            else:
                console.print(f"[red][aos] 커밋 실패: {commit.stderr}[/red]")
        else:
            console.print("[yellow][aos] 일부 충돌이 해결되지 않았습니다. 수동으로 확인 후 커밋하세요.[/yellow]")
    else:
        console.print(f"[red][aos] 오류: {result.stderr}[/red]")
        raise click.Abort()
