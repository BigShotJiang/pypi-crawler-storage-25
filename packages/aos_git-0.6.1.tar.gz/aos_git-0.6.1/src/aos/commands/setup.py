import stat
import subprocess
import tomllib
from pathlib import Path
import click
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich import box
from aos.config.settings import (
    load_config, save_config, AIConfig,
    DatabricksConfig, AnthropicConfig, BehaviorConfig,
)
from aos.git_auth import normalize_url

console = Console()

NOTIFY_CONFIG_TEMPLATE = """\
# aos-git 알림 설정
# aos setup --notify 로 자동 생성됨

[notify]
branch = "{branch}"

# main push 시 알림을 받을 전체 팀원
recipients = {recipients}

# feature 브랜치 push 시 알림을 받을 병합 관리자 (비워두면 비활성화)
mergers = {mergers}
"""


def _banner():
    console.print()
    console.print(Panel(
        Text.assemble(
            ("  aos", "bold cyan"),
            ("  —  AI-powered Git Helper", "dim"),
        ),
        box=box.ROUNDED,
        border_style="cyan",
        padding=(0, 2),
    ))
    console.print()


def _step(n: int, total: int, title: str):
    console.print()
    console.rule(f"[bold cyan]Step {n}/{total}[/bold cyan]  [bold]{title}[/bold]")
    console.print()


def _ok(msg: str):
    console.print(f"  [bold green]✓[/bold green]  {msg}")


_PRE_PUSH_HOOK = """\
#!/usr/bin/env bash
# aos pre-push hook — aos setup 으로 자동 생성됨
#
#   main push (릴리스 커밋 제외) → 팀 이메일 알림
#   feature 브랜치 push         → 병합 관리자 알림

set -e

while read -r local_ref local_sha remote_ref remote_sha; do

    if [[ "$remote_ref" == "refs/heads/main" ]]; then
        COMMIT_MSG="$(git log -1 --format='%s' "$local_sha")"
        if [[ "$COMMIT_MSG" =~ ^chore:\\ release\\ v ]]; then
            echo "[pre-push] 릴리스 커밋 감지 — 팀 알림 생략"
        else
            echo "[pre-push] main 브랜치 push 감지 → 팀 알림 발송 중..."
            export GITLAB_USER_NAME="$(git log -1 --format='%an' "$local_sha")"
            export CI_COMMIT_MESSAGE="$COMMIT_MSG"
            export CI_COMMIT_SHA="$(git log -1 --format='%H' "$local_sha")"
            export CI_PROJECT_URL="$(git remote get-url origin | sed 's/\\.git$//')"
            aos notify --event main-push || \\
                echo "[WARN] 팀 알림 발송 실패 — push는 계속 진행합니다"
        fi

    elif [[ "$remote_ref" == refs/heads/* ]]; then
        echo "[pre-push] 브랜치 push 감지 → 병합 관리자 알림 발송 중..."
        export BRANCH_NAME="${remote_ref#refs/heads/}"
        export GITLAB_USER_NAME="$(git log -1 --format='%an' "$local_sha")"
        export CI_COMMIT_MESSAGE="$(git log -1 --format='%s' "$local_sha")"
        export CI_COMMIT_SHA="$(git log -1 --format='%H' "$local_sha")"
        export CI_PROJECT_URL="$(git remote get-url origin | sed 's/\\.git$//')"
        aos notify --event branch-push || \\
            echo "[WARN] 병합 관리자 알림 발송 실패 — push는 계속 진행합니다"
    fi

done

exit 0
"""


def _find_repo_root() -> Path | None:
    result = subprocess.run(
        ["git", "rev-parse", "--show-toplevel"],
        capture_output=True, text=True,
    )
    if result.returncode == 0:
        return Path(result.stdout.strip())
    return None


def _load_project_notify_config(repo_root: Path) -> dict:
    """프로젝트의 scripts/notify_config.toml을 읽어 현재 설정을 반환한다."""
    config_path = repo_root / "scripts" / "notify_config.toml"
    if config_path.exists():
        with open(config_path, "rb") as f:
            return tomllib.load(f).get("notify", {})
    return {}


def _install_git_hook(repo_root: Path) -> None:
    hook_dst = repo_root / ".git" / "hooks" / "pre-push"
    if hook_dst.exists() or hook_dst.is_symlink():
        hook_dst.unlink()
    hook_dst.write_text(_PRE_PUSH_HOOK)
    hook_dst.chmod(hook_dst.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    _ok("pre-push hook 설치됨")


def _generate_notify_config(branch: str, recipients: list[str], mergers: list[str], repo_root: Path) -> None:
    scripts_dir = repo_root / "scripts"
    scripts_dir.mkdir(exist_ok=True)
    recipients_toml = "[" + ", ".join(f'"{r}"' for r in recipients) + "]"
    mergers_toml = "[" + ", ".join(f'"{r}"' for r in mergers) + "]"
    config_path = scripts_dir / "notify_config.toml"
    config_path.write_text(
        NOTIFY_CONFIG_TEMPLATE.format(branch=branch, recipients=recipients_toml, mergers=mergers_toml)
    )
    _ok("scripts/notify_config.toml 생성됨")


def _setup_notify(install_hook: bool = True) -> None:
    """이메일 알림 설정을 입력받아 scripts/notify_config.toml 에 저장한다."""
    repo_root = _find_repo_root()
    current = _load_project_notify_config(repo_root) if repo_root else {}

    console.print(Panel(
        Text.assemble(
            ("이 설정을 마치면:\n\n", ""),
            ("  • ", "green"), ("팀원이 feature 브랜치를 push하면 → 병합 관리자에게 자동 알림\n", ""),
            ("  • ", "green"), ("병합 관리자가 main을 업데이트하면 → 전체 팀원에게 자동 알림", ""),
        ),
        title="[bold cyan]이메일 알림 설정[/bold cyan]",
        border_style="cyan",
        box=box.ROUNDED,
        padding=(1, 2),
    ))

    _step(1, 3, "알림 기준 브랜치")
    console.print("  main에 push될 때 전체 팀에 알림을 보냅니다.")
    console.print("  [dim]다른 브랜치를 사용 중이라면 변경하세요.[/dim]")
    console.print()
    branch = click.prompt("  브랜치명", default=current.get("branch", "main"))

    _step(2, 3, "전체 팀원 이메일")
    console.print("  main 업데이트 시 알림을 받을 팀원 이메일을 입력하세요.")
    console.print("  [dim]콤마(,)로 구분  예) kim@lge.com, lee@lge.com[/dim]")
    console.print()
    recipients_raw = click.prompt(
        "  이메일",
        default=", ".join(current.get("recipients", [])),
    )
    recipients = [r.strip() for r in recipients_raw.split(",") if r.strip()]

    _step(3, 3, "병합 관리자 이메일")
    console.print("  feature 브랜치 push 시 알림을 받을 담당자 이메일을 입력하세요.")
    console.print("  [dim]비워두면 feature 브랜치 알림은 발송되지 않습니다.[/dim]")
    console.print()
    mergers_raw = click.prompt(
        "  이메일",
        default=", ".join(current.get("mergers", [])),
    )
    mergers = [r.strip() for r in mergers_raw.split(",") if r.strip()]

    console.print()
    if repo_root:
        _generate_notify_config(branch, recipients, mergers, repo_root)
        if install_hook:
            _install_git_hook(repo_root)
        console.print()
        console.print(Panel(
            Text.assemble(
                ("알림 설정 완료!\n\n", "bold green"),
                ("팀원과 공유하려면 아래 명령어로 커밋하세요:\n\n", ""),
                ("  git add scripts/notify_config.toml\n", "bold"),
                ("  git commit -m 'chore: update notify config'", "bold"),
            ),
            border_style="green",
            box=box.ROUNDED,
            padding=(1, 2),
        ))
    else:
        console.print("  [yellow]⚠[/yellow]  git 저장소를 찾을 수 없어 설정 파일을 생성하지 못했습니다.")


@click.command("setup")
@click.option("--notify", "notify_only", is_flag=True, default=False, help="알림 설정만 변경한다")
def setup_cmd(notify_only: bool):
    """AI 제공자를 설정하고 git을 구성한다.

    알림 설정만 변경하려면: aos setup --notify
    """
    cfg = load_config()

    if notify_only:
        _banner()
        _setup_notify()
        return

    # ── 전체 설정 ──────────────────────────────────────────
    _banner()
    console.print(Panel(
        Text.assemble(
            ("처음 사용하시나요? 아래 항목을 순서대로 입력해 주세요.\n\n", ""),
            ("  1. AI 제공자 선택  (Databricks / Anthropic)\n", ""),
            ("  2. API 인증 정보 입력\n", ""),
            ("  3. 안내 메시지 언어 선택\n", ""),
            ("  4. 이메일 알림 설정  (선택)\n", ""),
            ("  5. Git 인증 토큰  (선택)", ""),
        ),
        title="[bold]초기 설정[/bold]",
        border_style="blue",
        box=box.ROUNDED,
        padding=(1, 2),
    ))

    _step(1, 5, "AI 제공자 선택")
    console.print("  [bold]databricks[/bold]  사내 Databricks Model Serving을 사용합니다.")
    console.print("  [bold]anthropic [/bold]  Anthropic API를 직접 사용합니다.")
    console.print()
    provider = click.prompt(
        "  제공자",
        type=click.Choice(["databricks", "anthropic"]),
        default=cfg.ai.provider,
    )
    cfg.ai = AIConfig(provider=provider)

    _step(2, 5, "API 인증 정보")
    if provider == "databricks":
        host = click.prompt("  Databricks Host", default=cfg.databricks.host if cfg.databricks else "")
        db_token = click.prompt("  Databricks Token", hide_input=True, default=cfg.databricks.token if cfg.databricks and cfg.databricks.token else None)
        model = click.prompt("  모델 엔드포인트", default=cfg.ai.model or "databricks-claude-sonnet-4-6")
        cfg.databricks = DatabricksConfig(host=host, token=db_token)
        cfg.ai.model = model
    else:
        api_key = click.prompt(
            "  Anthropic API Key",
            hide_input=True,
            default=cfg.anthropic.api_key if cfg.anthropic else None,
        )
        model = click.prompt("  모델", default=cfg.ai.model or "claude-sonnet-4-6")
        cfg.anthropic = AnthropicConfig(api_key=api_key)
        cfg.ai.model = model

    _step(3, 5, "안내 메시지 언어")
    console.print("  [bold]ko[/bold]  한국어  |  [bold]en[/bold]  English")
    console.print()
    lang = click.prompt("  언어", type=click.Choice(["ko", "en"]), default=cfg.behavior.language)
    cfg.behavior = BehaviorConfig(language=lang)

    _step(4, 5, "이메일 알림 설정")
    console.print("  팀원이 브랜치를 push하거나 main이 업데이트될 때 이메일로 알릴 수 있습니다.")
    console.print()
    notify_enabled = click.confirm("  이메일 알림을 설정하시겠습니까?", default=True)
    if notify_enabled:
        _setup_notify(install_hook=False)

    # hook은 notify 설정 여부와 무관하게 항상 설치
    repo_root = _find_repo_root()
    if repo_root:
        _install_git_hook(repo_root)

    _step(5, 5, "Git 인증 토큰 (선택사항)")
    console.print("  GitHub / GitLab Personal Access Token을 입력하면")
    console.print("  push / fetch 시 비밀번호 입력 없이 진행됩니다.")
    if repo_root:
        result = subprocess.run(
            ["git", "remote", "get-url", "origin"],
            capture_output=True, text=True, cwd=repo_root,
        )
        remote_url = normalize_url(result.stdout) if result.returncode == 0 else ""
        if remote_url:
            console.print(f"  [dim]현재 원격 저장소: {remote_url}[/dim]")
    else:
        remote_url = ""
    console.print()

    existing_token = cfg.git_tokens.get(remote_url, "") if remote_url else ""
    git_token = click.prompt(
        "  Token",
        default=existing_token,
        hide_input=True,
        prompt_suffix=" (비워두면 건너뜀): ",
        show_default=False,
    )
    if git_token and remote_url:
        cfg.git_tokens[remote_url] = git_token
        _ok(f"Git 토큰 저장됨 ({remote_url})")
    elif not git_token and remote_url and existing_token:
        _ok("기존 토큰 유지")

    # AI 설정 + git_tokens 전역 저장
    save_config(cfg)

    # diff3 스타일 자동 설정
    subprocess.run(["git", "config", "--global", "merge.conflictstyle", "diff3"], check=False)

    console.print()
    console.print(Panel(
        Text.assemble(
            ("설정 완료!\n\n", "bold green"),
            ("  • ", "green"), ("AI/인증 설정: ~/.aos/config.toml\n", ""),
            ("  • ", "green"), ("알림 설정: scripts/notify_config.toml  (커밋하면 팀과 공유)\n", ""),
            ("  • ", "green"), ("git merge.conflictstyle=diff3 전역 적용됨\n\n", ""),
            ("이제 ", ""),
            ("aos merge", "bold cyan"),
            (" / ", ""),
            ("aos sync", "bold cyan"),
            (" 명령어로 AI 충돌 해결을 시작하세요!", ""),
        ),
        border_style="green",
        box=box.ROUNDED,
        padding=(1, 2),
    ))
    console.print()
