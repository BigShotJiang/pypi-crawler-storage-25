import json
import subprocess
from pathlib import Path

import click
from rich.console import Console

console = Console()

_CLAUDE_MD_SECTION = """\

## aos

This project uses aos for AI-powered git conflict resolution.

Rules:
- Use `aos merge <branch>` instead of `git merge` — AI resolves conflicts automatically
- Use `aos pull` instead of `git pull` — handles conflicts via AI
- Use `aos push` instead of `git push` — includes pre-push checks
- Use `aos checkout -b <branch>` to create new branches
- Use `aos sync` to sync with upstream branches
- Run `aos setup` once to configure the AI provider before using merge/pull
"""

# PreToolUse hook: fires before Bash tool calls that involve git
# Reminds Claude to use aos when merge conflicts are present
_SETTINGS_HOOK = {
    "matcher": "Bash",
    "hooks": [
        {
            "type": "command",
            "command": (
                "git diff --name-only --diff-filter=U 2>/dev/null | grep -q . && "
                "echo '{\"hookSpecificOutput\":{\"hookEventName\":\"PreToolUse\","
                "\"additionalContext\":\"aos: Merge conflicts detected. "
                "Use `aos merge` or `aos pull` for AI-powered resolution "
                "instead of manual editing.\"}}' || true"
            ),
        }
    ],
}


def _find_repo_root() -> Path | None:
    result = subprocess.run(
        ["git", "rev-parse", "--show-toplevel"],
        capture_output=True, text=True,
    )
    if result.returncode == 0:
        return Path(result.stdout.strip())
    return None


def _write_claude_md(repo_root: Path) -> None:
    claude_md = repo_root / "CLAUDE.md"
    if claude_md.exists():
        content = claude_md.read_text()
        if "## aos" in content:
            console.print("[cyan][aos] CLAUDE.md에 이미 aos 섹션이 있습니다. 건너뜁니다.[/cyan]")
            return
        claude_md.write_text(content + _CLAUDE_MD_SECTION)
    else:
        claude_md.write_text(_CLAUDE_MD_SECTION.lstrip())
    console.print(f"[green][aos] CLAUDE.md 업데이트:[/green] {claude_md}")


def _install_settings_hook(repo_root: Path) -> None:
    settings_path = repo_root / ".claude" / "settings.json"
    settings_path.parent.mkdir(parents=True, exist_ok=True)

    if settings_path.exists():
        data = json.loads(settings_path.read_text())
    else:
        data = {}

    hooks = data.setdefault("hooks", {})
    pre = hooks.setdefault("PreToolUse", [])

    # idempotent: skip if aos hook already registered
    for entry in pre:
        for hook in entry.get("hooks", []):
            if "aos" in hook.get("command", ""):
                console.print("[cyan][aos] settings.json에 이미 aos 훅이 있습니다. 건너뜁니다.[/cyan]")
                return

    pre.append(_SETTINGS_HOOK)
    settings_path.write_text(json.dumps(data, indent=2, ensure_ascii=False))
    console.print(f"[green][aos] .claude/settings.json 훅 등록:[/green] {settings_path}")


def _remove_claude_md_section(repo_root: Path) -> None:
    claude_md = repo_root / "CLAUDE.md"
    if not claude_md.exists():
        return
    content = claude_md.read_text()
    if "## aos" not in content:
        return

    lines = content.splitlines(keepends=True)
    out, in_section = [], False
    for line in lines:
        if line.strip() == "## aos":
            in_section = True
        if in_section:
            # next ## heading ends the section
            if line.startswith("## ") and line.strip() != "## aos":
                in_section = False
            else:
                continue
        out.append(line)
    claude_md.write_text("".join(out))
    console.print(f"[green][aos] CLAUDE.md에서 aos 섹션 제거:[/green] {claude_md}")


def _remove_settings_hook(repo_root: Path) -> None:
    settings_path = repo_root / ".claude" / "settings.json"
    if not settings_path.exists():
        return
    data = json.loads(settings_path.read_text())
    pre = data.get("hooks", {}).get("PreToolUse", [])
    filtered = [
        entry for entry in pre
        if not any("aos" in h.get("command", "") for h in entry.get("hooks", []))
    ]
    data.setdefault("hooks", {})["PreToolUse"] = filtered
    settings_path.write_text(json.dumps(data, indent=2, ensure_ascii=False))
    console.print(f"[green][aos] .claude/settings.json에서 aos 훅 제거:[/green] {settings_path}")


@click.group("claude")
def claude_cmd():
    """Claude Code 프로젝트 연동을 관리한다."""


@claude_cmd.command("install")
def claude_install():
    """현재 프로젝트에 aos Claude Code 연동을 설치한다.

    CLAUDE.md에 aos 규칙을 추가하고 .claude/settings.json에
    충돌 감지 훅을 등록합니다.
    """
    repo_root = _find_repo_root()
    if repo_root is None:
        console.print("[red][aos] git 저장소를 찾을 수 없습니다.[/red]")
        raise click.Abort()

    _write_claude_md(repo_root)
    _install_settings_hook(repo_root)

    console.print(
        "\n[bold green][aos] 프로젝트 연동 완료![/bold green]\n"
        "  Claude Code가 이 프로젝트에서 aos 명령어를 우선 사용합니다.\n"
        "  전역 skill이 없다면 먼저 실행하세요: [bold]aos install[/bold]"
    )


@claude_cmd.command("uninstall")
def claude_uninstall():
    """현재 프로젝트의 aos Claude Code 연동을 제거한다."""
    repo_root = _find_repo_root()
    if repo_root is None:
        console.print("[red][aos] git 저장소를 찾을 수 없습니다.[/red]")
        raise click.Abort()

    _remove_claude_md_section(repo_root)
    _remove_settings_hook(repo_root)
    console.print("[green][aos] 프로젝트 연동 제거 완료.[/green]")
