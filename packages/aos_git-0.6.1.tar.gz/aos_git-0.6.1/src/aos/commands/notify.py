import os
import smtplib
import subprocess
import sys
import tomllib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path

import click

SMTP_HOST = "lgekrhqsy01.lge.com"
SENDER_EMAIL = "eseds@lge.com"
SMTP_PORT = 25
SMTP_TIMEOUT = 15


def _load_project_notify_config() -> dict:
    """현재 git repo의 scripts/notify_config.toml을 읽는다."""
    result = subprocess.run(
        ["git", "rev-parse", "--show-toplevel"],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        return {}
    config_path = Path(result.stdout.strip()) / "scripts" / "notify_config.toml"
    if not config_path.exists():
        return {}
    with open(config_path, "rb") as f:
        return tomllib.load(f).get("notify", {})


def _load_recipients() -> list[str]:
    return _load_project_notify_config().get("recipients", [])


def _load_mergers() -> list[str]:
    return _load_project_notify_config().get("mergers", [])


def _project_name() -> str:
    url = os.environ.get("CI_PROJECT_URL", "")
    return url.rstrip("/").split("/")[-1] if url else ""


def _build_main_push_html() -> str:
    pusher = os.environ.get("GITLAB_USER_NAME", "알 수 없음")
    commit_msg = (os.environ.get("CI_COMMIT_MESSAGE", "") or "").strip().splitlines()[0]
    project_url = os.environ.get("CI_PROJECT_URL", "")
    commit_sha = (os.environ.get("CI_COMMIT_SHA", "") or "")[:8]
    project_name = _project_name()
    project_link = (
        f'<a href="{project_url}" style="color:#4A90D9;">{project_url}</a>'
        if project_url else "(없음)"
    )
    return f"""\
<!DOCTYPE html>
<html lang="ko">
<head><meta charset="utf-8"></head>
<body style="margin:0;padding:0;background:#f4f6f8;font-family:'Apple SD Gothic Neo',Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f6f8;padding:32px 0;">
    <tr><td align="center">
      <table width="580" cellpadding="0" cellspacing="0"
             style="background:#ffffff;border-radius:8px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.08);">
        <tr>
          <td style="background:#1a1a2e;padding:24px 32px;">
            <span style="color:#ffffff;font-size:18px;font-weight:700;letter-spacing:-0.3px;">{project_name or 'aos-git'}</span>
            <span style="color:#8899aa;font-size:13px;margin-left:8px;">aos-git 알림</span>
          </td>
        </tr>
        <tr>
          <td style="padding:32px 32px 0;">
            <p style="margin:0 0 8px;font-size:15px;color:#333;">안녕하세요,</p>
            <p style="margin:0 0 24px;font-size:15px;color:#333;line-height:1.6;">
              <strong>{project_name or 'main'}</strong> 프로젝트의 <strong>main</strong> 브랜치에 새로운 변경사항이 병합됐습니다.<br>
              각자 브랜치에 아래 명령어로 최신 버전을 반영해주세요.
            </p>
            <table width="100%" cellpadding="0" cellspacing="0"
                   style="background:#0d1117;border-radius:6px;margin-bottom:24px;">
              <tr>
                <td style="padding:16px 20px;font-family:'Courier New',monospace;font-size:14px;line-height:1.8;color:#e6edf3;">
                  <span style="color:#79c0ff;">$</span> aos sync<br>
                  <span style="color:#79c0ff;">$</span> aos push
                  <span style="color:#6e7681;font-size:12px;">&nbsp;&nbsp;# 원격 브랜치 업데이트 시</span>
                </td>
              </tr>
            </table>
            <table width="100%" cellpadding="0" cellspacing="0"
                   style="background:#fff8e1;border-left:4px solid #f5a623;border-radius:0 6px 6px 0;margin-bottom:24px;">
              <tr>
                <td style="padding:14px 16px;">
                  <p style="margin:0 0 6px;font-size:13px;font-weight:700;color:#b8860b;">aos push 는 선택사항입니다</p>
                  <table width="100%" cellpadding="4" cellspacing="0" style="font-size:13px;color:#555;">
                    <tr>
                      <td style="width:50%;vertical-align:top;">
                        <span style="color:#888;">필요한 경우</span><br>원격 브랜치를 최신 상태로 유지할 때
                      </td>
                      <td style="width:50%;vertical-align:top;">
                        <span style="color:#888;">생략해도 되는 경우</span><br>로컬에서 작업을 계속할 때
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
          </td>
        </tr>
        <tr>
          <td style="padding:0 32px 32px;">
            <table width="100%" cellpadding="0" cellspacing="0" style="background:#f8f9fa;border-radius:6px;">
              <tr>
                <td style="padding:16px 20px;">
                  <p style="margin:0 0 12px;font-size:12px;font-weight:700;color:#888;letter-spacing:0.5px;text-transform:uppercase;">업데이트 정보</p>
                  <table cellpadding="0" cellspacing="0" style="font-size:13px;color:#444;line-height:2;">
                    <tr>
                      <td style="color:#888;padding-right:16px;white-space:nowrap;">작업자</td>
                      <td><strong>{pusher}</strong></td>
                    </tr>
                    <tr>
                      <td style="color:#888;padding-right:16px;white-space:nowrap;">커밋</td>
                      <td>
                        <code style="background:#e8eaed;padding:1px 6px;border-radius:3px;font-size:12px;">{commit_sha}</code>
                        &nbsp;{commit_msg}
                      </td>
                    </tr>
                    <tr>
                      <td style="color:#888;padding-right:16px;white-space:nowrap;">프로젝트</td>
                      <td>{project_link}</td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
          </td>
        </tr>
        <tr>
          <td style="background:#f8f9fa;border-top:1px solid #eee;padding:16px 32px;text-align:center;">
            <p style="margin:0;font-size:12px;color:#aaa;line-height:1.6;">
              aos sync 는 병합 및 커밋을 자동으로 처리합니다.
              충돌 발생 시 AI가 자동으로 해결합니다.<br>
              문제가 있으면 병합 담당자에게 문의해주세요.
            </p>
          </td>
        </tr>
      </table>
    </td></tr>
  </table>
</body>
</html>"""


def _build_branch_push_html() -> str:
    branch = os.environ.get("BRANCH_NAME", "알 수 없음")
    pusher = os.environ.get("GITLAB_USER_NAME", "알 수 없음")
    commit_msg = (os.environ.get("CI_COMMIT_MESSAGE", "") or "").strip().splitlines()[0]
    commit_sha = (os.environ.get("CI_COMMIT_SHA", "") or "")[:8]
    project_url = os.environ.get("CI_PROJECT_URL", "")
    project_name = _project_name()
    project_link = (
        f'<a href="{project_url}" style="color:#4A90D9;">{project_url}</a>'
        if project_url else "(없음)"
    )
    return f"""\
<!DOCTYPE html>
<html lang="ko">
<head><meta charset="utf-8"></head>
<body style="margin:0;padding:0;background:#f4f6f8;font-family:'Apple SD Gothic Neo',Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f6f8;padding:32px 0;">
    <tr><td align="center">
      <table width="580" cellpadding="0" cellspacing="0"
             style="background:#ffffff;border-radius:8px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.08);">
        <tr>
          <td style="background:#1a1a2e;padding:24px 32px;">
            <span style="color:#ffffff;font-size:18px;font-weight:700;letter-spacing:-0.3px;">{project_name or 'aos-git'}</span>
            <span style="color:#8899aa;font-size:13px;margin-left:8px;">aos-git 알림</span>
          </td>
        </tr>
        <tr>
          <td style="padding:32px 32px 0;">
            <p style="margin:0 0 8px;font-size:15px;color:#333;">안녕하세요,</p>
            <p style="margin:0 0 24px;font-size:15px;color:#333;line-height:1.6;">
              <strong>{project_name or branch}</strong> 프로젝트의 <strong>{branch}</strong> 브랜치에 새 변경사항이 올라왔습니다.<br>
              아래 명령어로 병합을 진행해주세요.
            </p>
            <table width="100%" cellpadding="0" cellspacing="0"
                   style="background:#0d1117;border-radius:6px;margin-bottom:24px;">
              <tr>
                <td style="padding:16px 20px;font-family:'Courier New',monospace;font-size:14px;line-height:1.8;color:#e6edf3;">
                  <span style="color:#79c0ff;">$</span> aos merge {branch}
                </td>
              </tr>
            </table>
          </td>
        </tr>
        <tr>
          <td style="padding:0 32px 32px;">
            <table width="100%" cellpadding="0" cellspacing="0" style="background:#f8f9fa;border-radius:6px;">
              <tr>
                <td style="padding:16px 20px;">
                  <p style="margin:0 0 12px;font-size:12px;font-weight:700;color:#888;letter-spacing:0.5px;text-transform:uppercase;">변경사항 정보</p>
                  <table cellpadding="0" cellspacing="0" style="font-size:13px;color:#444;line-height:2;">
                    <tr>
                      <td style="color:#888;padding-right:16px;white-space:nowrap;">작업자</td>
                      <td><strong>{pusher}</strong></td>
                    </tr>
                    <tr>
                      <td style="color:#888;padding-right:16px;white-space:nowrap;">브랜치</td>
                      <td><code style="background:#e8eaed;padding:1px 6px;border-radius:3px;font-size:12px;">{branch}</code></td>
                    </tr>
                    <tr>
                      <td style="color:#888;padding-right:16px;white-space:nowrap;">커밋</td>
                      <td>
                        <code style="background:#e8eaed;padding:1px 6px;border-radius:3px;font-size:12px;">{commit_sha}</code>
                        &nbsp;{commit_msg}
                      </td>
                    </tr>
                    <tr>
                      <td style="color:#888;padding-right:16px;white-space:nowrap;">프로젝트</td>
                      <td>{project_link}</td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
          </td>
        </tr>
        <tr>
          <td style="background:#f8f9fa;border-top:1px solid #eee;padding:16px 32px;text-align:center;">
            <p style="margin:0;font-size:12px;color:#aaa;line-height:1.6;">
              aos merge 는 병합 및 충돌 해결을 자동으로 처리합니다.<br>
              충돌 발생 시 AI가 자동으로 해결합니다.
            </p>
          </td>
        </tr>
      </table>
    </td></tr>
  </table>
</body>
</html>"""


def _build_release_html() -> str:
    version = os.environ.get("AOS_RELEASE_VERSION", "")
    pusher = os.environ.get("GITLAB_USER_NAME", "알 수 없음")
    project_url = os.environ.get("CI_PROJECT_URL", "")
    project_name = _project_name()
    project_link = (
        f'<a href="{project_url}" style="color:#4A90D9;">{project_url}</a>'
        if project_url else "(없음)"
    )
    version_badge = (
        f'<code style="background:#e8eaed;padding:2px 8px;border-radius:4px;font-size:13px;">{version}</code>'
        if version else ""
    )
    pip_cmd = f"pip install --upgrade aos-git=={version}" if version else "pip install --upgrade aos-git"
    return f"""\
<!DOCTYPE html>
<html lang="ko">
<head><meta charset="utf-8"></head>
<body style="margin:0;padding:0;background:#f4f6f8;font-family:'Apple SD Gothic Neo',Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f6f8;padding:32px 0;">
    <tr><td align="center">
      <table width="580" cellpadding="0" cellspacing="0"
             style="background:#ffffff;border-radius:8px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.08);">
        <tr>
          <td style="background:#1a1a2e;padding:24px 32px;">
            <span style="color:#ffffff;font-size:18px;font-weight:700;letter-spacing:-0.3px;">{project_name or 'aos-git'}</span>
            <span style="color:#8899aa;font-size:13px;margin-left:8px;">새 버전 출시</span>
            {f'&nbsp;<span style="background:#2ea44f;color:#fff;font-size:11px;font-weight:700;padding:2px 8px;border-radius:10px;">v{version}</span>' if version else ""}
          </td>
        </tr>
        <tr>
          <td style="padding:32px 32px 0;">
            <p style="margin:0 0 8px;font-size:15px;color:#333;">안녕하세요,</p>
            <p style="margin:0 0 24px;font-size:15px;color:#333;line-height:1.6;">
              <strong>aos-git</strong> 새 버전{f' {version_badge}' if version_badge else ''}이 출시됐습니다.<br>
              아래 명령어로 최신 버전으로 업데이트해주세요.
            </p>
            <table width="100%" cellpadding="0" cellspacing="0"
                   style="background:#0d1117;border-radius:6px;margin-bottom:24px;">
              <tr>
                <td style="padding:16px 20px;font-family:'Courier New',monospace;font-size:14px;line-height:1.8;color:#e6edf3;">
                  <span style="color:#79c0ff;">$</span> {pip_cmd}
                </td>
              </tr>
            </table>
          </td>
        </tr>
        <tr>
          <td style="padding:0 32px 32px;">
            <table width="100%" cellpadding="0" cellspacing="0" style="background:#f8f9fa;border-radius:6px;">
              <tr>
                <td style="padding:16px 20px;">
                  <p style="margin:0 0 12px;font-size:12px;font-weight:700;color:#888;letter-spacing:0.5px;text-transform:uppercase;">릴리스 정보</p>
                  <table cellpadding="0" cellspacing="0" style="font-size:13px;color:#444;line-height:2;">
                    <tr>
                      <td style="color:#888;padding-right:16px;white-space:nowrap;">버전</td>
                      <td>{version_badge if version_badge else "-"}</td>
                    </tr>
                    <tr>
                      <td style="color:#888;padding-right:16px;white-space:nowrap;">배포자</td>
                      <td><strong>{pusher}</strong></td>
                    </tr>
                    <tr>
                      <td style="color:#888;padding-right:16px;white-space:nowrap;">프로젝트</td>
                      <td>{project_link}</td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
          </td>
        </tr>
        <tr>
          <td style="background:#f8f9fa;border-top:1px solid #eee;padding:16px 32px;text-align:center;">
            <p style="margin:0;font-size:12px;color:#aaa;line-height:1.6;">
              업데이트 후 기존 명령어를 그대로 사용할 수 있습니다.<br>
              문제가 있으면 배포자에게 문의해주세요.
            </p>
          </td>
        </tr>
      </table>
    </td></tr>
  </table>
</body>
</html>"""


def _send_email(subject: str, html_body: str, recipients: list[str]) -> None:
    msg = MIMEMultipart("alternative")
    msg["From"] = SENDER_EMAIL
    msg["To"] = ", ".join(recipients)
    msg["Subject"] = subject
    msg.attach(MIMEText(html_body, "html", "utf-8"))

    click.echo(f"SMTP 서버에 연결 중... ({SMTP_HOST}:{SMTP_PORT})")
    try:
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=SMTP_TIMEOUT) as server:
            server.ehlo()
            click.echo("메일 전송 중...")
            server.sendmail(SENDER_EMAIL, recipients, msg.as_string())
        click.echo(f"[OK] 메일 전송 완료 → {', '.join(recipients)}")
    except smtplib.SMTPRecipientsRefused as e:
        refused = ", ".join(addr for addr in e.recipients)
        click.echo(f"[ERROR] 수신자가 거부됨: {refused}", err=True)
        click.echo("  → 이메일 주소가 올바른지 확인하세요.", err=True)
        sys.exit(1)
    except smtplib.SMTPSenderRefused as e:
        click.echo(f"[ERROR] 발신자 거부됨: {SENDER_EMAIL} — {e.smtp_error.decode()}", err=True)
        sys.exit(1)
    except (smtplib.SMTPConnectError, ConnectionRefusedError) as e:
        click.echo(f"[ERROR] SMTP 서버에 연결할 수 없음: {SMTP_HOST}:{SMTP_PORT}", err=True)
        click.echo(f"  → {e}", err=True)
        sys.exit(1)
    except TimeoutError:
        click.echo(f"[ERROR] SMTP 연결 타임아웃 ({SMTP_TIMEOUT}초): {SMTP_HOST}:{SMTP_PORT}", err=True)
        sys.exit(1)
    except smtplib.SMTPException as e:
        click.echo(f"[ERROR] 메일 발송 실패: {e}", err=True)
        sys.exit(1)


@click.command("notify")
@click.option("--event", type=click.Choice(["main-push", "branch-push", "release"]), required=True)
@click.option("--test", "test_mode", is_flag=True, default=False, help="더미 데이터로 테스트")
def notify_cmd(event: str, test_mode: bool) -> None:
    """이메일 알림을 발송한다 (pre-push hook에서 자동 호출)."""
    if test_mode:
        os.environ.setdefault("GITLAB_USER_NAME", "테스트 유저")
        os.environ.setdefault("CI_COMMIT_MESSAGE", "test: 메일 발송 테스트")
        os.environ.setdefault("CI_COMMIT_SHA", "abcd1234efgh")
        os.environ.setdefault("CI_PROJECT_URL", "https://gitlab.example.com/project")
        os.environ.setdefault("BRANCH_NAME", "feature/test-branch")
        os.environ.setdefault("AOS_RELEASE_VERSION", "0.5.0")
        click.echo("[TEST MODE] 더미 데이터로 메일을 발송합니다.")
        click.echo()

    if event == "main-push":
        recipients = _load_recipients()
        if not recipients:
            click.echo("[ERROR] 수신자 목록이 없습니다.", err=True)
            click.echo("  → aos setup --notify 를 실행하여 수신자를 등록하세요.", err=True)
            sys.exit(1)
        commit_sha = (os.environ.get("CI_COMMIT_SHA", "") or "")[:8]
        project_name = _project_name()
        project_prefix = f"[{project_name}] " if project_name else "[aos-git] "
        subject = f"{project_prefix}main 브랜치가 업데이트됐습니다 ({commit_sha})"
        click.echo(f"수신자: {', '.join(recipients)}")
        _send_email(subject, _build_main_push_html(), recipients)

    elif event == "branch-push":
        mergers = _load_mergers()
        if not mergers:
            sys.exit(0)
        branch = os.environ.get("BRANCH_NAME", "알 수 없음")
        commit_sha = (os.environ.get("CI_COMMIT_SHA", "") or "")[:8]
        project_name = _project_name()
        project_prefix = f"[{project_name}] " if project_name else "[aos-git] "
        subject = f"{project_prefix}{branch} 브랜치에 새 변경사항이 있습니다 ({commit_sha})"
        click.echo(f"수신자: {', '.join(mergers)}")
        _send_email(subject, _build_branch_push_html(), mergers)

    elif event == "release":
        recipients = _load_recipients()
        if not recipients:
            click.echo("[ERROR] 수신자 목록이 없습니다.", err=True)
            sys.exit(1)
        version = os.environ.get("AOS_RELEASE_VERSION", "")
        project_name = _project_name()
        project_prefix = f"[{project_name}] " if project_name else "[aos-git] "
        subject = f"{project_prefix}새 버전이 출시됐습니다{f' (v{version})' if version else ''}"
        click.echo(f"수신자: {', '.join(recipients)}")
        _send_email(subject, _build_release_html(), recipients)
