from importlib.metadata import version as pkg_version, PackageNotFoundError
import click
from aos.commands.add import add_cmd
from aos.commands.branch import branch_cmd
from aos.commands.checkout import checkout_cmd
from aos.commands.pull import pull_cmd
from aos.commands.push import push_cmd
from aos.commands.commit import commit_cmd
from aos.commands.status import status_cmd
from aos.commands.merge import merge_cmd
from aos.commands.sync import sync_cmd
from aos.commands.setup import setup_cmd
from aos.commands.install import install_cmd, uninstall_cmd
from aos.commands.claude_cmd import claude_cmd
from aos.commands.notify import notify_cmd


def _get_version() -> str:
    try:
        return pkg_version("aos-git")
    except PackageNotFoundError:
        return "unknown"


@click.group()
@click.version_option(version=_get_version(), prog_name="aos")
def main():
    """aos — AI-powered git helper. 충돌을 AI가 해결해드립니다."""


main.add_command(add_cmd, name="add")
main.add_command(branch_cmd, name="branch")
main.add_command(checkout_cmd, name="checkout")
main.add_command(pull_cmd, name="pull")
main.add_command(push_cmd, name="push")
main.add_command(commit_cmd, name="commit")
main.add_command(status_cmd, name="status")
main.add_command(merge_cmd, name="merge")
main.add_command(sync_cmd, name="sync")
main.add_command(setup_cmd, name="setup")
main.add_command(install_cmd, name="install")
main.add_command(uninstall_cmd, name="uninstall")
main.add_command(claude_cmd, name="claude")
main.add_command(notify_cmd, name="notify")
