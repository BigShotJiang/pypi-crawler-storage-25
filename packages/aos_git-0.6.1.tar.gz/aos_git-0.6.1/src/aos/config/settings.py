from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional
import toml

CONFIG_PATH = Path.home() / ".aos" / "config.toml"


@dataclass
class AIConfig:
    provider: str = "databricks"
    model: str = "databricks-claude-sonnet-4-6"


@dataclass
class DatabricksConfig:
    host: str = ""
    token: str = ""


@dataclass
class AnthropicConfig:
    api_key: str = ""


@dataclass
class BehaviorConfig:
    auto_apply: bool = False
    context_lines: int = 20
    language: str = "ko"


@dataclass
class Config:
    ai: AIConfig = field(default_factory=AIConfig)
    databricks: Optional[DatabricksConfig] = field(default_factory=DatabricksConfig)
    anthropic: Optional[AnthropicConfig] = field(default_factory=AnthropicConfig)
    behavior: BehaviorConfig = field(default_factory=BehaviorConfig)
    git_tokens: dict = field(default_factory=dict)  # {normalized_remote_url: token}


def load_config() -> Config:
    if not CONFIG_PATH.exists():
        return Config()
    data = toml.load(CONFIG_PATH)
    return Config(
        ai=AIConfig(**data.get("ai", {})),
        databricks=DatabricksConfig(**data.get("databricks", {})),
        anthropic=AnthropicConfig(**data.get("anthropic", {})),
        behavior=BehaviorConfig(**data.get("behavior", {})),
        git_tokens=data.get("git_tokens", {}),
    )


def save_config(config: Config) -> None:
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    data = {
        "ai": {"provider": config.ai.provider, "model": config.ai.model},
        "databricks": {
            "host": config.databricks.host if config.databricks else "",
            "token": config.databricks.token if config.databricks else "",
        },
        "anthropic": {
            "api_key": config.anthropic.api_key if config.anthropic else "",
        },
        "behavior": {
            "auto_apply": config.behavior.auto_apply,
            "context_lines": config.behavior.context_lines,
            "language": config.behavior.language,
        },
        "git_tokens": config.git_tokens,
    }
    with open(CONFIG_PATH, "w") as f:
        toml.dump(data, f)
