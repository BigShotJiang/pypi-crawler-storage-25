"""Git 인증 토큰을 이용한 자격증명 주입 유틸리티."""
import os
import stat
import subprocess
import tempfile
from contextlib import contextmanager

from aos.config.settings import load_config


def normalize_url(url: str) -> str:
    """remote URL을 토큰 조회용 키로 정규화한다."""
    return url.strip().rstrip("/").removesuffix(".git")


def get_token(remote: str = "origin") -> str | None:
    """현재 repo의 remote에 해당하는 토큰을 반환한다."""
    result = subprocess.run(
        ["git", "remote", "get-url", remote],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        return None
    url = normalize_url(result.stdout)
    return load_config().git_tokens.get(url)


@contextmanager
def auth_env(token: str):
    """GIT_ASKPASS 임시 스크립트를 생성하고 환경변수 dict를 yield한다."""
    script = (
        "#!/usr/bin/env python3\n"
        "import sys\n"
        "prompt = sys.argv[1] if len(sys.argv) > 1 else ''\n"
        "if 'sername' in prompt:\n"
        "    print('oauth2')\n"
        f"elif 'assword' in prompt:\n"
        f"    print({repr(token)})\n"
    )
    tmp = tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", delete=False, prefix="aos_askpass_"
    )
    tmp.write(script)
    tmp.close()
    os.chmod(tmp.name, stat.S_IRWXU)
    try:
        yield {
            **os.environ,
            "GIT_ASKPASS": tmp.name,
            "GIT_TERMINAL_PROMPT": "0",
        }
    finally:
        os.unlink(tmp.name)
