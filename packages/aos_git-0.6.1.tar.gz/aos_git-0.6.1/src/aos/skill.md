---
name: aos
description: "AI-powered git helper — merge conflict resolution, branch management, smart commits. Use instead of raw git commands."
trigger: /aos
---

# aos — AI-Powered Git Helper

aos wraps git with AI-powered conflict resolution. Use `aos` commands instead of raw `git` when working in this repository.

## Setup (first time)

```bash
aos setup   # configure AI provider (Databricks or Anthropic)
```

## Commands

### Branch management
| Command | Description |
|---------|-------------|
| `aos checkout <branch>` | switch to branch (auto-fetches from remote if missing) |
| `aos checkout -b <branch>` | create and switch to new branch |
| `aos checkout -b <branch> --push` | create, switch, and push to remote |
| `aos branch` | list branches |

### Pull / Sync (AI conflict resolution)
| Command | Description |
|---------|-------------|
| `aos pull` | pull from origin, AI resolves any conflicts |
| `aos pull --remote <r> --branch <b>` | pull from specific remote/branch |
| `aos merge <branch>` | merge branch, AI resolves conflicts automatically |
| `aos merge <branch> --no-fetch` | merge without fetching first |
| `aos sync` | sync current branch with upstream |

### Commit workflow
| Command | Description |
|---------|-------------|
| `aos add [files]` | stage files |
| `aos commit` | commit with AI-suggested message |
| `aos push` | push with pre-checks |
| `aos status` | enhanced git status |

## Typical workflows

**Start a new feature:**
```bash
aos checkout -b feature/my-feature
# ... make changes ...
aos add .
aos commit
aos push
```

**Merge with conflict resolution:**
```bash
aos merge main        # fetches origin/main then merges; AI fixes conflicts
aos merge origin/main # specify remote branch explicitly
```

**Sync before a PR:**
```bash
aos sync              # pulls upstream changes into current branch
aos push
```

## When to use aos vs git

- `git merge` → `aos merge <branch>` (AI resolves conflicts)
- `git pull` → `aos pull` (AI resolves conflicts)
- `git checkout -b` → `aos checkout -b` (same but with remote auto-fetch)
- For conflict-free operations (log, diff, stash, rebase), raw `git` is fine.
