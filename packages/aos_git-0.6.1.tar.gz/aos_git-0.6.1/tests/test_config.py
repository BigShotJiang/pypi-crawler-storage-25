from pathlib import Path
from unittest.mock import patch
from aos.config.settings import load_config, save_config, Config, AIConfig, BehaviorConfig


def test_load_config_returns_defaults_when_missing(tmp_path):
    config_path = tmp_path / "config.toml"
    with patch("aos.config.settings.CONFIG_PATH", config_path):
        cfg = load_config()
    assert cfg.ai.provider == "databricks"
    assert cfg.behavior.auto_apply is False
    assert cfg.behavior.context_lines == 20


def test_save_and_load_roundtrip(tmp_path):
    config_path = tmp_path / ".aos" / "config.toml"
    with patch("aos.config.settings.CONFIG_PATH", config_path):
        cfg = Config(
            ai=AIConfig(provider="anthropic", model="claude-opus-4-6"),
            databricks=None,
            anthropic=None,
            behavior=BehaviorConfig(auto_apply=True, context_lines=30, language="en"),
        )
        save_config(cfg)
        loaded = load_config()
    assert loaded.ai.provider == "anthropic"
    assert loaded.behavior.auto_apply is True
    assert loaded.behavior.context_lines == 30


def test_git_tokens_roundtrip(tmp_path):
    config_path = tmp_path / ".aos" / "config.toml"
    with patch("aos.config.settings.CONFIG_PATH", config_path):
        cfg = Config(git_tokens={"https://gitlab.lge.com/team/repo": "glpat-abc123"})
        save_config(cfg)
        loaded = load_config()
    assert loaded.git_tokens == {"https://gitlab.lge.com/team/repo": "glpat-abc123"}
