import sys
from pathlib import Path
import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "scripts"))
import notify  # noqa: E402


def test_load_recipients_from_config(monkeypatch):
    monkeypatch.setattr(notify, "_load_notify_config", lambda: {
        "recipients": ["a@lge.com", "b@lge.com"]
    })
    assert notify.load_recipients() == ["a@lge.com", "b@lge.com"]


def test_load_recipients_falls_back_to_env(monkeypatch):
    monkeypatch.setattr(notify, "_load_notify_config", lambda: {})
    monkeypatch.setenv("NOTIFY_RECIPIENTS", "x@lge.com, y@lge.com")
    assert notify.load_recipients() == ["x@lge.com", "y@lge.com"]


def test_load_mergers_returns_configured_list(monkeypatch):
    monkeypatch.setattr(notify, "_load_notify_config", lambda: {
        "mergers": ["lead@lge.com"]
    })
    assert notify.load_mergers() == ["lead@lge.com"]


def test_load_mergers_returns_empty_when_not_configured(monkeypatch):
    monkeypatch.setattr(notify, "_load_notify_config", lambda: {
        "recipients": ["a@lge.com"]
    })
    assert notify.load_mergers() == []


def test_branch_push_html_contains_branch_and_merge_command(monkeypatch):
    monkeypatch.setenv("BRANCH_NAME", "feature/kim-data")
    monkeypatch.setenv("GITLAB_USER_NAME", "김철수")
    monkeypatch.setenv("CI_COMMIT_MESSAGE", "feat: add data pipeline")
    monkeypatch.setenv("CI_COMMIT_SHA", "abc12345")
    monkeypatch.setenv("CI_PROJECT_URL", "https://gitlab.com/team/project")
    html = notify._build_branch_push_html()
    assert "feature/kim-data" in html
    assert "aos merge feature/kim-data" in html
    assert "김철수" in html
    assert "feat: add data pipeline" in html
