"""ConstraintSynth — the full constraint-theory synthesizer."""

import struct
import wave

import numpy as np

from .oscillator import LatticeOscillator, UnisonOscillator
from .envelope import FunnelEnvelope, PitchEnvelope, FilterEnvelope
from .constraint_filter import (
    ConsonanceFilter, BiquadFilter, ModulatedBiquadFilter,
    SchroederReverb, FilterType,
)


class ConstraintSynth:
    """Lattice oscillator + funnel envelope + consonance filter + biquad + reverb.

    Now supports: pitch envelopes, filter envelopes, velocity sensitivity,
    stereo output, unison layering, multiple filter types with resonance.
    """

    def __init__(
        self,
        oscillator: LatticeOscillator | None = None,
        envelope: FunnelEnvelope | None = None,
        filter: ConsonanceFilter | None = None,
        filter_cutoff: float = 2000.0,
        reverb_wet: float = 0.3,
        # --- New parameters ---
        pitch_envelope: PitchEnvelope | None = None,
        filter_envelope: FilterEnvelope | None = None,
        filter_type: FilterType = "lowpass",
        filter_resonance: float = 0.707,
        velocity_sensitivity: float = 0.7,
        unison_voices: int = 1,
        unison_detune_cents: float = 0.0,
        stereo_width: float = 0.0,
        stereo_pan: float = 0.5,
    ):
        self.oscillator = oscillator or LatticeOscillator()
        self.envelope = envelope or FunnelEnvelope()
        self.filter = filter
        self.filter_cutoff = filter_cutoff
        self.reverb_wet = reverb_wet
        self.pitch_envelope = pitch_envelope or PitchEnvelope()
        self.filter_envelope = filter_envelope or FilterEnvelope()
        self.filter_type = filter_type
        self.filter_resonance = filter_resonance
        self.velocity_sensitivity = velocity_sensitivity
        self.unison_voices = unison_voices
        self.unison_detune_cents = unison_detune_cents
        self.stereo_width = stereo_width
        self.stereo_pan = stereo_pan

        # Create effects processors
        self._reverb = SchroederReverb(
            self.oscillator.sample_rate,
            wet=reverb_wet,
        )

    def play_note(self, pitch: int, velocity: int, duration: float) -> np.ndarray:
        """Generate a single note from MIDI parameters.

        Returns mono or stereo (N, 2) array depending on stereo_width.
        """
        sr = self.oscillator.sample_rate
        n_samples = int(sr * duration)

        # MIDI pitch → frequency
        freq = 440.0 * (2 ** ((pitch - 69) / 12.0))
        self.oscillator.frequency = freq

        # ── Velocity sensitivity ──
        # Higher velocity = louder AND brighter (higher effective cutoff)
        vel_norm = velocity / 127.0
        amp = vel_norm
        brightness_boost = 1.0 + (vel_norm - 0.5) * self.velocity_sensitivity
        brightness_boost = max(0.3, brightness_boost)

        # ── Generate oscillator ──
        if self.unison_voices > 1:
            unison = UnisonOscillator(
                base_oscillator=self.oscillator,
                voice_count=self.unison_voices,
                detune_cents=self.unison_detune_cents,
                stereo_spread=min(self.stereo_width, 1.0),
                velocity=velocity,
            )
            if self.pitch_envelope.active:
                signal = unison.generate_with_pitch_env(
                    duration,
                    self.pitch_envelope.start_ratio,
                    self.pitch_envelope.end_ratio,
                    self.pitch_envelope.decay,
                )
            else:
                signal = unison.generate(duration)
        else:
            if self.pitch_envelope.active:
                signal = self.oscillator.generate_with_pitch_env(
                    duration,
                    self.pitch_envelope.start_ratio,
                    self.pitch_envelope.end_ratio,
                    self.pitch_envelope.decay,
                )
            else:
                signal = self.oscillator.generate(duration)

        # ── Apply amplitude envelope ──
        signal = self.envelope.apply(signal, sr, duration)

        # ── Apply amplitude ──
        signal = signal * amp

        # ── Consonance filter ──
        if self.filter is not None:
            if signal.ndim == 2:
                left = self.filter.apply(signal[:, 0], freq, sr)
                right = self.filter.apply(signal[:, 1], freq, sr)
                signal = np.column_stack([left, right])
            else:
                signal = self.filter.apply(signal, freq, sr)

        # ── Biquad filter (with envelope modulation) ──
        if self.filter_cutoff > 0:
            is_stereo = signal.ndim == 2

            if is_stereo:
                # Process each channel separately
                left = signal[:, 0]
                right = signal[:, 1]
                left = self._apply_biquad_channel(left, sr, n_samples, brightness_boost)
                right = self._apply_biquad_channel(right, sr, n_samples, brightness_boost)
                signal = np.column_stack([left, right])
            else:
                signal = self._apply_biquad_channel(signal, sr, n_samples, brightness_boost)

        # ── Reverb ──
        if self.reverb_wet > 0:
            is_stereo = signal.ndim == 2
            if is_stereo:
                left, right = self._reverb.process_stereo(signal[:, 0], signal[:, 1])
                signal = np.column_stack([left, right])
            else:
                signal = self._reverb.process(signal)

        # ── Stereo panning (for mono signals) ──
        if signal.ndim == 1 and (self.stereo_pan != 0.5 or self.stereo_width > 0):
            pan = self.stereo_pan
            left = signal * (1.0 - pan) * 2
            right = signal * pan * 2
            signal = np.column_stack([left, right])

        return signal

    def _apply_biquad_channel(self, signal: np.ndarray, sr: int,
                              n_samples: int, brightness: float) -> np.ndarray:
        """Apply biquad filter to a mono channel with optional envelope."""
        effective_cutoff = self.filter_cutoff * brightness

        if self.filter_envelope.active:
            # Modulated filter: cutoff sweeps over time
            mod_filter = ModulatedBiquadFilter(
                filter_type=self.filter_type,
                cutoff_hz=effective_cutoff,
                sample_rate=sr,
                Q=self.filter_resonance,
            )
            cutoff_curve = self.filter_envelope.get_cutoff_curve(
                n_samples, sr, effective_cutoff)
            # Apply brightness to the curve
            cutoff_curve *= brightness
            return mod_filter.process_modulated(signal, cutoff_curve)
        else:
            # Static filter
            biquad = BiquadFilter(
                filter_type=self.filter_type,
                cutoff_hz=effective_cutoff,
                sample_rate=sr,
                Q=self.filter_resonance,
            )
            return biquad.process(signal)

    # ------------------------------------------------------------------
    # Presets
    # ------------------------------------------------------------------
    PRESETS = {
        "bop_sax": dict(
            oscillator=dict(lattice_shape="saw", lattice_stretch=1.0, use_polyblep=True),
            envelope=dict(attack=0.005, decay=0.08, sustain=0.75, release=0.15, hold=0.0),
            consonance_filter=dict(cutoff=0.5, resonance=1.0),
            filter_cutoff=3500.0,
            filter_type="lowpass",
            filter_resonance=0.8,
            reverb_wet=0.2,
            pitch_envelope=dict(start_ratio=1.0, end_ratio=1.0, decay=0.05),
            filter_envelope=dict(cutoff_start=5000.0, cutoff_end=2500.0, decay=0.08, amount=0.6),
            velocity_sensitivity=0.8,
            unison_voices=1,
            unison_detune_cents=0.0,
            stereo_width=0.3,
            stereo_pan=0.5,
        ),
        "blues_guitar": dict(
            oscillator=dict(lattice_shape="square", lattice_stretch=1.0, noise_floor=0.02),
            envelope=dict(attack=0.02, decay=0.15, sustain=0.6, release=0.4, hold=0.0),
            consonance_filter=dict(cutoff=0.4, resonance=1.2),
            filter_cutoff=1800.0,
            filter_type="lowpass",
            filter_resonance=1.2,
            reverb_wet=0.45,
            pitch_envelope=dict(start_ratio=1.02, end_ratio=1.0, decay=0.03),
            filter_envelope=dict(cutoff_start=4000.0, cutoff_end=1200.0, decay=0.15, amount=0.7),
            velocity_sensitivity=0.9,
            unison_voices=1,
            unison_detune_cents=0.0,
            stereo_width=0.4,
            stereo_pan=0.5,
        ),
        "techno_bass": dict(
            oscillator=dict(lattice_shape="saw", lattice_stretch=1.0),
            envelope=dict(attack=0.001, decay=0.3, sustain=0.0, release=0.1, hold=0.0),
            consonance_filter=None,
            filter_cutoff=800.0,
            filter_type="lowpass",
            filter_resonance=1.5,
            reverb_wet=0.0,
            pitch_envelope=dict(start_ratio=1.5, end_ratio=1.0, decay=0.04),
            filter_envelope=dict(cutoff_start=3000.0, cutoff_end=400.0, decay=0.1, amount=0.8),
            velocity_sensitivity=0.7,
            unison_voices=3,
            unison_detune_cents=15.0,
            stereo_width=0.0,
            stereo_pan=0.5,
        ),
        "piano_ballad": dict(
            oscillator=dict(lattice_shape="triangle", lattice_stretch=1.002),
            envelope=dict(attack=0.008, decay=0.5, sustain=0.4, release=0.8, hold=0.0),
            consonance_filter=dict(cutoff=0.6, resonance=0.8),
            filter_cutoff=4000.0,
            filter_type="lowpass",
            filter_resonance=0.707,
            reverb_wet=0.5,
            pitch_envelope=dict(start_ratio=1.0, end_ratio=1.0, decay=0.05),
            filter_envelope=dict(cutoff_start=6000.0, cutoff_end=3000.0, decay=0.3, amount=0.5),
            velocity_sensitivity=0.8,
            unison_voices=2,
            unison_detune_cents=5.0,
            stereo_width=0.5,
            stereo_pan=0.5,
        ),
        "808_kick": dict(
            oscillator=dict(lattice_shape="sine", lattice_stretch=1.0),
            envelope=dict(attack=0.001, decay=0.0, sustain=1.0, release=0.35, hold=0.0),
            consonance_filter=None,
            filter_cutoff=400.0,
            filter_type="lowpass",
            filter_resonance=2.0,
            reverb_wet=0.0,
            pitch_envelope=dict(start_ratio=4.0, end_ratio=1.0, decay=0.04),
            filter_envelope=dict(cutoff_start=2000.0, cutoff_end=200.0, decay=0.05, amount=0.9),
            velocity_sensitivity=0.9,
            unison_voices=1,
            unison_detune_cents=0.0,
            stereo_width=0.0,
            stereo_pan=0.5,
        ),
        "techno_lead": dict(
            oscillator=dict(lattice_shape="saw", lattice_stretch=1.0, use_polyblep=True),
            envelope=dict(attack=0.01, decay=0.2, sustain=0.5, release=0.15, hold=0.0),
            consonance_filter=None,
            filter_cutoff=3000.0,
            filter_type="lowpass",
            filter_resonance=2.5,
            reverb_wet=0.3,
            pitch_envelope=dict(start_ratio=1.0, end_ratio=1.0, decay=0.05),
            filter_envelope=dict(cutoff_start=6000.0, cutoff_end=2000.0, decay=0.2, amount=0.7),
            velocity_sensitivity=0.8,
            unison_voices=5,
            unison_detune_cents=20.0,
            stereo_width=0.7,
            stereo_pan=0.5,
        ),
        "techno_snare": dict(
            oscillator=dict(lattice_shape="triangle", lattice_stretch=1.0, noise_floor=0.3),
            envelope=dict(attack=0.001, decay=0.15, sustain=0.0, release=0.1, hold=0.0),
            consonance_filter=None,
            filter_cutoff=5000.0,
            filter_type="highpass",
            filter_resonance=0.707,
            reverb_wet=0.2,
            pitch_envelope=dict(start_ratio=0.5, end_ratio=1.0, decay=0.02),
            filter_envelope=dict(cutoff_start=8000.0, cutoff_end=3000.0, decay=0.05, amount=0.6),
            velocity_sensitivity=0.9,
            unison_voices=1,
            unison_detune_cents=0.0,
            stereo_width=0.0,
            stereo_pan=0.5,
        ),
        "ambient_pad": dict(
            oscillator=dict(lattice_shape="sine", lattice_stretch=1.001),
            envelope=dict(attack=0.3, decay=0.5, sustain=0.7, release=1.0, hold=0.0),
            consonance_filter=dict(cutoff=0.7, resonance=0.8),
            filter_cutoff=2500.0,
            filter_type="lowpass",
            filter_resonance=0.707,
            reverb_wet=0.6,
            pitch_envelope=dict(start_ratio=1.0, end_ratio=1.0, decay=0.05),
            filter_envelope=dict(cutoff_start=4000.0, cutoff_end=2000.0, decay=0.5, amount=0.4),
            velocity_sensitivity=0.5,
            unison_voices=7,
            unison_detune_cents=12.0,
            stereo_width=0.8,
            stereo_pan=0.5,
        ),
        "acid_bass": dict(
            oscillator=dict(lattice_shape="saw", lattice_stretch=1.0, use_polyblep=True),
            envelope=dict(attack=0.001, decay=0.2, sustain=0.0, release=0.08, hold=0.0),
            consonance_filter=None,
            filter_cutoff=1200.0,
            filter_type="lowpass",
            filter_resonance=4.0,
            reverb_wet=0.1,
            pitch_envelope=dict(start_ratio=1.2, end_ratio=1.0, decay=0.02),
            filter_envelope=dict(cutoff_start=6000.0, cutoff_end=600.0, decay=0.12, amount=0.95),
            velocity_sensitivity=0.8,
            unison_voices=1,
            unison_detune_cents=0.0,
            stereo_width=0.0,
            stereo_pan=0.5,
        ),
    }

    @classmethod
    def from_preset(cls, name: str) -> "ConstraintSynth":
        """Create a ConstraintSynth from a named preset."""
        if name not in cls.PRESETS:
            raise ValueError(f"Unknown preset '{name}'. Available: {list(cls.PRESETS)}")
        cfg = cls.PRESETS[name]
        osc = LatticeOscillator(**cfg["oscillator"])
        env = FunnelEnvelope(**cfg["envelope"])
        filt = ConsonanceFilter(**cfg["consonance_filter"]) if cfg.get("consonance_filter") else None
        pitch_env = PitchEnvelope(**cfg.get("pitch_envelope", {}))
        filter_env = FilterEnvelope(**cfg.get("filter_envelope", {}))
        return cls(
            oscillator=osc, envelope=env, filter=filt,
            filter_cutoff=cfg["filter_cutoff"],
            reverb_wet=cfg["reverb_wet"],
            pitch_envelope=pitch_env,
            filter_envelope=filter_env,
            filter_type=cfg.get("filter_type", "lowpass"),
            filter_resonance=cfg.get("filter_resonance", 0.707),
            velocity_sensitivity=cfg.get("velocity_sensitivity", 0.7),
            unison_voices=cfg.get("unison_voices", 1),
            unison_detune_cents=cfg.get("unison_detune_cents", 0.0),
            stereo_width=cfg.get("stereo_width", 0.0),
            stereo_pan=cfg.get("stereo_pan", 0.5),
        )

    @staticmethod
    def _crossfade(tail: np.ndarray, head: np.ndarray, samples: int = 64) -> tuple[np.ndarray, np.ndarray]:
        """Apply a short crossfade between the tail of one note and the head of the next."""
        samples = min(samples, len(tail), len(head))
        if samples <= 0:
            return tail, head
        fade_out = np.linspace(1, 0, samples)
        fade_in = np.linspace(0, 1, samples)
        # Handle stereo (N, 2)
        if tail.ndim == 2:
            fade_out = fade_out[:, np.newaxis]
            fade_in = fade_in[:, np.newaxis]
        tail[-samples:] *= fade_out
        head[:samples] = (head[:samples] * fade_in) + (tail[-samples:] * (1 - fade_in))
        return tail, head

    def render_melody(
        self,
        notes: list[tuple[int, int, float]],  # (pitch, velocity, duration)
        spacing: float = 0.05,
        crossfade_samples: int = 64,
    ) -> np.ndarray:
        """Render a sequence of notes into a single audio buffer."""
        sr = self.oscillator.sample_rate
        buffers: list[np.ndarray] = []
        for pitch, velocity, duration in notes:
            # Reset reverb state between notes for cleaner separation
            self._reverb.reset()
            note = self.play_note(pitch, velocity, duration)
            if buffers and crossfade_samples > 0:
                prev = buffers[-1]
                prev, note = self._crossfade(prev, note, crossfade_samples)
                buffers[-1] = prev
            buffers.append(note)
            if spacing > 0:
                if note.ndim == 2:
                    silence = np.zeros((int(sr * spacing), 2))
                else:
                    silence = np.zeros(int(sr * spacing))
                buffers.append(silence)
        return np.concatenate(buffers) if buffers else np.array([])

    @staticmethod
    def to_wav(signal: np.ndarray, path: str, sample_rate: int = 44100) -> None:
        """Save a numpy array as a 16-bit WAV file (mono or stereo)."""
        signal = np.clip(signal, -1.0, 1.0)
        if signal.ndim == 1:
            nchannels = 1
            data = (signal * 32767).astype(np.int16)
        else:
            nchannels = signal.shape[1]
            data = (signal * 32767).astype(np.int16)
        with wave.open(path, "w") as f:
            f.setnchannels(nchannels)
            f.setsampwidth(2)
            f.setframerate(sample_rate)
            f.writeframes(data.tobytes())

    @staticmethod
    def normalize(signal: np.ndarray, peak_db: float = -1.0) -> np.ndarray:
        """Normalize signal to peak_db below 0 dBFS."""
        peak = np.max(np.abs(signal))
        if peak > 0:
            target = 10 ** (peak_db / 20.0)
            signal = signal * (target / peak)
        return signal
