"""Funnel Envelope — ADSR as deadband funnel lifecycle + pitch envelopes."""

import numpy as np
from dataclasses import dataclass


@dataclass
class FunnelEnvelope:
    """
    ADSR envelope as deadband funnel.

    Attack = convergence rate, Sustain = equilibrium epsilon,
    Release = divergence. Hold = suspension plateau.
    """
    attack: float = 0.01   # convergence time (seconds)
    decay: float = 0.1     # relaxation time
    sustain: float = 0.7   # equilibrium epsilon (0-1)
    release: float = 0.3   # divergence time
    hold: float = 0.0      # suspension plateau

    def apply(self, signal: np.ndarray, sample_rate: int, note_duration: float) -> np.ndarray:
        """Apply envelope to signal."""
        n_samples = len(signal)
        if n_samples == 0:
            return signal

        envelope = np.zeros(n_samples)

        attack_samples = int(self.attack * sample_rate)
        decay_samples = int(self.decay * sample_rate)
        release_samples = int(self.release * sample_rate)
        hold_samples = int(self.hold * sample_rate)

        sustain_samples = (n_samples
                           - attack_samples
                           - decay_samples
                           - hold_samples
                           - release_samples)
        if sustain_samples < 0:
            sustain_samples = 0

        idx = 0

        # Attack — convergence ramp (0 → 1)
        if attack_samples > 0:
            end = min(attack_samples, n_samples)
            envelope[idx:end] = np.linspace(0, 1, end - idx)
            idx = end

        # Hold — suspension plateau at peak
        if hold_samples > 0 and idx < n_samples:
            end = min(idx + hold_samples, n_samples)
            envelope[idx:end] = 1.0
            idx = end

        # Decay — relaxation to pocket (1 → sustain)
        if decay_samples > 0 and idx < n_samples:
            end = min(idx + decay_samples, n_samples)
            envelope[idx:end] = np.linspace(1, self.sustain, end - idx)
            idx = end

        # Sustain — pocket equilibrium
        if sustain_samples > 0 and idx < n_samples:
            end = min(idx + sustain_samples, n_samples)
            envelope[idx:end] = self.sustain
            idx = end

        # Release — divergence (sustain → 0)
        if release_samples > 0 and idx < n_samples:
            remaining = min(release_samples, n_samples - idx)
            envelope[idx:idx + remaining] = np.linspace(self.sustain, 0, remaining)

        # Handle stereo (N, 2) or mono (N,)
        if signal.ndim == 2:
            return signal * envelope[:, np.newaxis]
        return signal * envelope


@dataclass
class PitchEnvelope:
    """Pitch envelope for percussive and expressive sounds.

    Creates frequency sweeps: kick drums sweep DOWN from high to low,
    snares sweep UP, 808s have deep sub-sweeps.

    start_ratio: frequency multiplier at note start (e.g. 4.0 = 2 octaves up)
    end_ratio: frequency multiplier at note end (1.0 = normal pitch)
    decay: time constant for exponential decay (seconds)
    """
    start_ratio: float = 1.0   # 1.0 = no sweep
    end_ratio: float = 1.0     # 1.0 = land at normal pitch
    decay: float = 0.05        # sweep time in seconds

    @property
    def active(self) -> bool:
        return self.start_ratio != 1.0 or self.end_ratio != 1.0

    def get_ratios(self, n_samples: int, sample_rate: int) -> np.ndarray:
        """Get per-sample pitch ratio array for oscillator pitch modulation."""
        if not self.active or n_samples == 0:
            return np.ones(n_samples)

        t = np.arange(n_samples) / sample_rate
        if self.decay > 0:
            alpha = 1.0 - np.exp(-t / self.decay)
        else:
            alpha = np.ones(n_samples)
        return self.start_ratio + (self.end_ratio - self.start_ratio) * alpha


@dataclass
class FilterEnvelope:
    """Filter cutoff envelope for dynamic timbral shaping.

    The filter cutoff sweeps from cutoff_start → cutoff_end over time,
    creating the classic "wah" or "pluck" effect.

    cutoff_start: starting cutoff frequency (Hz)
    cutoff_end: ending cutoff frequency (Hz)
    decay: time constant (seconds) — shorter = snappier
    amount: envelope depth (0-1), 0 = no effect
    """
    cutoff_start: float = 5000.0  # Hz — bright initial attack
    cutoff_end: float = 1000.0    # Hz — darker sustain
    decay: float = 0.1            # seconds
    amount: float = 0.0           # 0 = disabled, 1 = full sweep

    @property
    def active(self) -> bool:
        return self.amount > 0.0

    def get_cutoff_curve(self, n_samples: int, sample_rate: int,
                         base_cutoff: float) -> np.ndarray:
        """Get per-sample cutoff frequency array.

        base_cutoff: the static cutoff from the synth preset.
        When active, interpolates between cutoff_start and cutoff_end,
        then blends with base_cutoff based on amount.
        """
        if not self.active or n_samples == 0:
            return np.full(n_samples, base_cutoff)

        t = np.arange(n_samples) / sample_rate
        if self.decay > 0:
            alpha = 1.0 - np.exp(-t / self.decay)
        else:
            alpha = np.ones(n_samples)

        sweep = self.cutoff_start + (self.cutoff_end - self.cutoff_start) * alpha
        # Blend sweep with base cutoff based on amount
        return sweep * self.amount + base_cutoff * (1.0 - self.amount)
