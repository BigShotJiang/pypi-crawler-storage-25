"""Constraint Synthesizer — where waveshape IS lattice geometry."""

from .oscillator import LatticeOscillator
from .envelope import FunnelEnvelope, PitchEnvelope, FilterEnvelope
from .constraint_filter import (
    ConsonanceFilter, BiquadFilter, ModulatedBiquadFilter,
    SchroederReverb, FilterType,
)
from .synth import ConstraintSynth
from .playback import AudioPlayer
from .midi_renderer import MIDIRenderer
from .sound_engine import (
    SoundEngine as HighQualitySoundEngine,
    UnisonOscillator,
    StereoWidth,
    ChorusEffect,
    EnvelopeFollower,
    build_sound_engine,
    HIGH_QUALITY_PRESETS,
)
from .play_along import (
    PlayAlong,
    PlayAlongConfig,
    ResponseStrategy,
    ResponseEvent,
    auto_strategy,
)

__all__ = [
    "LatticeOscillator",
    "UnisonOscillator",
    "FunnelEnvelope",
    "PitchEnvelope",
    "FilterEnvelope",
    "ConsonanceFilter",
    "BiquadFilter",
    "ModulatedBiquadFilter",
    "SchroederReverb",
    "ConstraintSynth",
    "AudioPlayer",
    "MIDIRenderer",
    "HighQualitySoundEngine",
    "StereoWidth",
    "ChorusEffect",
    "EnvelopeFollower",
    "build_sound_engine",
    "HIGH_QUALITY_PRESETS",
    "PlayAlong",
    "PlayAlongConfig",
    "ResponseStrategy",
    "ResponseEvent",
    "auto_strategy",
]
