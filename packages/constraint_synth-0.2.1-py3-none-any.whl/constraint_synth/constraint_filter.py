"""Filters — consonance filter, biquad (LP/HP/BP/Notch), and Schroeder reverb."""

import numpy as np
from math import cos, pi, sin
from dataclasses import dataclass
from typing import Literal


# Harmonic series ratios (consonant with fundamental)
CONSONANT_RATIOS = [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0]


class ConsonanceFilter:
    """
    A filter that passes consonant harmonics and attenuates dissonant ones.

    cutoff: 0.0 = only unisons pass, 1.0 = everything passes
    resonance: constraint tightness (higher = sharper rolloff)
    """
    def __init__(self, cutoff: float = 0.5, resonance: float = 1.0):
        self.cutoff = cutoff
        self.resonance = resonance

    def apply(self, signal: np.ndarray, fundamental: float, sample_rate: int) -> np.ndarray:
        """Filter harmonics based on consonance with fundamental."""
        if fundamental <= 0 or len(signal) == 0:
            return signal

        spectrum = np.fft.rfft(signal)
        freqs = np.fft.rfftfreq(len(signal), 1.0 / sample_rate)

        for i, freq in enumerate(freqs):
            if freq < 20:
                continue
            ratio = freq / fundamental
            distances = [abs(ratio - cr) for cr in CONSONANT_RATIOS]
            min_dist = min(distances)
            consonance = max(0.0, 1.0 - min_dist)
            if consonance < self.cutoff:
                attenuation = (consonance / self.cutoff) ** self.resonance
                spectrum[i] *= attenuation

        return np.fft.irfft(spectrum, len(signal))


# ── Biquad Filter (LP / HP / BP / Notch) ───────────────────────────

FilterType = Literal["lowpass", "highpass", "bandpass", "notch"]


class BiquadFilter:
    """Second-order IIR biquad filter supporting LP, HP, BP, and notch.

    Based on the Audio EQ Cookbook by Robert Bristow-Johnson.
    Supports resonance (Q factor) for all filter types.
    """

    def __init__(self, filter_type: FilterType = "lowpass",
                 cutoff_hz: float = 2000.0, sample_rate: int = 44100,
                 Q: float = 0.707):
        self.filter_type = filter_type
        self.cutoff_hz = cutoff_hz
        self.sample_rate = sample_rate
        self.Q = max(Q, 0.1)  # prevent instability
        self._compute_coefficients()
        self.w = [0.0, 0.0]  # Direct Form II Transposed state

    def _compute_coefficients(self):
        """Compute biquad coefficients from filter type and parameters."""
        omega = 2 * pi * self.cutoff_hz / self.sample_rate
        # Clamp omega to avoid instability near Nyquist
        omega = min(omega, pi * 0.99)
        alpha = sin(omega) / (2 * self.Q)

        ft = self.filter_type

        if ft == "lowpass":
            b0 = (1 - cos(omega)) / 2
            b1 = 1 - cos(omega)
            b2 = (1 - cos(omega)) / 2
            a0 = 1 + alpha
            a1 = -2 * cos(omega)
            a2 = 1 - alpha
        elif ft == "highpass":
            b0 = (1 + cos(omega)) / 2
            b1 = -(1 + cos(omega))
            b2 = (1 + cos(omega)) / 2
            a0 = 1 + alpha
            a1 = -2 * cos(omega)
            a2 = 1 - alpha
        elif ft == "bandpass":
            b0 = alpha
            b1 = 0
            b2 = -alpha
            a0 = 1 + alpha
            a1 = -2 * cos(omega)
            a2 = 1 - alpha
        elif ft == "notch":
            b0 = 1
            b1 = -2 * cos(omega)
            b2 = 1
            a0 = 1 + alpha
            a1 = -2 * cos(omega)
            a2 = 1 - alpha
        else:
            raise ValueError(f"Unknown filter type: {ft}")

        self.b = [b0 / a0, b1 / a0, b2 / a0]
        self.a = [a1 / a0, a2 / a0]

    def set_cutoff(self, cutoff_hz: float):
        """Update cutoff frequency (recalculates coefficients)."""
        self.cutoff_hz = cutoff_hz
        self._compute_coefficients()

    def reset(self):
        """Clear filter state."""
        self.w = [0.0, 0.0]

    def process(self, samples: np.ndarray) -> np.ndarray:
        """Process a numpy array of samples through the filter."""
        output = np.zeros_like(samples)
        for i, x in enumerate(samples):
            y = self.b[0] * x + self.w[0]
            self.w[0] = self.b[1] * x - self.a[0] * y + self.w[1]
            self.w[1] = self.b[2] * x - self.a[1] * y
            output[i] = y
        return output


class ModulatedBiquadFilter:
    """Biquad filter with time-varying cutoff (for filter envelopes).

    Recalculates coefficients per-sample from a cutoff curve.
    """

    def __init__(self, filter_type: FilterType = "lowpass",
                 cutoff_hz: float = 2000.0, sample_rate: int = 44100,
                 Q: float = 0.707):
        self.filter_type = filter_type
        self.sample_rate = sample_rate
        self.Q = max(Q, 0.1)
        self.w = [0.0, 0.0]

    def _coefficients_at(self, cutoff_hz: float):
        """Compute biquad coefficients for a given cutoff."""
        omega = 2 * pi * cutoff_hz / self.sample_rate
        omega = min(omega, pi * 0.99)
        alpha = sin(omega) / (2 * self.Q)

        ft = self.filter_type
        if ft == "lowpass":
            b0 = (1 - cos(omega)) / 2
            b1 = 1 - cos(omega)
            b2 = (1 - cos(omega)) / 2
            a0 = 1 + alpha
            a1 = -2 * cos(omega)
            a2 = 1 - alpha
        elif ft == "highpass":
            b0 = (1 + cos(omega)) / 2
            b1 = -(1 + cos(omega))
            b2 = (1 + cos(omega)) / 2
            a0 = 1 + alpha
            a1 = -2 * cos(omega)
            a2 = 1 - alpha
        elif ft == "bandpass":
            b0 = alpha
            b1 = 0
            b2 = -alpha
            a0 = 1 + alpha
            a1 = -2 * cos(omega)
            a2 = 1 - alpha
        elif ft == "notch":
            b0 = 1
            b1 = -2 * cos(omega)
            b2 = 1
            a0 = 1 + alpha
            a1 = -2 * cos(omega)
            a2 = 1 - alpha
        else:
            raise ValueError(f"Unknown filter type: {ft}")

        return [b0 / a0, b1 / a0, b2 / a0], [a1 / a0, a2 / a0]

    def reset(self):
        self.w = [0.0, 0.0]

    def process_modulated(self, samples: np.ndarray,
                          cutoff_curve: np.ndarray) -> np.ndarray:
        """Process samples with time-varying cutoff frequency.

        cutoff_curve: array of cutoff frequencies (same length as samples).
        """
        output = np.zeros_like(samples)
        w0, w1 = self.w

        for i, x in enumerate(samples):
            b, a = self._coefficients_at(cutoff_curve[i])
            y = b[0] * x + w0
            w0 = b[1] * x - a[0] * y + w1
            w1 = b[2] * x - a[1] * y
            output[i] = y

        self.w = [w0, w1]
        return output


# ── Schroeder Reverb ────────────────────────────────────────────────

class SchroederReverb:
    """Schroeder reverb: 4 parallel comb filters + 2 series allpass filters."""

    def __init__(self, sample_rate: int = 44100, feedback: float = 0.84,
                 wet: float = 0.3, damping: float = 0.2):
        # Comb filter delay lengths (coprime for decorrelation)
        self.comb_delays = [1557, 1617, 1491, 1422]
        # Allpass delay lengths
        self.allpass_delays = [225, 556]

        self.combs = [np.zeros(d, dtype=np.float64) for d in self.comb_delays]
        self.comb_idx = [0] * 4
        self.allpasses = [np.zeros(d, dtype=np.float64) for d in self.allpass_delays]
        self.ap_idx = [0] * 2
        self.feedback = feedback
        self.wet = wet
        self.ap_gain = 0.5
        self.damping = damping  # lowpass damping in comb feedback
        self._damp_state = [0.0] * 4  # per-comb damping state

    def reset(self):
        """Clear all delay lines."""
        for buf in self.combs:
            buf[:] = 0
        for buf in self.allpasses:
            buf[:] = 0
        self.comb_idx = [0] * 4
        self.ap_idx = [0] * 2
        self._damp_state = [0.0] * 4

    def _process_combs(self, samples: np.ndarray) -> np.ndarray:
        """Run 4 parallel comb filters with damping and sum."""
        output = np.zeros_like(samples)
        for k in range(4):
            buf = self.combs[k]
            idx = self.comb_idx[k]
            damp_state = self._damp_state[k]
            for i, x in enumerate(samples):
                delayed = buf[idx]
                # One-pole lowpass in feedback path for damping
                damp_state = self.damping * delayed + (1 - self.damping) * damp_state
                buf[idx] = x + self.feedback * damp_state
                output[i] += delayed
                idx = (idx + 1) % len(buf)
            self.comb_idx[k] = idx
            self._damp_state[k] = damp_state
        return output / 4.0

    def _process_allpasses(self, samples: np.ndarray) -> np.ndarray:
        """Run 2 series allpass filters."""
        signal = samples
        for k in range(2):
            buf = self.allpasses[k]
            idx = self.ap_idx[k]
            out = np.zeros_like(signal)
            for i, x in enumerate(signal):
                delayed = buf[idx]
                buf[idx] = x + self.ap_gain * delayed
                out[i] = delayed - self.ap_gain * x
                idx = (idx + 1) % len(buf)
            self.ap_idx[k] = idx
            signal = out
        return signal

    def process(self, samples: np.ndarray) -> np.ndarray:
        """Process samples: parallel combs → series allpasses → dry/wet mix."""
        if self.wet <= 0 or len(samples) == 0:
            return samples.copy()
        comb_out = self._process_combs(samples)
        reverb = self._process_allpasses(comb_out)
        return samples * (1.0 - self.wet) + reverb * self.wet

    def process_stereo(self, left: np.ndarray, right: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """Process stereo with slight decorrelation between channels."""
        rev_l = self.process(left)
        # Flip comb delays for right channel decorrelation
        saved = self.combs[:]
        self.combs = [buf[::-1].copy() for buf in saved]
        self.comb_idx = [0] * 4
        self._damp_state = [0.0] * 4
        rev_r = self.process(right)
        self.combs = saved
        return rev_l, rev_r
