"""Lattice Oscillator — waveshape as lattice geometry, with anti-aliased synthesis."""

import numpy as np
from dataclasses import dataclass, field
from typing import Literal


@dataclass
class LatticeOscillator:
    """
    An oscillator where waveshape IS lattice geometry.

    sine: continuous, no snapping (epsilon=inf)
    square: binary snap (Z2 — only 2 directions)
    saw: ramp through lattice (Z — linear interpolation + snap)
    triangle: A2 snap (our Eisenstein lattice in 1D)
    eisenstein: full A2 lattice (hexagonal tiling)
    """
    frequency: float = 440.0      # Hz
    sample_rate: int = 44100
    lattice_shape: Literal["sine", "square", "saw", "triangle", "eisenstein"] = "sine"
    lattice_stretch: float = 1.0  # 1.0=harmonic, 1.002=piano, 1.5=bell
    noise_floor: float = 0.0      # 0-1, jitter that never converges
    snap_threshold: float = 1.0   # 0=soft snap, 1=hard snap
    use_polyblep: bool = True     # enable PolyBLEP anti-aliasing

    # ── Vectorised PolyBLEP ──────────────────────────────────────────

    @staticmethod
    def _polyblep_correct_vec(phase_inc: float, norm_phase: np.ndarray,
                              direction: Literal["rising", "falling"] = "rising") -> np.ndarray:
        """Vectorised PolyBLEP correction at phase-wrap discontinuities.

        Uses 2-point polynomial: corrects the first-order discontinuity
        at the wrap boundary (phase 0 ≡ 1).
        """
        if phase_inc <= 0:
            return np.zeros_like(norm_phase)

        correction = np.zeros_like(norm_phase)
        t = np.empty_like(norm_phase)

        # Before wrap: phase ∈ [1 - phase_inc, 1)
        mask_before = norm_phase >= (1.0 - phase_inc)
        t[mask_before] = (norm_phase[mask_before] - 1.0) / phase_inc  # (-1, 0]
        # After wrap: phase ∈ [0, phase_inc)
        mask_after = (~mask_before) & (norm_phase < phase_inc)
        t[mask_after] = norm_phase[mask_after] / phase_inc  # [0, 1)

        # Before wrap: val = 2t + t²  (t < 0, so val < 0)
        correction[mask_before] = 2 * t[mask_before] + t[mask_before] ** 2
        # After wrap: val = 2t - t²  (t > 0, so val > 0)
        correction[mask_after] = 2 * t[mask_after] - t[mask_after] ** 2

        if direction == "falling":
            correction = -correction
        return correction

    def generate(self, duration: float) -> np.ndarray:
        """Generate audio samples with anti-aliased waveshapes."""
        n_samples = int(self.sample_rate * duration)
        if n_samples == 0:
            return np.array([], dtype=np.float64)
        t = np.linspace(0, duration, n_samples, endpoint=False)
        phase = 2 * np.pi * self.frequency * t
        norm_phase = (phase / (2 * np.pi)) % 1.0  # normalised [0, 1)
        phase_inc = self.frequency / self.sample_rate

        if self.lattice_shape == "sine":
            signal = np.sin(phase)
        elif self.lattice_shape == "square":
            signal = np.sign(np.sin(phase))
            if self.use_polyblep and phase_inc < 0.5:
                signal += self._polyblep_correct_vec(phase_inc, norm_phase, "rising")
                shifted = (norm_phase - 0.5) % 1.0
                signal += self._polyblep_correct_vec(phase_inc, shifted, "falling")
        elif self.lattice_shape == "saw":
            signal = 2 * norm_phase - 1
            if self.use_polyblep and phase_inc < 0.5:
                signal -= self._polyblep_correct_vec(phase_inc, norm_phase, "rising")
        elif self.lattice_shape == "triangle":
            # Triangle = integrate square, so it's already bandlimited if square is
            signal = 2 * np.abs(2 * norm_phase - 1) - 1
        elif self.lattice_shape == "eisenstein":
            raw = np.sin(phase)
            signal = self._eisenstein_snap(raw)
        else:
            raise ValueError(f"Unknown lattice_shape: {self.lattice_shape}")

        # Apply inharmonicity (lattice stretch)
        if self.lattice_stretch != 1.0:
            harmonic = np.sin(phase * 2 * self.lattice_stretch) * 0.3
            signal = signal + harmonic

        # Apply noise floor (irreducible jitter)
        if self.noise_floor > 0:
            noise = np.random.normal(0, self.noise_floor * 0.1, len(signal))
            signal = signal + noise

        return signal

    def generate_with_pitch_env(self, duration: float,
                                pitch_start: float = 1.0,
                                pitch_end: float = 1.0,
                                pitch_decay: float = 0.05) -> np.ndarray:
        """Generate with a pitch envelope (frequency sweep).

        pitch_start/pitch_end are multipliers on self.frequency.
        pitch_decay is the exponential time constant in seconds.
        """
        n_samples = int(self.sample_rate * duration)
        if n_samples == 0:
            return np.array([], dtype=np.float64)

        t = np.linspace(0, duration, n_samples, endpoint=False)
        # Exponential pitch sweep from pitch_start → pitch_end
        if pitch_decay > 0:
            alpha = 1.0 - np.exp(-t / pitch_decay)
            pitch_mult = pitch_start + (pitch_end - pitch_start) * alpha
        else:
            pitch_mult = np.full(n_samples, pitch_end)

        # Compute instantaneous phase by integrating frequency
        freq_t = self.frequency * pitch_mult
        inst_phase = 2 * np.pi * np.cumsum(freq_t) / self.sample_rate
        norm_phase = (inst_phase / (2 * np.pi)) % 1.0

        if self.lattice_shape == "sine":
            signal = np.sin(inst_phase)
        elif self.lattice_shape == "square":
            signal = np.sign(np.sin(inst_phase))
            # PolyBLEP with varying phase increment
            for i in range(n_samples):
                pi = freq_t[i] / self.sample_rate
                if pi >= 0.5:
                    continue
                # Rising edge at wrap
                p = norm_phase[i]
                if p >= 1.0 - pi:
                    tt = (p - 1.0) / pi
                    signal[i] += 2 * tt + tt * tt
                elif p < pi:
                    tt = p / pi
                    signal[i] += 2 * tt - tt * tt
                # Falling edge at 0.5
                sp = (p - 0.5) % 1.0
                if sp >= 1.0 - pi:
                    tt = (sp - 1.0) / pi
                    signal[i] -= 2 * tt + tt * tt
                elif sp < pi:
                    tt = sp / pi
                    signal[i] -= 2 * tt - tt * tt
        elif self.lattice_shape == "saw":
            signal = 2 * norm_phase - 1
            # PolyBLEP correction for varying phase
            for i in range(n_samples):
                pi = freq_t[i] / self.sample_rate
                if pi >= 0.5:
                    continue
                p = norm_phase[i]
                if p >= 1.0 - pi:
                    tt = (p - 1.0) / pi
                    signal[i] -= 2 * tt + tt * tt
                elif p < pi:
                    tt = p / pi
                    signal[i] -= 2 * tt - tt * tt
        elif self.lattice_shape == "triangle":
            signal = 2 * np.abs(2 * norm_phase - 1) - 1
        elif self.lattice_shape == "eisenstein":
            raw = np.sin(inst_phase)
            signal = self._eisenstein_snap(raw)
        else:
            raise ValueError(f"Unknown lattice_shape: {self.lattice_shape}")

        if self.lattice_stretch != 1.0:
            harmonic = np.sin(inst_phase * 2 * self.lattice_stretch) * 0.3
            signal = signal + harmonic

        if self.noise_floor > 0:
            noise = np.random.normal(0, self.noise_floor * 0.1, len(signal))
            signal = signal + noise

        return signal

    def _eisenstein_snap(self, values: np.ndarray) -> np.ndarray:
        """Snap continuous values to Eisenstein lattice directions."""
        levels = 6
        scaled = values * levels / 2
        snapped_levels = np.round(scaled) / (levels / 2)
        return values + (snapped_levels - values) * self.snap_threshold


@dataclass
class UnisonOscillator:
    """Stack multiple detuned oscillators for thickness (unison).

    Used for supersaw-style sounds and thick pads.
    """
    base_oscillator: LatticeOscillator = field(default_factory=LatticeOscillator)
    voice_count: int = 1           # number of detuned voices (1 = mono, 3-7 typical)
    detune_cents: float = 0.0      # max detune in cents between voices
    stereo_spread: float = 0.0     # 0=mono, 1=full stereo spread
    velocity: int = 100            # MIDI velocity 0-127

    def generate(self, duration: float) -> np.ndarray:
        """Generate unison signal. Returns mono or stereo (N, 2) array."""
        if self.voice_count <= 1:
            return self.base_oscillator.generate(duration)

        signals = []
        pans = []
        for i in range(self.voice_count):
            # Distribute detune symmetrically around center
            voice_offset = (i - (self.voice_count - 1) / 2.0) / max(1, (self.voice_count - 1) / 2.0)
            detune_ratio = 2.0 ** (voice_offset * self.detune_cents / 1200.0)

            osc = LatticeOscillator(
                frequency=self.base_oscillator.frequency * detune_ratio,
                sample_rate=self.base_oscillator.sample_rate,
                lattice_shape=self.base_oscillator.lattice_shape,
                lattice_stretch=self.base_oscillator.lattice_stretch,
                noise_floor=self.base_oscillator.noise_floor,
                snap_threshold=self.base_oscillator.snap_threshold,
                use_polyblep=self.base_oscillator.use_polyblep,
            )
            sig = osc.generate(duration)
            signals.append(sig)
            # Pan: distribute voices across stereo field
            pans.append(0.5 + voice_offset * self.stereo_spread * 0.5)  # 0=left, 1=right

        # Mix voices with level compensation
        mix = np.sum(signals, axis=0) / self.voice_count

        if self.stereo_spread > 0:
            left = np.zeros_like(mix)
            right = np.zeros_like(mix)
            for sig, pan in zip(signals, pans):
                left += sig * (1.0 - pan)
                right += sig * pan
            left /= self.voice_count
            right /= self.voice_count
            return np.column_stack([left, right])

        return mix

    def generate_with_pitch_env(self, duration: float,
                                pitch_start: float = 1.0,
                                pitch_end: float = 1.0,
                                pitch_decay: float = 0.05) -> np.ndarray:
        """Generate unison with pitch envelope."""
        if self.voice_count <= 1:
            return self.base_oscillator.generate_with_pitch_env(
                duration, pitch_start, pitch_end, pitch_decay)

        # For unison with pitch env, generate each voice separately
        signals = []
        pans = []
        for i in range(self.voice_count):
            voice_offset = (i - (self.voice_count - 1) / 2.0) / max(1, (self.voice_count - 1) / 2.0)
            detune_ratio = 2.0 ** (voice_offset * self.detune_cents / 1200.0)

            osc = LatticeOscillator(
                frequency=self.base_oscillator.frequency * detune_ratio,
                sample_rate=self.base_oscillator.sample_rate,
                lattice_shape=self.base_oscillator.lattice_shape,
                lattice_stretch=self.base_oscillator.lattice_stretch,
                noise_floor=self.base_oscillator.noise_floor,
                snap_threshold=self.base_oscillator.snap_threshold,
                use_polyblep=self.base_oscillator.use_polyblep,
            )
            sig = osc.generate_with_pitch_env(duration, pitch_start, pitch_end, pitch_decay)
            signals.append(sig)
            pans.append(0.5 + voice_offset * self.stereo_spread * 0.5)

        if self.stereo_spread > 0:
            left = np.zeros_like(signals[0])
            right = np.zeros_like(signals[0])
            for sig, pan in zip(signals, pans):
                left += sig * (1.0 - pan)
                right += sig * pan
            left /= self.voice_count
            right /= self.voice_count
            return np.column_stack([left, right])

        return np.sum(signals, axis=0) / self.voice_count
