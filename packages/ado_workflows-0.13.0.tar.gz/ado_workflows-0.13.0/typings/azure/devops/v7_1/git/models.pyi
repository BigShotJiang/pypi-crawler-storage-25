"""Partial stubs for azure.devops.v7_1.git.models — only types used by ado-workflows."""

from __future__ import annotations

from datetime import datetime
from typing import Any

class IdentityRef:
    display_name: str
    unique_name: str
    id: str

class GitItem:
    path: str | None
    is_folder: bool | None
    is_sym_link: bool | None
    git_object_type: str | None
    object_id: str | None
    commit_id: str | None
    url: str | None
    content: str | None
    original_object_id: str | None
    def __init__(
        self,
        *,
        path: str | None = None,
        is_folder: bool | None = None,
        is_sym_link: bool | None = None,
        git_object_type: str | None = None,
        object_id: str | None = None,
        commit_id: str | None = None,
        url: str | None = None,
        content: str | None = None,
        original_object_id: str | None = None,
        **kwargs: Any,
    ) -> None: ...

class CommentPosition:
    line: int
    offset: int
    def __init__(
        self,
        *,
        line: int | None = None,
        offset: int | None = None,
    ) -> None: ...

class CommentThreadContext:
    file_path: str | None
    left_file_start: CommentPosition | None
    left_file_end: CommentPosition | None
    right_file_start: CommentPosition | None
    right_file_end: CommentPosition | None
    def __init__(
        self,
        *,
        file_path: str | None = None,
        left_file_start: CommentPosition | None = None,
        left_file_end: CommentPosition | None = None,
        right_file_start: CommentPosition | None = None,
        right_file_end: CommentPosition | None = None,
    ) -> None: ...

class Comment:
    author: IdentityRef
    content: str | None
    id: int
    is_deleted: bool | None
    parent_comment_id: int | None
    published_date: str | None
    def __init__(
        self,
        *,
        content: str | None = None,
        parent_comment_id: int | None = None,
        author: IdentityRef | None = None,
        id: int | None = None,
        is_deleted: bool | None = None,
        published_date: str | None = None,
        **kwargs: Any,
    ) -> None: ...

class GitPullRequestCommentThread:
    id: int
    status: str | None
    comments: list[Comment] | None
    thread_context: CommentThreadContext | None
    pull_request_thread_context: GitPullRequestCommentThreadContext | None
    properties: dict[str, Any] | None
    identities: dict[str, IdentityRef] | None
    published_date: datetime | None
    is_deleted: bool | None
    def __init__(
        self,
        *,
        comments: list[Comment] | None = None,
        status: str | None = None,
        id: int | None = None,
        thread_context: CommentThreadContext | None = None,
        pull_request_thread_context: GitPullRequestCommentThreadContext | None = None,
        properties: dict[str, Any] | None = None,
        identities: dict[str, IdentityRef] | None = None,
        published_date: datetime | None = None,
        is_deleted: bool | None = None,
        **kwargs: Any,
    ) -> None: ...

class GitPullRequestSearchCriteria:
    status: str | None
    creator_id: str | None
    reviewer_id: str | None
    def __init__(
        self,
        *,
        status: str | None = None,
        creator_id: str | None = None,
        reviewer_id: str | None = None,
        **kwargs: Any,
    ) -> None: ...

class _VotedForRef:
    id: str

class IdentityRefWithVote:
    display_name: str | None
    unique_name: str | None
    id: str | None
    vote: int | None
    is_container: bool | None
    is_required: bool | None
    voted_for: list[_VotedForRef] | None
    def __init__(
        self,
        *,
        display_name: str | None = None,
        unique_name: str | None = None,
        id: str | None = None,
        vote: int | None = None,
        is_container: bool | None = None,
        is_required: bool | None = None,
        voted_for: list[_VotedForRef] | None = None,
        **kwargs: Any,
    ) -> None: ...

class GitUserDate:
    date: datetime
    email: str | None
    name: str | None

class GitCommitRef:
    author: GitUserDate
    commit_id: str | None
    def __init__(
        self,
        *,
        author: GitUserDate | None = None,
        commit_id: str | None = None,
        **kwargs: Any,
    ) -> None: ...

class TeamProjectReference:
    id: str
    name: str

class GitRepository:
    name: str
    web_url: str
    id: str
    project: TeamProjectReference

class GitPullRequest:
    pull_request_id: int
    title: str
    url: str
    source_ref_name: str
    target_ref_name: str
    is_draft: bool
    status: str | None
    merge_status: str | None
    creation_date: datetime | None
    created_by: IdentityRef
    reviewers: list[IdentityRefWithVote] | None
    description: str | None
    last_merge_source_commit: GitCommitRef | None
    labels: list[WebApiTagDefinition] | None
    work_item_refs: list[ResourceRef] | None
    completion_options: GitPullRequestCompletionOptions | None
    repository: GitRepository
    def __init__(
        self,
        *,
        source_ref_name: str | None = None,
        target_ref_name: str | None = None,
        title: str | None = None,
        description: str | None = None,
        is_draft: bool | None = None,
        status: str | None = None,
        completion_options: GitPullRequestCompletionOptions | None = None,
        **kwargs: Any,
    ) -> None: ...

class CommentIterationContext:
    first_comparing_iteration: int
    second_comparing_iteration: int
    def __init__(
        self,
        *,
        first_comparing_iteration: int | None = None,
        second_comparing_iteration: int | None = None,
    ) -> None: ...

class GitPullRequestCommentThreadContext:
    change_tracking_id: int
    iteration_context: CommentIterationContext | None
    def __init__(
        self,
        *,
        change_tracking_id: int | None = None,
        iteration_context: CommentIterationContext | None = None,
    ) -> None: ...

class GitPullRequestIteration:
    id: int
    created_date: datetime | None
    description: str | None
    def __init__(
        self,
        *,
        id: int | None = None,
        created_date: datetime | None = None,
        description: str | None = None,
        **kwargs: Any,
    ) -> None: ...

class GitPullRequestChange:
    change_tracking_id: int
    additional_properties: dict[str, Any]
    def __init__(
        self,
        *,
        change_tracking_id: int | None = None,
    ) -> None: ...

class GitPullRequestIterationChanges:
    change_entries: list[GitPullRequestChange]
    next_skip: int | None
    next_top: int | None
    def __init__(
        self,
        *,
        change_entries: list[GitPullRequestChange] | None = None,
        next_skip: int | None = None,
        next_top: int | None = None,
    ) -> None: ...

class GitVersionDescriptor:
    version: str | None
    version_type: str | None
    def __init__(
        self,
        *,
        version: str | None = None,
        version_type: str | None = None,
    ) -> None: ...

class GitPullRequestCompletionOptions:
    merge_strategy: str | None
    delete_source_branch: bool | None
    transition_work_items: bool | None
    merge_commit_message: str | None
    bypass_policy: bool | None
    bypass_reason: str | None
    def __init__(
        self,
        *,
        merge_strategy: str | None = None,
        delete_source_branch: bool | None = None,
        transition_work_items: bool | None = None,
        merge_commit_message: str | None = None,
        bypass_policy: bool | None = None,
        bypass_reason: str | None = None,
        **kwargs: Any,
    ) -> None: ...

class WebApiTagDefinition:
    id: str
    name: str
    active: bool | None
    url: str | None

class WebApiCreateTagRequestData:
    name: str
    def __init__(
        self,
        *,
        name: str | None = None,
        **kwargs: Any,
    ) -> None: ...

class ResourceRef:
    id: str
    url: str
