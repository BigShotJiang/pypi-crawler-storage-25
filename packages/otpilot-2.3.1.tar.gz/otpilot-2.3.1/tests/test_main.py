import importlib
import json

from click.testing import CliRunner


def _load_main(monkeypatch, tmp_config_dir):
    import otpilot.logger as logger_module

    monkeypatch.setattr(logger_module, "LOG_FILE", str(tmp_config_dir / "otpilot.log"))

    import otpilot.main as main

    main = importlib.reload(main)
    monkeypatch.setattr(main, "LOG_FILE", str(tmp_config_dir / "otpilot.log"))
    monkeypatch.setattr(main, "PID_FILE", str(tmp_config_dir / "otpilot.pid"))
    return main


def test_version_command(tmp_config_dir, monkeypatch):
    """Prints the current version."""
    main = _load_main(monkeypatch, tmp_config_dir)
    runner = CliRunner()

    result = runner.invoke(main.cli, ["version"])

    assert result.exit_code == 0
    assert "2.2.0" in result.output


def test_status_when_configured(monkeypatch, tmp_config_dir):
    """Shows configured status when config exists."""
    main = _load_main(monkeypatch, tmp_config_dir)
    runner = CliRunner()

    monkeypatch.setattr(main, "config_exists", lambda: True)
    monkeypatch.setattr(main, "token_exists", lambda: True)
    monkeypatch.setattr(main, "get_config", lambda: {"hotkey": "ctrl+x", "notify_on_copy": True})

    result = runner.invoke(main.cli, ["status"])

    assert result.exit_code == 0
    assert "Hotkey" in result.output


def test_status_when_not_configured(monkeypatch, tmp_config_dir):
    """Shows not configured state when config missing."""
    main = _load_main(monkeypatch, tmp_config_dir)
    runner = CliRunner()

    monkeypatch.setattr(main, "config_exists", lambda: False)
    monkeypatch.setattr(main, "token_exists", lambda: False)

    result = runner.invoke(main.cli, ["status"])

    assert result.exit_code == 0
    assert "Not configured" in result.output


def test_status_shows_all_fields(monkeypatch, tmp_config_dir):
    """Displays all major status fields."""
    main = _load_main(monkeypatch, tmp_config_dir)
    runner = CliRunner()

    monkeypatch.setattr(main, "config_exists", lambda: True)
    monkeypatch.setattr(main, "token_exists", lambda: True)
    monkeypatch.setattr(
        main,
        "get_config",
        lambda: {
            "hotkey": "ctrl+x",
            "notify_on_copy": True,
            "otp_max_age_minutes": 5,
            "email_fetch_count": 3,
        },
    )

    result = runner.invoke(main.cli, ["status"])

    assert "Max OTP age" in result.output
    assert "Fetch count" in result.output


def test_fetch_copies_otp_to_clipboard(monkeypatch, tmp_config_dir):
    """Copies OTP to clipboard on fetch."""
    main = _load_main(monkeypatch, tmp_config_dir)
    runner = CliRunner()

    copied = {"value": None}

    monkeypatch.setattr(main, "fetch_recent_emails", lambda: [{"subject": "Your code is 123456", "body": "", "sender": ""}])
    monkeypatch.setattr(main, "extract_otp", lambda emails: "123456")
    monkeypatch.setattr(main, "copy_to_clipboard", lambda value: copied.update(value=value))
    monkeypatch.setattr(main, "get_config", lambda: {"auto_paste": False, "notify_on_copy": False})
    monkeypatch.setattr(main, "notify", lambda *args, **kwargs: None)
    monkeypatch.setattr("otpilot.history.save_entry", lambda *args, **kwargs: None)

    result = runner.invoke(main.cli, ["fetch"])

    assert result.exit_code == 0
    assert copied["value"] == "123456"


def test_fetch_notifies_when_no_otp_found(monkeypatch, tmp_config_dir):
    """Notifies user when no OTP is found."""
    main = _load_main(monkeypatch, tmp_config_dir)
    runner = CliRunner()

    notified = {"called": False}

    monkeypatch.setattr(main, "fetch_recent_emails", lambda: [])
    monkeypatch.setattr(main, "extract_otp", lambda emails: None)
    monkeypatch.setattr(main, "notify", lambda *args, **kwargs: notified.update(called=True))

    runner.invoke(main.cli, ["fetch"])

    assert notified["called"] is True


def test_fetch_handles_not_authenticated_error(monkeypatch, tmp_config_dir):
    """Handles NotAuthenticatedError during fetch."""
    main = _load_main(monkeypatch, tmp_config_dir)
    runner = CliRunner()

    notified = {"called": False}

    def raise_err():
        raise main.NotAuthenticatedError()

    monkeypatch.setattr(main, "fetch_recent_emails", raise_err)
    monkeypatch.setattr(main, "notify", lambda *args, **kwargs: notified.update(called=True))

    runner.invoke(main.cli, ["fetch"])

    assert notified["called"] is True


def test_fetch_handles_gmail_auth_error(monkeypatch, tmp_config_dir):
    """Handles GmailAuthError during fetch."""
    main = _load_main(monkeypatch, tmp_config_dir)
    runner = CliRunner()

    notified = {"called": False}

    def raise_err():
        raise main.GmailAuthError()

    monkeypatch.setattr(main, "fetch_recent_emails", raise_err)
    monkeypatch.setattr(main, "notify", lambda *args, **kwargs: notified.update(called=True))

    runner.invoke(main.cli, ["fetch"])

    assert notified["called"] is True


def test_fetch_handles_clipboard_error(monkeypatch, tmp_config_dir):
    """Handles ClipboardError during copy."""
    main = _load_main(monkeypatch, tmp_config_dir)
    runner = CliRunner()

    notified = {"called": False}

    monkeypatch.setattr(main, "fetch_recent_emails", lambda: [{"subject": "Your code is 123456", "body": "", "sender": ""}])
    monkeypatch.setattr(main, "extract_otp", lambda emails: "123456")
    monkeypatch.setattr(main, "copy_to_clipboard", lambda value: (_ for _ in ()).throw(main.ClipboardError("fail")))
    monkeypatch.setattr(main, "notify", lambda *args, **kwargs: notified.update(called=True))

    runner.invoke(main.cli, ["fetch"])

    assert notified["called"] is True


def test_fetch_handles_unexpected_exception(monkeypatch, tmp_config_dir):
    """Handles unexpected exceptions during fetch."""
    main = _load_main(monkeypatch, tmp_config_dir)
    runner = CliRunner()

    notified = {"called": False}

    def raise_err():
        raise RuntimeError("boom")

    monkeypatch.setattr(main, "fetch_recent_emails", raise_err)
    monkeypatch.setattr(main, "notify", lambda *args, **kwargs: notified.update(called=True))

    runner.invoke(main.cli, ["fetch"])

    assert notified["called"] is True


def test_stop_sends_sigterm_to_pid(monkeypatch, tmp_config_dir):
    """Sends SIGTERM to PID from file."""
    main = _load_main(monkeypatch, tmp_config_dir)
    runner = CliRunner()

    pid_file = tmp_config_dir / "otpilot.pid"
    pid_file.write_text("123", encoding="utf-8")

    killed = {}
    monkeypatch.setattr(main.os, "kill", lambda pid, sig: killed.update(pid=pid, sig=sig))

    result = runner.invoke(main.cli, ["stop"])

    assert result.exit_code == 0
    assert killed["pid"] == 123


def test_stop_when_no_pid_file(tmp_config_dir, monkeypatch):
    """Reports not running when PID file missing."""
    main = _load_main(monkeypatch, tmp_config_dir)
    runner = CliRunner()

    result = runner.invoke(main.cli, ["stop"])

    assert "not running" in result.output.lower()
    assert result.exit_code == 0


def test_stop_cleans_stale_pid_file(monkeypatch, tmp_config_dir):
    """Removes stale PID file on ProcessLookupError."""
    main = _load_main(monkeypatch, tmp_config_dir)
    runner = CliRunner()

    pid_file = tmp_config_dir / "otpilot.pid"
    pid_file.write_text("123", encoding="utf-8")

    def raise_lookup(pid, sig):
        raise ProcessLookupError()

    monkeypatch.setattr(main.os, "kill", raise_lookup)

    result = runner.invoke(main.cli, ["stop"])

    assert result.exit_code == 0
    assert not pid_file.exists()


def test_stop_handles_permission_error(monkeypatch, tmp_config_dir):
    """Handles PermissionError when stopping process."""
    main = _load_main(monkeypatch, tmp_config_dir)
    runner = CliRunner()

    pid_file = tmp_config_dir / "otpilot.pid"
    pid_file.write_text("123", encoding="utf-8")

    def raise_perm(pid, sig):
        raise PermissionError()

    monkeypatch.setattr(main.os, "kill", raise_perm)

    result = runner.invoke(main.cli, ["stop"])

    assert result.exit_code == 0
    assert "permission" in result.output.lower()


def test_stop_pid_file_deleted_after_success(monkeypatch, tmp_config_dir):
    """Deletes PID file after successful stop."""
    main = _load_main(monkeypatch, tmp_config_dir)
    runner = CliRunner()

    pid_file = tmp_config_dir / "otpilot.pid"
    pid_file.write_text("123", encoding="utf-8")

    monkeypatch.setattr(main.os, "kill", lambda pid, sig: None)

    runner.invoke(main.cli, ["stop"])

    assert not pid_file.exists()


def test_history_command_empty(monkeypatch, tmp_config_dir):
    """Shows empty message when no history entries exist."""
    main = _load_main(monkeypatch, tmp_config_dir)
    runner = CliRunner()

    import otpilot.history as history
    history = importlib.reload(history)
    monkeypatch.setattr(history, "HISTORY_FILE", tmp_config_dir / "history.json")

    result = runner.invoke(main.cli, ["history"])

    assert "No OTP history" in result.output


def test_history_command_shows_entries(monkeypatch, tmp_config_dir):
    """Displays history entries in output."""
    main = _load_main(monkeypatch, tmp_config_dir)
    runner = CliRunner()

    import otpilot.history as history
    history = importlib.reload(history)
    monkeypatch.setattr(history, "HISTORY_FILE", tmp_config_dir / "history.json")

    (tmp_config_dir / "history.json").write_text(
        json.dumps([
            {"otp": "123", "timestamp": "t", "sender": "a", "subject": "b"}
        ]),
        encoding="utf-8",
    )

    result = runner.invoke(main.cli, ["history"])

    assert "123" in result.output


def test_history_clear_flag(monkeypatch, tmp_config_dir):
    """Clears history when --clear is used."""
    main = _load_main(monkeypatch, tmp_config_dir)
    runner = CliRunner()

    import otpilot.history as history
    history = importlib.reload(history)
    monkeypatch.setattr(history, "HISTORY_FILE", tmp_config_dir / "history.json")

    (tmp_config_dir / "history.json").write_text("[]", encoding="utf-8")

    result = runner.invoke(main.cli, ["history", "--clear"], input="y\n")

    assert result.exit_code == 0
    assert not (tmp_config_dir / "history.json").exists()


def test_history_count_flag(monkeypatch, tmp_config_dir):
    """Limits output to specified count."""
    main = _load_main(monkeypatch, tmp_config_dir)
    runner = CliRunner()

    import otpilot.history as history
    history = importlib.reload(history)
    monkeypatch.setattr(history, "HISTORY_FILE", tmp_config_dir / "history.json")

    (tmp_config_dir / "history.json").write_text(
        json.dumps([
            {"otp": "1", "timestamp": "t", "sender": "a", "subject": "b"},
            {"otp": "2", "timestamp": "t", "sender": "a", "subject": "b"},
        ]),
        encoding="utf-8",
    )

    result = runner.invoke(main.cli, ["history", "--count", "1"])

    assert "1" in result.output
    assert "2" not in result.output


def test_logs_command_outputs_lines(monkeypatch, tmp_config_dir):
    """Outputs recent log lines."""
    main = _load_main(monkeypatch, tmp_config_dir)
    runner = CliRunner()

    log_path = tmp_config_dir / "otpilot.log"
    log_path.write_text("line1\nline2\nline3\n", encoding="utf-8")

    monkeypatch.setattr(main.sys, "platform", "win32")

    result = runner.invoke(main.cli, ["logs", "--lines", "2"])

    assert "line2" in result.output
    assert "line3" in result.output


def test_logs_command_when_no_log_file(monkeypatch, tmp_config_dir):
    """Reports when log file is missing."""
    main = _load_main(monkeypatch, tmp_config_dir)
    runner = CliRunner()

    result = runner.invoke(main.cli, ["logs"])

    assert "No logs" in result.output


def test_logs_lines_flag(monkeypatch, tmp_config_dir):
    """Respects --lines flag value."""
    main = _load_main(monkeypatch, tmp_config_dir)
    runner = CliRunner()

    log_path = tmp_config_dir / "otpilot.log"
    log_path.write_text("a\nb\nc\n", encoding="utf-8")

    monkeypatch.setattr(main.sys, "platform", "win32")

    result = runner.invoke(main.cli, ["logs", "--lines", "1"])

    assert result.output.strip() == "c"


def test_hotkey_set_flag(monkeypatch, tmp_config_dir):
    """Sets hotkey via --set flag."""
    main = _load_main(monkeypatch, tmp_config_dir)
    runner = CliRunner()

    saved = {}
    monkeypatch.setattr("otpilot.config.set_value", lambda key, value: saved.update({key: value}))
    monkeypatch.setattr("otpilot.config.get_value", lambda key, default=None: "ctrl+x")

    result = runner.invoke(main.cli, ["hotkey", "--set", "ctrl+y"])

    assert result.exit_code == 0
    assert saved["hotkey"] == "ctrl+y"


def test_hotkey_shows_current(monkeypatch, tmp_config_dir):
    """Shows current hotkey without changes."""
    main = _load_main(monkeypatch, tmp_config_dir)
    runner = CliRunner()

    monkeypatch.setattr("otpilot.config.get_value", lambda key, default=None: "ctrl+x")

    result = runner.invoke(main.cli, ["hotkey"], input="n\n")

    assert "Current hotkey" in result.output


def test_update_already_up_to_date(monkeypatch, tmp_config_dir):
    """Reports when OTPilot is up to date."""
    main = _load_main(monkeypatch, tmp_config_dir)
    runner = CliRunner()

    monkeypatch.setattr(main, "_fetch_latest_version", lambda: main.__version__)
    monkeypatch.setattr(main, "_is_update_available", lambda current, latest: False)

    result = runner.invoke(main.cli, ["update"])

    assert "up to date" in result.output.lower()


def test_update_shows_new_version(monkeypatch, tmp_config_dir):
    """Shows available update when newer version exists."""
    main = _load_main(monkeypatch, tmp_config_dir)
    runner = CliRunner()

    monkeypatch.setattr(main, "_fetch_latest_version", lambda: "9.9.9")
    monkeypatch.setattr(main, "_is_update_available", lambda current, latest: True)

    result = runner.invoke(main.cli, ["update"], input="n\n")

    assert "Update available" in result.output


def test_update_pypi_unreachable(monkeypatch, tmp_config_dir):
    """Handles PyPI lookup failure."""
    main = _load_main(monkeypatch, tmp_config_dir)
    runner = CliRunner()

    monkeypatch.setattr(main, "_fetch_latest_version", lambda: None)

    result = runner.invoke(main.cli, ["update"])

    assert "Could not check for updates" in result.output


def test_unknown_command_exits_nonzero(tmp_config_dir, monkeypatch):
    """Exits nonzero for unknown commands."""
    main = _load_main(monkeypatch, tmp_config_dir)
    runner = CliRunner()

    result = runner.invoke(main.cli, ["doesnotexist"])

    assert result.exit_code != 0


def test_hotkey_set_empty_string(monkeypatch, tmp_config_dir):
    """Allows empty hotkey values to be set."""
    main = _load_main(monkeypatch, tmp_config_dir)
    runner = CliRunner()

    saved = {}
    monkeypatch.setattr("otpilot.config.set_value", lambda key, value: saved.update({key: value}))
    monkeypatch.setattr("otpilot.config.get_value", lambda key, default=None: "ctrl+x")

    result = runner.invoke(main.cli, ["hotkey", "--set", ""])

    assert result.exit_code == 0
    assert saved["hotkey"] == ""


def test_history_count_flag_zero(monkeypatch, tmp_config_dir):
    """Shows no entries when --count is zero."""
    main = _load_main(monkeypatch, tmp_config_dir)
    runner = CliRunner()

    import otpilot.history as history
    history = importlib.reload(history)
    monkeypatch.setattr(history, "HISTORY_FILE", tmp_config_dir / "history.json")

    (tmp_config_dir / "history.json").write_text(
        json.dumps([{"otp": "1", "timestamp": "t", "sender": "a", "subject": "b"}]),
        encoding="utf-8",
    )

    result = runner.invoke(main.cli, ["history", "--count", "0"])

    assert "No OTP history" in result.output


def test_history_count_flag_negative(monkeypatch, tmp_config_dir):
    """Shows no entries when --count is negative."""
    main = _load_main(monkeypatch, tmp_config_dir)
    runner = CliRunner()

    import otpilot.history as history
    history = importlib.reload(history)
    monkeypatch.setattr(history, "HISTORY_FILE", tmp_config_dir / "history.json")

    (tmp_config_dir / "history.json").write_text(
        json.dumps([{"otp": "1", "timestamp": "t", "sender": "a", "subject": "b"}]),
        encoding="utf-8",
    )

    result = runner.invoke(main.cli, ["history", "--count", "-1"])

    assert "No OTP history" in result.output


def test_logs_lines_flag_zero(monkeypatch, tmp_config_dir):
    """Outputs nothing when --lines is zero."""
    main = _load_main(monkeypatch, tmp_config_dir)
    runner = CliRunner()

    log_path = tmp_config_dir / "otpilot.log"
    log_path.write_text("a\nb\n", encoding="utf-8")

    monkeypatch.setattr(main.sys, "platform", "win32")

    result = runner.invoke(main.cli, ["logs", "--lines", "0"])

    assert result.output == ""


def test_logs_lines_flag_very_large(monkeypatch, tmp_config_dir):
    """Outputs all lines when --lines exceeds file length."""
    main = _load_main(monkeypatch, tmp_config_dir)
    runner = CliRunner()

    log_path = tmp_config_dir / "otpilot.log"
    log_path.write_text("a\nb\n", encoding="utf-8")

    monkeypatch.setattr(main.sys, "platform", "win32")

    result = runner.invoke(main.cli, ["logs", "--lines", "9999"])

    assert "a" in result.output
    assert "b" in result.output


def test_fetch_with_corrupted_config(monkeypatch, tmp_config_dir):
    """Handles corrupted config during fetch."""
    main = _load_main(monkeypatch, tmp_config_dir)
    runner = CliRunner()

    (tmp_config_dir / "config.json").write_text("{bad json}", encoding="utf-8")

    monkeypatch.setattr(main, "fetch_recent_emails", lambda: [{"subject": "Your code is 123456", "body": "", "sender": ""}])
    monkeypatch.setattr(main, "extract_otp", lambda emails: "123456")
    monkeypatch.setattr(main, "copy_to_clipboard", lambda value: None)
    monkeypatch.setattr(main, "notify", lambda *args, **kwargs: None)
    monkeypatch.setattr("otpilot.history.save_entry", lambda *args, **kwargs: None)

    result = runner.invoke(main.cli, ["fetch"])

    assert result.exit_code == 0


def test_status_with_corrupted_config(monkeypatch, tmp_config_dir):
    """Handles corrupted config during status."""
    main = _load_main(monkeypatch, tmp_config_dir)
    runner = CliRunner()

    (tmp_config_dir / "config.json").write_text("{bad json}", encoding="utf-8")

    monkeypatch.setattr(main, "config_exists", lambda: True)
    monkeypatch.setattr(main, "token_exists", lambda: True)

    result = runner.invoke(main.cli, ["status"])

    assert result.exit_code == 0
