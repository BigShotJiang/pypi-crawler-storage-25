"""
Tests package for Allyanonimiser.
"""