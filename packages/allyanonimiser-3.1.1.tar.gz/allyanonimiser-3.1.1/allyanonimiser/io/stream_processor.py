"""
Stream processing utilities for Allyanonimiser.

This module provides streaming capabilities for processing very large files
using Polars for maximum efficiency and minimal memory usage.
"""

import logging
import os
from typing import Any, Generator, Optional

import pandas as pd

logger = logging.getLogger(__name__)

# Polars support is optional
POLARS_AVAILABLE = False
try:
    import polars as pl
    POLARS_AVAILABLE = True
except ImportError:
    # Define dummy objects to avoid NameErrors when Polars is not available
    class DummyModule:
        DataFrame = object
        LazyFrame = object

        def scan_csv(*args, **kwargs):
            pass

        def read_csv(*args, **kwargs):
            pass

        class Config:
            @staticmethod
            def set_streaming_chunk_size(*args, **kwargs):
                pass

    pl = DummyModule()


from .base import BaseProcessor


class StreamProcessor(BaseProcessor):
    """Streaming processor for very large files using Polars."""

    def __init__(self, allyanonimiser=None, n_workers=None, chunk_size=None):
        if not POLARS_AVAILABLE:
            logger.warning(
                "Polars is required for stream processing but is not available. "
                "Install with: pip install polars"
            )
        super().__init__(allyanonimiser)

        # Use values from settings if not explicitly provided
        if n_workers is None and hasattr(self.ally, 'worker_count'):
            self.n_workers = self.ally.worker_count
        else:
            self.n_workers = n_workers or os.cpu_count()

        # Use chunk size from settings or default
        if chunk_size is None and hasattr(self.ally, 'chunk_size'):
            self.chunk_size = self.ally.chunk_size
        else:
            self.chunk_size = chunk_size or 10000

    def _check_polars_available(self):
        """Check if Polars is available and raise an error if not."""
        if not POLARS_AVAILABLE:
            raise ImportError(
                "Polars is required for stream processing but is not available. "
                "Install with: pip install polars"
            )

    def stream_from_file(
        self,
        file_path: str,
        text_columns: str | list[str],
        active_entity_types: Optional[list[str]] = None,
        operators: Optional[dict[str, str]] = None,
        min_score_threshold: float = 0.7,
        anonymize: bool = True,
        chunk_size: Optional[int] = None,
        output_path: Optional[str] = None,
        progress_bar: bool = True,
        csv_options: Optional[dict[str, Any]] = None,
        age_bracket_size: int = 5,
        keep_postcode: bool = True
    ) -> Generator[dict[str, pd.DataFrame | list], None, None]:
        """
        Stream process a large CSV file with minimal memory usage.

        Args:
            file_path: Path to the CSV file to process
            text_columns: Column name(s) containing text to process
            active_entity_types: Optional list of entity types to activate
            operators: Dict mapping entity_type to anonymization operator
            min_score_threshold: Minimum confidence score threshold
            anonymize: Whether to perform anonymization
            chunk_size: Number of rows to process in each chunk (overrides instance setting)
            output_path: Optional path to write processed chunks (enables true streaming)
            progress_bar: Whether to display a progress bar
            csv_options: Optional dict of CSV parsing options for Polars
            age_bracket_size: Size of age brackets when using "age_bracket" operator
            keep_postcode: Whether to keep postcodes when anonymizing addresses

        Yields:
            Dict with processed chunk as DataFrame and entity DataFrame

        Note: For true streaming with minimal memory impact, provide output_path
        parameter so each processed chunk is written to disk immediately.
        """
        self._check_polars_available()

        # Import polars here to ensure it's available in this function scope
        import polars as pl

        # Use instance chunk_size if not provided
        chunk_size = chunk_size or self.chunk_size

        # Default CSV options
        if csv_options is None:
            csv_options = {
                "infer_schema_length": chunk_size,
                "n_rows": None,  # Process all rows
                "low_memory": True
            }

        # Configure analyzer settings
        if active_entity_types is not None:
            self.ally.analyzer.set_active_entity_types(active_entity_types)

        self.ally.analyzer.set_min_score_threshold(min_score_threshold)

        # Handle single column case
        if isinstance(text_columns, str):
            text_columns = [text_columns]

        # Configure Polars streaming chunk size
        try:
            pl.Config.set_streaming_chunk_size(chunk_size)
        except Exception as e:
            logger.warning(f"Failed to set Polars streaming chunk size: {e}")

        # Create LazyFrame for streaming
        lf = pl.scan_csv(file_path, **csv_options)

        # Validate columns are in the file
        available_columns = lf.columns
        for column in text_columns:
            if column not in available_columns:
                raise ValueError(f"Column '{column}' not found in CSV file")

        # Create output directories if needed
        if output_path and not os.path.exists(os.path.dirname(output_path)):
            os.makedirs(os.path.dirname(output_path), exist_ok=True)

        # Process in chunks
        chunk_counter = 0
        entities_buffer = []

        # Setup progress tracking if enabled
        if progress_bar:
            try:
                from tqdm import tqdm
            except ImportError:
                logger.warning("tqdm not installed, progress bar disabled")
                progress_bar = False

        # Determine total number of chunks for progress bar
        if progress_bar:
            # Get file size and estimate number of chunks
            file_size = os.path.getsize(file_path)
            # Check for header to estimate rows
            with open(file_path, 'r') as f:
                header = f.readline()
            avg_row_size = len(header)  # Use header as initial estimate
            est_rows = max(10, file_size // max(1, avg_row_size))
            est_chunks = (est_rows + chunk_size - 1) // chunk_size

            progress = tqdm(total=est_chunks, desc="Processing chunks")

        # Stream through the file with lazy evaluation
        # Configure Polars streaming chunk size
        try:
            import polars as pl
            pl.Config.set_streaming_chunk_size(chunk_size)
        except Exception as e:
            logger.warning(f"Failed to set Polars streaming chunk size: {e}")

        # Use streaming mode without explicit chunk_size parameter
        for chunk in lf.collect(streaming=True):
            # Process this chunk
            result = self._process_chunk(
                chunk=chunk,
                text_columns=text_columns,
                active_entity_types=active_entity_types,
                operators=operators,
                min_score_threshold=min_score_threshold,
                anonymize=anonymize,
                age_bracket_size=age_bracket_size,
                keep_postcode=keep_postcode
            )

            # Extract entities and processed data
            processed_chunk = result['dataframe']
            if result.get('entities'):
                entities_buffer.extend(result['entities'])

            # Write to output file if path provided (streaming mode)
            if output_path:
                # Write Polars DataFrame directly to CSV
                if chunk_counter == 0:
                    processed_chunk.write_csv(output_path)
                else:
                    # Append by writing without header
                    with open(output_path, "a") as f:
                        f.write(processed_chunk.write_csv(include_header=False))

                # Only yield entities if they exist
                if entities_buffer:
                    yield {
                        'entities': pd.DataFrame(entities_buffer)
                    }
                    entities_buffer = []  # Clear buffer after yielding
            else:
                # If not streaming to file, yield the processed chunk
                yield_result = {'dataframe': processed_chunk}

                # Include entities if they exist
                if entities_buffer:
                    yield_result['entities'] = pd.DataFrame(entities_buffer)
                    entities_buffer = []  # Clear buffer after yielding

                yield yield_result

            # Update progress
            if progress_bar:
                progress.update(1)

            chunk_counter += 1

        # Close progress bar
        if progress_bar:
            progress.close()

        # Yield any remaining entities
        if entities_buffer:
            yield {'entities': pd.DataFrame(entities_buffer)}

    def _process_chunk(
        self,
        chunk,
        text_columns: list[str],
        active_entity_types: Optional[list[str]] = None,
        operators: Optional[dict[str, str]] = None,
        min_score_threshold: float = 0.7,
        anonymize: bool = True,
        age_bracket_size: int = 5,
        keep_postcode: bool = True,
    ) -> dict[str, Any]:
        """Process a single chunk using Polars-native operations where possible."""
        import polars as pl

        # Ensure we have a Polars DataFrame
        if isinstance(chunk, pd.DataFrame):
            chunk = pl.from_pandas(chunk)

        all_entities: list = []
        result = chunk.clone()

        for column in text_columns:
            if column not in chunk.columns:
                continue

            texts = chunk[column].to_list()

            # Analyze in batch
            if active_entity_types is not None:
                self.ally.analyzer.set_active_entity_types(active_entity_types)
            self.ally.analyzer.set_min_score_threshold(min_score_threshold)

            # Use batch analysis to pre-warm spaCy cache
            batch_results = self.ally.analyzer.analyze_batch(
                [str(t) if t is not None else "" for t in texts]
            )

            anonymized_texts: list = []
            for row_idx, (text, entities) in enumerate(zip(texts, batch_results)):
                if text is None:
                    anonymized_texts.append(None)
                    continue

                text_str = str(text)
                for e in entities:
                    all_entities.append({
                        "row_index": row_idx,
                        "column": column,
                        "entity_type": e.entity_type,
                        "start": e.start,
                        "end": e.end,
                        "text": e.text or text_str[e.start:e.end],
                        "score": e.score,
                    })

                if anonymize:
                    r = self.ally.anonymize(
                        text_str,
                        operators=operators,
                        age_bracket_size=age_bracket_size,
                        keep_postcode=keep_postcode,
                    )
                    anonymized_texts.append(r["text"])
                else:
                    anonymized_texts.append(text_str)

            if anonymize:
                result = result.with_columns(
                    pl.Series(f"{column}_anonymized", anonymized_texts)
                )

        return {
            'dataframe': result,
            'entities': all_entities,
        }

    def process_large_file(
        self,
        file_path: str,
        text_columns: str | list[str],
        output_path: str,
        active_entity_types: Optional[list[str]] = None,
        operators: Optional[dict[str, str]] = None,
        min_score_threshold: float = 0.7,
        anonymize: bool = True,
        chunk_size: Optional[int] = None,
        save_entities: bool = True,
        entities_output_path: Optional[str] = None,
        csv_options: Optional[dict[str, Any]] = None,
        age_bracket_size: int = 5,
        keep_postcode: bool = True,
        progress_bar: bool = True
    ) -> dict[str, Any]:
        """
        Process a very large file with minimal memory impact, writing results directly to disk.

        This is the preferred method for extremely large files where holding the
        entire dataset in memory is impractical.

        Args:
            file_path: Path to the CSV file to process
            text_columns: Column name(s) containing text to process
            output_path: Path to write the processed CSV file
            active_entity_types: Optional list of entity types to activate
            operators: Dict mapping entity_type to anonymization operator
            min_score_threshold: Minimum confidence score threshold
            anonymize: Whether to perform anonymization
            chunk_size: Number of rows to process in each chunk (overrides instance setting)
            save_entities: Whether to save detected entities
            entities_output_path: Path to write entities CSV (if save_entities=True)
            csv_options: Optional dict of CSV parsing options for Polars
            age_bracket_size: Size of age brackets when using "age_bracket" operator
            keep_postcode: Whether to keep postcodes when anonymizing addresses
            progress_bar: Whether to display a progress bar

        Returns:
            Dict with processing statistics
        """
        self._check_polars_available()

        # Set default entities output path if not provided
        if save_entities and entities_output_path is None:
            base_dir = os.path.dirname(output_path)
            base_name = os.path.splitext(os.path.basename(output_path))[0]
            entities_output_path = os.path.join(base_dir, f"{base_name}_entities.csv")

        # Stream process the file
        total_rows = 0
        total_entities = 0
        entities_buffer = []

        for chunk_result in self.stream_from_file(
            file_path=file_path,
            text_columns=text_columns,
            active_entity_types=active_entity_types,
            operators=operators,
            min_score_threshold=min_score_threshold,
            anonymize=anonymize,
            chunk_size=chunk_size,
            output_path=output_path,
            progress_bar=progress_bar,
            csv_options=csv_options,
            age_bracket_size=age_bracket_size,
            keep_postcode=keep_postcode
        ):
            # Update statistics
            if 'dataframe' in chunk_result:
                total_rows += len(chunk_result['dataframe'])

            # Collect entities if saving
            if save_entities and 'entities' in chunk_result:
                entities_df = chunk_result['entities']
                entities_buffer.extend(entities_df.to_dict('records'))
                total_entities += len(entities_df)

        # Save collected entities if requested
        if save_entities and entities_output_path and entities_buffer:
            entities_df = pd.DataFrame(entities_buffer)
            entities_df.to_csv(entities_output_path, index=False)

        return {
            'total_rows_processed': total_rows,
            'total_entities_detected': total_entities,
            'output_file': output_path,
            'entities_file': entities_output_path if save_entities else None
        }
