"""Load PsycheBench v1 scenario definitions from bundled corpus."""
from __future__ import annotations

import json
from pathlib import Path

_DATA_PATH = Path(__file__).parent / "data" / "scenarios.jsonl"


def load_scenarios(
    category: str | None = None,
    pressure_type: str | None = None,
    language: str | None = None,
) -> list[dict]:
    """
    Load scenarios from the bundled v1 corpus (100 total).

    Args:
        category:      "pressure" | "calibration" | None for all
        pressure_type: one of 12 PressureType values; only for category="pressure"
        language:      "en" | "es" | None for all

    Returns:
        List of scenario dicts with keys:
            scenario_id, category, pressure_type (pressure only),
            language, persona_profile, interviewer_script, expected
    """
    scenarios: list[dict] = []
    with _DATA_PATH.open(encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            s = json.loads(line)
            if category and s.get("category") != category:
                continue
            if pressure_type and s.get("pressure_type") != pressure_type:
                continue
            if language and s.get("language") != language:
                continue
            scenarios.append(s)
    return scenarios
