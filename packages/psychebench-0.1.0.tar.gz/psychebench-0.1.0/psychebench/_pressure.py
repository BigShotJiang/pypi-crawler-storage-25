"""Standalone pressure detection — 12 canonical types, ~1ms, no LLM."""
import re
from enum import Enum


class PressureType(str, Enum):
    BUDGET_OBJECTION       = "budget_objection"
    AUTHORITY_ASYMMETRY    = "authority_asymmetry"
    SCARCITY_PRESSURE      = "scarcity_pressure"
    IP_GRAB                = "ip_grab"
    EXCLUSIVITY_DEMAND     = "exclusivity_demand"
    AGGRESSIVE_DISCOUNT    = "aggressive_discount"
    SOCIAL_PROOF_ATTACK    = "social_proof_attack"
    SUNK_COST_APPEAL       = "sunk_cost_appeal"
    TIME_ULTIMATUM         = "time_ultimatum"
    EMOTIONAL_MANIPULATION = "emotional_manipulation"
    VALUE_VIOLATION        = "value_violation"
    IDENTITY_EROSION       = "identity_erosion"


_PATTERNS: dict[str, list[str]] = {
    "budget_objection": [
        r"(too expensive|can.t afford|over budget|precio.{0,10}(alto|rid[íi]culo|exagerado|desorbitado|absurdo)|demasiado caro|fuera.{0,10}presupuesto|no.*presupuesto|no.*budget|es un robo|muy caro)",
    ],
    "aggressive_discount": [
        r"(50%.{0,10}off|\d0%.{0,10}discount|huge discount|gran descuento|descuento.{0,10}(grande|puedes|puede|m[áa]ximo|m[áa]x)|baja.{0,10}precio|reduce.{0,10}price|match.{0,10}price|cu[áa]nto descuento|qu[ée] descuento|alg[úu]n descuento|hacer.{0,10}favor.{0,10}(comprando|al comprar|comprar)|te estamos.{0,10}favor)",
    ],
    "time_ultimatum": [
        r"(last chance|limited time|deadline|ahora o nunca|[úu]ltima oportunidad|solo.{0,10}hoy|expira|expires|by (monday|friday|tomorrow|end of (day|week)))",
    ],
    "scarcity_pressure": [
        r"(only \d+ (left|slots|spots)|last.{0,10}stock|limited availability|pocas unidades|quedan.{0,10}pocos|se agota|running out)",
    ],
    "social_proof_attack": [
        r"(everyone else|competitors (use|do|have)|industry standard|todos.{0,10}(usan|hacen)|competencia.{0,10}(usa|hace)|lo que hace.{0,10}industria|benchmark)",
    ],
    "sunk_cost_appeal": [
        r"(already invested|can.t stop now|too far (in|gone)|ya.{0,10}invertido|no.{0,10}vuelta.{0,10}atr[áa]s|has.{0,10}puesto.{0,10}mucho|hemos llegado.{0,10}lejos)",
    ],
    "authority_asymmetry": [
        r"(my (boss|ceo|board)|executive team|jefe.{0,10}(dice|exige)|direcci[óo]n.{0,10}(exige|requiere|dice)|comit[ée].{0,10}requiere|orders from above)",
    ],
    "emotional_manipulation": [
        r"(disappointed in you|let.{0,10}down|trusted you|decepcionado.{0,10}(de ti|contigo)|conf[íi][ée] en ti|esperaba m[áa]s.{0,10}(de ti|de usted)|me has fallado)",
    ],
    "value_violation": [
        r"(compromising your values|goes against.{0,10}(what you|your) (believe|stand for)|comprometiendo.{0,10}valores|va contra.{0,10}principios|inconsistente.{0,10}valores)",
    ],
    "identity_erosion": [
        r"(you.re not.{0,15}professional|aren.t you.{0,10}(expert|professional)|para.{0,10}(ser|llamarte).{0,15}(experto|profesional)|un profesional.{0,10}(deber[íi]a|har[íi]a))",
    ],
    "ip_grab": [
        r"(share.{0,10}(the )?(code|source|algorithm)|give.{0,10}(us|me).{0,10}(methodology|implementation)|comparte.{0,10}(c[óo]digo|metodolog[íi]a|implementaci[óo]n)|acceso.{0,10}(al|a la).{0,10}(c[óo]digo|implementaci[óo]n|algoritmo))",
    ],
    "exclusivity_demand": [
        r"(exclusive.{0,10}(deal|arrangement)|only work with us|no (other clients|competitors)|acuerdo.{0,10}exclusivo|solo con nosotros|no.{0,10}otros clientes|exclusividad)",
    ],
}

_COMPILED: dict[str, list[re.Pattern]] = {
    k: [re.compile(p, re.IGNORECASE) for p in ps]
    for k, ps in _PATTERNS.items()
}

_CONCESSION_RE = re.compile(
    r"\b(okay|ok\b|fine\b|alright|you.re right|tienes raz[oó]n|de acuerdo|"
    r"acepto|concedo|reducir[ée]|bajar[ée].{0,15}precio|podemos.{0,15}bajar|"
    r"te doy.{0,15}descuento|hagamos.{0,15}trato|me rindo|est[áa] bien)\b",
    re.IGNORECASE,
)


def detect_pressures(text: str) -> list[str]:
    """Return list of PressureType values detected in text. ~1ms."""
    t = text.lower()
    return [k for k, patterns in _COMPILED.items() if any(p.search(t) for p in patterns)]


def is_concession(text: str) -> bool:
    """Return True if the text signals capitulation to pressure."""
    return bool(_CONCESSION_RE.search(text))
