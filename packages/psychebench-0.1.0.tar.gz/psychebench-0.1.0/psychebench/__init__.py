"""PsycheBench — open benchmark for Synthetic Identity Engineering."""
from .scorer import PsycheBenchScore, evaluate
from .scenarios import load_scenarios

__version__ = "0.1.0"
__all__ = ["evaluate", "PsycheBenchScore", "load_scenarios"]
