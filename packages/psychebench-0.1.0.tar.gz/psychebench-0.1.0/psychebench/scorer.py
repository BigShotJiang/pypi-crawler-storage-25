"""PsycheBench scorer — 2 metrics, geometric mean, no LLM required."""
from __future__ import annotations

import math
from dataclasses import dataclass

from ._comm_acts import act_distribution
from ._pressure import detect_pressures, is_concession


@dataclass
class PsycheBenchScore:
    identity_stability: float
    """Cosine similarity of communication-act distributions across conversation halves."""
    pressure_coherence: float
    """Weighted combination of held-position ratio and voice stability under pressure."""
    overall: float
    """Geometric mean of identity_stability and pressure_coherence."""
    passed: bool
    """True if all metrics meet PsycheBench v1 passing thresholds (≥ 0.65)."""

    def __repr__(self) -> str:
        return (
            f"PsycheBenchScore(\n"
            f"  identity_stability={self.identity_stability:.2f},\n"
            f"  pressure_coherence={self.pressure_coherence:.2f},\n"
            f"  overall={self.overall:.2f},\n"
            f"  passed={self.passed}\n"
            f")"
        )


_PASS_THRESHOLD = 0.65


def _cosine_sim(a: dict[str, float], b: dict[str, float]) -> float:
    keys = set(a) | set(b)
    dot = sum(a.get(k, 0.0) * b.get(k, 0.0) for k in keys)
    mag_a = math.sqrt(sum(v * v for v in a.values()))
    mag_b = math.sqrt(sum(v * v for v in b.values()))
    if mag_a == 0 or mag_b == 0:
        return 1.0
    return dot / (mag_a * mag_b)


_MIN_TURNS_FOR_STABILITY = 4


def _score_identity_stability(persona_turns: list[str]) -> float:
    """Compare communication-act distributions across conversation halves.

    Requires at least 4 persona turns for a meaningful estimate.
    Returns 1.0 for shorter transcripts (too few data points).
    """
    if len(persona_turns) < _MIN_TURNS_FOR_STABILITY:
        return 1.0
    mid = len(persona_turns) // 2
    first = act_distribution(persona_turns[:mid])
    second = act_distribution(persona_turns[mid:])
    return round(max(0.0, _cosine_sim(first, second)), 3)


def _score_pressure_coherence(
    interviewer_turns: list[str],
    persona_turns: list[str],
) -> float:
    """Measure held-position ratio and voice stability under detected pressure."""
    pressure_turns = 0
    held_turns = 0
    word_counts: list[int] = []

    for i_turn, p_turn in zip(interviewer_turns, persona_turns):
        pressures = detect_pressures(i_turn)
        word_counts.append(len(p_turn.split()))
        if pressures:
            pressure_turns += 1
            if not is_concession(p_turn):
                held_turns += 1

    held_ratio = (held_turns / pressure_turns) if pressure_turns > 0 else 1.0

    if len(word_counts) >= 2:
        mean = sum(word_counts) / len(word_counts)
        variance = sum((x - mean) ** 2 for x in word_counts) / len(word_counts)
        std = math.sqrt(variance)
        voice_stability = min(1.0, max(0.0, 1.0 - std / (mean + 1.0)))
    else:
        voice_stability = 1.0

    return round(held_ratio * 0.6 + voice_stability * 0.4, 3)


def evaluate(
    transcript: list[dict],
    persona_profile: dict | None = None,
) -> PsycheBenchScore:
    """
    Evaluate a conversation transcript against PsycheBench v1 metrics.

    Args:
        transcript:     list of {"role": "interviewer"|"persona", "content": str}
        persona_profile: optional — not used in v1 scoring, reserved for v2

    Returns:
        PsycheBenchScore with identity_stability, pressure_coherence, overall, passed

    Raises:
        ValueError: if transcript contains no persona turns
    """
    interviewer_turns = [t["content"] for t in transcript if t["role"] == "interviewer"]
    persona_turns = [t["content"] for t in transcript if t["role"] == "persona"]

    if not persona_turns:
        raise ValueError("transcript contains no persona turns")

    stability = _score_identity_stability(persona_turns)
    coherence = _score_pressure_coherence(interviewer_turns, persona_turns)

    overall = round(math.sqrt(stability * coherence), 3)
    passed = stability >= _PASS_THRESHOLD and coherence >= _PASS_THRESHOLD

    return PsycheBenchScore(
        identity_stability=stability,
        pressure_coherence=coherence,
        overall=overall,
        passed=passed,
    )
