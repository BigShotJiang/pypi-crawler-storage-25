"""Communication act classifier — pattern-based, no LLM."""
import re
from enum import Enum


class CommAct(str, Enum):
    ACCUSATION = "accusation"
    DEFLECTION = "deflection"
    REVEAL     = "reveal"
    COMFORT    = "comfort"
    QUESTION   = "question"
    ASSERTION  = "assertion"


_ACT_PATTERNS: list[tuple[CommAct, list[str]]] = [
    (CommAct.ACCUSATION, [
        r"\b(you always|you never|you don.t|how could you|you.re being|that.s not fair"
        r"|siempre (haces|dices)|nunca (haces|dices)|c[oó]mo puedes|eso no es justo)",
    ]),
    (CommAct.DEFLECTION, [
        r"\b(let.s (focus|talk about)|that.s not (the point|relevant)|i.d rather"
        r"|moving on|let me redirect|hablemos de|no es relevante|prefiero|pasemos a)",
    ]),
    (CommAct.REVEAL, [
        r"\b(honestly|to be honest|actually|if i.m being|what I really|the truth is"
        r"|frankly|en realidad|para ser honesto|lo que realmente|la verdad es|francamente)",
    ]),
    (CommAct.COMFORT, [
        r"\b(i understand|I get it|don.t worry|it.s okay|i.m here|that.s valid"
        r"|entiendo|no te preocupes|est[aá] bien|aqu[ií] estoy|es v[aá]lido)",
    ]),
    (CommAct.QUESTION, [
        r"\?",
        r"\b(what do you|how do you|why do you|can you explain|what makes|could you"
        r"|tell me|what.s your|¿(qu[eé]|c[oó]mo|por qu[eé]|cu[aá]l))",
    ]),
]

_COMPILED: list[tuple[CommAct, list[re.Pattern]]] = [
    (act, [re.compile(p, re.IGNORECASE) for p in patterns])
    for act, patterns in _ACT_PATTERNS
]


def classify_act(text: str) -> CommAct:
    """Classify a single utterance into one of 6 communication acts."""
    t = text.strip()
    for act, patterns in _COMPILED:
        if any(p.search(t) for p in patterns):
            return act
    return CommAct.ASSERTION


def act_distribution(texts: list[str]) -> dict[str, float]:
    """Return normalised act frequency distribution for a list of utterances."""
    if not texts:
        return {a.value: 0.0 for a in CommAct}
    counts: dict[str, int] = {a.value: 0 for a in CommAct}
    for t in texts:
        counts[classify_act(t).value] += 1
    n = len(texts)
    return {k: v / n for k, v in counts.items()}
