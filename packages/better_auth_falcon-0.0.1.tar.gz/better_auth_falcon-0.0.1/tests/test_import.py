import better_auth.falcon


def test_import():
    assert better_auth.falcon.__name__ == "better_auth.falcon"
