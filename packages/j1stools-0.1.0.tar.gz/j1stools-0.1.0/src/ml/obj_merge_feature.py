import numpy as np
import pandas as pd
from pandas import DataFrame
import pandas

from ml.feature_utils import add_lag
from utils import stock


class MergeFeature:
    def add_feature(df: pd.DataFrame):

        return df

    def test():
        pass
