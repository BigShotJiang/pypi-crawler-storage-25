from abc import ABC, abstractmethod
import array
from datetime import datetime
import random
import time

from aiohttp.abc import AbstractMatchInfo
import numpy as np
from numpy.ma import getdata
import pandas as pd
from pandas import DataFrame
from regex import F
from sklearn.metrics import accuracy_score, confusion_matrix, precision_score
from sklearn.preprocessing import label_binarize

from ml.obj_atr_feature import AtrFeature
from ml.obj_filter_data import FilterData
from ml.obj_hv_feature import HvFeature
from ml.obj_label import Label
from ml.obj_ma_feature import MaFeature
from ml.obj_macd_feature import MacdFeature
from ml.obj_market_feature import MarketFeature
from ml.obj_random_feature import RandomFeature
from ml.obj_volume_feature import VolumeFeature
import joblib


class BaseModel(ABC):

    def __init__(self):
        self.DEBUG = True
        self.THRESHOLD = 0.5
        now = datetime.now()
        self.t = now.strftime("%Y%m%d_%H%M%S")
        self.model_name = "model"
        self.is_training = True
        self.trainging_idx = 0

    def drop_na_inf(self, x, y):
        # 1. 把 inf 換成 NaN
        x.replace([np.inf, -np.inf], np.nan, inplace=True)
        # 2. 找出哪些列是乾淨的（沒有 NaN）
        # 注意：xtrain 和 ytrain 的列必須同步刪除，否則 index 會對不起來
        clean_mask = x.isnull().any(axis=1) == False
        x = x[clean_mask]
        y = y[clean_mask]
        return x, y

    # def load_stocks(self):
    #     all_close = []
    #     all = []
    #     self.list_stocks = list(set(self.list_stocks) - set(["0050", "0052"]))

    #     for df in stock_in(self.list_stocks):
    #         try:
    #             # df = stock(stock_id, is_add_noise=self.is_add_noise)
    #             df = self.gen_feature(df)
    #             # 建ema相關的feature會日期有誤差
    #             df = df[30:]
    #             all_close.append(df[["date", "close", "stock_id"]])
    #             df = FilterData.get_data(df)
    #         except Exception as e:
    #             print(f"__load_stock_data > {e}")
    #             continue

    #         if df is None:
    #             continue
    #         all.append(df)

    #     if len(all) == 0:
    #         raise Exception("no data")
    #     else:
    #         self.all_close_df = pd.concat(all_close, axis=0).sort_values("date")
    #         return pd.concat(all, axis=0).sort_values("date")  # .reset_index(drop=True)

    def print_matrix(self, ytest, yproba, accuracy_label2, is_better=False):
        if is_better:
            print(f"*" * 30, f"三分類混淆矩陣\n")
            y_pred_threshold = (yproba >= self.THRESHOLD).astype(int)
            conf_matrix = np.zeros((3, 3), dtype=int)
            for i in range(len(ytest)):
                actual_label = ytest.iloc[i]  # 假設這裡的值是 0, 1, 或 2

                # 檢查這個樣本在哪些類別中機率 >= 0.45
                # 注意：這裡一個樣本可能會投給多個類別，也可能不投
                predicted_indices = np.where(y_pred_threshold[i] == 1)[0]

                for pred_label in predicted_indices:
                    conf_matrix[actual_label, pred_label] += 1

            # 轉成 DataFrame 方便閱讀
            df_cm = pd.DataFrame(
                conf_matrix,
                index=["Actual 0", "Actual 1", "Actual 2"],
                columns=["Pred 0", "Pred 1", "Pred 2"],
            )
            print(df_cm)
            print(f"信心度 > {self.THRESHOLD} 的預測分佈表：")
            print(f"進場勝率: {accuracy_label2:.2%}")
        else:
            cm = confusion_matrix(ytest, yproba)
            # print("cm", cm, sep="\n")
            result = [[0] * 3 for _ in range(3)]

            # 2. 用雙層迴圈把原始資料填入左上角
            for i in range(len(cm)):
                for j in range(len(cm[i])):
                    result[i][j] = int(cm[i][j])
            cm = np.array(result)
            # print("cm", result, sep="\n")
            tp_2 = cm[2, 2]  # 真實為 2，預測也為 2 (賺錢)
            fp_2 = cm[0, 2] + cm[1, 2]  # 真實為 0 或 1，但預測為 2 (虧錢或沒賺)
            print(f"*" * 30, f"三分類混淆矩陣\n", cm)
            print(f"預測會漲但實際沒漲/跌 (FP): {fp_2}")
            print(f"預測會漲且實際達標 (TP): {tp_2}")
            # precision_2 = tp_2 / (tp_2 + fp_2) if (tp_2 + fp_2) > 0 else 0
            print(f"進場勝率: {accuracy_label2:.2%}")

    def get_full_name(self):
        return f"model/{self.model_name}{self.t}_{self.n}.joblib"

    # def prepare_df(self):

    #     df: pd.DataFrame = self.load_stocks()

    #     if (df.shape[0]) < 500:
    #         raise Exception("no data")

    #     # check df
    #     df.dropna(inplace=True)
    #     df = df.sort_values("date")

    #     features = self.__get_features_name(df)

    #     split_date_df = self.__split_date(df)
    #     self.train_df, self.test_df = split_date_df[0], split_date_df[1]

    #     # X_train = self.train_df[features]
    #     # y_train = self.train_df["target"]
    #     X_test = self.test_df[features]
    #     y_test = self.test_df["target"]

    #     return None, None, X_test, y_test

    def base_predict(self, xtest, ytest):
        # base
        y_proba = self.model.predict(xtest)
        accuracy = accuracy_score(ytest, y_proba)
        precisions = precision_score(ytest, y_proba, average=None, zero_division=0)
        if len(precisions) > 2:
            accuracy = precisions[2]
        else:
            accuracy = 0
        self.print_matrix(ytest=ytest, yproba=y_proba, accuracy_label2=accuracy)

        return accuracy

    def batter_predict(self, xtest, ytest):

        yproba = self.model.predict_proba(xtest)
        y_pred_threshold = (yproba >= self.THRESHOLD).astype(int)
        y_test_binarized = label_binarize(ytest, classes=[0, 1, 2])
        try:
            accuracy = precision_score(y_test_binarized, y_pred_threshold, average=None, zero_division=0)[2]
        except Exception as e:
            print("y_test_binarized", y_test_binarized[:5], sep="\n")
            print("y_pred_threshold", y_pred_threshold[:5], sep="\n")
            raise e
        self.print_matrix(ytest=ytest, yproba=yproba, accuracy_label2=accuracy, is_better=True)

        self.print_trading_date(xtest, yproba)
        self.print_target_counts(ytest)
        # import ft
        if self.is_print_import_ft:
            self.print_ft_important()

        return yproba

    def train_model(
        self,
        xtrain,
        xtest,
        ytrain,
        ytest,
        xval=None,
        yval=None,
        n=0,
        function_train=None,
    ):
        self.n = n
        print(f"*" * 30, f"第 {self.n + 1} 次訓練")

        # train
        model = self.model
        if self.is_training:
            if function_train:
                function_train(xtrain, xval, ytrain, yval, model)
            else:
                model.fit(xtrain, ytrain)
                joblib.dump(model, self.get_full_name())

        expected_features = self.model.feature_names_in_
        xtest = xtest[expected_features]

        self.base_predict(xtest, ytest)

        # test
        accuracy = self.batter_predict(xtest, ytest)
        return accuracy

    def print_target_counts(self, ytest):
        print("*" * 30, "value_counts")
        value_df = pd.concat(
            keys=["test"],
            objs=[ytest.value_counts()],
            # objs=[ytest["target"].value_counts()],
            # objs=[train_df["target"].value_counts(), test_df["target"].value_counts()],
            axis=1,
        ).sort_index()
        print(value_df)

    def check_null_inf(self, X_train):
        # 檢查是否有無限大 (inf)
        print(f"*" * 30, "isinf\n", np.isinf(X_train).any())
        # 檢查是否有空值 (NaN)
        print(f"*" * 30, "isnull\n", X_train.isnull().any())

    def print_ft_important(self):
        feat_importances = pd.Series(
            self.model.feature_importances_,
            index=self.model.feature_names_in_,
        )

        print("*" * 30, f"feat_importances {feat_importances.size}")
        print(feat_importances.sort_values(ascending=False))
        with open(f"log/log_import_ft{self.n}.py", "w", encoding="utf-8") as f:
            f.write(str(feat_importances.sort_values(ascending=False).index.tolist()))

    def get_gold_signal(self, xtest, y_proba: pd.Series) -> pd.DataFrame:
        results = pd.DataFrame(y_proba, index=xtest.index)
        results.reset_index(drop=False, inplace=True)
        # print(results.head())
        signal_label_2 = results.iloc[:, 4]
        return results

    def print_trading_date(self, xtest: pd.DataFrame, y_proba):
        print(f"*" * 30, "print_trading_date")
        xtest = self.get_gold_signal(xtest, y_proba)
        gold_signals = xtest[xtest.iloc[:, 4] > self.THRESHOLD]

        print(f"門檻設定: {self.THRESHOLD}")
        print(f"訊號量: {len(gold_signals)}")
        if len(gold_signals) > 0:
            print("訊號分布的天數:", gold_signals["date"].nunique())
            print("訊號包含的股票數:", gold_signals["stock_id"].nunique())  # 你的欄位是 stock_id
        return gold_signals
