def abc():
    print("abc")


def ddd(str):
    print(str)
    return "ddd"
