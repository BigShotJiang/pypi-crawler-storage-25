__all__ = ["abc", "ddd"]
from ml.j1stools import abc, ddd

# def abc():
#     pass


# def ddd(str):
#     pass
