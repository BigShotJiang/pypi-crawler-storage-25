from setuptools import setup, Extension
from Cython.Build import cythonize

# 定義要編譯的模組：因為檔案在 src 目錄，模組名稱直接命名為 j1stools
extensions = [
    Extension("j1stools", ["src/ml/j1stools.py"]),  # 對應你目前的原始碼路徑
]

setup(
    name="j1stools",
    version="0.1.0",
    package_dir={"": "src"},
    ext_modules=cythonize(extensions, compiler_directives={"language_level": "3"}),
    package_data={
        # 告訴打包工具要把 pyi 檔一起包進去
        "": ["j1stools.pyi"],
    },
    include_package_data=True,
    zip_safe=False,
)
