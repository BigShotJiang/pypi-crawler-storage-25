import os
import tempfile
import unittest

from whatsappchattodf import WhatsappChatToDF
from whatsappchattodf.whatsappchattodf import UserCountError


class TestWhatsappChatToDF(unittest.TestCase):

    def setUp(self):
        # Get the file path for test_chat.txt
        self.test_file_path = os.path.join(os.path.dirname(__file__), "test_chat.txt")

    def test_run(self):
        wctd = WhatsappChatToDF(self.test_file_path)
        df = wctd.run()
        self.assertIsNotNone(df)
        self.assertIn("Timestamp", df.columns)
        self.assertIn("User", df.columns)
        self.assertIn("Message", df.columns)
        self.assertGreater(len(df), 0)  # Ensure the DataFrame is not empty

    def test_run_removes_media_omitted_lines(self):
        wctd = WhatsappChatToDF(self.test_file_path)
        df = wctd.run()
        self.assertFalse(df["Message"].str.contains("<Media omitted>", na=False).any())

    def test_run_handles_system_lines_without_user_message_format(self):
        chat_content = "\n".join(
            [
                "01/01/24, 10:00 - Alice: Hi",
                "01/01/24, 10:01 - You pinned a message",
                "01/01/24, 10:02 - Bob: Hello",
                "01/01/24, 10:03 - Alice: <Media omitted>",
            ]
        )

        with tempfile.NamedTemporaryFile(mode="w", delete=False, encoding="utf8") as temp_file:
            temp_file.write(chat_content)
            temp_file_path = temp_file.name

        try:
            wctd = WhatsappChatToDF(temp_file_path)
            df = wctd.run()

            self.assertEqual(len(df), 2)
            self.assertListEqual(sorted(df["User"].unique().tolist()), ["Alice", "Bob"])
            self.assertFalse(df["Message"].str.contains("<Media omitted>", na=False).any())
        finally:
            os.remove(temp_file_path)

    def test_run_raises_exception_for_non_two_user_chat(self):
        chat_content = "\n".join(
            [
                "01/01/24, 10:00 - Alice: Hi",
                "01/01/24, 10:01 - Alice: Still here",
            ]
        )

        with tempfile.NamedTemporaryFile(mode="w", delete=False, encoding="utf8") as temp_file:
            temp_file.write(chat_content)
            temp_file_path = temp_file.name

        try:
            wctd = WhatsappChatToDF(temp_file_path)
            with self.assertRaises(UserCountError):
                wctd.run()
        finally:
            os.remove(temp_file_path)

    def test_run_parses_non_zero_padded_and_12h_timestamps(self):
        chat_content = "\n".join(
            [
                "1/1/24, 9:05 pm - Alice: Hi",
                "1/1/24, 9:06 pm - Bob: Hello",
            ]
        )

        with tempfile.NamedTemporaryFile(mode="w", delete=False, encoding="utf8") as temp_file:
            temp_file.write(chat_content)
            temp_file_path = temp_file.name

        try:
            wctd = WhatsappChatToDF(temp_file_path)
            df = wctd.run()
            self.assertEqual(len(df), 2)
            self.assertTrue(df["Timestamp"].notna().all())
        finally:
            os.remove(temp_file_path)


if __name__ == "__main__":
    unittest.main()
