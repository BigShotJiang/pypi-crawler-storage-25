/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {

  // ── categories ──────────────────────────────────────────────────────────────
  const categories = new Collection({
    id: "pbc_3292755704",
    name: "categories",
    type: "base",
    listRule: null,
    viewRule: null,
    createRule: null,
    updateRule: null,
    deleteRule: null,
    fields: [
      {
        id: "nxgm1cat",
        name: "name",
        type: "text",
        required: true,
        min: null,
        max: null,
        pattern: "",
      },
    ],
  });
  app.save(categories);

  // ── tags ────────────────────────────────────────────────────────────────────
  const tags = new Collection({
    id: "pbc_1219621782",
    name: "tags",
    type: "base",
    listRule: null,
    viewRule: null,
    createRule: null,
    updateRule: null,
    deleteRule: null,
    fields: [
      {
        id: "nxgm1tag",
        name: "name",
        type: "text",
        required: true,
        min: null,
        max: null,
        pattern: "",
      },
    ],
  });
  app.save(tags);

  // ── images ──────────────────────────────────────────────────────────────────
  const images = new Collection({
    id: "pbc_3607937828",
    name: "images",
    type: "base",
    listRule: null,
    viewRule: null,
    createRule: null,
    updateRule: null,
    deleteRule: null,
    fields: [
      {
        id: "imgttl01",
        name: "title",
        type: "text",
        required: true,
        min: null,
        max: null,
        pattern: "",
      },
      {
        id: "imgfile01",
        name: "file",
        type: "file",
        required: false,
        maxSelect: 1,
        maxSize: 0,
        mimeTypes: [
          "image/jpeg",
          "image/png",
          "image/gif",
          "image/webp",
          "image/heic",
        ],
        thumbs: ["200x200", "800x0"],
        protected: false,
      },
      {
        id: "imgcat001",
        name: "category_id",
        type: "relation",
        required: false,
        maxSelect: 1,
        collectionId: "pbc_3292755704",
        cascadeDelete: false,
      },
    ],
  });
  app.save(images);

  // ── image_tags ───────────────────────────────────────────────────────────────
  const image_tags = new Collection({
    id: "pbc_1664503336",
    name: "image_tags",
    type: "base",
    listRule: null,
    viewRule: null,
    createRule: null,
    updateRule: null,
    deleteRule: null,
    fields: [
      {
        id: "itimg0001",
        name: "image_id",
        type: "relation",
        required: true,
        maxSelect: 1,
        collectionId: "pbc_3607937828",
        cascadeDelete: true,
      },
      {
        id: "ittag0001",
        name: "tag_id",
        type: "relation",
        required: true,
        maxSelect: 1,
        collectionId: "pbc_1219621782",
        cascadeDelete: false,
      },
    ],
  });
  app.save(image_tags);

}, (app) => {

  // down — удаляем в обратном порядке (зависимости сначала)
  for (const name of ["image_tags", "images", "tags", "categories"]) {
    try {
      app.delete(app.findCollectionByNameOrId(name));
    } catch (_) {}
  }

});
