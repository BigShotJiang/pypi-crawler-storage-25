/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {

  for (const name of ["categories", "images", "tags", "image_tags"]) {
    const col = app.findCollectionByNameOrId(name);

    col.fields.add(new Field({
      id: name + "_created",
      name: "created",
      type: "autodate",
      onCreate: true,
      onUpdate: false,
      nullable: false,
      hidden: false,
      presentable: false,
      system: false,
    }));

    col.fields.add(new Field({
      id: name + "_updated",
      name: "updated",
      type: "autodate",
      onCreate: true,
      onUpdate: true,
      nullable: false,
      hidden: false,
      presentable: false,
      system: false,
    }));

    app.save(col);
  }

}, (app) => {

  for (const name of ["categories", "images", "tags", "image_tags"]) {
    const col = app.findCollectionByNameOrId(name);
    col.fields.removeById(name + "_created");
    col.fields.removeById(name + "_updated");
    app.save(col);
  }

});
