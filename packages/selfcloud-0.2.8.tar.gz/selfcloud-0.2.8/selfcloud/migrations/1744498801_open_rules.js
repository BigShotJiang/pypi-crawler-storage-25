/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {

  for (const name of ["categories", "images", "tags", "image_tags"]) {
    const col = app.findCollectionByNameOrId(name);
    col.listRule   = "";
    col.viewRule   = "";
    col.createRule = "";
    col.updateRule = "";
    col.deleteRule = "";
    app.save(col);
  }

}, (app) => {

  for (const name of ["categories", "images", "tags", "image_tags"]) {
    const col = app.findCollectionByNameOrId(name);
    col.listRule   = null;
    col.viewRule   = null;
    col.createRule = null;
    col.updateRule = null;
    col.deleteRule = null;
    app.save(col);
  }

});
