/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {

  // ── images: add user_id field + access rules ──────────────────────────────
  const images = app.findCollectionByNameOrId("images");

  images.fields.add(new Field({
    id: "imguser01",
    name: "user_id",
    type: "text",
    required: false,
    min: null,
    max: null,
    pattern: "",
  }));

  images.listRule   = 'user_id = @request.auth.id';
  images.viewRule   = 'user_id = @request.auth.id';
  images.createRule = '@request.auth.id != ""';
  images.updateRule = 'user_id = @request.auth.id';
  images.deleteRule = 'user_id = @request.auth.id';

  app.save(images);

  // ── documents: add user_id field + access rules ───────────────────────────
  const documents = app.findCollectionByNameOrId("documents");

  documents.fields.add(new Field({
    id: "docuser01",
    name: "user_id",
    type: "text",
    required: false,
    min: null,
    max: null,
    pattern: "",
  }));

  documents.listRule   = 'user_id = @request.auth.id';
  documents.viewRule   = 'user_id = @request.auth.id';
  documents.createRule = '@request.auth.id != ""';
  documents.updateRule = 'user_id = @request.auth.id';
  documents.deleteRule = 'user_id = @request.auth.id';

  app.save(documents);

  // ── image_tags: restrict to owner's images ────────────────────────────────
  const imageTags = app.findCollectionByNameOrId("image_tags");
  imageTags.listRule   = 'image_id.user_id = @request.auth.id';
  imageTags.viewRule   = 'image_id.user_id = @request.auth.id';
  imageTags.createRule = 'image_id.user_id = @request.auth.id';
  imageTags.updateRule = 'image_id.user_id = @request.auth.id';
  imageTags.deleteRule = 'image_id.user_id = @request.auth.id';
  app.save(imageTags);

}, (app) => {

  // ── revert images ─────────────────────────────────────────────────────────
  const images = app.findCollectionByNameOrId("images");
  images.fields.removeById("imguser01");
  images.listRule   = '';
  images.viewRule   = '';
  images.createRule = '';
  images.updateRule = '';
  images.deleteRule = '';
  app.save(images);

  // ── revert documents ──────────────────────────────────────────────────────
  const documents = app.findCollectionByNameOrId("documents");
  documents.fields.removeById("docuser01");
  documents.listRule   = '';
  documents.viewRule   = '';
  documents.createRule = '';
  documents.updateRule = '';
  documents.deleteRule = '';
  app.save(documents);

  // ── revert image_tags ─────────────────────────────────────────────────────
  const imageTags = app.findCollectionByNameOrId("image_tags");
  imageTags.listRule   = '';
  imageTags.viewRule   = '';
  imageTags.createRule = '';
  imageTags.updateRule = '';
  imageTags.deleteRule = '';
  app.save(imageTags);

});
