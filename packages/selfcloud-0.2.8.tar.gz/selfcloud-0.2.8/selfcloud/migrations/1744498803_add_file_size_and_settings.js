/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {

  // ── file_size field on images ────────────────────────────────────────────────
  const images = app.findCollectionByNameOrId("images");
  images.fields.add(new Field({
    id: "imgsize01",
    name: "file_size",
    type: "number",
    required: false,
    min: null,
    max: null,
    onlyInt: true,
  }));
  app.save(images);

  // ── settings (key/value store) ───────────────────────────────────────────────
  const settings = new Collection({
    id: "pbc_settings001",
    name: "settings",
    type: "base",
    listRule: "",
    viewRule: "",
    createRule: "",
    updateRule: "",
    deleteRule: "",
    fields: [
      {
        id: "setkey001",
        name: "key",
        type: "text",
        required: true,
        min: null,
        max: null,
        pattern: "",
      },
      {
        id: "setval001",
        name: "value",
        type: "text",
        required: false,
        min: null,
        max: null,
        pattern: "",
      },
    ],
  });
  app.save(settings);

}, (app) => {

  const images = app.findCollectionByNameOrId("images");
  images.fields.removeById("imgsize01");
  app.save(images);

  try {
    app.delete(app.findCollectionByNameOrId("settings"));
  } catch (_) {}

});
