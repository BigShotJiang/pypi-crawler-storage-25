/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {

  const users = app.findCollectionByNameOrId("users");

  let usernameField = users.fields.getByName("username");
  if (!usernameField) {
    users.fields.add(new Field({
      id: "users_username",
      name: "username",
      type: "text",
      required: false,
      unique: true,
      min: 3,
      max: 150,
      pattern: "^[a-zA-Z0-9_\\-]+$",
    }));
  } else {
    // Field exists but may not have unique constraint — enforce it
    usernameField.unique = true;
  }

  users.passwordAuth = {
    enabled: true,
    identityFields: ["username"],
  };

  app.save(users);

}, (app) => {

  const users = app.findCollectionByNameOrId("users");
  users.passwordAuth = {
    enabled: true,
    identityFields: ["email"],
  };
  try { users.fields.removeById("users_username"); } catch (_) {}
  app.save(users);

});
