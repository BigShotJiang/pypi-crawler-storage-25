/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {

  // ── images: remove favorite, add video mime types, add mime_type field ───────
  const images = app.findCollectionByNameOrId("images");
  images.fields.removeById("imgfav001");

  const fileField = images.fields.getByName("file");
  fileField.mimeTypes = [
    "image/jpeg",
    "image/png",
    "image/gif",
    "image/webp",
    "image/heic",
    "video/mp4",
    "video/quicktime",
    "video/x-m4v",
  ];

  images.fields.add(new Field({
    id: "imgmime01",
    name: "mime_type",
    type: "text",
    required: false,
    min: null,
    max: null,
    pattern: "",
  }));
  app.save(images);

  // ── documents collection ──────────────────────────────────────────────────────
  const documents = new Collection({
    id: "pbc_documents01",
    name: "documents",
    type: "base",
    listRule: "",
    viewRule: "",
    createRule: "",
    updateRule: "",
    deleteRule: "",
    fields: [
      {
        id: "doctitle01",
        name: "title",
        type: "text",
        required: true,
        min: null,
        max: null,
        pattern: "",
      },
      {
        id: "docfile001",
        name: "file",
        type: "file",
        required: false,
        maxSelect: 1,
        maxSize: 0,
        mimeTypes: [],
        thumbs: [],
        protected: false,
      },
      {
        id: "docmime01",
        name: "mime_type",
        type: "text",
        required: false,
        min: null,
        max: null,
        pattern: "",
      },
      {
        id: "docsize01",
        name: "file_size",
        type: "number",
        required: false,
        min: null,
        max: null,
        onlyInt: true,
      },
      {
        id: "documents_created",
        name: "created",
        type: "autodate",
        onCreate: true,
        onUpdate: false,
        nullable: false,
        hidden: false,
        presentable: false,
        system: false,
      },
      {
        id: "documents_updated",
        name: "updated",
        type: "autodate",
        onCreate: true,
        onUpdate: true,
        nullable: false,
        hidden: false,
        presentable: false,
        system: false,
      },
    ],
  });
  app.save(documents);

  // ── seed "Избранное" tag ──────────────────────────────────────────────────────
  try {
    app.findFirstRecordByFilter("tags", 'name = "Избранное"');
  } catch (_) {
    const record = new Record(app.findCollectionByNameOrId("tags"));
    record.set("name", "Избранное");
    app.save(record);
  }

}, (app) => {

  // ── restore favorite field, revert mime types, remove mime_type ───────────────
  const images = app.findCollectionByNameOrId("images");

  images.fields.add(new Field({
    id: "imgfav001",
    name: "favorite",
    type: "bool",
    required: false,
  }));

  const fileField = images.fields.getByName("file");
  fileField.mimeTypes = [
    "image/jpeg",
    "image/png",
    "image/gif",
    "image/webp",
    "image/heic",
  ];

  images.fields.removeById("imgmime01");
  app.save(images);

  // ── remove documents ──────────────────────────────────────────────────────────
  try {
    app.delete(app.findCollectionByNameOrId("documents"));
  } catch (_) {}

});
