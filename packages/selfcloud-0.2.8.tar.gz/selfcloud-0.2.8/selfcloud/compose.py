import shutil
import subprocess
from pathlib import Path

import typer
from rich.console import Console

console = Console()

SELFCLOUD_DIR = Path.home() / ".selfcloud"
COMPOSE_FILE = SELFCLOUD_DIR / "docker-compose.yml"

_COMPOSE_CONTENT = """\
services:
  pocketbase:
    image: ghcr.io/muchobien/pocketbase:latest
    ports:
      - "8090:8090"
    volumes:
      - ./pb_data:/pb_data
      - ./pb_migrations:/pb_migrations
"""


def setup() -> None:
    """Create ~/.selfcloud/, copy bundled migrations, write compose file."""
    SELFCLOUD_DIR.mkdir(exist_ok=True)
    (SELFCLOUD_DIR / "pb_data").mkdir(exist_ok=True)

    migrations_dst = SELFCLOUD_DIR / "pb_migrations"
    migrations_dst.mkdir(exist_ok=True)

    migrations_src = Path(__file__).parent / "migrations"
    if migrations_src.exists():
        for src_file in sorted(migrations_src.glob("*.js")):
            dst_file = migrations_dst / src_file.name
            if not dst_file.exists():
                shutil.copy(src_file, dst_file)

    COMPOSE_FILE.write_text(_COMPOSE_CONTENT)


def up() -> None:
    console.print("[dim]Starting PocketBase...[/dim]")
    _run(["docker", "compose", "up", "-d", "--pull", "always"])


def down() -> None:
    _run(["docker", "compose", "down"])


def ps() -> None:
    _run(["docker", "compose", "ps"])


def _run(cmd: list[str]) -> None:
    try:
        subprocess.run(cmd, cwd=SELFCLOUD_DIR, check=True)
    except subprocess.CalledProcessError as exc:
        console.print(f"[red]Command failed: {exc}[/red]")
        raise typer.Exit(1)
