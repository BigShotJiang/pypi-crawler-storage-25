import socket
import urllib.request


def get_local_ip() -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "localhost"


def get_public_ip() -> str | None:
    for url in (
        "https://api.ipify.org",
        "https://checkip.amazonaws.com",
    ):
        try:
            with urllib.request.urlopen(url, timeout=4) as r:
                return r.read().decode().strip()
        except Exception:
            continue
    return None
