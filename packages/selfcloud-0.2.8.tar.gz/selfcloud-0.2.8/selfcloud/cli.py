import json
import shutil
import time
import urllib.request
from pathlib import Path

import typer
from rich.console import Console
from rich.prompt import Prompt

from selfcloud import compose, docker, network
from selfcloud.banner import print_banner

app = typer.Typer(
    add_completion=False,
    help="SelfCloud — self-hosted media and file storage.",
    invoke_without_command=True,
)
console = Console()

_CONFIG_FILE = Path.home() / ".selfcloud" / "config.json"
_SELFCLOUD_DIR = Path.home() / ".selfcloud"


def _load_config() -> dict:
    if _CONFIG_FILE.exists():
        return json.loads(_CONFIG_FILE.read_text())
    return {}


def _save_config(config: dict) -> None:
    _CONFIG_FILE.parent.mkdir(exist_ok=True)
    _CONFIG_FILE.write_text(json.dumps(config, indent=2))


_PB_URL = "http://localhost:8090"


def _wait_for_pocketbase(timeout: int = 30) -> bool:
    for _ in range(timeout):
        try:
            urllib.request.urlopen(f"{_PB_URL}/api/health", timeout=1)
            return True
        except Exception:
            time.sleep(1)
    return False


def _sync_quota(quota_gb: float) -> None:
    quota_bytes = str(int(quota_gb * 1024 * 1024 * 1024))
    try:
        url = f'{_PB_URL}/api/collections/settings/records?filter=key%3D"storage_quota_bytes"'
        with urllib.request.urlopen(url, timeout=5) as r:
            items = json.loads(r.read()).get("items", [])

        body = json.dumps({"key": "storage_quota_bytes", "value": quota_bytes}).encode()

        if items:
            req = urllib.request.Request(
                f"{_PB_URL}/api/collections/settings/records/{items[0]['id']}",
                data=body,
                headers={"Content-Type": "application/json"},
                method="PATCH",
            )
        else:
            req = urllib.request.Request(
                f"{_PB_URL}/api/collections/settings/records",
                data=body,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass


def _free_gb() -> float | None:
    try:
        return shutil.disk_usage(Path.home()).free / (1024 ** 3)
    except Exception:
        return None


def _ask_quota(config: dict) -> dict:
    free = _free_gb()
    console.print("\n[bold]How much storage will SelfCloud use?[/bold]")
    if free is not None:
        console.print(f"  [dim]{free:.2f} GB available on disk[/dim]")

    while True:
        gb = typer.prompt("  Size in GB", type=float)
        if free is not None and gb > free:
            console.print(f"  [red]Cannot exceed available disk space ({free:.2f} GB)[/red]")
            continue
        if gb <= 0:
            console.print("  [red]Must be greater than 0[/red]")
            continue
        break

    config["quota_gb"] = gb
    _save_config(config)
    return config


def _do_start() -> None:
    config = _load_config()
    if "quota_gb" not in config:
        config = _ask_quota(config)

    docker.ensure_docker()
    compose.setup()
    compose.up()

    if _wait_for_pocketbase():
        _sync_quota(config["quota_gb"])

    local_ip = network.get_local_ip()
    console.print("\n[bold green]✓ SelfCloud is running[/bold green]\n")
    console.print(f"  [bold]Address:[/bold]  {local_ip}")
    console.print(f"  [bold]Quota:[/bold]    {config['quota_gb']} GB\n")


def _do_stop() -> None:
    compose.down()
    console.print("[bold]SelfCloud stopped.[/bold]")


def _do_status() -> None:
    compose.ps()


def _do_check_updates() -> None:
    from importlib.metadata import version as pkg_version
    try:
        current = pkg_version("selfcloud")
    except Exception:
        current = "unknown"

    console.print(f"  Current version: [bold]{current}[/bold]")
    console.print("  [dim]Checking PyPI...[/dim]")

    try:
        with urllib.request.urlopen(
            "https://pypi.org/pypi/selfcloud/json", timeout=5
        ) as r:
            latest = json.loads(r.read())["info"]["version"]

        if latest == current:
            console.print(f"  [green]You are up to date ({current})[/green]")
        else:
            console.print(f"  [yellow]Update available: {current} → {latest}[/yellow]")
            console.print("  Run: [bold]pipx upgrade selfcloud[/bold]")
    except Exception:
        console.print("  [red]Could not reach PyPI[/red]")
        console.print("  Run manually: [bold]pipx upgrade selfcloud[/bold]")


def _do_change_quota() -> None:
    config = _load_config()
    current = config.get("quota_gb")
    if current is not None:
        console.print(f"\n  Current quota: [bold]{current} GB[/bold]")
    config = _ask_quota(config)

    if _wait_for_pocketbase(timeout=3):
        _sync_quota(config["quota_gb"])
        console.print(f"[green]✓ Quota updated to {config['quota_gb']} GB[/green]")
    else:
        console.print("[dim]SelfCloud is not running — quota will apply on next start.[/dim]")


def _do_uninstall() -> None:
    confirmed = Prompt.ask(
        "\n  [red]This will stop SelfCloud and delete all data in ~/.selfcloud. Continue?[/red]",
        choices=["yes", "no"],
        default="no",
    )
    if confirmed != "yes":
        console.print("Cancelled.")
        return

    console.print("[dim]Stopping containers...[/dim]")
    try:
        compose.down()
    except Exception:
        pass

    if _SELFCLOUD_DIR.exists():
        shutil.rmtree(_SELFCLOUD_DIR)
        console.print(f"[dim]Removed {_SELFCLOUD_DIR}[/dim]")

    console.print("\n[bold]SelfCloud uninstalled.[/bold]")
    console.print("To remove the package: [bold]pipx uninstall selfcloud[/bold]\n")


def _show_menu() -> None:
    print_banner()

    options = {
        "1": ("Start", _do_start),
        "2": ("Stop", _do_stop),
        "3": ("Status", _do_status),
        "4": ("Change storage quota", _do_change_quota),
        "5": ("Check for updates", _do_check_updates),
        "6": ("Uninstall", _do_uninstall),
    }

    for key, (label, _) in options.items():
        console.print(f"  [bold]{key}[/bold]. {label}")

    console.print()
    choice = Prompt.ask("  Select", choices=list(options.keys()))
    console.print()
    options[choice][1]()


@app.callback()
def main(ctx: typer.Context) -> None:
    if ctx.invoked_subcommand is None:
        _show_menu()


@app.command()
def start() -> None:
    """Start the SelfCloud backend."""
    print_banner()
    _do_start()


@app.command()
def stop() -> None:
    """Stop the SelfCloud backend."""
    print_banner()
    _do_stop()


@app.command()
def status() -> None:
    """Show running containers."""
    print_banner()
    _do_status()


@app.command()
def uninstall() -> None:
    """Stop and remove all SelfCloud data."""
    print_banner()
    _do_uninstall()
