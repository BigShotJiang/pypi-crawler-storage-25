import os
import shutil
import subprocess
import sys

import typer
from rich.console import Console

console = Console()


def ensure_docker() -> None:
    if shutil.which("docker"):
        return

    console.print("[yellow]Docker not found. Installing...[/yellow]")

    if sys.platform != "linux":
        console.print(
            "[red]Automatic Docker installation is only supported on Linux.[/red]\n"
            "Install Docker manually: https://docs.docker.com/get-docker/"
        )
        raise typer.Exit(1)

    try:
        subprocess.run(
            ["sudo", "sh", "-c", "curl -fsSL https://get.docker.com | sh"],
            check=True,
        )
        user = os.environ.get("SUDO_USER") or os.environ.get("USER", "")
        if user:
            subprocess.run(["sudo", "usermod", "-aG", "docker", user], check=True)
        console.print("[green]Docker installed.[/green]")
        console.print(
            "[yellow]You may need to log out and back in for group changes to take effect.[/yellow]"
        )
    except subprocess.CalledProcessError as exc:
        console.print(f"[red]Docker installation failed: {exc}[/red]")
        raise typer.Exit(1)
