"""Local adapter tests."""
