"""
S06 Context — 컨텍스트 수집 + 윈도우 관리

역할:
1. stage_params에서 선택된 RAG 컬렉션으로 문서 검색 (xgen-documents API)
2. stage_params에서 선택된 DB 연결의 스키마 요약 조회 (ServiceProvider.database 위임)
3. 검색 결과를 system_prompt에 추가
4. 토큰 예산 초과 시 컨텍스트 압축

실행기가 하드코딩하지 않음 — stage_params에서 리소스를 읽어서 동적 실행.
"""

import logging

from ..core.stage import Stage, StrategyInfo
from ..core.state import PipelineState
from ..core.service_registry import get_service_url

logger = logging.getLogger("harness.stage.context")

CHARS_PER_TOKEN = 3  # 평균 추정


class ContextStage(Stage):

    @property
    def stage_id(self) -> str:
        return "s06_context"

    @property
    def order(self) -> int:
        return 6

    def should_bypass(self, state: PipelineState) -> bool:
        # 첫 번째 루프에서만 RAG 검색 실행 (이후는 토큰 관리만)
        return state.loop_iteration > 1

    async def execute(self, state: PipelineState) -> dict:
        config = state.config
        results = {
            "rag_chunks": 0, "rag_collections": 0, "db_results": 0, "compacted": False,
            "ontology_results": 0, "folders_expanded": 0, "reranked": False,
        }

        # ── 1. RAG 컬렉션 + folders 확장 ──
        rag_collections: list[str] = list(self.get_param("rag_collections", state, []) or [])
        if not rag_collections and hasattr(config, 'rag_collections'):
            rag_collections = list(getattr(config, 'rag_collections', []) or [])

        # folders → 해당 폴더 안의 컬렉션 자동 추가 (DocumentService.list_collections 위임)
        folders: list[str] = list(self.get_param("folders", state, []) or [])
        if folders:
            services = state.metadata.get("services")
            doc_service = getattr(services, "documents", None) if services else None
            if doc_service and hasattr(doc_service, "list_collections"):
                try:
                    all_cols = await doc_service.list_collections() or []
                    expanded = [
                        c.get("collection_name") for c in all_cols
                        if isinstance(c, dict)
                        and (c.get("folder_id") in folders or str(c.get("folder_id")) in folders)
                        and c.get("collection_name")
                    ]
                    for col in expanded:
                        if col not in rag_collections:
                            rag_collections.append(col)
                    results["folders_expanded"] = len(expanded)
                except Exception as e:
                    logger.warning("[Context] folder expansion failed: %s", e)

        if rag_collections and state.user_input:
            # verbose: RAG fetch 시작
            from ..events.types import StageSubstepEvent as _Sub
            await state.emit_verbose(_Sub(
                stage_id=self.stage_id, substep="rag_fetch_start",
                meta={"collections": rag_collections, "top_k": int(self.get_param("rag_top_k", state, 4))},
            ))
            rag_context = await self._fetch_rag(
                collections=rag_collections,
                query=state.user_input,
                user_id=state.user_id or "0",
                top_k=int(self.get_param("rag_top_k", state, 4)),
            )
            # rerank — DocumentService.rerank 위임 (선택된 reranker 가 있을 때만)
            reranker_name: str = self.get_param("reranker", state, "") or ""
            if reranker_name and rag_context:
                services = state.metadata.get("services")
                doc_service = getattr(services, "documents", None) if services else None
                if doc_service and hasattr(doc_service, "rerank"):
                    try:
                        rag_context = await doc_service.rerank(
                            query=state.user_input, text=rag_context, provider=reranker_name,
                        ) or rag_context
                        results["reranked"] = True
                    except Exception as e:
                        logger.warning("[Context] rerank failed: %s", e)
            if rag_context:
                # system_prompt에 RAG 컨텍스트 추가
                state.system_prompt = f"{state.system_prompt}\n\n{rag_context}"
                results["rag_chunks"] = rag_context.count("[")  # 대략적 청크 수
                results["rag_collections"] = len(rag_collections)
                logger.info("[Context] RAG: %d collections, added to system prompt", len(rag_collections))
            from ..events.types import StageSubstepEvent as _Sub2
            await state.emit_verbose(_Sub2(
                stage_id=self.stage_id, substep="rag_fetch_complete",
                meta={"chunks": results.get("rag_chunks", 0)},
            ))

        # ── 1.5 Ontology / GraphRAG — DocumentService.ontology_query 위임 ──
        ontology_collections: list[str] = list(self.get_param("ontology_collections", state, []) or [])
        if ontology_collections and state.user_input:
            services = state.metadata.get("services")
            doc_service = getattr(services, "documents", None) if services else None
            if doc_service and hasattr(doc_service, "ontology_query"):
                try:
                    onto_chunks: list[str] = []
                    for col in ontology_collections:
                        try:
                            r = await doc_service.ontology_query(state.user_input, col)
                            if r:
                                onto_chunks.append(f"[graph:{col}]\n{r if isinstance(r, str) else str(r)[:2000]}")
                        except Exception as e:
                            logger.warning("[Context] ontology_query (%s) failed: %s", col, e)
                    if onto_chunks:
                        state.system_prompt = (state.system_prompt or "") + (
                            "\n\n<graph_rag>\n" + "\n\n".join(onto_chunks) + "\n</graph_rag>"
                        )
                        results["ontology_results"] = len(onto_chunks)
                        logger.info("[Context] ontology: %d collections injected", len(onto_chunks))
                except Exception as e:
                    logger.warning("[Context] ontology pipeline error: %s", e)

        # ── 2. DB 연결 — services.database.get_schema_summary 로 위임 ──
        # 라이브러리는 connection_name 같은 추상 식별자만 다루고,
        # 실제 SQL/엔진별 해석은 ServiceProvider.database 구현체 책임.
        db_connections: list[str] = self.get_param("db_connections", state, [])
        if db_connections:
            services = state.metadata.get("services")
            if services and getattr(services, "database", None):
                summaries: list[str] = []
                for conn in db_connections:
                    try:
                        summary = await services.database.get_schema_summary(conn)
                        if summary:
                            summaries.append(summary)
                    except Exception as e:
                        logger.warning("[Context] DB schema 조회 실패 (%s): %s", conn, e)
                if summaries:
                    state.system_prompt += "\n\n<db_context>\n" + "\n".join(summaries) + "\n</db_context>"
                    results["db_results"] = len(summaries)
                    logger.info("[Context] DB context injected: %d connections", len(summaries))
                else:
                    results["db_results"] = 0
                    logger.info("[Context] db_connections: %d selected, schema 조회 결과 없음", len(db_connections))
            else:
                results["db_results"] = 0
                logger.info(
                    "[Context] db_connections: %d selected, but ServiceProvider.database 가 주입되지 않음",
                    len(db_connections),
                )

        # ── 3. 토큰 예산 관리 ──
        context_window = self.get_param("context_window", state, config.context_window if config else 200_000)
        max_tokens = config.max_tokens if config else 8192
        available_tokens = context_window - max_tokens

        if config and config.thinking_enabled:
            available_tokens -= config.thinking_budget_tokens

        total_chars = len(state.system_prompt)
        for msg in state.messages:
            content = msg.get("content", "")
            if isinstance(content, str):
                total_chars += len(content)
            elif isinstance(content, list):
                for block in content:
                    if isinstance(block, dict):
                        total_chars += len(str(block.get("text", "")))
                        total_chars += len(str(block.get("content", "")))

        estimated_tokens = total_chars // CHARS_PER_TOKEN
        budget_used = estimated_tokens / available_tokens if available_tokens > 0 else 1.0

        # 압축 전략 디스패치 — token_budget(기본) 또는 sliding_window
        strategy_name = self.get_param("strategy", state, "token_budget")
        compaction_threshold = self.get_param("compaction_threshold", state, 80) / 100.0

        if strategy_name == "sliding_window":
            # 슬라이딩 윈도우: 최근 N개 메시지만 유지 (심플하지만 채팅에 효과적)
            window_size = int(self.get_param("window_size", state, 20))
            if len(state.messages) > window_size:
                state.messages = state.messages[-window_size:]
                results["compacted"] = True
                logger.info("[Context] SlidingWindow: kept last %d messages", window_size)
        elif budget_used > compaction_threshold and len(state.messages) > 4:
            # token_budget(기본): first + last 3
            state.messages = [state.messages[0]] + state.messages[-3:]
            results["compacted"] = True
            logger.info("[Context] Compacted: kept first + last 3 messages")

        results["estimated_tokens"] = estimated_tokens
        results["budget_used"] = round(budget_used, 2)

        logger.info("[Context] tokens=%d, budget=%.0f%%, rag=%d cols",
                    estimated_tokens, budget_used * 100, len(rag_collections))
        return results

    async def _fetch_rag(self, collections: list[str], query: str, user_id: str, top_k: int = 4) -> str:
        """xgen-documents API로 RAG 검색.

        실행기가 직접 하드코딩하지 않고, stage_params에서 선택된 컬렉션만 검색.
        """
        import httpx

        parts = []
        docs_url = get_service_url('documents')
        if not docs_url:
            logger.info("documents service not registered, skipping RAG")
            return []
        try:
            async with httpx.AsyncClient(timeout=httpx.Timeout(15)) as client:
                for col_name in collections:
                    try:
                        resp = await client.post(
                            f"{docs_url}/api/retrieval/documents/search",
                            json={
                                "collection_name": col_name,
                                "query_text": query,
                                "limit": top_k,
                                "score_threshold": 0.1,
                            },
                            headers={
                                "x-user-id": str(user_id),
                                "x-user-name": "harness",
                                "x-user-admin": "true",
                                "x-user-superuser": "true",
                            },
                        )
                        if resp.status_code == 200:
                            results = resp.json().get("results", [])
                            if results:
                                part = f"## {col_name} ({len(results)}건)\n\n"
                                for i, r in enumerate(results):
                                    part += f"[{i+1}] {r.get('file_name', '')} ({r.get('score', 0):.3f})\n{r.get('chunk_text', '')}\n\n"
                                parts.append(part)
                    except Exception as e:
                        logger.warning("[Context] RAG search failed for %s: %s", col_name, e)
                        continue
        except Exception as e:
            logger.error("[Context] RAG client error: %s", e)

        return "\n\n".join(parts)

    def list_strategies(self) -> list[StrategyInfo]:
        return [
            StrategyInfo("token_budget", "RAG 검색 + 토큰 예산 압축", is_default=True),
            StrategyInfo("sliding_window", "슬라이딩 윈도우 (최근 N개 메시지)"),
        ]
