## [0.0.4] – 2026-05-11
### Fixed
- ``_recursive_validate`` now recurses into any :class:`collections.abc.Mapping`, not only built-in ``dict``, so nested values are checked (e.g. :class:`collections.UserDict`).
- ``_check_type`` supports ``typing.Literal``, ``Type[T]`` / ``type[T]``, ``typing.Self`` (or ``typing_extensions.Self`` on older interpreters), ``typing.Final``, ``typing.NewType`` (including chained ``NewType``), ``typing.TypeVar`` (constraints and bounds), and ``typing.ForwardRef`` objects left over from ``from __future__ import annotations``.
- ``_check_typeddict`` now resolves a TypedDict's annotations through :func:`typing.get_type_hints` (with raw fallback) so structural checks work under deferred annotations.
- Path constraint traversal accepts decimal index segments for sequences (including negative indices) and never falls through to iterating mapping keys when a key is missing.
- ``_recursive_validate`` and ``_iter_path_values`` no longer consume single-use iterators or generators passed as arguments — a new ``_is_safe_iterable`` helper excludes ``Iterator``, mappings, and ``str`` / ``bytes`` / ``bytearray``.
- ``_check_type`` for ``Iterable[T]`` is shallow when the value is an iterator: it confirms iterability without consuming it.
- The constraint parser tolerates whitespace inside ranges (``"1 - 3"`` parses as ``"1-3"``) and silently skips empty trailing entries between semicolons.
- Class-based annotations whose ``isinstance`` check raises ``TypeError`` (e.g. non-runtime ``typing.Protocol``) no longer crash the validator; non-runtime ``Protocol`` subclasses are now validated **structurally** by checking that every declared protocol attribute is present on the supplied value.
- ``Callable[[…], R]`` annotations now also verify positional arity (via ``inspect.signature``); fully variadic and uninspectable callables are accepted, mismatched arities are reported.
- Class annotations whose metaclass raises ``TypeError`` from ``__instancecheck__`` / ``__subclasscheck__`` now fail closed instead of silently accepting any value.
- Path-spec parsing distinguishes a *literal empty key* from the wildcard branch: dict keys that are literally ``""`` can be addressed via the new ``\!`` escape (``data:\!=0-3``). Literal ``*`` is similarly available via ``\*``.
- Specs whose first segment is empty (``":x=1-3"``, ``":=1-3"``) now emit a parse-time warning instead of being silently dropped.

### Added
- Reorganised exhaustive test suite under ``tests/`` (helpers, ``_check_type``, ``_recursive_validate``, globals/context, end-to-end ``validate_args``, and edge-case coverage) achieving **100 %** line coverage of ``typekeeper/typekeeper.py``.
- Internal LRU cache for ``(origin, args)`` lookups (``_cached_origin_args``) shaving ~10 % off type-check overhead.
- New examples: ``complex_typing.py``, ``typeddicts.py``, ``forward_refs.py``, ``globals_and_context.py``, ``protocols.py``. All examples now print per-call validation overhead via ``examples/_bench.py``.
- Regression suite (`tests/test_bug_validation.py`) covering the 10 bugs raised against 0.0.4 — five real defects (now fixed) and five locked-in by-design behaviours.
- Rewritten profiling harness at ``tools/profile.py`` with scenario benchmarks (bare vs. checked vs. suspended), optional ``--cprofile`` breakdown, and ``--json`` output.
- Performance section in the README with measured per-scenario overhead.

### Changed
- Project metadata moved from ``setup.py`` to ``pyproject.toml`` (PEP 621). Added the ``dev`` extra and per-tool configuration sections (``pytest``, ``coverage``).
- ``_split_path`` returns a list of ``_Segment(value, literal)`` named tuples. Backwards-compatible behaviour is preserved for non-escaped paths; consumers that introspected the previous ``list[str]`` shape should access the ``.value`` attribute.

### Removed
- The legacy ``lengths=`` keyword argument on ``validate_args``. The
  parameter now covers numeric ranges, length ranges, and path specs,
  so the misleading name is gone; pass ``constraints=`` exclusively.

## [0.0.3b1] – 2025-06-14
### Added
- Support colon-delimited path specs with `:` and `\` escapes.
- Wildcard `*` segments and trailing colon shorthand.
- Later path specs override earlier ones; duplicate primitives handled correctly.
- Recursively calls `_validate()` on nested objects.
- Fixed "int" not being matched to <class 'int'> while using future annotations
- Global `set_stop_on_error()` toggle to raise a `ValueError` on the first validation failure.

### Removed
- Attribute-based traversal in spec paths. Only keys and indexes are followed.

## [0.0.2] – 2025-04-29
### Features
- Add support for `*args` and `**kwargs` type hints while keeping standard IDE checkers happy.

### Refactoring
- Update type hint for `suspended_arg_checks()` to match new annotation behavior.

### Documentation
- Simplify `_recursive_validate` docstring to concise Sphinx‐style format.
