"""
Argument Checker Library
Provides a decorator to validate function parameters against type annotations,
default values, and numeric or length specifications.
"""

from __future__ import annotations

import inspect
import re
import warnings
from collections.abc import (
    Callable as CallableABC,
    Iterable,
    Iterator,
    Mapping,
    MutableMapping,
    MutableSequence,
    Sequence,
    Set as SetABC,
)
from contextlib import contextmanager
from functools import lru_cache, wraps
from typing import (
    Annotated,
    Any,
    Callable,
    Dict,
    Final,
    ForwardRef,
    Generator,
    Generic,
    Literal,
    NamedTuple,
    Protocol,
    Tuple,
    TypeVar,
    Union,
    get_args,
    get_origin,
)
from typing import get_type_hints

try:  # Python < 3.10
    from types import UnionType as _UnionType
except ImportError:  # pragma: no cover - older interpreters
    _UnionType = None

try:
    from typing import Self as _TypingSelf
except ImportError:  # pragma: no cover - Python < 3.11
    try:
        from typing_extensions import Self as _TypingSelf
    except ImportError:  # pragma: no cover
        _TypingSelf = None

try:
    from typing import is_typeddict as _is_typeddict
except ImportError:  # pragma: no cover - Python < 3.10
    try:
        from typing_extensions import is_typeddict as _is_typeddict
    except ImportError:  # pragma: no cover

        def _is_typeddict(obj) -> bool:
            return isinstance(obj, type) and hasattr(obj, "__required_keys__")


# Default namespace for resolving stray ``ForwardRef`` annotations.
import builtins as _builtins
import typing as _typing

_TYPING_NAMESPACE = {
    **vars(_builtins),
    **{name: getattr(_typing, name) for name in dir(_typing) if not name.startswith("_")},
}


# Global flag to enable/disable all checks
RUN_CHECKS: bool = True
STOP_ON_ERROR: bool = False


def set_stop_on_error(stop: bool) -> None:
    """Raise a ``ValueError`` as soon as a validation warning would occur."""

    global STOP_ON_ERROR
    STOP_ON_ERROR = stop


def set_arg_checks(enabled: bool) -> None:
    """
    Globally enable or disable argument checking for decorated functions.

    :param enabled: True to enable checks, False to disable.
    """
    global RUN_CHECKS
    RUN_CHECKS = enabled


@contextmanager
def suspended_arg_checks() -> Generator[None, Any, None]:
    """
    Temporarily disable argument checking within a with-block.

    Usage:
        with suspended_arg_checks():
            # checks are disabled here
            foo(...)
        # checks are restored here
    """
    global RUN_CHECKS
    original = RUN_CHECKS
    RUN_CHECKS = False
    try:
        yield
    finally:
        RUN_CHECKS = original


def _emit_warning(
    message: str, filename: str, lineno: int, *, stop_on_error: bool | None = None
) -> None:
    """
    Emit a standardized warning at a given file and line number.

    :param message: Warning message content.
    :param filename: File path to attribute the warning to.
    :param lineno: Line number in the file for the warning.
    """
    if STOP_ON_ERROR if stop_on_error is None else stop_on_error:
        raise ValueError(f"{filename}:{lineno}: {message}")
    warnings.warn_explicit(message, UserWarning, filename, lineno)


@lru_cache(maxsize=1024)
def _cached_origin_args(annotation):
    """Memoize ``(get_origin(annotation), get_args(annotation))`` lookups.

    The typing introspection helpers are surprisingly expensive in tight
    loops because they walk the annotation object every time.  Caching by
    annotation identity/equality removes that cost for the common case of
    repeated calls with the same annotation.
    """

    return get_origin(annotation), get_args(annotation)


@lru_cache(maxsize=None)
def _get_source_lines(func):
    """
    Retrieve the source code lines and starting line number for a function.

    :param func: Function object to inspect.
    :return: Tuple of (list of source lines, starting line number).
    """
    try:
        return inspect.getsourcelines(func)
    except (TypeError, OSError):
        return ["\n"], 0


def _parse_specs(
    constraints: str, *, stop_on_error: bool | None = None
) -> list[tuple[str, list[tuple[float, float]]]]:
    """
    Convert a spec string into an ordered sequence of parameter/range pairs.

    :param constraints: Specification string, e.g. "x=1,3-5; y=0-2".
    :return: List of (name, ranges) in the order specified.
    """
    specs: list[tuple[str, list[tuple[float, float]]]] = []
    if not constraints:
        return specs
    for token in constraints.split(";"):
        token = token.strip()
        if not token:
            # Silently skip empty entries (e.g. trailing semicolons).
            continue
        if "=" not in token:
            _emit_warning(
                f"Invalid spec format '{token}'",
                __file__,
                0,
                stop_on_error=stop_on_error,
            )
            continue
        name, spec_text = map(str.strip, token.split("=", 1))
        # Empty / leading-colon parameter names yield specs that can never
        # match any bound argument; report instead of silently dropping.
        first_seg = _split_path(name)[0] if name else _Segment("", False)
        if first_seg.value == "" and not first_seg.literal:
            _emit_warning(
                f"Invalid spec '{token}': empty parameter name",
                __file__,
                0,
                stop_on_error=stop_on_error,
            )
            continue
        ranges: list[tuple[float, float]] = []
        for tok in spec_text.split(","):
            tok = tok.strip()
            if not tok:
                continue
            # Allow whitespace around the inner ``-`` separator and around the
            # numeric values themselves while keeping negative-number support.
            collapsed = re.sub(r"\s+", "", tok)
            m_range = re.fullmatch(r"(-?\d+(?:\.\d+)?)-(-?\d+(?:\.\d+)?)", collapsed)
            m_single = re.fullmatch(r"(-?\d+(?:\.\d+)?)", collapsed)
            if m_range:
                lo, hi = float(m_range.group(1)), float(m_range.group(2))
                if lo > hi:
                    _emit_warning(
                        f"Invalid range for '{name}': {lo} > {hi}",
                        __file__,
                        0,
                        stop_on_error=stop_on_error,
                    )
                    continue
                ranges.append((lo, hi))
            elif m_single:
                n = float(m_single.group(1))
                ranges.append((n, n))
            else:
                _emit_warning(
                    f"Invalid spec token '{tok}' for parameter '{name}'",
                    __file__,
                    0,
                    stop_on_error=stop_on_error,
                )
        if ranges:
            specs.append((name, ranges))
    return specs


def _is_safe_iterable(obj) -> bool:
    """Return True when iterating *obj* is non-destructive and meaningful.

    Strings, byte sequences, mappings, and one-shot iterators (generators)
    are excluded so validation never silently consumes data.
    """

    if isinstance(obj, (str, bytes, bytearray)):
        return False
    if isinstance(obj, Mapping):
        return False
    if isinstance(obj, Iterator):
        return False
    return isinstance(obj, Iterable)


class _Segment(NamedTuple):
    """A single component of a parsed path spec.

    ``value`` holds the textual key/index for the segment.  ``literal`` is
    True when the segment originated from one or more escape sequences (or
    the explicit empty-literal sigil ``\\!``); literal segments are
    matched verbatim and never trigger the wildcard branch even when their
    value is ``""`` or ``"*"``.
    """

    value: str
    literal: bool


def _split_path(name: str) -> list[_Segment]:
    """Split a colon-delimited path honoring escape sequences.

    Supported escapes (the leading character is a backslash):

    - ``\\:``  literal ``:`` inside a segment.
    - ``\\\\`` literal backslash.
    - ``\\*``  literal ``*`` segment (overrides wildcard semantics).
    - ``\\!``  literal empty segment (overrides wildcard semantics);
      addresses dict keys that are literally ``""``.

    Any other escape sequence preserves the character that follows the
    backslash but still marks the segment as ``literal=True``.
    """

    parts: list[_Segment] = []
    buf: list[str] = []
    escape = False
    has_escape = False  # any escape applied to current segment
    for ch in name:
        if escape:
            if ch != "!":
                # Treat any other escaped char as a literal of that char.
                buf.append(ch)
            has_escape = True
            escape = False
        elif ch == "\\":
            escape = True
        elif ch == ":":
            parts.append(_Segment("".join(buf), has_escape))
            buf = []
            has_escape = False
        else:
            buf.append(ch)
    parts.append(_Segment("".join(buf), has_escape))
    return parts


def _iter_path_values(obj, path, prefix: list[str] | None = None):
    """Yield ``(path, value)`` pairs found by traversing *path* starting at *obj*.

    *path* is a list of :class:`_Segment` instances (as produced by
    :func:`_split_path`); a bare ``list[str]`` is also accepted for
    backwards compatibility and treated as a list of non-literal segments.
    """

    if prefix is None:
        prefix = []

    if not path:
        yield prefix, obj
        return

    seg, *rest = path
    if not isinstance(seg, _Segment):
        seg = _Segment(seg, False)
    value = seg.value

    # Wildcard only when the segment was *not* produced by escape sequences.
    if not seg.literal and value in ("", "*"):
        if isinstance(obj, Mapping):
            for key, val in obj.items():
                yield from _iter_path_values(val, rest, prefix + [str(key)])
        elif _is_safe_iterable(obj):
            for idx, item in enumerate(obj):
                yield from _iter_path_values(item, rest, prefix + [str(idx)])
        return

    if isinstance(obj, Mapping):
        if value in obj:
            yield from _iter_path_values(obj[value], rest, prefix + [value])
        return

    if (
        not seg.literal
        and isinstance(obj, Sequence)
        and not isinstance(obj, (str, bytes, bytearray))
        and (value.isdigit() or (value.startswith("-") and value[1:].isdigit()))
    ):
        idx = int(value)
        if -len(obj) <= idx < len(obj):
            yield from _iter_path_values(obj[idx], rest, prefix + [value])
        return

    if _is_safe_iterable(obj):
        for idx, item in enumerate(obj):
            yield from _iter_path_values(item, path, prefix + [str(idx)])


def is_immutable(obj) -> bool:
    """
    Determine if an object is deeply immutable.

    :param obj: Any object to check.
    :return: True if object is immutable, False otherwise.
    """
    im_types = (type(None), bool, int, float, complex, str, bytes, range)
    if isinstance(obj, im_types):
        return True
    if isinstance(obj, tuple):
        return all(is_immutable(item) for item in obj)
    if isinstance(obj, frozenset):
        return all(is_immutable(item) for item in obj)
    return False


def _is_protocol_class(annotation) -> bool:
    """Return True when *annotation* is a :class:`typing.Protocol` subclass."""

    return (
        inspect.isclass(annotation)
        and getattr(annotation, "_is_protocol", False)
        and annotation is not Protocol
    )


def _protocol_attrs(proto) -> frozenset:
    """Return the set of attribute names declared by *proto*.

    Prefers the modern ``__protocol_attrs__`` attribute (Python 3.12+)
    and falls back to walking the MRO for older interpreters.
    """

    declared = getattr(proto, "__protocol_attrs__", None)
    if declared is not None:
        return frozenset(declared)
    names: set[str] = set()
    for base in proto.__mro__:
        if base in (object, Protocol, Generic):
            continue
        names.update(getattr(base, "__annotations__", {}).keys())
        for attr in vars(base):
            if attr.startswith("_"):
                continue
            names.add(attr)
    return frozenset(names)


def _check_protocol(value, proto) -> bool:
    """Validate *value* against the structure of a :class:`Protocol`.

    Runtime-checkable protocols use the standard ``isinstance`` path when
    possible; otherwise every declared protocol member must be present on
    the value.  When the protocol declares no inspectable members, the
    value is accepted (we have nothing to check against).
    """

    if getattr(proto, "_is_runtime_protocol", False):
        try:
            return isinstance(value, proto)
        except TypeError:  # pragma: no cover - falls back to structural
            pass
    attrs = _protocol_attrs(proto)
    if not attrs:
        return True
    return all(hasattr(value, name) for name in attrs)


def _check_callable_arity(value, params) -> bool:
    """Best-effort check that *value* accepts ``len(params)`` positional args.

    Returns True when:
      - the value is not introspectable via :func:`inspect.signature`, or
      - the value accepts ``*args`` (variadic), or
      - the declared positional count fits between the minimum required
        and maximum accepted positional parameters of the value.
    """

    expected = len(params)
    try:
        sig = inspect.signature(value)
    except (TypeError, ValueError):
        return True
    min_required = 0
    max_accepted = 0
    has_var_positional = False
    for p in sig.parameters.values():
        if p.kind is inspect.Parameter.VAR_POSITIONAL:
            has_var_positional = True
            continue
        if p.kind in (
            inspect.Parameter.POSITIONAL_ONLY,
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
        ):
            if p.default is inspect._empty:
                min_required += 1
            max_accepted += 1
    if has_var_positional:
        return expected >= min_required
    return min_required <= expected <= max_accepted


def _check_typeddict(value, td) -> bool:
    if not isinstance(value, dict):
        return False
    try:
        annotations = get_type_hints(td, include_extras=True)
    except Exception:
        annotations = getattr(td, "__annotations__", None) or {}
    if not annotations:
        return True
    required = getattr(td, "__required_keys__", None)
    optional = getattr(td, "__optional_keys__", None)
    if required is not None:
        for key in required:
            if key not in value:
                return False
            if not _check_type(value[key], annotations[key]):
                return False
    if optional is not None:
        for key in optional:
            if key in value and not _check_type(value[key], annotations[key]):
                return False
    if required is None and optional is None:
        for key, ann in annotations.items():
            if key not in value or not _check_type(value[key], ann):
                return False
    return True


def _check_type(value, annotation) -> bool:
    """
    Recursively check whether *value* satisfies *annotation*.

    Handles ``typing`` / standard-library forms including ``Union`` (and PEP 604
    unions where exposed as ``types.UnionType``), ``Annotated``, ``Literal``,
    ``Final``, ``Type[...]`` / ``type[...]``, ``NewType``, ``TypeVar`` (bounds
    and constraints), ``TypedDict`` (structural dict checks), ``Self``,
    builtins and ABC generics, and ``Callable``. String annotations that were
    not resolved by ``get_type_hints`` are not enforced. Values with odd
    non-checkable annotation objects are accepted.
    """
    if annotation is Any:
        return True
    if _TypingSelf is not None and annotation is _TypingSelf:
        return True
    if isinstance(annotation, TypeVar):
        if annotation.__constraints__:
            return any(_check_type(value, c) for c in annotation.__constraints__)
        bound = annotation.__bound__
        if bound is not None:
            return _check_type(value, bound)
        return True
    if getattr(annotation, "__supertype__", None) is not None:
        supertype = annotation.__supertype__
        return _check_type(value, supertype)
    if isinstance(annotation, ForwardRef):
        # Unresolved forward reference (e.g. left over from
        # ``from __future__ import annotations``).  Try to resolve it against
        # the typing namespace; fall back to "unchecked" otherwise.
        forward = annotation.__forward_arg__
        try:
            resolved = eval(forward, _TYPING_NAMESPACE, None)  # noqa: S307
        except Exception:
            return True
        if resolved is annotation:  # pragma: no cover - guards against rare self-cycles
            return True
        return _check_type(value, resolved)
    if isinstance(annotation, str):
        # Stringified annotations that did not resolve via ``get_type_hints``;
        # treat as unchecked (including unknown forward references).
        return True
    try:
        origin, args = _cached_origin_args(annotation)
    except TypeError:  # pragma: no cover - unhashable annotation falls back below
        try:
            origin = get_origin(annotation)
            args = get_args(annotation)
        except TypeError:
            return True

    if origin is Literal:
        return value in args
    container_origin = origin in (list, tuple, dict, set, frozenset)
    if container_origin and not isinstance(value, origin):
        return False
    if origin is Union or (_UnionType is not None and origin is _UnionType):
        return any(_check_type(value, arg) for arg in args)
    if origin is Annotated:
        return _check_type(value, args[0])
    if origin is Final:
        return _check_type(value, args[0]) if args else True
    if origin in (Sequence, MutableSequence):
        if not isinstance(value, Sequence):
            return False
        return (not args) or all(_check_type(v, args[0]) for v in value)
    if origin in (Mapping, MutableMapping):
        if not isinstance(value, Mapping):
            return False
        if args:
            kt, vt = args
            return all(
                _check_type(k, kt) and _check_type(v, vt) for k, v in value.items()
            )
        return True
    if origin is list:
        return (not args) or all(_check_type(v, args[0]) for v in value)
    if origin is tuple:
        if not args:
            return True
        if len(args) == 2 and args[1] is Ellipsis:
            return all(_check_type(v, args[0]) for v in value)
        if len(args) == len(value):
            return all(_check_type(v, a) for v, a in zip(value, args))
        return False
    if origin is dict:
        if args:
            kt, vt = args
            return all(
                _check_type(k, kt) and _check_type(v, vt) for k, v in value.items()
            )
        return True
    if origin in (set, frozenset):
        return (not args) or all(_check_type(v, args[0]) for v in value)
    if origin is Iterable:
        try:
            iter(value)
        except TypeError:
            return False
        # Never iterate a single-use iterator/generator here; doing so would
        # silently consume the caller's data.  Element-level checking is
        # skipped in that case but the shallow ``Iterable`` claim still holds.
        if isinstance(value, Iterator) or not args:
            return True
        return all(_check_type(v, args[0]) for v in value)
    if origin in (Callable, CallableABC):
        if not callable(value):
            return False
        if not args or args[0] is Ellipsis:
            return True
        params = args[0]
        if not isinstance(params, (list, tuple)):  # pragma: no cover - defensive
            return True
        return _check_callable_arity(value, params)
    if origin is type:
        if not isinstance(value, type):
            return False
        if not args:
            return True
        expected = args[0]
        try:
            return issubclass(value, expected)
        except TypeError:
            return False
    if _is_typeddict(annotation):
        return _check_typeddict(value, annotation)
    if _is_protocol_class(annotation):
        return _check_protocol(value, annotation)
    if inspect.isclass(annotation):
        try:
            return isinstance(value, annotation)
        except TypeError:
            # The annotation's metaclass refuses to perform isinstance
            # checks.  Fail closed so the user is alerted via the standard
            # type-mismatch warning instead of silently accepting anything.
            return False
    if origin is not None and isinstance(origin, type):
        return isinstance(value, origin)
    return True


def _recursive_validate(obj, path=None, *, _seen=None) -> list[tuple[list, object]]:
    """
    Recursively validate an object and its nested elements.

    :param obj: The object to validate
    :param path: Current traversal path (for internal recursion).
    :returns: List of `(path, bad_value)` tuples for each validation failure.
    """
    path = [] if path is None else path.copy()
    _seen = set() if _seen is None else _seen

    obj_id = id(obj)
    if obj_id in _seen:
        return []
    _seen.add(obj_id)
    failures: list[tuple[list, object]] = []

    # 1) run the object’s own _validate()
    validator = getattr(obj, "_validate", None)
    if callable(validator):
        try:
            ok = validator()
        except Exception:
            ok = False
        if not ok:
            failures.append((path, obj))

    # 2) recurse into mappings
    if isinstance(obj, Mapping):
        for key, val in obj.items():
            failures.extend(_recursive_validate(key, path + [f"[key {key!r}]"], _seen=_seen))
            failures.extend(_recursive_validate(val, path + [f"[{key!r}]"], _seen=_seen))
    # 3) recurse into safe iterables (never iterators/generators)
    elif _is_safe_iterable(obj):
        for idx, item in enumerate(obj):
            failures.extend(_recursive_validate(item, path + [f"[{idx}]"], _seen=_seen))

    return failures


def validate_args(
    _func=None,
    constraints: str | None = None,
    *,
    ignore_defaults: bool = False,
    stop_on_error: bool | None = None,
):
    """
    Decorator to validate function parameters against type hints,
    default values, and numeric or length specifications.

    :param _func: Function object to inspect.
    :param constraints: Specification string for ranges, e.g. "x=1-5; y=3".
    :param ignore_defaults: If True, skip mutable default argument warnings.
    :param stop_on_error: Override the global ``STOP_ON_ERROR`` for this decorator.
    :return: Decorated function with validation logic applied on call.
    """
    if not RUN_CHECKS:
        return _func if _func is not None else (lambda f: f)

    spec_list = _parse_specs(constraints, stop_on_error=stop_on_error)

    def decorator(func):
        if not RUN_CHECKS:
            return func
        base_sig = inspect.signature(func)

        decorator_stop = STOP_ON_ERROR if stop_on_error is None else stop_on_error

        def apply_annotations(sig, hints):
            params = []
            for name, param in sig.parameters.items():
                ann = hints.get(name, param.annotation)
                params.append(param.replace(annotation=ann))
            sig = sig.replace(parameters=params)

            params = []
            for name, param in sig.parameters.items():
                ann = param.annotation
                if param.kind is inspect.Parameter.VAR_POSITIONAL:
                    if ann is not inspect._empty:
                        param = param.replace(annotation=Tuple[ann, ...])
                elif param.kind is inspect.Parameter.VAR_KEYWORD:
                    if ann is not inspect._empty:
                        param = param.replace(annotation=Dict[str, ann])
                params.append(param)
            return sig.replace(parameters=params)

        try:
            hints = get_type_hints(func, include_extras=True)
            hints_resolved = True
        except (NameError, TypeError):
            hints = dict(getattr(func, "__annotations__", {}))
            hints_resolved = False

        sig = apply_annotations(base_sig, hints)

        # Use cached source lookup
        src_lines, start = _get_source_lines(func)
        def_code = getattr(func, "__code__", None)
        def_filename = def_code.co_filename if def_code else getattr(func, "__module__", "<unknown>")
        decorator_lineno = None
        def_lineno = def_code.co_firstlineno if def_code else start

        # locate decorator and def lines
        for idx, line in enumerate(src_lines):
            stripped = line.lstrip()
            if stripped.startswith("@validate_args") and decorator_lineno is None:
                decorator_lineno = start + idx
            if stripped.startswith("def "):
                def_lineno = start + idx
                break

        # Decoration-time checks
        for pname, param in sig.parameters.items():
            default = param.default
            ann = param.annotation
            if (
                not ignore_defaults
                and default is not inspect._empty
                and not is_immutable(default)
            ):
                _emit_warning(
                    f"Mutable default for '{pname}' in '{func}': {default!r}",
                    def_filename,
                    decorator_lineno or def_lineno,
                    stop_on_error=decorator_stop,
                )
            if (
                default is not inspect._empty
                and ann is not inspect._empty
                and not _check_type(default, ann)
            ):
                _emit_warning(
                    f"Default for '{pname}' in '{func}' does not match annotation {ann!r}; expected {ann!r}, got {type(default)!r}",
                    def_filename,
                    decorator_lineno or def_lineno,
                    stop_on_error=decorator_stop,
                )

        @wraps(func)
        def wrapper(*args, **kwargs):
            nonlocal sig, hints, hints_resolved
            if not RUN_CHECKS:
                return func(*args, **kwargs)
            current_stop = STOP_ON_ERROR if stop_on_error is None else stop_on_error
            frame = inspect.currentframe().f_back
            call_filename = frame.f_code.co_filename
            call_lineno = frame.f_lineno
            del frame

            if not hints_resolved:
                try:
                    hints = get_type_hints(func, include_extras=True)
                    sig = apply_annotations(base_sig, hints)
                    hints_resolved = True
                except (NameError, TypeError):
                    pass

            bound = sig.bind_partial(*args, **kwargs)
            bound.apply_defaults()

            for pname, val in bound.arguments.items():
                bads = _recursive_validate(val)
                for path, bad in bads:
                    loc = "".join(path) or "[self]"
                    _emit_warning(
                        f"Recursed value of parameter '{pname}' at depth {loc} failed _validate in '{func}' (defined at {def_filename}:{def_lineno})",
                        call_filename,
                        call_lineno,
                        stop_on_error=current_stop,
                    )

            # Call-time checks: numeric ranges & lengths
            seen: set[tuple] = set()
            for spec_name, ranges in reversed(spec_list):
                parts = _split_path(spec_name)
                pname = parts[0].value
                if pname not in bound.arguments:
                    continue
                items = list(_iter_path_values(bound.arguments[pname], parts[1:]))
                if not items:
                    continue
                for path_frag, val in items:
                    key = tuple([pname] + path_frag)
                    if key in seen:
                        continue
                    seen.add(key)
                    if isinstance(val, (int, float)):
                        if not any(lo <= val <= hi for lo, hi in ranges):
                            _emit_warning(
                                f"Value for '{spec_name}'={val} not in ranges {ranges} (defined at {def_filename}:{def_lineno})",
                                call_filename,
                                call_lineno,
                                stop_on_error=current_stop,
                            )
                    else:
                        try:
                            length = len(val)
                        except Exception:
                            _emit_warning(
                                f"Cannot determine length of '{spec_name}' for spec {ranges} (defined at {def_filename}:{def_lineno})",
                                call_filename,
                                call_lineno,
                                stop_on_error=current_stop,
                            )
                            continue
                        if not any(lo <= length <= hi for lo, hi in ranges):
                            _emit_warning(
                                f"Length of '{spec_name}'={length} not in ranges {ranges} (defined at {def_filename}:{def_lineno})",
                                call_filename,
                                call_lineno,
                                stop_on_error=current_stop,
                            )

            # Call-time checks: types
            for name, val in bound.arguments.items():
                annt = sig.parameters[name].annotation
                if annt is not inspect._empty and not _check_type(val, annt):
                    _emit_warning(
                        f"Arg '{name}' to '{func}' mismatches {annt!r}; expected {annt!r}, got {type(bound.arguments[name])!r} (defined at {def_filename}:{def_lineno})",
                        call_filename,
                        call_lineno,
                        stop_on_error=current_stop,
                    )

            return func(*bound.args, **bound.kwargs)

        return wrapper

    return (lambda f: decorator if f is None else decorator(f))(_func)
