"""Public API surface for typekeeper."""

from .typekeeper import (
    set_arg_checks,
    set_stop_on_error,
    suspended_arg_checks,
    validate_args,
)

__version__ = "0.0.4"

__all__ = [
    "__version__",
    "set_arg_checks",
    "set_stop_on_error",
    "suspended_arg_checks",
    "validate_args",
]
