"""Tests for global toggles and context managers."""

from __future__ import annotations

import warnings

import pytest

from typekeeper.typekeeper import (
    set_arg_checks,
    set_stop_on_error,
    suspended_arg_checks,
    validate_args,
)
import typekeeper.typekeeper as tk


class TestGlobals:
    def test_set_arg_checks_toggles_module_flag(self):
        set_arg_checks(False)
        assert tk.RUN_CHECKS is False
        set_arg_checks(True)
        assert tk.RUN_CHECKS is True

    def test_set_stop_on_error_toggles_module_flag(self):
        set_stop_on_error(True)
        assert tk.STOP_ON_ERROR is True
        set_stop_on_error(False)
        assert tk.STOP_ON_ERROR is False

    def test_suspended_arg_checks_disables_inside_block(self):
        assert tk.RUN_CHECKS is True
        with suspended_arg_checks():
            assert tk.RUN_CHECKS is False
        assert tk.RUN_CHECKS is True

    def test_suspended_arg_checks_restores_on_exception(self):
        try:
            with suspended_arg_checks():
                assert tk.RUN_CHECKS is False
                raise RuntimeError("explode")
        except RuntimeError:
            pass
        assert tk.RUN_CHECKS is True

    def test_suspended_arg_checks_bypasses_validation(self):
        @validate_args()
        def g(x: int) -> int:
            return x

        with suspended_arg_checks():
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter("always")
                assert g("not an int") == "not an int"
            assert caught == []

    def test_disabling_checks_before_decoration_skips_wrapper(self):
        set_arg_checks(False)
        try:
            @validate_args()
            def f(x: int) -> int:
                return x

            # With checks disabled at decoration time, the function should
            # be returned without instrumentation.  No warning even on bad
            # input.
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter("always")
                assert f("x") == "x"
            assert caught == []
        finally:
            set_arg_checks(True)

    def test_disabling_checks_between_outer_and_inner_decorator(self):
        deco = validate_args(constraints="x=1-3")
        set_arg_checks(False)
        try:
            @deco
            def f(x: int) -> int:
                return x

            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter("always")
                assert f(99) == 99
            assert caught == []
        finally:
            set_arg_checks(True)

    def test_global_stop_on_error_raises_on_violation(self):
        @validate_args()
        def f(x: int) -> int:
            return x

        set_stop_on_error(True)
        try:
            with pytest.raises(ValueError):
                f("bad")
        finally:
            set_stop_on_error(False)

    def test_decorator_level_stop_on_error_overrides_global(self):
        @validate_args(stop_on_error=True)
        def f(x: int) -> int:
            return x

        set_stop_on_error(False)
        with pytest.raises(ValueError):
            f("bad")

    def test_decorator_level_stop_on_error_false_overrides_global_true(self):
        @validate_args(stop_on_error=False)
        def f(x: int) -> int:
            return x

        set_stop_on_error(True)
        try:
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter("always")
                assert f("bad") == "bad"
            assert any("mismatches" in str(c.message) for c in caught)
        finally:
            set_stop_on_error(False)
