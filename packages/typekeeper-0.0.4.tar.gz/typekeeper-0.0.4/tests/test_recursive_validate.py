"""Tests for :func:`typekeeper.typekeeper._recursive_validate`."""

from __future__ import annotations

from collections import OrderedDict, UserDict

from typekeeper.typekeeper import _recursive_validate


class _OK:
    def _validate(self) -> bool:
        return True


class _Bad:
    def _validate(self) -> bool:
        return False


class _Raises:
    def _validate(self) -> bool:
        raise RuntimeError("nope")


class _NonBool:
    """``_validate`` returning a falsy non-bool counts as failure."""

    def _validate(self):  # noqa: D401
        return 0


class TestRecursiveValidate:
    def test_object_without_validate_is_ok(self):
        assert _recursive_validate(object()) == []

    def test_passing_validator(self):
        assert _recursive_validate(_OK()) == []

    def test_failing_validator(self):
        obj = _Bad()
        failures = _recursive_validate(obj)
        assert failures == [([], obj)]

    def test_validator_that_raises_is_treated_as_failure(self):
        obj = _Raises()
        failures = _recursive_validate(obj)
        assert failures == [([], obj)]

    def test_validator_returning_falsy_non_bool_is_failure(self):
        obj = _NonBool()
        failures = _recursive_validate(obj)
        assert failures == [([], obj)]

    def test_recurses_into_dict_values_and_keys(self):
        bad_key = _Bad()
        bad_val = _Bad()
        d = {bad_key: bad_val}
        failures = _recursive_validate(d)
        assert len(failures) == 2
        assert {id(bad_key), id(bad_val)} == {id(o) for _, o in failures}

    def test_recurses_into_userdict_values(self):
        bad = _Bad()
        ud = UserDict({"a": bad})
        failures = _recursive_validate(ud)
        assert any(o is bad for _, o in failures)

    def test_ordered_dict_iteration_order_preserved_in_paths(self):
        d = OrderedDict([("a", _OK()), ("b", _Bad()), ("c", _OK())])
        failures = _recursive_validate(d)
        # The single failure is the value at key 'b'.
        assert len(failures) == 1
        path, value = failures[0]
        assert "'b'" in path[-1]

    def test_recurses_into_sequences(self):
        bad = _Bad()
        failures = _recursive_validate([_OK(), bad, _OK()])
        assert any("[1]" in p[-1] for p, _ in failures)

    def test_strings_bytes_bytearrays_are_not_iterated(self):
        # If string/bytes were iterated, we'd produce nested per-char paths.
        assert _recursive_validate("abc") == []
        assert _recursive_validate(b"abc") == []
        assert _recursive_validate(bytearray(b"abc")) == []

    def test_handles_cycles(self):
        a = {}
        a["self"] = a  # cyclic dict
        assert _recursive_validate(a) == []

    def test_handles_cycle_in_list(self):
        a = [1]
        a.append(a)
        assert _recursive_validate(a) == []

    def test_failures_include_nested_path(self):
        bad = _Bad()
        d = {"users": [{"profile": bad}]}
        failures = _recursive_validate(d)
        assert len(failures) == 1
        path, _ = failures[0]
        assert "users" in path[0] and "0" in path[1] and "profile" in path[2]
