"""Tests exercising less-common code paths (for full coverage + bug discovery)."""

from __future__ import annotations

import textwrap
import warnings
from collections import Counter, OrderedDict, deque
from typing import (
    Dict,
    ForwardRef,
    List,
    Mapping,
    Optional,
    Tuple,
    Type,
)

import pytest

from typekeeper.typekeeper import _check_type, _check_typeddict, validate_args


# ---------------------------------------------------------------------------
# Coverage: ForwardRef paths in _check_type
# ---------------------------------------------------------------------------

class TestForwardRefResolution:
    def test_resolvable_forwardref_against_builtin(self):
        ref = ForwardRef("int")
        assert _check_type(1, ref) is True
        assert _check_type("x", ref) is False

    def test_unresolvable_forwardref_is_unchecked(self):
        ref = ForwardRef("Nope_404_unique_name")
        # Falls back to True since the name cannot be resolved.
        assert _check_type("anything", ref) is True


# ---------------------------------------------------------------------------
# Coverage: unsubscripted typing generics
# ---------------------------------------------------------------------------

class TestUnsubscriptedGenerics:
    def test_typing_tuple_without_subscript_accepts_any_tuple(self):
        assert _check_type((1, 2), Tuple) is True

    def test_typing_dict_without_subscript_accepts_any_dict(self):
        assert _check_type({"a": 1}, Dict) is True

    def test_typing_mapping_without_subscript_accepts_any_mapping(self):
        assert _check_type({"a": 1}, Mapping) is True

    def test_typing_type_without_subscript_accepts_any_class(self):
        # Equivalent to ``type`` from builtins through the origin branch.
        assert _check_type(int, Type) is True
        assert _check_type(1, Type) is False


# ---------------------------------------------------------------------------
# Coverage: Type[T] non-class param fallback
# ---------------------------------------------------------------------------

class TestTypeWithUncheckableParam:
    def test_type_subscript_with_non_class_arg_does_not_raise(self):
        # When the param of Type[...] isn't a regular class, issubclass may
        # raise; the helper must return False (or True) without exploding.
        unusual = Type[List[int]]  # subscripted form
        assert _check_type(int, unusual) in (True, False)


# ---------------------------------------------------------------------------
# Coverage: custom generic class (collections.Counter / OrderedDict)
# ---------------------------------------------------------------------------

class TestCustomGenericOrigins:
    def test_counter_origin_branch(self):
        assert _check_type(Counter({"a": 1}), Counter[int]) is True
        assert _check_type({"a": 1}, Counter[int]) is False  # not a Counter

    def test_deque_origin_branch(self):
        assert _check_type(deque([1, 2]), deque) is True
        assert _check_type([1, 2], deque) is False

    def test_ordereddict_origin_branch(self):
        od = OrderedDict([("a", 1)])
        assert _check_type(od, OrderedDict) is True


# ---------------------------------------------------------------------------
# Coverage: TypedDict without __required_keys__/__optional_keys__
# ---------------------------------------------------------------------------

class _PlainShim:
    """Mimics a TypedDict-shaped object missing the required-keys metadata."""

    __annotations__ = {"id": int}

    def __init_subclass__(cls, **kwargs):
        pass


class TestTypedDictFallback:
    def test_falls_back_to_annotations_when_keys_metadata_missing(self):
        # Direct call into the helper to exercise the fallback branch.
        assert _check_typeddict({"id": 1}, _PlainShim) is True
        assert _check_typeddict({}, _PlainShim) is False
        assert _check_typeddict({"id": "x"}, _PlainShim) is False

    def test_falls_back_to_raw_annotations_when_get_type_hints_raises(self):
        # Annotations containing an unresolvable ForwardRef cause
        # ``get_type_hints`` to fail; ``_check_typeddict`` should still
        # operate using the raw annotation dict (and ForwardRef itself
        # short-circuits in ``_check_type`` to "unchecked").
        class Pathological:
            __annotations__ = {"x": ForwardRef("NameDoesNotExist__")}
            __required_keys__ = frozenset({"x"})
            __optional_keys__ = frozenset()

        assert _check_typeddict({"x": object()}, Pathological) is True
        # Missing required key still fails.
        assert _check_typeddict({}, Pathological) is False


# ---------------------------------------------------------------------------
# Coverage: deferred get_type_hints resolution at call time (591-592)
# ---------------------------------------------------------------------------

class TestDeferredHintResolution:
    def test_hints_resolve_after_decoration_when_initially_failing(self, tmp_path):
        module = tmp_path / "deferred.py"
        module.write_text(textwrap.dedent(
            """
            from __future__ import annotations
            from typekeeper import validate_args

            @validate_args()
            def f(x: LateBound) -> int:
                return 0

            class LateBound:
                pass
            """
        ))
        import importlib.util
        spec = importlib.util.spec_from_file_location("deferred_mod", module)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        inst = mod.LateBound()
        assert mod.f(inst) == 0
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            mod.f("not LateBound")
        assert any("mismatches" in str(c.message) for c in caught)


# ---------------------------------------------------------------------------
# Bug-hunt: generator arguments are not consumed during validation
# ---------------------------------------------------------------------------

class TestGeneratorArgumentSafety:
    """Validators must not consume generator-style arguments.

    Iterating a generator inside ``_recursive_validate`` or path resolution
    silently empties it before the user function sees it.  Regardless of
    whether type checking can be performed on the generator's contents,
    the original argument should reach the function intact.
    """

    def test_generator_arg_not_consumed(self):
        @validate_args()
        def f(gen) -> list:
            return list(gen)

        def make_gen():
            yield 1
            yield 2
            yield 3

        assert f(make_gen()) == [1, 2, 3]

    def test_generator_with_constraint_not_consumed(self):
        @validate_args()
        def f(gen) -> list:
            return list(gen)

        gen = (i for i in range(3))
        assert f(gen) == [0, 1, 2]


# ---------------------------------------------------------------------------
# Bug-hunt: object with raising __len__ in length spec
# ---------------------------------------------------------------------------

class TestRaisingLen:
    def test_value_with_raising_len_does_not_crash(self):
        class Weird:
            def __len__(self):
                raise RuntimeError("nope")

        @validate_args(constraints="x=1-3")
        def f(x) -> int:
            return 0

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            f(Weird())
        assert any("Cannot determine length" in str(c.message) for c in caught)


# ---------------------------------------------------------------------------
# Bug-hunt: bool vs int handling in numeric spec
# ---------------------------------------------------------------------------

class TestBoolAsInt:
    def test_bool_is_accepted_where_int_required(self):
        @validate_args(constraints="x=0-1")
        def f(x: int) -> int:
            return int(x)

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            f(True)
            f(False)
        assert caught == []


# ---------------------------------------------------------------------------
# Bug-hunt: spec applying to a string parameter checks length, not value
# ---------------------------------------------------------------------------

class TestStringLengthSpec:
    def test_string_arg_uses_length_for_spec(self):
        @validate_args(constraints="name=2-5")
        def f(name: str) -> str:
            return name

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            f("ok")
        assert caught == []

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            f("x")
        assert any("Length of 'name'" in str(c.message) for c in caught)


# ---------------------------------------------------------------------------
# Bug-hunt: optional default annotation conflict scenarios
# ---------------------------------------------------------------------------

class TestOptionalDefaults:
    def test_optional_default_none_is_quiet(self):
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")

            @validate_args()
            def f(x: Optional[int] = None) -> Optional[int]:
                return x

        assert not any("does not match annotation" in str(c.message) for c in caught)

    def test_optional_str_default_warns_type_mismatch(self):
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")

            @validate_args()
            def f(x: Optional[int] = "wrong") -> Optional[int]:  # type: ignore[assignment]
                return x

        assert any("does not match annotation" in str(c.message) for c in caught)


# ---------------------------------------------------------------------------
# Bug-hunt: passing a class as a value to a class annotation
# ---------------------------------------------------------------------------

class TestClassValueVsClassAnnotation:
    def test_class_object_does_not_match_instance_annotation(self):
        @validate_args()
        def f(x: int) -> int:
            return 0

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            f(int)
        assert any("mismatches" in str(c.message) for c in caught)


# ---------------------------------------------------------------------------
# Bug-hunt: paths into nested ``UserDict`` and ``UserList``
# ---------------------------------------------------------------------------

class TestCustomContainers:
    def test_userdict_path_index(self):
        from collections import UserDict, UserList

        @validate_args(constraints="d:key=0-9")
        def f(d) -> int:
            return 0

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            f(UserDict({"key": 5}))
        assert caught == []

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            f(UserDict({"key": 99}))
        assert any("d:key" in str(c.message) for c in caught)

    def test_userlist_index_segment(self):
        from collections import UserList

        @validate_args(constraints="lst:0=0-9")
        def f(lst) -> int:
            return 0

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            f(UserList([5]))
        assert caught == []

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            f(UserList([99]))
        assert any("lst:0" in str(c.message) for c in caught)


# ---------------------------------------------------------------------------
# Bug-hunt: nested validation paths preserve order
# ---------------------------------------------------------------------------

class TestIterableShallowCheck:
    def test_iterable_with_iterator_value_is_accepted_without_consuming(self):
        from typing import Iterable as TypingIterable

        gen = (i for i in range(3))
        # Shallow check: must say True and not consume the generator.
        assert _check_type(gen, TypingIterable[int]) is True
        assert list(gen) == [0, 1, 2]


class TestProtocolInstanceCheckFallback:
    def test_non_runtime_protocol_uses_structural_check(self):
        from typing import Protocol

        class P(Protocol):
            def close(self) -> None: ...

        class Implementor:
            def close(self) -> None:
                pass

        # Structural check honours the Protocol's declared members even
        # without ``@runtime_checkable``.
        assert _check_type(Implementor(), P) is True
        assert _check_type(123, P) is False


class TestMultipleSpecsSameParam:
    def test_two_independent_ranges_for_same_param(self):
        @validate_args(constraints="x=1,3-5")
        def f(x: int) -> int:
            return x

        # 1 is OK, 4 is OK, 2 is bad.
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            f(1)
            f(4)
        assert caught == []

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            f(2)
        assert any("not in ranges" in str(c.message) for c in caught)
