"""Exhaustive tests for :func:`typekeeper.typekeeper._check_type`."""

from __future__ import annotations

import collections.abc as abc
from dataclasses import dataclass
from typing import (
    Annotated,
    Any,
    Callable,
    Dict,
    Final,
    FrozenSet,
    Iterable,
    List,
    Mapping,
    MutableMapping,
    MutableSequence,
    NewType,
    Optional,
    Sequence,
    Set,
    Tuple,
    Type,
    TypedDict,
    TypeVar,
    Union,
)

import pytest

from typekeeper.typekeeper import _check_type

try:
    from typing import Literal
except ImportError:  # pragma: no cover
    from typing_extensions import Literal  # type: ignore

try:
    from typing import Self
    HAS_SELF = True
except ImportError:  # pragma: no cover
    HAS_SELF = False


# ---------------------------------------------------------------------------
# Base cases
# ---------------------------------------------------------------------------

class TestBaseCases:
    def test_any_accepts_anything(self):
        for value in [None, 0, "x", [1], object()]:
            assert _check_type(value, Any) is True

    @pytest.mark.skipif(not HAS_SELF, reason="typing.Self not available")
    def test_self_is_accepted(self):
        from typing import Self as _Self
        assert _check_type(object(), _Self) is True

    def test_concrete_classes(self):
        assert _check_type(1, int) is True
        assert _check_type("x", int) is False
        assert _check_type(None, type(None)) is True
        assert _check_type(1, type(None)) is False

    def test_string_annotation_is_accepted_when_unresolved(self):
        # Stringified forward refs are skipped at runtime.
        assert _check_type(123, "MysteryThing") is True
        assert _check_type("anything", "'AnotherMystery'") is True


# ---------------------------------------------------------------------------
# Unions, Optional, PEP 604 union, nested
# ---------------------------------------------------------------------------

class TestUnions:
    def test_typing_union(self):
        ann = Union[int, str]
        assert _check_type(1, ann) is True
        assert _check_type("x", ann) is True
        assert _check_type(1.5, ann) is False

    def test_optional(self):
        ann = Optional[int]
        assert _check_type(None, ann) is True
        assert _check_type(0, ann) is True
        assert _check_type("x", ann) is False

    def test_pep604_union(self):
        assert _check_type(1, int | str) is True
        assert _check_type(1.5, int | str) is False

    def test_nested_union_in_list(self):
        ann = List[Union[int, str]]
        assert _check_type([1, "a"], ann) is True
        assert _check_type([1, 1.5], ann) is False


# ---------------------------------------------------------------------------
# Annotated, Final, NewType, Literal
# ---------------------------------------------------------------------------

class TestAliasForms:
    def test_annotated_uses_first_arg(self):
        ann = Annotated[int, "meta"]
        assert _check_type(1, ann) is True
        assert _check_type("x", ann) is False

    def test_annotated_nested_in_list(self):
        ann = List[Annotated[int, "meta"]]
        assert _check_type([1, 2], ann) is True
        assert _check_type([1, "x"], ann) is False

    def test_final_uses_underlying_type(self):
        assert _check_type(1, Final[int]) is True
        assert _check_type("x", Final[int]) is False
        # Bare Final without args is accepted.
        assert _check_type(1, Final) is True

    def test_newtype_simple_unwrap(self):
        UserId = NewType("UserId", int)
        assert _check_type(1, UserId) is True
        assert _check_type("x", UserId) is False

    def test_newtype_chained(self):
        Inner = NewType("Inner", int)
        Outer = NewType("Outer", Inner)
        assert _check_type(1, Outer) is True
        assert _check_type("x", Outer) is False

    def test_literal_values(self):
        ann = Literal[1, "two", True]
        assert _check_type(1, ann) is True
        assert _check_type("two", ann) is True
        assert _check_type(True, ann) is True
        assert _check_type("nope", ann) is False
        assert _check_type(2, ann) is False


# ---------------------------------------------------------------------------
# Builtin generics
# ---------------------------------------------------------------------------

class TestListTupleDictSet:
    def test_list_with_and_without_args(self):
        assert _check_type([1, 2], list[int]) is True
        assert _check_type([1, "x"], list[int]) is False
        assert _check_type([], list[int]) is True
        # Bare ``list`` annotation accepts any list contents.
        assert _check_type([1, "x"], list) is True
        # Mismatched container type returns False.
        assert _check_type((1, 2), list[int]) is False

    def test_tuple_variants(self):
        assert _check_type((1, 2), tuple[int, ...]) is True
        assert _check_type((), tuple[int, ...]) is True
        assert _check_type((1, "x"), tuple[int, ...]) is False
        assert _check_type((1, "x"), tuple[int, str]) is True
        assert _check_type((1, 2), tuple[int, str]) is False
        # Length mismatch returns False.
        assert _check_type((1, 2, 3), tuple[int, str]) is False
        # Bare ``tuple`` accepts any tuple.
        assert _check_type((1, "x"), tuple) is True

    def test_dict_variants(self):
        assert _check_type({"a": 1}, dict[str, int]) is True
        assert _check_type({"a": "x"}, dict[str, int]) is False
        assert _check_type({1: 2}, dict[str, int]) is False
        assert _check_type({1: 2}, dict) is True

    def test_set_and_frozenset(self):
        assert _check_type({1, 2}, set[int]) is True
        assert _check_type({"x"}, set[int]) is False
        assert _check_type(frozenset({1, 2}), FrozenSet[int]) is True
        assert _check_type(frozenset({"x"}), FrozenSet[int]) is False
        assert _check_type({1, 2}, set) is True


# ---------------------------------------------------------------------------
# typing generics (List, Dict, Tuple, Set)
# ---------------------------------------------------------------------------

class TestTypingGenerics:
    def test_typing_list_equivalent_to_builtin(self):
        assert _check_type([1], List[int]) is True
        assert _check_type([1], List) is True

    def test_typing_dict(self):
        assert _check_type({"a": 1}, Dict[str, int]) is True

    def test_typing_tuple(self):
        assert _check_type((1,), Tuple[int]) is True
        assert _check_type((1, 2), Tuple[int, int]) is True

    def test_typing_set(self):
        assert _check_type({1, 2}, Set[int]) is True


# ---------------------------------------------------------------------------
# ABC origins
# ---------------------------------------------------------------------------

class TestAbcOrigins:
    def test_sequence_accepts_list_and_tuple(self):
        assert _check_type([1], Sequence[int]) is True
        assert _check_type((1,), Sequence[int]) is True
        assert _check_type({1}, Sequence[int]) is False  # sets aren't sequences

    def test_mutable_sequence(self):
        assert _check_type([1], MutableSequence[int]) is True
        # Tuples are Sequence but not MutableSequence; the current code only
        # checks ``isinstance(value, Sequence)`` for both, so a tuple passes.
        # We assert the documented behavior with a tuple-of-correct-items.
        assert _check_type([1, "x"], MutableSequence[int]) is False

    def test_mapping(self):
        assert _check_type({"a": 1}, Mapping[str, int]) is True
        assert _check_type({1: 1}, Mapping[str, int]) is False
        assert _check_type([("a", 1)], Mapping[str, int]) is False

    def test_mutable_mapping(self):
        assert _check_type({"a": 1}, MutableMapping[str, int]) is True

    def test_iterable_accepts_iterables(self):
        assert _check_type([1, 2], Iterable[int]) is True
        assert _check_type((1, 2), Iterable[int]) is True
        # Non-iterables should fail the iter() try.
        assert _check_type(123, Iterable[int]) is False

    def test_bare_sequence_abc_without_subscript(self):
        # Falls through to inspect.isclass branch.
        assert _check_type([1], abc.Sequence) is True


# ---------------------------------------------------------------------------
# Callable and Type[T]
# ---------------------------------------------------------------------------

class TestCallableAndType:
    def test_callable_accepts_callables(self):
        assert _check_type(len, Callable[..., int]) is True
        assert _check_type(lambda x: x, Callable[[int], int]) is True
        assert _check_type(123, Callable) is False

    def test_callable_abc(self):
        assert _check_type(len, abc.Callable) is True
        assert _check_type(123, abc.Callable) is False

    def test_type_form_accepts_class_objects_only(self):
        assert _check_type(int, Type[int]) is True
        assert _check_type(bool, Type[int]) is True  # bool is subclass of int
        assert _check_type(str, Type[int]) is False
        assert _check_type(1, Type[int]) is False

    def test_type_builtin_without_args_accepts_any_class(self):
        assert _check_type(int, type) is True
        assert _check_type(1, type) is False

    def test_type_with_non_class_param_does_not_crash(self):
        # ``Type[int | str]`` -> issubclass(int, int|str) is OK on 3.10+.
        # The fallback path returning False is also acceptable behavior.
        result = _check_type(int, Type[Union[int, str]])
        assert result in (True, False)


# ---------------------------------------------------------------------------
# TypeVar handling
# ---------------------------------------------------------------------------

class TestTypeVar:
    def test_unconstrained_typevar_accepts_anything(self):
        T = TypeVar("T")
        assert _check_type(1, T) is True
        assert _check_type("x", T) is True

    def test_bound_typevar(self):
        class Base:
            pass

        class Sub(Base):
            pass

        TBound = TypeVar("TBound", bound=Base)
        assert _check_type(Sub(), TBound) is True
        assert _check_type(Base(), TBound) is True
        assert _check_type("x", TBound) is False

    def test_constrained_typevar(self):
        TNum = TypeVar("TNum", int, float)
        assert _check_type(1, TNum) is True
        assert _check_type(1.5, TNum) is True
        assert _check_type("x", TNum) is False


# ---------------------------------------------------------------------------
# TypedDict
# ---------------------------------------------------------------------------

class _UserTD(TypedDict):
    id: int
    name: str


class _PartialTD(TypedDict, total=False):
    id: int
    name: str


class _NestedTD(TypedDict):
    user: _UserTD


class _EmptyTD(TypedDict):
    pass


class TestTypedDict:
    def test_total_typeddict_required_keys(self):
        assert _check_type({"id": 1, "name": "a"}, _UserTD) is True
        assert _check_type({"id": 1}, _UserTD) is False  # missing name
        assert _check_type({"id": "x", "name": "a"}, _UserTD) is False

    def test_typeddict_extra_keys_allowed(self):
        # Structural check ignores extra keys.
        assert _check_type({"id": 1, "name": "a", "x": 1}, _UserTD) is True

    def test_partial_typeddict_optional_keys(self):
        assert _check_type({}, _PartialTD) is True
        assert _check_type({"id": 1}, _PartialTD) is True
        assert _check_type({"id": "x"}, _PartialTD) is False

    def test_nested_typeddict(self):
        assert _check_type({"user": {"id": 1, "name": "a"}}, _NestedTD) is True
        assert _check_type({"user": {"id": 1}}, _NestedTD) is False

    def test_typeddict_value_must_be_mapping(self):
        assert _check_type(["id", 1], _UserTD) is False

    def test_empty_typeddict_accepts_any_dict(self):
        assert _check_type({}, _EmptyTD) is True
        assert _check_type({"extra": 1}, _EmptyTD) is True


# ---------------------------------------------------------------------------
# Dataclasses and arbitrary classes
# ---------------------------------------------------------------------------

@dataclass
class _Point:
    x: int
    y: int


class TestArbitraryClasses:
    def test_dataclass_uses_isinstance(self):
        assert _check_type(_Point(1, 2), _Point) is True
        assert _check_type({"x": 1, "y": 2}, _Point) is False

    def test_subclass_passes(self):
        class A:
            pass

        class B(A):
            pass

        assert _check_type(B(), A) is True


# ---------------------------------------------------------------------------
# Odd / non-checkable annotations
# ---------------------------------------------------------------------------

class TestOddAnnotations:
    def test_non_type_annotation_does_not_raise(self):
        # An instance used as an annotation cannot be passed to isinstance.
        sentinel = object()
        assert _check_type(123, sentinel) is True
        assert _check_type("x", sentinel) is True
