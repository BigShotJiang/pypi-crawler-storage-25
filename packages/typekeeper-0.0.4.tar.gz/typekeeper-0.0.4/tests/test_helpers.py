"""Direct tests for helper functions in :mod:`typekeeper.typekeeper`."""

from __future__ import annotations

import warnings
from collections import OrderedDict, UserDict, UserList
from types import MappingProxyType

import pytest

from typekeeper.typekeeper import (
    _emit_warning,
    _get_source_lines,
    _is_safe_iterable,
    _iter_path_values,
    _parse_specs,
    _Segment,
    _split_path,
    is_immutable,
    set_stop_on_error,
)


def _values(parts):
    """Return just the ``.value`` of each parsed ``_Segment``."""

    return [p.value for p in parts]


# ---------------------------------------------------------------------------
# _emit_warning
# ---------------------------------------------------------------------------

class TestEmitWarning:
    def test_emits_userwarning_with_explicit_filename_and_lineno(self):
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            _emit_warning("hello", "/tmp/path.py", 17)
        assert len(caught) == 1
        assert caught[0].category is UserWarning
        assert str(caught[0].message) == "hello"
        assert caught[0].filename == "/tmp/path.py"
        assert caught[0].lineno == 17

    def test_stop_on_error_per_call_raises(self):
        with pytest.raises(ValueError, match="boom"):
            _emit_warning("boom", "f.py", 1, stop_on_error=True)

    def test_global_stop_on_error_raises(self):
        set_stop_on_error(True)
        try:
            with pytest.raises(ValueError):
                _emit_warning("global", "f.py", 1)
        finally:
            set_stop_on_error(False)

    def test_per_call_false_overrides_global_true(self):
        set_stop_on_error(True)
        try:
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter("always")
                _emit_warning("ok", "f.py", 1, stop_on_error=False)
            assert len(caught) == 1
        finally:
            set_stop_on_error(False)


# ---------------------------------------------------------------------------
# _get_source_lines
# ---------------------------------------------------------------------------

class TestGetSourceLines:
    def test_returns_lines_for_regular_function(self):
        def sample():
            return 1

        lines, start = _get_source_lines(sample)
        assert any("def sample" in line for line in lines)
        assert isinstance(start, int)

    def test_handles_builtin_without_source(self):
        # `len` has no Python source; the helper should swallow the error.
        lines, start = _get_source_lines(len)
        assert lines == ["\n"]
        assert start == 0

    def test_handles_lambda(self):
        fn = lambda x: x  # noqa: E731
        lines, start = _get_source_lines(fn)
        assert isinstance(lines, list)
        assert isinstance(start, int)


# ---------------------------------------------------------------------------
# _parse_specs
# ---------------------------------------------------------------------------

class TestParseSpecs:
    def test_none_and_empty_inputs(self):
        assert _parse_specs(None) == []
        assert _parse_specs("") == []

    def test_single_value_and_range_tokens(self):
        specs = _parse_specs("x=3; y=1-5")
        assert specs == [("x", [(3.0, 3.0)]), ("y", [(1.0, 5.0)])]

    def test_multiple_tokens_for_same_parameter(self):
        specs = _parse_specs("x=1,3-5,7")
        assert specs == [("x", [(1.0, 1.0), (3.0, 5.0), (7.0, 7.0)])]

    def test_floats_and_negatives(self):
        specs = _parse_specs("a=-2.5-0; b=-3")
        assert specs == [("a", [(-2.5, 0.0)]), ("b", [(-3.0, -3.0)])]

    def test_warns_and_skips_missing_equals(self):
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            assert _parse_specs("bogus; x=1") == [("x", [(1.0, 1.0)])]
        assert any("Invalid spec format" in str(c.message) for c in caught)

    def test_warns_on_inverted_range(self):
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            assert _parse_specs("x=5-1") == []
        assert any("Invalid range" in str(c.message) for c in caught)

    def test_warns_on_garbage_token(self):
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            assert _parse_specs("x=abc") == []
        assert any("Invalid spec token" in str(c.message) for c in caught)

    def test_empty_token_between_commas_is_skipped_silently(self):
        # "x=1,," should produce a single value range (1,1), commas with empty
        # text between them are ignored.
        assert _parse_specs("x=1,,") == [("x", [(1.0, 1.0)])]

    def test_stop_on_error_keyword_raises_on_first_problem(self):
        with pytest.raises(ValueError):
            _parse_specs("bad", stop_on_error=True)

    def test_whitespace_is_tolerated(self):
        assert _parse_specs("  x = 1 - 3 ;  ") == [("x", [(1.0, 3.0)])]

    def test_drops_parameter_with_no_valid_ranges(self):
        with warnings.catch_warnings(record=True):
            warnings.simplefilter("always")
            assert _parse_specs("x=junk; y=2") == [("y", [(2.0, 2.0)])]


# ---------------------------------------------------------------------------
# _split_path
# ---------------------------------------------------------------------------

class TestSplitPath:
    def test_basic_split(self):
        assert _values(_split_path("a:b:c")) == ["a", "b", "c"]
        assert all(not p.literal for p in _split_path("a:b:c"))

    def test_single_segment(self):
        parts = _split_path("only")
        assert parts == [_Segment("only", False)]

    def test_empty_segments_preserved(self):
        assert _values(_split_path("a::b")) == ["a", "", "b"]
        assert _values(_split_path("a:")) == ["a", ""]
        assert _values(_split_path(":")) == ["", ""]
        # All non-literal — they remain wildcard-eligible.
        assert all(not p.literal for p in _split_path("a:"))

    def test_escaped_colon(self):
        parts = _split_path("a\\:b")
        assert parts == [_Segment("a:b", True)]

    def test_escaped_backslash(self):
        parts = _split_path("a\\\\b:c")
        assert parts == [_Segment("a\\b", True), _Segment("c", False)]

    def test_trailing_lone_backslash_is_swallowed(self):
        # Trailing escape with no follow-up character is treated as no-op.
        assert _split_path("a\\") == [_Segment("a", False)]

    def test_empty_literal_escape(self):
        # New: ``\!`` produces a literal empty segment that does NOT act
        # as a wildcard during traversal.
        assert _split_path("a:\\!") == [
            _Segment("a", False),
            _Segment("", True),
        ]

    def test_star_escape_is_literal(self):
        # ``\*`` yields a literal ``*`` segment (no wildcard expansion).
        parts = _split_path("a:\\*")
        assert parts == [_Segment("a", False), _Segment("*", True)]


# ---------------------------------------------------------------------------
# _iter_path_values
# ---------------------------------------------------------------------------

class TestIterPathValues:
    def test_empty_path_returns_object(self):
        assert list(_iter_path_values(42, [])) == [([], 42)]

    def test_dict_key_lookup(self):
        data = {"x": {"y": 5}}
        assert list(_iter_path_values(data, ["x", "y"])) == [(["x", "y"], 5)]

    def test_missing_dict_key_yields_nothing(self):
        assert list(_iter_path_values({"a": 1}, ["b"])) == []

    def test_wildcard_over_dict(self):
        result = list(_iter_path_values({"a": 1, "b": 2}, ["*"]))
        assert sorted(result) == sorted([(["a"], 1), (["b"], 2)])

    def test_wildcard_over_list(self):
        result = list(_iter_path_values([10, 20], ["*"]))
        assert result == [(["0"], 10), (["1"], 20)]

    def test_empty_segment_acts_as_wildcard(self):
        result = list(_iter_path_values([1, 2], [""]))
        assert result == [(["0"], 1), (["1"], 2)]

    def test_integer_segment_on_sequence(self):
        assert list(_iter_path_values([5, 6, 7], ["1"])) == [(["1"], 6)]

    def test_negative_integer_segment_on_sequence(self):
        assert list(_iter_path_values([5, 6, 7], ["-1"])) == [(["-1"], 7)]

    def test_integer_segment_out_of_range_yields_nothing(self):
        assert list(_iter_path_values([5], ["3"])) == []
        assert list(_iter_path_values([5], ["-9"])) == []

    def test_fallthrough_iterates_when_segment_is_not_index_or_key(self):
        # When the segment isn't numeric and the container is a sequence with
        # mapping elements, the traversal "looks deeper" by iterating items.
        data = [{"k": 1}, {"k": 2}]
        result = list(_iter_path_values(data, ["k"]))
        assert result == [(["0", "k"], 1), (["1", "k"], 2)]

    def test_wildcard_on_non_iterable_returns_nothing(self):
        assert list(_iter_path_values(42, ["*"])) == []

    def test_strings_are_not_iterated(self):
        assert list(_iter_path_values("abc", ["*"])) == []
        assert list(_iter_path_values(b"abc", ["*"])) == []
        assert list(_iter_path_values(bytearray(b"abc"), ["*"])) == []

    def test_userdict_subclass_traverses_correctly(self):
        ud = UserDict({"a": 1, "b": 2})
        result = list(_iter_path_values(ud, ["a"]))
        assert result == [(["a"], 1)]

    def test_mappingproxy_traverses_correctly(self):
        proxy = MappingProxyType({"k": 9})
        assert list(_iter_path_values(proxy, ["k"])) == [(["k"], 9)]

    def test_userlist_supports_index_segments(self):
        ul = UserList([10, 20, 30])
        assert list(_iter_path_values(ul, ["1"])) == [(["1"], 20)]

    def test_ordered_dict_preserves_iteration_order(self):
        od = OrderedDict([("a", 1), ("b", 2), ("c", 3)])
        keys = [path[0] for path, _ in _iter_path_values(od, ["*"])]
        assert keys == ["a", "b", "c"]


# ---------------------------------------------------------------------------
# is_immutable
# ---------------------------------------------------------------------------

class TestIsImmutable:
    @pytest.mark.parametrize(
        "value",
        [None, True, False, 0, 1, -1, 3.14, 1 + 2j, "x", b"x", range(3), ()],
    )
    def test_primitives_are_immutable(self, value):
        assert is_immutable(value) is True

    def test_tuple_of_immutables(self):
        assert is_immutable((1, "a", (2, 3))) is True

    def test_tuple_with_nested_mutable_is_mutable(self):
        assert is_immutable((1, [2])) is False

    def test_frozenset_of_immutables(self):
        assert is_immutable(frozenset({1, 2, 3})) is True

    def test_mutable_containers(self):
        assert is_immutable([1]) is False
        assert is_immutable({1: 2}) is False
        assert is_immutable({1, 2}) is False

    def test_arbitrary_object_is_not_immutable(self):
        class C:
            pass

        assert is_immutable(C()) is False


# ---------------------------------------------------------------------------
# _is_safe_iterable
# ---------------------------------------------------------------------------

class TestIsSafeIterable:
    def test_str_bytes_bytearray_excluded(self):
        assert _is_safe_iterable("abc") is False
        assert _is_safe_iterable(b"abc") is False
        assert _is_safe_iterable(bytearray(b"abc")) is False

    def test_mapping_excluded(self):
        assert _is_safe_iterable({"a": 1}) is False

    def test_generator_and_iterator_excluded(self):
        def gen():
            yield 1

        assert _is_safe_iterable(gen()) is False
        assert _is_safe_iterable(iter([1, 2])) is False

    def test_lists_sets_tuples_included(self):
        assert _is_safe_iterable([1, 2]) is True
        assert _is_safe_iterable((1, 2)) is True
        assert _is_safe_iterable({1, 2}) is True
        assert _is_safe_iterable(frozenset({1, 2})) is True

    def test_non_iterable_excluded(self):
        assert _is_safe_iterable(1) is False
        assert _is_safe_iterable(object()) is False
