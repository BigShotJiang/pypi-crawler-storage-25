"""Shared pytest fixtures for the typekeeper test suite."""

from __future__ import annotations

import warnings

import pytest

from typekeeper.typekeeper import set_arg_checks, set_stop_on_error


@pytest.fixture(autouse=True)
def _reset_global_state():
    """Ensure each test starts with a known global state."""

    set_arg_checks(True)
    set_stop_on_error(False)
    yield
    set_arg_checks(True)
    set_stop_on_error(False)


@pytest.fixture
def collect_warnings():
    """Yield a callable that records UserWarnings emitted in a code block."""

    def _runner(callable_, *args, **kwargs):
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            result = callable_(*args, **kwargs)
        return result, list(caught)

    return _runner
