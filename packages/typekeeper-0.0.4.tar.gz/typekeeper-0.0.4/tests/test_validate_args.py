"""End-to-end tests for the :func:`validate_args` decorator."""

from __future__ import annotations

import warnings
from typing import Optional

import pytest

from typekeeper.typekeeper import validate_args


def _emit_warnings(callable_, *args, **kwargs):
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        result = callable_(*args, **kwargs)
    return result, [str(c.message) for c in caught]


# ---------------------------------------------------------------------------
# Decoration forms
# ---------------------------------------------------------------------------

class TestDecoratorForms:
    def test_bare_decorator_without_parens(self):
        @validate_args
        def f(x: int) -> int:
            return x

        assert f(1) == 1
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            f("bad")
        assert any("mismatches" in str(c.message) for c in caught)

    def test_decorator_with_empty_parens(self):
        @validate_args()
        def f(x: int) -> int:
            return x

        assert f(1) == 1

    def test_decorator_with_constraints_kwarg(self):
        @validate_args(constraints="x=1-3")
        def f(x: int) -> int:
            return x

        assert f(2) == 2
        _, msgs = _emit_warnings(f, 99)
        assert any("not in ranges" in m for m in msgs)

    def test_unknown_kwarg_rejected(self):
        # ``lengths=`` used to be a legacy alias; it has been removed in
        # 0.0.4 — callers must use ``constraints=`` exclusively.
        with pytest.raises(TypeError):
            validate_args(lengths="x=1-3")  # type: ignore[call-arg]


# ---------------------------------------------------------------------------
# Decoration-time checks
# ---------------------------------------------------------------------------

class TestDecorationTimeChecks:
    def test_mutable_list_default_warns(self):
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")

            @validate_args()
            def f(items: list = []):  # noqa: B006
                return items

        assert any("Mutable default" in str(c.message) for c in caught)

    def test_mutable_dict_default_warns(self):
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")

            @validate_args()
            def f(d: dict = {}):  # noqa: B006
                return d

        assert any("Mutable default" in str(c.message) for c in caught)

    def test_ignore_defaults_suppresses_mutable_warning(self):
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")

            @validate_args(ignore_defaults=True)
            def f(items: list = []):  # noqa: B006
                return items

        assert not any("Mutable default" in str(c.message) for c in caught)

    def test_immutable_default_emits_no_warning(self):
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")

            @validate_args()
            def f(x: int = 1):
                return x

        assert not any("Mutable default" in str(c.message) for c in caught)

    def test_default_type_mismatch_warns(self):
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")

            @validate_args()
            def f(x: int = "wrong"):  # type: ignore[assignment]
                return x

        assert any("does not match annotation" in str(c.message) for c in caught)

    def test_optional_default_none_does_not_warn(self):
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")

            @validate_args()
            def f(x: Optional[int] = None):
                return x

        assert not any("does not match annotation" in str(c.message) for c in caught)


# ---------------------------------------------------------------------------
# Call-time type checks
# ---------------------------------------------------------------------------

class TestCallTimeTypeChecks:
    def test_correct_call_emits_no_warning(self):
        @validate_args()
        def f(x: int, y: str) -> str:
            return y * x

        _, msgs = _emit_warnings(f, 2, "ab")
        assert msgs == []

    def test_wrong_arg_type_warns(self):
        @validate_args()
        def f(x: int) -> int:
            return x

        _, msgs = _emit_warnings(f, "no")
        assert any("mismatches" in m for m in msgs)

    def test_nested_generic_arg(self):
        @validate_args()
        def f(rows: list[dict[str, int]]) -> int:
            return len(rows)

        assert f([{"a": 1}, {"b": 2}]) == 2
        _, msgs = _emit_warnings(f, [{"a": "x"}])
        assert any("mismatches" in m for m in msgs)

    def test_varargs_validation(self):
        @validate_args()
        def f(*args: int) -> int:
            return len(args)

        assert f(1, 2, 3) == 3
        _, msgs = _emit_warnings(f, 1, "x")
        assert any("mismatches" in m for m in msgs)

    def test_varkw_validation(self):
        @validate_args()
        def f(**kw: int) -> int:
            return len(kw)

        assert f(a=1, b=2) == 2
        _, msgs = _emit_warnings(f, a=1, b="x")
        assert any("mismatches" in m for m in msgs)


# ---------------------------------------------------------------------------
# Spec validation
# ---------------------------------------------------------------------------

class TestSpecValidation:
    def test_numeric_range_passes(self):
        @validate_args(constraints="x=1-3")
        def f(x: int) -> int:
            return x

        _, msgs = _emit_warnings(f, 2)
        assert msgs == []

    def test_numeric_range_fails(self):
        @validate_args(constraints="x=1-3")
        def f(x: int) -> int:
            return x

        _, msgs = _emit_warnings(f, 99)
        assert any("not in ranges" in m for m in msgs)

    def test_length_range_passes(self):
        @validate_args(constraints="data=2-4")
        def f(data: list[int]) -> int:
            return len(data)

        _, msgs = _emit_warnings(f, [1, 2, 3])
        assert msgs == []

    def test_length_range_fails(self):
        @validate_args(constraints="data=2-4")
        def f(data: list[int]) -> int:
            return len(data)

        _, msgs = _emit_warnings(f, [1])
        assert any("Length of" in m for m in msgs)

    def test_object_without_len_emits_warning(self):
        class _NoLen:
            pass

        @validate_args(constraints="x=2-4")
        def f(x) -> int:
            return 0

        _, msgs = _emit_warnings(f, _NoLen())
        assert any("Cannot determine length" in m for m in msgs)

    def test_path_into_list_index_segment(self):
        @validate_args(constraints="rows:0:score=0-100")
        def f(rows: list[dict]) -> int:
            return rows[0]["score"]

        _, msgs = _emit_warnings(f, [{"score": 50}])
        assert msgs == []
        _, msgs = _emit_warnings(f, [{"score": 101}])
        assert any("rows:0:score" in m for m in msgs)

    def test_path_with_wildcard_each_item(self):
        @validate_args(constraints="data:*=1-5")
        def f(data: list[int]) -> int:
            return sum(data)

        _, msgs = _emit_warnings(f, [1, 2, 3])
        assert msgs == []
        _, msgs = _emit_warnings(f, [1, 99, 3])
        assert any("data:*" in m for m in msgs)

    def test_path_unknown_param_is_skipped(self):
        @validate_args(constraints="ghost=1-3")
        def f(x: int) -> int:
            return x

        _, msgs = _emit_warnings(f, 1)
        assert msgs == []

    def test_path_no_matching_items_is_silent(self):
        @validate_args(constraints="d:missing=1-3")
        def f(d: dict) -> dict:
            return d

        _, msgs = _emit_warnings(f, {"present": 1})
        assert msgs == []

    def test_later_specs_override_earlier(self):
        @validate_args(constraints="rows::v=0-1; rows:0:v=99")
        def f(rows: list[dict]) -> int:
            return 0

        # rows[0].v is 50: the second (later) spec demands exactly 99 for
        # the (0, v) cell, so it should warn even though the first spec
        # bounded all to 0-1 (which would also warn).  The later one wins;
        # only one warning per cell is emitted.
        _, msgs = _emit_warnings(f, [{"v": 50}])
        assert sum(1 for m in msgs if "rows" in m) == 1


# ---------------------------------------------------------------------------
# _validate recursion
# ---------------------------------------------------------------------------

class TestRecursiveValidateIntegration:
    def test_failure_path_appears_in_warning(self):
        class Thing:
            def __init__(self, ok: bool) -> None:
                self.ok = ok

            def _validate(self) -> bool:
                return self.ok

        @validate_args()
        def f(things: list) -> int:
            return len(things)

        _, msgs = _emit_warnings(f, [Thing(True), Thing(False), Thing(True)])
        assert any("Recursed value" in m and "[1]" in m for m in msgs)


# ---------------------------------------------------------------------------
# Forward references / deferred resolution
# ---------------------------------------------------------------------------

class TestForwardReferences:
    def test_forward_reference_resolved_at_call_time(self):
        ns: dict = {}
        src = (
            "from __future__ import annotations\n"
            "from typekeeper import validate_args\n"
            "\n"
            "@validate_args()\n"
            "def f(x: int | float):\n"
            "    return x\n"
        )
        exec(src, ns)
        assert ns["f"](1) == 1
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            ns["f"]("bad")
        assert any("mismatches" in str(c.message) for c in caught)


# ---------------------------------------------------------------------------
# Functions with annotations producing TypeErrors during get_type_hints
# ---------------------------------------------------------------------------

class TestProblematicHints:
    def test_unresolvable_annotation_does_not_break_decoration(self):
        ns: dict = {}
        src = (
            "from __future__ import annotations\n"
            "from typekeeper import validate_args\n"
            "\n"
            "@validate_args()\n"
            "def f(x: 'Mystery'):\n"
            "    return x\n"
        )
        exec(src, ns)
        # Since 'Mystery' never resolves, the runtime should not crash and
        # should not falsely reject any value.
        ns["f"](1)
        ns["f"]("x")


# ---------------------------------------------------------------------------
# Builtins / unsourced callables
# ---------------------------------------------------------------------------

class TestUnsourcedCallables:
    def test_decorating_function_without_python_source_does_not_crash(self):
        # ``inspect.getsourcelines`` raises for builtins; the decorator should
        # still produce a working wrapper.
        @validate_args()
        def wrapper(x: int) -> int:
            return x

        # Force lru_cache miss for source lookup by decorating a builtin.
        # ``len`` itself can't accept the same call shape but we only care
        # that decoration completes.
        wrapped_len = validate_args()(len)
        assert wrapped_len([1, 2, 3]) == 3
