"""Regression tests for the bug list raised against typekeeper 0.0.4.

Each ``TestBugN`` group documents the original issue, the resolution, and
locks in the post-fix behavior.  Items that were *not* bugs (working as
designed) get lock-in tests so future refactors can't regress them.
"""

from __future__ import annotations

import warnings
from typing import Callable, Protocol, runtime_checkable

import pytest

from typekeeper.typekeeper import (
    _check_type,
    _iter_path_values,
    _Segment,
    _split_path,
    is_immutable,
    validate_args,
)


# ---------------------------------------------------------------------------
# Bug #1 — literal "" dict key was unreachable through path specs.
# Fix:    new ``\!`` escape in ``_split_path`` produces a literal empty
#         segment that bypasses the wildcard branch in
#         ``_iter_path_values``.
# ---------------------------------------------------------------------------

class TestBug1EmptyKey:
    def test_unescaped_empty_segment_remains_wildcard(self):
        data = {"": 5, "real": 9}
        result = list(_iter_path_values(data, _split_path("")))
        # ``_split_path("")`` -> [Segment("", False)] -> wildcard.
        assert sorted(result) == sorted([([""], 5), (["real"], 9)])

    def test_literal_empty_key_addressable_via_escape(self):
        data = {"": 5, "real": 9}
        # ``\!`` is the new explicit empty-literal sigil.
        result = list(_iter_path_values(data, _split_path("\\!")))
        assert result == [([""], 5)]

    def test_spec_with_empty_literal_key(self):
        @validate_args(constraints="d:\\!=0-3")
        def f(d: dict) -> dict:
            return d

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            f({"": 2, "anything": 99})
        assert caught == []

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            f({"": 99, "anything": 0})
        # Only the literal "" entry must fail; "anything" is ignored.
        bad = [m for m in caught if "not in ranges" in str(m.message)]
        assert len(bad) == 1


# ---------------------------------------------------------------------------
# Bug #2 — trailing colon == wildcard (documented behavior, locked in).
# ---------------------------------------------------------------------------

class TestBug2TrailingColon:
    def test_trailing_colon_means_wildcard(self):
        parts = _split_path("a:")
        assert parts == [_Segment("a", False), _Segment("", False)]

    def test_spec_with_trailing_colon_iterates_each_element(self):
        @validate_args(constraints="d:=1-3")
        def f(d: dict) -> dict:
            return d

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            f({"a": 1, "b": 2})
        assert caught == []

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            f({"a": 99})
        assert any("d:" in str(c.message) for c in caught)


# ---------------------------------------------------------------------------
# Bug #3 — leading colon -> empty parameter name.
# Fix:    ``_parse_specs`` now emits a clear warning instead of silently
#         dropping the spec.
# ---------------------------------------------------------------------------

class TestBug3LeadingColon:
    def test_split_returns_empty_first_segment(self):
        parts = _split_path(":a")
        assert parts == [_Segment("", False), _Segment("a", False)]

    def test_leading_colon_spec_warns_at_parse_time(self):
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")

            @validate_args(constraints=":a=1-3")
            def f(x: int) -> int:
                return x

        assert any(
            "empty parameter name" in str(c.message).lower() for c in caught
        )

    def test_leading_colon_spec_does_not_fire_at_call_time(self):
        # The spec is dropped, so calling the function should not fire
        # any range-violation warning regardless of the argument.
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")

            @validate_args(constraints=":a=1-3")
            def f(x: int) -> int:
                return x

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            f(99)
        assert not any("not in ranges" in str(c.message) for c in caught)


# ---------------------------------------------------------------------------
# Bug #4 — bare ":" path == two empty wildcards (lock-in + parse warning).
# ---------------------------------------------------------------------------

class TestBug4BareColon:
    def test_bare_colon_split(self):
        parts = _split_path(":")
        assert parts == [_Segment("", False), _Segment("", False)]

    def test_bare_colon_spec_warns_at_parse_time(self):
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")

            @validate_args(constraints=":=1-3")
            def f(x: int) -> int:
                return x

        assert any(
            "empty parameter name" in str(c.message).lower() for c in caught
        )


# ---------------------------------------------------------------------------
# Bug #5 — ``bytearray`` mutable (lock-in).
# ---------------------------------------------------------------------------

class TestBug5BytearrayIsMutable:
    def test_bytearray_is_treated_as_mutable(self):
        assert is_immutable(bytearray(b"abc")) is False

    def test_bytes_remains_immutable(self):
        assert is_immutable(b"abc") is True

    def test_memoryview_is_treated_as_mutable(self):
        assert is_immutable(memoryview(b"x")) is False


# ---------------------------------------------------------------------------
# Bug #6 — non-runtime Protocol now validates structurally.
# ---------------------------------------------------------------------------

@runtime_checkable
class _SupportsClose(Protocol):
    def close(self) -> None: ...


class _Closer:
    def close(self) -> None:  # noqa: D401
        return None


class _NoClose:
    pass


class _NonRuntimeProto(Protocol):
    def close(self) -> None: ...


class TestBug6Protocol:
    def test_runtime_checkable_works(self):
        assert _check_type(_Closer(), _SupportsClose) is True
        assert _check_type(_NoClose(), _SupportsClose) is False
        assert _check_type(123, _SupportsClose) is False

    def test_non_runtime_protocol_validated_structurally(self):
        assert _check_type(_Closer(), _NonRuntimeProto) is True
        assert _check_type(_NoClose(), _NonRuntimeProto) is False
        assert _check_type(123, _NonRuntimeProto) is False

    def test_empty_protocol_accepts_anything(self):
        class Empty(Protocol):
            pass

        assert _check_type(object(), Empty) is True
        assert _check_type(42, Empty) is True

    def test_protocol_attrs_mro_fallback(self):
        # Force the MRO fallback by hiding ``__protocol_attrs__`` from a
        # class that nonetheless self-identifies as a Protocol.  This keeps
        # the legacy branch covered on every interpreter.
        from typekeeper.typekeeper import _protocol_attrs

        class Legacy:
            _is_protocol = True
            value: int

            def close(self) -> None:
                pass

        attrs = _protocol_attrs(Legacy)
        assert "close" in attrs
        assert "value" in attrs

    def test_non_runtime_protocol_with_data_attribute(self):
        class HasData(Protocol):
            value: int

        class Carrier:
            value = 1

        class Empty:
            pass

        assert _check_type(Carrier(), HasData) is True
        assert _check_type(Empty(), HasData) is False


# ---------------------------------------------------------------------------
# Bug #7 — Callable[[...], R] now performs a best-effort arity check.
# ---------------------------------------------------------------------------

class TestBug7CallableArity:
    def test_exact_arity_match_passes(self):
        assert _check_type(lambda x: x, Callable[[int], int]) is True
        assert _check_type(lambda a, b: a + b, Callable[[int, int], int]) is True

    def test_too_few_or_too_many_args_fails(self):
        assert _check_type(lambda: 0, Callable[[int], int]) is False
        assert _check_type(lambda a, b, c: 0, Callable[[int], int]) is False

    def test_variadic_value_is_always_accepted(self):
        assert _check_type(lambda *a, **kw: 0, Callable[[int], int]) is True
        assert _check_type(lambda *a, **kw: 0, Callable[[int, int, int], int]) is True

    def test_value_with_default_argument(self):
        # ``f(a, b=1)`` accepts 1 or 2 positional arguments.
        def f(a, b=1):
            return 0

        assert _check_type(f, Callable[[int], int]) is True
        assert _check_type(f, Callable[[int, int], int]) is True
        assert _check_type(f, Callable[[int, int, int], int]) is False

    def test_callable_with_ellipsis_skips_arity(self):
        assert _check_type(lambda: 0, Callable[..., int]) is True
        assert _check_type(lambda a, b, c: 0, Callable[..., int]) is True

    def test_non_callable_value_still_fails(self):
        assert _check_type(123, Callable[[int], int]) is False

    def test_uninspectable_value_is_accepted(self):
        # ``inspect.signature`` raises ValueError for several CPython
        # builtins; the fallback path must accept those callables instead
        # of crashing.
        assert _check_type(range, Callable[[int], range]) is True
        assert _check_type(str, Callable[[int], str]) is True


# ---------------------------------------------------------------------------
# Bug #8 — class whose isinstance raises TypeError now fails closed.
# ---------------------------------------------------------------------------

class _RaisingMeta(type):
    def __instancecheck__(cls, instance):  # noqa: D401
        raise TypeError("annotation cannot perform isinstance check")


class _Weird(metaclass=_RaisingMeta):
    pass


class TestBug8RaisingMetaclass:
    def test_raising_metaclass_is_rejected(self):
        assert _check_type(1, _Weird) is False
        assert _check_type("anything", _Weird) is False


# ---------------------------------------------------------------------------
# Bug #9 — allow-list policy of ``is_immutable`` (lock-in).
# ---------------------------------------------------------------------------

class TestBug9ImmutableAllowList:
    def test_unknown_types_are_treated_as_mutable(self):
        class Custom:
            pass

        assert is_immutable(Custom()) is False
        assert is_immutable(set()) is False
        assert is_immutable({}) is False
        assert is_immutable([]) is False

    def test_known_immutables(self):
        for value in (None, True, 1, 1.5, 1 + 2j, "x", b"x", range(3), ()):
            assert is_immutable(value) is True, f"{value!r} should be immutable"


# ---------------------------------------------------------------------------
# Bug #10 — __slots__ class with mutable attribute (lock-in).
# ---------------------------------------------------------------------------

class _SlotHolder:
    __slots__ = ("data",)

    def __init__(self) -> None:
        self.data = []


class TestBug10SlotsWithMutable:
    def test_instance_is_mutable(self):
        assert is_immutable(_SlotHolder()) is False

    def test_tuple_containing_slot_instance_is_mutable(self):
        assert is_immutable((_SlotHolder(),)) is False

    def test_frozenset_containing_slot_instance_is_mutable(self):
        h = _SlotHolder()
        assert is_immutable(frozenset({h})) is False
