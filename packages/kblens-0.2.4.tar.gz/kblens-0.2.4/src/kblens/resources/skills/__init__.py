"""Bundled agent skills."""
