"""Bundled kblens-kb skill."""
