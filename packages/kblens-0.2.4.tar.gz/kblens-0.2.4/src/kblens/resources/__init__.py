"""Bundled package resources."""
