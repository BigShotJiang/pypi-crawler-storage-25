"""
Unified Ibis Expression Builder module to eliminate duplication
between IbisPlanner, ProgressiveDataLoader, and HierarchicalVirtualScrollManager
"""
from typing import List, Dict, Any, Optional, Union
import re
import ibis
from ibis import BaseBackend as IbisBaseBackend
from ibis.expr.api import Table as IbisTable, Expr as IbisExpr, Column as IbisColumn
from pivot_engine.types.pivot_spec import PivotSpec, Measure


class IbisExpressionBuilder:
    """
    Unified class for building Ibis expressions across all components
    """
    
    def __init__(self, backend: IbisBaseBackend):
        self.backend = backend

    @staticmethod
    def _custom_category_field_id(dimension: Dict[str, Any]) -> str:
        prefix = "__custom_category__"
        raw_field = dimension.get("field") if isinstance(dimension, dict) else None
        if isinstance(raw_field, str) and raw_field.startswith(prefix):
            return raw_field
        raw_id = ""
        if isinstance(dimension, dict):
            raw_id = str(dimension.get("id") or dimension.get("name") or dimension.get("label") or "category")
        slug = re.sub(r"[^a-z0-9_]+", "_", raw_id.strip().lower()).strip("_") or "category"
        if not re.match(r"^[a-z_]", slug):
            slug = f"c_{slug}"
        return f"{prefix}{slug}"

    @staticmethod
    def _normalize_custom_category_operator(value: Any) -> str:
        raw = str(value or "eq").strip()
        aliases = {
            "=": "=",
            "eq": "=",
            "==": "=",
            "!=": "!=",
            "<>": "!=",
            "ne": "!=",
            "not_eq": "!=",
            "not eq": "!=",
            "lt": "<",
            "lte": "<=",
            "gt": ">",
            "gte": ">=",
            "startsWith": "starts_with",
            "endsWith": "ends_with",
            "startswith": "starts_with",
            "endswith": "ends_with",
            "notIn": "not in",
            "isNull": "is null",
            "isNotNull": "is not null",
            "is_null": "is null",
            "is null": "is null",
            "is_not_null": "is not null",
            "is not null": "is not null",
            "not_in": "not in",
            "not in": "not in",
            "notin": "not in",
            "isnull": "is null",
            "isnotnull": "is not null",
        }
        normalized = aliases.get(raw)
        if normalized:
            return normalized
        normalized = raw.replace(" ", "_").lower()
        return aliases.get(normalized, normalized)

    def _normalize_custom_category_clause(
        self,
        clause: Dict[str, Any],
        fallback_field: str = "",
    ) -> Optional[Dict[str, Any]]:
        if not isinstance(clause, dict):
            return None
        field = clause.get("field")
        if not isinstance(field, str) or not field.strip():
            field = fallback_field
        if not isinstance(field, str) or not field.strip():
            return None
        operator = self._normalize_custom_category_operator(
            clause.get("operator", clause.get("op", clause.get("type", "eq")))
        )
        if operator in {"in", "not in"}:
            raw_values = clause.get("values")
            if raw_values is None:
                raw_values = clause.get("value")
            if isinstance(raw_values, str):
                values = [item.strip() for item in raw_values.split(",") if item.strip()]
            elif isinstance(raw_values, (list, tuple, set)):
                values = list(raw_values)
            else:
                values = [] if raw_values is None else [raw_values]
            value = values
        else:
            value = clause.get("value")
        return {
            "field": field.strip(),
            "op": operator,
            "value": value,
            "caseSensitive": bool(clause.get("caseSensitive", False)),
        }

    def _normalize_custom_category_condition(
        self,
        condition: Any,
        fallback_field: str = "",
    ) -> Optional[Dict[str, Any]]:
        if not isinstance(condition, dict):
            return None
        op = str(condition.get("op") or condition.get("operator") or "AND").upper()
        op = "OR" if op == "OR" else "AND"
        source = condition.get("clauses")
        if source is None:
            source = condition.get("conditions")
        if isinstance(source, list):
            clauses = [
                normalized
                for normalized in (
                    self._normalize_custom_category_clause(item, fallback_field)
                    for item in source
                )
                if normalized is not None
            ]
        else:
            single_clause = self._normalize_custom_category_clause(condition, fallback_field)
            clauses = [single_clause] if single_clause else []
        if not clauses:
            return None
        return {"op": op, "conditions": clauses}

    def build_custom_category_expression(self, table: IbisTable, dimension: Dict[str, Any]) -> Optional[IbisExpr]:
        if not isinstance(dimension, dict):
            return None
        field_id = self._custom_category_field_id(dimension)
        fallback_label = (
            dimension.get("fallbackLabel")
            or dimension.get("defaultLabel")
            or dimension.get("fallback")
            or "Other"
        )
        expr = ibis.literal(str(fallback_label))
        rules = dimension.get("rules") if isinstance(dimension.get("rules"), list) else []

        for rule in reversed(rules):
            if not isinstance(rule, dict):
                continue
            label = str(rule.get("label") or "").strip()
            if not label:
                continue
            condition = self._normalize_custom_category_condition(
                rule.get("condition") or rule,
                str(rule.get("field") or ""),
            )
            if not condition:
                continue
            condition_expr = self._build_filter_object(table, condition)
            if condition_expr is None:
                continue
            expr = condition_expr.ifelse(ibis.literal(label), expr)

        return expr.name(field_id)

    def apply_custom_dimensions(self, table: IbisTable, custom_dimensions: Optional[List[Dict[str, Any]]]) -> IbisTable:
        """Attach user-defined category columns before filters/grouping are planned.

        Category string column and its optional sort-key column are computed in a
        single mutate() call so each dimension adds only one subquery layer.
        """
        if not custom_dimensions:
            return table
        current_table = table
        for dimension in custom_dimensions:
            field_id = self._custom_category_field_id(dimension)
            category_expr = self.build_custom_category_expression(current_table, dimension)
            if category_expr is None:
                continue
            mutations: Dict[str, Any] = {field_id: category_expr}
            sort_key_expr = self._build_category_sort_key_expr(current_table, dimension)
            if sort_key_expr is not None:
                mutations[f"__sortkey__{field_id}"] = sort_key_expr
            current_table = current_table.mutate(**mutations)
        return current_table

    def _build_category_sort_key_expr(self, table: IbisTable, dimension: Dict[str, Any]) -> Optional[IbisExpr]:
        """Build a numeric hidden sort key for category ordering.

        Built from the RAW row conditions (same pass as the category string) so
        the database evaluates each rule condition only once per query.
        alpha / alpha_desc need no hidden key (plain string sort covers them).
        """
        order = str(dimension.get("order") or "creation").strip().lower()
        if order in ("alpha", "alpha_desc"):
            return None
        rules = dimension.get("rules", []) if isinstance(dimension.get("rules"), list) else []
        n = len(rules)

        if order == "creation":
            expr = ibis.literal(n, type="int64")
            for i in range(n - 1, -1, -1):
                rule = rules[i]
                if not isinstance(rule, dict):
                    continue
                condition = self._normalize_custom_category_condition(
                    rule.get("condition") or rule,
                    str(rule.get("field") or ""),
                )
                if not condition:
                    continue
                cond_expr = self._build_filter_object(table, condition)
                if cond_expr is None:
                    continue
                expr = cond_expr.ifelse(ibis.literal(i, type="int64"), expr)
            return expr

        if order in ("numeric", "numeric_desc"):
            expr = ibis.literal(1e18)
            for i in range(n - 1, -1, -1):
                rule = rules[i]
                if not isinstance(rule, dict):
                    continue
                label = str(rule.get("label") or "").strip()
                try:
                    num_val = float(label)
                except (ValueError, TypeError):
                    continue
                condition = self._normalize_custom_category_condition(
                    rule.get("condition") or rule,
                    str(rule.get("field") or ""),
                )
                if not condition:
                    continue
                cond_expr = self._build_filter_object(table, condition)
                if cond_expr is None:
                    continue
                expr = cond_expr.ifelse(ibis.literal(num_val), expr)
            return expr

        return None

    def build_filter_expression(self, table: IbisTable, filters: List[Dict[str, Any]], is_post_agg: bool = False) -> Optional[IbisExpr]:
        """Converts a list of filter dictionaries into a single Ibis boolean expression."""
        if not filters:
            return None

        all_expressions = []

        for f in filters:
            expr = self._build_filter_object(table, f, is_post_agg=is_post_agg)
            if expr is not None:
                all_expressions.append(expr)


        if not all_expressions:
            return None

        # AND all the top-level expressions together into a single boolean expression
        final_expression = all_expressions[0]
        for expr in all_expressions[1:]:
            final_expression &= expr
            
        return final_expression

    def _build_filter_object(self, table: IbisTable, filter_spec: Dict[str, Any], is_post_agg: bool = False) -> Optional[IbisExpr]:
        if not isinstance(filter_spec, dict):
            print(f"Warning: Malformed filter object skipped: {filter_spec}")
            return None

        # Composite filter object like {operator: 'AND', conditions: [...]}.
        # Conditions may themselves be composite, which is required for exact
        # OR-of-AND hierarchy parent-path filtering.
        if ('op' in filter_spec or 'operator' in filter_spec) and 'conditions' in filter_spec:
            sub_expressions = []
            for sub_cond in filter_spec.get('conditions', []):
                expr = self._build_filter_object(table, sub_cond, is_post_agg=is_post_agg)
                if expr is not None:
                    sub_expressions.append(expr)

            if not sub_expressions:
                return None

            combined_sub = sub_expressions[0]
            op = str(filter_spec.get('op') or filter_spec.get('operator') or "OR").upper()
            if op == 'AND':
                for expr in sub_expressions[1:]:
                    combined_sub &= expr
            else:
                for expr in sub_expressions[1:]:
                    combined_sub |= expr
            return combined_sub

        # Simple filter object like {field: ..., op: ..., value: ...}
        if 'field' in filter_spec:
            field = filter_spec.get("field")
            if not field or field not in table.columns:
                if not is_post_agg:
                    print(f"Warning: Filter field '{field}' not found in table columns.")
                return None

            return self._build_single_filter(
                table[field],
                filter_spec.get('op', '='),
                filter_spec.get('value'),
                filter_spec.get('caseSensitive', False)
            )

        print(f"Warning: Malformed filter object skipped: {filter_spec}")
        return None

    def _build_single_filter(self, col: IbisColumn, op: str, value: Any, case_sensitive: bool = False) -> Optional[IbisExpr]:
        """Internal helper to build a single condition for a column."""
        op = self._normalize_custom_category_operator(op).lower()
        
        # Helper to cast value to column type for strict comparisons
        def cast_val(v, c):
            if v is None: return v
            try:
                col_type = c.type()
                
                # Integer handling
                if col_type.is_integer():
                    if isinstance(v, (int, float)):
                        return int(v)
                    if isinstance(v, str) and v.strip():
                        # Handle "123.0" -> 123
                        try:
                            return int(float(v))
                        except:
                            return int(v)
                
                # Float/Double/Decimal handling
                elif col_type.is_floating() or col_type.is_decimal():
                    if isinstance(v, (int, float, str)):
                        return float(v)
                
                # Boolean handling
                elif col_type.is_boolean():
                    if isinstance(v, str):
                        return v.lower() in ('true', '1', 't', 'yes', 'y')
                    return bool(v)
                
                # String handling (ensure string)
                elif col_type.is_string() and not isinstance(v, str):
                    return str(v)
                
                # Date/Time handling (let Ibis handle string parsing, but ensure string)
                elif (col_type.is_date() or col_type.is_timestamp()) and not isinstance(v, (str, int, float)):
                     # If it's a python date/datetime object, it's fine.
                     pass

            except Exception:
                # If casting fails, return original value and let backend complain or handle it
                pass
            return v

        if op in ["=", "eq"]:
            val = cast_val(value, col)
            if not case_sensitive and isinstance(value, str):
                try:
                    if col.type().is_string():
                        return col.lower() == str(val).lower()
                except: pass
            return col == val

        if op in ["!=", "ne"]:
            val = cast_val(value, col)
            if not case_sensitive and isinstance(value, str):
                try:
                    if col.type().is_string():
                        return col.lower() != str(val).lower()
                except: pass
            return col != val

        if op in ["<", "lt"]:
            return col < cast_val(value, col)
        if op in ["<=", "lte"]:
            return col <= cast_val(value, col)
        if op in [">", "gt"]:
            return col > cast_val(value, col)
        if op in [">=", "gte"]:
            return col >= cast_val(value, col)
        
        # String/Array operations
        if op == "in":
            if isinstance(value, (list, tuple, set)):
                vals = [cast_val(v, col) for v in value]
                if not case_sensitive:
                    try:
                        if col.type().is_string():
                            # For case-insensitive IN, we can use lower() on col and values
                            return col.lower().isin([str(v).lower() for v in vals])
                    except: pass
                return col.isin(vals)
            return col == cast_val(value, col) # Fallback for single value

        if op == "not in":
            if isinstance(value, (list, tuple, set)):
                vals = [cast_val(v, col) for v in value]
                if not case_sensitive:
                    try:
                        if col.type().is_string():
                            return ~col.lower().isin([str(v).lower() for v in vals])
                    except: pass
                return ~col.isin(vals)
            return col != cast_val(value, col)

        if op == "between":
            if isinstance(value, (list, tuple)) and len(value) == 2:
                return col.between(cast_val(value[0], col), cast_val(value[1], col))
        
        # All subsequent operations require casting to string
        str_col = col.cast('string')
        
        if op == "like":
            return str_col.like(value) if case_sensitive else str_col.ilike(value)
        if op == "ilike":
            return str_col.ilike(value) # Always insensitive
        
        if op == "starts_with":
            pat = f"{value}%"
            return str_col.like(pat) if case_sensitive else str_col.ilike(pat)
        if op == "ends_with":
            pat = f"%{value}"
            return str_col.like(pat) if case_sensitive else str_col.ilike(pat)
        if op == "contains":
            pat = f"%{value}%"
            return str_col.like(pat) if case_sensitive else str_col.ilike(pat)
        
        # Null/empty checks. The custom category UI labels these operators as
        # "empty" and the client evaluator treats whitespace-only strings as
        # empty, so keep server-side materialization aligned.
        if op == "is null":
            try:
                if col.type().is_string():
                    return col.isnull() | (col.cast("string").strip() == "")
            except Exception:
                pass
            return col.isnull()
        if op == "is not null":
            try:
                if col.type().is_string():
                    return col.notnull() & (col.cast("string").strip() != "")
            except Exception:
                pass
            return col.notnull()
        
        return None

    def build_sort_expressions(self, table: IbisTable, sort_specs: Union[Dict[str, Any], List[Dict[str, Any]]]) -> List[Union[ibis.Column, ibis.Expr]]:
        """Converts sort specifications to a list of Ibis sort expressions."""
        if not sort_specs:
            return []

        sort_list = [sort_specs] if isinstance(sort_specs, dict) else sort_specs
        ibis_sorts = []
        seen_effective_sorts = set()

        for s in sort_list:
            field = s.get("field")
            if not field:
                continue

            sort_type = str(s.get("sortType") or "").strip().lower()
            sort_key_field = s.get("sortKeyField")
            use_hidden_sort_key = (
                isinstance(sort_key_field, str)
                and sort_key_field
                and sort_key_field in table.columns
            )
            effective_field = sort_key_field if use_hidden_sort_key else field
            if effective_field not in table.columns:
                if field not in table.columns:
                    continue
                effective_field = field
                use_hidden_sort_key = False

            order = (s.get("order") or "asc").lower()
            nulls = (s.get("nulls") or "").lower()
            semantic_type = str(
                s.get("semanticType") or s.get("semantic") or s.get("sortSemantic") or ""
            ).lower()
            absolute_sort = bool(s.get("absoluteSort")) or sort_type in {
                "absolute",
                "abs",
                "absolute_value",
                "absolute-value",
            }
            effective_sort_key = (
                effective_field,
                order,
                nulls,
                semantic_type if not use_hidden_sort_key else "",
                absolute_sort,
            )
            if effective_sort_key in seen_effective_sorts:
                continue
            seen_effective_sorts.add(effective_sort_key)

            col = table[effective_field]
            sort_expr = None

            if semantic_type == "tenor" and not use_hidden_sort_key:
                # Parse pillar values into a numeric days key.
                # Supports: tenor notation (1D, 2W, 6M, 1Y), ISO dates (2025-04-01),
                # and month-year strings (Jun 2025, June 2025).
                tenor_text = col.cast("string")

                # --- Tenor: 1D / 2W / 6M / 1Y ---
                tenor_pat = r"^\s*([0-9]+(?:\.[0-9]+)?)\s*([A-Za-z])\s*$"
                num_val = tenor_text.re_extract(tenor_pat, 1).nullif("").cast("float64")
                unit_str = tenor_text.re_extract(tenor_pat, 2).lower()
                unit_factor = (unit_str == "d").ifelse(
                    1.0,
                    (unit_str == "w").ifelse(
                        7.0,
                        (unit_str == "m").ifelse(
                            30.4375,
                            (unit_str == "y").ifelse(365.25, ibis.null()),
                        ),
                    ),
                )
                tenor_key = num_val * unit_factor
                is_tenor = num_val.notnull() & unit_factor.notnull()

                # --- ISO date: 2025-04-01 ---
                iso_pat = r"^\s*(\d{4})-(\d{2})-(\d{2})\s*$"
                iso_y = tenor_text.re_extract(iso_pat, 1).nullif("").cast("float64")
                iso_m = tenor_text.re_extract(iso_pat, 2).nullif("").cast("float64")
                iso_d = tenor_text.re_extract(iso_pat, 3).nullif("").cast("float64")
                iso_key = (iso_y - 1970.0) * 365.25 + (iso_m - 1.0) * 30.4375 + iso_d
                is_iso = iso_y.notnull()

                # --- Month-year: Jun 2025 / June 2025 (first 3 chars of month name) ---
                my_pat = r"^\s*([A-Za-z]+)\s+(\d{4})\s*$"
                mon_abbr = tenor_text.re_extract(my_pat, 1).lower().substr(0, 3)
                my_year = tenor_text.re_extract(my_pat, 2).nullif("").cast("float64")
                mon_num = (
                    (mon_abbr == "jan").ifelse(1.0,
                    (mon_abbr == "feb").ifelse(2.0,
                    (mon_abbr == "mar").ifelse(3.0,
                    (mon_abbr == "apr").ifelse(4.0,
                    (mon_abbr == "may").ifelse(5.0,
                    (mon_abbr == "jun").ifelse(6.0,
                    (mon_abbr == "jul").ifelse(7.0,
                    (mon_abbr == "aug").ifelse(8.0,
                    (mon_abbr == "sep").ifelse(9.0,
                    (mon_abbr == "oct").ifelse(10.0,
                    (mon_abbr == "nov").ifelse(11.0,
                    (mon_abbr == "dec").ifelse(12.0, ibis.null())))))))))))))
                my_key = (my_year - 1970.0) * 365.25 + (mon_num - 1.0) * 30.4375
                is_my = my_year.notnull() & mon_num.notnull()

                # Combined key: tenor → ISO date → month-year → fallback text
                sort_key = is_tenor.ifelse(
                    tenor_key,
                    is_iso.ifelse(iso_key, is_my.ifelse(my_key, ibis.null())),
                )
                is_valid = is_tenor | is_iso | is_my

                ibis_sorts.append(is_valid.desc())
                ibis_sorts.append(sort_key.asc() if order == "asc" else sort_key.desc())
                ibis_sorts.append(tenor_text.asc() if order == "asc" else tenor_text.desc())
                continue

            if nulls == 'first':
                ibis_sorts.append(col.isnull().desc())
            elif nulls == 'last':
                ibis_sorts.append(col.isnull().asc())

            if absolute_sort:
                try:
                    col_type = col.type()
                    is_numeric_col = any(
                        getattr(col_type, type_check, lambda: False)()
                        for type_check in ("is_numeric", "is_integer", "is_floating", "is_decimal")
                    )
                    sort_col = col.abs() if is_numeric_col else col
                except Exception:
                    sort_col = col
                if order == 'asc':
                    ibis_sorts.append(sort_col.asc())
                    ibis_sorts.append(col.asc())
                elif order == 'desc':
                    ibis_sorts.append(sort_col.desc())
                    ibis_sorts.append(col.desc())
                continue

            if order == 'asc':
                sort_expr = col.asc()
            elif order == 'desc':
                sort_expr = col.desc()

            if sort_expr is not None:
                ibis_sorts.append(sort_expr)

        return ibis_sorts

    def build_cursor_filter_expression(self, table: IbisTable, spec: PivotSpec) -> Optional[IbisExpr]:
        """Builds an Ibis WHERE clause for cursor-based pagination."""
        if not spec.cursor or not spec.sort:
            return None

        sort_keys = spec.sort if isinstance(spec.sort, list) else [spec.sort]
        
        or_clauses = []

        for i in range(len(sort_keys)):
            current_key = sort_keys[i]
            field = current_key['field']
            order = current_key.get('order', 'asc').lower()
            
            and_clauses = []
            for j in range(i):
                prev_key = sort_keys[j]
                prev_field = prev_key['field']
                prev_val = spec.cursor.get(prev_field)
                if prev_field not in table.columns:
                    return None
                and_clauses.append(table[prev_field] == prev_val)

            if field not in table.columns:
                return None

            col_expr = table[field]
            cursor_value = spec.cursor.get(field)
            if order == 'asc':
                current_clause = col_expr > cursor_value
            else: # order == 'desc'
                current_clause = col_expr < cursor_value
            
            if and_clauses:
                full_clause = and_clauses[0]
                for clause in and_clauses[1:]:
                    full_clause &= clause
                full_clause &= current_clause
            else:
                full_clause = current_clause
            
            or_clauses.append(full_clause)

        if not or_clauses:
            return None
        
        combined_or_filter = or_clauses[0]
        for or_expr in or_clauses[1:]:
            combined_or_filter |= or_expr
        
        return combined_or_filter

    def build_measure_aggregation(self, table: IbisTable, measure: Measure) -> ibis.Scalar:
        """Converts a Measure object into an Ibis aggregation expression."""
        if not measure.alias:
            raise ValueError("Measure must include an alias")

        col = table[measure.field] if measure.field else None
        agg_type = (measure.agg or "sum").strip().lower()

        if measure.expression:
            raise ValueError(f"Custom Ibis expressions are not supported directly in measure '{measure.alias}'.")

        if measure.filter_condition:
            # Handle filtered measure by using Ibis 'where' on the column
            # This is equivalent to conditional aggregation (FILTER clause in SQL)
            if col is not None:
                # Need to convert dictionary filter to Ibis expression
                # This requires access to the table to build the filter
                filter_expr = self.build_filter_expression(table, [measure.filter_condition])
                if filter_expr is not None:
                    col = col.where(filter_expr)

        if agg_type in {"weighted_avg", "wavg", "weighted_mean"}:
            if col is None:
                raise ValueError(f"Weighted average requires a value field for measure '{measure.alias}'")
            if not measure.weighted_field:
                raise ValueError(
                    f"Weighted average measure '{measure.alias}' requires 'weighted_field' (or valConfig weightField)"
                )
            if measure.weighted_field not in table.columns:
                raise ValueError(
                    f"Weighted average measure '{measure.alias}' references unknown weight field '{measure.weighted_field}'"
                )

            weight_col = table[measure.weighted_field]
            if measure.filter_condition:
                filter_expr = self.build_filter_expression(table, [measure.filter_condition])
                if filter_expr is not None:
                    weight_col = weight_col.where(filter_expr)

            # Ignore rows where value or weight is null.
            valid_mask = col.notnull() & weight_col.notnull()
            weighted_value = ibis.ifelse(valid_mask, col * weight_col, ibis.null())
            weighted_weight = ibis.ifelse(valid_mask, weight_col, ibis.null())
            weighted_sum = weighted_value.sum()
            total_weight = weighted_weight.sum()
            return (weighted_sum / total_weight.nullif(0)).name(measure.alias)

        if agg_type == 'sum':
            return col.sum().name(measure.alias)
        elif agg_type == 'avg':
            return col.mean().name(measure.alias)
        elif agg_type == 'min':
            return col.min().name(measure.alias)
        elif agg_type == 'max':
            return col.max().name(measure.alias)
        elif agg_type == 'count':
            return col.count().name(measure.alias) if measure.field else table.count().name(measure.alias)
        elif agg_type in ['count_distinct', 'distinct_count']:
            return col.nunique().name(measure.alias)
        elif agg_type == 'stddev':
            return col.std().name(measure.alias)
        elif agg_type == 'variance':
            return col.var().name(measure.alias)
        elif agg_type == 'median':
            # Try exact median, then approximate, then quantile
            try:
                return col.median().name(measure.alias)
            except (AttributeError, NotImplementedError):
                try:
                    return col.approx_median().name(measure.alias)
                except (AttributeError, NotImplementedError):
                     return col.quantile(0.5).name(measure.alias)
        elif agg_type == 'percentile':
            if measure.percentile is None:
                raise ValueError("Percentile aggregation requires percentile parameter")
            p = float(measure.percentile)
            try:
                return col.quantile(p).name(measure.alias)
            except (AttributeError, NotImplementedError):
                try:
                    return col.approx_quantile(p).name(measure.alias)
                except (AttributeError, NotImplementedError):
                    raise ValueError(f"Percentile/Quantile not supported by backend for measure {measure.alias}")
        elif agg_type == 'string_agg':
            sep = measure.separator or ','
            return col.group_concat(sep).name(measure.alias)
        elif agg_type == 'array_agg':
            return col.collect().name(measure.alias)
        elif agg_type in {"first", "last"}:
            method = 'first' if agg_type == 'first' else 'last'
            return col.arbitrary(how=method).name(measure.alias)
        else:
            raise ValueError(f"Unsupported aggregation type: {agg_type}")

    def build_aggregated_table(self, 
                               table: IbisTable,
                               group_cols: List[str],
                               measures: List[Measure],
                               sort_specs: Optional[Union[Dict[str, Any], List[Dict[str, Any]]]] = None,
                               limit: Optional[int] = None,
                               offset: Optional[int] = None) -> IbisTable:
        """
        Builds a standard aggregated table with grouping, sorting, and pagination
        """
        # Build aggregations
        aggregations = []
        for m in measures:
            agg_expr = self.build_measure_aggregation(table, m)
            aggregations.append(agg_expr)

        # Apply grouping and aggregation
        if group_cols:
            result_table = table.group_by(group_cols).aggregate(aggregations)
        else:
            result_table = table.aggregate(aggregations)

        # Apply sorting
        if sort_specs:
            ibis_sorts = self.build_sort_expressions(result_table, sort_specs)
            if ibis_sorts:
                result_table = result_table.order_by(ibis_sorts)

        # Apply limit and offset
        if limit:
            if offset:
                result_table = result_table.limit(limit, offset=offset)
            else:
                result_table = result_table.limit(limit)
        elif offset:
            # If only offset is provided, we need to limit to something large
            result_table = result_table.limit(1000000, offset=offset)  # Large default limit

        return result_table

    def build_base_table_with_filters(self, spec: PivotSpec) -> IbisTable:
        """
        Builds a base table with filters applied
        """
        base_table = self.backend.table(spec.table)
        base_table = self.apply_custom_dimensions(base_table, getattr(spec, "custom_dimensions", []))

        # Apply filters
        filtered_table = base_table
        if spec.filters:
            filter_expr = self.build_filter_expression(base_table, spec.filters)
            if filter_expr is not None:
                filtered_table = filtered_table.filter(filter_expr)

        return filtered_table
