"""Core module for phoenix."""
