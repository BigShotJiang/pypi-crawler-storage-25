from __future__ import annotations

import json
import os
import re
import threading
import tomllib
import traceback
from pathlib import Path
from typing import Any
from xml.etree import ElementTree as ET

from dotenv import load_dotenv
from textual import events
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.widgets import Footer, Static, TextArea, RichLog
from rich.text import Text
from minters.workspace import resolve_workspace_root

try:
    from regulator.model import regulator
except ModuleNotFoundError:
    from model import regulator

ROOT = resolve_workspace_root(create=False)
load_dotenv(ROOT / ".env", override=False)


def _read_version() -> str:
    pyproject = ROOT / "pyproject.toml"
    try:
        data = tomllib.loads(pyproject.read_text(encoding="utf-8"))
    except Exception:
        return "dev"
    return str(data.get("project", {}).get("version", "dev"))


DEFAULT_MODEL = os.getenv("REGULATOR_MODEL", "1984-m3-0421")
APP_VERSION = _read_version()
COMPOSER_MIN_HEIGHT = 5
COMPOSER_MAX_HEIGHT = 12

TASK_CONTEXT = f"Workspace root: {ROOT}"
STATUS_FRAMES = ["◜", "◠", "◝", "◞", "◡", "◟"]
TITLE_ART = r"""
 __  __ ___ _   _ _____ _____ ____
|  \/  |_ _| \ | |_   _| ____|  _ \
| |\/| || ||  \| | | | |  _| | |_) |
| |  | || || |\  | | | | |___|  _ <
|_|  |_|___|_| \_| |_| |_____|_| \_\\
 ____  _____    _    _
/ ___|| ____|  / \  | |
\___ \|  _|   / _ \ | |
 ___) | |___ / ___ \| |___
|____/|_____/_/   \_\_____|
""".strip("\n")


def build_task(user_task: str) -> str:
    task = user_task.strip()
    if not task:
        return TASK_CONTEXT
    return f"{TASK_CONTEXT}\n\nUser task:\n{task}"


class Composer(TextArea):
    BINDINGS = [
        Binding("ctrl+enter", "submit", "Send", show=False),
        Binding("ctrl+s", "submit", "Send", show=False),
    ]

    async def _on_key(self, event: events.Key) -> None:
        if event.key == "enter":
            event.stop()
            event.prevent_default()
            self.action_submit()
            return
        await super()._on_key(event)

    def action_submit(self) -> None:
        submit = getattr(self.app, "action_submit_prompt", None)
        if callable(submit):
            submit()


class SealApp(App[None]):
    CSS = """
    Screen {
        background: #000000;
        color: #ffffff;
    }

    #header-area {
        height: auto;
        padding: 1 4 1 4; /* Reduced padding */
        border-bottom: solid #141414;
    }

    #minter-title {
        color: #ffffff;
        text-style: bold;
        height: auto;
        padding-bottom: 1;
    }

    #minter-subtitle {
        color: #444444;
        height: auto;
    }

    #feed {
        height: 1fr;
        padding: 1 4 1 4;
        background: #000000;
        color: #444444;
        border: none;
        scrollbar-color: #202020 #000000;
    }

    #feed:focus {
        border: none;
    }

    #status-row {
        height: 0;
        padding: 0 4;
        color: #444444;
        background: #000000;
    }

    #input-row {
        height: auto;
        min-height: 7;
        border-top: solid #141414;
        padding: 1 4;
        align: left bottom;
        background: #000000;
    }

    #input-prompt {
        width: 2;
        height: 1;
        color: #ffffff;
        text-style: bold;
        padding: 1 1 0 0;
    }

    #task-input {
        width: 1fr;
        min-height: 5;
        height: 5;
        max-height: 12;
        background: #000000;
        border: solid #353535;
        scrollbar-color: #4a4a4a #000000;
        color: #ffffff;
        padding: 1 1;
    }

    #task-input:focus {
        border: solid #5a5a5a;
        background: #000000;
    }

    #task-input .text-area--selection {
        background: #ffffff;
        color: #000000;
    }

    #task-input .text-area--cursor {
        background: #ffffff;
        color: #000000;
    }

    Footer {
        background: #000000;
        color: #555555;
        border-top: solid #141414;
    }
    """

    BINDINGS = [
        Binding("ctrl+j", "focus_prompt", "Prompt", show=False),
        Binding("ctrl+k", "focus_feed", "Transcript", show=False),
        Binding("ctrl+l", "clear_logs", "Clear"),
        Binding("q", "quit", "Quit"),
    ]

    TITLE = "Minter Seal"

    def __init__(self, model_name: str = DEFAULT_MODEL) -> None:
        super().__init__()
        self.model_name = model_name
        self.busy = False
        self._response_started = False
        self._status_frame = 0
        self._stream_buffer = ""

    def compose(self) -> ComposeResult:
        with Vertical(id="header-area"):
            yield Static(TITLE_ART, id="minter-title")
            yield Static("", id="minter-subtitle")
        yield RichLog(
            id="feed",
            markup=False,
            highlight=False,
            auto_scroll=True,
        )
        yield Static("", id="status-row")
        with Horizontal(id="input-row"):
            yield Static("> ", id="input-prompt")
            yield Composer(
                "",
                id="task-input",
                soft_wrap=True,
                show_line_numbers=False,
                highlight_cursor_line=False,
                placeholder="Type here",
            )
        yield Footer()

    def on_mount(self) -> None:
        self._update_header()
        self._write_welcome()
        self._render_status()
        self.set_interval(0.14, self._animate_status)
        self.call_after_refresh(self._resize_composer)
        composer = self.query_one("#task-input", Composer)
        composer.show_horizontal_scrollbar = False
        composer.show_vertical_scrollbar = False
        composer.focus()

    def _write_welcome(self) -> None:
        feed = self.query_one("#feed", RichLog)
        welcome = (
            "* Welcome to the Minter.\n\n"
            "while(minting) {\n"
            "    inspect_repo();\n"
            "    edit_files();\n"
            "    run_contracts();\n"
            "    validate();\n"
            "    iterate();\n"
            "}\n"
        )
        for line in welcome.splitlines():
            feed.write(Text(line, style="grey20"))
        feed.write(Text(""))

    # ── actions ──────────────────────────────────────────────────────────

    def action_focus_prompt(self) -> None:
        self.query_one("#task-input", Composer).focus()

    def action_focus_feed(self) -> None:
        self.query_one("#feed", RichLog).focus()

    def action_submit_prompt(self) -> None:
        self._submit_prompt()

    def action_clear_logs(self) -> None:
        self.query_one("#feed", RichLog).clear()
        self._stream_buffer = ""
        self._response_started = False
        self._write_welcome()
        self._render_status()

    def on_text_area_changed(self, event: TextArea.Changed) -> None:
        if event.text_area.id == "task-input":
            self.call_after_refresh(self._resize_composer)

    # ── feed helpers ─────────────────────────────────────────────────────

    def _format_prompt_block(self, raw_task: str) -> str:
        lines = raw_task.splitlines() or [raw_task]
        first = f"> {lines[0]}"
        rest = [f"  {line}" for line in lines[1:]]
        return "\n".join([first, *rest])

    def _mark_response_started(self) -> None:
        if self._response_started:
            return
        self._response_started = True
        self._render_status()

    # def _animate_status(self) -> None:
    #     if self.busy and self._response_started:
    #         self._status_frame = (self._status_frame + 1) % len(STATUS_FRAMES)
    #     self._render_status()

    def _update_header(self) -> None:
        subtitle = f"v{APP_VERSION}"
        self.query_one("#minter-subtitle", Static).update(subtitle)

    def _animate_status(self) -> None:
        # Animate as long as the app is busy, regardless of whether text has started streaming
        if self.busy:
            self._status_frame = (self._status_frame + 1) % len(STATUS_FRAMES)
            self._render_status()

    def _render_status(self) -> None:
        status = self.query_one("#status-row", Static)
        
        if self.busy:
            frame = STATUS_FRAMES[self._status_frame]
            # Show "pondering..." before the stream starts, "composing..." during
            action = "composing" if self._response_started else "pondering"
            text = f"{frame} {action}..."
            status.styles.height = 1
        else:
            text = ""
            status.styles.height = 0
            
        status.update(text)

    def _resize_composer(self) -> None:
        composer = self.query_one("#task-input", Composer)
        row = self.query_one("#input-row", Horizontal)
        wrapped_height = composer.wrapped_document.height if composer.wrap_width > 0 else COMPOSER_MIN_HEIGHT
        target_height = max(COMPOSER_MIN_HEIGHT, min(COMPOSER_MAX_HEIGHT, wrapped_height))
        composer.styles.height = target_height
        row.styles.height = target_height + 2
        composer.show_vertical_scrollbar = wrapped_height > COMPOSER_MAX_HEIGHT

    def _trim(self, text: str, limit: int = 96) -> str:
        compact = re.sub(r"\s+", " ", str(text)).strip()
        if len(compact) <= limit:
            return compact
        return f"{compact[: limit - 3]}..."

    def _short_path(self, value: str | None) -> str:
        raw = str(value or "").strip()
        if not raw:
            return "?"
        try:
            path = Path(raw)
        except (TypeError, ValueError):
            return raw
        if path.is_absolute():
            try:
                return str(path.resolve().relative_to(ROOT)) or "."
            except ValueError:
                return path.name or raw
        return raw

    def _parse_service_call(self, call_text: str) -> tuple[str, dict[str, Any]]:
        try:
            node = ET.fromstring(call_text)
            service_name = node.attrib.get("name", "service").strip() or "service"
            params = json.loads(node.text or "{}")
            return service_name, params if isinstance(params, dict) else {}
        except (ET.ParseError, json.JSONDecodeError):
            match = re.search(r'name="([^"]+)"', call_text)
            return (match.group(1) if match else "service", {})

    def _service_summary(
        self,
        service_name: str,
        params: dict[str, Any],
        result: dict[str, Any] | None = None,
    ) -> str:
        result = result or {}
        path = self._short_path(result.get("path") or params.get("path"))
        if service_name == "read_file":
            start = params.get("start_line", 1)
            end = params.get("end_line", 240)
            return f"read_file {path}:{start}-{end}"
        if service_name == "write_file":
            return f"write_file {path}"
        if service_name == "patch_file":
            return f"patch_file {path}"
        if service_name == "make_directory":
            return f"make_directory {path}"
        if service_name == "delete_path":
            return f"delete_path {path}"
        if service_name == "python_check":
            return f"python_check {path}"
        if service_name == "run_contract":
            class_name = str(result.get("class_name") or params.get("class_name") or "").strip()
            label = f"run_contract {path}"
            return f"{label}::{class_name}" if class_name else label
        if service_name == "list_files":
            pattern = str(params.get("glob") or params.get("pattern") or params.get("path") or "**/*")
            return f"list_files {self._trim(pattern, 72)}"
        if service_name == "grep_repo":
            pattern = str(params.get("pattern") or "")
            return f"grep_repo {self._trim(pattern, 72)}"
        if service_name == "repo_tree":
            return "repo_tree workspace"
        if service_name == "sandbox_run":
            command = self._trim(str(params.get("command") or ""), 80)
            cwd = self._short_path(params.get("cwd") or ".")
            return f"shell {command} @ {cwd}"
        if service_name == "sandbox_python":
            code = self._trim(str(params.get("code") or ""), 68)
            cwd = self._short_path(params.get("cwd") or ".")
            return f"python {code} @ {cwd}"
        if params:
            preview = ", ".join(
                f"{key}={self._trim(str(value), 20)}" for key, value in list(params.items())[:2]
            )
            return f"{service_name} {preview}".strip()
        return service_name

    def _observation_suffix(self, service_name: str, result: dict[str, Any]) -> str:
        if service_name == "read_file":
            line_count = result.get("line_count")
            return f" ({line_count} lines)" if line_count else ""
        if service_name == "patch_file":
            replaced = result.get("replaced")
            return f" ({replaced} replace)" if replaced else ""
        if service_name == "list_files":
            count = result.get("count")
            return f" ({count} match)" if count == 1 else (f" ({count} matches)" if count else "")
        if service_name == "python_check":
            return " (syntax ok)"
        if service_name == "run_contract":
            class_name = str(result.get("class_name") or "").strip()
            healthy = result.get("healthy")
            if class_name and healthy:
                return f" ({class_name}, healthy)"
            if class_name:
                return f" ({class_name})"
        if service_name == "sandbox_run":
            if result.get("timed_out"):
                return " (timed out)"
            if result.get("exit_code") is not None:
                return f" (exit {result.get('exit_code')})"
        return ""

    def _format_service_call_line(self, call_text: str) -> str:
        service_name, params = self._parse_service_call(call_text)
        summary = self._service_summary(service_name, params)
        details = summary[len(service_name) :].strip() if summary.startswith(service_name) else summary
        inner = details if details else "..."
        return f"  ▶ [call]  service.{service_name}({inner})"

    def _format_observation_line(self, payload: dict[str, Any]) -> str:
        service_name = str(payload.get("service_name") or "service").strip() or "service"
        params = payload.get("params", {}) if isinstance(payload.get("params"), dict) else {}
        result = payload.get("result", {}) if isinstance(payload.get("result"), dict) else {}
        success = bool(payload.get("success", False))
        label = self._service_summary(service_name, params, result)

        if success:
            return f"  ✔ [ok]    service.{label}{self._observation_suffix(service_name, result)}"
        error = self._trim(str(payload.get("error") or "client-managed service execution failed."), 88)
        return f"  ✖ [error] service.{label} :: {error}"

    def _set_busy(self, busy: bool) -> None:
        self.busy = busy
        self.query_one("#task-input", Composer).disabled = busy
        if busy:
            self._status_frame = 0
            self._response_started = False
        else:
            self._response_started = False
        self._render_status()

    # ── submit ───────────────────────────────────────────────────────────

    def _submit_prompt(self) -> None:
        if self.busy:
            return

        input_widget = self.query_one("#task-input", Composer)
        raw_task = input_widget.text.strip()
        if not raw_task:
            return

        input_widget.load_text("")
        self._resize_composer()
        if self._handle_local_command(raw_task):
            input_widget.focus()
            return

        feed = self.query_one("#feed", RichLog)
        feed.write(Text(""))
        for line in self._format_prompt_block(raw_task).splitlines():
            feed.write(Text(line, style="bold white"))
        feed.write(Text(""))
        self._response_started = False

        self._set_busy(True)
        task = build_task(raw_task)
        thread = threading.Thread(target=self._run_task, args=(task,), daemon=True)
        thread.start()

    def _handle_local_command(self, raw_task: str) -> bool:
        command = raw_task.strip()
        feed = self.query_one("#feed", RichLog)

        if command == "/clear":
            self.action_clear_logs()
            return True
        if command == "/help":
            help_text = (
                "/help\n"
                "  inspect the contracts folder and summarize the strategies\n"
                "  fix the gold contract and iterate until it runs healthy\n"
                "  grep the repo for all uses of regulator and explain the flow\n"
                "  write a new contract in contracts/demo/contract.py and validate it"
            )
            feed.write(Text(""))
            for line in help_text.splitlines():
                feed.write(Text(line, style="cyan"))
            feed.write(Text(""))
            return True
        if command.startswith("/model "):
            next_model = command.split(" ", 1)[1].strip()
            if next_model:
                self.model_name = next_model
                feed.write(Text(f"\nmodel -> {self.model_name}\n", style="cyan"))
            return True
        return False

    # ── task execution ────────────────────────────────────────────────────

    def _run_task(self, task: str) -> None:
        try:
            regulator(model=self.model_name, task=task, event_handler=self._relay_event)
        except Exception as exc:
            payload = {
                "type": "runtime_error",
                "text": f"{exc}\n\n{traceback.format_exc()}".strip(),
            }
            self.call_from_thread(self._handle_stream_event, payload)

    def _relay_event(self, event: dict[str, object]) -> None:
        self.call_from_thread(self._handle_stream_event, event)

    def _handle_stream_event(self, event: dict[str, object]) -> None:
        event_type = str(event.get("type", ""))
        feed = self.query_one("#feed", RichLog)

        if event_type == "text_delta":
            self._mark_response_started()
            self._stream_buffer += str(event.get("text", ""))
            while "\n" in self._stream_buffer:
                line, self._stream_buffer = self._stream_buffer.split("\n", 1)
                feed.write(Text(line, style="white"))
            return

        if event_type == "newline":
            if self._stream_buffer:
                feed.write(Text(self._stream_buffer, style="white"))
                self._stream_buffer = ""
            else:
                feed.write(Text("", style="white"))
            return

        if event_type == "service_call":
            if self._stream_buffer:
                feed.write(Text(self._stream_buffer, style="white"))
                self._stream_buffer = ""
            call_text = str(event.get("service_call") or event.get("text") or "").strip()
            summary = self._format_service_call_line(call_text)
            feed.write(Text(summary, style="grey50"))
            return

        if event_type == "observation":
            if self._stream_buffer:
                feed.write(Text(self._stream_buffer, style="white"))
                self._stream_buffer = ""
            payload = event.get("payload") if isinstance(event.get("payload"), dict) else {}
            summary = self._format_observation_line(payload)
            feed.write(Text(summary, style="grey50"))
            return

        if event_type == "awaiting_client_services":
            return

        if event_type == "response_complete":
            if self._stream_buffer:
                feed.write(Text(self._stream_buffer, style="white"))
                self._stream_buffer = ""
            feed.write(Text("  · done", style="grey50"))
            feed.write(Text("", style="white"))
            self._set_busy(False)
            self.query_one("#task-input", Composer).focus()
            return

        if event_type == "runtime_error":
            if self._stream_buffer:
                feed.write(Text(self._stream_buffer, style="white"))
                self._stream_buffer = ""
            message = str(event.get("text", "Unknown error"))
            feed.write(Text(f"  ✖ {message}", style="red"))
            self._set_busy(False)
            self.query_one("#task-input", Composer).focus()
            return

    def run_task_once_for_testing(self, task: str) -> None:
        self._run_task(build_task(task))


def main() -> None:
    SealApp().run()


if __name__ == "__main__":
    main()