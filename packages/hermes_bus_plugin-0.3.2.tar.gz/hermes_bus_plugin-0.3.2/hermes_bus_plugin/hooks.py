"""Bus hook handlers — startup, context injection, progress tracking."""

import json
import os
import re
import struct
import socket
import subprocess
import sys
import threading
import time
from datetime import datetime

_bus_messages = []
_msg_lock = threading.Lock()

# Notify config cache
_notify_config = None
_notify_config_mtime = 0


def _log(msg: str):
    """Debug log — only active when HERMES_BUS_DEBUG=1."""
    if os.environ.get("HERMES_BUS_DEBUG") != "1":
        return
    try:
        import datetime
        ts = datetime.datetime.now().strftime("%H:%M:%S.%f")
        with open("/tmp/hermes_bus_debug.log", "a") as f:
            f.write(f"[{ts}] {msg}\n")
    except Exception:
        pass


def _load_notify_config() -> dict:
    """Load and cache bus-rules.yaml (or fallback to notify.yaml), refetch if file changed."""
    global _notify_config, _notify_config_mtime
    home = os.environ.get("HERMES_HOME", os.path.expanduser("~/.hermes"))
    # New path: bus-rules.yaml at ~/.hermes/
    path = os.path.join(home, "bus-rules.yaml")
    # Fallback: old path at hermes-notify/notify.yaml
    if not os.path.exists(path):
        path = os.path.join(home, "hermes-notify", "notify.yaml")
    if not os.path.exists(path):
        return {"callbacks": []}
    try:
        mtime = os.path.getmtime(path)
        if _notify_config is not None and mtime == _notify_config_mtime:
            return _notify_config
        import yaml
        with open(path) as f:
            _notify_config = yaml.safe_load(f) or {"callbacks": []}
        _notify_config_mtime = mtime
    except Exception:
        return {"callbacks": []}
    return _notify_config


def _match_rule(msg_type: str, callbacks: list) -> dict | None:
    """Find best matching rule by match_type (lowest priority wins)."""
    if not msg_type:
        return None
    matches = [r for r in callbacks if r.get("match_type") == msg_type]
    if not matches:
        return None
    return min(matches, key=lambda r: r.get("priority", 100))


def _format_print(template: str, msg: dict) -> str:
    """Render print_format template with placeholders and ANSI colors.

    Placeholders:
      {from}            — sender endpoint name
      {text}            — message body text
      {type}            — message body type
      {ts}              — Unix timestamp (raw)
      {ts:strftime}     — formatted timestamp, e.g. {ts:%Y-%m-%d %H:%M:%S}
      {color:name}      — ANSI foreground color (black/red/green/yellow/blue/
                           magenta/cyan/white, or bold_red etc.)
      {bold}            — bold text
      {reset}           — reset all styles
    """
    body = msg.get("body", {})
    from_ep = msg.get("from", "?")
    text = body.get("text", "") if isinstance(body, dict) else str(body)
    msg_type = body.get("type", "") if isinstance(body, dict) else ""
    ts = msg.get("ts", time.time())

    def _replace_ts(m):
        fmt = m.group(1)
        if fmt:
            return datetime.fromtimestamp(float(ts)).strftime(fmt)
        return str(int(float(ts)))

    ANSI_COLORS = {
        "black": "30", "red": "31", "green": "32", "yellow": "33",
        "blue": "34", "magenta": "35", "cyan": "36", "white": "37",
    }

    def _replace_color(m):
        name = m.group(1).lower()
        parts = name.split("_", 1)
        bold = parts[0] == "bold" and len(parts) > 1
        color_name = parts[1] if bold else parts[0]
        code = ANSI_COLORS.get(color_name)
        if code is None:
            return ""
        if bold:
            return f"\033[1;{code}m"
        return f"\033[{code}m"

    result = template.replace("{from}", from_ep)
    result = result.replace("{text}", text)
    result = result.replace("{type}", msg_type)
    result = re.sub(r"\{ts(?::([^}]*))?\}", _replace_ts, result)
    result = re.sub(r"\{color:([^}]+)\}", _replace_color, result)
    result = result.replace("{bold}", "\033[1m")
    result = result.replace("{reset}", "\033[0m")
    return result


def _banner_print(text: str):
    """Print banner — every path we can think of."""
    line = f"[Hermes Bus] {text}"
    _log(f"BANNER: {text}")

    # Path 1: prompt_toolkit (canonical for TUI)
    try:
        from prompt_toolkit import print_formatted_text
        from prompt_toolkit.formatted_text import ANSI
        print_formatted_text(ANSI(f"\n\033[1;36m[Hermes Bus]\033[0m {text}"))
        _log("  -> prompt_toolkit OK")
        return
    except Exception as e:
        _log(f"  -> prompt_toolkit failed: {e}")

    # Path 2: cli._cprint
    try:
        from cli import _cprint
        _cprint(f"\033[1;36m[Hermes Bus]\033[0m {text}")
        _log("  -> _cprint OK")
        return
    except Exception as e:
        _log(f"  -> _cprint failed: {e}")

    # Path 3: __stdout__
    try:
        sys.__stdout__.write(f"\n{line}\n")
        sys.__stdout__.flush()
        _log("  -> __stdout__ OK")
        return
    except Exception as e:
        _log(f"  -> __stdout__ failed: {e}")

    # Path 4: stderr
    try:
        sys.stderr.write(f"\n{line}\n")
        sys.stderr.flush()
        _log("  -> stderr OK")
        return
    except Exception as e:
        _log(f"  -> stderr failed: {e}")

    # Path 5: print
    try:
        print(f"\n{line}")
        _log("  -> print OK")
    except Exception as e:
        _log(f"  -> print failed: {e}")


def _process_bus_message(msg: dict):
    """Process a single bus message: print, context injection, command execution."""
    # Only process routed messages with a body
    body = msg.get("body", {})
    msg_type = body.get("type", None) if isinstance(body, dict) else None
    if not msg_type:
        # Not a notification message (system message etc.), still queue for context
        with _msg_lock:
            _bus_messages.append(msg)
        return

    from_ep = msg.get("from", "?")
    callbacks = _load_notify_config().get("callbacks", [])
    rule = _match_rule(msg_type, callbacks)

    if rule is None:
        return

    # --- print: true → immediately print to terminal ---
    if rule.get("print"):
        tmpl = rule.get("print_format", "[{from}] {text}")
        _banner_print(_format_print(tmpl, msg))

    # --- command → spawn subprocess (async) ---
    if rule.get("command"):
        try:
            env = os.environ.copy()
            env["MESSAGE"] = json.dumps(msg, ensure_ascii=False)
            env["TYPE"] = msg_type or ""
            env["FROM"] = from_ep or ""
            p = subprocess.Popen(
                rule["command"],
                shell=True,
                stdin=subprocess.PIPE,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                env=env,
            )
            p.stdin.write(json.dumps(msg).encode())
            p.stdin.close()
        except Exception:
            pass

    # --- context: true → queue for on_pre_llm_call ---
    if rule.get("context"):
        with _msg_lock:
            _bus_messages.append(msg)


def ensure_bus_running():
    """Start bus daemon if not running."""
    _log(f"ensure_bus_running called, cwd={os.getcwd()}")
    try:
        r = subprocess.run(
            ["hermes-busd", "status"],
            capture_output=True, text=True, timeout=5,
        )
        out = (r.stdout + r.stderr).lower()
        _log(f"hermes-busd status: stdout={r.stdout.strip()}, stderr={r.stderr.strip()}")
        if "not running" in out or "stale" in out or "no socket" in out or "not respond" in out:
            _log("bus not running, calling restart")
            subprocess.run(["hermes-busd", "restart"], timeout=10)
            return True
        if _check_socket_alive():
            _log("socket check passed")
            return True
        _log("socket check FAILED, calling restart")
        subprocess.run(["hermes-busd", "restart"], timeout=10)
        return True
    except FileNotFoundError as e:
        _log(f"hermes-busd not found: {e}")
        return False
    except Exception as e:
        _log(f"ensure_bus_running error: {type(e).__name__}: {e}")
        return False


def _check_socket_alive() -> bool:
    home = os.environ.get("HERMES_HOME", os.path.expanduser("~/.hermes"))
    sock_path = os.path.join(home, "hermes-bus.sock")
    _log(f"_check_socket_alive: {sock_path} exists={os.path.exists(sock_path)}")
    try:
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.settimeout(2)
        s.connect(sock_path)
        s.close()
        return True
    except Exception as e:
        _log(f"_check_socket_alive failed: {e}")
        return False


def on_gateway_startup(**kwargs):
    """Check bus health — don't restart (register() already started it)."""
    _log("on_gateway_startup")
    if _check_socket_alive():
        return "Bus socket alive"
    return "Bus socket not found"


def on_session_start(**kwargs):
    """No-op: banner printed directly from listen_bus thread after 3s delay."""
    pass


def on_pre_llm_call(**kwargs):
    """Inject bus messages (with context:true rules) into LLM context."""
    with _msg_lock:
        if not _bus_messages:
            return None
        msgs = list(_bus_messages)
        _bus_messages.clear()

    if not msgs:
        return None

    context_lines = []
    callbacks = _load_notify_config().get("callbacks", [])

    for m in msgs:
        body = m.get("body", {})
        msg_type = body.get("type", None) if isinstance(body, dict) else None
        from_ep = m.get("from", "?")
        text = body.get("text", "") if isinstance(body, dict) else str(body)

        # Only inject context for messages with context:true rule matched
        rule = _match_rule(msg_type, callbacks)
        if rule and rule.get("context"):
            context_lines.append(f"[Bus/{from_ep}]: {text}")

    if not context_lines:
        return None

    return {"context": "\n".join(context_lines)}


def on_post_tool_call(tool_name: str = "", result: str = "", **kwargs):
    pass


def listen_bus(endpoint: str = "hermes-bus"):
    """Background thread: connect, register, listen."""
    home = os.environ.get("HERMES_HOME", os.path.expanduser("~/.hermes"))
    sock_path = os.path.join(home, "hermes-bus.sock")
    reconnect_delay = 5
    was_connected = False
    reconnect_count = 0

    _log(f"listen_bus START endpoint={endpoint} sock={sock_path}")

    while True:
        try:
            while not os.path.exists(sock_path):
                _log(f"listen_bus: waiting for socket {sock_path}")
                time.sleep(2)

            s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            s.settimeout(30)
            s.connect(sock_path)
            _log("listen_bus: connected")

            reg = json.dumps({"type": "register", "endpoint": endpoint}).encode()
            s.sendall(struct.pack(">I", len(reg)) + reg)
            _log(f"listen_bus: sent register for {endpoint}")

            header = s.recv(4)
            if not header:
                _log("listen_bus: recv empty header after register")
                s.close()
                time.sleep(2)
                continue
            length = struct.unpack(">I", header)[0]
            data = b""
            while len(data) < length:
                chunk = s.recv(length - len(data))
                if not chunk:
                    break
                data += chunk
            try:
                reply = json.loads(data.decode())
                _log(f"listen_bus: got reply type={reply.get('type')}")
                if reply.get("type") == "registered":
                    sid = reply.get("session_id", "")
                    if sid:
                        os.environ["HERMES_BUS_PLUGIN_SID"] = sid[:8]
                        _log(f"listen_bus: registered sid={sid[:8]}")

                    cur_endpoint = os.environ.get("HERMES_BUS_PLUGIN_ENDPOINT", endpoint)
                    cur_sid = os.environ.get("HERMES_BUS_PLUGIN_SID", "")
                    sid_part = f" (sid: {cur_sid})" if cur_sid else ""

                    if was_connected:
                        _banner_print(f"Reconnected as: {cur_endpoint}{sid_part}")
                    else:
                        # Delay to let TUI greeting render first
                        time.sleep(3)
                        _banner_print(f"Connected as: {cur_endpoint}{sid_part}")
                        _banner_print("Use /title <name> to set a persistent session name\n")
                    was_connected = True
            except Exception as e:
                _log(f"listen_bus: parse reply error: {e}")

            # Ping thread
            def _ping(sock_ref):
                while True:
                    time.sleep(55)
                    try:
                        ping = json.dumps({"type": "ping"}).encode()
                        sock_ref.sendall(struct.pack(">I", len(ping)) + ping)
                    except Exception:
                        break
            threading.Thread(target=_ping, args=(s,), daemon=True).start()

            # Listen loop
            while True:
                try:
                    header = s.recv(4)
                    if not header or len(header) < 4:
                        _log("listen_bus: recv empty/broken header, breaking")
                        break
                    length = struct.unpack(">I", header)[0]
                    data = b""
                    while len(data) < length:
                        chunk = s.recv(length - len(data))
                        if not chunk:
                            break
                        data += chunk
                    msg = json.loads(data.decode())
                    # Process message: print/context/command via notify rules
                    _process_bus_message(msg)
                except socket.timeout:
                    continue
                except (ConnectionResetError, BrokenPipeError):
                    _log("listen_bus: ConnectionReset/BrokenPipe, breaking")
                    break

        except (socket.timeout, ConnectionRefusedError, FileNotFoundError, OSError) as e:
            _log(f"listen_bus: outer connect error: {type(e).__name__}: {e}")
        except Exception as e:
            _log(f"listen_bus: outer unknown error: {type(e).__name__}: {e}")
        finally:
            try:
                s.close()
            except Exception:
                pass

        reconnect_count += 1
        _log(f"listen_bus: disconnect #{reconnect_count}, was_connected={was_connected}")
        if was_connected:
            _banner_print(f"Disconnected — reconnecting in {reconnect_delay}s...")
        time.sleep(reconnect_delay)
