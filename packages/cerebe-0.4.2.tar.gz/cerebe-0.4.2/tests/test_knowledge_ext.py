"""Tests for knowledge resource extensions (artifacts)."""

from __future__ import annotations

import json

import pytest

from cerebe import AsyncCerebe, Cerebe

# ── artifacts ──────────────────────────────────────────────────────


class TestKnowledgeArtifacts:
    def test_sends_correct_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"status": "ok"}, "meta": {}})
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        client.knowledge.artifacts("assessment", "assess_123", student_id="stu_1")
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/knowledge/artifacts"
        assert req.method == "POST"
        data = json.loads(req.read())
        assert data["artifact_type"] == "assessment"
        assert data["artifact_id"] == "assess_123"
        assert data["student_id"] == "stu_1"

    def test_sends_only_required_fields(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"status": "ok"}, "meta": {}})
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        client.knowledge.artifacts("lesson", "les_456")
        req = httpx_mock.get_request()
        data = json.loads(req.read())
        assert data["artifact_type"] == "lesson"
        assert data["artifact_id"] == "les_456"
        assert "student_id" not in data
        assert "metadata" not in data
        assert "source" not in data

    def test_sends_all_optional_fields(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"status": "ok"}, "meta": {}})
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        client.knowledge.artifacts(
            "quiz",
            "quiz_789",
            student_id="stu_2",
            metadata={"difficulty": "hard"},
            source="curriculum",
        )
        req = httpx_mock.get_request()
        data = json.loads(req.read())
        assert data["artifact_type"] == "quiz"
        assert data["student_id"] == "stu_2"
        assert data["metadata"] == {"difficulty": "hard"}
        assert data["source"] == "curriculum"


@pytest.mark.anyio
class TestAsyncKnowledgeArtifacts:
    async def test_sends_correct_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"status": "ok"}, "meta": {}})
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            await client.knowledge.artifacts("assessment", "assess_123", student_id="stu_1")
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/knowledge/artifacts"
        assert req.method == "POST"
        data = json.loads(req.read())
        assert data["artifact_type"] == "assessment"
        assert data["student_id"] == "stu_1"
