"""Tests for Prompt and PromptChangeRequest resources — sync + async."""

from __future__ import annotations

import json

import pytest

from cerebe import AsyncCerebe, Cerebe
from cerebe.resources.prompts import (
    AsyncPromptChangeRequestResource,
    AsyncPromptResource,
    PromptChangeRequestResource,
    PromptResource,
)

_OK = {"data": {}, "meta": {}}


# ── PromptResource — sync ──────────────────────────────────────────


class TestPromptList:
    def test_sends_request(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        prompts = PromptResource(client)
        prompts.list()
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompts/"
        assert req.method == "GET"

    def test_with_tags(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        prompts = PromptResource(client)
        prompts.list(tags=["math", "science"])
        req = httpx_mock.get_request()
        assert "tags=math%2Cscience" in str(req.url) or "tags=math,science" in str(
            req.url
        )

    def test_no_tags_omits_param(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        prompts = PromptResource(client)
        prompts.list()
        req = httpx_mock.get_request()
        assert "tags" not in str(req.url)


class TestPromptGet:
    def test_sends_request(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        prompts = PromptResource(client)
        prompts.get("greeting")
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompts/greeting"
        assert req.method == "GET"

    def test_with_tags(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        prompts = PromptResource(client)
        prompts.get("greeting", tags=["prod"])
        req = httpx_mock.get_request()
        assert "tags=prod" in str(req.url)


class TestPromptRender:
    def test_sends_correct_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        prompts = PromptResource(client)
        prompts.render("greeting", {"name": "World"})
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompts/greeting/render"
        assert req.method == "POST"
        data = json.loads(req.read())
        assert data["variables"] == {"name": "World"}

    def test_with_optional_fields(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        prompts = PromptResource(client)
        prompts.render(
            "greeting",
            {"name": "World"},
            version="2.0",
            tags=["math"],
            evaluate=True,
            actor="admin",
        )
        req = httpx_mock.get_request()
        data = json.loads(req.read())
        assert data["version"] == "2.0"
        assert data["tags"] == ["math"]
        assert data["evaluate"] is True
        assert data["actor"] == "admin"

    def test_omits_none_optional_fields(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        prompts = PromptResource(client)
        prompts.render("greeting", {"name": "World"})
        req = httpx_mock.get_request()
        data = json.loads(req.read())
        assert "version" not in data
        assert "tags" not in data
        assert "evaluate" not in data
        assert "actor" not in data


class TestPromptEvaluate:
    def test_sends_request(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        prompts = PromptResource(client)
        prompts.evaluate("greeting", version="1.0", dataset_path="/data/eval.json")
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompts/greeting/evaluate"
        assert req.method == "POST"
        data = json.loads(req.read())
        assert data["version"] == "1.0"
        assert data["dataset_path"] == "/data/eval.json"

    def test_no_body_when_no_params(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        prompts = PromptResource(client)
        prompts.evaluate("greeting")
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompts/greeting/evaluate"


class TestPromptDelete:
    def test_sends_request(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        prompts = PromptResource(client)
        prompts.delete("greeting")
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompts/greeting"
        assert req.method == "DELETE"

    def test_with_tags(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        prompts = PromptResource(client)
        prompts.delete("greeting", tags=["deprecated"])
        req = httpx_mock.get_request()
        assert "tags=deprecated" in str(req.url)


class TestPromptCreateVersion:
    def test_sends_request(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        prompts = PromptResource(client)
        prompts.create_version(
            "greeting",
            system_prompt="You are helpful.",
            user_prompt="Hello {name}",
            version="2.0",
            tags=["math"],
            metadata={"author": "admin"},
            placeholders=["name"],
            status="draft",
            actor="admin",
        )
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompts/greeting/versions"
        assert req.method == "POST"
        data = json.loads(req.read())
        assert data["system_prompt"] == "You are helpful."
        assert data["user_prompt"] == "Hello {name}"
        assert data["version"] == "2.0"
        assert data["tags"] == ["math"]
        assert data["metadata"] == {"author": "admin"}
        assert data["placeholders"] == ["name"]
        assert data["status"] == "draft"
        assert data["actor"] == "admin"


class TestPromptListVersions:
    def test_sends_request(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        prompts = PromptResource(client)
        prompts.list_versions("greeting")
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompts/greeting/versions"
        assert req.method == "GET"

    def test_with_tags(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        prompts = PromptResource(client)
        prompts.list_versions("greeting", tags=["v2"])
        req = httpx_mock.get_request()
        assert "tags=v2" in str(req.url)


class TestPromptPromote:
    def test_sends_request(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        prompts = PromptResource(client)
        prompts.promote("greeting", version="2.0")
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompts/greeting/promote"
        assert req.method == "POST"
        data = json.loads(req.read())
        assert data["version"] == "2.0"

    def test_with_actor(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        prompts = PromptResource(client)
        prompts.promote("greeting", version="2.0", actor="admin")
        req = httpx_mock.get_request()
        data = json.loads(req.read())
        assert data["actor"] == "admin"


class TestPromptUpdateMetadata:
    def test_sends_request(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        prompts = PromptResource(client)
        prompts.update_metadata(
            "greeting", "2.0", metadata={"reviewed": True}, status="active", actor="admin"
        )
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompts/greeting/versions/2.0"
        assert req.method == "PATCH"
        data = json.loads(req.read())
        assert data["metadata"] == {"reviewed": True}
        assert data["status"] == "active"
        assert data["actor"] == "admin"


class TestPromptBulkUpsert:
    def test_sends_list_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        prompts = PromptResource(client)
        payload = [
            {"name": "greeting", "system_prompt": "Hello"},
            {"name": "farewell", "system_prompt": "Bye"},
        ]
        prompts.bulk_upsert(payload)
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompts/bulk-upsert"
        assert req.method == "POST"
        data = json.loads(req.read())
        assert len(data) == 2
        assert data[0]["name"] == "greeting"


# ── PromptChangeRequestResource — sync ─────────────────────────────


class TestChangeRequestList:
    def test_sends_request(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        cr = PromptChangeRequestResource(client)
        cr.list()
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompt-change-requests/"
        assert req.method == "GET"

    def test_with_filters(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        cr = PromptChangeRequestResource(client)
        cr.list(status="pending", prompt_name="greeting", environment="prod")
        req = httpx_mock.get_request()
        assert "status=pending" in str(req.url)
        assert "prompt_name=greeting" in str(req.url)
        assert "environment=prod" in str(req.url)

    def test_no_filters_omits_params(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        cr = PromptChangeRequestResource(client)
        cr.list()
        req = httpx_mock.get_request()
        assert "status" not in str(req.url)
        assert "prompt_name" not in str(req.url)


class TestChangeRequestCreate:
    def test_sends_correct_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        cr = PromptChangeRequestResource(client)
        cr.create(
            "greeting",
            system_prompt="You are helpful.",
            user_prompt="Hello {name}",
            version="2.0",
            environment="staging",
            actor="admin",
            metadata={"reason": "update"},
            placeholders=["name"],
            dataset_path="/data/eval.json",
        )
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompt-change-requests/"
        assert req.method == "POST"
        data = json.loads(req.read())
        assert data["prompt_name"] == "greeting"
        assert data["system_prompt"] == "You are helpful."
        assert data["version"] == "2.0"
        assert data["environment"] == "staging"
        assert data["dataset_path"] == "/data/eval.json"

    def test_minimal_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        cr = PromptChangeRequestResource(client)
        cr.create("greeting", "You are helpful.", "Hello {name}", "1.0")
        req = httpx_mock.get_request()
        data = json.loads(req.read())
        assert data["prompt_name"] == "greeting"
        assert data["system_prompt"] == "You are helpful."
        assert data["user_prompt"] == "Hello {name}"
        assert data["version"] == "1.0"
        assert "environment" not in data


class TestChangeRequestGet:
    def test_sends_request(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        cr = PromptChangeRequestResource(client)
        cr.get("cr_123")
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompt-change-requests/cr_123"
        assert req.method == "GET"


class TestChangeRequestSubmit:
    def test_sends_request(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        cr = PromptChangeRequestResource(client)
        cr.submit("cr_123", actor="admin", assigned_reviewer="reviewer_1", auto_evaluate=True)
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompt-change-requests/cr_123/submit"
        assert req.method == "POST"
        data = json.loads(req.read())
        assert data["actor"] == "admin"
        assert data["assigned_reviewer"] == "reviewer_1"
        assert data["auto_evaluate"] is True

    def test_no_body_when_no_params(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        cr = PromptChangeRequestResource(client)
        cr.submit("cr_123")
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompt-change-requests/cr_123/submit"


class TestChangeRequestEvaluate:
    def test_sends_request(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        cr = PromptChangeRequestResource(client)
        cr.evaluate("cr_123", actor="admin")
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompt-change-requests/cr_123/evaluate"
        assert req.method == "POST"
        data = json.loads(req.read())
        assert data["actor"] == "admin"


class TestChangeRequestApprove:
    def test_sends_request(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        cr = PromptChangeRequestResource(client)
        cr.approve("cr_123", actor="admin")
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompt-change-requests/cr_123/approve"
        assert req.method == "POST"
        data = json.loads(req.read())
        assert data["actor"] == "admin"


class TestChangeRequestReject:
    def test_sends_request(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        cr = PromptChangeRequestResource(client)
        cr.reject("cr_123", actor="admin", notes="Needs revision")
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompt-change-requests/cr_123/reject"
        assert req.method == "POST"
        data = json.loads(req.read())
        assert data["actor"] == "admin"
        assert data["notes"] == "Needs revision"

    def test_no_body_when_no_params(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        cr = PromptChangeRequestResource(client)
        cr.reject("cr_123")
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompt-change-requests/cr_123/reject"


class TestChangeRequestCancel:
    def test_sends_request(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        cr = PromptChangeRequestResource(client)
        cr.cancel("cr_123", actor="admin")
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompt-change-requests/cr_123/cancel"
        assert req.method == "POST"
        data = json.loads(req.read())
        assert data["actor"] == "admin"


# ── Sub-resource wiring ────────────────────────────────────────────


class TestPromptSubResource:
    def test_change_requests_accessible_via_prompts(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        prompts = PromptResource(client)
        prompts.change_requests.list()
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompt-change-requests/"


# ── AsyncPromptResource ───────────────────────────────────────────


@pytest.mark.anyio
class TestAsyncPromptList:
    async def test_sends_request(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            prompts = AsyncPromptResource(client)
            await prompts.list()
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompts/"
        assert req.method == "GET"

    async def test_with_tags(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            prompts = AsyncPromptResource(client)
            await prompts.list(tags=["math", "science"])
        req = httpx_mock.get_request()
        assert "tags=math%2Cscience" in str(req.url) or "tags=math,science" in str(
            req.url
        )


@pytest.mark.anyio
class TestAsyncPromptGet:
    async def test_sends_request(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            prompts = AsyncPromptResource(client)
            await prompts.get("greeting")
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompts/greeting"


@pytest.mark.anyio
class TestAsyncPromptRender:
    async def test_sends_correct_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            prompts = AsyncPromptResource(client)
            await prompts.render("greeting", {"name": "World"})
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompts/greeting/render"
        data = json.loads(req.read())
        assert data["variables"] == {"name": "World"}

    async def test_with_optional_fields(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            prompts = AsyncPromptResource(client)
            await prompts.render(
                "greeting",
                {"name": "World"},
                version="2.0",
                tags=["math"],
                evaluate=True,
                actor="admin",
            )
        req = httpx_mock.get_request()
        data = json.loads(req.read())
        assert data["version"] == "2.0"
        assert data["evaluate"] is True


@pytest.mark.anyio
class TestAsyncPromptEvaluate:
    async def test_sends_request(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            prompts = AsyncPromptResource(client)
            await prompts.evaluate("greeting", version="1.0")
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompts/greeting/evaluate"
        data = json.loads(req.read())
        assert data["version"] == "1.0"


@pytest.mark.anyio
class TestAsyncPromptDelete:
    async def test_sends_request(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            prompts = AsyncPromptResource(client)
            await prompts.delete("greeting")
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompts/greeting"
        assert req.method == "DELETE"


@pytest.mark.anyio
class TestAsyncPromptCreateVersion:
    async def test_sends_request(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            prompts = AsyncPromptResource(client)
            await prompts.create_version(
                "greeting",
                system_prompt="You are helpful.",
                version="2.0",
                tags=["math"],
            )
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompts/greeting/versions"
        data = json.loads(req.read())
        assert data["system_prompt"] == "You are helpful."
        assert data["version"] == "2.0"


@pytest.mark.anyio
class TestAsyncPromptListVersions:
    async def test_sends_request(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            prompts = AsyncPromptResource(client)
            await prompts.list_versions("greeting")
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompts/greeting/versions"
        assert req.method == "GET"


@pytest.mark.anyio
class TestAsyncPromptPromote:
    async def test_sends_request(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            prompts = AsyncPromptResource(client)
            await prompts.promote("greeting", version="2.0", actor="admin")
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompts/greeting/promote"
        data = json.loads(req.read())
        assert data["version"] == "2.0"
        assert data["actor"] == "admin"


@pytest.mark.anyio
class TestAsyncPromptUpdateMetadata:
    async def test_sends_request(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            prompts = AsyncPromptResource(client)
            await prompts.update_metadata(
                "greeting", "2.0", metadata={"reviewed": True}, status="active"
            )
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompts/greeting/versions/2.0"
        assert req.method == "PATCH"
        data = json.loads(req.read())
        assert data["metadata"] == {"reviewed": True}
        assert data["status"] == "active"


@pytest.mark.anyio
class TestAsyncPromptBulkUpsert:
    async def test_sends_list_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            prompts = AsyncPromptResource(client)
            payload = [{"name": "greeting", "system_prompt": "Hello"}]
            await prompts.bulk_upsert(payload)
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompts/bulk-upsert"
        data = json.loads(req.read())
        assert len(data) == 1


# ── AsyncPromptChangeRequestResource ──────────────────────────────


@pytest.mark.anyio
class TestAsyncChangeRequestList:
    async def test_sends_request(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            cr = AsyncPromptChangeRequestResource(client)
            await cr.list()
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompt-change-requests/"
        assert req.method == "GET"

    async def test_with_filters(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            cr = AsyncPromptChangeRequestResource(client)
            await cr.list(status="pending", prompt_name="greeting")
        req = httpx_mock.get_request()
        assert "status=pending" in str(req.url)
        assert "prompt_name=greeting" in str(req.url)


@pytest.mark.anyio
class TestAsyncChangeRequestCreate:
    async def test_sends_correct_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            cr = AsyncPromptChangeRequestResource(client)
            await cr.create("greeting", "You are helpful.", "Hello {name}", "1.0", actor="admin")
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompt-change-requests/"
        data = json.loads(req.read())
        assert data["prompt_name"] == "greeting"
        assert data["system_prompt"] == "You are helpful."
        assert data["actor"] == "admin"


@pytest.mark.anyio
class TestAsyncChangeRequestGet:
    async def test_sends_request(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            cr = AsyncPromptChangeRequestResource(client)
            await cr.get("cr_123")
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompt-change-requests/cr_123"
        assert req.method == "GET"


@pytest.mark.anyio
class TestAsyncChangeRequestSubmit:
    async def test_sends_request(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            cr = AsyncPromptChangeRequestResource(client)
            await cr.submit("cr_123", actor="admin", auto_evaluate=True)
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompt-change-requests/cr_123/submit"
        data = json.loads(req.read())
        assert data["actor"] == "admin"
        assert data["auto_evaluate"] is True


@pytest.mark.anyio
class TestAsyncChangeRequestEvaluate:
    async def test_sends_request(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            cr = AsyncPromptChangeRequestResource(client)
            await cr.evaluate("cr_123", actor="admin")
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompt-change-requests/cr_123/evaluate"
        data = json.loads(req.read())
        assert data["actor"] == "admin"


@pytest.mark.anyio
class TestAsyncChangeRequestApprove:
    async def test_sends_request(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            cr = AsyncPromptChangeRequestResource(client)
            await cr.approve("cr_123", actor="admin")
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompt-change-requests/cr_123/approve"
        data = json.loads(req.read())
        assert data["actor"] == "admin"


@pytest.mark.anyio
class TestAsyncChangeRequestReject:
    async def test_sends_request(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            cr = AsyncPromptChangeRequestResource(client)
            await cr.reject("cr_123", actor="admin", notes="Needs revision")
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompt-change-requests/cr_123/reject"
        data = json.loads(req.read())
        assert data["notes"] == "Needs revision"


@pytest.mark.anyio
class TestAsyncChangeRequestCancel:
    async def test_sends_request(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            cr = AsyncPromptChangeRequestResource(client)
            await cr.cancel("cr_123", actor="admin")
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompt-change-requests/cr_123/cancel"
        data = json.loads(req.read())
        assert data["actor"] == "admin"


@pytest.mark.anyio
class TestAsyncPromptSubResource:
    async def test_change_requests_accessible_via_prompts(self, httpx_mock) -> None:
        httpx_mock.add_response(json=_OK)
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            prompts = AsyncPromptResource(client)
            await prompts.change_requests.list()
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/prompt-change-requests/"
