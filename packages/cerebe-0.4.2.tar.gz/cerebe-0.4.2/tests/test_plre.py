"""Tests for the plre resource."""

from __future__ import annotations

import json

import pytest

from cerebe import AsyncCerebe, Cerebe
from cerebe.resources.plre import AsyncPLREResource, PLREResource

# ── Sync: patterns ─────────────────────────────────────────────────


class TestPLREPatterns:
    def test_sends_correct_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"patterns": []}, "meta": {}})
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        resource = PLREResource(client)
        resource.patterns("entity_1")
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/plre/patterns"
        assert req.method == "POST"
        data = json.loads(req.read())
        assert data["entity_id"] == "entity_1"
        assert "lookback_days" not in data

    def test_with_lookback_days(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"patterns": []}, "meta": {}})
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        resource = PLREResource(client)
        resource.patterns("entity_1", lookback_days=30)
        req = httpx_mock.get_request()
        data = json.loads(req.read())
        assert data["lookback_days"] == 30


# ── Sync: store_event ──────────────────────────────────────────────


class TestPLREStoreEvent:
    def test_sends_correct_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"event_id": "evt_1"}, "meta": {}})
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        resource = PLREResource(client)
        resource.store_event(
            "entity_1",
            "quiz_completed",
            {"score": 85},
            {"accuracy": 0.85, "time_spent": 120},
        )
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/plre/events"
        assert req.method == "POST"
        data = json.loads(req.read())
        assert data["entity_id"] == "entity_1"
        assert data["event_type"] == "quiz_completed"
        assert data["content"] == {"score": 85}
        assert data["assessment"]["accuracy"] == 0.85
        assert "trace_id" not in data

    def test_with_trace_id(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {}, "meta": {}})
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        resource = PLREResource(client)
        resource.store_event("e_1", "test", "content", {}, trace_id="trace_abc")
        req = httpx_mock.get_request()
        data = json.loads(req.read())
        assert data["trace_id"] == "trace_abc"


# ── Sync: gaps ─────────────────────────────────────────────────────


class TestPLREGaps:
    def test_sends_correct_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"gaps": []}, "meta": {}})
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        resource = PLREResource(client)
        assessment = {"score": 70, "topic": "algebra"}
        patterns = [{"pattern": "declining", "subject": "math"}]
        resource.gaps("entity_1", assessment, patterns)
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/plre/gaps"
        assert req.method == "POST"
        data = json.loads(req.read())
        assert data["entity_id"] == "entity_1"
        assert data["current_assessment"] == assessment
        assert data["historical_patterns"] == patterns


# ── Async: patterns ────────────────────────────────────────────────


@pytest.mark.anyio
class TestAsyncPLREPatterns:
    async def test_sends_correct_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"patterns": []}, "meta": {}})
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            resource = AsyncPLREResource(client)
            await resource.patterns("entity_1")
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/plre/patterns"
        data = json.loads(req.read())
        assert data["entity_id"] == "entity_1"

    async def test_with_lookback_days(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {}, "meta": {}})
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            resource = AsyncPLREResource(client)
            await resource.patterns("entity_1", lookback_days=7)
        req = httpx_mock.get_request()
        data = json.loads(req.read())
        assert data["lookback_days"] == 7


# ── Async: store_event ─────────────────────────────────────────────


@pytest.mark.anyio
class TestAsyncPLREStoreEvent:
    async def test_sends_correct_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"event_id": "evt_1"}, "meta": {}})
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            resource = AsyncPLREResource(client)
            await resource.store_event(
                "entity_1", "quiz_completed", {"score": 85}, {"accuracy": 0.85}
            )
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/plre/events"
        data = json.loads(req.read())
        assert data["entity_id"] == "entity_1"
        assert data["event_type"] == "quiz_completed"


# ── Async: gaps ────────────────────────────────────────────────────


@pytest.mark.anyio
class TestAsyncPLREGaps:
    async def test_sends_correct_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"gaps": []}, "meta": {}})
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            resource = AsyncPLREResource(client)
            await resource.gaps("entity_1", {"score": 70}, [{"pattern": "declining"}])
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/plre/gaps"
        data = json.loads(req.read())
        assert data["entity_id"] == "entity_1"
        assert data["current_assessment"] == {"score": 70}
        assert data["historical_patterns"] == [{"pattern": "declining"}]
