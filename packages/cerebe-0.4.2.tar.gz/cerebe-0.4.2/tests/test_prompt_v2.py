"""Tests for the prompt_v2 resource."""

from __future__ import annotations

import json

import pytest

from cerebe import AsyncCerebe, Cerebe
from cerebe.resources.prompt_v2 import AsyncPromptV2Resource, PromptV2Resource

# ── Sync: enrich ───────────────────────────────────────────────────


class TestPromptV2Enrich:
    def test_sends_correct_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"enriched_prompt": "..."}, "meta": {}})
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        resource = PromptV2Resource(client)
        resource.enrich("sess_1", "Help with math", {"domain": "math"})
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v2/prompt/enrich"
        assert req.method == "POST"
        data = json.loads(req.read())
        assert data["session_id"] == "sess_1"
        assert data["prompt"] == "Help with math"
        assert data["domain_context"] == {"domain": "math"}
        assert "options" not in data

    def test_with_options(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {}, "meta": {}})
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        resource = PromptV2Resource(client)
        resource.enrich("sess_1", "test", {}, options={"verbose": True})
        req = httpx_mock.get_request()
        data = json.loads(req.read())
        assert data["options"] == {"verbose": True}


# ── Sync: enrich_assessment ────────────────────────────────────────


class TestPromptV2EnrichAssessment:
    def test_sends_correct_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"enriched_prompt": "..."}, "meta": {}})
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        resource = PromptV2Resource(client)
        resource.enrich_assessment("sess_2", "Quiz me", {"subject": "science"})
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v2/prompt/enrich-assessment"
        assert req.method == "POST"
        data = json.loads(req.read())
        assert data["session_id"] == "sess_2"
        assert data["prompt"] == "Quiz me"
        assert data["domain_context"] == {"subject": "science"}

    def test_with_options(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {}, "meta": {}})
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        resource = PromptV2Resource(client)
        resource.enrich_assessment("sess_2", "Quiz", {}, options={"difficulty": "hard"})
        req = httpx_mock.get_request()
        data = json.loads(req.read())
        assert data["options"] == {"difficulty": "hard"}


# ── Sync: health ───────────────────────────────────────────────────


class TestPromptV2Health:
    def test_calls_correct_endpoint(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"status": "ok"}, "meta": {}})
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        resource = PromptV2Resource(client)
        resource.health()
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v2/prompt/health"
        assert req.method == "GET"


# ── Async: enrich ──────────────────────────────────────────────────


@pytest.mark.anyio
class TestAsyncPromptV2Enrich:
    async def test_sends_correct_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"enriched_prompt": "..."}, "meta": {}})
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            resource = AsyncPromptV2Resource(client)
            await resource.enrich("sess_1", "Help with math", {"domain": "math"})
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v2/prompt/enrich"
        data = json.loads(req.read())
        assert data["session_id"] == "sess_1"
        assert data["prompt"] == "Help with math"

    async def test_with_options(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {}, "meta": {}})
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            resource = AsyncPromptV2Resource(client)
            await resource.enrich("sess_1", "test", {}, options={"verbose": True})
        req = httpx_mock.get_request()
        data = json.loads(req.read())
        assert data["options"] == {"verbose": True}


# ── Async: enrich_assessment ───────────────────────────────────────


@pytest.mark.anyio
class TestAsyncPromptV2EnrichAssessment:
    async def test_sends_correct_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"enriched_prompt": "..."}, "meta": {}})
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            resource = AsyncPromptV2Resource(client)
            await resource.enrich_assessment("sess_2", "Quiz me", {"subject": "science"})
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v2/prompt/enrich-assessment"
        data = json.loads(req.read())
        assert data["session_id"] == "sess_2"


# ── Async: health ──────────────────────────────────────────────────


@pytest.mark.anyio
class TestAsyncPromptV2Health:
    async def test_calls_correct_endpoint(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"status": "ok"}, "meta": {}})
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            resource = AsyncPromptV2Resource(client)
            await resource.health()
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v2/prompt/health"
        assert req.method == "GET"
