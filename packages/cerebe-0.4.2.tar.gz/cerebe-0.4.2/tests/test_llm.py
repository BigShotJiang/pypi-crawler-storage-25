"""Tests for the llm resource."""

from __future__ import annotations

import json

import pytest

from cerebe import AsyncCerebe, Cerebe
from cerebe.resources.llm import AsyncLLMResource, LLMResource

# ── Sync: chat ─────────────────────────────────────────────────────


class TestLLMChat:
    def test_sends_correct_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"response": "Hello!"}, "meta": {}})
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        resource = LLMResource(client)
        messages = [{"role": "user", "content": "Hi"}]
        resource.chat(messages)
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/llm/v1/chat"
        assert req.method == "POST"
        data = json.loads(req.read())
        assert data["messages"] == messages
        assert "capability" not in data
        assert "delivery_mode" not in data

    def test_with_all_options(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {}, "meta": {}})
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        resource = LLMResource(client)
        resource.chat(
            [{"role": "user", "content": "Hi"}],
            capability="reasoning",
            delivery_mode="streaming",
            temperature=0.7,
            max_tokens=1024,
        )
        req = httpx_mock.get_request()
        data = json.loads(req.read())
        assert data["capability"] == "reasoning"
        assert data["delivery_mode"] == "streaming"
        assert data["temperature"] == 0.7
        assert data["max_tokens"] == 1024

    def test_with_partial_options(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {}, "meta": {}})
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        resource = LLMResource(client)
        resource.chat([{"role": "user", "content": "Hi"}], temperature=0.0)
        req = httpx_mock.get_request()
        data = json.loads(req.read())
        assert data["temperature"] == 0.0
        assert "capability" not in data
        assert "max_tokens" not in data


# ── Async: chat ────────────────────────────────────────────────────


@pytest.mark.anyio
class TestAsyncLLMChat:
    async def test_sends_correct_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"response": "Hello!"}, "meta": {}})
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            resource = AsyncLLMResource(client)
            messages = [{"role": "user", "content": "Hi"}]
            await resource.chat(messages)
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/llm/v1/chat"
        data = json.loads(req.read())
        assert data["messages"] == messages

    async def test_with_all_options(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {}, "meta": {}})
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            resource = AsyncLLMResource(client)
            await resource.chat(
                [{"role": "user", "content": "Hi"}],
                capability="vision",
                delivery_mode="non_streaming",
                temperature=0.7,
                max_tokens=1024,
            )
        req = httpx_mock.get_request()
        data = json.loads(req.read())
        assert data["capability"] == "vision"
        assert data["delivery_mode"] == "non_streaming"
        assert data["temperature"] == 0.7
        assert data["max_tokens"] == 1024
