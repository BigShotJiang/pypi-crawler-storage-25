"""Tests for the working_memory resource."""

from __future__ import annotations

import json

import pytest

from cerebe import AsyncCerebe, Cerebe
from cerebe.resources.working_memory import AsyncWorkingMemoryResource, WorkingMemoryResource

# ── Sync: store ────────────────────────────────────────────────────


class TestWorkingMemoryStore:
    def test_sends_correct_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"id": "wm_1"}, "meta": {}})
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        resource = WorkingMemoryResource(client)
        resource.store("entity_1", "current task context")
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/memory/working"
        assert req.method == "POST"
        data = json.loads(req.read())
        assert data["entity_id"] == "entity_1"
        assert data["content"] == "current task context"
        assert "ttl_seconds" not in data
        assert "scope" not in data
        assert "importance" not in data

    def test_with_all_options(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {}, "meta": {}})
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        resource = WorkingMemoryResource(client)
        resource.store("entity_1", "context", ttl_seconds=3600, scope="task", importance=0.9)
        req = httpx_mock.get_request()
        data = json.loads(req.read())
        assert data["ttl_seconds"] == 3600
        assert data["scope"] == "task"
        assert data["importance"] == 0.9


# ── Sync: get ──────────────────────────────────────────────────────


class TestWorkingMemoryGet:
    def test_sends_correct_params(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"memories": []}, "meta": {}})
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        resource = WorkingMemoryResource(client)
        resource.get("entity_1")
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/memory/working"
        assert req.method == "GET"
        assert "entity_id=entity_1" in str(req.url)

    def test_no_extra_params(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"memories": []}, "meta": {}})
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        resource = WorkingMemoryResource(client)
        resource.get("entity_1")
        req = httpx_mock.get_request()
        assert "entity_id=entity_1" in str(req.url)
        assert "scope" not in str(req.url)


# ── Sync: sweep ────────────────────────────────────────────────────


class TestWorkingMemorySweep:
    def test_calls_correct_endpoint(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"swept_count": 5}, "meta": {}})
        client = Cerebe(api_key="ck_test_xxx", max_retries=0)
        resource = WorkingMemoryResource(client)
        resource.sweep()
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/memory/working/sweep"
        assert req.method == "POST"


# ── Async: store ───────────────────────────────────────────────────


@pytest.mark.anyio
class TestAsyncWorkingMemoryStore:
    async def test_sends_correct_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"id": "wm_1"}, "meta": {}})
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            resource = AsyncWorkingMemoryResource(client)
            await resource.store("entity_1", "current task context")
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/memory/working"
        data = json.loads(req.read())
        assert data["entity_id"] == "entity_1"
        assert data["content"] == "current task context"

    async def test_with_all_options(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {}, "meta": {}})
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            resource = AsyncWorkingMemoryResource(client)
            await resource.store("entity_1", "ctx", ttl_seconds=60, scope="session", importance=0.5)
        req = httpx_mock.get_request()
        data = json.loads(req.read())
        assert data["ttl_seconds"] == 60
        assert data["scope"] == "session"
        assert data["importance"] == 0.5


# ── Async: get ─────────────────────────────────────────────────────


@pytest.mark.anyio
class TestAsyncWorkingMemoryGet:
    async def test_sends_correct_params(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"memories": []}, "meta": {}})
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            resource = AsyncWorkingMemoryResource(client)
            await resource.get("entity_1")
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/memory/working"
        assert req.method == "GET"
        assert "entity_id=entity_1" in str(req.url)

    async def test_no_extra_params(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {}, "meta": {}})
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            resource = AsyncWorkingMemoryResource(client)
            await resource.get("entity_1")
        req = httpx_mock.get_request()
        assert "entity_id=entity_1" in str(req.url)
        assert "scope" not in str(req.url)


# ── Async: sweep ───────────────────────────────────────────────────


@pytest.mark.anyio
class TestAsyncWorkingMemorySweep:
    async def test_calls_correct_endpoint(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"swept_count": 5}, "meta": {}})
        async with AsyncCerebe(api_key="ck_test_xxx", max_retries=0) as client:
            resource = AsyncWorkingMemoryResource(client)
            await resource.sweep()
        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/memory/working/sweep"
        assert req.method == "POST"
