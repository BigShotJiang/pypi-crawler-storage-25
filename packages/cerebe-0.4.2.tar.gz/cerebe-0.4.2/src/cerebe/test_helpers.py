"""Test data lifecycle helpers — reset, seed, and fixtures.

Only available with test/dev API keys.

Usage:
    client = Cerebe(api_key="ck_test_xxx")
    client.test.seed(fixture="basic")
    # ... run tests ...
    client.test.reset()
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, cast

if TYPE_CHECKING:
    from ._client import AsyncCerebe, Cerebe


@dataclass
class ResetResult:
    status: str
    deleted_count: int
    collection: str


@dataclass
class SeedResult:
    status: str
    fixture: str
    created_count: int
    collection: str


class TestHelpers:
    """Sync test data lifecycle helpers."""

    def __init__(self, client: Cerebe) -> None:
        self._client = client

    def reset(self, confirm: bool = True) -> ResetResult:
        """Wipe all test data for the authenticated org."""
        resp = self._client.request("POST", "/api/v1/test/reset", json={"confirm": confirm})
        return ResetResult(**resp.data)

    def seed(self, fixture: str = "basic", entity_id: str | None = None) -> SeedResult:
        """Seed test data from a fixture set."""
        payload: dict[str, Any] = {"fixture": fixture}
        if entity_id:
            payload["entity_id"] = entity_id
        resp = self._client.request("POST", "/api/v1/test/seed", json=payload)
        return SeedResult(**resp.data)

    def list_fixtures(self) -> dict[str, Any]:
        """List available test fixtures."""
        resp = self._client.request("GET", "/api/v1/test/fixtures")
        return cast(dict[str, Any], resp.data)


class AsyncTestHelpers:
    """Async test data lifecycle helpers."""

    def __init__(self, client: AsyncCerebe) -> None:
        self._client = client

    async def reset(self, confirm: bool = True) -> ResetResult:
        """Wipe all test data for the authenticated org."""
        resp = await self._client.request("POST", "/api/v1/test/reset", json={"confirm": confirm})
        return ResetResult(**resp.data)

    async def seed(self, fixture: str = "basic", entity_id: str | None = None) -> SeedResult:
        """Seed test data from a fixture set."""
        payload: dict[str, Any] = {"fixture": fixture}
        if entity_id:
            payload["entity_id"] = entity_id
        resp = await self._client.request("POST", "/api/v1/test/seed", json=payload)
        return SeedResult(**resp.data)

    async def list_fixtures(self) -> dict[str, Any]:
        """List available test fixtures."""
        resp = await self._client.request("GET", "/api/v1/test/fixtures")
        return cast(dict[str, Any], resp.data)
