"""Cerebe Python SDK — Cognitive Services Platform.

Usage:
    from cerebe import Cerebe, AsyncCerebe

    # Sync client
    client = Cerebe(api_key="ck_live_xxx", project="proj_xxx")
    results = client.memory.search(query="user preferences", session_id="sess_123")

    # Async client
    async with AsyncCerebe(api_key="ck_live_xxx") as client:
        results = await client.memory.search(query="user preferences", session_id="sess_123")
"""

from ._client import AsyncCerebe, Cerebe
from ._config import CerebeConfig
from ._errors import (
    AuthenticationError,
    CerebeError,
    NotFoundError,
    RateLimitError,
    ServerError,
    ValidationError,
)
from ._response import APIResponse
from .resources.memory import MemoryType
from .test_helpers import AsyncTestHelpers, TestHelpers

__all__ = [
    "Cerebe",
    "AsyncCerebe",
    "CerebeConfig",
    "CerebeError",
    "AuthenticationError",
    "RateLimitError",
    "NotFoundError",
    "ValidationError",
    "ServerError",
    "APIResponse",
    "MemoryType",
    "TestHelpers",
    "AsyncTestHelpers",
]

__version__ = "0.4.2"
