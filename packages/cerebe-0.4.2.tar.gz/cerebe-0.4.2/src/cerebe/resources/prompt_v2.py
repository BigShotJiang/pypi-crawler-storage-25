"""Prompt V2 resource for the Cerebe SDK."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from .._response import APIResponse

if TYPE_CHECKING:
    from .._client import AsyncCerebe, Cerebe


class PromptV2Resource:
    """Sync prompt enrichment operations (V2)."""

    def __init__(self, client: Cerebe) -> None:
        self._client = client

    def enrich(
        self,
        session_id: str,
        prompt: str,
        domain_context: dict[str, Any],
        *,
        options: dict[str, Any] | None = None,
    ) -> APIResponse[Any]:
        """Enrich a prompt with cognitive context."""
        body: dict[str, Any] = {
            "session_id": session_id,
            "prompt": prompt,
            "domain_context": domain_context,
        }
        if options:
            body["options"] = options
        return self._client.request("POST", "/api/v2/prompt/enrich", json=body)

    def enrich_assessment(
        self,
        session_id: str,
        prompt: str,
        domain_context: dict[str, Any],
        *,
        options: dict[str, Any] | None = None,
    ) -> APIResponse[Any]:
        """Enrich a prompt for assessment scenarios."""
        body: dict[str, Any] = {
            "session_id": session_id,
            "prompt": prompt,
            "domain_context": domain_context,
        }
        if options:
            body["options"] = options
        return self._client.request("POST", "/api/v2/prompt/enrich-assessment", json=body)

    def health(self) -> APIResponse[Any]:
        """Check prompt V2 service health."""
        return self._client.request("GET", "/api/v2/prompt/health")


class AsyncPromptV2Resource:
    """Async prompt enrichment operations (V2)."""

    def __init__(self, client: AsyncCerebe) -> None:
        self._client = client

    async def enrich(
        self,
        session_id: str,
        prompt: str,
        domain_context: dict[str, Any],
        *,
        options: dict[str, Any] | None = None,
    ) -> APIResponse[Any]:
        """Enrich a prompt with cognitive context."""
        body: dict[str, Any] = {
            "session_id": session_id,
            "prompt": prompt,
            "domain_context": domain_context,
        }
        if options:
            body["options"] = options
        return await self._client.request("POST", "/api/v2/prompt/enrich", json=body)

    async def enrich_assessment(
        self,
        session_id: str,
        prompt: str,
        domain_context: dict[str, Any],
        *,
        options: dict[str, Any] | None = None,
    ) -> APIResponse[Any]:
        """Enrich a prompt for assessment scenarios."""
        body: dict[str, Any] = {
            "session_id": session_id,
            "prompt": prompt,
            "domain_context": domain_context,
        }
        if options:
            body["options"] = options
        return await self._client.request("POST", "/api/v2/prompt/enrich-assessment", json=body)

    async def health(self) -> APIResponse[Any]:
        """Check prompt V2 service health."""
        return await self._client.request("GET", "/api/v2/prompt/health")
