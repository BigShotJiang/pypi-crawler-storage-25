"""Meta-learning resource for the Cerebe SDK."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from .._response import APIResponse

if TYPE_CHECKING:
    from .._client import AsyncCerebe, Cerebe


class MetaLearningResource:
    """Sync meta-learning / PLRE operations."""

    def __init__(self, client: Cerebe) -> None:
        self._client = client

    def analyze(
        self,
        user_id: str,
        *,
        window: str = "7d",
        domains: list[str] | None = None,
    ) -> APIResponse[Any]:
        """Analyze learning patterns for a user."""
        body: dict[str, Any] = {"user_id": user_id, "window": window}
        if domains:
            body["domains"] = domains
        return self._client.request("POST", "/api/v1/meta-learning/analyze", json=body)

    def profile(self, user_id: str) -> APIResponse[Any]:
        """Get comprehensive learner profile."""
        return self._client.request("GET", f"/api/v1/meta-learning/profile/{user_id}")

    def plre_transition(
        self,
        user_id: str,
        session_id: str,
        *,
        target_phase: str | None = None,
        reason: str | None = None,
    ) -> APIResponse[Any]:
        """Trigger a PLRE phase transition."""
        return self._client.request(
            "POST",
            "/api/v1/meta-learning/plre/transition",
            json={
                "user_id": user_id,
                "session_id": session_id,
                "target_phase": target_phase,
                "reason": reason,
            },
        )

    def plre_state(self, user_id: str, *, session_id: str | None = None) -> APIResponse[Any]:
        """Get current PLRE state."""
        params: dict[str, Any] = {"user_id": user_id}
        if session_id:
            params["session_id"] = session_id
        return self._client.request("GET", "/api/v1/meta-learning/plre/state", params=params)


class AsyncMetaLearningResource:
    """Async meta-learning / PLRE operations."""

    def __init__(self, client: AsyncCerebe) -> None:
        self._client = client

    async def analyze(
        self,
        user_id: str,
        *,
        window: str = "7d",
        domains: list[str] | None = None,
    ) -> APIResponse[Any]:
        """Analyze learning patterns for a user."""
        body: dict[str, Any] = {"user_id": user_id, "window": window}
        if domains:
            body["domains"] = domains
        return await self._client.request("POST", "/api/v1/meta-learning/analyze", json=body)

    async def profile(self, user_id: str) -> APIResponse[Any]:
        """Get comprehensive learner profile."""
        return await self._client.request("GET", f"/api/v1/meta-learning/profile/{user_id}")

    async def plre_transition(
        self,
        user_id: str,
        session_id: str,
        *,
        target_phase: str | None = None,
        reason: str | None = None,
    ) -> APIResponse[Any]:
        """Trigger a PLRE phase transition."""
        return await self._client.request(
            "POST",
            "/api/v1/meta-learning/plre/transition",
            json={
                "user_id": user_id,
                "session_id": session_id,
                "target_phase": target_phase,
                "reason": reason,
            },
        )

    async def plre_state(self, user_id: str, *, session_id: str | None = None) -> APIResponse[Any]:
        """Get current PLRE state."""
        params: dict[str, Any] = {"user_id": user_id}
        if session_id:
            params["session_id"] = session_id
        return await self._client.request("GET", "/api/v1/meta-learning/plre/state", params=params)
