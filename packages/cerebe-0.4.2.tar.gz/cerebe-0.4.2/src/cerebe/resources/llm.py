"""LLM resource for the Cerebe SDK."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Literal

from .._response import APIResponse

if TYPE_CHECKING:
    from .._client import AsyncCerebe, Cerebe

Capability = Literal["standard", "vision", "reasoning", "classification", "tax_document"]
DeliveryMode = Literal["non_streaming", "streaming"]


class LLMResource:
    """Sync LLM operations."""

    def __init__(self, client: Cerebe) -> None:
        self._client = client

    def chat(
        self,
        messages: list[dict[str, Any]],
        *,
        capability: Capability | None = None,
        delivery_mode: DeliveryMode | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        metadata: dict[str, Any] | None = None,
        response_format: dict[str, Any] | None = None,
    ) -> APIResponse[Any]:
        """Send a chat completion request."""
        body: dict[str, Any] = {"messages": messages}
        if capability is not None:
            body["capability"] = capability
        if delivery_mode is not None:
            body["delivery_mode"] = delivery_mode
        if temperature is not None:
            body["temperature"] = temperature
        if max_tokens is not None:
            body["max_tokens"] = max_tokens
        if metadata is not None:
            body["metadata"] = metadata
        if response_format is not None:
            body["response_format"] = response_format
        return self._client.request("POST", "/api/v1/llm/v1/chat", json=body)


class AsyncLLMResource:
    """Async LLM operations."""

    def __init__(self, client: AsyncCerebe) -> None:
        self._client = client

    async def chat(
        self,
        messages: list[dict[str, Any]],
        *,
        capability: Capability | None = None,
        delivery_mode: DeliveryMode | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        metadata: dict[str, Any] | None = None,
        response_format: dict[str, Any] | None = None,
    ) -> APIResponse[Any]:
        """Send a chat completion request."""
        body: dict[str, Any] = {"messages": messages}
        if capability is not None:
            body["capability"] = capability
        if delivery_mode is not None:
            body["delivery_mode"] = delivery_mode
        if temperature is not None:
            body["temperature"] = temperature
        if max_tokens is not None:
            body["max_tokens"] = max_tokens
        if metadata is not None:
            body["metadata"] = metadata
        if response_format is not None:
            body["response_format"] = response_format
        return await self._client.request("POST", "/api/v1/llm/v1/chat", json=body)
