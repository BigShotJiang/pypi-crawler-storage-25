"""Error types for the Cerebe SDK."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any


class CerebeError(Exception):
    """Base error for all Cerebe SDK errors."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        code: str | None = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.code = code
        self.request_id = request_id

    def __repr__(self) -> str:
        parts = [f"message={self.message!r}"]
        if self.status_code:
            parts.append(f"status_code={self.status_code}")
        if self.code:
            parts.append(f"code={self.code!r}")
        if self.request_id:
            parts.append(f"request_id={self.request_id!r}")
        return f"{type(self).__name__}({', '.join(parts)})"


class AuthenticationError(CerebeError):
    """Raised when authentication fails (401)."""

    pass


class RateLimitError(CerebeError):
    """Raised when rate limited (429)."""

    def __init__(
        self,
        message: str,
        *,
        retry_after: float | None = None,
        **kwargs: object,
    ) -> None:
        super().__init__(message, status_code=429, **kwargs)  # type: ignore[arg-type]
        self.retry_after = retry_after


class NotFoundError(CerebeError):
    """Raised when a resource is not found (404)."""

    pass


class ValidationError(CerebeError):
    """Raised when request validation fails (400/422)."""

    pass


class ServerError(CerebeError):
    """Raised on server errors (5xx)."""

    pass


def raise_for_status(status_code: int, body: dict[str, Any]) -> None:
    """Raise an appropriate error based on HTTP status code.

    Handles two error response shapes from the Cerebe API:
    - Raw:      ``{"error": "message string", "request_id": "..."}``
    - Envelope: ``{"error": {"message": "...", "code": "...", "request_id": "..."}}``
    """
    if status_code < 400:
        return

    error = body.get("error", {})

    message: str
    code: str | None
    request_id: str | None

    if isinstance(error, str):
        message = error
        code = None
        request_id = body.get("request_id")
    elif isinstance(error, Mapping):
        message = error.get("message", f"HTTP {status_code}")
        code = error.get("code")
        request_id = error.get("request_id") or body.get("request_id")
    else:
        # error is null, list, or unexpected type — fall back gracefully
        message = str(error) if error else f"HTTP {status_code}"
        code = None
        request_id = body.get("request_id")

    if status_code == 401:
        raise AuthenticationError(message, status_code=status_code, code=code, request_id=request_id)
    elif status_code == 404:
        raise NotFoundError(message, status_code=status_code, code=code, request_id=request_id)
    elif status_code == 429:
        raise RateLimitError(message, retry_after=None, status_code=status_code, code=code, request_id=request_id)
    elif status_code in (400, 422):
        raise ValidationError(message, status_code=status_code, code=code, request_id=request_id)
    elif status_code >= 500:
        raise ServerError(message, status_code=status_code, code=code, request_id=request_id)
    else:
        raise CerebeError(message, status_code=status_code, code=code, request_id=request_id)
