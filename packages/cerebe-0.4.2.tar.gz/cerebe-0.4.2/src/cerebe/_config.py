"""Configuration for the Cerebe SDK."""

from __future__ import annotations

import os
from dataclasses import dataclass, field


@dataclass
class CerebeConfig:
    """SDK configuration with env var fallbacks."""

    api_key: str = ""
    project: str = ""
    base_url: str = "https://api.cerebe.ai"
    timeout: float = 30.0
    max_retries: int = 3
    retry_delay: float = 0.5
    headers: dict[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        # Environment variable fallbacks
        if not self.api_key:
            self.api_key = os.environ.get("CEREBE_API_KEY", "")
        if not self.project:
            self.project = os.environ.get("CEREBE_PROJECT", "")
        if self.base_url == "https://api.cerebe.ai":
            self.base_url = os.environ.get("CEREBE_BASE_URL", self.base_url)

        # Strip trailing slash
        self.base_url = self.base_url.rstrip("/")

    def validate(self) -> None:
        """Validate required configuration."""
        if not self.api_key:
            raise ValueError(
                "API key is required. Set CEREBE_API_KEY environment variable "
                "or pass api_key to the client constructor."
            )
