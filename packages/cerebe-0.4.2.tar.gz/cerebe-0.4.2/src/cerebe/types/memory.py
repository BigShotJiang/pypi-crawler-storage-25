"""Memory type definitions."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, Field

MemoryType = Literal[
    "episodic",
    "semantic",
    "procedural",
    "sequential",
    "execution_history",
    "plan",
    "tool_reliability",
    "working",
    "declarative",
]


class Memory(BaseModel):
    """A stored memory."""

    id: str
    session_id: str | None = None
    content: str
    memory_type: MemoryType = "semantic"
    importance: float = 0.5
    similarity_score: float | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)
    embedding_digest: str | None = None


class MemorySearchResult(BaseModel):
    """A single search result with relevance score."""

    memory: Memory
    score: float = 0.0
    source: str | None = None  # "vector", "graph", "bm25"


class MemorySearchResponse(BaseModel):
    """Response from memory search."""

    memories: list[Memory] = Field(default_factory=list)
    total: int = 0
    session_id: str | None = None


class MemoryHarvestResponse(BaseModel):
    """Response from memory harvesting."""

    harvested_memories: list[Memory] = Field(default_factory=list)
    extraction_quality_score: float = 0.0
    processing_time_ms: float = 0.0


class ConsolidateResponse(BaseModel):
    """Response from memory consolidation."""

    consolidated_count: int = 0
    merged_count: int = 0
    status: str = "completed"
