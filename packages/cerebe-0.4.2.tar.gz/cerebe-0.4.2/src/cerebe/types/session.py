"""Session type definitions."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field


class SessionInfo(BaseModel):
    """Session information."""

    session_id: str
    created_at: datetime | None = None
    updated_at: datetime | None = None
    cognitive_state: dict[str, Any] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)
