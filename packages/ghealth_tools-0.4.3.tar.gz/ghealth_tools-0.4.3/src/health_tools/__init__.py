try:
    from health_tools._version import version as __version__
except ImportError:
    __version__ = "0.0.0"
