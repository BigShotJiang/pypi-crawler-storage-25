from unittest import TestCase
from pgturbo import spellcheck, game


class SuggestionTest(TestCase):
    HOOKS = spellcheck.HOOKS + list(game.PGZeroGame.EVENT_HANDLERS.values())

    def assert_suggestions(self, w, candidates, expected):
        suggestions = spellcheck.suggest(w, candidates)
        self.assertEqual(suggestions, expected)

    def assert_best_suggestion(self, w, expected):
        suggestions = spellcheck.suggest(w, self.HOOKS)
        self.assertEqual(suggestions[0], expected)

    def test_distance_zero(self):
        self.assertEqual(
            spellcheck.distance('on_mouse_down', 'on_mouse_down'),
            0
        )

    def test_misspelled(self):
        """With only one suggestion, return it."""
        self.assert_suggestions('drow', ['draw'], ['draw'])

    def test_not_misspelled(self):
        """With only completely different words, there are no candidates."""
        self.assert_suggestions('fire_laser', ['draw', 'update'], [])

    def test_misspelled_on_mouse_down(self):
        self.assert_best_suggestion('onmousedown', 'on_mouse_down')

    def test_misspelled_on_mouse_down2(self):
        self.assert_best_suggestion('onMouseDown', 'on_mouse_down')

    def test_misspelled_on_mouse_down3(self):
        self.assert_best_suggestion('on_muose_Down', 'on_mouse_down')

    def test_misspelled_on_mouse_down4(self):
        self.assert_best_suggestion('on_mouse_don', 'on_mouse_down')


class LoggingSpellCheckResult:
    def __init__(self):
        self.warnings = []
        self.errors = []
        self.bad_handlers = []

    def warn(self, msg, found, suggestion):
        self.warnings.append((found, suggestion))

    def error(self, msg, found, suggestion):
        self.errors.append((found, suggestion))

    def warn_event_handlers(self, typos, missing):
        self.warnings.extend(typos)
        self.bad_handlers.extend(missing)

    def has_error(self, found, suggestion):
        return (found, suggestion) in self.errors

    def has_warning(self, found, suggestion):
        return (found, suggestion) in self.warnings

    def has_bad_handler(self, handler):
        return handler in self.bad_handlers

    def get_report(self):
        lines = []
        for type in ('warnings', 'errors'):
            msgs = getattr(self, type)
            if msgs:
                lines += [
                    'Got %s:' % type,
                ]
                lines += ['  %s -> %s' % m for m in msgs]
            else:
                lines += ['No %s emitted' % type]
        return '\n'.join(lines)


class SpellCheckerTest(TestCase):
    def setUp(self):
        self.result = LoggingSpellCheckResult()

    def assert_has_warning(self, found, suggestion):
        if self.result.has_warning(found, suggestion):
            return

        raise AssertionError(
            'Expected warning (%s -> %s)\n' % (found, suggestion) +
            self.result.get_report()
        )

    def assert_has_error(self, found, suggestion):
        if self.result.has_error(found, suggestion):
            return

        raise AssertionError(
            'Expected error (%s -> %s)\n' % (found, suggestion) +
            self.result.get_report()
        )

    def assert_has_handler_warning(self, handler):
        if self.result.has_bad_handler(handler):
            return

        raise AssertionError(
            'Expected warning for hander %s\n' % handler +
            self.result.get_report()
        )

    def spellcheck(self, namespace):
        spellcheck.spellcheck(namespace,
                              list(game.PGZeroGame.EVENT_HANDLERS.values()),
                              self.result)

    def test_misspelled_mousedown(self):
        self.spellcheck({
            'on_moose_down': lambda: None,
        })
        self.assert_has_warning('on_moose_down', 'on_mouse_down')

    def test_misspelled_width_uppercase(self):
        self.spellcheck({
            'WIDHT': 640,
        })
        self.assert_has_warning('WIDHT', 'WIDTH')

    def test_misspelled_width_lowercase(self):
        self.spellcheck({
            'widht': 640,
        })
        self.assert_has_warning('widht', 'WIDTH')

    def test_misspelled_width_mixed_lower_and_upper_case(self):
        self.spellcheck({
            'WIDht': 640,
        })
        self.assert_has_warning('WIDht', 'WIDTH')

    def test_misspelled_param(self):
        self.spellcheck({
            'on_mouse_down': lambda buton: None,
        })
        self.assert_has_error('buton', 'button')

    def test_invalid_event_handler(self):
        self.spellcheck({
            'on_key_press': lambda: None,
            'onKeyPress': lambda: None
        })
        self.assert_has_handler_warning('on_key_press')
        self.assert_has_handler_warning('onKeyPress')


class CheckColorNamesTest(TestCase):
    def test_correct_color_name(self):
        # On a correct color name, the function just returns nothing.
        self.assertIsNone(spellcheck.check_color_name("blue"))

    def test_wrong_color_name(self):
        # On an incorrect one, a descriptive error is raised.
        self.assertRaisesRegex(KeyError,
                               "No color called read found, did you mean red?",
                               spellcheck.check_color_name, "read")
