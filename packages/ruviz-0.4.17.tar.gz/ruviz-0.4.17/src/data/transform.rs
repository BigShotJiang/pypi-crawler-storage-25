// Data transformation utilities (future)
