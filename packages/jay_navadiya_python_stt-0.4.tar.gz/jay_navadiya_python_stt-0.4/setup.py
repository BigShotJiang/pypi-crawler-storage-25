from setuptools import setup, find_packages

setup(
    name='Jay_Navadiya_Python_STT',
    version='0.4',
    author='Jay Navadiya',
    author_email='jaynavadiya201120@gmail.com',
    description='A simple speech-to-text application using Selenium and WebDriver Manager created by Jay Navadiya',
    packages=find_packages(),
    install_requires=[
        'selenium',
        'webdriver-manager'
    ]
)


