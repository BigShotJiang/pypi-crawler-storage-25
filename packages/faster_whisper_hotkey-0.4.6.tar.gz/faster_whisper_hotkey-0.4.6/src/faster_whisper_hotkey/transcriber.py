import logging
import signal
import threading
import time

import numpy as np
import pulsectl
import sounddevice as sd
from pynput import keyboard

from .clipboard import backup_clipboard, restore_clipboard, set_clipboard
from .llm_corrector import LLMCorrector
from .models import ModelWrapper
from .paste import paste_to_active_window
from .settings import Settings

logger = logging.getLogger(__name__)

# Minimum recording duration to prevent short noise transcriptions
MIN_RECORDING_DURATION = 1.0  # seconds


class MicrophoneTranscriber:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.sample_rate = 16000
        self.max_buffer_length = 10 * 60 * self.sample_rate
        self.audio_buffer = np.zeros(self.max_buffer_length, dtype=np.float32)
        self.buffer_index = 0

        # Load the requested model wrapper
        self.model_wrapper = ModelWrapper(self.settings)

        # Initialize LLM corrector if enabled
        self.llm_corrector = None
        if getattr(settings, "llm_correction_enabled", False):
            endpoint = getattr(settings, "llm_endpoint", "")
            model_name = getattr(settings, "llm_model_name", "")
            if endpoint and model_name:
                self.llm_corrector = LLMCorrector(endpoint, model_name)

        self.stop_event = threading.Event()
        self.exit_flag = False
        self.is_recording = False
        self.device_name = self.settings.device_name
        self.keyboard_controller = keyboard.Controller()
        self.language = self.settings.language
        self.hotkey_key = self._parse_hotkey(self.settings.hotkey)
        self.is_transcribing = False
        self.last_transcription_end_time = 0.0
        self.transcription_queue = []
        self.timer = None
        self.recording_start_time = 0.0

    # ------------------------------------------------------------------
    # Hotkey mapping
    # ------------------------------------------------------------------
    def _parse_hotkey(self, hotkey_str):
        key_mapping = {
            "pause": keyboard.Key.pause,
            "f4": keyboard.Key.f4,
            "f8": keyboard.Key.f8,
            "insert": keyboard.Key.insert,
        }
        return key_mapping.get(hotkey_str, keyboard.Key.pause)

    # ------------------------------------------------------------------
    # Set default audio source
    # ------------------------------------------------------------------
    def set_default_audio_source(self):
        try:
            with pulsectl.Pulse("set-default-source") as pulse:
                for source in pulse.source_list():
                    if source.name == self.device_name:
                        pulse.source_default_set(source)
                        logger.info(f"Default source set to: {source.name}")
                        return
                logger.warning(f"Source '{self.device_name}' not found")
        except Exception as e:
            logger.debug(f"Failed to set default source: {e}")

    # ------------------------------------------------------------------
    # Audio processing utilities
    # ------------------------------------------------------------------
    @staticmethod
    def _normalize_audio(audio_data: np.ndarray) -> np.ndarray:
        """Normalize audio data to [-1, 1] range."""
        max_val = np.abs(audio_data).max()
        return audio_data / max_val if not np.isclose(max_val, 0) else audio_data

    @staticmethod
    def _to_mono(audio_data: np.ndarray) -> np.ndarray:
        """Convert stereo audio to mono by averaging channels."""
        if audio_data.ndim > 1 and audio_data.shape[1] == 2:
            return np.mean(audio_data, axis=1).astype(np.float32)
        return audio_data.flatten().astype(np.float32)

    # ------------------------------------------------------------------
    # Audio callback
    # ------------------------------------------------------------------
    def audio_callback(self, indata, frames, time_, status):
        if status:
            logger.warning(f"Status: {status}")
        audio_data = self._to_mono(indata)
        audio_data = self._normalize_audio(audio_data)

        new_index = self.buffer_index + len(audio_data)
        if new_index > self.max_buffer_length:
            audio_data = audio_data[: self.max_buffer_length - self.buffer_index]
            new_index = self.max_buffer_length
        self.audio_buffer[self.buffer_index : new_index] = audio_data
        self.buffer_index = new_index

    # ------------------------------------------------------------------
    # Clipboard handling
    # ------------------------------------------------------------------
    def _send_via_clipboard(self, text: str) -> bool:
        """Send text via clipboard with automatic fallback to typing."""
        original_clip = backup_clipboard()
        if not set_clipboard(text):
            logger.error("Could not set clipboard - falling back to typing")
            return False
        time.sleep(0.01)  # give clipboard time to settle
        paste_to_active_window()
        if original_clip is not None:
            time.sleep(0.05)
            restore_clipboard(original_clip)
        return True

    def _type_text(self, text: str):
        """Fallback: type text character by character."""
        for char in text:
            self.keyboard_controller.press(char)
            self.keyboard_controller.release(char)
            time.sleep(0.001)

    # ------------------------------------------------------------------
    # Transcription and sending
    # ------------------------------------------------------------------
    def transcribe_and_send(self, audio_data):
        try:
            self.is_transcribing = True
            transcribed_text = self.model_wrapper.transcribe(
                audio_data,
                sample_rate=self.sample_rate,
                language=self.settings.language,
            )

            # Log the raw transcription
            if transcribed_text.strip():
                logger.info(f'Transcribed text: "{transcribed_text}"')
            else:
                logger.info("No speech detected")

            # Apply LLM correction if enabled
            if self.llm_corrector and transcribed_text.strip():
                transcribed_text = self.llm_corrector.correct(transcribed_text)

            # Send the text via clipboard or fallback to typing
            if transcribed_text.strip():
                if callable(set_clipboard) and self._send_via_clipboard(transcribed_text):
                    pass  # Successfully sent via clipboard
                else:
                    self._type_text(transcribed_text)

        except Exception as e:
            logger.error(f"Transcription error: {e}")
        finally:
            self.is_transcribing = False
            self.last_transcription_end_time = time.time()
            self.process_next_transcription()

    def process_next_transcription(self):
        if self.transcription_queue and not self.is_transcribing:
            audio_data = self.transcription_queue.pop(0)
            self.is_transcribing = True
            threading.Thread(
                target=self.transcribe_and_send, args=(audio_data,), daemon=True
            ).start()

    # ------------------------------------------------------------------
    # Recording control
    # ------------------------------------------------------------------
    def start_recording(self):
        if not self.is_recording:
            logger.info("Recording...")
            self.stop_event.clear()
            self.is_recording = True
            self.recording_start_time = time.time()
            self.stream = sd.InputStream(
                callback=self.audio_callback,
                channels=1,
                samplerate=self.sample_rate,
                blocksize=4000,
                device="default",
            )
            self.stream.start()

    def stop_recording_and_transcribe(self):
        if hasattr(self, "timer") and self.timer:
            self.timer.cancel()
        if self.is_recording:
            self.stop_event.set()
            self.is_recording = False
            try:
                self.stream.stop()
                self.stream.close()
            except Exception:
                pass
            if self.buffer_index > 0:
                audio_data = self.audio_buffer[: self.buffer_index]
                recording_duration = time.time() - self.recording_start_time

                if recording_duration >= MIN_RECORDING_DURATION:
                    self.audio_buffer = np.zeros(
                        self.max_buffer_length, dtype=np.float32
                    )
                    self.buffer_index = 0
                    self.transcription_queue.append(audio_data)
                    self.process_next_transcription()
                    logger.info(f"Recording duration: {recording_duration:.2f}s")
                    logger.info("Processing transcription...")
                else:
                    self.audio_buffer = np.zeros(
                        self.max_buffer_length, dtype=np.float32
                    )
                    self.buffer_index = 0
                    logger.info(
                        f"Recording duration: {recording_duration:.2f}s - too short, skipping transcription"
                    )
            else:
                self.buffer_index = 0
                self.is_transcribing = False
                self.last_transcription_end_time = time.time()
                self.process_next_transcription()

    # ------------------------------------------------------------------
    # Hotkey handlers
    # ------------------------------------------------------------------
    def on_press(self, key):
        try:
            current_time = time.time()
            if self.is_recording or (
                current_time - self.last_transcription_end_time < 0.1
            ):
                return True
            if key == self.hotkey_key and not self.is_recording:
                self.start_recording()
                return True
        except AttributeError:
            pass
        return True

    def on_release(self, key):
        """
        Release the hotkey to stop recording *even if a transcription is in progress*.
        This ensures queued audio is added immediately; the text is sent as soon as the
        transcription finishes.
        """
        try:
            if key == self.hotkey_key and self.is_recording:
                self.stop_recording_and_transcribe()
                return True
        except AttributeError:
            pass
        return True

    # ------------------------------------------------------------------
    # Main loop
    # ------------------------------------------------------------------
    def run(self):
        try:
            self.set_default_audio_source()
        except Exception:
            pass

        # Define wrapper functions to satisfy type checker
        def _on_press(key):
            self.on_press(key)
            return None

        def _on_release(key):
            self.on_release(key)
            return None

        listener = keyboard.Listener(on_press=_on_press, on_release=_on_release)
        listener.start()

        logger.info(
            f"Press {self.settings.hotkey.capitalize()} to start/stop recording. Press Ctrl+C to exit."
        )

        def sigint_handler(signum, frame):
            self.exit_flag = True

        signal.signal(signal.SIGINT, sigint_handler)

        while not self.exit_flag:
            if not listener.is_alive():
                break
            time.sleep(0.1)

        listener.stop()

        if self.is_recording:
            self.stop_recording_and_transcribe()

        logger.info("Program terminated by user")
