# Changelog

All notable changes to `z4j` are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.0.15] - 2026-04-27

### Performance

- Bumps `z4j-brain` floor to `>=1.0.15,<1.1` which lands the
  **P-1 batched heartbeat upsert** — replaces N+1 worker upsert
  round-trips per event batch with a single
  `INSERT...ON CONFLICT DO UPDATE` (dialect-aware on
  Postgres + SQLite). Worker hostnames in the batch are
  deduplicated and flushed as one statement; heartbeat
  carries `max(occurred_at)` instead of racing with
  wall-clock `now()`. Verified end-to-end against a real
  WebSocket: 50 events from 3 workers collapse to 3 worker
  rows with `last_heartbeat = max(occurred_at)` per worker
  (delta 0.000s). 200-event batch now issues exactly **one**
  INSERT against `workers` (was 200 SELECTs + up to 200
  INSERTs/UPDATEs). See [z4j-brain 1.0.15 CHANGELOG](https://github.com/z4jdev/z4j-brain/blob/main/CHANGELOG.md#1015---2026-04-27).

### Security

- Bumps `z4j-brain` floor to `>=1.0.15,<1.1` which adds **SPA
  catch-all hardening** — typo'd `/api/v1/...` URLs now return
  clean 404 JSON instead of being shadowed by the dashboard
  SPA's `index.html` (which broke frontend code with
  `Unexpected token '<'`). Defends `/api/`, `/ws/`, `/metrics`,
  `/auth/`, `/setup/`, `/healthz`, `/.well-known/`,
  `/openapi.json`, `/docs`, `/redoc`, and `/assets/` from
  ever being served as the SPA fallback.

### Fixed

- SQLite migration downgrade across the v1.0.15 schema is now
  safe (uses `op.batch_alter_table` for column drops). Required
  for any operator who deploys to SQLite for eval and needs to
  roll back.
- Latent `ImportError` on certain personal-notification 403
  paths is now a real HTTP 403 envelope.

## [1.0.14] - 2026-04-24

### Security (BREAKING)

- Bumps `z4j-brain` floor to `>=1.0.14,<1.1` which closes two silent-leak defaults:
  1. `z4j serve` now refuses to start when `Z4J_ENVIRONMENT=dev` AND the bind host is non-loopback — the unsafe combo that exposed dev-mode cookies and disabled host validation to anyone who could reach the port.
  2. Default bind host in dev mode is now `127.0.0.1` (was `0.0.0.0`).

  See [/operations/dev-vs-production/](https://z4j.dev/operations/dev-vs-production/) for the migration guide. Most deployments need three env vars added to their systemd unit (`Z4J_ENVIRONMENT=production`, `Z4J_PUBLIC_URL=https://...`, `Z4J_ALLOWED_HOSTS`) and a restart.

### Added

- Bumps `z4j-brain` floor to `>=1.0.14,<1.1` which adds **PagerDuty + Discord native notification channels**, multi-select cross-import (project channels ↔ personal channels), the **`z4j metrics-token rotate`** CLI for token hygiene, **`--environment` / `--env`** flag on `z4j serve`, and a 21-item security audit hardening pass (Codex audit + independent triple audit) covering notification audit-log secret leakage, ReDoS, DoS-input caps, rate limits, IP allow-list discipline, deepcopy of imported configs, atomic file creation for the metrics token, and bonus pre-existing-bug fixes. See [z4j-brain 1.0.14 CHANGELOG](https://github.com/z4jdev/z4j-brain/blob/main/CHANGELOG.md#1014---2026-04-24).

## [1.0.13] - 2026-04-24

### Security (BREAKING)

- Bumps `z4j-brain` floor to `>=1.0.13,<1.1` which makes `/metrics` fail-secure by default. Fresh installs and in-place upgrades auto-mint `Z4J_METRICS_AUTH_TOKEN` and persist it to `~/.z4j/secret.env`; `/metrics` returns 401 unless the correct `Authorization: Bearer <token>` is presented OR the operator explicitly sets `Z4J_METRICS_PUBLIC=1`. Closes the default-insecure `/metrics` footgun introduced in 1.0.11. See [z4j-brain 1.0.13 CHANGELOG](https://github.com/z4jdev/z4j-brain/blob/main/CHANGELOG.md#1013---2026-04-24) for operator migration notes.

## [1.0.12] - 2026-04-24

### Fixed

- Bumps `z4j-brain` floor to `>=1.0.12,<1.1` which restores the dashboard SPA. The 1.0.11 wheel on PyPI accidentally shipped the Python code without the bundled SPA, so `GET /` returned `{"detail": "Not Found"}` on every fresh install. `pip install -U z4j` and restart - no DB migrations, no env changes.

## [1.0.11] - 2026-04-24

### Changed

- Bumps pinned versions to match the v1.0.11 audit-hardening wave: `z4j-core>=1.0.5`, `z4j-brain>=1.0.11,<1.1`. See [z4j-brain CHANGELOG](https://github.com/z4jdev/z4j-brain/blob/main/CHANGELOG.md#1011---2026-04-24) for the security findings closed (4 Medium + 3 Low). **Note**: 1.0.11 shipped without the dashboard SPA in the wheel - upgrade directly to 1.0.12 instead.

## [1.0.4] - 2026-04-23

### Fixed

- **Bumps `z4j-brain` floor to `>=1.0.4`** which fixes four UX bugs in the bare-metal first-boot flow:
  1. Stale-DB cross-version safety net: when a fresh secret is auto-minted, any pre-existing `~/.z4j/z4j.db` from a crashed older install is moved aside to `.stale-bak`.
  2. Setup rate-limit budget bumped from 5 to 30 attempts per IP per 15-min window.
  3. Rate-limit lockout no longer self-perpetuates (used to count each blocked retry, extending the window indefinitely).
  4. Setup error messages now include actionable guidance instead of the opaque "setup token expired or already used".
- New `z4j-brain reset-setup` CLI command for stuck operators (escape hatch when locked out without wanting to nuke `~/.z4j/`).

### Compatibility

- Backwards compatible. Compose files unchanged from 1.0.3.

## [1.0.3] - 2026-04-22

### Fixed

- **Bumps `z4j-brain` floor to `>=1.0.3`** which fixes the zero-config bare-metal `pip install z4j && z4j-brain serve` flow. Before this fix, the CLI auto-defaulted `Z4J_DATABASE_URL` to `~/.z4j/z4j.db` but did NOT auto-mint HMAC signing keys, so `z4j-brain serve` crashed with a Pydantic `ValidationError: secret + session_secret Field required` until the operator manually exported them. The Docker entrypoint had always done this; the bare-metal CLI now matches.
- README "Quick start" rewritten: `pip install z4j && z4j-brain serve` is now the entire flow. No manual `secrets.token_urlsafe` dance.

### Compatibility

- Backwards compatible. Operators who already set `Z4J_SECRET`, `Z4J_SESSION_SECRET`, etc. via env vars or compose files see no behavior change. The auto-mint kicks in only when those env vars are unset.
- Compose files unchanged from 1.0.2.

## [1.0.2] - 2026-04-22

### Added

- **Docker Compose recipes ship with the package.** `docker-compose.yml` (SQLite mode), `docker-compose.postgres.yml` (PostgreSQL sidecar), `docker-compose.caddy.yml` (Let's Encrypt HTTPS overlay), and `.env.example` are now included in the `z4j` sdist and the [z4jdev/z4j GitHub repo](https://github.com/z4jdev/z4j). Operators can `git clone github.com/z4jdev/z4j && docker compose up -d` for a fully working self-host without reading the Dockerfile.
- Compose files reference the public `z4jdev/z4j:latest` image on Docker Hub (published in v1.0.1 of the brain).

### Notes

- Wheel content is unchanged from 1.0.1 - the compose files are sdist + repo artifacts, not runtime Python code. `pip install z4j==1.0.1` and `pip install z4j==1.0.2` land identical Python on disk. The sdist (and the GitHub repo) is where compose recipes appear.

## [1.0.1] - 2026-04-22

First public release of the z4j umbrella package. Synchronized with z4j-brain 1.0.1.

### Features

- **Meta-install for the z4j control plane.** `pip install z4j` resolves to `z4j-brain>=1.0.1` + `z4j-core>=1.0.1`, giving a fully working brain server (dashboard, REST API, WebSocket gateway, SQLite DB, Alembic migrations, CLI) in one command. Mirrors the `docker run z4jdev/z4j` experience for Python-first operators.
- **Clean extras surface for adapter selection**: `[celery]`, `[django]`, `[flask]`, `[fastapi]`, `[rq]`, `[dramatiq]`, `[huey]`, `[arq]`, `[taskiq]`, `[apscheduler]`, `[bare]`. Each extra pulls the engine adapter plus its companion scheduler (where applicable) in one shot, covering the 95% case.
- **Infra pass-through extra** `[postgres]` defers to `z4j-brain[postgres]`, so asyncpg's version floor stays owned by the brain package rather than being duplicated here.
- **Convenience bundles**: `[agents]` (every engine adapter at once) and `[all]` (= `[agents,postgres]`, the kitchen sink for CI / dev rigs).
- **Agent-only install recipe documented** for organizations whose policy forbids AGPL code: `pip install z4j-core z4j-<adapter>` keeps Apache-2.0 purity without touching the brain.

### Notes

- **OpenTelemetry is not shipped.** The umbrella intentionally does not expose an `[otel]` extra. z4j-brain 1.0.1 simultaneously drops its own `[otel]` extra because the packages were installed but the integration code was never wired (no `TracerProvider` init, no FastAPI instrumentation, no OTLP export path). OpenTelemetry support will return as a real working feature in a future release, at which point both packages will reintroduce the extra. Until then, the working observability story is Prometheus `/metrics` + structlog JSON logs, both wired in z4j-brain since 1.0.0.

### Compatibility

- Python 3.11, 3.12, 3.13, 3.14.
- Operating-system independent (Linux, macOS, Windows).
- Depends on `z4j-brain>=1.0.1` (AGPL v3) and `z4j-core>=1.0.1` (Apache 2.0).

## Links

- Repository: <https://github.com/z4jdev/z4j>
- Issues: <https://github.com/z4jdev/z4j/issues>
- PyPI: <https://pypi.org/project/z4j/>

[Unreleased]: https://github.com/z4jdev/z4j/compare/v1.0.0...HEAD
[1.0.0]: https://github.com/z4jdev/z4j/releases/tag/v1.0.0
