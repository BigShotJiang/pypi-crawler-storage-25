"""Base class for dynamic pydantic models"""

import contextlib
import functools
import operator
import typing as ty
import warnings

import pydantic
import pydantic.fields
import pydantic_core

from .exceptions import (
    AmbiguousDiscriminatorValueError,
    NoRegisteredTypesError,
    RegistrationError,
)
from .union_mode import DiscriminatedConfig, UnionMode


def _inject_discriminator_field(
    cls: type[pydantic.BaseModel],
    disc_field: str,
    value: str,
) -> pydantic.fields.FieldInfo:
    """Injects the discriminator field into the given model

    Parameters
    ----------
    cls
        The BaseModel subclass
    disc_field
        Name of the discriminator field
    value
        Value of the discriminator field
    """
    if hasattr(cls, disc_field):
        msg = (
            f'Cannot inject discriminator field "{disc_field}" into '
            f"{cls.__name__}: an attribute with that name already exists. "
            "Rename either the attribute or the discriminator_field to avoid "
            "the conflict."
        )
        raise RegistrationError(msg)

    cls.model_fields[disc_field] = pydantic.fields.FieldInfo(
        default=value,
        annotation=ty.Literal[value],  # type: ignore[not-a-type]
        frozen=True,
    )
    with contextlib.suppress(pydantic.errors.PydanticUndefinedAnnotation):
        cls.model_rebuild(force=True)
    return cls.model_fields[disc_field]


class TrackingGroup(pydantic.BaseModel):
    """Tracker for pydantic models"""

    name: str = pydantic.Field(
        description=(
            "Name of the tracking group. This is for human display, so it "
            "doesn't technically need to be globally unique, but it should be "
            "meaningfully named, as it will be used in error messages."
        ),
    )
    union_mode: UnionMode | None = pydantic.Field(
        None,
        description=(
            "Union validation strategy. Pass a DiscriminatedConfig instance "
            'or one of the plain strings "smart" or "left_to_right". You can '
            "also just pass the fields for DiscriminatedConfig to this "
            "model and they will be forwarded."
        ),
    )
    discriminator_field: str | None = pydantic.Field(
        None,
        description=(
            "Name of the discriminator field. NOTE: This field is "
            "here as an alias for union_mode.discriminator_field. Passing "
            "both a discriminator_field and a union_mode will result in an "
            "error."
        ),
    )
    discriminator_value_generator: ty.Callable[[type], str] | None = pydantic.Field(
        None,
        description=(
            "A callable that produces default values for the discriminator field"
        ),
    )
    plugin_entry_point: str | None = pydantic.Field(
        None,
        description=(
            "If given, then plugins packages will be supported through this "
            "Python entrypoint. The entrypoint can either be a function, "
            "which will be called, or simply a module, which will be "
            "imported. In either case, models found along the import path of "
            "the entrypoint will be registered. If the entrypoint is a "
            "function, additional models may be declared in the function."
        ),
    )
    models: dict[str, type[pydantic.BaseModel]] = pydantic.Field(
        {},
        description="The tracked models",
    )

    _generation: int = pydantic.PrivateAttr(default=0)
    _adapter: pydantic.TypeAdapter | None = pydantic.PrivateAttr(default=None)
    _adapter_generation: int = pydantic.PrivateAttr(default=-1)

    @pydantic.model_validator(mode="after")
    def _ensure_union_mode(self) -> "TrackingGroup":
        """There must be a union_mode

        This validator works as a guard on _coerce_union_mode to make
        """
        if self.union_mode is None:
            msg = (
                "union_mode is required. This normally indicates that you "
                "subclasses TrackingGroup and wrote an invalid validator, but "
                "could also be a bug with dynapydantic, so please file a bug "
                "report with a reproducer on how you got here if you suspect "
                "a bug."
            )
            raise ValueError(msg)

        # Ensure the top-level fields are in-sync
        if isinstance(self.union_mode, DiscriminatedConfig):
            self.discriminator_field = self.union_mode.discriminator_field
            self.discriminator_value_generator = (
                self.union_mode.discriminator_value_generator
            )
        else:
            self.discriminator_field = None
            self.discriminator_value_generator = None

        return self

    @pydantic.model_validator(mode="before")
    @classmethod
    def _coerce_union_mode(cls, data: ty.Any) -> ty.Any:  # noqa: ANN401
        """Coerce flat discriminator kwargs into a DiscriminatedConfig.

        Allows callers to pass ``discriminator_field`` and
        ``discriminator_value_generator`` at the top level and transparently
        assembles a ``DiscriminatedConfig`` from them. This avoids an extra
        import/nesting layer for the user.
        """
        if not isinstance(data, dict):
            return data

        disc_field = data.get("discriminator_field", None)
        has_disc_field = disc_field is not None
        union_mode = data.get("union_mode", None)
        has_union_mode = union_mode is not None

        # If the user passed us both a discriminator field and a union_mode,
        # things must be perfectly consistent
        if has_disc_field and has_union_mode:
            consistent = (
                isinstance(union_mode, DiscriminatedConfig)
                and disc_field == union_mode.discriminator_field
                and data.get("discriminator_value_generator")
                is union_mode.discriminator_value_generator
            ) or (
                isinstance(union_mode, dict)
                and disc_field == union_mode.get("discriminator_field")
                and data.get("discriminator_value_generator")
                is union_mode.get("discriminator_value_generator")
            )
            if not consistent:
                msg = (
                    "Received both union_mode and discriminator_field; pass one "
                    "or the other."
                )
                raise ValueError(msg)

        if has_disc_field and not has_union_mode:
            # Forward arguments to DiscriminatedConfig
            data["union_mode"] = {
                "discriminator_field": disc_field,
                "discriminator_value_generator": data.get(
                    "discriminator_value_generator",
                ),
            }
        elif not has_disc_field and not has_union_mode:
            msg = "Either union_mode or discriminator_field must be given"
            raise ValueError(msg)

        return data

    @property
    def _discriminated(self) -> DiscriminatedConfig | None:
        """Return the DiscriminatedMode config, or None if not discriminated."""
        return (
            self.union_mode
            if isinstance(self.union_mode, DiscriminatedConfig)
            else None
        )

    def load_plugins(self) -> None:
        """Load plugins to discover/register additional models"""
        if self.plugin_entry_point is None:
            return

        from importlib.metadata import entry_points  # noqa: PLC0415

        for ep in entry_points().select(group=self.plugin_entry_point):
            plugin = ep.load()
            if callable(plugin):
                plugin()

    @ty.overload
    def register(self, value: str | None = None) -> ty.Callable[[type], type]: ...

    @ty.overload
    def register(self, value: type[pydantic.BaseModel]) -> type[pydantic.BaseModel]: ...

    def register(
        self,
        value: str | type[pydantic.BaseModel] | None = None,
    ) -> ty.Callable[[type], type] | type[pydantic.BaseModel]:
        """Register a model into this group (decorator)

        Parameters
        ----------
        value
            Value for the discriminator field. If not given, then
            discriminator_value_generator must be non-None or the
            discriminator field must be declared by hand. Can also be the type
            itself to register (if the ()'s are omitted from the decorator).
        """
        if isinstance(value, type):
            self.register_model(value)
            return value

        def _wrapper(cls: type[pydantic.BaseModel]) -> type[pydantic.BaseModel]:
            self.register_model(cls, value)
            return cls

        return _wrapper

    def register_model(
        self,
        cls: type[pydantic.BaseModel],
        discriminator_value: str | None = None,
    ) -> None:
        """Register the given model into this group

        Parameters
        ----------
        cls
            The model to register
        discriminator_value
            Value for the discriminator field. If not given, then
            discriminator_value_generator must be non-None or the
            discriminator field must be declared by hand.
        """
        if discriminator_value is not None and not isinstance(discriminator_value, str):
            msg = (
                "discriminator_value must be a str if given, was "
                f"{type(discriminator_value).__name__}"
            )
            raise RegistrationError(msg)

        if not isinstance(cls, type) or not issubclass(cls, pydantic.BaseModel):
            msg = (
                "only pydantic BaseModel subclasses can be registered in a "
                f"TrackingGroup. Got {cls}, which was not."
            )
            raise RegistrationError(msg)

        if (dm := self._discriminated) is not None:
            disc = dm.discriminator_field
            field = cls.model_fields.get(disc)

            if field is None:
                if discriminator_value is not None:
                    _inject_discriminator_field(cls, disc, discriminator_value)
                elif dm.discriminator_value_generator is not None:
                    _inject_discriminator_field(
                        cls,
                        disc,
                        dm.discriminator_value_generator(cls),
                    )
                else:
                    msg = (
                        f"unable to determine a discriminator value for "
                        f'{cls.__name__} in tracking group "{self.name}". '
                        "No value was passed, discriminator_value_generator "
                        f'was None and the "{disc}" field was not defined.'
                    )
                    raise RegistrationError(msg)
            elif ty.get_origin(field.annotation) is not ty.Literal:
                msg = (
                    f'the discriminator field "{disc}" already existed in '
                    f"{cls.__name__}, but its type annotation was "
                    f"{field.annotation}, not Literal."
                )
                raise RegistrationError(msg)
            elif (
                discriminator_value is not None and field.default != discriminator_value
            ):
                msg = (
                    f"the discriminator value for {cls.__name__} was "
                    f'ambiguous, the passed value was "{discriminator_value}" '
                    f' and "{field.default}" via the discriminator '
                    f"field ({disc})."
                )
                raise AmbiguousDiscriminatorValueError(msg)

            self._register_with_discriminator_field(cls)
        else:
            if discriminator_value is not None:
                warnings.warn(
                    f'A discriminator_value of "{discriminator_value}" was '
                    f"explicitly passed for {cls.__name__}, but "
                    f'union_mode="{self.union_mode}" does not use a '
                    "discriminator. The value will be ignored.",
                    stacklevel=2,
                )
            self._register_plain(cls)

    def union(
        self,
        *,
        plain: bool | None = None,
    ) -> ty.Any:  # noqa: ANN401
        """Return the union of all registered models

        Parameters
        ----------
        plain
            If set to `True`, a plain union of all members will be returned.
            Otherwise, the returned union will be annotated in accordance with
            the union mode.

        Returns
        -------
        Any
            If there is 1 registered type, the type itself. If there is > 1, a
            union of all registered types. This union may be annotated if
            `plain` is not `True`.

        Raises
        ------
        NoRegisteredTypesError
            If no types have been registered yet.
        """
        n = len(self.models)
        if n == 0:
            msg = (
                "Unable to produce a union from the tracking group "
                f'"{self.name}", as no types have been registered yet.'
            )
            raise NoRegisteredTypesError(msg)
        if n == 1:
            return next(iter(self.models.values()))

        union_mode = "smart" if plain else self.union_mode

        if isinstance(union_mode, DiscriminatedConfig):
            return ty.Annotated[
                functools.reduce(
                    operator.or_,
                    tuple(
                        ty.Annotated[x, pydantic.Tag(v)] for v, x in self.models.items()
                    ),
                ),
                pydantic.Field(discriminator=union_mode.discriminator_field),
            ]

        plain_union = functools.reduce(operator.or_, self.models.values())
        if union_mode == "left_to_right":
            return ty.Annotated[plain_union, pydantic.Field(union_mode="left_to_right")]

        # "smart" mode is pydantic's default behavior on a plain union
        return plain_union

    @property
    def generation(self) -> int:
        """The generation of the tracking group.

        This is a counter that increments every time a new registration occurs
        """
        return self._generation

    @property
    def type_adapter(self) -> pydantic.TypeAdapter:
        """Get the pydantic TypeAdapter for the union of all group members"""
        if self.generation != self._adapter_generation:
            self._adapter = pydantic.TypeAdapter(self.union())
            self._adapter_generation = self.generation

        # casting because the if statement ensures it is non-None (because
        # _adapter_generation starts at -1 and generation increments from 0.
        return ty.cast("pydantic.TypeAdapter", self._adapter)

    def _register_with_discriminator_field(self, cls: type[pydantic.BaseModel]) -> None:
        """Register the model with the default of the discriminator field

        Parameters
        ----------
        cls
            The class to register, must have the disciminator field set with a
            unique default value in the group.
        """
        disc = ty.cast("DiscriminatedConfig", self.union_mode).discriminator_field
        value = cls.model_fields[disc].default
        if value == pydantic_core.PydanticUndefined:
            msg = (
                f"{cls.__name__}.{disc} had no default value, it must "
                "have one which is unique among all tracked models."
            )
            raise RegistrationError(msg)
        if not isinstance(value, str):
            msg = (
                f"{cls.__name__}.{disc} had a default value of {value}, which "
                f"was of type {type(value).__name__}, not str."
            )
            raise RegistrationError(msg)

        self._do_register(value, cls)

    def _register_plain(self, cls: type[pydantic.BaseModel]) -> None:
        """Register the model keyed by its class name.

        Used for smart / left_to_right modes where no discriminator field
        is involved.

        Parameters
        ----------
        cls
            The model to register.
        """
        self._do_register(str(id(cls)), cls)

    def _do_register(self, key: str, cls: type[pydantic.BaseModel]) -> None:
        """Register the given model under the given key

        Parameters
        ----------
        key
            The key under which to register the model
        cls
            The model to register.
        """
        if (other := self.models.get(key)) is not None:
            if other is not cls:
                msg = (
                    f'Cannot register {cls.__name__} under the "{key}" '
                    f"identifier, which is already in use by {other.__name__}."
                )
                raise RegistrationError(msg)
        else:
            self._generation += 1
            self.models[key] = cls
