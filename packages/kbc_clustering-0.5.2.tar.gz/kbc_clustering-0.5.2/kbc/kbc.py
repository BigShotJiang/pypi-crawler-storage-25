

"""
KBC clustering — Kernel-Bounded Clustering: Achieving the Objective of Spectral Clustering without Eigendecomposition in Artificial Intelligence Journal (AIJ) 2025.
Author: Hang Zhang
"""

import warnings
import numpy as np
import torch
import math
from tqdm import trange
from sklearn.base import BaseEstimator, ClusterMixin
from sklearn.utils import check_array, check_random_state
from scipy.sparse.csgraph import connected_components
from scipy.sparse import csr_matrix, lil_matrix, hstack
from sklearn.metrics.pairwise import pairwise_distances
import torch.nn.functional as F


# Suppress warnings for cleaner output
warnings.filterwarnings('ignore')


class KBC(BaseEstimator, ClusterMixin):
    """
    KBC: Kernel-Bounded Clustering

    Parameters
    ----------
    k : int
        Number of clusters.
    tau : float
        Threshold for binarising the subgraph (relative to max kernel value).
    psi : int
        Number of centroids per isolation-tree.
    t : int, default=100
        Number of isolation trees.
    subsample_size : int, default=10_000
        Size of subset used to build the kernel matrix.
    batch_size : int, default=10_000
        GPU batch size for IK transform.
    random_state : int or None, default=None
        Random seed for reproducibility.
    post_processing : bool, default=False
        Refine labels with k-means iterations after graph clustering.

    Attributes
    ----------
    labels_ : ndarray of shape (n_samples,)
        Cluster labels (0-based).
    """

    def __init__(self, k: int, tau: float, psi: int, t: int = 100,
                 subsample_size: int = 10_000, batch_size: int = 10_000,
                 random_state=None, post_processing: bool = True, metric = 'euclidean',device: torch.device = 'None', device_clu: torch.device='cpu'):
        self.k = k
        self.tau = tau
        self.psi = psi
        self.t = t
        self.subsample_size = subsample_size
        self.batch_size = batch_size
        self.random_state = random_state
        self.post_processing = post_processing
        self.device = device
        self.metric = metric  # 
        self.device_clu = device_clu

    def _clustering_device(self):
        if isinstance(self.device_clu, torch.device):
            return self.device_clu
        if self.device_clu in ['cpu', 'CPU']:
            return torch.device('cpu')
        if self.device_clu in [None, 'None']:
            return self.device
        return torch.device(self.device_clu)

    def fit(self, X, y=None):
        """
        Perform clustering.

        Parameters
        ----------
        X : array-like of shape (n_samples, n_features)
            Training data.
        y : Ignored
            Not used, present for sklearn API consistency.

        Returns
        -------
        self : object
        """
        X = check_array(X, dtype=np.float32, order='C')
        n, d = X.shape

        if self.device == 'None':
            self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

        # Ensure psi is at least 2 to avoid degenerate radius
        psi = max(2, min(self.psi, n))
        self.ik = _IsolationKernel(t=self.t, psi=psi, device=self.device, random_state=self.random_state, metric=self.metric)
        self.ik.fit(X)
        self.ndata = self.ik.transform(X, batch_size=self.batch_size)  # (n, t*psi), int8

        rng = check_random_state(self.random_state)
        s = min(self.subsample_size, n)
        sID = rng.choice(n, s, replace=False)

        # Move subset to GPU for kernel computation
        sub = torch.tensor(self.ndata[sID], dtype=torch.float32, device=self.device)  # (s, t*psi)

        # Compute kernel on subset
        K = sub @ sub.T  # (s, s)
        tau_s = self.tau * float(K.max().item())
        Kg = (K >= tau_s).int()

        n_comp, labels_sub = connected_components(
            csr_matrix(Kg.cpu().numpy()), directed=False
        )
        labels_sub = torch.from_numpy(labels_sub).to(self.device, dtype=torch.int32)

        if n_comp < self.k:
            raise ValueError(
                f"KBC found only {n_comp} connected components, "
                f"but k={self.k} was requested. Try increasing tau (current={self.tau:.4f})."
            )

        # Select top-k largest components
        comp_size = np.bincount(labels_sub.cpu().numpy(), minlength=n_comp)
        topk_idx = np.argsort(comp_size)[-self.k:][::-1]

        full_labels = torch.full((n,), -1, dtype=torch.int32, device=self.device)

        centers_list = []
        for new_id, old_id in enumerate(topk_idx):
            mask_in_sub = (labels_sub == old_id)
            full_labels[sID[mask_in_sub.cpu()]] = new_id
            centers_list.append(sub[mask_in_sub].mean(dim=0))

        self.centers = torch.stack(centers_list) # (k, feature_dim)

        clu_device = self._clustering_device()
        unassigned_mask = (full_labels == -1)
        if unassigned_mask.any():
            if clu_device.type == 'cpu':
                unassigned_indices = torch.where(unassigned_mask)[0].cpu().numpy()
                ndata_unassigned = self.ndata[unassigned_indices].astype(np.float32, copy=False)
                centers_cpu = self.centers.detach().cpu().numpy()
                sim = ndata_unassigned @ centers_cpu.T
                full_labels[unassigned_indices] = torch.from_numpy(
                    sim.argmax(axis=1).astype(np.int32)
                ).to(full_labels.device)
            else:
                unassigned_indices = torch.where(unassigned_mask)[0]
                for i in range(0, len(unassigned_indices), self.batch_size):
                    idx_chunk = unassigned_indices[i : i + self.batch_size]
                    ndata_chunk = torch.from_numpy(
                        self.ndata[idx_chunk.cpu().numpy()]
                    ).float().to(clu_device)
                    centers_chunk = self.centers.to(clu_device)
                    sim_chunk = ndata_chunk @ centers_chunk.T
                    full_labels[idx_chunk] = sim_chunk.argmax(dim=1).to(torch.int32).to(full_labels.device)
                    del ndata_chunk, sim_chunk
                if clu_device.type == 'cuda':
                    torch.cuda.empty_cache()

        # Optional refinement via k-means in IK space
        if self.post_processing:
            ndata_tensor = torch.tensor(self.ndata, dtype=torch.float32, device='cpu')
            full_labels = self._refine_gpu(ndata_tensor, full_labels, self.k)
        else:
            full_labels = full_labels.cpu()
        # self.labels_ = full_labels.cpu().numpy()

        self.labels_ = full_labels.numpy()
        return self

    def predict(self, X):
        """Predict cluster labels for new data."""
        X = check_array(X, dtype=np.float32, order='C')
        n, d = X.shape
        ndata_new = self.ik.transform(X, batch_size=self.batch_size) 
        ndata_tensor = torch.tensor(ndata_new, dtype=torch.float32, device='cpu')
        chunk_size = 10000
        newlabels = torch.full((n,), -1, dtype=torch.int32, device=self.device)
        for i in trange(0, n, chunk_size, desc="Assigning data to the distribution", leave=False):
            sub_chunk = ndata_tensor[i:i + chunk_size] 
            sim_chunk = sub_chunk @ self.centers.T   
            best_center = sim_chunk.argmax(dim=1).to(torch.int32)
            newlabels[i:i + chunk_size] = best_center
        return newlabels.cpu().numpy()

    def fit_predict(self, X, y=None):
        """Return cluster labels."""
        if self.device == 'None' or self.device == 'cpu':
            return self.fit_cpu(X, y).labels_
        return self.fit(X, y).labels_

    @torch.no_grad()
    def _refine_gpu(self, ndata, labels, k, max_iter=100, tol=0.01):
        """
        Refine labels using k-means-style updates in the Isolation Kernel space.

        Parameters
        ----------
        ndata : torch.Tensor, shape (n_samples, n_features_ik)
            Data in Isolation Kernel space (dense float32).
        labels : torch.Tensor, shape (n_samples,)
            Current cluster labels (0-based).
        k : int
            Number of clusters.
        max_iter : int
            Maximum number of refinement iterations.
        tol : float
            Convergence threshold (fraction of points that can change).

        Returns
        -------
        new_labels : torch.Tensor, shape (n_samples,)
            Refined labels.
        """
        clu_device = self._clustering_device()
        labels = labels.cpu()
        n = ndata.shape[0]
        th = max(1, int(math.ceil(tol * n)))
        for _ in range(max_iter):
            # Recompute centroids
            centers = torch.stack([
                ndata[labels == c].mean(dim=0) for c in range(k)
            ]).to(clu_device)  # (k, d_ik)

            new_labels = torch.empty(n, dtype=torch.long, device='cpu')
            if clu_device.type == 'cpu':
                similarity = ndata @ centers.cpu().T
                new_labels = similarity.argmax(dim=1).to(labels.dtype).cpu()
            else:
                for start_idx in range(0, n, self.batch_size):
                    end_idx = min(start_idx + self.batch_size, n)
                    batch_data = ndata[start_idx:end_idx].to(clu_device)
                    similarity = batch_data @ centers.T
                    batch_labels = similarity.argmax(dim=1).to(labels.dtype)
                    new_labels[start_idx:end_idx] = batch_labels.cpu()
                if clu_device.type == 'cuda':
                    torch.cuda.empty_cache()
            if (new_labels != labels).sum().item() < th:
                break
            labels = new_labels
        return labels

    def fit_cpu(self, X, y=None):
        """Fit the Isolation Kernel on CPU."""
        
        X = check_array(X, dtype=np.float32, order='C')
        n, d = X.shape
        self.device = torch.device('cpu')
        psi = max(2, min(self.psi, n))
        self.ik = _IsolationKernel(t=self.t, psi=psi, device=self.device, random_state=self.random_state, metric=self.metric)
        self.ik.fit(X)
        self.ndata = self.ik.transform(X, batch_size=self.batch_size) 

        s = min(self.subsample_size, n)
        sID = np.random.permutation(self.ndata.shape[0])[:s]
        sID.sort()
        ndata_s = self.ndata[sID, :].toarray()
        K = (ndata_s @ ndata_s.T) / self.t
        self.labels_ = IKBC(self.ndata.toarray(), K, self.tau * K.max(), self.k, sID)
        return self

        
def IKBC(ndata, K, tau, k, sID):
    s = K.shape[0]
    n_samples = ndata.shape[0]
    sID = np.array(sID, dtype=int)
    K_g = K >= tau
    graph_matrix = csr_matrix(K_g)
    n_components, Tclass_s = connected_components(csgraph=graph_matrix, directed=False, return_labels=True)
    if n_components >= k:
        component_ids, component_sizes = np.unique(Tclass_s, return_counts=True)
        top_k_indices = np.argsort(component_sizes)[-k:]
        index = component_ids[top_k_indices]
        Tlass_k = np.zeros(n_samples, dtype=int)
        mean_i = np.zeros((k, ndata.shape[1]))
        for i in range(k):
            current_component_id = index[i]
            mask = Tclass_s == current_component_id
            original_indices_of_core_cluster = sID[mask]
            if len(original_indices_of_core_cluster) == 0: continue
            Tlass_k[original_indices_of_core_cluster] = i + 1
            centroid = ndata[original_indices_of_core_cluster, :].mean(axis=0)
            mean_i[i, :] = np.asarray(centroid).squeeze()
        unassigned_mask = Tlass_k == 0
        if np.any(unassigned_mask):
            unassigned_data = ndata[unassigned_mask, :]
            similarities = unassigned_data @ mean_i.T
            aha = np.argmax(similarities, axis=1) + 1
            Tlass_k[unassigned_mask] = aha
        Tclass = Tlass_k
        Th = np.ceil(n_samples * 0.01)
        for _ in range(100):
            Cmean = np.zeros((k, ndata.shape[1]))
            for i in range(1, k + 1):
                cluster_mask = Tclass == i
                if np.any(cluster_mask):
                    centroid = ndata[cluster_mask, :].mean(axis=0)
                    Cmean[i - 1, :] = np.asarray(centroid).squeeze()
            similarities = ndata @ Cmean.T
            Tclass2 = np.argmax(similarities, axis=1) + 1
            if np.sum(Tclass2 != Tclass) < Th: break
            Tclass = Tclass2
        return Tclass
    else:
        return np.ones(n_samples, dtype=int)
    


# ===================================================================
# Isolation-Kernel GPU implementation (internal use only) @Yi-xiao Ma
# ===================================================================
class _IsolationKernel:
    """Minimal GPU Isolation-Kernel transformer."""

    def __init__(self, t: int, psi: int, device: torch.device, random_state=None, metric='euclidean'):
        self.device = device
        self._t = t
        self._psi = psi
        self._center_index_list = None
        self._radius_list = None
        self.random_state = random_state
        self.metric = metric
        self.X = None


    def fit(self, X: np.ndarray):
        self.X = X
        n_samples = X.shape[0]

        if self._psi > n_samples:
            self._psi = n_samples
            warnings.warn(f"psi is set to {n_samples} "
                          "as it is greater than the number of data points.")

        # rng = np.random.default_rng()
        rng = check_random_state(self.random_state)
        self._center_index_list = np.vstack([
            rng.choice(n_samples, size=self._psi, replace=False)
            for _ in range(self._t)
        ])  # shape=(t, psi)

        self._center_list = np.zeros((self._t * self._psi, X.shape[1]), dtype=X.dtype)
        self._radius_list = torch.zeros((self._t, self._psi), dtype=torch.float32, device=self.device)

        for i in range(self._t):
            sample = X[self._center_index_list[i]]
            self._center_list[i * self._psi:(i + 1) * self._psi] = sample

            sample_cuda = torch.tensor(sample, dtype=torch.float32, device=self.device)
            if self.metric == 'euclidean':
                s2s = torch.cdist(sample_cuda, sample_cuda, p=2)
            else:
                s2s = torch.tensor(pairwise_distances(sample, metric=self.metric), dtype=torch.float32, device=self.device)
            s2s.fill_diagonal_(float('inf'))
            self._radius_list[i] = torch.min(s2s, dim=0).values
        return self

    def transform(self, X: np.ndarray, batch_size: int = 10000):
        if X.ndim == 1:
            X = X.reshape(1, -1)

        n_samples = X.shape[0]
        output = torch.zeros((n_samples, self._psi * self._t), device='cpu', dtype=torch.int32)

        for start in trange(0, n_samples, batch_size, desc="Transforming data to Kernel space", leave=False):
            end = min(start + batch_size, n_samples)
            batch_cuda = torch.tensor(X[start:end], dtype=torch.float32, device=self.device)

            for i in range(self._t):
                sl = slice(i * self._psi, (i + 1) * self._psi)
                sample_cuda = torch.tensor(self._center_list[sl], dtype=torch.float32, device=self.device)
                if self.metric == 'euclidean':
                    p2s = torch.cdist(batch_cuda, sample_cuda, p=2)
                else:
                    # p2s = torch.tensor(pairwise_distances(X[start:end], sample_cuda.cpu().numpy(), metric=self.metric), dtype=torch.float32, device=self.device)
                    p2s = torch.cdist(F.normalize(batch_cuda, dim=1), F.normalize(sample_cuda, dim=1), p=2)
                p2ns_idx = torch.argmin(p2s, dim=1)
                p2ns = p2s[torch.arange(p2ns_idx.size(0), device=self.device), p2ns_idx]
                accept = p2ns <= self._radius_list[i, p2ns_idx]

                col_idx = p2ns_idx[accept] + i * self._psi
                output[start:end][accept, col_idx] = 1

        # Always return 2D array for consistency
        return output.numpy()



def iNNEspace_zjdis_fast(Sdata, data, psi, t, dtdist):
    sn, _ = Sdata.shape
    n, _ = data.shape
    ndata_list = []
    all_curt_indices = [np.random.choice(sn, psi, replace=False) for _ in range(t)]
    for i in range(t):
        CurtIndex = all_curt_indices[i]
        _, IA = np.unique(Sdata[CurtIndex, :], axis=0, return_index=True)
        IA.sort()
        NCurtIndex = CurtIndex[IA]
        n_centers = len(NCurtIndex)
        if n_centers < 2: continue
        sample_sample = dtdist[np.ix_(NCurtIndex, NCurtIndex)]
        np.fill_diagonal(sample_sample, np.inf)
        R = np.min(sample_sample, axis=1)
        distance_sample = dtdist[NCurtIndex, :]
        D = np.min(distance_sample, axis=0)
        I = np.argmin(distance_sample, axis=0)
        outside_mask = D > R[I]
        z = lil_matrix((n, n_centers)) 
        inside_mask = ~outside_mask
        inside_indices = np.where(inside_mask)[0]
        assigned_center_indices = I[inside_mask]
        if len(inside_indices) > 0:
            z[inside_indices, assigned_center_indices] = 1
        ndata_list.append(z)
    if not ndata_list: return csr_matrix((n, 0))
    return hstack(ndata_list, format='csr')
