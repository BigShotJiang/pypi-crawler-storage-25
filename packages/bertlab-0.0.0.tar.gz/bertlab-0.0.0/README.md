# bertlab

`bertlab` is a brutally focused encoder training lab.

This initial release is a placeholder package used to reserve the project name on PyPI while the repository is being prepared for the first public implementation release.
