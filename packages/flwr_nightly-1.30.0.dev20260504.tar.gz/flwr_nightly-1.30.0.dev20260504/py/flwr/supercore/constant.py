# Copyright 2025 Flower Labs GmbH. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================
"""Constants for Flower infrastructure."""


from __future__ import annotations

import os
import sys
from enum import Enum

from flwr.common.constant import (
    FLWR_DIR,
    NOOP_ACCOUNT_NAME,
    SYSTEM_TIME_TOLERANCE,
    TIMESTAMP_TOLERANCE,
)
from flwr.proto.federation_config_pb2 import SimulationConfig  # pylint: disable=E0611

if sys.version_info >= (3, 11):
    from enum import StrEnum
else:

    class StrEnum(str, Enum):
        """Python 3.10-compatible fallback for enum.StrEnum.

        Preserves StrEnum behavior by returning the member value from str(). Remove this
        fallback once Python 3.10 support is dropped.
        """

        def __str__(self) -> str:
            """Return the member value."""
            return str(self.value)


# Constants for Inflatable
HEAD_BODY_DIVIDER = b"\x00"
HEAD_VALUE_DIVIDER = " "

# Constants for object pushing and pulling
FLWR_PRIVATE_MAX_CONCURRENT_OBJ_PUSHES = int(
    os.getenv("FLWR_PRIVATE_MAX_CONCURRENT_OBJ_PUSHES", "2")
)  # Default maximum number of concurrent pushes
FLWR_PRIVATE_MAX_CONCURRENT_OBJ_PULLS = int(
    os.getenv("FLWR_PRIVATE_MAX_CONCURRENT_OBJ_PULLS", "2")
)  # Default maximum number of concurrent pulls
PULL_MAX_TIME = 7200  # Default maximum time to wait for pulling objects
PULL_MAX_TRIES_PER_OBJECT = 500  # Default maximum number of tries to pull an object
PULL_INITIAL_BACKOFF = 1  # Initial backoff time for pulling objects
PULL_BACKOFF_CAP = 10  # Maximum backoff time for pulling objects

# Top-level key in YAML config for exec plugin settings
EXEC_PLUGIN_SECTION = "exec_plugin"

# Flower in-memory Python-based database name
FLWR_IN_MEMORY_DB_NAME = ":flwr-in-memory:"

# Flower in-memory SQLite database URL
FLWR_IN_MEMORY_SQLITE_DB_URL = "sqlite:///:memory:"

# Constants for Hub
APP_ID_PATTERN = r"^@[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$"
APP_VERSION_PATTERN = r"^\d+\.\d+\.\d+$"
PLATFORM_API_URL = "https://api.flower.ai/v1"

# Constants for Flower CLI update check
FLWR_DISABLE_UPDATE_CHECK = "FLWR_DISABLE_UPDATE_CHECK"
FLWR_UPDATE_CHECK_URL = f"{PLATFORM_API_URL}/update-check/flwr"
FLWR_UPDATE_CHECK_CONNECT_TIMEOUT_SECONDS = 1
FLWR_UPDATE_CHECK_READ_TIMEOUT_SECONDS = 2
FLWR_UPDATE_CHECK_CACHE_DIR = ".cache"
FLWR_UPDATE_CHECK_CACHE_FILENAME = "update-check.json"
FLWR_UPDATE_CHECK_SHOW_INTERVAL_SECONDS = 12 * 60 * 60

# SuperGrid constants
SUPERGRID_ADDRESS = "supergrid.flower.ai"

# Specification for app publishing
APP_PUBLISH_ALLOWED_LICENSE_FILES = ("LICENSE", "LICENSE.md")
APP_PUBLISH_INCLUDE_PATTERNS = (
    "**/*.py",
    "**/*.toml",
    "**/*.md",
    "**/*.yaml",
    "**/*.yml",
    "**/*.json",
    "**/*.jsonl",
    "/.gitignore",
    "**/.editorconfig",
    "/LICENSE",
    "/LICENSE.md",
)
APP_PUBLISH_EXCLUDE_PATTERNS = (
    f"{FLWR_DIR}/**",  # Exclude the .flwr directory
    "**/__pycache__/**",
)
MAX_TOTAL_BYTES = 10 * 1024 * 1024  # 10 MB
MAX_FILE_BYTES = 1 * 1024 * 1024  # 1 MB
MAX_FILE_COUNT = 1000
MAX_DIR_DEPTH = 10  # relative depth (number of parts in relpath)
UTF8 = "utf-8"
MIME_MAP = {
    ".py": "text/x-python; charset=utf-8",
    ".md": "text/markdown; charset=utf-8",
    ".toml": "application/toml; charset=utf-8",
}
MAX_NAME_LENGTH = 32  # max length for app names; also used for federation names

# Constants for federations
NOOP_FEDERATION = f"@{NOOP_ACCOUNT_NAME}/default"
NOOP_FEDERATION_DESCRIPTION = "A federation for testing and development purposes."
DEFAULT_SIMULATION_CONFIG = SimulationConfig(
    num_supernodes=10,
    client_resources_num_cpus=2,
    client_resources_num_gpus=0.0,
    backend="ray",
    verbose=False,
    init_args_num_cpus=None,
    init_args_num_gpus=None,
    init_args_logging_level="WARNING",
    init_args_log_to_driver=True,
)

# Constants for exit handling
FORCE_EXIT_TIMEOUT_SECONDS = 5  # Used in `flwr_exit` function
TELEMETRY_TIMEOUT_SECONDS = 4  # Timeout for sending telemetry events during exit

# Constants for message processing timing
MESSAGE_TIME_ENTRY_MAX_AGE_SECONDS = 3600

# SuperExec auth constants
SUPEREXEC_AUTH_TIMESTAMP_HEADER = "flwr-superexec-ts"
SUPEREXEC_AUTH_NONCE_HEADER = "flwr-superexec-nonce"
SUPEREXEC_AUTH_BODY_SHA256_HEADER = "flwr-superexec-body-sha256"
SUPEREXEC_AUTH_SIGNATURE_HEADER = "flwr-superexec-signature"
SUPEREXEC_AUTH_SECRET_CONTEXT = b"superexec-auth-v1"
MIN_TIMESTAMP_DIFF_SECONDS = -SYSTEM_TIME_TOLERANCE
MAX_TIMESTAMP_DIFF_SECONDS = TIMESTAMP_TOLERANCE + SYSTEM_TIME_TOLERANCE

# Constants for Flower runtime version metadata
FLWR_PACKAGE_NAME_METADATA_KEY = "flwr-package-name"
FLWR_PACKAGE_VERSION_METADATA_KEY = "flwr-package-version"
FLWR_COMPONENT_NAME_METADATA_KEY = "flwr-component-name"
VERSION_INCOMPATIBILITY_MESSAGE_METADATA_KEY = "flwr-version-incompatibility-message"

# System message type
SYSTEM_MESSAGE_TYPE = "system"

# SQLite PRAGMA settings for optimal performance and correctness
SQLITE_PRAGMAS = (
    ("busy_timeout", "5000"),  # Retry lock acquisition for up to 5s before SQLITE_BUSY
    ("journal_mode", "WAL"),  # Enable Write-Ahead Logging for better concurrency
    ("synchronous", "NORMAL"),
    ("foreign_keys", "ON"),
    ("cache_size", "-64000"),  # 64MB cache
    ("temp_store", "MEMORY"),  # In-memory temp tables
    ("mmap_size", "268435456"),  # 256MB memory-mapped I/O
)


class NodeStatus:
    """Event log writer types."""

    REGISTERED = "registered"
    ONLINE = "online"
    OFFLINE = "offline"
    UNREGISTERED = "unregistered"

    def __new__(cls) -> NodeStatus:
        """Prevent instantiation."""
        raise TypeError(f"{cls.__name__} cannot be instantiated.")


class InvitationStatus(StrEnum):
    """Status of a federation invitation."""

    PENDING = "pending"
    ACCEPTED = "accepted"
    REJECTED = "rejected"
    REVOKED = "revoked"
    EXPIRED = "expired"


class RunType(StrEnum):
    """Supported run types."""

    SERVER_APP = "serverapp"
    SIMULATION = "simulation"


class RunTime(StrEnum):
    """Supported runtimes."""

    DEPLOYMENT = "deployment"
    SIMULATION = "simulation"


class TaskType(StrEnum):
    """Supported task types."""

    SERVER_APP = "flwr-serverapp"
    CLIENT_APP = "flwr-clientapp"
    SIMULATION = "flwr-simulation"
    AGENT_APP = "flwr-agentapp"
    MODEL = "flwr-model"
    CONNECTOR = "flwr-connector"


TASK_TYPES_REQUIRING_FAB_HASH: frozenset[TaskType] = frozenset(
    {
        TaskType.SERVER_APP,
        TaskType.CLIENT_APP,
        TaskType.AGENT_APP,
    }
)
TASK_TYPES_REQUIRING_MODEL_REF: frozenset[TaskType] = frozenset({TaskType.MODEL})
TASK_TYPES_REQUIRING_CONNECTOR_REF: frozenset[TaskType] = frozenset(
    {TaskType.CONNECTOR}
)


class ActionType(StrEnum):
    """Supported control action types."""

    REGISTER_SUPERNODE = "register_supernode"
    START_RUN = "start_run"
    CREATE_FEDERATION = "create_federation"
    CREATE_INVITATION = "create_invitation"
    ACCEPT_INVITATION = "accept_invitation"
