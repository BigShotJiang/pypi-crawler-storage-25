"""NEO_JAX package."""

import os

# Ensure double precision by default for physics fidelity.
# Users can disable via NEO_JAX_ENABLE_X64=0 or JAX_ENABLE_X64=0.
if os.getenv("JAX_ENABLE_X64") is None:
    enable_x64 = os.getenv("NEO_JAX_ENABLE_X64", "1").strip().lower()
    if enable_x64 not in {"0", "false", "no", "off"}:
        try:  # pragma: no cover - defensive in case jax isn't available yet
            import jax

            if not jax.config.jax_enable_x64:
                jax.config.update("jax_enable_x64", True)
        except Exception:
            pass

from ._version import __version__
from .api import load_boozmn, run_boozer, run_booz_xform, run_boozmn, run_neo
from .config import NeoConfig
from .data_models import BoozerData, NeoInputs, NeoOutputs, VmecData
from .driver import run_neo_from_boozer, run_neo_from_boozmn
from .io import booz_xform_to_boozerdata, booz_xform_to_boozerdata_jax, read_boozmn
from .plotting import plot_epsilon_effective
from .pipeline import (
    booz_xform_from_vmec_wout,
    booz_xform_from_vmec_state_jax,
    build_vmec_boozer_neo_jax,
    run_boozer_to_neo,
    run_vmec_boozer_neo,
    run_vmec_boozer_neo_jax,
)
from .workflow import SurfaceProblem, build_surface_problem
from .results import NeoResults, NeoSurfaceResult, neo_outputs_to_results

__all__ = [
    "__version__",
    "VmecData",
    "BoozerData",
    "NeoInputs",
    "NeoOutputs",
    "NeoConfig",
    "NeoResults",
    "NeoSurfaceResult",
    "neo_outputs_to_results",
    "read_boozmn",
    "booz_xform_to_boozerdata",
    "booz_xform_to_boozerdata_jax",
    "run_neo_from_boozer",
    "run_neo_from_boozmn",
    "load_boozmn",
    "run_boozmn",
    "run_boozer",
    "run_booz_xform",
    "run_neo",
    "plot_epsilon_effective",
    "SurfaceProblem",
    "build_surface_problem",
    "run_boozer_to_neo",
    "run_vmec_boozer_neo",
    "booz_xform_from_vmec_wout",
    "booz_xform_from_vmec_state_jax",
    "build_vmec_boozer_neo_jax",
    "run_vmec_boozer_neo_jax",
]
