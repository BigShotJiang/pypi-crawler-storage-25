# orze-pro — Autopilot for GPU Experiments

[![PyPI](https://img.shields.io/pypi/v/orze-pro)](https://pypi.org/project/orze-pro/)
[![Requires](https://img.shields.io/badge/requires-orze%20%E2%89%A53.0-green)](https://pypi.org/project/orze/)

The intelligence layer for [orze](https://github.com/warlockee/orze).

**orze** (open source) is a complete GPU experiment orchestration tool:
scheduling, leaderboard, notifications, retrospection, analysis, admin dashboard,
and **Smart Suggestions** (rule-based idea generation that keeps GPUs busy).

**orze-pro** adds **autopilot**: LLM-powered research agents that propose ideas,
auto-fix failures, and evolve code on plateaus — so experiments run while you sleep.

## Install

```bash
pip install orze          # open-source orchestrator
pip install orze-pro      # adds autopilot
```

## What's Included

| Feature | orze (free) | + orze-pro |
|---------|:-----------:|:----------:|
| GPU scheduling & multi-node | ✓ | ✓ |
| Idea queue (ideas.md + SQLite) | ✓ | ✓ |
| Hyperparameter sweep (Cartesian product) | ✓ | ✓ |
| Leaderboard report | ✓ | ✓ |
| Telegram/Slack notifications (rich) | ✓ | ✓ |
| Admin dashboard & MCP server | ✓ | ✓ |
| Retrospection (plateau detection) | ✓ | ✓ |
| Cross-experiment regression analysis | ✓ | ✓ |
| Failure analysis & categorization | ✓ | ✓ |
| Checkpoint GC | ✓ | ✓ |
| Sealed eval protection | ✓ | ✓ |
| Service watchdog (auto-restart) | ✓ | ✓ |
| Smart Suggestions (rule-based ideas) | ✓ | ✓ |
| **Autonomous research agents** (Gemini/GPT/Claude) | | ✓ |
| **Auto-fix failed experiments** | | ✓ |
| **Code evolution on plateau** | | ✓ |
| **Meta-research (strategy adjustment)** | | ✓ |
| **Interactive Telegram/Slack bot** | | ✓ |

## Smart Suggestions vs Research Agents

orze free includes **Smart Suggestions** — rule-based idea generation that keeps your GPUs busy by generating parameter variations, regression fixes, and tradeoff sweeps. No API key needed.

orze-pro replaces Smart Suggestions with **Research Agents** — LLM-powered agents that read all your results, form hypotheses, and design novel experiments. They don't just try ±5% variations — they reason about *why* a dataset regressed and propose targeted fixes.

| | Smart Suggestions (free) | Research Agents (pro) |
|---|---|---|
| How | Rule-based: perturbations, scale sweeps | LLM-driven: reads results, forms hypotheses |
| Requires API key | No | Yes |
| Finds ±10% improvements | Yes | Yes |
| Discovers new approaches | No | Yes |
| Fixes failures | No | Yes (auto-diagnose + patch) |
| Evolves code | No | Yes (modifies train script) |

## How It Works

```bash
# Without pro (Smart Suggestions):
orze -c orze.yaml
# ✓ Runs your experiments + auto-generated parameter variations
# ✓ Reports results, detects plateaus, analyzes regressions
# ✓ Smart Suggestions keeps GPUs busy with systematic exploration

# With pro (Research Agents):
pip install orze-pro
orze -c orze.yaml
# ✓ Everything above, PLUS:
# ✓ Research agent reads results and proposes novel ideas
# ✓ Auto-fixes failures and retries
# ✓ Evolves train script when stuck on a plateau
# ✓ You sleep. Experiments run.
```

Zero config change — same `orze.yaml`. Pro features activate automatically.

## Compatibility

| orze | orze-pro | Notes |
|------|----------|-------|
| 3.0.x | 0.1.x | Current release |
| 2.x | — | All features built-in (no pro needed) |

## License

Proprietary. Contact support@orze.ai for licensing.
