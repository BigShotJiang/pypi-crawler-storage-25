"""MoE-PolicyLang experts backend for HuggingFace Transformers.

Registers a ``"moe_policylang"`` experts implementation via HF's official
``ExpertsInterface`` API.  When active, expert weights live on CPU and
are copied to GPU on-demand based on the DSL policy's cache decisions.

This is NOT monkey-patching — it uses the same extension mechanism that
HF's own ``batched_mm`` and ``grouped_mm`` backends use.

Performance optimizations (v1.2.3+):
    - **Pre-allocated GPU pool**: expert-shaped buffers allocated once at
      init; transfers use ``copy_()`` into existing slots (no CUDA malloc).
    - **Batched hook call**: one ``on_layer_batch()`` per layer instead
      of one ``on_layer()`` per token, eliminating per-token Python overhead.
    - **Explicit eviction**: pool slots are released (not GC'd), preventing
      memory fragmentation and enabling higher cache capacities.
    - **Double-buffered async**: prefetch transfers run on a dedicated CUDA
      stream using pool slots, overlapping with compute.

Integration flow:
    1. ``attach()`` registers the backend and sets
       ``config._experts_implementation = "moe_policylang"``
    2. Each MoE layer's ``Experts.forward()`` dispatches to our backend
    3. Our backend:
       a. Feeds expert selections to the PolicyHook (batched)
       b. Copies needed expert slices from CPU → GPU (pool slots)
       c. Runs computation on GPU using the standard eager loop
       d. Eviction callback releases pool slots (no GC delay)
"""

from __future__ import annotations

import time
from typing import TYPE_CHECKING, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

if TYPE_CHECKING:
    from moe_policylang.integrations.weight_placement import WeightPlacementManager
    from moe_policylang.integrations.gpu_expert_pool import GPUExpertPool


def _is_quantized_experts(experts_mod: nn.Module) -> bool:
    """Check if an experts module uses per-expert quantized sub-modules.

    Quantized models may have individual expert modules with w1/w2/w3
    sub-modules instead of fused gate_up_proj/down_proj tensors.
    """
    # Check if module is a ModuleList with sub-modules that have w1/w2/w3
    if hasattr(experts_mod, '0') or (hasattr(experts_mod, '__getitem__') and len(list(experts_mod.children())) > 0):
        first_child = next(iter(experts_mod.children()), None)
        if first_child is not None and hasattr(first_child, 'w1'):
            return True
    return False


def _move_expert_to_device(expert_mod: nn.Module, device) -> None:
    """Move all parameters and buffers of an expert module to a device."""
    for p in expert_mod.parameters():
        if not p.is_meta:
            p.data = p.data.to(device, non_blocking=True)
    for b in expert_mod.buffers():
        if not b.is_meta:
            b.data = b.data.to(device, non_blocking=True)


def _expert_byte_size(expert_mod: nn.Module) -> int:
    """Calculate the total byte size of an expert module's parameters."""
    total = 0
    for p in expert_mod.parameters():
        if not p.is_meta:
            total += p.numel() * p.element_size()
    return total


def _moe_policylang_experts_forward(
    self: nn.Module,
    hidden_states: torch.Tensor,
    top_k_index: torch.Tensor,
    top_k_weights: torch.Tensor,
) -> torch.Tensor:
    """Policy-controlled expert offloading forward.

    This replaces the default eager loop with one that:
    - Feeds router decisions to the MoE-PolicyLang policy (batched)
    - Copies only needed expert weight slices from CPU to GPU (pooled)
    - Runs computation identically to HF's eager implementation

    Supports both fused (fp16) and per-expert quantized layouts.
    """
    ctx = self._moe_policylang_ctx
    is_quantized = ctx.get("is_quantized", False)

    if is_quantized:
        return _quantized_experts_forward(self, hidden_states, top_k_index, top_k_weights)
    return _fused_experts_forward(self, hidden_states, top_k_index, top_k_weights)


def _quantized_experts_forward(
    self: nn.Module,
    hidden_states: torch.Tensor,
    top_k_index: torch.Tensor,
    top_k_weights: torch.Tensor,
) -> torch.Tensor:
    """Forward for per-expert quantized modules.

    Each expert is a module with w1 (gate), w2 (down), w3 (up) sub-modules.
    We move the entire expert module to GPU, compute using its forward, then
    optionally leave it cached.
    """
    ctx = self._moe_policylang_ctx
    mgr: WeightPlacementManager = ctx["mgr"]
    layer_idx: int = ctx["layer_idx"]
    gpu_device: torch.device = ctx["gpu_device"]
    expert_bytes: int = ctx["expert_bytes"]

    # -- 1. Feed expert selections to the policy (BATCHED) --
    mgr._current_layer_idx = layer_idx
    idx_cpu = top_k_index.cpu()
    wt_cpu = top_k_weights.cpu()
    all_selected = [idx_cpu[t].tolist() for t in range(idx_cpu.shape[0])]
    all_scores = [[float(w) for w in wt_cpu[t]] for t in range(wt_cpu.shape[0])]
    mgr.hook.on_layer_batch(
        layer_idx, all_selected,
        all_scores=all_scores,
        expert_size_gb=expert_bytes / 1e9,
    )

    # -- 2. Determine unique experts and move to GPU --
    needed_experts = top_k_index.unique().cpu().tolist()
    gpu_cache = ctx["gpu_cache"]  # {expert_id: True} — tracks which are on GPU

    for eid in needed_experts:
        if eid not in gpu_cache:
            t0 = time.perf_counter()
            expert_mod = self[eid]
            _move_expert_to_device(expert_mod, gpu_device)
            torch.cuda.synchronize(gpu_device)
            elapsed = time.perf_counter() - t0
            gpu_cache[eid] = True
            mgr.stats.cpu_to_gpu_transfers += 1
            mgr.stats.bytes_transferred += expert_bytes
            mgr.stats.transfer_time_s += elapsed
            mgr._on_gpu.add((layer_idx, eid))

    # -- 3. Compute using quantized module forward --
    final_hidden_states = torch.zeros_like(hidden_states)
    expert_mask = F.one_hot(top_k_index, num_classes=self.num_experts)
    expert_mask = expert_mask.permute(2, 1, 0)  # [num_experts, top_k, tokens]
    expert_hit = torch.greater(expert_mask.sum(dim=(-1, -2)), 0).nonzero()

    for expert_idx in expert_hit:
        expert_idx = expert_idx[0].item()
        if expert_idx == self.num_experts:
            continue

        top_k_pos, token_idx = torch.where(expert_mask[expert_idx])
        current_state = hidden_states[token_idx]

        # Use the quantized expert module's forward (handles dequantization)
        expert_mod = self[expert_idx]
        gate = expert_mod.w1(current_state)
        up = expert_mod.w3(current_state)
        current_hidden_states = self.act_fn(gate) * up
        current_hidden_states = expert_mod.w2(current_hidden_states)
        current_hidden_states = current_hidden_states * top_k_weights[token_idx, top_k_pos, None]
        final_hidden_states.index_add_(
            0, token_idx, current_hidden_states.to(final_hidden_states.dtype)
        )

    # -- 4. Async prefetch for quantized --
    atm = mgr._atm
    if atm is not None and hasattr(mgr.hook, 'prefetcher'):
        next_layer = layer_idx + 1
        if next_layer < getattr(mgr.accessor, 'num_layers', float('inf')):
            predicted = mgr.hook.prefetcher.predict(
                layer_idx, list(needed_experts)
            )
            for pred_eid in predicted:
                pred_key = (next_layer, pred_eid)
                if pred_key not in mgr._on_gpu:
                    # For quantized, prefetch = move module to GPU
                    pass  # TODO: async module move

    mgr.stats.forward_calls += 1
    return final_hidden_states


def _fused_experts_forward(
    self: nn.Module,
    hidden_states: torch.Tensor,
    top_k_index: torch.Tensor,
    top_k_weights: torch.Tensor,
) -> torch.Tensor:
    """Forward for fused (fp16) expert tensors (gate_up_proj/down_proj)."""
    ctx = self._moe_policylang_ctx
    mgr: WeightPlacementManager = ctx["mgr"]
    layer_idx: int = ctx["layer_idx"]
    gpu_device: torch.device = ctx["gpu_device"]
    expert_bytes: int = ctx["expert_bytes"]
    pool: Optional["GPUExpertPool"] = ctx.get("pool")

    # -- 1. Feed expert selections to the policy (BATCHED) --
    # Single CPU transfer + one hook call instead of N per-token calls.
    mgr._current_layer_idx = layer_idx
    idx_cpu = top_k_index.cpu()
    wt_cpu = top_k_weights.cpu()
    all_selected = [idx_cpu[t].tolist() for t in range(idx_cpu.shape[0])]
    all_scores = [[float(w) for w in wt_cpu[t]] for t in range(wt_cpu.shape[0])]
    mgr.hook.on_layer_batch(
        layer_idx, all_selected,
        all_scores=all_scores,
        expert_size_gb=expert_bytes / 1e9,
    )

    # -- 2. Determine unique experts needed and load to GPU --
    needed_experts = top_k_index.unique().cpu().tolist()
    gpu_cache = ctx["gpu_cache"]  # {expert_id: {"gate_up": Tensor, "down": Tensor}}
    atm = mgr._atm  # AsyncTransferManager or None

    for eid in needed_experts:
        if eid not in gpu_cache:
            # Check async transfer manager first
            if atm is not None:
                gpu_tensors = atm.ensure_ready(layer_idx, eid)
                if gpu_tensors is not None:
                    gpu_cache[eid] = {
                        "gate_up": gpu_tensors.get("gate_up", gpu_tensors.get("param_0")),
                        "down": gpu_tensors.get("down", gpu_tensors.get("param_1")),
                    }
                    mgr.stats.cpu_to_gpu_transfers += 1
                    mgr.stats.bytes_transferred += expert_bytes
                    mgr._on_gpu.add((layer_idx, eid))
                    continue

            # Transfer via pool (copy_) or fallback (.to)
            t0 = time.perf_counter()
            if pool is not None:
                try:
                    gpu_cache[eid] = pool.load(
                        layer_idx, eid,
                        self.gate_up_proj[eid],
                        self.down_proj[eid],
                        non_blocking=True,
                    )
                except RuntimeError:
                    # Pool full — fallback to allocation
                    gpu_cache[eid] = {
                        "gate_up": self.gate_up_proj[eid].to(gpu_device, non_blocking=True),
                        "down": self.down_proj[eid].to(gpu_device, non_blocking=True),
                    }
            else:
                gpu_cache[eid] = {
                    "gate_up": self.gate_up_proj[eid].to(gpu_device, non_blocking=True),
                    "down": self.down_proj[eid].to(gpu_device, non_blocking=True),
                }
            torch.cuda.synchronize(gpu_device)
            elapsed = time.perf_counter() - t0
            mgr.stats.cpu_to_gpu_transfers += 1
            mgr.stats.bytes_transferred += expert_bytes
            mgr.stats.transfer_time_s += elapsed
            mgr._on_gpu.add((layer_idx, eid))

            # Register with ATM so it knows about this sync transfer
            if atm is not None:
                atm.mark_ready(layer_idx, eid, gpu_cache[eid])

    # -- 3. Compute (same as HF eager loop) --
    final_hidden_states = torch.zeros_like(hidden_states)
    expert_mask = F.one_hot(top_k_index, num_classes=self.num_experts)
    expert_mask = expert_mask.permute(2, 1, 0)  # [num_experts, top_k, tokens]
    expert_hit = torch.greater(expert_mask.sum(dim=(-1, -2)), 0).nonzero()

    for expert_idx in expert_hit:
        expert_idx = expert_idx[0].item()
        if expert_idx == self.num_experts:
            continue

        top_k_pos, token_idx = torch.where(expert_mask[expert_idx])
        current_state = hidden_states[token_idx]

        # Use GPU-cached expert weights
        cached = gpu_cache[expert_idx]
        gate, up = F.linear(current_state, cached["gate_up"]).chunk(2, dim=-1)
        current_hidden_states = self.act_fn(gate) * up
        current_hidden_states = F.linear(current_hidden_states, cached["down"])
        current_hidden_states = current_hidden_states * top_k_weights[token_idx, top_k_pos, None]
        final_hidden_states.index_add_(
            0, token_idx, current_hidden_states.to(final_hidden_states.dtype)
        )

    # -- 4. Async prefetch: start transferring predicted experts for next layer --
    if atm is not None and hasattr(mgr.hook, 'prefetcher'):
        next_layer = layer_idx + 1
        if next_layer < getattr(mgr.accessor, 'num_layers', float('inf')):
            predicted = mgr.hook.prefetcher.predict(
                layer_idx, list(needed_experts)
            )
            for pred_eid in predicted:
                pred_key = (next_layer, pred_eid)
                if pred_key not in mgr._on_gpu and pred_eid not in gpu_cache:
                    cpu_tensors = {
                        "gate_up": self.gate_up_proj[pred_eid],
                        "down": self.down_proj[pred_eid],
                    }
                    size_bytes = expert_bytes
                    atm.start_transfer(next_layer, pred_eid, cpu_tensors, size_bytes)

    mgr.stats.forward_calls += 1
    return final_hidden_states


def _evict_from_gpu_cache(ctx: dict, expert_id: int) -> None:
    """Called by the cache eviction callback to free GPU memory."""
    gpu_cache = ctx["gpu_cache"]
    pool: Optional["GPUExpertPool"] = ctx.get("pool")
    if expert_id in gpu_cache:
        if ctx.get("is_quantized"):
            # Move expert module back to CPU
            experts_mod = ctx["experts_mod"]
            _move_expert_to_device(experts_mod[expert_id], "cpu")
        elif pool is not None:
            # Release slot back to pool — no GC delay, buffer reused
            pool.release(ctx["layer_idx"], expert_id)
        del gpu_cache[expert_id]


def register_backend() -> None:
    """Register the 'moe_policylang' experts backend with HuggingFace."""
    try:
        from transformers.integrations.moe import ExpertsInterface
        ExpertsInterface.register("moe_policylang", _moe_policylang_experts_forward)
    except ImportError:
        raise ImportError(
            "HuggingFace Transformers >= 4.51 required for experts backend. "
            "Install with: pip install transformers>=4.51"
        )


def _materialize_to_cpu(module: nn.Module, attr_name: str) -> None:
    """Ensure a module attribute is a real CPU tensor, handling meta devices.

    accelerate >= 1.13 may leave CPU-mapped parameters as meta-device stubs.
    We can't assign .data to a meta Parameter (PyTorch rejects the type
    mismatch), so we replace the attribute with a new Parameter/tensor.
    """
    param = getattr(module, attr_name)
    if param.device.type == "cpu":
        return  # Already materialized on CPU — nothing to do
    if param.device.type == "meta":
        # Meta tensors: check accelerate's offload hooks for real weights
        cpu_data = None
        hook = getattr(module, "_hf_hook", None)
        if hook is not None:
            weights_map = getattr(hook, "weights_map", None)
            if weights_map is not None and attr_name in weights_map:
                cpu_data = weights_map[attr_name]
        if cpu_data is None:
            cpu_data = torch.empty(param.shape, dtype=param.dtype, device="cpu")
        # Replace the attribute entirely (can't assign .data on meta param)
        new_param = torch.nn.Parameter(cpu_data, requires_grad=False)
        setattr(module, attr_name, new_param)
    else:
        # GPU tensor — move to CPU
        param.data = param.data.cpu()


def install_backend(
    model: nn.Module,
    mgr: "WeightPlacementManager",
) -> list[dict]:
    """Activate the moe_policylang backend on a loaded model.

    1. Moves expert weight tensors to CPU
    2. Attaches per-layer context to each Experts module
    3. Sets config._experts_implementation = "moe_policylang"

    Returns the list of per-layer context dicts (for cleanup).
    """
    register_backend()

    accessor = mgr.accessor
    gpu_device = mgr.gpu_device
    contexts = []

    # Find all Experts modules and attach context
    layers = accessor._layers
    for layer_idx in accessor.moe_layer_indices:
        moe_block = accessor._get_moe_block(layer_idx)
        experts_mod = moe_block.experts

        is_quantized = _is_quantized_experts(experts_mod)

        if is_quantized:
            # Quantized: per-expert modules with w1/w2/w3 sub-modules
            # Ensure all experts are on CPU
            for i in range(len(list(experts_mod.children()))):
                _move_expert_to_device(experts_mod[i], "cpu")

            # Per-expert byte size from first expert
            expert_bytes = _expert_byte_size(experts_mod[0])

            ctx = {
                "mgr": mgr,
                "layer_idx": layer_idx,
                "gpu_device": gpu_device,
                "expert_bytes": expert_bytes,
                "gpu_cache": {},  # {expert_id: True}
                "is_quantized": True,
                "experts_mod": experts_mod,
                "pool": None,
            }
        else:
            # Fused: gate_up_proj/down_proj tensors
            # Move expert weights to CPU (handle meta/disk-offloaded tensors)
            _materialize_to_cpu(experts_mod, "gate_up_proj")
            _materialize_to_cpu(experts_mod, "down_proj")

            # Per-expert byte size
            gate_up_bytes = experts_mod.gate_up_proj[0].numel() * experts_mod.gate_up_proj[0].element_size()
            down_bytes = experts_mod.down_proj[0].numel() * experts_mod.down_proj[0].element_size()
            expert_bytes = gate_up_bytes + down_bytes

            # Create GPU expert pool for this layer if capacity > 0
            pool = None
            cache_capacity = getattr(mgr.hook, 'cache', None)
            if cache_capacity is not None:
                cap = getattr(cache_capacity, 'capacity', 0)
                if cap > 0:
                    try:
                        from moe_policylang.integrations.gpu_expert_pool import GPUExpertPool
                        pool = GPUExpertPool(
                            capacity=cap,
                            gate_up_shape=tuple(experts_mod.gate_up_proj[0].shape),
                            down_shape=tuple(experts_mod.down_proj[0].shape),
                            dtype=experts_mod.gate_up_proj.dtype,
                            device=gpu_device,
                        )
                    except Exception:
                        pool = None  # Fallback to dynamic allocation

            ctx = {
                "mgr": mgr,
                "layer_idx": layer_idx,
                "gpu_device": gpu_device,
                "expert_bytes": expert_bytes,
                "gpu_cache": {},  # {expert_id: {"gate_up": Tensor, "down": Tensor}}
                "is_quantized": False,
                "pool": pool,   # GPUExpertPool or None
            }

        experts_mod._moe_policylang_ctx = ctx
        contexts.append(ctx)

    # Install eviction callback: when the policy cache evicts an expert,
    # free its GPU tensor copies.  We override the method directly on the
    # cache so it fires for every eviction.
    def _evict_handler(expert_id: int):
        # Evict from ALL layers' GPU caches — the global cache doesn't
        # track which layer an expert was loaded for.
        evicted_any = False
        for ctx in contexts:
            if expert_id in ctx["gpu_cache"]:
                _evict_from_gpu_cache(ctx, expert_id)
                key = (ctx["layer_idx"], expert_id)
                mgr._on_gpu.discard(key)
                evicted_any = True
        if evicted_any:
            mgr.stats.gpu_to_cpu_transfers += 1
        # Also evict from async transfer manager
        if mgr._atm is not None:
            mgr._atm.evict_expert_all_layers(expert_id)

    cache = mgr.hook.cache
    if hasattr(cache, 'on_evict'):
        cache.on_evict = _evict_handler
    if hasattr(cache, 'primary') and hasattr(cache.primary, 'on_evict'):
        cache.primary.on_evict = _evict_handler
    if hasattr(cache, 'secondary') and hasattr(cache.secondary, 'on_evict'):
        cache.secondary.on_evict = _evict_handler

    # Activate the backend
    model.config._experts_implementation = "moe_policylang"

    return contexts


def uninstall_backend(model: nn.Module, contexts: list[dict]) -> None:
    """Revert to default experts implementation."""
    model.config._experts_implementation = "eager"
    for ctx in contexts:
        ctx["gpu_cache"].clear()
    # Expert weights remain on CPU — caller can move back if needed
