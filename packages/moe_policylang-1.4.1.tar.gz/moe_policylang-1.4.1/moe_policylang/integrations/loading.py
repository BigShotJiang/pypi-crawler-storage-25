"""Expert-aware model loading for memory-constrained GPUs.

When a MoE model exceeds available VRAM, standard ``device_map="auto"`` fails
because it doesn't understand the MoE structure — it treats expert layers the
same as attention layers.

This module provides ``load_moe_model()``, which builds a custom device_map
that places the model *skeleton* (embeddings, attention, norms) on GPU and
*expert weights* on CPU.  MoE-PolicyLang then manages expert placement at
runtime via the DSL policy.

This is the same approach used by vLLM, MoE-Infinity, and DeepSpeed-MoE —
integrate expert offloading into the loading path rather than treating it
as a post-load optimization.

Usage:
    import moe_policylang
    from moe_policylang.integrations.loading import load_moe_model

    model, tokenizer = load_moe_model("mistralai/Mixtral-8x7B-Instruct-v0.1")
    mgr = moe_policylang.attach(model, policy_dsl)
    output = model.generate(...)
"""

from __future__ import annotations

from typing import Any, Dict, Optional, Tuple

import torch


class QuantBackendUnavailableError(RuntimeError):
    """Raised when a quantized model is requested but the backend is unavailable."""

    def __init__(self, model_id: str, *, quant_method: str, reason: str):
        super().__init__(
            f"Cannot load '{model_id}' ({quant_method} quantized).\n"
            f"\n"
            f"{reason}\n"
            f"\n"
            f"Alternatively, use a non-quantized (fp16/bf16) model with load_moe_model()."
        )


def _check_quant_backend(quant_method: str, model_id: str) -> None:
    """Reject quantized models — direct loading is not supported.

    Quantized models (GPTQ, AWQ) should be served via vLLM instead.
    load_moe_model() only supports fp16 models.

    Raises:
        QuantBackendUnavailableError: with guidance to use vLLM.
    """
    raise QuantBackendUnavailableError(
        model_id,
        quant_method=quant_method,
        reason=(
            f"{quant_method.upper()} models are not supported by load_moe_model().\n"
            "\n"
            "Use the vLLM integration for quantized models:\n"
            "\n"
            "  from moe_policylang.integrations.vllm_backend import VLLMPolicyRunner\n"
            "\n"
            "  runner = VLLMPolicyRunner(\n"
            f"      model='{model_id}',\n"
            f"      quantization='{quant_method}',\n"
            "      policy_dsl='policy p {{ cache {{ capacity = 8  eviction = lru }} }}',\n"
            "  )\n"
            "  results = runner.generate([...])\n"
            "\n"
            "Install: pip install moe-policylang[vllm]"
        ),
    )


def _is_expert_key(key: str) -> bool:
    """Check if a state_dict key belongs to an expert module.

    Expert keys contain patterns like:
      - .block_sparse_moe.experts.  (Mixtral)
      - .mlp.experts.               (Qwen, OLMoE)
      - .moe.experts.               (generic)

    Works with any parameter suffix (.weight, .qweight, .scales, etc.)
    because it matches on the module path, not the parameter name.
    """
    expert_markers = [
        ".block_sparse_moe.experts.",
        ".mlp.experts.",
        ".moe.experts.",
        ".experts.gate_up_proj",
        ".experts.down_proj",
        ".experts.gate_proj",
        ".experts.up_proj",
    ]
    return any(marker in key for marker in expert_markers)



def _is_expert_module(name: str) -> bool:
    """Check if a module path belongs to an expert sub-module."""
    expert_markers = [
        ".block_sparse_moe.experts.",
        ".mlp.experts.",
        ".moe.experts.",
    ]
    return any(marker in f".{name}." or name.endswith(marker.rstrip("."))
               for marker in expert_markers)


def build_expert_device_map(
    model_id: str,
    gpu_device: int = 0,
    *,
    dtype: torch.dtype = torch.float16,
    trust_remote_code: bool = False,
) -> Dict[str, Any]:
    """Build a device_map that places expert weights on CPU, everything else on GPU.

    Uses **module-level** keys which work regardless of parameter name
    suffixes (e.g., ``.weight``, ``.qweight``, ``.scales``).  This makes
    the device map compatible with fp16 models regardless of parameter
    name suffixes used by different model architectures.

    Args:
        model_id: HuggingFace model ID or local path.
        gpu_device: CUDA device index.
        dtype: Weight dtype (used for size estimation).
        trust_remote_code: Whether to trust remote code for model config.

    Returns:
        A dict mapping module names to devices, suitable for
        ``from_pretrained(device_map=...)``.
    """
    from transformers import AutoConfig, AutoModelForCausalLM

    config = AutoConfig.from_pretrained(
        model_id, trust_remote_code=trust_remote_code
    )

    with torch.device("meta"):
        model = AutoModelForCausalLM.from_config(
            config, trust_remote_code=trust_remote_code
        )

    # Build module-level device map.  Expert modules and all their
    # descendants go to CPU; everything else goes to GPU.
    # Map at multiple levels so that parameters added during quantization
    # preprocessing (e.g., gate_up_proj) inherit CPU from their ancestor.
    device_map: Dict[str, Any] = {"": gpu_device}
    for name, module in model.named_modules():
        if not name:
            continue
        if _is_expert_module(name):
            device_map[name] = "cpu"

    del model
    return device_map


def load_moe_model(
    model_id: str,
    *,
    gpu_device: int = 0,
    dtype: torch.dtype = torch.float16,
    trust_remote_code: bool = False,
    tokenizer_id: Optional[str] = None,
) -> Tuple[Any, Any]:
    """Load a MoE model with expert weights on CPU, skeleton on GPU.

    Supports **fp16 models only**.  For quantized models (GPTQ, AWQ),
    use the vLLM integration instead (``VLLMPolicyRunner``).

    The expert-aware device map places the model skeleton (embeddings,
    attention, norms, gates) on GPU and expert weight tensors on CPU.
    MoE-PolicyLang then manages expert placement at runtime via the DSL policy.

    Args:
        model_id: HuggingFace model ID or local path (fp16 only).
        gpu_device: CUDA device index.
        dtype: Weight dtype (default: torch.float16).
        trust_remote_code: Whether to trust remote code.
        tokenizer_id: Override tokenizer ID (defaults to model_id).

    Returns:
        (model, tokenizer) tuple, ready for ``moe_policylang.attach()``.

    Raises:
        QuantBackendUnavailableError: If the model is quantized (GPTQ/AWQ).

    Examples:
        model, tok = load_moe_model("Qwen/Qwen1.5-MoE-A2.7B")
        model, tok = load_moe_model("mistralai/Mixtral-8x7B-Instruct-v0.1")
    """
    from transformers import AutoConfig, AutoModelForCausalLM, AutoTokenizer

    config = AutoConfig.from_pretrained(
        model_id, trust_remote_code=trust_remote_code
    )

    # Detect and reject pre-quantized models
    quant_cfg = getattr(config, "quantization_config", None)
    if quant_cfg is not None:
        quant_method = (
            quant_cfg.get("quant_method", "unknown")
            if isinstance(quant_cfg, dict)
            else getattr(quant_cfg, "quant_method", "unknown")
        )
        _check_quant_backend(quant_method, model_id)

    print(f"Loading {model_id}...")

    # fp16: use expert-aware device_map
    device_map = build_expert_device_map(
        model_id,
        gpu_device=gpu_device,
        dtype=dtype,
        trust_remote_code=trust_remote_code,
    )
    gpu_keys = sum(1 for v in device_map.values() if v == gpu_device)
    cpu_keys = sum(1 for v in device_map.values() if v == "cpu")
    print(f"  {gpu_keys} modules on GPU, {cpu_keys} expert modules on CPU")

    kw = {
        "device_map": device_map,
        "low_cpu_mem_usage": True,
        "trust_remote_code": trust_remote_code,
        "torch_dtype": dtype,
    }
    print(f"  Loading with device map...")
    model = AutoModelForCausalLM.from_pretrained(model_id, **kw)
    model.eval()

    gpu_gb = torch.cuda.memory_allocated(gpu_device) / 1e9
    print(f"  Loaded: {gpu_gb:.1f} GB on GPU (experts on CPU)")

    tok_id = tokenizer_id or model_id
    tokenizer = AutoTokenizer.from_pretrained(tok_id, trust_remote_code=trust_remote_code)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    return model, tokenizer
