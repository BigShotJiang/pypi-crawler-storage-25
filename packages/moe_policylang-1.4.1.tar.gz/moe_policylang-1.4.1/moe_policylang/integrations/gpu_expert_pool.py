"""Pre-allocated GPU memory pool for expert weight tensors.

Eliminates per-transfer CUDA memory allocation by pre-allocating a fixed
number of expert-shaped GPU buffers at initialization.  Transfers use
``Tensor.copy_()`` into the pre-allocated slots instead of
``Tensor.to()`` which allocates new GPU memory each time.

The pool maintains a free-list and a mapping from (layer, expert) to
slot index, enabling O(1) allocation and deallocation.

Expected speedup: 3–5× on the transfer path by eliminating CUDA malloc
overhead and reducing memory fragmentation.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional, Tuple

import torch


@dataclass
class _PoolSlot:
    """A single pre-allocated GPU buffer slot."""
    gate_up: torch.Tensor   # Pre-allocated GPU buffer for gate+up weights
    down: torch.Tensor       # Pre-allocated GPU buffer for down weights
    occupied_by: Optional[Tuple[int, int]] = None  # (layer_idx, expert_id) or None


class GPUExpertPool:
    """Fixed-size pool of pre-allocated GPU expert weight buffers.

    Usage::

        pool = GPUExpertPool(
            capacity=32,
            gate_up_shape=(4096, 28672),
            down_shape=(14336, 4096),
            dtype=torch.float16,
            device=torch.device("cuda:0"),
        )

        # Load expert into a pool slot (copy_, no allocation)
        slot = pool.load(layer_idx=0, expert_id=3, gate_up_cpu, down_cpu)

        # Use slot.gate_up and slot.down for computation

        # Release slot back to pool on eviction
        pool.release(layer_idx=0, expert_id=3)

    All buffers are allocated once at ``__init__`` and reused throughout
    inference.  ``load()`` uses ``Tensor.copy_()`` with
    ``non_blocking=True`` to overlap with compute when called from the
    transfer CUDA stream.
    """

    def __init__(
        self,
        capacity: int,
        gate_up_shape: Tuple[int, ...],
        down_shape: Tuple[int, ...],
        dtype: torch.dtype = torch.float16,
        device: torch.device = torch.device("cuda:0"),
    ):
        self.capacity = capacity
        self.device = device
        self.dtype = dtype

        # Pre-allocate all GPU buffers
        self._slots: list[_PoolSlot] = []
        for _ in range(capacity):
            slot = _PoolSlot(
                gate_up=torch.empty(gate_up_shape, dtype=dtype, device=device),
                down=torch.empty(down_shape, dtype=dtype, device=device),
            )
            self._slots.append(slot)

        # Free-list: indices of available slots
        self._free: list[int] = list(range(capacity))

        # Mapping: (layer_idx, expert_id) → slot index
        self._occupied: Dict[Tuple[int, int], int] = {}

        # Byte size per expert (for stats)
        self.expert_bytes = (
            gate_up_shape[0] * gate_up_shape[1] * torch.finfo(dtype).bits // 8
            + down_shape[0] * down_shape[1] * torch.finfo(dtype).bits // 8
        ) if len(gate_up_shape) == 2 and len(down_shape) == 2 else 0

    @property
    def num_free(self) -> int:
        return len(self._free)

    @property
    def num_occupied(self) -> int:
        return len(self._occupied)

    def is_loaded(self, layer_idx: int, expert_id: int) -> bool:
        """Check if expert is in the pool."""
        return (layer_idx, expert_id) in self._occupied

    def get(
        self, layer_idx: int, expert_id: int
    ) -> Optional[Dict[str, torch.Tensor]]:
        """Get GPU tensors for a loaded expert, or None if not in pool."""
        key = (layer_idx, expert_id)
        if key not in self._occupied:
            return None
        slot = self._slots[self._occupied[key]]
        return {"gate_up": slot.gate_up, "down": slot.down}

    def load(
        self,
        layer_idx: int,
        expert_id: int,
        gate_up_cpu: torch.Tensor,
        down_cpu: torch.Tensor,
        non_blocking: bool = True,
    ) -> Dict[str, torch.Tensor]:
        """Copy expert weights into a pre-allocated GPU slot.

        Uses ``Tensor.copy_()`` — no GPU memory allocation occurs.

        Args:
            layer_idx: Layer index.
            expert_id: Expert index.
            gate_up_cpu: CPU tensor with gate+up projection weights.
            down_cpu: CPU tensor with down projection weights.
            non_blocking: If True, copy can overlap with compute.

        Returns:
            Dict with ``"gate_up"`` and ``"down"`` GPU tensors (views into
            the pre-allocated pool).

        Raises:
            RuntimeError: If the pool is full.
        """
        key = (layer_idx, expert_id)

        # Already loaded — just return the existing slot
        if key in self._occupied:
            slot = self._slots[self._occupied[key]]
            return {"gate_up": slot.gate_up, "down": slot.down}

        if not self._free:
            raise RuntimeError(
                f"GPUExpertPool is full ({self.capacity} slots). "
                f"Evict an expert before loading a new one."
            )

        slot_idx = self._free.pop()
        slot = self._slots[slot_idx]

        # Copy into pre-allocated buffer — no allocation!
        slot.gate_up.copy_(gate_up_cpu, non_blocking=non_blocking)
        slot.down.copy_(down_cpu, non_blocking=non_blocking)
        slot.occupied_by = key

        self._occupied[key] = slot_idx
        return {"gate_up": slot.gate_up, "down": slot.down}

    def release(self, layer_idx: int, expert_id: int) -> bool:
        """Release a slot back to the free-list.

        The GPU memory is NOT freed — it stays allocated and will be
        reused by the next ``load()`` call.  This is the whole point:
        we avoid CUDA malloc/free churn.

        Returns:
            True if the expert was in the pool and released, False if not found.
        """
        key = (layer_idx, expert_id)
        slot_idx = self._occupied.pop(key, None)
        if slot_idx is None:
            return False

        slot = self._slots[slot_idx]
        slot.occupied_by = None
        self._free.append(slot_idx)
        return True

    def release_expert_all_layers(self, expert_id: int) -> int:
        """Release an expert from all layers (for global cache eviction).

        Returns:
            Number of slots released.
        """
        to_release = [
            key for key in self._occupied if key[1] == expert_id
        ]
        for key in to_release:
            self.release(key[0], key[1])
        return len(to_release)

    def clear(self) -> None:
        """Release all slots back to the free-list."""
        self._occupied.clear()
        for i, slot in enumerate(self._slots):
            slot.occupied_by = None
        self._free = list(range(self.capacity))

    def stats(self) -> dict:
        """Pool utilization stats."""
        return {
            "capacity": self.capacity,
            "occupied": self.num_occupied,
            "free": self.num_free,
            "utilization": self.num_occupied / self.capacity if self.capacity > 0 else 0.0,
        }
