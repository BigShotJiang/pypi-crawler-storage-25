"""vLLM backend integration for MoE-PolicyLang.

Connects MoE-PolicyLang's policy layer to a vLLM-served model. Since vLLM
runs the model in a subprocess (EngineCore), this integration uses
``LLM.apply_model()`` to register routing trace collectors inside the worker,
then feeds captured routing decisions through PolicyHook after generation.

Architecture:
    ┌─────────────────────────────────────────────────────────────┐
    │  Main Process                                               │
    │  ┌──────────────┐    ┌───────────────┐    ┌─────────────┐  │
    │  │ DSL/Compiler │ -> │  PolicyHook   │ -> │   Stats     │  │
    │  └──────────────┘    └───────────────┘    └─────────────┘  │
    │         │                    ▲                               │
    │         │                    │ routing trace                 │
    │  ┌──────▼──────────────────────────────────────────────┐    │
    │  │  VLLMPolicyRunner                                   │    │
    │  │    - install_hooks() via apply_model                │    │
    │  │    - generate()                                     │    │
    │  │    - collect_trace() via apply_model                │    │
    │  │    - replay trace through PolicyHook                │    │
    │  └─────────────────────────────────────────────────────┘    │
    └─────────────────────────────────────────────────────────────┘
                            │ RPC
    ┌───────────────────────▼─────────────────────────────────────┐
    │  EngineCore Worker Process                                   │
    │  ┌───────────────────────────────────────────────────────┐  │
    │  │  Model (Qwen2MoeForCausalLM)                          │  │
    │  │    └── layers[*].mlp.gate (router)                    │  │
    │  │         └── forward_hook → _routing_trace list        │  │
    │  └───────────────────────────────────────────────────────┘  │
    └─────────────────────────────────────────────────────────────┘

Usage:
    from moe_policylang.integrations.vllm_backend import VLLMPolicyRunner

    runner = VLLMPolicyRunner(
        model="Qwen/Qwen1.5-MoE-A2.7B-Chat-GPTQ-Int4",
        policy_dsl='''
            policy demo {
                cache { capacity = 8  eviction = lru }
                prefetch { strategy = adjacent  lookahead = 1 }
                schedule { mode = gpu_only }
            }
        ''',
        quantization="gptq",
    )
    results = runner.generate(["The capital of France is"], max_tokens=20)
    print(results["text"])
    print(results["policy_stats"])
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence

import torch
import torch.nn as nn


# ---------------------------------------------------------------------------
# Routing trace data
# ---------------------------------------------------------------------------

@dataclass
class RoutingEvent:
    """A single routing decision captured from one MoE layer forward."""
    layer_idx: int
    expert_indices: List[List[int]]  # [num_tokens, top_k]
    expert_weights: List[List[float]]  # [num_tokens, top_k]


# ---------------------------------------------------------------------------
# Hook installer (runs inside vLLM worker process via apply_model)
# ---------------------------------------------------------------------------

def _install_routing_hooks(model: nn.Module) -> Dict[str, Any]:
    """Install forward hooks on MoE router layers to capture routing decisions.

    This function is sent to the vLLM worker process via apply_model().
    It finds MoE layers, registers hooks, and stores a trace buffer on the model.
    """
    # Initialize trace storage on the model
    if not hasattr(model, '_policylang_routing_trace'):
        model._policylang_routing_trace = []
    model._policylang_routing_trace.clear()

    # Find MoE router/gate modules
    hooks_installed = 0
    model_info = {"num_layers": 0, "num_experts": 0, "top_k": 0}

    for name, module in model.named_modules():
        # Match common MoE gate patterns across architectures
        # Qwen2Moe: model.layers.N.mlp.gate
        # Mixtral: model.layers.N.block_sparse_moe.gate
        # OLMoE: model.layers.N.mlp.gate
        if not (name.endswith('.gate') and 'mlp' in name or
                name.endswith('.gate') and 'moe' in name):
            continue

        # Extract layer index from name
        parts = name.split('.')
        layer_idx = None
        for i, part in enumerate(parts):
            if part == 'layers' and i + 1 < len(parts):
                try:
                    layer_idx = int(parts[i + 1])
                except ValueError:
                    continue

        if layer_idx is None:
            continue

        # Determine num_experts from gate weight shape
        if hasattr(module, 'weight') and module.weight is not None:
            num_experts = module.weight.shape[0]
            model_info["num_experts"] = max(model_info["num_experts"], num_experts)

        model_info["num_layers"] = max(model_info["num_layers"], layer_idx + 1)

        # Register hook
        def make_hook(lidx):
            def hook_fn(mod, inputs, output):
                # output = router logits [num_tokens, num_experts]
                if isinstance(output, torch.Tensor):
                    logits = output
                elif isinstance(output, tuple):
                    logits = output[0] if isinstance(output[0], torch.Tensor) else None
                else:
                    return

                if logits is None or logits.dim() < 2:
                    return

                # Compute top-k routing
                routing_weights = torch.softmax(logits, dim=-1)
                # Determine top_k from model config or default
                top_k = getattr(mod, '_policylang_top_k', 4)
                k = min(top_k, logits.shape[-1])
                weights, indices = torch.topk(routing_weights, k, dim=-1)

                # Store trace event (keep on CPU to avoid VRAM accumulation)
                model._policylang_routing_trace.append({
                    'layer_idx': lidx,
                    'indices': indices.cpu().tolist(),
                    'weights': weights.cpu().tolist(),
                })
            return hook_fn

        handle = module.register_forward_hook(make_hook(layer_idx))
        # Store handle for later removal
        if not hasattr(model, '_policylang_hook_handles'):
            model._policylang_hook_handles = []
        model._policylang_hook_handles.append(handle)
        hooks_installed += 1

    # Try to get top_k from model config
    config = getattr(model, 'config', None)
    if config is not None:
        top_k = getattr(config, 'num_experts_per_tok', None) or \
                getattr(config, 'num_selected_experts', None) or 4
        model_info["top_k"] = top_k
        # Set on gates for the hooks to use
        for name, module in model.named_modules():
            if name.endswith('.gate'):
                module._policylang_top_k = top_k
    else:
        model_info["top_k"] = 4

    model_info["hooks_installed"] = hooks_installed
    return model_info


def _collect_routing_trace(model: nn.Module) -> List[Dict]:
    """Retrieve and clear the routing trace from the model.

    Called via apply_model() after generation completes.
    """
    trace = getattr(model, '_policylang_routing_trace', [])
    # Copy and clear
    result = list(trace)
    trace.clear()
    return result


def _remove_routing_hooks(model: nn.Module) -> int:
    """Remove all installed routing hooks.

    Called via apply_model() for cleanup.
    """
    handles = getattr(model, '_policylang_hook_handles', [])
    count = len(handles)
    for h in handles:
        h.remove()
    model._policylang_hook_handles = []
    if hasattr(model, '_policylang_routing_trace'):
        del model._policylang_routing_trace
    return count


# ---------------------------------------------------------------------------
# VLLMPolicyRunner
# ---------------------------------------------------------------------------

class VLLMPolicyRunner:
    """Runs vLLM inference with MoE-PolicyLang routing observation.

    Loads a quantized MoE model via vLLM, instruments the router layers
    to capture expert selections, and replays the routing trace through
    PolicyHook to produce cache/prefetch/scheduler statistics.

    This demonstrates that the policy DSL's compiled logic produces
    meaningful scheduling decisions on real routing patterns from a
    production-grade inference engine.
    """

    def __init__(
        self,
        model: str,
        policy_dsl: str,
        quantization: str = "gptq",
        gpu_memory_utilization: float = 0.70,
        max_model_len: int = 512,
        enforce_eager: bool = True,
    ):
        self.model_name = model
        self.policy_dsl = policy_dsl
        self.quantization = quantization
        self.gpu_memory_utilization = gpu_memory_utilization
        self.max_model_len = max_model_len
        self.enforce_eager = enforce_eager

        self._llm = None
        self._model_info = None
        self._hook = None

    def _ensure_loaded(self):
        """Lazy-load model and install hooks."""
        if self._llm is not None:
            return

        # apply_model sends Python functions via RPC; vLLM needs pickle for that
        os.environ.setdefault("VLLM_ALLOW_INSECURE_SERIALIZATION", "1")

        from vllm import LLM
        self._llm = LLM(
            model=self.model_name,
            quantization=self.quantization,
            gpu_memory_utilization=self.gpu_memory_utilization,
            max_model_len=self.max_model_len,
            enforce_eager=self.enforce_eager,
        )

        # Install routing hooks inside the worker
        results = self._llm.apply_model(_install_routing_hooks)
        self._model_info = results[0] if results else {}

        # Compile the policy
        from moe_policylang.parser import parse_policy
        from moe_policylang.compiler import compile_policy
        from moe_policylang.runtime.hooks import build_hook

        policy_ir = parse_policy(self.policy_dsl)
        compiled = compile_policy(policy_ir)

        num_layers = self._model_info.get("num_layers", 24)
        num_experts = self._model_info.get("num_experts", 60)

        self._hook = build_hook(
            compiled,
            num_layers=num_layers,
            num_experts=num_experts,
        )

    def generate(
        self,
        prompts: List[str],
        max_tokens: int = 30,
        temperature: float = 0.0,
    ) -> Dict[str, Any]:
        """Generate text and collect policy statistics.

        Returns a dict with:
            - text: list of generated strings
            - policy_stats: cache/prefetch/scheduler statistics
            - routing_summary: summary of expert routing decisions
            - model_info: model architecture details
        """
        self._ensure_loaded()

        from vllm import SamplingParams

        params = SamplingParams(temperature=temperature, max_tokens=max_tokens)
        outputs = self._llm.generate(prompts, params)

        # Collect routing trace from the worker
        traces = self._llm.apply_model(_collect_routing_trace)
        trace = traces[0] if traces else []

        # Replay trace through PolicyHook
        self._hook.reset() if hasattr(self._hook, 'reset') else None
        for event in trace:
            layer_idx = event['layer_idx']
            all_indices = event['indices']  # [num_tokens, top_k]
            all_weights = event['weights']  # [num_tokens, top_k]

            # Feed batch of token routing decisions
            self._hook.on_layer_batch(
                layer_idx=layer_idx,
                all_selected=all_indices,
                all_scores=all_weights,
                expert_size_gb=0.08,  # ~80MB per expert for Qwen1.5-MoE
            )

        # Collect results
        generated_texts = [o.outputs[0].text for o in outputs]
        policy_stats = self._hook.stats_snapshot()

        # Routing summary
        unique_experts_per_layer = {}
        for event in trace:
            lidx = event['layer_idx']
            experts = set()
            for token_experts in event['indices']:
                experts.update(token_experts)
            if lidx not in unique_experts_per_layer:
                unique_experts_per_layer[lidx] = set()
            unique_experts_per_layer[lidx].update(experts)

        routing_summary = {
            "total_routing_events": len(trace),
            "layers_observed": len(unique_experts_per_layer),
            "avg_unique_experts_per_layer": (
                sum(len(v) for v in unique_experts_per_layer.values()) /
                max(len(unique_experts_per_layer), 1)
            ),
            "top_k": self._model_info.get("top_k", 4),
        }

        return {
            "text": generated_texts,
            "policy_stats": policy_stats,
            "routing_summary": routing_summary,
            "model_info": self._model_info,
        }

    def detach(self):
        """Remove hooks and clean up."""
        if self._llm is not None:
            self._llm.apply_model(_remove_routing_hooks)

    @property
    def model_info(self) -> Dict[str, Any]:
        """Model architecture info (available after first generate)."""
        self._ensure_loaded()
        return self._model_info or {}
