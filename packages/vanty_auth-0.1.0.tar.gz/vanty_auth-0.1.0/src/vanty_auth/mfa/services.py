from __future__ import annotations

from starlette.requests import Request

from vanty_auth.account.schemas import AuthFlowResult
from vanty_auth.account.services import AuthService
from vanty_auth.core.exceptions import InvalidCredentials, InvalidState, InvalidToken
from vanty_auth.core.schemas import MessageResponse
from vanty_auth.core.security import (
    decode_pending_mfa_token,
    decrypt_text,
    encrypt_text,
    generate_recovery_codes,
    generate_totp_secret,
    hash_secret,
    totp_provisioning_uri,
    utcnow,
    verify_password,
    verify_totp_code,
)
from vanty_auth.db.models import MfaAuthenticator, RecoveryCode, User
from vanty_auth.mfa.schemas import RecoveryCodesResponse, TotpEnrollmentResponse


class MfaService:
    def __init__(self, *, auth_service: AuthService) -> None:
        self.auth_service = auth_service

    @property
    def settings(self):
        return self.auth_service.settings

    @property
    def events(self):
        return self.auth_service.events

    async def enroll_totp(self, user: User) -> TotpEnrollmentResponse:
        primary = await self.auth_service.primary_email(user)
        authenticators = await MfaAuthenticator.filter(user=user, type="totp")
        auth_ids = [item.id for item in authenticators]
        if auth_ids:
            await RecoveryCode.filter(authenticator_id__in=auth_ids).delete()
        await MfaAuthenticator.filter(id__in=auth_ids, confirmed=False).delete()
        secret = generate_totp_secret()
        authenticator = await MfaAuthenticator.create(
            user=user,
            type="totp",
            secret_encrypted=encrypt_text(self.settings, secret),
            confirmed=False,
        )
        return TotpEnrollmentResponse(
            message="Confirm the generated TOTP code",
            secret=secret,
            provisioning_uri=totp_provisioning_uri(
                secret,
                email=primary.email,
                issuer=self.settings.app_name,
            ),
            authenticator_id=str(authenticator.id),
        )

    async def confirm_totp(self, user: User, *, code: str) -> RecoveryCodesResponse:
        authenticator = await MfaAuthenticator.filter(user=user, type="totp").order_by("-created_at").first()
        if not authenticator:
            raise InvalidState("No TOTP enrollment in progress")
        secret = decrypt_text(self.settings, authenticator.secret_encrypted)
        if not verify_totp_code(secret, code):
            raise InvalidCredentials("Invalid authenticator code")
        authenticator.confirmed = True
        authenticator.last_used_at = utcnow()
        await authenticator.save(update_fields=["confirmed", "last_used_at"])
        await RecoveryCode.filter(authenticator=authenticator).delete()
        codes = generate_recovery_codes()
        for code_value in codes:
            await RecoveryCode.create(authenticator=authenticator, code_hash=hash_secret(code_value))
        self.events.record("mfa.enabled", user_id=str(user.id))
        return RecoveryCodesResponse(message="MFA enabled", recovery_codes=codes)

    async def verify_totp(
        self,
        request: Request,
        *,
        mfa_token: str,
        code: str | None,
        recovery_code: str | None,
    ) -> AuthFlowResult:
        try:
            payload = decode_pending_mfa_token(self.settings, mfa_token)
        except Exception as exc:
            raise InvalidToken("Invalid MFA token") from exc
        user = await User.get(id=payload["sub"])
        authenticator = await MfaAuthenticator.filter(user=user, confirmed=True, type="totp").first()
        if not authenticator:
            raise InvalidState("MFA is not enabled")

        accepted = False
        if code:
            secret = decrypt_text(self.settings, authenticator.secret_encrypted)
            accepted = verify_totp_code(secret, code)
        elif recovery_code:
            recovery = await RecoveryCode.filter(
                authenticator=authenticator,
                code_hash=hash_secret(recovery_code.upper()),
                used_at__isnull=True,
            ).first()
            if recovery:
                recovery.used_at = utcnow()
                await recovery.save(update_fields=["used_at"])
                accepted = True
        if not accepted:
            raise InvalidCredentials("Invalid MFA verification")
        authenticator.last_used_at = utcnow()
        await authenticator.save(update_fields=["last_used_at"])
        return await self.auth_service.issue_login_response_for_user(request, user)

    async def recovery_code_status(self, user: User) -> MessageResponse:
        authenticator = await MfaAuthenticator.filter(user=user, confirmed=True, type="totp").first()
        if not authenticator:
            raise InvalidState("MFA is not enabled")
        total = await RecoveryCode.filter(authenticator=authenticator).count()
        remaining = await RecoveryCode.filter(authenticator=authenticator, used_at__isnull=True).count()
        return MessageResponse(message="Recovery code status", debug={"total": total, "remaining": remaining})

    async def regenerate_recovery_codes(self, user: User) -> RecoveryCodesResponse:
        authenticator = await MfaAuthenticator.filter(user=user, confirmed=True, type="totp").first()
        if not authenticator:
            raise InvalidState("MFA is not enabled")
        await RecoveryCode.filter(authenticator=authenticator).delete()
        codes = generate_recovery_codes()
        for code_value in codes:
            await RecoveryCode.create(authenticator=authenticator, code_hash=hash_secret(code_value))
        return RecoveryCodesResponse(message="Recovery codes regenerated", recovery_codes=codes)

    async def disable_mfa(self, user: User, *, password: str) -> MessageResponse:
        if not verify_password(password, user.password_hash):
            raise InvalidCredentials("Password is incorrect")
        authenticators = await MfaAuthenticator.filter(user=user)
        auth_ids = [item.id for item in authenticators]
        if auth_ids:
            await RecoveryCode.filter(authenticator_id__in=auth_ids).delete()
            await MfaAuthenticator.filter(id__in=auth_ids).delete()
        self.events.record("mfa.disabled", user_id=str(user.id))
        return MessageResponse(message="MFA disabled")
