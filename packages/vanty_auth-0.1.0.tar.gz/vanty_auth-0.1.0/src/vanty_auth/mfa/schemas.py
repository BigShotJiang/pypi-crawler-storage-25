from __future__ import annotations

from pydantic import BaseModel, Field, field_validator


class TotpEnrollmentResponse(BaseModel):
    message: str
    secret: str
    provisioning_uri: str
    authenticator_id: str


class RecoveryCodesResponse(BaseModel):
    message: str
    recovery_codes: list[str]


class TotpConfirmRequest(BaseModel):
    code: str = Field(min_length=6, max_length=8)


class TotpVerifyRequest(BaseModel):
    mfa_token: str
    code: str | None = None
    recovery_code: str | None = None

    @field_validator("recovery_code")
    @classmethod
    def normalize_recovery_code(cls, value: str | None) -> str | None:
        return value.upper() if value else value


class MfaDisableRequest(BaseModel):
    password: str
