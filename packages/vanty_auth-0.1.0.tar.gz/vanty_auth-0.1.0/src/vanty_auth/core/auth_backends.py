from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

from starlette.requests import Request

from vanty_auth.core.security import decode_access_token, hash_secret, utcnow
from vanty_auth.db.models import ApiKey, AuthSession, User
from vanty_auth.settings import AuthKitSettings


@dataclass(slots=True)
class AuthCredentials:
    user: User
    session: AuthSession | None
    principal_type: str
    api_key: ApiKey | None = None


class AuthBackend(Protocol):
    async def authenticate(self, request: Request) -> AuthCredentials | None: ...


class SessionAuthBackend:
    def __init__(self, settings: AuthKitSettings) -> None:
        self.settings = settings

    async def authenticate(self, request: Request) -> AuthCredentials | None:
        cookie = request.cookies.get(self.settings.session_cookie_name)
        if not cookie:
            return None
        session = await AuthSession.filter(
            session_hash=hash_secret(cookie),
            revoked_at__isnull=True,
        ).first()
        if not session or session.expires_at <= utcnow():
            return None
        user = await User.get(id=session.user_id)
        session.last_seen_at = utcnow()
        await session.save(update_fields=["last_seen_at"])
        return AuthCredentials(user=user, session=session, principal_type="user_session")


class BearerTokenBackend:
    def __init__(self, settings: AuthKitSettings) -> None:
        self.settings = settings

    async def authenticate(self, request: Request) -> AuthCredentials | None:
        auth_header = request.headers.get("authorization")
        if not auth_header or not auth_header.lower().startswith("bearer "):
            return None
        token = auth_header.split(" ", 1)[1]
        if token.startswith("ak_"):
            return None
        try:
            payload = decode_access_token(self.settings, token)
        except Exception:
            return None
        session = await AuthSession.filter(id=payload["sid"], revoked_at__isnull=True).first()
        if not session or session.expires_at <= utcnow():
            return None
        user = await User.get(id=payload["sub"])
        session.last_seen_at = utcnow()
        await session.save(update_fields=["last_seen_at"])
        return AuthCredentials(user=user, session=session, principal_type="user_session")


class ApiKeyAuthBackend:
    def __init__(self, *, api_key_service: object) -> None:
        self.api_key_service = api_key_service

    async def authenticate(self, request: Request) -> AuthCredentials | None:
        from vanty_auth.api_keys.services import ApiKeyService

        assert isinstance(self.api_key_service, ApiKeyService)
        raw = request.headers.get("x-api-key")
        if not raw:
            auth_header = request.headers.get("authorization", "")
            if auth_header.lower().startswith("bearer ak_"):
                raw = auth_header.split(" ", 1)[1]
        if not raw:
            return None
        api_key = await self.api_key_service.authenticate_api_key(raw)
        if api_key is None:
            return None
        user = await User.get(id=api_key.created_by_user_id) if api_key.created_by_user_id else None
        return AuthCredentials(
            user=user,  # type: ignore[arg-type]
            session=None,
            principal_type="api_key",
            api_key=api_key,
        )
