from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Protocol

logger = logging.getLogger(__name__)


@dataclass(slots=True)
class EmailPayload:
    to: str
    subject: str
    body: str
    meta: dict[str, str] = field(default_factory=dict)


class EmailSender(Protocol):
    async def send(self, payload: EmailPayload) -> None: ...


class MemoryEmailSender:
    def __init__(self) -> None:
        self.outbox: list[EmailPayload] = []

    async def send(self, payload: EmailPayload) -> None:
        self.outbox.append(payload)


class LoggingEmailSender:
    async def send(self, payload: EmailPayload) -> None:
        logger.info("auth-kit email to=%s subject=%s meta=%s", payload.to, payload.subject, payload.meta)
