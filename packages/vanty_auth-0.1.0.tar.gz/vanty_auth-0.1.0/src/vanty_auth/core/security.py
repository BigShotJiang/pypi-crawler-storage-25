from __future__ import annotations

import hashlib
import secrets
import time
from collections import defaultdict, deque
from datetime import UTC, datetime, timedelta
from typing import Any
from uuid import UUID

import jwt
import pyotp
from cryptography.fernet import Fernet
from pwdlib import PasswordHash

from vanty_auth.settings import AuthKitSettings

password_hash = PasswordHash.recommended()


def utcnow() -> datetime:
    return datetime.now(UTC)


def hash_secret(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def new_secret(length: int = 32) -> str:
    return secrets.token_urlsafe(length)


def hash_password(password: str) -> str:
    return password_hash.hash(password)


def verify_password(password: str, password_hash_value: str | None) -> bool:
    if not password_hash_value:
        return False
    return password_hash.verify(password, password_hash_value)


def issue_access_token(
    settings: AuthKitSettings,
    *,
    user_id: UUID,
    session_id: UUID,
    mfa_complete: bool = True,
) -> str:
    now = utcnow()
    payload = {
        "sub": str(user_id),
        "sid": str(session_id),
        "iss": settings.jwt_issuer,
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(seconds=settings.access_token_ttl_seconds)).timestamp()),
        "mfa": mfa_complete,
        "typ": "access",
    }
    return jwt.encode(payload, settings.secret_key, algorithm=settings.jwt_algorithm)


def decode_access_token(settings: AuthKitSettings, token: str) -> dict[str, Any]:
    return jwt.decode(
        token,
        settings.secret_key,
        algorithms=[settings.jwt_algorithm],
        issuer=settings.jwt_issuer,
        options={"require": ["exp", "iat", "iss", "sub", "sid", "typ"]},
    )


def issue_pending_mfa_token(settings: AuthKitSettings, *, user_id: UUID) -> str:
    now = utcnow()
    payload = {
        "sub": str(user_id),
        "iss": settings.jwt_issuer,
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(seconds=settings.mfa_pending_ttl_seconds)).timestamp()),
        "typ": "mfa",
    }
    return jwt.encode(payload, settings.secret_key, algorithm=settings.jwt_algorithm)


def decode_pending_mfa_token(settings: AuthKitSettings, token: str) -> dict[str, Any]:
    return jwt.decode(
        token,
        settings.secret_key,
        algorithms=[settings.jwt_algorithm],
        issuer=settings.jwt_issuer,
        options={"require": ["exp", "iat", "iss", "sub", "typ"]},
    )


def issue_refresh_token() -> str:
    return new_secret(48)


def create_fernet(settings: AuthKitSettings) -> Fernet:
    return Fernet(settings.encryption_key)


def encrypt_text(settings: AuthKitSettings, value: str) -> str:
    return create_fernet(settings).encrypt(value.encode("utf-8")).decode("utf-8")


def decrypt_text(settings: AuthKitSettings, value: str) -> str:
    return create_fernet(settings).decrypt(value.encode("utf-8")).decode("utf-8")


def generate_totp_secret() -> str:
    return pyotp.random_base32()


def verify_totp_code(secret: str, code: str) -> bool:
    return pyotp.TOTP(secret).verify(code, valid_window=1)


def totp_provisioning_uri(secret: str, *, email: str, issuer: str) -> str:
    return pyotp.TOTP(secret).provisioning_uri(name=email, issuer_name=issuer)


def generate_recovery_codes(count: int = 10) -> list[str]:
    return [secrets.token_hex(4).upper() for _ in range(count)]


class RateLimiter:
    def __init__(self) -> None:
        self._entries: dict[str, deque[float]] = defaultdict(deque)

    def allow(self, *, key: str, limit: int, window_seconds: int) -> bool:
        now = time.time()
        bucket = self._entries[key]
        while bucket and bucket[0] <= now - window_seconds:
            bucket.popleft()
        if len(bucket) >= limit:
            return False
        bucket.append(now)
        return True
