from __future__ import annotations

from dataclasses import dataclass

PERMISSION_MEMBERS_READ = "org:members:read"
PERMISSION_MEMBERS_MANAGE = "org:members:manage"
PERMISSION_ROLES_MANAGE = "org:roles:manage"
PERMISSION_API_KEYS_READ = "org:api_keys:read"
PERMISSION_API_KEYS_MANAGE = "org:api_keys:manage"
PERMISSION_SECURITY_MANAGE = "org:security:manage"


@dataclass(slots=True, frozen=True)
class RoleDefinition:
    slug: str
    permissions: tuple[str, ...]


DEFAULT_ROLE_DEFINITIONS: dict[str, RoleDefinition] = {
    "owner": RoleDefinition(
        slug="owner",
        permissions=(
            PERMISSION_MEMBERS_READ,
            PERMISSION_MEMBERS_MANAGE,
            PERMISSION_ROLES_MANAGE,
            PERMISSION_API_KEYS_READ,
            PERMISSION_API_KEYS_MANAGE,
            PERMISSION_SECURITY_MANAGE,
        ),
    ),
    "admin": RoleDefinition(
        slug="admin",
        permissions=(
            PERMISSION_MEMBERS_READ,
            PERMISSION_MEMBERS_MANAGE,
            PERMISSION_ROLES_MANAGE,
            PERMISSION_API_KEYS_READ,
            PERMISSION_API_KEYS_MANAGE,
            PERMISSION_SECURITY_MANAGE,
        ),
    ),
    "developer": RoleDefinition(
        slug="developer",
        permissions=(
            PERMISSION_MEMBERS_READ,
            PERMISSION_API_KEYS_READ,
            PERMISSION_API_KEYS_MANAGE,
        ),
    ),
    "billing": RoleDefinition(
        slug="billing",
        permissions=(PERMISSION_MEMBERS_READ,),
    ),
    "member": RoleDefinition(
        slug="member",
        permissions=(PERMISSION_MEMBERS_READ,),
    ),
    "guest": RoleDefinition(
        slug="guest",
        permissions=(),
    ),
}

REGISTERED_PERMISSIONS = {
    PERMISSION_MEMBERS_READ,
    PERMISSION_MEMBERS_MANAGE,
    PERMISSION_ROLES_MANAGE,
    PERMISSION_API_KEYS_READ,
    PERMISSION_API_KEYS_MANAGE,
    PERMISSION_SECURITY_MANAGE,
}


def permissions_for_role(role_slug: str) -> list[str]:
    return list(DEFAULT_ROLE_DEFINITIONS.get(role_slug, DEFAULT_ROLE_DEFINITIONS["member"]).permissions)


def register_role_definition(role: RoleDefinition) -> None:
    DEFAULT_ROLE_DEFINITIONS[role.slug] = role
    REGISTERED_PERMISSIONS.update(role.permissions)


def register_permission(permission: str) -> None:
    REGISTERED_PERMISSIONS.add(permission)
