from __future__ import annotations


class AuthError(Exception):
    def __init__(self, detail: str = "") -> None:
        self.detail = detail
        super().__init__(detail)


class InvalidCredentials(AuthError): ...


class EmailNotVerified(AuthError): ...


class NotFound(AuthError): ...


class Conflict(AuthError): ...


class PermissionDenied(AuthError): ...


class RateLimitExceeded(AuthError): ...


class InvalidToken(AuthError): ...


class InvalidState(AuthError): ...


class NotAuthenticated(AuthError): ...


class MfaRequired(AuthError):
    def __init__(self, mfa_token: str) -> None:
        self.mfa_token = mfa_token
        super().__init__("MFA required")
