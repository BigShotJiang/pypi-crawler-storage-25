from __future__ import annotations

from uuid import UUID

from vanty_auth.core.auth_context import AuthContext
from vanty_auth.core.exceptions import PermissionDenied


def require_organization_match(context: AuthContext, organization_id: UUID) -> None:
    if context.organization_id != organization_id:
        raise PermissionDenied("Active organization mismatch")
