from __future__ import annotations

from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import asdict, dataclass
from typing import Any
from uuid import UUID

from asgiref.local import Local


@dataclass(slots=True)
class AuthContext:
    principal_type: str
    user_id: UUID | None
    session_id: UUID | None
    organization_id: UUID | None
    membership_id: UUID | None
    role_slug: str | None
    permissions: list[str]
    api_key_id: UUID | None
    request_id: str
    ip_address: str | None
    user_agent: str | None

    def asdict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class AuthContextEnvelope:
    actor_user_id: UUID | None
    session_id: UUID | None
    organization_id: UUID | None
    membership_id: UUID | None
    api_key_id: UUID | None
    request_id: str | None


_MISSING = object()
_auth_context_state = Local()


class AuthContextLocal:
    def __getattr__(self, name: str) -> Any:
        context = get_current_auth_context()
        if context is None:
            raise AttributeError(name)
        return getattr(context, name)

    def __setattr__(self, name: str, value: Any) -> None:
        context = get_current_auth_context()
        if context is None:
            raise AttributeError("No current auth context")
        setattr(context, name, value)
        _auth_context_state.context = context


auth_local = AuthContextLocal()


def get_current_auth_context() -> AuthContext | None:
    return getattr(_auth_context_state, "context", None)


def require_current_auth_context() -> AuthContext:
    context = get_current_auth_context()
    if context is None:
        raise RuntimeError("No auth context is active")
    return context


@contextmanager
def auth_context(context: AuthContext | None) -> Iterator[AuthContext | None]:
    previous = getattr(_auth_context_state, "context", _MISSING)
    _auth_context_state.context = context
    try:
        yield context
    finally:
        if previous is _MISSING:
            delattr(_auth_context_state, "context")
        else:
            _auth_context_state.context = previous
