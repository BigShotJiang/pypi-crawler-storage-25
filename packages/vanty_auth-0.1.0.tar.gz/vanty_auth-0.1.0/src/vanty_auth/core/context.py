from __future__ import annotations

from dataclasses import dataclass

from vanty_auth.core.email import EmailSender
from vanty_auth.core.events import EventRecorder
from vanty_auth.core.security import RateLimiter
from vanty_auth.settings import AuthKitSettings


@dataclass(slots=True)
class ServiceContext:
    settings: AuthKitSettings
    email_sender: EmailSender
    rate_limiter: RateLimiter
    events: EventRecorder
