from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any


@dataclass(slots=True)
class DomainEvent:
    name: str
    payload: dict[str, Any]
    happened_at: datetime = field(default_factory=lambda: datetime.now(UTC))


class EventRecorder:
    def __init__(self) -> None:
        self._events: list[DomainEvent] = []

    def record(self, name: str, **payload: Any) -> None:
        self._events.append(DomainEvent(name=name, payload=payload))

    def drain(self) -> list[DomainEvent]:
        events = list(self._events)
        self._events.clear()
        return events
