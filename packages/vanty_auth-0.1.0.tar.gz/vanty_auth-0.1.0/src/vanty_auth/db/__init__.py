from vanty_auth.db.models import __models__

__all__ = ["__models__"]
