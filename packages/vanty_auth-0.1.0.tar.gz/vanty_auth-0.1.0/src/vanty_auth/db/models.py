from __future__ import annotations

import uuid

from tortoise import fields
from tortoise.models import Model


class User(Model):
    id = fields.UUIDField(primary_key=True, default=uuid.uuid4)
    password_hash = fields.CharField(max_length=255, null=True)
    display_name = fields.CharField(max_length=255, null=True)
    avatar_url = fields.CharField(max_length=500, null=True)
    is_active = fields.BooleanField(default=True)
    is_superuser = fields.BooleanField(default=False)
    created_at = fields.DatetimeField(auto_now_add=True)
    updated_at = fields.DatetimeField(auto_now=True)
    last_login_at = fields.DatetimeField(null=True)


class EmailAddress(Model):
    id = fields.UUIDField(primary_key=True, default=uuid.uuid4)
    user = fields.ForeignKeyField("models.User", related_name="emails", on_delete=fields.CASCADE)
    email = fields.CharField(max_length=320, unique=True)
    verified = fields.BooleanField(default=False)
    primary = fields.BooleanField(default=False)
    pending = fields.BooleanField(default=False)
    created_at = fields.DatetimeField(auto_now_add=True)


class EmailVerificationToken(Model):
    id = fields.UUIDField(primary_key=True, default=uuid.uuid4)
    user = fields.ForeignKeyField(
        "models.User",
        related_name="email_verification_tokens",
        on_delete=fields.CASCADE,
    )
    email_address = fields.ForeignKeyField(
        "models.EmailAddress",
        related_name="verification_tokens",
        on_delete=fields.CASCADE,
    )
    token_hash = fields.CharField(max_length=64, unique=True)
    purpose = fields.CharField(max_length=32, default="verify_email")
    expires_at = fields.DatetimeField()
    consumed_at = fields.DatetimeField(null=True)
    created_at = fields.DatetimeField(auto_now_add=True)


class PasswordResetToken(Model):
    id = fields.UUIDField(primary_key=True, default=uuid.uuid4)
    user = fields.ForeignKeyField("models.User", related_name="password_reset_tokens", on_delete=fields.CASCADE)
    token_hash = fields.CharField(max_length=64, unique=True)
    expires_at = fields.DatetimeField()
    consumed_at = fields.DatetimeField(null=True)
    created_at = fields.DatetimeField(auto_now_add=True)


class Organization(Model):
    id = fields.UUIDField(primary_key=True, default=uuid.uuid4)
    name = fields.CharField(max_length=255)
    slug = fields.CharField(max_length=255, unique=True)
    kind = fields.CharField(max_length=32, default="organization")
    logo_url = fields.CharField(max_length=500, null=True)
    settings = fields.JSONField(default=dict)
    is_active = fields.BooleanField(default=True)
    owner = fields.ForeignKeyField(
        "models.User",
        related_name="owned_organizations",
        null=True,
        on_delete=fields.SET_NULL,
    )
    created_at = fields.DatetimeField(auto_now_add=True)
    updated_at = fields.DatetimeField(auto_now=True)


class OrganizationMembership(Model):
    id = fields.UUIDField(primary_key=True, default=uuid.uuid4)
    organization = fields.ForeignKeyField(
        "models.Organization",
        related_name="memberships",
        on_delete=fields.CASCADE,
    )
    user = fields.ForeignKeyField(
        "models.User",
        related_name="organization_memberships",
        null=True,
        on_delete=fields.SET_NULL,
    )
    invited_by = fields.ForeignKeyField(
        "models.User",
        related_name="sent_membership_invites",
        null=True,
        on_delete=fields.SET_NULL,
    )
    invited_email = fields.CharField(max_length=320, null=True)
    state = fields.CharField(max_length=32, default="active")
    role_slug = fields.CharField(max_length=64, default="member")
    created_at = fields.DatetimeField(auto_now_add=True)
    updated_at = fields.DatetimeField(auto_now=True)

    class Meta:
        unique_together = (("organization", "user"),)


class OrganizationInvitation(Model):
    id = fields.UUIDField(primary_key=True, default=uuid.uuid4)
    organization = fields.ForeignKeyField(
        "models.Organization",
        related_name="invitations",
        on_delete=fields.CASCADE,
    )
    invited_by = fields.ForeignKeyField(
        "models.User",
        related_name="organization_invitations",
        null=True,
        on_delete=fields.SET_NULL,
    )
    email = fields.CharField(max_length=320)
    role_slug = fields.CharField(max_length=64, default="member")
    token_hash = fields.CharField(max_length=64, unique=True)
    expires_at = fields.DatetimeField()
    accepted_at = fields.DatetimeField(null=True)
    revoked_at = fields.DatetimeField(null=True)
    created_at = fields.DatetimeField(auto_now_add=True)


class ApiKey(Model):
    id = fields.UUIDField(primary_key=True, default=uuid.uuid4)
    organization = fields.ForeignKeyField(
        "models.Organization",
        related_name="api_keys",
        on_delete=fields.CASCADE,
    )
    created_by_user = fields.ForeignKeyField(
        "models.User",
        related_name="created_api_keys",
        null=True,
        on_delete=fields.SET_NULL,
    )
    name = fields.CharField(max_length=255)
    description = fields.CharField(max_length=500, null=True)
    key_prefix = fields.CharField(max_length=32, unique=True)
    secret_hash = fields.CharField(max_length=64, unique=True)
    permissions = fields.JSONField(default=list)
    last_used_at = fields.DatetimeField(null=True)
    revoked_at = fields.DatetimeField(null=True)
    created_at = fields.DatetimeField(auto_now_add=True)


class ProviderApp(Model):
    id = fields.UUIDField(primary_key=True, default=uuid.uuid4)
    provider = fields.CharField(max_length=32, unique=True)
    protocol = fields.CharField(max_length=32, default="oauth2")
    client_id = fields.CharField(max_length=255)
    client_secret = fields.CharField(max_length=255)
    authorize_url = fields.CharField(max_length=500)
    token_url = fields.CharField(max_length=500)
    userinfo_url = fields.CharField(max_length=500)
    email_url = fields.CharField(max_length=500, null=True)
    scopes = fields.JSONField(default=list)
    enabled = fields.BooleanField(default=True)
    created_at = fields.DatetimeField(auto_now_add=True)
    updated_at = fields.DatetimeField(auto_now=True)


class SocialAccount(Model):
    id = fields.UUIDField(primary_key=True, default=uuid.uuid4)
    user = fields.ForeignKeyField("models.User", related_name="social_accounts", on_delete=fields.CASCADE)
    provider = fields.CharField(max_length=32)
    provider_user_id = fields.CharField(max_length=255)
    email = fields.CharField(max_length=320, null=True)
    extra_data = fields.JSONField(default=dict)
    created_at = fields.DatetimeField(auto_now_add=True)
    updated_at = fields.DatetimeField(auto_now=True)

    class Meta:
        unique_together = (("provider", "provider_user_id"),)


class SocialToken(Model):
    id = fields.UUIDField(primary_key=True, default=uuid.uuid4)
    social_account = fields.ForeignKeyField("models.SocialAccount", related_name="tokens", on_delete=fields.CASCADE)
    access_token = fields.TextField()
    refresh_token = fields.TextField(null=True)
    expires_at = fields.DatetimeField(null=True)
    created_at = fields.DatetimeField(auto_now_add=True)
    updated_at = fields.DatetimeField(auto_now=True)


class OAuthState(Model):
    id = fields.UUIDField(primary_key=True, default=uuid.uuid4)
    provider = fields.CharField(max_length=32)
    state = fields.CharField(max_length=255, unique=True)
    code_verifier = fields.CharField(max_length=255)
    redirect_uri = fields.CharField(max_length=500)
    action = fields.CharField(max_length=32, default="login")
    user = fields.ForeignKeyField("models.User", related_name="oauth_states", null=True, on_delete=fields.SET_NULL)
    expires_at = fields.DatetimeField()
    consumed_at = fields.DatetimeField(null=True)
    created_at = fields.DatetimeField(auto_now_add=True)


class AuthSession(Model):
    id = fields.UUIDField(primary_key=True, default=uuid.uuid4)
    user = fields.ForeignKeyField("models.User", related_name="sessions", on_delete=fields.CASCADE)
    active_organization = fields.ForeignKeyField(
        "models.Organization",
        related_name="active_sessions",
        null=True,
        on_delete=fields.SET_NULL,
    )
    session_hash = fields.CharField(max_length=64, unique=True)
    transport = fields.CharField(max_length=16, default="browser")
    user_agent = fields.CharField(max_length=512, null=True)
    ip_address = fields.CharField(max_length=64, null=True)
    revoked_at = fields.DatetimeField(null=True)
    expires_at = fields.DatetimeField()
    last_seen_at = fields.DatetimeField(auto_now_add=True)
    created_at = fields.DatetimeField(auto_now_add=True)


class RefreshToken(Model):
    id = fields.UUIDField(primary_key=True, default=uuid.uuid4)
    session = fields.ForeignKeyField("models.AuthSession", related_name="refresh_tokens", on_delete=fields.CASCADE)
    token_hash = fields.CharField(max_length=64, unique=True)
    expires_at = fields.DatetimeField()
    revoked_at = fields.DatetimeField(null=True)
    created_at = fields.DatetimeField(auto_now_add=True)


class MfaAuthenticator(Model):
    id = fields.UUIDField(primary_key=True, default=uuid.uuid4)
    user = fields.ForeignKeyField("models.User", related_name="authenticators", on_delete=fields.CASCADE)
    type = fields.CharField(max_length=16, default="totp")
    secret_encrypted = fields.TextField()
    confirmed = fields.BooleanField(default=False)
    created_at = fields.DatetimeField(auto_now_add=True)
    last_used_at = fields.DatetimeField(null=True)


class RecoveryCode(Model):
    id = fields.UUIDField(primary_key=True, default=uuid.uuid4)
    authenticator = fields.ForeignKeyField(
        "models.MfaAuthenticator",
        related_name="recovery_codes",
        on_delete=fields.CASCADE,
    )
    code_hash = fields.CharField(max_length=64, unique=True)
    used_at = fields.DatetimeField(null=True)
    created_at = fields.DatetimeField(auto_now_add=True)


class LoginAttempt(Model):
    id = fields.UUIDField(primary_key=True, default=uuid.uuid4)
    email = fields.CharField(max_length=255, index=True)
    ip_address = fields.CharField(max_length=45, index=True)
    user_agent = fields.TextField(default="")
    success = fields.BooleanField(default=False)
    failure_reason = fields.CharField(max_length=100, default="")
    created_at = fields.DatetimeField(auto_now_add=True)

    class Meta:
        table = "auth_login_attempt"
        ordering = ["-created_at"]


class BlockedIP(Model):
    id = fields.UUIDField(primary_key=True, default=uuid.uuid4)
    ip_address = fields.CharField(max_length=45, unique=True)
    reason = fields.CharField(max_length=255, default="")
    blocked_at = fields.DatetimeField(auto_now_add=True)
    blocked_by = fields.ForeignKeyField(
        "models.User",
        related_name="blocked_ips",
        null=True,
        on_delete=fields.SET_NULL,
    )
    expires_at = fields.DatetimeField(null=True)

    class Meta:
        table = "auth_blocked_ip"


__models__ = [
    User,
    EmailAddress,
    EmailVerificationToken,
    PasswordResetToken,
    Organization,
    OrganizationMembership,
    OrganizationInvitation,
    ApiKey,
    ProviderApp,
    SocialAccount,
    SocialToken,
    OAuthState,
    AuthSession,
    RefreshToken,
    MfaAuthenticator,
    RecoveryCode,
    LoginAttempt,
    BlockedIP,
]
