from __future__ import annotations

from vanty_auth.api_keys.schemas import ApiKeyView
from vanty_auth.core.context import ServiceContext
from vanty_auth.core.exceptions import NotFound, PermissionDenied
from vanty_auth.core.rbac import PERMISSION_API_KEYS_MANAGE
from vanty_auth.core.schemas import MessageResponse
from vanty_auth.core.security import hash_secret, new_secret, utcnow
from vanty_auth.db.models import ApiKey, Organization, User


class ApiKeyService:
    def __init__(self, *, context: ServiceContext) -> None:
        self.context = context

    async def list_api_keys(self, *, organization: Organization) -> list[ApiKeyView]:
        keys = await ApiKey.filter(organization=organization).order_by("-created_at")
        return [
            ApiKeyView(
                id=item.id,
                name=item.name,
                description=item.description,
                key_prefix=item.key_prefix,
                permissions=list(item.permissions),
                created_at=item.created_at,
                last_used_at=item.last_used_at,
                revoked_at=item.revoked_at,
            )
            for item in keys
        ]

    async def create_api_key(
        self,
        *,
        organization: Organization,
        created_by: User | None,
        name: str,
        description: str | None,
        permissions: list[str],
        effective_permissions: list[str],
    ) -> tuple[ApiKeyView, str]:
        if PERMISSION_API_KEYS_MANAGE not in effective_permissions:
            raise PermissionDenied("Missing permission")
        prefix = f"ak_{new_secret(6).lower()[:12]}"
        secret = f"{prefix}.{new_secret(24)}"
        key = await ApiKey.create(
            organization=organization,
            created_by_user=created_by,
            name=name,
            description=description,
            key_prefix=prefix,
            secret_hash=hash_secret(secret),
            permissions=permissions,
        )
        return (
            ApiKeyView(
                id=key.id,
                name=key.name,
                description=key.description,
                key_prefix=key.key_prefix,
                permissions=list(key.permissions),
                created_at=key.created_at,
                last_used_at=key.last_used_at,
                revoked_at=key.revoked_at,
            ),
            secret,
        )

    async def revoke_api_key(
        self,
        *,
        organization: Organization,
        api_key_id,
        effective_permissions: list[str],
    ) -> MessageResponse:
        if PERMISSION_API_KEYS_MANAGE not in effective_permissions:
            raise PermissionDenied("Missing permission")
        api_key = await ApiKey.filter(id=api_key_id, organization=organization).first()
        if not api_key:
            raise NotFound("API key not found")
        api_key.revoked_at = utcnow()
        await api_key.save(update_fields=["revoked_at"])
        return MessageResponse(message="API key revoked")

    async def authenticate_api_key(self, raw_secret: str) -> ApiKey | None:
        if "." not in raw_secret:
            return None
        prefix = raw_secret.split(".", 1)[0]
        api_key = await ApiKey.filter(key_prefix=prefix, revoked_at__isnull=True).first()
        if not api_key:
            return None
        if api_key.secret_hash != hash_secret(raw_secret):
            return None
        api_key.last_used_at = utcnow()
        await api_key.save(update_fields=["last_used_at"])
        return api_key
