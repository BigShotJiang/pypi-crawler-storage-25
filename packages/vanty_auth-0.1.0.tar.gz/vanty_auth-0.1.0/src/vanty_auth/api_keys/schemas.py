from __future__ import annotations

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, Field


class ApiKeyView(BaseModel):
    id: UUID
    name: str
    description: str | None = None
    key_prefix: str
    permissions: list[str]
    created_at: datetime
    last_used_at: datetime | None = None
    revoked_at: datetime | None = None


class ApiKeysResponse(BaseModel):
    api_keys: list[ApiKeyView]


class CreateApiKeyRequest(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    description: str | None = Field(default=None, max_length=500)
    permissions: list[str] = Field(default_factory=list)


class CreateApiKeyResponse(BaseModel):
    api_key: ApiKeyView
    secret: str
