from importlib.metadata import PackageNotFoundError, version

from vanty_auth.core.auth_context import AuthContext, AuthContextEnvelope
from vanty_auth.fastapi.middleware import AuthContextMiddleware
from vanty_auth.kit import AuthKit, mount_auth_router
from vanty_auth.settings import AuthKitSettings

try:
    __version__ = version("vanty-auth")
except PackageNotFoundError:
    __version__ = "0.1.0"

__all__ = [
    "AuthContext",
    "AuthContextEnvelope",
    "AuthContextMiddleware",
    "AuthKit",
    "AuthKitSettings",
    "__version__",
    "mount_auth_router",
]
