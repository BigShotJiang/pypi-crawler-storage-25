from __future__ import annotations

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, Field


class EnabledProvidersResponse(BaseModel):
    providers: list[str]


class ProviderConfigView(BaseModel):
    id: UUID
    provider: str
    protocol: str
    client_id: str
    authorize_url: str
    token_url: str
    userinfo_url: str
    email_url: str | None = None
    scopes: list[str] = Field(default_factory=list)
    enabled: bool
    created_at: datetime
    updated_at: datetime


class ProviderConfigsResponse(BaseModel):
    providers: list[ProviderConfigView]


class CreateOrUpdateProviderRequest(BaseModel):
    provider: str = Field(min_length=1, max_length=32)
    protocol: str = Field(default="oauth2", max_length=32)
    client_id: str = Field(min_length=1, max_length=255)
    client_secret: str = Field(min_length=1, max_length=255)
    authorize_url: str = Field(min_length=1, max_length=500)
    token_url: str = Field(min_length=1, max_length=500)
    userinfo_url: str = Field(min_length=1, max_length=500)
    email_url: str | None = Field(default=None, max_length=500)
    scopes: list[str] = Field(default_factory=list)
    enabled: bool = True


class SecurityOverviewResponse(BaseModel):
    total_users: int
    active_sessions: int
    mfa_enabled_count: int
    mfa_adoption_percent: float
    recent_failed_logins: int
    blocked_ips_count: int
    enabled_providers: list[str]
