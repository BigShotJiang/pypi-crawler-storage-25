from __future__ import annotations

from datetime import timedelta
from uuid import UUID

from vanty_auth.core.context import ServiceContext
from vanty_auth.core.exceptions import NotFound
from vanty_auth.core.schemas import MessageResponse
from vanty_auth.core.security import utcnow
from vanty_auth.db.models import (
    AuthSession,
    BlockedIP,
    LoginAttempt,
    MfaAuthenticator,
    ProviderApp,
    User,
)
from vanty_auth.providers.schemas import (
    ProviderConfigView,
    SecurityOverviewResponse,
)


class ProviderAdminService:
    def __init__(self, *, context: ServiceContext) -> None:
        self.context = context

    async def list_enabled_providers(self) -> list[str]:
        providers = await ProviderApp.filter(enabled=True).all()
        settings_providers = [
            name
            for name, app in self.context.settings.provider_apps.items()
            if app.enabled
        ]
        db_providers = [p.provider for p in providers]
        seen: set[str] = set()
        result: list[str] = []
        for p in db_providers + settings_providers:
            if p not in seen:
                seen.add(p)
                result.append(p)
        return result

    async def list_provider_configs(self) -> list[ProviderConfigView]:
        providers = await ProviderApp.all().order_by("provider")
        return [self._to_view(p) for p in providers]

    async def get_provider_config(self, provider_id: UUID) -> ProviderConfigView:
        provider = await ProviderApp.filter(id=provider_id).first()
        if not provider:
            raise NotFound("Provider not found")
        return self._to_view(provider)

    async def create_or_update_provider(
        self,
        *,
        provider: str,
        protocol: str = "oauth2",
        client_id: str,
        client_secret: str,
        authorize_url: str,
        token_url: str,
        userinfo_url: str,
        email_url: str | None = None,
        scopes: list[str] | None = None,
        enabled: bool = True,
    ) -> ProviderConfigView:
        existing = await ProviderApp.filter(provider=provider).first()
        if existing:
            existing.protocol = protocol
            existing.client_id = client_id
            existing.client_secret = client_secret
            existing.authorize_url = authorize_url
            existing.token_url = token_url
            existing.userinfo_url = userinfo_url
            existing.email_url = email_url
            existing.scopes = scopes or []
            existing.enabled = enabled
            await existing.save()
            return self._to_view(existing)
        app = await ProviderApp.create(
            provider=provider,
            protocol=protocol,
            client_id=client_id,
            client_secret=client_secret,
            authorize_url=authorize_url,
            token_url=token_url,
            userinfo_url=userinfo_url,
            email_url=email_url,
            scopes=scopes or [],
            enabled=enabled,
        )
        return self._to_view(app)

    async def delete_provider(self, provider_id: UUID) -> MessageResponse:
        deleted = await ProviderApp.filter(id=provider_id).delete()
        if not deleted:
            raise NotFound("Provider not found")
        return MessageResponse(message="Provider deleted")

    async def get_security_overview(self) -> SecurityOverviewResponse:
        total_users = await User.filter(is_active=True).count()
        active_sessions = await AuthSession.filter(
            revoked_at__isnull=True,
            expires_at__gt=utcnow(),
        ).count()
        mfa_enabled_count = await MfaAuthenticator.filter(confirmed=True).count()
        mfa_adoption_percent = (
            round((mfa_enabled_count / total_users) * 100, 1) if total_users > 0 else 0.0
        )
        recent_failed = await LoginAttempt.filter(
            success=False,
            created_at__gte=utcnow() - timedelta(hours=24),
        ).count()
        blocked_count = await BlockedIP.all().count()
        enabled_providers = await self.list_enabled_providers()
        return SecurityOverviewResponse(
            total_users=total_users,
            active_sessions=active_sessions,
            mfa_enabled_count=mfa_enabled_count,
            mfa_adoption_percent=mfa_adoption_percent,
            recent_failed_logins=recent_failed,
            blocked_ips_count=blocked_count,
            enabled_providers=enabled_providers,
        )

    def _to_view(self, provider: ProviderApp) -> ProviderConfigView:
        return ProviderConfigView(
            id=provider.id,
            provider=provider.provider,
            protocol=provider.protocol,
            client_id=provider.client_id,
            authorize_url=provider.authorize_url,
            token_url=provider.token_url,
            userinfo_url=provider.userinfo_url,
            email_url=provider.email_url,
            scopes=provider.scopes,
            enabled=provider.enabled,
            created_at=provider.created_at,
            updated_at=provider.updated_at,
        )
