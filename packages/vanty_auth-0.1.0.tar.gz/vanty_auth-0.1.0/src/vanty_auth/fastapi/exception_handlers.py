from __future__ import annotations

from fastapi import FastAPI
from starlette.requests import Request
from starlette.responses import JSONResponse

from vanty_auth.core.exceptions import (
    AuthError,
    Conflict,
    EmailNotVerified,
    InvalidCredentials,
    InvalidState,
    InvalidToken,
    MfaRequired,
    NotAuthenticated,
    NotFound,
    PermissionDenied,
    RateLimitExceeded,
)

EXCEPTION_STATUS_MAP: dict[type[AuthError], int] = {
    InvalidCredentials: 400,
    InvalidState: 400,
    EmailNotVerified: 403,
    NotFound: 404,
    Conflict: 409,
    PermissionDenied: 403,
    RateLimitExceeded: 429,
    InvalidToken: 400,
    NotAuthenticated: 401,
}


def register_exception_handlers(app: FastAPI) -> None:
    @app.exception_handler(MfaRequired)
    async def _mfa_required_handler(_request: Request, exc: MfaRequired) -> JSONResponse:
        return JSONResponse(
            status_code=200,
            content={"mfa_required": True, "mfa_token": exc.mfa_token},
        )

    for exc_class, status_code in EXCEPTION_STATUS_MAP.items():

        def _make_handler(sc: int):
            async def _handler(_request: Request, exc: AuthError) -> JSONResponse:
                return JSONResponse(status_code=sc, content={"detail": exc.detail})

            return _handler

        app.add_exception_handler(exc_class, _make_handler(status_code))
