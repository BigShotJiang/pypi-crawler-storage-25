"""FastAPI router, middleware, and dependency helpers."""
