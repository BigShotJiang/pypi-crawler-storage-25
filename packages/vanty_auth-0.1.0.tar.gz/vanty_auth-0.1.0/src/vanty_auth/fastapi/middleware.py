from __future__ import annotations

from fastapi import Request

from vanty_auth.core.auth_context import auth_context


class AuthContextMiddleware:
    def __init__(self, app) -> None:
        self.app = app

    async def __call__(self, scope, receive, send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        request = Request(scope, receive=receive)
        kit = getattr(scope["app"].state, "auth_kit", None)
        context = None
        if kit is not None:
            context = await kit.auth_context_service.resolve_request_context(request)

        scope.setdefault("state", {})
        scope["state"]["auth_context"] = context

        if kit is not None and context is not None:
            user, session = await kit.auth_context_service.user_and_session_for_context(context)
            scope["state"]["current_user"] = user
            scope["state"]["current_session"] = session

        with auth_context(context):
            await self.app(scope, receive, send)
