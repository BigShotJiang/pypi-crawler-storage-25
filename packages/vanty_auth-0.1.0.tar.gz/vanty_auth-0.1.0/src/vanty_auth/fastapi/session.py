from __future__ import annotations

from starlette.responses import Response

from vanty_auth.account.schemas import AuthFlowResult, AuthResponse, MfaChallengeResponse
from vanty_auth.core.schemas import MessageResponse
from vanty_auth.settings import AuthKitSettings


def set_session_cookie(response: Response, session_secret: str, settings: AuthKitSettings) -> None:
    response.set_cookie(
        key=settings.session_cookie_name,
        value=session_secret,
        max_age=settings.session_ttl_seconds,
        httponly=settings.session_cookie_httponly,
        secure=settings.session_cookie_secure,
        samesite=settings.session_cookie_samesite,
        domain=settings.session_cookie_domain,
        path="/",
    )


def clear_session_cookie(response: Response, settings: AuthKitSettings) -> None:
    response.delete_cookie(settings.session_cookie_name, path="/")


def finalize_auth_response(
    response: Response,
    result: AuthFlowResult,
    settings: AuthKitSettings,
) -> AuthResponse | MfaChallengeResponse | MessageResponse:
    if result.session_secret:
        set_session_cookie(response, result.session_secret, settings)
    return result.body
