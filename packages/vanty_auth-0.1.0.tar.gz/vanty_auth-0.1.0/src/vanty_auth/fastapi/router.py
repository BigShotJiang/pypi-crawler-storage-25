from __future__ import annotations

from typing import TYPE_CHECKING
from uuid import UUID

from fastapi import APIRouter, Depends, Query, Request, Response

from vanty_auth.account.schemas import (
    AuthContextView,
    AuthResponse,
    ChangePasswordRequest,
    EmailChangeRequest,
    ForgotPasswordRequest,
    LoginRequest,
    RefreshRequest,
    ResetPasswordRequest,
    SessionsResponse,
    SignupRequest,
    UpdateProfileRequest,
    UserView,
    VerifyEmailRequest,
)
from vanty_auth.api_keys.schemas import (
    ApiKeysResponse,
    CreateApiKeyRequest,
    CreateApiKeyResponse,
)
from vanty_auth.core.auth_context import get_current_auth_context
from vanty_auth.core.guards import require_organization_match
from vanty_auth.core.rbac import PERMISSION_API_KEYS_MANAGE, PERMISSION_MEMBERS_MANAGE
from vanty_auth.core.schemas import MessageResponse
from vanty_auth.fastapi.dependencies import (
    CurrentAuth,
    get_auth_context,
    get_auth_kit,
    get_auth_settings,
    get_current_auth,
    require_active_organization,
    require_permission,
)
from vanty_auth.fastapi.session import clear_session_cookie, finalize_auth_response
from vanty_auth.mfa.schemas import (
    MfaDisableRequest,
    RecoveryCodesResponse,
    TotpConfirmRequest,
    TotpEnrollmentResponse,
    TotpVerifyRequest,
)
from vanty_auth.organizations.schemas import (
    CreateOrganizationRequest,
    InvitationsResponse,
    InviteMemberRequest,
    MembersResponse,
    OrganizationDetail,
    OrganizationsResponse,
    OrganizationSwitchRequest,
    TransferOwnershipRequest,
    UpdateMemberRoleRequest,
    UpdateOrganizationRequest,
)
from vanty_auth.providers.schemas import EnabledProvidersResponse
from vanty_auth.settings import AuthKitSettings
from vanty_auth.social.schemas import SocialStartResponse

if TYPE_CHECKING:
    from vanty_auth.kit import AuthKit

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/signup", response_model=MessageResponse)
async def signup(
    request: Request,
    payload: SignupRequest,
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> MessageResponse:
    return await auth_kit.auth_service.signup(request, email=payload.email, password=payload.password)


@router.post("/email/verify", response_model=MessageResponse)
async def verify_email(
    payload: VerifyEmailRequest,
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> MessageResponse:
    return await auth_kit.auth_service.verify_email(payload.token)


@router.post("/password/forgot", response_model=MessageResponse)
async def forgot_password(
    payload: ForgotPasswordRequest,
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> MessageResponse:
    return await auth_kit.auth_service.forgot_password(email=payload.email)


@router.post("/password/reset", response_model=MessageResponse)
async def reset_password(
    payload: ResetPasswordRequest,
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> MessageResponse:
    return await auth_kit.auth_service.reset_password(token=payload.token, password=payload.password)


@router.post("/login", response_model=AuthResponse)
async def login(
    request: Request,
    response: Response,
    payload: LoginRequest,
    auth_kit: AuthKit = Depends(get_auth_kit),
    settings: AuthKitSettings = Depends(get_auth_settings),
) -> AuthResponse:
    result = await auth_kit.auth_service.login(request, email=payload.email, password=payload.password)
    return finalize_auth_response(response, result, settings)


@router.post("/logout", response_model=MessageResponse)
async def logout(
    response: Response,
    auth: CurrentAuth = Depends(get_current_auth),
    auth_kit: AuthKit = Depends(get_auth_kit),
    settings: AuthKitSettings = Depends(get_auth_settings),
) -> MessageResponse:
    result = await auth_kit.auth_service.logout(auth.session)
    clear_session_cookie(response, settings)
    return result


@router.post("/token/refresh", response_model=AuthResponse)
async def refresh(
    payload: RefreshRequest,
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> AuthResponse:
    return await auth_kit.auth_service.refresh(refresh_token=payload.refresh_token)


@router.get("/me", response_model=UserView)
async def me(
    auth: CurrentAuth = Depends(get_current_auth),
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> UserView:
    return await auth_kit.auth_service.me(auth.user, session=auth.session)


@router.patch("/me", response_model=UserView)
async def update_profile(
    payload: UpdateProfileRequest,
    auth: CurrentAuth = Depends(get_current_auth),
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> UserView:
    return await auth_kit.auth_service.update_profile(
        auth.user,
        display_name=payload.display_name,
        avatar_url=payload.avatar_url,
    )


@router.delete("/me", response_model=MessageResponse)
async def delete_account(
    response: Response,
    auth: CurrentAuth = Depends(get_current_auth),
    auth_kit: AuthKit = Depends(get_auth_kit),
    settings: AuthKitSettings = Depends(get_auth_settings),
) -> MessageResponse:
    result = await auth_kit.auth_service.delete_account(auth.user)
    clear_session_cookie(response, settings)
    return result


@router.get("/context", response_model=AuthContextView | None)
async def context_view(
    _=Depends(get_auth_context),
) -> AuthContextView | None:
    context = get_current_auth_context()
    return context.asdict() if context else None


@router.post("/password/change", response_model=MessageResponse)
async def change_password(
    payload: ChangePasswordRequest,
    auth: CurrentAuth = Depends(get_current_auth),
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> MessageResponse:
    return await auth_kit.auth_service.change_password(
        auth.user,
        current_password=payload.current_password,
        new_password=payload.new_password,
    )


@router.post("/email/change", response_model=MessageResponse)
async def change_email(
    payload: EmailChangeRequest,
    auth: CurrentAuth = Depends(get_current_auth),
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> MessageResponse:
    return await auth_kit.auth_service.request_email_change(auth.user, new_email=payload.new_email)


@router.get("/sessions", response_model=SessionsResponse)
async def list_sessions(
    auth: CurrentAuth = Depends(get_current_auth),
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> SessionsResponse:
    sessions = await auth_kit.session_service.list_sessions(auth.user, current_session=auth.session)
    return SessionsResponse(sessions=sessions)


@router.delete("/sessions/{session_id}", response_model=MessageResponse)
async def revoke_session(
    session_id: UUID,
    response: Response,
    auth: CurrentAuth = Depends(get_current_auth),
    auth_kit: AuthKit = Depends(get_auth_kit),
    settings: AuthKitSettings = Depends(get_auth_settings),
) -> MessageResponse:
    result = await auth_kit.session_service.revoke_session(auth.user, session_id=session_id)
    if auth.session and session_id == auth.session.id:
        clear_session_cookie(response, settings)
    return result


@router.post("/sessions/revoke-others", response_model=MessageResponse)
async def revoke_other_sessions(
    auth: CurrentAuth = Depends(get_current_auth),
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> MessageResponse:
    return await auth_kit.session_service.revoke_other_sessions(auth.user, current_session=auth.session)


@router.post("/sessions/revoke-all", response_model=MessageResponse)
async def revoke_all_sessions(
    response: Response,
    auth: CurrentAuth = Depends(get_current_auth),
    auth_kit: AuthKit = Depends(get_auth_kit),
    settings: AuthKitSettings = Depends(get_auth_settings),
) -> MessageResponse:
    result = await auth_kit.session_service.revoke_all_sessions(auth.user)
    clear_session_cookie(response, settings)
    return result


@router.post("/mfa/totp/enroll", response_model=TotpEnrollmentResponse)
async def enroll_totp(
    auth: CurrentAuth = Depends(get_current_auth),
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> TotpEnrollmentResponse:
    return await auth_kit.mfa_service.enroll_totp(auth.user)


@router.post("/mfa/totp/confirm", response_model=RecoveryCodesResponse)
async def confirm_totp(
    payload: TotpConfirmRequest,
    auth: CurrentAuth = Depends(get_current_auth),
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> RecoveryCodesResponse:
    return await auth_kit.mfa_service.confirm_totp(auth.user, code=payload.code)


@router.post("/mfa/totp/verify", response_model=AuthResponse)
async def verify_totp(
    request: Request,
    response: Response,
    payload: TotpVerifyRequest,
    auth_kit: AuthKit = Depends(get_auth_kit),
    settings: AuthKitSettings = Depends(get_auth_settings),
) -> AuthResponse:
    result = await auth_kit.mfa_service.verify_totp(
        request,
        mfa_token=payload.mfa_token,
        code=payload.code,
        recovery_code=payload.recovery_code,
    )
    return finalize_auth_response(response, result, settings)


@router.get("/mfa/recovery-codes", response_model=MessageResponse)
async def recovery_code_status(
    auth: CurrentAuth = Depends(get_current_auth),
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> MessageResponse:
    return await auth_kit.mfa_service.recovery_code_status(auth.user)


@router.post("/mfa/recovery-codes", response_model=RecoveryCodesResponse)
async def regenerate_recovery_codes(
    auth: CurrentAuth = Depends(get_current_auth),
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> RecoveryCodesResponse:
    return await auth_kit.mfa_service.regenerate_recovery_codes(auth.user)


@router.post("/mfa/disable", response_model=MessageResponse)
async def disable_mfa(
    payload: MfaDisableRequest,
    auth: CurrentAuth = Depends(get_current_auth),
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> MessageResponse:
    return await auth_kit.mfa_service.disable_mfa(auth.user, password=payload.password)


# --- Organizations ---


@router.get("/organizations", response_model=OrganizationsResponse)
async def organizations(
    auth: CurrentAuth = Depends(get_current_auth),
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> OrganizationsResponse:
    current_org_id = auth.session.active_organization_id if auth.session else None
    orgs = await auth_kit.organization_service.organizations_for_user(
        auth.user, current_organization_id=current_org_id,
    )
    return OrganizationsResponse(organizations=orgs)


@router.post("/organizations/switch", response_model=MessageResponse)
async def switch_organization(
    payload: OrganizationSwitchRequest,
    auth: CurrentAuth = Depends(get_current_auth),
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> MessageResponse:
    result = await auth_kit.organization_service.switch_organization(
        user=auth.user,
        session=auth.session,
        organization_id=payload.organization_id,
    )
    return MessageResponse(message=f"Switched to {result.name}", debug={"organization_id": str(result.id)})


@router.post("/organizations", response_model=OrganizationDetail)
async def create_organization(
    payload: CreateOrganizationRequest,
    auth: CurrentAuth = Depends(get_current_auth),
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> OrganizationDetail:
    return await auth_kit.organization_service.create_organization(
        auth.user,
        name=payload.name,
        slug=payload.slug,
    )


@router.get("/organizations/{org_id}", response_model=OrganizationDetail)
async def get_organization(
    org_id: UUID,
    auth: CurrentAuth = Depends(get_current_auth),
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> OrganizationDetail:
    return await auth_kit.organization_service.get_organization_detail(org_id)


@router.patch("/organizations/{org_id}", response_model=OrganizationDetail)
async def update_organization(
    org_id: UUID,
    payload: UpdateOrganizationRequest,
    _=Depends(require_permission(PERMISSION_MEMBERS_MANAGE)),
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> OrganizationDetail:
    return await auth_kit.organization_service.update_organization(
        org_id,
        name=payload.name,
        slug=payload.slug,
        logo_url=payload.logo_url,
        settings=payload.settings,
    )


@router.delete("/organizations/{org_id}", response_model=MessageResponse)
async def delete_organization(
    org_id: UUID,
    auth: CurrentAuth = Depends(get_current_auth),
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> MessageResponse:
    return await auth_kit.organization_service.delete_organization(org_id, auth.user)


@router.post("/organizations/{org_id}/leave", response_model=MessageResponse)
async def leave_organization(
    org_id: UUID,
    auth: CurrentAuth = Depends(get_current_auth),
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> MessageResponse:
    return await auth_kit.organization_service.leave_organization(org_id, auth.user)


@router.post("/organizations/{org_id}/transfer-ownership", response_model=MessageResponse)
async def transfer_ownership(
    org_id: UUID,
    payload: TransferOwnershipRequest,
    auth: CurrentAuth = Depends(get_current_auth),
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> MessageResponse:
    return await auth_kit.organization_service.transfer_ownership(
        org_id, auth.user, payload.new_owner_membership_id,
    )


# --- Members ---


@router.get("/organizations/{org_id}/members", response_model=MembersResponse)
async def list_members(
    org_id: UUID,
    context=Depends(require_permission(PERMISSION_MEMBERS_MANAGE)),
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> MembersResponse:
    require_organization_match(context, org_id)
    members = await auth_kit.organization_service.list_members(organization_id=org_id)
    return MembersResponse(members=members)


@router.post("/organizations/{org_id}/invites", response_model=MessageResponse)
async def invite_member(
    org_id: UUID,
    payload: InviteMemberRequest,
    auth: CurrentAuth = Depends(get_current_auth),
    context=Depends(require_permission(PERMISSION_MEMBERS_MANAGE)),
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> MessageResponse:
    require_organization_match(context, org_id)
    invitation = await auth_kit.organization_service.invite_member(
        organization_id=org_id,
        invited_by=auth.user,
        email=payload.email,
        role_slug=payload.role_slug,
        permissions=context.permissions,
    )
    return MessageResponse(message="Invitation created", debug={"invitation_id": str(invitation.id)})


@router.get("/organizations/{org_id}/invites", response_model=InvitationsResponse)
async def list_invitations(
    org_id: UUID,
    context=Depends(require_permission(PERMISSION_MEMBERS_MANAGE)),
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> InvitationsResponse:
    require_organization_match(context, org_id)
    invitations = await auth_kit.organization_service.list_invitations(organization_id=org_id)
    return InvitationsResponse(invitations=invitations)


@router.delete("/organizations/{org_id}/invites/{invite_id}", response_model=MessageResponse)
async def revoke_invitation(
    org_id: UUID,
    invite_id: UUID,
    context=Depends(require_permission(PERMISSION_MEMBERS_MANAGE)),
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> MessageResponse:
    require_organization_match(context, org_id)
    return await auth_kit.organization_service.revoke_invitation(
        organization_id=org_id,
        invitation_id=invite_id,
        permissions=context.permissions,
    )


# --- Invitations (user-facing) ---


@router.get("/invitations", response_model=InvitationsResponse)
async def my_invitations(
    auth: CurrentAuth = Depends(get_current_auth),
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> InvitationsResponse:
    invitations = await auth_kit.organization_service.list_user_invitations(auth.user)
    return InvitationsResponse(invitations=invitations)


@router.post("/invitations/{invite_id}/accept", response_model=MessageResponse)
async def accept_invitation(
    invite_id: UUID,
    auth: CurrentAuth = Depends(get_current_auth),
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> MessageResponse:
    return await auth_kit.organization_service.accept_invitation(invite_id, auth.user)


@router.post("/invitations/{invite_id}/decline", response_model=MessageResponse)
async def decline_invitation(
    invite_id: UUID,
    auth: CurrentAuth = Depends(get_current_auth),
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> MessageResponse:
    return await auth_kit.organization_service.decline_invitation(invite_id, auth.user)


@router.patch("/organizations/{org_id}/members/{membership_id}", response_model=MessageResponse)
async def update_member_role(
    org_id: UUID,
    membership_id: UUID,
    payload: UpdateMemberRoleRequest,
    context=Depends(require_permission(PERMISSION_MEMBERS_MANAGE)),
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> MessageResponse:
    require_organization_match(context, org_id)
    member = await auth_kit.organization_service.update_member_role(
        organization_id=org_id,
        membership_id=membership_id,
        role_slug=payload.role_slug,
        permissions=context.permissions,
    )
    return MessageResponse(message="Member updated", debug={"membership_id": str(member.id)})


@router.delete("/organizations/{org_id}/members/{membership_id}", response_model=MessageResponse)
async def revoke_member(
    org_id: UUID,
    membership_id: UUID,
    context=Depends(require_permission(PERMISSION_MEMBERS_MANAGE)),
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> MessageResponse:
    require_organization_match(context, org_id)
    return await auth_kit.organization_service.revoke_member(
        organization_id=org_id,
        membership_id=membership_id,
        permissions=context.permissions,
    )


# --- API keys ---


@router.get("/api-keys", response_model=ApiKeysResponse)
async def list_api_keys(
    organization=Depends(require_active_organization),
    _=Depends(require_permission(PERMISSION_API_KEYS_MANAGE)),
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> ApiKeysResponse:
    keys = await auth_kit.api_key_service.list_api_keys(organization=organization)
    return ApiKeysResponse(api_keys=keys)


@router.post("/api-keys", response_model=CreateApiKeyResponse)
async def create_api_key(
    payload: CreateApiKeyRequest,
    auth: CurrentAuth = Depends(get_current_auth),
    organization=Depends(require_active_organization),
    context=Depends(require_permission(PERMISSION_API_KEYS_MANAGE)),
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> CreateApiKeyResponse:
    api_key, secret = await auth_kit.api_key_service.create_api_key(
        organization=organization,
        created_by=auth.user,
        name=payload.name,
        description=payload.description,
        permissions=payload.permissions,
        effective_permissions=context.permissions,
    )
    return CreateApiKeyResponse(api_key=api_key, secret=secret)


@router.delete("/api-keys/{api_key_id}", response_model=MessageResponse)
async def revoke_api_key(
    api_key_id: UUID,
    organization=Depends(require_active_organization),
    context=Depends(require_permission(PERMISSION_API_KEYS_MANAGE)),
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> MessageResponse:
    return await auth_kit.api_key_service.revoke_api_key(
        organization=organization,
        api_key_id=api_key_id,
        effective_permissions=context.permissions,
    )


# --- Providers ---


@router.get("/providers", response_model=EnabledProvidersResponse)
async def enabled_providers(
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> EnabledProvidersResponse:
    providers = await auth_kit.provider_admin_service.list_enabled_providers()
    return EnabledProvidersResponse(providers=providers)


# --- Social auth ---


@router.get("/social/{provider}/start", response_model=SocialStartResponse)
async def social_start(
    provider: str,
    redirect_uri: str = Query(...),
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> SocialStartResponse:
    return await auth_kit.social_service.start_social_flow(
        provider=provider, redirect_uri=redirect_uri, action="login", user=None,
    )


@router.get("/social/{provider}/connect", response_model=SocialStartResponse)
async def social_connect(
    provider: str,
    redirect_uri: str = Query(...),
    auth: CurrentAuth = Depends(get_current_auth),
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> SocialStartResponse:
    return await auth_kit.social_service.start_social_flow(
        provider=provider,
        redirect_uri=redirect_uri,
        action="connect",
        user=auth.user,
    )


@router.get("/social/{provider}/callback")
async def social_callback(
    provider: str,
    state: str,
    code: str,
    request: Request,
    response: Response,
    auth_kit: AuthKit = Depends(get_auth_kit),
    settings: AuthKitSettings = Depends(get_auth_settings),
):
    result = await auth_kit.social_service.social_callback(
        request, provider=provider, state=state, code=code,
    )
    if hasattr(result, "session_secret"):
        return finalize_auth_response(response, result, settings)
    return result


@router.delete("/social/{provider}/disconnect", response_model=MessageResponse)
async def social_disconnect(
    provider: str,
    auth: CurrentAuth = Depends(get_current_auth),
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> MessageResponse:
    return await auth_kit.social_service.disconnect_social_account(auth.user, provider=provider)
