from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from fastapi import Depends, Request

from vanty_auth.core.auth_context import AuthContext
from vanty_auth.core.exceptions import Conflict, NotAuthenticated, PermissionDenied
from vanty_auth.db.models import AuthSession, Organization, User
from vanty_auth.settings import AuthKitSettings

if TYPE_CHECKING:
    from vanty_auth.kit import AuthKit


@dataclass(slots=True)
class CurrentAuth:
    user: User
    session: AuthSession | None


def get_auth_kit(request: Request) -> AuthKit:
    return request.app.state.auth_kit


def get_auth_settings(request: Request) -> AuthKitSettings:
    kit: AuthKit = request.app.state.auth_kit
    return kit.settings


async def get_auth_context(
    request: Request,
    kit: Any = Depends(get_auth_kit),
) -> AuthContext | None:
    context = getattr(request.state, "auth_context", None)
    if context is not None:
        return context
    return await kit.auth_context_service.resolve_request_context(request)


async def get_current_auth(
    request: Request,
    context: AuthContext | None = Depends(get_auth_context),
) -> CurrentAuth:
    if context is None or context.user_id is None:
        raise NotAuthenticated("Authentication required")
    user: User | None = getattr(request.state, "current_user", None)
    session: AuthSession | None = getattr(request.state, "current_session", None)
    if user is None:
        raise NotAuthenticated("Authentication required")
    return CurrentAuth(user=user, session=session)


async def require_active_organization(
    request: Request,
    context: AuthContext | None = Depends(get_auth_context),
) -> Organization:
    if context is None or context.user_id is None:
        raise NotAuthenticated("Authentication required")
    if context.organization_id is None:
        raise Conflict("Active organization required")
    organization = await Organization.get(id=context.organization_id)
    request.state.current_organization = organization
    return organization


def require_permission(permission: str):
    async def dependency(context: AuthContext | None = Depends(get_auth_context)) -> AuthContext:
        if context is None:
            raise NotAuthenticated("Authentication required")
        if permission not in context.permissions:
            raise PermissionDenied("Missing permission")
        return context

    return dependency
