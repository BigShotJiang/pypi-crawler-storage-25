from __future__ import annotations

from datetime import timedelta
from typing import Any
from uuid import UUID

from vanty_auth.core.context import ServiceContext
from vanty_auth.core.exceptions import Conflict, InvalidState, NotFound, PermissionDenied
from vanty_auth.core.rbac import PERMISSION_MEMBERS_MANAGE
from vanty_auth.core.schemas import MessageResponse
from vanty_auth.core.security import hash_secret, new_secret, utcnow
from vanty_auth.db.models import (
    AuthSession,
    EmailAddress,
    Organization,
    OrganizationInvitation,
    OrganizationMembership,
    User,
)
from vanty_auth.organizations.schemas import InvitationView, MemberView, OrganizationDetail, OrganizationSummary


class OrganizationService:
    def __init__(self, *, context: ServiceContext) -> None:
        self.context = context

    @property
    def settings(self):
        return self.context.settings

    async def ensure_personal_organization(self, user: User, *, email: str | None = None) -> Organization:
        existing = await Organization.filter(owner=user, kind="personal").first()
        if existing:
            membership = await OrganizationMembership.filter(organization=existing, user=user).first()
            if not membership:
                await OrganizationMembership.create(
                    organization=existing,
                    user=user,
                    invited_email=email,
                    state="active",
                    role_slug="owner",
                )
            return existing
        local_part = (email or f"user-{user.id}").split("@", 1)[0].lower()
        organization = await Organization.create(
            name=f"{local_part}'s Workspace",
            slug=self._new_slug(local_part),
            kind="personal",
            owner=user,
        )
        await OrganizationMembership.create(
            organization=organization,
            user=user,
            invited_email=email,
            state="active",
            role_slug="owner",
        )
        return organization

    async def organizations_for_user(
        self,
        user: User,
        *,
        current_organization_id: UUID | None,
    ) -> list[OrganizationSummary]:
        memberships = await OrganizationMembership.filter(user=user, state="active").select_related(
            "organization"
        )
        results: list[OrganizationSummary] = []
        for membership in memberships:
            organization = await Organization.get(id=membership.organization_id)
            results.append(
                OrganizationSummary(
                    id=organization.id,
                    name=organization.name,
                    slug=organization.slug,
                    kind=organization.kind,
                    role_slug=membership.role_slug,
                    current=organization.id == current_organization_id,
                )
            )
        return results

    async def membership_for_user(
        self,
        *,
        user: User,
        organization_id: UUID,
    ) -> OrganizationMembership | None:
        return await OrganizationMembership.filter(
            user=user,
            organization_id=organization_id,
            state="active",
        ).first()

    async def resolve_active_organization(
        self,
        *,
        user: User,
        session: AuthSession | None = None,
    ) -> tuple[Organization, OrganizationMembership]:
        if session and session.active_organization_id:
            membership = await self.membership_for_user(
                user=user,
                organization_id=session.active_organization_id,
            )
            if membership:
                organization = await Organization.get(id=membership.organization_id)
                return organization, membership
        organization = await self.ensure_personal_organization(user)
        membership = await self.membership_for_user(user=user, organization_id=organization.id)
        if not membership:
            raise InvalidState("Missing organization membership")
        if session:
            session.active_organization = organization
            await session.save(update_fields=["active_organization_id"])
        return organization, membership

    async def switch_organization(
        self,
        *,
        user: User,
        session: AuthSession,
        organization_id: UUID,
    ) -> OrganizationSummary:
        membership = await self.membership_for_user(user=user, organization_id=organization_id)
        if not membership:
            raise NotFound("Organization not found")
        organization = await Organization.get(id=membership.organization_id)
        session.active_organization = organization
        await session.save(update_fields=["active_organization_id"])
        return OrganizationSummary(
            id=organization.id,
            name=organization.name,
            slug=organization.slug,
            kind=organization.kind,
            role_slug=membership.role_slug,
            current=True,
        )

    async def create_organization(
        self,
        user: User,
        *,
        name: str,
        slug: str | None = None,
    ) -> OrganizationDetail:
        if not self.settings.allow_org_creation:
            raise PermissionDenied("Organization creation is disabled")
        if self.settings.require_email_verification_for_org_creation:
            has_verified = await EmailAddress.filter(user=user, verified=True).exists()
            if not has_verified:
                raise PermissionDenied("Verified email required to create an organization")
        resolved_slug = slug or self._slug_from_name(name)
        self._validate_slug(resolved_slug)
        if await Organization.filter(slug=resolved_slug).exists():
            raise Conflict("Organization slug is already taken")
        organization = await Organization.create(
            name=name,
            slug=resolved_slug,
            kind="organization",
            owner=user,
        )
        await OrganizationMembership.create(
            organization=organization,
            user=user,
            invited_email=(await EmailAddress.filter(user=user, primary=True).first()).email
            if await EmailAddress.filter(user=user, primary=True).exists()
            else None,
            state="active",
            role_slug="owner",
        )
        return await self.get_organization_detail(organization.id)

    async def update_organization(
        self,
        organization_id: UUID,
        *,
        name: str | None = None,
        slug: str | None = None,
        logo_url: str | None = None,
        settings: dict[str, Any] | None = None,
    ) -> OrganizationDetail:
        organization = await Organization.filter(id=organization_id).first()
        if not organization:
            raise NotFound("Organization not found")
        if slug and slug != organization.slug:
            self._validate_slug(slug)
            if await Organization.filter(slug=slug).exclude(id=organization_id).exists():
                raise Conflict("Organization slug is already taken")
            organization.slug = slug
        if name is not None:
            organization.name = name
        if logo_url is not None:
            organization.logo_url = logo_url
        if settings is not None:
            organization.settings = settings
        await organization.save()
        return await self.get_organization_detail(organization.id)

    async def delete_organization(
        self,
        organization_id: UUID,
        user: User,
    ) -> MessageResponse:
        organization = await Organization.filter(id=organization_id).first()
        if not organization:
            raise NotFound("Organization not found")
        if organization.kind == "personal":
            raise PermissionDenied("Cannot delete a personal workspace")
        if organization.owner_id != user.id:
            raise PermissionDenied("Only the owner can delete the organization")
        await OrganizationMembership.filter(organization=organization).delete()
        await OrganizationInvitation.filter(organization=organization).delete()
        await organization.delete()
        return MessageResponse(message="Organization deleted")

    async def get_organization_detail(self, organization_id: UUID) -> OrganizationDetail:
        organization = await Organization.filter(id=organization_id).first()
        if not organization:
            raise NotFound("Organization not found")
        member_count = await OrganizationMembership.filter(
            organization_id=organization_id, state="active"
        ).count()
        return OrganizationDetail(
            id=organization.id,
            name=organization.name,
            slug=organization.slug,
            kind=organization.kind,
            logo_url=organization.logo_url,
            settings=organization.settings,
            is_active=organization.is_active,
            member_count=member_count,
            created_at=organization.created_at,
            updated_at=organization.updated_at,
        )

    async def revoke_invitation(
        self,
        *,
        organization_id: UUID,
        invitation_id: UUID,
        permissions: list[str],
    ) -> MessageResponse:
        if PERMISSION_MEMBERS_MANAGE not in permissions:
            raise PermissionDenied("Missing permission")
        invitation = await OrganizationInvitation.filter(
            id=invitation_id,
            organization_id=organization_id,
            revoked_at__isnull=True,
            accepted_at__isnull=True,
        ).first()
        if not invitation:
            raise NotFound("Invitation not found")
        invitation.revoked_at = utcnow()
        await invitation.save(update_fields=["revoked_at"])
        membership = await OrganizationMembership.filter(
            organization_id=organization_id,
            invited_email=invitation.email,
            state="invited",
        ).first()
        if membership:
            membership.state = "revoked"
            await membership.save(update_fields=["state", "updated_at"])
        return MessageResponse(message="Invitation revoked")

    async def accept_invitation(
        self,
        invitation_id: UUID,
        user: User,
    ) -> MessageResponse:
        invitation = await OrganizationInvitation.filter(
            id=invitation_id,
            revoked_at__isnull=True,
            accepted_at__isnull=True,
        ).first()
        if not invitation:
            raise NotFound("Invitation not found or already used")
        if invitation.expires_at <= utcnow():
            raise InvalidState("Invitation has expired")
        user_email = await EmailAddress.filter(user=user, primary=True).first()
        if not user_email or user_email.email.lower() != invitation.email.lower():
            raise PermissionDenied("Invitation was sent to a different email address")
        existing = await OrganizationMembership.filter(
            organization_id=invitation.organization_id,
            user=user,
            state="active",
        ).first()
        if existing:
            raise Conflict("Already a member of this organization")
        invited_membership = await OrganizationMembership.filter(
            organization_id=invitation.organization_id,
            invited_email=invitation.email,
            state="invited",
        ).first()
        if invited_membership:
            invited_membership.user = user
            invited_membership.state = "active"
            await invited_membership.save(update_fields=["user_id", "state", "updated_at"])
        else:
            await OrganizationMembership.create(
                organization_id=invitation.organization_id,
                user=user,
                invited_email=invitation.email,
                state="active",
                role_slug=invitation.role_slug,
            )
        invitation.accepted_at = utcnow()
        await invitation.save(update_fields=["accepted_at"])
        return MessageResponse(message="Invitation accepted")

    async def decline_invitation(
        self,
        invitation_id: UUID,
        user: User,
    ) -> MessageResponse:
        invitation = await OrganizationInvitation.filter(
            id=invitation_id,
            revoked_at__isnull=True,
            accepted_at__isnull=True,
        ).first()
        if not invitation:
            raise NotFound("Invitation not found or already used")
        user_email = await EmailAddress.filter(user=user, primary=True).first()
        if not user_email or user_email.email.lower() != invitation.email.lower():
            raise PermissionDenied("Invitation was sent to a different email address")
        invitation.revoked_at = utcnow()
        await invitation.save(update_fields=["revoked_at"])
        membership = await OrganizationMembership.filter(
            organization_id=invitation.organization_id,
            invited_email=invitation.email,
            state="invited",
        ).first()
        if membership:
            membership.state = "revoked"
            await membership.save(update_fields=["state", "updated_at"])
        return MessageResponse(message="Invitation declined")

    async def list_user_invitations(self, user: User) -> list[InvitationView]:
        user_email = await EmailAddress.filter(user=user, primary=True).first()
        if not user_email:
            return []
        invitations = await OrganizationInvitation.filter(
            email=user_email.email.lower(),
            revoked_at__isnull=True,
            accepted_at__isnull=True,
        ).select_related("organization").order_by("-created_at")
        return [
            InvitationView(
                id=invite.id,
                email=invite.email,
                role_slug=invite.role_slug,
                organization_id=invite.organization_id,
                organization_name=invite.organization.name if invite.organization else None,
                created_at=invite.created_at,
                accepted_at=invite.accepted_at,
                revoked_at=invite.revoked_at,
            )
            for invite in invitations
        ]

    async def leave_organization(
        self,
        organization_id: UUID,
        user: User,
    ) -> MessageResponse:
        organization = await Organization.filter(id=organization_id).first()
        if not organization:
            raise NotFound("Organization not found")
        if organization.kind == "personal":
            raise PermissionDenied("Cannot leave a personal workspace")
        membership = await self.membership_for_user(user=user, organization_id=organization_id)
        if not membership:
            raise NotFound("Not a member of this organization")
        if membership.role_slug == "owner":
            owner_count = await OrganizationMembership.filter(
                organization_id=organization_id, role_slug="owner", state="active"
            ).count()
            if owner_count <= 1:
                raise PermissionDenied("Transfer ownership before leaving as sole owner")
        membership.state = "left"
        await membership.save(update_fields=["state", "updated_at"])
        return MessageResponse(message="Left organization")

    async def transfer_ownership(
        self,
        organization_id: UUID,
        current_owner: User,
        new_owner_membership_id: UUID,
    ) -> MessageResponse:
        organization = await Organization.filter(id=organization_id).first()
        if not organization:
            raise NotFound("Organization not found")
        if organization.kind == "personal":
            raise PermissionDenied("Cannot transfer ownership of a personal workspace")
        if organization.owner_id != current_owner.id:
            raise PermissionDenied("Only the current owner can transfer ownership")
        new_owner_membership = await OrganizationMembership.filter(
            id=new_owner_membership_id,
            organization_id=organization_id,
            state="active",
        ).first()
        if not new_owner_membership or not new_owner_membership.user_id:
            raise NotFound("Target member not found")
        old_membership = await self.membership_for_user(user=current_owner, organization_id=organization_id)
        if old_membership:
            old_membership.role_slug = "admin"
            await old_membership.save(update_fields=["role_slug", "updated_at"])
        new_owner_membership.role_slug = "owner"
        await new_owner_membership.save(update_fields=["role_slug", "updated_at"])
        organization.owner_id = new_owner_membership.user_id
        await organization.save(update_fields=["owner_id", "updated_at"])
        return MessageResponse(message="Ownership transferred")

    async def list_members(self, *, organization_id: UUID) -> list[MemberView]:
        memberships = await OrganizationMembership.filter(organization_id=organization_id).select_related("user")
        members: list[MemberView] = []
        for membership in memberships:
            email: str | None = membership.invited_email
            display_name: str | None = None
            if membership.user_id:
                email_obj = await EmailAddress.filter(user_id=membership.user_id, primary=True).first()
                email = email_obj.email if email_obj else email
                user = await User.filter(id=membership.user_id).first()
                if user:
                    display_name = user.display_name
            members.append(
                MemberView(
                    id=membership.id,
                    user_id=membership.user_id,
                    email=email,
                    display_name=display_name,
                    role_slug=membership.role_slug,
                    state=membership.state,
                    created_at=membership.created_at,
                )
            )
        return members

    async def list_invitations(self, *, organization_id: UUID) -> list[InvitationView]:
        invitations = await OrganizationInvitation.filter(organization_id=organization_id).order_by("-created_at")
        return [
            InvitationView(
                id=invite.id,
                email=invite.email,
                role_slug=invite.role_slug,
                organization_id=invite.organization_id,
                created_at=invite.created_at,
                accepted_at=invite.accepted_at,
                revoked_at=invite.revoked_at,
            )
            for invite in invitations
        ]

    async def invite_member(
        self,
        *,
        organization_id: UUID,
        invited_by: User,
        email: str,
        role_slug: str,
        permissions: list[str],
    ) -> InvitationView:
        if PERMISSION_MEMBERS_MANAGE not in permissions:
            raise PermissionDenied("Missing permission")
        normalized_email = email.lower().strip()
        invitation = await OrganizationInvitation.create(
            organization_id=organization_id,
            invited_by=invited_by,
            email=normalized_email,
            role_slug=role_slug,
            token_hash=hash_secret(new_secret(24)),
            expires_at=utcnow() + timedelta(days=7),
        )
        membership = await OrganizationMembership.filter(
            organization_id=organization_id,
            invited_email=normalized_email,
        ).first()
        if not membership:
            existing_user_email = await EmailAddress.filter(email=normalized_email).first()
            await OrganizationMembership.create(
                organization_id=organization_id,
                user_id=existing_user_email.user_id if existing_user_email else None,
                invited_by=invited_by,
                invited_email=normalized_email,
                state="invited",
                role_slug=role_slug,
            )
        return InvitationView(
            id=invitation.id,
            email=invitation.email,
            role_slug=invitation.role_slug,
            created_at=invitation.created_at,
            accepted_at=invitation.accepted_at,
            revoked_at=invitation.revoked_at,
        )

    async def update_member_role(
        self,
        *,
        organization_id: UUID,
        membership_id: UUID,
        role_slug: str,
        permissions: list[str],
    ) -> MemberView:
        if PERMISSION_MEMBERS_MANAGE not in permissions:
            raise PermissionDenied("Missing permission")
        membership = await OrganizationMembership.filter(
            id=membership_id,
            organization_id=organization_id,
        ).first()
        if not membership:
            raise NotFound("Member not found")
        membership.role_slug = role_slug
        await membership.save(update_fields=["role_slug", "updated_at"])
        email = membership.invited_email
        if membership.user_id:
            email_obj = await EmailAddress.filter(user_id=membership.user_id, primary=True).first()
            email = email_obj.email if email_obj else email
        return MemberView(
            id=membership.id,
            user_id=membership.user_id,
            email=email,
            role_slug=membership.role_slug,
            state=membership.state,
            created_at=membership.created_at,
        )

    async def revoke_member(
        self,
        *,
        organization_id: UUID,
        membership_id: UUID,
        permissions: list[str],
    ) -> MessageResponse:
        if PERMISSION_MEMBERS_MANAGE not in permissions:
            raise PermissionDenied("Missing permission")
        membership = await OrganizationMembership.filter(
            id=membership_id,
            organization_id=organization_id,
        ).first()
        if not membership:
            raise NotFound("Member not found")
        membership.state = "revoked"
        await membership.save(update_fields=["state", "updated_at"])
        return MessageResponse(message="Member revoked")

    def _new_slug(self, seed: str) -> str:
        return f"{seed}-{new_secret(4).lower()}"

    def _slug_from_name(self, name: str) -> str:
        import re

        slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
        return slug or f"org-{new_secret(4).lower()}"

    def _validate_slug(self, slug: str) -> None:
        if slug in self.settings.restricted_org_slugs:
            raise Conflict(f"Slug '{slug}' is restricted")
        if slug in [n.lower().replace(" ", "-") for n in self.settings.restricted_org_names]:
            raise Conflict("Organization name is restricted")
