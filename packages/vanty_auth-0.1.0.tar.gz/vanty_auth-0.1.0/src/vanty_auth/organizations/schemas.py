from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import BaseModel, EmailStr, Field


class OrganizationSummary(BaseModel):
    id: UUID
    name: str
    slug: str
    kind: str
    role_slug: str
    current: bool = False


class OrganizationDetail(BaseModel):
    id: UUID
    name: str
    slug: str
    kind: str
    logo_url: str | None = None
    settings: dict[str, Any] = Field(default_factory=dict)
    is_active: bool = True
    member_count: int = 0
    created_at: datetime
    updated_at: datetime


class OrganizationsResponse(BaseModel):
    organizations: list[OrganizationSummary]


class OrganizationSwitchRequest(BaseModel):
    organization_id: UUID


class CreateOrganizationRequest(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    slug: str | None = Field(default=None, min_length=1, max_length=255, pattern=r"^[a-z0-9][a-z0-9-]*$")


class UpdateOrganizationRequest(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=255)
    slug: str | None = Field(default=None, min_length=1, max_length=255, pattern=r"^[a-z0-9][a-z0-9-]*$")
    logo_url: str | None = None
    settings: dict[str, Any] | None = None


class TransferOwnershipRequest(BaseModel):
    new_owner_membership_id: UUID


class MemberView(BaseModel):
    id: UUID
    user_id: UUID | None
    email: EmailStr | None = None
    display_name: str | None = None
    role_slug: str
    state: str
    created_at: datetime


class MembersResponse(BaseModel):
    members: list[MemberView]


class InviteMemberRequest(BaseModel):
    email: EmailStr
    role_slug: str = Field(default="member", min_length=1, max_length=64)


class UpdateMemberRoleRequest(BaseModel):
    role_slug: str = Field(min_length=1, max_length=64)


class InvitationView(BaseModel):
    id: UUID
    email: EmailStr
    role_slug: str
    organization_id: UUID | None = None
    organization_name: str | None = None
    created_at: datetime
    accepted_at: datetime | None = None
    revoked_at: datetime | None = None


class InvitationsResponse(BaseModel):
    invitations: list[InvitationView]
