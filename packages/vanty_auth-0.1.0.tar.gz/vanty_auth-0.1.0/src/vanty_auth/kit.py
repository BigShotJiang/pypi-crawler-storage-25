from __future__ import annotations

import asyncio

from fastapi import APIRouter
from tortoise import Tortoise

from vanty_auth.account import (
    AuthContextService,
    AuthService,
    OrganizationResolver,
    PermissionResolver,
    SessionService,
)
from vanty_auth.admin import AuthAdminService
from vanty_auth.admin.router import admin_router
from vanty_auth.api_keys import ApiKeyService
from vanty_auth.core.auth_backends import ApiKeyAuthBackend, BearerTokenBackend, SessionAuthBackend
from vanty_auth.core.auth_context import AuthContextEnvelope, get_current_auth_context
from vanty_auth.core.context import ServiceContext
from vanty_auth.core.email import EmailSender, LoggingEmailSender, MemoryEmailSender
from vanty_auth.core.events import EventRecorder
from vanty_auth.core.rbac import RoleDefinition, register_permission, register_role_definition
from vanty_auth.core.security import RateLimiter
from vanty_auth.fastapi.exception_handlers import register_exception_handlers
from vanty_auth.fastapi.middleware import AuthContextMiddleware
from vanty_auth.fastapi.router import router as auth_router
from vanty_auth.mfa import MfaService
from vanty_auth.organizations import OrganizationService
from vanty_auth.providers import ProviderAdminService
from vanty_auth.security import SecurityService
from vanty_auth.settings import AuthKitSettings
from vanty_auth.social import SocialAuthService, SocialRepository
from vanty_auth.social.providers import (
    ProviderAppRepository,
    ProviderAppResolver,
    build_default_provider_registry,
)

_BACKEND_REGISTRY: dict[str, type] = {
    "bearer": BearerTokenBackend,
    "session": SessionAuthBackend,
    "api_key": ApiKeyAuthBackend,
}


class AuthKit:
    """Composition root for vanty-auth.

    Wires all services and their dependencies.  Access services directly
    via attributes: ``auth_kit.auth_service``,
    ``auth_kit.organization_service``, ``auth_kit.mfa_service``, etc.
    """

    def __init__(
        self,
        settings: AuthKitSettings | None = None,
        *,
        email_sender: EmailSender | None = None,
    ) -> None:
        self.settings = settings or AuthKitSettings()
        self.email_sender = email_sender or (
            MemoryEmailSender() if self.settings.email_sender == "memory" else LoggingEmailSender()
        )
        self.context = ServiceContext(
            settings=self.settings,
            email_sender=self.email_sender,
            rate_limiter=RateLimiter(),
            events=EventRecorder(),
        )
        self.provider_registry = build_default_provider_registry()
        self.provider_app_repository = ProviderAppRepository()
        self.social_repository = SocialRepository()
        self.provider_app_resolver = ProviderAppResolver(
            settings=self.settings,
            registry=self.provider_registry,
            repository=self.provider_app_repository,
        )
        self.organization_service = OrganizationService(context=self.context)
        self.security_service = SecurityService(context=self.context)
        self.auth_service = AuthService(
            context=self.context,
            organization_service=self.organization_service,
            security_service=self.security_service,
        )
        self.session_service = SessionService(auth_service=self.auth_service)
        self.mfa_service = MfaService(auth_service=self.auth_service)
        self.api_key_service = ApiKeyService(context=self.context)
        self.permission_resolver = PermissionResolver()
        self.organization_resolver = OrganizationResolver(organization_service=self.organization_service)

        backends = self._build_backends()
        self.auth_context_service = AuthContextService(
            backends=backends,
            organization_service=self.organization_service,
            organization_resolver=self.organization_resolver,
            permission_resolver=self.permission_resolver,
        )
        self.social_service = SocialAuthService(
            auth_service=self.auth_service,
            provider_registry=self.provider_registry,
            provider_app_resolver=self.provider_app_resolver,
            social_repository=self.social_repository,
        )
        self.provider_admin_service = ProviderAdminService(context=self.context)
        self.admin_service = AuthAdminService(context=self.context)
        self.router: APIRouter = auth_router
        self._admin_router: APIRouter = admin_router
        self._orm_lock = asyncio.Lock()
        self._orm_initialized = False

    def _build_backends(self) -> list:
        backends = []
        for name in self.settings.auth_backends:
            cls = _BACKEND_REGISTRY.get(name)
            if cls is None:
                continue
            if cls is ApiKeyAuthBackend:
                backends.append(cls(api_key_service=self.api_key_service))
            else:
                backends.append(cls(self.settings))
        return backends

    @property
    def events(self) -> EventRecorder:
        return self.context.events

    @property
    def outbox(self):
        return self.auth_service.outbox

    @property
    def admin_router(self) -> APIRouter:
        return self._admin_router

    async def init_orm(self, *, generate_schemas: bool = False) -> None:
        async with self._orm_lock:
            if self._orm_initialized:
                return
            await Tortoise.init(
                db_url=self.settings.database_url,
                modules={"models": ["vanty_auth.db.models"]},
                _enable_global_fallback=True,
            )
            if generate_schemas:
                await Tortoise.generate_schemas(safe=True)
            self._orm_initialized = True

    async def close_orm(self) -> None:
        if self._orm_initialized:
            await Tortoise.close_connections()
            self._orm_initialized = False

    def register_role(self, role: RoleDefinition) -> None:
        register_role_definition(role)

    def register_permission(self, permission: str) -> None:
        register_permission(permission)

    def serialize_current_context(self) -> AuthContextEnvelope:
        return self.auth_context_service.to_envelope(get_current_auth_context())

    async def run_with_auth_context(self, envelope: AuthContextEnvelope, func, *args, **kwargs):
        return await self.auth_context_service.run_with_auth_context(envelope, func, *args, **kwargs)

    async def run_with_organization_context(self, organization_id, func, *args, **kwargs):
        return await self.auth_context_service.run_with_organization_context(
            organization_id,
            func,
            *args,
            **kwargs,
        )


def mount_auth_router(app, settings: AuthKitSettings | None = None) -> AuthKit:
    if not any(item.cls is AuthContextMiddleware for item in app.user_middleware):
        app.add_middleware(AuthContextMiddleware)
    kit = AuthKit(settings=settings)
    app.include_router(kit.router)
    app.state.auth_kit = kit
    register_exception_handlers(app)
    return kit
