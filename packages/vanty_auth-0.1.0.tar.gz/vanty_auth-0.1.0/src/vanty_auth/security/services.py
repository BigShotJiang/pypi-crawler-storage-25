from __future__ import annotations

from datetime import datetime

from vanty_auth.core.context import ServiceContext
from vanty_auth.core.exceptions import Conflict, NotFound
from vanty_auth.core.schemas import MessageResponse
from vanty_auth.core.security import utcnow
from vanty_auth.db.models import BlockedIP, LoginAttempt, User
from vanty_auth.security.schemas import BlockedIPView, LoginAttemptView


class SecurityService:
    def __init__(self, *, context: ServiceContext) -> None:
        self.context = context

    @property
    def settings(self):
        return self.context.settings

    async def record_login_attempt(
        self,
        *,
        email: str,
        ip_address: str,
        user_agent: str,
        success: bool,
        failure_reason: str = "",
    ) -> None:
        await LoginAttempt.create(
            email=email.lower().strip(),
            ip_address=ip_address,
            user_agent=user_agent or "",
            success=success,
            failure_reason=failure_reason,
        )

    async def is_ip_blocked(self, ip_address: str) -> bool:
        blocked = await BlockedIP.filter(ip_address=ip_address).first()
        if not blocked:
            return False
        if blocked.expires_at and blocked.expires_at <= utcnow():
            await blocked.delete()
            return False
        return True

    async def check_auto_block(self, ip_address: str) -> bool:
        """Returns True if the IP was auto-blocked due to exceeding threshold."""
        from datetime import timedelta

        window_start = utcnow() - timedelta(minutes=self.settings.login_attempt_window_minutes)
        failed_count = await LoginAttempt.filter(
            ip_address=ip_address,
            success=False,
            created_at__gte=window_start,
        ).count()
        if failed_count >= self.settings.max_login_attempts_before_block:
            existing = await BlockedIP.filter(ip_address=ip_address).first()
            if not existing:
                await BlockedIP.create(
                    ip_address=ip_address,
                    reason="Auto-blocked: too many failed login attempts",
                )
            return True
        return False

    async def list_login_attempts(
        self,
        *,
        limit: int = 50,
        offset: int = 0,
        email: str | None = None,
        ip_address: str | None = None,
        success: bool | None = None,
    ) -> tuple[list[LoginAttemptView], int]:
        qs = LoginAttempt.all()
        if email:
            qs = qs.filter(email=email.lower().strip())
        if ip_address:
            qs = qs.filter(ip_address=ip_address)
        if success is not None:
            qs = qs.filter(success=success)
        total = await qs.count()
        attempts = await qs.order_by("-created_at").offset(offset).limit(limit)
        return [
            LoginAttemptView(
                id=a.id,
                email=a.email,
                ip_address=a.ip_address,
                user_agent=a.user_agent,
                success=a.success,
                failure_reason=a.failure_reason,
                created_at=a.created_at,
            )
            for a in attempts
        ], total

    async def list_blocked_ips(self) -> list[BlockedIPView]:
        blocked = await BlockedIP.all().order_by("-blocked_at")
        return [
            BlockedIPView(
                id=b.id,
                ip_address=b.ip_address,
                reason=b.reason,
                blocked_at=b.blocked_at,
                expires_at=b.expires_at,
            )
            for b in blocked
        ]

    async def block_ip(
        self,
        *,
        ip_address: str,
        reason: str = "",
        blocked_by: User | None = None,
        expires_at: datetime | None = None,
    ) -> BlockedIPView:
        existing = await BlockedIP.filter(ip_address=ip_address).first()
        if existing:
            raise Conflict("IP address is already blocked")
        blocked = await BlockedIP.create(
            ip_address=ip_address,
            reason=reason,
            blocked_by=blocked_by,
            expires_at=expires_at,
        )
        return BlockedIPView(
            id=blocked.id,
            ip_address=blocked.ip_address,
            reason=blocked.reason,
            blocked_at=blocked.blocked_at,
            expires_at=blocked.expires_at,
        )

    async def unblock_ip(self, ip_address: str) -> MessageResponse:
        deleted = await BlockedIP.filter(ip_address=ip_address).delete()
        if not deleted:
            raise NotFound("IP address not found in block list")
        return MessageResponse(message="IP address unblocked")
