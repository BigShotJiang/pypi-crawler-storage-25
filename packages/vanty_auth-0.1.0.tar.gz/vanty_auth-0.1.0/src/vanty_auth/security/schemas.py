from __future__ import annotations

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, Field


class LoginAttemptView(BaseModel):
    id: UUID
    email: str
    ip_address: str
    user_agent: str
    success: bool
    failure_reason: str
    created_at: datetime


class LoginAttemptsResponse(BaseModel):
    login_attempts: list[LoginAttemptView]
    total: int


class BlockedIPView(BaseModel):
    id: UUID
    ip_address: str
    reason: str
    blocked_at: datetime
    expires_at: datetime | None = None


class BlockedIPsResponse(BaseModel):
    blocked_ips: list[BlockedIPView]


class BlockIPRequest(BaseModel):
    ip_address: str = Field(max_length=45)
    reason: str = Field(default="", max_length=255)
    expires_at: datetime | None = None


class UnblockIPRequest(BaseModel):
    ip_address: str = Field(max_length=45)
