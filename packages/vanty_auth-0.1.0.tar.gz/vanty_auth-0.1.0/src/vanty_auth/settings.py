from __future__ import annotations

import base64
import hashlib
from functools import cached_property
from typing import Literal

from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class ProviderAppSettings(BaseModel):
    protocol: str = "oauth2"
    client_id: str
    client_secret: str
    authorize_url: str | None = None
    token_url: str | None = None
    userinfo_url: str | None = None
    scopes: list[str] = Field(default_factory=list)
    email_url: str | None = None
    enabled: bool = True


class AuthKitSettings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="AUTH_KIT_",
        env_file=".env",
        env_nested_delimiter="__",
        extra="ignore",
    )

    app_name: str = "vanty-auth"
    database_url: str = "sqlite://./vanty-auth.db"
    secret_key: str = "change-me"
    base_url: str = "http://localhost:8000"
    jwt_issuer: str = "vanty-auth"
    jwt_algorithm: str = "HS256"
    access_token_ttl_seconds: int = 900
    refresh_token_ttl_seconds: int = 60 * 60 * 24 * 7
    session_ttl_seconds: int = 60 * 60 * 24 * 7
    verification_ttl_seconds: int = 60 * 60 * 24
    password_reset_ttl_seconds: int = 60 * 30
    oauth_state_ttl_seconds: int = 60 * 10
    mfa_pending_ttl_seconds: int = 60 * 5
    rate_limit_window_seconds: int = 60
    login_rate_limit_attempts: int = 5
    signup_rate_limit_attempts: int = 5
    forgot_password_rate_limit_attempts: int = 5
    session_cookie_name: str = "auth_session"
    session_cookie_secure: bool = False
    session_cookie_httponly: bool = True
    session_cookie_samesite: Literal["lax", "strict", "none"] = "lax"
    session_cookie_domain: str | None = None
    debug_expose_secrets: bool = False
    email_sender: Literal["memory", "log"] = "memory"
    auth_backends: list[str] = Field(default_factory=lambda: ["bearer", "api_key", "session"])
    provider_apps: dict[str, ProviderAppSettings] = Field(default_factory=dict)

    restricted_org_slugs: list[str] = Field(
        default_factory=lambda: ["admin", "api", "www", "app", "auth"]
    )
    restricted_org_names: list[str] = Field(default_factory=list)
    max_login_attempts_before_block: int = 10
    login_attempt_window_minutes: int = 30
    allow_account_deletion: bool = True
    allow_org_creation: bool = True
    require_email_verification_for_org_creation: bool = True

    @cached_property
    def encryption_key(self) -> bytes:
        digest = hashlib.sha256(self.secret_key.encode("utf-8")).digest()
        return base64.urlsafe_b64encode(digest)
