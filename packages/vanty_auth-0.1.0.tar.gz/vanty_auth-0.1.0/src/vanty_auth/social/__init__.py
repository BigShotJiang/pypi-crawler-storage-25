from vanty_auth.social.repository import SocialRepository
from vanty_auth.social.services import SocialAuthService

__all__ = ["SocialAuthService", "SocialRepository"]
