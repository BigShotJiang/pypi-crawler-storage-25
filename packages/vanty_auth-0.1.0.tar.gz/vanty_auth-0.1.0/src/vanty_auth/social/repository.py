from __future__ import annotations

from datetime import timedelta
from uuid import UUID

from vanty_auth.core.security import utcnow
from vanty_auth.db.models import OAuthState, SocialAccount, SocialToken, User
from vanty_auth.social.providers.identity import ProviderIdentity


class SocialRepository:
    async def create_oauth_state(
        self,
        *,
        provider: str,
        state: str,
        code_verifier: str,
        redirect_uri: str,
        action: str,
        user: User | None,
        ttl_seconds: int,
    ) -> OAuthState:
        return await OAuthState.create(
            provider=provider,
            state=state,
            code_verifier=code_verifier,
            redirect_uri=redirect_uri,
            action=action,
            user=user,
            expires_at=utcnow() + timedelta(seconds=ttl_seconds),
        )

    async def get_active_oauth_state(self, *, provider: str, state: str) -> OAuthState | None:
        return await OAuthState.filter(provider=provider, state=state, consumed_at__isnull=True).first()

    async def consume_oauth_state(self, oauth_state: OAuthState) -> None:
        oauth_state.consumed_at = utcnow()
        await oauth_state.save(update_fields=["consumed_at"])

    async def get_social_account(self, *, provider: str, provider_user_id: str) -> SocialAccount | None:
        return await SocialAccount.filter(provider=provider, provider_user_id=provider_user_id).first()

    async def get_user_social_account(self, *, user: User, provider: str) -> SocialAccount | None:
        return await SocialAccount.filter(user=user, provider=provider).first()

    async def count_other_accounts(self, *, user: User, excluding_social_account_id: UUID) -> int:
        return await SocialAccount.filter(user=user).exclude(id=excluding_social_account_id).count()

    async def upsert_social_account(
        self,
        *,
        user: User,
        provider: str,
        identity: ProviderIdentity,
        token_payload: dict[str, object],
    ) -> SocialAccount:
        social_account = await self.get_social_account(
            provider=provider,
            provider_user_id=identity.provider_user_id,
        )
        normalized_email = identity.email.lower() if identity.email else None
        if not social_account:
            social_account = await SocialAccount.create(
                user=user,
                provider=provider,
                provider_user_id=identity.provider_user_id,
                email=normalized_email,
                extra_data=identity.raw,
            )
        else:
            social_account.extra_data = identity.raw
            social_account.email = normalized_email or social_account.email
            await social_account.save(update_fields=["extra_data", "email", "updated_at"])

        expires_in = token_payload.get("expires_in")
        expires_at = utcnow() + timedelta(seconds=int(expires_in)) if expires_in else None
        existing_token = await SocialToken.filter(social_account=social_account).first()
        if existing_token:
            existing_token.access_token = str(token_payload["access_token"])
            existing_token.refresh_token = (
                str(token_payload["refresh_token"])
                if token_payload.get("refresh_token")
                else None
            )
            existing_token.expires_at = expires_at
            await existing_token.save(
                update_fields=["access_token", "refresh_token", "expires_at", "updated_at"]
            )
        else:
            await SocialToken.create(
                social_account=social_account,
                access_token=str(token_payload["access_token"]),
                refresh_token=(
                    str(token_payload["refresh_token"])
                    if token_payload.get("refresh_token")
                    else None
                ),
                expires_at=expires_at,
            )
        return social_account

    async def delete_social_account(self, social_account: SocialAccount) -> None:
        await SocialToken.filter(social_account=social_account).delete()
        await social_account.delete()
