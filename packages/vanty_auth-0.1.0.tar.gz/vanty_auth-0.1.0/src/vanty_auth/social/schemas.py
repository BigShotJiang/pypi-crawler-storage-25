from __future__ import annotations

from pydantic import BaseModel


class SocialStartResponse(BaseModel):
    authorization_url: str
