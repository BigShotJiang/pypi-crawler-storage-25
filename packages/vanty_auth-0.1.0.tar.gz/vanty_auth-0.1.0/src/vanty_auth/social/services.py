from __future__ import annotations

from starlette.requests import Request

from vanty_auth.account.schemas import AuthFlowResult
from vanty_auth.account.services import AuthService
from vanty_auth.core.exceptions import InvalidState, NotFound
from vanty_auth.core.schemas import MessageResponse
from vanty_auth.core.security import new_secret, utcnow
from vanty_auth.db.models import User
from vanty_auth.social.providers import OAuth2Provider, ProviderRegistry, generate_pkce_pair
from vanty_auth.social.providers.resolver import ProviderAppResolver
from vanty_auth.social.repository import SocialRepository
from vanty_auth.social.schemas import SocialStartResponse


class SocialAuthService:
    def __init__(
        self,
        *,
        auth_service: AuthService,
        provider_registry: ProviderRegistry,
        provider_app_resolver: ProviderAppResolver,
        social_repository: SocialRepository,
    ) -> None:
        self.auth_service = auth_service
        self.provider_registry = provider_registry
        self.provider_app_resolver = provider_app_resolver
        self.social_repository = social_repository

    @property
    def settings(self):
        return self.auth_service.settings

    @property
    def events(self):
        return self.auth_service.events

    async def start_social_flow(
        self,
        *,
        provider: str,
        redirect_uri: str,
        action: str,
        user: User | None,
    ) -> SocialStartResponse:
        provider_handler = self._oauth2_provider(provider)
        provider_app = await self.provider_app_resolver.resolve(provider)
        verifier, challenge = generate_pkce_pair()
        state = new_secret(24)
        await self.social_repository.create_oauth_state(
            provider=provider,
            state=state,
            code_verifier=verifier,
            redirect_uri=redirect_uri,
            action=action,
            user=user,
            ttl_seconds=self.settings.oauth_state_ttl_seconds,
        )
        return SocialStartResponse(
            authorization_url=provider_handler.build_authorization_url(
                provider_app,
                redirect_uri=redirect_uri,
                state=state,
                code_challenge=challenge,
            ),
        )

    async def social_callback(
        self,
        request: Request,
        *,
        provider: str,
        state: str,
        code: str,
    ) -> AuthFlowResult | MessageResponse:
        oauth_state = await self.social_repository.get_active_oauth_state(provider=provider, state=state)
        if not oauth_state or oauth_state.expires_at <= utcnow():
            raise InvalidState("Invalid social login state")
        await self.social_repository.consume_oauth_state(oauth_state)
        provider_handler = self._oauth2_provider(provider)
        provider_app = await self.provider_app_resolver.resolve(provider)
        token_payload = await provider_handler.exchange_code(
            provider_app,
            redirect_uri=oauth_state.redirect_uri,
            code=code,
            code_verifier=oauth_state.code_verifier,
        )
        identity = await provider_handler.fetch_identity(provider_app, token_payload)
        user = await self.auth_service.resolve_social_user(
            action=oauth_state.action,
            user_id=oauth_state.user_id,
            provider=provider,
            provider_user_id=identity.provider_user_id,
            email=identity.email,
            email_verified=identity.email_verified,
        )
        social_account = await self.social_repository.upsert_social_account(
            user=user,
            provider=provider,
            identity=identity,
            token_payload=token_payload,
        )
        if oauth_state.action == "connect":
            self.events.record(
                "social.connected",
                user_id=str(user.id),
                provider=provider,
                social_account_id=str(social_account.id),
            )
            return MessageResponse(
                message=f"{provider} account connected",
                debug={"social_account_id": str(social_account.id)},
            )
        return await self.auth_service.issue_login_response_for_user(request, user)

    async def disconnect_social_account(self, user: User, *, provider: str) -> MessageResponse:
        social_account = await self.social_repository.get_user_social_account(user=user, provider=provider)
        if not social_account:
            raise NotFound("Social account not found")
        other_social_count = await self.social_repository.count_other_accounts(
            user=user,
            excluding_social_account_id=social_account.id,
        )
        if not user.password_hash and other_social_count == 0:
            raise InvalidState("Cannot disconnect the last login method")
        await self.social_repository.delete_social_account(social_account)
        self.events.record("social.disconnected", user_id=str(user.id), provider=provider)
        return MessageResponse(message=f"{provider} disconnected")

    def _oauth2_provider(self, provider_id: str) -> OAuth2Provider:
        try:
            provider = self.provider_registry.get(provider_id)
        except KeyError as exc:
            raise NotFound(f"Provider '{provider_id}' is not registered") from exc
        if not isinstance(provider, OAuth2Provider):
            raise InvalidState(f"Provider '{provider_id}' does not support OAuth2")
        return provider
