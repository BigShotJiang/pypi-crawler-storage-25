from __future__ import annotations

import base64
import hashlib
import secrets
from abc import abstractmethod
from typing import Any
from urllib.parse import urlencode

import httpx

from vanty_auth.social.providers.base import Provider
from vanty_auth.social.providers.identity import ProviderIdentity, ResolvedProviderApp


def generate_pkce_pair() -> tuple[str, str]:
    verifier = secrets.token_urlsafe(64)
    challenge = base64.urlsafe_b64encode(
        hashlib.sha256(verifier.encode("ascii")).digest()
    ).rstrip(b"=").decode("ascii")
    return verifier, challenge


class OAuth2Provider(Provider):
    def build_authorization_url(
        self,
        provider_app: ResolvedProviderApp,
        *,
        redirect_uri: str,
        state: str,
        code_challenge: str,
    ) -> str:
        if not provider_app.authorize_url:
            raise ValueError(f"{self.provider_id} is missing an authorize URL")
        params = {
            "client_id": provider_app.client_id,
            "redirect_uri": redirect_uri,
            "response_type": "code",
            "scope": " ".join(provider_app.scopes),
            "state": state,
            "code_challenge": code_challenge,
            "code_challenge_method": "S256",
        }
        return f"{provider_app.authorize_url}?{urlencode(params)}"

    async def exchange_code(
        self,
        provider_app: ResolvedProviderApp,
        *,
        redirect_uri: str,
        code: str,
        code_verifier: str,
    ) -> dict[str, Any]:
        if not provider_app.token_url:
            raise ValueError(f"{self.provider_id} is missing a token URL")
        async with httpx.AsyncClient(timeout=15.0) as client:
            response = await client.post(
                provider_app.token_url,
                headers={"Accept": "application/json"},
                data={
                    "client_id": provider_app.client_id,
                    "client_secret": provider_app.client_secret,
                    "code": code,
                    "code_verifier": code_verifier,
                    "grant_type": "authorization_code",
                    "redirect_uri": redirect_uri,
                },
            )
            response.raise_for_status()
            return response.json()

    async def fetch_identity(
        self,
        provider_app: ResolvedProviderApp,
        token_payload: dict[str, Any],
    ) -> ProviderIdentity:
        access_token = token_payload["access_token"]
        headers = {"Authorization": f"Bearer {access_token}", "Accept": "application/json"}
        async with httpx.AsyncClient(timeout=15.0) as client:
            user_data = await self.fetch_user_payload(client, provider_app, headers)
            email_data = await self.fetch_email_payload(client, provider_app, headers)
        return self.normalize_identity(user_data, email_data)

    async def fetch_user_payload(
        self,
        client: httpx.AsyncClient,
        provider_app: ResolvedProviderApp,
        headers: dict[str, str],
    ) -> dict[str, Any]:
        if not provider_app.userinfo_url:
            raise ValueError(f"{self.provider_id} is missing a userinfo URL")
        response = await client.get(provider_app.userinfo_url, headers=headers)
        response.raise_for_status()
        return response.json()

    async def fetch_email_payload(
        self,
        client: httpx.AsyncClient,
        provider_app: ResolvedProviderApp,
        headers: dict[str, str],
    ) -> Any | None:
        return None

    @abstractmethod
    def normalize_identity(
        self,
        user_data: dict[str, Any],
        email_data: Any | None,
    ) -> ProviderIdentity:
        raise NotImplementedError
