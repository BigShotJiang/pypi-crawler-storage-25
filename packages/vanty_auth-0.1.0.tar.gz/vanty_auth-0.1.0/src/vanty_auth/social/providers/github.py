from __future__ import annotations

from typing import Any

import httpx

from vanty_auth.social.providers.identity import (
    ProviderDefinition,
    ProviderIdentity,
    ResolvedProviderApp,
)
from vanty_auth.social.providers.oauth2 import OAuth2Provider


class GitHubProvider(OAuth2Provider):
    definition = ProviderDefinition(
        provider_id="github",
        display_name="GitHub",
        authorize_url="https://github.com/login/oauth/authorize",
        token_url="https://github.com/login/oauth/access_token",
        userinfo_url="https://api.github.com/user",
        email_url="https://api.github.com/user/emails",
        scopes=("read:user", "user:email"),
    )

    async def fetch_email_payload(
        self,
        client: httpx.AsyncClient,
        provider_app: ResolvedProviderApp,
        headers: dict[str, str],
    ) -> Any | None:
        if not provider_app.email_url:
            return None
        response = await client.get(provider_app.email_url, headers=headers)
        response.raise_for_status()
        return response.json()

    def normalize_identity(
        self,
        user_data: dict[str, Any],
        email_data: Any | None,
    ) -> ProviderIdentity:
        email = user_data.get("email")
        verified = bool(email)
        if isinstance(email_data, list):
            primary = next(
                (
                    item
                    for item in email_data
                    if item.get("primary") and item.get("verified")
                ),
                None,
            )
            if primary:
                email = primary.get("email")
                verified = True
        return ProviderIdentity(
            provider_user_id=str(user_data["id"]),
            email=email,
            email_verified=verified,
            name=user_data.get("name") or user_data.get("login"),
            avatar_url=user_data.get("avatar_url"),
            raw=user_data,
        )
