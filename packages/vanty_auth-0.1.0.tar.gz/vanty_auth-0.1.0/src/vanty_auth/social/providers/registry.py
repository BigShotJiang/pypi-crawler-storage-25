from __future__ import annotations

from vanty_auth.social.providers.base import Provider
from vanty_auth.social.providers.github import GitHubProvider
from vanty_auth.social.providers.google import GoogleProvider


class ProviderRegistry:
    def __init__(self, providers: list[Provider] | None = None) -> None:
        self._providers: dict[str, Provider] = {}
        for provider in providers or []:
            self.register(provider)

    def register(self, provider: Provider) -> None:
        self._providers[provider.provider_id] = provider

    def get(self, provider_id: str) -> Provider:
        try:
            return self._providers[provider_id]
        except KeyError as exc:
            raise KeyError(f"Unknown provider '{provider_id}'") from exc

    def values(self) -> tuple[Provider, ...]:
        return tuple(self._providers.values())


def build_default_provider_registry() -> ProviderRegistry:
    return ProviderRegistry(
        [
            GoogleProvider(),
            GitHubProvider(),
        ]
    )
