from __future__ import annotations

from typing import Any

from vanty_auth.social.providers.identity import ProviderDefinition, ProviderIdentity
from vanty_auth.social.providers.oauth2 import OAuth2Provider


class GoogleProvider(OAuth2Provider):
    definition = ProviderDefinition(
        provider_id="google",
        display_name="Google",
        authorize_url="https://accounts.google.com/o/oauth2/v2/auth",
        token_url="https://oauth2.googleapis.com/token",
        userinfo_url="https://openidconnect.googleapis.com/v1/userinfo",
        scopes=("openid", "email", "profile"),
    )

    def normalize_identity(
        self,
        user_data: dict[str, Any],
        email_data: Any | None,
    ) -> ProviderIdentity:
        return ProviderIdentity(
            provider_user_id=user_data["sub"],
            email=user_data.get("email"),
            email_verified=bool(user_data.get("email_verified")),
            name=user_data.get("name"),
            avatar_url=user_data.get("picture"),
            raw=user_data,
        )
