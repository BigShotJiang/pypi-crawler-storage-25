from vanty_auth.social.providers.base import Provider
from vanty_auth.social.providers.github import GitHubProvider
from vanty_auth.social.providers.google import GoogleProvider
from vanty_auth.social.providers.identity import (
    ProviderDefinition,
    ProviderIdentity,
    ResolvedProviderApp,
)
from vanty_auth.social.providers.oauth2 import OAuth2Provider, generate_pkce_pair
from vanty_auth.social.providers.registry import ProviderRegistry, build_default_provider_registry
from vanty_auth.social.providers.resolver import (
    ProviderAppRecord,
    ProviderAppRepository,
    ProviderAppResolver,
)

__all__ = [
    "GitHubProvider",
    "GoogleProvider",
    "OAuth2Provider",
    "Provider",
    "ProviderAppRecord",
    "ProviderAppRepository",
    "ProviderAppResolver",
    "ProviderDefinition",
    "ProviderIdentity",
    "ProviderRegistry",
    "ResolvedProviderApp",
    "build_default_provider_registry",
    "generate_pkce_pair",
]
