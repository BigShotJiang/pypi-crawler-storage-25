from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(slots=True, frozen=True)
class ProviderDefinition:
    provider_id: str
    display_name: str
    protocol: str = "oauth2"
    authorize_url: str | None = None
    token_url: str | None = None
    userinfo_url: str | None = None
    scopes: tuple[str, ...] = ()
    email_url: str | None = None


@dataclass(slots=True)
class ResolvedProviderApp:
    provider_id: str
    client_id: str
    client_secret: str
    protocol: str = "oauth2"
    authorize_url: str | None = None
    token_url: str | None = None
    userinfo_url: str | None = None
    scopes: list[str] = field(default_factory=list)
    email_url: str | None = None


@dataclass(slots=True)
class ProviderIdentity:
    provider_user_id: str
    email: str | None
    email_verified: bool
    name: str | None
    avatar_url: str | None
    raw: dict[str, Any]
