from __future__ import annotations

from dataclasses import dataclass, field

from fastapi import HTTPException, status

from vanty_auth.db.models import ProviderApp
from vanty_auth.settings import AuthKitSettings, ProviderAppSettings
from vanty_auth.social.providers.identity import ResolvedProviderApp
from vanty_auth.social.providers.registry import ProviderRegistry


@dataclass(slots=True)
class ProviderAppRecord:
    provider: str
    protocol: str
    client_id: str
    client_secret: str
    authorize_url: str | None
    token_url: str | None
    userinfo_url: str | None
    email_url: str | None
    scopes: list[str] = field(default_factory=list)


class ProviderAppRepository:
    async def get_enabled(self, provider_id: str) -> ProviderAppRecord | None:
        record = await ProviderApp.filter(provider=provider_id, enabled=True).first()
        if not record:
            return None
        return ProviderAppRecord(
            provider=record.provider,
            protocol=record.protocol,
            client_id=record.client_id,
            client_secret=record.client_secret,
            authorize_url=record.authorize_url,
            token_url=record.token_url,
            userinfo_url=record.userinfo_url,
            email_url=record.email_url,
            scopes=list(record.scopes),
        )


class ProviderAppResolver:
    def __init__(
        self,
        *,
        settings: AuthKitSettings,
        registry: ProviderRegistry,
        repository: ProviderAppRepository,
    ) -> None:
        self.settings = settings
        self.registry = registry
        self.repository = repository

    async def resolve(self, provider_id: str) -> ResolvedProviderApp:
        provider = self._get_provider(provider_id)
        db_record = await self.repository.get_enabled(provider_id)
        if db_record:
            return ResolvedProviderApp(
                provider_id=provider.provider_id,
                protocol=db_record.protocol,
                client_id=db_record.client_id,
                client_secret=db_record.client_secret,
                authorize_url=db_record.authorize_url or provider.definition.authorize_url,
                token_url=db_record.token_url or provider.definition.token_url,
                userinfo_url=db_record.userinfo_url or provider.definition.userinfo_url,
                email_url=db_record.email_url or provider.definition.email_url,
                scopes=list(db_record.scopes or provider.definition.scopes),
            )

        fallback = self.settings.provider_apps.get(provider_id)
        if fallback and fallback.enabled:
            return self._resolve_fallback(provider_id, provider.definition.protocol, fallback)

        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Provider '{provider_id}' is not configured",
        )

    def _resolve_fallback(
        self,
        provider_id: str,
        provider_protocol: str,
        fallback: ProviderAppSettings,
    ) -> ResolvedProviderApp:
        provider = self._get_provider(provider_id)
        return ResolvedProviderApp(
            provider_id=provider_id,
            protocol=fallback.protocol or provider_protocol,
            client_id=fallback.client_id,
            client_secret=fallback.client_secret,
            authorize_url=fallback.authorize_url or provider.definition.authorize_url,
            token_url=fallback.token_url or provider.definition.token_url,
            userinfo_url=fallback.userinfo_url or provider.definition.userinfo_url,
            email_url=fallback.email_url or provider.definition.email_url,
            scopes=list(fallback.scopes or provider.definition.scopes),
        )

    def _get_provider(self, provider_id: str):
        try:
            return self.registry.get(provider_id)
        except KeyError as exc:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Provider '{provider_id}' is not registered",
            ) from exc
