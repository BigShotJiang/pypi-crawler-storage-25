from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from vanty_auth.social.providers.identity import ProviderDefinition, ProviderIdentity, ResolvedProviderApp


class Provider(ABC):
    definition: ProviderDefinition

    @property
    def provider_id(self) -> str:
        return self.definition.provider_id

    @property
    def protocol(self) -> str:
        return self.definition.protocol

    @abstractmethod
    async def fetch_identity(
        self,
        provider_app: ResolvedProviderApp,
        token_payload: dict[str, Any],
    ) -> ProviderIdentity:
        raise NotImplementedError
