from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import BaseModel, Field


class AdminOrganizationView(BaseModel):
    id: UUID
    name: str
    slug: str
    kind: str
    logo_url: str | None = None
    settings: dict[str, Any] = Field(default_factory=dict)
    is_active: bool
    owner_id: UUID | None = None
    member_count: int = 0
    created_at: datetime
    updated_at: datetime


class AdminOrganizationListResponse(BaseModel):
    organizations: list[AdminOrganizationView]
    total: int


class AdminOrganizationDetailResponse(BaseModel):
    organization: AdminOrganizationView
    members: list[AdminMemberView] = Field(default_factory=list)
    invitation_count: int = 0


class AdminMemberView(BaseModel):
    id: UUID
    user_id: UUID | None = None
    email: str | None = None
    display_name: str | None = None
    role_slug: str
    state: str
    created_at: datetime


class AdminUpdateOrganizationRequest(BaseModel):
    is_active: bool | None = None
    name: str | None = Field(default=None, max_length=255)


class AdminUserView(BaseModel):
    id: UUID
    email: str | None = None
    display_name: str | None = None
    avatar_url: str | None = None
    is_active: bool
    is_superuser: bool
    mfa_enabled: bool = False
    organization_count: int = 0
    created_at: datetime
    last_login_at: datetime | None = None


class AdminUserListResponse(BaseModel):
    users: list[AdminUserView]
    total: int


class AdminUserDetailResponse(BaseModel):
    user: AdminUserView
    organizations: list[AdminUserOrgView] = Field(default_factory=list)
    active_session_count: int = 0


class AdminUserOrgView(BaseModel):
    organization_id: UUID
    organization_name: str
    role_slug: str


class AdminUpdateUserRequest(BaseModel):
    is_active: bool | None = None
    is_superuser: bool | None = None


class PlatformStatsResponse(BaseModel):
    total_users: int
    active_users: int
    total_organizations: int
    active_organizations: int
    total_sessions: int
    active_sessions: int
    mfa_adoption_percent: float
