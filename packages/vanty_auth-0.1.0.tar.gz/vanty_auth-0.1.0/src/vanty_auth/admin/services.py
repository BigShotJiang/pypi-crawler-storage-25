from __future__ import annotations

from uuid import UUID

from tortoise.expressions import Q

from vanty_auth.admin.schemas import (
    AdminMemberView,
    AdminOrganizationDetailResponse,
    AdminOrganizationView,
    AdminUserDetailResponse,
    AdminUserOrgView,
    AdminUserView,
    PlatformStatsResponse,
)
from vanty_auth.core.context import ServiceContext
from vanty_auth.core.exceptions import NotFound
from vanty_auth.core.security import utcnow
from vanty_auth.db.models import (
    AuthSession,
    EmailAddress,
    MfaAuthenticator,
    Organization,
    OrganizationInvitation,
    OrganizationMembership,
    User,
)


class AuthAdminService:
    def __init__(self, *, context: ServiceContext) -> None:
        self.context = context

    async def list_all_organizations(
        self,
        *,
        search: str | None = None,
        is_active: bool | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> tuple[list[AdminOrganizationView], int]:
        qs = Organization.all()
        if search:
            qs = qs.filter(Q(name__icontains=search) | Q(slug__icontains=search))
        if is_active is not None:
            qs = qs.filter(is_active=is_active)
        total = await qs.count()
        orgs = await qs.order_by("-created_at").offset(offset).limit(limit)
        views: list[AdminOrganizationView] = []
        for org in orgs:
            member_count = await OrganizationMembership.filter(
                organization=org, state="active"
            ).count()
            views.append(
                AdminOrganizationView(
                    id=org.id,
                    name=org.name,
                    slug=org.slug,
                    kind=org.kind,
                    logo_url=org.logo_url,
                    settings=org.settings,
                    is_active=org.is_active,
                    owner_id=org.owner_id,
                    member_count=member_count,
                    created_at=org.created_at,
                    updated_at=org.updated_at,
                )
            )
        return views, total

    async def get_organization_admin_detail(
        self, organization_id: UUID
    ) -> AdminOrganizationDetailResponse:
        org = await Organization.filter(id=organization_id).first()
        if not org:
            raise NotFound("Organization not found")
        memberships = await OrganizationMembership.filter(
            organization=org
        ).select_related("user")
        members: list[AdminMemberView] = []
        for m in memberships:
            email: str | None = m.invited_email
            display_name: str | None = None
            if m.user_id:
                email_obj = await EmailAddress.filter(
                    user_id=m.user_id, primary=True
                ).first()
                email = email_obj.email if email_obj else email
                user = await User.filter(id=m.user_id).first()
                if user:
                    display_name = user.display_name
            members.append(
                AdminMemberView(
                    id=m.id,
                    user_id=m.user_id,
                    email=email,
                    display_name=display_name,
                    role_slug=m.role_slug,
                    state=m.state,
                    created_at=m.created_at,
                )
            )
        member_count = sum(1 for m in members if m.state == "active")
        invitation_count = await OrganizationInvitation.filter(
            organization=org,
            revoked_at__isnull=True,
            accepted_at__isnull=True,
        ).count()
        org_view = AdminOrganizationView(
            id=org.id,
            name=org.name,
            slug=org.slug,
            kind=org.kind,
            logo_url=org.logo_url,
            settings=org.settings,
            is_active=org.is_active,
            owner_id=org.owner_id,
            member_count=member_count,
            created_at=org.created_at,
            updated_at=org.updated_at,
        )
        return AdminOrganizationDetailResponse(
            organization=org_view,
            members=members,
            invitation_count=invitation_count,
        )

    async def update_organization_admin(
        self,
        organization_id: UUID,
        *,
        is_active: bool | None = None,
        name: str | None = None,
    ) -> AdminOrganizationView:
        org = await Organization.filter(id=organization_id).first()
        if not org:
            raise NotFound("Organization not found")
        if is_active is not None:
            org.is_active = is_active
        if name is not None:
            org.name = name
        await org.save()
        member_count = await OrganizationMembership.filter(
            organization=org, state="active"
        ).count()
        return AdminOrganizationView(
            id=org.id,
            name=org.name,
            slug=org.slug,
            kind=org.kind,
            logo_url=org.logo_url,
            settings=org.settings,
            is_active=org.is_active,
            owner_id=org.owner_id,
            member_count=member_count,
            created_at=org.created_at,
            updated_at=org.updated_at,
        )

    async def list_all_users(
        self,
        *,
        search: str | None = None,
        is_active: bool | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> tuple[list[AdminUserView], int]:
        qs = User.all()
        if is_active is not None:
            qs = qs.filter(is_active=is_active)
        if search:
            user_ids_from_email = await EmailAddress.filter(
                email__icontains=search
            ).values_list("user_id", flat=True)
            name_q = Q(display_name__icontains=search)
            email_q = Q(id__in=list(user_ids_from_email))
            qs = qs.filter(name_q | email_q)
        total = await qs.count()
        users = await qs.order_by("-created_at").offset(offset).limit(limit)
        views: list[AdminUserView] = []
        for user in users:
            email_obj = await EmailAddress.filter(user=user, primary=True).first()
            mfa_enabled = await MfaAuthenticator.filter(
                user=user, confirmed=True
            ).exists()
            org_count = await OrganizationMembership.filter(
                user=user, state="active"
            ).count()
            views.append(
                AdminUserView(
                    id=user.id,
                    email=email_obj.email if email_obj else None,
                    display_name=user.display_name,
                    avatar_url=user.avatar_url,
                    is_active=user.is_active,
                    is_superuser=user.is_superuser,
                    mfa_enabled=mfa_enabled,
                    organization_count=org_count,
                    created_at=user.created_at,
                    last_login_at=user.last_login_at,
                )
            )
        return views, total

    async def get_user_admin_detail(self, user_id: UUID) -> AdminUserDetailResponse:
        user = await User.filter(id=user_id).first()
        if not user:
            raise NotFound("User not found")
        email_obj = await EmailAddress.filter(user=user, primary=True).first()
        mfa_enabled = await MfaAuthenticator.filter(
            user=user, confirmed=True
        ).exists()
        org_count = await OrganizationMembership.filter(
            user=user, state="active"
        ).count()
        user_view = AdminUserView(
            id=user.id,
            email=email_obj.email if email_obj else None,
            display_name=user.display_name,
            avatar_url=user.avatar_url,
            is_active=user.is_active,
            is_superuser=user.is_superuser,
            mfa_enabled=mfa_enabled,
            organization_count=org_count,
            created_at=user.created_at,
            last_login_at=user.last_login_at,
        )
        memberships = await OrganizationMembership.filter(
            user=user, state="active"
        ).select_related("organization")
        org_views: list[AdminUserOrgView] = []
        for m in memberships:
            org = await Organization.filter(id=m.organization_id).first()
            if org:
                org_views.append(
                    AdminUserOrgView(
                        organization_id=org.id,
                        organization_name=org.name,
                        role_slug=m.role_slug,
                    )
                )
        active_session_count = await AuthSession.filter(
            user=user,
            revoked_at__isnull=True,
            expires_at__gt=utcnow(),
        ).count()
        return AdminUserDetailResponse(
            user=user_view,
            organizations=org_views,
            active_session_count=active_session_count,
        )

    async def update_user_admin(
        self,
        user_id: UUID,
        *,
        is_active: bool | None = None,
        is_superuser: bool | None = None,
    ) -> AdminUserView:
        user = await User.filter(id=user_id).first()
        if not user:
            raise NotFound("User not found")
        if is_active is not None:
            user.is_active = is_active
        if is_superuser is not None:
            user.is_superuser = is_superuser
        await user.save(update_fields=["is_active", "is_superuser", "updated_at"])
        email_obj = await EmailAddress.filter(user=user, primary=True).first()
        mfa_enabled = await MfaAuthenticator.filter(
            user=user, confirmed=True
        ).exists()
        org_count = await OrganizationMembership.filter(
            user=user, state="active"
        ).count()
        return AdminUserView(
            id=user.id,
            email=email_obj.email if email_obj else None,
            display_name=user.display_name,
            avatar_url=user.avatar_url,
            is_active=user.is_active,
            is_superuser=user.is_superuser,
            mfa_enabled=mfa_enabled,
            organization_count=org_count,
            created_at=user.created_at,
            last_login_at=user.last_login_at,
        )

    async def get_platform_stats(self) -> PlatformStatsResponse:
        total_users = await User.all().count()
        active_users = await User.filter(is_active=True).count()
        total_organizations = await Organization.all().count()
        active_organizations = await Organization.filter(is_active=True).count()
        total_sessions = await AuthSession.all().count()
        active_sessions = await AuthSession.filter(
            revoked_at__isnull=True,
            expires_at__gt=utcnow(),
        ).count()
        mfa_users = await MfaAuthenticator.filter(confirmed=True).count()
        mfa_percent = round((mfa_users / active_users) * 100, 1) if active_users > 0 else 0.0
        return PlatformStatsResponse(
            total_users=total_users,
            active_users=active_users,
            total_organizations=total_organizations,
            active_organizations=active_organizations,
            total_sessions=total_sessions,
            active_sessions=active_sessions,
            mfa_adoption_percent=mfa_percent,
        )
