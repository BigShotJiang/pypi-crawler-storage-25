from __future__ import annotations

from typing import TYPE_CHECKING
from uuid import UUID

from fastapi import APIRouter, Depends, Query

from vanty_auth.admin.schemas import (
    AdminOrganizationDetailResponse,
    AdminOrganizationListResponse,
    AdminOrganizationView,
    AdminUpdateOrganizationRequest,
    AdminUpdateUserRequest,
    AdminUserDetailResponse,
    AdminUserListResponse,
    AdminUserView,
    PlatformStatsResponse,
)
from vanty_auth.core.schemas import MessageResponse
from vanty_auth.fastapi.dependencies import get_auth_kit
from vanty_auth.providers.schemas import (
    CreateOrUpdateProviderRequest,
    ProviderConfigsResponse,
    ProviderConfigView,
    SecurityOverviewResponse,
)
from vanty_auth.security.schemas import (
    BlockedIPsResponse,
    BlockedIPView,
    BlockIPRequest,
    LoginAttemptsResponse,
    UnblockIPRequest,
)

if TYPE_CHECKING:
    from vanty_auth.kit import AuthKit

admin_router = APIRouter(tags=["admin"])


@admin_router.get("/organizations", response_model=AdminOrganizationListResponse)
async def admin_list_organizations(
    search: str | None = Query(default=None),
    is_active: bool | None = Query(default=None),
    limit: int = Query(default=50, le=200),
    offset: int = Query(default=0, ge=0),
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> AdminOrganizationListResponse:
    orgs, total = await auth_kit.admin_service.list_all_organizations(
        search=search, is_active=is_active, limit=limit, offset=offset,
    )
    return AdminOrganizationListResponse(organizations=orgs, total=total)


@admin_router.get("/organizations/{org_id}", response_model=AdminOrganizationDetailResponse)
async def admin_get_organization(
    org_id: UUID,
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> AdminOrganizationDetailResponse:
    return await auth_kit.admin_service.get_organization_admin_detail(org_id)


@admin_router.patch("/organizations/{org_id}", response_model=AdminOrganizationView)
async def admin_update_organization(
    org_id: UUID,
    payload: AdminUpdateOrganizationRequest,
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> AdminOrganizationView:
    return await auth_kit.admin_service.update_organization_admin(
        org_id, is_active=payload.is_active, name=payload.name,
    )


@admin_router.get("/users", response_model=AdminUserListResponse)
async def admin_list_users(
    search: str | None = Query(default=None),
    is_active: bool | None = Query(default=None),
    limit: int = Query(default=50, le=200),
    offset: int = Query(default=0, ge=0),
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> AdminUserListResponse:
    users, total = await auth_kit.admin_service.list_all_users(
        search=search, is_active=is_active, limit=limit, offset=offset,
    )
    return AdminUserListResponse(users=users, total=total)


@admin_router.get("/users/{user_id}", response_model=AdminUserDetailResponse)
async def admin_get_user(
    user_id: UUID,
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> AdminUserDetailResponse:
    return await auth_kit.admin_service.get_user_admin_detail(user_id)


@admin_router.patch("/users/{user_id}", response_model=AdminUserView)
async def admin_update_user(
    user_id: UUID,
    payload: AdminUpdateUserRequest,
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> AdminUserView:
    return await auth_kit.admin_service.update_user_admin(
        user_id, is_active=payload.is_active, is_superuser=payload.is_superuser,
    )


@admin_router.get("/providers", response_model=ProviderConfigsResponse)
async def admin_list_providers(
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> ProviderConfigsResponse:
    providers = await auth_kit.provider_admin_service.list_provider_configs()
    return ProviderConfigsResponse(providers=providers)


@admin_router.get("/providers/{provider_id}", response_model=ProviderConfigView)
async def admin_get_provider(
    provider_id: UUID,
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> ProviderConfigView:
    return await auth_kit.provider_admin_service.get_provider_config(provider_id)


@admin_router.post("/providers", response_model=ProviderConfigView)
async def admin_create_or_update_provider(
    payload: CreateOrUpdateProviderRequest,
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> ProviderConfigView:
    return await auth_kit.provider_admin_service.create_or_update_provider(
        provider=payload.provider,
        protocol=payload.protocol,
        client_id=payload.client_id,
        client_secret=payload.client_secret,
        authorize_url=payload.authorize_url,
        token_url=payload.token_url,
        userinfo_url=payload.userinfo_url,
        email_url=payload.email_url,
        scopes=payload.scopes,
        enabled=payload.enabled,
    )


@admin_router.delete("/providers/{provider_id}", response_model=MessageResponse)
async def admin_delete_provider(
    provider_id: UUID,
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> MessageResponse:
    return await auth_kit.provider_admin_service.delete_provider(provider_id)


@admin_router.get("/security/overview", response_model=SecurityOverviewResponse)
async def admin_security_overview(
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> SecurityOverviewResponse:
    return await auth_kit.provider_admin_service.get_security_overview()


@admin_router.get("/security/login-attempts", response_model=LoginAttemptsResponse)
async def admin_login_attempts(
    email: str | None = Query(default=None),
    ip_address: str | None = Query(default=None),
    success: bool | None = Query(default=None),
    limit: int = Query(default=50, le=200),
    offset: int = Query(default=0, ge=0),
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> LoginAttemptsResponse:
    attempts, total = await auth_kit.security_service.list_login_attempts(
        limit=limit, offset=offset, email=email, ip_address=ip_address, success=success,
    )
    return LoginAttemptsResponse(login_attempts=attempts, total=total)


@admin_router.get("/security/blocked-ips", response_model=BlockedIPsResponse)
async def admin_blocked_ips(
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> BlockedIPsResponse:
    blocked = await auth_kit.security_service.list_blocked_ips()
    return BlockedIPsResponse(blocked_ips=blocked)


@admin_router.post("/security/block-ip", response_model=BlockedIPView)
async def admin_block_ip(
    payload: BlockIPRequest,
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> BlockedIPView:
    return await auth_kit.security_service.block_ip(
        ip_address=payload.ip_address,
        reason=payload.reason,
        expires_at=payload.expires_at,
    )


@admin_router.post("/security/unblock-ip", response_model=MessageResponse)
async def admin_unblock_ip(
    payload: UnblockIPRequest,
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> MessageResponse:
    return await auth_kit.security_service.unblock_ip(payload.ip_address)


@admin_router.get("/stats", response_model=PlatformStatsResponse)
async def admin_platform_stats(
    auth_kit: AuthKit = Depends(get_auth_kit),
) -> PlatformStatsResponse:
    return await auth_kit.admin_service.get_platform_stats()
