from __future__ import annotations

from datetime import timedelta
from uuid import UUID

from starlette.requests import Request

from vanty_auth.account.schemas import AuthFlowResult, AuthResponse, SessionView, UserView
from vanty_auth.core.context import ServiceContext
from vanty_auth.core.email import EmailPayload, MemoryEmailSender
from vanty_auth.core.exceptions import (
    EmailNotVerified,
    InvalidCredentials,
    InvalidState,
    InvalidToken,
    MfaRequired,
    PermissionDenied,
    RateLimitExceeded,
)
from vanty_auth.core.schemas import MessageResponse
from vanty_auth.core.security import (
    hash_password,
    hash_secret,
    issue_access_token,
    issue_pending_mfa_token,
    issue_refresh_token,
    new_secret,
    utcnow,
    verify_password,
)
from vanty_auth.db.models import (
    AuthSession,
    EmailAddress,
    EmailVerificationToken,
    MfaAuthenticator,
    Organization,
    OrganizationMembership,
    PasswordResetToken,
    RefreshToken,
    User,
)


class AuthService:
    def __init__(self, *, context: ServiceContext, organization_service=None, security_service=None) -> None:
        self.context = context
        self.organization_service = organization_service
        self.security_service = security_service

    @property
    def settings(self):
        return self.context.settings

    @property
    def events(self):
        return self.context.events

    @property
    def outbox(self) -> list[EmailPayload]:
        if isinstance(self.context.email_sender, MemoryEmailSender):
            return self.context.email_sender.outbox
        return []

    def _require_rate_limit(self, key: str, limit: int) -> None:
        allowed = self.context.rate_limiter.allow(
            key=key,
            limit=limit,
            window_seconds=self.settings.rate_limit_window_seconds,
        )
        if not allowed:
            raise RateLimitExceeded("Too many requests")

    async def _send_email(
        self,
        *,
        to: str,
        subject: str,
        body: str,
        meta: dict[str, str],
    ) -> None:
        await self.context.email_sender.send(
            EmailPayload(to=to, subject=subject, body=body, meta=meta)
        )

    async def primary_email(self, user: User) -> EmailAddress:
        email = await EmailAddress.filter(user=user, primary=True, pending=False).first()
        if not email:
            raise InvalidState("User has no primary email")
        return email

    async def user_view(
        self,
        user: User,
        *,
        current_organization_id: UUID | None = None,
    ) -> UserView:
        primary = await self.primary_email(user)
        mfa_enabled = await MfaAuthenticator.filter(user=user, confirmed=True).exists()
        organizations = []
        if self.organization_service is not None:
            organizations = await self.organization_service.organizations_for_user(
                user,
                current_organization_id=current_organization_id,
            )
        return UserView(
            id=user.id,
            email=primary.email,
            email_verified=primary.verified,
            display_name=user.display_name,
            avatar_url=user.avatar_url,
            mfa_enabled=mfa_enabled,
            created_at=user.created_at,
            organizations=organizations,
        )

    async def session_view(
        self,
        session: AuthSession,
        *,
        current_session_id: UUID | None,
    ) -> SessionView:
        return SessionView(
            id=session.id,
            current=session.id == current_session_id,
            transport=session.transport,
            created_at=session.created_at,
            last_seen_at=session.last_seen_at,
            ip_address=session.ip_address,
            user_agent=session.user_agent,
            active_organization_id=session.active_organization_id,
        )

    async def create_session(
        self,
        user: User,
        request: Request,
        *,
        transport: str,
    ) -> tuple[AuthSession, str]:
        raw_secret = new_secret(32)
        session = await AuthSession.create(
            user=user,
            session_hash=hash_secret(raw_secret),
            transport=transport,
            user_agent=request.headers.get("user-agent"),
            ip_address=request.client.host if request.client else None,
            expires_at=utcnow() + timedelta(seconds=self.settings.session_ttl_seconds),
        )
        if self.organization_service is not None:
            organization = await self.organization_service.ensure_personal_organization(
                user,
                email=(await self.primary_email(user)).email,
            )
            session.active_organization = organization
            await session.save(update_fields=["active_organization_id"])
        user.last_login_at = utcnow()
        await user.save(update_fields=["last_login_at"])
        return session, raw_secret

    async def issue_refresh_token(self, session: AuthSession) -> str:
        raw = issue_refresh_token()
        await RefreshToken.create(
            session=session,
            token_hash=hash_secret(raw),
            expires_at=utcnow() + timedelta(seconds=self.settings.refresh_token_ttl_seconds),
        )
        return raw

    async def auth_payload(
        self,
        user: User,
        session: AuthSession,
        session_secret: str,
    ) -> AuthFlowResult:
        refresh_token = await self.issue_refresh_token(session)
        user_view = await self.user_view(user, current_organization_id=session.active_organization_id)
        session_view = await self.session_view(session, current_session_id=session.id)
        body = AuthResponse(
            user=user_view,
            session=session_view,
            access_token=issue_access_token(
                self.settings,
                user_id=user.id,
                session_id=session.id,
            ),
            refresh_token=refresh_token,
        )
        return AuthFlowResult(body=body, session_secret=session_secret)

    async def issue_login_response_for_user(
        self,
        request: Request,
        user: User,
        *,
        transport: str = "browser",
    ) -> AuthFlowResult:
        session, session_secret = await self.create_session(user, request, transport=transport)
        self.events.record("user.logged_in", user_id=str(user.id), session_id=str(session.id))
        return await self.auth_payload(user, session, session_secret)

    async def create_email_verification(
        self,
        user: User,
        email_address: EmailAddress,
        *,
        purpose: str,
    ) -> str:
        token = new_secret(24)
        await EmailVerificationToken.filter(
            user=user,
            email_address=email_address,
            consumed_at__isnull=True,
        ).update(consumed_at=utcnow())
        await EmailVerificationToken.create(
            user=user,
            email_address=email_address,
            token_hash=hash_secret(token),
            purpose=purpose,
            expires_at=utcnow() + timedelta(seconds=self.settings.verification_ttl_seconds),
        )
        await self._send_email(
            to=email_address.email,
            subject="Verify your email",
            body=f"Verification token: {token}",
            meta={"purpose": purpose},
        )
        return token

    async def signup(self, request: Request, *, email: str, password: str) -> MessageResponse:
        del request
        email = email.lower().strip()
        self._require_rate_limit(f"signup:{email}", self.settings.signup_rate_limit_attempts)
        if await EmailAddress.filter(email=email).exists():
            raise InvalidCredentials("Unable to create account")
        user = await User.create(password_hash=hash_password(password))
        email_address = await EmailAddress.create(
            user=user,
            email=email,
            verified=False,
            primary=True,
            pending=False,
        )
        if self.organization_service is not None:
            await self.organization_service.ensure_personal_organization(user, email=email)
        verification_token = await self.create_email_verification(
            user,
            email_address,
            purpose="verify_email",
        )
        self.events.record("user.signed_up", user_id=str(user.id), email=email)
        debug = {"verification_token": verification_token} if self.settings.debug_expose_secrets else None
        return MessageResponse(message="Account created. Verify your email to continue.", debug=debug)

    async def verify_email(self, token: str) -> MessageResponse:
        record = await EmailVerificationToken.filter(
            token_hash=hash_secret(token),
            consumed_at__isnull=True,
        ).select_related("user", "email_address").first()
        if not record or record.expires_at <= utcnow():
            raise InvalidToken("Invalid or expired verification token")
        record.consumed_at = utcnow()
        await record.save(update_fields=["consumed_at"])
        email_address = await EmailAddress.get(id=record.email_address_id)
        if email_address.pending:
            await EmailAddress.filter(user_id=record.user_id, primary=True).exclude(
                id=email_address.id
            ).delete()
            email_address.pending = False
            email_address.primary = True
        email_address.verified = True
        await email_address.save(update_fields=["verified", "pending", "primary"])
        self.events.record("email.verified", user_id=str(record.user_id), email=email_address.email)
        return MessageResponse(message="Email verified")

    async def forgot_password(self, *, email: str) -> MessageResponse:
        email = email.lower().strip()
        self._require_rate_limit(f"forgot:{email}", self.settings.forgot_password_rate_limit_attempts)
        user_email = await EmailAddress.filter(email=email, primary=True).select_related("user").first()
        debug = None
        if user_email:
            token = new_secret(24)
            await PasswordResetToken.create(
                user_id=user_email.user_id,
                token_hash=hash_secret(token),
                expires_at=utcnow() + timedelta(seconds=self.settings.password_reset_ttl_seconds),
            )
            await self._send_email(
                to=email,
                subject="Reset your password",
                body=f"Password reset token: {token}",
                meta={"purpose": "password_reset"},
            )
            if self.settings.debug_expose_secrets:
                debug = {"reset_token": token}
        return MessageResponse(message="If the account exists, a reset message has been sent.", debug=debug)

    async def reset_password(self, *, token: str, password: str) -> MessageResponse:
        record = await PasswordResetToken.filter(
            token_hash=hash_secret(token),
            consumed_at__isnull=True,
        ).select_related("user").first()
        if not record or record.expires_at <= utcnow():
            raise InvalidToken("Invalid or expired reset token")
        user = await User.get(id=record.user_id)
        user.password_hash = hash_password(password)
        await user.save(update_fields=["password_hash"])
        record.consumed_at = utcnow()
        await record.save(update_fields=["consumed_at"])
        self.events.record("password.reset", user_id=str(user.id))
        return MessageResponse(message="Password updated")

    async def _resolve_verified_user_email(self, email: str) -> tuple[User | None, EmailAddress | None]:
        email_obj = await EmailAddress.filter(email=email.lower().strip(), primary=True).select_related(
            "user"
        ).first()
        if not email_obj:
            return None, None
        user = await User.get(id=email_obj.user_id)
        return user, email_obj

    async def login(self, request: Request, *, email: str, password: str) -> AuthFlowResult:
        email = email.lower().strip()
        ip = request.client.host if request.client else "unknown"
        ua = request.headers.get("user-agent", "")
        self._require_rate_limit(f"login:{email}", self.settings.login_rate_limit_attempts)
        if self.security_service:
            if await self.security_service.is_ip_blocked(ip):
                await self.security_service.record_login_attempt(
                    email=email, ip_address=ip, user_agent=ua,
                    success=False, failure_reason="blocked_ip",
                )
                raise InvalidCredentials("Invalid credentials")
        user, email_address = await self._resolve_verified_user_email(email)
        if not user or not email_address or not verify_password(password, user.password_hash):
            if self.security_service:
                await self.security_service.record_login_attempt(
                    email=email, ip_address=ip, user_agent=ua,
                    success=False, failure_reason="invalid_credentials",
                )
                await self.security_service.check_auto_block(ip)
            raise InvalidCredentials("Invalid credentials")
        if not email_address.verified:
            if self.security_service:
                await self.security_service.record_login_attempt(
                    email=email, ip_address=ip, user_agent=ua,
                    success=False, failure_reason="email_not_verified",
                )
            raise EmailNotVerified("Email verification required")
        authenticator = await MfaAuthenticator.filter(user=user, confirmed=True).first()
        if authenticator:
            if self.security_service:
                await self.security_service.record_login_attempt(
                    email=email, ip_address=ip, user_agent=ua,
                    success=True, failure_reason="",
                )
            raise MfaRequired(
                mfa_token=issue_pending_mfa_token(self.settings, user_id=user.id),
            )
        if self.security_service:
            await self.security_service.record_login_attempt(
                email=email, ip_address=ip, user_agent=ua,
                success=True, failure_reason="",
            )
        return await self.issue_login_response_for_user(request, user)

    async def refresh(self, *, refresh_token: str) -> AuthResponse:
        refresh = await RefreshToken.filter(
            token_hash=hash_secret(refresh_token),
            revoked_at__isnull=True,
        ).select_related("session").first()
        if not refresh or refresh.expires_at <= utcnow():
            raise InvalidToken("Invalid refresh token")
        session = await AuthSession.get(id=refresh.session_id)
        if session.revoked_at is not None or session.expires_at <= utcnow():
            raise InvalidToken("Session inactive")
        user = await User.get(id=session.user_id)
        refresh.revoked_at = utcnow()
        await refresh.save(update_fields=["revoked_at"])
        new_refresh = await self.issue_refresh_token(session)
        user_view = await self.user_view(user, current_organization_id=session.active_organization_id)
        session_view = await self.session_view(session, current_session_id=session.id)
        return AuthResponse(
            user=user_view,
            session=session_view,
            access_token=issue_access_token(self.settings, user_id=user.id, session_id=session.id),
            refresh_token=new_refresh,
        )

    async def logout(self, session: AuthSession) -> MessageResponse:
        session.revoked_at = utcnow()
        await session.save(update_fields=["revoked_at"])
        await RefreshToken.filter(session=session, revoked_at__isnull=True).update(revoked_at=utcnow())
        self.events.record("user.logged_out", session_id=str(session.id), user_id=str(session.user_id))
        return MessageResponse(message="Logged out")

    async def me(self, user: User, *, session: AuthSession | None = None) -> UserView:
        current_organization_id = session.active_organization_id if session else None
        return await self.user_view(user, current_organization_id=current_organization_id)

    async def change_password(
        self,
        user: User,
        *,
        current_password: str,
        new_password: str,
    ) -> MessageResponse:
        if not verify_password(current_password, user.password_hash):
            raise InvalidCredentials("Current password is incorrect")
        user.password_hash = hash_password(new_password)
        await user.save(update_fields=["password_hash"])
        self.events.record("password.changed", user_id=str(user.id))
        return MessageResponse(message="Password changed")

    async def request_email_change(self, user: User, *, new_email: str) -> MessageResponse:
        new_email = new_email.lower().strip()
        if await EmailAddress.filter(email=new_email).exclude(user=user).exists():
            raise InvalidCredentials("Email is already in use")
        await EmailAddress.filter(user=user, pending=True).delete()
        pending = await EmailAddress.create(
            user=user,
            email=new_email,
            verified=False,
            primary=False,
            pending=True,
        )
        token = await self.create_email_verification(user, pending, purpose="change_email")
        debug = {"verification_token": token} if self.settings.debug_expose_secrets else None
        self.events.record("email.change_requested", user_id=str(user.id), email=new_email)
        return MessageResponse(message="Verify the new email address to complete the change.", debug=debug)

    async def resolve_social_user(
        self,
        *,
        action: str,
        user_id: UUID | None,
        provider: str,
        provider_user_id: str,
        email: str | None,
        email_verified: bool,
    ) -> User:
        if action == "connect":
            if not user_id:
                raise InvalidState("Missing connect user context")
            return await User.get(id=user_id)

        existing = await self._get_existing_social_user(provider=provider, provider_user_id=provider_user_id)
        if existing:
            return existing

        if email:
            email_row = await EmailAddress.filter(email=email.lower()).first()
            if email_row and email_verified:
                return await User.get(id=email_row.user_id)

        if not email:
            raise InvalidState("Provider did not return an email address")

        user = await User.create(password_hash=None)
        await EmailAddress.create(
            user=user,
            email=email.lower(),
            verified=email_verified,
            primary=True,
            pending=False,
        )
        if self.organization_service is not None:
            await self.organization_service.ensure_personal_organization(user, email=email.lower())
        return user

    async def update_profile(
        self,
        user: User,
        *,
        display_name: str | None = None,
        avatar_url: str | None = None,
    ) -> UserView:
        if display_name is not None:
            user.display_name = display_name
        if avatar_url is not None:
            user.avatar_url = avatar_url
        await user.save(update_fields=["display_name", "avatar_url", "updated_at"])
        self.events.record("profile.updated", user_id=str(user.id))
        return await self.user_view(user)

    async def delete_account(self, user: User) -> MessageResponse:
        if not self.settings.allow_account_deletion:
            raise PermissionDenied("Account deletion is disabled")
        sessions = await AuthSession.filter(user=user, revoked_at__isnull=True).all()
        now = utcnow()
        for session in sessions:
            session.revoked_at = now
            await session.save(update_fields=["revoked_at"])
            await RefreshToken.filter(
                session=session, revoked_at__isnull=True
            ).update(revoked_at=now)
        memberships = await OrganizationMembership.filter(
            user=user, state="active"
        ).select_related("organization")
        for m in memberships:
            org = await Organization.filter(id=m.organization_id).first()
            if org and org.kind == "organization":
                m.state = "left"
                await m.save(update_fields=["state", "updated_at"])
        user.is_active = False
        await user.save(update_fields=["is_active", "updated_at"])
        self.events.record("account.deleted", user_id=str(user.id))
        return MessageResponse(message="Account deactivated")

    async def _get_existing_social_user(self, *, provider: str, provider_user_id: str) -> User | None:
        from vanty_auth.db.models import SocialAccount

        existing = await SocialAccount.filter(
            provider=provider,
            provider_user_id=provider_user_id,
        ).first()
        if existing:
            return await User.get(id=existing.user_id)
        return None
