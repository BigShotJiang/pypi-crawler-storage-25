from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import BaseModel, EmailStr, Field

from vanty_auth.core.schemas import MessageResponse
from vanty_auth.organizations.schemas import OrganizationSummary


class UserView(BaseModel):
    id: UUID
    email: EmailStr
    email_verified: bool
    display_name: str | None = None
    avatar_url: str | None = None
    mfa_enabled: bool
    created_at: datetime
    organizations: list[OrganizationSummary] = Field(default_factory=list)


class SessionView(BaseModel):
    id: UUID
    current: bool
    transport: str
    created_at: datetime
    last_seen_at: datetime
    ip_address: str | None = None
    user_agent: str | None = None
    active_organization_id: UUID | None = None


class AuthContextView(BaseModel):
    principal_type: str
    user_id: UUID | None
    session_id: UUID | None
    organization_id: UUID | None
    membership_id: UUID | None
    role_slug: str | None
    permissions: list[str]
    api_key_id: UUID | None
    request_id: str
    ip_address: str | None
    user_agent: str | None


class AuthResponse(BaseModel):
    user: UserView
    session: SessionView
    access_token: str
    refresh_token: str
    debug: dict[str, Any] | None = None


class MfaChallengeResponse(BaseModel):
    mfa_required: bool = True
    mfa_token: str


class SessionsResponse(BaseModel):
    sessions: list[SessionView]


class SignupRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class RefreshRequest(BaseModel):
    refresh_token: str


class ForgotPasswordRequest(BaseModel):
    email: EmailStr


class ResetPasswordRequest(BaseModel):
    token: str
    password: str = Field(min_length=8, max_length=128)


class ChangePasswordRequest(BaseModel):
    current_password: str
    new_password: str = Field(min_length=8, max_length=128)


class VerifyEmailRequest(BaseModel):
    token: str


class EmailChangeRequest(BaseModel):
    new_email: EmailStr


class UpdateProfileRequest(BaseModel):
    display_name: str | None = Field(default=None, max_length=255)
    avatar_url: str | None = Field(default=None, max_length=500)


@dataclass(slots=True)
class AuthFlowResult:
    body: AuthResponse | MfaChallengeResponse | MessageResponse
    session_secret: str | None = None
