from __future__ import annotations

from uuid import UUID

from vanty_auth.account.services import AuthService
from vanty_auth.core.exceptions import NotFound
from vanty_auth.core.schemas import MessageResponse
from vanty_auth.core.security import utcnow
from vanty_auth.db.models import AuthSession, RefreshToken, User


class SessionService:
    def __init__(self, *, auth_service: AuthService) -> None:
        self.auth_service = auth_service

    async def list_sessions(self, user: User, *, current_session: AuthSession):
        sessions = await AuthSession.filter(user=user, revoked_at__isnull=True).order_by("-created_at")
        return [
            await self.auth_service.session_view(item, current_session_id=current_session.id)
            for item in sessions
        ]

    async def revoke_session(self, user: User, *, session_id: UUID) -> MessageResponse:
        session = await AuthSession.filter(id=session_id, user=user, revoked_at__isnull=True).first()
        if not session:
            raise NotFound("Session not found")
        now = utcnow()
        session.revoked_at = now
        await session.save(update_fields=["revoked_at"])
        await RefreshToken.filter(session=session, revoked_at__isnull=True).update(revoked_at=now)
        return MessageResponse(message="Session revoked")

    async def revoke_other_sessions(
        self,
        user: User,
        *,
        current_session: AuthSession,
    ) -> MessageResponse:
        now = utcnow()
        other_sessions = await AuthSession.filter(user=user, revoked_at__isnull=True).exclude(
            id=current_session.id
        )
        session_ids = [session.id for session in other_sessions]
        for session in other_sessions:
            session.revoked_at = now
            await session.save(update_fields=["revoked_at"])
        if session_ids:
            await RefreshToken.filter(session_id__in=session_ids, revoked_at__isnull=True).update(
                revoked_at=now
            )
        return MessageResponse(message="Other sessions revoked")

    async def revoke_all_sessions(self, user: User) -> MessageResponse:
        now = utcnow()
        sessions = await AuthSession.filter(user=user, revoked_at__isnull=True)
        session_ids = [session.id for session in sessions]
        if session_ids:
            await AuthSession.filter(id__in=session_ids).update(revoked_at=now)
            await RefreshToken.filter(session_id__in=session_ids, revoked_at__isnull=True).update(
                revoked_at=now
            )
        return MessageResponse(message="All sessions revoked")
