from __future__ import annotations

import uuid
from typing import TYPE_CHECKING

from starlette.requests import Request

from vanty_auth.core.auth_context import AuthContext, AuthContextEnvelope, auth_context
from vanty_auth.core.rbac import permissions_for_role
from vanty_auth.db.models import ApiKey, AuthSession, OrganizationMembership, User

if TYPE_CHECKING:
    from vanty_auth.core.auth_backends import AuthBackend, AuthCredentials


class PermissionResolver:
    def resolve(
        self,
        membership: OrganizationMembership | None,
        *,
        api_key: ApiKey | None = None,
    ) -> list[str]:
        if api_key:
            return list(api_key.permissions)
        if membership:
            return permissions_for_role(membership.role_slug)
        return []


class OrganizationResolver:
    def __init__(self, *, organization_service) -> None:
        self.organization_service = organization_service

    async def resolve_for_session(self, *, user: User, session: AuthSession):
        return await self.organization_service.resolve_active_organization(user=user, session=session)


class AuthContextService:
    def __init__(
        self,
        *,
        backends: list[AuthBackend],
        organization_service,
        organization_resolver: OrganizationResolver,
        permission_resolver: PermissionResolver,
    ) -> None:
        self.backends = backends
        self.organization_service = organization_service
        self.organization_resolver = organization_resolver
        self.permission_resolver = permission_resolver

    async def resolve_request_context(self, request: Request) -> AuthContext | None:
        request_id = request.headers.get("x-request-id", str(uuid.uuid4()))

        credentials: AuthCredentials | None = None
        for backend in self.backends:
            credentials = await backend.authenticate(request)
            if credentials is not None:
                break

        if credentials is None:
            return None

        if credentials.principal_type == "api_key" and credentials.api_key is not None:
            api_key = credentials.api_key
            membership = await OrganizationMembership.filter(
                organization_id=api_key.organization_id,
                role_slug="owner",
                state="active",
            ).first()
            permissions = self.permission_resolver.resolve(membership, api_key=api_key)
            return AuthContext(
                principal_type="api_key",
                user_id=api_key.created_by_user_id,
                session_id=None,
                organization_id=api_key.organization_id,
                membership_id=membership.id if membership else None,
                role_slug=membership.role_slug if membership else None,
                permissions=permissions,
                api_key_id=api_key.id,
                request_id=request_id,
                ip_address=request.client.host if request.client else None,
                user_agent=request.headers.get("user-agent"),
            )

        user = credentials.user
        session = credentials.session
        if session is None:
            return None

        organization, membership = await self.organization_resolver.resolve_for_session(
            user=user,
            session=session,
        )
        permissions = self.permission_resolver.resolve(membership)
        return AuthContext(
            principal_type="user_session",
            user_id=user.id,
            session_id=session.id,
            organization_id=organization.id,
            membership_id=membership.id,
            role_slug=membership.role_slug,
            permissions=permissions,
            api_key_id=None,
            request_id=request_id,
            ip_address=request.client.host if request.client else None,
            user_agent=request.headers.get("user-agent"),
        )

    async def user_and_session_for_context(self, context: AuthContext) -> tuple[User | None, AuthSession | None]:
        user = await User.get(id=context.user_id) if context.user_id else None
        session = await AuthSession.get(id=context.session_id) if context.session_id else None
        return user, session

    def to_envelope(self, context: AuthContext | None) -> AuthContextEnvelope:
        if context is None:
            return AuthContextEnvelope(None, None, None, None, None, None)
        return AuthContextEnvelope(
            actor_user_id=context.user_id,
            session_id=context.session_id,
            organization_id=context.organization_id,
            membership_id=context.membership_id,
            api_key_id=context.api_key_id,
            request_id=context.request_id,
        )

    async def restore_envelope(self, envelope: AuthContextEnvelope) -> AuthContext | None:
        if (
            envelope.organization_id is None
            and envelope.actor_user_id is None
            and envelope.api_key_id is None
        ):
            return None
        membership = None
        if envelope.membership_id:
            membership = await OrganizationMembership.filter(id=envelope.membership_id, state="active").first()
        permissions = self.permission_resolver.resolve(membership)
        return AuthContext(
            principal_type="api_key" if envelope.api_key_id else "user_session",
            user_id=envelope.actor_user_id,
            session_id=envelope.session_id,
            organization_id=envelope.organization_id,
            membership_id=membership.id if membership else envelope.membership_id,
            role_slug=membership.role_slug if membership else None,
            permissions=permissions,
            api_key_id=envelope.api_key_id,
            request_id=envelope.request_id or str(uuid.uuid4()),
            ip_address=None,
            user_agent=None,
        )

    async def run_with_auth_context(self, envelope: AuthContextEnvelope, func, *args, **kwargs):
        restored = await self.restore_envelope(envelope)
        with auth_context(restored):
            return await func(*args, **kwargs)

    async def run_with_organization_context(self, organization_id, func, *args, **kwargs):
        restored = AuthContext(
            principal_type="system",
            user_id=None,
            session_id=None,
            organization_id=organization_id,
            membership_id=None,
            role_slug=None,
            permissions=[],
            api_key_id=None,
            request_id=str(uuid.uuid4()),
            ip_address=None,
            user_agent=None,
        )
        with auth_context(restored):
            return await func(*args, **kwargs)
