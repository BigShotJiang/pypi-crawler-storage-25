from __future__ import annotations

import pytest

from vanty_auth import AuthKit, AuthKitSettings
from vanty_auth.core.auth_context import AuthContextEnvelope
from vanty_auth.db.models import EmailAddress, OrganizationMembership, User

pytestmark = pytest.mark.integration


@pytest.mark.asyncio
async def test_auth_context_envelope_restore_rehydrates_permissions(tmp_path):
    settings = AuthKitSettings(
        database_url=f"sqlite://{tmp_path / 'jobs.db'}",
        secret_key="jobs-test-secret-key",
        debug_expose_secrets=True,
    )
    kit = AuthKit(settings=settings)
    await kit.init_orm(generate_schemas=True)
    try:
        user = await User.create(password_hash="hashed")
        await EmailAddress.create(
            user=user,
            email="worker@example.com",
            verified=True,
            primary=True,
            pending=False,
        )
        organization = await kit.organization_service.ensure_personal_organization(
            user,
            email="worker@example.com",
        )
        membership = await OrganizationMembership.get(organization=organization, user=user)
        envelope = AuthContextEnvelope(
            actor_user_id=user.id,
            session_id=None,
            organization_id=organization.id,
            membership_id=membership.id,
            api_key_id=None,
            request_id="job-request-id",
        )

        restored = await kit.auth_context_service.restore_envelope(envelope)

        assert restored is not None
        assert restored.organization_id == organization.id
        assert restored.role_slug == "owner"
        assert "org:api_keys:manage" in restored.permissions
    finally:
        await kit.close_orm()


@pytest.mark.asyncio
async def test_empty_auth_context_envelope_restores_to_none(tmp_path):
    settings = AuthKitSettings(
        database_url=f"sqlite://{tmp_path / 'jobs-empty.db'}",
        secret_key="jobs-test-secret-key",
        debug_expose_secrets=True,
    )
    kit = AuthKit(settings=settings)
    await kit.init_orm(generate_schemas=True)
    try:
        restored = await kit.auth_context_service.restore_envelope(
            AuthContextEnvelope(None, None, None, None, None, None)
        )

        assert restored is None
    finally:
        await kit.close_orm()
