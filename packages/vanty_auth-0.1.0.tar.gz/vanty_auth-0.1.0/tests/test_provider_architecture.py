from __future__ import annotations

import pytest

from vanty_auth.settings import AuthKitSettings, ProviderAppSettings
from vanty_auth.social.providers.github import GitHubProvider
from vanty_auth.social.providers.google import GoogleProvider
from vanty_auth.social.providers.registry import build_default_provider_registry
from vanty_auth.social.providers.resolver import (
    ProviderAppRecord,
    ProviderAppResolver,
)

pytestmark = pytest.mark.unit


class StubProviderAppRepository:
    def __init__(self, record: ProviderAppRecord | None = None) -> None:
        self.record = record

    async def get_enabled(self, provider_id: str) -> ProviderAppRecord | None:
        if self.record and self.record.provider == provider_id:
            return self.record
        return None


@pytest.mark.asyncio
async def test_provider_registry_resolves_settings_fallback():
    settings = AuthKitSettings(
        provider_apps={
            "github": ProviderAppSettings(
                client_id="settings-client",
                client_secret="settings-secret",
            )
        }
    )
    resolver = ProviderAppResolver(
        settings=settings,
        registry=build_default_provider_registry(),
        repository=StubProviderAppRepository(),
    )

    resolved = await resolver.resolve("github")

    assert resolved.client_id == "settings-client"
    assert resolved.authorize_url == "https://github.com/login/oauth/authorize"
    assert resolved.scopes == ["read:user", "user:email"]


@pytest.mark.asyncio
async def test_db_provider_config_overrides_settings_fallback():
    settings = AuthKitSettings(
        provider_apps={
            "github": ProviderAppSettings(
                client_id="settings-client",
                client_secret="settings-secret",
            )
        }
    )
    resolver = ProviderAppResolver(
        settings=settings,
        registry=build_default_provider_registry(),
        repository=StubProviderAppRepository(
            ProviderAppRecord(
                provider="github",
                protocol="oauth2",
                client_id="db-client",
                client_secret="db-secret",
                authorize_url="https://db.example/auth",
                token_url="https://db.example/token",
                userinfo_url="https://db.example/user",
                email_url="https://db.example/email",
                scopes=["custom:scope"],
            )
        ),
    )

    resolved = await resolver.resolve("github")

    assert resolved.client_id == "db-client"
    assert resolved.authorize_url == "https://db.example/auth"
    assert resolved.scopes == ["custom:scope"]


def test_provider_identity_normalization_is_provider_specific():
    google_identity = GoogleProvider().normalize_identity(
        {
            "sub": "google-user",
            "email": "hello@example.com",
            "email_verified": True,
            "name": "Hello",
            "picture": "https://example.com/avatar.png",
        },
        None,
    )
    github_identity = GitHubProvider().normalize_identity(
        {
            "id": 42,
            "login": "octocat",
            "avatar_url": "https://example.com/octocat.png",
        },
        [
            {
                "email": "octocat@example.com",
                "primary": True,
                "verified": True,
            }
        ],
    )

    assert google_identity.provider_user_id == "google-user"
    assert google_identity.email_verified is True
    assert github_identity.provider_user_id == "42"
    assert github_identity.email == "octocat@example.com"
