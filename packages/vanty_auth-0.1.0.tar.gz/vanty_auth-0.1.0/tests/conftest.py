from __future__ import annotations

import sqlite3
from collections.abc import Callable, Iterator
from contextlib import asynccontextmanager, contextmanager
from dataclasses import dataclass
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
from urllib.parse import parse_qs, urlparse
from uuid import uuid4

import httpx
import pyotp
import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from vanty_auth import AuthKit, AuthKitSettings, mount_auth_router

DEFAULT_PASSWORD = "s3cretPass!"
DEFAULT_SECRET_KEY = "test-secret-key-for-jwt-and-encryption"
REPO_ROOT = Path(__file__).resolve().parents[1]
REFERENCE_API_PATH = REPO_ROOT / "examples" / "reference-api" / "main.py"


@dataclass(slots=True)
class HTTPXCall:
    method: str
    url: str
    headers: dict[str, str] | None
    data: dict[str, str] | None


@dataclass(slots=True)
class HTTPXRoute:
    status_code: int
    payload: object


class HTTPXBoundary:
    def __init__(self, monkeypatch: pytest.MonkeyPatch) -> None:
        self._routes: dict[tuple[str, str], HTTPXRoute] = {}
        self.calls: list[HTTPXCall] = []
        monkeypatch.setattr(httpx, "AsyncClient", self._build_client())

    def add_json(
        self,
        method: str,
        url: str,
        payload: object,
        *,
        status_code: int = 200,
    ) -> None:
        self._routes[(method.upper(), url)] = HTTPXRoute(status_code=status_code, payload=payload)

    def _build_client(self):
        manager = self

        class FakeAsyncClient:
            def __init__(self, *args, **kwargs) -> None:
                del args, kwargs

            async def __aenter__(self) -> FakeAsyncClient:
                return self

            async def __aexit__(self, exc_type, exc, tb) -> bool:
                del exc_type, exc, tb
                return False

            async def get(self, url: str, *, headers: dict[str, str] | None = None):
                return manager._dispatch("GET", url, headers=headers, data=None)

            async def post(
                self,
                url: str,
                *,
                headers: dict[str, str] | None = None,
                data: dict[str, str] | None = None,
            ):
                return manager._dispatch("POST", url, headers=headers, data=data)

        return FakeAsyncClient

    def _dispatch(
        self,
        method: str,
        url: str,
        *,
        headers: dict[str, str] | None,
        data: dict[str, str] | None,
    ) -> httpx.Response:
        route = self._routes.get((method, url))
        if route is None:
            raise AssertionError(f"Unstubbed outbound HTTP request: {method} {url}")
        self.calls.append(HTTPXCall(method=method, url=url, headers=headers, data=data))
        request = httpx.Request(method, url, headers=headers)
        return httpx.Response(route.status_code, json=route.payload, request=request)


@contextmanager
def build_test_client(db_path: Path, **setting_overrides) -> Iterator[TestClient]:
    settings = AuthKitSettings(
        **{
            "database_url": f"sqlite://{db_path}",
            "secret_key": DEFAULT_SECRET_KEY,
            "debug_expose_secrets": True,
            "email_sender": "memory",
            **setting_overrides,
        }
    )
    app = FastAPI()
    kit = mount_auth_router(app, settings=settings)

    @asynccontextmanager
    async def lifespan(_: FastAPI):
        await kit.init_orm(generate_schemas=True)
        try:
            yield
        finally:
            await kit.close_orm()

    app.router.lifespan_context = lifespan
    with TestClient(app) as client:
        client.db_path = db_path
        client.auth_kit = kit
        client.auth_settings = settings
        yield client


@pytest.fixture
def make_client(tmp_path: Path) -> Callable[..., Iterator[TestClient]]:
    def factory(**setting_overrides) -> Iterator[TestClient]:
        db_path = tmp_path / f"{uuid4().hex}.db"
        return build_test_client(db_path, **setting_overrides)

    return factory


@pytest.fixture
def make_kit(tmp_path: Path):
    @asynccontextmanager
    async def factory(**setting_overrides):
        db_path = tmp_path / f"{uuid4().hex}.db"
        settings = AuthKitSettings(
            **{
                "database_url": f"sqlite://{db_path}",
                "secret_key": DEFAULT_SECRET_KEY,
                "debug_expose_secrets": True,
                "email_sender": "memory",
                **setting_overrides,
            }
        )
        kit = AuthKit(settings=settings)
        await kit.init_orm(generate_schemas=True)
        try:
            yield kit
        finally:
            await kit.close_orm()

    return factory


@pytest.fixture
def load_reference_app():
    def factory():
        spec = spec_from_file_location("reference_api_main", REFERENCE_API_PATH)
        assert spec and spec.loader
        module = module_from_spec(spec)
        spec.loader.exec_module(module)
        return module.app

    return factory


@pytest.fixture
def signup_user():
    def factory(client: TestClient, email: str, password: str = DEFAULT_PASSWORD) -> dict[str, object]:
        response = client.post("/auth/signup", json={"email": email, "password": password})
        assert response.status_code == 200
        return response.json()

    return factory


@pytest.fixture
def verify_email():
    def factory(client: TestClient, token: str) -> dict[str, object]:
        response = client.post("/auth/email/verify", json={"token": token})
        assert response.status_code == 200
        return response.json()

    return factory


@pytest.fixture
def login_user():
    def factory(client: TestClient, email: str, password: str = DEFAULT_PASSWORD) -> dict[str, object]:
        response = client.post("/auth/login", json={"email": email, "password": password})
        assert response.status_code == 200
        return response.json()

    return factory


@pytest.fixture
def signup_and_login(signup_user, verify_email, login_user):
    def factory(client: TestClient, email: str, password: str = DEFAULT_PASSWORD) -> dict[str, object]:
        signup_response = signup_user(client, email, password)
        verification_token = str(signup_response["debug"]["verification_token"])
        verify_email(client, verification_token)
        return login_user(client, email, password)

    return factory


@pytest.fixture
def auth_headers():
    def factory(payload: dict[str, object]) -> dict[str, str]:
        return {"Authorization": f"Bearer {payload['access_token']}"}

    return factory


@pytest.fixture
def extract_state():
    def factory(authorization_url: str) -> str:
        return parse_qs(urlparse(authorization_url).query)["state"][0]

    return factory


@pytest.fixture
def totp_now():
    def factory(secret: str) -> str:
        return pyotp.TOTP(secret).now()

    return factory


@pytest.fixture
def sqlite_execute():
    def factory(client: TestClient, statement: str, params: tuple[object, ...] = ()) -> None:
        db_path = Path(client.db_path)
        with sqlite3.connect(db_path) as connection:
            connection.execute(statement, params)
            connection.commit()

    return factory


@pytest.fixture
def insert_team_organization(sqlite_execute):
    def factory(
        client: TestClient,
        *,
        user_id: str,
        email: str,
        role_slug: str = "admin",
        name: str = "Team Workspace",
        slug: str | None = None,
    ) -> tuple[str, str]:
        organization_id = str(uuid4())
        membership_id = str(uuid4())
        organization_slug = slug or f"team-{uuid4().hex[:8]}"
        sqlite_execute(
            client,
            """
            INSERT INTO organization (id, name, slug, kind, owner_id, settings, is_active, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, '{}', 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            """,
            (organization_id, name, organization_slug, "organization", user_id),
        )
        sqlite_execute(
            client,
            """
            INSERT INTO organizationmembership (
                id, organization_id, user_id, invited_by_id, invited_email, state, role_slug, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            """,
            (membership_id, organization_id, user_id, user_id, email, "active", role_slug),
        )
        return organization_id, membership_id

    return factory


@pytest.fixture
def insert_membership(sqlite_execute):
    def factory(
        client: TestClient,
        *,
        organization_id: str,
        user_id: str | None,
        invited_by_id: str | None,
        invited_email: str,
        role_slug: str,
        state: str = "active",
    ) -> str:
        membership_id = str(uuid4())
        sqlite_execute(
            client,
            """
            INSERT INTO organizationmembership (
                id, organization_id, user_id, invited_by_id, invited_email, state, role_slug, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            """,
            (membership_id, organization_id, user_id, invited_by_id, invited_email, state, role_slug),
        )
        return membership_id

    return factory


@pytest.fixture
def insert_provider_app(sqlite_execute):
    def factory(
        client: TestClient,
        *,
        provider: str = "github",
        client_id: str = "client-id",
        client_secret: str = "client-secret",
        authorize_url: str = "https://example.com/auth",
        token_url: str = "https://example.com/token",
        userinfo_url: str = "https://example.com/user",
        email_url: str = "https://example.com/email",
        scopes: str = '["read:user", "user:email"]',
    ) -> str:
        provider_app_id = str(uuid4())
        sqlite_execute(
            client,
            """
            INSERT INTO providerapp (
                id, provider, protocol, client_id, client_secret, authorize_url,
                token_url, userinfo_url, email_url, scopes, enabled, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            """,
            (
                provider_app_id,
                provider,
                "oauth2",
                client_id,
                client_secret,
                authorize_url,
                token_url,
                userinfo_url,
                email_url,
                scopes,
                1,
            ),
        )
        return provider_app_id

    return factory


@pytest.fixture
def httpx_boundary(monkeypatch: pytest.MonkeyPatch) -> HTTPXBoundary:
    return HTTPXBoundary(monkeypatch)
