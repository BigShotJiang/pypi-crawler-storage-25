from __future__ import annotations

from uuid import uuid4

import pytest

from vanty_auth.core.exceptions import NotFound
from vanty_auth.db.models import EmailAddress, User

pytestmark = pytest.mark.unit


@pytest.mark.asyncio
async def test_list_all_organizations(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        await EmailAddress.create(user=user, email="u@test.com", verified=True, primary=True, pending=False)
        await kit.organization_service.ensure_personal_organization(user, email="u@test.com")
        await kit.organization_service.create_organization(user, name="Org A")
        await kit.organization_service.create_organization(user, name="Org B")

        orgs, total = await kit.admin_service.list_all_organizations()

        assert total == 3  # personal + 2 orgs
        assert len(orgs) == 3


@pytest.mark.asyncio
async def test_list_all_organizations_search(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        await EmailAddress.create(user=user, email="u@test.com", verified=True, primary=True, pending=False)
        await kit.organization_service.create_organization(user, name="Alpha Corp", slug="alpha")
        await kit.organization_service.create_organization(user, name="Beta Inc", slug="beta")

        orgs, total = await kit.admin_service.list_all_organizations(search="alpha")

        assert total == 1
        assert orgs[0].name == "Alpha Corp"


@pytest.mark.asyncio
async def test_get_organization_admin_detail(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        await EmailAddress.create(user=user, email="u@test.com", verified=True, primary=True, pending=False)
        detail = await kit.organization_service.create_organization(user, name="Org")

        result = await kit.admin_service.get_organization_admin_detail(detail.id)

        assert result.organization.name == "Org"
        assert len(result.members) == 1
        assert result.members[0].role_slug == "owner"


@pytest.mark.asyncio
async def test_update_organization_admin(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        await EmailAddress.create(user=user, email="u@test.com", verified=True, primary=True, pending=False)
        detail = await kit.organization_service.create_organization(user, name="Org")

        updated = await kit.admin_service.update_organization_admin(detail.id, is_active=False)

        assert updated.is_active is False

        re_enabled = await kit.admin_service.update_organization_admin(detail.id, is_active=True)

        assert re_enabled.is_active is True


@pytest.mark.asyncio
async def test_list_all_users(make_kit):
    async with make_kit() as kit:
        u1 = await User.create(password_hash="hashed", display_name="Alice")
        await EmailAddress.create(user=u1, email="a@test.com", verified=True, primary=True, pending=False)
        u2 = await User.create(password_hash="hashed", display_name="Bob")
        await EmailAddress.create(user=u2, email="b@test.com", verified=True, primary=True, pending=False)

        users, total = await kit.admin_service.list_all_users()

        assert total == 2
        assert len(users) == 2


@pytest.mark.asyncio
async def test_list_all_users_search(make_kit):
    async with make_kit() as kit:
        u1 = await User.create(password_hash="hashed", display_name="Alice")
        await EmailAddress.create(user=u1, email="alice@test.com", verified=True, primary=True, pending=False)
        u2 = await User.create(password_hash="hashed", display_name="Bob")
        await EmailAddress.create(user=u2, email="bob@test.com", verified=True, primary=True, pending=False)

        users, total = await kit.admin_service.list_all_users(search="alice")

        assert total == 1
        assert users[0].display_name == "Alice"


@pytest.mark.asyncio
async def test_get_user_admin_detail(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed", display_name="Alice")
        await EmailAddress.create(user=user, email="a@test.com", verified=True, primary=True, pending=False)
        await kit.organization_service.ensure_personal_organization(user, email="a@test.com")

        result = await kit.admin_service.get_user_admin_detail(user.id)

        assert result.user.display_name == "Alice"
        assert result.user.email == "a@test.com"
        assert len(result.organizations) == 1


@pytest.mark.asyncio
async def test_update_user_admin(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        await EmailAddress.create(user=user, email="u@test.com", verified=True, primary=True, pending=False)

        updated = await kit.admin_service.update_user_admin(user.id, is_active=False)

        assert updated.is_active is False

        updated2 = await kit.admin_service.update_user_admin(user.id, is_superuser=True)

        assert updated2.is_superuser is True


@pytest.mark.asyncio
async def test_update_user_admin_not_found(make_kit):
    async with make_kit() as kit:
        with pytest.raises(NotFound):
            await kit.admin_service.update_user_admin(uuid4(), is_active=False)


@pytest.mark.asyncio
async def test_platform_stats(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        await EmailAddress.create(user=user, email="u@test.com", verified=True, primary=True, pending=False)
        await kit.organization_service.ensure_personal_organization(user, email="u@test.com")

        stats = await kit.admin_service.get_platform_stats()

        assert stats.total_users == 1
        assert stats.active_users == 1
        assert stats.total_organizations >= 1
