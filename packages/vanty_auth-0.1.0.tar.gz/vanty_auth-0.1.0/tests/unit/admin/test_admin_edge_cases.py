from __future__ import annotations

from uuid import uuid4

import pytest

from vanty_auth.core.exceptions import NotFound
from vanty_auth.db.models import EmailAddress, User

pytestmark = pytest.mark.unit


@pytest.mark.asyncio
async def test_list_all_organizations_filter_active(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        await EmailAddress.create(user=user, email="u@test.com", verified=True, primary=True, pending=False)
        await kit.organization_service.create_organization(user, name="Active Org")
        inactive = await kit.organization_service.create_organization(user, name="Inactive Org")
        await kit.admin_service.update_organization_admin(inactive.id, is_active=False)

        active_orgs, active_total = await kit.admin_service.list_all_organizations(is_active=True)
        all_orgs, all_total = await kit.admin_service.list_all_organizations()

        assert active_total == 1
        assert all_total == 2


@pytest.mark.asyncio
async def test_get_organization_admin_detail_not_found(make_kit):
    async with make_kit() as kit:
        with pytest.raises(NotFound):
            await kit.admin_service.get_organization_admin_detail(uuid4())


@pytest.mark.asyncio
async def test_update_organization_admin_not_found(make_kit):
    async with make_kit() as kit:
        with pytest.raises(NotFound):
            await kit.admin_service.update_organization_admin(uuid4(), is_active=False)


@pytest.mark.asyncio
async def test_update_organization_admin_name(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        await EmailAddress.create(user=user, email="u@test.com", verified=True, primary=True, pending=False)
        detail = await kit.organization_service.create_organization(user, name="Old")

        updated = await kit.admin_service.update_organization_admin(detail.id, name="New")

        assert updated.name == "New"


@pytest.mark.asyncio
async def test_list_all_users_filter_active(make_kit):
    async with make_kit() as kit:
        u1 = await User.create(password_hash="hashed", is_active=True)
        await EmailAddress.create(user=u1, email="a@test.com", verified=True, primary=True, pending=False)
        u2 = await User.create(password_hash="hashed", is_active=False)
        await EmailAddress.create(user=u2, email="b@test.com", verified=True, primary=True, pending=False)

        active_users, active_total = await kit.admin_service.list_all_users(is_active=True)

        assert active_total == 1


@pytest.mark.asyncio
async def test_get_user_admin_detail_not_found(make_kit):
    async with make_kit() as kit:
        with pytest.raises(NotFound):
            await kit.admin_service.get_user_admin_detail(uuid4())
