from __future__ import annotations

from types import SimpleNamespace

import pyotp
import pytest
from starlette.requests import Request

from vanty_auth.core.exceptions import InvalidState
from vanty_auth.core.security import issue_pending_mfa_token
from vanty_auth.db.models import EmailAddress, User

pytestmark = pytest.mark.unit


def make_request() -> Request:
    scope = {
        "type": "http",
        "headers": [],
        "client": ("127.0.0.1", 1234),
        "state": {},
        "app": SimpleNamespace(state=SimpleNamespace()),
    }
    return Request(scope)


@pytest.mark.asyncio
async def test_verify_totp_requires_enabled_mfa(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        await EmailAddress.create(
            user=user,
            email="mfa-user@example.com",
            verified=True,
            primary=True,
            pending=False,
        )
        mfa_token = issue_pending_mfa_token(kit.settings, user_id=user.id)

        with pytest.raises(InvalidState, match="MFA is not enabled"):
            await kit.mfa_service.verify_totp(
                make_request(),
                mfa_token=mfa_token,
                code="123456",
                recovery_code=None,
            )


@pytest.mark.asyncio
async def test_regenerate_recovery_codes_requires_enabled_mfa(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        await EmailAddress.create(
            user=user,
            email="mfa-user@example.com",
            verified=True,
            primary=True,
            pending=False,
        )

        with pytest.raises(InvalidState, match="MFA is not enabled"):
            await kit.mfa_service.regenerate_recovery_codes(user)


@pytest.mark.asyncio
async def test_enroll_totp_replaces_previous_recovery_codes(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        await EmailAddress.create(
            user=user,
            email="mfa-user@example.com",
            verified=True,
            primary=True,
            pending=False,
        )
        first = await kit.mfa_service.enroll_totp(user)
        await kit.mfa_service.confirm_totp(user, code=pyotp.TOTP(first.secret).now())
        second = await kit.mfa_service.enroll_totp(user)

        assert second.authenticator_id != first.authenticator_id
