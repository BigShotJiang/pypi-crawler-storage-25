from __future__ import annotations

import pytest

from vanty_auth.social.providers.github import GitHubProvider
from vanty_auth.social.providers.identity import ProviderDefinition, ProviderIdentity, ResolvedProviderApp
from vanty_auth.social.providers.oauth2 import OAuth2Provider
from vanty_auth.social.providers.registry import ProviderRegistry

pytestmark = pytest.mark.unit


class DummyProvider(OAuth2Provider):
    definition = ProviderDefinition(provider_id="dummy", display_name="Dummy")

    def normalize_identity(self, user_data: dict[str, object], email_data: object | None) -> ProviderIdentity:
        del email_data
        return ProviderIdentity(
            provider_user_id=str(user_data["id"]),
            email=None,
            email_verified=False,
            name=None,
            avatar_url=None,
            raw=user_data,
        )


def test_build_authorization_url_includes_expected_query_parameters():
    provider = DummyProvider()
    provider_app = ResolvedProviderApp(
        provider_id="dummy",
        client_id="client-id",
        client_secret="client-secret",
        authorize_url="https://example.com/auth",
        scopes=["profile"],
    )

    url = provider.build_authorization_url(
        provider_app,
        redirect_uri="http://localhost/callback",
        state="state-123",
        code_challenge="challenge-123",
    )

    assert "client_id=client-id" in url
    assert "redirect_uri=http%3A%2F%2Flocalhost%2Fcallback" in url
    assert "state=state-123" in url
    assert "code_challenge=challenge-123" in url


@pytest.mark.asyncio
async def test_exchange_code_requires_token_url():
    provider = DummyProvider()
    provider_app = ResolvedProviderApp(
        provider_id="dummy",
        client_id="client-id",
        client_secret="client-secret",
        token_url=None,
    )

    with pytest.raises(ValueError, match="missing a token URL"):
        await provider.exchange_code(
            provider_app,
            redirect_uri="http://localhost/callback",
            code="oauth-code",
            code_verifier="verifier",
        )


@pytest.mark.asyncio
async def test_fetch_user_payload_requires_userinfo_url():
    provider = DummyProvider()
    provider_app = ResolvedProviderApp(
        provider_id="dummy",
        client_id="client-id",
        client_secret="client-secret",
        userinfo_url=None,
    )

    with pytest.raises(ValueError, match="missing a userinfo URL"):
        await provider.fetch_user_payload(
            client=None,
            provider_app=provider_app,
            headers={},
        )


@pytest.mark.asyncio
async def test_github_fetch_email_payload_returns_none_without_email_url():
    provider = GitHubProvider()
    provider_app = ResolvedProviderApp(
        provider_id="github",
        client_id="client-id",
        client_secret="client-secret",
        email_url=None,
    )

    email_payload = await provider.fetch_email_payload(
        client=None,
        provider_app=provider_app,
        headers={},
    )

    assert email_payload is None


def test_provider_registry_values_returns_registered_providers():
    providers = ProviderRegistry([DummyProvider()])

    assert tuple(provider.provider_id for provider in providers.values()) == ("dummy",)
