from __future__ import annotations

from unittest.mock import Mock

import pytest

from vanty_auth.core.exceptions import InvalidState
from vanty_auth.social.providers.base import Provider
from vanty_auth.social.providers.identity import ProviderDefinition, ProviderIdentity, ResolvedProviderApp
from vanty_auth.social.providers.registry import ProviderRegistry
from vanty_auth.social.services import SocialAuthService

pytestmark = pytest.mark.unit


class NonOAuthProvider(Provider):
    definition = ProviderDefinition(provider_id="non-oauth", display_name="Non OAuth", protocol="custom")

    async def fetch_identity(
        self,
        provider_app: ResolvedProviderApp,
        token_payload: dict[str, object],
    ) -> ProviderIdentity:
        del provider_app, token_payload
        return ProviderIdentity(
            provider_user_id="123",
            email=None,
            email_verified=False,
            name=None,
            avatar_url=None,
            raw={},
        )


def test_social_service_rejects_non_oauth_providers():
    service = SocialAuthService(
        auth_service=Mock(),
        provider_registry=ProviderRegistry([NonOAuthProvider()]),
        provider_app_resolver=Mock(),
        social_repository=Mock(),
    )

    with pytest.raises(InvalidState, match="does not support OAuth2"):
        service._oauth2_provider("non-oauth")
