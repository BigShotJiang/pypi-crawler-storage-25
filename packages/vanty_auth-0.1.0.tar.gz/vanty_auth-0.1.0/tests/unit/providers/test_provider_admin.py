from __future__ import annotations

from uuid import uuid4

import pytest

from vanty_auth.core.exceptions import NotFound
from vanty_auth.db.models import ProviderApp

pytestmark = pytest.mark.unit


@pytest.mark.asyncio
async def test_list_enabled_providers_empty(make_kit):
    async with make_kit() as kit:
        result = await kit.provider_admin_service.list_enabled_providers()

        assert result == []


@pytest.mark.asyncio
async def test_list_enabled_providers_from_db(make_kit):
    async with make_kit() as kit:
        await ProviderApp.create(
            provider="github", protocol="oauth2",
            client_id="cid", client_secret="csecret",
            authorize_url="https://auth.example.com",
            token_url="https://token.example.com",
            userinfo_url="https://userinfo.example.com",
            enabled=True,
        )
        await ProviderApp.create(
            provider="google", protocol="oauth2",
            client_id="cid2", client_secret="csecret2",
            authorize_url="https://auth2.example.com",
            token_url="https://token2.example.com",
            userinfo_url="https://userinfo2.example.com",
            enabled=False,
        )

        result = await kit.provider_admin_service.list_enabled_providers()

        assert "github" in result
        assert "google" not in result


@pytest.mark.asyncio
async def test_create_or_update_provider_creates(make_kit):
    async with make_kit() as kit:
        view = await kit.provider_admin_service.create_or_update_provider(
            provider="github", client_id="cid", client_secret="csecret",
            authorize_url="https://auth.example.com",
            token_url="https://token.example.com",
            userinfo_url="https://userinfo.example.com",
        )

        assert view.provider == "github"
        assert view.client_id == "cid"
        assert view.enabled is True


@pytest.mark.asyncio
async def test_create_or_update_provider_updates(make_kit):
    async with make_kit() as kit:
        await kit.provider_admin_service.create_or_update_provider(
            provider="github", client_id="old", client_secret="csecret",
            authorize_url="https://auth.example.com",
            token_url="https://token.example.com",
            userinfo_url="https://userinfo.example.com",
        )

        updated = await kit.provider_admin_service.create_or_update_provider(
            provider="github", client_id="new-id", client_secret="new-secret",
            authorize_url="https://auth2.example.com",
            token_url="https://token2.example.com",
            userinfo_url="https://userinfo2.example.com",
        )

        assert updated.client_id == "new-id"
        assert await ProviderApp.all().count() == 1


@pytest.mark.asyncio
async def test_list_provider_configs(make_kit):
    async with make_kit() as kit:
        await kit.provider_admin_service.create_or_update_provider(
            provider="github", client_id="cid", client_secret="csecret",
            authorize_url="https://auth.example.com",
            token_url="https://token.example.com",
            userinfo_url="https://userinfo.example.com",
        )

        configs = await kit.provider_admin_service.list_provider_configs()

        assert len(configs) == 1
        assert configs[0].provider == "github"


@pytest.mark.asyncio
async def test_get_provider_config(make_kit):
    async with make_kit() as kit:
        view = await kit.provider_admin_service.create_or_update_provider(
            provider="github", client_id="cid", client_secret="csecret",
            authorize_url="https://auth.example.com",
            token_url="https://token.example.com",
            userinfo_url="https://userinfo.example.com",
        )

        config = await kit.provider_admin_service.get_provider_config(view.id)

        assert config.provider == "github"


@pytest.mark.asyncio
async def test_get_provider_config_not_found(make_kit):
    async with make_kit() as kit:
        with pytest.raises(NotFound):
            await kit.provider_admin_service.get_provider_config(uuid4())


@pytest.mark.asyncio
async def test_delete_provider(make_kit):
    async with make_kit() as kit:
        view = await kit.provider_admin_service.create_or_update_provider(
            provider="github", client_id="cid", client_secret="csecret",
            authorize_url="https://auth.example.com",
            token_url="https://token.example.com",
            userinfo_url="https://userinfo.example.com",
        )

        result = await kit.provider_admin_service.delete_provider(view.id)

        assert result.message == "Provider deleted"
        assert not await ProviderApp.filter(id=view.id).exists()


@pytest.mark.asyncio
async def test_delete_provider_not_found(make_kit):
    async with make_kit() as kit:
        with pytest.raises(NotFound):
            await kit.provider_admin_service.delete_provider(uuid4())


@pytest.mark.asyncio
async def test_security_overview(make_kit):
    async with make_kit() as kit:
        from vanty_auth.db.models import EmailAddress, User

        user = await User.create(password_hash="hashed")
        await EmailAddress.create(user=user, email="u@test.com", verified=True, primary=True, pending=False)

        overview = await kit.provider_admin_service.get_security_overview()

        assert overview.total_users == 1
        assert overview.active_sessions == 0
        assert overview.mfa_enabled_count == 0
        assert isinstance(overview.enabled_providers, list)
