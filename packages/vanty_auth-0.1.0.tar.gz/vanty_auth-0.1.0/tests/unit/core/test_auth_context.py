from __future__ import annotations

import asyncio
from uuid import uuid4

import pytest
from asgiref.sync import async_to_sync, sync_to_async

from vanty_auth.core.auth_context import (
    AuthContext,
    auth_context,
    auth_local,
    get_current_auth_context,
    require_current_auth_context,
)

pytestmark = pytest.mark.unit


def build_context() -> AuthContext:
    return AuthContext(
        principal_type="user_session",
        user_id=uuid4(),
        session_id=uuid4(),
        organization_id=uuid4(),
        membership_id=uuid4(),
        role_slug="owner",
        permissions=["org:api_keys:manage"],
        api_key_id=None,
        request_id="request-id",
        ip_address="127.0.0.1",
        user_agent="pytest",
    )


def test_auth_context_manager_sets_and_resets_current_context():
    context = build_context()

    with auth_context(context):
        assert get_current_auth_context() == context
        assert require_current_auth_context() == context

    assert get_current_auth_context() is None


def test_auth_context_manager_restores_previous_context_after_nested_scope():
    outer = build_context()
    inner = build_context()

    with auth_context(outer):
        assert get_current_auth_context() == outer
        with auth_context(inner):
            assert get_current_auth_context() == inner
        assert get_current_auth_context() == outer

    assert get_current_auth_context() is None


def test_auth_local_reads_and_updates_active_context():
    context = build_context()

    with auth_context(context):
        assert auth_local.role_slug == "owner"
        auth_local.role_slug = "admin"
        assert require_current_auth_context().role_slug == "admin"


def test_auth_local_and_require_current_context_fail_without_context():
    with pytest.raises(AttributeError):
        _ = auth_local.role_slug

    with pytest.raises(AttributeError):
        auth_local.role_slug = "admin"

    with pytest.raises(RuntimeError):
        require_current_auth_context()


@pytest.mark.asyncio
async def test_current_context_survives_async_sync_async_with_asgiref_bridges():
    context = build_context()

    async def read_async_context() -> AuthContext | None:
        await asyncio.sleep(0)
        return get_current_auth_context()

    def sync_hop() -> tuple[AuthContext | None, AuthContext | None]:
        during_sync = get_current_auth_context()
        back_in_async = async_to_sync(read_async_context)()
        return during_sync, back_in_async

    with auth_context(context):
        before = get_current_auth_context()
        during_sync, after = await sync_to_async(sync_hop)()

    assert before == context
    assert during_sync == context
    assert after == context
    assert get_current_auth_context() is None


@pytest.mark.asyncio
async def test_current_context_does_not_implicitly_cross_run_in_executor_boundary():
    context = build_context()
    loop = asyncio.get_running_loop()

    with auth_context(context):
        seen_in_executor = await loop.run_in_executor(None, get_current_auth_context)

    assert seen_in_executor is None


def test_current_context_survives_sync_async_sync_with_asgiref_bridges():
    context = build_context()

    async def async_hop() -> tuple[AuthContext | None, AuthContext | None]:
        during_async = get_current_auth_context()
        back_in_sync = await sync_to_async(get_current_auth_context)()
        return during_async, back_in_sync

    with auth_context(context):
        before = get_current_auth_context()
        during_async, after = async_to_sync(async_hop)()

    assert before == context
    assert during_async == context
    assert after == context
    assert get_current_auth_context() is None
