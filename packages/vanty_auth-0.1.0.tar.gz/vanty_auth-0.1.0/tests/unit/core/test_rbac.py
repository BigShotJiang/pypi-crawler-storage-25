from __future__ import annotations

from uuid import uuid4

import pytest

from vanty_auth.core.rbac import (
    REGISTERED_PERMISSIONS,
    RoleDefinition,
    permissions_for_role,
    register_permission,
    register_role_definition,
)

pytestmark = pytest.mark.unit


def test_unknown_role_falls_back_to_member_permissions():
    assert permissions_for_role("not-a-real-role") == ["org:members:read"]


def test_register_role_definition_and_permission_extend_registry():
    permission = f"custom:permission:{uuid4()}"
    role = RoleDefinition(slug=f"custom-role-{uuid4().hex[:8]}", permissions=(permission,))

    register_role_definition(role)
    register_permission(permission + ":extra")

    assert permission in permissions_for_role(role.slug)
    assert permission + ":extra" in REGISTERED_PERMISSIONS
