from __future__ import annotations

import logging

import pytest

from vanty_auth.core.email import EmailPayload, LoggingEmailSender, MemoryEmailSender

pytestmark = pytest.mark.unit


@pytest.mark.asyncio
async def test_memory_email_sender_collects_outbox():
    sender = MemoryEmailSender()
    payload = EmailPayload(to="hello@example.com", subject="Hello", body="Body")

    await sender.send(payload)

    assert sender.outbox == [payload]


@pytest.mark.asyncio
async def test_logging_email_sender_emits_log(caplog: pytest.LogCaptureFixture):
    sender = LoggingEmailSender()
    payload = EmailPayload(to="hello@example.com", subject="Hello", body="Body", meta={"purpose": "test"})

    with caplog.at_level(logging.INFO):
        await sender.send(payload)

    assert "auth-kit email to=hello@example.com subject=Hello" in caplog.text
