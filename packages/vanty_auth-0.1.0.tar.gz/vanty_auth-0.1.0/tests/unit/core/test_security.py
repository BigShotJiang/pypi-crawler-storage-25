from __future__ import annotations

from uuid import uuid4

import pytest

from vanty_auth.core.security import (
    RateLimiter,
    decode_access_token,
    decode_pending_mfa_token,
    decrypt_text,
    encrypt_text,
    hash_password,
    issue_access_token,
    issue_pending_mfa_token,
    verify_password,
)
from vanty_auth.settings import AuthKitSettings

pytestmark = pytest.mark.unit


def test_password_hashing_and_verification_round_trip():
    password_hash = hash_password("s3cretPass!")

    assert verify_password("s3cretPass!", password_hash) is True
    assert verify_password("wrong-pass", password_hash) is False


def test_encrypt_and_decrypt_round_trip():
    settings = AuthKitSettings(secret_key="security-test-key-security-test-key")
    encrypted = encrypt_text(settings, "hello world")

    assert decrypt_text(settings, encrypted) == "hello world"


def test_issue_and_decode_tokens():
    settings = AuthKitSettings(secret_key="token-test-key-token-test-key-token")
    user_id = uuid4()
    session_id = uuid4()

    access_token = issue_access_token(settings, user_id=user_id, session_id=session_id)
    pending_token = issue_pending_mfa_token(settings, user_id=user_id)

    access_payload = decode_access_token(settings, access_token)
    pending_payload = decode_pending_mfa_token(settings, pending_token)

    assert access_payload["sub"] == str(user_id)
    assert access_payload["sid"] == str(session_id)
    assert pending_payload["sub"] == str(user_id)
    assert pending_payload["typ"] == "mfa"


def test_rate_limiter_blocks_after_limit():
    limiter = RateLimiter()

    assert limiter.allow(key="login:user@example.com", limit=2, window_seconds=60) is True
    assert limiter.allow(key="login:user@example.com", limit=2, window_seconds=60) is True
    assert limiter.allow(key="login:user@example.com", limit=2, window_seconds=60) is False
