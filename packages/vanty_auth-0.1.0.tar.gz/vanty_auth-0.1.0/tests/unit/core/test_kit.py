from __future__ import annotations

from uuid import uuid4

import pytest
from fastapi import FastAPI

from vanty_auth import mount_auth_router
from vanty_auth.core.auth_context import AuthContext, AuthContextEnvelope, auth_context
from vanty_auth.core.rbac import RoleDefinition, permissions_for_role
from vanty_auth.db.models import EmailAddress, OrganizationMembership, User
from vanty_auth.fastapi.middleware import AuthContextMiddleware

pytestmark = pytest.mark.unit


@pytest.mark.asyncio
async def test_kit_init_orm_is_idempotent_and_role_registration_works(make_kit):
    async with make_kit() as kit:
        role = RoleDefinition(slug=f"qa-{uuid4().hex[:8]}", permissions=("org:test:manage",))

        await kit.init_orm(generate_schemas=True)
        kit.register_role(role)
        kit.register_permission("org:test:read")

        assert "org:test:manage" in permissions_for_role(role.slug)


@pytest.mark.asyncio
async def test_run_with_auth_context_restores_context(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        await EmailAddress.create(
            user=user,
            email="worker@example.com",
            verified=True,
            primary=True,
            pending=False,
        )
        organization = await kit.organization_service.ensure_personal_organization(
            user,
            email="worker@example.com",
        )
        membership = await OrganizationMembership.get(organization=organization, user=user)
        envelope = AuthContextEnvelope(
            actor_user_id=user.id,
            session_id=None,
            organization_id=organization.id,
            membership_id=membership.id,
            api_key_id=None,
            request_id="request-id",
        )

        async def current_org_id():
            from vanty_auth.core.auth_context import require_current_auth_context

            return require_current_auth_context().organization_id

        restored_org_id = await kit.run_with_auth_context(envelope, current_org_id)
        system_org_id = await kit.run_with_organization_context(organization.id, current_org_id)

        assert restored_org_id == organization.id
        assert system_org_id == organization.id


@pytest.mark.asyncio
async def test_serialize_current_context_uses_active_context(make_kit):
    async with make_kit() as kit:
        context = AuthContext(
            principal_type="user_session",
            user_id=uuid4(),
            session_id=uuid4(),
            organization_id=uuid4(),
            membership_id=uuid4(),
            role_slug="owner",
            permissions=["org:api_keys:manage"],
            api_key_id=None,
            request_id="request-id",
            ip_address=None,
            user_agent=None,
        )

        with auth_context(context):
            envelope = kit.serialize_current_context()

        assert envelope.actor_user_id == context.user_id
        assert envelope.organization_id == context.organization_id


def test_mount_auth_router_adds_middleware_once():
    app = FastAPI()

    mount_auth_router(app)
    mount_auth_router(app)

    middleware_classes = [item.cls for item in app.user_middleware]
    assert middleware_classes.count(AuthContextMiddleware) == 1
