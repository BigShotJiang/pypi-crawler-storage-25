from __future__ import annotations

import pytest

from vanty_auth.core.events import EventRecorder

pytestmark = pytest.mark.unit


def test_event_recorder_drains_and_clears_events():
    recorder = EventRecorder()
    recorder.record("user.logged_in", user_id="123")
    recorder.record("user.logged_out", user_id="123")

    events = recorder.drain()

    assert [event.name for event in events] == ["user.logged_in", "user.logged_out"]
    assert events[0].payload == {"user_id": "123"}
    assert recorder.drain() == []
