from __future__ import annotations

from datetime import timedelta

import pytest

from vanty_auth.core.exceptions import Conflict, NotFound
from vanty_auth.core.security import utcnow
from vanty_auth.db.models import BlockedIP

pytestmark = pytest.mark.unit


@pytest.mark.asyncio
async def test_record_login_attempt(make_kit):
    async with make_kit() as kit:
        await kit.security_service.record_login_attempt(
            email="test@test.com", ip_address="1.2.3.4",
            user_agent="TestUA", success=True,
        )

        attempts, total = await kit.security_service.list_login_attempts(limit=10, offset=0)
        assert total == 1
        assert attempts[0].email == "test@test.com"
        assert attempts[0].success is True


@pytest.mark.asyncio
async def test_record_failed_login_attempt(make_kit):
    async with make_kit() as kit:
        await kit.security_service.record_login_attempt(
            email="test@test.com", ip_address="1.2.3.4",
            user_agent="TestUA", success=False, failure_reason="invalid_credentials",
        )

        attempts, total = await kit.security_service.list_login_attempts(
            limit=10, offset=0, success=False
        )
        assert total == 1
        assert attempts[0].failure_reason == "invalid_credentials"


@pytest.mark.asyncio
async def test_list_login_attempts_filter_by_email(make_kit):
    async with make_kit() as kit:
        await kit.security_service.record_login_attempt(
            email="a@test.com", ip_address="1.1.1.1", user_agent="", success=True,
        )
        await kit.security_service.record_login_attempt(
            email="b@test.com", ip_address="2.2.2.2", user_agent="", success=False,
        )

        attempts, total = await kit.security_service.list_login_attempts(
            limit=10, offset=0, email="a@test.com"
        )
        assert total == 1
        assert attempts[0].email == "a@test.com"


@pytest.mark.asyncio
async def test_block_and_check_ip(make_kit):
    async with make_kit() as kit:
        assert await kit.security_service.is_ip_blocked("5.5.5.5") is False

        view = await kit.security_service.block_ip(ip_address="5.5.5.5", reason="Abuse")

        assert view.ip_address == "5.5.5.5"
        assert view.reason == "Abuse"
        assert await kit.security_service.is_ip_blocked("5.5.5.5") is True


@pytest.mark.asyncio
async def test_block_ip_duplicate_raises_conflict(make_kit):
    async with make_kit() as kit:
        await kit.security_service.block_ip(ip_address="5.5.5.5", reason="Abuse")

        with pytest.raises(Conflict, match="already blocked"):
            await kit.security_service.block_ip(ip_address="5.5.5.5")


@pytest.mark.asyncio
async def test_unblock_ip(make_kit):
    async with make_kit() as kit:
        await kit.security_service.block_ip(ip_address="5.5.5.5", reason="Abuse")

        result = await kit.security_service.unblock_ip("5.5.5.5")

        assert result.message == "IP address unblocked"
        assert await kit.security_service.is_ip_blocked("5.5.5.5") is False


@pytest.mark.asyncio
async def test_unblock_ip_not_found(make_kit):
    async with make_kit() as kit:
        with pytest.raises(NotFound):
            await kit.security_service.unblock_ip("9.9.9.9")


@pytest.mark.asyncio
async def test_list_blocked_ips(make_kit):
    async with make_kit() as kit:
        await kit.security_service.block_ip(ip_address="1.1.1.1")
        await kit.security_service.block_ip(ip_address="2.2.2.2")

        blocked = await kit.security_service.list_blocked_ips()

        assert len(blocked) == 2


@pytest.mark.asyncio
async def test_expired_block_is_cleaned_up(make_kit):
    async with make_kit() as kit:
        await BlockedIP.create(
            ip_address="6.6.6.6",
            reason="expired",
            expires_at=utcnow() - timedelta(hours=1),
        )

        assert await kit.security_service.is_ip_blocked("6.6.6.6") is False
        assert not await BlockedIP.filter(ip_address="6.6.6.6").exists()


@pytest.mark.asyncio
async def test_auto_block_threshold(make_kit):
    async with make_kit(max_login_attempts_before_block=3, login_attempt_window_minutes=60) as kit:
        for _ in range(3):
            await kit.security_service.record_login_attempt(
                email="spam@test.com", ip_address="7.7.7.7",
                user_agent="", success=False, failure_reason="invalid_credentials",
            )

        blocked = await kit.security_service.check_auto_block("7.7.7.7")

        assert blocked is True
        assert await kit.security_service.is_ip_blocked("7.7.7.7") is True
