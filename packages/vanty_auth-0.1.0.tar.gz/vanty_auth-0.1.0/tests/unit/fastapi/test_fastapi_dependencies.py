from __future__ import annotations

from types import SimpleNamespace
from uuid import uuid4

import pytest
from starlette.requests import Request

from vanty_auth.core.auth_context import AuthContext
from vanty_auth.core.exceptions import NotAuthenticated
from vanty_auth.fastapi.dependencies import get_current_auth, require_permission

pytestmark = pytest.mark.unit


def make_request() -> Request:
    scope = {
        "type": "http",
        "headers": [],
        "client": ("127.0.0.1", 1234),
        "state": {},
        "app": SimpleNamespace(state=SimpleNamespace()),
    }
    return Request(scope)


@pytest.mark.asyncio
async def test_get_current_auth_requires_current_user_on_request_state():
    request = make_request()
    context = AuthContext(
        principal_type="user_session",
        user_id=uuid4(),
        session_id=uuid4(),
        organization_id=uuid4(),
        membership_id=uuid4(),
        role_slug="owner",
        permissions=["org:api_keys:manage"],
        api_key_id=None,
        request_id="request-id",
        ip_address=None,
        user_agent=None,
    )

    with pytest.raises(NotAuthenticated, match="Authentication required"):
        await get_current_auth(request, context)


@pytest.mark.asyncio
async def test_require_permission_requires_context():
    dependency = require_permission("org:api_keys:manage")

    with pytest.raises(NotAuthenticated, match="Authentication required"):
        await dependency(None)
