from __future__ import annotations

import pytest

from vanty_auth.core.exceptions import PermissionDenied
from vanty_auth.db.models import User

pytestmark = pytest.mark.unit


@pytest.mark.asyncio
async def test_create_api_key_requires_manage_permission(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        organization = await kit.organization_service.ensure_personal_organization(user, email="owner@example.com")

        with pytest.raises(PermissionDenied, match="Missing permission"):
            await kit.api_key_service.create_api_key(
                organization=organization,
                created_by=user,
                name="Worker",
                description=None,
                permissions=["org:members:read"],
                effective_permissions=[],
            )


@pytest.mark.asyncio
async def test_revoke_api_key_requires_manage_permission(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        organization = await kit.organization_service.ensure_personal_organization(user, email="owner@example.com")
        api_key, _ = await kit.api_key_service.create_api_key(
            organization=organization,
            created_by=user,
            name="Worker",
            description=None,
            permissions=["org:members:read"],
            effective_permissions=["org:api_keys:manage"],
        )

        with pytest.raises(PermissionDenied, match="Missing permission"):
            await kit.api_key_service.revoke_api_key(
                organization=organization,
                api_key_id=api_key.id,
                effective_permissions=[],
            )


@pytest.mark.asyncio
async def test_authenticate_api_key_rejects_wrong_secret(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        organization = await kit.organization_service.ensure_personal_organization(user, email="owner@example.com")
        _, secret = await kit.api_key_service.create_api_key(
            organization=organization,
            created_by=user,
            name="Worker",
            description=None,
            permissions=["org:members:read"],
            effective_permissions=["org:api_keys:manage"],
        )
        prefix, _ = secret.split(".", 1)

        authenticated = await kit.api_key_service.authenticate_api_key(f"{prefix}.wrong-secret")

        assert authenticated is None
