from __future__ import annotations

import pytest

from vanty_auth.core.exceptions import Conflict, NotFound, PermissionDenied
from vanty_auth.db.models import EmailAddress, Organization, OrganizationInvitation, OrganizationMembership, User

pytestmark = pytest.mark.unit


@pytest.mark.asyncio
async def test_create_organization(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        await EmailAddress.create(user=user, email="u@test.com", verified=True, primary=True, pending=False)
        await kit.organization_service.ensure_personal_organization(user, email="u@test.com")

        detail = await kit.organization_service.create_organization(user, name="Acme Corp")

        assert detail.name == "Acme Corp"
        assert detail.kind == "organization"
        assert detail.member_count == 1
        membership = await OrganizationMembership.filter(
            organization_id=detail.id, user=user, state="active"
        ).first()
        assert membership is not None
        assert membership.role_slug == "owner"


@pytest.mark.asyncio
async def test_create_organization_custom_slug(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        await EmailAddress.create(user=user, email="u@test.com", verified=True, primary=True, pending=False)

        detail = await kit.organization_service.create_organization(
            user, name="Acme Corp", slug="acme-corp"
        )

        assert detail.slug == "acme-corp"


@pytest.mark.asyncio
async def test_create_organization_restricted_slug(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        await EmailAddress.create(user=user, email="u@test.com", verified=True, primary=True, pending=False)

        with pytest.raises(Conflict, match="restricted"):
            await kit.organization_service.create_organization(
                user, name="Admin Org", slug="admin"
            )


@pytest.mark.asyncio
async def test_create_organization_duplicate_slug(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        await EmailAddress.create(user=user, email="u@test.com", verified=True, primary=True, pending=False)

        await kit.organization_service.create_organization(user, name="A", slug="my-org")

        with pytest.raises(Conflict, match="already taken"):
            await kit.organization_service.create_organization(user, name="B", slug="my-org")


@pytest.mark.asyncio
async def test_create_organization_requires_verified_email(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        await EmailAddress.create(user=user, email="u@test.com", verified=False, primary=True, pending=False)

        with pytest.raises(PermissionDenied, match="Verified email"):
            await kit.organization_service.create_organization(user, name="Acme")


@pytest.mark.asyncio
async def test_create_organization_disabled(make_kit):
    async with make_kit(allow_org_creation=False) as kit:
        user = await User.create(password_hash="hashed")
        await EmailAddress.create(user=user, email="u@test.com", verified=True, primary=True, pending=False)

        with pytest.raises(PermissionDenied, match="disabled"):
            await kit.organization_service.create_organization(user, name="Acme")


@pytest.mark.asyncio
async def test_update_organization(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        await EmailAddress.create(user=user, email="u@test.com", verified=True, primary=True, pending=False)
        detail = await kit.organization_service.create_organization(user, name="Old Name")

        updated = await kit.organization_service.update_organization(
            detail.id, name="New Name", logo_url="https://logo.png"
        )

        assert updated.name == "New Name"
        assert updated.logo_url == "https://logo.png"


@pytest.mark.asyncio
async def test_update_organization_slug_conflict(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        await EmailAddress.create(user=user, email="u@test.com", verified=True, primary=True, pending=False)
        await kit.organization_service.create_organization(user, name="A", slug="org-a")
        detail_b = await kit.organization_service.create_organization(user, name="B", slug="org-b")

        with pytest.raises(Conflict, match="already taken"):
            await kit.organization_service.update_organization(detail_b.id, slug="org-a")


@pytest.mark.asyncio
async def test_delete_organization(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        await EmailAddress.create(user=user, email="u@test.com", verified=True, primary=True, pending=False)
        detail = await kit.organization_service.create_organization(user, name="Delete Me")

        result = await kit.organization_service.delete_organization(detail.id, user)

        assert result.message == "Organization deleted"
        assert not await Organization.filter(id=detail.id).exists()


@pytest.mark.asyncio
async def test_delete_personal_org_forbidden(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        await EmailAddress.create(user=user, email="u@test.com", verified=True, primary=True, pending=False)
        personal = await kit.organization_service.ensure_personal_organization(user, email="u@test.com")

        with pytest.raises(PermissionDenied, match="personal"):
            await kit.organization_service.delete_organization(personal.id, user)


@pytest.mark.asyncio
async def test_delete_organization_non_owner_forbidden(make_kit):
    async with make_kit() as kit:
        owner = await User.create(password_hash="hashed")
        await EmailAddress.create(user=owner, email="o@test.com", verified=True, primary=True, pending=False)
        other = await User.create(password_hash="hashed")
        detail = await kit.organization_service.create_organization(owner, name="Org")

        with pytest.raises(PermissionDenied, match="owner"):
            await kit.organization_service.delete_organization(detail.id, other)


@pytest.mark.asyncio
async def test_get_organization_detail(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        await EmailAddress.create(user=user, email="u@test.com", verified=True, primary=True, pending=False)
        detail = await kit.organization_service.create_organization(user, name="Acme")

        fetched = await kit.organization_service.get_organization_detail(detail.id)

        assert fetched.id == detail.id
        assert fetched.member_count == 1


@pytest.mark.asyncio
async def test_get_organization_detail_not_found(make_kit):
    from uuid import uuid4

    async with make_kit() as kit:
        with pytest.raises(NotFound):
            await kit.organization_service.get_organization_detail(uuid4())


@pytest.mark.asyncio
async def test_leave_organization(make_kit):
    async with make_kit() as kit:
        owner = await User.create(password_hash="hashed")
        await EmailAddress.create(user=owner, email="o@test.com", verified=True, primary=True, pending=False)
        member = await User.create(password_hash="hashed")
        await EmailAddress.create(user=member, email="m@test.com", verified=True, primary=True, pending=False)
        detail = await kit.organization_service.create_organization(owner, name="Org")
        await OrganizationMembership.create(
            organization_id=detail.id, user=member,
            invited_email="m@test.com", state="active", role_slug="member",
        )

        result = await kit.organization_service.leave_organization(detail.id, member)

        assert result.message == "Left organization"
        membership = await OrganizationMembership.filter(
            organization_id=detail.id, user=member
        ).first()
        assert membership.state == "left"


@pytest.mark.asyncio
async def test_leave_personal_org_forbidden(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        await EmailAddress.create(user=user, email="u@test.com", verified=True, primary=True, pending=False)
        personal = await kit.organization_service.ensure_personal_organization(user, email="u@test.com")

        with pytest.raises(PermissionDenied, match="personal"):
            await kit.organization_service.leave_organization(personal.id, user)


@pytest.mark.asyncio
async def test_leave_as_sole_owner_forbidden(make_kit):
    async with make_kit() as kit:
        owner = await User.create(password_hash="hashed")
        await EmailAddress.create(user=owner, email="o@test.com", verified=True, primary=True, pending=False)
        detail = await kit.organization_service.create_organization(owner, name="Org")

        with pytest.raises(PermissionDenied, match="sole owner"):
            await kit.organization_service.leave_organization(detail.id, owner)


@pytest.mark.asyncio
async def test_transfer_ownership(make_kit):
    async with make_kit() as kit:
        owner = await User.create(password_hash="hashed")
        await EmailAddress.create(user=owner, email="o@test.com", verified=True, primary=True, pending=False)
        new_owner = await User.create(password_hash="hashed")
        await EmailAddress.create(user=new_owner, email="n@test.com", verified=True, primary=True, pending=False)
        detail = await kit.organization_service.create_organization(owner, name="Org")
        new_membership = await OrganizationMembership.create(
            organization_id=detail.id, user=new_owner,
            invited_email="n@test.com", state="active", role_slug="member",
        )

        result = await kit.organization_service.transfer_ownership(
            detail.id, owner, new_membership.id
        )

        assert result.message == "Ownership transferred"
        org = await Organization.get(id=detail.id)
        assert org.owner_id == new_owner.id
        old_membership = await OrganizationMembership.filter(
            organization_id=detail.id, user=owner
        ).first()
        assert old_membership.role_slug == "admin"
        refreshed_new = await OrganizationMembership.get(id=new_membership.id)
        assert refreshed_new.role_slug == "owner"


@pytest.mark.asyncio
async def test_transfer_ownership_non_owner_forbidden(make_kit):
    async with make_kit() as kit:
        from uuid import uuid4

        owner = await User.create(password_hash="hashed")
        await EmailAddress.create(user=owner, email="o@test.com", verified=True, primary=True, pending=False)
        other = await User.create(password_hash="hashed")
        detail = await kit.organization_service.create_organization(owner, name="Org")

        with pytest.raises(PermissionDenied, match="current owner"):
            await kit.organization_service.transfer_ownership(detail.id, other, uuid4())


@pytest.mark.asyncio
async def test_revoke_invitation(make_kit):
    async with make_kit() as kit:
        owner = await User.create(password_hash="hashed")
        await EmailAddress.create(user=owner, email="o@test.com", verified=True, primary=True, pending=False)
        detail = await kit.organization_service.create_organization(owner, name="Org")
        invite = await kit.organization_service.invite_member(
            organization_id=detail.id,
            invited_by=owner,
            email="invitee@test.com",
            role_slug="member",
            permissions=["org:members:manage"],
        )

        result = await kit.organization_service.revoke_invitation(
            organization_id=detail.id,
            invitation_id=invite.id,
            permissions=["org:members:manage"],
        )

        assert result.message == "Invitation revoked"
        inv = await OrganizationInvitation.get(id=invite.id)
        assert inv.revoked_at is not None


@pytest.mark.asyncio
async def test_accept_invitation(make_kit):
    async with make_kit() as kit:
        owner = await User.create(password_hash="hashed")
        await EmailAddress.create(user=owner, email="o@test.com", verified=True, primary=True, pending=False)
        invitee = await User.create(password_hash="hashed")
        await EmailAddress.create(user=invitee, email="invitee@test.com", verified=True, primary=True, pending=False)
        detail = await kit.organization_service.create_organization(owner, name="Org")
        invite = await kit.organization_service.invite_member(
            organization_id=detail.id,
            invited_by=owner,
            email="invitee@test.com",
            role_slug="member",
            permissions=["org:members:manage"],
        )

        result = await kit.organization_service.accept_invitation(invite.id, invitee)

        assert result.message == "Invitation accepted"
        membership = await OrganizationMembership.filter(
            organization_id=detail.id, user=invitee, state="active"
        ).first()
        assert membership is not None
        assert membership.role_slug == "member"


@pytest.mark.asyncio
async def test_decline_invitation(make_kit):
    async with make_kit() as kit:
        owner = await User.create(password_hash="hashed")
        await EmailAddress.create(user=owner, email="o@test.com", verified=True, primary=True, pending=False)
        invitee = await User.create(password_hash="hashed")
        await EmailAddress.create(user=invitee, email="invitee@test.com", verified=True, primary=True, pending=False)
        detail = await kit.organization_service.create_organization(owner, name="Org")
        invite = await kit.organization_service.invite_member(
            organization_id=detail.id,
            invited_by=owner,
            email="invitee@test.com",
            role_slug="member",
            permissions=["org:members:manage"],
        )

        result = await kit.organization_service.decline_invitation(invite.id, invitee)

        assert result.message == "Invitation declined"
        inv = await OrganizationInvitation.get(id=invite.id)
        assert inv.revoked_at is not None


@pytest.mark.asyncio
async def test_list_user_invitations(make_kit):
    async with make_kit() as kit:
        owner = await User.create(password_hash="hashed")
        await EmailAddress.create(user=owner, email="o@test.com", verified=True, primary=True, pending=False)
        invitee = await User.create(password_hash="hashed")
        await EmailAddress.create(user=invitee, email="invitee@test.com", verified=True, primary=True, pending=False)
        detail = await kit.organization_service.create_organization(owner, name="Org")
        await kit.organization_service.invite_member(
            organization_id=detail.id,
            invited_by=owner,
            email="invitee@test.com",
            role_slug="member",
            permissions=["org:members:manage"],
        )

        invitations = await kit.organization_service.list_user_invitations(invitee)

        assert len(invitations) == 1
        assert invitations[0].organization_name == "Org"
