from __future__ import annotations

from datetime import timedelta
from uuid import uuid4

import pytest

from vanty_auth.core.exceptions import Conflict, InvalidState, NotFound, PermissionDenied
from vanty_auth.core.security import hash_secret, new_secret, utcnow
from vanty_auth.db.models import (
    EmailAddress,
    OrganizationInvitation,
    OrganizationMembership,
    User,
)

pytestmark = pytest.mark.unit


@pytest.mark.asyncio
async def test_update_organization_not_found(make_kit):
    async with make_kit() as kit:
        with pytest.raises(NotFound):
            await kit.organization_service.update_organization(uuid4(), name="X")


@pytest.mark.asyncio
async def test_update_organization_settings(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        await EmailAddress.create(user=user, email="u@test.com", verified=True, primary=True, pending=False)
        detail = await kit.organization_service.create_organization(user, name="Org")

        updated = await kit.organization_service.update_organization(
            detail.id, settings={"feature_x": True}
        )

        assert updated.settings == {"feature_x": True}


@pytest.mark.asyncio
async def test_delete_organization_not_found(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        with pytest.raises(NotFound):
            await kit.organization_service.delete_organization(uuid4(), user)


@pytest.mark.asyncio
async def test_revoke_invitation_permission_denied(make_kit):
    async with make_kit() as kit:
        with pytest.raises(PermissionDenied):
            await kit.organization_service.revoke_invitation(
                organization_id=uuid4(),
                invitation_id=uuid4(),
                permissions=[],
            )


@pytest.mark.asyncio
async def test_revoke_invitation_not_found(make_kit):
    async with make_kit() as kit:
        with pytest.raises(NotFound):
            await kit.organization_service.revoke_invitation(
                organization_id=uuid4(),
                invitation_id=uuid4(),
                permissions=["org:members:manage"],
            )


@pytest.mark.asyncio
async def test_accept_invitation_not_found(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        with pytest.raises(NotFound):
            await kit.organization_service.accept_invitation(uuid4(), user)


@pytest.mark.asyncio
async def test_accept_invitation_expired(make_kit):
    async with make_kit() as kit:
        owner = await User.create(password_hash="hashed")
        await EmailAddress.create(user=owner, email="o@test.com", verified=True, primary=True, pending=False)
        invitee = await User.create(password_hash="hashed")
        await EmailAddress.create(user=invitee, email="i@test.com", verified=True, primary=True, pending=False)
        detail = await kit.organization_service.create_organization(owner, name="Org")
        invite = await OrganizationInvitation.create(
            organization_id=detail.id,
            invited_by=owner,
            email="i@test.com",
            role_slug="member",
            token_hash=hash_secret(new_secret(24)),
            expires_at=utcnow() - timedelta(hours=1),
        )

        with pytest.raises(InvalidState, match="expired"):
            await kit.organization_service.accept_invitation(invite.id, invitee)


@pytest.mark.asyncio
async def test_accept_invitation_wrong_email(make_kit):
    async with make_kit() as kit:
        owner = await User.create(password_hash="hashed")
        await EmailAddress.create(user=owner, email="o@test.com", verified=True, primary=True, pending=False)
        wrong_user = await User.create(password_hash="hashed")
        await EmailAddress.create(user=wrong_user, email="wrong@test.com", verified=True, primary=True, pending=False)
        detail = await kit.organization_service.create_organization(owner, name="Org")
        invite = await OrganizationInvitation.create(
            organization_id=detail.id,
            invited_by=owner,
            email="other@test.com",
            role_slug="member",
            token_hash=hash_secret(new_secret(24)),
            expires_at=utcnow() + timedelta(days=7),
        )

        with pytest.raises(PermissionDenied, match="different email"):
            await kit.organization_service.accept_invitation(invite.id, wrong_user)


@pytest.mark.asyncio
async def test_accept_invitation_already_member(make_kit):
    async with make_kit() as kit:
        owner = await User.create(password_hash="hashed")
        await EmailAddress.create(user=owner, email="o@test.com", verified=True, primary=True, pending=False)
        invitee = await User.create(password_hash="hashed")
        await EmailAddress.create(user=invitee, email="i@test.com", verified=True, primary=True, pending=False)
        detail = await kit.organization_service.create_organization(owner, name="Org")
        await OrganizationMembership.create(
            organization_id=detail.id, user=invitee,
            invited_email="i@test.com", state="active", role_slug="member",
        )
        invite = await OrganizationInvitation.create(
            organization_id=detail.id,
            invited_by=owner,
            email="i@test.com",
            role_slug="member",
            token_hash=hash_secret(new_secret(24)),
            expires_at=utcnow() + timedelta(days=7),
        )

        with pytest.raises(Conflict, match="Already a member"):
            await kit.organization_service.accept_invitation(invite.id, invitee)


@pytest.mark.asyncio
async def test_accept_invitation_creates_membership_when_no_invited_record(make_kit):
    async with make_kit() as kit:
        owner = await User.create(password_hash="hashed")
        await EmailAddress.create(user=owner, email="o@test.com", verified=True, primary=True, pending=False)
        invitee = await User.create(password_hash="hashed")
        await EmailAddress.create(user=invitee, email="new@test.com", verified=True, primary=True, pending=False)
        detail = await kit.organization_service.create_organization(owner, name="Org")
        invite = await OrganizationInvitation.create(
            organization_id=detail.id,
            invited_by=owner,
            email="new@test.com",
            role_slug="developer",
            token_hash=hash_secret(new_secret(24)),
            expires_at=utcnow() + timedelta(days=7),
        )

        result = await kit.organization_service.accept_invitation(invite.id, invitee)

        assert result.message == "Invitation accepted"
        membership = await OrganizationMembership.filter(
            organization_id=detail.id, user=invitee, state="active"
        ).first()
        assert membership is not None
        assert membership.role_slug == "developer"


@pytest.mark.asyncio
async def test_decline_invitation_not_found(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        with pytest.raises(NotFound):
            await kit.organization_service.decline_invitation(uuid4(), user)


@pytest.mark.asyncio
async def test_decline_invitation_wrong_email(make_kit):
    async with make_kit() as kit:
        owner = await User.create(password_hash="hashed")
        await EmailAddress.create(user=owner, email="o@test.com", verified=True, primary=True, pending=False)
        wrong_user = await User.create(password_hash="hashed")
        await EmailAddress.create(user=wrong_user, email="wrong@test.com", verified=True, primary=True, pending=False)
        detail = await kit.organization_service.create_organization(owner, name="Org")
        invite = await OrganizationInvitation.create(
            organization_id=detail.id,
            invited_by=owner,
            email="someone@test.com",
            role_slug="member",
            token_hash=hash_secret(new_secret(24)),
            expires_at=utcnow() + timedelta(days=7),
        )

        with pytest.raises(PermissionDenied, match="different email"):
            await kit.organization_service.decline_invitation(invite.id, wrong_user)


@pytest.mark.asyncio
async def test_list_user_invitations_no_email(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")

        invitations = await kit.organization_service.list_user_invitations(user)

        assert invitations == []


@pytest.mark.asyncio
async def test_leave_organization_not_found(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        with pytest.raises(NotFound):
            await kit.organization_service.leave_organization(uuid4(), user)


@pytest.mark.asyncio
async def test_leave_organization_not_member(make_kit):
    async with make_kit() as kit:
        owner = await User.create(password_hash="hashed")
        await EmailAddress.create(user=owner, email="o@test.com", verified=True, primary=True, pending=False)
        outsider = await User.create(password_hash="hashed")
        detail = await kit.organization_service.create_organization(owner, name="Org")

        with pytest.raises(NotFound, match="Not a member"):
            await kit.organization_service.leave_organization(detail.id, outsider)


@pytest.mark.asyncio
async def test_transfer_ownership_not_found(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        with pytest.raises(NotFound):
            await kit.organization_service.transfer_ownership(uuid4(), user, uuid4())


@pytest.mark.asyncio
async def test_transfer_ownership_personal_forbidden(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        await EmailAddress.create(user=user, email="u@test.com", verified=True, primary=True, pending=False)
        personal = await kit.organization_service.ensure_personal_organization(user, email="u@test.com")

        with pytest.raises(PermissionDenied, match="personal"):
            await kit.organization_service.transfer_ownership(personal.id, user, uuid4())


@pytest.mark.asyncio
async def test_transfer_ownership_target_not_found(make_kit):
    async with make_kit() as kit:
        owner = await User.create(password_hash="hashed")
        await EmailAddress.create(user=owner, email="o@test.com", verified=True, primary=True, pending=False)
        detail = await kit.organization_service.create_organization(owner, name="Org")

        with pytest.raises(NotFound, match="Target member"):
            await kit.organization_service.transfer_ownership(detail.id, owner, uuid4())


@pytest.mark.asyncio
async def test_validate_slug_restricted_names(make_kit):
    async with make_kit(restricted_org_names=["Forbidden Corp"]) as kit:
        user = await User.create(password_hash="hashed")
        await EmailAddress.create(user=user, email="u@test.com", verified=True, primary=True, pending=False)

        with pytest.raises(Conflict, match="restricted"):
            await kit.organization_service.create_organization(
                user, name="Test", slug="forbidden-corp"
            )


@pytest.mark.asyncio
async def test_create_organization_auto_slug(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        await EmailAddress.create(user=user, email="u@test.com", verified=True, primary=True, pending=False)

        detail = await kit.organization_service.create_organization(user, name="My Org!")

        assert detail.slug.startswith("my-org")
