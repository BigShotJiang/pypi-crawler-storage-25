from __future__ import annotations

from datetime import timedelta
from unittest.mock import AsyncMock

import pytest

from vanty_auth.core.exceptions import InvalidState, NotFound, PermissionDenied
from vanty_auth.core.security import utcnow
from vanty_auth.db.models import AuthSession, EmailAddress, Organization, OrganizationMembership, User

pytestmark = pytest.mark.unit


@pytest.mark.asyncio
async def test_ensure_personal_organization_recreates_missing_membership(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        organization = await Organization.create(
            name="Personal Workspace",
            slug="personal-workspace",
            kind="personal",
            owner=user,
        )

        resolved = await kit.organization_service.ensure_personal_organization(user, email="owner@example.com")
        membership = await OrganizationMembership.filter(organization=organization, user=user).first()

        assert kit.organization_service.settings.app_name == kit.settings.app_name
        assert resolved.id == organization.id
        assert membership is not None
        assert membership.role_slug == "owner"


@pytest.mark.asyncio
async def test_resolve_active_organization_sets_personal_org_on_session(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        await EmailAddress.create(
            user=user,
            email="owner@example.com",
            verified=True,
            primary=True,
            pending=False,
        )
        session = await AuthSession.create(
            user=user,
            session_hash="session-hash",
            transport="browser",
            expires_at=utcnow() + timedelta(days=1),
        )

        organization, membership = await kit.organization_service.resolve_active_organization(
            user=user,
            session=session,
        )

        assert organization.kind == "personal"
        assert membership.organization_id == organization.id
        assert session.active_organization_id == organization.id


@pytest.mark.asyncio
async def test_resolve_active_organization_raises_when_membership_missing(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        await EmailAddress.create(
            user=user,
            email="owner@example.com",
            verified=True,
            primary=True,
            pending=False,
        )
        kit.organization_service.membership_for_user = AsyncMock(return_value=None)

        with pytest.raises(InvalidState, match="Missing organization membership"):
            await kit.organization_service.resolve_active_organization(user=user)


@pytest.mark.asyncio
async def test_invite_member_requires_permission(make_kit):
    async with make_kit() as kit:
        owner = await User.create(password_hash="hashed")
        organization = await kit.organization_service.ensure_personal_organization(owner, email="owner@example.com")

        with pytest.raises(PermissionDenied, match="Missing permission"):
            await kit.organization_service.invite_member(
                organization_id=organization.id,
                invited_by=owner,
                email="member@example.com",
                role_slug="member",
                permissions=[],
            )


@pytest.mark.asyncio
async def test_update_member_role_handles_missing_email_and_missing_member(make_kit):
    async with make_kit() as kit:
        owner = await User.create(password_hash="hashed")
        member = await User.create(password_hash="hashed")
        organization = await kit.organization_service.ensure_personal_organization(owner, email="owner@example.com")
        membership = await OrganizationMembership.create(
            organization=organization,
            user=member,
            invited_by=owner,
            invited_email="member@example.com",
            state="active",
            role_slug="member",
        )

        updated = await kit.organization_service.update_member_role(
            organization_id=organization.id,
            membership_id=membership.id,
            role_slug="billing",
            permissions=["org:members:manage"],
        )

        assert updated.email == "member@example.com"
        assert updated.role_slug == "billing"

        with pytest.raises(PermissionDenied, match="Missing permission"):
            await kit.organization_service.update_member_role(
                organization_id=organization.id,
                membership_id=membership.id,
                role_slug="member",
                permissions=[],
            )

        with pytest.raises(NotFound, match="Member not found"):
            await kit.organization_service.update_member_role(
                organization_id=organization.id,
                membership_id=organization.id,
                role_slug="member",
                permissions=["org:members:manage"],
            )


@pytest.mark.asyncio
async def test_revoke_member_requires_permission_and_existing_membership(make_kit):
    async with make_kit() as kit:
        owner = await User.create(password_hash="hashed")
        organization = await kit.organization_service.ensure_personal_organization(owner, email="owner@example.com")

        with pytest.raises(PermissionDenied, match="Missing permission"):
            await kit.organization_service.revoke_member(
                organization_id=organization.id,
                membership_id=organization.id,
                permissions=[],
            )

        with pytest.raises(NotFound, match="Member not found"):
            await kit.organization_service.revoke_member(
                organization_id=organization.id,
                membership_id=organization.id,
                permissions=["org:members:manage"],
            )
