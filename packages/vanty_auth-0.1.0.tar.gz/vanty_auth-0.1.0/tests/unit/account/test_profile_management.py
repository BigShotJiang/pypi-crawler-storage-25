from __future__ import annotations

import pytest

from vanty_auth.core.exceptions import PermissionDenied
from vanty_auth.db.models import EmailAddress, User

pytestmark = pytest.mark.unit


@pytest.mark.asyncio
async def test_update_profile_display_name(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        await EmailAddress.create(user=user, email="u@test.com", verified=True, primary=True, pending=False)

        view = await kit.auth_service.update_profile(user, display_name="Alice")

        assert view.display_name == "Alice"
        refreshed = await User.get(id=user.id)
        assert refreshed.display_name == "Alice"


@pytest.mark.asyncio
async def test_update_profile_avatar(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        await EmailAddress.create(user=user, email="u@test.com", verified=True, primary=True, pending=False)

        view = await kit.auth_service.update_profile(user, avatar_url="https://img.png")

        assert view.avatar_url == "https://img.png"


@pytest.mark.asyncio
async def test_update_profile_preserves_existing(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed", display_name="Bob")
        await EmailAddress.create(user=user, email="u@test.com", verified=True, primary=True, pending=False)

        view = await kit.auth_service.update_profile(user, avatar_url="https://img.png")

        assert view.display_name == "Bob"
        assert view.avatar_url == "https://img.png"


@pytest.mark.asyncio
async def test_delete_account(make_kit):
    async with make_kit() as kit:

        user = await User.create(password_hash="hashed")
        await EmailAddress.create(user=user, email="u@test.com", verified=True, primary=True, pending=False)
        await kit.organization_service.ensure_personal_organization(user, email="u@test.com")

        result = await kit.auth_service.delete_account(user)

        assert result.message == "Account deactivated"
        refreshed = await User.get(id=user.id)
        assert refreshed.is_active is False


@pytest.mark.asyncio
async def test_delete_account_disabled(make_kit):
    async with make_kit(allow_account_deletion=False) as kit:
        user = await User.create(password_hash="hashed")
        await EmailAddress.create(user=user, email="u@test.com", verified=True, primary=True, pending=False)

        with pytest.raises(PermissionDenied, match="disabled"):
            await kit.auth_service.delete_account(user)


@pytest.mark.asyncio
async def test_user_view_includes_new_fields(make_kit):
    async with make_kit() as kit:
        user = await User.create(
            password_hash="hashed", display_name="Test", avatar_url="https://avatar.png"
        )
        await EmailAddress.create(user=user, email="u@test.com", verified=True, primary=True, pending=False)

        view = await kit.auth_service.user_view(user)

        assert view.display_name == "Test"
        assert view.avatar_url == "https://avatar.png"
