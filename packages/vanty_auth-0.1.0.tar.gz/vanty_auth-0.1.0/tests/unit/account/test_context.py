from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import AsyncMock, Mock

import pytest
from starlette.requests import Request

from vanty_auth.account.context import (
    AuthContextService,
    PermissionResolver,
)

pytestmark = pytest.mark.unit


def make_request(*, headers: dict[str, str] | None = None) -> Request:
    scope = {
        "type": "http",
        "headers": [
            (key.lower().encode("latin-1"), value.encode("latin-1"))
            for key, value in (headers or {}).items()
        ],
        "client": ("127.0.0.1", 1234),
        "state": {},
        "app": SimpleNamespace(state=SimpleNamespace()),
    }
    return Request(scope)


def test_permission_resolver_returns_empty_list_without_membership_or_key():
    resolver = PermissionResolver()

    assert resolver.resolve(None) == []


def test_auth_context_service_to_envelope_returns_empty_envelope_for_none():
    service = AuthContextService(
        backends=[],
        organization_service=Mock(),
        organization_resolver=Mock(),
        permission_resolver=Mock(),
    )

    envelope = service.to_envelope(None)

    assert envelope.actor_user_id is None
    assert envelope.organization_id is None


@pytest.mark.asyncio
async def test_resolve_request_context_returns_none_when_no_backend_matches():
    failing_backend = Mock()
    failing_backend.authenticate = AsyncMock(return_value=None)
    service = AuthContextService(
        backends=[failing_backend],
        organization_service=Mock(),
        organization_resolver=Mock(),
        permission_resolver=PermissionResolver(),
    )

    result = await service.resolve_request_context(make_request())
    assert result is None
