from __future__ import annotations

from datetime import timedelta
from types import SimpleNamespace

import pytest
from starlette.requests import Request

from vanty_auth.core.exceptions import InvalidState, InvalidToken
from vanty_auth.core.security import hash_secret, utcnow
from vanty_auth.db.models import AuthSession, EmailAddress, RefreshToken, User

pytestmark = pytest.mark.unit


def make_request(*, authorization: str | None = None, cookie: str | None = None) -> Request:
    headers: list[tuple[bytes, bytes]] = []
    if authorization:
        headers.append((b"authorization", authorization.encode("latin-1")))
    if cookie:
        headers.append((b"cookie", cookie.encode("latin-1")))
    scope = {
        "type": "http",
        "headers": headers,
        "client": ("127.0.0.1", 1234),
        "state": {},
        "app": SimpleNamespace(state=SimpleNamespace()),
    }
    return Request(scope)


@pytest.mark.asyncio
async def test_auth_service_outbox_is_empty_with_logging_sender(make_kit):
    async with make_kit(email_sender="log") as kit:
        assert kit.auth_service.outbox == []


@pytest.mark.asyncio
async def test_auth_service_outbox_returns_memory_sender_outbox(make_kit):
    async with make_kit() as kit:
        assert kit.auth_service.outbox == []


@pytest.mark.asyncio
async def test_primary_email_requires_existing_primary_email(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")

        with pytest.raises(InvalidState, match="User has no primary email"):
            await kit.auth_service.primary_email(user)


@pytest.mark.asyncio
async def test_refresh_rejects_inactive_session(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        await EmailAddress.create(
            user=user,
            email="refresh-user@example.com",
            verified=True,
            primary=True,
            pending=False,
        )
        session = await AuthSession.create(
            user=user,
            session_hash="session-hash",
            transport="browser",
            expires_at=utcnow() + timedelta(days=1),
        )
        session.revoked_at = utcnow()
        await session.save(update_fields=["revoked_at"])
        await RefreshToken.create(
            session=session,
            token_hash=hash_secret("refresh-token"),
            expires_at=utcnow() + timedelta(days=1),
        )

        with pytest.raises(InvalidToken, match="Session inactive"):
            await kit.auth_service.refresh(refresh_token="refresh-token")


@pytest.mark.asyncio
async def test_resolve_social_user_requires_connect_user_context(make_kit):
    async with make_kit() as kit:
        with pytest.raises(InvalidState, match="Missing connect user context"):
            await kit.auth_service.resolve_social_user(
                action="connect",
                user_id=None,
                provider="github",
                provider_user_id="123",
                email="hello@example.com",
                email_verified=True,
            )


@pytest.mark.asyncio
async def test_resolve_social_user_reuses_existing_verified_email_user(make_kit):
    async with make_kit() as kit:
        user = await User.create(password_hash="hashed")
        await EmailAddress.create(
            user=user,
            email="existing@example.com",
            verified=True,
            primary=True,
            pending=False,
        )

        resolved = await kit.auth_service.resolve_social_user(
            action="login",
            user_id=None,
            provider="github",
            provider_user_id="123",
            email="existing@example.com",
            email_verified=True,
        )

        assert resolved.id == user.id


@pytest.mark.asyncio
async def test_resolve_social_user_requires_email_for_new_account(make_kit):
    async with make_kit() as kit:
        with pytest.raises(InvalidState, match="Provider did not return an email address"):
            await kit.auth_service.resolve_social_user(
                action="login",
                user_id=None,
                provider="github",
                provider_user_id="123",
                email=None,
                email_verified=False,
            )
