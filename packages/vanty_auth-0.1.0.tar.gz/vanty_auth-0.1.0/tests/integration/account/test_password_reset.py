from __future__ import annotations

import pytest

pytestmark = pytest.mark.integration


def test_password_reset_unknown_account_returns_generic_message(make_client):
    with make_client() as client:
        response = client.post(
            "/auth/password/forgot",
            json={"email": "missing@example.com"},
        )

        assert response.status_code == 200
        assert response.json()["message"] == "If the account exists, a reset message has been sent."
        assert response.json()["debug"] is None


def test_password_reset_rejects_invalid_token(make_client):
    with make_client() as client:
        response = client.post(
            "/auth/password/reset",
            json={"token": "invalid-token", "password": "NewPassw0rd!"},
        )

        assert response.status_code == 400
        assert response.json()["detail"] == "Invalid or expired reset token"


def test_password_reset_flow_allows_new_login(make_client, signup_user, verify_email):
    with make_client() as client:
        signup_response = signup_user(client, "reset@example.com")
        verify_email(client, str(signup_response["debug"]["verification_token"]))

        forgot = client.post("/auth/password/forgot", json={"email": "reset@example.com"})
        reset = client.post(
            "/auth/password/reset",
            json={"token": forgot.json()["debug"]["reset_token"], "password": "NewPassw0rd!"},
        )
        old_login = client.post(
            "/auth/login",
            json={"email": "reset@example.com", "password": "s3cretPass!"},
        )
        new_login = client.post(
            "/auth/login",
            json={"email": "reset@example.com", "password": "NewPassw0rd!"},
        )

        assert forgot.status_code == 200
        assert reset.status_code == 200
        assert old_login.status_code == 400
        assert new_login.status_code == 200
