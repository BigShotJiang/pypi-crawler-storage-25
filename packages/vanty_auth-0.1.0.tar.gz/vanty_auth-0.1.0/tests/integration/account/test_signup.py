from __future__ import annotations

import pytest

pytestmark = pytest.mark.integration


def test_signup_verify_login_and_personal_organization(make_client, signup_and_login, auth_headers):
    with make_client() as client:
        payload = signup_and_login(client, "hello@example.com")
        me = client.get("/auth/me", headers=auth_headers(payload))

        assert me.status_code == 200
        body = me.json()
        assert body["email_verified"] is True
        assert len(body["organizations"]) == 1
        assert body["organizations"][0]["kind"] == "personal"


def test_signup_rejects_duplicate_email(make_client, signup_user):
    with make_client() as client:
        signup_user(client, "duplicate@example.com")
        duplicate = client.post(
            "/auth/signup",
            json={"email": "duplicate@example.com", "password": "s3cretPass!"},
        )

        assert duplicate.status_code == 400
        assert duplicate.json()["detail"] == "Unable to create account"


def test_verify_email_rejects_invalid_token(make_client):
    with make_client() as client:
        response = client.post("/auth/email/verify", json={"token": "not-a-real-token"})

        assert response.status_code == 400
        assert response.json()["detail"] == "Invalid or expired verification token"
