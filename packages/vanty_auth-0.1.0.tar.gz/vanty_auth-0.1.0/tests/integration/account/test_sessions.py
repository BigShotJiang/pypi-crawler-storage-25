from __future__ import annotations

from uuid import uuid4

import pytest

pytestmark = pytest.mark.integration


def test_list_sessions_marks_current_when_multiple_exist(make_client, signup_and_login, auth_headers):
    with make_client() as client:
        first = signup_and_login(client, "sessions@example.com")
        second = client.post(
            "/auth/login",
            json={"email": "sessions@example.com", "password": "s3cretPass!"},
        ).json()
        response = client.get("/auth/sessions", headers=auth_headers(second))

        assert response.status_code == 200
        sessions = response.json()["sessions"]
        assert len(sessions) == 2
        assert any(session["id"] == first["session"]["id"] for session in sessions)
        assert any(session["id"] == second["session"]["id"] and session["current"] for session in sessions)


def test_revoke_unknown_session_returns_404(make_client, signup_and_login, auth_headers):
    with make_client() as client:
        payload = signup_and_login(client, "missing-session@example.com")
        response = client.delete(
            f"/auth/sessions/{uuid4()}",
            headers=auth_headers(payload),
        )

        assert response.status_code == 404
        assert response.json()["detail"] == "Session not found"


def test_revoke_other_sessions_invalidates_older_access_token(make_client, signup_and_login, auth_headers):
    with make_client() as client:
        first = signup_and_login(client, "multi-session@example.com")
        second = client.post(
            "/auth/login",
            json={"email": "multi-session@example.com", "password": "s3cretPass!"},
        ).json()

        revoke = client.post("/auth/sessions/revoke-others", headers=auth_headers(second))
        client.cookies.clear()
        first_me = client.get("/auth/me", headers=auth_headers(first))
        second_me = client.get("/auth/me", headers=auth_headers(second))

        assert revoke.status_code == 200
        assert first_me.status_code == 401
        assert second_me.status_code == 200


def test_revoke_current_session_clears_cookie_auth(make_client, signup_and_login, auth_headers):
    with make_client() as client:
        payload = signup_and_login(client, "current-session@example.com")
        revoke = client.delete(
            f"/auth/sessions/{payload['session']['id']}",
            headers=auth_headers(payload),
        )
        me = client.get("/auth/me")

        assert revoke.status_code == 200
        assert me.status_code == 401


def test_logout_revokes_session_for_cookie_and_bearer_auth(make_client, signup_and_login, auth_headers):
    with make_client() as client:
        payload = signup_and_login(client, "logout@example.com")
        logout = client.post("/auth/logout", headers=auth_headers(payload))
        bearer_me = client.get("/auth/me", headers=auth_headers(payload))
        cookie_me = client.get("/auth/me")

        assert logout.status_code == 200
        assert logout.json()["message"] == "Logged out"
        assert bearer_me.status_code == 401
        assert cookie_me.status_code == 401


def test_revoke_all_sessions_invalidates_all_access(make_client, signup_and_login, auth_headers):
    with make_client() as client:
        first = signup_and_login(client, "all-sessions@example.com")
        second = client.post(
            "/auth/login",
            json={"email": "all-sessions@example.com", "password": "s3cretPass!"},
        ).json()

        revoke = client.post("/auth/sessions/revoke-all", headers=auth_headers(second))
        first_me = client.get("/auth/me", headers=auth_headers(first))
        second_me = client.get("/auth/me", headers=auth_headers(second))
        cookie_me = client.get("/auth/me")

        assert revoke.status_code == 200
        assert first_me.status_code == 401
        assert second_me.status_code == 401
        assert cookie_me.status_code == 401
