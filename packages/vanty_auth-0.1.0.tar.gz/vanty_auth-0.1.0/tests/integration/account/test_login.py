from __future__ import annotations

import pytest

pytestmark = pytest.mark.integration


def test_login_requires_verified_email(make_client, signup_user):
    with make_client() as client:
        signup_user(client, "pending@example.com")
        response = client.post(
            "/auth/login",
            json={"email": "pending@example.com", "password": "s3cretPass!"},
        )

        assert response.status_code == 403
        assert response.json()["detail"] == "Email verification required"


def test_login_rejects_invalid_credentials(make_client, signup_user, verify_email):
    with make_client() as client:
        signup_response = signup_user(client, "wrong-password@example.com")
        verify_email(client, str(signup_response["debug"]["verification_token"]))
        response = client.post(
            "/auth/login",
            json={"email": "wrong-password@example.com", "password": "wrong-pass"},
        )

        assert response.status_code == 400
        assert response.json()["detail"] == "Invalid credentials"


def test_login_sets_session_cookie_and_cookie_auth_works(make_client, signup_and_login):
    with make_client() as client:
        payload = signup_and_login(client, "cookie@example.com")
        me = client.get("/auth/me")

        assert payload["session"]["id"]
        assert client.cookies.get("auth_session")
        assert me.status_code == 200
        assert me.json()["email"] == "cookie@example.com"


def test_refresh_rotates_refresh_tokens(make_client, signup_and_login):
    with make_client() as client:
        payload = signup_and_login(client, "refresh@example.com")
        refresh_response = client.post(
            "/auth/token/refresh",
            json={"refresh_token": payload["refresh_token"]},
        )
        reused_response = client.post(
            "/auth/token/refresh",
            json={"refresh_token": payload["refresh_token"]},
        )

        assert refresh_response.status_code == 200
        assert refresh_response.json()["refresh_token"] != payload["refresh_token"]
        assert reused_response.status_code == 400
        assert reused_response.json()["detail"] == "Invalid refresh token"


def test_login_rate_limit_blocks_repeated_failures(make_client, signup_user, verify_email):
    with make_client(login_rate_limit_attempts=1) as client:
        signup_response = signup_user(client, "limited@example.com")
        verify_email(client, str(signup_response["debug"]["verification_token"]))

        first = client.post(
            "/auth/login",
            json={"email": "limited@example.com", "password": "wrong-pass"},
        )
        second = client.post(
            "/auth/login",
            json={"email": "limited@example.com", "password": "wrong-pass"},
        )

        assert first.status_code == 400
        assert second.status_code == 429
        assert second.json()["detail"] == "Too many requests"
