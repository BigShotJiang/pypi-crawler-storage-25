from __future__ import annotations

import pytest

pytestmark = pytest.mark.integration


def test_change_password_updates_credentials(make_client, signup_and_login, auth_headers):
    with make_client() as client:
        payload = signup_and_login(client, "change-password@example.com")
        change = client.post(
            "/auth/password/change",
            headers=auth_headers(payload),
            json={"current_password": "s3cretPass!", "new_password": "NewPassw0rd!"},
        )
        old_login = client.post(
            "/auth/login",
            json={"email": "change-password@example.com", "password": "s3cretPass!"},
        )
        new_login = client.post(
            "/auth/login",
            json={"email": "change-password@example.com", "password": "NewPassw0rd!"},
        )

        assert change.status_code == 200
        assert old_login.status_code == 400
        assert new_login.status_code == 200


def test_change_password_requires_correct_current_password(make_client, signup_and_login, auth_headers):
    with make_client() as client:
        payload = signup_and_login(client, "wrong-current@example.com")
        response = client.post(
            "/auth/password/change",
            headers=auth_headers(payload),
            json={"current_password": "incorrect", "new_password": "NewPassw0rd!"},
        )

        assert response.status_code == 400
        assert response.json()["detail"] == "Current password is incorrect"
