from __future__ import annotations

import pytest

pytestmark = pytest.mark.integration


def test_change_email_requires_unique_address(make_client, signup_and_login, auth_headers):
    with make_client() as client:
        owner = signup_and_login(client, "owner@example.com")
        signup_and_login(client, "taken@example.com")

        response = client.post(
            "/auth/email/change",
            headers=auth_headers(owner),
            json={"new_email": "taken@example.com"},
        )

        assert response.status_code == 400
        assert response.json()["detail"] == "Email is already in use"


def test_change_email_swaps_primary_email_after_verification(make_client, signup_and_login, auth_headers):
    with make_client() as client:
        payload = signup_and_login(client, "old@example.com")
        change = client.post(
            "/auth/email/change",
            headers=auth_headers(payload),
            json={"new_email": "new@example.com"},
        )
        verification_token = change.json()["debug"]["verification_token"]
        verify = client.post("/auth/email/verify", json={"token": verification_token})
        old_login = client.post(
            "/auth/login",
            json={"email": "old@example.com", "password": "s3cretPass!"},
        )
        new_login = client.post(
            "/auth/login",
            json={"email": "new@example.com", "password": "s3cretPass!"},
        )

        assert change.status_code == 200
        assert verify.status_code == 200
        assert old_login.status_code == 400
        assert new_login.status_code == 200
