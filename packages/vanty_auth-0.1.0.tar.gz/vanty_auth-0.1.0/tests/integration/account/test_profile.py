from __future__ import annotations

import pytest

pytestmark = pytest.mark.integration


def test_update_profile(make_client, signup_and_login, auth_headers):
    with make_client() as client:
        creds = signup_and_login(client, "u@test.com")
        headers = auth_headers(creds)

        response = client.patch(
            "/auth/me",
            json={"display_name": "Alice", "avatar_url": "https://img.png"},
            headers=headers,
        )

        assert response.status_code == 200
        data = response.json()
        assert data["display_name"] == "Alice"
        assert data["avatar_url"] == "https://img.png"


def test_update_profile_partial(make_client, signup_and_login, auth_headers):
    with make_client() as client:
        creds = signup_and_login(client, "u@test.com")
        headers = auth_headers(creds)

        response = client.patch(
            "/auth/me",
            json={"display_name": "Bob"},
            headers=headers,
        )

        assert response.status_code == 200
        assert response.json()["display_name"] == "Bob"


def test_delete_account(make_client, signup_and_login, auth_headers):
    with make_client() as client:
        creds = signup_and_login(client, "u@test.com")
        headers = auth_headers(creds)

        response = client.delete("/auth/me", headers=headers)

        assert response.status_code == 200
        assert response.json()["message"] == "Account deactivated"


def test_me_shows_new_fields(make_client, signup_and_login, auth_headers):
    with make_client() as client:
        creds = signup_and_login(client, "u@test.com")
        headers = auth_headers(creds)
        client.patch(
            "/auth/me",
            json={"display_name": "Zara"},
            headers=headers,
        )

        response = client.get("/auth/me", headers=headers)

        assert response.status_code == 200
        assert response.json()["display_name"] == "Zara"
