from __future__ import annotations

import sqlite3
from pathlib import Path

import pytest

pytestmark = pytest.mark.integration


def test_login_records_attempt(make_client, signup_and_login):
    with make_client() as client:
        signup_and_login(client, "u@test.com")

        db_path = Path(client.db_path)
        with sqlite3.connect(db_path) as conn:
            rows = conn.execute("SELECT * FROM auth_login_attempt").fetchall()
            assert len(rows) >= 1


def test_blocked_ip_prevents_login(make_client, signup_user, verify_email):
    with make_client() as client:
        resp = signup_user(client, "u@test.com")
        token = resp["debug"]["verification_token"]
        verify_email(client, token)

        db_path = Path(client.db_path)
        with sqlite3.connect(db_path) as conn:
            from uuid import uuid4
            conn.execute(
                "INSERT INTO auth_blocked_ip (id, ip_address, reason, blocked_at) "
                "VALUES (?, ?, ?, CURRENT_TIMESTAMP)",
                (str(uuid4()), "testclient", "Test block"),
            )
            conn.commit()

        response = client.post(
            "/auth/login", json={"email": "u@test.com", "password": "s3cretPass!"}
        )

        assert response.status_code == 400


def test_delete_account_leaves_org_memberships(make_client, signup_and_login, auth_headers):
    with make_client() as client:
        creds = signup_and_login(client, "u@test.com")
        headers = auth_headers(creds)
        client.post(
            "/auth/organizations", json={"name": "Team Org"}, headers=headers,
        )

        response = client.delete("/auth/me", headers=headers)

        assert response.status_code == 200

        db_path = Path(client.db_path)
        with sqlite3.connect(db_path) as conn:
            rows = conn.execute(
                "SELECT state FROM organizationmembership WHERE organization_id IN "
                "(SELECT id FROM organization WHERE kind='organization')"
            ).fetchall()
            for row in rows:
                assert row[0] == "left"


def test_login_attempt_filter_by_ip(make_client, signup_and_login):
    with make_client() as client:
        signup_and_login(client, "u@test.com")

        db_path = Path(client.db_path)
        with sqlite3.connect(db_path) as conn:
            rows = conn.execute(
                "SELECT ip_address FROM auth_login_attempt"
            ).fetchall()
            assert len(rows) >= 1
