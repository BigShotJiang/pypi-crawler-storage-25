from __future__ import annotations

import pytest

pytestmark = pytest.mark.integration


def test_enabled_providers_empty(make_client):
    with make_client() as client:
        response = client.get("/auth/providers")

        assert response.status_code == 200
        assert response.json()["providers"] == []


def test_enabled_providers_with_db_provider(make_client, insert_provider_app):
    with make_client() as client:
        insert_provider_app(client, provider="github")

        response = client.get("/auth/providers")

        assert response.status_code == 200
        assert "github" in response.json()["providers"]
