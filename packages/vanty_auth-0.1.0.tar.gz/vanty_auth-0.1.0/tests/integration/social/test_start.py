from __future__ import annotations

from urllib.parse import parse_qs, urlparse

import pytest

from vanty_auth.settings import ProviderAppSettings

pytestmark = pytest.mark.integration


def github_provider_apps() -> dict[str, ProviderAppSettings]:
    return {
        "github": ProviderAppSettings(
            client_id="client-id",
            client_secret="client-secret",
            authorize_url="https://example.com/auth",
            token_url="https://example.com/token",
            userinfo_url="https://example.com/user",
            email_url="https://example.com/email",
            scopes=["read:user", "user:email"],
        )
    }


def test_social_start_uses_configured_provider_settings(make_client):
    with make_client(provider_apps=github_provider_apps()) as client:
        response = client.get("/auth/social/github/start", params={"redirect_uri": "http://localhost/callback"})

        assert response.status_code == 200
        authorization_url = response.json()["authorization_url"]
        query = parse_qs(urlparse(authorization_url).query)
        assert authorization_url.startswith("https://example.com/auth?")
        assert query["client_id"] == ["client-id"]
        assert query["redirect_uri"] == ["http://localhost/callback"]
        assert query["state"]


def test_social_start_rejects_unconfigured_registered_provider(make_client):
    with make_client() as client:
        response = client.get("/auth/social/github/start", params={"redirect_uri": "http://localhost/callback"})

        assert response.status_code == 404
        assert response.json()["detail"] == "Provider 'github' is not configured"


def test_social_start_rejects_unknown_provider(make_client):
    with make_client(provider_apps=github_provider_apps()) as client:
        response = client.get("/auth/social/not-real/start", params={"redirect_uri": "http://localhost/callback"})

        assert response.status_code == 404
        assert response.json()["detail"] == "Provider 'not-real' is not registered"
