from __future__ import annotations

import sqlite3

import pytest

from vanty_auth.settings import ProviderAppSettings

pytestmark = [pytest.mark.integration, pytest.mark.network]


def github_provider_apps() -> dict[str, ProviderAppSettings]:
    return {
        "github": ProviderAppSettings(
            client_id="client-id",
            client_secret="client-secret",
            authorize_url="https://example.com/auth",
            token_url="https://example.com/token",
            userinfo_url="https://example.com/user",
            email_url="https://example.com/email",
            scopes=["read:user", "user:email"],
        )
    }


def test_social_callback_logs_in_user_and_persists_tokens(make_client, extract_state, httpx_boundary):
    with make_client(provider_apps=github_provider_apps()) as client:
        start = client.get("/auth/social/github/start", params={"redirect_uri": "http://localhost/callback"})
        state = extract_state(start.json()["authorization_url"])
        httpx_boundary.add_json(
            "POST",
            "https://example.com/token",
            {"access_token": "access-1", "refresh_token": "refresh-1", "expires_in": 3600},
        )
        httpx_boundary.add_json(
            "GET",
            "https://example.com/user",
            {"id": 42, "login": "octocat", "avatar_url": "https://example.com/avatar.png"},
        )
        httpx_boundary.add_json(
            "GET",
            "https://example.com/email",
            [{"email": "octocat@example.com", "primary": True, "verified": True}],
        )

        callback = client.get(
            "/auth/social/github/callback",
            params={"state": state, "code": "oauth-code"},
        )
        me = client.get("/auth/me")

        assert callback.status_code == 200
        assert callback.json()["access_token"]
        assert me.status_code == 200
        assert me.json()["email"] == "octocat@example.com"
        with sqlite3.connect(client.db_path) as connection:
            token_row = connection.execute(
                "SELECT access_token, refresh_token FROM socialtoken"
            ).fetchone()
        assert token_row == ("access-1", "refresh-1")


def test_social_callback_updates_existing_token_record(make_client, extract_state, httpx_boundary):
    with make_client(provider_apps=github_provider_apps()) as client:
        first_start = client.get("/auth/social/github/start", params={"redirect_uri": "http://localhost/callback"})
        first_state = extract_state(first_start.json()["authorization_url"])
        httpx_boundary.add_json(
            "POST",
            "https://example.com/token",
            {"access_token": "access-1", "refresh_token": "refresh-1", "expires_in": 3600},
        )
        httpx_boundary.add_json(
            "GET",
            "https://example.com/user",
            {"id": 42, "login": "octocat", "avatar_url": "https://example.com/avatar-one.png"},
        )
        httpx_boundary.add_json(
            "GET",
            "https://example.com/email",
            [{"email": "octocat@example.com", "primary": True, "verified": True}],
        )
        first_callback = client.get(
            "/auth/social/github/callback",
            params={"state": first_state, "code": "first-code"},
        )

        second_start = client.get("/auth/social/github/start", params={"redirect_uri": "http://localhost/callback"})
        second_state = extract_state(second_start.json()["authorization_url"])
        httpx_boundary.add_json(
            "POST",
            "https://example.com/token",
            {"access_token": "access-2", "refresh_token": "refresh-2", "expires_in": 7200},
        )
        httpx_boundary.add_json(
            "GET",
            "https://example.com/user",
            {"id": 42, "login": "octocat", "avatar_url": "https://example.com/avatar-two.png"},
        )
        httpx_boundary.add_json(
            "GET",
            "https://example.com/email",
            [{"email": "octocat@example.com", "primary": True, "verified": True}],
        )
        second_callback = client.get(
            "/auth/social/github/callback",
            params={"state": second_state, "code": "second-code"},
        )

        with sqlite3.connect(client.db_path) as connection:
            token_rows = connection.execute(
                "SELECT access_token, refresh_token FROM socialtoken"
            ).fetchall()
            account_rows = connection.execute(
                "SELECT email, extra_data FROM socialaccount"
            ).fetchall()

        assert first_callback.status_code == 200
        assert second_callback.status_code == 200
        assert token_rows == [("access-2", "refresh-2")]
        assert len(account_rows) == 1
        assert "avatar-two" in account_rows[0][1]


def test_social_callback_rejects_invalid_state(make_client, httpx_boundary):
    del httpx_boundary
    with make_client(provider_apps=github_provider_apps()) as client:
        response = client.get(
            "/auth/social/github/callback",
            params={"state": "missing-state", "code": "oauth-code"},
        )

        assert response.status_code == 400
        assert response.json()["detail"] == "Invalid social login state"
