from __future__ import annotations

import sqlite3

import pytest

from vanty_auth.settings import ProviderAppSettings

pytestmark = [pytest.mark.integration, pytest.mark.network]


def github_provider_apps() -> dict[str, ProviderAppSettings]:
    return {
        "github": ProviderAppSettings(
            client_id="client-id",
            client_secret="client-secret",
            authorize_url="https://example.com/auth",
            token_url="https://example.com/token",
            userinfo_url="https://example.com/user",
            email_url="https://example.com/email",
            scopes=["read:user", "user:email"],
        )
    }


def complete_social_login(
    client,
    extract_state,
    httpx_boundary,
    *,
    provider_user_id: int,
    email: str,
) -> dict[str, object]:
    start = client.get("/auth/social/github/start", params={"redirect_uri": "http://localhost/callback"})
    state = extract_state(start.json()["authorization_url"])
    httpx_boundary.add_json(
        "POST",
        "https://example.com/token",
        {
            "access_token": f"access-{provider_user_id}",
            "refresh_token": f"refresh-{provider_user_id}",
            "expires_in": 3600,
        },
    )
    httpx_boundary.add_json(
        "GET",
        "https://example.com/user",
        {"id": provider_user_id, "login": f"user-{provider_user_id}", "avatar_url": "https://example.com/avatar.png"},
    )
    httpx_boundary.add_json(
        "GET",
        "https://example.com/email",
        [{"email": email, "primary": True, "verified": True}],
    )
    response = client.get(
        "/auth/social/github/callback",
        params={"state": state, "code": f"code-{provider_user_id}"},
    )
    assert response.status_code == 200
    return response.json()


def test_disconnect_social_account_requires_existing_account(make_client, signup_and_login, auth_headers):
    with make_client(provider_apps=github_provider_apps()) as client:
        payload = signup_and_login(client, "disconnect-missing@example.com")
        response = client.delete("/auth/social/github/disconnect", headers=auth_headers(payload))

        assert response.status_code == 404
        assert response.json()["detail"] == "Social account not found"


def test_disconnect_social_account_succeeds_for_user_with_password(
    make_client,
    signup_and_login,
    auth_headers,
    extract_state,
    httpx_boundary,
):
    with make_client(provider_apps=github_provider_apps()) as client:
        payload = signup_and_login(client, "disconnect@example.com")
        start = client.get(
            "/auth/social/github/connect",
            headers=auth_headers(payload),
            params={"redirect_uri": "http://localhost/callback"},
        )
        state = extract_state(start.json()["authorization_url"])
        httpx_boundary.add_json(
            "POST",
            "https://example.com/token",
            {"access_token": "access-disconnect", "refresh_token": "refresh-disconnect", "expires_in": 3600},
        )
        httpx_boundary.add_json(
            "GET",
            "https://example.com/user",
            {"id": 123, "login": "disconnect", "avatar_url": "https://example.com/avatar.png"},
        )
        httpx_boundary.add_json(
            "GET",
            "https://example.com/email",
            [{"email": "disconnect@example.com", "primary": True, "verified": True}],
        )
        client.get("/auth/social/github/callback", params={"state": state, "code": "disconnect-code"})

        response = client.delete("/auth/social/github/disconnect", headers=auth_headers(payload))

        with sqlite3.connect(client.db_path) as connection:
            social_count = connection.execute("SELECT COUNT(*) FROM socialaccount").fetchone()[0]

        assert response.status_code == 200
        assert response.json()["message"] == "github disconnected"
        assert social_count == 0


def test_disconnect_last_login_method_is_blocked(make_client, auth_headers, extract_state, httpx_boundary):
    with make_client(provider_apps=github_provider_apps()) as client:
        payload = complete_social_login(
            client,
            extract_state,
            httpx_boundary,
            provider_user_id=777,
            email="social-only@example.com",
        )
        response = client.delete("/auth/social/github/disconnect", headers=auth_headers(payload))

        assert response.status_code == 400
        assert response.json()["detail"] == "Cannot disconnect the last login method"
