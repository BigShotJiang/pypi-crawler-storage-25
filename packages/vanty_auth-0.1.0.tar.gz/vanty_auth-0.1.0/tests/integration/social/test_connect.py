from __future__ import annotations

import sqlite3

import pytest

from vanty_auth.settings import ProviderAppSettings

pytestmark = [pytest.mark.integration, pytest.mark.network]


def github_provider_apps() -> dict[str, ProviderAppSettings]:
    return {
        "github": ProviderAppSettings(
            client_id="client-id",
            client_secret="client-secret",
            authorize_url="https://example.com/auth",
            token_url="https://example.com/token",
            userinfo_url="https://example.com/user",
            email_url="https://example.com/email",
            scopes=["read:user", "user:email"],
        )
    }


def test_social_connect_links_account_to_existing_user(
    make_client,
    signup_and_login,
    auth_headers,
    extract_state,
    httpx_boundary,
):
    with make_client(provider_apps=github_provider_apps()) as client:
        payload = signup_and_login(client, "connect@example.com")
        start = client.get(
            "/auth/social/github/connect",
            headers=auth_headers(payload),
            params={"redirect_uri": "http://localhost/callback"},
        )
        state = extract_state(start.json()["authorization_url"])
        httpx_boundary.add_json(
            "POST",
            "https://example.com/token",
            {"access_token": "access-connect", "refresh_token": "refresh-connect", "expires_in": 3600},
        )
        httpx_boundary.add_json(
            "GET",
            "https://example.com/user",
            {"id": 99, "login": "connector", "avatar_url": "https://example.com/avatar.png"},
        )
        httpx_boundary.add_json(
            "GET",
            "https://example.com/email",
            [{"email": "connect@example.com", "primary": True, "verified": True}],
        )

        callback = client.get(
            "/auth/social/github/callback",
            params={"state": state, "code": "oauth-code"},
        )

        with sqlite3.connect(client.db_path) as connection:
            social_rows = connection.execute(
                "SELECT provider, provider_user_id, email FROM socialaccount"
            ).fetchall()

        assert callback.status_code == 200
        assert callback.json()["message"] == "github account connected"
        assert social_rows == [("github", "99", "connect@example.com")]
