from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

pytestmark = pytest.mark.integration


def test_reference_app_pages(load_reference_app):
    app = load_reference_app()

    with TestClient(app) as client:
        home = client.get("/")
        docs = client.get("/docs")
        health = client.get("/health")

    assert home.status_code == 200
    assert home.json()["docs_url"] == "/docs"
    assert docs.status_code == 200
    assert "Scalar" in docs.text
    assert health.status_code == 200
    assert health.json() == {"status": "ok"}
