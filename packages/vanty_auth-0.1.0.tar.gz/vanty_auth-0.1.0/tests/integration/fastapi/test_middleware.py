from __future__ import annotations

import pytest
from fastapi import FastAPI, Request
from fastapi.testclient import TestClient

from vanty_auth.fastapi.middleware import AuthContextMiddleware

pytestmark = pytest.mark.integration


def test_auth_context_middleware_handles_app_without_auth_kit():
    app = FastAPI()
    app.add_middleware(AuthContextMiddleware)

    @app.get("/state")
    async def state(request: Request):
        return {"auth_context": request.state.auth_context}

    with TestClient(app) as client:
        response = client.get("/state")

    assert response.status_code == 200
    assert response.json() == {"auth_context": None}
