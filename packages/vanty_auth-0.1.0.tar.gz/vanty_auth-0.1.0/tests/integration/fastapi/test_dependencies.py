from __future__ import annotations

import pytest

from vanty_auth.settings import ProviderAppSettings

pytestmark = pytest.mark.integration


def github_provider_apps() -> dict[str, ProviderAppSettings]:
    return {
        "github": ProviderAppSettings(
            client_id="client-id",
            client_secret="client-secret",
        )
    }


def test_context_returns_null_when_unauthenticated(make_client):
    with make_client() as client:
        response = client.get("/auth/context")

        assert response.status_code == 200
        assert response.json() is None


def test_me_requires_authentication(make_client):
    with make_client() as client:
        response = client.get("/auth/me")

        assert response.status_code == 401
        assert response.json()["detail"] == "Authentication required"


def test_api_keys_route_requires_active_organization(make_client):
    with make_client() as client:
        response = client.get("/auth/api-keys")

        assert response.status_code == 401
        assert response.json()["detail"] == "Authentication required"


def test_social_connect_requires_authentication(make_client):
    with make_client(provider_apps=github_provider_apps()) as client:
        response = client.get("/auth/social/github/connect", params={"redirect_uri": "http://localhost/callback"})

        assert response.status_code == 401
        assert response.json()["detail"] == "Authentication required"


def test_invalid_access_token_is_treated_as_no_context(make_client):
    with make_client() as client:
        response = client.get("/auth/context", headers={"Authorization": "Bearer invalid-token"})

        assert response.status_code == 200
        assert response.json() is None
