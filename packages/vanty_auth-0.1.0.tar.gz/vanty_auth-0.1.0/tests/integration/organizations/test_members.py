from __future__ import annotations

import pytest

pytestmark = pytest.mark.integration


def test_update_member_role_and_revoke_member(
    make_client,
    signup_and_login,
    auth_headers,
    insert_team_organization,
):
    with make_client() as client:
        payload = signup_and_login(client, "manage-members@example.com")
        me = client.get("/auth/me", headers=auth_headers(payload)).json()
        organization_id, _ = insert_team_organization(
            client,
            user_id=me["id"],
            email=me["email"],
            role_slug="admin",
        )
        client.post(
            "/auth/organizations/switch",
            headers=auth_headers(payload),
            json={"organization_id": organization_id},
        )
        invite = client.post(
            f"/auth/organizations/{organization_id}/invites",
            headers=auth_headers(payload),
            json={"email": "member@example.com", "role_slug": "member"},
        )
        invitation_id = invite.json()["debug"]["invitation_id"]
        members = client.get(
            f"/auth/organizations/{organization_id}/members",
            headers=auth_headers(payload),
        ).json()["members"]
        invited_member = next(member for member in members if member["email"] == "member@example.com")

        update = client.patch(
            f"/auth/organizations/{organization_id}/members/{invited_member['id']}",
            headers=auth_headers(payload),
            json={"role_slug": "billing"},
        )
        updated_members = client.get(
            f"/auth/organizations/{organization_id}/members",
            headers=auth_headers(payload),
        ).json()["members"]
        revoke = client.delete(
            f"/auth/organizations/{organization_id}/members/{invited_member['id']}",
            headers=auth_headers(payload),
        )
        revoked_members = client.get(
            f"/auth/organizations/{organization_id}/members",
            headers=auth_headers(payload),
        ).json()["members"]
        updated_member = next(member for member in updated_members if member["id"] == invited_member["id"])
        revoked_member = next(member for member in revoked_members if member["id"] == invited_member["id"])

        assert invitation_id
        assert update.status_code == 200
        assert updated_member["role_slug"] == "billing"
        assert revoke.status_code == 200
        assert revoked_member["state"] == "revoked"


def test_member_without_manage_permission_gets_forbidden(
    make_client,
    signup_and_login,
    auth_headers,
    insert_team_organization,
    insert_membership,
):
    with make_client() as client:
        owner = signup_and_login(client, "owner-two@example.com")
        member_payload = signup_and_login(client, "plain-member@example.com")
        owner_me = client.get("/auth/me", headers=auth_headers(owner)).json()
        member_me = client.get("/auth/me", headers=auth_headers(member_payload)).json()
        organization_id, _ = insert_team_organization(
            client,
            user_id=owner_me["id"],
            email=owner_me["email"],
            role_slug="admin",
        )
        insert_membership(
            client,
            organization_id=organization_id,
            user_id=member_me["id"],
            invited_by_id=owner_me["id"],
            invited_email=member_me["email"],
            role_slug="member",
        )
        client.post(
            "/auth/organizations/switch",
            headers=auth_headers(member_payload),
            json={"organization_id": organization_id},
        )

        members = client.get(
            f"/auth/organizations/{organization_id}/members",
            headers=auth_headers(member_payload),
        )
        invite = client.post(
            f"/auth/organizations/{organization_id}/invites",
            headers=auth_headers(member_payload),
            json={"email": "blocked@example.com", "role_slug": "member"},
        )

        assert members.status_code == 403
        assert members.json()["detail"] == "Missing permission"
        assert invite.status_code == 403
        assert invite.json()["detail"] == "Missing permission"
