from __future__ import annotations

import pytest

pytestmark = pytest.mark.integration


def test_switch_organization_updates_current_context(
    make_client,
    signup_and_login,
    auth_headers,
    insert_team_organization,
):
    with make_client() as client:
        payload = signup_and_login(client, "owner@example.com")
        me = client.get("/auth/me", headers=auth_headers(payload)).json()
        organization_id, _ = insert_team_organization(
            client,
            user_id=me["id"],
            email=me["email"],
            role_slug="admin",
        )

        response = client.post(
            "/auth/organizations/switch",
            headers=auth_headers(payload),
            json={"organization_id": organization_id},
        )
        context = client.get("/auth/context", headers=auth_headers(payload))

        assert response.status_code == 200
        assert context.status_code == 200
        assert context.json()["organization_id"] == organization_id


def test_list_organizations_includes_current_org(make_client, signup_and_login, auth_headers):
    with make_client() as client:
        payload = signup_and_login(client, "org-list@example.com")
        response = client.get("/auth/organizations", headers=auth_headers(payload))

        assert response.status_code == 200
        assert len(response.json()["organizations"]) == 1
        assert response.json()["organizations"][0]["current"] is True


def test_switch_organization_rejects_missing_membership(make_client, signup_and_login, auth_headers):
    with make_client() as client:
        payload = signup_and_login(client, "missing-org@example.com")
        response = client.post(
            "/auth/organizations/switch",
            headers=auth_headers(payload),
            json={"organization_id": "00000000-0000-0000-0000-000000000999"},
        )

        assert response.status_code == 404
        assert response.json()["detail"] == "Organization not found"
