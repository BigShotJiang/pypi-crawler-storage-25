from __future__ import annotations

import pytest

pytestmark = pytest.mark.integration


def test_list_invitations_returns_created_invite(
    make_client,
    signup_and_login,
    auth_headers,
    insert_team_organization,
):
    with make_client() as client:
        payload = signup_and_login(client, "org-owner@example.com")
        me = client.get("/auth/me", headers=auth_headers(payload)).json()
        organization_id, _ = insert_team_organization(
            client,
            user_id=me["id"],
            email=me["email"],
            role_slug="admin",
        )
        client.post(
            "/auth/organizations/switch",
            headers=auth_headers(payload),
            json={"organization_id": organization_id},
        )

        invite = client.post(
            f"/auth/organizations/{organization_id}/invites",
            headers=auth_headers(payload),
            json={"email": "invitee@example.com", "role_slug": "member"},
        )
        invitations = client.get(
            f"/auth/organizations/{organization_id}/invites",
            headers=auth_headers(payload),
        )

        assert invite.status_code == 200
        assert invitations.status_code == 200
        assert len(invitations.json()["invitations"]) == 1
        assert invitations.json()["invitations"][0]["email"] == "invitee@example.com"


def test_invitation_routes_reject_active_organization_mismatch(
    make_client,
    signup_and_login,
    auth_headers,
    insert_team_organization,
):
    with make_client() as client:
        payload = signup_and_login(client, "mismatch-owner@example.com")
        me = client.get("/auth/me", headers=auth_headers(payload)).json()
        organization_id, _ = insert_team_organization(
            client,
            user_id=me["id"],
            email=me["email"],
            role_slug="admin",
        )

        invite = client.post(
            f"/auth/organizations/{organization_id}/invites",
            headers=auth_headers(payload),
            json={"email": "invitee@example.com", "role_slug": "member"},
        )
        invitations = client.get(
            f"/auth/organizations/{organization_id}/invites",
            headers=auth_headers(payload),
        )

        assert invite.status_code == 403
        assert invite.json()["detail"] == "Active organization mismatch"
        assert invitations.status_code == 403
        assert invitations.json()["detail"] == "Active organization mismatch"
