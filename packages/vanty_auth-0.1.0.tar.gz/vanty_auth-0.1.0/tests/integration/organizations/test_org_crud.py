from __future__ import annotations

import pytest

pytestmark = pytest.mark.integration


def test_create_organization(make_client, signup_and_login, auth_headers):
    with make_client() as client:
        creds = signup_and_login(client, "owner@test.com")
        headers = auth_headers(creds)

        response = client.post(
            "/auth/organizations",
            json={"name": "Acme Corp", "slug": "acme-corp"},
            headers=headers,
        )

        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "Acme Corp"
        assert data["slug"] == "acme-corp"
        assert data["kind"] == "organization"
        assert data["member_count"] == 1


def test_create_organization_restricted_slug(make_client, signup_and_login, auth_headers):
    with make_client() as client:
        creds = signup_and_login(client, "owner@test.com")
        headers = auth_headers(creds)

        response = client.post(
            "/auth/organizations",
            json={"name": "Admin Org", "slug": "admin"},
            headers=headers,
        )

        assert response.status_code == 409


def test_get_organization_detail(make_client, signup_and_login, auth_headers):
    with make_client() as client:
        creds = signup_and_login(client, "owner@test.com")
        headers = auth_headers(creds)
        create_resp = client.post(
            "/auth/organizations",
            json={"name": "Acme"},
            headers=headers,
        )
        org_id = create_resp.json()["id"]

        response = client.get(f"/auth/organizations/{org_id}", headers=headers)

        assert response.status_code == 200
        assert response.json()["name"] == "Acme"


def test_update_organization(make_client, signup_and_login, auth_headers):
    with make_client() as client:
        creds = signup_and_login(client, "owner@test.com")
        headers = auth_headers(creds)
        create_resp = client.post(
            "/auth/organizations",
            json={"name": "Old Name"},
            headers=headers,
        )
        org_id = create_resp.json()["id"]
        client.post(
            "/auth/organizations/switch",
            json={"organization_id": org_id},
            headers=headers,
        )

        response = client.patch(
            f"/auth/organizations/{org_id}",
            json={"name": "New Name"},
            headers=headers,
        )

        assert response.status_code == 200
        assert response.json()["name"] == "New Name"


def test_delete_organization(make_client, signup_and_login, auth_headers):
    with make_client() as client:
        creds = signup_and_login(client, "owner@test.com")
        headers = auth_headers(creds)
        create_resp = client.post(
            "/auth/organizations",
            json={"name": "Delete Me"},
            headers=headers,
        )
        org_id = create_resp.json()["id"]

        response = client.delete(f"/auth/organizations/{org_id}", headers=headers)

        assert response.status_code == 200
        assert response.json()["message"] == "Organization deleted"


def test_leave_organization(make_client, signup_and_login, auth_headers):
    with make_client() as client:
        owner_creds = signup_and_login(client, "owner@test.com")
        member_creds = signup_and_login(client, "member@test.com")
        owner_headers = auth_headers(owner_creds)
        member_headers = auth_headers(member_creds)
        create_resp = client.post(
            "/auth/organizations",
            json={"name": "Team Org"},
            headers=owner_headers,
        )
        org_id = create_resp.json()["id"]
        client.post(
            "/auth/organizations/switch",
            json={"organization_id": org_id},
            headers=owner_headers,
        )
        client.post(
            f"/auth/organizations/{org_id}/invites",
            json={"email": "member@test.com", "role_slug": "member"},
            headers=owner_headers,
        )
        invites_resp = client.get("/auth/invitations", headers=member_headers)
        invite_id = invites_resp.json()["invitations"][0]["id"]
        client.post(f"/auth/invitations/{invite_id}/accept", headers=member_headers)

        response = client.post(f"/auth/organizations/{org_id}/leave", headers=member_headers)

        assert response.status_code == 200
        assert response.json()["message"] == "Left organization"
