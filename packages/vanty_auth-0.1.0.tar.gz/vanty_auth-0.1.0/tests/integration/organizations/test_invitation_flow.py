from __future__ import annotations

import pytest

pytestmark = pytest.mark.integration


def test_invitation_accept_decline_flow(make_client, signup_and_login, auth_headers):
    with make_client() as client:
        owner_creds = signup_and_login(client, "owner@test.com")
        invitee_creds = signup_and_login(client, "invitee@test.com")
        owner_headers = auth_headers(owner_creds)
        invitee_headers = auth_headers(invitee_creds)

        create_resp = client.post(
            "/auth/organizations", json={"name": "Team"}, headers=owner_headers,
        )
        org_id = create_resp.json()["id"]
        client.post(
            "/auth/organizations/switch",
            json={"organization_id": org_id},
            headers=owner_headers,
        )

        client.post(
            f"/auth/organizations/{org_id}/invites",
            json={"email": "invitee@test.com", "role_slug": "member"},
            headers=owner_headers,
        )

        my_invites = client.get("/auth/invitations", headers=invitee_headers)
        assert my_invites.status_code == 200
        invitations = my_invites.json()["invitations"]
        assert len(invitations) == 1
        invite_id = invitations[0]["id"]

        accept_resp = client.post(
            f"/auth/invitations/{invite_id}/accept", headers=invitee_headers,
        )
        assert accept_resp.status_code == 200
        assert accept_resp.json()["message"] == "Invitation accepted"


def test_invitation_decline(make_client, signup_and_login, auth_headers):
    with make_client() as client:
        owner_creds = signup_and_login(client, "owner@test.com")
        invitee_creds = signup_and_login(client, "invitee@test.com")
        owner_headers = auth_headers(owner_creds)
        invitee_headers = auth_headers(invitee_creds)

        create_resp = client.post(
            "/auth/organizations", json={"name": "Team"}, headers=owner_headers,
        )
        org_id = create_resp.json()["id"]
        client.post(
            "/auth/organizations/switch",
            json={"organization_id": org_id},
            headers=owner_headers,
        )
        client.post(
            f"/auth/organizations/{org_id}/invites",
            json={"email": "invitee@test.com", "role_slug": "member"},
            headers=owner_headers,
        )

        my_invites = client.get("/auth/invitations", headers=invitee_headers)
        invite_id = my_invites.json()["invitations"][0]["id"]

        decline_resp = client.post(
            f"/auth/invitations/{invite_id}/decline", headers=invitee_headers,
        )
        assert decline_resp.status_code == 200
        assert decline_resp.json()["message"] == "Invitation declined"


def test_invitation_revoke(make_client, signup_and_login, auth_headers):
    with make_client() as client:
        owner_creds = signup_and_login(client, "owner@test.com")
        owner_headers = auth_headers(owner_creds)

        create_resp = client.post(
            "/auth/organizations", json={"name": "Team"}, headers=owner_headers,
        )
        org_id = create_resp.json()["id"]
        client.post(
            "/auth/organizations/switch",
            json={"organization_id": org_id},
            headers=owner_headers,
        )
        client.post(
            f"/auth/organizations/{org_id}/invites",
            json={"email": "someone@test.com", "role_slug": "member"},
            headers=owner_headers,
        )

        invites = client.get(
            f"/auth/organizations/{org_id}/invites", headers=owner_headers,
        )
        invite_id = invites.json()["invitations"][0]["id"]

        revoke_resp = client.delete(
            f"/auth/organizations/{org_id}/invites/{invite_id}", headers=owner_headers,
        )
        assert revoke_resp.status_code == 200
        assert revoke_resp.json()["message"] == "Invitation revoked"


def test_transfer_ownership_via_api(make_client, signup_and_login, auth_headers):
    with make_client() as client:
        owner_creds = signup_and_login(client, "owner@test.com")
        member_creds = signup_and_login(client, "member@test.com")
        owner_headers = auth_headers(owner_creds)
        member_headers = auth_headers(member_creds)

        create_resp = client.post(
            "/auth/organizations", json={"name": "Transfer Org"}, headers=owner_headers,
        )
        org_id = create_resp.json()["id"]
        client.post(
            "/auth/organizations/switch",
            json={"organization_id": org_id},
            headers=owner_headers,
        )
        client.post(
            f"/auth/organizations/{org_id}/invites",
            json={"email": "member@test.com", "role_slug": "admin"},
            headers=owner_headers,
        )
        my_invites = client.get("/auth/invitations", headers=member_headers)
        invite_id = my_invites.json()["invitations"][0]["id"]
        client.post(f"/auth/invitations/{invite_id}/accept", headers=member_headers)

        members = client.get(
            f"/auth/organizations/{org_id}/members", headers=owner_headers,
        )
        member_membership_id = None
        for m in members.json()["members"]:
            if m["email"] == "member@test.com":
                member_membership_id = m["id"]
                break
        assert member_membership_id is not None

        transfer_resp = client.post(
            f"/auth/organizations/{org_id}/transfer-ownership",
            json={"new_owner_membership_id": member_membership_id},
            headers=owner_headers,
        )
        assert transfer_resp.status_code == 200
        assert transfer_resp.json()["message"] == "Ownership transferred"
