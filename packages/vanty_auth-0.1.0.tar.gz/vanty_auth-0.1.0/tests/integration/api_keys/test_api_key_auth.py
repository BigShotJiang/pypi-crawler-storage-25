from __future__ import annotations

import pytest

pytestmark = pytest.mark.integration


def test_api_key_auth_works_via_header_and_bearer_prefix(make_client, signup_and_login, auth_headers):
    with make_client() as client:
        payload = signup_and_login(client, "api-key-auth@example.com")
        created = client.post(
            "/auth/api-keys",
            headers=auth_headers(payload),
            json={
                "name": "Worker",
                "description": "background",
                "permissions": ["org:api_keys:manage", "org:members:read"],
            },
        )
        secret = created.json()["secret"]
        client.cookies.clear()

        via_header = client.get("/auth/context", headers={"X-Api-Key": secret})
        via_bearer = client.get("/auth/context", headers={"Authorization": f"Bearer {secret}"})

        assert via_header.status_code == 200
        assert via_header.json()["principal_type"] == "api_key"
        assert via_bearer.status_code == 200
        assert via_bearer.json()["api_key_id"] == via_header.json()["api_key_id"]


def test_invalid_or_revoked_api_keys_do_not_authenticate(make_client, signup_and_login, auth_headers):
    with make_client() as client:
        payload = signup_and_login(client, "api-key-invalid@example.com")
        created = client.post(
            "/auth/api-keys",
            headers=auth_headers(payload),
            json={
                "name": "Worker",
                "description": "background",
                "permissions": ["org:api_keys:manage"],
            },
        )
        api_key_id = created.json()["api_key"]["id"]
        secret = created.json()["secret"]
        client.cookies.clear()

        bad_format = client.get("/auth/context", headers={"X-Api-Key": "not-a-secret"})
        client.delete(f"/auth/api-keys/{api_key_id}", headers=auth_headers(payload))
        revoked = client.get("/auth/context", headers={"X-Api-Key": secret})

        assert bad_format.status_code == 200
        assert bad_format.json() is None
        assert revoked.status_code == 200
        assert revoked.json() is None


def test_api_key_permission_guard_blocks_missing_permission(make_client, signup_and_login, auth_headers):
    with make_client() as client:
        payload = signup_and_login(client, "api-key-perms@example.com")
        created = client.post(
            "/auth/api-keys",
            headers=auth_headers(payload),
            json={
                "name": "Limited",
                "description": "limited key",
                "permissions": ["org:members:read"],
            },
        )
        secret = created.json()["secret"]
        client.cookies.clear()
        response = client.get("/auth/api-keys", headers={"X-Api-Key": secret})

        assert response.status_code == 403
        assert response.json()["detail"] == "Missing permission"
