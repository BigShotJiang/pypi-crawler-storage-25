from __future__ import annotations

from uuid import uuid4

import pytest

pytestmark = pytest.mark.integration


def test_create_list_and_revoke_api_keys(make_client, signup_and_login, auth_headers):
    with make_client() as client:
        payload = signup_and_login(client, "keys@example.com")

        empty = client.get("/auth/api-keys", headers=auth_headers(payload))
        created = client.post(
            "/auth/api-keys",
            headers=auth_headers(payload),
            json={
                "name": "Background worker",
                "description": "worker key",
                "permissions": ["org:api_keys:manage", "org:members:read"],
            },
        )
        listed = client.get("/auth/api-keys", headers=auth_headers(payload))
        api_key_id = created.json()["api_key"]["id"]
        revoked = client.delete(f"/auth/api-keys/{api_key_id}", headers=auth_headers(payload))
        listed_after = client.get("/auth/api-keys", headers=auth_headers(payload))

        assert empty.status_code == 200
        assert empty.json()["api_keys"] == []
        assert created.status_code == 200
        assert len(listed.json()["api_keys"]) == 1
        assert revoked.status_code == 200
        assert listed_after.json()["api_keys"][0]["revoked_at"] is not None


def test_revoke_unknown_api_key_returns_404(make_client, signup_and_login, auth_headers):
    with make_client() as client:
        payload = signup_and_login(client, "missing-key@example.com")
        response = client.delete(f"/auth/api-keys/{uuid4()}", headers=auth_headers(payload))

        assert response.status_code == 404
        assert response.json()["detail"] == "API key not found"
