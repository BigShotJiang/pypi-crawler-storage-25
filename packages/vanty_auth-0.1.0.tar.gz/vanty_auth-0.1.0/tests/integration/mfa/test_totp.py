from __future__ import annotations

import pytest

pytestmark = pytest.mark.integration


def test_confirm_totp_requires_enrollment(make_client, signup_and_login, auth_headers):
    with make_client() as client:
        payload = signup_and_login(client, "mfa-no-enroll@example.com")
        response = client.post(
            "/auth/mfa/totp/confirm",
            headers=auth_headers(payload),
            json={"code": "123456"},
        )

        assert response.status_code == 400
        assert response.json()["detail"] == "No TOTP enrollment in progress"


def test_totp_enrollment_and_verification_with_code(make_client, signup_and_login, auth_headers, totp_now):
    with make_client() as client:
        payload = signup_and_login(client, "mfa-code@example.com")
        enroll = client.post("/auth/mfa/totp/enroll", headers=auth_headers(payload))
        secret = enroll.json()["secret"]
        confirm = client.post(
            "/auth/mfa/totp/confirm",
            headers=auth_headers(payload),
            json={"code": totp_now(secret)},
        )
        mfa_login = client.post(
            "/auth/login",
            json={"email": "mfa-code@example.com", "password": "s3cretPass!"},
        )
        verify = client.post(
            "/auth/mfa/totp/verify",
            json={"mfa_token": mfa_login.json()["mfa_token"], "code": totp_now(secret)},
        )

        assert enroll.status_code == 200
        assert confirm.status_code == 200
        assert mfa_login.status_code == 200
        assert mfa_login.json()["mfa_required"] is True
        assert verify.status_code == 200
        assert verify.json()["access_token"]


def test_confirm_totp_rejects_incorrect_code(make_client, signup_and_login, auth_headers):
    with make_client() as client:
        payload = signup_and_login(client, "mfa-bad-code@example.com")
        client.post("/auth/mfa/totp/enroll", headers=auth_headers(payload))
        response = client.post(
            "/auth/mfa/totp/confirm",
            headers=auth_headers(payload),
            json={"code": "000000"},
        )

        assert response.status_code == 400
        assert response.json()["detail"] == "Invalid authenticator code"


def test_verify_totp_rejects_invalid_token(make_client):
    with make_client() as client:
        response = client.post(
            "/auth/mfa/totp/verify",
            json={"mfa_token": "invalid-token", "code": "123456"},
        )

        assert response.status_code == 400
        assert response.json()["detail"] == "Invalid MFA token"
