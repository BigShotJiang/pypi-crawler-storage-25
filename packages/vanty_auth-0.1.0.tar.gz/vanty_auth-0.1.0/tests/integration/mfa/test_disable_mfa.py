from __future__ import annotations

import pytest

pytestmark = pytest.mark.integration


def enable_totp(client, payload, auth_headers, totp_now) -> None:
    enroll = client.post("/auth/mfa/totp/enroll", headers=auth_headers(payload))
    secret = enroll.json()["secret"]
    confirm = client.post(
        "/auth/mfa/totp/confirm",
        headers=auth_headers(payload),
        json={"code": totp_now(secret)},
    )
    assert confirm.status_code == 200


def test_disable_mfa_requires_correct_password(make_client, signup_and_login, auth_headers, totp_now):
    with make_client() as client:
        payload = signup_and_login(client, "mfa-disable-wrong@example.com")
        enable_totp(client, payload, auth_headers, totp_now)
        response = client.post(
            "/auth/mfa/disable",
            headers=auth_headers(payload),
            json={"password": "wrong-pass"},
        )

        assert response.status_code == 400
        assert response.json()["detail"] == "Password is incorrect"


def test_disable_mfa_removes_mfa_requirement(make_client, signup_and_login, auth_headers, totp_now):
    with make_client() as client:
        payload = signup_and_login(client, "mfa-disable@example.com")
        enable_totp(client, payload, auth_headers, totp_now)
        disable = client.post(
            "/auth/mfa/disable",
            headers=auth_headers(payload),
            json={"password": "s3cretPass!"},
        )
        login = client.post(
            "/auth/login",
            json={"email": "mfa-disable@example.com", "password": "s3cretPass!"},
        )

        assert disable.status_code == 200
        assert login.status_code == 200
        assert "access_token" in login.json()
        assert "mfa_required" not in login.json()
