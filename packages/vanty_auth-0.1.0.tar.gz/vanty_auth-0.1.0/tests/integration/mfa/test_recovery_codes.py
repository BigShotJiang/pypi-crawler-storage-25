from __future__ import annotations

import pytest

pytestmark = pytest.mark.integration


def enable_totp(client, payload, auth_headers, totp_now) -> list[str]:
    enroll = client.post("/auth/mfa/totp/enroll", headers=auth_headers(payload))
    secret = enroll.json()["secret"]
    confirm = client.post(
        "/auth/mfa/totp/confirm",
        headers=auth_headers(payload),
        json={"code": totp_now(secret)},
    )
    assert confirm.status_code == 200
    return list(confirm.json()["recovery_codes"])


def test_recovery_code_status_requires_enabled_mfa(make_client, signup_and_login, auth_headers):
    with make_client() as client:
        payload = signup_and_login(client, "mfa-status@example.com")
        response = client.get("/auth/mfa/recovery-codes", headers=auth_headers(payload))

        assert response.status_code == 400
        assert response.json()["detail"] == "MFA is not enabled"


def test_recovery_codes_can_be_used_once(make_client, signup_and_login, auth_headers, totp_now):
    with make_client() as client:
        payload = signup_and_login(client, "mfa-recovery@example.com")
        recovery_codes = enable_totp(client, payload, auth_headers, totp_now)
        status_before = client.get("/auth/mfa/recovery-codes", headers=auth_headers(payload))
        login = client.post(
            "/auth/login",
            json={"email": "mfa-recovery@example.com", "password": "s3cretPass!"},
        )
        first_verify = client.post(
            "/auth/mfa/totp/verify",
            json={"mfa_token": login.json()["mfa_token"], "recovery_code": recovery_codes[0]},
        )
        second_login = client.post(
            "/auth/login",
            json={"email": "mfa-recovery@example.com", "password": "s3cretPass!"},
        )
        second_verify = client.post(
            "/auth/mfa/totp/verify",
            json={"mfa_token": second_login.json()["mfa_token"], "recovery_code": recovery_codes[0]},
        )
        status_after = client.get("/auth/mfa/recovery-codes", headers=auth_headers(payload))

        assert status_before.status_code == 200
        assert status_before.json()["debug"] == {"total": 10, "remaining": 10}
        assert first_verify.status_code == 200
        assert second_verify.status_code == 400
        assert second_verify.json()["detail"] == "Invalid MFA verification"
        assert status_after.json()["debug"] == {"total": 10, "remaining": 9}


def test_regenerate_recovery_codes_replaces_previous_set(make_client, signup_and_login, auth_headers, totp_now):
    with make_client() as client:
        payload = signup_and_login(client, "mfa-regenerate@example.com")
        original_codes = enable_totp(client, payload, auth_headers, totp_now)
        regenerate = client.post("/auth/mfa/recovery-codes", headers=auth_headers(payload))
        login = client.post(
            "/auth/login",
            json={"email": "mfa-regenerate@example.com", "password": "s3cretPass!"},
        )
        old_code_attempt = client.post(
            "/auth/mfa/totp/verify",
            json={"mfa_token": login.json()["mfa_token"], "recovery_code": original_codes[0]},
        )
        fresh_codes = regenerate.json()["recovery_codes"]

        assert regenerate.status_code == 200
        assert len(fresh_codes) == 10
        assert old_code_attempt.status_code == 400
        assert old_code_attempt.json()["detail"] == "Invalid MFA verification"
