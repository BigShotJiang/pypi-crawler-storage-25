from __future__ import annotations

from contextlib import asynccontextmanager, contextmanager
from pathlib import Path
from uuid import uuid4

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from vanty_auth import AuthKitSettings, mount_auth_router

pytestmark = pytest.mark.integration

DEFAULT_SECRET_KEY = "test-secret-key-for-jwt-and-encryption"


@contextmanager
def build_admin_test_client(db_path: Path, **setting_overrides):
    settings = AuthKitSettings(
        **{
            "database_url": f"sqlite://{db_path}",
            "secret_key": DEFAULT_SECRET_KEY,
            "debug_expose_secrets": True,
            "email_sender": "memory",
            **setting_overrides,
        }
    )
    app = FastAPI()
    kit = mount_auth_router(app, settings=settings)
    app.include_router(kit.admin_router, prefix="/admin/auth")

    @asynccontextmanager
    async def lifespan(_: FastAPI):
        await kit.init_orm(generate_schemas=True)
        try:
            yield
        finally:
            await kit.close_orm()

    app.router.lifespan_context = lifespan
    with TestClient(app) as client:
        client.db_path = db_path
        client.auth_kit = kit
        yield client


@pytest.fixture
def admin_client(tmp_path):
    db_path = tmp_path / f"{uuid4().hex}.db"
    with build_admin_test_client(db_path) as client:
        yield client


def _signup_login(client, email, password="s3cretPass!"):
    resp = client.post("/auth/signup", json={"email": email, "password": password})
    assert resp.status_code == 200
    token = resp.json()["debug"]["verification_token"]
    client.post("/auth/email/verify", json={"token": token})
    resp = client.post("/auth/login", json={"email": email, "password": password})
    assert resp.status_code == 200
    return resp.json()


def test_admin_list_organizations(admin_client):
    creds = _signup_login(admin_client, "admin@test.com")
    headers = {"Authorization": f"Bearer {creds['access_token']}"}
    admin_client.post(
        "/auth/organizations", json={"name": "Test Org"}, headers=headers,
    )

    response = admin_client.get("/admin/auth/organizations", headers=headers)

    assert response.status_code == 200
    data = response.json()
    assert data["total"] >= 1
    assert len(data["organizations"]) >= 1


def test_admin_get_organization(admin_client):
    creds = _signup_login(admin_client, "admin@test.com")
    headers = {"Authorization": f"Bearer {creds['access_token']}"}
    create_resp = admin_client.post(
        "/auth/organizations", json={"name": "Detail Org"}, headers=headers,
    )
    org_id = create_resp.json()["id"]

    response = admin_client.get(f"/admin/auth/organizations/{org_id}", headers=headers)

    assert response.status_code == 200
    assert response.json()["organization"]["name"] == "Detail Org"


def test_admin_update_organization(admin_client):
    creds = _signup_login(admin_client, "admin@test.com")
    headers = {"Authorization": f"Bearer {creds['access_token']}"}
    create_resp = admin_client.post(
        "/auth/organizations", json={"name": "Org"}, headers=headers,
    )
    org_id = create_resp.json()["id"]

    response = admin_client.patch(
        f"/admin/auth/organizations/{org_id}",
        json={"is_active": False},
        headers=headers,
    )

    assert response.status_code == 200
    assert response.json()["is_active"] is False


def test_admin_list_users(admin_client):
    creds = _signup_login(admin_client, "admin@test.com")
    headers = {"Authorization": f"Bearer {creds['access_token']}"}

    response = admin_client.get("/admin/auth/users", headers=headers)

    assert response.status_code == 200
    assert response.json()["total"] >= 1


def test_admin_get_user(admin_client):
    creds = _signup_login(admin_client, "admin@test.com")
    headers = {"Authorization": f"Bearer {creds['access_token']}"}
    user_id = creds["user"]["id"]

    response = admin_client.get(f"/admin/auth/users/{user_id}", headers=headers)

    assert response.status_code == 200
    assert response.json()["user"]["email"] == "admin@test.com"


def test_admin_update_user(admin_client):
    creds = _signup_login(admin_client, "admin@test.com")
    headers = {"Authorization": f"Bearer {creds['access_token']}"}
    user_id = creds["user"]["id"]

    response = admin_client.patch(
        f"/admin/auth/users/{user_id}",
        json={"is_superuser": True},
        headers=headers,
    )

    assert response.status_code == 200
    assert response.json()["is_superuser"] is True


def test_admin_platform_stats(admin_client):
    creds = _signup_login(admin_client, "admin@test.com")
    headers = {"Authorization": f"Bearer {creds['access_token']}"}

    response = admin_client.get("/admin/auth/stats", headers=headers)

    assert response.status_code == 200
    data = response.json()
    assert "total_users" in data
    assert "active_sessions" in data


def test_admin_security_overview(admin_client):
    creds = _signup_login(admin_client, "admin@test.com")
    headers = {"Authorization": f"Bearer {creds['access_token']}"}

    response = admin_client.get("/admin/auth/security/overview", headers=headers)

    assert response.status_code == 200
    data = response.json()
    assert "total_users" in data
    assert "enabled_providers" in data


def test_admin_provider_crud(admin_client):
    creds = _signup_login(admin_client, "admin@test.com")
    headers = {"Authorization": f"Bearer {creds['access_token']}"}

    create_resp = admin_client.post(
        "/admin/auth/providers",
        json={
            "provider": "github",
            "client_id": "cid",
            "client_secret": "csecret",
            "authorize_url": "https://auth.example.com",
            "token_url": "https://token.example.com",
            "userinfo_url": "https://userinfo.example.com",
        },
        headers=headers,
    )
    assert create_resp.status_code == 200
    provider_id = create_resp.json()["id"]

    list_resp = admin_client.get("/admin/auth/providers", headers=headers)
    assert list_resp.status_code == 200
    assert len(list_resp.json()["providers"]) == 1

    get_resp = admin_client.get(f"/admin/auth/providers/{provider_id}", headers=headers)
    assert get_resp.status_code == 200
    assert get_resp.json()["provider"] == "github"

    delete_resp = admin_client.delete(f"/admin/auth/providers/{provider_id}", headers=headers)
    assert delete_resp.status_code == 200
    assert delete_resp.json()["message"] == "Provider deleted"


def test_admin_block_unblock_ip(admin_client):
    creds = _signup_login(admin_client, "admin@test.com")
    headers = {"Authorization": f"Bearer {creds['access_token']}"}

    block_resp = admin_client.post(
        "/admin/auth/security/block-ip",
        json={"ip_address": "10.0.0.1", "reason": "Test block"},
        headers=headers,
    )
    assert block_resp.status_code == 200
    assert block_resp.json()["ip_address"] == "10.0.0.1"

    list_resp = admin_client.get("/admin/auth/security/blocked-ips", headers=headers)
    assert list_resp.status_code == 200
    assert len(list_resp.json()["blocked_ips"]) == 1

    unblock_resp = admin_client.post(
        "/admin/auth/security/unblock-ip",
        json={"ip_address": "10.0.0.1"},
        headers=headers,
    )
    assert unblock_resp.status_code == 200

    list_resp2 = admin_client.get("/admin/auth/security/blocked-ips", headers=headers)
    assert len(list_resp2.json()["blocked_ips"]) == 0


def test_admin_login_attempts(admin_client):
    creds = _signup_login(admin_client, "admin@test.com")
    headers = {"Authorization": f"Bearer {creds['access_token']}"}

    response = admin_client.get("/admin/auth/security/login-attempts", headers=headers)

    assert response.status_code == 200
    assert response.json()["total"] >= 1
