from __future__ import annotations

from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from scalar_fastapi import DocumentDownloadType, Layout, Theme, get_scalar_api_reference

from vanty_auth import AuthKitSettings, mount_auth_router

LOCAL_DATA_DIR = Path(__file__).resolve().parents[2] / ".local"
LOCAL_DATA_DIR.mkdir(exist_ok=True)

settings = AuthKitSettings(
    database_url=f"sqlite://{LOCAL_DATA_DIR / 'reference-api.db'}",
    debug_expose_secrets=True,
    email_sender="memory",
)
app = FastAPI(
    title="Vanty Auth Reference API",
    summary="Reference API for the vanty-auth package",
    description="Organization-aware auth API with sessions, MFA, API keys, and user management.",
    docs_url=None,
    redoc_url=None,
)
kit = mount_auth_router(app, settings=settings)


@asynccontextmanager
async def lifespan(app: FastAPI):
    await kit.init_orm(generate_schemas=True)
    try:
        yield
    finally:
        await kit.close_orm()


app.router.lifespan_context = lifespan

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://127.0.0.1:5173",
        "http://localhost:5173",
        "http://127.0.0.1:5174",
        "http://localhost:5174",
        "http://127.0.0.1:4174",
        "http://localhost:4174",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
async def root():
    return {
        "name": "vanty-auth reference api",
        "docs_url": "/docs",
        "health_url": "/health",
        "frontend_dev_url": "http://127.0.0.1:5173",
    }


@app.get("/docs", include_in_schema=False)
async def scalar_docs():
    return get_scalar_api_reference(
        title="Vanty Auth Reference",
        openapi_url=app.openapi_url,
        theme=Theme.DEEP_SPACE,
        layout=Layout.MODERN,
        hide_models=False,
        dark_mode=True,
        hide_dark_mode_toggle=True,
        document_download_type=DocumentDownloadType.BOTH,
        custom_css="""
        body { background: radial-gradient(circle at top, #1b2b3a 0%, #07111a 58%, #03070b 100%); }
        .light-mode { --scalar-background-1: #07111a; --scalar-background-2: #0f1d29; }
        .sidebar { border-right: 1px solid rgba(255,255,255,0.08); }
        """,
    )


@app.get("/health")
async def health():
    return {"status": "ok"}
