import { create } from "zustand"
import { createJSONStorage, persist } from "zustand/middleware"

import { createAuthActionsSlice } from "~/store/slices/auth-actions-slice"
import { createSessionSlice } from "~/store/slices/session-slice"
import { createViewerSlice } from "~/store/slices/viewer-slice"
import type { AppStore, PersistedSessionState } from "~/store/types"
export {
  selectCurrentOrganization,
  selectCurrentUser,
  selectHasHydrated,
  selectIsAuthenticated,
} from "~/store/types"

const AUTH_STORAGE_KEY = "vanty-auth-demo"

export const useAppStore = create<AppStore>()(
  persist(
    (...args) => ({
      ...createSessionSlice(...args),
      ...createViewerSlice(...args),
      ...createAuthActionsSlice(...args),
    }),
    {
      name: AUTH_STORAGE_KEY,
      storage: createJSONStorage(() => localStorage),
      partialize: (state): PersistedSessionState => ({
        accessToken: state.accessToken,
        refreshToken: state.refreshToken,
        status: state.status,
      }),
      onRehydrateStorage: () => (state) => {
        state?.setHydrated(true)
      },
    },
  ),
)
