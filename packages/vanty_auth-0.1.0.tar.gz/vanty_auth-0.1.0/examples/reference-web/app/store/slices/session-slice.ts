import type { StateCreator } from "zustand"

import type { AppStore, SessionSlice } from "~/store/types"

export const createSessionSlice: StateCreator<AppStore, [], [], SessionSlice> = (
  set,
) => ({
  hasHydrated: false,
  accessToken: null,
  refreshToken: null,
  status: "anonymous",
  setHydrated: (hasHydrated) => set({ hasHydrated }),
  setTokens: ({ accessToken, refreshToken }) =>
    set({
      accessToken,
      refreshToken,
      status: "authenticated",
    }),
  clearTokens: () =>
    set({
      accessToken: null,
      refreshToken: null,
      status: "anonymous",
    }),
})
