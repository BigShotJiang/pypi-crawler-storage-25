import type { StateCreator } from "zustand"

import type { AppStore, ViewerSlice } from "~/store/types"
import { getDefaultOrganizationId } from "~/store/types"

export const createViewerSlice: StateCreator<AppStore, [], [], ViewerSlice> = (
  set,
) => ({
  user: null,
  activeOrganizationId: null,
  setUser: (user) =>
    set({
      user,
      activeOrganizationId: getDefaultOrganizationId(user),
    }),
  setActiveOrganizationId: (activeOrganizationId) => set({ activeOrganizationId }),
  clearUser: () =>
    set({
      user: null,
      activeOrganizationId: null,
    }),
})
