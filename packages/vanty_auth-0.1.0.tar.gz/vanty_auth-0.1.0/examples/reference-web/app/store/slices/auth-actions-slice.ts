import type { StateCreator } from "zustand"

import type { AppStore, AuthActionsSlice } from "~/store/types"
import { getDefaultOrganizationId } from "~/store/types"

export const createAuthActionsSlice: StateCreator<
  AppStore,
  [],
  [],
  AuthActionsSlice
> = (set) => ({
  applyAuthResponse: ({ access_token, refresh_token, user }) =>
    set({
      accessToken: access_token,
      refreshToken: refresh_token,
      status: "authenticated",
      user,
      activeOrganizationId: getDefaultOrganizationId(user),
    }),
  syncUser: (user) =>
    set((state) => ({
      user,
      activeOrganizationId:
        user?.organizations?.some(
          (organization) => organization.id === state.activeOrganizationId,
        )
          ? state.activeOrganizationId
          : getDefaultOrganizationId(user),
    })),
  resetAuth: () =>
    set({
      accessToken: null,
      refreshToken: null,
      status: "anonymous",
      user: null,
      activeOrganizationId: null,
    }),
})
