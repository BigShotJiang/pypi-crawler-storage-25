import type { AuthResponse } from "~/lib/api/generated/models/authResponse"
import type { OrganizationSummary } from "~/lib/api/generated/models/organizationSummary"
import type { UserView } from "~/lib/api/generated/models/userView"

export type AuthStatus = "anonymous" | "authenticated"

export type PersistedSessionState = {
  accessToken: string | null
  refreshToken: string | null
  status: AuthStatus
}

export type SessionSlice = PersistedSessionState & {
  hasHydrated: boolean
  setHydrated: (hasHydrated: boolean) => void
  setTokens: (tokens: {
    accessToken: string
    refreshToken: string | null
  }) => void
  clearTokens: () => void
}

export type ViewerSlice = {
  user: UserView | null
  activeOrganizationId: string | null
  setUser: (user: UserView | null) => void
  setActiveOrganizationId: (organizationId: string | null) => void
  clearUser: () => void
}

export type AuthActionsSlice = {
  applyAuthResponse: (payload: AuthResponse) => void
  syncUser: (user: UserView | null) => void
  resetAuth: () => void
}

export type AppStore = SessionSlice & ViewerSlice & AuthActionsSlice

export function getDefaultOrganizationId(user: UserView | null) {
  return (
    user?.organizations?.find((organization) => organization.current)?.id ??
    user?.organizations?.[0]?.id ??
    null
  )
}

export function selectIsAuthenticated(state: AppStore) {
  return state.status === "authenticated" && Boolean(state.accessToken)
}

export function selectCurrentUser(state: AppStore) {
  return state.user
}

export function selectHasHydrated(state: AppStore) {
  return state.hasHydrated
}

export function selectCurrentOrganization(
  state: AppStore,
): OrganizationSummary | null {
  if (!state.user?.organizations?.length) {
    return null
  }

  return (
    state.user.organizations.find(
      (organization) => organization.id === state.activeOrganizationId,
    ) ??
    state.user.organizations.find((organization) => organization.current) ??
    state.user.organizations[0] ??
    null
  )
}
