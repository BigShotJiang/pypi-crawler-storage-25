import { type RouteConfig, index, route, layout } from "@react-router/dev/routes"

export default [
  route("login", "routes/login.tsx"),
  route("signup", "routes/signup.tsx"),
  layout("routes/layout.tsx", [
    index("routes/home.tsx"),
    route("profile", "routes/profile.tsx"),
    route("members", "routes/members.tsx"),
    route("api-keys", "routes/api-keys.tsx"),
  ]),
] satisfies RouteConfig
