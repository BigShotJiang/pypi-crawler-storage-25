import { useState, type FormEvent } from "react"
import { useCurrentOrg } from "~/hooks/use-auth"
import { useMutation, useQueryClient } from "@tanstack/react-query"
import {
  getMembersQueryKey,
  inviteMember,
  revokeMember,
  useMembersQuery,
  updateMemberRole,
} from "~/lib/api"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "~/components/ui/card"
import { Button } from "~/components/ui/button"
import { Input } from "~/components/ui/input"
import { Label } from "~/components/ui/label"
import { Badge } from "~/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "~/components/ui/dialog"

export default function MembersPage() {
  const queryClient = useQueryClient()
  const currentOrg = useCurrentOrg()
  const [inviteEmail, setInviteEmail] = useState("")
  const [inviteRole, setInviteRole] = useState("member")
  const [dialogOpen, setDialogOpen] = useState(false)

  const membersQuery = useMembersQuery(currentOrg?.id ?? "")

  const inviteMutation = useMutation({
    mutationFn: () => inviteMember(currentOrg!.id, inviteEmail, inviteRole),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: getMembersQueryKey(currentOrg!.id) })
      setInviteEmail("")
      setInviteRole("member")
      setDialogOpen(false)
    },
  })

  const revokeMutation = useMutation({
    mutationFn: (membershipId: string) =>
      revokeMember(currentOrg!.id, membershipId),
    onSuccess: () =>
      queryClient.invalidateQueries({ queryKey: getMembersQueryKey(currentOrg!.id) }),
  })

  const promoteMutation = useMutation({
    mutationFn: (membershipId: string) =>
      updateMemberRole(currentOrg!.id, membershipId, "admin"),
    onSuccess: () =>
      queryClient.invalidateQueries({ queryKey: getMembersQueryKey(currentOrg!.id) }),
  })

  function handleInvite(e: FormEvent) {
    e.preventDefault()
    inviteMutation.mutate()
  }

  if (!currentOrg) {
    return (
      <p className="text-muted-foreground text-sm">
        No organization selected.
      </p>
    )
  }

  return (
    <div className="grid gap-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold tracking-tight">Members</h1>
          <p className="text-muted-foreground text-sm">
            Manage members of {currentOrg.name}
          </p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger render={<Button />}>Invite member</DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Invite a team member</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleInvite} className="grid gap-4">
              <div className="grid gap-2">
                <Label htmlFor="invite-email">Email address</Label>
                <Input
                  id="invite-email"
                  type="email"
                  value={inviteEmail}
                  onChange={(e) => setInviteEmail(e.target.value)}
                  placeholder="teammate@example.com"
                  required
                  autoFocus
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="invite-role">Role</Label>
                <Input
                  id="invite-role"
                  value={inviteRole}
                  onChange={(e) => setInviteRole(e.target.value)}
                  placeholder="member"
                />
              </div>
              {inviteMutation.error && (
                <p className="text-destructive text-sm">
                  {inviteMutation.error.message}
                </p>
              )}
              <Button type="submit" disabled={inviteMutation.isPending}>
                {inviteMutation.isPending ? "Sending..." : "Send invite"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Team members</CardTitle>
          <CardDescription>
            {membersQuery.data?.members.length ?? 0} members
          </CardDescription>
        </CardHeader>
        <CardContent>
          {membersQuery.isLoading ? (
            <p className="text-muted-foreground text-sm">Loading...</p>
          ) : (
            <div className="grid gap-2">
              {membersQuery.data?.members.map((member) => (
                <div
                  key={member.id}
                  className="flex items-center justify-between rounded-md border p-3"
                >
                  <div className="grid gap-0.5">
                    <span className="text-sm font-medium">
                      {member.email ?? "Pending invite"}
                    </span>
                    <span className="text-muted-foreground text-xs">
                      Joined{" "}
                      {new Date(member.created_at).toLocaleDateString()}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">{member.role_slug}</Badge>
                    <Badge variant="secondary">{member.state}</Badge>
                    {member.role_slug !== "owner" && (
                      <>
                        {member.role_slug !== "admin" && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => promoteMutation.mutate(member.id)}
                          >
                            Make admin
                          </Button>
                        )}
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-destructive"
                          onClick={() => revokeMutation.mutate(member.id)}
                        >
                          Remove
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
