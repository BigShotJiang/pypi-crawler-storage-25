import { Link, NavLink, Navigate, Outlet, useNavigate } from "react-router"
import { useAuth, useCurrentOrg } from "~/hooks/use-auth"
import { Button } from "~/components/ui/button"
import { Separator } from "~/components/ui/separator"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "~/components/ui/dropdown-menu"
import { Avatar, AvatarFallback } from "~/components/ui/avatar"

function navLinkClass({ isActive }: { isActive: boolean }) {
  return [
    "text-sm px-3 py-1.5 rounded-md transition-colors",
    isActive
      ? "bg-accent text-accent-foreground font-medium"
      : "text-muted-foreground hover:text-foreground hover:bg-accent/50",
  ].join(" ")
}

export default function AppLayout() {
  const navigate = useNavigate()
  const { user, isLoading, logout } = useAuth()
  const currentOrg = useCurrentOrg()

  if (isLoading) {
    return (
      <div className="flex min-h-svh items-center justify-center">
        <p className="text-muted-foreground text-sm">Loading...</p>
      </div>
    )
  }

  if (!user) {
    return <Navigate to="/login" replace />
  }

  const initials = user.email
    .split("@")[0]
    .slice(0, 2)
    .toUpperCase()

  return (
    <div className="flex min-h-svh flex-col">
      <header className="border-b">
        <div className="mx-auto flex h-14 max-w-5xl items-center gap-4 px-4">
          <Link to="/" className="text-sm font-semibold tracking-tight">
            Vanty Auth
          </Link>
          {currentOrg && (
            <>
              <Separator orientation="vertical" className="!h-4" />
              <span className="text-muted-foreground text-xs">
                {currentOrg.name}
              </span>
            </>
          )}
          <nav className="ml-auto flex items-center gap-1">
            <NavLink to="/" end className={navLinkClass}>
              Dashboard
            </NavLink>
            <NavLink to="/profile" className={navLinkClass}>
              Profile
            </NavLink>
            <NavLink to="/members" className={navLinkClass}>
              Members
            </NavLink>
            <NavLink to="/api-keys" className={navLinkClass}>
              API Keys
            </NavLink>
          </nav>
          <DropdownMenu>
            <DropdownMenuTrigger
              render={
                <Button variant="ghost" size="icon" className="rounded-full" />
              }
            >
              <Avatar className="h-7 w-7">
                <AvatarFallback className="text-xs">{initials}</AvatarFallback>
              </Avatar>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <div className="px-2 py-1.5">
                <p className="text-sm font-medium">{user.email}</p>
                <p className="text-muted-foreground text-xs">
                  {currentOrg?.role_slug ?? "user"}
                </p>
              </div>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => navigate("/profile")}>
                Profile & security
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={logout}>Sign out</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </header>
      <main className="mx-auto w-full max-w-5xl flex-1 px-4 py-8">
        <Outlet />
      </main>
    </div>
  )
}
