import { useState, type FormEvent } from "react"
import { useMutation, useQueryClient } from "@tanstack/react-query"
import {
  createApiKey,
  getApiKeysQueryKey,
  revokeApiKey,
  useApiKeysQuery,
} from "~/lib/api"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "~/components/ui/card"
import { Button } from "~/components/ui/button"
import { Input } from "~/components/ui/input"
import { Label } from "~/components/ui/label"
import { Badge } from "~/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "~/components/ui/dialog"

export default function ApiKeysPage() {
  const queryClient = useQueryClient()
  const [name, setName] = useState("")
  const [description, setDescription] = useState("")
  const [permissions, setPermissions] = useState("")
  const [dialogOpen, setDialogOpen] = useState(false)
  const [createdSecret, setCreatedSecret] = useState<string | null>(null)

  const keysQuery = useApiKeysQuery()

  const createMutation = useMutation({
    mutationFn: () =>
      createApiKey(
        name,
        description,
        permissions
          .split(",")
          .map((s) => s.trim())
          .filter(Boolean),
      ),
    onSuccess: (data) => {
      setCreatedSecret(data.secret)
      setName("")
      setDescription("")
      setPermissions("")
      queryClient.invalidateQueries({ queryKey: getApiKeysQueryKey() })
    },
  })

  const revokeMutation = useMutation({
    mutationFn: revokeApiKey,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: getApiKeysQueryKey() }),
  })

  function handleCreate(e: FormEvent) {
    e.preventDefault()
    createMutation.mutate()
  }

  return (
    <div className="grid gap-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold tracking-tight">API Keys</h1>
          <p className="text-muted-foreground text-sm">
            Create and manage organization-scoped API keys
          </p>
        </div>
        <Dialog
          open={dialogOpen}
          onOpenChange={(open) => {
            setDialogOpen(open)
            if (!open) setCreatedSecret(null)
          }}
        >
          <DialogTrigger render={<Button />}>Create key</DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {createdSecret ? "Key created" : "New API key"}
              </DialogTitle>
            </DialogHeader>
            {createdSecret ? (
              <div className="grid gap-3">
                <p className="text-sm">
                  Copy this secret now. It will not be shown again.
                </p>
                <code className="bg-muted rounded p-3 text-xs font-mono break-all select-all">
                  {createdSecret}
                </code>
                <Button onClick={() => {
                  setCreatedSecret(null)
                  setDialogOpen(false)
                }}>
                  Done
                </Button>
              </div>
            ) : (
              <form onSubmit={handleCreate} className="grid gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="key-name">Name</Label>
                  <Input
                    id="key-name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="My API key"
                    required
                    autoFocus
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="key-desc">Description</Label>
                  <Input
                    id="key-desc"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="For CI/CD pipeline"
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="key-perms">Permissions</Label>
                  <Input
                    id="key-perms"
                    value={permissions}
                    onChange={(e) => setPermissions(e.target.value)}
                    placeholder="org:members:read, org:api_keys:manage"
                  />
                  <p className="text-muted-foreground text-xs">
                    Comma-separated permission strings
                  </p>
                </div>
                {createMutation.error && (
                  <p className="text-destructive text-sm">
                    {createMutation.error.message}
                  </p>
                )}
                <Button type="submit" disabled={createMutation.isPending}>
                  {createMutation.isPending ? "Creating..." : "Create key"}
                </Button>
              </form>
            )}
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Keys</CardTitle>
          <CardDescription>
            {keysQuery.data?.api_keys.length ?? 0} keys
          </CardDescription>
        </CardHeader>
        <CardContent>
          {keysQuery.isLoading ? (
            <p className="text-muted-foreground text-sm">Loading...</p>
          ) : keysQuery.data?.api_keys.length === 0 ? (
            <p className="text-muted-foreground text-sm">
              No API keys yet. Create one to get started.
            </p>
          ) : (
            <div className="grid gap-2">
              {keysQuery.data?.api_keys.map((key) => (
                <div
                  key={key.id}
                  className="flex items-center justify-between rounded-md border p-3"
                >
                  <div className="grid gap-0.5">
                    <span className="text-sm font-medium">{key.name}</span>
                    <span className="text-muted-foreground text-xs font-mono">
                      {key.key_prefix}...
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    {key.revoked_at ? (
                      <Badge variant="destructive">Revoked</Badge>
                    ) : (
                      <>
                        <Badge variant="outline">Active</Badge>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-destructive"
                          onClick={() => revokeMutation.mutate(key.id)}
                        >
                          Revoke
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
