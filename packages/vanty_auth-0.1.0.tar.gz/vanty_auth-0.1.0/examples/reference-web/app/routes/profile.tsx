import { useState, type FormEvent } from "react"
import { useAuth } from "~/hooks/use-auth"
import { useMutation, useQueryClient } from "@tanstack/react-query"
import {
  changePassword,
  confirmTotp,
  disableMfa,
  enrollTotp,
  getMeQueryKey,
  regenerateRecoveryCodes,
  useSessionsQuery,
} from "~/lib/api"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "~/components/ui/card"
import { Button } from "~/components/ui/button"
import { Input } from "~/components/ui/input"
import { Label } from "~/components/ui/label"
import { Badge } from "~/components/ui/badge"
import { Separator } from "~/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "~/components/ui/tabs"

function PasswordSection() {
  const [currentPw, setCurrentPw] = useState("")
  const [newPw, setNewPw] = useState("")
  const [msg, setMsg] = useState<string | null>(null)

  const mutation = useMutation({
    mutationFn: () => changePassword(currentPw, newPw),
    onSuccess: (data) => {
      setMsg(data.message)
      setCurrentPw("")
      setNewPw("")
    },
    onError: (err) => setMsg(err.message),
  })

  function handleSubmit(e: FormEvent) {
    e.preventDefault()
    mutation.mutate()
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Change password</CardTitle>
        <CardDescription>Update your account password</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="grid gap-4 max-w-sm">
          <div className="grid gap-2">
            <Label htmlFor="current-pw">Current password</Label>
            <Input
              id="current-pw"
              type="password"
              value={currentPw}
              onChange={(e) => setCurrentPw(e.target.value)}
              required
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="new-pw">New password</Label>
            <Input
              id="new-pw"
              type="password"
              value={newPw}
              onChange={(e) => setNewPw(e.target.value)}
              required
            />
          </div>
          {msg && <p className="text-sm">{msg}</p>}
          <Button type="submit" disabled={mutation.isPending} className="w-fit">
            {mutation.isPending ? "Updating..." : "Update password"}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}

function MfaSection() {
  const { user, refetch } = useAuth()
  const queryClient = useQueryClient()
  const [totpCode, setTotpCode] = useState("")
  const [disablePw, setDisablePw] = useState("")
  const [recoveryCodes, setRecoveryCodes] = useState<string[] | null>(null)

  const enrollMutation = useMutation({
    mutationFn: enrollTotp,
  })

  const confirmMutation = useMutation({
    mutationFn: () => confirmTotp(totpCode),
    onSuccess: (data) => {
      setRecoveryCodes(data.recovery_codes)
      setTotpCode("")
      refetch()
    },
  })

  const disableMutation = useMutation({
    mutationFn: () => disableMfa(disablePw),
    onSuccess: () => {
      setDisablePw("")
      refetch()
      queryClient.invalidateQueries({ queryKey: getMeQueryKey() })
    },
  })

  const regenMutation = useMutation({
    mutationFn: regenerateRecoveryCodes,
    onSuccess: (data) => setRecoveryCodes(data.recovery_codes),
  })

  if (!user) return null

  return (
    <Card>
      <CardHeader>
        <CardTitle>Two-factor authentication</CardTitle>
        <CardDescription>
          {user.mfa_enabled
            ? "MFA is enabled on your account"
            : "Add an extra layer of security to your account"}
        </CardDescription>
      </CardHeader>
      <CardContent className="grid gap-6">
        {!user.mfa_enabled ? (
          <div className="grid gap-4 max-w-sm">
            {!enrollMutation.data ? (
              <Button
                variant="outline"
                onClick={() => enrollMutation.mutate()}
                disabled={enrollMutation.isPending}
              >
                {enrollMutation.isPending ? "Generating..." : "Set up TOTP"}
              </Button>
            ) : (
              <>
                <div className="grid gap-2">
                  <Label>TOTP secret</Label>
                  <code className="bg-muted rounded p-2 text-xs break-all">
                    {enrollMutation.data.secret}
                  </code>
                </div>
                <div className="grid gap-2">
                  <Label>Provisioning URI</Label>
                  <code className="bg-muted rounded p-2 text-xs break-all">
                    {enrollMutation.data.provisioning_uri}
                  </code>
                </div>
                <Separator />
                <div className="grid gap-2">
                  <Label htmlFor="totp-code">Enter code from authenticator</Label>
                  <Input
                    id="totp-code"
                    value={totpCode}
                    onChange={(e) => setTotpCode(e.target.value)}
                    placeholder="123456"
                    className="font-mono"
                  />
                </div>
                {confirmMutation.error && (
                  <p className="text-destructive text-sm">
                    {confirmMutation.error.message}
                  </p>
                )}
                <Button
                  onClick={() => confirmMutation.mutate()}
                  disabled={confirmMutation.isPending || !totpCode}
                >
                  {confirmMutation.isPending ? "Confirming..." : "Confirm"}
                </Button>
              </>
            )}
          </div>
        ) : (
          <div className="grid gap-4 max-w-sm">
            <div className="flex items-center gap-2">
              <Badge>Enabled</Badge>
              <span className="text-muted-foreground text-sm">
                TOTP is active
              </span>
            </div>
            <Separator />
            <div className="grid gap-2">
              <Label htmlFor="disable-pw">Password to disable MFA</Label>
              <Input
                id="disable-pw"
                type="password"
                value={disablePw}
                onChange={(e) => setDisablePw(e.target.value)}
              />
            </div>
            <div className="flex gap-2">
              <Button
                variant="destructive"
                onClick={() => disableMutation.mutate()}
                disabled={disableMutation.isPending || !disablePw}
              >
                Disable MFA
              </Button>
              <Button
                variant="outline"
                onClick={() => regenMutation.mutate()}
                disabled={regenMutation.isPending}
              >
                Regenerate codes
              </Button>
            </div>
          </div>
        )}

        {recoveryCodes && (
          <div className="grid gap-2">
            <Label>Recovery codes (save these)</Label>
            <div className="bg-muted grid grid-cols-2 gap-1 rounded p-3">
              {recoveryCodes.map((code) => (
                <code key={code} className="text-xs font-mono">
                  {code}
                </code>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

function SessionsSection() {
  const sessionsQuery = useSessionsQuery()

  return (
    <Card>
      <CardHeader>
        <CardTitle>Active sessions</CardTitle>
        <CardDescription>Devices currently signed in</CardDescription>
      </CardHeader>
      <CardContent>
        {sessionsQuery.isLoading ? (
          <p className="text-muted-foreground text-sm">Loading...</p>
        ) : (
          <div className="grid gap-2">
            {sessionsQuery.data?.sessions.map((session) => (
              <div
                key={session.id}
                className="flex items-center justify-between rounded-md border p-3"
              >
                <div className="grid gap-0.5">
                  <span className="text-sm font-medium font-mono">
                    {session.id.slice(0, 8)}
                  </span>
                  <span className="text-muted-foreground text-xs">
                    {session.ip_address ?? "Unknown IP"} ·{" "}
                    {new Date(session.last_seen_at).toLocaleString()}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  {session.current && (
                    <Badge variant="secondary">Current</Badge>
                  )}
                  <Badge variant="outline">{session.transport}</Badge>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

export default function ProfilePage() {
  return (
    <div className="grid gap-6">
      <div>
        <h1 className="text-xl font-semibold tracking-tight">
          Profile & Security
        </h1>
        <p className="text-muted-foreground text-sm">
          Manage your password, two-factor authentication, and active sessions
        </p>
      </div>
      <Tabs defaultValue="security">
        <TabsList>
          <TabsTrigger value="security">Security</TabsTrigger>
          <TabsTrigger value="mfa">MFA</TabsTrigger>
          <TabsTrigger value="sessions">Sessions</TabsTrigger>
        </TabsList>
        <TabsContent value="security" className="mt-4">
          <PasswordSection />
        </TabsContent>
        <TabsContent value="mfa" className="mt-4">
          <MfaSection />
        </TabsContent>
        <TabsContent value="sessions" className="mt-4">
          <SessionsSection />
        </TabsContent>
      </Tabs>
    </div>
  )
}
