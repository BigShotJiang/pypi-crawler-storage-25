import { useAuth, useCurrentOrg } from "~/hooks/use-auth"
import { useQueryClient } from "@tanstack/react-query"
import {
  getMeQueryKey,
  getSessionsQueryKey,
  switchOrganization,
  useSessionsQuery,
} from "~/lib/api"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "~/components/ui/card"
import { Badge } from "~/components/ui/badge"
import { Button } from "~/components/ui/button"

export default function DashboardPage() {
  const queryClient = useQueryClient()
  const { user, refetch } = useAuth()
  const currentOrg = useCurrentOrg()

  const sessionsQuery = useSessionsQuery()

  if (!user) return null

  async function handleSwitch(orgId: string) {
    await switchOrganization(orgId)
    await refetch()
    await queryClient.invalidateQueries({ queryKey: getMeQueryKey() })
    await queryClient.invalidateQueries({ queryKey: getSessionsQueryKey() })
  }

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>Account</CardTitle>
          <CardDescription>Your account overview</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-3 text-sm">
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground">Email</span>
            <span className="font-medium">{user.email}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground">Email verified</span>
            <Badge variant={user.email_verified ? "default" : "destructive"}>
              {user.email_verified ? "Verified" : "Unverified"}
            </Badge>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground">MFA</span>
            <Badge variant={user.mfa_enabled ? "default" : "secondary"}>
              {user.mfa_enabled ? "Enabled" : "Disabled"}
            </Badge>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground">Active sessions</span>
            <span className="font-mono text-xs">
              {sessionsQuery.data?.sessions.length ?? "..."}
            </span>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Organizations</CardTitle>
          <CardDescription>
            Switch the active organization on your session
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-2">
          {(user.organizations ?? []).map((org) => (
            <div
              key={org.id}
              className="flex items-center justify-between rounded-md border p-3"
            >
              <div className="grid gap-0.5">
                <span className="text-sm font-medium">{org.name}</span>
                <span className="text-muted-foreground text-xs">
                  {org.role_slug}
                </span>
              </div>
              {org.current ? (
                <Badge variant="secondary">Current</Badge>
              ) : (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleSwitch(org.id)}
                >
                  Switch
                </Button>
              )}
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  )
}
