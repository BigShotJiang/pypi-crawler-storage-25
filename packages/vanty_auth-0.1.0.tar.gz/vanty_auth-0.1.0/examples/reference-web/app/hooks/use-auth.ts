import { useCallback, useEffect } from "react"
import { useNavigate } from "react-router"
import { useQueryClient } from "@tanstack/react-query"

import { ApiError, getMeQueryKey } from "~/lib/api"
import { useMeAuthMeGet } from "~/lib/api/generated/auth/auth"
import {
  selectCurrentOrganization,
  selectCurrentUser,
  selectHasHydrated,
  selectIsAuthenticated,
  useAppStore,
} from "~/store"

export function useAuth() {
  const queryClient = useQueryClient()
  const navigate = useNavigate()
  const hasHydrated = useAppStore(selectHasHydrated)
  const user = useAppStore(selectCurrentUser)
  const isAuthenticated = useAppStore(selectIsAuthenticated)
  const applyAuthResponse = useAppStore((state) => state.applyAuthResponse)
  const resetAuth = useAppStore((state) => state.resetAuth)
  const syncUser = useAppStore((state) => state.syncUser)

  const meQuery = useMeAuthMeGet({
    query: {
      enabled: hasHydrated && isAuthenticated,
      retry: false,
    },
  })

  useEffect(() => {
    if (meQuery.data) {
      syncUser(meQuery.data)
    }
  }, [meQuery.data, syncUser])

  useEffect(() => {
    if (meQuery.error instanceof ApiError && meQuery.error.status === 401) {
      resetAuth()
      queryClient.removeQueries({ queryKey: getMeQueryKey() })
    }
  }, [meQuery.error, queryClient, resetAuth])

  const finishLogin = useCallback(
    (response: Parameters<typeof applyAuthResponse>[0]) => {
      applyAuthResponse(response)
      queryClient.setQueryData(getMeQueryKey(), response.user)
    },
    [applyAuthResponse, queryClient],
  )

  const logout = useCallback(() => {
    resetAuth()
    queryClient.clear()
    navigate("/login")
  }, [navigate, queryClient, resetAuth])

  return {
    user,
    isLoading: !hasHydrated || (isAuthenticated && meQuery.isLoading),
    isAuthenticated,
    finishLogin,
    logout,
    refetch: meQuery.refetch,
  }
}

export function useCurrentOrg() {
  return useAppStore(selectCurrentOrganization)
}
