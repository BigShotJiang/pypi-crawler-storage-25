import {
  changePasswordAuthPasswordChangePost,
  confirmTotpAuthMfaTotpConfirmPost,
  createApiKeyAuthApiKeysPost,
  enrollTotpAuthMfaTotpEnrollPost,
  getListApiKeysAuthApiKeysGetQueryKey,
  getListMembersAuthOrganizationsOrgIdMembersGetQueryKey,
  getListSessionsAuthSessionsGetQueryKey,
  getMeAuthMeGetQueryKey,
  inviteMemberAuthOrganizationsOrgIdInvitesPost,
  listApiKeysAuthApiKeysGet,
  listMembersAuthOrganizationsOrgIdMembersGet,
  listSessionsAuthSessionsGet,
  loginAuthLoginPost,
  meAuthMeGet,
  regenerateRecoveryCodesAuthMfaRecoveryCodesPost,
  revokeApiKeyAuthApiKeysApiKeyIdDelete,
  revokeMemberAuthOrganizationsOrgIdMembersMembershipIdDelete,
  signupAuthSignupPost,
  switchOrganizationAuthOrganizationsSwitchPost,
  updateMemberRoleAuthOrganizationsOrgIdMembersMembershipIdPatch,
  useListApiKeysAuthApiKeysGet,
  useListMembersAuthOrganizationsOrgIdMembersGet,
  useListSessionsAuthSessionsGet,
  verifyEmailAuthEmailVerifyPost,
  disableMfaAuthMfaDisablePost,
} from "~/lib/api/generated/auth/auth"
import type {
  ApiKeysResponse,
  ApiKeyView,
  AuthResponse,
  CreateApiKeyResponse,
  MemberView,
  MembersResponse,
  MessageResponse,
  MfaChallengeResponse,
  OrganizationSummary,
  RecoveryCodesResponse,
  SessionView,
  SessionsResponse,
  TotpEnrollmentResponse,
  UserView,
} from "~/lib/api/generated/models"
export { API_BASE_URL, ApiError } from "~/lib/api/mutator"

export function isAuthResponse(
  value: AuthResponse | MfaChallengeResponse,
): value is AuthResponse {
  return "access_token" in value
}

export function isMfaChallenge(
  value: AuthResponse | MfaChallengeResponse,
): value is MfaChallengeResponse {
  return "mfa_token" in value && !("access_token" in value)
}

export {
  getListApiKeysAuthApiKeysGetQueryKey as getApiKeysQueryKey,
  getListMembersAuthOrganizationsOrgIdMembersGetQueryKey as getMembersQueryKey,
  getListSessionsAuthSessionsGetQueryKey as getSessionsQueryKey,
  getMeAuthMeGetQueryKey as getMeQueryKey,
}

export type {
  ApiKeysResponse,
  ApiKeyView,
  AuthResponse,
  CreateApiKeyResponse,
  MemberView,
  MembersResponse,
  MessageResponse,
  MfaChallengeResponse,
  OrganizationSummary,
  RecoveryCodesResponse,
  SessionView,
  SessionsResponse,
  TotpEnrollmentResponse,
  UserView,
}

export function signup(email: string, password: string): Promise<MessageResponse> {
  return signupAuthSignupPost({ email, password })
}

export function verifyEmail(token: string): Promise<MessageResponse> {
  return verifyEmailAuthEmailVerifyPost({ token })
}

export function login(
  email: string,
  password: string,
): Promise<AuthResponse | MfaChallengeResponse> {
  return loginAuthLoginPost({ email, password })
}

export function fetchMe(): Promise<UserView> {
  return meAuthMeGet()
}

export function changePassword(
  current_password: string,
  new_password: string,
): Promise<MessageResponse> {
  return changePasswordAuthPasswordChangePost({
    current_password,
    new_password,
  })
}

export function fetchSessions(): Promise<SessionsResponse> {
  return listSessionsAuthSessionsGet()
}

export function useSessionsQuery() {
  return useListSessionsAuthSessionsGet()
}

export function enrollTotp(): Promise<TotpEnrollmentResponse> {
  return enrollTotpAuthMfaTotpEnrollPost()
}

export function confirmTotp(code: string): Promise<RecoveryCodesResponse> {
  return confirmTotpAuthMfaTotpConfirmPost({ code })
}

export function disableMfa(password: string): Promise<MessageResponse> {
  return disableMfaAuthMfaDisablePost({ password })
}

export function regenerateRecoveryCodes(): Promise<RecoveryCodesResponse> {
  return regenerateRecoveryCodesAuthMfaRecoveryCodesPost()
}

export function switchOrganization(
  organization_id: string,
): Promise<MessageResponse> {
  return switchOrganizationAuthOrganizationsSwitchPost({ organization_id })
}

export function listMembers(orgId: string): Promise<MembersResponse> {
  return listMembersAuthOrganizationsOrgIdMembersGet(orgId)
}

export function useMembersQuery(orgId: string) {
  return useListMembersAuthOrganizationsOrgIdMembersGet(orgId)
}

export function inviteMember(
  orgId: string,
  email: string,
  role_slug: string,
): Promise<MessageResponse> {
  return inviteMemberAuthOrganizationsOrgIdInvitesPost(orgId, {
    email,
    role_slug,
  })
}

export function updateMemberRole(
  orgId: string,
  membershipId: string,
  role_slug: string,
): Promise<MessageResponse> {
  return updateMemberRoleAuthOrganizationsOrgIdMembersMembershipIdPatch(
    orgId,
    membershipId,
    { role_slug },
  )
}

export function revokeMember(
  orgId: string,
  membershipId: string,
): Promise<MessageResponse> {
  return revokeMemberAuthOrganizationsOrgIdMembersMembershipIdDelete(
    orgId,
    membershipId,
  )
}

export function listApiKeys(): Promise<ApiKeysResponse> {
  return listApiKeysAuthApiKeysGet()
}

export function useApiKeysQuery() {
  return useListApiKeysAuthApiKeysGet()
}

export function createApiKey(
  name: string,
  description: string,
  permissions: string[],
): Promise<CreateApiKeyResponse> {
  return createApiKeyAuthApiKeysPost({
    name,
    description,
    permissions,
  })
}

export function revokeApiKey(apiKeyId: string): Promise<MessageResponse> {
  return revokeApiKeyAuthApiKeysApiKeyIdDelete(apiKeyId)
}
