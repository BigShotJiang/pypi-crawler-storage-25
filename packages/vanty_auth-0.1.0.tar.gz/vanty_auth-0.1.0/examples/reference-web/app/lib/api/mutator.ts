import { useAppStore } from "~/store"

export const API_BASE_URL =
  import.meta.env.VITE_API_BASE_URL ?? "http://127.0.0.1:8000"

export class ApiError extends Error {
  constructor(
    public readonly status: number,
    public readonly body: unknown,
  ) {
    super(
      typeof body === "string" && body
        ? body
        : `Request failed with status ${status}`,
    )
  }
}

export type BodyType<BodyData> = BodyData
export type ErrorType<ErrorData> = ApiError & { data?: ErrorData }

type RequestOptions = Omit<RequestInit, "body"> & {
  body?: BodyInit | null
}

function isJsonBody(value: unknown) {
  return (
    value !== null &&
    typeof value === "object" &&
    !(value instanceof Blob) &&
    !(value instanceof ArrayBuffer) &&
    !(value instanceof FormData) &&
    !(value instanceof URLSearchParams)
  )
}

async function parseResponse(response: Response) {
  if (response.status === 204 || response.status === 205) {
    return null
  }

  const contentType = response.headers.get("content-type") ?? ""
  if (contentType.includes("application/json")) {
    return response.json()
  }

  const text = await response.text()
  return text || null
}

export async function apiClient<T>(
  path: string,
  { body, headers, ...requestOptions }: RequestOptions = {},
): Promise<T> {
  const authHeaders = new Headers(headers)
  const accessToken = useAppStore.getState().accessToken

  if (accessToken) {
    authHeaders.set("Authorization", `Bearer ${accessToken}`)
  }

  let requestBody: BodyInit | null | undefined
  if (body !== undefined && body !== null) {
    if (isJsonBody(body)) {
      authHeaders.set("Content-Type", "application/json")
      requestBody = JSON.stringify(body)
    } else {
      requestBody = body as BodyInit
    }
  }

  const response = await fetch(new URL(path, API_BASE_URL), {
    ...requestOptions,
    body: requestBody,
    headers: authHeaders,
    credentials: "include",
  })

  const data = await parseResponse(response)
  if (!response.ok) {
    throw new ApiError(response.status, data)
  }

  return data as T
}
