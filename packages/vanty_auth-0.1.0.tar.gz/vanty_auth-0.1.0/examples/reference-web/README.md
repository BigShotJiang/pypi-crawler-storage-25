# Reference Web

`reference-web` is the frontend example for `vanty-auth`. It is intended to be a copyable, production-shaped example rather than a throwaway demo.

## Stack

- React Router
- shadcn/ui
- TanStack Query
- Zustand with slice composition
- Orval for generated SDK and hooks

## API Generation

The checked-in OpenAPI spec lives at `openapi/vanty-auth.openapi.json`.

Regenerate the spec and frontend client with:

```bash
pnpm run generate:api
```

That script:

1. loads the FastAPI app from `../reference-api/main.py`
2. writes a fresh OpenAPI document into `openapi/`
3. runs Orval with `orval.config.ts`

## File Ownership

Generated files:

- `app/lib/api/generated/**`
- `openapi/vanty-auth.openapi.json`

Hand-maintained files:

- `app/lib/api.ts`
- `app/lib/api/mutator.ts`
- `app/store/**`
- `app/hooks/**`
- `app/routes/**`

## Responsibility Split

- Orval generates the typed SDK and TanStack Query hooks from the checked-in OpenAPI schema.
- `app/lib/api/mutator.ts` owns transport concerns such as base URL resolution, credentials, auth header injection, and HTTP error normalization.
- `app/lib/api.ts` is the small app-facing facade that maps generated exports into readable frontend primitives.
- Zustand owns durable client state such as auth tokens, hydration state, the current user, and the active organization.
- TanStack Query owns server state, caching, and invalidation for backend resources.

## Development

Start the backend and frontend in separate terminals:

```bash
cd ../reference-api
uv run --with uvicorn uvicorn main:app --host 127.0.0.1 --port 8000
```

```bash
pnpm run dev -- --host 127.0.0.1 --port 5173
```

Run checks with:

```bash
pnpm run typecheck
pnpm run build
```
