import { defineConfig } from "orval"

export default defineConfig({
  vantyAuth: {
    input: {
      target: "./openapi/vanty-auth.openapi.json",
    },
    output: {
      target: "./app/lib/api/generated/index.ts",
      schemas: "./app/lib/api/generated/models",
      client: "react-query",
      mode: "tags-split",
      clean: true,
      prettier: true,
      override: {
        mutator: {
          path: "./app/lib/api/mutator.ts",
          name: "apiClient",
        },
        fetch: {
          includeHttpResponseReturnType: false,
        },
        query: {
          useQuery: true,
          useInfinite: false,
        },
      },
    },
  },
})
