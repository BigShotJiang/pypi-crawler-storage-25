# Changelog

## 0.1.0

- Flatten the repository to a standard Python package layout with root `src/`, `docs/`, `examples/`, and `tests/`.
- Add an integration-first pytest suite with strict coverage gating and CI validation.
- Publish the package from the repo root with package-facing README, license, and build metadata.
