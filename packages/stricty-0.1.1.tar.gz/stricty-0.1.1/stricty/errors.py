class StrictTypeError(TypeError):
    pass