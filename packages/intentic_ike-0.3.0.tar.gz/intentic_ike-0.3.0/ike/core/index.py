"""SQLite WAL index for routing metadata.

Stores ONLY metadata (title, summary, domain, token_count, mtime).
Never stores line positions — fetcher/writer always live-parse.

Thread-safety: connections are created per-thread via threading.local().
This is required because FastMCP dispatches tool calls in a thread pool.
"""

from __future__ import annotations

import sqlite3
import threading
from pathlib import Path

from .parser import Parser
from .types import ChunkRef

_SCHEMA = """\
CREATE TABLE IF NOT EXISTS chunks (
    file_path    TEXT NOT NULL,
    section_id   TEXT NOT NULL,
    section_title TEXT,
    token_count  INTEGER,
    knowledge_type TEXT,
    summary      TEXT,
    title        TEXT,
    domain       TEXT,
    file_mtime   REAL,
    PRIMARY KEY (file_path, section_id)
);
"""


class Index:
    def __init__(
        self,
        kb_root: Path,
        db_path: Path | None = None,
    ) -> None:
        self.kb_root = kb_root
        if db_path is None:
            db_path = Path.home() / ".ike" / "index.db"
        db_path.parent.mkdir(parents=True, exist_ok=True)

        self._db_path = str(db_path)
        self._local = threading.local()

        # Validate schema on init thread
        conn = self._get_conn()
        conn.execute("PRAGMA journal_mode=WAL")
        conn.commit()

    def _get_conn(self) -> sqlite3.Connection:
        """Return a thread-local SQLite connection, creating one if needed."""
        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = sqlite3.connect(self._db_path, timeout=5)
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute(_SCHEMA)
            self._local.conn = conn
        return conn

    # ── Build / Rebuild ─────────────────────────────────────────

    def build(self, parser: Parser) -> int:
        """Full build. Parse all .md files and index them. Returns chunk count."""
        total = 0
        for md_file in sorted(self.kb_root.rglob("*.md")):
            if md_file.name.startswith("."):
                continue
            total += self._index_file(md_file, parser)
        self._get_conn().commit()
        return total

    def rebuild(self, parser: Parser) -> int:
        """DROP + full build."""
        self._get_conn().execute("DELETE FROM chunks")
        self._get_conn().commit()
        return self.build(parser)

    def update_file(self, file_path: Path, parser: Parser) -> int:
        """Re-index a single file. Returns new chunk count for that file."""
        rel = self._rel(file_path)
        self._get_conn().execute("DELETE FROM chunks WHERE file_path = ?", (rel,))
        count = self._index_file(file_path, parser)
        self._get_conn().commit()
        return count

    # ── Query ───────────────────────────────────────────────────

    def query(
        self,
        keywords: list[str],
        knowledge_type: str | None = None,
        limit: int = 10,
    ) -> list[ChunkRef]:
        """SQL LIKE match on title, summary, domain, section_title.

        Scoring: each keyword match in title/summary/domain adds 1 point.
        Results sorted by score descending.
        """
        if not keywords:
            return self._all_chunks(knowledge_type, limit)

        conditions = []
        params: list[str] = []

        for kw in keywords:
            like = f"%{kw}%"
            conditions.append(
                "(title LIKE ? OR summary LIKE ? OR domain LIKE ? OR section_title LIKE ?)"
            )
            params.extend([like, like, like, like])

        where = " OR ".join(conditions)

        # Score: count how many keyword conditions match
        score_parts = []
        score_params: list[str] = []
        for kw in keywords:
            like = f"%{kw}%"
            score_parts.append(
                "(CASE WHEN title LIKE ? THEN 1 ELSE 0 END"
                " + CASE WHEN summary LIKE ? THEN 1 ELSE 0 END"
                " + CASE WHEN domain LIKE ? THEN 1 ELSE 0 END"
                " + CASE WHEN section_title LIKE ? THEN 1 ELSE 0 END)"
            )
            score_params.extend([like, like, like, like])

        score_expr = " + ".join(score_parts)

        type_filter = ""
        type_params: list[str] = []
        if knowledge_type:
            type_filter = " AND knowledge_type = ?"
            type_params = [knowledge_type]

        sql = (
            f"SELECT file_path, section_id, token_count, ({score_expr}) AS score"
            f" FROM chunks WHERE ({where}){type_filter}"
            f" ORDER BY score DESC LIMIT ?"
        )
        all_params = score_params + params + type_params + [str(limit)]

        rows = self._get_conn().execute(sql, all_params).fetchall()
        return [
            ChunkRef(
                file_path=row[0],
                section_id=row[1],
                token_count=row[2] or 0,
                score=float(row[3]),
            )
            for row in rows
        ]

    # ── Freshness ───────────────────────────────────────────────

    def needs_update(self, file_path: Path) -> bool:
        """Compare mtime in DB vs filesystem."""
        rel = self._rel(file_path)
        row = self._get_conn().execute(
            "SELECT file_mtime FROM chunks WHERE file_path = ? LIMIT 1", (rel,)
        ).fetchone()
        if row is None:
            return True
        try:
            current_mtime = file_path.stat().st_mtime
        except OSError:
            return True
        return current_mtime > row[0]

    def ensure_fresh(self, parser: Parser) -> None:
        """Re-index only changed files."""
        for md_file in sorted(self.kb_root.rglob("*.md")):
            if md_file.name.startswith("."):
                continue
            if self.needs_update(md_file):
                rel = self._rel(md_file)
                self._get_conn().execute("DELETE FROM chunks WHERE file_path = ?", (rel,))
                self._index_file(md_file, parser)
        self._get_conn().commit()

    # ── Private ─────────────────────────────────────────────────

    def _index_file(self, file_path: Path, parser: Parser) -> int:
        """Parse and insert chunks for one file. Returns chunk count."""
        try:
            doc = parser.parse_document(file_path)
        except Exception:
            return 0

        mtime = file_path.stat().st_mtime
        fm = doc.frontmatter
        title = fm.get("title", "")
        summary = fm.get("summary", "")
        domain = fm.get("domain", "")
        rel = self._rel(file_path)

        for chunk in doc.chunks:
            self._get_conn().execute(
                "INSERT OR REPLACE INTO chunks"
                " (file_path, section_id, section_title, token_count,"
                "  knowledge_type, summary, title, domain, file_mtime)"
                " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    rel,
                    chunk.section_id,
                    chunk.section_title,
                    chunk.token_count,
                    chunk.knowledge_type,
                    summary,
                    title,
                    domain,
                    mtime,
                ),
            )
        return len(doc.chunks)

    def _rel(self, file_path: Path) -> str:
        try:
            return str(file_path.relative_to(self.kb_root))
        except ValueError:
            return str(file_path)

    def _all_chunks(
        self, knowledge_type: str | None, limit: int
    ) -> list[ChunkRef]:
        """Return all chunks (for empty keyword query)."""
        conn = self._get_conn()
        if knowledge_type:
            rows = conn.execute(
                "SELECT file_path, section_id, token_count FROM chunks"
                " WHERE knowledge_type = ? LIMIT ?",
                (knowledge_type, limit),
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT file_path, section_id, token_count FROM chunks LIMIT ?",
                (str(limit),),
            ).fetchall()
        return [
            ChunkRef(file_path=r[0], section_id=r[1], token_count=r[2] or 0, score=0.0)
            for r in rows
        ]
