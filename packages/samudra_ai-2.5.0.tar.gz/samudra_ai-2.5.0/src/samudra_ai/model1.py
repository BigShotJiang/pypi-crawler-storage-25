# # File: src/samudra_ai/models.py

from typing import Tuple, List, Optional
import numpy as np
from tensorflow.keras.models import Model
from tensorflow.keras.layers import (
    Input, TimeDistributed, Conv2D, BatchNormalization,
    Dropout, GlobalAveragePooling2D, GlobalMaxPooling2D, Concatenate, Flatten, Bidirectional, LSTM, Dense, Reshape, LeakyReLU)


class ModelConfig1:
    """Konfigurasi fleksibel untuk CNN-BiLSTM Samudra-AI"""
    def __init__(
        self,
        filters: List[int] = [16, 32, 64, 128],
        kernel_size: Tuple[int, int] = (3, 3),
        # activation: str = "linear",
        rnn_units: int = 64,
        dropout_rates: List[float] = [0.0, 0.1, 0.2, 0.2],
        leaky_relu_alpha: float = 0.1,
        batch_size: int = 8,
        epochs: int = 100,
        learning_rate: float = 3e-4,
        dense_units: int = 512,
        dropout_output = 0.2,
        loss_type: str = "huber",
        huber_delta: float = 0.5,     
        clipnorm: Optional[float] = 0.5,

    ):
        self.filters = filters
        self.kernel_size = kernel_size
        # self.activation = activation
        self.rnn_units = rnn_units
        self.dropout_rates = dropout_rates
        self.leaky_relu_alpha = leaky_relu_alpha
        self.batch_size = batch_size
        self.epochs = epochs
        self.learning_rate = learning_rate
        self.dense_units = dense_units
        self.dropout_output = dropout_output
        self.loss_type = loss_type
        self.huber_delta = huber_delta
        self.clipnorm = clipnorm

def build_cnn_bilstm(
    input_shape: Tuple,
    output_shape: Tuple,
    config: Optional[ModelConfig1] = None
) -> Model:
    """
    Bangun arsitektur CNN-BiLSTM sesuai baseline,
    tapi fleksibel untuk variabel harian/bulanan dan berbagai parameter.
    """
    if config is None:
        config = ModelConfig1()  # pakai default baseline

    target_height, target_width = output_shape[0], output_shape[1]
    inputs = Input(shape=input_shape, name="input_layer")
    x = inputs

    # === TimeDistributed CNN layers ===
    for i, f in enumerate(config.filters):
        x = TimeDistributed(
            Conv2D(f, config.kernel_size, padding="same")
        )(x)
        x = TimeDistributed(LeakyReLU(config.leaky_relu_alpha))(x)
        x = TimeDistributed(BatchNormalization())(x)

        # Tambahkan dropout sesuai urutan kalau tersedia
        if i < len(config.dropout_rates) and config.dropout_rates[i] > 0:
            x = TimeDistributed(Dropout(config.dropout_rates[i]))(x)

    # === Flatten/GAP dan Dropout ===
    # x = TimeDistributed(Flatten())(x)
    gap = TimeDistributed(GlobalAveragePooling2D())(x)
    gmp = TimeDistributed(GlobalMaxPooling2D())(x)
    x = Concatenate(name="hybrid_pooling")([gap, gmp])
    x = Dropout(config.dropout_output)(x)

    # === BiLSTM layers ===
    x = Bidirectional(LSTM(config.rnn_units, return_sequences=True))(x)
    x = Bidirectional(LSTM(config.rnn_units))(x)

    # === Dense ke output ===
    x = Dense(config.dense_units, activation="relu")(x)
    x = Dropout(config.dropout_output)(x)
    x = Dense(target_height * target_width)(x)
    outputs = Reshape((target_height, target_width, 1))(x)

    # === Compile model ===
    model = Model(inputs=inputs, outputs=outputs)
    # optimizer = Adam(learning_rate=config.learning_rate, clipnorm=0.5)
    # model.compile(optimizer=optimizer, loss=losses.Huber(delta=0.5), metrics=["mae"])
    return model