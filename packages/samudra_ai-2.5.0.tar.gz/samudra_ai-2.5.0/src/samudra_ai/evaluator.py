# File: src/samudra_ai/evaluator.py

import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
import seaborn as sns
import xarray as xr
import cartopy.crs as ccrs
from .utils import compute_metrics

# =========================
# 🔹 UTIL: AUTO DIM DETECTION
# =========================
def get_spatial_dims(da):
    return [d for d in da.dims if d != "time"]

# =========================
# 🔹 UTIL: SAFE MEAN (GRID AGNOSTIC)
# =========================
def spatial_mean(da):
    dims = get_spatial_dims(da)
    return da.mean(dim=dims)

def safe_interp_like(mask, target):
    try:
        return mask.interp_like(target, method="nearest")
    except Exception:
        print("⚠️ Mask interp gagal → fallback tanpa alignment")
        return mask

def create_mask_from_reference(ref_da):
    """
    Mask berbasis NaN dari observasi (lebih cepat & konsisten)
    """
    mask = xr.where(np.isnan(ref_da.isel(time=0)), 0, 1)
    return mask

# =========================
# 🔹 UTIL: RENAME FOR PLOT ONLY
# =========================
def ensure_latlon_for_plot(da):
    da = da.copy()

    # sudah ada
    if "lat" in da.dims and "lon" in da.dims:
        return da

    rename_map = {}

    for d in da.dims:
        if d.lower() in ["y", "j", "latitude"]:
            rename_map[d] = "lat"
        elif d.lower() in ["x", "i", "longitude"]:
            rename_map[d] = "lon"

    if rename_map:
        print(f"⚠️ Rename dim untuk plot: {rename_map}")
        da = da.rename(rename_map)

    return da

# =========================
# 🔹 UTIL: MASK FROM REFERENCE (FAST & CONSISTENT)
# =========================
def apply_mask(da, ref_da, mode="ocean"):
    mask = create_mask_from_reference(ref_da)
    mask = safe_interp_like(mask, da)

    if mode == "ocean":
        return da.where(mask == 1)
    elif mode == "land":
        return da.where(mask == 0)
    else:
        return da

# =========================
# 🔹 MAIN EVALUATION
# =========================
def evaluate_model(ref_data, raw_gcm_data, corrected_data, var_name, output_dir=None):

    print("\n🔎 Evaluasi model ...")

    # === SAMAKAN PANJANG TIME ===
    time_len = min(len(ref_data.time), len(raw_gcm_data.time), len(corrected_data.time))

    ref = ref_data.isel(time=slice(0, time_len))
    raw = raw_gcm_data.isel(time=slice(0, time_len))
    corr = corrected_data.isel(time=slice(0, time_len))

    # =========================
    # 🔹 TIMESERIES (NO GRID MATCHING)
    # =========================
    ref_series = spatial_mean(ref)
    raw_series = spatial_mean(raw)
    corr_series = spatial_mean(corr)

    # =========================
    # 🔹 METRICS
    # =========================
    metrics_raw = compute_metrics(ref_series.values, raw_series.values)
    metrics_corr = compute_metrics(ref_series.values, corr_series.values)

    results_df = pd.DataFrame([
        {'Source': 'GCM Asli', **dict(zip(['Correlation', 'RMSE', 'Bias', 'MAE'], metrics_raw))},
        {'Source': 'GCM Terkoreksi', **dict(zip(['Correlation', 'RMSE', 'Bias', 'MAE'], metrics_corr))},
    ])

    # =========================
    # 🔹 SAVE
    # =========================
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
        results_df.to_excel(os.path.join(output_dir, "summary_metrics.xlsx"), index=False)

    # =========================
    # 🔹 TIMESERIES PLOT
    # =========================
    df_line = pd.DataFrame({
        "Time": ref_series.time.values,
        "GCM Asli": raw_series.values,
        "GCM Terkoreksi": corr_series.values,
        "Observasi": ref_series.values
    })

    plt.figure(figsize=(15, 6))
    sns.lineplot(data=df_line)
    plt.title(f"Time Series Comparison {var_name.upper()}")
    plt.grid(True)

    if output_dir:
        plt.savefig(os.path.join(output_dir, "timeseries.png"), dpi=300)

    plt.show()

    # =========================
    # 🔹 METRIC BAR
    # =========================
    df_melt = results_df.melt(id_vars=['Source'], var_name='Metric', value_name='Value')

    plt.figure(figsize=(10, 6))
    sns.barplot(data=df_melt, x='Metric', y='Value', hue='Source')
    plt.title("Evaluation Metrics")

    if output_dir:
        plt.savefig(os.path.join(output_dir, "metrics.png"), dpi=300)

    plt.show()

    return results_df, corr

def ensure_2d(da):
    keep_dims = [d for d in da.dims if d.lower() in ["lat", "lon"]]

    if len(keep_dims) != 2:
        print(f"Reducing extra dims: {da.dims}")
        da = da.mean(dim=[d for d in da.dims if d not in keep_dims])
    return da

# =========================
# 🔹 SPATIAL PLOT (SAFE)
# =========================
def plot_spatial_comparison(
    corrected_da, raw_gcm_da, ref_da,
    var_name, output_dir=None, units="",
    mask_type=None  # "land", "ocean", None
):

    print("🌍 Plot spasial ...")

    out_mean = corrected_da.mean(dim="time")
    gcm_mean = raw_gcm_da.mean(dim="time")
    ref_mean = ref_da.mean(dim="time")

    out_mean = ensure_2d(out_mean)
    gcm_mean = ensure_2d(gcm_mean)
    ref_mean = ensure_2d(ref_mean)

    # 🔥 APPLY MASK
    if mask_type in ["land", "ocean"]:
        out_mean = apply_mask(out_mean, ref_da, mask_type)
        gcm_mean = apply_mask(gcm_mean, ref_da, mask_type)
        ref_mean = apply_mask(ref_mean, ref_da, mask_type)

    # rename untuk plot
    out_mean = ensure_latlon_for_plot(out_mean)
    gcm_mean = ensure_latlon_for_plot(gcm_mean)
    ref_mean = ensure_latlon_for_plot(ref_mean)

    datasets = [out_mean, gcm_mean, ref_mean]
    titles = ["Corrected", "Raw GCM", "Reference"]

    fig, axes = plt.subplots(
        1, 3, figsize=(18, 6),
        subplot_kw={"projection": ccrs.PlateCarree()}
    )

    for ax, da, title in zip(axes, datasets, titles):

        im = ax.pcolormesh(
            da["lon"], da["lat"], da,
            cmap="coolwarm",
            transform=ccrs.PlateCarree()
        )

        ax.coastlines()
        ax.set_title(title)

    # === COLORBAR ===
    cbar = fig.colorbar(im, ax=axes, orientation="horizontal", fraction=0.05)
    cbar.set_label(units)

    plt.suptitle(f"Spatial Comparison {var_name.upper()}")

    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
        path = os.path.join(output_dir, f"spatial_{var_name}.png")
        plt.savefig(path, dpi=300)
        print(f"✅ Saved: {path}")

    plt.show()

# =========================
# 🔹 CARTOPY IMPORT (WAJIB DI ATAS)
# =========================
try:
    import cartopy.crs as ccrs
    HAS_CARTOPY = True
except ImportError:
    HAS_CARTOPY = False

# =========================
# 🔹 UNCERTAINTY PLOTS (POLISHED & SAFE)
# =========================
def plot_uncertainty_map(mean_da, std_da, lower_da, upper_da, var_label, output_dir, ref_da=None, mask_type="auto"):
    """
    Plot uncertainty final:
    1. Relative Uncertainty (%) agar skala warna Hist vs Proj konsisten.
    2. Hist: 3 Panel (Mean, Ref, Uncertainty %).
    3. Proj: 2 Panel (Mean, Uncertainty %).
    4. Masking otomatis (zos=ocean, pr/tas=land).
    """
    os.makedirs(output_dir, exist_ok=True)
    fname = var_label.replace(" ", "_").lower()

    # 1. Deteksi Mode
    has_valid_ref = False
    if ref_da is not None:
        try:
            mean_times = mean_da.time.values.astype('datetime64[D]')
            ref_times = ref_da.time.values.astype('datetime64[D]')
            if np.intersect1d(mean_times, ref_times).size > 0:
                has_valid_ref = True
        except Exception:
            pass

    # 2. Setup Figure (3 Panel jika Validasi, 2 Panel jika Proyeksi)
    n_panels = 3 if has_valid_ref else 2
    if HAS_CARTOPY:
        fig, axes = plt.subplots(1, n_panels, figsize=(6*n_panels, 5), subplot_kw={"projection": ccrs.PlateCarree()})
    else:
        fig, axes = plt.subplots(1, n_panels, figsize=(6*n_panels, 5))
    
    if n_panels == 1: axes = [axes]
    t_idx = 0

    # 3. Masking Cerdas
    final_mask_mode = "none"
    if mask_type == "auto":
        var_lower = var_label.lower()
        if any(v in var_lower for v in ["zos", "tos", "sla", "sst"]):
            final_mask_mode = "ocean"
        elif any(v in var_lower for v in ["pr", "tas", "precip", "t2m"]):
            final_mask_mode = "land"
    else:
        final_mask_mode = mask_type

    template_mask = ref_da if ref_da is not None else mean_da
    mean = mean_da.isel(time=t_idx)
    std = std_da.isel(time=t_idx)
    
    if final_mask_mode in ["ocean", "land"]:
        mean = apply_mask(mean, template_mask, mode=final_mask_mode)
        std = apply_mask(std, template_mask, mode=final_mask_mode)

    ref = None
    if has_valid_ref:
        ref = ref_da.isel(time=t_idx)
        if final_mask_mode in ["ocean", "land"]:
            ref = apply_mask(ref, template_mask, mode=final_mask_mode)

    # 4. Skala Seragam untuk Value
    vmin_val = float(mean.min())
    vmax_val = float(mean.max())
    if has_valid_ref:
        vmin_val = min(vmin_val, float(ref.min()))
        vmax_val = max(vmax_val, float(ref.max()))

    # 🔥 5. RELATIVE UNCERTAINTY (%)
    with np.errstate(divide='ignore', invalid='ignore'):
        rel_std = (std / np.abs(mean)) * 100
        rel_std = rel_std.clip(min=0, max=100)

    # 6. PLOT PANEL
    
    # Panel 1: Mean
    im_mean = mean.plot(ax=axes[0], cmap="coolwarm", vmin=vmin_val, vmax=vmax_val, add_colorbar=False)
    if HAS_CARTOPY: axes[0].coastlines()
    axes[0].set_title(f"Mean Prediction ({mean_da.time.dt.strftime('%Y-%m').values[t_idx]})")

    if has_valid_ref:
        # Panel 2: Reference
        im_ref = ref.plot(ax=axes[1], cmap="coolwarm", vmin=vmin_val, vmax=vmax_val, add_colorbar=False)
        if HAS_CARTOPY: axes[1].coastlines()
        axes[1].set_title("Reference / Observasi")
        
        # Panel 3: Relative Uncertainty
        im_std = rel_std.plot(ax=axes[2], cmap="OrRd", vmin=0, vmax=50, add_colorbar=False) 
        if HAS_CARTOPY: axes[2].coastlines()
        axes[2].set_title("Rel. Uncertainty (%)")
    else:
        # Panel 2 (Proyeksi): Relative Uncertainty
        im_std = rel_std.plot(ax=axes[1], cmap="OrRd", vmin=0, vmax=50, add_colorbar=False)
        if HAS_CARTOPY: axes[1].coastlines()
        axes[1].set_title("Rel. Uncertainty (%)")

    # 7. COLORBAR
    # Colorbar 1: Value (Di bawah Mean & Ref)
    cbar_ax1 = fig.add_axes([0.15, 0.06, 0.30, 0.02])
    fig.colorbar(im_mean, cax=cbar_ax1, orientation="horizontal").set_label(f"{var_label} Value")

    # Colorbar 2: Uncertainty % (Di bawah Uncertainty)
    cbar_ax2 = fig.add_axes([0.65, 0.06, 0.25, 0.02])
    fig.colorbar(im_std, cax=cbar_ax2, orientation="horizontal").set_label("Uncertainty (%)")

    # Judul & Simpan
    title_suffix = " (Validated)" if has_valid_ref else " (Projection)"
    plt.suptitle(f"Uncertainty Analysis: {var_label}{title_suffix}", fontsize=14, fontweight="bold", y=1.05)
    
    suffix = "validated" if has_valid_ref else "projection"
    path = os.path.join(output_dir, f"uncertainty_{suffix}_{fname}.png")
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()
    print(f"✅ Uncertainty plot saved: {path}")

def plot_temporal_uncertainty(mean_da, lower_da, upper_da, ref_da, var_label, output_dir):
    """
    Plot evolusi temporal + 95% CI (spatial mean).
    ✅ FIX: 
    1. Reference muncul jika rentang tahun overlap (handle time_seq shift).
    2. Filename dibedakan: temporal_uncertainty_validated_{var}.png vs temporal_uncertainty_projection_{var}.png
    """
    os.makedirs(output_dir, exist_ok=True)
    fname = var_label.replace(" ", "_").lower()

    ts_mean = mean_da.mean(dim=['lat', 'lon'])
    ts_lower = lower_da.mean(dim=['lat', 'lon'])
    ts_upper = upper_da.mean(dim=['lat', 'lon'])

    plt.figure(figsize=(10, 5))
    plt.fill_between(ts_mean.time, ts_lower, ts_upper, 
                     color="orange", alpha=0.3, label="95% Confidence Interval")
    plt.plot(ts_mean.time, ts_mean, 
             color="red", linewidth=2, label="Mean Prediction")
    
    # ✅ FIX: Cek overlap berdasarkan Rentang Tahun (Year Range)
    plot_ref = False
    if ref_da is not None:
        try:
            # Ambil tahun pertama dan terakhir
            mean_start = ts_mean.time.values[0].astype('datetime64[Y]')
            mean_end = ts_mean.time.values[-1].astype('datetime64[Y]')
            ref_start = ref_da.time.values[0].astype('datetime64[Y]')
            ref_end = ref_da.time.values[-1].astype('datetime64[Y]')
            
            # Cek apakah rentang tahun beririsan
            if (mean_start <= ref_end) and (mean_end >= ref_start):
                plot_ref = True
        except Exception as e:
            print(f"⚠️ Warning checking time overlap: {e}")

    if plot_ref:
        ts_ref = ref_da.mean(dim=['lat', 'lon'])
        plt.plot(ts_ref.time, ts_ref, 
                 color="blue", linestyle="--", linewidth=1.5, label="Reference")

    plt.xlabel("Time")
    plt.ylabel(f"{var_label}")
    plt.title(f"Temporal Evolution: {var_label} (Spatial Mean)")
    plt.legend(loc='upper left')
    plt.grid(True, alpha=0.3)
    plt.tight_layout()

    # 🔥 FIX: Filename dibedakan validated vs projection
    suffix = "validated" if plot_ref else "projection"
    path = os.path.join(output_dir, f"temporal_uncertainty_{suffix}_{fname}.png")
    plt.savefig(path, dpi=300)
    plt.close()
    print(f"✅ Temporal uncertainty plot saved: {path}")