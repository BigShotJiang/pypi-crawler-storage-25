# File: src/samudra_ai/core.py
import os
import json
import joblib
import logging
import xarray as xr
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import load_model as keras_load_model,  model_from_json
from tensorflow.keras.layers import LeakyReLU
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau

from .model1 import build_cnn_bilstm, ModelConfig1
from .model2 import build_convlstm2d, ModelConfig2
from .model3 import build_unet_convlstm, ModelConfig3
from .utils import NumpyEncoder, save_to_netcdf
from .data_loader import load_and_mask_dataset
from .trainer import prepare_training_data, plot_training_history
from .evaluator import evaluate_model, plot_spatial_comparison
from .utils import add_seasonal_features, apply_log_transform, inverse_log_transform
from .utils import align_time_if_needed
from samudra_ai.utils import to_time_str

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def _compile_model_with_config(model, config, logger_instance=None):
    """
    Compile model menggunakan parameter dari config object.
    Nilai default diambil dari ModelConfig class masing-masing.
    """
    from tensorflow.keras.optimizers import Adam
    from tensorflow.keras import losses
    
    # 1. Setup Loss Function (baca dari config)
    loss_type = getattr(config, "loss_type", "huber")
    huber_delta = getattr(config, "huber_delta", 1.0)  # fallback aman
    
    if loss_type == "huber":
        loss_fn = losses.Huber(delta=huber_delta)
        log_msg = f"loss=Huber(δ={huber_delta})"
    elif loss_type == "mae":
        loss_fn = "mae"
        log_msg = "loss=MAE"
    else:  # default mse
        loss_fn = "mse"
        log_msg = "loss=MSE"
    
    # 2. Setup Optimizer + Gradient Clipping (baca dari config)
    clipnorm_val = getattr(config, "clipnorm", None)
    opt_kwargs = {"learning_rate": getattr(config, "learning_rate", 1e-3)}
    
    if clipnorm_val is not None:
        opt_kwargs["clipnorm"] = clipnorm_val
        log_msg += f", clipnorm={clipnorm_val}"
    
    optimizer = Adam(**opt_kwargs)
    
    # 3. Compile
    model.compile(optimizer=optimizer, loss=loss_fn, metrics=["mae"])
    
    if logger_instance:
        logger_instance.info(f"📦 Model compiled: {log_msg}, lr={opt_kwargs['learning_rate']}")

class SamudraAI:
    def __init__(
        self,
        time_seq: int = 9,
        lstm_units: int = 64,
        learning_rate: float = 3e-4,
        config: ModelConfig1 = None,
        use_log: bool = False,
        use_seasonal: bool = False,
        mode: str = None
    ):
        self.time_seq = time_seq
        self.lstm_units = lstm_units
        self.learning_rate = learning_rate
        self.config = config

        # =========================
        # MODE PRIORITY
        # =========================
        if mode == "hujan":
            self.use_log = True
            self.use_seasonal = True
        else:
            # backward compatibility
            self.use_log = use_log
            self.use_seasonal = use_seasonal

        self.mode = mode
        self.model = None
        self.scaler_X = None
        self.scaler_y = None
        self.history = None
        self.obs_for_metadata = None

    @staticmethod
    def _apply_scaler_safely(X, scaler):
        """
        Clean version for StandardScaler ONLY (recommended)
        """
        X_flat = X.reshape(X.shape[0], -1)
        return scaler.transform(X_flat).reshape(X.shape)
    
    def _squeeze_channel(self, da):
        if isinstance(da, xr.DataArray) and "channel" in da.dims:
            da = da.squeeze("channel", drop=True)
        return da

    def fit(self, x_data_hist: xr.DataArray, y_data_obs: xr.DataArray, epochs: int = 100, batch_size: int = 8, test_size: float = 0.2, seed: int = 42):
        logger.info("🧠 Memulai training model CNN-BiLSTM...")
        self.obs_for_metadata = y_data_obs.copy(deep=True)

        # ✅ bersihkan dari awal
        if "channel" in self.obs_for_metadata.dims:
            self.obs_for_metadata = self.obs_for_metadata.squeeze("channel", drop=True)

        # =========================
        # TIME ALIGNMENT (NEW)
        # =========================

        x_data_hist, y_data_obs = align_time_if_needed(
            x_data_hist,
            y_data_obs,
            mode=self.mode or "bulanan")

        # =========================
        # STEP 1 - AFTER SEASONAL
        # =========================
        if self.use_seasonal:
            x_data_hist = add_seasonal_features(x_data_hist)

        self.n_input_channels = x_data_hist.sizes.get("channel", 1)

        self.feature_mode = {
            "use_log": self.use_log,
            "use_seasonal": self.use_seasonal
        }

        if self.use_log:
            x_data_hist = xr.apply_ufunc(apply_log_transform, x_data_hist)
            y_data_obs = xr.apply_ufunc(apply_log_transform, y_data_obs)
        
        # =========================
        # TRAINER
        # =========================
        X_train, X_test, y_train, y_test, scaler_X, scaler_y = prepare_training_data(
            x_data_hist, y_data_obs, self.time_seq, seed, config=self.config
        )
        self.scaler_X = scaler_X
        self.scaler_y = scaler_y

        input_shape = X_train.shape[1:]
        output_shape = y_train.shape[1:3]

        # ✅ pakai config custom kalau ada, kalau tidak build default
        if self.config is None:
            self.config = ModelConfig1(rnn_units=self.lstm_units, learning_rate=self.learning_rate)

        self.model = build_cnn_bilstm(input_shape, output_shape, self.config)
        self.model.summary()

        _compile_model_with_config(self.model, self.config, logger)

        callbacks = [EarlyStopping(patience=10, restore_best_weights=True), ReduceLROnPlateau(patience=5, verbose=1)]
        self.history = self.model.fit(
            X_train, y_train, epochs=epochs, batch_size=batch_size,
            validation_data=(X_test, y_test), callbacks=callbacks, verbose=1
        )

        loss, mae = self.model.evaluate(X_test, y_test, verbose=0)
        logger.info(f"✅ Training selesai -> Final Val Loss (MSE): {loss:.4f}, Final Val MAE: {mae:.4f}")

    def correction(self, data_to_correct: xr.DataArray, save_path: str = None) -> xr.DataArray:
        if not all([self.model, self.scaler_X, self.scaler_y, self.obs_for_metadata is not None]):
            raise RuntimeError("Model belum dilatih. Jalankan .fit() terlebih dahulu.")

        logger.info(f"🔬 Mengoreksi data dengan shape: {data_to_correct.shape}...")

        # =========================
        # FIX DIM ANEH (CRITICAL)
        # =========================
        for d in data_to_correct.dims:
            if data_to_correct.sizes[d] == 1 and d != "time":
                data_to_correct = data_to_correct.squeeze(d)

        # =========================
        # 1. FEATURE ENGINEERING (CONSISTENT WITH TRAINING)
        # =========================
        if self.use_seasonal:
            data_to_correct = add_seasonal_features(data_to_correct)

        # =========================
        # 2. CONVERT TO NUMPY
        # =========================
        X_future = data_to_correct.fillna(0).values

        # SAFE DIMENSION NORMALIZATION
        if X_future.ndim == 3:
            # asumsi: (time, lat, lon)
            X_future = X_future[..., np.newaxis]

        elif X_future.ndim != 4:
            raise ValueError(f"Unexpected shape: {X_future.shape}")

        expected_channels = self.n_input_channels

        if X_future.shape[-1] != expected_channels:
            logger.warning(f"Channel mismatch: expected={expected_channels}, got={X_future.shape[-1]}")

        # =========================
        # 4. OPTIONAL LOG
        # =========================
        if self.use_log:
            X_future = apply_log_transform(X_future)

        # =========================
        # 5. SCALING
        # =========================
        X_future_scaled = self._apply_scaler_safely(X_future, self.scaler_X)

        # =========================
        # 6. BUILD SEQUENCES
        # =========================
        n_time = X_future_scaled.shape[0]

        if n_time < self.time_seq:
            raise ValueError(
                f"❌ Not enough time steps: {n_time} < {self.time_seq}"
            )
        
        if "time" not in data_to_correct.dims:
            raise ValueError("Input must contain time dimension")

        time_values = data_to_correct.time.values

        seq_indices = [
            (i, i + self.time_seq)
            for i in range(len(X_future_scaled) - self.time_seq + 1)
        ]

        X_future_seq = np.array([
            X_future_scaled[start:end]
            for start, end in seq_indices
        ])

        valid_time = np.array([
            time_values[end - 1] for _, end in seq_indices
        ])

        # =========================
        # 7. MODEL INPUT CHECK
        # =========================
        if len(valid_time) != len(X_future_seq):
            raise ValueError("Mismatch time vs sequence")

        # =========================
        # STRICT SHAPE VALIDATION (IMPORTANT)
        # =========================
        expected_channels = self.n_input_channels

        if X_future_seq.ndim not in [4, 5]:
            raise ValueError(f"Invalid ndim: {X_future_seq.shape}")

        # kalau belum ada channel dim
        if X_future_seq.ndim == 4:
            # (batch, time, lat, lon)
            X_future_seq = X_future_seq[..., np.newaxis]

        # kalau sudah 5D tapi channel mismatch
        if X_future_seq.shape[-1] != expected_channels:
            raise ValueError(
                f"Channel mismatch: expected {expected_channels}, got {X_future_seq.shape[-1]}"
            )
            
        # =========================
        # 8. PREDICT
        # =========================
        pred_scaled = self.model.predict(X_future_seq, batch_size=1)

        # =========================
        # FIX OUTPUT CHANNEL
        # =========================
        if pred_scaled.ndim == 4:
            pred_scaled = np.squeeze(pred_scaled, axis=-1)

        flat_pred = pred_scaled.reshape(pred_scaled.shape[0], -1)

        # =========================
        # 9. INVERSE SCALE
        # =========================
        pred_original = self.scaler_y.inverse_transform(flat_pred)

        # =========================
        # 10. INVERSE LOG
        # =========================
        if self.use_log:
            pred_original = inverse_log_transform(pred_original)

        # =========================
        # 11. RESHAPE OUTPUT
        # =========================
        obs_shape = self.obs_for_metadata.isel(time=0).shape

        pred_original = pred_original.reshape((pred_scaled.shape[0], *obs_shape))

        # ✅ FIX OUTPUT DIM
        if pred_original.ndim == 4 and pred_original.shape[-1] == 1:
            pred_original = np.squeeze(pred_original, axis=-1)

        # =========================
        # 12. BUILD DATAARRAY
        # =========================
        obs_mask = self.obs_for_metadata.isel(time=0).notnull()

        # ✅ FIX MASK DIM (WAJIB)
        if "channel" in obs_mask.dims:
            obs_mask = obs_mask.squeeze("channel")

        lat_dim_name = next((d for d in obs_mask.dims if 'lat' in d.lower()), 'lat')
        lon_dim_name = next((d for d in obs_mask.dims if 'lon' in d.lower()), 'lon')

        if set(obs_mask.dims) != {lat_dim_name, lon_dim_name}:
            raise ValueError(f"Unexpected mask dims: {obs_mask.dims}")

        obs_mask = obs_mask.transpose(lat_dim_name, lon_dim_name)

        predicted_da = xr.DataArray(
            pred_original,
            coords={
                "time": valid_time,
                lat_dim_name: obs_mask.coords[lat_dim_name],
                lon_dim_name: obs_mask.coords[lon_dim_name]
            },
            dims=["time", lat_dim_name, lon_dim_name],
            name="corrected"
        )

        # =========================
        # 13. MASKING
        # =========================
        predicted_masked = predicted_da.where(obs_mask, drop=False)

        # =========================
        # 14. SAVE
        # =========================
        if save_path:
            save_to_netcdf(predicted_masked, save_path)

        logger.info("✅ Koreksi selesai.")
        return predicted_masked

    def evaluate_and_plot(
        self,
        raw_gcm_data: xr.DataArray,
        ref_data: xr.DataArray,
        var_name_ref: str,
        output_dir: str = "hasil_evaluasi",
        save_corrected_path: str = None,
        mask_type: str = None):
        
        corrected_data = self.correction(raw_gcm_data)

        corrected_data = self._squeeze_channel(corrected_data)
        raw_gcm_data = self._squeeze_channel(raw_gcm_data)
        ref_data = self._squeeze_channel(ref_data)

        # Debug log hasil prediksi
        try:
            min_val = np.nanmin(corrected_data.values)
            max_val = np.nanmax(corrected_data.values)
            print(f"✅ Hasil koreksi -> min: {min_val:.4f}, max: {max_val:.4f}, shape: {corrected_data.shape}")
        except Exception as e:
            print("⚠️ Gagal menghitung min/max hasil koreksi:", e)

        if "time" in ref_data.dims:

            ref_time_str = to_time_str(ref_data.time.values, self.mode)
            corr_time_str = to_time_str(corrected_data.time.values, self.mode)
            raw_time_str = to_time_str(raw_gcm_data.time.values, self.mode)

            common = np.intersect1d(ref_time_str, corr_time_str)

            if len(common) == 0:
                raise ValueError("❌ No matching time in evaluation")

            ref_idx  = np.isin(ref_time_str, common)
            corr_idx = np.isin(corr_time_str, common)
            raw_idx  = np.isin(raw_time_str, common)

            ref_data        = ref_data.isel(time=ref_idx)
            corrected_data  = corrected_data.isel(time=corr_idx)
            raw_gcm_data    = raw_gcm_data.isel(time=raw_idx)

            # optional (pilih salah satu)
            # new_time = np.arange(len(common))
            new_time = common

            ref_data        = ref_data.assign_coords(time=new_time)
            corrected_data  = corrected_data.assign_coords(time=new_time)
            raw_gcm_data    = raw_gcm_data.assign_coords(time=new_time)

        # Simpan hasil koreksi jika diminta
        if save_corrected_path:
            save_to_netcdf(corrected_data, save_corrected_path)

        # === Plot spasial perbandingan ===
        spatial_path = plot_spatial_comparison(
            corrected_da=corrected_data,
            raw_gcm_da=raw_gcm_data,
            ref_da=ref_data,
            var_name=var_name_ref,
            output_dir=output_dir,
            units=ref_data.attrs.get("units", ""),
            mask_type=mask_type 
        )
        logger.info(f"🌍 Peta spasial disimpan ke: {spatial_path}")

        return evaluate_model(ref_data, raw_gcm_data, corrected_data, var_name_ref, output_dir)
    
    def generate_climate_analysis(self, hist_data, future_data, var_label, output_dir):
        from .climate_analysis import generate_climate_analysis

        logger.info("🌍 Menjalankan climate analysis...")

        # =========================
        # CLEAN DATA (WAJIB)
        # =========================
        hist_data = self._squeeze_channel(hist_data)
        future_data = self._squeeze_channel(future_data)

        return generate_climate_analysis(
            hist_data,
            future_data,
            var_label,
            output_dir
        )

    def plot_history(self, output_dir: str = None):
        if not self.history:
            raise ValueError("Model belum dilatih.")
        plot_training_history(self.history, output_dir)

    def predict_with_uncertainty(self, data: xr.DataArray, n_samples: int = 10,
                                batch_size: int = 4, return_bounds: bool = True):
        """
        Monte Carlo Dropout untuk estimasi uncertainty prediksi (Keras 3 Compatible).
        Return: (mean, std, lower_95, upper_95) sebagai xr.DataArray
        """
        if not self.model or not self.scaler_X or not self.scaler_y:
            raise RuntimeError("Model belum dilatih. Jalankan .fit() terlebih dahulu.")

        logger.info(f"🔮 Running Monte Carlo Dropout with {n_samples} samples...")

        # 1. Preprocessing (identik dengan correction)
        data_proc = data.copy(deep=True)
        for d in data_proc.dims:
            if data_proc.sizes[d] == 1 and d != "time":
                data_proc = data_proc.squeeze(d, drop=True)
        if self.use_seasonal:
            data_proc = add_seasonal_features(data_proc)

        X_np = np.nan_to_num(data_proc.fillna(0).values)
        if X_np.ndim == 3: X_np = X_np[..., np.newaxis]
        if self.use_log: X_np = apply_log_transform(X_np)

        X_scaled = self._apply_scaler_safely(X_np, self.scaler_X)
        if X_scaled.ndim == 3: X_scaled = X_scaled[..., np.newaxis]

        # 2. Build sequences
        n_time = X_scaled.shape[0]
        if n_time < self.time_seq:
            raise ValueError(f"Not enough time steps: {n_time} < {self.time_seq}")
        X_seq = np.stack([X_scaled[i:i+self.time_seq] for i in range(n_time - self.time_seq + 1)])
        if X_seq.ndim == 4: X_seq = X_seq[..., np.newaxis]
        valid_time = data.time.values[self.time_seq - 1:]

        # 3. MC Sampling (✅ FIX Keras 3: Direct call + training=True)
        predictions = []
        for _ in range(n_samples):
            sample_preds = []
            # Loop manual per batch untuk hemat memori & compatibility
            for i in range(0, len(X_seq), batch_size):
                batch = X_seq[i:i+batch_size]
                # ✅ Langsung panggil model, bukan .predict()
                pred_batch = self.model(batch, training=True).numpy()
                if pred_batch.ndim == 4:
                    pred_batch = np.squeeze(pred_batch, axis=-1)
                sample_preds.append(pred_batch)
            predictions.append(np.concatenate(sample_preds, axis=0))

        predictions = np.stack(predictions)  # (n_samples, n_pred, lat, lon)
        mean_scaled = np.mean(predictions, axis=0)
        std_scaled = np.std(predictions, axis=0)

        # 4. Inverse Transform (hitung bounds di scaled space dulu, baru inverse)
        lower_scaled = mean_scaled - 1.96 * std_scaled
        upper_scaled = mean_scaled + 1.96 * std_scaled

        def inv_transform(arr):
            flat = arr.reshape(arr.shape[0], -1)
            orig = self.scaler_y.inverse_transform(flat).reshape(arr.shape)
            return inverse_log_transform(orig) if self.use_log else orig

        # 5. Build xr.DataArray
        lat_name = next((d for d in self.obs_for_metadata.dims if 'lat' in d.lower()), 'lat')
        lon_name = next((d for d in self.obs_for_metadata.dims if 'lon' in d.lower()), 'lon')

        def to_xarray(arr, name):
            return xr.DataArray(
                arr, coords={"time": valid_time, lat_name: self.obs_for_metadata[lat_name],
                            lon_name: self.obs_for_metadata[lon_name]},
                dims=["time", lat_name, lon_name], name=name
            )

        mean_da = to_xarray(inv_transform(mean_scaled), "mean")
        lower_da = to_xarray(inv_transform(lower_scaled), "lower_95")
        upper_da = to_xarray(inv_transform(upper_scaled), "upper_95")
        std_da = (upper_da - lower_da) / (2 * 1.96)

        logger.info("✅ Uncertainty estimation complete.")
        return mean_da, std_da, lower_da, upper_da

    def analyze_uncertainty(self, data, var_label="variable", ref_data=None, 
                        output_dir="uncertainty", n_samples=20, batch_size=16):
        """
        All-in-one: Calculate MC Dropout uncertainty + generate plots.
        Urutan baru: data, label, ref(opsional), dir, ...
        """
        # 1. Calculate Uncertainty
        mean, std, lower, upper = self.predict_with_uncertainty(
            data, n_samples=n_samples, batch_size=batch_size
        )
        
        # 2. Generate Plots
        # ⚠️ PENTING: Pastikan nama fungsi di-import SAMA PERSIS dengan di evaluator.py
        from .evaluator import plot_uncertainty_map, plot_temporal_uncertainty
        
        # Panggil fungsi plotting (sesuaikan nama fungsi di sini)
        plot_uncertainty_map(mean, std, lower, upper, var_label, output_dir, ref_da=ref_data)
        plot_temporal_uncertainty(mean, lower, upper, ref_data, var_label, output_dir)
        
        logger.info(f"✅ Uncertainty analysis complete for {var_label}.")
        return mean, std, lower, upper

    def save(self, path: str):
        logger.info(f"💾 Menyimpan model ke direktori: {path}...")
        os.makedirs(path, exist_ok=True)

        # Simpan model dan scaler
        self.model.save(os.path.join(path, "model.keras"))
        joblib.dump(self.scaler_X, os.path.join(path, "scaler_X.gz"))
        joblib.dump(self.scaler_y, os.path.join(path, "scaler_y.gz"))

        # Simpan metadata observasi dengan backend yang lebih stabil
        try:
            self.obs_for_metadata.to_netcdf(
                os.path.join(path, "obs_metadata.nc"),
                engine="h5netcdf"
            )
        except Exception as e:
            logger.warning(f"❗ Gagal menyimpan obs_metadata.nc: {e}")

        # Simpan konfigurasi model
        config = {
            'time_seq': self.time_seq,
            'lstm_units': self.lstm_units,
            'learning_rate': self.learning_rate,
            'use_log': self.use_log,
            'use_seasonal': self.use_seasonal,
            'mode': self.mode,
            'n_input_channels': self.n_input_channels
        }

        with open(os.path.join(path, "config.json"), 'w') as f:
            json.dump(config, f, cls=NumpyEncoder)

        logger.info(f"✅ Model dan komponen berhasil disimpan.")

    @classmethod
    def load(cls, path: str):
        logger.info(f"🔄 Memuat model dari direktori: {path}...")
        required_files = ["config.json", "model.keras", "scaler_X.gz", "scaler_y.gz", "obs_metadata.nc"]
        for fname in required_files:
            full_path = os.path.join(path, fname)
            if not os.path.exists(full_path):
                raise FileNotFoundError(f"File tidak ditemukan: {full_path}")

        with open(os.path.join(path, "config.json"), 'r') as f:
            config = json.load(f)
        instance = cls(
            time_seq=config.get("time_seq", 9),
            lstm_units=config.get("lstm_units", 64),
            learning_rate=config.get("learning_rate", 3e-4),
            use_log=config.get("use_log", False),
            use_seasonal=config.get("use_seasonal", False),
            mode=config.get("mode", None)
        )
        # Inisialisasi atribut tambahan
        instance.n_input_channels = config.get("n_input_channels", None)  # Tambahkan ini

        instance.model = keras_load_model(
            os.path.join(path, "model.keras"),
            custom_objects={"LeakyReLU": LeakyReLU},
            compile=False)
        instance.scaler_X = joblib.load(os.path.join(path, "scaler_X.gz"))
        instance.scaler_y = joblib.load(os.path.join(path, "scaler_y.gz"))
        instance.obs_for_metadata = xr.open_dataarray(os.path.join(path, "obs_metadata.nc"))

        # Compile
        _compile_model_with_config(instance.model, instance.config, logger)

        logger.info(f"✅ Model dan komponen berhasil dimuat.")
        return instance
    
class SamudraAI2:
    def __init__(self, time_seq: int = 9, config: ModelConfig2 = None,
                 use_log: bool = False, use_seasonal: bool = False, mode: str = None):
        self.time_seq = time_seq
        self.config = config
        self.use_log = use_log
        # =========================
        # MODE PRIORITY
        # =========================
        if mode == "hujan":
            self.use_log = True
            self.use_seasonal = True
        else:
            # backward compatibility
            self.use_log = use_log
            self.use_seasonal = use_seasonal
        self.mode = mode
        self.model = None
        self.scaler_X = None
        self.scaler_y = None
        self.history = None
        self.obs_for_metadata = None

    @staticmethod
    def _apply_scaler_safely(X, scaler):
        """
        Clean version for StandardScaler ONLY (recommended)
        """
        X_flat = X.reshape(X.shape[0], -1)
        return scaler.transform(X_flat).reshape(X.shape)
    
    def _squeeze_channel(self, da):
        if isinstance(da, xr.DataArray) and "channel" in da.dims:
            da = da.squeeze("channel", drop=True)
        return da

    def fit(self, x_data_hist, y_data_obs, epochs: int = None, batch_size: int = None, test_size: float = 0.2, seed: int = 42):
        logger.info("🧠 Memulai training model ConvLSTM2D...")
        self.obs_for_metadata = y_data_obs.copy(deep=True)

        # ✅ bersihkan dari awal
        if "channel" in self.obs_for_metadata.dims:
            self.obs_for_metadata = self.obs_for_metadata.squeeze("channel", drop=True)

        # =========================
        # TIME ALIGNMENT (NEW)
        # =========================
        x_data_hist, y_data_obs = align_time_if_needed(
            x_data_hist,
            y_data_obs,
            mode=self.mode or "bulanan")

        # =========================
        # STEP 1 - AFTER SEASONAL
        # =========================
        if self.use_seasonal:
            x_data_hist = add_seasonal_features(x_data_hist)

        self.n_input_channels = x_data_hist.sizes.get("channel", 1)

        self.feature_mode = {
            "use_log": self.use_log,
            "use_seasonal": self.use_seasonal
        }

        if self.use_log:
            x_data_hist = xr.apply_ufunc(apply_log_transform, x_data_hist)
            y_data_obs = xr.apply_ufunc(apply_log_transform, y_data_obs)

        # =========================
        # TRAINER
        # =========================
        X_train, X_test, y_train, y_test, scaler_X, scaler_y = prepare_training_data(
            x_data_hist, y_data_obs, self.time_seq, seed, config=self.config
        )
        self.scaler_X, self.scaler_y = scaler_X, scaler_y

        input_shape = X_train.shape[1:]    # (time_seq, lat, lon, 1)
        output_shape = y_train.shape[1:3]  # (lat, lon)

        if self.config is None:
            self.config = ModelConfig2()

        self.model = build_convlstm2d(input_shape, output_shape, self.config)
        self.model.summary()

        _compile_model_with_config(self.model, self.config, logger)

        callbacks = [EarlyStopping(patience=10, restore_best_weights=True), ReduceLROnPlateau(patience=5, verbose=1)]
        self.history = self.model.fit(
            X_train, y_train,
            epochs=epochs or self.config.epochs,
            batch_size=batch_size or self.config.batch_size,
            validation_data=(X_test, y_test),
            callbacks=callbacks, verbose=1
        )

    def correction(self, data_to_correct: xr.DataArray, save_path: str = None) -> xr.DataArray:
        if not all([self.model, self.scaler_X, self.scaler_y, self.obs_for_metadata is not None]):
            raise RuntimeError("Model belum dilatih. Jalankan .fit() terlebih dahulu.")

        logger.info(f"🔬 Mengoreksi data dengan shape: {data_to_correct.shape}...")

        # =========================
        # FIX DIM ANEH (CRITICAL)
        # =========================
        for d in data_to_correct.dims:
            if data_to_correct.sizes[d] == 1 and d != "time":
                data_to_correct = data_to_correct.squeeze(d)

        # =========================
        # 1. FEATURE ENGINEERING (CONSISTENT WITH TRAINING)
        # =========================
        if self.use_seasonal:
            data_to_correct = add_seasonal_features(data_to_correct)

        # =========================
        # 2. CONVERT TO NUMPY
        # =========================
        X_future = data_to_correct.fillna(0).values

        if X_future.ndim == 3:
            X_future = X_future[..., np.newaxis]
        elif X_future.ndim != 4:
            raise ValueError(f"Unexpected shape: {X_future.shape}")

        expected_channels = self.n_input_channels

        if X_future.shape[-1] != expected_channels:
            raise ValueError(
                f"Channel mismatch! expected={expected_channels}, got={X_future.shape[-1]}"
            )

        # =========================
        # 4. OPTIONAL LOG
        # =========================
        if self.use_log:
            X_future = apply_log_transform(X_future)

        # =========================
        # 5. SCALING
        # =========================
        X_future_scaled = self._apply_scaler_safely(X_future, self.scaler_X)

        # ✅ FIX INI DI SINI
        if X_future_scaled.ndim == 3:
            X_future_scaled = X_future_scaled[..., np.newaxis]

        # =========================
        # 6. VALIDASI DASAR
        # =========================
        if "time" not in data_to_correct.dims:
            raise ValueError("Input must contain time dimension")

        n_time = X_future_scaled.shape[0]

        if n_time < self.time_seq:
            raise ValueError(
                f"❌ Not enough time steps: {n_time} < {self.time_seq}"
            )

        time_values = data_to_correct.time.values

        # =========================
        # 7. BUILD SEQUENCE WINDOW
        # =========================

        X_future_seq = np.stack([
            X_future_scaled[i:i + self.time_seq]
            for i in range(n_time - self.time_seq + 1)
        ])

        valid_time = time_values[self.time_seq - 1:]

        # =========================
        # FORCE 5D SAFETY (CRITICAL FOR CONVLSTM2D)
        # =========================
        if X_future_seq.ndim == 4:
            X_future_seq = X_future_seq[..., np.newaxis]

        # =========================
        # 9. CHANNEL SAFETY CHECK (IMPORTANT)
        # =========================
        expected_channels = self.n_input_channels

        if X_future_seq.shape[-1] != expected_channels:
            raise ValueError(
                f"Channel mismatch: expected={expected_channels}, "
                f"got={X_future_seq.shape[-1]}"
            )
            
        # =========================
        # 10. FINAL DEBUG
        # =========================
        print("🧪 ConvLSTM2D input shape:", X_future_seq.shape)

        # =========================
        # 8. PREDICT
        # =========================
        pred_scaled = self.model.predict(X_future_seq, batch_size=1)

        # =========================
        # FIX OUTPUT CHANNEL
        # =========================
        if pred_scaled.ndim == 4:
            pred_scaled = np.squeeze(pred_scaled, axis=-1)

        flat_pred = pred_scaled.reshape(pred_scaled.shape[0], -1)

        # =========================
        # 9. INVERSE SCALE
        # =========================
        pred_original = self.scaler_y.inverse_transform(flat_pred)

        # =========================
        # 10. INVERSE LOG
        # =========================
        if self.use_log:
            pred_original = inverse_log_transform(pred_original)

        # =========================
        # 11. RESHAPE OUTPUT
        # =========================
        obs_shape = self.obs_for_metadata.isel(time=0).shape

        pred_original = pred_original.reshape((pred_scaled.shape[0], *obs_shape))

        # ✅ FIX OUTPUT DIM
        if pred_original.ndim == 4 and pred_original.shape[-1] == 1:
            pred_original = np.squeeze(pred_original, axis=-1)

        # =========================
        # 12. BUILD DATAARRAY
        # =========================
        obs_mask = self.obs_for_metadata.isel(time=0).notnull()

        # ✅ FIX MASK DIM (WAJIB)
        if "channel" in obs_mask.dims:
            obs_mask = obs_mask.squeeze("channel")

        lat_dim_name = next((d for d in obs_mask.dims if 'lat' in d.lower()), 'lat')
        lon_dim_name = next((d for d in obs_mask.dims if 'lon' in d.lower()), 'lon')

        if set(obs_mask.dims) != {lat_dim_name, lon_dim_name}:
            raise ValueError(f"Unexpected mask dims: {obs_mask.dims}")

        obs_mask = obs_mask.transpose(lat_dim_name, lon_dim_name)

        predicted_da = xr.DataArray(
            pred_original,
            coords={
                "time": valid_time,
                lat_dim_name: obs_mask.coords[lat_dim_name],
                lon_dim_name: obs_mask.coords[lon_dim_name]
            },
            dims=["time", lat_dim_name, lon_dim_name],
            name="corrected"
        )

        # =========================
        # 13. MASKING
        # =========================
        predicted_masked = predicted_da.where(obs_mask, drop=False)

        # =========================
        # 14. SAVE
        # =========================
        if save_path:
            save_to_netcdf(predicted_masked, save_path)

        logger.info("✅ Koreksi selesai.")
        return predicted_masked

    def evaluate_and_plot(
        self,
        raw_gcm_data: xr.DataArray,
        ref_data: xr.DataArray,
        var_name_ref: str,
        output_dir: str = "hasil_evaluasi",
        save_corrected_path: str = None,
        mask_type: str = None):

        logger.info("📊 Evaluasi model dengan data referensi...")
        
        corrected_data = self.correction(raw_gcm_data)

        corrected_data = self._squeeze_channel(corrected_data)
        raw_gcm_data = self._squeeze_channel(raw_gcm_data)
        ref_data = self._squeeze_channel(ref_data)

        # Debug log hasil prediksi
        try:
            min_val = np.nanmin(corrected_data.values)
            max_val = np.nanmax(corrected_data.values)
            print(f"✅ Hasil koreksi -> min: {min_val:.4f}, max: {max_val:.4f}, shape: {corrected_data.shape}")
        except Exception as e:
            print("⚠️ Gagal menghitung min/max hasil koreksi:", e)

        if "time" in ref_data.dims:

            ref_time_str = to_time_str(ref_data.time.values, self.mode)
            corr_time_str = to_time_str(corrected_data.time.values, self.mode)
            raw_time_str = to_time_str(raw_gcm_data.time.values, self.mode)

            common = np.intersect1d(ref_time_str, corr_time_str)

            if len(common) == 0:
                raise ValueError("❌ No matching time in evaluation")

            ref_idx  = np.isin(ref_time_str, common)
            corr_idx = np.isin(corr_time_str, common)
            raw_idx  = np.isin(raw_time_str, common)

            ref_data        = ref_data.isel(time=ref_idx)
            corrected_data  = corrected_data.isel(time=corr_idx)
            raw_gcm_data    = raw_gcm_data.isel(time=raw_idx)

            # optional (pilih salah satu)
            # new_time = np.arange(len(common))
            new_time = common

            ref_data        = ref_data.assign_coords(time=new_time)
            corrected_data  = corrected_data.assign_coords(time=new_time)
            raw_gcm_data    = raw_gcm_data.assign_coords(time=new_time)

        # Simpan hasil koreksi jika diminta
        if save_corrected_path:
            save_to_netcdf(corrected_data, save_corrected_path)

        # === Plot spasial perbandingan ===
        spatial_path = plot_spatial_comparison(
            corrected_da=corrected_data,
            raw_gcm_da=raw_gcm_data,
            ref_da=ref_data,
            var_name=var_name_ref,
            output_dir=output_dir,
            units=ref_data.attrs.get("units", ""),
            mask_type=mask_type 
        )
        logger.info(f"🌍 Peta spasial disimpan ke: {spatial_path}")

        return evaluate_model(ref_data, raw_gcm_data, corrected_data, var_name_ref, output_dir)
    
    def generate_climate_analysis(self, hist_data, future_data, var_label, output_dir):
        from .climate_analysis import generate_climate_analysis

        logger.info("🌍 Menjalankan climate analysis...")

        # =========================
        # CLEAN DATA (WAJIB)
        # =========================
        hist_data = self._squeeze_channel(hist_data)
        future_data = self._squeeze_channel(future_data)

        return generate_climate_analysis(
            hist_data,
            future_data,
            var_label,
            output_dir
        )

    def plot_history(self, output_dir: str = None):
        if not self.history:
            raise ValueError("Model belum dilatih.")
        plot_training_history(self.history, output_dir)

    def predict_with_uncertainty(self, data: xr.DataArray, n_samples: int = 10,
                                batch_size: int = 4, return_bounds: bool = True):
        """
        Monte Carlo Dropout untuk estimasi uncertainty prediksi (Keras 3 Compatible).
        Return: (mean, std, lower_95, upper_95) sebagai xr.DataArray
        """
        if not self.model or not self.scaler_X or not self.scaler_y:
            raise RuntimeError("Model belum dilatih. Jalankan .fit() terlebih dahulu.")

        logger.info(f"🔮 Running Monte Carlo Dropout with {n_samples} samples...")

        # 1. Preprocessing (identik dengan correction)
        data_proc = data.copy(deep=True)
        for d in data_proc.dims:
            if data_proc.sizes[d] == 1 and d != "time":
                data_proc = data_proc.squeeze(d, drop=True)
        if self.use_seasonal:
            data_proc = add_seasonal_features(data_proc)

        X_np = np.nan_to_num(data_proc.fillna(0).values)
        if X_np.ndim == 3: X_np = X_np[..., np.newaxis]
        if self.use_log: X_np = apply_log_transform(X_np)

        X_scaled = self._apply_scaler_safely(X_np, self.scaler_X)
        if X_scaled.ndim == 3: X_scaled = X_scaled[..., np.newaxis]

        # 2. Build sequences
        n_time = X_scaled.shape[0]
        if n_time < self.time_seq:
            raise ValueError(f"Not enough time steps: {n_time} < {self.time_seq}")
        X_seq = np.stack([X_scaled[i:i+self.time_seq] for i in range(n_time - self.time_seq + 1)])
        if X_seq.ndim == 4: X_seq = X_seq[..., np.newaxis]
        valid_time = data.time.values[self.time_seq - 1:]

        # 3. MC Sampling (✅ FIX Keras 3: Direct call + training=True)
        predictions = []
        for _ in range(n_samples):
            sample_preds = []
            # Loop manual per batch untuk hemat memori & compatibility
            for i in range(0, len(X_seq), batch_size):
                batch = X_seq[i:i+batch_size]
                # ✅ Langsung panggil model, bukan .predict()
                pred_batch = self.model(batch, training=True).numpy()
                if pred_batch.ndim == 4:
                    pred_batch = np.squeeze(pred_batch, axis=-1)
                sample_preds.append(pred_batch)
            predictions.append(np.concatenate(sample_preds, axis=0))

        predictions = np.stack(predictions)  # (n_samples, n_pred, lat, lon)
        mean_scaled = np.mean(predictions, axis=0)
        std_scaled = np.std(predictions, axis=0)

        # 4. Inverse Transform (hitung bounds di scaled space dulu, baru inverse)
        lower_scaled = mean_scaled - 1.96 * std_scaled
        upper_scaled = mean_scaled + 1.96 * std_scaled

        def inv_transform(arr):
            flat = arr.reshape(arr.shape[0], -1)
            orig = self.scaler_y.inverse_transform(flat).reshape(arr.shape)
            return inverse_log_transform(orig) if self.use_log else orig

        # 5. Build xr.DataArray
        lat_name = next((d for d in self.obs_for_metadata.dims if 'lat' in d.lower()), 'lat')
        lon_name = next((d for d in self.obs_for_metadata.dims if 'lon' in d.lower()), 'lon')

        def to_xarray(arr, name):
            return xr.DataArray(
                arr, coords={"time": valid_time, lat_name: self.obs_for_metadata[lat_name],
                            lon_name: self.obs_for_metadata[lon_name]},
                dims=["time", lat_name, lon_name], name=name
            )

        mean_da = to_xarray(inv_transform(mean_scaled), "mean")
        lower_da = to_xarray(inv_transform(lower_scaled), "lower_95")
        upper_da = to_xarray(inv_transform(upper_scaled), "upper_95")
        std_da = (upper_da - lower_da) / (2 * 1.96)

        logger.info("✅ Uncertainty estimation complete.")
        return mean_da, std_da, lower_da, upper_da
    
    def analyze_uncertainty(self, data, var_label="variable", ref_data=None, 
                        output_dir="uncertainty", n_samples=20, batch_size=16):
        """
        All-in-one: Calculate MC Dropout uncertainty + generate plots.
        Urutan baru: data, label, ref(opsional), dir, ...
        """
        # 1. Calculate Uncertainty
        mean, std, lower, upper = self.predict_with_uncertainty(
            data, n_samples=n_samples, batch_size=batch_size
        )
        
        # 2. Generate Plots
        # ⚠️ PENTING: Pastikan nama fungsi di-import SAMA PERSIS dengan di evaluator.py
        from .evaluator import plot_uncertainty_map, plot_temporal_uncertainty
        
        # Panggil fungsi plotting (sesuaikan nama fungsi di sini)
        plot_uncertainty_map(mean, std, lower, upper, var_label, output_dir, ref_da=ref_data)
        plot_temporal_uncertainty(mean, lower, upper, ref_data, var_label, output_dir)
        
        logger.info(f"✅ Uncertainty analysis complete for {var_label}.")
        return mean, std, lower, upper

    def save(self, path: str):
        logger.info(f"💾 Menyimpan model ke direktori: {path}...")
        os.makedirs(path, exist_ok=True)

        # Simpan model dan scaler
        self.model.save(os.path.join(path, "model2.keras"))
        joblib.dump(self.scaler_X, os.path.join(path, "scaler_X2.gz"))
        joblib.dump(self.scaler_y, os.path.join(path, "scaler_y2.gz"))

        # Simpan metadata observasi dengan backend yang lebih stabil
        try:
            self.obs_for_metadata.to_netcdf(
                os.path.join(path, "obs_metadata2.nc"),
                engine="h5netcdf"
            )
        except Exception as e:
            logger.warning(f"❗ Gagal menyimpan obs_metadata.nc: {e}")

        # Simpan konfigurasi model
        config = {
            "time_seq": self.time_seq,
            "use_log": self.use_log,
            'use_seasonal': self.use_seasonal,
            'mode': self.mode,
            "model_config": self.config.__dict__,
            "n_input_channels": self.n_input_channels
        }
        with open(os.path.join(path, "config2.json"), 'w') as f:
            json.dump(config, f, cls=NumpyEncoder)

        logger.info(f"✅ Model dan komponen berhasil disimpan.")

    @classmethod
    def load(cls, path: str):
        logger.info(f"🔄 Memuat model dari direktori: {path}...")

        # =====================================
        # Validate required files
        # =====================================
        required_files = [
            "config2.json",
            "model2.keras",
            "scaler_X2.gz",
            "scaler_y2.gz",
            "obs_metadata2.nc"
        ]

        for fname in required_files:
            full_path = os.path.join(path, fname)
            if not os.path.exists(full_path):
                raise FileNotFoundError(f"❌ File tidak ditemukan: {full_path}")

        # =====================================
        # Load config
        # =====================================
        with open(os.path.join(path, "config2.json"), "r") as f:
            config = json.load(f)

        # SamudraAI2 hanya butuh time_seq & config ModelConfig2
        cfg = ModelConfig2(**config["model_config"])
        instance = cls(
            time_seq=config["time_seq"],
            config=cfg,
            use_log=config.get("use_log", False),
            use_seasonal=config.get("use_seasonal", False),
            mode=config.get("mode", None)
        )

        # Inisialisasi atribut tambahan
        instance.n_input_channels = config.get("n_input_channels", None)  # Tambahkan ini

        # =====================================
        # Load model
        # =====================================
        model_path = os.path.join(path, "model2.keras")

        instance.model = keras_load_model(
            model_path,
            custom_objects={"LeakyReLU": LeakyReLU},
            compile=False
        )

        # =====================================
        # Load scalers
        # =====================================
        instance.scaler_X = joblib.load(os.path.join(path, "scaler_X2.gz"))
        instance.scaler_y = joblib.load(os.path.join(path, "scaler_y2.gz"))

        # =====================================
        # Load metadata
        # =====================================
        instance.obs_for_metadata = xr.open_dataarray(
            os.path.join(path, "obs_metadata2.nc"))

        # Compile
        _compile_model_with_config(instance.model, instance.config, logger)

        logger.info("✅ Model CONVLSTM2D dan komponen berhasil dimuat.")
        return instance
    
class SamudraAI3:
    """SamudraAI3: U-Net + ConvLSTM untuk Spatio-Temporal Forecasting"""
    def __init__(self, time_seq: int = 12, config: ModelConfig3 = None,
                 use_log: bool = False, use_seasonal: bool = False, mode: str = None):
        self.time_seq = time_seq
        self.config = config
        # =========================
        # MODE PRIORITY (SAMA PERSIS DENGAN SamudraAI2)
        # =========================
        if mode == "hujan":
            self.use_log = True
            self.use_seasonal = True
        else:
            self.use_log = use_log
            self.use_seasonal = use_seasonal
        self.mode = mode
        self.model = None
        self.scaler_X = None
        self.scaler_y = None
        self.history = None
        self.obs_for_metadata = None
        self.n_input_channels = None
        self.feature_mode = None

    @staticmethod
    def _apply_scaler_safely(X, scaler):
        """Clean version for StandardScaler ONLY (reuse dari SamudraAI2)"""
        X_flat = X.reshape(X.shape[0], -1)
        return scaler.transform(X_flat).reshape(X.shape)
    
    def _squeeze_channel(self, da):
        """Hapus dimensi channel jika ada (reuse dari SamudraAI2)"""
        if isinstance(da, xr.DataArray) and "channel" in da.dims:
            da = da.squeeze("channel", drop=True)
        return da
    
    def fit(self, x_data_hist, y_data_obs, epochs: int = None, batch_size: int = None, 
            test_size: float = 0.2, seed: int = 42):
        logger.info("🧠 Memulai training model U-Net + ConvLSTM...")
        self.obs_for_metadata = y_data_obs.copy(deep=True)

        # ✅ bersihkan channel dari awal
        if "channel" in self.obs_for_metadata.dims:
            self.obs_for_metadata = self.obs_for_metadata.squeeze("channel", drop=True)

        # =========================
        # TIME ALIGNMENT (REUSE DARI SamudraAI2)
        # =========================
        x_data_hist, y_data_obs = align_time_if_needed(
            x_data_hist, y_data_obs, mode=self.mode or "bulanan")

        # =========================
        # FEATURE ENGINEERING (REUSE)
        # =========================
        if self.use_seasonal:
            x_data_hist = add_seasonal_features(x_data_hist)

        self.n_input_channels = x_data_hist.sizes.get("channel", 1)
        self.feature_mode = {"use_log": self.use_log, "use_seasonal": self.use_seasonal}

        if self.use_log:
            x_data_hist = xr.apply_ufunc(apply_log_transform, x_data_hist)
            y_data_obs = xr.apply_ufunc(apply_log_transform, y_data_obs)

        # =========================
        # PREPARE TRAINING DATA (REUSE prepare_training_data)
        # =========================
        X_train, X_test, y_train, y_test, scaler_X, scaler_y = prepare_training_data(
            x_data_hist, y_data_obs, self.time_seq, seed, config=self.config
        )
        self.scaler_X, self.scaler_y = scaler_X, scaler_y

        # =========================
        # BUILD MODEL
        # =========================
        input_shape = X_train.shape[1:]    # (time_seq, lat, lon, C)
        output_shape = y_train.shape[1:3]  # (lat, lon)

        if self.config is None:
            self.config = ModelConfig3()

        self.model = build_unet_convlstm(input_shape, output_shape, self.config)
        self.model.summary()

        _compile_model_with_config(self.model, self.config, logger)

        # =========================
        # TRAIN
        # =========================
        callbacks = [
            EarlyStopping(patience=10, restore_best_weights=True), 
            ReduceLROnPlateau(patience=5, verbose=1)
        ]
        self.history = self.model.fit(
            X_train, y_train,
            epochs=epochs or self.config.epochs,
            batch_size=batch_size or self.config.batch_size,
            validation_data=(X_test, y_test),
            callbacks=callbacks, 
            verbose=1
        )
        return self.history
    
    def correction(self, data_to_correct: xr.DataArray, save_path: str = None) -> xr.DataArray:
        if not all([self.model, self.scaler_X, self.scaler_y, self.obs_for_metadata is not None]):
            raise RuntimeError("Model belum dilatih. Jalankan .fit() terlebih dahulu.")

        logger.info(f"🔬 Mengoreksi data dengan shape: {data_to_correct.shape}...")

        # =========================
        # FIX DIM ANEH (CRITICAL - REUSE)
        # =========================
        for d in data_to_correct.dims:
            if data_to_correct.sizes[d] == 1 and d != "time":
                data_to_correct = data_to_correct.squeeze(d)

        # =========================
        # 1. FEATURE ENGINEERING (CONSISTENT WITH TRAINING)
        # =========================
        if self.use_seasonal:
            data_to_correct = add_seasonal_features(data_to_correct)

        # =========================
        # 2. CONVERT TO NUMPY
        # =========================
        X_future = data_to_correct.fillna(0).values

        if X_future.ndim == 3:
            X_future = X_future[..., np.newaxis]
        elif X_future.ndim != 4:
            raise ValueError(f"Unexpected shape: {X_future.shape}")

        expected_channels = self.n_input_channels
        if X_future.shape[-1] != expected_channels:
            raise ValueError(
                f"Channel mismatch! expected={expected_channels}, got={X_future.shape[-1]}"
            )

        # =========================
        # 3. OPTIONAL LOG TRANSFORM
        # =========================
        if self.use_log:
            X_future = apply_log_transform(X_future)

        # =========================
        # 4. SCALING
        # =========================
        X_future_scaled = self._apply_scaler_safely(X_future, self.scaler_X)

        # ✅ FIX INI DI SINI (sama dengan SamudraAI2)
        if X_future_scaled.ndim == 3:
            X_future_scaled = X_future_scaled[..., np.newaxis]

        # =========================
        # 5. VALIDASI DASAR
        # =========================
        if "time" not in data_to_correct.dims:
            raise ValueError("Input must contain time dimension")

        n_time = X_future_scaled.shape[0]
        if n_time < self.time_seq:
            raise ValueError(f"❌ Not enough time steps: {n_time} < {self.time_seq}")

        time_values = data_to_correct.time.values

        # =========================
        # 6. BUILD SEQUENCE WINDOW
        # =========================
        X_future_seq = np.stack([
            X_future_scaled[i:i + self.time_seq]
            for i in range(n_time - self.time_seq + 1)
        ])
        valid_time = time_values[self.time_seq - 1:]

        # =========================
        # FORCE 5D SAFETY (CRITICAL FOR ConvLSTM/U-Net)
        # =========================
        if X_future_seq.ndim == 4:
            X_future_seq = X_future_seq[..., np.newaxis]

        # =========================
        # CHANNEL SAFETY CHECK
        # =========================
        if X_future_seq.shape[-1] != expected_channels:
            raise ValueError(
                f"Channel mismatch: expected={expected_channels}, got={X_future_seq.shape[-1]}"
            )
            
        print("🧪 U-Net+ConvLSTM input shape:", X_future_seq.shape)

        # =========================
        # 7. PREDICT
        # =========================
        pred_scaled = self.model.predict(X_future_seq, batch_size=1)

        # =========================
        # FIX OUTPUT CHANNEL
        # =========================
        if pred_scaled.ndim == 4:
            pred_scaled = np.squeeze(pred_scaled, axis=-1)

        flat_pred = pred_scaled.reshape(pred_scaled.shape[0], -1)

        # =========================
        # 8. INVERSE SCALE
        # =========================
        pred_original = self.scaler_y.inverse_transform(flat_pred)

        # =========================
        # 9. INVERSE LOG
        # =========================
        if self.use_log:
            pred_original = inverse_log_transform(pred_original)

        # =========================
        # 10. RESHAPE OUTPUT
        # =========================
        obs_shape = self.obs_for_metadata.isel(time=0).shape
        pred_original = pred_original.reshape((pred_scaled.shape[0], *obs_shape))

        if pred_original.ndim == 4 and pred_original.shape[-1] == 1:
            pred_original = np.squeeze(pred_original, axis=-1)

        # =========================
        # 11. BUILD DATAARRAY (SAMA PERSIS DENGAN SamudraAI2)
        # =========================
        obs_mask = self.obs_for_metadata.isel(time=0).notnull()

        if "channel" in obs_mask.dims:
            obs_mask = obs_mask.squeeze("channel")

        lat_dim_name = next((d for d in obs_mask.dims if 'lat' in d.lower()), 'lat')
        lon_dim_name = next((d for d in obs_mask.dims if 'lon' in d.lower()), 'lon')

        if set(obs_mask.dims) != {lat_dim_name, lon_dim_name}:
            raise ValueError(f"Unexpected mask dims: {obs_mask.dims}")

        obs_mask = obs_mask.transpose(lat_dim_name, lon_dim_name)

        predicted_da = xr.DataArray(
            pred_original,
            coords={
                "time": valid_time,
                lat_dim_name: obs_mask.coords[lat_dim_name],
                lon_dim_name: obs_mask.coords[lon_dim_name]
            },
            dims=["time", lat_dim_name, lon_dim_name],
            name="corrected"
        )

        # =========================
        # 12. MASKING
        # =========================
        predicted_masked = predicted_da.where(obs_mask, drop=False)

        # =========================
        # 13. SAVE
        # =========================
        if save_path:
            save_to_netcdf(predicted_masked, save_path)

        logger.info("✅ Koreksi selesai.")
        return predicted_masked
    
    def evaluate_and_plot(
        self, raw_gcm_data: xr.DataArray, ref_data: xr.DataArray,
        var_name_ref: str, output_dir: str = "hasil_evaluasi",
        save_corrected_path: str = None, mask_type: str = None):

        logger.info("📊 Evaluasi model dengan data referensi...")
        
        corrected_data = self.correction(raw_gcm_data)
        corrected_data = self._squeeze_channel(corrected_data)
        raw_gcm_data = self._squeeze_channel(raw_gcm_data)
        ref_data = self._squeeze_channel(ref_data)

        # Debug log
        try:
            min_val = np.nanmin(corrected_data.values)
            max_val = np.nanmax(corrected_data.values)
            print(f"✅ Hasil koreksi -> min: {min_val:.4f}, max: {max_val:.4f}, shape: {corrected_data.shape}")
        except Exception as e:
            print("⚠️ Gagal menghitung min/max hasil koreksi:", e)

        # Time alignment (reuse logic SamudraAI2)
        if "time" in ref_data.dims:
            ref_time_str = to_time_str(ref_data.time.values, self.mode)
            corr_time_str = to_time_str(corrected_data.time.values, self.mode)
            raw_time_str = to_time_str(raw_gcm_data.time.values, self.mode)

            common = np.intersect1d(ref_time_str, corr_time_str)
            if len(common) == 0:
                raise ValueError("❌ No matching time in evaluation")

            ref_idx  = np.isin(ref_time_str, common)
            corr_idx = np.isin(corr_time_str, common)
            raw_idx  = np.isin(raw_time_str, common)

            ref_data = ref_data.isel(time=ref_idx)
            corrected_data = corrected_data.isel(time=corr_idx)
            raw_gcm_data = raw_gcm_data.isel(time=raw_idx)

            new_time = common
            ref_data = ref_data.assign_coords(time=new_time)
            corrected_data = corrected_data.assign_coords(time=new_time)
            raw_gcm_data = raw_gcm_data.assign_coords(time=new_time)

        if save_corrected_path:
            save_to_netcdf(corrected_data, save_corrected_path)

        # Plot & evaluate (reuse functions)
        spatial_path = plot_spatial_comparison(
            corrected_da=corrected_data, raw_gcm_da=raw_gcm_data, ref_da=ref_data,
            var_name=var_name_ref, output_dir=output_dir,
            units=ref_data.attrs.get("units", ""), mask_type=mask_type
        )
        logger.info(f"🌍 Peta spasial disimpan ke: {spatial_path}")

        return evaluate_model(ref_data, raw_gcm_data, corrected_data, var_name_ref, output_dir)

    def generate_climate_analysis(self, hist_data, future_data, var_label, output_dir):
        from .climate_analysis import generate_climate_analysis
        logger.info("🌍 Menjalankan climate analysis...")
        hist_data = self._squeeze_channel(hist_data)
        future_data = self._squeeze_channel(future_data)
        return generate_climate_analysis(hist_data, future_data, var_label, output_dir)

    def plot_history(self, output_dir: str = None):
        if not self.history:
            raise ValueError("Model belum dilatih.")
        plot_training_history(self.history, output_dir)

    def predict_with_uncertainty(self, data: xr.DataArray, n_samples: int = 10,
                                batch_size: int = 4, return_bounds: bool = True):
        """
        Monte Carlo Dropout untuk estimasi uncertainty prediksi (Keras 3 Compatible).
        Return: (mean, std, lower_95, upper_95) sebagai xr.DataArray
        """
        if not self.model or not self.scaler_X or not self.scaler_y:
            raise RuntimeError("Model belum dilatih. Jalankan .fit() terlebih dahulu.")

        logger.info(f"🔮 Running Monte Carlo Dropout with {n_samples} samples...")

        # 1. Preprocessing (identik dengan correction)
        data_proc = data.copy(deep=True)
        for d in data_proc.dims:
            if data_proc.sizes[d] == 1 and d != "time":
                data_proc = data_proc.squeeze(d, drop=True)
        if self.use_seasonal:
            data_proc = add_seasonal_features(data_proc)

        X_np = np.nan_to_num(data_proc.fillna(0).values)
        if X_np.ndim == 3: X_np = X_np[..., np.newaxis]
        if self.use_log: X_np = apply_log_transform(X_np)

        X_scaled = self._apply_scaler_safely(X_np, self.scaler_X)
        if X_scaled.ndim == 3: X_scaled = X_scaled[..., np.newaxis]

        # 2. Build sequences
        n_time = X_scaled.shape[0]
        if n_time < self.time_seq:
            raise ValueError(f"Not enough time steps: {n_time} < {self.time_seq}")
        X_seq = np.stack([X_scaled[i:i+self.time_seq] for i in range(n_time - self.time_seq + 1)])
        if X_seq.ndim == 4: X_seq = X_seq[..., np.newaxis]
        valid_time = data.time.values[self.time_seq - 1:]

        # 3. MC Sampling (✅ FIX Keras 3: Direct call + training=True)
        predictions = []
        for _ in range(n_samples):
            sample_preds = []
            # Loop manual per batch untuk hemat memori & compatibility
            for i in range(0, len(X_seq), batch_size):
                batch = X_seq[i:i+batch_size]
                # ✅ Langsung panggil model, bukan .predict()
                pred_batch = self.model(batch, training=True).numpy()
                if pred_batch.ndim == 4:
                    pred_batch = np.squeeze(pred_batch, axis=-1)
                sample_preds.append(pred_batch)
            predictions.append(np.concatenate(sample_preds, axis=0))

        predictions = np.stack(predictions)  # (n_samples, n_pred, lat, lon)
        mean_scaled = np.mean(predictions, axis=0)
        std_scaled = np.std(predictions, axis=0)

        # 4. Inverse Transform (hitung bounds di scaled space dulu, baru inverse)
        lower_scaled = mean_scaled - 1.96 * std_scaled
        upper_scaled = mean_scaled + 1.96 * std_scaled

        def inv_transform(arr):
            flat = arr.reshape(arr.shape[0], -1)
            orig = self.scaler_y.inverse_transform(flat).reshape(arr.shape)
            return inverse_log_transform(orig) if self.use_log else orig

        # 5. Build xr.DataArray
        lat_name = next((d for d in self.obs_for_metadata.dims if 'lat' in d.lower()), 'lat')
        lon_name = next((d for d in self.obs_for_metadata.dims if 'lon' in d.lower()), 'lon')

        def to_xarray(arr, name):
            return xr.DataArray(
                arr, coords={"time": valid_time, lat_name: self.obs_for_metadata[lat_name],
                            lon_name: self.obs_for_metadata[lon_name]},
                dims=["time", lat_name, lon_name], name=name
            )

        mean_da = to_xarray(inv_transform(mean_scaled), "mean")
        lower_da = to_xarray(inv_transform(lower_scaled), "lower_95")
        upper_da = to_xarray(inv_transform(upper_scaled), "upper_95")
        std_da = (upper_da - lower_da) / (2 * 1.96)

        logger.info("✅ Uncertainty estimation complete.")
        return mean_da, std_da, lower_da, upper_da
    
    def analyze_uncertainty(self, data, var_label="variable", ref_data=None, 
                        output_dir="uncertainty", n_samples=20, batch_size=16):
        """
        All-in-one: Calculate MC Dropout uncertainty + generate plots.
        Urutan baru: data, label, ref(opsional), dir, ...
        """
        # 1. Calculate Uncertainty
        mean, std, lower, upper = self.predict_with_uncertainty(
            data, n_samples=n_samples, batch_size=batch_size
        )
        
        # 2. Generate Plots
        # ⚠️ PENTING: Pastikan nama fungsi di-import SAMA PERSIS dengan di evaluator.py
        from .evaluator import plot_uncertainty_map, plot_temporal_uncertainty
        
        # Panggil fungsi plotting (sesuaikan nama fungsi di sini)
        plot_uncertainty_map(mean, std, lower, upper, var_label, output_dir, ref_da=ref_data)
        plot_temporal_uncertainty(mean, lower, upper, ref_data, var_label, output_dir)
        
        logger.info(f"✅ Uncertainty analysis complete for {var_label}.")
        return mean, std, lower, upper

    def save(self, path: str):
        logger.info(f"💾 Menyimpan SamudraAI3 ke direktori: {path}...")
        os.makedirs(path, exist_ok=True)

        # Pastikan model built
        if not self.model.built:
            dummy = tf.zeros((1, self.time_seq, 10, 10, self.n_input_channels or 1))
            self.model.build(dummy.shape)

        # === PENYIMPANAN WEIGHT YANG ROBUST ===
        weights_path = os.path.join(path, "weights3.npz")
        arch_path = os.path.join(path, "architecture3.json")
        
        # Ambil weights sebagai list of numpy arrays
        weights = self.model.get_weights()
        
        # Simpan dengan metadata jumlah weight
        np.savez(
            weights_path,
            weights=np.array(weights, dtype=object),  # Simpan sebagai array of objects
            n_weights=len(weights),                   # Simpan juga jumlahnya sebagai metadata
            allow_pickle=True
        )
        
        with open(arch_path, "w") as f:
            f.write(self.model.to_json())

        # Scalers & metadata (naming konsisten: scaler_X3.gz, obs_metadata3.nc)
        joblib.dump(self.scaler_X, os.path.join(path, "scaler_X3.gz"))
        joblib.dump(self.scaler_y, os.path.join(path, "scaler_y3.gz"))
        
        try:
            self.obs_for_metadata.to_netcdf(
                os.path.join(path, "obs_metadata3.nc"), engine="h5netcdf")
        except Exception as e:
            logger.warning(f"❗ Gagal menyimpan obs_metadata3.nc: {e}")

        # Config (config3.json)
        config_dict = {
            "time_seq": self.time_seq,
            "use_log": self.use_log,
            "use_seasonal": self.use_seasonal,
            "mode": self.mode,
            "n_input_channels": self.n_input_channels,
            "model_config": self.config.__dict__,
            "save_method": "manual_weights"
        }
        with open(os.path.join(path, "config3.json"), "w") as f:
            json.dump(config_dict, f, cls=NumpyEncoder)

        logger.info(f"✅ SamudraAI3 dan komponen berhasil disimpan.")

    @classmethod
    def load(cls, path: str):
        logger.info(f"🔄 Memuat SamudraAI3 dari direktori: {path}...")
        import keras
        from samudra_ai.model3 import resize_5d_skip, get_skip_output_shape
        keras.config.enable_unsafe_deserialization()

        # Validate files (naming: config3.json, weights3.npz, dll)
        required = ["config3.json", "weights3.npz", "architecture3.json", 
                    "scaler_X3.gz", "scaler_y3.gz", "obs_metadata3.nc"]
        for fname in required:
            full_path = os.path.join(path, fname)
            if not os.path.exists(full_path):
                raise FileNotFoundError(f"❌ File tidak ditemukan: {full_path}")

        # Load config
        with open(os.path.join(path, "config3.json"), "r") as f:
            config = json.load(f)

        instance = cls(
            time_seq=config["time_seq"],
            config=ModelConfig3(**config["model_config"]),
            use_log=config.get("use_log", False),
            use_seasonal=config.get("use_seasonal", False),
            mode=config.get("mode", None)
        )
        instance.n_input_channels = config.get("n_input_channels", None)

        # Load model manual
        with open(os.path.join(path, "architecture3.json"), "r") as f:
            instance.model = model_from_json(f.read(),custom_objects={
                                                        "LeakyReLU": LeakyReLU,
                                                        "resize_5d_skip": resize_5d_skip,        
                                                        "get_skip_output_shape": get_skip_output_shape
                                                    })

        # Load weights dengan robust handling
        weights_path = os.path.join(path, "weights3.npz")
        w = np.load(weights_path, allow_pickle=True)
        
        # Coba load dengan metadata dulu (format baru)
        if 'n_weights' in w.files:
            n_weights = w['n_weights']
            weights = w['weights'][:n_weights]  # Ambil sesuai jumlah yang tercatat
        else:
            # Fallback ke format lama (jika ada)
            weights = [w[f'arr_{i}'] for i in range(len(w.files))]
        
        # Validasi: pastikan jumlah weight cocok dengan model
        model_weights = instance.model.get_weights()
        if len(weights) != len(model_weights):
            logger.warning(
                f"⚠️ Weight count mismatch: saved={len(weights)}, expected={len(model_weights)}. "
                f"Attempting to load compatible weights..."
            )
            # Coba load sebagian yang cocok (hanya untuk debugging, tidak direkomendasikan untuk produksi)
            min_len = min(len(weights), len(model_weights))
            weights = weights[:min_len]
            # Atau raise error jika ingin strict:
            # raise ValueError(f"Weight mismatch: saved {len(weights)} but model expects {len(model_weights)}")
        
        # Set weights ke model
        instance.model.set_weights(weights)

        # Load components
        instance.scaler_X = joblib.load(os.path.join(path, "scaler_X3.gz"))
        instance.scaler_y = joblib.load(os.path.join(path, "scaler_y3.gz"))
        instance.obs_for_metadata = xr.open_dataarray(os.path.join(path, "obs_metadata3.nc"))

        # Compile
        _compile_model_with_config(instance.model, instance.config, logger)

        logger.info("✅ SamudraAI3 dan komponen berhasil dimuat.")
        return instance