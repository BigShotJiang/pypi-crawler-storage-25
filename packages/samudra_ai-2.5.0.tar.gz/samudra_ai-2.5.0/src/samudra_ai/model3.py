# src/samudra_ai/models.py
from typing import Tuple, List, Optional
import tensorflow as tf
from tensorflow.keras.layers import (
    Input, ConvLSTM2D, BatchNormalization, Dropout, 
    Conv2D, TimeDistributed, MaxPooling2D, UpSampling2D,
    Concatenate, Resizing, LeakyReLU
)
from tensorflow.keras.models import Model
from tensorflow.keras import regularizers

def resize_5d_skip(tensors):
    """Resize skip connection 5D agar match dengan decoder output"""
    x_t, skip_t = tensors
    target_h = tf.shape(x_t)[2]
    target_w = tf.shape(x_t)[3]
    
    orig_shape = tf.shape(skip_t)
    batch, time_dim, h_s, w_s, c_s = orig_shape[0], orig_shape[1], orig_shape[2], orig_shape[3], orig_shape[4]
    
    skip_flat = tf.reshape(skip_t, [batch * time_dim, h_s, w_s, c_s])
    skip_resized_flat = tf.image.resize(skip_flat, [target_h, target_w], method='bilinear')
    return tf.reshape(skip_resized_flat, [batch, time_dim, target_h, target_w, c_s])

def get_skip_output_shape(input_shapes):
    """Memberi tahu Keras shape output Lambda untuk skip resize"""
    x_shape, skip_shape = input_shapes
    # Output: (batch, time, height_dari_x, width_dari_x, channel_dari_skip)
    return (x_shape[0], x_shape[1], x_shape[2], x_shape[3], skip_shape[4])

class ModelConfig3:
    """Konfigurasi untuk U-Net + ConvLSTM (SamudraAI3)"""
    def __init__(
        self,
        encoder_filters: List[int] = [16, 32, 64],
        bottleneck_filters: int = 128,
        decoder_filters: List[int] = [64, 32, 16],
        kernel_size: Tuple[int, int] = (3, 3),
        activation: str = "relu",
        dropout_rates: List[float] = [0.2, 0.3, 0.4, 0.3, 0.2],  # encoder + bottleneck + decoder
        upsample_mode: str = "bilinear",  # 'nearest' atau 'bilinear'
        learning_rate: float = 1e-3,
        batch_size: int = 8,
        epochs: int = 100,
        loss_type: str = "huber",
        huber_delta: float = 0.2,     
        clipnorm: Optional[float] = 0.5,  
    ):
        self.encoder_filters = encoder_filters
        self.bottleneck_filters = bottleneck_filters
        self.decoder_filters = decoder_filters
        self.kernel_size = kernel_size
        self.activation = activation
        self.dropout_rates = dropout_rates
        self.upsample_mode = upsample_mode
        self.learning_rate = learning_rate
        self.batch_size = batch_size
        self.epochs = epochs
        self.loss_type = loss_type
        self.huber_delta = huber_delta
        self.clipnorm = clipnorm

def build_unet_convlstm(
    input_shape: Tuple,
    output_shape: Tuple,
    config: Optional[ModelConfig3] = None
) -> Model:
    """
    Arsitektur U-Net Spatio-Temporal dengan ConvLSTM2D.
    Dirancang untuk sequence-to-sequence forecasting iklim.
    """
    if config is None:
        config = ModelConfig3()

    target_height, target_width = output_shape[0], output_shape[1]
    inputs = Input(shape=input_shape, name="unet_input")  # (batch, time, H, W, C)
    x = inputs

    skip_connections = []

    # === ENCODER ===
    for i, f in enumerate(config.encoder_filters):
        x = ConvLSTM2D(f, config.kernel_size, padding="same", return_sequences=True, 
                       activation=config.activation, name=f"enc_convlstm_{i}")(x)
        x = BatchNormalization(name=f"enc_bn_{i}")(x)
        
        if i < len(config.dropout_rates) and config.dropout_rates[i] > 0:
            x = TimeDistributed(Dropout(config.dropout_rates[i], name=f"enc_drop_{i}"))(x)
            
        skip_connections.append(x)  # Simpan output sebelum pooling
        
        if i < len(config.encoder_filters) - 1:
            x = TimeDistributed(MaxPooling2D((2, 2), padding='same', name=f"enc_pool_{i}"))(x)

    # === BOTTLENECK ===
    bottleneck_idx = len(config.encoder_filters)
    x = ConvLSTM2D(config.bottleneck_filters, config.kernel_size, padding="same", 
                   return_sequences=True, activation=config.activation, 
                   name="bottleneck_convlstm")(x)
    x = BatchNormalization(name="bottleneck_bn")(x)
    if bottleneck_idx < len(config.dropout_rates) and config.dropout_rates[bottleneck_idx] > 0:
        x = TimeDistributed(Dropout(config.dropout_rates[bottleneck_idx], name="bottleneck_drop"))(x)

    # === DECODER ===
    for i, f in enumerate(config.decoder_filters):
        x = TimeDistributed(UpSampling2D((2, 2), name=f"dec_upsample_{i}"))(x)
        
        # Skip connection dari encoder (reverse order)
        skip = skip_connections[-(i + 1)]
        
        skip_resized = tf.keras.layers.Lambda(
            resize_5d_skip,
            output_shape=get_skip_output_shape
        )([x, skip])
        
        x = Concatenate(name=f"dec_concat_{i}")([x, skip_resized])
        
        x = ConvLSTM2D(f, config.kernel_size, padding="same", return_sequences=True, 
               activation=config.activation,
               kernel_regularizer=regularizers.l2(1e-4),  # Tambahkan ini
               name=f"dec_convlstm_{i}")(x)
        
        x = BatchNormalization(name=f"dec_bn_{i}")(x)
        
        dec_drop_idx = len(config.encoder_filters) + 1 + i
        if dec_drop_idx < len(config.dropout_rates) and config.dropout_rates[dec_drop_idx] > 0:
            x = TimeDistributed(Dropout(config.dropout_rates[dec_drop_idx], name=f"dec_drop_{i}"))(x)

    # === OUTPUT HEAD ===
    # Process seluruh sequence
    x = TimeDistributed(Resizing(target_height, target_width, name="final_resize"))(x)
    x = TimeDistributed(Conv2D(1, (1, 1), padding="same", activation="linear"))(x)
    
    # [FIX] Ambil HANYA timestep terakhir agar shape cocok dengan y_train (batch, H, W, 1)
    outputs = tf.keras.layers.Lambda(
        lambda t: t[:, -1, :, :, :], 
        output_shape=lambda s: (s[0], s[2], s[3], s[4]),
        name="last_timestep"
    )(x)

    model = Model(inputs=inputs, outputs=outputs, name="unet_convlstm_model")
    # optimizer = Adam(learning_rate=config.learning_rate, clipnorm=0.5)
    # model.compile(optimizer=optimizer, loss=losses.Huber(delta=0.2), metrics=["mae"])
    return model