# File: src/samudra_ai/data_loader.py yang baruuuuuuu
import os
import xarray as xr
import pandas as pd
import numpy as np
import cftime
from .utils import standardize_dims

def load_and_mask_dataset(file_path: str, var_name: str, lat_range: tuple, lon_range: tuple, time_range: tuple) -> xr.DataArray:

    print(f"-> Memuat dan memproses file: {os.path.basename(file_path)}...")

    # === Validasi waktu ===
    if not (isinstance(time_range, (list, tuple)) and len(time_range) == 2):
        raise ValueError("time_range harus tuple (start, end) dengan format YYYY-MM-DD")

    start_dt, end_dt = map(pd.to_datetime, time_range)
    if start_dt >= end_dt:
        raise ValueError("Tanggal awal harus lebih kecil dari tanggal akhir")

    # === Buka dataset dengan fallback engine ===
    try:
        data = xr.open_dataset(file_path, engine="h5netcdf", decode_times=True)
    except Exception:
        print(f"⚠️ Engine 'h5netcdf' gagal, mencoba 'netCDF4'...")
        data = xr.open_dataset(file_path, engine="netcdf4", decode_times=True)

    # === Pastikan variabel ada ===
    if var_name not in data.variables:
        raise ValueError(f"Variabel '{var_name}' tidak ditemukan di {file_path}")

    da = data[var_name]

    # === Deteksi nama waktu ===
    time_candidates = ["time", "valid_time", "date", "Time", "t"]
    detected_time = next((t for t in time_candidates if t in data.dims or t in data.coords), None)
    if not detected_time:
        raise ValueError("Tidak menemukan koordinat waktu (time/valid_time/date/Time/t).")
    if detected_time != "time":
        data = data.rename({detected_time: "time"})
        da = data[var_name]

    # === Konversi waktu (cftime ke datetime64) ===
    if np.issubdtype(da.time.dtype, np.datetime64):
        pass
    else:
        try:
            da["time"] = xr.decode_cf(da).time
        except Exception:
            try:
                da["time"] = pd.to_datetime(da["time"].values)
            except Exception:
                print("⚠️ Waktu tidak bisa dikonversi otomatis, akan gunakan tipe original.")

    # === Seleksi waktu ===
    try:
        da = da.sel(time=slice(start_dt, end_dt))
    except Exception:
        # fallback jika cftime
        time_type = type(da.time.values[0])
        if "cftime" in str(time_type):
            da = da.sel(time=slice(
                time_type(start_dt.year, start_dt.month, start_dt.day),
                time_type(end_dt.year, end_dt.month, end_dt.day)
            ))

    if da.time.size == 0:
        raise ValueError("Tidak ada data dalam rentang waktu yang diberikan.")

    # === Deteksi nama lat/lon ===
    lat_names = ["lat", "latitude", "nav_lat", "y", "j", "LAT", "Y"]
    lon_names = ["lon", "longitude", "nav_lon", "x", "i", "LON", "X"]

    detected_lat = next((k for k in lat_names if k in da.dims or k in da.coords), None)
    detected_lon = next((k for k in lon_names if k in da.dims or k in da.coords), None)

    if not detected_lat or not detected_lon:
        raise ValueError("Koordinat lat/lon tidak ditemukan dalam dataset.")

    # === Tangani jika lat/lon berbentuk 2D (curvilinear) ===
    lat_vals = da[detected_lat]
    lon_vals = da[detected_lon]
    if lat_vals.ndim == 2 or lon_vals.ndim == 2:
        print("⚠️ Deteksi grid curvilinear (2D), slicing langsung akan di-skip.")
        sliced_data = da  # tidak bisa dislice langsung
    else:
        # Urutkan dan slice
        if lat_vals[0] > lat_vals[-1]:
            da = da.sortby(detected_lat)
        if lon_vals[0] > lon_vals[-1]:
            da = da.sortby(detected_lon)
        sliced_data = da.sel(
            {detected_lat: slice(*lat_range), detected_lon: slice(*lon_range)}
        )

    # === Hapus timestep kosong ===
    sliced_data = sliced_data.dropna(dim="time", how="all")

    if sliced_data.size == 0:
        raise ValueError("Data kosong setelah slicing spasial/waktu.")

    # =========================
    # STANDARDIZE DIM (FULL CONTROL HERE)
    # =========================

    is_curvilinear = (
        sliced_data[detected_lat].ndim == 2 or
        sliced_data[detected_lon].ndim == 2
    )

    if is_curvilinear:
        print("⚠️ Curvilinear grid detected → skip standardize_dims")
    else:
        sliced_data = standardize_dims(sliced_data)

    print(f"✅ Dataset siap → shape={sliced_data.shape}, var={var_name}")

    # =========================
    # NORMALIZE TIME (SAFE)
    # =========================

    time_values = sliced_data.time.values

    # infer frequency
    try:
        time_resolution = pd.infer_freq(pd.to_datetime(time_values))
    except Exception:
        time_resolution = None

    # =========================
    # CFTime Handling
    # =========================
    if isinstance(time_values[0], cftime.datetime) or "cftime" in str(type(time_values[0])):

        print("⚠️ CFTime detected → converting to datetime64...")

        # convert manually
        converted_time = pd.to_datetime([
            f"{t.year:04d}-{t.month:02d}-{t.day:02d}"
            for t in time_values
        ])

        sliced_data["time"] = converted_time

    # =========================
    # Standard datetime
    # =========================
    else:

        t = pd.to_datetime(time_values)

        # Daily data → keep original
        if time_resolution in ["D", "1D"]:

            print("📅 Daily resolution detected → keeping original timestamps")
            sliced_data["time"] = t

        else:
            # Monthly normalization
            print("📅 Monthly resolution detected → normalizing to month-start")

            normalized_time = pd.DatetimeIndex([
                pd.Timestamp(year=x.year, month=x.month, day=1)
                for x in t
            ])

            sliced_data["time"] = normalized_time

    print("✅ Time normalized")
    print("Time sample:", sliced_data.time.values[:5])

    # =========================
    # FINAL CHECKS
    # =========================
    if sliced_data.time.size == 0:
        raise ValueError("Tidak ada data waktu setelah normalisasi.")

    if "channel" not in sliced_data.dims:
        sliced_data = sliced_data.expand_dims("channel")
        sliced_data = sliced_data.assign_coords(channel=[0])

    return sliced_data