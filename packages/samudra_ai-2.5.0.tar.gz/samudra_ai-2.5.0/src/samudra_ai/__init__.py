# File: src/samudra_ai/__init__.py
from .core import SamudraAI, SamudraAI2, SamudraAI3
from .data_loader import load_and_mask_dataset
from .trainer import prepare_training_data, plot_training_history
from .evaluator import evaluate_model, plot_spatial_comparison, apply_mask
from .preprocess_dcpp import preprocess_dcpp

__version__ = "2.5.0"
__all__ = [
    'SamudraAI',
    'SamudraAI2',
    'SamudraAI3',
    'load_and_mask_dataset',
    'prepare_training_data',
    'plot_training_history',
    'evaluate_model',
    'plot_spatial_comparison',
    "preprocess_dcpp",
    "apply_mask",
]