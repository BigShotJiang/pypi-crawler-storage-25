# # File: src/samudra_ai/trainer.py
# file lama, udah OK

from sklearn.preprocessing import MinMaxScaler, StandardScaler
from sklearn.model_selection import train_test_split
import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt
import os
import xarray as xr

def ensure_numpy(data):
    if isinstance(data, xr.DataArray):
        return data.values
    return np.array(data)

def ensure_time_first_np(arr, time_axis=0):
    # assume already correct from xarray
    return arr

def prepare_training_data(
    x_data,
    y_data,
    time_seq=10,
    seed=42,
    config=None
):

    # =========================
    # 1. ALIGN TIME
    # =========================
    n_time = x_data.shape[0]

    # =========================
    # 2. TO NUMPY + CLEAN
    # =========================
    x_np = np.nan_to_num(x_data.values, nan=0.0, posinf=0.0, neginf=0.0)
    y_np = np.nan_to_num(y_data.values, nan=0.0, posinf=0.0, neginf=0.0)

    # =========================
    # 3. HANDLE DIMENSIONS
    # =========================
    if x_np.ndim == 3:
        x_np = x_np[..., np.newaxis]

    elif x_np.ndim == 4 and x_data.dims[0] == "channel":
        x_np = np.transpose(x_np, (1, 2, 3, 0))

    if y_np.ndim == 4:
        if y_data.dims[0] == "channel":
            y_np = y_np[0]
        elif y_data.dims[-1] == "channel":
            y_np = np.squeeze(y_np, axis=-1)

    # =========================
    # 4. SAFETY CHECK
    # =========================
    n_time = x_np.shape[0]
    if n_time <= time_seq:
        raise ValueError(f"❌ Data too short: {n_time} <= {time_seq}")

    # =========================
    # 5. SCALE (NO LEAKAGE)
    # =========================
    x_flat = x_np.reshape(n_time, -1)
    y_flat = y_np.reshape(n_time, -1)

    split = int(n_time * 0.8)

    scaler_X = StandardScaler()
    scaler_y = StandardScaler()

    scaler_X.fit(x_flat[:split])
    scaler_y.fit(y_flat[:split])

    x_scaled = scaler_X.transform(x_flat).reshape(x_np.shape)
    y_scaled = scaler_y.transform(y_flat).reshape(y_np.shape)

    # =========================
    # 6. BUILD SEQUENCE (FIXED)
    # =========================
    X_seq, Y_seq = [], []

    for i in range(n_time - time_seq + 1):
        X_seq.append(x_scaled[i:i + time_seq])
        Y_seq.append(y_scaled[i + time_seq - 1])

    X_seq = np.array(X_seq)
    Y_seq = np.array(Y_seq)

    # =========================
    # 7. SPLIT AFTER SEQUENCE
    # =========================
    split_seq = int(len(X_seq) * 0.8)

    X_train = X_seq[:split_seq]
    X_test  = X_seq[split_seq:]

    y_train = Y_seq[:split_seq]
    y_test  = Y_seq[split_seq:]

    # =========================
    # 8. FINAL CHECK
    # =========================
    if X_train.ndim != 5:
        raise ValueError(f"X_train invalid shape: {X_train.shape}")

    if y_train.ndim != 3:
        raise ValueError(f"y_train invalid shape: {y_train.shape}")

    return X_train, X_test, y_train, y_test, scaler_X, scaler_y

def plot_training_history(history, output_dir=None):
    if output_dir: os.makedirs(output_dir, exist_ok=True)
    plt.figure(figsize=(10, 6))
    plt.plot(history.history['loss'], label='Train Loss')
    plt.plot(history.history['val_loss'], label='Val Loss')
    plt.title("Kurva Loss Training")
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.legend()
    plt.grid(True, alpha=0.3)
    if output_dir:
        plt.savefig(os.path.join(output_dir, "loss_curve.png"))
    plt.show()

    # plt.figure(figsize=(10, 6))
    # plt.plot(history.history['mae'], label='Train MAE')
    # plt.plot(history.history['val_mae'], label='Val MAE')
    # plt.title("Kurva MAE Training")
    # plt.xlabel("Epoch")
    # plt.ylabel("MAE")
    # plt.legend()
    # if output_dir:
    #     plt.savefig(os.path.join(output_dir, "mae_curve.png"))
    # plt.show()

