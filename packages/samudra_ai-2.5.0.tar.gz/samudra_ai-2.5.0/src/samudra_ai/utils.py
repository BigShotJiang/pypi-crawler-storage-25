# src/samudra_ai/utils.py

import json
import numpy as np
import xarray as xr
import pandas as pd
import datetime
import cftime
from sklearn.metrics import mean_absolute_error
from scipy.interpolate import griddata

def get_lat_lon_names(da):
    lat_candidates = ["lat", "latitude", "nav_lat"]
    lon_candidates = ["lon", "longitude", "nav_lon"]

    lat_name = next((c for c in lat_candidates if c in da.coords), None)
    lon_name = next((c for c in lon_candidates if c in da.coords), None)

    return lat_name, lon_name


def is_curvilinear(da):
    lat_name, lon_name = get_lat_lon_names(da)

    if lat_name is None or lon_name is None:
        return False

    return da[lat_name].ndim == 2 and da[lon_name].ndim == 2

def regrid_if_needed(gcm_da, obs_da):

    if not is_curvilinear(gcm_da):
        print("✅ Regular grid → skip regrid")
        return gcm_da

    print("🌍 Grid Curvilinear terdeteksi → regridding ke Regular grid")

    lat_name, lon_name = get_lat_lon_names(gcm_da)

    if lat_name is None or lon_name is None:
        print("⚠️ Tidak ditemukan koordinat lat/lon → skip regrid")
        return gcm_da

    lat2d = gcm_da[lat_name].values
    lon2d = gcm_da[lon_name].values

    target_lat = obs_da["lat"].values
    target_lon = obs_da["lon"].values

    lon_target_2d, lat_target_2d = np.meshgrid(target_lon, target_lat)

    out = []

    lat_flat = lat2d.ravel()
    lon_flat = lon2d.ravel()
    base_mask = ~np.isnan(lat_flat) & ~np.isnan(lon_flat)

    for t in range(gcm_da.sizes["time"]):

        da_t = gcm_da.isel(time=t)

        # 🔥 pastikan time sudah hilang
        if "time" in da_t.dims:
            da_t = da_t.squeeze("time")

        # 🔥 handle channel
        if "channel" in da_t.dims:
            da_t = da_t.isel(channel=0)

        # 🔥 squeeze sisa dim singleton
        da_t = da_t.squeeze()

        # 🔥 VALIDASI FINAL
        if da_t.ndim != 2:
            raise ValueError(f"❌ Invalid 2D field at t={t}, shape={da_t.shape}")

        values = da_t.values
        val_flat = values.ravel()

        valid_mask = base_mask & ~np.isnan(val_flat)

        points = np.column_stack((lat_flat[valid_mask], lon_flat[valid_mask]))
        vals = val_flat[valid_mask]

        if len(vals) < 10:
            print(f"⚠️ Skip timestep {t} (too few valid points)")
            interp = np.full_like(lat_target_2d, np.nan)
            out.append(interp)
            continue

        interp = griddata(points, vals, (lat_target_2d, lon_target_2d), method="linear")

        obs_t = obs_da.isel(time=0)

        if "channel" in obs_t.dims:
            obs_t = obs_t.isel(channel=0)

        obs_mask = ~np.isnan(obs_t.values)

        # pastikan shape sama
        if obs_mask.shape != interp.shape:
            print("⚠️ Obs mask shape mismatch → skip masking")
        else:
            interp[~obs_mask] = np.nan

        # 🔥 FIX NaN fallback
        nan_ratio = np.isnan(interp).mean()
        if nan_ratio > 0.2:
            # print(f"⚠️ High NaN ({nan_ratio:.2f}) → fallback nearest")
            interp_nearest = griddata(points, vals, (lat_target_2d, lon_target_2d), method="nearest")
            interp[np.isnan(interp)] = interp_nearest[np.isnan(interp)]

        out.append(interp)

    out = np.stack(out, axis=0)

    # VALIDASI
    if out.shape[0] != gcm_da.sizes["time"]:
        raise ValueError(
            f"❌ Output time mismatch: {out.shape[0]} vs {gcm_da.sizes['time']}"
        )

    da_out = xr.DataArray(
        out,
        dims=("time", "lat", "lon"),
        coords={
            "time": gcm_da["time"],
            "lat": target_lat,
            "lon": target_lon
        }
    )

    # channel
    da_out = da_out.expand_dims("channel").assign_coords(channel=[0])

    print("✅ Konversi grid selesai")

    return da_out

def add_seasonal_features(da: xr.DataArray, scale_factor: float = 1.0) -> xr.DataArray:
    """
    Add seasonal encoding (sin/cos month) as extra channel.

    OUTPUT FORMAT (STRICT):
        (time, lat, lon, channel)

    channel:
        0 = original data
        1 = sin(month)
        2 = cos(month)
    """

    # =========================
    # ENSURE BASE FORMAT
    # =========================
    if "channel" in da.dims:
        da = da.isel(channel=0)

    # jika masih 3D → expand channel
    da = da.expand_dims("channel")
    da = da.assign_coords(channel=[0])

    # =========================
    # TIME FEATURES
    # =========================
    month = da["time"].dt.month

    sin_month = np.sin(2 * np.pi * month / 12)
    cos_month = np.cos(2 * np.pi * month / 12)

    # =========================
    # BROADCAST KE GRID
    # =========================
    base = da.isel(channel=0)

    sin_da = xr.DataArray(sin_month, coords={"time": da.time}, dims=["time"])
    cos_da = xr.DataArray(cos_month, coords={"time": da.time}, dims=["time"])

    sin_da = xr.broadcast(sin_da, base)[0]
    cos_da = xr.broadcast(cos_da, base)[0]

    # =========================
    # ADD CHANNEL DIM
    # =========================
    sin_da = sin_da.expand_dims("channel").assign_coords(channel=[1]) * scale_factor
    cos_da = cos_da.expand_dims("channel").assign_coords(channel=[2]) * scale_factor

    # =========================
    # CONCAT
    # =========================
    out = xr.concat([da, sin_da, cos_da], dim="channel")

    # =========================
    # FORCE STANDARD ORDER
    # =========================
    out = out.transpose("time", "lat", "lon", "channel")

    return out

def apply_log_transform(x):
    return np.log1p(np.maximum(x, 0))

def inverse_log_transform(x, clip_max=15):
    if clip_max is not None:
        x = np.clip(x, None, clip_max)
    return np.maximum(np.expm1(x), 0)

def standardize_dims(da: xr.DataArray) -> xr.DataArray:
    da = da.copy()

    # =========================
    # DETECT CURVILINEAR
    # =========================
    is_curvilinear = (
        "lat" in da.coords and
        "lon" in da.coords and
        len(da["lat"].dims) == 2
    )

    # =========================
    # HANDLE REGULAR GRID
    # =========================
    if not is_curvilinear:
        rename_map = {}

        # standard names
        if "latitude" in da.dims:
            rename_map["latitude"] = "lat"
        if "longitude" in da.dims:
            rename_map["longitude"] = "lon"

        # fallback y/x → lat/lon (ONLY if safe)
        if "y" in da.dims and "lat" not in da.dims:
            rename_map["y"] = "lat"
        if "x" in da.dims and "lon" not in da.dims:
            rename_map["x"] = "lon"

        if rename_map:
            da = da.rename(rename_map)

        if "lat" not in da.dims or "lon" not in da.dims:
            print("⚠️ Skip standardize_dims: bukan regular grid")
            return da

        spatial_dims = ("lat", "lon")

    # =========================
    # HANDLE CURVILINEAR GRID
    # =========================
    else:
        print("⚠️ Curvilinear grid detected → using original spatial dims")

        # ambil dim dari lat
        spatial_dims = da["lat"].dims  # biasanya (y,x)

        if len(spatial_dims) != 2:
            raise ValueError("❌ Curvilinear lat harus 2D")

    # =========================
    # VALIDASI DIM
    # =========================
    if "time" not in da.dims:
        raise ValueError("❌ Tidak ada dim 'time'")

    # =========================
    # DROP DIM LAIN (kalau ada)
    # =========================
    allowed_dims = ["time", *spatial_dims]

    extra_dims = [d for d in da.dims if d not in allowed_dims]

    if extra_dims:
        print(f"⚠️ Drop dim tambahan: {extra_dims}")
        da = da.isel({d: 0 for d in extra_dims})

    # =========================
    # ENSURE CHANNEL
    # =========================
    if "channel" not in da.dims:
        da = da.expand_dims("channel")
        da = da.assign_coords(channel=[0])

    # =========================
    # FINAL ORDER (FIXED)
    # =========================
    da = da.transpose("time", *spatial_dims, "channel")

    return da

def safe_time_convert(time_values):
    if isinstance(time_values[0], cftime.datetime):
        print("⚠️ CFTime detected in align_time → skip conversion")
        return time_values
    try:
        return pd.to_datetime(time_values).normalize()
    except Exception:
        print("⚠️ Fallback: keep original time")
        return time_values
    
def to_time_str(time_values, mode=None):

    def convert_one(t):

        # =========================
        # CASE 1: CFTime (AMAN)
        # =========================
        if isinstance(t, cftime.datetime):
            if mode == "hujan":
                return f"{t.year:04d}-{t.month:02d}-{t.day:02d}"
            else:
                return f"{t.year:04d}-{t.month:02d}"

        # =========================
        # CASE 2: numpy.datetime64
        # =========================
        if isinstance(t, np.datetime64):
            ts = pd.Timestamp(t)
            if mode == "hujan":
                return ts.strftime("%Y-%m-%d")
            else:
                return ts.strftime("%Y-%m")

        # =========================
        # CASE 3: python datetime
        # =========================
        if hasattr(t, "year") and hasattr(t, "month"):
            if mode == "hujan":
                return f"{t.year:04d}-{t.month:02d}-{t.day:02d}"
            else:
                return f"{t.year:04d}-{t.month:02d}"

        # =========================
        # FALLBACK (STRING)
        # =========================
        t_str = str(t)
        return t_str[:10] if mode == "hujan" else t_str[:7]

    return np.array([convert_one(t) for t in time_values])

def align_time_if_needed(gcm, obs, mode="bulanan"):
    gcm = gcm.copy()
    obs = obs.copy()

    # =========================
    # SORT (WAJIB)
    # =========================
    gcm = gcm.sortby("time")
    obs = obs.sortby("time")

    # =========================
    # STRING CONVERSION (CORE FIX)
    # =========================
    gcm_time_str = to_time_str(gcm.time.values, mode)
    obs_time_str = to_time_str(obs.time.values, mode)

    common = np.intersect1d(gcm_time_str, obs_time_str)

    print(f"🔍 COMMON TIME: {len(common)}")

    if len(common) == 0:
        raise ValueError("❌ No overlapping time found")

    gcm = gcm.isel(time=np.isin(gcm_time_str, common))
    obs = obs.isel(time=np.isin(obs_time_str, common))

    return gcm, obs

def compute_metrics(obs, model):
    """Menghitung metrik statistik antara data observasi dan model."""
    if isinstance(obs, xr.DataArray): obs = obs.values
    if isinstance(model, xr.DataArray): model = model.values
    obs_vals, model_vals = obs.flatten(), model.flatten()
    mask = ~np.isnan(obs_vals) & ~np.isnan(model_vals)
    obs_clean, model_clean = obs_vals[mask], model_vals[mask]
    if len(obs_clean) == 0: return np.nan, np.nan, np.nan, np.nan
    correlation = np.corrcoef(obs_clean, model_clean)[0, 1]
    rmse = np.sqrt(np.mean((model_clean - obs_clean) ** 2))
    bias = np.mean(model_clean - obs_clean)
    mae = mean_absolute_error(obs_clean, model_clean)
    return correlation, rmse, bias, mae

def save_to_netcdf(da: xr.DataArray, path: str, attrs: dict = None):
    """
    Simpan xarray.DataArray ke file NetCDF dengan atribut dan encoding standar.
    """
    da.name = da.name or "variable"
    da.attrs.update(attrs or {})
    da.attrs.setdefault("title", "Hasil Koreksi SAMUDRA-AI")
    da.attrs.setdefault("description", "Data hasil koreksi bias menggunakan CNN-BiLSTM")
    da.attrs.setdefault("history", f"Generated by SAMUDRA-AI on {datetime.datetime.now().isoformat()}")
    
    # Tambahkan encoding agar tidak terlalu besar (opsional)
    encoding = {
        da.name: {
            "zlib": True,
            "complevel": 4,
            "_FillValue": -9999.0,
        }
    }
    da.to_netcdf(path, encoding=encoding, engine="h5netcdf")
    print(f"💾 Data berhasil disimpan ke: {path}")

class NumpyEncoder(json.JSONEncoder):
    """ Kelas helper untuk encoding NumPy array ke JSON. """
    def default(self, obj):
        if isinstance(obj, np.generic):
            return obj.item()
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        return super().default(obj)