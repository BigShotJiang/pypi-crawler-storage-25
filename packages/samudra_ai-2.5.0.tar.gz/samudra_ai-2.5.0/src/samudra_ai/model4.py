# File: src/samudra_ai/model4.py

from typing import Tuple, List, Optional
import numpy as np
import tensorflow as tf

from tensorflow.keras.models import Model
from tensorflow.keras.layers import (
    Input,
    TimeDistributed,
    Conv2D,
    BatchNormalization,
    Dropout,
    Reshape,
    Dense,
    GRU,
    Lambda
)

from tensorflow.keras.optimizers import Adam
from tensorflow.keras import losses
from spektral.layers import GCNConv


# =========================================================
# CONFIG
# =========================================================

class ModelConfig4:
    """
    Konfigurasi SamudraAI4
    Hybrid CNN + Graph Neural Network + GRU
    """

    def __init__(
        self,

        # CNN encoder
        cnn_filters: List[int] = [16, 32],

        # Graph
        gnn_units: int = 64,

        # Temporal
        gru_units: int = 128,

        # Kernel
        kernel_size: Tuple[int, int] = (3, 3),

        # Training
        learning_rate: float = 1e-3,
        batch_size: int = 4,
        epochs: int = 100,

        # Dropout
        dropout_rate: float = 0.2,

        # Loss
        loss_function = None,
        huber_delta: float = 0.3
    ):

        self.cnn_filters = cnn_filters
        self.gnn_units = gnn_units
        self.gru_units = gru_units
        self.kernel_size = kernel_size
        self.learning_rate = learning_rate
        self.batch_size = batch_size
        self.epochs = epochs
        self.dropout_rate = dropout_rate

        self.loss_function = (
            loss_function
            if loss_function is not None
            else losses.Huber(delta=huber_delta)
        )


# =========================================================
# ADJACENCY MATRIX
# =========================================================

def build_grid_adjacency(height, width):
    """
    Membuat adjacency matrix 8-neighbor
    untuk grid climate.
    """

    n_nodes = height * width
    A = np.zeros((n_nodes, n_nodes), dtype=np.float32)

    def node_index(i, j):
        return i * width + j

    directions = [
        (-1, -1), (-1, 0), (-1, 1),
        (0, -1),           (0, 1),
        (1, -1),  (1, 0),  (1, 1)
    ]

    for i in range(height):
        for j in range(width):

            current = node_index(i, j)

            for di, dj in directions:

                ni = i + di
                nj = j + dj

                if 0 <= ni < height and 0 <= nj < width:
                    neighbor = node_index(ni, nj)
                    A[current, neighbor] = 1.0

    # self-loop
    A += np.eye(n_nodes)

    return A


# =========================================================
# MODEL
# =========================================================

def build_gnn_model(
    input_shape: Tuple,
    output_shape: Tuple,
    config: Optional[ModelConfig4] = None
) -> Model:

    """
    SamudraAI4
    CNN + GCN + GRU
    """

    if config is None:
        config = ModelConfig4()

    target_height = output_shape[0]
    target_width = output_shape[1]

    n_nodes = target_height * target_width

    # =====================================================
    # INPUT
    # =====================================================

    inputs = Input(shape=input_shape)

    x = inputs

    # =====================================================
    # CNN ENCODER
    # =====================================================

    for f in config.cnn_filters:

        x = TimeDistributed(
            Conv2D(
                f,
                config.kernel_size,
                padding="same",
                activation="relu"
            )
        )(x)

        x = TimeDistributed(BatchNormalization())(x)

    x = TimeDistributed(Dropout(config.dropout_rate))(x)

    # =====================================================
    # RESHAPE TO GRAPH NODES
    # =====================================================

    feature_dim = config.cnn_filters[-1]

    x = TimeDistributed(
        Reshape((n_nodes, feature_dim))
    )(x)

    # =====================================================
    # ADJACENCY MATRIX
    # =====================================================

    A = build_grid_adjacency(target_height, target_width)

    A_tensor = tf.constant(A, dtype=tf.float32)

    # =====================================================
    # GRAPH CONV
    # =====================================================

    graph_outputs = []

    time_steps = input_shape[0]

    for t in range(time_steps):

        xt = Lambda(lambda z: z[:, t])(x)

        g = GCNConv(config.gnn_units, activation="relu")(
            [xt, A_tensor]
        )

        graph_outputs.append(g)

    x = Lambda(lambda z: tf.stack(z, axis=1))(graph_outputs)

    # =====================================================
    # TEMPORAL LEARNING
    # =====================================================

    x = Reshape((time_steps, n_nodes * config.gnn_units))(x)

    x = GRU(
        config.gru_units,
        return_sequences=False
    )(x)

    x = Dropout(config.dropout_rate)(x)

    # =====================================================
    # DECODER
    # =====================================================

    x = Dense(
        target_height * target_width,
        activation="linear"
    )(x)

    outputs = Reshape(
        (target_height, target_width, 1)
    )(x)

    # =====================================================
    # MODEL
    # =====================================================

    model = Model(inputs, outputs, name="samudra_ai4_gnn")

    model.compile(
        optimizer=Adam(config.learning_rate),
        loss=config.loss_function,
        metrics=["mae"]
    )

    return model