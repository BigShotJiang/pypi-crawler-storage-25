# samudra-ai
Library Python samudra-ai versi terbaru

# SamudraAI 🌊

![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)
[![PyPI version](https://badge.fury.io/py/samudra-ai.svg)](https://pypi.org/project/samudra-ai/)
[![Python](https://img.shields.io/pypi/pyversions/samudra-ai.svg)](https://pypi.org/project/samudra-ai/)

Paket Python versi terbaru untuk melakukan pengolahan koreksi bias model iklim global menggunakan arsitektur deep learning.

**SamudraAI** memudahkan peneliti dan praktisi di bidang ilmu iklim untuk menerapkan metode koreksi bias yang canggih pada data GCM (General Circulation Model) menggunakan data observasi sebagai referensi.



## Pilihan Model

1️⃣ SamudraAI (CNN-BiLSTM)

✅ Kelebihan:
Training paling cepat & konsumsi VRAM paling ringan
Robust terhadap noise & missing data berkat pooling & dropout
Sangat baik menangkap tren temporal & rata-rata regional
Bekerja stabil dengan dataset terbatas

⚠️ Kekurangan:
Global pooling menghilangkan detail spasial resolusi tinggi
Output spasial direkonstruksi dari Dense layer → cenderung smooth/blur
Kurang optimal untuk pola lokal tajam (gradien pesisir, orografis)

🎯 Kapan Dipilih:
Bias correction parameter iklim, studi regional skala besar, environment dengan GPU terbatas, atau baseline cepat.

2️⃣ SamudraAI2 (ConvLSTM2D)

✅ Kelebihan:
Memodelkan dependensi spasial & temporal secara bersamaan
Struktur spasial lebih terjaga dibanding pooling-based model
Evolusi temporal halus berkat filter rekuren spasial
Keseimbangan baik antara akurasi & biaya komputasi

⚠️ Kekurangan:
Dapat kesulitan dengan skala spasial sangat tidak seragam
Output sequence-to-sequence perlu slicing manual untuk next-step prediction
VRAM lebih tinggi dari SamudraAI

🎯 Kapan Dipilih:
Downscaling dan koreksi bias dengan transisi temporal yang penting dan resolusi temporal yang lebih tinggi.

3️⃣ SamudraAI3 (U-Net + ConvLSTM)

✅ Kelebihan:
Ekstraksi fitur multi-skala (detail lokal + konteks global)
Skip connections mempertahankan pola resolusi tinggi
Dynamic resize menangani input dimensi ganjil/kecil secara robust (padding='same')

⚠️ Kekurangan:
Konsumsi VRAM & waktu training paling tinggi
Memerlukan tuning dropout & learning rate agar tidak overfit
Rentan noise jika data training terlalu sedikit atau tidak stabil

🎯 Kapan Dipilih:
Koreksi bias high-precision (curah hujan ekstrem), region dengan topografi/pesisir kompleks.


## Fitur Utama

* 🧠 **Antarmuka Sederhana**: API yang bersih, sederhana dan mudah digunakan.
* 🛠️ **Pra-pemrosesan Terintegrasi**: Fungsi bawaan untuk memuat, memotong, dan menormalisasi data iklim dalam format NetCDF.
* 🛠️ **Tersedia transformasi log/expm**: Fungsi bawaan untuk memuat, memotong, dan menormalisasi data iklim khususnya data hujan.
* 🛠️ **Tersedia feature seasonal**: Fungsi bawaan untuk memasukkan faktor pola musiman khususnya pada data hujan.
* 🛠️ **Tersedia manual tunning**: Fungsi bawaan apabila mau melakukan parameter tunning selain pilihan default untuk hasil yang spesifik.
* 🛠️ **Tersedia uncertainty model**: Fungsi bawaan untuk melihat kemampuan model dalam melakukan koreksi untuk data grid random.
* 💾 **Model Persistent**: Kemampuan untuk menyimpan model yang telah dilatih dan memuatnya kembali untuk diterapkan pada data dimasa depan.


## Instalasi

Anda dapat menginstal SamudraAI langsung dari PyPI menggunakan pip:

```bash
pip install samudra-ai
```


## Penggunaan Library
```
https://github.com/adityoAJA/samudra-ai/blob/cc71adc811d5b16ece2d6db74044124974eb1136/How-to-use-samudra-ai.txt
```


## Best Practice

* ✅ Disarankan menggunakan TensorFlow GPU untuk performa optimal
* ✅ Disarankan memiliki memory / RAM yang cukup untuk pengolahan data dengan resolusi tinggi dan luasan domain yang besar
* ✅ Jalankan versi tunning yang sudah ter hardcore. Bila hasil kurang optimal bisa menyesuaikan ulang parameter tunningnya secara manual.
* ⚠️ Hindari mencampur save/load model .keras antar environment yang berbeda
* ⚠️ Menggunakan Docker tetap bisa berjalan, namun proses save and load (penggunaan no.5) tidak bisa diproses karena perbedaan env
* 💡 Format .nc hasil koreksi bisa langsung digunakan untuk plotting dan analisis


## Lisensi

Proyek ini dilisensikan di bawah **MIT License**. Lihat file `LICENSE` untuk detailnya.
