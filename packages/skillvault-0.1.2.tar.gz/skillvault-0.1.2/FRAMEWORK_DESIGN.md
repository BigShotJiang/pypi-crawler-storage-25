# Skillvault 设计文档

## 1. 定位

**Agent 技能基础设施** — 解决 Skill 怎么存储、怎么检索、怎么注入、怎么生长。

- 不是 SaaS，不需要多租户
- 不是框架，不需要适配器
- 就是一个 **可以被任何 Agent 系统 import 使用的本地库**

---

## 2. 架构

```
你的 Agent 代码
    │
    v
SkillManager (一个类)
    │
    v
skills.db (SQLite + sqlite-vec)
```

没有事件总线，没有存储抽象层，没有插件系统。

---

## 3. 核心 API

```python
from skillvault import SkillManager

# 初始化
sm = SkillManager("skills.db", embed_fn=my_embed, llm_fn=my_llm)

# 查询 → 返回可注入 LLM 的字符串
context = sm.query("React useEffect cleanup", budget=4000)

# 注册技能
sm.register(Skill(id="frontend-react", ...))

# 提取知识（对话结束后显式调用）
draft_id = sm.extract(messages)

# 审核
sm.approve(draft_id)
sm.reject(draft_id, reason="过时")
```

**为什么一个类够用：**
- 本地文件（`skills.db`），不需要网络请求
- 直接方法调用，没有事件/回调/适配器
- Agent 代码决定什么时候 `query()` 和 `extract()`

---

## 4. 依赖注入

Embedding 和 LLM 都通过函数注入，不硬编码任何厂商：

```python
import json
from openai import OpenAI
from skillvault import SkillManager

client = OpenAI()

# embed_fn: 必须提供，返回固定维度的浮点数列表
# text-embedding-3-small 返回 1536 维
def embed(text: str) -> list[float]:
    resp = client.embeddings.create(model="text-embedding-3-small", input=[text])
    return resp.data[0].embedding

# llm_fn: 可选，用于 extract() 提取知识
# 输入是对话文本，返回分析结果 dict
def extract_knowledge(text: str) -> dict:
    resp = client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": f"Extract reusable knowledge from:\n{text}\n\nReturn JSON with fields: has_knowledge(bool), title, playbook, examples, when_to_use, dependencies(list)"}],
        response_format={"type": "json_object"},
    )
    return json.loads(resp.choices[0].message.content)

sm = SkillManager("skills.db", embed_fn=embed, llm_fn=extract_knowledge)
```

**`llm_fn` 返回格式：**

```python
{
    "has_knowledge": bool,        # 必须：是否包含可复用知识
    "title": str,                 # 可选：标题
    "playbook": str,              # 可选：步骤说明 (markdown)
    "examples": str,              # 可选：代码示例 (markdown)
    "when_to_use": str,           # 可选：适用场景
    "dependencies": ["skill-id"], # 可选：相关 skill
}
```

- `embed_fn` 必须提供，否则 `query()` 会报错
- `llm_fn` 可选，不提供则 `extract()` 直接返回 `None`

---

## 5. 权限分离

通过 `mode` 参数控制，不需要单独的类：

| mode | 能做什么 |
|------|---------|
| `"admin"` (默认) | 完整权限：register, approve, reject, archive |
| `"agent"` | 受限：只能 query + extract，admin 操作抛 PermissionError |

```python
# Agent 代码
sm = SkillManager("skills.db", embed_fn=..., mode="agent")
sm.query("...")           # OK
sm.extract(messages)      # OK
sm.register(skill)        # PermissionError
sm.approve(draft_id)      # PermissionError
```

**为什么需要强制分离：**

```
没有权限分离的危险路径：
Agent 执行错误 → extract() → 错误知识进 draft → 自动 promote → 污染 canonical
```

---

## 6. 数据模型

```python
@dataclass
class Skill:
    id: str                    # "frontend-react"
    name: str                  # 显示名称
    source: str                # "canonical" | "draft"
    status: str                # "active" | "archived"
    chunks: List[Chunk]
    confidence: float = 1.0    # 草稿的置信度
    extracted_from: str = ""   # 来源
    created_at: datetime

@dataclass
class Chunk:
    id: str                    # "frontend-react::useeffect"
    skill_id: str
    section: str               # 标题
    content: str               # Markdown 内容
    tokens: int                # 预计算的 token 数
    priority: int = 0          # 加载优先级
    required: bool = False     # 是否强制加载
    dependencies: List[str] = []  # 依赖的 chunk ID
```

依赖关系存在 Chunk 内部，用递归 CTE 展开（最多 3 跳）。

---

## 7. 查询流程

```python
def query(text, budget=4000, include_drafts=False, top_k=20, score_threshold=0.4):
    1. embed_fn(text) → 向量
    2. sqlite-vec ANN 检索 → candidates
    3. 递归展开 hard dependencies
    4. 加载命中 skill 的 required chunks
    5. Token budget 裁剪（required > hard_dep > vector）
    6. 记录 usage（驱动自动提升）
    7. 组装 XML blocks 返回
```

---

## 8. 自生长流程

```python
def extract(context):
    1. llm_fn(context) → 分析结果
    2. 置信度评估（长度、代码块、步骤标记等）
    3. 向量相似度去重
    4. 创建 draft skill
    5. 检查自动提升条件
```

**调用时机由用户决定**（不需要事件系统）：

```python
# 对话结束后
if len(messages) >= 5:
    sm.extract(messages)

# 任务成功后
if task_result.success:
    sm.extract([{"role": "user", "content": task}, {"role": "assistant", "content": solution}])

# 用户纠正后
sm.extract([{"role": "user", "content": f"错误：{bad}\n正确：{good}"}])
```

---

## 9. 自动提升

单条 SQL，不需要策略模式：

```sql
UPDATE skills SET source = 'canonical'
WHERE id = ? AND source = 'draft'
  AND confidence >= ?
  AND (SELECT COALESCE(query_count, 0) FROM usage_stats WHERE skill_id = skills.id) >= ?
```

默认阈值：`{"usage": 5, "confidence": 0.9}`，可在初始化时覆盖。

---

## 10. 存储

SQLite + sqlite-vec，单文件 `skills.db`：

```sql
skills     -- 技能元数据
chunks     -- 内容片段（dependencies 用 JSON 数组）
vec_chunks -- 向量索引（sqlite-vec 虚拟表）
embeddings -- 向量回退存储（sqlite-vec 不可用时）
usage_stats -- 使用统计
reviews    -- 审核记录
```

**为什么不用 PostgreSQL：**
- 单文件、零配置、Python 内置
- sqlite-vec 对 <10 万条足够快
- 需要迁移时导出 JSON 即可

---

## 11. CLI

需要 `pip install skillvault[cli]`：

```bash
python -m skillvault.cli list
python -m skillvault.cli review-queue
python -m skillvault.cli approve draft::skill-id
python -m skillvault.cli reject draft::skill-id --reason "过时"
python -m skillvault.cli export skill-id output.json
python -m skillvault.cli import input.json
python -m skillvault.cli stats
```

---

## 12. 依赖

核心（必须）：
- `sqlite-vec` — 向量检索

可选：
- `openai` — OpenAI embedding
- `click` — CLI
- `sentence-transformers` — 本地 embedding

---

## 13. 设计原则

1. **一个类搞定** — `SkillManager`
2. **直接调用** — 没有事件、没有订阅、没有回调
3. **显式优于隐式** — `extract()` 由调用方显式调用
4. **默认 SQLite** — 不抽象存储
5. **注入而非内置** — `embed_fn`/`llm_fn` 由用户提供
6. **JSON 交换格式** — 方便迁移
7. **权限强制分离** — `mode` 参数控制

---

**文档版本**: v2.0
**最后更新**: 2026-04-18
