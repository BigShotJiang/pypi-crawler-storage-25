# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Development Commands

```bash
# Install in development mode
pip install -e ".[dev]"

# Run all tests
pytest

# Run a single test file
pytest tests/test_skill_manager.py

# Run a single test class
pytest tests/test_skill_manager.py::TestSkillManager -v

# Run a single test method
pytest tests/test_skill_manager.py::TestSkillManager::test_register_and_get -v

# Format code
black src/ tests/

# Lint
ruff check src/ tests/

# Run CLI (requires pip install skillvault[cli])
python -m skillvault.cli --help
python -m skillvault.cli stats
python -m skillvault.cli list

# Build package
python -m build
```

## Architecture Overview

Skillvault is a **local Python library** for agent skill management — not a SaaS or framework. It provides SQLite-based storage with vector search (sqlite-vec) for semantic skill retrieval, plus a self-growth mechanism where agents extract knowledge from conversations into draft skills for human review.

### Core Design: Two-Tier Skill System

The system enforces a strict separation between human-authored and agent-extracted knowledge:

- **Canonical skills** (`source="canonical"`) — Written by humans or approved through review. Always returned by default in `query()`.
- **Draft skills** (`source="draft"`) — Extracted by the growth engine from agent conversations. Only included in `query()` when `include_drafts=True`.

This two-tier design is enforced at the API level through a single class with a `mode` parameter:

- **`SkillManager(db_path, mode="admin")`** — Full permissions (human/admin use). Can `register()`, `approve()`, `reject()`, `archive()`.
- **`SkillManager(db_path, mode="agent")`** — Restricted permissions (agent code use). Can only `query()` (canonical only) and `extract()` (creates drafts). Admin methods raise `PermissionError`.

### Internal Modules

```
skillvault/
├── __init__.py      # Exports SkillManager, Skill, Chunk
├── models.py        # Skill, Chunk dataclasses
├── manager.py       # Core class (query/growth/review unified)
├── storage.py       # SQLite + sqlite-vec persistence
├── query.py         # Semantic search + context assembly (internal)
├── growth.py        # LLM-based extraction + auto-promote (internal)
└── cli.py           # CLI commands (requires [cli] extra)
```

### Dependency Injection

Both embedding and LLM analysis are injected via callables:

```python
from skillvault import SkillManager

# Custom embedding (e.g., local model, OpenAI, etc.)
def my_embed(text: str) -> list[float]:
    ...

# Custom LLM for extraction (optional)
def my_llm(text: str) -> dict:
    return {
        "has_knowledge": True,
        "title": "...",
        "playbook": "...",
        ...
    }

sm = SkillManager("skills.db", embed_fn=my_embed, llm_fn=my_llm)
```

If `embed_fn` is not provided and you attempt to embed, a `RuntimeError` is raised. Install the `openai` extra for a built-in OpenAI embed function, or provide your own.

### Query Flow (`SkillManager.query()`)

1. Embed query text via injected `embed_fn`
2. ANN search via sqlite-vec (or fallback cosine similarity)
3. Expand hard dependencies recursively (recursive CTE, max 3 hops)
4. Load required chunks for hit skills
5. Apply token budget: priority order is `required` > `hard_dep` > `vector` hits
6. Record usage for hit skills (drives auto-promotion)
7. Assemble into `<skill name="...">` XML blocks for direct LLM injection

### Growth Flow (`SkillManager.extract()`)

1. LLM analyzes context via injected `llm_fn` for reusable knowledge
2. Heuristic confidence scoring (length, code blocks, step-by-step markers, headers)
3. Duplicate detection via vector similarity against existing chunks
4. Save as draft skill with `source="draft"`
5. Store embeddings for each chunk
6. Check auto-promotion thresholds (single SQL UPDATE)

### Auto-Promotion

Drafts auto-promote to canonical via a single SQL UPDATE when:
- Usage count >= threshold (default 5, tracked in `usage_stats` table)
- Confidence >= threshold (default 0.9)

```sql
UPDATE skills SET source = 'canonical'
WHERE id = ? AND source = 'draft'
  AND confidence >= ?
  AND (SELECT COALESCE(query_count, 0) FROM usage_stats WHERE skill_id = skills.id) >= ?
```

### Data Model

- **Skill** — Top-level unit with `id`, `name`, `source`, `status`, `chunks`, `confidence`
- **Chunk** — Content fragment with `content`, `tokens`, `priority`, `required` flag, `dependencies` list
- Dependencies are stored as JSON arrays of chunk IDs in the `chunks` table; expansion uses recursive SQLite CTEs
- Embeddings stored in a `vec_chunks` virtual table (sqlite-vec) with fallback to a plain `embeddings` table

### CLI (`skillvault.cli`)

Requires `pip install skillvault[cli]`. Commands: `list`, `review-queue`, `approve`, `reject`, `export`, `import`, `stats`.

```bash
python -m skillvault.cli list
python -m skillvault.cli review-queue
```

## Key Files

- `src/skillvault/manager.py` — Public API (`SkillManager`)
- `src/skillvault/storage.py` — SQLite schema, vector search, dependency expansion
- `src/skillvault/query.py` — Context assembly and token budget logic (internal)
- `src/skillvault/growth.py` — LLM extraction and auto-promotion (internal)
- `src/skillvault/models.py` — `Skill` and `Chunk` dataclasses
- `FRAMEWORK_DESIGN.md` — Full design rationale and architecture decisions
- `AGENT_INTEGRATION_GUIDE.md` — Complete agent integration guide (self-growth, triggers, feedback)
- `pyproject.toml` — Build config (hatchling), deps, black/ruff settings (line-length: 100)
