"""Main SkillManager class - unified interface."""

from __future__ import annotations

from pathlib import Path
from typing import List, Optional, Union, Callable

from .models import Skill, Chunk
from .storage import SkillStorage
from .query import QueryEngine
from .growth import GrowthEngine


class SkillManager:
    """Unified skill management interface.

    Args:
        db_path: Path to SQLite database file.
        embed_fn: Function to generate embeddings (text -> list of floats).
                  If None, you must install the 'openai' extra or provide one.
        llm_fn: Optional function for LLM-based extraction (text -> analysis dict).
                If None, extract() will return None.
        mode: "admin" (full permissions, default) or "agent" (query + extract only).
        min_confidence: Minimum confidence threshold for extraction.
        auto_promote: Dict with "usage" and "confidence" thresholds for auto-promotion.
    """

    def __init__(
        self,
        db_path: str = "skills.db",
        embed_fn: Optional[Callable[[str], list[float]]] = None,
        llm_fn: Optional[Callable[[str], dict]] = None,
        mode: str = "admin",
        min_confidence: float = 0.7,
        auto_promote: Optional[dict] = None,
    ):
        if mode not in ("admin", "agent"):
            raise ValueError(f"mode must be 'admin' or 'agent', got {mode!r}")

        self.mode = mode
        self.storage = SkillStorage(db_path)
        self.query_engine = QueryEngine(self.storage, embed_fn)
        self.growth_engine = GrowthEngine(
            self.storage, min_confidence, embed_fn, llm_fn
        )
        self.auto_promote = auto_promote or {"usage": 5, "confidence": 0.9}

    def _require_admin(self, action: str) -> None:
        """Raise PermissionError if called in agent mode."""
        if self.mode == "agent":
            raise PermissionError(
                f"{action} is not allowed in agent mode. "
                "Use SkillManager(..., mode='admin') for full permissions."
            )

    # ── Query ──
    def query(
        self,
        text: str,
        budget: int = 4000,
        include_drafts: bool = False,
        top_k: int = 20,
        score_threshold: float = 0.4,
    ) -> str:
        """Query skills and return formatted context.

        In agent mode, drafts are always excluded regardless of include_drafts.
        """
        if self.mode == "agent":
            include_drafts = False

        return self.query_engine.query(
            text, budget, include_drafts, top_k, score_threshold
        )

    # ── Registration ──
    def register(
        self, skill: Union[Skill, str, Path], generate_embeddings: bool = True
    ) -> str:
        """Register a skill (object, JSON string, or file path)."""
        self._require_admin("register")

        if isinstance(skill, (str, Path)):
            path = Path(skill)
            if path.suffix == ".json":
                skill = Skill.from_json(path.read_text())
            else:
                skill = self._load_from_directory(path)

        self.storage.save_skill(skill)

        if generate_embeddings:
            for chunk in skill.chunks:
                embedding = self.query_engine.embed(chunk.content)
                self.storage.save_embedding(chunk.id, embedding)

        return skill.id

    def _load_from_directory(self, path: Path) -> Skill:
        """Load skill from directory containing SKILL.md."""
        md_file = path / "SKILL.md"
        if not md_file.exists():
            raise ValueError(f"No SKILL.md found in {path}")

        content = md_file.read_text()
        skill_id = path.name

        chunk = Chunk(
            id=f"{skill_id}::main",
            skill_id=skill_id,
            section=skill_id,
            content=content,
            tokens=len(content) // 4,
        )

        return Skill(id=skill_id, name=skill_id, chunks=[chunk])

    def get(self, skill_id: str) -> Optional[Skill]:
        """Get a skill by ID."""
        return self.storage.load_skill(skill_id)

    def list(self, source: Optional[str] = None, status: Optional[str] = None) -> List[Skill]:
        """List skills with optional filtering."""
        return self.storage.list_skills(source, status)

    # ── Growth ──
    def extract(
        self, context: Union[str, list[dict]], confidence_threshold: Optional[float] = None
    ) -> Optional[str]:
        """Extract knowledge from context, create draft."""
        draft_id = self.growth_engine.extract(context, confidence_threshold)

        if draft_id:
            self.growth_engine.check_auto_promote(
                draft_id,
                self.auto_promote.get("usage", 5),
                self.auto_promote.get("confidence", 0.9),
            )

        return draft_id

    # ── Review (admin only) ──
    def review_queue(self, limit: int = 10) -> List[Skill]:
        """Get pending drafts for review."""
        self._require_admin("review_queue")
        skills = self.storage.list_skills(source="draft", status="active")
        skills.sort(key=lambda s: s.confidence, reverse=True)
        return skills[:limit]

    def approve(self, skill_id: str) -> bool:
        """Approve draft -> canonical."""
        self._require_admin("approve")
        skill = self.storage.load_skill(skill_id)
        if not skill or skill.source != "draft":
            return False

        self.storage.conn.execute(
            "UPDATE skills SET source = 'canonical' WHERE id = ?", (skill_id,)
        )
        self.storage.conn.commit()
        self.storage.record_review(skill_id, "approve")
        return True

    def reject(self, skill_id: str, reason: str = "") -> bool:
        """Reject draft -> archived."""
        self._require_admin("reject")
        skill = self.storage.load_skill(skill_id)
        if not skill or skill.source != "draft":
            return False

        self.storage.conn.execute(
            "UPDATE skills SET status = 'archived' WHERE id = ?", (skill_id,)
        )
        self.storage.conn.commit()
        self.storage.record_review(skill_id, "reject", reason)
        return True

    def archive(self, skill_id: str) -> bool:
        """Archive a skill."""
        self._require_admin("archive")
        skill = self.storage.load_skill(skill_id)
        if not skill:
            return False

        self.storage.conn.execute(
            "UPDATE skills SET status = 'archived' WHERE id = ?", (skill_id,)
        )
        self.storage.conn.commit()
        return True

    # ── Import/Export ──
    def export(self, skill_id: str, path: str) -> None:
        """Export skill to JSON file."""
        self._require_admin("export")
        skill = self.get(skill_id)
        if not skill:
            raise ValueError(f"Skill not found: {skill_id}")
        Path(path).write_text(skill.to_json(), encoding="utf-8")

    def import_(self, path: str) -> str:
        """Import skill from JSON file."""
        self._require_admin("import_")
        json_text = Path(path).read_text(encoding="utf-8")
        skill = Skill.from_json(json_text)
        return self.register(skill)

    # ── Stats ──
    def stats(self) -> dict:
        """Get usage statistics."""
        cursor = self.storage.conn

        canonical = cursor.execute(
            "SELECT COUNT(*) FROM skills WHERE source = 'canonical' AND status = 'active'"
        ).fetchone()[0]

        draft = cursor.execute(
            "SELECT COUNT(*) FROM skills WHERE source = 'draft' AND status = 'active'"
        ).fetchone()[0]

        archived = cursor.execute(
            "SELECT COUNT(*) FROM skills WHERE status = 'archived'"
        ).fetchone()[0]

        chunks = cursor.execute("SELECT COUNT(*) FROM chunks").fetchone()[0]

        return {
            "canonical": canonical,
            "draft": draft,
            "archived": archived,
            "chunks": chunks,
            "pending_review": draft,  # all active drafts are pending review
        }

    def close(self) -> None:
        """Close resources."""
        self.storage.close()
