"""SQLite storage backend with optional sqlite-vec for vector search."""

import sqlite3
import json
import struct
import math
from pathlib import Path
from typing import List, Optional, Dict

try:
    import sqlite_vec
    SQLITE_VEC_AVAILABLE = True
except ImportError:
    SQLITE_VEC_AVAILABLE = False

from .models import Skill, Chunk


class SkillStorage:
    """SQLite-based skill storage with vector embeddings."""
    
    def __init__(self, db_path: str = "skills.db"):
        self.db_path = db_path
        self.conn = sqlite3.connect(db_path)
        self.conn.row_factory = sqlite3.Row
        self._has_sqlite_vec = False
        self._init_db()
    
    def _init_db(self):
        """Initialize database schema."""
        self.conn.execute("PRAGMA journal_mode=WAL")
        
        # Skills table
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS skills (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                source TEXT DEFAULT 'canonical',
                status TEXT DEFAULT 'active',
                confidence REAL DEFAULT 1.0,
                extracted_from TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Chunks table
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS chunks (
                id TEXT PRIMARY KEY,
                skill_id TEXT REFERENCES skills(id) ON DELETE CASCADE,
                section TEXT NOT NULL,
                content TEXT NOT NULL,
                tokens INTEGER NOT NULL,
                priority INTEGER DEFAULT 0,
                required INTEGER DEFAULT 0,
                dependencies TEXT DEFAULT '[]',
                score REAL
            )
        """)
        
        # Reviews table
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS reviews (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                skill_id TEXT,
                action TEXT,
                feedback TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Usage tracking
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS usage_stats (
                skill_id TEXT PRIMARY KEY,
                query_count INTEGER DEFAULT 0,
                last_used TIMESTAMP
            )
        """)
        
        # Embeddings table (fallback if sqlite-vec not available)
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS embeddings (
                chunk_id TEXT PRIMARY KEY REFERENCES chunks(id) ON DELETE CASCADE,
                embedding BLOB NOT NULL
            )
        """)
        
        self.conn.commit()
        
        # Try to initialize sqlite-vec
        self._init_sqlite_vec()
    
    def _init_sqlite_vec(self):
        """Try to initialize sqlite-vec extension."""
        if not SQLITE_VEC_AVAILABLE:
            return
        
        try:
            # Try to enable extension loading
            try:
                self.conn.enable_load_extension(True)
            except AttributeError:
                pass
            
            sqlite_vec.load(self.conn)
            self._has_sqlite_vec = True
            
            # Create vector virtual table
            self.conn.execute("""
                CREATE VIRTUAL TABLE IF NOT EXISTS vec_chunks
                USING vec0(embedding float[1536])
            """)
            self.conn.commit()
        except Exception:
            self._has_sqlite_vec = False
    
    def save_skill(self, skill: Skill) -> str:
        """Save or update a skill."""
        with self.conn:
            self.conn.execute("""
                INSERT OR REPLACE INTO skills 
                (id, name, source, status, confidence, extracted_from)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (skill.id, skill.name, skill.source, skill.status, 
                  skill.confidence, skill.extracted_from))
            
            # Delete old chunks
            self.conn.execute("DELETE FROM chunks WHERE skill_id = ?", (skill.id,))
            
            # Insert new chunks
            for chunk in skill.chunks:
                self.conn.execute("""
                    INSERT INTO chunks 
                    (id, skill_id, section, content, tokens, priority, required, dependencies)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """, (chunk.id, chunk.skill_id, chunk.section, chunk.content,
                      chunk.tokens, chunk.priority, int(chunk.required),
                      json.dumps(chunk.dependencies)))
        
        return skill.id
    
    def load_skill(self, skill_id: str) -> Optional[Skill]:
        """Load a skill by ID."""
        row = self.conn.execute(
            "SELECT * FROM skills WHERE id = ?", (skill_id,)
        ).fetchone()
        
        if not row:
            return None
        
        chunks = self._load_chunks(skill_id)
        
        return Skill(
            id=row["id"],
            name=row["name"],
            source=row["source"],
            status=row["status"],
            chunks=chunks,
            confidence=row["confidence"],
            extracted_from=row["extracted_from"],
        )
    
    def _load_chunks(self, skill_id: str) -> List[Chunk]:
        """Load chunks for a skill."""
        rows = self.conn.execute(
            "SELECT * FROM chunks WHERE skill_id = ?", (skill_id,)
        ).fetchall()
        
        chunks = []
        for row in rows:
            chunks.append(Chunk(
                id=row["id"],
                skill_id=row["skill_id"],
                section=row["section"],
                content=row["content"],
                tokens=row["tokens"],
                priority=row["priority"],
                required=bool(row["required"]),
                dependencies=json.loads(row["dependencies"]),
            ))
        
        return chunks
    
    def list_skills(self, source: Optional[str] = None, 
                    status: Optional[str] = None) -> List[Skill]:
        """List skills with optional filtering."""
        query = "SELECT id FROM skills WHERE 1=1"
        params = []
        
        if source:
            query += " AND source = ?"
            params.append(source)
        if status:
            query += " AND status = ?"
            params.append(status)
        
        rows = self.conn.execute(query, params).fetchall()
        
        skills = []
        for row in rows:
            skill = self.load_skill(row["id"])
            if skill:
                skills.append(skill)
        
        return skills
    
    def delete_skill(self, skill_id: str, soft: bool = True) -> None:
        """Delete a skill (soft delete by default)."""
        if soft:
            self.conn.execute(
                "UPDATE skills SET status = 'archived' WHERE id = ?",
                (skill_id,)
            )
        else:
            self.conn.execute("DELETE FROM skills WHERE id = ?", (skill_id,))
        self.conn.commit()
    
    def save_embedding(self, chunk_id: str, embedding: List[float]) -> None:
        """Save vector embedding for a chunk."""
        # Serialize float32
        vec_bytes = struct.pack(f"{len(embedding)}f", *embedding)
        
        if self._has_sqlite_vec:
            # Save to vec_chunks
            row = self.conn.execute(
                "SELECT rowid FROM chunks WHERE id = ?", (chunk_id,)
            ).fetchone()
            
            if row:
                self.conn.execute("""
                    INSERT OR REPLACE INTO vec_chunks (rowid, embedding)
                    VALUES (?, ?)
                """, (row["rowid"], vec_bytes))
                self.conn.commit()
        else:
            # Fallback: save to embeddings table
            self.conn.execute("""
                INSERT OR REPLACE INTO embeddings (chunk_id, embedding)
                VALUES (?, ?)
            """, (chunk_id, vec_bytes))
            self.conn.commit()
    
    def search_similar(self, query_embedding: List[float], 
                      top_k: int = 20, 
                      score_threshold: float = 0.4) -> List[dict]:
        """Search for similar chunks using ANN or fallback."""
        if self._has_sqlite_vec:
            return self._search_sqlite_vec(query_embedding, top_k, score_threshold)
        else:
            return self._search_fallback(query_embedding, top_k, score_threshold)
    
    def _search_sqlite_vec(self, query_embedding: List[float], 
                          top_k: int, score_threshold: float) -> List[dict]:
        """Search using sqlite-vec."""
        vec_bytes = struct.pack(f"{len(query_embedding)}f", *query_embedding)
        
        rows = self.conn.execute("""
            SELECT 
                c.id, c.skill_id, c.section, c.content,
                c.tokens, c.priority, c.required, c.dependencies,
                v.distance AS score
            FROM vec_chunks v
            JOIN chunks c ON c.rowid = v.rowid
            WHERE v.embedding MATCH ?
              AND v.k = ?
              AND v.distance < ?
            ORDER BY v.distance
        """, (vec_bytes, top_k, score_threshold)).fetchall()
        
        return [dict(row) for row in rows]
    
    def _search_fallback(self, query_embedding: List[float], 
                        top_k: int, score_threshold: float) -> List[dict]:
        """Fallback search using cosine similarity."""
        # Load all embeddings
        rows = self.conn.execute("""
            SELECT e.chunk_id, e.embedding, c.*
            FROM embeddings e
            JOIN chunks c ON c.id = e.chunk_id
        """).fetchall()
        
        results = []
        for row in rows:
            # Deserialize embedding
            emb_bytes = row["embedding"]
            emb = struct.unpack(f"{len(emb_bytes) // 4}f", emb_bytes)
            
            # Calculate cosine similarity
            similarity = self._cosine_similarity(query_embedding, emb)
            distance = 1 - similarity
            
            if distance < score_threshold:
                results.append({
                    "id": row["id"],
                    "skill_id": row["skill_id"],
                    "section": row["section"],
                    "content": row["content"],
                    "tokens": row["tokens"],
                    "priority": row["priority"],
                    "required": row["required"],
                    "dependencies": row["dependencies"],
                    "score": distance,
                })
        
        # Sort by score (lower is better)
        results.sort(key=lambda x: x["score"])
        return results[:top_k]
    
    @staticmethod
    def _cosine_similarity(a: List[float], b: List[float]) -> float:
        """Calculate cosine similarity between two vectors."""
        dot_product = sum(x * y for x, y in zip(a, b))
        magnitude_a = math.sqrt(sum(x * x for x in a))
        magnitude_b = math.sqrt(sum(x * x for x in b))
        
        if magnitude_a == 0 or magnitude_b == 0:
            return 0.0
        
        return dot_product / (magnitude_a * magnitude_b)
    
    def expand_dependencies(self, chunk_ids: List[str], 
                           max_depth: int = 3) -> List[dict]:
        """Recursively expand hard dependencies."""
        if not chunk_ids:
            return []
        
        placeholders = ",".join("?" * len(chunk_ids))
        
        # Use recursive CTE
        rows = self.conn.execute(f"""
            WITH RECURSIVE deps(id, depth) AS (
                SELECT id, 1
                FROM chunks
                WHERE id IN ({placeholders})
                
                UNION
                
                SELECT c.id, d.depth + 1
                FROM chunks c
                JOIN deps d ON c.id IN (
                    SELECT json_each.value 
                    FROM chunks parent, json_each(parent.dependencies)
                    WHERE parent.id = d.id
                )
                WHERE d.depth < ?
            )
            SELECT DISTINCT 
                c.id, c.skill_id, c.section, c.content,
                c.tokens, c.priority, c.required, c.dependencies
            FROM chunks c
            JOIN deps ON c.id = deps.id
            WHERE c.id NOT IN ({placeholders})
        """, chunk_ids + [max_depth] + chunk_ids).fetchall()
        
        return [dict(row) for row in rows]
    
    def load_required_chunks(self, skill_ids: List[str]) -> List[dict]:
        """Load required chunks for given skills."""
        if not skill_ids:
            return []
        
        placeholders = ",".join("?" * len(skill_ids))
        
        rows = self.conn.execute(f"""
            SELECT id, skill_id, section, content, tokens, priority, required, dependencies
            FROM chunks
            WHERE required = 1 AND skill_id IN ({placeholders})
        """, skill_ids).fetchall()
        
        return [dict(row) for row in rows]
    
    def record_usage(self, skill_id: str) -> None:
        """Record skill usage."""
        self.conn.execute("""
            INSERT INTO usage_stats (skill_id, query_count, last_used)
            VALUES (?, 1, datetime('now'))
            ON CONFLICT(skill_id) DO UPDATE SET
                query_count = query_count + 1,
                last_used = datetime('now')
        """, (skill_id,))
        self.conn.commit()
    
    def get_usage_stats(self, skill_id: str) -> dict:
        """Get usage stats for a skill."""
        row = self.conn.execute(
            "SELECT * FROM usage_stats WHERE skill_id = ?", (skill_id,)
        ).fetchone()
        
        if row:
            return dict(row)
        return {"skill_id": skill_id, "query_count": 0, "last_used": None}
    
    def record_review(self, skill_id: str, action: str, feedback: str = "") -> None:
        """Record a review action."""
        self.conn.execute("""
            INSERT INTO reviews (skill_id, action, feedback)
            VALUES (?, ?, ?)
        """, (skill_id, action, feedback))
        self.conn.commit()
    
    def close(self):
        """Close database connection."""
        self.conn.close()
