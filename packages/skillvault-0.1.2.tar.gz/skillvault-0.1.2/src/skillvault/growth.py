"""Skill growth engine for automatic knowledge extraction."""

import json
from typing import List, Optional, Union, Callable

from .models import Skill, Chunk
from .storage import SkillStorage


class GrowthEngine:
    """Extract knowledge from context to create draft skills."""

    def __init__(self, storage: SkillStorage,
                 min_confidence: float = 0.7,
                 embed_fn: Optional[Callable[[str], List[float]]] = None,
                 llm_fn: Optional[Callable[[str], dict]] = None):
        self.storage = storage
        self.min_confidence = min_confidence
        self.embed_fn = embed_fn
        self.llm_fn = llm_fn
    
    def extract(self, context: Union[str, List[dict]], 
                confidence_threshold: Optional[float] = None) -> Optional[str]:
        """Extract skill from context. Returns draft_id or None."""
        threshold = confidence_threshold or self.min_confidence
        
        # Format context
        if isinstance(context, list):
            context_text = self._format_dialog(context)
        else:
            context_text = context
        
        # Step 1: Analyze with LLM
        analysis = self._analyze_content(context_text)
        if not analysis.get("has_knowledge", False):
            return None
        
        # Step 2: Evaluate confidence
        score = self._evaluate_confidence(analysis)
        if score < threshold:
            return None
        
        # Step 3: Check for duplicates
        if self._is_duplicate(analysis.get("content", "")):
            return None
        
        # Step 4: Create draft skill
        draft = self._create_draft(analysis, score, context_text)
        self.storage.save_skill(draft)
        
        # Save embedding for chunks
        for chunk in draft.chunks:
            embedding = self._embed(chunk.content)
            self.storage.save_embedding(chunk.id, embedding)
        
        return draft.id
    
    def _format_dialog(self, messages: List[dict]) -> str:
        """Format dialog messages to text."""
        lines = []
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            lines.append(f"{role}: {content}")
        return "\n".join(lines)
    
    def _analyze_content(self, text: str) -> dict:
        """Use LLM to analyze if content contains reusable knowledge."""
        if self.llm_fn is None:
            return {"has_knowledge": False}
        try:
            return self.llm_fn(text)
        except Exception:
            return {"has_knowledge": False}
    
    def _evaluate_confidence(self, analysis: dict) -> float:
        """Evaluate confidence score of extracted knowledge."""
        # Build full content from structured parts for scoring
        parts = [
            analysis.get("playbook", ""),
            analysis.get("examples", ""),
            analysis.get("when_to_use", ""),
            analysis.get("summary", ""),
        ]
        content = "\n".join(p for p in parts if p)
        if not content:
            content = analysis.get("content", "")

        scores = []

        # Completeness: length and structure
        if len(content) > 400:
            scores.append(0.3)
        elif len(content) > 200:
            scores.append(0.25)
        elif len(content) > 100:
            scores.append(0.15)
        else:
            scores.append(0.05)

        # Has code examples
        if "```" in content:
            scores.append(0.25)

        # Has step-by-step instructions
        if any(marker in content for marker in ["1.", "2.", "Step", "步骤", "- "]):
            scores.append(0.2)

        # Has markdown headers
        if "##" in content or "###" in content:
            scores.append(0.1)

        # Has clear applicability description
        if analysis.get("when_to_use") and len(analysis["when_to_use"]) > 20:
            scores.append(0.1)

        # Has concrete scenarios
        if analysis.get("applicable_scenarios"):
            scores.append(0.1)

        return min(sum(scores), 1.0)
    
    def _is_duplicate(self, content: str) -> bool:
        """Check if content is duplicate of existing chunks."""
        # Simple check: search for similar content
        try:
            embedding = self._embed(content)
            results = self.storage.search_similar(embedding, top_k=1, score_threshold=0.15)
            return len(results) > 0
        except Exception:
            return False
    
    def _create_draft(self, analysis: dict, confidence: float,
                     source_text: str) -> Skill:
        """Create a draft skill from analysis with structured SKILL.md format."""
        import hashlib

        # Generate ID
        title = analysis.get("title", "Extracted Skill")
        skill_id = f"draft::{hashlib.md5(title.encode()).hexdigest()[:8]}"

        # Parse dependencies
        deps = analysis.get("dependencies", [])
        if isinstance(deps, str):
            deps = [d.strip() for d in deps.split(",") if d.strip()]
        deps = [d for d in deps if isinstance(d, str)]

        # Build structured SKILL.md content
        parts = [f"# {title}"]

        if analysis.get("summary"):
            parts.append(f"\n## Summary\n\n{analysis['summary']}")

        if analysis.get("when_to_use"):
            parts.append(f"\n## When to Use\n\n{analysis['when_to_use']}")

        playbook = analysis.get("playbook", analysis.get("content", ""))
        if playbook:
            parts.append(f"\n## Playbook\n\n{playbook}")

        if analysis.get("examples"):
            parts.append(f"\n## Examples\n\n{analysis['examples']}")

        if analysis.get("applicable_scenarios"):
            scenarios = analysis["applicable_scenarios"]
            if isinstance(scenarios, list):
                scenario_text = "\n".join(f"- {s}" for s in scenarios)
                parts.append(f"\n## Applicable Scenarios\n\n{scenario_text}")

        if deps:
            dep_text = "\n".join(f"- {d}" for d in deps)
            parts.append(f"\n## Dependencies\n\n{dep_text}")

        structured_content = "\n".join(parts)

        # Create chunks: main content + metadata
        chunks = []

        # Main playbook chunk
        chunks.append(Chunk(
            id=f"{skill_id}::playbook",
            skill_id=skill_id,
            section="Playbook",
            content=playbook if playbook else structured_content,
            tokens=len(playbook if playbook else structured_content) // 4,
            priority=0,
            required=True,
            dependencies=deps,
        ))

        # Full structured document chunk
        chunks.append(Chunk(
            id=f"{skill_id}::manifest",
            skill_id=skill_id,
            section="Manifest",
            content=structured_content,
            tokens=len(structured_content) // 4,
            priority=1,
        ))

        return Skill(
            id=skill_id,
            name=title,
            source="draft",
            status="active",
            chunks=chunks,
            confidence=confidence,
            extracted_from=source_text[:200],
        )
    
    def _embed(self, text: str) -> List[float]:
        """Create embedding for text."""
        if self.embed_fn is None:
            raise RuntimeError("No embed_fn provided. Pass one to SkillManager or install openai extra.")
        return self.embed_fn(text)

    def check_auto_promote(self, skill_id: str,
                          usage_threshold: int = 5,
                          confidence_threshold: float = 0.9) -> bool:
        """Auto-promote draft to canonical if usage and confidence thresholds are met."""
        cursor = self.storage.conn.execute(
            """UPDATE skills SET source = 'canonical'
                WHERE id = ? AND source = 'draft'
                  AND confidence >= ?
                  AND (SELECT COALESCE(query_count, 0)
                       FROM usage_stats WHERE skill_id = skills.id) >= ?""",
            (skill_id, confidence_threshold, usage_threshold)
        )
        self.storage.conn.commit()
        return cursor.rowcount > 0

    def archive_old_drafts(self, ttl_days: int = 30) -> int:
        """Archive drafts older than TTL. Returns count archived."""
        cursor = self.storage.conn.execute("""
            UPDATE skills
            SET status = 'archived'
            WHERE source = 'draft'
              AND status = 'active'
              AND created_at < datetime('now', ?)
        """, (f'-{ttl_days} days',))

        self.storage.conn.commit()
        return cursor.rowcount
