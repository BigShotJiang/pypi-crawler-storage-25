"""Skill Manager - Agent Skill Management System."""

from .models import Skill, Chunk
from .manager import SkillManager

__version__ = "0.1.2"
__all__ = [
    "SkillManager",
    "Skill",
    "Chunk",
]
