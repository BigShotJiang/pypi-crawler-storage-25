## ADDED Requirements

### Requirement: Agent restricted access
The system SHALL provide a restricted client for Agent code that limits write access.

#### Scenario: AgentSkillClient blocks canonical writes
- **WHEN** Agent code uses AgentSkillClient
- **THEN** the client SHALL NOT expose approve(), reject(), register(), or delete() methods

#### Scenario: AgentSkillClient defaults to canonical-only queries
- **WHEN** Agent calls query() through AgentSkillClient
- **THEN** include_drafts SHALL default to False

### Requirement: Full access for humans
The system SHALL provide full access through SkillManager for human operators.

#### Scenario: SkillManager has all methods
- **WHEN** human uses SkillManager directly
- **THEN** all methods including approve(), reject(), register(), delete() SHALL be available

### Requirement: Permission enforcement at code level
The system SHALL enforce permissions through class design rather than runtime checks.

#### Scenario: Missing method raises AttributeError
- **WHEN** Agent code attempts to call agent_client.approve()
- **THEN** Python SHALL raise AttributeError at runtime

### Requirement: Auto-promotion safety
The system SHALL ensure auto-promotion does not bypass human oversight for conflicting content.

#### Scenario: Conflict requires human review
- **WHEN** auto-promotion detects a conflict with existing canonical content
- **THEN** the draft SHALL remain in review queue for human decision
