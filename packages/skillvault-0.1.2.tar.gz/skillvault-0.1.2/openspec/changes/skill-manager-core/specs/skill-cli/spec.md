## ADDED Requirements

### Requirement: List Skills command
The CLI SHALL support listing Skills with filtering options.

#### Scenario: List all Skills
- **WHEN** user runs `skill-cli list`
- **THEN** the CLI SHALL display all active Skills with their source and status

#### Scenario: Filter by source
- **WHEN** user runs `skill-cli list --source draft`
- **THEN** the CLI SHALL display only draft Skills

### Requirement: Review queue command
The CLI SHALL display the review queue for human operators.

#### Scenario: Show review queue
- **WHEN** user runs `skill-cli review-queue`
- **THEN** the CLI SHALL display pending drafts with confidence scores and previews

### Requirement: Approve and reject commands
The CLI SHALL support approving and rejecting draft Skills.

#### Scenario: Approve via CLI
- **WHEN** user runs `skill-cli approve draft::react_hooks`
- **THEN** the draft SHALL be promoted to canonical

#### Scenario: Reject via CLI
- **WHEN** user runs `skill-cli reject draft::bad_practice --reason "outdated"`
- **THEN** the draft SHALL be archived with the provided reason

### Requirement: Import and export commands
The CLI SHALL support importing and exporting Skills via JSON files.

#### Scenario: Export a Skill
- **WHEN** user runs `skill-cli export frontend-react > react.json`
- **THEN** the Skill SHALL be exported to JSON format

#### Scenario: Import a Skill
- **WHEN** user runs `skill-cli import react.json`
- **THEN** the Skill SHALL be imported from the JSON file

### Requirement: Statistics command
The CLI SHALL display usage statistics.

#### Scenario: Show stats
- **WHEN** user runs `skill-cli stats`
- **THEN** the CLI SHALL display counts of canonical/draft/archived Skills and chunks
