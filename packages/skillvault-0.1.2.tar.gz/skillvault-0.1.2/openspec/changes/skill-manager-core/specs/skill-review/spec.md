## ADDED Requirements

### Requirement: Review queue management
The system SHALL provide a review queue for pending draft Skills.

#### Scenario: List pending drafts
- **WHEN** user calls `review_queue(limit=10)`
- **THEN** the system SHALL return draft Skills sorted by confidence (highest first)

### Requirement: Approve draft Skills
The system SHALL allow humans to approve draft Skills, moving them to canonical.

#### Scenario: Approve a draft
- **WHEN** user calls `approve(draft_id)`
- **THEN** the draft Skill SHALL be moved to canonical status

#### Scenario: Approve creates review record
- **WHEN** user approves a draft
- **THEN** the system SHALL record the approval action in the reviews table

### Requirement: Reject draft Skills
The system SHALL allow humans to reject draft Skills, archiving them.

#### Scenario: Reject a draft
- **WHEN** user calls `reject(draft_id, reason="outdated")`
- **THEN** the draft Skill SHALL be marked as archived

#### Scenario: Reject with feedback
- **WHEN** user rejects with a reason
- **THEN** the system SHALL store the reason in the review record

### Requirement: Archive canonical Skills
The system SHALL support archiving canonical Skills that are outdated.

#### Scenario: Manual archive
- **WHEN** user archives a canonical Skill
- **THEN** the Skill status SHALL change to "archived" and it SHALL not appear in query results
