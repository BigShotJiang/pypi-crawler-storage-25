## ADDED Requirements

### Requirement: Semantic search with ANN
The system SHALL perform Approximate Nearest Neighbor search using sqlite-vec.

#### Scenario: Query returns relevant Skills
- **WHEN** user calls `query(text="React hooks", budget=4000)`
- **THEN** the system SHALL return a formatted string containing relevant Skill content

#### Scenario: Query respects budget limit
- **WHEN** user calls `query(text="React", budget=1000)`
- **THEN** the returned content SHALL not exceed 1000 tokens

### Requirement: Dependency expansion
The system SHALL recursively expand hard dependencies when querying.

#### Scenario: Hard dependency expansion
- **WHEN** a queried Chunk has hard_dep dependencies
- **THEN** the system SHALL load those dependency Chunks automatically

#### Scenario: Dependency depth limit
- **WHEN** dependency chain exceeds 3 levels
- **THEN** the system SHALL stop expanding beyond depth 3

### Requirement: Token budget cropping
The system SHALL prioritize and crop Chunks based on available token budget.

#### Scenario: Required chunks loaded first
- **WHEN** query budget is limited
- **THEN** required chunks SHALL be loaded before ANN results

#### Scenario: Priority-based loading
- **WHEN** multiple chunks compete for remaining budget
- **THEN** chunks with lower priority values SHALL be loaded first

### Requirement: Draft exclusion by default
The system SHALL exclude draft Skills from query results unless explicitly requested.

#### Scenario: Default query excludes drafts
- **WHEN** user calls `query()` without include_drafts parameter
- **THEN** only canonical Skills SHALL be included

#### Scenario: Explicit draft inclusion
- **WHEN** user calls `query(include_drafts=True)`
- **THEN** draft Skills MAY be included with their confidence scores
