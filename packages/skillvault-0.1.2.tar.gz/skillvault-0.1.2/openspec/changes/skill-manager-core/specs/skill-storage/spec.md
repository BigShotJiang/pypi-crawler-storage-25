## ADDED Requirements

### Requirement: Skill 数据模型定义
The system SHALL define `Skill` and `Chunk` data classes with all required fields.

#### Scenario: Create a Skill object
- **WHEN** user creates a Skill with id="frontend-react", name="Frontend React", source="canonical"
- **THEN** the Skill object SHALL contain the provided fields and default values for optional fields

#### Scenario: Skill contains Chunks
- **WHEN** user creates a Skill with a list of Chunk objects
- **THEN** each Chunk SHALL have id, skill_id, section, content, tokens, priority, required, and dependencies fields

### Requirement: Skill CRUD operations
The system SHALL support Create, Read, Update, Delete operations for Skills.

#### Scenario: Register a new Skill
- **WHEN** user calls `register(skill)` with a valid Skill object
- **THEN** the Skill SHALL be persisted to the database and return the skill_id

#### Scenario: Retrieve a Skill by ID
- **WHEN** user calls `get(skill_id)` with an existing skill_id
- **THEN** the system SHALL return the complete Skill object with all Chunks

#### Scenario: List all Skills
- **WHEN** user calls `list()` without filters
- **THEN** the system SHALL return all active Skills

#### Scenario: List filtered Skills
- **WHEN** user calls `list(source="draft", status="active")`
- **THEN** the system SHALL return only active draft Skills

### Requirement: Skill import and export
The system SHALL support importing Skills from JSON files and exporting Skills to JSON.

#### Scenario: Export a Skill to JSON
- **WHEN** user calls `export(skill_id, "path/to/file.json")`
- **THEN** the system SHALL write a JSON file containing the complete Skill data

#### Scenario: Import a Skill from JSON
- **WHEN** user calls `import_("path/to/file.json")`
- **THEN** the system SHALL read the JSON file and register the Skill

### Requirement: SQLite storage schema
The system SHALL create and manage SQLite tables for skills, chunks, and vector embeddings.

#### Scenario: Initialize database
- **WHEN** user creates a new SkillManager with a non-existent database path
- **THEN** the system SHALL create all required tables: skills, chunks, vec_chunks, reviews

#### Scenario: Chunk dependencies stored as JSON
- **WHEN** user registers a Skill with Chunk dependencies
- **THEN** the dependencies SHALL be stored as a JSON array in the chunks table
