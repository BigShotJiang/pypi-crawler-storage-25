## ADDED Requirements

### Requirement: Extract knowledge from context
The system SHALL analyze context and extract reusable knowledge as draft Skills.

#### Scenario: Extract from dialog history
- **WHEN** user calls `extract(messages)` with a list of dialog messages
- **THEN** if the content contains reusable knowledge, the system SHALL create a draft Skill

#### Scenario: Low confidence extraction rejected
- **WHEN** extracted content has confidence below min_confidence (default 0.7)
- **THEN** the system SHALL return None and not create a draft

### Requirement: Confidence evaluation
The system SHALL evaluate the quality of extracted knowledge.

#### Scenario: Content completeness scoring
- **WHEN** evaluating extracted content
- **THEN** the system SHALL score based on length, structure, code examples, and step-by-step instructions

#### Scenario: Duplicate detection
- **WHEN** extracted content is similar to existing chunks
- **THEN** the system SHALL reject the extraction to avoid duplication

### Requirement: Auto-promotion rules
The system SHALL automatically promote draft Skills to canonical when criteria are met.

#### Scenario: Auto-promote based on usage and confidence
- **WHEN** a draft has been used >= 5 times AND confidence >= 0.9
- **THEN** the system SHALL automatically promote it to canonical

#### Scenario: Auto-archive old drafts
- **WHEN** a draft has been pending for >= 30 days
- **THEN** the system SHALL archive it automatically

### Requirement: Conflict detection before promotion
The system SHALL check for conflicts with existing canonical Skills before promotion.

#### Scenario: Conflict blocks auto-promotion
- **WHEN** auto-promoting a draft that conflicts with existing canonical content
- **THEN** the system SHALL mark it for manual review instead of auto-promoting
