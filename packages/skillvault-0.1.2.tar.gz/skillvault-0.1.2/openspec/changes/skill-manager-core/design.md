## Context

Agent 系统需要将零散的操作知识沉淀为结构化、可复用的 Skill。当前方案通过 prompt 注入知识，导致：
- 知识分散在各个 prompt 模板中，难以维护
- 无法根据查询动态加载最相关的知识片段
- 无法从运行中自动学习和沉淀新知识
- 缺乏质量管控机制，错误知识可能污染系统

本设计构建一个本地 Skill 管理库，解决上述问题。

## Goals / Non-Goals

**Goals:**
- 提供单一 `SkillManager` 类，20 个方法以内，简化使用
- 支持 Skill 的存储、查询、自生长、审核完整生命周期
- 实现双轨架构：canonical（高质量，人工管理）+ draft（待验证，Agent 提取）
- 使用 SQLite + sqlite-vec 实现本地存储和语义检索
- 支持 Chunk 级别的依赖展开和 Token Budget 裁剪
- 权限分离：Agent 只能写 draft，canonical 写入权只属于人类
- 提供 CLI 工具支持人工管理

**Non-Goals:**
- 多租户支持
- 分布式部署
- 实时协作编辑
- 内置大量 Agent 框架 Adapter（只提供示例模板）
- 版本管理（v2 考虑）
- 多模态 Skill（图片、视频）

## Decisions

### 1. 单一 SkillManager 类而非多接口
**选择**：合并 SkillRegistry + QueryEngine + ContextAssembler 为一个类
**理由**：减少认知负担，一个类搞定所有交互。存储细节封装在内部。

### 2. 显式调用 extract() 而非事件驱动
**选择**：Agent 代码显式调用 `extract()`，不自动触发
**理由**：事件系统 = 额外复杂度（订阅、发布、队列、异步）。Agent 代码清楚何时应该提取，直接调用更简单可控。

### 3. SQLite + sqlite-vec 作为默认存储
**选择**：单文件 SQLite，不抽象存储层
**理由**：零配置、Python 标准库内置、足够快（<10 万条）。如果未来需要 PostgreSQL，通过 JSON 导入导出迁移。

### 4. Chunk 级别依赖而非 Skill 级别
**选择**：依赖关系存储在 Chunk 上，展开时递归加载
**理由**：更细粒度，避免加载整个 Skill。支持跨 Skill 依赖（如通用错误处理模式）。

### 5. AgentSkillClient 受限类
**选择**：通过两个类分离权限，而非 RBAC 或 ACL
**理由**：简单直接，代码层面强制约束。Agent 初始化时只获得受限客户端，无法调用 approve/register/delete。

### 6. 配置字典而非策略接口
**选择**：auto_promote 用配置字典 `{"usage": 5, "confidence": 0.9}`
**理由**：99% 场景用默认规则，不需要策略模式的开销。

## Risks / Trade-offs

- **[Risk] SQLite 并发写入性能** → **Mitigation**：WAL 模式，Agent 的 extract() 是低频操作（只在对话结束/任务成功时调用）
- **[Risk] LLM 提取质量不稳定** → **Mitigation**：置信度评估 + 重复检测 + 人工审核，draft 默认不加载
- **[Risk] Embedding 成本** → **Mitigation**：默认使用 text-embedding-3-small，支持本地模型切换
- **[Risk] Agent 自我欺骗** → **Mitigation**：权限分离，Agent 无法写入 canonical，自动提升前检查冲突
- **[Trade-off] 功能完整 vs 复杂度** → 选择：砍掉版本管理、多存储后端、事件系统等，保持核心简洁

## Migration Plan

- 无迁移（新建项目）
- 未来如需迁移存储：使用 `export()` / `import_()` JSON 格式

## Open Questions

- 是否需要在 v0.1 支持本地 Embedding 模型？（可以先只用 OpenAI）
- 自动提升规则的具体阈值是否需要可配置？（已实现配置字典）
