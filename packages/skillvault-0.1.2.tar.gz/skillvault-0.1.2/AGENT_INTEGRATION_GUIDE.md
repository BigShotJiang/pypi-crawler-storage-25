# Agent Integration Guide

Complete integration guide for connecting agent systems to skillvault — covering initialization, permission separation, query injection, self-growth, and feedback loops.

**Version**: 0.2.0 | **License**: MIT

Use this skill when building or modifying an agent system that needs to integrate with skillvault for skill storage, retrieval, and self-growth.

---

## What skillvault Provides

skillvault is a **local Python library** (not a service) that gives your agent three capabilities:

1. **Semantic skill retrieval** — Query a local SQLite database with vector search to get relevant skills as formatted context for LLM prompts
2. **Self-growth** — Extract reusable knowledge from agent conversations and tasks into draft skills
3. **Human-in-the-loop governance** — Draft skills require human approval before becoming canonical; agents cannot bypass this

**Key constraint**: Agents have restricted permissions. They can read canonical skills and write drafts, but they cannot approve, reject, or directly write canonical skills. This prevents echo-chamber effects where bad agent outputs feed back into the knowledge base.

---

## Integration Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Your Agent System                         │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │
│  │   LLM Call  │  │  Task Logic │  │  Conversation Loop  │  │
│  └──────┬──────┘  └──────┬──────┘  └──────────┬──────────┘  │
│         │                │                    │             │
│         ▼                ▼                    ▼             │
│  ┌──────────────────────────────────────────────────────┐  │
│  │         SkillManager(mode="agent") (restricted)       │  │
│  │  • query(text) → returns skill context               │  │
│  │  • extract(context) → creates draft skill            │  │
│  │  • CANNOT: approve, reject, register, archive        │  │
│  └────────────────────────┬─────────────────────────────┘  │
│                           │                                  │
└───────────────────────────┼──────────────────────────────────┘
                            ▼
                   ┌─────────────────┐
                   │  SkillManager   │  ← Human/admin only
                   │  (mode="admin") │
                   └────────┬────────┘
                            ▼
                   ┌─────────────────┐
                   │   skills.db     │
                   │  SQLite + vec   │
                   └─────────────────┘
```

---

## Step-by-Step Integration

### Step 1: Initialize the SkillManager

Create a `SkillManager` instance in your agent system. You must provide an `embed_fn` (embedding function) since the core package no longer bundles OpenAI.

```python
from skillvault import SkillManager

# Example: OpenAI embedding (requires pip install skillvault[openai])
from openai import OpenAI
openai_client = OpenAI()

def embed_fn(text: str) -> list[float]:
    resp = openai_client.embeddings.create(
        model="text-embedding-3-small",
        input=[text]
    )
    return resp.data[0].embedding

# Initialize (creates skills.db if not exists)
sm = SkillManager(
    db_path="skills.db",
    embed_fn=embed_fn,
    mode="agent",  # Restricted permissions
    min_confidence=0.7,
    auto_promote={"usage": 5, "confidence": 0.9}
)
```

**When to call**: Once at agent system startup. Reuse the same instance across the process lifetime.

---

### Step 2: Inject Skills into LLM Prompts

Before every LLM call, query skillvault for relevant skills and inject them into the system prompt.

```python
import anthropic

client = anthropic.Anthropic()

def call_llm(user_input: str, conversation_history: list) -> str:
    # Query relevant skills (canonical only, drafts excluded by default)
    skill_context = sm.query(
        text=user_input,
        budget=3000,           # Remaining token budget for skills
        top_k=20,              # Max candidate chunks
        score_threshold=0.4    # Minimum similarity score
    )

    # Build system prompt with skill context
    system_prompt = f"""You are a helpful assistant.

<skills>
{skill_context}
</skills>

Use the above skills when relevant to the user's request."""

    response = client.messages.create(
        model="claude-sonnet-4",
        system=system_prompt,
        messages=conversation_history + [{"role": "user", "content": user_input}]
    )

    return response.content[0].text
```

**What `query()` returns**:

```xml
<skill name="frontend-react">
## React Hooks

Use useEffect for side effects...
</skill>

<skill name="python-error-handling">
## Exception Patterns

Always catch specific exceptions...
</skill>
```

**Key behaviors**:
- Returns empty string if no skills match
- Automatically filters out draft skills (agents should not use unverified knowledge)
- Automatically expands hard dependencies (if a chunk depends on another, both are included)
- Applies token budget: `required` chunks > `hard_dep` chunks > vector search hits
- Records usage statistics for auto-promotion

---

### Step 3: Self-Growth — Extract Knowledge Explicitly

Unlike earlier versions, skillvault **does not** automatically decide when to extract. Your agent code decides when a conversation or task contains valuable knowledge worth saving.

```python
# After a complex multi-turn conversation
if len(messages) >= 5:
    draft_id = sm.extract(messages)
    if draft_id:
        log.info(f"Extracted draft skill: {draft_id}")

# After a user correction (high-signal learning moment)
draft_id = sm.extract(
    f"Original (wrong): {original_output}\n\nCorrection: {user_correction}",
    confidence_threshold=0.5  # Lower bar for corrections
)
```

**When to extract**:
- After a complex multi-step task (many tool calls, many turns)
- After a user correction — corrections are the highest-quality learning signal
- After a novel problem-solving session that produced reusable patterns

**What `extract()` does**:
1. If you provided `llm_fn` during initialization, it analyzes context with LLM for reusable knowledge
2. Heuristic confidence scoring (length, code blocks, step-by-step markers)
3. Duplicate detection via vector similarity
4. Saves as draft skill with `source="draft"`
5. Checks auto-promotion thresholds (usage + confidence)
6. Returns `draft_id` or `None` if content fails quality gates

**Note**: If you did not provide `llm_fn`, `extract()` returns `None`. You can either:
- Provide a custom `llm_fn` that analyzes text and returns a structured dict
- Handle extraction entirely outside skillvault and call `sm.register(skill)` via an admin client

---

### Step 4: Admin Operations (Human/Admin Code)

For human review and management, use `mode="admin"` (or the same `SkillManager` instance in admin code):

```python
# Admin mode (separate process or elevated privilege)
admin = SkillManager(
    db_path="skills.db",
    embed_fn=embed_fn,
    mode="admin"
)

# Review pending drafts
pending = admin.review_queue(limit=10)
for draft in pending:
    print(f"{draft.id}: {draft.name} (confidence: {draft.confidence:.2f})")

# Approve or reject
admin.approve("draft::a3f7b2d1")
admin.reject("draft::a3f7b2d1", reason="Too specific, not reusable")

# Register canonical skills
from skillvault.models import Skill, Chunk
skill = Skill(
    id="my-skill",
    name="My Skill",
    chunks=[Chunk(
        id="my-skill::main",
        skill_id="my-skill",
        section="Main",
        content="...",
        tokens=100
    )]
)
admin.register(skill)
```

---

## Complete Integration Example

```python
#!/usr/bin/env python3
"""Complete agent integration with skillvault self-growth."""

import os
import anthropic
from openai import OpenAI
from skillvault import SkillManager

# Embedding function (OpenAI)
openai_client = OpenAI()

def embed_fn(text: str) -> list[float]:
    resp = openai_client.embeddings.create(
        model="text-embedding-3-small", input=[text]
    )
    return resp.data[0].embedding


class SelfGrowingAgent:
    def __init__(self, db_path: str = "skills.db"):
        # Initialize skillvault in agent mode
        self.sm = SkillManager(
            db_path=db_path,
            embed_fn=embed_fn,
            mode="agent"
        )

        # LLM client
        self.llm = anthropic.Anthropic()

    def run(self):
        """Main conversation loop with self-growth."""
        messages = []

        print("Agent ready. Type 'exit' to quit.")

        while True:
            user_input = input("\nUser: ").strip()
            if user_input.lower() in ("exit", "quit"):
                break

            # Generate response with skill injection
            response = self._generate_response(user_input, messages)
            print(f"Agent: {response}")

            # Track conversation for potential extraction
            messages.extend([
                {"role": "user", "content": user_input},
                {"role": "assistant", "content": response}
            ])

            # Extract after substantial conversations
            if len(messages) >= 10:
                draft_id = self.sm.extract(messages)
                if draft_id:
                    print(f"  [Growth] Extracted draft: {draft_id}")

        # Final extraction attempt
        if len(messages) >= 5:
            final_draft = self.sm.extract(messages)
            if final_draft:
                print(f"  [Growth] Final extraction: {final_draft}")

        self.sm.close()

    def _generate_response(self, user_input: str, messages: list) -> str:
        """Call LLM with skillvault context injection."""
        # Query relevant skills
        skills = self.sm.query(user_input, budget=3000)

        system = f"""You are a helpful assistant.

Relevant skills:
{skills}"""

        response = self.llm.messages.create(
            model="claude-sonnet-4",
            system=system,
            messages=messages + [{"role": "user", "content": user_input}],
            max_tokens=4000
        )

        return response.content[0].text


if __name__ == "__main__":
    agent = SelfGrowingAgent()
    agent.run()
```

---

## Self-Growth Lifecycle

skillvault implements a self-growth lifecycle:

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│  Perception │────▶│Crystallization│───▶│   Weaving   │
│ (your code) │     │  (LLM提取)   │     │  (存储draft) │
└─────────────┘     └─────────────┘     └──────┬──────┘
                                               │
                                               ▼
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│  Evolution  │◀────│  Validation │◀────│   (人类审核)  │
│(自动提升/归档)│     │  (质量+使用)  │     │             │
└─────────────┘     └─────────────┘     └─────────────┘
```

### Phase 1: Perception (感知)

**What**: Your agent code decides when to call `extract()`.

**When to trigger**:
- Conversation depth >= 5 turns (complex problem-solving)
- Tool call complexity is high (multi-step task)
- User correction detected (highest-quality signal)

**Agent action**: Call `sm.extract(context)` when you judge the conversation contains reusable knowledge.

---

### Phase 2: Crystallization (结晶)

**What**: If `llm_fn` is provided, it analyzes context with LLM to extract structured knowledge.

**Expected `llm_fn` output**:
```python
{
    "has_knowledge": True,
    "title": "Skill name",
    "summary": "One-line description",
    "when_to_use": "Applicable scenarios",
    "playbook": "Step-by-step instructions",
    "examples": "Code examples",
    "dependencies": ["skill-id-1"],
    "applicable_scenarios": ["scenario 1"]
}
```

**Agent action**: Provide `llm_fn` during initialization, or handle extraction externally.

---

### Phase 3: Weaving (编织)

**What**: The extracted knowledge is saved as a draft skill with structured chunks.

**What gets stored**:
- `playbook` chunk (required, with dependencies) — the core actionable content
- `manifest` chunk — full structured document for display
- Both chunks get vector embeddings for future retrieval

**Agent action**: Returns `draft_id` (e.g., `draft::a3f7b2d1`). Returns `None` if extraction fails quality gates.

---

### Phase 4: Validation (验证)

**What**: Heuristic confidence scoring and duplicate detection.

**Checks**:

| Check | Description | Failure Action |
|-------|-------------|---------------|
| Confidence | Score >= `min_confidence` | Return `None` |
| Duplicate | Vector similarity check | Return `None` |

---

### Phase 5: Evolution (进化)

**What**: Drafts either get promoted, archived, or stay pending.

**Paths**:

```
Draft ──[auto-promote: usage>=5 + confidence>=0.9]──▶ Canonical
Draft ──[human approves]─────────────────────────────▶ Canonical
Draft ──[human rejects]──────────────────────────────▶ Archived
Draft ──[30 days no activity]────────────────────────▶ Archived
```

**Agent action**: None — evolution is automatic or human-driven.

---

## Configuration Reference

### SkillManager

```python
SkillManager(
    db_path: str = "skills.db",           # SQLite file path
    embed_fn: Callable[[str], list[float]] # REQUIRED: embedding function
                                          #   e.g., OpenAI, local model, etc.
    llm_fn: Callable[[str], dict] = None  # OPTIONAL: LLM analysis for extract()
    mode: str = "admin",                  # "admin" (full) or "agent" (restricted)
    min_confidence: float = 0.7,          # Minimum confidence for extraction
    auto_promote: dict = None             # {"usage": 5, "confidence": 0.9}
)
```

### Agent Mode Restrictions

```python
# Allowed
sm.query(text, budget=4000, top_k=20, score_threshold=0.4) → str
sm.extract(context, confidence_threshold=None) → Optional[str]

# Raises PermissionError
sm.register(skill)      # ❌ Not allowed
sm.approve(draft_id)    # ❌ Not allowed
sm.reject(draft_id)     # ❌ Not allowed
sm.archive(skill_id)    # ❌ Not allowed
sm.review_queue()       # ❌ Not allowed
sm.export(skill_id)     # ❌ Not allowed
sm.import_(path)        # ❌ Not allowed
```

---

## Best Practices

### 1. Always Query Before LLM Calls

```python
# Good: Skills enhance every LLM call
skills = sm.query(user_input, budget=3000)
system += f"\n\n{skills}"

# Bad: Only query occasionally
if random.random() > 0.5:
    skills = sm.query(...)  # Inconsistent skill usage
```

### 2. Extract Judiciously

Don't extract after every turn — only when you detect reusable knowledge:

```python
# Good: Extract after substantial work
if len(messages) >= 5 and has_tool_calls(messages):
    sm.extract(messages)

# Bad: Extract after every message
sm.extract(messages)  # Too noisy, low quality
```

### 3. Handle Corrections Immediately

User corrections are the highest-quality training signal:

```python
# Good: Direct extraction with lower threshold
correction_context = f"Wrong: {original}\n\nCorrect: {correction}"
sm.extract(correction_context, confidence_threshold=0.5)

# Bad: Let it go through normal flow
sm.extract(f"User said: {correction}")  # May miss the signal
```

### 4. Set Appropriate Budgets

The `budget` parameter in `query()` is the token budget for skills, not the total prompt budget:

```python
# If your model context is 8k and you use 2k for conversation,
# allocate ~4k for skills (leave headroom for response)
remaining = 8000 - conversation_tokens - 2000  # response headroom
skills = sm.query(input_text, budget=remaining)
```

### 5. Use Dependency Chains for Complex Skills

When registering skills manually, set dependencies so related skills load together:

```python
Chunk(
    id="auth::oauth",
    skill_id="auth",
    content="OAuth2 flow implementation...",
    dependencies=["auth::basics", "crypto::jwt"],  # Auto-load prerequisites
    required=True
)
```

---

## Troubleshooting

### Auto-promotion never triggers

**Symptom**: Drafts stay pending forever despite high confidence.

**Causes**:
1. `record_usage()` may not be called in `query()` — ensure your skillvault version >= 0.2.0
2. Draft not being queried — check that agent code actually uses `query()`
3. Confidence below threshold — check draft confidence with `sm.get()`

**Fix**: Verify stats:
```python
stats = sm.stats()
print(f"Pending review: {stats['pending_review']}")
```

### Extraction returns None too often

**Symptom**: `sm.extract()` always returns `None`.

**Causes**:
1. No `llm_fn` provided — `extract()` returns `None` without an LLM analyzer
2. Content below confidence threshold — reduce `min_confidence` temporarily
3. Duplicate detection — content too similar to existing skills

**Debug**:
```python
# Check if llm_fn is set
print(sm.growth_engine.llm_fn is not None)
# Force extraction with lower threshold:
draft_id = sm.extract(context, confidence_threshold=0.3)
```

### Skills not appearing in query results

**Symptom**: `query()` returns empty string even when skills exist.

**Causes**:
1. Skills are drafts and `include_drafts=False` (default)
2. Score below `score_threshold` — lower to 0.2 for testing
3. Embeddings not saved — ensure `generate_embeddings=True` during registration

**Debug**:
```python
# Check what skills exist (admin mode)
admin = SkillManager("skills.db", embed_fn=embed_fn, mode="admin")
skills = admin.list()
for s in skills:
    print(f"{s.id}: source={s.source}, status={s.status}")
```

---

## Version Compatibility

This integration guide matches **skillvault >= 0.2.0**.

Key changes in 0.2.0:
- **Removed**: `AgentSkillClient`, `GrowthTrigger` — use `mode="agent"` and explicit `extract()` calls
- **Changed**: `embed_model` parameter → `embed_fn` injection (bring your own embeddings)
- **Changed**: `embed_model` and OpenAI deps moved to `[openai]` extra
- **Changed**: `click` and CLI moved to `[cli]` extra
- **Simplified**: Auto-promotion reduced to single SQL check (usage + confidence only)

---

## See Also

- `README.md` — Project overview and CLI usage
- `FRAMEWORK_DESIGN.md` — Full architecture rationale and design decisions
- `CLAUDE.md` — Development commands and internal module structure
- `src/skillvault/manager.py` — `SkillManager` source
