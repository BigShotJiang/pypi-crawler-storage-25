from setuptools import setup

setup(
    name="datalab-app-plugin-insitu",
    version="0.0.0.1",
    author="",
    author_email="",
    description="A security place-holder package",
    classifiers=[
    "Programming Language :: Python :: 3",
    "Operating System :: OS Independent"
    ]
)
