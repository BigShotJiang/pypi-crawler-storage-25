"""Shared enumerations for Summary Stack."""

from enum import Enum


class SourceType(str, Enum):
    """Supported source types for content processing.

    These types are detected by SummaryStackConverter based on:
    - URL patterns (youtube, general web URLs)
    - File extensions (pdf, audio, video, etc.)
    - Content analysis (text vs markdown)
    """

    # Web sources
    URL = "url"
    YOUTUBE = "youtube"

    # Document formats
    PDF = "pdf"
    DOCUMENT = "document"  # docx, doc
    PRESENTATION = "presentation"  # pptx
    SPREADSHEET = "spreadsheet"  # xlsx, xls, csv
    NOTEBOOK = "notebook"  # ipynb
    EBOOK = "ebook"  # epub

    # Media formats
    AUDIO = "audio"  # mp3, wav, m4a, ogg, flac
    VIDEO = "video"  # mp4, avi, mov, mkv, webm
    IMAGE = "image"  # jpg, jpeg, png, gif, webp

    # Text formats
    TEXT = "text"  # txt
    MARKDOWN = "markdown"  # md
    DATA = "data"  # json, xml

    # Fallback
    UNKNOWN = "unknown"


class DocumentType(str, Enum):
    """Types of documents for specialized processing."""

    RESEARCH = "research"  # Papers, studies, academic content
    TECHNICAL = "technical"  # Documentation, specs, procedures
    BUSINESS = "business"  # Reports, strategies, metrics
    MARKETING = "marketing"  # Campaigns, positioning, audience insights
    GENERAL = "general"  # Default catch-all


class SubscriptionTier(str, Enum):
    """User subscription tiers for quota and feature access.

    These tiers determine:
    - Monthly generation limits
    - Allowed source types

    Note: BYOM (Bring Your Own Model) is a feature available to pro users,
    not a separate tier. Pro users can optionally provide their own API keys.
    """

    FREE = "free"  # Limited generations, basic source types only
    PRO = "pro"  # Unlimited generations, all source types, BYOM eligible


class CredentialProvider(str, Enum):
    """Supported LLM providers for BYOM (Bring Your Own Model) functionality.

    Note: Tavily is not included here - it's a system-level service covered by
    the platform for all users (free and pro).
    """

    OPENAI = "openai"  # OpenAI API (GPT models)
    ANTHROPIC = "anthropic"  # Anthropic API (Claude models)
    GOOGLE = "google"  # Google Generative AI (Gemini models)
    OPENROUTER = "openrouter"  # OpenRouter (multiple providers)
    GROK = "grok"  # xAI API (Grok models)


# Human-readable display names for credential providers
CREDENTIAL_PROVIDER_DISPLAY_NAMES: dict["CredentialProvider", str] = {
    CredentialProvider.OPENAI: "OpenAI",
    CredentialProvider.ANTHROPIC: "Anthropic",
    CredentialProvider.GOOGLE: "Google AI",
    CredentialProvider.OPENROUTER: "OpenRouter",
    CredentialProvider.GROK: "xAI (Grok)",
}

# All credential providers are LLM providers (Tavily was removed - it's system-level)
LLM_PROVIDERS: frozenset[CredentialProvider] = frozenset(
    {
        CredentialProvider.OPENAI,
        CredentialProvider.ANTHROPIC,
        CredentialProvider.GOOGLE,
        CredentialProvider.OPENROUTER,
        CredentialProvider.GROK,
    }
)


def is_llm_provider(provider: CredentialProvider) -> bool:
    """Check if a provider is an LLM provider (can be set as active)."""
    return provider in LLM_PROVIDERS


class Environment(str, Enum):
    """Valid deployment environments for API keys.

    Values match the database CHECK constraint exactly:
    ['local', 'dev', 'staging', 'prod']
    """

    LOCAL = "local"
    DEV = "dev"
    STAGING = "staging"
    PROD = "prod"

    @classmethod
    def normalize(cls, env: str) -> "Environment":
        """Normalize environment string to enum value.

        Handles common aliases like 'production' -> PROD, 'development' -> DEV.
        Defaults to LOCAL for unknown values.
        """
        env_lower = env.lower()
        if env_lower in ("production", "prod"):
            return cls.PROD
        if env_lower in ("development", "dev"):
            return cls.DEV
        if env_lower == "staging":
            return cls.STAGING
        return cls.LOCAL


class IntegrationProvider(str, Enum):
    """Supported content source integrations (NOT LLM providers).

    These are external services for capturing content (Readwise, Pocket, etc.)
    that send webhooks to trigger Summary Stack creation.
    """

    READWISE = "readwise"


class IntegrationStatus(str, Enum):
    """Integration connection status."""

    ACTIVE = "active"
    INACTIVE = "inactive"
    ERROR = "error"


# Human-readable display names for integration providers
INTEGRATION_PROVIDER_DISPLAY_NAMES: dict["IntegrationProvider", str] = {
    IntegrationProvider.READWISE: "Readwise Reader",
}
