# -*- coding: utf-8 -*-

"""
Provides common elements and clients related to database engines.
"""

from importlib.metadata import PackageNotFoundError
from importlib.metadata import version


try:
    __version__ = version("core-db")

except PackageNotFoundError:
    __version__ = "unknown"
