"""Sophon: Generative benchmark for probing spatial reasoning in VLMs."""

__version__ = "0.0.1"
