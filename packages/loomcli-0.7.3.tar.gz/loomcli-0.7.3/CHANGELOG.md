# Changelog

All notable changes to the Powerloom schema and CLI are documented here. This repo uses two independent version streams:

- **Schema:** `schema-vX.Y.Z` git tags. Semver — breaking changes bump major, additive bump minor, docs-only bump patch.
- **CLI:** `vX.Y.Z` git tags on this repo. Trigger PyPI publish via `.github/workflows/publish.yml`.

## Unreleased

## v0.7.3 — 2026-04-28 (CLI)

**`weave conventions sync` auto-detects OU scope.** Closes powerloom thread `53b781c8`. The SessionStart hook in `.claude/settings.json` no longer needs a hardcoded `--scope` argument — the CLI walks four detection paths in order until one resolves.

### Detection chain

1. Explicit `--scope <dotted-path>` (existing, highest priority)
2. Cached scope from the last successful sync in this config dir (existing, v0.6.8+)
3. **NEW:** Active sub-principal's home OU — fetched via `/me`, then walked through `/ous/tree` to build the dotted slug path
4. **NEW:** `git remote get-url origin` → matched against `tracker_projects.github_repo_url`; the project's `ou_id` becomes the scope (pairs with Powerloom migration 0072)

If all four fail, the error message now lists each path tried.

### What you can drop

The `.claude/settings.json` hook can shrink from:
```bash
weave conventions sync --scope bespoke-technology.powerloom --runtime claude_code --quiet
```
to:
```bash
weave conventions sync --runtime claude_code --quiet
```

(Recommended once you've signed in once: the auth-gated detection paths need a valid token. The hook continues to work with the explicit `--scope` for full back-compat.)

### Tests

- 15/15 passing. Existing `test_sync_no_scope_no_cache_exits_2` updated to assert the new "Could not determine OU scope" error shape.


## v0.7.2 — 2026-04-28 (CLI)

**Agent-session registration for non-developers.** The `register` command no longer assumes a git checkout. Three explicit scope-detection paths, friendlier errors, and a new interactive `start` command for users who don't have (or want) a branch dependency.

### What changed

- **`weave agent-session register --workspace-id <id>`** — new path for hosted clients (Antigravity, mobile, in-browser sessions) that don't have a local git checkout. Workspace id becomes the scope (slugified + date-suffixed).
- **`weave agent-session register --scope <slug>`** — explicit path. `--summary` now auto-generates from `--scope` if omitted, so a single `--scope` flag is enough.
- **`weave agent-session start`** — new interactive command for PMs / ops / non-dev users. Prompts for a scope + summary, defaults `--actor-kind=human`, never touches git.
- **Smarter error messages** — when no scope-detection input is supplied, the error suggests the right path based on cwd context (cwd-is-git → `--from-branch`; cwd-is-not-git → `--scope` / `--workspace-id` / `start`).
- **`--from-branch` non-session-branch behavior** — instead of hard-erroring on branches that don't match `session/<scope>-<yyyymmdd>`, the CLI now slugifies the branch name and appends today's date with a warning, so devs working off oddly-named feature branches aren't blocked.

### Pairs with

- Powerloom thread `a9091bbc` (de-couple agent-session registration) and `51174e34` (attach GitHub repo info to projects when agents connect).
- Engine route `/agent-sessions` already accepts nullable `branch_name`; this release closes the CLI-side gap.

### Tests

- 24/24 in `test_agent_session_cli.py` (3 new: `--scope` alone, `--workspace-id`, bare-`register` smart-error)
- 1 new for `start` interactive prompt path


## v0.7.1 — 2026-04-27 (CLI)

**Plugin install error UX.** `weave plugin install <client> --execute` now pre-flight-checks that the client binary (`gemini` / `codex` / `claude`) is on `PATH` before subprocess-ing into it. When the binary is missing, the error message points the user at the install URL instead of surfacing a bare `[WinError 2] The system cannot find the file specified`.

Reproducer that prompted the fix:
```
PS> weave plugin install gemini --execute
gemini extensions install C:\Users\…\plugins\0.7.0\gemini\powerloom-weave --consent --skip-settings
Install failed: [WinError 2] The system cannot find the file specified
```

After:
```
PS> weave plugin install gemini --execute
gemini extensions install C:\Users\…\plugins\0.7.0\gemini\powerloom-weave --consent --skip-settings
Install failed: 'gemini' is not on PATH.
  Install the Gemini CLI first: https://github.com/google-gemini/gemini-cli (npm: `npm install -g @google/gemini-cli`).
  Once installed, re-run weave plugin install gemini --execute.
```

Same pre-flight applies to `codex` and `claude` install commands.


## v0.7.0 — 2026-04-27 (CLI)

**Cascading conventions.** `weave conventions sync` now fetches the **effective** convention set for the agent's OU — folding org-wide policy, every OU ancestor, the leaf OU, and (in future) project-scoped conventions into a single rule list with child-wins-with-deny semantics. Org admins can author once at the root and have every descendant session pick it up automatically.

### What changed

- **`weave conventions sync --scope <ou-path>`** — `--scope` is now an OU dotted path (e.g. `bespoke-technology.powerloom` or `/dev-org/engineering`) and the CLI calls the new `/memory/semantic/conventions/effective?ou_path=…` endpoint. Older engines that don't have `/effective` (Powerloom < 2026-04-27) get a transparent fallback to the legacy `/match` route, so an upgraded CLI doesn't break an older deployment.
- **Marker block now shows inheritance.** Each rendered convention carries a source-scope tag (`org`, `ou`, `project`) and, when inherited from above, a `_Inheritance: org → ou:engineering → ou:powerloom_` trail so agents reading `CLAUDE.md` / `AGENTS.md` / `GEMINI.md` know which level authored each rule.
- **Body items folded.** When a child OU restates a parent's bullet, the parent's contribution is dropped and the child's text takes its position. A child convention with `deny_parent: true` truncates the chain entirely above it.

### Pairs with

- **Powerloom migration 0070** — adds `scope` (`'org'|'ou'|'project'`), nullable `ou_id`, `project_id` FK, `deny_parent` boolean. Backwards-compat default of `scope='ou'` so existing rows keep working.
- **`/memory/semantic/conventions/effective`** endpoint — cascading resolver. Walks `ou_closure` from the leaf upward, applies child-wins-with-deny, returns folded rows with `inheritance_chain` for UI/CLI rendering.
- **`recommended_loomcli_version`** bumped to `0.7.0` in the engine's capabilities response.

### Tests

- Existing 28 convention tests pass on the new schema.
- 14 new tests in `test_memory_conventions_cascading.py` (engine side) covering org-level create, scope guards, parent/child cascade, deny_parent truncation, archive exclusion, inheritance-chain shape.


## v0.6.9 — 2026-04-27 (CLI)

**Pip-install ergonomics + agent UX.** Combines two independently-landed feature blocks under one release: bundled plugin assets ship inside the wheel (no more git-clone-of-loomcli prerequisite for any client), and the agent surface picks up auto-detection + contextual defaults + a batch runner.

### Bundled plugin assets

- **`weave plugin path <client> [--json]`** — prints the exported plugin path for a given client (`claude-code`, `codex`, `gemini`, `antigravity`). Triggers asset export on first call to `<config_dir>/plugins/<version>/`.
- **`weave plugin install <client> --execute`** — now resolves the bundled-asset path and shells out to the client's native install command. Dry-run (no `--execute`) prints a copy-pasteable form instead, formatted with `subprocess.list2cmdline` on Windows / `shlex.join` on POSIX so no shell escaping needed.
- **`weave plugin doctor`** JSON output now includes `export_root` and per-client `install_command` fields so scripting can chain into plugin doctor without re-running install.
- **`weave doctor`** picks up: `python.executable`, `python.version`, `stdio.encoding` (helpful on Windows where cp932/cp1252 break rich rendering), and `plugin.export_root`.

### Agent UX & workflow ergonomics

- **Agent Mode detection**: auto-detects AI agents (`GEMINI_CLI`, `CLAUDE_CODE`, etc.) and defaults output to JSON.
- **Contextual defaults**: agent commands (`status`, `ask`, `chat`, etc.) now use the agent/OU linked to the current git branch's active coordination session.
- **Hierarchical OU discovery**: `weave get ous --tree` provides a visual and JSON-standardized tree of the organization unit hierarchy.
- **Batch command**: `weave batch` allows sequential execution of multiple weave commands in a single process, improving cross-shell compatibility.
- **Workflow ergonomics**: `weave agent-session init <branch>` handles branch creation and registration in one step; `--from-branch` now supports flexible branch names.
- **Agent-friendly errors**: standardized JSON error objects via `PowerloomApiError.to_dict()` when in Agent Mode.
- **`weave agent-session register --from-branch`** — error path now prints `cwd:` so the user sees which directory `loomcli` thought it was in. `--if-not-active` honors `--json`: emits `{"status": "already_active", "session": {…}}` instead of swallowing the bail-out so callers can detect re-runs.

### Capabilities pin

- Engine PR `Powerloom#171` updates `recommended_loomcli_version` from `0.6.8` → `0.6.9` so existing consumers get the upgrade nudge through `weave whoami` / capability checks.

### Tests

- 27 new + updated for plugin asset export (`test_doctor_plugin_cmd.py`) and `register --from-branch --json` branches (`test_agent_session_cli.py`)
- Plus the agent-mode + batch coverage from the init-loomcli-20260427 branch
- Full suite still green


## v0.6.8 — 2026-04-27 (CLI)

**Conventions sync.** Surfaces OU-scoped Powerloom conventions (engine v064 / `/memory/semantic/conventions/*`) into the project-rules file the runtime reads at session start.

### New commands

- **`weave conventions sync --scope <dotted-path> [--runtime claude_code|codex_cli|gemini_cli|antigravity|all] [--workdir DIR] [--dry-run] [--quiet]`** — Fetch conventions matching the OU scope-ref + write them to CLAUDE.md / AGENTS.md / GEMINI.md inside an HTML-comment marker block. Re-syncs replace the block; hand-edits outside survive. Caches the last-used scope so subsequent runs (e.g. SessionStart hook) don't need `--scope`.
- **`weave conventions show --scope <dotted-path>`** — Read-only preview of what would sync.
- **`weave conventions list [--status active|archived]`** — Cross-OU view of every convention visible to your org.

### Pairs with

- **Powerloom PR #169** — adds `weave conventions sync --scope bespoke-technology.powerloom --runtime claude_code --quiet` to `.claude/settings.json` SessionStart hook so every Claude Code session opening the Powerloom repo gets the latest conventions auto-merged.
- The convention authoring/management UI is filed as a follow-up thread (`ui-convention-authoring-management-page` in powerloom-ui).
- Project-scope conventions (today OU-only) is filed as a follow-up (`conventions-project-scope-extension` in powerloom-engine).
- Scope auto-detection (drop the hardcoded `--scope` from the hook) is filed as a low-priority follow-up.

### Tests

- 15 new in `test_conventions_cmd.py` covering: discovery, show (table + empty), sync (create / replace / append / dry-run / all-runtimes / cached-scope / no-scope-no-cache / invalid-runtime / quiet / corrupted-half-marker), list (table + status filter)
- Full suite: **702 passed** (was 684 in v0.6.7)


## v0.6.7 — 2026-04-27 (CLI)

**AX improvements + first-class agent management.** Surfaces Gemini's PR #41 work + the v067 follow-ups that landed since v0.6.6.

### New commands

- **`weave configure`** — AWS-style interactive wizard for profiles + PATs. First-time-setup-friendly.
- **`weave profile switch <name>`** — quick environment toggle between configured profiles.
- **`weave agent sub-principal mint`** — easy identity management for spinning up new sub-principals from the CLI.
- **`weave agent-session update`** — metadata updates for an existing coordination session (capabilities, scope, etc.).

### Cross-cutting

- **`--output` flag (global)** + **`POWERLOOM_FORMAT=json` env var** — every command can now emit machine-readable JSON for agent/CI consumption. Single place to opt into JSON instead of per-command flags.
- **Unified `agent_cmd.py`** — observability commands (status, logs, recent-work) folded back into the main agent module. The old `agent_observe_cmd.py` retired.

### Tests

- 684 passed (same as v0.6.6; this release is mostly UX surface, no test count delta)


## v0.6.6 — 2026-04-27 (CLI)

**Bulk-migration toolkit + sprint hierarchy + empty-folder bootstrap.** Surfaces a handful of post-v0.6.5 features so the post-org-reorg workflow has the CLI primitives it needs.

### New commands

- **`weave thread move <ref> --to <project> [--force]`** — Cross-project thread move with safe cleanup. Two-phase: without `--force` returns 409 with the cleanup plan (sprint memberships in source project, milestone/parent FK references, dependency edges that would become cross-project); with `--force` applies the cleanup + the move with full audit reply on the moved thread. Pairs with Powerloom #164 (`POST /threads/{id}/move`).
- **`weave agent-session bootstrap`** — Empty-folder onboarding flow for new clients (PR #37). Initializes a workspace from a project's bootstrap config without requiring a pre-existing checkout.

### Sprint hierarchy

- **`weave sprint create --milestone <uuid>`**, **`weave sprint update <ref> --milestone <uuid>`**, **`weave sprint list --milestone <uuid>`** — Sprints can now nest under milestones (Project > Milestone > Sprint > Thread > Subthread). Pairs with Powerloom #165 (migration 0068 + service-layer support). UUID-only today; milestone slug-resolution lands as a follow-up.

### Tests

- 4 new in `test_sprint_cmd.py` (--milestone create/update/list + UUID validation)
- 4 new in `test_thread_cmd.py` (move endpoint UUID/slug/force/409 paths)
- 24 new in `test_agent_session_cli.py` for bootstrap (Codex contribution)
- Full suite: **684 passed** (was 650 in v0.6.5; +34 net).


## v0.6.5 — 2026-04-27 (CLI)

**Sub-principal pipeline + sprint CLI + slug resolver across the board.** First non-rc release in the v0.6 line — drops the `-rcN` suffix per the new versioning convention (releases are stable by default, pre-releases happen on side-branches when needed).

### New commands

- **`weave sprint`** family — `create / list / show / update / activate / complete / archive / delete / add-thread / remove-thread / threads`. Pairs with the W1.5.2 engine routes (Powerloom #156) so sprints can be dogfooded end-to-end without curl. Sprint addressing accepts UUID, `project:slug`, or bare slug — same shape as W1.5.1 thread slugs.
- **`weave thread tree / sprint-tree / orphans`** — ASCII tree renderers for the W1.5.3 engine routes (Powerloom #153). `tree` shows the parent_thread_id + parent_of-edge tree rooted at one thread. `sprint-tree` does the same rooted at a sprint's top-level threads. `orphans` lists threads with no parent and no sprint membership ("what's loose right now?" triage).

### Sub-principal pipeline (v067 onboarding sprint)

The auto-attribution path that's been a no-op since v0.6.4-rc1 is finally wired end-to-end:

- `weave agent-session register` now find-or-creates a sub-principal named `<actor_kind>:<scope>` against `POST /me/agents` AFTER the agent-session POST succeeds. Caches the UUID in a new per-scope file at `<config_dir>/active-subprincipal-<scope>.txt` (since shell SessionStart hooks can't propagate `export VAR=…` to the parent shell — the env-var-only path was a no-op for every real session).
- `weave thread create / reply / pluck` resolves the active sub-principal in two tiers: (1) `POWERLOOM_ACTIVE_SUBPRINCIPAL_ID` env var (explicit override; wins when set), (2) the per-scope cache file (with branch derivation via `git rev-parse`). Falls back to "no attribution" gracefully when neither source resolves.
- New `loomcli.config.active_subprincipal_file(scope)` helper for the cache-file path.

After this release, every CC session running the existing `.claude/settings.json` SessionStart hook auto-stamps `session_attribution` on every tracker action with no human ritual. Codex/Antigravity/Gemini hooks are open follow-ups (tracked in the v067-onboarding sprint).

### Slug resolver (W1.5.1 + W1.5.3 dogfood)

- **`weave thread show / pluck / reply / done / close / wont-do / update`** all accept UUID, `project:slug`, or bare slug now. Slug shape validated client-side before hitting the network; 404 from `/by-slug` lookups renders a project + slug-specific error.

### Documentation

- README + plugin SKILL files updated for the new commands and the auto-attribution flow.
- The connect-your-agent doc references the new sprint + tree commands as primary examples for "you've onboarded — now what?"

### Tests

- 23 new in `test_sprint_cmd.py` (full sprint CRUD + slug resolution + JSON output + lifecycle parametrize).
- 9 new across `test_thread_cmd.py` + `test_agent_session_cli.py` for the sub-principal pipeline (env-var precedence, file fallback, per-scope isolation, graceful network failure, end-to-end attribution).
- Full suite: **650 passed**.


## v0.6.4-rc2 — 2026-04-27 (CLI)

**Agent onboarding friction reduction + security hardening.** This release focuses on making the first-time setup experience smoother for agents and humans alike, paired with server-side capability discovery.

### New Features & Fixes

- **`weave doctor` version health** — Now retrieves `min_loomcli_version` and `recommended_loomcli_version` from the server's `/capabilities` endpoint. Warns the user with a clear `pip install -U loomcli` hint if their CLI version is outdated or below recommendation.
- **`weave plugin doctor --fix`** — Automated repair for common setup issues. Detects missing binary or plugin files and executes the necessary install/enable commands (e.g., automatically enabling the Gemini extension).
- **CI Pipeline** — Added GitHub Actions workflow for automated `ruff` linting and `pytest` execution on every push and PR.
- **Dependency Update** — Added `packaging` to core dependencies for robust PEP 440 version comparison.
- **Onboarding Guide** — Added links to the new "Connect Your Agent" guide in README and command outputs.


## v0.6.4-rc1 — 2026-04-27 (CLI)

**Substantial new command surface + dogfood loop hardening.** Ships the `weave thread` family that CLAUDE.md / GEMINI.md / AGENTS.md §4.10 has been referencing, plus auto-attribution, plus several Codex/Gemini plugin install fixes, plus the post-prod-deploy MCP setup hotfix.

### New commands

- **`weave thread create / pluck / reply / done / close / wont-do / list / show / update`** — the canonical CLI surface for the §4.10 tracker-thread workflow. Closes the "use weave thread create" parenthetical that was an escape-hatch in the project-rules docs.
- **`weave thread my-work [--watch --interval N]`** — heads-up display for "what am I working on right now," with poll-mode + summary-line + JSON output.
- **`weave agent-session status / watch`** — inspect coordination sessions with optional polling.
- **`weave thread reply` auto-stamping** — when `POWERLOOM_ACTIVE_SUBPRINCIPAL_ID` env var is set, both `create` and `reply` automatically populate `metadata_json.session_attribution` so audit trails distinguish "you" from "your agent session acting as you." Pure opt-in — direct human callers without the env see no behavior change. `--no-attribution` flag opts out per-command.

### Skill + plugin updates

- **`powerloom-onboarding` skill** — fresh-agent first-10-minute walkthrough for Claude Code, Codex CLI, and Gemini CLI. Mirrors across all three plugin packages.
- **`weave-tracker` skill** — full thread-lifecycle reference; the §4.10 "fallback when subcommands aren't shipped" section retired (the subcommands are here now).
- **Codex marketplace + Gemini install fixes** — corrects plugin install paths + the install instructions in the docs.

### Hotfix: `weave setup-claude-code` writes correct .mcp.json schema

Pre-hotfix, `weave setup-claude-code` wrote `.mcp.json` with server entries at the top level (no `mcpServers` wrapper), which Claude Code rejects with `mcpServers: Does not adhere to MCP server configuration schema`. The hotfix:
- Writes the canonical `{"mcpServers": {...}}` shape.
- Auto-migrates pre-hotfix broken files on next run (detects + relocates top-level server entries; removes the duplicates).
- Switches default to writing the literal `Bearer pat_xxx` token instead of `${POWERLOOM_MCP_TOKEN}` substitution (CC's HTTP-transport MCP config doesn't reliably env-var-substitute inside header values; verified 2026-04-27 against api.powerloom.org). New `--use-env-substitution` flag opts back into the `${VAR}` form for committed/shared workspaces.

### Co-deployed with Powerloom #146 (P0 routing-loop fix)

This release pairs with the engine-side fix to the AWS ALB routing loop that was returning HTTP 463 to fresh CC sessions. Both must be deployed together for the demo loop to work end-to-end.

### Tests

627/627 pass (524 pre-existing + 22 weave-thread + new my-work + L4 auto-stamp + setup-claude-code migration tests). Two pre-existing unrelated failures remain on `main` (covered in their own threads).

- **Client plugin packages**: keeps the existing Claude Code plugin and adds OpenAI Codex + Gemini CLI plugin/extension packages under `plugins/`.

## v0.6.3-rc1 — 2026-04-26 (CLI)

**v057 closeout + v061-v064 first slices — schema-version negotiation, target-OU compose gating, TypeDefinition + Convention stdlib derivations.** Four landed-together commits from the v057-closeout side branch, reconciled onto v0.6.2-rc1 (the import-project release) and re-bumped to v0.6.3-rc1.

### New

- **`X-Powerloom-Schema-Version` header** — `loomcli/client.py` injects the header on every request, sourced from `loomcli.schema.SCHEMA_VERSION`. Engines pre-dating v057 ignore it; engines on v057+ run it through the `core/schema_version_check.py` 426 gate (engine companion in PR #133, ships in same deploy).
- **426 response formatter** — `_format_version_mismatch()` recognizes the engine's canonical 426 body shape (`error.detail.{supported_versions, client_sent}`) and emits an upgrade-hint message; non-canonical 426s fall back to the default extractor.
- **`metadata.target_ou_path` on Compose manifests** — manifest authors can publish a composed kind to a specific OU instead of the default org root. Engine-side resolution lands in PR #133 (`services/compose.py` resolve_target_ou_id + migration 0054).
- **TypeDefinition stdlib derivation** — first cell-level memory primitive shipped as a v2 stdlib kind. New schema at `schema/v2/stdlib/type-definition.schema.json`; loomcli builder at `loomcli/schema/v2/stdlib/type_definition.py`; example manifest at `examples/minimal/type-definition.yaml`.
- **Convention stdlib derivation** (v064) — `compose(Policy[intent], Scope[applies_to])`, the 11th stdlib kind. Top-down authored rules with `enforcement_mode` + `status` enums and `references_json` cross-links. Schema at `schema/v2/stdlib/convention.schema.json`.

### Schema

- 2.0.0-draft.1 → 2.0.2-draft.1 (additive: TypeDefinition + Convention; target_ou metadata on Compose).

### Tests

- 18 tests for X-Powerloom-Schema-Version header injection + formatter
- 100 tests for compose target_ou validation + apply path
- 172 tests for TypeDefinition schema validation
- 19 tests for Convention schema validation
- All 484 existing tests still pass — full suite 553/553 green

### Reconcile note

Originally three sequential `0.6.1-rcN` releases on `session/v057-closeout-20260425`, plus an additional `0.6.2-rc1` cut on the same branch carrying Convention. The `0.6.2-rc1` slot was pre-empted by the `weave import-project` cut (different feature, also dated 2026-04-26). This reconciles all four commits + bumps to `0.6.3-rc1` as a single unified release; the intermediate rc bumps are squashed away.

## v0.6.2-rc1 — 2026-04-26 (CLI)

**v059 self-import MVP — `weave import-project`.** New CLI command that imports a Powerloom-shaped checkout (Project.md + docs/phases/*.md + KNOWN_ISSUES.md + docs/out-of-scope.md + docs/handoffs/*.md + ReadMe.md) into the engine's tracker subsystem. The CLI walks the local files and POSTs their contents; the engine does the parsing + apply via the new `POST /projects/import/from-source` endpoint (Powerloom PR #129). No engine-package dependency on the client side.

### New

- **`weave import-project <path>`** — uploads a checkout's source files to the engine and reports created/updated counters. Flags: `--dry-run` (rollback semantics), `--slug` / `--name` (defaults `powerloom` / `Powerloom`), `--slug-override` (apply against a sandbox project without disturbing the canonical one). Idempotent — re-runs against the same source produce 0 new threads via the engine's dedupe-key matching.
- **`loomcli/commands/import_project_cmd.py`** — collects the canonical source path set, enforces the 5 MB upload cap locally before round-trip, passes `git rev-parse --short HEAD` as `commit_sha` for source-drift provenance.
- **`tests/test_import_project_cli.py`** — 13 tests: command discovery, auth gate, empty-repo rejection, source-file collection, body shape (slug/name/dry-run/override), result rendering (success summary, dry-run banner, per-op errors), API-error propagation. Engine-side parsing is covered by Powerloom's own integration tests.

## v0.6.1-rc1 — 2026-04-25 (CLI, side-branch draft)

**v057 stdlib expansion: `FailureRecoveryFrame`.** First Frame-Semantics derivation lands as a v2.0.1 stdlib kind. Operators can now author scope-attached recovery templates that bind the canonical four frame elements (`Action_Attempted` / `Error_Type` / `Corrective_Action` / `Final_Outcome`) to specific failure patterns agents should follow. v058+ will let consolidation distill these from episodic runs (`provenance: distilled_from_episodic`); v057 ships only the operator-authored path.

> Side-branch release. Cut on `session/memory-schema-arc-20260425`; canonical `vNNN` and PyPI tag assigned at reconcile-to-main.

### New

- **`schema/v2/stdlib/failure-recovery-frame.schema.json`** — additive. Derivation: `compose(Process[recovery_procedure], Policy[trigger_conditions], Scope[applicable_scope])`. Required spec fields: `display_name`, `applicable_scope_ref`, `action_attempted`, `error_type`, `corrective_action`, `final_outcome`. `error_type.category='other'` requires `error_type.signature` (enforced via JSON Schema `if`/`then`). Schema version bumps `2.0.0-draft.1 → 2.0.1-draft.1`.
- **`examples/minimal/failure-recovery-frame.yaml`** — minimal manifest covering the canonical rate-limit-429 retry pattern.
- **`tests/schema/test_failure_recovery_frame.py`** — 23 tests: minimal validates, every required-field omission rejected, every error category accepted, `category='other'` requires signature, every final-outcome enum accepted, `max_attempts` bounds, provenance default + enum, derivation metadata sanity.
- **`schema/v2/powerloom.v2.bundle.json`** — `oneOf` extended to include the new kind. Description bumped 8→9 stdlib derivations.
- **`scripts/generate_schema_package.py`** — `SCHEMA_VERSION` now sourced from `schema/v2/VERSION` instead of hardcoded. Avoids future drift between the literal in the script and the actual schema version.

### Engine pin (downstream)

Powerloom engine should bump `loomcli>=0.6.1rc1,<0.7.0` in `api/pyproject.toml` to consume the new kind. Engine-side validators + `kind_registry` discovery handled in the matching engine PR on the same session branch.

### Compat

- Existing `0.6.0-rc2` manifests continue to validate unchanged — the v057 work is purely additive on the v2.0.0 surface.
- `_V2_STDLIB_KINDS` in `migrate_cmd.py` stays at the original 8 — `FailureRecoveryFrame` is new in v2 with no v1 equivalent, so it has no v1→v2 migration path to surface.

## v0.6.0-rc2 — 2026-04-24 (CLI)

**First actual pre-release of the 0.6.0 series.** The 0.6.0rc1 pyproject bump merged on the long branch but never got tagged (PEP 440 string `0.6.0rc1` didn't match the publish workflow's `v*.*.*-*` tag pattern). 0.6.0-rc2 ships with everything rc1 was supposed to — plus one live-test bug fix.

### Fix
- **`weave login` default API URL** (PR #10) — `POWERLOOM_API_BASE_URL` default flipped from `http://localhost:8000` → `https://api.powerloom.org`. A fresh `pip install loomcli` + `weave login` now talks to the hosted cluster out of the box. Docker-compose dev workflows already pass `POWERLOOM_API_BASE_URL` or `--api-url` so they're unaffected.

### Carried forward from 0.6.0rc1 (which never shipped)
See the 0.6.0rc1 entry below — all five milestones (stdlib polish, compose operator, migrate tool, loomcli.schema package, v2 schema bundle) are in this release.

## v0.6.0rc1 — 2026-04-24 (CLI)

**v056 schema v2.0.0 surface — first pre-release.** Ships the Chomskian 6 authoring stack: six primitives (Entity/Event/Relation/Process/Scope/Policy), eight stdlib derivations (Organization/OU/Agent/Skill/WorkflowType/Workflow/MemoryPolicy/MCPDeployment), and the `compose` operator. Also ships the migration tooling to bring v1.2.0 manifests forward.

### New

- **`loomcli.schema` Pydantic package** — generated from `schema/v2/*.schema.json` via `scripts/generate_schema_package.py` (datamodel-code-generator). Importable as `from loomcli.schema.v2 import stdlib, primitives, compose, common`. Regeneration lives in the same script; CI compares the generated output to the committed files.
- **`weave compose` operator** (3 subcommands): `scaffold` prints a starter Compose manifest; `lint` runs three-pass validation (meta-schema + slot-shape + shallow scope_ref pattern) with cross-file `$ref` resolution; `show` fetches effective kind schemas from the v056 `/kind-registry` endpoint.
- **`weave migrate v1-to-v2`** — bumps apiVersion with full parity for the 8 stdlib kinds, emits re-express-as guidance for the 9 retired-in-v2 kinds (Group, GroupMembership, RoleBinding, SkillAccessGrant, AgentSkill, AgentMCPServer, MCPServerRegistration, standalone Scope, Credential). Supports `--in-place`, `--out`, `--check`, directory recursion.
- **v2 schema bundle** — `schema/v2/` now shipped inside the wheel under `_bundled_schema/v2/` so pip-installed `weave` can validate v2 manifests offline.
- **T5 compose-doc polish** — `compose.schema.json` description expanded with explicit Policy slot authoring guidance (`policy_type` is free-form text; worked example; Entity/Event/Relation hints). Closes the T5-05 benchmark failure cluster where models left `policy_type` off Policy slots.

### Deferred to 0.6.0 final (v056 M6/M7)

- Engine `/kind-registry` route + compose reconciler (the `show` command wires against them but they aren't deployed yet).
- Migration guide doc (`docs/migration-v1-to-v2.md`).
- CHANGELOG reconciliation with Powerloom ReadMe.md once v056 ships.

### Compat

- `powerloom.app/v1` manifests continue to work against current engine deployments; v056 adds v2 support additively.
- Legacy alias `powerloom/v1` still accepted at migration time (warn-level note).

## v0.5.4 — 2026-04-24 (CLI)

**Close the Pydantic ↔ schema drift for v1.2.0.** Before this release, the CLI bundled the v1.2.0 JSON Schema but the parallel Pydantic models in `loomcli/manifest/schema.py` only covered v1.1.0 shapes. Manifests using any v1.2.0 addition (`system` / `auto_attach_to` on Skill; `coordinator_role` / `task_kinds` / `memory_permissions` / `reranker_model` on Agent; the new kinds `WorkflowType` / `MemoryPolicy` / `Scope`) passed schema validation then crashed with `"Extra inputs are not permitted"` on Pydantic parse.

### Fix scope

- **`SkillSpec`** extended with `system: bool` + `auto_attach_to: AutoAttachSelector | None`. New `AutoAttachSelector` class enforces the selector's exact shape + enum values.
- **`AgentSpec`** extended with `coordinator_role: bool`, `task_kinds: list[TaskKind]`, `memory_permissions: list[str]`, `reranker_model: str | None`.
- **New kinds registered:** `WorkflowType`, `MemoryPolicy`, `Scope`. Each has its own Spec model with field-level validation (enums, numeric ranges). All three use a shared new `OUIdScopedMetadata` class (since v1.2.0 new kinds use `metadata.ou_id: uuid` rather than `metadata.ou_path`).

### Tests

28 new tests in `tests/test_schema_1_2_0_drift.py` covering: every new Skill/Agent field, every new kind's default + custom values, enum rejection, kind-registry wiring, `OUIdScopedMetadata` shape. Full suite: 194/194.

### Bug-fix context

Surfaced running the reference-fleet bootstrap against Shane's prod org:

```
/bespoke-technology/studio/bespoke-brand-style: doc 1 (Skill):
pydantic spec drift (bug — schema passed but model rejected):
system: Extra inputs are not permitted;
auto_attach_to: Extra inputs are not permitted
```

The manifest was correct — the CLI just didn't know about the v1.2.0 extension fields it had advertised via its schema bundle.

### Looking forward

This class of drift is what v056's Milestone 5 closes permanently — the `loomcli.schema` Python package will be generated from the JSON Schema via `datamodel-code-generator`, so future schema additions can't desync from Pydantic. Until then, schema-v1.2.0 + Pydantic-v1.2.0 are now aligned and 28 regression tests guard the alignment.

## v0.5.3 — 2026-04-24 (CLI)

**Approval-gate support + full error visibility.** Closes two gaps surfaced when Shane ran the reference-fleet bootstrap against production.

### New: approval-gate support

Organizations with a `justification_required` approval policy could not use `weave apply` at all — the API returned HTTP 409 with `code: justification_required` before processing the request, and the CLI had no way to send the required `X-Approval-Justification` header.

Now supported two ways:

- **`weave --justification "reason" <any command>`** — global flag. Applies to every request made in that invocation.
- **`POWERLOOM_APPROVAL_JUSTIFICATION=reason`** env var — same effect, useful in scripts (e.g. the `bootstrap.sh`/`bootstrap.ps1` scripts set it automatically).

The header flows from CLI flag → env var → `RuntimeConfig.approval_justification` → `PowerloomClient` constructor → `X-Approval-Justification` HTTP header on every request.

### Fix: apply-results table no longer truncates errors

`weave apply` was rendering the Rich results table with an Error column clipped to 80 characters, which hid the most important information when things went wrong (the full error body was being discarded before display). The table-row summary still shows the first 80 chars for scannability, but full error bodies are now printed below the table for any row that failed, unclipped + indented for readability.

### Bug fix context

Surfaced when Shane's bootstrap tried to create skills on a prod org with an approval policy:
```
HTTP 409 POST /skills: {'code': 'justification_require... 'message': 'this polic...
```
— table clipped the error, leaving both the CLI user AND the fix-it developer guessing what the full message was. Both fixed in this release.

### Tests

9 new tests in `tests/test_approval_justification.py` covering: env-var read path, empty-string-is-none, client header injection present/absent, CLI flag flows to config, help output documents the flag. Full suite: 166/166 passing.

## v0.5.2 — 2026-04-24 (CLI)

**Skill archive upload/activate commands.** Closes the gap `weave apply` leaves open — apply creates/updates the Skill *shell* (manifest metadata), but archive content (the zip with SKILL.md + code + prompts) has to be uploaded separately. Before 0.5.2, that meant curl. Now it's declarative.

### New commands

- **`weave skill upload <address> <archive.zip>`** — POSTs the archive to `/skills/{id}/versions` as multipart/form-data. Prints the returned version UUID, frontmatter name/description, sha256, and size. Does NOT activate — the skill's `current_version_id` stays unchanged until you activate explicitly.
- **`weave skill activate <address> <version-uuid>`** — PATCHes the skill's `current_version_id`. Promotes the uploaded version to runnable.
- **`weave skill upload-and-activate <address> <archive.zip>`** — The common case. Upload + activate in one operation. If activation fails after upload, surfaces both facts so the user can retry activation without re-uploading.
- **`weave skill versions <address>`** — Lists all uploaded versions for a skill (UUID, frontmatter name, sha256, size, upload timestamp).

### Address syntax

All commands take a `<address>` argument of the form `/ou-path/skill-name`, e.g. `/bespoke-technology/studio/bespoke-brand-style`. The skill name is the trailing segment; everything before it is the OU path. Address resolution uses the same `AddressResolver` as `weave apply` — consistent with the rest of the CLI.

### Archive support

- `.zip` → `application/zip`
- `.tar.gz` / `.tgz` → `application/gzip`
- Anything else → `application/octet-stream`

The API validates the archive server-side (SKILL.md frontmatter schema, path-traversal protection, size caps).

## v0.5.1 — 2026-04-24 (CLI)

**Auth UX overhaul — real production login now works, plus PAT management.** First release where `weave` is actually usable against `api.powerloom.org` without manually editing the credentials file.

### New commands

- **`weave login`** — top-level alias for `weave auth login`. Default behavior is a browser-paste flow: opens `https://powerloom.org/settings/access-tokens` in your browser, prompts you to paste the PAT you just minted, verifies it against `/me`, and writes credentials on success. Similar register to `gh auth login` / `aws sso login`.
- **`weave logout`** / **`weave whoami`** — top-level aliases for the parallel `weave auth` commands.
- **`weave login --pat <token>`** — non-interactive mode for scripts and CI. Verifies the token against `/me` before persisting.
- **`weave login --no-browser`** — headless/remote-system mode. Prints the URL and prompts for paste without launching a browser.
- **`weave auth pat create --name <label> [--expires-at <iso>]`** — mint a new PAT. Raw token is shown once.
- **`weave auth pat list`** — list PAT metadata for the signed-in user.
- **`weave auth pat revoke <id>`** — revoke a PAT by UUID.

### Preserved

- `weave login --dev-as <email>` — unchanged dev-mode impersonation. Still requires `POWERLOOM_AUTH_MODE=dev` on the API (localhost/docker-compose only).

### Deferred

- Fully-automated OIDC device-code flow (the `--oidc` stub) — lands in loomcli 0.6.0 alongside schema 2.0.0. Requires API-side device-code endpoints + a Web UI approval page; not in 0.5.1 scope.

### Notes

- Web UI URL is configurable via `POWERLOOM_WEB_URL` for local/staging development. Default: `https://powerloom.org`.
- Credentials directory is unchanged — `%APPDATA%\powerloom\powerloom\credentials` on Windows, `~/.config/powerloom/credentials` on Linux/macOS. The directory is created on first successful login.
- `__version__` also bumped from a stale `0.3.0` to match the pyproject version.

## v0.5.0 — 2026-04-23 (CLI)

**Ships schema-v1.2.0 to PyPI.** First CLI release since the renumber-to-PEP-440 fix (prior `pyproject.toml` carried an invalid `v0.4.0` string that the publish preflight would have rejected — no wheel ever reached PyPI at that version). Bumping straight to `0.5.0` to keep CLI-stream numbering monotonic and to pair cleanly with the schema-v1.2.0 payload.

- Schema bundle in wheel now includes `workflow-type`, `memory-policy`, `scope` kinds + v1.2.0 Agent/Skill extensions.
- No CLI-surface breaking changes. `weave --help` unchanged. Existing manifests keep validating.
- Gated on Powerloom engine v052 for the new kinds (earlier engines tolerate them as unknown and will 404 on apply).

## v0.3.0 — 2026-04-22 (CLI)

**First PyPI publish — `pip install loomcli` installs the `weave` console script.**

Consolidates the repo from schema-only (weavecli era) into the authoritative home for both the schema AND the CLI:

- CLI source migrated in from the Powerloom monorepo's `cli/` directory as part of the Alfred-MVP-arc v034 post-ship work. Powerloom monorepo no longer vendors CLI source; its dev story is `pip install loomcli` like everyone else.
- Repo renamed `weavecli` → `loomcli` to avoid PyPI name collision with an unrelated project. PyPI wheel name: `loomcli`. Python module: `loomcli`. CLI binary command: `weave` (unchanged — narrative fit: Loom is the tool, Powerloom is the platform, `weave` is what Loom does).
- PyPI publish workflow (`.github/workflows/publish.yml`) wired with OIDC Trusted Publishing. Tag push `vX.Y.Z` → preflight (tag matches pyproject, schema bundle present) → build wheel + sdist → smoke-test the wheel (install + `weave --version` + `--help`) → verify schema bundle inside wheel → publish to PyPI. No API token needed.
- JSON Schema inlined at `schema/v1/` (no more submodule relationship with Powerloom monorepo — the wheel bundles schema directly).
- Repo layout flattened: `loomcli/` at root, `schema/v1/` at root, `tests/` at root (with `tests/schema/` for schema test suite).

**CLI features (inherited from Powerloom monorepo's CLI at the time of migration):**

- Declarative manifests — `weave plan`, `weave apply`, `weave destroy` (kubectl-style YAML, JSON Schema validated).
- Resource inspection — `weave get`, `weave describe`, `weave import`.
- Phase-14 workflow authoring + execution — `weave workflow apply|run|status|ls|cancel`.
- Multi-session coordination — `weave agent-session register|end|ls|get|tasks|task-complete`.
- Auth — `weave auth login` (OIDC device-code stubbed; dev-mode impersonation works), `weave auth whoami`.
- PyInstaller single-binary build (`build-binary.sh` + `loomcli.spec`).

## schema-v1.2.0 — 2026-04-23

**Additive release. No breaking changes.** All v1.1.0 manifests continue to validate. Engine negotiation advertises `supported_schema_versions: ["1.0.0", "1.1.0", "1.2.0"]`; CLI picks highest mutual.

### New kinds

- **`WorkflowType`** — declarative authoring of workflow types. `coordinator_agent_id`, `memory_policy_id`, `task_kinds`, `runtime_targets` fields. Previously only REST-created.
- **`MemoryPolicy`** — per-org memory governance config: `review_cadence_hours`, `timeout_action` (`approve|forget|escalate`), `review_deadline_hours`, `tentative_weight`, `org_scope_requires_approval`, `max_memories_per_session`, `consolidation_gate`.
- **`Scope`** — explicit scope declarations (previously implicit via OU). `parent_scope_ref`, `inheritance_mode` (`full|isolated|selective`), optional `selective_inheritance` block, `retention_override`.

### Agent kind — additive fields

- `coordinator_role: bool = false` — marks an LLM-coordinator; auto-attaches grading skills.
- `task_kinds: [routing|qa|analogy|execution|coordination]` — context-assembler representation hints.
- `memory_permissions: [scope_ref]` — explicit scope allowlist for memory reads.
- `reranker_model: string | null` — optional per-agent reranker override.

### Skill kind — additive fields

- `system: bool = false` — marks skill for auto-attach per selector rules.
- `auto_attach_to: object | null` — selector with `agent_kinds`, `task_kinds`, `runtime_types`, `coordinator_role_required`. Conditions ANDed.

### Powerloom engine pairing

Powerloom engine v052 (target) accepts the new fields + adds Pydantic shapes. Existing engines at v044+ tolerate the new fields (ignored server-side on older schemas).

### Source

Draft derived from the 6-report memory/schema architecture review in `github.com/shanerlevy-debug/Powerloom:docs/memory-evolution/`. See the companion Powerloom PR #61 for the synthesis + phasing plan.

## schema-v1.1.0 — 2026-04-22

Additive sync with Powerloom engine v044 changes:
- `Skill`: added `skill_type` (`archive|tool_definition`) + `tool_schema` (JSON, required when `skill_type=tool_definition`).
- `Agent`: added `runtime_type` + `agent_kind` enum expanded to `user|service`.
- `McpDeployment`: added `isolation_mode` (`shared|dedicated`) + `template_kind` enum expanded to 15 values (echo, files, postgres, slack, powerloom_meta + 10 SaaS templates).

## schema-v1.0.0 — 2026-04-21

Initial schema extraction. Matches Powerloom monorepo v024 in shape.

**Kinds published (12 existing + 1 preview):**

- `OU`, `Group`, `GroupMembership`, `RoleBinding`
- `Skill`, `SkillAccessGrant`, `Credential`
- `MCPServerRegistration`, `MCPDeployment`
- `Agent`, `AgentSkill`, `AgentMCPServer`
- `Workflow` (preview — runtime lands in monorepo Phase 14)

**Dialect extensions introduced:**

- `x-powerloom-ref` — cross-kind reference with target kind + ID resolution
- `x-powerloom-server-field` — field populated by server, rejected on input
- `x-powerloom-immutable` — field cannot change after create
- `x-powerloom-reconciler-hint` — signals what reconciler cares about
- `x-powerloom-secret-ref` — field resolves via `CredentialStore`
- `x-powerloom-default-from-server` — default chosen server-side (policy)
- `x-powerloom-auxiliary` — field comes from an `AuxiliaryClass` (Phase 15.4)
- `x-powerloom-example` — agent-demo-grade example payload
- `x-powerloom-tier-availability` — tier gating annotation
- `x-powerloom-apply-order` — reconciler ordering hint

**Notes:**

- `apiVersion` rename: monorepo shipped `powerloom/v1`; schema publishes `powerloom.app/v1`. CLI accepts both through schema-v1; monorepo migrates to canonical form on next build.
- No CLI release in this tag — CLI shipped separately at v0.3.0 once repo renamed and CLI migrated in.
