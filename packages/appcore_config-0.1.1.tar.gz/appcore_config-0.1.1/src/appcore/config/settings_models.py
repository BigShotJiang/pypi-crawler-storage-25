"""Pydantic schema models for configuration data."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


class AppCoreBaseModel(BaseModel):
    """Base settings model with strict extra-field handling."""

    model_config = ConfigDict(extra="forbid")


class AppInfo(AppCoreBaseModel):
    """Application identity metadata."""

    name: str
    version: str


class KeyringSettings(AppCoreBaseModel):
    """Configuration for the keyring-backed key provider."""

    service_name: str = "my_app"
    username: str = "encryption_key"


class AzureKeyVaultSettings(AppCoreBaseModel):
    """Configuration for Azure Key Vault access."""

    vault_url: str


class EnvVarSettings(AppCoreBaseModel):
    """Configuration for environment-variable key lookup."""

    env_var_name: str = "APP_ENCRYPTION_KEY"


class CryptoSettings(AppCoreBaseModel):
    """Configuration for application cryptography."""

    key_name: str = "app-encryption-key"
    salt: str = "changeme-use-random-32bytes"


class SecuritySettings(AppCoreBaseModel):
    """Top-level security settings."""

    key_provider: Literal["keyring", "azure_key_vault", "env_var"] = "keyring"
    keyring: KeyringSettings = Field(default_factory=KeyringSettings)
    azure_key_vault: AzureKeyVaultSettings | None = None
    env_var: EnvVarSettings = Field(default_factory=EnvVarSettings)
    crypto: CryptoSettings = Field(default_factory=CryptoSettings)


class LoggingSinkConfig(AppCoreBaseModel):
    """Configuration for a single log sink."""

    type: str
    level: str = "DEBUG"
    path: str | None = None
    max_bytes: int = 10 * 1024 * 1024
    backup_count: int = 10
    encoding: str = "utf-8"
    when: str = "midnight"
    smtp_host: str | None = None
    smtp_port: int = 587
    use_ssl: bool = True
    from_addr: str | None = None
    to_addrs: list[str] = Field(default_factory=list)
    cc_addrs: list[str] = Field(default_factory=list)
    bcc_addrs: list[str] = Field(default_factory=list)
    subject: str = "[{levelname}] MyApp Alert"
    buffer_capacity: int = 20
    connection_name: str | None = None
    table_name: str = "app_logs"
    host: str | None = None
    port: int = 514
    facility: str = "local0"
    protocol: Literal["udp", "tcp"] = "udp"


class LoggingSettings(AppCoreBaseModel):
    """Top-level logging settings."""

    level: str = "INFO"
    structured: bool = False
    format: str = "%(asctime)s [%(levelname)-8s] %(name)s - %(message)s"
    sinks: list[LoggingSinkConfig] = Field(
        default_factory=lambda: [LoggingSinkConfig(type="console")]
    )


class EmailSettings(AppCoreBaseModel):
    """Top-level email settings."""

    smtp_host: str
    smtp_port: int = 587
    use_ssl: bool = False
    timeout: int = 30
    auth_type: Literal["plain", "oauth2", "none"] = "none"
    username: str = ""
    password: str = ""
    sender_name: str = "Application"
    sender_email: str = "noreply@example.com"


class DatabaseConnectionSettings(AppCoreBaseModel):
    """Database connection settings for one named database."""

    dialect: Literal["sqlite", "postgresql", "mssql", "mysql"]
    encrypted_connection_string: str
    host: str | None = None
    pool_size: int = 5
    max_overflow: int = 10
    pool_timeout: int = 30
    echo: bool = False


class DatabaseSettings(AppCoreBaseModel):
    """Top-level database settings."""

    default: str = "primary"
    connections: dict[str, DatabaseConnectionSettings]


class AppSettings(AppCoreBaseModel):
    """Root application settings object."""

    app: AppInfo
    security: SecuritySettings
    logging: LoggingSettings
    email: EmailSettings
    database: DatabaseSettings


JsonDict = dict[str, Any]
