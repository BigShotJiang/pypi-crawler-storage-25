"""
SnowforgeBroadcaster — the main orchestrator.

Ties together a ``ReportExporter``, email dispatch, and broadcast
configuration to export BI reports and deliver them to recipients.
"""

from __future__ import annotations

import time
from typing import Any

from .BroadcastConfig import BroadcastConfig
from .Email import Attachment, SmtpConfig, send_email
from .ParameterResolver import resolve_parameters
from .ReportExporter import ExportResult, ReportExporter
from ..Logging import Debug


class SnowforgeBroadcaster:
    """
    High-level API for exporting reports and broadcasting them.

    Parameters
    ----------
    exporter : ReportExporter
        The BI back-end to export reports from (injected).
    smtp : SmtpConfig, optional
        SMTP settings.  Defaults to ``localhost:25``.
    poll_interval : float
        Seconds between status checks while waiting for an export.
    max_poll_attempts : int
        Give up after this many polls (0 = unlimited).
    """

    def __init__(self, exporter: ReportExporter, *, smtp: SmtpConfig | None = None, poll_interval: float = 5.0, max_poll_attempts: int = 240) -> None:
        
        self.exporter = exporter
        self.smtp = smtp or SmtpConfig()
        self.poll_interval = poll_interval
        self.max_poll_attempts = max_poll_attempts


    def export_report(self, config: BroadcastConfig) -> ExportResult:
        """
        Export and download a report.  Blocks until complete or failed.

        Returns
        -------
        ExportResult
            The downloaded file bytes and filename.

        Raises
        ------
        RuntimeError
            If the export fails or times out.
        """
        export_id = self.exporter.start_export(
            workspace_id=config.workspace_id,
            report_id=config.report_id,
            parameters=resolve_parameters(config.parameters),
        )
        Debug.log(f"Export started: {export_id}", "INFO")

        result = self._wait_for_export(config, export_id)
        Debug.log(f"Export complete: {export_id} → {result.filename}", "SUCCESS")
        return result

    def broadcast(self, config: BroadcastConfig) -> ExportResult:
        """
        Full pipeline: export the report, then deliver it.

        Currently supports ``channel="email"``.  Extend the
        ``_deliver`` method for Teams or other channels.
        """
        result = self.export_report(config)
        self._deliver(config, result)
        return result

    # ------------------------------------------------------------------
    # Delivery
    # ------------------------------------------------------------------

    def _deliver(self, config: BroadcastConfig, result: ExportResult) -> None:
        channel = config.channel.lower()

        if channel == "email":
            self._deliver_email(config, result)
            
        elif channel == "teams":
            raise NotImplementedError("Teams delivery is not yet implemented")

        else:
            raise ValueError(f"Unknown delivery channel: {channel!r}")

    def _deliver_email(self, config: BroadcastConfig, result: ExportResult) -> None:
        send_email(
            subject=config.subject,
            sender=config.sender,
            recipients=config.recipients,
            body=config.body,
            attachments=[
                Attachment(data=result.content, filename=result.filename)
            ],
            smtp=self.smtp,
        )
        Debug.log(
            f"Email delivered to {', '.join(config.recipients)} ({result.filename})",
            "SUCCESS",
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _wait_for_export(
        self, config: BroadcastConfig, export_id: str
    ) -> ExportResult:
        attempts = 0
        while True:
            time.sleep(self.poll_interval)
            attempts += 1

            status = self.exporter.poll_status(
                config.workspace_id, config.report_id, export_id
            )
            
            print(status)

            if status == "completed":
                return self.exporter.download(
                    config.workspace_id, config.report_id, export_id
                )

            if status == "failed":
                Debug.log(
                    f"Export {export_id} failed during processing.", "ERROR"
                )
                raise RuntimeError(
                    f"Export {export_id} failed during processing."
                )

            if self.max_poll_attempts and attempts >= self.max_poll_attempts:
                Debug.log(
                    f"Export {export_id} timed out after {attempts} polls.",
                    "ERROR",
                )
                raise TimeoutError(
                    f"Export {export_id} timed out after {attempts} polls."
                )

            Debug.log(
                f"Export {export_id} still running (poll {attempts}/{self.max_poll_attempts or '∞'})",
                "DEBUG",
            )
