"""
Dynamic token substitution for report parameters.

Tokens are replaced at export time so configuration files can reference
relative dates without hardcoding values.

Supported tokens
----------------
$$TODAY          ISO date of today              (e.g. 2026-05-12)
$$YESTERDAY      ISO date of yesterday          (e.g. 2026-05-11)
$$CURRENT_WEEK   ISO week number of this week   (e.g. 20)
$$LAST_WEEK      ISO week number of last week   (e.g. 19)
$$CURRENT_MONTH  Month number of this month     (e.g. 5)
$$LAST_MONTH     Month number of last month     (e.g. 4)
$$CURRENT_YEAR   Current year                   (e.g. 2026)
$$LAST_YEAR      Previous year                  (e.g. 2025)
"""

from __future__ import annotations

from datetime import date, timedelta
from typing import Any


def _today() -> date:
    return date.today()


_TOKENS: dict[str, Any] = {
    "$$TODAY":         lambda: _today().isoformat(),
    "$$YESTERDAY":     lambda: (_today() - timedelta(days=1)).isoformat(),
    "$$CURRENT_WEEK":  lambda: str(_today().isocalendar()[1]),
    "$$LAST_WEEK":     lambda: str((_today() - timedelta(weeks=1)).isocalendar()[1]),
    "$$CURRENT_MONTH": lambda: str(_today().month),
    "$$LAST_MONTH":    lambda: str((_today().replace(day=1) - timedelta(days=1)).month),
    "$$CURRENT_YEAR":  lambda: str(_today().year),
    "$$LAST_YEAR":     lambda: str(_today().year - 1),
}


def resolve_parameters(parameters: dict[str, Any] | None) -> dict[str, Any] | None:
    """Replace dynamic tokens in parameter values and return a new dict."""
    if not parameters:
        return parameters

    resolved: dict[str, Any] = {}
    for key, value in parameters.items():
        if isinstance(value, str):
            for token, resolver in _TOKENS.items():
                if token in value:
                    value = value.replace(token, resolver())
        resolved[key] = value
    return resolved
