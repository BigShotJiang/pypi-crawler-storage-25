"""
Fabric / Power BI adapter for the ReportExporter protocol.

Wraps your existing ``FabricIntegration`` class so the broadcaster
doesn't depend on it directly.
"""

from __future__ import annotations

from typing import Any

from ..ReportExporter import ExportResult, ReportExporter
from ...Logging import Debug


class FabricExporter(ReportExporter):
    """
    Bridges ``FabricIntegration`` into the ``ReportExporter`` interface.

    Parameters
    ----------
    fabric : object
        An instance of your ``FabricIntegration`` class.  Accepted as a
        plain object so this module never imports FabricIntegration
        itself — you wire it up from the outside.
    """

    def __init__(self, fabric: object) -> None:
        self._fabric = fabric  # type: ignore[assignment]

    # ------------------------------------------------------------------
    # ReportExporter implementation
    # ------------------------------------------------------------------

    def start_export(
        self,
        workspace_id: str,
        report_id: str,
        parameters: dict[str, Any] | None = None,
    ) -> str:
        resp = self._fabric.export_paginated_report(
            self._fabric.access_token,
            workspace_id,
            report_id,
            parameters,
        )
        if resp is None:
            raise RuntimeError(
                f"Export request failed for report {report_id} in workspace {workspace_id}. "
                "Check earlier log messages for details."
            )
        export_id: str = resp.json()["id"]
        Debug.log(f"Started Fabric export {export_id}", "INFO")
        return export_id

    def poll_status(
        self,
        workspace_id: str,
        report_id: str,
        export_id: str,
    ) -> str:
        status_code = self._fabric.check_report_status(
            workspace_id, report_id, export_id
        )
        
        mapping = {200: "Completed", 202: "InProgress", 500: "Failed"}
        result = mapping.get(status_code, "Failed")
        print(result) # bash script reads this line to determine export status, so it must be exactly "Completed", "InProgress", or "Failed"

        return result

    def download(
        self,
        workspace_id: str,
        report_id: str,
        export_id: str,
    ) -> ExportResult:
        content, name = self._fabric.download_report(
            workspace_id, report_id, export_id
        )
        return ExportResult(content=content, filename=name)
