"""
This module is recent, used with `FrameBuffer`
and working properly, a bit more strict than
others you can find in the project and maybe
should be removed.
"""
from yta_programming.decorators.requires_dependency import requires_dependency
from yta_editor_pools.texture import create_texture, create_texture_like


@requires_dependency('numpy', 'yta_editor_frame', 'numpy')
def _texture_to_numpy_frame(
    texture: 'moderngl.Texture',
    do_flip_texture: bool = True,
    do_force_contiguous: bool = False
):
    """
    *For internal use only*

    Create a `np.ndarray` from the `texture` provided
    and return it.

    This method is only meant to be used within
    the `FrameBuffer` class.

    This frame is not forced to be contiguous.
    """
    import numpy as np

    dtype_map = {
        'f1': np.uint8,
        'f2': np.float16,
        'f4': np.float32,
    }

    np_dtype = dtype_map.get(texture.dtype)

    if np_dtype is None:
        raise Exception(f'Unsupported texture dtype: {texture.dtype}')

    data = texture.read()
    frame = np.frombuffer(data, dtype = np_dtype)
    # The format is (height, width, number_of_components)
    frame = frame.reshape(texture.height, texture.width, texture.components)

    # Flip it
    frame = (
        np.flipud(frame)
        if do_flip_texture else
        frame
    )

    # Force it as contiguous
    frame = (
        np.ascontiguousarray(frame)
        if do_force_contiguous else
        frame
    )

    # # We always force 'RGBA'
    # frame = _ensure_rgba_numpy_array(frame)

    return frame

@requires_dependency('numpy', 'yta_editor_frame', 'numpy')
def _ensure_rgba_numpy_array(
    ndarray: 'np.ndarray',
    do_force_contiguous: bool = False
) -> 'np.ndarray':
    """
    *For internal use only*

    Transform the `ndarray` provided to make sure
    that it is representing a 'rgba' frame,
    compatible with textures like the following one:
    - `dtype = uint8`
    - `shape = (H, W, 4)`
    - `layout = RGBA`

    This method is only meant to be used within
    the `FrameBuffer` class.

    This array is forced to be contiguous if the
    `do_force_contiguous` parameter is `True`, that
    must be set as `True` when we are about to use
    that frame to build a texture o to write with
    the pyav library.
    """
    import numpy as np

    if ndarray.ndim == 2:
        ndarray = np.repeat(ndarray[:, :, None], 3, axis = 2)

    if ndarray.shape[2] == 3:
        alpha = np.full(
            (ndarray.shape[0], ndarray.shape[1], 1),
            (
                255
                if ndarray.dtype == np.uint8 else
                1.0
            ),
            dtype = ndarray.dtype
        )
        # alpha = np.full((ndarray.shape[0], ndarray.shape[1], 1), 255, dtype = ndarray.dtype)
        ndarray = np.concatenate((ndarray, alpha), axis = 2)

    if ndarray.shape[2] != 4:
        raise Exception('The format of this numpy array is not accepted.')
    
    # Force uint8
    if ndarray.dtype != np.uint8:
        if np.issubdtype(ndarray.dtype, np.floating):
            max_val = ndarray.max()

            # Standard heuristic (could be wrong)
            if max_val <= 1.0:
                ndarray = ndarray * 255.0

        ndarray = np.clip(ndarray, 0, 255).astype(np.uint8)
    
    ndarray = (
        np.ascontiguousarray(ndarray)
        if do_force_contiguous else
        ndarray
    )

    return ndarray

@requires_dependency('numpy', 'yta_editor_frame', 'numpy')
@requires_dependency('moderngl', 'yta_editor_frame', 'moderngl')
def _numpy_frame_to_texture(
    numpy_frame: 'np.ndarray',
    render_context: 'RenderContext',
    do_flip: bool = True,
    do_from_pool: bool = True
) -> 'moderngl.Texture':
    """
    *For internal use only*

    Create a `moderngl.Texture` from the given
    `numpy_frame` and return it.

    This method is only meant to be used within
    the `FrameBuffer` class.

    Please, remember to release the texture when
    finished as it is being extracted from the
    pool.
    """
    import moderngl

    # Flip and make it contiguous
    numpy_frame = _prepare_numpy_frame_for_texture(
        numpy_frame = numpy_frame,
        do_flip = do_flip
    )

    number_of_components = (
        numpy_frame.shape[2]
        if numpy_frame.ndim == 3 else
        1
    )

    """
    We are always using 'np.uint8' because we are also
    forcing 'f1' textures dtype.
    """
    # TODO: Sometimes we can receive a 'float32', why (?)
    # TODO: Transform dtype to texture dtype with utils
    dtype = (
        'f1'
        if numpy_frame.dtype.name == 'uint8' else
        'f4'
        if numpy_frame.dtype.name == 'float32' else
        # This is not ok, but by now...
        'f1'
    )

    height, width = numpy_frame.shape[:2]

    # Obtain or create the texture
    texture = (
        render_context.gpu.texture.acquire(
            width = width,
            height = height,
            number_of_components = number_of_components,
            dtype = dtype
        )
        if do_from_pool else
        create_texture(
            opengl_context = render_context.gpu.context,
            data = None,
            width = width,
            height = height,
            number_of_components = number_of_components,
            dtype = dtype
        )
    )

    # Write the data
    texture.write(numpy_frame)

    # TODO: Make this configurable
    # Set the filter
    texture.filter = (moderngl.NEAREST, moderngl.NEAREST)

    return texture

def _prepare_numpy_frame_for_texture(
    numpy_frame: 'np.ndarray',
    do_flip: bool = True
) -> 'np.ndarray':
    """
    *For internal use only*

    Prepare the `numpy_frame` to be loaded in a
    `moderngl.Texture` doing the following:
    - Flipping it if `do_flip` is `True`
    - Forcing it as a contiguous array
    """
    import numpy as np

    # 1. Flip
    numpy_frame = (
        np.flipud(numpy_frame)
        if do_flip else
        numpy_frame
    )

    # 2. Contiguous
    numpy_frame = np.ascontiguousarray(numpy_frame)

    return numpy_frame

def copy_texture(
    texture: 'moderngl.Texture',
    render_context: 'RenderContext',
    do_get_from_pool: bool = True
    # TODO: Add 'filter' to make it customizable
) -> 'moderngl.Texture':
    """
    Copy the `texture` provided to a new one and
    return it. The new texture will be obtained
    from the pool if the `do_get_from_pool` boolean
    flag is `True`, or freely created if `False`.
    """
    new_texture = (
        render_context.gpu.texture.acquire_like(
            texture = texture
        )
        if do_get_from_pool else
        create_texture_like(
            opengl_context = render_context.gpu.context,
            data = None,
            texture = texture
        )
    )

    new_texture.write(texture.read())

    return new_texture