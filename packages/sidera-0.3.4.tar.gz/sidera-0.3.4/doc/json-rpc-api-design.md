# JSON-RPC API Design

## 1. Dependent Higher-Level Documents

- [README.md](../README.md)

## 2. Scope

This document defines the planned structure for exposing the existing Sidera API through JSON-RPC over standard input/output.

The current implementation scope is JSON-RPC API support only. LSP support is not included in this change. However, the structure should keep a clear boundary so that LSP support can be added later without reshaping the core JSON-RPC transport and dispatch layers.

## 3. Current Structure

The current source tree is a Python package under `src/sidera`.

Important existing responsibilities are:

- `src/sidera/main.py`: Application initialization, initial scenario loading, and worker startup.
- `src/sidera/config/arguments.py`: Command-line argument definitions and parsing.
- `src/sidera/api/sidera_api.py`: Composite API class built from API mixins.
- `src/sidera/api/mixin/`: Scenario, node, event, player, and login API operations.
- `src/sidera/api/reply.py`: API result wrapper and exception handling.
- `src/sidera/task/`: Session, context, and async worker management.
- `src/sidera/event/`: Event subscription and dispatch.
- `src/sidera/scenario/`: Scenario domain model and node operations.

The existing `SideraApi` class is suitable as the application-facing API boundary for JSON-RPC. The JSON-RPC layer should adapt requests to existing API method calls rather than duplicate scenario or node logic.

## 4. Proposed Structure

Add a new `rpc` package under `src/sidera`.

```text
src/sidera/
  main.py
  app.py                         # Optional shared bootstrap module.

  config/
    arguments.py                 # Add --stdio.

  api/
    sidera_api.py
    mixin/
    reply.py
    types.py

  rpc/
    __init__.py
    jsonrpc.py                   # JSON-RPC 2.0 request, response, and error models.
    stdio.py                     # Standard I/O transport and Content-Length framing.
    router.py                    # JSON-RPC method dispatch to SideraApi.
    serializers.py               # JSON serialization for API return values.
    errors.py                    # Exception to JSON-RPC error conversion.
    events.py                    # JSON-RPC event subscription management.
    server.py                    # Stdio server loop integrating transport and router.
    methods.py                   # Public JSON-RPC method name definitions.

  task/
  event/
  scenario/
  player/
  plugin/
  utils/
```

The `rpc` package must not contain LSP-specific concepts such as `initialize`, `shutdown`, `textDocument/*`, or capability negotiation. Those belong in a future `lsp` package if LSP support is added.

## 5. Runtime Flow

The planned standard I/O mode should use the following flow:

```text
stdin/stdout
  -> rpc.stdio
  -> rpc.jsonrpc
  -> rpc.router
  -> SideraApi
  -> rpc.serializers
  -> rpc.jsonrpc
  -> rpc.stdio
```

The `--stdio` command-line option selects this mode.

`main.py` should branch by mode:

```text
main(args)
  init_application(args)
  if Arguments.args.stdio:
      run_rpc_stdio()
  else:
      run_default()
```

If `main.py` becomes too responsible for mode-specific startup, shared bootstrap logic may be moved into `src/sidera/app.py`.

## 6. JSON-RPC Method Naming

Public JSON-RPC methods should use a stable external naming convention and map to the existing Python API internally.

Recommended method names:

```text
sidera.loadScenarioFromFile
sidera.loadScenarioFromJson
sidera.getScenarioIds
sidera.clearScenarios
sidera.selectCurrentScenario
sidera.getCurrentScenario
sidera.getScenarioInfo

sidera.dumpJson
sidera.loadJson
sidera.getData
sidera.getPatch
sidera.getNodeInfo
sidera.patch
sidera.syncData
sidera.append
sidera.clear
sidera.remove

sidera.subscribe
sidera.unsubscribe
```

The router should map these names to the existing snake_case API methods, for example:

```text
sidera.getNodeInfo -> SideraApi.get_node_info
sidera.loadScenarioFromFile -> SideraApi.load_scenario_from_file
```

Using camelCase externally keeps the JSON-RPC surface compatible with common editor and language tooling conventions while preserving the existing Python API style internally.

## 7. Event Notifications

JSON-RPC event notifications are exposed through RPC-specific subscription methods.

```text
sidera.subscribe
sidera.unsubscribe
```

`sidera.subscribe` registers a server-side event subscriber and returns a subscription identifier.

Parameters:

```json
{
  "target": "signals",
  "name": "optional subscriber name"
}
```

The `target` parameter accepts a node target string or a list of node target strings. The `name` parameter is optional.

Result:

```json
{
  "subscriptionId": "<uuid>"
}
```

`sidera.unsubscribe` removes a registered subscription.

Parameters:

```json
{
  "subscriptionId": "<uuid>"
}
```

When a subscribed event is received, the server sends a JSON-RPC notification.

```json
{
  "jsonrpc": "2.0",
  "method": "sidera.event",
  "params": {
    "subscriptionId": "<uuid>",
    "event": {},
    "subscription": "<subscription>"
  }
}
```

The `event` value is serialized by `rpc.serializers.to_json_value`. The `subscription` value is the string representation of the underlying subscription.

The JSON-RPC layer owns these RPC event subscriptions. They are backed by the existing event subscriber mechanism, and are closed when explicitly unsubscribed or when the router is closed.

## 8. Error Handling

The JSON-RPC layer should call `SideraApi` with `raise_exceptions=False` where practical, then convert `Reply` objects into JSON-RPC responses.

Suggested error mapping:

- Invalid JSON or invalid JSON-RPC envelope: `-32700` or `-32600`.
- Unknown method: `-32601`.
- Invalid parameters: `-32602`.
- Internal API exception: `-32000`.

The response should include a concise error message. Detailed traceback data should be sent to logs rather than JSON-RPC responses.

## 9. Serialization

`rpc.serializers` should centralize conversion of API return values into JSON-compatible data.

It should support:

- Pydantic models.
- Tuples and lists.
- Dictionaries.
- Paths and pure paths.
- Node identifiers and scenario identifiers.
- Primitive values.
- `None`.

Scenario and node data should preserve the existing model structure as much as possible. Serialization should be deterministic so tests can compare exact JSON payloads.

## 10. Standard I/O Constraints

When `--stdio` is active, stdout is reserved for JSON-RPC messages only.

Existing console and event logging currently use stdout in some places. In stdio mode, logs must be redirected to stderr or a file, or console logging must be disabled. Any non-protocol output on stdout can corrupt the JSON-RPC stream.

The stdio transport should use Content-Length framing:

```text
Content-Length: <byte length>

<json payload>
```

The byte length must be calculated from the UTF-8 encoded payload.

## 11. Test Structure

Add focused tests under `test/rpc`.

```text
test/
  rpc/
    test_jsonrpc.py              # Request, response, and error models.
    test_stdio.py                # Content-Length framing.
    test_router.py               # Method dispatch.
    test_server.py               # Representative stdio server cases.
    test_serializers.py          # JSON-compatible API result conversion.
    test_api_calls.py            # Representative call coverage for public JSON-RPC APIs.
    test_events.py               # JSON-RPC event subscribe, notification, and unsubscribe.

  test_args.py                   # --stdio argument behavior.
```

The tests should cover both successful API calls and error responses.

## 12. Future LSP Compatibility

LSP support should be added later as a separate package, not as part of the current JSON-RPC API change.

Possible future structure:

```text
src/sidera/
  lsp/
    __init__.py
    server.py
    methods.py
    types.py
```

The future LSP layer should reuse:

- `rpc.jsonrpc`
- `rpc.stdio`
- `rpc.errors`
- parts of `rpc.serializers`

The future LSP layer should provide its own method router because LSP has protocol-specific lifecycle methods, capabilities, notifications, and request naming rules.

## 13. Design Decision Summary

The current change should add only the `rpc` package and the `--stdio` mode.

The existing API, scenario, event, and task packages should remain the core application layers. JSON-RPC should be implemented as an adapter around `SideraApi`, with no scenario-domain logic duplicated inside `rpc`.

No `lsp` folder should be added in this change. The design keeps LSP support possible by keeping JSON-RPC transport, message parsing, error conversion, and serialization protocol-neutral.
