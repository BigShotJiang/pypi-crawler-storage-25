"""Validate, tag, build, and optionally upload a Sidera release to PyPI."""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import tarfile
import urllib.error
import urllib.request
import zipfile
from dataclasses import dataclass
from pathlib import Path

try:
    import tomllib
except ModuleNotFoundError:  # pragma: no cover - Python < 3.11 compatibility
    import tomli as tomllib


ROOT = Path(__file__).resolve().parents[1]
RELEASE_DIST = ROOT / "dist" / "release"
VERSION_RE = re.compile(
    r"^v?(?P<major>0|[1-9]\d*)\.(?P<minor>0|[1-9]\d*)\.(?P<patch>0|[1-9]\d*)$"
)
FORBIDDEN_SDIST_PARTS = {
    ".agent",
    ".devcontainer",
    ".github",
    ".vscode",
    "test",
    "requirements-dev.lock",
    "requirements.lock",
    "uv.lock",
    ".pre-commit-config.yaml",
    ".python-version",
    "pytest.ini",
    "ruff.toml",
}


@dataclass(frozen=True, order=True)
class Version:
    major: int
    minor: int
    patch: int

    @classmethod
    def parse(cls, value: str) -> Version:
        match = VERSION_RE.match(value)
        if not match:
            raise ValueError(f"unsupported version: {value!r}; use MAJOR.MINOR.PATCH")
        return cls(*(int(match.group(part)) for part in ("major", "minor", "patch")))

    def bump(self, part: str) -> Version:
        if part == "major":
            return Version(self.major + 1, 0, 0)
        if part == "minor":
            return Version(self.major, self.minor + 1, 0)
        if part == "patch":
            return Version(self.major, self.minor, self.patch + 1)
        raise ValueError(f"unsupported bump part: {part}")

    def __str__(self) -> str:
        return f"{self.major}.{self.minor}.{self.patch}"


def run(
    command: list[str],
    *,
    check: bool = True,
    capture: bool = False,
    env: dict[str, str] | None = None,
) -> str:
    print("+", " ".join(command), flush=True)
    result = subprocess.run(
        command,
        cwd=ROOT,
        check=False,
        text=True,
        stdout=subprocess.PIPE if capture else None,
        stderr=subprocess.STDOUT if capture else None,
        env=env,
    )
    output = result.stdout or ""
    if capture and output:
        print(output, end="" if output.endswith("\n") else "\n")
    if check and result.returncode != 0:
        raise SystemExit(result.returncode)
    return output


def project_name() -> str:
    with (ROOT / "pyproject.toml").open("rb") as handle:
        data = tomllib.load(handle)
    return data["project"]["name"]


def git_output(*args: str) -> str:
    return run(["git", *args], capture=True).strip()


def ensure_clean_worktree(*, allow_dirty: bool) -> None:
    status = git_output("status", "--porcelain")
    if status:
        if allow_dirty:
            print(
                "WARNING: working tree is dirty; continuing because --allow-dirty was set."
            )
            return
        raise SystemExit(
            "Working tree is not clean. Commit or stash changes before releasing:\n"
            + status
        )


def ensure_release_ref(*, required_branch: str, required_remote_ref: str) -> None:
    branch = git_output("branch", "--show-current")
    if branch != required_branch:
        raise SystemExit(
            f"Release upload must run on branch {required_branch!r}; current branch is {branch!r}."
        )

    head = git_output("rev-parse", "HEAD")
    remote = git_output("rev-parse", required_remote_ref)
    if head != remote:
        raise SystemExit(
            "Release upload must run from the same commit as "
            f"{required_remote_ref}; HEAD={head[:12]}, {required_remote_ref}={remote[:12]}."
        )


def latest_release_version(prefix: str) -> Version:
    tags = git_output(
        "tag", "--list", f"{prefix}*", "--sort=-version:refname"
    ).splitlines()
    for tag in tags:
        try:
            return Version.parse(tag.removeprefix(prefix))
        except ValueError:
            continue
    raise SystemExit(f"No release tags matching {prefix}MAJOR.MINOR.PATCH were found.")


def target_version(args: argparse.Namespace) -> Version:
    if args.version:
        return Version.parse(args.version)
    return latest_release_version(args.tag_prefix).bump(args.bump)


def pypi_json_url(repository: str, package: str, version: Version) -> str | None:
    repositories = {
        "pypi": "https://pypi.org/pypi/{package}/{version}/json",
        "testpypi": "https://test.pypi.org/pypi/{package}/{version}/json",
    }
    template = repositories.get(repository)
    if template is None:
        return None
    return template.format(package=package, version=version)


def ensure_version_not_uploaded(
    repository: str, package: str, version: Version
) -> None:
    url = pypi_json_url(repository, package, version)
    if url is None:
        print(f"Skipping version existence check for custom repository: {repository}")
        return
    request = urllib.request.Request(url, headers={"Accept": "application/json"})
    try:
        with urllib.request.urlopen(request, timeout=15) as response:
            if response.status == 200:
                raise SystemExit(f"{package} {version} already exists on {repository}.")
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            print(f"{package} {version} is not present on {repository}.")
            return
        raise SystemExit(f"Failed to check {repository}: HTTP {exc.code}") from exc
    except urllib.error.URLError as exc:
        raise SystemExit(f"Failed to check {repository}: {exc}") from exc


def ensure_tag_absent(tag: str) -> None:
    result = subprocess.run(
        ["git", "rev-parse", "-q", "--verify", f"refs/tags/{tag}"], cwd=ROOT
    )
    if result.returncode == 0:
        raise SystemExit(f"Tag already exists: {tag}")


def create_tag(tag: str, *, dry_run: bool) -> None:
    if dry_run:
        print(f"DRY RUN: would create tag {tag}")
        return
    run(["git", "tag", "-a", tag, "-m", f"Release {tag}"])


def delete_tag(tag: str) -> None:
    run(["git", "tag", "-d", tag], check=False)


def metadata_version(path: Path) -> str:
    if path.suffix == ".whl":
        with zipfile.ZipFile(path) as archive:
            metadata_name = next(
                name
                for name in archive.namelist()
                if name.endswith(".dist-info/METADATA")
            )
            metadata = archive.read(metadata_name).decode()
    else:
        with tarfile.open(path) as archive:
            metadata_name = next(
                name for name in archive.getnames() if name.endswith("PKG-INFO")
            )
            member = archive.extractfile(metadata_name)
            if member is None:
                raise SystemExit(f"Could not read {metadata_name}")
            metadata = member.read().decode()
    for line in metadata.splitlines():
        if line.startswith("Version: "):
            return line.removeprefix("Version: ").strip()
    raise SystemExit(f"No Version metadata found in {path}")


def assert_release_metadata(files: list[Path], version: Version) -> None:
    expected = str(version)
    for file in files:
        actual = metadata_version(file)
        if actual != expected:
            raise SystemExit(f"{file.name} has version {actual}; expected {expected}")
        if "+" in actual or ".dev" in actual:
            raise SystemExit(f"{file.name} has a non-release version: {actual}")


def assert_sdist_contents(sdist: Path) -> None:
    with tarfile.open(sdist) as archive:
        names = archive.getnames()
    violations: list[str] = []
    for name in names:
        parts = Path(name).parts[1:]
        if any(part in FORBIDDEN_SDIST_PARTS for part in parts):
            violations.append(name)
        if "__pycache__" in parts or name.endswith((".pyc", ".pyo", ".pyd")):
            violations.append(name)
    if violations:
        joined = "\n".join(violations[:40])
        suffix = "\n..." if len(violations) > 40 else ""
        raise SystemExit(f"sdist contains forbidden files:\n{joined}{suffix}")


def build_release(version: Version, *, pretend_version: bool) -> list[Path]:
    if RELEASE_DIST.exists():
        shutil.rmtree(RELEASE_DIST)
    env = os.environ.copy()
    if pretend_version:
        env["SETUPTOOLS_SCM_PRETEND_VERSION"] = str(version)
    run(
        [
            "uv",
            "build",
            "--out-dir",
            str(RELEASE_DIST),
            "--clear",
            "--no-create-gitignore",
        ],
        env=env,
    )
    files = sorted(RELEASE_DIST.glob(f"sidera-{version}*"))
    if len(files) != 2:
        raise SystemExit(
            f"Expected exactly 2 release artifacts for {version}, found {len(files)}."
        )
    sdist = next(
        (path for path in files if path.suffixes[-2:] == [".tar", ".gz"]), None
    )
    wheel = next((path for path in files if path.suffix == ".whl"), None)
    if sdist is None or wheel is None:
        raise SystemExit(f"Expected one sdist and one wheel in {RELEASE_DIST}.")
    assert_release_metadata([sdist, wheel], version)
    assert_sdist_contents(sdist)
    return [sdist, wheel]


def twine_check(files: list[Path]) -> None:
    run(["uv", "run", "twine", "check", *(str(path) for path in files)])


def upload(files: list[Path], repository: str) -> None:
    command = ["uv", "run", "twine", "upload"]
    if repository in {"pypi", "testpypi"}:
        command += ["--repository", repository]
    else:
        command += ["--repository-url", repository]
    command += [str(path) for path in files]
    run(command)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--version", help="Release version to create, for example 0.3.1."
    )
    parser.add_argument("--bump", choices=("patch", "minor", "major"), default="patch")
    parser.add_argument("--tag-prefix", default="v")
    parser.add_argument(
        "--repository", default="pypi", help="pypi, testpypi, or a repository URL."
    )
    parser.add_argument(
        "--upload", action="store_true", help="Upload artifacts after all checks pass."
    )
    parser.add_argument(
        "--push-tag",
        action="store_true",
        help="Push the created tag after a successful upload.",
    )
    parser.add_argument("--skip-ruff", action="store_true")
    parser.add_argument("--skip-tests", action="store_true")
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Run checks without creating a tag or uploading.",
    )
    parser.add_argument(
        "--allow-dirty",
        action="store_true",
        help="Allow a dirty worktree for dry-run checks only.",
    )
    parser.add_argument(
        "--yes", action="store_true", help="Confirm tag creation and upload."
    )
    parser.add_argument(
        "--release-branch",
        default="main",
        help="Branch required for upload. Defaults to main.",
    )
    parser.add_argument(
        "--release-remote-ref",
        default="origin/main",
        help="Remote ref HEAD must match for upload. Defaults to origin/main.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    package = project_name()
    version = target_version(args)
    tag = f"{args.tag_prefix}{version}"
    dry_run = args.dry_run or not args.upload

    print(
        json.dumps(
            {
                "package": package,
                "version": str(version),
                "tag": tag,
                "repository": args.repository,
            },
            indent=2,
        )
    )
    if args.upload and args.allow_dirty:
        raise SystemExit("--allow-dirty cannot be used with --upload.")
    ensure_clean_worktree(allow_dirty=args.allow_dirty)
    if args.upload:
        ensure_release_ref(
            required_branch=args.release_branch,
            required_remote_ref=args.release_remote_ref,
        )
    ensure_tag_absent(tag)
    ensure_version_not_uploaded(args.repository, package, version)

    if not args.skip_ruff:
        run(["uv", "run", "ruff", "check"])
    if not args.skip_tests:
        run(["uv", "run", "pytest", "-q"])

    if args.upload and not args.yes:
        raise SystemExit("Refusing to create a release without --yes.")

    tag_created = False
    cleanup_tag_on_failure = True
    try:
        create_tag(tag, dry_run=dry_run)
        tag_created = not dry_run
        files = build_release(version, pretend_version=dry_run)
        twine_check(files)
        if args.upload:
            cleanup_tag_on_failure = False
            upload(files, args.repository)
            if args.push_tag:
                run(["git", "push", "origin", tag])
        else:
            print("DRY RUN: upload skipped. Add --upload --yes to publish.")
    except BaseException:
        if tag_created and cleanup_tag_on_failure:
            print(f"Release failed; deleting local tag {tag}.", file=sys.stderr)
            delete_tag(tag)
        raise


if __name__ == "__main__":
    main()
