from enum import Enum
from importlib import resources
from pathlib import Path

# Sample scenario data
TEST_DATA_MODULE = "sidera_test_data"
SAMPLE_FOLDER = "scenario"
_sample_folder = Path(str(resources.files(TEST_DATA_MODULE) / SAMPLE_FOLDER))


class SampleScenario(str, Enum):
    """Sample scenarios for testing."""

    # Sample scenarios list
    power = "power"

    @property
    def path(self):
        """Get the path of the sample scenario."""
        return _sample_folder / f"{self.value}.json"

    def read_text(self) -> str:
        """Read the text of the sample scenario."""
        return self.path.read_text(encoding="utf-8", errors="ignore")

    @classmethod
    def get_list(cls):
        """Get the list of sample scenarios."""
        return [item.value for item in cls]
