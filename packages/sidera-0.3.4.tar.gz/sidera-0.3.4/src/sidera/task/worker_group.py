import asyncio
from collections.abc import Coroutine
from logging import getLogger

from typing_extensions import Self

from .asyncio_compat import TaskGroup
from .context import Context
from .worker_task import WorkerTask

log = getLogger(__name__)


class WorkerGroup(TaskGroup):
    """Worker task group class."""

    @classmethod
    def get_current(cls) -> Self:
        """Get the current task group."""
        return Context.get_by_type(cls)

    def __init__(self):
        super().__init__()
        self._running = False
        self._done = False
        self._workers: list[WorkerTask] = []

    @classmethod
    def clear(cls):
        """Clear all worker tasks."""
        cls.stop()
        current = cls.get_current()
        current._workers.clear()
        self = cls()
        Context.set_by_type(self)
        assert cls.get_current() is self
        return self

    @classmethod
    def append_worker(cls, coro: Coroutine, name: str):
        """Create a task."""
        self = cls.get_current()
        worker = WorkerTask(coro, name)
        self._workers.append(worker)
        if self._running:
            worker.run(self)
        return worker

    @classmethod
    def reset(cls):
        """Reset the task group."""
        self = cls.get_current()
        workers = self._workers
        self = cls.clear()
        self._workers = workers

    @classmethod
    def start(cls, timeout: float | None = None):
        """Run all worker tasks with default session."""
        self = cls.get_current()
        try:
            self._running = True
            if timeout is None:
                asyncio.run(self._start_workers())
            else:
                asyncio.run(self._start_timeout(timeout))
        except KeyboardInterrupt:
            log.warning("KeyboardInterrupt: stopping all tasks.")
        finally:
            self._running = False
            self._done = True

    async def _start_timeout(self, delay: float):
        """Start the task group with timeout."""
        try:
            await asyncio.wait_for(self._start_workers(), timeout=delay)
        except asyncio.TimeoutError:
            log.warning("TimeoutError: stopping all tasks.")
            self.stop()
            raise

    async def _start_workers(self):
        """Start the task group."""
        log.debug("All tasks start.")
        async with self:
            for worker in self._workers:
                worker.run(self)
            log.debug("Started tasks: %s", ", ".join(repr(wk) for wk in self._workers))
        log.debug("All tasks completed.")

    @classmethod
    def stop(cls):
        """Cancel all worker tasks of default session."""
        self = cls.get_current()
        if self._running:
            for worker in self._workers:
                worker.cancel()

    @classmethod
    def is_running(cls) -> bool:
        """Check if the task group is running."""
        return cls.get_current()._running

    @classmethod
    def done(cls) -> bool:
        """Check if the task group is done."""
        return cls.get_current()._done
