from contextvars import ContextVar
from time import time

from typing_extensions import Self

DEFAULT_USER_NAME = "__anonymous__"


class Session:
    """Session data class"""

    __default: Self | None = None
    __ctx_var = ContextVar["Session | None"]("sidera session", default=None)

    def __new__(cls, *args, **kwargs):
        """Setup default object."""
        if cls.__default is None:
            cls.__default = super().__new__(cls)
            assert args[0] == DEFAULT_USER_NAME, "First session must be default."
            return cls.__default
        return super().__new__(cls)

    def __init__(
        self,
        user_name: str,
        session_name: str | None = None,
        timeout_sec: int | None = None,
    ):
        self._user_name = user_name
        self._session_name = session_name or f"user: {user_name}"
        self._level = 0
        self._timeout_sec = timeout_sec
        self._timeout = (
            None if timeout_sec is None else self._start_time + timeout_sec * 1000
        )
        self.open()

    def open(self):
        """Set the session as active."""
        self._start_time = time()
        self._end_time = None
        self.__ctx_var.set(self)
        return

    def close(self):
        """Set the session as done."""
        assert self is not self.__default, "Default session cannot be closed."
        self._end_time = time()
        self.__ctx_var.set(self.__default)
        return

    def is_closed(self):
        """Check if the session is closed."""
        return self._end_time is not None

    def check_timeout(self):
        """Check whether the session has timed out and extend the timeout period."""
        if self.is_closed():
            return False
        if self._timeout_sec is None:
            return True
        cur_time = time()
        if self._timeout is None or self._timeout > cur_time:
            self._timeout = cur_time + self._timeout_sec * 1000
            return True
        self._end_time = self._timeout
        return False

    @property
    def user_name(self):
        return self._user_name

    @classmethod
    def get_default(cls):
        return cls.__default or cls(
            DEFAULT_USER_NAME, timeout_sec=None, session_name="default"
        )

    @classmethod
    def get_current(cls):
        return cls.__ctx_var.get() or cls.get_default()

    def __str__(self):
        return f"Session<{self._session_name}>"
