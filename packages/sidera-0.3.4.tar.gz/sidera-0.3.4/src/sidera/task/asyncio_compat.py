import asyncio
import sys
from collections.abc import Coroutine
from types import TracebackType


if sys.version_info >= (3, 11):
    from asyncio import TaskGroup
else:

    class TaskGroup:
        """Small asyncio.TaskGroup compatibility layer for Python 3.10."""

        def __init__(self) -> None:
            self._tasks: list[asyncio.Task[object]] = []

        async def __aenter__(self) -> "TaskGroup":
            """Enter the task group context."""
            return self

        async def __aexit__(
            self,
            exc_type: type[BaseException] | None,
            exc: BaseException | None,
            traceback: TracebackType | None,
        ) -> bool:
            """Wait for tasks and propagate the first task exception."""
            if exc_type is not None:
                self._cancel_tasks()
            results = await asyncio.gather(*self._tasks, return_exceptions=True)
            if exc is not None:
                return False
            for result in results:
                if isinstance(result, BaseException):
                    raise result
            return False

        def create_task(
            self, coro: Coroutine[object, object, object], name: str
        ) -> asyncio.Task[object]:
            """Create and register a task in the group."""
            task = asyncio.create_task(coro, name=name)
            self._tasks.append(task)
            return task

        def _cancel_tasks(self) -> None:
            """Cancel all unfinished tasks."""
            for task in self._tasks:
                if not task.done():
                    task.cancel()
