from asyncio import Task
from collections.abc import Coroutine
from logging import getLogger

from .asyncio_compat import TaskGroup


log = getLogger(__name__)


class WorkerTask:
    """Task launcher class."""

    def __init__(self, coro: Coroutine, name: str):
        self._name = name
        self._coro = coro
        self._task: Task | None = None

    async def _start(self):
        """Entry point of the task."""
        log.debug("%s starts.", str(self))
        try:
            await self._coro
        finally:
            log.debug("%s finishes.", str(self))

    def run(self, group: TaskGroup):
        """Run the launcher."""
        assert self._task is None, f"{self} is already running."
        self._task = group.create_task(self._start(), name=self._name)

    def cancel(self):
        """Cancel the task."""
        if self._task is None:
            log.warning("%s is not running.", str(self))
            return
        if self._task.cancelled():
            log.debug("%s is already cancelled.", str(self))
            return
        if self._task.done():
            log.debug("%s is already done.", str(self))
            return
        log.debug("Cancel %s.", str(self))
        self._task.cancel()

    @property
    def name(self):
        return self._name

    def is_running(self):
        """Check if the task is running."""
        if self._task is None:
            return False
        return not self._task.done()

    def __str__(self):
        return f"Task<{self._name}>"

    def __repr__(self):
        return f"Task<{self._name}:{repr(self._coro)}>"
