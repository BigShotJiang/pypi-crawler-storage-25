from logging import getLogger
from typing import Any, TypeVar, cast

from typing_extensions import Self

from .session import Session

log = getLogger(__name__)
T = TypeVar("T")


class Context:
    """Application context class"""

    _pool: dict[str, Self] = {}
    _Unset = object()

    def __init__(
        self,
        user_name: str,
        items: dict[str, Any] = {},
    ):
        assert user_name not in self._pool.keys(), (
            f"{user_name} context is already exists."
        )

        self._user_name = user_name
        self._items: dict[str, Any] = items.copy()

        self._pool[self._user_name] = cast(Self, self)
        log.debug(f"{self} is created.")

    @classmethod
    def current_name(cls):
        """Get current context name."""
        return Session.get_current().user_name

    @classmethod
    def get_context(cls, user_name: str | None = None):
        """Get context.
        Args:
            session: Session object. None is for current session.
        """
        user_name = user_name or Session.get_current().user_name
        ctx = cls._pool.get(user_name) or cls(user_name)
        return ctx

    def remove_context(self):
        """Remove context from pool."""
        assert self._user_name in self._pool.keys(), f"{self._user_name} is not exists."
        self._pool.pop(self._user_name)
        log.debug(f"{self} is removed.")

    @classmethod
    def get_item(
        cls,
        key: str,
        default: Any = None,
        user_name: str | None = None,
    ):
        """Get item from current context with item name."""
        self = cls.get_context(user_name)
        return self._items.get(key, default)

    @classmethod
    def get_by_type(
        cls,
        cls_type: type[T],
        *args,
        default: T | None = None,
        user_name: str | None = None,
        **kwargs: Any,
    ) -> T:
        """Get class type item from current context."""
        key = cls_type.__name__
        item = cls.get_item(key, user_name=user_name)
        if item is not None:
            return item
        current = cls_type(*args, **kwargs) if default is None else default
        cls.set_by_type(current)
        return current

    @classmethod
    def set_item(cls, key: str | type, value: Any, user_name: str | None = None):
        """Set item as current context."""
        self = cls.get_context(user_name)
        key = key if isinstance(key, str) else key.__name__
        self._items[key] = value

    @classmethod
    def set_by_type(
        cls,
        value: object,
        user_name: str | None = None,
    ):
        """Set class type item as current context."""
        cls_type = type(value)
        key = cls_type.__name__
        cls.set_item(key, value, user_name)

    @property
    def user_name(self):
        return self._user_name

    def __str__(self):
        return f"Context<{self._user_name}>"
