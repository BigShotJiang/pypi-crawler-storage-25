import sys
from importlib.metadata import distribution
from logging import getLogger

from sidera.config import Arguments
from sidera.plugin import PluginHooks
from sidera.rpc import run_rpc_stdio
from sidera.scenario import NodePath
from sidera.task import Session, WorkerGroup
from sidera.scenario.models import Scenario

log = getLogger(__name__)


def init_application(args: list[str] | None = None):
    """Initialize the application."""
    if args is not None:
        sys.argv = [sys.argv[0], *args]
    plugin_hooks = PluginHooks()
    plugin_hooks.initialize()
    Session.get_default().open()

    async def _sample_loop():
        if Arguments.args.sample:
            NodePath.load_scenario(Arguments.args.sample.path)
            log.debug(NodePath().get_data(Scenario).dump_json())
        if Arguments.args.scenario:
            NodePath.load_scenario(Arguments.args.scenario)
            log.debug(NodePath().get_data(Scenario).dump_json())
            pass

    WorkerGroup.append_worker(_sample_loop(), "sample_loop")


def main(args: list[str] | None = None):
    """Main entry point for the Sidera application."""
    init_application(args)
    log.info("===== starting Sidera v%s =====", distribution("sidera").version)
    if Arguments.args.stdio:
        run_rpc_stdio()
    else:
        WorkerGroup.start()


if __name__ == "__main__":
    main()
