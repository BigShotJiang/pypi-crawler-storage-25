from pathlib import PurePath
from uuid import UUID

from pydantic import BaseModel

from .jsonrpc import JsonValue


def to_json_value(value: object) -> JsonValue:
    """Convert a Python value returned by the API to a JSON-compatible value."""
    match value:
        case None | str() | int() | float() | bool():
            return value
        case UUID() | PurePath():
            return str(value)
        case BaseModel():
            return _convert_model(value)
        case tuple() | list():
            return [to_json_value(item) for item in value]
        case dict():
            return {str(key): to_json_value(item) for key, item in value.items()}
        case _:
            return str(value)


def _convert_model(value: BaseModel) -> JsonValue:
    """Convert a Pydantic model to a JSON-compatible value."""
    dumped = value.model_dump(mode="json", by_alias=True, exclude_none=True)
    return to_json_value(dumped)
