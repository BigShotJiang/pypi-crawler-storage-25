RPC_METHODS: dict[str, str] = {
    "sidera.loadScenarioFromFile": "load_scenario_from_file",
    "sidera.loadScenarioFromJson": "load_scenario_from_json",
    "sidera.getScenarioIds": "get_scenario_ids",
    "sidera.clearScenarios": "clear_scenarios",
    "sidera.selectCurrentScenario": "select_current_scenario",
    "sidera.getCurrentScenario": "get_current_scenario",
    "sidera.getScenarioInfo": "get_scenario_info",
    "sidera.dumpJson": "dump_json",
    "sidera.loadJson": "load_json",
    "sidera.getData": "get_data",
    "sidera.getPatch": "get_patch",
    "sidera.getNodeInfo": "get_node_info",
    "sidera.patch": "patch",
    "sidera.syncData": "sync_data",
    "sidera.append": "append",
    "sidera.clear": "clear",
    "sidera.remove": "remove",
}

RPC_EVENT_METHODS = frozenset(
    {
        "sidera.subscribe",
        "sidera.unsubscribe",
    }
)
