from typing import BinaryIO

from .jsonrpc import JsonRpcEnvelopeError, JsonRpcErrorCode

HEADER_ENCODING = "ascii"
CONTENT_LENGTH = "content-length"


def read_message(stream: BinaryIO) -> str | None:
    """Read one Content-Length framed message from a binary stream."""
    headers = _read_headers(stream)
    if headers is None:
        return None
    length = _get_content_length(headers)
    body = stream.read(length)
    if len(body) != length:
        raise JsonRpcEnvelopeError(
            JsonRpcErrorCode.PARSE_ERROR,
            "Unexpected end of stream while reading message body.",
        )
    return body.decode("utf-8")


def write_message(stream: BinaryIO, payload: str) -> None:
    """Write one Content-Length framed message to a binary stream."""
    body = payload.encode("utf-8")
    header = f"Content-Length: {len(body)}\r\n\r\n".encode(HEADER_ENCODING)
    stream.write(header)
    stream.write(body)
    stream.flush()


def _read_headers(stream: BinaryIO) -> dict[str, str] | None:
    """Read Content-Length headers from the stream."""
    headers: dict[str, str] = {}
    while line := stream.readline():
        line = line.rstrip(b"\r\n")
        if not line:
            return headers
        try:
            name, value = line.decode(HEADER_ENCODING).split(":", 1)
        except ValueError as exc:
            raise JsonRpcEnvelopeError(
                JsonRpcErrorCode.PARSE_ERROR,
                "Invalid message header.",
            ) from exc
        headers[name.lower()] = value.strip()
    return None


def _get_content_length(headers: dict[str, str]) -> int:
    """Get Content-Length from parsed headers."""
    if CONTENT_LENGTH not in headers:
        raise JsonRpcEnvelopeError(
            JsonRpcErrorCode.PARSE_ERROR,
            "Content-Length header is required.",
        )
    try:
        length = int(headers[CONTENT_LENGTH])
    except ValueError as exc:
        raise JsonRpcEnvelopeError(
            JsonRpcErrorCode.PARSE_ERROR,
            "Content-Length header must be an integer.",
        ) from exc
    if length < 0:
        raise JsonRpcEnvelopeError(
            JsonRpcErrorCode.PARSE_ERROR,
            "Content-Length header must not be negative.",
        )
    return length
