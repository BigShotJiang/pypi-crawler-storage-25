from logging import getLogger
from sys import stdin, stdout

from sidera.api import SideraApi

from .jsonrpc import (
    JsonRpcEnvelopeError,
    dump_json_payload,
    make_error_response,
    parse_json_payload,
)
from .router import JsonRpcRouter
from .stdio import read_message, write_message

log = getLogger(__name__)


class JsonRpcServer:
    """JSON-RPC server that handles Sidera API requests."""

    def __init__(self, api: SideraApi | None = None) -> None:
        self._router = JsonRpcRouter(api or SideraApi(raise_exceptions=False))

    def handle_payload(self, payload: str) -> str | None:
        """Handle one JSON-RPC payload and return a response payload."""
        try:
            requests = parse_json_payload(payload)
        except JsonRpcEnvelopeError as exc:
            error_response = make_error_response(exc.request_id, exc.code, str(exc))
            return dump_json_payload(error_response)

        if isinstance(requests, list):
            responses = []
            for request in requests:
                batch_response = self._router.handle_request(request)
                if batch_response is not None:
                    responses.append(batch_response)
            return dump_json_payload(responses) if responses else None

        single_response = self._router.handle_request(requests)
        return (
            dump_json_payload(single_response) if single_response is not None else None
        )

    def take_notification_payloads(self) -> list[str]:
        """Return pending JSON-RPC notification payloads."""
        return [
            dump_json_payload(notification)
            for notification in self._router.pop_notifications()
        ]


def run_rpc_stdio() -> None:
    """Run the JSON-RPC server over standard input/output."""
    server = JsonRpcServer()
    input_stream = stdin.buffer
    output_stream = stdout.buffer
    while True:
        try:
            payload = read_message(input_stream)
        except JsonRpcEnvelopeError as exc:
            response = make_error_response(exc.request_id, exc.code, str(exc))
            write_message(output_stream, dump_json_payload(response))
            continue
        if payload is None:
            break
        try:
            response_payload = server.handle_payload(payload)
        except Exception:
            log.exception("Unhandled JSON-RPC server error.")
            raise
        if response_payload is not None:
            write_message(output_stream, response_payload)
        for notification_payload in server.take_notification_payloads():
            write_message(output_stream, notification_payload)
