from collections import deque
from uuid import uuid4

from sidera.event import BaseEvent, BaseSubscription, EventSubscriber
from sidera.scenario import NodeSubscription, Targets

from .jsonrpc import JsonValue, make_notification
from .serializers import to_json_value

EVENT_NOTIFICATION_METHOD = "sidera.event"


class RpcEventSubscription:
    """JSON-RPC event subscription state."""

    def __init__(self, subscription_id: str, target: Targets, name: str = "") -> None:
        self.subscription_id = subscription_id
        self.subscription = NodeSubscription(target, name)
        self.subscriber = EventSubscriber(
            self._handle_event,
            self.subscription,
            name or subscription_id,
        )
        self.notifications: deque[dict[str, JsonValue]] = deque()
        self.subscriber.activate()

    def close(self) -> None:
        """Deactivate the underlying subscriber."""
        self.subscriber.deactivate()

    def _handle_event(
        self,
        event: BaseEvent,
        subscription: BaseSubscription,
    ) -> None:
        """Queue a JSON-RPC notification for a received event."""
        self.notifications.append(
            make_notification(
                EVENT_NOTIFICATION_METHOD,
                {
                    "subscriptionId": self.subscription_id,
                    "event": to_json_value(event),
                    "subscription": str(subscription),
                },
            )
        )


class RpcEventManager:
    """Manage JSON-RPC event subscriptions and pending notifications."""

    def __init__(self) -> None:
        self._subscriptions: dict[str, RpcEventSubscription] = {}

    def subscribe(self, target: Targets, name: str = "") -> str:
        """Register a JSON-RPC event subscription and return its id."""
        subscription_id = str(uuid4())
        self._subscriptions[subscription_id] = RpcEventSubscription(
            subscription_id,
            target,
            name,
        )
        return subscription_id

    def unsubscribe(self, subscription_id: str) -> None:
        """Remove a JSON-RPC event subscription."""
        subscription = self._subscriptions.pop(subscription_id, None)
        if subscription is None:
            raise ValueError(f"Subscription not found: {subscription_id}")
        subscription.close()

    def pop_notifications(self) -> list[dict[str, JsonValue]]:
        """Return and clear pending event notifications."""
        notifications: list[dict[str, JsonValue]] = []
        for subscription in self._subscriptions.values():
            while subscription.notifications:
                notifications.append(subscription.notifications.popleft())
        return notifications

    def close(self) -> None:
        """Remove all event subscriptions."""
        for subscription in self._subscriptions.values():
            subscription.close()
        self._subscriptions.clear()
