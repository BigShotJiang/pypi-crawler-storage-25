from collections.abc import Callable
from typing import TypeAlias

from sidera.api import Reply, SideraApi
from sidera.scenario import NodePath

from .errors import error_from_exception, error_from_reply
from .events import RpcEventManager
from .jsonrpc import (
    JsonParams,
    JsonRpcErrorCode,
    JsonRpcRequest,
    JsonValue,
    make_error_response,
    make_success_response,
)
from .methods import RPC_EVENT_METHODS, RPC_METHODS
from .serializers import to_json_value

ApiCallable: TypeAlias = Callable[..., Reply[object]]


class JsonRpcRouter:
    """Dispatch JSON-RPC requests to Sidera API methods."""

    def __init__(
        self,
        api: SideraApi | None = None,
        event_manager: RpcEventManager | None = None,
    ) -> None:
        self._api = api or SideraApi(raise_exceptions=False)
        self._event_manager = event_manager or RpcEventManager()

    def handle_request(self, request: JsonRpcRequest) -> dict[str, JsonValue] | None:
        """Handle one JSON-RPC request and return a response."""
        if request.method in RPC_EVENT_METHODS:
            return self._handle_event_request(request)
        if request.method not in RPC_METHODS:
            return self._error(
                request,
                JsonRpcErrorCode.METHOD_NOT_FOUND,
                f"Method not found: {request.method}",
            )

        api_name = RPC_METHODS[request.method]
        api_method = getattr(self._api, api_name)
        try:
            args, kwargs = self._prepare_params(api_name, request.params)
            reply = api_method(*args, **kwargs)
        except Exception as exc:
            code, message = error_from_exception(exc)
            return self._error(request, code, message)

        if reply.is_error():
            code, message = error_from_reply(reply)
            return self._error(request, code, message)
        if request.is_notification:
            return None
        return make_success_response(request.id, to_json_value(reply.get_data()))

    def pop_notifications(self) -> list[dict[str, JsonValue]]:
        """Return and clear pending JSON-RPC event notifications."""
        return self._event_manager.pop_notifications()

    def close(self) -> None:
        """Close resources owned by the router."""
        self._event_manager.close()

    def _handle_event_request(
        self,
        request: JsonRpcRequest,
    ) -> dict[str, JsonValue] | None:
        """Handle JSON-RPC event subscription methods."""
        try:
            match request.method:
                case "sidera.subscribe":
                    result = self._subscribe(request.params)
                case "sidera.unsubscribe":
                    result = self._unsubscribe(request.params)
                case _:
                    raise ValueError(f"Unknown event method: {request.method}")
        except Exception as exc:
            code, message = error_from_exception(exc)
            return self._error(request, code, message)
        if request.is_notification:
            return None
        return make_success_response(request.id, result)

    def _subscribe(self, params: JsonParams | None) -> JsonValue:
        """Subscribe to events from JSON-RPC parameters."""
        args, kwargs = _split_params(params)
        if args:
            target = args[0]
            name = str(args[1]) if len(args) > 1 else ""
        else:
            if "target" not in kwargs:
                raise TypeError("The target parameter is required.")
            target = kwargs["target"]
            name = str(kwargs.get("name", ""))
        subscription_id = self._event_manager.subscribe(_normalize_target(target), name)
        return {"subscriptionId": subscription_id}

    def _unsubscribe(self, params: JsonParams | None) -> bool:
        """Unsubscribe from events using JSON-RPC parameters."""
        args, kwargs = _split_params(params)
        if args:
            subscription_id = str(args[0])
        else:
            if "subscriptionId" not in kwargs:
                raise TypeError("The subscriptionId parameter is required.")
            subscription_id = str(kwargs["subscriptionId"])
        self._event_manager.unsubscribe(subscription_id)
        return True

    def _prepare_params(
        self,
        api_name: str,
        params: JsonParams | None,
    ) -> tuple[list[object], dict[str, object]]:
        """Prepare JSON-RPC params for an API method."""
        args, kwargs = _split_params(params)
        match api_name:
            case "append":
                args, kwargs = self._convert_append_params(args, kwargs)
            case "patch":
                args, kwargs = self._convert_patch_params(args, kwargs)
            case "sync_data":
                args, kwargs = self._convert_sync_data_params(args, kwargs)
        return args, kwargs

    def _convert_append_params(
        self,
        args: list[object],
        kwargs: dict[str, object],
    ) -> tuple[list[object], dict[str, object]]:
        """Convert append data to the child item model for the target node."""
        node, data = _get_node_and_data(args, kwargs, "data")
        model = NodePath(str(node)).get_child_model()
        converted: object = model.model_validate(data)
        return _set_node_and_data(args, kwargs, node, converted, "data")

    def _convert_patch_params(
        self,
        args: list[object],
        kwargs: dict[str, object],
    ) -> tuple[list[object], dict[str, object]]:
        """Convert patch data to the patch model for the target node."""
        node, data = _get_node_and_data(args, kwargs, "data")
        model = NodePath(str(node)).get_patch_model()
        converted: object = model.model_validate(data)
        return _set_node_and_data(args, kwargs, node, converted, "data")

    def _convert_sync_data_params(
        self,
        args: list[object],
        kwargs: dict[str, object],
    ) -> tuple[list[object], dict[str, object]]:
        """Convert sync data to the node model for the target node."""
        node, data = _get_node_and_data(args, kwargs, "value")
        converted: object = NodePath(str(node))._get_node().convert_to_model(data)
        return _set_node_and_data(args, kwargs, node, converted, "value")

    def _error(
        self,
        request: JsonRpcRequest,
        code: int,
        message: str,
    ) -> dict[str, JsonValue] | None:
        """Create an error response unless the request is a notification."""
        if request.is_notification:
            return None
        return make_error_response(request.id, code, message)


def _split_params(params: JsonParams | None) -> tuple[list[object], dict[str, object]]:
    """Split JSON-RPC params into positional and keyword arguments."""
    match params:
        case None:
            return [], {}
        case list():
            return list(params), {}
        case dict():
            return [], dict(params)
        case _:
            raise TypeError("Invalid JSON-RPC params.")


def _get_node_and_data(
    args: list[object],
    kwargs: dict[str, object],
    data_name: str,
) -> tuple[object, object]:
    """Get node and data parameters from positional or keyword params."""
    if args:
        if len(args) < 2:
            raise TypeError("The node and data parameters are required.")
        return args[0], args[1]
    if "node" not in kwargs or data_name not in kwargs:
        raise TypeError(f"The node and {data_name} parameters are required.")
    return kwargs["node"], kwargs[data_name]


def _set_node_and_data(
    args: list[object],
    kwargs: dict[str, object],
    node: object,
    data: object,
    data_name: str,
) -> tuple[list[object], dict[str, object]]:
    """Set converted node and data parameters back to argument containers."""
    if args:
        args[0] = node
        args[1] = data
    else:
        kwargs["node"] = node
        kwargs[data_name] = data
    return args, kwargs


def _normalize_target(target: object) -> str | list[str]:
    """Normalize JSON-RPC target params to NodeSubscription targets."""
    match target:
        case str():
            return target
        case list() if all(isinstance(item, str) for item in target):
            return target
        case _:
            raise TypeError(f"Invalid event target: {target}")
