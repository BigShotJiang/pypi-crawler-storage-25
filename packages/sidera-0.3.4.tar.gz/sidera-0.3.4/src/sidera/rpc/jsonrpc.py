from dataclasses import dataclass
from json import JSONDecodeError, dumps, loads
from typing import TYPE_CHECKING, Literal, TypeAlias

from pydantic import BaseModel, ConfigDict, Field, ValidationError
from typing_extensions import TypeAliasType

JsonPrimitive: TypeAlias = str | int | float | bool | None
if TYPE_CHECKING:
    JsonValue: TypeAlias = JsonPrimitive | list["JsonValue"] | dict[str, "JsonValue"]
else:
    JsonValue = TypeAliasType(
        "JsonValue", JsonPrimitive | list["JsonValue"] | dict[str, "JsonValue"]
    )
JsonParams: TypeAlias = list[JsonValue] | dict[str, JsonValue]
JsonRpcId: TypeAlias = str | int | None

JSONRPC_VERSION = "2.0"


@dataclass(frozen=True)
class JsonRpcErrorCode:
    """JSON-RPC 2.0 error code constants."""

    PARSE_ERROR: int = -32700
    INVALID_REQUEST: int = -32600
    METHOD_NOT_FOUND: int = -32601
    INVALID_PARAMS: int = -32602
    INTERNAL_ERROR: int = -32000


class JsonRpcRequestModel(BaseModel):
    """Validated JSON-RPC request envelope."""

    model_config = ConfigDict(extra="forbid")

    jsonrpc: Literal["2.0"]
    method: str
    params: JsonParams | None = None
    id: JsonRpcId = Field(default=None)


@dataclass(frozen=True)
class JsonRpcRequest:
    """JSON-RPC request with notification metadata."""

    method: str
    params: JsonParams | None = None
    id: JsonRpcId = None
    is_notification: bool = False


class JsonRpcEnvelopeError(ValueError):
    """JSON-RPC envelope validation error."""

    def __init__(self, code: int, message: str, request_id: JsonRpcId = None) -> None:
        self.code = code
        self.request_id = request_id
        super().__init__(message)


def parse_json_payload(payload: str) -> JsonRpcRequest | list[JsonRpcRequest]:
    """Parse a JSON-RPC payload into request objects."""
    try:
        data = loads(payload)
    except JSONDecodeError as exc:
        raise JsonRpcEnvelopeError(JsonRpcErrorCode.PARSE_ERROR, str(exc)) from exc

    if isinstance(data, list):
        if not data:
            raise JsonRpcEnvelopeError(
                JsonRpcErrorCode.INVALID_REQUEST,
                "Batch request must contain at least one request.",
            )
        return [_parse_request(item) for item in data]
    return _parse_request(data)


def _parse_request(data: object) -> JsonRpcRequest:
    """Parse a single JSON-RPC request object."""
    request_id = data.get("id") if isinstance(data, dict) else None
    if not isinstance(data, dict):
        raise JsonRpcEnvelopeError(
            JsonRpcErrorCode.INVALID_REQUEST,
            "Request must be a JSON object.",
            request_id,
        )
    is_notification = "id" not in data
    try:
        model = JsonRpcRequestModel.model_validate(data)
    except ValidationError as exc:
        raise JsonRpcEnvelopeError(
            JsonRpcErrorCode.INVALID_REQUEST,
            "Invalid JSON-RPC request.",
            request_id,
        ) from exc
    return JsonRpcRequest(
        method=model.method,
        params=model.params,
        id=model.id,
        is_notification=is_notification,
    )


def make_success_response(
    request_id: JsonRpcId, result: JsonValue
) -> dict[str, JsonValue]:
    """Create a JSON-RPC success response dictionary."""
    return {"jsonrpc": JSONRPC_VERSION, "id": request_id, "result": result}


def make_error_response(
    request_id: JsonRpcId,
    code: int,
    message: str,
) -> dict[str, JsonValue]:
    """Create a JSON-RPC error response dictionary."""
    return {
        "jsonrpc": JSONRPC_VERSION,
        "id": request_id,
        "error": {"code": code, "message": message},
    }


def make_notification(
    method: str, params: JsonParams | None = None
) -> dict[str, JsonValue]:
    """Create a JSON-RPC notification dictionary."""
    notification: dict[str, JsonValue] = {
        "jsonrpc": JSONRPC_VERSION,
        "method": method,
    }
    if params is not None:
        notification["params"] = params
    return notification


def dump_json_payload(data: dict[str, JsonValue] | list[dict[str, JsonValue]]) -> str:
    """Serialize a JSON-RPC response payload deterministically."""
    return dumps(data, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
