from pydantic import ValidationError

from sidera.api import Reply

from .jsonrpc import JsonRpcErrorCode


def error_from_reply(reply: Reply[object]) -> tuple[int, str]:
    """Convert an API error reply to a JSON-RPC error."""
    exception = reply.get_exception()
    if isinstance(exception, TypeError | ValueError | ValidationError):
        return JsonRpcErrorCode.INVALID_PARAMS, str(exception)
    return JsonRpcErrorCode.INTERNAL_ERROR, str(exception)


def error_from_exception(exception: Exception) -> tuple[int, str]:
    """Convert an exception to a JSON-RPC error."""
    if isinstance(exception, TypeError | ValueError | ValidationError):
        return JsonRpcErrorCode.INVALID_PARAMS, str(exception)
    return JsonRpcErrorCode.INTERNAL_ERROR, str(exception)
