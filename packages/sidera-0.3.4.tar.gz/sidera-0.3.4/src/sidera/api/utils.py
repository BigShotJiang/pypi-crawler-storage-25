def str_args(*args, max_len: int = 100, **kwargs):
    """Convert the arguments to a string."""
    params = ""
    for arg in args:
        if len(params) > 1:
            params += ", "
        if len(params) > max_len:
            break
        params += repr(arg)
    for key, val in kwargs.items():
        if len(params) > 1:
            params += ", "
        if len(params) > max_len:
            break
        params += f"{key}={repr(val)}"
    if len(params) > max_len:
        params = params[: max(0, max_len - 3)] + "..."
    return params
