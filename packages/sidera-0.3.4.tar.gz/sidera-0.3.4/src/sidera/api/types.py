from pathlib import PurePath
from typing import Annotated, Callable, Coroutine, Generic, Literal, TypeVar

from pydantic import BaseModel, Field

from sidera.event import BaseEvent
from sidera.scenario.nodes import NodeId, NodeType, ScenarioId

TNodeId = TypeVar("TNodeId", bound=NodeId)
TNodeType = TypeVar("TNodeType", bound=NodeType)

ScenarioReference = Annotated[
    NodeId | str | PurePath,
    Field(
        title="Scenario Identifier",
        description="""This is a scenario id or node path as str or PurePath instance.
        Accepts path containing scenario name that do not duplicate.""",
        examples=[
            "~6aed83bc-d18d-48af-9263-0415c187500f",
            "/scenarios/~6aed83bc-d18d-48af-9263-0415c187500f",
            "/scenarios/sample_scenario",
        ],
    ),
]


NodeReference = Annotated[
    NodeId | str | PurePath,
    Field(
        title="Node Identifier",
        description="""This is a node id or node path as str or PurePath instance.
        Accepts a path containing an index number or a unique item name.""",
        examples=[
            "~6aed83bc-d18d-48af-9263-0415c187500f",
            "/scenarios/~6aed83bc-d18d-48af-9263-0415c187500f/signals/0",
            "/scenarios/test scenario/signals/Power",
        ],
    ),
]

EventHandler = Annotated[
    Callable[[BaseEvent], Coroutine | None],
    Field(
        title="Event Handler",
        description="Event handler function to be called when the event is triggered.",
        examples=[
            "def on_event(event: BaseEvent): ...",
            "async def on_event(event: BaseEvent): ...",
        ],
    ),
]


class NodeInfo(BaseModel, Generic[TNodeId, TNodeType]):
    """Node information."""

    id: TNodeId = Field(
        ...,
        title="Node ID",
        description="Unique identifier of the node.",
        examples=[
            "~6aed83bc-d18d-48af-9263-0415c187500f",
            "~6aed83bc-d18d-48af-9263-0415c187500f/scenarios",
            "~6aed83bc-d18d-48af-9263-0415c187500f/name",
        ],
    )
    index: int | None = Field(
        default=None,
        title="Node Index",
        description="Index of the node in the group list.",
    )
    type: TNodeType = Field(
        ...,
        title="Node Type",
        description="""Type of the node.
        top: top scenario group ('/scenarios')
        scenario: scenario node
        group: group of items
        item: single item
        field: field of item
        """,
    )
    path: str = Field(
        ...,
        title="Node Path",
        description="Path of the node.",
        examples=[
            "/scenarios/~6aed83bc-d18d-48af-9263-0415c187500f/signals/~adbf4745-3400-48f8-ad6b-31f9e6206bf6",
        ],
    )
    named_path: str = Field(
        ...,
        title="Named Path",
        description="Path of the node with name.",
        examples=[
            "/scenarios/sample_scenario/signals/Power",
        ],
    )
    field_names: tuple[str, ...] = Field(
        ...,
        title="Node Fields",
        description="List of field names of the node.",
        examples=["""["id", "name", "description"]"""],
    )
    group_names: tuple[str, ...] = Field(
        ...,
        title="Node Child Groups",
        description="List of child group names of the node.",
        examples=["""["signals", "states",]"""],
    )
    source: str | None = Field(
        default=None,
        title="Node Child Groups",
        description="List of child group names of the node.",
        examples=["""["signals", "states",]"""],
    )


class ScenarioInfo(NodeInfo[ScenarioId, Literal["scenario"]]):
    """Scenario information."""

    id: ScenarioId = Field(
        ...,
        title="Scenario ID",
        description="Unique identifier of the scenario.",
        examples=[
            "~6aed83bc-d18d-48af-9263-0415c187500f",
            "~6aed83bc-d18d-48af-9263-0415c187500f/scenarios",
            "~6aed83bc-d18d-48af-9263-0415c187500f/name",
        ],
    )
    type: Literal["scenario"] = "scenario"
