from traceback import TracebackException
from itertools import chain
from typing import Generic, TypeVar

from .utils import str_args

T = TypeVar("T")


class Reply(Generic[T]):
    """API reply base class."""

    def __init__(
        self,
        contents: T,
        api: str = "(unknown api)",
        args: tuple = (),
        kwargs: dict = {},
    ):
        self._contents = contents
        self._exception = contents if isinstance(contents, Exception) else None
        self._api = api
        self._args = args
        self._kwargs = kwargs

    def is_error(self, exc: type[Exception] | None = None) -> bool:
        """Check if the result is an error."""
        if bool(self):
            return False
        return True if exc is None else isinstance(self._exception, exc)

    def raise_exception(self):
        """Raise the exception if the result is an error."""
        if isinstance(self._exception, Exception):
            raise self._exception

    def get_data(self) -> T:
        """Return the contents data."""
        self.raise_exception()
        return self._contents

    def get_typed_data(self, model: type[T]) -> T:
        """Return the contents data."""
        data = self.get_data()
        if isinstance(data, model):
            return data
        raise TypeError(f"Expected {model}, but got {type(data)}: {self}")

    def get_exception(self):
        """Return the exception if the result is an error."""
        if self._exception is None:
            raise AttributeError(
                "No exception in the reply. Do not call get_exception() unless an exception occurs."
            )
        return self._exception

    @property
    def api(self) -> str:
        """Return the API name."""
        return self._api

    @property
    def call_repr(self) -> str:
        """Return the API arguments."""
        args = (str_args(arg) for arg in self._args)
        kwargs = (f"{k}={str_args(v)}" for k, v in self._kwargs.items())
        return f"{self._api}({', '.join(chain(args, kwargs))})"

    def __bool__(self):
        return self._exception is None

    def __str__(self):
        if isinstance(self._exception, Exception):
            tb = TracebackException.from_exception(self._exception)
            last_stack = list(tb.stack)[-1]
            filename = last_stack.filename
            lineno = last_stack.lineno
            ex_name = type(self._exception).__name__
            return (
                f"{ex_name}[{self.call_repr}]< {filename}:{lineno} - {self._exception}>"
            )
        else:
            return f"Reply[{self.call_repr}]<{str_args(self._contents, max_len=80)}>"

    def __repr__(self) -> str:
        return self.__str__()
