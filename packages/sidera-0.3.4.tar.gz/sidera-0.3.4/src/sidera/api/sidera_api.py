from .mixin.event_api import SideraEventApi
from .mixin.login_api import SideraLoginApi
from .mixin.node_api import SideraNodeApi
from .mixin.scenario_api import SideraScenarioApi
from .mixin.player_api import SideraPlayerApi


class SideraApi(
    SideraLoginApi, SideraScenarioApi, SideraNodeApi, SideraEventApi, SideraPlayerApi
):
    """Sidera API composite class using Mixin."""

    pass
