from functools import wraps
from logging import DEBUG, getLogger
from typing import (
    Callable,
    ParamSpec,
    TypeVar,
    cast,
)

from sidera.config import ConfigManager
from sidera.event import EventDispatchWorker
from sidera.task import Session

from ..types import EventHandler
from ..reply import Reply

log = getLogger(__name__)


P = ParamSpec("P")
R = TypeVar("R")


class BaseSideraApi:
    """Sidera API Mixin base class."""

    def __init__(self, raise_exceptions: bool = True) -> None:
        self._session = Session.get_default()
        self._event_workers: dict[EventHandler, EventDispatchWorker] = {}
        self.raise_exceptions = raise_exceptions

    @property
    def session(self):
        return self._session

    @property
    def config(self):
        return ConfigManager

    def check_session(self):
        """Check the session."""
        assert self._session.check_timeout(), "Session is timed out."


def api(
    func: Callable[P, R],
) -> Callable[P, Reply[R]]:
    """API decorator."""

    @wraps(func)
    def wrapper(*args: P.args, **kwargs: P.kwargs) -> Reply[R]:
        call_args = cast(dict[str, object], kwargs)
        call_repr = ", ".join(
            [*(repr(arg) for arg in args)]
            + [f"{key}={value!r}" for key, value in call_args.items()]
        )
        log.debug(
            "API called: %s(%s)",
            func.__name__,
            call_repr if log.isEnabledFor(DEBUG) else "",
        )
        api_obj: BaseSideraApi | None = None
        try:
            if len(args) > 0:
                api_obj = cast(BaseSideraApi, args[0])
                api_obj.check_session()
            results = func(*args, **kwargs)
        except Exception as e:
            reply = cast(
                Reply[R],
                Reply(e, api=func.__name__, args=args[1:], kwargs=call_args),
            )
            log.warning("API caught exception: %s", reply)
            if api_obj is not None and api_obj.raise_exceptions:
                # raise the exception with api information
                reply.raise_exception()
            # if the exception is not raised, return the reply with the exception
            return reply

        reply = Reply(
            contents=results, api=func.__name__, args=args[1:], kwargs=call_args
        )
        log.debug(
            "API returns: %s",
            reply if log.isEnabledFor(DEBUG) else func.__name__,
        )
        return reply

    return wrapper
