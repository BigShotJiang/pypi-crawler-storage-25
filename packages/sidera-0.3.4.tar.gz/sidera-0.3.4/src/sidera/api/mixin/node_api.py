from typing import Any

from sidera.api.types import NodeInfo, NodeReference
from sidera.exceptions import InvalidNodeOperation
from sidera.scenario import (
    FieldModel,
    GroupName,
    ItemModel,
    NodeId,
    NodeModelType,
    NodePath,
    PatchModel,
)

from .base_api import BaseSideraApi, api


class SideraNodeApi(BaseSideraApi):
    """Sidera node operation API class for Mixin."""

    @api
    def dump_json(self, node: NodeReference, indent: int | None = None) -> str:
        """Dump json subtree data of the node."""
        node_path = NodePath(node)
        return node_path.dump_json(indent=indent)

    @api
    def load_json(self, node: NodeReference, json: str):
        """Load json data to the node and its descendant nodes in the scenario.
        This API adds and deletes nodes, and all nodes that do not contain an ID are treated as additions.
        """
        node_path = NodePath(node)
        node_path.sync_json(json)

    @api
    def get_data(self, node: NodeReference) -> NodeModelType:
        """Get the node data with descendants in bulk."""
        node_path = NodePath(node)
        data = node_path.get_data()
        return data

    @api
    def get_index(self, node: NodeReference) -> int | None:
        """Get node index in group list."""
        node_path = NodePath(node)
        index = node_path.index
        if index is None:
            raise InvalidNodeOperation(f"Node does not have index: {node_path}")
        return index

    @api
    def get_source(self, node: NodeReference) -> str:
        """Get the source string of the node."""
        node_path = NodePath(node)
        source = node_path.get_source()
        return source or ""

    @api
    def get_patch(self, node: NodeReference, **kwargs) -> PatchModel:
        """Get fields of the node info without children in scenario."""
        node_path = NodePath(node)
        patch = node_path.get_patch(**kwargs)
        return patch

    @api
    def get_child_ids(self, node: NodeReference) -> tuple[NodeId, ...]:
        """Get child item id list of the group node in scenario."""
        node_path = NodePath(node)
        return tuple(node_path.iter_child_ids())

    @api
    def get_group_counts(self, node: NodeReference) -> dict[GroupName, int]:
        """Get dict of node groups with child counts in specified node or group."""
        node_path = NodePath(node)
        return node_path.get_group_counts()

    @api
    def get_node_info(self, node: NodeReference) -> NodeInfo:
        """Get node information."""
        node_path = NodePath(node)
        info = NodeInfo(
            id=node_path.id,
            index=node_path.index,
            type=node_path.node_type,
            path=str(node_path.resolve()),
            named_path=str(node_path.named),
            field_names=node_path.field_names,
            group_names=node_path.group_names,
            source=node_path.get_source(),
        )
        return info

    @api
    def patch(self, node: NodeReference, data: PatchModel):
        """Patch a specific node in the scenario with partial data from model input.
        This API does not allow adding or deleting nodes.
        The update will fail if any descendant node without an ID are provide.
        """
        node_path = NodePath(node)
        node_path.patch(data)

    @api
    def sync_data(self, node: NodeReference, value: NodeModelType):
        """Patch a specific node in the scenario with partial data from model input.
        This API does not allow adding or deleting nodes.
        The update will fail if any descendant node without an ID are provide.
        """
        node_path = NodePath(node)
        changed_path = node_path.sync_data(value)
        return str(changed_path) if changed_path else None

    @api
    def set_field_value(self, node: NodeReference, value: FieldModel | Any):
        """Set value to the specific field node in the scenario."""
        node_path = NodePath(node)
        node_path.set_field_value(value)

    @api
    def append(self, node: NodeReference, data: ItemModel):
        """Add the data as a new child node of the group node."""
        parent = NodePath(node)
        node_path = parent.append(data)
        return str(node_path)

    @api
    def clear(self, node: NodeReference):
        """Delete all data in the node."""
        node_path = NodePath(node)
        node_path.clear()

    @api
    def remove(self, node: NodeReference):
        """Remove the node from the scenario."""
        node_path = NodePath(node)
        node_path.remove()
