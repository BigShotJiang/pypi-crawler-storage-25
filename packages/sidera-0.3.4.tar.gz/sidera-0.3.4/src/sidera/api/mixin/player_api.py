from pathlib import PurePath

from sidera.player import Player, SceneFlow
from sidera.scenario import NodePath

from .base_api import BaseSideraApi, api


class SideraPlayerApi(BaseSideraApi):
    """Sidera player operation API class for Mixin."""

    @api
    def set_story(self, path: str | PurePath) -> None:
        """Set story to play scene flow."""
        path = NodePath(path)
        player = Player.current()
        player.set_story(path)

    @api
    def get_scene_flow(self) -> SceneFlow:
        """Get current scene flow."""
        player = Player.current()
        return player.current_scene_flow
