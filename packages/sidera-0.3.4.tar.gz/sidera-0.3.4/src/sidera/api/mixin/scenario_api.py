from pathlib import Path, PurePath

from sidera.scenario import NodePath, ScenarioId
from sidera.scenario.models import Scenario
from sidera_test_data.sample import SampleScenario

from ..types import ScenarioReference, ScenarioInfo
from .base_api import BaseSideraApi, api


class SideraScenarioApi(BaseSideraApi):
    """Sidera scenario operation API class for Mixin."""

    @api
    def load_scenario_from_file(self, path: str | PurePath):
        """Load scenario data from file.
        Args:
            path: Path to the scenario file.
        Returns:
            The loaded scenario id.
        """
        node_path = NodePath.load_scenario(Path(path))
        return node_path.scenario_id

    @api
    def load_scenario_from_json(self, json: str, source: str = ""):
        """Load scenario data from json data.
        Args:
            json: JSON data of the entire scenario.
            source: Source file path of the scenario data to identify by client.
        Returns:
            The loaded scenario id.
        """
        data = Scenario.model_validate_json(json)
        node_path = NodePath.append_scenario(data, source)
        return node_path.scenario_id

    @api
    def get_scenario_ids(self):
        """Get a list of scenario ids.
        Returns:
            A tuple of scenario ids.
        """
        return NodePath.get_scenario_ids()

    @api
    def clear_scenarios(self):
        """Clear the all loaded scenarios."""
        NodePath.clear_scenarios()

    @api
    def select_current_scenario(self, scenario: ScenarioReference):
        """Select as current scenario data.
        Args:
            scenario: Scenario id or path.
        """
        node_path = NodePath(scenario)
        node_path.select_scenario()

    @api
    def get_current_scenario(self):
        """Get node id of current scenario.
        Returns:
            The scenario id of the current scenario.
            If no scenario is selected, the id is '~00000000-0000-0000-0000-000000000000'
        """
        return NodePath(".").scenario_id

    @api
    def get_scenario_source(self, scenario: ScenarioReference):
        """Get source info by scenario node path.
        Args:
            scenario: Scenario id or path.
        Returns:
            Source info of the scenario node.
        """
        node_path = NodePath(scenario)
        return node_path.get_source() or ""

    @api
    def get_scenario_path_by_source(self, source: str):
        """Get scenario node path by source info.
        Args:
            source: Source info of the scenario node.
        Returns:
            Scenario node id.
        """
        top_group = NodePath("/scenarios")
        scenario_id = next(
            (
                ScenarioId(scenario_id)
                for scenario_id in top_group.iter_child_ids()
                if NodePath(scenario_id).get_source() == source
            ),
            None,
        )
        if scenario_id is None:
            raise ValueError(f"Scenario node with source '{source}' is not found.")
        return scenario_id

    @api
    def get_scenario_info(self, scenario: ScenarioReference) -> ScenarioInfo:
        """Get scenario information."""
        node_path = NodePath(scenario)
        info = ScenarioInfo(
            id=node_path.scenario_id,
            index=node_path.index,
            path=str(node_path.resolve()),
            named_path=str(node_path.named),
            field_names=node_path.field_names,
            group_names=node_path.group_names,
            source=node_path.get_source(),
        )
        return info

    @api
    def sync_scenario(self, json: str, scenario: ScenarioReference = "."):
        """Sync scenario data with json data.
        Args:
            json: scenario data to sync.
            scenario: The scenario id or path of the scenario to sync. Uses the current scenario if omitted.
        Returns:
            True if the scenario is updated, False all data is the same.
        """
        scenario_path = NodePath(scenario)
        if scenario_path is None:
            raise ValueError("Current scenario is not selected.")
        data = Scenario.model_validate_json(json)
        update_path = scenario_path.sync_data(data)
        return bool(update_path)

    @api
    def get_sample_scenario_names(self):
        """Get sample scenario names.
        Returns:
            A list of sample scenario names.
        """
        return SampleScenario.get_list()
