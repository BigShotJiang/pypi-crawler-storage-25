from sidera.task import Context, Session

from .base_api import BaseSideraApi, api


class SideraLoginApi(BaseSideraApi):
    """Sidera login operation API class for Mixin."""

    @api
    def login(self, user_name: str, *args, **kwargs):
        """Login to session with user name."""
        self._session = Session(user_name, *args, **kwargs)
        Context.get_context(user_name)

    @api
    def logout(self):
        """Logout from session."""
        Context.get_context().remove_context()
        self._session.close()
        self._session = Session.get_default()
