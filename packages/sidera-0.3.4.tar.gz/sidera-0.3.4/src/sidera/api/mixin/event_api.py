from inspect import iscoroutinefunction

from sidera.event import (
    AsyncEventSubscriber,
    BaseEvent,
    BaseSubscription,
    EventDispatchWorker,
)
from sidera.scenario import NodeSubscription, Targets

from ..types import EventHandler
from .base_api import BaseSideraApi, api


class SideraEventApi(BaseSideraApi):
    """Sidera event operation API class for Mixin."""

    @api
    def subscribe(self, handler: EventHandler, target: Targets):
        """Subscribe events."""
        worker = self._event_workers.get(handler)
        if worker is not None:
            assert len(worker.subscriptions) == 1, "Only one subscription is supported."
            subscription = next(sub for sub in worker.subscriptions)
            assert isinstance(subscription, NodeSubscription)
            subscription.add(target)
            return

        async def _dispatch(event: BaseEvent, subscription: BaseSubscription):
            assert isinstance(subscription, NodeSubscription)
            if iscoroutinefunction(handler):
                await handler(event)
            else:
                handler(event)

        subscription = NodeSubscription(target)
        worker_name = f"{handler.__module__}:{handler.__name__}"
        worker = EventDispatchWorker(worker_name, _dispatch, subscription)
        self._event_workers[handler] = worker

    @api
    def unsubscribe(self, handler: EventHandler, target: Targets | None = None):
        """Unsubscribe events."""
        subscriber = self._event_workers.get(handler)
        if subscriber is None:
            raise ValueError(f"Handler '{handler}' is not found.")
        assert len(subscriber.subscriptions) == 1, "Only one subscription is supported."
        subscription = next(sub for sub in subscriber.subscriptions)
        assert isinstance(subscription, NodeSubscription)
        if target is not None:
            subscription.remove(target)
        if target is None or len(subscription) == 0:
            subscriber.remove()
            self._event_workers.pop(handler)

    @api
    def get_subscriber(self, target: Targets, name: str = "") -> AsyncEventSubscriber:
        """Get asynchronous subscriber."""
        subscription = NodeSubscription(target)
        subscriber = AsyncEventSubscriber(subscription, name)
        return subscriber
