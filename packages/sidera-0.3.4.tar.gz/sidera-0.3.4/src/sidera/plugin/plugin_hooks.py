from logging import getLogger
from sys import exit, stderr

from pluggy import PluginManager
from pydantic import ValidationError

from sidera.config import ConfigManager, Arguments

from . import hook_specs
from .plugin_registry import PLUGIN_REGISTRY_LIST

log = getLogger(__name__)


class PluginHooks:
    """Plugin hooks provider."""

    @staticmethod
    def __get_plugin_manager():
        """Get plugin manager."""
        pm = PluginManager("sidera")
        pm.add_hookspecs(hook_specs)
        pm.load_setuptools_entrypoints("sidera")
        # resister default plugins
        for plugin in PLUGIN_REGISTRY_LIST:
            pm.register(plugin)
        return pm

    _plugin_mgr = __get_plugin_manager()

    def initialize(self):
        """Initialize the plugins."""
        try:
            self.setup_config()
        except ValidationError as e:
            print(f"error: parsing configurations: {e}", file=stderr)
            exit(1)
        self.init_logger()
        self.init_plugin()
        self.dump_info()

    def setup_config(self):
        """Setup the configuration customized by plugin."""
        self._plugin_mgr.hook.setup_config()
        try:
            ConfigManager.parse_args()
        except Exception as e:
            Arguments.print_usage()
            print(f"error: parsing arguments: {e}", file=stderr)
            exit(1)
        try:
            ConfigManager.load()
        except Exception as e:
            print(f"error: parsing configurations: {e}", file=stderr)
            exit(1)

    def init_logger(self):
        """Setup the logger before the initialization."""
        self._plugin_mgr.hook.setup_logger()

    def init_plugin(self):
        """Initialize the plugins."""
        self._plugin_mgr.hook.initialize()

    def get_plugins(self) -> list[str]:
        """Get the list of plugin names."""
        return [name for name, _ in self._plugin_mgr.list_name_plugin()]

    def dump_info(self):
        """Dump the plugin information."""
        if ConfigManager.files:
            log.info(
                "Loaded config file: %s",
                ", ".join(str(file) for file in ConfigManager.files),
            )
        else:
            log.info("No config file loaded.")
        plugins = [name for name, _ in self._plugin_mgr.list_name_plugin()] or [
            "(none)"
        ]
        log.info("Plug-in[%d]: %s", len(plugins), ", ".join(plugins))
