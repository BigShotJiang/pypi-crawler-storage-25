from .logger import default_loggers

PLUGIN_REGISTRY_LIST = [default_loggers]
