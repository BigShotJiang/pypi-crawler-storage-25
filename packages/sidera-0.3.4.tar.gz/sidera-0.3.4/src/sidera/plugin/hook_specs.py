from pluggy import HookspecMarker

plugin_hook_spec = HookspecMarker("sidera")


@plugin_hook_spec()
def setup_config():
    """Prepare the plugin configuration."""


@plugin_hook_spec()
def setup_logger():
    """Prepare the logger before the initialization."""


@plugin_hook_spec()
async def initialize():
    """Initialize the plugin."""
