from logging import Formatter, StreamHandler, getLogger
from sys import stdout
from typing import TextIO

from pydantic import Field, field_validator

from sidera.config import ConfigModel, ConfigManager
from .common import LogLevel, LOG_LEVELS

CONSOLE_LOG_FORMAT = "%(message)s"


class StreamLoggerConfig(ConfigModel):
    """Logger configuration for stream output."""

    level: LogLevel | None = Field(
        default="INFO",
        description=f"Log level ({', '.join(LOG_LEVELS)})",
    )

    @field_validator("level", mode="before")
    @classmethod
    def _str_to_upper(cls, value: object) -> object:
        return value.upper() if isinstance(value, str) else value


def setup_console_logger(verbose: bool, stream: TextIO = stdout) -> None:
    """Setup console logger."""
    conf = ConfigManager.get_config(StreamLoggerConfig, "logger.console")
    conf_level = "DEBUG" if verbose else conf.level
    if conf_level is None:
        return
    root = getLogger()
    console_handler = StreamHandler(stream=stream)
    console_handler.setLevel(conf_level)
    console_handler.setFormatter(Formatter(CONSOLE_LOG_FORMAT))
    root.addHandler(console_handler)
