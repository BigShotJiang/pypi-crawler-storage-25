from logging import getLogger
from sys import stderr

from sidera.config import Arguments, ConfigModel
from sidera.plugin import plugin_hook_impl

from .console_logger import setup_console_logger
from .file_logger import setup_file_logger
from .event_logger import setup_event_logger

PLUGIN_NAME = __name__

CONSOLE_LOG_FORMAT = "%(message)s"
FILE_LOG_FORMAT = "%(asctime)s [%(levelname)s] %(filename)s %(lineno)s: %(message)s"


@plugin_hook_impl
def setup_config():
    """Prepare the plugin configuration."""
    Arguments.add_argument(
        "--verbose", action="store_true", help="Output verbose log on console."
    )


class LoggerArgsModel(ConfigModel):
    """Logger arguments."""

    verbose: bool = False
    stdio: bool = False


@plugin_hook_impl
def setup_logger():
    """Prepare the logger before the initialization."""
    args = Arguments.get_args(LoggerArgsModel)
    stream = stderr if args.stdio else None
    if stream is None:
        setup_console_logger(args.verbose)
        setup_event_logger(args.verbose)
    else:
        setup_console_logger(args.verbose, stream=stream)
        setup_event_logger(args.verbose, stream=stream)
    setup_file_logger()
    root = getLogger()
    root.setLevel(min(root.level, *(handler.level for handler in root.handlers)))
