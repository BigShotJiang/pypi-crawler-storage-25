from logging import FileHandler, Formatter, StreamHandler, getLogger
from sys import stdout
from typing import TextIO

from pydantic import Field

from sidera.config import ConfigManager, ConfigModel
from sidera.event import BaseEvent, BaseSubscription, EventDispatchWorker
from sidera.scenario import NodeSubscription

event_log = getLogger(__name__)
event_log.propagate = False

PLUGIN_NAME = __name__

EVENT_LOG_FORMAT = "%(message)s"

_event_dispatch_worker = None


async def event_logging(event: BaseEvent, subscription: BaseSubscription) -> None:
    """Log dispatched event details."""
    event_log.info("%s - %s", str(event), str(subscription))


class EventLoggerConfig(ConfigModel):
    """Logger configuration for stream output."""

    console: bool = Field(
        default=False,
        description="Enable logging of events output to the console.",
    )
    file: bool = Field(
        default=False,
        description="Enable logging of events output to the file.",
    )
    monitor_task: bool = Field(
        default=False,
        description="Create monitor task to logging all events.",
        alias="monitor-task",
    )


def setup_event_logger(verbose: bool, stream: TextIO = stdout) -> None:
    """Prepare the logger before the initialization."""
    conf = ConfigManager.get_config(EventLoggerConfig, "logger.event")
    if not verbose and not conf.console and not conf.file:
        return

    if conf.console or verbose:
        event_handler = StreamHandler(stream=stream)
        event_handler.setLevel("DEBUG")
        event_handler.setFormatter(Formatter(EVENT_LOG_FORMAT))
        event_log.addHandler(event_handler)

    if conf.file:
        root = getLogger()
        file_handler = next(
            (hdl for hdl in root.handlers if isinstance(hdl, FileHandler)), None
        )
        if file_handler is not None:
            event_log.addHandler(file_handler)

    if conf.monitor_task:
        global _event_dispatch_worker
        subscription = NodeSubscription("/")
        _event_dispatch_worker = EventDispatchWorker(
            "event_logger", subscriptions={subscription: event_logging}
        )
