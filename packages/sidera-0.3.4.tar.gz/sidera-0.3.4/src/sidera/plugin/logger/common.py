from typing import Literal, get_args

LogLevel = Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL", "NOTSET"]
LOG_LEVELS = get_args(LogLevel)
