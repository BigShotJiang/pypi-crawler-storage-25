from logging import Formatter, getLogger
from logging.handlers import RotatingFileHandler
from pathlib import Path
from pydantic import Field, field_validator

from sidera.config import ConfigModel
from sidera.config.manager import ConfigManager
from .common import LogLevel, LOG_LEVELS

FILE_LOG_FORMAT = "%(asctime)s [%(levelname)s] %(filename)s %(lineno)s: %(message)s"

log = getLogger(__name__)


class FileLoggerConfig(ConfigModel):
    """Logger configuration for file output."""

    level: LogLevel | None = Field(
        default=None,
        description=f"Log level ({', '.join(LOG_LEVELS)})",
    )
    path: Path | None = Field(alias="file", default=None, description="Log file path.")
    max_bytes: int = Field(
        alias="max-bytes",
        default=1_000_000,
        description="Maximum log file size in bytes.",
    )
    backup_count: int = Field(
        alias="backup-count", default=1, description="Number of backup log files."
    )

    @field_validator("level", mode="before")
    @classmethod
    def _str_to_upper(cls, value):
        return value.upper() if isinstance(value, str) else value


def setup_file_logger():
    """Setup file logger."""
    conf = ConfigManager.get_config(FileLoggerConfig, "logger.file")
    if conf.level is None or conf.path is None:
        return
    file_handler = RotatingFileHandler(
        filename=conf.path,
        maxBytes=conf.max_bytes,
        backupCount=conf.backup_count,
        encoding="utf-8",
        errors="ignore",
    )
    file_handler.setLevel(conf.level)
    file_handler.setFormatter(Formatter(FILE_LOG_FORMAT))
    root = getLogger()
    root.addHandler(file_handler)
    log.debug("Log to file [%s]: %s", conf.level, conf.path)
