from pathlib import Path
import sys
from typing import Any, Type, TypeVar, overload

from typing_extensions import Self

if sys.version_info >= (3, 11):
    from tomllib import TOMLDecodeError, loads
else:
    from tomli import TOMLDecodeError, loads

from sidera.task import Context

from .arguments import Arguments, ArgumentsModel
from .models import ConfigModel, CoreConfigModel

T = TypeVar("T", bound=ConfigModel)


class ConfigManager:
    """Configurations manager for application and all plugins."""

    files: list[Path] = []
    _args: ArgumentsModel

    @classmethod
    def current(cls) -> Self:
        """Return current configuration manager."""
        return Context.get_by_type(cls)

    def __init__(self):
        self._name = Context.current_name()
        self._configs: dict[str, Any] = {}

    @classmethod
    def parse_args(cls):
        """Parse arguments"""
        cls._args = Arguments.parse_args()
        config_file = cls._args.config
        if config_file is None:
            return
        cls.files.clear()
        cls.add_file(config_file)

    @classmethod
    def add_file(cls, file: Path | str):
        """Add configuration file to list."""
        file = Path(file)
        if file.exists() and file.is_file():
            cls.files.append(file.expanduser())
            return True
        return False

    @classmethod
    def load(cls):
        """Load configuration from file."""
        self = cls.current()
        self._configs = {}
        for file in cls.files:
            if not file.exists() or not file.is_file():
                continue
            text = file.read_text(encoding="utf-8", errors="ignore")
            try:
                conf_dict = loads(text)
                self._configs.update(conf_dict.get("sidera", {}))
            except TOMLDecodeError as e:
                raise TOMLDecodeError(f"Error decoding {file}: {e}") from e
        return self

    @overload
    @classmethod
    def get_config(cls, model: None = None, group: str = "") -> CoreConfigModel: ...

    @overload
    @classmethod
    def get_config(cls, model: Type[T], group: str = "") -> T: ...

    @classmethod
    def get_config(
        cls, model: Type[T] | None = None, group: str = ""
    ) -> T | CoreConfigModel:
        """Get configuration model of plugin."""
        self = cls.current()
        data = self._configs
        for grp in group.split("."):
            if not grp:
                break
            data = data.get(grp, {})
        if model is None:
            return CoreConfigModel.model_validate(data, strict=False)
        return model.model_validate(data, strict=False)

    def __str__(self):
        return f"{self.__class__.__name__}<{self._name}>"

    def __repr__(self) -> str:
        return str(self)
