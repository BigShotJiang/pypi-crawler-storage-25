from argparse import SUPPRESS, ArgumentParser
from importlib.metadata import distribution
from os import getcwd
from pathlib import Path
from typing import Any, Type, TypeVar

from pydantic import Field, FilePath

from sidera_test_data.sample import SampleScenario

from .models import ConfigModel

DEFAULT_CONFIG_FILE = "sidera.toml"
T = TypeVar("T", bound=ConfigModel)


def get_default_config_file():
    """Return the default configuration file."""
    file = Path(getcwd()) / DEFAULT_CONFIG_FILE
    return file if file.exists() else SUPPRESS


class ArgumentsModel(ConfigModel):
    """Default arguments model."""

    config: FilePath | None = Field(
        default_factory=(
            lambda: (
                Path(DEFAULT_CONFIG_FILE)
                if Path(DEFAULT_CONFIG_FILE).exists()
                else None
            )
        ),
        description=f"Path of the configuration file that replaces the default '{DEFAULT_CONFIG_FILE}'.",
    )
    sample: SampleScenario | None = Field(
        default=None,
        description=f"Sample scenario name selected from '{' | '.join(SampleScenario.get_list())}'.",
    )
    scenario: FilePath | None = Field(
        default=None, description="Path of the scenario file."
    )
    stdio: bool = Field(
        default=False,
        description="Run in RPC mode over standard input/output.",
    )


class Arguments:
    """Arguments manager for application and all plugins."""

    _parser = ArgumentParser(
        description="Sidera is a tool to manage scenario for system states.",
        conflict_handler="resolve",
    )
    _parser.add_argument(
        "--version", action="version", version=distribution("sidera").version
    )
    _parser.add_argument(
        "--config", type=Path, default=SUPPRESS, help="Configuration file to use."
    )
    _parser.add_argument(
        "--stdio",
        action="store_true",
        help="Run in RPC mode over standard input/output.",
    )
    _parser.add_argument(
        "--sample",
        type=str,
        default=SUPPRESS,
        help=f"Sample scenario name to load: '{' | '.join(SampleScenario.get_list())}'.",
    )
    _parser.add_argument(
        nargs="?", type=str, dest="scenario", help="Scenario file to load."
    )

    _unknown_args: list[str] | None = None
    _arg_values: dict[str, Any] = {}
    args: ArgumentsModel

    @classmethod
    def skip_unknown_args(cls):
        """Setup to skip unknown arguments."""
        cls._unknown_args = []

    @classmethod
    def add_argument(cls, *args, **kwargs):
        """Add argument to parser."""
        return cls._parser.add_argument(*args, **kwargs)

    @classmethod
    def add_argument_group(cls, *args, **kwargs):
        """Add an argument group to parser."""
        return cls._parser.add_argument_group(*args, **kwargs)

    @classmethod
    def parse_args(cls):
        """Parse arguments"""
        if cls._unknown_args is None:
            args = cls._parser.parse_args()
        else:
            args, unknown = cls._parser.parse_known_args()
            cls._unknown_args = unknown
        cls._arg_values = vars(args)
        cls.args = ArgumentsModel.model_validate(vars(args))
        return cls.args

    @classmethod
    def print_usage(cls):
        """Print usage of arguments."""
        cls._parser.print_usage()

    @classmethod
    def get_args(cls, model: Type[T]) -> T:
        """Return validated arguments."""
        return model.model_validate(cls._arg_values)
