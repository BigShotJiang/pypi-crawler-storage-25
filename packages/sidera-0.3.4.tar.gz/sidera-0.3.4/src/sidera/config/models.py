from pydantic import BaseModel, ConfigDict


class ConfigModel(BaseModel):
    """Base class for the configuration models."""

    model_config = ConfigDict(validate_assignment=True, extra="ignore")


class CoreConfigModel(ConfigModel):
    """Config class for the application."""

    pass
