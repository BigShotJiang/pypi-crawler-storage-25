from typing import Any, TypeAlias
from pydantic import TypeAdapter, ValidationError

TypeHint: TypeAlias = Any


def is_valid_type(value: object, type_hint: TypeHint) -> bool:
    """Check if the value is valid for the given type hint."""
    adapter = TypeAdapter(type_hint)
    try:
        adapter.validate_python(value)
        return True
    except ValidationError:
        return False


def is_strict_instance(value: object, type_hint: TypeHint) -> bool:
    """Check if the value is a strict instance of the given type hint."""
    adapter = TypeAdapter(type_hint)
    try:
        adapter.validate_python(value, strict=True)
        return True
    except ValidationError:
        return False
