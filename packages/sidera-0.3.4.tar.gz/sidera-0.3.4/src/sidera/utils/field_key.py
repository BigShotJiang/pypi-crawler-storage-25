from typing import Any

from pydantic.alias_generators import to_snake


def to_underscore_keys(values: dict[str, Any]):
    """Replace character of field name from "-" to "_"."""
    return {k.replace("-", "_"): v for k, v in values.items()}


def to_snake_case_keys(values: dict[str, Any]):
    """Convert keys of dict to snake_case."""
    return {to_snake(k): v for k, v in values.items()}


def normalize_field_keys(values: dict[str, Any]):
    """Normalize keys for Python field name."""
    return {normalize_field_name(k): v for k, v in values.items()}


def normalize_field_name(name: str):
    """Normalize str for Python field name."""
    return to_snake(name.replace("-", "_"))


def merge_args(args1: dict[str, Any], args2: dict[str, Any]):
    """Merge two args and check duplicate keys."""
    if common_keys := args1.keys() & args2.keys():
        raise ValueError(f"There are duplicate keys in arguments: {common_keys}")
    return {**args1, **args2}
