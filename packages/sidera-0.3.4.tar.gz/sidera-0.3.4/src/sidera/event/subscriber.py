from logging import getLogger
from typing import Callable, Iterable, TypeAlias

from .base_event import BaseEvent
from .base_subscription import BaseSubscription

log = getLogger(__name__)

EventNotify: TypeAlias = tuple[BaseEvent, BaseSubscription]
EventHandler: TypeAlias = Callable[[BaseEvent, BaseSubscription], None]


class EventSubscriber:
    """Event Subscriber."""

    def __init__(
        self,
        call_back: EventHandler,
        subscriptions: Iterable[BaseSubscription] | BaseSubscription = [],
        name: str = "",
    ):
        from .dispatcher import EventDispatcher

        self._call_back = call_back
        self._subscriptions: list[BaseSubscription] = []
        self._name = name or "<unnamed>"
        self._dispatcher = EventDispatcher.current()
        self.append(subscriptions)

    def append(self, subscriptions: Iterable[BaseSubscription] | BaseSubscription):
        """Append subscription."""
        for sub in (
            list(subscriptions)
            if isinstance(subscriptions, Iterable)
            else [subscriptions]
        ):
            if sub in self._subscriptions:
                continue
            log.info(f"{self} is appended a subscription: {repr(sub)}")
            self._subscriptions.append(sub)

    def remove(self, subscription: BaseSubscription):
        """Remove subscription."""
        log.info(f"{self} is removed a subscription: {subscription}")
        self._subscriptions.remove(subscription)

    def activate(self):
        """Activate subscriber."""
        if not self.active:
            self._dispatcher.add_subscriber(self)
            log.info(f"{self} is activated.")

    def deactivate(self):
        """Deactivate subscriber."""
        if self.active:
            self._dispatcher.remove_subscriber(self)
            log.info(f"{self} is deactivated.")

    def dispatch(self, event: BaseEvent):
        """Receive event from dispatcher."""
        for subscription in (sub for sub in self._subscriptions if sub.match(event)):
            log.debug(f"{self} dispatches {event} to {subscription}")
            self._call_back(event, subscription)

    def __enter__(self):
        """Activate subscriber."""
        self.activate()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Deactivate subscriber."""
        self.deactivate()

    @property
    def active(self):
        """Check if subscriber is active."""
        return self in self._dispatcher

    @property
    def subscriptions(self):
        """Get all subscriptions."""
        return self._subscriptions

    @property
    def name(self):
        """Get name of subscriber."""
        return self._name

    def __str__(self) -> str:
        return f"{self._name}"

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}<{self._name}: {', '.join(str(sub) for sub in self._subscriptions)}>"
