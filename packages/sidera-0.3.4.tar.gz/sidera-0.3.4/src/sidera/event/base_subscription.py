from abc import ABC, abstractmethod

from .base_event import BaseEvent


class BaseSubscription(ABC):
    """Base event target filter class."""

    @abstractmethod
    def match(self, event: BaseEvent) -> bool:
        """Check if the event is matched."""
        raise NotImplementedError
