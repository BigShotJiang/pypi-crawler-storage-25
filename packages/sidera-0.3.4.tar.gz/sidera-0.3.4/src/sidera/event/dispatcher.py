from sidera.task import Context

from .subscriber import EventSubscriber


class EventDispatcher:
    """Event dispatcher for each context."""

    @classmethod
    def current(cls, user_name: str | None = None) -> "EventDispatcher":
        """Get event dispatcher for context."""
        return Context.get_by_type(cls, user_name=user_name)

    def __init__(self):
        self._subscribers: list[EventSubscriber] = []

    @classmethod
    def add_subscriber(cls, subscriber: EventSubscriber):
        """Add subscriber to dispatcher."""
        self = cls.current()
        self._subscribers.append(subscriber)

    @classmethod
    def remove_subscriber(cls, subscriber: EventSubscriber):
        """Add subscriber to dispatcher."""
        self = cls.current()
        self._subscribers.remove(subscriber)

    @classmethod
    def dispatch(cls, event):
        """Dispatch event to all subscribers."""
        self = cls.current()
        for subscriber in self._subscribers:
            subscriber.dispatch(event)

    @classmethod
    def clear(cls):
        """Clear all subscribers."""
        self = cls.current()
        self._subscribers.clear()

    def __contains__(self, subscriber: EventSubscriber):
        """Check if subscriber is in the dispatcher."""
        return subscriber in self._subscribers

    def __len__(self):
        """Get number of subscribers."""
        return len(self._subscribers)
