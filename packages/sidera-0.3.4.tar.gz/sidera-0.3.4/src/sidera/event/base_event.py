from pydantic import BaseModel, Field, StrictStr, ConfigDict
from pydantic.alias_generators import to_camel


class BaseEvent(BaseModel):
    """Event base model."""

    model_config = ConfigDict(
        extra="ignore", strict=True, alias_generator=to_camel, populate_by_name=True
    )

    event_name: StrictStr = Field(..., title="Event Name")

    def dispatch(self):
        """Dispatch event to subscribers."""
        from .dispatcher import EventDispatcher

        EventDispatcher.dispatch(self)

    def __str__(self):
        return f"Event<{self.event_name}>"
