import asyncio
from collections.abc import Awaitable, Callable, Iterable

from sidera.task import WorkerGroup

from .base_event import BaseEvent
from .base_subscription import BaseSubscription
from .async_subscriber import AsyncEventSubscriber

EventHandler = Callable[[BaseEvent, BaseSubscription], Awaitable[None]]
EventSubscriptions = (
    dict[BaseSubscription, EventHandler] | Iterable[BaseSubscription] | BaseSubscription
)


class EventDispatchWorker:
    """Event dispatch task."""

    _Terminate = object()

    def __init__(
        self,
        name: str = "",
        handler: EventHandler | None = None,
        subscriptions: EventSubscriptions = {},
    ):
        self._name = name or "<unnamed>"
        self._default_handler: EventHandler = handler or self._dummy_handler
        self._handlers: dict[BaseSubscription, EventHandler] = self._get_subscriptions(
            subscriptions
        )
        self._subscriber = AsyncEventSubscriber(
            subscriptions=self._handlers.keys(), name=name
        )
        self._worker = WorkerGroup.append_worker(self._run(), self._name)
        self._active = asyncio.Event()
        self.start()

    def _get_subscriptions(self, subscriptions: EventSubscriptions):
        """Get subscriptions and handlers dict from input parameter."""
        match subscriptions:
            case BaseSubscription():
                return {subscriptions: self._default_handler}
            case dict() if all(
                isinstance(sub, BaseSubscription) and callable(handler)
                for sub, handler in subscriptions.items()
            ):
                return subscriptions
            case Iterable() if all(
                isinstance(sub, BaseSubscription) for sub in subscriptions
            ):
                return {sub: self._default_handler for sub in subscriptions}
            case _:
                raise TypeError(f"Invalid subscriptions: {subscriptions}")

    def start(self):
        """Start event subscription."""
        self._active.set()
        self._subscriber.activate()

    def stop(self):
        """Stop event subscription."""
        self._active.clear()
        self._subscriber.deactivate()

    def remove(self):
        """Remove publisher."""
        self.stop()
        self._worker.cancel()

    async def _run(self):
        """Task entry to wait event and dispatch to handler."""
        while True:
            await self._active.wait()
            async for event, subscription in self._subscriber:
                # Subscription may be removed by other task.
                handler = self._handlers.get(subscription, self._dummy_handler)
                if handler is None:
                    continue
                await handler(event, subscription)

    async def _dummy_handler(self, event: BaseEvent, subscription: BaseSubscription):
        """Dummy handler for event."""
        pass

    def add_subscription(
        self, subscription: BaseSubscription, handler: EventHandler | None = None
    ):
        """Add subscription and handler to publisher."""
        self._subscriber.append(subscription)
        self._handlers[subscription] = handler or self._default_handler

    def remove_subscription(self, subscription: BaseSubscription):
        """Remove subscription handler to publisher."""
        self._subscriber.remove(subscription)
        self._handlers.pop(subscription)

    @property
    def subscriber(self):
        """Get subscriber."""
        return self._subscriber

    @property
    def handlers(self):
        """Get all subscriptions."""
        return self._handlers

    @property
    def active(self):
        """Check if publisher is active."""
        return self._active.is_set()

    @property
    def subscriptions(self):
        """Get all subscriptions."""
        return self._subscriber.subscriptions

    def __str__(self) -> str:
        return f"Publisher<{self._name}>"

    def __repr__(self) -> str:
        return (
            f"Publisher<{self._name}: {', '.join(str(sub) for sub in self._handlers)}>"
        )
