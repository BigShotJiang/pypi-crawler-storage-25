from asyncio import Queue
from logging import getLogger
from typing import Callable, Iterable

from .base_event import BaseEvent
from .base_subscription import BaseSubscription
from .subscriber import EventSubscriber

log = getLogger(__name__)

EventNotify = tuple[BaseEvent, BaseSubscription]
EventHandler = Callable[[EventNotify], None]


class AsyncEventSubscriber(EventSubscriber):
    """Event Subscriber."""

    def __init__(
        self,
        subscriptions: Iterable[BaseSubscription] | BaseSubscription = [],
        name: str = "",
    ):
        self._queue: Queue[EventNotify] = Queue()
        super().__init__(self._put_event, subscriptions, name)

    async def get_event(self):
        """Dispatch event to subscriber."""
        return await self._queue.get()

    async def __aenter__(self):
        """Activate subscriber."""
        self.activate()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Deactivate subscriber."""
        self.deactivate()

    def __aiter__(self):
        """Async iterator for event."""
        self.activate()
        return self

    async def __anext__(self) -> EventNotify:
        """Async iterator for event."""
        if not self.active:
            self.deactivate()
            raise StopAsyncIteration
        return await self.get_event()

    def _put_event(self, event: BaseEvent, subscription: BaseSubscription):
        """Dispatch event for each subscription."""
        self._queue.put_nowait((event, subscription))

    def __str__(self) -> str:
        return f"AsyncSubscriber<{self._name}>"

    def __repr__(self) -> str:
        return f"AsyncSubscriber<{self._name}: {', '.join(str(sub) for sub in self._subscriptions)}>"
