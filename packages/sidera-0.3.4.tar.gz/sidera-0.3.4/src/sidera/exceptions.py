class NodeNotFoundError(Exception):
    """Sidera custom exception if node not found."""

    pass


class MultipleNodesFoundError(KeyError):
    """Sidera custom exception if multiple nodes are found by the specified key."""

    pass


class InvalidNodeOperation(ValueError):
    """Sidera custom exception if the node of the specified path does not accept the operation."""

    pass


class DuplicateIdError(ValueError):
    """Sidera custom exception if the node with the same ID already exists."""

    pass
