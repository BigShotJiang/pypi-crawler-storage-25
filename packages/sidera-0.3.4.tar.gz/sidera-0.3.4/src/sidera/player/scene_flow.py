from logging import getLogger

from pydantic import Field

from sidera.scenario import NodePath
from sidera.scenario.models import (
    BaseItemModel,
    Scene,
    StatePatch,
    Story,
    StoryPatch,
)

log = getLogger(__name__)


class SceneFlow(BaseItemModel):
    """Scene flow data"""

    start_state_path: str = Field(
        default="",
        description="The node path if the start sate exists, otherwise empty.",
    )
    start_state: StatePatch | None = Field(
        default=None,
        description="The state information if the start state exists, otherwise None.",
    )
    active_story: StoryPatch | None = Field(
        default=None,
        description="The story information if the current active story exists, otherwise None.",
    )
    scenes: list[Scene] = Field(
        default=[],
        description="The list of scene data.",
    )
    dest_state: StatePatch | None = Field(
        default=None,
        description="The state information if the destination state exists, otherwise None.",
    )

    @classmethod
    def set_story(cls, story_path: NodePath):
        """Set the defined story as scene flow."""
        story = story_path.get_data(Story)

        start_state_path = story_path.parent.parent
        start_state = start_state_path.get_patch(StatePatch)

        dest_state = None
        if story.dest_state_name is not None:
            dest_state_path = start_state_path.parent / story.dest_state_name
            if dest_state_path.exists():
                dest_state = dest_state_path.get_patch(StatePatch)
            else:
                log.warning(
                    f"{story_path} has dest state '{dest_state_path}', but not found."
                )

        scenes = story.scenes
        return cls(
            start_state_path=str(start_state_path),
            start_state=start_state,
            active_story=story.get_patch(),
            scenes=scenes,
            dest_state=dest_state,
        )
