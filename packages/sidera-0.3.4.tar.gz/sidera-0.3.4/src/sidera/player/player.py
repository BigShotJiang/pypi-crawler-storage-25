from logging import getLogger

from sidera.event import BaseEvent, BaseSubscription, EventSubscriber
from sidera.scenario import NodePath, NodeSubscription
from sidera.scenario.models import Input, Output
from sidera.task import Context

from .scene_flow import SceneFlow

log = getLogger(__name__)

DEFAULT_STATE = NodePath("states/0")
DEFAULT_STORY = DEFAULT_STATE / "stories/0"


class Player:
    """Player class."""

    @classmethod
    def current(cls, user_name: str | None = None) -> "Player":
        """Get player for context."""
        return Context.get_by_type(cls, user_name=user_name)

    def __init__(self):
        # Playing position
        self._current_story_path: NodePath | None = None
        self._current_scene_flow = SceneFlow()
        self._current_scene_index = 0
        self._inputs: list[Input] = []
        self._output: list[Output] = []

        # Set up event subscriber
        self._evt_states = NodeSubscription(NodePath("states"))
        self._evt_signals = NodeSubscription(NodePath("signals"))
        self._event_subscriber = EventSubscriber(
            self._event_handler, [self._evt_states, self._evt_signals]
        )
        self._event_subscriber.activate()
        self.set_story(DEFAULT_STORY)
        self.reset()

    def set_story(self, story_path: NodePath):
        """Set current story."""
        if story_path.exists():
            self._current_story_path = story_path.resolve()
            scene_flow = SceneFlow.set_story(story_path)
            self._current_scene_flow = scene_flow
        else:
            self._current_story_path = None
            self._current_scene_flow = SceneFlow()
            log.warning(f"Story path {story_path} does not exist.")

    def _event_handler(self, event: BaseEvent, subscription: BaseSubscription):
        """Handle event."""
        if subscription == self._evt_states:
            self.update_story()

    def update_story(self):
        """Update player with latest story data."""
        if self._current_story_path is None:
            new_story = DEFAULT_STORY
        elif not self._current_story_path.exists():
            log.warning(f"Story path {self._current_story_path} does not exist.")
            new_story = DEFAULT_STORY
        else:
            new_story = self._current_story_path
        self.set_story(new_story)

    def reset(self):
        """Reset player to start state."""
        self._current_scene_index = 0

    def check_current_flow(self):
        """Check current scene flow data."""
        if not self._current_scene_flow.start_state:
            return False
        if len(self._current_scene_flow.scenes) == 0:
            return False
        return True

    @property
    def current_scene_flow(self) -> SceneFlow:
        """Get current scene flow."""
        return self._current_scene_flow
