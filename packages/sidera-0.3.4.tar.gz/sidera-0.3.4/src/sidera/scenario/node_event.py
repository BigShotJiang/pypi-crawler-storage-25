from typing import Literal, TypeAlias

from pydantic import Field

from sidera.event import BaseEvent

NodeEventName = Literal[
    "on_create",
    "on_update",
    "on_delete",
    "on_change_current_scenario",
]

Propagation = Literal["parents", "children", "both", "none", "all"]


class BaseNodeEvent(BaseEvent):
    """Node event base model."""

    event_name: NodeEventName = Field(..., title="Event Name")
    propagation: Propagation = Field(default="parents", title="Propagation type")
    source: str = Field(..., title="Node or group path to publish event")

    def __str__(self):
        from sidera.scenario.nodes import NodePath

        path = NodePath(self.source)
        return f"{self.event_name}({path.named or path.resolve()})"

    def __repr__(self):
        return f"NodeEvent<{self}>"

    def __eq__(self, other: object) -> bool:
        from sidera.scenario.nodes import NodePath

        if isinstance(other, BaseNodeEvent):
            return (
                self.event_name == other.event_name
                and self.propagation == other.propagation
                and NodePath(self.source) == NodePath(other.source)
            )
        return super().__eq__(other)


class CreateNodeEvent(BaseNodeEvent):
    """Event about addition of new node."""

    event_name: NodeEventName = "on_create"
    propagation: Propagation = "parents"


class UpdateNodeEvent(BaseNodeEvent):
    """Event about update of node data."""

    event_name: NodeEventName = "on_update"
    propagation: Propagation = "both"


class DeleteNodeEvent(BaseNodeEvent):
    """Event about deletion of node."""

    event_name: NodeEventName = "on_delete"
    propagation: Propagation = "both"


class ChangeCurrentScenarioEvent(BaseNodeEvent):
    """Event about changed current scenario."""

    event_name: NodeEventName = "on_change_current_scenario"
    propagation: Propagation = "both"


NodeEventType: TypeAlias = (
    CreateNodeEvent | UpdateNodeEvent | DeleteNodeEvent | ChangeCurrentScenarioEvent
)
