from itertools import chain
from logging import getLogger
from typing import TYPE_CHECKING, Iterable
from uuid import UUID

from sidera.exceptions import MultipleNodesFoundError, NodeNotFoundError
from sidera.scenario.models import BaseItemModel, ItemLink, ItemUUID, Scenario

from .changed_paths import ChangedPaths
from .node_id import UNSET_UUID, NodeId, ScenarioId

if TYPE_CHECKING:
    from .field_node import FieldNode
    from .group_node import GroupNode
    from .item_node import ItemNode

log = getLogger(__name__)


class ItemMap:
    """Manages the mapping of node id and object."""

    _scenario_id: ScenarioId = ScenarioId(UNSET_UUID)
    _scenario_node: "ItemNode[Scenario] | None"
    _id_map: "dict[UUID, ItemNode]"

    def __init__(self, scenario_id: ScenarioId):
        self._scenario_id = scenario_id
        self._scenario_node = None
        self._id_map = {}

    @property
    def scenario_id(self) -> ScenarioId:
        """Get scenario id."""
        return self._scenario_id

    @property
    def id_map(self) -> dict[UUID, "ItemNode"]:
        """Get id map."""
        return self._id_map

    @property
    def scenario_node(self) -> "ItemNode[Scenario]":
        """Get scenario id."""
        if self._scenario_node is None:
            raise NodeNotFoundError(f"Scenario id is not found: {self._scenario_id}")
        return self._scenario_node

    def initialize(self, scenario_node: "ItemNode[Scenario]"):
        """Add node to the map."""
        if scenario_node.id.uuid != self._scenario_id.uuid:
            raise ValueError(
                f"Invalid scenario node {scenario_node} for the map {self._scenario_id}"
            )
        self._scenario_node = scenario_node
        self._id_map[scenario_node.id.uuid] = scenario_node
        self.update()
        self.validate_links()

    def add_node(self, node: "ItemNode"):
        """Add node to the map."""
        if node.scenario_id != self._scenario_id:
            raise NodeNotFoundError(
                f"Node {node} is not in the same scenario: {self._scenario_id}"
            )
        if node.id.uuid in self._id_map:
            raise ValueError(f"Already exists node id: {node.id.uuid}")
        self._id_map[node.id.uuid] = node
        self.update()
        return

    def update(self):
        """Update item map with scenario node."""
        new_map = {}
        self._setup_items(self.scenario_node, new_map)
        self._id_map = new_map
        return

    def _setup_items(self, item: "ItemNode", new_map: "dict[UUID, ItemNode]"):
        """Create all item node in group data."""
        for group in item.iter_children():
            for data in group.data:
                assert isinstance(data, BaseItemModel)
                item = self._id_map.get(data.id) or group.create_item(data)
                new_map[data.id] = item
                self._setup_items(item, new_map)

    def get_node(self, node_id: BaseItemModel | NodeId | UUID) -> "ItemNode":
        """Get node by id."""
        match node_id:
            case NodeId():
                uuid = node_id.uuid
            case UUID():
                uuid = node_id
            case BaseItemModel():
                uuid = node_id.id
            case _:
                raise TypeError(f"Invalid type of node id: {type(node_id)}: {node_id}")
        if (node := self._id_map.get(uuid)) is None:
            raise NodeNotFoundError(f"Node id is not found: {node_id}")
        return node

    def remove_children(self, node: "GroupNode | ItemNode"):
        """Remove the node child subtree from the map."""
        from sidera.scenario.nodes.item_node import ItemNode

        changed = ChangedPaths()
        for child in node.iter_children():
            self.remove_children(child)
            if isinstance(child, ItemNode):
                self._id_map.pop(child.id.uuid)
                changed -= child.path
        return changed

    def validate_links(self):
        """Validate item links in scenario."""
        return self._validate_subtree_link(self.scenario_node)

    def get_referrers(self, node: "ItemNode", include_subtree: bool = False):
        """Get a path list of   all referrers of the node."""
        if not include_subtree:
            return list(self._iter_item_referrers(node))
        return list(
            field
            for field in chain(
                self._iter_item_referrers(node),
                *(
                    self._iter_item_referrers(child)
                    for child in chain.from_iterable(
                        group.iter_children() for group in node.iter_children()
                    )
                ),
            )
        )

    def _iter_item_referrers(self, node: "ItemNode"):
        return iter(
            field
            for field in self._iter_link_fields(self.scenario_node)
            if any(
                item_link
                for item_link in field.iter_link()
                if item_link.id == node.id.uuid
            )
        )

    def _iter_link_fields(self, node: "ItemNode") -> "Iterable[FieldNode]":
        """Yield all fields with item link in the node."""
        for field in node.iter_fields():
            if field.has_link:
                yield field
        for group in node.iter_children():
            for child in group.iter_children():
                yield from self._iter_link_fields(child)

    def _validate_subtree_link(self, item: "ItemNode"):
        """Recursively validate child items."""
        changed = self._validate_link_fields(item)
        for child_item in chain.from_iterable(
            group.iter_children() for group in item.iter_children()
        ):
            changed &= self._validate_subtree_link(child_item)
        return changed

    def _validate_link_fields(self, item: "ItemNode"):
        """Validate item link fields."""
        changed = ChangedPaths()
        for field in (field for field in item.iter_fields() if field.has_link):
            updated = False
            for item_link in field.iter_link():
                update_link = self.validate_item_link(item, item_link)
                if update_link:
                    log.debug(
                        f"Update item link: {item.full_name}\n  {item_link} -> {update_link}"
                    )
                    item_link.apply_from(update_link)
                    updated = True
            if updated:
                changed |= field.path
        return changed

    def validate_item_link(self, source_node: "ItemNode", item_link: ItemLink):
        """Validate value of item link field."""
        if source_node.scenario_id != self._scenario_id:
            raise NodeNotFoundError(
                f"Link node is not in the same scenario: {source_node.scenario_id}"
            )
        if item_link.is_unset():
            return None
        if item_link.is_offset_link():
            return self._validate_offset_link(source_node, item_link)
        return self._validate_path_link(item_link)

    def _validate_path_link(self, item_link: ItemLink):
        """Validate path link."""
        if id_node := self._get_node_from_id(item_link.id):
            if id_node.relative_name == item_link.path:
                # Path link is valid
                return None
            # Update path from id
            return ItemLink(id=item_link.id, path=id_node.relative_name)
        if path_node := self._get_node_from_link_path(item_link.path):
            # Update id from path
            return ItemLink(id=path_node.id.uuid, path=path_node.relative_name)
        if item_link.path is not None:
            if item_link.id != UNSET_UUID:
                # Both of id and path is unlinked, clear the id
                return ItemLink(id=UNSET_UUID, path=item_link.path)
        # Path is unlinked
        log.debug(f"Unlinked path link: {item_link}")
        return None

    def _get_node_from_link_path(
        self,
        path: str | None,
    ):
        """Get node from path."""
        from sidera.scenario.nodes.item_node import ItemNode

        if path is None:
            return None
        parts = path.split("/")
        item_node = self.scenario_node
        try:
            while parts:
                group_name = parts.pop(0)
                item_name = parts.pop(0)
                item_node = item_node[group_name][item_name]
                assert isinstance(item_node, ItemNode)
            return item_node
        except MultipleNodesFoundError:
            log.info(
                f"Multiple item nodes found for path {path}: {self}\n  {item_node}"
            )
            return None
        except Exception as e:
            log.info(f"Link path {path} is not found in the map: {self}\n  {e}")
            return None

    def _validate_offset_link(self, source_node: "ItemNode", item_link: ItemLink):
        """Validate offset link."""
        assert item_link.offset is not None
        if id_node := self._get_node_from_id(item_link.id):
            offset = self._get_offset_of_node(source_node, id_node)
            if item_link.offset == offset:
                # Offset link is valid
                return None
            # Update offset from id
            return ItemLink(id=item_link.id, offset=offset)
        if offset_node := self._get_node_from_offset(source_node, item_link):
            # Update path in link
            return ItemLink(id=offset_node.id.uuid, offset=item_link.offset)
        if item_link.id != UNSET_UUID:
            # Both of id and path is unlinked, clear the id
            return ItemLink(id=UNSET_UUID, offset=item_link.offset)
        # Offset is unlinked
        log.debug(f"Unlinked offset link: {item_link}")
        return None

    def _get_node_from_id(self, item_id: ItemUUID):
        """Get node from item id."""
        if item_id == UNSET_UUID:
            return None
        node = self._id_map.get(item_id)
        if node is None:
            log.info(f"Link id {item_id} is not found in the map: {self}")
        return node

    def _get_node_from_offset(self, source_node: "ItemNode", item_link: ItemLink):
        """Get item node from item link offset."""
        if not (offset := item_link.offset):
            return None
        group_node = source_node.parent
        index = source_node.index + offset
        if index < 0 or group_node.child_count <= index:
            log.info(f"Link offset {offset} is out of range: {group_node}")
            return None
        return group_node[index]

    def _get_offset_of_node(self, source_node: "ItemNode", target_node: "ItemNode"):
        """Get id of the signal value from item link."""
        group_node = source_node.parent
        if target_node.parent != group_node:
            log.info(
                f"Link node {source_node} is not in the same group as {target_node}."
            )
            return None
        return target_node.index - source_node.index

    def __bool__(self) -> bool:
        """Check if the map is empty."""
        return self._scenario_id.uuid != UNSET_UUID

    def __str__(self) -> str:
        if self._scenario_node is None:
            return f"ItemMap(scenario=<None>:{self.scenario_id}, {len(self._id_map)} nodes)"
        return f"ItemMap(scenario='{self.scenario_node.name}':{self.scenario_id}, {len(self._id_map)} nodes)"

    def __repr__(self) -> str:
        return str(self) + "\n" + self.dump(max=10)

    def dump(self, max: int | None = None) -> str:
        """Dump item map for debug."""
        if (max is None) or len(self._id_map) <= max:
            return "\n".join(
                f"  {node.id}: {node.relative_name}" for node in self._id_map.values()
            )
        return (
            "\n".join(
                f"  {node.id}: {node.relative_name}"
                for node in list(self._id_map.values())[:max]
            )
            + f"\n  ... (total {len(self._id_map)})"
        )
