from logging import getLogger
from pathlib import PurePath
from typing import TypeGuard

from typing_extensions import Self

from sidera.exceptions import InvalidNodeOperation, NodeNotFoundError
from sidera.scenario.models import Scenario
from sidera.task import Context

from .changed_paths import ChangedPaths
from .group_node import GroupNode
from .item_map import ItemMap
from .node_id import UNSET_UUID, NodeId, ScenarioId
from .scenario_context import ScenarioContext

log = getLogger(__name__)


class ScenarioGroup(GroupNode[Scenario]):
    """Group of scenarios."""

    NAME = "scenarios"
    _parent: Self

    @classmethod
    def get_instance(cls) -> "ScenarioGroup":
        """Get singleton scenarios group singleton."""
        return Context.get_by_type(cls)

    def __init__(self):
        self._scenario_list: list[Scenario] = []
        self._scenario_map: dict[ScenarioId, ItemMap] = {}
        self._current_id = ScenarioId(UNSET_UUID)
        self.dispatch_current_changed = self._dummy_dispatcher
        super().__init__(self.NAME, list[Scenario], self._scenario_list, self)
        self._path = PurePath(f"/{self.NAME}")
        self._full_name = PurePath(f"/{self.NAME}")

    @staticmethod
    def _dummy_dispatcher():
        """Dummy function for type hint."""
        pass

    def iter_children(self):
        """Iterate over child nodes."""
        return (map.scenario_node for map in self._scenario_map.values() if map)

    def get_copied_data(self):
        """Get deep copied data of the node."""
        raise InvalidNodeOperation("ScenariosGroup does not support get_copied_data")

    def select_scenario(self, scenario_id: ScenarioId):
        """Select scenario."""
        previous_id = self._current_id
        try:
            if scenario_id == ScenarioId(UNSET_UUID):
                if self.child_count == 0:
                    self._current_id = ScenarioId(UNSET_UUID)
                    return None
                scenario_id = next(self.iter_children()).scenario_id
            elif scenario_id not in self._scenario_map:
                raise NodeNotFoundError(f"Scenario id '{scenario_id}' is not found.")
            self._current_id = scenario_id
            return self[self._current_id]
        finally:
            # Dispatch event
            if previous_id != self._current_id:
                self.dispatch_current_changed()

    def append_child(
        self,
        data: Scenario,
        context: ScenarioContext | None = None,
        source: str = "",
    ):
        """Append scenario to the group."""
        scenario_id = ScenarioId(data.id)
        if scenario_id in self:
            data = data.copy(deep=False)
            log.info(
                f"Set a new scenario id '~{data.id}', because the current id '{scenario_id}' already exists."
            )

        self.data.append(data)

        item_map = ItemMap(scenario_id)
        self._scenario_map[scenario_id] = item_map
        context = context or ScenarioContext(scenario_id, item_map, source)
        scenario_node = self.create_item(data, context)
        item_map.initialize(scenario_node)

        if self._current_id == ScenarioId(UNSET_UUID):
            self.select_scenario(scenario_id)
        return scenario_node, ChangedPaths(appended=[scenario_node.path])

    def remove_child(self, data: Scenario):
        """Remove scenario from the group."""
        remove_id = ScenarioId(data.id)
        item_map = self._scenario_map.pop(remove_id, None)
        if item_map is None:
            raise NodeNotFoundError(f"Scenario id '{remove_id}' is not found.")
        node = item_map.scenario_node
        self._scenario_list.remove(node.data)
        if self._current_id == remove_id:
            self.select_scenario(ScenarioId(UNSET_UUID))
        return ChangedPaths(
            removed=[node.path],
        )

    def get_patch(self, **kwargs):
        """Get copied patch data of the node."""
        raise InvalidNodeOperation("ScenariosGroup does not support patch.")

    def dump_json(self, indent: int | None = 2) -> str:
        """Dump node data to json."""
        raise InvalidNodeOperation("ScenariosGroup does not support dump_json.")

    def sync(self, sync_data: list[Scenario]):
        """Sync group data."""
        raise InvalidNodeOperation("ScenariosGroup does not support sync")

    def clear(self):
        """Clear data and all children data."""
        raise InvalidNodeOperation(
            "ScenariosGroup does not support clear(), instead use clear_scenarios()"
        )

    def clear_scenarios(self):
        """Clear all scenarios."""
        changed = ChangedPaths(
            removed=[map.scenario_node.path for map in self._scenario_map.values()]
        )
        self._scenario_list.clear()
        self._scenario_map.clear()
        self.select_scenario(ScenarioId(UNSET_UUID))
        return changed

    @classmethod
    def is_type(
        cls, node: object, model: type[Scenario] = Scenario
    ) -> TypeGuard["ScenarioGroup"]:
        """Check if node is of ScenarioGroup type."""
        return super().is_type(node, model)

    @property
    def id(self) -> NodeId:
        """Id of node like "~00000000-0000-..." format."""
        return NodeId(UNSET_UUID)

    @property
    def current_id(self) -> ScenarioId:
        """Get current scenario id."""
        return self._current_id

    @property
    def current_node(self):
        """Get current scenario node."""
        if item_map := self._scenario_map.get(self._current_id, None):
            return item_map.scenario_node
        return None
