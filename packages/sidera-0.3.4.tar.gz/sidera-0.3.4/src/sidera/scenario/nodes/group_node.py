from json import loads as json_loads
from typing import (
    TYPE_CHECKING,
    Any,
    Generic,
    Iterator,
    TypeGuard,
    TypeVar,
    cast,
    get_args,
)

from typing_extensions import Self

from sidera.exceptions import DuplicateIdError
from sidera.scenario.models import ItemModel, group_dump_json

from .base_node import BaseNode
from .changed_paths import ChangedPaths
from .node_id import NodeId
from .scenario_context import ScenarioContext

if TYPE_CHECKING:
    from .item_node import ItemNode

T = TypeVar("T", bound=ItemModel)


class GroupNode(BaseNode[list[T]], Generic[T]):
    """Node for a group of DataModel items."""

    _child_model: type[T]
    _parent: "ItemNode | Self"

    def __init__(
        self, name: str, model: type[list[T]], data: list[T], parent: "ItemNode | Self"
    ):
        super().__init__(name, model, data, parent)
        child_model_args = get_args(model)
        if len(child_model_args) == 0:
            assert False, f"Model {model} has no child model"
        self._child_model = get_args(model)[0]

    def create_item(
        self, data: T, context: ScenarioContext | None = None
    ) -> "ItemNode[T]":
        """Create item node as child."""
        from .item_node import ItemNode

        name = data.get_name()
        item = ItemNode(name, self._child_model, data, self, context)
        return item

    def iter_children(self) -> Iterator["ItemNode[T]"]:
        """Iterate over child nodes."""
        return (self.item_map.get_node(data) for data in self.data)

    def get_copied_data(self):
        """Get deep copied data of the node."""
        return [data.copy() for data in self.data]

    def dump_json(self, indent: int | None = 2) -> str:
        """Dump node data to json."""
        return group_dump_json(self.data, indent=indent)

    def sync(self, sync_data: list[T]) -> ChangedPaths:
        """Sync group data."""
        changed = self._sync(sync_data)
        if changed:
            changed &= self.item_map.validate_links()
        return changed

    def _sync(self, sync_data: list[T]) -> ChangedPaths:
        """Sync group data internal process."""
        if type(sync_data) is not list:
            raise ValueError(f"Invalid data type to sync {self}: {type(sync_data)}")
        changed, new_data_list = self._create_new_list(sync_data)
        changed &= self._check_removed(new_data_list)
        changed = changed or self._check_order_changed(new_data_list)
        # Replace data with new data
        if changed:
            self.data[:] = new_data_list
            self.item_map.update()
        return changed

    def _create_new_list(self, sync_data: list[T]):
        """Create new list of sync and append data."""
        cur_item_dict = {item.data.id: item for item in self.iter_children()}
        self._check_duplicate_id(sync_data)
        changed = ChangedPaths()
        new_data_list: list[T] = []
        for item_data in sync_data:
            if cur_item := cur_item_dict.get(item_data.id):
                # Sync item
                changed &= cur_item._sync(item_data)
                new_data_list.append(cur_item.data)
                continue
            # Append new data
            new_data_list.append(item_data)
            changed += f"{self.path}/~{item_data.id}"
        return changed, new_data_list

    def _check_duplicate_id(self, sync_data: list[T]):
        """Check if there are duplicate ids in the list."""
        ids_set = set(data.id for data in sync_data)
        if len(ids_set) != len(sync_data):
            raise DuplicateIdError(f"Duplicate id found in sync data: {self}")

    def _check_removed(self, new_data_list: list[T]):
        """Check if item is removed."""
        changed = ChangedPaths()
        new_ids = set(dt.id for dt in new_data_list)
        for item_path in (
            item.path for item in self.iter_children() if item.data.id not in new_ids
        ):
            # Remove item
            changed -= item_path
        return changed

    def _check_order_changed(self, new_data_list: list[T]):
        """Check if order of items is changed."""
        changed = ChangedPaths()
        for new_data, cur_data in zip(new_data_list, self.data):
            if new_data.id != cur_data.id:
                # Order of items is changed
                changed += self.path
                continue
        return changed

    def convert_to_model(self, data: Any) -> list[T]:
        """Convert data to model."""
        if isinstance(data, str):
            try:
                data = json_loads(data)
            except Exception:
                pass
        if isinstance(data, list):
            if all(isinstance(dt, self._child_model) for dt in data):
                return data
            if all(isinstance(dt, dict) for dt in data):
                return cast(
                    list[T], [self._child_model.model_validate(dt) for dt in data]
                )
        raise TypeError(f"Invalid data type to convert for {self}")

    def clear(self):
        """Clear all data from list."""
        changed = self.item_map.remove_children(self)
        self.data.clear()
        if changed:
            self.item_map.update()
            changed &= self.item_map.validate_links()
        return changed

    def append_child(
        self, data: T, context: ScenarioContext | None = None
    ) -> "tuple[ItemNode[T], ChangedPaths]":
        """Add data in list and create item node."""
        if data.id in set(dt.id for dt in self.data):
            raise DuplicateIdError(
                f"Data already exists in group. data: {data.get_name()}, group: {self}"
            )
        self.data.append(data)
        item = self.create_item(data, context)
        changed = ChangedPaths(appended=[item.path])
        self.item_map.add_node(item)
        changed &= self.item_map.validate_links()
        return item, changed

    def remove_child(self, data: T):
        """Remove data from group node data."""
        node = self.item_map.get_node(data)
        self.data.remove(data)
        changed = ChangedPaths(removed=[node.path])
        self.item_map.update()
        changed &= self.item_map.validate_links()
        return changed

    def get_child_model(self) -> type[T]:
        """Return child model."""
        return self._child_model

    @classmethod
    def is_type(cls, node: object, model: type[Any]) -> TypeGuard["GroupNode[Any]"]:
        """Check if node is of ItemNode type."""
        return super().is_type(node, model)

    @property
    def id(self) -> NodeId:
        """Id of node like "~00000000-0000-..." format."""
        return NodeId(self._parent.id).with_field(self._name)

    @property
    def patch_model(self) -> None:
        """Model type to update node."""
        return None

    @property
    def child_count(self) -> int:
        """Return number of items in group."""
        return len(self.data)

    @property
    def _generic_type(self) -> type[T]:
        """Return model of generic type."""
        return self._child_model

    def __getitem__(self, key: "BaseNode | NodeId | str | int"):
        """Get child node by index."""
        from .item_node import ItemNode

        item = super().__getitem__(key)
        assert ItemNode.is_type(item, self._child_model)
        return item

    def __str__(self) -> str:
        class_name = self.class_name.replace("list", self._child_model.__name__)
        return f"{class_name}<{self.full_name}>"

    def __repr__(self) -> str:
        return f"{super().__repr__()}: {len(self.data)} items"
