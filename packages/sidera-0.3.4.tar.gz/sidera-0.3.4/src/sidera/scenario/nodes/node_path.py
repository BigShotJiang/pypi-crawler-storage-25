from copy import deepcopy
from logging import getLogger
from os import PathLike
from pathlib import Path, PurePath, PurePosixPath
from typing import Any, Iterator, Literal, TypeAlias, TypeVar, cast, overload

from sidera.exceptions import (
    InvalidNodeOperation,
    MultipleNodesFoundError,
    NodeNotFoundError,
)
from sidera.scenario.models import (
    GroupName,
    ItemModel,
    Scenario,
)
from sidera.scenario.models.items.type_checkers import (
    is_group_name,
    is_subclass_of_model,
)
from sidera.scenario.node_event import (
    ChangeCurrentScenarioEvent,
    DeleteNodeEvent,
    NodeEventType,
)
from sidera.task import Context

from .base_node import (
    BaseNode,
    ChildNodeOperations,
    FieldModel,
    NodeDataModel,
    NodeModelType,
    PatchModel,
)
from .field_node import FieldNode
from .group_node import GroupNode
from .item_node import ItemNode
from .node_id import UNSET_UUID, NodeId, ScenarioId
from .scenario_group import ScenarioGroup

TBaseNode = TypeVar("TBaseNode", bound=BaseNode[Any])
TNodeModelType = TypeVar("TNodeModelType", bound=NodeModelType)
TPatchModel = TypeVar("TPatchModel", bound=PatchModel)

PathType: TypeAlias = Literal[
    "top", "absolute", "current", "scenario-id", "item-id", "invalid"
]
NodeType: TypeAlias = Literal[
    "top", "scenario", "group", "item", "field", "(unknown)", "(non-existent)"
]

log = getLogger(__name__)


class NodePath(PurePosixPath):
    """Node path class for sidera data tree."""

    @classmethod
    def _get_top_path(cls):
        """Get top path."""
        return Context.get_by_type(cls, f"/{ScenarioGroup.NAME}")

    def __init__(self, *args):
        super().__init__()
        self._top_group = ScenarioGroup.get_instance()
        self._path_type, self._scenario_name = self._parse_path_type()
        if not self.is_top:
            self._top_path = self._get_top_path()
        else:
            self._top_path = self
            self._top_group.dispatch_current_changed = lambda: self._dispatch_event(
                ChangeCurrentScenarioEvent
            )

    def _parse_path_type(self) -> tuple[PathType, str | None]:
        """Parse path type and scenario name."""
        if self.parts == ():
            return "current", ""
        if self.parts in {("/", ScenarioGroup.NAME), ("/",)}:
            return "top", None
        if super().is_absolute() and self.parts[1] == ScenarioGroup.NAME:
            return "absolute", self.parts[2]
        if super().is_absolute():
            return "invalid", None
        if self.parts[0] in self._top_group:
            return "scenario-id", self.parts[0]
        if self.parts[0].startswith("~"):
            return "item-id", ""
        return "current", ""

    @overload
    def _get_node(self, node_type: None = None) -> BaseNode[Any]:
        pass

    @overload
    def _get_node(self, node_type: type[TBaseNode]) -> TBaseNode:
        pass

    def _get_node(
        self, node_type: type[TBaseNode] | None = None
    ) -> BaseNode[Any] | TBaseNode:
        """Get node by path."""
        node: BaseNode[Any] | None = None
        match self._path_type:
            case "top":
                # Scenarios group node
                node = self._top_group
            case "absolute":
                # Group or field node absolute with named path
                node = self._find_node(self._top_group, self.parts[2:])
            case "current" if self._current_scenario_node:
                node = self._find_node(self._current_scenario_node, self.parts)
            case "scenario-id":
                node = (self._top_path / self)._get_node()
            case "item-id" if item_id := NodeId.try_parse(self.parts[0]):
                start_node = self._get_item_from_scenario_cache(item_id)
                node = self._find_node(start_node, self.parts[1:])
            case _:
                node = None

        if node is None:
            raise NodeNotFoundError(f"Node not found for {self}")

        if node_type is not None and not isinstance(node, node_type):
            req_type_name = getattr(node_type, "__name__", str(node_type))
            get_type_name = getattr(node, "__name__", str(node))
            raise TypeError(
                f"Node '{self}' is not {req_type_name} but {get_type_name}."
            )
        return node

    def _get_item_from_scenario_cache(self, item_id: NodeId):
        if self._scenario_node is None:
            raise NodeNotFoundError("Not found scenario node.")
        node = self._scenario_node[item_id]
        return node

    def _find_node(
        self, start_node: BaseNode[Any], parts: tuple[str, ...]
    ) -> BaseNode[Any]:
        """Find node by path."""
        node: BaseNode[Any] | None = start_node
        for part in parts:
            try:
                assert node is not None
                node = node[part]
            except MultipleNodesFoundError:
                raise
            except KeyError:
                node = None
                break
        if node is None:
            raise NodeNotFoundError(f"Node not found '{part}' in {self}")
        return node

    def _dispatch_event(self, event: type[NodeEventType]):
        """Dispatch node event."""
        self.get_event(event).dispatch()

    def _get_changed_style(self, other: str | None):
        """Get the same style node path."""
        if other is None:
            return None
        return self._get_same_style(other)

    def _get_same_style(self, other: PurePath | str):
        """Get the same style node path."""
        if self.is_absolute:
            return NodePath(other).absolute()
        return NodePath(other).relative()

    def __truediv__(self, key: str | PathLike[str]) -> "NodePath":
        """Join path parts and initialize node metadata."""
        return NodePath(super().__truediv__(key))

    def relative_to(self, *other: str | PathLike[str]) -> "NodePath":
        """Return a relative path with initialized node metadata."""
        return NodePath(super().relative_to(*other))

    # Judgement
    def __eq__(self, other: object) -> bool:
        """Check if the path is equal to the other path."""
        if not isinstance(other, NodePath):
            return super().__eq__(other)
        if self.exists(allow_multiple=False):
            return self.is_same(other)
        if super().is_absolute() == other.is_absolute:
            return super().__eq__(other)
        try:
            return self.absolute(True) == other.absolute(True)
        except NodeNotFoundError:
            return False

    def is_same(self, other: "NodePath"):
        """Check if the path has the same data as the other path."""
        if not isinstance(other, NodePath):
            return False
        try:
            return (
                self._scenario_node == other._scenario_node
                and self._get_node().id == other._get_node().id
            )
        except Exception:
            return False

    def exists(self, allow_multiple: bool = True):
        """Check if the node exists."""
        try:
            self._get_node()
            return True
        except NodeNotFoundError:
            return False
        except MultipleNodesFoundError:
            return allow_multiple

    @property
    def is_absolute(self):
        """Check if the node is absolute path."""
        return super().is_absolute()

    @property
    def is_top(self):
        """Check if the node is top group."""
        return self._path_type == "top"

    @property
    def is_scenario(self):
        """Check if the item node of scenario."""
        try:
            node = self._get_node(ItemNode)
            return node.is_model(Scenario)
        except (NodeNotFoundError, MultipleNodesFoundError, TypeError):
            return False

    @property
    def is_group(self):
        """Check if the node is a group."""
        try:
            self._get_node(GroupNode)
            return True
        except (NodeNotFoundError, MultipleNodesFoundError, TypeError):
            return False

    @property
    def is_item(self):
        """Check if the node is a item."""
        try:
            self._get_node(ItemNode)
            return True
        except (NodeNotFoundError, MultipleNodesFoundError, TypeError):
            return False

    @property
    def is_field(self):
        """Check if the node is a field."""
        try:
            self._get_node(FieldNode)
            return True
        except (NodeNotFoundError, MultipleNodesFoundError, TypeError):
            return False

    # Path operations and properties
    def absolute(self, strict: bool = False) -> "NodePath":
        """Get absolute path."""
        match self._path_type:
            case "invalid" if strict:
                raise NodeNotFoundError(f"Failed to absolute for {self}")
            case "invalid":
                return self
            case "top" | "absolute":
                return self
            case "scenario-id":
                return self._top_path / self
            case "item-id" if (scenario_id := ScenarioId.try_parse(self.parts[0])) and (
                node := self._get_item_from_scenario_cache(scenario_id)
            ):
                return NodePath(node.path).parent / self
            case "item-id" if strict:
                raise NodeNotFoundError(f"Item node id not found: {self}")
            case "item-id":
                return self
            case "current" if self._current_scenario_node:
                return NodePath(
                    "/", ScenarioGroup.NAME, self._current_scenario_node.id, *self.parts
                )
            case "current" if strict:
                raise NodeNotFoundError(f"Not selected scenario: {self}")
            case "current":
                return self
            case _:
                raise RuntimeError(f"Invalid path type {self._path_type}: {self}")

    def resolve(self, strict: bool = False):
        """Get resolve to id path."""
        try:
            node = self._get_node()
            return NodePath(node.path)
        except Exception:
            if strict:
                raise
            return self

    def relative(self, strict: bool = False):
        """Get relative path from current."""
        try:
            id_path = self.resolve(strict=True)
        except Exception:
            if strict:
                raise
            return self

        if self._scenario_node is None:
            # Not part of scenario data
            if strict:
                raise InvalidNodeOperation(f"Not part of scenario data: {self}")
            return self

        try:
            if self._top_group.current_id == self._scenario_node.id:
                # relative to current scenario
                return id_path.relative_to(self._scenario_node.path)
            # relative to scenarios group
            return id_path.relative_to(self._top_path)
        except Exception as e:
            log.exception(f"Failed to get relative path: {self}\n{e}")
            return self

    @property
    def parent(self):
        """Get node parent path."""
        match self._path_type:
            case "top":
                return self
            case "scenario-id" if len(self.parts) == 1:
                return self._top_path
            case "current" if len(self.parts) == 0:
                return self._top_path
            case "item-id" if len(self.parts) == 1:
                # return parent group path of top item id
                return self.resolve().parent
            case _:
                return NodePath(super().parent)

    @property
    def scenario_id(self) -> ScenarioId:
        """Get scenario node id."""
        if node := self._scenario_node:
            return node.scenario_id
        return ScenarioId(UNSET_UUID)

    @property
    def _scenario_node(self):
        """Get scenario node."""
        try:
            match self._scenario_name:
                case None:
                    return None
                case "":
                    return self._top_group.current_node
                case _:
                    return self._top_group[self._scenario_name]
        except (KeyError, NodeNotFoundError, MultipleNodesFoundError):
            return None

    @property
    def _current_scenario_node(self):
        """Get scenario path."""
        return self._top_group.current_node

    @property
    def child_count(self):
        """Get number of child nodes."""
        try:
            node = self._get_node()
            return node.child_count
        except Exception:
            return 0

    @property
    def index(self):
        """Get index of node in group."""
        try:
            node = self._get_node()
            return node.index
        except Exception:
            return None

    @property
    def id(self):
        """Get node data id."""
        try:
            node = self._get_node()
            return node.id
        except Exception:
            return NodeId()

    @property
    def name(self):
        """Get node data name."""
        try:
            node = self._get_node()
            return node.name
        except Exception:
            return ""

    @property
    def named(self):
        """Get node full named path."""
        try:
            node = self._get_node()
            return node.full_name
        except Exception:
            return ""

    @property
    def node_type(self) -> NodeType:
        """Get node type."""
        try:
            node = self._get_node()
            match node:
                case ScenarioGroup():
                    return "top"
                case ItemNode() if node.is_model(Scenario):
                    return "scenario"
                case ItemNode():
                    return "item"
                case GroupNode():
                    return "group"
                case FieldNode():
                    return "field"
                case _:
                    return "(unknown)"
        except NodeNotFoundError:
            return "(non-existent)"
        except MultipleNodesFoundError:
            return "(unknown)"
        except Exception:
            return "(unknown)"

    @property
    def field_names(self) -> tuple[str, ...]:
        """Field names of the node."""
        node = self._get_node()
        return tuple(field.name for field in node.iter_fields())

    @property
    def group_names(self) -> tuple[str, ...]:
        """Group names of the nodes."""
        node = self._get_node()
        return tuple(
            child.name for child in node.iter_children() if isinstance(child, GroupNode)
        )

    # Set something to the node
    def patch(self, data: PatchModel):
        """Patch node data with model data."""
        node = self._get_node()
        changed = node.patch(data)
        common_path = changed.dispatch_events()
        return self._get_changed_style(common_path)

    def set_field_value(self, value: FieldModel | Any):
        """Set field value to the field node."""
        node = self._get_node()
        if not isinstance(node, FieldNode):
            raise InvalidNodeOperation(f"This is not field node: {self}")
        changed = node.set_value(value)
        common_path = changed.dispatch_events()
        return self._get_changed_style(common_path)

    def sync_json(self, json: str):
        """Synchronize json data with the node."""
        node = self._get_node()
        data = node.convert_to_model(json)
        return self.sync_data(data)

    def sync_data(self, data: NodeModelType):
        """Patch partial node data to the node."""
        node = self._get_node()
        changed = node.sync(data)
        common_path = changed.dispatch_events()
        return self._get_changed_style(common_path)

    def append(self, data: ItemModel):
        """Append a item node data to the group node."""
        node = self._get_node()
        if not isinstance(node, ChildNodeOperations):
            raise InvalidNodeOperation(f"This node cannot append child: {self}")
        child_node = cast(ChildNodeOperations[ItemModel], node)
        model = child_node.get_child_model()
        if not isinstance(data, model):
            raise TypeError(f"Invalid data type {type(data)} to append to {self}.")
        if self.is_top and isinstance(data, Scenario):
            return self.append_scenario(data)
        copied = deepcopy(data)
        item, changed = child_node.append_child(copied)
        changed.dispatch_events()
        item_path = NodePath(item.path)
        return self._get_same_style(item_path)

    def remove(self) -> None:
        """Remove the item node from the parent group node."""
        node = self._get_node()
        if self.is_item:
            # Dispatch delete event before removing the node
            self._dispatch_event(DeleteNodeEvent)
        changed = node.remove()
        # Removed is already dispatched in the node
        changed.removed = []
        changed.dispatch_events()

    def clear(self) -> None:
        """Initialize all child data of the node."""
        node = self._get_node()
        changed = node.clear()
        changed.dispatch_events()

    # Get something from the node
    def dump_json(self, indent: int | None = 2) -> str:
        """Dump data as json from the node."""
        node = self._get_node()
        return node.dump_json(indent=indent)

    def get_model(self):
        """Get the model type of the node."""
        node = self._get_node()
        return node.model

    def get_patch_model(self) -> type[PatchModel]:
        """Get the patch model type of the node."""
        node = self._get_node()
        return type(node.get_patch())

    def get_child_model(self) -> type[ItemModel]:
        """Get the model type of the child node."""
        node = self._get_node()
        if not isinstance(node, ChildNodeOperations):
            raise InvalidNodeOperation(f"This node does not have child model: {self}")
        return cast(ChildNodeOperations[ItemModel], node).get_child_model()

    def get_referrers(self, include_subtree: bool = False) -> "list[NodePath]":
        """Get a nodes list that referrers to the node as item link."""
        node = self._get_node(ItemNode)
        return [
            NodePath(referrer.path)
            for referrer in node.item_map.get_referrers(node, include_subtree)
        ]

    def get_link(self):
        """Get the link to the node."""
        node = self._get_node()
        return node.get_link()

    @overload
    def get_copied_data(self, model: None = None) -> NodeModelType:
        pass

    @overload
    def get_copied_data(self, model: type[TNodeModelType]) -> TNodeModelType:
        pass

    def get_copied_data(
        self, model: type[TNodeModelType] | None = None
    ) -> TNodeModelType | NodeDataModel:
        """Get the copied data with new ids for all descendant nodes from the node."""
        node = self._get_node()
        if model is not None and not is_subclass_of_model(node.model, model):
            raise TypeError(
                f"Data type of {self} is '{self.get_model()}' but specified {model}."
            )
        return node.get_copied_data()

    @overload
    def get_data(self, model: None = None) -> NodeModelType:
        pass

    @overload
    def get_data(self, model: type[TNodeModelType]) -> TNodeModelType:
        pass

    def get_data(
        self, model: type[TNodeModelType] | None = None
    ) -> TNodeModelType | NodeDataModel:
        """Get the data for the node and all descendant nodes."""
        node = self._get_node()
        if model is not None and not is_subclass_of_model(node.model, model):
            raise TypeError(
                f"Data type of {self} is '{self.get_model()}' but specified {model}."
            )
        return deepcopy(node.data)

    @overload
    def get_patch(self, model: None = None, **kwargs) -> PatchModel:
        pass

    @overload
    def get_patch(self, model: type[TPatchModel], **kwargs) -> TPatchModel:
        pass

    def get_patch(
        self, model: type[TPatchModel] | None = None, **kwargs
    ) -> TPatchModel | PatchModel:
        """Get the patch data for the node and all descendant nodes."""
        node = self._get_node()
        patch = node.get_patch(**kwargs)
        if model and not isinstance(patch, model):
            raise TypeError(
                f"Invalid patch type {model} is specified for {self}: {type(patch)}"
            )
        return patch

    def get_source(self):
        """Get the source info of the scenario data."""
        node = self._get_node()
        return node.scenario_source

    def iter_child_ids(self) -> Iterator["NodeId"]:
        """Iterate the child nodes."""
        node = self._get_node()
        return iter(child.id for child in node.iter_children())

    def get_group_counts(self) -> dict[GroupName, int]:
        """Get the number of child nodes of each group in the node."""
        node = self._get_node()
        return {
            group.name: group.child_count
            for group in node.iter_children()
            if isinstance(group, GroupNode) and is_group_name(group.name)
        }

    def get_event(self, event: type[NodeEventType]) -> NodeEventType:
        """Get event object for the path."""
        return event(source=str(self.resolve()))

    # Scenario operations
    @classmethod
    def load_scenario(cls, file: Path | str):
        """Load scenario data from file."""
        file = Path(file)
        if not file.exists() or not file.is_file():
            raise FileNotFoundError(f"Scenario data file is not found: {file}")
        json_data = file.read_text(encoding="utf-8", errors="ignore")
        source = str(file.resolve())
        data = Scenario.model_validate_json(json_data)
        return cls.append_scenario(data, source)

    @classmethod
    def append_scenario(cls, data: Scenario, source: str = ""):
        """Append scenario data."""
        copied = Scenario(**data.dump())
        scenario, changed = NodePath()._top_group.append_child(copied, source=source)
        changed.dispatch_events()
        return NodePath(scenario.path)

    @classmethod
    def get_scenario_ids(cls):
        """Get tuple of scenario ids."""
        return tuple(
            scenario.scenario_id for scenario in NodePath()._top_group.iter_children()
        )

    @classmethod
    def clear_scenarios(cls):
        """Clear all scenarios."""
        top_group = cls._get_top_path()
        top_group._top_group.clear_scenarios()

    def select_scenario(self):
        """Select node as current scenario data."""
        node = self._get_node()
        if node.model != Scenario:
            raise InvalidNodeOperation(f"{self} does not have scenario id.")
        current_node = self._top_group.select_scenario(self.scenario_id)
        assert current_node is not None
        return NodePath(current_node.path)

    def __repr__(self):
        """Get string representation of node path."""
        if self.named and str(self) != self.named:
            return f"NodePath({self} - {self.named})"
        return super().__repr__()

    def __hash__(self):
        """Get hash value."""
        try:
            node = self._get_node()
            return hash(node.path)
        except (NodeNotFoundError, MultipleNodesFoundError):
            return super().__hash__()
