from uuid import UUID
from typing import Any

from pydantic_core import core_schema
from pydantic import (
    GetCoreSchemaHandler,
    GetJsonSchemaHandler,
)
from pydantic.json_schema import JsonSchemaValue

from sidera.scenario.models import UNSET_UUID


class NodeId(str):
    """The node id string.
    The node id is a UUID string prefixed with '~' or a path as str.
    The path is a string with the format of '~{uuid}/{field}'."""

    def __new__(cls, value: str | UUID = UNSET_UUID):
        if isinstance(value, UUID):
            formatted = f"~{value}"
        elif isinstance(value, str):
            id_str, _, field = value.partition("/")
            try:
                uuid = UUID(id_str[1:]) if id_str.startswith("~") else UUID(id_str)
            except Exception:
                raise ValueError(f"{cls.__name__} must be str or UUID.")
            formatted = f"~{uuid}/{field}" if field else f"~{uuid}"
        else:
            raise TypeError(f"{cls.__name__} must be str or UUID.")
        return super().__new__(cls, formatted)

    @classmethod
    def __get_pydantic_core_schema__(
        cls, source_type: Any, handler: GetCoreSchemaHandler
    ) -> core_schema.CoreSchema:
        return core_schema.no_info_plain_validator_function(cls._validate)

    @classmethod
    def __get_pydantic_json_schema__(
        cls, core_schema: core_schema.CoreSchema, handler: GetJsonSchemaHandler
    ) -> JsonSchemaValue:
        """Return the json schema as the string type."""
        return {
            "type": "string",
            "title": "Node ID",
            "description": """The node id string.
                The node id is a UUID string prefixed with '~' or a path as str.
                The path is a string with the format of '~{uuid}/{field}'.""",
            "examples": [
                "~123e4567-e89b-12d3-a456-426614174000",
                "~123e4567-e89b-12d3-a456-426614174000/field",
            ],
        }

    @classmethod
    def _validate(cls, value: str) -> "NodeId":
        return cls(value)

    @property
    def id(self):
        """Get the id part of."""
        return self.partition("/")[0]

    @property
    def field(self):
        """Get the field parts."""
        return self.partition("/")[2]

    @property
    def uuid(self):
        """Get the uuid of node id."""
        return UUID(self[1:].partition("/")[0])

    @classmethod
    def try_parse(cls, value: str):
        """Create a node id from a string."""
        try:
            return cls(value)
        except ValueError:
            return None

    def with_field(self, field: str):
        """Get a new node id with the field."""
        return type(self)(f"{self.id}/{field}")

    def __bool__(self):
        """Check if the node id is valid."""
        return self.uuid != UNSET_UUID


class ScenarioId(NodeId):
    """Scenario id is set automatically.
    The scenario id is a UUID string prefixed with '~' as str.
    The scenario is  path accepts item id or name for items.
    """

    def __new__(cls, value: str | UUID = UNSET_UUID):
        node_id = super().__new__(cls, value)
        if node_id.field:
            raise ValueError(
                f"Scenario ID cannot have field string: '.../{node_id.field}'."
            )
        return node_id

    @classmethod
    def __get_pydantic_json_schema__(
        cls, core_schema: core_schema.CoreSchema, handler: GetJsonSchemaHandler
    ) -> JsonSchemaValue:
        """Return the json schema as the string type."""
        return {
            "type": "string",
            "title": "Scenario ID",
            "description": """The scenario id string.
                The scenario id is a UUID string prefixed with '~'.
                This value is automatically created by the server.""",
            "examples": [
                "~6aed83bc-d18d-48af-9263-0415c187500f",
            ],
        }
