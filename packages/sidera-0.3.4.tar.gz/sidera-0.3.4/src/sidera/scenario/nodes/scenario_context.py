from dataclasses import dataclass

from sidera.scenario.models import UNSET_UUID

from .item_map import ItemMap
from .node_id import ScenarioId


@dataclass(frozen=True)
class ScenarioContext:
    """Context for scenario node."""

    id: ScenarioId
    item_map: ItemMap
    source: str = ""

    @classmethod
    def get_empty(cls):
        """Get empty scenario context."""
        unset_scenario_id = ScenarioId(UNSET_UUID)
        return cls(
            id=unset_scenario_id,
            item_map=ItemMap(unset_scenario_id),
            source="",
        )

    def empty(self) -> bool:
        """Check if scenario context is empty."""
        return self.id == ScenarioId(UNSET_UUID)
