from abc import ABC
from collections.abc import Callable, Iterator
from pathlib import PurePath
from typing import (
    Any,
    Generic,
    Protocol,
    TypeAlias,
    TypeGuard,
    TypeVar,
    cast,
    runtime_checkable,
)
from uuid import UUID

from sidera.exceptions import (
    InvalidNodeOperation,
    MultipleNodesFoundError,
)
from sidera.scenario.models import (
    FieldModel,
    ItemLink,
    ItemModel,
    ModelGroup,
    PatchModel,
)
from sidera.scenario.models.items.type_checkers import (
    is_item_model,
    is_subclass_of_model,
)

from .changed_paths import ChangedPaths
from .item_map import ItemMap
from .node_id import NodeId, ScenarioId
from .scenario_context import ScenarioContext

NodeDataModel: TypeAlias = ItemModel | FieldModel
NodeModelType: TypeAlias = ItemModel | FieldModel | ModelGroup
T = TypeVar("T")
TItemModel = TypeVar("TItemModel", bound=ItemModel)


class BaseNode(ABC, Generic[T]):
    """Base class for scenario node."""

    _name: str
    _full_name: PurePath
    _path: PurePath
    _parent: "BaseNode"
    _model: type[T]
    _data_source: T | Callable[[], T]
    _scenario_context: ScenarioContext = ScenarioContext.get_empty()

    def __init__(
        self,
        name: str,
        model: type[T],
        data: T | Callable[[], T],
        parent: "BaseNode",
    ):
        self._name = name
        self._data_source = data
        self._parent = parent
        self._model = model
        if parent is self:
            # top node has defined _path and _named_path.
            pass
        else:
            self._full_name = parent._full_name / name
            self._path = parent._path / (self.id.field or self.id)
            if self._scenario_context.empty():
                self._scenario_context = parent._scenario_context

    def matches(self, key: str) -> bool:
        """Check if node is same as given pattern."""
        if key.isdigit():
            # Check if key is index
            return self.index == int(key)
        return key in (self.id, self.name)

    def iter_children(self) -> Iterator["BaseNode"]:
        """Get iterator over child nodes."""
        return iter(())

    def get_child_node(self, key: str) -> "BaseNode | None":
        """Get child node by name, id or index."""
        matches = (node for node in self.iter_children() if node.matches(key))
        node = next(matches, None)
        if node is None:
            return None
        if next(matches, None) is not None:
            raise MultipleNodesFoundError(f"{self} has multiple nodes named '{key}'.")
        return node

    def has_child_node(self, key: str) -> bool:
        """Check if node contains child node.
        Note:
            This method accepts multiple nodes with same name.
        """
        return bool(
            next((node for node in self.iter_children() if node.matches(key)), None)
        )

    def iter_fields(self) -> Iterator["BaseNode"]:
        """Get iterator over fields nodes."""
        return iter(())

    def get_field(self, name: str) -> "BaseNode | None":
        """Get field nodes."""
        return None

    def get_link(self) -> ItemLink:
        """Get link to the node."""
        raise InvalidNodeOperation(f"{self.class_name} cannot get_link: {self}")

    def get_copied_data(self):
        """Get deep copied data of the node."""
        raise InvalidNodeOperation(f"{self.class_name} cannot get_copied_data: {self}")

    def get_patch(self, **kwargs):
        """Get copied patch data of the node."""
        if is_item_model(self.data):
            return self.data.get_patch(**kwargs)
        raise InvalidNodeOperation(f"{self.class_name} cannot patch: {self}")

    def dump_json(self, indent: int | None = 2) -> str:
        """Dump node data to json."""
        raise InvalidNodeOperation(f"{self.class_name} cannot dump_json: {self}")

    def patch(self, patch_data: PatchModel) -> ChangedPaths:
        """Update node data with partial data."""
        raise InvalidNodeOperation(f"{self.class_name} cannot update: {self}")

    def _get_updated_path(self, paths: set[str]) -> str:
        """Get updated path from set of paths."""
        paths.discard("")
        if len(paths) == 0:
            # No children updated
            return ""
        elif len(paths) > 1:
            # Multiple children updated
            return self.path
        # Single child updated
        return paths.pop()

    def convert_to_model(self, data: Any) -> T:
        """Convert data to model."""
        raise InvalidNodeOperation(f"{self.class_name} cannot convert to model: {self}")

    def sync(self, sync_data: T) -> ChangedPaths:
        """Sync node data.
        Returns:
            ChangedPaths: changed node paths of sync operation.
        """
        raise InvalidNodeOperation(f"{self.class_name} cannot sync: {self}")

    def clear(self) -> ChangedPaths:
        """Clear data and all children data.
        Returns:
            int: Number of children cleared.
        """
        raise InvalidNodeOperation(f"{self.class_name} cannot clear: {self}")

    def remove(self) -> ChangedPaths:
        """Remove node from parent node."""
        raise InvalidNodeOperation(f"{self.class_name} cannot remove: {self}")

    def is_model(self, model: type[NodeModelType] | type[ModelGroup]) -> bool:
        """Check if node is of model type."""
        return is_subclass_of_model(self.model, model)

    def _rename_children(self):
        """Rename subtree nodes."""
        for child in self.iter_children():
            child._full_name = self._full_name / child.name
            child._rename_children()
        for field in self.iter_fields():
            field._full_name = self._full_name / field.name

    @classmethod
    def is_type(cls, node: object, model: type[Any]) -> TypeGuard["BaseNode[Any]"]:
        """Check if node is of ItemNode type."""
        return isinstance(node, cls) and (
            model is Any or issubclass(model, node._generic_type)
        )

    @classmethod
    def load_data(cls, dump: Any) -> T:
        """Load dump data and return node data."""
        return dump

    @property
    def data(self) -> T:
        """Data of the node."""
        if callable(self._data_source):
            data_source = cast(Callable[[], T], self._data_source)
            return data_source()
        return self._data_source

    @property
    def model(self) -> type[T]:
        """Model type of the node with type annotation."""
        return self._model

    @property
    def _generic_type(self) -> type[Any]:
        """Return model of generic type."""
        return self._model

    @property
    def class_name(self) -> str:
        """Model name of the node."""
        return f"{self.__class__.__name__}[{self._model.__name__}]"

    @property
    def id(self) -> NodeId:
        """Id of node like "~00000000-0000-..." format."""
        raise NotImplementedError(
            f"{self.__class__.__name__} does not have id: {self._model.__name__}"
        )

    @property
    def uuid(self) -> UUID | None:
        """UUID of node data."""
        return self.id.uuid

    @property
    def index(self) -> int | None:
        """Index of node in parent."""
        return None

    @property
    def name(self) -> str:
        """Name of node."""
        return self._name

    @property
    def full_name(self) -> str:
        """Return full named path of the node."""
        return str(self._full_name)

    @property
    def relative_name(self) -> str:
        """Return relative named path from scenario node."""
        if len(self._full_name.parts) < 4:
            return ""
        return str(PurePath(*self._full_name.parts[3:]))

    @property
    def path(self) -> str:
        """Return id path of the node."""
        return str(self._path)

    @property
    def parent(self) -> "BaseNode":
        """Get parent node."""
        return self._parent

    @property
    def scenario_source(self) -> str:
        """Get scenario source info."""
        return self._scenario_context.source

    @property
    def scenario_id(self) -> ScenarioId:
        """Get scenario id."""
        return self._scenario_context.id

    @property
    def item_map(self) -> ItemMap:
        """Get scenario id."""
        return self._scenario_context.item_map

    @property
    def child_count(self) -> int:
        """Get number of children."""
        return 0

    def __eq__(self, other: Any):
        if not isinstance(other, BaseNode):
            return False
        return self.id == other.id and isinstance(other, self.__class__)

    def __hash__(self):
        return hash((self.id, self.__class__))

    def __getitem__(self, key: "BaseNode | NodeId | str | int"):
        """Get child node by index."""
        if isinstance(key, int):
            key = str(key)
        elif isinstance(key, BaseNode):
            key = key.id

        # Get from item map
        if isinstance(key, NodeId) and self.item_map:
            node = self.item_map.get_node(key.uuid)
            return node[key.field] if key.field else node

        # Get from fields
        if field := self.get_field(key):
            return field

        # Find child node by name or id
        child = self.get_child_node(key)
        if child is None:
            raise KeyError(f"'{key}' is not in {self}")
        return child

    def __contains__(self, item: "BaseNode | NodeId | str | int") -> bool:
        """Check if node contains child node."""
        if isinstance(item, int):
            item = str(item)
        elif isinstance(item, BaseNode):
            item = item.id
        return self.has_child_node(item) or self.get_field(item) is not None

    def __str__(self) -> str:
        return f"{self.class_name}<{self.full_name}>"

    def __repr__(self) -> str:
        return f"{self.__str__()[:-1]}:{self.path}>"


@runtime_checkable
class ChildNodeOperations(Protocol[TItemModel]):
    """Protocol for nodes that can operate on item child nodes."""

    def append_child(
        self, data: TItemModel
    ) -> "tuple[BaseNode[TItemModel], ChangedPaths]":
        """Add item data as a child node."""
        ...

    def remove_child(self, data: TItemModel) -> ChangedPaths:
        """Remove item data from child nodes."""
        ...

    def get_child_model(self) -> type[TItemModel]:
        """Return child item model."""
        ...
