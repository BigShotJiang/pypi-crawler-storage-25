from json import loads as json_loads
from typing import (
    TYPE_CHECKING,
    Any,
    Generic,
    Iterator,
    TypeGuard,
    TypeVar,
    cast,
    get_args,
    get_origin,
)
from uuid import UUID

from sidera.exceptions import InvalidNodeOperation
from sidera.scenario.models import FieldModel, ItemLink, ItemModel, PatchModel
from sidera.utils.field_key import normalize_field_name

from .base_node import BaseNode
from .changed_paths import ChangedPaths
from .node_id import NodeId
from .scenario_context import ScenarioContext

if TYPE_CHECKING:
    from .field_node import FieldNode
    from .group_node import GroupNode

T = TypeVar("T", bound=ItemModel)
U = TypeVar("U", bound=ItemModel)


class ItemNode(BaseNode[T], Generic[T]):
    """Node for a single item of DataModel."""

    _id_as_path: bool = True
    _parent: "GroupNode"
    _groups: "list[GroupNode]"
    _fields: "dict[str, FieldNode]"
    _patch_model: type[PatchModel]

    def __init__(
        self,
        name: str,
        model: type[T],
        data: T,
        parent: "GroupNode",
        context: ScenarioContext | None = None,
    ):
        if context is not None:
            # Set the scenario context for the scenario item node
            self._scenario_context = context
        super().__init__(name, model, data, parent)
        self._groups = []
        self._fields = {}
        self._setup_child_nodes()
        self._patch_model = self._model.get_patch_model()

    def _setup_child_nodes(self):
        """Create group node list from DataModel object."""
        from .field_node import FieldNode
        from .group_node import GroupNode

        for field_name, field_info in self.data.model_fields.items():
            field_model = field_info.annotation
            assert field_model is not None  # for type checker
            if field_name == "id":
                continue
            if get_origin(field_model) is list and issubclass(
                get_args(field_model)[0], ItemModel
            ):
                data = getattr(self.data, field_name)
                self._groups.append(GroupNode(field_name, field_model, data, self))
            else:

                def _get_field_data(name=field_name) -> FieldModel:
                    """Closure to get field data."""
                    return getattr(self.data, name)

                self._fields[field_name] = FieldNode(
                    field_name, field_model, _get_field_data, self
                )

    def iter_children(self) -> "Iterator[GroupNode]":
        """Iterate over child groups."""
        return iter(self._groups)

    def iter_fields(self) -> Iterator["FieldNode"]:
        """Get iterator over fields nodes."""
        return iter(self._fields.values())

    def get_field(self, name: str) -> "FieldNode | None":
        """Get field nodes."""
        return self._fields.get(normalize_field_name(name))

    def dump_json(self, indent: int | None = 2) -> str:
        """Dump node data to json."""
        return self.data.dump_json(indent=indent)

    def patch(self, patch_data: PatchModel) -> ChangedPaths:
        """Update node data with partial data."""
        old_name = self.name
        changed = self._patch(patch_data)
        if (changed and any(field.has_link for field in self._fields.values())) or (
            old_name != self.name
        ):
            changed &= self.item_map.validate_links()
        return changed

    def _patch(self, patch_data: PatchModel) -> ChangedPaths:
        """Update node data with partial data internal process."""
        updated_fields = self.data.patch(patch_data)
        if self.name != self._full_name.name:
            # Update full_name because of rename
            self._full_name = self._full_name.with_name(self.name)
            self._rename_children()
        changed = ChangedPaths()
        for field_name in updated_fields:
            changed |= f"{self.path}/{field_name}"
        return changed

    def sync(self, sync_data: T) -> ChangedPaths:
        """Update node data."""
        changed = self._sync(sync_data)
        if changed:
            changed &= self.item_map.validate_links()
        return changed

    def _sync(self, sync_data: T) -> ChangedPaths:
        """Update node data internal process."""
        if not isinstance(sync_data, self._model):
            raise TypeError(f"Invalid data model type to sync {self}: {self._model}")
        changed = self._sync_child_groups(sync_data)
        patch = sync_data.get_patch()
        changed &= self._patch(patch)
        return changed

    def _sync_child_groups(self, sync_data: T) -> ChangedPaths:
        """Sync child groups."""
        changed = ChangedPaths()
        for group in self._groups:
            group_data = getattr(sync_data, group.name)
            changed &= group._sync(group_data)
        return changed

    def convert_to_model(self, data: Any) -> T:
        """Convert data to model."""
        if isinstance(data, self._model):
            return data
        if isinstance(data, self.patch_model):
            return cast(T, self._model.model_validate(self.data.patch(data)))
        if isinstance(data, dict):
            return cast(T, self._model.model_validate(data))
        if isinstance(data, str):
            try:
                json = json_loads(data)
                return cast(T, self._model.model_validate(json))
            except Exception:
                pass
        raise TypeError(f"Invalid data type to convert for {self}")

    def remove(self):
        """Remove node from parent."""
        return self._parent.remove_child(self.data)

    def get_copied_data(self):
        """Get deep copied data of the node."""
        return self.data.copy()

    def clear(self):
        """Clear all data from child groups."""
        changed = ChangedPaths()
        for field in self.iter_fields():
            if field.name == "id":
                # Skip id field
                continue
            try:
                changed &= field.clear()
            except InvalidNodeOperation:
                # Skip if field cannot be cleared
                pass
        for group in self.iter_children():
            changed = group.clear()
        # Links have already been verified at the group and file levels.
        # Integrate changes to the item node.
        return ChangedPaths(updated=[self.path]) if changed else changed

    def get_link(self) -> ItemLink:
        """Get link to the node."""
        return ItemLink(self.id, path=self.relative_name)

    @classmethod
    def is_type(cls, node: object, model: type[U]) -> TypeGuard["ItemNode[U]"]:
        """Check if node is of ItemNode type."""
        return super().is_type(node, model)

    @property
    def id(self) -> NodeId:
        """Id of node like "~00000000-0000-..." format."""
        self_id = getattr(self.data, "id", None)
        if self_id is None or not isinstance(self_id, UUID):
            raise TypeError(f"Invalid id type for {self}: {type(self_id)}")
        return NodeId(self_id)

    @property
    def patch_model(self) -> type[PatchModel]:
        """patch model type of the node with type annotation."""
        return self._patch_model

    @property
    def child_count(self) -> int:
        """Return number of child groups."""
        return len(self._groups)

    @property
    def index(self) -> int:
        """Get index of node in group."""
        return self._parent.data.index(self.data)

    @property
    def name(self) -> str:
        """Name of the node."""
        return self.data.get_name()
