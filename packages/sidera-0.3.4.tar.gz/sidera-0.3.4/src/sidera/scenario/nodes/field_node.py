from copy import deepcopy
from json import dumps as json_dumps
from json import loads as json_loads
from typing import TYPE_CHECKING, Any, Callable, Generic, TypeGuard, TypeVar, cast

from pydantic import BaseModel
from pydantic.fields import FieldInfo
from pydantic_core import PydanticUndefined

from sidera.exceptions import InvalidNodeOperation
from sidera.scenario.models import FieldModel, ItemLink, ItemModel

from .base_node import BaseNode
from .changed_paths import ChangedPaths
from .node_id import NodeId

if TYPE_CHECKING:
    from .item_node import ItemNode

T = TypeVar("T", bound=FieldModel)
U = TypeVar("U", bound=FieldModel)


class FieldNode(BaseNode[T], Generic[T]):
    """Node for a group of DataModel items."""

    _parent: "ItemNode"
    _field_info: FieldInfo
    _data_source: Callable[[], T]

    def __init__(
        self, name: str, model: type, data: Callable[[], T], parent: "ItemNode"
    ):
        super().__init__(name, model, data, parent)

        self._parent_data: ItemModel = self._parent.data
        parent_model = self._parent.model
        assert issubclass(parent_model, ItemModel)
        self._field_info = parent_model.model_fields[self.name]
        self._has_link = next(self._collect_link(self.data), None) is not None

    def iter_link(self):
        """Get list of item links."""
        if self._has_link:
            yield from self._collect_link(self.data)

    def _collect_link(self, data: Any):
        """Check if the field has link."""
        if isinstance(data, ItemLink):
            yield data
        if isinstance(data, BaseModel):
            for field_name in type(data).model_fields:
                if field_name.startswith("_"):
                    continue
                field_data = getattr(data, field_name)
                yield from self._collect_link(field_data)

    def dump_json(self, indent: int | None = 2) -> str:
        """Dump node data to json."""
        if isinstance(self.data, BaseModel):
            return self.data.model_dump_json(indent=indent)
        return json_dumps(self.data, indent=indent, default=str)

    def set_value(self, set_data: Any):
        """Update filed data."""
        changed = ChangedPaths()
        model_data = self.convert_to_model(set_data)
        if self.data == model_data:
            # No change
            return changed
        if model_data is None:
            setattr(self._parent_data, self.name, model_data)
            changed |= str(self.path)
        changed &= self._update_field_values(model_data)
        if self.has_link:
            # Update link data
            changed &= self.item_map.validate_links()
        return changed

    def _update_field_values(self, model_data):
        """Update all parent field values with self value."""
        changed = ChangedPaths()
        patch_data = self._parent_data.get_patch(**{self.name: model_data})
        for field_name in patch_data.model_dump(exclude_none=True):
            old_data = getattr(self._parent_data, field_name)
            new_data = getattr(patch_data, field_name)
            if old_data != new_data:
                # Update field data
                setattr(self._parent_data, field_name, new_data)
                changed |= str(self._path.parent / field_name)
        return changed

    def convert_to_model(self, data: Any) -> T:
        """Convert data to model."""
        if data is None:
            return cast(T, data)
        if isinstance(data, self._model):
            return data
        if isinstance(data, str):
            try:
                data = json_loads(data)
            except Exception:
                pass
        if isinstance(self.data, BaseModel) and isinstance(data, dict):
            return self.data.model_validate(data)
        return self._model(data)  # type: ignore

    def get_copied_data(self):
        """Get deep copied data of the node."""
        return deepcopy(self.data)

    def clear(self):
        """Clear all data from list."""
        if self._field_info.default_factory is not None:
            # TODO: type ignore to avoid linker warning
            init_data = self._field_info.default_factory()  # type: ignore
        elif self._field_info.default is PydanticUndefined:
            raise InvalidNodeOperation(
                f"{self}' has no default value or default factory."
            )
        else:
            init_data = self._field_info.default
        return self.set_value(init_data)

    @classmethod
    def is_type(cls, node: object, model: type[U]) -> TypeGuard["FieldNode[U]"]:
        """Check if node is of ItemNode type."""
        return super().is_type(node, model)

    @property
    def id(self) -> NodeId:
        """Id of node like "~00000000-0000-..." format."""
        return NodeId(self._parent.id).with_field(self._name)

    @property
    def has_link(self):
        """Return list of item links."""
        return self._has_link
