from os.path import commonpath

from pydantic import BaseModel

from sidera.scenario.node_event import (
    CreateNodeEvent,
    DeleteNodeEvent,
    UpdateNodeEvent,
)


class ChangedPaths(BaseModel):
    """Result of node operations."""

    removed: list[str] = []
    updated: list[str] = []
    appended: list[str] = []

    def _remove_redundant_updates(self):
        """Remove redundant updates"""
        self.updated = list(
            dict.fromkeys(
                path
                for path in self.updated
                if path not in self.removed and path not in self.appended
            )
        )

    def __iand__(self, other: "ChangedPaths"):
        """Extend other ChangedPaths values to this."""
        self.removed.extend(other.removed)
        self.updated.extend(other.updated)
        self.appended.extend(other.appended)
        self._remove_redundant_updates()
        return self

    def __isub__(self, other: str):
        """Append removed change path to this."""
        self.removed.append(other)
        self._remove_redundant_updates()
        return self

    def __ior__(self, other: str):
        """Append updated change path to this."""
        self.updated.append(other)
        self._remove_redundant_updates()
        return self

    def __iadd__(self, other: str):
        """Append appended change path to this."""
        self.appended.append(other)
        self._remove_redundant_updates()
        return self

    def __str__(self) -> str:
        return f"SyncResult(removed: {len(self.removed)}, updated: {len(self.updated)}, appended: {len(self.appended)})"

    def __repr__(self) -> str:
        paths = self.__str__()
        if self.removed:
            paths += f"\nRemoved: {chr(10).join(self.removed)}"
        if self.updated:
            paths += f"\nUpdated: {chr(10).join(self.updated)}"
        if self.appended:
            paths += f"\nAppended: {chr(10).join(self.appended)}"
        return paths

    def __bool__(self) -> bool:
        return bool(self.removed or self.updated or self.appended)

    def get_all(self) -> list[str]:
        """Get all changed paths."""
        return self.removed + self.updated + self.appended

    def dispatch_events(self):
        """Dispatch events for all changed paths."""

        for path in self.removed:
            DeleteNodeEvent(source=path).dispatch()
        for path in self.appended:
            CreateNodeEvent(source=path).dispatch()
        for path in self.updated:
            UpdateNodeEvent(source=path).dispatch()
        paths = self.get_all()
        if paths:
            return commonpath(paths)

        return None
