from abc import ABC, abstractmethod
from pydantic import BaseModel, ConfigDict, model_serializer, model_validator
from pydantic.alias_generators import to_camel
from typing import Any

from sidera.utils.field_key import to_underscore_keys


class BaseFunctionModel(BaseModel, ABC):
    """Base function model of signal."""

    model_config = ConfigDict(
        extra="allow", strict=False, alias_generator=to_camel, populate_by_name=True
    )

    name: str

    @abstractmethod
    def __call__(
        self, prev: float = 0.0, delta_ms: float = 1000.0, **kwargs: Any
    ) -> Any:
        """Calculation of signal function.
        Args:
            prev: Previous value of signal.
            delta_ms: Time difference in milliseconds from state changed.
            ...: TBD (TODO: Add more parameters)
        """
        raise NotImplementedError("Calculation is not implemented.")

    @model_validator(mode="before")
    @classmethod
    def _hyphen_to_underscore(cls, values: dict[str, Any]):
        """Replace character of field name from "-" to "_"."""
        return to_underscore_keys(values)

    @model_serializer(mode="wrap")
    def _add_name_serializer(self, serializer):
        data = serializer(self)
        if isinstance(data, dict):
            data = {"name": self.name, **data}
        return data
