from typing import Any, Literal
from pydantic import Field
from .base_function import BaseFunctionModel


class Constant(BaseFunctionModel):
    """Return static value."""

    name: Literal["constant"] = "constant"
    value: float = Field(..., title="Value of constant signal.")

    def __init__(self, value: float, **kwargs: Any):
        """Initialize constant value to accept position arg."""
        kwargs["value"] = value
        super().__init__(**kwargs)

    def __call__(self, prev: float = 0.0, delta_ms: float = 1000.0, **_: Any) -> float:
        """Return constant value."""
        return self.value
