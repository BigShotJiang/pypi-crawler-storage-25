from logging import getLogger

from typing import TYPE_CHECKING, Annotated, TypeAlias, Union
from pydantic import Field

from .base_function import BaseFunctionModel
from .constant import Constant
from .linear import Linear

log = getLogger(__name__)

function_registry: list[type[BaseFunctionModel]] = [
    Constant,
    Linear,
]

if TYPE_CHECKING:
    FunctionModel: TypeAlias = Annotated[Constant | Linear, Field(discriminator="name")]
else:
    FunctionModel = Annotated[
        Union[tuple(function_registry)],
        Field(discriminator="name"),
    ]


def register_function(cls: type[BaseFunctionModel]) -> None:
    """Register a function model class."""
    global FunctionModel
    function_registry.append(cls)
    if function_registry:
        FunctionModel = Annotated[  # type: ignore[assignment, valid-type]
            Union[tuple(function_registry)],
            Field(discriminator="name"),
        ]


__all__ = ["Constant", "Linear", "BaseFunctionModel", "FunctionModel"]
