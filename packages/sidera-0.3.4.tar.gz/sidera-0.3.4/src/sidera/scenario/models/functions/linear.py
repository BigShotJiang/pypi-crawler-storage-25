from typing import Any, Literal
from pydantic import Field

from .base_function import BaseFunctionModel


class Linear(BaseFunctionModel):
    """Linear function."""

    name: Literal["linear"] = "linear"
    slope: float = Field(..., title="Slope of linear signal.")
    min: float = Field(float("-inf"), title="Minimum threshold value of linear signal.")
    max: float = Field(float("inf"), title="Maximum threshold value of linear signal.")

    def __init__(self, slope: float, **kwargs: Any):
        """Initialize constant value to accept position arg."""
        kwargs["slope"] = slope
        super().__init__(**kwargs)

    def __call__(self, prev: float = 0.0, delta_ms: float = 1000.0, **_: Any) -> float:
        """Return calculated value."""
        return max(self.min, min(self.max, self.slope * delta_ms / 1000 + prev))
