from typing import Literal, TypeAlias
from uuid import UUID

from pydantic import BaseModel

from .input import Input, InputPatch
from .output import Output, OutputPatch
from .scenario import Scenario, ScenarioPatch
from .scene import Scene, ScenePatch
from .signal import Signal, SignalPatch
from .state import State, StatePatch
from .story import Story, StoryPatch
from .value import Value, ValuePatch

FieldModel: TypeAlias = str | int | float | bool | UUID | BaseModel

ItemModel: TypeAlias = (
    Scenario | Signal | Value | State | Input | Output | Story | Scene
)
PatchModel: TypeAlias = (
    ScenarioPatch
    | SignalPatch
    | ValuePatch
    | StatePatch
    | InputPatch
    | OutputPatch
    | StoryPatch
    | ScenePatch
)

ModelGroup: TypeAlias = (
    list[ItemModel]
    | list[Scenario]
    | list[Signal]
    | list[Value]
    | list[State]
    | list[Input]
    | list[Output]
    | list[Story]
    | list[Scene]
)

GroupName = Literal[
    "scenarios",
    "signals",
    "states",
    "stories",
    "scenes",
    "values",
    "inputs",
    "outputs",
]
