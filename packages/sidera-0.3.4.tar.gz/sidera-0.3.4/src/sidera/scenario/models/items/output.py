from pydantic import Field

from ..fields.item_link import ItemLink
from .base_data import BaseDataModel
from .base_item import BaseItemModel


class OutputPatch(BaseDataModel):
    """Output patch model."""

    signal_value: ItemLink | None = None


class Output(BaseItemModel[OutputPatch]):
    """Output model."""

    _patch_model = OutputPatch

    signal_value: ItemLink = Field(
        ...,
        title="Link to Output Signal Value",
        description="""This is a link to the value of the output signal.
            Link value is automatically updated according to the source node.""",
    )

    def get_name(self):
        """Get name of output item."""
        return self.signal_value.get_name("signals")
