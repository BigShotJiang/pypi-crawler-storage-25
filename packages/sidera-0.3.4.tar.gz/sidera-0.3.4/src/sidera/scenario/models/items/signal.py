from pydantic import Field, StrictStr

from .base_data import BaseDataModel
from .base_item import BaseItemModel
from .value import Value


class SignalPatch(BaseDataModel):
    """Signal patch model."""

    name: StrictStr | None = None
    description: StrictStr | None = None


class Signal(BaseItemModel[SignalPatch]):
    """Signal model."""

    _patch_model = SignalPatch

    name: StrictStr = Field(
        ...,
        title="Signal name",
        description="""This is a user-defined name for the signal.
            It must be unique within the scenario.
            Names with only numerals are prohibited, as they are always treated as index numbers.
            Names beginning with “~” are treated as ID numbers.""",
        min_length=1,
        examples=["Main Power"],
    )
    description: StrictStr = Field(
        default="",
        title="Signal description",
        description="""This is a description of the signal.
            This value is for informational purposes only and does not influence the behavior of the system.""",
        examples=["Main power signal for the system."],
    )
    values: list[Value] = Field(
        default=[],
        title="Signal values list",
        description="""List of all possible values for this signal.""",
    )
