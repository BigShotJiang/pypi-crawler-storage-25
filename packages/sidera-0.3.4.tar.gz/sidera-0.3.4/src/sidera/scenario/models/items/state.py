from pydantic import Field, StrictStr

from .base_data import BaseDataModel
from .base_item import BaseItemModel
from .input import Input
from .output import Output
from .story import Story


class StatePatch(BaseDataModel):
    """State patch model."""

    name: StrictStr | None = None
    description: StrictStr | None = None


class State(BaseItemModel[StatePatch]):
    """State model."""

    _patch_model = StatePatch

    name: StrictStr = Field(
        ...,
        title="State Name",
        description="""This is a user-defined name for the state.
            It must be unique within the scenario.
            Names with only numerals are prohibited, as they are always treated as index numbers.
            Names beginning with “~” are treated as ID numbers.""",
        min_length=1,
        examples=["Power Off", "Light Off", "Light On", "..."],
    )
    description: StrictStr = Field(
        default="",
        title="State Description",
        description="""This is a description of the state.
            This value is for informational purposes only and does not influence the behavior of the system.""",
        examples=["System power is off and shut down."],
    )
    inputs: list[Input] = Field(
        default=[],
        title="Input Signals",
        description="""List of input signals that affect this state.""",
    )
    outputs: list[Output] = Field(
        default=[],
        title="Output Signals",
        description="""List of output signals that will be affected by the change in this state.""",
    )
    stories: list[Story] = Field(
        default=[],
        title="Transition Stories",
        description="""List of state transition stories that describe the state change.""",
    )
