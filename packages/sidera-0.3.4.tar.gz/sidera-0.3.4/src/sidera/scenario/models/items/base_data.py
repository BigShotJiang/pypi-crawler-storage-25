from typing import Any

from pydantic import BaseModel, ConfigDict, model_validator
from pydantic.alias_generators import to_camel

from sidera.utils.field_key import to_underscore_keys


class BaseDataModel(BaseModel):
    """Base scenario item data class.
    This is used to define functions common to both the item model and patch model.
    """

    model_config = ConfigDict(
        extra="ignore", strict=True, alias_generator=to_camel, populate_by_name=True
    )

    @model_validator(mode="before")
    @classmethod
    def _hyphen_to_underscore(cls, values: dict[str, Any]):
        """Replace character of field name from "-" to "_"."""
        return to_underscore_keys(values)

    @model_validator(mode="before")
    @classmethod
    def _validate_name(cls, values: dict[str, Any]):
        """Check "name" value and remove whitespaces from the leading and trailing."""
        name = values.get("name")
        if isinstance(name, str):
            name = name.strip()
            if name.startswith("~"):
                raise ValueError(
                    "'name' string must not begin with '~', as this is treated as an ID string."
                )
            if name.isdigit():
                raise ValueError(
                    "'name' must not consist entirely of numbers, as this is treated as an index number."
                )
            values["name"] = name
        return values
