from pydantic import Field, StrictStr

from .base_data import BaseDataModel
from .base_item import BaseItemModel
from .scene import Scene


class StoryPatch(BaseDataModel):
    """Story patch model."""

    name: StrictStr | None = None
    description: StrictStr | None = None
    dest_state_name: StrictStr | None = None


class Story(BaseItemModel[StoryPatch]):
    """Story model."""

    _patch_model = StoryPatch

    name: StrictStr = Field(
        default="",
        title="Transition Story Name",
        description="""This is a user-defined name for the state transition story.
            The name is not required, but it must be unique within the state.
            Names with only numerals are prohibited, as they are always treated as index numbers.
            Names beginning with “~” are treated as ID numbers.""",
        min_length=1,
        examples=["Power off to on", "Power on to off", "..."],
    )
    description: StrictStr = Field(
        default="",
        title="Story Description",
        description="""This is a description of the state transition story.
            This value is for informational purposes only and does not influence the behavior of the system.""",
        examples=["System power is turned on from off."],
    )
    dest_state_name: StrictStr | None = Field(
        default=None,
        title="Destination State",
        description="""This shows the state transition destination for this story.""",
        examples=["Power On", "Power Off", "..."],
    )
    scenes: list[Scene] = Field(
        default=[],
        title="Scenes List",
        description="""List of scenes that describe the signal change in this transition story.""",
    )
