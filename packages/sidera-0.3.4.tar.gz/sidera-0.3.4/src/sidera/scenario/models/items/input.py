from pydantic import Field

from ..fields.item_link import ItemLink
from .base_data import BaseDataModel
from .base_item import BaseItemModel


class InputPatch(BaseDataModel):
    """Input patch model."""

    signal_value: ItemLink | None = None


class Input(BaseItemModel[InputPatch]):
    """Input model."""

    _patch_model = InputPatch

    signal_value: ItemLink = Field(
        ...,
        title="Link to Input Signal Value",
        description="""This is a link to the value of the input signal.
            Link value is automatically updated according to the source node.""",
    )

    def get_name(self):
        """Get name of input item."""
        return self.signal_value.get_name("signals")
