from pydantic import Field, StrictStr

from ..functions import FunctionModel
from .base_data import BaseDataModel
from .base_item import BaseItemModel


class ValuePatch(BaseDataModel):
    """Value patch model."""

    name: StrictStr | None = None
    description: StrictStr | None = None
    function: FunctionModel | None = None  # type: ignore


class Value(BaseItemModel[ValuePatch]):
    """Value model of signal."""

    _patch_model = ValuePatch

    name: StrictStr = Field(
        ...,
        title="Value Display Name",
        description="""This is a user-defined name for the value.
            It must be unique within the signal.
            Names with only numerals are prohibited, as they are always treated as index numbers.
            Names beginning with “~” are treated as ID numbers.""",
        min_length=1,
        examples=["ON", "OFF", "..."],
    )
    description: StrictStr = Field(
        default="",
        title="Value Description",
        description="""This is a description of the value.
            This value is for informational purposes only and does not influence the behavior of the system.""",
    )
    function: FunctionModel = Field(  # type: ignore
        ...,
        title="Signal Definition",
    )
