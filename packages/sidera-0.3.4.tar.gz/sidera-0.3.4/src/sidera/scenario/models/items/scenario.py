from json import dumps as json_dumps

from pydantic import Field, StrictStr

from .base_data import BaseDataModel
from .base_item import BaseItemModel
from .signal import Signal
from .state import State


class ScenarioPatch(BaseDataModel):
    """Scenario patch model."""

    name: StrictStr | None = None
    description: StrictStr | None = None


class Scenario(BaseItemModel[ScenarioPatch]):
    """Scenario model."""

    _patch_model = ScenarioPatch

    name: StrictStr = Field(
        default="(unnamed)",
        title="Scenario Name",
        description="""This is a user-defined name for the scenario.
            Names with only numerals are prohibited, as they are always treated as index numbers.
            Names beginning with “~” are treated as ID numbers.""",
        min_length=1,
    )
    description: StrictStr = Field(
        default="",
        title="Scenario Description",
        description="""This is a description of the scenario.
            This value is for informational purposes only and does not influence the behavior of the system.""",
    )
    signals: list[Signal] = Field(default=[], title="Signal data list")
    states: list[State] = Field(default=[], title="State data list")

    def dump(
        self,
        exclude_id: bool = False,
        by_alias: bool = True,
        exclude_none: bool = True,
        **kwargs,
    ):
        """Dump node data to dict."""
        dumped = super().dump(
            exclude_id=exclude_id,
            by_alias=by_alias,
            exclude_none=exclude_none,
            **kwargs,
        )
        # Remove id from dump data of Scenario data.
        dumped.pop("id", None)
        return dumped

    def dump_json(
        self,
        exclude_id: bool = False,
        indent: int | None = 2,
        exclude_none: bool = True,
        **kwargs,
    ):
        """Dump node data to JSON for serialization."""
        dumped = self.dump(
            exclude_id=exclude_id,
            exclude_none=exclude_none,
            **kwargs,
        )
        return json_dumps(dumped, indent=indent, default=str, **kwargs)
