from typing import (
    Any,
    Literal,
    TypeGuard,
    TypeVar,
    Union,
    get_args,
    get_origin,
    overload,
)

from .type_aliases import GroupName, ItemModel, PatchModel

T = TypeVar("T")
TType = TypeVar("TType", bound=type)


def is_item_model(data: Any) -> TypeGuard[ItemModel]:
    """Check if the data is a ItemModel."""
    return isinstance(data, get_args(ItemModel))


def is_item_type(model: type | None) -> TypeGuard[type[ItemModel]]:
    """Check if the type is a ItemModel."""
    return model is not None and issubclass(model, get_args(ItemModel))


def is_patch_model(data: Any) -> TypeGuard[PatchModel]:
    """Check if the data is a PatchModel."""
    return isinstance(data, get_args(PatchModel))


def is_patch_type(model: type | None) -> TypeGuard[type[PatchModel]]:
    """Check if the type is a PatchModel."""
    return model is not None and issubclass(model, get_args(PatchModel))


def is_group_name(node_name: str) -> TypeGuard[GroupName]:
    """Check if the node name is a group node."""
    return node_name in get_args(GroupName)


@overload
def is_instance_of_model(val: object, model: type[T]) -> TypeGuard[T]:
    pass


@overload
def is_instance_of_model(val: object, model: Union[T, Any] | None) -> bool:
    pass


def is_instance_of_model(
    val: object, model: type[T] | Union[T, Any] | None
) -> TypeGuard[T] | bool:
    """Check value is instance of model."""
    if model is None:
        return val is None
    match get_origin(model):
        case t if t is Union:
            return any(is_instance_of_model(val, arg) for arg in get_args(model))
        case t if t is Literal:
            return val in get_args(model)
        case t if t is list:
            if isinstance(val, list):
                return all(
                    is_instance_of_model(item, get_args(model)[0]) for item in val
                )
            return False
        case t if t is tuple:
            if not isinstance(val, tuple):
                return False
            mdl_args = get_args(model)
            if mdl_args[-1] is ...:
                # Extend tuple model to match value length
                mdl_args = mdl_args[:-1]
                mdl_args = (
                    mdl_args + (mdl_args[-1],) * (len(val) - len(mdl_args))
                    if len(mdl_args) < len(val)
                    else mdl_args
                )
            if len(val) != len(mdl_args):
                return False
            return all(is_instance_of_model(v, m) for v, m in zip(val, mdl_args))
        case _:
            return isinstance(model, type) and isinstance(val, model)


@overload
def is_subclass_of_model(cls: type | None, model: TType) -> TypeGuard[TType]:
    pass


@overload
def is_subclass_of_model(cls: type | None, model: Union[TType, Any] | None) -> bool:
    pass


def is_subclass_of_model(
    cls: type | None,
    model: TType | Union[TType, Any] | None,
) -> TypeGuard[TType] | bool:
    """Check type is subclass of model."""
    if cls is None or model is None:
        return cls is model is None

    if get_origin(cls) is Union:
        return any(is_subclass_of_model(arg, model) for arg in get_args(cls))

    match get_origin(model):
        case t if t is Union:
            return any(is_subclass_of_model(cls, arg) for arg in get_args(model))
        case t if t is Literal:
            if get_origin(cls) is not Literal:
                return False
            return set(get_args(cls)) <= set(get_args(model))
        case t if t is list:
            if get_origin(cls) is list:
                return all(
                    is_subclass_of_model(arg, get_args(model)[0])
                    for arg in get_args(cls)
                )
            return False
        case t if t is tuple:
            if get_origin(cls) is not tuple:
                return False
            mdl_args = get_args(model)
            cls_args = get_args(cls)
            cls_args = cls_args if cls_args[-1] is not ... else cls_args[:-1]
            if mdl_args[-1] is ...:
                # Extend tuple model to match class args length
                mdl_args = mdl_args[:-1]
                mdl_args = (
                    mdl_args + (mdl_args[-1],) * (len(cls_args) - len(mdl_args))
                    if len(mdl_args) < len(cls_args)
                    else mdl_args
                )
            if len(cls_args) != len(mdl_args):
                return False
            return all(
                is_subclass_of_model(c_arg, m_arg)
                for c_arg, m_arg in zip(cls_args, mdl_args)
            )
        case None if cls_type := get_origin(cls):
            return issubclass(cls_type, model)
        case _:
            return issubclass(cls, model)
