from pydantic import Field, StrictStr

from ..fields.item_link import ItemLink
from ..fields.wait_time import WaitTime
from .base_data import BaseDataModel
from .base_item import BaseItemModel


class ScenePatch(BaseDataModel):
    """Scene patch model."""

    name: StrictStr | None = None
    description: StrictStr | None = None
    wait_time: WaitTime | None = None
    signal_value: ItemLink | None = None


class Scene(BaseItemModel[ScenePatch]):
    """Scene model."""

    _patch_model = ScenePatch

    name: StrictStr = Field(
        default="",
        title="Scene Name",
        description="""This is a user-defined name for the scene.
            Names with only numerals are prohibited, as they are always treated as index numbers.
            Names beginning with “~” are treated as ID numbers.""",
        examples=["Power Off", "Light Off", "Light On", "..."],
    )
    description: StrictStr = Field(default="", title="Scene Description")
    wait_time: WaitTime = Field(
        default=WaitTime(),
        title="Scene Wait Time",
        description="""This is the wait time after the previous scene before this scene executes the signal change.
            The unit of the number is milliseconds.""",
    )
    signal_value: ItemLink = Field(
        ...,
        title="Link to Changing Signal Value",
        description="""This is a link to the value of the changing signal.
            Link value is automatically updated according to the source node.""",
    )
