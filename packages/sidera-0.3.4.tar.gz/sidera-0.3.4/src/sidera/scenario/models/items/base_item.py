from json import dumps as json_dumps
from typing import Any, ClassVar, Generic, TypeVar, cast
from uuid import UUID, uuid4

from pydantic import ConfigDict, model_validator, Field
from pydantic.alias_generators import to_camel
from typing_extensions import Self

from ..fields.item_id import UNSET_UUID, ItemUUID
from .base_data import BaseDataModel

T = TypeVar("T", bound=BaseDataModel)


class BaseItemModel(BaseDataModel, Generic[T]):
    """Base scenario item data class."""

    id: ItemUUID = Field(
        default=UNSET_UUID,
        title="Item ID",
        description="The ID of the item. If not set, a new ID is generated.",
        frozen=True,
    )

    # Partial update model for patch operation
    # Type is 'T' but it is not possible to use it in ClassVar
    _patch_model: ClassVar[type[BaseDataModel]]

    model_config = ConfigDict(
        extra="forbid", strict=True, alias_generator=to_camel, populate_by_name=True
    )

    @model_validator(mode="before")
    @classmethod
    def _validate_id(cls, values: dict[str, Any] | Any):
        """Validate id to UUID type."""
        id_val = values.get("id")
        if id_val in ("", None):
            id_val = UNSET_UUID
        elif isinstance(id_val, str):
            id_val = UUID(id_val)
        # if 'id' is not set, generate new id
        if id_val == UNSET_UUID:
            id_val = cls.generate_id()
        values["id"] = id_val
        return values

    @staticmethod
    def generate_id() -> UUID:
        """Generate new uuid v4."""
        return uuid4()

    @classmethod
    def get_patch_model(cls):
        """Get model to patch operation."""
        return cast(type[T], cls._patch_model)

    @classmethod
    def create_from_patch(cls, patch: BaseDataModel):
        """Create new model instance from patch model."""
        return cls.model_validate(patch.model_dump(exclude_none=True))

    def dump(
        self,
        exclude_id: bool = False,
        by_alias: bool = True,
        exclude_none: bool = True,
        **kwargs,
    ):
        """Dump node data to dict.
        Args:
            exclude_id - exclude id keys and values from json data.
            by_alias - Use field alias for dump.
            exclude_none - Exclude None values from dump.
            **kwargs - Additional arguments for model_dump.
        Returns:
            dict: Dumped data.
        """
        dumped = self.model_dump(by_alias=by_alias, exclude_none=exclude_none, **kwargs)
        if exclude_id:
            self.remove_id_values(dumped)
        return dumped

    def dump_json(
        self,
        exclude_id: bool = False,
        indent: int | None = 2,
        exclude_none: bool = True,
        **kwargs,
    ):
        """Dump node data to JSON for serialization.
        Args:
            exclude_id - exclude id keys and values from json data.
            by_alias - Use field alias for json.
            exclude_none - Exclude None values from json.
            **kwargs - Additional arguments for model_dump.
        """
        if not exclude_id:
            return self.model_dump_json(exclude_none=exclude_none, **kwargs)
        dumped = self.dump(
            exclude_id=exclude_id,
            exclude_none=exclude_none,
            **kwargs,
        )
        return json_dumps(dumped, indent=indent, default=str, **kwargs)

    def patch(self, patch_data: BaseDataModel) -> list[str]:
        """Update partial node data fields."""
        if not isinstance(patch_data, self._patch_model):
            raise TypeError(f"Invalid patch data type for {self}: {type(patch_data)}")
        updated_fields = []
        # replace current data with updated data
        for field in type(patch_data).model_fields.keys():
            current_value = getattr(self, field)
            updated_value = getattr(patch_data, field)
            if updated_value is None:
                continue
            if updated_value == current_value:
                continue
            setattr(self, field, updated_value)
            updated_fields.append(field)
        return updated_fields

    def get_patch(self, **kwargs) -> T:
        """Get patch model without children data."""
        patch_model = self.get_patch_model()
        return (
            patch_model.model_validate(kwargs)
            if kwargs
            else patch_model.model_validate(
                self.model_dump(exclude={"id"}, exclude_none=True)
            )
        )

    def get_name(self):
        """Get model name."""
        return str(getattr(self, "name", "")) or f"~{self.id}"

    def copy(
        self,
        *,
        include: Any = None,
        exclude: Any = None,
        update: dict[str, Any] | None = None,
        deep: bool = True,
    ) -> Self:
        """Copy model data and update the nested all id ."""
        if include is None and exclude is None and update is not None:
            return self.model_copy(update=update, deep=deep)
        if include is not None or update is not None:
            dumped = self.model_dump(
                include=include,
                exclude=exclude,
                round_trip=True,
            )
            if update is not None:
                dumped.update(update)
            return cast(Self, self.model_validate(dumped))
        if deep:
            dumped = self.dump(exclude_id=True)
        else:
            dumped = self.dump(
                exclude={"id"} if exclude is None else exclude,
                exclude_none=True,
            )
        copied = self.model_validate(dumped)
        return cast(Self, copied)

    @classmethod
    def remove_id_values(cls, data: dict[str, Any] | list):
        """Remove "id" key and reset link id value from dump data."""
        if isinstance(data, dict):
            data.pop("id", None)
            for value in data.values():
                cls.remove_id_values(value)
        elif isinstance(data, list):
            for item in data:
                cls.remove_id_values(item)
