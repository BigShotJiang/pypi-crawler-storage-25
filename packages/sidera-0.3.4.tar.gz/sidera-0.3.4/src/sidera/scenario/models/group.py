from json import dumps as json_dumps
from collections.abc import Sequence

from .items.type_aliases import ItemModel


def group_dump_json(
    data: Sequence[ItemModel],
    indent: int | None = 2,
    exclude_id: bool = False,
    **kwargs,
) -> str:
    """Dump group data."""
    return json_dumps(
        [item.dump(exclude_id=exclude_id) for item in data],
        indent=indent,
        default=str,
        **kwargs,
    )
