from typing import Any, Literal, Annotated

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator
from pydantic.alias_generators import to_camel

from sidera.utils.field_key import normalize_field_keys, to_underscore_keys, merge_args

from .item_link import ItemLink

WaitTimeValue = Annotated[Literal["any"] | float, Field(title="Wait Time Value")]
WaitTimeArg = Annotated[
    WaitTimeValue | str | int,
    Field(title="Wait Time Argument Type"),
]


class WaitTime(BaseModel):
    """Wait time model."""

    model_config = ConfigDict(
        extra="forbid", strict=True, alias_generator=to_camel, populate_by_name=True
    )

    start_item: ItemLink = Field(
        default=ItemLink(),
        title="Source Link ID",
        description="""The link to a Scene or State where time measurement starts.
            If no 'id' is not set, 'offset' is used and that ID is set.
            If the 'id' is a valid ID, 'offset' is updated to the offset of the index to the link item.
            If the offset value underflows the list of scenes, it indicates the link to 'State'.
            Zero and plus values are used in a loop story.
            If the offset value overflows or specifies an unreached scene, the time is invalid.""",
    )

    delay: WaitTimeValue = Field(
        default="any",
        title="Wait Time [ms]",
        description="The wait time in milliseconds from the 'start_item'.",
    )

    @model_validator(mode="before")
    @classmethod
    def _normalize_input(cls, values: dict[str, Any] | Any):
        """Replace character of field name from "-" to "_"."""
        if isinstance(values, dict):
            # Replace character of field name from "-" to "_"."""
            return to_underscore_keys(values)
        # Convert to dict as positional argument
        return {"delay": values}

    @field_validator("delay", mode="before")
    @classmethod
    def _validate_delay(cls, value: WaitTimeValue | str | int) -> WaitTimeValue:
        """validate delay field."""
        return cls._normalize_delay(value)

    @classmethod
    def _normalize_delay(cls, value: WaitTimeValue | str | int) -> WaitTimeValue:
        """Check if delay is valid."""
        match value:
            case "any":
                return value
            case float() | int() if value >= 0.0:
                return float(value)
            case str():
                try:
                    return float(value)
                except ValueError:
                    pass
        raise ValueError(
            f"Invalid wait time value: {value}. Must be 'any' or a positive number."
        )

    @model_validator(mode="after")
    def _clear_source_for_any(self):
        """If delay is 'any', clear source link."""
        if self.delay == "any" and self.start_item:
            self.start_item = ItemLink()
        return self

    def __init__(
        self,
        delay: "WaitTimeArg | WaitTime | None" = None,
        **kwargs,
    ):
        """Initialize constant value to accept position arg."""
        kwargs = normalize_field_keys(kwargs)
        if isinstance(delay, WaitTime):
            kwargs = delay.model_dump()
        elif delay is not None:
            args = {"delay": self._normalize_delay(delay)}
            kwargs = merge_args(args, kwargs)
        super().__init__(**kwargs)
