from typing import Annotated
from uuid import UUID

from pydantic import Field

UNSET_UUID = UUID("00000000-0000-0000-0000-000000000000")


ItemUUID = Annotated[
    UUID,
    Field(
        default=UNSET_UUID,
        title="Item ID",
        description="""A unique id will be set automatically as UUIDv4.
            Users should not edit this ID.
            If you change or delete the ID, there is a possibility that the links within the scenario will become inconsistent.""",
        examples=[
            "6aed83bc-d18d-48af-9263-0415c187500f",
            "00000000-0000-0000-0000-000000000000 (unset)",
        ],
    ),
]
