from typing import Annotated, Any, Literal
from uuid import UUID

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    PrivateAttr,
    field_validator,
    model_validator,
)
from pydantic.alias_generators import to_camel

from sidera.utils.field_key import merge_args, to_underscore_keys
from sidera.utils.type_check import is_strict_instance

from .item_id import UNSET_UUID, ItemUUID

ItemLinkArg = Annotated[
    str | int | UUID | None,
    Field(
        title="Item Link Argument Type",
    ),
]


class ItemLink(BaseModel):
    """Item link model."""

    model_config = ConfigDict(
        extra="forbid", strict=False, alias_generator=to_camel, populate_by_name=True
    )

    id: ItemUUID = Field(
        default=UNSET_UUID,
        title="Source Item ID",
        description="""The ID of the linked item.""",
    )
    path: str | None = Field(
        default=None,
        title="Source Item Path",
        description="""The path of the linked item from the top scenario item.""",
    )
    offset: int | None = Field(
        default=None,
        title="Source Item Relative Offset",
        description="""The relative offset value of the index to the linked item.
            0 indicates the item itself, and -1 indicates the previous item.""",
    )

    _location_type: Literal["path", "offset"] = PrivateAttr("path")

    @model_validator(mode="before")
    @classmethod
    def _normalize_input(cls, values: dict[str, Any] | Any):
        """Normalize dumped data before model validation."""
        if isinstance(values, dict):
            # Replace character of field name from "-" to "_"."""
            return to_underscore_keys(values)
        # Convert to dict as positional argument
        return cls._validate_arg(values)

    @field_validator("id", mode="before")
    @classmethod
    def _id_to_uuid(cls, value: str | ItemUUID) -> ItemUUID:
        """Convert id to uuid if it is string type."""
        match value:
            case str() if value == "":
                return UNSET_UUID
            case str() if value.startswith("~"):
                return UUID(value[1:])
            case str():
                return UUID(value)
            case _:
                return value

    @model_validator(mode="after")
    def _check_location_type(self):
        if (self.path is not None) and (self.offset is not None):
            raise ValueError("Only one of 'path' or 'offset' must be set.")
        if self.path:
            self._location_type = "path"
        elif self.offset:
            self._location_type = "offset"
        return self

    def __init__(
        self,
        value: "ItemLinkArg | ItemLink" = None,
        **kwargs,
    ):
        """Initialize ItemLink with positional args."""
        if value is not None:
            args = self._validate_arg(value)
            kwargs = merge_args(args, kwargs)
        super().__init__(**kwargs)

    @staticmethod
    def _validate_arg(value: "ItemLinkArg | ItemLink") -> dict[str, Any]:
        """Validate and normalize argument."""
        args: dict[str, Any] = {}
        match value:
            case str() if value == "":
                args["id"] = UNSET_UUID
            case str() if value.startswith("~"):
                args["id"] = UUID(value[1:])
            case str() if value.isdigit() or (
                value[0] in ("+", "-") and value[1:].isdigit()
            ):
                args["offset"] = int(value)
            case str():
                try:
                    args["id"] = UUID(value)
                except ValueError:
                    args["path"] = value
            case int():
                args["offset"] = value
            case UUID():
                args["id"] = value
            case None:
                args["id"] = UNSET_UUID
            case ItemLink():
                args = value.model_dump()
            case _:
                raise ValueError(
                    f"Invalid value type: {type(value)}. Expected str, int, or UUID."
                )
        return args

    def get_name(self, parent: str = "") -> str:
        """Get the name of the item link."""
        if self.path and parent:
            parts = self.path.split("/")
            try:
                index = parts.index(parent)
                return parts[index + 1]
            except (ValueError, IndexError):
                return "(invalid path)"
        if self.path is not None:
            return self.path.replace("/", ".")
        if self.offset is not None:
            return f"{self.offset:+d}"
        if self.id == UNSET_UUID:
            return "(unlinked)"
        return f"~{self.id}"

    def apply_from(self, source: "ItemLink"):
        """Apply values from another ItemLink."""
        self.id = source.id
        self.path = source.path
        self.offset = source.offset

    def is_same_target(self, other: "ItemLink | ItemLinkArg") -> bool:
        """Compare ItemLink with another object."""
        if not isinstance(other, ItemLink):
            if not is_strict_instance(other, ItemLinkArg):
                return False
            other = ItemLink(other)
        if not self and not other:
            # Both are unlinked
            return True
        if self.id == other.id != UNSET_UUID:
            # Compare by ID
            return True
        if UNSET_UUID in (self.id, other.id):
            # Compare by path or offset
            if self.path == other.path is not None:
                return True
            if self.offset == other.offset is not None:
                return True
        return False

    def is_unset(self) -> bool:
        """Check if ItemLink is unset value."""
        return self.id == UNSET_UUID and self.path is None and self.offset is None

    def is_path_link(self) -> bool:
        """Check if ItemLink is path link."""
        return self.path is not None

    def is_offset_link(self) -> bool:
        """Check if ItemLink is offset link."""
        return self.offset is not None

    def __bool__(self) -> bool:
        """Check if ItemLink is set value."""
        return not (self.is_unset())

    def __str__(self) -> str:
        """Get string representation of ItemLink."""
        link_id = str(self.id) if self.id != UNSET_UUID else "(unlinked)"
        if self._location_type == "path":
            return f"ItemLink(id={link_id}, path={self.path})"
        if self._location_type == "offset":
            return f"ItemLink(id={link_id}, offset={self.offset:+d})"
        return f"ItemLink(id={link_id})"
