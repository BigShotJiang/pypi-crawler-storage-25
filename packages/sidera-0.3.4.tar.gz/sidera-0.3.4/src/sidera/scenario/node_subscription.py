from itertools import chain
from logging import getLogger
from typing import Generator, Iterable, TypeAlias

from sidera.event import BaseEvent, BaseSubscription

from .node_event import BaseNodeEvent
from .nodes import NodePath

log = getLogger(__name__)

Target: TypeAlias = NodePath | str
TargetList: TypeAlias = Iterable[str] | Iterable[NodePath] | Iterable[Target]
Targets: TypeAlias = Target | TargetList


class NodeSubscription(BaseSubscription):
    """Filter to select events published by EventBroker."""

    def __init__(self, targets: Targets = [], name: str = ""):
        self._name = name
        self._targets: list[NodePath] = []
        self._paths: set[NodePath] = set()
        self.add(targets)

    def add(self, targets: Targets):
        """Append target to subscription filter."""
        before = len(self._targets)
        for path in self._convert_paths_list(targets):
            if path in self._targets:
                log.info(f"Duplicated node '{path}' is ignored.")
                continue
            self._targets.append(path)
            self._paths.update(self._path_nodes(path))
        return len(self._targets) > before

    def remove(self, targets: Targets):
        """Remove filter from subscription filter."""
        before = len(self._targets)
        for path in self._convert_paths_list(targets):
            if path not in self._targets:
                log.info(f"Not found node '{path}' is ignored.")
                continue
            self._targets.remove(path)
        self._paths = set(
            chain.from_iterable(self._path_nodes(path) for path in self._targets)
        )
        return len(self._targets) < before

    @staticmethod
    def _convert_path(target: Target) -> NodePath | None:
        match target:
            case str() | NodePath():
                return NodePath(target)
            case _:
                assert False, f"Invalid target type '{type(target)}'."

    def _convert_paths_list(self, targets: Targets) -> Generator[NodePath, None, None]:
        """Convert target list to node list."""
        targets = iter((targets,)) if isinstance(targets, (NodePath, str)) else targets
        for item in targets:
            path = self._convert_path(item)
            if path is None:
                log.info(f"Not found node '{item}' is ignored.")
                continue
            yield path

    def clear(self):
        """Clear all filters."""
        self._targets.clear()
        self._paths.clear()

    @staticmethod
    def _path_nodes(path: NodePath) -> Generator[NodePath, None, None]:
        """Get all nodes in the path."""
        while True:
            yield path
            if path == path.parent:
                break
            path = path.parent

    def _abs_paths(self) -> Iterable[NodePath]:
        """Get all absolute paths."""
        top = NodePath("/scenarios")
        if top not in self._paths:
            yield top
        for path in self._paths:
            yield path.absolute()

    def match(self, event: BaseEvent) -> bool:
        """Check if the node is matched."""
        if not isinstance(event, BaseNodeEvent):
            return False
        path = NodePath(event.source)
        match event.propagation:
            case "all":
                return True
            case "none" if path in self._targets:
                return True
            case "children" | "both" if path in self._abs_paths():
                return True
            case "parents" | "both" if any(
                parent in self._targets for parent in self._path_nodes(path.absolute())
            ):
                return True
            case _:
                return False

    def replace(self, old: Target, new: Target):
        """Rename path in filter."""
        old_path = self._convert_path(old)
        new_path = self._convert_path(new)
        assert old_path is not None and new_path is not None
        for target in (path for path in self._targets if path.is_relative_to(old_path)):
            replaced = NodePath(new_path) / target.relative_to(old_path)
            self.remove(target)
            self.add(replaced)

    def has_target(self, target: Target):
        """Check if filter contains node, group or path."""
        node = self._convert_path(target)
        return node in self._targets

    @property
    def name(self) -> str:
        """Get name of subscription."""
        return self._name or self._targets_str()

    def _targets_str(self) -> str:
        """Get target string."""
        match len(self._targets):
            case 0:
                return "(none)"
            case 1:
                path = self._targets[0]
                return path.named or str(path)
            case _:
                return f"({len(self._targets)} targets)"

    def __len__(self):
        """Return the number of target nodes."""
        return len(self._targets)

    def __str__(self):
        return f"{self.name}"

    def __repr__(self):
        targets = ", ".join(
            (f"{path}:{path.named}" if path.named else str(path))
            for path in self._targets
        )
        return f"NodeSubscription<{targets}>"
