from django.shortcuts import render
from django.http import JsonResponse
from .forms import ProfileImageForm
from PIL import Image
import io, base64

def profile_drop_view(request):
    if request.method == "POST":
        form = ProfileImageForm(request.POST, request.FILES)
        if form.is_valid():
            img = Image.open(form.cleaned_data['image'])
            min_side = min(img.width, img.height)

            left = (img.width - min_side) / 2
            top = (img.height - min_side) / 2
            right = left + min_side
            bottom = top + min_side

            img = img.crop((left, top, right, bottom))
            img = img.resize((200, 200))

            buffer = io.BytesIO()
            img.save(buffer, format="PNG")

            import base64
            img_str = base64.b64encode(buffer.getvalue()).decode()

            return JsonResponse({'success': True, 'image': 'data:image/png;base64,' + img_str})

        return JsonResponse({'success': False, 'errors': form.errors})

    return render(request, 'profile_drop/drop_input.html')
