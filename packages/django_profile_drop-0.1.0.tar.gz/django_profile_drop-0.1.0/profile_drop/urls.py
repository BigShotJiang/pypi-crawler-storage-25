from django.urls import path
from .views import profile_drop_view

urlpatterns = [
    path('drop/', profile_drop_view, name='profile_drop'),
]
