from setuptools import setup, find_packages

setup(
    name="django-profile-drop",
    version="0.1.0",
    author="Armand Kouassi",
    description="Profile image drag and drop with auto resize",
    packages=find_packages(),
    include_package_data=True,
    install_requires=["Django>=3.2", "Pillow"],
)
