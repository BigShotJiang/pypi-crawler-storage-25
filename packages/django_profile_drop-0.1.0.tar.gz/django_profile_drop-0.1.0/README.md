Django Profile Drop

Plugin Django pour upload d'image avec drag & drop et redimensionnement automatique.
