from __future__ import annotations

from typing import Any

from .openai import OpenAIInterceptor

PROVIDER = "azure-foundry"


class FoundryInterceptor:
    """Wraps azure.ai.projects.AIProjectClient.

    Intercepts get_openai_client() and get_azure_openai_client() so the
    returned OpenAI client is automatically cost-tracked. All other
    attributes are delegated unchanged to the underlying AIProjectClient.

    Usage:
        cp = CostPilotClient(project="my-project")
        project_client = cp.wrap(AIProjectClient(endpoint, credential))

        # Both patterns work:
        openai_client = project_client.get_openai_client()
        response = openai_client.chat.completions.create(...)

        with project_client.get_openai_client() as client:
            response = client.responses.create(...)
    """

    def __init__(self, client: Any, cp_client: Any) -> None:
        self._client = client
        self._cp = cp_client

    def get_openai_client(self, **kwargs: Any) -> OpenAIInterceptor:
        raw = self._client.get_openai_client(**kwargs)
        return OpenAIInterceptor(raw, self._cp, provider=PROVIDER)

    def get_azure_openai_client(self, **kwargs: Any) -> OpenAIInterceptor:
        raw = self._client.get_azure_openai_client(**kwargs)
        return OpenAIInterceptor(raw, self._cp, provider=PROVIDER)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._client, name)
