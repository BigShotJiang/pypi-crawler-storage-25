from __future__ import annotations

import inspect
import time
from typing import Any


class AnthropicInterceptor:
    def __init__(self, client: Any, cp_client: Any) -> None:
        self._client = client
        self._cp = cp_client
        self.messages = _MessagesInterceptor(client.messages, cp_client)

    def __enter__(self) -> "AnthropicInterceptor":
        if hasattr(self._client, "__enter__"):
            self._client.__enter__()
        return self

    def __exit__(self, *args: Any) -> Any:
        if hasattr(self._client, "__exit__"):
            return self._client.__exit__(*args)

    async def __aenter__(self) -> "AnthropicInterceptor":
        if hasattr(self._client, "__aenter__"):
            await self._client.__aenter__()
        return self

    async def __aexit__(self, *args: Any) -> Any:
        if hasattr(self._client, "__aexit__"):
            return await self._client.__aexit__(*args)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._client, name)


class _MessagesInterceptor:
    def __init__(self, messages: Any, cp_client: Any) -> None:
        self._messages = messages
        self._cp = cp_client

    def create(self, *args: Any, **kwargs: Any) -> Any:
        start = time.monotonic()
        system_tokens = self._cp.sanitizer.count_tokens_only(kwargs.get("system"), kwargs.get("model", ""))
        response = self._messages.create(*args, **kwargs)
        if inspect.isawaitable(response):
            return self._record_async(response, start, system_tokens, kwargs)
        return self._record(response, start, system_tokens, kwargs)

    def _record(self, response: Any, start: float, system_tokens: int, kwargs: dict[str, Any]) -> Any:
        latency_ms = int((time.monotonic() - start) * 1000)
        usage = getattr(response, "usage", None)
        model = getattr(response, "model", None) or kwargs.get("model", "unknown")
        self._cp.record_llm_call(
            provider="anthropic",
            model=model,
            input_tokens=getattr(usage, "input_tokens", 0),
            output_tokens=getattr(usage, "output_tokens", 0),
            cache_read_tokens=getattr(usage, "cache_read_input_tokens", 0),
            cache_write_tokens=getattr(usage, "cache_creation_input_tokens", 0),
            system_prompt_tokens=system_tokens,
            latency_ms=latency_ms,
        )
        return response

    async def _record_async(self, awaitable: Any, start: float, system_tokens: int, kwargs: dict[str, Any]) -> Any:
        response = await awaitable
        return self._record(response, start, system_tokens, kwargs)
