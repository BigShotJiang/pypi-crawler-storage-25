from __future__ import annotations

import inspect
import time
from typing import Any


class OpenAIInterceptor:
    def __init__(self, client: Any, cp_client: Any, *, provider: str = "openai") -> None:
        self._client = client
        self._cp = cp_client
        self._provider = provider
        self.chat = _ChatInterceptor(client.chat, cp_client, provider)
        self.embeddings = _EmbeddingsInterceptor(client.embeddings, cp_client, provider)
        if hasattr(client, "responses"):
            self.responses = _ResponsesInterceptor(client.responses, cp_client, provider)

    def __enter__(self) -> "OpenAIInterceptor":
        if hasattr(self._client, "__enter__"):
            self._client.__enter__()
        return self

    def __exit__(self, *args: Any) -> Any:
        if hasattr(self._client, "__exit__"):
            return self._client.__exit__(*args)

    async def __aenter__(self) -> "OpenAIInterceptor":
        if hasattr(self._client, "__aenter__"):
            await self._client.__aenter__()
        return self

    async def __aexit__(self, *args: Any) -> Any:
        if hasattr(self._client, "__aexit__"):
            return await self._client.__aexit__(*args)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._client, name)


class _ChatInterceptor:
    def __init__(self, chat: Any, cp_client: Any, provider: str) -> None:
        self._chat = chat
        self.completions = _CompletionsInterceptor(chat.completions, cp_client, provider)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._chat, name)


class _CompletionsInterceptor:
    def __init__(self, completions: Any, cp_client: Any, provider: str) -> None:
        self._completions = completions
        self._cp = cp_client
        self._provider = provider

    def create(self, *args: Any, **kwargs: Any) -> Any:
        if kwargs.get("stream"):
            return self._completions.create(*args, **kwargs)
        start = time.monotonic()
        system_tokens = _system_tokens_from_messages(self._cp, kwargs.get("messages"), kwargs.get("model", ""))
        response = self._completions.create(*args, **kwargs)
        if inspect.isawaitable(response):
            return self._record_async(response, start, system_tokens, kwargs)
        return self._record(response, start, system_tokens, kwargs)

    def _record(self, response: Any, start: float, system_tokens: int, kwargs: dict[str, Any]) -> Any:
        latency_ms = int((time.monotonic() - start) * 1000)
        usage = getattr(response, "usage", None)
        model = getattr(response, "model", None) or kwargs.get("model", "unknown")
        self._cp.record_llm_call(
            provider=self._provider,
            model=model,
            input_tokens=getattr(usage, "prompt_tokens", 0),
            output_tokens=getattr(usage, "completion_tokens", 0),
            cache_read_tokens=0,
            cache_write_tokens=0,
            system_prompt_tokens=system_tokens,
            latency_ms=latency_ms,
        )
        return response

    async def _record_async(self, awaitable: Any, start: float, system_tokens: int, kwargs: dict[str, Any]) -> Any:
        response = await awaitable
        return self._record(response, start, system_tokens, kwargs)


class _EmbeddingsInterceptor:
    def __init__(self, embeddings: Any, cp_client: Any, provider: str) -> None:
        self._embeddings = embeddings
        self._cp = cp_client
        self._provider = provider

    def create(self, *args: Any, **kwargs: Any) -> Any:
        start = time.monotonic()
        response = self._embeddings.create(*args, **kwargs)
        if inspect.isawaitable(response):
            return self._record_async(response, start, kwargs)
        return self._record(response, start, kwargs)

    def _record(self, response: Any, start: float, kwargs: dict[str, Any]) -> Any:
        latency_ms = int((time.monotonic() - start) * 1000)
        usage = getattr(response, "usage", None)
        model = getattr(response, "model", None) or kwargs.get("model", "unknown")
        total_tokens = getattr(usage, "total_tokens", 0)
        self._cp.record_llm_call(
            provider=self._provider,
            model=model,
            input_tokens=total_tokens,
            output_tokens=0,
            embedding_tokens=total_tokens,
            latency_ms=latency_ms,
        )
        return response

    async def _record_async(self, awaitable: Any, start: float, kwargs: dict[str, Any]) -> Any:
        response = await awaitable
        return self._record(response, start, kwargs)


class _ResponsesInterceptor:
    """Intercepts the OpenAI Responses API (client.responses.create).

    Used by Azure AI Foundry clients and any OpenAI client that uses the
    newer Responses API. Token fields differ from chat.completions:
    input_tokens / output_tokens (not prompt_tokens / completion_tokens).
    """

    def __init__(self, responses: Any, cp_client: Any, provider: str) -> None:
        self._responses = responses
        self._cp = cp_client
        self._provider = provider

    def create(self, *args: Any, **kwargs: Any) -> Any:
        start = time.monotonic()
        response = self._responses.create(*args, **kwargs)
        if inspect.isawaitable(response):
            return self._record_async(response, start, kwargs)
        return self._record(response, start, kwargs)

    def _record(self, response: Any, start: float, kwargs: dict[str, Any]) -> Any:
        latency_ms = int((time.monotonic() - start) * 1000)
        usage = getattr(response, "usage", None)
        model = getattr(response, "model", None) or kwargs.get("model", "unknown")
        self._cp.record_llm_call(
            provider=self._provider,
            model=model,
            input_tokens=getattr(usage, "input_tokens", 0),
            output_tokens=getattr(usage, "output_tokens", 0),
            latency_ms=latency_ms,
        )
        return response

    async def _record_async(self, awaitable: Any, start: float, kwargs: dict[str, Any]) -> Any:
        response = await awaitable
        return self._record(response, start, kwargs)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._responses, name)


def _system_tokens_from_messages(cp_client: Any, messages: Any, model: str) -> int:
    if not isinstance(messages, list):
        return 0
    text = []
    for message in messages:
        if isinstance(message, dict) and message.get("role") == "system":
            text.append(message.get("content", ""))
    return cp_client.sanitizer.count_tokens_only(text, model)
