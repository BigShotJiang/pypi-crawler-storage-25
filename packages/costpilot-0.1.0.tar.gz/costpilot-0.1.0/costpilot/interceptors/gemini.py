from __future__ import annotations

import inspect
import time
from typing import Any


class GeminiInterceptor:
    """Wraps google.genai.Client — intercepts models.generate_content."""

    def __init__(self, client: Any, cp_client: Any) -> None:
        self._client = client
        self._cp = cp_client
        self.models = _ModelsInterceptor(client.models, cp_client)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._client, name)


class _ModelsInterceptor:
    def __init__(self, models: Any, cp_client: Any) -> None:
        self._models = models
        self._cp = cp_client

    def generate_content(self, *args: Any, **kwargs: Any) -> Any:
        start = time.monotonic()
        response = self._models.generate_content(*args, **kwargs)
        if inspect.isawaitable(response):
            return self._record_async(response, start, kwargs)
        return self._record(response, start, kwargs)

    def _record(self, response: Any, start: float, kwargs: dict[str, Any]) -> Any:
        latency_ms = int((time.monotonic() - start) * 1000)
        usage = getattr(response, "usage_metadata", None)
        # google.genai uses model name passed in kwargs; response may not echo it
        model = kwargs.get("model", "gemini-2.0-flash")
        self._cp.record_llm_call(
            provider="gemini",
            model=model,
            input_tokens=getattr(usage, "prompt_token_count", 0) or 0,
            output_tokens=getattr(usage, "candidates_token_count", 0) or 0,
            latency_ms=latency_ms,
        )
        return response

    async def _record_async(self, awaitable: Any, start: float, kwargs: dict[str, Any]) -> Any:
        response = await awaitable
        return self._record(response, start, kwargs)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._models, name)
