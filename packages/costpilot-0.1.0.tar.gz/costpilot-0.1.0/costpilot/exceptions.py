class CostPilotError(Exception):
    """Base exception for CostPilot SDK errors."""


class ConfigError(CostPilotError):
    """Raised when .costpilot.yaml is missing or invalid."""


class AuthError(CostPilotError):
    """Raised when CostPilot cannot resolve an authenticated operating mode."""


class StorageError(CostPilotError):
    """Raised when a row does not match the SQLite adapter contract."""


class InsufficientDataError(CostPilotError):
    """Raised when the scenario engine lacks enough queries or calendar days to project."""
