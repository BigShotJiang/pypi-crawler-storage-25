-- Migration 001: initial schema
-- Applied when PRAGMA user_version = 0

CREATE TABLE IF NOT EXISTS queries (
    id                        TEXT PRIMARY KEY,
    timestamp                 DATETIME DEFAULT CURRENT_TIMESTAMP,
    project                   TEXT NOT NULL,
    feature                   TEXT,
    user_id_hash              TEXT,
    session_id_hash           TEXT,
    provider                  TEXT NOT NULL,
    model                     TEXT NOT NULL,
    input_tokens              INTEGER NOT NULL,
    output_tokens             INTEGER NOT NULL,
    embedding_tokens          INTEGER DEFAULT 0,
    cache_read_tokens         INTEGER DEFAULT 0,
    cache_write_tokens        INTEGER DEFAULT 0,
    system_prompt_tokens      INTEGER DEFAULT 0,
    context_tokens            INTEGER DEFAULT 0,
    cost_usd                  REAL NOT NULL,
    latency_ms                INTEGER,
    synced_to_cloud           BOOLEAN DEFAULT FALSE,
    CONSTRAINT no_pii CHECK (user_id_hash NOT LIKE '%@%')
);

CREATE TABLE IF NOT EXISTS service_usage (
    id                  TEXT PRIMARY KEY,
    timestamp           DATETIME DEFAULT CURRENT_TIMESTAMP,
    project             TEXT NOT NULL,
    service             TEXT NOT NULL,
    operation           TEXT NOT NULL,
    units               REAL DEFAULT 1,
    estimated_cost_usd  REAL DEFAULT 0,
    metadata            TEXT
);

CREATE TABLE IF NOT EXISTS pricing_snapshots (
    id                        TEXT PRIMARY KEY,
    captured_at               DATETIME DEFAULT CURRENT_TIMESTAMP,
    provider                  TEXT NOT NULL,
    model                     TEXT NOT NULL,
    input_price_per_million   REAL,
    output_price_per_million  REAL,
    cache_read_per_million    REAL,
    cache_write_per_million   REAL,
    source                    TEXT,
    source_url                TEXT
);

CREATE TABLE IF NOT EXISTS migration_reports (
    id                    TEXT PRIMARY KEY,
    generated_at          DATETIME DEFAULT CURRENT_TIMESTAMP,
    project               TEXT NOT NULL,
    period_days           INTEGER,
    target_cloud          TEXT,
    report_json           TEXT,
    projected_monthly_usd REAL
);

CREATE TABLE IF NOT EXISTS audit_log (
    id          TEXT PRIMARY KEY,
    timestamp   DATETIME DEFAULT CURRENT_TIMESTAMP,
    event_type  TEXT NOT NULL,
    result      TEXT,
    metadata    TEXT
);

CREATE TABLE IF NOT EXISTS health_metrics (
    id              TEXT PRIMARY KEY,
    timestamp       DATETIME DEFAULT CURRENT_TIMESTAMP,
    project         TEXT NOT NULL,
    service         TEXT NOT NULL,
    metric          TEXT NOT NULL,
    value           REAL NOT NULL,
    status          TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS alerts (
    id              TEXT PRIMARY KEY,
    timestamp       DATETIME DEFAULT CURRENT_TIMESTAMP,
    project         TEXT NOT NULL,
    alert_type      TEXT NOT NULL,
    service         TEXT,
    message         TEXT NOT NULL,
    value           REAL,
    threshold       REAL,
    acknowledged    BOOLEAN DEFAULT FALSE
);

CREATE INDEX IF NOT EXISTS idx_queries_project   ON queries(project);
CREATE INDEX IF NOT EXISTS idx_queries_timestamp ON queries(timestamp);
CREATE INDEX IF NOT EXISTS idx_queries_model     ON queries(model);
CREATE INDEX IF NOT EXISTS idx_queries_synced    ON queries(synced_to_cloud);
CREATE INDEX IF NOT EXISTS idx_service_project   ON service_usage(project, service);
CREATE INDEX IF NOT EXISTS idx_health_project_service ON health_metrics(project, service, timestamp);
CREATE INDEX IF NOT EXISTS idx_alerts_project    ON alerts(project, acknowledged);

PRAGMA user_version = 1;
