from __future__ import annotations

from sqlalchemy import Boolean, CheckConstraint, Column, DateTime, Float, Index, Integer, String, Text, func
from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    pass


class QueryRow(Base):
    __tablename__ = "queries"
    __table_args__ = (
        CheckConstraint("user_id_hash NOT LIKE '%@%'", name="no_pii"),
        Index("idx_queries_project", "project"),
        Index("idx_queries_timestamp", "timestamp"),
        Index("idx_queries_model", "model"),
        Index("idx_queries_synced", "synced_to_cloud"),
    )

    id = Column(String(36), primary_key=True)
    timestamp = Column(DateTime, server_default=func.now(), nullable=False)
    project = Column(String, nullable=False)
    feature = Column(String)
    user_id_hash = Column(String)
    session_id_hash = Column(String)
    provider = Column(String, nullable=False)
    model = Column(String, nullable=False)
    input_tokens = Column(Integer, nullable=False)
    output_tokens = Column(Integer, nullable=False)
    embedding_tokens = Column(Integer, server_default="0")
    cache_read_tokens = Column(Integer, server_default="0")
    cache_write_tokens = Column(Integer, server_default="0")
    system_prompt_tokens = Column(Integer, server_default="0")
    context_tokens = Column(Integer, server_default="0")
    cost_usd = Column(Float, nullable=False)
    latency_ms = Column(Integer)
    synced_to_cloud = Column(Boolean, server_default="0")


class ServiceUsage(Base):
    __tablename__ = "service_usage"
    __table_args__ = (
        Index("idx_service_project", "project", "service"),
    )

    id = Column(String(36), primary_key=True)
    timestamp = Column(DateTime, server_default=func.now(), nullable=False)
    project = Column(String, nullable=False)
    service = Column(String, nullable=False)
    operation = Column(String, nullable=False)
    units = Column(Float, server_default="1")
    estimated_cost_usd = Column(Float, server_default="0")
    # "metadata" is reserved by SQLAlchemy's DeclarativeBase — use DB alias
    metadata_json = Column("metadata", Text)


class PricingSnapshot(Base):
    __tablename__ = "pricing_snapshots"

    id = Column(String(36), primary_key=True)
    captured_at = Column(DateTime, server_default=func.now(), nullable=False)
    provider = Column(String, nullable=False)
    model = Column(String, nullable=False)
    input_price_per_million = Column(Float)
    output_price_per_million = Column(Float)
    cache_read_per_million = Column(Float)
    cache_write_per_million = Column(Float)
    source = Column(String)
    source_url = Column(String)


class MigrationReport(Base):
    __tablename__ = "migration_reports"

    id = Column(String(36), primary_key=True)
    generated_at = Column(DateTime, server_default=func.now(), nullable=False)
    project = Column(String, nullable=False)
    period_days = Column(Integer)
    target_cloud = Column(String)
    report_json = Column(Text)
    projected_monthly_usd = Column(Float)


class AuditLogRow(Base):
    __tablename__ = "audit_log"

    id = Column(String(36), primary_key=True)
    timestamp = Column(DateTime, server_default=func.now(), nullable=False)
    event_type = Column(String, nullable=False)
    result = Column(String)
    # "metadata" is reserved by SQLAlchemy's DeclarativeBase — use DB alias
    metadata_json = Column("metadata", Text)


class HealthMetric(Base):
    __tablename__ = "health_metrics"
    __table_args__ = (
        Index("idx_health_project_service", "project", "service", "timestamp"),
    )

    id = Column(String(36), primary_key=True)
    timestamp = Column(DateTime, server_default=func.now(), nullable=False)
    project = Column(String, nullable=False)
    service = Column(String, nullable=False)   # redis | qdrant | appwrite | llm
    metric = Column(String, nullable=False)    # latency_ms | memory_pct | hit_rate | error_rate
    value = Column(Float, nullable=False)
    status = Column(String, nullable=False)    # healthy | warning | critical


class Alert(Base):
    __tablename__ = "alerts"
    __table_args__ = (
        Index("idx_alerts_project", "project", "acknowledged"),
    )

    id = Column(String(36), primary_key=True)
    timestamp = Column(DateTime, server_default=func.now(), nullable=False)
    project = Column(String, nullable=False)
    alert_type = Column(String, nullable=False)   # cost_spike | memory_high | latency_spike
    service = Column(String)
    message = Column(String, nullable=False)
    value = Column(Float)
    threshold = Column(Float)
    acknowledged = Column(Boolean, server_default="0")
