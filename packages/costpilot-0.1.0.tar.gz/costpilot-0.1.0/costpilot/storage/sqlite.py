from __future__ import annotations

import json
import uuid
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Generator

from sqlalchemy import and_, create_engine, func, select, update
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session

from costpilot.exceptions import StorageError

from ._crypto import decrypt_row, encrypt_row, field_fernet, sqlcipher_key
from .models import Alert, AuditLogRow, Base, HealthMetric, MigrationReport, PricingSnapshot, QueryRow, ServiceUsage


class SqliteStore:
    """ORM-backed store. Accepts any SQLAlchemy URL or a filesystem path (SQLite)."""

    def __init__(
        self,
        db: str | Path,
        *,
        history_days_limit: int = -1,
        sync_enabled: bool = True,
        read_only: bool = False,
    ) -> None:
        self.history_days_limit = history_days_limit
        self.sync_enabled = sync_enabled
        self.read_only = read_only
        self._fernet = field_fernet()
        self._engine = self._make_engine(db, read_only)
        if not read_only:
            Base.metadata.create_all(self._engine)
            self._run_migrations()

    def close(self) -> None:
        self._engine.dispose()

    # ── writes ───────────────────────────────────────────────────────────────

    def insert_query(self, row: dict[str, Any]) -> None:
        payload = dict(row)
        payload.setdefault("id", str(uuid.uuid4()))
        payload.setdefault("embedding_tokens", 0)
        payload.setdefault("cache_read_tokens", 0)
        payload.setdefault("cache_write_tokens", 0)
        payload.setdefault("system_prompt_tokens", 0)
        payload.setdefault("context_tokens", 0)
        payload.setdefault("synced_to_cloud", False)
        required = {"id", "project", "provider", "model", "input_tokens", "output_tokens", "cost_usd"}
        missing = required - payload.keys()
        if missing:
            raise StorageError(f"queries row missing required fields: {sorted(missing)}")
        # Enforce no_pii constraint before field encryption obscures the value
        uid = payload.get("user_id_hash")
        if isinstance(uid, str) and "@" in uid:
            from sqlalchemy.exc import IntegrityError
            raise IntegrityError("no_pii CHECK constraint: user_id_hash must not contain '@'", None, None)
        payload = encrypt_row(payload, self._fernet)
        with self._session() as session:
            session.add(QueryRow(**self._pick(payload, QueryRow)))
            session.commit()

    def insert_service_usage(self, row: dict[str, Any]) -> None:
        payload = dict(row)
        payload.setdefault("id", str(uuid.uuid4()))
        payload.setdefault("units", 1)
        payload.setdefault("estimated_cost_usd", 0)
        if isinstance(payload.get("metadata"), dict):
            payload["metadata"] = json.dumps(payload["metadata"])
        with self._session() as session:
            session.add(ServiceUsage(**self._pick(payload, ServiceUsage)))
            session.commit()

    def insert_pricing_snapshot(self, row: dict[str, Any]) -> None:
        payload = dict(row)
        payload.setdefault("id", str(uuid.uuid4()))
        with self._session() as session:
            session.add(PricingSnapshot(**self._pick(payload, PricingSnapshot)))
            session.commit()

    def insert_migration_report(
        self,
        project: str,
        target: str,
        report: dict[str, Any],
        projected_monthly_usd: float,
    ) -> str:
        report_id = str(uuid.uuid4())
        with self._session() as session:
            session.add(MigrationReport(
                id=report_id,
                project=project,
                period_days=report.get("period_days"),
                target_cloud=target,
                report_json=json.dumps(report),
                projected_monthly_usd=projected_monthly_usd,
            ))
            session.commit()
        return report_id

    def insert_audit_log(self, row: dict[str, Any]) -> None:
        payload = dict(row)
        payload.setdefault("id", str(uuid.uuid4()))
        if isinstance(payload.get("metadata"), dict):
            payload["metadata"] = json.dumps(payload["metadata"])
        with self._session() as session:
            session.add(AuditLogRow(**self._pick(payload, AuditLogRow)))
            session.commit()

    def insert_health_metric(self, row: dict[str, Any]) -> None:
        payload = dict(row)
        payload.setdefault("id", str(uuid.uuid4()))
        with self._session() as session:
            session.add(HealthMetric(**self._pick(payload, HealthMetric)))
            session.commit()

    def insert_alert(self, row: dict[str, Any]) -> None:
        payload = dict(row)
        payload.setdefault("id", str(uuid.uuid4()))
        payload.setdefault("acknowledged", False)
        with self._session() as session:
            session.add(Alert(**self._pick(payload, Alert)))
            session.commit()

    def alert_fired_recently(self, project: str, alert_type: str, service: str | None, window_minutes: int = 30) -> bool:
        cutoff = datetime.now(timezone.utc) - timedelta(minutes=window_minutes)
        conditions: list[Any] = [
            Alert.project == project,
            Alert.alert_type == alert_type,
            Alert.timestamp >= cutoff,
        ]
        if service:
            conditions.append(Alert.service == service)
        stmt = select(func.count()).select_from(Alert).where(and_(*conditions))
        with self._session() as session:
            return int(session.execute(stmt).scalar() or 0) > 0

    def acknowledge_alert(self, alert_id: str) -> bool:
        with self._session() as session:
            session.execute(
                update(Alert).where(Alert.id == alert_id).values(acknowledged=True)
            )
            session.commit()
        return True

    def get_health_metrics(
        self,
        project: str | None = None,
        service: str | None = None,
        hours: int = 24,
        limit: int = 500,
    ) -> list[dict[str, Any]]:
        cutoff = datetime.now(timezone.utc) - timedelta(hours=hours)
        conditions: list[Any] = [HealthMetric.timestamp >= cutoff]
        if project:
            conditions.append(HealthMetric.project == project)
        if service:
            conditions.append(HealthMetric.service == service)
        stmt = (
            select(HealthMetric)
            .where(and_(*conditions))
            .order_by(HealthMetric.timestamp.desc())
            .limit(max(1, min(limit, 5000)))
        )
        with self._session() as session:
            return [self._to_dict(r) for r in session.execute(stmt).scalars()]

    def get_alerts(self, project: str | None = None, include_acknowledged: bool = False) -> list[dict[str, Any]]:
        conditions: list[Any] = []
        if project:
            conditions.append(Alert.project == project)
        if not include_acknowledged:
            conditions.append(Alert.acknowledged == False)  # noqa: E712
        stmt = select(Alert).order_by(Alert.timestamp.desc()).limit(200)
        if conditions:
            stmt = stmt.where(and_(*conditions))
        with self._session() as session:
            return [self._to_dict(r) for r in session.execute(stmt).scalars()]

    def mark_synced(self, query_ids: list[str]) -> None:
        if not query_ids:
            return
        with self._session() as session:
            session.execute(
                update(QueryRow)
                .where(QueryRow.id.in_(query_ids))
                .values(synced_to_cloud=True)
            )
            session.commit()

    # ── reads ────────────────────────────────────────────────────────────────

    def get_project_stats(self, project: str, days: int = 7) -> dict[str, Any]:
        since = self._since_for_days(days)
        conditions = self._query_conditions(project=project, since=since)
        stmt = select(
            func.coalesce(func.sum(QueryRow.cost_usd), 0).label("total_cost_usd"),
            func.count().label("total_queries"),
            func.count(QueryRow.model.distinct()).label("distinct_models"),
            func.count(func.coalesce(QueryRow.feature, "").distinct()).label("distinct_features"),
        )
        if conditions:
            stmt = stmt.where(and_(*conditions))
        with self._session() as session:
            row = session.execute(stmt).mappings().one()
            total_queries = int(row["total_queries"] or 0)
            total_cost = float(row["total_cost_usd"] or 0)
            return {
                "total_cost_usd": round(total_cost, 8),
                "total_queries": total_queries,
                "avg_cost_per_query": round(total_cost / total_queries, 8) if total_queries else 0.0,
                "distinct_models": int(row["distinct_models"] or 0),
                "distinct_features": int(row["distinct_features"] or 0),
            }

    def get_queries_paginated(
        self,
        project: str | None = None,
        model: str | None = None,
        feature: str | None = None,
        since: datetime | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        conditions = self._query_conditions(project=project, model=model, feature=feature, since=since)
        stmt = select(QueryRow).order_by(QueryRow.timestamp.desc()).limit(max(0, min(limit, 1000))).offset(max(0, offset))
        if conditions:
            stmt = stmt.where(and_(*conditions))
        with self._session() as session:
            return [self._to_dict(r) for r in session.execute(stmt).scalars()]

    def count_queries(
        self,
        project: str | None = None,
        model: str | None = None,
        feature: str | None = None,
        since: datetime | None = None,
    ) -> int:
        conditions = self._query_conditions(project=project, model=model, feature=feature, since=since)
        stmt = select(func.count()).select_from(QueryRow)
        if conditions:
            stmt = stmt.where(and_(*conditions))
        with self._session() as session:
            return int(session.execute(stmt).scalar() or 0)

    def data_span_days(self, project: str) -> float:
        """Calendar days between first and last query for a project (scenario engine data gate)."""
        stmt = select(
            func.min(QueryRow.timestamp).label("first"),
            func.max(QueryRow.timestamp).label("last"),
        ).where(QueryRow.project == project)
        with self._session() as session:
            row = session.execute(stmt).mappings().one()
        first, last = row["first"], row["last"]
        if first is None or last is None:
            return 0.0
        if isinstance(first, str):
            first = datetime.fromisoformat(first.replace("Z", "+00:00"))
        if isinstance(last, str):
            last = datetime.fromisoformat(last.replace("Z", "+00:00"))
        # Normalize to UTC naive for arithmetic
        if first.tzinfo is not None:
            first = first.replace(tzinfo=None)
        if last.tzinfo is not None:
            last = last.replace(tzinfo=None)
        return max(0.0, (last - first).total_seconds() / 86400)

    def get_cost_by_model(self, project: str | None = None, days: int = 30) -> list[dict[str, Any]]:
        since = self._since_for_days(days)
        conditions = self._query_conditions(project=project, since=since)
        stmt = (
            select(
                QueryRow.model,
                func.count().label("query_count"),
                func.coalesce(func.sum(QueryRow.cost_usd), 0).label("total_cost_usd"),
            )
            .group_by(QueryRow.model)
            .order_by(func.sum(QueryRow.cost_usd).desc())
        )
        if conditions:
            stmt = stmt.where(and_(*conditions))
        with self._session() as session:
            return [dict(r._mapping) for r in session.execute(stmt)]

    def get_cost_by_feature(self, project: str | None = None, days: int = 30) -> list[dict[str, Any]]:
        since = self._since_for_days(days)
        conditions = self._query_conditions(project=project, since=since)
        feature_col = func.coalesce(QueryRow.feature, "untagged")
        stmt = (
            select(
                feature_col.label("feature"),
                func.count().label("query_count"),
                func.coalesce(func.sum(QueryRow.cost_usd), 0).label("total_cost_usd"),
            )
            .group_by(feature_col)
            .order_by(func.sum(QueryRow.cost_usd).desc())
        )
        if conditions:
            stmt = stmt.where(and_(*conditions))
        with self._session() as session:
            return [dict(r._mapping) for r in session.execute(stmt)]

    def get_cost_over_time(
        self,
        project: str | None = None,
        days: int = 30,
        granularity: str = "day",
    ) -> list[dict[str, Any]]:
        since = self._since_for_days(days)
        conditions = self._query_conditions(project=project, since=since)
        bucket = self._time_bucket(QueryRow.timestamp, granularity).label("bucket")
        stmt = (
            select(
                bucket,
                func.coalesce(func.sum(QueryRow.cost_usd), 0).label("total_cost_usd"),
                func.count().label("query_count"),
            )
            .group_by(self._time_bucket(QueryRow.timestamp, granularity))
            .order_by(self._time_bucket(QueryRow.timestamp, granularity).asc())
        )
        if conditions:
            stmt = stmt.where(and_(*conditions))
        with self._session() as session:
            return [dict(r._mapping) for r in session.execute(stmt)]

    def get_service_stats(self, project: str | None = None, days: int = 7) -> list[dict[str, Any]]:
        since = self._since_for_days(days)
        conditions: list[Any] = []
        if project:
            conditions.append(ServiceUsage.project == project)
        if since:
            conditions.append(ServiceUsage.timestamp >= since)
        stmt = (
            select(
                ServiceUsage.service,
                ServiceUsage.operation,
                func.count().label("ops"),
                func.coalesce(func.sum(ServiceUsage.units), 0).label("units"),
                func.coalesce(func.sum(ServiceUsage.estimated_cost_usd), 0).label("estimated_cost_usd"),
            )
            .group_by(ServiceUsage.service, ServiceUsage.operation)
            .order_by(ServiceUsage.service, func.count().desc())
        )
        if conditions:
            stmt = stmt.where(and_(*conditions))
        with self._session() as session:
            rows = [dict(r._mapping) for r in session.execute(stmt)]
        grouped: dict[str, dict[str, Any]] = {}
        for row in rows:
            entry = grouped.setdefault(
                row["service"],
                {"service": row["service"], "ops": 0, "units": 0.0, "estimated_cost_usd": 0.0, "top_operations": []},
            )
            entry["ops"] += int(row["ops"] or 0)
            entry["units"] += float(row["units"] or 0)
            entry["estimated_cost_usd"] += float(row["estimated_cost_usd"] or 0)
            entry["top_operations"].append({"operation": row["operation"], "ops": row["ops"], "units": row["units"]})
        return list(grouped.values())

    def get_unsynced_queries(self, limit: int = 1000) -> list[dict[str, Any]]:
        if not self.sync_enabled:
            return []
        stmt = (
            select(QueryRow)
            .where(QueryRow.synced_to_cloud == False)  # noqa: E712
            .order_by(QueryRow.timestamp.asc())
            .limit(max(1, min(limit, 1000)))
        )
        with self._session() as session:
            return [self._to_dict(r) for r in session.execute(stmt).scalars()]

    def get_projects(self) -> list[dict[str, Any]]:
        stmt = (
            select(
                QueryRow.project,
                func.count().label("query_count"),
                func.coalesce(func.sum(QueryRow.cost_usd), 0).label("total_cost_usd"),
                func.max(QueryRow.timestamp).label("last_seen"),
            )
            .group_by(QueryRow.project)
            .order_by(func.max(QueryRow.timestamp).desc())
        )
        with self._session() as session:
            return [dict(r._mapping) for r in session.execute(stmt)]

    def get_audit_log(self, since: datetime | None = None, limit: int = 100) -> list[dict[str, Any]]:
        stmt = (
            select(AuditLogRow)
            .order_by(AuditLogRow.timestamp.desc())
            .limit(max(1, min(limit, 1000)))
        )
        if since:
            stmt = stmt.where(AuditLogRow.timestamp >= since)
        with self._session() as session:
            return [self._to_dict(r) for r in session.execute(stmt).scalars()]

    def get_recent_pricing_snapshot(self) -> dict[str, Any] | None:
        stmt = select(PricingSnapshot).order_by(PricingSnapshot.captured_at.desc()).limit(1)
        with self._session() as session:
            row = session.execute(stmt).scalar_one_or_none()
            return self._to_dict(row) if row else None

    def get_latest_health_status(self, project: str) -> list[dict[str, Any]]:
        """Latest metric row per (service, metric) pair — Health dashboard status cards."""
        # MAX(rowid) picks the last inserted row per group, breaking timestamp ties.
        from sqlalchemy import text
        sql = text("""
            SELECT h.* FROM health_metrics h
            WHERE h.project = :project
              AND h.rowid IN (
                SELECT MAX(rowid) FROM health_metrics
                WHERE project = :project
                GROUP BY service, metric
              )
            ORDER BY h.service, h.metric
        """)
        with self._session() as session:
            rows = session.execute(sql, {"project": project}).mappings().all()
            return [dict(r) for r in rows]

    def get_health_history(
        self,
        project: str,
        service: str | None = None,
        hours: int = 24,
    ) -> list[dict[str, Any]]:
        """Time-series health metrics — sparkline charts."""
        return self.get_health_metrics(project=project, service=service, hours=hours)

    def get_unacknowledged_alerts(self, project: str) -> list[dict[str, Any]]:
        """Alerts with acknowledged = FALSE — dashboard banners."""
        return self.get_alerts(project=project, include_acknowledged=False)

    def export_queries(self, project: str | None, since: datetime | None = None) -> list[dict[str, Any]]:
        conditions = self._query_conditions(project=project, since=since)
        stmt = select(QueryRow).order_by(QueryRow.timestamp.asc())
        if conditions:
            stmt = stmt.where(and_(*conditions))
        with self._session() as session:
            return [self._to_dict(r) for r in session.execute(stmt).scalars()]

    # ── private helpers ───────────────────────────────────────────────────────

    def _run_migrations(self) -> None:
        """Ensure PRAGMA user_version is up-to-date. Phase 1: only migration 001."""
        migrations_dir = Path(__file__).parent / "migrations"
        with self._engine.connect() as conn:
            from sqlalchemy import text
            version = int(conn.execute(text("PRAGMA user_version")).scalar() or 0)
            if version < 1:
                # Tables were already created by create_all(); just stamp the version.
                conn.execute(text("PRAGMA user_version = 1"))
                conn.commit()

    @contextmanager
    def _session(self) -> Generator[Session, None, None]:
        with Session(self._engine) as session:
            yield session

    def _query_conditions(
        self,
        project: str | None = None,
        model: str | None = None,
        feature: str | None = None,
        since: datetime | None = None,
    ) -> list[Any]:
        conditions: list[Any] = []
        if project:
            conditions.append(QueryRow.project == project)
        if model:
            conditions.append(QueryRow.model == model)
        if feature:
            conditions.append(QueryRow.feature.like(f"%{feature}%"))
        effective_since = self._apply_history_floor(since)
        if effective_since:
            conditions.append(QueryRow.timestamp >= effective_since)
        return conditions

    def _time_bucket(self, column: Any, granularity: str) -> Any:
        dialect = self._engine.dialect.name
        if dialect == "postgresql":
            trunc = "hour" if granularity == "hour" else "day"
            fmt = "YYYY-MM-DD HH24:00:00" if granularity == "hour" else "YYYY-MM-DD"
            return func.to_char(func.date_trunc(trunc, column), fmt)
        if dialect in ("mysql", "mariadb"):
            fmt = "%Y-%m-%d %H:00:00" if granularity == "hour" else "%Y-%m-%d"
            return func.date_format(column, fmt)
        # SQLite (default)
        fmt = "%Y-%m-%d %H:00:00" if granularity == "hour" else "%Y-%m-%d"
        return func.strftime(fmt, column)

    def _since_for_days(self, days: int) -> datetime | None:
        if days < 0 and self.history_days_limit < 0:
            return None
        effective_days = days if days >= 0 else self.history_days_limit
        if self.history_days_limit >= 0:
            effective_days = min(effective_days, self.history_days_limit)
        return datetime.now(timezone.utc) - timedelta(days=effective_days)

    def _apply_history_floor(self, since: datetime | None) -> datetime | None:
        if self.history_days_limit < 0:
            return since
        floor = datetime.now(timezone.utc) - timedelta(days=self.history_days_limit)
        if since is None:
            return floor
        if since.tzinfo is None:
            since = since.replace(tzinfo=timezone.utc)
        return max(since, floor)

    def _to_dict(self, obj: Any) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for prop in obj.__mapper__.column_attrs:
            col = prop.columns[0]
            value = getattr(obj, prop.key)
            if isinstance(value, datetime):
                if value.tzinfo:
                    value = value.astimezone(timezone.utc).replace(tzinfo=None)
                value = value.isoformat(sep=" ", timespec="seconds")
            result[col.name] = value
        return decrypt_row(result, self._fernet)

    @staticmethod
    def _pick(payload: dict[str, Any], model: type) -> dict[str, Any]:
        # Build a map from DB column name → Python attr name so ORM constructor
        # receives the correct keyword arguments
        attr_by_col: dict[str, str] = {
            prop.columns[0].name: prop.key
            for prop in model.__mapper__.column_attrs
        }
        return {attr_by_col[k]: v for k, v in payload.items() if k in attr_by_col}

    @staticmethod
    def _make_engine(db: str | Path, read_only: bool) -> Engine:
        from sqlalchemy.pool import StaticPool

        text = str(db)
        # Non-SQLite URLs (postgres, mysql) pass through without encryption
        if "://" in text and not text.startswith("sqlite"):
            return create_engine(text)

        db_path = Path(text).resolve()
        db_path.parent.mkdir(parents=True, exist_ok=True)
        key = sqlcipher_key()

        try:
            import sqlcipher3.dbapi2 as sqlcipher  # type: ignore[import]

            def _creator() -> Any:
                flags = 1 if read_only else 6  # SQLITE_OPEN_READONLY vs READWRITE|CREATE
                conn = sqlcipher.connect(str(db_path), check_same_thread=False)
                conn.execute(f"PRAGMA key=\"x'{key}'\"")  # hex literal form avoids quote injection
                conn.execute("PRAGMA kdf_iter=64000")
                if not read_only:
                    conn.execute("PRAGMA journal_mode=WAL")
                    conn.execute("PRAGMA synchronous=NORMAL")
                    conn.execute("PRAGMA foreign_keys=ON")
                return conn

            return create_engine("sqlite+pysqlite://", creator=_creator, poolclass=StaticPool)

        except ImportError:
            # sqlcipher3 not installed — fall back to plain SQLite with a warning
            import warnings
            warnings.warn(
                "sqlcipher3 not installed: local database is NOT encrypted. "
                "Install with: pip install sqlcipher3",
                stacklevel=4,
            )
            from sqlalchemy import event
            url = f"sqlite:///{db_path}"
            engine = create_engine(url, connect_args={"check_same_thread": False}, poolclass=StaticPool)
            if not read_only:
                @event.listens_for(engine, "connect")
                def _set_pragma(dbapi_conn: Any, _: Any) -> None:
                    cur = dbapi_conn.cursor()
                    cur.execute("PRAGMA journal_mode=WAL")
                    cur.execute("PRAGMA synchronous=NORMAL")
                    cur.execute("PRAGMA foreign_keys=ON")
                    cur.close()
            return engine
