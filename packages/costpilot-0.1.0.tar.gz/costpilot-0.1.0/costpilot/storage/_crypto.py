from __future__ import annotations

import base64
import hashlib
import hmac
import os
import platform
from pathlib import Path
from typing import Any

from cryptography.fernet import Fernet  # type: ignore[import]

# Embedded salts — different per layer so keys are independent
_SQLCIPHER_SALT = b"costpilot-sqlcipher-v1"
_FIELD_SALT     = b"costpilot-fields-v1"

# Fields encrypted at the row level (defense-in-depth for privacy identifiers)
ENCRYPTED_FIELDS: frozenset[str] = frozenset({"user_id_hash", "session_id_hash"})


def _machine_bytes() -> bytes:
    # 1. Explicit override — set COSTPILOT_MACHINE_ID in container environments
    override = os.environ.get("COSTPILOT_MACHINE_ID")
    if override:
        return override.encode("utf-8")
    # 2. Linux /etc/machine-id — stable across reboots, survives container restarts
    try:
        mid = Path("/etc/machine-id").read_text().strip()
        if mid:
            return mid.encode("utf-8")
    except OSError:
        pass
    # 3. Fallback: hostname + arch (platform.processor() returns "" on Linux containers)
    return (platform.node() + platform.machine()).encode("utf-8", errors="replace")


def sqlcipher_key() -> str:
    """32-byte hex key for `PRAGMA key`. Re-derived every process start, never stored."""
    # key=machine_bytes (entropy), msg=salt (domain separator) — not the other way around
    return hmac.new(_machine_bytes(), _SQLCIPHER_SALT, hashlib.sha256).hexdigest()


def field_fernet() -> Fernet:
    """Fernet instance for field-level encryption of privacy identifiers."""
    raw = hmac.new(_machine_bytes(), _FIELD_SALT, hashlib.sha256).digest()
    return Fernet(base64.urlsafe_b64encode(raw))


def encrypt_row(row: dict[str, Any], fernet: Fernet) -> dict[str, Any]:
    out = dict(row)
    for field in ENCRYPTED_FIELDS:
        if out.get(field) is not None:
            out[field] = fernet.encrypt(str(out[field]).encode()).decode()
    return out


def decrypt_row(row: dict[str, Any], fernet: Fernet) -> dict[str, Any]:
    out = dict(row)
    for field in ENCRYPTED_FIELDS:
        if out.get(field) is not None:
            try:
                out[field] = fernet.decrypt(str(out[field]).encode()).decode()
            except Exception:
                pass  # legacy unencrypted row — leave as-is
    return out
