from __future__ import annotations

import re


def redis_pattern(key: str) -> str:
    """Redact likely variable Redis key segments while keeping grouping useful."""
    parts = key.split(":")
    redacted = []
    for part in parts:
        if re.fullmatch(r"[0-9a-fA-F-]{6,}", part) or any(char.isdigit() for char in part):
            redacted.append("*")
        elif "@" in part:
            redacted.append("*")
        else:
            redacted.append(part)
    return ":".join(redacted)
