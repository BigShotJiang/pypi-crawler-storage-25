from __future__ import annotations

import json
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from typing import Any

from ..exceptions import InsufficientDataError


class ScenarioEngine:
    def __init__(self, store: Any, pricing: Any) -> None:
        self._store = store
        self._pricing = pricing

    def project(
        self,
        project: str,
        daily_users: int,
        queries_per_user: int,
        period_days: int = 30,
    ) -> dict[str, Any]:
        query_count = self._store.count_queries(project)
        if query_count < 500:
            raise InsufficientDataError(
                f"Need 500+ queries to project. Have {query_count}. Keep running for 3-5 days."
            )
        span = self._store.data_span_days(project)
        if span < 3:
            days_remaining = 3 - span
            raise InsufficientDataError(
                f"Need 3+ days of data. {days_remaining:.1f} days remaining."
            )

        rows = self._recent_queries(project, period_days)
        if len(rows) < 10:
            return {"error": "insufficient_data", "message": "Capture at least 10 queries before projecting."}

        total = len(rows)
        avg_input = sum(row["input_tokens"] for row in rows) / total
        avg_output = sum(row["output_tokens"] for row in rows) / total
        avg_cache_read = sum(row.get("cache_read_tokens") or 0 for row in rows) / total
        avg_cache_write = sum(row.get("cache_write_tokens") or 0 for row in rows) / total
        avg_cost = sum(row["cost_usd"] for row in rows) / total
        model_counts = Counter(row["model"] for row in rows)
        model_costs: dict[str, list[float]] = defaultdict(list)
        for row in rows:
            model_costs[row["model"]].append(float(row["cost_usd"] or 0))

        model_mix = {model: count / total for model, count in model_counts.items()}
        queries_per_month = int(daily_users * queries_per_user * 30)
        by_model_usd = {
            model: round(queries_per_month * proportion * _avg(model_costs[model]), 2)
            for model, proportion in model_mix.items()
        }
        monthly_cost_usd = round(sum(by_model_usd.values()), 2)
        monthly_cost_inr = round(monthly_cost_usd * self._pricing.usd_to_inr, 2)

        return {
            "project": project,
            "inputs": {
                "daily_users": daily_users,
                "queries_per_user": queries_per_user,
                "period_days": period_days,
            },
            "measured_baseline": {
                "queries_observed": total,
                "avg_input_tokens": round(avg_input),
                "avg_output_tokens": round(avg_output),
                "avg_cache_read_tokens": round(avg_cache_read),
                "avg_cache_write_tokens": round(avg_cache_write),
                "avg_cost_per_query_usd": round(avg_cost, 8),
                "model_mix": model_mix,
            },
            "projection": {
                "queries_per_month": queries_per_month,
                "monthly_cost_usd": monthly_cost_usd,
                "monthly_cost_inr": monthly_cost_inr,
                "by_model_usd": by_model_usd,
            },
            "optimizations": self._fixed_optimizations(monthly_cost_usd),
        }

    def pre_migration_report(self, project: str, target_cloud: str, period_days: int = 14) -> dict[str, Any]:
        span = self._store.data_span_days(project)
        if span < 14:
            days_remaining = 14 - span
            raise InsufficientDataError(
                f"Migration plan needs 14 days of data. {days_remaining:.1f} days remaining."
            )

        target_cloud = target_cloud.lower()
        stats = self._store.get_project_stats(project, period_days)
        service_stats = self._store.get_service_stats(project, period_days)
        scale_to_month = 30 / max(period_days, 1)
        llm_monthly = round(float(stats["total_cost_usd"]) * scale_to_month, 2)

        line_items = [
            {
                "service": "LLM inference",
                "tier": "Measured provider mix",
                "based_on": f"{stats['total_queries']} queries measured over {period_days} days",
                "monthly_cost_usd": llm_monthly,
                "monthly_cost_inr": round(llm_monthly * self._pricing.usd_to_inr, 2),
            }
        ]
        for stat in service_stats:
            cost = self._service_monthly_cost(target_cloud, stat, scale_to_month)
            line_items.append(
                {
                    "service": self._service_name(target_cloud, stat["service"]),
                    "tier": self._pricing.infrastructure_rate(target_cloud, stat["service"]).get("tier", "Projected"),
                    "based_on": f"{round(stat['units'], 2)} units over {period_days} days measured",
                    "monthly_cost_usd": cost,
                    "monthly_cost_inr": round(cost * self._pricing.usd_to_inr, 2),
                }
            )

        total_usd = round(sum(item["monthly_cost_usd"] for item in line_items), 2)
        report = {
            "project": project,
            "target_cloud": target_cloud,
            "period_days": period_days,
            "generated_at": datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
            "line_items": line_items,
            "totals": {
                "monthly_cost_usd": total_usd,
                "monthly_cost_inr": round(total_usd * self._pricing.usd_to_inr, 2),
            },
            "caveats": [
                f"Based on {period_days} days of measured usage; actual cost will vary with traffic.",
                "Provider rates come from the checked-in CostPilot pricing registry.",
                "Does not include egress, monitoring, backup, or support costs.",
            ],
        }
        self._store.insert_migration_report(project, target_cloud, report, total_usd)
        return report

    def generate_freeform_scenario(
        self,
        project: str,
        prompt: str,
        period_days: int = 30,
    ) -> dict[str, Any]:
        """Gemini-powered free-form scenario (Pro/Enterprise only).

        Applies the same minimum data gates as project(), then builds a
        structured context summary and calls gemini-2.0-flash to produce
        a projection in the same shape as project().
        """
        query_count = self._store.count_queries(project)
        if query_count < 500:
            raise InsufficientDataError(
                f"Need 500+ queries to project. Have {query_count}. Keep running for 3-5 days."
            )
        span = self._store.data_span_days(project)
        if span < 3:
            days_remaining = 3 - span
            raise InsufficientDataError(
                f"Need 3+ days of data. {days_remaining:.1f} days remaining."
            )

        rows = self._recent_queries(project, period_days)
        if len(rows) < 10:
            return {"error": "insufficient_data", "message": "Capture at least 10 queries before projecting."}

        total = len(rows)
        avg_input = sum(r["input_tokens"] for r in rows) / total
        avg_output = sum(r["output_tokens"] for r in rows) / total
        avg_cost = sum(r["cost_usd"] for r in rows) / total
        model_counts = Counter(r["model"] for r in rows)
        model_mix = {m: c / total for m, c in model_counts.items()}

        context_summary = {
            "queries_observed": total,
            "avg_input_tokens": round(avg_input),
            "avg_output_tokens": round(avg_output),
            "avg_cost_per_query_usd": round(avg_cost, 8),
            "model_mix": model_mix,
            "period_days": period_days,
        }

        try:
            from google import genai  # type: ignore[import]

            client = genai.Client()
            system_ctx = (
                "You are a cost projection assistant for LLM workloads. "
                "Given aggregate usage metrics (no prompt content), project monthly cost "
                "for the described scenario. Return strict JSON with fields: "
                "daily_users (int), queries_per_user (int), monthly_cost_usd (float), "
                "monthly_cost_inr (float), rationale (string)."
            )
            user_msg = (
                f"Usage profile:\n{json.dumps(context_summary, indent=2)}\n\n"
                f"Scenario: {prompt}"
            )
            response = client.models.generate_content(
                model="gemini-2.0-flash",
                contents=[{"role": "user", "parts": [{"text": f"{system_ctx}\n\n{user_msg}"}]}],
            )
            raw_text = response.text.strip()
            # Strip markdown code fences if present
            if raw_text.startswith("```"):
                raw_text = raw_text.split("```")[1]
                if raw_text.startswith("json"):
                    raw_text = raw_text[4:]
            gemini_data = json.loads(raw_text)
        except Exception as exc:
            gemini_data = {
                "rationale": f"Gemini call failed: {exc}. Falling back to heuristic projection.",
                "daily_users": 1000,
                "queries_per_user": 5,
                "monthly_cost_usd": round(avg_cost * 1000 * 5 * 30, 2),
                "monthly_cost_inr": round(avg_cost * 1000 * 5 * 30 * self._pricing.usd_to_inr, 2),
            }

        daily_users = int(gemini_data.get("daily_users") or 1000)
        queries_per_user = int(gemini_data.get("queries_per_user") or 5)
        monthly_cost_usd = float(gemini_data.get("monthly_cost_usd") or 0)
        monthly_cost_inr = float(gemini_data.get("monthly_cost_inr") or monthly_cost_usd * self._pricing.usd_to_inr)

        return {
            "project": project,
            "freeform_prompt": prompt,
            "inputs": {
                "daily_users": daily_users,
                "queries_per_user": queries_per_user,
                "period_days": period_days,
            },
            "measured_baseline": context_summary,
            "projection": {
                "queries_per_month": daily_users * queries_per_user * 30,
                "monthly_cost_usd": round(monthly_cost_usd, 2),
                "monthly_cost_inr": round(monthly_cost_inr, 2),
                "by_model_usd": {},
            },
            "optimizations": self._fixed_optimizations(monthly_cost_usd),
            "rationale": gemini_data.get("rationale", ""),
            "powered_by": "gemini-2.0-flash",
        }

    def project_from_records(
        self,
        project: str,
        daily_users: int,
        queries_per_user: int,
        n: int = 10,
    ) -> dict[str, Any]:
        """Trial-safe projection using the last N records. No days/count gates."""
        all_rows = self._store.get_queries_paginated(project=project, since=None, limit=5000, offset=0)
        rows = sorted(all_rows, key=lambda r: str(r.get("timestamp") or ""), reverse=True)[:n]

        if len(rows) < 10:
            return {
                "error": "insufficient_data",
                "message": f"Capture at least 10 queries before projecting. Have {len(rows)}.",
            }

        total = len(rows)
        avg_input = sum(float(row.get("input_tokens") or 0) for row in rows) / total
        avg_output = sum(float(row.get("output_tokens") or 0) for row in rows) / total
        avg_cache_read = sum(float(row.get("cache_read_tokens") or 0) for row in rows) / total
        avg_cache_write = sum(float(row.get("cache_write_tokens") or 0) for row in rows) / total
        avg_cost = sum(float(row.get("cost_usd") or 0) for row in rows) / total
        model_counts = Counter(str(row.get("model") or "unknown") for row in rows)
        model_costs: dict[str, list[float]] = defaultdict(list)
        for row in rows:
            model_costs[str(row.get("model") or "unknown")].append(float(row.get("cost_usd") or 0))

        model_mix = {model: count / total for model, count in model_counts.items()}
        queries_per_month = int(daily_users * queries_per_user * 30)
        by_model_usd = {
            model: round(queries_per_month * proportion * _avg(model_costs[model]), 2)
            for model, proportion in model_mix.items()
        }
        monthly_cost_usd = round(sum(by_model_usd.values()), 2)
        monthly_cost_inr = round(monthly_cost_usd * self._pricing.usd_to_inr, 2)

        return {
            "project": project,
            "inputs": {
                "daily_users": daily_users,
                "queries_per_user": queries_per_user,
                "sample_records": n,
            },
            "measured_baseline": {
                "queries_observed": total,
                "avg_input_tokens": round(avg_input),
                "avg_output_tokens": round(avg_output),
                "avg_cache_read_tokens": round(avg_cache_read),
                "avg_cache_write_tokens": round(avg_cache_write),
                "avg_cost_per_query_usd": round(avg_cost, 8),
                "model_mix": model_mix,
            },
            "projection": {
                "queries_per_month": queries_per_month,
                "monthly_cost_usd": monthly_cost_usd,
                "monthly_cost_inr": monthly_cost_inr,
                "by_model_usd": by_model_usd,
            },
            "optimizations": self._fixed_optimizations(monthly_cost_usd),
            "note": f"Sampled from {n} most recent records (trial mode).",
        }

    def generate_freeform_from_records(
        self,
        project: str,
        prompt: str,
        n: int = 10,
    ) -> dict[str, Any]:
        """Gemini free-form scenario using last N records. Trial-safe: no days/count gates."""
        all_rows = self._store.get_queries_paginated(project=project, since=None, limit=5000, offset=0)
        rows = sorted(all_rows, key=lambda r: str(r.get("timestamp") or ""), reverse=True)[:n]

        if len(rows) < 10:
            return {
                "error": "insufficient_data",
                "message": f"Capture at least 10 queries before projecting. Have {len(rows)}.",
            }

        total = len(rows)
        avg_input = sum(float(r.get("input_tokens") or 0) for r in rows) / total
        avg_output = sum(float(r.get("output_tokens") or 0) for r in rows) / total
        avg_cost = sum(float(r.get("cost_usd") or 0) for r in rows) / total
        model_counts = Counter(str(r.get("model") or "unknown") for r in rows)
        model_mix = {m: c / total for m, c in model_counts.items()}

        context_summary = {
            "queries_observed": total,
            "avg_input_tokens": round(avg_input),
            "avg_output_tokens": round(avg_output),
            "avg_cost_per_query_usd": round(avg_cost, 8),
            "model_mix": model_mix,
            "sample_records": n,
        }

        try:
            from google import genai  # type: ignore[import]

            client = genai.Client()
            system_ctx = (
                "You are a cost projection assistant for LLM workloads. "
                "Given aggregate usage metrics (no prompt content), project monthly cost "
                "for the described scenario. Return strict JSON with fields: "
                "daily_users (int), queries_per_user (int), monthly_cost_usd (float), "
                "monthly_cost_inr (float), rationale (string)."
            )
            user_msg = (
                f"Usage profile:\n{json.dumps(context_summary, indent=2)}\n\n"
                f"Scenario: {prompt}"
            )
            response = client.models.generate_content(
                model="gemini-2.0-flash",
                contents=[{"role": "user", "parts": [{"text": f"{system_ctx}\n\n{user_msg}"}]}],
            )
            raw_text = response.text.strip()
            if raw_text.startswith("```"):
                raw_text = raw_text.split("```")[1]
                if raw_text.startswith("json"):
                    raw_text = raw_text[4:]
            gemini_data = json.loads(raw_text)
        except Exception as exc:
            gemini_data = {
                "rationale": f"Gemini call failed: {exc}. Falling back to heuristic projection.",
                "daily_users": 1000,
                "queries_per_user": 5,
                "monthly_cost_usd": round(avg_cost * 1000 * 5 * 30, 2),
                "monthly_cost_inr": round(avg_cost * 1000 * 5 * 30 * self._pricing.usd_to_inr, 2),
            }

        daily_users = int(gemini_data.get("daily_users") or 1000)
        queries_per_user = int(gemini_data.get("queries_per_user") or 5)
        monthly_cost_usd = float(gemini_data.get("monthly_cost_usd") or 0)
        monthly_cost_inr = float(gemini_data.get("monthly_cost_inr") or monthly_cost_usd * self._pricing.usd_to_inr)

        return {
            "project": project,
            "freeform_prompt": prompt,
            "inputs": {
                "daily_users": daily_users,
                "queries_per_user": queries_per_user,
                "sample_records": n,
            },
            "measured_baseline": context_summary,
            "projection": {
                "queries_per_month": daily_users * queries_per_user * 30,
                "monthly_cost_usd": round(monthly_cost_usd, 2),
                "monthly_cost_inr": round(monthly_cost_inr, 2),
                "by_model_usd": {},
            },
            "optimizations": self._fixed_optimizations(monthly_cost_usd),
            "rationale": gemini_data.get("rationale", ""),
            "powered_by": "gemini-2.0-flash",
            "note": f"Sampled from {n} most recent records (trial mode).",
        }

    def _recent_queries(self, project: str, period_days: int) -> list[dict[str, Any]]:
        since = datetime.now(timezone.utc) - timedelta(days=period_days)
        return self._store.get_queries_paginated(project=project, since=since, limit=1000, offset=0)

    def _fixed_optimizations(self, monthly_cost_usd: float) -> list[dict[str, Any]]:
        candidates = [
            ("Cache system prompt", 0.34, "low", "Cache reads are cheaper than repeated full input tokens."),
            ("Route simple tasks to smaller models", 0.22, "medium", "Measured model mix can usually split easy requests onto cheaper models."),
            ("Trim RAG context", 0.18, "high", "Lower input token counts reduce spend on every provider."),
        ]
        return [
            {
                "title": title,
                "save_pct": save_pct,
                "save_usd": round(monthly_cost_usd * save_pct, 2),
                "save_inr": round(monthly_cost_usd * save_pct * self._pricing.usd_to_inr, 2),
                "effort": effort,
                "rationale": rationale,
            }
            for title, save_pct, effort, rationale in candidates
        ]

    def _service_monthly_cost(self, target_cloud: str, stat: dict[str, Any], scale_to_month: float) -> float:
        service = stat["service"]
        units = float(stat.get("units") or 0) * scale_to_month
        rate = self._pricing.infrastructure_rate(target_cloud, service)
        if service == "redis":
            return round(24 * 30 * float(rate.get("per_hour", 0) or 0), 2)
        if service == "qdrant":
            return round((units / 1_000_000) * float(rate.get("per_million_queries", 0) or 0), 2)
        if service == "appwrite":
            return round((units / 1_000_000) * float(rate.get("per_million_executions", 0) or 0), 2)
        return 0.0

    def _service_name(self, target_cloud: str, service: str) -> str:
        names = {
            "azure": {"redis": "Azure Cache for Redis", "qdrant": "Qdrant Cloud", "appwrite": "Appwrite Cloud"},
            "aws": {"redis": "ElastiCache Redis", "qdrant": "Qdrant Cloud", "appwrite": "Appwrite Cloud"},
            "gcp": {"redis": "Memorystore Redis", "qdrant": "Qdrant Cloud", "appwrite": "Appwrite Cloud"},
        }
        return names.get(target_cloud, {}).get(service, service)


def _avg(values: list[float]) -> float:
    return sum(values) / len(values) if values else 0.0
