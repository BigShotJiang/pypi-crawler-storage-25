from __future__ import annotations

import hashlib
import json
import os
import uuid
from typing import Any

from .auth import AuthState, resolve_auth_state
from .cloud_sync import CloudSyncQueue
from .config import CostPilotConfig, load_config
from .health import HealthPoller
from .interceptors.anthropic import AnthropicInterceptor
from .interceptors.foundry import FoundryInterceptor
from .interceptors.gemini import GeminiInterceptor
from .interceptors.openai import OpenAIInterceptor
from .pricing import PricingRegistry
from .privacy import DataSanitizer
from .scenario import ScenarioEngine
from .services import QdrantTracker, RedisTracker, track_appwrite
from .storage import SqliteStore


class CostPilotClient:
    def __init__(
        self,
        project: str,
        feature: str | None = None,
        user_id: str | None = None,
        session_id: str | None = None,
        config_path: str = ".costpilot.yaml",
    ) -> None:
        self.config: CostPilotConfig = load_config(config_path)
        self.project = project or self.config.project
        self.feature = feature
        self.user_id = user_id
        self.session_id = session_id
        self.sanitizer = DataSanitizer()

        db_url = os.getenv("COSTPILOT_DB") or self.config.storage_url
        self.store = SqliteStore(db_url, history_days_limit=-1, sync_enabled=self.config.api_key is not None)
        self.auth_state: AuthState = resolve_auth_state(self.config, store=self.store)
        self.mode = self.auth_state.mode
        self.tier = self.auth_state.tier
        self.limits = self.auth_state.limits
        self.store.history_days_limit = int(self.limits.get("history_days", -1) or -1)
        self.store.sync_enabled = self.mode == "cloud"

        self._check_salt_rotation()
        self.pricing = PricingRegistry(store=self.store, live=True)
        self._ensure_pricing_snapshot()
        self.scenario = ScenarioEngine(self.store, self.pricing)
        self.cloud_sync: CloudSyncQueue | None = None
        if self.mode == "cloud" and self.config.api_key:
            self.cloud_sync = CloudSyncQueue(store=self.store, api_key=self.config.api_key, project=self.project)
            self.cloud_sync.flush_unsynced(limit=100)

        self._poller: HealthPoller | None = None
        if self.config.health.enabled:
            self._poller = HealthPoller(
                config=self.config.health,
                store=self.store,
                project=self.project,
                services_cfg=self.config.services,
            )
            self._poller.start()

    def wrap(self, client: Any) -> Any:
        if self._is_foundry_client(client):
            return FoundryInterceptor(client, self)
        if self._is_anthropic_client(client):
            return AnthropicInterceptor(client, self)
        if self._is_openai_client(client):
            provider = "azure-openai" if self._is_azure_openai_client(client) else "openai"
            return OpenAIInterceptor(client, self, provider=provider)
        if self._is_gemini_client(client):
            return GeminiInterceptor(client, self)
        raise TypeError(f"Unsupported LLM client type: {type(client)!r}")

    def record_llm_call(
        self,
        *,
        provider: str,
        model: str,
        input_tokens: int,
        output_tokens: int,
        cache_read_tokens: int = 0,
        cache_write_tokens: int = 0,
        system_prompt_tokens: int = 0,
        context_tokens: int | None = None,
        embedding_tokens: int = 0,
        latency_ms: int | None = None,
    ) -> dict[str, Any]:
        cost = self.pricing.calculate_cost(
            model=model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cache_read_tokens=cache_read_tokens,
            cache_write_tokens=cache_write_tokens,
            provider=provider,
        )
        raw = {
            "id": str(uuid.uuid4()),
            "project": self.project,
            "feature": self.feature,
            "user_id_hash": self._hash_optional(self.user_id),
            "session_id_hash": self._hash_optional(self.session_id),
            "provider": provider,
            "model": model,
            "input_tokens": int(input_tokens or 0),
            "output_tokens": int(output_tokens or 0),
            "embedding_tokens": int(embedding_tokens or 0),
            "cache_read_tokens": int(cache_read_tokens or 0),
            "cache_write_tokens": int(cache_write_tokens or 0),
            "system_prompt_tokens": int(system_prompt_tokens or 0),
            "context_tokens": (
                int(context_tokens)
                if context_tokens is not None
                else max(0, int(input_tokens or 0) - int(system_prompt_tokens or 0) - 200)
            ),
            "cost_usd": cost,
            "latency_ms": latency_ms,
        }
        safe = self.sanitizer.sanitize_for_storage(raw)
        self.store.insert_query(safe)
        if self.cloud_sync:
            self.cloud_sync.push(safe)
        return safe

    def track_redis(self, operation: str, key_pattern: str) -> RedisTracker:
        return RedisTracker(self, operation, key_pattern)

    def track_qdrant(self, operation: str, collection: str) -> QdrantTracker:
        return QdrantTracker(self, operation, collection)

    def track_appwrite(self, service: str, operation: str):
        return track_appwrite(self, service, operation)

    def estimate_service_cost(self, service: str, operation: str, units: float) -> float:
        if self.config.environment == "local":
            return 0.0
        rate = self.pricing.infrastructure_rate(self.config.environment, service)
        if service == "redis":
            # Upstash: per_100k_commands. Azure/AWS/GCP: per_hour (assume ~60s operation = 1/3600 hour).
            if rate.get("per_100k_commands"):
                return round((units / 100_000) * float(rate["per_100k_commands"]), 8)
            if rate.get("per_hour"):
                return round((1 / 3600) * float(rate["per_hour"]), 8)
            return 0.0
        if service == "qdrant":
            return round((units / 1_000_000) * float(rate.get("per_million_queries", 0) or 0), 8)
        if service == "appwrite":
            return round((units / 1_000_000) * float(rate.get("per_million_executions", 0) or 0), 8)
        return 0.0

    def _check_salt_rotation(self) -> None:
        salt = self.config.privacy.salt
        salt_fingerprint = hashlib.sha256(salt.encode()).hexdigest()[:16]
        salt_state_path = self.config.state_dir / "salt-fingerprint.json"
        try:
            if salt_state_path.exists():
                stored = json.loads(salt_state_path.read_text()).get("fingerprint")
                if stored and stored != salt_fingerprint:
                    self.store.insert_audit_log(
                        {"event_type": "salt_rotated", "result": "info", "metadata": {"fingerprint": salt_fingerprint}}
                    )
            salt_state_path.write_text(json.dumps({"fingerprint": salt_fingerprint}))
        except OSError:
            pass

    def _ensure_pricing_snapshot(self) -> None:
        if self.store.get_recent_pricing_snapshot() is not None:
            return
        for row in self.pricing.snapshot_rows():
            self.store.insert_pricing_snapshot(row)

    def _hash_optional(self, value: str | None) -> str | None:
        if value is None:
            return None
        return self.sanitizer.hash_user_id(value, self.config.privacy.salt)

    def _is_anthropic_client(self, client: Any) -> bool:
        try:
            import anthropic

            candidates = [getattr(anthropic, "Anthropic", None), getattr(anthropic, "AsyncAnthropic", None)]
            return any(candidate and isinstance(client, candidate) for candidate in candidates)
        except Exception:
            return hasattr(client, "messages") and type(client).__module__.startswith("anthropic")

    def _is_openai_client(self, client: Any) -> bool:
        try:
            import openai

            candidates = [
                getattr(openai, "OpenAI", None),
                getattr(openai, "AsyncOpenAI", None),
                getattr(openai, "AzureOpenAI", None),
                getattr(openai, "AsyncAzureOpenAI", None),
            ]
            return any(candidate and isinstance(client, candidate) for candidate in candidates)
        except Exception:
            return hasattr(client, "chat") and hasattr(client, "embeddings")

    def _is_azure_openai_client(self, client: Any) -> bool:
        try:
            import openai

            candidates = [getattr(openai, "AzureOpenAI", None), getattr(openai, "AsyncAzureOpenAI", None)]
            return any(candidate and isinstance(client, candidate) for candidate in candidates)
        except Exception:
            return "Azure" in type(client).__name__

    def _is_gemini_client(self, client: Any) -> bool:
        try:
            from google import genai  # type: ignore[import]
            return isinstance(client, genai.Client)
        except Exception:
            return hasattr(client, "models") and hasattr(getattr(client, "models", None), "generate_content")

    def _is_foundry_client(self, client: Any) -> bool:
        try:
            from azure.ai.projects import AIProjectClient  # type: ignore[import]

            return isinstance(client, AIProjectClient)
        except ImportError:
            # azure-ai-projects not installed — fall back to duck typing
            return (
                hasattr(client, "get_openai_client")
                and not hasattr(client, "chat")
                and not hasattr(client, "messages")
            )
