from __future__ import annotations

import hashlib
import re
from typing import Any


class DataSanitizer:
    SAFE_FIELDS = {
        "id",
        "timestamp",
        "project",
        "feature",
        "user_id_hash",
        "session_id_hash",
        "provider",
        "model",
        "input_tokens",
        "output_tokens",
        "embedding_tokens",
        "cache_read_tokens",
        "cache_write_tokens",
        "system_prompt_tokens",
        "context_tokens",
        "cost_usd",
        "latency_ms",
    }

    def sanitize_for_storage(self, raw: dict[str, Any]) -> dict[str, Any]:
        return {key: value for key, value in raw.items() if key in self.SAFE_FIELDS}

    def hash_user_id(self, user_id: str, salt: str) -> str:
        return hashlib.sha256(f"{salt}:{user_id}".encode("utf-8")).hexdigest()[:16]

    def count_tokens_only(self, text: Any, model: str = "") -> int:
        if text is None:
            return 0
        normalized = self._flatten_text(text)
        if not normalized:
            return 0
        try:
            import tiktoken

            encoding = tiktoken.encoding_for_model(model or "gpt-4o-mini")
            return len(encoding.encode(normalized))
        except Exception:
            return max(1, len(re.findall(r"\S+", normalized)))

    def _flatten_text(self, text: Any) -> str:
        if isinstance(text, str):
            return text
        if isinstance(text, list):
            return " ".join(self._flatten_text(item) for item in text)
        if isinstance(text, dict):
            if "text" in text:
                return str(text["text"])
            return " ".join(self._flatten_text(value) for value in text.values())
        return str(text)
