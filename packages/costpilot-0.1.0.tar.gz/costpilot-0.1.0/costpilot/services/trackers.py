from __future__ import annotations

import functools
import json
import time
import uuid
from typing import Any, Callable


class RedisTracker:
    def __init__(self, cp_client: Any, operation: str, key_pattern: str) -> None:
        self._cp = cp_client
        self.operation = operation
        self.key_pattern = key_pattern
        self._hit: bool | None = None
        self.start = 0.0

    def __enter__(self) -> "RedisTracker":
        self.start = time.monotonic()
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        latency_ms = int((time.monotonic() - self.start) * 1000)
        self._cp.store.insert_service_usage(
            {
                "id": str(uuid.uuid4()),
                "project": self._cp.project,
                "service": "redis",
                "operation": self.operation,
                "units": 1,
                "estimated_cost_usd": self._cp.estimate_service_cost("redis", self.operation, 1),
                "metadata": json.dumps(
                    {"hit": self._hit, "key_pattern": self.key_pattern, "latency_ms": latency_ms}
                ),
            }
        )

    def record(self, hit: bool) -> None:
        self._hit = hit


class QdrantTracker:
    def __init__(self, cp_client: Any, operation: str, collection: str) -> None:
        self._cp = cp_client
        self.operation = operation
        self.collection = collection
        self._vectors = 0
        self._hits = 0
        self.start = 0.0

    def __enter__(self) -> "QdrantTracker":
        self.start = time.monotonic()
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        latency_ms = int((time.monotonic() - self.start) * 1000)
        units = self._vectors or 1
        self._cp.store.insert_service_usage(
            {
                "id": str(uuid.uuid4()),
                "project": self._cp.project,
                "service": "qdrant",
                "operation": self.operation,
                "units": units,
                "estimated_cost_usd": self._cp.estimate_service_cost("qdrant", self.operation, units),
                "metadata": json.dumps(
                    {
                        "collection": self.collection,
                        "vectors": self._vectors,
                        "hits": self._hits,
                        "latency_ms": latency_ms,
                    }
                ),
            }
        )

    def record(self, vectors_searched: int = 0, hits: int = 0) -> None:
        self._vectors = vectors_searched
        self._hits = hits


def track_appwrite(cp_client: Any, service: str, operation: str) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            start = time.monotonic()
            status = "success"
            try:
                return fn(*args, **kwargs)
            except Exception:
                status = "error"
                raise
            finally:
                latency_ms = int((time.monotonic() - start) * 1000)
                cp_client.store.insert_service_usage(
                    {
                        "id": str(uuid.uuid4()),
                        "project": cp_client.project,
                        "service": "appwrite",
                        "operation": operation,
                        "units": 1,
                        "estimated_cost_usd": cp_client.estimate_service_cost("appwrite", operation, 1),
                        "metadata": json.dumps(
                            {"function": service, "status": status, "latency_ms": latency_ms}
                        ),
                    }
                )

        return wrapper

    return decorator
