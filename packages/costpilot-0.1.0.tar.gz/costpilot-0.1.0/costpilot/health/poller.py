from __future__ import annotations

import logging
import threading
import time
import uuid
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from costpilot.config import HealthConfig
    from costpilot.storage import SqliteStore

LOGGER = logging.getLogger("costpilot.health")


class HealthPoller:
    """Background daemon thread — polls Redis, Qdrant, Appwrite every poll_interval_sec.

    Never raises into the main app. All failures are logged and swallowed.
    """

    def __init__(self, config: "HealthConfig", store: "SqliteStore", project: str, services_cfg: dict[str, Any]) -> None:
        self._config = config
        self._store = store
        self._project = project
        self._services = services_cfg
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        if not self._config.enabled:
            return
        self._thread = threading.Thread(target=self._run, daemon=True, name="costpilot-health")
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()

    # ── main loop ────────────────────────────────────────────────────────────

    def _run(self) -> None:
        while not self._stop.is_set():
            try:
                self._poll_all()
            except Exception:
                LOGGER.debug("health poll cycle failed", exc_info=True)
            self._stop.wait(self._config.poll_interval_sec)

    def _poll_all(self) -> None:
        redis_cfg = self._services.get("redis") or {}
        if redis_cfg.get("enabled"):
            self._poll_redis(redis_cfg)

        qdrant_cfg = self._services.get("qdrant") or {}
        if qdrant_cfg.get("enabled"):
            self._poll_qdrant(qdrant_cfg)

        appwrite_cfg = self._services.get("appwrite") or {}
        if appwrite_cfg.get("enabled"):
            self._poll_appwrite(appwrite_cfg)

    # ── service pollers ──────────────────────────────────────────────────────

    def _poll_redis(self, cfg: dict[str, Any]) -> None:
        try:
            import redis  # type: ignore[import]
            host = cfg.get("host", "localhost")
            port = int(cfg.get("port", 6379))
            start = time.monotonic()
            r = redis.Redis(host=host, port=port, socket_connect_timeout=2, socket_timeout=2)
            info = r.info("memory")
            latency_ms = int((time.monotonic() - start) * 1000)
            used = int(info.get("used_memory", 0))
            max_mem = int(info.get("maxmemory", 0))
            memory_pct = (used / max_mem * 100) if max_mem > 0 else 0.0

            self._record("redis", "latency_ms", latency_ms, self._config.alerts.qdrant_latency_ms)
            self._record("redis", "memory_pct", memory_pct, self._config.alerts.redis_memory_pct)
        except Exception:
            LOGGER.debug("redis health poll failed", exc_info=True)

    def _poll_qdrant(self, cfg: dict[str, Any]) -> None:
        try:
            import httpx
            host = cfg.get("host", "localhost")
            port = int(cfg.get("port", 6333))
            start = time.monotonic()
            resp = httpx.get(f"http://{host}:{port}/healthz", timeout=2.0)
            latency_ms = int((time.monotonic() - start) * 1000)
            resp.raise_for_status()
            self._record("qdrant", "latency_ms", latency_ms, self._config.alerts.qdrant_latency_ms)
        except Exception:
            LOGGER.debug("qdrant health poll failed", exc_info=True)

    def _poll_appwrite(self, cfg: dict[str, Any]) -> None:
        try:
            import httpx
            endpoint = cfg.get("endpoint", "http://localhost/v1")
            start = time.monotonic()
            resp = httpx.get(f"{endpoint}/health", timeout=3.0)
            latency_ms = int((time.monotonic() - start) * 1000)
            resp.raise_for_status()
            self._record("appwrite", "latency_ms", latency_ms, self._config.alerts.appwrite_latency_ms)
        except Exception:
            LOGGER.debug("appwrite health poll failed", exc_info=True)

    # ── helpers ──────────────────────────────────────────────────────────────

    def _record(self, service: str, metric: str, value: float, threshold: float) -> None:
        if value >= threshold * 1.5:
            status = "critical"
        elif value >= threshold:
            status = "warning"
        else:
            status = "healthy"

        try:
            self._store.insert_health_metric({
                "id": str(uuid.uuid4()),
                "project": self._project,
                "service": service,
                "metric": metric,
                "value": value,
                "status": status,
            })
        except Exception:
            LOGGER.debug("failed to write health metric", exc_info=True)

        if status in ("warning", "critical"):
            alert_type = f"{metric}_high" if metric != "latency_ms" else "latency_spike"
            if not self._store.alert_fired_recently(self._project, alert_type, service, window_minutes=30):
                try:
                    self._store.insert_alert({
                        "id": str(uuid.uuid4()),
                        "project": self._project,
                        "alert_type": alert_type,
                        "service": service,
                        "message": f"{service} {metric} is {status}: {value:.1f} (threshold {threshold:.1f})",
                        "value": value,
                        "threshold": threshold,
                        "acknowledged": False,
                    })
                except Exception:
                    LOGGER.debug("failed to write alert", exc_info=True)
