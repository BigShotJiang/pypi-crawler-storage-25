from __future__ import annotations

import logging
import os
import secrets
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from .exceptions import ConfigError

LOGGER = logging.getLogger("costpilot.config")

ENVIRONMENTS = {"local", "azure", "aws", "gcp"}


@dataclass(frozen=True)
class PrivacyConfig:
    hash_user_ids: bool = True
    salt: str = ""
    capture_prompts: bool = False


@dataclass(frozen=True)
class StorageConfig:
    path: str = "./.costpilot/data.db"
    url: str | None = None  # SQLAlchemy URL; overrides path when set (postgresql://, mysql://, etc.)


@dataclass(frozen=True)
class DashboardConfig:
    port: int = 3721


@dataclass(frozen=True)
class LlmConfig:
    providers: list[str] = field(default_factory=lambda: ["anthropic", "azure-openai", "openai"])
    azure_openai: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class HealthAlertsConfig:
    redis_memory_pct: float = 80.0
    qdrant_latency_ms: float = 500.0
    appwrite_latency_ms: float = 1000.0
    cost_spike_pct: float = 200.0
    llm_error_rate_pct: float = 5.0


@dataclass(frozen=True)
class HealthConfig:
    enabled: bool = True
    poll_interval_sec: int = 60
    alerts: HealthAlertsConfig = field(default_factory=HealthAlertsConfig)


@dataclass(frozen=True)
class CostPilotConfig:
    project: str
    environment: str
    api_key: str | None
    license_key: str | None
    privacy: PrivacyConfig
    llm: LlmConfig
    services: dict[str, Any]
    storage: StorageConfig
    dashboard: DashboardConfig
    health: HealthConfig
    cloud: dict[str, Any]
    config_path: Path
    warnings: tuple[str, ...] = ()

    @property
    def base_dir(self) -> Path:
        return self.config_path.parent

    @property
    def storage_path(self) -> Path:
        return resolve_path(self.storage.path, self.base_dir)

    @property
    def state_dir(self) -> Path:
        return self.storage_path.parent

    @property
    def storage_url(self) -> str:
        """SQLAlchemy connection URL. Uses storage.url when set, otherwise builds sqlite:/// from storage.path."""
        if self.storage.url:
            return self.storage.url
        return f"sqlite:///{self.storage_path.resolve()}"

    @property
    def mode_hint(self) -> str:
        return "cloud" if self.api_key else "self-host"


def resolve_path(path: str | os.PathLike[str], base_dir: Path | None = None) -> Path:
    raw = Path(path).expanduser()
    if raw.is_absolute():
        return raw
    return (base_dir or Path.cwd()) / raw


def load_config(config_path: str | os.PathLike[str] = ".costpilot.yaml") -> CostPilotConfig:
    env_path = os.getenv("COSTPILOT_CONFIG")
    path = Path(env_path or config_path).expanduser()
    if not path.is_absolute():
        path = Path.cwd() / path

    if not path.exists():
        raise ConfigError(
            f"No auth key found in {path}. Run 'costpilot init' to sign up or paste an existing key."
        )

    raw = yaml.safe_load(path.read_text()) or {}
    warnings: list[str] = []

    project = str(raw.get("project") or path.parent.name)
    environment = str(raw.get("environment") or "local")
    if environment not in ENVIRONMENTS:
        raise ConfigError(f"Unsupported environment '{environment}'. Expected one of {sorted(ENVIRONMENTS)}.")

    api_key = _blank_to_none(raw.get("api_key"))
    license_key = _blank_to_none(raw.get("license_key"))
    if api_key and license_key:
        warnings.append("Both api_key and license_key are set; api_key wins and CLOUD mode is selected.")
        license_key = None
    if not api_key and not license_key:
        raise ConfigError(
            "No auth key found in .costpilot.yaml. Run 'costpilot init' to sign up or paste an existing key."
        )
    if api_key and not api_key.startswith("cp_live_sk_"):
        raise ConfigError("api_key must start with 'cp_live_sk_'.")
    if api_key and len(api_key) != 43:
        raise ConfigError("api_key must be 43 characters (cp_live_sk_ + 32 hex chars).")
    if license_key and not license_key.startswith("cpl_lic_"):
        raise ConfigError("license_key must start with 'cpl_lic_'.")
    if license_key and len(license_key) != 40:
        raise ConfigError("license_key must be 40 characters (cpl_lic_ + 32 hex chars).")

    privacy_raw = raw.get("privacy") or {}
    if privacy_raw.get("hash_user_ids") is False:
        warnings.append("privacy.hash_user_ids is fixed to true; ignoring configured false value.")
    if privacy_raw.get("capture_prompts") is True:
        warnings.append("privacy.capture_prompts is fixed to false; ignoring configured true value.")
    for warning in warnings:
        LOGGER.warning(warning)

    privacy = PrivacyConfig(
        hash_user_ids=True,
        salt=str(privacy_raw.get("salt") or ""),
        capture_prompts=False,
    )

    llm_raw = raw.get("llm") or {}
    llm = LlmConfig(
        providers=list(llm_raw.get("providers") or ["anthropic", "azure-openai", "openai"]),
        azure_openai=dict(llm_raw.get("azure_openai") or {}),
    )

    storage_raw = raw.get("storage") or {}
    storage = StorageConfig(
        path=str(storage_raw.get("path") or "./.costpilot/data.db"),
        url=_blank_to_none(storage_raw.get("url")),
    )
    dashboard = DashboardConfig(port=int((raw.get("dashboard") or {}).get("port") or 3721))

    health_raw = raw.get("health") or {}
    alerts_raw = health_raw.get("alerts") or {}
    health = HealthConfig(
        enabled=bool(health_raw.get("enabled", True)),
        poll_interval_sec=int(health_raw.get("poll_interval_sec") or 60),
        alerts=HealthAlertsConfig(
            redis_memory_pct=float(alerts_raw.get("redis_memory_pct") or 80),
            qdrant_latency_ms=float(alerts_raw.get("qdrant_latency_ms") or 500),
            appwrite_latency_ms=float(alerts_raw.get("appwrite_latency_ms") or 1000),
            cost_spike_pct=float(alerts_raw.get("cost_spike_pct") or 200),
            llm_error_rate_pct=float(alerts_raw.get("llm_error_rate_pct") or 5),
        ),
    )

    return CostPilotConfig(
        project=project,
        environment=environment,
        api_key=api_key,
        license_key=license_key,
        privacy=privacy,
        llm=llm,
        services=dict(raw.get("services") or {}),
        storage=storage,
        dashboard=dashboard,
        health=health,
        cloud=dict(raw.get("cloud") or {}),
        config_path=path,
        warnings=tuple(warnings),
    )


def generate_default_config(
    project: str,
    *,
    api_key: str | None = None,
    license_key: str | None = None,
    salt: str | None = None,
) -> dict[str, Any]:
    if bool(api_key) == bool(license_key):
        raise ConfigError("Exactly one of api_key or license_key is required.")
    return {
        "project": project,
        "environment": "local",
        "api_key": api_key or "",
        "license_key": license_key or "",
        "privacy": {
            "hash_user_ids": True,
            "salt": salt or secrets.token_hex(16),
            "capture_prompts": False,
        },
        "llm": {
            "providers": ["anthropic", "azure-openai", "openai"],
            "azure_openai": {"deployment_type": "payg", "region": "eastus"},
        },
        "services": {
            "redis": {"enabled": True, "mode": "docker", "host": "localhost", "port": 6379},
            "qdrant": {"enabled": True, "mode": "docker", "host": "localhost", "port": 6333},
            "appwrite": {"enabled": True, "mode": "docker", "endpoint": "http://localhost/v1"},
        },
        "storage": {"path": "./.costpilot/data.db", "url": ""},
        "dashboard": {"port": 3721},
        "cloud": {
            "region": "ap-south-1",
            "azure": {"subscription_id": "", "resource_group": ""},
        },
    }


def write_config(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(payload, sort_keys=False))


def _blank_to_none(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None
