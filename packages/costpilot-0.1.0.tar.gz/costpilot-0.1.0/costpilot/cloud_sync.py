from __future__ import annotations

import queue
import threading
from typing import Any

import httpx

from .constants import resolve_costpilot_api_base


LOCAL_ONLY_FIELDS = {"id", "timestamp", "synced_to_cloud"}


class CloudSyncQueue:
    def __init__(self, *, store: Any, api_key: str, project: str, api_base: str | None = None) -> None:
        self.store = store
        self.api_key = api_key
        self.project = project
        self.api_base = resolve_costpilot_api_base(api_base)
        self.revoked = False
        self._queue: queue.Queue[dict[str, Any]] = queue.Queue()
        self._thread: threading.Thread | None = None
        self._lock = threading.Lock()

    def push(self, row: dict[str, Any]) -> None:
        self._queue.put(dict(row))
        self._ensure_worker()

    def flush_unsynced(self, limit: int = 100) -> None:
        for row in self.store.get_unsynced_queries(limit=limit):
            self._queue.put(row)
        self._ensure_worker()

    def _ensure_worker(self) -> None:
        with self._lock:
            if self._thread and self._thread.is_alive():
                return
            self._thread = threading.Thread(target=self._drain, name="costpilot-cloud-sync", daemon=True)
            self._thread.start()

    def _drain(self) -> None:
        batch: list[dict[str, Any]] = []
        while True:
            try:
                batch.append(self._queue.get(timeout=0.25))
            except queue.Empty:
                if batch:
                    self._send_batch(batch)
                return
            if len(batch) >= 100:
                self._send_batch(batch)
                batch = []

    def _send_batch(self, rows: list[dict[str, Any]]) -> None:
        if self.revoked:
            return
        query_ids = [row["id"] for row in rows if row.get("id")]
        payload = {
            "project": self.project,
            "data": [self._cloud_payload(row) for row in rows],
        }
        try:
            response = httpx.post(
                f"{self.api_base}/v1/ingest",
                headers={"Authorization": f"Bearer {self.api_key}"},
                json=payload,
                timeout=5.0,
            )
            if response.status_code == 401:
                self.revoked = True
                self.store.insert_audit_log(
                    {"event_type": "key_revoked", "result": "info", "metadata": {"key_prefix": self.api_key[:15]}}
                )
                return
            response.raise_for_status()
            self.store.mark_synced(query_ids)
            self.store.insert_audit_log(
                {"event_type": "sync_attempt", "result": "success", "metadata": {"batch_size": len(rows)}}
            )
        except Exception as exc:
            self.store.insert_audit_log(
                {
                    "event_type": "sync_attempt",
                    "result": "failure",
                    "metadata": {"batch_size": len(rows), "reason": str(exc)[:160]},
                }
            )

    def _cloud_payload(self, row: dict[str, Any]) -> dict[str, Any]:
        return {key: value for key, value in row.items() if key not in LOCAL_ONLY_FIELDS and value is not None}
