from __future__ import annotations

import json
import logging
import time
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

LITELLM_PRICES_URL = (
    "https://raw.githubusercontent.com/BerriAI/litellm/main/"
    "model_prices_and_context_window.json"
)
FRANKFURTER_URL = "https://api.frankfurter.app/latest"

_FETCH_TIMEOUT = 10.0
_CACHE_TTL = 86_400  # 24 hours
_CACHE_PATH = Path.home() / ".costpilot" / "pricing_cache.json"

# LiteLLM key prefix → our provider name (order matters: longest prefix first)
PREFIX_TO_PROVIDER: dict[str, str] = {
    "azure_ai/":          "azure-foundry",
    "vertex_ai_beta/":    "google-vertex",
    "vertex_ai/":         "google-vertex",
    "together_ai/":       "together",
    "huggingface/":       "huggingface",
    "perplexity/":        "perplexity",
    "anthropic/":         "anthropic",
    "deepseek/":          "deepseek",
    "mistral/":           "mistral",
    "cohere/":            "cohere",
    "openai/":            "openai",
    "gemini/":            "gemini",
    "azure/":             "azure",
    "bedrock/":           "aws-bedrock",
    "groq/":              "groq",
    "xai/":               "xai",
}

# LiteLLM litellm_provider field → our provider name (for unprefixed keys)
_LITELLM_PROVIDER_MAP: dict[str, str] = {
    "anthropic":       "anthropic",
    "openai":          "openai",
    "gemini":          "gemini",
    "google":          "gemini",
    "azure":           "azure",
    "azure_ai":        "azure-foundry",
    "vertex_ai":       "google-vertex",
    "bedrock":         "aws-bedrock",
    "mistral_ai":      "mistral",
    "cohere_chat":     "cohere",
    "cohere":          "cohere",
    "groq":            "groq",
    "together_ai":     "together",
    "huggingface":     "huggingface",
    "deepseek":        "deepseek",
    "xai":             "xai",
    "perplexity":      "perplexity",
}

# Our provider name → LiteLLM key prefix (for lookup hints)
PROVIDER_TO_PREFIX: dict[str, str] = {v: k for k, v in reversed(list(PREFIX_TO_PROVIDER.items()))}


def _infer_provider_from_name(name: str) -> str:
    n = name.lower()
    if "claude" in n:
        return "anthropic"
    if n.startswith(("gpt-", "o1-", "o3-", "o4-")) or "openai" in n:
        return "openai"
    if "gemini" in n:
        return "gemini"
    if "llama" in n:
        return "meta"
    if "mistral" in n or "mixtral" in n:
        return "mistral"
    if "deepseek" in n:
        return "deepseek"
    if "phi" in n:
        return "microsoft"
    return "unknown"


class PriceFetcher:
    """Fetches live model prices (LiteLLM JSON) + exchange rates (Frankfurter)."""

    def fetch_model_prices(self, timeout: float = _FETCH_TIMEOUT) -> dict[str, Any]:
        """Returns our models-dict format. Raises on network/parse failure."""
        import httpx

        resp = httpx.get(LITELLM_PRICES_URL, timeout=timeout, follow_redirects=True)
        resp.raise_for_status()
        return self._parse_litellm(resp.json())

    def fetch_exchange_rates(
        self, base: str = "USD", timeout: float = _FETCH_TIMEOUT
    ) -> dict[str, float]:
        """Returns {currency_code: rate} relative to base. Raises on failure."""
        import httpx

        resp = httpx.get(
            FRANKFURTER_URL,
            params={"from": base},
            timeout=timeout,
            follow_redirects=True,
        )
        resp.raise_for_status()
        data = resp.json()
        rates: dict[str, float] = {k: float(v) for k, v in data.get("rates", {}).items()}
        rates[base.upper()] = 1.0
        return rates

    def load_with_cache(
        self,
        ttl: int = _CACHE_TTL,
        cache_path: Path = _CACHE_PATH,
    ) -> dict[str, Any] | None:
        """
        Returns cached result if fresh (age < ttl seconds), else fetches live.
        Returns None only if both fetches fail and no valid cache exists.
        Result shape: {"models": {...}, "exchange_rates": {...}, "fetched_at": float}
        """
        cached = self._read_cache(cache_path, ttl)
        if cached is not None:
            return cached

        result: dict[str, Any] = {"fetched_at": time.time()}
        any_success = False

        try:
            result["models"] = self.fetch_model_prices()
            result["source"] = "litellm"
            any_success = True
        except Exception as exc:
            logger.warning("Live model price fetch failed: %s", exc)

        try:
            result["exchange_rates"] = self.fetch_exchange_rates()
            any_success = True
        except Exception as exc:
            logger.warning("Exchange rate fetch failed: %s", exc)

        if any_success:
            self._write_cache(cache_path, result)
            return result

        return None

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _parse_litellm(self, raw: dict[str, Any]) -> dict[str, Any]:
        """
        Dynamically parses every entry in the LiteLLM pricing JSON.
        No fixed model list — any model with cost info is included.
        canonical ID = key with provider prefix stripped.
        Both the prefixed key (e.g. gemini/gemini-3-flash-preview) and the
        canonical key (gemini-3-flash-preview) are stored so lookup works
        regardless of how the caller names the model.
        """
        out: dict[str, Any] = {}

        for litellm_key, entry in raw.items():
            if not isinstance(entry, dict):
                continue
            if litellm_key.startswith("sample_spec"):
                continue

            # Resolve provider + canonical ID
            canonical = litellm_key
            provider: str | None = None

            for prefix, prov in PREFIX_TO_PROVIDER.items():
                if litellm_key.startswith(prefix):
                    canonical = litellm_key[len(prefix):]
                    provider = prov
                    break

            if provider is None:
                lp = entry.get("litellm_provider", "")
                provider = _LITELLM_PROVIDER_MAP.get(lp) or _infer_provider_from_name(litellm_key)

            inp = entry.get("input_cost_per_token")
            out_t = entry.get("output_cost_per_token")
            cr = entry.get("cache_read_input_token_cost")
            cw = entry.get("cache_creation_input_token_cost")
            ctx = entry.get("max_input_tokens") or entry.get("max_tokens")
            mode = entry.get("mode", "")

            # Skip entries that carry no pricing data
            if inp is None and out_t is None:
                continue

            model_data: dict[str, Any] = {"provider": provider}
            if inp is not None:
                model_data["input_per_million"] = round(float(inp) * 1_000_000, 6)
            if out_t is not None:
                model_data["output_per_million"] = round(float(out_t) * 1_000_000, 6)
            if cr is not None:
                model_data["cache_read_per_million"] = round(float(cr) * 1_000_000, 6)
            if cw is not None:
                model_data["cache_write_per_million"] = round(float(cw) * 1_000_000, 6)
            if ctx:
                model_data["context_window"] = int(ctx)
            if mode == "embedding":
                model_data["type"] = "embedding"
                model_data.pop("output_per_million", None)

            # Store under canonical (prefix-stripped) key; first entry wins.
            # Also store the original prefixed key so callers using the full
            # LiteLLM key format get a direct hit.
            if canonical not in out:
                out[canonical] = model_data
            if litellm_key != canonical and litellm_key not in out:
                out[litellm_key] = model_data

        return out

    def _read_cache(self, path: Path, ttl: int) -> dict[str, Any] | None:
        try:
            if not path.exists():
                return None
            data: dict[str, Any] = json.loads(path.read_text())
            age = time.time() - float(data.get("fetched_at", 0))
            if age < ttl:
                return data
        except Exception:
            pass
        return None

    def _write_cache(self, path: Path, data: dict[str, Any]) -> None:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(data, indent=2))
        except Exception as exc:
            logger.warning("Could not write pricing cache: %s", exc)
