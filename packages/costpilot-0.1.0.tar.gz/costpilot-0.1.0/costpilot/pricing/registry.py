from __future__ import annotations

import json
import logging
import os
import threading
import uuid
from pathlib import Path
from typing import Any

from .fetcher import LITELLM_PRICES_URL, PREFIX_TO_PROVIDER, PROVIDER_TO_PREFIX, PriceFetcher

logger = logging.getLogger(__name__)


class PricingRegistry:
    def __init__(
        self,
        path: str | Path | None = None,
        store: Any | None = None,
        live: bool = False,
    ) -> None:
        self.path = Path(path) if path else self._default_path()
        self._data = json.loads(self.path.read_text())
        self._store = store
        self._live_models: dict[str, Any] | None = None
        self._exchange_rates: dict[str, float] | None = None
        self._fetcher = PriceFetcher()

        if live:
            self._start_background_fetch()

    # ------------------------------------------------------------------
    # Public API (all backward-compatible)
    # ------------------------------------------------------------------

    @property
    def data(self) -> dict[str, Any]:
        return self._data

    @property
    def usd_to_inr(self) -> float:
        if self._exchange_rates:
            return self._exchange_rates.get("INR", self._fallback_inr)
        return self._fallback_inr

    def convert_currency(self, usd: float, currency_code: str) -> float:
        """Convert USD amount to target currency. Falls back gracefully if rate unavailable."""
        code = currency_code.upper()
        if self._exchange_rates:
            rate = self._exchange_rates.get(code)
            if rate is not None:
                return round(usd * rate, 6)
        if code == "INR":
            return round(usd * self._fallback_inr, 6)
        return round(usd, 6)

    def get_available_currencies(self) -> list[str]:
        if self._exchange_rates:
            return sorted(self._exchange_rates.keys())
        return ["INR", "USD"]

    def calculate_cost(
        self,
        model: str,
        input_tokens: int,
        output_tokens: int,
        cache_read_tokens: int = 0,
        cache_write_tokens: int = 0,
        provider: str | None = None,
    ) -> float:
        normalized = self.normalize_model(model)
        rates = self.get_rates(normalized, provider=provider)
        if not rates:
            self._log_unknown_model(normalized)
            return 0.0

        regular_input = max(0, int(input_tokens or 0) - int(cache_read_tokens or 0))
        output_price = (
            0.0 if rates.get("type") == "embedding"
            else float(rates.get("output_per_million", 0) or 0)
        )
        cost = (
            (regular_input / 1_000_000) * float(rates.get("input_per_million", 0) or 0)
            + (int(output_tokens or 0) / 1_000_000) * output_price
            + (int(cache_read_tokens or 0) / 1_000_000) * float(rates.get("cache_read_per_million", 0) or 0)
            + (int(cache_write_tokens or 0) / 1_000_000) * float(rates.get("cache_write_per_million", 0) or 0)
        )
        return round(max(0.0, cost), 8)

    def normalize_model(self, model: str) -> str:
        return self._data.get("model_aliases", {}).get(model, model)

    def get_rates(self, model: str, provider: str | None = None) -> dict[str, Any] | None:
        """
        Lookup pricing for a model. Tries multiple key forms so callers don't
        need to know the LiteLLM prefix convention:
          1. Exact match
          2. Provider-hinted prefix (e.g. gemini/gemini-3-flash-preview)
          3. All known prefixes in order
          4. Strip any prefix already in the model name
          5. Fallback to prices.json static data
        """
        if self._live_models:
            # 1. Exact
            rates = self._live_models.get(model)
            if rates:
                return rates
            # 2. Provider hint → try that prefix first
            if provider:
                prefix = PROVIDER_TO_PREFIX.get(provider)
                if prefix:
                    rates = self._live_models.get(f"{prefix}{model}")
                    if rates:
                        return rates
            # 3. All prefixes
            for prefix in PREFIX_TO_PROVIDER:
                rates = self._live_models.get(f"{prefix}{model}")
                if rates:
                    return rates
            # 4. Strip prefix already in model name (e.g. "gemini/gemini-3-flash-preview")
            if "/" in model:
                bare = model.split("/", 1)[1]
                rates = self._live_models.get(bare)
                if rates:
                    return rates
        # 5. Static fallback
        return self._data.get("models", {}).get(model)

    def infrastructure_rate(self, target_cloud: str, service: str) -> dict[str, Any]:
        return dict(self._data.get("infrastructure", {}).get(target_cloud, {}).get(service, {}))

    def snapshot_rows(self) -> list[dict[str, Any]]:
        using_live = bool(self._live_models)
        source = "litellm" if using_live else self._data.get("last_verified_source", "hardcoded")
        source_url = LITELLM_PRICES_URL if using_live else None
        models = self._live_models if using_live else self._data.get("models", {})
        rows: list[dict[str, Any]] = []
        for model, rates in models.items():
            rows.append(
                {
                    "id": str(uuid.uuid4()),
                    "provider": rates.get("provider", "unknown"),
                    "model": model,
                    "input_price_per_million": rates.get("input_per_million"),
                    "output_price_per_million": rates.get("output_per_million"),
                    "cache_read_per_million": rates.get("cache_read_per_million"),
                    "cache_write_per_million": rates.get("cache_write_per_million"),
                    "source": source,
                    "source_url": source_url,
                }
            )
        return rows

    def refresh_prices(self) -> bool:
        """Foreground blocking refresh. Returns True on success."""
        result = self._fetcher.load_with_cache(ttl=0)
        return self._apply_live_data(result)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    @property
    def _fallback_inr(self) -> float:
        return float(self._data.get("currency", {}).get("usd_to_inr", 83.55))

    def _start_background_fetch(self) -> None:
        t = threading.Thread(target=self._background_fetch, daemon=True)
        t.start()

    def _background_fetch(self) -> None:
        try:
            result = self._fetcher.load_with_cache()
            self._apply_live_data(result)
        except Exception as exc:
            logger.debug("Background pricing fetch error: %s", exc)

    def _apply_live_data(self, result: dict[str, Any] | None) -> bool:
        if not result:
            return False
        if "models" in result:
            self._live_models = result["models"]
        if "exchange_rates" in result:
            self._exchange_rates = result["exchange_rates"]
        return True

    def _log_unknown_model(self, model: str) -> None:
        if not self._store:
            return
        self._store.insert_audit_log(
            {
                "event_type": "unknown_model",
                "result": "zero_cost_recorded",
                "metadata": {"model": model},
            }
        )

    def _default_path(self) -> Path:
        env_path = os.getenv("COSTPILOT_PRICING_REGISTRY")
        if env_path:
            return Path(env_path)
        here = Path(__file__).resolve()
        for parent in here.parents:
            candidate = parent / "pricing-registry" / "prices.json"
            if candidate.exists():
                return candidate
        repo_candidate = here.parents[4] / "pricing-registry" / "prices.json"
        if repo_candidate.exists():
            return repo_candidate
        raise FileNotFoundError("Could not locate pricing-registry/prices.json")
