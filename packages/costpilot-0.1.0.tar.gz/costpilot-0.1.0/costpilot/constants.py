from __future__ import annotations

import os


DEFAULT_COSTPILOT_API_BASE = "https://api.thecostpilot.dev"


def resolve_costpilot_api_base(api_base: str | None = None) -> str:
    return (api_base or os.getenv("COSTPILOT_API_BASE") or DEFAULT_COSTPILOT_API_BASE).rstrip("/")
