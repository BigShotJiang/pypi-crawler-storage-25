from __future__ import annotations

import hashlib
import platform
from pathlib import Path
from typing import Any

import httpx

from .cache import is_fresh, iso_now, load_cache, save_cache
from costpilot.constants import DEFAULT_COSTPILOT_API_BASE, resolve_costpilot_api_base


class LicenseValidator:
    DEFAULT_API_BASE = DEFAULT_COSTPILOT_API_BASE

    def __init__(self, cache_path: Path, *, api_base: str | None = None, store: Any | None = None) -> None:
        self.cache_path = cache_path
        self.api_base = resolve_costpilot_api_base(api_base)
        self.store = store

    def validate(self, license_key: str) -> dict[str, Any]:
        cache = load_cache(self.cache_path)
        if cache and is_fresh(cache, days=30):
            self._audit("license_validated", "cached", {"machine_id_match": True})
            return {**cache, "from_cache": True}

        payload = {"license_key": license_key, "machine_id": self.machine_id()}
        try:
            response = httpx.post(f"{self.api_base}/v1/license/validate", json=payload, timeout=10.0)
            response.raise_for_status()
            result = response.json()
            if result.get("valid"):
                result = {**result, "cached_at": iso_now()}
                save_cache(self.cache_path, result)
                self._audit("license_validated", "success", {"machine_id_match": True})
            else:
                self.cache_path.unlink(missing_ok=True)
                self._audit("license_validated", "failure", {"reason": result.get("reason")})
            return result
        except Exception as exc:
            if cache:
                self._audit("license_validated", "cached", {"offline_mode": True})
                return {**cache, "offline_mode": True}
            self._audit("license_validated", "failure", {"reason": "cannot_validate"})
            return {"valid": False, "reason": f"Cannot validate: {exc}"}

    def machine_id(self) -> str:
        raw = f"{platform.node()}:{platform.machine()}"
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]

    def _audit(self, event_type: str, result: str, metadata: dict[str, Any]) -> None:
        if self.store:
            self.store.insert_audit_log({"event_type": event_type, "result": result, "metadata": metadata})
