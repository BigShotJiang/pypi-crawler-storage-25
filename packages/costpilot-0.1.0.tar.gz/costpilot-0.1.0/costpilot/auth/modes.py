from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from costpilot.config import CostPilotConfig
from costpilot.exceptions import AuthError

from .api_key import ApiKeyValidator
from .license import LicenseValidator


ENTERPRISE_LIMITS = {
    "projects": -1,
    "history_days": None,
    "ingest_per_day": -1,
    "llm_providers": -1,
    "services": -1,
    "export_unlocked": True,
    "scenario_basic_attempts": -1,
    "freeform_attempts": -1,
    "migration_basic_attempts": -1,
    "projection_sample_records": -1,
}


@dataclass(frozen=True)
class AuthState:
    mode: str
    tier: str
    limits: dict[str, Any]
    validation: dict[str, Any]
    account_email: str | None = None
    tier_expires_at: str | None = None
    license_expires_at: str | None = None


def resolve_auth_state(config: CostPilotConfig, *, store: Any | None = None) -> AuthState:
    config.state_dir.mkdir(parents=True, exist_ok=True)
    if config.api_key:
        validator = ApiKeyValidator(config.state_dir / "key-cache.json", store=store)
        result = validator.validate(config.api_key)
        if not result.get("valid"):
            raise AuthError(f"Invalid API key: {result.get('reason', 'unknown')}")
        state = AuthState(
            mode="cloud",
            tier=str(result.get("tier") or "trial"),
            limits=dict(result.get("limits") or {}),
            validation=result,
            account_email=result.get("account_email") or result.get("email"),
            tier_expires_at=result.get("tier_expires_at"),
        )
        _audit_mode(store, state)
        return state

    if config.license_key:
        validator = LicenseValidator(config.state_dir / "license-cache.json", store=store)
        result = validator.validate(config.license_key)
        if not result.get("valid"):
            raise AuthError(f"Invalid license key: {result.get('reason', 'unknown')}")
        state = AuthState(
            mode="self-host",
            tier=str(result.get("tier") or "enterprise"),
            limits=ENTERPRISE_LIMITS,
            validation=result,
            license_expires_at=result.get("expires_at"),
        )
        _audit_mode(store, state)
        return state

    raise AuthError("No auth key found in .costpilot.yaml. Run 'costpilot init'.")


def _audit_mode(store: Any | None, state: AuthState) -> None:
    if store:
        store.insert_audit_log(
            {
                "event_type": "mode_resolved",
                "result": "info",
                "metadata": {"mode": state.mode, "tier": state.tier},
            }
        )
