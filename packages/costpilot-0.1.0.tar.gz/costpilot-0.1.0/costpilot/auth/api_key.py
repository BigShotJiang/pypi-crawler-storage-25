from __future__ import annotations

from pathlib import Path
from typing import Any

import httpx

from .cache import is_fresh, iso_now, load_cache, save_cache
from costpilot.constants import DEFAULT_COSTPILOT_API_BASE, resolve_costpilot_api_base


class ApiKeyValidator:
    DEFAULT_API_BASE = DEFAULT_COSTPILOT_API_BASE

    def __init__(self, cache_path: Path, *, api_base: str | None = None, store: Any | None = None) -> None:
        self.cache_path = cache_path
        self.api_base = resolve_costpilot_api_base(api_base)
        self.store = store

    def validate(self, api_key: str) -> dict[str, Any]:
        cache = load_cache(self.cache_path)
        if cache and is_fresh(cache, hours=6):
            self._audit("key_validated", "cached", {"key_prefix": api_key[:15], "tier": cache.get("tier")})
            return {**cache, "from_cache": True}

        try:
            response = httpx.get(
                f"{self.api_base}/v1/auth/validate",
                headers={"Authorization": f"Bearer {api_key}"},
                timeout=5.0,
            )
            if response.status_code == 401:
                result = {"valid": False, "reason": "invalid_api_key"}
            else:
                response.raise_for_status()
                result = response.json()
            if result.get("valid"):
                old_tier = cache.get("tier") if cache else None
                new_tier = result.get("tier")
                if old_tier and new_tier and old_tier != new_tier:
                    self._audit("plan_downgraded", "info", {"from": old_tier, "to": new_tier})
                result = {**result, "cached_at": iso_now()}
                save_cache(self.cache_path, result)
                self._audit("key_validated", "success", {"key_prefix": api_key[:15], "tier": new_tier})
            else:
                self.cache_path.unlink(missing_ok=True)
                self._audit("key_invalid", "failure", {"key_prefix": api_key[:15], "reason": result.get("reason")})
            return result
        except Exception as exc:
            if cache and is_fresh(cache, hours=168):
                self._audit("key_validated", "cached", {"key_prefix": api_key[:15], "offline_mode": True})
                return {**cache, "offline_mode": True}
            self._audit("key_invalid", "failure", {"key_prefix": api_key[:15], "reason": "offline_no_cache"})
            return {"valid": False, "reason": f"offline_no_cache: {exc}"}

    def _audit(self, event_type: str, result: str, metadata: dict[str, Any]) -> None:
        if self.store:
            self.store.insert_audit_log({"event_type": event_type, "result": result, "metadata": metadata})
