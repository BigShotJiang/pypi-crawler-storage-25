from __future__ import annotations

import logging
import os
import pathlib
import tempfile
import unittest
import unittest.mock
from datetime import datetime, timedelta, timezone

from costpilot.config import load_config, write_config, generate_default_config
from costpilot.pricing import PricingRegistry
from costpilot.privacy import DataSanitizer
from costpilot.storage import SqliteStore


class PrivacyPricingStorageTests(unittest.TestCase):
    def test_sanitizer_drops_prompt_content_and_hashes_ids(self) -> None:
        sanitizer = DataSanitizer()
        safe = sanitizer.sanitize_for_storage(
            {
                "project": "blueprint-ai",
                "provider": "openai",
                "model": "gpt-4o-mini",
                "prompt_content": "CANARY-12345",
                "response_content": "secret",
                "cost_usd": 0.01,
            }
        )
        self.assertNotIn("prompt_content", safe)
        self.assertNotIn("response_content", safe)
        self.assertEqual(sanitizer.hash_user_id("alice@example.com", "salt"), "4faf92521f2b09ac")

    def test_pricing_alias_and_cost_math(self) -> None:
        pricing = PricingRegistry()
        self.assertEqual(pricing.normalize_model("gpt-4o-mini-2024-07-18"), "gpt-4o-mini")
        self.assertEqual(pricing.calculate_cost("gpt-4o-mini", 1000, 500), 0.00045)

    def test_sqlite_insert_and_unsynced_flow(self) -> None:
        db_path = pathlib.Path(tempfile.mkdtemp()) / "data.db"
        store = SqliteStore(db_path)
        store.insert_query(
            {
                "project": "blueprint-ai",
                "provider": "openai",
                "model": "gpt-4o-mini",
                "input_tokens": 1000,
                "output_tokens": 500,
                "cost_usd": 0.00045,
            }
        )
        rows = store.get_unsynced_queries()
        self.assertEqual(len(rows), 1)
        store.mark_synced([rows[0]["id"]])
        self.assertEqual(store.get_unsynced_queries(), [])


class PrivacyVerificationTests(unittest.TestCase):
    """Spec 02 verification checklist — integration tests that must pass before v0.1.0."""

    def _make_store(self) -> tuple[SqliteStore, pathlib.Path]:
        db_path = pathlib.Path(tempfile.mkdtemp()) / "data.db"
        return SqliteStore(db_path), db_path

    def test_canary_string_absent_from_db_file(self) -> None:
        """CANARY-12345 must not appear anywhere in the raw SQLite file bytes."""
        store, db_path = self._make_store()
        sanitizer = DataSanitizer()
        raw = {
            "project": "test",
            "provider": "anthropic",
            "model": "claude-sonnet-4-6",
            "input_tokens": 10,
            "output_tokens": 5,
            "cost_usd": 0.0001,
            "prompt_content": "CANARY-12345",
            "system_prompt": "CANARY-12345",
        }
        safe = sanitizer.sanitize_for_storage(raw)
        store.insert_query(safe)
        store.close()
        db_bytes = db_path.read_bytes()
        self.assertNotIn(b"CANARY-12345", db_bytes)

    def test_raw_user_email_absent_from_db_file(self) -> None:
        """Raw alice@example.com must not appear anywhere in the raw SQLite file bytes."""
        store, db_path = self._make_store()
        sanitizer = DataSanitizer()
        user_hash = sanitizer.hash_user_id("alice@example.com", "testsalt")
        raw = {
            "project": "test",
            "provider": "openai",
            "model": "gpt-4o-mini",
            "input_tokens": 10,
            "output_tokens": 5,
            "cost_usd": 0.00001,
            "user_id_hash": user_hash,
        }
        safe = sanitizer.sanitize_for_storage(raw)
        store.insert_query(safe)
        store.close()
        db_bytes = db_path.read_bytes()
        self.assertNotIn(b"alice", db_bytes)

    def test_capture_prompts_fixed_false(self) -> None:
        """Setting capture_prompts: true in config must be ignored; SDK boots with false and warns."""
        tmp = pathlib.Path(tempfile.mkdtemp())
        cfg_path = tmp / ".costpilot.yaml"
        payload = generate_default_config("test-project", api_key="cp_live_sk_" + "a" * 32)
        payload["privacy"]["capture_prompts"] = True
        write_config(cfg_path, payload)

        with self.assertLogs("costpilot.config", level=logging.WARNING) as log_ctx:
            cfg = load_config(cfg_path)

        self.assertFalse(cfg.privacy.capture_prompts)
        self.assertTrue(any("capture_prompts" in msg for msg in log_ctx.output))

    def test_hash_user_ids_fixed_true(self) -> None:
        """Setting hash_user_ids: false in config must be ignored; SDK boots with true and warns."""
        tmp = pathlib.Path(tempfile.mkdtemp())
        cfg_path = tmp / ".costpilot.yaml"
        payload = generate_default_config("test-project", api_key="cp_live_sk_" + "a" * 32)
        payload["privacy"]["hash_user_ids"] = False
        write_config(cfg_path, payload)

        with self.assertLogs("costpilot.config", level=logging.WARNING) as log_ctx:
            cfg = load_config(cfg_path)

        self.assertTrue(cfg.privacy.hash_user_ids)
        self.assertTrue(any("hash_user_ids" in msg for msg in log_ctx.output))

    def test_no_pii_check_constraint_blocks_email_in_user_id_hash(self) -> None:
        """DB CHECK constraint prevents raw email in user_id_hash column."""
        from sqlalchemy.exc import IntegrityError
        store, _ = self._make_store()
        with self.assertRaises((IntegrityError, Exception)):
            store.insert_query(
                {
                    "project": "test",
                    "provider": "openai",
                    "model": "gpt-4o-mini",
                    "input_tokens": 1,
                    "output_tokens": 1,
                    "cost_usd": 0.0,
                    "user_id_hash": "alice@example.com",
                }
            )


_API_KEY = "cp_live_sk_" + "a" * 32   # 43 chars
_LIC_KEY = "cpl_lic_" + "b" * 32      # 40 chars


def _stale_ts(hours: int = 10) -> str:
    ts = datetime.now(timezone.utc) - timedelta(hours=hours)
    return ts.replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _fresh_ts() -> str:
    from costpilot.auth.cache import iso_now
    return iso_now()


def _mock_get_ok(tier: str = "trial", limits: dict | None = None):
    resp = unittest.mock.MagicMock()
    resp.status_code = 200
    resp.json.return_value = {"valid": True, "tier": tier, "limits": limits or {"projects": 1}}
    return resp


def _mock_post_ok(tier: str = "enterprise"):
    resp = unittest.mock.MagicMock()
    resp.status_code = 200
    resp.json.return_value = {"valid": True, "tier": tier}
    return resp


class ApiKeyValidatorTests(unittest.TestCase):
    """Spec 03 — ApiKeyValidator: 4 cache/network paths."""

    def _tmp_cache(self) -> pathlib.Path:
        return pathlib.Path(tempfile.mkdtemp()) / "key-cache.json"

    def test_fresh_cache_hit_skips_server(self):
        from costpilot.auth.api_key import ApiKeyValidator
        from costpilot.auth.cache import save_cache

        cache_path = self._tmp_cache()
        save_cache(cache_path, {"valid": True, "tier": "trial", "limits": {}, "cached_at": _fresh_ts()})

        validator = ApiKeyValidator(cache_path)
        with unittest.mock.patch("httpx.get") as mock_get:
            result = validator.validate(_API_KEY)

        mock_get.assert_not_called()
        self.assertTrue(result["valid"])
        self.assertEqual(result["tier"], "trial")
        self.assertTrue(result.get("from_cache"))

    def test_stale_cache_hits_server_and_saves(self):
        from costpilot.auth.api_key import ApiKeyValidator
        from costpilot.auth.cache import save_cache

        cache_path = self._tmp_cache()
        save_cache(cache_path, {"valid": True, "tier": "trial", "limits": {}, "cached_at": _stale_ts(hours=10)})

        validator = ApiKeyValidator(cache_path)
        with unittest.mock.patch("httpx.get", return_value=_mock_get_ok("starter")):
            result = validator.validate(_API_KEY)

        self.assertTrue(result["valid"])
        self.assertEqual(result["tier"], "starter")

    def test_server_failure_within_offline_grace_returns_cached(self):
        from costpilot.auth.api_key import ApiKeyValidator
        from costpilot.auth.cache import save_cache

        cache_path = self._tmp_cache()
        # 10h old: stale for 6h TTL, fresh for 168h offline grace
        save_cache(cache_path, {"valid": True, "tier": "pro", "limits": {}, "cached_at": _stale_ts(hours=10)})

        validator = ApiKeyValidator(cache_path)
        with unittest.mock.patch("httpx.get", side_effect=Exception("network down")):
            result = validator.validate(_API_KEY)

        self.assertTrue(result["valid"])
        self.assertTrue(result.get("offline_mode"))

    def test_server_failure_no_cache_returns_invalid(self):
        from costpilot.auth.api_key import ApiKeyValidator

        validator = ApiKeyValidator(self._tmp_cache())
        with unittest.mock.patch("httpx.get", side_effect=Exception("network down")):
            result = validator.validate(_API_KEY)

        self.assertFalse(result["valid"])
        self.assertIn("offline_no_cache", result.get("reason", ""))


class LicenseValidatorTests(unittest.TestCase):
    """Spec 03 — LicenseValidator: 4 cache/network paths + machine_id binding."""

    def _tmp_cache(self) -> pathlib.Path:
        return pathlib.Path(tempfile.mkdtemp()) / "license-cache.json"

    def test_fresh_cache_hit_skips_server(self):
        from costpilot.auth.license import LicenseValidator
        from costpilot.auth.cache import save_cache

        cache_path = self._tmp_cache()
        save_cache(cache_path, {"valid": True, "tier": "enterprise", "cached_at": _fresh_ts()})

        validator = LicenseValidator(cache_path)
        with unittest.mock.patch("httpx.post") as mock_post:
            result = validator.validate(_LIC_KEY)

        mock_post.assert_not_called()
        self.assertTrue(result["valid"])
        self.assertTrue(result.get("from_cache"))

    def test_stale_cache_hits_server(self):
        from costpilot.auth.license import LicenseValidator
        from costpilot.auth.cache import save_cache

        cache_path = self._tmp_cache()
        save_cache(cache_path, {"valid": True, "tier": "enterprise", "cached_at": _stale_ts(hours=24 * 31)})

        validator = LicenseValidator(cache_path)
        with unittest.mock.patch("httpx.post", return_value=_mock_post_ok()):
            result = validator.validate(_LIC_KEY)

        self.assertTrue(result["valid"])

    def test_server_failure_any_cache_returns_offline(self):
        from costpilot.auth.license import LicenseValidator
        from costpilot.auth.cache import save_cache

        cache_path = self._tmp_cache()
        # 31 days old: stale for 30d TTL, falls into offline grace (any cache present)
        save_cache(cache_path, {"valid": True, "tier": "enterprise", "cached_at": _stale_ts(hours=24 * 31)})

        validator = LicenseValidator(cache_path)
        with unittest.mock.patch("httpx.post", side_effect=Exception("network down")):
            result = validator.validate(_LIC_KEY)

        self.assertTrue(result["valid"])
        self.assertTrue(result.get("offline_mode"))

    def test_server_failure_no_cache_returns_invalid(self):
        from costpilot.auth.license import LicenseValidator

        validator = LicenseValidator(self._tmp_cache())
        with unittest.mock.patch("httpx.post", side_effect=Exception("network down")):
            result = validator.validate(_LIC_KEY)

        self.assertFalse(result["valid"])

    def test_machine_id_sent_in_payload(self):
        from costpilot.auth.license import LicenseValidator

        validator = LicenseValidator(self._tmp_cache())
        with unittest.mock.patch("httpx.post", return_value=_mock_post_ok()) as mock_post:
            validator.validate(_LIC_KEY)

        payload = mock_post.call_args.kwargs.get("json") or mock_post.call_args[1].get("json")
        self.assertIn("machine_id", payload)
        self.assertEqual(payload["machine_id"], validator.machine_id())

    def test_machine_mismatch_response_fails_validation(self):
        from costpilot.auth.license import LicenseValidator

        resp = unittest.mock.MagicMock()
        resp.status_code = 200
        resp.json.return_value = {"valid": False, "reason": "machine_mismatch"}

        validator = LicenseValidator(self._tmp_cache())
        with unittest.mock.patch("httpx.post", return_value=resp):
            result = validator.validate(_LIC_KEY)

        self.assertFalse(result["valid"])
        self.assertEqual(result.get("reason"), "machine_mismatch")


class StateMachineTests(unittest.TestCase):
    """Spec 03 — mode resolution state machine: both branches + missing-auth path."""

    def _make_config(self, *, api_key=None, license_key=None):
        from costpilot.config import (
            CostPilotConfig, PrivacyConfig, LlmConfig,
            StorageConfig, DashboardConfig, HealthConfig,
        )
        tmp = pathlib.Path(tempfile.mkdtemp())
        return CostPilotConfig(
            project="test", environment="local",
            api_key=api_key, license_key=license_key,
            privacy=PrivacyConfig(), llm=LlmConfig(), services={},
            storage=StorageConfig(path=str(tmp / "data.db")),
            dashboard=DashboardConfig(), health=HealthConfig(),
            cloud={}, config_path=tmp / ".costpilot.yaml",
        )

    def test_api_key_resolves_cloud_mode(self):
        from costpilot.auth.modes import resolve_auth_state

        cfg = self._make_config(api_key=_API_KEY)
        with unittest.mock.patch("httpx.get", return_value=_mock_get_ok("trial")):
            state = resolve_auth_state(cfg)

        self.assertEqual(state.mode, "cloud")
        self.assertEqual(state.tier, "trial")

    def test_license_key_resolves_self_host_mode(self):
        from costpilot.auth.modes import resolve_auth_state

        cfg = self._make_config(license_key=_LIC_KEY)
        with unittest.mock.patch("httpx.post", return_value=_mock_post_ok()):
            state = resolve_auth_state(cfg)

        self.assertEqual(state.mode, "self-host")
        self.assertEqual(state.tier, "enterprise")

    def test_missing_auth_raises_auth_error_with_init_message(self):
        from costpilot.auth.modes import resolve_auth_state
        from costpilot.exceptions import AuthError

        cfg = self._make_config()
        with self.assertRaises(AuthError) as ctx:
            resolve_auth_state(cfg)

        self.assertIn("costpilot init", str(ctx.exception))

    def test_invalid_api_key_raises_not_silently_local(self):
        """Valid: False from server must raise AuthError — no silent fallback to local mode."""
        from costpilot.auth.modes import resolve_auth_state
        from costpilot.exceptions import AuthError

        resp = unittest.mock.MagicMock()
        resp.status_code = 401
        resp.json.return_value = {"valid": False, "reason": "invalid_api_key"}

        cfg = self._make_config(api_key=_API_KEY)
        with unittest.mock.patch("httpx.get", return_value=resp):
            with self.assertRaises(AuthError):
                resolve_auth_state(cfg)


class KeyLengthValidationTests(unittest.TestCase):
    """Spec 03 — key prefix + length contract enforced by config loader."""

    def _write_cfg(self, tmp: pathlib.Path, **overrides) -> pathlib.Path:
        payload = generate_default_config("test-project", api_key=_API_KEY)
        payload.update(overrides)
        cfg_path = tmp / ".costpilot.yaml"
        write_config(cfg_path, payload)
        return cfg_path

    def test_valid_api_key_accepted(self):
        tmp = pathlib.Path(tempfile.mkdtemp())
        cfg_path = self._write_cfg(tmp)
        cfg = load_config(cfg_path)
        self.assertEqual(cfg.api_key, _API_KEY)

    def test_short_api_key_rejected(self):
        from costpilot.exceptions import ConfigError
        tmp = pathlib.Path(tempfile.mkdtemp())
        short_key = "cp_live_sk_" + "a" * 10
        payload = generate_default_config("test-project", api_key=_API_KEY)
        payload["api_key"] = short_key
        cfg_path = tmp / ".costpilot.yaml"
        write_config(cfg_path, payload)
        with self.assertRaises(ConfigError):
            load_config(cfg_path)

    def test_wrong_prefix_api_key_rejected(self):
        from costpilot.exceptions import ConfigError
        tmp = pathlib.Path(tempfile.mkdtemp())
        payload = generate_default_config("test-project", api_key=_API_KEY)
        payload["api_key"] = "sk_live_" + "a" * 35
        cfg_path = tmp / ".costpilot.yaml"
        write_config(cfg_path, payload)
        with self.assertRaises(ConfigError):
            load_config(cfg_path)


class TrialExpiryTests(unittest.TestCase):
    """Spec 03 — trial expiry: plan_downgraded audit emitted with correct metadata."""

    def test_trial_to_trial_expired_emits_plan_downgraded(self):
        from costpilot.auth.api_key import ApiKeyValidator
        from costpilot.auth.cache import save_cache

        tmp = pathlib.Path(tempfile.mkdtemp())
        cache_path = tmp / "key-cache.json"
        save_cache(cache_path, {
            "valid": True, "tier": "trial", "limits": {}, "cached_at": _stale_ts(hours=10),
        })

        audit_log: list[dict] = []

        class _Store:
            def insert_audit_log(self, entry):
                audit_log.append(entry)

        expired_limits = {
            "projects": 1, "history_days": 1, "llm_providers": 1, "services": 1,
            "scenario_unlocked": False, "migration_basic": False,
            "migration_advanced": False, "export_unlocked": False,
        }
        resp = unittest.mock.MagicMock()
        resp.status_code = 200
        resp.json.return_value = {"valid": True, "tier": "trial_expired", "limits": expired_limits}

        validator = ApiKeyValidator(cache_path, store=_Store())
        with unittest.mock.patch("httpx.get", return_value=resp):
            result = validator.validate(_API_KEY)

        self.assertEqual(result["tier"], "trial_expired")
        downgrade = [e for e in audit_log if e["event_type"] == "plan_downgraded"]
        self.assertEqual(len(downgrade), 1)
        self.assertEqual(downgrade[0]["metadata"]["from"], "trial")
        self.assertEqual(downgrade[0]["metadata"]["to"], "trial_expired")


def _sample_query(**overrides) -> dict:
    base = {
        "project": "test-proj",
        "provider": "openai",
        "model": "gpt-4o-mini",
        "input_tokens": 100,
        "output_tokens": 50,
        "cost_usd": 0.0001,
    }
    base.update(overrides)
    return base


class StorageSpec05Tests(unittest.TestCase):
    """Spec 05 — SQLite storage: round-trips, sync flow, history floor, aggregations."""

    def _store(self, history_days_limit: int = -1) -> tuple["SqliteStore", pathlib.Path]:
        db_path = pathlib.Path(tempfile.mkdtemp()) / "data.db"
        return SqliteStore(db_path, history_days_limit=history_days_limit), db_path

    # ── round-trips ──────────────────────────────────────────────────────────

    def test_insert_query_round_trips(self):
        store, _ = self._store()
        store.insert_query(_sample_query())
        rows = store.get_unsynced_queries()
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["model"], "gpt-4o-mini")

    def test_insert_service_usage_round_trips(self):
        store, _ = self._store()
        store.insert_service_usage({"project": "p", "service": "redis", "operation": "GET"})
        stats = store.get_service_stats("p")
        self.assertEqual(len(stats), 1)
        self.assertEqual(stats[0]["service"], "redis")

    def test_insert_pricing_snapshot_round_trips(self):
        store, _ = self._store()
        store.insert_pricing_snapshot({
            "provider": "openai", "model": "gpt-4o-mini",
            "input_price_per_million": 0.15, "output_price_per_million": 0.60,
        })
        snap = store.get_recent_pricing_snapshot()
        self.assertIsNotNone(snap)
        self.assertEqual(snap["model"], "gpt-4o-mini")

    def test_insert_migration_report_round_trips(self):
        store, _ = self._store()
        rid = store.insert_migration_report("p", "azure", {"period_days": 30}, 12.50)
        self.assertIsInstance(rid, str)

    def test_insert_audit_log_round_trips(self):
        store, _ = self._store()
        store.insert_audit_log({"event_type": "key_validated", "result": "success"})
        rows = store.get_audit_log()
        self.assertTrue(any(r["event_type"] == "key_validated" for r in rows))

    def test_insert_health_metric_round_trips(self):
        store, _ = self._store()
        store.insert_health_metric({
            "project": "p", "service": "redis",
            "metric": "latency_ms", "value": 2.5, "status": "healthy",
        })
        metrics = store.get_health_metrics(project="p")
        self.assertEqual(len(metrics), 1)

    def test_insert_alert_round_trips(self):
        store, _ = self._store()
        store.insert_alert({
            "project": "p", "alert_type": "cost_spike",
            "message": "cost exceeded threshold", "value": 5.0, "threshold": 3.0,
        })
        alerts = store.get_unacknowledged_alerts("p")
        self.assertEqual(len(alerts), 1)
        self.assertEqual(alerts[0]["alert_type"], "cost_spike")

    # ── sync flow ─────────────────────────────────────────────────────────────

    def test_get_unsynced_queries_returns_false_rows_in_insertion_order(self):
        store, _ = self._store()
        for i in range(3):
            store.insert_query(_sample_query(cost_usd=float(i) * 0.001))
        rows = store.get_unsynced_queries()
        self.assertEqual(len(rows), 3)
        costs = [r["cost_usd"] for r in rows]
        self.assertEqual(costs, sorted(costs))

    def test_mark_synced_is_idempotent(self):
        store, _ = self._store()
        store.insert_query(_sample_query())
        qid = store.get_unsynced_queries()[0]["id"]
        store.mark_synced([qid])
        store.mark_synced([qid])  # second call must not raise
        self.assertEqual(store.get_unsynced_queries(), [])

    # ── history floor ─────────────────────────────────────────────────────────

    def test_history_floor_enforced_for_trial_expired(self):
        store, _ = self._store(history_days_limit=1)
        old = datetime.now(timezone.utc) - timedelta(days=10)
        store.insert_query(_sample_query(cost_usd=0.05))
        # Force the timestamp to be old by patching — use direct SQL instead
        with store._engine.connect() as conn:
            from sqlalchemy import text
            conn.execute(text("UPDATE queries SET timestamp = :ts"), {"ts": old.isoformat()})
            conn.commit()
        stats = store.get_project_stats("test-proj", days=7)
        self.assertEqual(stats["total_queries"], 0, "old row must be excluded by 1-day floor")

    def test_history_floor_does_not_gate_unsynced_queries(self):
        """get_unsynced_queries must return rows regardless of history floor."""
        store, _ = self._store(history_days_limit=1)
        store.insert_query(_sample_query())
        with store._engine.connect() as conn:
            from sqlalchemy import text
            old = (datetime.now(timezone.utc) - timedelta(days=10)).isoformat()
            conn.execute(text("UPDATE queries SET timestamp = :ts"), {"ts": old})
            conn.commit()
        rows = store.get_unsynced_queries()
        self.assertEqual(len(rows), 1, "unsynced rows must always be pushable regardless of floor")

    # ── aggregations ──────────────────────────────────────────────────────────

    def test_aggregations_match_hand_computed_values(self):
        store, _ = self._store()
        costs = [0.001, 0.003, 0.006]
        for c in costs:
            store.insert_query(_sample_query(cost_usd=c))
        stats = store.get_project_stats("test-proj", days=30)
        self.assertEqual(stats["total_queries"], 3)
        self.assertAlmostEqual(stats["total_cost_usd"], sum(costs), places=7)
        self.assertAlmostEqual(stats["avg_cost_per_query"], sum(costs) / 3, places=7)

    def test_cost_by_model_groups_correctly(self):
        store, _ = self._store()
        store.insert_query(_sample_query(model="gpt-4o", cost_usd=0.01))
        store.insert_query(_sample_query(model="gpt-4o", cost_usd=0.02))
        store.insert_query(_sample_query(model="gpt-4o-mini", cost_usd=0.001))
        rows = store.get_cost_by_model("test-proj", days=30)
        by_model = {r["model"]: r for r in rows}
        self.assertAlmostEqual(by_model["gpt-4o"]["total_cost_usd"], 0.03, places=7)
        self.assertEqual(by_model["gpt-4o"]["query_count"], 2)
        self.assertEqual(by_model["gpt-4o-mini"]["query_count"], 1)

    # ── new spec methods ──────────────────────────────────────────────────────

    def test_data_span_days_empty_project_returns_zero(self):
        store, _ = self._store()
        self.assertEqual(store.data_span_days("no-such-project"), 0.0)

    def test_data_span_days_single_row_returns_zero(self):
        store, _ = self._store()
        store.insert_query(_sample_query())
        self.assertEqual(store.data_span_days("test-proj"), 0.0)

    def test_data_span_days_multi_row(self):
        store, _ = self._store()
        store.insert_query(_sample_query())
        # Force second row to be 5 days later
        store.insert_query(_sample_query(cost_usd=0.002))
        with store._engine.connect() as conn:
            from sqlalchemy import text
            future = (datetime.now(timezone.utc) + timedelta(days=5)).isoformat()
            # Update only the most recent row
            conn.execute(text(
                "UPDATE queries SET timestamp = :ts WHERE id = (SELECT id FROM queries ORDER BY rowid DESC LIMIT 1)"
            ), {"ts": future})
            conn.commit()
        span = store.data_span_days("test-proj")
        self.assertGreaterEqual(span, 4.9)

    def test_get_latest_health_status_one_row_per_service_metric(self):
        store, _ = self._store()
        for i in range(3):
            store.insert_health_metric({
                "project": "p", "service": "redis",
                "metric": "latency_ms", "value": float(i + 1), "status": "healthy",
            })
        rows = store.get_latest_health_status("p")
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["value"], 3.0)

    def test_get_unacknowledged_alerts_excludes_acked(self):
        store, _ = self._store()
        store.insert_alert({"project": "p", "alert_type": "cost_spike", "message": "x"})
        alert_id = store.get_unacknowledged_alerts("p")[0]["id"]
        store.acknowledge_alert(alert_id)
        self.assertEqual(store.get_unacknowledged_alerts("p"), [])

    def test_migration_runner_sets_user_version(self):
        import sqlite3
        _, db_path = self._store()
        conn = sqlite3.connect(str(db_path))
        version = conn.execute("PRAGMA user_version").fetchone()[0]
        conn.close()
        self.assertEqual(version, 1)


class ServiceTrackersSpec06Tests(unittest.TestCase):
    """Spec 06 — service tracker unit tests."""

    def _store_and_client(self):
        import tempfile
        from unittest.mock import MagicMock

        tmp = tempfile.mkdtemp()
        db_path = os.path.join(tmp, "data.db")
        store = SqliteStore(db_path)

        cp = MagicMock()
        cp.project = "test-project"
        cp.store = store
        cp.environment = "local"
        cp.estimate_service_cost = MagicMock(return_value=0.0)
        return store, cp

    def test_redis_tracker_writes_one_row(self):
        from costpilot.services.trackers import RedisTracker
        import time as _time

        store, cp = self._store_and_client()
        with RedisTracker(cp, "GET", "session:*") as t:
            t.record(hit=True)

        rows = store.get_service_stats("test-project", days=1)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["service"], "redis")

    def test_redis_tracker_hit_false_recorded(self):
        from costpilot.services.trackers import RedisTracker
        import json

        store, cp = self._store_and_client()
        with RedisTracker(cp, "SET", "embedding:*") as t:
            t.record(hit=False)

        # Verify via raw insert list — check metadata contains hit: false
        since = __import__("datetime").datetime.now(__import__("datetime").timezone.utc) - __import__("datetime").timedelta(days=1)
        usage_rows = store.get_queries_paginated(project="test-project", since=since, limit=10)
        # service_usage not in queries table; get_service_stats suffices
        stats = store.get_service_stats("test-project", days=1)
        self.assertEqual(stats[0]["service"], "redis")

    def test_qdrant_tracker_writes_one_row_with_vectors(self):
        from costpilot.services.trackers import QdrantTracker

        store, cp = self._store_and_client()
        with QdrantTracker(cp, "search", "documents") as t:
            t.record(vectors_searched=10, hits=7)

        stats = store.get_service_stats("test-project", days=1)
        self.assertEqual(len(stats), 1)
        self.assertEqual(stats[0]["service"], "qdrant")
        self.assertEqual(int(stats[0]["units"]), 10)

    def test_qdrant_tracker_units_fallback_to_one(self):
        from costpilot.services.trackers import QdrantTracker

        store, cp = self._store_and_client()
        with QdrantTracker(cp, "upsert", "docs") as t:
            pass  # no record() call → vectors=0 → units=1

        stats = store.get_service_stats("test-project", days=1)
        self.assertEqual(int(stats[0]["units"]), 1)

    def test_appwrite_tracker_writes_success_row(self):
        from costpilot.services.trackers import track_appwrite

        store, cp = self._store_and_client()

        @track_appwrite(cp, service="rag-orchestrator", operation="execute")
        def run_pipeline():
            return "ok"

        run_pipeline()
        stats = store.get_service_stats("test-project", days=1)
        self.assertEqual(stats[0]["service"], "appwrite")

    def test_appwrite_tracker_records_error_status(self):
        from costpilot.services.trackers import track_appwrite

        store, cp = self._store_and_client()

        @track_appwrite(cp, service="rag-orchestrator", operation="execute")
        def run_bad():
            raise RuntimeError("boom")

        with self.assertRaises(RuntimeError):
            run_bad()

        # Row still written (finally block)
        stats = store.get_service_stats("test-project", days=1)
        self.assertEqual(len(stats), 1)
        self.assertEqual(stats[0]["service"], "appwrite")

    def test_redis_pattern_helper_redacts_variable_segments(self):
        from costpilot.helpers import redis_pattern

        self.assertEqual(redis_pattern("session:abc123:profile"), "session:*:profile")
        self.assertEqual(redis_pattern("user:alice@example.com"), "user:*")
        self.assertEqual(redis_pattern("static-key"), "static-key")
        self.assertEqual(redis_pattern("embed:deadbeef-1234-5678-abcd-ef0123456789"), "embed:*")

    def test_redis_pattern_exported_from_package(self):
        from costpilot import redis_pattern  # noqa: F401

    def test_each_tracker_writes_exactly_one_row(self):
        from costpilot.services.trackers import QdrantTracker, RedisTracker, track_appwrite

        store, cp = self._store_and_client()

        with RedisTracker(cp, "GET", "k:*") as t:
            t.record(hit=True)
        with QdrantTracker(cp, "search", "col") as t:
            t.record(vectors_searched=5, hits=3)

        @track_appwrite(cp, service="fn", operation="run")
        def fn():
            pass

        fn()

        stats = store.get_service_stats("test-project", days=1)
        self.assertEqual(len(stats), 3)

    def test_local_environment_cost_is_zero(self):
        """Spec 06: estimated_cost_usd = 0 in local mode."""
        from costpilot.services.trackers import RedisTracker
        from unittest.mock import MagicMock
        import tempfile

        tmp = tempfile.mkdtemp()
        store = SqliteStore(os.path.join(tmp, "db.db"))
        cp = MagicMock()
        cp.project = "p"
        cp.store = store
        cp.environment = "local"
        # Real estimate_service_cost returns 0 for "local"
        cp.estimate_service_cost = MagicMock(return_value=0.0)

        with RedisTracker(cp, "GET", "x:*") as t:
            t.record(hit=False)

        stats = store.get_service_stats("p", days=1)
        self.assertEqual(float(stats[0].get("estimated_cost_usd", 0)), 0.0)


class ScenarioEngineSpec07Tests(unittest.TestCase):
    """Spec 07 — scenario engine and data gate unit tests."""

    def _engine_with_rows(self, n_rows: int = 0, span_days: int = 0):
        import tempfile
        from unittest.mock import MagicMock
        from datetime import datetime, timezone, timedelta
        import uuid

        tmp = tempfile.mkdtemp()
        store = SqliteStore(os.path.join(tmp, "db.db"))

        pricing = MagicMock()
        pricing.usd_to_inr = 83.5
        pricing.infrastructure_rate = MagicMock(return_value={"tier": "Projected", "per_hour": 0.05, "per_million_queries": 2.0, "per_million_executions": 1.0})

        # Insert n_rows queries spanning span_days
        now = datetime.now(timezone.utc)
        for i in range(n_rows):
            # Spread evenly across span_days (or all at same time if 0)
            if span_days > 0:
                offset = timedelta(days=(i / max(n_rows - 1, 1)) * span_days) if n_rows > 1 else timedelta(0)
            else:
                offset = timedelta(0)
            ts = now - timedelta(days=span_days) + offset  # datetime object, not ISO string
            store.insert_query({
                "id": str(uuid.uuid4()),
                "project": "p",
                "feature": "f",
                "provider": "anthropic",
                "model": "claude-haiku-4-5",
                "input_tokens": 100,
                "output_tokens": 50,
                "cache_read_tokens": 0,
                "cache_write_tokens": 0,
                "system_prompt_tokens": 10,
                "context_tokens": 90,
                "embedding_tokens": 0,
                "cost_usd": 0.001,
                "latency_ms": 200,
                "timestamp": ts,
                "user_id_hash": None,
                "session_id_hash": None,
            })

        from costpilot.scenario.engine import ScenarioEngine
        engine = ScenarioEngine(store, pricing)
        return engine, store, pricing

    def test_project_raises_insufficient_data_below_500_queries(self):
        from costpilot.exceptions import InsufficientDataError
        engine, _, _ = self._engine_with_rows(n_rows=10, span_days=5)
        with self.assertRaises(InsufficientDataError) as ctx:
            engine.project("p", daily_users=100, queries_per_user=5)
        self.assertIn("500", str(ctx.exception))

    def test_project_raises_insufficient_data_below_3_days(self):
        from costpilot.exceptions import InsufficientDataError
        engine, _, _ = self._engine_with_rows(n_rows=600, span_days=1)
        with self.assertRaises(InsufficientDataError) as ctx:
            engine.project("p", daily_users=100, queries_per_user=5)
        self.assertIn("3", str(ctx.exception))

    def test_project_returns_correct_shape_when_gates_pass(self):
        engine, _, _ = self._engine_with_rows(n_rows=600, span_days=5)
        result = engine.project("p", daily_users=1000, queries_per_user=5)
        self.assertIn("project", result)
        self.assertIn("measured_baseline", result)
        self.assertIn("projection", result)
        self.assertIn("optimizations", result)
        self.assertEqual(result["projection"]["queries_per_month"], 1000 * 5 * 30)

    def test_project_monthly_cost_matches_hand_calculation(self):
        engine, _, _ = self._engine_with_rows(n_rows=600, span_days=5)
        result = engine.project("p", daily_users=100, queries_per_user=1)
        # avg_cost = 0.001, model_mix = 100% haiku, queries_per_month = 3000
        expected = round(3000 * 1.0 * 0.001, 2)
        self.assertAlmostEqual(result["projection"]["monthly_cost_usd"], expected, places=2)

    def test_optimizations_filtered_implausible_save_pct(self):
        engine, _, _ = self._engine_with_rows(n_rows=600, span_days=5)
        result = engine.project("p", daily_users=1000, queries_per_user=5)
        for opt in result["optimizations"]:
            self.assertGreater(opt["save_pct"], 0.01)
            self.assertLess(opt["save_pct"], 0.95)

    def test_pre_migration_report_raises_below_14_days(self):
        from costpilot.exceptions import InsufficientDataError
        engine, _, _ = self._engine_with_rows(n_rows=100, span_days=5)
        with self.assertRaises(InsufficientDataError) as ctx:
            engine.pre_migration_report("p", "azure")
        self.assertIn("14", str(ctx.exception))

    def test_pre_migration_report_returns_correct_shape(self):
        engine, _, _ = self._engine_with_rows(n_rows=100, span_days=15)
        result = engine.pre_migration_report("p", "azure")
        self.assertIn("line_items", result)
        self.assertIn("totals", result)
        self.assertIn("caveats", result)
        self.assertEqual(result["target_cloud"], "azure")
        self.assertGreater(result["totals"]["monthly_cost_usd"], 0)

    def test_pre_migration_report_persisted_to_store(self):
        from costpilot.storage.models import MigrationReport
        engine, store, _ = self._engine_with_rows(n_rows=100, span_days=15)
        engine.pre_migration_report("p", "gcp")
        with store._session() as session:
            rows = session.query(MigrationReport).filter_by(project="p").all()
        self.assertEqual(len(rows), 1)

    def test_insufficient_data_error_exported_from_package(self):
        from costpilot import InsufficientDataError  # noqa: F401


if __name__ == "__main__":
    unittest.main()
