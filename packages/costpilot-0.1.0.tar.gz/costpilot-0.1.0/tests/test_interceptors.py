"""
Unit tests for spec 01-sdk.md interceptor contract.

Tests run without real LLM calls or network access — the provider client
is mocked; only the interceptor + sanitizer + pricing + store are real.
"""
from __future__ import annotations

import pathlib
import tempfile
import types
import unittest
import uuid
from typing import Any
from unittest.mock import MagicMock, patch

from costpilot.interceptors.anthropic import AnthropicInterceptor
from costpilot.interceptors.foundry import FoundryInterceptor
from costpilot.interceptors.openai import OpenAIInterceptor
from costpilot.pricing import PricingRegistry
from costpilot.privacy import DataSanitizer
from costpilot.storage import SqliteStore


# ---------------------------------------------------------------------------
# Minimal cp_client stand-in — avoids config/auth machinery
# ---------------------------------------------------------------------------

class _FakeCostPilotClient:
    """Replicates the subset of CostPilotClient used by interceptors."""

    def __init__(self, store: SqliteStore, pricing: PricingRegistry, *, user_id: str | None = None) -> None:
        self.project = "test-project"
        self.feature = None
        self.user_id = user_id
        self.session_id = None
        self.mode = "self-host"
        self.pricing = pricing
        self.store = store
        self.sanitizer = DataSanitizer()
        self.cloud_sync = None
        # minimal config for hashing
        self._salt = "test-salt-abc"
        self.config = types.SimpleNamespace(privacy=types.SimpleNamespace(salt=self._salt))

    def record_llm_call(
        self,
        *,
        provider: str,
        model: str,
        input_tokens: int,
        output_tokens: int,
        cache_read_tokens: int = 0,
        cache_write_tokens: int = 0,
        system_prompt_tokens: int = 0,
        context_tokens: int | None = None,
        embedding_tokens: int = 0,
        latency_ms: int | None = None,
    ) -> dict[str, Any]:
        cost = self.pricing.calculate_cost(
            model=model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cache_read_tokens=cache_read_tokens,
            cache_write_tokens=cache_write_tokens,
        )
        raw = {
            "id": str(uuid.uuid4()),
            "project": self.project,
            "feature": self.feature,
            "user_id_hash": self.sanitizer.hash_user_id(self.user_id, self._salt) if self.user_id else None,
            "session_id_hash": None,
            "provider": provider,
            "model": model,
            "input_tokens": int(input_tokens or 0),
            "output_tokens": int(output_tokens or 0),
            "embedding_tokens": int(embedding_tokens or 0),
            "cache_read_tokens": int(cache_read_tokens or 0),
            "cache_write_tokens": int(cache_write_tokens or 0),
            "system_prompt_tokens": int(system_prompt_tokens or 0),
            "context_tokens": (
                int(context_tokens)
                if context_tokens is not None
                else max(0, int(input_tokens or 0) - int(system_prompt_tokens or 0) - 200)
            ),
            "cost_usd": cost,
            "latency_ms": latency_ms,
            # kitchen-sink pollution that must NOT survive sanitization
            "prompt_content": "CANARY-raw-text",
            "response_content": "CANARY-response-text",
        }
        safe = self.sanitizer.sanitize_for_storage(raw)
        self.store.insert_query(safe)
        if self.mode == "cloud" and self.cloud_sync:
            self.cloud_sync.push(safe)
        return safe


def _make_env() -> tuple[_FakeCostPilotClient, SqliteStore, PricingRegistry]:
    db_path = pathlib.Path(tempfile.mkdtemp()) / "data.db"
    store = SqliteStore(db_path)
    pricing = PricingRegistry(store=store)
    cp = _FakeCostPilotClient(store, pricing, user_id="user_123")
    return cp, store, pricing


# ---------------------------------------------------------------------------
# Helpers — mock provider responses
# ---------------------------------------------------------------------------

def _anthropic_response(model: str = "claude-haiku-4-5", input_tokens: int = 100, output_tokens: int = 50) -> Any:
    usage = types.SimpleNamespace(
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        cache_read_input_tokens=0,
        cache_creation_input_tokens=0,
    )
    return types.SimpleNamespace(usage=usage, model=model)


def _openai_chat_response(model: str = "gpt-4o-mini", prompt_tokens: int = 80, completion_tokens: int = 40) -> Any:
    usage = types.SimpleNamespace(prompt_tokens=prompt_tokens, completion_tokens=completion_tokens)
    return types.SimpleNamespace(usage=usage, model=model)


def _openai_embedding_response(model: str = "text-embedding-3-small", total_tokens: int = 60) -> Any:
    usage = types.SimpleNamespace(total_tokens=total_tokens)
    return types.SimpleNamespace(usage=usage, model=model)


# ---------------------------------------------------------------------------
# Anthropic interceptor tests
# ---------------------------------------------------------------------------

class TestAnthropicInterceptorUnit(unittest.TestCase):
    def setUp(self) -> None:
        self.cp, self.store, self.pricing = _make_env()

    def _make_interceptor(self, response: Any) -> AnthropicInterceptor:
        mock_messages = MagicMock()
        mock_messages.create.return_value = response
        mock_client = MagicMock()
        mock_client.messages = mock_messages
        return AnthropicInterceptor(mock_client, self.cp)

    def test_row_inserted_after_create(self) -> None:
        interceptor = self._make_interceptor(_anthropic_response())
        interceptor.messages.create(model="claude-haiku-4-5", max_tokens=100, messages=[])
        rows = self.store.get_queries_paginated(project="test-project")
        self.assertEqual(len(rows), 1)

    def test_sanitizer_invoked__prompt_content_absent(self) -> None:
        interceptor = self._make_interceptor(_anthropic_response())
        with patch.object(self.cp.sanitizer, "sanitize_for_storage", wraps=self.cp.sanitizer.sanitize_for_storage) as spy:
            interceptor.messages.create(model="claude-haiku-4-5", max_tokens=100, messages=[])
            spy.assert_called_once()
        rows = self.store.get_queries_paginated(project="test-project")
        self.assertNotIn("prompt_content", rows[0])
        self.assertNotIn("response_content", rows[0])

    def test_provider_field_is_anthropic(self) -> None:
        interceptor = self._make_interceptor(_anthropic_response())
        interceptor.messages.create(model="claude-haiku-4-5", max_tokens=100, messages=[])
        rows = self.store.get_queries_paginated(project="test-project")
        self.assertEqual(rows[0]["provider"], "anthropic")

    def test_cost_usd_positive_for_known_model(self) -> None:
        interceptor = self._make_interceptor(_anthropic_response(model="claude-haiku-4-5"))
        interceptor.messages.create(model="claude-haiku-4-5", max_tokens=100, messages=[])
        rows = self.store.get_queries_paginated(project="test-project")
        self.assertGreater(rows[0]["cost_usd"], 0.0)

    def test_cost_zero_and_audit_log_for_unknown_model(self) -> None:
        interceptor = self._make_interceptor(_anthropic_response(model="completely-unknown-model-xyz"))
        interceptor.messages.create(model="completely-unknown-model-xyz", max_tokens=100, messages=[])
        rows = self.store.get_queries_paginated(project="test-project")
        self.assertEqual(rows[0]["cost_usd"], 0.0)
        audit = self.store.get_audit_log(limit=10)
        event_types = [r["event_type"] for r in audit]
        self.assertIn("unknown_model", event_types)

    def test_user_id_is_hashed_not_raw(self) -> None:
        interceptor = self._make_interceptor(_anthropic_response())
        interceptor.messages.create(model="claude-haiku-4-5", max_tokens=100, messages=[])
        rows = self.store.get_queries_paginated(project="test-project")
        self.assertIsNotNone(rows[0]["user_id_hash"])
        self.assertNotEqual(rows[0]["user_id_hash"], "user_123")

    def test_system_prompt_tokens_counted_text_never_stored(self) -> None:
        interceptor = self._make_interceptor(_anthropic_response(input_tokens=200))
        interceptor.messages.create(
            model="claude-haiku-4-5",
            max_tokens=100,
            system="You are a helpful assistant.",
            messages=[],
        )
        rows = self.store.get_queries_paginated(project="test-project")
        self.assertGreater(rows[0]["system_prompt_tokens"], 0)
        self.assertNotIn("system", rows[0])

    def test_response_returned_unchanged(self) -> None:
        resp = _anthropic_response()
        interceptor = self._make_interceptor(resp)
        result = interceptor.messages.create(model="claude-haiku-4-5", max_tokens=100, messages=[])
        self.assertIs(result, resp)

    def test_getattr_delegates_to_underlying_client(self) -> None:
        mock_messages = MagicMock()
        mock_messages.create.return_value = _anthropic_response()
        mock_client = MagicMock()
        mock_client.messages = mock_messages
        mock_client.api_key = "test-key-123"
        interceptor = AnthropicInterceptor(mock_client, self.cp)
        self.assertEqual(interceptor.api_key, "test-key-123")


# ---------------------------------------------------------------------------
# OpenAI chat completions interceptor tests
# ---------------------------------------------------------------------------

class TestOpenAIChatInterceptorUnit(unittest.TestCase):
    def setUp(self) -> None:
        self.cp, self.store, self.pricing = _make_env()

    def _make_interceptor(self, response: Any, *, provider: str = "openai") -> OpenAIInterceptor:
        mock_completions = MagicMock()
        mock_completions.create.return_value = response
        mock_chat = MagicMock()
        mock_chat.completions = mock_completions
        mock_client = MagicMock()
        mock_client.chat = mock_chat
        mock_client.embeddings = MagicMock()
        return OpenAIInterceptor(mock_client, self.cp, provider=provider)

    def test_row_inserted_after_create(self) -> None:
        interceptor = self._make_interceptor(_openai_chat_response())
        interceptor.chat.completions.create(model="gpt-4o-mini", messages=[])
        rows = self.store.get_queries_paginated(project="test-project")
        self.assertEqual(len(rows), 1)

    def test_sanitizer_invoked__prompt_content_absent(self) -> None:
        interceptor = self._make_interceptor(_openai_chat_response())
        with patch.object(self.cp.sanitizer, "sanitize_for_storage", wraps=self.cp.sanitizer.sanitize_for_storage) as spy:
            interceptor.chat.completions.create(model="gpt-4o-mini", messages=[])
            spy.assert_called_once()
        rows = self.store.get_queries_paginated(project="test-project")
        self.assertNotIn("prompt_content", rows[0])

    def test_provider_field_openai(self) -> None:
        interceptor = self._make_interceptor(_openai_chat_response(), provider="openai")
        interceptor.chat.completions.create(model="gpt-4o-mini", messages=[])
        rows = self.store.get_queries_paginated(project="test-project")
        self.assertEqual(rows[0]["provider"], "openai")

    def test_provider_field_azure(self) -> None:
        interceptor = self._make_interceptor(_openai_chat_response(), provider="azure-openai")
        interceptor.chat.completions.create(model="gpt-4o-mini", messages=[])
        rows = self.store.get_queries_paginated(project="test-project")
        self.assertEqual(rows[0]["provider"], "azure-openai")

    def test_cost_usd_positive_for_known_model(self) -> None:
        interceptor = self._make_interceptor(_openai_chat_response(model="gpt-4o-mini"))
        interceptor.chat.completions.create(model="gpt-4o-mini", messages=[])
        rows = self.store.get_queries_paginated(project="test-project")
        self.assertGreater(rows[0]["cost_usd"], 0.0)

    def test_cost_zero_and_audit_log_for_unknown_model(self) -> None:
        interceptor = self._make_interceptor(_openai_chat_response(model="gpt-999-ultra"))
        interceptor.chat.completions.create(model="gpt-999-ultra", messages=[])
        rows = self.store.get_queries_paginated(project="test-project")
        self.assertEqual(rows[0]["cost_usd"], 0.0)
        audit = self.store.get_audit_log(limit=10)
        self.assertIn("unknown_model", [r["event_type"] for r in audit])

    def test_user_id_hashed(self) -> None:
        interceptor = self._make_interceptor(_openai_chat_response())
        interceptor.chat.completions.create(model="gpt-4o-mini", messages=[])
        rows = self.store.get_queries_paginated(project="test-project")
        self.assertNotEqual(rows[0]["user_id_hash"], "user_123")

    def test_stream_passthrough_not_intercepted(self) -> None:
        mock_stream = object()
        mock_completions = MagicMock()
        mock_completions.create.return_value = mock_stream
        mock_chat = MagicMock()
        mock_chat.completions = mock_completions
        mock_client = MagicMock()
        mock_client.chat = mock_chat
        mock_client.embeddings = MagicMock()
        interceptor = OpenAIInterceptor(mock_client, self.cp)
        result = interceptor.chat.completions.create(model="gpt-4o-mini", messages=[], stream=True)
        self.assertIs(result, mock_stream)
        rows = self.store.get_queries_paginated(project="test-project")
        self.assertEqual(rows, [])

    def test_response_returned_unchanged(self) -> None:
        resp = _openai_chat_response()
        interceptor = self._make_interceptor(resp)
        result = interceptor.chat.completions.create(model="gpt-4o-mini", messages=[])
        self.assertIs(result, resp)


# ---------------------------------------------------------------------------
# OpenAI embeddings interceptor tests
# ---------------------------------------------------------------------------

class TestOpenAIEmbeddingsInterceptorUnit(unittest.TestCase):
    def setUp(self) -> None:
        self.cp, self.store, self.pricing = _make_env()

    def _make_interceptor(self, response: Any) -> OpenAIInterceptor:
        mock_embeddings = MagicMock()
        mock_embeddings.create.return_value = response
        mock_client = MagicMock()
        mock_client.chat = MagicMock()
        mock_client.chat.completions = MagicMock()
        mock_client.embeddings = mock_embeddings
        return OpenAIInterceptor(mock_client, self.cp)

    def test_row_inserted_with_embedding_tokens(self) -> None:
        interceptor = self._make_interceptor(_openai_embedding_response(total_tokens=60))
        interceptor.embeddings.create(model="text-embedding-3-small", input="hello world")
        rows = self.store.get_queries_paginated(project="test-project")
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["embedding_tokens"], 60)

    def test_output_tokens_zero_for_embeddings(self) -> None:
        interceptor = self._make_interceptor(_openai_embedding_response())
        interceptor.embeddings.create(model="text-embedding-3-small", input="test")
        rows = self.store.get_queries_paginated(project="test-project")
        self.assertEqual(rows[0]["output_tokens"], 0)


# ---------------------------------------------------------------------------
# Sanitizer whitelist contract
# ---------------------------------------------------------------------------

class TestSanitizerWhitelist(unittest.TestCase):
    def test_only_whitelisted_fields_survive(self) -> None:
        san = DataSanitizer()
        raw = {
            "id": "abc",
            "project": "proj",
            "provider": "anthropic",
            "model": "claude-haiku-4-5",
            "input_tokens": 100,
            "output_tokens": 50,
            "cost_usd": 0.001,
            "prompt_content": "MUST-NOT-SURVIVE",
            "response_content": "MUST-NOT-SURVIVE",
            "system_prompt_text": "MUST-NOT-SURVIVE",
            "user_email": "alice@example.com",
            "raw_user_id": "user_123",
            "ip_address": "1.2.3.4",
        }
        safe = san.sanitize_for_storage(raw)
        self.assertNotIn("prompt_content", safe)
        self.assertNotIn("response_content", safe)
        self.assertNotIn("system_prompt_text", safe)
        self.assertNotIn("user_email", safe)
        self.assertNotIn("raw_user_id", safe)
        self.assertNotIn("ip_address", safe)
        self.assertIn("id", safe)
        self.assertIn("cost_usd", safe)


# ---------------------------------------------------------------------------
# Responses API interceptor tests (OpenAI Responses API / Azure Foundry)
# ---------------------------------------------------------------------------

def _responses_response(
    model: str = "gpt-4o-mini",
    input_tokens: int = 80,
    output_tokens: int = 40,
) -> Any:
    usage = types.SimpleNamespace(input_tokens=input_tokens, output_tokens=output_tokens)
    return types.SimpleNamespace(usage=usage, model=model)


class TestResponsesAPIInterceptorUnit(unittest.TestCase):
    def setUp(self) -> None:
        self.cp, self.store, self.pricing = _make_env()

    def _make_interceptor(self, response: Any, *, provider: str = "azure-foundry") -> OpenAIInterceptor:
        mock_responses = MagicMock()
        mock_responses.create.return_value = response
        mock_client = MagicMock()
        mock_client.chat = MagicMock()
        mock_client.chat.completions = MagicMock()
        mock_client.embeddings = MagicMock()
        mock_client.responses = mock_responses
        return OpenAIInterceptor(mock_client, self.cp, provider=provider)

    def test_row_inserted_after_responses_create(self) -> None:
        interceptor = self._make_interceptor(_responses_response())
        interceptor.responses.create(model="gpt-4o-mini", input="Hello")
        rows = self.store.get_queries_paginated(project="test-project")
        self.assertEqual(len(rows), 1)

    def test_token_fields_use_input_output_not_prompt_completion(self) -> None:
        interceptor = self._make_interceptor(_responses_response(input_tokens=120, output_tokens=60))
        interceptor.responses.create(model="gpt-4o-mini", input="Hello")
        rows = self.store.get_queries_paginated(project="test-project")
        self.assertEqual(rows[0]["input_tokens"], 120)
        self.assertEqual(rows[0]["output_tokens"], 60)

    def test_provider_field_azure_foundry(self) -> None:
        interceptor = self._make_interceptor(_responses_response(), provider="azure-foundry")
        interceptor.responses.create(model="gpt-4o-mini", input="Hello")
        rows = self.store.get_queries_paginated(project="test-project")
        self.assertEqual(rows[0]["provider"], "azure-foundry")

    def test_response_returned_unchanged(self) -> None:
        resp = _responses_response()
        interceptor = self._make_interceptor(resp)
        result = interceptor.responses.create(model="gpt-4o-mini", input="Hello")
        self.assertIs(result, resp)

    def test_no_responses_attr_when_client_lacks_it(self) -> None:
        mock_client = MagicMock(spec=["chat", "embeddings"])
        mock_client.chat = MagicMock()
        mock_client.chat.completions = MagicMock()
        mock_client.embeddings = MagicMock()
        interceptor = OpenAIInterceptor(mock_client, self.cp)
        self.assertFalse(hasattr(interceptor, "responses"))


# ---------------------------------------------------------------------------
# FoundryInterceptor tests
# ---------------------------------------------------------------------------

class TestFoundryInterceptorUnit(unittest.TestCase):
    def setUp(self) -> None:
        self.cp, self.store, self.pricing = _make_env()

    def _make_foundry_client(self, chat_response: Any) -> MagicMock:
        mock_completions = MagicMock()
        mock_completions.create.return_value = chat_response
        mock_chat = MagicMock()
        mock_chat.completions = mock_completions
        mock_openai_client = MagicMock()
        mock_openai_client.chat = mock_chat
        mock_openai_client.embeddings = MagicMock()
        mock_foundry = MagicMock()
        mock_foundry.get_openai_client.return_value = mock_openai_client
        return mock_foundry

    def test_get_openai_client_returns_openai_interceptor(self) -> None:
        foundry = FoundryInterceptor(self._make_foundry_client(_openai_chat_response()), self.cp)
        openai_client = foundry.get_openai_client()
        self.assertIsInstance(openai_client, OpenAIInterceptor)

    def test_wrapped_client_uses_azure_foundry_provider(self) -> None:
        foundry = FoundryInterceptor(self._make_foundry_client(_openai_chat_response()), self.cp)
        openai_client = foundry.get_openai_client()
        openai_client.chat.completions.create(model="gpt-4o-mini", messages=[])
        rows = self.store.get_queries_paginated(project="test-project")
        self.assertEqual(rows[0]["provider"], "azure-foundry")

    def test_row_inserted_through_foundry_client(self) -> None:
        foundry = FoundryInterceptor(self._make_foundry_client(_openai_chat_response()), self.cp)
        openai_client = foundry.get_openai_client()
        openai_client.chat.completions.create(model="gpt-4o-mini", messages=[])
        rows = self.store.get_queries_paginated(project="test-project")
        self.assertEqual(len(rows), 1)

    def test_getattr_delegates_non_openai_attrs_to_underlying(self) -> None:
        mock_foundry = self._make_foundry_client(_openai_chat_response())
        mock_foundry.project_name = "my-foundry-project"
        foundry = FoundryInterceptor(mock_foundry, self.cp)
        self.assertEqual(foundry.project_name, "my-foundry-project")

    def test_context_manager_protocol_on_wrapped_openai_client(self) -> None:
        mock_openai = MagicMock()
        mock_openai.__enter__ = MagicMock(return_value=mock_openai)
        mock_openai.__exit__ = MagicMock(return_value=False)
        mock_openai.chat = MagicMock()
        mock_openai.chat.completions = MagicMock()
        mock_openai.chat.completions.create.return_value = _openai_chat_response()
        mock_openai.embeddings = MagicMock()
        mock_foundry = MagicMock()
        mock_foundry.get_openai_client.return_value = mock_openai
        foundry = FoundryInterceptor(mock_foundry, self.cp)
        wrapped = foundry.get_openai_client()
        with wrapped as client:
            client.chat.completions.create(model="gpt-4o-mini", messages=[])
        rows = self.store.get_queries_paginated(project="test-project")
        self.assertEqual(len(rows), 1)


if __name__ == "__main__":
    unittest.main()
