# CostPilot Python SDK

The SDK instruments LLM provider clients, writes sanitized cost records to local
SQLite, and optionally syncs those sanitized records to CostPilot cloud when a
cloud API key is configured.

```python
from costpilot import CostPilotClient
import anthropic

cp = CostPilotClient(project="blueprint-ai", user_id="user_123")
client = cp.wrap(anthropic.Anthropic())
response = client.messages.create(model="claude-haiku-4-5", messages=[])
```
