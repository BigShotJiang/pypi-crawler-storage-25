"""
### Tribulnation Indodax
> An SDK to connect Indodax with the Tribulnation ecosystem.

- Details
"""