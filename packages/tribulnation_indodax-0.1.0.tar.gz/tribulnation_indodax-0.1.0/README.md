# Tribulnation Indodax SDK

> An SDK to connect Indodax with the Tribulnation ecosystem.

🚧 Under construction.