"""后台守护进程：纯事件接力，不做决策。

两个职责：
1. Stop  — Worker 完成 → 通知 Supervisor
2. Stall — JSONL 心跳停跳（3 分钟无写入）→ 通知 Supervisor

v0.3: 遍历所有 mission 的所有 worker。
"""

from __future__ import annotations

import json
import logging
import os
import signal
import sys
import time
from pathlib import Path
from typing import Any
from xml.sax.saxutils import escape as xml_escape, quoteattr

from mation import cmux
from mation.state import (
    STATE_DIR,
    append_transcript,
    find_supervisor,
    iter_workers,
    load_global,
    load_mission,
    list_missions,
    save_mission,
    worker_session_id,
)
from mation.worker import resolve_worker

STATE_DIR.mkdir(parents=True, exist_ok=True)
LOG_FILE = STATE_DIR / "daemon.log"
RUNTIME_STATE_FILE = STATE_DIR / "daemon-runtime.json"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [daemon] %(message)s",
    handlers=[logging.FileHandler(LOG_FILE)],
)
log = logging.getLogger(__name__)

POLL_INTERVAL = 2
MIN_NOTIFY_INTERVAL = 10  # 最小通知间隔，防刷屏
STALL_TIMEOUT = 180  # JSONL 无写入多久后视为 stall（秒）
STALL_MAX_COUNT = 10  # 连续 stall 事件最多发送次数（到达上限后终止自动提醒）
REPLY_INLINE_LIMIT = 200  # stop reply 超过此长度则截断，完整内容溢写到文件


def stop_file(session_id: str) -> Path:
    return STATE_DIR / f"stop-{session_id}"


def _send_to_surface(surface_id: str, message: str) -> None:
    try:
        cmux.send_text(surface_id, message)
    except RuntimeError as e:
        log.error(f"Failed to send to {surface_id}: {e}")


def notify_supervisor(mission: dict[str, Any], message: str) -> None:
    """通知 mission 的 supervisor。claim 缺失或 resolve 失败则丢事件。"""
    mission_name = mission.get("name", "?")
    sup = find_supervisor(mission)
    if not sup:
        # 理论上不可达：主循环已过滤 unclaimed mission。保留作为 defensive guard。
        log.debug(
            "notify_supervisor called on mission %r with no supervisor, dropping: %s",
            mission_name, message[:80],
        )
        return
    info = resolve_worker(sup["session"])
    if not info.running or not info.surface_id:
        log.warning(
            "Supervisor session %r for mission %r not reachable (not found via ps), dropping event",
            sup.get("session"), mission_name,
        )
        return
    # 替换换行符，避免 Escape 打断 Supervisor 正在运行的 generation
    safe_message = message.replace("\n", " ")
    log.info(
        "→ Supervisor[%s] %s: %s",
        mission_name, info.surface_id[:8], safe_message[:120],
    )
    _send_to_surface(info.surface_id, safe_message)


# 每个 (mission, worker) 组合的时间戳追踪
_last_notify: dict[str, float] = {}   # key: "mission:session"
_last_stall: dict[str, float] = {}
# 自治降级状态：连续 stall 计数。stop 到达时清零。
_stall_count: dict[str, int] = {}
# 终态（A0）只发一次，后续不再重复提醒。
_stall_closed: set[str] = set()
# worker create 成功返回已覆盖初始化确认：每个 worker 的首个 stop 事件不再推送。
_first_stop_suppressed: set[str] = set()


def _load_runtime_state() -> None:
    """Load persisted runtime state on daemon startup."""
    global _last_notify, _last_stall, _stall_count, _stall_closed
    try:
        if not RUNTIME_STATE_FILE.exists():
            return
        data = json.loads(RUNTIME_STATE_FILE.read_text())
        _last_notify = data.get("last_notify", {})
        _last_stall = data.get("last_stall", {})
        _stall_count = data.get("stall_count", {})
        _stall_closed = set(data.get("stall_closed", []))
        log.info(
            "Loaded runtime state: %d stall keys, %d closed",
            len(_stall_count), len(_stall_closed),
        )
    except Exception as e:
        log.warning("Failed to load runtime state, starting fresh: %s", e)


def _save_runtime_state() -> None:
    """Atomically persist runtime state so it survives daemon restart."""
    try:
        data = {
            "last_notify": _last_notify,
            "last_stall": _last_stall,
            "stall_count": _stall_count,
            "stall_closed": list(_stall_closed),
        }
        tmp = RUNTIME_STATE_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(data))
        tmp.rename(RUNTIME_STATE_FILE)
    except Exception as e:
        log.warning("Failed to save runtime state: %s", e)


def _build_event_xml(
    kind: str,
    attrs: dict[str, str],
    body: str = "",
) -> str:
    """Build a well-formed `<mation event=... ...>body</mation>` element.

    - Attribute values go through `xml.sax.saxutils.quoteattr` (which
      handles both quoting and escaping in one step and returns the value
      already wrapped in quotes).
    - `body` is embedded **as-is**. The caller is responsible for
      constructing valid body content: plain text must already be
      `xml_escape`-d, nested elements must have their own text content
      escaped. The helper does not guess structure.
    - Empty body → self-closing tag `<mation ... />`.

    Returns a single-line XML string (no embedded newlines).
    """
    attr_str = " ".join(f"{k}={quoteattr(v)}" for k, v in attrs.items())
    if attr_str:
        open_tag = f"<mation event={quoteattr(kind)} {attr_str}"
    else:
        open_tag = f"<mation event={quoteattr(kind)}"
    if not body:
        return f"{open_tag}/>"
    return f"{open_tag}>{body}</mation>"



def _format_stall_msg(
    mission_name: str,
    session: str,
    age: int,
    stall_count: int,
) -> str:
    return _build_event_xml(
        "stall",
        {
            "mission": mission_name,
            "worker": session,
            "silent": f"{age}s",
            "stall_count": str(stall_count),
            "stall_max": str(STALL_MAX_COUNT),
        },
    )


def _save_worker_output(
    mission_name: str,
    session: str,
    worker_name: str,
    content: str,
) -> Path | None:
    """把 Worker 的 stop 回复持久化到文件，返回路径。内容为空则返回 None。"""
    if not content:
        return None
    try:
        label = (worker_name or session[:8]).replace("/", "-").replace(" ", "_")
        ts = int(time.time() * 1000)
        out_dir = STATE_DIR / "missions" / mission_name / "worker-output"
        out_dir.mkdir(parents=True, exist_ok=True)
        out_file = out_dir / f"{label}-{ts}.md"
        out_file.write_text(content, encoding="utf-8")
        return out_file
    except Exception as e:
        log.warning("Failed to save worker output [%s/%s]: %s", mission_name, session, e)
        return None


def _format_stop_msg(
    mission_name: str,
    session: str,
    last_msg: str,
    output_file: Path | None = None,
) -> str:
    """构造 stop 事件消息，含嵌套 `<reply>` 元素。

    `last_msg` 是 Worker 任意文本回复（经常包含 `<`, `>`, `&`, 甚至字面
    `</reply>` / `</mation>` ——review 报告、代码示例、XML 讨论都会命中），
    必须在包进 `<reply>` 前 `xml_escape`。外层标签和属性交给 `_build_event_xml`。
    """
    attrs: dict[str, str] = {"mission": mission_name, "worker": session}
    if output_file:
        attrs["output_file"] = str(output_file)
    escaped_reply = xml_escape(last_msg)
    return _build_event_xml("stop", attrs, f"<reply>{escaped_reply}</reply>")


def _format_aggregated_stall_msg(
    mission_name: str,
    stalls: list[dict[str, Any]],
) -> str:
    """多 worker 同时 stall 时的聚合消息，一条代替 N 条。"""
    max_count = max(s["stall_count"] for s in stalls)
    return _build_event_xml(
        "stall",
        {
            "mission": mission_name,
            "workers": str(len(stalls)),
            "stall_count_max": str(max_count),
            "stall_max": str(STALL_MAX_COUNT),
        },
    )


def _mark_worker_bootstrapped(mission_name: str, session: str) -> None:
    """Persist bootstrapped=True so daemon restart doesn't re-suppress the next stop."""
    try:
        m = load_mission(mission_name)
        if m is None:
            return
        for p in m.get("participants", []):
            if p.get("role") == "worker" and p.get("session") == session:
                p["bootstrapped"] = True
                save_mission(mission_name, m)
                return
    except Exception as e:
        log.warning("Failed to mark worker %s bootstrapped: %s", session, e)


def _check_worker(
    mission_name: str,
    mission: dict[str, Any],
    worker: dict[str, Any],
) -> dict[str, Any] | None:
    """对一个 worker 做 stop/stall 检测。

    Stop 事件：立即通知 supervisor，返回 None。
    Stall 事件：更新状态后返回 stall info dict，由调用方聚合发送。
    无事件：返回 None。
    """
    session = worker.get("session")
    if not session:
        return None

    session_id = worker_session_id(worker)
    if not session_id:
        return None

    key = f"{mission_name}:{session}"
    sf = stop_file(session_id)

    if sf.exists():
        try:
            stop_data = json.loads(sf.read_text())
            last_msg = stop_data.get("last_assistant_message", "")
        except (json.JSONDecodeError, OSError):
            last_msg = ""

        sf.unlink(missing_ok=True)
        _last_stall.pop(key, None)
        _stall_count.pop(key, None)
        _stall_closed.discard(key)

        now = time.time()
        last = _last_notify.get(key, 0)
        if now - last < MIN_NOTIFY_INTERVAL:
            log.info("Stop signal consumed, throttled (%.0fs since last notify)", now - last)
        else:
            # Persist Worker→Supervisor reply to transcript before notifying.
            # append_transcript never raises — observability must not break
            # the main event-relay flow.
            append_transcript(
                mission_name,
                direction="worker_to_sup",
                worker=session,
                content=last_msg,
                kind="stop_reply",
            )
            if session not in _first_stop_suppressed:
                _first_stop_suppressed.add(session)
                _last_notify[key] = now
                log.info("Initial stop suppressed [%s/%s]", mission_name, session)
                _mark_worker_bootstrapped(mission_name, session)
            else:
                output_file: Path | None = None
                inline_reply = last_msg
                if len(last_msg) > REPLY_INLINE_LIMIT:
                    output_file = _save_worker_output(
                        mission_name, session, worker.get("name") or "", last_msg
                    )
                    inline_reply = last_msg[:REPLY_INLINE_LIMIT] + "…"
                msg = _format_stop_msg(mission_name, session, inline_reply, output_file)
                notify_supervisor(mission, msg)
                _last_notify[key] = now
                log.info("Stop signal consumed [%s/%s]", mission_name, session)
        _save_runtime_state()
        return None

    else:
        # Stall 检测：JSONL mtime 作为 Worker 活跃心跳
        cache = worker.get("cache") or {}
        jsonl = cache.get("jsonl_path")
        if jsonl:
            jsonl_path = Path(jsonl)
            if jsonl_path.exists():
                mtime = jsonl_path.stat().st_mtime
                now = time.time()
                age = now - mtime
                last_stall = _last_stall.get(key, 0)
                # 渐进式退避：1st=180s, 2nd=240s, 3rd+=300s
                count_so_far = _stall_count.get(key, 0)
                effective_timeout = min(STALL_TIMEOUT + count_so_far * 60, 300)
                if age > effective_timeout and now - last_stall > effective_timeout:
                    if key in _stall_closed:
                        _last_stall[key] = now
                        log.info(
                            "JSONL stall suppressed (closed) [%s/%s] (%ds)",
                            mission_name,
                            session,
                            int(age),
                        )
                        _save_runtime_state()
                        return None

                    count = _stall_count.get(key, 0) + 1
                    _stall_count[key] = count
                    _last_stall[key] = now
                    if count >= STALL_MAX_COUNT:
                        _stall_closed.add(key)
                    log.info(
                        "JSONL stall detected [%s/%s] (%ds) count=%d/%d",
                        mission_name,
                        session,
                        int(age),
                        count,
                        STALL_MAX_COUNT,
                    )
                    _save_runtime_state()
                    return {
                        "session": session,
                        "age": int(age),
                        "stall_count": count,
                    }
        return None


def run_daemon() -> None:
    log.info("Daemon started (pid=%d)", os.getpid())

    for f in STATE_DIR.glob("stop-*"):
        f.unlink(missing_ok=True)
        log.info(f"Cleaned stale signal: {f.name}")

    # Restore persisted runtime state (stall counts, notify timestamps, closed set).
    _load_runtime_state()

    # Pre-fill _first_stop_suppressed from persisted state so daemon restart
    # doesn't re-suppress the first real stop for already-bootstrapped workers.
    for _mn in list_missions():
        _m = load_mission(_mn)
        if _m:
            for _w in iter_workers(_m):
                if _w.get("bootstrapped", False):
                    _first_stop_suppressed.add(_w["session"])
    if _first_stop_suppressed:
        log.info("Pre-filled _first_stop_suppressed: %d sessions", len(_first_stop_suppressed))

    def handle_signal(signum: int, frame: Any) -> None:
        log.info("Daemon stopping")
        sys.exit(0)

    signal.signal(signal.SIGTERM, handle_signal)
    signal.signal(signal.SIGINT, handle_signal)

    while True:
        try:
            g = load_global()
            if g is None:
                log.info("No active mation, exiting")
                break

            for mission_name in list_missions():
                mission = load_mission(mission_name)
                if mission is None or mission.get("status") == "stopped":
                    continue
                # Unclaimed mission = dormant. 没 supervisor 说明还没 wire 起来，
                # 主动跳过比"跑完再丢弃"更干净，也不留 warning 噪声。
                if not find_supervisor(mission):
                    continue
                stall_batch: list[dict[str, Any]] = []
                for worker in iter_workers(mission):
                    stall = _check_worker(mission_name, mission, worker)
                    if stall:
                        stall_batch.append(stall)
                if stall_batch:
                    if len(stall_batch) == 1:
                        s = stall_batch[0]
                        msg = _format_stall_msg(
                            mission_name,
                            s["session"],
                            s["age"],
                            s["stall_count"],
                        )
                    else:
                        msg = _format_aggregated_stall_msg(mission_name, stall_batch)
                    notify_supervisor(mission, msg)

        except Exception as e:
            log.error(f"Daemon error: {e}")

        time.sleep(POLL_INTERVAL)
