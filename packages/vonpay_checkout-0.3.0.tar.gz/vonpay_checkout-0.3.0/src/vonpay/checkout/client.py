"""Von Payments Checkout SDK client."""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import logging
import math
import random
import re
import time
from urllib.parse import urlencode, urlparse
from datetime import datetime, timezone
from typing import Any, Dict, Optional, Union

import httpx

from vonpay.checkout.errors import VonPayError
from vonpay.checkout.types import (
    CheckoutSession,
    DryRunResult,
    ErrorReporter,
    ErrorReporterContext,
    HealthStatus,
    RateLimitInfo,
    SessionStatus,
    WebhookEvent,
)

_log = logging.getLogger("vonpay.checkout")

_DEFAULT_BASE_URL = "https://checkout.vonpay.com"
_DEFAULT_API_VERSION = "2026-04-14"
_DEFAULT_MAX_RETRIES = 2
_DEFAULT_TIMEOUT = 30.0
_RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}
_WEBHOOK_TIMESTAMP_TOLERANCE = 300  # 5 minutes
_VALID_KEY_PREFIXES = ("vp_sk_test_", "vp_sk_live_", "vp_pk_test_", "vp_pk_live_")

# Read version dynamically from installed package metadata to avoid drift with
# pyproject.toml. Falls back to "0.0.0" only in editable installs before build.
try:
    from importlib.metadata import version as _pkg_version

    _SDK_VERSION = _pkg_version("vonpay-checkout")
except Exception:  # pragma: no cover — fallback for unbuilt editable installs
    _SDK_VERSION = "0.0.0"
_HEX_64 = re.compile(r"^[0-9a-f]{64}$")
_UINT = re.compile(r"^[0-9]+$")


def _parse_v2_signature_header(header: str) -> Optional[Dict[str, Any]]:
    """Parse "t=<sec>,v2=<hex>" into {"t": int, "v2": str}. Returns None if malformed."""
    if not header:
        return None
    t_val: Optional[int] = None
    v2_val: Optional[str] = None
    for part in header.split(","):
        if "=" not in part:
            return None
        key, val = part.split("=", 1)
        key = key.strip()
        val = val.strip()
        if key == "t":
            if not _UINT.match(val):
                return None
            t_val = int(val)
        elif key == "v2":
            if not _HEX_64.match(val):
                return None
            v2_val = val
    if t_val is None or v2_val is None:
        return None
    return {"t": t_val, "v2": v2_val}


def _parse_rate_limit(headers: httpx.Headers) -> Optional[RateLimitInfo]:
    limit = headers.get("x-ratelimit-limit")
    if not limit:
        return None
    retry_after_raw = headers.get("retry-after")
    retry_after = None
    if retry_after_raw:
        try:
            retry_after = int(retry_after_raw)
        except ValueError:
            pass
    return RateLimitInfo(
        limit=int(limit),
        remaining=int(headers.get("x-ratelimit-remaining", "0")),
        reset=int(headers.get("x-ratelimit-reset", "0")),
        retry_after=retry_after,
    )


def _safe_url(url: str) -> str:
    """Strip query string from URL for safe inclusion in error context."""
    q = url.find("?")
    return url if q == -1 else url[:q]


def _camel_to_snake(name: str) -> str:
    """Convert camelCase to snake_case."""
    result = re.sub(r"([A-Z])", r"_\1", name).lower()
    return result.lstrip("_")


def _snake_to_camel(name: str) -> str:
    """Convert snake_case to camelCase."""
    parts = name.split("_")
    return parts[0] + "".join(p.capitalize() for p in parts[1:])


def _to_snake_keys(d: Dict[str, Any]) -> Dict[str, Any]:
    return {_camel_to_snake(k): v for k, v in d.items()}


def _to_camel_keys(d: Dict[str, Any]) -> Dict[str, Any]:
    return {_snake_to_camel(k): v for k, v in d.items() if v is not None}


class _Sessions:
    def __init__(self, client: VonPayCheckout) -> None:
        self._client = client

    def create(
        self,
        *,
        amount: int,
        currency: str,
        country: Optional[str] = None,
        description: Optional[str] = None,
        success_url: Optional[str] = None,
        cancel_url: Optional[str] = None,
        metadata: Optional[Dict[str, str]] = None,
        idempotency_key: Optional[str] = None,
    ) -> CheckoutSession:
        """Create a new checkout session."""
        body = _to_camel_keys(
            {
                "amount": amount,
                "currency": currency.upper(),
                "country": country.upper() if country else None,
                "description": description,
                "success_url": success_url,
                "cancel_url": cancel_url,
                "metadata": metadata,
            }
        )
        data = self._client._request(
            "POST",
            "/v1/sessions",
            json_body=body,
            idempotency_key=idempotency_key,
            reporter_method="sessions.create",
        )
        snake = _to_snake_keys(data)
        return CheckoutSession(
            id=snake["id"],
            checkout_url=snake["checkout_url"],
            expires_at=snake["expires_at"],
        )

    def get(self, session_id: str) -> SessionStatus:
        """Retrieve the current state of a checkout session.

        Requires a secret key (vp_sk_*). Publishable keys are rejected with 403.
        """
        data = self._client._request(
            "GET", f"/v1/sessions/{session_id}", reporter_method="sessions.get"
        )
        snake = _to_snake_keys(data)
        return SessionStatus(
            id=snake["id"],
            status=snake["status"],
            mode=snake["mode"],
            merchant_id=snake["merchant_id"],
            amount=snake["amount"],
            currency=snake["currency"],
            created_at=snake["created_at"],
            updated_at=snake["updated_at"],
            expires_at=snake["expires_at"],
            country=snake.get("country"),
            description=snake.get("description"),
            collect_shipping=snake.get("collect_shipping"),
            shipping_address=snake.get("shipping_address"),
            transaction_id=snake.get("transaction_id"),
            metadata=snake.get("metadata"),
        )

    def validate(
        self,
        *,
        amount: int,
        currency: str,
        country: Optional[str] = None,
        description: Optional[str] = None,
    ) -> DryRunResult:
        """Validate session params without creating a session (dry run)."""
        body = _to_camel_keys(
            {
                "amount": amount,
                "currency": currency.upper(),
                "country": country.upper() if country else None,
                "description": description,
            }
        )
        data = self._client._request(
            "POST",
            "/v1/sessions",
            json_body=body,
            params={"dry_run": "true"},
            reporter_method="sessions.validate",
        )
        return DryRunResult(
            valid=data["valid"],
            warnings=data.get("warnings", []),
        )


class _Webhooks:
    def __init__(self, client: Optional["VonPayCheckout"] = None) -> None:
        # client may be None when verify_signature is invoked statically — that
        # path doesn't report errors, so the reference is only needed by the
        # construct_event helpers.
        self._client = client

    @staticmethod
    def verify_signature(
        payload: Union[str, bytes], signature: str, secret: str
    ) -> bool:
        """Verify that a webhook payload was signed by Von Payments.

        Args:
            payload: Raw request body — bytes (httpx / Flask / FastAPI default) or str.
            signature: Value of the X-VonPay-Signature header.
            secret: Your merchant API key (vp_sk_*), used as the HMAC secret.
        """
        if not _HEX_64.match(signature):
            return False
        payload_bytes = payload if isinstance(payload, (bytes, bytearray)) else payload.encode()
        expected = hmac.new(
            secret.encode(), payload_bytes, hashlib.sha256
        ).digest()
        # _HEX_64 already enforces lowercase; compare raw bytes to match Node's
        # timingSafeEqual(Buffer.from(sig, "hex"), ...) and avoid any
        # string-allocation ambiguity around compare_digest.
        return hmac.compare_digest(bytes.fromhex(signature), expected)

    def construct_event(
        self, payload: Union[str, bytes], signature: str, secret: str, timestamp: str
    ) -> WebhookEvent:
        """Verify signature and timestamp, then parse the webhook payload.

        Args:
            payload: Raw request body — bytes (httpx / Flask / FastAPI default) or str.
            signature: Value of the X-VonPay-Signature header.
            secret: Your merchant API key (vp_sk_*), used as the HMAC secret.
            timestamp: Value of the X-VonPay-Timestamp header (ISO 8601).

        Raises:
            VonPayError: If signature or timestamp verification fails.
        """
        try:
            event_time = datetime.fromisoformat(
                timestamp.replace("Z", "+00:00")
            ).timestamp()
        except ValueError:
            event_time = 0.0

        now = time.time()
        if abs(now - event_time) > _WEBHOOK_TIMESTAMP_TOLERANCE:
            err = VonPayError(
                status=401,
                error="Webhook timestamp outside tolerance (±5 minutes)",
                code="webhook_invalid_signature",
                fix="Ensure server clock is synchronized and process webhooks promptly",
                docs="https://docs.vonpay.com/reference/webhooks#signature-verification",
            )
            if self._client is not None:
                self._client._report_error(
                    err, method="webhooks.construct_event", status=401, code=err.code
                )
            raise err

        if not _Webhooks.verify_signature(payload, signature, secret):
            err = VonPayError(
                status=401,
                error="Webhook signature verification failed",
                code="webhook_invalid_signature",
                fix="Ensure you are using your merchant API key (vp_sk_*) as the secret",
                docs="https://docs.vonpay.com/reference/webhooks#signature-verification",
            )
            if self._client is not None:
                self._client._report_error(
                    err, method="webhooks.construct_event", status=401, code=err.code
                )
            raise err

        data = json.loads(payload)
        snake = _to_snake_keys(data)
        return WebhookEvent(
            event=snake["event"],
            session_id=snake["session_id"],
            merchant_id=snake["merchant_id"],
            amount=snake["amount"],
            currency=snake["currency"],
            status=snake["status"],
            timestamp=snake["timestamp"],
            transaction_id=snake.get("transaction_id"),
            error=snake.get("error"),
            failure_code=snake.get("failure_code"),
            refund_id=snake.get("refund_id"),
            metadata=snake.get("metadata"),
        )

    def construct_event_v2(
        self, payload: Union[str, bytes], signature_header: str, secret: str
    ) -> WebhookEvent:
        """Verify and parse a webhook using the v2 signature format that binds
        the timestamp into the HMAC payload (Stripe-strict).

        The X-VonPay-Signature header must have the form::

            t=<unix-seconds>,v2=<hex-sha256>

        where v2 = HMAC(secret, f"{t}.{body}"). This prevents replay of a body
        with a new timestamp — v1 verifies the two independently, which is
        safe in practice but not Stripe-strict.

        Backward compatibility: the server only emits v2 when the merchant has
        opted in via the dashboard. Until then, construct_event_v2 will reject
        v1-only signatures with webhook_invalid_signature. Prefer
        construct_event unless you have explicitly enabled v2 on the merchant.

        Args:
            payload: Raw request body (bytes or str).
            signature_header: Full value of X-VonPay-Signature (e.g. "t=1714521600,v2=abc...").
            secret: Your merchant API key (vp_sk_*), used as the HMAC secret.

        Raises:
            VonPayError: If the header is malformed, timestamp is outside
                tolerance, or HMAC verification fails.
        """
        parsed = _parse_v2_signature_header(signature_header)
        if parsed is None:
            err = VonPayError(
                status=401,
                error="Webhook v2 signature header malformed — expected 't=<sec>,v2=<hex>'",
                code="webhook_invalid_signature",
                fix="Ensure the server is emitting v2 signatures and the X-VonPay-Signature header is forwarded intact",
                docs="https://docs.vonpay.com/reference/webhooks#signature-verification",
            )
            if self._client is not None:
                self._client._report_error(
                    err, method="webhooks.construct_event_v2", status=401, code=err.code
                )
            raise err
        t = parsed["t"]
        v2 = parsed["v2"]

        now_sec = time.time()
        if abs(now_sec - t) > _WEBHOOK_TIMESTAMP_TOLERANCE:
            err = VonPayError(
                status=401,
                error="Webhook timestamp outside tolerance (±5 minutes)",
                code="webhook_invalid_signature",
                fix="Ensure server clock is synchronized and process webhooks promptly",
                docs="https://docs.vonpay.com/reference/webhooks#signature-verification",
            )
            if self._client is not None:
                self._client._report_error(
                    err, method="webhooks.construct_event_v2", status=401, code=err.code
                )
            raise err

        payload_bytes = (
            payload if isinstance(payload, (bytes, bytearray)) else payload.encode()
        )
        signed = f"{t}.".encode() + bytes(payload_bytes)
        expected = hmac.new(secret.encode(), signed, hashlib.sha256).digest()
        if not hmac.compare_digest(bytes.fromhex(v2), expected):
            err = VonPayError(
                status=401,
                error="Webhook v2 signature verification failed",
                code="webhook_invalid_signature",
                fix="Ensure you are using your merchant API key (vp_sk_*) as the secret",
                docs="https://docs.vonpay.com/reference/webhooks#signature-verification",
            )
            if self._client is not None:
                self._client._report_error(
                    err, method="webhooks.construct_event_v2", status=401, code=err.code
                )
            raise err

        data = json.loads(payload)
        snake = _to_snake_keys(data)
        return WebhookEvent(
            event=snake["event"],
            session_id=snake["session_id"],
            merchant_id=snake["merchant_id"],
            amount=snake["amount"],
            currency=snake["currency"],
            status=snake["status"],
            timestamp=snake["timestamp"],
            transaction_id=snake.get("transaction_id"),
            error=snake.get("error"),
            failure_code=snake.get("failure_code"),
            refund_id=snake.get("refund_id"),
            metadata=snake.get("metadata"),
        )


class VonPayCheckout:
    """Von Payments Checkout SDK client.

    Args:
        api_key: Your merchant API key (vp_sk_test_* or vp_sk_live_*).
        api_version: API version date (default: 2026-04-14).
        base_url: API base URL (default: https://checkout.vonpay.com).
        max_retries: Max retry attempts on 429/5xx (default: 2).
        timeout: Request timeout in seconds (default: 30).
    """

    def __init__(
        self,
        api_key: str,
        *,
        api_version: str = _DEFAULT_API_VERSION,
        base_url: str = _DEFAULT_BASE_URL,
        max_retries: int = _DEFAULT_MAX_RETRIES,
        timeout: float = _DEFAULT_TIMEOUT,
        error_reporter: Optional[ErrorReporter] = None,
    ) -> None:
        if not api_key:
            raise ValueError("API key is required")
        if not any(api_key.startswith(p) for p in _VALID_KEY_PREFIXES):
            raise ValueError(
                f"Invalid API key format. Keys must start with one of: "
                f"{', '.join(_VALID_KEY_PREFIXES)}"
            )

        self._api_key = api_key
        self._api_version = api_version
        self._base_url = base_url.rstrip("/")
        self._max_retries = max_retries
        self._timeout = timeout
        self._error_reporter = error_reporter
        self._client = httpx.Client(timeout=timeout)

        self.sessions = _Sessions(self)
        self.webhooks = _Webhooks(self)

    def _report_error(
        self,
        err: Exception,
        *,
        method: str,
        url: Optional[str] = None,
        status: Optional[int] = None,
        request_id: Optional[str] = None,
        code: Optional[str] = None,
        attempt: Optional[int] = None,
    ) -> None:
        """Invoke the configured error_reporter callback, swallowing any throw
        from the integrator's reporter so an observability bug never breaks an
        SDK call.

        When no reporter is configured, falls back to a structured
        ``logging.warning`` call on the ``vonpay.checkout`` logger so
        integrators get minimum-viable visibility for free. Skipped under
        pytest (``PYTEST_CURRENT_TEST`` env var) and when ``VONPAY_QUIET=1``.
        """
        ctx = ErrorReporterContext(
            method=method,
            sdk_version=_SDK_VERSION,
            url=url,
            status=status,
            request_id=request_id,
            code=code,
            attempt=attempt,
        )
        if self._error_reporter is not None:
            try:
                self._error_reporter(err, ctx)
            except Exception as reporter_err:
                _log.warning(
                    "[vonpay] error_reporter raised; suppressing: %s",
                    reporter_err,
                )
            return

        # Default reporter — structured warning to logging so any aggregator
        # captures it without explicit wiring.
        import os
        if os.environ.get("PYTEST_CURRENT_TEST") or os.environ.get("VONPAY_QUIET") == "1":
            return
        summary: Dict[str, Any] = {
            "method": ctx.method,
            "sdk_version": ctx.sdk_version,
        }
        if ctx.url:
            summary["url"] = ctx.url
        if ctx.status is not None:
            summary["status"] = ctx.status
        if ctx.request_id:
            summary["request_id"] = ctx.request_id
        if ctx.code:
            summary["code"] = ctx.code
        if ctx.attempt is not None:
            summary["attempt"] = ctx.attempt
        if isinstance(err, VonPayError):
            summary["retryable"] = err.retryable
            summary["next_action"] = err.next_action
        _log.warning("[vonpay] %s %s", err, json.dumps(summary))

    def __del__(self) -> None:
        try:
            self._client.close()
        except Exception:
            pass

    def _request(
        self,
        method: str,
        path: str,
        *,
        json_body: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, str]] = None,
        idempotency_key: Optional[str] = None,
        reporter_method: Optional[str] = None,
    ) -> Dict[str, Any]:
        url = f"{self._base_url}{path}"
        headers: Dict[str, str] = {
            "Authorization": f"Bearer {self._api_key}",
            "Von-Pay-Version": self._api_version,
            "User-Agent": f"vonpay-python/{_SDK_VERSION}",
            "Accept": "application/json",
        }
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key

        last_error: Optional[Exception] = None

        for attempt in range(self._max_retries + 1):
            if attempt > 0:
                delay = self._get_retry_delay(attempt, last_error)
                time.sleep(delay)

            try:
                response = self._client.request(
                    method, url, headers=headers, json=json_body, params=params
                )
            except httpx.HTTPError as exc:
                last_error = exc
                if attempt == self._max_retries:
                    self._report_error(
                        exc,
                        method=reporter_method or f"{method} {path}",
                        url=_safe_url(url),
                        attempt=attempt,
                    )
                    raise
                continue

            request_id = response.headers.get("x-request-id", "")
            rate_limit = _parse_rate_limit(response.headers)

            if response.is_success:
                return response.json()  # type: ignore[no-any-return]

            # Parse error
            try:
                error_data = response.json()
            except Exception:
                error_data = {
                    "error": f"HTTP {response.status_code}",
                    "code": "internal_error",
                    "fix": "Check the API status page",
                    "docs": "https://docs.vonpay.com",
                }

            last_error = VonPayError(
                status=response.status_code,
                error=error_data.get("error", "Unknown error"),
                code=error_data.get("code", "internal_error"),
                fix=error_data.get("fix", ""),
                docs=error_data.get("docs", ""),
                request_id=request_id,
                rate_limit=rate_limit,
            )

            if response.status_code not in _RETRYABLE_STATUS_CODES:
                self._report_error(
                    last_error,
                    method=reporter_method or f"{method} {path}",
                    url=_safe_url(url),
                    status=response.status_code,
                    request_id=request_id,
                    code=last_error.code,
                    attempt=attempt,
                )
                raise last_error

            if attempt == self._max_retries:
                self._report_error(
                    last_error,
                    method=reporter_method or f"{method} {path}",
                    url=_safe_url(url),
                    status=response.status_code,
                    request_id=request_id,
                    code=last_error.code,
                    attempt=attempt,
                )
                raise last_error

        raise last_error or Exception("Request failed")

    def _get_retry_delay(
        self, attempt: int, last_error: Optional[Exception]
    ) -> float:
        if isinstance(last_error, VonPayError) and last_error.rate_limit:
            retry_after = last_error.rate_limit.retry_after
            if retry_after is not None:
                return min(retry_after, 60.0)
        base = math.pow(5, attempt - 1)
        jitter = random.random() * base * 0.1
        return base + jitter

    def health(self) -> HealthStatus:
        """Check API health status and latency."""
        start = time.monotonic()
        data = self._request("GET", "/api/health", reporter_method="health")
        latency = (time.monotonic() - start) * 1000
        return HealthStatus(
            status=data.get("status", "ok"),
            latency_ms=round(latency, 1),
            version=data.get("version", ""),
        )

    @staticmethod
    def verify_return_signature(
        params: Dict[str, str],
        secret: str,
        *,
        expected_success_url: Optional[str] = None,
        expected_key_mode: Optional[str] = None,
        max_age_seconds: int = 600,
    ) -> bool:
        """Verify a return URL signature from a checkout redirect.

        Supports both v1 (plain hex HMAC) and v2 ("v2.<payload>.<hmac>")
        signature formats. If params["sig"] starts with "v2.", v2 verification
        runs; otherwise v1 is used.

        v1 signs: sessionId.status.amount.currency.transactionId (joined with .)

        v2 additionally binds successUrl, keyMode, and issuedAt into the
        signature. When verifying v2, callers must supply expected_success_url
        and expected_key_mode so the verifier can assert those fields; v2
        also enforces that iat is within max_age_seconds (default 600).

        Args:
            params: URL query params (session, status, amount, currency,
                transaction_id, sig).
            secret: Your session signing secret, NOT your API key.
            expected_success_url: v2 only. The success URL the merchant
                configured when creating the session. Required for v2.
            expected_key_mode: v2 only. "test" or "live". Required for v2.
            max_age_seconds: v2 only. Reject sigs older than this. Default 600.
        """
        sig = params.get("sig", "")
        session = params.get("session", "")
        status = params.get("status", "")
        amount = params.get("amount", "")
        currency = params.get("currency", "")
        transaction_id = params.get("transaction_id", "")

        if not sig or not session or not status or not amount or not currency:
            return False

        if sig.startswith("v2."):
            return VonPayCheckout._verify_return_signature_v2(
                sig,
                session,
                status,
                amount,
                currency,
                transaction_id,
                secret,
                expected_success_url,
                expected_key_mode,
                max_age_seconds,
            )

        if not _HEX_64.match(sig):
            return False

        data = ".".join([session, status, amount, currency, transaction_id])
        expected = hmac.new(
            secret.encode(), data.encode(), hashlib.sha256
        ).digest()
        return hmac.compare_digest(bytes.fromhex(sig), expected)

    @staticmethod
    def _verify_return_signature_v2(
        sig: str,
        session: str,
        status: str,
        amount: str,
        currency: str,
        transaction_id: str,
        secret: str,
        expected_success_url: Optional[str],
        expected_key_mode: Optional[str],
        max_age_seconds: int,
    ) -> bool:
        parts = sig.split(".")
        if len(parts) != 3 or parts[0] != "v2":
            return False
        payload_b64, hex_hmac = parts[1], parts[2]
        if not _HEX_64.match(hex_hmac):
            return False

        # HMAC is over "v2.<payload_b64>" — same string the signer computed
        signed_input = f"v2.{payload_b64}"
        expected_hmac = hmac.new(
            secret.encode(), signed_input.encode(), hashlib.sha256
        ).digest()
        if not hmac.compare_digest(bytes.fromhex(hex_hmac), expected_hmac):
            return False

        # Decode base64url-encoded JSON payload
        try:
            padded = payload_b64 + "=" * (-len(payload_b64) % 4)
            payload_json = base64.urlsafe_b64decode(padded.encode()).decode("utf-8")
            payload = json.loads(payload_json)
        except (ValueError, json.JSONDecodeError):
            return False

        # Field-by-field cross-check against URL query params
        if payload.get("sid") != session:
            return False
        if payload.get("status") != status:
            return False
        if str(payload.get("amount")) != amount:
            return False
        if payload.get("currency") != currency:
            return False
        if str(payload.get("transactionId") or "") != (transaction_id or ""):
            return False

        # successUrl: required for v2, callers must pass expected
        if expected_success_url is None:
            return False
        if payload.get("successUrl") != _normalise_success_url(expected_success_url):
            return False

        # keyMode: required for v2, callers must pass expected
        if expected_key_mode is None:
            return False
        if payload.get("keyMode") != expected_key_mode:
            return False

        # iat freshness
        iat = payload.get("iat")
        if not isinstance(iat, (int, float)):
            return False
        if time.time() - iat > max_age_seconds:
            return False
        if iat > time.time() + 60:  # sig from the future = clock skew > tolerance
            return False

        return True


def _normalise_success_url(raw: str) -> str:
    """Canonicalise a success URL the same way the checkout signer does.

    Rules: origin + path (trailing slash stripped unless root) + sorted query
    params. Fragment dropped. Must match src/lib/session-tokens.ts
    `normaliseSuccessUrl` byte-for-byte.
    """
    u = urlparse(raw)
    path = u.path
    if path.endswith("/") and path != "/":
        path = path.rstrip("/")

    # Sort query params alphabetically, preserve all values
    if u.query:
        pairs = [tuple(p.split("=", 1)) if "=" in p else (p, "") for p in u.query.split("&")]
        pairs.sort(key=lambda kv: kv[0])
        qs = urlencode(pairs)
    else:
        qs = ""

    origin = f"{u.scheme}://{u.netloc}"
    return f"{origin}{path}{'?' + qs if qs else ''}"
