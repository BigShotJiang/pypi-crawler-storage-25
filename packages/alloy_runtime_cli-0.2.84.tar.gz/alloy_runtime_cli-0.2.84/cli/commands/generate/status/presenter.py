"""Presenter for async generation status command output."""

from typing import cast

from cli.infrastructure.formatting.fields import (
    format_cost,
    format_datetime,
    format_duration_ms,
    format_optional,
    format_tokens,
    format_uuid,
)
from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.entity_renderer import FieldConfig
from alloy_runtime_types.dtos.generation import AsyncGenerationStatusResponse


def present_generation_status(response: AsyncGenerationStatusResponse) -> None:
    """Present async generation status details."""
    output = OutputService.get()
    fields = [
        FieldConfig(
            "execution_id", "Execution ID", lambda v: format_uuid(v, short=False)
        ),
        FieldConfig("status", "Status"),
        FieldConfig("queued_at", "Queued At", format_datetime),
    ]
    if response.status == "pending":
        fields.append(
            FieldConfig(
                "pending_for_ms",
                "Pending For",
                lambda value: (
                    format_duration_ms(value) if value is not None else cast(str, None)
                ),
            )
        )
    fields.extend(
        [
            FieldConfig("started_at", "Started At", format_datetime),
            FieldConfig("completed_at", "Completed At", format_datetime),
            FieldConfig(
                "total_duration_ms",
                "Duration",
                lambda value: (
                    format_duration_ms(value) if value is not None else cast(str, None)
                ),
            ),
            FieldConfig(
                "assistant_message_id", "Assistant Message ID", format_optional
            ),
            FieldConfig("chat_session_id", "Session ID", format_optional),
            FieldConfig(
                "primary_content_part_id",
                "Primary Content Part ID",
                format_optional,
            ),
            FieldConfig("output_text", "Output"),
            FieldConfig("output_incomplete", "Output Incomplete"),
            FieldConfig(
                "usage",
                "Input Tokens",
                lambda usage: (
                    format_tokens(usage.input_tokens) if usage else cast(str, None)
                ),
            ),
            FieldConfig(
                "usage",
                "Output Tokens",
                lambda usage: (
                    format_tokens(usage.output_tokens) if usage else cast(str, None)
                ),
            ),
            FieldConfig(
                "usage",
                "Reasoning Tokens",
                lambda usage: (
                    format_tokens(usage.reasoning_tokens)
                    if usage and usage.reasoning_tokens is not None
                    else cast(str, None)
                ),
            ),
            FieldConfig(
                "cost",
                "Cost",
                lambda cost: (
                    format_cost(cost.total_cost_usd) if cost else cast(str, None)
                ),
            ),
            FieldConfig("provider_key", "Provider", format_optional),
            FieldConfig("provider_model_name", "Model", format_optional),
            FieldConfig("error_message", "Error", format_optional),
            FieldConfig("error_type", "Error Type", format_optional),
            FieldConfig("external_id", "External ID", format_optional),
        ]
    )
    output.entity(
        response,
        "Generation Status",
        fields,
        raw_payload=response,
    )
