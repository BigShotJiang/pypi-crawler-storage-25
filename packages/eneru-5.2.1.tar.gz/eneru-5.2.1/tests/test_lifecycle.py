"""Tests for the v5.2 lifecycle classifier (Slice 3).

Covers the marker-file CRUD helpers and the pure
:func:`classify_startup` function across every branch:
- upgrade marker → 📦 Upgraded
- pip-path upgrade (last_seen vs current) → 📦 Upgraded
- shutdown marker reason=sequence_complete → 📊 Recovered
- shutdown marker reason=fatal → 🚀 Restarted (fatal)
- shutdown marker reason=signal + recent downtime → 🔄 Restarted
- shutdown marker reason=signal + old downtime → 🚀 Started (last seen)
- no marker, last_seen present → 🚀 Started (after crash)
- no marker, no last_seen → 🚀 Started (first install)
"""

import json
import time

import pytest

from eneru.lifecycle import (
    EVENT_TYPE_DAEMON_AFTER_CRASH,
    EVENT_TYPE_DAEMON_RECOVERED,
    EVENT_TYPE_DAEMON_RESTARTED,
    EVENT_TYPE_DAEMON_RESTARTED_AFTER_FATAL,
    EVENT_TYPE_DAEMON_START,
    EVENT_TYPE_DAEMON_UPGRADED,
    REASON_FATAL,
    REASON_SEQUENCE_COMPLETE,
    REASON_SIGNAL,
    RESTART_DOWNTIME_THRESHOLD_SECS,
    SHUTDOWN_MARKER_NAME,
    UPGRADE_MARKER_NAME,
    classify_event_type,
    classify_startup,
    coalesce_recovered_with_prev_shutdown,
    delete_shutdown_marker,
    delete_upgrade_marker,
    read_shutdown_marker,
    read_upgrade_marker,
    write_shutdown_marker,
)
from eneru.stats import StatsStore


# ==============================================================================
# Marker file CRUD
# ==============================================================================

class TestShutdownMarker:

    @pytest.mark.unit
    def test_write_then_read_round_trip(self, tmp_path):
        write_shutdown_marker(
            tmp_path, version="5.2.0", reason=REASON_SIGNAL,
            shutdown_at=1700000000,
        )
        marker = read_shutdown_marker(tmp_path)
        assert marker == {
            "shutdown_at": 1700000000,
            "version": "5.2.0",
            "reason": "signal",
        }

    @pytest.mark.unit
    def test_read_returns_none_when_absent(self, tmp_path):
        assert read_shutdown_marker(tmp_path) is None

    @pytest.mark.unit
    def test_read_returns_none_on_invalid_json(self, tmp_path):
        (tmp_path / SHUTDOWN_MARKER_NAME).write_text("{not valid json")
        assert read_shutdown_marker(tmp_path) is None

    @pytest.mark.unit
    def test_delete_idempotent_when_absent(self, tmp_path):
        # Must not raise even when the marker isn't there.
        delete_shutdown_marker(tmp_path)
        delete_shutdown_marker(tmp_path)

    @pytest.mark.unit
    def test_delete_removes_existing_marker(self, tmp_path):
        write_shutdown_marker(tmp_path, version="5.2.0")
        assert (tmp_path / SHUTDOWN_MARKER_NAME).exists()
        delete_shutdown_marker(tmp_path)
        assert not (tmp_path / SHUTDOWN_MARKER_NAME).exists()

    @pytest.mark.unit
    def test_write_creates_directory_if_missing(self, tmp_path):
        target = tmp_path / "nested" / "stats"
        write_shutdown_marker(target, version="5.2.0")
        assert (target / SHUTDOWN_MARKER_NAME).exists()

    @pytest.mark.unit
    def test_write_uses_now_when_shutdown_at_omitted(self, tmp_path):
        before = int(time.time())
        write_shutdown_marker(tmp_path, version="5.2.0")
        after = int(time.time())
        marker = read_shutdown_marker(tmp_path)
        assert before <= marker["shutdown_at"] <= after


class TestMarkerIOErrorPaths:
    """v5.2.1 coverage gaps: the marker-file helpers swallow OSError
    so a read-only filesystem or permission issue degrades to "no
    marker found" rather than crashing the daemon."""

    @pytest.mark.unit
    def test_write_shutdown_marker_swallows_oserror(self, tmp_path, monkeypatch):
        """A failed mkdir / write_text doesn't raise — the next start
        just classifies as 'after crash' instead of having the marker
        context. Best-effort by design."""
        from pathlib import Path

        def fail_mkdir(*a, **kw):
            raise PermissionError("read-only filesystem")
        monkeypatch.setattr(Path, "mkdir", fail_mkdir)
        # Must not raise.
        write_shutdown_marker(tmp_path, version="5.2.0")

    @pytest.mark.unit
    def test_read_shutdown_marker_swallows_oserror(self, tmp_path, monkeypatch):
        """A read failure (corrupted disk, permissions) returns None
        rather than raising into the startup path."""
        from pathlib import Path
        # Pre-create the marker so .exists() returns True, then make
        # the read fail.
        write_shutdown_marker(tmp_path, version="5.2.0")
        original_read = Path.read_text

        def fail_read(self, *a, **kw):
            if self.name == SHUTDOWN_MARKER_NAME:
                raise OSError("disk read error")
            return original_read(self, *a, **kw)
        monkeypatch.setattr(Path, "read_text", fail_read)
        assert read_shutdown_marker(tmp_path) is None

    @pytest.mark.unit
    def test_delete_marker_swallows_oserror(self, tmp_path, monkeypatch):
        """delete_*_marker must be idempotent AND survive permission
        errors so a misconfigured stats_dir doesn't crash startup."""
        from pathlib import Path
        write_shutdown_marker(tmp_path, version="5.2.0")

        def fail_unlink(self, *a, **kw):
            raise OSError("permission denied")
        monkeypatch.setattr(Path, "unlink", fail_unlink)
        # Must not raise.
        delete_shutdown_marker(tmp_path)
        delete_upgrade_marker(tmp_path)


class TestUpgradeMarker:

    @pytest.mark.unit
    def test_read_returns_dict_when_present(self, tmp_path):
        (tmp_path / UPGRADE_MARKER_NAME).write_text(
            json.dumps({"old_version": "5.1.2", "new_version": "5.2.0"})
        )
        assert read_upgrade_marker(tmp_path) == {
            "old_version": "5.1.2", "new_version": "5.2.0",
        }

    @pytest.mark.unit
    def test_read_returns_none_when_absent(self, tmp_path):
        assert read_upgrade_marker(tmp_path) is None

    @pytest.mark.unit
    def test_read_returns_none_on_invalid_json(self, tmp_path):
        (tmp_path / UPGRADE_MARKER_NAME).write_text("garbage")
        assert read_upgrade_marker(tmp_path) is None

    @pytest.mark.unit
    def test_delete_idempotent(self, tmp_path):
        delete_upgrade_marker(tmp_path)


# ==============================================================================
# classify_startup — each branch
# ==============================================================================

class TestClassifyStartup:

    @pytest.mark.unit
    def test_upgrade_marker_takes_priority(self):
        body, ntype = classify_startup(
            current_version="5.2.0",
            shutdown_marker={"shutdown_at": 1, "version": "5.1.2",
                             "reason": "signal"},
            upgrade_marker={"old_version": "5.1.2",
                            "new_version": "5.2.0"},
            last_seen_version="5.1.2",
            now_ts=100,
        )
        assert "📦" in body and "Upgraded" in body
        assert "5.1.2" in body and "5.2.0" in body
        assert ntype == "success"

    @pytest.mark.unit
    def test_upgrade_marker_falls_back_to_current_when_new_version_missing(self):
        body, _ = classify_startup(
            current_version="5.2.0",
            shutdown_marker=None,
            upgrade_marker={"old_version": "5.1.2"},  # no new_version
            last_seen_version=None,
            now_ts=100,
        )
        assert "5.1.2" in body and "5.2.0" in body

    @pytest.mark.unit
    def test_pip_path_upgrade_via_last_seen_version_diff(self):
        """No on-disk markers but last_seen_version differs from
        current_version (pip user upgraded between runs)."""
        body, ntype = classify_startup(
            current_version="5.2.0",
            shutdown_marker=None,
            upgrade_marker=None,
            last_seen_version="5.1.2",
            now_ts=100,
        )
        assert "📦" in body and "Upgraded" in body
        assert "5.1.2" in body and "5.2.0" in body
        assert ntype == "success"

    @pytest.mark.unit
    def test_shutdown_sequence_complete_emits_recovered(self):
        body, ntype = classify_startup(
            current_version="5.2.0",
            shutdown_marker={"shutdown_at": 1000,
                             "version": "5.2.0",
                             "reason": REASON_SEQUENCE_COMPLETE},
            upgrade_marker=None,
            last_seen_version="5.2.0",
            now_ts=23000,  # 22000s downtime
        )
        assert "📊" in body and "Recovered" in body
        assert "power-loss" in body
        assert "5.2.0" in body
        assert ntype == "success"

    @pytest.mark.unit
    def test_shutdown_fatal_emits_restarted_after_fatal(self):
        # Same version on both sides — otherwise the pip-path upgrade
        # branch wins (covered separately in
        # test_pip_upgrade_during_shutdown_marker_combines_both).
        body, ntype = classify_startup(
            current_version="5.2.0",
            shutdown_marker={"shutdown_at": 100,
                             "version": "5.2.0",
                             "reason": REASON_FATAL},
            upgrade_marker=None,
            last_seen_version="5.2.0",
            now_ts=200,
        )
        assert "🚀" in body and "Restarted" in body
        assert "fatally" in body
        assert "5.2.0" in body
        assert ntype == "warning"

    @pytest.mark.unit
    def test_shutdown_signal_recent_downtime_emits_restarted(self):
        body, ntype = classify_startup(
            current_version="5.2.0",
            shutdown_marker={"shutdown_at": 100,
                             "version": "5.2.0",
                             "reason": REASON_SIGNAL},
            upgrade_marker=None,
            last_seen_version="5.2.0",
            now_ts=100 + RESTART_DOWNTIME_THRESHOLD_SECS - 1,
        )
        assert "🔄" in body and "Restarted" in body
        assert ntype == "info"

    @pytest.mark.unit
    def test_shutdown_signal_old_downtime_emits_started_with_last_seen(self):
        body, ntype = classify_startup(
            current_version="5.2.0",
            shutdown_marker={"shutdown_at": 100,
                             "version": "5.2.0",
                             "reason": REASON_SIGNAL},
            upgrade_marker=None,
            last_seen_version="5.2.0",
            now_ts=100 + RESTART_DOWNTIME_THRESHOLD_SECS + 60,
        )
        assert "🚀" in body and "Started" in body and "last seen" in body
        assert "🔄" not in body
        assert ntype == "info"

    @pytest.mark.unit
    def test_no_marker_with_last_seen_emits_after_crash(self):
        body, ntype = classify_startup(
            current_version="5.2.0",
            shutdown_marker=None,
            upgrade_marker=None,
            last_seen_version="5.2.0",
            now_ts=100,
        )
        assert "🚀" in body and "after crash" in body
        assert ntype == "warning"

    @pytest.mark.unit
    def test_no_marker_no_last_seen_emits_first_start(self):
        body, ntype = classify_startup(
            current_version="5.2.0",
            shutdown_marker=None,
            upgrade_marker=None,
            last_seen_version=None,
            now_ts=100,
        )
        assert "🚀" in body and "Started" in body
        assert "after crash" not in body
        assert "last seen" not in body
        assert ntype == "info"

    @pytest.mark.unit
    def test_pip_upgrade_during_shutdown_marker_combines_both(self):
        """Edge case: pip user upgraded mid-cycle. Both shutdown marker
        AND a different last_seen_version are present. Should explain
        both via the upgrade phrasing, since the version change is the
        bigger story."""
        body, ntype = classify_startup(
            current_version="5.2.0",
            shutdown_marker={"shutdown_at": 100,
                             "version": "5.1.2",
                             "reason": REASON_SIGNAL},
            upgrade_marker=None,
            last_seen_version="5.1.2",
            now_ts=200,
        )
        assert "📦" in body and "Upgraded" in body
        assert "5.1.2" in body and "5.2.0" in body
        assert ntype == "success"


# ==============================================================================
# v5.2.1: defensive old-version fallback chain in classify_startup
# ==============================================================================

class TestUpgradeOldVersionFallback:
    """The RPM postinstall path used to land with old_version='unknown'
    (RPM passes nothing in $2 and the v5.2.0 default was the literal
    string 'unknown'). v5.2.1 fixes the source via preinstall.sh and
    adds a defensive fallback chain in classify_startup so a marker
    that still arrives with 'unknown'/'?'/empty doesn't render as
    'vunknown' on screen."""

    @pytest.mark.unit
    def test_unknown_old_version_falls_back_to_shutdown_marker(self):
        """Marker says 'unknown'; shutdown_marker.version is the next
        most authoritative source (graceful exit always populates it)."""
        body, _ = classify_startup(
            current_version="5.2.1",
            shutdown_marker={"shutdown_at": 1, "version": "5.2.0",
                             "reason": "signal"},
            upgrade_marker={"old_version": "unknown",
                            "new_version": "5.2.1"},
            last_seen_version="5.1.2",
            now_ts=100,
        )
        assert "vunknown" not in body
        assert "v5.2.0 → v5.2.1" in body

    @pytest.mark.unit
    def test_question_mark_old_version_falls_back_to_shutdown_marker(self):
        body, _ = classify_startup(
            current_version="5.2.1",
            shutdown_marker={"shutdown_at": 1, "version": "5.2.0",
                             "reason": "signal"},
            upgrade_marker={"old_version": "?", "new_version": "5.2.1"},
            last_seen_version=None,
            now_ts=100,
        )
        assert "v?" not in body
        assert "v5.2.0" in body

    @pytest.mark.unit
    def test_empty_old_version_falls_back_to_shutdown_marker(self):
        body, _ = classify_startup(
            current_version="5.2.1",
            shutdown_marker={"shutdown_at": 1, "version": "5.2.0",
                             "reason": "signal"},
            upgrade_marker={"old_version": "", "new_version": "5.2.1"},
            last_seen_version=None,
            now_ts=100,
        )
        assert "v5.2.0" in body

    @pytest.mark.unit
    def test_falls_back_to_last_seen_when_no_shutdown_marker(self):
        """No shutdown_marker (e.g., upgrade landed before the daemon
        could write it on a prior run); meta.last_seen_version is the
        last resort before the literal '?'."""
        body, _ = classify_startup(
            current_version="5.2.1",
            shutdown_marker=None,
            upgrade_marker={"old_version": "unknown",
                            "new_version": "5.2.1"},
            last_seen_version="5.1.2",
            now_ts=100,
        )
        assert "vunknown" not in body
        assert "v5.1.2 → v5.2.1" in body

    @pytest.mark.unit
    def test_renders_question_mark_only_when_every_source_is_missing(self):
        """The original behaviour for the truly-no-info case. Should be
        very rare in practice — preinstall + shutdown marker + stats DB
        all absent means a fresh-on-fresh package install with no daemon
        run in between, which doesn't trigger the upgrade branch
        anyway. Belt-and-suspenders."""
        body, _ = classify_startup(
            current_version="5.2.1",
            shutdown_marker=None,
            upgrade_marker={"old_version": "unknown"},
            last_seen_version=None,
            now_ts=100,
        )
        assert "v? → v5.2.1" in body

    @pytest.mark.unit
    def test_explicit_old_version_wins_over_shutdown_marker(self):
        """Sanity check: when preinstall succeeded and the marker has a
        real old_version, that's authoritative — don't override it with
        a possibly-stale shutdown_marker.version."""
        body, _ = classify_startup(
            current_version="5.2.1",
            shutdown_marker={"shutdown_at": 1, "version": "5.0.0",
                             "reason": "signal"},
            upgrade_marker={"old_version": "5.2.0",
                            "new_version": "5.2.1"},
            last_seen_version="5.1.2",
            now_ts=100,
        )
        assert "v5.2.0 → v5.2.1" in body
        assert "v5.0.0" not in body  # shutdown marker NOT used

    @pytest.mark.unit
    def test_unknown_case_insensitive(self):
        body, _ = classify_startup(
            current_version="5.2.1",
            shutdown_marker={"shutdown_at": 1, "version": "5.2.0",
                             "reason": "signal"},
            upgrade_marker={"old_version": "UNKNOWN",
                            "new_version": "5.2.1"},
            last_seen_version=None,
            now_ts=100,
        )
        assert "vUNKNOWN" not in body
        assert "v5.2.0" in body


# ==============================================================================
# Slice 4: coalesce Recovered with previous shutdown headline
# ==============================================================================

class TestClassifyEventType:
    """Mirrors TestClassifyStartup; verifies that the events-table tag
    matches the priority order classify_startup uses for the user-
    facing notification body. New event_type strings here do NOT need
    a schema bump (events.event_type is TEXT)."""

    @pytest.mark.unit
    def test_upgrade_marker_emits_upgraded(self):
        assert classify_event_type(
            current_version="5.2.0",
            shutdown_marker={"shutdown_at": 1, "version": "5.1.2",
                             "reason": REASON_SIGNAL},
            upgrade_marker={"old_version": "5.1.2"},
            last_seen_version="5.1.2",
            now_ts=100,
        ) == EVENT_TYPE_DAEMON_UPGRADED

    @pytest.mark.unit
    def test_pip_path_upgrade_emits_upgraded(self):
        assert classify_event_type(
            current_version="5.2.0",
            shutdown_marker=None,
            upgrade_marker=None,
            last_seen_version="5.1.2",
            now_ts=100,
        ) == EVENT_TYPE_DAEMON_UPGRADED

    @pytest.mark.unit
    def test_sequence_complete_emits_recovered(self):
        assert classify_event_type(
            current_version="5.2.0",
            shutdown_marker={"shutdown_at": 1000, "version": "5.2.0",
                             "reason": REASON_SEQUENCE_COMPLETE},
            upgrade_marker=None,
            last_seen_version="5.2.0",
            now_ts=23000,
        ) == EVENT_TYPE_DAEMON_RECOVERED

    @pytest.mark.unit
    def test_fatal_emits_restarted_after_fatal(self):
        assert classify_event_type(
            current_version="5.2.0",
            shutdown_marker={"shutdown_at": 100, "version": "5.2.0",
                             "reason": REASON_FATAL},
            upgrade_marker=None,
            last_seen_version="5.2.0",
            now_ts=200,
        ) == EVENT_TYPE_DAEMON_RESTARTED_AFTER_FATAL

    @pytest.mark.unit
    def test_signal_recent_emits_restarted(self):
        assert classify_event_type(
            current_version="5.2.0",
            shutdown_marker={"shutdown_at": 100, "version": "5.2.0",
                             "reason": REASON_SIGNAL},
            upgrade_marker=None,
            last_seen_version="5.2.0",
            now_ts=100 + RESTART_DOWNTIME_THRESHOLD_SECS - 1,
        ) == EVENT_TYPE_DAEMON_RESTARTED

    @pytest.mark.unit
    def test_signal_old_emits_start(self):
        # Old downtime past the restart threshold reads as a fresh
        # start; _start_stats already inserts DAEMON_START so the
        # caller is expected to skip the duplicate.
        assert classify_event_type(
            current_version="5.2.0",
            shutdown_marker={"shutdown_at": 100, "version": "5.2.0",
                             "reason": REASON_SIGNAL},
            upgrade_marker=None,
            last_seen_version="5.2.0",
            now_ts=100 + RESTART_DOWNTIME_THRESHOLD_SECS + 60,
        ) == EVENT_TYPE_DAEMON_START

    @pytest.mark.unit
    def test_no_marker_with_last_seen_emits_after_crash(self):
        assert classify_event_type(
            current_version="5.2.0",
            shutdown_marker=None,
            upgrade_marker=None,
            last_seen_version="5.2.0",
            now_ts=100,
        ) == EVENT_TYPE_DAEMON_AFTER_CRASH

    @pytest.mark.unit
    def test_no_marker_no_last_seen_emits_start(self):
        assert classify_event_type(
            current_version="5.2.0",
            shutdown_marker=None,
            upgrade_marker=None,
            last_seen_version=None,
            now_ts=100,
        ) == EVENT_TYPE_DAEMON_START


class TestCoalesceRecoveredWithPrevShutdown:

    def _store(self, tmp_path):
        s = StatsStore(tmp_path / "n.db")
        s.open()
        return s

    @pytest.mark.unit
    def test_no_pending_returns_none(self, tmp_path):
        s = self._store(tmp_path)
        try:
            assert coalesce_recovered_with_prev_shutdown(
                s, downtime_secs=60, now_ts=2000,
            ) is None
        finally:
            s.close()

    @pytest.mark.unit
    def test_with_headline_includes_reason_and_times(self, tmp_path):
        """When the previous instance's pending shutdown headline carries
        a Reason: line, the coalesced body lifts that reason verbatim."""
        s = self._store(tmp_path)
        try:
            head_id = s.enqueue_notification(
                body=("🚨 **EMERGENCY SHUTDOWN INITIATED!**\n"
                      "Reason: Battery charge 14% below threshold 20%\n"
                      "Executing shutdown tasks."),
                notify_type="failure",
                category="shutdown",
                ts=1000,
            )
            body = coalesce_recovered_with_prev_shutdown(
                s, downtime_secs=3600, now_ts=4600,
            )
            assert body is not None
            assert "📊" in body and "Recovered" in body
            assert "Battery charge 14% below threshold 20%" in body
            # The headline row should now be cancelled with reason coalesced.
            row = s._conn.execute(
                "SELECT status, cancel_reason FROM notifications "
                "WHERE id=?", (head_id,),
            ).fetchone()
            assert row == ("cancelled", "coalesced")
        finally:
            s.close()

    @pytest.mark.unit
    def test_with_summary_only_includes_times(self, tmp_path):
        """When only the shutdown_summary is pending (the headline
        already shipped), coalesce on the summary alone — no Reason
        line available, but still folds into one Recovered message."""
        s = self._store(tmp_path)
        try:
            sum_id = s.enqueue_notification(
                body="✅ **Shutdown Sequence Complete** (took 12s)\nPowering down.",
                notify_type="failure",
                category="shutdown_summary",
                ts=1000,
            )
            body = coalesce_recovered_with_prev_shutdown(
                s, downtime_secs=120, now_ts=1120,
            )
            assert body is not None
            assert "Recovered" in body
            row = s._conn.execute(
                "SELECT status, cancel_reason FROM notifications "
                "WHERE id=?", (sum_id,),
            ).fetchone()
            assert row == ("cancelled", "coalesced")
        finally:
            s.close()

    @pytest.mark.unit
    def test_headline_takes_priority_over_summary_when_both_pending(self, tmp_path):
        """If both the shutdown headline AND its summary are pending,
        the coalesced body is built from the headline (which carries
        the Reason) and the summary is also cancelled."""
        s = self._store(tmp_path)
        try:
            head_id = s.enqueue_notification(
                body=("🚨 **EMERGENCY SHUTDOWN INITIATED!**\n"
                      "Reason: Runtime 30s below threshold 60s\n"
                      "Executing."),
                notify_type="failure", category="shutdown", ts=1000,
            )
            sum_id = s.enqueue_notification(
                body="✅ **Shutdown Sequence Complete** (took 8s)",
                notify_type="failure", category="shutdown_summary", ts=1010,
            )
            body = coalesce_recovered_with_prev_shutdown(
                s, downtime_secs=300, now_ts=1310,
            )
            assert body is not None
            assert "Runtime 30s below threshold 60s" in body
            for nid in (head_id, sum_id):
                row = s._conn.execute(
                    "SELECT status, cancel_reason FROM notifications "
                    "WHERE id=?", (nid,),
                ).fetchone()
                assert row == ("cancelled", "coalesced")
        finally:
            s.close()
