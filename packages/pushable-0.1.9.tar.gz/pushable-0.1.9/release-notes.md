
## Changed

- Switched from poetry to uv
- Updated dependencies
- Switched from CircleCI to GitHub CI workflow & added release workflow

