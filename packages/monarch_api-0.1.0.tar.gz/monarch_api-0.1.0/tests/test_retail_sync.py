from __future__ import annotations

import json

import httpx

from monarch_api import MonarchClient


def test_retail_sync_list_sends_expected_filters_and_rich_query() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Common_RetailSyncsQueryWithTotal"
        assert payload["variables"]["filters"] == {"status": "pending_matches", "vendor": "amazon"}
        assert payload["variables"]["limit"] == 3
        assert "RetailSyncWithOrdersFields" in payload["query"]
        assert "attachments" in payload["query"]
        assert "orders" in payload["query"]
        return httpx.Response(
            200,
            json={
                "data": {
                    "retailSyncsWithTotal": {
                        "totalCount": 1,
                        "results": [
                            {
                                "id": "sync-1",
                                "status": "pending_matches",
                                "vendor": "amazon",
                                "attachments": [],
                                "orders": [],
                            }
                        ],
                    }
                }
            },
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.retail_sync.list(filters={"status": "pending_matches", "vendor": "amazon"}, limit=3)
    assert payload["results"][0]["id"] == "sync-1"


def test_retail_sync_get_returns_rich_receipt_payload() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Common_RetailSyncQuery"
        assert payload["variables"] == {"syncId": "sync-1"}
        assert "vendorOrderId" in payload["query"]
        assert "retailTransactions" in payload["query"]
        return httpx.Response(
            200,
            json={
                "data": {
                    "retailSync": {
                        "id": "sync-1",
                        "status": "pending_matches",
                        "vendor": "user_import",
                        "attachments": [
                            {
                                "id": "attachment-1",
                                "filename": "receipt.jpg",
                                "extension": "jpg",
                                "sizeBytes": 1234,
                                "originalAssetUrl": "https://example.com/receipt.jpg",
                                "thumbnailUrl": "https://example.com/thumb.jpg",
                                "storageId": "storage-1",
                            }
                        ],
                        "orders": [
                            {
                                "id": "order-1",
                                "merchantName": "Cash Wise",
                                "vendorOrderId": "ABC123",
                                "date": "2026-04-12",
                                "grandTotal": "24.51",
                                "retailTransactions": [
                                    {
                                        "id": "retail-txn-1",
                                        "date": "2026-04-12",
                                        "total": "24.51",
                                        "transactionType": "purchase",
                                        "transactionUpdateSkipped": False,
                                        "transaction": {
                                            "id": "txn-1",
                                            "isManual": False,
                                            "hasSplitTransactions": False,
                                            "merchant": {"id": "merchant-1", "name": "Cash Wise", "logoUrl": None},
                                        },
                                    }
                                ],
                                "retailLineItems": [],
                            }
                        ],
                    }
                }
            },
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.retail_sync.get("sync-1")
    assert payload["attachments"][0]["filename"] == "receipt.jpg"
    assert payload["orders"][0]["vendorOrderId"] == "ABC123"
