from __future__ import annotations

import json

import httpx

from monarch_api import MonarchClient


def test_savings_goals_uses_expected_operation() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Common_SavingsGoals"
        return httpx.Response(200, json={"data": {"savingsGoals": [{"id": "goal-1"}]}})

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.goals.savings_goals()
    assert payload[0]["id"] == "goal-1"


def test_savings_goal_account_uses_expected_variables() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Common_SavingsGoalAccount"
        assert payload["variables"] == {"id": "account-1"}
        return httpx.Response(200, json={"data": {"account": {"id": "account-1"}}})

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.goals.savings_goal_account("account-1")
    assert payload["id"] == "account-1"


def test_legacy_goals_migration_uses_expected_operation() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Common_LegacyGoalsMigrationQuery"
        return httpx.Response(200, json={"data": {"migratedToSavingsGoals": True}})

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.goals.legacy_migration()
    assert payload["migratedToSavingsGoals"] is True
