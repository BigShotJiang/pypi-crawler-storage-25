from __future__ import annotations

import json

import httpx

from monarch_api import MonarchClient


def test_accounts_page_uses_expected_operation_and_filters() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Web_GetAccountsPage"
        assert payload["variables"] == {"filters": {"accountSubtypes": ["checking"]}}
        assert "AccountsListFields" in payload["query"]
        return httpx.Response(
            200,
            json={
                "data": {
                    "hasAccounts": True,
                    "accountTypeSummaries": [],
                    "householdPreferences": {"id": "prefs-1"},
                }
            },
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.accounts.page(filters={"accountSubtypes": ["checking"]})
    assert payload["hasAccounts"] is True


def test_accounts_recent_balances_returns_accounts_list() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Web_GetAccountsPageRecentBalance"
        assert payload["variables"] == {"startDate": "2026-03-13"}
        return httpx.Response(
            200,
            json={
                "data": {
                    "accounts": [{"id": "account-1", "recentBalances": [1, 2, 3]}],
                }
            },
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.accounts.recent_balances(start_date="2026-03-13")
    assert payload[0]["id"] == "account-1"


def test_accounts_active_institution_notices_uses_expected_operation() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Common_AllActiveInstitutionNotices"
        assert payload["variables"] == {}
        assert "activeInstitutionNotices" in payload["query"]
        return httpx.Response(
            200,
            json={
                "data": {
                    "activeInstitutionNotices": [{"id": "notice-1", "severity": "critical"}],
                }
            },
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.accounts.active_institution_notices()
    assert payload[0]["id"] == "notice-1"


def test_accounts_aggregate_snapshots_uses_expected_operation() -> None:
    expected_filters = {
        "startDate": "2026-03-13",
        "endDate": None,
        "useAdaptiveGranularity": True,
        "accountFilters": {"accountSubtypes": ["checking", "cash_management"]},
    }

    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Common_GetAggregateSnapshots"
        assert payload["variables"] == {"filters": expected_filters}
        return httpx.Response(
            200,
            json={"data": {"aggregateSnapshots": [{"date": "2026-03-13", "balance": 1000}]}},
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.accounts.aggregate_snapshots(filters=expected_filters)
    assert payload[0]["balance"] == 1000


def test_accounts_display_balance_at_date_uses_expected_operation() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Common_GetDisplayBalanceAtDate"
        assert payload["variables"] == {
            "date": "2026-03-13",
            "filters": {"accountSubtypes": ["checking"]},
        }
        return httpx.Response(
            200,
            json={"data": {"accounts": [{"id": "account-1", "displayBalance": "$100.00"}]}},
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.accounts.display_balance_at_date(date="2026-03-13", filters={"accountSubtypes": ["checking"]})
    assert payload[0]["id"] == "account-1"


def test_accounts_snapshots_by_account_type_uses_expected_operation() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Common_GetSnapshotsByAccountType"
        assert payload["variables"] == {
            "startDate": "2024-04-01",
            "timeframe": "month",
            "filters": {},
        }
        return httpx.Response(
            200,
            json={
                "data": {
                    "snapshotsByAccountType": [{"accountType": "depository", "month": "2026-03-01", "balance": 1}],
                    "accountTypes": [{"name": "depository", "group": "asset"}],
                }
            },
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.accounts.snapshots_by_account_type(start_date="2024-04-01", timeframe="month")
    assert payload["accountTypes"][0]["name"] == "depository"


def test_accounts_institution_settings_uses_expected_operation() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Web_GetInstitutionSettings"
        assert payload["variables"] == {}
        assert "CredentialSettingsCardFields" in payload["query"]
        return httpx.Response(
            200,
            json={
                "data": {
                    "credentials": [{"id": "credential-1"}],
                    "accounts": [{"id": "account-1"}],
                    "subscription": {"hasPremiumEntitlement": True},
                }
            },
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.accounts.institution_settings()
    assert payload["credentials"][0]["id"] == "credential-1"


def test_accounts_latest_force_refresh_operation_uses_expected_query() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Common_LatestForceRefreshOperation"
        assert payload["variables"] == {}
        return httpx.Response(
            200,
            json={"data": {"latestForceRefreshOperation": {"id": "refresh-1", "state": "IN_PROGRESS"}}},
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.accounts.latest_force_refresh_operation()
    assert payload["id"] == "refresh-1"


def test_accounts_force_refresh_operation_uses_expected_query() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Common_ForceRefreshOperationQuery"
        assert payload["variables"] == {"id": "refresh-1"}
        return httpx.Response(
            200,
            json={
                "data": {
                    "forceRefreshOperation": {
                        "id": "refresh-1",
                        "state": "COMPLETED",
                        "completedAccountCount": 1,
                        "totalAccountCount": 1,
                        "accounts": [{"accountId": "account-1", "state": "COMPLETED"}],
                    }
                }
            },
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.accounts.force_refresh_operation("refresh-1")
    assert payload["state"] == "COMPLETED"


def test_accounts_force_refresh_account_status_uses_expected_query() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Common_ForceRefreshAccountQuery"
        assert payload["variables"] == {"accountId": "account-1"}
        return httpx.Response(
            200,
            json={
                "data": {
                    "account": {
                        "id": "account-1",
                        "canBeForceRefreshed": True,
                        "hasSyncOrRecentRefreshRequest": False,
                    }
                }
            },
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.accounts.force_refresh_account_status("account-1")
    assert payload["canBeForceRefreshed"] is True


def test_accounts_filters_uses_expected_query() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Web_AccountFilterQuery"
        assert payload["variables"] == {}
        return httpx.Response(
            200,
            json={
                "data": {
                    "accounts": [{"id": "account-1", "displayName": "Checking"}],
                    "myHousehold": {"id": "house-1", "users": [{"id": "user-1"}]},
                    "householdPreferences": {"accountGroupOrder": ["cash"]},
                }
            },
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.accounts.filters()
    assert payload["myHousehold"]["id"] == "house-1"


def test_accounts_account_types_uses_expected_query() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Web_GetAccountTypes"
        assert payload["variables"] == {}
        return httpx.Response(
            200,
            json={
                "data": {
                    "accountTypes": [{"name": "depository", "display": "Cash", "group": "assets"}],
                }
            },
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.accounts.account_types()
    assert payload[0]["name"] == "depository"


def test_accounts_force_refresh_account_uses_expected_mutation() -> None:
    expected_input = {"accountId": "account-1", "source": "cli"}

    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Common_ForceRefreshAccountMutation"
        assert payload["variables"] == {"input": expected_input}
        return httpx.Response(
            200,
            json={"data": {"forceRefreshAccount": {"success": True, "errors": []}}},
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.accounts.force_refresh_account(expected_input)
    assert payload["success"] is True


def test_accounts_force_refresh_all_uses_expected_mutation() -> None:
    expected_input = {"source": "cli"}

    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Common_ForceRefreshAccountsMutation"
        assert payload["variables"] == {"input": expected_input}
        return httpx.Response(
            200,
            json={
                "data": {
                    "forceRefreshAllAccounts": {
                        "success": True,
                        "forceRefreshOperationId": "refresh-1",
                        "errors": [],
                    }
                }
            },
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.accounts.force_refresh_all(expected_input)
    assert payload["forceRefreshOperationId"] == "refresh-1"


def test_accounts_institutions_uses_external_metadata_endpoint() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.method == "GET"
        assert str(request.url) == (
            "https://iss-api.monarch.com/api/v1/institutions/"
            "?ids=inst-1&ids=inst-2&include_logo=false"
        )
        return httpx.Response(
            200,
            json={
                "type": "institution",
                "items": [{"id": "inst-1"}, {"id": "inst-2"}],
                "count": 2,
            },
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.accounts.institutions(ids=["inst-1", "inst-2"], include_logo=False)
    assert payload["count"] == 2


def test_accounts_institution_uses_external_detail_endpoint() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.method == "GET"
        assert str(request.url) == "https://iss-api.monarch.com/api/v1/institutions/inst-1"
        return httpx.Response(
            200,
            json={
                "type": "institution",
                "id": "inst-1",
                "data": {"id": "inst-1", "name": "Institution One"},
            },
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.accounts.institution("inst-1")
    assert payload["data"]["name"] == "Institution One"
