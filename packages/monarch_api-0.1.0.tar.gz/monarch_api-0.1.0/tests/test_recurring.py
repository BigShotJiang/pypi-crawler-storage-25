from __future__ import annotations

import json

import httpx

from monarch_api import MonarchClient


def test_recurring_streams_uses_expected_variables() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Common_GetRecurringStreams"
        assert payload["variables"] == {"includeLiabilities": True}
        return httpx.Response(200, json={"data": {"recurringTransactionStreams": [{"stream": {"id": "stream-1"}}]}})

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.recurring.streams(include_liabilities=True)
    assert payload[0]["stream"]["id"] == "stream-1"


def test_aggregated_recurring_items_uses_expected_variables() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Common_GetAggregatedRecurringItems"
        assert payload["variables"] == {
            "startDate": "2026-04-01",
            "endDate": "2026-04-30",
            "filters": {"isCompleted": False},
        }
        return httpx.Response(200, json={"data": {"aggregatedRecurringItems": {"groups": []}}})

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.recurring.aggregated_items(
        start_date="2026-04-01",
        end_date="2026-04-30",
        filters={"isCompleted": False},
    )
    assert payload["groups"] == []


def test_dashboard_upcoming_recurring_items_uses_expected_variables() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Web_GetDashboardUpcomingRecurringTransactionItems"
        assert payload["variables"] == {
            "startDate": "2026-04-13",
            "endDate": "2026-04-30",
            "includeLiabilities": True,
            "filters": {"isCompleted": False},
        }
        return httpx.Response(200, json={"data": {"recurringRemainingDue": {"amount": 10}, "recurringTransactionItems": []}})

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.recurring.dashboard_upcoming_items(
        start_date="2026-04-13",
        end_date="2026-04-30",
        include_liabilities=True,
        filters={"isCompleted": False},
    )
    assert payload["recurringRemainingDue"]["amount"] == 10
