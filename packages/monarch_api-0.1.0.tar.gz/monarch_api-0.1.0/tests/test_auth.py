from __future__ import annotations

import json
from pathlib import Path

import httpx

from monarch_api import MonarchClient, MonarchMfaRequiredError


def test_login_sets_session_and_uses_expected_headers() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.method == "POST"
        assert request.url.path == "/auth/login/"
        body = json.loads(request.content.decode("utf-8"))
        assert body["username"] == "user@example.com"
        assert body["totp"] == "123456"
        assert request.headers["Monarch-Client"] == "monarch-core-web-app-rest"
        return httpx.Response(
            200,
            json={
                "token": "token-123",
                "id": "user-1",
                "email": "user@example.com",
                "display_name": "User",
                "household": {"id": "household-1"},
            },
        )

    client = MonarchClient(http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)))
    session = client.auth.login(username="user@example.com", password="secret", totp="123456")
    assert session.token == "token-123"
    assert client.session is not None
    assert client.session.household_id == "household-1"


def test_login_raises_mfa_required() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(403, json={"detail": "MFA is required to proceed.", "error_code": "MFA_REQUIRED"})

    client = MonarchClient(http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)))
    try:
        client.auth.login(username="user@example.com", password="secret")
    except MonarchMfaRequiredError as exc:
        assert exc.status_code == 403
    else:
        raise AssertionError("Expected MonarchMfaRequiredError")


def test_session_round_trip(tmp_path: Path) -> None:
    client = MonarchClient(token="token-123")
    path = tmp_path / "session.json"
    client.auth.save_session(path)
    other = MonarchClient()
    session = other.auth.load_session(path)
    assert session.token == "token-123"
