from __future__ import annotations

import json

import httpx

from monarch_api import MonarchClient


def test_investments_accounts_uses_expected_operation() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Web_GetInvestmentsAccounts"
        assert payload["variables"] == {}
        return httpx.Response(
            200,
            json={"data": {"accounts": [{"id": "acct-1", "displayName": "Brokerage"}]}},
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.investments.accounts()
    assert payload[0]["id"] == "acct-1"


def test_investments_portfolio_uses_expected_variables() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Web_GetPortfolio"
        assert payload["variables"] == {
            "portfolioInput": {"startDate": "2026-03-01", "endDate": "2026-04-01"}
        }
        return httpx.Response(
            200,
            json={"data": {"portfolio": {"performance": {"totalValue": 1234}}}},
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.investments.portfolio(
        portfolio_input={"startDate": "2026-03-01", "endDate": "2026-04-01"}
    )
    assert payload["performance"]["totalValue"] == 1234


def test_investments_security_history_uses_expected_variables() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Web_GetSecuritiesHistoricalPerformance"
        assert payload["variables"] == {
            "input": {
                "securityIds": ["sec-1"],
                "startDate": "2026-03-01",
                "endDate": "2026-04-01",
            }
        }
        return httpx.Response(
            200,
            json={
                "data": {
                    "securityHistoricalPerformance": [
                        {"security": {"id": "sec-1"}, "historicalChart": []}
                    ]
                }
            },
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.investments.securities_historical_performance(
        input_data={
            "securityIds": ["sec-1"],
            "startDate": "2026-03-01",
            "endDate": "2026-04-01",
        }
    )
    assert payload[0]["security"]["id"] == "sec-1"
