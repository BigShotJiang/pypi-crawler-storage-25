from __future__ import annotations

import json

import httpx

from monarch_api import MonarchClient


def test_transactions_list_sends_expected_operation_name() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/graphql"
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Web_GetTransactionsList"
        assert payload["variables"]["limit"] == 10
        assert request.headers["Authorization"] == "Token token-123"
        return httpx.Response(
            200,
            json={
                "data": {
                    "allTransactions": {
                        "totalCount": 1,
                        "totalSelectableCount": 1,
                        "results": [{"id": "txn-1", "amount": 100}],
                    },
                    "transactionRules": [{"id": "rule-1"}],
                }
            },
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.transactions.list(limit=10)
    assert payload["results"][0]["id"] == "txn-1"


def test_transaction_delete_wraps_input_shape() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Common_DeleteTransactionMutation"
        assert payload["variables"] == {"input": {"transactionId": "txn-1"}}
        return httpx.Response(
            200,
            json={"data": {"deleteTransaction": {"deleted": True, "errors": []}}},
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.transactions.delete("txn-1")
    assert payload["deleted"] is True


def test_attachment_upload_info_uses_bundle_derived_mutation() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Common_GetTransactionAttachmentUploadInfo"
        assert payload["variables"] == {"transactionId": "txn-1"}
        return httpx.Response(
            200,
            json={
                "data": {
                    "getTransactionAttachmentUploadInfo": {
                        "info": {
                            "path": "folder/file",
                            "requestParams": {"api_key": "abc"},
                        }
                    }
                }
            },
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.attachments.get_upload_info("txn-1")
    assert payload["info"]["path"] == "folder/file"
