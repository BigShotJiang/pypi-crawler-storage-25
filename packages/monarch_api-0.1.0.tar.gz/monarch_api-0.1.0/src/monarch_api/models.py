from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any
from uuid import uuid4
import json


@dataclass(slots=True)
class MonarchSession:
    token: str
    user_id: str | None = None
    email: str | None = None
    name: str | None = None
    display_name: str | None = None
    household_id: str | None = None
    device_uuid: str = field(default_factory=lambda: str(uuid4()))
    client_platform: str = "web"
    rest_client_name: str = "monarch-core-web-app-rest"
    graphql_client_name: str = "monarch-core-web-app-graphql"
    client_version: str = "v1.0.2086"

    @property
    def authorization_header(self) -> str:
        return f"Token {self.token}"

    @classmethod
    def from_login_response(
        cls,
        payload: dict[str, Any],
        *,
        device_uuid: str | None = None,
        client_version: str = "v1.0.2086",
    ) -> "MonarchSession":
        household = payload.get("household") or {}
        return cls(
            token=payload["token"],
            user_id=payload.get("id"),
            email=payload.get("email"),
            name=payload.get("name"),
            display_name=payload.get("display_name"),
            household_id=household.get("id"),
            device_uuid=device_uuid or str(uuid4()),
            client_version=client_version,
        )

    def to_json(self) -> str:
        return json.dumps(asdict(self), indent=2, sort_keys=True)

    @classmethod
    def from_json(cls, raw: str) -> "MonarchSession":
        return cls(**json.loads(raw))

    def save(self, path: str | Path) -> None:
        Path(path).write_text(self.to_json(), encoding="utf-8")

    @classmethod
    def load(cls, path: str | Path) -> "MonarchSession":
        return cls.from_json(Path(path).read_text(encoding="utf-8"))
