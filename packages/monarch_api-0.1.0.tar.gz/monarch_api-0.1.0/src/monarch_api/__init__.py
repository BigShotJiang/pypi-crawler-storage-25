from importlib.metadata import PackageNotFoundError, version

from .client import MonarchClient
from .exceptions import (
    MonarchAPIError,
    MonarchAuthError,
    MonarchGraphQLError,
    MonarchHTTPError,
    MonarchMfaRequiredError,
)
from .models import MonarchSession

try:
    __version__ = version("monarch-api")
except PackageNotFoundError:  # pragma: no cover - fallback for local source use
    __version__ = "0.0.0"

__all__ = [
    "MonarchAPIError",
    "MonarchAuthError",
    "MonarchClient",
    "MonarchGraphQLError",
    "MonarchHTTPError",
    "MonarchMfaRequiredError",
    "MonarchSession",
    "__version__",
]
