from __future__ import annotations

import httpx

from .api import (
    AccountsAPI,
    AttachmentsAPI,
    GoalsAPI,
    HouseholdAPI,
    InvestmentsAPI,
    MerchantsAPI,
    PlanningAPI,
    RecurringAPI,
    ReportsAPI,
    RetailSyncAPI,
    RulesAPI,
    SettingsAPI,
    SubscriptionAPI,
    TransactionsAPI,
)
from .auth import AuthAPI
from .models import MonarchSession
from .transport import MonarchTransport


class MonarchClient:
    def __init__(
        self,
        *,
        base_url: str = "https://api.monarch.com",
        timeout: float = 30.0,
        session: MonarchSession | None = None,
        token: str | None = None,
        http_client: httpx.Client | None = None,
    ) -> None:
        if token and session:
            raise ValueError("Pass either token or session, not both.")
        if token:
            session = MonarchSession(token=token)

        self._transport = MonarchTransport(
            base_url=base_url,
            timeout=timeout,
            session=session,
            http_client=http_client,
        )
        self.auth = AuthAPI(self._transport)
        self.household = HouseholdAPI(self._transport)
        self.accounts = AccountsAPI(self._transport)
        self.subscription = SubscriptionAPI(self._transport)
        self.settings = SettingsAPI(self._transport)
        self.planning = PlanningAPI(self._transport)
        self.goals = GoalsAPI(self._transport)
        self.recurring = RecurringAPI(self._transport)
        self.investments = InvestmentsAPI(self._transport)
        self.transactions = TransactionsAPI(self._transport)
        self.merchants = MerchantsAPI(self._transport)
        self.attachments = AttachmentsAPI(self._transport)
        self.rules = RulesAPI(self._transport)
        self.reports = ReportsAPI(self._transport)
        self.retail_sync = RetailSyncAPI(self._transport)

    @property
    def session(self) -> MonarchSession | None:
        return self._transport.session

    def close(self) -> None:
        self._transport.close()

    def __enter__(self) -> "MonarchClient":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()
