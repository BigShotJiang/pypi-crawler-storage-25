from __future__ import annotations

from uuid import uuid4

import httpx

from ._types import JSON
from .exceptions import MonarchAuthError, MonarchGraphQLError, MonarchHTTPError, MonarchMfaRequiredError
from .models import MonarchSession


class MonarchTransport:
    def __init__(
        self,
        *,
        base_url: str = "https://api.monarch.com",
        timeout: float = 30.0,
        session: MonarchSession | None = None,
        http_client: httpx.Client | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.session = session
        self._owns_client = http_client is None
        self._client = http_client or httpx.Client(base_url=self.base_url, timeout=timeout)
        self.device_uuid = session.device_uuid if session else str(uuid4())

    def close(self) -> None:
        if self._owns_client:
            self._client.close()

    def set_session(self, session: MonarchSession) -> None:
        self.session = session
        self.device_uuid = session.device_uuid

    def rest_json(self, method: str, path: str, *, json_body: JSON | None = None, authenticated: bool = False) -> JSON:
        response = self._client.request(
            method,
            path,
            json=json_body,
            headers=self._rest_headers(authenticated),
        )
        payload = self._decode_json(response)
        if response.status_code >= 400:
            self._raise_rest_error(response.status_code, payload)
        return payload

    def graphql(self, operation_name: str, query: str, variables: JSON | None = None) -> JSON:
        if not self.session:
            raise MonarchAuthError(401, "GraphQL requests require an authenticated session.")
        response = self._client.post(
            "/graphql",
            json={
                "operationName": operation_name,
                "variables": variables or {},
                "query": query,
            },
            headers=self._graphql_headers(),
        )
        payload = self._decode_json(response)
        if response.status_code >= 400:
            raise MonarchHTTPError(response.status_code, f"GraphQL request failed for {operation_name}.", payload)
        if payload.get("errors"):
            raise MonarchGraphQLError(f"GraphQL errors for {operation_name}.", payload["errors"])
        data = payload.get("data")
        if not isinstance(data, dict):
            raise MonarchGraphQLError(f"GraphQL response for {operation_name} did not include a data object.", payload)
        return data

    def _rest_headers(self, authenticated: bool) -> dict[str, str]:
        session = self.session
        headers = {
            "Accept": "application/json",
            "Client-Platform": session.client_platform if session else "web",
            "Content-Type": "application/json",
            "Device-Uuid": self.device_uuid,
            "Monarch-Client": session.rest_client_name if session else "monarch-core-web-app-rest",
            "Monarch-Client-Version": session.client_version if session else "v1.0.2086",
        }
        if authenticated and session:
            headers["Authorization"] = session.authorization_header
        return headers

    def _graphql_headers(self) -> dict[str, str]:
        session = self.session
        if not session:
            raise MonarchAuthError(401, "GraphQL requests require an authenticated session.")
        return {
            "Accept": "application/json",
            "Authorization": session.authorization_header,
            "Client-Platform": session.client_platform,
            "Content-Type": "application/json",
            "Device-Uuid": self.device_uuid,
            "Monarch-Client": session.graphql_client_name,
            "Monarch-Client-Version": session.client_version,
        }

    @staticmethod
    def _decode_json(response: httpx.Response) -> JSON:
        try:
            payload = response.json()
        except ValueError as exc:
            raise MonarchHTTPError(response.status_code, "Response was not valid JSON.") from exc
        if not isinstance(payload, dict):
            raise MonarchHTTPError(response.status_code, "Response JSON was not an object.", payload)
        return payload

    @staticmethod
    def _raise_rest_error(status_code: int, payload: JSON) -> None:
        message = str(payload.get("detail") or payload.get("message") or "Monarch REST request failed.")
        if payload.get("error_code") == "MFA_REQUIRED":
            raise MonarchMfaRequiredError(status_code, message, payload)
        raise MonarchAuthError(status_code, message, payload)
