from __future__ import annotations

from typing import Any, TypeAlias

JSON: TypeAlias = dict[str, Any]
