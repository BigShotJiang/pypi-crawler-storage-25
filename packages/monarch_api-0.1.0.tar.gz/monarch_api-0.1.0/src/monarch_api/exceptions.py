class MonarchAPIError(Exception):
    """Base exception for client and API failures."""


class MonarchHTTPError(MonarchAPIError):
    def __init__(self, status_code: int, message: str, payload: object | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.payload = payload


class MonarchAuthError(MonarchHTTPError):
    """Raised for auth failures."""


class MonarchMfaRequiredError(MonarchAuthError):
    """Raised when the server requires MFA/TOTP to continue."""


class MonarchGraphQLError(MonarchAPIError):
    def __init__(self, message: str, errors: object | None = None) -> None:
        super().__init__(message)
        self.errors = errors
