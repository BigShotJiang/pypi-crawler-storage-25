from __future__ import annotations

from .._types import JSON
from ..documents import (
    GET_AGGREGATED_RECURRING_ITEMS,
    GET_DASHBOARD_UPCOMING_RECURRING_ITEMS,
    GET_RECURRING_PAUSED_BANNER,
    GET_RECURRING_STREAMS,
)
from ..transport import MonarchTransport


class RecurringAPI:
    def __init__(self, transport: MonarchTransport) -> None:
        self._transport = transport

    def streams(self, *, include_liabilities: bool | None = None) -> list[JSON]:
        data = self._transport.graphql(
            "Common_GetRecurringStreams",
            GET_RECURRING_STREAMS,
            {"includeLiabilities": include_liabilities},
        )
        return data["recurringTransactionStreams"]

    def aggregated_items(self, *, start_date: str, end_date: str, filters: JSON | None = None) -> JSON:
        data = self._transport.graphql(
            "Common_GetAggregatedRecurringItems",
            GET_AGGREGATED_RECURRING_ITEMS,
            {
                "startDate": start_date,
                "endDate": end_date,
                "filters": filters or {},
            },
        )
        return data["aggregatedRecurringItems"]

    def dashboard_upcoming_items(
        self,
        *,
        start_date: str,
        end_date: str,
        include_liabilities: bool | None = None,
        filters: JSON | None = None,
    ) -> JSON:
        return self._transport.graphql(
            "Web_GetDashboardUpcomingRecurringTransactionItems",
            GET_DASHBOARD_UPCOMING_RECURRING_ITEMS,
            {
                "startDate": start_date,
                "endDate": end_date,
                "includeLiabilities": include_liabilities,
                "filters": filters or {},
            },
        )

    def paused_banner(self) -> JSON:
        return self._transport.graphql(
            "Web_RecurringPausedBanner",
            GET_RECURRING_PAUSED_BANNER,
            {},
        )
