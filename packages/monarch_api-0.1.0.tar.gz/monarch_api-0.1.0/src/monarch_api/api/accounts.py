from __future__ import annotations

from urllib.parse import urlencode

from .._types import JSON
from ..documents import (
    FORCE_REFRESH_ACCOUNT,
    FORCE_REFRESH_ALL_ACCOUNTS,
    GET_ACTIVE_INSTITUTION_NOTICES,
    GET_AGGREGATE_SNAPSHOTS,
    GET_ACCOUNT_FILTER_QUERY,
    GET_ACCOUNT_TYPES,
    GET_ACCOUNTS_PAGE,
    GET_ACCOUNTS_PAGE_RECENT_BALANCE,
    GET_ACCOUNTS_SYNCING,
    GET_DISPLAY_BALANCE_AT_DATE,
    GET_FILTERED_ACCOUNTS,
    GET_FORCE_REFRESH_ACCOUNT,
    GET_FORCE_REFRESH_OPERATION,
    GET_HAS_ACCOUNTS,
    GET_INSTITUTION_SETTINGS,
    GET_LATEST_FORCE_REFRESH_OPERATION,
    GET_SNAPSHOTS_BY_ACCOUNT_TYPE,
)
from ..exceptions import MonarchGraphQLError
from ..transport import MonarchTransport

INSTITUTIONS_BASE_URL = "https://iss-api.monarch.com/api/v1/institutions/"


class AccountsAPI:
    def __init__(self, transport: MonarchTransport) -> None:
        self._transport = transport

    def has_accounts(self) -> bool:
        data = self._transport.graphql(
            "Common_GetHasAccounts",
            GET_HAS_ACCOUNTS,
            {},
        )
        return bool(data["hasAccounts"])

    def active_institution_notices(self) -> list[JSON]:
        data = self._transport.graphql(
            "Common_AllActiveInstitutionNotices",
            GET_ACTIVE_INSTITUTION_NOTICES,
            {},
        )
        return data["activeInstitutionNotices"]

    def aggregate_snapshots(self, *, filters: JSON | None = None) -> list[JSON]:
        data = self._transport.graphql(
            "Common_GetAggregateSnapshots",
            GET_AGGREGATE_SNAPSHOTS,
            {"filters": filters or {}},
        )
        return data["aggregateSnapshots"]

    def syncing_status(self) -> JSON:
        return self._transport.graphql(
            "Common_ForceRefreshAccountsQuery",
            GET_ACCOUNTS_SYNCING,
            {},
        )

    def latest_force_refresh_operation(self) -> JSON | None:
        data = self._transport.graphql(
            "Common_LatestForceRefreshOperation",
            GET_LATEST_FORCE_REFRESH_OPERATION,
            {},
        )
        return data.get("latestForceRefreshOperation")

    def force_refresh_operation(self, operation_id: str) -> JSON:
        data = self._transport.graphql(
            "Common_ForceRefreshOperationQuery",
            GET_FORCE_REFRESH_OPERATION,
            {"id": operation_id},
        )
        return data["forceRefreshOperation"]

    def force_refresh_account_status(self, account_id: str) -> JSON:
        data = self._transport.graphql(
            "Common_ForceRefreshAccountQuery",
            GET_FORCE_REFRESH_ACCOUNT,
            {"accountId": account_id},
        )
        return data["account"]

    def display_balance_at_date(self, *, date: str, filters: JSON | None = None) -> list[JSON]:
        data = self._transport.graphql(
            "Common_GetDisplayBalanceAtDate",
            GET_DISPLAY_BALANCE_AT_DATE,
            {"date": date, "filters": filters or {}},
        )
        return data["accounts"]

    def snapshots_by_account_type(self, *, start_date: str, timeframe: str, filters: JSON | None = None) -> JSON:
        return self._transport.graphql(
            "Common_GetSnapshotsByAccountType",
            GET_SNAPSHOTS_BY_ACCOUNT_TYPE,
            {
                "startDate": start_date,
                "timeframe": timeframe,
                "filters": filters or {},
            },
        )

    def page(self, *, filters: JSON | None = None) -> JSON:
        return self._transport.graphql(
            "Web_GetAccountsPage",
            GET_ACCOUNTS_PAGE,
            {"filters": filters or {}},
        )

    def recent_balances(self, *, start_date: str | None = None) -> list[JSON]:
        data = self._transport.graphql(
            "Web_GetAccountsPageRecentBalance",
            GET_ACCOUNTS_PAGE_RECENT_BALANCE,
            {"startDate": start_date},
        )
        return data["accounts"]

    def filtered(self, *, filters: JSON | None = None) -> list[JSON]:
        data = self._transport.graphql(
            "Web_GetFilteredAccounts",
            GET_FILTERED_ACCOUNTS,
            {"filters": filters or {}},
        )
        return data["accounts"]

    def filters(self) -> JSON:
        return self._transport.graphql(
            "Web_AccountFilterQuery",
            GET_ACCOUNT_FILTER_QUERY,
            {},
        )

    def account_types(self) -> list[JSON]:
        data = self._transport.graphql(
            "Web_GetAccountTypes",
            GET_ACCOUNT_TYPES,
            {},
        )
        return data["accountTypes"]

    def institution_settings(self) -> JSON:
        return self._transport.graphql(
            "Web_GetInstitutionSettings",
            GET_INSTITUTION_SETTINGS,
            {},
        )

    def force_refresh_account(self, input_data: JSON) -> JSON:
        return self._payload(
            "forceRefreshAccount",
            self._transport.graphql(
                "Common_ForceRefreshAccountMutation",
                FORCE_REFRESH_ACCOUNT,
                {"input": input_data},
            ),
        )

    def force_refresh_all(self, input_data: JSON | None = None) -> JSON:
        variables: JSON = {}
        if input_data is not None:
            variables["input"] = input_data
        return self._payload(
            "forceRefreshAllAccounts",
            self._transport.graphql(
                "Common_ForceRefreshAccountsMutation",
                FORCE_REFRESH_ALL_ACCOUNTS,
                variables,
            ),
        )

    def institutions(
        self,
        *,
        ids: list[str] | None = None,
        include_logo: bool | None = None,
    ) -> JSON:
        query_items: list[tuple[str, str]] = []
        for institution_id in ids or []:
            query_items.append(("ids", institution_id))
        if include_logo is not None:
            query_items.append(("include_logo", str(include_logo).lower()))
        query = f"?{urlencode(query_items, doseq=True)}" if query_items else ""
        return self._transport.rest_json(
            "GET",
            f"{INSTITUTIONS_BASE_URL}{query}",
            authenticated=False,
        )

    def institution(self, institution_id: str) -> JSON:
        return self._transport.rest_json(
            "GET",
            f"{INSTITUTIONS_BASE_URL}{institution_id}",
            authenticated=False,
        )

    @staticmethod
    def _payload(field_name: str, data: JSON) -> JSON:
        payload = data.get(field_name)
        if not isinstance(payload, dict):
            raise MonarchGraphQLError(f"Expected payload object for {field_name}.", data)
        return payload
