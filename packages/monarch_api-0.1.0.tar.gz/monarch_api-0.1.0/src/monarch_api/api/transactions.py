from __future__ import annotations

from .._types import JSON
from ..documents import (
    CREATE_TRANSACTION,
    DELETE_TRANSACTION,
    GET_CATEGORIES,
    GET_HOUSEHOLD_TRANSACTION_TAGS,
    GET_TRANSACTION_DRAWER,
    GET_TRANSACTIONS_FILTER_QUERY,
    GET_TRANSACTIONS_LIST,
    GET_TRANSACTION_FILTERS_METADATA,
    SET_TRANSACTION_TAGS,
    UPDATE_TRANSACTION,
)
from ..exceptions import MonarchGraphQLError
from ..transport import MonarchTransport


class TransactionsAPI:
    def __init__(self, transport: MonarchTransport) -> None:
        self._transport = transport

    def list(
        self,
        *,
        offset: int | None = None,
        limit: int = 25,
        filters: JSON | None = None,
        order_by: str = "date",
    ) -> JSON:
        data = self._transport.graphql(
            "Web_GetTransactionsList",
            GET_TRANSACTIONS_LIST,
            {
                "offset": offset,
                "limit": limit,
                "filters": filters or {"transactionVisibility": "non_hidden_transactions_only"},
                "orderBy": order_by,
            },
        )
        return {
            "allTransactions": data["allTransactions"],
            "transactionRules": data["transactionRules"],
            "results": data["allTransactions"]["results"],
        }

    def get(self, transaction_id: str, *, redirect_posted: bool = True) -> JSON:
        data = self._transport.graphql(
            "GetTransactionDrawer",
            GET_TRANSACTION_DRAWER,
            {"id": transaction_id, "redirectPosted": redirect_posted},
        )
        return data["getTransaction"]

    def filters(self, *, search: str | None = None, include_ids: list[str] | None = None) -> JSON:
        return self._transport.graphql(
            "Web_TransactionsFilterQuery",
            GET_TRANSACTIONS_FILTER_QUERY,
            {"search": search, "includeIds": include_ids},
        )

    def filters_metadata(self, filters: JSON) -> JSON:
        data = self._transport.graphql(
            "Web_GetTransactionFiltersMetadata",
            GET_TRANSACTION_FILTERS_METADATA,
            {"input": filters},
        )
        return data["transactionFiltersMetadata"]

    def create(self, input_data: JSON) -> JSON:
        return self._require_payload(
            "createTransaction",
            self._transport.graphql(
                "Common_CreateTransactionMutation",
                CREATE_TRANSACTION,
                {"input": input_data},
            ),
        )

    def update(self, input_data: JSON) -> JSON:
        return self._require_payload(
            "updateTransaction",
            self._transport.graphql(
                "Web_TransactionDrawerUpdateTransaction",
                UPDATE_TRANSACTION,
                {"input": input_data},
            ),
        )

    def delete(self, transaction_id: str) -> JSON:
        return self._require_payload(
            "deleteTransaction",
            self._transport.graphql(
                "Common_DeleteTransactionMutation",
                DELETE_TRANSACTION,
                {"input": {"transactionId": transaction_id}},
            ),
        )

    def set_tags(self, transaction_id: str, tag_ids: list[str]) -> JSON:
        return self._require_payload(
            "setTransactionTags",
            self._transport.graphql(
                "Web_SetTransactionTags",
                SET_TRANSACTION_TAGS,
                {"input": {"transactionId": transaction_id, "tagIds": tag_ids}},
            ),
        )

    def tags(
        self,
        *,
        search: str | None = None,
        limit: int | None = None,
        bulk_params: JSON | None = None,
        include_transaction_count: bool = False,
    ) -> list[JSON]:
        data = self._transport.graphql(
            "Common_GetHouseholdTransactionTags",
            GET_HOUSEHOLD_TRANSACTION_TAGS,
            {
                "search": search,
                "limit": limit,
                "bulkParams": bulk_params,
                "includeTransactionCount": include_transaction_count,
            },
        )
        return data["householdTransactionTags"]

    def categories(self, *, include_system_disabled_categories: bool | None = None) -> JSON:
        return self._transport.graphql(
            "Common_GetCategories",
            GET_CATEGORIES,
            {"includeSystemDisabledCategories": include_system_disabled_categories},
        )

    @staticmethod
    def _require_payload(field_name: str, data: JSON) -> JSON:
        payload = data.get(field_name)
        if not isinstance(payload, dict):
            raise MonarchGraphQLError(f"Expected payload object for {field_name}.", data)
        return payload
