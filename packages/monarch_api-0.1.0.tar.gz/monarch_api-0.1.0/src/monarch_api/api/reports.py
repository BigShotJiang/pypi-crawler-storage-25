from __future__ import annotations

from .._types import JSON
from ..documents import (
    GET_CASH_FLOW_DASHBOARD,
    GET_CASH_FLOW_ENTITY_AGGREGATES,
    GET_CASH_FLOW_TIMEFRAME_AGGREGATES,
    GET_REPORTS_DATA,
)
from ..transport import MonarchTransport


class ReportsAPI:
    def __init__(self, transport: MonarchTransport) -> None:
        self._transport = transport

    def cash_flow_dashboard(self, *, filters: JSON | None = None) -> JSON:
        return self._transport.graphql(
            "Common_GetCashFlowDashboard",
            GET_CASH_FLOW_DASHBOARD,
            {"filters": filters or {}},
        )

    def cash_flow_entity_aggregates(self, *, filters: JSON | None = None) -> JSON:
        return self._transport.graphql(
            "Common_GetCashFlowEntityAggregates",
            GET_CASH_FLOW_ENTITY_AGGREGATES,
            {"filters": filters or {}},
        )

    def cash_flow_timeframe_aggregates(self, *, filters: JSON | None = None) -> JSON:
        return self._transport.graphql(
            "Common_GetCashFlowTimeframeAggregates",
            GET_CASH_FLOW_TIMEFRAME_AGGREGATES,
            {"filters": filters or {}},
        )

    def data(
        self,
        *,
        filters: JSON,
        group_by: list[str] | None = None,
        group_by_timeframe: str | None = None,
        sort_by: str | None = None,
        include_category: bool = False,
        include_category_group: bool = False,
        include_merchant: bool = False,
        include_business_entity: bool = False,
        include_budget_variability: bool = False,
        fill_empty_values: bool = True,
    ) -> JSON:
        return self._transport.graphql(
            "Common_GetReportsData",
            GET_REPORTS_DATA,
            {
                "filters": filters,
                "groupBy": group_by,
                "groupByTimeframe": group_by_timeframe,
                "sortBy": sort_by,
                "includeCategory": include_category,
                "includeCategoryGroup": include_category_group,
                "includeMerchant": include_merchant,
                "includeBusinessEntity": include_business_entity,
                "includeBudgetVariability": include_budget_variability,
                "fillEmptyValues": fill_empty_values,
            },
        )
