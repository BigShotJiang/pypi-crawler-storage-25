from __future__ import annotations

from .._types import JSON
from ..documents import (
    GET_GOALS_DASHBOARD_CARD,
    GET_LEGACY_GOALS_MIGRATION,
    GET_SAVINGS_GOAL_ACCOUNT,
    GET_SAVINGS_GOALS,
    GET_SAVINGS_GOALS_WITH_THIS_MONTH_BALANCES,
)
from ..transport import MonarchTransport


class GoalsAPI:
    def __init__(self, transport: MonarchTransport) -> None:
        self._transport = transport

    def savings_goals(self) -> list[JSON]:
        data = self._transport.graphql(
            "Common_SavingsGoals",
            GET_SAVINGS_GOALS,
            {},
        )
        return data["savingsGoals"]

    def savings_goals_with_this_month_balances(self) -> JSON:
        return self._transport.graphql(
            "Common_SavingsGoalsWithThisMonthBalances",
            GET_SAVINGS_GOALS_WITH_THIS_MONTH_BALANCES,
            {},
        )

    def savings_goal_account(self, account_id: str) -> JSON:
        data = self._transport.graphql(
            "Common_SavingsGoalAccount",
            GET_SAVINGS_GOAL_ACCOUNT,
            {"id": account_id},
        )
        return data["account"]

    def dashboard_card(self) -> list[JSON]:
        data = self._transport.graphql(
            "Web_GoalsDashboardCardV2",
            GET_GOALS_DASHBOARD_CARD,
            {},
        )
        return data["goalsV2"]

    def legacy_migration(self) -> JSON:
        return self._transport.graphql(
            "Common_LegacyGoalsMigrationQuery",
            GET_LEGACY_GOALS_MIGRATION,
            {},
        )
