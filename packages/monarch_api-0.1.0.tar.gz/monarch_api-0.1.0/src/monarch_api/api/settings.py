from __future__ import annotations

from .._types import JSON
from ..documents import (
    GET_BUSINESS_ENTITIES,
    GET_BUSINESS_ENTITIES_BANNER_PROFILE,
    GET_DASHBOARD_CONFIG,
    GET_HAS_ACTIVITY,
    GET_HOUSEHOLD_MEMBER_SETTINGS,
    GET_NOTIFICATION_PREFERENCES,
    GET_OLDEST_DELETABLE_SYNCED_SNAPSHOT_DATE,
    GET_OLDEST_DELETABLE_TRANSACTION_DATE,
    GET_REVIEW_SUMMARY_BY_USER,
    GET_SECURITY_SETTINGS,
    GET_SIDEBAR_DATA,
    GET_USER_PROFILE_FLAGS,
)
from ..transport import MonarchTransport


class SettingsAPI:
    def __init__(self, transport: MonarchTransport) -> None:
        self._transport = transport

    def user_profile_flags(self) -> JSON:
        data = self._transport.graphql(
            "Common_UserProfileFlags",
            GET_USER_PROFILE_FLAGS,
            {},
        )
        return data["userProfile"]

    def dashboard_config(self) -> JSON:
        data = self._transport.graphql(
            "GetDashboardConfig",
            GET_DASHBOARD_CONFIG,
            {},
        )
        return data["myHousehold"]

    def oldest_deletable_synced_snapshot_date(self) -> str | None:
        data = self._transport.graphql(
            "OldestDeletableSyncedSnapshotDate",
            GET_OLDEST_DELETABLE_SYNCED_SNAPSHOT_DATE,
            {},
        )
        return data.get("oldestDeletableSyncedSnapshotDate")

    def oldest_deletable_transaction_date(
        self,
        *,
        include_synced: bool = False,
        include_uploaded: bool = False,
        include_manual: bool = False,
    ) -> str | None:
        data = self._transport.graphql(
            "Common_OldestDeletableTransactionDate",
            GET_OLDEST_DELETABLE_TRANSACTION_DATE,
            {
                "includeSynced": include_synced,
                "includeUploaded": include_uploaded,
                "includeManual": include_manual,
            },
        )
        return data.get("oldestDeletableTransactionDate")

    def sidebar_data(self, *, promo_code: str | None = None) -> JSON:
        return self._transport.graphql(
            "Web_GetSidebarData",
            GET_SIDEBAR_DATA,
            {"promoCode": promo_code},
        )

    def household_member_settings(self) -> JSON:
        return self._transport.graphql(
            "Common_GetHouseHoldMemberSettings",
            GET_HOUSEHOLD_MEMBER_SETTINGS,
            {},
        )

    def security_settings(self) -> JSON:
        return self._transport.graphql(
            "Web_GetSecuritySettings",
            GET_SECURITY_SETTINGS,
            {},
        )

    def notification_preferences(self) -> list[JSON]:
        data = self._transport.graphql(
            "Common_GetNotificationPreferences",
            GET_NOTIFICATION_PREFERENCES,
            {},
        )
        return data["notificationPreferences"]

    def review_summary_by_user(self) -> list[JSON]:
        data = self._transport.graphql(
            "Common_GetReviewSummaryByUser",
            GET_REVIEW_SUMMARY_BY_USER,
            {},
        )
        return data["byNeedsReviewByUser"]

    def business_entities_banner_profile(self) -> JSON:
        data = self._transport.graphql(
            "Common_GetBusinessEntitiesBannerProfile",
            GET_BUSINESS_ENTITIES_BANNER_PROFILE,
            {},
        )
        return (data.get("me") or {}).get("profile") or {}

    def business_entities(self) -> list[JSON]:
        data = self._transport.graphql(
            "Common_GetBusinessEntities",
            GET_BUSINESS_ENTITIES,
            {},
        )
        return data["businessEntities"]

    def has_activity(self) -> JSON:
        data = self._transport.graphql(
            "Common_HasActivity",
            GET_HAS_ACTIVITY,
            {},
        )
        return data["me"]
