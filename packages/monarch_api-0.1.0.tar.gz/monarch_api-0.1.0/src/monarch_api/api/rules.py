from __future__ import annotations

from .._types import JSON
from ..documents import (
    CREATE_TRANSACTION_RULE,
    DELETE_ALL_TRANSACTION_RULES,
    DELETE_TRANSACTION_RULE,
    GET_TRANSACTION_RULES,
    PREVIEW_TRANSACTION_RULE,
    UPDATE_TRANSACTION_RULE,
    UPDATE_TRANSACTION_RULE_ORDER,
)
from ..exceptions import MonarchGraphQLError
from ..transport import MonarchTransport


class RulesAPI:
    def __init__(self, transport: MonarchTransport) -> None:
        self._transport = transport

    def list(self) -> list[JSON]:
        data = self._transport.graphql(
            "GetTransactionRules",
            GET_TRANSACTION_RULES,
            {},
        )
        return data["transactionRules"]

    def create(self, input_data: JSON) -> JSON:
        return self._payload(
            "createTransactionRuleV2",
            self._transport.graphql(
                "Common_CreateTransactionRuleMutationV2",
                CREATE_TRANSACTION_RULE,
                {"input": input_data},
            ),
        )

    def update(self, input_data: JSON) -> JSON:
        return self._payload(
            "updateTransactionRuleV2",
            self._transport.graphql(
                "Common_UpdateTransactionRuleMutationV2",
                UPDATE_TRANSACTION_RULE,
                {"input": input_data},
            ),
        )

    def delete(self, rule_id: str) -> JSON:
        return self._payload(
            "deleteTransactionRule",
            self._transport.graphql(
                "Common_DeleteTransactionRule",
                DELETE_TRANSACTION_RULE,
                {"id": rule_id},
            ),
        )

    def preview(self, rule: JSON, *, offset: int | None = None) -> JSON:
        variables: JSON = {"rule": rule}
        if offset is not None:
            variables["offset"] = offset
        data = self._transport.graphql(
            "Common_PreviewTransactionRule",
            PREVIEW_TRANSACTION_RULE,
            variables,
        )
        return data["transactionRulePreview"]

    def update_order(self, rule_id: str, order: int) -> JSON:
        return self._payload(
            "updateTransactionRuleOrderV2",
            self._transport.graphql(
                "Web_UpdateRuleOrderMutation",
                UPDATE_TRANSACTION_RULE_ORDER,
                {"id": rule_id, "order": order},
            ),
        )

    def delete_all(self) -> JSON:
        return self._payload(
            "deleteAllTransactionRules",
            self._transport.graphql(
                "Web_DeleteAllTransactionRulesMutation",
                DELETE_ALL_TRANSACTION_RULES,
                {},
            ),
        )

    @staticmethod
    def _payload(field_name: str, data: JSON) -> JSON:
        payload = data.get(field_name)
        if not isinstance(payload, dict):
            raise MonarchGraphQLError(f"Expected payload object for {field_name}.", data)
        return payload
