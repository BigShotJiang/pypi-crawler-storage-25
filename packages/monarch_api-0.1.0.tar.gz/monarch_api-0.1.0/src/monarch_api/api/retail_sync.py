from __future__ import annotations

from .._types import JSON
from ..documents import (
    COMPLETE_RETAIL_SYNC,
    CREATE_BULK_RETAIL_SYNC,
    CREATE_RETAIL_SYNC,
    DELETE_RETAIL_SYNC,
    GET_RETAIL_EXTENSION_SETTINGS,
    GET_RETAIL_SYNC,
    LIST_RETAIL_SYNCS,
    MATCH_RETAIL_TRANSACTION,
    START_RETAIL_SYNC,
    UNMATCH_RETAIL_TRANSACTION,
    UPDATE_RETAIL_ORDER,
    UPDATE_RETAIL_VENDOR_SETTINGS,
)
from ..exceptions import MonarchGraphQLError
from ..transport import MonarchTransport


class RetailSyncAPI:
    def __init__(self, transport: MonarchTransport) -> None:
        self._transport = transport

    def get_settings(self) -> JSON:
        data = self._transport.graphql(
            "Common_GetRetailExtensionSettings",
            GET_RETAIL_EXTENSION_SETTINGS,
            {},
        )
        return data["retailExtensionSettings"]

    def get(self, sync_id: str) -> JSON:
        data = self._transport.graphql(
            "Common_RetailSyncQuery",
            GET_RETAIL_SYNC,
            {"syncId": sync_id},
        )
        return data["retailSync"]

    def list(
        self,
        *,
        filters: JSON,
        offset: int = 0,
        limit: int = 50,
        include_total_count: bool = True,
    ) -> JSON:
        data = self._transport.graphql(
            "Common_RetailSyncsQueryWithTotal",
            LIST_RETAIL_SYNCS,
            {
                "filters": filters,
                "offset": offset,
                "limit": limit,
                "includeTotalCount": include_total_count,
            },
        )
        return data["retailSyncsWithTotal"]

    def create(self, input_data: JSON) -> JSON:
        return self._payload(
            "createRetailSync",
            self._transport.graphql(
                "Common_CreateRetailSync",
                CREATE_RETAIL_SYNC,
                {"input": input_data},
            ),
        )

    def create_bulk(self, input_data: JSON) -> JSON:
        return self._payload(
            "createBulkRetailSync",
            self._transport.graphql(
                "Common_CreateBulkRetailSync",
                CREATE_BULK_RETAIL_SYNC,
                {"input": input_data},
            ),
        )

    def start(self, sync_id: str) -> JSON:
        return self._payload(
            "startRetailSync",
            self._transport.graphql(
                "Common_StartRetailSync",
                START_RETAIL_SYNC,
                {"syncId": sync_id},
            ),
        )

    def complete(self, sync_id: str) -> JSON:
        return self._payload(
            "completeRetailSync",
            self._transport.graphql(
                "Common_CompleteRetailSync",
                COMPLETE_RETAIL_SYNC,
                {"syncId": sync_id},
            ),
        )

    def delete(self, sync_id: str) -> JSON:
        return self._payload(
            "deleteUnmatchedRetailSync",
            self._transport.graphql(
                "Common_DeleteRetailSync",
                DELETE_RETAIL_SYNC,
                {"syncId": sync_id},
            ),
        )

    def match_transaction(self, retail_transaction_id: str, transaction_id: str) -> JSON:
        return self._payload(
            "matchRetailTransaction",
            self._transport.graphql(
                "Common_MatchRetailTransaction",
                MATCH_RETAIL_TRANSACTION,
                {"retailTransactionId": retail_transaction_id, "transactionId": transaction_id},
            ),
        )

    def unmatch_transaction(self, retail_transaction_id: str) -> JSON:
        return self._payload(
            "unmatchRetailTransaction",
            self._transport.graphql(
                "Web_UnmatchRetailTransaction",
                UNMATCH_RETAIL_TRANSACTION,
                {"retailTransactionId": retail_transaction_id},
            ),
        )

    def update_order(self, input_data: JSON) -> JSON:
        return self._payload(
            "updateRetailOrder",
            self._transport.graphql(
                "Common_UpdateRetailOrder",
                UPDATE_RETAIL_ORDER,
                {"input": input_data},
            ),
        )

    def update_vendor_settings(self, input_data: JSON) -> JSON:
        return self._payload(
            "updateRetailVendorSettings",
            self._transport.graphql(
                "Common_UpdateRetailVendorSettings",
                UPDATE_RETAIL_VENDOR_SETTINGS,
                {"input": input_data},
            ),
        )

    @staticmethod
    def _payload(field_name: str, data: JSON) -> JSON:
        payload = data.get(field_name)
        if not isinstance(payload, dict):
            raise MonarchGraphQLError(f"Expected {field_name} payload.", data)
        return payload
