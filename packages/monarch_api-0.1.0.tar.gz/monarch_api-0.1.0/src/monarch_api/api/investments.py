from __future__ import annotations

from .._types import JSON
from ..documents import (
    GET_INVESTMENTS_ACCOUNTS,
    GET_INVESTMENTS_DASHBOARD_CARD,
    GET_PORTFOLIO,
    GET_SECURITIES_HISTORICAL_PERFORMANCE,
)
from ..transport import MonarchTransport


class InvestmentsAPI:
    def __init__(self, transport: MonarchTransport) -> None:
        self._transport = transport

    def accounts(self) -> list[JSON]:
        data = self._transport.graphql(
            "Web_GetInvestmentsAccounts",
            GET_INVESTMENTS_ACCOUNTS,
            {},
        )
        return data["accounts"]

    def dashboard_card(self) -> JSON:
        return self._transport.graphql(
            "Web_GetInvestmentsDashboardCard",
            GET_INVESTMENTS_DASHBOARD_CARD,
            {},
        )

    def portfolio(self, *, portfolio_input: JSON | None = None) -> JSON:
        data = self._transport.graphql(
            "Web_GetPortfolio",
            GET_PORTFOLIO,
            {"portfolioInput": portfolio_input},
        )
        return data["portfolio"]

    def securities_historical_performance(self, *, input_data: JSON) -> list[JSON]:
        data = self._transport.graphql(
            "Web_GetSecuritiesHistoricalPerformance",
            GET_SECURITIES_HISTORICAL_PERFORMANCE,
            {"input": input_data},
        )
        return data["securityHistoricalPerformance"]
