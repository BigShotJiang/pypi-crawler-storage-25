from __future__ import annotations

from .._types import JSON
from ..documents import (
    GET_ENTITLEMENTS,
    GET_FEATURE_ENTITLEMENT_PARAMS,
    GET_GIFTED_SUBSCRIPTIONS,
    GET_PLUS_TIER_ACCESS,
    GET_PREMIUM_UPGRADE_PLANS,
    GET_REFERRAL_SETTINGS,
    GET_SUBSCRIPTION,
    GET_SUBSCRIPTION_DETAILS,
    GET_SUBSCRIPTION_MODAL,
    GET_TRIAL_STATUS,
)
from ..transport import MonarchTransport


class SubscriptionAPI:
    def __init__(self, transport: MonarchTransport) -> None:
        self._transport = transport

    def details(self) -> JSON:
        data = self._transport.graphql(
            "Common_GetSubscriptionDetails",
            GET_SUBSCRIPTION_DETAILS,
            {},
        )
        return data["subscription"]

    def subscription(self) -> JSON:
        return self._transport.graphql(
            "Web_GetSubscription",
            GET_SUBSCRIPTION,
            {},
        )

    def modal(self, *, promo_code: str | None = None, stripe_price_id: str = "") -> JSON:
        return self._transport.graphql(
            "Web_GetSubscriptionModal",
            GET_SUBSCRIPTION_MODAL,
            {
                "promoCode": promo_code,
                "stripePriceId": stripe_price_id,
            },
        )

    def premium_upgrade_plans(
        self,
        *,
        promo_code: str | None = None,
        referral_code: str | None = None,
        selected_plan_id: str | None = None,
    ) -> JSON:
        return self._transport.graphql(
            "Common_GetPremiumUpgradePlans",
            GET_PREMIUM_UPGRADE_PLANS,
            {
                "promoCode": promo_code,
                "referralCode": referral_code,
                "selectedPlanId": selected_plan_id,
            },
        )

    def trial_status(self) -> JSON:
        data = self._transport.graphql(
            "GetTrialStatus",
            GET_TRIAL_STATUS,
            {},
        )
        return data["subscription"]

    def entitlements(self) -> JSON:
        data = self._transport.graphql(
            "Common_GetEntitlements",
            GET_ENTITLEMENTS,
            {},
        )
        return data["subscription"]

    def feature_entitlement_params(self) -> JSON:
        data = self._transport.graphql(
            "Common_GetFeatureEntitlementParams",
            GET_FEATURE_ENTITLEMENT_PARAMS,
            {},
        )
        return data["subscription"]

    def plus_tier_access(self) -> JSON:
        data = self._transport.graphql(
            "Common_GetPlusTierAccess",
            GET_PLUS_TIER_ACCESS,
            {},
        )
        return data["subscription"]

    def gifted_subscriptions(self) -> list[JSON]:
        data = self._transport.graphql(
            "Common_GetGiftedSubscriptions",
            GET_GIFTED_SUBSCRIPTIONS,
            {},
        )
        return data["giftedSubscriptionsPurchasedByHousehold"]

    def referral_settings(
        self,
        *,
        statistics_start_date: str,
        statistics_end_date: str,
        v1_payout_method: str,
        v2_payout_method: str,
    ) -> JSON:
        return self._transport.graphql(
            "Common_GetReferralSettings",
            GET_REFERRAL_SETTINGS,
            {
                "statisticsStartDate": statistics_start_date,
                "statisticsEndDate": statistics_end_date,
                "v1PayoutMethod": v1_payout_method,
                "v2PayoutMethod": v2_payout_method,
            },
        )
