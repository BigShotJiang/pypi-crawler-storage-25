from __future__ import annotations

from .._types import JSON
from ..documents import GET_HOUSEHOLD_MEMBERS, GET_HOUSEHOLD_PREFERENCES, GET_MY_HOUSEHOLD
from ..transport import MonarchTransport


class HouseholdAPI:
    def __init__(self, transport: MonarchTransport) -> None:
        self._transport = transport

    def get(self) -> JSON:
        data = self._transport.graphql(
            "Common_GetMyHousehold",
            GET_MY_HOUSEHOLD,
            {},
        )
        return data["myHousehold"]

    def members(self) -> JSON:
        return self._transport.graphql(
            "Common_GetHouseholdMembers",
            GET_HOUSEHOLD_MEMBERS,
            {},
        )

    def preferences(self) -> JSON:
        return self._transport.graphql(
            "Common_GetHouseholdPreferences",
            GET_HOUSEHOLD_PREFERENCES,
            {},
        )
