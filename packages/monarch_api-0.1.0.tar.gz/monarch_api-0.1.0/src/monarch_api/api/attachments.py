from __future__ import annotations

from .._types import JSON
from ..documents import (
    ADD_TRANSACTION_ATTACHMENT,
    DELETE_ATTACHMENT,
    GET_ATTACHMENT_DETAILS,
    GET_TRANSACTION_ATTACHMENT_UPLOAD_INFO,
)
from ..exceptions import MonarchGraphQLError
from ..transport import MonarchTransport


class AttachmentsAPI:
    def __init__(self, transport: MonarchTransport) -> None:
        self._transport = transport

    def get_upload_info(self, transaction_id: str) -> JSON:
        data = self._transport.graphql(
            "Common_GetTransactionAttachmentUploadInfo",
            GET_TRANSACTION_ATTACHMENT_UPLOAD_INFO,
            {"transactionId": transaction_id},
        )
        return data["getTransactionAttachmentUploadInfo"]

    def add(self, input_data: JSON) -> JSON:
        data = self._transport.graphql(
            "Common_AddTransactionAttachment",
            ADD_TRANSACTION_ATTACHMENT,
            {"input": input_data},
        )
        payload = data.get("addTransactionAttachment")
        if not isinstance(payload, dict):
            raise MonarchGraphQLError("Expected addTransactionAttachment payload.", data)
        return payload

    def get(self, attachment_id: str) -> JSON:
        data = self._transport.graphql(
            "Mobile_GetAttachmentDetails",
            GET_ATTACHMENT_DETAILS,
            {"attachmentId": attachment_id},
        )
        return data["transactionAttachment"]

    def delete(self, attachment_id: str) -> bool:
        data = self._transport.graphql(
            "Web_TransactionDrawerDeleteAttachment",
            DELETE_ATTACHMENT,
            {"id": attachment_id},
        )
        return bool(data["deleteTransactionAttachment"]["deleted"])
