from __future__ import annotations

from .._types import JSON
from ..documents import (
    GET_HOUSEHOLD_MERCHANTS,
    GET_MERCHANTS_SEARCH,
    GET_RECOMMENDED_MERCHANTS,
    UPDATE_MERCHANT,
)
from ..exceptions import MonarchGraphQLError
from ..transport import MonarchTransport


class MerchantsAPI:
    def __init__(self, transport: MonarchTransport) -> None:
        self._transport = transport

    def search(self, *, search: str | None = None, limit: int = 20, include_ids: list[str] | None = None) -> list[JSON]:
        data = self._transport.graphql(
            "GetMerchantsSearch",
            GET_MERCHANTS_SEARCH,
            {"search": search, "limit": limit, "includeIds": include_ids},
        )
        return data["merchants"]

    def household(
        self,
        *,
        offset: int = 0,
        limit: int = 50,
        order_by: str = "TRANSACTION_COUNT",
        search: str | None = None,
    ) -> list[JSON]:
        data = self._transport.graphql(
            "Web_GetMerchantSelectHouseholdMerchants",
            GET_HOUSEHOLD_MERCHANTS,
            {"offset": offset, "limit": limit, "orderBy": order_by, "search": search},
        )
        return data["merchants"]

    def recommended_for_transaction(self, transaction_id: str) -> list[JSON]:
        data = self._transport.graphql(
            "Web_GetMerchantSelectRecommendedMerchants",
            GET_RECOMMENDED_MERCHANTS,
            {"transactionId": transaction_id},
        )
        return data["recommendedMerchants"]

    def update(self, input_data: JSON) -> JSON:
        data = self._transport.graphql(
            "Common_UpdateMerchant",
            UPDATE_MERCHANT,
            {"input": input_data},
        )
        payload = data.get("updateMerchant")
        if not isinstance(payload, dict):
            raise MonarchGraphQLError("Expected updateMerchant payload.", data)
        return payload
