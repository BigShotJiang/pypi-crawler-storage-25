GET_INVESTMENTS_ACCOUNTS = """
query Web_GetInvestmentsAccounts {
  accounts(
    filters: {accountType: "brokerage", includeManual: true, includeHidden: false, ignoreHiddenFromNetWorth: true}
  ) {
    id
    displayName
    isTaxable
    icon
    order
    logoUrl
    includeInNetWorth
    syncDisabled
    subtype {
      display
      __typename
    }
    __typename
  }
}
""".strip()

GET_INVESTMENTS_DASHBOARD_CARD = """
query Web_GetInvestmentsDashboardCard {
  portfolio {
    performance {
      totalValue
      oneDayChangeDollars
      topMovers {
        id
        name
        ticker
        oneDayChangePercent
        currentPrice
        __typename
      }
      __typename
    }
    __typename
  }
}
""".strip()

GET_PORTFOLIO = """
query Web_GetPortfolio($portfolioInput: PortfolioInput) {
  portfolio(input: $portfolioInput) {
    performance {
      totalValue
      totalChangePercent
      totalChangeDollars
      oneDayChangePercent
      historicalChart {
        date
        returnPercent
        __typename
      }
      benchmarks {
        security {
          id
          ticker
          name
          oneDayChangePercent
          __typename
        }
        historicalChart {
          date
          returnPercent
          __typename
        }
        __typename
      }
      __typename
    }
    aggregateHoldings {
      edges {
        node {
          id
          quantity
          costBasis
          totalValue
          securityPriceChangeDollars
          securityPriceChangePercent
          lastSyncedAt
          holdings {
            id
            type
            typeDisplay
            name
            ticker
            closingPrice
            closingPriceUpdatedAt
            quantity
            value
            costBasis
            userCostBasis
            account {
              id
              mask
              icon
              logoUrl
              institution {
                id
                name
                __typename
              }
              type {
                name
                display
                __typename
              }
              subtype {
                name
                display
                __typename
              }
              displayName
              order
              currentBalance
              __typename
            }
            taxLots {
              id
              createdAt
              acquisitionDate
              acquisitionQuantity
              costBasisPerUnit
              __typename
            }
            __typename
          }
          security {
            id
            name
            ticker
            currentPrice
            currentPriceUpdatedAt
            closingPrice
            type
            typeDisplay
            categoryGroup
            __typename
          }
          __typename
        }
        __typename
      }
      __typename
    }
    __typename
  }
}
""".strip()

GET_SECURITIES_HISTORICAL_PERFORMANCE = """
query Web_GetSecuritiesHistoricalPerformance($input: SecurityHistoricalPerformanceInput!) {
  securityHistoricalPerformance(input: $input) {
    security {
      id
      __typename
    }
    historicalChart {
      date
      returnPercent
      __typename
    }
    __typename
  }
}
""".strip()
