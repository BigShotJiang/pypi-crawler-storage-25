NEW_ACCOUNT_LOGO_FIELDS = """
fragment NewAccountLogoFields on Account {
  id
  dataProvider
  logoUrl
  type {
    name
    display
    __typename
  }
  subtype {
    name
    __typename
  }
  institution {
    id
    logo
    primaryColor
    __typename
  }
  __typename
}
""".strip()

GOAL_SUMMARY_FIELDS = """
fragment GoalSummaryFields on SavingsGoal {
  id
  type
  name
  createdAt
  archivedAt
  imageStorageProvider
  imageStorageProviderId
  status
  progress
  currentBalance
  targetDate
  targetAmount
  hasFutureBudgetDifferentFromCurrentMonth
  currentMonthActualBudgetAmount
  currentMonthPlannedContributionAmount
  plannedMonthlyContribution
  spendingTotal
  netContribution
  netContributionWithSpending
  netContributionWithoutSpending
  balanceThisMonth
  estimatedMonthsUntilCompletion
  forecastedCompletionDate
  isSinkingFund
  priority
  allocationAmountsByAccount {
    goalId
    adjustmentAmount
    totalAmount
    spendingAmount
    contributionsAmount
    withdrawalsAmount
    account {
      icon
      displayName
      displayBalance
      linkedGoal {
        id
        __typename
      }
      subtype {
        name
        display
        __typename
      }
      ...NewAccountLogoFields
      __typename
    }
    __typename
  }
  __typename
}
""".strip()

SAVINGS_GOAL_ACCOUNT_FIELDS = """
fragment SavingsGoalAccountFields on Account {
  ...NewAccountLogoFields
  icon
  displayBalance
  displayName
  subtype {
    name
    display
    __typename
  }
  availableBalanceForGoalsUnmemoized
  includeInGoalContributions
  goalAllocatedAmount
  linkedGoal {
    id
    __typename
  }
  __typename
}
""".strip()

DEBT_ACCOUNT_FIELDS = """
fragment DebtAccountFields on Account {
  id
  displayName
  displayBalance
  icon
  logoUrl
  includeInNetWorth
  isHidden
  displayLastUpdatedAt
  apr
  interestRate
  minimumPayment
  plannedPayment
  excludeFromDebtPaydown
  type {
    name
    display
    __typename
  }
  subtype {
    name
    display
    __typename
  }
  __typename
}
""".strip()

GET_SAVINGS_GOALS = f"""
query Common_SavingsGoals {{
  savingsGoals {{
    ...GoalSummaryFields
    __typename
  }}
}}

{NEW_ACCOUNT_LOGO_FIELDS}

{GOAL_SUMMARY_FIELDS}
""".strip()

GET_SAVINGS_GOALS_WITH_THIS_MONTH_BALANCES = f"""
query Common_SavingsGoalsWithThisMonthBalances {{
  savingsGoals {{
    ...GoalSummaryFields
    __typename
  }}
  goalsBalanceThisMonth
  currentTotalBalanceForGoals
}}

{NEW_ACCOUNT_LOGO_FIELDS}

{GOAL_SUMMARY_FIELDS}
""".strip()

GET_SAVINGS_GOAL_ACCOUNT = f"""
query Common_SavingsGoalAccount($id: UUID!) {{
  account(id: $id) {{
    ...SavingsGoalAccountFields
    __typename
  }}
}}

{NEW_ACCOUNT_LOGO_FIELDS}

{SAVINGS_GOAL_ACCOUNT_FIELDS}
""".strip()

GET_GOALS_DASHBOARD_CARD = """
query Web_GoalsDashboardCardV2 {
  goalsV2 {
    id
    priority
    ...Web_GoalDashboardRowFields
    __typename
  }
}

fragment Web_GoalDashboardRowFields on GoalV2 {
  id
  name
  imageStorageProvider
  imageStorageProviderId
  currentAmount
  completionPercent
  completedAt
  archivedAt
  type
  accountAllocations {
    id
    currentMonthChange {
      percent
      amount
      __typename
    }
    __typename
  }
  __typename
}
""".strip()

GET_LEGACY_GOALS_MIGRATION = f"""
query Common_LegacyGoalsMigrationQuery {{
  legacyGoalsMigrationData {{
    id
    newGoalId
    type
    archivedAt
    completedAt
    __typename
  }}
  debtAccounts {{
    ...DebtAccountFields
    __typename
  }}
  migratedToSavingsGoals
}}

{DEBT_ACCOUNT_FIELDS}
""".strip()
