from .transactions import PAYLOAD_ERROR_FIELDS

TRANSACTION_RULE_FIELDS = """
fragment TransactionRuleFields on TransactionRuleV2 {
  id
  merchantCriteriaUseOriginalStatement
  merchantCriteria {
    operator
    value
    __typename
  }
  originalStatementCriteria {
    operator
    value
    __typename
  }
  merchantNameCriteria {
    operator
    value
    __typename
  }
  amountCriteria {
    operator
    isExpense
    value
    valueRange {
      lower
      upper
      __typename
    }
    __typename
  }
  categoryIds
  accountIds
  categories {
    id
    name
    icon
    __typename
  }
  accounts {
    id
    displayName
    icon
    logoUrl
    __typename
  }
  criteriaOwnerIsJoint
  criteriaOwnerUserIds
  criteriaOwnerUsers {
    id
    displayName
    profilePictureUrl
    __typename
  }
  criteriaBusinessEntityIds
  criteriaBusinessEntityIsUnassigned
  setMerchantAction {
    id
    name
    __typename
  }
  setCategoryAction {
    id
    name
    icon
    __typename
  }
  addTagsAction {
    id
    name
    color
    __typename
  }
  linkGoalAction {
    id
    name
    imageStorageProvider
    imageStorageProviderId
    __typename
  }
  linkSavingsGoalAction {
    id
    name
    imageStorageProvider
    imageStorageProviderId
    __typename
  }
  needsReviewByUserAction {
    id
    displayName
    __typename
  }
  unassignNeedsReviewByUserAction
  sendNotificationAction
  setHideFromReportsAction
  reviewStatusAction
  actionSetOwnerIsJoint
  actionSetOwner {
    id
    displayName
    profilePictureUrl
    __typename
  }
  actionSetBusinessEntity {
    id
    name
    logoUrl
    color
    __typename
  }
  actionSetBusinessEntityIsUnassigned
  recentApplicationCount
  lastAppliedAt
  splitTransactionsAction {
    amountType
    splitsInfo {
      categoryId
      merchantName
      amount
      goalId
      savingsGoalId
      tags
      hideFromReports
      reviewStatus
      needsReviewByUserId
      ownerUserId
      ownerIsJoint
      businessEntityId
      businessEntityIsUnassigned
      __typename
    }
    __typename
  }
  __typename
}
""".strip()

GET_TRANSACTION_RULES = f"""
query GetTransactionRules {{
  transactionRules {{
    id
    order
    ...TransactionRuleFields
    __typename
  }}
}}

{TRANSACTION_RULE_FIELDS}
""".strip()

CREATE_TRANSACTION_RULE = f"""
mutation Common_CreateTransactionRuleMutationV2($input: CreateTransactionRuleInput!) {{
  createTransactionRuleV2(input: $input) {{
    errors {{
      ...PayloadErrorFields
    }}
  }}
}}

{PAYLOAD_ERROR_FIELDS}
""".strip()

UPDATE_TRANSACTION_RULE = f"""
mutation Common_UpdateTransactionRuleMutationV2($input: UpdateTransactionRuleInput!) {{
  updateTransactionRuleV2(input: $input) {{
    errors {{
      ...PayloadErrorFields
    }}
  }}
}}

{PAYLOAD_ERROR_FIELDS}
""".strip()

DELETE_TRANSACTION_RULE = f"""
mutation Common_DeleteTransactionRule($id: ID!) {{
  deleteTransactionRule(id: $id) {{
    deleted
    errors {{
      ...PayloadErrorFields
    }}
  }}
}}

{PAYLOAD_ERROR_FIELDS}
""".strip()

PREVIEW_TRANSACTION_RULE = """
query Common_PreviewTransactionRule($rule: TransactionRulePreviewInput!, $offset: Int) {
  transactionRulePreview(input: $rule) {
    totalCount
    results(offset: $offset, limit: 30) {
      newName
      newSplitTransactions
      newCategory {
        id
        icon
        name
      }
      newOwnerIsJoint
      newOwnerUser {
        id
        displayName
        profilePictureUrl
      }
      newHideFromReports
      newTags {
        id
        name
        color
        order
      }
      newGoal {
        id
        name
        imageStorageProvider
        imageStorageProviderId
      }
      newBusinessEntity {
        id
        name
        logoUrl
        color
      }
      newBusinessEntityIsUnassigned
      newSplitTransactions
      transaction {
        id
        date
        amount
        merchant {
          id
          name
        }
        category {
          id
          name
          icon
        }
        ownedByUser {
          id
          displayName
          profilePictureUrl
        }
        businessEntity {
          id
          name
          logoUrl
          color
        }
      }
    }
  }
}
""".strip()

UPDATE_TRANSACTION_RULE_ORDER = f"""
mutation Web_UpdateRuleOrderMutation($id: ID!, $order: Int!) {{
  updateTransactionRuleOrderV2(id: $id, order: $order) {{
    transactionRules {{
      id
      order
      ...TransactionRuleFields
      __typename
    }}
  }}
}}

{TRANSACTION_RULE_FIELDS}
""".strip()

DELETE_ALL_TRANSACTION_RULES = """
mutation Web_DeleteAllTransactionRulesMutation {
  deleteAllTransactionRules {
    deleted
  }
}
""".strip()
