BUDGET_DATA_MONTHLY_AMOUNTS_FIELDS = """
fragment BudgetDataMonthlyAmountsFields on BudgetMonthlyAmounts {
  month
  plannedCashFlowAmount
  plannedSetAsideAmount
  actualAmount
  remainingAmount
  previousMonthRolloverAmount
  rolloverType
  cumulativeActualAmount
  rolloverTargetAmount
  __typename
}
""".strip()

BUDGET_MONTHLY_AMOUNTS_BY_CATEGORY_FIELDS = """
fragment BudgetMonthlyAmountsByCategoryFields on BudgetCategoryMonthlyAmounts {
  category {
    id
    __typename
  }
  monthlyAmounts {
    ...BudgetDataMonthlyAmountsFields
    __typename
  }
  __typename
}
""".strip()

BUDGET_MONTHLY_AMOUNTS_BY_CATEGORY_GROUP_FIELDS = """
fragment BudgetMonthlyAmountsByCategoryGroupFields on BudgetCategoryGroupMonthlyAmounts {
  categoryGroup {
    id
    __typename
  }
  monthlyAmounts {
    ...BudgetDataMonthlyAmountsFields
    __typename
  }
  __typename
}
""".strip()

BUDGET_MONTHLY_AMOUNTS_FOR_FLEX_EXPENSE_FIELDS = """
fragment BudgetMonthlyAmountsForFlexExpenseFields on BudgetFlexMonthlyAmounts {
  budgetVariability
  monthlyAmounts {
    ...BudgetDataMonthlyAmountsFields
    __typename
  }
  __typename
}
""".strip()

BUDGET_DATA_TOTALS_BY_MONTH_FIELDS = """
fragment BudgetDataTotalsByMonthFields on BudgetTotals {
  actualAmount
  plannedAmount
  previousMonthRolloverAmount
  remainingAmount
  __typename
}
""".strip()

BUDGET_TOTALS_BY_MONTH_FIELDS = """
fragment BudgetTotalsByMonthFields on BudgetMonthTotals {
  month
  totalIncome {
    ...BudgetDataTotalsByMonthFields
    __typename
  }
  totalExpenses {
    ...BudgetDataTotalsByMonthFields
    __typename
  }
  totalFixedExpenses {
    ...BudgetDataTotalsByMonthFields
    __typename
  }
  totalNonMonthlyExpenses {
    ...BudgetDataTotalsByMonthFields
    __typename
  }
  totalFlexibleExpenses {
    ...BudgetDataTotalsByMonthFields
    __typename
  }
  __typename
}
""".strip()

BUDGET_ROLLOVER_PERIOD_FIELDS = """
fragment BudgetRolloverPeriodFields on BudgetRolloverPeriod {
  id
  startMonth
  endMonth
  startingBalance
  targetAmount
  frequency
  type
  __typename
}
""".strip()

BUDGET_CATEGORY_FIELDS = """
fragment BudgetCategoryFields on Category {
  id
  name
  icon
  order
  budgetVariability
  excludeFromBudget
  isSystemCategory
  updatedAt
  group {
    id
    type
    budgetVariability
    groupLevelBudgetingEnabled
    __typename
  }
  rolloverPeriod {
    ...BudgetRolloverPeriodFields
    __typename
  }
  __typename
}
""".strip()

BUDGET_STATUS_FIELDS = """
fragment BudgetStatusFields on BudgetStatus {
  hasBudget
  hasTransactions
  willCreateBudgetFromEmptyDefaultCategories
  __typename
}
""".strip()

BUDGET_DATA_FIELDS = """
fragment BudgetDataFields on BudgetData {
  monthlyAmountsByCategory {
    ...BudgetMonthlyAmountsByCategoryFields
    __typename
  }
  monthlyAmountsByCategoryGroup {
    ...BudgetMonthlyAmountsByCategoryGroupFields
    __typename
  }
  monthlyAmountsForFlexExpense {
    ...BudgetMonthlyAmountsForFlexExpenseFields
    __typename
  }
  totalsByMonth {
    ...BudgetTotalsByMonthFields
    __typename
  }
  __typename
}
""".strip()

BUDGET_CATEGORY_GROUP_FIELDS = """
fragment BudgetCategoryGroupFields on CategoryGroup {
  id
  name
  order
  type
  budgetVariability
  updatedAt
  groupLevelBudgetingEnabled
  categories {
    ...BudgetCategoryFields
    __typename
  }
  rolloverPeriod {
    id
    type
    startMonth
    endMonth
    startingBalance
    frequency
    targetAmount
    __typename
  }
  __typename
}
""".strip()

BUDGET_DATA_GOALS_V2_FIELDS = """
fragment BudgetDataGoalsV2Fields on GoalV2 {
  id
  name
  archivedAt
  completedAt
  priority
  imageStorageProvider
  imageStorageProviderId
  plannedContributions(startMonth: $startDate, endMonth: $endDate) {
    id
    month
    amount
    __typename
  }
  monthlyContributionSummaries(startMonth: $startDate, endMonth: $endDate) {
    month
    sum
    __typename
  }
  __typename
}
""".strip()

SAVINGS_GOAL_MONTHLY_BUDGET_AMOUNTS_FIELDS = """
fragment SavingsGoalMonthlyBudgetAmountsFields on SavingsGoalMonthlyBudgetAmounts {
  id
  savingsGoal {
    id
    name
    type
    status
    archivedAt
    priority
    targetDate
    imageStorageProvider
    imageStorageProviderId
    __typename
  }
  monthlyAmounts {
    id
    month
    plannedAmount
    actualAmount
    remainingAmount
    totalPlannedAmount
    totalActualAmount
    totalRemainingAmount
    __typename
  }
  __typename
}
""".strip()

GET_BUDGET_DATA = f"""
query Common_BudgetDataQuery($startDate: Date!, $endDate: Date!) {{
  budgetSystem
  budgetStatus {{
    ...BudgetStatusFields
    __typename
  }}
  budgetData(startMonth: $startDate, endMonth: $startDate) {{
    ...BudgetDataFields
    __typename
  }}
  categoryGroups {{
    ...BudgetCategoryGroupFields
    __typename
  }}
  goalsV2 {{
    ...BudgetDataGoalsV2Fields
    __typename
  }}
  savingsGoalMonthlyBudgetAmounts(startMonth: $startDate, endMonth: $endDate) {{
    ...SavingsGoalMonthlyBudgetAmountsFields
    __typename
  }}
}}

{BUDGET_DATA_MONTHLY_AMOUNTS_FIELDS}

{BUDGET_MONTHLY_AMOUNTS_BY_CATEGORY_FIELDS}

{BUDGET_MONTHLY_AMOUNTS_BY_CATEGORY_GROUP_FIELDS}

{BUDGET_MONTHLY_AMOUNTS_FOR_FLEX_EXPENSE_FIELDS}

{BUDGET_DATA_TOTALS_BY_MONTH_FIELDS}

{BUDGET_TOTALS_BY_MONTH_FIELDS}

{BUDGET_ROLLOVER_PERIOD_FIELDS}

{BUDGET_CATEGORY_FIELDS}

{BUDGET_STATUS_FIELDS}

{BUDGET_DATA_FIELDS}

{BUDGET_CATEGORY_GROUP_FIELDS}

{BUDGET_DATA_GOALS_V2_FIELDS}

{SAVINGS_GOAL_MONTHLY_BUDGET_AMOUNTS_FIELDS}
""".strip()

GET_JOINT_PLANNING_DATA = f"""
query Common_GetJointPlanningData($startDate: Date!, $endDate: Date!) {{
  budgetSystem
  budgetData(startMonth: $startDate, endMonth: $endDate) {{
    ...BudgetDataFields
    __typename
  }}
  categoryGroups {{
    ...BudgetCategoryGroupFields
    __typename
  }}
  goalsV2 {{
    ...BudgetDataGoalsV2Fields
    __typename
  }}
  savingsGoalMonthlyBudgetAmounts(startMonth: $startDate, endMonth: $endDate) {{
    ...SavingsGoalMonthlyBudgetAmountsFields
    __typename
  }}
}}

{BUDGET_DATA_MONTHLY_AMOUNTS_FIELDS}

{BUDGET_MONTHLY_AMOUNTS_BY_CATEGORY_FIELDS}

{BUDGET_MONTHLY_AMOUNTS_BY_CATEGORY_GROUP_FIELDS}

{BUDGET_MONTHLY_AMOUNTS_FOR_FLEX_EXPENSE_FIELDS}

{BUDGET_DATA_TOTALS_BY_MONTH_FIELDS}

{BUDGET_TOTALS_BY_MONTH_FIELDS}

{BUDGET_ROLLOVER_PERIOD_FIELDS}

{BUDGET_CATEGORY_FIELDS}

{BUDGET_DATA_FIELDS}

{BUDGET_CATEGORY_GROUP_FIELDS}

{BUDGET_DATA_GOALS_V2_FIELDS}

{SAVINGS_GOAL_MONTHLY_BUDGET_AMOUNTS_FIELDS}
""".strip()
