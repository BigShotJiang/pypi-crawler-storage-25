PAYLOAD_ERROR_FIELDS = """
fragment PayloadErrorFields on PayloadError {
  fieldErrors {
    field
    messages
    __typename
  }
  message
  code
  __typename
}
""".strip()

TRANSACTION_OVERVIEW_FIELDS = """
fragment TransactionOverviewFields on Transaction {
  id
  amount
  pending
  date
  hideFromReports
  hiddenByAccount
  plaidName
  notes
  isRecurring
  reviewStatus
  needsReview
  isSplitTransaction
  dataProviderDescription
  deletedAt
  deletedByType
  attachments {
    id
    __typename
  }
  goal {
    id
    name
    __typename
  }
  savingsGoalEvent {
    id
    goal {
      id
      name
      __typename
    }
    __typename
  }
  category {
    id
    name
    icon
    systemCategory
    group {
      id
      type
      __typename
    }
    __typename
  }
  merchant {
    name
    id
    transactionsCount
    logoUrl
    recurringTransactionStream {
      frequency
      isActive
      __typename
    }
    __typename
  }
  tags {
    id
    name
    color
    order
    __typename
  }
  account {
    id
    displayName
    icon
    logoUrl
    __typename
  }
  ownedByUser {
    id
    displayName
    profilePictureUrl
    __typename
  }
  businessEntity {
    id
    name
    logoUrl
    color
    __typename
  }
  __typename
}
""".strip()

TRANSACTION_DRAWER_SPLIT_MESSAGE_FIELDS = """
fragment TransactionDrawerSplitMessageFields on Transaction {
  id
  amount
  merchant {
    id
    name
    __typename
  }
  category {
    id
    icon
    name
    __typename
  }
  __typename
}
""".strip()

ORIGINAL_TRANSACTION_FIELDS = """
fragment OriginalTransactionFields on Transaction {
  id
  date
  amount
  merchant {
    id
    name
    __typename
  }
  __typename
}
""".strip()

ACCOUNT_LINK_FIELDS = """
fragment AccountLinkFields on Account {
  id
  displayName
  icon
  logoUrl
  id
  __typename
}
""".strip()

TRANSACTION_DRAWER_FIELDS = """
fragment TransactionDrawerFields on Transaction {
  id
  amount
  pending
  isRecurring
  date
  originalDate
  hideFromReports
  needsReview
  reviewedAt
  reviewedByUser {
    id
    name
    __typename
  }
  plaidName
  notes
  hasSplitTransactions
  isSplitTransaction
  isManual
  updatedByRetailSync
  linkedRetailTransactionId
  splitTransactions {
    id
    ...TransactionDrawerSplitMessageFields
    __typename
  }
  originalTransaction {
    id
    updatedByRetailSync
    ...OriginalTransactionFields
    __typename
  }
  attachments {
    id
    extension
    sizeBytes
    filename
    originalAssetUrl
    __typename
  }
  account {
    id
    hideTransactionsFromReports
    ownedByUser {
      id
      __typename
    }
    businessEntity {
      id
      __typename
    }
    type {
      name
      display
      __typename
    }
    ...AccountLinkFields
    __typename
  }
  category {
    id
    __typename
  }
  goal {
    id
    __typename
  }
  savingsGoalEvent {
    id
    goal {
      id
      __typename
    }
    account {
      id
      __typename
    }
    relatedGoalEvents {
      id
      amount
      date
      type
      goal {
        id
        __typename
      }
      account {
        id
        __typename
      }
      __typename
    }
    __typename
  }
  merchant {
    id
    name
    transactionCount
    logoUrl
    hasActiveRecurringStreams
    recurringTransactionStream {
      id
      frequency
      __typename
    }
    __typename
  }
  tags {
    id
    name
    color
    order
    __typename
  }
  needsReviewByUser {
    id
    __typename
  }
  ownedByUser {
    id
    __typename
  }
  ownershipOverriddenAt
  businessEntity {
    id
    __typename
  }
  businessEntityOverriddenAt
  ...TransactionOverviewFields
  __typename
}
""".strip()

GET_TRANSACTIONS_LIST = f"""
query Web_GetTransactionsList($offset: Int, $limit: Int, $filters: TransactionFilterInput, $orderBy: TransactionOrdering) {{
  allTransactions(filters: $filters) {{
    totalCount
    totalSelectableCount
    results(offset: $offset, limit: $limit, orderBy: $orderBy) {{
      id
      ...TransactionOverviewFields
      __typename
    }}
    __typename
  }}
  transactionRules {{
    id
    __typename
  }}
}}

{TRANSACTION_OVERVIEW_FIELDS}
""".strip()

GET_TRANSACTION_DRAWER = f"""
query GetTransactionDrawer($id: UUID!, $redirectPosted: Boolean) {{
  getTransaction(id: $id, redirectPosted: $redirectPosted) {{
    id
    ...TransactionDrawerFields
    __typename
  }}
  myHousehold {{
    id
    users {{
      id
      displayName
      profilePictureUrl
      __typename
    }}
    __typename
  }}
}}

{TRANSACTION_DRAWER_SPLIT_MESSAGE_FIELDS}

{ORIGINAL_TRANSACTION_FIELDS}

{ACCOUNT_LINK_FIELDS}

{TRANSACTION_OVERVIEW_FIELDS}

{TRANSACTION_DRAWER_FIELDS}
""".strip()

GET_TRANSACTIONS_FILTER_QUERY = """
query Web_TransactionsFilterQuery($search: String, $includeIds: [ID!]) {
  categoryGroups {
    id
    name
    order
    categories {
      id
      name
      icon
      order
      __typename
    }
    __typename
  }
  goalsV2 {
    id
    name
    imageStorageProvider
    imageStorageProviderId
    archivedAt
    priority
    __typename
  }
  savingsGoals {
    id
    name
    imageStorageProvider
    imageStorageProviderId
    archivedAt
    priority
    __typename
  }
  merchants(search: $search, includeIds: $includeIds) {
    id
    name
    transactionCount
    logoUrl
    __typename
  }
  accounts {
    id
    displayName
    logoUrl
    icon
    type {
      name
      display
      __typename
    }
    __typename
  }
  householdTransactionTags {
    id
    name
    order
    color
    __typename
  }
  myHousehold {
    id
    users {
      id
      name
      displayName
      profilePictureUrl
      __typename
    }
    __typename
  }
  householdPreferences {
    accountGroupOrder
    collaborationToolsEnabled
    __typename
  }
}
""".strip()

GET_TRANSACTION_FILTERS_METADATA = """
query Web_GetTransactionFiltersMetadata($input: TransactionFilterInput!) {
  transactionFiltersMetadata(input: $input) {
    categories {
      id
      name
      icon
      __typename
    }
    categoryGroups {
      id
      name
      __typename
    }
    accounts {
      id
      displayName
      logoUrl
      icon
      __typename
    }
    merchants {
      id
      name
      logoUrl
      __typename
    }
    tags {
      id
      name
      color
      __typename
    }
    goals {
      id
      name
      imageStorageProvider
      imageStorageProviderId
      __typename
    }
    savingsGoals {
      id
      name
      imageStorageProvider
      imageStorageProviderId
      __typename
    }
    needsReviewByUser {
      id
      name
      __typename
    }
    ownershipSet {
      includeJointlyOwned
      users {
        id
        name
        displayName
        profilePictureUrl
        __typename
      }
      __typename
    }
    businessEntitySet {
      includeUnassigned
      businessEntities {
        id
        name
        logoUrl
        color
        __typename
      }
      __typename
    }
    __typename
  }
}
""".strip()

CREATE_TRANSACTION = f"""
mutation Common_CreateTransactionMutation($input: CreateTransactionMutationInput!) {{
  createTransaction(input: $input) {{
    transaction {{
      id
      __typename
    }}
    errors {{
      ...PayloadErrorFields
      __typename
    }}
    __typename
  }}
}}

{PAYLOAD_ERROR_FIELDS}
""".strip()

UPDATE_TRANSACTION = f"""
mutation Web_TransactionDrawerUpdateTransaction($input: UpdateTransactionMutationInput!) {{
  updateTransaction(input: $input) {{
    transaction {{
      id
      ...TransactionDrawerFields
      __typename
    }}
    errors {{
      ...PayloadErrorFields
      __typename
    }}
    __typename
  }}
}}

{TRANSACTION_DRAWER_SPLIT_MESSAGE_FIELDS}

{ORIGINAL_TRANSACTION_FIELDS}

{ACCOUNT_LINK_FIELDS}

{TRANSACTION_OVERVIEW_FIELDS}

{TRANSACTION_DRAWER_FIELDS}

{PAYLOAD_ERROR_FIELDS}
""".strip()

DELETE_TRANSACTION = f"""
mutation Common_DeleteTransactionMutation($input: DeleteTransactionMutationInput!) {{
  deleteTransaction(input: $input) {{
    deleted
    errors {{
      ...PayloadErrorFields
      __typename
    }}
    __typename
  }}
}}

{PAYLOAD_ERROR_FIELDS}
""".strip()

SET_TRANSACTION_TAGS = f"""
mutation Web_SetTransactionTags($input: SetTransactionTagsInput!) {{
  setTransactionTags(input: $input) {{
    errors {{
      ...PayloadErrorFields
      __typename
    }}
    transaction {{
      id
      tags {{
        id
        __typename
      }}
      __typename
    }}
    __typename
  }}
}}

{PAYLOAD_ERROR_FIELDS}
""".strip()
