GET_USER_PROFILE_FLAGS = """
query Common_UserProfileFlags {
  userProfile {
    ...UserProfileFlagsFields
    __typename
  }
}

fragment UserProfileFlagsFields on UserProfile {
  id
  aiAssistantOptedInAt
  dismissedTaxLotsWalkthroughAt
  dismissedTransferAccountDataWalkthroughAt
  dismissedTransactionsListUpdatesTourAt
  dismissedYearlyReviewAt
  hasDismissedWhatsNewAt
  hasSeenCategoriesManagementTour
  hasSeenWeeklyReviewTour
  viewedMarkAsReviewedUpdatesCalloutAt
  hasHiddenReferralProgramPrompts
  dismissedOwnershipWalkthroughAt
  finishedOwnershipSetupAt
  displayOwnershipOnTransactionsList
  dismissedFinancialProfileBannerForMemberIds
  dismissedPaychecksWalkthroughAt
  dismissedContinuousMonitoringWalkthroughAt
  dismissedInvestmentsAdvancedWalkthroughAt
  dismissedFundAnalysisDisclosureAt
  hasReviewedSpending
  dismissedPlusTierWalkthroughAt
  __typename
}
""".strip()

GET_DASHBOARD_CONFIG = """
query GetDashboardConfig {
  myHousehold {
    id
    ...HouseholdDashboard
    __typename
  }
}

fragment HouseholdDashboard on Household {
  id
  preferences {
    dashboardConfig {
      web {
        ...DashboardConfig
        __typename
      }
      mobile {
        ...DashboardConfig
        __typename
      }
      __typename
    }
    __typename
  }
  __typename
}

fragment DashboardConfig on PlatformDashboardConfig {
  layout
  widgets
  __typename
}
""".strip()

GET_OLDEST_DELETABLE_SYNCED_SNAPSHOT_DATE = """
query OldestDeletableSyncedSnapshotDate {
  oldestDeletableSyncedSnapshotDate
}
""".strip()

GET_OLDEST_DELETABLE_TRANSACTION_DATE = """
query Common_OldestDeletableTransactionDate(
  $includeSynced: Boolean = false
  $includeUploaded: Boolean = false
  $includeManual: Boolean = false
) {
  oldestDeletableTransactionDate(
    includeSynced: $includeSynced
    includeUploaded: $includeUploaded
    includeManual: $includeManual
  )
}
""".strip()

GET_SIDEBAR_DATA = """
query Web_GetSidebarData($promoCode: String) {
  me {
    id
    displayName
    email
    profilePicture {
      id
      cloudinaryPublicId
      __typename
    }
    profilePictureUrl
    sponsorAccountName
    __typename
  }
  subscription {
    id
    billingPeriod
    paymentSource
    isOnFreeTrial
    hasPremiumEntitlement
    nextPaymentAmount
    activeSponsorship {
      id
      __typename
    }
    ...FreeTrialDurationPanelData
    __typename
  }
  subscriptionOffering(stripePromoCode: $promoCode) {
    promoCodeError
    promoCodeDescription
    plans {
      period
      pricePerPeriodDollars
      __typename
    }
    __typename
  }
}

fragment FreeTrialDurationPanelData on HouseholdSubscription {
  id
  trialEndsAt
  plusTrialEndsAt
  canceledPlusTrialAt
  trialDurationDays
  trialType
  entitlements
  __typename
}
""".strip()

GET_HOUSEHOLD_MEMBER_SETTINGS = """
query Common_GetHouseHoldMemberSettings {
  me {
    id
    householdRole
    __typename
  }
  myHousehold {
    id
    users {
      id
      name
      displayName
      email
      householdRole
      hasMfaOn
      profilePictureUrl
      financialProfile {
        ...FinancialProfileFields
        __typename
      }
      __typename
    }
    __typename
  }
  householdInvites {
    id
    invitedEmail
    createdAt
    isRevoked
    usedAt
    __typename
  }
  householdAccessGrants {
    id
    toEmail
    toName
    createdAt
    expiresAt
    __typename
  }
}

fragment FinancialProfileFields on UserFinancialProfile {
  id
  birthday
  grossAnnualIncome
  employmentStatus
  taxFilingStatus
  relationshipToOwner
  numberOfDependents
  __typename
}
""".strip()

GET_SECURITY_SETTINGS = """
query Web_GetSecuritySettings {
  me {
    id
    email
    hasMfaOn
    isVerified
    hasPassword
    externalAuthProviders {
      provider
      email
      __typename
    }
    pendingEmailUpdateVerification {
      email
      __typename
    }
    activeSupportAccountAccessGrant {
      id
      createdAt
      expiresAt
      __typename
    }
    __typename
  }
  userDiscordData {
    id
    discordId
    username
    roles
    __typename
  }
}
""".strip()

GET_NOTIFICATION_PREFERENCES = """
query Common_GetNotificationPreferences {
  notificationPreferences {
    ...NotificationPreferenceFields
    __typename
  }
}

fragment NotificationPreferenceFields on NotificationPreference {
  id
  group
  type
  additionalPreferences
  additionalPreferencesMeta
  title
  description
  EMAIL
  PUSH
  emailEnabled
  pushEnabled
  inAppEnabled
  __typename
}
""".strip()

GET_REVIEW_SUMMARY_BY_USER = """
query Common_GetReviewSummaryByUser {
  byNeedsReviewByUser: aggregates(
    groupBy: ["needsReviewByUser"]
    filters: {needsReview: true, transactionVisibility: all_transactions}
  ) {
    groupBy {
      needsReviewByUser {
        id
        name
        __typename
      }
      __typename
    }
    summary {
      count
      __typename
    }
    __typename
  }
}
""".strip()

GET_BUSINESS_ENTITIES_BANNER_PROFILE = """
query Common_GetBusinessEntitiesBannerProfile {
  me {
    id
    profile {
      id
      shouldShowBusinessEntitiesBanner
      businessEntitiesBannerCount
      dismissedBusinessEntitiesBannerAt
      __typename
    }
    __typename
  }
}
""".strip()

GET_BUSINESS_ENTITIES = """
query Common_GetBusinessEntities {
  businessEntities {
    ...BusinessEntityFields
    __typename
  }
}

fragment BusinessEntityFields on BusinessEntity {
  id
  name
  description
  logoUrl
  color
  notes
  structure
  createdAt
  updatedAt
  accounts {
    id
    logoUrl
    displayName
    __typename
  }
  accountsCount
  transactionsCount
  __typename
}
""".strip()

GET_HAS_ACTIVITY = """
query Common_HasActivity {
  me {
    id
    hasNewActivity
    __typename
  }
}
""".strip()
