GET_RECURRING_STREAMS = """
query Common_GetRecurringStreams($includeLiabilities: Boolean) {
  recurringTransactionStreams(
    includePending: true
    includeLiabilities: $includeLiabilities
  ) {
    stream {
      id
      reviewStatus
      frequency
      amount
      baseDate
      dayOfTheMonth
      isApproximate
      name
      logoUrl
      recurringType
      merchant {
        id
        __typename
      }
      creditReportLiabilityAccount {
        id
        account {
          id
          __typename
        }
        lastStatement {
          id
          dueDate
          __typename
        }
        __typename
      }
      __typename
    }
    __typename
  }
}
""".strip()

GET_AGGREGATED_RECURRING_ITEMS = """
query Common_GetAggregatedRecurringItems($startDate: Date!, $endDate: Date!, $filters: RecurringTransactionFilter) {
  aggregatedRecurringItems(
    startDate: $startDate
    endDate: $endDate
    groupBy: "status"
    filters: $filters
  ) {
    groups {
      groupBy {
        status
        __typename
      }
      results {
        ...RecurringItemFields
        __typename
      }
      summary {
        expense {
          total
          __typename
        }
        creditCard {
          total
          __typename
        }
        income {
          total
          __typename
        }
        __typename
      }
      __typename
    }
    aggregatedSummary {
      expense {
        completed
        remaining
        total
        count
        pendingAmountCount
        __typename
      }
      creditCard {
        completed
        remaining
        total
        count
        pendingAmountCount
        __typename
      }
      income {
        completed
        remaining
        total
        __typename
      }
      __typename
    }
    __typename
  }
}

fragment RecurringItemStreamFields on RecurringTransactionStream {
  id
  frequency
  isActive
  amount
  isApproximate
  name
  logoUrl
  merchant {
    id
    name
    logoUrl
    __typename
  }
  creditReportLiabilityAccount {
    id
    liabilityType
    account {
      id
      __typename
    }
    __typename
  }
  __typename
}

fragment RecurringItemLiabilityFields on LiabilityStatement {
  id
  minimumPaymentAmount
  paymentsInformation {
    status
    remainingBalance
    transactions {
      id
      amount
      date
      category {
        id
        name
        icon
        group {
          id
          name
          type
          __typename
        }
        __typename
      }
      __typename
    }
    __typename
  }
  __typename
}

fragment RecurringItemFields on RecurringTransactionCalendarItem {
  stream {
    ...RecurringItemStreamFields
    __typename
  }
  date
  isPast
  isLate
  markedPaidAt
  isCompleted
  transactionId
  amount
  amountDiff
  isAmountDifferentThanOriginal
  creditReportLiabilityStatementId
  category {
    id
    name
    icon
    __typename
  }
  account {
    id
    displayName
    icon
    logoUrl
    __typename
  }
  liabilityStatement {
    ...RecurringItemLiabilityFields
    __typename
  }
  __typename
}
""".strip()

GET_DASHBOARD_UPCOMING_RECURRING_ITEMS = """
query Web_GetDashboardUpcomingRecurringTransactionItems($startDate: Date!, $endDate: Date!, $includeLiabilities: Boolean, $filters: RecurringTransactionFilter) {
  recurringRemainingDue(
    startDate: $startDate
    endDate: $endDate
    includeLiabilities: $includeLiabilities
  ) {
    amount
    __typename
  }
  recurringTransactionItems(
    startDate: $startDate
    endDate: $endDate
    includeLiabilities: $includeLiabilities
    filters: $filters
  ) {
    stream {
      id
      frequency
      name
      logoUrl
      merchant {
        id
        __typename
      }
      creditReportLiabilityAccount {
        id
        account {
          id
          __typename
        }
        __typename
      }
      __typename
    }
    isPast
    date
    amount
    account {
      id
      logoUrl
      icon
      __typename
    }
    __typename
  }
}
""".strip()

GET_RECURRING_PAUSED_BANNER = """
query Web_RecurringPausedBanner {
  spinwheelUser {
    isBillSyncTrackingEnabled
    __typename
  }
}
""".strip()
