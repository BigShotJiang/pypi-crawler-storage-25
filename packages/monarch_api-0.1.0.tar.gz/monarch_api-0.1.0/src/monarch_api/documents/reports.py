GET_CASH_FLOW_DASHBOARD = """
query Common_GetCashFlowDashboard($filters: TransactionFilterInput) {
  byDay: aggregates(filters: $filters, fillEmptyValues: true, groupBy: ["day"]) {
    summary {
      sumExpense
      __typename
    }
    groupBy {
      day
      __typename
    }
    __typename
  }
}
""".strip()

GET_CASH_FLOW_ENTITY_AGGREGATES = """
query Common_GetCashFlowEntityAggregates($filters: TransactionFilterInput) {
  byCategory: aggregates(filters: $filters, groupBy: ["category"]) {
    groupBy {
      category {
        id
        name
        icon
        group {
          id
          type
          __typename
        }
        __typename
      }
      __typename
    }
    summary {
      sum
      __typename
    }
    __typename
  }
  byCategoryGroup: aggregates(filters: $filters, groupBy: ["categoryGroup"]) {
    groupBy {
      categoryGroup {
        id
        name
        type
        __typename
      }
      __typename
    }
    summary {
      sum
      __typename
    }
    __typename
  }
  byMerchant: aggregates(filters: $filters, groupBy: ["merchant"]) {
    groupBy {
      merchant {
        id
        name
        logoUrl
        __typename
      }
      __typename
    }
    summary {
      sumIncome
      sumExpense
      __typename
    }
    __typename
  }
  summary: aggregates(filters: $filters, fillEmptyValues: true) {
    summary {
      sumIncome
      sumExpense
      savings
      savingsRate
      __typename
    }
    __typename
  }
}
""".strip()

GET_CASH_FLOW_TIMEFRAME_AGGREGATES = """
query Common_GetCashFlowTimeframeAggregates($filters: TransactionFilterInput) {
  byYear: aggregates(groupBy: ["year"], fillEmptyValues: true, filters: $filters) {
    groupBy {
      year
      __typename
    }
    summary {
      savings
      savingsRate
      sumIncome
      sumExpense
      __typename
    }
    __typename
  }
  byMonth: aggregates(
    groupBy: ["month"]
    fillEmptyValues: true
    filters: $filters
  ) {
    groupBy {
      month
      __typename
    }
    summary {
      savings
      savingsRate
      sumIncome
      sumExpense
      __typename
    }
    __typename
  }
  byQuarter: aggregates(
    groupBy: ["quarter"]
    fillEmptyValues: true
    filters: $filters
  ) {
    groupBy {
      quarter
      __typename
    }
    summary {
      savings
      savingsRate
      sumIncome
      sumExpense
      __typename
    }
    __typename
  }
}
""".strip()

REPORTS_DATA_CATEGORY_FIELDS = """
fragment ReportsCategoryFields on ReportsGroupByData {
  category {
    id
    name
    icon
    group {
      id
      name
      type
      __typename
    }
    __typename
  }
  __typename
}
""".strip()

REPORTS_DATA_CATEGORY_GROUP_FIELDS = """
fragment ReportsCategoryGroupFields on ReportsGroupByData {
  categoryGroup {
    id
    name
    type
    __typename
  }
  __typename
}
""".strip()

REPORTS_DATA_MERCHANT_FIELDS = """
fragment ReportsMerchantFields on ReportsGroupByData {
  merchant {
    id
    name
    __typename
  }
  __typename
}
""".strip()

REPORTS_DATA_BUSINESS_ENTITY_FIELDS = """
fragment ReportsBusinessEntityFields on ReportsGroupByData {
  businessEntity {
    id
    name
    color
    icon
    logoUrl
    __typename
  }
  __typename
}
""".strip()

REPORTS_DATA_BUDGET_VARIABILITY_FIELDS = """
fragment ReportsBudgetVariabilityFields on ReportsGroupByData {
  budgetVariability {
    id
    name
    __typename
  }
  __typename
}
""".strip()

REPORTS_SUMMARY_FIELDS = """
fragment ReportsSummaryFields on TransactionsSummary {
  sum
  avg
  count
  max
  sumIncome
  sumExpense
  savings
  savingsRate
  first
  last
  __typename
}
""".strip()

GET_REPORTS_DATA = f"""
query Common_GetReportsData($filters: TransactionFilterInput!, $groupBy: [ReportsGroupByEntity!], $groupByTimeframe: ReportsGroupByTimeframe, $sortBy: ReportsSortBy, $includeCategory: Boolean = false, $includeCategoryGroup: Boolean = false, $includeMerchant: Boolean = false, $includeBusinessEntity: Boolean = false, $includeBudgetVariability: Boolean = false, $fillEmptyValues: Boolean = true) {{
  reports(
    groupBy: $groupBy
    groupByTimeframe: $groupByTimeframe
    filters: $filters
    sortBy: $sortBy
    fillEmptyValues: $fillEmptyValues
  ) {{
    groupBy {{
      date
      ...ReportsCategoryFields @include(if: $includeCategory)
      ...ReportsCategoryGroupFields @include(if: $includeCategoryGroup)
      ...ReportsMerchantFields @include(if: $includeMerchant)
      ...ReportsBusinessEntityFields @include(if: $includeBusinessEntity)
      ...ReportsBudgetVariabilityFields @include(if: $includeBudgetVariability)
      __typename
    }}
    summary {{
      ...ReportsSummaryFields
      __typename
    }}
    __typename
  }}
  aggregates(filters: $filters, fillEmptyValues: $fillEmptyValues) {{
    summary {{
      ...ReportsSummaryFields
      __typename
    }}
    __typename
  }}
}}

{REPORTS_DATA_CATEGORY_FIELDS}

{REPORTS_DATA_CATEGORY_GROUP_FIELDS}

{REPORTS_DATA_MERCHANT_FIELDS}

{REPORTS_DATA_BUSINESS_ENTITY_FIELDS}

{REPORTS_DATA_BUDGET_VARIABILITY_FIELDS}

{REPORTS_SUMMARY_FIELDS}
""".strip()
