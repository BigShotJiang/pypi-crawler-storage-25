from .transactions import PAYLOAD_ERROR_FIELDS

GET_HOUSEHOLD_TRANSACTION_TAGS = """
query Common_GetHouseholdTransactionTags($search: String, $limit: Int, $bulkParams: BulkTransactionDataParams, $includeTransactionCount: Boolean = false) {
  householdTransactionTags(
    search: $search
    limit: $limit
    bulkParams: $bulkParams
  ) {
    id
    name
    color
    order
    transactionCount @include(if: $includeTransactionCount)
    __typename
  }
}
""".strip()

GET_CATEGORIES = """
query Common_GetCategories($includeSystemDisabledCategories: Boolean) {
  categoryGroups {
    id
    name
    order
    type
    groupLevelBudgetingEnabled
    budgetVariability
    rolloverPeriod {
      id
      startMonth
      startingBalance
      frequency
      targetAmount
      type
      __typename
    }
    categories {
      id
      __typename
    }
    __typename
  }
  categories(includeDisabledSystemCategories: $includeSystemDisabledCategories) {
    id
    name
    order
    icon
    isSystemCategory
    excludeFromBudget
    budgetVariability
    isDisabled
    group {
      id
      type
      __typename
    }
    rolloverPeriod {
      id
      startMonth
      startingBalance
      frequency
      targetAmount
      type
      __typename
    }
    __typename
  }
}
""".strip()

GET_MERCHANTS_SEARCH = """
query GetMerchantsSearch($search: String, $limit: Int, $includeIds: [ID!]) {
  merchants(
    search: $search
    limit: $limit
    orderBy: TRANSACTION_COUNT
    includeIds: $includeIds
  ) {
    id
    name
    transactionCount
    __typename
  }
}
""".strip()

GET_HOUSEHOLD_MERCHANTS = """
query Web_GetMerchantSelectHouseholdMerchants($offset: Int!, $limit: Int!, $orderBy: MerchantOrdering, $search: String) {
  merchants(
    offset: $offset
    limit: $limit
    orderBy: $orderBy
    search: $search
    includeMerchantsWithoutTransactions: false
  ) {
    id
    name
    logoUrl
    transactionCount
    __typename
  }
}
""".strip()

GET_RECOMMENDED_MERCHANTS = """
query Web_GetMerchantSelectRecommendedMerchants($transactionId: ID!) {
  recommendedMerchants(id: $transactionId) {
    name
    source
    transactionCount
    __typename
  }
}
""".strip()

UPDATE_MERCHANT = f"""
mutation Common_UpdateMerchant($input: UpdateMerchantInput!) {{
  updateMerchant(input: $input) {{
    merchant {{
      id
      name
      recurringTransactionStream {{
        id
        frequency
        amount
        baseDate
        isActive
        __typename
      }}
      __typename
    }}
    errors {{
      ...PayloadErrorFields
      __typename
    }}
    __typename
  }}
}}

{PAYLOAD_ERROR_FIELDS}
""".strip()

GET_TRANSACTION_ATTACHMENT_UPLOAD_INFO = """
mutation Common_GetTransactionAttachmentUploadInfo($transactionId: UUID!) {
  getTransactionAttachmentUploadInfo(transactionId: $transactionId) {
    info {
      path
      requestParams {
        timestamp
        folder
        signature
        api_key
        upload_preset
      }
    }
  }
}
""".strip()

ADD_TRANSACTION_ATTACHMENT = """
mutation Common_AddTransactionAttachment($input: TransactionAddAttachmentMutationInput!) {
  addTransactionAttachment(input: $input) {
    attachment {
      id
      publicId
      extension
      sizeBytes
      filename
      originalAssetUrl
    }
    errors {
      message
    }
  }
}
""".strip()

GET_ATTACHMENT_DETAILS = """
query Mobile_GetAttachmentDetails($attachmentId: UUID!) {
  transactionAttachment(id: $attachmentId) {
    id
    originalAssetUrl
  }
}
""".strip()

DELETE_ATTACHMENT = """
mutation Web_TransactionDrawerDeleteAttachment($id: UUID!) {
  deleteTransactionAttachment(id: $id) {
    deleted
  }
}
""".strip()

GET_RETAIL_EXTENSION_SETTINGS = """
query Common_GetRetailExtensionSettings {
  retailExtensionSettings {
    id
    retailVendorSettings {
      id
      vendor
      shouldCategorizeAndSplitTransactions
      shouldUpdateTransactionsNotes
    }
  }
}
""".strip()

RETAIL_LINE_ITEM_FIELDS = """
fragment RetailLineItemFields on RetailLineItem {
  __typename
  id
  title
  quantity
  price
  total
  isAssociatedToRetailTransaction
  category {
    __typename
    id
    name
    icon
  }
}
""".strip()

RETAIL_TRANSACTION_FIELDS = """
fragment RetailTransactionFields on RetailTransaction {
  __typename
  id
  date
  total
  transactionType
  transactionUpdateSkipped
  transaction {
    id
    isManual
    hasSplitTransactions
    merchant {
      id
      name
      logoUrl
      __typename
    }
    __typename
  }
}
""".strip()

RETAIL_ORDER_ATTACHMENT_FIELDS = """
fragment RetailOrderAttachmentFields on RetailUserAttachment {
  id
  storageId
  filename
  extension
  sizeBytes
  originalAssetUrl
  thumbnailUrl
  __typename
}
""".strip()

RETAIL_ORDER_FIELDS = """
fragment RetailOrderFields on RetailOrder {
  __typename
  id
  merchantName
  vendor
  vendorOrderId
  date
  totalForProducts
  shipping
  deliveryFee
  additionalCharges
  adjustmentsAmount
  totalBeforeTax
  tax
  tip
  giftCardAmount
  grandTotal
  displayStatus
  retailLineItems {
    ...RetailLineItemFields
  }
  retailTransactions {
    ...RetailTransactionFields
  }
}
""".strip()

RETAIL_SYNC_BASIC_FIELDS = """
fragment RetailSyncBasicFields on RetailSync {
  __typename
  id
  vendor
  status
  startedAt
  endedAt
  createdAt
  updatedAt
}
""".strip()

RETAIL_SYNC_WITH_ORDERS_FIELDS = """
fragment RetailSyncWithOrdersFields on RetailSync {
  ...RetailSyncBasicFields
  orders {
    ...RetailOrderFields
  }
  attachments {
    ...RetailOrderAttachmentFields
  }
}
""".strip()

GET_RETAIL_SYNC = f"""
query Common_RetailSyncQuery($syncId: ID!) {{
  retailSync(id: $syncId) {{
    ...RetailSyncWithOrdersFields
  }}
}}

{RETAIL_LINE_ITEM_FIELDS}

{RETAIL_TRANSACTION_FIELDS}

{RETAIL_ORDER_ATTACHMENT_FIELDS}

{RETAIL_ORDER_FIELDS}

{RETAIL_SYNC_BASIC_FIELDS}

{RETAIL_SYNC_WITH_ORDERS_FIELDS}
""".strip()

LIST_RETAIL_SYNCS = f"""
query Common_RetailSyncsQueryWithTotal(
  $filters: RetailSyncFilterInput!
  $offset: Int!
  $limit: Int!
  $includeTotalCount: Boolean
) {{
  retailSyncsWithTotal(
    filters: $filters
    offset: $offset
    limit: $limit
    includeTotalCount: $includeTotalCount
  ) {{
    totalCount
    results {{
      ...RetailSyncWithOrdersFields
    }}
  }}
}}

{RETAIL_LINE_ITEM_FIELDS}

{RETAIL_TRANSACTION_FIELDS}

{RETAIL_ORDER_ATTACHMENT_FIELDS}

{RETAIL_ORDER_FIELDS}

{RETAIL_SYNC_BASIC_FIELDS}

{RETAIL_SYNC_WITH_ORDERS_FIELDS}
""".strip()

CREATE_RETAIL_SYNC = f"""
mutation Common_CreateRetailSync($input: CreateRetailSyncInput!) {{
  createRetailSync(input: $input) {{
    retailSync {{
      ...RetailSyncBasicFields
    }}
    errors {{
      ...PayloadErrorFields
    }}
  }}
}}

{RETAIL_SYNC_BASIC_FIELDS}

{PAYLOAD_ERROR_FIELDS}
""".strip()

CREATE_BULK_RETAIL_SYNC = f"""
mutation Common_CreateBulkRetailSync($input: CreateBulkRetailSyncInput!) {{
  createBulkRetailSync(input: $input) {{
    retailSyncs {{
      ...RetailSyncBasicFields
    }}
    errors {{
      ...PayloadErrorFields
    }}
  }}
}}

{RETAIL_SYNC_BASIC_FIELDS}

{PAYLOAD_ERROR_FIELDS}
""".strip()

START_RETAIL_SYNC = f"""
mutation Common_StartRetailSync($syncId: ID!) {{
  startRetailSync(id: $syncId) {{
    retailSync {{
      ...RetailSyncBasicFields
    }}
    errors {{
      ...PayloadErrorFields
    }}
  }}
}}

{RETAIL_SYNC_BASIC_FIELDS}

{PAYLOAD_ERROR_FIELDS}
""".strip()

COMPLETE_RETAIL_SYNC = f"""
mutation Common_CompleteRetailSync($syncId: ID!) {{
  completeRetailSync(id: $syncId) {{
    retailSync {{
      ...RetailSyncWithOrdersFields
    }}
    errors {{
      ...PayloadErrorFields
    }}
  }}
}}

{RETAIL_LINE_ITEM_FIELDS}

{RETAIL_TRANSACTION_FIELDS}

{RETAIL_ORDER_ATTACHMENT_FIELDS}

{RETAIL_ORDER_FIELDS}

{RETAIL_SYNC_BASIC_FIELDS}

{RETAIL_SYNC_WITH_ORDERS_FIELDS}

{PAYLOAD_ERROR_FIELDS}
""".strip()

DELETE_RETAIL_SYNC = f"""
mutation Common_DeleteRetailSync($syncId: ID!) {{
  deleteUnmatchedRetailSync(id: $syncId) {{
    success
    errors {{
      ...PayloadErrorFields
    }}
  }}
}}

{PAYLOAD_ERROR_FIELDS}
""".strip()

MATCH_RETAIL_TRANSACTION = f"""
mutation Common_MatchRetailTransaction($retailTransactionId: ID!, $transactionId: ID!) {{
  matchRetailTransaction(
    retailTransactionId: $retailTransactionId
    transactionId: $transactionId
  ) {{
    retailSync {{
      ...RetailSyncBasicFields
    }}
    errors {{
      ...PayloadErrorFields
    }}
  }}
}}

{RETAIL_SYNC_BASIC_FIELDS}

{PAYLOAD_ERROR_FIELDS}
""".strip()

UNMATCH_RETAIL_TRANSACTION = f"""
mutation Web_UnmatchRetailTransaction($retailTransactionId: ID!) {{
  unmatchRetailTransaction(retailTransactionId: $retailTransactionId) {{
    retailSync {{
      ...RetailSyncBasicFields
    }}
    errors {{
      ...PayloadErrorFields
    }}
  }}
}}

{RETAIL_SYNC_BASIC_FIELDS}

{PAYLOAD_ERROR_FIELDS}
""".strip()

UPDATE_RETAIL_ORDER = f"""
mutation Common_UpdateRetailOrder($input: UpdateRetailOrderInput!) {{
  updateRetailOrder(input: $input) {{
    retailSync {{
      ...RetailSyncWithOrdersFields
    }}
    errors {{
      ...PayloadErrorFields
    }}
  }}
}}

{RETAIL_LINE_ITEM_FIELDS}

{RETAIL_TRANSACTION_FIELDS}

{RETAIL_ORDER_ATTACHMENT_FIELDS}

{RETAIL_ORDER_FIELDS}

{RETAIL_SYNC_BASIC_FIELDS}

{RETAIL_SYNC_WITH_ORDERS_FIELDS}

{PAYLOAD_ERROR_FIELDS}
""".strip()

UPDATE_RETAIL_VENDOR_SETTINGS = f"""
mutation Common_UpdateRetailVendorSettings($input: UpdateRetailVendorSettingsInput!) {{
  updateRetailVendorSettings(input: $input) {{
    retailVendorSettings {{
      id
      vendor
      shouldCategorizeAndSplitTransactions
      shouldUpdateTransactionsNotes
    }}
    errors {{
      ...PayloadErrorFields
    }}
  }}
}}

{PAYLOAD_ERROR_FIELDS}
""".strip()
