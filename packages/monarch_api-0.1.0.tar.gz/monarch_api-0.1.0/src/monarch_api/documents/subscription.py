GET_SUBSCRIPTION_DETAILS = """
query Common_GetSubscriptionDetails {
  subscription {
    id
    paymentSource
    referralCode
    isOnFreeTrial
    hasPremiumEntitlement
    willCancelAtPeriodEnd
    trialEndsAt
    trialDurationDays
    plusTrialEndsAt
    billingPeriod
    isEligibleForCoreToPlusPromo
    paymentMethod {
      lastFour
      __typename
    }
    activeSponsorship {
      id
      __typename
    }
    __typename
  }
}
""".strip()

GET_SUBSCRIPTION = """
query Web_GetSubscription {
  subscription {
    id
    ...SubscriptionFields
    ...SponsoredSubscriptionFields
    __typename
  }
  invoices {
    id
    date
    amount
    receiptUrl
    __typename
  }
  creditBalance
  constants {
    monthlyPriceDollars
    __typename
  }
}

fragment SubscriptionFields on HouseholdSubscription {
  id
  trialEndsAt
  trialType
  trialDurationDays
  isOnFreeTrial
  canceledPlusTrialAt
  plusTrialEndsAt
  hasChargedForLifetime
  currentPeriodEndsAt
  billingPeriod
  nextPaymentAmount
  hasStripeSubscriptionId
  hasPremiumEntitlement
  entitlements
  eligibleForTrial
  willCancelAtPeriodEnd
  paymentSource
  hasBillingIssue
  isSponsor
  hasHadFreeTrialExtension
  paymentMethod {
    lastFour
    brand
    __typename
  }
  activePromoCode {
    code
    description
    __typename
  }
  sponsoredBy {
    name
    email
    profilePictureUrl
    __typename
  }
  analyticsFreemiumSummaryStatus
  isEligibleForCoreToPlusPromo
  __typename
}

fragment SponsoredSubscriptionFields on HouseholdSubscription {
  activeSponsorship {
    id
    sponsor {
      name
      email
      profilePictureUrl
      __typename
    }
    __typename
  }
  __typename
}
""".strip()

GET_SUBSCRIPTION_MODAL = """
query Web_GetSubscriptionModal($promoCode: String, $stripePriceId: String! = "") {
  subscription {
    id
    billingPeriod
    trialEndsAt
    trialDurationDays
    hasPremiumEntitlement
    entitlements
    willCancelAtPeriodEnd
    isOnFreeTrial
    paymentSource
    paymentMethod {
      brand
      lastFour
      __typename
    }
    hasStripeSubscriptionId
    hasChargedForLifetime
    referralRedemption {
      campaign
      __typename
    }
    analyticsFreemiumSummaryStatus
    currentPeriodEndsAt
    nextPaymentAmount
    hasHadFreeTrialExtension
    canceledPlusTrialAt
    activePromoCode {
      code
      __typename
    }
    plusUpgradeProratedAmount(stripePriceId: $stripePriceId, promoCode: $promoCode)
    __typename
  }
  plusUpgradeTrial {
    trialDays
    isEligible
    __typename
  }
  subscriptionOffering(
    selectedPlanId: $stripePriceId
    stripePromoCode: $promoCode
  ) {
    promoCodeError
    promoCodeDescription
    promoCodeDuration
    promoCodeDurationInMonths
    plans {
      name
      period
      tier
      pricePerPeriodDollars
      discountedPricePerPeriodDollars
      stripeId
      newTrialEndsAt
      requirePaymentMethod
      sponsoredBy {
        name
        email
        profilePictureUrl
        __typename
      }
      __typename
    }
    __typename
  }
}
""".strip()

GET_PREMIUM_UPGRADE_PLANS = """
query Common_GetPremiumUpgradePlans($promoCode: String, $referralCode: String, $selectedPlanId: String) {
  subscriptionOffering(
    stripePromoCode: $promoCode
    referralCode: $referralCode
    selectedPlanId: $selectedPlanId
  ) {
    promoCodeError
    promoCodeDescription
    promoCodeDuration
    promoCodeDurationInMonths
    plans {
      name
      period
      pricePerPeriodDollars
      discountedPricePerPeriodDollars
      stripeId
      tier
      newTrialEndsAt
      requirePaymentMethod
      sponsoredBy {
        name
        email
        profilePictureUrl
        __typename
      }
      __typename
    }
    __typename
  }
  subscription {
    id
    trialEndsAt
    referralRedemption {
      campaign
      __typename
    }
    __typename
  }
}
""".strip()

GET_TRIAL_STATUS = """
query GetTrialStatus {
  subscription {
    id
    eligibleForTrial
    trialDurationDays
    hasPremiumEntitlement
    entitlements
    __typename
  }
}
""".strip()

GET_ENTITLEMENTS = """
query Common_GetEntitlements {
  subscription {
    id
    entitlements
    __typename
  }
}
""".strip()

GET_FEATURE_ENTITLEMENT_PARAMS = """
query Common_GetFeatureEntitlementParams {
  subscription {
    id
    entitlementParams {
      features {
        feature
        requiredEntitlements
        __typename
      }
      constants {
        entitlement
        maxCredentials
        maxTransactionRules
        __typename
      }
      __typename
    }
    __typename
  }
}
""".strip()

GET_PLUS_TIER_ACCESS = """
query Common_GetPlusTierAccess {
  subscription {
    id
    entitlements
    __typename
  }
}
""".strip()

GET_GIFTED_SUBSCRIPTIONS = """
query Common_GetGiftedSubscriptions {
  giftedSubscriptionsPurchasedByHousehold {
    id
    createdAt
    recipientName
    promoCode
    status
    redeemedAt
    __typename
  }
}
""".strip()

GET_REFERRAL_SETTINGS = """
query Common_GetReferralSettings(
  $statisticsStartDate: DateTime!
  $statisticsEndDate: DateTime!
  $v1PayoutMethod: ReferralPayoutMethod!
  $v2PayoutMethod: ReferralPayoutMethod!
) {
  constants {
    ...ReferralConstantsFields
    __typename
  }
  legacyReferralStatistics: referralStatistics(
    filters: {creditPayoutMethod: $v1PayoutMethod, endDate: $statisticsEndDate}
  ) {
    ...ReferralLegacyStatisticsFields
    __typename
  }
  referralStatistics: referralStatistics(
    filters: {
      creditPayoutMethod: $v2PayoutMethod
      startDate: $statisticsStartDate
      endDate: $statisticsEndDate
    }
  ) {
    ...ReferralEarningsStatisticsFields
    __typename
  }
  referralRedemptions(
    filters: {creditPayoutMethod: $v2PayoutMethod, hasEarnedCredits: true}
  ) {
    id
    ...ReferralEarningsRedemptionsFields
    __typename
  }
}

fragment ReferralConstantsFields on Constants {
  referralAnnualRewardLimitUsd
  referralV2ProgramLaunchDate
  __typename
}

fragment ReferralLegacyStatisticsFields on ReferralStatistics {
  creditsEarned
  subscribed
  signedUp
  __typename
}

fragment ReferralEarningsStatisticsFields on ReferralStatistics {
  creditsEarned
  pendingCount
  earnedCreditsCount
  __typename
}

fragment ReferralEarningsRedemptionsFields on ReferralRedemption {
  id
  creditsEarned
  creditsEarnedAt
  __typename
}
""".strip()
