GET_MY_HOUSEHOLD = """
query Common_GetMyHousehold {
  myHousehold {
    ...HouseholdFields
    __typename
  }
}

fragment HouseholdFields on Household {
  address
  city
  id
  name
  state
  zipCode
  country
  __typename
}
""".strip()

GET_HOUSEHOLD_MEMBERS = """
query Common_GetHouseholdMembers {
  me {
    id
    __typename
  }
  myHousehold {
    id
    users {
      id
      name
      displayName
      householdRole
      profilePictureUrl
      __typename
    }
    __typename
  }
}
""".strip()

GET_HOUSEHOLD_PREFERENCES = """
query Common_GetHouseholdPreferences {
  householdPreferences {
    id
    ...HouseholdPreferencesFields
    __typename
  }
  ...HouseholdBudgetSettingsFields
}

fragment HouseholdPreferencesFields on HouseholdPreferences {
  id
  newTransactionsNeedReview
  uncategorizedTransactionsNeedReview
  pendingTransactionsCanBeEdited
  accountGroupOrder
  aiAssistantEnabled
  llmEnrichmentEnabled
  investmentTransactionsEnabled
  budgetApplyToFutureMonthsDefault
  hiddenTransactionsBetaEnabled
  collaborationToolsEnabled
  aggDataSharingEnabled
  aiModelTrainingOnUserDataEnabled
  excludeBusinessFromBudget
  continuousFinancialMonitoringEnabled
  eligibleForFinancialInsights
  __typename
}

fragment HouseholdBudgetSettingsFields on Query {
  budgetSystem
  budgetApplyToFutureMonthsDefault
  __typename
}
""".strip()
