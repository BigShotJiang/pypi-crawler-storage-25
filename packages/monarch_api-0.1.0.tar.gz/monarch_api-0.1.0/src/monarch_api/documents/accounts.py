from .transactions import PAYLOAD_ERROR_FIELDS

GET_ACTIVE_INSTITUTION_NOTICES = """
query Common_AllActiveInstitutionNotices {
  activeInstitutionNotices {
    id
    publicMessage
    severity
    startsAt
    institutionId
    dataProvider
    showAsWarnBeforeConnecting
    __typename
  }
}
""".strip()

GET_HAS_ACCOUNTS = """
query Common_GetHasAccounts {
  hasAccounts
}
""".strip()

GET_ACCOUNTS_SYNCING = """
query Common_ForceRefreshAccountsQuery {
  hasAccountsSyncing
}
""".strip()

GET_AGGREGATE_SNAPSHOTS = """
query Common_GetAggregateSnapshots($filters: AggregateSnapshotFilters) {
  aggregateSnapshots(filters: $filters) {
    date
    balance
    assetsBalance
    liabilitiesBalance
    __typename
  }
}
""".strip()

GET_DISPLAY_BALANCE_AT_DATE = """
query Common_GetDisplayBalanceAtDate($date: Date!, $filters: AccountFilters) {
  accounts(filters: $filters) {
    id
    displayBalance(date: $date)
    includeInNetWorth
    type {
      name
      __typename
    }
    __typename
  }
}
""".strip()

GET_SNAPSHOTS_BY_ACCOUNT_TYPE = """
query Common_GetSnapshotsByAccountType($startDate: Date!, $timeframe: Timeframe!, $filters: AccountFilters) {
  snapshotsByAccountType(
    startDate: $startDate
    timeframe: $timeframe
    filters: $filters
  ) {
    accountType
    month
    balance
    __typename
  }
  accountTypes {
    name
    group
    __typename
  }
}
""".strip()

GET_LATEST_FORCE_REFRESH_OPERATION = """
query Common_LatestForceRefreshOperation {
  latestForceRefreshOperation {
    id
    state
  }
}
""".strip()

GET_FORCE_REFRESH_OPERATION = """
query Common_ForceRefreshOperationQuery($id: ID!) {
  forceRefreshOperation(id: $id) {
    id
    state
    completedAccountCount
    totalAccountCount
    accounts {
      accountId
      state
      newTransactionCount
      updatedTransactionCount
      completedAt
      startedAt
      timedOut
      errorMessage
      errorDetail
    }
  }
}
""".strip()

GET_FORCE_REFRESH_ACCOUNT = """
query Common_ForceRefreshAccountQuery($accountId: UUID!) {
  account(id: $accountId) {
    id
    canBeForceRefreshed
    hasSyncOrRecentRefreshRequest
  }
}
""".strip()

ACCOUNT_MASK_FIELDS = """
fragment AccountMaskFields on Account {
  id
  mask
  subtype {
    display
    __typename
  }
  __typename
}
""".strip()

INSTITUTION_STATUS_TOOLTIP_FIELDS = """
fragment InstitutionStatusTooltipFields on Institution {
  id
  logo
  name
  status
  plaidStatus
  newConnectionsDisabled
  hasIssuesReported
  url
  hasIssuesReportedMessage
  transactionsStatus
  balanceStatus
  __typename
}
""".strip()

ACCOUNT_LIST_ITEM_FIELDS = """
fragment AccountListItemFields on Account {
  id
  displayName
  displayBalance
  signedBalance
  updatedAt
  syncDisabled
  dataProviderDeactivatedAt
  icon
  logoUrl
  isHidden
  isAsset
  includeInNetWorth
  includeBalanceInNetWorth
  displayLastUpdatedAt
  limit
  type {
    name
    __typename
  }
  ...AccountMaskFields
  credential {
    id
    updateRequired
    dataProvider
    disconnectedFromDataProviderAt
    syncDisabledAt
    syncDisabledReason
    __typename
  }
  connectionStatus {
    connectionStatusCode
    copyTitle
    inAppSmallCopy
    inAppCopy
    helpCenterUrl
    __typename
  }
  institution {
    id
    ...InstitutionStatusTooltipFields
    __typename
  }
  ownedByUser {
    id
    displayName
    profilePictureUrl
    __typename
  }
  businessEntity {
    id
    name
    logoUrl
    color
    __typename
  }
  __typename
}
""".strip()

ACCOUNTS_LIST_FIELDS = """
fragment AccountsListFields on Account {
  id
  syncDisabled
  isHidden
  isAsset
  includeInNetWorth
  order
  type {
    name
    display
    __typename
  }
  ...AccountListItemFields
  __typename
}
""".strip()

GET_ACCOUNTS_PAGE = f"""
query Web_GetAccountsPage($filters: AccountFilters) {{
  hasAccounts
  accountTypeSummaries(filters: $filters) {{
    type {{
      name
      display
      group
      __typename
    }}
    accounts {{
      id
      credential {{
        id
        institution {{
          id
          name
          __typename
        }}
        __typename
      }}
      connectionStatus {{
        connectionStatusCode
        copyTitle
        inAppSmallCopy
        inAppCopy
        helpCenterUrl
        __typename
      }}
      ...AccountsListFields
      __typename
    }}
    isAsset
    totalDisplayBalance
    __typename
  }}
  householdPreferences {{
    id
    accountGroupOrder
    collaborationToolsEnabled
    __typename
  }}
}}

{ACCOUNT_MASK_FIELDS}

{INSTITUTION_STATUS_TOOLTIP_FIELDS}

{ACCOUNT_LIST_ITEM_FIELDS}

{ACCOUNTS_LIST_FIELDS}
""".strip()

GET_ACCOUNTS_PAGE_RECENT_BALANCE = """
query Web_GetAccountsPageRecentBalance($startDate: Date) {
  accounts {
    id
    recentBalances(startDate: $startDate)
    type {
      name
      display
      group
      __typename
    }
    includeInNetWorth
    __typename
  }
}
""".strip()

GET_FILTERED_ACCOUNTS = """
query Web_GetFilteredAccounts($filters: AccountFilters) {
  accounts(filters: $filters) {
    id
    createdAt
    displayName
    displayBalance
    displayLastUpdatedAt
    dataProvider
    icon
    logoUrl
    order
    isAsset
    includeBalanceInNetWorth
    deactivatedAt
    manualInvestmentsTrackingMethod
    isManual
    syncDisabled
    type {
      display
      name
      __typename
    }
    credential {
      updateRequired
      syncDisabledAt
      __typename
    }
    institution {
      status
      newConnectionsDisabled
      __typename
    }
    ownedByUser {
      id
      displayName
      profilePictureUrl
      __typename
    }
    businessEntity {
      id
      __typename
    }
    __typename
  }
}
""".strip()

GET_ACCOUNT_FILTER_QUERY = """
query Web_AccountFilterQuery {
  accounts {
    id
    displayName
    logoUrl
    icon
    type {
      name
      display
      group
      __typename
    }
    subtype {
      name
      display
      __typename
    }
    __typename
  }
  myHousehold {
    id
    users {
      id
      name
      profilePictureUrl
      __typename
    }
    __typename
  }
  householdPreferences {
    accountGroupOrder
    collaborationToolsEnabled
    __typename
  }
}
""".strip()

GET_ACCOUNT_TYPES = """
query Web_GetAccountTypes {
  accountTypes {
    name
    display
    group
    showForSyncedAccounts
    possibleSubtypes {
      display
      name
      __typename
    }
    __typename
  }
}
""".strip()

FORCE_REFRESH_ACCOUNT = f"""
mutation Common_ForceRefreshAccountMutation($input: ForceRefreshAccountInput!) {{
  forceRefreshAccount(input: $input) {{
    success
    errors {{
      ...PayloadErrorFields
    }}
  }}
}}

{PAYLOAD_ERROR_FIELDS}
""".strip()

FORCE_REFRESH_ALL_ACCOUNTS = f"""
mutation Common_ForceRefreshAccountsMutation($input: ForceRefreshAllAccountsInput) {{
  forceRefreshAllAccounts(input: $input) {{
    success
    forceRefreshOperationId
    errors {{
      ...PayloadErrorFields
    }}
  }}
}}

{PAYLOAD_ERROR_FIELDS}
""".strip()

GET_INSTITUTION_SETTINGS = """
query Web_GetInstitutionSettings {
  credentials {
    id
    ...CredentialSettingsCardFields
    __typename
  }
  accounts(filters: {includeDeleted: true, includeHidden: true}) {
    id
    createdAt
    displayName
    subtype {
      display
      __typename
    }
    mask
    credential {
      id
      __typename
    }
    deletedAt
    hideFromList
    ownedByUser {
      id
      displayName
      profilePictureUrl
      __typename
    }
    displayLastUpdatedAt
    updatedAt
    __typename
  }
  subscription {
    isOnFreeTrial
    hasPremiumEntitlement
    __typename
  }
}

fragment InstitutionLogoWithStatusFields on Credential {
  dataProvider
  updateRequired
  institution {
    hasIssuesReported
    logo
    status
    balanceStatus
    transactionsStatus
    __typename
  }
  __typename
}

fragment InstitutionInfoFields on Credential {
  id
  displayLastUpdatedAt
  dataProvider
  updateRequired
  disconnectedFromDataProviderAt
  syncDisabledAt
  syncDisabledReason
  createdAt
  user {
    displayName
    __typename
  }
  ...InstitutionLogoWithStatusFields
  institution {
    id
    name
    logo
    newConnectionsDisabled
    hasIssuesReported
    hasIssuesReportedMessage
    __typename
  }
  __typename
}

fragment CredentialSyncStatusFields on Credential {
  id
  displayLastUpdatedAt
  dataProvider
  updateRequired
  institution {
    id
    hasIssuesReportedMessage
    __typename
  }
  __typename
}

fragment CredentialSettingsCardFields on Credential {
  id
  updateRequired
  disconnectedFromDataProviderAt
  syncDisabledAt
  syncDisabledReason
  ...InstitutionInfoFields
  ...CredentialSyncStatusFields
  institution {
    id
    name
    logo
    url
    newConnectionsDisabled
    hasIssuesReportedMessage
    __typename
  }
  __typename
}
""".strip()
