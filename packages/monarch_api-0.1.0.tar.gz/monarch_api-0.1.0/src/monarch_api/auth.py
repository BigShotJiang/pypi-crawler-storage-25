from __future__ import annotations

from pathlib import Path

from ._types import JSON
from .models import MonarchSession
from .transport import MonarchTransport


class AuthAPI:
    def __init__(self, transport: MonarchTransport) -> None:
        self._transport = transport

    def login(
        self,
        *,
        username: str,
        password: str,
        totp: str | None = None,
        trusted_device: bool = True,
        supports_mfa: bool = True,
        supports_email_otp: bool = True,
        supports_recaptcha: bool = True,
    ) -> MonarchSession:
        payload: JSON = {
            "username": username,
            "password": password,
            "trusted_device": trusted_device,
            "supports_mfa": supports_mfa,
            "supports_email_otp": supports_email_otp,
            "supports_recaptcha": supports_recaptcha,
        }
        if totp:
            payload["totp"] = totp
        response = self._transport.rest_json("POST", "/auth/login/", json_body=payload, authenticated=False)
        session = MonarchSession.from_login_response(response, device_uuid=self._transport.device_uuid)
        self._transport.set_session(session)
        return session

    def use_token(self, token: str, *, device_uuid: str | None = None) -> MonarchSession:
        session = MonarchSession(token=token, device_uuid=device_uuid or self._transport.device_uuid)
        self._transport.set_session(session)
        return session

    def get_me(self) -> JSON:
        return self._transport.rest_json("GET", "/users/me/", authenticated=True)

    def save_session(self, path: str | Path) -> None:
        if not self._transport.session:
            raise ValueError("No authenticated session is loaded.")
        self._transport.session.save(path)

    def load_session(self, path: str | Path) -> MonarchSession:
        session = MonarchSession.load(path)
        self._transport.set_session(session)
        return session
