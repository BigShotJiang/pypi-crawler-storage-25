QUESTIONS = {
    "1": {
        "files": {
            "index.html": """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Psg ITECh</title>
<style>
body {
font-family: Arial, sans-serif;
text-align: center;
background: linear-gradient(to bottom, #e0f7fa, #ffffff);
margin: 0;
padding: 0;
}

header {
background-color: #004080;
color: white;
padding: 20px 0;
box-shadow: 0 4px 8px rgba(0,0,0,0.2);
font-size: 24px;
}

main {
margin-top: 30px;
display: inline-block;
padding: 20px;
background-color: rgba(255,255,255,0.9);
border-radius: 10px;
box-shadow: 0 4px 15px rgba(0,0,0,0.1);
}

img {
border: 4px solid #004080;
border-radius: 10px;
cursor: pointer;
transition: transform 0.3s, box-shadow 0.3s;
}

img:hover {
transform: scale(1.05);
box-shadow: 0 8px 20px rgba(0,0,0,0.4);
}

area {
cursor: pointer;
}
</style>
</head>
<body>

<header>
PSG Institute of Technology and Applied Research
</header>

<main>
<img src="psgitech.jpg" alt="South India States" usemap="#state">

<map name="state">
<area shape="rect" coords="73,26,111,73" alt="Admin" href="https://psgitech.ac.in/" title="Admin Block">
<area shape="rect" coords="70,99,110,146" alt="CSE" href="https://cse.psgitech.ac.in/" title="CSE Department">
<area shape="rect" coords="127,113,181,156" alt="EEE" href="https://eee.psgitech.ac.in/" title="EEE Department">
<area shape="rect" coords="189,104,249,144" alt="ECE" href="https://ece.psgitech.ac.in/" title="ECE Department">
<area shape="rect" coords="190,27,252,76" alt="Civil" href="https://civil.psgitech.ac.in/" title="Civil Department">
<area shape="rect" coords="122,22,181,59" alt="Mech" href="https://mechanical.psgitech.ac.in/" title="Mechanical Department">
</map>
</main>

</body>
</html>"""
        }
    },

    "2": {
        "files": {
            "index.html": """<!DOCTYPE html>
<html>
<head>
<title>Resume using CSS</title>

<link rel="stylesheet" href="style.css">

<style>
body {
font-family: Arial, sans-serif;
background-color: #f2f2f2;
}
h2 {
color: darkblue;
}
</style>
</head>

<body>

<h1 style="color: darkred; text-align: center;">
Ananya S
</h1>

<p style="text-align: center; font-weight: bold;">
Computer Science Student
</p>

<hr>

<h2>Education</h2>
<ul>
<li>B.E Computer Science – PSG iTech</li>
<li>Higher Secondary – IPS, Erode</li>
</ul>

<h2>Skills</h2>
<ul>
<li>Python, Java</li>
<li>HTML, CSS</li>
<li>MySQL</li>
</ul>

<h2>Achievements</h2>
<p class="highlight">
Winner – College Hackathon 2024
</p>

</body>
</html>""",
            "style.css": """ul {
background-color: white;
padding: 10px;
}

li {
margin: 5px;
}

.highlight {
color: green;
font-weight: bold;
}"""
        }
    },

    "3": {
        "files": {
            "index.html": """<!DOCTYPE html>
<html>
<head>
<title>Simple Registration Form</title>

<style>
body{
font-family:Arial;
background:#f4f6f9;
}
.container{
width:400px;
margin:40px auto;
background:white;
padding:20px;
border-radius:8px;
box-shadow:0 0 10px rgba(0,0,0,0.1);
}
h2{
text-align:center;
}
label{
font-weight:bold;
}
input{
width:100%;
padding:8px;
margin-top:5px;
margin-bottom:10px;
border:1px solid #ccc;
border-radius:4px;
}
input[type="radio"]{
width:auto;
}
.error{
color:red;
font-size:12px;
}

.success{
color:green;
text-align:center;
}
button{
width:100%;
padding:10px;
background:#007bff;
color:white;
border:none;
border-radius:5px;
cursor:pointer;
}
button:hover{
background:#0056b3;
}
</style>

</head>
<body>
<div class="container">
<h2>Registration Form</h2>

<form id="form">
<label>Full Name</label>
<input type="text" id="name">
<div class="error" id="nameError"></div>

<label>Email</label>
<input type="text" id="email">
<div class="error" id="emailError"></div>

<label>Password</label>
<input type="password" id="password">
<div class="error" id="passwordError"></div>

<label>Confirm Password</label>
<input type="password" id="confirm">
<div class="error" id="confirmError"></div>

<label>Phone</label>
<input type="text" id="phone">
<div class="error" id="phoneError"></div>

<label>Gender</label><br>
<input type="radio" name="gender" value="Male"> Male
<input type="radio" name="gender" value="Female"> Female
<div class="error" id="genderError"></div>

<br><br>

<button type="button" onclick="validate()">Submit</button>
<div class="success" id="success"></div>
</form>

</div>

<script>

function validate(){

document.querySelectorAll(".error").forEach(e=>e.innerHTML="")
document.getElementById("success").innerHTML=""

let name=document.getElementById("name").value.trim()
let email=document.getElementById("email").value.trim()
let password=document.getElementById("password").value
let confirm=document.getElementById("confirm").value
let phone=document.getElementById("phone").value.trim()
let gender=document.querySelector('input[name="gender"]:checked')

let valid=true

if(!/^[A-Za-z ]+$/.test(name)){
document.getElementById("nameError").innerHTML="Enter valid name"
valid=false
}

let emailPattern=/^[^ ]+@[^ ]+\.[a-z]{2,3}$/

if(!emailPattern.test(email)){
document.getElementById("emailError").innerHTML="Enter valid email"
valid=false
}

if(password.length<6){
document.getElementById("passwordError").innerHTML="Password must be at least 6 characters"
valid=false
}

if(password!==confirm){
document.getElementById("confirmError").innerHTML="Passwords do not match"
valid=false
}

if(!/^[0-9]{10}$/.test(phone)){
document.getElementById("phoneError").innerHTML="Enter 10 digit phone number"
valid=false
}
if(!gender){
document.getElementById("genderError").innerHTML="Select gender"
valid=false
}
if(valid){
document.getElementById("success").innerHTML="Form submitted successfully!"
document.getElementById("form").reset()
}

}

</script>

</body>
</html>"""
        }
    },

    "5a": {
        "files": {
            "index.html": """<!DOCTYPE html>
<html>
<head>
<title>Simple Registration Form</title>

<style>
body{
font-family:Arial;
background:linear-gradient(135deg,#6dd5ed,#2193b0);
display:flex;
justify-content:center;
align-items:center;
height:100vh;
}

.container{
background:white;
padding:30px;
border-radius:10px;
width:320px;
box-shadow:0 0 10px rgba(0,0,0,0.3);
}

h2{
text-align:center;
}

input{
width:100%;
padding:10px;
margin-top:5px;
margin-bottom:15px;
border:1px solid #ccc;
border-radius:5px;
}

input[type=radio]{
width:auto;
}

input[type=submit]{
background:#2193b0;
color:white;
border:none;
cursor:pointer;
}

input[type=submit]:hover{
background:#176d82;
}
</style>
</head>

<body>

<div class="container">

<h2>Registration Form</h2>

<form action="MyServlet" method="POST">

<label>Full Name</label>
<input type="text" name="name" required>

<label>Email</label>
<input type="email" name="email" required>

<label>Phone</label>
<input type="text" name="phone" required>

<label>Gender</label><br>
<input type="radio" name="gender" value="Male" required> Male
<input type="radio" name="gender" value="Female"> Female
<br><br>

<input type="submit" value="Register">

</form>

</div>

</body>
</html>""",
            "MyServlet.java": """import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/MyServlet")
public class MyServlet extends HttpServlet {

protected void doPost(HttpServletRequest request, HttpServletResponse response)
throws ServletException, IOException {

String name = request.getParameter("name");
String email = request.getParameter("email");
String phone = request.getParameter("phone");
String gender = request.getParameter("gender");

response.setContentType("text/html");
PrintWriter out = response.getWriter();

out.println("<html>");
out.println("<head><title>Result</title></head>");
out.println("<body style='font-family:Arial;text-align:center;margin-top:100px;'>");

out.println("<h2 style='color:green;'>Registration Successful</h2>");
out.println("<p><b>Name:</b> " + name + "</p>");
out.println("<p><b>Email:</b> " + email + "</p>");
out.println("<p><b>Phone:</b> " + phone + "</p>");
out.println("<p><b>Gender:</b> " + gender + "</p>");

out.println("</body>");
out.println("</html>");
}
}""",
            "web.xml": """<web-app xmlns="https://jakarta.ee/xml/ns/jakartaee"
version="5.0">

<servlet>
<servlet-name>MyServlet</servlet-name>
<servlet-class>MyServlet</servlet-class>
</servlet>

<servlet-mapping>
<servlet-name>MyServlet</servlet-name>
<url-pattern>/MyServlet</url-pattern>
</servlet-mapping>

</web-app>"""
        }
    },

    "5b": {
        "files": {
            "movie.html": """<!DOCTYPE html>
<html>
<head>
<title>Movie Ticket Booking</title>

<style>
body{
font-family:Arial;
background:linear-gradient(135deg,#89f7fe,#66a6ff);
display:flex;
justify-content:center;
align-items:center;
height:100vh;
}

.container{
background:white;
padding:30px;
border-radius:10px;
width:350px;
box-shadow:0 0 10px rgba(0,0,0,0.3);
}

h2{
text-align:center;
}

input{
width:100%;
padding:10px;
margin-top:5px;
margin-bottom:15px;
border:1px solid #ccc;
border-radius:5px;
}

input[type=submit]{
background:#4a90e2;
color:white;
border:none;
cursor:pointer;
}

input[type=submit]:hover{
background:#2d6fb7;
}
</style>

</head>

<body>

<div class="container">

<h2>Movie Ticket Booking</h2>

<form action="movie" method="post">

<label>Customer Name</label>
<input type="text" name="name" required>

<label>Movie Name</label>
<input type="text" name="movie" required>

<label>Number of Tickets</label>
<input type="number" name="tickets" required>

<label>Show Time</label>
<input type="time" name="time" required>

<input type="submit" value="Book Ticket">

</form>

</div>

</body>
</html>""",
            "MovieServlet.java": """import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@WebServlet("/movie")
public class MovieServlet extends HttpServlet {

protected void doPost(HttpServletRequest request, HttpServletResponse response)
throws ServletException, IOException {

response.setContentType("text/html");
PrintWriter out = response.getWriter();

String name = request.getParameter("name");
String movie = request.getParameter("movie");
String tickets = request.getParameter("tickets");
String time = request.getParameter("time");

Cookie c1 = new Cookie("name",name);
Cookie c2 = new Cookie("movie",movie);
Cookie c3 = new Cookie("tickets",tickets);
Cookie c4 = new Cookie("time",time);

response.addCookie(c1);
response.addCookie(c2);
response.addCookie(c3);
response.addCookie(c4);

out.println("<html>");
out.println("<body style='font-family:Arial;text-align:center;margin-top:100px;'>");

out.println("<h2>Welcome " + name + "</h2>");
out.println("<p>Your movie booking is stored using cookies.</p>");
out.println("<a href='ticket'>View Ticket</a>");

out.println("</body>");
out.println("</html>");
}
}""",
            "TicketServlet.java": """import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@WebServlet("/ticket")
public class TicketServlet extends HttpServlet {

protected void doGet(HttpServletRequest request, HttpServletResponse response)
throws ServletException, IOException {

response.setContentType("text/html");
PrintWriter out = response.getWriter();

Cookie cookies[] = request.getCookies();

String name="",movie="",tickets="",time="";

if(cookies!=null){
for(Cookie c : cookies){

if(c.getName().equals("name"))
name = c.getValue();

if(c.getName().equals("movie"))
movie = c.getValue();

if(c.getName().equals("tickets"))
tickets = c.getValue();

if(c.getName().equals("time"))
time = c.getValue();
}
}

out.println("<html>");
out.println("<body style='font-family:Arial;text-align:center;margin-top:100px;'>");

out.println("<h2>Movie Ticket</h2>");
out.println("<p>Name: " + name + "</p>");
out.println("<p>Movie: " + movie + "</p>");
out.println("<p>Tickets: " + tickets + "</p>");
out.println("<p>Show Time: " + time + "</p>");

out.println("</body>");
out.println("</html>");
}
}""",
            "web.xml": """<web-app xmlns="http://xmlns.jcp.org/xml/ns/javaee"
version="3.1">

<servlet>
<servlet-name>MovieServlet</servlet-name>
<servlet-class>MovieServlet</servlet-class>
</servlet>

<servlet-mapping>
<servlet-name>MovieServlet</servlet-name>
<url-pattern>/movie</url-pattern>
</servlet-mapping>

<servlet>
<servlet-name>TicketServlet</servlet-name>
<servlet-class>TicketServlet</servlet-class>
</servlet>

<servlet-mapping>
<servlet-name>TicketServlet</servlet-name>
<url-pattern>/ticket</url-pattern>
</servlet-mapping>

</web-app>"""
        }
    },

    "6a": {
        "files": {
            "index.jsp": """<!DOCTYPE html>
<html>
<head>
<title>Online Exam Home</title>
</head>
<body>
<h2>Online Examination System</h2>
<a href="login.jsp">Student Login</a>
</body>
</html>""",
            "login.jsp": """<!DOCTYPE html>
<html>
<head>
<title>Login</title>
</head>
<body>
<h2>Student Login</h2>
<form action="login" method="post">
Register Number: <input type="text" name="regno" required><br><br>
Password: <input type="password" name="password" required><br><br>
<input type="submit" value="Login">
</form>
</body>
</html>""",
            "exam.jsp": """<%@ page import="java.sql.*" %>
<!DOCTYPE html>
<html>
<head>
<title>Exam</title>
</head>
<body>
<h2>Exam</h2>

<form action="submitExam" method="post">
<%
String regno = (String) session.getAttribute("regno");

if (regno == null) {
response.sendRedirect("login.jsp");
return;
}

Connection con = null;
Statement stmt = null;
ResultSet rs = null;

try {
Class.forName("com.mysql.cj.jdbc.Driver");
con = DriverManager.getConnection(
"jdbc:mysql://localhost:3306/webtechdb?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC",
"root",
"viswaa_gs"
);

stmt = con.createStatement();
rs = stmt.executeQuery("SELECT * FROM questions");

while (rs.next()) {
%>
<p>
<b><%= rs.getInt("qid") %>. <%= rs.getString("question") %></b><br>
<input type="radio" name="q<%= rs.getInt("qid") %>" value="<%= rs.getString("option1") %>" required> <%= rs.getString("option1") %><br>
<input type="radio" name="q<%= rs.getInt("qid") %>" value="<%= rs.getString("option2") %>"> <%= rs.getString("option2") %><br>
<input type="radio" name="q<%= rs.getInt("qid") %>" value="<%= rs.getString("option3") %>"> <%= rs.getString("option3") %><br>
<input type="radio" name="q<%= rs.getInt("qid") %>" value="<%= rs.getString("option4") %>"> <%= rs.getString("option4") %><br>
</p>
<%
}
} catch (Exception e) {
out.println("Error: " + e.getMessage());
} finally {
if (rs != null) try { rs.close(); } catch (Exception e) {}
if (stmt != null) try { stmt.close(); } catch (Exception e) {}
if (con != null) try { con.close(); } catch (Exception e) {}
}
%>

<input type="submit" value="Submit">
</form>
</body>
</html>""",
            "result.jsp": """<!DOCTYPE html>
<html>
<head>
<title>Result</title>
</head>
<body>
<h2>Exam Result</h2>

<%
String regno = (String) request.getAttribute("regno");
String name = (String) request.getAttribute("name");
Integer score = (Integer) request.getAttribute("score");
%>

<%
if (score != null) {
%>
<p><b>Register Number:</b> <%= regno %></p>
<p><b>Name:</b> <%= name %></p>
<p><b>Score:</b> <%= score %></p>
<%
} else {
%>
<p>No result available</p>
<%
}
%>

<br>
<a href="logout.jsp">Logout</a>
</body>
</html>""",
            "logout.jsp": """<%
session.invalidate();
response.sendRedirect("login.jsp");
%>""",
            "DBConnection.java": """import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
public static Connection getConnection() throws Exception {
Class.forName("com.mysql.cj.jdbc.Driver");
return DriverManager.getConnection(
"jdbc:mysql://localhost:3306/webtechdb?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC",
"root",
"viswaa_gs"
);
}
}""",
            "LoginServlet.java": """import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class LoginServlet extends HttpServlet {

protected void doPost(HttpServletRequest request, HttpServletResponse response)
throws ServletException, IOException {

String regno = request.getParameter("regno");
String password = request.getParameter("password");

try {
Connection con = DBConnection.getConnection();

PreparedStatement ps = con.prepareStatement(
"SELECT * FROM exam_students WHERE regno=? AND password=?"
);
ps.setString(1, regno);
ps.setString(2, password);

ResultSet rs = ps.executeQuery();

if (rs.next()) {
HttpSession session = request.getSession();
session.setAttribute("regno", regno);
response.sendRedirect("exam.jsp");
} else {
response.getWriter().println("Invalid login");
}

rs.close();
ps.close();
con.close();

} catch (Exception e) {
response.getWriter().println("Error: " + e.getMessage());
}
}
}""",
            "SubmitExamServlet.java": """import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class SubmitExamServlet extends HttpServlet {

protected void doPost(HttpServletRequest request, HttpServletResponse response)
throws ServletException, IOException {

HttpSession session = request.getSession(false);

if (session == null || session.getAttribute("regno") == null) {
response.sendRedirect("login.jsp");
return;
}

String regno = (String) session.getAttribute("regno");
int score = 0;

Connection con = null;
Statement stmt = null;
ResultSet rs = null;
PreparedStatement psInsert = null;
PreparedStatement psName = null;
ResultSet rsName = null;

try {
con = DBConnection.getConnection();

stmt = con.createStatement();
rs = stmt.executeQuery("SELECT qid, answer FROM questions");

while (rs.next()) {
int qid = rs.getInt("qid");
String correct = rs.getString("answer");
String user = request.getParameter("q" + qid);

if (correct != null && correct.equals(user)) {
score++;
}
}

psInsert = con.prepareStatement(
"INSERT INTO exam_results(regno, score) VALUES(?, ?)"
);
psInsert.setString(1, regno);
psInsert.setInt(2, score);
psInsert.executeUpdate();

String name = "";

psName = con.prepareStatement(
"SELECT name FROM exam_students WHERE regno=?"
);
psName.setString(1, regno);
rsName = psName.executeQuery();

if (rsName.next()) {
name = rsName.getString("name");
}

request.setAttribute("regno", regno);
request.setAttribute("name", name);
request.setAttribute("score", score);

request.getRequestDispatcher("result.jsp").forward(request, response);

} catch (Exception e) {
response.getWriter().println("Error: " + e.getMessage());
} finally {
try { if (rsName != null) rsName.close(); } catch (Exception e) {}
try { if (psName != null) psName.close(); } catch (Exception e) {}
try { if (rs != null) rs.close(); } catch (Exception e) {}
try { if (stmt != null) stmt.close(); } catch (Exception e) {}
try { if (psInsert != null) psInsert.close(); } catch (Exception e) {}
try { if (con != null) con.close(); } catch (Exception e) {}
}
}
}""",
            "web.xml": """<?xml version="1.0" encoding="UTF-8"?>
<web-app xmlns="https://jakarta.ee/xml/ns/jakartaee"
xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
xsi:schemaLocation="https://jakarta.ee/xml/ns/jakartaee
https://jakarta.ee/xml/ns/jakartaee/web-app_6_0.xsd"
version="6.0">

<servlet>
<servlet-name>LoginServlet</servlet-name>
<servlet-class>LoginServlet</servlet-class>
</servlet>

<servlet-mapping>
<servlet-name>LoginServlet</servlet-name>
<url-pattern>/login</url-pattern>
</servlet-mapping>

<servlet>
<servlet-name>SubmitExamServlet</servlet-name>
<servlet-class>SubmitExamServlet</servlet-class>
</servlet>

<servlet-mapping>
<servlet-name>SubmitExamServlet</servlet-name>
<url-pattern>/submitExam</url-pattern>
</servlet-mapping>

<welcome-file-list>
<welcome-file>index.jsp</welcome-file>
</welcome-file-list>

</web-app>"""
        }
    },

    "6b": {
        "files": {
            "index.jsp": """<!DOCTYPE html>
<html>
<head>
<title>Student Mark List Home</title>
</head>
<body>
<h2>Student Mark List System</h2>
<a href="search.jsp">Search Student Mark List</a>
</body>
</html>""",
            "marksheet.jsp": """<%@ page session="false" %>
<!DOCTYPE html>
<html>
<head>
<title>Student Mark Sheet</title>
</head>
<body>
<h2>Student Mark Sheet</h2>

<%
String regno = (String) request.getAttribute("regno");
String name = (String) request.getAttribute("name");
String dept = (String) request.getAttribute("dept");
Integer s1 = (Integer) request.getAttribute("subject1");
Integer s2 = (Integer) request.getAttribute("subject2");
Integer s3 = (Integer) request.getAttribute("subject3");
Integer s4 = (Integer) request.getAttribute("subject4");
Integer s5 = (Integer) request.getAttribute("subject5");
Integer total = (Integer) request.getAttribute("total");
Double average = (Double) request.getAttribute("average");
String resultStatus = (String) request.getAttribute("result_status");
%>

<%
if (regno != null) {
%>
<p>Register Number: <%= regno %></p>
<p>Name: <%= name %></p>
<p>Department: <%= dept %></p>

<table border="1" cellpadding="10">
<tr><th>Subject</th><th>Marks</th></tr>
<tr><td>Subject 1</td><td><%= s1 %></td></tr>
<tr><td>Subject 2</td><td><%= s2 %></td></tr>
<tr><td>Subject 3</td><td><%= s3 %></td></tr>
<tr><td>Subject 4</td><td><%= s4 %></td></tr>
<tr><td>Subject 5</td><td><%= s5 %></td></tr>
<tr><td>Total</td><td><%= total %></td></tr>
<tr><td>Average</td><td><%= average %></td></tr>
<tr><td>Result</td><td><%= resultStatus %></td></tr>
</table>
<%
} else {
%>
<p>No student record found.</p>
<%
}
%>
</body>
</html>""",
            "search.jsp": """<!DOCTYPE html>
<html>
<head>
<title>Search Student</title>
</head>
<body>
<h2>Enter Register Number</h2>
<form action="searchStudent" method="post">
Register Number: <input type="text" name="regno" required><br><br>
<input type="submit" value="Get Mark List">
</form>
</body>
</html>""",
            "DBConnection.java": """import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
public static Connection getConnection() throws Exception {
Class.forName("com.mysql.cj.jdbc.Driver");
return DriverManager.getConnection(
"jdbc:mysql://localhost:3306/webtechdb?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC",
"root",
"viswaa_gs"
);
}
}""",
            "SearchStudentServlet.java": """import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class SearchStudentServlet extends HttpServlet {

protected void doPost(HttpServletRequest request, HttpServletResponse response)
throws ServletException, IOException {

String regno = request.getParameter("regno");

try {
Connection con = DBConnection.getConnection();

String query = "SELECT si.regno, si.name, si.dept, sm.subject1, sm.subject2, sm.subject3, sm.subject4, sm.subject5, sm.total, sm.average, sm.result_status "
+ "FROM student_info si JOIN student_marks sm ON si.regno = sm.regno WHERE si.regno = ?";

PreparedStatement ps = con.prepareStatement(query);
ps.setString(1, regno);

ResultSet rs = ps.executeQuery();

if (rs.next()) {
request.setAttribute("regno", rs.getString("regno"));
request.setAttribute("name", rs.getString("name"));
request.setAttribute("dept", rs.getString("dept"));
request.setAttribute("subject1", rs.getInt("subject1"));
request.setAttribute("subject2", rs.getInt("subject2"));
request.setAttribute("subject3", rs.getInt("subject3"));
request.setAttribute("subject4", rs.getInt("subject4"));
request.setAttribute("subject5", rs.getInt("subject5"));
request.setAttribute("total", rs.getInt("total"));
request.setAttribute("average", rs.getDouble("average"));
request.setAttribute("result_status", rs.getString("result_status"));
}

rs.close();
ps.close();
con.close();

request.getRequestDispatcher("marksheet.jsp").forward(request, response);

} catch (Exception e) {
response.getWriter().println("Error: " + e.getMessage());
}
}
}""",
            "web.xml": """<?xml version="1.0" encoding="UTF-8"?>
<web-app xmlns="https://jakarta.ee/xml/ns/jakartaee"
xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
xsi:schemaLocation="https://jakarta.ee/xml/ns/jakartaee
https://jakarta.ee/xml/ns/jakartaee/web-app_6_0.xsd"
version="6.0">

<servlet>
<servlet-name>SearchStudentServlet</servlet-name>
<servlet-class>SearchStudentServlet</servlet-class>
</servlet>

<servlet-mapping>
<servlet-name>SearchStudentServlet</servlet-name>
<url-pattern>/searchStudent</url-pattern>
</servlet-mapping>

<welcome-file-list>
<welcome-file>index.jsp</welcome-file>
</welcome-file-list>

</web-app>"""
        }
    },

    "7a": {
        "files": {
            "book.xml": """<?xml version="1.0"?>
<book xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
xsi:noNamespaceSchemaLocation="book.xsd">
<title>Python Basics</title>
<author>Ravi Kumar</author>
<price>450</price>
</book>""",
            "book.xsd": """<?xml version="1.0"?>
<xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema">
<xs:element name="book">
<xs:complexType>
<xs:sequence>
<xs:element name="title" type="xs:string"/>
<xs:element name="author" type="xs:string"/>
<xs:element name="price" type="xs:int"/>
</xs:sequence>
</xs:complexType>
</xs:element>
</xs:schema>"""
        }
    },

    "7b": {
        "files": {
            "book.xml": """<?xml version="1.0"?>
<?xml-stylesheet type="text/xsl" href="book.xsl"?>
<book>
<title>Python Basics</title>
<author>Ravi Kumar</author>
<price>450</price>
</book>""",
            "book.xsl": """<?xml version="1.0"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0">
<xsl:template match="/">
<html>
<body>
<h2>Book Details</h2>
<p>Title: <xsl:value-of select="book/title"/></p>
<p>Author: <xsl:value-of select="book/author"/></p>
<p>Price: <xsl:value-of select="book/price"/></p>
</body>
</html>
</xsl:template>
</xsl:stylesheet>"""
        }
    },

    "8": {
        "files": {
            "index.html": """<!DOCTYPE html>
<html>
<head>
<title>Employee Management System</title>
</head>
<body>
<h2>Employee Management System</h2>

<form action="EmployeeCRUDServlet" method="post">
ID: <input type="text" name="id"><br><br>
Name: <input type="text" name="name"><br><br>
Salary: <input type="text" name="salary"><br><br>

<button type="submit" name="action" value="insert">Insert</button>
<button type="submit" name="action" value="update">Update</button>
<button type="submit" name="action" value="delete">Delete</button>
<button type="submit" name="action" value="view">View</button>
</form>
</body>
</html>""",
            "EmployeeCRUDServlet.java": """import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.sql.*;

public class EmployeeCRUDServlet extends HttpServlet {

Connection con;

public void init() throws ServletException {
try {
Class.forName("com.mysql.cj.jdbc.Driver");
con = DriverManager.getConnection(
"jdbc:mysql://localhost:3306/company",
"root",
"viswaa_gs"   // change password if needed
);
} catch (Exception e) {
System.out.println(e);
}
}

protected void doPost(HttpServletRequest request, HttpServletResponse response)
throws ServletException, IOException {

response.setContentType("text/html");
PrintWriter out = response.getWriter();

String action = request.getParameter("action");

try {
if (action.equals("insert")) {
int id = Integer.parseInt(request.getParameter("id"));
String name = request.getParameter("name");
float salary = Float.parseFloat(request.getParameter("salary"));

PreparedStatement ps = con.prepareStatement(
"INSERT INTO employee VALUES (?, ?, ?)"
);
ps.setInt(1, id);
ps.setString(2, name);
ps.setFloat(3, salary);
ps.executeUpdate();

out.println("<h3>Inserted Successfully</h3>");
}
else if (action.equals("update")) {
int id = Integer.parseInt(request.getParameter("id"));
String name = request.getParameter("name");
float salary = Float.parseFloat(request.getParameter("salary"));

PreparedStatement ps = con.prepareStatement(
"UPDATE employee SET name=?, salary=? WHERE id=?"
);
ps.setString(1, name);
ps.setFloat(2, salary);
ps.setInt(3, id);
ps.executeUpdate();

out.println("<h3>Updated Successfully</h3>");
}
else if (action.equals("delete")) {
int id = Integer.parseInt(request.getParameter("id"));

PreparedStatement ps = con.prepareStatement(
"DELETE FROM employee WHERE id=?"
);
ps.setInt(1, id);
ps.executeUpdate();

out.println("<h3>Deleted Successfully</h3>");
}
else if (action.equals("view")) {
Statement st = con.createStatement();
ResultSet rs = st.executeQuery("SELECT * FROM employee");

out.println("<h2>Employee Records</h2>");
out.println("<table border='1'>");
out.println("<tr><th>ID</th><th>Name</th><th>Salary</th></tr>");

while (rs.next()) {
out.println("<tr>");
out.println("<td>" + rs.getInt(1) + "</td>");
out.println("<td>" + rs.getString(2) + "</td>");
out.println("<td>" + rs.getFloat(3) + "</td>");
out.println("</tr>");
}

out.println("</table>");
}

out.println("<br><a href='index.html'>Back</a>");

} catch (Exception e) {
out.println("Error: " + e);
}
}

public void destroy() {
try {
if (con != null) {
con.close();
}
} catch (Exception e) {}
}
}""",
            "web.xml": """<web-app xmlns="https://jakarta.ee/xml/ns/jakartaee"
xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
xsi:schemaLocation="https://jakarta.ee/xml/ns/jakartaee
https://jakarta.ee/xml/ns/jakartaee/web-app_6_0.xsd"
version="6.0">

<servlet>
<servlet-name>EmployeeCRUDServlet</servlet-name>
<servlet-class>EmployeeCRUDServlet</servlet-class>
</servlet>

<servlet-mapping>
<servlet-name>EmployeeCRUDServlet</servlet-name>
<url-pattern>/EmployeeCRUDServlet</url-pattern>
</servlet-mapping>

<welcome-file-list>
<welcome-file>index.html</welcome-file>
</welcome-file-list>

</web-app>""",
            "database.sql": """CREATE DATABASE company;

USE company;

CREATE TABLE employee (
id INT PRIMARY KEY,
name VARCHAR(50),
salary FLOAT
);"""
        }
    }
}