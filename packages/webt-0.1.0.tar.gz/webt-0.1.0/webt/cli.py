import sys
import os
from webt.data import QUESTIONS


def create_files(qno):
    if qno not in QUESTIONS:
        print("❌ Question not found")
        return

    folder = f"question_{qno}"
    os.makedirs(folder, exist_ok=True)

    for filename, content in QUESTIONS[qno]["files"].items():
        path = os.path.join(folder, filename)
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)

    print(f"✅ Created {folder} with files!")


def main():
    if len(sys.argv) < 3:
        print("Usage: webt get <number>")
        return

    command = sys.argv[1]

    if command == "get":
        qno = sys.argv[2]
        create_files(qno)
    else:
        print("Unknown command")