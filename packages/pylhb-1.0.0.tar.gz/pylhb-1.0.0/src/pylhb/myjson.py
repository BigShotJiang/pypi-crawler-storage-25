"""
模块：myjson
作者：李生
描述：JOSN读写
"""
import json

class MyJSON:
    """JSON读写"""
    def __init__(self,jsonFile="config.json") -> None:
        self.jsonFile=jsonFile
        
    def getKey(self,key):
        """
        获取Key
        param key:Key
        return：此key的数据
        """
        with open(self.jsonFile,'r', encoding="utf-8") as f:
            configs=json.load(f)
        return configs[key]
    
    def setKey(self,key,value):
        """
        设置Key
        param key：key
        param value：值
        """
        # 读取
        with open(self.jsonFile,'r', encoding="utf-8") as f:
            configs=json.load(f)
        # 设置参数
        configs[key]=value
        # 保存
        with open(self.jsonFile, 'w', encoding="utf-8") as f:
            json.dump(configs, f)
