"""Public Python API for mWinPy.

The package exports thin Python bindings over a native Windows extension module.
"""

from ._mWinPy import Process, Processes


__all__ = [
    "Process",
    "Processes"
]