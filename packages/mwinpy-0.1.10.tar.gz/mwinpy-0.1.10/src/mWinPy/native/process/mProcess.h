#pragma once
#include <Windows.h>

// predefine: process_t
typedef struct process_t process_t;

// vtable
typedef struct {
        void (*destroy)(process_t *self);
}process_vtable_t;

// object: process_t
typedef struct process_t {
        process_vtable_t *vtable;
        LPCWSTR name;
        DWORD pid;
        HANDLE hProcess;
}process_t;

// public functions
void getProcess(process_t *self);
void destroyProcess(process_t *self);