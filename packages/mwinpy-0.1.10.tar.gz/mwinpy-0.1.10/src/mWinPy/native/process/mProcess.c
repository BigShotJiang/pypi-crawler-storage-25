#include "mProcess.h"
#include <stdlib.h>
#include <Psapi.h> //https://learn.microsoft.com/de-de/windows/win32/psapi/psapi-reference


// ------ fill vtable ---

static void v_destroy_process(process_t *proc) {

        if (proc->hProcess) {
                CloseHandle(proc->hProcess);
                proc->hProcess = NULL;
        }

}

static process_vtable_t v_process_vtable = {
        .destroy = v_destroy_process,
};

// ------ public ---

void getProcess(process_t *self) {
        self->vtable = &v_process_vtable;
        self->pid = GetCurrentProcessId();
        self->hProcess = OpenProcess(
                PROCESS_QUERY_INFORMATION | PROCESS_VM_READ,
                FALSE,
                self->pid
        );
}

void destroyProcess(process_t *self) {
        if (self->vtable && self->vtable->destroy) {
                self->vtable->destroy(self);
        }
}