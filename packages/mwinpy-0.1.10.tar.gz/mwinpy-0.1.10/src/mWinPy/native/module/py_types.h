#pragma once

#define PY_SSIZE_T_CLEAN
#include <Python.h>

#include "process/mProcess.h"
#include "processes/mProcesses.h"

// ================================================================ PyProcess

typedef struct {
        PyObject_HEAD
        process_t *proc;
} PyProcess;

typedef struct {
        PyObject_HEAD
} PyProcesses;

extern PyTypeObject PyProcessType;
extern PyTypeObject PyProcessesType;