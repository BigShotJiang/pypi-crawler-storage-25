#include "module/py_types.h"
#include <stdlib.h>

// ---------------------------------------------------------------- methods --

static PyObject *PyProcesses_getAllProcessesIDs(PyProcesses *self, PyObject* args, PyObject* kw) {

        DWORD count = 1024;
        static char *kwlist[] = {"count", NULL};

        if (!PyArg_ParseTupleAndKeywords(args, kw, "|k", kwlist, &count)) {
                return NULL;
        }
        if (count <= 0) {
                PyErr_SetString(PyExc_ValueError, "count must be a positive integer");
                return NULL;
        }

        DWORD *pids = getAllProcessesIDs(&count);
        if (!pids) {
                PyErr_SetString(PyExc_RuntimeError, "Failed to get process IDs");
                return NULL;
        }

        PyObject *list = PyList_New(count);
        if (!list) {
                free(pids);
                return NULL;
        }

        for (DWORD i = 0; i < count; i++) {
                PyObject *pid = PyLong_FromUnsignedLong(pids[i]);
                if (!pid) {
                        Py_DECREF(list);
                        free(pids);
                        return NULL;
                }
                PyList_SET_ITEM(list, i, pid); // steals reference
        }

        free(pids);
        return list;
}

static PyMethodDef PyProcesses_methods[] = {
        {
                "getAllProcessesIDs",
                (PyCFunction)(void(*)(void))PyProcesses_getAllProcessesIDs,
                METH_VARARGS | METH_KEYWORDS | METH_CLASS,
                "getAllProcessesIDs(count=...) -> list[int]\nReturns all Process IDs of all Process Objects on the system."
        },
        {NULL}
};

PyTypeObject PyProcessesType = {
        PyVarObject_HEAD_INIT(NULL, 0)
};

PyTypeObject PyProcessesesType = {
        PyVarObject_HEAD_INIT(NULL, 0)
        .tp_name      = "_mWinPy.Processes",
        .tp_doc       = "Providing access to the Processes on the System.",
        .tp_basicsize = sizeof(PyProcesses),
        .tp_flags     = Py_TPFLAGS_DEFAULT | Py_TPFLAGS_BASETYPE,
        .tp_new       = PyType_GenericNew,
        .tp_methods   = PyProcesses_methods,
    };