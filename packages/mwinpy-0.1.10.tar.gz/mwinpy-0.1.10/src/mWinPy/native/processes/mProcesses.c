#include "mProcesses.h"
#include <stdlib.h>
#include <Psapi.h> //https://learn.microsoft.com/de-de/windows/win32/psapi/psapi-reference

DWORD *getAllProcessesIDs(DWORD *count) {
        DWORD capacity = 1024;
        DWORD *processes = (DWORD *)malloc(capacity * sizeof(DWORD));
        DWORD bytesNeeded = 0;

        if (!processes) {
                return NULL;
        }

        if (!EnumProcesses(processes, capacity*sizeof(DWORD), &bytesNeeded)) {
                free(processes);
                return NULL;
        }

        *count = bytesNeeded / sizeof(DWORD);
        return processes;

}