#pragma once
#include <Windows.h>

// public functions
DWORD *getAllProcessesIDs(DWORD *count);