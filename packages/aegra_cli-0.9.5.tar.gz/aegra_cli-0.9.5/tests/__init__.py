"""Tests for aegra-cli."""
