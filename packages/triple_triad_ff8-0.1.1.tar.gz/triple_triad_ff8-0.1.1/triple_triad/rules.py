# Game rules and capture logic

OPPOSITE = {'top': 'bottom', 'bottom': 'top', 'left': 'right', 'right': 'left'}


def get_attacker_value(card, direction):
    return getattr(card, direction)


def get_defender_value(card, direction):
    return getattr(card, OPPOSITE[direction])


def resolve_captures(board, pos, placed_card, rules):
    """Apply basic capture logic (and Same/Plus if enabled)."""
    captures = []
    neighbors = board.get_neighbors(pos)

    same_candidates = []
    plus_candidates = []

    for direction, (npos, ncard) in neighbors.items():
        if ncard is None or ncard.owner == placed_card.owner:
            continue
        atk = get_attacker_value(placed_card, direction)
        dfn = get_defender_value(ncard, direction)

        # Basic capture
        if atk > dfn:
            captures.append((npos, ncard))

        # Same rule tracking
        if 'Same' in rules and atk == dfn:
            same_candidates.append((npos, ncard))

        # Plus rule tracking
        if 'Plus' in rules:
            plus_candidates.append((npos, ncard, atk + dfn))

    # Same rule: if 2+ neighbors have equal values
    if 'Same' in rules and len(same_candidates) >= 2:
        print("  *** SAME! ***")
        for npos, ncard in same_candidates:
            if (npos, ncard) not in captures:
                captures.append((npos, ncard))

    # Plus rule: if 2+ neighbors share the same sum
    if 'Plus' in rules and len(plus_candidates) >= 2:
        sums = [x[2] for x in plus_candidates]
        for s in set(sums):
            matching = [x for x in plus_candidates if x[2] == s]
            if len(matching) >= 2:
                print("  *** PLUS! ***")
                for npos, ncard, _ in matching:
                    if (npos, ncard) not in captures:
                        captures.append((npos, ncard))

    return captures


def simulate_capture(board, pos, card, owner, rules):
    """
    Calculate captures for a hypothetical move without modifying state.
    
    This is a stateless simulation used by the AI to evaluate moves
    without the overhead of deepcopying board and card objects.
    
    Args:
        board: The current Board object (read-only)
        pos: Position to simulate placing at (0-8)
        card: Card object with top/right/bottom/left attributes
        owner: The owner of the placed card ('P' or 'CPU')
        rules: List of active rules
    
    Returns:
        int: Number of cards that would be captured
    """
    captures = 0
    neighbors = board.get_neighbors(pos)
    
    same_candidates = []
    plus_candidates = []
    
    for direction, (npos, ncard) in neighbors.items():
        if ncard is None or ncard.owner == owner:
            continue
        
        atk = get_attacker_value(card, direction)
        dfn = get_defender_value(ncard, direction)
        
        # Basic capture
        if atk > dfn:
            captures += 1
        
        # Same rule tracking
        if 'Same' in rules and atk == dfn:
            same_candidates.append((npos, ncard))
        
        # Plus rule tracking
        if 'Plus' in rules:
            plus_candidates.append((npos, ncard, atk + dfn))
    
    # Same rule: if 2+ neighbors have equal values
    if 'Same' in rules and len(same_candidates) >= 2:
        for npos, ncard in same_candidates:
            # Count unique captures
            captures += 1
    
    # Plus rule: if 2+ neighbors share the same sum
    if 'Plus' in rules and len(plus_candidates) >= 2:
        sums = [x[2] for x in plus_candidates]
        for s in set(sums):
            matching = [x for x in plus_candidates if x[2] == s]
            if len(matching) >= 2:
                captures += len(matching)
    
    return captures
