from triple_triad.game import main

if __name__ == "__main__":
    main()