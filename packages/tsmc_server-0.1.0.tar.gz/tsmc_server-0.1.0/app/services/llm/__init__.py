"""LLM client abstractions."""

