"""API and internal schemas."""

