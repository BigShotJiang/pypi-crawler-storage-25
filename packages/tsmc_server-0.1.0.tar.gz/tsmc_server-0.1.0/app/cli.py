from __future__ import annotations

import argparse
import json
import shutil
import sys
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path

from app.cli_config import (
    CLIConfig,
    apply_runtime_environment,
    default_cli_config,
    ensure_cli_directories,
    ensure_env_file,
    load_cli_config,
    merge_cli_config,
    save_cli_config,
)
from app.cli_paths import CLIPaths, default_cli_paths
from app.cli_service import (
    daemon_reload,
    ensure_systemd_user_available,
    get_service_status,
    maybe_warn_about_linger,
    port_is_open,
    service_control,
    stream_service_logs,
    write_systemd_unit,
)


PACKAGE_NAME = "tsmc-server"


def package_version() -> str:
    try:
        return version(PACKAGE_NAME)
    except PackageNotFoundError:
        return "0.0.0"


def resolve_cli_paths(config_path: Path | None = None) -> CLIPaths:
    defaults = default_cli_paths()
    if config_path is None:
        return defaults

    resolved_config_path = config_path.expanduser().resolve()
    return CLIPaths(
        config_dir=resolved_config_path.parent,
        config_path=resolved_config_path,
        env_path=resolved_config_path.parent / "tsmc.env",
        data_dir=defaults.data_dir,
        markdown_dir=defaults.markdown_dir,
        database_path=defaults.database_path,
        systemd_user_dir=defaults.systemd_user_dir,
        unit_path=defaults.unit_path,
    )


def load_effective_config(args: argparse.Namespace) -> tuple[CLIPaths, CLIConfig]:
    paths = resolve_cli_paths(getattr(args, "config", None))
    loaded = load_cli_config(paths.config_path, paths=paths)
    merged = merge_cli_config(
        loaded,
        host=getattr(args, "host", None),
        port=getattr(args, "port", None),
        data_dir=getattr(args, "data_dir", None),
        markdown_dir=getattr(args, "markdown_dir", None),
        public_url=getattr(args, "public_url", None),
    )
    return paths, merged


def print_kv(label: str, value: object) -> None:
    print(f"{label}: {value}")


def command_run(args: argparse.Namespace) -> int:
    paths, config = load_effective_config(args)
    ensure_cli_directories(config, paths)
    ensure_env_file(paths.env_path)
    apply_runtime_environment(config, paths.env_path)

    import uvicorn

    host = args.host or config.host
    port = args.port or config.port
    uvicorn.run("app.main:app", host=host, port=port, reload=False)
    return 0


def command_service_install(args: argparse.Namespace) -> int:
    ensure_systemd_user_available()
    paths, config = load_effective_config(args)
    effective_config = merge_cli_config(
        config,
        data_dir=args.data_dir or config.data_dir,
        markdown_dir=args.markdown_dir or config.markdown_dir,
    )

    ensure_cli_directories(effective_config, paths)
    save_cli_config(effective_config, paths.config_path)
    ensure_env_file(paths.env_path, force=args.force)
    write_systemd_unit(effective_config, paths, force=args.force)
    daemon_reload()

    if args.enable or args.start:
        service_control("enable", effective_config.service_name)
    if args.start:
        service_control("start", effective_config.service_name)

    print("TSMC service installed.")
    print_kv("Service", f"{effective_config.service_name}.service")
    print_kv("URL", f"http://{effective_config.host}:{effective_config.port}")
    print_kv("Config", paths.config_path)
    print_kv("Env", paths.env_path)
    print_kv("Data", effective_config.data_dir)
    print_kv("Markdown", effective_config.markdown_dir)
    print_kv("Database", effective_config.database_path)
    linger_warning = maybe_warn_about_linger()
    if linger_warning:
        print()
        print(linger_warning)
    return 0


def command_service_control(args: argparse.Namespace) -> int:
    paths = resolve_cli_paths(getattr(args, "config", None))
    config = load_cli_config(paths.config_path, paths=paths)
    ensure_systemd_user_available()
    service_control(args.action, config.service_name)
    print(f"{args.action.title()}ed {config.service_name}.service")
    return 0


def command_service_status(args: argparse.Namespace) -> int:
    paths = resolve_cli_paths(getattr(args, "config", None))
    config = load_cli_config(paths.config_path, paths=paths)
    status = get_service_status(config, config.service_name)
    print_kv("Service", f"{config.service_name}.service")
    print_kv("Systemd", status.systemd_state)
    print_kv("Enabled", "yes" if status.enabled else "no")
    print_kv("Health", "ok" if status.health_ok else f"failed ({status.health_status_code or status.health_error or 'unreachable'})")
    print_kv("Config", paths.config_path)
    print_kv("Env", paths.env_path)
    print_kv("Data", config.data_dir)
    print_kv("Markdown", config.markdown_dir)
    print_kv("Database", config.database_path)
    return 0 if status.active else 1


def command_service_logs(args: argparse.Namespace) -> int:
    paths = resolve_cli_paths(getattr(args, "config", None))
    config = load_cli_config(paths.config_path, paths=paths)
    return stream_service_logs(config.service_name, follow=args.follow, lines=args.lines, since=args.since)


def command_service_uninstall(args: argparse.Namespace) -> int:
    paths = resolve_cli_paths(getattr(args, "config", None))
    config = load_cli_config(paths.config_path, paths=paths)
    try:
        ensure_systemd_user_available()
        service_control("stop", config.service_name)
    except RuntimeError:
        pass
    try:
        service_control("disable", config.service_name)
    except RuntimeError:
        pass

    if paths.unit_path.exists():
        paths.unit_path.unlink()
        try:
            daemon_reload()
        except RuntimeError:
            pass

    if args.purge_data:
        if paths.config_dir.exists():
            shutil.rmtree(paths.config_dir)
        if config.data_dir.exists():
            shutil.rmtree(config.data_dir)
        print("Removed TSMC service, config, and data.")
        return 0

    print("Removed TSMC service. Config and data were kept.")
    print_kv("Config", paths.config_dir)
    print_kv("Data", config.data_dir)
    return 0


def command_doctor(args: argparse.Namespace) -> int:
    paths = resolve_cli_paths(getattr(args, "config", None))
    config = load_cli_config(paths.config_path, paths=paths)
    status = get_service_status(config, config.service_name)
    problems: list[str] = []

    if not shutil.which("systemctl"):
        problems.append("systemctl is not available.")
    if not paths.config_path.exists():
        problems.append(f"Config file is missing: {paths.config_path}")
    if not paths.env_path.exists():
        problems.append(f"Env file is missing: {paths.env_path}")
    if not config.data_dir.exists():
        problems.append(f"Data directory is missing: {config.data_dir}")
    if not config.markdown_dir.exists():
        problems.append(f"Markdown directory is missing: {config.markdown_dir}")
    if not status.active and port_is_open(config.host, config.port):
        problems.append(f"Port {config.port} is already open but {config.service_name}.service is not active.")

    print_kv("Service", f"{config.service_name}.service")
    print_kv("Health", "ok" if status.health_ok else f"failed ({status.health_status_code or status.health_error or 'unreachable'})")
    print_kv("Config", paths.config_path)
    print_kv("Markdown", config.markdown_dir)
    print_kv("Database", config.database_path)

    if problems:
        print()
        print("Problems:")
        for problem in problems:
            print(f"- {problem}")
        return 1

    print()
    print("No obvious problems found.")
    return 0


def command_config_show(args: argparse.Namespace) -> int:
    paths = resolve_cli_paths(getattr(args, "config", None))
    config = load_cli_config(paths.config_path, paths=paths)
    payload = {
        "server": {
            "host": config.host,
            "port": config.port,
            "public_url": config.public_url,
        },
        "storage": {
            "data_dir": str(config.data_dir),
            "markdown_dir": str(config.markdown_dir),
            "database_path": str(config.database_path),
        },
        "processing": {
            "llm_backend": config.llm_backend,
        },
        "service": {
            "name": config.service_name,
        },
    }
    print(json.dumps(payload, indent=2))
    return 0


def command_config_path(args: argparse.Namespace) -> int:
    paths = resolve_cli_paths(getattr(args, "config", None))
    config = load_cli_config(paths.config_path, paths=paths)
    print_kv("Config", paths.config_path)
    print_kv("Env", paths.env_path)
    print_kv("Unit", paths.unit_path)
    print_kv("Data", config.data_dir)
    print_kv("Markdown", config.markdown_dir)
    print_kv("Database", config.database_path)
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="tsmc", description="TSMC backend service manager")
    parser.add_argument("--config", type=Path, help="Path to the TSMC config.toml file.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    run_parser = subparsers.add_parser("run", help="Run the TSMC backend in the foreground.")
    run_parser.add_argument("--host")
    run_parser.add_argument("--port", type=int)
    run_parser.add_argument("--data-dir", type=Path)
    run_parser.add_argument("--markdown-dir", type=Path)
    run_parser.set_defaults(func=command_run)

    service_parser = subparsers.add_parser("service", help="Manage the TSMC background service.")
    service_subparsers = service_parser.add_subparsers(dest="service_command", required=True)

    install_parser = service_subparsers.add_parser("install", help="Install the TSMC systemd user service.")
    install_parser.add_argument("--start", action="store_true")
    install_parser.add_argument("--enable", action="store_true")
    install_parser.add_argument("--host")
    install_parser.add_argument("--port", type=int)
    install_parser.add_argument("--data-dir", type=Path)
    install_parser.add_argument("--markdown-dir", type=Path)
    install_parser.add_argument("--public-url")
    install_parser.add_argument("--force", action="store_true")
    install_parser.set_defaults(func=command_service_install)

    for action in ["start", "stop", "restart"]:
        action_parser = service_subparsers.add_parser(action, help=f"{action.title()} the TSMC service.")
        action_parser.set_defaults(func=command_service_control, action=action)

    status_parser = service_subparsers.add_parser("status", help="Show TSMC service status.")
    status_parser.set_defaults(func=command_service_status)

    logs_parser = service_subparsers.add_parser("logs", help="Show TSMC service logs.")
    logs_parser.add_argument("-f", "--follow", action="store_true")
    logs_parser.add_argument("-n", "--lines", type=int, default=100)
    logs_parser.add_argument("--since")
    logs_parser.set_defaults(func=command_service_logs)

    uninstall_parser = service_subparsers.add_parser("uninstall", help="Uninstall the TSMC service.")
    uninstall_parser.add_argument("--purge-data", action="store_true")
    uninstall_parser.set_defaults(func=command_service_uninstall)

    doctor_parser = subparsers.add_parser("doctor", help="Run basic health checks.")
    doctor_parser.set_defaults(func=command_doctor)

    config_parser = subparsers.add_parser("config", help="Inspect TSMC configuration.")
    config_subparsers = config_parser.add_subparsers(dest="config_command", required=True)
    config_show_parser = config_subparsers.add_parser("show", help="Show effective config.")
    config_show_parser.set_defaults(func=command_config_show)
    config_path_parser = config_subparsers.add_parser("path", help="Show important config and data paths.")
    config_path_parser.set_defaults(func=command_config_path)

    version_parser = subparsers.add_parser("version", help="Show the installed TSMC version.")
    version_parser.set_defaults(func=lambda _args: print(package_version()) or 0)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
