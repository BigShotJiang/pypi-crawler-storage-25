"""Core application helpers."""

