# REST API — Core Concepts

This section covers the foundational patterns for working with any django-mojo REST API:

- [Frontend Starter](../frontend_starter.md) — Practical client bootstrap for auth/session handling
- [Authentication](authentication.md) — How to authenticate requests
- [Request & Response Format](request_response.md) — Data formats, envelopes, errors
- [Filtering, Searching & Sorting](filtering.md) — Query parameters for lists
- [Pagination](pagination.md) — Paging through results
- [Graphs](graphs.md) — Selecting response shapes
- [Aggregation](aggregation.md) — `_mode=count|top|distinct|summary|histogram` on every list endpoint
