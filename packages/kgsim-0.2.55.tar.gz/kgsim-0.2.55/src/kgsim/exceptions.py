"""a collection of all the kgsim exception types"""

class SimulationNotFoundError(Exception):
    """you tried to init a simulation that doesn't exist"""

class SimulationHasNotRunError(Exception):
    """this simulation hasn't been run yet"""