"""Thread-safe pool of Playwright browser instances.

Usage (context manager — recommended):
    from aibrain.core.browser_pool import get_pool

    with get_pool().checkout() as browser:
        page = browser.new_page()
        ...

Usage (manual checkout/checkin):
    pool = get_pool()
    browser = pool.checkout(timeout=30)
    try:
        ...
    finally:
        pool.checkin(browser)

Playwright is imported lazily so this module is safe to import even when
playwright is not installed — errors only appear at checkout time.
"""

import contextlib
import queue
import threading

_singleton = None
_singleton_lock = threading.Lock()


def _launch_browser(launch_kwargs: dict):
    """Launch a single chromium browser. Playwright imported here (lazy)."""
    from playwright.sync_api import sync_playwright  # noqa: PLC0415

    pw = sync_playwright().start()
    browser = pw.chromium.launch(**launch_kwargs)
    # Attach the playwright context so we can stop it on shutdown.
    browser._pw_ctx = pw  # type: ignore[attr-defined]
    return browser


def _close_browser(browser) -> None:
    try:
        browser.close()
    except Exception:
        pass
    pw = getattr(browser, "_pw_ctx", None)
    if pw is not None:
        try:
            pw.stop()
        except Exception:
            pass


class _CheckoutContext:
    """Returned by BrowserPool.checkout() when used as a context manager."""

    def __init__(self, pool: "BrowserPool", browser):
        self._pool = pool
        self._browser = browser

    def __enter__(self):
        return self._browser

    def __exit__(self, *_):
        self._pool.checkin(self._browser)


class BrowserPool:
    """Thread-safe pool of sync Playwright chromium browsers.

    Args:
        size: Number of browser instances to keep in the pool.
        launch_kwargs: Extra keyword arguments passed to chromium.launch().
    """

    def __init__(self, size: int = 3, **launch_kwargs):
        self._size = size
        self._launch_kwargs = launch_kwargs
        self._pool: queue.Queue = queue.Queue(maxsize=size)
        self._all: list = []
        self._lock = threading.Lock()
        self._initialized = False
        self._closed = False

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _ensure_initialized(self) -> None:
        """Lazily create all browser instances on first checkout."""
        if self._initialized:
            return
        with self._lock:
            if self._initialized:
                return
            for _ in range(self._size):
                browser = _launch_browser(self._launch_kwargs)
                self._all.append(browser)
                self._pool.put(browser)
            self._initialized = True

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def checkout(self, timeout: float = 30) -> "_CheckoutContext":
        """Checkout a browser from the pool.

        Blocks until one is available or *timeout* seconds elapse.

        Returns a context manager:
            with pool.checkout() as browser:
                ...  # browser auto-checked-in on exit

        Or call .checkout() and use the returned context object's
        _browser attribute if you need manual control — but the context
        manager pattern is strongly preferred.

        Raises:
            TimeoutError: No browser became available within *timeout* seconds.
            RuntimeError: Pool has been shut down.
        """
        if self._closed:
            raise RuntimeError("BrowserPool has been shut down")
        self._ensure_initialized()
        try:
            browser = self._pool.get(timeout=timeout)
        except queue.Empty:
            raise TimeoutError(
                f"No browser available after {timeout}s — all {self._size} instances busy"
            )
        return _CheckoutContext(self, browser)

    def checkin(self, browser_or_ctx) -> None:
        """Return a browser (or _CheckoutContext) to the pool.

        Accepts either the raw browser object or the _CheckoutContext
        returned by checkout().  If the pool is shut down the browser
        is closed instead.
        """
        browser = (
            browser_or_ctx._browser
            if isinstance(browser_or_ctx, _CheckoutContext)
            else browser_or_ctx
        )
        if self._closed:
            _close_browser(browser)
            return
        try:
            self._pool.put_nowait(browser)
        except queue.Full:
            # Should not happen under normal use, but close gracefully.
            _close_browser(browser)

    def shutdown(self) -> None:
        """Close all browsers and mark the pool as shut down."""
        self._closed = True
        for browser in self._all:
            _close_browser(browser)
        self._all.clear()
        # Drain the queue so any waiting threads unblock with an error.
        while not self._pool.empty():
            try:
                self._pool.get_nowait()
            except queue.Empty:
                break

    @property
    def size(self) -> int:
        return self._size

    # Allow `with pool.checkout() as browser:` directly on the pool.
    # (checkout() already returns a context manager, this is just documentation.)


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------

def get_pool(size: int = 3, **launch_kwargs) -> BrowserPool:
    """Return the shared module-level BrowserPool, creating it if needed.

    Args:
        size: Pool size — only used when creating the pool for the first time.
        **launch_kwargs: Passed to chromium.launch() — only used on first call.
    """
    global _singleton
    if _singleton is None:
        with _singleton_lock:
            if _singleton is None:
                _singleton = BrowserPool(size=size, **launch_kwargs)
    return _singleton
