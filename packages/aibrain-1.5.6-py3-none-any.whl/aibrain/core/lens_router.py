"""
lens_router.py — SelRoute v3 lens selection for the SuperWorker.

Maps a task description / task_type to the relevant subset of the lens
registry, plus always-on safety lenses.

v1.4 refactor (2026-04-11): the lens data moved to `lenses_public.py`
(public floor, ships on PyPI). This module now carries:

  * `_load_overlay()` — looks up a private `lens_overlay.py` from
    `decker_system/02_subagents/` and merges it INTO the public floor.
    Overlay keys REPLACE public keys entirely (Q4 decision).
  * Tier-aware `route()` — takes an optional `tier` parameter and filters
    to the lenses available at that tier. When a natural best-match lens
    is above the caller's tier, route() silently picks the best available
    in-tier lens AND returns an `upgrade_notice` explaining what Pro adds.
  * Honest-rubric fallback — no warnings when the overlay is missing.
    Free-tier users never know it existed.

Resolution order for the overlay root (Q3 decision — mirrors
`aibrain_db._resolve_root`):

  1. `~/.aibrainrc` key `decker_system_root`
  2. `DECKER_SYSTEM_ROOT` env var
  3. `%USERPROFILE%/decker_system` (Windows default)
  4. `~/decker_system` (POSIX default)

See `tmp/design_lens_split_v14.md` for the full design.
"""
from __future__ import annotations

import importlib.util
import logging
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

from aibrain.core.lenses_public import (
    ALWAYS_ON_LENSES as _PUBLIC_ALWAYS_ON,
    LENSES as _PUBLIC_LENSES,
    TASK_TYPE_LENSES as _PUBLIC_TASK_TYPE_LENSES,
    TIER_LENSES,
    tier_allowed_lenses,
)

log = logging.getLogger("aibrain.lens_router")


# ---------------------------------------------------------------------------
# Overlay loading
# ---------------------------------------------------------------------------

def _read_aibrainrc_key(key: str) -> Optional[str]:
    """Read a ``key=value`` line from ``~/.aibrainrc``.

    Backwards compatible with the single-line canonical-DB sentinel
    format: line 1 is the aibrain root path, subsequent ``key=value``
    lines are parsed by this helper.
    """
    sentinel = Path.home() / ".aibrainrc"
    if not sentinel.exists():
        return None
    try:
        lines = sentinel.read_text(encoding="utf-8").splitlines()
    except Exception:
        return None
    for line in lines[1:]:  # skip the aibrain-root line
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, _, v = line.partition("=")
        if k.strip() == key:  # noqa: secret-compare — config key name, not a secret
            return v.strip() or None
    return None


def _resolve_overlay_root() -> Optional[Path]:
    """Resolve the decker_system directory per Q3 decision.

    Lookup order:
      1. ``AIBRAIN_DISABLE_OVERLAY=1`` → force public-only mode (tests)
      2. ``~/.aibrainrc`` key ``decker_system_root``
      3. ``DECKER_SYSTEM_ROOT`` env var
      4. ``%USERPROFILE%/decker_system``  (Windows default)
      5. ``~/decker_system``              (POSIX default)

    Returns ``None`` when no overlay is discoverable — the public floor
    runs clean with no warnings.
    """
    # 0. Escape hatch for tests and CI public-only mode
    if os.environ.get("AIBRAIN_DISABLE_OVERLAY") == "1":
        return None

    # 1. ~/.aibrainrc key
    root = _read_aibrainrc_key("decker_system_root")
    if root:
        p = Path(root).expanduser()
        if p.exists():
            return p

    # 2. DECKER_SYSTEM_ROOT env var
    env_root = os.environ.get("DECKER_SYSTEM_ROOT")
    if env_root:
        p = Path(env_root).expanduser()
        if p.exists():
            return p

    # 3. Platform defaults (graceful degrade — returns None if absent)
    candidates = []
    userprofile = os.environ.get("USERPROFILE")
    if userprofile:
        candidates.append(Path(userprofile) / "decker_system")
    candidates.append(Path.home() / "decker_system")
    for c in candidates:
        if c.exists():
            return c

    return None


def _load_overlay() -> tuple[dict, dict, list, dict]:
    """Return (lenses, task_type_lenses, always_on, agent_router_defaults).

    Empty values on any failure. Overlay is strictly additive / replacing
    at same-key level — missing file = public floor runs alone, no warning.
    """
    root = _resolve_overlay_root()
    if root is None:
        return {}, {}, [], {}

    overlay_file = root / "02_subagents" / "lens_overlay.py"
    if not overlay_file.exists():
        return {}, {}, [], {}

    try:
        spec = importlib.util.spec_from_file_location(
            "_aibrain_lens_overlay", str(overlay_file)
        )
        if spec is None or spec.loader is None:
            return {}, {}, [], {}
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)  # type: ignore[union-attr]
    except Exception as e:
        # Loud error only if Decker explicitly wants one
        if os.environ.get("AIBRAIN_REQUIRE_OVERLAY"):
            raise
        log.debug("lens overlay load failed silently: %s", e)
        return {}, {}, [], {}

    return (
        dict(getattr(mod, "OVERLAY_LENSES", {}) or {}),
        dict(getattr(mod, "OVERLAY_TASK_TYPE_LENSES", {}) or {}),
        list(getattr(mod, "OVERLAY_ALWAYS_ON", []) or []),
        dict(getattr(mod, "OVERLAY_AGENT_ROUTER_DEFAULTS", {}) or {}),
    )


# ---------------------------------------------------------------------------
# Module-level merged registry (loaded once at import)
# ---------------------------------------------------------------------------

(
    _OVERLAY_LENSES,
    _OVERLAY_TASK_TYPE_LENSES,
    _OVERLAY_ALWAYS_ON,
    OVERLAY_AGENT_ROUTER_DEFAULTS,
) = _load_overlay()

_OVERLAY_LOADED: bool = bool(_OVERLAY_LENSES or _OVERLAY_ALWAYS_ON)

# Merge: overlay keys REPLACE public floor keys entirely (Q4).
LENSES: dict[str, dict] = {**_PUBLIC_LENSES, **_OVERLAY_LENSES}

# TASK_TYPE_LENSES merge: overlay list fully replaces the public list for
# that task_type. Overlay author is responsible for preserving any public
# entries they still want.
TASK_TYPE_LENSES: dict[str, list[str]] = {**_PUBLIC_TASK_TYPE_LENSES}
for _tt, _lst in _OVERLAY_TASK_TYPE_LENSES.items():
    TASK_TYPE_LENSES[_tt] = list(_lst)

# Always-on lenses: overlay replaces public floor entirely if present.
ALWAYS_ON_LENSES: list[str] = (
    list(_OVERLAY_ALWAYS_ON) if _OVERLAY_ALWAYS_ON else list(_PUBLIC_ALWAYS_ON)
)


# ---------------------------------------------------------------------------
# Tier helpers
# ---------------------------------------------------------------------------

def _current_tier() -> str:
    """Return the caller's tier — defaults to ``free`` on any failure."""
    try:
        from aibrain_licensing import get_license
        tier = get_license().tier  # type: ignore[attr-defined]
        return tier or "free"
    except Exception:
        return "free"


def _effective_allowed(tier: str) -> set[str]:
    """Return the lens set available to ``tier``.

    When the private overlay is loaded, tier enforcement is a no-op —
    every key in the merged registry is available (Decker's machine).
    """
    if _OVERLAY_LOADED:
        return set(LENSES.keys())
    return tier_allowed_lenses(tier)


# ---------------------------------------------------------------------------
# Routing API
# ---------------------------------------------------------------------------

@dataclass
class LensRoute:
    """Result of routing a task to its lens set."""
    task_type: str
    lenses: list[str]                   # in priority order
    always_on: list[str]                # always-included safety lenses
    routing_reason: str
    fallback: bool = False              # True if we fell back to broad_unknown
    upgrade_notice: Optional[str] = None  # Q2: free→paid gentle nudge

    @property
    def total_lens_count(self) -> int:
        all_set = set(self.lenses) | set(self.always_on)
        return len(all_set)

    @property
    def all_lenses(self) -> list[str]:
        seen: set[str] = set()
        out: list[str] = []
        for name in (self.lenses + self.always_on):
            if name not in seen:
                seen.add(name)
                out.append(name)
        return out


def route(
    task_type: Optional[str] = None,
    task_description: str = "",
    lens_count: int = 7,
    min_lens_count: int = 5,
    tier: Optional[str] = None,
) -> LensRoute:
    """
    Route a task to the relevant SuperWorker lens set.

    Args:
        task_type: an explicit category from TASK_TYPE_LENSES. If None or
                   unknown, infers from task_description keywords.
        task_description: free-text description of the task.
        lens_count: target number of routed lenses (default 7).
        min_lens_count: minimum number of routed lenses (default 5).
        tier: override the detected license tier. Default None = read from
              ``aibrain_licensing.get_license().tier``. Ignored when the
              private overlay is loaded.

    Returns:
        LensRoute — carries the resolved lenses, always-on safety lenses,
        routing_reason, and an optional ``upgrade_notice`` string when a
        free-tier request was downgraded from a paid lens (Q2).
    """
    if task_type is None or task_type not in TASK_TYPE_LENSES:
        task_type = _infer_task_type(task_description)

    fallback = False
    if task_type not in TASK_TYPE_LENSES:
        task_type = "broad_unknown"
        fallback = True

    candidate_lenses = TASK_TYPE_LENSES[task_type]
    # Filter out any lens names that don't exist in the merged LENSES
    valid = [name for name in candidate_lenses if name in LENSES]

    # Tier enforcement
    resolved_tier = tier or _current_tier()
    allowed = _effective_allowed(resolved_tier)

    # Split: natural (pre-tier) pick vs in-tier filtered pick.
    target = max(min_lens_count, lens_count)
    natural = valid[:target]
    in_tier = [n for n in valid if n in allowed][:target]

    # Generate upgrade notice BEFORE padding — based on whether the natural
    # top pick was blocked by the caller's tier. Padding with broad_unknown
    # lenses would otherwise mask the tier downgrade signal.
    upgrade_notice: Optional[str] = None
    if not _OVERLAY_LOADED and natural and natural[0] not in allowed:
        paid_lens = natural[0]
        # Pick the free-tier replacement — the first in_tier candidate,
        # or the first broad_unknown fallback if none of the task-specific
        # lenses are available to this tier.
        if in_tier:
            free_lens = in_tier[0]
        else:
            free_lens = None
            for name in TASK_TYPE_LENSES.get("broad_unknown", []):
                if name in LENSES and name in allowed:
                    free_lens = name
                    break
        if free_lens:
            upgrade_notice = (
                f"This response used the {free_lens} employee. The Pro tier "
                f"includes {paid_lens} which is specifically tuned for this "
                f"kind of task."
            )

    routed = list(in_tier)

    if len(routed) < min_lens_count:
        # Pad from broad_unknown intersected with allowed
        for name in TASK_TYPE_LENSES.get("broad_unknown", []):
            if name in LENSES and name in allowed and name not in routed:
                routed.append(name)
                if len(routed) >= min_lens_count:
                    break

    routing_reason = (
        f"task_type={task_type!r}, picked top-{len(routed)} lenses "
        f"(tier={resolved_tier!r})"
        + (" (FALLBACK to broad_unknown)" if fallback else "")
    )

    # Always-on lenses respect tier — drop any that aren't allowed. In
    # practice the public always-on lenses are always in Free tier.
    always_on_filtered = [n for n in ALWAYS_ON_LENSES if n in allowed or _OVERLAY_LOADED]

    return LensRoute(
        task_type=task_type,
        lenses=routed,
        always_on=always_on_filtered,
        routing_reason=routing_reason,
        fallback=fallback,
        upgrade_notice=upgrade_notice,
    )


def _infer_task_type(description: str) -> str:
    """Best-effort task_type inference from a description string.

    Honest-rubric principle: returns 'broad_unknown' when no strong signal
    is present rather than guessing.
    """
    if not description:
        return "broad_unknown"
    d = description.lower()

    # Specialty SPECIALIST task types first (most specific).
    if any(k in d for k in ("dependency audit", "supply chain", "transitive dep", "package risk")):
        return "dependency_audit"
    if any(k in d for k in ("blue team", "defensive security", "harden defense")):
        return "defensive_security"
    if any(k in d for k in ("red team", "adversarial review", "offensive security")):
        return "offensive_security"
    if any(k in d for k in ("code audit", "audit this code", "per-commit security", "code security")):
        return "code_audit"
    if any(k in d for k in ("chain validation", "attack chain", "chain logic")):
        return "chain_validation"
    if any(k in d for k in ("regression test", "integration risk", "regression check", "regression risk")):
        return "regression_test"
    if any(k in d for k in ("test coverage", "coverage gap", "missing test")):
        return "test_coverage"
    if any(k in d for k in ("desktop app", "native toolchain", "rust app")):
        return "desktop_engineering"
    if any(k in d for k in ("performance review", "perf review", "performance audit")):
        return "performance_review"
    if any(k in d for k in ("competitive analysis", "competitor", "market position")):
        return "competitive_analysis"
    if any(k in d for k in ("archive search", "knowledge recall", "consolidate knowledge")):
        return "archive_search"
    if any(k in d for k in ("product framing", "product positioning", "product philosophy")):
        return "product_framing"
    if any(k in d for k in ("send message", "send email", "send telegram", "send a message",
                            "telegram message", "email reply", "draft reply", "draft a reply")):
        return "send_communication"

    # Broader categories
    if any(k in d for k in ("security", "vuln", "exploit", "credential", "attack")):
        return "security_review"
    if any(k in d for k in ("distributed", "concurrent", "race condition", "consensus")):
        return "distributed_systems"
    if any(k in d for k in ("metric", "measurement", "benchmark", "score", "rubric")):
        return "metrics_analysis"
    if any(k in d for k in ("scaling", "scale to", "throughput", "performance")):
        return "scaling_decision"
    if any(k in d for k in ("ai safety", "alignment", "value")):
        return "ai_safety"
    if any(k in d for k in ("memory.md", "memory update", "session summary", "synthesize this session")):
        return "memory_synthesis"
    if any(k in d for k in ("polish", "refine", "fix what we have", "verify-and-fix")):
        return "polish_refine"
    if any(k in d for k in ("architecture", "design", "module structure", "code review", "refactor")):
        return "architecture_review"
    if any(k in d for k in ("ux", "user experience", "interface", "dashboard")):
        return "ux_design"
    if any(k in d for k in ("data model", "schema", "data shape")):
        return "data_modeling"
    if any(k in d for k in ("strategy", "strategic", "competitive", "moat")):
        return "strategy_decision"
    if any(k in d for k in ("product", "feature", "user-facing", "shipping")):
        return "product_decision"
    if any(k in d for k in ("business impact", "revenue", "customer cost", "churn")):
        return "business_impact"
    if any(k in d for k in ("writing", "content", "blog", "post", "synthesis text")):
        return "writing_synthesis"
    if any(k in d for k in ("research", "hypothesis", "experiment")):
        return "research_question"
    if any(k in d for k in ("first principles", "from scratch", "fundamental")):
        return "first_principles"
    if any(k in d for k in ("long-term", "long term", "100 year", "vision")):
        return "long_term_vision"
    if any(k in d for k in ("founder", "ship", "launch", "company decision")):
        return "founder_decision"

    return "broad_unknown"


def list_task_types() -> list[str]:
    """Return all known task types (for CLI / debugging)."""
    return sorted(TASK_TYPE_LENSES.keys())


def list_lenses() -> list[str]:
    """Return all known lens names (for CLI / debugging)."""
    return sorted(LENSES.keys())


# ---------------------------------------------------------------------------
# Canonical task_type aliases for select_lenses() caller convenience.
# Maps the four broad domains in the SuperWorker design to concrete task_types.
# ---------------------------------------------------------------------------
_DOMAIN_TO_TASK_TYPE: dict[str, str] = {
    "engineering":  "code_review",
    "code":         "code_review",
    "strategy":     "strategy_decision",
    "product":      "strategy_decision",
    "ml":           "ml_implementation",
    "research":     "research_question",
    "security":     "security_review",
}

# Always-on lenses that MUST be in every selection regardless of task type.
# On a private overlay install the operator lens and security lens are named
# persona entries. On a public install they are the public floor neutrals
# ("Operator Lens", "Adversarial Security Lens"). Both satisfy the same
# semantic contract: operator always-on + adversarial always-on.
# ALWAYS_ON_LENSES is the live value (overlay-replaced or public floor).
_ALWAYS_ON_CANONICAL: list[str] = ALWAYS_ON_LENSES  # live value, overlay or public


def select_lenses(
    task_description: str,
    task_type: str = "",
    lens_count: int = 7,
    tier: Optional[str] = None,
) -> list[str]:
    """Select the N most relevant lenses for a task.

    Public API for lens selection. Returns an ordered list of lens names
    (strings) without always-on duplicates.

    Routing logic:
    - ``task_type`` may be a canonical TASK_TYPE_LENSES key or a domain alias
      ("engineering", "code", "strategy", "product", "ml", "research",
      "security"). Unknown values fall through to keyword inference on
      ``task_description``.
    - Always-on lenses (operator + adversarial, set by overlay or public floor)
      are ALWAYS prepended, regardless of task type or lens_count.
    - Deduplication is applied: if an always-on lens would also appear in the
      routed set, it is not duplicated.

    Args:
        task_description: free-text description of the task.
        task_type:        explicit domain/task_type hint (optional).
        lens_count:       target number of routed lenses *excluding* always-on
                          lenses (default 7).
        tier:             caller's license tier (default = auto-detect).

    Returns:
        Ordered list: [always_on_lenses..., routed_lenses...]
    """
    # Resolve domain alias → canonical task_type key
    resolved_type: Optional[str] = _DOMAIN_TO_TASK_TYPE.get(task_type.lower(), task_type) or None

    lr = route(
        task_type=resolved_type,
        task_description=task_description,
        lens_count=lens_count,
        tier=tier,
    )
    return lr.all_lenses


def describe_lenses(lens_names: list[str]) -> list[dict]:
    """Return [{name, specialty, categories}] for the given lens names.

    Unknown lens names are included with specialty="unknown" so callers
    never silently drop a lens from a prompt.
    """
    out: list[dict] = []
    for name in lens_names:
        meta = LENSES.get(name, {})
        out.append({
            "name": name,
            "specialty": meta.get("specialty", "unknown"),
            "categories": meta.get("categories", []),
        })
    return out
