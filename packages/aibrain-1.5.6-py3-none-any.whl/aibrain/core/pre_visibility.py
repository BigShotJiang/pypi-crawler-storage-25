"""
Pre-visibility checklist — binary pass/fail gate before any public exposure.

Run before: PyPI publish, Show HN, open-source push.
CLI: aibrain pre-check
API: from aibrain.core.pre_visibility import run_checklist
"""

import os
import re
import subprocess
import sys
from pathlib import Path

# Internal tool names that must never appear in public-facing files
_INTERNAL_NAMES = [
    "wintermute", "remediate", "permeate", "rogue", "paragon",
    "cve_db.py", "chain_validator.py", "openclaw",
]

# Public-facing files to scan
_PUBLIC_FILES = ["README.md", "SECURITY.md", "pyproject.toml", "LICENSE", "CHANGELOG.md"]

# Patterns that indicate credentials
_CRED_PATTERNS = [
    r"(?i)(api[_-]?key|secret[_-]?key|password|token)\s*[=:]\s*['\"][^'\"]{8,}",
    r"(?i)-----BEGIN\s+(RSA\s+)?PRIVATE\s+KEY-----",
    r"ghp_[A-Za-z0-9]{36}",                  # GitHub PAT
    r"sk-[A-Za-z0-9]{20,}",                   # OpenAI-style key
    r"AKIA[0-9A-Z]{16}",                      # AWS access key
]

# .gitignore must cover these patterns
_REQUIRED_GITIGNORE = [".env", "*.key", "credentials"]


def _find_repo_root(start: Path | None = None) -> Path:
    """Walk up to find .git directory."""
    p = start or Path.cwd()
    for parent in [p] + list(p.parents):
        if (parent / ".git").exists():
            return parent
    return p


def _check_no_creds_in_history(repo: Path, n_commits: int = 20) -> dict:
    """Check last N commits for credential patterns."""
    try:
        result = subprocess.run(
            ["git", "log", f"-{n_commits}", "--diff-filter=A", "-p", "--no-color"],
            capture_output=True, text=True, cwd=str(repo), timeout=30,
        )
        output = result.stdout
        findings = []
        for pattern in _CRED_PATTERNS:
            matches = re.findall(pattern, output)
            if matches:
                findings.append(f"Pattern {pattern[:40]}... matched {len(matches)} time(s)")
        return {
            "name": "no_credentials_in_history",
            "passed": len(findings) == 0,
            "detail": "; ".join(findings) if findings else f"Clean — last {n_commits} commits checked",
        }
    except Exception as e:
        return {"name": "no_credentials_in_history", "passed": False, "detail": str(e)}


def _check_no_internal_names(repo: Path) -> dict:
    """Check public-facing files for internal tool names."""
    findings = []
    for fname in _PUBLIC_FILES:
        fpath = repo / fname
        if not fpath.exists():
            continue
        content = fpath.read_text(encoding="utf-8", errors="replace").lower()
        for name in _INTERNAL_NAMES:
            if name.lower() in content:
                findings.append(f"{fname}: contains '{name}'")
    return {
        "name": "no_internal_names_in_public_files",
        "passed": len(findings) == 0,
        "detail": "; ".join(findings) if findings else "Clean",
    }


def _check_tests_pass(repo: Path) -> dict:
    """Run pytest and verify all tests pass."""
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pytest", "--tb=no", "-q"],
            capture_output=True, text=True, cwd=str(repo), timeout=120,
        )
        passed = result.returncode == 0
        # Extract summary line like "52 passed"
        lines = result.stdout.strip().splitlines()
        summary = lines[-1] if lines else "no output"
        return {
            "name": "all_tests_pass",
            "passed": passed,
            "detail": summary,
        }
    except subprocess.TimeoutExpired:
        return {"name": "all_tests_pass", "passed": False, "detail": "pytest timed out (120s)"}
    except Exception as e:
        return {"name": "all_tests_pass", "passed": False, "detail": str(e)}


def _check_file_exists(repo: Path, filename: str) -> dict:
    """Check that a required file exists."""
    exists = (repo / filename).exists()
    return {
        "name": f"{filename.lower().replace('.', '_')}_exists",
        "passed": exists,
        "detail": f"{filename} found" if exists else f"{filename} MISSING",
    }


def _check_gitignore_coverage(repo: Path) -> dict:
    """Verify .gitignore covers required sensitive patterns."""
    gitignore = repo / ".gitignore"
    if not gitignore.exists():
        return {
            "name": "gitignore_covers_secrets",
            "passed": False,
            "detail": ".gitignore not found",
        }
    content = gitignore.read_text(encoding="utf-8", errors="replace")
    missing = []
    for pattern in _REQUIRED_GITIGNORE:
        if pattern not in content:
            missing.append(pattern)
    return {
        "name": "gitignore_covers_secrets",
        "passed": len(missing) == 0,
        "detail": f"Missing: {', '.join(missing)}" if missing else "All required patterns covered",
    }


def _check_no_todo_fixme(repo: Path) -> dict:
    """Check public-facing files for TODO/FIXME markers."""
    findings = []
    for fname in _PUBLIC_FILES:
        fpath = repo / fname
        if not fpath.exists():
            continue
        content = fpath.read_text(encoding="utf-8", errors="replace")
        for i, line in enumerate(content.splitlines(), 1):
            if re.search(r"\b(TODO|FIXME)\b", line):
                findings.append(f"{fname}:{i}")
    return {
        "name": "no_todo_fixme_in_public_files",
        "passed": len(findings) == 0,
        "detail": "; ".join(findings) if findings else "Clean",
    }


def run_checklist(repo_path: str | Path | None = None) -> dict:
    """
    Run the full pre-visibility checklist.

    Returns:
        {
            "overall": "PASS" | "FAIL",
            "checks": [{"name": str, "passed": bool, "detail": str}, ...],
            "passed": int,
            "failed": int,
        }
    """
    repo = _find_repo_root(Path(repo_path) if repo_path else None)

    checks = [
        _check_no_creds_in_history(repo),
        _check_no_internal_names(repo),
        _check_tests_pass(repo),
        _check_file_exists(repo, "SECURITY.md"),
        _check_file_exists(repo, "LICENSE"),
        _check_gitignore_coverage(repo),
        _check_no_todo_fixme(repo),
    ]

    passed = sum(1 for c in checks if c["passed"])
    failed = len(checks) - passed

    return {
        "overall": "PASS" if failed == 0 else "FAIL",
        "checks": checks,
        "passed": passed,
        "failed": failed,
    }


def cli_main(args: list | None = None) -> int:
    """CLI entry point for `aibrain pre-check`."""
    import argparse

    parser = argparse.ArgumentParser(description="Pre-visibility checklist")
    parser.add_argument("--path", help="Repository path (default: auto-detect)")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    parsed = parser.parse_args(args or [])

    result = run_checklist(parsed.path)

    if parsed.json:
        import json
        print(json.dumps(result, indent=2))
    else:
        print(f"\n  Pre-Visibility Checklist — {result['overall']}")
        print(f"  {'─' * 50}")
        for check in result["checks"]:
            icon = "PASS" if check["passed"] else "FAIL"
            print(f"  [{icon}] {check['name']}")
            print(f"         {check['detail']}")
        print(f"\n  Result: {result['passed']} passed, {result['failed']} failed\n")

    return 0 if result["overall"] == "PASS" else 1
