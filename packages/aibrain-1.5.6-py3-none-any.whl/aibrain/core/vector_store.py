"""
vector_store.py — Abstracted vector storage layer with multiple backends.

Interface: store(id, embedding), search(embedding, k), delete(id), count()
Backends:
  - SqliteVecStore  — current production backend using sqlite-vec extension
  - NumpyStore      — fallback in-memory cosine similarity (zero deps)
  - FaissStore      — optional high-performance backend (if faiss installed)

Factory:
  get_vector_store(backend='auto') — auto-detects best available backend

Usage:
    from aibrain.core.vector_store import get_vector_store

    vs = get_vector_store()  # auto-detect best backend
    vs.store(42, [0.1, 0.2, ...])
    results = vs.search([0.1, 0.2, ...], k=5)  # [(id, distance), ...]
    vs.delete(42)
    print(vs.count())
"""

from __future__ import annotations

import logging
import math
import sqlite3
import struct
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

log = logging.getLogger("aibrain.vector_store")


# ---------------------------------------------------------------------------
# Abstract interface
# ---------------------------------------------------------------------------

class VectorStore(ABC):
    """Abstract vector storage interface."""

    @abstractmethod
    def store(self, id: int, embedding: list[float]) -> None:
        """Store or update a vector by ID."""
        ...

    @abstractmethod
    def search(self, embedding: list[float], k: int = 5) -> list[tuple[int, float]]:
        """Find k nearest neighbors. Returns list of (id, distance) tuples.

        Distance is L2 / Euclidean. Lower = more similar.
        """
        ...

    @abstractmethod
    def delete(self, id: int) -> bool:
        """Delete a vector by ID. Returns True if it existed."""
        ...

    @abstractmethod
    def count(self) -> int:
        """Return total number of stored vectors."""
        ...

    @property
    def backend_name(self) -> str:
        """Human-readable backend name."""
        return self.__class__.__name__


# ---------------------------------------------------------------------------
# Backend: SqliteVecStore (production — uses sqlite-vec extension)
# ---------------------------------------------------------------------------

class SqliteVecStore(VectorStore):
    """Vector store backed by sqlite-vec virtual table.

    This is the production backend used by aibrain_db.py.
    Requires the sqlite-vec extension to be installed.
    """

    # Allowed table names — prevents SQL injection via table parameter
    _ALLOWED_TABLES = frozenset({"memories_vec", "test_vec", "satellite_vec"})

    def __init__(self, db_path: str | Path, table: str = "memories_vec",
                 dim: int = 384, conn: sqlite3.Connection | None = None):
        if not table.isidentifier():
            raise ValueError(f"Invalid table name: {table!r}")
        self._db_path = str(db_path)
        self._table = table
        self._dim = dim
        self._external_conn = conn is not None
        if conn is not None:
            self._conn = conn
        else:
            self._conn = self._connect()
        self._ensure_table()

    def _connect(self) -> sqlite3.Connection:
        import sqlite_vec
        conn = sqlite3.connect(self._db_path, check_same_thread=False)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.enable_load_extension(True)
        sqlite_vec.load(conn)
        conn.enable_load_extension(False)
        return conn

    def _ensure_table(self):
        try:
            # Table name validated in __init__ (must be Python identifier)
            sql = f"CREATE VIRTUAL TABLE IF NOT EXISTS {self._table} USING vec0(memory_id INTEGER PRIMARY KEY, embedding float[{self._dim}])"  # noqa:sql-fstring
            self._conn.execute(sql)
            self._conn.commit()
        except Exception as e:
            log.debug("vec0 table creation: %s", e)

    def _pack(self, embedding: list[float]) -> bytes:
        return struct.pack(f"{len(embedding)}f", *embedding)

    def store(self, id: int, embedding: list[float]) -> None:
        emb_bytes = self._pack(embedding)
        sql = f"INSERT OR REPLACE INTO {self._table} (memory_id, embedding) VALUES (?, ?)"  # noqa:sql-fstring — table name validated in __init__
        self._conn.execute(sql, (id, emb_bytes))
        self._conn.commit()

    def search(self, embedding: list[float], k: int = 5) -> list[tuple[int, float]]:
        emb_bytes = self._pack(embedding)
        sql = f"SELECT v.memory_id, v.distance FROM {self._table} v WHERE v.embedding MATCH ? AND k = ?"  # noqa:sql-fstring — table name validated in __init__
        rows = self._conn.execute(sql, (emb_bytes, k)).fetchall()
        return [(row[0], row[1]) for row in rows]

    def delete(self, id: int) -> bool:
        sql = f"DELETE FROM {self._table} WHERE memory_id = ?"  # noqa:sql-fstring — table name validated in __init__
        cur = self._conn.execute(sql, (id,))
        self._conn.commit()
        return cur.rowcount > 0

    def count(self) -> int:
        sql = f"SELECT COUNT(*) FROM {self._table}"  # noqa:sql-fstring — table name validated in __init__
        row = self._conn.execute(sql).fetchone()
        return row[0] if row else 0

    def close(self):
        if not self._external_conn:
            self._conn.close()


# ---------------------------------------------------------------------------
# Backend: NumpyStore (fallback — in-memory cosine similarity, zero deps)
# ---------------------------------------------------------------------------

class NumpyStore(VectorStore):
    """In-memory vector store using pure Python cosine similarity.

    Zero external dependencies. Suitable as fallback when sqlite-vec
    is unavailable. Not persisted — data lives only in memory.
    """

    def __init__(self):
        self._vectors: dict[int, list[float]] = {}

    def store(self, id: int, embedding: list[float]) -> None:
        self._vectors[id] = list(embedding)

    def search(self, embedding: list[float], k: int = 5) -> list[tuple[int, float]]:
        if not self._vectors:
            return []
        results = []
        for vid, vec in self._vectors.items():
            dist = self._cosine_distance(embedding, vec)
            results.append((vid, dist))
        results.sort(key=lambda x: x[1])
        return results[:k]

    def delete(self, id: int) -> bool:
        if id in self._vectors:
            del self._vectors[id]
            return True
        return False

    def count(self) -> int:
        return len(self._vectors)

    @staticmethod
    def _cosine_distance(a: list[float], b: list[float]) -> float:
        """Cosine distance (1 - cosine_similarity). Range [0, 2]."""
        dot = sum(x * y for x, y in zip(a, b))
        na = math.sqrt(sum(x * x for x in a))
        nb = math.sqrt(sum(x * x for x in b))
        if na == 0 or nb == 0:
            return 2.0
        sim = dot / (na * nb)
        return 1.0 - sim


# ---------------------------------------------------------------------------
# Backend: FaissStore (optional — high-performance, requires faiss)
# ---------------------------------------------------------------------------

class FaissStore(VectorStore):
    """Vector store backed by FAISS IndexFlatL2.

    High-performance nearest neighbor search. Requires `faiss-cpu` or
    `faiss-gpu` to be installed. Falls back gracefully if unavailable.
    """

    def __init__(self, dim: int = 384):
        import faiss
        self._dim = dim
        self._index = faiss.IndexFlatL2(dim)
        self._id_map: list[int] = []  # position -> memory_id
        self._id_to_pos: dict[int, int] = {}  # memory_id -> position

    def store(self, id: int, embedding: list[float]) -> None:
        import numpy as np
        vec = np.array([embedding], dtype=np.float32)
        if id in self._id_to_pos:
            # FAISS IndexFlatL2 doesn't support update — rebuild without old entry
            self._remove_internal(id)
        pos = self._index.ntotal
        self._index.add(vec)
        self._id_map.append(id)
        self._id_to_pos[id] = pos

    def search(self, embedding: list[float], k: int = 5) -> list[tuple[int, float]]:
        import numpy as np
        if self._index.ntotal == 0:
            return []
        k = min(k, self._index.ntotal)
        vec = np.array([embedding], dtype=np.float32)
        distances, indices = self._index.search(vec, k)
        results = []
        for dist, idx in zip(distances[0], indices[0]):
            if idx < 0 or idx >= len(self._id_map):
                continue
            results.append((self._id_map[idx], float(dist)))
        return results

    def delete(self, id: int) -> bool:
        if id not in self._id_to_pos:
            return False
        self._remove_internal(id)
        return True

    def count(self) -> int:
        return self._index.ntotal

    def _remove_internal(self, id: int):
        """Remove an entry by rebuilding the index without it."""
        import numpy as np
        if id not in self._id_to_pos:
            return
        # Rebuild: collect all vectors except the one being removed
        old_ids = list(self._id_map)
        old_vecs = []
        for i in range(self._index.ntotal):
            vec = self._index.reconstruct(i)
            old_vecs.append(vec)

        import faiss
        self._index = faiss.IndexFlatL2(self._dim)
        self._id_map = []
        self._id_to_pos = {}

        for oid, vec in zip(old_ids, old_vecs):
            if oid == id:
                continue
            pos = self._index.ntotal
            self._index.add(np.array([vec], dtype=np.float32))
            self._id_map.append(oid)
            self._id_to_pos[oid] = pos


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

def get_vector_store(
    backend: str = "auto",
    db_path: str | Path | None = None,
    dim: int = 384,
    conn: sqlite3.Connection | None = None,
) -> VectorStore:
    """Create a vector store with the best available backend.

    Args:
        backend: 'auto', 'sqlite_vec', 'numpy', or 'faiss'.
        db_path: Path to SQLite database (for sqlite_vec backend).
        dim: Embedding dimension (default 384 for MiniLM).
        conn: Optional existing SQLite connection (for sqlite_vec backend).

    Returns:
        VectorStore instance.

    Auto-detection order: sqlite_vec > faiss > numpy
    """
    if backend == "auto":
        backend = _detect_best_backend()

    if backend == "sqlite_vec":
        if db_path is None and conn is None:
            from aibrain_db import AIBRAIN_ROOT
            db_path = AIBRAIN_ROOT / "aibrain.db"
        return SqliteVecStore(db_path=db_path or ":memory:", table="memories_vec", dim=dim, conn=conn)

    elif backend == "faiss":
        return FaissStore(dim=dim)

    elif backend == "numpy":
        return NumpyStore()

    else:
        raise ValueError(f"Unknown vector store backend: {backend!r}. Use 'auto', 'sqlite_vec', 'numpy', or 'faiss'.")


def _detect_best_backend() -> str:
    """Detect the best available vector store backend."""
    # 1. Try sqlite-vec
    try:
        import sqlite_vec
        return "sqlite_vec"
    except ImportError:
        pass

    # 2. Try FAISS
    try:
        import faiss
        return "faiss"
    except ImportError:
        pass

    # 3. Fallback to pure Python
    return "numpy"


def available_backends() -> list[str]:
    """Return list of available backend names."""
    backends = ["numpy"]  # always available
    try:
        import sqlite_vec
        backends.insert(0, "sqlite_vec")
    except ImportError:
        pass
    try:
        import faiss
        backends.append("faiss")
    except ImportError:
        pass
    return backends
