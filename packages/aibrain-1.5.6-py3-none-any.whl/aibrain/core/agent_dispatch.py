"""
agent_dispatch.py — Thin logging wrapper for Agent() spawns.

Every Agent() tool call must be bracketed by dispatch_agent() / complete_dispatch()
so that the execution_log has a row for every spawn. Without this, agent work
is invisible to the audit trail, cost tracker, and quality system.

Usage (the full 4-layer stack):

    from aibrain.core.companies import create_task, checkout_task, complete_task
    from aibrain.core.agent_dispatch import dispatch_agent, complete_dispatch, build_agent_prompt

    # 1. Company task
    task = create_task('GT_LRWrEBQQ', title='...', description='...', assignee_agent_id='CDTYrHYkyH8')
    checkout_task('GT_LRWrEBQQ', task['id'])

    # 2. Build persona-prepended prompt BEFORE spawning
    full_prompt = build_agent_prompt("CDTYrHYkyH8", task_description)
    info = dispatch_agent(task['id'], full_prompt)

    # 3. <<< Agent(prompt=full_prompt) call happens here externally >>>
    agent_output = "... agent returned ..."

    # 4. Close the log row AFTER Agent() returns
    complete_dispatch(info['dispatch_id'], info['task_id'], quality_score=0.8, output_summary=agent_output[:500])

    # 5. Complete the company task
    complete_task(task['id'], quality_score=0.8)

Thin layer — no new dependencies, no new orchestration. Delegates all DB work
to the existing harness bookend functions (start_subagent_execution,
complete_subagent_execution, score_subagent_output). Matches harness.py patterns exactly.
"""

import os as _os
import json as _json

from aibrain.core.harness import (
    start_subagent_execution,
    complete_subagent_execution,
    score_subagent_output,
)

__all__ = [
    "dispatch_agent",
    "complete_dispatch",
    "record_agent_spawn",
    "score_subagent_output",  # re-export for callers who want the heuristic scorer
    "get_agent_persona",
    "build_agent_prompt",
    "fuzzy_match_persona_file",
]


def _get_canonical_db():
    """Get canonical aibrain.db path via AIBRAIN_ROOT."""
    try:
        from aibrain.aibrain_db import AIBRAIN_ROOT
        return _os.path.join(AIBRAIN_ROOT, "aibrain.db")
    except Exception:
        return _os.path.expanduser("~/projects/aibrain/aibrain.db")


def get_agent_persona(agent_id: str, company_id: str = "GT_LRWrEBQQ") -> str:
    """
    Load the full persona/system prompt for an agent.

    Priority order:
    1. company_agents.instructions field (DB — edited via dashboard)
    2. metadata.persona_file path → read file from disk
    3. Empty string (agent has no persona configured)

    Returns empty string on any error — never raises.
    """
    try:
        import sqlite3
        db_path = _get_canonical_db()
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        row = conn.execute(
            "SELECT instructions, metadata FROM company_agents WHERE id=? AND company_id=?",
            [agent_id, company_id]
        ).fetchone()
        conn.close()
        if not row:
            return ""
        instructions = (row["instructions"] or "").strip()
        if instructions:
            return instructions
        meta = {}
        try:
            meta = _json.loads(row["metadata"] or "{}")
        except Exception:
            pass
        persona_file = meta.get("persona_file")
        if persona_file and _os.path.exists(persona_file):
            return open(persona_file, encoding="utf-8").read().strip()
    except Exception:
        pass
    return ""


def fuzzy_match_persona_file(agent_name: str, subagents_dir: str = r"C:\Users\sinde\decker_system\02_subagents") -> str | None:
    """
    Find a persona .md file for an agent by fuzzy name matching.

    Tries variants: name_snake_v2.md, name_snake_agent_v2.md, name_snake.md, name_snake_agent.md
    Returns absolute path if found, else None.
    """
    import re
    name_snake = re.sub(r"[^a-z0-9]+", "_", agent_name.lower()).strip("_")
    candidates = [
        f"{name_snake}_v2.md",
        f"{name_snake}_agent_v2.md",
        f"{name_snake}.md",
        f"{name_snake}_agent.md",
        f"{name_snake}_v2_agent.md",
    ]
    try:
        available = {f.lower(): f for f in _os.listdir(subagents_dir) if f.endswith(".md")}
        for c in candidates:
            if c in available:
                return _os.path.join(subagents_dir, available[c])
    except Exception:
        pass
    return None


def build_agent_prompt(agent_id: str, task_prompt: str, company_id: str = "GT_LRWrEBQQ") -> str:
    """
    Build the full prompt for an Agent() spawn by prepending the agent's persona.

    If the agent has a persona configured (via DB instructions or persona_file),
    it is prepended with a separator so the agent knows its role before seeing the task.
    If no persona is configured, returns task_prompt unchanged.

    Usage::

        full_prompt = build_agent_prompt("CDTYrHYkyH8", "Fix the auth module IDOR bug")
        info = dispatch_agent(task_id, full_prompt)
        # Agent(prompt=full_prompt)  ← Agent() call in Neuro's turn

    Returns:
        str: persona + separator + task_prompt, or just task_prompt if no persona.
    """
    persona = get_agent_persona(agent_id, company_id)
    if not persona:
        return task_prompt
    separator = "\n\n---\n\nYour current task:\n\n"
    return persona + separator + task_prompt


def dispatch_agent(
    task_id: str,
    prompt: str,
    actor: str = "neuro",
    classification: str = "complex",
    model_used: str = "claude-sonnet-4-6",
    estimated_cost_usd: float = 0.0,
) -> dict:
    """
    Record an agent dispatch to execution_log BEFORE spawning the Agent() tool.

    Creates an execution_log row in 'started' state so partially-completed spawns
    (e.g. session dies between dispatch and complete) are visible as dangling rows
    in the audit trail rather than disappearing silently.

    Args:
        task_id:            Company task ID to link this spawn to (company_issue_id).
        prompt:             The prompt/description being sent to the agent.
                            First 200 chars used as the action label in execution_log.
        actor:              Who is spawning (default: "neuro").
        classification:     Task complexity: "deterministic", "simple", "judgment",
                            or "complex" (default: "complex" — agents are always complex).
        model_used:         Model the agent will use. Used as a tag in detail JSON;
                            not written to model_used column until complete_dispatch().
        estimated_cost_usd: Pre-spawn cost estimate. Stored in detail JSON as a tag.
                            Cannot be written to cost_cents column until completion.

    Returns:
        dict with keys:
            dispatch_id (str):   ID to pass to complete_dispatch().
            task_id (str):       Echo of the task_id for chaining.
            classification (str): Echo of the classification used.

    Example::

        from aibrain.core.agent_dispatch import dispatch_agent, complete_dispatch, build_agent_prompt

        full_prompt = build_agent_prompt("CDTYrHYkyH8", task_description)
        info = dispatch_agent(task_id, full_prompt)
        # <<< Agent(prompt=full_prompt) call here >>>
        complete_dispatch(info['dispatch_id'], info['task_id'], quality_score=0.8, output_summary=result)
    """
    tags = [
        f"model:{model_used}",
        f"estimated_cost_usd:{estimated_cost_usd:.4f}",
    ]

    dispatch_id = start_subagent_execution(
        description=prompt,
        task_type=classification,
        actor=actor,
        company_issue_id=task_id,
        tags=tags,
    )

    return {
        "dispatch_id": dispatch_id,
        "task_id": task_id,
        "classification": classification,
    }


def complete_dispatch(
    dispatch_id: str,
    task_id: str,
    quality_score: float,
    output_summary: str,
    actual_cost_usd: float = 0.0,
) -> None:
    """
    Record completion of a dispatched agent AFTER the Agent() tool returns.

    Updates the execution_log row opened by dispatch_agent() with the agent's
    output, quality score, and actual cost. Marks success=1 if quality_score >= 0.3.

    Args:
        dispatch_id:     The ID returned by dispatch_agent() (or record_agent_spawn()).
        task_id:         Company task ID (passed through for symmetry; not re-written to DB).
        quality_score:   Float 0.0–1.0. Use score_subagent_output() for a heuristic value.
                         Pass 0.0 if the agent produced no usable output.
        output_summary:  Raw or summarised agent output (first 1000 chars used).
        actual_cost_usd: Actual USD spent if measurable. Converted to cents for storage.
                         Pass 0.0 when backed by a subscription (cannot measure).

    Returns:
        None. Logs a warning on DB failure but does not raise.

    Example::

        complete_dispatch(
            dispatch_id=info['dispatch_id'],
            task_id=task['id'],
            quality_score=score_subagent_output(agent_result, "Audit auth module"),
            output_summary=agent_result,
            actual_cost_usd=0.0,
        )
    """
    cost_cents = int(round(actual_cost_usd * 100)) if actual_cost_usd else None

    complete_subagent_execution(
        execution_id=dispatch_id,
        output_text=output_summary,
        quality_score=quality_score,
        cost_cents=cost_cents,
        model_used=None,  # agent does not self-report model in current SDK
    )


def record_agent_spawn(
    task_id: str,
    description: str,
    actor: str = "neuro",
    classification: str = "complex",
) -> str:
    """
    One-liner convenience wrapper — call this immediately before Agent().

    Equivalent to dispatch_agent() but returns just the dispatch_id string
    for callers who prefer the minimal interface.

    Args:
        task_id:        Company task ID to link this spawn to.
        description:    Short description of what the agent will do.
        actor:          Who is spawning (default: "neuro").
        classification: Task complexity class (default: "complex").

    Returns:
        dispatch_id (str): Pass this to complete_dispatch() after Agent() returns.

    Example::

        dispatch_id = record_agent_spawn(task['id'], "Fix IDOR in /api/users")
        # <<< Agent() call >>>
        complete_dispatch(dispatch_id, task['id'], quality_score=0.85, output_summary=result)
    """
    info = dispatch_agent(
        task_id=task_id,
        prompt=description,
        actor=actor,
        classification=classification,
    )
    return info["dispatch_id"]
