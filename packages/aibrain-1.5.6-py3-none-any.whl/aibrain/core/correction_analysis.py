"""Correction cluster analysis — identifies top failure modes from correction memories.

Reads all correction/feedback memories, clusters by content similarity using
the existing embedding infrastructure, and extracts common failure patterns.
"""

import json
import os
import sqlite3
import sys
from collections import Counter, defaultdict
from pathlib import Path


def _get_db() -> sqlite3.Connection:
    """Open a connection to aibrain.db via the canonical resolver — see aibrain_db.AIBRAIN_ROOT."""
    from aibrain_db import AIBRAIN_ROOT
    db_path = AIBRAIN_ROOT / "aibrain.db"
    conn = sqlite3.connect(str(db_path), check_same_thread=False)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.row_factory = sqlite3.Row
    return conn


def _load_corrections(db: sqlite3.Connection | None = None) -> list[dict]:
    """Load all active correction and feedback memories."""
    if db is None:
        db = _get_db()
    rows = db.execute(
        "SELECT id, name, type, content, tags, importance, created, updated "
        "FROM memories WHERE active=1 AND type IN ('correction', 'feedback') "
        "ORDER BY updated DESC"
    ).fetchall()
    return [dict(r) for r in rows]


def _compute_embeddings(texts: list[str]) -> list[list[float]] | None:
    """Compute embeddings using the aibrain_db embedder infrastructure."""
    try:
        import aibrain_db
        if not aibrain_db._db_vec_enabled:
            aibrain_db.init_embedder()
        if aibrain_db._db_embedder is None:
            return None
        vecs = []
        for t in texts:
            v = aibrain_db._compute_embedding(t)
            if v is not None:
                vecs.append(v)
            else:
                vecs.append([0.0] * 384)
        return vecs
    except Exception:
        return None


def _cosine_sim(a: list[float], b: list[float]) -> float:
    """Cosine similarity between two vectors."""
    dot = sum(x * y for x, y in zip(a, b))
    na = sum(x * x for x in a) ** 0.5
    nb = sum(x * x for x in b) ** 0.5
    if na == 0 or nb == 0:
        return 0.0
    return dot / (na * nb)


def _cluster_greedy(embeddings: list[list[float]], threshold: float = 0.65) -> list[list[int]]:
    """Simple greedy clustering — assign each item to first cluster within threshold.

    Returns list of clusters, each a list of indices.
    """
    n = len(embeddings)
    assigned = [False] * n
    clusters: list[list[int]] = []

    for i in range(n):
        if assigned[i]:
            continue
        cluster = [i]
        assigned[i] = True
        for j in range(i + 1, n):
            if assigned[j]:
                continue
            if _cosine_sim(embeddings[i], embeddings[j]) >= threshold:
                cluster.append(j)
                assigned[j] = True
        clusters.append(cluster)

    # Sort clusters by size descending
    clusters.sort(key=len, reverse=True)
    return clusters


def _extract_pattern(memories: list[dict]) -> str:
    """Extract the common failure pattern from a cluster of memories.

    Uses the most important memory's name as the primary label,
    then summarizes common keywords across the cluster.
    """
    if not memories:
        return "unknown"

    # Pick the highest-importance memory as representative
    best = max(memories, key=lambda m: float(m.get("importance", 0.5) or 0.5))
    label = best.get("name", "").strip()

    # Extract common words from all names (minus stopwords)
    stopwords = {"the", "a", "an", "is", "was", "are", "were", "be", "been",
                 "to", "of", "in", "for", "on", "with", "at", "by", "from",
                 "and", "or", "not", "no", "do", "don't", "it", "its",
                 "this", "that", "but", "-", "—", "", "all", "any"}
    word_counts: Counter = Counter()
    for m in memories:
        words = set(w.lower() for w in (m.get("name", "") + " " + m.get("tags", "")).split()
                    if w.lower() not in stopwords and len(w) > 2)
        word_counts.update(words)

    # Top keywords that appear in >40% of cluster members
    min_freq = max(2, len(memories) * 0.4)
    common_kw = [w for w, c in word_counts.most_common(10) if c >= min_freq]

    if common_kw:
        return f"{label} [{', '.join(common_kw[:5])}]"
    return label


def top_failure_modes(n: int = 10, threshold: float = 0.65,
                      db: sqlite3.Connection | None = None) -> list[dict]:
    """Return the N most common correction/failure patterns.

    Args:
        n: Number of top patterns to return.
        threshold: Cosine similarity threshold for clustering (0.0-1.0).
        db: Optional DB connection (for testing).

    Returns:
        List of dicts with keys:
        - pattern: str — description of the failure mode
        - count: int — number of corrections in this cluster
        - example_ids: list[int] — memory IDs in this cluster
        - representative: str — name of the most important memory
        - importance_avg: float — average importance across cluster
    """
    corrections = _load_corrections(db)
    if not corrections:
        return []

    # Try embedding-based clustering first
    texts = [f"{m.get('name', '')} {m.get('content', '')[:200]}" for m in corrections]
    embeddings = _compute_embeddings(texts)

    if embeddings and len(embeddings) == len(corrections):
        clusters = _cluster_greedy(embeddings, threshold=threshold)
    else:
        # Fallback: cluster by tag overlap
        clusters = _cluster_by_tags(corrections)

    results = []
    for cluster_indices in clusters[:n]:
        cluster_mems = [corrections[i] for i in cluster_indices]
        pattern = _extract_pattern(cluster_mems)
        imp_avg = sum(float(m.get("importance", 0.5) or 0.5) for m in cluster_mems) / len(cluster_mems)
        best = max(cluster_mems, key=lambda m: float(m.get("importance", 0.5) or 0.5))
        results.append({
            "pattern": pattern,
            "count": len(cluster_mems),
            "example_ids": [m["id"] for m in cluster_mems],
            "representative": best.get("name", ""),
            "importance_avg": round(imp_avg, 3),
        })

    return results


def _cluster_by_tags(corrections: list[dict]) -> list[list[int]]:
    """Fallback clustering when embeddings are unavailable — group by tag overlap."""
    tag_groups: defaultdict[str, list[int]] = defaultdict(list)
    for i, m in enumerate(corrections):
        tags = (m.get("tags") or "").strip()
        # Use first tag as group key, or 'untagged'
        key = tags.split(",")[0].strip().lower() if tags else "untagged"
        tag_groups[key].append(i)

    clusters = sorted(tag_groups.values(), key=len, reverse=True)
    return clusters


def cli_failures(args: list[str] | None = None) -> int:
    """CLI entry point for `aibrain failures`."""
    args = args or []
    n = 10
    if "-n" in args:
        idx = args.index("-n")
        if idx + 1 < len(args):
            try:
                n = int(args[idx + 1])
            except ValueError:
                pass

    modes = top_failure_modes(n=n)
    if not modes:
        print("  No correction memories found.")
        return 0

    total_corrections = sum(m["count"] for m in modes)
    print(f"\n  Top {len(modes)} Failure Modes ({total_corrections} corrections analyzed)")
    print(f"  {'=' * 60}")

    for i, mode in enumerate(modes, 1):
        pct = (mode["count"] / total_corrections * 100) if total_corrections else 0
        print(f"\n  {i}. {mode['pattern']}")
        print(f"     Count: {mode['count']} ({pct:.0f}%) | Avg importance: {mode['importance_avg']:.2f}")
        print(f"     Representative: {mode['representative']}")
        if len(mode["example_ids"]) <= 5:
            print(f"     Memory IDs: {mode['example_ids']}")
        else:
            print(f"     Memory IDs: {mode['example_ids'][:5]} ... (+{len(mode['example_ids']) - 5} more)")

    print()
    return 0
