"""Tests for brain_self_model.py — meta-cognition / knowledge map."""

import json
import sqlite3
import tempfile
import os
import pytest

from aibrain.core.brain_self_model import (
    knowledge_map,
    _classify_domain,
    _extract_tag_domains,
    cli_knowledge,
    EXPECTED_DOMAINS,
)


@pytest.fixture
def test_db(tmp_path):
    """Create a minimal aibrain.db with test memories."""
    db_path = str(tmp_path / "aibrain.db")
    conn = sqlite3.connect(db_path)
    conn.execute("""
        CREATE TABLE memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            type TEXT DEFAULT 'reference',
            tags TEXT DEFAULT '',
            content TEXT DEFAULT '',
            created TEXT,
            updated TEXT,
            active INTEGER DEFAULT 1,
            memory_class TEXT,
            importance REAL DEFAULT 0.5,
            access_count INTEGER DEFAULT 0,
            last_accessed TEXT,
            source_agent TEXT,
            consolidated_from TEXT,
            user_id TEXT,
            agent_id TEXT,
            storage_strength REAL,
            status TEXT DEFAULT 'active',
            superseded_by INTEGER,
            valid_from TEXT,
            valid_until TEXT
        )
    """)
    # Create vec table for embedding count
    conn.execute("""
        CREATE TABLE memories_vec_rowids (
            rowid INTEGER PRIMARY KEY,
            id INTEGER
        )
    """)

    # Insert test memories across domains
    test_memories = [
        ("vuln_scan_results", "reference", "security,auto-extracted", "Found XSS vulnerability in target"),
        ("exploit_chain_1", "discovery", "security,adversarial", "SQL injection exploit chain discovered"),
        ("cve_2026_1234", "reference", '["domain:security"]', "CVE-2026-1234 remote code execution"),
        ("architecture_decision", "decision", "domain:architecture", "Chose modular design pattern for plugin system"),
        ("system_refactor", "pattern", "architecture", "Refactoring the interface abstraction layer"),
        ("product_roadmap_q2", "project", "product,roadmap", "AIBrain v2.0 feature planning and pricing tiers"),
        ("deploy_workflow", "reference", "operations,devops", "Docker deployment pipeline for CI/CD"),
        ("git_merge_conflict", "fix", "git,auto-extracted", "Fixed merge conflict on rebase"),
        ("selroute_paper", "reference", "research,paper", "SelRoute benchmark evaluation on arxiv"),
        ("memory_consolidation", "pattern", "memory_system", "Brain consolidation and retention patterns"),
        ("archived_old", "reference", "old", "This is archived"),
    ]

    for name, mtype, tags, content in test_memories:
        status = "archived" if name == "archived_old" else "active"
        conn.execute(
            "INSERT INTO memories (name, type, tags, content, status) VALUES (?, ?, ?, ?, ?)",
            (name, mtype, tags, content, status),
        )

    # Add some vec rowids (simulate 8 of 11 embedded)
    for i in range(1, 9):
        conn.execute("INSERT INTO memories_vec_rowids (rowid, id) VALUES (?, ?)", (i, i))

    conn.commit()
    conn.close()
    return db_path


def test_knowledge_map_counts(test_db):
    """Test that knowledge_map returns correct total counts."""
    km = knowledge_map(db_path=test_db)
    assert km["total_active"] == 10  # 11 total minus 1 archived
    assert km["total_all"] == 11
    assert km["total_embedded"] == 8
    assert 0.0 < km["embedding_coverage"] < 1.0


def test_knowledge_map_domains(test_db):
    """Test that domain classification groups memories correctly."""
    km = knowledge_map(db_path=test_db)
    domains = km["by_domain"]

    # Security should have at least 3 (vuln_scan, exploit_chain, cve)
    assert "security" in domains
    assert domains["security"]["count"] >= 3

    # Architecture should be present
    assert "architecture" in domains
    assert domains["architecture"]["count"] >= 1


def test_knowledge_map_gaps(test_db):
    """Test that gap detection identifies missing domains."""
    km = knowledge_map(db_path=test_db)
    # With only 10 memories, threshold is ~1, so domains with 0 memories are gaps
    # marketing, trading, job_search should all be gaps (no test data for them)
    for gap_domain in ["marketing", "trading", "job_search"]:
        assert gap_domain in km["gaps"], f"{gap_domain} should be a gap"


def test_knowledge_map_depth_score(test_db):
    """Test depth score is between 0 and 1 and reflects coverage."""
    km = knowledge_map(db_path=test_db)
    assert 0.0 <= km["depth_score"] <= 1.0
    # We cover ~7 of 10 domains, so depth should be > 0.5
    assert km["depth_score"] > 0.5


def test_classify_domain_keywords():
    """Test the keyword-based domain classifier."""
    assert "security" in _classify_domain("Found XSS vulnerability")
    assert "git" in _classify_domain("git commit and push to repo")
    assert "uncategorized" in _classify_domain("random unrelated text")


def test_extract_tag_domains():
    """Test extraction of domain:X from tag strings."""
    assert _extract_tag_domains('["domain:security", "source:test"]') == ["security"]
    assert _extract_tag_domains("domain:architecture,other") == ["architecture"]
    assert _extract_tag_domains("") == []
    assert _extract_tag_domains(None) == []


def test_cli_json_output(test_db, capsys):
    """Test that CLI --json produces valid JSON."""
    result = cli_knowledge(["--json", "--db", test_db])
    assert result == 0
    captured = capsys.readouterr()
    data = json.loads(captured.out)
    assert "total_active" in data
    assert "by_domain" in data
    assert "gaps" in data


def test_knowledge_map_by_type(test_db):
    """Test that by_type breakdown is accurate."""
    km = knowledge_map(db_path=test_db)
    assert "reference" in km["by_type"]
    assert km["by_type"]["reference"] >= 3  # vuln_scan, cve, deploy, selroute


def test_knowledge_map_empty_db(tmp_path):
    """Test knowledge_map handles an empty database gracefully."""
    db_path = str(tmp_path / "empty.db")
    conn = sqlite3.connect(db_path)
    conn.execute("""
        CREATE TABLE memories (
            id INTEGER PRIMARY KEY, name TEXT, type TEXT, tags TEXT,
            content TEXT, status TEXT DEFAULT 'active'
        )
    """)
    conn.execute("CREATE TABLE memories_vec_rowids (rowid INTEGER PRIMARY KEY, id INTEGER)")
    conn.commit()
    conn.close()

    km = knowledge_map(db_path=db_path)
    assert km["total_active"] == 0
    assert km["depth_score"] == 0.0
    assert km["embedding_coverage"] == 0.0
