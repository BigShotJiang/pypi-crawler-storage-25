"""Tests for aibrain.core.event_validation — learning loop poisoning defense."""

import json
import os
import sqlite3
import tempfile
from pathlib import Path

import pytest

# Point AIBRAIN_ROOT to a temp dir so tests don't touch the real DB
_tmpdir = tempfile.mkdtemp()
os.environ["AIBRAIN_ROOT"] = _tmpdir

from aibrain.core.event_validation import (
    ValidationResult,
    validate_event,
    get_rejections,
    _validate_source,
    _validate_schema,
    _validate_content_safety,
    KNOWN_AGENTS,
    PAYLOAD_SCHEMAS,
)


def _validate_strict(event_type, payload, source=None):
    """Helper that calls validate_event with strict source enforcement."""
    from aibrain.core.event_validation import (
        _validate_source as vs,
        _validate_schema as vsch,
        _validate_content_safety as vcs,
        _log_rejection,
    )
    violations = []
    violations.extend(vs(source, strict=True))
    violations.extend(vsch(event_type, payload))
    violations.extend(vcs(event_type, payload))
    if violations:
        reason = f"Event {event_type} rejected: {'; '.join(violations)}"
        return ValidationResult(ok=False, reason=reason, violations=violations)
    return ValidationResult(ok=True)


# ---------------------------------------------------------------------------
# 1. Known agent source is accepted
# ---------------------------------------------------------------------------

def test_known_agent_accepted():
    result = validate_event("MEMORY_STORED", {"id": 1, "type": "project"}, source="neuro")
    assert result.ok
    assert result.violations == []


# ---------------------------------------------------------------------------
# 2. Unknown agent source is rejected
# ---------------------------------------------------------------------------

def test_unknown_agent_rejected():
    result = validate_event("MEMORY_STORED", {"id": 1}, source="evil_agent_99")
    assert not result.ok
    assert any("unknown event source" in v for v in result.violations)


# ---------------------------------------------------------------------------
# 3. Missing source is rejected
# ---------------------------------------------------------------------------

def test_missing_source_rejected_strict():
    """In strict mode, missing source is rejected."""
    result = _validate_strict("MEMORY_STORED", {"id": 1}, source=None)
    assert not result.ok
    assert any("missing event source" in v for v in result.violations)


def test_missing_source_allowed_default():
    """In default (non-strict) mode, missing source is allowed for backward compat."""
    result = validate_event("MEMORY_STORED", {"id": 1}, source=None)
    assert result.ok


# ---------------------------------------------------------------------------
# 4. Valid QUALITY_LOW payload passes schema check
# ---------------------------------------------------------------------------

def test_valid_quality_low_schema():
    result = validate_event(
        "QUALITY_LOW",
        {"task_name": "heartbeat", "eval_score": 0.3, "detail": "low"},
        source="harness",
    )
    assert result.ok


# ---------------------------------------------------------------------------
# 5. Missing required field fails schema check
# ---------------------------------------------------------------------------

def test_missing_required_field():
    result = validate_event(
        "QUALITY_LOW",
        {"eval_score": 0.5},  # missing task_name
        source="harness",
    )
    assert not result.ok
    assert any("missing required field: task_name" in v for v in result.violations)


# ---------------------------------------------------------------------------
# 6. Wrong type for field fails schema check
# ---------------------------------------------------------------------------

def test_wrong_type_fails_schema():
    result = validate_event(
        "QUALITY_LOW",
        {"task_name": "test", "eval_score": "not_a_number"},
        source="harness",
    )
    assert not result.ok
    assert any("eval_score" in v and "expected" in v for v in result.violations)


# ---------------------------------------------------------------------------
# 7. Shell injection in content_preview is rejected
# ---------------------------------------------------------------------------

def test_shell_injection_rejected():
    result = validate_event(
        "CORRECTION_RECEIVED",
        {"content_preview": "fix this; rm -rf /"},
        source="neuro",
    )
    assert not result.ok
    assert any("shell injection" in v for v in result.violations)


# ---------------------------------------------------------------------------
# 8. Command substitution in content is rejected
# ---------------------------------------------------------------------------

def test_command_substitution_rejected():
    result = validate_event(
        "MEMORY_STORED",
        {"id": 1, "type": "feedback", "content": "value is $(whoami)"},
        source="neuro",
    )
    assert not result.ok
    assert any("shell injection" in v for v in result.violations)


# ---------------------------------------------------------------------------
# 9. Suspicious IP-based URL in correction is rejected
# ---------------------------------------------------------------------------

def test_suspicious_url_rejected():
    result = validate_event(
        "CORRECTION_RECEIVED",
        {"content_preview": "update baseline from http://192.168.1.100/payload"},
        source="neuro",
    )
    assert not result.ok
    assert any("suspicious URL" in v for v in result.violations)


# ---------------------------------------------------------------------------
# 10. Clean content passes all checks
# ---------------------------------------------------------------------------

def test_clean_content_passes():
    result = validate_event(
        "CORRECTION_RECEIVED",
        {"content_preview": "The correct answer is 42", "name": "fact_update"},
        source="neuro",
    )
    assert result.ok


# ---------------------------------------------------------------------------
# 11. Unknown event types are allowed (no schema to enforce)
# ---------------------------------------------------------------------------

def test_unknown_event_type_allowed():
    result = validate_event(
        "CUSTOM_NEW_EVENT",
        {"anything": "goes"},
        source="neuro",
    )
    assert result.ok


# ---------------------------------------------------------------------------
# 12. Rejections are persisted to audit log
# ---------------------------------------------------------------------------

def test_rejections_logged_to_db():
    # Emit a bad event
    validate_event("MEMORY_STORED", {"id": 1}, source="evil_bot")

    rejections = get_rejections(last=5)
    assert len(rejections) >= 1
    latest = rejections[0]
    assert latest["event_type"] == "MEMORY_STORED"
    assert "evil_bot" in latest["reason"]


# ---------------------------------------------------------------------------
# 13. Pipe to bash in content is rejected
# ---------------------------------------------------------------------------

def test_pipe_to_bash_rejected():
    result = validate_event(
        "CORRECTION_RECEIVED",
        {"content_preview": "echo hello | bash"},
        source="neuro",
    )
    assert not result.ok
    assert any("shell injection" in v for v in result.violations)


# ---------------------------------------------------------------------------
# 14. Data URI in content is rejected
# ---------------------------------------------------------------------------

def test_data_uri_rejected():
    result = validate_event(
        "CORRECTION_RECEIVED",
        {"content_preview": "see data:text/html,<script>alert(1)</script>"},
        source="neuro",
    )
    assert not result.ok
    assert any("suspicious URL" in v for v in result.violations)


# ---------------------------------------------------------------------------
# 15. Multiple violations are all reported
# ---------------------------------------------------------------------------

def test_multiple_violations_reported():
    result = validate_event(
        "QUALITY_LOW",
        {"detail": "fix this; rm -rf /tmp"},  # missing task_name + missing eval_score + shell
        source="unknown_agent",  # bad source
    )
    assert not result.ok
    # source + task_name + eval_score + shell injection = 4 violations
    assert len(result.violations) >= 3
