"""
Unit tests for aibrain/core/profile_registry.py

These tests run entirely in a temp directory — they never touch the real
AIBRAIN_ROOT so they are safe to run in any environment.
"""

from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

# Ensure project root is importable
_REPO_ROOT = Path(__file__).resolve().parent.parent.parent.parent
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from aibrain.core import profile_registry


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def tmp_root(tmp_path, monkeypatch):
    """Redirect AIBRAIN_ROOT to a temp dir for each test."""
    monkeypatch.setenv("AIBRAIN_ROOT", str(tmp_path))
    # profile_registry resolves root lazily via os.environ — no patching needed
    yield tmp_path


# ---------------------------------------------------------------------------
# load_registry
# ---------------------------------------------------------------------------

class TestLoadRegistry:
    def test_missing_file_returns_empty_dict(self, tmp_root):
        """load_registry() returns {} when profiles.json doesn't exist — no FileNotFoundError."""
        result = profile_registry.load_registry()
        assert result == {}

    def test_missing_file_does_not_raise(self, tmp_root):
        """load_registry() never raises even if AIBRAIN_ROOT doesn't exist."""
        # Point to a dir that does not exist at all
        os.environ["AIBRAIN_ROOT"] = str(tmp_root / "nonexistent" / "subdir")
        try:
            result = profile_registry.load_registry()
            assert result == {}
        finally:
            os.environ["AIBRAIN_ROOT"] = str(tmp_root)

    def test_corrupt_file_returns_empty_dict(self, tmp_root):
        """load_registry() returns {} on JSON parse error — never raises."""
        profiles_path = tmp_root / "profiles.json"
        profiles_path.write_text("NOT VALID JSON{{{", encoding="utf-8")
        result = profile_registry.load_registry()
        assert result == {}

    def test_non_dict_json_returns_empty_dict(self, tmp_root):
        """load_registry() returns {} if root JSON value is not a dict."""
        profiles_path = tmp_root / "profiles.json"
        profiles_path.write_text(json.dumps([1, 2, 3]), encoding="utf-8")
        result = profile_registry.load_registry()
        assert result == {}


# ---------------------------------------------------------------------------
# save_registry / round-trip
# ---------------------------------------------------------------------------

class TestSaveRegistry:
    def test_round_trip_save_load(self, tmp_root):
        """save_registry + load_registry preserves exact data."""
        data = {
            "work": {"name": "work", "mode": "hive", "label": "Work brain", "db_path": None, "created": "2026-01-01T00:00:00Z"},
            "security": {"name": "security", "mode": "isolated", "label": None, "db_path": "/home/user/aibrain/aibrain_security.db", "created": "2026-01-02T00:00:00Z"},
        }
        profile_registry.save_registry(data)
        loaded = profile_registry.load_registry()
        assert loaded == data

    def test_atomic_write_creates_no_tmp_on_success(self, tmp_root):
        """After a successful save, no .tmp file is left behind."""
        profile_registry.save_registry({"test": {"name": "test", "mode": "hive", "label": None, "db_path": None, "created": "2026-01-01T00:00:00Z"}})
        tmp_file = tmp_root / "profiles.json.tmp"
        assert not tmp_file.exists(), "Stale .tmp file found after save"

    def test_save_creates_parent_dirs(self, tmp_root):
        """save_registry creates AIBRAIN_ROOT if it doesn't exist."""
        deep_root = tmp_root / "deep" / "nested"
        os.environ["AIBRAIN_ROOT"] = str(deep_root)
        try:
            profile_registry.save_registry({"x": {"name": "x", "mode": "hive", "label": None, "db_path": None, "created": "2026-01-01T00:00:00Z"}})
            assert (deep_root / "profiles.json").exists()
        finally:
            os.environ["AIBRAIN_ROOT"] = str(tmp_root)

    def test_empty_registry_round_trip(self, tmp_root):
        """save and reload an empty dict."""
        profile_registry.save_registry({})
        assert profile_registry.load_registry() == {}


# ---------------------------------------------------------------------------
# is_isolated
# ---------------------------------------------------------------------------

class TestIsIsolated:
    def test_returns_false_for_missing_entry(self, tmp_root):
        """is_isolated returns False for profiles not in registry (backward compat)."""
        assert profile_registry.is_isolated("nonexistent-profile") is False

    def test_returns_false_for_hive_profile(self, tmp_root):
        profile_registry.register_profile("work", mode="hive")
        assert profile_registry.is_isolated("work") is False

    def test_returns_true_for_isolated_profile(self, tmp_root):
        profile_registry.register_profile("security", mode="isolated", db_path="/tmp/aibrain_security.db")
        assert profile_registry.is_isolated("security") is True

    def test_returns_false_on_empty_registry(self, tmp_root):
        """is_isolated never raises when registry is missing."""
        assert profile_registry.is_isolated("anything") is False


# ---------------------------------------------------------------------------
# register_profile / get_profile_entry
# ---------------------------------------------------------------------------

class TestRegisterProfile:
    def test_register_hive_profile(self, tmp_root):
        entry = profile_registry.register_profile("work", mode="hive", label="Work")
        assert entry["mode"] == "hive"
        assert entry["label"] == "Work"
        assert entry["db_path"] is None

    def test_register_isolated_profile(self, tmp_root):
        db = "/home/user/aibrain/aibrain_sec.db"
        entry = profile_registry.register_profile("security", mode="isolated", db_path=db)
        assert entry["mode"] == "isolated"
        assert entry["db_path"] == db

    def test_upsert_preserves_created_timestamp(self, tmp_root):
        """Re-registering should not overwrite the original created timestamp."""
        entry1 = profile_registry.register_profile("work", mode="hive")
        original_created = entry1["created"]
        entry2 = profile_registry.register_profile("work", mode="hive", label="Updated")
        assert entry2["created"] == original_created

    def test_upsert_updates_label(self, tmp_root):
        profile_registry.register_profile("work", mode="hive", label="Old")
        entry = profile_registry.register_profile("work", mode="hive", label="New")
        assert entry["label"] == "New"

    def test_get_returns_none_for_missing(self, tmp_root):
        assert profile_registry.get_profile_entry("ghost") is None

    def test_get_returns_entry_for_registered(self, tmp_root):
        profile_registry.register_profile("work", mode="hive")
        entry = profile_registry.get_profile_entry("work")
        assert entry is not None
        assert entry["mode"] == "hive"


# ---------------------------------------------------------------------------
# unregister_profile
# ---------------------------------------------------------------------------

class TestUnregisterProfile:
    def test_unregister_existing_returns_true(self, tmp_root):
        profile_registry.register_profile("temp", mode="hive")
        assert profile_registry.unregister_profile("temp") is True
        assert profile_registry.get_profile_entry("temp") is None

    def test_unregister_missing_returns_false(self, tmp_root):
        assert profile_registry.unregister_profile("ghost") is False

    def test_unregister_does_not_affect_others(self, tmp_root):
        profile_registry.register_profile("work", mode="hive")
        profile_registry.register_profile("security", mode="isolated", db_path="/tmp/x.db")
        profile_registry.unregister_profile("work")
        assert profile_registry.get_profile_entry("security") is not None


# ---------------------------------------------------------------------------
# list_profiles
# ---------------------------------------------------------------------------

class TestListProfiles:
    def test_empty_registry_returns_empty_list(self, tmp_root):
        assert profile_registry.list_profiles() == []

    def test_sorted_by_name(self, tmp_root):
        profile_registry.register_profile("zebra", mode="hive")
        profile_registry.register_profile("alpha", mode="hive")
        profile_registry.register_profile("mango", mode="isolated", db_path="/tmp/m.db")
        names = [p["name"] for p in profile_registry.list_profiles()]
        assert names == sorted(names)

    def test_each_entry_has_name_field(self, tmp_root):
        profile_registry.register_profile("work", mode="hive")
        for entry in profile_registry.list_profiles():
            assert "name" in entry

    def test_returns_all_profiles(self, tmp_root):
        for i in range(5):
            profile_registry.register_profile(f"profile{i}", mode="hive")
        assert len(profile_registry.list_profiles()) == 5
