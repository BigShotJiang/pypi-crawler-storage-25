"""
Tests for aibrain/core/correction_baseline.py

Uses an in-memory SQLite DB — never touches the real aibrain.db.
"""

from __future__ import annotations

import sqlite3
import sys
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import patch

import pytest

_REPO_ROOT = Path(__file__).resolve().parent.parent.parent.parent
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from aibrain.core.correction_baseline import (
    CORRECTION_TYPES,
    _compute_trend,
    _sparkline,
    classify_domain,
    correction_baseline,
    store_baseline,
)


# ── Fixtures ─────────────────────────────────────────────────────

@pytest.fixture
def mem_db(tmp_path):
    """Create an in-memory-like temp DB with the required schema."""
    db_path = str(tmp_path / "test.db")
    conn = sqlite3.connect(db_path)
    conn.execute("""
        CREATE TABLE memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            type TEXT DEFAULT 'project',
            tags TEXT DEFAULT '',
            content TEXT DEFAULT '',
            created TEXT DEFAULT (datetime('now')),
            updated TEXT DEFAULT (datetime('now')),
            active INTEGER DEFAULT 1,
            memory_class TEXT DEFAULT 'semantic',
            importance REAL DEFAULT 0.5,
            access_count INTEGER DEFAULT 0,
            last_accessed TEXT,
            source_agent TEXT,
            consolidated_from TEXT,
            user_id TEXT DEFAULT '',
            agent_id TEXT DEFAULT '',
            storage_strength REAL DEFAULT 1.0,
            status VARCHAR(20) NOT NULL DEFAULT 'active',
            superseded_by INTEGER
        )
    """)
    conn.execute("""
        CREATE TABLE evolution_metrics (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            metric_name TEXT NOT NULL,
            metric_value REAL NOT NULL,
            source TEXT,
            period TEXT,
            recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()
    return db_path


def _insert_memory(db_path: str, content: str, mem_type: str, created: str):
    conn = sqlite3.connect(db_path)
    conn.execute(
        "INSERT INTO memories (name, type, content, created, active) "
        "VALUES (?, ?, ?, ?, 1)",
        (f"test_{mem_type}", mem_type, content, created),
    )
    conn.commit()
    conn.close()


# ── classify_domain ──────────────────────────────────────────────

def test_classify_domain_security():
    assert classify_domain("Found XSS vulnerability in login page") == "security"


def test_classify_domain_git():
    assert classify_domain("Need to git push after rebase") == "git"


def test_classify_domain_aibrain():
    assert classify_domain("The aibrain workflow harness failed") == "aibrain"


def test_classify_domain_other():
    assert classify_domain("Something completely unrelated here") == "other"


# ── _compute_trend ───────────────────────────────────────────────

def test_trend_learning():
    """Second half rate significantly lower than first -> learning."""
    windows = [
        {"bucket": 0, "corrections": 8, "total": 10, "rate": 0.80},
        {"bucket": 1, "corrections": 7, "total": 10, "rate": 0.70},
        {"bucket": 2, "corrections": 3, "total": 10, "rate": 0.30},
        {"bucket": 3, "corrections": 2, "total": 10, "rate": 0.20},
    ]
    assert _compute_trend(windows) == "learning"


def test_trend_regressing():
    """Second half rate significantly higher -> regressing."""
    windows = [
        {"bucket": 0, "corrections": 2, "total": 10, "rate": 0.20},
        {"bucket": 1, "corrections": 3, "total": 10, "rate": 0.30},
        {"bucket": 2, "corrections": 7, "total": 10, "rate": 0.70},
        {"bucket": 3, "corrections": 8, "total": 10, "rate": 0.80},
    ]
    assert _compute_trend(windows) == "regressing"


def test_trend_stable():
    """Rates stay roughly the same -> stable."""
    windows = [
        {"bucket": 0, "corrections": 5, "total": 10, "rate": 0.50},
        {"bucket": 1, "corrections": 5, "total": 10, "rate": 0.50},
        {"bucket": 2, "corrections": 5, "total": 10, "rate": 0.51},
        {"bucket": 3, "corrections": 5, "total": 10, "rate": 0.50},
    ]
    assert _compute_trend(windows) == "stable"


def test_trend_insufficient_data():
    """Single window -> insufficient_data."""
    windows = [{"bucket": 0, "corrections": 5, "total": 10, "rate": 0.50}]
    assert _compute_trend(windows) == "insufficient_data"


# ── _sparkline ───────────────────────────────────────────────────

def test_sparkline_ascending():
    result = _sparkline([0.0, 0.25, 0.5, 0.75, 1.0])
    assert len(result) == 5
    # First char should be lowest, last should be highest
    assert result[0] == " "
    assert result[-1] == "█"


def test_sparkline_empty():
    assert _sparkline([]) == ""


# ── correction_baseline integration ──────────────────────────────

def test_baseline_empty_db(mem_db):
    data = correction_baseline(days=30, db_path=mem_db)
    assert data["domains"] == {}
    assert data["summary"]["total_corrections"] == 0


def test_baseline_with_data(mem_db):
    """Insert corrections across 2 weeks and verify domain bucketing."""
    now = datetime.utcnow()
    week_ago = now - timedelta(days=7)

    # Week 1: 3 security corrections, 2 security non-corrections
    for i in range(3):
        _insert_memory(mem_db, "Found exploit in scanner", "correction",
                       (week_ago + timedelta(hours=i)).isoformat())
    for i in range(2):
        _insert_memory(mem_db, "Scan completed on target", "completion",
                       (week_ago + timedelta(hours=i + 3)).isoformat())

    # Week 2: 1 security correction, 4 security non-corrections
    for i in range(1):
        _insert_memory(mem_db, "Vulnerability false positive", "correction",
                       (now - timedelta(hours=i + 1)).isoformat())
    for i in range(4):
        _insert_memory(mem_db, "Attack chain validated", "completion",
                       (now - timedelta(hours=i + 2)).isoformat())

    data = correction_baseline(days=30, window_days=7, db_path=mem_db)

    assert "security" in data["domains"]
    sec = data["domains"]["security"]
    assert len(sec["windows"]) >= 1
    assert data["summary"]["total_corrections"] == 4


# ── store_baseline ───────────────────────────────────────────────

def test_store_baseline(mem_db):
    """Verify metrics are written to evolution_metrics."""
    now = datetime.utcnow()
    for i in range(5):
        _insert_memory(mem_db, "git push failed on remote", "correction",
                       (now - timedelta(days=i)).isoformat())
    for i in range(5):
        _insert_memory(mem_db, "git commit successful", "completion",
                       (now - timedelta(days=i)).isoformat())

    count = store_baseline(db_path=mem_db)
    assert count > 0

    conn = sqlite3.connect(mem_db)
    rows = conn.execute(
        "SELECT metric_name FROM evolution_metrics WHERE source='correction_baseline'"
    ).fetchall()
    conn.close()
    assert len(rows) == count
    names = [r[0] for r in rows]
    assert any("correction_rate_" in n for n in names)
