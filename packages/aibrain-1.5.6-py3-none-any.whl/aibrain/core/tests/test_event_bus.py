"""Tests for aibrain.core.event_bus — audit log and pub/sub."""

import json
import os
import sqlite3
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

# Point AIBRAIN_ROOT to a temp dir so tests don't touch the real DB
_tmpdir = tempfile.mkdtemp()
os.environ["AIBRAIN_ROOT"] = _tmpdir

from aibrain.core.event_bus import (
    EventTypes,
    clear_handlers,
    cli_events,
    count_by_type,
    emit,
    off,
    on,
    recent,
    _connect,
)


@pytest.fixture(autouse=True)
def _clean_state():
    """Reset handlers and clear DB between tests."""
    clear_handlers()
    # Wipe the event_bus_log table
    try:
        conn = _connect()
        conn.execute("DELETE FROM event_bus_log")
        conn.commit()
        conn.close()
    except Exception:
        pass
    yield
    clear_handlers()


# ---------------------------------------------------------------------------
# 1. emit writes to DB
# ---------------------------------------------------------------------------

def test_emit_persists_to_db():
    row_id = emit("TEST_EVENT", {"key": "value"})
    assert row_id is not None
    assert isinstance(row_id, int)

    conn = _connect()
    row = conn.execute(
        "SELECT event_type, payload FROM event_bus_log WHERE id = ?", (row_id,)
    ).fetchone()
    conn.close()

    assert row["event_type"] == "TEST_EVENT"
    payload = json.loads(row["payload"])
    assert payload["key"] == "value"


# ---------------------------------------------------------------------------
# 2. on() registers handlers that fire on emit
# ---------------------------------------------------------------------------

def test_handler_called_on_emit():
    received = []
    on("MY_EVENT", lambda p: received.append(p))

    emit("MY_EVENT", {"x": 1})

    assert len(received) == 1
    assert received[0]["x"] == 1


# ---------------------------------------------------------------------------
# 3. Handlers for different event types don't cross-fire
# ---------------------------------------------------------------------------

def test_handler_isolation():
    a_calls = []
    b_calls = []
    on("TYPE_A", lambda p: a_calls.append(p))
    on("TYPE_B", lambda p: b_calls.append(p))

    emit("TYPE_A", {"source": "a"})

    assert len(a_calls) == 1
    assert len(b_calls) == 0


# ---------------------------------------------------------------------------
# 4. off() removes a handler
# ---------------------------------------------------------------------------

def test_off_removes_handler():
    calls = []
    handler = lambda p: calls.append(p)
    on("REMOVABLE", handler)
    off("REMOVABLE", handler)

    emit("REMOVABLE", {})

    assert len(calls) == 0


# ---------------------------------------------------------------------------
# 5. recent() returns events in reverse chronological order
# ---------------------------------------------------------------------------

def test_recent_returns_events():
    emit("EVT_1", {"order": 1})
    emit("EVT_2", {"order": 2})
    emit("EVT_3", {"order": 3})

    events = recent(last=10)
    assert len(events) == 3
    # recent() returns newest first
    assert events[0]["event_type"] == "EVT_3"
    assert events[2]["event_type"] == "EVT_1"


# ---------------------------------------------------------------------------
# 6. recent() filters by event_type
# ---------------------------------------------------------------------------

def test_recent_filters_by_type():
    emit("ALPHA", {"n": 1})
    emit("BETA", {"n": 2})
    emit("ALPHA", {"n": 3})

    events = recent(last=10, event_type="ALPHA")
    assert len(events) == 2
    assert all(e["event_type"] == "ALPHA" for e in events)


# ---------------------------------------------------------------------------
# 7. count_by_type() aggregates correctly
# ---------------------------------------------------------------------------

def test_count_by_type():
    emit("X", {})
    emit("X", {})
    emit("Y", {})

    counts = count_by_type()
    assert counts["X"] == 2
    assert counts["Y"] == 1


# ---------------------------------------------------------------------------
# 8. EventTypes constants match expected names
# ---------------------------------------------------------------------------

def test_event_type_constants():
    assert EventTypes.MEMORY_STORED == "MEMORY_STORED"
    assert EventTypes.CORRECTION_RECEIVED == "CORRECTION_RECEIVED"
    assert EventTypes.QUALITY_LOW == "QUALITY_LOW"
    assert EventTypes.TASK_COMPLETED == "TASK_COMPLETED"
    assert EventTypes.WORKFLOW_EXECUTED == "WORKFLOW_EXECUTED"


# ---------------------------------------------------------------------------
# 9. emit with None payload defaults to empty dict
# ---------------------------------------------------------------------------

def test_emit_none_payload():
    row_id = emit("EMPTY", None)
    events = recent(last=1)
    assert len(events) == 1
    assert events[0]["payload"] == {}


# ---------------------------------------------------------------------------
# 10. Handler exception doesn't break emit
# ---------------------------------------------------------------------------

def test_handler_exception_doesnt_break_emit():
    def bad_handler(p):
        raise ValueError("boom")

    good_calls = []
    on("ROBUST", bad_handler)
    on("ROBUST", lambda p: good_calls.append(p))

    row_id = emit("ROBUST", {"test": True})

    # Event still logged
    assert row_id is not None
    # Good handler still called despite bad one
    assert len(good_calls) == 1


# ---------------------------------------------------------------------------
# 11. cli_events runs without error
# ---------------------------------------------------------------------------

def test_cli_events_no_crash(capsys):
    emit("CLI_TEST", {"msg": "hello"})
    ret = cli_events(["--last", "5"])
    assert ret == 0
    out = capsys.readouterr().out
    assert "CLI_TEST" in out


# ---------------------------------------------------------------------------
# 12. cli_events --summary works
# ---------------------------------------------------------------------------

def test_cli_events_summary(capsys):
    emit("SUM_A", {})
    emit("SUM_A", {})
    emit("SUM_B", {})
    ret = cli_events(["--summary"])
    assert ret == 0
    out = capsys.readouterr().out
    assert "SUM_A" in out
    assert "TOTAL" in out
