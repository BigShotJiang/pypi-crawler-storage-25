"""
Test Matrix 2: Hive concurrent writes (SQLite locking).

Simulates two Hive profiles sharing the same aibrain.db and performing
concurrent INSERT INTO memories.  Verifies:

  1. SQLite WAL mode handles concurrent writers without corruption
  2. All rows are persisted (no silent drops)
  3. Busy-timeout prevents immediate SQLITE_BUSY failures
  4. Read-while-write works correctly under WAL

Uses threading to simulate two profiles writing simultaneously.
"""
from __future__ import annotations

import os
import sqlite3
import threading
import time
from pathlib import Path

import pytest


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def test_db(tmp_path) -> Path:
    """Create a temporary SQLite database with the memories table schema."""
    db_path = tmp_path / 'test_aibrain.db'
    conn = sqlite3.connect(str(db_path))
    conn.execute('PRAGMA journal_mode=WAL;')
    conn.execute("""
        CREATE TABLE memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            type TEXT DEFAULT 'project',
            tags TEXT DEFAULT '',
            content TEXT DEFAULT '',
            created TEXT DEFAULT (datetime('now')),
            updated TEXT DEFAULT (datetime('now')),
            active INTEGER DEFAULT 1,
            memory_class TEXT DEFAULT 'semantic',
            importance REAL DEFAULT 0.5,
            access_count INTEGER DEFAULT 0,
            last_accessed TEXT,
            source_agent TEXT,
            consolidated_from TEXT,
            user_id TEXT DEFAULT '',
            agent_id TEXT DEFAULT '',
            storage_strength REAL DEFAULT 1.0,
            status VARCHAR(20) NOT NULL DEFAULT 'active',
            superseded_by INTEGER
        )
    """)
    conn.commit()
    conn.close()
    return db_path


def _get_connection(db_path: Path, busy_timeout: int = 5000) -> sqlite3.Connection:
    """Open a connection with WAL mode and busy timeout."""
    conn = sqlite3.connect(str(db_path), timeout=busy_timeout / 1000)
    conn.execute('PRAGMA journal_mode=WAL;')
    conn.execute(f'PRAGMA busy_timeout={busy_timeout};')
    return conn


# ---------------------------------------------------------------------------
# 1. Journal mode verification
# ---------------------------------------------------------------------------

class TestJournalMode:
    """Verify the database is using WAL mode."""

    def test_wal_mode_is_set(self, test_db):
        """New test DB should be in WAL mode."""
        conn = _get_connection(test_db)
        mode = conn.execute('PRAGMA journal_mode;').fetchone()[0]
        conn.close()
        assert mode.lower() == 'wal'

    def test_production_db_wal_mode(self):
        """The actual aibrain.db should be in WAL mode."""
        prod_db = Path('C:/Users/sinde/projects/aibrain/aibrain.db')
        if not prod_db.exists():
            pytest.skip('Production DB not found')
        conn = sqlite3.connect(str(prod_db))
        mode = conn.execute('PRAGMA journal_mode;').fetchone()[0]
        conn.close()
        assert mode.lower() == 'wal', (
            f'Production DB is in {mode} mode -- should be WAL for concurrent safety'
        )


# ---------------------------------------------------------------------------
# 2. Concurrent writes -- basic
# ---------------------------------------------------------------------------

class TestConcurrentWrites:
    """Two threads writing to the same table simultaneously."""

    def test_two_writers_no_data_loss(self, test_db):
        """Two profiles each insert 100 rows -- all 200 must be present."""
        errors: list[Exception] = []
        rows_per_writer = 100

        def writer(profile_id: str, count: int):
            try:
                conn = _get_connection(test_db)
                for i in range(count):
                    conn.execute(
                        'INSERT INTO memories (name, content, source_agent) VALUES (?, ?, ?)',
                        (f'mem_{profile_id}_{i}', f'content from {profile_id}', profile_id),
                    )
                    conn.commit()
                conn.close()
            except Exception as e:
                errors.append(e)

        t1 = threading.Thread(target=writer, args=('profile_A', rows_per_writer))
        t2 = threading.Thread(target=writer, args=('profile_B', rows_per_writer))

        t1.start()
        t2.start()
        t1.join(timeout=30)
        t2.join(timeout=30)

        assert not errors, f'Writer threads raised errors: {errors}'

        # Verify all rows present
        conn = _get_connection(test_db)
        total = conn.execute('SELECT COUNT(*) FROM memories').fetchone()[0]
        a_count = conn.execute(
            "SELECT COUNT(*) FROM memories WHERE source_agent='profile_A'"
        ).fetchone()[0]
        b_count = conn.execute(
            "SELECT COUNT(*) FROM memories WHERE source_agent='profile_B'"
        ).fetchone()[0]
        conn.close()

        assert total == rows_per_writer * 2, f'Expected {rows_per_writer * 2}, got {total}'
        assert a_count == rows_per_writer
        assert b_count == rows_per_writer

    def test_five_writers_no_data_loss(self, test_db):
        """Five concurrent writers, 50 rows each -- all 250 must persist."""
        errors: list[Exception] = []
        rows_per_writer = 50
        num_writers = 5

        def writer(profile_id: str, count: int):
            try:
                conn = _get_connection(test_db)
                for i in range(count):
                    conn.execute(
                        'INSERT INTO memories (name, content, source_agent) VALUES (?, ?, ?)',
                        (f'mem_{profile_id}_{i}', f'content from {profile_id}', profile_id),
                    )
                    conn.commit()
                conn.close()
            except Exception as e:
                errors.append(e)

        threads = []
        for w in range(num_writers):
            t = threading.Thread(target=writer, args=(f'writer_{w}', rows_per_writer))
            threads.append(t)

        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=60)

        assert not errors, f'Writer threads raised errors: {errors}'

        conn = _get_connection(test_db)
        total = conn.execute('SELECT COUNT(*) FROM memories').fetchone()[0]
        conn.close()

        assert total == num_writers * rows_per_writer


# ---------------------------------------------------------------------------
# 3. Concurrent read + write
# ---------------------------------------------------------------------------

class TestConcurrentReadWrite:
    """Reader and writer operating simultaneously under WAL."""

    def test_read_while_writing(self, test_db):
        """Reader must see a consistent snapshot while writer is active."""
        errors: list[Exception] = []
        read_counts: list[int] = []
        write_done = threading.Event()

        def writer():
            try:
                conn = _get_connection(test_db)
                for i in range(100):
                    conn.execute(
                        'INSERT INTO memories (name, content) VALUES (?, ?)',
                        (f'mem_{i}', f'content_{i}'),
                    )
                    conn.commit()
                conn.close()
                write_done.set()
            except Exception as e:
                errors.append(e)
                write_done.set()

        def reader():
            try:
                conn = _get_connection(test_db)
                while not write_done.is_set():
                    count = conn.execute('SELECT COUNT(*) FROM memories').fetchone()[0]
                    read_counts.append(count)
                    time.sleep(0.001)
                # Final read
                count = conn.execute('SELECT COUNT(*) FROM memories').fetchone()[0]
                read_counts.append(count)
                conn.close()
            except Exception as e:
                errors.append(e)

        t_writer = threading.Thread(target=writer)
        t_reader = threading.Thread(target=reader)

        t_reader.start()
        t_writer.start()
        t_writer.join(timeout=30)
        t_reader.join(timeout=30)

        assert not errors, f'Errors during read/write: {errors}'
        # Counts must be monotonically non-decreasing
        for i in range(1, len(read_counts)):
            assert read_counts[i] >= read_counts[i - 1], (
                f'Count decreased: {read_counts[i - 1]} -> {read_counts[i]} at index {i}'
            )
        # Final count should be 100
        assert read_counts[-1] == 100


# ---------------------------------------------------------------------------
# 4. Transaction isolation
# ---------------------------------------------------------------------------

class TestTransactionIsolation:
    """Verify WAL transaction isolation properties."""

    def test_uncommitted_writes_not_visible(self, test_db):
        """Uncommitted rows from one connection must not be visible to another."""
        conn_a = _get_connection(test_db)
        conn_b = _get_connection(test_db)

        conn_a.execute(
            'INSERT INTO memories (name, content) VALUES (?, ?)',
            ('uncommitted_mem', 'should not be visible'),
        )
        # Do NOT commit conn_a

        count_b = conn_b.execute('SELECT COUNT(*) FROM memories').fetchone()[0]
        assert count_b == 0, 'Uncommitted row visible to other connection'

        conn_a.commit()
        count_b = conn_b.execute('SELECT COUNT(*) FROM memories').fetchone()[0]
        assert count_b == 1, 'Committed row not visible after commit'

        conn_a.close()
        conn_b.close()

    def test_rollback_not_visible(self, test_db):
        """Rolled-back rows must never be visible."""
        conn_a = _get_connection(test_db)
        conn_b = _get_connection(test_db)

        conn_a.execute(
            'INSERT INTO memories (name, content) VALUES (?, ?)',
            ('rollback_mem', 'should disappear'),
        )
        conn_a.rollback()

        count_a = conn_a.execute('SELECT COUNT(*) FROM memories').fetchone()[0]
        count_b = conn_b.execute('SELECT COUNT(*) FROM memories').fetchone()[0]

        assert count_a == 0
        assert count_b == 0

        conn_a.close()
        conn_b.close()


# ---------------------------------------------------------------------------
# 5. Busy timeout behaviour
# ---------------------------------------------------------------------------

class TestBusyTimeout:
    """Verify busy-timeout prevents immediate failures."""

    def test_busy_timeout_allows_retry(self, test_db):
        """With busy_timeout set, a blocked writer should eventually succeed."""
        errors: list[Exception] = []
        barrier = threading.Barrier(2, timeout=10)

        def writer_a():
            try:
                conn = _get_connection(test_db, busy_timeout=10000)
                conn.execute('BEGIN IMMEDIATE')
                conn.execute(
                    'INSERT INTO memories (name, content) VALUES (?, ?)',
                    ('a_mem', 'from A'),
                )
                barrier.wait()  # Sync so both hold transactions
                time.sleep(0.1)  # Hold lock briefly
                conn.commit()
                conn.close()
            except Exception as e:
                errors.append(e)

        def writer_b():
            try:
                conn = _get_connection(test_db, busy_timeout=10000)
                barrier.wait()  # Wait for A to hold lock
                # This should block then succeed after A commits
                conn.execute(
                    'INSERT INTO memories (name, content) VALUES (?, ?)',
                    ('b_mem', 'from B'),
                )
                conn.commit()
                conn.close()
            except Exception as e:
                errors.append(e)

        t1 = threading.Thread(target=writer_a)
        t2 = threading.Thread(target=writer_b)
        t1.start()
        t2.start()
        t1.join(timeout=30)
        t2.join(timeout=30)

        assert not errors, f'Busy timeout failed: {errors}'

        conn = _get_connection(test_db)
        total = conn.execute('SELECT COUNT(*) FROM memories').fetchone()[0]
        conn.close()
        assert total == 2


# ---------------------------------------------------------------------------
# 6. Data integrity
# ---------------------------------------------------------------------------

class TestDataIntegrity:
    """Verify no corruption after concurrent operations."""

    def test_integrity_check_after_concurrent_writes(self, test_db):
        """PRAGMA integrity_check must pass after heavy concurrent writes."""
        errors: list[Exception] = []

        def writer(wid: int):
            try:
                conn = _get_connection(test_db)
                for i in range(50):
                    conn.execute(
                        'INSERT INTO memories (name, content, importance, source_agent) '
                        'VALUES (?, ?, ?, ?)',
                        (f'integ_{wid}_{i}', f'data_{wid}_{i}', 0.5 + (i * 0.001), f'w{wid}'),
                    )
                    conn.commit()
                conn.close()
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=writer, args=(w,)) for w in range(4)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=60)

        assert not errors, f'Writers failed: {errors}'

        conn = _get_connection(test_db)
        result = conn.execute('PRAGMA integrity_check;').fetchone()[0]
        total = conn.execute('SELECT COUNT(*) FROM memories').fetchone()[0]
        conn.close()

        assert result == 'ok', f'Integrity check failed: {result}'
        assert total == 200, f'Expected 200 rows, got {total}'

    def test_no_duplicate_ids(self, test_db):
        """AUTOINCREMENT IDs must be unique across concurrent writers."""
        errors: list[Exception] = []

        def writer(wid: int):
            try:
                conn = _get_connection(test_db)
                for i in range(30):
                    conn.execute(
                        'INSERT INTO memories (name, content) VALUES (?, ?)',
                        (f'dup_{wid}_{i}', f'data'),
                    )
                    conn.commit()
                conn.close()
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=writer, args=(w,)) for w in range(3)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=30)

        assert not errors

        conn = _get_connection(test_db)
        ids = [row[0] for row in conn.execute('SELECT id FROM memories').fetchall()]
        conn.close()

        assert len(ids) == len(set(ids)), 'Duplicate IDs detected'
        assert len(ids) == 90
