"""
multi_retrieval.py — Multi-strategy retrieval with Reciprocal Rank Fusion.

Combines BM25 (FTS5), semantic (vec similarity), and temporal scoring
into a unified ranked list using RRF fusion.

Usage:
    from aibrain.core.multi_retrieval import multi_search
    results = multi_search("how do I deploy?", k=10)
"""

from __future__ import annotations

import logging
import math
import sqlite3
import struct
import time
from typing import Optional

log = logging.getLogger("aibrain.multi_retrieval")


def multi_search(
    query: str,
    k: int = 10,
    rrf_k: int = 60,
    weights: Optional[dict] = None,
    db: Optional[sqlite3.Connection] = None,
) -> list[dict]:
    """Multi-strategy retrieval with RRF fusion.

    Runs three independent retrieval strategies:
      1. BM25 via FTS5 rank function
      2. Semantic via vec similarity (sqlite-vec)
      3. Temporal scoring: recent memories boosted, stale penalized

    Fuses them using Reciprocal Rank Fusion: score = sum(weight / (k + rank)).

    Args:
        query: Natural language search query.
        k: Number of results to return.
        rrf_k: RRF constant (default 60, standard value from the RRF paper).
        weights: Optional dict with keys 'bm25', 'semantic', 'temporal'.
                 Defaults to {'bm25': 1.0, 'semantic': 1.2, 'temporal': 0.8}.
        db: Optional database connection (uses aibrain_db.get_db() if None).

    Returns:
        List of memory dicts with 'rrf_score' and 'retrieval_methods' fields.
    """
    if db is None:
        import aibrain_db
        db = aibrain_db.get_db()

    w = weights or {"bm25": 1.0, "semantic": 1.2, "temporal": 0.8}
    pool = max(k * 3, 50)

    bm25_results = _bm25_search(db, query, pool)
    semantic_results = _semantic_search(db, query, pool)
    temporal_results = _temporal_search(db, query, pool)

    fused = _rrf_fuse(
        [bm25_results, semantic_results, temporal_results],
        rrf_k=rrf_k,
        weights=[w.get("bm25", 1.0), w.get("semantic", 1.2), w.get("temporal", 0.8)],
        labels=["bm25", "semantic", "temporal"],
    )

    return fused[:k]


def _bm25_search(db: sqlite3.Connection, query: str, limit: int) -> list[dict]:
    """BM25 scoring via FTS5 rank function."""
    fts_query = _prepare_fts_query(query)
    if not fts_query:
        return []
    try:
        sql = (
            "SELECT m.*, rank AS bm25_rank "
            "FROM memories m JOIN memories_fts f ON m.id=f.rowid "
            "WHERE memories_fts MATCH ? AND m.active=1 AND m.status = 'active' "
            "ORDER BY rank "  # FTS5 rank is negative, lower = better match
            "LIMIT ?"
        )
        rows = db.execute(sql, [fts_query, limit]).fetchall()
        return [dict(r) for r in rows]
    except sqlite3.OperationalError as e:
        log.debug("BM25 search failed: %s", e)
        # Fallback to LIKE
        try:
            return [dict(r) for r in db.execute(
                "SELECT * FROM memories WHERE active=1 AND status='active' AND "
                "(name LIKE ? OR content LIKE ?) ORDER BY updated DESC LIMIT ?",
                [f"%{query}%", f"%{query}%", limit],
            ).fetchall()]
        except Exception:
            return []


def _semantic_search(db: sqlite3.Connection, query: str, limit: int) -> list[dict]:
    """Semantic scoring via vec similarity."""
    try:
        from aibrain_db import _compute_embedding, _db_vec_enabled
    except ImportError:
        return []

    if not _db_vec_enabled:
        return []

    emb = _compute_embedding(query)
    if emb is None:
        return []

    emb_bytes = struct.pack(f"{len(emb)}f", *emb)
    try:
        rows = db.execute(
            "SELECT v.memory_id, v.distance FROM memories_vec v "
            "WHERE v.embedding MATCH ? AND k = ?",
            (emb_bytes, limit),
        ).fetchall()
        # Batch fetch — single IN() query instead of one SELECT per row (fixes N+1)
        id_distance = {row[0]: row[1] for row in rows}
        if not id_distance:
            return []
        placeholders = ",".join("?" * len(id_distance))
        mems = db.execute(
            f"SELECT * FROM memories WHERE id IN ({placeholders}) AND active=1 AND status='active'",
            list(id_distance.keys()),
        ).fetchall()
        results = []
        for mem in mems:
            d = dict(mem)
            d["vec_distance"] = id_distance[d["id"]]
            results.append(d)
        return results
    except Exception as e:
        log.debug("Semantic search failed: %s", e)
        return []


def _temporal_search(db: sqlite3.Connection, query: str, limit: int) -> list[dict]:
    """Temporal scoring: recent memories boosted, stale penalized.

    Score formula:
      temporal_score = recency_score * importance * validity_penalty

    Where:
      recency_score = 1.0 / (1.0 + days_since_update / 30)
      validity_penalty = 0.3 if valid_until IS NOT NULL (superseded), else 1.0
    """
    try:
        # Check if valid_until column exists
        cols = {r[1] for r in db.execute("PRAGMA table_info(memories)").fetchall()}
        has_validity = "valid_until" in cols

        if has_validity:
            sql = (
                "SELECT *, "
                "julianday('now') - julianday(COALESCE(updated, created)) AS days_old, "
                "CASE WHEN valid_until IS NOT NULL THEN 0.3 ELSE 1.0 END AS validity_penalty "
                "FROM memories WHERE active=1 AND status='active' "
                "ORDER BY updated DESC LIMIT ?"
            )
        else:
            sql = (
                "SELECT *, "
                "julianday('now') - julianday(COALESCE(updated, created)) AS days_old, "
                "1.0 AS validity_penalty "
                "FROM memories WHERE active=1 AND status='active' "
                "ORDER BY updated DESC LIMIT ?"
            )
        rows = db.execute(sql, [limit]).fetchall()
        results = []
        for r in rows:
            d = dict(r)
            days_old = d.pop("days_old", 0) or 0
            validity = d.pop("validity_penalty", 1.0)
            recency = 1.0 / (1.0 + max(days_old, 0) / 30.0)
            importance = float(d.get("importance", 0.5) or 0.5)
            d["temporal_score"] = recency * importance * validity
            results.append(d)
        # Sort by temporal_score descending
        results.sort(key=lambda x: x.get("temporal_score", 0), reverse=True)
        return results
    except Exception as e:
        log.debug("Temporal search failed: %s", e)
        return []


def _rrf_fuse(
    result_lists: list[list[dict]],
    rrf_k: int = 60,
    weights: Optional[list[float]] = None,
    labels: Optional[list[str]] = None,
) -> list[dict]:
    """Reciprocal Rank Fusion — combine multiple ranked lists.

    For each item in each list:
      rrf_contribution = weight / (rrf_k + rank + 1)

    Final score = sum of contributions across all lists.

    Args:
        result_lists: List of ranked result lists.
        rrf_k: Constant to prevent high-ranked items from dominating. Default 60.
        weights: Per-list weights. Defaults to [1.0, ...].
        labels: Per-list labels for provenance tracking.

    Returns:
        Fused list sorted by RRF score descending, with 'rrf_score'
        and 'retrieval_methods' fields added.
    """
    if weights is None:
        weights = [1.0] * len(result_lists)
    if labels is None:
        labels = [f"method_{i}" for i in range(len(result_lists))]

    scores: dict[int, float] = {}
    items: dict[int, dict] = {}
    methods: dict[int, list[str]] = {}

    for weight, results, label in zip(weights, result_lists, labels):
        for rank, mem in enumerate(results):
            mid = mem.get("id")
            if mid is None:
                continue
            rrf_score = weight / (rrf_k + rank + 1)
            scores[mid] = scores.get(mid, 0.0) + rrf_score
            if mid not in items:
                items[mid] = mem
            methods.setdefault(mid, []).append(label)

    # Attach metadata and sort
    fused = []
    for mid, score in scores.items():
        item = items[mid]
        item["rrf_score"] = round(score, 6)
        item["retrieval_methods"] = methods[mid]
        fused.append((score, item))

    fused.sort(key=lambda x: x[0], reverse=True)
    return [item for _, item in fused]


def _prepare_fts_query(query: str) -> str:
    """Prepare a query string for FTS5 MATCH.

    Wraps each word in quotes to handle special chars, joins with OR.
    """
    words = query.strip().split()
    if not words:
        return ""
    # Quote each term and join with OR for broad matching
    terms = [f'"{w}"' for w in words if len(w) > 1]
    return " OR ".join(terms) if terms else ""
