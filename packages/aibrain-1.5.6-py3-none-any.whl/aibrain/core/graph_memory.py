"""
graph_memory.py — Knowledge graph over brain memories using SQLite.

Provides a free local alternative to Mem0's graph memory ($249/mo).
Pure SQLite, zero new dependencies, auto-wires into memory storage.

Schema (added via aibrain_db._migrate_schema()):
  memory_relations (
    id TEXT PRIMARY KEY,
    from_memory_id TEXT NOT NULL REFERENCES memories(id),
    to_memory_id TEXT NOT NULL REFERENCES memories(id),
    relation_type TEXT NOT NULL,
    weight REAL NOT NULL DEFAULT 1.0,
    created_at TEXT DEFAULT (datetime('now')),
    UNIQUE(from_memory_id, to_memory_id, relation_type)
  )

Relation types:
  supports      — this memory provides evidence for another
  contradicts   — this memory conflicts with another
  refines       — this memory narrows/corrects another
  caused_by     — causal link (A caused B)
  related_to    — general keyword-overlap association (auto-link default)

API:
  add_relation(from_id, to_id, relation_type, weight=1.0) -> str
  get_relations(memory_id, direction="both") -> list[dict]
  get_neighbors(memory_id, depth=1, relation_types=None) -> list[dict]
  find_path(from_id, to_id, max_depth=3) -> list[str] | None
  auto_link(memory_id, content, top_n=3) -> int
"""

from __future__ import annotations

import logging
import os
import re
import sqlite3
import uuid
from collections import deque
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Valid relation types (enforced at Python level for portability with CHECK)
# ---------------------------------------------------------------------------

VALID_RELATION_TYPES = frozenset(
    {"supports", "contradicts", "refines", "caused_by", "related_to"}
)

# Keyword overlap threshold for auto_link
AUTO_LINK_THRESHOLD = 0.2

# Stopwords excluded from keyword overlap
_STOPWORDS = frozenset({
    "the", "a", "an", "and", "or", "but", "in", "on", "at", "to", "for",
    "of", "with", "by", "from", "up", "about", "into", "through", "during",
    "is", "are", "was", "were", "be", "been", "being", "have", "has", "had",
    "do", "does", "did", "will", "would", "could", "should", "may", "might",
    "must", "can", "that", "this", "these", "those", "i", "you", "he", "she",
    "it", "we", "they", "what", "which", "who", "when", "where", "why", "how",
    "all", "each", "both", "more", "most", "other", "some", "such", "no",
    "not", "only", "same", "than", "then", "too", "very", "just", "also",
    "as", "if", "so", "its", "their", "our", "your", "my", "his", "her",
})


# ---------------------------------------------------------------------------
# DB helpers
# ---------------------------------------------------------------------------

def _get_db() -> sqlite3.Connection:
    """Get the canonical AIBrain DB connection (row_factory set)."""
    import sys
    _root = Path(__file__).resolve().parent.parent.parent
    if str(_root) not in sys.path:
        sys.path.insert(0, str(_root))

    import aibrain_db
    db = sqlite3.connect(str(aibrain_db.AIBRAIN_ROOT / "aibrain.db"))
    db.row_factory = sqlite3.Row
    return db


def _ensure_schema(db: sqlite3.Connection) -> None:
    """Create memory_relations table + indexes if they don't exist."""
    db.executescript("""
        CREATE TABLE IF NOT EXISTS memory_relations (
            id TEXT PRIMARY KEY,
            from_memory_id INTEGER NOT NULL,
            to_memory_id INTEGER NOT NULL,
            relation_type TEXT NOT NULL
                CHECK (relation_type IN ('supports','contradicts','refines','caused_by','related_to')),
            weight REAL NOT NULL DEFAULT 1.0,
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            UNIQUE(from_memory_id, to_memory_id, relation_type)
        );
        CREATE INDEX IF NOT EXISTS idx_memory_relations_from ON memory_relations(from_memory_id);
        CREATE INDEX IF NOT EXISTS idx_memory_relations_to ON memory_relations(to_memory_id);
    """)
    db.commit()


# ---------------------------------------------------------------------------
# Tokenizer — mirrors decay_contradicted_memories approach
# ---------------------------------------------------------------------------

def _tokenize(text: str) -> set[str]:
    """Extract keywords (≥4 chars, not stopwords) from text."""
    words = re.findall(r"[a-z]{4,}", text.lower())
    return {w for w in words if w not in _STOPWORDS}


def _overlap_score(tokens_a: set[str], tokens_b: set[str]) -> float:
    """Jaccard-style overlap: intersection / union. Returns 0.0 if either is empty."""
    if not tokens_a or not tokens_b:
        return 0.0
    return len(tokens_a & tokens_b) / len(tokens_a | tokens_b)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def add_relation(
    from_id: int,
    to_id: int,
    relation_type: str,
    weight: float = 1.0,
    db: Optional[sqlite3.Connection] = None,
) -> str:
    """Add a directed relation between two memories.

    Args:
        from_id: Source memory ID (integer PK in memories table).
        to_id: Target memory ID.
        relation_type: One of VALID_RELATION_TYPES.
        weight: Relation strength 0.0–1.0 (default 1.0).
        db: Optional existing connection (uses canonical DB if None).

    Returns:
        The relation UUID string.

    Raises:
        ValueError: If relation_type is invalid.
        sqlite3.IntegrityError: If the (from, to, type) triple already exists.
    """
    if relation_type not in VALID_RELATION_TYPES:
        raise ValueError(
            f"Invalid relation_type {relation_type!r}. "
            f"Must be one of: {sorted(VALID_RELATION_TYPES)}"
        )

    _own_db = db is None
    if _own_db:
        db = _get_db()

    try:
        _ensure_schema(db)
        relation_id = str(uuid.uuid4())
        db.execute(
            "INSERT OR IGNORE INTO memory_relations "
            "(id, from_memory_id, to_memory_id, relation_type, weight, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (
                relation_id,
                from_id,
                to_id,
                relation_type,
                weight,
                datetime.now(timezone.utc).isoformat(),
            ),
        )
        db.commit()

        # Fetch the actual id — INSERT OR IGNORE may have skipped (already exists)
        row = db.execute(
            "SELECT id FROM memory_relations "
            "WHERE from_memory_id=? AND to_memory_id=? AND relation_type=?",
            (from_id, to_id, relation_type),
        ).fetchone()
        return row["id"] if row else relation_id
    finally:
        if _own_db:
            db.close()


def get_relations(
    memory_id: int,
    direction: str = "both",
    db: Optional[sqlite3.Connection] = None,
) -> list[dict]:
    """Get all relations involving a memory.

    Args:
        memory_id: The memory to look up.
        direction: "outbound" (from), "inbound" (to), or "both".
        db: Optional existing connection.

    Returns:
        List of relation dicts with keys:
          id, from_memory_id, to_memory_id, relation_type, weight, created_at,
          direction ('inbound'|'outbound')
    """
    _own_db = db is None
    if _own_db:
        db = _get_db()

    try:
        _ensure_schema(db)
        results = []

        if direction in ("outbound", "both"):
            rows = db.execute(
                "SELECT *, 'outbound' as direction FROM memory_relations "
                "WHERE from_memory_id = ?",
                (memory_id,),
            ).fetchall()
            results.extend(dict(r) for r in rows)

        if direction in ("inbound", "both"):
            rows = db.execute(
                "SELECT *, 'inbound' as direction FROM memory_relations "
                "WHERE to_memory_id = ?",
                (memory_id,),
            ).fetchall()
            results.extend(dict(r) for r in rows)

        return results
    finally:
        if _own_db:
            db.close()


def get_neighbors(
    memory_id: int,
    depth: int = 1,
    relation_types: Optional[list[str]] = None,
    db: Optional[sqlite3.Connection] = None,
) -> list[dict]:
    """Get neighboring memories up to `depth` hops away.

    Args:
        memory_id: Starting memory.
        depth: Number of hops (1 = direct neighbors only).
        relation_types: Filter to specific relation types (None = all).
        db: Optional existing connection.

    Returns:
        List of dicts with memory fields + 'hop' (distance) and 'relation_type'.
        Closest hop wins if a memory is reachable via multiple paths.
    """
    _own_db = db is None
    if _own_db:
        db = _get_db()

    try:
        _ensure_schema(db)

        # BFS over the relation graph
        visited: dict[int, int] = {}  # memory_id -> hop distance
        visited[memory_id] = 0
        queue: deque[tuple[int, int]] = deque([(memory_id, 0)])
        neighbor_rows: list[dict] = []

        while queue:
            current_id, current_hop = queue.popleft()
            if current_hop >= depth:
                continue

            # Build relation type filter
            type_clause = ""
            type_params: list = []
            if relation_types:
                placeholders = ",".join("?" * len(relation_types))
                type_clause = f" AND relation_type IN ({placeholders})"
                type_params = list(relation_types)

            # Outbound edges
            out_rows = db.execute(
                f"SELECT to_memory_id as neighbor_id, relation_type, weight "
                f"FROM memory_relations WHERE from_memory_id=?{type_clause}",
                [current_id] + type_params,
            ).fetchall()

            # Inbound edges
            in_rows = db.execute(
                f"SELECT from_memory_id as neighbor_id, relation_type, weight "
                f"FROM memory_relations WHERE to_memory_id=?{type_clause}",
                [current_id] + type_params,
            ).fetchall()

            for row in list(out_rows) + list(in_rows):
                nid = row["neighbor_id"]
                hop = current_hop + 1
                if nid not in visited:
                    visited[nid] = hop
                    queue.append((nid, hop))

                    # Fetch the actual memory
                    mem = db.execute(
                        "SELECT * FROM memories WHERE id=? AND active=1",
                        (nid,),
                    ).fetchone()
                    if mem:
                        d = dict(mem)
                        d["hop"] = hop
                        d["relation_type"] = row["relation_type"]
                        d["relation_weight"] = row["weight"]
                        neighbor_rows.append(d)

        return neighbor_rows
    finally:
        if _own_db:
            db.close()


def find_path(
    from_id: int,
    to_id: int,
    max_depth: int = 3,
    db: Optional[sqlite3.Connection] = None,
) -> Optional[list[int]]:
    """BFS shortest path between two memories.

    Args:
        from_id: Starting memory ID.
        to_id: Target memory ID.
        max_depth: Maximum hops to search.
        db: Optional existing connection.

    Returns:
        List of memory IDs forming the path (inclusive of start and end),
        or None if no path found within max_depth.
    """
    if from_id == to_id:
        return [from_id]

    _own_db = db is None
    if _own_db:
        db = _get_db()

    try:
        _ensure_schema(db)

        # BFS — store {node_id: parent_id} for path reconstruction
        parent: dict[int, Optional[int]] = {from_id: None}
        queue: deque[tuple[int, int]] = deque([(from_id, 0)])

        while queue:
            current_id, current_depth = queue.popleft()
            if current_depth >= max_depth:
                continue

            # Collect all neighbors (both directions)
            neighbors = db.execute(
                "SELECT to_memory_id as nid FROM memory_relations WHERE from_memory_id=? "
                "UNION "
                "SELECT from_memory_id as nid FROM memory_relations WHERE to_memory_id=?",
                (current_id, current_id),
            ).fetchall()

            for row in neighbors:
                nid = row["nid"]
                if nid not in parent:
                    parent[nid] = current_id
                    if nid == to_id:
                        # Reconstruct path
                        path = []
                        node: Optional[int] = to_id
                        while node is not None:
                            path.append(node)
                            node = parent[node]
                        path.reverse()
                        return path
                    queue.append((nid, current_depth + 1))

        return None  # No path found
    finally:
        if _own_db:
            db.close()


def auto_link(
    memory_id: int,
    content: str,
    top_n: int = 3,
    db: Optional[sqlite3.Connection] = None,
) -> int:
    """Auto-create 'related_to' edges by keyword overlap with existing memories.

    Args:
        memory_id: The newly-stored memory to link.
        content: Its text content (tokenized for overlap).
        top_n: Max candidates to consider (default 3 — keeps storage fast).
        db: Optional existing connection.

    Returns:
        Number of new relations created.
    """
    _own_db = db is None
    if _own_db:
        db = _get_db()

    try:
        _ensure_schema(db)

        tokens_new = _tokenize(content)
        if not tokens_new:
            return 0

        # Pull candidate memories via FTS keyword match (fast, no full scan)
        # Build a simple FTS query from top tokens
        top_tokens = sorted(tokens_new, key=len, reverse=True)[:10]
        fts_query = " OR ".join(top_tokens)

        try:
            # FTS candidates — active memories only, exclude self
            candidates = db.execute(
                "SELECT m.id, m.content FROM memories m "
                "JOIN memories_fts f ON m.id = f.rowid "
                "WHERE memories_fts MATCH ? AND m.active=1 AND m.id != ? "
                "ORDER BY rank LIMIT ?",
                (fts_query, memory_id, top_n * 3),  # over-fetch for filtering
            ).fetchall()
        except Exception:
            # FTS may fail on special chars — fall back to recent memories
            candidates = db.execute(
                "SELECT id, content FROM memories "
                "WHERE active=1 AND id != ? "
                "ORDER BY id DESC LIMIT ?",
                (memory_id, top_n * 3),
            ).fetchall()

        if not candidates:
            return 0

        # Score by overlap, take top_n above threshold
        scored = []
        for row in candidates:
            tokens_existing = _tokenize(row["content"] or "")
            score = _overlap_score(tokens_new, tokens_existing)
            if score >= AUTO_LINK_THRESHOLD:
                scored.append((score, row["id"]))

        # Sort descending, take top_n
        scored.sort(reverse=True)
        scored = scored[:top_n]

        created = 0
        for weight, related_id in scored:
            try:
                rel_id = str(uuid.uuid4())
                db.execute(
                    "INSERT OR IGNORE INTO memory_relations "
                    "(id, from_memory_id, to_memory_id, relation_type, weight, created_at) "
                    "VALUES (?, ?, ?, 'related_to', ?, ?)",
                    (
                        rel_id,
                        memory_id,
                        related_id,
                        round(weight, 4),
                        datetime.now(timezone.utc).isoformat(),
                    ),
                )
                # Check if row was actually inserted (OR IGNORE skips duplicates)
                if db.execute("SELECT changes()").fetchone()[0] > 0:
                    created += 1
            except Exception as exc:
                logger.debug("auto_link insert failed for %s->%s: %s", memory_id, related_id, exc)

        if created > 0:
            db.commit()

        return created
    finally:
        if _own_db:
            db.close()


# ---------------------------------------------------------------------------
# CLI helper — used by aibrain graph show <memory_id>
# ---------------------------------------------------------------------------

def cli_graph_show(memory_id: int, depth: int = 2) -> None:
    """Print graph neighbors for a memory up to depth 2."""
    db = _get_db()
    try:
        _ensure_schema(db)

        # Print the root memory
        root = db.execute(
            "SELECT id, name, type, content FROM memories WHERE id=?", (memory_id,)
        ).fetchone()
        if not root:
            print(f"  Memory {memory_id} not found.")
            return

        print()
        print(f"  Graph for memory {memory_id}: {root['name'][:80]}")
        print(f"  Type: {root['type']}")
        print()

        # Get direct relations
        relations = get_relations(memory_id, direction="both", db=db)
        if not relations:
            print("  No relations found.")
        else:
            print(f"  Direct relations ({len(relations)}):")
            for rel in relations:
                arrow = "-->" if rel["direction"] == "outbound" else "<--"
                peer_id = rel["to_memory_id"] if rel["direction"] == "outbound" else rel["from_memory_id"]
                peer = db.execute(
                    "SELECT name FROM memories WHERE id=?", (peer_id,)
                ).fetchone()
                peer_name = peer["name"][:60] if peer else f"[id={peer_id}]"
                print(
                    f"    [{rel['relation_type']:12s}] {arrow} ({peer_id}) {peer_name}  "
                    f"weight={rel['weight']:.3f}"
                )

        # Get 2-hop neighbors
        neighbors = get_neighbors(memory_id, depth=depth, db=db)
        if depth > 1 and neighbors:
            hop2 = [n for n in neighbors if n["hop"] == 2]
            if hop2:
                print()
                print(f"  2-hop neighbors ({len(hop2)}):")
                for n in hop2:
                    print(
                        f"    [{n['relation_type']:12s}] ({n['id']}) {n['name'][:60]}  "
                        f"hop={n['hop']}"
                    )
        print()
    finally:
        db.close()
