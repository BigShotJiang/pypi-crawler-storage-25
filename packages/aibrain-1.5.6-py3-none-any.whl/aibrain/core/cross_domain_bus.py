"""
cross_domain_bus.py — Cross-domain event bridge for AIBrain.

Accepts events from external products (Wintermute, Remediate, Permeate, etc.)
and maps them into the internal event bus. Events are validated through the
poisoning defense (event_validation.py) before dispatch.

Two ingestion modes:
  1. File-based queue: external product writes JSON to a drop directory,
     this module polls/reads and dispatches.
  2. Direct API: call ingest_external_event() from an HTTP handler or
     inter-process call.

Usage:
    from aibrain.core.cross_domain_bus import (
        register_external_source,
        ingest_external_event,
        ingest_from_file_queue,
    )

    # Whitelist what Wintermute can emit
    register_external_source("wintermute", [
        "WINTERMUTE_SCAN_COMPLETE",
        "WINTERMUTE_CHAIN_COMPLETE",
        "WINTERMUTE_FINDING",
    ])

    # Ingest a single event
    result = ingest_external_event("wintermute", "WINTERMUTE_SCAN_COMPLETE", {
        "target": "example.com", "findings": 12,
    })

    # Or poll the file queue
    processed = ingest_from_file_queue()
"""

from __future__ import annotations

import json
import logging
import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

log = logging.getLogger("aibrain.cross_domain_bus")

# ---------------------------------------------------------------------------
# External source registry
# ---------------------------------------------------------------------------

@dataclass
class ExternalSource:
    """Registered external product that can emit events."""
    product_name: str
    allowed_event_types: set[str] = field(default_factory=set)
    registered_at: float = field(default_factory=time.time)


# product_name → ExternalSource
_sources: dict[str, ExternalSource] = {}


def register_external_source(product_name: str, event_types: list[str]) -> ExternalSource:
    """Whitelist an external product and the event types it can emit.

    Args:
        product_name: Identifier for the external product (e.g. "wintermute").
        event_types: List of event type strings this product is allowed to emit.

    Returns:
        The registered ExternalSource.
    """
    if not product_name or not isinstance(product_name, str):
        raise ValueError("product_name must be a non-empty string")
    if not event_types:
        raise ValueError("event_types must be a non-empty list")

    source = ExternalSource(
        product_name=product_name.lower(),
        allowed_event_types=set(event_types),
    )
    _sources[source.product_name] = source
    log.info("Registered external source '%s' with events: %s",
             source.product_name, event_types)
    return source


def unregister_external_source(product_name: str) -> bool:
    """Remove an external source from the registry."""
    return _sources.pop(product_name.lower(), None) is not None


def get_registered_sources() -> dict[str, list[str]]:
    """Return a dict of product_name → list of allowed event types."""
    return {
        name: sorted(src.allowed_event_types)
        for name, src in _sources.items()
    }


def clear_sources() -> None:
    """Remove all registered external sources. For testing."""
    _sources.clear()


# ---------------------------------------------------------------------------
# Event type mapping: external → internal
# ---------------------------------------------------------------------------

# Maps external event types to internal AIBrain event types.
# If an external event type is not in this map, it passes through as-is.
EVENT_TYPE_MAP: dict[str, str] = {
    "WINTERMUTE_SCAN_COMPLETE": "SCAN_FINDING_STORED",
    "WINTERMUTE_CHAIN_COMPLETE": "SCAN_FINDING_STORED",
    "WINTERMUTE_FINDING": "SCAN_FINDING_STORED",
    "REMEDIATE_FIX_APPLIED": "TASK_COMPLETED",
    "REMEDIATE_FIX_FAILED": "QUALITY_LOW",
    "PERMEATE_SESSION_END": "WORKFLOW_EXECUTED",
}


def set_event_mapping(external_type: str, internal_type: str) -> None:
    """Add or update an external→internal event type mapping."""
    EVENT_TYPE_MAP[external_type] = internal_type


def get_event_mapping(external_type: str) -> str:
    """Resolve an external event type to its internal mapping.

    Returns the mapped internal type, or the original if no mapping exists.
    """
    return EVENT_TYPE_MAP.get(external_type, external_type)


# ---------------------------------------------------------------------------
# Ingestion result
# ---------------------------------------------------------------------------

@dataclass
class IngestResult:
    """Outcome of ingesting an external event."""
    ok: bool
    event_id: Optional[int] = None
    internal_event_type: Optional[str] = None
    reason: str = ""


# ---------------------------------------------------------------------------
# Core: ingest external event
# ---------------------------------------------------------------------------

def ingest_external_event(
    product_name: str,
    event_type: str,
    payload: dict | None = None,
) -> IngestResult:
    """Validate and dispatch an event from an external product.

    Steps:
      1. Check product is registered
      2. Check event type is whitelisted for this product
      3. Map external event type to internal type
      4. Validate through poisoning defense (event_validation.py)
      5. Emit on the internal event bus

    Args:
        product_name: The external product identifier.
        event_type: The external event type string.
        payload: Arbitrary event data.

    Returns:
        IngestResult with ok=True on success, or ok=False with reason.
    """
    payload = payload or {}
    product_key = product_name.lower()

    # 1. Check product is registered
    source = _sources.get(product_key)
    if source is None:
        return IngestResult(
            ok=False,
            reason=f"unknown external source: {product_name!r} — register with register_external_source() first",
        )

    # 2. Check event type is whitelisted
    if event_type not in source.allowed_event_types:
        return IngestResult(
            ok=False,
            reason=f"event type {event_type!r} not whitelisted for source {product_name!r}",
        )

    # 3. Map to internal event type
    internal_type = get_event_mapping(event_type)

    # 4. Validate payload through poisoning defense (schema + content safety)
    #    We validate here with source=None (lenient) because the external source
    #    is already whitelisted above. The event_bus.emit() will also validate,
    #    so we use source="backend" (a known agent) for the emit call.
    try:
        from aibrain.core.event_validation import validate_event
        # Validate schema and content safety only — source is already checked above
        result = validate_event(internal_type, payload, source=None)
        if not result.ok:
            return IngestResult(
                ok=False,
                reason=f"validation failed: {result.reason}",
            )
    except ImportError:
        pass  # validation module not available, allow through
    except Exception as e:
        log.debug("Cross-domain validation error (non-fatal): %s", e)

    # 5. Enrich payload with cross-domain metadata
    enriched_payload = {
        **payload,
        "_cross_domain": {
            "source_product": product_key,
            "original_event_type": event_type,
            "mapped_to": internal_type,
        },
    }

    # 6. Emit on internal bus using "backend" as source (recognized by event_validation)
    #    The cross-domain origin is preserved in the _cross_domain payload field.
    try:
        from aibrain.core.event_bus import emit as bus_emit
        event_id = bus_emit(internal_type, enriched_payload, source="backend")
        return IngestResult(
            ok=True,
            event_id=event_id,
            internal_event_type=internal_type,
        )
    except Exception as e:
        return IngestResult(
            ok=False,
            reason=f"emit failed: {e}",
        )


# ---------------------------------------------------------------------------
# File-based queue ingestion
# ---------------------------------------------------------------------------

def _get_queue_dir() -> Path:
    """Resolve the file-based event queue directory."""
    root = os.environ.get("AIBRAIN_ROOT", "")
    if root:
        return Path(root) / "event_queue"
    here = Path(__file__).resolve().parent
    for p in [here.parent.parent, here.parent]:
        candidate = p / "event_queue"
        if candidate.exists():
            return candidate
    # Default: create alongside aibrain.db (canonical location)
    from aibrain_db import AIBRAIN_ROOT
    return AIBRAIN_ROOT / "event_queue"


def ingest_from_file_queue(queue_dir: Path | None = None) -> list[IngestResult]:
    """Read and process all pending events from the file queue.

    Each file is a JSON object with:
        {"product": "wintermute", "event_type": "...", "payload": {...}}

    Processed files are moved to a 'processed' subdirectory.
    Failed files are moved to a 'failed' subdirectory.

    Args:
        queue_dir: Override queue directory (useful for testing).

    Returns:
        List of IngestResults for each processed file.
    """
    qdir = queue_dir or _get_queue_dir()
    if not qdir.exists():
        return []

    processed_dir = qdir / "processed"
    failed_dir = qdir / "failed"
    processed_dir.mkdir(parents=True, exist_ok=True)
    failed_dir.mkdir(parents=True, exist_ok=True)

    results = []
    for fpath in sorted(qdir.glob("*.json")):
        if not fpath.is_file():
            continue

        try:
            data = json.loads(fpath.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError) as e:
            log.warning("Failed to read queue file %s: %s", fpath.name, e)
            _safe_move(fpath, failed_dir / fpath.name)
            results.append(IngestResult(ok=False, reason=f"bad JSON in {fpath.name}: {e}"))
            continue

        product = data.get("product", "")
        event_type = data.get("event_type", "")
        payload = data.get("payload", {})

        if not product or not event_type:
            log.warning("Queue file %s missing product or event_type", fpath.name)
            _safe_move(fpath, failed_dir / fpath.name)
            results.append(IngestResult(ok=False, reason=f"missing fields in {fpath.name}"))
            continue

        result = ingest_external_event(product, event_type, payload)
        results.append(result)

        if result.ok:
            _safe_move(fpath, processed_dir / fpath.name)
        else:
            _safe_move(fpath, failed_dir / fpath.name)

    return results


def _safe_move(src: Path, dst: Path) -> None:
    """Move a file, overwriting destination if it exists."""
    try:
        if dst.exists():
            dst.unlink()
        src.rename(dst)
    except OSError as e:
        log.debug("Failed to move %s → %s: %s", src, dst, e)
