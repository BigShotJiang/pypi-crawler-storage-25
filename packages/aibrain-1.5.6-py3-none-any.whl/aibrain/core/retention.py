"""
retention.py — Memory retention policy for AIBrain (Breslow Recommendation 3).

Uses a continuous survival probability function rather than discrete retention
tiers. Every memory is scored by its actual Ebbinghaus decay curve; type acts
as a prior multiplier on that curve, not a categorical cutoff.

Algorithm:
    survival = type_prior * ebbinghaus_retention(elapsed_days, factors)

Where:
    - ebbinghaus_retention is computed via memory_decay.retention() using the
      memory's real importance, access_count, and confirmation_count signals.
    - type_prior is a multiplier in (0, 1.2] that shifts the curve up or down
      based on the memory type's expected longevity.
    - A single tuneable threshold (SURVIVAL_ARCHIVE_THRESHOLD = 0.10) replaces
      the old per-type day table.

This means a high-importance 'completion' memory survives where a low-
importance one does not — the actual content signals drive the decision, not
a blunt type category.

"Archive" means setting active=0. Data is never deleted — just hidden from
search results. Can be restored with `aibrain memory restore <id>`.

Usage:
    from aibrain.core.retention import apply_retention_policy
    stats = apply_retention_policy(dry_run=True)

    from aibrain.core.retention import memory_survival_probability
    prob = memory_survival_probability(mem_dict, now=datetime.utcnow())
"""

import logging
import math
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from aibrain.core.memory_decay import (
    DecayFactors,
    retention as ebbinghaus_retention,
    _parse_ts,
    _count_confirmations,
)

log = logging.getLogger("aibrain.retention")

# ---------------------------------------------------------------------------
# Tuneable constants
# ---------------------------------------------------------------------------

# Single archive threshold — replaces the old per-type day table.
# A memory whose survival probability drops below this is an archive candidate.
SURVIVAL_ARCHIVE_THRESHOLD: float = 0.10

# Type prior weights — multipliers on the decay curve, not categorical cutoffs.
# >1.0 shifts the curve upward (memory survives longer for a given elapsed time).
# <1.0 shifts the curve downward (memory decays faster toward the threshold).
# 1.0 = no shift (the Ebbinghaus curve alone decides).
TYPE_PRIOR_WEIGHTS: dict[str, float] = {
    # Strong positive prior — curated, high-value knowledge
    "user":     1.2,
    "feedback": 1.2,
    "pattern":  1.2,
    "skill":    1.2,

    # Neutral prior — structured knowledge, reasonable longevity
    "project":   1.0,
    "reference": 1.0,
    "decision":  1.0,

    # Weak positive prior (legacy kept for compatibility)
    "discovery": 1.0,

    # Negative prior — auto-generated, high-volume, lower expected longevity
    "completion": 0.8,
    "correction": 0.8,
    "fix":        0.8,

    # Strong negative prior — ephemeral session data
    "agent": 0.5,
}

# Prior for unknown types — neutral (the decay curve alone decides)
DEFAULT_TYPE_PRIOR: float = 1.0

# ---------------------------------------------------------------------------
# Legacy shim — keeps callers that imported RETENTION_POLICY working.
# Maps the old dict shape to the new one by approximation. New code should
# use TYPE_PRIOR_WEIGHTS + SURVIVAL_ARCHIVE_THRESHOLD directly.
# ---------------------------------------------------------------------------
RETENTION_POLICY: dict[str, Optional[int]] = {
    "user":       None,
    "feedback":   None,
    "pattern":    None,
    "skill":      None,
    "project":    90,
    "reference":  90,
    "decision":   90,
    "discovery":  30,
    "completion": 30,
    "correction": 30,
    "fix":        30,
    "agent":      7,
}

DEFAULT_RETENTION_DAYS: int = 60  # kept for callers that import this constant


# ---------------------------------------------------------------------------
# Core survival function
# ---------------------------------------------------------------------------


def memory_survival_probability(mem: dict, now: Optional[datetime] = None) -> float:
    """Compute a 0.0-1.0 survival probability for a single memory dict.

    The probability combines the Ebbinghaus decay curve (driven by the
    memory's real importance/access/confirmation signals) with a type-based
    prior multiplier. The result is clamped to [0, 1].

    Args:
        mem: A dict with at minimum the keys that a ``memories`` row carries.
             Required: 'type', plus any of 'importance', 'access_count',
             'last_accessed', 'created'. Missing fields are treated honestly
             (not faked) — the decay module skips unknown factors.
        now: Evaluation timestamp (UTC). Defaults to datetime.now(UTC).

    Returns:
        float in [0.0, 1.0]. Values below SURVIVAL_ARCHIVE_THRESHOLD are
        archive candidates.
    """
    if now is None:
        now = datetime.now(timezone.utc)
    elif now.tzinfo is None:
        now = now.replace(tzinfo=timezone.utc)

    # --- Elapsed time ---
    # Prefer last_accessed (memory has been reinforced); fall back to created.
    ref = _parse_ts(mem.get("last_accessed")) or _parse_ts(mem.get("created"))
    if ref is None:
        elapsed_days = 0.0
    else:
        elapsed_days = max(0.0, (now - ref).total_seconds() / 86400.0)

    # --- Ebbinghaus factors from actual signals ---
    factors = DecayFactors()

    ac = mem.get("access_count")
    if ac is not None:
        factors.access_frequency = int(ac)

    imp = mem.get("importance")
    if imp is not None:
        factors.importance = float(imp)

    # confirmation_count may be pre-joined into the dict or absent.
    cc = mem.get("confirmation_count")
    if cc is not None:
        factors.confirmation_count = int(cc)

    # emotional_salience — honest-None (not yet computed anywhere)
    factors.emotional_salience = None

    base_retention = ebbinghaus_retention(elapsed_days, factors)

    # --- Type prior ---
    mem_type = mem.get("type", "")
    prior = TYPE_PRIOR_WEIGHTS.get(mem_type, DEFAULT_TYPE_PRIOR)

    survival = prior * base_retention

    # Clamp to [0, 1] — prior can push above 1.0 for fresh high-prior memories.
    return max(0.0, min(1.0, survival))


# ---------------------------------------------------------------------------
# Batch survival scan (used by apply_retention_policy)
# ---------------------------------------------------------------------------


def _load_memories_for_retention(db: sqlite3.Connection) -> list[dict]:
    """Load all active memories with the columns needed for survival scoring."""
    cur = db.execute(
        """
        SELECT
            m.id,
            m.type,
            m.importance,
            m.access_count,
            m.last_accessed,
            m.created
        FROM memories m
        WHERE m.active = 1
        """
    )
    cols = [d[0] for d in cur.description]
    return [dict(zip(cols, row)) for row in cur.fetchall()]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def apply_retention_policy(
    db_path: Optional[str] = None,
    dry_run: bool = False,
    threshold: float = SURVIVAL_ARCHIVE_THRESHOLD,
) -> dict:
    """Apply survival-probability-based retention to all active memories.

    Memories whose survival probability falls below ``threshold`` are set
    inactive (active=0). The threshold defaults to SURVIVAL_ARCHIVE_THRESHOLD
    (0.10) and is the single tuneable knob replacing the old per-type day table.

    Args:
        db_path: Path to the SQLite DB. Defaults to the canonical aibrain.db.
        dry_run: If True, compute candidates but do NOT write to the DB.
        threshold: Survival probability below which a memory is archived.
                   Default: 0.10.

    Returns:
        dict with keys:
            archived     — {type: count} of archived (or would-be-archived) memories
            total_archived — int total
            dry_run      — bool
            threshold    — float threshold used
            policy       — human-readable type_prior summary
    """
    if db_path is None:
        from aibrain_db import AIBRAIN_ROOT  # type: ignore
        db_path = str(AIBRAIN_ROOT / "aibrain.db")

    db = sqlite3.connect(db_path)
    db.row_factory = sqlite3.Row

    now = datetime.now(timezone.utc)

    memories = _load_memories_for_retention(db)

    # Optionally join confirmation_count from memory_history if the table exists.
    # We attempt a single batch query; if the table is absent we skip gracefully.
    try:
        hist_cur = db.execute(
            """
            SELECT memory_id, COUNT(*) as cc
            FROM memory_history
            WHERE action IN ('correction','self_reflection','praise','reinforce','confirm')
            GROUP BY memory_id
            """
        )
        confirm_map = {row[0]: row[1] for row in hist_cur.fetchall()}
    except sqlite3.OperationalError:
        confirm_map = {}

    for mem in memories:
        if mem["id"] in confirm_map:
            mem["confirmation_count"] = confirm_map[mem["id"]]

    # Score and bucket
    archive_ids: list[int] = []
    archived: dict[str, int] = {}

    for mem in memories:
        prob = memory_survival_probability(mem, now=now)
        if prob < threshold:
            mem_id = mem["id"]
            mem_type = mem.get("type", "_unknown")
            archive_ids.append(mem_id)
            archived[mem_type] = archived.get(mem_type, 0) + 1
            log.debug(
                "Archive candidate id=%d type=%s survival=%.4f",
                mem_id, mem_type, prob,
            )

    total = len(archive_ids)

    if archive_ids and not dry_run:
        # Batch update in slices of 999 to stay under SQLite's variable limit.
        for i in range(0, len(archive_ids), 999):
            batch = archive_ids[i : i + 999]
            placeholders = ",".join("?" * len(batch))
            db.execute(
                f"UPDATE memories SET active=0, updated=datetime('now') "
                f"WHERE id IN ({placeholders})",
                batch,
            )
        db.commit()
        log.info("Retention applied: archived %d memories (threshold=%.2f)", total, threshold)
    elif dry_run:
        log.info(
            "Retention dry run: would archive %d memories (threshold=%.2f)",
            total, threshold,
        )

    db.close()

    return {
        "archived": archived,
        "total_archived": total,
        "dry_run": dry_run,
        "threshold": threshold,
        "policy": {
            k: f"prior={v:.1f}" for k, v in TYPE_PRIOR_WEIGHTS.items()
        },
    }


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="Apply survival-probability retention policy to memories"
    )
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--db", help="Database path")
    parser.add_argument(
        "--threshold",
        type=float,
        default=SURVIVAL_ARCHIVE_THRESHOLD,
        help=f"Survival probability threshold (default: {SURVIVAL_ARCHIVE_THRESHOLD})",
    )
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
    result = apply_retention_policy(
        db_path=args.db, dry_run=args.dry_run, threshold=args.threshold
    )

    print(f"\nRetention {'preview' if args.dry_run else 'applied'} "
          f"(threshold={result['threshold']:.2f}):")
    for mem_type, count in result["archived"].items():
        print(f"  {mem_type}: {count} archived")
    print(f"  Total: {result['total_archived']}")
