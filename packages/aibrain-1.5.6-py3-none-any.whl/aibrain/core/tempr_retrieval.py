"""
tempr_retrieval.py — TEMPR hybrid retrieval with 4-channel RRF fusion.

TEMPR = Temporal + Entity-graph + Matching (BM25) + Passage + Reciprocal-rank
(the acronym comes from the Hindsight intel report 2026-04-11 — see
decker_system/00_meta/intel_reports/hindsight_v2026_04_current_analysis.md §3.1).

Four parallel retrieval channels, fused via Reciprocal Rank Fusion:
  1. Semantic via existing vec store (bge-base / MiniLM embeddings)
  2. BM25 via sqlite-fts5 (memories_fts)
  3. Graph walk via recursive CTE on entity_links (seeded from channels 1 & 2)
  4. Temporal — recency-boosted, importance-weighted, validity-penalized

This is an OPT-IN alternative to the existing multi_retrieval.multi_search.
Existing behaviour is untouched: callers get TEMPR only when they ask for it.

Usage:
    from aibrain.core.tempr_retrieval import TEMPRRetriever
    retr = TEMPRRetriever(db=conn)
    hits = retr.retrieve("how do I deploy to production?", k=10)

All OSS, no paid dependencies.
"""

from __future__ import annotations

import logging
import sqlite3
import struct
from typing import Optional

log = logging.getLogger("aibrain.tempr")

# ---------------------------------------------------------------------------
# Defaults — tuned for the RRF paper's canonical constant k=60
# ---------------------------------------------------------------------------

DEFAULT_WEIGHTS = {
    "semantic": 1.2,
    "bm25": 1.0,
    "graph": 0.7,
    "temporal": 0.8,
}
DEFAULT_RRF_K = 60
DEFAULT_POOL_MULT = 3  # per-channel pool = max(k * mult, 50)
DEFAULT_GRAPH_DEPTH = 2  # how many hops to walk from seed memories


class TEMPRRetriever:
    """4-channel hybrid retriever — semantic + BM25 + graph + temporal, RRF-fused.

    Intentionally stateless beyond the DB handle and weights so it's safe to
    share across threads / reuse across queries. No background threads, no
    caches — if you want caching, wrap this class.
    """

    def __init__(
        self,
        db: Optional[sqlite3.Connection] = None,
        weights: Optional[dict] = None,
        rrf_k: int = DEFAULT_RRF_K,
        graph_depth: int = DEFAULT_GRAPH_DEPTH,
    ) -> None:
        self._external_db = db
        self.weights = {**DEFAULT_WEIGHTS, **(weights or {})}
        self.rrf_k = rrf_k
        self.graph_depth = max(1, int(graph_depth))

    # ----- public API ------------------------------------------------------

    def retrieve(self, query: str, k: int = 10) -> list[dict]:
        """Run all 4 channels, RRF-fuse, return top-k memories.

        Returns dicts with the usual memory columns plus:
          rrf_score (float) — final RRF score
          retrieval_methods (list[str]) — which channels contributed
        """
        if not query or not query.strip():
            return []

        db = self._get_db()
        pool = max(k * DEFAULT_POOL_MULT, 50)

        semantic = self._channel_semantic(db, query, pool)
        bm25 = self._channel_bm25(db, query, pool)
        # Graph channel is seeded by the top hits from semantic + bm25 so it
        # only walks from relevant nodes, not every memory in the DB.
        seeds = _seed_ids(semantic, bm25, limit=max(10, k))
        graph = self._channel_graph(db, seeds, pool)
        temporal = self._channel_temporal(db, pool)

        fused = _rrf_fuse(
            [semantic, bm25, graph, temporal],
            rrf_k=self.rrf_k,
            weights=[
                self.weights["semantic"],
                self.weights["bm25"],
                self.weights["graph"],
                self.weights["temporal"],
            ],
            labels=["semantic", "bm25", "graph", "temporal"],
        )
        return fused[:k]

    # ----- channels --------------------------------------------------------

    def _channel_semantic(
        self, db: sqlite3.Connection, query: str, limit: int
    ) -> list[dict]:
        """Channel 1 — dense vector similarity via sqlite-vec."""
        try:
            from aibrain_db import _compute_embedding, _db_vec_enabled
        except Exception:
            return []
        if not _db_vec_enabled:
            return []
        emb = _compute_embedding(query)
        if emb is None:
            return []
        emb_bytes = struct.pack(f"{len(emb)}f", *emb)
        try:
            rows = db.execute(
                "SELECT v.memory_id, v.distance FROM memories_vec v "
                "WHERE v.embedding MATCH ? AND k = ?",
                (emb_bytes, limit),
            ).fetchall()
        except Exception as exc:
            log.debug("TEMPR semantic channel failed: %s", exc)
            return []
        # Batch fetch — single IN() query instead of one SELECT per row (fixes N+1)
        id_distance = {row[0]: row[1] for row in rows}
        if not id_distance:
            return []
        placeholders = ",".join("?" * len(id_distance))
        mems = db.execute(
            f"SELECT * FROM memories WHERE id IN ({placeholders}) AND active=1 AND status='active'",
            list(id_distance.keys()),
        ).fetchall()
        out: list[dict] = []
        for mem in mems:
            d = dict(mem)
            d["vec_distance"] = id_distance[d["id"]]
            out.append(d)
        return out

    def _channel_bm25(
        self, db: sqlite3.Connection, query: str, limit: int
    ) -> list[dict]:
        """Channel 2 — BM25 via FTS5 rank function."""
        fts_query = _prepare_fts_query(query)
        if not fts_query:
            return []
        try:
            rows = db.execute(
                "SELECT m.*, rank AS bm25_rank "
                "FROM memories m JOIN memories_fts f ON m.id=f.rowid "
                "WHERE memories_fts MATCH ? AND m.active=1 AND m.status='active' "
                "ORDER BY rank LIMIT ?",
                [fts_query, limit],
            ).fetchall()
            return [dict(r) for r in rows]
        except sqlite3.DatabaseError as exc:
            # Both OperationalError (bad FTS query) and DatabaseError
            # (corrupt FTS index on DB copy) fall back to LIKE so the
            # other three channels can still fuse something useful.
            log.debug("TEMPR bm25 channel fell back to LIKE: %s", exc)
            try:
                rows = db.execute(
                    "SELECT * FROM memories WHERE active=1 AND status='active' AND "
                    "(name LIKE ? OR content LIKE ?) ORDER BY updated DESC LIMIT ?",
                    [f"%{query}%", f"%{query}%", limit],
                ).fetchall()
                return [dict(r) for r in rows]
            except Exception:
                return []

    def _channel_graph(
        self, db: sqlite3.Connection, seed_ids: list[int], limit: int
    ) -> list[dict]:
        """Channel 3 — recursive CTE walk on entity_links from seed memories.

        Seed memories come from the semantic + BM25 channels, so we're
        expanding relevant neighbourhoods only. Walks up to ``graph_depth``
        hops, ranking by shortest distance then memory importance.

        If entity_links doesn't exist (fresh DBs) or there are no seeds,
        returns empty and lets RRF carry on with the other channels.
        """
        if not seed_ids:
            return []
        # Verify entity_links exists — skip channel cleanly on minimal DBs.
        try:
            db.execute("SELECT 1 FROM entity_links LIMIT 1").fetchone()
        except sqlite3.OperationalError:
            return []

        placeholders = ",".join("?" for _ in seed_ids)
        depth = self.graph_depth
        # Note the repeated `placeholders` block — we exclude seed IDs
        # from final results, because walking a tight neighbourhood will
        # re-visit seeds at dist ≥ 2 through backlinks, and those are
        # already ranked by the semantic/bm25 channels.
        cte = f"""
        WITH RECURSIVE walk(mem_id, dist) AS (
            SELECT id, 0 FROM memories
             WHERE id IN ({placeholders})
               AND active=1 AND status='active'
            UNION
            SELECT el.target_id, w.dist + 1
              FROM entity_links el
              JOIN walk w ON w.mem_id = el.source_id
             WHERE el.source_type='memory' AND el.target_type='memory'
               AND w.dist < ?
            UNION
            SELECT el.source_id, w.dist + 1
              FROM entity_links el
              JOIN walk w ON w.mem_id = el.target_id
             WHERE el.source_type='memory' AND el.target_type='memory'
               AND w.dist < ?
        )
        SELECT m.*, MIN(w.dist) AS graph_dist
          FROM walk w
          JOIN memories m ON m.id = w.mem_id
         WHERE m.active=1 AND m.status='active'
           AND m.id NOT IN ({placeholders})
         GROUP BY m.id
         ORDER BY graph_dist ASC, m.importance DESC
         LIMIT ?
        """
        params = list(seed_ids) + [depth, depth] + list(seed_ids) + [limit]
        try:
            rows = db.execute(cte, params).fetchall()
            return [dict(r) for r in rows]
        except sqlite3.OperationalError as exc:
            log.debug("TEMPR graph channel failed: %s", exc)
            return []

    def _channel_temporal(
        self, db: sqlite3.Connection, limit: int
    ) -> list[dict]:
        """Channel 4 — recency * importance * validity penalty.

        Note: this channel is query-agnostic by design — its job is to
        surface "what matters lately", not "what matches the query". The
        RRF fusion takes care of combining it with the lexical/dense
        channels. Unlike multi_retrieval._temporal_search, TEMPR applies
        a 14-day recency horizon (Hindsight report's tuned value), not 30.
        """
        try:
            cols = {r[1] for r in db.execute("PRAGMA table_info(memories)").fetchall()}
            has_validity = "valid_until" in cols
            validity_expr = (
                "CASE WHEN valid_until IS NOT NULL THEN 0.3 ELSE 1.0 END"
                if has_validity
                else "1.0"
            )
            sql = (
                f"SELECT *, "
                f"julianday('now') - julianday(COALESCE(updated, created)) AS days_old, "
                f"{validity_expr} AS validity_penalty "
                f"FROM memories WHERE active=1 AND status='active' "
                f"ORDER BY updated DESC LIMIT ?"
            )
            rows = db.execute(sql, [limit]).fetchall()
            out: list[dict] = []
            for r in rows:
                d = dict(r)
                days_old = d.pop("days_old", 0) or 0
                validity = d.pop("validity_penalty", 1.0)
                # 14-day horizon vs 30-day in multi_retrieval — TEMPR rewards
                # very-recent heavily, which is where the recall lift comes from.
                recency = 1.0 / (1.0 + max(days_old, 0) / 14.0)
                importance = float(d.get("importance", 0.5) or 0.5)
                d["temporal_score"] = recency * importance * validity
                out.append(d)
            out.sort(key=lambda x: x.get("temporal_score", 0), reverse=True)
            return out
        except sqlite3.OperationalError as exc:
            log.debug("TEMPR temporal channel failed: %s", exc)
            return []

    # ----- helpers ---------------------------------------------------------

    def _get_db(self) -> sqlite3.Connection:
        if self._external_db is not None:
            return self._external_db
        import aibrain_db
        return aibrain_db.get_db()


# ---------------------------------------------------------------------------
# Module-level helpers (reused by tests and benchmark harness)
# ---------------------------------------------------------------------------

def _seed_ids(
    *result_lists: list[dict], limit: int = 10
) -> list[int]:
    """Collect unique memory IDs from the top of each result list.

    Used to seed the graph walk with "already plausibly relevant" memories
    rather than the whole DB. Preserves round-robin ordering across lists
    so no single channel dominates the seed set.
    """
    seen: set[int] = set()
    ordered: list[int] = []
    # Take first of each list, then second of each, etc — round robin.
    i = 0
    while len(ordered) < limit:
        added_this_round = False
        for lst in result_lists:
            if i < len(lst):
                mid = lst[i].get("id")
                if mid is not None and mid not in seen:
                    seen.add(mid)
                    ordered.append(mid)
                    added_this_round = True
                    if len(ordered) >= limit:
                        break
        if not added_this_round:
            break
        i += 1
    return ordered


def _rrf_fuse(
    result_lists: list[list[dict]],
    rrf_k: int = DEFAULT_RRF_K,
    weights: Optional[list[float]] = None,
    labels: Optional[list[str]] = None,
) -> list[dict]:
    """Reciprocal Rank Fusion — combine N ranked lists.

    For each item in each list:
        contribution = weight / (rrf_k + rank + 1)
    Final score is the sum across lists. Standard Cormack et al. formulation.

    Kept deliberately in-sync with multi_retrieval._rrf_fuse — if one moves,
    the other should move too.
    """
    if weights is None:
        weights = [1.0] * len(result_lists)
    if labels is None:
        labels = [f"method_{i}" for i in range(len(result_lists))]

    scores: dict[int, float] = {}
    items: dict[int, dict] = {}
    methods: dict[int, list[str]] = {}

    for weight, results, label in zip(weights, result_lists, labels):
        for rank, mem in enumerate(results):
            mid = mem.get("id")
            if mid is None:
                continue
            contribution = weight / (rrf_k + rank + 1)
            scores[mid] = scores.get(mid, 0.0) + contribution
            if mid not in items:
                items[mid] = mem
            methods.setdefault(mid, []).append(label)

    fused: list[tuple[float, dict]] = []
    for mid, score in scores.items():
        item = items[mid]
        item["rrf_score"] = round(score, 6)
        item["retrieval_methods"] = methods[mid]
        fused.append((score, item))
    fused.sort(key=lambda x: x[0], reverse=True)
    return [item for _, item in fused]


def _prepare_fts_query(query: str) -> str:
    """Quote each term, join with OR — same as multi_retrieval for consistency."""
    words = query.strip().split()
    if not words:
        return ""
    terms = [f'"{w}"' for w in words if len(w) > 1]
    return " OR ".join(terms) if terms else ""
