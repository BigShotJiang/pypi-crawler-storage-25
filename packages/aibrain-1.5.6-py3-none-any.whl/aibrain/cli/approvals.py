"""
aibrain.cli.approvals — Interactive approvals menu.

Modeled exactly on the compress config menu pattern that works.
"""
from __future__ import annotations

import os
import sqlite3
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

_DB_PATH: Path | None = None


def _db_path() -> Path:
    """Resolve the aibrain.db path via the canonical resolver — see aibrain_db.AIBRAIN_ROOT."""
    global _DB_PATH
    if _DB_PATH is None:
        from aibrain_db import AIBRAIN_ROOT
        _DB_PATH = AIBRAIN_ROOT / "aibrain.db"
    return _DB_PATH


def _set_db_path(p: Path) -> None:
    global _DB_PATH
    _DB_PATH = p


def load_pending() -> list[dict[str, Any]]:
    conn = sqlite3.connect(str(_db_path()))
    conn.row_factory = sqlite3.Row
    rows = conn.execute(
        "SELECT id, created, category, title, detail "
        "FROM approvals WHERE status='pending' ORDER BY category, created"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def _update_status(ids: list[int], status: str) -> int:
    if not ids:
        return 0
    conn = sqlite3.connect(str(_db_path()))
    now = datetime.now(timezone.utc).isoformat()
    placeholders = ",".join("?" for _ in ids)
    conn.execute(
        f"UPDATE approvals SET status=?, decided_at=?, updated=? "
        f"WHERE id IN ({placeholders})",
        [status, now, now] + ids,
    )
    conn.commit()
    conn.close()
    return len(ids)


PAGE = 10
# Backward-compat alias for older tests that import PAGE_SIZE.
PAGE_SIZE = PAGE


def _render(items, page, focused, checked):
    n = len(items)
    total_pages = max(1, (n + PAGE - 1) // PAGE)
    p = min(page, total_pages - 1)
    start = p * PAGE
    end = min(start + PAGE, n)
    page_items = items[start:end]

    lines = [
        '',
        f'  Pending Approvals  ({n} items, {len(checked)} checked)  page {p+1}/{total_pages}',
        f'  SPACE=toggle  A=approve checked  R=reject checked  S=select page  P=next page  Q=quit',
        '',
    ]
    for i, item in enumerate(page_items):
        idx = start + i
        mk = 'x' if item['id'] in checked else ' '
        cur = '>' if idx == focused else ' '
        title = (item.get('title') or '?')[:70]
        lines.append(f'  {cur} [{mk}] {idx+1:>3}. {title}')

    # Pad to fixed height so redraw doesn't leave artifacts
    while len(lines) < PAGE + 5:
        lines.append('')

    lines.append(f'  [{len(checked)} selected]  A=approve  R=reject  Q=quit')
    lines.append('')
    return '\n'.join(lines)


def interactive_menu() -> None:
    if not sys.stdout.isatty():
        for item in load_pending():
            print(f"{item['id']}|{item.get('category','')}|{item.get('title','')}")
        return

    items = load_pending()
    if not items:
        print("\n  No pending approvals.\n")
        return

    from aibrain.cli.utils import _getch

    page = 0
    focused = 0
    checked: set[int] = set()
    n = len(items)

    # Initial draw
    text = _render(items, page, focused, checked)
    sys.stdout.write(text)
    sys.stdout.flush()
    menu_lines = text.count('\n')

    while True:
        ch = _getch()

        if ch in ('q', 'Q'):
            sys.stdout.write('\n')
            return

        elif ch in ('a', 'A') and checked:
            count = _update_status(list(checked), 'approved')
            sys.stdout.write(f'\x1b[{menu_lines}A\x1b[J')
            print(f'\n  Approved {count} items.\n')
            items = load_pending()
            if not items:
                print('  No pending approvals remaining.\n')
                return
            n = len(items)
            page = 0
            focused = 0
            checked.clear()

        elif ch in ('r', 'R') and checked:
            count = _update_status(list(checked), 'rejected')
            sys.stdout.write(f'\x1b[{menu_lines}A\x1b[J')
            print(f'\n  Rejected {count} items.\n')
            items = load_pending()
            if not items:
                print('  No pending approvals remaining.\n')
                return
            n = len(items)
            page = 0
            focused = 0
            checked.clear()

        elif ch == ' ':
            if 0 <= focused < n:
                iid = items[focused]['id']
                if iid in checked:
                    checked.discard(iid)
                else:
                    checked.add(iid)
                if focused < n - 1:
                    focused += 1
                    if focused >= (page + 1) * PAGE:
                        page += 1

        elif ch in ('s', 'S'):
            start = page * PAGE
            end = min(start + PAGE, n)
            page_ids = {items[i]['id'] for i in range(start, end)}
            if page_ids.issubset(checked):
                checked -= page_ids
            else:
                checked |= page_ids

        elif ch in ('p', 'P'):
            total_pages = max(1, (n + PAGE - 1) // PAGE)
            page = (page + 1) % total_pages
            focused = page * PAGE

        # Arrow keys — Windows (\xe0 or \x00 prefix) and Unix (\x1b[)
        elif ch in ('\xe0', '\x00'):
            n2 = _getch()
            if n2 == 'H':  # Up
                focused = max(0, focused - 1)
                if focused < page * PAGE:
                    page = max(0, page - 1)
            elif n2 == 'P':  # Down
                focused = min(n - 1, focused + 1)
                if focused >= (page + 1) * PAGE:
                    page += 1

        elif ch == '\x1b':
            try:
                n1 = _getch()
                if n1 == '[':
                    n2 = _getch()
                    if n2 == 'A':
                        focused = max(0, focused - 1)
                        if focused < page * PAGE:
                            page = max(0, page - 1)
                    elif n2 == 'B':
                        focused = min(n - 1, focused + 1)
                        if focused >= (page + 1) * PAGE:
                            page += 1
            except Exception:
                pass

        elif ch.isdigit() and ch != '0':
            idx = int(ch) - 1 + page * PAGE
            if 0 <= idx < n:
                iid = items[idx]['id']
                if iid in checked:
                    checked.discard(iid)
                else:
                    checked.add(iid)
                focused = idx

        else:
            continue

        # Redraw — same pattern as compress config
        sys.stdout.write(f'\x1b[{menu_lines}A')
        text = _render(items, page, focused, checked)
        sys.stdout.write(text)
        sys.stdout.flush()
        menu_lines = text.count('\n')


# Backward-compat alias for older test signature — real rendering is _render().
# Kept only so collection imports don't break; legacy tests still fail on
# assertions (by design — see tests/test_approvals.py triage notes).
def render_menu(groups, page=0, focused=0, cat_idx=0, checked=None, total=0):
    if checked is None:
        checked = set()
    if not groups or total == 0:
        return "\n  No pending approvals.\n"
    # Flatten groups to a flat list compatible with _render.
    items: list[dict[str, Any]] = []
    for _cat, cat_items in groups:
        items.extend(cat_items)
    return _render(items, page, focused, checked)


# Keep test helpers
def group_by_category(items):
    seen = {}
    order = []
    for item in items:
        cat = item.get("category", "uncategorized") or "uncategorized"
        if cat not in seen:
            seen[cat] = []
            order.append(cat)
        seen[cat].append(item)
    return [(cat, seen[cat]) for cat in order]


def render_detail(item):
    return f"\n  #{item['id']} [{item.get('category','')}] {item.get('title','')}\n  {item.get('detail','')}\n"
