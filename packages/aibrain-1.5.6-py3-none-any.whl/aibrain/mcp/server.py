"""
aibrain.mcp.server — Hippocampus-as-a-service.

Standalone MCP server that exposes AIBrain's persistent memory tools
(memory_store, memory_recall, memory_search, memory_stats, memory_ingest,
memory_prepare) as an authenticated HTTP JSON-RPC 2.0 endpoint so ANY MCP
client (Cursor, Claude Code, Zed, Continue) can reach the same brain.

Runnable:
    python -m aibrain.mcp.server                   # default 127.0.0.1:8799
    python -m aibrain.mcp.server --host 0.0.0.0 --port 8799
    python -m aibrain.mcp.server --db /path/aibrain.db

Environment:
    AIBRAIN_MCP_TOKEN   Required. Clients send "Authorization: Bearer <token>".
    AIBRAIN_MCP_HOST    Overrides --host.
    AIBRAIN_MCP_PORT    Overrides --port.
    AIBRAIN_DB          DB override (same semantics as mcp_server.py stdio mode).

Contract: see aibrain/mcp/CONTRACT.md for the versioned tool schema.
Setup:    see aibrain/mcp/SETUP.md for client install recipes.

Honest-rubric rule: when an underlying tool returns None because the backing
data isn't available, the MCP response carries null — never a fabricated
placeholder. Bug #6 compliance: uses aibrain.core.harness._get_or_create_db
so the DB path always resolves from the canonical AIBRAIN_ROOT.
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Callable

log = logging.getLogger("aibrain.mcp.server")

# ---------------------------------------------------------------------------
# Contract version — bump on any breaking change to the tool surface.
# See aibrain/mcp/CONTRACT.md for the full schema.
# ---------------------------------------------------------------------------
CONTRACT_VERSION = "1.0.0"
MCP_PROTOCOL_VERSION = "2024-11-05"
SERVER_NAME = "aibrain-memory"

# JSON-RPC error codes (per MCP / JSON-RPC 2.0 spec)
ERR_PARSE = -32700
ERR_INVALID_REQUEST = -32600
ERR_METHOD_NOT_FOUND = -32601
ERR_INVALID_PARAMS = -32602
ERR_INTERNAL = -32603
# Auth is an application-level error — keep it out of the reserved JSON-RPC range.
ERR_UNAUTHORIZED = -32001


# ---------------------------------------------------------------------------
# Tool adapters
# ---------------------------------------------------------------------------
# Each adapter is a thin wrapper that:
#   1. Calls the canonical implementation (from the legacy mcp_server.py module
#      which already owns _store/_search/_recall/_stats — we reuse it instead
#      of forking a second memory backend).
#   2. Returns JSON-serializable output (plain dicts / lists / scalars / None).
#   3. Passes None through untouched. If upstream returns None, we return null —
#      we never synthesize fake data. This is the honest-rubric rule.

def _load_backend():
    """Import the legacy top-level mcp_server module and pin its DB path.

    We deliberately reuse mcp_server.py instead of duplicating the memory
    logic. That module already carries ~2,500 lines of proven store/search/
    recall behavior (canonical_dedup, vector search, tiered retrieval, etc).

    Bug #6 compliance: db path is resolved via
    aibrain.core.harness._get_or_create_db so the file is guaranteed to
    exist at the canonical location before anyone reads or writes.
    """
    # Ensure repo root is importable so `import mcp_server` finds the
    # top-level file. Walk up from this file until we find mcp_server.py.
    here = Path(__file__).resolve()
    for parent in here.parents:
        if (parent / "mcp_server.py").exists():
            if str(parent) not in sys.path:
                sys.path.insert(0, str(parent))
            break

    import mcp_server  # type: ignore[import-not-found]

    # If a test fixture has already wired the module up (db_path set and
    # connection live), trust it and don't re-init the embedder — otherwise
    # we'd clobber the fixture's intentional `_vec_enabled = False`.
    already_configured = (
        getattr(mcp_server, "_db_path", None) is not None
        and getattr(mcp_server, "_conn", None) is not None
    )

    if not already_configured:
        # Pin DB path (Bug #6 compliant — always resolves + creates canonical file)
        if mcp_server._db_path is None:  # type: ignore[attr-defined]
            try:
                from aibrain.core.harness import _get_or_create_db
                mcp_server._db_path = _get_or_create_db()  # type: ignore[attr-defined]
            except Exception:
                env_db = os.environ.get("AIBRAIN_DB")
                if env_db:
                    mcp_server._db_path = Path(env_db)  # type: ignore[attr-defined]
                else:
                    mcp_server._db_path = Path.home() / "aibrain" / "aibrain.db"  # type: ignore[attr-defined]
                    mcp_server._db_path.parent.mkdir(parents=True, exist_ok=True)

        # Initialize embedder (graceful no-op if sentence-transformers/sqlite-vec missing)
        try:
            mcp_server._init_embedder()
        except Exception as exc:
            log.warning("embedder init failed (continuing without vec search): %s", exc)

        # Touch DB to ensure schema ready
        mcp_server._get_db()

    return mcp_server


def _tool_memory_store(backend, args: dict) -> dict:
    return backend._store(
        name=args["name"],
        content=args["content"],
        mem_type=args.get("type", "reference"),
        tags=args.get("tags", ""),
        importance=args.get("importance", 0.5),
    )


def _tool_memory_search(backend, args: dict) -> list[dict] | None:
    query = args.get("query")
    if not query:
        raise ValueError("memory_search: 'query' is required")
    results = backend._search(
        query=query,
        limit=args.get("limit", 10),
        search_type=args.get("search_type"),
    )
    return results  # may be empty list; never fake


def _tool_memory_recall(backend, args: dict) -> list[dict]:
    return backend._recall(
        mem_type=args.get("type"),
        limit=args.get("limit", 10),
    )


def _tool_memory_stats(backend, args: dict) -> dict:
    return backend._stats()


def _tool_memory_ingest(backend, args: dict) -> dict | None:
    transcript = args.get("transcript")
    if not transcript:
        raise ValueError("memory_ingest: 'transcript' is required")
    try:
        from conversation_observer import ConversationObserver  # type: ignore
    except ImportError:
        return None  # honest null — module unavailable
    observer = ConversationObserver(str(backend._db_path))
    return observer.ingest_transcript(
        transcript=transcript,
        session_id=args.get("session_id", ""),
    )


def _tool_memory_prepare(backend, args: dict) -> dict | None:
    task_type = args.get("task_type")
    if not task_type:
        raise ValueError("memory_prepare: 'task_type' is required")
    try:
        from skill_memory import SkillMemory  # type: ignore
    except ImportError:
        return None  # honest null — module unavailable
    sm = SkillMemory(str(backend._db_path))
    return sm.prepare(task_type=task_type, context=args.get("context", ""))


# ---------------------------------------------------------------------------
# Tool schema (advertised via tools/list)
# ---------------------------------------------------------------------------

TOOL_SCHEMA: list[dict] = [
    {
        "name": "memory_store",
        "description": (
            "Store a new memory or update an existing one. Auto-detects "
            "duplicates by name and by embedding similarity."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Short identifier"},
                "content": {"type": "string", "description": "Memory content"},
                "type": {
                    "type": "string",
                    "enum": ["user", "feedback", "project", "reference", "pattern", "decision"],
                    "default": "reference",
                },
                "tags": {"type": "string", "default": ""},
                "importance": {
                    "type": "number",
                    "default": 0.5,
                    "minimum": 0.0,
                    "maximum": 1.0,
                },
            },
            "required": ["name", "content"],
        },
    },
    {
        "name": "memory_search",
        "description": (
            "Search memories with selective routing. Supports temporal queries, "
            "preference boost, and passage-level reranking."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string"},
                "limit": {"type": "integer", "default": 10, "minimum": 1, "maximum": 50},
                "search_type": {
                    "type": "string",
                    "enum": [
                        "temporal", "preference", "multi_session",
                        "ss_user", "ss_assistant", "knowledge_update", "factual",
                    ],
                },
            },
            "required": ["query"],
        },
    },
    {
        "name": "memory_recall",
        "description": "Recall top memories by importance, optionally filtered by type.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "type": {
                    "type": "string",
                    "enum": ["user", "feedback", "project", "reference", "pattern", "decision"],
                },
                "limit": {"type": "integer", "default": 10, "minimum": 1, "maximum": 50},
            },
        },
    },
    {
        "name": "memory_stats",
        "description": "Memory system statistics — counts, types, DB path, embedding state.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "memory_ingest",
        "description": (
            "Ingest a conversation transcript for automatic memory extraction. "
            "Returns null if the conversation_observer module is not installed."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "transcript": {"type": "string"},
                "session_id": {"type": "string", "default": ""},
            },
            "required": ["transcript"],
        },
    },
    {
        "name": "memory_prepare",
        "description": (
            "Prepare a skill briefing before starting a task. Returns null if "
            "skill_memory is unavailable."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "task_type": {"type": "string"},
                "context": {"type": "string", "default": ""},
            },
            "required": ["task_type"],
        },
    },
]

TOOL_DISPATCH: dict[str, Callable[[Any, dict], Any]] = {
    "memory_store": _tool_memory_store,
    "memory_search": _tool_memory_search,
    "memory_recall": _tool_memory_recall,
    "memory_stats": _tool_memory_stats,
    "memory_ingest": _tool_memory_ingest,
    "memory_prepare": _tool_memory_prepare,
}


# ---------------------------------------------------------------------------
# JSON-RPC handler
# ---------------------------------------------------------------------------

def _json_rpc_error(req_id: Any, code: int, message: str) -> dict:
    return {
        "jsonrpc": "2.0",
        "id": req_id,
        "error": {"code": code, "message": message},
    }


def _json_rpc_ok(req_id: Any, result: Any) -> dict:
    return {"jsonrpc": "2.0", "id": req_id, "result": result}


def _to_mcp_content(result: Any) -> dict:
    """Wrap a tool result as MCP content blocks.

    MCP clients expect tools/call to return {"content": [TextContent], ...}.
    We always serialize as JSON text so clients can parse programmatically.
    Honest-rubric: None serializes to JSON null, not an empty dict.
    """
    text = json.dumps(result, default=str, ensure_ascii=False, indent=2)
    return {
        "content": [{"type": "text", "text": text}],
        "isError": False,
    }


class MemoryMCPHandler(BaseHTTPRequestHandler):
    """MCP JSON-RPC 2.0 over HTTP.

    POST /            → JSON-RPC request (initialize, tools/list, tools/call)
    GET  /health      → {"status":"ok","contract":"1.0.0",...}
    """

    server_version = f"aibrain-mcp/{CONTRACT_VERSION}"

    # Quiet the default access log — route through our logger instead.
    def log_message(self, format: str, *args) -> None:  # noqa: A002
        log.info("%s - %s", self.address_string(), format % args)

    # -- auth ---------------------------------------------------------------
    def _check_auth(self) -> bool:
        expected = getattr(self.server, "auth_token", None)
        if not expected:
            return True  # no token configured → auth disabled (dev only)
        header = self.headers.get("Authorization", "")
        if header.startswith("Bearer "):
            provided = header[len("Bearer "):].strip()
            return provided == expected
        # Also accept X-AIBrain-Token for clients that can't set Authorization.
        alt = self.headers.get("X-AIBrain-Token", "").strip()
        return bool(alt) and alt == expected

    def _send_json(self, status: int, payload: dict) -> None:
        body = json.dumps(payload, default=str, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    # -- HTTP verbs ---------------------------------------------------------
    def do_GET(self) -> None:  # noqa: N802 (stdlib naming)
        if self.path == "/health":
            self._send_json(200, {
                "status": "ok",
                "server": SERVER_NAME,
                "contract": CONTRACT_VERSION,
                "protocol": MCP_PROTOCOL_VERSION,
                "auth_required": bool(getattr(self.server, "auth_token", None)),
            })
            return
        self._send_json(404, {"error": "not found"})

    def do_POST(self) -> None:  # noqa: N802
        if not self._check_auth():
            self._send_json(401, _json_rpc_error(None, ERR_UNAUTHORIZED, "unauthorized"))
            return

        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0:
            self._send_json(400, _json_rpc_error(None, ERR_INVALID_REQUEST, "empty body"))
            return
        try:
            raw = self.rfile.read(length)
            msg = json.loads(raw.decode("utf-8"))
        except Exception as exc:
            self._send_json(400, _json_rpc_error(None, ERR_PARSE, f"parse error: {exc}"))
            return

        response = self._handle_rpc(msg)
        if response is None:
            # Notification (no id) — per JSON-RPC, respond with 204.
            self.send_response(204)
            self.end_headers()
            return
        self._send_json(200, response)

    # -- JSON-RPC dispatch --------------------------------------------------
    def _handle_rpc(self, msg: dict) -> dict | None:
        req_id = msg.get("id")
        method = msg.get("method")
        params = msg.get("params") or {}

        if msg.get("jsonrpc") != "2.0" or not method:
            return _json_rpc_error(req_id, ERR_INVALID_REQUEST, "invalid JSON-RPC envelope")

        if method == "initialize":
            return _json_rpc_ok(req_id, {
                "protocolVersion": MCP_PROTOCOL_VERSION,
                "capabilities": {"tools": {"listChanged": False}},
                "serverInfo": {
                    "name": SERVER_NAME,
                    "version": CONTRACT_VERSION,
                },
            })

        if method == "notifications/initialized":
            return None  # notification — no response body

        if method == "tools/list":
            return _json_rpc_ok(req_id, {"tools": TOOL_SCHEMA})

        if method == "tools/call":
            return self._call_tool(req_id, params)

        if method == "ping":
            return _json_rpc_ok(req_id, {})

        return _json_rpc_error(req_id, ERR_METHOD_NOT_FOUND, f"unknown method: {method}")

    def _call_tool(self, req_id: Any, params: dict) -> dict:
        name = params.get("name")
        args = params.get("arguments") or {}
        handler = TOOL_DISPATCH.get(name or "")
        if handler is None:
            return _json_rpc_error(req_id, ERR_METHOD_NOT_FOUND, f"unknown tool: {name}")
        backend = self.server.backend  # type: ignore[attr-defined]
        try:
            result = handler(backend, args)
        except KeyError as exc:
            return _json_rpc_error(req_id, ERR_INVALID_PARAMS, f"missing argument: {exc}")
        except ValueError as exc:
            return _json_rpc_error(req_id, ERR_INVALID_PARAMS, str(exc))
        except Exception as exc:  # pragma: no cover — surfaced in error payload
            log.exception("tool %s failed", name)
            return _json_rpc_error(req_id, ERR_INTERNAL, f"{type(exc).__name__}: {exc}")
        return _json_rpc_ok(req_id, _to_mcp_content(result))


# ---------------------------------------------------------------------------
# Server factory
# ---------------------------------------------------------------------------

class MemoryMCPServer(ThreadingHTTPServer):
    """ThreadingHTTPServer that carries auth token + backend module reference."""

    daemon_threads = True

    def __init__(self, address: tuple[str, int], token: str | None, backend):
        super().__init__(address, MemoryMCPHandler)
        self.auth_token = token
        self.backend = backend
        self._lock = threading.Lock()


def build_server(host: str, port: int, token: str | None, db_path: Path | None = None) -> MemoryMCPServer:
    backend = _load_backend()
    if db_path is not None:
        backend._db_path = db_path  # type: ignore[attr-defined]
        # Reset cached connection so the new path is picked up.
        backend._conn = None  # type: ignore[attr-defined]
        backend._get_db()

    # Pre-wire aibrain_db so its lazy-init branches (get_db → init_embedder)
    # don't kick off a HuggingFace model download on first _store call.
    # The mcp_server helper handles path + embedder state; we also pin
    # aibrain_db's embedder sentinel so the `_db_embedder is None and not
    # _db_vec_enabled` branch inside aibrain_db.get_db cannot fire.
    try:
        backend._sync_db_to_aibrain_db()
        import aibrain_db as _adb
        if _adb._db_embedder is None and not _adb._db_vec_enabled:
            # Non-None sentinel blocks the lazy init without enabling vec.
            _adb._db_embedder = False  # type: ignore[assignment]
    except Exception as exc:  # pragma: no cover — defensive
        log.warning("aibrain_db pre-sync failed: %s", exc)

    return MemoryMCPServer((host, port), token, backend)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="aibrain.mcp.server",
        description="AIBrain Memory MCP server — hippocampus-as-a-service",
    )
    parser.add_argument("--host", default=os.environ.get("AIBRAIN_MCP_HOST", "127.0.0.1"))
    parser.add_argument("--port", type=int,
                        default=int(os.environ.get("AIBRAIN_MCP_PORT", "8799")))
    parser.add_argument("--db", type=Path, default=None,
                        help="Override AIBrain DB path (defaults to canonical AIBRAIN_ROOT)")
    parser.add_argument("--allow-noauth", action="store_true",
                        help="Start without AIBRAIN_MCP_TOKEN (LOCAL DEV ONLY)")
    args = parser.parse_args(argv)

    logging.basicConfig(
        level=logging.INFO,
        format="[%(asctime)s] %(name)s %(levelname)s: %(message)s",
    )

    token = os.environ.get("AIBRAIN_MCP_TOKEN")
    if not token and not args.allow_noauth:
        print(
            "ERROR: AIBRAIN_MCP_TOKEN not set. "
            "Set the env var or pass --allow-noauth for local dev.",
            file=sys.stderr,
        )
        return 2

    server = build_server(args.host, args.port, token, db_path=args.db)
    print(
        f"[aibrain-mcp] {SERVER_NAME} v{CONTRACT_VERSION} listening on "
        f"http://{args.host}:{args.port}  (auth={'on' if token else 'OFF'}, "
        f"db={server.backend._db_path})",
        file=sys.stderr,
    )
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("[aibrain-mcp] shutdown", file=sys.stderr)
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
