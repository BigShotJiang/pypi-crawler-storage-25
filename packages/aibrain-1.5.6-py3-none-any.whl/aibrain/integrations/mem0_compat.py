"""
aibrain.integrations.mem0_compat — Drop-in replacement for Mem0's MemoryClient.

Provides the same API surface as Mem0's MemoryClient so existing Mem0 users
can migrate to AIBrain by changing a single import line:

    # Before (Mem0)
    from mem0 import MemoryClient
    m = MemoryClient(api_key="...")

    # After (AIBrain)
    from aibrain.integrations.mem0_compat import MemoryClient
    m = MemoryClient()

All data stays local — no cloud, no API keys, no telemetry.

Migration helper:
    from aibrain.integrations.mem0_compat import migrate_from_mem0
    migrate_from_mem0(mem0_client, aibrain_client)
"""

from __future__ import annotations

from typing import Any, Optional, Union


class MemoryClient:
    """Mem0-compatible MemoryClient backed by AIBrain's Brain.

    Implements the public Mem0 MemoryClient methods:
        add, search, get, get_all, delete, history

    Parameters:
        api_key:   Ignored (kept for signature compat). AIBrain is local-only.
        db_path:   Override path to aibrain.db.
        org_id:    Ignored (Mem0 cloud concept).
        project_id: Ignored (Mem0 cloud concept).
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        db_path: Optional[str] = None,
        org_id: Optional[str] = None,
        project_id: Optional[str] = None,
    ) -> None:
        from aibrain.core.memory_api import Brain

        self._brain = Brain(db_path=db_path) if db_path else Brain()

    # -- Mem0 API surface -------------------------------------------------------

    def add(
        self,
        messages: Union[str, list[dict]],
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        run_id: Optional[str] = None,
        metadata: Optional[dict] = None,
        filters: Optional[dict] = None,
        infer: bool = True,
        **kwargs: Any,
    ) -> list[dict]:
        """Add memories from text or conversation messages.

        Mem0 signature: add(messages, user_id=, agent_id=, run_id=, metadata=, ...)
        Maps to: Brain.add(messages, user_id=, agent_id=, metadata=, infer=)

        Args:
            messages:  Raw text or list of chat messages
                       [{"role": "user", "content": "..."}].
            user_id:   Scope memories to this user.
            agent_id:  Scope memories to this agent.
            run_id:    Ignored (Mem0 concept — no direct equivalent).
            metadata:  Extra metadata dict stored in tags.
            filters:   Ignored (Mem0 server-side filter).
            infer:     If True, extract facts via LLM before storing.

        Returns:
            List of dicts with 'id', 'memory', 'event' keys.
        """
        combined_meta = dict(metadata) if metadata else {}
        if run_id:
            combined_meta["run_id"] = run_id

        return self._brain.add(
            messages,
            user_id=user_id,
            agent_id=agent_id,
            metadata=combined_meta or None,
            infer=infer,
        )

    def search(
        self,
        query: str,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        run_id: Optional[str] = None,
        limit: int = 10,
        filters: Optional[dict] = None,
        **kwargs: Any,
    ) -> list[dict]:
        """Search memories by semantic similarity.

        Mem0 signature: search(query, user_id=, agent_id=, limit=, ...)
        Maps to: Brain.search(query, user_id=, agent_id=, limit=)

        Returns:
            List of memory dicts with id, memory, score, metadata fields.
        """
        return self._brain.search(
            query,
            user_id=user_id,
            agent_id=agent_id,
            limit=limit,
        )

    def get(self, memory_id: int, **kwargs: Any) -> Optional[dict]:
        """Get a single memory by ID.

        Mem0 signature: get(memory_id)
        Maps to: Brain.get(memory_id)

        Returns:
            Memory dict or None.
        """
        return self._brain.get(memory_id)

    def get_all(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        run_id: Optional[str] = None,
        limit: int = 100,
        **kwargs: Any,
    ) -> list[dict]:
        """List all memories, optionally filtered.

        Mem0 signature: get_all(user_id=, agent_id=, ...)
        Maps to: Brain.get_all(user_id=, agent_id=, limit=)

        Returns:
            List of memory dicts.
        """
        return self._brain.get_all(
            user_id=user_id,
            agent_id=agent_id,
            limit=limit,
        )

    def delete(self, memory_id: int, **kwargs: Any) -> bool:
        """Delete a memory by ID (soft-delete).

        Mem0 signature: delete(memory_id)
        Maps to: Brain.delete(memory_id)

        Returns:
            True if deleted, False if not found.
        """
        return self._brain.delete(memory_id)

    def delete_all(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        **kwargs: Any,
    ) -> int:
        """Bulk-delete all memories for a user or agent.

        Returns:
            Number of memories deleted.
        """
        return self._brain.delete_all(user_id=user_id, agent_id=agent_id)

    def history(self, memory_id: int, **kwargs: Any) -> list[dict]:
        """Get change history for a memory.

        Mem0 signature: history(memory_id)
        Maps to: Brain.history(memory_id)

        Returns:
            List of history entries, newest first.
        """
        return self._brain.history(memory_id)

    def update(
        self,
        memory_id: int,
        data: str,
        metadata: Optional[dict] = None,
        **kwargs: Any,
    ) -> Optional[dict]:
        """Update a memory's content.

        Returns:
            Updated memory dict, or None if not found.
        """
        return self._brain.update(memory_id, data, metadata=metadata)

    def reset(self) -> None:
        """Reset is a no-op — AIBrain uses soft-delete, not hard wipe."""
        pass


# ---------------------------------------------------------------------------
# Migration helper
# ---------------------------------------------------------------------------

def migrate_from_mem0(
    mem0_client: Any,
    aibrain_client: Optional[MemoryClient] = None,
    user_id: Optional[str] = None,
    agent_id: Optional[str] = None,
    batch_size: int = 100,
) -> dict:
    """Migrate all memories from a Mem0 MemoryClient into AIBrain.

    Reads every memory from the source Mem0 client and writes it into the
    destination AIBrain MemoryClient.  Deduplication is handled automatically
    by AIBrain's canonical dedup pipeline.

    Args:
        mem0_client:     An existing Mem0 MemoryClient instance.
        aibrain_client:  Destination MemoryClient. Created if None.
        user_id:         Filter source memories to this user.
        agent_id:        Filter source memories to this agent.
        batch_size:      How many memories to fetch per page from Mem0.

    Returns:
        Dict with 'migrated', 'skipped', 'errors' counts and 'details' list.

    Usage:
        from mem0 import MemoryClient as Mem0Client
        from aibrain.integrations.mem0_compat import MemoryClient, migrate_from_mem0

        old = Mem0Client(api_key="m0-...")
        new = MemoryClient()
        result = migrate_from_mem0(old, new, user_id="alice")
        print(f"Migrated {result['migrated']} memories")
    """
    if aibrain_client is None:
        aibrain_client = MemoryClient()

    # Pull all memories from Mem0
    kwargs: dict[str, Any] = {}
    if user_id:
        kwargs["user_id"] = user_id
    if agent_id:
        kwargs["agent_id"] = agent_id

    try:
        source_memories = mem0_client.get_all(**kwargs)
    except Exception as exc:
        return {"migrated": 0, "skipped": 0, "errors": 1, "details": [str(exc)]}

    migrated = 0
    skipped = 0
    errors = 0
    details: list[str] = []

    for mem in source_memories:
        content = mem.get("memory", "") or mem.get("content", "")
        if not content:
            skipped += 1
            details.append(f"skip empty id={mem.get('id', '?')}")
            continue

        mem_meta = mem.get("metadata")
        try:
            results = aibrain_client.add(
                content,
                user_id=user_id or mem.get("user_id"),
                agent_id=agent_id or mem.get("agent_id"),
                metadata=mem_meta,
                infer=False,  # Already extracted facts — don't re-infer
            )
            event = results[0].get("event", "") if results else ""
            if event == "SKIP":
                skipped += 1
            else:
                migrated += 1
        except Exception as exc:
            errors += 1
            details.append(f"error id={mem.get('id', '?')}: {exc}")

    return {
        "migrated": migrated,
        "skipped": skipped,
        "errors": errors,
        "details": details,
    }
