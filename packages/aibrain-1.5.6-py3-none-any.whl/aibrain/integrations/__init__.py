"""
aibrain.integrations — Adapters for popular AI/ML frameworks.

All imports are lazy (call-time only) so installing langchain/crewai/langgraph
is NOT required to use aibrain itself.
"""
