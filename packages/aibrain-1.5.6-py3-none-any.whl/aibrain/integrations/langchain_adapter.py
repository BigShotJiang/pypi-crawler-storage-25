"""
aibrain.integrations.langchain_adapter — LangChain BaseMemory backed by AIBrain.

Provides a drop-in LangChain memory class that reads/writes through the AIBrain
Brain API.  LangChain is imported at call time only — no hard dependency.

Usage:
    from aibrain.integrations.langchain_adapter import AIBrainMemory

    memory = AIBrainMemory(user_id="alice")

    # Use with any LangChain chain:
    from langchain.chains import ConversationChain
    from langchain_openai import ChatOpenAI

    chain = ConversationChain(llm=ChatOpenAI(), memory=memory)
    chain.predict(input="My favourite colour is blue")
    chain.predict(input="What is my favourite colour?")
"""

from __future__ import annotations

from typing import Any, Optional


class AIBrainMemory:
    """LangChain-compatible memory backend using AIBrain.

    Subclasses ``langchain.memory.BaseMemory`` at runtime so LangChain
    is only required when this class is actually instantiated.

    Parameters:
        user_id:  Scope memories to this user.
        agent_id: Scope memories to this agent.
        db_path:  Override path to aibrain.db (default: auto-detect).
        memory_key: Variable name injected into chain context (default "history").
        input_key:  Key for human input in the chain (default "input").
        k:         Number of relevant memories to retrieve per turn.
        compress:  If True, compress retrieved memories via aibrain-compress.
    """

    # These are declared here and also set dynamically after BaseMemory mixin
    memory_key: str = "history"
    input_key: str = "input"

    def __new__(cls, *args: Any, **kwargs: Any) -> "AIBrainMemory":
        """Dynamically inject BaseMemory as a parent at instantiation time."""
        try:
            from langchain.memory import BaseMemory as _BaseMemory  # type: ignore[import]
        except ImportError:
            raise ImportError(
                "langchain is required for AIBrainMemory. "
                "Install it with: pip install langchain"
            )

        # Only patch once
        if _BaseMemory not in cls.__bases__:
            cls.__bases__ = (_BaseMemory, *cls.__bases__)

        return super().__new__(cls)

    def __init__(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        db_path: Optional[str] = None,
        memory_key: str = "history",
        input_key: str = "input",
        k: int = 5,
        compress: bool = False,
    ) -> None:
        # Avoid double-init from BaseMemory
        if hasattr(self, "_brain"):
            return

        from aibrain.core.memory_api import Brain

        self._brain = Brain(db_path=db_path) if db_path else Brain()
        self._user_id = user_id
        self._agent_id = agent_id
        self._k = k
        self._compress = compress
        self.memory_key = memory_key
        self.input_key = input_key

    # -- BaseMemory interface --------------------------------------------------

    @property
    def memory_variables(self) -> list[str]:
        return [self.memory_key]

    def load_memory_variables(self, inputs: dict[str, Any]) -> dict[str, str]:
        """Retrieve relevant memories for the current input."""
        query = inputs.get(self.input_key, "")
        if not query:
            return {self.memory_key: ""}

        results = self._brain.search(
            query,
            user_id=self._user_id,
            agent_id=self._agent_id,
            limit=self._k,
        )

        texts = [r.get("memory", "") for r in results if r.get("memory")]

        if self._compress and texts:
            try:
                from aibrain.tools.compress import compress
                joined = "\n".join(texts)
                texts = [compress(command=["memory", "recall"], output=joined)]
            except Exception:
                pass  # Fall back to uncompressed

        return {self.memory_key: "\n".join(texts)}

    def save_context(self, inputs: dict[str, Any], outputs: dict[str, str]) -> None:
        """Persist the turn's input and output as memories."""
        human_input = inputs.get(self.input_key, "")
        ai_output = next(iter(outputs.values()), "") if outputs else ""

        text = f"Human: {human_input}\nAI: {ai_output}"
        self._brain.add(
            text,
            user_id=self._user_id,
            agent_id=self._agent_id,
        )

    def clear(self) -> None:
        """Clear is a no-op — AIBrain uses soft-delete, not hard wipe."""
        pass
