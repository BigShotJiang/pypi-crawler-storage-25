"""
aibrain.integrations.langgraph_adapter — LangGraph checkpoint store backed by AIBrain.

Stores LangGraph checkpoints (serialised graph state) as AIBrain memories,
enabling persistent, searchable conversation/workflow state.

LangGraph is imported at call time only — no hard dependency.

Usage:
    from aibrain.integrations.langgraph_adapter import AIBrainCheckpointStore

    store = AIBrainCheckpointStore(user_id="workflow-1")

    # Save a checkpoint
    store.put(thread_id="t1", checkpoint_id="c1", data={"messages": [...], "step": 3})

    # Load latest checkpoint for a thread
    cp = store.get(thread_id="t1")

    # List all checkpoints for a thread
    all_cps = store.list(thread_id="t1")

    # Use with LangGraph (if langgraph is installed):
    from langgraph.graph import StateGraph
    graph = StateGraph(...)
    compiled = graph.compile(checkpointer=store)
"""

from __future__ import annotations

import json
import time
from typing import Any, Optional


class AIBrainCheckpointStore:
    """LangGraph-compatible checkpoint store using AIBrain as the backend.

    Each checkpoint is stored as an AIBrain memory with:
    - name: "checkpoint:{thread_id}:{checkpoint_id}"
    - content: JSON-serialised checkpoint data
    - tags: "checkpoint,thread:{thread_id}"
    - type: "reference"

    Parameters:
        user_id:  Scope checkpoints to this user.
        db_path:  Override path to aibrain.db.
    """

    def __init__(
        self,
        user_id: Optional[str] = None,
        db_path: Optional[str] = None,
    ) -> None:
        from aibrain.core.memory_api import Brain

        self._brain = Brain(db_path=db_path) if db_path else Brain()
        self._user_id = user_id

    def put(
        self,
        thread_id: str,
        checkpoint_id: str,
        data: dict[str, Any],
    ) -> dict:
        """Save a checkpoint.

        Args:
            thread_id:     Identifies the conversation/workflow thread.
            checkpoint_id: Unique ID for this checkpoint within the thread.
            data:          Arbitrary serialisable state dict.

        Returns:
            Dict with id, memory, event keys from Brain.add().
        """
        name = f"checkpoint:{thread_id}:{checkpoint_id}"
        content = json.dumps({
            "thread_id": thread_id,
            "checkpoint_id": checkpoint_id,
            "ts": time.time(),
            "data": data,
        }, ensure_ascii=False)

        results = self._brain.add(
            content,
            user_id=self._user_id,
            metadata={"thread_id": thread_id, "checkpoint_id": checkpoint_id},
            infer=False,  # Store raw — don't extract facts from state blobs
        )
        return results[0] if results else {}

    def get(
        self,
        thread_id: str,
        checkpoint_id: Optional[str] = None,
    ) -> Optional[dict[str, Any]]:
        """Load a checkpoint.

        If checkpoint_id is None, returns the most recent checkpoint for the thread.

        Returns:
            The checkpoint data dict, or None if not found.
        """
        if checkpoint_id:
            query = f"checkpoint:{thread_id}:{checkpoint_id}"
        else:
            query = f"checkpoint:{thread_id}"

        results = self._brain.search(
            query, user_id=self._user_id, limit=10,
        )

        # Filter to actual checkpoints for this thread
        matches = []
        for r in results:
            mem = r.get("memory", "")
            try:
                parsed = json.loads(mem)
            except (json.JSONDecodeError, TypeError):
                continue
            if parsed.get("thread_id") != thread_id:
                continue
            if checkpoint_id and parsed.get("checkpoint_id") != checkpoint_id:
                continue
            matches.append(parsed)

        if not matches:
            return None

        # Return most recent by timestamp
        matches.sort(key=lambda x: x.get("ts", 0), reverse=True)
        return matches[0].get("data")

    def list(
        self,
        thread_id: str,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        """List all checkpoints for a thread, newest first.

        Returns:
            List of dicts with thread_id, checkpoint_id, ts, data keys.
        """
        results = self._brain.search(
            f"checkpoint:{thread_id}",
            user_id=self._user_id,
            limit=limit * 2,
        )

        checkpoints = []
        for r in results:
            try:
                parsed = json.loads(r.get("memory", ""))
            except (json.JSONDecodeError, TypeError):
                continue
            if parsed.get("thread_id") != thread_id:
                continue
            checkpoints.append(parsed)

        checkpoints.sort(key=lambda x: x.get("ts", 0), reverse=True)
        return checkpoints[:limit]
