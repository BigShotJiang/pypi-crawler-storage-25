"""
CLI entry point for aibrain.

Global flags:
    --path <dir>              — override AIBRAIN_ROOT (brain data directory)

Usage:
    aibrain setup             — first-time setup wizard (--auto / --defaults for no prompts)
    aibrain init              — initialize database
    aibrain summary           — dashboard stats
    aibrain search "query"    — cross-table FTS search
    aibrain browse            — open memory browser in browser
    aibrain forget "topic"    — preview what would be deleted
    aibrain forget "topic" --confirm  — permanently delete
    aibrain skills            — show skill inventory
    aibrain workflows list    — list all workflows + status
    aibrain workflows enable <n>  — enable (+ auto-enable deps)
    aibrain workflows disable <n> — disable a workflow
    aibrain workflows enable --recommended — starter set
    aibrain workflows sync    — create OS scheduled tasks
    aibrain workflows sync --dry-run — preview changes
    aibrain workflows run <n> — run immediately
    aibrain workflows deps    — show dependency map
    aibrain audit [N]          — show last N execution audit entries (default 20)
    aibrain attention [N]      — show last N attention log entries (retrieval telemetry, default 20)
    aibrain subagent-log list [N] — show recent subagent (Agent() spawn) executions (default 20)
    aibrain usage              — current-month token-to-cents spend (list-rate equivalent)
    aibrain next [N]           — predict next N workflows (default 3)
    aibrain health             — brain health report (memories, quality, tier usage)
    aibrain fitness            — brain fitness score (objective function) and trend
    aibrain license            — show license status + tier
    aibrain license activate <k> — activate license key
    aibrain license activations  — show activation record for current key
    aibrain license tiers     — show pricing tiers
    aibrain marketplace package --name "Brain" — package brain for sale
    aibrain marketplace validate <f> — validate .brain file
    aibrain marketplace publish <f>  — publish to marketplace
    aibrain marketplace search "q"   — search marketplace
    aibrain marketplace install <id> — install a brain
    aibrain marketplace revenue      — revenue dashboard
    aibrain mesh status       — show mesh agent status
    aibrain mesh register <n> <db> — register agent in mesh
    aibrain mesh merge        — merge all agents (consensus)
    aibrain mesh distribute   — push merged brain to all agents
    aibrain mesh swarm create <type> -n 100 — create training swarm
    aibrain mesh swarm harvest <type> — merge swarm back
    aibrain history snapshot "msg" — snapshot current brain state
    aibrain history list      — list all snapshots
    aibrain history rollback <id> — roll back to snapshot
    aibrain history branch <name> — branch brain for experiments
    aibrain history diff <a> [b]  — compare versions
    aibrain scale stats       — brain health report
    aibrain scale compact     — archive stale memories
    aibrain scale analyze     — shard recommendations
    aibrain brain export      — export brain to JSON
    aibrain brain import <f>  — import brain from JSON
    aibrain brain merge <src> — merge from git URL or path
    aibrain brain stats       — brain statistics
    aibrain config get <key>  — read config
    aibrain config set <k> <v> — write config
    aibrain attack build      — download ATT&CK STIX + build graph
    aibrain attack search "q" — search techniques, malware, tools
    aibrain attack technique T1566  — full technique info
    aibrain attack mitigations T1566 — mitigations for technique
    aibrain attack tactic initial-access — techniques by tactic
    aibrain attack chain T1566 T1059 — find paths between nodes
    aibrain attack stats      — graph statistics
    aibrain packs             — browse available brain packs (domain bundles)
    aibrain packs activate <n> — activate a pack (enables its workflows)
    aibrain packs active      — show currently active packs
    aibrain profile list      — list all Claude Code profiles (hive/isolated)
    aibrain profile create <name> [--mode hive|isolated] — create a new profile
    aibrain profile info <name>   — show profile details
    aibrain profile delete <name> --confirm — unregister a profile
    aibrain start             — restore stack + start services (like rebooting your OS)
    aibrain status            — show current stack (crons, hooks, services)
    aibrain stack save [name] — save named stack snapshot
    aibrain stack restore [n] — restore from last (or named) snapshot
    aibrain stack rollback    — roll back to previous snapshot (keeps last 3)
    aibrain stack rollback 2  — roll back 2 steps
    aibrain stack set-default — save current state as your default stack
    aibrain stack list        — list saved snapshots
    aibrain update            — safe self-update (backup, pull, validate, auto-config)
    aibrain create <name>     — scaffold a new AIBrain project
    aibrain chat              — interactive conversational mode with the brain
    aibrain learn-from-history [--dry-run] [--last-days N] [--skip-secrets-check]
                              — retrolearn from Claude Code session JSONL history
    aibrain inbox --company <id> — show pending approvals for a company
    aibrain approve <id> [--note <text>] — approve a queued item
    aibrain reject <id> [--note <text>]  — reject a queued item
    aibrain train <wf> -n N   — training loop: run workflow N times with feedback
    aibrain test -n N [wfs..] — automated quality evaluation
    aibrain tools             — list available built-in tools
    aibrain enforcement list  — show all loaded rules with source and enforcement points
    aibrain intel run         — run competitive intel sweep for all configured targets
    aibrain intel run --target NAME — run intel sweep for one named target
    aibrain import-mem0 <file> [--dry-run] [--type TYPE]
                              — import a Mem0 JSON export into AIBrain (competitor migration)
    aibrain vacuum-vec         — remove orphan rows from memories_vec (ghost vectors)
    aibrain serve             — start everything (API + dashboard + open browser)
    aibrain server            — start FastAPI server only
    aibrain mcp               — start MCP server (stdio)
    aibrain version           — print version
"""

import os
import sys
from pathlib import Path

# Ensure project root is importable
_root = Path(__file__).resolve().parent.parent
if str(_root) not in sys.path:
    sys.path.insert(0, str(_root))


_QUICK_START = """
Quick Start:
  pip install aibrain
  aibrain setup              # First-time setup (use --auto for no prompts)
  aibrain chat               # Interactive memory chat
  aibrain create myproject   # Scaffold a new project
  aibrain serve              # Launch dashboard (requires: pip install aibrain[api])
"""

_SUBCOMMAND_HELP = {
    "setup": "First-time setup wizard.\n\nUsage:\n  aibrain setup                Interactive wizard (11 steps)\n  aibrain setup --auto         Fully automatic, no prompts, discovers env vars\n  aibrain setup --defaults     Same as --auto\n  aibrain setup --config path  Use a pre-filled config file\n  aibrain setup --reconfigure  Open section picker to update individual settings",
    "chat": "Interactive conversational mode with the brain.\n\nUsage:\n  aibrain chat             Start chatting with your brain\n  aibrain chat --db path   Use a specific database\n\nCommands inside chat:\n  remember: <text>  Store a new memory\n  quit / exit       Leave chat",
    "create": "Scaffold a new AIBrain project.\n\nUsage:\n  aibrain create <name>    Create project directory with boilerplate",
    "serve": "Start API backend + dashboard UI.\n\nUsage:\n  aibrain serve\n\nRequires: pip install aibrain[api]\nDashboard docs: https://myaibrain.org/docs/dashboard",
    "server": "Start FastAPI server only (no dashboard).\n\nUsage:\n  aibrain server\n\nRequires: pip install aibrain[api]",
    "init": "Initialize the brain database.\n\nUsage:\n  aibrain init",
    "search": "Full-text search across all brain tables.\n\nUsage:\n  aibrain search \"query\"",
    "train": "Training loop: run workflow N times with feedback.\n\nUsage:\n  aibrain train <workflow> [-n iterations]",
    "test": "Automated quality evaluation.\n\nUsage:\n  aibrain test [-n iterations] [workflow_names...] [--save-baseline]",
    "workflows": "Manage workflows.\n\nUsage:\n  aibrain workflows list\n  aibrain workflows enable <n>\n  aibrain workflows disable <n>\n  aibrain workflows enable --recommended\n  aibrain workflows sync [--dry-run]\n  aibrain workflows run <n>\n  aibrain workflows deps",
    "brain": "Brain import/export/merge.\n\nUsage:\n  aibrain brain export\n  aibrain brain export-marketplace --output mybrain.db [--domain security] [--creator neuro] [--version 1.0.0]\n  aibrain brain import <file>\n  aibrain brain merge <source>\n  aibrain brain stats",
    "version": "Print the installed aibrain version.",
    "mcp": "Start MCP server (stdio mode).\n\nRequires: pip install aibrain[mcp]",
    "packs": "Browse and activate brain packs (life-domain bundles).\n\nUsage:\n  aibrain packs              List available packs\n  aibrain packs activate <n> Activate a pack",
    "profile": "Manage Claude Code profiles (hive/isolated brain modes).\n\nUsage:\n  aibrain profile list                          List all profiles\n  aibrain profile create <name> [--mode hive|isolated] [--label \"...\"]\n  aibrain profile info <name>                   Show profile details\n  aibrain profile delete <name> --confirm       Unregister a profile\n\nModes:\n  hive      Shared brain DB — same memories across profiles\n  isolated  Dedicated brain DB — profile-level separation (not OS-level isolation)",
    "approvals": "Interactive approval queue.\n\nUsage:\n  aibrain approvals          Launch interactive menu (grouped by category)\n\nKeys:\n  SPACE      Toggle focused item       G  Next category\n  S          Select all in category    D  Detail view\n  A          Approve all checked       R  Reject all checked\n  P          Next page (if >15 items)  Q  Quit\n  Up/Down    Navigate                  1-9 Quick toggle",
    "models": "Show available local + remote models with routing assignments.\n\nUsage:\n  aibrain models             Show all models and routing table\n  aibrain models --refresh   Force re-probe Ollama\n  aibrain models --json      Output as JSON",
    "enforcement": "List all loaded HARD RULE enforcement constraints.\n\nUsage:\n  aibrain enforcement list   Show all rules: builtin, db, file sources with their enforcement points",
    "import-mem0": "Import a Mem0 JSON export into AIBrain (competitor migration path).\n\nUsage:\n  aibrain import-mem0 <file>             Import all memories\n  aibrain import-mem0 <file> --dry-run   Preview without storing\n  aibrain import-mem0 <file> --type ref  Store as type 'ref'\n\nMem0 export format: JSON array of {memory, metadata, created_at, updated_at}",
    "dream": "Run nightly consolidation cycle — compresses memories, reinforces high-value ones, prunes noise.\n\nUsage:\n  aibrain dream\n\nRuns the memory_consolidation workflow through the harness.",
    "stats": "Show brain stats: memory count, retrieval quality, model name, DB path.\n\nUsage:\n  aibrain stats",
    "activate": "Activate a Pro/Team license key (shorthand for `aibrain license activate`).\n\nUsage:\n  aibrain activate <key>",
    "install-desktop": "Download and install the AIBrain native desktop app (Windows only).\n\nUsage:\n  aibrain install-desktop    Download and run the native desktop installer\n\nThe installer is downloaded from the GitHub release for the current version.",
    "export": "Export Markdown documents to PDF.\n\nUsage:\n  aibrain export <file.md>              Export single file\n  aibrain export <file.md> --out out.pdf  Custom output path\n  aibrain export <dir/>                  Export all .md files in directory\n  aibrain export <dir/> --out out_dir/   Export all to target directory\n\nRequires: pip install aibrain[export]",
}


def _resolve_db_path():
    """Resolve the aibrain database path via the canonical resolver — see aibrain_db.AIBRAIN_ROOT."""
    from aibrain_db import AIBRAIN_ROOT
    return str(AIBRAIN_ROOT / "aibrain.db")


def _is_setup_complete():
    """Check if setup has been run (config.json or DB exists)."""
    from aibrain_db import AIBRAIN_ROOT
    return (AIBRAIN_ROOT / "config.json").exists() or (AIBRAIN_ROOT / "aibrain.db").exists()


def _install_desktop():
    """Download and run the AIBrain native desktop installer (Windows only)."""
    import platform
    import urllib.request
    import urllib.error
    import tempfile
    import subprocess
    import json
    import os
    import re

    if platform.system() != "Windows":
        print("  Native desktop app: Windows only. Skipping on", platform.system())
        return

    from aibrain import __version__

    print(f"\n  Downloading AIBrain desktop app v{__version__}...")

    # Resolve GitHub token — env var first, then ~/.decker_env file
    token = os.environ.get("GITHUB_PAT") or os.environ.get("GITHUB_TOKEN") or ""
    if not token:
        for env_file in [
            os.path.expanduser("~/.decker_env"),
            os.path.join(os.environ.get("USERPROFILE", ""), ".decker_env"),
        ]:
            try:
                with open(env_file, "r") as f:
                    m = re.search(r"GITHUB_PAT=['\"]?([A-Za-z0-9_]+)['\"]?", f.read())
                    if m:
                        token = m.group(1)
                        break
            except OSError:
                pass

    api_base = "https://api.github.com/repos/DeckerOps/aibrain"
    auth_headers = {"Authorization": f"token {token}", "Accept": "application/vnd.github.v3+json"} if token else {"Accept": "application/vnd.github.v3+json"}

    tmp = tempfile.mktemp(suffix=".exe")
    try:
        # Use latest GitHub release — desktop app version is independent of PyPI version
        rel_req = urllib.request.Request(f"{api_base}/releases/latest", headers=auth_headers)
        with urllib.request.urlopen(rel_req, timeout=15) as r:
            release = json.loads(r.read())

        desktop_ver = release.get("tag_name", "").lstrip("v")
        print(f"  Latest desktop release: v{desktop_ver}")

        asset_id = next(
            (a["id"] for a in release.get("assets", []) if a["name"].endswith("_x64-setup.exe")),
            None,
        )
        if asset_id is None:
            raise ValueError(f"No x64 installer asset found in latest release ({release.get('tag_name')})")

        # Download via asset API endpoint (works for private repos with token)
        dl_url = f"{api_base}/releases/assets/{asset_id}"
        dl_headers = dict(auth_headers)
        dl_headers["Accept"] = "application/octet-stream"
        dl_req = urllib.request.Request(dl_url, headers=dl_headers)

        print(f"  Asset ID: {asset_id} — streaming download...")
        with urllib.request.urlopen(dl_req, timeout=300) as resp:
            total = int(resp.headers.get("Content-Length", 0))
            downloaded = 0
            chunk = 65536
            with open(tmp, "wb") as f:
                while True:
                    data = resp.read(chunk)
                    if not data:
                        break
                    f.write(data)
                    downloaded += len(data)
                    if total > 0:
                        pct = min(downloaded * 100 // total, 100)
                        bar = "#" * (pct // 5) + "-" * (20 - pct // 5)
                        print(f"\r  [{bar}] {pct}%", end="", flush=True)

        print()  # newline after progress bar
        print("  Download complete. Running installer...")
        subprocess.run([tmp], check=False)
        print("  Desktop app installed.")
    except Exception as e:
        print(f"\n  Could not download desktop installer: {e}")
        print(f"  Download manually from: https://myaibrain.org")
    finally:
        try:
            os.unlink(tmp)
        except Exception:
            pass


def main():
    args = sys.argv[1:]

    # Issue #7: --path flag to override AIBRAIN_ROOT (avoids picking up dev DB)
    if "--path" in args:
        idx = args.index("--path")
        if idx + 1 < len(args):
            os.environ["AIBRAIN_ROOT"] = args[idx + 1]
            args = args[:idx] + args[idx + 2:]  # strip --path <val> from args
            sys.argv = [sys.argv[0]] + args

    # Global per-invocation routing flags — strip before command dispatch so
    # subcommands don't see them as positional args.
    # --fast  → fast_mode=True (no SuperWorker this run)
    # --deep  → deep_mode=True (force SuperWorker this run)
    _fast_flag = "--fast" in args
    _deep_flag = "--deep" in args
    if _fast_flag or _deep_flag:
        args = [a for a in args if a not in ("--fast", "--deep")]
        try:
            from aibrain.core.routing_settings import RoutingSettings as _RS
            _rs = _RS.load()
            _rs.fast_mode = _fast_flag
            _rs.deep_mode = _deep_flag
            _rs.save()
        except Exception:
            pass  # Non-fatal — flag parsing is best-effort

    if not args or args[0] in ("-h", "--help"):
        print(_QUICK_START.strip())
        print()
        print(__doc__.strip())
        return

    # Fix #5: --version / -v flag — return version without "Unknown command" error
    if args[0] in ("--version", "-v"):
        from aibrain import __version__
        print(f"aibrain {__version__}")
        return

    cmd = args[0]

    # --- Issue #8: aibrain help <command> ---
    if cmd == "help":
        if len(args) > 1:
            subcmd = args[1]
            if subcmd in _SUBCOMMAND_HELP:
                print(f"\n  aibrain {subcmd}")
                print(f"  {'─' * 40}")
                print(f"  {_SUBCOMMAND_HELP[subcmd]}")
                print()
            else:
                print(f"  No help available for '{subcmd}'. Run 'aibrain --help' for all commands.")
        else:
            print(_QUICK_START.strip())
            print()
            print(__doc__.strip())
        return

    if cmd == "version":
        from aibrain import __version__
        print(f"aibrain {__version__}")

    elif cmd == "create":
        from aibrain.cli.create import create_project
        name = args[1] if len(args) > 1 else ""
        if not name:
            print("Usage: aibrain create <project_name>")
            return
        sys.exit(create_project(name))

    elif cmd == "chat":
        # Issue #9: check setup before running interactive commands
        if not _is_setup_complete():
            print("Run 'aibrain setup' first to initialize your brain.")
            print("  Quick start: aibrain setup --auto")
            sys.exit(1)
        from aibrain.cli.chat import run_chat
        db = None
        if "--db" in args:
            idx = args.index("--db")
            db = args[idx + 1] if idx + 1 < len(args) else None
        sys.exit(run_chat(db_path=db))

    elif cmd == "train":
        from aibrain.cli.train import run_train
        if len(args) < 2:
            print("Usage: aibrain train <workflow> [-n iterations]")
            return
        workflow = args[1]
        n = 3
        if "-n" in args:
            idx = args.index("-n")
            try:
                n = int(args[idx + 1])
            except (IndexError, ValueError):
                pass
        sys.exit(run_train(workflow, iterations=n))

    elif cmd == "test":
        from aibrain.cli.test_cmd import run_test
        n = 3
        if "-n" in args:
            idx = args.index("-n")
            try:
                n = int(args[idx + 1])
            except (IndexError, ValueError):
                pass
        save_bl = "--save-baseline" in args
        # Remaining args that don't start with - are workflow names
        wfs = [a for a in args[1:] if not a.startswith("-") and a not in (str(n),)]
        # Remove the number that follows -n from workflows list
        if "-n" in args:
            idx = args.index("-n")
            if idx + 1 < len(args):
                try:
                    int(args[idx + 1])
                    nval = args[idx + 1]
                    wfs = [w for w in wfs if w != nval]
                except ValueError:
                    pass
        sys.exit(run_test(workflows=wfs or None, iterations=n, save_baseline=save_bl))

    elif cmd == "tools":
        from aibrain.tools import list_tools, BUILTIN_TOOLS
        print(f"\n  AIBrain Built-in Tools ({len(BUILTIN_TOOLS)})")
        print(f"  ────────────────────────")
        for name in list_tools():
            tool = BUILTIN_TOOLS[name]
            print(f"  {name:<20} {tool.description[:60]}")
        print()

    elif cmd == "browse":
        import os
        from memory_browser import browse
        db = args[1] if len(args) > 1 and not args[1].startswith("-") else None
        output = None
        if "--output" in args:
            idx = args.index("--output")
            output = args[idx + 1] if idx + 1 < len(args) else None
        browse(db, output)

    elif cmd == "forget":
        if len(args) < 2:
            print("Usage: aibrain forget <query> [--confirm]")
            return
        query = " ".join(a for a in args[1:] if a != "--confirm")
        confirm = "--confirm" in args
        import os
        from memory_lifecycle import MemoryLifecycle
        db_path = _resolve_db_path()
        ml = MemoryLifecycle(db_path)
        result = ml.forget(query, dry_run=not confirm)
        if not confirm:
            print(f"DRY RUN — would delete:")
            print(f"  Memories:     {result.get('memories', 0)}")
            print(f"  Passages:     {result.get('passages', 0)}")
            print(f"  Facts:        {result.get('facts', 0)}")
            print(f"  Entity links: {result.get('entity_links', 0)}")
            print(f"  Embeddings:   {result.get('embeddings', 0)}")
            if result.get('memory_names'):
                print(f"\n  Matching memories:")
                for name in result['memory_names'][:10]:
                    print(f"    - {name}")
            print(f"\nRun with --confirm to execute: aibrain forget \"{query}\" --confirm")
        else:
            print(f"DELETED:")
            for k, v in result.items():
                if k not in ('deleted', 'dry_run'):
                    print(f"  {k}: {v}")

    elif cmd == "mesh":
        import os
        from brain_mesh import cli_mesh
        db_path = _resolve_db_path()
        sys.exit(cli_mesh(args[1:], db_path))

    elif cmd == "history":
        import os
        from brain_versioning import cli_versioning
        db_path = _resolve_db_path()
        sys.exit(cli_versioning(args[1:], db_path))

    elif cmd == "scale":
        import os
        from brain_versioning import cli_scale
        db_path = _resolve_db_path()
        sys.exit(cli_scale(args[1:], db_path))

    elif cmd == "license":
        from aibrain_licensing import cli_license
        sys.exit(cli_license(args[1:]))

    elif cmd == "marketplace":
        import os
        from brain_marketplace import cli_marketplace
        db_path = _resolve_db_path()
        sys.exit(cli_marketplace(args[1:], db_path))

    elif cmd == "workflows":
        import os
        from workflow_scheduler import cli_workflows
        db_path = _resolve_db_path()
        cli_workflows(args[1:], db_path)

    elif cmd == "skills":
        import os
        from skill_memory import SkillMemory
        db_path = _resolve_db_path()
        sm = SkillMemory(db_path)
        profiles = sm.get_all_profiles()
        stats = sm.stats()
        print(f"=== Skill Inventory ===")
        print(f"  Episodes: {stats['total_episodes']}")
        print(f"  Active principles: {stats['total_principles']}")
        print(f"  Task types: {stats['task_types']}")
        if profiles:
            print(f"\n  Skills:")
            for p in profiles:
                trend = p.get('trend', 'stable')
                print(f"    {p['task_type']}: {p['total_episodes']} episodes, "
                      f"{p['avg_outcome']:.0%} avg, {trend}")

    elif cmd == "setup":
        import os
        # If AIBRAIN_ROOT not set and running from site-packages, default to ~/aibrain (the user install layout).
        # This is the setup wizard first-run path — we are legitimately CREATING the canonical directory here.
        if "AIBRAIN_ROOT" not in os.environ:
            if "site-packages" in str(_root):
                default_root = Path.home() / "aibrain"  # noqa:rogue-aibrain-path — setup wizard first-run creates the canonical directory
                default_root.mkdir(parents=True, exist_ok=True)
                os.environ["AIBRAIN_ROOT"] = str(default_root)
                print(f"  Data directory: {default_root}")
        from aibrain.setup_wizard import run_wizard
        run_wizard(args[1:])  # pass remaining args (--auto, --config, etc.)
        _install_desktop()

    elif cmd == "brain":
        # Delegate brain subcommands to aibrain_db
        import aibrain_db
        sys.argv = ["aibrain_db"] + args
        aibrain_db.main() if hasattr(aibrain_db, "main") else _run_db_cli(args)

    elif cmd == "server":
        import os
        if "AIBRAIN_ROOT" not in os.environ and "site-packages" in str(_root):
            os.environ["AIBRAIN_ROOT"] = str(Path.home() / "aibrain")  # noqa: site-packages user install default
        try:
            import uvicorn
        except ImportError:
            print("Error: FastAPI deps not installed. Run: pip install aibrain[api]", file=sys.stderr)
            sys.exit(1)
        uvicorn.run("backend.main:app", host="127.0.0.1", port=8001, reload=False)

    elif cmd == "serve":
        # Single command: starts API backend + dashboard UI
        import os
        import subprocess
        import threading
        import webbrowser
        import time

        if "AIBRAIN_ROOT" not in os.environ and "site-packages" in str(_root):
            os.environ["AIBRAIN_ROOT"] = str(Path.home() / "aibrain")  # noqa: site-packages user install default

        # Issue #3: check for uvicorn BEFORE printing the banner
        try:
            import uvicorn  # noqa: F401
        except ImportError:
            print("Dashboard requires: pip install aibrain[api]")
            sys.exit(1)

        api_port = 8001
        dash_port = 3000
        dashboard_dir = _root / "dashboard"

        from aibrain import __version__
        print(f"\n  AIBrain v{__version__}")
        print(f"  ─────────────────────────")

        # Start API backend in background thread
        def run_api():
            import uvicorn as _uv
            _uv.run("backend.main:app", host="127.0.0.1", port=api_port, reload=False, log_level="warning")

        api_thread = threading.Thread(target=run_api, daemon=True)
        api_thread.start()
        print(f"  API server starting on http://localhost:{api_port}")

        # Start dashboard if it exists and has node_modules
        dash_process = None
        if dashboard_dir.exists() and (dashboard_dir / "node_modules").exists():
            try:
                dash_process = subprocess.Popen(
                    ["npx", "next", "start", "-p", str(dash_port)],
                    cwd=str(dashboard_dir),
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    shell=(sys.platform == "win32"),
                )
                print(f"  Dashboard starting on http://localhost:{dash_port}")
            except Exception as _e:
                print(f"  Dashboard could not start ({_e}). Running in API-only mode.")
        elif dashboard_dir.exists():
            print(f"  Dashboard found but node_modules missing — run: cd dashboard && npm install && npm run build")
        else:
            # Issue #6: helpful message instead of error-looking output
            print(f"  Dashboard available at: https://myaibrain.org/docs/dashboard")
            print(f"  Or run from source: see https://myaibrain.org/docs/dashboard for setup instructions")
            print(f"  Running in API-only mode.")

        print(f"  ─────────────────────────")
        print(f"  Press Ctrl+C to stop\n")

        # Open browser after short delay
        def open_browser():
            time.sleep(3)
            url = f"http://localhost:{dash_port}" if dash_process else f"http://localhost:{api_port}"
            webbrowser.open(url)

        threading.Thread(target=open_browser, daemon=True).start()

        try:
            api_thread.join()
        except KeyboardInterrupt:
            print("\n  Shutting down...")
            if dash_process:
                dash_process.terminate()
            print("  Done.")

    elif cmd == "attack":
        # ATT&CK knowledge graph — search techniques, mitigations, chains
        import attack_graph
        sys.argv = ["attack_graph"] + args[1:]
        attack_graph.main()

    elif cmd == "packs":
        _handle_packs(args[1:])

    elif cmd == "onboarding-stats":
        # Phase completion funnel — cohort analysis for wizard skip-vs-churn.
        # Reads user_onboarding_phases table and prints a funnel table.
        import sqlite3 as _sqlite3
        db_path = _resolve_db_path()
        try:
            _ob_conn = _sqlite3.connect(db_path)
            _ob_conn.row_factory = _sqlite3.Row
            _ob_rows = _ob_conn.execute(
                """
                SELECT
                    phase,
                    MAX(phase_name) AS phase_name,
                    COUNT(DISTINCT CASE WHEN skipped = 0 THEN user_id END) AS completed_users,
                    COUNT(DISTINCT CASE WHEN skipped = 1 THEN user_id END) AS skipped_users,
                    COUNT(DISTINCT user_id) AS total_users
                FROM user_onboarding_phases
                GROUP BY phase
                ORDER BY phase
                """
            ).fetchall()
            _ob_conn.close()
        except Exception as _ob_e:
            print(f"Error reading onboarding phases: {_ob_e}")
            sys.exit(1)

        if not _ob_rows:
            print("\n  No onboarding phase data recorded yet.")
            print("  Phases are tracked when users complete or skip wizard steps.")
            sys.exit(0)

        _ob_baseline = max(1, _ob_rows[0]["total_users"]) if _ob_rows else 1

        print()
        print("  Onboarding Phase Funnel")
        print("  " + "=" * 55)

        _ob_skip_rates = []
        for _ob_r in _ob_rows:
            _ob_phase = _ob_r["phase"]
            _ob_name = _ob_r["phase_name"] or f"phase_{_ob_phase}"
            _ob_completed = _ob_r["completed_users"] or 0
            _ob_skipped = _ob_r["skipped_users"] or 0
            _ob_total = _ob_r["total_users"] or 0
            _ob_pct = _ob_completed / _ob_baseline * 100
            _ob_skip_pct = _ob_skipped / max(1, _ob_total) * 100
            _ob_skip_rates.append((_ob_phase, _ob_name, _ob_skip_pct))
            print(f"  Phase {_ob_phase} ({_ob_name:<14}):  {_ob_completed:>5} users  {_ob_pct:>5.1f}%")

        print()
        print(
            "  Skip rate by phase: "
            + ", ".join(f"{p}={r:.0f}%" for p, _, r in _ob_skip_rates)
        )
        print()
        sys.exit(0)

    elif cmd == "start":
        # Like rebooting your OS — restore stack, start services, ready to go
        print("AIBrain starting up...")
        import subprocess

        # Step 1: Restore stack (prompts if last != default)
        stack_script = _root / "stack_snapshot.py"
        if stack_script.exists():
            print("\n  Restoring stack...")
            subprocess.run(
                [sys.executable, str(stack_script), "startup"],
                cwd=str(_root), timeout=30,
            )
        else:
            print("  No stack_snapshot.py found, skipping restore")

        # Step 2: Auto-config free tier (ensures all free workflows enabled)
        print("\n  Configuring free-tier workflows...")
        try:
            from aibrain_update import auto_config_free_tier
            enabled, added = auto_config_free_tier()
            if enabled or added:
                print(f"  Configured: {enabled} enabled, {added} added")
            else:
                print("  All free-tier workflows already configured")
        except ImportError:
            pass

        # Step 3: Sync agent hooks
        print("\n  Syncing agent hooks...")
        try:
            from aibrain_update import sync_agent_hooks
            sync_agent_hooks()
        except ImportError:
            pass

        # Step 3b: Install compress shell hook (auto-on for all users)
        print("\n  Installing token compression hook...")
        try:
            from aibrain.tools.compress.hook import install_hook
            msg = install_hook()
            # Print only the first line (path confirmation) to keep output clean
            print(f"  {msg.splitlines()[0]}")
        except Exception as _e:
            print(f"  Skipped compress hook ({_e})")

        # Step 4: Start API server (background)
        print("\n  Starting API server on :8001...")
        try:
            import uvicorn  # noqa: F401
            subprocess.Popen(
                [sys.executable, "-m", "uvicorn", "backend.main:app",
                 "--host", "127.0.0.1", "--port", "8001"],
                cwd=str(_root),
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
            print("  API server started")
        except ImportError:
            print("  Skipped (install with: pip install aibrain[api])")

        # Step 5: Save fresh snapshot
        if stack_script.exists():
            subprocess.run(
                [sys.executable, str(stack_script), "auto"],
                cwd=str(_root), capture_output=True, timeout=15,
            )

        print("\n  AIBrain is ready.")

    elif cmd == "status":
        import subprocess
        stack_script = _root / "stack_snapshot.py"
        if stack_script.exists():
            r = subprocess.run(
                [sys.executable, str(stack_script), "current"],
                cwd=str(_root), timeout=15,
            )
        else:
            print("No stack_snapshot.py found")

    elif cmd == "stack":
        import subprocess
        stack_script = _root / "stack_snapshot.py"
        if not stack_script.exists():
            print("Error: stack_snapshot.py not found", file=sys.stderr)
            sys.exit(1)
        sub_args = args[1:] if len(args) > 1 else ["list"]
        subprocess.run(
            [sys.executable, str(stack_script)] + sub_args,
            cwd=str(_root),
        )

    elif cmd == "update":
        import subprocess
        update_script = _root / "aibrain_update.py"
        if update_script.exists():
            subprocess.run(
                [sys.executable, str(update_script)] + args[1:],
                cwd=str(_root),
            )
        else:
            print("Error: aibrain_update.py not found", file=sys.stderr)
            sys.exit(1)
        _install_desktop()

    elif cmd in ("install-desktop", "install_desktop"):
        _install_desktop()

    elif cmd == "encrypt":
        import subprocess
        encrypt_script = _root / "aibrain_encryption.py"
        if encrypt_script.exists():
            subprocess.run(
                [sys.executable, str(encrypt_script)] + args[1:],
                cwd=str(_root),
            )
        else:
            print("Error: aibrain_encryption.py not found", file=sys.stderr)
            sys.exit(1)

    elif cmd == "mcp":
        import asyncio
        try:
            from mcp_server import main as mcp_main
        except ImportError:
            print("Error: MCP deps not installed. Run: pip install aibrain[mcp]", file=sys.stderr)
            sys.exit(1)
        # Fix #3: strip the "mcp" subcommand token so mcp_server's argparse
        # only sees ["aibrain.exe"] plus any user-supplied args (e.g. --db).
        if len(sys.argv) > 1 and sys.argv[1] == "mcp":
            sys.argv.pop(1)
        asyncio.run(mcp_main())

    elif cmd == "company":
        from aibrain.core.companies import cli_main as company_cli
        company_cli(args[1:])

    elif cmd == "agent":
        from aibrain.core.companies import hire_agent, list_agents, get_agent
        subcmd = args[1] if len(args) > 1 else ""
        if subcmd == "list":
            company_id = args[args.index("--company") + 1] if "--company" in args else ""
            if not company_id:
                print("Usage: aibrain agent list --company <id>")
            else:
                agents = list_agents(company_id)
                for a in agents:
                    print(f"  {a['role']:<10} {a['name']:<20} {a['status']:<8} model={a.get('model','auto')} id={a['id']}")
        elif subcmd == "hire":
            name = args[2] if len(args) > 2 else ""
            company_id = args[args.index("--company") + 1] if "--company" in args else ""
            role = args[args.index("--role") + 1] if "--role" in args else "general"
            if not name or not company_id:
                print("Usage: aibrain agent hire <name> --company <id> [--role ceo|manager|general]")
            else:
                result = hire_agent(company_id, name, role=role)
                if "error" in result:
                    print(f"Error: {result['error']}")
                else:
                    print(f"Hired: {result['name']} ({result['role']}) id={result['id']}")
        elif subcmd == "heartbeat":
            agent_id = args[2] if len(args) > 2 else ""
            if not agent_id:
                print("Usage: aibrain agent heartbeat <agent_id>")
            else:
                from aibrain.core.heartbeat import run_heartbeat
                result = run_heartbeat(agent_id)
                summary = result.get('summary', '').encode('ascii', 'replace').decode()
                print(f"  {result.get('agent','?')}: {result['status']} (q={result.get('quality',0):.2f})")
                print(f"  {summary[:200]}")
        else:
            print("Usage: aibrain agent [list|hire|heartbeat] ...")

    elif cmd == "task":
        from aibrain.core.companies import create_task, list_tasks
        subcmd = args[1] if len(args) > 1 else ""
        if subcmd == "create":
            title = args[2] if len(args) > 2 else ""
            company_id = args[args.index("--company") + 1] if "--company" in args else ""
            assign = args[args.index("--assign") + 1] if "--assign" in args else None
            if not title or not company_id:
                print("Usage: aibrain task create <title> --company <id> [--assign <agent_id>]")
            else:
                result = create_task(company_id, title, assignee_agent_id=assign)
                print(f"Task #{result['issue_number']}: {result['title']} [{result['status']}]")
        elif subcmd == "list":
            company_id = args[args.index("--company") + 1] if "--company" in args else ""
            if not company_id:
                print("Usage: aibrain task list --company <id>")
            else:
                tasks = list_tasks(company_id)
                for t in tasks:
                    print(f"  #{t['issue_number']} [{t['status']}] {t['title']}")
        elif subcmd == "verify":
            # aibrain task verify <task_id> [--output <text>]
            from aibrain.core.task_verification import re_verify_task, list_followups
            task_id = args[2] if len(args) > 2 else ""
            if not task_id:
                print("Usage: aibrain task verify <task_id> [--output <text>]")
            else:
                work_output = None
                if "--output" in args:
                    work_output = args[args.index("--output") + 1]
                result = re_verify_task(task_id, work_output=work_output)
                print(f"Task: {task_id}")
                print(f"  verification_status: {result['verification_status']}")
                print(f"  criteria ({len(result['criteria'])}):")
                for c in result["criteria"]:
                    print(f"    - {c}")
                print(f"  gaps ({len(result['gaps'])}):")
                for g in result["gaps"]:
                    print(f"    ! {g}")
                if result["follow_up_tasks"]:
                    print(f"  follow-ups created ({len(result['follow_up_tasks'])}):")
                    for fid in result["follow_up_tasks"]:
                        print(f"    + {fid}")
                # Also show any pre-existing children
                children = list_followups(task_id)
                if children:
                    print(f"  existing child tasks: {len(children)}")
                    for c in children:
                        print(f"    #{c.get('issue_number', '?')} [{c['status']}] {c['title']}")
        else:
            print("Usage: aibrain task [create|list|verify] ...")

    elif cmd == "inbox":
        from aibrain.core.companies import pending_approvals
        company_id = args[args.index("--company") + 1] if "--company" in args else (args[1] if len(args) > 1 else "")
        if not company_id:
            print("Usage: aibrain inbox --company <id>")
        else:
            approvals = pending_approvals(company_id)
            if not approvals:
                print("No pending approvals.")
            else:
                for a in approvals:
                    print(f"  [{a['type']}] {a.get('payload', '')[:60]} — {a['status']}")
                    print(f"    ID: {a['id']}  |  aibrain approve {a['id']}")

    elif cmd == "approve":
        approval_id = args[1] if len(args) > 1 else ""
        note = args[args.index("--note") + 1] if "--note" in args else ""
        if not approval_id:
            print("Usage: aibrain approve <approval_id> [--note <text>]")
        else:
            from aibrain.core.companies import approve
            result = approve(approval_id, note)
            print(f"Approved: {result['id']} — {result.get('decision_note', '')}")

    elif cmd == "reject":
        approval_id = args[1] if len(args) > 1 else ""
        note = args[args.index("--note") + 1] if "--note" in args else ""
        if not approval_id:
            print("Usage: aibrain reject <approval_id> [--note <text>]")
        else:
            from aibrain.core.companies import reject
            result = reject(approval_id, note)
            print(f"Rejected: {result['id']} — {result.get('decision_note', '')}")

    elif cmd == "audit":
        # Show recent execution audit trail
        try:
            import sqlite3
            from aibrain_db import AIBRAIN_ROOT
            db_path = AIBRAIN_ROOT / "aibrain.db"
            db = sqlite3.connect(str(db_path))
            db.row_factory = sqlite3.Row
            limit = 20
            if args:
                try:
                    limit = int(args[0])
                except (ValueError, IndexError):
                    pass
            rows = db.execute(
                "SELECT action, success, quality_score, model_used, cost_cents, "
                "duration_ms, task_type, authority, retries, created_at "
                "FROM execution_log ORDER BY created_at DESC LIMIT ?", (limit,)
            ).fetchall()
            if not rows:
                print("No audit entries yet. Run workflows through the harness to generate data.")
                print("Example: python -m aibrain.core.workflow_runner heartbeat")
            else:
                print(f"\n{'Action':<35} {'Q':>4} {'OK':>3} {'Model':<12} {'Cost':>6} {'Time':>7} {'Type':<15}")
                print("-" * 90)
                for r in rows:
                    q = f"{r['quality_score']:.1f}" if r['quality_score'] is not None else "?"
                    ok = "Y" if r['success'] else "N"
                    cost = f"${r['cost_cents']/100:.2f}" if r['cost_cents'] else "$0"
                    ms = f"{r['duration_ms']}ms"
                    print(f"{r['action']:<35} {q:>4} {ok:>3} {r['model_used'] or '?':<12} {cost:>6} {ms:>7} {r['task_type'] or '?':<15}")
                print(f"\nTotal: {len(rows)} entries. Use `aibrain audit 50` for more.")
            db.close()
        except Exception as e:
            if "no such table" in str(e):
                print("No audit entries yet. Run `aibrain init` to create tables, then run workflows through the harness.")
            else:
                print(f"Audit error: {e}")

    elif cmd == "attention":
        # Show last N attention log entries (CLS Step 4 retrieval telemetry)
        # Usage: aibrain attention [N]
        try:
            import sqlite3
            from aibrain_db import AIBRAIN_ROOT
            db_path = AIBRAIN_ROOT / "aibrain.db"
            db = sqlite3.connect(str(db_path))
            db.row_factory = sqlite3.Row
            limit = 20
            if args:
                try:
                    limit = int(args[0])
                except (ValueError, IndexError):
                    pass
            rows = db.execute(
                "SELECT COALESCE(ts, timestamp) as ts, query, "
                "COALESCE(channel, search_type, 'semantic') as channel, "
                "COALESCE(results_count, result_count, 0) as n, "
                "top_score "
                "FROM attention_log ORDER BY id DESC LIMIT ?",
                (limit,)
            ).fetchall()
            if not rows:
                print("No attention log entries yet.")
                print("Run memory searches to generate telemetry data.")
            else:
                print(f"\n{'Timestamp':<20} {'Query':<42} {'Channel':<12} {'N':>3} {'Score':>7}")
                print("-" * 90)
                for r in rows:
                    ts = (r["ts"] or "")[:19]
                    q = (r["query"] or "")[:40]
                    ch = (r["channel"] or "semantic")[:11]
                    n = r["n"] or 0
                    sc = f"{r['top_score']:.3f}" if r["top_score"] is not None else "    ?"
                    print(f"{ts:<20} {q:<42} {ch:<12} {n:>3} {sc:>7}")
                print(f"\nTotal: {len(rows)} entries. Use `aibrain attention 50` for more.")
            db.close()
        except Exception as e:
            if "no such table" in str(e):
                print("No attention log yet. Run `aibrain init` first.")
            else:
                print(f"Attention log error: {e}")

    elif cmd == "subagent-log":
        # Show recent subagent executions from execution_log
        # Usage: aibrain subagent-log list [N]
        subcmd = args[0] if args else "list"
        if subcmd != "list":
            print(f"Unknown subagent-log subcommand: {subcmd!r}. Use: aibrain subagent-log list [N]")
            sys.exit(1)
        try:
            import sqlite3
            from aibrain_db import AIBRAIN_ROOT
            db_path = AIBRAIN_ROOT / "aibrain.db"
            db = sqlite3.connect(str(db_path))
            db.row_factory = sqlite3.Row
            limit = 20
            if len(args) > 1:
                try:
                    limit = int(args[1])
                except (ValueError, IndexError):
                    pass
            rows = db.execute("""
                SELECT action, success, quality_score, model_used, cost_cents,
                       duration_ms, task_type, entity_id, created_at
                FROM execution_log
                WHERE task_type IN ('judgment', 'complex')
                  AND (entity_type = 'subagent' OR action LIKE 'subagent.%')
                ORDER BY created_at DESC
                LIMIT ?
            """, (limit,)).fetchall()
            if not rows:
                print("No subagent executions yet.")
                print("Use start_subagent_execution() before Agent() calls to instrument spawns.")
            else:
                print(f"\n{'Action':<45} {'Q':>4} {'OK':>3} {'Model':<10} {'Cost':>6} {'Task':<12} {'Linked':<20}")
                print("-" * 105)
                for r in rows:
                    q = f"{r['quality_score']:.2f}" if r['quality_score'] is not None else "  ? "
                    ok = "Y" if r['success'] else "N"
                    cost = f"${r['cost_cents']/100:.2f}" if r['cost_cents'] else "$?"
                    action = r['action'][:44]
                    linked = r['entity_id'] or "-"
                    print(f"{action:<45} {q:>4} {ok:>3} {r['model_used'] or '?':<10} {cost:>6} {r['task_type'] or '?':<12} {linked:<20}")
                print(f"\nTotal: {len(rows)} subagent executions. Use `aibrain subagent-log list 50` for more.")
            db.close()
        except Exception as e:
            if "no such table" in str(e):
                print("No audit entries yet. Run workflows through the harness first.")
            else:
                print(f"Subagent log error: {e}")

    elif cmd == "health":
        # Show brain health summary
        try:
            import sqlite3
            from aibrain_db import AIBRAIN_ROOT
            db_path = AIBRAIN_ROOT / "aibrain.db"
            db = sqlite3.connect(str(db_path))
            db.row_factory = sqlite3.Row

            memories = db.execute("SELECT COUNT(*) FROM memories WHERE active=1").fetchone()[0]
            by_type = db.execute("SELECT type, COUNT(*) as cnt FROM memories WHERE active=1 GROUP BY type ORDER BY cnt DESC LIMIT 5").fetchall()

            # Audit stats
            try:
                total_execs = db.execute("SELECT COUNT(*) FROM execution_log").fetchone()[0]
                success_rate = db.execute("SELECT AVG(success) FROM execution_log").fetchone()[0] or 0
                avg_quality = db.execute("SELECT AVG(quality_score) FROM execution_log WHERE success=1").fetchone()[0] or 0
            except Exception:
                total_execs, success_rate, avg_quality = 0, 0, 0

            # License
            try:
                from aibrain_licensing import get_license, get_tier_status
                lic = get_license()
                tier = lic.tier
                tier_status = get_tier_status()
            except Exception:
                tier = "unknown"
                tier_status = {}

            print(f"\n  AIBrain Health Report")
            print(f"  {'='*40}")
            print(f"  Tier:           {tier}")
            print(f"  Memories:       {memories} active")
            print(f"  Top types:      {', '.join(f'{r[0]}({r[1]})' for r in by_type)}")
            print(f"  Executions:     {total_execs} total")
            print(f"  Success rate:   {success_rate*100:.0f}%")
            print(f"  Avg quality:    {avg_quality:.2f}")

            # Resource limits
            resources = tier_status.get("resources", {})
            if resources:
                print(f"\n  Resource Usage:")
                for res, info in resources.items():
                    current = info.get("current", 0)
                    limit = info.get("limit")
                    remaining = info.get("remaining")
                    if limit:
                        pct = (current / limit * 100) if limit else 0
                        bar = "#" * int(pct / 5) + "-" * (20 - int(pct / 5))
                        print(f"    {res:<20} [{bar}] {current}/{limit}")
                    else:
                        print(f"    {res:<20} {current} (unlimited)")

            print()
            db.close()
        except Exception as e:
            print(f"Health check error: {e}")

    elif cmd == "learn":
        sub = args[1] if len(args) > 1 else ""
        if sub == "config":
            from aibrain.tools.learn.config import interactive_menu
            interactive_menu()
        else:
            print("Usage: aibrain learn config")

    elif cmd == "approvals":
        from aibrain.cli.approvals import interactive_menu as approvals_menu
        approvals_menu()

    elif cmd == "next":
        from aibrain.core.state_predictor import predict_next, format_predictions
        n = 3
        if args:
            try:
                n = int(args[0])
            except (ValueError, IndexError):
                pass
        predictions = predict_next(n=n)
        print(format_predictions(predictions))

    elif cmd == "metrics":
        from aibrain.core.product_metrics import print_dashboard
        print_dashboard()

    elif cmd == "usage":
        # Current-month token-to-cents equivalence report.
        # Sums execution_log.cost_cents_equivalent (list-rate computed from
        # envelope tokens) so subscription-backed CLI runs are visible. Apr 11
        # 2026 — task #11.
        from aibrain.core.usage_report import print_usage
        sys.exit(print_usage())

    elif cmd == "routing":
        # SuperWorker routing mode + daily token budget management.
        #   aibrain routing status              — show current mode, budget, today's spend
        #   aibrain routing set-mode <mode>     — auto | always_superworker | never_superworker | manual
        #   aibrain routing set-budget <cents>  — set daily cap in cents (0 = clear cap)
        #   aibrain routing reset               — restore all settings to defaults
        #
        # Per-invocation flags (global, strip before command):
        #   aibrain --fast <cmd>  — fast_mode=True (no SuperWorker this invocation)
        #   aibrain --deep <cmd>  — deep_mode=True (force SuperWorker this invocation)
        from aibrain.core.routing_settings import (
            RoutingSettings,
            VALID_MODES,
            get_today_spend_cents,
        )

        subcmd = args[1] if len(args) > 1 else "status"

        if subcmd == "status":
            rs = RoutingSettings.load()
            today_cents = get_today_spend_cents()
            budget_cap = rs.token_budget_per_day_cents
            print()
            print("  SuperWorker Routing Settings")
            print("  " + "=" * 40)
            print(f"  Mode:              {rs.mode}")
            print(f"  Fast mode (flag):  {rs.fast_mode}")
            print(f"  Deep mode (flag):  {rs.deep_mode}")
            if budget_cap is not None:
                cap_str = f"${budget_cap / 100:.2f}/day"
                spent_str = (
                    f"${today_cents / 100:.2f}" if today_cents is not None else "unknown"
                )
                remaining = (
                    max(0, budget_cap - today_cents) if today_cents is not None else None
                )
                remaining_str = (
                    f"${remaining / 100:.2f}" if remaining is not None else "unknown"
                )
                print(f"  Daily budget cap:  {cap_str}")
                print(f"  Today's spend:     {spent_str}")
                print(f"  Remaining today:   {remaining_str}")
                if today_cents is not None and today_cents >= budget_cap:
                    print("  Budget status:     EXCEEDED — SuperWorker disabled for today")
                else:
                    print("  Budget status:     OK")
            else:
                today_str = (
                    f"${today_cents / 100:.2f}" if today_cents is not None else "unknown"
                )
                print(f"  Daily budget cap:  none (unlimited)")
                print(f"  Today's spend:     {today_str}")
            print()
            print("  Modes:")
            print("    auto              — SuperWorker for judgment/complex tasks (default)")
            print("    always_superworker — Force SuperWorker on every task")
            print("    never_superworker  — Single-worker only")
            print("    manual             — Per-invocation --fast/--deep flags decide")
            print()
            print("  Commands:")
            print("    aibrain routing set-mode <mode>     — change routing mode")
            print("    aibrain routing set-budget <cents>  — set daily cap (0=clear)")
            print("    aibrain routing reset               — restore defaults")
            print("    aibrain --fast <cmd>                — no SuperWorker this run")
            print("    aibrain --deep <cmd>                — force SuperWorker this run")
            print()

        elif subcmd == "set-mode":
            mode = args[2] if len(args) > 2 else ""
            if mode not in VALID_MODES:
                print(f"  Unknown mode: {mode!r}")
                print(f"  Valid modes: {', '.join(VALID_MODES)}")
                sys.exit(1)
            rs = RoutingSettings.load()
            rs.mode = mode
            rs.save()
            print(f"  Routing mode set to: {mode}")

        elif subcmd == "set-budget":
            raw = args[2] if len(args) > 2 else ""
            try:
                cents = int(raw)
            except (ValueError, IndexError):
                print("  Usage: aibrain routing set-budget <cents>")
                print("  Example: aibrain routing set-budget 1000  (= $10.00/day cap)")
                print("  Example: aibrain routing set-budget 0     (= clear cap)")
                sys.exit(1)
            rs = RoutingSettings.load()
            if cents <= 0:
                rs.token_budget_per_day_cents = None
                rs.save()
                print("  Daily token budget cap cleared (unlimited)")
            else:
                rs.token_budget_per_day_cents = cents
                rs.save()
                print(f"  Daily token budget set to: {cents} cents (${cents / 100:.2f}/day)")

        elif subcmd == "reset":
            rs = RoutingSettings()  # fresh defaults
            rs.save()
            print("  Routing settings reset to defaults (mode=auto, no budget cap)")

        else:
            print(f"  Unknown routing subcommand: {subcmd!r}")
            print("  Usage: aibrain routing status | set-mode <mode> | set-budget <cents> | reset")
            sys.exit(1)

    elif cmd == "corrections":
        from aibrain.core.correction_baseline import cli_corrections
        sys.exit(cli_corrections(args[1:]))

    elif cmd == "fitness":
        from aibrain.core.objective import cli_fitness
        sys.exit(cli_fitness(args[1:]))

    elif cmd == "marketing":
        sub = args[1] if len(args) > 1 else "stats"
        if sub == "stats":
            from aibrain.tools.marketing.config import stats_cli
            stats_cli(args[2:])
        else:
            print(f"Unknown marketing subcommand: {sub!r}")
            print("Usage: aibrain marketing stats [--summary|--sync]")

    elif cmd == "settings":
        from aibrain.cli.settings_menu import master_settings
        master_settings()

    elif cmd == "models":
        from aibrain.core.dynamic_router import cli_models
        sys.exit(cli_models(args[1:]))

    elif cmd == "model":
        sub = args[0] if args else "config"
        if sub == "config":
            from aibrain.tools.model.config import interactive_menu
            interactive_menu()
        else:
            print(f"Unknown model subcommand: {sub!r}")
            print("Usage: aibrain model config")

    elif cmd == "sync":
        sub = args[1] if len(args) > 1 else ""
        if sub == "config":
            from aibrain.tools.sync.config import interactive_menu
            interactive_menu()
        else:
            print("Usage: aibrain sync config")

    elif cmd == "suggest-rules":
        from aibrain.core.rule_learner import cli_suggest_rules
        sys.exit(cli_suggest_rules(args[1:]))

    elif cmd == "failures":
        from aibrain.core.correction_analysis import cli_failures
        sys.exit(cli_failures(args[1:]))

    elif cmd == "events":
        from aibrain.core.event_bus import cli_events
        sys.exit(cli_events(args[1:]))

    elif cmd == "enforcement":
        subcmd = args[1] if len(args) > 1 else "list"
        if subcmd == "list":
            from aibrain.core.enforcement import load_rules, BUILTIN_RULES
            rules = load_rules(force_reload=True)
            builtin_ids = {r.rule_id for r in BUILTIN_RULES}
            print()
            print(f"  {'RULE ID':<45}  {'SOURCE':<8}  {'SEVERITY':<8}  ENFORCEMENT POINTS")
            print(f"  {'─' * 45}  {'─' * 8}  {'─' * 8}  {'─' * 40}")
            for r in sorted(rules, key=lambda x: (x.source, x.rule_id)):
                pts = ", ".join(r.enforcement_points)
                src = r.source if r.source in ("builtin", "file") else "db"
                print(f"  {r.rule_id:<45}  {src:<8}  {r.severity:<8}  {pts}")
            print()
            print(f"  Total: {len(rules)} rules ({len(builtin_ids)} builtin, {len(rules) - len(builtin_ids)} from memory/files)")
            print()
        else:
            print(f"Unknown enforcement subcommand: {subcmd}")
            print("Usage: aibrain enforcement list")
            sys.exit(1)

    elif cmd == "profile":
        from aibrain.cli.profile_cmd import main as profile_main
        sys.exit(profile_main(args[1:]))

    elif cmd == "pre-check":
        from aibrain.core.pre_visibility import cli_main
        sys.exit(cli_main(args[1:]))

    elif cmd == "authorizations":
        from aibrain.core.authorization_ledger import cli_authorizations
        sys.exit(cli_authorizations(args[1:]))

    elif cmd == "knowledge":
        from aibrain.core.brain_self_model import cli_knowledge
        sys.exit(cli_knowledge(args[1:]))

    elif cmd == "doctor":
        # Startup / health diagnostic — detects rogue brain DBs, verifies canonical
        # resolver, reports anything that would cause a split-brain situation.
        # Created Apr 10 2026 after the 4-day split-brain bug was discovered —
        # this is the detector that would have caught it on day 1.
        try:
            from aibrain_db import AIBRAIN_ROOT, find_all_aibrain_dbs
        except Exception as e:
            print(f"FAIL: cannot import canonical resolver: {e}")
            sys.exit(2)

        print()
        print("=" * 60)
        print("  aibrain doctor — brain DB health check")
        print("=" * 60)
        print()

        # 1. Canonical root
        canonical_db = AIBRAIN_ROOT / "aibrain.db"
        canonical_exists = canonical_db.exists()
        print(f"  Canonical AIBRAIN_ROOT: {AIBRAIN_ROOT}")
        print(f"  Canonical DB exists:    {'yes' if canonical_exists else 'NO'}")
        if canonical_exists:
            try:
                size = canonical_db.stat().st_size
                print(f"  Canonical DB size:      {size:,} bytes")
            except Exception:
                pass

        # 2. Rogue DB detection
        print()
        all_dbs = find_all_aibrain_dbs()
        print(f"  aibrain.db files found on system: {len(all_dbs)}")
        for p in all_dbs:
            marker = "CANONICAL" if p == canonical_db.resolve() else "ROGUE"
            try:
                sz = p.stat().st_size
                print(f"    [{marker:<9}] {p}  ({sz:,} bytes)")
            except Exception:
                print(f"    [{marker:<9}] {p}")

        problems = len(all_dbs) - (1 if canonical_exists else 0)
        print()

        # 3. Schema sanity check on canonical
        if canonical_exists:
            try:
                import sqlite3
                db = sqlite3.connect(f"file:{canonical_db}?mode=ro", uri=True)
                tables_expected = [
                    "memories", "execution_log", "evolution_outcomes",
                    "company_issues", "companies", "attention_log",
                ]
                missing = []
                for t in tables_expected:
                    row = db.execute(
                        "SELECT name FROM sqlite_master WHERE type='table' AND name=?", (t,)
                    ).fetchone()
                    if not row:
                        missing.append(t)
                db.close()
                if missing:
                    print(f"  Schema check: MISSING tables {missing}")
                    problems += 1
                else:
                    print(f"  Schema check: all {len(tables_expected)} core tables present")
            except Exception as e:
                print(f"  Schema check: ERROR {e}")
                problems += 1

        # 3b. Vectorless active memories — silent semantic-search degradation.
        # The Apr 10 fix routed realtime_learner through aibrain_db.create_memory()
        # so every write generates an embedding. Any active memory without a
        # vec entry indicates a writer that's still bypassing the canonical path.
        # See task V97pd2lsTLU.
        if canonical_exists:
            try:
                import sqlite3
                import sqlite_vec
                _db = sqlite3.connect(f"file:{canonical_db}?mode=ro", uri=True)
                _db.enable_load_extension(True)
                sqlite_vec.load(_db)
                _db.enable_load_extension(False)
                vectorless = _db.execute(
                    "SELECT COUNT(*) FROM memories m "
                    "WHERE m.active=1 AND m.status='active' "
                    "AND NOT EXISTS (SELECT 1 FROM memories_vec v WHERE v.memory_id = m.id)"
                ).fetchone()[0]
                _db.close()
                if vectorless > 0:
                    print(f"  Vector check: {vectorless} active memories WITHOUT embeddings — silent semantic-search gap")
                    problems += 1
                else:
                    print("  Vector check: all active memories embedded")
            except Exception as e:
                print(f"  Vector check: SKIPPED ({e})")

        # 4. Summary
        print()
        print("-" * 60)
        if problems == 0:
            print("  STATUS: healthy")
            sys.exit(0)
        else:
            print(f"  STATUS: {problems} problem(s) detected")
            if len(all_dbs) > 1:
                print()
                print("  Rogue DBs indicate split-brain risk. Fix by:")
                print("    1. Choose ONE canonical location")
                print("    2. Set AIBRAIN_ROOT env var, OR write path to ~/.aibrainrc")
                print("    3. Archive the others (never delete — see never-delete rule)")
            sys.exit(1)

    elif cmd == "superworker":
        subcmd = args[1] if len(args) > 1 else ""
        if subcmd == "run":
            task = " ".join(args[2:]) if len(args) > 2 else ""
            if not task:
                print("Usage: aibrain superworker run \"<task>\"")
                sys.exit(1)

            # Resolve tier from license for quota display
            tier = None
            user_id = None
            try:
                from aibrain_licensing import get_license
                lic = get_license()
                tier = getattr(lic, "tier", None)
                user_id = getattr(lic, "key", None) or getattr(lic, "email", None)
            except Exception:
                pass  # Unlicensed install — no quota enforcement

            from aibrain.core.superworker import invoke, SuperWorkerQuotaError, _get_monthly_usage, _FREE_TIER_MONTHLY_LIMIT

            # Show quota status for free tier before running
            if tier == "free":
                _uid = user_id or "anonymous"
                used = _get_monthly_usage(_uid)
                remaining = max(0, _FREE_TIER_MONTHLY_LIMIT - used)
                print(f"  SuperWorker quota: {used}/{_FREE_TIER_MONTHLY_LIMIT} used this month ({remaining} remaining)")
                if remaining == 0:
                    print(f"  Quota exhausted. Upgrade to Pro for unlimited runs.")
                    sys.exit(1)
                print()

            print(f"  Running SuperWorker...")
            print(f"  Task: {task[:80]}{'...' if len(task) > 80 else ''}")
            print()

            try:
                result = invoke(task, user_id=user_id, tier=tier)
            except SuperWorkerQuotaError as e:
                print(f"  Quota exceeded: {e}")
                sys.exit(1)

            # Show top voices (top 3 by weight)
            if result.voices:
                sorted_voices = sorted(result.voices, key=lambda v: v.get("weight", 0), reverse=True)
                top_voices = sorted_voices[:3]
                print("  Top contributing lenses:")
                for v in top_voices:
                    weight_pct = int((v.get("weight") or 0) * 100)
                    arg_preview = v.get("argument", "")[:80]
                    print(f"    [{weight_pct:>3}%] {v['lens']}: {arg_preview}")
                print()

            # Show synthesis
            if result.synthesis:
                print("  Synthesis:")
                for line in result.synthesis.strip().splitlines()[:10]:
                    print(f"    {line}")
                print()

            # Summary line
            conf = f"{result.synthesis_confidence:.2f}" if result.synthesis_confidence is not None else "?"
            score = f"{result.eval_score:.2f}" if result.eval_score is not None else "?"
            lenses_n = len(result.lenses_consulted)
            print(f"  Lenses: {lenses_n}  |  Confidence: {conf}  |  Eval: {score}  |  Status: {result.parse_status}")
            if result.cost_cents_equivalent is not None:
                print(f"  Equivalent cost: ${result.cost_cents_equivalent / 100:.4f}")
            if result.warnings:
                for w in result.warnings[:3]:
                    print(f"  Warning: {w}")

            # Show updated quota for free tier
            if tier == "free":
                _uid = user_id or "anonymous"
                used_after = _get_monthly_usage(_uid)
                remaining_after = max(0, _FREE_TIER_MONTHLY_LIMIT - used_after)
                print(f"\n  Quota after run: {used_after}/{_FREE_TIER_MONTHLY_LIMIT} ({remaining_after} remaining)")

            sys.exit(0 if result.success else 1)
        else:
            print("Usage: aibrain superworker run \"<task>\"")
            sys.exit(1)

    elif cmd == "local-llm":
        # aibrain local-llm status — show Ollama status, available models, RAG test
        subcmd = args[1] if len(args) > 1 else "status"
        if subcmd != "status":
            print("Usage: aibrain local-llm status")
            sys.exit(1)

        from aibrain.core.local_llm import LocalLLMClient
        from aibrain.core.local_rag import build_rag_context

        print()
        print("=" * 50)
        print("  aibrain local-llm status")
        print("=" * 50)
        print()

        client = LocalLLMClient()
        available = client._get_available_models()
        running = len(available) > 0
        resolved = client.model_name() if running else None

        print(f"  Ollama running:    {'yes' if running else 'no'}")
        if available:
            print(f"  Available models:  {', '.join(available)}")
            print(f"  Selected (auto):   {resolved}")
        else:
            base_url = client.base_url
            print(f"  No models found.   (endpoint: {base_url})")
            print("  To add a model:    ollama pull gemma3:4b")
        print()

        # RAG test
        print("  RAG test (query: 'test'):")
        ctx = build_rag_context("test", top_n=2)
        if ctx:
            for line in ctx.split("\n")[:2]:
                print(f"    {line[:100]}")
        else:
            print("    (no matching memories — brain may be empty or DB unavailable)")
        print()

    elif cmd == "learn-from-history":
        # aibrain learn-from-history [--dry-run] [--last-days N] [--skip-secrets-check]
        _cmd_learn_from_history(args[1:])

    elif cmd == "intel":
        # aibrain intel run [--target NAME]
        subcmd = args[1] if len(args) > 1 else "run"
        if subcmd == "run":
            target_filter = None
            if "--target" in args:
                idx = args.index("--target")
                if idx + 1 < len(args):
                    target_filter = args[idx + 1]

            # Load target list for display
            from pathlib import Path as _P
            import json as _json
            _targets_config = _P.home() / ".aibrain" / "intel_targets.json"
            _default_targets = ["OB1", "Mem0", "Zep"]
            if _targets_config.exists():
                try:
                    _loaded = _json.loads(_targets_config.read_text())
                    _target_names = [t.get("name", "?") for t in _loaded]
                except Exception:
                    _target_names = _default_targets
            else:
                _target_names = _default_targets

            if target_filter:
                _run_targets = [target_filter]
            else:
                _run_targets = _target_names

            print(f"\n  Running intel sweep for {len(_run_targets)} target(s): {', '.join(_run_targets)}")
            print("  ─────────────────────────────────────────────────")

            from aibrain.core.workflow_runner import run_workflow
            result = run_workflow("intel_agent_run", actor="cli")

            if result.success and isinstance(result.output, dict):
                out = result.output
                analyzed = out.get("targets_analyzed", 0)
                stored = out.get("findings_stored", 0)
                tg = out.get("telegram_sent", False)
                print(f"\n  Done.")
                print(f"  Targets analyzed: {analyzed}")
                print(f"  Findings stored:  {stored}")
                print(f"  Telegram digest:  {'sent' if tg else 'not sent (check TELEGRAM_TOKEN)'}")
            elif result.success:
                print(f"\n  Done. Output: {result.output}")
            else:
                print(f"\n  Error: {result.error}")
                sys.exit(1)
            print()
        else:
            print(f"  Usage: aibrain intel run [--target NAME]")
            print(f"    No args: run all configured targets (~/.aibrain/intel_targets.json)")
            print(f"    --target NAME: run one target by name")
            print(f"  Configure targets: edit ~/.aibrain/intel_targets.json")
            print(f"  See enterprise docs: decker_system/00_meta/enterprise_intel_scheduling.md")

    elif cmd == "graph":
        # aibrain graph show <memory_id> [--depth N]
        subcmd = args[1] if len(args) > 1 else "show"
        if subcmd == "show":
            if len(args) < 3:
                print("Usage: aibrain graph show <memory_id> [--depth N]")
                sys.exit(1)
            try:
                mem_id = int(args[2])
            except ValueError:
                print(f"Error: memory_id must be an integer, got {args[2]!r}")
                sys.exit(1)
            depth = 2
            if "--depth" in args:
                try:
                    depth = int(args[args.index("--depth") + 1])
                except (IndexError, ValueError):
                    pass
            from aibrain.core.graph_memory import cli_graph_show
            cli_graph_show(mem_id, depth=depth)
        else:
            print(f"Unknown graph subcommand: {subcmd!r}")
            print("Usage: aibrain graph show <memory_id> [--depth N]")
            sys.exit(1)

    elif cmd == "backfill-confidence":
        # aibrain backfill-confidence — backfill NULL confidence values from importance
        import aibrain_db
        db_path = _resolve_db_path()
        print("Backfilling confidence scores on memories with NULL confidence...")
        result = aibrain_db.backfill_confidence_from_importance(db_path=db_path)
        n = result["updated_from_importance"]
        m = result["updated_default"]
        print(f"Updated {n} memories from importance, {m} with default 0.5")
        print(f"Total updated: {n + m}")

    elif cmd == "import-mem0":
        sys.exit(_cmd_import_mem0(args[1:]))

    elif cmd == "vacuum-vec":
        # Remove orphan rows from memories_vec (vectors with no matching memory).
        try:
            from aibrain_db import vacuum_memories_vec
            result = vacuum_memories_vec()
            deleted = result.get("deleted", 0)
            error = result.get("error")
            if error:
                print(f"vacuum-vec error: {error}", file=sys.stderr)
                sys.exit(1)
            print(f"vacuum-vec: deleted {deleted} orphan vector row(s)")
        except Exception as exc:
            print(f"vacuum-vec failed: {exc}", file=sys.stderr)
            sys.exit(1)

    elif cmd == "config":
        # `aibrain config get <key>` / `aibrain config set <key> <value>`
        # Routing keys get special validation; all others delegate to aibrain_db.
        subcmd = args[1] if len(args) > 1 else ""
        key = args[2] if len(args) > 2 else ""

        if subcmd == "get" and key == "routing":
            # Show all routing.* settings in a table
            from aibrain.core.routing_config import cli_config_get_routing
            print(cli_config_get_routing())
            return

        if subcmd == "get" and key.startswith("routing."):
            from aibrain.core.routing_config import RoutingConfig
            rc = RoutingConfig()
            all_keys = rc.get_all()
            val = all_keys.get(key, "(not set)")
            print(f"{key} = {val}")
            return

        if subcmd == "set" and key.startswith("routing."):
            value = " ".join(args[3:]) if len(args) > 3 else ""
            if not value:
                print(f"Usage: aibrain config set {key} <value>")
                sys.exit(1)
            from aibrain.core.routing_config import cli_config_set_routing
            try:
                result = cli_config_set_routing(key, value)
                print(result)
            except ValueError as e:
                print(f"Error: {e}", file=sys.stderr)
                sys.exit(1)
            return

        # Non-routing config: delegate to aibrain_db
        import aibrain_db
        sys.argv = ["aibrain_db"] + args
        aibrain_db.main() if hasattr(aibrain_db, "main") else _run_db_cli(args)

    elif cmd == "export":
        # aibrain export <file.md> [--out <out.pdf>]
        # aibrain export <dir/> [--out <out_dir/>]
        if len(args) < 2:
            print("Usage:")
            print("  aibrain export <file.md>              Export single file")
            print("  aibrain export <file.md> --out out.pdf  Custom output path")
            print("  aibrain export <dir/>                  Export all .md files in directory")
            print("  aibrain export <dir/> --out out_dir/   Export all to target directory")
            print()
            print("Requires: pip install aibrain[export]")
            sys.exit(1)

        export_path = args[1]
        out_path = None
        if "--out" in args:
            idx = args.index("--out")
            out_path = args[idx + 1] if idx + 1 < len(args) else None

        try:
            from aibrain.tools.doc_export import export_md_to_pdf, export_directory
        except ImportError as e:
            print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)

        import os as _os
        target = _os.path.expanduser(export_path)

        if _os.path.isdir(target):
            try:
                outputs = export_directory(target, out_dir=out_path)
            except Exception as e:
                print(f"Export failed: {e}", file=sys.stderr)
                sys.exit(1)
            if not outputs:
                print(f"No .md files found in: {target}")
            else:
                for p in outputs:
                    size = _os.path.getsize(p)
                    print(f"  Exported: {p}  ({size:,} bytes)")
                print(f"\n  {len(outputs)} file(s) exported.")
        else:
            try:
                result = export_md_to_pdf(target, out_path=out_path)
            except FileNotFoundError as e:
                print(f"Error: {e}", file=sys.stderr)
                sys.exit(1)
            except Exception as e:
                print(f"Export failed: {e}", file=sys.stderr)
                sys.exit(1)
            size = _os.path.getsize(result)
            print(f"Exported: {result}  ({size:,} bytes)")

    elif cmd == "dream":
        # Run nightly memory consolidation cycle through the harness
        try:
            from aibrain.core.workflow_runner import run_workflow
            print("\n  aibrain dream — starting nightly consolidation cycle...")
            result = run_workflow("memory_consolidation", actor="neuro")
            if result.success:
                print(f"  Consolidation complete. Quality score: {result.quality_score:.2f}")
            else:
                print(f"  Consolidation finished with errors: {result.error or 'unknown'}")
                sys.exit(1)
        except Exception as e:
            print(f"  dream failed: {e}", file=sys.stderr)
            sys.exit(1)

    elif cmd == "stats":
        # Show brain stats: memory count, retrieval quality, model name, DB path
        try:
            import os as _os
            import aibrain_db as _adb
            db_path = str(_adb.AIBRAIN_ROOT / "aibrain.db")
            ms = _adb.memory_summary()
            memory_count = ms["total"]

            # Retrieval quality from execution_log
            try:
                _db = _adb.get_db()
                avg_quality = _db.execute(
                    "SELECT AVG(quality_score) FROM execution_log WHERE success=1"
                ).fetchone()[0]
                retrieval_quality = round(avg_quality, 3) if avg_quality is not None else None
            except Exception:
                retrieval_quality = None

            model_name = _os.environ.get("AIBRAIN_EMBEDDING_MODEL", "all-MiniLM-L6-v2")

            print(f"\n  AIBrain Stats")
            print(f"  {'='*40}")
            print(f"  Memories:         {memory_count} active")
            print(f"  Retrieval quality:{f' {retrieval_quality:.3f}' if retrieval_quality is not None else ' n/a (no executions yet)'}")
            print(f"  Embedding model:  {model_name}")
            print(f"  DB path:          {db_path}")
            print()
        except Exception as e:
            print(f"  stats error: {e}", file=sys.stderr)
            sys.exit(1)

    elif cmd == "activate":
        # Shorthand for: aibrain license activate <key>
        if len(args) < 2:
            print("Usage: aibrain activate <key>")
            print("  Shorthand for: aibrain license activate <key>")
            sys.exit(1)
        from aibrain_licensing import cli_license
        sys.exit(cli_license(["activate", args[1]]))

    else:
        # Delegate to aibrain_db.py CLI (init, summary, search, config, etc.)
        import aibrain_db
        # Re-inject the sub-args so aibrain_db sees them as sys.argv[1:]
        sys.argv = ["aibrain_db"] + args
        aibrain_db.main() if hasattr(aibrain_db, "main") else _run_db_cli(args)


def _cmd_learn_from_history(args: list) -> None:
    """Implementation of `aibrain learn-from-history`.

    Scans ~/.claude*/projects/**/*.jsonl session files and extracts three-signal
    learning moments (corrections, praise, self_reflection) into the brain DB.

    Flags:
        --dry-run           Scan and report without writing to the DB.
        --last-days N       Only scan files modified within the last N days.
        --skip-secrets-check  Disable secrets filter (faster, less safe).
    """
    dry_run = "--dry-run" in args
    skip_secrets = "--skip-secrets-check" in args

    max_age_days: int | None = None
    if "--last-days" in args:
        idx = args.index("--last-days")
        try:
            max_age_days = int(args[idx + 1])
        except (IndexError, ValueError):
            print("Usage: aibrain learn-from-history [--dry-run] [--last-days N] [--skip-secrets-check]")
            sys.exit(1)

    from aibrain.core.retrolearn_scanner import find_session_files, count_turns, retrolearn_all

    print()
    print("  aibrain learn-from-history")
    print("  " + "─" * 40)
    if dry_run:
        print("  [DRY RUN — no writes to brain DB]")
    print()

    # Discovery phase
    print("  Scanning for Claude Code session files...")
    files = find_session_files()

    if not files:
        print("  No session files found under ~/.claude*/projects/")
        print("  (Expected .jsonl files — are you using Claude Code?)")
        return

    # Count turns for stats
    total_lines = 0
    total_user_turns = 0
    for f in files:
        lines, user_turns = count_turns(f)
        total_lines += lines
        total_user_turns += user_turns

    proj_dirs: set = set()
    for f in files:
        # Two levels up from the .jsonl: projects/<proj>/<session>.jsonl
        try:
            proj_dirs.add(f.parent.parent.name)
        except Exception:
            pass

    print(f"  Found {len(files)} session files across {len(proj_dirs)} projects")
    print(f"  Total turns: {total_lines:,}  (user turns: {total_user_turns:,})")
    if max_age_days:
        print(f"  Filtering to last {max_age_days} days")
    print()

    # Prompt — unless --dry-run flag already provided
    if not dry_run:
        try:
            choice = input("  [D] dry-run  [Y] learn  [N] skip: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            return
        if choice in ("n", "no", "skip"):
            print("  Skipped.")
            return
        if choice in ("d", "dry", "dry-run"):
            dry_run = True
            print("  Switching to dry-run mode.")

    print()
    print("  Extracting learning signals...")

    # Progress reporter
    _last: list[int] = [0]

    def _progress(idx: int, total: int, fpath: "Path") -> None:
        pct = int(100 * idx / total) if total else 100
        if pct >= _last[0] + 10 or idx == 0:
            _last[0] = pct
            print(f"  [{pct:3d}%] {idx}/{total} files processed...", end="\r", flush=True)

    result = retrolearn_all(
        files,
        dry_run=dry_run,
        progress_callback=_progress,
        max_age_days=max_age_days,
    )

    # Clear progress line
    print(" " * 60, end="\r")
    print()

    # Report
    sig = result["by_signal"]
    print(f"  Results:")
    print(f"    Files scanned:          {result['files_scanned']}")
    if result["files_skipped_dedup"] > 0:
        print(f"    Files skipped (dedup):  {result['files_skipped_dedup']}")
    if result["files_skipped_age"] > 0:
        print(f"    Files skipped (age):    {result['files_skipped_age']}")
    print()
    print(f"    Corrections extracted:  {sig.get('correction', 0)}")
    print(f"    Praise extracted:       {sig.get('praise', 0)}")
    print(f"    Self-reflections:       {sig.get('self_reflection', 0)}")
    print(f"    Total memories:         {result['total_extracted']}")
    if result["total_secrets_skipped"]:
        print(f"    Turns skipped (secrets): {result['total_secrets_skipped']}")
    if result["errors"]:
        print(f"    Errors:                 {len(result['errors'])}")
        for err in result["errors"][:3]:
            print(f"      - {err}")

    print()
    if dry_run:
        print("  Dry run complete — no changes written.")
        print("  Run without --dry-run to write to brain.")
    else:
        print(f"  Done. Added {result['total_extracted']} memories to brain.")

    print()


def run_server():
    """Entry point for `aibrain-server` console script."""
    try:
        import uvicorn
    except ImportError:
        print("Error: FastAPI deps not installed. Run: pip install aibrain[api]", file=sys.stderr)
        sys.exit(1)
    uvicorn.run("backend.main:app", host="127.0.0.1", port=8001, reload=False)


def _run_db_cli(args):
    """Fallback: call aibrain_db as a script if it has no main()."""
    import subprocess
    result = subprocess.run(
        [sys.executable, str(_root / "aibrain_db.py")] + args,
        cwd=str(_root),
    )
    sys.exit(result.returncode)


def _handle_packs(args):
    """Browse and activate brain packs (life-domain bundles)."""
    import json
    import os

    # Try multiple locations: AIBRAIN_ROOT, package dir, share/aibrain
    from aibrain_db import AIBRAIN_ROOT as _CANON_ROOT
    packs_path = None
    candidates = [
        _root / "brain_packs.json",
        Path(__file__).resolve().parent.parent / "brain_packs.json",
        _CANON_ROOT / "brain_packs.json",
        Path(sys.prefix) / "share" / "aibrain" / "brain_packs.json",
    ]
    for candidate in candidates:
        if candidate.exists():
            packs_path = candidate
            break
    if packs_path is None:
        print("Error: brain_packs.json not found. Searched:", file=sys.stderr)
        for c in candidates:
            print(f"  {c}", file=sys.stderr)
        sys.exit(1)

    data = json.loads(packs_path.read_text(encoding="utf-8"))
    packs = data.get("packs", {})

    subcmd = args[0] if args else "list"

    if subcmd in ("list", "browse"):
        print("AIBrain Packs — pick what fits your life\n")
        for key, pack in packs.items():
            tier_badge = "" if pack.get("tier") == "free" else " [Pro]"
            wf_count = len(pack.get("workflows", []))
            print(f"  {key:20s} {pack['name']}{tier_badge}")
            print(f"  {'':20s} {pack['tagline']}")
            print(f"  {'':20s} {wf_count} workflows")
            print()
        print("Activate a pack:  aibrain packs activate <name>")
        print("Example:          aibrain packs activate productivity")

    elif subcmd == "activate":
        if len(args) < 2:
            print("Usage: aibrain packs activate <pack_name>")
            print(f"Available: {', '.join(packs.keys())}")
            return

        pack_name = args[1]
        if pack_name not in packs:
            print(f"Unknown pack: {pack_name}")
            print(f"Available: {', '.join(packs.keys())}")
            return

        pack = packs[pack_name]
        pack_workflows = set(pack.get("workflows", []))

        # Load scheduled_jobs.json and enable pack workflows
        jobs_path = _root / "scheduled_jobs.json"
        if not jobs_path.exists():
            print("Error: scheduled_jobs.json not found", file=sys.stderr)
            sys.exit(1)

        jobs_data = json.loads(jobs_path.read_text(encoding="utf-8"))
        jobs = jobs_data.get("jobs", [])
        existing_names = {j["name"] for j in jobs}

        enabled_count = 0
        for job in jobs:
            if job["name"] in pack_workflows and not job.get("enabled", False):
                job["enabled"] = True
                enabled_count += 1

        # Add missing workflows with defaults from free-tier defaults or basic template
        try:
            from aibrain_update import FREE_TIER_JOB_DEFAULTS
        except ImportError:
            FREE_TIER_JOB_DEFAULTS = {}

        added_count = 0
        for wf_name in sorted(pack_workflows):
            if wf_name not in existing_names:
                defaults = FREE_TIER_JOB_DEFAULTS.get(wf_name, {})
                new_job = {
                    "name": wf_name,
                    "script": defaults.get("script", f"run_workflow.py {wf_name}"),
                    "cron": defaults.get("cron", "0 8 * * *"),
                    "enabled": True,
                    "group": defaults.get("group", "pack"),
                    "pack": pack_name,
                    "description": defaults.get("description", f"From {pack['name']} pack"),
                }
                jobs.append(new_job)
                added_count += 1

        jobs_data["jobs"] = jobs
        jobs_data["_updated"] = __import__("datetime").datetime.now().strftime("%Y-%m-%d")
        jobs_path.write_text(json.dumps(jobs_data, indent=2), encoding="utf-8")

        # Track active packs in config
        config_path = _root / "config.json"
        if config_path.exists():
            try:
                cfg = json.loads(config_path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                cfg = {}
        else:
            cfg = {}
        active_packs = set(cfg.get("active_packs", []))
        active_packs.add(pack_name)
        cfg["active_packs"] = sorted(active_packs)
        config_path.write_text(json.dumps(cfg, indent=2), encoding="utf-8")

        print(f"\n  Activated: {pack['name']}")
        print(f"  {pack['description']}")
        print(f"  Enabled {enabled_count} workflows, added {added_count} new")
        print(f"\n  Workflows in this pack:")
        for wf in sorted(pack_workflows):
            print(f"    - {wf}")

        # Inject seed memories
        seeds = pack.get("seed_memories", [])
        if seeds:
            try:
                from aibrain_db import get_db
                db = get_db()
                for seed in seeds:
                    db.execute(
                        "INSERT OR IGNORE INTO memories (name, content, type, importance, created_at, updated_at) VALUES (?, ?, ?, ?, datetime('now'), datetime('now'))",
                        (seed["name"], seed["content"], seed.get("type", "reference"), seed.get("importance", 0.5)),
                    )
                db.commit()
                print(f"  Added {len(seeds)} seed memories")
            except Exception:
                pass

        # Inject skill profiles
        skills = pack.get("skills", [])
        if skills:
            try:
                from skill_memory import SkillMemory
                import os
                db_path = _resolve_db_path()
                sm = SkillMemory(db_path)
                for skill in skills:
                    for principle in skill.get("principles", []):
                        sm.add_principle(
                            task_type=skill["task_type"],
                            principle=principle,
                            source=f"pack:{pack_name}",
                        )
                print(f"  Loaded {len(skills)} skill profiles ({sum(len(s.get('principles',[])) for s in skills)} principles)")
            except Exception:
                pass

        # Apply stack config (cron overrides)
        stack_cfg = pack.get("stack", {})
        cron_overrides = stack_cfg.get("cron_overrides", {})
        if cron_overrides:
            override_count = 0
            for job in jobs_data.get("jobs", []):
                if job["name"] in cron_overrides:
                    job["cron"] = cron_overrides[job["name"]]
                    override_count += 1
            if override_count:
                jobs_path.write_text(json.dumps(jobs_data, indent=2), encoding="utf-8")
                print(f"  Applied {override_count} cron schedule overrides")

        # Save stack snapshot for this pack
        import subprocess
        stack_script = _root / "stack_snapshot.py"
        if stack_script.exists():
            subprocess.run(
                [sys.executable, str(stack_script), "save", f"pack_{pack_name}"],
                cwd=str(_root), capture_output=True, timeout=15,
            )
            print(f"  Saved stack snapshot: pack_{pack_name}")

        # Store agent config
        agent_cfg = pack.get("agent_config", {})
        if agent_cfg:
            cfg["agent_focus"] = agent_cfg.get("focus_areas", [])
            cfg["agent_personality"] = agent_cfg.get("personality", "")
            cfg["system_prompt_addition"] = agent_cfg.get("system_prompt_addition", "")
            config_path.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
            print(f"  Agent specialisation configured: {', '.join(agent_cfg.get('focus_areas', []))}")

        # Note satellite DBs needed
        sat_dbs = pack.get("satellite_dbs", [])
        if sat_dbs:
            print(f"\n  Satellite DBs ({len(sat_dbs)}):")
            for sdb in sat_dbs:
                print(f"    - {sdb['name']}: {sdb['description']}")
            print(f"  Run 'aibrain brain import' to populate these with domain knowledge")

    elif subcmd == "active":
        config_path = _root / "config.json"
        if config_path.exists():
            try:
                cfg = json.loads(config_path.read_text(encoding="utf-8"))
                active = cfg.get("active_packs", [])
                if active:
                    print("Active packs:")
                    for p in active:
                        pack = packs.get(p, {})
                        print(f"  {p:20s} {pack.get('name', p)} — {len(pack.get('workflows', []))} workflows")
                else:
                    print("No packs activated. Run: aibrain packs activate <name>")
            except (json.JSONDecodeError, OSError):
                print("No packs activated.")
        else:
            print("No config.json found. Run: aibrain setup")

    else:
        print(f"Unknown packs command: {subcmd}")
        print("Usage: aibrain packs [list|activate <name>|active]")


def _cmd_import_mem0(args: list) -> int:
    """Implementation of `aibrain import-mem0 <file> [--dry-run] [--type TYPE]`.

    Imports a Mem0 JSON export into AIBrain's brain database.

    Mem0 export format (standard):
        [
          {"memory": "text", "metadata": {...}, "created_at": "...", "updated_at": "..."},
          ...
        ]

    Args:
        args: CLI args after the 'import-mem0' subcommand.

    Returns:
        Exit code (0 = success, 1 = error).
    """
    if not args or args[0] in ("-h", "--help"):
        print(
            "Usage: aibrain import-mem0 <path-to-mem0-export.json> [--dry-run] [--type TYPE]\n"
            "\n"
            "Import a Mem0 JSON export into your AIBrain brain database.\n"
            "\n"
            "Arguments:\n"
            "  <path>       Path to the Mem0 JSON export file\n"
            "\n"
            "Options:\n"
            "  --dry-run    Preview what would be imported without storing anything\n"
            "  --type TYPE  Memory type to assign (default: user)\n"
            "  -h, --help   Show this help message\n"
            "\n"
            "Example:\n"
            "  aibrain import-mem0 mem0_export.json\n"
            "  aibrain import-mem0 mem0_export.json --dry-run\n"
            "  aibrain import-mem0 mem0_export.json --type reference\n"
        )
        return 0

    import json

    # Parse flags
    dry_run = "--dry-run" in args

    mem_type = "user"
    if "--type" in args:
        idx = args.index("--type")
        if idx + 1 < len(args):
            mem_type = args[idx + 1]
        else:
            print("Error: --type requires a value (e.g. --type user)", file=sys.stderr)
            return 1

    # Find the file path (first positional arg)
    file_path = None
    for a in args:
        if not a.startswith("-") and a != mem_type:
            file_path = a
            break

    if not file_path:
        print("Error: no input file specified.", file=sys.stderr)
        print("Usage: aibrain import-mem0 <path-to-mem0-export.json> [--dry-run] [--type TYPE]", file=sys.stderr)
        return 1

    # Load and parse JSON
    try:
        with open(file_path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except FileNotFoundError:
        print(f"Error: file not found: {file_path}", file=sys.stderr)
        return 1
    except json.JSONDecodeError as exc:
        print(f"Error: malformed JSON in {file_path}: {exc}", file=sys.stderr)
        return 1
    except OSError as exc:
        print(f"Error reading {file_path}: {exc}", file=sys.stderr)
        return 1

    if not isinstance(data, list):
        print(f"Error: expected a JSON array at top level, got {type(data).__name__}", file=sys.stderr)
        return 1

    total = len(data)
    imported = 0
    skipped = 0

    if dry_run:
        print(f"DRY RUN — {total} entries found in {file_path}")
        print(f"Would import as type={mem_type!r}")
        print()

    import aibrain_db

    for i, entry in enumerate(data, start=1):
        if not isinstance(entry, dict):
            print(f"  [{i}/{total}] Skipped — not an object: {entry!r}")
            skipped += 1
            continue

        content = entry.get("memory", "").strip()
        if not content:
            print(f"  [{i}/{total}] Skipped — empty memory field")
            skipped += 1
            continue

        metadata = entry.get("metadata") or {}
        created_at = entry.get("created_at", "")
        updated_at = entry.get("updated_at", "")

        # Build a name from first 60 chars of content
        name = content[:60].replace("\n", " ")
        if len(content) > 60:
            name += "..."

        # Build tags from metadata keys
        tags = ",".join(str(k) for k in metadata.keys()) if metadata else "mem0"
        if not tags:
            tags = "mem0"

        if dry_run:
            print(f"  [{i}/{total}] Would import: {name!r} (type={mem_type})")
            imported += 1
            continue

        try:
            aibrain_db.create_memory(
                name=name,
                mem_type=mem_type,
                content=content,
                tags=tags,
                importance=0.5,
                source_agent="import-mem0",
            )
            imported += 1
            if total <= 50 or i % 10 == 0 or i == total:
                print(f"  Imported {imported}/{total} memories")
        except Exception as exc:
            print(f"  [{i}/{total}] Error importing entry: {exc}", file=sys.stderr)
            skipped += 1

    print()
    if dry_run:
        print(f"DRY RUN complete — would import {imported} memories, skip {skipped}")
    else:
        print(f"Import complete — {imported} memories imported, {skipped} skipped")

    return 0


if __name__ == "__main__":
    main()
