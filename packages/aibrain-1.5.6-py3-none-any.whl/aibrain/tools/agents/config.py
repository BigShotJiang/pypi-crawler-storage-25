"""
aibrain.tools.agents.config — Interactive agents configuration menu.

Reads the company_agents table and lets the user toggle agents active/inactive.
Works with the default company (first active) or AIBRAIN_COMPANY_ID env var.

Entry point: interactive_menu()
"""
from __future__ import annotations

import os
import sqlite3
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from aibrain.cli.utils import _getch


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------

def _resolve_db_path() -> str:
    """Resolve the aibrain.db path via the canonical resolver — see aibrain_db.AIBRAIN_ROOT."""
    from aibrain_db import AIBRAIN_ROOT
    return str(AIBRAIN_ROOT / "aibrain.db")


def _get_default_company_id(db_path: str) -> Optional[str]:
    """Get the default company ID (env var or first active)."""
    env_id = os.environ.get("AIBRAIN_COMPANY_ID")
    if env_id:
        return env_id
    try:
        conn = sqlite3.connect(db_path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        row = conn.execute(
            "SELECT id FROM companies WHERE status='active' ORDER BY created_at LIMIT 1"
        ).fetchone()
        conn.close()
        return row["id"] if row else None
    except Exception:
        return None


def _load_agents(db_path: str, company_id: str) -> List[Dict]:
    """Load all non-terminated agents for a company."""
    conn = sqlite3.connect(db_path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    rows = conn.execute(
        "SELECT id, name, role, title, status FROM company_agents "
        "WHERE company_id=? AND status != 'terminated' ORDER BY role, name",
        (company_id,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def _save_agent_status(db_path: str, agent_id: str, active: bool) -> None:
    """Toggle an agent's status between idle and paused."""
    new_status = "idle" if active else "paused"
    conn = sqlite3.connect(db_path, check_same_thread=False)
    conn.execute(
        "UPDATE company_agents SET status=?, updated_at=datetime('now') WHERE id=?",
        (new_status, agent_id)
    )
    conn.commit()
    conn.close()


# ---------------------------------------------------------------------------
# Status helpers (for settings_menu.py)
# ---------------------------------------------------------------------------

def get_agents_status() -> str:
    """Return a brief status string like '18/20 active'."""
    try:
        db_path = _resolve_db_path()
        company_id = _get_default_company_id(db_path)
        if not company_id:
            return 'no company'
        agents = _load_agents(db_path, company_id)
        active = sum(1 for a in agents if a.get("status") not in ("paused", "error"))
        return f'{active}/{len(agents)} active'
    except Exception:
        return 'unavailable'


# ---------------------------------------------------------------------------
# Rendering
# ---------------------------------------------------------------------------

PAGE_SIZE = 12


def _render_menu(agents: List[Dict], states: Dict[str, bool],
                 focused: int, page: int) -> str:
    start = page * PAGE_SIZE
    page_agents = agents[start:start + PAGE_SIZE]
    total_pages = max(1, (len(agents) + PAGE_SIZE - 1) // PAGE_SIZE)
    active_count = sum(1 for v in states.values() if v)

    lines = [
        '',
        '  Agents Config  (SPACE/number to toggle, P next page, ENTER save, Q quit)',
        '',
        f'  {active_count}/{len(agents)} active agents',
        '',
    ]

    for i, agent in enumerate(page_agents):
        marker = 'x' if states[agent["id"]] else ' '
        cursor = '>' if i == focused else ' '
        role = agent.get("role", "general")
        name = agent.get("name", "?")
        num = i + 1 if i < 9 else 0
        lines.append(f'  {cursor} [{marker}] {num}. {name:<22s} [{role}]')

    if total_pages > 1:
        lines.append('')
        lines.append(f'  Page {page + 1}/{total_pages}  [P] next page')

    lines.append('')
    lines.append('  ENTER to save  |  Q to quit without saving')
    lines.append('')
    return '\n'.join(lines)


# ---------------------------------------------------------------------------
# Interactive menu
# ---------------------------------------------------------------------------

def interactive_menu() -> None:
    """Launch the interactive agents configuration menu."""
    db_path = _resolve_db_path()
    company_id = _get_default_company_id(db_path)

    if not company_id:
        print('No active company found. Create one first: aibrain company create <name>')
        return

    agents = _load_agents(db_path, company_id)
    if not agents:
        print('No agents found. Hire agents first: aibrain agent hire <name> --company <id>')
        return

    # Non-tty fallback
    if not sys.stdout.isatty():
        for a in agents:
            active = a.get("status") not in ("paused", "error")
            print(f'{a["name"]}={"active" if active else "inactive"} [{a["role"]}]')
        return

    # Build states: True = active (idle/active/running), False = paused
    states: Dict[str, bool] = {}
    original: Dict[str, bool] = {}
    for a in agents:
        is_active = a.get("status") not in ("paused", "error")
        states[a["id"]] = is_active
        original[a["id"]] = is_active

    focused = 0
    page = 0

    menu_text = _render_menu(agents, states, focused, page)
    sys.stdout.write(menu_text)
    sys.stdout.flush()
    menu_lines = menu_text.count('\n')

    while True:
        ch = _getch()

        if ch in ('\r', '\n'):
            sys.stdout.write('\n')
            # Save diffs only
            changes = 0
            for aid, is_active in states.items():
                if is_active != original[aid]:
                    _save_agent_status(db_path, aid, is_active)
                    changes += 1
            active_count = sum(1 for v in states.values() if v)
            if changes:
                print(f'Saved. {active_count}/{len(agents)} agents active ({changes} changed).')
            else:
                print(f'No changes. {active_count}/{len(agents)} agents active.')
            return

        if ch in ('q', 'Q'):
            sys.stdout.write('\n')
            print('No changes.')
            return

        if ch in ('p', 'P'):
            total_pages = max(1, (len(agents) + PAGE_SIZE - 1) // PAGE_SIZE)
            page = (page + 1) % total_pages
            focused = 0

        elif ch == ' ':
            start = page * PAGE_SIZE
            page_agents = agents[start:start + PAGE_SIZE]
            if 0 <= focused < len(page_agents):
                aid = page_agents[focused]["id"]
                states[aid] = not states[aid]

        elif ch.isdigit() and ch != '0':
            idx = int(ch) - 1
            start = page * PAGE_SIZE
            page_agents = agents[start:start + PAGE_SIZE]
            if 0 <= idx < len(page_agents):
                focused = idx
                aid = page_agents[idx]["id"]
                states[aid] = not states[aid]

        elif ch == '\x1b':
            try:
                next1 = _getch()
                if next1 == '[':
                    next2 = _getch()
                    n_items = min(PAGE_SIZE, len(agents) - page * PAGE_SIZE)
                    if n_items > 0:
                        if next2 == 'A':
                            focused = (focused - 1) % n_items
                        elif next2 == 'B':
                            focused = (focused + 1) % n_items
            except Exception:
                pass

        elif ch == '\xe0' or ch == '\x00':
            try:
                next1 = _getch()
                n_items = min(PAGE_SIZE, len(agents) - page * PAGE_SIZE)
                if n_items > 0:
                    if next1 == 'H':
                        focused = (focused - 1) % n_items
                    elif next1 == 'P':
                        focused = (focused + 1) % n_items
            except Exception:
                pass

        else:
            continue

        sys.stdout.write(f'\x1b[{menu_lines}A')
        new_text = _render_menu(agents, states, focused, page)
        sys.stdout.write(new_text)
        sys.stdout.flush()
        menu_lines = new_text.count('\n')
