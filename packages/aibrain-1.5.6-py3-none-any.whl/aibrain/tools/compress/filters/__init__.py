"""Compress filters package."""
