"""
Build tool output compression filters.

Covers: next build, tsc, eslint/biome, prettier, cargo build/check/clippy,
        webpack, docker ps/images/logs.
Strips progress noise, keeps errors and summary metrics.
"""
from __future__ import annotations

import re


def compress_tsc(output: str) -> str:
    """TypeScript compiler -- keep error lines and summary only."""
    lines = output.splitlines()
    result: list[str] = []
    seen_patterns: dict[str, int] = {}

    for line in lines:
        # TS errors: "src/foo.ts(12,5): error TS2345: ..."
        if re.search(r'error TS\d+|Found \d+ error', line):
            # Deduplicate repeated error patterns (same error code, different location)
            m = re.search(r'(error TS\d+):', line)
            if m:
                code = m.group(1)
                seen_patterns[code] = seen_patterns.get(code, 0) + 1
                if seen_patterns[code] <= 10:
                    result.append(line)
                elif seen_patterns[code] == 11:
                    result.append(f'... and more {code} errors (deduplicated)')
            else:
                result.append(line)
        elif 'warning' in line.lower() and re.search(r'TS\d+', line):
            result.append(line)

    return '\n'.join(result) if result else '(no errors)'


def compress_eslint(output: str) -> str:
    """ESLint/Biome -- keep file paths + error/warning lines, drop blank lines."""
    lines = output.splitlines()
    result: list[str] = []
    current_file: str = ''
    file_errors: list[str] = []

    for line in lines:
        stripped = line.strip()
        if not stripped:
            if current_file and file_errors:
                result.append(current_file)
                result.extend(file_errors)
                result.append('')
                current_file = ''
                file_errors = []
            continue

        # File path line (absolute path or relative)
        if re.match(r'^(/|[A-Za-z]:\\|\./)', stripped) and not re.search(r'error|warning', stripped, re.I):
            if current_file and file_errors:
                result.append(current_file)
                result.extend(file_errors)
                result.append('')
            current_file = stripped
            file_errors = []
        elif re.search(r'error|warning|problem', line, re.I):
            file_errors.append(f'  {stripped}')

    if current_file and file_errors:
        result.append(current_file)
        result.extend(file_errors)

    # Summary line (e.g. "10 problems (5 errors, 5 warnings)")
    summary_lines = [l for l in lines if re.search(r'\d+ problem|\d+ error', l, re.I)]
    result.extend(summary_lines)

    return '\n'.join(result) if result else '(no issues)'


def compress_next_build(output: str) -> str:
    """Next.js build -- keep route table, errors, and final size summary."""
    lines = output.splitlines()
    result: list[str] = []
    in_routes = False

    for line in lines:
        # Route size table header
        if re.search(r'Route \(', line) or re.search(r'Page\s+Size', line):
            in_routes = True
        # End of route table
        if in_routes and line.strip() == '':
            in_routes = False

        # Keep route lines, errors, build output summary
        if in_routes or re.search(r'error|warning|failed|compiled|ready in', line, re.I):
            result.append(line.rstrip())

    return '\n'.join(result) if result else output.strip().splitlines()[-1] if output.strip() else '(no output)'


def compress_cargo_build(output: str) -> str:
    """Cargo build/check -- keep error and warning lines, drop progress."""
    lines = output.splitlines()
    result: list[str] = []

    for line in lines:
        if re.search(r'^error|^warning|Finished|error\[E', line):
            result.append(line.rstrip())

    return '\n'.join(result) if result else '(clean build)'


def compress_prettier(output: str) -> str:
    """Prettier --check -- keep only files needing formatting."""
    lines = output.splitlines()
    result = [l for l in lines if not l.startswith('Checking') and l.strip()]
    return '\n'.join(result) if result else '(all formatted)'


def compress_docker_ps(output: str) -> str:
    """
    docker ps / docker ps -a -- compact table.

    Keeps: header row + one compact line per container.
    Format: NAMES  IMAGE  STATUS  PORTS
    """
    lines = output.splitlines()
    if not lines:
        return output

    header = lines[0]
    # Parse column positions from header
    col_names = ['CONTAINER ID', 'IMAGE', 'COMMAND', 'CREATED', 'STATUS', 'PORTS', 'NAMES']
    positions: list[tuple[str, int]] = []
    for col in col_names:
        idx = header.find(col)
        if idx >= 0:
            positions.append((col, idx))
    positions.sort(key=lambda x: x[1])

    if not positions:
        return output  # fallback: unknown format

    def extract(line: str, col_idx: int, next_idx: int | None) -> str:
        if next_idx:
            return line[col_idx:next_idx].strip()
        return line[col_idx:].strip()

    containers: list[str] = []
    for line in lines[1:]:
        if not line.strip():
            continue
        parts: dict[str, str] = {}
        for i, (col, start) in enumerate(positions):
            end = positions[i + 1][1] if i + 1 < len(positions) else None
            parts[col] = extract(line, start, end)

        names = parts.get('NAMES', '')
        image = parts.get('IMAGE', '')
        status = parts.get('STATUS', '')
        ports = parts.get('PORTS', '')

        # Truncate long image names (keep registry/image:tag)
        if len(image) > 40:
            image = image[:37] + '...'

        compact = f'{names}  {image}  {status}'
        if ports:
            compact += f'  {ports}'
        containers.append(compact)

    count = len(containers)
    header = f'{count} container{"s" if count != 1 else ""}:'
    result = [header] + containers
    return '\n'.join(result)


def compress_docker_images(output: str) -> str:
    """
    docker images -- compact table.

    Format: REPOSITORY:TAG  SIZE  CREATED
    """
    lines = output.splitlines()
    if not lines:
        return output

    header = lines[0]
    col_names = ['REPOSITORY', 'TAG', 'IMAGE ID', 'CREATED', 'SIZE']
    positions: list[tuple[str, int]] = []
    for col in col_names:
        idx = header.find(col)
        if idx >= 0:
            positions.append((col, idx))
    positions.sort(key=lambda x: x[1])

    if not positions:
        return output

    def extract(line: str, col_idx: int, next_idx: int | None) -> str:
        if next_idx:
            return line[col_idx:next_idx].strip()
        return line[col_idx:].strip()

    result: list[str] = ['REPOSITORY:TAG  SIZE  CREATED']
    for line in lines[1:]:
        if not line.strip():
            continue
        parts: dict[str, str] = {}
        for i, (col, start) in enumerate(positions):
            end = positions[i + 1][1] if i + 1 < len(positions) else None
            parts[col] = extract(line, start, end)

        repo = parts.get('REPOSITORY', '')
        tag = parts.get('TAG', '')
        size = parts.get('SIZE', '')
        created = parts.get('CREATED', '')

        compact = f'{repo}:{tag}  {size}  {created}'
        result.append(compact)

    return '\n'.join(result)


def compress_docker_logs(output: str) -> str:
    """
    docker logs -- deduplicate repeated log lines.

    Groups identical lines with a count prefix.
    """
    from aibrain.tools.compress.filters.generic import deduplicate, strip_noise
    out = strip_noise(output)
    return deduplicate(out, max_repeat=3)


def compress_pip_list(output: str) -> str:
    """
    pip list -- summarise to package count only.

    "5 packages installed: certifi, requests, ..."
    """
    lines = output.splitlines()
    packages = []
    for line in lines:
        stripped = line.strip()
        if not stripped or stripped.startswith('-') or stripped.lower().startswith('package'):
            continue
        parts = stripped.split()
        if len(parts) >= 2:
            packages.append(parts[0])  # name only, no version

    if not packages:
        return output.strip()

    count = len(packages)
    # Show up to 5 names inline — enough to confirm what's installed
    shown = packages[:5]
    hidden = count - 5
    names_str = ', '.join(shown)
    if hidden > 0:
        names_str += f' (+{hidden} more)'
    return f'{count} packages installed: {names_str}'


def compress_pip_install(output: str) -> str:
    """
    pip install -- strip download progress bars, keep summary.

    Keeps: "Successfully installed", "Collecting", errors/warnings.
    Drops: download progress bar lines (━━━━).
    """
    lines = output.splitlines()
    result = []
    for line in lines:
        stripped = line.strip()
        # Progress bar lines contain unicode block chars or "eta"
        if re.search(r'[━═]{5,}|\d+\.\d+ [KMG]B/s', line):
            continue
        if stripped:
            result.append(stripped)

    # Just show final summary lines
    summary = [l for l in result if 'Successfully' in l or 'error' in l.lower() or 'warning' in l.lower()]
    collecting = [l for l in result if l.startswith('Collecting')]

    if summary:
        out_parts = []
        if collecting:
            out_parts.append(f'Collecting: {", ".join(l.split()[1] for l in collecting if len(l.split()) > 1)}')
        out_parts.extend(summary)
        return '\n'.join(out_parts)

    return '\n'.join(result) if result else output.strip()


def compress_npm(output: str) -> str:
    """
    npm install/ci -- strip deprecated warnings, keep summary.

    Keeps: "added N packages", "found N vulnerabilities", errors.
    """
    lines = output.splitlines()
    result = []
    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue
        # Skip deprecation warnings noise
        if re.match(r'npm warn deprecated', stripped):
            continue
        if re.match(r'\d+ packages are looking for funding', stripped):
            continue
        if re.match(r'run `npm fund`', stripped):
            continue
        result.append(stripped)

    return '\n'.join(result) if result else output.strip()


def compress_ps(output: str) -> str:
    """
    ps aux/ps -ef -- compact process list.

    Shows PID + short CMD, 15 processes max.
    Small lists (<=5 lines) are collapsed to process count.
    """
    lines = [l for l in output.splitlines() if l.strip()]
    if not lines:
        return output

    # Find header line index
    header_idx = next((i for i, l in enumerate(lines) if re.match(r'^\s*(PID|USER)', l, re.I)), None)
    data_lines = lines[header_idx + 1:] if header_idx is not None else lines

    count = len(data_lines)
    if count == 0:
        return output.strip()

    # Compact: show PID + process name only (strip paths and flags)
    compact = []
    process_names = []
    for line in data_lines:
        parts = line.split()
        if not parts:
            continue
        pid = parts[0]
        # CMD: take the executable name (strip path, strip flags)
        cmd_parts = parts[min(2, len(parts) - 1):]
        if cmd_parts:
            exe = cmd_parts[0].replace('\\', '/').rsplit('/', 1)[-1]
            # Append first argument if it looks like a script name
            if len(cmd_parts) > 1 and not cmd_parts[1].startswith('-') and len(cmd_parts[1]) < 30:
                exe += f' {cmd_parts[1]}'
            cmd = exe[:35]
        else:
            cmd = '?'
        compact.append(f'{pid:>6}  {cmd}')
        process_names.append(cmd)

    # For small lists (<=8 processes), show as single summary line
    if count <= 8:
        names_str = ', '.join(process_names)
        if len(names_str) > 80:
            names_str = ', '.join(process_names[:5]) + f' +{count-5} more'
        return f'{count} processes: {names_str}'

    shown = compact[:15]
    hidden = count - 15
    out = f'{count} processes:\n' + '\n'.join(shown)
    if hidden > 0:
        out += f'\n... and {hidden} more'
    return out


def compress_ls(output: str) -> str:
    """
    ls -la -- compact file listing.

    Shows count summary + names only (strip permissions/owner/dates).
    """
    lines = [l for l in output.splitlines() if l.strip()]
    if not lines:
        return output

    files = []
    dirs = []
    for line in lines:
        if line.startswith('total'):
            continue
        parts = line.split()
        if not parts:
            continue
        name = parts[-1]
        if name in ('.', '..'):
            continue
        if line.startswith('d') or (len(parts) > 0 and parts[0].startswith('d')):
            dirs.append(name)
        else:
            files.append(name)

    total = len(files) + len(dirs)
    parts_out = []
    if dirs:
        parts_out.append(f'{len(dirs)} dirs: {", ".join(dirs[:10])}{"..." if len(dirs) > 10 else ""}')
    if files:
        parts_out.append(f'{len(files)} files: {", ".join(files[:10])}{"..." if len(files) > 10 else ""}')

    return f'{total} items\n' + '\n'.join(parts_out) if parts_out else output.strip()


def compress_env(output: str) -> str:
    """
    env/printenv -- show count + short key list only, no values.

    Target: <15% of input size.
    Format: "30 env vars [HOME PATH USER PWD SHELL +25 more]"
    """
    lines = [l for l in output.splitlines() if l.strip() and '=' in l]
    if not lines:
        return output.strip()

    keys = [l.split('=', 1)[0] for l in lines]
    count = len(keys)
    # Show only first 5 key names (enough to confirm env is loaded)
    shown = keys[:5]
    hidden = count - 5
    keys_str = ' '.join(shown)
    if hidden > 0:
        keys_str += f' +{hidden} more'
    return f'{count} env vars [{keys_str}]'


# Keyword pattern for sensitive env var names (case-insensitive)
_SECRET_KEY_RE = re.compile(r'TOKEN|KEY|SECRET|PASSWORD|API|PWD', re.IGNORECASE)


def compress_printenv_single(var_name: str, output: str) -> str:
    """
    Handle `printenv VARNAME` (single-variable form).

    printenv with one argument outputs just the raw value with no KEY= prefix,
    so the normal env filter cannot redact it.  Always replace the entire output
    with a safe placeholder — we cannot tell from the value alone whether it is
    sensitive, so option (a) is used: unconditional redaction.
    """
    return '[env value hidden]'


def compress_json_cat(output: str) -> str:
    """
    cat <file>.json -- show structure (keys) without values.

    Useful for large config files.
    """
    import json as _json
    try:
        data = _json.loads(output)
    except (ValueError, TypeError):
        return output.strip()

    def _scalar_type(v) -> str:
        """Return type placeholder for a scalar value — never expose the value itself."""
        if v is None:
            return '<null>'
        if isinstance(v, bool):
            return '<bool>'
        if isinstance(v, (int, float)):
            return '<number>'
        return '<string>'

    def _describe(obj, indent=0) -> list[str]:
        prefix = '  ' * indent
        lines = []
        if isinstance(obj, dict):
            for k, v in obj.items():
                if isinstance(v, dict):
                    lines.append(f'{prefix}{k}: {{{len(v)} keys}}')
                elif isinstance(v, list):
                    lines.append(f'{prefix}{k}: [{len(v)} items]')
                else:
                    # MAJOR #4: show type name only — never truncated value (prevents partial secret leak)
                    lines.append(f'{prefix}{k}: {_scalar_type(v)}')
        elif isinstance(obj, list):
            lines.append(f'{prefix}[{len(obj)} items]')
            if obj and isinstance(obj[0], dict):
                lines.extend(_describe(obj[0], indent + 1))
        else:
            lines.append(f'{prefix}{_scalar_type(obj)}')
        return lines

    result_lines = _describe(data)
    result = '\n'.join(result_lines)
    # Only return compressed if it's actually shorter
    if len(result) < len(output):
        return result
    return output.strip()


def compress_build(tool: str, output: str) -> str:
    """Dispatch build/infra compression by tool name."""
    if not output.strip():
        return output

    t = tool.lower()
    if 'tsc' in t or 'typescript' in t:
        return compress_tsc(output)
    if 'eslint' in t or 'biome' in t or 'lint' in t:
        return compress_eslint(output)
    if 'next' in t:
        return compress_next_build(output)
    if 'cargo' in t:
        return compress_cargo_build(output)
    if 'prettier' in t:
        return compress_prettier(output)
    if t in ('docker ps', 'docker-ps'):
        return compress_docker_ps(output)
    if t in ('docker images', 'docker-images'):
        return compress_docker_images(output)
    if t in ('docker logs', 'docker-logs'):
        return compress_docker_logs(output)

    # Generic build: errors and last line
    lines = output.splitlines()
    errors = [l for l in lines if re.search(r'error|Error|ERROR', l)]
    if errors:
        return '\n'.join(errors)
    return lines[-1] if lines else '(no output)'
