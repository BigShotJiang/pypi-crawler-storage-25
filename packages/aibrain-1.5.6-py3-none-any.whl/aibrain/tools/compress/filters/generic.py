"""
Generic fallback compression filter.

Deduplicates consecutive identical lines, strips excessive blank lines,
removes common noise patterns (progress bars, spinner characters), collapses
repeated stack frames, and shows "... and N more similar lines" for runs of
similar output.
"""
from __future__ import annotations

import re
from collections import Counter


_SPINNER_RE = re.compile(r'[\|/\-\\]\s*$')
_PROGRESS_RE = re.compile(r'\[[\s=#>]+\]|\d+%|\bETA\b|\beta\b')
_BLANK_RE = re.compile(r'^\s*$')

# Stack frame patterns across languages
_FRAME_RE = re.compile(
    r'^\s*(File ".+", line \d+|'
    r'at .+\(.+:\d+:\d+\)|'
    r'at .+\(.+\)|'
    r'\S+\.py:\d+|'
    r'\S+\.(js|ts|jsx|tsx|rs|go|java|rb|cs):\d+)',
    re.IGNORECASE,
)


def deduplicate(output: str, max_repeat: int = 2) -> str:
    """
    Remove lines that appear more than *max_repeat* consecutive times.
    Also collapse runs of blank lines to a single blank.
    Shows "... and N more similar lines" when a run is collapsed.
    """
    lines = output.splitlines()
    result: list[str] = []
    counts: Counter = Counter()
    prev: str | None = None
    blank_run = 0
    suppressed = 0

    def flush_suppressed() -> None:
        nonlocal suppressed
        if suppressed > 0:
            result.append(f'... and {suppressed} more similar lines')
            suppressed = 0

    for line in lines:
        if _BLANK_RE.match(line):
            flush_suppressed()
            blank_run += 1
            if blank_run == 1:
                result.append(line)
            continue
        else:
            blank_run = 0

        if line == prev:
            counts[line] += 1
            if counts[line] <= max_repeat:
                result.append(line)
            else:
                suppressed += 1
        else:
            flush_suppressed()
            counts[line] = 1
            result.append(line)
            prev = line

    flush_suppressed()
    return '\n'.join(result)


def strip_noise(output: str) -> str:
    """Remove spinner lines and pure progress-bar lines."""
    lines = output.splitlines()
    cleaned = [
        l for l in lines
        if not _SPINNER_RE.search(l) and not _PROGRESS_RE.search(l.rstrip())
    ]
    return '\n'.join(cleaned)


def collapse_stack_frames(output: str, keep_top: int = 1, keep_bottom: int = 1) -> str:
    """
    Collapse long stack traces.

    Keeps *keep_top* frames + *keep_bottom* frames, collapses the middle.
    Works across Python, JS/TS, Rust, Go.
    """
    lines = output.splitlines()
    frame_indices = [i for i, l in enumerate(lines) if _FRAME_RE.match(l)]

    if len(frame_indices) <= keep_top + keep_bottom:
        return output  # short enough, no collapse needed

    keep_set: set[int] = set()
    # Keep first keep_top frames
    for idx in frame_indices[:keep_top]:
        keep_set.add(idx)
    # Keep last keep_bottom frames
    for idx in frame_indices[-keep_bottom:]:
        keep_set.add(idx)

    middle_count = len(frame_indices) - keep_top - keep_bottom

    result: list[str] = []
    inserted_ellipsis = False
    for i, line in enumerate(lines):
        if i in frame_indices and i not in keep_set:
            if not inserted_ellipsis:
                result.append(f'    ... ({middle_count} frames collapsed)')
                inserted_ellipsis = True
        else:
            inserted_ellipsis = False
            result.append(line)

    return '\n'.join(result)


def deduplicate_similar(output: str, threshold: int = 5) -> str:
    """
    Detect runs of lines that differ only in numbers/paths/hashes.
    When a run of *threshold* or more such "similar" lines is found,
    show the first 2 + "... and N more similar lines".
    """
    lines = output.splitlines()
    if len(lines) < threshold:
        return output

    # Normalize a line by replacing numbers, hashes, paths with placeholders
    _norm_re = re.compile(r'[0-9a-f]{6,}|\d+|/\S+|\\\\?\S+')

    def normalize(line: str) -> str:
        return _norm_re.sub('X', line)

    result: list[str] = []
    i = 0

    while i < len(lines):
        norm = normalize(lines[i])
        # Look ahead for similar lines
        j = i + 1
        while j < len(lines) and normalize(lines[j]) == norm:
            j += 1

        run_length = j - i
        if run_length >= threshold:
            result.append(lines[i])
            result.append(lines[i + 1])
            hidden = run_length - 2
            result.append(f'... and {hidden} more similar lines')
            i = j
        else:
            result.append(lines[i])
            i += 1

    return '\n'.join(result)


_ERROR_LINE_RE = re.compile(r'\b(error|Error|ERROR|exception|Exception|EXCEPTION|fail|FAIL|Fail)\b')
_PROGRESS_LINE_RE = re.compile(r'^(Processing|Loading|Checking|Scanning|Fetching|Downloading|Uploading|Building|Compiling)\s', re.IGNORECASE)


def compress_generic(output: str) -> str:
    """
    Apply generic noise stripping + deduplication + stack collapse.

    If the output has clear error lines mixed with progress/noise lines,
    extract only the error lines (plus last 2 lines for context).
    """
    if not output.strip():
        return output

    lines = output.splitlines()

    # Check if this looks like a progress+error mix
    progress_lines = [l for l in lines if _PROGRESS_LINE_RE.match(l.strip())]
    error_lines = [l for l in lines if _ERROR_LINE_RE.search(l)]

    if error_lines and len(progress_lines) >= len(lines) * 0.3:
        # Mostly progress output with some errors -- extract errors + last line
        tail = lines[-2:] if len(lines) >= 2 else lines[-1:]
        result = error_lines + [l for l in tail if l not in error_lines]
        return '\n'.join(result).strip()

    out = strip_noise(output)
    out = collapse_stack_frames(out)
    out = deduplicate(out)
    return out.strip()
