"""
aibrain.tools.compress.config — Per-type compression toggle configuration.

Config file: ~/.aibrain/compress.toml
Env vars override config file (highest precedence).

Example compress.toml:
    [compress]
    enabled = true   # master switch — false disables all compression

    [compress.git]
    enabled = true

    [compress.test]
    enabled = true

    [compress.build]
    enabled = true

    [compress.docker]
    enabled = true

    [compress.pip]
    enabled = true

    [compress.env]
    enabled = false   # turn off env compression to preserve raw output for learning

    [compress.json]
    enabled = true

    [compress.traceback]
    enabled = true

Precedence: env var (highest) > config file > default (all on).
"""
from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any

# Env var names per category
_DISABLE_MAP: dict[str, str] = {
    'git':       'AIBRAIN_COMPRESS_DISABLE_GIT',
    'test':      'AIBRAIN_COMPRESS_DISABLE_TEST',
    'build':     'AIBRAIN_COMPRESS_DISABLE_BUILD',
    'docker':    'AIBRAIN_COMPRESS_DISABLE_DOCKER',
    'pip':       'AIBRAIN_COMPRESS_DISABLE_PIP',
    'env':       'AIBRAIN_COMPRESS_DISABLE_ENV',
    'json':      'AIBRAIN_COMPRESS_DISABLE_JSON',
    'traceback': 'AIBRAIN_COMPRESS_DISABLE_TRACEBACK',
}

_CONFIG_PATH = Path.home() / '.aibrain' / 'compress.toml'

# Cached config — loaded once per process
_config_cache: dict | None = None


def _load_toml_file(path: Path) -> dict:
    """Load a TOML file. Uses stdlib tomllib (Python 3.11+) or manual parser."""
    if sys.version_info >= (3, 11):
        import tomllib
        with open(path, 'rb') as f:
            return tomllib.load(f)
    else:
        # Minimal TOML parser for older Python — handles [section], key = value
        return _parse_toml_minimal(path.read_text(encoding='utf-8'))


def _parse_toml_minimal(text: str) -> dict:
    """
    Minimal TOML parser. Supports:
      - [section] and [section.subsection]
      - key = value (string, bool, int, float)
      - # comments
    """
    result: dict = {}
    current: dict = result
    current_path: list[str] = []

    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith('#'):
            continue

        if line.startswith('[') and line.endswith(']'):
            # Section header
            section = line[1:-1].strip()
            parts = section.split('.')
            current = result
            current_path = parts
            for part in parts:
                current = current.setdefault(part, {})
            continue

        if '=' in line:
            key, _, raw_val = line.partition('=')
            key = key.strip()
            raw_val = raw_val.strip()

            # Remove inline comment
            if ' #' in raw_val:
                raw_val = raw_val[:raw_val.index(' #')].strip()

            # Parse value type
            if raw_val.lower() == 'true':
                val: Any = True
            elif raw_val.lower() == 'false':
                val = False
            elif raw_val.startswith('"') or raw_val.startswith("'"):
                val = raw_val.strip('"\'')
            else:
                try:
                    val = int(raw_val)
                except ValueError:
                    try:
                        val = float(raw_val)
                    except ValueError:
                        val = raw_val

            current[key] = val

    return result


def load_config() -> dict:
    """
    Load compress config from ~/.aibrain/compress.toml.
    Returns {} if no config file. Result is cached per process.
    """
    global _config_cache
    if _config_cache is not None:
        return _config_cache
    if _CONFIG_PATH.exists():
        try:
            _config_cache = _load_toml_file(_CONFIG_PATH)
        except Exception:
            _config_cache = {}
    else:
        _config_cache = {}
    return _config_cache


def _invalidate_cache() -> None:
    """Force config reload on next call (used by config set/reset commands)."""
    global _config_cache
    _config_cache = None


def is_disabled(category: str) -> bool:
    """
    Return True if compression for *category* should be skipped.

    Precedence: AIBRAIN_COMPRESS_DISABLE (master) > per-type env var > config file.
    Default: enabled (return False).
    """
    # Master disable
    if os.environ.get('AIBRAIN_COMPRESS_DISABLE'):
        return True

    # Per-type env var (empty string = not set = not disabled)
    env_var = _DISABLE_MAP.get(category, '')
    if env_var and os.environ.get(env_var):
        return True

    # Config file
    cfg = load_config()
    compress_cfg = cfg.get('compress', {})

    # Master enabled flag in config
    if not compress_cfg.get('enabled', True):
        return True

    # Per-category enabled flag
    category_cfg = compress_cfg.get(category, {})
    if isinstance(category_cfg, dict):
        if not category_cfg.get('enabled', True):
            return True

    return False


def get_effective_config() -> dict:
    """
    Return effective config merging env vars + config file + defaults.
    Used by `aibrain-compress config show`.
    """
    categories = list(_DISABLE_MAP.keys())
    cfg = load_config()
    compress_cfg = cfg.get('compress', {})

    master_env = bool(os.environ.get('AIBRAIN_COMPRESS_DISABLE'))
    master_cfg = compress_cfg.get('enabled', True)

    result: dict = {
        'master': {
            'enabled': not master_env and master_cfg,
            'source': 'env' if master_env else ('config' if 'enabled' in compress_cfg else 'default'),
        },
        'categories': {},
    }

    for cat in categories:
        env_var = _DISABLE_MAP[cat]
        env_disabled = bool(os.environ.get(env_var))
        cat_cfg = compress_cfg.get(cat, {})
        cfg_enabled = cat_cfg.get('enabled', True) if isinstance(cat_cfg, dict) else True
        effective = not master_env and master_cfg and not env_disabled and cfg_enabled

        if env_disabled:
            source = 'env'
        elif isinstance(cat_cfg, dict) and 'enabled' in cat_cfg:
            source = 'config'
        else:
            source = 'default'

        result['categories'][cat] = {
            'enabled': effective,
            'source': source,
            'env_var': env_var,
        }

    return result


def set_config_value(section_key: str, value: str) -> str:
    """
    Write a value to ~/.aibrain/compress.toml.
    section_key format: 'compress.git.enabled' or 'compress.enabled'
    Returns a status message.
    """
    parts = section_key.split('.')
    if len(parts) < 2:
        return f'Error: key must be in format <section>.<key> (got {section_key!r})'

    # Parse value
    parsed: Any
    if value.lower() == 'true':
        parsed = True
    elif value.lower() == 'false':
        parsed = False
    else:
        try:
            parsed = int(value)
        except ValueError:
            try:
                parsed = float(value)
            except ValueError:
                parsed = value

    # Load current config (raw)
    _CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    cfg = load_config()

    # Navigate/create nested structure
    node = cfg
    for part in parts[:-1]:
        node = node.setdefault(part, {})
    node[parts[-1]] = parsed

    # Write back as TOML
    _write_toml(cfg, _CONFIG_PATH)
    _invalidate_cache()

    return f'Set {section_key} = {parsed!r} in {_CONFIG_PATH}'


def reset_config() -> str:
    """Delete the config file. Returns status message."""
    _invalidate_cache()
    if _CONFIG_PATH.exists():
        _CONFIG_PATH.unlink()
        return f'Deleted {_CONFIG_PATH}'
    return f'No config file at {_CONFIG_PATH}'


# ---------------------------------------------------------------------------
# Interactive menu
# ---------------------------------------------------------------------------

# Menu items: (label, description, config_key)
_MENU_ITEMS = [
    ('Git',        'status, diff, log, push',       'git'),
    ('Tests',      'pytest, vitest, jest, cargo test', 'test'),
    ('Build',      'tsc, eslint, cargo build, prettier', 'build'),
    ('Docker',     'ps, images, logs',              'docker'),
    ('Pip',        'list, install',                 'pip'),
    ('Env',        'environment variables',         'env'),
    ('JSON',       'cat *.json, config files',      'json'),
    ('Tracebacks', 'Python stack traces',           'traceback'),
]


def _getch() -> str:
    """Read a single keypress without echo. Cross-platform.

    Delegates to the shared aibrain.cli.utils._getch so there is one
    canonical implementation across all interactive menus.
    """
    from aibrain.cli.utils import _getch as _shared_getch
    return _shared_getch()


def _get_initial_states() -> list[bool]:
    """Return current enabled state for each menu item (default: all True)."""
    cfg = load_config()
    compress_cfg = cfg.get('compress', {})
    states = []
    for _, _, key in _MENU_ITEMS:
        cat_cfg = compress_cfg.get(key, {})
        if isinstance(cat_cfg, dict):
            states.append(cat_cfg.get('enabled', True))
        else:
            states.append(True)
    return states


def _render_menu(states: list[bool], focused: int) -> str:
    """Render the menu to a string."""
    lines = [
        '',
        '  Compression settings (SPACE/number to toggle, ENTER to save, Q to quit)',
        '',
    ]
    for i, (label, desc, _) in enumerate(_MENU_ITEMS):
        marker = 'x' if states[i] else ' '
        cursor = '>' if i == focused else ' '
        lines.append(f'  {cursor} [{marker}] {i + 1}. {label:<12} {desc}')
    lines.append('')
    lines.append('  Press ENTER to save  |  Q to quit without saving')
    lines.append('')
    return '\n'.join(lines)


def _save_states(states: list[bool]) -> None:
    """Write menu toggle states to compress.toml."""
    _CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    cfg = load_config()

    compress_cfg = cfg.setdefault('compress', {})
    for i, (_, _, key) in enumerate(_MENU_ITEMS):
        cat_cfg = compress_cfg.setdefault(key, {})
        if not isinstance(cat_cfg, dict):
            compress_cfg[key] = {}
            cat_cfg = compress_cfg[key]
        cat_cfg['enabled'] = states[i]

    _write_toml(cfg, _CONFIG_PATH)
    _invalidate_cache()


def interactive_menu() -> None:
    """
    Launch an interactive checklist menu for compression settings.

    Non-tty fallback: prints plain key=value lines to stdout.
    """
    # Non-tty fallback: print plain config
    if not sys.stdout.isatty():
        cfg = load_config()
        compress_cfg = cfg.get('compress', {})
        for _, _, key in _MENU_ITEMS:
            cat_cfg = compress_cfg.get(key, {})
            enabled = cat_cfg.get('enabled', True) if isinstance(cat_cfg, dict) else True
            print(f'{key}={"enabled" if enabled else "disabled"}')
        return

    states = _get_initial_states()
    focused = 0
    n = len(_MENU_ITEMS)

    # Draw initial menu
    menu_text = _render_menu(states, focused)
    sys.stdout.write(menu_text)
    sys.stdout.flush()

    # Count lines drawn so we can redraw in-place
    menu_lines = menu_text.count('\n')

    while True:
        ch = _getch()

        # ENTER (carriage return or newline)
        if ch in ('\r', '\n'):
            # Move cursor past the menu
            sys.stdout.write('\n')
            _save_states(states)
            print('Saved.')
            return

        # Q or q — quit without saving
        if ch in ('q', 'Q'):
            sys.stdout.write('\n')
            print('No changes.')
            return

        # Number keys 1-8
        if ch.isdigit():
            idx = int(ch) - 1
            if 0 <= idx < n:
                states[idx] = not states[idx]
                focused = idx

        # SPACE — toggle focused item
        elif ch == ' ':
            states[focused] = not states[focused]

        # Arrow keys (escape sequences) — move focus
        elif ch == '\x1b':
            # Try to read rest of escape sequence
            try:
                next1 = _getch()
                if next1 == '[':
                    next2 = _getch()
                    if next2 == 'A':  # Up
                        focused = (focused - 1) % n
                    elif next2 == 'B':  # Down
                        focused = (focused + 1) % n
            except Exception:
                pass

        else:
            continue

        # Redraw: move cursor up menu_lines lines, then reprint
        sys.stdout.write(f'\x1b[{menu_lines}A')
        new_text = _render_menu(states, focused)
        sys.stdout.write(new_text)
        sys.stdout.flush()
        menu_lines = new_text.count('\n')


def _write_toml(data: dict, path: Path) -> None:
    """Write a nested dict as minimal TOML (only supports str/bool/int/float values)."""
    lines: list[str] = []

    def _write_section(d: dict, prefix: str) -> None:
        # First pass: scalar key=value pairs at this level
        scalars = {k: v for k, v in d.items() if not isinstance(v, dict)}
        dicts = {k: v for k, v in d.items() if isinstance(v, dict)}

        if scalars:
            if prefix:
                lines.append(f'\n[{prefix}]')
            for k, v in scalars.items():
                if isinstance(v, bool):
                    lines.append(f'{k} = {"true" if v else "false"}')
                elif isinstance(v, str):
                    lines.append(f'{k} = "{v}"')
                else:
                    lines.append(f'{k} = {v}')

        for k, v in dicts.items():
            sub_prefix = f'{prefix}.{k}' if prefix else k
            _write_section(v, sub_prefix)

    _write_section(data, '')
    path.write_text('\n'.join(lines).strip() + '\n', encoding='utf-8')
