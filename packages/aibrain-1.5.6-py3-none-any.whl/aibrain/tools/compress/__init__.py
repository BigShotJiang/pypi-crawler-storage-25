"""
aibrain.tools.compress -- AIBrain-native token compression for CLI output.

Zero telemetry, zero network calls, pure Python stdlib.

CLI usage:
    # Pipe mode (most common -- shell hook uses this)
    git status | aibrain-compress -- git status
    git diff   | aibrain-compress -- git diff

    # Wrap mode (run command and compress output in one call)
    aibrain-compress git status
    aibrain-compress git diff HEAD~1

    # Install shell hook (makes git/pytest/etc auto-compress)
    aibrain-compress init
    aibrain-compress disable      # disable / uninstall hook
    aibrain-compress uninstall    # alias for disable

    # Config management
    aibrain-compress config show                          # effective config
    aibrain-compress config set compress.git.enabled false
    aibrain-compress config reset                         # delete config file

Public API:
    from aibrain.tools.compress import compress

    compressed = compress(command=['git', 'status'], output=raw_stdout)

Per-type compression toggles (env vars):
    AIBRAIN_COMPRESS_DISABLE                  Master disable — turns off ALL compression
    AIBRAIN_COMPRESS_DISABLE_GIT              Disable git compression
    AIBRAIN_COMPRESS_DISABLE_TEST             Disable test-runner compression
    AIBRAIN_COMPRESS_DISABLE_BUILD            Disable build-tool compression
    AIBRAIN_COMPRESS_DISABLE_DOCKER           Disable docker compression
    AIBRAIN_COMPRESS_DISABLE_PIP              Disable pip compression
    AIBRAIN_COMPRESS_DISABLE_ENV              Disable env/printenv compression
    AIBRAIN_COMPRESS_DISABLE_JSON             Disable JSON cat compression
    AIBRAIN_COMPRESS_DISABLE_TRACEBACK        Disable Python traceback compression

Config file (~/.aibrain/compress.toml):
    [compress]
    enabled = true

    [compress.git]
    enabled = true

    [compress.env]
    enabled = false   # example: keep raw env output for learning log

Env vars override config file (highest precedence).

Raw output learning log:
    AIBRAIN_COMPRESS_LEARN_LOG=/path/to/raw.log
    When set, compress() appends raw output BEFORE compressing to this log file.
    Rotates at 10MB (keeps last 2 rotations: .1 .2).
    Format:
        --- 2026-04-09T11:30:00Z | git status | /cwd ---
        [full raw output]
    Useful for realtime_learner.py to access full uncompressed context.
"""
from __future__ import annotations

import os
import re
import subprocess
import sys
from datetime import datetime, timezone
from typing import Sequence

from aibrain.tools.compress.filters.git import compress_git
from aibrain.tools.compress.filters.test import compress_test
from aibrain.tools.compress.filters.build import (
    compress_build,
    compress_docker_ps,
    compress_docker_images,
    compress_docker_logs,
    compress_pip_list,
    compress_pip_install,
    compress_npm,
    compress_ps,
    compress_ls,
    compress_env,
    compress_printenv_single,
    compress_json_cat,
)
from aibrain.tools.compress.filters.generic import compress_generic
from aibrain.tools.compress.config import is_disabled


__all__ = ['compress', 'main']

__version__ = '2.1.0'

# Max log file size before rotation (10 MB)
_LOG_MAX_BYTES = 10 * 1024 * 1024


# ---------------------------------------------------------------------------
# Raw output learning log
# ---------------------------------------------------------------------------

def _redact_secrets_for_log(text: str) -> str:
    """
    Light secret-redaction pass applied to output BEFORE writing to the learn log.

    Redacts any line matching KEY=VALUE where the key name contains a secret
    keyword (TOKEN, KEY, SECRET, PASSWORD, API, PWD — case-insensitive).
    Does NOT alter the main compression pipeline — this is log-only sanitisation.
    """
    _secret_key_re = re.compile(
        r'^([A-Z_][A-Z0-9_]*(?:TOKEN|KEY|SECRET|PASSWORD|API|PWD)[A-Z0-9_]*)=(.+)$',
        re.IGNORECASE | re.MULTILINE,
    )
    return _secret_key_re.sub(r'\1=[redacted]', text)


def _append_learn_log(command: Sequence[str], raw: str) -> None:
    """
    Append raw output to the learning log file if AIBRAIN_COMPRESS_LEARN_LOG is set.
    Rotates at 10MB: .log -> .log.1 -> .log.2 (keeps last 2 rotations).

    # PIPELINE STATUS (2026-04-09): DATA COLLECTION ONLY
    # ---------------------------------------------------
    # This function writes raw CLI output to a log file. Nothing reads it.
    # realtime_learner.py watches conversation JSONL logs, NOT this file.
    # No training loop, no ingestion pipeline, no feedback mechanism exists
    # that consumes this log and feeds it back into compression tuning or
    # brain memory.
    #
    # The data IS useful — it captures pre-compression ground truth that
    # could train better filters. But the pipeline to do so has not been
    # built yet. See docs/learn_log_status.md for the task spec.
    #
    # SECURITY: log is pre-filtered for secrets but may still contain
    # sensitive command output. Do not commit or sync this file.
    """
    log_path_str = os.environ.get('AIBRAIN_COMPRESS_LEARN_LOG')
    if not log_path_str or not raw:
        return

    import pathlib
    log_path = pathlib.Path(log_path_str)
    try:
        log_path.parent.mkdir(parents=True, exist_ok=True)

        # Rotate if needed
        if log_path.exists() and log_path.stat().st_size >= _LOG_MAX_BYTES:
            _rotate_log(log_path)

        # Build header
        ts = datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
        cmd_str = ' '.join(str(c) for c in command)
        try:
            cwd = os.getcwd()
        except OSError:
            cwd = '?'

        # Pre-filter secrets before writing to log.
        # Special case: printenv VARNAME outputs a bare value with no KEY= prefix —
        # _redact_secrets_for_log cannot match it, so replace the entire payload.
        tool_name = str(command[0]).lower().replace('\\', '/').rsplit('/', 1)[-1]
        if tool_name.endswith('.exe'):
            tool_name = tool_name[:-4]
        if tool_name == 'printenv' and len(command) == 2:
            safe_raw = '[env value hidden]\n'
        else:
            safe_raw = _redact_secrets_for_log(raw)

        header = f'--- {ts} | {cmd_str} | {cwd} ---\n'
        entry = header + safe_raw
        if not entry.endswith('\n'):
            entry += '\n'

        with open(log_path, 'a', encoding='utf-8', errors='replace') as f:
            f.write(entry)

    except Exception:
        pass  # never crash the compress pipeline


def _rotate_log(log_path: 'pathlib.Path') -> None:  # noqa: F821
    """Rotate log: .log.1 -> .log.2, .log -> .log.1. Drop .log.2 if exists."""
    import pathlib

    p1 = pathlib.Path(str(log_path) + '.1')
    p2 = pathlib.Path(str(log_path) + '.2')

    # Drop oldest
    if p2.exists():
        try:
            p2.unlink()
        except Exception:
            pass

    # Shift existing rotations
    if p1.exists():
        try:
            p1.rename(p2)
        except Exception:
            pass

    # Current -> .1
    try:
        log_path.rename(p1)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def compress(command: Sequence[str], output: str) -> str:
    """
    Compress *output* produced by *command*.

    :param command: The argv list of the command that produced the output
                    (e.g. ['git', 'status'] or ['cargo', 'test']).
    :param output: Raw combined stdout+stderr string.
    :returns: Compressed string. Never raises -- falls back to generic on error.
    """
    if not command:
        return compress_generic(output)

    # Log raw output BEFORE compression (if enabled via AIBRAIN_COMPRESS_LEARN_LOG)
    _append_learn_log(command, output)

    tool = command[0].lower() if command[0] else ''

    # Strip leading path component on Windows (e.g. C:\Windows\...\git.exe -> git)
    if '/' in tool or '\\' in tool:
        tool = tool.replace('\\', '/').rsplit('/', 1)[-1]
    # Strip .exe suffix
    if tool.endswith('.exe'):
        tool = tool[:-4]

    try:
        if tool == 'git':
            if is_disabled('git'):
                return compress_generic(output)
            subcommand = _git_subcommand(command[1:])
            return compress_git(subcommand, output)

        if tool in ('pytest', 'py.test'):
            if is_disabled('test'):
                return compress_generic(output)
            return compress_test('pytest', output)

        if tool == 'python' and any(
            'pytest' in a or 'test' in a for a in command[1:]
        ):
            if is_disabled('test'):
                return compress_generic(output)
            return compress_test('pytest', output)

        if tool == 'cargo':
            sub = command[1] if len(command) > 1 else ''
            if sub == 'test':
                if is_disabled('test'):
                    return compress_generic(output)
                return compress_test('cargo', output)
            if is_disabled('build'):
                return compress_generic(output)
            return compress_build('cargo', output)

        if tool in ('vitest', 'jest'):
            if is_disabled('test'):
                return compress_generic(output)
            return compress_test(tool, output)

        if tool == 'go' and len(command) > 1 and command[1] == 'test':
            if is_disabled('test'):
                return compress_generic(output)
            return compress_test('go test', output)

        if tool in ('tsc', 'eslint', 'biome', 'prettier'):
            if is_disabled('build'):
                return compress_generic(output)
            return compress_build(tool, output)

        if tool in ('next', 'npx') and any('next' in a for a in command):
            if is_disabled('build'):
                return compress_generic(output)
            return compress_build('next', output)

        if tool == 'docker':
            if is_disabled('docker'):
                return compress_generic(output)
            sub = command[1].lower() if len(command) > 1 else ''
            if sub == 'ps':
                return compress_docker_ps(output)
            if sub == 'images':
                return compress_docker_images(output)
            if sub == 'logs':
                return compress_docker_logs(output)
            return compress_generic(output)

        if tool == 'pip':
            if is_disabled('pip'):
                return compress_generic(output)
            sub = command[1].lower() if len(command) > 1 else ''
            if sub == 'list':
                return compress_pip_list(output)
            if sub in ('install', 'download'):
                return compress_pip_install(output)
            return compress_generic(output)

        if tool in ('npm', 'npx', 'pnpm', 'yarn'):
            sub = command[1].lower() if len(command) > 1 else ''
            if sub in ('install', 'ci', 'i', 'add'):
                if is_disabled('build'):
                    return compress_generic(output)
                return compress_npm(output)
            return compress_generic(output)

        if tool in ('ps',):
            return compress_ps(output)

        if tool in ('ls', 'dir'):
            return compress_ls(output)

        if tool in ('env', 'printenv', 'set'):
            if is_disabled('env'):
                return compress_generic(output)
            # printenv VARNAME (single-var form) outputs a bare value with no KEY= prefix.
            # The normal env filter cannot recognise or redact it, so intercept here and
            # unconditionally replace the output with a safe placeholder (option a).
            if tool == 'printenv' and len(command) == 2:
                var_name = str(command[1])
                return compress_printenv_single(var_name, output)
            return compress_env(output)

        if tool in ('cat', 'type') and command and any(
            a.endswith('.json') for a in command[1:]
        ):
            if is_disabled('json'):
                return compress_generic(output)
            return compress_json_cat(output)

        if tool == 'python':
            # Python script output with stack trace -- strip code lines, keep File lines + error
            if is_disabled('traceback'):
                return compress_generic(output)
            return _compress_python_traceback(output)

        return compress_generic(output)

    except Exception:
        return output  # never crash -- return raw on any error


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _compress_python_traceback(output: str) -> str:
    """
    Compress Python tracebacks.

    Strategy: collapse File chain to "file:line(fn) -> ..." format.
    Shows: Traceback header + compact chain + error type/message.
    Falls back to generic if no traceback detected.

    Example output:
        Traceback: app.py:42(main) -> utils.py:7(transform)
        ValueError: invalid input
    """
    if 'Traceback' not in output and 'Error:' not in output:
        return compress_generic(output)

    lines = output.splitlines()
    frames: list[str] = []
    error_line = ''
    file_re = re.compile(r'File "(.+?)", line (\d+), in (\S+)')

    for line in lines:
        m = file_re.search(line)
        if m:
            path, lineno, func = m.groups()
            # Use basename only
            basename = path.replace('\\', '/').rsplit('/', 1)[-1]
            frames.append(f'{basename}:{lineno}({func})')
        elif re.match(r'^\w+(\.\w+)*Error', line) or re.match(r'^\w+(\.\w+)*Warning', line):
            error_line = line.strip()

    if not frames and not error_line:
        return output.strip()

    # Build compact form
    chain = ' -> '.join(frames) if frames else ''
    result_lines = []
    if chain:
        result_lines.append(f'Traceback: {chain}')
    if error_line:
        result_lines.append(error_line)

    compressed = '\n'.join(result_lines)
    # Only return compressed if actually shorter
    if compressed and len(compressed) < len(output):
        return compressed
    return output.strip()


def _git_subcommand(args: Sequence[str]) -> str:
    """Extract the git subcommand from argv (skips flags like -C, --no-pager)."""
    skip_next = False
    for arg in args:
        if skip_next:
            skip_next = False
            continue
        if arg in ('-C', '--work-tree', '--git-dir', '-c', '--config-env'):
            skip_next = True
            continue
        if not arg.startswith('-'):
            return arg
    return ''


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def main(argv: list[str] | None = None) -> None:
    """
    Entry point for `aibrain-compress` CLI.

    Modes:
        aibrain-compress init                    Install shell hook (on by default after aibrain setup)
        aibrain-compress disable                 Remove shell hook (opt out)
        aibrain-compress uninstall               Alias for disable
        aibrain-compress config                  Interactive checklist menu for compression settings
        aibrain-compress -- <cmd> [args...]      Read stdin, compress, print
        aibrain-compress <cmd> [args...]         Run command, compress, print
    """
    from aibrain.tools.compress.hook import install_hook, uninstall_hook

    args = argv if argv is not None else sys.argv[1:]

    if not args:
        print(
            'aibrain-compress v{version} -- AIBrain token compression\n'
            '\n'
            'Usage:\n'
            '  aibrain-compress init               Install shell hook\n'
            '  aibrain-compress disable            Disable / remove shell hook\n'
            '  aibrain-compress uninstall          Alias for disable\n'
            '  aibrain-compress config             Interactive compression settings menu\n'
            '  aibrain-compress -- git status      Compress stdin from git status\n'
            '  aibrain-compress git status         Run + compress git status\n'
            '\n'
            'Environment:\n'
            '  AIBRAIN_COMPRESS_DIFF_CONTEXT=N          Context lines in git diff (default: 0)\n'
            '  AIBRAIN_COMPRESS_DISABLE                 Disable ALL compression\n'
            '  AIBRAIN_COMPRESS_DISABLE_GIT             Disable git compression\n'
            '  AIBRAIN_COMPRESS_DISABLE_TEST            Disable test-runner compression\n'
            '  AIBRAIN_COMPRESS_DISABLE_BUILD           Disable build-tool compression\n'
            '  AIBRAIN_COMPRESS_DISABLE_DOCKER          Disable docker compression\n'
            '  AIBRAIN_COMPRESS_DISABLE_PIP             Disable pip compression\n'
            '  AIBRAIN_COMPRESS_DISABLE_ENV             Disable env/printenv compression\n'
            '  AIBRAIN_COMPRESS_DISABLE_JSON            Disable JSON cat compression\n'
            '  AIBRAIN_COMPRESS_DISABLE_TRACEBACK       Disable Python traceback compression\n'
            '  AIBRAIN_COMPRESS_LEARN_LOG=/path/file    Log raw output before compression\n'.format(
                version=__version__
            ),
            end='',
        )
        return

    if args[0] == 'init':
        print(install_hook())
        return

    if args[0] in ('disable', 'uninstall'):
        print(uninstall_hook())
        return

    if args[0] == 'config':
        _handle_config_subcommand(args[1:])
        return

    # Strip leading '--' separator (pipe mode: stdin contains the raw output)
    pipe_mode = args[0] == '--'
    if pipe_mode:
        args = args[1:]

    if not args:
        # Nothing to do -- pass through
        sys.stdout.write(sys.stdin.read())
        return

    if pipe_mode:
        # Read raw output from stdin, command info from args
        raw = sys.stdin.read()
        result = compress(args, raw)
        sys.stdout.write(result)
        if result and not result.endswith('\n'):
            sys.stdout.write('\n')
    else:
        # Wrap mode: run the command ourselves
        try:
            proc = subprocess.run(
                args,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
            )
            raw = proc.stdout or ''
            result = compress(args, raw)
            sys.stdout.write(result)
            if result and not result.endswith('\n'):
                sys.stdout.write('\n')
            sys.exit(proc.returncode)
        except FileNotFoundError:
            print(f'aibrain-compress: command not found: {args[0]}', file=sys.stderr)
            sys.exit(127)


def _handle_config_subcommand(args: list[str]) -> None:
    """Handle `aibrain-compress config` — launches interactive checklist menu."""
    from aibrain.tools.compress.config import interactive_menu
    interactive_menu()


if __name__ == '__main__':
    main()
