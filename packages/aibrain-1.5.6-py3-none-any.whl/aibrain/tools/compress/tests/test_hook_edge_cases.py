"""
Test Matrix 1: Shell hook behaviour under non-standard conditions.

Shadow Board flagged these scenarios as untested:
  1. Interactive commands (git add -p, git rebase -i)
  2. Binary output (commands writing binary to stdout)
  3. TTY-dependent commands (docker build progress, npm spinners)
  4. CI / non-interactive contexts (piped output, no tty)
  5. Commands that flush output in chunks

The hook design (hook.py) captures ALL stdout+stderr into a shell variable,
then pipes it through aibrain-compress.  This means:

  - Interactive commands: BROKEN by design. `command git add -p 2>&1` captures
    the interactive prompts but stdin is still connected, so the user cannot
    see prompts before typing.  This is a known limitation documented below.
  - Binary output: The shell variable assignment (`_out=$(...)`) and printf
    will mangle NUL bytes.  The compress() Python function will receive
    garbled text.  However, it must NOT crash -- it should fall through to
    generic or return raw.
  - TTY-dependent output: Progress bars, spinners, and \r-based updates will
    be captured as flat text (no real tty).  The compress pipeline should
    handle this gracefully.
  - CI / piped contexts: The hook wraps `command git`, so in CI where output
    is already piped, it should work identically -- just no tty escape codes.
  - Chunked output: Since the hook captures everything into a variable before
    piping, chunked flushing is irrelevant -- all output is buffered first.

KEY INVARIANT: The hook must NEVER change the exit code of the wrapped
command.  Every test below verifies this.
"""
from __future__ import annotations

import os
import subprocess
import sys
import textwrap

import pytest

from aibrain.tools.compress import compress
from aibrain.tools.compress.hook import (
    _BASH_HOOK,
    _PS_HOOK,
    install_hook,
    uninstall_hook,
)


# ---------------------------------------------------------------------------
# 1. Interactive commands (git add -p, git rebase -i)
# ---------------------------------------------------------------------------

class TestInteractiveCommands:
    """
    The bash hook does: _out=$(command git "$@" 2>&1)

    This captures stdout+stderr into a variable.  For interactive commands
    (add -p, rebase -i), the prompts are captured but the user cannot see
    them before the command finishes.  This effectively breaks interactive
    git commands.

    EXPECTED BEHAVIOUR: The hook should ideally detect interactive subcommands
    and bypass compression, passing through directly.  Currently it does NOT
    do this -- these tests document the current state and verify that at
    minimum, compress() does not crash on interactive-style output.
    """

    def test_compress_handles_add_p_output(self):
        """git add -p output contains prompts and diff hunks.
        compress() must not crash on this mixed content."""
        raw = textwrap.dedent("""\
            diff --git a/file.py b/file.py
            index abc1234..def5678 100644
            --- a/file.py
            +++ b/file.py
            @@ -1,5 +1,6 @@
             import os
            +import sys

             def main():
                 pass
            (1/1) Stage this hunk [y,n,q,a,d,e,?]?
        """)
        result = compress(['git', 'add', '-p'], raw)
        assert isinstance(result, str)
        assert len(result) > 0
        # Must not crash -- that is the key assertion

    def test_compress_handles_rebase_i_output(self):
        """git rebase -i output after editor closes."""
        raw = textwrap.dedent("""\
            Successfully rebased and updated refs/heads/feature.
        """)
        result = compress(['git', 'rebase', '-i', 'HEAD~3'], raw)
        assert isinstance(result, str)

    def test_bash_hook_does_not_bypass_interactive(self):
        """Document that the bash hook does NOT currently bypass interactive cmds.

        The hook function unconditionally captures output.  There is no check
        for subcommands like add -p, rebase -i, etc.  This test verifies
        that the hook template lacks an interactive bypass.
        """
        # The hook should ideally contain something like:
        #   case "$1" in add) ... ;; rebase) ... ;; esac
        # Currently it does not:
        assert 'add -p' not in _BASH_HOOK, (
            'Hook gained interactive bypass -- update this test'
        )
        assert 'rebase -i' not in _BASH_HOOK, (
            'Hook gained interactive bypass -- update this test'
        )

    def test_compress_preserves_exit_code_on_interactive_output(self):
        """Even if compress garbles interactive output, exit code must survive.
        We test the Python-level compress() -- it must not raise."""
        # Simulate a failed interactive command (user aborted)
        raw = 'error: patch failed\n'
        # compress must return a string, never raise
        result = compress(['git', 'add', '-p'], raw)
        assert isinstance(result, str)


# ---------------------------------------------------------------------------
# 2. Binary output
# ---------------------------------------------------------------------------

class TestBinaryOutput:
    """
    The shell hook captures output via $(...) which strips NUL bytes.
    The Python compress() receives text, so true binary is already mangled
    by the time it arrives.  These tests verify compress() handles garbled
    binary-like content without crashing.
    """

    def test_compress_handles_binary_garbage(self):
        """Binary content that survived shell capture (NULs stripped)."""
        # Simulate what $(command ...) would produce from binary output:
        # NUL bytes stripped, random high-byte chars as mojibake
        raw = '\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR' + '\xff' * 50
        result = compress(['git', 'show', 'HEAD:image.png'], raw)
        assert isinstance(result, str)

    def test_compress_handles_mixed_text_binary(self):
        """Output that starts as text but contains binary segments."""
        raw = 'commit abc123\nAuthor: test\n\n' + '\x00\xff\xfe' * 20
        result = compress(['git', 'show', '--format=raw'], raw)
        assert isinstance(result, str)

    def test_compress_never_raises_on_arbitrary_bytes(self):
        """Fuzz-like test: random byte sequences decoded as latin-1."""
        import random
        random.seed(42)
        raw = ''.join(chr(random.randint(0, 255)) for _ in range(500))
        # Must not raise
        result = compress(['some-tool'], raw)
        assert isinstance(result, str)

    def test_compress_returns_something_on_binary(self):
        """Even on binary, compress must return non-None string."""
        raw = '\x00' * 100
        result = compress(['cat', 'binary.dat'], raw)
        assert result is not None
        assert isinstance(result, str)


# ---------------------------------------------------------------------------
# 3. TTY-dependent commands (progress bars, spinners, \r overwrite)
# ---------------------------------------------------------------------------

class TestTTYDependentOutput:
    """
    TTY-dependent commands use \\r (carriage return) to overwrite lines,
    ANSI escape codes for colors/cursor movement, and progress bars.
    When captured via $(...), these become flat text with embedded control
    characters.  compress() must handle this gracefully.
    """

    def test_docker_build_progress_bars(self):
        """Docker build output with progress indicators."""
        raw = textwrap.dedent("""\
            Step 1/5 : FROM python:3.11-slim
             ---> abc123def456
            Step 2/5 : COPY . /app
            \r[+] Building 2.1s (5/5)
            \r[+] Building 2.3s (5/5) FINISHED
            Successfully built abc123def456
            Successfully tagged myapp:latest
        """)
        result = compress(['docker', 'build', '.'], raw)
        assert isinstance(result, str)
        # Should not crash on \r characters
        assert len(result) > 0

    def test_npm_install_spinner_output(self):
        """npm install with spinner/progress characters captured flat."""
        raw = textwrap.dedent("""\
            \r\x1b[K\r\x1b[1Gnpm warn deprecated glob@7.2.3
            \r\x1b[K\r\x1b[1G
            added 412 packages in 8s
            148 packages are looking for funding
            found 0 vulnerabilities
        """)
        result = compress(['npm', 'install'], raw)
        assert isinstance(result, str)
        # The useful content should survive
        assert 'added' in result.lower() or '412' in result

    def test_curl_progress_bar(self):
        """curl with progress bar captured as text."""
        raw = textwrap.dedent("""\
              % Total    % Received % Xferd  Speed   Time
            \r  0     0    0     0    0     0      0 --:--:--
            \r100  1234  100  1234    0     0   5678      0 --:--:--
            {"status": "ok"}
        """)
        result = compress(['curl', '-o', '-', 'http://example.com'], raw)
        assert isinstance(result, str)

    def test_ansi_escape_codes_stripped_or_passed(self):
        """ANSI color codes should not crash compress."""
        raw = '\x1b[32m+ added line\x1b[0m\n\x1b[31m- removed line\x1b[0m\n'
        result = compress(['git', 'diff'], raw)
        assert isinstance(result, str)
        assert len(result) > 0

    def test_carriage_return_overwrite_lines(self):
        """Lines with \\r overwrites (progress indicator pattern)."""
        lines = []
        for pct in range(0, 101, 10):
            lines.append(f'\rDownloading: {pct}%')
        raw = ''.join(lines) + '\nDownload complete.\n'
        result = compress(['wget', 'http://example.com/file'], raw)
        assert isinstance(result, str)


# ---------------------------------------------------------------------------
# 4. CI / non-interactive contexts (piped, no tty)
# ---------------------------------------------------------------------------

class TestCINonInteractive:
    """
    In CI environments, stdout is not a tty.  The hook captures output
    identically (shell variable capture doesn't depend on tty).  These tests
    verify compress() works correctly on output that lacks tty formatting.
    """

    def test_git_status_no_color(self):
        """CI git output has no ANSI codes -- should compress normally."""
        raw = textwrap.dedent("""\
            On branch main
            Changes not staged for commit:
              (use "git add <file>..." to update what will be committed)
            \tmodified:   src/app.py
            no changes added to commit
        """)
        result = compress(['git', 'status'], raw)
        assert 'src/app.py' in result
        assert '(use "git add' not in result

    def test_pytest_ci_output(self):
        """pytest in CI -- no color, no progress dots animation."""
        raw = textwrap.dedent("""\
            ============================= test session starts ==============================
            platform linux -- Python 3.11.0
            collected 5 items

            tests/test_api.py .....

            ============================== 5 passed in 1.23s ===============================
        """)
        result = compress(['pytest'], raw)
        assert isinstance(result, str)
        assert '5 passed' in result or 'passed' in result.lower()

    def test_empty_output_in_ci(self):
        """Commands that produce no output (common in CI scripts)."""
        result = compress(['git', 'checkout', 'main'], '')
        assert result == ''

    def test_piped_multiline_output(self):
        """Large piped output that would normally be paged."""
        # 200 lines of log
        lines = [f'abc{i:04x} Fix issue #{i}' for i in range(200)]
        raw = '\n'.join(lines)
        result = compress(['git', 'log', '--oneline', '-200'], raw)
        assert isinstance(result, str)
        # Should be compressed (generic dedup or log filter)
        assert len(result) > 0


# ---------------------------------------------------------------------------
# 5. Commands that flush in chunks
# ---------------------------------------------------------------------------

class TestChunkedOutput:
    """
    The bash hook captures ALL output into a variable before piping to
    aibrain-compress.  This means chunked flushing is irrelevant at the
    shell level -- everything is buffered.

    However, in wrap mode (aibrain-compress <cmd>), subprocess.run() also
    buffers everything via PIPE.  These tests verify the Python wrap mode
    handles large/chunked output.
    """

    def test_large_diff_output(self):
        """Large diff output (simulating a big changeset)."""
        hunks = []
        for i in range(50):
            hunks.append(textwrap.dedent(f"""\
                diff --git a/file{i}.py b/file{i}.py
                --- a/file{i}.py
                +++ b/file{i}.py
                @@ -1,3 +1,4 @@
                 existing line
                +new line {i}
                 another line
            """))
        raw = '\n'.join(hunks)
        result = compress(['git', 'diff'], raw)
        assert isinstance(result, str)
        # Should compress significantly (many similar hunks)
        assert len(result) < len(raw)

    def test_large_test_output(self):
        """Large test suite output with many pass lines."""
        lines = ['=' * 60 + ' test session starts ' + '=' * 20]
        lines.append('collected 500 items')
        for i in range(500):
            lines.append(f'tests/test_module{i // 10}.py::test_case_{i} PASSED')
        lines.append('=' * 60 + f' 500 passed in 45.2s ' + '=' * 20)
        raw = '\n'.join(lines)
        result = compress(['pytest'], raw)
        assert isinstance(result, str)
        # Should be massively compressed (all passed)
        assert len(result) < len(raw) * 0.3

    def test_streaming_log_output(self):
        """Simulates tailing a log file -- many repetitive lines.

        Note: docker logs goes through compress_docker_logs which deduplicates
        identical lines.  When timestamps differ (like here), each line is
        unique so no dedup occurs.  The key assertion is that compress does
        not crash and returns a valid string.  Actual compression depends on
        whether the generic filter can find patterns."""
        lines = []
        for i in range(100):
            lines.append(f'2026-04-09T12:00:{i:02d}Z INFO  Request processed in 42ms')
        raw = '\n'.join(lines)
        result = compress(['docker', 'logs', 'mycontainer'], raw)
        assert isinstance(result, str)
        # Must return valid output (may or may not compress -- timestamps differ)
        assert len(result) <= len(raw)


# ---------------------------------------------------------------------------
# 6. Exit code preservation (critical invariant)
# ---------------------------------------------------------------------------

class TestExitCodePreservation:
    """
    The hook's #1 job after compression is preserving the original exit code.
    These tests verify the bash hook template correctly captures and returns
    the exit code.
    """

    def test_bash_hook_captures_exit_code(self):
        """Bash hook must assign $? to _ec and return it."""
        assert '_ec=$?' in _BASH_HOOK
        assert 'return $_ec' in _BASH_HOOK

    def test_bash_hook_exit_code_before_pipe(self):
        """Exit code must be captured BEFORE the pipe to aibrain-compress.

        If _ec=$? came after the pipe, it would reflect aibrain-compress's
        exit code instead of git's."""
        lines = _BASH_HOOK.splitlines()
        ec_line = next(i for i, l in enumerate(lines) if '_ec=$?' in l)
        pipe_line = next(i for i, l in enumerate(lines) if '| aibrain-compress' in l)
        assert ec_line < pipe_line, (
            'Exit code captured AFTER pipe -- would reflect compress exit code, not git'
        )

    def test_ps_hook_captures_exit_code(self):
        """PowerShell hook must capture $LASTEXITCODE before piping."""
        assert '$LASTEXITCODE' in _PS_HOOK
        assert 'exit $ec' in _PS_HOOK

    def test_ps_hook_exit_code_before_pipe(self):
        """PowerShell exit code captured before pipe."""
        lines = _PS_HOOK.splitlines()
        ec_line = next(i for i, l in enumerate(lines) if '$ec = $LASTEXITCODE' in l)
        pipe_line = next(i for i, l in enumerate(lines) if '| & aibrain-compress' in l)
        assert ec_line < pipe_line

    def test_wrap_mode_preserves_exit_code(self):
        """CLI wrap mode (main()) should sys.exit with the command's exit code.

        We test this by invoking main() directly with a command that exits 42."""
        from aibrain.tools.compress import main
        with pytest.raises(SystemExit) as exc_info:
            main([sys.executable, '-c', 'import sys; print("fail"); sys.exit(42)'])
        assert exc_info.value.code == 42

    def test_wrap_mode_preserves_zero_exit(self):
        """Successful command should exit 0."""
        from aibrain.tools.compress import main
        with pytest.raises(SystemExit) as exc_info:
            main([sys.executable, '-c', 'print("ok")'])
        assert exc_info.value.code == 0


# ---------------------------------------------------------------------------
# 7. Hook install/uninstall edge cases
# ---------------------------------------------------------------------------

class TestHookInstallEdgeCases:
    """Edge cases in hook installation that could cause shell breakage."""

    def test_install_into_empty_file(self, tmp_path):
        """Installing into a brand new (empty) profile."""
        profile = tmp_path / '.bashrc'
        profile.write_text('', encoding='utf-8')
        msg = install_hook(profile_path=profile)
        assert 'installed' in msg.lower()
        content = profile.read_text(encoding='utf-8')
        assert 'aibrain-compress' in content

    def test_install_preserves_existing_content(self, tmp_path):
        """Existing shell config must not be damaged."""
        profile = tmp_path / '.bashrc'
        existing = 'export PATH="/usr/local/bin:$PATH"\nalias ll="ls -la"\n'
        profile.write_text(existing, encoding='utf-8')
        install_hook(profile_path=profile)
        content = profile.read_text(encoding='utf-8')
        assert 'export PATH="/usr/local/bin:$PATH"' in content
        assert 'alias ll="ls -la"' in content
        assert 'aibrain-compress' in content

    def test_uninstall_leaves_clean_file(self, tmp_path):
        """After uninstall, no aibrain-compress artifacts remain."""
        profile = tmp_path / '.bashrc'
        existing = 'export FOO=bar\n'
        profile.write_text(existing, encoding='utf-8')
        install_hook(profile_path=profile)
        uninstall_hook(profile_path=profile)
        content = profile.read_text(encoding='utf-8')
        assert 'aibrain-compress' not in content
        assert 'FOO=bar' in content

    def test_install_on_nonexistent_profile(self, tmp_path):
        """Profile file does not exist yet -- should create it."""
        profile = tmp_path / 'subdir' / '.bashrc'
        msg = install_hook(profile_path=profile)
        assert 'installed' in msg.lower()
        assert profile.exists()

    def test_backup_created_on_install(self, tmp_path):
        """Installing must create a backup of the existing profile."""
        profile = tmp_path / '.bashrc'
        profile.write_text('# my config\n', encoding='utf-8')

        from aibrain.tools.compress.hook import _get_backup_dir
        import unittest.mock as mock

        backup_dir = tmp_path / 'backups'
        with mock.patch('aibrain.tools.compress.hook._get_backup_dir', return_value=backup_dir):
            install_hook(profile_path=profile)

        backups = list(backup_dir.glob('.bashrc_*'))
        assert len(backups) >= 1, 'No backup created during install'


# ---------------------------------------------------------------------------
# 8. Compress function resilience (fail-silent guarantee)
# ---------------------------------------------------------------------------

class TestCompressResilience:
    """
    compress() must NEVER raise.  The except clause at line 338 of __init__.py
    catches all exceptions and returns raw output.  These tests stress that.
    """

    def test_none_in_command_list(self):
        """Command list with None element -- should fall through to generic filter.

        Previously bugged (AttributeError on command[0].lower()), now guarded.
        """
        result = compress([None, 'status'], 'some output')
        assert isinstance(result, str)

    def test_empty_command_list(self):
        """Empty command list should use generic filter."""
        result = compress([], 'some output here')
        assert isinstance(result, str)

    def test_extremely_long_output(self):
        """1MB of output should not OOM or hang."""
        raw = 'x' * (1024 * 1024)
        result = compress(['some-tool'], raw)
        assert isinstance(result, str)

    def test_unicode_output(self):
        """Non-ASCII output must not crash."""
        raw = 'Branch: feature/\u65e5\u672c\u8a9e\n\u2714 All tests passed\n'
        result = compress(['git', 'status'], raw)
        assert isinstance(result, str)

    def test_only_newlines(self):
        """Output that is only newlines."""
        result = compress(['git', 'status'], '\n\n\n\n')
        assert isinstance(result, str)
