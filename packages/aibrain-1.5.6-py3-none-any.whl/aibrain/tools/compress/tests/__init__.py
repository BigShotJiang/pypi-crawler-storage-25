"""Tests for aibrain.tools.compress."""
