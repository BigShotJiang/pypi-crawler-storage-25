"""
builtin.py — 15 starter tools for AIBrain agents.

Each tool is a callable class with name, description, and __call__.
All tools use only stdlib (no heavy deps). Errors are caught and returned
as string messages rather than raised.
"""

import ast
import csv
import fnmatch
import io
import ipaddress
import json
import logging
import os
import re
import shlex
import socket
import subprocess
import sys
import textwrap
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Optional
from urllib.parse import urlparse

_log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Security helpers
# ---------------------------------------------------------------------------

# Blocked path patterns for ReadFileTool / WriteFileTool
_BLOCKED_PATH_PATTERNS = [
    "/etc/shadow", "/etc/passwd",
    "/.ssh/", "/.aws/", "/.gnupg/",
    ".env", ".decker_env",
    "id_rsa", "credentials",
]


def _is_blocked_path(resolved_path: str) -> bool:
    """Check if a resolved path matches any blocked pattern."""
    norm = resolved_path.replace("\\", "/")
    for pattern in _BLOCKED_PATH_PATTERNS:
        if pattern in norm:
            return True
    return False


def _is_ssrf_target(url_str: str) -> bool:
    """Return True if the URL targets a private/internal IP or blocked hostname.

    Uses the validated SSRF check from backend/security.py when available,
    falling back to a strict inline check that blocks on any uncertainty.
    """
    try:
        # Prefer the full validate_url() from backend security module
        _backend = os.path.join(os.path.dirname(os.path.dirname(__file__)), "backend")
        if _backend not in sys.path:
            sys.path.insert(0, _backend)
        from security import validate_url
        is_safe, _reason = validate_url(url_str)
        return not is_safe
    except ImportError:
        pass

    # Inline fallback — strict: block on any uncertainty
    _ALLOWED_SCHEMES = {"http", "https"}
    _BLOCKED_HOSTS = {"localhost", "metadata.google.internal", "169.254.169.254", "0.0.0.0"}
    try:
        parsed = urlparse(url_str)
        # Block non-http(s) schemes (file://, gopher://, ftp://, etc.)
        if (parsed.scheme or "").lower() not in _ALLOWED_SCHEMES:
            return True
        hostname = parsed.hostname or ""
        if not hostname or hostname in _BLOCKED_HOSTS:
            return True
        # Resolve hostname to IP and check if private
        resolved = socket.getaddrinfo(hostname, None, socket.AF_UNSPEC, socket.SOCK_STREAM)
        for family, _, _, _, sockaddr in resolved:
            ip = ipaddress.ip_address(sockaddr[0])
            if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved:
                return True
    except Exception:
        # If we can't resolve, BLOCK (fail closed — not fail open)
        return True
    return False


# ---------------------------------------------------------------------------
# Base
# ---------------------------------------------------------------------------

class BaseTool:
    """Base class for all AIBrain tools."""
    name: str = ""
    description: str = ""

    def __call__(self, **kwargs) -> str:
        raise NotImplementedError


# ---------------------------------------------------------------------------
# 1. ReadFileTool
# ---------------------------------------------------------------------------

class ReadFileTool(BaseTool):
    """Read a file's contents and return as string."""
    name = "read_file"
    description = "Read a file's contents. Args: path (str), encoding (str, default utf-8), limit (int, max lines)."

    def __call__(self, *, path: str, encoding: str = "utf-8", limit: int = 0, **kw) -> str:
        if not path:
            return "Error: path is required"
        p = Path(path).resolve()
        resolved = str(p)
        if _is_blocked_path(resolved):
            return f"Error: access to this path is blocked for security reasons"
        if not p.exists():
            return f"Error: file not found: {path}"
        if not p.is_file():
            return f"Error: not a file: {path}"
        try:
            text = p.read_text(encoding=encoding, errors="replace")
            if limit > 0:
                lines = text.splitlines(keepends=True)
                text = "".join(lines[:limit])
            return text
        except Exception as e:
            return f"Error reading file: {type(e).__name__}"


# ---------------------------------------------------------------------------
# 2. WriteFileTool
# ---------------------------------------------------------------------------

class WriteFileTool(BaseTool):
    """Write content to a file, creating parent directories as needed."""
    name = "write_file"
    description = "Write content to a file. Args: path (str), content (str), encoding (str, default utf-8), append (bool)."

    def __call__(self, *, path: str, content: str, encoding: str = "utf-8",
                 append: bool = False, **kw) -> str:
        if not path:
            return "Error: path is required"
        if content is None:
            return "Error: content is required"
        p = Path(path).resolve()
        resolved = str(p)
        if _is_blocked_path(resolved):
            return f"Error: access to this path is blocked for security reasons"
        try:
            p.parent.mkdir(parents=True, exist_ok=True)
            mode = "a" if append else "w"
            p.write_text(content, encoding=encoding) if not append else \
                p.open(mode, encoding=encoding).write(content)
            return f"Written {len(content)} chars to {path}"
        except Exception as e:
            return f"Error writing file: {type(e).__name__}"


# ---------------------------------------------------------------------------
# 3. ListDirectoryTool
# ---------------------------------------------------------------------------

class ListDirectoryTool(BaseTool):
    """List files and directories in a given path."""
    name = "list_directory"
    description = "List files in a directory. Args: path (str), recursive (bool), pattern (str glob filter)."

    def __call__(self, *, path: str = ".", recursive: bool = False,
                 pattern: str = "*", **kw) -> str:
        p = Path(path)
        if not p.exists():
            return f"Error: directory not found: {path}"
        if not p.is_dir():
            return f"Error: not a directory: {path}"
        try:
            if recursive:
                entries = sorted(str(e.relative_to(p)) for e in p.rglob(pattern))
            else:
                entries = sorted(str(e.relative_to(p)) for e in p.glob(pattern))
            if not entries:
                return f"No entries matching '{pattern}' in {path}"
            # Cap at 500 entries to avoid huge output
            if len(entries) > 500:
                entries = entries[:500]
                entries.append(f"... (truncated, {len(entries)} total)")
            return "\n".join(entries)
        except Exception as e:
            return f"Error listing {path}: {e}"


# ---------------------------------------------------------------------------
# 4. SearchFilesTool
# ---------------------------------------------------------------------------

class SearchFilesTool(BaseTool):
    """Search for files by glob pattern across a directory tree."""
    name = "search_files"
    description = "Search for files by glob pattern. Args: pattern (str), path (str, default '.'), max_results (int)."

    def __call__(self, *, pattern: str, path: str = ".", max_results: int = 100, **kw) -> str:
        if not pattern:
            return "Error: pattern is required"
        p = Path(path)
        if not p.exists():
            return f"Error: path not found: {path}"
        try:
            results = []
            for match in p.rglob(pattern):
                results.append(str(match))
                if len(results) >= max_results:
                    break
            if not results:
                return f"No files matching '{pattern}' in {path}"
            return "\n".join(results)
        except Exception as e:
            return f"Error searching: {e}"


# ---------------------------------------------------------------------------
# 5. WebSearchTool
# ---------------------------------------------------------------------------

class WebSearchTool(BaseTool):
    """Web search — tries MCP web_search, falls back to simple URL fetch."""
    name = "web_search"
    description = "Search the web. Args: query (str). Returns search results or error."

    def __call__(self, *, query: str, **kw) -> str:
        if not query:
            return "Error: query is required"

        # Try stdlib URL fetch as a search approximation
        # (Real MCP integration would call web_search MCP server)
        try:
            import urllib.request
            import urllib.parse
            url = f"https://html.duckduckgo.com/html/?q={urllib.parse.quote_plus(query)}"
            if _is_ssrf_target(url):
                return "Error: request to private/internal network is blocked"
            req = urllib.request.Request(url, headers={"User-Agent": "AIBrain/1.0"})
            with urllib.request.urlopen(req, timeout=10) as resp:
                html = resp.read().decode("utf-8", errors="replace")
            # Extract text snippets from result links
            results = []
            for match in re.finditer(r'class="result__snippet">(.*?)</a>', html, re.DOTALL):
                text = re.sub(r"<[^>]+>", "", match.group(1)).strip()
                if text:
                    results.append(text)
            if results:
                return "\n\n".join(results[:5])
            return f"Search completed but no snippets extracted for: {query}"
        except Exception as e:
            return f"Web search error: {e}"


# ---------------------------------------------------------------------------
# 6. WebFetchTool
# ---------------------------------------------------------------------------

class WebFetchTool(BaseTool):
    """Fetch a URL and return its content."""
    name = "web_fetch"
    description = "Fetch a URL. Args: url (str), max_length (int, default 50000). Returns page content."

    def __call__(self, *, url: str, max_length: int = 50000, **kw) -> str:
        if not url:
            return "Error: url is required"
        if _is_ssrf_target(url):
            return "Error: request to private/internal network is blocked"
        try:
            import urllib.request
            req = urllib.request.Request(url, headers={"User-Agent": "AIBrain/1.0"})
            with urllib.request.urlopen(req, timeout=15) as resp:
                content_type = resp.headers.get("Content-Type", "")
                data = resp.read(max_length).decode("utf-8", errors="replace")
            # Strip HTML tags for readability if HTML
            if "html" in content_type.lower():
                data = re.sub(r"<script[^>]*>.*?</script>", "", data, flags=re.DOTALL)
                data = re.sub(r"<style[^>]*>.*?</style>", "", data, flags=re.DOTALL)
                data = re.sub(r"<[^>]+>", " ", data)
                data = re.sub(r"\s+", " ", data).strip()
            return data[:max_length]
        except Exception as e:
            return f"Fetch error: {e}"


# ---------------------------------------------------------------------------
# 7. ShellTool
# ---------------------------------------------------------------------------

# Allowlist of safe command prefixes (no shell=True, no arbitrary commands)
_ALLOWED_COMMANDS = frozenset({
    "ls", "dir", "cat", "head", "tail", "wc", "grep", "find", "echo",
    "pwd", "whoami", "date", "uname", "pip", "python", "git",
})

# Git subcommands that are allowed
_ALLOWED_GIT_SUBCOMMANDS = frozenset({"status", "log", "diff"})


def _is_command_allowed(args: list[str]) -> tuple[bool, str]:
    """Check if a parsed command is in the allowlist. Returns (allowed, reason)."""
    if not args:
        return False, "empty command"
    base = os.path.basename(args[0]).lower()
    # Strip .exe suffix on Windows
    if base.endswith(".exe"):
        base = base[:-4]
    if base not in _ALLOWED_COMMANDS:
        return False, f"command '{base}' is not in the allowlist. Allowed: {', '.join(sorted(_ALLOWED_COMMANDS))}"
    # Special restriction for git: only allow safe subcommands
    if base == "git":
        if len(args) < 2:
            return False, "git requires a subcommand"
        sub = args[1].lower()
        if sub not in _ALLOWED_GIT_SUBCOMMANDS:
            return False, f"git subcommand '{sub}' is not allowed. Allowed: {', '.join(sorted(_ALLOWED_GIT_SUBCOMMANDS))}"
    # Special restriction for python: only allow --version
    if base == "python" and args[1:] != ["--version"]:
        return False, "only 'python --version' is allowed"
    return True, ""


class ShellTool(BaseTool):
    """Execute a shell command with allowlist-based safety checks."""
    name = "shell"
    description = "Execute a shell command. Args: command (str), timeout (int, default 30), cwd (str)."

    def __call__(self, *, command: str, timeout: int = 30, cwd: str = None, **kw) -> str:
        if not command:
            return "Error: command is required"
        # Parse command safely — no shell interpretation
        try:
            args = shlex.split(command)
        except ValueError as e:
            return f"Error: could not parse command: {e}"
        if not args:
            return "Error: empty command after parsing"

        # Allowlist check
        allowed, reason = _is_command_allowed(args)
        if not allowed:
            _log.warning("ShellTool rejected command: %s — %s", command, reason)
            return f"Error: {reason}"

        try:
            result = subprocess.run(
                args, shell=False, capture_output=True, text=True,
                timeout=timeout, cwd=cwd,
            )
            output = result.stdout
            if result.stderr:
                output += f"\nSTDERR: {result.stderr}"
            if result.returncode != 0:
                output += f"\n(exit code: {result.returncode})"
            return output.strip() or "(no output)"
        except subprocess.TimeoutExpired:
            return f"Error: command timed out after {timeout}s"
        except Exception as e:
            return f"Error executing command: {e}"


# ---------------------------------------------------------------------------
# 8. PythonREPLTool
# ---------------------------------------------------------------------------

# Safe builtins whitelist for PythonREPLTool
_SAFE_BUILTINS = {
    "print": print, "len": len, "range": range, "int": int, "float": float,
    "str": str, "bool": bool, "list": list, "dict": dict, "tuple": tuple,
    "set": set, "type": type, "isinstance": isinstance, "abs": abs,
    "round": round, "min": min, "max": max, "sum": sum, "sorted": sorted,
    "enumerate": enumerate, "zip": zip, "map": map, "filter": filter,
    "any": any, "all": all, "repr": repr, "chr": chr, "ord": ord,
    "hex": hex, "bin": bin, "oct": oct,
    "True": True, "False": False, "None": None,
}


_BLOCKED_IMPORTS = frozenset({
    "os", "sys", "subprocess", "shutil", "pathlib", "socket",
    "ctypes", "multiprocessing", "threading", "importlib",
    "builtins", "gc", "inspect", "signal", "pty", "tty",
    "paramiko", "ftplib", "smtplib", "http", "urllib",
})


def _check_safe_ast(code: str) -> str | None:
    """AST pre-scan: return an error string if dangerous constructs are found, else None.

    Defense-in-depth layer before subprocess execution. Catches import statements
    and __import__ calls that should not run even in a sandboxed child process.
    """
    import ast as _ast
    try:
        tree = _ast.parse(code)
    except SyntaxError as e:
        return f"Error: SyntaxError — {e}"

    for node in _ast.walk(tree):
        # import X / import X as Y
        if isinstance(node, _ast.Import):
            for alias in node.names:
                top = alias.name.split(".")[0]
                if top in _BLOCKED_IMPORTS:
                    return f"Error: import '{alias.name}' is not allowed in the sandbox"
        # from X import Y
        elif isinstance(node, _ast.ImportFrom):
            top = (node.module or "").split(".")[0]
            if top in _BLOCKED_IMPORTS:
                return f"Error: import from '{node.module}' is not allowed in the sandbox"
        # __import__(...)
        elif isinstance(node, _ast.Call):
            func = node.func
            if isinstance(func, _ast.Name) and func.id == "__import__":
                return "Error: __import__ is not allowed in the sandbox"

    return None


class PythonREPLTool(BaseTool):
    """Execute Python code in a subprocess-isolated environment."""
    name = "python_repl"
    description = "Execute Python code. Args: code (str). Returns stdout + return value."

    def __call__(self, *, code: str, **kw) -> str:
        if not code:
            return "Error: code is required"

        # SECURITY layer 1: AST pre-scan blocks dangerous imports before exec
        ast_error = _check_safe_ast(code)
        if ast_error:
            return ast_error

        # SECURITY layer 2: subprocess isolation prevents sandbox escapes
        # via ctypes, __class__.__bases__, gc tricks that bypass AST checks.
        # Also auto-capture the `result` variable for REPL ergonomics.
        wrapped = code + "\ntry:\n    print(result)\nexcept NameError:\n    pass"
        try:
            proc = subprocess.run(
                [sys.executable, "-c", wrapped],
                capture_output=True, text=True, timeout=10,
            )
            output = proc.stdout
            if proc.stderr:
                output += f"\nSTDERR: {proc.stderr}"
            if proc.returncode != 0 and not output.strip():
                output = f"Error (exit {proc.returncode}): {proc.stderr.strip()}"
            return output.strip() or "(executed, no output)"
        except subprocess.TimeoutExpired:
            return "Error: code execution timed out (10s limit)"
        except Exception as e:
            return f"Error: {e}"


# ---------------------------------------------------------------------------
# 9. MemorySearchTool
# ---------------------------------------------------------------------------

class MemorySearchTool(BaseTool):
    """Search brain memory using semantic/FTS search."""
    name = "memory_search"
    description = "Search brain memory. Args: query (str), user_id (str), limit (int, default 5)."

    def __call__(self, *, query: str, user_id: str = None, limit: int = 5,
                 db_path: str = None, **kw) -> str:
        if not query:
            return "Error: query is required"
        try:
            from aibrain.core.memory_api import Brain
            brain = Brain(db_path=db_path)
            results = brain.search(query, user_id=user_id, limit=limit)
            if not results:
                return f"No memories found for: {query}"
            lines = []
            for r in results:
                score = r.get("score", 0)
                mem = r.get("memory", "")[:200]
                lines.append(f"[{score:.2f}] {mem}")
            return "\n".join(lines)
        except Exception as e:
            return f"Memory search error: {e}"


# ---------------------------------------------------------------------------
# 10. MemoryStoreTool
# ---------------------------------------------------------------------------

class MemoryStoreTool(BaseTool):
    """Store a new memory in the brain."""
    name = "memory_store"
    description = "Store a memory. Args: content (str), user_id (str), metadata (dict)."

    def __call__(self, *, content: str, user_id: str = None, metadata: dict = None,
                 db_path: str = None, **kw) -> str:
        if not content:
            return "Error: content is required"
        try:
            from aibrain.core.memory_api import Brain
            brain = Brain(db_path=db_path)
            results = brain.add(content, user_id=user_id, metadata=metadata, infer=False)
            events = [f"{r['event']}(id={r['id']})" for r in results]
            return f"Stored: {', '.join(events)}"
        except Exception as e:
            return f"Memory store error: {e}"


# ---------------------------------------------------------------------------
# 11. JSONParseTool
# ---------------------------------------------------------------------------

class JSONParseTool(BaseTool):
    """Parse JSON data and optionally query with a dotted path."""
    name = "json_parse"
    description = "Parse and query JSON. Args: data (str), path (str, e.g. 'users.0.name')."

    def __call__(self, *, data: str, path: str = "", **kw) -> str:
        if not data:
            return "Error: data is required"
        try:
            parsed = json.loads(data)
        except json.JSONDecodeError as e:
            return f"Error: invalid JSON: {e}"

        if not path:
            return json.dumps(parsed, indent=2, default=str)

        # Navigate dotted path
        current = parsed
        for key in path.split("."):
            try:
                if isinstance(current, list):
                    current = current[int(key)]
                elif isinstance(current, dict):
                    current = current[key]
                else:
                    return f"Error: cannot traverse into {type(current).__name__} with key '{key}'"
            except (KeyError, IndexError, ValueError) as e:
                return f"Error: path '{path}' failed at '{key}': {e}"

        if isinstance(current, (dict, list)):
            return json.dumps(current, indent=2, default=str)
        return str(current)


# ---------------------------------------------------------------------------
# 12. CSVReadTool
# ---------------------------------------------------------------------------

class CSVReadTool(BaseTool):
    """Read and query CSV files."""
    name = "csv_read"
    description = "Read a CSV file. Args: path (str), limit (int), columns (list[str]), filter_col (str), filter_val (str)."

    def __call__(self, *, path: str, limit: int = 50, columns: list = None,
                 filter_col: str = None, filter_val: str = None, **kw) -> str:
        if not path:
            return "Error: path is required"
        p = Path(path)
        if not p.exists():
            return f"Error: file not found: {path}"
        try:
            with open(p, newline="", encoding="utf-8-sig") as f:
                reader = csv.DictReader(f)
                if not reader.fieldnames:
                    return "Error: CSV has no headers"

                rows = []
                for row in reader:
                    # Apply filter
                    if filter_col and filter_val:
                        if row.get(filter_col, "") != filter_val:
                            continue
                    # Apply column selection
                    if columns:
                        row = {k: v for k, v in row.items() if k in columns}
                    rows.append(row)
                    if len(rows) >= limit:
                        break

            if not rows:
                return "No rows matched"

            # Format as table
            headers = list(rows[0].keys())
            lines = [" | ".join(headers)]
            lines.append(" | ".join("-" * len(h) for h in headers))
            for row in rows:
                lines.append(" | ".join(str(row.get(h, "")) for h in headers))
            return "\n".join(lines)
        except Exception as e:
            return f"Error reading CSV: {e}"


# ---------------------------------------------------------------------------
# 13. CalculatorTool
# ---------------------------------------------------------------------------

# Whitelist of safe AST node types for math evaluation
_SAFE_NODES = (
    ast.Expression, ast.BinOp, ast.UnaryOp, ast.Constant, ast.Num,
    ast.Add, ast.Sub, ast.Mult, ast.Div, ast.FloorDiv, ast.Mod, ast.Pow,
    ast.USub, ast.UAdd,
)


class CalculatorTool(BaseTool):
    """Safely evaluate math expressions using AST parsing."""
    name = "calculator"
    description = "Evaluate a math expression. Args: expression (str). Examples: '2+3', '(10*5)/2', '2**10'."

    def __call__(self, *, expression: str, **kw) -> str:
        if not expression:
            return "Error: expression is required"
        try:
            tree = ast.parse(expression.strip(), mode="eval")
            # Validate all nodes are safe math operations
            for node in ast.walk(tree):
                if not isinstance(node, _SAFE_NODES):
                    return f"Error: unsupported operation: {type(node).__name__}"
            result = eval(compile(tree, "<calc>", "eval"))
            return str(result)
        except ZeroDivisionError:
            return "Error: division by zero"
        except SyntaxError as e:
            return f"Error: invalid expression: {e}"
        except Exception as e:
            return f"Error: {e}"


# ---------------------------------------------------------------------------
# 14. DateTimeTool
# ---------------------------------------------------------------------------

class DateTimeTool(BaseTool):
    """Get current date/time, do date math, or format dates."""
    name = "datetime"
    description = ("Date/time operations. Args: operation (str: 'now', 'format', 'add', 'diff'), "
                   "date (str), days (int), hours (int), fmt (str).")

    def __call__(self, *, operation: str = "now", date: str = None,
                 days: int = 0, hours: int = 0, fmt: str = "%Y-%m-%d %H:%M:%S",
                 **kw) -> str:
        try:
            if operation == "now":
                return datetime.now().strftime(fmt)

            elif operation == "utc":
                return datetime.now(timezone.utc).strftime(fmt)

            elif operation == "format":
                if not date:
                    return "Error: date is required for format operation"
                # Try common formats
                for parse_fmt in ["%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%Y-%m-%dT%H:%M:%S",
                                  "%Y-%m-%dT%H:%M:%SZ", "%m/%d/%Y", "%d/%m/%Y"]:
                    try:
                        dt = datetime.strptime(date, parse_fmt)
                        return dt.strftime(fmt)
                    except ValueError:
                        continue
                return f"Error: could not parse date: {date}"

            elif operation == "add":
                base = datetime.now()
                if date:
                    for parse_fmt in ["%Y-%m-%d %H:%M:%S", "%Y-%m-%d"]:
                        try:
                            base = datetime.strptime(date, parse_fmt)
                            break
                        except ValueError:
                            continue
                result = base + timedelta(days=days, hours=hours)
                return result.strftime(fmt)

            elif operation == "diff":
                if not date:
                    return "Error: date is required for diff operation"
                target = None
                for parse_fmt in ["%Y-%m-%d %H:%M:%S", "%Y-%m-%d"]:
                    try:
                        target = datetime.strptime(date, parse_fmt)
                        break
                    except ValueError:
                        continue
                if target is None:
                    return f"Error: could not parse date: {date}"
                delta = target - datetime.now()
                return f"{delta.days} days, {delta.seconds // 3600} hours"

            else:
                return f"Error: unknown operation: {operation}. Use: now, utc, format, add, diff"
        except Exception as e:
            return f"Error: {e}"


# ---------------------------------------------------------------------------
# 15. TextSummaryTool
# ---------------------------------------------------------------------------

class TextSummaryTool(BaseTool):
    """Extract a summary from long text (no LLM, pure extraction)."""
    name = "text_summary"
    description = "Summarize text by extracting key sentences. Args: text (str), max_sentences (int, default 5)."

    def __call__(self, *, text: str, max_sentences: int = 5, **kw) -> str:
        if not text:
            return "Error: text is required"
        # Split into sentences
        sentences = re.split(r'(?<=[.!?])\s+', text.strip())
        if len(sentences) <= max_sentences:
            return text.strip()

        # Score sentences by position and keyword density
        scored = []
        keywords = set()
        # Extract capitalized words as rough keywords
        for s in sentences:
            for word in re.findall(r'\b[A-Z][a-z]+\b', s):
                keywords.add(word.lower())

        for i, s in enumerate(sentences):
            score = 0.0
            # Position bonus: first and last sentences matter more
            if i == 0:
                score += 2.0
            elif i == len(sentences) - 1:
                score += 1.0
            elif i < 3:
                score += 1.5

            # Length penalty: very short sentences are less informative
            words = s.split()
            if len(words) < 4:
                score -= 1.0
            elif len(words) > 8:
                score += 0.5

            # Keyword density
            word_set = {w.lower().strip(".,!?;:") for w in words}
            overlap = len(word_set & keywords)
            score += overlap * 0.3

            scored.append((score, i, s))

        # Sort by score descending, take top N, then re-order by position
        scored.sort(key=lambda x: x[0], reverse=True)
        top = scored[:max_sentences]
        top.sort(key=lambda x: x[1])  # restore original order

        return " ".join(s for _, _, s in top)


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

_ALL_TOOLS = [
    ReadFileTool(),
    WriteFileTool(),
    ListDirectoryTool(),
    SearchFilesTool(),
    WebSearchTool(),
    WebFetchTool(),
    ShellTool(),
    PythonREPLTool(),
    MemorySearchTool(),
    MemoryStoreTool(),
    JSONParseTool(),
    CSVReadTool(),
    CalculatorTool(),
    DateTimeTool(),
    TextSummaryTool(),
]

BUILTIN_TOOLS: dict[str, BaseTool] = {tool.name: tool for tool in _ALL_TOOLS}


def get_tool(name: str) -> Optional[BaseTool]:
    """Get a tool by name, or None if not found."""
    return BUILTIN_TOOLS.get(name)


def list_tools() -> list[str]:
    """Return names of all built-in tools."""
    return list(BUILTIN_TOOLS.keys())
