"""
aibrain.tools.evolution.config — Interactive evolution configuration menu.

Config file: ~/.aibrain/evolution.toml

Provides interactive_menu() for `aibrain settings` > Evolution
and load_evolution_config() consumed by the harness/workflow_runner.

Example evolution.toml:
    [evolution]
    auto_evolve = true
    interval_hours = 6
"""
from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

_CONFIG_PATH = Path.home() / '.aibrain' / 'evolution.toml'

# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------

_DEFAULTS: dict[str, Any] = {
    'auto_evolve': True,
    'interval_hours': 6,
}

# Cached config
_config_cache: dict | None = None


# ---------------------------------------------------------------------------
# TOML parsing (same minimal pattern as other config modules)
# ---------------------------------------------------------------------------

def _load_toml_file(path: Path) -> dict:
    if sys.version_info >= (3, 11):
        import tomllib
        with open(path, 'rb') as f:
            return tomllib.load(f)
    else:
        return _parse_toml_minimal(path.read_text(encoding='utf-8'))


def _parse_toml_minimal(text: str) -> dict:
    result: dict = {}
    current: dict = result
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith('#'):
            continue
        if line.startswith('[') and line.endswith(']'):
            section = line[1:-1].strip()
            parts = section.split('.')
            current = result
            for part in parts:
                current = current.setdefault(part, {})
            continue
        if '=' in line:
            key, _, raw_val = line.partition('=')
            key = key.strip()
            raw_val = raw_val.strip()
            if ' #' in raw_val:
                raw_val = raw_val[:raw_val.index(' #')].strip()
            val: Any
            if raw_val.lower() == 'true':
                val = True
            elif raw_val.lower() == 'false':
                val = False
            elif raw_val.startswith('"') or raw_val.startswith("'"):
                val = raw_val.strip('"\'')
            else:
                try:
                    val = int(raw_val)
                except ValueError:
                    try:
                        val = float(raw_val)
                    except ValueError:
                        val = raw_val
            current[key] = val
    return result


def _write_toml(data: dict, path: Path) -> None:
    lines: list[str] = []

    def _write_section(d: dict, prefix: str) -> None:
        scalars = {k: v for k, v in d.items() if not isinstance(v, dict)}
        dicts = {k: v for k, v in d.items() if isinstance(v, dict)}
        if scalars:
            if prefix:
                lines.append(f'\n[{prefix}]')
            for k, v in scalars.items():
                if isinstance(v, bool):
                    lines.append(f'{k} = {"true" if v else "false"}')
                elif isinstance(v, str):
                    lines.append(f'{k} = "{v}"')
                else:
                    lines.append(f'{k} = {v}')
        for k, v in dicts.items():
            sub_prefix = f'{prefix}.{k}' if prefix else k
            _write_section(v, sub_prefix)

    _write_section(data, '')
    path.write_text('\n'.join(lines).strip() + '\n', encoding='utf-8')


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def load_evolution_config() -> dict:
    """Load evolution config from ~/.aibrain/evolution.toml.

    Returns dict with keys: auto_evolve (bool), interval_hours (int).
    """
    global _config_cache
    if _config_cache is not None:
        return _config_cache

    result: dict[str, Any] = dict(_DEFAULTS)

    if _CONFIG_PATH.exists():
        try:
            raw = _load_toml_file(_CONFIG_PATH)
            evo = raw.get('evolution', {})
            if 'auto_evolve' in evo:
                result['auto_evolve'] = bool(evo['auto_evolve'])
            if 'interval_hours' in evo:
                result['interval_hours'] = int(evo['interval_hours'])
        except Exception:
            pass

    _config_cache = result
    return result


def _invalidate_cache() -> None:
    global _config_cache
    _config_cache = None


# ---------------------------------------------------------------------------
# Interactive menu
# ---------------------------------------------------------------------------

def _getch() -> str:
    from aibrain.cli.utils import _getch as _shared_getch
    return _shared_getch()


def _render_menu(auto_evolve: bool, interval_hours: int, focused: int) -> str:
    lines = [
        '',
        '  Evolution Config  (SPACE toggle, +/- adjust, ENTER save, Q quit)',
        '',
    ]
    # Item 0: auto-evolve checkbox
    marker = 'x' if auto_evolve else ' '
    cursor = '>' if focused == 0 else ' '
    lines.append(f'  {cursor} [{marker}] 1. Auto-evolution   Automatically evolve skills after executions')

    # Item 1: interval scale
    cursor = '>' if focused == 1 else ' '
    bar_width = 10
    frac = (interval_hours - 1) / max(24 - 1, 1)
    filled = max(0, min(bar_width, int(frac * bar_width + 0.5)))
    bar = '=' * filled + '-' * (bar_width - filled)
    lines.append(f'  {cursor}     2. Interval         [{bar}]  {interval_hours}h  (+/- 1, range 1-24)')

    lines.append('')
    lines.append('  ENTER to save  |  Q to quit without saving')
    lines.append('')
    return '\n'.join(lines)


def _save_config(auto_evolve: bool, interval_hours: int) -> None:
    _CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    data = {
        'evolution': {
            'auto_evolve': auto_evolve,
            'interval_hours': interval_hours,
        }
    }
    _write_toml(data, _CONFIG_PATH)
    _invalidate_cache()


def interactive_menu() -> None:
    """Launch the interactive evolution config menu."""
    if not sys.stdout.isatty():
        cfg = load_evolution_config()
        print(f'auto_evolve={"enabled" if cfg["auto_evolve"] else "disabled"}')
        print(f'interval_hours={cfg["interval_hours"]}')
        return

    _invalidate_cache()
    cfg = load_evolution_config()
    auto_evolve = cfg['auto_evolve']
    interval_hours = cfg['interval_hours']
    focused = 0
    n = 2

    menu_text = _render_menu(auto_evolve, interval_hours, focused)
    sys.stdout.write(menu_text)
    sys.stdout.flush()
    menu_lines = menu_text.count('\n')

    while True:
        ch = _getch()

        if ch in ('\r', '\n'):
            sys.stdout.write('\n')
            _save_config(auto_evolve, interval_hours)
            status = "on" if auto_evolve else "off"
            print(f'Saved. Auto-evolution: {status}, interval: {interval_hours}h.')
            return

        if ch in ('q', 'Q'):
            sys.stdout.write('\n')
            print('No changes.')
            return

        if ch == ' ':
            if focused == 0:
                auto_evolve = not auto_evolve

        elif ch in ('+', '='):
            if focused == 1:
                interval_hours = min(24, interval_hours + 1)

        elif ch == '-':
            if focused == 1:
                interval_hours = max(1, interval_hours - 1)

        elif ch.isdigit():
            idx = int(ch) - 1
            if 0 <= idx < n:
                focused = idx
                if idx == 0:
                    auto_evolve = not auto_evolve

        elif ch == '\x1b':
            try:
                next1 = _getch()
                if next1 == '[':
                    next2 = _getch()
                    if next2 == 'A':
                        focused = (focused - 1) % n
                    elif next2 == 'B':
                        focused = (focused + 1) % n
            except Exception:
                pass

        elif ch == '\xe0' or ch == '\x00':
            try:
                next1 = _getch()
                if next1 == 'H':
                    focused = (focused - 1) % n
                elif next1 == 'P':
                    focused = (focused + 1) % n
            except Exception:
                pass

        else:
            continue

        sys.stdout.write(f'\x1b[{menu_lines}A')
        new_text = _render_menu(auto_evolve, interval_hours, focused)
        sys.stdout.write(new_text)
        sys.stdout.flush()
        menu_lines = new_text.count('\n')
