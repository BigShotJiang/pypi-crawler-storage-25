"""
doc_export.py — Convert Markdown documents to clean PDFs.

Stack: markdown (MD→HTML) + xhtml2pdf (HTML→PDF, default) or WeasyPrint (opt-in).

xhtml2pdf is pure-Python and works on Windows without any system binary install.
WeasyPrint produces higher-quality output but requires GTK3 native libs on Windows.

Install optional deps:
    pip install aibrain[export]
    # or manually:
    pip install markdown xhtml2pdf

To opt into WeasyPrint (Linux/macOS or Windows with GTK3-Runtime installed):
    AIBRAIN_PDF_BACKEND=weasyprint pip install weasyprint
    AIBRAIN_PDF_BACKEND=weasyprint python -m aibrain.tools.doc_export file.md
"""

from __future__ import annotations

import os
from pathlib import Path

# ─── Embedded CSS ─────────────────────────────────────────────────────────────

_CSS = """
@page {
    margin: 2cm;
    size: A4;
}

body {
    font-family: system-ui, Georgia, "Times New Roman", serif;
    font-size: 11pt;
    line-height: 1.6;
    color: #1a1a1a;
    max-width: 100%;
}

h1 {
    font-size: 22pt;
    font-weight: 700;
    color: #111;
    margin-top: 2.5em;
    margin-bottom: 0.5em;
    padding-bottom: 0.2em;
    border-bottom: 2px solid #ddd;
    page-break-before: always;
}

h1:first-child,
h1:first-of-type {
    page-break-before: avoid;
}

h2 {
    font-size: 16pt;
    font-weight: 600;
    color: #222;
    margin-top: 1.8em;
    margin-bottom: 0.4em;
    border-bottom: 1px solid #eee;
    padding-bottom: 0.1em;
}

h3 {
    font-size: 13pt;
    font-weight: 600;
    color: #333;
    margin-top: 1.4em;
    margin-bottom: 0.3em;
}

h4, h5, h6 {
    font-size: 11pt;
    font-weight: 600;
    color: #444;
    margin-top: 1em;
    margin-bottom: 0.2em;
}

p {
    margin-top: 0.5em;
    margin-bottom: 0.8em;
}

a {
    color: #2563eb;
    text-decoration: underline;
}

code {
    font-family: "Courier New", Courier, monospace;
    font-size: 9.5pt;
    background-color: #f3f4f6;
    color: #111;
    padding: 0.1em 0.3em;
    border-radius: 3px;
    border: 1px solid #e5e7eb;
}

pre {
    background-color: #f3f4f6;
    border: 1px solid #d1d5db;
    border-radius: 4px;
    padding: 0.8em 1em;
    overflow-x: auto;
    margin: 0.8em 0;
    page-break-inside: avoid;
}

pre code {
    background: none;
    border: none;
    padding: 0;
    font-size: 9pt;
    line-height: 1.5;
}

blockquote {
    border-left: 4px solid #9ca3af;
    margin: 0.8em 0;
    padding: 0.4em 1em;
    color: #555;
    background: #fafafa;
}

ul, ol {
    margin: 0.5em 0 0.8em 1.5em;
    padding: 0;
}

li {
    margin-bottom: 0.2em;
}

table {
    border-collapse: collapse;
    width: 100%;
    margin: 1em 0;
    font-size: 10pt;
    page-break-inside: avoid;
}

th, td {
    border: 1px solid #d1d5db;
    padding: 0.4em 0.6em;
    text-align: left;
}

th {
    background-color: #f3f4f6;
    font-weight: 600;
}

tr:nth-child(even) {
    background-color: #fafafa;
}

hr {
    border: none;
    border-top: 1px solid #e5e7eb;
    margin: 1.5em 0;
}

img {
    max-width: 100%;
    height: auto;
}
"""

# ─── Backend detection ────────────────────────────────────────────────────────

def _detect_backend() -> str:
    """Return the PDF backend to use: 'weasyprint' or 'xhtml2pdf'.

    Priority:
    1. If AIBRAIN_PDF_BACKEND=weasyprint AND weasyprint is importable → weasyprint
    2. xhtml2pdf (pure-Python, works everywhere, default)
    3. weasyprint as last-resort fallback (if xhtml2pdf not installed but weasyprint is)
    4. 'none' — neither backend available

    WeasyPrint requires GTK3/Pango native libs (needs manual install on Windows).
    xhtml2pdf is pure-Python via ReportLab and ships with pip install aibrain[export].
    """
    # Opt-in: WeasyPrint only when explicitly requested AND importable
    if os.environ.get("AIBRAIN_PDF_BACKEND") == "weasyprint":
        try:
            from weasyprint import HTML  # noqa: F401
            return "weasyprint"
        except (ImportError, OSError):
            pass  # env var set but weasyprint not installed — fall through to xhtml2pdf

    # Default: xhtml2pdf (pure-Python, no system deps)
    try:
        from xhtml2pdf import pisa  # noqa: F401
        return "xhtml2pdf"
    except ImportError:
        pass

    # Last-resort fallback: weasyprint (if somehow installed but env var not set)
    try:
        from weasyprint import HTML  # noqa: F401
        return "weasyprint"
    except (ImportError, OSError):
        pass

    return "none"


def _html_to_pdf_weasyprint(html_doc: str, dest: Path, base_url: str) -> None:
    from weasyprint import HTML, CSS
    css = CSS(string=_CSS)
    HTML(string=html_doc, base_url=base_url).write_pdf(str(dest), stylesheets=[css])


def _html_to_pdf_xhtml2pdf(html_doc: str, dest: Path) -> None:
    from xhtml2pdf import pisa
    # xhtml2pdf expects CSS embedded in the HTML <style> block
    html_with_css = html_doc.replace(
        "</head>",
        f"<style>{_CSS}</style></head>",
        1,
    )
    with open(str(dest), "wb") as fh:
        result = pisa.CreatePDF(html_with_css.encode("utf-8"), dest=fh)
    if result.err:
        raise RuntimeError(f"xhtml2pdf conversion failed with {result.err} error(s)")


# ─── Core conversion ──────────────────────────────────────────────────────────


def export_md_to_pdf(md_path: str, out_path: str = None) -> str:
    """Convert a single Markdown file to a clean PDF.

    Backend selection:
    - xhtml2pdf (ReportLab) is the default — pure-Python, works on all platforms
      with no system binary dependencies.
    - WeasyPrint is used only when AIBRAIN_PDF_BACKEND=weasyprint is set AND
      weasyprint is importable. Produces higher-quality output but requires
      GTK3/Pango native libs (needs manual install on Windows).

    Args:
        md_path:  Path to the input .md file.
        out_path: Destination PDF path. Defaults to same directory and name as
                  input with .pdf extension.

    Returns:
        Absolute path to the written PDF.

    Raises:
        ImportError: if neither markdown nor a PDF backend is installed.
        FileNotFoundError: if md_path does not exist.
    """
    try:
        import markdown as _md
    except ImportError:
        raise ImportError(
            "The 'markdown' package is required for PDF export.\n"
            "Install with:  pip install aibrain[export]"
        )

    backend = _detect_backend()
    if backend == "none":
        raise ImportError(
            "No PDF backend found.\n"
            "Install with:  pip install aibrain[export]"
        )

    src = Path(md_path).resolve()
    if not src.exists():
        raise FileNotFoundError(f"Markdown file not found: {src}")

    if out_path is None:
        dest = src.with_suffix(".pdf")
    else:
        dest = Path(out_path).resolve()

    dest.parent.mkdir(parents=True, exist_ok=True)

    raw_md = src.read_text(encoding="utf-8")

    # Extensions: tables, fenced code blocks, attribute lists, definition lists
    html_body = _md.markdown(
        raw_md,
        extensions=["tables", "fenced_code", "attr_list", "def_list", "toc"],
    )

    html_doc = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>{src.stem}</title>
</head>
<body>
{html_body}
</body>
</html>"""

    if backend == "weasyprint":
        _html_to_pdf_weasyprint(html_doc, dest, str(src.parent))
    else:
        _html_to_pdf_xhtml2pdf(html_doc, dest)

    return str(dest)


def export_directory(dir_path: str, out_dir: str = None) -> list[str]:
    """Export all .md files in a directory to PDFs.

    Args:
        dir_path: Directory to scan for .md files (non-recursive).
        out_dir:  Destination directory for PDFs. Defaults to same directory
                  as dir_path.

    Returns:
        List of absolute paths to the written PDFs.
    """
    src_dir = Path(dir_path).resolve()
    if not src_dir.is_dir():
        raise NotADirectoryError(f"Not a directory: {src_dir}")

    if out_dir is None:
        dest_dir = src_dir
    else:
        dest_dir = Path(out_dir).resolve()
        dest_dir.mkdir(parents=True, exist_ok=True)

    md_files = sorted(src_dir.glob("*.md"))
    if not md_files:
        return []

    results: list[str] = []
    for md_file in md_files:
        out_path = dest_dir / md_file.with_suffix(".pdf").name
        written = export_md_to_pdf(str(md_file), str(out_path))
        results.append(written)

    return results


# ─── Harness-wrapped CLI entry ────────────────────────────────────────────────

def _cli_main() -> None:
    """Parse sys.argv and call export_md_to_pdf / export_directory."""
    import sys

    args = sys.argv[1:]
    if not args or args[0] in ("-h", "--help"):
        print(__doc__)
        print("Usage:")
        print("  python -m aibrain.tools.doc_export <file.md>              Export single file")
        print("  python -m aibrain.tools.doc_export <file.md> --out out.pdf  Custom output path")
        print("  python -m aibrain.tools.doc_export <dir/>                  Export all .md in dir")
        print("  python -m aibrain.tools.doc_export <dir/> --out out_dir/   Export all to dir")
        sys.exit(0)

    target = os.path.expanduser(args[0])
    out_path = None
    if "--out" in args:
        idx = args.index("--out")
        out_path = args[idx + 1] if idx + 1 < len(args) else None

    if os.path.isdir(target):
        outputs = export_directory(target, out_dir=out_path)
        if not outputs:
            print(f"No .md files found in: {target}")
        else:
            for p in outputs:
                size = os.path.getsize(p)
                print(f"  Exported: {p}  ({size:,} bytes)")
            print(f"\n  {len(outputs)} file(s) exported.")
    else:
        result = export_md_to_pdf(target, out_path=out_path)
        size = os.path.getsize(result)
        print(f"Exported: {result}  ({size:,} bytes)")


if __name__ == "__main__":
    from aibrain.core.workflow_base import workflow_execute

    def _entry():
        _cli_main()

    workflow_execute(
        workflow_name="doc_export",
        action=_entry,
        task_type="simple",
        actor="cli",
    )
