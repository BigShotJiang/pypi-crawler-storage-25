"""
Tests for aibrain.tools.workflows.config — interactive workflow configuration menu.

Covers all 10 acceptance criteria from Build 1 spec.
"""
import os
import sqlite3
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

# Ensure project root is on path for workflow_scheduler import
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent.parent))

from aibrain.tools.workflows.config import (
    _load_workflows,
    _group_by_category,
    _MenuState,
    _render_menu,
    _save_diffs,
    interactive_menu,
    PAGE_SIZE,
    _CATEGORY_LABELS,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def temp_db(tmp_path):
    """Create a temporary DB with sample workflows for testing."""
    db_path = str(tmp_path / "test.db")
    conn = sqlite3.connect(db_path)
    conn.execute("""
        CREATE TABLE workflows (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            display_name TEXT DEFAULT '',
            category TEXT DEFAULT 'general',
            description TEXT DEFAULT '',
            cron_schedule TEXT DEFAULT '',
            enabled INTEGER DEFAULT 0,
            source TEXT DEFAULT 'registry'
        )
    """)
    # Insert test workflows across categories
    workflows = [
        ("email_triage", "Email Triage", "comms", "Triage inbox", 1),
        ("email_auto_reply", "Email Auto Reply", "comms", "Draft replies", 1),
        ("newsletter_digest", "Newsletter Digest", "comms", "Summarise newsletters", 1),
        ("contact_enricher", "Contact Enricher", "comms", "Enrich contacts", 0),
        ("content_calendar", "Content Calendar", "comms", "Schedule content", 1),
        ("daily_planner", "Daily Planner", "productivity", "Plan your day", 0),
        ("weekly_report", "Weekly Report", "productivity", "Weekly summary", 1),
        ("habit_tracker", "Habit Tracker", "productivity", "Track habits", 0),
        ("arxiv_tracker", "Arxiv Tracker", "research", "Track papers", 0),
        ("daily_research", "Daily Research", "research", "Daily scanning", 1),
        ("risk_analyst", "Risk Analyst", "intelligence", "Risk analysis", 0),
    ]
    conn.executemany(
        "INSERT INTO workflows (name, display_name, category, description, enabled) VALUES (?, ?, ?, ?, ?)",
        workflows,
    )
    conn.commit()
    conn.close()
    return db_path


@pytest.fixture
def state_from_db(temp_db):
    """Create a _MenuState from the temp DB."""
    wfs = _load_workflows(temp_db)
    groups = _group_by_category(wfs)
    return _MenuState(groups)


# ---------------------------------------------------------------------------
# Test 1: Menu launches without error (AC1)
# ---------------------------------------------------------------------------

def test_interactive_menu_launches_non_tty(temp_db, capsys):
    """AC1 + AC7: Non-tty fallback prints workflow_name=enabled|disabled."""
    import io
    fake_out = io.StringIO()
    fake_out.isatty = lambda: False
    with patch("sys.stdout", fake_out):
        interactive_menu(temp_db)

    output = fake_out.getvalue()
    lines = [l for l in output.strip().split("\n") if l]
    assert len(lines) == 11  # 11 test workflows
    # Check format
    for line in lines:
        assert "=" in line
        name, status = line.split("=", 1)
        assert status in ("enabled", "disabled")


# ---------------------------------------------------------------------------
# Test 2: Current enabled/disabled state shown correctly (AC2)
# ---------------------------------------------------------------------------

def test_initial_state_matches_db(temp_db):
    """AC2: Initial render matches DB state."""
    wfs = _load_workflows(temp_db)
    groups = _group_by_category(wfs)
    state = _MenuState(groups)

    # Verify specific items
    assert state.current["email_triage"] is True
    assert state.current["contact_enricher"] is False
    assert state.current["daily_planner"] is False
    assert state.current["daily_research"] is True


# ---------------------------------------------------------------------------
# Test 3: Toggle + save persists changes (AC3)
# ---------------------------------------------------------------------------

def test_toggle_and_save_persists(temp_db):
    """AC3: Toggling an item and saving persists to DB."""
    wfs = _load_workflows(temp_db)
    groups = _group_by_category(wfs)
    state = _MenuState(groups)

    # contact_enricher is in comms group (index 0), find it
    comms_cat, comms_wfs = groups[0]
    assert comms_cat == "comms"
    enricher_idx = next(i for i, w in enumerate(comms_wfs) if w["name"] == "contact_enricher")

    # Toggle it on
    state.toggle(enricher_idx)
    assert state.current["contact_enricher"] is True

    # Save diffs
    to_enable, to_disable = state.get_diffs()
    assert "contact_enricher" in to_enable
    assert len(to_disable) == 0

    _save_diffs(temp_db, to_enable, to_disable)

    # Verify DB
    conn = sqlite3.connect(temp_db)
    row = conn.execute("SELECT enabled FROM workflows WHERE name='contact_enricher'").fetchone()
    conn.close()
    assert row[0] == 1


# ---------------------------------------------------------------------------
# Test 4: Q leaves no changes (AC4)
# ---------------------------------------------------------------------------

def test_quit_no_changes(temp_db):
    """AC4: Pressing Q leaves DB unchanged."""
    wfs = _load_workflows(temp_db)
    groups = _group_by_category(wfs)
    state = _MenuState(groups)

    # Toggle something but DON'T save
    state.toggle(0)
    # get_diffs would show changes, but we don't call _save_diffs
    to_enable, to_disable = state.get_diffs()
    assert len(to_enable) > 0 or len(to_disable) > 0

    # DB should still be unchanged
    conn = sqlite3.connect(temp_db)
    rows = conn.execute("SELECT name, enabled FROM workflows ORDER BY name").fetchall()
    conn.close()
    original_wfs = _load_workflows(temp_db)
    # Re-verify original states
    for wf in original_wfs:
        if wf["name"] == "contact_enricher":
            assert wf["enabled"] == 0  # still disabled


# ---------------------------------------------------------------------------
# Test 5: G cycles through all groups, wraps (AC5)
# ---------------------------------------------------------------------------

def test_group_cycling_wraps(state_from_db):
    """AC5: G key cycles through all groups, last wraps to first."""
    state = state_from_db
    n_groups = len(state.groups)
    assert n_groups == 4  # comms, intelligence, productivity, research

    first_group = state.groups[0][0]
    assert state.group_idx == 0

    # Cycle through all groups
    for i in range(n_groups):
        state.next_group()

    # Should be back to first
    assert state.group_idx == 0
    assert state.current_group[0] == first_group


# ---------------------------------------------------------------------------
# Test 6: R shows recommended but does not save (AC6)
# ---------------------------------------------------------------------------

def test_recommended_preview_no_save(temp_db):
    """AC6: R key shows recommended set but does not persist until ENTER."""
    wfs = _load_workflows(temp_db)
    groups = _group_by_category(wfs)
    state = _MenuState(groups)

    original_enabled = state.total_enabled
    state.apply_recommended()

    # Some should now be toggled on in state
    new_enabled = state.total_enabled
    assert new_enabled >= original_enabled

    # But DB should be unchanged
    conn = sqlite3.connect(temp_db)
    db_enabled = conn.execute("SELECT COUNT(*) FROM workflows WHERE enabled=1").fetchone()[0]
    conn.close()
    assert db_enabled == 6  # original count


# ---------------------------------------------------------------------------
# Test 7: Non-tty fallback format (AC7)
# ---------------------------------------------------------------------------

def test_non_tty_fallback_format(temp_db):
    """AC7: Non-tty prints workflow_name=enabled|disabled."""
    import io
    fake_out = io.StringIO()
    fake_out.isatty = lambda: False
    with patch("sys.stdout", fake_out):
        interactive_menu(temp_db)

    output = fake_out.getvalue()
    lines = [l for l in output.strip().split("\n") if l]
    # Every line must match name=enabled|disabled
    for line in lines:
        assert "=" in line
        parts = line.split("=", 1)
        assert len(parts) == 2
        assert parts[1] in ("enabled", "disabled")


# ---------------------------------------------------------------------------
# Test 8: Arrow keys navigate, number keys toggle, SPACE toggles (AC8)
# ---------------------------------------------------------------------------

def test_number_toggle_and_space_toggle(state_from_db):
    """AC8: Number keys toggle by index, SPACE toggles focused."""
    state = state_from_db
    items = state.current_page_items
    first_name = items[0]["name"]
    original = state.current[first_name]

    # Toggle by index 0
    state.toggle(0)
    assert state.current[first_name] != original

    # Toggle back with same index
    state.toggle(0)
    assert state.current[first_name] == original

    # Focus on item 2, then toggle
    state.focused = 2
    third_name = items[2]["name"]
    original_third = state.current[third_name]
    state.toggle(state.focused)
    assert state.current[third_name] != original_third


def test_arrow_navigation(state_from_db):
    """AC8: Arrow keys move focus up and down with wrapping."""
    state = state_from_db
    n_items = len(state.current_page_items)
    assert n_items > 0

    state.focused = 0
    # Down wraps around
    for _ in range(n_items):
        old = state.focused
        state.focused = (state.focused + 1) % n_items
    assert state.focused == 0  # back to start

    # Up from 0 wraps to last
    state.focused = (state.focused - 1) % n_items
    assert state.focused == n_items - 1


# ---------------------------------------------------------------------------
# Test 9: After save prints summary (AC9)
# ---------------------------------------------------------------------------

def test_save_summary_message(temp_db, capsys):
    """AC9: After save, prints 'Saved. N of M workflows enabled.'"""
    wfs = _load_workflows(temp_db)
    groups = _group_by_category(wfs)
    state = _MenuState(groups)

    # Toggle one
    state.toggle(0)
    to_enable, to_disable = state.get_diffs()
    _save_diffs(temp_db, to_enable, to_disable)

    total_enabled = state.total_enabled
    total = state.total_workflows
    changes = len(to_enable) + len(to_disable)

    if changes:
        msg = f"Saved. {total_enabled} of {total} workflows enabled."
    else:
        msg = f"No changes. {total_enabled} of {total} workflows enabled."

    # Verify format matches spec
    assert "of" in msg
    assert "workflows enabled" in msg
    assert str(total_enabled) in msg
    assert str(total) in msg


# ---------------------------------------------------------------------------
# Test 10: No crash on empty group or single-item group (AC10)
# ---------------------------------------------------------------------------

def test_empty_group_no_crash():
    """AC10: Empty group renders without error."""
    empty_groups = [("empty_cat", [])]
    state = _MenuState(empty_groups)
    rendered = _render_menu(state)
    assert "0 workflows" in rendered
    assert "0 enabled" in rendered
    assert state.current_page_items == []
    assert state.group_enabled_count == 0


def test_single_item_group_no_crash():
    """AC10: Single-item group renders and toggles without error."""
    single_groups = [("single", [
        {"name": "solo_wf", "display_name": "Solo", "category": "single",
         "description": "Only one", "enabled": 0}
    ])]
    state = _MenuState(single_groups)
    rendered = _render_menu(state)
    assert "1 workflows" in rendered
    assert "solo_wf" in rendered

    # Toggle the single item
    state.toggle(0)
    assert state.current["solo_wf"] is True

    # Re-render after toggle
    rendered2 = _render_menu(state)
    assert "[x]" in rendered2


# ---------------------------------------------------------------------------
# Extra: Diff-only persistence (no bulk rewrite)
# ---------------------------------------------------------------------------

def test_save_diffs_only_changes(temp_db):
    """Only changed workflows are written to DB, not a full rewrite."""
    # Get original state
    conn = sqlite3.connect(temp_db)
    before = {r[0]: r[1] for r in conn.execute("SELECT name, enabled FROM workflows").fetchall()}
    conn.close()

    # Enable one, disable one
    _save_diffs(temp_db, ["contact_enricher"], ["email_triage"])

    conn = sqlite3.connect(temp_db)
    after = {r[0]: r[1] for r in conn.execute("SELECT name, enabled FROM workflows").fetchall()}
    conn.close()

    assert after["contact_enricher"] == 1
    assert after["email_triage"] == 0
    # Unchanged items should stay the same
    assert after["newsletter_digest"] == before["newsletter_digest"]
    assert after["daily_planner"] == before["daily_planner"]


# ---------------------------------------------------------------------------
# Extra: Pagination
# ---------------------------------------------------------------------------

def test_pagination():
    """Groups with >10 items show pagination."""
    many_wfs = [
        {"name": f"wf_{i:02d}", "display_name": f"WF {i}", "category": "big",
         "description": f"Workflow {i}", "enabled": i % 2}
        for i in range(15)
    ]
    groups = [("big", many_wfs)]
    state = _MenuState(groups)

    assert state.total_pages == 2
    assert len(state.current_page_items) == PAGE_SIZE

    state.next_page()
    assert state.page_idx == 1
    assert len(state.current_page_items) == 5

    rendered = _render_menu(state)
    assert "Page 2/2" in rendered


# ---------------------------------------------------------------------------
# Extra: Settings menu integration
# ---------------------------------------------------------------------------

def test_settings_menu_status():
    """get_workflows_status returns a formatted string."""
    from aibrain.cli.settings_menu import get_workflows_status
    status = get_workflows_status()
    assert "/" in status
    assert "enabled" in status


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
