"""
aibrain.tools.workflows.config — Interactive workflow configuration menu.

Checkbox menu grouped by category with in-place redraw.
Reads current state from the workflows DB table, applies diffs only on save.

Entry point: interactive_menu(db_path)

Keys:
    SPACE / number  Toggle focused / numbered item
    Arrow up/down   Navigate within group
    G               Cycle to next group
    R               Enable recommended set (preview, not saved until ENTER)
    ENTER           Save changes (diffs only)
    Q               Quit without saving
    P               Next page (if group has >10 items)

Non-tty fallback: prints <workflow_name>=enabled|disabled one per line.
"""
from __future__ import annotations

import os
import sqlite3
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from aibrain.cli.utils import _getch


# ---------------------------------------------------------------------------
# Human-readable labels for categories
# ---------------------------------------------------------------------------

_CATEGORY_LABELS: Dict[str, str] = {
    "business": "Business",
    "code_architecture": "Code & Architecture",
    "communication": "Communications",
    "content": "Content",
    "developer": "Developer",
    "devops": "DevOps",
    "email": "Email",
    "finance": "Finance",
    "intelligence": "Intelligence",
    "internal": "Internal",
    "job_hunting": "Job Hunting",
    "knowledge": "Knowledge",
    "multi_agent": "Multi-Agent",
    "ops": "Operations",
    "personal_intelligence": "Personal Intelligence",
    "proactive": "Proactive",
    "productivity": "Productivity",
    "professional": "Professional",
    "research": "Research",
    "security": "Security",
    "security_compliance": "Security & Compliance",
    "self_improvement": "Self Improvement",
    "skill_evolution": "Skill Evolution",
    "social_media": "Social Media",
    "trading": "Trading",
}

PAGE_SIZE = 10


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------

def _resolve_db_path(db_path: Optional[str] = None) -> str:
    """Resolve the aibrain.db path via the canonical resolver — see aibrain_db.AIBRAIN_ROOT."""
    if db_path:
        return db_path
    from aibrain_db import AIBRAIN_ROOT
    return str(AIBRAIN_ROOT / "aibrain.db")


def _load_workflows(db_path: str) -> List[Dict]:
    """Load all workflows from DB, ordered by category then name."""
    conn = sqlite3.connect(db_path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    rows = conn.execute(
        "SELECT name, display_name, category, description, enabled "
        "FROM workflows ORDER BY category, name"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def _group_by_category(workflows: List[Dict]) -> List[Tuple[str, List[Dict]]]:
    """Group workflows by category. Returns [(category, [wf, ...]), ...]."""
    groups: Dict[str, List[Dict]] = {}
    for wf in workflows:
        cat = wf.get("category", "general")
        groups.setdefault(cat, []).append(wf)
    # Sort groups alphabetically
    return sorted(groups.items(), key=lambda x: x[0])


def _get_recommended_names() -> List[str]:
    """Return the recommended workflow names from workflow_scheduler."""
    try:
        from workflow_scheduler import RECOMMENDED_ALL
        return list(RECOMMENDED_ALL)
    except ImportError:
        # Fallback: hardcoded subset
        return [
            "correction_learner", "memory_hygiene", "self_model_refresh",
            "session_prep", "task_retrospective", "skill_sharpener",
            "principle_validator", "decision_journal", "weekly_wins",
            "life_dashboard", "commitment_tracker", "learning_path",
            "daily_planner", "weekly_review",
        ]


# ---------------------------------------------------------------------------
# State tracking
# ---------------------------------------------------------------------------

class _MenuState:
    """Tracks current menu state across groups, pages, and toggle changes."""

    def __init__(self, groups: List[Tuple[str, List[Dict]]]):
        self.groups = groups
        self.group_idx = 0
        self.page_idx = 0
        self.focused = 0
        # Original enabled states keyed by workflow name
        self.original: Dict[str, bool] = {}
        # Current (possibly modified) states
        self.current: Dict[str, bool] = {}
        for _cat, wfs in groups:
            for wf in wfs:
                enabled = bool(wf.get("enabled", 0))
                self.original[wf["name"]] = enabled
                self.current[wf["name"]] = enabled

    @property
    def current_group(self) -> Tuple[str, List[Dict]]:
        return self.groups[self.group_idx]

    @property
    def current_page_items(self) -> List[Dict]:
        """Items on the current page of the current group."""
        _cat, wfs = self.current_group
        start = self.page_idx * PAGE_SIZE
        return wfs[start:start + PAGE_SIZE]

    @property
    def total_pages(self) -> int:
        _cat, wfs = self.current_group
        return max(1, (len(wfs) + PAGE_SIZE - 1) // PAGE_SIZE)

    @property
    def group_enabled_count(self) -> int:
        _cat, wfs = self.current_group
        return sum(1 for wf in wfs if self.current[wf["name"]])

    @property
    def total_enabled(self) -> int:
        return sum(1 for v in self.current.values() if v)

    @property
    def total_workflows(self) -> int:
        return len(self.current)

    def next_group(self) -> None:
        self.group_idx = (self.group_idx + 1) % len(self.groups)
        self.page_idx = 0
        self.focused = 0

    def next_page(self) -> None:
        if self.page_idx < self.total_pages - 1:
            self.page_idx += 1
            self.focused = 0

    def toggle(self, idx: int) -> None:
        """Toggle the item at idx on the current page."""
        items = self.current_page_items
        if 0 <= idx < len(items):
            name = items[idx]["name"]
            self.current[name] = not self.current[name]

    def apply_recommended(self) -> None:
        """Enable the recommended set (preview only, not persisted)."""
        recommended = _get_recommended_names()
        for name in recommended:
            if name in self.current:
                self.current[name] = True

    def get_diffs(self) -> Tuple[List[str], List[str]]:
        """Return (to_enable, to_disable) lists of workflow names that changed."""
        to_enable = []
        to_disable = []
        for name, was_enabled in self.original.items():
            now_enabled = self.current[name]
            if now_enabled and not was_enabled:
                to_enable.append(name)
            elif not now_enabled and was_enabled:
                to_disable.append(name)
        return to_enable, to_disable


# ---------------------------------------------------------------------------
# Rendering
# ---------------------------------------------------------------------------

def _render_menu(state: _MenuState) -> str:
    """Render the current menu view to a string."""
    cat, wfs = state.current_group
    label = _CATEGORY_LABELS.get(cat, cat.replace("_", " ").title())
    page_items = state.current_page_items
    n_items = len(page_items)
    total_in_group = len(wfs)
    enabled_in_group = state.group_enabled_count

    lines = [
        "",
        "  Workflow Manager  (SPACE/number to toggle, G to switch group, R for recommended, ENTER to save, Q to quit)",
        "",
        f"  Group: [{cat}] {state.group_idx + 1}/{len(state.groups)}  {label}  ({total_in_group} workflows, {enabled_in_group} enabled)",
        "",
    ]

    for i, wf in enumerate(page_items):
        marker = "x" if state.current[wf["name"]] else " "
        cursor = ">" if i == state.focused else " "
        name = wf["name"]
        desc = (wf.get("description") or "")[:50]
        num = i + 1 if i < 9 else 0
        lines.append(f"  {cursor} [{marker}] {num}. {name:<25s} {desc}")

    # Pagination indicator
    if state.total_pages > 1:
        lines.append("")
        lines.append(f"  Page {state.page_idx + 1}/{state.total_pages}  [P] next page")

    lines.append("")
    lines.append("  [G] next group  [R] enable recommended set  |  ENTER to save  |  Q to quit")
    lines.append("")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Persistence — apply diffs only
# ---------------------------------------------------------------------------

def _save_diffs(db_path: str, to_enable: List[str], to_disable: List[str]) -> None:
    """Apply enable/disable diffs to the DB. Only changed items are written."""
    if not to_enable and not to_disable:
        return
    conn = sqlite3.connect(db_path, check_same_thread=False)
    for name in to_enable:
        conn.execute("UPDATE workflows SET enabled=1 WHERE name=?", (name,))
    for name in to_disable:
        conn.execute("UPDATE workflows SET enabled=0 WHERE name=?", (name,))
    conn.commit()
    conn.close()


# ---------------------------------------------------------------------------
# Interactive menu entry point
# ---------------------------------------------------------------------------

def interactive_menu(db_path: Optional[str] = None) -> None:
    """
    Launch the interactive workflow configuration menu.

    Non-tty fallback: prints <workflow_name>=enabled|disabled one per line.
    """
    db_path = _resolve_db_path(db_path)
    workflows = _load_workflows(db_path)

    if not workflows:
        print("No workflows found. Run 'aibrain init' first.")
        return

    groups = _group_by_category(workflows)

    # Non-tty fallback
    if not sys.stdout.isatty():
        for wf in workflows:
            status = "enabled" if wf.get("enabled") else "disabled"
            print(f"{wf['name']}={status}")
        return

    state = _MenuState(groups)

    # Draw initial menu
    menu_text = _render_menu(state)
    sys.stdout.write(menu_text)
    sys.stdout.flush()
    menu_lines = menu_text.count("\n")

    while True:
        ch = _getch()

        # ENTER — save and exit
        if ch in ("\r", "\n"):
            sys.stdout.write("\n")
            to_enable, to_disable = state.get_diffs()
            _save_diffs(db_path, to_enable, to_disable)
            total_enabled = state.total_enabled
            total = state.total_workflows
            changes = len(to_enable) + len(to_disable)
            if changes:
                print(f"Saved. {total_enabled} of {total} workflows enabled.")
            else:
                print(f"No changes. {total_enabled} of {total} workflows enabled.")
            return

        # Q — quit without saving
        if ch in ("q", "Q"):
            sys.stdout.write("\n")
            print("No changes.")
            return

        # G — next group
        if ch in ("g", "G"):
            state.next_group()

        # R — recommended set
        elif ch in ("r", "R"):
            state.apply_recommended()

        # P — next page
        elif ch in ("p", "P"):
            state.next_page()

        # Number keys 1-9 — toggle item
        elif ch.isdigit() and ch != "0":
            idx = int(ch) - 1
            page_items = state.current_page_items
            if 0 <= idx < len(page_items):
                state.toggle(idx)
                state.focused = idx

        # SPACE — toggle focused item
        elif ch == " ":
            state.toggle(state.focused)

        # Arrow keys
        elif ch == "\x1b":
            try:
                next1 = _getch()
                if next1 == "[":
                    next2 = _getch()
                    n_items = len(state.current_page_items)
                    if n_items > 0:
                        if next2 == "A":  # Up
                            state.focused = (state.focused - 1) % n_items
                        elif next2 == "B":  # Down
                            state.focused = (state.focused + 1) % n_items
            except Exception:
                pass

        else:
            continue

        # Redraw
        sys.stdout.write(f"\x1b[{menu_lines}A")
        new_text = _render_menu(state)
        sys.stdout.write(new_text)
        sys.stdout.flush()
        menu_lines = new_text.count("\n")
