"""
aibrain.tools.model.config — Interactive model routing configuration.

Config file: ~/.aibrain/model.toml
Env vars override config file (highest precedence).

Example model.toml:
    [model]
    provider = "auto"
    embedding = "all-MiniLM-L6-v2"
    cost_per_run_max = 0.50
    daily_budget = 5.00

    [model.routing]
    deterministic = "code_only"
    simple = "haiku"
    judgment = "sonnet"
    complex = "opus"

Precedence: env var (highest) > config file > defaults.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any

_CONFIG_PATH = Path.home() / '.aibrain' / 'model.toml'

# Cached config — loaded once per process
_config_cache: dict | None = None

# ---------------------------------------------------------------------------
# Defaults — match current hardcoded behaviour
# ---------------------------------------------------------------------------

DEFAULTS: dict[str, Any] = {
    'provider': 'auto',
    'embedding': 'all-MiniLM-L6-v2',
    'cost_per_run_max': 0.50,
    'daily_budget': 5.00,
}

DEFAULT_ROUTING: dict[str, str] = {
    'deterministic': 'code_only',
    'simple': 'haiku',
    'judgment': 'sonnet',
    'complex': 'opus',
}

PROVIDERS = ['auto', 'anthropic', 'openai', 'ollama']
EMBEDDINGS = ['all-MiniLM-L6-v2', 'bge-base-en-v1.5', 'ollama/all-minilm', 'none']
ROUTING_OPTIONS = ['code_only', 'haiku', 'sonnet', 'opus', 'local', 'auto']
TIERS = ['deterministic', 'simple', 'judgment', 'complex']


# ---------------------------------------------------------------------------
# TOML parsing (reuse pattern from compress/config.py)
# ---------------------------------------------------------------------------

def _load_toml_file(path: Path) -> dict:
    """Load a TOML file. Uses stdlib tomllib (Python 3.11+) or manual parser."""
    if sys.version_info >= (3, 11):
        import tomllib
        with open(path, 'rb') as f:
            return tomllib.load(f)
    else:
        return _parse_toml_minimal(path.read_text(encoding='utf-8'))


def _parse_toml_minimal(text: str) -> dict:
    """
    Minimal TOML parser. Supports:
      - [section] and [section.subsection]
      - key = value (string, bool, int, float)
      - # comments
    """
    result: dict = {}
    current: dict = result

    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith('#'):
            continue

        if line.startswith('[') and line.endswith(']'):
            section = line[1:-1].strip()
            parts = section.split('.')
            current = result
            for part in parts:
                current = current.setdefault(part, {})
            continue

        if '=' in line:
            key, _, raw_val = line.partition('=')
            key = key.strip()
            raw_val = raw_val.strip()

            # Remove inline comment
            if ' #' in raw_val:
                raw_val = raw_val[:raw_val.index(' #')].strip()

            # Parse value type
            val: Any
            if raw_val.lower() == 'true':
                val = True
            elif raw_val.lower() == 'false':
                val = False
            elif raw_val.startswith('"') or raw_val.startswith("'"):
                val = raw_val.strip('"\'')
            else:
                try:
                    val = int(raw_val)
                except ValueError:
                    try:
                        val = float(raw_val)
                    except ValueError:
                        val = raw_val

            current[key] = val

    return result


def _write_toml(data: dict, path: Path) -> None:
    """Write a nested dict as minimal TOML."""
    lines: list[str] = []

    def _write_section(d: dict, prefix: str) -> None:
        scalars = {k: v for k, v in d.items() if not isinstance(v, dict)}
        dicts = {k: v for k, v in d.items() if isinstance(v, dict)}

        if scalars:
            if prefix:
                lines.append(f'\n[{prefix}]')
            for k, v in scalars.items():
                if isinstance(v, bool):
                    lines.append(f'{k} = {"true" if v else "false"}')
                elif isinstance(v, str):
                    lines.append(f'{k} = "{v}"')
                else:
                    lines.append(f'{k} = {v}')

        for k, v in dicts.items():
            sub_prefix = f'{prefix}.{k}' if prefix else k
            _write_section(v, sub_prefix)

    _write_section(data, '')
    path.write_text('\n'.join(lines).strip() + '\n', encoding='utf-8')


# ---------------------------------------------------------------------------
# Config loading
# ---------------------------------------------------------------------------

def load_config() -> dict:
    """
    Load model config from ~/.aibrain/model.toml.
    Returns {} if no config file. Result is cached per process.
    """
    global _config_cache
    if _config_cache is not None:
        return _config_cache
    if _CONFIG_PATH.exists():
        try:
            _config_cache = _load_toml_file(_CONFIG_PATH)
        except Exception:
            _config_cache = {}
    else:
        _config_cache = {}
    return _config_cache


def _invalidate_cache() -> None:
    """Force config reload on next call."""
    global _config_cache
    _config_cache = None


def load_model_config() -> dict:
    """
    Return a flat dict with all model config values, merging:
      env vars > config file > defaults.

    Keys returned:
      provider, embedding, cost_per_run_max, daily_budget,
      routing (dict of tier -> model)

    This is the function workflow_runner.py should call.
    """
    cfg = load_config()
    model_cfg = cfg.get('model', {})

    # Env var overrides
    provider = os.environ.get('AIBRAIN_LLM_PROVIDER',
                              model_cfg.get('provider', DEFAULTS['provider']))
    embedding = os.environ.get('AIBRAIN_EMBEDDING_MODEL',
                               model_cfg.get('embedding', DEFAULTS['embedding']))

    cost_per_run_max = model_cfg.get('cost_per_run_max', DEFAULTS['cost_per_run_max'])
    daily_budget = model_cfg.get('daily_budget', DEFAULTS['daily_budget'])

    # Routing
    routing_cfg = model_cfg.get('routing', {})
    routing = {}
    for tier in TIERS:
        routing[tier] = routing_cfg.get(tier, DEFAULT_ROUTING[tier])

    return {
        'provider': provider,
        'embedding': embedding,
        'cost_per_run_max': float(cost_per_run_max),
        'daily_budget': float(daily_budget),
        'routing': routing,
    }


# ---------------------------------------------------------------------------
# Interactive menu
# ---------------------------------------------------------------------------

def _getch() -> str:
    """Read a single keypress. Delegates to shared implementation."""
    from aibrain.cli.utils import _getch as _shared_getch
    return _shared_getch()


def _render_menu(state: dict, focused: int) -> str:
    """Render the full model config menu."""
    lines = [
        '',
        '  Model Configuration  (arrows, SPACE/TAB to change, +/- on scales, ENTER save, Q quit)',
        '',
    ]

    # --- LLM Provider (radio, items 0..3) ---
    lines.append('  LLM Provider:')
    provider_descriptions = {
        'auto': 'Use best available based on API keys found',
        'anthropic': 'Anthropic only (Claude models)',
        'openai': 'OpenAI only (GPT models)',
        'ollama': 'Local only (Ollama, no API cost)',
    }
    for i, p in enumerate(PROVIDERS):
        selected = '(x)' if state['provider'] == p else '( )'
        cursor = '>' if focused == i else ' '
        lines.append(f'  {cursor} {selected} {i + 1}. {p:<12} {provider_descriptions[p]}')

    lines.append('')

    # --- Workflow routing (TAB-cycle, items 4..7) ---
    lines.append('  Workflow routing:')
    tier_descriptions = {
        'deterministic': 'no LLM, pure Python',
        'simple': 'fast + cheap',
        'judgment': 'balanced',
        'complex': 'most capable',
    }
    for j, tier in enumerate(TIERS):
        idx = 4 + j
        cursor = '>' if focused == idx else ' '
        model = state['routing'][tier]
        lines.append(f'  {cursor}   {tier:<16} [{model:<9}]   {tier_descriptions[tier]:<25} (TAB to cycle)')

    lines.append('')

    # --- Cost ceiling (scale, items 8..9) ---
    lines.append('  Cost ceiling:')
    # Item 8: per-run
    cursor8 = '>' if focused == 8 else ' '
    per_run = state['cost_per_run_max']
    bar8 = _scale_bar(per_run, 0.0, 5.0)
    lines.append(f'  {cursor8}   Per workflow run   [{bar8}]  ${per_run:.2f}   (+/- $0.05, range $0.00-$5.00)')

    # Item 9: daily
    cursor9 = '>' if focused == 9 else ' '
    daily = state['daily_budget']
    bar9 = _scale_bar(daily, 0.0, 50.0)
    lines.append(f'  {cursor9}   Daily budget       [{bar9}]  ${daily:.2f}  (+/- $0.50, range $0.00-$50.00)')

    lines.append('')

    # --- Embedding model (radio, items 10..12) ---
    lines.append('  Embedding model:')
    embedding_descriptions = {
        'all-MiniLM-L6-v2': '22MB, fast, good recall (default)',
        'bge-base-en-v1.5': '100MB, better on preference queries',
        'ollama/all-minilm': 'Via Ollama API, no pip dep, GPU-accelerated',
        'none': 'Disable vector search',
    }
    for k, emb in enumerate(EMBEDDINGS):
        idx = 10 + k
        selected = '(x)' if state['embedding'] == emb else '( )'
        cursor = '>' if focused == idx else ' '
        lines.append(f'  {cursor} {selected} {emb:<22} {embedding_descriptions[emb]}')

    lines.append('')
    lines.append('  ENTER to save  |  Q to quit')
    lines.append('')
    return '\n'.join(lines)


def _scale_bar(value: float, min_val: float, max_val: float, width: int = 10) -> str:
    """Return a visual scale bar like '====------'."""
    if max_val <= min_val:
        return '=' * width
    ratio = max(0.0, min(1.0, (value - min_val) / (max_val - min_val)))
    filled = int(round(ratio * width))
    return '=' * filled + '-' * (width - filled)


_TOTAL_ITEMS = 14  # 4 providers + 4 tiers + 2 scales + 4 embeddings


def _get_initial_state() -> dict:
    """Load current state from config (or defaults)."""
    mcfg = load_model_config()
    return {
        'provider': mcfg['provider'],
        'embedding': mcfg['embedding'],
        'cost_per_run_max': mcfg['cost_per_run_max'],
        'daily_budget': mcfg['daily_budget'],
        'routing': dict(mcfg['routing']),
    }


def _save_state(state: dict) -> None:
    """Write menu state to model.toml."""
    _CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)

    data = {
        'model': {
            'provider': state['provider'],
            'embedding': state['embedding'],
            'cost_per_run_max': state['cost_per_run_max'],
            'daily_budget': state['daily_budget'],
            'routing': dict(state['routing']),
        }
    }
    _write_toml(data, _CONFIG_PATH)
    _invalidate_cache()


def _summary_line(state: dict) -> str:
    """Build the post-save summary."""
    routing_parts = ' / '.join(
        f'{t}={state["routing"][t]}' for t in TIERS
    )
    return f'Saved. Provider: {state["provider"]}, routing: {routing_parts}.'


def interactive_menu() -> None:
    """
    Launch an interactive model config menu.

    Non-tty fallback: prints plain key=value lines to stdout.
    """
    # Non-tty fallback
    if not sys.stdout.isatty():
        mcfg = load_model_config()
        print(f'provider={mcfg["provider"]}')
        print(f'embedding={mcfg["embedding"]}')
        print(f'cost_per_run_max={mcfg["cost_per_run_max"]:.2f}')
        print(f'daily_budget={mcfg["daily_budget"]:.2f}')
        for tier in TIERS:
            print(f'routing.{tier}={mcfg["routing"][tier]}')
        return

    _invalidate_cache()
    state = _get_initial_state()
    focused = 0
    n = _TOTAL_ITEMS

    menu_text = _render_menu(state, focused)
    sys.stdout.write(menu_text)
    sys.stdout.flush()
    menu_lines = menu_text.count('\n')

    while True:
        ch = _getch()

        # ENTER — save
        if ch in ('\r', '\n'):
            sys.stdout.write('\n')
            _save_state(state)
            print(_summary_line(state))
            return

        # Q — quit without saving
        if ch in ('q', 'Q'):
            sys.stdout.write('\n')
            print('No changes.')
            return

        # Arrow keys
        if ch == '\x1b':
            try:
                next1 = _getch()
                if next1 == '[':
                    next2 = _getch()
                    if next2 == 'A':  # Up
                        focused = (focused - 1) % n
                    elif next2 == 'B':  # Down
                        focused = (focused + 1) % n
            except Exception:
                pass

        # TAB — cycle routing model (or advance focus)
        elif ch == '\t':
            if 4 <= focused <= 7:
                tier = TIERS[focused - 4]
                current = state['routing'][tier]
                idx = ROUTING_OPTIONS.index(current) if current in ROUTING_OPTIONS else 0
                state['routing'][tier] = ROUTING_OPTIONS[(idx + 1) % len(ROUTING_OPTIONS)]
            else:
                focused = (focused + 1) % n

        # SPACE — select radio / cycle routing
        elif ch == ' ':
            if 0 <= focused <= 3:
                state['provider'] = PROVIDERS[focused]
            elif 4 <= focused <= 7:
                tier = TIERS[focused - 4]
                current = state['routing'][tier]
                idx = ROUTING_OPTIONS.index(current) if current in ROUTING_OPTIONS else 0
                state['routing'][tier] = ROUTING_OPTIONS[(idx + 1) % len(ROUTING_OPTIONS)]
            elif 10 <= focused <= 13:
                state['embedding'] = EMBEDDINGS[focused - 10]

        # +/= key — increase scale value
        elif ch in ('+', '='):
            if focused == 8:
                state['cost_per_run_max'] = min(5.0, round(state['cost_per_run_max'] + 0.05, 2))
            elif focused == 9:
                state['daily_budget'] = min(50.0, round(state['daily_budget'] + 0.50, 2))

        # - key — decrease scale value
        elif ch == '-':
            if focused == 8:
                state['cost_per_run_max'] = max(0.0, round(state['cost_per_run_max'] - 0.05, 2))
            elif focused == 9:
                state['daily_budget'] = max(0.0, round(state['daily_budget'] - 0.50, 2))

        # Number keys 1-9 for quick access
        elif ch.isdigit() and ch != '0':
            idx = int(ch) - 1
            if 0 <= idx < 4:
                # Provider radio — select directly
                state['provider'] = PROVIDERS[idx]
                focused = idx
            elif idx < n:
                focused = idx

        else:
            continue

        # Redraw
        sys.stdout.write(f'\x1b[{menu_lines}A')
        new_text = _render_menu(state, focused)
        sys.stdout.write(new_text)
        sys.stdout.flush()
        menu_lines = new_text.count('\n')
