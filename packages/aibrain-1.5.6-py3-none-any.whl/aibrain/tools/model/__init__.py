"""aibrain.tools.model — LLM model routing configuration."""
