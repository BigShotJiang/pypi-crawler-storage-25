"""
aibrain.tools.sync.config — Interactive brain sync configuration menu.

Config file: ~/.aibrain/sync.toml

Provides interactive_menu() for `aibrain sync config` and
load_sync_config() for programmatic access to sync settings.

Example sync.toml:
    [sync]
    direction = "both"   # "both", "push", "pull"
    path = "/tmp/brain_sync.json"

    [sync.tables]
    memories = true
    company = true
    skills = true
    workflows = true
    config = true
    evolution = true
    knowledge_graph = true
"""
from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

_CONFIG_PATH = Path.home() / '.aibrain' / 'sync.toml'

# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------

_DIRECTIONS: list[tuple[str, str, str]] = [
    ('both', 'Push + Pull',  'Bidirectional sync'),
    ('push', 'Push only',    'Export brain to remote'),
    ('pull', 'Pull only',    'Import brain from remote'),
]

_TABLE_ITEMS: list[tuple[str, str, str]] = [
    ('memories',        'Memories',        ''),
    ('company',         'Company',         'agents, issues, goals, projects'),
    ('skills',          'Skills',          ''),
    ('workflows',       'Workflows',       ''),
    ('config',          'Config',          'scrubbed — no credentials'),
    ('evolution',       'Evolution',       'outcomes, metrics, cycles'),
    ('knowledge_graph', 'Knowledge graph', 'entities, facts, passages'),
]

_DEFAULT_DIRECTION = 'both'
_DEFAULT_PATH = '/tmp/brain_sync.json'

_TABLE_DEFAULTS: dict[str, bool] = {key: True for key, _, _ in _TABLE_ITEMS}

# Cached config — loaded once per process
_config_cache: dict | None = None


# ---------------------------------------------------------------------------
# TOML parsing (reuses compress pattern)
# ---------------------------------------------------------------------------

def _parse_toml_minimal(text: str) -> dict:
    """
    Minimal TOML parser. Supports:
      - [section] and [section.subsection]
      - key = value (string, bool, int, float)
      - # comments
    """
    result: dict = {}
    current: dict = result

    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith('#'):
            continue

        if line.startswith('[') and line.endswith(']'):
            section = line[1:-1].strip()
            parts = section.split('.')
            current = result
            for part in parts:
                current = current.setdefault(part, {})
            continue

        if '=' in line:
            key, _, raw_val = line.partition('=')
            key = key.strip()
            raw_val = raw_val.strip()

            # Remove inline comment
            if ' #' in raw_val:
                raw_val = raw_val[:raw_val.index(' #')].strip()

            # Parse value type
            if raw_val.lower() == 'true':
                val: Any = True
            elif raw_val.lower() == 'false':
                val = False
            elif raw_val.startswith('"') or raw_val.startswith("'"):
                val = raw_val.strip('"\'')
            else:
                try:
                    val = int(raw_val)
                except ValueError:
                    try:
                        val = float(raw_val)
                    except ValueError:
                        val = raw_val

            current[key] = val

    return result


def _load_toml_file(path: Path) -> dict:
    """Load a TOML file. Uses stdlib tomllib (3.11+) or minimal parser."""
    if sys.version_info >= (3, 11):
        import tomllib
        with open(path, 'rb') as f:
            return tomllib.load(f)
    else:
        return _parse_toml_minimal(path.read_text(encoding='utf-8'))


def _write_toml(data: dict, path: Path) -> None:
    """Write a nested dict as minimal TOML."""
    lines: list[str] = []

    def _write_section(d: dict, prefix: str) -> None:
        scalars = {k: v for k, v in d.items() if not isinstance(v, dict)}
        dicts = {k: v for k, v in d.items() if isinstance(v, dict)}

        if scalars:
            if prefix:
                lines.append(f'\n[{prefix}]')
            for k, v in scalars.items():
                if isinstance(v, bool):
                    lines.append(f'{k} = {"true" if v else "false"}')
                elif isinstance(v, str):
                    lines.append(f'{k} = "{v}"')
                else:
                    lines.append(f'{k} = {v}')

        for k, v in dicts.items():
            sub_prefix = f'{prefix}.{k}' if prefix else k
            _write_section(v, sub_prefix)

    _write_section(data, '')
    path.write_text('\n'.join(lines).strip() + '\n', encoding='utf-8')


# ---------------------------------------------------------------------------
# Config load / save / cache
# ---------------------------------------------------------------------------

def load_sync_config() -> dict:
    """
    Load sync config from ~/.aibrain/sync.toml.
    Returns merged config with defaults for any missing keys.
    Result is cached per process.
    """
    global _config_cache
    if _config_cache is not None:
        return _config_cache

    raw: dict = {}
    if _CONFIG_PATH.exists():
        try:
            raw = _load_toml_file(_CONFIG_PATH)
        except Exception:
            raw = {}

    sync_cfg = raw.get('sync', {})

    # Build merged config
    direction = sync_cfg.get('direction', _DEFAULT_DIRECTION)
    if direction not in ('both', 'push', 'pull'):
        direction = _DEFAULT_DIRECTION

    sync_path = sync_cfg.get('path', _DEFAULT_PATH)

    tables_cfg = sync_cfg.get('tables', {})
    tables: dict[str, bool] = {}
    for key, _, _ in _TABLE_ITEMS:
        tables[key] = tables_cfg.get(key, _TABLE_DEFAULTS[key])

    _config_cache = {
        'direction': direction,
        'path': sync_path,
        'tables': tables,
    }
    return _config_cache


def _invalidate_cache() -> None:
    """Force config reload on next call."""
    global _config_cache
    _config_cache = None


def _save_config(direction: str, tables: dict[str, bool], sync_path: str) -> None:
    """Write sync config to ~/.aibrain/sync.toml."""
    _CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)

    data: dict = {
        'sync': {
            'direction': direction,
            'path': sync_path,
            'tables': dict(tables),
        },
    }

    _write_toml(data, _CONFIG_PATH)
    _invalidate_cache()


# ---------------------------------------------------------------------------
# Status helper (for settings_menu)
# ---------------------------------------------------------------------------

def get_sync_status() -> str:
    """Return a brief status string for the master settings menu."""
    try:
        _invalidate_cache()
        cfg = load_sync_config()
        direction = cfg['direction']
        enabled = sum(1 for v in cfg['tables'].values() if v)
        total = len(cfg['tables'])
        dir_label = {'both': 'push+pull', 'push': 'push', 'pull': 'pull'}[direction]
        return f'{dir_label}, {enabled}/{total} tables'
    except Exception:
        return 'push+pull, 7/7 tables'


# ---------------------------------------------------------------------------
# Menu rendering
# ---------------------------------------------------------------------------

def _render_menu(direction: str, tables: dict[str, bool],
                 sync_path: str, focused: int) -> str:
    """Render the sync config menu to a string."""
    lines = [
        '',
        '  Brain Sync Config (SPACE to toggle, ENTER to save, Q to quit)',
        '',
        '  Sync direction:',
    ]

    idx = 0
    for i, (key, label, desc) in enumerate(_DIRECTIONS):
        marker = 'x' if direction == key else ' '  # noqa:plain-secret-comparison
        cursor = '>' if focused == idx else ' '
        lines.append(f'  {cursor} ({marker}) {idx + 1}. {label:<16} {desc}')
        idx += 1

    lines.append('')
    lines.append('  Tables to sync:')

    for key, label, desc in _TABLE_ITEMS:
        marker = 'x' if tables.get(key, True) else ' '
        cursor = '>' if focused == idx else ' '
        suffix = f'  ({desc})' if desc else ''
        lines.append(f'  {cursor} [{marker}] {idx + 1}. {label:<18}{suffix}')
        idx += 1

    lines.append('')
    lines.append('  Remote:')
    cursor = '>' if focused == idx else ' '
    lines.append(f'  {cursor} {idx + 1}. Sync path    [{sync_path}]')

    lines.append('')
    lines.append('  ENTER to save  |  Q to quit')
    lines.append('')
    return '\n'.join(lines)


# ---------------------------------------------------------------------------
# Interactive menu
# ---------------------------------------------------------------------------

_DIRECTION_COUNT = len(_DIRECTIONS)
_TABLE_COUNT = len(_TABLE_ITEMS)
_TOTAL_ITEMS = _DIRECTION_COUNT + _TABLE_COUNT + 1  # +1 for path


def _getch() -> str:
    """Delegate to shared aibrain.cli.utils._getch."""
    from aibrain.cli.utils import _getch as _shared_getch
    return _shared_getch()


def _read_line(prompt: str) -> str:
    """Read a line of input (for editing sync path)."""
    sys.stdout.write(prompt)
    sys.stdout.flush()
    return input()


def interactive_menu() -> None:
    """
    Launch an interactive menu for brain sync settings.

    Non-tty fallback: prints plain key=value lines to stdout.
    """
    # Non-tty fallback
    if not sys.stdout.isatty():
        _invalidate_cache()
        cfg = load_sync_config()
        print(f'direction={cfg["direction"]}')
        print(f'path={cfg["path"]}')
        for key, _, _ in _TABLE_ITEMS:
            enabled = cfg['tables'].get(key, True)
            print(f'tables.{key}={"enabled" if enabled else "disabled"}')
        return

    _invalidate_cache()
    cfg = load_sync_config()
    direction = cfg['direction']
    tables = dict(cfg['tables'])
    sync_path = cfg['path']
    focused = 0
    n = _TOTAL_ITEMS

    menu_text = _render_menu(direction, tables, sync_path, focused)
    sys.stdout.write(menu_text)
    sys.stdout.flush()
    menu_lines = menu_text.count('\n')

    while True:
        ch = _getch()

        # ENTER — save
        if ch in ('\r', '\n'):
            sys.stdout.write('\n')
            _save_config(direction, tables, sync_path)
            print('Saved.')
            return

        # Q — quit without saving
        if ch in ('q', 'Q'):
            sys.stdout.write('\n')
            print('No changes.')
            return

        # Number keys — jump + toggle
        if ch.isdigit():
            raw_idx = int(ch)
            # Handle "10" — peek for second digit
            if raw_idx == 1:
                # Could be 1 or 10+
                pass  # single digit handled below
            idx = raw_idx - 1
            if 0 <= idx < n:
                focused = idx
                _toggle_at(idx, direction, tables)
                # Update direction if in direction range
                if idx < _DIRECTION_COUNT:
                    direction = _DIRECTIONS[idx][0]

        # SPACE — toggle focused item
        elif ch == ' ':
            _toggle_at(focused, direction, tables)
            if focused < _DIRECTION_COUNT:
                direction = _DIRECTIONS[focused][0]

        # Arrow keys
        elif ch == '\x1b':
            try:
                next1 = _getch()
                if next1 == '[':
                    next2 = _getch()
                    if next2 == 'A':  # Up
                        focused = (focused - 1) % n
                    elif next2 == 'B':  # Down
                        focused = (focused + 1) % n
            except Exception:
                pass

        # 'e' or 'E' — edit path when focused on path item
        elif ch in ('e', 'E') and focused == n - 1:
            sys.stdout.write('\n  New sync path: ')
            sys.stdout.flush()
            try:
                new_path = input().strip()
                if new_path:
                    sync_path = new_path
            except (EOFError, KeyboardInterrupt):
                pass

        else:
            continue

        # Redraw
        sys.stdout.write(f'\x1b[{menu_lines}A')
        new_text = _render_menu(direction, tables, sync_path, focused)
        sys.stdout.write(new_text)
        sys.stdout.flush()
        menu_lines = new_text.count('\n')


def _toggle_at(idx: int, direction: str, tables: dict[str, bool]) -> None:
    """Toggle the item at the given index. Direction items are radio; table items are checkboxes."""
    if idx < _DIRECTION_COUNT:
        # Radio — handled by caller setting direction
        pass
    elif idx < _DIRECTION_COUNT + _TABLE_COUNT:
        table_idx = idx - _DIRECTION_COUNT
        key = _TABLE_ITEMS[table_idx][0]
        tables[key] = not tables[key]
    # Path item (last) — no toggle, uses 'e' to edit
