"""
aibrain.tools.learn.config — Interactive learning configuration menu.

Config file: ~/.aibrain/learn.toml

Provides interactive_menu() for `aibrain learn config` and
load_learn_config() consumed by realtime_learner.py to replace
hardcoded constants.

Defaults match the original hardcoded values in realtime_learner.py
so behaviour is unchanged until the user actively reconfigures.
"""
from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

_CONFIG_PATH = Path.home() / '.aibrain' / 'learn.toml'

# ---------------------------------------------------------------------------
# Defaults — must match realtime_learner.py hardcoded values exactly
# ---------------------------------------------------------------------------

_DEFAULTS: dict[str, Any] = {
    'min_msg_length': 40,
    'max_per_run': 10,
    'precompact_limit': 25,
    'watch_interval_min': 15,
}

_SIGNAL_DEFAULTS: dict[str, bool] = {
    'corrections': True,
    'fixes': True,
    'discoveries': True,
    'decisions': True,
    'completions': True,
}

_IMPORTANCE_DEFAULTS: dict[str, float] = {
    'corrections': 0.8,
    'fixes': 0.7,
    'discoveries': 0.7,
    'decisions': 0.6,
    'completions': 0.4,
}

# Cached config — loaded once per process
_config_cache: dict | None = None


# ---------------------------------------------------------------------------
# TOML parsing (reuse pattern from compress/config.py)
# ---------------------------------------------------------------------------

def _load_toml_file(path: Path) -> dict:
    """Load a TOML file. Uses stdlib tomllib (Python 3.11+) or manual parser."""
    if sys.version_info >= (3, 11):
        import tomllib
        with open(path, 'rb') as f:
            return tomllib.load(f)
    else:
        return _parse_toml_minimal(path.read_text(encoding='utf-8'))


def _parse_toml_minimal(text: str) -> dict:
    """Minimal TOML parser. Supports [section], [section.sub], key = value, # comments."""
    result: dict = {}
    current: dict = result

    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith('#'):
            continue

        if line.startswith('[') and line.endswith(']'):
            section = line[1:-1].strip()
            parts = section.split('.')
            current = result
            for part in parts:
                current = current.setdefault(part, {})
            continue

        if '=' in line:
            key, _, raw_val = line.partition('=')
            key = key.strip()
            raw_val = raw_val.strip()

            # Remove inline comment
            if ' #' in raw_val:
                raw_val = raw_val[:raw_val.index(' #')].strip()

            # Parse value type
            val: Any
            if raw_val.lower() == 'true':
                val = True
            elif raw_val.lower() == 'false':
                val = False
            elif raw_val.startswith('"') or raw_val.startswith("'"):
                val = raw_val.strip('"\'')
            else:
                try:
                    val = int(raw_val)
                except ValueError:
                    try:
                        val = float(raw_val)
                    except ValueError:
                        val = raw_val

            current[key] = val

    return result


def _write_toml(data: dict, path: Path) -> None:
    """Write a nested dict as minimal TOML."""
    lines: list[str] = []

    def _write_section(d: dict, prefix: str) -> None:
        scalars = {k: v for k, v in d.items() if not isinstance(v, dict)}
        dicts = {k: v for k, v in d.items() if isinstance(v, dict)}

        if scalars:
            if prefix:
                lines.append(f'\n[{prefix}]')
            for k, v in scalars.items():
                if isinstance(v, bool):
                    lines.append(f'{k} = {"true" if v else "false"}')
                elif isinstance(v, str):
                    lines.append(f'{k} = "{v}"')
                elif isinstance(v, float):
                    lines.append(f'{k} = {v}')
                else:
                    lines.append(f'{k} = {v}')

        for k, v in dicts.items():
            sub_prefix = f'{prefix}.{k}' if prefix else k
            _write_section(v, sub_prefix)

    _write_section(data, '')
    path.write_text('\n'.join(lines).strip() + '\n', encoding='utf-8')


# ---------------------------------------------------------------------------
# Public API — load_learn_config()
# ---------------------------------------------------------------------------

def load_learn_config() -> dict:
    """
    Load learning config from ~/.aibrain/learn.toml.

    Returns a flat dict with keys matching _DEFAULTS plus nested signal/importance
    dicts. If no config file exists, returns defaults. Safe to call at import time.

    Keys returned:
        min_msg_length (int), max_per_run (int), precompact_limit (int),
        watch_interval_min (int), signals (dict[str, bool]),
        importance (dict[str, float])
    """
    global _config_cache
    if _config_cache is not None:
        return _config_cache

    result: dict[str, Any] = dict(_DEFAULTS)
    result['signals'] = dict(_SIGNAL_DEFAULTS)
    result['importance'] = dict(_IMPORTANCE_DEFAULTS)

    if _CONFIG_PATH.exists():
        try:
            raw = _load_toml_file(_CONFIG_PATH)
            learn = raw.get('learn', {})

            # Scalar overrides
            for key in _DEFAULTS:
                if key in learn:
                    result[key] = learn[key]

            # Signal toggles
            sig_cfg = learn.get('signals', {})
            for key in _SIGNAL_DEFAULTS:
                if key in sig_cfg:
                    result['signals'][key] = bool(sig_cfg[key])

            # Importance weights
            imp_cfg = learn.get('importance', {})
            for key in _IMPORTANCE_DEFAULTS:
                if key in imp_cfg:
                    result['importance'][key] = float(imp_cfg[key])

        except Exception:
            pass  # Malformed config — fall back to defaults

    _config_cache = result
    return result


def _invalidate_cache() -> None:
    """Force config reload on next call."""
    global _config_cache
    _config_cache = None


# ---------------------------------------------------------------------------
# Signal type metadata (for menu display)
# ---------------------------------------------------------------------------

_SIGNAL_ITEMS: list[tuple[str, str, str]] = [
    # (key, label, description)
    ('corrections',  'Corrections',  '"was wrong", "actually", "turns out"'),
    ('fixes',        'Fixes',        '"fixed", "root cause", "resolved"'),
    ('discoveries',  'Discoveries',  '"discovered", "realized", "found that"'),
    ('decisions',    'Decisions',    '"chose", "decided", "went with"'),
    ('completions',  'Completions',  '"done", "shipped", "merged"'),
]

_SCALE_ITEMS: list[tuple[str, str, int, int, int, str]] = [
    # (key, label, step, min_val, max_val, unit)
    ('min_msg_length',    'Min message length',  5,  20,  200, 'chars'),
    ('max_per_run',       'Max per hook run',     1,   1,   50, ''),
    ('precompact_limit',  'PreCompact limit',     1,   5,  100, ''),
    ('watch_interval_min','Watch interval',        5,   5,  120, 'min'),
]


# ---------------------------------------------------------------------------
# Interactive menu
# ---------------------------------------------------------------------------

def _getch() -> str:
    """Delegate to shared aibrain.cli.utils._getch."""
    from aibrain.cli.utils import _getch as _shared_getch
    return _shared_getch()


def _render_menu(signal_states: dict[str, bool], importance: dict[str, float],
                 scale_values: dict[str, int], focused: int) -> str:
    """Render the full learn config menu."""
    lines = [
        '',
        '  Learning Config  (arrows navigate, +/- adjust, SPACE toggle, ENTER save, Q quit)',
        '',
        '  Signal types to capture:',
    ]

    idx = 0
    for key, label, desc in _SIGNAL_ITEMS:
        marker = 'x' if signal_states[key] else ' '
        cursor = '>' if focused == idx else ' '
        imp = importance[key]
        lines.append(f'  {cursor} [{marker}] {idx + 1}. {label:<14} importance {imp:.1f}   {desc}')
        idx += 1

    lines.append('')
    lines.append('  Sensitivity:')

    for key, label, step, min_val, max_val, unit in _SCALE_ITEMS:
        cursor = '>' if focused == idx else ' '
        val = scale_values[key]
        # Render scale bar (10 chars wide)
        bar_width = 10
        frac = (val - min_val) / max(max_val - min_val, 1)
        filled = max(0, min(bar_width, int(frac * bar_width + 0.5)))
        bar = '=' * filled + '-' * (bar_width - filled)
        unit_str = f' {unit}' if unit else ''
        range_str = f'(+/- {step}, range {min_val}-{max_val})'
        lines.append(f'  {cursor}   {idx + 1}. {label:<20} [{bar}]   {val}{unit_str}   {range_str}')
        idx += 1

    lines.append('')
    lines.append('  ENTER to save  |  Q to quit without saving')
    lines.append('')
    return '\n'.join(lines)


def _save_config(signal_states: dict[str, bool], importance: dict[str, float],
                 scale_values: dict[str, int]) -> None:
    """Write current menu state to ~/.aibrain/learn.toml."""
    _CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)

    data = {
        'learn': {
            **{k: v for k, v in scale_values.items()},
            'signals': dict(signal_states),
            'importance': dict(importance),
        }
    }

    _write_toml(data, _CONFIG_PATH)
    _invalidate_cache()


def interactive_menu() -> None:
    """
    Launch the interactive learning config menu.

    Non-tty fallback: prints plain key=value lines.
    """
    # Non-tty fallback
    if not sys.stdout.isatty():
        cfg = load_learn_config()
        for key in _DEFAULTS:
            print(f'{key}={cfg[key]}')
        for key in _SIGNAL_DEFAULTS:
            print(f'signals.{key}={"enabled" if cfg["signals"][key] else "disabled"}')
        for key in _IMPORTANCE_DEFAULTS:
            print(f'importance.{key}={cfg["importance"][key]}')
        return

    cfg = load_learn_config()
    signal_states = dict(cfg['signals'])
    importance = dict(cfg['importance'])
    scale_values = {k: cfg[k] for k in _DEFAULTS}

    n_signals = len(_SIGNAL_ITEMS)
    n_scales = len(_SCALE_ITEMS)
    n_total = n_signals + n_scales
    focused = 0

    # Draw initial menu
    menu_text = _render_menu(signal_states, importance, scale_values, focused)
    sys.stdout.write(menu_text)
    sys.stdout.flush()
    menu_lines = menu_text.count('\n')

    while True:
        ch = _getch()

        # ENTER — save and exit
        if ch in ('\r', '\n'):
            sys.stdout.write('\n')
            _save_config(signal_states, importance, scale_values)
            active = sum(1 for v in signal_states.values() if v)
            total = len(signal_states)
            print(f'Saved. {active} of {total} signal types active, min length {scale_values["min_msg_length"]}.')
            return

        # Q — quit without saving
        if ch in ('q', 'Q'):
            sys.stdout.write('\n')
            print('No changes.')
            return

        # Number keys 1-9
        if ch.isdigit():
            idx = int(ch) - 1
            if 0 <= idx < n_total:
                focused = idx
                if idx < n_signals:
                    # Toggle signal
                    key = _SIGNAL_ITEMS[idx][0]
                    signal_states[key] = not signal_states[key]

        # SPACE — toggle focused signal (only for signal items)
        elif ch == ' ':
            if focused < n_signals:
                key = _SIGNAL_ITEMS[focused][0]
                signal_states[key] = not signal_states[key]

        # + or = — increase scale value
        elif ch in ('+', '='):
            if focused >= n_signals:
                scale_idx = focused - n_signals
                key, _, step, min_val, max_val, _ = _SCALE_ITEMS[scale_idx]
                scale_values[key] = min(scale_values[key] + step, max_val)

        # - — decrease scale value
        elif ch == '-':
            if focused >= n_signals:
                scale_idx = focused - n_signals
                key, _, step, min_val, max_val, _ = _SCALE_ITEMS[scale_idx]
                scale_values[key] = max(scale_values[key] - step, min_val)

        # Arrow keys
        elif ch == '\x1b':
            try:
                next1 = _getch()
                if next1 == '[':
                    next2 = _getch()
                    if next2 == 'A':  # Up
                        focused = (focused - 1) % n_total
                    elif next2 == 'B':  # Down
                        focused = (focused + 1) % n_total
            except Exception:
                pass

        # Windows arrow keys (msvcrt returns special two-char sequences)
        elif ch == '\xe0' or ch == '\x00':
            try:
                next1 = _getch()
                if next1 == 'H':  # Up
                    focused = (focused - 1) % n_total
                elif next1 == 'P':  # Down
                    focused = (focused + 1) % n_total
            except Exception:
                pass

        else:
            continue

        # Redraw
        sys.stdout.write(f'\x1b[{menu_lines}A')
        new_text = _render_menu(signal_states, importance, scale_values, focused)
        sys.stdout.write(new_text)
        sys.stdout.flush()
        menu_lines = new_text.count('\n')
