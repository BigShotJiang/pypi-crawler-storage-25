# aibrain.tools.learn — Learning configuration module.
