"""
Tests for aibrain.tools.marketing.analytics -- social analytics data layer.
"""
from __future__ import annotations

import json
import sqlite3
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from aibrain.tools.marketing.analytics import (
    ensure_table,
    load_posting_log,
    sync_posts,
    update_engagement,
    get_all_analytics,
    get_platform_breakdown,
    get_top_posts,
    get_worst_posts,
    get_time_slot_analysis,
    get_content_type_analysis,
    generate_weekly_summary,
    get_connection,
)


@pytest.fixture
def db():
    """Create an in-memory DB with the social_analytics table."""
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    ensure_table(conn)
    yield conn
    conn.close()


@pytest.fixture
def sample_posts():
    """Sample posting_log entries."""
    now = datetime.now(timezone.utc)
    return [
        {
            "id": "post_001",
            "platform": "linkedin",
            "status": "posted",
            "posted_at": (now - timedelta(days=1)).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "content_file": "day1/linkedin-1.md",
            "content_summary": "Day 1 LinkedIn launch post",
            "engagement": {"impressions": 500, "likes": 25, "comments": 5, "shares": 3},
        },
        {
            "id": "post_002",
            "platform": "twitter",
            "status": "posted",
            "posted_at": (now - timedelta(days=2)).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "content_file": "day1/twitter-1.md",
            "content_summary": "Day 1 Twitter thread",
            "engagement": {"impressions": 1200, "likes": 80, "comments": 12, "shares": 20},
        },
        {
            "id": "post_003",
            "platform": "reddit",
            "status": "posted",
            "posted_at": (now - timedelta(days=3)).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "content_file": "day1/reddit-1.md",
            "content_summary": "Day 1 Reddit discussion",
            "engagement": {"impressions": 300, "likes": 10, "comments": 8, "shares": 1},
        },
        {
            "id": "post_004",
            "platform": "tiktok",
            "status": "pending",
            "content_file": "day2/tiktok-1.md",
            "content_summary": "Day 2 TikTok video",
            "engagement": {},
        },
        {
            "id": "post_005",
            "platform": "instagram",
            "status": "posted",
            "posted_at": (now - timedelta(hours=6)).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "content_file": "day2/image-post.md",
            "content_summary": "Day 2 Instagram image",
            "engagement": {"impressions": 800, "likes": 45, "comments": 3, "shares": 7},
        },
    ]


# ---------------------------------------------------------------------------
# Test: ensure_table
# ---------------------------------------------------------------------------

class TestEnsureTable:
    def test_creates_table(self):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        ensure_table(conn)
        tables = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='social_analytics'"
        ).fetchall()
        assert len(tables) == 1
        conn.close()

    def test_idempotent(self, db):
        # Call again -- should not raise
        ensure_table(db)
        tables = db.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='social_analytics'"
        ).fetchall()
        assert len(tables) == 1


# ---------------------------------------------------------------------------
# Test: sync_posts
# ---------------------------------------------------------------------------

class TestSyncPosts:
    def test_inserts_posted_items(self, db, sample_posts):
        count = sync_posts(db, sample_posts)
        # 4 posted, 1 pending -> should insert 4
        assert count == 4

    def test_skips_pending(self, db, sample_posts):
        sync_posts(db, sample_posts)
        rows = get_all_analytics(db)
        post_ids = [r["post_id"] for r in rows]
        assert "post_004" not in post_ids  # pending

    def test_idempotent_sync(self, db, sample_posts):
        first = sync_posts(db, sample_posts)
        second = sync_posts(db, sample_posts)
        assert first == 4
        assert second == 0  # all already synced

    def test_preserves_engagement_from_log(self, db, sample_posts):
        sync_posts(db, sample_posts)
        row = db.execute(
            "SELECT * FROM social_analytics WHERE post_id = 'post_002'"
        ).fetchone()
        assert row["likes"] == 80
        assert row["impressions"] == 1200

    def test_content_type_detection(self, db, sample_posts):
        sync_posts(db, sample_posts)
        # TikTok platform -> video type (but post_004 is pending, won't be synced)
        # Instagram with "image" in content_file -> image type
        row = db.execute(
            "SELECT content_type FROM social_analytics WHERE post_id = 'post_005'"
        ).fetchone()
        assert row["content_type"] == "image"


# ---------------------------------------------------------------------------
# Test: update_engagement
# ---------------------------------------------------------------------------

class TestUpdateEngagement:
    def test_updates_existing_post(self, db, sample_posts):
        sync_posts(db, sample_posts)
        result = update_engagement(db, "post_001", impressions=1000, likes=50, comments=10, shares=5)
        assert result is True
        row = db.execute(
            "SELECT * FROM social_analytics WHERE post_id = 'post_001'"
        ).fetchone()
        assert row["likes"] == 50
        assert row["impressions"] == 1000
        assert row["measured_at"] is not None

    def test_returns_false_for_missing_post(self, db):
        result = update_engagement(db, "nonexistent", likes=10)
        assert result is False


# ---------------------------------------------------------------------------
# Test: platform breakdown
# ---------------------------------------------------------------------------

class TestPlatformBreakdown:
    def test_groups_by_platform(self, db, sample_posts):
        sync_posts(db, sample_posts)
        breakdown = get_platform_breakdown(db)
        assert "linkedin" in breakdown
        assert "twitter" in breakdown
        assert breakdown["twitter"]["total_likes"] == 80


# ---------------------------------------------------------------------------
# Test: top/worst posts
# ---------------------------------------------------------------------------

class TestTopWorstPosts:
    def test_top_posts_ordered(self, db, sample_posts):
        sync_posts(db, sample_posts)
        top = get_top_posts(db, n=2, metric="likes")
        assert len(top) == 2
        assert top[0]["likes"] >= top[1]["likes"]

    def test_worst_posts_ordered(self, db, sample_posts):
        sync_posts(db, sample_posts)
        worst = get_worst_posts(db, n=2, metric="likes")
        assert len(worst) == 2
        assert worst[0]["likes"] <= worst[1]["likes"]


# ---------------------------------------------------------------------------
# Test: time slot analysis
# ---------------------------------------------------------------------------

class TestTimeSlotAnalysis:
    def test_returns_hour_data(self, db, sample_posts):
        sync_posts(db, sample_posts)
        slots = get_time_slot_analysis(db)
        # Should have at least one hour slot
        assert len(slots) > 0
        assert "hour" in slots[0]
        assert "avg_likes" in slots[0]


# ---------------------------------------------------------------------------
# Test: content type analysis
# ---------------------------------------------------------------------------

class TestContentTypeAnalysis:
    def test_returns_type_data(self, db, sample_posts):
        sync_posts(db, sample_posts)
        types = get_content_type_analysis(db)
        assert len(types) > 0
        type_names = [t["content_type"] for t in types]
        assert "text" in type_names


# ---------------------------------------------------------------------------
# Test: weekly summary
# ---------------------------------------------------------------------------

class TestWeeklySummary:
    def test_generates_summary_with_data(self, db, sample_posts):
        sync_posts(db, sample_posts)
        summary = generate_weekly_summary(db, weeks_back=1)
        assert "Social Analytics Weekly Summary" in summary
        assert "Platform Breakdown" in summary
        assert "Best Post" in summary

    def test_empty_db_returns_message(self, db):
        summary = generate_weekly_summary(db, weeks_back=1)
        assert "No posts found" in summary


# ---------------------------------------------------------------------------
# Test: load_posting_log
# ---------------------------------------------------------------------------

class TestLoadPostingLog:
    def test_loads_from_file(self, tmp_path, sample_posts):
        log_file = tmp_path / "posting_log.json"
        log_file.write_text(json.dumps(sample_posts))
        loaded = load_posting_log(log_file)
        assert len(loaded) == 5

    def test_missing_file_returns_empty(self, tmp_path):
        loaded = load_posting_log(tmp_path / "nonexistent.json")
        assert loaded == []
