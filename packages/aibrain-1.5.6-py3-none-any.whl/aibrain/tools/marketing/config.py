"""
aibrain.tools.marketing.config -- Interactive marketing stats menu.

Usage:
    aibrain marketing stats     Show top posts, platform breakdown, engagement trends

Follows the compress config interactive menu pattern.
"""
from __future__ import annotations

import sys

from aibrain.tools.marketing.analytics import (
    get_connection,
    ensure_table,
    get_all_analytics,
    get_platform_breakdown,
    get_top_posts,
    get_worst_posts,
    get_time_slot_analysis,
    get_content_type_analysis,
    generate_weekly_summary,
    sync_posts,
    load_posting_log,
)


# Menu views
_VIEWS = [
    ("Overview",          "Total posts, impressions, likes across all platforms"),
    ("Top Posts",         "Best performing posts by likes"),
    ("Worst Posts",       "Lowest performing posts"),
    ("Platform Breakdown", "Metrics grouped by platform"),
    ("Time Slots",        "Best posting times by hour"),
    ("Content Types",     "Performance by content type (text/image/video)"),
    ("Weekly Summary",    "Full weekly report (Telegram-ready)"),
    ("Sync Posts",        "Import new posts from posting_log.json"),
]


def _getch() -> str:
    """Read single keypress."""
    from aibrain.cli.utils import _getch as _shared_getch
    return _shared_getch()


def _render_menu(focused: int) -> str:
    """Render the view selector."""
    lines = [
        "",
        "  Marketing Analytics (number to view, Q to quit)",
        "",
    ]
    for i, (label, desc) in enumerate(_VIEWS):
        cursor = ">" if i == focused else " "
        lines.append(f"  {cursor} {i + 1}. {label:<20} {desc}")
    lines.append("")
    lines.append("  Press number to view  |  Q to quit")
    lines.append("")
    return "\n".join(lines)


def _show_overview(conn) -> None:
    """Print overview stats."""
    rows = get_all_analytics(conn)
    if not rows:
        print("\n  No analytics data yet. Run 'aibrain marketing stats' and select Sync Posts.\n")
        return

    total = len(rows)
    impressions = sum(r.get("impressions", 0) or 0 for r in rows)
    likes = sum(r.get("likes", 0) or 0 for r in rows)
    comments = sum(r.get("comments", 0) or 0 for r in rows)
    shares = sum(r.get("shares", 0) or 0 for r in rows)
    clicks = sum(r.get("clicks", 0) or 0 for r in rows)

    platforms = set(r["platform"] for r in rows)

    print(f"\n  === Overview ===")
    print(f"  Total posts tracked: {total}")
    print(f"  Platforms: {', '.join(sorted(platforms))}")
    print(f"  Impressions: {impressions:,}")
    print(f"  Likes: {likes:,}")
    print(f"  Comments: {comments:,}")
    print(f"  Shares: {shares:,}")
    print(f"  Clicks: {clicks:,}")
    if total > 0:
        print(f"  Avg likes/post: {likes / total:.1f}")
    print()


def _show_top_posts(conn) -> None:
    """Print top 5 posts."""
    posts = get_top_posts(conn, n=5, metric="likes")
    if not posts:
        print("\n  No posts with engagement data.\n")
        return
    print(f"\n  === Top 5 Posts (by likes) ===")
    for i, p in enumerate(posts, 1):
        print(f"  {i}. [{p['platform']}] {(p.get('content_summary') or 'N/A')[:50]}")
        print(f"     Likes: {p.get('likes', 0)}  Comments: {p.get('comments', 0)}  "
              f"Shares: {p.get('shares', 0)}  Impressions: {p.get('impressions', 0)}")
    print()


def _show_worst_posts(conn) -> None:
    """Print worst 5 posts."""
    posts = get_worst_posts(conn, n=5, metric="likes")
    if not posts:
        print("\n  No posts with engagement data.\n")
        return
    print(f"\n  === Worst 5 Posts (by likes) ===")
    for i, p in enumerate(posts, 1):
        print(f"  {i}. [{p['platform']}] {(p.get('content_summary') or 'N/A')[:50]}")
        print(f"     Likes: {p.get('likes', 0)}  Comments: {p.get('comments', 0)}  "
              f"Shares: {p.get('shares', 0)}  Impressions: {p.get('impressions', 0)}")
    print()


def _show_platform_breakdown(conn) -> None:
    """Print platform breakdown."""
    breakdown = get_platform_breakdown(conn)
    if not breakdown:
        print("\n  No platform data.\n")
        return
    print(f"\n  === Platform Breakdown ===")
    print(f"  {'Platform':<12} {'Posts':>6} {'Impressions':>12} {'Likes':>8} {'Comments':>10} {'Shares':>8}")
    print(f"  {'-' * 58}")
    for plat, data in breakdown.items():
        print(f"  {plat:<12} {data['post_count']:>6} {data['total_impressions'] or 0:>12,} "
              f"{data['total_likes'] or 0:>8,} {data['total_comments'] or 0:>10,} {data['total_shares'] or 0:>8,}")
    print()


def _show_time_slots(conn) -> None:
    """Print time slot analysis."""
    slots = get_time_slot_analysis(conn)
    if not slots:
        print("\n  No time slot data (need posted_at timestamps).\n")
        return
    print(f"\n  === Best Time Slots (by avg likes) ===")
    print(f"  {'Hour':>6} {'Posts':>6} {'Avg Imp':>10} {'Avg Likes':>10} {'Avg Cmts':>10}")
    print(f"  {'-' * 44}")
    for s in slots:
        print(f"  {s['hour']:>4}:00 {s['post_count']:>6} {s['avg_impressions'] or 0:>10.0f} "
              f"{s['avg_likes'] or 0:>10.1f} {s['avg_comments'] or 0:>10.1f}")
    print()


def _show_content_types(conn) -> None:
    """Print content type analysis."""
    types = get_content_type_analysis(conn)
    if not types:
        print("\n  No content type data.\n")
        return
    print(f"\n  === Content Type Analysis ===")
    print(f"  {'Type':<10} {'Posts':>6} {'Avg Imp':>10} {'Avg Likes':>10} {'Avg Cmts':>10} {'Avg Shares':>11}")
    print(f"  {'-' * 59}")
    for t in types:
        print(f"  {(t['content_type'] or 'unknown'):<10} {t['post_count']:>6} "
              f"{t['avg_impressions'] or 0:>10.0f} {t['avg_likes'] or 0:>10.1f} "
              f"{t['avg_comments'] or 0:>10.1f} {t['avg_shares'] or 0:>11.1f}")
    print()


def _show_weekly_summary(conn) -> None:
    """Print weekly summary."""
    summary = generate_weekly_summary(conn)
    print(f"\n{summary}\n")


def _do_sync(conn) -> None:
    """Sync posts from posting_log.json."""
    posts = load_posting_log()
    if not posts:
        print("\n  No posting_log.json found or empty.\n")
        return
    count = sync_posts(conn, posts)
    total = len(get_all_analytics(conn))
    print(f"\n  Synced {count} new posts. Total tracked: {total}.\n")


_HANDLERS = [
    _show_overview,
    _show_top_posts,
    _show_worst_posts,
    _show_platform_breakdown,
    _show_time_slots,
    _show_content_types,
    _show_weekly_summary,
    _do_sync,
]


def interactive_menu() -> None:
    """
    Launch interactive marketing stats menu.

    Non-tty fallback: prints overview to stdout.
    """
    conn = get_connection()
    ensure_table(conn)

    if not sys.stdout.isatty():
        _show_overview(conn)
        conn.close()
        return

    focused = 0
    n = len(_VIEWS)

    menu_text = _render_menu(focused)
    sys.stdout.write(menu_text)
    sys.stdout.flush()
    menu_lines = menu_text.count("\n")

    while True:
        ch = _getch()

        if ch in ("q", "Q"):
            sys.stdout.write("\n")
            conn.close()
            return

        if ch.isdigit():
            idx = int(ch) - 1
            if 0 <= idx < n:
                focused = idx
                # Clear menu area and show the view
                sys.stdout.write("\n")
                _HANDLERS[idx](conn)

                # Redraw menu
                menu_text = _render_menu(focused)
                sys.stdout.write(menu_text)
                sys.stdout.flush()
                menu_lines = menu_text.count("\n")
                continue

        # Enter key
        if ch in ("\r", "\n"):
            sys.stdout.write("\n")
            _HANDLERS[focused](conn)

            menu_text = _render_menu(focused)
            sys.stdout.write(menu_text)
            sys.stdout.flush()
            menu_lines = menu_text.count("\n")
            continue

        # Arrow keys
        if ch == "\x1b":
            try:
                next1 = _getch()
                if next1 == "[":
                    next2 = _getch()
                    if next2 == "A":  # Up
                        focused = (focused - 1) % n
                    elif next2 == "B":  # Down
                        focused = (focused + 1) % n
            except Exception:
                pass

            # Redraw
            sys.stdout.write(f"\x1b[{menu_lines}A")
            menu_text = _render_menu(focused)
            sys.stdout.write(menu_text)
            sys.stdout.flush()
            menu_lines = menu_text.count("\n")


def stats_cli(args: list[str] | None = None) -> None:
    """
    CLI entry for `aibrain marketing stats`.
    With --summary flag, prints plain text summary (non-interactive).
    """
    args = args or []
    if "--summary" in args:
        conn = get_connection()
        ensure_table(conn)
        print(generate_weekly_summary(conn))
        conn.close()
    elif "--sync" in args:
        conn = get_connection()
        ensure_table(conn)
        _do_sync(conn)
        conn.close()
    else:
        interactive_menu()
