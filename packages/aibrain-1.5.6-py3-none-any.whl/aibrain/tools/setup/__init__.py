# aibrain.tools.setup — Setup reconfiguration interactive menu.
