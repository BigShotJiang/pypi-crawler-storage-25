"""
aibrain.tools.setup.reconfigure -- Interactive setup reconfiguration menu.

Entry point: `aibrain setup --reconfigure`

Provides a radio-style section picker for the 9 configuration areas.
Each section opens its own sub-prompt (reusing the setup_wizard interview
functions) then returns to the top-level menu.

Changes are staged in memory until ENTER at the top level, which writes
them to config.json in one shot. No DB init or dep checks run unless
the user explicitly picks option 0 (full validation).

Navigation:
  Number key   -- open that section's sub-prompt
  Arrow keys   -- move focus
  ENTER        -- save all staged changes to config.json
  Q / ESC      -- quit without saving
"""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

from aibrain.cli.utils import _getch


# ---------------------------------------------------------------------------
# Config I/O
# ---------------------------------------------------------------------------

def _config_path() -> Path:
    """Return the path to config.json (respects AIBRAIN_ROOT)."""
    import os
    root = Path(os.environ.get("AIBRAIN_ROOT", Path(__file__).resolve().parent.parent.parent.parent))
    return root / "config.json"


def _load_config() -> dict:
    """Load config.json. Returns {} if missing or corrupt."""
    p = _config_path()
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass
    return {}


def _save_config(cfg: dict) -> None:
    """Write config.json atomically."""
    p = _config_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(cfg, indent=2), encoding="utf-8")


# ---------------------------------------------------------------------------
# Section status detection
# ---------------------------------------------------------------------------

def _mask(value: str | Any) -> str:
    """Mask a secret value for display."""
    if not value or not isinstance(value, str):
        return ""
    if len(value) > 8:
        return value[:4] + "..." + value[-4:]
    return value[:3] + "..."


def _check_tailscale() -> bool:
    """Return True if Tailscale is connected."""
    try:
        from aibrain_networking import is_tailscale_installed, is_tailscale_ready
        return is_tailscale_installed() and is_tailscale_ready()
    except Exception:
        return False


def _section_status(cfg: dict) -> dict[str, bool]:
    """Return configured/not-configured state for each section."""
    return {
        "identity": bool(cfg.get("agent_name")),
        "ai_provider": bool(cfg.get("anthropic_api_key") or cfg.get("openai_api_key")),
        "email": bool(cfg.get("agent_email")),
        "github": bool(cfg.get("github_token")),
        "telegram": bool(cfg.get("telegram_bot_token")),
        "ollama": bool(cfg.get("ollama_url")),
        "networking": _check_tailscale() or bool(cfg.get("peer_url")),
        "workflows": True,   # always has defaults
        "satellites": True,   # always has defaults
    }


def _section_summary(cfg: dict) -> dict[str, str]:
    """Return a one-line summary string for each section."""
    summaries: dict[str, str] = {}

    name = cfg.get("agent_name", "")
    loc = cfg.get("location_name", "")
    summaries["identity"] = f"{name}  |  {loc}" if name and loc else (name or "Not configured")

    # AI provider
    providers = []
    if cfg.get("anthropic_api_key"):
        providers.append("Anthropic")
    if cfg.get("openai_api_key"):
        providers.append("OpenAI")
    if providers:
        summaries["ai_provider"] = ", ".join(providers) + "  |  API key: set"
    else:
        summaries["ai_provider"] = "Not configured"

    summaries["email"] = cfg.get("agent_email", "Not configured") or "Not configured"

    if cfg.get("github_token"):
        user = cfg.get("github_username", "configured")
        summaries["github"] = f"Token set  |  user: {user}"
    else:
        summaries["github"] = "Not configured"

    if cfg.get("telegram_bot_token"):
        chat = cfg.get("telegram_chat_id", "")
        summaries["telegram"] = f"Token set" + (f"  |  chat: {chat}" if chat else "")
    else:
        summaries["telegram"] = "Not configured"

    if cfg.get("ollama_url"):
        model = cfg.get("ollama_model", "")
        summaries["ollama"] = f"{cfg['ollama_url']}" + (f"  |  {model}" if model else "")
    else:
        summaries["ollama"] = "Not configured"

    if _check_tailscale():
        summaries["networking"] = "Tailscale connected"
    elif cfg.get("peer_url"):
        summaries["networking"] = f"Manual peer: {cfg['peer_url']}"
    else:
        summaries["networking"] = "Not configured"

    summaries["workflows"] = "Use aibrain workflows config"
    summaries["satellites"] = "Use aibrain brain stats"

    return summaries


# ---------------------------------------------------------------------------
# Section definitions
# ---------------------------------------------------------------------------

# (key, label) -- order matters for rendering
SECTIONS = [
    ("identity", "Identity"),
    ("ai_provider", "AI Provider"),
    ("email", "Email"),
    ("github", "GitHub"),
    ("telegram", "Telegram"),
    ("ollama", "Ollama"),
    ("networking", "Networking"),
    ("workflows", "Workflows"),
    ("satellites", "Satellites"),
]


# ---------------------------------------------------------------------------
# Section sub-prompts -- each returns updated cfg dict (or unchanged)
# ---------------------------------------------------------------------------

def _prompt(label: str, default: str = "", password: bool = False) -> str:
    """Simple line prompt. Blank input returns default."""
    suffix = f" [{default}]" if default else ""
    try:
        if password:
            try:
                import getpass
                value = getpass.getpass(f"  {label}{suffix}: ")
            except Exception:
                value = input(f"  {label}{suffix}: ")
        else:
            value = input(f"  {label}{suffix}: ")
        return value.strip() or default
    except (EOFError, KeyboardInterrupt):
        print()
        return default


def _configure_identity(cfg: dict) -> dict:
    """Configure agent name and location."""
    print("\n  --- Identity ---")
    import os
    _default = os.environ.get("AGENT_ID", "Agent")
    cfg["agent_name"] = _prompt("Agent name", cfg.get("agent_name", _default))

    city = _prompt("City name (for weather/context, blank to skip)", cfg.get("location_name", ""))
    if city:
        cfg["location_name"] = city
        # Try geocode
        try:
            import urllib.request
            import urllib.parse
            url = f"https://geocoding-api.open-meteo.com/v1/search?name={urllib.parse.quote(city)}&count=1&language=en"
            req = urllib.request.Request(url, headers={"User-Agent": "AIBrain-Setup/1.0"})
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode())
                if data.get("results"):
                    r = data["results"][0]
                    cfg["location_lat"] = r["latitude"]
                    cfg["location_lon"] = r["longitude"]
                    print(f"  Location: {r.get('name', city)} ({r['latitude']}, {r['longitude']})")
        except Exception:
            pass
    return cfg


def _configure_ai_provider(cfg: dict) -> dict:
    """Configure Anthropic and/or OpenAI API keys."""
    print("\n  --- AI Provider ---")
    key = _prompt("Anthropic API key (blank to keep current)",
                  cfg.get("anthropic_api_key", ""), password=True)
    if key:
        cfg["anthropic_api_key"] = key

    key = _prompt("OpenAI API key (blank to keep current)",
                  cfg.get("openai_api_key", ""), password=True)
    if key:
        cfg["openai_api_key"] = key
    return cfg


def _configure_email(cfg: dict) -> dict:
    """Configure email settings."""
    print("\n  --- Email ---")
    email = _prompt("Gmail address", cfg.get("agent_email", ""))
    if email:
        cfg["agent_email"] = email
        cfg["email_to"] = email
        cfg["agent_smtp_host"] = "smtp.gmail.com"
        cfg["agent_imap_host"] = "imap.gmail.com"
        pw = _prompt("App password (blank to keep current)",
                     cfg.get("agent_email_password", ""), password=True)
        if pw:
            cfg["agent_email_password"] = pw.replace(" ", "")
    return cfg


def _configure_github(cfg: dict) -> dict:
    """Configure GitHub token."""
    print("\n  --- GitHub ---")
    token = _prompt("GitHub token (blank to keep current)",
                    cfg.get("github_token", ""), password=True)
    if token:
        cfg["github_token"] = token
    user = _prompt("GitHub username", cfg.get("github_username", ""))
    if user:
        cfg["github_username"] = user
    return cfg


def _configure_telegram(cfg: dict) -> dict:
    """Configure Telegram bot."""
    print("\n  --- Telegram ---")
    token = _prompt("Telegram bot token (blank to keep current)",
                    cfg.get("telegram_bot_token", ""), password=True)
    if token:
        cfg["telegram_bot_token"] = token
    chat = _prompt("Telegram chat ID", cfg.get("telegram_chat_id", ""))
    if chat:
        cfg["telegram_chat_id"] = chat
    return cfg


def _configure_ollama(cfg: dict) -> dict:
    """Configure Ollama local LLM."""
    print("\n  --- Ollama ---")
    url = _prompt("Ollama URL (e.g. http://localhost:11434)", cfg.get("ollama_url", ""))
    if url:
        cfg["ollama_url"] = url
        model = _prompt("Ollama model", cfg.get("ollama_model", "llama3.2"))
        cfg["ollama_model"] = model
    return cfg


def _configure_networking(cfg: dict) -> dict:
    """Configure networking / peer connection."""
    print("\n  --- Networking ---")
    print("  Tailscale is configured outside AIBrain (tailscale up).")
    peer = _prompt("Manual peer URL (e.g. http://192.168.1.x:7800)", cfg.get("peer_url", ""))
    if peer:
        cfg["peer_url"] = peer
        name = _prompt("Peer agent name", cfg.get("peer_name", ""))
        if name:
            cfg["peer_name"] = name
    return cfg


def _configure_workflows(cfg: dict) -> dict:
    """Delegate to the workflows config menu if available."""
    print("\n  --- Workflows ---")
    try:
        from aibrain.tools.workflows.config import interactive_menu
        interactive_menu()
    except ImportError:
        print("  Workflow config not yet available.")
        print("  Use: aibrain workflows enable/disable <name>")
    return cfg


def _configure_satellites(cfg: dict) -> dict:
    """Show satellite info."""
    print("\n  --- Satellites ---")
    print("  Satellite databases are managed via:")
    print("    aibrain brain stats    -- view satellites")
    print("    python aibrain_db.py satellite register -- add new")
    return cfg


def _run_full_validation(cfg: dict) -> dict:
    """Run DB init, dep checks, connectivity tests."""
    print("\n  --- Full Validation ---")
    print("  Running connectivity checks...")
    try:
        from setup_wizard import test_connectivity
        progress = {"config": cfg, "completed_steps": []}
        test_connectivity(progress)
    except Exception as e:
        print(f"  Validation error: {e}")
    return cfg


# Map section keys to configure functions
SECTION_HANDLERS: dict[str, Any] = {
    "identity": _configure_identity,
    "ai_provider": _configure_ai_provider,
    "email": _configure_email,
    "github": _configure_github,
    "telegram": _configure_telegram,
    "ollama": _configure_ollama,
    "networking": _configure_networking,
    "workflows": _configure_workflows,
    "satellites": _configure_satellites,
}


# ---------------------------------------------------------------------------
# Rendering
# ---------------------------------------------------------------------------

def _status_char(is_configured: bool) -> str:
    """Return [x] or [ ] status indicator."""
    return "x" if is_configured else " "


def _render_menu(cfg: dict, focused: int, staged_dirty: bool) -> str:
    """Render the reconfigure top-level menu."""
    status = _section_status(cfg)
    summaries = _section_summary(cfg)

    lines = [
        "",
        "  AIBrain Reconfigure  (number to open section, ENTER to save all pending, Q to quit)",
        "",
        "  Configuration status:",
    ]

    for i, (key, label) in enumerate(SECTIONS):
        cursor = ">" if i == focused else " "
        marker = _status_char(status.get(key, False))
        summary = summaries.get(key, "")
        lines.append(f"  {cursor} [{marker}] {i + 1}. {label:<14} {summary}")

    lines.append("")
    lines.append("    0. Run full validation (DB init, connectivity tests)")
    lines.append("")
    if staged_dirty:
        lines.append("  Changes staged. Press ENTER to save, Q to discard.")
    else:
        lines.append("  Press a number to open that section. ENTER to save. Q to quit.")
    lines.append("")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def interactive_menu() -> None:
    """
    Launch the interactive reconfigure menu.

    Non-tty fallback: prints section statuses as key=value.
    """
    cfg = _load_config()

    # Non-tty fallback
    if not sys.stdout.isatty():
        status = _section_status(cfg)
        summaries = _section_summary(cfg)
        for key, label in SECTIONS:
            configured = "configured" if status.get(key, False) else "not_configured"
            print(f"{key}={configured}  # {summaries.get(key, '')}")
        return

    # Keep a copy to detect changes
    original_json = json.dumps(cfg, sort_keys=True)
    focused = 0
    n = len(SECTIONS)

    def _is_dirty() -> bool:
        return json.dumps(cfg, sort_keys=True) != original_json

    # Initial draw
    menu_text = _render_menu(cfg, focused, _is_dirty())
    sys.stdout.write(menu_text)
    sys.stdout.flush()
    menu_lines = menu_text.count("\n")

    while True:
        ch = _getch()

        # Q -- quit without saving
        if ch in ("q", "Q"):
            sys.stdout.write("\n")
            if _is_dirty():
                print("  Discarded unsaved changes.")
            else:
                print("  No changes.")
            return

        # ESC -- may be arrow key or plain ESC
        if ch == "\x1b":
            try:
                next1 = _getch()
                if next1 == "[":
                    next2 = _getch()
                    if next2 == "A":  # Up
                        focused = (focused - 1) % n
                    elif next2 == "B":  # Down
                        focused = (focused + 1) % n
                    # Redraw
                    sys.stdout.write(f"\x1b[{menu_lines}A")
                    new_text = _render_menu(cfg, focused, _is_dirty())
                    sys.stdout.write(new_text)
                    sys.stdout.flush()
                    menu_lines = new_text.count("\n")
                    continue
            except Exception:
                pass
            # Plain ESC = quit
            sys.stdout.write("\n")
            if _is_dirty():
                print("  Discarded unsaved changes.")
            else:
                print("  No changes.")
            return

        # ENTER -- save staged changes
        if ch in ("\r", "\n"):
            sys.stdout.write("\n")
            if _is_dirty():
                _save_config(cfg)
                print(f"  Saved to {_config_path()}")
            else:
                print("  No changes to save.")
            return

        # Number keys 0-9
        if ch == "0":
            # Full validation
            sys.stdout.write("\n")
            _run_full_validation(cfg)
            # Redraw
            menu_text = _render_menu(cfg, focused, _is_dirty())
            sys.stdout.write(menu_text)
            sys.stdout.flush()
            menu_lines = menu_text.count("\n")
            continue

        if ch.isdigit():
            idx = int(ch) - 1
            if 0 <= idx < n:
                focused = idx
                key, _ = SECTIONS[idx]
                handler = SECTION_HANDLERS.get(key)
                if handler:
                    sys.stdout.write("\n")
                    sys.stdout.flush()
                    cfg = handler(cfg)
                # Redraw
                menu_text = _render_menu(cfg, focused, _is_dirty())
                sys.stdout.write(menu_text)
                sys.stdout.flush()
                menu_lines = menu_text.count("\n")
                continue

        # Any other key -- just redraw (focus may have changed)
        sys.stdout.write(f"\x1b[{menu_lines}A")
        new_text = _render_menu(cfg, focused, _is_dirty())
        sys.stdout.write(new_text)
        sys.stdout.flush()
        menu_lines = new_text.count("\n")
