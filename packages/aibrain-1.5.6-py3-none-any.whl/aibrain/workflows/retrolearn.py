"""
retrolearn.py — Backfill evolution_outcomes from unlinked honest execution_log rows.

The problem: execution_log rows with honest quality_score values but no entity_id
linkage are invisible to the evolution engine. This workflow creates an
evolution_outcomes entry for each eligible row so the pattern detector can see them.

Eligibility criteria:
  - entity_id IS NULL OR entity_id = ''  (no task linkage)
  - created_at >= cutoff_date            (post-honest-rubric era, default 2026-04-10)
  - quality_score IS NOT NULL            (honest score present)
  - NOT already in evolution_outcomes WHERE source='retrolearn' AND source_id=str(row.id)

Safe to re-run: idempotent via the source='retrolearn' + source_id dedup check.
"""

import json
import os
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from aibrain.core.workflow_base import workflow_execute

# ---------------------------------------------------------------------------
# DB path — use canonical AIBRAIN_ROOT resolver, not a hardcoded path.
# Every module that opens aibrain.db MUST go through aibrain_db.AIBRAIN_ROOT
# per the pre-commit linter rule (split-brain prevention).
# ---------------------------------------------------------------------------
try:
    from aibrain_db import AIBRAIN_ROOT
    _DB_PATH = str(AIBRAIN_ROOT / "aibrain.db")
except ImportError:
    _DB_PATH = os.environ.get("AIBRAIN_DB_PATH", str(Path.home() / "projects" / "aibrain" / "aibrain.db"))


def _get_con() -> sqlite3.Connection:
    con = sqlite3.connect(_DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")
    return con


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def get_retrolearn_stats(cutoff_date: str = '2026-04-10') -> dict:
    """
    Returns counts of eligible, already-processed, and remaining rows.

    Returns:
        {eligible: N, already_processed: N, remaining: N}
    """
    con = _get_con()
    try:
        eligible = con.execute(
            """
            SELECT COUNT(*) FROM execution_log
            WHERE (entity_id IS NULL OR entity_id = '')
              AND created_at >= ?
              AND quality_score IS NOT NULL
            """,
            (cutoff_date,),
        ).fetchone()[0]

        already_processed = con.execute(
            "SELECT COUNT(*) FROM evolution_outcomes WHERE source = 'retrolearn'",
        ).fetchone()[0]

        # Remaining = eligible rows not yet backfilled.
        # Cross-reference via source_id to handle partial prior runs.
        remaining = con.execute(
            """
            SELECT COUNT(*) FROM execution_log el
            WHERE (el.entity_id IS NULL OR el.entity_id = '')
              AND el.created_at >= ?
              AND el.quality_score IS NOT NULL
              AND NOT EXISTS (
                  SELECT 1 FROM evolution_outcomes eo
                  WHERE eo.source = 'retrolearn'
                    AND eo.source_id = CAST(el.id AS TEXT)
              )
            """,
            (cutoff_date,),
        ).fetchone()[0]

        return {
            "eligible": eligible,
            "already_processed": already_processed,
            "remaining": remaining,
        }
    finally:
        con.close()


def run_retrolearn(
    cutoff_date: str = '2026-04-10',
    dry_run: bool = False,
    batch_size: int = 200,
) -> dict:
    """
    Backfill evolution_outcomes from unlinked honest execution_log rows.

    For each eligible execution_log row NOT already backfilled:
      - source        = 'retrolearn'
      - source_id     = str(row.id)
      - action        = row.action
      - result        = 'succeeded' if quality_score >= 0.5 else 'failed'
      - details       = JSON with quality_score, actor, task_type, model_used, original_log_id
      - failure_reason = 'quality below threshold' if failed, else None

    Args:
        cutoff_date: ISO date string — only rows on/after this date are eligible.
        dry_run: If True, count eligible rows but write nothing.
        batch_size: Max rows to process per run (default 200).

    Returns:
        {processed: N, skipped_existing: N, succeeded: N, failed: N, dry_run: bool}
    """
    con = _get_con()
    processed = 0
    skipped_existing = 0
    succeeded = 0
    failed = 0
    now_iso = datetime.now(timezone.utc).isoformat()

    try:
        rows = con.execute(
            """
            SELECT el.id, el.action, el.quality_score, el.actor,
                   el.task_type, el.model_used
            FROM execution_log el
            WHERE (el.entity_id IS NULL OR el.entity_id = '')
              AND el.created_at >= ?
              AND el.quality_score IS NOT NULL
              AND NOT EXISTS (
                  SELECT 1 FROM evolution_outcomes eo
                  WHERE eo.source = 'retrolearn'
                    AND eo.source_id = CAST(el.id AS TEXT)
              )
            ORDER BY el.created_at ASC
            LIMIT ?
            """,
            (cutoff_date, batch_size),
        ).fetchall()

        for row in rows:
            result = 'succeeded' if row['quality_score'] >= 0.5 else 'failed'
            failure_reason = 'quality below threshold' if result == 'failed' else None
            details = json.dumps({
                'quality_score': row['quality_score'],
                'actor': row['actor'],
                'task_type': row['task_type'],
                'model_used': row['model_used'],
                'original_log_id': row['id'],
            })

            if dry_run:
                # Count without writing
                processed += 1
                if result == 'succeeded':
                    succeeded += 1
                else:
                    failed += 1
                continue

            try:
                con.execute(
                    """
                    INSERT INTO evolution_outcomes
                        (source, source_id, action, result, details, failure_reason, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        'retrolearn',
                        str(row['id']),
                        row['action'],
                        result,
                        details,
                        failure_reason,
                        now_iso,
                    ),
                )
                processed += 1
                if result == 'succeeded':
                    succeeded += 1
                else:
                    failed += 1
            except sqlite3.IntegrityError:
                # Race condition — another process inserted this row first
                skipped_existing += 1

        if not dry_run:
            con.commit()

    finally:
        con.close()

    return {
        'processed': processed,
        'skipped_existing': skipped_existing,
        'succeeded': succeeded,
        'failed': failed,
        'dry_run': dry_run,
    }


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def _main() -> int:
    import argparse

    parser = argparse.ArgumentParser(
        description="Backfill evolution_outcomes from unlinked honest execution_log rows."
    )
    parser.add_argument('--dry-run', action='store_true', help='Count but do not write')
    parser.add_argument('--cutoff', default='2026-04-10', help='ISO date cutoff (default: 2026-04-10)')
    parser.add_argument('--batch-size', type=int, default=200, help='Max rows per run (default: 200)')
    args = parser.parse_args()

    stats = get_retrolearn_stats(args.cutoff)
    print(
        f"Eligible: {stats['eligible']} | "
        f"Already processed: {stats['already_processed']} | "
        f"Remaining: {stats['remaining']}"
    )

    result = run_retrolearn(args.cutoff, dry_run=args.dry_run, batch_size=args.batch_size)
    print(result)
    return 0


if __name__ == '__main__':
    workflow_execute(
        workflow_name="retrolearn",
        action=_main,
        task_type="deterministic",
        actor="cli",
    )
