"""
task_router.py — Universal classify → route → execute pipeline for AIBrain.

Generalizes the selective routing pattern proven in LongMemEval (Ra@5=0.789)
to all work domains: memory, security, jobs, content, email, automation.

The insight: selective routing beats uniform strategy by 15-20% across every
domain tested. The same classify → route → execute pattern works whether
you're retrieving memories, scanning vulnerabilities, or publishing content.

Usage:
    from task_router import TaskRouter

    router = TaskRouter()
    result = await router.execute("scan target_app for SQL injection")
    # -> classifies as (security, scan) -> dispatches to reactive_engine

    result = await router.execute({"domain": "jobs", "action": "search",
                                    "params": {"location": "Remote"}})
    # -> routes to job_pipeline graph

Architecture:
    TaskRouter
      classify(task) -> TaskType        # keyword rules, LLM fallback
      route(task_type) -> Strategy      # lookup table (data, not code)
      execute(task, strategy) -> Result # dispatch to backend adapter
"""

import asyncio
import json
import logging
import os
import sqlite3
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Optional, Protocol
from uuid import uuid4

log = logging.getLogger("task_router")

# ---------------------------------------------------------------------------
# Portable path resolution
# ---------------------------------------------------------------------------
AIBRAIN_ROOT = Path(os.environ.get("AIBRAIN_ROOT", Path(__file__).parent))
_HOME = Path.home()


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class TaskType:
    """Classification result — what kind of work is this?"""
    domain: str = "general"      # memory, security, jobs, content, email, automation, trading
    action: str = "execute"      # search, scan, apply, publish, triage, deploy, trade, etc.
    complexity: str = "simple"   # simple, complex, reactive
    confidence: float = 1.0      # 0.0-1.0, how sure the classifier is
    metadata: dict = field(default_factory=dict)

    @property
    def key(self) -> str:
        return f"{self.domain}.{self.action}"


@dataclass
class ExecutionStrategy:
    """How to execute — which backend, specialist agent, and tool chain."""
    name: str = ""
    backend: str = "direct"       # reactive_engine, durable_workflow, direct,
                                  # mcp_tool, playwright, n8n, cli
    graph_name: str = ""          # for reactive_engine: which graph
    tool_chain: list = field(default_factory=list)  # ordered tools/steps
    params: dict = field(default_factory=dict)
    fallback: str = ""            # fallback strategy name if primary fails
    timeout_s: float = 300.0      # max execution time
    # Specialist routing
    agent: str = ""               # subagent prompt file (e.g. "pixel_agent.md")
    mcp_tools: list = field(default_factory=list)  # MCP tools to use (canva, indeed, etc.)

    @property
    def key(self) -> str:
        return self.name or f"{self.backend}:{self.graph_name or ','.join(self.tool_chain)}"


@dataclass
class TaskResult:
    """Execution outcome."""
    success: bool = False
    output: Any = None
    error: str = ""
    confidence: float = 1.0
    duration_s: float = 0.0
    backend_used: str = ""
    strategy_key: str = ""
    task_type_key: str = ""
    needs_escalation: bool = False
    trace_id: str = field(default_factory=lambda: str(uuid4()))


# ---------------------------------------------------------------------------
# Backend adapter protocol
# ---------------------------------------------------------------------------

class BackendAdapter(Protocol):
    """Interface for execution backends."""
    async def run(self, task: dict, strategy: ExecutionStrategy) -> TaskResult: ...


# ---------------------------------------------------------------------------
# Built-in backend adapters
# ---------------------------------------------------------------------------

class DirectBackend:
    """Call registered Python functions directly. Simplest backend."""

    def __init__(self):
        self._handlers: dict[str, Callable] = {}

    def register(self, name: str, fn: Callable):
        self._handlers[name] = fn

    async def run(self, task: dict, strategy: ExecutionStrategy) -> TaskResult:
        results = []
        for tool_name in strategy.tool_chain:
            handler = self._handlers.get(tool_name)
            if not handler:
                return TaskResult(success=False, error=f"No handler: {tool_name}",
                                  backend_used="direct")
            try:
                if asyncio.iscoroutinefunction(handler):
                    result = await handler(task, strategy.params)
                else:
                    result = handler(task, strategy.params)
                results.append(result)
            except Exception as e:
                return TaskResult(success=False, error=str(e), backend_used="direct")

        return TaskResult(success=True, output=results[-1] if results else None,
                          backend_used="direct")


class CLIBackend:
    """Run shell commands / Python scripts via subprocess."""

    async def run(self, task: dict, strategy: ExecutionStrategy) -> TaskResult:
        import subprocess
        outputs = []
        for cmd in strategy.tool_chain:
            # Substitute task params into command
            resolved = cmd
            for k, v in task.items():
                resolved = resolved.replace(f"{{{k}}}", str(v))
            for k, v in strategy.params.items():
                resolved = resolved.replace(f"{{{k}}}", str(v))

            try:
                import shlex
                resolved_args = shlex.split(resolved)
                proc = subprocess.run(
                    resolved_args, shell=False, capture_output=True, text=True,
                    timeout=strategy.timeout_s, cwd=strategy.params.get("cwd"),
                )
                outputs.append({
                    "cmd": resolved,
                    "stdout": proc.stdout,
                    "stderr": proc.stderr,
                    "returncode": proc.returncode,
                })
                if proc.returncode != 0:
                    return TaskResult(
                        success=False, output=outputs,
                        error=f"Command failed (rc={proc.returncode}): {proc.stderr[:500]}",
                        backend_used="cli",
                    )
            except subprocess.TimeoutExpired:
                return TaskResult(success=False, error=f"Timeout: {resolved}",
                                  backend_used="cli")

        return TaskResult(success=True, output=outputs, backend_used="cli")


class ReactiveEngineBackend:
    """Wraps ReactiveEngine — loads graph by name, runs to convergence."""

    def __init__(self, graphs: dict = None):
        self._graphs = graphs or {}

    def register_graph(self, name: str, graph: dict, initial_state: dict = None):
        self._graphs[name] = {"graph": graph, "initial_state": initial_state or {}}

    async def run(self, task: dict, strategy: ExecutionStrategy) -> TaskResult:
        graph_def = self._graphs.get(strategy.graph_name)
        if not graph_def:
            return TaskResult(success=False, error=f"Unknown graph: {strategy.graph_name}",
                              backend_used="reactive_engine")
        try:
            from reactive_engine import ReactiveEngine
            initial = {**graph_def["initial_state"], **task, **strategy.params}
            engine = ReactiveEngine(initial, graph_def["graph"])
            final_state = await engine.run()
            return TaskResult(success=True, output=final_state,
                              backend_used="reactive_engine")
        except Exception as e:
            return TaskResult(success=False, error=str(e),
                              backend_used="reactive_engine")


class MCPToolBackend:
    """Call MCP tools (memory_search, Canva, Indeed, etc.)."""

    def __init__(self, mcp_caller: Callable = None):
        self._call = mcp_caller  # async fn(tool_name, params) -> result

    async def run(self, task: dict, strategy: ExecutionStrategy) -> TaskResult:
        if not self._call:
            return TaskResult(success=False, error="No MCP caller configured",
                              backend_used="mcp_tool")
        results = []
        for tool_name in strategy.tool_chain:
            try:
                result = await self._call(tool_name, {**task, **strategy.params})
                results.append(result)
            except Exception as e:
                return TaskResult(success=False, error=f"MCP {tool_name}: {e}",
                                  backend_used="mcp_tool")

        return TaskResult(success=True, output=results[-1] if results else None,
                          backend_used="mcp_tool")


# ---------------------------------------------------------------------------
# Classifier — keyword pattern matching (same approach as _classify_query)
# ---------------------------------------------------------------------------

# Domain keywords — conservative, only classify when strong signal
_DOMAIN_KEYWORDS = {
    "security": [
        "scan", "vulnerability", "exploit", "pentest", "penetration",
        "attack", "finding", "cve", "injection", "xss", "sqli",
        "security_scanner", "remediate", "nmap", "nuclei", "chain",
    ],
    "jobs": [
        "job", "resume", "apply", "application", "recruiter",
        "linkedin", "indeed", "seek", "interview", "hire",
        "position", "role", "salary",
    ],
    "content": [
        "post", "publish", "linkedin post", "tweet", "social media",
        "schedule post", "content calendar", "gumroad", "blog",
        "article", "draft",
    ],
    "email": [
        "email", "inbox", "reply", "smtp", "imap", "gmail",
        "send email", "check email", "recruiter email",
    ],
    "memory": [
        "remember", "recall", "memory", "what did i", "do i",
        "what was", "search memories", "store memory",
    ],
    "trading": [
        "trade", "trading", "portfolio", "position", "momentum",
        "trading platform", "market", "portfolio tracker", "prediction market",
        "pnl", "drawdown", "signal", "backtest",
    ],
    "automation": [
        "automate", "workflow", "cron", "schedule", "n8n",
        "playwright", "browser", "scrape",
    ],
    "mobile": [
        "mobile", "react native", "expo", "app store", "google play",
        "ios", "android", "screen", "component", "navigation",
        "companion app", "outdoor app", "hobby app",
    ],
    "research": [
        "research", "investigate", "analyze", "study", "benchmark",
        "experiment", "paper", "arxiv", "literature",
    ],
    "infrastructure": [
        "docker", "deploy", "vps", "server", "devops",
        "kubernetes", "ci/cd", "pipeline", "nginx", "ssl",
    ],
    "product": [
        "product", "roadmap", "feature", "prioritize", "mvp",
        "user story", "sprint", "backlog",
    ],
    "finance": [
        "tax", "revenue", "expense", "invoice", "accounting",
        "budget", "roi", "profit",
    ],
    "legal": [
        "legal", "compliance", "license", "terms of service",
        "privacy policy", "gdpr", "contract",
    ],
    "simulation": [
        "simulate", "simulation", "predict", "forecast", "abm",
        "agent-based", "monte carlo", "mirofish", "swarm",
        "population", "scenario", "what if", "model behavior",
    ],
    "health": [
        "health", "sleep", "exercise", "diet", "calories",
        "fitness", "workout", "heart rate", "steps",
    ],
    "decision": [
        "decide", "decision", "tradeoff", "compare options",
        "pros and cons", "evaluate", "which should",
    ],
    "network": [
        "network", "contact", "relationship", "referral",
        "introduction", "who knows", "connection",
    ],
    "privacy": [
        "privacy", "opsec", "anonymity", "vpn", "tor",
        "expose", "leak", "sensitive",
    ],
}

# Action keywords
_ACTION_KEYWORDS = {
    "search": ["search", "find", "look for", "query", "list", "scan inbox"],
    "scan": ["scan", "test", "audit", "assess", "probe", "check for"],
    "apply": ["apply", "submit", "send application"],
    "publish": ["publish", "post", "send", "dispatch", "share"],
    "triage": ["triage", "prioritize", "categorize", "sort", "classify"],
    "build": ["build", "create", "generate", "write", "implement", "design", "make"],
    "deploy": ["deploy", "push", "ship", "release"],
    "trade": ["trade", "buy", "sell", "execute order", "place order"],
    "report": ["report", "digest", "summary", "dashboard", "stats", "pnl", "drawdown", "check portfolio"],
    "respond": ["respond", "reply", "answer", "acknowledge"],
}


def classify(task: str | dict) -> TaskType:
    """Classify incoming work by domain and action.

    Conservative: defaults to general.execute when unsure.
    Pattern: identical to _classify_query() but generalized beyond memory.
    """
    if isinstance(task, dict):
        # Pre-classified task — trust explicit domain/action
        return TaskType(
            domain=task.get("domain", "general"),
            action=task.get("action", "execute"),
            complexity=task.get("complexity", "simple"),
            confidence=1.0,
            metadata=task,
        )

    q = task.lower()

    # Domain classification — first match wins (ordered by specificity)
    domain = "general"
    domain_confidence = 0.0
    for d, keywords in _DOMAIN_KEYWORDS.items():
        hits = sum(1 for kw in keywords if kw in q)
        if hits > 0:
            score = hits / len(keywords)
            if score > domain_confidence:
                domain = d
                domain_confidence = score

    # Action classification
    action = "execute"
    action_confidence = 0.0
    for a, keywords in _ACTION_KEYWORDS.items():
        hits = sum(1 for kw in keywords if kw in q)
        if hits > 0:
            score = hits / len(keywords)
            if score > action_confidence:
                action = a
                action_confidence = score

    # Complexity heuristic
    complexity = "simple"
    if any(w in q for w in ["full", "comprehensive", "deep", "all", "complete"]):
        complexity = "complex"
    if any(w in q for w in ["reactive", "continuous", "loop", "monitor", "watch"]):
        complexity = "reactive"

    confidence = min(domain_confidence + action_confidence, 1.0)
    if domain == "general":
        confidence = max(confidence, 0.3)  # low confidence for unclassified

    return TaskType(
        domain=domain,
        action=action,
        complexity=complexity,
        confidence=confidence,
        metadata={"raw_query": task},
    )


# ---------------------------------------------------------------------------
# Routing table — the core data structure
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Specialist agent mapping — which subagent handles which domain
# Maps domain -> agent prompt file in subagents directory
# ---------------------------------------------------------------------------

def _resolve_subagent_dir() -> Path:
    """Resolve the subagents directory in this priority order:
    1. AIBRAIN_SUBAGENT_DIR env var (operator override)
    2. aibrain/config.json `subagents_dir` key (canonical config — same source as backend/aibrain_api.py)
    3. Fallback: AIBRAIN_ROOT / "subagents" (legacy default; usually does not exist)

    This unifies task_router.py with the rest of aibrain so a single
    config.json edit propagates to every loader. Closes V2 Special Liaison
    finding (Entry 8 in intel_agent_v2_self_feedback_log.md): "config split =
    silent-inertness failure mode" — task_router used to read its own env var
    with a non-existent default, while config.json correctly pointed at
    decker_system/02_subagents. Result: get_specialist_agent() silently
    returned None for every call in the default environment.
    """
    # 1. Env var override (highest priority — for ops who want a specific dir)
    env_override = os.environ.get("AIBRAIN_SUBAGENT_DIR")
    if env_override:
        return Path(env_override)

    # 2. Canonical config.json
    config_path = AIBRAIN_ROOT / "config.json"
    if config_path.exists():
        try:
            cfg = json.loads(config_path.read_text(encoding="utf-8"))
            if cfg.get("subagents_dir"):
                return Path(cfg["subagents_dir"])
        except (json.JSONDecodeError, OSError):
            pass

    # 3. Legacy default fallback (usually non-existent — surfaces the gap)
    return AIBRAIN_ROOT / "subagents"


SUBAGENT_DIR = _resolve_subagent_dir()

_SPECIALIST_AGENTS = {
    # Domain -> (agent_file, description)
    "security":     ("security_agent.md", "Autonomous pentest/vuln scanning"),
    "security.pentest": ("pentesting_agent.md", "Manual pentest methodology"),
    "security.osint": ("osint_agent.md", "OSINT reconnaissance"),
    "security.malware": ("malware_re_agent.md", "Malware reverse engineering"),
    "security.social": ("social_engineering_agent.md", "Social engineering campaigns"),
    "security.supply_chain": ("supply_chain_security_agent.md", "Supply chain risk"),
    "security.cloud": ("cloud_security_agent.md", "Cloud security assessment"),
    "security.identity": ("idtarget_appttacks_agent.md", "Identity/auth attacks"),
    "security.code_review": ("code_review_agent.md", "Security code review"),
    "security.ai_ml": ("ai_ml_security_agent.md", "AI/ML model security"),
    "jobs":         ("automation_agent.md", "Job search automation"),
    "content":      ("content_agent.md", "Content creation and scheduling"),
    "content.publish": ("communications_agent.md", "Public-facing comms — REQUIRES USER APPROVAL"),
    "email":        ("automation_agent.md", "Email automation"),
    "trading":      ("trading_agent_design.md", "Trading strategy execution"),
    "mobile":       ("pixel_agent.md", "React Native mobile development"),
    "research":     ("research_agent.md", "Deep research and analysis"),
    "finance":      ("finance_agent.md", "Financial planning and tax"),
    "legal":        ("legal_agent.md", "Legal and compliance"),
    "infrastructure": ("infrastructure_agent.md", "DevOps, Docker, VPS"),
    "product":      ("product_manager_agent.md", "Product decisions and roadmap"),
    "sales":        ("sales_agent.md", "Sales funnel and outreach"),
    "privacy":      ("privacy_agent.md", "Privacy and OPSEC"),
    "health":       ("health_agent.md", "Health monitoring"),
    "education":    ("education_agent.md", "Learning and skill development"),
    "intel":        ("intel_agent.md", "Intelligence gathering"),
    "network":      ("network_agent.md", "Professional networking"),
    "reputation":   ("reputation_agent.md", "Online reputation management"),
    "decision":     ("decision_agent.md", "Decision frameworks"),
    "mobility":     ("mobility_agent.md", "Global mobility and relocation"),
    "screenplay":   ("screenplay_agent.md", "Creative writing"),
    "simulation":   ("research_agent.md", "Agent-based simulation and prediction"),
}

# ---------------------------------------------------------------------------
# MCP tool mapping — which MCP tools are available for which domains
# ---------------------------------------------------------------------------
_MCP_TOOLS = {
    # Domain -> list of MCP tool prefixes available
    "content":   ["mcp__claude_ai_Canva__"],            # Canva design tools
    "jobs":      ["mcp__claude_ai_Indeed__"],            # Indeed job search
    "automation": ["mcp__n8n-mcp__", "mcp__playwright__"],  # n8n workflows + browser
    "memory":    ["mcp__aibrain-memory__"],              # Memory store/search/recall
    "browser":   ["mcp__playwright__"],                  # Browser automation
}

def _resolve_persona_path(base_path: Path) -> Path:
    """Prefer the V2 persona file when it exists; fall back to V1.

    V1 files are immutable per the lineage rule. V2 files live beside V1
    with a `_v2.md` suffix. When the loader does not specify a version
    explicitly, pick V2 iff present, else V1. Added 2026-04-12 for V2
    deployment. See decker_system/02_subagents/*_v2.md.
    """
    v2 = base_path.with_name(f"{base_path.stem}_v2{base_path.suffix}")
    return v2 if v2.exists() else base_path


def get_specialist_agent(domain: str, action: str = "") -> Optional[str]:
    """Get the specialist agent prompt file for a domain.

    Checks specific (domain.action) first, then generic (domain).
    Returns the full path to the agent prompt file, or None.
    """
    # Try specific first
    specific_key = f"{domain}.{action}"
    if specific_key in _SPECIALIST_AGENTS:
        agent_file = _SPECIALIST_AGENTS[specific_key][0]
    elif domain in _SPECIALIST_AGENTS:
        agent_file = _SPECIALIST_AGENTS[domain][0]
    else:
        return None

    path = _resolve_persona_path(SUBAGENT_DIR / agent_file)
    return str(path) if path.exists() else None


def get_mcp_tools(domain: str) -> list[str]:
    """Get available MCP tool prefixes for a domain."""
    return _MCP_TOOLS.get(domain, [])


# ---------------------------------------------------------------------------
# Route configuration — loaded from routes_config.json or built-in defaults
# ---------------------------------------------------------------------------
# Users can override routes by placing a routes_config.json in AIBRAIN_ROOT.
# Format: {"security.report": {"backend": "cli", "tool_chain": ["python /path/to/report.py"]}, ...}
# ---------------------------------------------------------------------------

def _load_route_overrides() -> dict:
    """Load user-specific route overrides from routes_config.json."""
    config_path = AIBRAIN_ROOT / "routes_config.json"
    if config_path.exists():
        try:
            with open(config_path) as f:
                raw = json.load(f)
            overrides = {}
            for key_str, cfg in raw.items():
                parts = key_str.split(".", 1)
                if len(parts) != 2:
                    continue
                domain, action = parts
                overrides[(domain, action)] = ExecutionStrategy(
                    name=cfg.get("name", f"{domain}_{action}"),
                    backend=cfg.get("backend", "direct"),
                    graph_name=cfg.get("graph_name", ""),
                    tool_chain=cfg.get("tool_chain", []),
                    params=cfg.get("params", {}),
                    fallback=cfg.get("fallback", ""),
                    timeout_s=cfg.get("timeout_s", 300.0),
                    agent=cfg.get("agent", ""),
                    mcp_tools=cfg.get("mcp_tools", []),
                )
            return overrides
        except Exception as e:
            log.warning(f"Failed to load routes_config.json: {e}")
    return {}


def _p(relative_path: str) -> str:
    """Resolve a path relative to AIBRAIN_ROOT. For use in tool_chain commands."""
    return str(AIBRAIN_ROOT / relative_path)


# Default routing table. Maps (domain, action) -> ExecutionStrategy.
# Same concept as _ROUTING_TABLE_MINILM but for all domains.
# Each route specifies: backend, tools, AND specialist agent + MCP tools.
#
# CLI tool_chain entries that reference scripts use _p() for AIBRAIN_ROOT-relative
# paths. Routes for external projects (security_scanner, analytics, etc.) are loaded from
# routes_config.json — they are user-specific integrations, not part of core AIBrain.
_DEFAULT_ROUTES: dict[tuple[str, str], ExecutionStrategy] = {
    # Memory — memory MCP tools, no specialist agent needed
    ("memory", "search"):   ExecutionStrategy(name="mem_search", backend="mcp_tool",
                                              tool_chain=["memory_search"],
                                              mcp_tools=["memory_search"]),
    ("memory", "execute"):  ExecutionStrategy(name="mem_recall", backend="mcp_tool",
                                              tool_chain=["memory_recall"],
                                              mcp_tools=["memory_recall"]),

    # Security — requires routes_config.json for project-specific paths
    ("security", "scan"):   ExecutionStrategy(name="sec_scan", backend="reactive_engine",
                                              graph_name="security_scanner_scan",
                                              agent="security_agent.md"),
    ("security", "report"):  ExecutionStrategy(name="sec_report", backend="direct",
                                               agent="security_agent.md"),
    ("security", "build"):   ExecutionStrategy(name="sec_code_review", backend="direct",
                                               agent="code_review_agent.md"),

    # Jobs — automation_agent + Indeed MCP + Playwright
    ("jobs", "search"):     ExecutionStrategy(name="job_search", backend="direct",
                                              timeout_s=600,
                                              agent="automation_agent.md",
                                              mcp_tools=["indeed_search_jobs", "playwright"]),
    ("jobs", "respond"):    ExecutionStrategy(name="job_reply", backend="direct",
                                              tool_chain=["email_send"],
                                              agent="automation_agent.md"),
    ("jobs", "triage"):     ExecutionStrategy(name="job_triage", backend="direct",
                                              agent="automation_agent.md",
                                              mcp_tools=["indeed_get_job_details"]),

    # Content — content_agent + Canva MCP (publish goes through communications_agent)
    ("content", "publish"): ExecutionStrategy(name="content_pub", backend="direct",
                                              agent="communications_agent.md",
                                              mcp_tools=["canva_export"]),
    ("content", "build"):   ExecutionStrategy(name="content_draft", backend="mcp_tool",
                                              tool_chain=["canva_generate"],
                                              agent="content_agent.md",
                                              mcp_tools=["canva_generate", "canva_create_design"]),
    ("content", "search"):  ExecutionStrategy(name="content_research", backend="direct",
                                              agent="research_agent.md"),

    # Email — automation_agent + IMAP/SMTP
    ("email", "search"):    ExecutionStrategy(name="email_scan", backend="direct",
                                              agent="automation_agent.md"),
    ("email", "respond"):   ExecutionStrategy(name="email_reply", backend="direct",
                                              tool_chain=["smtp_send"],
                                              agent="automation_agent.md"),

    # Trading — requires routes_config.json for project-specific paths
    ("trading", "scan"):    ExecutionStrategy(name="momentum_scan", backend="direct",
                                              agent="trading_agent_design.md"),
    ("trading", "report"):  ExecutionStrategy(name="trading_report", backend="direct",
                                              agent="trading_agent_design.md"),
    ("trading", "trade"):   ExecutionStrategy(name="trading_exec", backend="direct",
                                              agent="trading_agent_design.md"),

    # Mobile — pixel_agent (React Native specialist)
    ("mobile", "build"):    ExecutionStrategy(name="mobile_build", backend="direct",
                                              agent="pixel_agent.md"),
    ("mobile", "deploy"):   ExecutionStrategy(name="mobile_deploy", backend="cli",
                                              tool_chain=["npx expo build"],
                                              agent="pixel_agent.md"),

    # Automation — n8n MCP + Playwright
    ("automation", "build"): ExecutionStrategy(name="n8n_workflow", backend="mcp_tool",
                                               tool_chain=["n8n_create_workflow"],
                                               agent="automation_agent.md",
                                               mcp_tools=["n8n_create_workflow", "n8n_deploy_template"]),
    ("automation", "execute"): ExecutionStrategy(name="browser_auto", backend="mcp_tool",
                                                  tool_chain=["playwright"],
                                                  agent="automation_agent.md",
                                                  mcp_tools=["playwright_navigate", "playwright_click"]),

    # Research — research_agent
    ("research", "search"):  ExecutionStrategy(name="deep_research", backend="direct",
                                               agent="research_agent.md"),
    ("research", "execute"): ExecutionStrategy(name="research_exec", backend="direct",
                                               agent="research_agent.md"),

    # Infrastructure — infrastructure_agent
    ("infrastructure", "build"):  ExecutionStrategy(name="infra_build", backend="cli",
                                                     agent="infrastructure_agent.md"),
    ("infrastructure", "deploy"): ExecutionStrategy(name="infra_deploy", backend="cli",
                                                     agent="infrastructure_agent.md"),

    # Product decisions — product_manager_agent
    ("product", "execute"):  ExecutionStrategy(name="product_decision", backend="direct",
                                               agent="product_manager_agent.md"),

    # Finance — finance_agent
    ("finance", "report"):   ExecutionStrategy(name="finance_report", backend="direct",
                                               agent="finance_agent.md"),

    # Legal — legal_agent
    ("legal", "execute"):    ExecutionStrategy(name="legal_review", backend="direct",
                                               agent="legal_agent.md"),

    # Simulation — ABM for prediction (markets, products, content)
    ("simulation", "execute"): ExecutionStrategy(name="sim_predict", backend="cli",
                                                  tool_chain=[f"python {_p('simulation/run_abm.py')} --scenario product_launch --json"],
                                                  timeout_s=600,
                                                  agent="research_agent.md"),
    ("simulation", "build"):   ExecutionStrategy(name="sim_setup", backend="direct",
                                                  agent="research_agent.md"),
    ("simulation", "report"):  ExecutionStrategy(name="sim_report", backend="cli",
                                                  tool_chain=[f"python {_p('simulation/analyze_results.py')}"],
                                                  agent="research_agent.md"),

    # General fallback
    ("general", "execute"):  ExecutionStrategy(name="general", backend="direct",
                                               tool_chain=[]),
    ("general", "build"):    ExecutionStrategy(name="general_build", backend="direct",
                                               tool_chain=[]),
}

# Apply user overrides from routes_config.json
_DEFAULT_ROUTES.update(_load_route_overrides())


def route(task_type: TaskType, routing_table: dict = None) -> ExecutionStrategy:
    """Select optimal execution strategy. Pure lookup from routing table.

    Falls back through: exact (domain, action) -> (domain, 'execute') -> general.
    """
    table = routing_table or _DEFAULT_ROUTES

    # Exact match
    key = (task_type.domain, task_type.action)
    if key in table:
        return table[key]

    # Domain fallback
    fallback_key = (task_type.domain, "execute")
    if fallback_key in table:
        return table[fallback_key]

    # General fallback
    return table.get(("general", "execute"),
                     ExecutionStrategy(name="noop", backend="direct"))


# ---------------------------------------------------------------------------
# TaskRouter — the orchestrator
# ---------------------------------------------------------------------------

class TaskRouter:
    """Universal classify -> route -> execute pipeline.

    This is the generalization of _classify_query() + _get_routing_table()
    from mcp_server.py, applied to all work domains.
    """

    def __init__(self, db_path: str = None, routing_table: dict = None):
        self._routing_table = routing_table or dict(_DEFAULT_ROUTES)
        self._backends: dict[str, BackendAdapter] = {}
        self._db_path = db_path
        self._execution_log: list[dict] = []

        # Register built-in backends
        self._direct = DirectBackend()
        self._backends["direct"] = self._direct
        self._backends["cli"] = CLIBackend()
        self._backends["reactive_engine"] = ReactiveEngineBackend()
        self._backends["mcp_tool"] = MCPToolBackend()

    def register_backend(self, name: str, backend: BackendAdapter):
        """Register a custom execution backend."""
        self._backends[name] = backend

    def register_handler(self, name: str, fn: Callable):
        """Register a direct-call handler function."""
        self._direct.register(name, fn)

    def register_route(self, domain: str, action: str, strategy: ExecutionStrategy):
        """Add or override a routing table entry."""
        self._routing_table[(domain, action)] = strategy

    def register_graph(self, name: str, graph: dict, initial_state: dict = None):
        """Register a reactive engine graph."""
        re_backend = self._backends.get("reactive_engine")
        if isinstance(re_backend, ReactiveEngineBackend):
            re_backend.register_graph(name, graph, initial_state)

    def set_mcp_caller(self, caller: Callable):
        """Set the MCP tool caller for the MCP backend."""
        mcp_backend = self._backends.get("mcp_tool")
        if isinstance(mcp_backend, MCPToolBackend):
            mcp_backend._call = caller

    def classify(self, task: str | dict) -> TaskType:
        """Classify incoming work."""
        return classify(task)

    def route(self, task_type: TaskType) -> ExecutionStrategy:
        """Select execution strategy. Auto-creates routes for unknown domains."""
        strategy = route(task_type, self._routing_table)

        # Self-expanding: if we fell back to general, try to create a specific route
        if strategy.name in ("general", "noop", "general_build") and task_type.domain != "general":
            new_strategy = self._auto_create_route(task_type)
            if new_strategy:
                strategy = new_strategy

        return strategy

    def _auto_create_route(self, task_type: TaskType) -> Optional[ExecutionStrategy]:
        """Auto-create a new route for an unrouted domain/action.

        Scans available subagents and MCP tools to find the best match.
        Persists new route to routing table and optionally to DB.
        """
        domain = task_type.domain
        action = task_type.action

        # Try to find a matching specialist agent
        agent_file = None
        agent_path = get_specialist_agent(domain, action)
        if agent_path:
            agent_file = Path(agent_path).name

        # If no specialist agent, scan subagent directory for keyword match.
        # V2-preference filter (2026-04-12): when a V1 file has a V2 sibling,
        # skip the V1 so we never double-match the same logical persona. The
        # matched V2 stem still contains the domain substring (e.g. `intel_agent_v2`
        # contains `intel`), so keyword matching continues to work.
        if not agent_file and SUBAGENT_DIR.exists():
            for f in SUBAGENT_DIR.glob("*.md"):
                if f.stem.endswith("_v2"):
                    pass  # V2 file — always a candidate
                else:
                    v2_sibling = f.with_name(f"{f.stem}_v2{f.suffix}")
                    if v2_sibling.exists():
                        continue  # V2 exists — skip V1 to avoid double-load
                if domain in f.stem.lower() or domain.replace("_", "") in f.stem.lower():
                    agent_file = f.name
                    break

        # Get MCP tools for this domain
        mcp_tools = get_mcp_tools(domain)

        # Determine backend
        backend = "direct"
        if mcp_tools:
            backend = "mcp_tool"

        # Create strategy
        strategy = ExecutionStrategy(
            name=f"auto_{domain}_{action}",
            backend=backend,
            agent=agent_file or "",
            mcp_tools=mcp_tools,
        )

        # Register the new route
        self._routing_table[(domain, action)] = strategy
        log.info(f"TaskRouter: auto-created route {domain}.{action} -> {strategy.key}"
                 f" (agent={agent_file}, mcp={mcp_tools})")

        # Persist to DB
        if self._db_path:
            try:
                conn = sqlite3.connect(self._db_path)
                conn.execute("""
                    INSERT OR REPLACE INTO task_routes
                        (domain, action, backend, graph_name, tool_chain, params, created, updated)
                    VALUES (?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
                """, (domain, action, backend, "", json.dumps(mcp_tools),
                      json.dumps({"agent": agent_file or ""})))
                conn.commit()
                conn.close()
            except Exception as e:
                log.debug(f"Auto-route DB persist failed: {e}")

        return strategy

    async def execute(self, task: str | dict,
                      strategy: ExecutionStrategy = None) -> TaskResult:
        """Full pipeline: classify -> route -> execute.

        If strategy is provided, skips classify+route (manual override).
        """
        t0 = time.time()

        # Classify
        task_type = self.classify(task)
        task_dict = task if isinstance(task, dict) else {"query": task}

        # Route
        if strategy is None:
            strategy = self.route(task_type)

        # Select backend
        backend = self._backends.get(strategy.backend)
        if not backend:
            return TaskResult(
                success=False,
                error=f"Unknown backend: {strategy.backend}",
                task_type_key=task_type.key,
                strategy_key=strategy.key,
            )

        # Execute
        log.info(f"TaskRouter: {task_type.key} -> {strategy.key} via {strategy.backend}")

        try:
            result = await backend.run(task_dict, strategy)
        except Exception as e:
            result = TaskResult(success=False, error=str(e))

        # Enrich result
        result.duration_s = time.time() - t0
        result.task_type_key = task_type.key
        result.strategy_key = strategy.key
        if not result.backend_used:
            result.backend_used = strategy.backend

        # Log execution
        self._log_execution(task_type, strategy, result)

        # Fallback on failure
        if not result.success and strategy.fallback:
            fallback_strategy = self._routing_table.get(
                (task_type.domain, strategy.fallback)
            )
            if fallback_strategy:
                log.info(f"TaskRouter: fallback -> {fallback_strategy.key}")
                result = await self.execute(task, strategy=fallback_strategy)

        return result

    def _log_execution(self, task_type: TaskType, strategy: ExecutionStrategy,
                       result: TaskResult):
        """Record execution for learning loop."""
        entry = {
            "ts": datetime.utcnow().isoformat(),
            "domain": task_type.domain,
            "action": task_type.action,
            "backend": result.backend_used,
            "strategy": strategy.key,
            "success": result.success,
            "duration_s": result.duration_s,
            "confidence": task_type.confidence,
            "trace_id": result.trace_id,
        }
        self._execution_log.append(entry)

        # Persist to DB if available
        if self._db_path:
            self._persist_execution(entry)

    def _persist_execution(self, entry: dict):
        """Write execution record to SQLite."""
        try:
            conn = sqlite3.connect(self._db_path)
            conn.execute("""
                INSERT INTO task_executions
                    (task_text, domain, action, backend_used, success,
                     duration_ms, confidence, trace_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                json.dumps(entry),
                entry["domain"],
                entry["action"],
                entry["backend"],
                int(entry["success"]),
                entry["duration_s"] * 1000,
                entry["confidence"],
                entry["trace_id"],
            ))
            conn.commit()
            conn.close()
        except Exception as e:
            log.debug(f"Execution log DB write failed: {e}")

    # Introspection
    def list_routes(self) -> list[dict]:
        """Return all registered routes."""
        return [
            {
                "domain": d,
                "action": a,
                "backend": s.backend,
                "graph": s.graph_name,
                "tools": s.tool_chain,
                "strategy": s.key,
                "agent": s.agent,
                "mcp_tools": s.mcp_tools,
            }
            for (d, a), s in sorted(self._routing_table.items())
        ]

    def stats(self) -> dict:
        """Return execution statistics."""
        if not self._execution_log:
            return {"total": 0}

        total = len(self._execution_log)
        successes = sum(1 for e in self._execution_log if e["success"])
        by_domain = {}
        for e in self._execution_log:
            d = e["domain"]
            if d not in by_domain:
                by_domain[d] = {"total": 0, "success": 0, "avg_ms": 0}
            by_domain[d]["total"] += 1
            if e["success"]:
                by_domain[d]["success"] += 1
            by_domain[d]["avg_ms"] += e["duration_s"] * 1000

        for d in by_domain:
            if by_domain[d]["total"]:
                by_domain[d]["avg_ms"] /= by_domain[d]["total"]

        return {
            "total": total,
            "success_rate": successes / total if total else 0,
            "by_domain": by_domain,
        }


# ---------------------------------------------------------------------------
# DB schema extension — call from aibrain_db._init_schema
# ---------------------------------------------------------------------------

TASK_ROUTER_SCHEMA = """
    CREATE TABLE IF NOT EXISTS task_routes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        domain TEXT NOT NULL,
        action TEXT NOT NULL,
        backend TEXT NOT NULL,
        graph_name TEXT DEFAULT '',
        tool_chain TEXT DEFAULT '[]',
        params TEXT DEFAULT '{}',
        fallback TEXT DEFAULT '',
        success_count INTEGER DEFAULT 0,
        fail_count INTEGER DEFAULT 0,
        avg_duration_ms REAL DEFAULT 0,
        active INTEGER DEFAULT 1,
        created TEXT DEFAULT (datetime('now')),
        updated TEXT DEFAULT (datetime('now')),
        UNIQUE(domain, action)
    );

    CREATE TABLE IF NOT EXISTS task_executions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        task_text TEXT DEFAULT '',
        domain TEXT,
        action TEXT,
        backend_used TEXT,
        success INTEGER,
        duration_ms REAL,
        confidence REAL,
        escalated INTEGER DEFAULT 0,
        trace_id TEXT,
        created TEXT DEFAULT (datetime('now'))
    );
"""


def init_db_schema(conn: sqlite3.Connection):
    """Add task router tables to an existing DB connection."""
    conn.executescript(TASK_ROUTER_SCHEMA)


# ---------------------------------------------------------------------------
# Convenience — create a pre-configured router
# ---------------------------------------------------------------------------

def create_router(db_path: str = None) -> TaskRouter:
    """Create a TaskRouter with default routes and backends.

    Optionally connects to AIBrain DB for persistence.
    """
    router = TaskRouter(db_path=db_path)

    # Initialize DB schema if path provided
    if db_path:
        try:
            conn = sqlite3.connect(db_path)
            init_db_schema(conn)
            conn.close()
        except Exception as e:
            log.warning(f"Could not init task router DB: {e}")

    return router


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("Usage:")
        print("  python task_router.py classify 'scan target_app for SQLi'")
        print("  python task_router.py routes")
        print("  python task_router.py run 'search remote security jobs'")
        sys.exit(0)

    cmd = sys.argv[1]

    if cmd == "classify":
        query = " ".join(sys.argv[2:])
        tt = classify(query)
        print(f"Domain:     {tt.domain}")
        print(f"Action:     {tt.action}")
        print(f"Complexity: {tt.complexity}")
        print(f"Confidence: {tt.confidence:.2f}")
        print(f"Key:        {tt.key}")
        strategy = route(tt)
        print(f"Strategy:   {strategy.key}")
        print(f"Backend:    {strategy.backend}")
        print(f"Tools:      {strategy.tool_chain}")
        if strategy.agent:
            agent_path = get_specialist_agent(tt.domain, tt.action)
            print(f"Agent:      {strategy.agent}" + (f" ({'exists' if agent_path else 'NOT FOUND'})" if strategy.agent else ""))
        if strategy.mcp_tools:
            print(f"MCP Tools:  {strategy.mcp_tools}")

    elif cmd == "routes":
        router = TaskRouter()
        for r in router.list_routes():
            print(f"  {r['domain']}.{r['action']:<10} -> {r['backend']:<18} {r['strategy']}")

    elif cmd == "run":
        query = " ".join(sys.argv[2:])
        router = create_router()
        result = asyncio.run(router.execute(query))
        print(f"\nResult: {'OK' if result.success else 'FAIL'}")
        print(f"Backend: {result.backend_used}")
        print(f"Duration: {result.duration_s:.2f}s")
        if result.error:
            print(f"Error: {result.error}")
        if result.output:
            print(f"Output: {json.dumps(result.output, indent=2, default=str)[:2000]}")

    else:
        print(f"Unknown command: {cmd}")
