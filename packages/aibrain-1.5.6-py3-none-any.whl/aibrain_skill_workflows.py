#!/usr/bin/env python3
"""
aibrain_skill_workflows.py — 40 Skill-Executing Workflows

These workflows are what an AI agent wants available after receiving aibrain.
They directly execute the intelligence encoded in the 40 skills, making the
agent measurably better at every task type.

Four categories:
1. Agent Self-Improvement (10) — what the agent needs to get better over time
2. Skill Execution: Code & Architecture (10) — automating the technical skills
3. Skill Execution: Security & Compliance (10) — automating the security skills
4. Intelligence & Research (10) — knowledge acquisition and synthesis

Each workflow:
- Maps to one or more of the 40 skills
- Uses aibrain's memory, skill_memory, and self_model systems
- Records skill episodes so the agent learns from execution
- Produces actionable output stored as brain memories
"""

import hashlib
import json
import logging
import os
import re
import sqlite3
import subprocess
import time
from abc import ABC, abstractmethod
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple

log = logging.getLogger("aibrain.skill_workflows")


# ---------------------------------------------------------------------------
# Base
# ---------------------------------------------------------------------------

class SkillWorkflow(ABC):
    """Base class for skill-executing workflows."""

    name: str = "base"
    display_name: str = "Base"
    description: str = ""
    category: str = "general"
    schedule_cron: str = "0 9 * * *"
    maps_to_skills: List[str] = []  # which skills this workflow executes

    def __init__(self, db_path: str, config: Dict = None):
        self.db_path = db_path
        self.config = config or {}
        self._conn = None

    def _db(self):
        if self._conn is None:
            self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
            self._conn.row_factory = sqlite3.Row
        return self._conn

    def store(self, name: str, content: str, mem_type: str = "reference",
              tags: str = "", importance: float = 0.5):
        db = self._db()
        try:
            existing = db.execute(
                "SELECT id FROM memories WHERE name=? AND active=1", (name,)
            ).fetchone()
            if existing:
                db.execute(
                    "UPDATE memories SET content=?, tags=?, importance=?, updated=datetime('now') WHERE id=?",
                    (content, tags, importance, existing[0])
                )
            else:
                db.execute(
                    "INSERT INTO memories (name, type, tags, content, importance, created, updated, active) "
                    "VALUES (?, ?, ?, ?, ?, datetime('now'), datetime('now'), 1)",
                    (name, mem_type, tags, content, importance)
                )
            db.commit()
        except Exception as e:
            log.error("[%s] store failed: %s", self.name, e)

    def search(self, query: str, limit: int = 10) -> List[Dict]:
        db = self._db()
        try:
            rows = db.execute(
                "SELECT name, content, tags, type FROM memories "
                "WHERE active=1 AND content LIKE ? ORDER BY updated DESC LIMIT ?",
                (f"%{query}%", limit)
            ).fetchall()
            return [dict(r) for r in rows]
        except Exception:
            return []

    def get_principles(self, task_type: str) -> List[Dict]:
        """Load skill principles for a task type."""
        db = self._db()
        try:
            rows = db.execute(
                "SELECT principle, confidence, source_episode_id FROM skill_principles "
                "WHERE task_type=? AND status='active' ORDER BY confidence DESC LIMIT 10",
                (task_type,)
            ).fetchall()
            return [dict(r) for r in rows]
        except Exception:
            return []

    def record_episode(self, task_type: str, description: str, approach: str,
                       tools: List[str], outcome: float, context: List[str] = None,
                       duration: float = 0):
        """Record a skill episode for learning."""
        db = self._db()
        try:
            db.execute(
                "INSERT INTO skill_episodes "
                "(task_type, task_description, approach_taken, tools_used, "
                "outcome_quality, context_keys, duration_seconds, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))",
                (task_type, description, approach, json.dumps(tools),
                 outcome, json.dumps(context or []), duration)
            )
            db.commit()
        except Exception as e:
            log.debug("[%s] episode recording skipped: %s", self.name, e)

    def get_config(self, key: str, default=None):
        return self.config.get(key, default)

    @abstractmethod
    def run(self) -> Dict:
        pass

    @property
    def schedule(self) -> str:
        return self.schedule_cron


# =========================================================================
# CATEGORY 1: AGENT SELF-IMPROVEMENT (10)
# What an agent needs to become the best version of itself
# =========================================================================

class SkillSharpener(SkillWorkflow):
    """Review past skill episodes, identify weak areas, update principles.

    Maps to: all skills — meta-workflow that improves every other workflow.
    """
    name = "skill_sharpener"
    display_name = "Skill Sharpener"
    description = "Analyze past task performance to identify weak areas and strengthen principles"
    category = "self_improvement"
    schedule_cron = "0 22 * * 0"  # Sunday 10pm
    maps_to_skills = ["all"]

    def run(self) -> Dict:
        db = self._db()

        # Find task types with declining performance
        weak_areas = []
        strong_areas = []
        try:
            task_types = db.execute(
                "SELECT DISTINCT task_type, COUNT(*) as episodes, "
                "AVG(outcome_quality) as avg_outcome, "
                "AVG(CASE WHEN created_at >= datetime('now', '-7 days') THEN outcome_quality END) as recent_avg "
                "FROM skill_episodes GROUP BY task_type HAVING episodes >= 3 "
                "ORDER BY avg_outcome ASC"
            ).fetchall()

            for tt in task_types:
                data = dict(tt)
                recent = data.get("recent_avg") or data["avg_outcome"]
                overall = data["avg_outcome"]

                if recent < overall * 0.8:  # 20% decline
                    weak_areas.append({
                        "task_type": data["task_type"],
                        "episodes": data["episodes"],
                        "avg": round(overall, 2),
                        "recent": round(recent, 2),
                        "trend": "declining"
                    })
                elif recent > 0.8:
                    strong_areas.append({
                        "task_type": data["task_type"],
                        "avg": round(overall, 2),
                    })
        except Exception:
            pass

        # Find principles with low confidence that need reinforcement
        fragile_principles = []
        try:
            rows = db.execute(
                "SELECT task_type, principle, confidence FROM skill_principles "
                "WHERE status='active' AND confidence < 0.5 "
                "ORDER BY confidence ASC LIMIT 10"
            ).fetchall()
            fragile_principles = [dict(r) for r in rows]
        except Exception:
            pass

        report = f"# Skill Analysis — {datetime.now().strftime('%Y-%m-%d')}\n\n"

        if weak_areas:
            report += "## Areas Needing Improvement\n"
            for w in weak_areas:
                report += (f"- **{w['task_type']}**: avg {w['avg']:.0%} → recent {w['recent']:.0%} "
                          f"({w['trend']}, {w['episodes']} episodes)\n")

        if strong_areas:
            report += "\n## Strong Areas\n"
            for s in strong_areas[:5]:
                report += f"- **{s['task_type']}**: {s['avg']:.0%} average\n"

        if fragile_principles:
            report += "\n## Principles Needing Reinforcement\n"
            for p in fragile_principles:
                report += f"- [{p['task_type']}] ({p['confidence']:.0%}) {p['principle'][:80]}\n"

        self.store(
            f"skill_analysis_{datetime.now().strftime('%Y_W%W')}",
            report, "reference", "skill_analysis,self_improvement,auto", 0.7
        )

        return {"status": "ok", "weak_areas": len(weak_areas),
                "strong_areas": len(strong_areas),
                "fragile_principles": len(fragile_principles)}


class SelfModelRefresh(SkillWorkflow):
    """Regenerate the agent's self-model from accumulated evidence.

    The self-model is what the agent loads first every session — its identity,
    capabilities, and understanding of the user.
    """
    name = "self_model_refresh"
    display_name = "Self-Model Refresh"
    description = "Regenerate agent identity document from accumulated memories and skill data"
    category = "self_improvement"
    schedule_cron = "0 23 * * 0"  # Sunday 11pm
    maps_to_skills = ["self_model"]

    def run(self) -> Dict:
        db = self._db()

        # Count capabilities
        skill_counts = {}
        try:
            rows = db.execute(
                "SELECT task_type, COUNT(*) as episodes, AVG(outcome_quality) as avg "
                "FROM skill_episodes GROUP BY task_type ORDER BY avg DESC"
            ).fetchall()
            skill_counts = {r["task_type"]: {"episodes": r["episodes"], "avg": round(r["avg"], 2)}
                          for r in rows}
        except Exception:
            pass

        # Count total memories
        total_memories = 0
        try:
            row = db.execute("SELECT COUNT(*) as c FROM memories WHERE active=1").fetchone()
            total_memories = row["c"] if row else 0
        except Exception:
            pass

        # User preferences learned
        user_prefs = self.search("preference", limit=20)

        # Build self-model
        model = f"# Agent Self-Model\n"
        model += f"**Last updated:** {datetime.now().strftime('%Y-%m-%d %H:%M')}\n"
        model += f"**Total memories:** {total_memories}\n"
        model += f"**Task types practiced:** {len(skill_counts)}\n\n"

        if skill_counts:
            model += "## Capabilities (by demonstrated competence)\n"
            sorted_skills = sorted(skill_counts.items(), key=lambda x: x[1]["avg"], reverse=True)
            for task, data in sorted_skills[:15]:
                level = "expert" if data["avg"] > 0.8 else "proficient" if data["avg"] > 0.6 else "developing"
                model += f"- **{task}**: {level} ({data['avg']:.0%} avg, {data['episodes']} episodes)\n"

        if user_prefs:
            model += "\n## Known User Preferences\n"
            for pref in user_prefs[:10]:
                model += f"- {pref['content'][:100]}\n"

        model += "\n## Operating Principles\n"
        model += "- Accuracy before speed\n"
        model += "- Admit uncertainty rather than confabulate\n"
        model += "- Every task is a learning opportunity — record episodes\n"
        model += "- Use accumulated principles before defaulting to generic approaches\n"

        self.store("self_model", model, "agent", "self_model,identity,auto", 0.9)
        return {"status": "ok", "skills": len(skill_counts), "memories": total_memories}


class KnowledgeGapDetector(SkillWorkflow):
    """Find topics the user asks about where the agent has no stored knowledge.

    Scans recent interactions for queries that returned no results,
    and flags them as knowledge gaps to fill.
    """
    name = "knowledge_gap_detector"
    display_name = "Knowledge Gap Detector"
    description = "Identify topics where the agent lacks stored knowledge"
    category = "self_improvement"
    schedule_cron = "0 21 * * 5"  # Friday 9pm
    maps_to_skills = ["autonomous_research"]

    def run(self) -> Dict:
        db = self._db()

        # Find search queries that returned zero results (from activity log)
        gaps = []
        try:
            rows = db.execute(
                "SELECT DISTINCT action as query, COUNT(*) as attempts "
                "FROM activity WHERE category='search' "
                "AND timestamp >= datetime('now', '-7 days') "
                "GROUP BY action ORDER BY attempts DESC LIMIT 20"
            ).fetchall()

            for r in rows:
                query = r["query"]
                # Check if we have memories for this topic
                count = db.execute(
                    "SELECT COUNT(*) as c FROM memories WHERE active=1 AND content LIKE ?",
                    (f"%{query}%",)
                ).fetchone()
                if count and count["c"] < 2:
                    gaps.append({"query": query, "attempts": r["attempts"],
                                "existing": count["c"]})
        except Exception:
            pass

        if gaps:
            report = f"# Knowledge Gaps — {datetime.now().strftime('%Y-%m-%d')}\n\n"
            report += "Topics the user asked about where I have insufficient knowledge:\n\n"
            for g in gaps:
                report += f"- **{g['query']}** — searched {g['attempts']}x, only {g['existing']} memories\n"
            report += "\n*Consider researching these topics to build knowledge base.*"

            self.store(
                f"knowledge_gaps_{datetime.now().strftime('%Y_W%W')}",
                report, "reference", "gaps,learning,self_improvement,auto", 0.6
            )

        return {"status": "ok", "gaps_found": len(gaps)}


class CorrectionLearner(SkillWorkflow):
    """Process user corrections into updated skill principles.

    When a user corrects the agent, that correction is gold — it reveals
    a gap between what the agent did and what was actually needed.
    """
    name = "correction_learner"
    display_name = "Correction Learner"
    description = "Convert user corrections into permanent skill improvements"
    category = "self_improvement"
    schedule_cron = "0 22 * * *"  # daily 10pm
    maps_to_skills = ["all"]

    def run(self) -> Dict:
        db = self._db()
        corrections = []
        try:
            rows = db.execute(
                "SELECT name, content, tags FROM memories "
                "WHERE (tags LIKE '%correction%' OR tags LIKE '%feedback%' OR tags LIKE '%wrong%') "  # noqa:like-wildcard-injection
                "AND active=1 AND created >= datetime('now', '-7 days') "
                "ORDER BY created DESC LIMIT 20"
            ).fetchall()
            corrections = [dict(r) for r in rows]
        except Exception:
            pass

        principles_created = 0
        for corr in corrections:
            content = corr.get("content", "")
            # Extract what the correction teaches
            # Look for patterns: "should have", "instead of", "next time", "the correct"
            lesson = None
            for pattern in [r'should\s+(?:have\s+)?(.+)', r'instead\s+of.*?,\s*(.+)',
                           r'next\s+time[,:]?\s*(.+)', r'the\s+correct\s+(?:approach|way|answer)\s+is\s+(.+)']:
                match = re.search(pattern, content, re.IGNORECASE)
                if match:
                    lesson = match.group(1).strip()[:200]
                    break

            if lesson:
                # Determine task type from context
                task_type = "general"
                for tag in corr.get("tags", "").split(","):
                    tag = tag.strip()
                    if tag and tag not in ("correction", "feedback", "wrong", "auto"):
                        task_type = tag
                        break

                try:
                    db.execute(
                        "INSERT INTO skill_principles "
                        "(task_type, principle, confidence, status, source_episode_id, created_at) "
                        "VALUES (?, ?, 0.6, 'active', NULL, datetime('now'))",
                        (task_type, f"Learned from correction: {lesson}")
                    )
                    db.commit()
                    principles_created += 1
                except Exception:
                    pass

        if principles_created > 0:
            self.store(
                f"corrections_processed_{datetime.now().strftime('%Y%m%d')}",
                f"Processed {len(corrections)} corrections into {principles_created} new principles.",
                "reference", "corrections,learning,auto", 0.6
            )

        return {"status": "ok", "corrections": len(corrections),
                "principles_created": principles_created}


class TaskBriefingGenerator(SkillWorkflow):
    """Generate pre-task briefings by loading all relevant context.

    Before any complex task, this workflow assembles: relevant memories,
    applicable skill principles, past episode outcomes, and user preferences.
    """
    name = "task_briefing"
    display_name = "Task Briefing Generator"
    description = "Assemble comprehensive briefings before complex tasks"
    category = "self_improvement"
    schedule_cron = "0 6 * * *"  # daily 6am
    maps_to_skills = ["project_planning", "research_synthesis"]

    def run(self) -> Dict:
        db = self._db()

        # Find active projects (most likely upcoming tasks)
        projects = []
        try:
            rows = db.execute(
                "SELECT name, content, tags FROM memories "
                "WHERE type='project' AND active=1 ORDER BY updated DESC LIMIT 5"
            ).fetchall()
            projects = [dict(r) for r in rows]
        except Exception:
            pass

        briefings = 0
        for proj in projects:
            name = proj["name"]
            tags = proj.get("tags", "").split(",")

            # Gather relevant principles
            principles = []
            for tag in tags[:3]:
                tag = tag.strip()
                if tag:
                    principles.extend(self.get_principles(tag))

            # Gather related memories
            related = self.search(name, limit=5)

            briefing = f"# Briefing: {name}\n\n"
            briefing += f"**Project context:** {proj['content'][:200]}\n\n"

            if principles:
                briefing += "## Applicable Principles\n"
                for p in principles[:5]:
                    briefing += f"- ({p.get('confidence', 0):.0%}) {p['principle'][:100]}\n"

            if related:
                briefing += "\n## Related Knowledge\n"
                for r in related:
                    briefing += f"- {r['name']}: {r['content'][:80]}\n"

            self.store(
                f"briefing_{name}_{datetime.now().strftime('%Y%m%d')}",
                briefing, "reference", "briefing,preparation,auto", 0.6
            )
            briefings += 1

        return {"status": "ok", "briefings": briefings}


class TaskRetrospective(SkillWorkflow):
    """After task completion, evaluate quality and record learnings.

    Scans recent completed tasks and generates retrospective analysis.
    """
    name = "task_retrospective"
    display_name = "Task Retrospective"
    description = "Analyze completed tasks for quality patterns and learning opportunities"
    category = "self_improvement"
    schedule_cron = "0 18 * * 5"  # Friday 6pm
    maps_to_skills = ["retrospective_analysis"]

    def run(self) -> Dict:
        db = self._db()

        # Recent episodes this week
        episodes = []
        try:
            rows = db.execute(
                "SELECT task_type, task_description, approach_taken, outcome_quality, "
                "tools_used, duration_seconds, created_at "
                "FROM skill_episodes WHERE created_at >= datetime('now', '-7 days') "
                "ORDER BY outcome_quality ASC"
            ).fetchall()
            episodes = [dict(r) for r in rows]
        except Exception:
            pass

        if not episodes:
            return {"status": "ok", "episodes": 0}

        avg_quality = sum(e["outcome_quality"] for e in episodes) / len(episodes)
        best = max(episodes, key=lambda e: e["outcome_quality"])
        worst = min(episodes, key=lambda e: e["outcome_quality"])

        report = f"# Weekly Retrospective — {datetime.now().strftime('%Y-%m-%d')}\n\n"
        report += f"**Tasks completed:** {len(episodes)}\n"
        report += f"**Average quality:** {avg_quality:.0%}\n\n"

        report += "## Best Performance\n"
        report += f"- {best['task_type']}: {best['task_description'][:80]} ({best['outcome_quality']:.0%})\n"
        report += f"  Approach: {best['approach_taken'][:100]}\n\n"

        report += "## Needs Improvement\n"
        report += f"- {worst['task_type']}: {worst['task_description'][:80]} ({worst['outcome_quality']:.0%})\n"
        report += f"  Approach: {worst['approach_taken'][:100]}\n\n"

        # Task type distribution
        type_counts = Counter(e["task_type"] for e in episodes)
        report += "## Task Distribution\n"
        for tt, count in type_counts.most_common(10):
            report += f"- {tt}: {count} tasks\n"

        report += "\n## Reflection\n"
        report += "- What patterns led to the best outcomes?\n"
        report += "- What could be done differently for low-scoring tasks?\n"
        report += "- Are there task types being avoided?\n"

        self.store(
            f"retrospective_{datetime.now().strftime('%Y_W%W')}",
            report, "reference", "retrospective,learning,weekly,auto", 0.7
        )

        self.record_episode("self_reflection", f"Weekly retro: {len(episodes)} tasks, avg {avg_quality:.0%}",
                           "retrospective_analysis", ["task_retrospective"], avg_quality)

        return {"status": "ok", "episodes": len(episodes), "avg_quality": round(avg_quality, 2)}


class MemoryHygiene(SkillWorkflow):
    """Consolidate duplicates, decay stale memories, archive old data.

    Keeps the brain clean and fast. Critical for long-running agents.
    """
    name = "memory_hygiene"
    display_name = "Memory Hygiene"
    description = "Clean duplicates, decay stale memories, consolidate related items"
    category = "self_improvement"
    schedule_cron = "0 3 * * 0"  # Sunday 3am
    maps_to_skills = ["memory_lifecycle"]

    def run(self) -> Dict:
        db = self._db()
        stats = {"duplicates_merged": 0, "stale_archived": 0, "total_active": 0}

        # Count active memories
        try:
            row = db.execute("SELECT COUNT(*) as c FROM memories WHERE active=1").fetchone()
            stats["total_active"] = row["c"] if row else 0
        except Exception:
            pass

        # Find and merge exact content duplicates
        try:
            dupes = db.execute(
                "SELECT content, COUNT(*) as cnt, GROUP_CONCAT(id) as ids "
                "FROM memories WHERE active=1 GROUP BY content HAVING cnt > 1 LIMIT 50"
            ).fetchall()
            for dupe in dupes:
                ids = [int(i) for i in dupe["ids"].split(",")]
                keep_id = ids[0]
                for remove_id in ids[1:]:
                    db.execute("UPDATE memories SET active=0 WHERE id=?", (remove_id,))
                    stats["duplicates_merged"] += 1
            db.commit()
        except Exception:
            pass

        # Archive stale low-importance memories (>90 days old, importance < 0.3)
        try:
            result = db.execute(
                "UPDATE memories SET active=0 WHERE active=1 "
                "AND importance < 0.3 AND updated < datetime('now', '-90 days')"
            )
            stats["stale_archived"] = result.rowcount
            db.commit()
        except Exception:
            pass

        if stats["duplicates_merged"] > 0 or stats["stale_archived"] > 0:
            self.store(
                f"memory_hygiene_{datetime.now().strftime('%Y%m%d')}",
                f"Cleaned brain: {stats['duplicates_merged']} duplicates merged, "
                f"{stats['stale_archived']} stale memories archived. "
                f"{stats['total_active']} active memories remaining.",
                "reference", "hygiene,maintenance,auto", 0.4
            )

        return {"status": "ok", **stats}


class PrincipleValidator(SkillWorkflow):
    """Test existing principles against recent outcomes.

    If a principle says "always use X approach" but recent episodes show
    X approach performing poorly, the principle needs updating.
    """
    name = "principle_validator"
    display_name = "Principle Validator"
    description = "Validate stored principles against actual task outcomes"
    category = "self_improvement"
    schedule_cron = "0 22 * * 3"  # Wednesday 10pm
    maps_to_skills = ["all"]

    def run(self) -> Dict:
        db = self._db()
        validated = 0
        invalidated = 0

        try:
            principles = db.execute(
                "SELECT id, task_type, principle, confidence FROM skill_principles "
                "WHERE status='active' ORDER BY confidence ASC LIMIT 20"
            ).fetchall()

            for p in principles:
                # Check recent episode outcomes for this task type
                episodes = db.execute(
                    "SELECT AVG(outcome_quality) as avg, COUNT(*) as cnt "
                    "FROM skill_episodes WHERE task_type=? "
                    "AND created_at >= datetime('now', '-30 days')",
                    (p["task_type"],)
                ).fetchone()

                if episodes and episodes["cnt"] >= 3:
                    avg = episodes["avg"]
                    if avg > 0.7:
                        # Task type performing well — boost principle confidence
                        new_conf = min(p["confidence"] + 0.05, 0.95)
                        db.execute(
                            "UPDATE skill_principles SET confidence=? WHERE id=?",
                            (new_conf, p["id"])
                        )
                        validated += 1
                    elif avg < 0.4:
                        # Task type performing poorly — flag principle
                        db.execute(
                            "UPDATE skill_principles SET status='review', confidence=? WHERE id=?",
                            (max(p["confidence"] - 0.1, 0.1), p["id"])
                        )
                        invalidated += 1

            db.commit()
        except Exception:
            pass

        return {"status": "ok", "validated": validated, "invalidated": invalidated}


class UserModelUpdater(SkillWorkflow):
    """Track changing user preferences and communication patterns."""
    name = "user_model"
    display_name = "User Model Updater"
    description = "Track evolving user preferences and communication style"
    category = "self_improvement"
    schedule_cron = "0 23 * * 0"  # Sunday 11pm
    maps_to_skills = ["self_model"]

    def run(self) -> Dict:
        db = self._db()

        # Aggregate preference-type memories
        prefs = []
        try:
            rows = db.execute(
                "SELECT name, content, updated FROM memories "
                "WHERE (type='preference' OR tags LIKE '%preference%' OR tags LIKE '%user%') "  # noqa:like-wildcard-injection
                "AND active=1 ORDER BY updated DESC LIMIT 30"
            ).fetchall()
            prefs = [dict(r) for r in rows]
        except Exception:
            pass

        # Compile user model
        model = f"# User Model\n"
        model += f"**Last updated:** {datetime.now().strftime('%Y-%m-%d')}\n"
        model += f"**Known preferences:** {len(prefs)}\n\n"

        categories = defaultdict(list)
        for p in prefs:
            tags = p.get("tags", "") if isinstance(p.get("tags"), str) else ""
            cat = "general"
            for t in tags.split(","):
                if t.strip() and t.strip() not in ("preference", "user", "auto"):
                    cat = t.strip()
                    break
            categories[cat].append(p)

        for cat, items in sorted(categories.items()):
            model += f"## {cat.title()}\n"
            for item in items[:5]:
                model += f"- {item['content'][:100]}\n"
            model += "\n"

        self.store("user_model", model, "agent", "user_model,preferences,auto", 0.8)
        return {"status": "ok", "preferences": len(prefs), "categories": len(categories)}


class SessionPreparation(SkillWorkflow):
    """Build a briefing document for the start of each session.

    Loads: self-model, active projects, pending decisions, recent learnings.
    This is what the agent reads first to establish continuity.
    """
    name = "session_prep"
    display_name = "Session Preparation"
    description = "Prepare comprehensive session briefing for continuity across conversations"
    category = "self_improvement"
    schedule_cron = "0 5 * * *"  # daily 5am
    maps_to_skills = ["self_model", "project_planning"]

    def run(self) -> Dict:
        db = self._db()

        # Load self-model
        self_model = ""
        try:
            row = db.execute(
                "SELECT content FROM memories WHERE name='self_model' AND active=1"
            ).fetchone()
            if row:
                self_model = row["content"][:500]
        except Exception:
            pass

        # Active projects
        projects = []
        try:
            rows = db.execute(
                "SELECT name, content FROM memories WHERE type='project' AND active=1 "
                "ORDER BY updated DESC LIMIT 5"
            ).fetchall()
            projects = [dict(r) for r in rows]
        except Exception:
            pass

        # Recent decisions
        decisions = self.search("decision", limit=5)

        # Today's priorities
        today_plan = []
        try:
            row = db.execute(
                "SELECT content FROM memories WHERE name LIKE 'daily_plan_%' "
                "AND active=1 ORDER BY created DESC LIMIT 1"
            ).fetchone()
            if row:
                today_plan = [row["content"][:300]]
        except Exception:
            pass

        briefing = f"# Session Briefing — {datetime.now().strftime('%Y-%m-%d %H:%M')}\n\n"

        if self_model:
            briefing += f"## Identity\n{self_model[:200]}\n\n"

        if projects:
            briefing += "## Active Projects\n"
            for p in projects:
                briefing += f"- **{p['name']}**: {p['content'][:80]}\n"
            briefing += "\n"

        if decisions:
            briefing += "## Recent Decisions\n"
            for d in decisions[:3]:
                briefing += f"- {d['content'][:80]}\n"
            briefing += "\n"

        if today_plan:
            briefing += "## Today's Plan\n"
            briefing += today_plan[0] + "\n"

        self.store("session_briefing", briefing, "agent",
                   "briefing,session,continuity,auto", 0.9)

        return {"status": "ok", "projects": len(projects),
                "decisions": len(decisions)}


# =========================================================================
# CATEGORY 2: SKILL EXECUTION — CODE & ARCHITECTURE (10)
# =========================================================================

class CodeReviewRunner(SkillWorkflow):
    """Execute the code_review skill against a codebase.

    Loads principles, prepares checklist, scans for common issues.
    """
    name = "code_review_runner"
    display_name = "Code Review Runner"
    description = "Execute systematic code review using learned principles and OWASP checklist"
    category = "code_architecture"
    schedule_cron = "0 9 * * 1-5"
    maps_to_skills = ["code_review", "security_assessment"]

    def run(self) -> Dict:
        principles = self.get_principles("code_review")
        security_principles = self.get_principles("security_assessment")

        checklist = "# Code Review Checklist\n\n"
        checklist += "## From Learned Principles\n"
        if principles:
            for p in principles:
                checklist += f"- [{p.get('confidence', 0):.0%}] {p['principle']}\n"
        else:
            checklist += "- [ ] Tests exist and pass\n"
            checklist += "- [ ] Error handling on all external calls\n"
            checklist += "- [ ] No hardcoded credentials or secrets\n"
            checklist += "- [ ] Input validation on all user-facing endpoints\n"
            checklist += "- [ ] SQL queries use parameterized statements\n"

        checklist += "\n## Security Checks\n"
        if security_principles:
            for p in security_principles[:5]:
                checklist += f"- [{p.get('confidence', 0):.0%}] {p['principle']}\n"
        else:
            checklist += "- [ ] OWASP Top 10 coverage\n"
            checklist += "- [ ] Authentication at every boundary\n"
            checklist += "- [ ] Authorization checks (not just auth)\n"
            checklist += "- [ ] No sensitive data in logs\n"

        self.store(f"review_checklist_{datetime.now().strftime('%Y%m%d')}",
                   checklist, "reference", "code_review,checklist,auto", 0.5)

        return {"status": "ok", "principles": len(principles),
                "security_checks": len(security_principles)}


class ArchitectureEvaluator(SkillWorkflow):
    """Evaluate codebase against architecture review scorecard."""
    name = "architecture_evaluator"
    display_name = "Architecture Evaluator"
    description = "Score codebase health against architecture review dimensions"
    category = "code_architecture"
    schedule_cron = "0 10 * * 1"
    maps_to_skills = ["code_architecture_review", "system_design"]

    def run(self) -> Dict:
        principles = self.get_principles("architecture_review")

        dimensions = [
            "Modularity", "Testability", "Dependency direction",
            "Error handling", "Configuration management",
            "Security boundaries", "Data integrity", "Scalability readiness"
        ]

        scorecard = "# Architecture Scorecard\n\n"
        scorecard += "| Dimension | Score (1-5) | Assessment |\n"
        scorecard += "|-----------|------------|------------|\n"
        for dim in dimensions:
            scorecard += f"| {dim} | _/5 | [Evaluate against codebase] |\n"

        if principles:
            scorecard += "\n## Learned Architecture Principles\n"
            for p in principles:
                scorecard += f"- {p['principle'][:100]}\n"

        self.store(f"arch_scorecard_{datetime.now().strftime('%Y%m%d')}",
                   scorecard, "reference", "architecture,scorecard,auto", 0.5)

        return {"status": "ok", "dimensions": len(dimensions)}


class TechDebtAnalyzer(SkillWorkflow):
    """Scan for technical debt indicators using the skill's categories."""
    name = "tech_debt_analyzer"
    display_name = "Technical Debt Analyzer"
    description = "Identify and categorize technical debt by type and remediation priority"
    category = "code_architecture"
    schedule_cron = "0 10 * * 1"
    maps_to_skills = ["technical_debt_assessment"]

    def run(self) -> Dict:
        db = self._db()

        # Look for debt-related memories
        debt_items = self.search("TODO", limit=20)
        debt_items += self.search("hack", limit=10)
        debt_items += self.search("workaround", limit=10)
        debt_items += self.search("technical debt", limit=10)

        report = f"# Tech Debt Inventory — {datetime.now().strftime('%Y-%m-%d')}\n\n"
        report += f"**{len(debt_items)} debt indicators found**\n\n"

        categories = {"deliberate": [], "inadvertent": [], "unknown": []}
        for item in debt_items:
            content_lower = item.get("content", "").lower()
            if any(w in content_lower for w in ["temporary", "shortcut", "quick fix", "todo"]):
                categories["deliberate"].append(item)
            elif any(w in content_lower for w in ["should have", "wrong", "bug", "broken"]):
                categories["inadvertent"].append(item)
            else:
                categories["unknown"].append(item)

        for cat, items in categories.items():
            if items:
                report += f"## {cat.title()} Debt ({len(items)})\n"
                for item in items[:10]:
                    report += f"- {item['name']}: {item['content'][:80]}\n"
                report += "\n"

        self.store(f"tech_debt_{datetime.now().strftime('%Y%m%d')}",
                   report, "reference", "tech_debt,analysis,auto", 0.6)

        return {"status": "ok", "debt_items": len(debt_items)}


class DependencyAuditRunner(SkillWorkflow):
    """Execute dependency audit using the skill's red-flag criteria."""
    name = "dependency_audit_runner"
    display_name = "Dependency Audit Runner"
    description = "Audit project dependencies for security, licensing, and maintenance risks"
    category = "code_architecture"
    schedule_cron = "0 10 * * 1"
    maps_to_skills = ["dependency_audit"]

    def run(self) -> Dict:
        principles = self.get_principles("dependency_audit")

        audit_template = "# Dependency Audit Template\n\n"
        audit_template += "## Red Flags to Check\n"

        if principles:
            for p in principles:
                audit_template += f"- {p['principle'][:100]}\n"
        else:
            audit_template += "- No commits in 2+ years\n"
            audit_template += "- Single maintainer with no succession\n"
            audit_template += "- Known CVEs without patches\n"
            audit_template += "- License incompatible with project\n"
            audit_template += "- Excessive transitive dependencies\n"
            audit_template += "- Dependency does one thing you could inline in 20 lines\n"

        audit_template += "\n## Audit Checklist\n"
        audit_template += "| Package | Version | Latest | CVEs | Last Update | License | Risk |\n"
        audit_template += "|---------|---------|--------|------|------------|---------|------|\n"
        audit_template += "| [fill] | | | | | | |\n"

        self.store(f"dep_audit_template_{datetime.now().strftime('%Y%m%d')}",
                   audit_template, "reference", "dependency,audit,template,auto", 0.5)

        return {"status": "ok", "principles": len(principles)}


class APIDocGenerator(SkillWorkflow):
    """Generate API documentation templates using the api_documentation skill."""
    name = "api_doc_generator"
    display_name = "API Documentation Generator"
    description = "Generate structured API documentation from endpoint definitions"
    category = "code_architecture"
    schedule_cron = "0 14 * * 5"
    maps_to_skills = ["api_documentation", "api_design"]

    def run(self) -> Dict:
        design_principles = self.get_principles("api_design")
        doc_principles = self.get_principles("api_documentation")

        # Search for API-related memories
        api_memories = self.search("endpoint", limit=20)
        api_memories += self.search("api", limit=20)

        doc = "# API Documentation Draft\n\n"
        if design_principles:
            doc += "## Design Principles\n"
            for p in design_principles[:5]:
                doc += f"- {p['principle'][:100]}\n"

        if api_memories:
            doc += "\n## Known Endpoints\n"
            seen = set()
            for m in api_memories:
                key = m.get("name", "")
                if key not in seen:
                    doc += f"- {key}: {m['content'][:80]}\n"
                    seen.add(key)
                if len(seen) >= 20:
                    break

        doc += "\n## Documentation Template Per Endpoint\n"
        doc += "```\n"
        doc += "### [Method] [Path]\n"
        doc += "[Description]\n\n"
        doc += "**Parameters:**\n| Name | Type | Required | Description |\n"
        doc += "**Response (200):** [example]\n"
        doc += "**Errors:** [error codes and messages]\n"
        doc += "**curl example:** [runnable command]\n"
        doc += "```\n"

        self.store(f"api_docs_{datetime.now().strftime('%Y%m%d')}",
                   doc, "reference", "api,documentation,auto", 0.5)

        return {"status": "ok", "endpoints_found": len(api_memories)}


class MigrationPlanner(SkillWorkflow):
    """Generate migration plans using the migration_planning skill."""
    name = "migration_planner"
    display_name = "Migration Planner"
    description = "Generate structured migration plans with rollback strategies"
    category = "code_architecture"
    schedule_cron = "0 10 * * 1"
    maps_to_skills = ["migration_planning"]

    def run(self) -> Dict:
        principles = self.get_principles("migration_planning")

        template = "# Migration Plan Template\n\n"
        template += "## Pre-Migration Checklist\n"
        template += "- [ ] Rollback plan written and tested\n"
        template += "- [ ] Success criteria defined\n"
        template += "- [ ] Monitoring alerts configured\n"
        template += "- [ ] Data backup taken\n"
        template += "- [ ] Maintenance window scheduled\n"
        template += "- [ ] Communication plan for stakeholders\n\n"

        if principles:
            template += "## Learned Migration Principles\n"
            for p in principles:
                template += f"- {p['principle'][:100]}\n"

        template += "\n## Strategy Options\n"
        template += "- Big Bang: all at once (fastest, highest risk)\n"
        template += "- Strangler Fig: gradual replacement (safest, slowest)\n"
        template += "- Blue-Green: parallel systems (requires 2x resources)\n"
        template += "- Feature Flags: per-feature behind flags (flexible, complex)\n"

        self.store("migration_template", template, "reference",
                   "migration,planning,template,auto", 0.5)

        return {"status": "ok", "principles": len(principles)}


class ErrorHandlingAuditor(SkillWorkflow):
    """Audit error handling patterns using the error_handling skill."""
    name = "error_handling_auditor"
    display_name = "Error Handling Auditor"
    description = "Check code patterns against error handling best practices"
    category = "code_architecture"
    schedule_cron = "0 10 * * 3"
    maps_to_skills = ["error_handling"]

    def run(self) -> Dict:
        principles = self.get_principles("error_handling")

        audit = "# Error Handling Audit Checklist\n\n"

        if principles:
            audit += "## Learned Principles\n"
            for p in principles:
                audit += f"- {p['principle'][:100]}\n"
        else:
            audit += "## Default Checks\n"
            audit += "- [ ] No bare except: or except Exception:\n"
            audit += "- [ ] All external calls wrapped in try/except\n"
            audit += "- [ ] Errors logged with context before handling\n"
            audit += "- [ ] User-facing errors separated from developer errors\n"
            audit += "- [ ] Retry logic has exponential backoff\n"
            audit += "- [ ] Graceful degradation for non-critical features\n"

        audit += "\n## Anti-Patterns to Flag\n"
        audit += "- `except: pass` — swallowed exception\n"
        audit += "- Retry without backoff — hammering a failing service\n"
        audit += "- Error message leaks internal paths or stack traces to user\n"
        audit += "- Catch-all exception hiding real bugs\n"

        self.store(f"error_audit_{datetime.now().strftime('%Y%m%d')}",
                   audit, "reference", "error_handling,audit,auto", 0.5)

        return {"status": "ok", "principles": len(principles)}


class TestStrategyGenerator(SkillWorkflow):
    """Generate testing strategy using the test_writing skill."""
    name = "test_strategy"
    display_name = "Test Strategy Generator"
    description = "Generate test plans with coverage targets and edge case identification"
    category = "code_architecture"
    schedule_cron = "0 9 * * 1"
    maps_to_skills = ["test_writing"]

    def run(self) -> Dict:
        principles = self.get_principles("test_writing")

        strategy = "# Test Strategy\n\n"
        strategy += "## Test Pyramid\n"
        strategy += "- Unit tests: 70% — single function, mocked deps, fast\n"
        strategy += "- Integration: 20% — multiple components, real DB\n"
        strategy += "- E2E/Smoke: 10% — full system, real endpoints\n\n"

        if principles:
            strategy += "## Learned Testing Principles\n"
            for p in principles:
                strategy += f"- {p['principle'][:100]}\n"

        strategy += "\n## Edge Cases to Always Test\n"
        strategy += "- Empty input, null, None\n"
        strategy += "- Max values, boundary conditions\n"
        strategy += "- Concurrent access\n"
        strategy += "- Authentication failure paths\n"
        strategy += "- Network timeout / connection refused\n"
        strategy += "- Malformed input (SQL injection, XSS payloads)\n"

        self.store(f"test_strategy_{datetime.now().strftime('%Y%m%d')}",
                   strategy, "reference", "testing,strategy,auto", 0.5)

        return {"status": "ok", "principles": len(principles)}


class RefactoringAdvisor(SkillWorkflow):
    """Identify refactoring opportunities using the code_refactoring skill."""
    name = "refactoring_advisor"
    display_name = "Refactoring Advisor"
    description = "Identify code smells and suggest refactoring priorities"
    category = "code_architecture"
    schedule_cron = "0 14 * * 3"
    maps_to_skills = ["code_refactoring"]

    def run(self) -> Dict:
        principles = self.get_principles("code_refactoring")

        guide = "# Refactoring Guide\n\n"
        guide += "## Code Smells to Look For\n"
        guide += "- Functions > 30 lines → extract method\n"
        guide += "- Duplicated code blocks → extract shared function\n"
        guide += "- Deep nesting (>3 levels) → early returns or extract\n"
        guide += "- Magic numbers → named constants\n"
        guide += "- God class (>500 lines) → split by responsibility\n"
        guide += "- Feature envy (method uses another class more than its own)\n\n"

        if principles:
            guide += "## Learned Refactoring Principles\n"
            for p in principles:
                guide += f"- {p['principle'][:100]}\n"

        guide += "\n## Safety Rules\n"
        guide += "- Tests must exist BEFORE refactoring\n"
        guide += "- One refactoring per commit\n"
        guide += "- Run tests after EVERY change\n"
        guide += "- Never refactor and add features in the same PR\n"

        self.store(f"refactoring_guide_{datetime.now().strftime('%Y%m%d')}",
                   guide, "reference", "refactoring,guide,auto", 0.5)

        return {"status": "ok", "principles": len(principles)}


class DatabaseSchemaReviewer(SkillWorkflow):
    """Review database schemas using the database_schema skill."""
    name = "db_schema_reviewer"
    display_name = "Database Schema Reviewer"
    description = "Audit database schemas for normalization, indexing, and naming consistency"
    category = "code_architecture"
    schedule_cron = "0 10 * * 2"
    maps_to_skills = ["database_schema"]

    def run(self) -> Dict:
        principles = self.get_principles("database_schema")

        checklist = "# Database Schema Review\n\n"
        checklist += "## Required Checks\n"
        checklist += "- [ ] Every table has: id (PK), created_at, updated_at\n"
        checklist += "- [ ] All foreign keys are indexed\n"
        checklist += "- [ ] NOT NULL on required columns\n"
        checklist += "- [ ] CHECK constraints on enum-like columns\n"
        checklist += "- [ ] Consistent naming (snake_case, plural tables, singular columns)\n"
        checklist += "- [ ] No FLOAT for money (use INTEGER cents)\n"
        checklist += "- [ ] Soft delete strategy (active/deleted_at column)\n"
        checklist += "- [ ] Indexes on columns used in WHERE/JOIN\n\n"

        if principles:
            checklist += "## Learned Schema Principles\n"
            for p in principles:
                checklist += f"- {p['principle'][:100]}\n"

        self.store(f"schema_review_{datetime.now().strftime('%Y%m%d')}",
                   checklist, "reference", "database,schema,review,auto", 0.5)

        return {"status": "ok", "principles": len(principles)}


# =========================================================================
# CATEGORY 3: SKILL EXECUTION — SECURITY & COMPLIANCE (10)
# =========================================================================

class SecurityAssessmentRunner(SkillWorkflow):
    """Execute the security assessment skill's OWASP Top 10 checklist."""
    name = "security_assessment_runner"
    display_name = "Security Assessment Runner"
    description = "Run systematic OWASP Top 10 security assessment checklist"
    category = "security_compliance"
    schedule_cron = "0 10 * * 1"
    maps_to_skills = ["security_assessment"]

    def run(self) -> Dict:
        principles = self.get_principles("security_assessment")
        scan_principles = self.get_principles("scan_injection")

        checklist = "# Security Assessment Checklist\n\n"
        checklist += "## OWASP Top 10 (2021)\n"
        owasp = [
            ("A01", "Broken Access Control", "IDOR, BFLA, missing function-level auth"),
            ("A02", "Cryptographic Failures", "Weak hashing, exposed secrets, HTTP without TLS"),
            ("A03", "Injection", "SQLi, XSS, CMDi, SSTI, XXE, LDAP injection"),
            ("A04", "Insecure Design", "Race conditions, mass assignment, missing rate limits"),
            ("A05", "Security Misconfiguration", "Default creds, verbose errors, missing headers"),
            ("A06", "Vulnerable Components", "Known CVEs in dependencies"),
            ("A07", "Auth Failures", "Weak passwords, missing MFA, session fixation"),
            ("A08", "Data Integrity Failures", "Insecure deserialization, unsigned updates"),
            ("A09", "Logging Failures", "No audit trail, sensitive data in logs"),
            ("A10", "SSRF", "Server-side request forgery, internal network access"),
        ]
        for code, name, desc in owasp:
            checklist += f"- [ ] **{code}: {name}** — {desc}\n"

        if principles:
            checklist += "\n## Learned Security Principles\n"
            for p in principles:
                checklist += f"- ({p.get('confidence', 0):.0%}) {p['principle'][:100]}\n"

        if scan_principles:
            checklist += "\n## Scanning Intelligence\n"
            for p in scan_principles[:5]:
                checklist += f"- {p['principle'][:100]}\n"

        self.store(f"security_checklist_{datetime.now().strftime('%Y%m%d')}",
                   checklist, "reference", "security,owasp,checklist,auto", 0.7)

        self.record_episode("security_assessment", "Generated OWASP checklist",
                           "checklist_generation", ["security_assessment_runner"],
                           0.7, ["owasp", "checklist"])

        return {"status": "ok", "owasp_items": 10, "principles": len(principles)}


class ThreatModelGenerator(SkillWorkflow):
    """Generate STRIDE threat models using the threat_modeling skill."""
    name = "threat_model_generator"
    display_name = "Threat Model Generator"
    description = "Generate STRIDE threat analysis for described systems"
    category = "security_compliance"
    schedule_cron = "0 10 * * 2"
    maps_to_skills = ["threat_modeling"]

    def run(self) -> Dict:
        principles = self.get_principles("threat_modeling")

        template = "# STRIDE Threat Model Template\n\n"
        template += "## 1. System Description\n[Describe the system here]\n\n"
        template += "## 2. Data Flow Diagram\n[Draw users, services, data stores, trust boundaries]\n\n"
        template += "## 3. STRIDE Analysis\n"

        stride = [
            ("Spoofing", "Can an attacker impersonate a user or service?"),
            ("Tampering", "Can data be modified in transit or at rest?"),
            ("Repudiation", "Can actions be denied (no audit trail)?"),
            ("Information Disclosure", "Can sensitive data leak?"),
            ("Denial of Service", "Can the system be made unavailable?"),
            ("Elevation of Privilege", "Can a low-privilege user gain admin?"),
        ]
        template += "| Threat | STRIDE | Component | Likelihood | Impact | Mitigation |\n"
        template += "|--------|--------|-----------|-----------|--------|------------|\n"
        for category, question in stride:
            template += f"| {question[:50]} | {category[0]} | [component] | H/M/L | H/M/L | [fix] |\n"

        if principles:
            template += "\n## Learned Threat Modeling Principles\n"
            for p in principles:
                template += f"- {p['principle'][:100]}\n"

        self.store("threat_model_template", template, "reference",
                   "threat_model,stride,template,auto", 0.6)

        return {"status": "ok", "stride_categories": 6}


class ComplianceMapper(SkillWorkflow):
    """Map findings to compliance frameworks using the compliance_mapping skill."""
    name = "compliance_mapper"
    display_name = "Compliance Mapper"
    description = "Map security findings to 15 regulatory compliance frameworks"
    category = "security_compliance"
    schedule_cron = "0 11 * * 1"
    maps_to_skills = ["compliance_mapping"]

    def run(self) -> Dict:
        # Load any findings from memory
        findings = self.search("finding", limit=50)
        findings += self.search("vulnerability", limit=50)

        frameworks = [
            "OWASP Top 10 2021", "PCI-DSS 4.0", "NIST 800-53",
            "Essential Eight", "ISO 27001", "SOC 2", "CWE Top 25",
            "GDPR", "HIPAA", "CIS Controls v8"
        ]

        report = f"# Compliance Status — {datetime.now().strftime('%Y-%m-%d')}\n\n"
        report += f"**Findings in brain:** {len(findings)}\n"
        report += f"**Frameworks tracked:** {len(frameworks)}\n\n"

        report += "## Framework Coverage\n"
        for fw in frameworks:
            report += f"- [ ] {fw}\n"

        if findings:
            # Categorize findings
            categories = Counter()
            for f in findings:
                content = f.get("content", "").lower()
                for cat in ["sqli", "xss", "csrf", "idor", "ssrf", "auth", "misconfig"]:
                    if cat in content:
                        categories[cat] += 1

            if categories:
                report += "\n## Finding Categories\n"
                for cat, count in categories.most_common():
                    report += f"- {cat}: {count} findings\n"

        principles = self.get_principles("compliance_mapping")
        if principles:
            report += "\n## Compliance Mapping Principles\n"
            for p in principles:
                report += f"- {p['principle'][:100]}\n"

        self.store(f"compliance_status_{datetime.now().strftime('%Y%m%d')}",
                   report, "reference", "compliance,mapping,auto", 0.6)

        return {"status": "ok", "findings": len(findings), "frameworks": len(frameworks)}


class IncidentResponseRunner(SkillWorkflow):
    """Generate incident response playbooks using the incident_response skill."""
    name = "incident_response_runner"
    display_name = "Incident Response Runner"
    description = "Generate structured incident response plans and postmortem templates"
    category = "security_compliance"
    schedule_cron = "0 9 * * 1"
    maps_to_skills = ["incident_response"]

    def run(self) -> Dict:
        principles = self.get_principles("incident_response")

        playbook = "# Incident Response Playbook\n\n"
        playbook += "## Severity Levels\n"
        playbook += "| Level | Definition | Response Time |\n"
        playbook += "|-------|-----------|---------------|\n"
        playbook += "| SEV-1 | Service down / data breach | Immediate |\n"
        playbook += "| SEV-2 | Degraded / potential breach | < 1 hour |\n"
        playbook += "| SEV-3 | Minor issue, no user impact | < 4 hours |\n\n"

        playbook += "## Response Flow\n"
        playbook += "1. Detect & Classify\n"
        playbook += "2. Contain (stop bleeding, preserve evidence)\n"
        playbook += "3. Communicate (facts, not speculation)\n"
        playbook += "4. Investigate (what, when, how, impact)\n"
        playbook += "5. Remediate (root cause, not symptom)\n"
        playbook += "6. Recover (restore normal operations)\n"
        playbook += "7. Review (blameless postmortem within 48h)\n\n"

        if principles:
            playbook += "## Learned IR Principles\n"
            for p in principles:
                playbook += f"- {p['principle'][:100]}\n"

        self.store("incident_playbook", playbook, "reference",
                   "incident_response,playbook,auto", 0.7)

        return {"status": "ok", "principles": len(principles)}


class PerformanceProfiler(SkillWorkflow):
    """Identify performance bottlenecks using the performance_optimization skill."""
    name = "performance_profiler"
    display_name = "Performance Profiler"
    description = "Systematic performance bottleneck identification checklist"
    category = "security_compliance"
    schedule_cron = "0 14 * * 2"
    maps_to_skills = ["performance_optimization"]

    def run(self) -> Dict:
        principles = self.get_principles("performance_optimization")

        guide = "# Performance Optimization Guide\n\n"
        guide += "## Bottleneck Identification (check in order)\n"
        guide += "1. **Database** — slow queries, missing indexes, N+1 problems\n"
        guide += "2. **Network** — excessive API calls, large payloads, no compression\n"
        guide += "3. **Memory** — leaks, growing collections, no bounds\n"
        guide += "4. **CPU** — unnecessary computation, missing caching\n"
        guide += "5. **I/O** — synchronous file operations, blocking reads\n\n"

        guide += "## Common Fixes\n"
        guide += "- N+1 queries → eager loading / batch fetch\n"
        guide += "- Missing indexes → EXPLAIN, add indexes on WHERE columns\n"
        guide += "- Large payloads → paginate, compress, select only needed fields\n"
        guide += "- Sync I/O → async/await, connection pooling\n"
        guide += "- Redundant computation → memoize, cache, precompute\n\n"

        guide += "## Golden Rule\n"
        guide += "**MEASURE before optimizing.** Profile first, optimize the bottleneck, measure after.\n"

        if principles:
            guide += "\n## Learned Performance Principles\n"
            for p in principles:
                guide += f"- {p['principle'][:100]}\n"

        self.store(f"perf_guide_{datetime.now().strftime('%Y%m%d')}",
                   guide, "reference", "performance,optimization,auto", 0.5)

        return {"status": "ok", "principles": len(principles)}


class RiskAssessmentRunner(SkillWorkflow):
    """Execute risk assessment using the risk_assessment skill framework."""
    name = "risk_assessment_runner"
    display_name = "Risk Assessment Runner"
    description = "Generate risk registers and mitigation strategies"
    category = "security_compliance"
    schedule_cron = "0 10 * * 1"
    maps_to_skills = ["risk_assessment"]

    def run(self) -> Dict:
        # Load project risks from memory
        risks = self.search("risk", limit=20)
        principles = self.get_principles("risk_assessment")

        template = "# Risk Register\n\n"
        template += "| ID | Risk | Probability | Impact | Level | Mitigation | Owner |\n"
        template += "|----|------|-----------|--------|-------|-----------|-------|\n"

        if risks:
            for i, r in enumerate(risks[:10], 1):
                template += f"| R-{i:03d} | {r['content'][:50]} | _/H/M/L | _/H/M/L | _ | [plan] | [owner] |\n"
        else:
            template += "| R-001 | [Describe risk] | H/M/L | H/M/L | _ | [plan] | [owner] |\n"

        template += "\n## Response Strategies\n"
        template += "- **Avoid**: eliminate by changing the plan\n"
        template += "- **Mitigate**: reduce probability or impact\n"
        template += "- **Transfer**: insurance, contracts, SLAs\n"
        template += "- **Accept**: acknowledge and monitor\n"

        if principles:
            template += "\n## Learned Risk Principles\n"
            for p in principles:
                template += f"- {p['principle'][:100]}\n"

        self.store(f"risk_register_{datetime.now().strftime('%Y%m%d')}",
                   template, "reference", "risk,assessment,register,auto", 0.6)

        return {"status": "ok", "known_risks": len(risks)}


class ADRWriter(SkillWorkflow):
    """Generate Architecture Decision Records using the ADR skill."""
    name = "adr_writer"
    display_name = "ADR Writer"
    description = "Generate architecture decision record templates from discussion context"
    category = "security_compliance"
    schedule_cron = "0 16 * * 5"
    maps_to_skills = ["architecture_decision_records"]

    def run(self) -> Dict:
        # Find recent decisions in memory
        decisions = self.search("decision", limit=10)
        decisions += self.search("chose", limit=10)
        decisions += self.search("decided", limit=10)

        template = "# ADR Template\n\n"
        template += "## ADR-[NUMBER]: [Title]\n\n"
        template += "**Status:** [Proposed | Accepted | Deprecated]\n\n"
        template += "### Context\n[What issue are we facing? 2-3 paragraphs max.]\n\n"
        template += "### Decision\n[What did we decide?]\n\n"
        template += "### Alternatives Considered\n"
        template += "#### Option A: [Name]\n- Pros: [list]\n- Cons: [list]\n- Why rejected: [1 sentence]\n\n"
        template += "### Consequences\n- Positive: [what gets better]\n- Negative: [what gets harder]\n- Risks: [what could go wrong]\n\n"
        template += "### Review Date\n[When to revisit]\n\n"

        if decisions:
            template += "---\n\n## Recent Decisions to Document\n"
            seen = set()
            for d in decisions:
                key = d.get("name", "")
                if key not in seen:
                    template += f"- {key}: {d['content'][:80]}\n"
                    seen.add(key)

        self.store("adr_template", template, "reference",
                   "adr,architecture,decisions,auto", 0.5)

        return {"status": "ok", "undocumented_decisions": len(decisions)}


class OnboardingDocBuilder(SkillWorkflow):
    """Generate onboarding documentation from project context."""
    name = "onboarding_builder"
    display_name = "Onboarding Doc Builder"
    description = "Create onboarding guides from accumulated project knowledge"
    category = "security_compliance"
    schedule_cron = "0 10 * * 5"
    maps_to_skills = ["onboarding_guide"]

    def run(self) -> Dict:
        # Gather project context
        projects = self.search("project", limit=10)
        setup = self.search("setup", limit=10)
        tools = self.search("tool", limit=10)

        guide = "# Onboarding Guide (Auto-Generated)\n\n"
        guide += "## Day 1: Get Set Up\n"

        if setup:
            for s in setup[:5]:
                guide += f"- {s['content'][:80]}\n"
        else:
            guide += "- [ ] Clone the repo\n"
            guide += "- [ ] Install dependencies\n"
            guide += "- [ ] Run locally\n"
            guide += "- [ ] Access staging environment\n"

        if tools:
            guide += "\n## Tools & Services\n"
            for t in tools[:10]:
                guide += f"- {t['name']}: {t['content'][:60]}\n"

        if projects:
            guide += "\n## Active Projects\n"
            for p in projects[:5]:
                guide += f"- {p['name']}: {p['content'][:80]}\n"

        self.store("onboarding_guide", guide, "reference",
                   "onboarding,guide,auto", 0.5)

        return {"status": "ok", "sections": 3}


class ReleaseNotesWriter(SkillWorkflow):
    """Generate release notes from recent changes."""
    name = "release_notes_writer"
    display_name = "Release Notes Writer"
    description = "Generate structured release notes from change memories"
    category = "security_compliance"
    schedule_cron = "0 15 * * 5"
    maps_to_skills = ["release_notes"]

    def run(self) -> Dict:
        changes = self.search("feat", limit=10)
        changes += self.search("fix", limit=10)
        changes += self.search("change", limit=10)

        features = [c for c in changes if "feat" in c.get("tags", "")]
        fixes = [c for c in changes if "fix" in c.get("tags", "")]
        other = [c for c in changes if c not in features and c not in fixes]

        notes = f"# Release Notes — {datetime.now().strftime('%Y-%m-%d')}\n\n"
        if features:
            notes += "## New Features\n"
            for f in features[:10]:
                notes += f"- **{f['name']}**: {f['content'][:80]}\n"
        if fixes:
            notes += "\n## Bug Fixes\n"
            for f in fixes[:10]:
                notes += f"- {f['name']}: {f['content'][:80]}\n"
        if other:
            notes += "\n## Other Changes\n"
            for o in other[:10]:
                notes += f"- {o['name']}: {o['content'][:80]}\n"

        self.store(f"release_notes_{datetime.now().strftime('%Y%m%d')}",
                   notes, "reference", "release_notes,auto", 0.5)

        return {"status": "ok", "features": len(features), "fixes": len(fixes)}


class TroubleshootingGuideWriter(SkillWorkflow):
    """Build troubleshooting guides from incident history."""
    name = "troubleshooting_writer"
    display_name = "Troubleshooting Guide Writer"
    description = "Generate troubleshooting guides from past incidents and error patterns"
    category = "security_compliance"
    schedule_cron = "0 14 * * 5"
    maps_to_skills = ["troubleshooting_guide"]

    def run(self) -> Dict:
        errors = self.search("error", limit=20)
        errors += self.search("bug", limit=10)
        errors += self.search("issue", limit=10)

        guide = "# Troubleshooting Guide (Auto-Generated)\n\n"

        if errors:
            # Group by topic
            topics = defaultdict(list)
            for e in errors:
                topic = e.get("tags", "general").split(",")[0].strip() or "general"
                topics[topic].append(e)

            for topic, items in sorted(topics.items()):
                guide += f"## {topic.title()}\n"
                for item in items[:5]:
                    guide += f"### {item['name']}\n"
                    guide += f"**Problem:** {item['content'][:100]}\n"
                    guide += f"**Fix:** [Document the resolution]\n\n"
        else:
            guide += "No error patterns found in memory yet.\n"
            guide += "Store errors with tags 'error' to build this guide automatically.\n"

        self.store("troubleshooting_guide", guide, "reference",
                   "troubleshooting,guide,auto", 0.5)

        return {"status": "ok", "error_patterns": len(errors)}


# =========================================================================
# CATEGORY 4: INTELLIGENCE & RESEARCH (10)
# =========================================================================

class AutonomousResearcher(SkillWorkflow):
    """Conduct multi-source research on configured topics."""
    name = "autonomous_researcher"
    display_name = "Autonomous Researcher"
    description = "Conduct systematic multi-source research on topics of interest"
    category = "intelligence"
    schedule_cron = "0 8 * * 1,3,5"
    maps_to_skills = ["autonomous_research", "research_synthesis"]

    def run(self) -> Dict:
        topics = self.get_config("research_topics",
            "AI agent memory,retrieval augmented generation,MCP protocol").split(",")
        topics = [t.strip() for t in topics if t.strip()]

        # Search memories for existing knowledge per topic
        report = f"# Research Status — {datetime.now().strftime('%Y-%m-%d')}\n\n"
        for topic in topics:
            existing = self.search(topic, limit=10)
            report += f"## {topic}\n"
            report += f"**Existing knowledge:** {len(existing)} memories\n"
            if existing:
                for m in existing[:3]:
                    report += f"- {m['content'][:80]}\n"
            else:
                report += "- ⚠️ No knowledge stored — needs research\n"
            report += "\n"

        self.store(f"research_status_{datetime.now().strftime('%Y%m%d')}",
                   report, "reference", "research,status,auto", 0.5)

        return {"status": "ok", "topics": len(topics)}


class KnowledgeGraphBuilder(SkillWorkflow):
    """Extract entities and relationships from stored memories."""
    name = "knowledge_graph_builder"
    display_name = "Knowledge Graph Builder"
    description = "Extract entities and relationships from memories into structured knowledge"
    category = "intelligence"
    schedule_cron = "0 22 * * 0"
    maps_to_skills = ["knowledge_graph_building"]

    def run(self) -> Dict:
        db = self._db()

        # Extract entities from recent memories
        entities = Counter()
        relationships = []
        try:
            rows = db.execute(
                "SELECT content FROM memories WHERE active=1 "
                "AND created >= datetime('now', '-7 days') LIMIT 100"
            ).fetchall()

            for row in rows:
                content = row["content"]
                # Extract capitalized phrases (likely entities)
                caps = re.findall(r'\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\b', content)
                for cap in caps:
                    if len(cap) > 2 and cap not in ("The", "This", "That", "What", "When", "Where"):
                        entities[cap] += 1

                # Extract simple relationships
                for pattern in [r'(\w+)\s+(?:uses|runs|depends on|built with)\s+(\w+)',
                               r'(\w+)\s+(?:is a|is the|works at)\s+(\w+)']:
                    matches = re.findall(pattern, content, re.IGNORECASE)
                    relationships.extend(matches)

        except Exception:
            pass

        report = f"# Knowledge Graph — {datetime.now().strftime('%Y-%m-%d')}\n\n"
        report += f"**Entities:** {len(entities)}\n"
        report += f"**Relationships:** {len(relationships)}\n\n"

        if entities:
            report += "## Top Entities\n"
            for entity, count in entities.most_common(20):
                report += f"- {entity} (mentioned {count}x)\n"

        if relationships:
            report += "\n## Relationships\n"
            seen = set()
            for subj, obj in relationships[:20]:
                key = f"{subj}→{obj}"
                if key not in seen:
                    report += f"- {subj} → {obj}\n"
                    seen.add(key)

        self.store(f"knowledge_graph_{datetime.now().strftime('%Y_W%W')}",
                   report, "reference", "knowledge_graph,entities,auto", 0.5)

        return {"status": "ok", "entities": len(entities), "relationships": len(relationships)}


class CompetitiveIntelligence(SkillWorkflow):
    """Track competitor activity and market positioning."""
    name = "competitive_intelligence"
    display_name = "Competitive Intelligence"
    description = "Monitor competitors and analyze market positioning"
    category = "intelligence"
    schedule_cron = "0 9 * * 1"
    maps_to_skills = ["competitive_analysis"]

    def run(self) -> Dict:
        principles = self.get_principles("competitive_analysis")
        competitors = self.search("competitor", limit=20)

        report = f"# Competitive Intelligence — {datetime.now().strftime('%Y-%m-%d')}\n\n"

        if competitors:
            report += "## Known Competitors\n"
            for c in competitors:
                report += f"- {c['name']}: {c['content'][:80]}\n"
        else:
            report += "No competitor data stored. Add memories tagged 'competitor'.\n"

        if principles:
            report += "\n## Analysis Framework\n"
            for p in principles:
                report += f"- {p['principle'][:100]}\n"

        report += "\n## Analysis Template\n"
        report += "| Competitor | Strength | Weakness | Our Advantage |\n"
        report += "|-----------|----------|----------|---------------|\n"

        self.store(f"competitive_intel_{datetime.now().strftime('%Y%m%d')}",
                   report, "reference", "competitive,intelligence,auto", 0.6)

        return {"status": "ok", "competitors_tracked": len(competitors)}


class DataAnalysisRunner(SkillWorkflow):
    """Execute data analysis using the data_analysis skill framework."""
    name = "data_analysis_runner"
    display_name = "Data Analysis Runner"
    description = "Run systematic data analysis using learned principles and checklists"
    category = "intelligence"
    schedule_cron = "0 14 * * 1"
    maps_to_skills = ["data_analysis"]

    def run(self) -> Dict:
        principles = self.get_principles("data_analysis")

        checklist = "# Data Analysis Checklist\n\n"
        checklist += "## 1. Understand the Data\n"
        checklist += "- [ ] Shape: rows, columns, types\n"
        checklist += "- [ ] Missing values: count and pattern\n"
        checklist += "- [ ] Distributions: normal? skewed? outliers?\n\n"

        checklist += "## 2. Find Patterns\n"
        checklist += "- [ ] Correlations: what moves together?\n"
        checklist += "- [ ] Time trends: increasing? seasonal?\n"
        checklist += "- [ ] Segments: different group behaviors?\n"
        checklist += "- [ ] Anomalies: data points that don't fit?\n\n"

        checklist += "## 3. Present Findings\n"
        checklist += "- [ ] Every finding answers 'so what?'\n"
        checklist += "- [ ] Numbers are specific, not vague\n"
        checklist += "- [ ] Assumptions and limitations stated\n"

        if principles:
            checklist += "\n## Learned Analysis Principles\n"
            for p in principles:
                checklist += f"- {p['principle'][:100]}\n"

        self.store(f"analysis_checklist_{datetime.now().strftime('%Y%m%d')}",
                   checklist, "reference", "data_analysis,checklist,auto", 0.5)

        return {"status": "ok", "principles": len(principles)}


class PromptEngineeringLab(SkillWorkflow):
    """Test and refine prompt patterns using the prompt_engineering skill."""
    name = "prompt_lab"
    display_name = "Prompt Engineering Lab"
    description = "Track prompt patterns, test effectiveness, and build prompt library"
    category = "intelligence"
    schedule_cron = "0 16 * * 5"
    maps_to_skills = ["prompt_engineering"]

    def run(self) -> Dict:
        principles = self.get_principles("prompt_engineering")
        prompts = self.search("prompt", limit=20)

        library = f"# Prompt Library — {datetime.now().strftime('%Y-%m-%d')}\n\n"
        library += f"**Stored prompts:** {len(prompts)}\n\n"

        if principles:
            library += "## Learned Prompt Principles\n"
            for p in principles:
                library += f"- ({p.get('confidence', 0):.0%}) {p['principle'][:100]}\n"

        library += "\n## Core Prompt Patterns\n"
        library += "1. **Specify output format** — JSON, table, list, etc.\n"
        library += "2. **Provide examples** — 2-3 input/output pairs\n"
        library += "3. **Chain of thought** — 'Think step by step'\n"
        library += "4. **Separate instructions from data** — XML tags, delimiters\n"
        library += "5. **Constrain output** — enums, max length, required fields\n"

        if prompts:
            library += "\n## Stored Prompt Templates\n"
            for p in prompts[:10]:
                library += f"- **{p['name']}**: {p['content'][:80]}\n"

        self.store("prompt_library", library, "reference",
                   "prompts,engineering,library,auto", 0.5)

        return {"status": "ok", "prompts": len(prompts)}


class TrendDetector(SkillWorkflow):
    """Identify emerging patterns across stored memories."""
    name = "trend_detector"
    display_name = "Trend Detector"
    description = "Identify emerging patterns and trends across accumulated knowledge"
    category = "intelligence"
    schedule_cron = "0 21 * * 0"
    maps_to_skills = ["research_synthesis"]

    def run(self) -> Dict:
        db = self._db()

        # Find topics growing in frequency
        recent_tags = Counter()
        older_tags = Counter()

        try:
            recent = db.execute(
                "SELECT tags FROM memories WHERE active=1 "
                "AND created >= datetime('now', '-7 days')"
            ).fetchall()
            for r in recent:
                for tag in (r["tags"] or "").split(","):
                    tag = tag.strip()
                    if tag and tag != "auto":
                        recent_tags[tag] += 1

            older = db.execute(
                "SELECT tags FROM memories WHERE active=1 "
                "AND created >= datetime('now', '-30 days') "
                "AND created < datetime('now', '-7 days')"
            ).fetchall()
            for r in older:
                for tag in (r["tags"] or "").split(","):
                    tag = tag.strip()
                    if tag and tag != "auto":
                        older_tags[tag] += 1
        except Exception:
            pass

        # Find trending topics (appearing more in recent vs older)
        trending = []
        for tag, count in recent_tags.most_common(50):
            old_count = older_tags.get(tag, 0)
            if count > old_count * 1.5 and count >= 3:
                trending.append({"tag": tag, "recent": count, "older": old_count})

        report = f"# Trend Analysis — {datetime.now().strftime('%Y-%m-%d')}\n\n"

        if trending:
            report += "## Trending Topics (growing this week)\n"
            for t in trending[:10]:
                report += f"- **{t['tag']}**: {t['recent']} mentions this week (was {t['older']} last 3 weeks)\n"
        else:
            report += "No significant trends detected this week.\n"

        report += f"\n## Most Active Topics\n"
        for tag, count in recent_tags.most_common(10):
            report += f"- {tag}: {count} mentions\n"

        self.store(f"trends_{datetime.now().strftime('%Y_W%W')}",
                   report, "reference", "trends,analysis,auto", 0.5)

        return {"status": "ok", "trending": len(trending)}


class SystemDesignRunner(SkillWorkflow):
    """Generate system design documents using the system_design skill."""
    name = "system_design_runner"
    display_name = "System Design Runner"
    description = "Generate structured system design documents with tradeoff analysis"
    category = "intelligence"
    schedule_cron = "0 10 * * 2"
    maps_to_skills = ["system_design"]

    def run(self) -> Dict:
        principles = self.get_principles("system_design")

        template = "# System Design Template\n\n"
        template += "## 1. Requirements\n"
        template += "- Functional: [what it does]\n"
        template += "- Non-functional: QPS, latency, availability, consistency\n\n"
        template += "## 2. Scale Estimates\n"
        template += "- Users, QPS, storage, bandwidth\n\n"
        template += "## 3. API Design\n"
        template += "- [endpoint definitions]\n\n"
        template += "## 4. Data Model\n"
        template += "- [schema + access patterns]\n\n"
        template += "## 5. Architecture\n"
        template += "- [components + data flow diagram]\n\n"
        template += "## 6. Tradeoffs\n"
        template += "| Decision | Chosen | Alternative | Why |\n"
        template += "|----------|--------|------------|-----|\n\n"

        template += "## Common Patterns\n"
        template += "- Read-heavy: cache + CDN + read replicas\n"
        template += "- Write-heavy: WAL + async + event queue\n"
        template += "- Search: inverted index (ES) or FTS5\n"
        template += "- Real-time: WebSocket + pub/sub\n"

        if principles:
            template += "\n## Learned Design Principles\n"
            for p in principles:
                template += f"- {p['principle'][:100]}\n"

        self.store("system_design_template", template, "reference",
                   "system_design,template,auto", 0.5)

        return {"status": "ok", "principles": len(principles)}


class ProjectPlanningRunner(SkillWorkflow):
    """Generate project plans using the project_planning skill."""
    name = "project_planning_runner"
    display_name = "Project Planning Runner"
    description = "Generate structured project plans with phases, risks, and milestones"
    category = "intelligence"
    schedule_cron = "0 9 * * 1"
    maps_to_skills = ["project_planning"]

    def run(self) -> Dict:
        principles = self.get_principles("project_planning")
        projects = self.search("project", limit=10)

        plan = f"# Project Planning — {datetime.now().strftime('%Y-%m-%d')}\n\n"

        if projects:
            plan += "## Active Projects\n"
            for p in projects[:5]:
                plan += f"- **{p['name']}**: {p['content'][:80]}\n"

        plan += "\n## Planning Template\n"
        plan += "1. Define the outcome — what does 'done' look like?\n"
        plan += "2. Work backwards from deadline\n"
        plan += "3. Break into phases with demo-able deliverables\n"
        plan += "4. Estimate honestly (then multiply by 1.5)\n"
        plan += "5. Identify dependencies and blockers\n"
        plan += "6. Define the MVP — smallest version that delivers value\n"

        if principles:
            plan += "\n## Learned Planning Principles\n"
            for p in principles:
                plan += f"- {p['principle'][:100]}\n"

        self.store(f"project_plan_{datetime.now().strftime('%Y%m%d')}",
                   plan, "reference", "planning,projects,auto", 0.5)

        return {"status": "ok", "active_projects": len(projects)}


class TechnicalWritingAssistant(SkillWorkflow):
    """Generate writing frameworks using the technical_writing skill."""
    name = "technical_writing_assistant"
    display_name = "Technical Writing Assistant"
    description = "Generate structured technical writing templates and style guides"
    category = "intelligence"
    schedule_cron = "0 9 * * 1"
    maps_to_skills = ["technical_writing", "documentation_writing"]

    def run(self) -> Dict:
        principles = self.get_principles("technical_writing")
        doc_principles = self.get_principles("documentation_writing")

        guide = "# Technical Writing Guide\n\n"
        guide += "## Core Rules\n"
        guide += "- Name your reader — who specifically are you writing for?\n"
        guide += "- One idea per paragraph\n"
        guide += "- Concrete before abstract — example first, then principle\n"
        guide += "- Active voice — 'the server processes' not 'is processed by'\n"
        guide += "- Short sentences for complex ideas\n\n"

        guide += "## Structure Templates\n"
        guide += "### Tutorial\n"
        guide += "1. What you'll build (result first)\n"
        guide += "2. Prerequisites\n"
        guide += "3. Step-by-step with code\n"
        guide += "4. Why each step matters\n"
        guide += "5. Common errors + fixes\n"
        guide += "6. Next steps\n\n"

        guide += "### Technical Blog Post\n"
        guide += "1. Hook (the problem or surprising result)\n"
        guide += "2. Context (why this matters)\n"
        guide += "3. Approach (what you did)\n"
        guide += "4. Results (with data)\n"
        guide += "5. Honest limitations\n"
        guide += "6. Conclusion + CTA\n"

        all_principles = principles + doc_principles
        if all_principles:
            guide += "\n## Learned Writing Principles\n"
            for p in all_principles[:10]:
                guide += f"- {p['principle'][:100]}\n"

        self.store("writing_guide", guide, "reference",
                   "writing,technical,guide,auto", 0.5)

        return {"status": "ok", "principles": len(all_principles)}


class InterviewPrepBuilder(SkillWorkflow):
    """Generate interview preparation materials using the interview_preparation skill."""
    name = "interview_prep_builder"
    display_name = "Interview Prep Builder"
    description = "Generate STAR stories, company research briefs, and question banks from context"
    category = "intelligence"
    schedule_cron = "0 8 * * *"
    maps_to_skills = ["interview_preparation", "research_synthesis"]

    def run(self) -> Dict:
        principles = self.get_principles("interview_preparation")

        # Search for interview-related context
        company_info = self.search("company", limit=10)
        role_info = self.search("role", limit=10)
        experience = self.search("experience", limit=10)

        prep = f"# Interview Preparation — {datetime.now().strftime('%Y-%m-%d')}\n\n"

        if company_info:
            prep += "## Company Research\n"
            for c in company_info[:5]:
                prep += f"- {c['content'][:80]}\n"

        prep += "\n## STAR Story Template\n"
        prep += "**Situation:** [2 sentences — set the scene]\n"
        prep += "**Task:** [1 sentence — your responsibility]\n"
        prep += "**Action:** [3-4 sentences — what YOU did (not 'we')]\n"
        prep += "**Result:** [1-2 sentences — quantified outcome]\n"
        prep += "**Learning:** [1 sentence — what you'd do differently]\n\n"

        prep += "## Question Categories to Prepare\n"
        prep += "- Technical depth (your expertise area)\n"
        prep += "- System design (architecture thinking)\n"
        prep += "- Behavioral (leadership, conflict, failure)\n"
        prep += "- Culture fit (why this company)\n"
        prep += "- Reverse questions (what YOU ask them)\n"

        if principles:
            prep += "\n## Learned Interview Principles\n"
            for p in principles:
                prep += f"- {p['principle'][:100]}\n"

        self.store(f"interview_prep_{datetime.now().strftime('%Y%m%d')}",
                   prep, "reference", "interview,preparation,auto", 0.6)

        return {"status": "ok", "company_context": len(company_info),
                "principles": len(principles)}


# =========================================================================
# REGISTRY
# =========================================================================

SKILL_WORKFLOW_REGISTRY: Dict[str, type] = {
    # Self-Improvement
    "skill_sharpener": SkillSharpener,
    "self_model_refresh": SelfModelRefresh,
    "knowledge_gap_detector": KnowledgeGapDetector,
    "correction_learner": CorrectionLearner,
    "task_briefing": TaskBriefingGenerator,
    "task_retrospective": TaskRetrospective,
    "memory_hygiene": MemoryHygiene,
    "principle_validator": PrincipleValidator,
    "user_model": UserModelUpdater,
    "session_prep": SessionPreparation,
    # Code & Architecture
    "code_review_runner": CodeReviewRunner,
    "architecture_evaluator": ArchitectureEvaluator,
    "tech_debt_analyzer": TechDebtAnalyzer,
    "dependency_audit_runner": DependencyAuditRunner,
    "api_doc_generator": APIDocGenerator,
    "migration_planner": MigrationPlanner,
    "error_handling_auditor": ErrorHandlingAuditor,
    "test_strategy": TestStrategyGenerator,
    "refactoring_advisor": RefactoringAdvisor,
    "db_schema_reviewer": DatabaseSchemaReviewer,
    # Security & Compliance
    "security_assessment_runner": SecurityAssessmentRunner,
    "threat_model_generator": ThreatModelGenerator,
    "compliance_mapper": ComplianceMapper,
    "incident_response_runner": IncidentResponseRunner,
    "performance_profiler": PerformanceProfiler,
    "risk_assessment_runner": RiskAssessmentRunner,
    "adr_writer": ADRWriter,
    "onboarding_builder": OnboardingDocBuilder,
    "release_notes_writer": ReleaseNotesWriter,
    "troubleshooting_writer": TroubleshootingGuideWriter,
    # Intelligence & Research
    "autonomous_researcher": AutonomousResearcher,
    "knowledge_graph_builder": KnowledgeGraphBuilder,
    "competitive_intelligence": CompetitiveIntelligence,
    "data_analysis_runner": DataAnalysisRunner,
    "prompt_lab": PromptEngineeringLab,
    "trend_detector": TrendDetector,
    "system_design_runner": SystemDesignRunner,
    "project_planning_runner": ProjectPlanningRunner,
    "technical_writing_assistant": TechnicalWritingAssistant,
    "interview_prep_builder": InterviewPrepBuilder,
}


def seed_skill_workflows(db_path: str) -> int:
    """Register all skill workflows. Called by `aibrain init`."""
    conn = sqlite3.connect(db_path, check_same_thread=False)
    count = 0
    for name, cls in SKILL_WORKFLOW_REGISTRY.items():
        try:
            conn.execute("""
                INSERT OR REPLACE INTO workflows
                (name, display_name, category, description, cron_schedule, enabled, source)
                VALUES (?, ?, ?, ?, ?, 0, 'builtin_skill')
            """, (cls.name, cls.display_name, cls.category, cls.description, cls.schedule_cron))
            count += 1
        except Exception as e:
            log.error("Failed to seed %s: %s", name, e)
    conn.commit()
    conn.close()
    return count


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print(f"Skill Workflows ({len(SKILL_WORKFLOW_REGISTRY)}):\n")
        for cat in ["self_improvement", "code_architecture", "security_compliance", "intelligence"]:
            workflows = {k: v for k, v in SKILL_WORKFLOW_REGISTRY.items() if v.category == cat}
            print(f"  [{cat}] ({len(workflows)})")
            for name, cls in workflows.items():
                skills = ", ".join(cls.maps_to_skills[:3]) if cls.maps_to_skills else "—"
                print(f"    {name:35s} → skills: {skills}")
            print()
    else:
        wf_name = sys.argv[1]
        from aibrain_db import AIBRAIN_ROOT
        db = sys.argv[3] if "--db" in sys.argv else str(AIBRAIN_ROOT / "aibrain.db")
        cls = SKILL_WORKFLOW_REGISTRY.get(wf_name)
        if cls:
            wf = cls(db)
            result = wf.run()
            print(json.dumps(result, indent=2))
        else:
            print(f"Unknown workflow: {wf_name}")
