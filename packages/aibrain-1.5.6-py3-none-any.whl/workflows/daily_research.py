#!/usr/bin/env python3
"""AIBrain Workflow: Daily Research — aggregates news from free APIs, emails digest.

Evolution-integrated: tracks topic engagement, source quality, and proposes
hypotheses to the evolution engine so the digest improves over time.
"""

import argparse
import datetime
import json
import os
import smtplib
import sqlite3
import sys
import time
import urllib.request
from email.mime.text import MIMEText
from pathlib import Path

import requests
from bs4 import BeautifulSoup

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

# ---------------------------------------------------------------------------
# Config & DB helpers
# ---------------------------------------------------------------------------

from aibrain_db import AIBRAIN_ROOT, get_db
_cfg_path = AIBRAIN_ROOT / "config.json"
CONFIG = json.loads(_cfg_path.read_text()) if _cfg_path.exists() else {}
def _find_db():
    """Find best DB path, checking both new and legacy names."""
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    configured = CONFIG.get("db_path")
    if configured and Path(configured).exists():
        return configured
    mem_db = AIBRAIN_ROOT / "memory" / "memory.db"
    if mem_db.exists():
        return str(mem_db)
    return str(AIBRAIN_ROOT / "aibrain.db")

MEMORY_DB = CONFIG.get("db_path", _find_db())
EVOLUTION_DB = str(AIBRAIN_ROOT / "aibrain.db")
API_BASE = os.environ.get("AIBRAIN_API", os.environ.get("AIBRAIN_API", "http://localhost:8001/api/agent"))

DEFAULT_CATEGORIES = [
    {"name": "Cybersecurity", "queries": ["cybersecurity", "zero day", "CVE"], "subreddits": ["netsec", "cybersecurity"]},
    {"name": "AI & ML", "queries": ["artificial intelligence", "LLM", "machine learning"], "subreddits": ["MachineLearning", "artificial"]},
    {"name": "Software Dev", "queries": ["programming", "devops", "software engineering"], "subreddits": ["programming", "devops"]},
    {"name": "Startups & Tech", "queries": ["startup", "tech industry", "venture capital"], "subreddits": ["startups", "technology"]},
    {"name": "Privacy & OSINT", "queries": ["OSINT", "privacy", "surveillance"], "subreddits": ["OSINT", "privacy"]},
]

def log_activity(action, detail="", status="ok"):
    """Log activity to AIBrain API."""
    try:
        data = json.dumps({
            "action": action, "category": "research",
            "detail": detail, "status": status,
        }).encode()
        req = urllib.request.Request(
            f"{API_BASE}/activity", data=data,
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass


HEADERS = {"User-Agent": "AIBrain/1.0 (research digest)"}

# How many runs before a zero-engagement topic gets demoted
DEMOTION_THRESHOLD = 5
# How many runs between hypothesis proposals
HYPOTHESIS_INTERVAL = 10


def get_db():
    db = get_db()
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    return db


def load_state(name):
    try:
        db = get_db()
        row = db.execute(
            "SELECT content FROM memories WHERE name=? AND active=1",
            (f"workflow_state:{name}",),
        ).fetchone()
        db.close()
        return json.loads(row["content"]) if row else {}
    except Exception:
        return {}


def save_state(name, state):
    db = get_db()
    try:
        now = datetime.datetime.now().isoformat()
        existing = db.execute(
            "SELECT id FROM memories WHERE name=? AND active=1",
            (f"workflow_state:{name}",),
        ).fetchone()
        if existing:
            db.execute("UPDATE memories SET content=?, updated=? WHERE id=?",
                       (json.dumps(state), now, existing["id"]))
        else:
            db.execute(
                "INSERT INTO memories (name,type,tags,content,created,updated,active) VALUES (?,?,?,?,?,?,1)",
                (f"workflow_state:{name}", "reference", "workflow,state",
                 json.dumps(state), now, now),
            )
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def send_email(to, subject, body, dry_run=False):
    if dry_run:
        print(f"TO: {to}\nSUBJECT: {subject}\n\n{body}")
        return
    agent_email = CONFIG.get("agent_email", "aibrain@localhost")
    agent_password = CONFIG.get("agent_email_password", CONFIG.get("email_app_password", ""))
    msg = MIMEText(body, "plain")
    msg["From"] = agent_email
    msg["To"] = to
    msg["Subject"] = subject
    with smtplib.SMTP_SSL(CONFIG.get("agent_smtp_host", CONFIG.get("email_smtp_host", "smtp.gmail.com")), 465) as s:
        s.login(agent_email, agent_password)
        s.send_message(msg)


# ---------------------------------------------------------------------------
# Evolution Engine integration (lightweight, fail-safe)
# ---------------------------------------------------------------------------

def _get_evolution_db():
    """Open evolution DB via canonical get_db(). Returns None if unavailable."""
    try:
        return get_db()
    except Exception as e:
        print(f"  Evolution DB unavailable: {e}", file=sys.stderr)
        return None


def record_evolution_outcome(action, result, details=None, duration_seconds=None):
    """Record a workflow outcome in the evolution engine. Fails silently."""
    try:
        db = _get_evolution_db()
        if db is None:
            return None
        # Check table exists before inserting
        tables = [r[0] for r in db.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()]
        if "evolution_outcomes" not in tables:
            db.close()
            return None
        cur = db.execute(
            """INSERT INTO evolution_outcomes
               (source, source_id, action, result, details, failure_reason, duration_seconds)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            ("workflow", "daily_research", action, result, details, None, duration_seconds)
        )
        db.commit()
        outcome_id = cur.lastrowid
        db.close()
        return outcome_id
    except Exception as e:
        print(f"  Evolution outcome recording failed: {e}", file=sys.stderr)
        return None


def record_evolution_pattern(pattern_text, severity="low"):
    """Record a pattern observation in the evolution engine. Fails silently."""
    try:
        db = _get_evolution_db()
        if db is None:
            return None
        tables = [r[0] for r in db.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()]
        if "evolution_patterns" not in tables:
            db.close()
            return None
        # Check if similar pattern exists
        existing = db.execute(
            "SELECT id, frequency FROM evolution_patterns WHERE pattern LIKE ? AND status = 'active'",
            (f"%{pattern_text[:80]}%",)
        ).fetchone()
        if existing:
            db.execute(
                "UPDATE evolution_patterns SET frequency = ?, last_seen = CURRENT_TIMESTAMP WHERE id = ?",
                (existing["frequency"] + 1, existing["id"])
            )
            db.commit()
            pattern_id = existing["id"]
        else:
            cur = db.execute(
                """INSERT INTO evolution_patterns (pattern, frequency, severity)
                   VALUES (?, 1, ?)""",
                (pattern_text, severity)
            )
            db.commit()
            pattern_id = cur.lastrowid
        db.close()
        return pattern_id
    except Exception as e:
        print(f"  Evolution pattern recording failed: {e}", file=sys.stderr)
        return None


def propose_evolution_hypothesis(pattern_id, hypothesis, impact=0.5, confidence=0.5):
    """Propose an improvement hypothesis. Fails silently."""
    try:
        db = _get_evolution_db()
        if db is None:
            return None
        tables = [r[0] for r in db.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()]
        if "evolution_hypotheses" not in tables:
            db.close()
            return None
        cur = db.execute(
            """INSERT INTO evolution_hypotheses
               (pattern_id, hypothesis, change_type, target, impact_score, confidence, proposed_change)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (pattern_id, hypothesis, "workflow", "workflows/daily_research.py",
             min(1.0, max(0.0, impact)), min(1.0, max(0.0, confidence)),
             json.dumps({"auto_generated": True, "source": "daily_research_evolution"}))
        )
        db.commit()
        hyp_id = cur.lastrowid
        db.close()
        return hyp_id
    except Exception as e:
        print(f"  Evolution hypothesis proposal failed: {e}", file=sys.stderr)
        return None


# ---------------------------------------------------------------------------
# State management for evolution tracking
# ---------------------------------------------------------------------------

def _default_evolution_state():
    """Return a clean evolution state structure."""
    return {
        "last_run": None,
        "run_count": 0,
        "topic_engagement": {},
        "source_quality": {},
        "last_hypothesis_run": 0,
        "run_history": [],  # last 20 run summaries for trend analysis
    }


def _merge_evolution_state(existing):
    """Ensure all required keys exist in loaded state."""
    defaults = _default_evolution_state()
    for key, val in defaults.items():
        if key not in existing:
            existing[key] = val
    return existing


def update_topic_shown(state, cat_name):
    """Increment the 'shown' counter for a topic."""
    if cat_name not in state["topic_engagement"]:
        state["topic_engagement"][cat_name] = {"shown": 0, "engaged": 0}
    state["topic_engagement"][cat_name]["shown"] += 1


def record_topic_engagement(state, cat_name, engaged=True):
    """Record that user engaged (or did not engage) with a topic."""
    if cat_name not in state["topic_engagement"]:
        state["topic_engagement"][cat_name] = {"shown": 0, "engaged": 0}
    if engaged:
        state["topic_engagement"][cat_name]["engaged"] += 1


def update_source_quality(state, source_name, items_returned):
    """Track how many items a source returned (0 = miss, >0 = hit)."""
    if source_name not in state["source_quality"]:
        state["source_quality"][source_name] = {"attempts": 0, "hits": 0}
    state["source_quality"][source_name]["attempts"] += 1
    if items_returned > 0:
        state["source_quality"][source_name]["hits"] += 1


def get_source_hit_rate(state, source_name):
    """Return hit rate for a source (0.0 to 1.0). Default 1.0 for unknown."""
    sq = state.get("source_quality", {}).get(source_name, {})
    attempts = sq.get("attempts", 0)
    if attempts < 3:
        return 1.0  # not enough data yet
    return sq.get("hits", 0) / attempts


def get_topic_engagement_rate(state, cat_name):
    """Return engagement rate for a topic (0.0 to 1.0). Default 0.5 for unknown."""
    te = state.get("topic_engagement", {}).get(cat_name, {})
    shown = te.get("shown", 0)
    if shown < 3:
        return 0.5  # not enough data yet
    return te.get("engaged", 0) / shown


def should_demote_topic(state, cat_name):
    """Return True if a topic has zero engagement after DEMOTION_THRESHOLD runs."""
    te = state.get("topic_engagement", {}).get(cat_name, {})
    shown = te.get("shown", 0)
    engaged = te.get("engaged", 0)
    return shown >= DEMOTION_THRESHOLD and engaged == 0


# ---------------------------------------------------------------------------
# Data sources (all free, no API keys)
# ---------------------------------------------------------------------------

def fetch_hackernews(query, limit=5):
    """Fetch top HN stories matching query."""
    items = []
    try:
        resp = requests.get("https://hacker-news.firebaseio.com/v0/topstories.json", headers=HEADERS, timeout=10)
        story_ids = resp.json()[:30]  # check top 30
        for sid in story_ids:
            time.sleep(0.2)  # rate limit
            item = requests.get(f"https://hacker-news.firebaseio.com/v0/item/{sid}.json", headers=HEADERS, timeout=5).json()
            title = item.get("title", "")
            if any(q.lower() in title.lower() for q in query if len(q) > 3):
                items.append({
                    "title": title,
                    "url": item.get("url", f"https://news.ycombinator.com/item?id={sid}"),
                    "score": item.get("score", 0),
                    "source": "Hacker News",
                })
            if len(items) >= limit:
                break
    except Exception as e:
        print(f"  HN error: {e}", file=sys.stderr)
    return items


def fetch_reddit(subreddits, limit=5):
    """Fetch top posts from subreddits."""
    items = []
    for sub in subreddits[:2]:  # max 2 subreddits per category
        try:
            time.sleep(1)  # Reddit rate limit
            resp = requests.get(
                f"https://www.reddit.com/r/{sub}/hot.json?limit=10",
                headers=HEADERS, timeout=10,
            )
            if resp.status_code == 429:
                print(f"  Reddit rate limited on r/{sub}", file=sys.stderr)
                continue
            data = resp.json()
            for post in data.get("data", {}).get("children", []):
                pd = post["data"]
                if pd.get("stickied"):
                    continue
                items.append({
                    "title": pd.get("title", ""),
                    "url": f"https://reddit.com{pd.get('permalink', '')}",
                    "score": pd.get("score", 0),
                    "source": f"r/{sub}",
                })
        except Exception as e:
            print(f"  Reddit error (r/{sub}): {e}", file=sys.stderr)
    items.sort(key=lambda x: x["score"], reverse=True)
    return items[:limit]


def fetch_arxiv(query, limit=5):
    """Fetch recent ArXiv papers."""
    items = []
    try:
        q = "+".join(query[:2])  # use first 2 query terms
        url = f"http://export.arxiv.org/api/query?search_query=all:{q}&sortBy=submittedDate&max_results={limit}"
        resp = requests.get(url, headers=HEADERS, timeout=10)
        soup = BeautifulSoup(resp.text, "xml")
        for entry in soup.find_all("entry"):
            title = entry.find("title").text.strip().replace("\n", " ")
            link = entry.find("id").text.strip()
            summary = entry.find("summary").text.strip()[:150].replace("\n", " ")
            items.append({
                "title": title,
                "url": link,
                "summary": summary,
                "source": "ArXiv",
            })
    except Exception as e:
        print(f"  ArXiv error: {e}", file=sys.stderr)
    return items


# ---------------------------------------------------------------------------
# Main logic
# ---------------------------------------------------------------------------

def select_categories(categories, day_of_week, state=None):
    """Rotate categories by day. Monday=all, Tue-Fri=2 per day.

    If evolution state is available, boost high-engagement categories and
    demote zero-engagement ones by adjusting which get selected on non-Monday days.
    """
    if day_of_week == 0:  # Monday
        return categories
    if day_of_week >= 5:  # Weekend — skip
        return []

    # Base selection: rotate through pairs
    idx = ((day_of_week - 1) * 2) % len(categories)
    base = [categories[idx % len(categories)], categories[(idx + 1) % len(categories)]]

    if state is None:
        return base

    # Evolution-aware selection: if a base pick should be demoted, swap it
    boosted = _get_boosted_categories(categories, state)
    result = []
    for cat in base:
        cat_name = cat["name"]
        if should_demote_topic(state, cat_name) and boosted:
            # Replace demoted topic with highest-engagement alternative
            replacement = boosted.pop(0)
            if replacement["name"] != cat_name:
                print(f"  [evolution] Demoting '{cat_name}' (zero engagement), "
                      f"boosting '{replacement['name']}'")
                result.append(replacement)
                continue
        result.append(cat)

    return result


def _get_boosted_categories(categories, state):
    """Return categories sorted by engagement rate (highest first), excluding demoted."""
    scored = []
    for cat in categories:
        name = cat["name"]
        if should_demote_topic(state, name):
            continue
        rate = get_topic_engagement_rate(state, name)
        scored.append((rate, cat))
    scored.sort(key=lambda x: x[0], reverse=True)
    return [cat for _, cat in scored]


def format_report(results, state=None):
    """Format the research digest. Includes evolution stats if available."""
    now = datetime.datetime.now()
    lines = [
        f"DAILY RESEARCH DIGEST — {now.strftime('%A %B %d, %Y')}",
        "=" * 50,
        "",
    ]

    for cat_name, items in results.items():
        lines.append(f"--- {cat_name} ({len(items)} items) ---")
        if not items:
            lines.append("  No relevant items found today.")
            lines.append("")
            continue
        for item in items:
            lines.append(f"  [{item['source']}] {item['title']}")
            lines.append(f"  {item['url']}")
            if item.get("summary"):
                lines.append(f"  {item['summary']}")
            if item.get("score"):
                lines.append(f"  Score: {item['score']}")
            lines.append("")

    total = sum(len(items) for items in results.values())
    lines.append(f"Total: {total} items across {len(results)} categories")

    # Append evolution insights if we have enough data
    if state and state.get("run_count", 0) >= 5:
        lines.append("")
        lines.append("--- Evolution Insights ---")
        te = state.get("topic_engagement", {})
        for cat_name in sorted(te.keys()):
            stats = te[cat_name]
            shown = stats.get("shown", 0)
            engaged = stats.get("engaged", 0)
            rate = f"{engaged}/{shown}" if shown > 0 else "n/a"
            lines.append(f"  {cat_name}: engagement {rate}")
        sq = state.get("source_quality", {})
        low_quality = [s for s, v in sq.items()
                       if v.get("attempts", 0) >= 5 and v["hits"] / max(1, v["attempts"]) < 0.3]
        if low_quality:
            lines.append(f"  Low-quality sources: {', '.join(low_quality)}")

    lines.append("—\nPowered by AIBrain (HN + Reddit + ArXiv — all free, no keys)")
    return "\n".join(lines)


def _record_run_observation(state, results, duration_seconds):
    """Record an evolution observation for this run."""
    now = datetime.datetime.now().isoformat()
    run_count = state.get("run_count", 0)

    # Build per-category stats
    cat_stats = {}
    for cat_name, items in results.items():
        word_count = sum(
            len(item.get("title", "").split()) + len(item.get("summary", "").split())
            for item in items
        )
        cat_stats[cat_name] = {
            "item_count": len(items),
            "word_count": word_count,
        }

    total_items = sum(len(v) for v in results.values())
    details = json.dumps({
        "run_count": run_count,
        "categories": cat_stats,
        "total_items": total_items,
        "delivery_time": now,
    })

    # Record outcome in evolution engine
    result_status = "success" if total_items > 0 else "partial"
    record_evolution_outcome(
        action=f"daily_research_run_{run_count}",
        result=result_status,
        details=details,
        duration_seconds=duration_seconds,
    )

    # Record pattern observation for source quality
    for source_name, sq in state.get("source_quality", {}).items():
        attempts = sq.get("attempts", 0)
        hits = sq.get("hits", 0)
        if attempts >= 10 and hits / max(1, attempts) < 0.2:
            record_evolution_pattern(
                f"Research source '{source_name}' has low hit rate "
                f"({hits}/{attempts} = {hits/max(1,attempts):.0%})",
                severity="medium",
            )

    # Record pattern for zero-engagement topics
    for cat_name in state.get("topic_engagement", {}):
        if should_demote_topic(state, cat_name):
            record_evolution_pattern(
                f"Research topic '{cat_name}' has zero engagement after "
                f"{state['topic_engagement'][cat_name]['shown']} runs",
                severity="low",
            )

    # Append to run_history (keep last 20)
    history = state.get("run_history", [])[-20:]
    history.append({
        "timestamp": now,
        "run_count": run_count,
        "total_items": total_items,
        "categories": list(results.keys()),
        "duration_seconds": duration_seconds,
    })
    state["run_history"] = history[-20:]

    return details


def _maybe_propose_hypothesis(state):
    """Every HYPOTHESIS_INTERVAL runs, analyze trends and propose a hypothesis."""
    run_count = state.get("run_count", 0)
    last_hyp = state.get("last_hypothesis_run", 0)

    if run_count - last_hyp < HYPOTHESIS_INTERVAL:
        return

    print(f"  [evolution] Run {run_count}: checking for hypothesis proposals...")

    te = state.get("topic_engagement", {})
    if not te:
        return

    # Find highest and lowest engagement categories
    rates = {}
    for cat_name, stats in te.items():
        shown = stats.get("shown", 0)
        if shown < 3:
            continue
        rates[cat_name] = stats.get("engaged", 0) / shown

    if len(rates) < 2:
        return

    best = max(rates, key=rates.get)
    worst = min(rates, key=rates.get)
    best_rate = rates[best]
    worst_rate = rates[worst]

    # Propose hypothesis if there's a meaningful gap
    if best_rate > 0 and best_rate >= worst_rate * 2:
        ratio = best_rate / max(0.01, worst_rate)
        hypothesis = (
            f"Category '{best}' should be weighted higher in daily research — "
            f"it gets {ratio:.1f}x the engagement of '{worst}' "
            f"({best_rate:.0%} vs {worst_rate:.0%} over {te[best]['shown']} runs)"
        )
        # Record pattern first
        pattern_id = record_evolution_pattern(
            f"Research engagement disparity: '{best}' ({best_rate:.0%}) vs '{worst}' ({worst_rate:.0%})",
            severity="low",
        )
        if pattern_id:
            propose_evolution_hypothesis(
                pattern_id=pattern_id,
                hypothesis=hypothesis,
                impact=min(0.8, 0.3 + (ratio - 1) * 0.1),  # higher ratio = higher impact
                confidence=min(0.9, 0.4 + te[best]["shown"] * 0.02),  # more data = higher confidence
            )
            print(f"  [evolution] Proposed: {hypothesis}")

    # Also check source quality trends
    sq = state.get("source_quality", {})
    for source, stats in sq.items():
        attempts = stats.get("attempts", 0)
        hits = stats.get("hits", 0)
        if attempts >= 10 and hits / max(1, attempts) < 0.2:
            hypothesis = (
                f"Source '{source}' should be deprioritized — "
                f"only {hits}/{attempts} successful fetches ({hits/max(1,attempts):.0%} hit rate)"
            )
            pattern_id = record_evolution_pattern(
                f"Research source '{source}' consistently low quality",
                severity="medium",
            )
            if pattern_id:
                propose_evolution_hypothesis(
                    pattern_id=pattern_id,
                    hypothesis=hypothesis,
                    impact=0.4,
                    confidence=min(0.9, 0.5 + attempts * 0.01),
                )
                print(f"  [evolution] Proposed: {hypothesis}")

    state["last_hypothesis_run"] = run_count


def record_feedback(category_name, engaged=True):
    """CLI entry point to record engagement feedback for a category.

    Usage: python daily_research.py --feedback "AI & ML"
           python daily_research.py --feedback "AI & ML" --no-engage
    """
    state = load_state("daily_research")
    state = _merge_evolution_state(state)
    record_topic_engagement(state, category_name, engaged=engaged)
    save_state("daily_research", state)
    action = "engaged" if engaged else "not engaged"
    print(f"Recorded: user {action} with '{category_name}'")
    print(f"  Current stats: {state['topic_engagement'].get(category_name, {})}")


def main():
    parser = argparse.ArgumentParser(description="AIBrain Daily Research")
    parser.add_argument("--dry-run", action="store_true", help="Print instead of emailing")
    parser.add_argument("--all", action="store_true", help="Fetch all categories regardless of day")
    parser.add_argument("--feedback", type=str, metavar="CATEGORY",
                        help="Record engagement feedback for a category")
    parser.add_argument("--no-engage", action="store_true",
                        help="With --feedback, mark as NOT engaged (default is engaged)")
    parser.add_argument("--show-state", action="store_true",
                        help="Print current evolution state and exit")
    args = parser.parse_args()

    # --- Feedback mode ---
    if args.feedback:
        record_feedback(args.feedback, engaged=not args.no_engage)
        return

    # --- Load and merge evolution state ---
    state = load_state("daily_research")
    state = _merge_evolution_state(state)

    # --- Show state mode ---
    if args.show_state:
        print(json.dumps(state, indent=2))
        return

    categories = CONFIG.get("research_categories", DEFAULT_CATEGORIES)
    email_to = CONFIG.get("email_to", CONFIG.get("agent_email", ""))

    dow = datetime.datetime.now().weekday()
    if args.all:
        selected = categories
    else:
        selected = select_categories(categories, dow, state=state)

    if not selected:
        print("Weekend — no research digest today.")
        return

    run_start = time.time()
    state["run_count"] = state.get("run_count", 0) + 1
    run_count = state["run_count"]
    print(f"Fetching {len(selected)} categories (run #{run_count})...")

    results = {}
    for cat in selected:
        cat_name = cat["name"]
        print(f"  {cat_name}...")
        items = []

        # Track topic as shown
        update_topic_shown(state, cat_name)

        # HN — check source quality before fetching
        hn_rate = get_source_hit_rate(state, "hackernews")
        if hn_rate >= 0.1:  # only skip if truly broken (< 10% hit rate)
            hn = fetch_hackernews(cat.get("queries", []))
            update_source_quality(state, "hackernews", len(hn))
            items.extend(hn)
        else:
            print(f"    [evolution] Skipping HN (hit rate {hn_rate:.0%})")

        # Reddit — check source quality
        reddit_rate = get_source_hit_rate(state, "reddit")
        if reddit_rate >= 0.1:
            reddit = fetch_reddit(cat.get("subreddits", []))
            update_source_quality(state, "reddit", len(reddit))
            items.extend(reddit)
        else:
            print(f"    [evolution] Skipping Reddit (hit rate {reddit_rate:.0%})")

        # ArXiv (only for research-heavy categories) — check source quality
        if cat_name in ("AI & ML", "Cybersecurity", "Privacy & OSINT"):
            arxiv_rate = get_source_hit_rate(state, "arxiv")
            if arxiv_rate >= 0.1:
                arxiv = fetch_arxiv(cat.get("queries", []))
                update_source_quality(state, "arxiv", len(arxiv))
                items.extend(arxiv)
            else:
                print(f"    [evolution] Skipping ArXiv (hit rate {arxiv_rate:.0%})")

        # Deduplicate by URL
        seen = set()
        unique = []
        for item in items:
            if item["url"] not in seen:
                seen.add(item["url"])
                unique.append(item)
        results[cat_name] = unique

    duration = time.time() - run_start
    report = format_report(results, state=state)

    if not email_to or args.dry_run:
        print(report)
    else:
        total = sum(len(v) for v in results.values())
        send_email(email_to, f"Research Digest — {total} items", report)
        print(f"Sent research digest ({total} items) to {email_to}")

    # --- Evolution: record observation and update state ---
    state["last_run"] = datetime.datetime.now().isoformat()
    state["categories_fetched"] = [c["name"] for c in selected]

    _record_run_observation(state, results, duration)
    _maybe_propose_hypothesis(state)

    save_state("daily_research", state)
    total = sum(len(v) for v in results.values())
    log_activity("daily_research", f"Run #{run_count}: {total} items across {len(selected)} categories in {duration:.1f}s")

    print(f"  Run #{run_count} complete in {duration:.1f}s. "
          f"State saved with {len(state.get('topic_engagement', {}))} tracked topics, "
          f"{len(state.get('source_quality', {}))} tracked sources.")


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name='daily_research',
        action=_workflow_entry,
        task_type='judgment',
        actor='cli',
    )
