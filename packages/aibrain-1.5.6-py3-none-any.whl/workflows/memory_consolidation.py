"""
Memory Consolidation — nightly "sleep cycle" for the brain.

Five-step process:
1. CLUSTER — group active memories by type + embedding similarity (>0.80)
2. MERGE   — consolidate clusters of 3+ into single entries
3. DECAY   — reduce storage_strength for memories not accessed in 30+ days
4. ARCHIVE — archive memories with combined retention < 0.05
5. REBUILD — regenerate all category_summaries from active memories

Idempotent: running twice produces the same result (skips already-consolidated
and already-superseded entries).

Usage:
    python -m aibrain.core.workflow_runner memory_consolidation
    python workflows/memory_consolidation.py --dry-run
    python workflows/memory_consolidation.py --verbose
"""

import argparse
import json
import logging
import os
import struct
import sqlite3
import sys
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

from aibrain.core.memory_decay import compute_decay_score

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

# --- Path setup ---
from aibrain_db import AIBRAIN_ROOT
if str(AIBRAIN_ROOT) not in sys.path:
    sys.path.insert(0, str(AIBRAIN_ROOT))

import aibrain_db

logger = logging.getLogger("aibrain.consolidation")

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

SIMILARITY_THRESHOLD = 0.80   # cosine similarity for clustering
MIN_CLUSTER_SIZE = 3          # minimum cluster size to trigger merge
# DECAY_DAYS and DECAY_RATE removed — replaced by Ebbinghaus curve from memory_decay.py
# Old cliff: zero decay before 30 days, then linear at 0.05/day past threshold.
# New curve: R = exp(-t/S) via compute_decay_score(); new_strength = max(0.1, R * 10.0)
DECAY_FLOOR = 0.1             # minimum storage_strength after decay (survival threshold)
ARCHIVE_RETENTION = 0.05      # combined retention below this => archive


# ---------------------------------------------------------------------------
# Step 1: CLUSTER
# ---------------------------------------------------------------------------

def _get_active_memories(db: sqlite3.Connection) -> list[dict]:
    """Fetch all active, non-superseded, non-consolidated memories."""
    rows = db.execute("""
        SELECT m.id, m.name, m.type, m.content, m.importance,
               m.storage_strength, m.access_count, m.last_accessed,
               m.created, m.updated, m.status, m.consolidated_from
        FROM memories m
        WHERE m.active = 1
          AND m.status = 'active'
          AND (m.consolidated_from IS NULL OR m.consolidated_from = '')
    """).fetchall()
    return [dict(r) for r in rows]


def _get_embedding(db: sqlite3.Connection, memory_id: int) -> bytes | None:
    """Get raw embedding bytes for a memory from the vec table."""
    try:
        row = db.execute(
            "SELECT embedding FROM memories_vec WHERE memory_id = ?",
            (memory_id,)
        ).fetchone()
        return row[0] if row else None
    except Exception:
        return None


def _cosine_sim_from_bytes(a: bytes, b: bytes) -> float:
    """Compute cosine similarity between two embedding byte blobs.

    Assumes normalized embeddings (dot product = cosine similarity).
    """
    if not a or not b or len(a) != len(b):
        return 0.0
    dim = len(a) // 4  # float32
    va = struct.unpack(f"{dim}f", a)
    vb = struct.unpack(f"{dim}f", b)
    return sum(x * y for x, y in zip(va, vb))


def cluster_memories(db: sqlite3.Connection) -> dict[str, list[list[dict]]]:
    """Group active memories by type, then by embedding similarity.

    Returns: {type: [[mem1, mem2, mem3, ...], [memA, memB, memC, ...], ...]}
    Only includes clusters with >= MIN_CLUSTER_SIZE members.
    """
    memories = _get_active_memories(db)

    # Group by type first
    by_type: dict[str, list[dict]] = defaultdict(list)
    for m in memories:
        by_type[m["type"]].append(m)

    # Load embeddings
    embeddings: dict[int, bytes] = {}
    for m in memories:
        emb = _get_embedding(db, m["id"])
        if emb:
            embeddings[m["id"]] = emb

    all_clusters: dict[str, list[list[dict]]] = {}

    for mem_type, mems in by_type.items():
        # Filter to memories with embeddings for clustering
        with_emb = [m for m in mems if m["id"] in embeddings]

        if len(with_emb) < MIN_CLUSTER_SIZE:
            continue

        # Single-linkage clustering with similarity threshold
        clusters = _single_linkage_cluster(with_emb, embeddings)

        # Only keep clusters >= MIN_CLUSTER_SIZE
        valid = [c for c in clusters if len(c) >= MIN_CLUSTER_SIZE]
        if valid:
            all_clusters[mem_type] = valid

    return all_clusters


def _single_linkage_cluster(
    mems: list[dict], embeddings: dict[int, bytes]
) -> list[list[dict]]:
    """Simple single-linkage agglomerative clustering.

    A memory joins a cluster if it has >= SIMILARITY_THRESHOLD similarity
    with ANY member already in that cluster.
    """
    clusters: list[list[dict]] = []

    for m in mems:
        emb = embeddings[m["id"]]
        placed = False

        for cluster in clusters:
            for member in cluster:
                member_emb = embeddings[member["id"]]
                sim = _cosine_sim_from_bytes(emb, member_emb)
                if sim >= SIMILARITY_THRESHOLD:
                    cluster.append(m)
                    placed = True
                    break
            if placed:
                break

        if not placed:
            clusters.append([m])

    return clusters


# ---------------------------------------------------------------------------
# Step 2: MERGE
# ---------------------------------------------------------------------------

def merge_clusters(
    db: sqlite3.Connection, clusters: dict[str, list[list[dict]]], dry_run: bool = False
) -> list[dict]:
    """For each cluster, create one consolidated memory and supersede sources.

    Returns list of merge actions taken.
    """
    actions = []

    for mem_type, type_clusters in clusters.items():
        for cluster in type_clusters:
            if len(cluster) < MIN_CLUSTER_SIZE:
                continue

            source_ids = [m["id"] for m in cluster]
            max_importance = max(m.get("importance") or 0.5 for m in cluster)
            sum_storage = min(
                sum((m.get("storage_strength") or 1.0) for m in cluster),
                100.0,
            )

            # Concatenate key facts from cluster members
            contents = []
            for m in cluster:
                content = (m.get("content") or "").strip()
                if content:
                    contents.append(content)
            merged_content = " | ".join(contents)
            merged_name = f"[consolidated] {contents[0][:80]}" if contents else "[consolidated]"

            action = {
                "type": mem_type,
                "source_ids": source_ids,
                "merged_content_preview": merged_content[:200],
                "importance": max_importance,
                "storage_strength": sum_storage,
            }

            if not dry_run:
                new_id = _create_consolidated(
                    db,
                    name=merged_name[:120],
                    mem_type=mem_type,
                    content=merged_content,
                    importance=max_importance,
                    storage_strength=sum_storage,
                    source_ids=source_ids,
                )
                action["new_id"] = new_id

                # Mark sources as superseded
                for sid in source_ids:
                    db.execute(
                        "UPDATE memories SET status = 'superseded', superseded_by = ? "
                        "WHERE id = ?",
                        (new_id, sid),
                    )
                db.commit()

            actions.append(action)

    return actions


def _create_consolidated(
    db: sqlite3.Connection,
    name: str,
    mem_type: str,
    content: str,
    importance: float,
    storage_strength: float,
    source_ids: list[int],
) -> int:
    """Insert a new consolidated memory with consolidated_from metadata."""
    consolidated_from = json.dumps(source_ids)
    db.execute("""
        INSERT INTO memories (name, type, memory_class, tags, content, importance,
                              storage_strength, consolidated_from,
                              created, updated, active, status)
        VALUES (?, ?, 'semantic', '', ?, ?, ?, ?, datetime('now'), datetime('now'), 1, 'active')
    """, (name, mem_type, content, importance, storage_strength, consolidated_from))
    db.commit()
    new_id = db.execute("SELECT last_insert_rowid()").fetchone()[0]

    # Update embedding for consolidated content if vec is available
    if aibrain_db._db_vec_enabled:
        emb = aibrain_db._compute_embedding(f"{name} {content}")
        if emb is not None:
            emb_bytes = struct.pack(f"{len(emb)}f", *emb)
            try:
                db.execute(
                    "INSERT INTO memories_vec (memory_id, embedding) VALUES (?, ?)",
                    (new_id, emb_bytes),
                )
                db.commit()
            except Exception:
                pass

    return new_id


# ---------------------------------------------------------------------------
# Step 3: DECAY
# ---------------------------------------------------------------------------

def decay_memories(db: sqlite3.Connection, dry_run: bool = False) -> int:
    """Apply Ebbinghaus forgetting curve to storage_strength for every active memory.

    Uses :func:`aibrain.core.memory_decay.compute_decay_score` which implements
    R = exp(-t / S(m)) where S is assembled from access_frequency, importance,
    and confirmation_count — identical to the curve used for retrieval re-ranking.

    Mapping: new_strength = max(DECAY_FLOOR, retention * 10.0)
    This gives:
        retention=1.0  → storage_strength=10.0  (fresh / frequently accessed)
        retention=0.5  → storage_strength=5.0   (half-decayed)
        retention=0.01 → storage_strength=0.1   (floor — archive candidate)

    storage_strength is only updated when the new value differs from the current
    stored value, so repeated runs are idempotent to within floating-point noise.

    Returns count of memories whose storage_strength was updated.
    """
    rows = db.execute("""
        SELECT id, COALESCE(storage_strength, 1.0) AS storage_strength
        FROM memories
        WHERE status = 'active' AND active = 1
    """).fetchall()

    now_ts = datetime.now(timezone.utc)
    updated = 0

    for row in rows:
        memory_id = row[0]
        current_strength = float(row[1])

        retention = compute_decay_score(memory_id, now_ts=now_ts, db=db)
        if retention is None:
            # Memory disappeared or has no timestamp — skip without touching it.
            continue

        new_strength = max(DECAY_FLOOR, retention * 10.0)

        # Only write when meaningfully different (avoids spurious DB churn).
        if abs(new_strength - current_strength) < 1e-4:
            continue

        if not dry_run:
            db.execute(
                "UPDATE memories SET storage_strength = ? WHERE id = ?",
                (new_strength, memory_id),
            )

        updated += 1

    if not dry_run and updated:
        db.commit()

    return updated


# ---------------------------------------------------------------------------
# Step 4: ARCHIVE
# ---------------------------------------------------------------------------

def archive_weak_memories(
    db: sqlite3.Connection, dry_run: bool = False, return_details: bool = False
) -> int | tuple[int, list[dict]]:
    """Archive memories whose combined retention < ARCHIVE_RETENTION.

    Combined retention = 0.7 * retrieval_strength + 0.3 * (storage_strength / 10).
    retrieval_strength approximated by power-law decay from updated timestamp.

    When return_details=True, returns (count, list_of_archive_detail_dicts) instead
    of just the count. Used by the dream diary writer.
    """
    rows = db.execute("""
        SELECT id, updated, storage_strength, type, content
        FROM memories
        WHERE status = 'active' AND active = 1
    """).fetchall()

    now = datetime.now(timezone.utc)
    to_archive = []
    archive_details = []

    for row in rows:
        mem_id, updated_str, storage, mem_type, content = row
        storage = storage if storage is not None else 1.0

        try:
            dt_str = str(updated_str).replace("T", " ").split(".")[0][:19]
            updated_dt = datetime.strptime(dt_str, "%Y-%m-%d %H:%M:%S")
            updated_dt = updated_dt.replace(tzinfo=timezone.utc)
            days_since = (now - updated_dt).total_seconds() / 86400.0
        except (ValueError, TypeError):
            continue  # skip if we can't parse date

        # Power-law decay matching _salience_score: stability=30 days
        retrieval = (1.0 + days_since / 30.0) ** -1.0 if days_since >= 0 else 1.0
        storage_norm = min(storage / 10.0, 1.0)
        retention = 0.7 * retrieval + 0.3 * storage_norm

        if retention < ARCHIVE_RETENTION:
            to_archive.append(mem_id)
            if return_details:
                archive_details.append({
                    "type": mem_type or "unknown",
                    "content_preview": (content or "")[:80],
                    "retention": round(retention, 3),
                })

    if dry_run:
        if return_details:
            return len(to_archive), archive_details
        return len(to_archive)

    if to_archive:
        placeholders = ",".join("?" * len(to_archive))
        db.execute(
            f"UPDATE memories SET status = 'archived' WHERE id IN ({placeholders})",  # noqa:SQL-FSTRING
            to_archive,
        )
        db.commit()

    if return_details:
        return len(to_archive), archive_details
    return len(to_archive)


# ---------------------------------------------------------------------------
# Step 5: REBUILD category summaries
# ---------------------------------------------------------------------------

def rebuild_category_summaries(db: sqlite3.Connection, dry_run: bool = False) -> list[str]:
    """Regenerate category_summaries for all active memory types.

    Returns list of category names rebuilt.
    """
    rows = db.execute("""
        SELECT DISTINCT type FROM memories
        WHERE active = 1 AND status = 'active'
    """).fetchall()

    categories = [r[0] for r in rows if r[0]]

    if not dry_run:
        for cat in categories:
            try:
                aibrain_db.update_category_summary(cat, db=db)
            except Exception as e:
                logger.warning("Failed to rebuild summary for %s: %s", cat, e)

    return categories


# ---------------------------------------------------------------------------
# Main consolidation runner
# ---------------------------------------------------------------------------

def run_consolidation(dry_run: bool = False, verbose: bool = False) -> dict:
    """Execute the full 5-step consolidation cycle.

    Returns a summary dict with counts for each step.
    """
    db = aibrain_db.get_db()

    if verbose:
        logging.basicConfig(level=logging.DEBUG)
    else:
        logging.basicConfig(level=logging.INFO)

    result = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "dry_run": dry_run,
        "clusters_found": 0,
        "memories_merged": 0,
        "consolidated_entries_created": 0,
        "memories_decayed": 0,
        "memories_archived": 0,
        "categories_rebuilt": [],
    }

    # Step 1: CLUSTER
    logger.info("Step 1/5: Clustering memories by type + embedding similarity...")
    clusters = cluster_memories(db)
    total_clustered = sum(len(m) for cl in clusters.values() for m in cl)
    result["clusters_found"] = sum(len(cl) for cl in clusters.values())
    logger.info("  Found %d clusters across %d types (%d memories)",
                result["clusters_found"], len(clusters), total_clustered)

    # Step 2: MERGE
    logger.info("Step 2/5: Merging clusters (min size %d)...", MIN_CLUSTER_SIZE)
    merge_actions = merge_clusters(db, clusters, dry_run=dry_run)
    result["consolidated_entries_created"] = len(merge_actions)
    result["memories_merged"] = sum(len(a["source_ids"]) for a in merge_actions)
    logger.info("  Created %d consolidated entries from %d source memories",
                result["consolidated_entries_created"], result["memories_merged"])

    # Step 3: DECAY
    logger.info("Step 3/5: Applying Ebbinghaus decay curve to all active memories...")
    result["memories_decayed"] = decay_memories(db, dry_run=dry_run)
    logger.info("  Decayed %d memories", result["memories_decayed"])

    # Step 4: ARCHIVE — collect details for dream diary
    logger.info("Step 4/5: Archiving weak memories (retention < %.2f)...", ARCHIVE_RETENTION)
    archived_count, archive_details = archive_weak_memories(
        db, dry_run=dry_run, return_details=True
    )
    result["memories_archived"] = archived_count
    logger.info("  Archived %d memories", result["memories_archived"])

    # Step 5: REBUILD
    logger.info("Step 5/5: Rebuilding category summaries...")
    result["categories_rebuilt"] = rebuild_category_summaries(db, dry_run=dry_run)
    logger.info("  Rebuilt %d categories: %s", len(result["categories_rebuilt"]),
                ", ".join(result["categories_rebuilt"][:10]))

    # Log to execution_log
    if not dry_run:
        try:
            db.execute("""
                INSERT INTO execution_log (action, success, quality_score, task_type, created_at)
                VALUES ('memory_consolidation', 1, 1.0, 'deterministic', datetime('now'))
            """)
            db.commit()
        except Exception:
            pass

    # Write dream diary — must run AFTER all steps, never on dry_run
    if not dry_run:
        write_dream_diary(result, merge_actions, archive_details)

    return result


# ---------------------------------------------------------------------------
# Dream diary writer
# ---------------------------------------------------------------------------

DREAMS_HISTORY_MAX = 7  # keep last N run summaries in the JSON history file


def write_dream_diary(result: dict, merge_actions: list[dict], archive_details: list[dict]) -> None:
    """Write DREAMS.md and append to dreams_history.json after a consolidation run.

    Never raises — diary failure must not break the consolidation run.
    """
    try:
        now_str = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M")
        dreams_path = Path(AIBRAIN_ROOT) / "DREAMS.md"
        history_path = Path(AIBRAIN_ROOT) / "dreams_history.json"

        # Build promoted section from merge_actions
        promoted_count = result.get("consolidated_entries_created", 0)
        merged_mem_count = result.get("memories_merged", 0)
        merged_lines = []
        for action in merge_actions[:10]:  # cap at 10 for readability
            preview = action.get("merged_content_preview", "")[:80]
            importance = action.get("importance", 0.0)
            count = len(action.get("source_ids", []))
            mem_type = action.get("type", "unknown")
            reason = "embedding cluster merge"
            merged_lines.append(
                f"- [{mem_type}] \"{preview}\" (importance: {importance:.2f}, "
                f"{count} sources, reason: {reason})"
            )

        # Build archived section
        archived_count = result.get("memories_archived", 0)
        archive_lines = []
        for detail in archive_details[:10]:  # cap at 10
            mem_type = detail.get("type", "unknown")
            preview = detail.get("content_preview", "")
            retention = detail.get("retention", 0.0)
            archive_lines.append(
                f"- [{mem_type}] \"{preview}\" (retention: {retention:.3f} — below threshold)"
            )

        # Build merged clusters section
        clusters_found = result.get("clusters_found", 0)
        merge_cluster_lines = []
        for action in merge_actions[:10]:
            count = len(action.get("source_ids", []))
            mem_type = action.get("type", "unknown")
            importance = action.get("importance", 0.0)
            merge_cluster_lines.append(
                f"- {count} {mem_type} memories merged into consolidated entry "
                f"(importance: {importance:.2f})"
            )

        # Assemble markdown
        total_processed = (
            merged_mem_count
            + archived_count
            + result.get("memories_decayed", 0)
        )
        unchanged = max(0, total_processed - merged_mem_count - archived_count)

        lines = [
            f"# Dream Cycle — {now_str}",
            "",
            f"## Promoted to long-term memory ({promoted_count})",
        ]
        if merged_lines:
            lines.extend(merged_lines)
        else:
            lines.append("- None this cycle")

        lines += [
            "",
            f"## Archived ({archived_count})",
        ]
        if archive_lines:
            lines.extend(archive_lines)
        else:
            lines.append("- None this cycle")

        lines += [
            "",
            f"## Merged clusters ({promoted_count})",
        ]
        if merge_cluster_lines:
            lines.extend(merge_cluster_lines)
        else:
            lines.append("- None this cycle")

        lines += [
            "",
            "## Stats",
            (
                f"- Total processed: {total_processed} | "
                f"Promoted: {promoted_count} | "
                f"Archived: {archived_count} | "
                f"Merged: {merged_mem_count} | "
                f"Decayed: {result.get('memories_decayed', 0)} | "
                f"Clusters found: {clusters_found}"
            ),
            "",
        ]

        dreams_path.write_text("\n".join(lines), encoding="utf-8")
        logger.info("Dream diary written to %s", dreams_path)

        # Append compact summary to dreams_history.json (rolling last 7)
        summary = {
            "timestamp": result.get("timestamp", now_str),
            "promoted": promoted_count,
            "archived": archived_count,
            "merged": merged_mem_count,
            "clusters_found": clusters_found,
            "decayed": result.get("memories_decayed", 0),
            "categories_rebuilt": len(result.get("categories_rebuilt", [])),
        }

        history: list[dict] = []
        if history_path.exists():
            try:
                history = json.loads(history_path.read_text(encoding="utf-8"))
                if not isinstance(history, list):
                    history = []
            except Exception:
                history = []

        history.append(summary)
        # Keep only last N entries
        history = history[-DREAMS_HISTORY_MAX:]
        history_path.write_text(json.dumps(history, indent=2, default=str), encoding="utf-8")
        logger.info("Dream history updated (%d entries)", len(history))

    except Exception as exc:
        logger.warning("Dream diary write failed (non-fatal): %s", exc)


# ---------------------------------------------------------------------------
# Workflow registration helper
# ---------------------------------------------------------------------------

def register_workflow(db: sqlite3.Connection | None = None):
    """Register this workflow in the workflows table if not already present."""
    if db is None:
        db = aibrain_db.get_db()

    existing = db.execute(
        "SELECT id FROM workflows WHERE name = 'memory_consolidation'"
    ).fetchone()

    if existing:
        return existing[0]

    db.execute("""
        INSERT INTO workflows (name, display_name, category, description,
                               cron_schedule, script_path, enabled, source,
                               created, updated)
        VALUES (
            'memory_consolidation',
            'Memory Consolidation (Sleep Cycle)',
            'maintenance',
            'Nightly brain consolidation: cluster similar memories, merge clusters of 3+, decay stale entries, archive weak memories, rebuild category summaries.',
            '0 3 * * *',
            'workflows/memory_consolidation.py',
            1,
            'builtin',
            datetime('now'),
            datetime('now')
        )
    """)
    db.commit()
    return db.execute("SELECT last_insert_rowid()").fetchone()[0]


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Memory consolidation — nightly sleep cycle for the brain"
    )
    parser.add_argument("--dry-run", action="store_true",
                        help="Preview what would happen without making changes")
    parser.add_argument("--verbose", action="store_true",
                        help="Detailed output")
    args = parser.parse_args()

    result = run_consolidation(dry_run=args.dry_run, verbose=args.verbose)

    print(json.dumps(result, indent=2, default=str))
    return 0


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        sys.exit(main())
    workflow_execute(
        workflow_name='memory_consolidation',
        action=_workflow_entry,
        task_type='judgment',
        actor='cli',
    )
