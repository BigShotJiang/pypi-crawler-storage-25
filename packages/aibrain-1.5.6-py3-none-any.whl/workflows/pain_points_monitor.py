#!/usr/bin/env python3
"""
pain_points_monitor.py — Monitor LinkedIn/Reddit/HN/X for AI agent pain points.

Watches for posts where people complain about problems AIBrain solves:
  - AI forgetting context between sessions
  - No persistent memory for agents
  - Expensive cloud-only AI
  - Agents starting fresh every run

For each match: drafts a helpful comment, sends to Telegram for approval.
NEVER posts without explicit Decker approval.

Run: python pain_points_monitor.py [--dry-run]
"""

import datetime
import hashlib
import json
import os
import sys
import time
import threading
import urllib.request
import urllib.parse
from pathlib import Path

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

from aibrain_db import AIBRAIN_ROOT
_cfg_path = AIBRAIN_ROOT / "config.json"
CONFIG = json.loads(_cfg_path.read_text()) if _cfg_path.exists() else {}

STATE_FILE = AIBRAIN_ROOT / "data" / "pain_points_seen.json"
HEADERS = {"User-Agent": "Mozilla/5.0 (compatible; AIBrainBot/1.0)"}

TELEGRAM_TOKEN = os.environ.get("TELEGRAM_TOKEN", CONFIG.get("telegram_token", ""))
TELEGRAM_CHAT = os.environ.get("TELEGRAM_CHAT_ID", str(CONFIG.get("telegram_chat_id", "8267616606")))

# ---------------------------------------------------------------------------
# Pain point keywords — things people complain about that we solve
# ---------------------------------------------------------------------------

PAIN_KEYWORDS = [
    "AI forgets context",
    "AI no memory",
    "AI agent memory",
    "agent forgetting",
    "persistent memory AI",
    "LLM no persistent memory",
    "AI starts fresh every session",
    "context window resets",
    "agent context lost",
    "AI expensive API",
    "local LLM agent",
    "offline AI agent",
    "AI agent cost",
    "openai too expensive",
    "anthropic too expensive",
]

SUBREDDITS = [
    "LocalLLaMA",
    "MachineLearning",
    "ChatGPT",
    "ClaudeAI",
    "artificial",
    "singularity",
    "selfhosted",
    "programming",
]

# ---------------------------------------------------------------------------
# Response templates — each is a starting point, will be tailored by model
# ---------------------------------------------------------------------------

RESPONSE_TEMPLATES = {
    "memory": (
        "I hit this exact problem too. What worked for me: "
        "AIBrain (open source) — it's an MCP server that gives agents persistent, "
        "searchable memory across sessions. 79k memories in my instance now, survives restarts. "
        "`pip install aibrain[mcp,embeddings]` if you want to try it. "
        "myaibrain.org for docs."
    ),
    "cost": (
        "For the cost problem: most tasks don't need GPT-4/Claude Sonnet. "
        "AIBrain has a built-in task classifier that routes simple tasks to local Ollama models ($0) "
        "and only uses cloud APIs for complex judgment calls. "
        "Our cost dropped to ~$0.05/month for 847 tasks. Open source: myaibrain.org"
    ),
    "local": (
        "If you want offline-capable agents with persistent memory, "
        "AIBrain works great here — SQLite brain, local Ollama routing, "
        "no cloud dependency for most tasks. MIT licensed. myaibrain.org"
    ),
}

# ---------------------------------------------------------------------------
# State management
# ---------------------------------------------------------------------------

def load_seen():
    if STATE_FILE.exists():
        try:
            return set(json.loads(STATE_FILE.read_text()))
        except Exception:
            pass
    return set()


def save_seen(seen: set):
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    STATE_FILE.write_text(json.dumps(sorted(seen), indent=2))


def url_hash(url: str) -> str:
    return hashlib.md5(url.encode()).hexdigest()[:16]


# ---------------------------------------------------------------------------
# Platform scrapers (public APIs only — no auth needed)
# ---------------------------------------------------------------------------

def search_hn(keyword: str) -> list[dict]:
    results = []
    try:
        url = f"https://hn.algolia.com/api/v1/search_by_date?query={urllib.parse.quote(keyword)}&tags=story,comment&hitsPerPage=5"
        req = urllib.request.Request(url, headers=HEADERS)
        data = json.loads(urllib.request.urlopen(req, timeout=10).read())
        for hit in data.get("hits", []):
            title = hit.get("title") or ""
            body = hit.get("comment_text") or hit.get("story_text") or ""
            if not _is_ai_relevant(title, body):
                continue
            results.append({
                "source": "HackerNews",
                "title": hit.get("title") or hit.get("comment_text", "")[:100],
                "url": hit.get("url") or f"https://news.ycombinator.com/item?id={hit.get('objectID')}",
                "score": hit.get("points") or hit.get("num_comments", 0),
                "date": (hit.get("created_at") or "")[:10],
                "keyword": keyword,
            })
    except Exception as e:
        print(f"HN error ({keyword}): {e}", file=sys.stderr)
    return results


# AI/tech context signals — post must contain at least one
AI_CONTEXT_TERMS = frozenset([
    "ai", "llm", "agent", "gpt", "claude", "openai", "anthropic", "memory",
    "model", "langchain", "copilot", "chatgpt", "ollama", "llama", "gemini",
    "inference", "embedding", "vector", "token", "prompt", "rag", "mcp",
    "local model", "language model", "aibrain", "context window",
])


def _is_ai_relevant(title: str, body: str = "") -> bool:
    """Return True if post is about AI/LLM/agents (not a false positive)."""
    text = (title + " " + body).lower()
    return any(term in text for term in AI_CONTEXT_TERMS)


def search_reddit(keyword: str, subreddits: list[str]) -> list[dict]:
    results = []
    for sub in subreddits[:3]:
        try:
            time.sleep(1.5)
            url = f"https://www.reddit.com/r/{sub}/search.json?q={urllib.parse.quote(keyword)}&sort=new&t=week&limit=5&restrict_sr=on"
            req = urllib.request.Request(url, headers=HEADERS)
            data = json.loads(urllib.request.urlopen(req, timeout=10).read())
            for post in data.get("data", {}).get("children", []):
                pd = post["data"]
                score = pd.get("score", 0)
                if score < 2:
                    continue
                title = pd.get("title", "")
                selftext = pd.get("selftext", "")
                # Require AI context — reject off-topic false positives
                if not _is_ai_relevant(title, selftext):
                    continue
                results.append({
                    "source": f"r/{sub}",
                    "title": title,
                    "url": f"https://reddit.com{pd.get('permalink', '')}",
                    "score": score,
                    "date": datetime.datetime.fromtimestamp(pd.get("created_utc", 0)).strftime("%Y-%m-%d"),
                    "keyword": keyword,
                })
        except Exception:
            continue
    return results


# ---------------------------------------------------------------------------
# Comment draft generation
# ---------------------------------------------------------------------------

def draft_comment(post: dict) -> str:
    """Pick the most relevant response template based on keyword."""
    keyword = post["keyword"].lower()
    if any(w in keyword for w in ["memory", "forget", "context", "session", "fresh"]):
        template = RESPONSE_TEMPLATES["memory"]
    elif any(w in keyword for w in ["expensive", "cost", "api", "price"]):
        template = RESPONSE_TEMPLATES["cost"]
    elif any(w in keyword for w in ["local", "offline", "ollama"]):
        template = RESPONSE_TEMPLATES["local"]
    else:
        template = RESPONSE_TEMPLATES["memory"]

    return template


# ---------------------------------------------------------------------------
# Telegram notification (fire-and-forget, no blocking)
# ---------------------------------------------------------------------------

def send_telegram(message: str, dry_run: bool = False) -> None:
    if dry_run:
        print(f"\n[TELEGRAM DRY RUN]\n{message}\n")
        return
    if not TELEGRAM_TOKEN:
        print("No TELEGRAM_TOKEN — skipping Telegram send", file=sys.stderr)
        return

    def _send():
        try:
            url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
            data = json.dumps({"chat_id": TELEGRAM_CHAT, "text": message, "parse_mode": "HTML"}).encode()
            req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
            urllib.request.urlopen(req, timeout=10)
        except Exception as e:
            print(f"Telegram send failed: {e}", file=sys.stderr)

    threading.Thread(target=_send, daemon=True).start()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def run(dry_run: bool = False):
    seen = load_seen()
    new_posts = []

    print(f"[pain_points_monitor] Starting scan — {len(PAIN_KEYWORDS)} keywords, {len(SUBREDDITS)} subreddits")

    for keyword in PAIN_KEYWORDS:
        # HN search
        for post in search_hn(keyword):
            uid = url_hash(post["url"])
            if uid not in seen:
                new_posts.append(post)
                seen.add(uid)
        time.sleep(0.5)

        # Reddit search
        for post in search_reddit(keyword, SUBREDDITS):
            uid = url_hash(post["url"])
            if uid not in seen:
                new_posts.append(post)
                seen.add(uid)

    print(f"[pain_points_monitor] Found {len(new_posts)} new posts")

    if not new_posts:
        print("[pain_points_monitor] No new posts — nothing to draft")
        save_seen(seen)
        return

    # Send Telegram notification with drafted comments (for approval)
    # Cap at 5 per run to avoid spam
    for post in new_posts[:5]:
        draft = draft_comment(post)
        msg = (
            f"<b>Pain Point Post — {post['source']}</b>\n"
            f"Keyword: {post['keyword']}\n"
            f"Title: {post['title'][:120]}\n"
            f"Score: {post['score']} | Date: {post['date']}\n"
            f"URL: {post['url']}\n\n"
            f"<b>Draft response:</b>\n{draft}\n\n"
            f"Reply YES to post, or ignore to skip."
        )
        send_telegram(msg, dry_run=dry_run)
        time.sleep(0.5)

    save_seen(seen)
    print(f"[pain_points_monitor] Sent {min(len(new_posts), 5)} drafts to Telegram for approval")


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        import argparse
        parser = argparse.ArgumentParser(description="Monitor pain point posts + draft responses")
        parser.add_argument("--dry-run", action="store_true", help="Print output without sending Telegram")
        args = parser.parse_args()
        run(dry_run=args.dry_run)
    workflow_execute(
        workflow_name='pain_points_monitor',
        action=_workflow_entry,
        task_type='simple',
        actor='cli',
    )
