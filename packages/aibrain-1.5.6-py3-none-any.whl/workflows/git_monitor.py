#!/usr/bin/env python3
"""AIBrain Workflow: Git Monitor — track GitHub repo activity and report changes."""

import argparse
import datetime
import json
import os
import sqlite3
import sys
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

# ---------------------------------------------------------------------------
# Config & DB helpers
# ---------------------------------------------------------------------------

from aibrain_db import AIBRAIN_ROOT, get_db
_cfg_path = AIBRAIN_ROOT / "config.json"
CONFIG = json.loads(_cfg_path.read_text()) if _cfg_path.exists() else {}
def _find_db():
    """Find best DB path, checking both new and legacy names."""
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    configured = CONFIG.get("db_path")
    if configured and Path(configured).exists():
        return configured
    mem_db = AIBRAIN_ROOT / "memory" / "memory.db"
    if mem_db.exists():
        return str(mem_db)
    return str(AIBRAIN_ROOT / "aibrain.db")

MEMORY_DB = CONFIG.get("db_path", _find_db())

GITHUB_API = "https://api.github.com"
STATE_KEY = "workflow_state:git_monitor"
API_BASE = os.environ.get("AIBRAIN_API", os.environ.get("AIBRAIN_API", "http://localhost:8001/api/agent"))


def log_activity(action, detail="", status="ok"):
    import urllib.request as _ur
    try:
        data = json.dumps({
            "action": action, "category": "devops",
            "detail": detail, "status": status,
        }).encode()
        req = _ur.Request(
            f"{API_BASE}/activity", data=data,
            headers={"Content-Type": "application/json"},
        )
        _ur.urlopen(req, timeout=5)
    except Exception:
        pass


def get_db():
    db = get_db()
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    return db


def load_state(name):
    try:
        db = get_db()
        row = db.execute(
            "SELECT content FROM memories WHERE name=? AND active=1",
            (f"workflow_state:{name}",),
        ).fetchone()
        db.close()
        return json.loads(row["content"]) if row else {}
    except Exception:
        return {}


def save_state(name, state):
    db = get_db()
    try:
        now = datetime.datetime.now().isoformat()
        existing = db.execute(
            "SELECT id FROM memories WHERE name=? AND active=1",
            (f"workflow_state:{name}",),
        ).fetchone()
        if existing:
            db.execute("UPDATE memories SET content=?, updated=? WHERE id=?",
                       (json.dumps(state), now, existing["id"]))
        else:
            db.execute(
                "INSERT INTO memories (name,type,tags,content,created,updated,active) VALUES (?,?,?,?,?,?,1)",
                (f"workflow_state:{name}", "reference", "workflow,state",
                 json.dumps(state), now, now),
            )
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


# ---------------------------------------------------------------------------
# GitHub API helpers
# ---------------------------------------------------------------------------

def gh_request(path, token, params=None):
    """Make a GitHub REST API request. Returns parsed JSON or None on error."""
    url = f"{GITHUB_API}{path}"
    if params:
        qs = "&".join(f"{k}={v}" for k, v in params.items())
        url = f"{url}?{qs}"

    req = Request(url)
    req.add_header("Accept", "application/vnd.github+json")
    req.add_header("X-GitHub-Api-Version", "2022-11-28")
    if token:
        req.add_header("Authorization", f"Bearer {token}")

    try:
        with urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode())
    except HTTPError as e:
        body = e.read().decode() if e.fp else ""
        print(f"  GitHub API error {e.code} on {path}: {body[:200]}", file=sys.stderr)
        return None
    except URLError as e:
        print(f"  Network error on {path}: {e.reason}", file=sys.stderr)
        return None


def gh_paginate(path, token, params=None, max_pages=3):
    """Fetch up to max_pages of results from a paginated endpoint."""
    all_items = []
    params = dict(params or {})
    params.setdefault("per_page", "100")

    for page in range(1, max_pages + 1):
        params["page"] = str(page)
        data = gh_request(path, token, params)
        if not data or not isinstance(data, list):
            break
        all_items.extend(data)
        if len(data) < int(params["per_page"]):
            break
    return all_items


# ---------------------------------------------------------------------------
# Activity fetchers — each returns list of activity dicts
# ---------------------------------------------------------------------------

def fetch_open_prs(repo, token, since):
    """Fetch PRs created or updated since timestamp."""
    items = gh_paginate(
        f"/repos/{repo}/pulls",
        token,
        {"state": "open", "sort": "updated", "direction": "desc"},
    )
    activities = []
    for pr in items:
        updated = pr.get("updated_at", "")
        if updated <= since:
            continue
        activities.append({
            "type": "pr",
            "repo": repo,
            "number": pr["number"],
            "title": pr["title"],
            "user": pr["user"]["login"],
            "url": pr["html_url"],
            "created_at": pr["created_at"],
            "updated_at": updated,
            "draft": pr.get("draft", False),
            "labels": [l["name"] for l in pr.get("labels", [])],
        })
    return activities


def fetch_review_requests(repo, token, username, since):
    """Fetch PRs where the user has been requested for review."""
    items = gh_paginate(
        f"/repos/{repo}/pulls",
        token,
        {"state": "open", "sort": "updated", "direction": "desc"},
    )
    activities = []
    for pr in items:
        updated = pr.get("updated_at", "")
        if updated <= since:
            continue
        reviewers = [r["login"] for r in pr.get("requested_reviewers", [])]
        if username in reviewers:
            activities.append({
                "type": "review_requested",
                "repo": repo,
                "number": pr["number"],
                "title": pr["title"],
                "user": pr["user"]["login"],
                "url": pr["html_url"],
                "updated_at": updated,
            })
    return activities


def fetch_assigned_issues(repo, token, username, since):
    """Fetch issues assigned to user, updated since timestamp."""
    items = gh_paginate(
        f"/repos/{repo}/issues",
        token,
        {"assignee": username, "state": "open", "sort": "updated", "direction": "desc"},
    )
    activities = []
    for issue in items:
        # Skip pull requests (GitHub returns PRs in issues endpoint)
        if "pull_request" in issue:
            continue
        updated = issue.get("updated_at", "")
        if updated <= since:
            continue
        activities.append({
            "type": "issue_assigned",
            "repo": repo,
            "number": issue["number"],
            "title": issue["title"],
            "user": issue["user"]["login"],
            "url": issue["html_url"],
            "created_at": issue["created_at"],
            "updated_at": updated,
            "labels": [l["name"] for l in issue.get("labels", [])],
        })
    return activities


def fetch_ci_failures(repo, token, since, branches=None):
    """Fetch failed workflow runs on watched branches."""
    branches = branches or ["main", "master"]
    activities = []
    for branch in branches:
        runs = gh_request(
            f"/repos/{repo}/actions/runs",
            token,
            {"branch": branch, "status": "failure", "per_page": "10"},
        )
        if not runs or "workflow_runs" not in runs:
            continue
        for run in runs["workflow_runs"]:
            updated = run.get("updated_at", "")
            if updated <= since:
                continue
            activities.append({
                "type": "ci_failure",
                "repo": repo,
                "branch": branch,
                "workflow": run.get("name", "unknown"),
                "run_number": run.get("run_number"),
                "conclusion": run.get("conclusion", "failure"),
                "url": run.get("html_url", ""),
                "updated_at": updated,
                "actor": run.get("actor", {}).get("login", "unknown"),
            })
    return activities


def fetch_releases(repo, token, since):
    """Fetch new releases and tags since timestamp."""
    items = gh_paginate(
        f"/repos/{repo}/releases",
        token,
        {"per_page": "10"},
        max_pages=1,
    )
    activities = []
    for rel in items:
        published = rel.get("published_at", rel.get("created_at", ""))
        if published <= since:
            continue
        activities.append({
            "type": "release",
            "repo": repo,
            "tag": rel.get("tag_name", ""),
            "name": rel.get("name", ""),
            "prerelease": rel.get("prerelease", False),
            "draft": rel.get("draft", False),
            "url": rel.get("html_url", ""),
            "published_at": published,
            "author": rel.get("author", {}).get("login", "unknown"),
        })
    return activities


# ---------------------------------------------------------------------------
# Report formatting
# ---------------------------------------------------------------------------

def format_report(all_activity, repos_checked):
    """Format activity into a human-readable summary report."""
    now = datetime.datetime.now()
    total = len(all_activity)

    lines = [
        f"GIT MONITOR — {now.strftime('%A %B %d, %Y %I:%M %p')}",
        f"Repos checked: {len(repos_checked)} | New activity: {total}",
        "=" * 55,
        "",
    ]

    if total == 0:
        lines.append("No new activity across watched repos.")
        lines.append("")
        lines.append("---\nPowered by AIBrain (read-only monitor)")
        return "\n".join(lines)

    # Group by type
    by_type = {}
    for a in all_activity:
        by_type.setdefault(a["type"], []).append(a)

    # CI failures first (highest priority)
    if "ci_failure" in by_type:
        items = by_type["ci_failure"]
        lines.append(f"CI/CD FAILURES ({len(items)})")
        for a in items:
            lines.append(f"  [{a['repo']}] {a['workflow']} on {a['branch']}")
            lines.append(f"    Run #{a['run_number']} by {a['actor']}")
            lines.append(f"    {a['url']}")
            lines.append("")

    # Review requests
    if "review_requested" in by_type:
        items = by_type["review_requested"]
        lines.append(f"REVIEW REQUESTED ({len(items)})")
        for a in items:
            lines.append(f"  [{a['repo']}] #{a['number']}: {a['title']}")
            lines.append(f"    From: {a['user']}  {a['url']}")
            lines.append("")

    # Assigned issues
    if "issue_assigned" in by_type:
        items = by_type["issue_assigned"]
        lines.append(f"ASSIGNED ISSUES ({len(items)})")
        for a in items:
            labels = f"  [{', '.join(a['labels'])}]" if a.get("labels") else ""
            lines.append(f"  [{a['repo']}] #{a['number']}: {a['title']}{labels}")
            lines.append(f"    {a['url']}")
            lines.append("")

    # Pull requests
    if "pr" in by_type:
        items = by_type["pr"]
        lines.append(f"PULL REQUESTS ({len(items)})")
        for a in items:
            draft = " [DRAFT]" if a.get("draft") else ""
            labels = f"  [{', '.join(a['labels'])}]" if a.get("labels") else ""
            lines.append(f"  [{a['repo']}] #{a['number']}: {a['title']}{draft}{labels}")
            lines.append(f"    By: {a['user']}  {a['url']}")
        lines.append("")

    # Releases
    if "release" in by_type:
        items = by_type["release"]
        lines.append(f"RELEASES ({len(items)})")
        for a in items:
            pre = " [pre-release]" if a.get("prerelease") else ""
            lines.append(f"  [{a['repo']}] {a['tag']}: {a['name']}{pre}")
            lines.append(f"    By: {a['author']}  {a['url']}")
        lines.append("")

    lines.append("---\nPowered by AIBrain (read-only monitor)")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="AIBrain Git Monitor — track GitHub repo activity")
    parser.add_argument("--dry-run", action="store_true", help="Print report without saving state")
    parser.add_argument("--reset", action="store_true", help="Reset last-checked timestamps")
    args = parser.parse_args()

    # Read config
    token = CONFIG.get("github_token", "")
    username = CONFIG.get("github_username", "")
    watched_repos = CONFIG.get("watched_repos", CONFIG.get("github_repos", []))

    if not token:
        print("Error: github_token not set in config.json", file=sys.stderr)
        sys.exit(1)
    if not watched_repos:
        print("Error: no repos configured. Set watched_repos in config.json", file=sys.stderr)
        sys.exit(1)

    # Load previous state for last-checked timestamps
    state = load_state("git_monitor")
    if args.reset:
        state = {}
        print("Reset all last-checked timestamps.")

    repo_timestamps = state.get("repo_timestamps", {})

    # Default: look back 24 hours on first run
    default_since = (datetime.datetime.utcnow() - datetime.timedelta(hours=24)).strftime(
        "%Y-%m-%dT%H:%M:%SZ"
    )

    all_activity = []

    for repo in watched_repos:
        since = repo_timestamps.get(repo, default_since)
        print(f"Checking {repo} (since {since})...")

        # Fetch all activity types
        prs = fetch_open_prs(repo, token, since)
        all_activity.extend(prs)
        print(f"  {len(prs)} PR updates")

        if username:
            reviews = fetch_review_requests(repo, token, username, since)
            all_activity.extend(reviews)
            print(f"  {len(reviews)} review requests")

            issues = fetch_assigned_issues(repo, token, username, since)
            all_activity.extend(issues)
            print(f"  {len(issues)} assigned issues")

        ci = fetch_ci_failures(repo, token, since)
        all_activity.extend(ci)
        print(f"  {len(ci)} CI failures")

        releases = fetch_releases(repo, token, since)
        all_activity.extend(releases)
        print(f"  {len(releases)} releases")

        # Update timestamp for this repo
        repo_timestamps[repo] = datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")

    # Deduplicate by (type, repo, number/tag)
    seen = set()
    deduped = []
    for a in all_activity:
        key = (a["type"], a.get("repo"), a.get("number", a.get("tag", a.get("run_number"))))
        if key not in seen:
            seen.add(key)
            deduped.append(a)
    all_activity = deduped

    report = format_report(all_activity, watched_repos)
    print()
    print(report)

    # Save state unless dry run
    if not args.dry_run:
        new_state = {
            "last_run": datetime.datetime.now().isoformat(),
            "repos_checked": len(watched_repos),
            "total_activity": len(all_activity),
            "repo_timestamps": repo_timestamps,
            "summary": {
                "prs": len([a for a in all_activity if a["type"] == "pr"]),
                "review_requests": len([a for a in all_activity if a["type"] == "review_requested"]),
                "issues": len([a for a in all_activity if a["type"] == "issue_assigned"]),
                "ci_failures": len([a for a in all_activity if a["type"] == "ci_failure"]),
                "releases": len([a for a in all_activity if a["type"] == "release"]),
            },
        }
        save_state("git_monitor", new_state)
        print("\nState saved to activity DB.")
        ci_count = len([a for a in all_activity if a["type"] == "ci_failure"])
        log_activity("git_monitor",
                      f"{len(watched_repos)} repos, {len(all_activity)} events, {ci_count} CI failures",
                      "warning" if ci_count > 0 else "ok")
    else:
        print("\n[dry-run] State not saved.")


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name='git_monitor',
        action=_workflow_entry,
        task_type='deterministic',
        actor='cli',
    )
