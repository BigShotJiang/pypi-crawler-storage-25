#!/usr/bin/env python3
"""AIBrain Workflow: RSS Digest — fetch feeds, deduplicate, email digest."""

import argparse
import datetime
import hashlib
import json
import os
import re
import smtplib
import sqlite3
import sys
import urllib.request
from email.mime.text import MIMEText
from pathlib import Path

import feedparser

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

# ---------------------------------------------------------------------------
# Config & DB helpers
# ---------------------------------------------------------------------------

from aibrain_db import AIBRAIN_ROOT, get_db
_cfg_path = AIBRAIN_ROOT / "config.json"
CONFIG = json.loads(_cfg_path.read_text()) if _cfg_path.exists() else {}
def _find_db():
    """Find best DB path, checking both new and legacy names."""
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    configured = CONFIG.get("db_path")
    if configured and Path(configured).exists():
        return configured
    mem_db = AIBRAIN_ROOT / "memory" / "memory.db"
    if mem_db.exists():
        return str(mem_db)
    return str(AIBRAIN_ROOT / "aibrain.db")

MEMORY_DB = CONFIG.get("db_path", _find_db())
API_BASE = os.environ.get("AIBRAIN_API", os.environ.get("AIBRAIN_API", "http://localhost:8001/api/agent"))


def log_activity(action, detail="", status="ok"):
    try:
        data = json.dumps({
            "action": action, "category": "research",
            "detail": detail, "status": status,
        }).encode()
        req = urllib.request.Request(
            f"{API_BASE}/activity", data=data,
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass


DEFAULT_FEEDS = [
    "https://hnrss.org/frontpage",
    "https://feeds.arstechnica.com/arstechnica/index",
    "https://www.theverge.com/rss/index.xml",
]

MAX_SEEN = 500  # keep last N hashes to prevent unbounded growth
MAX_ITEMS = 30  # cap items per digest


def get_db():
    db = get_db()
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    return db


def load_state(name):
    try:
        db = get_db()
        row = db.execute(
            "SELECT content FROM memories WHERE name=? AND active=1",
            (f"workflow_state:{name}",),
        ).fetchone()
        db.close()
        return json.loads(row["content"]) if row else {}
    except Exception:
        return {}


def save_state(name, state):
    db = get_db()
    try:
        now = datetime.datetime.now().isoformat()
        existing = db.execute(
            "SELECT id FROM memories WHERE name=? AND active=1",
            (f"workflow_state:{name}",),
        ).fetchone()
        if existing:
            db.execute("UPDATE memories SET content=?, updated=? WHERE id=?",
                       (json.dumps(state), now, existing["id"]))
        else:
            db.execute(
                "INSERT INTO memories (name,type,tags,content,created,updated,active) VALUES (?,?,?,?,?,?,1)",
                (f"workflow_state:{name}", "reference", "workflow,state",
                 json.dumps(state), now, now),
            )
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def send_email(to, subject, body, dry_run=False):
    if dry_run:
        print(f"TO: {to}\nSUBJECT: {subject}\n\n{body}")
        return
    agent_email = CONFIG.get("agent_email", "aibrain@localhost")
    agent_password = CONFIG.get("agent_email_password", CONFIG.get("email_app_password", ""))
    msg = MIMEText(body, "plain")
    msg["From"] = agent_email
    msg["To"] = to
    msg["Subject"] = subject
    with smtplib.SMTP_SSL(CONFIG.get("agent_smtp_host", CONFIG.get("email_smtp_host", "smtp.gmail.com")), 465) as s:
        s.login(agent_email, agent_password)
        s.send_message(msg)


def strip_html(text):
    return re.sub(r"<[^>]+>", "", text).strip()


# ---------------------------------------------------------------------------
# RSS logic
# ---------------------------------------------------------------------------

def item_id(entry):
    link = entry.get("link", entry.get("id", entry.get("title", "")))
    return hashlib.md5(link.encode()).hexdigest()


def fetch_newsapi_headlines(api_key, country="us", category=None):
    """Fetch top headlines from NewsAPI (free tier). Returns list of entry-like dicts."""
    headlines = []
    try:
        params = f"country={country}&apiKey={api_key}"
        if category:
            params += f"&category={category}"
        url = f"https://newsapi.org/v2/top-headlines?{params}"
        req = urllib.request.Request(url, headers={"User-Agent": "AIBrain/1.0"})
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read().decode())
        for article in data.get("articles", []):
            headlines.append({
                "title": article.get("title", "Untitled"),
                "link": article.get("url", ""),
                "summary": article.get("description") or "",
                "source": article.get("source", {}).get("name", "NewsAPI"),
            })
    except Exception as e:
        print(f"Warning: NewsAPI fetch failed: {e}", file=sys.stderr)
    return headlines


def fetch_feeds(feed_urls):
    results = {}
    for url in feed_urls:
        try:
            feed = feedparser.parse(url)
            title = feed.feed.get("title", url)
            results[title] = feed.entries
        except Exception as e:
            results[f"ERROR: {url}"] = []
            print(f"Warning: failed to parse {url}: {e}", file=sys.stderr)
    return results


def format_digest(new_items, feed_items):
    now = datetime.datetime.now()
    lines = [
        f"RSS DIGEST — {now.strftime('%A %B %d, %Y')}",
        f"{len(new_items)} new items across {len(feed_items)} feeds",
        "=" * 50,
        "",
    ]

    for feed_name, entries in feed_items.items():
        if not entries:
            continue
        lines.append(f"--- {feed_name} ({len(entries)} new) ---")
        lines.append("")
        for entry in entries[:10]:  # max 10 per feed
            title = entry.get("title", "Untitled")
            link = entry.get("link", "")
            summary = strip_html(entry.get("summary", ""))[:150]
            lines.append(f"  {title}")
            if link:
                lines.append(f"  {link}")
            if summary:
                lines.append(f"  {summary}")
            lines.append("")

    if not new_items:
        lines.append("No new items since last digest.")
        lines.append("")

    lines.append("—\nPowered by AIBrain | News data from NewsAPI.org")
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="AIBrain RSS Digest")
    parser.add_argument("--dry-run", action="store_true", help="Print instead of emailing")
    args = parser.parse_args()

    feeds = CONFIG.get("rss_feeds", DEFAULT_FEEDS)
    email_to = CONFIG.get("email_to", CONFIG.get("agent_email", ""))

    state = load_state("rss_digest")
    seen_ids = set(list(state.get("seen_ids", []))[-MAX_SEEN:])

    all_feeds = fetch_feeds(feeds)

    # Supplement with NewsAPI headlines if API key is configured
    newsapi_key = CONFIG.get("newsapi_key", os.environ.get("NEWSAPI_KEY", ""))
    if newsapi_key:
        newsapi_items = fetch_newsapi_headlines(
            newsapi_key,
            country=CONFIG.get("newsapi_country", "us"),
            category=CONFIG.get("newsapi_category"),
        )
        if newsapi_items:
            all_feeds["NewsAPI Top Headlines"] = newsapi_items

    new_items = []
    feed_new = {}
    for feed_name, entries in all_feeds.items():
        new_entries = []
        for entry in entries:
            eid = item_id(entry)
            if eid not in seen_ids:
                new_entries.append(entry)
                new_items.append(entry)
                seen_ids.add(eid)
        if new_entries:
            feed_new[feed_name] = new_entries

    # Cap total items
    new_items = new_items[:MAX_ITEMS]

    digest = format_digest(new_items, feed_new)

    if not email_to or args.dry_run:
        print(digest)
    else:
        send_email(email_to, f"RSS Digest — {len(new_items)} new items", digest)
        print(f"Sent RSS digest ({len(new_items)} items) to {email_to}")

    # Trim seen list
    seen_list = list(seen_ids)[-MAX_SEEN:]
    save_state("rss_digest", {
        "last_run": datetime.datetime.now().isoformat(),
        "seen_ids": seen_list,
    })

    log_activity("rss_digest", f"{len(new_items)} new items from {len(all_feeds)} feeds")


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name='rss_digest',
        action=_workflow_entry,
        task_type='simple',
        actor='cli',
    )
