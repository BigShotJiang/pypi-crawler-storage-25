"""Shared Telegram notification utility for AIBrain workflows.

All sends are fire-and-forget via daemon threads — the caller never blocks
waiting on the Telegram API. If Telegram is slow or down, workflows continue.

Usage:
    from telegram_utils import send_telegram
    send_telegram("Job done.")
    send_telegram("Alert!", chat_id="-5288572284")
"""

import json
import os
import threading
import urllib.request

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute


def _resolve_token() -> str:
    """Try both env var naming conventions used across workflows."""
    return (
        os.environ.get("TELEGRAM_BOT_TOKEN")
        or os.environ.get("TELEGRAM_TOKEN")
        or ""
    )


def _resolve_chat_id() -> str:
    return os.environ.get("TELEGRAM_CHAT_ID", "")


def send_telegram(
    message: str,
    chat_id: str | None = None,
    token: str | None = None,
    parse_mode: str = "HTML",
) -> None:
    """Send a Telegram message. Non-blocking — returns immediately.

    Args:
        message:    Text to send.
        chat_id:    Destination chat ID. Defaults to TELEGRAM_CHAT_ID env var.
        token:      Bot token. Defaults to TELEGRAM_BOT_TOKEN / TELEGRAM_TOKEN.
        parse_mode: Telegram parse mode. Default "HTML".
    """
    resolved_token = token or _resolve_token()
    resolved_chat = chat_id or _resolve_chat_id()
    if not resolved_token or not resolved_chat:
        return

    def _send() -> None:
        url = f"https://api.telegram.org/bot{resolved_token}/sendMessage"
        payload = json.dumps({
            "chat_id": resolved_chat,
            "text": message,
            "parse_mode": parse_mode,
        }).encode()
        req = urllib.request.Request(
            url, data=payload, headers={"Content-Type": "application/json"}
        )
        try:
            urllib.request.urlopen(req, timeout=10)
        except Exception:
            pass

    threading.Thread(target=_send, daemon=True).start()
