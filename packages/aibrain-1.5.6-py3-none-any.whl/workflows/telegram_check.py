#!/usr/bin/env python3
"""Smart telegram inbox check — delegates to shared agent_comms module.

This file used to duplicate the actioned-tracking logic. That caused drift:
broker_hook.py had its own "last seen timestamp" file while this script used
an actioned JSONL. On session restart the hook would re-surface messages
that the check script considered handled. Fix: both now use agent_comms.

Usage:
    python telegram_check.py
    python telegram_check.py --action "TIMESTAMP" "summary"
    python telegram_check.py --action-all
"""

import sys
from pathlib import Path

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

# Make agent_comms importable from decker_system tools
_TOOLS_DIR = Path(r"C:\Users\sinde\decker_system\04_tools")
if str(_TOOLS_DIR) not in sys.path:
    sys.path.insert(0, str(_TOOLS_DIR))

import agent_comms  # noqa: E402

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


def main() -> int:
    return agent_comms._cli(sys.argv)


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        sys.exit(main())
    workflow_execute(
        workflow_name='telegram_check',
        action=_workflow_entry,
        task_type='deterministic',
        actor='cli',
    )
