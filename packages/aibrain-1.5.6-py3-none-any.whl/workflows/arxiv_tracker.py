#!/usr/bin/env python3
"""AIBrain Workflow: ArXiv Tracker — monitor academic papers by topic."""

import argparse
import datetime
import hashlib
import json
import os
import smtplib
import sqlite3
import sys
import urllib.request
from email.mime.text import MIMEText
from pathlib import Path

import requests
from bs4 import BeautifulSoup

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

from aibrain_db import AIBRAIN_ROOT, get_db
_cfg_path = AIBRAIN_ROOT / "config.json"
CONFIG = json.loads(_cfg_path.read_text()) if _cfg_path.exists() else {}
def _find_db():
    """Find best DB path, checking both new and legacy names."""
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    configured = CONFIG.get("db_path")
    if configured and Path(configured).exists():
        return configured
    mem_db = AIBRAIN_ROOT / "memory" / "memory.db"
    if mem_db.exists():
        return str(mem_db)
    return str(AIBRAIN_ROOT / "aibrain.db")

MEMORY_DB = CONFIG.get("db_path", _find_db())
API_BASE = os.environ.get("AIBRAIN_API", os.environ.get("AIBRAIN_API", "http://localhost:8001/api/agent"))


def log_activity(action, detail="", status="ok"):
    try:
        data = json.dumps({
            "action": action, "category": "research",
            "detail": detail, "status": status,
        }).encode()
        req = urllib.request.Request(
            f"{API_BASE}/activity", data=data,
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass


DEFAULT_QUERIES = ["large language model", "autonomous agent", "vulnerability detection"]


def get_db():
    db = get_db()
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    return db

def load_state(name):
    try:
        db = get_db()
        row = db.execute("SELECT content FROM memories WHERE name=? AND active=1",
                         (f"workflow_state:{name}",)).fetchone()
        db.close()
        return json.loads(row["content"]) if row else {}
    except Exception:
        return {}

def save_state(name, state):
    db = get_db()
    try:
        now = datetime.datetime.now().isoformat()
        existing = db.execute("SELECT id FROM memories WHERE name=? AND active=1",
                             (f"workflow_state:{name}",)).fetchone()
        if existing:
            db.execute("UPDATE memories SET content=?, updated=? WHERE id=?",
                       (json.dumps(state), now, existing["id"]))
        else:
            db.execute("INSERT INTO memories (name,type,tags,content,created,updated,active) VALUES (?,?,?,?,?,?,1)",
                       (f"workflow_state:{name}", "reference", "workflow,state", json.dumps(state), now, now))
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()

def send_email(to, subject, body, dry_run=False):
    if dry_run:
        print(f"TO: {to}\nSUBJECT: {subject}\n\n{body}")
        return
    agent_email = CONFIG.get("agent_email", "aibrain@localhost")
    agent_password = CONFIG.get("agent_email_password", CONFIG.get("email_app_password", ""))
    msg = MIMEText(body, "plain")
    msg["From"] = agent_email
    msg["To"] = to
    msg["Subject"] = subject
    with smtplib.SMTP_SSL(CONFIG.get("agent_smtp_host", CONFIG.get("email_smtp_host", "smtp.gmail.com")), 465) as s:
        s.login(agent_email, agent_password)
        s.send_message(msg)


def search_arxiv(query, max_results=10):
    papers = []
    try:
        url = f"http://export.arxiv.org/api/query?search_query=all:{query}&sortBy=submittedDate&max_results={max_results}"
        resp = requests.get(url, timeout=15)
        soup = BeautifulSoup(resp.text, "xml")
        for entry in soup.find_all("entry"):
            paper_id = entry.find("id").text.strip()
            title = entry.find("title").text.strip().replace("\n", " ")
            summary = entry.find("summary").text.strip().replace("\n", " ")[:200]
            authors = [a.find("name").text for a in entry.find_all("author")][:3]
            published = entry.find("published").text[:10]
            papers.append({
                "id": hashlib.md5(paper_id.encode()).hexdigest()[:12],
                "arxiv_id": paper_id.split("/")[-1],
                "title": title,
                "summary": summary,
                "authors": ", ".join(authors) + (" et al." if len(entry.find_all("author")) > 3 else ""),
                "published": published,
                "url": paper_id,
            })
    except Exception as e:
        print(f"ArXiv error for '{query}': {e}", file=sys.stderr)
    return papers


def format_digest(results, seen_ids):
    lines = [
        f"ARXIV TRACKER — {datetime.datetime.now().strftime('%A %B %d, %Y')}",
        "=" * 50,
        "",
    ]

    total_new = 0
    for query, papers in results.items():
        new_papers = [p for p in papers if p["id"] not in seen_ids]
        total_new += len(new_papers)

        lines.append(f"--- {query} ({len(new_papers)} new / {len(papers)} total) ---")
        for p in new_papers[:5]:
            lines.append(f"  {p['title']}")
            lines.append(f"  {p['authors']} — {p['published']}")
            lines.append(f"  {p['url']}")
            lines.append(f"  {p['summary']}")
            lines.append("")

        if not new_papers:
            lines.append("  No new papers since last check.")
            lines.append("")

    lines.append(f"Total: {total_new} new papers")
    lines.append("—\nPowered by AIBrain + ArXiv API (free)")
    return "\n".join(lines), total_new


def main():
    parser = argparse.ArgumentParser(description="AIBrain ArXiv Tracker")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    queries = CONFIG.get("arxiv_queries", DEFAULT_QUERIES)
    email_to = CONFIG.get("email_to", CONFIG.get("agent_email", ""))
    state = load_state("arxiv_tracker")
    seen_ids = set(list(state.get("seen_ids", []))[-500:])

    results = {}
    all_new_ids = []
    for q in queries:
        print(f"  Searching: {q}")
        papers = search_arxiv(q)
        results[q] = papers
        all_new_ids.extend(p["id"] for p in papers)

    digest, total_new = format_digest(results, seen_ids)

    if not email_to or args.dry_run:
        print(digest)
    else:
        send_email(email_to, f"ArXiv Tracker — {total_new} new papers", digest)
        print(f"Sent ArXiv digest ({total_new} papers) to {email_to}")

    seen_ids.update(all_new_ids)
    save_state("arxiv_tracker", {
        "last_run": datetime.datetime.now().isoformat(),
        "seen_ids": list(seen_ids)[-500:],
    })

    log_activity("arxiv_tracker", f"{total_new} new papers across {len(queries)} queries")


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name='arxiv_tracker',
        action=_workflow_entry,
        task_type='simple',
        actor='cli',
    )
