#!/usr/bin/env python3
"""AIBrain Workflow: Knowledge Graph Builder — extract entities, relationships,
and semantic facts from memories to build a compounding knowledge graph.

Runs every 6 hours. Processes memories added since last run:
1. Extract entities from each memory (tech, people, URLs, etc.)
2. Detect co-occurrence relationships between entities across memories
3. Extract SPO triples (subject-predicate-object) from memory content
4. Create hyperedges linking memories that share 3+ entities
5. Merge duplicate/similar entities (deduplication pass)

The graph powers cross-domain questions, knowledge traversal, and
compounding intelligence — each new memory enriches the entire graph.

Usage:
    python knowledge_graph_builder.py               # Full build
    python knowledge_graph_builder.py --dry-run      # Report only
    python knowledge_graph_builder.py --rebuild       # Re-index all memories
    python knowledge_graph_builder.py --stats         # Show graph statistics
    python knowledge_graph_builder.py --dedup         # Run deduplication pass
"""

import argparse
import json
import logging
import os
import re
import sqlite3
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

# ---------------------------------------------------------------------------
# Paths and constants
# ---------------------------------------------------------------------------

from aibrain_db import AIBRAIN_ROOT
logger = logging.getLogger("knowledge_graph_builder")

BATCH_SIZE = 200          # memories per batch
CO_OCCURRENCE_MIN = 2     # min shared entities to create a link
HYPEREDGE_MIN = 3         # min shared entities to create a hyperedge
DEDUP_THRESHOLD = 0.85    # similarity threshold for entity dedup

# ---------------------------------------------------------------------------
# SPO extraction patterns (no LLM — regex + heuristics)
# ---------------------------------------------------------------------------

# Patterns that capture (subject, predicate, object) from natural language
_SPO_PATTERNS = [
    # "X uses Y", "X using Y"
    (re.compile(r"\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\s+(?:uses?|using)\s+([A-Z][a-z]+(?:\s*[A-Za-z.]*)*)", re.MULTILINE),
     "uses"),
    # "X depends on Y", "X dependent on Y"
    (re.compile(r"\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\s+(?:depends?\s+on|dependent\s+on|relies?\s+on)\s+([A-Z][a-z]+(?:\s*[A-Za-z.]*)*)", re.MULTILINE),
     "depends_on"),
    # "X built with Y", "X written in Y"
    (re.compile(r"\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\s+(?:built\s+(?:with|in|on|using)|written\s+in|powered\s+by)\s+([A-Za-z][A-Za-z.+#]*)", re.MULTILINE),
     "built_with"),
    # "X replaces Y", "X replaced by Y"
    (re.compile(r"\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\s+(?:replaces?|replaced)\s+([A-Z][a-z]+(?:\s*[A-Za-z.]*)*)", re.MULTILINE),
     "replaces"),
    # "X integrates with Y"
    (re.compile(r"\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\s+integrates?\s+(?:with|into)\s+([A-Z][a-z]+(?:\s*[A-Za-z.]*)*)", re.MULTILINE),
     "integrates_with"),
    # "X is a Y", "X is an Y"
    (re.compile(r"\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\s+is\s+(?:a|an)\s+([a-z][a-z\s]{2,30})", re.MULTILINE),
     "is_a"),
    # "X caused by Y", "X due to Y"
    (re.compile(r"\b([A-Z][a-z]+(?:\s+[a-z]+)*)\s+(?:caused\s+by|due\s+to|because\s+of)\s+([a-z][a-z\s]{2,40})", re.MULTILINE),
     "caused_by"),
    # "fixed X by Y", "resolved X with Y"
    (re.compile(r"(?:fixed|resolved|solved)\s+(.{5,40}?)\s+(?:by|with|using)\s+(.{5,40}?)(?:\.|$)", re.MULTILINE | re.IGNORECASE),
     "fixed_by"),
    # "learned that X", "discovered X"
    (re.compile(r"(?:learned|discovered|found)\s+that\s+(.{10,60})", re.MULTILINE | re.IGNORECASE),
     "learned"),
]

# Simpler keyword-based relationship detection
_KEYWORD_RELATIONSHIPS = {
    "alternative_to": ["alternative to", "instead of", "rather than", "swap for"],
    "part_of": ["part of", "component of", "module of", "subset of"],
    "works_at": ["works at", "employed at", "joined"],
    "created_by": ["created by", "built by", "developed by", "authored by", "made by"],
}


def _find_db():
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    return str(AIBRAIN_ROOT / "aibrain.db")


def _get_db(db_path=None):
    path = db_path or _find_db()
    db = sqlite3.connect(path)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA journal_mode=WAL")
    return db


def _log_activity(workflow, message):
    """Log to activity table if it exists."""
    try:
        db = _get_db()
        db.execute(
            "INSERT INTO activity (type, message, created_at) VALUES (?, ?, ?)",
            (workflow, message, datetime.now().isoformat())
        )
        db.commit()
        db.close()
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Entity extraction (delegates to entity_extractor.py)
# ---------------------------------------------------------------------------

def _ensure_entity_tables(db):
    """Create entity tables if not present."""
    db.execute("""
        CREATE TABLE IF NOT EXISTS entities (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            type TEXT NOT NULL,
            category TEXT DEFAULT '',
            mention_count INTEGER DEFAULT 1,
            first_seen TEXT NOT NULL,
            last_seen TEXT NOT NULL,
            UNIQUE(name, type)
        )
    """)
    db.execute("""
        CREATE TABLE IF NOT EXISTS memory_entities (
            memory_id INTEGER NOT NULL,
            entity_id INTEGER NOT NULL,
            PRIMARY KEY (memory_id, entity_id)
        )
    """)
    db.execute("""
        CREATE TABLE IF NOT EXISTS graph_build_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            run_at TEXT NOT NULL,
            memories_processed INTEGER DEFAULT 0,
            entities_found INTEGER DEFAULT 0,
            links_created INTEGER DEFAULT 0,
            facts_extracted INTEGER DEFAULT 0,
            hyperedges_created INTEGER DEFAULT 0,
            duration_ms INTEGER DEFAULT 0,
            watermark_id INTEGER DEFAULT 0
        )
    """)
    db.commit()


def _extract_entities(text):
    """Extract entities using the same logic as entity_extractor.py."""
    try:
        from backend.entity_extractor import extract_entities
        return extract_entities(text)
    except ImportError:
        pass
    # Inline fallback: basic tech + name extraction
    try:
        sys_path = str(AIBRAIN_ROOT)
        import sys
        if sys_path not in sys.path:
            sys.path.insert(0, sys_path)
        from backend.entity_extractor import extract_entities
        return extract_entities(text)
    except ImportError:
        return _extract_entities_fallback(text)


def _extract_entities_fallback(text):
    """Minimal entity extraction without entity_extractor module."""
    entities = []
    seen = set()

    # Capitalized phrases (names, projects)
    for m in re.finditer(r"\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)\b", text):
        phrase = m.group(1)
        key = phrase.lower()
        if key not in seen and len(phrase) > 4:
            seen.add(key)
            entities.append({"name": phrase, "type": "name", "category": "entity"})

    # Common tech terms
    tech_terms = [
        "python", "javascript", "react", "fastapi", "docker", "redis",
        "sqlite", "postgresql", "claude", "gpt-4", "nginx", "git",
        "telegram", "github", "linux", "windows",
    ]
    lower = text.lower()
    for term in tech_terms:
        if term in lower and term not in seen:
            seen.add(term)
            entities.append({"name": term, "type": "technology", "category": "tool"})

    return entities


# ---------------------------------------------------------------------------
# SPO triple extraction
# ---------------------------------------------------------------------------

def extract_spo_triples(text):
    """Extract subject-predicate-object triples from text using patterns."""
    triples = []
    seen = set()

    # Pattern-based extraction
    for pattern, predicate in _SPO_PATTERNS:
        try:
            for match in pattern.finditer(text):
                groups = match.groups()
                if len(groups) >= 2:
                    subj = groups[0].strip()[:100]
                    obj = groups[1].strip()[:100]
                elif len(groups) == 1:
                    # "learned that X" type — subject is implicit
                    subj = "agent"
                    obj = groups[0].strip()[:100]
                else:
                    continue

                # Clean up
                subj = subj.rstrip(".,;:")
                obj = obj.rstrip(".,;:")

                if len(subj) < 2 or len(obj) < 2:
                    continue

                key = (subj.lower(), predicate, obj.lower())
                if key not in seen:
                    seen.add(key)
                    triples.append({
                        "subject": subj,
                        "predicate": predicate,
                        "object": obj,
                        "snippet": match.group()[:200],
                    })
        except re.error:
            continue

    # Keyword-based relationship detection
    for rel, keywords in _KEYWORD_RELATIONSHIPS.items():
        for kw in keywords:
            idx = text.lower().find(kw)
            if idx == -1:
                continue
            # Get surrounding context
            start = max(0, idx - 50)
            end = min(len(text), idx + len(kw) + 50)
            context = text[start:end]

            # Try to find entities around the keyword
            before = text[max(0, idx - 50):idx].strip()
            after = text[idx + len(kw):min(len(text), idx + len(kw) + 50)].strip()

            # Find last capitalized word/phrase before keyword
            subj_match = re.search(r"([A-Z][A-Za-z]+(?:\s+[A-Za-z]+)*)\s*$", before)
            obj_match = re.search(r"^([A-Z][A-Za-z]+(?:\s+[A-Za-z]+)*)", after)

            if subj_match and obj_match:
                subj = subj_match.group(1).strip()[:100]
                obj = obj_match.group(1).strip()[:100]
                key = (subj.lower(), rel, obj.lower())
                if key not in seen:
                    seen.add(key)
                    triples.append({
                        "subject": subj,
                        "predicate": rel,
                        "object": obj,
                        "snippet": context[:200],
                    })

    return triples


# ---------------------------------------------------------------------------
# Core graph building
# ---------------------------------------------------------------------------

def get_watermark(db):
    """Get the last processed memory ID."""
    try:
        row = db.execute(
            "SELECT MAX(watermark_id) as wm FROM graph_build_log"
        ).fetchone()
        return row["wm"] or 0
    except sqlite3.OperationalError:
        return 0


def process_memories(db, start_id=0, limit=BATCH_SIZE, dry_run=False):
    """Process memories from start_id, extract entities and relationships.

    Returns dict with processing stats.
    """
    stats = {
        "memories_processed": 0,
        "entities_found": 0,
        "new_entities": 0,
        "links_created": 0,
        "facts_extracted": 0,
        "hyperedges_created": 0,
        "max_id": start_id,
    }

    # Fetch unprocessed memories
    rows = db.execute("""
        SELECT id, name, content, type, tags
        FROM memories
        WHERE id > ? AND active = 1
        ORDER BY id ASC
        LIMIT ?
    """, (start_id, limit)).fetchall()

    if not rows:
        return stats

    now = datetime.now().isoformat()

    # Phase 1: Entity extraction per memory
    memory_entities = {}  # memory_id -> [(entity_name, entity_type), ...]

    for row in rows:
        mid = row["id"]
        full_text = f"{row['name']} {row['content']}"
        if row["tags"]:
            full_text += f" {row['tags']}"

        entities = _extract_entities(full_text)
        stats["entities_found"] += len(entities)
        stats["memories_processed"] += 1
        stats["max_id"] = max(stats["max_id"], mid)

        entity_ids = []
        for ent in entities:
            if dry_run:
                entity_ids.append((ent["name"], ent["type"]))
                continue

            # Upsert entity
            existing = db.execute(
                "SELECT id FROM entities WHERE name = ? AND type = ?",
                (ent["name"], ent["type"])
            ).fetchone()

            if existing:
                entity_id = existing["id"]
                db.execute(
                    "UPDATE entities SET mention_count = mention_count + 1, last_seen = ? WHERE id = ?",
                    (now, entity_id)
                )
            else:
                # Check tier limit before creating new entity
                try:
                    from aibrain_licensing import check_limit
                    check_limit("entities")
                except ImportError:
                    pass
                except Exception:
                    # At entity cap — skip new entities, still link existing ones
                    continue
                cursor = db.execute(
                    "INSERT INTO entities (name, type, category, first_seen, last_seen) VALUES (?, ?, ?, ?, ?)",
                    (ent["name"], ent["type"], ent.get("category", ""), now, now)
                )
                entity_id = cursor.lastrowid
                stats["new_entities"] += 1

            # Link entity to memory
            db.execute(
                "INSERT OR IGNORE INTO memory_entities (memory_id, entity_id) VALUES (?, ?)",
                (mid, entity_id)
            )
            entity_ids.append((ent["name"], ent["type"], entity_id))

        memory_entities[mid] = entity_ids

        # Phase 1b: SPO triple extraction
        triples = extract_spo_triples(full_text)
        for triple in triples:
            stats["facts_extracted"] += 1
            if dry_run:
                continue

            # Check for existing fact
            existing_fact = db.execute(
                "SELECT fact_id FROM semantic_facts WHERE subject = ? AND predicate = ? AND object = ?",
                (triple["subject"], triple["predicate"], triple["object"])
            ).fetchone()

            if existing_fact:
                fact_id = existing_fact["fact_id"]
                db.execute(
                    "UPDATE semantic_facts SET confidence = MIN(1.0, confidence + 0.1), updated_at = ? WHERE fact_id = ?",
                    (now, fact_id)
                )
            else:
                cursor = db.execute(
                    "INSERT INTO semantic_facts (subject, predicate, object, fact_type, confidence) VALUES (?, ?, ?, 'relationship', 0.5)",
                    (triple["subject"], triple["predicate"], triple["object"])
                )
                fact_id = cursor.lastrowid

            # Record evidence
            db.execute(
                "INSERT INTO fact_evidence (fact_id, source_memory_id, extraction_method, verbatim_snippet) VALUES (?, ?, 'pattern', ?)",
                (fact_id, mid, triple.get("snippet", "")[:500])
            )

    if dry_run:
        return stats

    # Phase 2: Co-occurrence links between memories
    # Find pairs of memories that share entities
    entity_to_memories = defaultdict(set)
    for mid, ents in memory_entities.items():
        for ent_info in ents:
            if len(ent_info) >= 3:
                entity_to_memories[ent_info[2]].add(mid)  # entity_id -> set of memory_ids

    # Create entity_links for co-occurring memories
    pair_shared = Counter()  # (m1, m2) -> count of shared entities
    for eid, mids in entity_to_memories.items():
        mids_list = sorted(mids)
        for i in range(len(mids_list)):
            for j in range(i + 1, len(mids_list)):
                pair_shared[(mids_list[i], mids_list[j])] += 1

    for (m1, m2), count in pair_shared.items():
        if count >= CO_OCCURRENCE_MIN:
            db.execute("""
                INSERT OR IGNORE INTO entity_links
                (source_type, source_id, target_type, target_id, relationship, metadata)
                VALUES ('memory', ?, 'memory', ?, 'co_occurrence',
                        json_object('shared_entities', ?))
            """, (m1, m2, count))
            stats["links_created"] += 1

        # Create hyperedges for memories with 3+ shared entities
        if count >= HYPEREDGE_MIN:
            # Check if hyperedge already exists
            existing = db.execute("""
                SELECT h.id FROM hyperedges h
                JOIN hyperedge_members hm1 ON h.id = hm1.hyperedge_id AND hm1.memory_id = ?
                JOIN hyperedge_members hm2 ON h.id = hm2.hyperedge_id AND hm2.memory_id = ?
                WHERE h.label = 'shared_knowledge'
            """, (m1, m2)).fetchone()

            if not existing:
                try:
                    db.execute(
                        "INSERT INTO hyperedges (label, confidence, metadata) VALUES ('shared_knowledge', ?, ?)",
                        (min(1.0, count * 0.2), json.dumps({"shared_entities": count}))
                    )
                    edge_id = db.execute("SELECT last_insert_rowid()").fetchone()[0]
                    db.execute(
                        "INSERT INTO hyperedge_members (hyperedge_id, memory_id, role) VALUES (?, ?, 'member')",
                        (edge_id, m1)
                    )
                    db.execute(
                        "INSERT INTO hyperedge_members (hyperedge_id, memory_id, role) VALUES (?, ?, 'member')",
                        (edge_id, m2)
                    )
                    stats["hyperedges_created"] += 1
                except sqlite3.IntegrityError:
                    pass

    db.commit()
    return stats


# ---------------------------------------------------------------------------
# Entity deduplication
# ---------------------------------------------------------------------------

def dedup_entities(db, dry_run=False):
    """Merge duplicate entities (e.g., 'python' and 'Python', 'react' and 'React.js')."""
    entities = db.execute(
        "SELECT id, name, type, category, mention_count FROM entities ORDER BY mention_count DESC"
    ).fetchall()

    merge_map = {}  # entity_id to merge into -> entity_id to absorb
    seen = {}       # normalized_name -> canonical entity

    # Normalize and group
    for ent in entities:
        # Normalize: lowercase, strip trailing version numbers, common suffixes
        norm = ent["name"].lower().strip()
        norm = re.sub(r"\.js$", "", norm)
        norm = re.sub(r"\s*\d+(\.\d+)*$", "", norm)
        norm = norm.replace("-", "").replace("_", "")

        key = (norm, ent["type"])
        if key in seen:
            # This is a duplicate — merge into the canonical (higher mention_count)
            canonical = seen[key]
            merge_map[ent["id"]] = canonical["id"]
        else:
            seen[key] = dict(ent)

    if dry_run:
        return {"duplicates_found": len(merge_map), "merges": [
            {"from": eid, "into": target} for eid, target in merge_map.items()
        ]}

    merged = 0
    for dup_id, canonical_id in merge_map.items():
        # Move memory_entities references
        db.execute("""
            UPDATE OR IGNORE memory_entities SET entity_id = ? WHERE entity_id = ?
        """, (canonical_id, dup_id))
        # Remove orphaned references
        db.execute("DELETE FROM memory_entities WHERE entity_id = ?", (dup_id,))
        # Add mention count to canonical
        db.execute("""
            UPDATE entities SET mention_count = mention_count + (
                SELECT mention_count FROM entities WHERE id = ?
            ) WHERE id = ?
        """, (dup_id, canonical_id))
        # Delete duplicate
        db.execute("DELETE FROM entities WHERE id = ?", (dup_id,))
        merged += 1

    db.commit()
    return {"duplicates_found": len(merge_map), "merged": merged}


# ---------------------------------------------------------------------------
# Statistics
# ---------------------------------------------------------------------------

def get_graph_stats(db):
    """Return graph statistics."""
    stats = {}

    try:
        stats["total_entities"] = db.execute("SELECT COUNT(*) FROM entities").fetchone()[0]
    except sqlite3.OperationalError:
        stats["total_entities"] = 0

    try:
        stats["total_memory_links"] = db.execute("SELECT COUNT(*) FROM memory_entities").fetchone()[0]
    except sqlite3.OperationalError:
        stats["total_memory_links"] = 0

    try:
        stats["total_entity_links"] = db.execute(
            "SELECT COUNT(*) FROM entity_links WHERE relationship = 'co_occurrence'"
        ).fetchone()[0]
    except sqlite3.OperationalError:
        stats["total_entity_links"] = 0

    try:
        stats["total_facts"] = db.execute("SELECT COUNT(*) FROM semantic_facts").fetchone()[0]
    except sqlite3.OperationalError:
        stats["total_facts"] = 0

    try:
        stats["total_hyperedges"] = db.execute("SELECT COUNT(*) FROM hyperedges").fetchone()[0]
    except sqlite3.OperationalError:
        stats["total_hyperedges"] = 0

    try:
        stats["total_memories"] = db.execute("SELECT COUNT(*) FROM memories WHERE active = 1").fetchone()[0]
    except sqlite3.OperationalError:
        stats["total_memories"] = 0

    try:
        stats["indexed_memories"] = db.execute(
            "SELECT COUNT(DISTINCT memory_id) FROM memory_entities"
        ).fetchone()[0]
    except sqlite3.OperationalError:
        stats["indexed_memories"] = 0

    # Top entities by mention count
    try:
        top = db.execute(
            "SELECT name, type, mention_count FROM entities ORDER BY mention_count DESC LIMIT 15"
        ).fetchall()
        stats["top_entities"] = [dict(r) for r in top]
    except sqlite3.OperationalError:
        stats["top_entities"] = []

    # Fact predicates distribution
    try:
        predicates = db.execute(
            "SELECT predicate, COUNT(*) as cnt FROM semantic_facts GROUP BY predicate ORDER BY cnt DESC LIMIT 10"
        ).fetchall()
        stats["fact_predicates"] = {r["predicate"]: r["cnt"] for r in predicates}
    except sqlite3.OperationalError:
        stats["fact_predicates"] = {}

    # Build history
    try:
        history = db.execute(
            "SELECT * FROM graph_build_log ORDER BY run_at DESC LIMIT 5"
        ).fetchall()
        stats["recent_builds"] = [dict(r) for r in history]
    except sqlite3.OperationalError:
        stats["recent_builds"] = []

    return stats


def format_stats(stats):
    """Format stats for display."""
    lines = ["=== Knowledge Graph Statistics ===", ""]
    lines.append(f"Memories:       {stats.get('total_memories', 0)} total, {stats.get('indexed_memories', 0)} indexed")
    lines.append(f"Entities:       {stats.get('total_entities', 0)}")
    lines.append(f"Memory-Entity:  {stats.get('total_memory_links', 0)} links")
    lines.append(f"Co-occurrence:  {stats.get('total_entity_links', 0)} links")
    lines.append(f"Semantic Facts: {stats.get('total_facts', 0)}")
    lines.append(f"Hyperedges:     {stats.get('total_hyperedges', 0)}")

    if stats.get("top_entities"):
        lines.append("")
        lines.append("Top Entities:")
        for ent in stats["top_entities"]:
            lines.append(f"  {ent['name']:30s} ({ent['type']:12s}) x{ent['mention_count']}")

    if stats.get("fact_predicates"):
        lines.append("")
        lines.append("Fact Predicates:")
        for pred, cnt in stats["fact_predicates"].items():
            lines.append(f"  {pred:25s} {cnt}")

    if stats.get("recent_builds"):
        lines.append("")
        lines.append("Recent Builds:")
        for build in stats["recent_builds"]:
            lines.append(f"  {build.get('run_at', '?')}: {build.get('memories_processed', 0)} memories, "
                         f"{build.get('entities_found', 0)} entities, "
                         f"{build.get('links_created', 0)} links, "
                         f"{build.get('facts_extracted', 0)} facts")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Main pipeline
# ---------------------------------------------------------------------------

def run_build(dry_run=False, rebuild=False, db_path=None, batch_size=BATCH_SIZE):
    """Run the full knowledge graph build pipeline."""
    import time
    start = time.time()

    db = _get_db(db_path)
    _ensure_entity_tables(db)

    watermark = 0 if rebuild else get_watermark(db)

    total_stats = {
        "memories_processed": 0,
        "entities_found": 0,
        "new_entities": 0,
        "links_created": 0,
        "facts_extracted": 0,
        "hyperedges_created": 0,
    }

    # Process in batches
    current_id = watermark
    while True:
        batch_stats = process_memories(db, start_id=current_id, limit=batch_size, dry_run=dry_run)
        if batch_stats["memories_processed"] == 0:
            break

        for key in total_stats:
            total_stats[key] += batch_stats.get(key, 0)
        current_id = batch_stats["max_id"]

    # Dedup pass
    dedup_result = dedup_entities(db, dry_run=dry_run)
    total_stats["dedup"] = dedup_result

    duration_ms = int((time.time() - start) * 1000)

    # Log the build
    if not dry_run and total_stats["memories_processed"] > 0:
        db.execute("""
            INSERT INTO graph_build_log
            (run_at, memories_processed, entities_found, links_created,
             facts_extracted, hyperedges_created, duration_ms, watermark_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            datetime.now().isoformat(),
            total_stats["memories_processed"],
            total_stats["entities_found"],
            total_stats["links_created"],
            total_stats["facts_extracted"],
            total_stats["hyperedges_created"],
            duration_ms,
            current_id,
        ))
        db.commit()

    db.close()

    total_stats["duration_ms"] = duration_ms
    total_stats["watermark"] = current_id
    total_stats["mode"] = "dry_run" if dry_run else ("rebuild" if rebuild else "incremental")

    return total_stats


def format_report(stats):
    """Format build results for display."""
    lines = [f"=== Knowledge Graph Build ({stats.get('mode', 'incremental')}) ===", ""]
    lines.append(f"Memories processed: {stats['memories_processed']}")
    lines.append(f"Entities found:     {stats['entities_found']} ({stats.get('new_entities', 0)} new)")
    lines.append(f"Co-occurrence links: {stats['links_created']}")
    lines.append(f"Semantic facts:     {stats['facts_extracted']}")
    lines.append(f"Hyperedges:         {stats['hyperedges_created']}")

    dedup = stats.get("dedup", {})
    if dedup.get("duplicates_found", 0) > 0:
        lines.append(f"Dedup:              {dedup.get('merged', dedup.get('duplicates_found', 0))} merged")

    lines.append(f"Duration:           {stats['duration_ms']}ms")
    lines.append(f"Watermark:          memory #{stats['watermark']}")

    if stats["memories_processed"] == 0:
        lines.append("")
        lines.append("No new memories to process. Graph is up to date.")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Knowledge Graph Builder — extract entities and relationships from memories."
    )
    parser.add_argument("--dry-run", action="store_true", help="Report only, no DB changes")
    parser.add_argument("--rebuild", action="store_true", help="Re-index all memories from scratch")
    parser.add_argument("--stats", action="store_true", help="Show graph statistics")
    parser.add_argument("--dedup", action="store_true", help="Run entity deduplication only")
    parser.add_argument("--batch-size", type=int, default=BATCH_SIZE, help=f"Batch size (default: {BATCH_SIZE})")
    parser.add_argument("--db", type=str, default=None, help="Database path override")

    args = parser.parse_args()
    db_path = args.db

    if args.stats:
        db = _get_db(db_path)
        _ensure_entity_tables(db)
        stats = get_graph_stats(db)
        db.close()
        print(format_stats(stats))
        return

    if args.dedup:
        db = _get_db(db_path)
        _ensure_entity_tables(db)
        result = dedup_entities(db, dry_run=args.dry_run)
        db.close()
        print(f"Dedup: {result.get('duplicates_found', 0)} duplicates found, "
              f"{result.get('merged', 0)} merged")
        return

    result = run_build(
        dry_run=args.dry_run,
        rebuild=args.rebuild,
        db_path=db_path,
        batch_size=args.batch_size,
    )
    print(format_report(result))

    _log_activity("knowledge_graph_builder",
                  f"{result['memories_processed']} memories, "
                  f"{result['entities_found']} entities, "
                  f"{result['links_created']} links, "
                  f"{result['facts_extracted']} facts")


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name='knowledge_graph_builder',
        action=_workflow_entry,
        task_type='judgment',
        actor='cli',
    )
