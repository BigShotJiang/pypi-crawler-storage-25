#!/usr/bin/env python3
"""
viral_poster.py — Unified 6-hour posting runner for publishing_calendar.json.

Reads the 686-entry viral launch calendar, finds all entries with
scheduled <= now and status='pending', posts to each platform, then
updates the calendar JSON and appends to posting_log.json.

Usage:
    python viral_poster.py --post-due          # Post all overdue entries
    python viral_poster.py --post-due --dry-run  # Preview without posting
    python viral_poster.py --status            # Show platform status
"""

import argparse
import datetime
import json
import os
import re
import sys
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import URLError

# Harness integration (P0-1 workflow discipline)
from aibrain.core.workflow_base import workflow_execute

# LinkedIn posting — adapter wraps social_poster.post_linkedin to match poster contract
from workflows.social_poster import post_linkedin as _social_post_linkedin

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

DECKER_ENV = Path.home() / ".decker_env"
CALENDAR_PATH = Path(r"C:\Users\sinde\decker_system\12_social\publishing_calendar.json")
POSTING_LOG_PATH = Path(r"C:\Users\sinde\decker_system\12_social\posting_log.json")
GRAPHICS_DIR = Path(r"C:\Users\sinde\decker_system\04_tools\social_graphic\output\aibrain")

# ---------------------------------------------------------------------------
# Credential loader
# ---------------------------------------------------------------------------

def load_env() -> dict:
    """Parse ~/.decker_env into a dict."""
    env = {}
    if not DECKER_ENV.exists():
        return env
    for line in DECKER_ENV.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" in line:
            k, v = line.split("=", 1)
            env[k.strip()] = v.strip()
    return env

ENV = load_env()
for k, v in ENV.items():
    os.environ.setdefault(k, v)

# ---------------------------------------------------------------------------
# Content file helpers
# ---------------------------------------------------------------------------

def read_content(content_file: str) -> str:
    """Read raw content from a .md file, returning full text."""
    p = Path(content_file)
    if not p.exists():
        return ""
    return p.read_text(encoding="utf-8")


def extract_post_text(content: str, platform: str) -> str:
    """
    Extract the actual post body from a viral-launch .md file.

    The files use a format like:
      # Day N — Platform — Variant
      **Post time:** ...
      **Format:** ...
      ---
      ## Section heading (optional)
      **Title:** ...  (for Reddit)
      **Post:**
      <body text>
      ---
      # Another section
    Returns the first post body found.
    """
    if not content:
        return ""

    # For Twitter threads: extract from "**Main tweet:**" or numbered tweets
    if platform == "twitter":
        # Try "**Main tweet:**\n<text>"
        m = re.search(r'\*\*Main tweet:\*\*\s*\n(.*?)(?=\n\n---|\n\n\*\*\d/|\Z)', content, re.DOTALL)
        if m:
            return m.group(1).strip()
        # Single standalone tweet: strip frontmatter
        lines = content.splitlines()
        body_lines = []
        in_body = False
        for line in lines:
            if line.strip() == "---":
                in_body = not in_body
                continue
            if in_body and not line.startswith("**") and line.strip():
                body_lines.append(line)
            elif in_body and line.startswith("**Post:**"):
                # next content is the body
                continue
        if body_lines:
            return "\n".join(body_lines[:5]).strip()  # First 5 lines for standalone
        # Fallback: take first non-header paragraph
        for line in lines:
            stripped = line.strip()
            if stripped and not stripped.startswith("#") and not stripped.startswith("**"):
                return stripped
        return content.strip()[:280]

    # For Reddit: extract first **Post:** section
    if platform == "reddit":
        m = re.search(r'\*\*Post:\*\*\s*\n(.*?)(?=\n---|\n## |\Z)', content, re.DOTALL)
        if m:
            return m.group(1).strip()
        return content.strip()[:1000]

    # For Instagram: extract caption after **Caption:** or first paragraph
    if platform == "instagram":
        m = re.search(r'\*\*Caption:\*\*\s*\n?(.*?)(?=\n\*\*|\n---|\Z)', content, re.DOTALL)
        if m:
            return m.group(1).strip()
        # Fall back: take meaningful lines after frontmatter
        lines = content.splitlines()
        body = []
        in_body = False
        for line in lines:
            if line.strip() == "---":
                in_body = True
                continue
            if in_body and line.strip() and not line.startswith("#") and not line.startswith("**Post time") and not line.startswith("**Format"):
                body.append(line.strip())
            if len(body) >= 5:
                break
        if body:
            return "\n".join(body)
        return content.strip()[:2200]

    # LinkedIn / default: strip frontmatter
    lines = content.splitlines()
    body = []
    past_header = False
    for line in lines:
        if not past_header:
            if line.strip() == "---":
                past_header = True
            continue
        if line.startswith("#") and not body:
            continue
        body.append(line)
    return "\n".join(body).strip()[:1300] if body else content.strip()[:1300]


def extract_reddit_title(content: str) -> str:
    """Extract Reddit post title from **Title:** field."""
    m = re.search(r'\*\*Title:\*\*\s*(.+)', content)
    if m:
        return m.group(1).strip()
    # Fallback: first non-empty, non-header line
    for line in content.splitlines():
        stripped = line.strip()
        if stripped and not stripped.startswith("#") and not stripped.startswith("**"):
            return stripped[:300]
    return "AIBrain — Local AI Agent Memory"


def extract_subreddit(content: str, entry_id: str) -> str:
    """
    Extract subreddit name from content file.
    Looks for '## r/subreddit' or '**Format:** r/subreddit' patterns.
    Falls back to known mappings by entry day/index.
    """
    # Look for ## r/subreddit_name heading
    m = re.search(r'## r/(\w+)', content)
    if m:
        return m.group(1)
    # Look for **Format:** r/subreddit + r/other
    m = re.search(r'r/(\w+)', content)
    if m:
        return m.group(1)
    # Default: safe general sub for AIBrain content
    return "selfhosted"


def find_instagram_image(entry: dict) -> str | None:
    """
    Find the best matching image for an Instagram entry.
    Tries: entry['image_file'], then day-based graphic, then any .png.
    """
    # Explicit override in calendar entry
    if "image_file" in entry:
        p = Path(entry["image_file"])
        if p.exists():
            return str(p)

    day = entry.get("day", 1)
    day_map = {
        1: "day1_amnesia.png",
        2: "day2_benchmarks.png",
        3: "day3_hottake.png",
        4: "day4_builder.png",
        5: "day5_marketplace.png",
        6: "day6_security.png",
        7: "day7_stats.png",
    }

    # Try day-specific graphic
    if day in day_map:
        candidate = GRAPHICS_DIR / day_map[day]
        if candidate.exists():
            return str(candidate)
        # For days > 7, cycle through the week
        cycle_day = ((day - 1) % 7) + 1
        if cycle_day in day_map:
            candidate = GRAPHICS_DIR / day_map[cycle_day]
            if candidate.exists():
                return str(candidate)

    # Last resort: any day*.png in the graphics dir
    for p in sorted(GRAPHICS_DIR.glob("day*.png")):
        return str(p)

    return None

# ---------------------------------------------------------------------------
# Platform posters
# ---------------------------------------------------------------------------

def post_twitter(entry: dict, content: str, dry_run: bool = False) -> dict:
    """
    Post to Twitter/X via tweepy (Twitter API v2).
    Requires: TWITTER_API_KEY, TWITTER_API_SECRET, TWITTER_ACCESS_TOKEN,
              TWITTER_ACCESS_TOKEN_SECRET in .decker_env.
    """
    api_key = ENV.get("TWITTER_API_KEY", "")
    api_secret = ENV.get("TWITTER_API_SECRET", "")
    access_token = ENV.get("TWITTER_ACCESS_TOKEN", "")
    access_token_secret = ENV.get("TWITTER_ACCESS_TOKEN_SECRET", "")

    missing = [k for k, v in {
        "TWITTER_API_KEY": api_key,
        "TWITTER_API_SECRET": api_secret,
        "TWITTER_ACCESS_TOKEN": access_token,
        "TWITTER_ACCESS_TOKEN_SECRET": access_token_secret,
    }.items() if not v]

    if missing:
        reason = f"Missing Twitter credentials: {', '.join(missing)}"
        print(f"  [SKIP] Twitter: {reason}")
        return {
            "status": "skipped",
            "reason": reason,
            "platform": "twitter",
        }

    post_text = extract_post_text(content, "twitter")
    if not post_text:
        return {"status": "error", "reason": "Empty post text", "platform": "twitter"}

    # Truncate to 280 chars
    if len(post_text) > 280:
        post_text = post_text[:277] + "..."

    if dry_run:
        print(f"  [DRY RUN] Twitter: would post ({len(post_text)} chars):")
        print(f"    {post_text[:100]}...")
        return {"status": "dry_run", "platform": "twitter", "text_preview": post_text[:100]}

    try:
        import tweepy
        client = tweepy.Client(
            consumer_key=api_key,
            consumer_secret=api_secret,
            access_token=access_token,
            access_token_secret=access_token_secret,
        )
        response = client.create_tweet(text=post_text)
        tweet_id = response.data["id"]
        print(f"  [OK] Twitter posted — tweet_id: {tweet_id}")
        return {"status": "posted", "platform": "twitter", "post_id": str(tweet_id)}
    except Exception as e:
        print(f"  [ERROR] Twitter: {e}")
        return {"status": "error", "reason": str(e), "platform": "twitter"}


def post_reddit(entry: dict, content: str, dry_run: bool = False) -> dict:
    """
    Post to Reddit via praw.
    Requires: REDDIT_CLIENT_ID, REDDIT_CLIENT_SECRET, REDDIT_USERNAME,
              REDDIT_PASSWORD in .decker_env.
    """
    client_id = ENV.get("REDDIT_CLIENT_ID", "")
    client_secret = ENV.get("REDDIT_CLIENT_SECRET", "")
    username = ENV.get("REDDIT_USERNAME", "")
    password = ENV.get("REDDIT_PASSWORD", "")

    missing = [k for k, v in {
        "REDDIT_CLIENT_ID": client_id,
        "REDDIT_CLIENT_SECRET": client_secret,
        "REDDIT_USERNAME": username,
        "REDDIT_PASSWORD": password,
    }.items() if not v]

    if missing:
        reason = f"Missing Reddit credentials: {', '.join(missing)}"
        print(f"  [SKIP] Reddit: {reason}")
        return {
            "status": "skipped",
            "reason": reason,
            "platform": "reddit",
        }

    subreddit_name = extract_subreddit(content, entry.get("id", ""))
    title = extract_reddit_title(content)
    body = extract_post_text(content, "reddit")

    if not body:
        return {"status": "error", "reason": "Empty post body", "platform": "reddit"}

    if dry_run:
        print(f"  [DRY RUN] Reddit r/{subreddit_name}: would post '{title[:60]}...'")
        return {
            "status": "dry_run",
            "platform": "reddit",
            "subreddit": subreddit_name,
            "title_preview": title[:60],
        }

    try:
        import praw
        reddit = praw.Reddit(
            client_id=client_id,
            client_secret=client_secret,
            username=username,
            password=password,
            user_agent=f"AIBrain viral poster by u/{username}",
        )
        subreddit = reddit.subreddit(subreddit_name)
        submission = subreddit.submit(title=title, selftext=body)
        post_url = f"https://www.reddit.com{submission.permalink}"
        print(f"  [OK] Reddit posted to r/{subreddit_name} — {post_url}")
        return {
            "status": "posted",
            "platform": "reddit",
            "subreddit": subreddit_name,
            "post_url": post_url,
            "post_id": submission.id,
        }
    except Exception as e:
        print(f"  [ERROR] Reddit: {e}")
        return {"status": "error", "reason": str(e), "platform": "reddit"}


def post_instagram(entry: dict, content: str, dry_run: bool = False) -> dict:
    """
    Post photo + caption to Instagram via instagrapi.
    Requires: INSTAGRAM_USERNAME, INSTAGRAM_PASSWORD in .decker_env.
    Image: matched by day number from the social_graphic/output/aibrain/ directory.
    """
    username = ENV.get("INSTAGRAM_USERNAME", "")
    password = ENV.get("INSTAGRAM_PASSWORD", "")

    missing = [k for k, v in {
        "INSTAGRAM_USERNAME": username,
        "INSTAGRAM_PASSWORD": password,
    }.items() if not v]

    if missing:
        return {
            "status": "skipped",
            "reason": f"Missing Instagram credentials: {', '.join(missing)}",
            "platform": "instagram",
        }

    image_path = find_instagram_image(entry)
    if not image_path:
        return {
            "status": "error",
            "reason": "No image found for Instagram post (checked GRAPHICS_DIR for day*.png)",
            "platform": "instagram",
        }

    caption = extract_post_text(content, "instagram")
    if not caption:
        caption = "AIBrain — persistent memory for any AI agent. Free on PyPI. myaibrain.org"

    if dry_run:
        print(f"  [DRY RUN] Instagram: would post image={Path(image_path).name}")
        print(f"    Caption: {caption[:80]}...")
        return {
            "status": "dry_run",
            "platform": "instagram",
            "image": image_path,
            "caption_preview": caption[:80],
        }

    try:
        from instagrapi import Client
        cl = Client()
        cl.login(username, password)
        media = cl.photo_upload(path=image_path, caption=caption)
        post_id = f"{media.id}_{media.user.pk}"
        print(f"  [OK] Instagram posted — post_id: {post_id}")
        return {
            "status": "posted",
            "platform": "instagram",
            "post_id": post_id,
        }
    except Exception as e:
        print(f"  [ERROR] Instagram: {e}")
        return {"status": "error", "reason": str(e), "platform": "instagram"}


def post_linkedin(entry: dict, content: str, dry_run: bool = False) -> dict:
    """
    Post to LinkedIn via social_poster.post_linkedin().
    Adapter: converts viral_poster poster contract → social_poster API.
    Requires: LINKEDIN_ACCESS_TOKEN in .decker_env.
    """
    post_text = extract_post_text(content, "linkedin")
    if not post_text:
        return {"status": "error", "reason": "Empty post text", "platform": "linkedin"}

    if dry_run:
        print(f"  [DRY RUN] LinkedIn: would post ({len(post_text)} chars):")
        print(f"    {post_text[:100]}...")
        return {"status": "dry_run", "platform": "linkedin", "text_preview": post_text[:100]}

    token = ENV.get("LINKEDIN_ACCESS_TOKEN", "")
    if not token:
        reason = "Missing LinkedIn credential: LINKEDIN_ACCESS_TOKEN"
        print(f"  [SKIP] LinkedIn: {reason}")
        return {"status": "skipped", "reason": reason, "platform": "linkedin"}

    success = _social_post_linkedin(post_text, ENV)
    if success:
        return {"status": "posted", "platform": "linkedin"}
    else:
        return {"status": "error", "reason": "post_linkedin() returned False — check logs above", "platform": "linkedin"}


# ---------------------------------------------------------------------------
# Calendar manager
# ---------------------------------------------------------------------------

def load_calendar() -> list:
    return json.loads(CALENDAR_PATH.read_text(encoding="utf-8"))


def save_calendar(cal: list) -> None:
    CALENDAR_PATH.write_text(json.dumps(cal, indent=2), encoding="utf-8")


def load_posting_log() -> list:
    if not POSTING_LOG_PATH.exists():
        return []
    try:
        return json.loads(POSTING_LOG_PATH.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return []


def save_posting_log(log: list) -> None:
    POSTING_LOG_PATH.write_text(json.dumps(log, indent=2, ensure_ascii=False), encoding="utf-8")


def append_posting_log(entry: dict, result: dict) -> None:
    """Append a result record to posting_log.json."""
    log = load_posting_log()
    now_iso = datetime.datetime.utcnow().isoformat() + "Z"
    record = {
        "calendar_id": entry.get("id"),
        "platform": entry.get("platform"),
        "scheduled": entry.get("scheduled"),
        "content_file": entry.get("content_file"),
        "day": entry.get("day"),
        "attempted_at": now_iso,
        **result,
    }
    log.append(record)
    POSTING_LOG_PATH.write_text(json.dumps(log, indent=2), encoding="utf-8")


# ---------------------------------------------------------------------------
# Main runner
# ---------------------------------------------------------------------------

POSTER_MAP = {
    "twitter": post_twitter,
    "reddit": post_reddit,
    "instagram": post_instagram,
    "linkedin": post_linkedin,
}


def post_due(dry_run: bool = False) -> None:
    """Find all pending entries with scheduled <= now and post them."""
    cal = load_calendar()
    now = datetime.datetime.now(datetime.timezone.utc)
    now_local = datetime.datetime.now()

    due = []
    for entry in cal:
        if entry.get("status") != "pending":
            continue
        if entry.get("manual") is True:
            # Skip manual_required entries silently
            continue
        platform = entry.get("platform", "")
        if platform == "tiktok":
            # Mark tiktok as manual_required and skip
            entry["status"] = "manual_required"
            entry["manual_required_reason"] = "TikTok requires manual upload"
            continue
        if platform not in POSTER_MAP:
            continue
        sched_str = entry.get("scheduled", "")
        if not sched_str:
            continue
        # Parse ISO8601 with optional timezone offset
        try:
            # Handle offset-aware timestamps
            sched_str_norm = sched_str
            # Python 3.11+ handles +HH:MM fine; for older, strip and compare
            sched_dt = datetime.datetime.fromisoformat(sched_str_norm)
            if sched_dt.tzinfo is None:
                sched_dt = sched_dt.replace(tzinfo=datetime.timezone.utc)
            if sched_dt <= now:
                due.append(entry)
        except ValueError:
            print(f"  [WARN] Cannot parse scheduled time '{sched_str}' for {entry.get('id')}")
            continue

    if not due:
        print(f"No posts due as of {now_local.strftime('%Y-%m-%d %H:%M')} UTC")
        return

    print(f"Found {len(due)} posts due (as of {now.strftime('%Y-%m-%d %H:%M')} UTC):")
    for e in due:
        print(f"  - [{e['platform']:<12}] {e.get('id')} (scheduled {e.get('scheduled')})")
    print()

    # Group by platform for clean output
    by_platform: dict[str, list] = {}
    for e in due:
        by_platform.setdefault(e["platform"], []).append(e)

    posted_count = 0
    error_count = 0

    for platform, entries in by_platform.items():
        poster = POSTER_MAP[platform]
        print(f"\n--- {platform.upper()} ({len(entries)} posts) ---")
        for entry in entries:
            content_file = entry.get("content_file", "")
            content = read_content(content_file)
            if not content:
                print(f"  [WARN] Content file missing: {content_file}")
                result = {"status": "error", "reason": f"Content file not found: {content_file}"}
            else:
                result = poster(entry, content, dry_run=dry_run)

            append_posting_log(entry, result)

            if not dry_run:
                status = result.get("status")
                if status == "posted":
                    entry["status"] = "posted"
                    entry["posted_at"] = datetime.datetime.utcnow().isoformat() + "Z"
                    if "post_id" in result:
                        entry["post_id"] = result["post_id"]
                    if "post_url" in result:
                        entry["post_url"] = result["post_url"]
                    posted_count += 1
                elif status == "skipped":
                    # Credentials missing — leave as pending so manual posting is possible
                    print(f"    -> Left as 'pending' (credentials missing)")
                elif status == "error":
                    entry["status"] = "error"
                    entry["error"] = result.get("reason", "unknown")
                    error_count += 1
            else:
                posted_count += 1

    if not dry_run:
        # Save tiktok manual_required changes + all post results
        save_calendar(cal)

    label = "[DRY RUN] " if dry_run else ""
    print(f"\n{label}Done: {posted_count} posted, {error_count} errors")
    if not dry_run:
        print(f"Calendar updated: {CALENDAR_PATH}")
        print(f"Log appended: {POSTING_LOG_PATH}")


def show_status() -> None:
    """Show credential status and pending post counts per platform."""
    print("=== viral_poster status ===\n")

    # Credentials
    cred_checks = {
        "Twitter": ["TWITTER_API_KEY", "TWITTER_API_SECRET", "TWITTER_ACCESS_TOKEN", "TWITTER_ACCESS_TOKEN_SECRET"],
        "Reddit": ["REDDIT_CLIENT_ID", "REDDIT_CLIENT_SECRET", "REDDIT_USERNAME", "REDDIT_PASSWORD"],
        "Instagram": ["INSTAGRAM_USERNAME", "INSTAGRAM_PASSWORD"],
        "LinkedIn": ["LINKEDIN_ACCESS_TOKEN"],
    }
    print("Credentials:")
    for platform, keys in cred_checks.items():
        missing = [k for k in keys if not ENV.get(k)]
        if missing:
            print(f"  {platform:<12} MISSING: {', '.join(missing)}")
        else:
            print(f"  {platform:<12} OK (all {len(keys)} keys present)")

    print()

    # Calendar summary
    cal = load_calendar()
    now = datetime.datetime.now(datetime.timezone.utc)
    by_platform: dict[str, dict] = {}
    for e in cal:
        p = e.get("platform", "unknown")
        if p not in by_platform:
            by_platform[p] = {"pending": 0, "posted": 0, "due": 0, "error": 0, "manual": 0}
        status = e.get("status", "")
        if status == "pending":
            by_platform[p]["pending"] += 1
            # Check if due
            sched_str = e.get("scheduled", "")
            if sched_str:
                try:
                    sched_dt = datetime.datetime.fromisoformat(sched_str)
                    if sched_dt.tzinfo is None:
                        sched_dt = sched_dt.replace(tzinfo=datetime.timezone.utc)
                    if sched_dt <= now:
                        by_platform[p]["due"] += 1
                except ValueError:
                    pass
        elif status == "posted":
            by_platform[p]["posted"] += 1
        elif status == "manual_required":
            by_platform[p]["manual"] += 1
        elif status == "error":
            by_platform[p]["error"] += 1

    print("Calendar summary:")
    print(f"  {'Platform':<14} {'Pending':>8} {'Due now':>8} {'Posted':>8} {'Errors':>8} {'Manual':>8}")
    print("  " + "-" * 56)
    for p, counts in sorted(by_platform.items()):
        print(f"  {p:<14} {counts['pending']:>8} {counts['due']:>8} {counts['posted']:>8} {counts['error']:>8} {counts['manual']:>8}")

    print(f"\n  Total entries: {len(cal)}")
    print(f"  Checked at: {now.strftime('%Y-%m-%d %H:%M')} UTC")


def main():
    parser = argparse.ArgumentParser(
        description="Viral launch calendar poster — posts due entries across Twitter, Reddit, Instagram."
    )
    parser.add_argument("--post-due", action="store_true",
                        help="Post all entries with scheduled <= now and status=pending")
    parser.add_argument("--dry-run", action="store_true",
                        help="Preview without actually posting or updating the calendar")
    parser.add_argument("--status", action="store_true",
                        help="Show credential status and pending post counts")
    args = parser.parse_args()

    if args.status:
        show_status()
    elif args.post_due:
        post_due(dry_run=args.dry_run)
    else:
        parser.print_help()


if __name__ == "__main__":
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name="viral_poster",
        action=_workflow_entry,
        task_type="judgment",
        actor="cli",
    )
