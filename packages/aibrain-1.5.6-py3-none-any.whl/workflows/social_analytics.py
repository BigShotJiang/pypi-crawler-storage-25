"""
Workflow: social_analytics

Syncs posting_log.json to social_analytics table, optionally scrapes
engagement data via Playwright, and generates a weekly summary.

Run via harness:
    python -m aibrain.core.workflow_runner social_analytics

Or directly for testing:
    python workflows/social_analytics.py [--scrape] [--summary] [--telegram]
"""
from __future__ import annotations

import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

# Ensure project root is importable
_root = Path(__file__).resolve().parent.parent
if str(_root) not in sys.path:
    sys.path.insert(0, str(_root))

from aibrain.tools.marketing.analytics import (
    get_connection,
    ensure_table,
    load_posting_log,
    sync_posts,
    update_engagement,
    generate_weekly_summary,
    get_all_analytics,
)


def run_sync(db_path: str | None = None, log_path: str | None = None) -> dict:
    """
    Phase 1: Sync posting_log.json into social_analytics table.
    Returns {synced: int, total: int}.
    """
    conn = get_connection(db_path)
    ensure_table(conn)
    posts = load_posting_log(log_path)
    synced = sync_posts(conn, posts)
    total = len(get_all_analytics(conn))
    conn.close()
    return {"synced": synced, "total": total}


def run_scrape(db_path: str | None = None) -> dict:
    """
    Phase 2: Use Playwright to scrape engagement data from each platform.

    This is a best-effort scraper. Platforms aggressively block automation,
    so failures are expected. Each platform handler catches its own errors
    and logs them without halting the workflow.

    Returns {updated: int, errors: list[str]}.
    """
    conn = get_connection(db_path)
    ensure_table(conn)
    rows = get_all_analytics(conn)

    if not rows:
        conn.close()
        return {"updated": 0, "errors": ["No posts to scrape"]}

    updated = 0
    errors: list[str] = []

    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        conn.close()
        return {"updated": 0, "errors": ["Playwright not installed. Run: pip install playwright && playwright install"]}

    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            page = browser.new_page()

            for row in rows:
                post_id = row.get("post_id", "")
                platform = row.get("platform", "")

                try:
                    engagement = _scrape_post(page, platform, post_id, row)
                    if engagement:
                        update_engagement(conn, post_id, **engagement)
                        updated += 1
                except Exception as e:
                    errors.append(f"{post_id} ({platform}): {str(e)[:100]}")

            browser.close()
    except Exception as e:
        errors.append(f"Browser launch failed: {str(e)[:200]}")

    conn.close()
    return {"updated": updated, "errors": errors}


def _scrape_post(page, platform: str, post_id: str, row: dict) -> dict | None:
    """
    Attempt to scrape engagement for a single post.
    Returns dict with keys matching update_engagement params, or None on failure.

    Platform-specific scraping is inherently fragile -- selectors change frequently.
    Each platform is handled separately so failures are isolated.
    """
    # Placeholder: real scraping would navigate to the post URL and extract metrics.
    # For now, we read whatever is already in the posting_log engagement field.
    # When Decker approves platform-specific scrapers, add them here.
    return None


def run_summary(db_path: str | None = None, weeks: int = 1) -> str:
    """Phase 3: Generate weekly summary text."""
    conn = get_connection(db_path)
    ensure_table(conn)
    summary = generate_weekly_summary(conn, weeks_back=weeks)
    conn.close()
    return summary


def send_telegram_summary(summary: str) -> bool:
    """Send summary to Decker via Telegram."""
    try:
        import requests
    except ImportError:
        print("requests not installed, cannot send Telegram message")
        return False

    token = os.environ.get("TELEGRAM_TOKEN", "")
    chat_id = "8267616606"  # Decker DM

    if not token:
        # Try loading from .decker_env
        env_file = Path.home() / ".decker_env"
        if env_file.exists():
            for line in env_file.read_text().splitlines():
                if line.startswith("TELEGRAM_TOKEN="):
                    token = line.split("=", 1)[1].strip().strip('"').strip("'")
                    break

    if not token:
        print("No TELEGRAM_TOKEN found")
        return False

    url = f"https://api.telegram.org/bot{token}/sendMessage"
    payload = {
        "chat_id": chat_id,
        "text": summary[:4096],  # Telegram message limit
        "parse_mode": "HTML",
    }
    try:
        resp = requests.post(url, json=payload, timeout=10)
        return resp.status_code == 200
    except Exception as e:
        print(f"Telegram send failed: {e}")
        return False


def run(actor: str = "neuro", **kwargs) -> dict:
    """
    Main workflow entry point (called by workflow_runner harness).

    Phases:
    1. Sync posting_log.json -> DB
    2. Optionally scrape engagement (if --scrape flag)
    3. Generate weekly summary
    """
    scrape = kwargs.get("scrape", False)
    telegram = kwargs.get("telegram", False)
    weeks = kwargs.get("weeks", 1)

    results: dict = {"timestamp": datetime.now(timezone.utc).isoformat()}

    # Phase 1: Sync
    sync_result = run_sync()
    results["sync"] = sync_result
    print(f"Synced {sync_result['synced']} new posts (total: {sync_result['total']})")

    # Phase 2: Scrape (optional)
    if scrape:
        scrape_result = run_scrape()
        results["scrape"] = scrape_result
        print(f"Updated {scrape_result['updated']} posts, {len(scrape_result['errors'])} errors")

    # Phase 3: Summary
    summary = run_summary(weeks=weeks)
    results["summary"] = summary
    print(summary)

    # Phase 4: Telegram (optional)
    if telegram:
        sent = send_telegram_summary(summary)
        results["telegram_sent"] = sent
        print(f"Telegram: {'sent' if sent else 'failed'}")

    return results


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        import argparse
        parser = argparse.ArgumentParser(description="Social analytics workflow")
        parser.add_argument("--scrape", action="store_true", help="Scrape engagement via Playwright")
        parser.add_argument("--summary", action="store_true", help="Print weekly summary only")
        parser.add_argument("--telegram", action="store_true", help="Send summary via Telegram")
        parser.add_argument("--weeks", type=int, default=1, help="Weeks to include in summary")
        parsed = parser.parse_args()

        if parsed.summary:
            print(run_summary(weeks=parsed.weeks))
        else:
            run(scrape=parsed.scrape, telegram=parsed.telegram, weeks=parsed.weeks)
    workflow_execute(
        workflow_name='social_analytics',
        action=_workflow_entry,
        task_type='simple',
        actor='cli',
    )
