"""job_apply.py -- ATS form fill layer for the job application pipeline.

Detects which ATS a job posting uses and attempts to fill the application form
with profile data and a generated cover letter. NEVER auto-submits.

Stops at the final confirmation step, takes a screenshot, and logs the
application as 'review_required' in job_tracker.db for Decker to review.

Supported ATS types:
  - workday       URL contains workday.com OR has Workday DOM marker
  - linkedin      linkedin.com/jobs AND Easy Apply button present
  - seek          seek.com.au AND Seek apply button present
  - smartrecruiters smartrecruiters.com OR SmartRecruiters DOM marker
  - pageup        pageuppeople.com OR PageUp DOM marker
  - email         Job description mentions email apply instructions
  - generic       Fallback for plain HTML forms with file upload
"""

import datetime
import json
import re
import sqlite3
import sys
from pathlib import Path
from typing import Optional

# Harness import required for all modules in the workflows directory (P0-1 backfill)
from aibrain.core.workflow_base import workflow_execute  # noqa: F401

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
_HERE = Path(__file__).parent
_PROFILE_PATH = _HERE / "decker_profile.json"
_DB_PATH = _HERE / "job_tracker.db"
_SCREENSHOTS_DIR = _HERE / "apply_screenshots"
_SCREENSHOTS_DIR.mkdir(exist_ok=True)

# ---------------------------------------------------------------------------
# Playwright availability check
# ---------------------------------------------------------------------------
_PLAYWRIGHT_AVAILABLE = False
try:
    import playwright  # noqa: F401
    _PLAYWRIGHT_AVAILABLE = True
except ImportError:
    print(
        "WARNING: playwright not available -- ATS form fill will be skipped.",
        file=sys.stderr,
    )


# ---------------------------------------------------------------------------
# DB helpers
# ---------------------------------------------------------------------------

def _get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(str(_DB_PATH))
    conn.execute("PRAGMA journal_mode=wal")
    conn.row_factory = sqlite3.Row
    _ensure_pipeline_table(conn)
    return conn


def _ensure_pipeline_table(conn: sqlite3.Connection) -> None:
    """Create pipeline_applications table if it does not exist.

    A separate table from the existing 'applications' table to avoid
    breaking the existing schema.
    """
    conn.execute("""
        CREATE TABLE IF NOT EXISTS pipeline_applications (
            id TEXT PRIMARY KEY,
            title TEXT,
            company TEXT,
            url TEXT,
            source TEXT,
            location TEXT,
            applied_date TEXT,
            status TEXT DEFAULT 'pending',
            cover_letter_path TEXT,
            screenshot_path TEXT,
            notes TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()


def _upsert_application(conn: sqlite3.Connection, record: dict) -> None:
    """Insert or replace an application record."""
    conn.execute(
        """
        INSERT OR REPLACE INTO pipeline_applications
            (id, title, company, url, source, location, applied_date,
             status, cover_letter_path, screenshot_path, notes, created_at)
        VALUES
            (:id, :title, :company, :url, :source, :location, :applied_date,
             :status, :cover_letter_path, :screenshot_path, :notes, :created_at)
        """,
        record,
    )
    conn.commit()


# ---------------------------------------------------------------------------
# Profile loader
# ---------------------------------------------------------------------------

def _load_profile() -> dict:
    if not _PROFILE_PATH.exists():
        raise FileNotFoundError(f"decker_profile.json not found at {_PROFILE_PATH}")
    return json.loads(_PROFILE_PATH.read_text(encoding="utf-8"))


# ---------------------------------------------------------------------------
# ATS detection
# ---------------------------------------------------------------------------

def detect_ats(job_url: str, page_html: str = "", page=None) -> str:
    """Detect which ATS is being used for a given job URL.

    Parameters
    ----------
    job_url : str
        The URL of the job posting.
    page_html : str, optional
        Pre-fetched HTML content of the page (used when page is None).
    page : playwright.Page, optional
        Live Playwright page for DOM queries (more reliable than raw HTML).

    Returns
    -------
    str
        One of: 'workday', 'linkedin', 'seek', 'smartrecruiters',
                'pageup', 'email', 'generic'
    """
    url_lower = job_url.lower()
    html_lower = page_html.lower()

    # Workday
    if "workday.com" in url_lower:
        return "workday"
    if page is not None:
        try:
            if page.query_selector('[data-automation-id="jobPostingHeader"]'):
                return "workday"
        except Exception:
            pass
    if 'data-automation-id="jobpostingheader"' in html_lower:
        return "workday"

    # LinkedIn Easy Apply
    if "linkedin.com/jobs" in url_lower:
        if page is not None:
            try:
                if page.query_selector('[aria-label*="Easy Apply"]'):
                    return "linkedin"
            except Exception:
                pass
        if "easy apply" in html_lower or "aria-label.*easy apply" in html_lower:
            return "linkedin"

    # Seek Apply
    if "seek.com.au" in url_lower:
        if page is not None:
            try:
                if page.query_selector('[data-testid="apply-button"]'):
                    return "seek"
            except Exception:
                pass
        if 'data-testid="apply-button"' in html_lower:
            return "seek"

    # SmartRecruiters
    if "smartrecruiters.com" in url_lower:
        return "smartrecruiters"
    if page is not None:
        try:
            if page.query_selector('[class*="sr-apply"]'):
                return "smartrecruiters"
        except Exception:
            pass

    # PageUp
    if "pageuppeople.com" in url_lower:
        return "pageup"
    if page is not None:
        try:
            if page.query_selector('[class*="pageup"]'):
                return "pageup"
        except Exception:
            pass

    # Email apply (check description/HTML)
    email_patterns = [
        r"email your resume to",
        r"applications to\s+\S+@\S+",
        r"send your cv to",
        r"apply by email",
        r"send resume to",
        r"email applications",
    ]
    for pat in email_patterns:
        if re.search(pat, html_lower):
            return "email"

    return "generic"


# ---------------------------------------------------------------------------
# Field fill helpers
# ---------------------------------------------------------------------------

def _safe_fill(page, selector: str, value: str) -> bool:
    """Try to fill a field. Returns True on success, False on failure."""
    try:
        el = page.query_selector(selector)
        if el and el.is_visible():
            el.click()
            el.fill(value)
            return True
    except Exception:
        pass
    return False


def _safe_select(page, selector: str, value: str, label: str = "") -> bool:
    """Try to select from a dropdown by value or label."""
    try:
        el = page.query_selector(selector)
        if el and el.is_visible():
            try:
                el.select_option(value=value)
                return True
            except Exception:
                pass
            try:
                el.select_option(label=label or value)
                return True
            except Exception:
                pass
    except Exception:
        pass
    return False


def _try_fill_common_fields(page, profile: dict) -> None:
    """Fill common personal information fields across ATS platforms."""
    first_name = profile["name"].split()[0]
    last_name = " ".join(profile["name"].split()[1:]) or profile["name"]

    # First name variants
    for sel in [
        'input[name*="first" i]', 'input[id*="first" i]',
        'input[placeholder*="first" i]', 'input[aria-label*="first name" i]',
    ]:
        if _safe_fill(page, sel, first_name):
            break

    # Last name variants
    for sel in [
        'input[name*="last" i]', 'input[id*="last" i]',
        'input[placeholder*="last" i]', 'input[aria-label*="last name" i]',
    ]:
        if _safe_fill(page, sel, last_name):
            break

    # Full name variants
    for sel in [
        'input[name*="fullname" i]', 'input[id*="fullname" i]',
        'input[name*="full_name" i]', 'input[aria-label*="full name" i]',
        'input[name="name"]', 'input[id="name"]',
    ]:
        if _safe_fill(page, sel, profile["name"]):
            break

    # Email
    for sel in [
        'input[type="email"]', 'input[name*="email" i]',
        'input[id*="email" i]', 'input[aria-label*="email" i]',
    ]:
        if _safe_fill(page, sel, profile["email"]):
            break

    # Phone
    for sel in [
        'input[type="tel"]', 'input[name*="phone" i]',
        'input[id*="phone" i]', 'input[name*="mobile" i]',
        'input[aria-label*="phone" i]',
    ]:
        if _safe_fill(page, sel, profile["phone"]):
            break

    # Location / city / address
    for sel in [
        'input[name*="location" i]', 'input[name*="city" i]',
        'input[name*="address" i]', 'input[id*="location" i]',
        'input[aria-label*="location" i]',
    ]:
        if _safe_fill(page, sel, profile["address"]):
            break

    # LinkedIn URL
    for sel in [
        'input[name*="linkedin" i]', 'input[id*="linkedin" i]',
        'input[placeholder*="linkedin" i]',
    ]:
        if _safe_fill(page, sel, f"https://{profile['linkedin']}"):
            break

    # "How did you hear about us" dropdown -- always "Other"
    for sel in [
        'select[name*="source" i]', 'select[name*="referral" i]',
        'select[id*="source" i]', 'select[name*="hear" i]',
        'select[id*="how" i]',
    ]:
        _safe_select(page, sel, "Other", "Other")

    # "Right to work" / citizenship dropdowns
    for sel in [
        'select[name*="work_authorization" i]',
        'select[name*="right_to_work" i]',
        'select[name*="eligible" i]',
        'select[name*="citizen" i]',
        'select[id*="work_auth" i]',
    ]:
        _safe_select(page, sel, "Yes", "Yes")

    # Years of experience dropdowns -- try 5+
    for sel in [
        'select[name*="years_experience" i]',
        'select[name*="experience" i]',
        'select[id*="experience" i]',
    ]:
        for opt in ["5", "5+", "5 or more", "6-10", "More than 5"]:
            if _safe_select(page, sel, opt, opt):
                break


def _upload_resume(page, resume_path: str) -> bool:
    """Attempt to upload the resume docx via file input."""
    try:
        file_inputs = page.query_selector_all('input[type="file"]')
        for fi in file_inputs:
            try:
                fi.set_input_files(resume_path)
                return True
            except Exception:
                continue
    except Exception:
        pass
    return False


def _fill_cover_letter(page, cover_letter_text: str) -> bool:
    """Paste cover letter into a cover letter textarea field."""
    for sel in [
        'textarea[name*="cover" i]', 'textarea[id*="cover" i]',
        'textarea[aria-label*="cover letter" i]',
        'textarea[name*="letter" i]', 'textarea[id*="letter" i]',
        'div[contenteditable="true"][aria-label*="cover" i]',
        'div[data-placeholder*="cover" i]',
    ]:
        try:
            el = page.query_selector(sel)
            if el and el.is_visible():
                el.click()
                el.fill(cover_letter_text)
                return True
        except Exception:
            pass
    return False


def _scroll_and_find_required(page) -> None:
    """Scroll through the page to surface hidden required fields."""
    try:
        page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
        page.wait_for_timeout(500)
        page.evaluate("window.scrollTo(0, 0)")
        page.wait_for_timeout(300)
    except Exception:
        pass


def _take_screenshot(page, job_id: str) -> str:
    """Take a screenshot and save to apply_screenshots directory."""
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{job_id}_{ts}.png"
    path = str(_SCREENSHOTS_DIR / filename)
    try:
        page.screenshot(path=path, full_page=True)
    except Exception as exc:
        print(f"  Screenshot failed: {exc}", file=sys.stderr)
        path = ""
    return path


# ---------------------------------------------------------------------------
# ATS-specific handlers
# ---------------------------------------------------------------------------

def _handle_workday(page, profile: dict, cover_letter_text: str, job_id: str) -> dict:
    """Handle Workday ATS form fill."""
    result = {"status": "apply_failed", "screenshot_path": ""}
    try:
        page.wait_for_selector(
            '[data-automation-id="jobPostingHeader"], .WJKR, [data-automation-id]',
            timeout=15000,
        )
        _try_fill_common_fields(page, profile)
        _upload_resume(page, profile["resume_docx"])
        _fill_cover_letter(page, cover_letter_text)
        _scroll_and_find_required(page)
        screenshot = _take_screenshot(page, job_id)
        result = {"status": "review_required", "screenshot_path": screenshot}
    except Exception as exc:
        print(f"  Workday handler error: {exc}", file=sys.stderr)
    return result


def _handle_linkedin(page, profile: dict, cover_letter_text: str, job_id: str) -> dict:
    """Handle LinkedIn Easy Apply flow."""
    result = {"status": "apply_failed", "screenshot_path": ""}
    try:
        # Click Easy Apply button
        btn = page.query_selector('[aria-label*="Easy Apply"]')
        if btn:
            btn.click()
            page.wait_for_timeout(1500)

        _try_fill_common_fields(page, profile)
        _upload_resume(page, profile["resume_docx"])
        _fill_cover_letter(page, cover_letter_text)

        # Navigate multi-step: click Next/Continue but stop before Submit
        for _ in range(8):
            _scroll_and_find_required(page)
            next_btn = page.query_selector(
                'button[aria-label*="Continue"], button[aria-label*="Next"], '
                'button[aria-label*="Review"]'
            )
            submit_btn = page.query_selector(
                'button[aria-label*="Submit application"]'
            )
            if submit_btn:
                # Stop here -- do NOT click submit
                break
            if next_btn:
                next_btn.click()
                page.wait_for_timeout(1000)
                _try_fill_common_fields(page, profile)
            else:
                break

        screenshot = _take_screenshot(page, job_id)
        result = {"status": "review_required", "screenshot_path": screenshot}
    except Exception as exc:
        print(f"  LinkedIn handler error: {exc}", file=sys.stderr)
    return result


def _handle_seek(page, profile: dict, cover_letter_text: str, job_id: str) -> dict:
    """Handle Seek apply flow."""
    result = {"status": "apply_failed", "screenshot_path": ""}
    try:
        btn = page.query_selector('[data-testid="apply-button"]')
        if btn:
            btn.click()
            page.wait_for_timeout(2000)

        _try_fill_common_fields(page, profile)
        _upload_resume(page, profile["resume_docx"])
        _fill_cover_letter(page, cover_letter_text)
        _scroll_and_find_required(page)

        screenshot = _take_screenshot(page, job_id)
        result = {"status": "review_required", "screenshot_path": screenshot}
    except Exception as exc:
        print(f"  Seek handler error: {exc}", file=sys.stderr)
    return result


def _handle_smartrecruiters(page, profile: dict, cover_letter_text: str, job_id: str) -> dict:
    """Handle SmartRecruiters apply flow."""
    result = {"status": "apply_failed", "screenshot_path": ""}
    try:
        apply_btn = page.query_selector(
            '[class*="sr-apply"], button[data-hook="apply-button"], '
            'a[data-hook="apply-button"]'
        )
        if apply_btn:
            apply_btn.click()
            page.wait_for_timeout(1500)

        _try_fill_common_fields(page, profile)
        _upload_resume(page, profile["resume_docx"])
        _fill_cover_letter(page, cover_letter_text)
        _scroll_and_find_required(page)

        screenshot = _take_screenshot(page, job_id)
        result = {"status": "review_required", "screenshot_path": screenshot}
    except Exception as exc:
        print(f"  SmartRecruiters handler error: {exc}", file=sys.stderr)
    return result


def _handle_pageup(page, profile: dict, cover_letter_text: str, job_id: str) -> dict:
    """Handle PageUp apply flow."""
    result = {"status": "apply_failed", "screenshot_path": ""}
    try:
        apply_btn = page.query_selector(
            '[class*="pageup"] button, #apply-button, .apply-btn'
        )
        if apply_btn:
            apply_btn.click()
            page.wait_for_timeout(1500)

        _try_fill_common_fields(page, profile)
        _upload_resume(page, profile["resume_docx"])
        _fill_cover_letter(page, cover_letter_text)
        _scroll_and_find_required(page)

        screenshot = _take_screenshot(page, job_id)
        result = {"status": "review_required", "screenshot_path": screenshot}
    except Exception as exc:
        print(f"  PageUp handler error: {exc}", file=sys.stderr)
    return result


def _handle_email(page, profile: dict, cover_letter_text: str, job_id: str) -> dict:
    """Handle email-apply jobs -- extract email address from page and log it."""
    result = {"status": "apply_failed", "screenshot_path": ""}
    try:
        html = page.content()
        emails = re.findall(r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}", html)
        screenshot = _take_screenshot(page, job_id)
        notes = f"Email apply. Addresses found: {', '.join(set(emails))}"
        result = {
            "status": "review_required",
            "screenshot_path": screenshot,
            "notes": notes,
        }
    except Exception as exc:
        print(f"  Email apply handler error: {exc}", file=sys.stderr)
    return result


def _handle_generic(page, profile: dict, cover_letter_text: str, job_id: str) -> dict:
    """Fallback: try to fill any HTML form with file upload and text fields."""
    result = {"status": "apply_failed", "screenshot_path": ""}
    try:
        _try_fill_common_fields(page, profile)
        _upload_resume(page, profile["resume_docx"])
        _fill_cover_letter(page, cover_letter_text)
        _scroll_and_find_required(page)

        screenshot = _take_screenshot(page, job_id)
        result = {"status": "review_required", "screenshot_path": screenshot}
    except Exception as exc:
        print(f"  Generic handler error: {exc}", file=sys.stderr)
    return result


# ---------------------------------------------------------------------------
# Main apply function
# ---------------------------------------------------------------------------

_ATS_HANDLERS = {
    "workday": _handle_workday,
    "linkedin": _handle_linkedin,
    "seek": _handle_seek,
    "smartrecruiters": _handle_smartrecruiters,
    "pageup": _handle_pageup,
    "email": _handle_email,
    "generic": _handle_generic,
}


def apply_to_job(
    job: dict,
    cover_letter_path: str,
    dry_run: bool = False,
) -> dict:
    """Attempt to apply to a job using ATS detection and form fill.

    Parameters
    ----------
    job : dict
        Job dict with keys: id, title, company, url, source, location, preview
    cover_letter_path : str
        Path to the saved cover letter text file.
    dry_run : bool
        If True, detect ATS but do not open browser or fill forms.

    Returns
    -------
    dict
        Result with keys: status, screenshot_path, notes, ats_type
    """
    if not _PLAYWRIGHT_AVAILABLE:
        print(
            f"  Playwright not available -- skipping apply for {job.get('title', '')}",
            file=sys.stderr,
        )
        return {"status": "apply_failed", "screenshot_path": "", "notes": "Playwright not installed", "ats_type": "unknown"}

    profile = _load_profile()
    job_id = job.get("id", "unknown")
    job_url = job.get("url", "")

    # Load cover letter text
    cover_letter_text = ""
    if cover_letter_path and Path(cover_letter_path).exists():
        cover_letter_text = Path(cover_letter_path).read_text(encoding="utf-8")

    if dry_run:
        ats_type = detect_ats(job_url)
        print(f"  DRY RUN: {job.get('title')} at {job.get('company')} -- ATS: {ats_type}")
        return {"status": "dry_run", "screenshot_path": "", "notes": f"ATS: {ats_type}", "ats_type": ats_type}

    from playwright.sync_api import sync_playwright

    result = {"status": "apply_failed", "screenshot_path": "", "notes": "", "ats_type": "unknown"}

    try:
        with sync_playwright() as pw:
            browser = pw.chromium.launch(
                headless=False,
                args=[
                    "--window-position=-2400,-2400",
                    "--disable-blink-features=AutomationControlled",
                    "--no-first-run",
                    "--no-default-browser-check",
                ],
            )
            page = browser.new_page(
                user_agent=(
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/124.0.0.0 Safari/537.36"
                ),
                locale="en-AU",
            )
            page.set_default_timeout(20000)

            try:
                page.goto(job_url, wait_until="domcontentloaded")
                page.wait_for_timeout(1000)

                # Get page HTML for ATS detection
                html = ""
                try:
                    html = page.content()
                except Exception:
                    pass

                ats_type = detect_ats(job_url, html, page)
                result["ats_type"] = ats_type
                print(
                    f"  Applying to {job.get('title')} at {job.get('company')} via {ats_type}",
                    file=sys.stderr,
                )

                handler = _ATS_HANDLERS.get(ats_type, _handle_generic)
                handler_result = handler(page, profile, cover_letter_text, job_id)
                result.update(handler_result)

            except Exception as exc:
                print(f"  Apply error for {job.get('title')}: {exc}", file=sys.stderr)
                result["notes"] = str(exc)
            finally:
                try:
                    browser.close()
                except Exception:
                    pass

    except Exception as exc:
        print(f"  Playwright launch error: {exc}", file=sys.stderr)
        result["notes"] = str(exc)

    # Log to DB
    _log_application(job, cover_letter_path, result)
    return result


def _log_application(job: dict, cover_letter_path: str, result: dict) -> None:
    """Log the application attempt to job_tracker.db."""
    try:
        conn = _get_db()
        record = {
            "id": job.get("id", ""),
            "title": job.get("title", ""),
            "company": job.get("company", ""),
            "url": job.get("url", ""),
            "source": job.get("source", ""),
            "location": job.get("location", ""),
            "applied_date": datetime.date.today().isoformat(),
            "status": result.get("status", "apply_failed"),
            "cover_letter_path": cover_letter_path or "",
            "screenshot_path": result.get("screenshot_path", ""),
            "notes": result.get("notes", f"ATS: {result.get('ats_type', 'unknown')}"),
            "created_at": datetime.datetime.now().isoformat(),
        }
        _upsert_application(conn, record)
        conn.close()
    except Exception as exc:
        print(f"  DB log error: {exc}", file=sys.stderr)


def get_review_required() -> list:
    """Return all applications with status 'review_required' from the DB."""
    try:
        conn = _get_db()
        rows = conn.execute(
            "SELECT * FROM pipeline_applications WHERE status = 'review_required' ORDER BY created_at DESC"
        ).fetchall()
        conn.close()
        return [dict(r) for r in rows]
    except Exception as exc:
        print(f"  DB read error: {exc}", file=sys.stderr)
        return []


def submit_application(job_id: str) -> bool:
    """Mark an application as 'submitted' after Decker has reviewed.

    This is the manual gate -- Decker calls --submit <job_id> after
    reviewing the screenshot. The actual form submission is NOT done
    here; this just updates the tracking status.
    """
    try:
        conn = _get_db()
        conn.execute(
            "UPDATE pipeline_applications SET status = 'submitted' WHERE id = ?",
            (job_id,),
        )
        conn.commit()
        conn.close()
        print(f"  Application {job_id} marked as submitted.")
        return True
    except Exception as exc:
        print(f"  Submit update error: {exc}", file=sys.stderr)
        return False


def is_location_allowed(location_str: str) -> bool:
    """Return True if the job location passes the Decker location filter.

    Allowed:  Adelaide SA, Remote AU, Remote UK, Remote US.
    Everything else is filtered out.
    """
    if not location_str:
        return False

    loc = location_str.lower()

    # Adelaide / South Australia
    if "adelaide" in loc or "south australia" in loc or " sa " in loc or loc.endswith(" sa"):
        return True

    # Remote with AU/UK/US qualifier -- must be remote AND one of the listed regions
    if "remote" in loc:
        if any(x in loc for x in ["australia", "au", "uk", "united kingdom", "us", "united states", "usa"]):
            return True
        # Generic "remote" with no country specified -- allow as candidate
        if loc.strip() in ("remote", "remote - worldwide", "remote (worldwide)", "anywhere"):
            return True

    return False


if __name__ == "__main__":
    # Quick smoke test
    print("detect_ats tests:")
    print(" workday.com:", detect_ats("https://company.wd3.myworkday.com/apply"))
    print(" linkedin:", detect_ats("https://www.linkedin.com/jobs/view/123456"))
    print(" seek:", detect_ats("https://www.seek.com.au/job/123"))
    print(" smartrecruiters:", detect_ats("https://jobs.smartrecruiters.com/Acme/123"))
    print(" pageup:", detect_ats("https://app.pageuppeople.com/apply/123"))
    print(" generic:", detect_ats("https://example.com/careers/apply"))
    print()
    print("is_location_allowed tests:")
    print(" Adelaide:", is_location_allowed("Adelaide SA"))
    print(" Remote AU:", is_location_allowed("Remote - Australia"))
    print(" Remote:", is_location_allowed("Remote"))
    print(" Sydney:", is_location_allowed("Sydney NSW"))
    print(" Remote UK:", is_location_allowed("Remote UK"))
    print(" London:", is_location_allowed("London, UK"))
    print()
    print("get_review_required:", get_review_required())
