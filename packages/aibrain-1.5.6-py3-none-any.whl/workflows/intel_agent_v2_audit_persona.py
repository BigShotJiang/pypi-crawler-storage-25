#!/usr/bin/env python3
"""AIBrain Workflow: intel_agent V2 — audit a persona file.

Phase B of the V2 propagation experiment (see
`C:\\Users\\sinde\\.claude-deckerops\\projects\\C--Users-sinde\\memory\\project_intel_agent_v2_pixel_moment_experiment.md`).

Shape:
    The persona file at `persona_path` is the target. The intel_agent_v2
    persona file is loaded as methodology context. The workflow reads both,
    then files a one-page V2 spec at `spec_path` (default:
    `decker_system/00_meta/v2_persona_specs/<stem>_v2_spec.md`).

    The spec body itself is authored by the caller's LLM context (the V2
    persona reasoning through the INTERROGATE / falsifiability / parallel
    epistemic gate / adversarial round / pressure-test / phase-contract /
    scope-bounded discipline) and handed in as `spec_content`. The workflow
    is the deterministic glue: it loads inputs, validates, writes output,
    and routes through `workflow_execute` so every audit run lands in
    `execution_log` with a quality score and audit trail.

    This mirrors every other workflow in the repo — heartbeat.py is
    deterministic glue for health checks, code_review_runner.py is
    deterministic glue for static analysis, this file is deterministic
    glue for V2 audit filing. The LLM work lives in the agent context
    one level up, exactly like it does for a human code reviewer using a
    review tool.

Usage (Python):
    from aibrain.core.workflow_runner import run_workflow

    result = run_workflow(
        "intel_agent_v2_audit_persona",
        persona_path="C:/Users/sinde/decker_system/02_subagents/decision_agent.md",
        spec_content="...the V2-authored one-page spec body...",
    )

Usage (CLI):
    python -m aibrain.core.workflow_runner intel_agent_v2_audit_persona \\
        --persona-path .../decision_agent.md \\
        --spec-content-file /tmp/decision_v2_spec.md
"""

from __future__ import annotations

import argparse
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from aibrain.core.workflow_base import workflow_execute

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

SUBAGENTS_DIR = Path("C:/Users/sinde/decker_system/02_subagents")
V2_PERSONA_PATH = SUBAGENTS_DIR / "intel_agent_v2.md"
V1_PERSONA_PATH = SUBAGENTS_DIR / "intel_agent.md"
SPEC_OUTPUT_DIR = Path("C:/Users/sinde/decker_system/00_meta/v2_persona_specs")

# Minimum sections a well-formed V2 spec must contain. The workflow is
# deterministic — it can't evaluate methodology quality, but it can enforce
# the structural discipline floor before filing. Missing any of these blocks
# the write and surfaces the gap as a workflow failure.
REQUIRED_SPEC_HEADERS = [
    "## Verdict",
    "## Domain-specific failure modes",
    "## V2 primitives that apply",
    "## What V1 already does well",
    "## What V2 would add",
    "## Cross-reference",
    "## Honest-null",
]


# ---------------------------------------------------------------------------
# Core
# ---------------------------------------------------------------------------

def _load_persona(path: Path) -> str:
    if not path.exists():
        raise FileNotFoundError(f"Persona file not found: {path}")
    return path.read_text(encoding="utf-8", errors="replace")


def _validate_spec(spec_content: str) -> list[str]:
    """Return a list of missing required headers. Empty list = spec passes."""
    missing = []
    for header in REQUIRED_SPEC_HEADERS:
        if header not in spec_content:
            missing.append(header)
    return missing


def _default_spec_path(persona_path: Path) -> Path:
    return SPEC_OUTPUT_DIR / f"{persona_path.stem}_v2_spec.md"


def run(
    persona_path: str,
    spec_content: str,
    spec_path: Optional[str] = None,
    dry_run: bool = False,
    **_ignored,
) -> dict:
    """Audit a persona: load inputs, validate spec structure, file output.

    Args:
        persona_path:  Absolute path to the V1 persona file being audited.
        spec_content:  The full markdown body of the V2 spec, authored by
                       the intel_agent_v2 caller context. Must contain all
                       `REQUIRED_SPEC_HEADERS`.
        spec_path:     Optional override for the output path. Defaults to
                       `SPEC_OUTPUT_DIR/<stem>_v2_spec.md`.
        dry_run:       If True, validate and return but do not write.

    Returns:
        dict with keys: success, persona, spec_path, missing_headers,
                        persona_chars, v1_floor_chars, v2_methodology_chars,
                        timestamp.

    Raises:
        FileNotFoundError:  If the persona or V2 methodology file is missing.
        ValueError:         If the spec content fails the required-headers
                            check. This is the structural discipline floor —
                            spec authorship without the parallel epistemic
                            gate blocks the write.
    """
    target = Path(persona_path)
    v1_floor = _load_persona(V1_PERSONA_PATH)
    v2_methodology = _load_persona(V2_PERSONA_PATH)
    target_text = _load_persona(target)

    missing = _validate_spec(spec_content)
    if missing:
        raise ValueError(
            "Spec is missing required structural headers — parallel epistemic gate "
            f"not satisfied: {missing}"
        )

    out_path = Path(spec_path) if spec_path else _default_spec_path(target)

    status = {
        "success": True,
        "persona": target.name,
        "spec_path": str(out_path),
        "missing_headers": missing,
        "persona_chars": len(target_text),
        "v1_floor_chars": len(v1_floor),
        "v2_methodology_chars": len(v2_methodology),
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }

    if not dry_run:
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(spec_content, encoding="utf-8")

    return status


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _main():
    parser = argparse.ArgumentParser(description="intel_agent_v2 — audit a persona")
    parser.add_argument("--persona-path", required=True, help="Path to the V1 persona to audit")
    parser.add_argument("--spec-content-file", required=True, help="Path to a file containing the V2-authored spec body")
    parser.add_argument("--spec-path", help="Override output path (defaults to 00_meta/v2_persona_specs/<stem>_v2_spec.md)")
    parser.add_argument("--dry-run", action="store_true", help="Validate only, do not write")
    args = parser.parse_args()

    spec_content = Path(args.spec_content_file).read_text(encoding="utf-8")

    status = run(
        persona_path=args.persona_path,
        spec_content=spec_content,
        spec_path=args.spec_path,
        dry_run=args.dry_run,
    )
    print(f"[{'dry-run' if args.dry_run else 'filed'}] {status['persona']} -> {status['spec_path']}")


if __name__ == "__main__":
    workflow_execute(
        workflow_name="intel_agent_v2_audit_persona",
        action=_main,
        task_type="judgment",
        actor="intel_agent_v2",
    )
