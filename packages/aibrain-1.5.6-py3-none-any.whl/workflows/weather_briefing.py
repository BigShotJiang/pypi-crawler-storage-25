#!/usr/bin/env python3
"""AIBrain Workflow: Weather Briefing — daily forecast via Open-Meteo (free, no API key)."""

import sys, io

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute
if sys.stdout.encoding and sys.stdout.encoding.lower() not in ("utf-8", "utf8"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

import argparse
import datetime
import json
import os
import smtplib
import sqlite3
import sys
import urllib.request
from email.mime.text import MIMEText
from pathlib import Path

# ---------------------------------------------------------------------------
# Config & DB helpers (self-contained — no external imports beyond stdlib)
# ---------------------------------------------------------------------------

from aibrain_db import AIBRAIN_ROOT, get_db
_cfg_path = AIBRAIN_ROOT / "config.json"
CONFIG = json.loads(_cfg_path.read_text()) if _cfg_path.exists() else {}
def _find_db():
    """Find best DB path, checking both new and legacy names."""
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    configured = CONFIG.get("db_path")
    if configured and Path(configured).exists():
        return configured
    mem_db = AIBRAIN_ROOT / "memory" / "memory.db"
    if mem_db.exists():
        return str(mem_db)
    return str(AIBRAIN_ROOT / "aibrain.db")

MEMORY_DB = CONFIG.get("db_path", _find_db())
API_BASE = os.environ.get("AIBRAIN_API", os.environ.get("AIBRAIN_API", "http://localhost:8001/api/agent"))


def log_activity(action, detail="", status="ok"):
    try:
        data = json.dumps({
            "action": action, "category": "productivity",
            "detail": detail, "status": status,
        }).encode()
        req = urllib.request.Request(
            f"{API_BASE}/activity", data=data,
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass


WMO_CODES = {
    0: "Clear sky", 1: "Mainly clear", 2: "Partly cloudy", 3: "Overcast",
    45: "Fog", 48: "Depositing rime fog",
    51: "Light drizzle", 53: "Moderate drizzle", 55: "Dense drizzle",
    61: "Slight rain", 63: "Moderate rain", 65: "Heavy rain",
    66: "Light freezing rain", 67: "Heavy freezing rain",
    71: "Slight snow", 73: "Moderate snow", 75: "Heavy snow", 77: "Snow grains",
    80: "Slight showers", 81: "Moderate showers", 82: "Violent showers",
    85: "Slight snow showers", 86: "Heavy snow showers",
    95: "Thunderstorm", 96: "Thunderstorm w/ slight hail", 99: "Thunderstorm w/ heavy hail",
}


def get_db():
    db = get_db()
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    return db


def load_state(name):
    try:
        db = get_db()
        row = db.execute(
            "SELECT content FROM memories WHERE name=? AND active=1",
            (f"workflow_state:{name}",),
        ).fetchone()
        db.close()
        return json.loads(row["content"]) if row else {}
    except Exception:
        return {}


def save_state(name, state):
    db = get_db()
    try:
        now = datetime.datetime.now().isoformat()
        existing = db.execute(
            "SELECT id FROM memories WHERE name=? AND active=1",
            (f"workflow_state:{name}",),
        ).fetchone()
        if existing:
            db.execute("UPDATE memories SET content=?, updated=? WHERE id=?",
                       (json.dumps(state), now, existing["id"]))
        else:
            db.execute(
                "INSERT INTO memories (name,type,tags,content,created,updated,active) VALUES (?,?,?,?,?,?,1)",
                (f"workflow_state:{name}", "reference", "workflow,state",
                 json.dumps(state), now, now),
            )
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def send_email(to, subject, body, dry_run=False):
    if dry_run:
        print(f"TO: {to}\nSUBJECT: {subject}\n\n{body}")
        return
    agent_email = CONFIG.get("agent_email", "aibrain@localhost")
    agent_password = CONFIG.get("agent_email_password", CONFIG.get("email_app_password", ""))
    msg = MIMEText(body, "plain")
    msg["From"] = agent_email
    msg["To"] = to
    msg["Subject"] = subject
    with smtplib.SMTP_SSL(CONFIG.get("agent_smtp_host", CONFIG.get("email_smtp_host", "smtp.gmail.com")), 465) as s:
        s.login(agent_email, agent_password)
        s.send_message(msg)


# ---------------------------------------------------------------------------
# Weather logic
# ---------------------------------------------------------------------------

def outfit_tip(temp_max):
    if temp_max < 5:
        return "Heavy coat, layers, gloves"
    if temp_max < 12:
        return "Warm jacket, layers"
    if temp_max < 20:
        return "Light jacket or hoodie"
    if temp_max < 28:
        return "T-shirt weather"
    return "Stay cool — shorts, sunscreen, hydrate"


def fetch_weather(lat, lon):
    url = (
        f"https://api.open-meteo.com/v1/forecast?"
        f"latitude={lat}&longitude={lon}"
        f"&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,"
        f"weathercode,windspeed_10m_max"
        f"&current_weather=true&timezone=auto&forecast_days=3"
    )
    with urllib.request.urlopen(url, timeout=15) as resp:
        return json.loads(resp.read().decode())


def format_briefing(data, location_name):
    current = data.get("current_weather", {})
    daily = data.get("daily", {})

    lines = [
        f"WEATHER BRIEFING — {location_name}",
        f"Generated: {datetime.datetime.now().strftime('%A %B %d, %Y %I:%M %p')}",
        "=" * 50,
        "",
        "CURRENT CONDITIONS",
        f"  Temperature: {current.get('temperature', '?')}°C",
        f"  Conditions:  {WMO_CODES.get(current.get('weathercode', -1), 'Unknown')}",
        f"  Wind:        {current.get('windspeed', '?')} km/h",
        "",
    ]

    for i, label in enumerate(["TODAY", "TOMORROW", "DAY AFTER"]):
        if i >= len(daily.get("time", [])):
            break
        t_max = daily["temperature_2m_max"][i]
        t_min = daily["temperature_2m_min"][i]
        precip = daily["precipitation_sum"][i]
        code = daily["weathercode"][i]
        wind = daily["windspeed_10m_max"][i]
        date_str = daily["time"][i]

        lines.append(f"{label} ({date_str})")
        lines.append(f"  High/Low:    {t_max}°C / {t_min}°C")
        lines.append(f"  Conditions:  {WMO_CODES.get(code, 'Unknown')}")
        lines.append(f"  Rain:        {precip} mm")
        lines.append(f"  Wind:        {wind} km/h")

        if i == 0:
            lines.append(f"  Outfit:      {outfit_tip(t_max)}")
            if precip > 1:
                lines.append("  Reminder:    Bring an umbrella!")
            if code >= 95:
                lines.append("  ⚠ SEVERE WEATHER WARNING — thunderstorms expected")
            if code >= 71 and code <= 77:
                lines.append("  ⚠ SNOW ALERT — check road conditions")
        lines.append("")

    lines.append("—\nPowered by AIBrain + Open-Meteo (free, no API key)")
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="AIBrain Weather Briefing")
    parser.add_argument("--dry-run", action="store_true", help="Print instead of emailing")
    args = parser.parse_args()

    lat = CONFIG.get("location_lat", 0)  # Set in config.json
    lon = CONFIG.get("location_lon", 0)
    location = CONFIG.get("location_name", "Your Location")
    if lat == 0 and lon == 0:
        print("NOTE: Set 'location_lat' and 'location_lon' in config.json for weather.", file=sys.stderr)
    email_to = CONFIG.get("email_to", CONFIG.get("agent_email", ""))

    try:
        data = fetch_weather(lat, lon)
    except Exception as e:
        body = f"Weather briefing unavailable today.\nError: {e}\n\n— AIBrain"
        if args.dry_run:
            print(body)
        elif email_to:
            send_email(email_to, "Weather Briefing — Unavailable", body, args.dry_run)
        sys.exit(1)

    briefing = format_briefing(data, location)

    if not email_to or args.dry_run:
        print(briefing)
    else:
        send_email(email_to, f"Weather Briefing — {location}", briefing)
        print(f"Sent weather briefing to {email_to}")

    save_state("weather_briefing", {"last_run": datetime.datetime.now().isoformat()})

    current = data.get("current_weather", {})
    temp = current.get("temperature", "?")
    code = WMO_CODES.get(current.get("weathercode", -1), "Unknown")
    log_activity("weather_briefing", f"{location}: {temp}°C, {code}")


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name='weather_briefing',
        action=_workflow_entry,
        task_type='deterministic',
        actor='cli',
    )
