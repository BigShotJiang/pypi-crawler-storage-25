"""
instagram_poster.py — Persistent Instagram posting via instagrapi.

Runs independently of Claude Code sessions. Designed to be triggered by
Windows Task Scheduler at 10:30 AM ACST daily.

Flow:
  1. Read instagram_captions.json
  2. Find today's entry by date
  3. Post image + caption via instagrapi (Facebook login)
  4. Mark as posted in JSON
  5. Send Telegram confirmation (or error alert)

Usage:
    python instagram_poster.py                  # Post today's entry
    python instagram_poster.py --date 2026-04-05  # Post specific date
    python instagram_poster.py --dry-run        # Preview without posting
    python instagram_poster.py --list           # Show all entries and status

Credentials: INSTAGRAM_USERNAME and INSTAGRAM_PASSWORD from ~/.decker_env
"""

import argparse
import json
import os
import sys
import traceback
from datetime import datetime
from pathlib import Path

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

# ═══════════════════════════════════════════════════════════════
# CONFIG
# ═══════════════════════════════════════════════════════════════

DECKER_ENV = Path.home() / ".decker_env"
SOCIAL_DIR = Path(r"C:\Users\sinde\decker_system\12_social")
CAPTIONS_FILE = SOCIAL_DIR / "visuals" / "instagram_captions.json"
VISUALS_DIR = SOCIAL_DIR / "visuals"
SESSION_FILE = Path.home() / ".instagram_session.json"
LOG_FILE = Path(r"C:\Users\sinde\decker_system\04_tools\content\instagram_poster.log")


def load_env():
    """Load credentials from .decker_env file."""
    env = {}
    if DECKER_ENV.exists():
        for line in DECKER_ENV.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                key, _, val = line.partition("=")
                key = key.strip()
                val = val.strip().strip("'\"")
                env[key] = val
    return env


def log(msg: str):
    """Log to file and stdout."""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def send_telegram(message: str, env: dict):
    """Send a Telegram notification. Fire-and-forget via daemon thread."""
    import threading
    import urllib.request

    token = env.get("TELEGRAM_TOKEN", "")
    chat_id = env.get("TELEGRAM_DM_ID", "")
    if not token or not chat_id:
        log("[WARN] No Telegram credentials — skipping notification")
        return

    def _send():
        url = f"https://api.telegram.org/bot{token}/sendMessage"
        import json as _json
        data = _json.dumps({"chat_id": chat_id, "text": message}).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
        try:
            urllib.request.urlopen(req, timeout=10)
        except Exception as e:
            log(f"[WARN] Telegram send failed: {e}")

    threading.Thread(target=_send, daemon=True).start()


def load_captions() -> dict:
    """Load the Instagram captions JSON."""
    if not CAPTIONS_FILE.exists():
        log(f"[ERROR] Captions file not found: {CAPTIONS_FILE}")
        sys.exit(1)
    return json.loads(CAPTIONS_FILE.read_text(encoding="utf-8"))


def save_captions(data: dict):
    """Save updated captions JSON."""
    CAPTIONS_FILE.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def find_todays_entry(data: dict, target_date: str = None) -> tuple[str, dict]:
    """Find the entry matching today's date (or a specific date)."""
    if target_date is None:
        target_date = datetime.now().strftime("%Y-%m-%d")

    for key, entry in data.items():
        if key.startswith("_"):
            continue
        if isinstance(entry, dict) and entry.get("date") == target_date:
            return key, entry

    return None, None


def post_to_instagram(image_path: str, caption: str, env: dict, dry_run: bool = False) -> bool:
    """Post an image with caption to Instagram via instagrapi."""
    if dry_run:
        log(f"[DRY RUN] Would post: {image_path}")
        log(f"[DRY RUN] Caption: {caption[:100]}...")
        return True

    username = env.get("INSTAGRAM_USERNAME", "")
    password = env.get("INSTAGRAM_PASSWORD", "")

    if not username or not password:
        log("[ERROR] INSTAGRAM_USERNAME or INSTAGRAM_PASSWORD not set in .decker_env")
        return False

    try:
        from instagrapi import Client

        cl = Client()

        # Try to load existing session
        if SESSION_FILE.exists():
            try:
                cl.load_settings(str(SESSION_FILE))
                cl.login(username, password)
                log("[OK] Logged in with saved session")
            except Exception:
                log("[INFO] Saved session expired, doing fresh login")
                cl = Client()
                cl.login(username, password)
                cl.dump_settings(str(SESSION_FILE))
        else:
            cl.login(username, password)
            cl.dump_settings(str(SESSION_FILE))
            log("[OK] Fresh login successful, session saved")

        # Post the image
        media = cl.photo_upload(
            path=image_path,
            caption=caption,
        )

        log(f"[OK] Posted! Media ID: {media.pk}")
        return True

    except Exception as e:
        log(f"[ERROR] Instagram post failed: {e}")
        log(traceback.format_exc())
        return False


def cmd_post(target_date: str = None, dry_run: bool = False):
    """Post today's (or specified date's) Instagram entry."""
    env = load_env()
    data = load_captions()

    key, entry = find_todays_entry(data, target_date)

    if not key or not entry:
        date_str = target_date or datetime.now().strftime("%Y-%m-%d")
        log(f"[INFO] No Instagram entry for {date_str}")
        return

    if entry.get("posted"):
        log(f"[SKIP] {key} ({entry['date']}) already posted")
        return

    image_file = entry.get("image", "")
    caption = entry.get("caption", "")
    image_path = VISUALS_DIR / image_file

    if not image_path.exists():
        log(f"[ERROR] Image not found: {image_path}")
        send_telegram(f"INSTAGRAM ERROR: Image not found for {key}: {image_file}", env)
        return

    if not caption:
        log(f"[ERROR] No caption for {key}")
        return

    log(f"Posting {key} ({entry['date']}): {image_file}")

    success = post_to_instagram(str(image_path), caption, env, dry_run=dry_run)

    if success and not dry_run:
        # Mark as posted
        data[key]["posted"] = True
        save_captions(data)
        log(f"[OK] Marked {key} as posted")

        # Telegram confirmation
        send_telegram(
            f"INSTAGRAM: Posted {key} ({entry['date']}) to @deckerslife\n"
            f"Image: {image_file}\n"
            f"Caption: {caption[:100]}...",
            env,
        )
    elif not success:
        send_telegram(
            f"INSTAGRAM ERROR: Failed to post {key} ({entry['date']})\n"
            f"Check logs: {LOG_FILE}",
            env,
        )


def cmd_list():
    """List all entries and their status."""
    data = load_captions()
    print(f"\n{'Day':<8} {'Date':<12} {'Posted':<8} {'Image':<25} Caption")
    print("-" * 90)
    for key, entry in data.items():
        if key.startswith("_"):
            continue
        if isinstance(entry, dict):
            posted = "YES" if entry.get("posted") else "no"
            date = entry.get("date", "?")
            image = entry.get("image", "?")
            caption = entry.get("caption", "")[:40]
            print(f"{key:<8} {date:<12} {posted:<8} {image:<25} {caption}...")
    print()


def main():
    parser = argparse.ArgumentParser(description="Instagram poster for @deckerslife")
    parser.add_argument("--date", help="Post for specific date (YYYY-MM-DD)")
    parser.add_argument("--dry-run", action="store_true", help="Preview without posting")
    parser.add_argument("--list", action="store_true", help="List all entries")

    args = parser.parse_args()

    if args.list:
        cmd_list()
    else:
        cmd_post(target_date=args.date, dry_run=args.dry_run)


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name='instagram_poster',
        action=_workflow_entry,
        task_type='simple',
        actor='cli',
    )
