#!/usr/bin/env python3
"""AIBrain Workflow: Contact Enricher — build contact profiles from email interactions."""

import argparse
import collections
import datetime
import email
import imaplib
import json
import os
import re
import smtplib
import sqlite3
import sys
import urllib.request
from email.header import decode_header
from email.mime.text import MIMEText
from pathlib import Path

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

from aibrain_db import AIBRAIN_ROOT, get_db
_cfg_path = AIBRAIN_ROOT / "config.json"
CONFIG = json.loads(_cfg_path.read_text()) if _cfg_path.exists() else {}
def _find_db():
    """Find best DB path, checking both new and legacy names."""
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    configured = CONFIG.get("db_path")
    if configured and Path(configured).exists():
        return configured
    mem_db = AIBRAIN_ROOT / "memory" / "memory.db"
    if mem_db.exists():
        return str(mem_db)
    return str(AIBRAIN_ROOT / "aibrain.db")

MEMORY_DB = CONFIG.get("db_path", _find_db())
API_BASE = os.environ.get("AIBRAIN_API", os.environ.get("AIBRAIN_API", "http://localhost:8001/api/agent"))


def log_activity(action, detail="", status="ok"):
    try:
        data = json.dumps({
            "action": action, "category": "email",
            "detail": detail, "status": status,
        }).encode()
        req = urllib.request.Request(
            f"{API_BASE}/activity", data=data,
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass


def get_db():
    db = get_db()
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    return db

def load_state(name):
    try:
        db = get_db()
        row = db.execute("SELECT content FROM memories WHERE name=? AND active=1",
                         (f"workflow_state:{name}",)).fetchone()
        db.close()
        return json.loads(row["content"]) if row else {}
    except Exception:
        return {}

def save_state(name, state):
    db = get_db()
    try:
        now = datetime.datetime.now().isoformat()
        existing = db.execute("SELECT id FROM memories WHERE name=? AND active=1",
                             (f"workflow_state:{name}",)).fetchone()
        if existing:
            db.execute("UPDATE memories SET content=?, updated=? WHERE id=?",
                       (json.dumps(state), now, existing["id"]))
        else:
            db.execute("INSERT INTO memories (name,type,tags,content,created,updated,active) VALUES (?,?,?,?,?,?,1)",
                       (f"workflow_state:{name}", "reference", "workflow,state", json.dumps(state), now, now))
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()

def send_email(to, subject, body, dry_run=False):
    if dry_run:
        print(f"TO: {to}\nSUBJECT: {subject}\n\n{body}")
        return
    agent_email = CONFIG.get("agent_email", "aibrain@localhost")
    agent_password = CONFIG.get("agent_email_password", CONFIG.get("email_app_password", ""))
    msg = MIMEText(body, "plain")
    msg["From"] = agent_email
    msg["To"] = to
    msg["Subject"] = subject
    with smtplib.SMTP_SSL(CONFIG.get("agent_smtp_host", CONFIG.get("email_smtp_host", "smtp.gmail.com")), 465) as s:
        s.login(agent_email, agent_password)
        s.send_message(msg)


def get_email_accounts():
    """Build list of all email accounts to monitor."""
    accounts = []
    agent_email = CONFIG.get("agent_email", "")
    agent_password = CONFIG.get("agent_email_password", CONFIG.get("email_app_password", ""))
    agent_imap = CONFIG.get("agent_imap_host", CONFIG.get("email_imap_host", "imap.gmail.com"))
    if agent_email and agent_password:
        accounts.append({"label": "agent", "email": agent_email, "password": agent_password, "imap_host": agent_imap})
    for acct in CONFIG.get("email_accounts", []):
        if acct.get("monitor") and acct.get("email") and acct.get("app_password"):
            accounts.append({
                "label": acct.get("label", acct["email"].split("@")[0]),
                "email": acct["email"],
                "password": acct["app_password"],
                "imap_host": acct.get("imap_host", "imap.gmail.com"),
            })
    return accounts


def decode_mime_header(header):
    if not header:
        return ""
    parts = decode_header(header)
    decoded = []
    for part, charset in parts:
        if isinstance(part, bytes):
            decoded.append(part.decode(charset or "utf-8", errors="replace"))
        else:
            decoded.append(str(part))
    return " ".join(decoded)


def scan_contacts(imap_host, email_addr, password, days=30):
    """Scan emails and build contact frequency map."""
    contacts = {}
    try:
        mail = imaplib.IMAP4_SSL(imap_host, 993)
        mail.login(email_addr, password)
        mail.select("INBOX", readonly=True)

        since = (datetime.date.today() - datetime.timedelta(days=days)).strftime("%d-%b-%Y")
        _, data = mail.search(None, f'(SINCE "{since}")')
        msg_ids = data[0].split()

        for mid in msg_ids[-200:]:
            _, msg_data = mail.fetch(mid, "(BODY[HEADER.FIELDS (FROM TO SUBJECT DATE)])")
            raw = msg_data[0][1]
            msg = email.message_from_bytes(raw)
            sender = decode_mime_header(msg.get("From", ""))

            # Extract email and name
            match = re.search(r"([\w.+-]+@[\w.-]+)", sender)
            if not match:
                continue
            addr = match.group(1).lower()
            name_match = re.match(r'"?([^"<]+)"?\s*<', sender)
            name = name_match.group(1).strip() if name_match else addr.split("@")[0]
            domain = addr.split("@")[1]

            if addr == email_addr.lower():
                continue  # skip self

            if addr not in contacts:
                contacts[addr] = {
                    "email": addr,
                    "name": name,
                    "domain": domain,
                    "count": 0,
                    "subjects": [],
                    "first_seen": msg.get("Date", ""),
                    "last_seen": msg.get("Date", ""),
                }
            contacts[addr]["count"] += 1
            contacts[addr]["last_seen"] = msg.get("Date", "")
            subj = decode_mime_header(msg.get("Subject", ""))
            if subj and len(contacts[addr]["subjects"]) < 3:
                contacts[addr]["subjects"].append(subj[:50])

        mail.logout()
    except Exception as e:
        print(f"IMAP error: {e}", file=sys.stderr)
    return contacts


def format_report(contacts):
    sorted_contacts = sorted(contacts.values(), key=lambda c: c["count"], reverse=True)

    # Filter out obvious automated senders
    human_contacts = [c for c in sorted_contacts if not any(
        p in c["email"] for p in ["noreply", "no-reply", "notifications", "mailer-daemon", "postmaster"]
    )]

    lines = [
        f"CONTACT ENRICHMENT — {datetime.datetime.now().strftime('%A %B %d, %Y')}",
        f"Scanned contacts: {len(contacts)} total, {len(human_contacts)} human",
        "=" * 50,
        "",
    ]

    # Top contacts
    lines.append("TOP CONTACTS (by frequency)")
    for c in human_contacts[:15]:
        lines.append(f"  {c['name']:25s} {c['email']:35s} {c['count']:>3d} emails")
        if c["subjects"]:
            lines.append(f"    Recent: {c['subjects'][0]}")
    lines.append("")

    # Domain breakdown
    domains = collections.Counter(c["domain"] for c in human_contacts)
    lines.append("TOP DOMAINS")
    for domain, count in domains.most_common(10):
        lines.append(f"  {domain:30s} {count:>3d} contacts")
    lines.append("")

    # New contacts (seen only once)
    new = [c for c in human_contacts if c["count"] == 1]
    if new:
        lines.append(f"NEW CONTACTS ({len(new)} one-time senders)")
        for c in new[:5]:
            lines.append(f"  {c['name']:25s} {c['email']}")
        lines.append("")

    lines.append("—\nPowered by AIBrain (read-only scan)")
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="AIBrain Contact Enricher — multi-account")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--days", type=int, default=30)
    args = parser.parse_args()

    accounts = get_email_accounts()
    if not accounts:
        print("Error: no email accounts configured in config.json", file=sys.stderr)
        sys.exit(1)

    email_to = CONFIG.get("email_to", CONFIG.get("agent_email", ""))

    # Scan contacts across all accounts
    all_contacts = {}
    per_account = {}
    for acct in accounts:
        print(f"Scanning {acct['label']} ({acct['email']}) — {args.days} days...")
        acct_contacts = scan_contacts(acct["imap_host"], acct["email"], acct["password"], args.days)
        # Merge contacts, tagging with account source
        for addr, info in acct_contacts.items():
            if addr in all_contacts:
                all_contacts[addr]["count"] += info["count"]
                all_contacts[addr]["accounts"].add(acct["label"])
                if info["last_seen"] > all_contacts[addr]["last_seen"]:
                    all_contacts[addr]["last_seen"] = info["last_seen"]
                for s in info["subjects"]:
                    if len(all_contacts[addr]["subjects"]) < 5:
                        all_contacts[addr]["subjects"].append(s)
            else:
                info["accounts"] = {acct["label"]}
                all_contacts[addr] = info
        per_account[acct["label"]] = len(acct_contacts)
        print(f"  {len(acct_contacts)} contacts found")

    # Convert sets to lists for JSON
    for c in all_contacts.values():
        c["accounts"] = sorted(c.get("accounts", set()))

    report = format_report(all_contacts)

    # Append multi-account summary if applicable
    if len(accounts) > 1:
        extra = ["\nACCOUNT SUMMARY:"]
        for label, count in per_account.items():
            extra.append(f"  {label:20s} {count:3d} contacts")
        # Cross-account contacts
        cross = [c for c in all_contacts.values() if len(c.get("accounts", [])) > 1]
        if cross:
            extra.append(f"\nCROSS-ACCOUNT CONTACTS ({len(cross)}):")
            for c in sorted(cross, key=lambda x: x["count"], reverse=True)[:10]:
                extra.append(f"  {c['name']:25s} seen in: {', '.join(c['accounts'])}")
        report += "\n" + "\n".join(extra)

    if not email_to or args.dry_run:
        print(report)
    else:
        acct_label = f" ({len(accounts)} accounts)" if len(accounts) > 1 else ""
        send_email(email_to, f"Contact Report — {len(all_contacts)} contacts{acct_label}", report)

    save_state("contact_enricher", {
        "last_run": datetime.datetime.now().isoformat(),
        "accounts_checked": len(accounts),
        "contacts_found": len(all_contacts),
        "per_account": per_account,
    })

    log_activity("contact_enricher_run",
                 f"accounts={len(accounts)} contacts={len(all_contacts)}")


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name='contact_enricher',
        action=_workflow_entry,
        task_type='simple',
        actor='cli',
    )
