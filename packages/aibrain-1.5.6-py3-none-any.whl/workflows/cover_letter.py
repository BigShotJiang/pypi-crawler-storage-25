"""cover_letter.py -- Cover letter generator for the job application pipeline.

Generates tailored cover letters using:
  1. Real-time company research via Playwright
  2. Structured candidate profile from decker_profile.json
  3. LLM generation via LocalLLMClient (Ollama) with requests fallback

Rules enforced in the prompt:
  - No dashes or pipes as punctuation
  - No bullet points in the body
  - Natural prose, 3 paragraphs
  - Opening specific to the company (never "I am writing to apply for...")
  - Metrics referenced: AIBrain 249K pageviews, Wintermute 28,865 findings, certifications
"""

import datetime
import json
import re
import sys
from pathlib import Path

# Harness import required for all modules in the workflows directory (P0-1 backfill)
from aibrain.core.workflow_base import workflow_execute  # noqa: F401

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
_HERE = Path(__file__).parent
_PROFILE_PATH = _HERE / "decker_profile.json"
_COVER_LETTERS_DIR = _HERE / "cover_letters"
_COVER_LETTERS_DIR.mkdir(exist_ok=True)

# ---------------------------------------------------------------------------
# Playwright availability check
# ---------------------------------------------------------------------------
_PLAYWRIGHT_AVAILABLE = False
try:
    import playwright  # noqa: F401
    _PLAYWRIGHT_AVAILABLE = True
except ImportError:
    pass


def _load_profile() -> dict:
    """Load the candidate profile from decker_profile.json."""
    if not _PROFILE_PATH.exists():
        raise FileNotFoundError(f"decker_profile.json not found at {_PROFILE_PATH}")
    return json.loads(_PROFILE_PATH.read_text(encoding="utf-8"))


def _slug(text: str) -> str:
    """Convert text to a safe filename slug."""
    return re.sub(r"[^a-z0-9]+", "_", text.lower()).strip("_")[:40]


def _research_company(company_name: str, job_url: str) -> str:
    """Scrape 2-3 sentences of company context via Playwright.

    Tries the company About page and LinkedIn company page.
    Returns empty string on any failure (graceful degradation).
    """
    if not _PLAYWRIGHT_AVAILABLE:
        return ""

    context_lines = []

    try:
        from playwright.sync_api import sync_playwright

        with sync_playwright() as pw:
            browser = pw.chromium.launch(
                headless=True,
                args=[
                    "--disable-blink-features=AutomationControlled",
                    "--no-first-run",
                    "--no-default-browser-check",
                ],
            )
            page = browser.new_page(
                user_agent=(
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/124.0.0.0 Safari/537.36"
                )
            )
            page.set_default_timeout(15000)

            # Strategy 1: try to extract domain from job_url and visit /about
            try:
                from urllib.parse import urlparse
                parsed = urlparse(job_url)
                if parsed.netloc and not any(
                    x in parsed.netloc
                    for x in ["seek.com", "indeed.com", "linkedin.com", "workday.com"]
                ):
                    about_url = f"{parsed.scheme}://{parsed.netloc}/about"
                    page.goto(about_url, wait_until="domcontentloaded")
                    # Grab visible paragraph text
                    texts = page.eval_on_selector_all(
                        "main p, section p, .about p, #about p",
                        "els => els.map(e => e.innerText.trim()).filter(t => t.length > 40)",
                    )
                    for t in texts[:3]:
                        clean = t.strip().replace("\n", " ")
                        if clean:
                            context_lines.append(clean)
            except Exception:
                pass

            # Strategy 2: LinkedIn company search (only if we have < 2 sentences)
            if len(context_lines) < 2:
                try:
                    search_url = (
                        f"https://www.linkedin.com/search/results/companies/"
                        f"?keywords={company_name.replace(' ', '+')}"
                    )
                    page.goto(search_url, wait_until="domcontentloaded")
                    # Grab the first result's tagline/description
                    desc_el = page.query_selector(
                        ".search-results__cluster-content .entity-result__summary"
                    )
                    if desc_el:
                        context_lines.append(desc_el.inner_text().strip())
                except Exception:
                    pass

            browser.close()

    except Exception as exc:
        print(f"  Company research failed for '{company_name}': {exc}", file=sys.stderr)

    return " ".join(context_lines[:3]).strip()


def _call_llm(prompt: str, system: str) -> str:
    """Call LLM for cover letter generation.

    Priority order:
      1. LocalLLMClient (Ollama -- local, zero cost)
      2. POST http://localhost:8001/api/v1/complete (AIBrain API)
      3. Raise RuntimeError
    """
    # Try LocalLLMClient first
    try:
        from aibrain.core.local_llm import LocalLLMClient

        client = LocalLLMClient()
        if client.is_available():
            messages = [{"role": "user", "content": prompt}]
            return client.complete(messages=messages, system=system)
    except Exception as exc:
        print(f"  LocalLLMClient unavailable: {exc}", file=sys.stderr)

    # Fallback: POST to local AIBrain API
    try:
        import requests as _req

        resp = _req.post(
            "http://localhost:8001/api/v1/complete",
            json={"prompt": prompt, "system": system, "max_tokens": 800},
            timeout=60,
        )
        if resp.status_code == 200:
            data = resp.json()
            # Handle both {"text": "..."} and {"content": "..."} shapes
            return data.get("text") or data.get("content") or str(data)
    except Exception as exc:
        print(f"  AIBrain API unavailable: {exc}", file=sys.stderr)

    raise RuntimeError(
        "No LLM backend available. Install Ollama (https://ollama.com) and pull a model, "
        "or ensure the AIBrain API is running at http://localhost:8001."
    )


def generate_cover_letter(
    job_title: str,
    company_name: str,
    job_url: str,
    job_description_text: str,
    job_id: str = "",
) -> str:
    """Generate a tailored cover letter and save it to disk.

    Parameters
    ----------
    job_title : str
        The job title as listed in the posting.
    company_name : str
        The hiring company name.
    job_url : str
        URL of the job posting (used for company research).
    job_description_text : str
        Full or partial job description text for context.
    job_id : str, optional
        Stable job ID for the filename. Generated from title+company if empty.

    Returns
    -------
    str
        Path to the saved cover letter file.
    """
    profile = _load_profile()

    # Generate a stable job_id if not provided
    if not job_id:
        import hashlib
        job_id = hashlib.md5(f"{job_title}:{company_name}:{job_url}".encode()).hexdigest()[:12]

    # Research the company
    print(f"  Researching {company_name}...", file=sys.stderr)
    company_context = _research_company(company_name, job_url)

    # Build the generation prompt
    certs_str = ", ".join(profile.get("certifications", []))
    skills_preview = ", ".join(profile.get("skills", [])[:10])

    system = (
        "You are a professional cover letter writer producing content for a real job application. "
        "The letter must be in natural prose with NO bullet points and NO dashes or pipes used as "
        "punctuation separators. Use commas, periods, and full sentences throughout. "
        "The opening line must be specific to the company and role, never starting with "
        "'I am writing to apply for'. "
        "Write exactly 3 paragraphs: (1) why this specific role and company, "
        "(2) the most relevant experience and achievements, "
        "(3) a clear call to action close. "
        "Keep the letter concise, around 300 words. Sound human, confident, and specific."
    )

    company_context_section = (
        f"\n\nCompany research context (use this for the opening paragraph):\n{company_context}"
        if company_context
        else ""
    )

    prompt = f"""Write a cover letter for the following application.

Candidate: {profile['name']}
Email: {profile['email']}
Phone: {profile['phone']}
Location: {profile['address']}
LinkedIn: {profile['linkedin']}
GitHub: {profile['github']}
Right to work: {profile['right_to_work']}

Certifications: {certs_str}
Key skills: {skills_preview}

Key achievements to reference (use specific numbers where relevant):
- Built Wintermute, an autonomous AI pentesting engine, benchmarked across 29 targets with 28,865 findings generated and an 81 percent flag capture rate
- Published AIBrain on PyPI. myaibrain.org has reached 249,000 pageviews
- Shipped a six-product cybersecurity and AI tooling suite (Wintermute, Remediate, Rogue, Paragon, Permeate, AIBrain)
- Conducted semantic routing research benchmarked across 4,486 evaluations and four models
- CompTIA Network+ and Security+ certified, actively pursuing CySA+ and PenTest+
- TryHackMe Top 1 percent globally
{company_context_section}

Job title: {job_title}
Company: {company_name}
Job URL: {job_url}

Job description excerpt:
{job_description_text[:800] if job_description_text else 'Not provided.'}

Write the cover letter now. Start directly with the letter text, no subject line, no date header.
Sign off with just the candidate name."""

    print(f"  Generating cover letter for {job_title} at {company_name}...", file=sys.stderr)
    letter_text = _call_llm(prompt, system)

    # Save to disk
    company_slug = _slug(company_name)
    filename = f"{job_id}_{company_slug}.txt"
    output_path = _COVER_LETTERS_DIR / filename
    output_path.write_text(letter_text, encoding="utf-8")

    print(f"  Cover letter saved: {output_path}", file=sys.stderr)
    return str(output_path)


if __name__ == "__main__":
    # Quick smoke test
    path = generate_cover_letter(
        job_title="Security Engineer",
        company_name="Example Corp",
        job_url="https://example.com/jobs/security-engineer",
        job_description_text="We are looking for a security engineer with penetration testing experience.",
    )
    print(f"Saved to: {path}")
