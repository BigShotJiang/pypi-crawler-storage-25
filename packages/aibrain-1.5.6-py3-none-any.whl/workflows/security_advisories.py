#!/usr/bin/env python3
"""AIBrain Workflow: Security Advisories Monitor.

Polls CISA KEV, NVD, and GitHub Security Advisories for new high/critical
findings. Deduplicates via seen_advisories.json, logs everything to JSONL,
and sends Telegram alerts for HIGH+ severity items.

Usage:
    python security_advisories.py              # one-shot scan
    python security_advisories.py --dry-run    # scan without sending alerts
"""

import argparse
import datetime
import json
import logging
import os
import re
import sys
import time
from pathlib import Path

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

try:
    import requests
except ImportError:
    # Fall back to urllib if requests isn't installed
    import urllib.request
    import urllib.error

    class _MinimalRequests:
        """Thin shim so the rest of the code can use requests-style calls."""

        class Response:
            def __init__(self, data, status):
                self._data = data
                self.status_code = status
                self.text = data.decode("utf-8", errors="replace")

            def json(self):
                return json.loads(self._data)

            def raise_for_status(self):
                if self.status_code >= 400:
                    raise Exception(f"HTTP {self.status_code}")

        def get(self, url, headers=None, timeout=30):
            req = urllib.request.Request(url, headers=headers or {})
            try:
                with urllib.request.urlopen(req, timeout=timeout) as resp:
                    return self.Response(resp.read(), resp.status)
            except urllib.error.HTTPError as e:
                return self.Response(b"", e.code)

    requests = _MinimalRequests()

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
WORKFLOW_DIR = Path(__file__).parent
DATA_DIR = WORKFLOW_DIR / "data" / "security_advisories"
SEEN_FILE = DATA_DIR / "seen_advisories.json"
LOG_FILE = DATA_DIR / "advisories.jsonl"

# Load ~/.decker_env before reading token — env var may not be set in cron context
def _load_decker_env() -> None:
    _env = Path.home() / ".decker_env"
    if not _env.exists():
        return
    try:
        for _line in _env.read_text(encoding="utf-8", errors="replace").splitlines():
            _line = _line.strip()
            if _line and not _line.startswith("#") and "=" in _line:
                k, v = _line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip('"'))
    except Exception:
        pass

_load_decker_env()

TELEGRAM_TOKEN = (
    os.environ.get("TELEGRAM_TOKEN")
    or os.environ.get("TELEGRAM_BOT_TOKEN")
    or ""
)
TELEGRAM_CHAT_ID = os.environ.get("TELEGRAM_CHAT_ID", "")
API_BASE = os.environ.get("AIBRAIN_API", os.environ.get("AIBRAIN_API", "http://localhost:8001/api/agent"))


def log_activity(action, detail="", status="ok"):
    """Log activity to AIBrain API."""
    try:
        import urllib.request as _ur
        data = json.dumps({
            "action": action, "category": "research",
            "detail": detail, "status": status,
        }).encode()
        req = _ur.Request(
            f"{API_BASE}/activity", data=data,
            headers={"Content-Type": "application/json"},
        )
        _ur.urlopen(req, timeout=5)
    except Exception:
        pass

MAX_SEEN = 5000  # prune oldest entries beyond this

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
log = logging.getLogger("security_advisories")

# ---------------------------------------------------------------------------
# Persistence helpers
# ---------------------------------------------------------------------------

def _ensure_dirs():
    DATA_DIR.mkdir(parents=True, exist_ok=True)


def load_seen() -> set:
    if SEEN_FILE.exists():
        try:
            data = json.loads(SEEN_FILE.read_text(encoding="utf-8"))
            return set(data) if isinstance(data, list) else set()
        except (json.JSONDecodeError, ValueError):
            return set()
    return set()


def save_seen(seen: set):
    # Keep bounded
    items = sorted(seen)
    if len(items) > MAX_SEEN:
        items = items[-MAX_SEEN:]
    SEEN_FILE.write_text(json.dumps(items, indent=0), encoding="utf-8")


def append_jsonl(record: dict):
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, default=str) + "\n")


# ---------------------------------------------------------------------------
# Telegram
# ---------------------------------------------------------------------------

def send_telegram(message: str) -> bool:
    """Send a Telegram message. Returns True on success."""
    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    payload = {
        "chat_id": TELEGRAM_CHAT_ID,
        "text": message,
        "parse_mode": "HTML",
        "disable_web_page_preview": True,
    }
    try:
        resp = requests.get(
            url + "?" + "&".join(f"{k}={v}" for k, v in payload.items()),
            timeout=15,
        )
        if resp.status_code != 200:
            log.warning("Telegram send failed: %s", resp.text[:200])
            return False
        return True
    except Exception as e:
        log.warning("Telegram send error: %s", e)
        return False


def _tg_post(message: str) -> bool:
    """POST-based Telegram send (more reliable for long messages)."""
    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    try:
        resp = requests.get(url, timeout=15)  # dummy to check connectivity
    except Exception:
        pass
    # Use urllib directly for POST with JSON body
    import urllib.request
    req = urllib.request.Request(
        url,
        data=json.dumps({
            "chat_id": TELEGRAM_CHAT_ID,
            "text": message,
            "parse_mode": "HTML",
            "disable_web_page_preview": True,
        }).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    def _dispatch():
        try:
            urllib.request.urlopen(req, timeout=15)
        except Exception as e:
            log.warning("Telegram POST error: %s", e)

    import threading
    threading.Thread(target=_dispatch, daemon=True).start()
    return True


# ---------------------------------------------------------------------------
# Feed: CISA Known Exploited Vulnerabilities
# ---------------------------------------------------------------------------

def fetch_cisa_kev() -> list[dict]:
    """Fetch CISA KEV catalog and return normalized advisory dicts."""
    url = "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json"
    advisories = []
    try:
        resp = requests.get(url, timeout=30)
        resp.raise_for_status()
        data = resp.json()
    except Exception as e:
        log.error("CISA KEV fetch failed: %s", e)
        return []

    for vuln in data.get("vulnerabilities", []):
        cve_id = vuln.get("cveID", "UNKNOWN")
        advisories.append({
            "id": cve_id,
            "source": "CISA-KEV",
            "severity": "CRITICAL",  # everything in KEV is actively exploited
            "description": vuln.get("shortDescription", "")[:300],
            "affected": vuln.get("vendorProject", "") + " " + vuln.get("product", ""),
            "date_added": vuln.get("dateAdded", ""),
            "due_date": vuln.get("dueDate", ""),
            "url": f"https://nvd.nist.gov/vuln/detail/{cve_id}",
        })
    return advisories


# ---------------------------------------------------------------------------
# Feed: NVD Recent CVEs
# ---------------------------------------------------------------------------

def fetch_nvd_recent() -> list[dict]:
    """Fetch the 20 most recent CVEs from NVD 2.0 API."""
    url = "https://services.nvd.nist.gov/rest/json/cves/2.0?resultsPerPage=20"
    advisories = []
    try:
        resp = requests.get(url, headers={"Accept": "application/json"}, timeout=30)
        resp.raise_for_status()
        data = resp.json()
    except Exception as e:
        log.error("NVD fetch failed: %s", e)
        return []

    for item in data.get("vulnerabilities", []):
        cve = item.get("cve", {})
        cve_id = cve.get("id", "UNKNOWN")

        # Extract severity from CVSS metrics
        severity = "UNKNOWN"
        base_score = 0.0
        metrics = cve.get("metrics", {})
        for version_key in ("cvssMetricV31", "cvssMetricV30", "cvssMetricV2"):
            metric_list = metrics.get(version_key, [])
            if metric_list:
                cvss_data = metric_list[0].get("cvssData", {})
                severity = metric_list[0].get("baseSeverity",
                           cvss_data.get("baseSeverity", "UNKNOWN")).upper()
                base_score = cvss_data.get("baseScore", 0.0)
                break

        # Extract description (prefer English)
        desc = ""
        for d in cve.get("descriptions", []):
            if d.get("lang") == "en":
                desc = d.get("value", "")[:300]
                break

        # Extract affected CPEs
        affected_parts = []
        for config in cve.get("configurations", []):
            for node in config.get("nodes", []):
                for match in node.get("cpeMatch", []):
                    cpe = match.get("criteria", "")
                    # cpe:2.3:a:vendor:product:version:...
                    parts = cpe.split(":")
                    if len(parts) >= 5:
                        affected_parts.append(f"{parts[3]} {parts[4]}")
        affected = ", ".join(affected_parts[:5]) if affected_parts else "See NVD"

        advisories.append({
            "id": cve_id,
            "source": "NVD",
            "severity": severity,
            "base_score": base_score,
            "description": desc,
            "affected": affected,
            "published": cve.get("published", ""),
            "url": f"https://nvd.nist.gov/vuln/detail/{cve_id}",
        })
    return advisories


# ---------------------------------------------------------------------------
# Feed: GitHub Security Advisories (scrape reviewed page)
# ---------------------------------------------------------------------------

def fetch_github_advisories() -> list[dict]:
    """Fetch GitHub Security Advisories (reviewed) via REST API."""
    url = "https://api.github.com/advisories?per_page=20&type=reviewed"
    advisories = []
    _gh_token = os.environ.get("GITHUB_PAT", "") or os.environ.get("GITHUB_TOKEN", "")
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    if _gh_token:
        headers["Authorization"] = f"Bearer {_gh_token}"
    try:
        resp = requests.get(
            url,
            headers=headers,
            timeout=30,
        )
        resp.raise_for_status()
        data = resp.json()
    except Exception as e:
        log.error("GitHub Advisories fetch failed: %s", e)
        return []

    if not isinstance(data, list):
        log.error("GitHub Advisories unexpected response type: %s", type(data))
        return []

    for adv in data:
        ghsa_id = adv.get("ghsa_id", "UNKNOWN")
        cve_id = adv.get("cve_id") or ghsa_id
        severity = (adv.get("severity") or "UNKNOWN").upper()

        # Affected packages
        affected_parts = []
        for vuln in adv.get("vulnerabilities", []):
            pkg = vuln.get("package", {})
            name = pkg.get("name", "")
            ecosystem = pkg.get("ecosystem", "")
            if name:
                affected_parts.append(f"{ecosystem}:{name}" if ecosystem else name)

        advisories.append({
            "id": cve_id,
            "ghsa_id": ghsa_id,
            "source": "GitHub",
            "severity": severity,
            "description": (adv.get("summary") or "")[:300],
            "affected": ", ".join(affected_parts[:5]) if affected_parts else "See advisory",
            "published": adv.get("published_at", ""),
            "url": adv.get("html_url", f"https://github.com/advisories/{ghsa_id}"),
        })
    return advisories


# ---------------------------------------------------------------------------
# Core scan
# ---------------------------------------------------------------------------

def scan(dry_run: bool = False) -> dict:
    """Run a full scan across all feeds. Returns summary stats.

    Args:
        dry_run: If True, log and record but don't send Telegram alerts.

    Returns:
        dict with keys: total_fetched, new_count, alerted, errors
    """
    _ensure_dirs()
    seen = load_seen()
    now = datetime.datetime.utcnow().isoformat() + "Z"

    stats = {"total_fetched": 0, "new_count": 0, "alerted": 0, "errors": 0}
    new_advisories = []

    # Fetch all feeds
    feeds = [
        ("CISA-KEV", fetch_cisa_kev),
        ("NVD", fetch_nvd_recent),
        ("GitHub", fetch_github_advisories),
    ]

    for feed_name, fetcher in feeds:
        log.info("Fetching %s...", feed_name)
        try:
            items = fetcher()
            stats["total_fetched"] += len(items)
            for adv in items:
                adv_id = adv["id"]
                if adv_id not in seen:
                    seen.add(adv_id)
                    adv["first_seen"] = now
                    new_advisories.append(adv)
                    stats["new_count"] += 1
        except Exception as e:
            log.error("Feed %s error: %s", feed_name, e)
            stats["errors"] += 1
        # Rate-limit between feeds
        time.sleep(1)

    # Log all new advisories to JSONL
    for adv in new_advisories:
        append_jsonl(adv)

    # Alert on HIGH/CRITICAL only
    alert_severities = {"HIGH", "CRITICAL"}
    alerts = [a for a in new_advisories if a.get("severity") in alert_severities]

    if alerts and not dry_run:
        # Batch into messages of up to 5 advisories each
        batch_size = 5
        for i in range(0, len(alerts), batch_size):
            batch = alerts[i:i + batch_size]
            lines = [f"<b>Security Advisory Alert</b> ({len(batch)} new)\n"]
            for adv in batch:
                lines.append(
                    f"<b>{adv['severity']}</b> | <code>{adv['id']}</code>\n"
                    f"{adv['description'][:150]}\n"
                    f"Affected: {adv['affected'][:100]}\n"
                    f"Source: {adv['source']} | <a href=\"{adv['url']}\">Details</a>\n"
                )
            msg = "\n".join(lines)
            if _tg_post(msg):
                stats["alerted"] += len(batch)
                log.info("Sent Telegram alert for %d advisories", len(batch))
            else:
                log.warning("Failed to send Telegram alert")
            time.sleep(0.5)
    elif alerts and dry_run:
        log.info("[DRY RUN] Would alert on %d advisories", len(alerts))
        stats["alerted"] = len(alerts)

    save_seen(seen)
    log.info(
        "Scan complete: fetched=%d, new=%d, alerted=%d, errors=%d",
        stats["total_fetched"], stats["new_count"],
        stats["alerted"], stats["errors"],
    )
    return stats


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Security Advisories Monitor")
    parser.add_argument("--dry-run", action="store_true", help="Scan without sending alerts")
    args = parser.parse_args()
    stats = scan(dry_run=args.dry_run)
    print(json.dumps(stats, indent=2))

    log_activity(
        "security_advisories",
        f"Fetched {stats['total_fetched']}, {stats['new_count']} new, {stats['alerted']} alerted",
        "error" if stats["errors"] > 0 else "ok",
    )


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name='security_advisories',
        action=_workflow_entry,
        task_type='simple',
        actor='cli',
    )
