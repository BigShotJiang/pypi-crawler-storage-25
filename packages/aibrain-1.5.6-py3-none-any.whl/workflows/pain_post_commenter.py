#!/usr/bin/env python3
"""
pain_post_commenter.py — Search Twitter/X for AI memory frustration posts, reply with AIBrain.

Searches for tweets where people complain about AI forgetting context, then replies
with a helpful comment mentioning AIBrain. Tracks replied-to tweets in a JSONL log
to avoid duplicates.

Usage:
    python pain_post_commenter.py [--dry-run] [--limit N] [--query-index N]

Options:
    --dry-run        Print what would be posted, don't actually post
    --limit N        Max replies per run (default: 10)
    --query-index N  Which search query to use (0-4), default rotates through all

Log: marketing/outreach/pain-post-replies-log.jsonl
"""

import argparse
import datetime
import json
import os
import random
import sys
import time
from pathlib import Path

import tweepy

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

# ---------------------------------------------------------------------------
# Env — load .decker_env before anything else
# ---------------------------------------------------------------------------

DECKER_ENV = Path("C:/Users/sinde/.decker_env")
if DECKER_ENV.exists():
    for _line in DECKER_ENV.read_text(encoding="utf-8").splitlines():
        _line = _line.strip()
        if _line and not _line.startswith("#") and "=" in _line:
            _k, _v = _line.split("=", 1)
            os.environ.setdefault(_k.strip(), _v.strip())

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

AIBRAIN_ROOT = Path(__file__).parent.parent
LOG_PATH = AIBRAIN_ROOT / "marketing" / "outreach" / "pain-post-replies-log.jsonl"

# ---------------------------------------------------------------------------
# Search queries — rotate through these
# ---------------------------------------------------------------------------

SEARCH_QUERIES = [
    '"AI keeps forgetting" OR "ChatGPT forgets everything"',
    '"have to re-explain" (AI OR ChatGPT OR Claude)',
    '"AI has no memory" OR "AI memory" (frustrating OR useless OR annoying)',
    '"I hate how AI forgets" OR "AI resets every conversation"',
    '"wish AI could remember" OR "AI context problem"',
]

# ---------------------------------------------------------------------------
# Reply variants — rotate randomly so we never post identical text twice in a row
# ---------------------------------------------------------------------------

COMMENT_VARIANTS = [
    "This is exactly why I built AIBrain — local memory that persists across sessions, any model, no cloud. pip install aibrain if you want to try it: myaibrain.org",
    "Same frustration drove me to build AIBrain. It gives any AI a persistent local memory that compounds over time — myaibrain.org",
    "AIBrain solves exactly this — runs local, persists across sessions, works with Claude/GPT/Ollama/anything. pip install aibrain",
    "Built something for this: AIBrain. Local memory, no cloud, follows you when you switch models. myaibrain.org — might be worth a look.",
    "This is the exact problem AIBrain addresses — persistent local memory for AI that doesn't reset each session. pip install aibrain / myaibrain.org",
]

# ---------------------------------------------------------------------------
# Credentials
# ---------------------------------------------------------------------------

def get_credentials() -> dict:
    """Pull Twitter credentials from env. Returns dict; missing keys left empty."""
    return {
        "api_key": os.environ.get("TWITTER_API_KEY", ""),
        "api_secret": os.environ.get("TWITTER_API_SECRET", ""),
        "access_token": os.environ.get("TWITTER_ACCESS_TOKEN", ""),
        "access_token_secret": os.environ.get("TWITTER_ACCESS_TOKEN_SECRET", ""),
    }


def check_credentials(creds: dict) -> list[str]:
    """Return list of missing credential names."""
    return [k for k, v in creds.items() if not v]


# ---------------------------------------------------------------------------
# Reply log — track what we've already replied to
# ---------------------------------------------------------------------------

def load_replied_ids() -> set[str]:
    """Load set of tweet IDs already replied to from JSONL log."""
    if not LOG_PATH.exists():
        return set()
    ids = set()
    for line in LOG_PATH.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            entry = json.loads(line)
            ids.add(str(entry["tweet_id"]))
        except (json.JSONDecodeError, KeyError):
            pass
    return ids


def log_reply(tweet_id: str, tweet_url: str, tweet_text: str,
               reply_text: str, reply_id: str) -> None:
    """Append a reply record to the JSONL log."""
    LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    entry = {
        "tweet_id": str(tweet_id),
        "tweet_url": tweet_url,
        "tweet_text": tweet_text,
        "reply_text": reply_text,
        "reply_id": str(reply_id),
        "timestamp": datetime.datetime.utcnow().isoformat() + "Z",
    }
    with LOG_PATH.open("a", encoding="utf-8") as f:
        f.write(json.dumps(entry) + "\n")


# ---------------------------------------------------------------------------
# Twitter client setup
# ---------------------------------------------------------------------------

def build_client(creds: dict) -> tweepy.Client:
    """Build a tweepy v2 Client with OAuth 1.0a credentials."""
    return tweepy.Client(
        consumer_key=creds["api_key"],
        consumer_secret=creds["api_secret"],
        access_token=creds["access_token"],
        access_token_secret=creds["access_token_secret"],
        wait_on_rate_limit=False,
    )


# ---------------------------------------------------------------------------
# Core logic
# ---------------------------------------------------------------------------

def pick_variant(last_variant: str | None) -> str:
    """Pick a random variant, avoiding repeating the immediately previous one."""
    choices = [v for v in COMMENT_VARIANTS if v != last_variant]
    return random.choice(choices)


def search_tweets(client: tweepy.Client, query: str, max_results: int = 50) -> list:
    """
    Search recent tweets. Returns list of tweet objects with public_metrics.
    max_results clamped to 10-100 (Twitter API v2 constraint).
    """
    max_results = max(10, min(100, max_results))
    # Exclude retweets and replies; require English; fetch public_metrics for like count
    full_query = f"({query}) -is:retweet -is:reply lang:en"
    try:
        response = client.search_recent_tweets(
            query=full_query,
            max_results=max_results,
            tweet_fields=["public_metrics", "author_id", "created_at"],
            expansions=["author_id"],
            user_fields=["username"],
        )
    except tweepy.errors.TooManyRequests:
        print("[WARN] Rate limit hit during search. Stopping this run.")
        return []
    except tweepy.errors.TwitterServerError as e:
        print(f"[WARN] Twitter server error during search: {e}")
        return []
    except tweepy.errors.HTTPException as e:
        err_str = str(e)
        # 401/402 on search = Free tier. Free tier only supports posting, not searching.
        # Basic tier ($100/mo) required: https://developer.twitter.com/en/portal/products
        if "401" in err_str or "402" in err_str or "Payment Required" in err_str or "credits" in err_str.lower() or "Unauthorized" in err_str:
            print("[WARN] search_recent_tweets is not available on Twitter Free tier.")
            print("       Upgrade to Basic ($100/mo) at: https://developer.twitter.com/en/portal/products")
            print("       Auth is valid — posting (create_tweet) will work when you have candidates.")
        else:
            print(f"[WARN] Search failed (HTTP {e}): {e}")
        return []
    except Exception as e:
        print(f"[WARN] Search failed: {e}")
        return []

    if not response.data:
        return []

    # Build username lookup from includes
    users = {}
    if response.includes and "users" in response.includes:
        for u in response.includes["users"]:
            users[u.id] = u.username

    # Attach username to each tweet for convenience
    tweets = []
    for tweet in response.data:
        tweet._username = users.get(tweet.author_id, "unknown")
        tweets.append(tweet)

    return tweets


def should_skip(tweet, replied_ids: set[str]) -> tuple[bool, str]:
    """Return (skip, reason) for a tweet."""
    tid = str(tweet.id)

    if tid in replied_ids:
        return True, "already replied"

    username = getattr(tweet, "_username", "")
    if username.lower() == "sindecker":
        return True, "own account"

    likes = 0
    if tweet.public_metrics:
        likes = tweet.public_metrics.get("like_count", 0)
    if likes < 5:
        return True, f"too few likes ({likes})"

    return False, ""


def run(dry_run: bool, limit: int, query_index: int | None) -> None:
    """Main execution loop."""
    creds = get_credentials()
    missing = check_credentials(creds)
    if missing:
        print(f"[ERROR] Missing Twitter credentials: {', '.join(missing)}")
        print("        Set them in C:/Users/sinde/.decker_env")
        sys.exit(1)

    client = build_client(creds)
    replied_ids = load_replied_ids()

    # Determine which queries to run
    if query_index is not None:
        if not (0 <= query_index < len(SEARCH_QUERIES)):
            print(f"[ERROR] --query-index must be 0-{len(SEARCH_QUERIES)-1}")
            sys.exit(1)
        queries_to_run = [SEARCH_QUERIES[query_index]]
        print(f"[INFO] Using query index {query_index}: {queries_to_run[0][:60]}...")
    else:
        queries_to_run = list(SEARCH_QUERIES)
        print(f"[INFO] Rotating through all {len(queries_to_run)} search queries")

    print(f"[INFO] Mode: {'DRY RUN' if dry_run else 'LIVE'} | Limit: {limit} replies")
    print(f"[INFO] Already replied to {len(replied_ids)} tweets")
    print()

    replies_sent = 0
    last_variant: str | None = None

    for query in queries_to_run:
        if replies_sent >= limit:
            break

        print(f"[SEARCH] {query[:70]}...")
        tweets = search_tweets(client, query, max_results=50)
        print(f"         Found {len(tweets)} tweets")

        for tweet in tweets:
            if replies_sent >= limit:
                break

            skip, reason = should_skip(tweet, replied_ids)
            if skip:
                continue

            likes = tweet.public_metrics.get("like_count", 0) if tweet.public_metrics else 0
            tweet_url = f"https://twitter.com/{tweet._username}/status/{tweet.id}"
            reply_text = pick_variant(last_variant)

            print(f"\n[CANDIDATE] @{tweet._username} ({likes} likes)")
            print(f"  URL:  {tweet_url}")
            print(f"  TEXT: {tweet.text[:120]}{'...' if len(tweet.text) > 120 else ''}")
            print(f"  REPLY: {reply_text}")

            if dry_run:
                print("  [DRY RUN] Would post reply — skipping actual post")
                replied_ids.add(str(tweet.id))  # prevent double-print within same run
                last_variant = reply_text
                replies_sent += 1
                continue

            # Live post
            try:
                response = client.create_tweet(
                    text=reply_text,
                    in_reply_to_tweet_id=tweet.id,
                )
                reply_id = response.data["id"]
                print(f"  [POSTED] reply_id={reply_id}")

                log_reply(
                    tweet_id=tweet.id,
                    tweet_url=tweet_url,
                    tweet_text=tweet.text,
                    reply_text=reply_text,
                    reply_id=reply_id,
                )
                replied_ids.add(str(tweet.id))
                last_variant = reply_text
                replies_sent += 1

                if replies_sent < limit:
                    print(f"  [WAIT] Sleeping 30s before next reply...")
                    time.sleep(30)

            except tweepy.errors.TooManyRequests:
                print("  [WARN] Rate limit hit while posting. Stopping this run.")
                return
            except tweepy.errors.Forbidden as e:
                print(f"  [WARN] Forbidden (duplicate tweet or restricted account?): {e}")
                # Don't add to replied_ids — didn't actually post
            except tweepy.errors.TwitterServerError as e:
                print(f"  [WARN] Twitter server error: {e}")
            except Exception as e:
                print(f"  [ERROR] Unexpected error posting reply: {e}")

    print(f"\n[DONE] Replies {'would have been ' if dry_run else ''}sent: {replies_sent}/{limit}")
    if not dry_run and replies_sent > 0:
        print(f"[LOG] Appended to {LOG_PATH}")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Search Twitter/X for AI memory frustration posts, reply with AIBrain."
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="Print what would be posted, don't actually post",
    )
    parser.add_argument(
        "--limit", type=int, default=10, metavar="N",
        help="Max replies per run (default: 10)",
    )
    parser.add_argument(
        "--query-index", type=int, default=None, metavar="N",
        help="Which search query to use (0-4). Default: rotate through all.",
    )
    args = parser.parse_args()
    run(dry_run=args.dry_run, limit=args.limit, query_index=args.query_index)


if __name__ == "__main__":
    workflow_execute("pain_post_commenter", main)
