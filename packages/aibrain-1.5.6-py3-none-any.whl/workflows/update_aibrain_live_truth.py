"""Regenerate aibrain_live_truth_v1_4_0.md from live source counts.

Queries the live repo for current truth values and rewrites the Version and
Code-surface-counts tables in the canonical truth doc. Preserves all other
prose (hard rule, release notes, related memories, etc.) by touching ONLY the
specific table rows we control.

Counts collected:
    - version: from pyproject.toml
    - workflows: `aibrain/workflows/*.py` excluding `__init__.py`
    - workflow registry entries: from aibrain.core.workflow_runner.WORKFLOW_REGISTRY
    - tests: `pytest --collect-only` count
    - test files: `tests/test_*.py`
    - dashboard pages: `dashboard/src/app/**/page.tsx`
    - skills (recursive): `.md` + `.py` under `skills/`
    - skills (flat): direct children of `skills/`
    - memories: SELECT COUNT(*) FROM memories in aibrain.db

Design:
    * Idempotent — re-running with no source changes leaves the doc byte-
      identical except for the Verified date.
    * Smallest-diff — only lines matching known table row fields are rewritten
      in place; prose lines pass through untouched.
    * Harnessable — exposes `run()` for aibrain.core.workflow_runner.
"""
from __future__ import annotations

import os
import re
import sqlite3
import subprocess
import sys
from datetime import datetime
from pathlib import Path

# P0-1 harness wire — workflow_execute is the canonical entry point that
# routes execution through task classification, model routing, authority
# check, quality eval, and audit trail. Pre-commit lint requires this
# import in every workflow file even if the run() function is called
# directly via the workflow_runner registry.
from aibrain.core.workflow_base import workflow_execute

REPO_ROOT = Path(__file__).resolve().parents[1]
TRUTH_DOC = Path(
    r"C:\Users\sinde\decker_system\00_meta\aibrain_live_truth_v1_4_0.md"
)


def _count_files(glob_root: Path, pattern: str, exclude_init: bool = False) -> int:
    if not glob_root.exists():
        return 0
    files = list(glob_root.glob(pattern))
    if exclude_init:
        files = [f for f in files if f.name != "__init__.py"]
    return len(files)


def _read_version() -> str:
    pyproject = REPO_ROOT / "pyproject.toml"
    if not pyproject.exists():
        return ""
    text = pyproject.read_text(encoding="utf-8")
    m = re.search(r'^version\s*=\s*"([^"]+)"', text, re.MULTILINE)
    return f"v{m.group(1)}" if m else ""


def _count_registry_entries() -> int:
    try:
        from aibrain.core.workflow_runner import WORKFLOW_REGISTRY
        return len(WORKFLOW_REGISTRY)
    except Exception:
        return 0


def _count_pytest() -> int:
    """Run `pytest --collect-only -q` and parse the summary line."""
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pytest", "--collect-only", "-q", "tests"],
            cwd=str(REPO_ROOT),
            capture_output=True,
            text=True,
            timeout=180,
        )
        # pytest writes "N tests collected" or "N/M tests collected in X.Ys"
        m = re.search(r"(\d+)\s+tests?\s+collected", result.stdout)
        if m:
            return int(m.group(1))
        m = re.search(r"collected\s+(\d+)\s+item", result.stdout)
        if m:
            return int(m.group(1))
    except Exception:
        pass
    return 0


def _count_memories() -> int:
    try:
        from aibrain_db import get_db as _canonical_get_db
        conn = _canonical_get_db()
        row = conn.execute("SELECT COUNT(*) FROM memories").fetchone()
        return int(row[0]) if row else 0
    except Exception:
        return 0


def _count_dashboard_pages() -> int:
    dashboard = REPO_ROOT / "dashboard" / "src" / "app"
    if not dashboard.exists():
        return 0
    return len(list(dashboard.rglob("page.tsx")))


def _count_skills_recursive() -> int:
    skills = REPO_ROOT / "skills"
    if not skills.exists():
        return 0
    return sum(1 for p in skills.rglob("*") if p.is_file() and p.suffix in {".md", ".py"})


def _count_skills_flat() -> int:
    skills = REPO_ROOT / "skills"
    if not skills.exists():
        return 0
    return sum(1 for p in skills.iterdir() if p.is_dir() or (p.is_file() and p.suffix in {".md", ".py"}))


def collect_truth() -> dict[str, str]:
    """Return the live-truth field -> value dict to write into the doc."""
    version = _read_version()
    # Canonical location is top-level workflows/ (verified 2026-04-12).
    # aibrain/workflows does not exist in this repo.
    workflows = _count_files(REPO_ROOT / "workflows", "*.py", exclude_init=True)
    registry_count = _count_registry_entries()
    tests = _count_pytest()
    test_files = _count_files(REPO_ROOT / "tests", "test_*.py")
    dashboard = _count_dashboard_pages()
    skills_recursive = _count_skills_recursive()
    skills_flat = _count_skills_flat()
    memories = _count_memories()

    truth: dict[str, str] = {}
    if version:
        truth["Latest shipped version"] = f"**{version}**"
    if workflows:
        truth["**Workflows**"] = f"**{workflows}**"
    if registry_count:
        truth["**Workflow registry entries**"] = f"**{registry_count}**"
    if tests:
        truth["**Tests**"] = f"**{tests:,}**"
    if test_files:
        truth["**Test files**"] = f"**{test_files}**"
    if dashboard:
        truth["**Dashboard pages**"] = f"**{dashboard}**"
    if skills_recursive:
        truth["**Skills (recursive)**"] = f"**{skills_recursive}**"
    if skills_flat:
        truth["**Skills (flat)**"] = f"**{skills_flat}**"
    if memories:
        truth["**Memories in live DB**"] = f"**{memories:,}**"
    return truth


def _rewrite_tables(markdown: str, truth: dict[str, str]) -> str:
    """Rewrite the second cell of table rows whose first cell matches a truth key.

    Preserves the third cell (source of truth) verbatim. Header rows and
    separators pass through untouched. First-cell match is literal string
    compare on the raw cell content (including ** markdown).
    """
    out_lines: list[str] = []
    for line in markdown.splitlines():
        stripped = line.strip()
        if stripped.startswith("|") and stripped.endswith("|") and not re.fullmatch(r"\|[\s\-:|]+\|", stripped):
            cells = [c.strip() for c in stripped.strip("|").split("|")]
            if len(cells) >= 2 and cells[0] in truth:
                new_val = truth[cells[0]]
                new_cells = [cells[0], new_val] + cells[2:]
                out_lines.append("| " + " | ".join(new_cells) + " |")
                continue
        out_lines.append(line)
    return "\n".join(out_lines) + ("\n" if markdown.endswith("\n") else "")


def _bump_verified_date(markdown: str) -> str:
    today = datetime.now().strftime("%Y-%m-%d")
    return re.sub(
        r"^\*\*Verified:\*\*\s+\d{4}-\d{2}-\d{2}",
        f"**Verified:** {today}",
        markdown,
        count=1,
        flags=re.MULTILINE,
    )


def run() -> dict:
    """Harness entry point. Returns a structured result dict."""
    if not TRUTH_DOC.exists():
        return {"success": False, "error": f"truth doc missing: {TRUTH_DOC}"}

    original = TRUTH_DOC.read_text(encoding="utf-8")
    truth = collect_truth()
    if not truth:
        return {"success": False, "error": "no truth values collected — all counters returned 0"}

    rewritten = _rewrite_tables(original, truth)
    rewritten = _bump_verified_date(rewritten)
    TRUTH_DOC.write_text(rewritten, encoding="utf-8")

    return {
        "success": True,
        "truth_doc": str(TRUTH_DOC),
        "values": {k.strip("*"): v.strip("*") for k, v in truth.items()},
        "changed": rewritten != original,
    }


if __name__ == "__main__":
    # Route through the harness so the run is logged + quality-evaluated +
    # cost-tracked + auth-checked, same shape as every other workflow.
    workflow_execute(
        workflow_name="update_aibrain_live_truth",
        action=run,
        task_type="deterministic",
        actor="neuro",
    )
