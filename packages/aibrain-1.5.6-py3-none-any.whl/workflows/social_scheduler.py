"""
social_scheduler.py — Schedule and dispatch social media posts.

Usage:
    python social_scheduler.py --check          # One-shot: post anything due now
    python social_scheduler.py --loop           # Continuous: check every hour
    python social_scheduler.py --list           # Show upcoming scheduled posts
    python social_scheduler.py --add --platform linkedin --time "2026-03-20T09:00" --content post.md

Reads from: publishing_calendar.json (same directory)
Tracks posted items in: posted_log.json (same directory)
Dispatches to: social_poster.py
"""

import argparse
import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone, timedelta
from pathlib import Path

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

SCRIPT_DIR = Path(__file__).parent
SOCIAL_DIR = Path(r"C:\Users\sinde\decker_system\12_social")
CALENDAR_PATH = SOCIAL_DIR / "publishing_calendar.json"
POSTED_LOG_PATH = SCRIPT_DIR / "posted_log.json"
SOCIAL_POSTER = SCRIPT_DIR / "social_poster.py"
PYTHON = sys.executable

CHECK_INTERVAL = 3600  # 1 hour in seconds
WINDOW_SECONDS = 3600  # Posts due within 1 hour are eligible


# ---------------------------------------------------------------------------
# Calendar management
# ---------------------------------------------------------------------------

def load_calendar() -> list[dict]:
    """Load the publishing calendar."""
    if not CALENDAR_PATH.exists():
        return []
    return json.loads(CALENDAR_PATH.read_text(encoding="utf-8"))


def save_calendar(entries: list[dict]):
    """Save the publishing calendar."""
    CALENDAR_PATH.write_text(json.dumps(entries, indent=2, default=str), encoding="utf-8")


def load_posted_log() -> list[str]:
    """Load IDs of already-posted items."""
    if not POSTED_LOG_PATH.exists():
        return []
    return json.loads(POSTED_LOG_PATH.read_text(encoding="utf-8"))


def save_posted_log(posted: list[str]):
    """Save the posted items log."""
    POSTED_LOG_PATH.write_text(json.dumps(posted, indent=2), encoding="utf-8")


def generate_post_id(entry: dict) -> str:
    """Generate a unique ID for a calendar entry."""
    # Support both calendar schemas: "id" field or constructed ID
    if "id" in entry:
        return entry["id"]
    platform = entry.get("platform", "unknown")
    scheduled = entry.get("scheduled_time", entry.get("scheduled", "no-time"))
    title = entry.get("title", entry.get("book", "untitled"))[:30]
    return f"{platform}:{scheduled}:{title}"


# ---------------------------------------------------------------------------
# Calendar entry format
# ---------------------------------------------------------------------------
# Each entry in publishing_calendar.json:
# {
#     "platform": "linkedin|twitter|mastodon",
#     "scheduled_time": "2026-03-20T09:00:00",   (local time, ISO 8601)
#     "title": "Short reference title",
#     "content_file": "path/to/post.md",          (optional — file with post text)
#     "text": "Inline post text",                 (optional — used if no content_file)
#     "thread": false,                            (optional — Twitter thread mode)
#     "telegram_notify": true                     (optional — send to Telegram)
# }


# ---------------------------------------------------------------------------
# Scheduling logic
# ---------------------------------------------------------------------------

def get_due_posts(calendar: list[dict], posted: list[str]) -> list[dict]:
    """Return posts that are due (within window) and not yet posted."""
    now = datetime.now(timezone.utc)
    due = []

    for entry in calendar:
        post_id = generate_post_id(entry)
        if post_id in posted:
            continue

        scheduled_str = entry.get("scheduled_time", entry.get("scheduled", ""))
        if not scheduled_str:
            continue

        try:
            scheduled = datetime.fromisoformat(scheduled_str)
            # Make naive datetimes UTC-aware for comparison
            if scheduled.tzinfo is None:
                scheduled = scheduled.replace(tzinfo=timezone.utc)
        except ValueError:
            print(f"[WARN] Invalid time format: {scheduled_str}")
            continue

        # Due if scheduled time is in the past or within the window
        diff = (now - scheduled).total_seconds()
        if -WINDOW_SECONDS <= diff:
            # It's due (either past due or within window)
            due.append(entry)

    return due


def dispatch_post(entry: dict) -> bool:
    """Dispatch a post to social_poster.py."""
    if not SOCIAL_POSTER.exists():
        print(f"[ERROR] social_poster.py not found at {SOCIAL_POSTER}")
        return False

    platform = entry.get("platform", "")
    content_file = entry.get("content_file", entry.get("content_ref", ""))
    text = entry.get("text", "")
    thread = entry.get("thread", False)
    telegram = entry.get("telegram_notify", False)

    # Skip manual posts (e.g., Reddit) and draft-only posts
    if entry.get("manual", False):
        print(f"[SKIP] Manual post: {entry.get('id', 'unknown')} — requires manual posting")
        return False
    if entry.get("status", "") == "draft":
        print(f"[SKIP] Draft post: {entry.get('id', 'unknown')} — not approved yet")
        return False

    cmd = [PYTHON, str(SOCIAL_POSTER), "--platform", platform]

    # Resolve content_ref (e.g., "launch_week_7day_posts.md#day-1-linkedin")
    if content_file and "#" in content_file:
        # content_ref points to a section in a markdown file in 12_social/
        ref_path = SOCIAL_DIR / content_file.split("#")[0]
        if ref_path.exists():
            cmd.extend(["--content", str(ref_path)])
        elif text:
            cmd.extend(["--text", text])
    elif content_file and Path(content_file).exists():
        cmd.extend(["--content", content_file])
    elif text:
        cmd.extend(["--text", text])
    else:
        print(f"[ERROR] No content for post: {entry.get('title', 'untitled')}")
        return False

    if thread and platform == "twitter":
        cmd.append("--thread")

    if telegram:
        cmd.append("--telegram")

    title = entry.get("title", "untitled")
    print(f"[DISPATCH] {platform}: {title}")

    result = subprocess.run(cmd, capture_output=True, text=True)
    print(result.stdout)
    if result.stderr:
        print(result.stderr)

    return result.returncode == 0


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

def cmd_check():
    """One-shot: check for due posts and dispatch them."""
    calendar = load_calendar()
    posted = load_posted_log()

    if not calendar:
        print("[INFO] Publishing calendar is empty.")
        if not CALENDAR_PATH.exists():
            print(f"       Create: {CALENDAR_PATH}")
            # Write example
            example = [
                {
                    "platform": "linkedin",
                    "scheduled_time": "2026-03-20T09:00:00",
                    "title": "Example post",
                    "text": "This is an example scheduled post.",
                    "telegram_notify": True,
                },
            ]
            save_calendar(example)
            print(f"       Example calendar written to {CALENDAR_PATH}")
        return

    due = get_due_posts(calendar, posted)

    if not due:
        print(f"[INFO] No posts due. Next check in {CHECK_INTERVAL // 60} minutes.")
        print(f"       Calendar has {len(calendar)} entries, {len(posted)} already posted.")
        return

    print(f"[INFO] {len(due)} post(s) due.")
    for entry in due:
        success = dispatch_post(entry)
        if success:
            post_id = generate_post_id(entry)
            posted.append(post_id)
            save_posted_log(posted)
            print(f"[OK] Posted: {entry.get('title', 'untitled')}")
        else:
            print(f"[FAIL] Could not post: {entry.get('title', 'untitled')}")


def cmd_loop():
    """Continuous loop: check every hour."""
    print(f"[LOOP] Social scheduler running. Checking every {CHECK_INTERVAL // 60} minutes.")
    print("       Press Ctrl+C to stop.\n")

    while True:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")
        print(f"--- Check at {timestamp} ---")
        cmd_check()
        print(f"--- Next check in {CHECK_INTERVAL // 60} minutes ---\n")
        time.sleep(CHECK_INTERVAL)


def cmd_list():
    """List upcoming scheduled posts."""
    calendar = load_calendar()
    posted = load_posted_log()

    if not calendar:
        print("[INFO] Publishing calendar is empty.")
        return

    now = datetime.now(timezone.utc)
    print(f"\n{'Status':<10} {'Platform':<12} {'Scheduled':<20} {'Title'}")
    print("-" * 70)

    for entry in sorted(calendar, key=lambda e: e.get("scheduled_time", "")):
        post_id = generate_post_id(entry)
        scheduled_str = entry.get("scheduled_time", entry.get("scheduled", "N/A"))
        platform = entry.get("platform", "???")
        title = entry.get("title", entry.get("book", "untitled"))

        if post_id in posted:
            status = "POSTED"
        else:
            try:
                scheduled = datetime.fromisoformat(scheduled_str)
                if scheduled.tzinfo is None:
                    scheduled = scheduled.replace(tzinfo=timezone.utc)
                if scheduled < now:
                    status = "OVERDUE"
                else:
                    status = "PENDING"
            except ValueError:
                status = "INVALID"

        print(f"{status:<10} {platform:<12} {scheduled_str:<20} {title}")

    print()


def cmd_add(platform: str, scheduled_time: str, content: str = None,
            text: str = None, title: str = None, thread: bool = False,
            telegram: bool = True):
    """Add a new entry to the publishing calendar."""
    calendar = load_calendar()

    entry = {
        "platform": platform,
        "scheduled_time": scheduled_time,
        "title": title or f"{platform} post at {scheduled_time}",
        "telegram_notify": telegram,
    }

    if content:
        entry["content_file"] = content
    elif text:
        entry["text"] = text
    else:
        print("[ERROR] --content or --text is required with --add.")
        sys.exit(1)

    if thread:
        entry["thread"] = True

    calendar.append(entry)
    save_calendar(calendar)
    print(f"[OK] Added to calendar: {entry['title']}")
    print(f"     Scheduled: {scheduled_time} on {platform}")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Social media post scheduler.")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--check", action="store_true",
                       help="One-shot: check and post anything due.")
    group.add_argument("--loop", action="store_true",
                       help="Continuous: check every hour.")
    group.add_argument("--list", action="store_true",
                       help="List all scheduled posts.")
    group.add_argument("--add", action="store_true",
                       help="Add a new scheduled post.")

    parser.add_argument("--platform", choices=["linkedin", "twitter", "mastodon"],
                        help="Platform (required with --add).")
    parser.add_argument("--time", metavar="DATETIME",
                        help="Scheduled time ISO 8601 (required with --add).")
    parser.add_argument("--content", metavar="FILE.md",
                        help="Post content file (used with --add).")
    parser.add_argument("--text", help="Inline post text (used with --add).")
    parser.add_argument("--title", help="Reference title (used with --add).")
    parser.add_argument("--thread", action="store_true",
                        help="Twitter thread mode (used with --add).")
    parser.add_argument("--no-telegram", action="store_true",
                        help="Skip Telegram notification (used with --add).")

    args = parser.parse_args()

    if args.check:
        cmd_check()
    elif args.loop:
        try:
            cmd_loop()
        except KeyboardInterrupt:
            print("\n[STOP] Scheduler stopped.")
    elif args.list:
        cmd_list()
    elif args.add:
        if not args.platform or not args.time:
            print("[ERROR] --add requires --platform and --time.")
            sys.exit(1)
        cmd_add(
            platform=args.platform,
            scheduled_time=args.time,
            content=args.content,
            text=args.text,
            title=args.title,
            thread=args.thread,
            telegram=not args.no_telegram,
        )


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name='social_scheduler',
        action=_workflow_entry,
        task_type='deterministic',
        actor='cli',
    )
