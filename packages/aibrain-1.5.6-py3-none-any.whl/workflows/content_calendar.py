#!/usr/bin/env python3
"""AIBrain Workflow: Content Calendar — manage social media posts for marketing AIBrain."""

import argparse
import datetime
import hashlib
import json
import os
import random
import sqlite3
import sys
import urllib.request
from pathlib import Path

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

# ---------------------------------------------------------------------------
# Config & DB helpers (self-contained — no external imports beyond stdlib)
# ---------------------------------------------------------------------------

from aibrain_db import AIBRAIN_ROOT, get_db
_cfg_path = AIBRAIN_ROOT / "config.json"
CONFIG = json.loads(_cfg_path.read_text()) if _cfg_path.exists() else {}
def _find_db():
    """Find best DB path, checking both new and legacy names."""
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    configured = CONFIG.get("db_path")
    if configured and Path(configured).exists():
        return configured
    mem_db = AIBRAIN_ROOT / "memory" / "memory.db"
    if mem_db.exists():
        return str(mem_db)
    return str(AIBRAIN_ROOT / "aibrain.db")

MEMORY_DB = CONFIG.get("db_path", _find_db())
STATE_KEY = "workflow_state:content_calendar"
API_BASE = os.environ.get("AIBRAIN_API", os.environ.get("AIBRAIN_API", "http://localhost:8001/api/agent"))


def log_activity(action, detail="", status="ok"):
    try:
        data = json.dumps({
            "action": action, "category": "comms",
            "detail": detail, "status": status,
        }).encode()
        req = urllib.request.Request(
            f"{API_BASE}/activity", data=data,
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass


PLATFORMS = ["linkedin", "x_twitter", "reddit", "youtube"]

# 20 workflows from registry.json
WORKFLOW_TOPICS = [
    "Daily Planner", "File Declutter", "Bookmark Organizer", "Job Search & Apply",
    "Interview Prep", "Content Calendar", "RSS Feed Digest", "Social Listener",
    "Daily Research Scanner", "arXiv Paper Tracker", "Price Watcher",
    "Expense Tracker", "Email Triage", "Contact Enricher", "Newsletter Digest",
    "GitHub Activity Digest", "Dependency Auditor", "Uptime Monitor",
    "Habit Tracker", "Weather Briefing",
]

# Template library: (category, template_format_string)
TEMPLATES = [
    # --- Per-workflow posts (placeholder {wf} filled from WORKFLOW_TOPICS) ---
    ("workflow", "AIBrain ships a {wf} workflow out of the box. Zero config, zero cost. Here's how it works:"),
    ("workflow", "I automated my {wf} with AIBrain in under 2 minutes. No API keys, no monthly fee."),
    ("workflow", "Most people pay $20/mo for {wf} tools. AIBrain does it free, locally, with full privacy."),
    # --- Meta content ---
    ("meta", "AIBrain: one-click setup, 20 free automations, runs on your machine. No cloud lock-in."),
    ("meta", "Your AI agent deserves a brain export. AIBrain memory graph lets you own every insight."),
    ("meta", "AIBrain memory graph: every automation learns, every insight persists. Your data never leaves your machine."),
    ("meta", "20 free automations. One install. No subscriptions. AIBrain is the personal agent OS you actually own."),
    ("meta", "One-click setup: install AIBrain, pick your workflows, run. That's it. No YAML, no Docker, no cloud account."),
    # --- Comparison content ---
    ("comparison", "AIBrain vs AutoGPT: one runs 20 workflows out of the box, the other needs a weekend of setup. Guess which is which."),
    ("comparison", "Why I stopped paying for n8n: AIBrain runs locally, costs nothing, and handles the same automations."),
    ("comparison", "Zapier charges per task. AIBrain charges nothing. Here's what 20 free workflows look like."),
    ("comparison", "AutoGPT needs Docker, OpenAI keys, and patience. AIBrain needs one command."),
    # --- Tutorial content ---
    ("tutorial", "How to set up email triage in 60 seconds with AIBrain [thread]"),
    ("tutorial", "Tutorial: build a daily research scanner with AIBrain — no code, no API keys."),
    ("tutorial", "Step by step: price tracking with AIBrain. Free alerts, local data, zero subscriptions."),
    ("tutorial", "How to get a daily weather briefing with outfit tips — AIBrain setup in 30 seconds."),
]


def get_db():
    db = get_db()
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    return db


def load_state():
    try:
        db = get_db()
        row = db.execute(
            "SELECT content FROM memories WHERE name=? AND active=1", (STATE_KEY,)
        ).fetchone()
        db.close()
        return json.loads(row["content"]) if row else {"queue": [], "posted": []}
    except Exception:
        return {"queue": [], "posted": []}


def save_state(state):
    db = get_db()
    now = datetime.datetime.now().isoformat()
    existing = db.execute(
        "SELECT id FROM memories WHERE name=? AND active=1", (STATE_KEY,)
    ).fetchone()
    blob = json.dumps(state)
    if existing:
        db.execute("UPDATE memories SET content=?, updated=? WHERE id=?",
                   (blob, now, existing["id"]))
    else:
        db.execute(
            "INSERT INTO memories (name,type,tags,content,created,updated,active) VALUES (?,?,?,?,?,?,1)",
            (STATE_KEY, "reference", "workflow,content_calendar", blob, now, now),
        )
    db.commit()
    db.close()


def post_id(text, platform):
    return hashlib.md5(f"{platform}:{text}".encode()).hexdigest()[:10]


def generate_posts(count=5):
    """Generate `count` new post ideas from templates, avoiding duplicates."""
    state = load_state()
    existing_ids = {p["id"] for p in state["queue"]} | {p["id"] for p in state["posted"]}
    new_posts = []
    candidates = []

    # Expand workflow templates
    for cat, tpl in TEMPLATES:
        if cat == "workflow":
            for wf in WORKFLOW_TOPICS:
                candidates.append((cat, tpl.format(wf=wf)))
        else:
            candidates.append((cat, tpl))

    random.shuffle(candidates)
    now = datetime.datetime.now()

    for cat, text in candidates:
        if len(new_posts) >= count:
            break
        platform = random.choice(PLATFORMS)
        pid = post_id(text, platform)
        if pid in existing_ids:
            continue
        scheduled = (now + datetime.timedelta(days=len(new_posts) + 1)).strftime("%Y-%m-%d")
        new_posts.append({
            "id": pid,
            "category": cat,
            "platform": platform,
            "text": text,
            "scheduled": scheduled,
            "status": "queued",
        })
        existing_ids.add(pid)

    state["queue"].extend(new_posts)
    return state, new_posts


def show_queue(state, limit=20):
    queued = [p for p in state["queue"] if p["status"] == "queued"]
    queued.sort(key=lambda p: p["scheduled"])
    if not queued:
        print("Queue is empty. Run --generate to create new post ideas.")
        return
    print(f"CONTENT QUEUE — {len(queued)} posts\n{'=' * 60}")
    for p in queued[:limit]:
        print(f"  [{p['id']}] {p['scheduled']}  {p['platform']:<12} [{p['category']}]")
        print(f"           {p['text'][:80]}{'...' if len(p['text']) > 80 else ''}")
        print()


def show_next(state):
    queued = [p for p in state["queue"] if p["status"] == "queued"]
    queued.sort(key=lambda p: p["scheduled"])
    if not queued:
        print("No posts in queue.")
        return
    p = queued[0]
    print("NEXT SCHEDULED POST")
    print("=" * 60)
    print(f"  ID:        {p['id']}")
    print(f"  Date:      {p['scheduled']}")
    print(f"  Platform:  {p['platform']}")
    print(f"  Category:  {p['category']}")
    print(f"  Text:\n    {p['text']}")
    print()
    posted_count = len(state["posted"])
    remaining = len(queued)
    print(f"Stats: {posted_count} posted, {remaining} queued")


def show_stats(state):
    posted = len(state["posted"])
    queued = len([p for p in state["queue"] if p["status"] == "queued"])
    by_platform = {}
    for p in state["posted"]:
        by_platform[p["platform"]] = by_platform.get(p["platform"], 0) + 1
    print(f"CONTENT CALENDAR STATS\n{'=' * 40}")
    print(f"  Total posted:  {posted}")
    print(f"  Queued:        {queued}")
    if by_platform:
        print("  By platform:")
        for plat, cnt in sorted(by_platform.items()):
            print(f"    {plat:<12} {cnt}")


def main():
    parser = argparse.ArgumentParser(description="AIBrain Content Calendar")
    parser.add_argument("--dry-run", action="store_true", help="Preview without saving to DB")
    parser.add_argument("--generate", type=int, nargs="?", const=5, metavar="N",
                        help="Generate N new post ideas (default 5)")
    parser.add_argument("--list", action="store_true", help="Show queued posts")
    parser.add_argument("--next", action="store_true", help="Show next scheduled post")
    parser.add_argument("--stats", action="store_true", help="Show posting statistics")
    parser.add_argument("--mark-posted", metavar="ID", help="Mark a post as published")
    args = parser.parse_args()

    if not any([args.generate, args.list, args.next, args.stats, args.mark_posted]):
        parser.print_help()
        return

    if args.generate:
        state, new_posts = generate_posts(count=args.generate)
        print(f"Generated {len(new_posts)} new post ideas:\n")
        for p in new_posts:
            print(f"  [{p['id']}] {p['scheduled']}  {p['platform']:<12} [{p['category']}]")
            print(f"           {p['text'][:80]}{'...' if len(p['text']) > 80 else ''}")
            print()
        if not args.dry_run:
            save_state(state)
            print(f"Saved to memory DB. Queue now has {len([p for p in state['queue'] if p['status'] == 'queued'])} posts.")
        else:
            print("[dry-run] Not saved.")

    elif args.list:
        show_queue(load_state())

    elif args.next:
        show_next(load_state())

    elif args.stats:
        state = load_state()
        show_stats(state)
        queued = len([p for p in state["queue"] if p["status"] == "queued"])
        log_activity("content_calendar", f"{len(state['posted'])} posted, {queued} queued")

    elif args.mark_posted:
        state = load_state()
        target = args.mark_posted
        found = False
        for i, p in enumerate(state["queue"]):
            if p["id"] == target:
                p["status"] = "posted"
                p["posted_at"] = datetime.datetime.now().isoformat()
                state["posted"].append(p)
                state["queue"].pop(i)
                found = True
                break
        if not found:
            print(f"Post {target} not found in queue.")
            sys.exit(1)
        if not args.dry_run:
            save_state(state)
        print(f"Marked {target} as posted. {'[dry-run]' if args.dry_run else 'Saved.'}")


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name='content_calendar',
        action=_workflow_entry,
        task_type='judgment',
        actor='cli',
    )
