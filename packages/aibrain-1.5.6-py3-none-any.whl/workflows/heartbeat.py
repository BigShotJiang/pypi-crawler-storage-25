"""
Agent Heartbeat — lightweight 30-minute pulse that keeps the system healthy.

Checks pending approvals, workflow health, memory stats, disk/DB health.
Emits a DomainEvent to the pattern bus so cross-domain question generator
has fresh data. NOT a consolidation pass — completes in <5 seconds.

Usage:
    python heartbeat.py              # quiet run, logs to activity table
    python heartbeat.py --dry-run    # print status, don't log or notify
    python heartbeat.py --verbose    # detailed output
"""

import argparse
import json
import os
import shutil
import sqlite3
import sys
import threading
import time
import urllib.request
import urllib.error
import uuid
from datetime import datetime, timezone, timedelta
from pathlib import Path

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

# --- Config ---

SCRIPT_DIR = Path(__file__).parent
from aibrain_db import AIBRAIN_ROOT, get_db
CONFIG_PATH = AIBRAIN_ROOT / "config.json"
_cfg = json.loads(CONFIG_PATH.read_text()) if CONFIG_PATH.exists() else {}


def _find_db():
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    configured = _cfg.get("db_path")
    if configured and Path(configured).exists():
        return configured
    mem_db = AIBRAIN_ROOT / "memory" / "memory.db"
    if mem_db.exists():
        return str(mem_db)
    return str(AIBRAIN_ROOT / "aibrain.db")


DB_PATH = Path(_cfg.get("db_path", _find_db()))
STATE_FILE = SCRIPT_DIR / "data" / "heartbeat_state.json"

def _load_decker_env() -> None:
    """Populate os.environ from ~/.decker_env if keys are missing."""
    _env = Path.home() / ".decker_env"
    if not _env.exists():
        return
    try:
        for _line in _env.read_text(encoding="utf-8", errors="replace").splitlines():
            _line = _line.strip()
            if _line and not _line.startswith("#") and "=" in _line:
                k, v = _line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip('"'))
    except Exception:
        pass


_load_decker_env()

TELEGRAM_BOT_TOKEN = (
    os.environ.get("TELEGRAM_TOKEN")
    or os.environ.get("TELEGRAM_BOT_TOKEN")
    or ""
)
TELEGRAM_CHAT_ID = os.environ.get("TELEGRAM_CHAT_ID", "")
MIN_NOTIFY_INTERVAL = 7200  # 2 hours between alerts
APPROVAL_THRESHOLD = 3      # notify if pending > this
DISK_THRESHOLD_GB = 1.0     # notify if free < this


def _load_config() -> dict:
    """Load config.json, falling back to env vars."""
    if CONFIG_PATH.exists():
        try:
            return json.loads(CONFIG_PATH.read_text())
        except (json.JSONDecodeError, OSError):
            pass
    return {}


def _load_state() -> dict:
    """Load last heartbeat state (notification timestamps, etc.)."""
    if STATE_FILE.exists():
        try:
            return json.loads(STATE_FILE.read_text())
        except (json.JSONDecodeError, OSError):
            pass
    return {}


def _save_state(state: dict):
    """Persist heartbeat state."""
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    STATE_FILE.write_text(json.dumps(state, indent=2))


def _db() -> sqlite3.Connection:
    """Open aibrain.db via canonical get_db() connection."""
    return get_db()


# --- Checks ---

def check_approvals(conn: sqlite3.Connection) -> int:
    """Count pending approvals."""
    cur = conn.execute("SELECT COUNT(*) FROM approvals WHERE status='pending'")
    return cur.fetchone()[0]


def check_stale_memories(conn: sqlite3.Connection) -> int:
    """Count memories with access_count=0 older than 30 days."""
    cutoff = (datetime.now(timezone.utc) - timedelta(days=30)).isoformat()
    cur = conn.execute(
        "SELECT COUNT(*) FROM memories WHERE access_count=0 AND created < ? AND active=1",
        (cutoff,),
    )
    return cur.fetchone()[0]


def check_scheduled_jobs(conn: sqlite3.Connection) -> tuple:
    """Return (active_count, failed_list). A job 'failed' if last_run is null
    but it should have run (enabled=1 and created > 24h ago)."""
    cur = conn.execute("SELECT name, last_run, created FROM scheduled_jobs WHERE enabled=1")
    rows = cur.fetchall()
    active = len(rows)
    cutoff = (datetime.now(timezone.utc) - timedelta(hours=24)).isoformat()
    failed = [r["name"] for r in rows if r["last_run"] is None and r["created"] < cutoff]
    return active, failed


def check_duplicate_workflow_states(conn: sqlite3.Connection) -> int:
    """Count duplicate workflow run states (same workflow_id + status in last 24h)."""
    try:
        cur = conn.execute(
            "SELECT COUNT(*) - COUNT(DISTINCT workflow_id || status) FROM workflow_runs "
            "WHERE started > datetime('now', '-1 day')"
        )
        return max(0, cur.fetchone()[0])
    except sqlite3.OperationalError:
        return 0


def check_disk() -> float:
    """Return free disk space in GB for the drive holding aibrain.db."""
    usage = shutil.disk_usage(str(AIBRAIN_ROOT))
    return round(usage.free / (1024 ** 3), 1)


def check_db_size() -> float:
    """Return DB file size in MB."""
    if DB_PATH.exists():
        return round(DB_PATH.stat().st_size / (1024 ** 2), 1)
    return 0.0


def check_last_backup() -> str:
    """Find most recent backup and return age string."""
    backup_dir = AIBRAIN_ROOT / "backups"
    if not backup_dir.exists():
        return "no backups"
    backups = sorted(backup_dir.glob("*.db*"), key=lambda p: p.stat().st_mtime, reverse=True)
    if not backups:
        return "no backups"
    age_min = (time.time() - backups[0].stat().st_mtime) / 60
    if age_min < 60:
        return f"{int(age_min)} minutes ago"
    elif age_min < 1440:
        return f"{int(age_min / 60)} hours ago"
    else:
        return f"{int(age_min / 1440)} days ago"


def check_memory_stats(conn: sqlite3.Connection) -> dict:
    """Lightweight memory stats."""
    cur = conn.execute("SELECT COUNT(*) FROM memories WHERE active=1")
    total = cur.fetchone()[0]
    cur = conn.execute("SELECT COUNT(*) FROM memories")
    total_all = cur.fetchone()[0]
    return {"active": total, "total": total_all, "archived": total_all - total}


# --- Pattern bus event ---

def emit_heartbeat_event(conn: sqlite3.Connection, status: dict):
    """Insert a heartbeat DomainEvent into pattern_bus_events."""
    conn.execute(
        "INSERT INTO pattern_bus_events (event_id, domain, source_agent, event_type, key, value, metadata) "
        "VALUES (?, 'system', ?, 'heartbeat', 'system_health', ?, ?)",
        (
            str(uuid.uuid4()),  # noqa:UUID4-SECURITY-TOKEN — event ID, not a secret
            os.getenv("AGENT_ID", "agent"),
            status.get("health", "unknown"),
            json.dumps(status),
        ),
    )
    conn.commit()


# --- Activity log ---

def log_activity(conn: sqlite3.Connection, status_line: str, health: str):
    """Write one-line status to activity table."""
    conn.execute(
        "INSERT INTO activity (agent, action, category, detail, status) VALUES (?, ?, ?, ?, ?)",
        (os.getenv("AGENT_ID", "agent"), "heartbeat", "system", status_line, health),
    )
    conn.commit()


# --- Telegram ---

def _send_telegram(message: str):
    """Send a Telegram message. Fire-and-forget via daemon thread."""
    token = TELEGRAM_BOT_TOKEN  # resolved at module load — tries TELEGRAM_TOKEN first
    if not token:
        cfg = _load_config()
        token = cfg.get("telegram_bot_token", "")
    if not token:
        return

    def _send():
        url = f"https://api.telegram.org/bot{token}/sendMessage"
        data = json.dumps({"chat_id": TELEGRAM_CHAT_ID, "text": message, "parse_mode": "HTML"}).encode()
        req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
        try:
            urllib.request.urlopen(req, timeout=10)
        except Exception:
            pass

    threading.Thread(target=_send, daemon=True).start()


def maybe_notify(state: dict, pending: int, failed_jobs: list, disk_gb: float) -> bool:
    """Send Telegram alert if thresholds exceeded and cooldown elapsed."""
    now = time.time()
    last = state.get("last_notify", 0)
    if now - last < MIN_NOTIFY_INTERVAL:
        return False

    reasons = []
    if pending > APPROVAL_THRESHOLD:
        reasons.append(f"Pending approvals: {pending}")
    if failed_jobs:
        reasons.append(f"Failed jobs: {', '.join(failed_jobs[:5])}")
    if disk_gb < DISK_THRESHOLD_GB:
        reasons.append(f"Disk critically low: {disk_gb} GB")

    if not reasons:
        return False

    msg = "<b>HEARTBEAT ALERT</b>\n" + "\n".join(f"- {r}" for r in reasons)
    _send_telegram(msg)
    state["last_notify"] = now
    return True


# --- Main ---

def run(dry_run: bool = False, verbose: bool = False) -> dict:
    """Execute one heartbeat cycle. Returns status dict."""
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    conn = _db()

    pending = check_approvals(conn)
    stale = check_stale_memories(conn)
    active_jobs, failed_jobs = check_scheduled_jobs(conn)
    dup_states = check_duplicate_workflow_states(conn)
    disk_gb = check_disk()
    db_mb = check_db_size()
    backup_age = check_last_backup()
    mem_stats = check_memory_stats(conn)

    health = "healthy"
    if failed_jobs or disk_gb < DISK_THRESHOLD_GB:
        health = "degraded"
    if disk_gb < 0.5:
        health = "critical"

    status = {
        "timestamp": now,
        "health": health,
        "pending_approvals": pending,
        "stale_memories": stale,
        "memory_active": mem_stats["active"],
        "memory_archived": mem_stats["archived"],
        "disk_free_gb": disk_gb,
        "db_size_mb": db_mb,
        "last_backup": backup_age,
        "scheduled_active": active_jobs,
        "failed_jobs": failed_jobs,
        "duplicate_states": dup_states,
    }

    status_line = (
        f"approvals={pending} stale={stale} jobs={active_jobs}/{len(failed_jobs)}fail "
        f"disk={disk_gb}GB db={db_mb}MB [{health}]"
    )

    if verbose:
        print(f"HEARTBEAT — {now}")
        print(f"  Pending approvals: {pending}")
        print(f"  Stale memories: {stale} (>30 days unused)")
        print(f"  Memories: {mem_stats['active']} active, {mem_stats['archived']} archived")
        print(f"  Last backup: {backup_age}")
        print(f"  Disk free: {disk_gb} GB")
        print(f"  DB size: {db_mb} MB")
        print(f"  Scheduled jobs: {active_jobs} active, {len(failed_jobs)} failed")
        if failed_jobs:
            print(f"    Failed: {', '.join(failed_jobs)}")
        if dup_states:
            print(f"  Duplicate workflow states: {dup_states}")
        print(f"  Status: {health}")

    if not dry_run:
        emit_heartbeat_event(conn, status)
        log_activity(conn, status_line, health)

        state = _load_state()
        notified = maybe_notify(state, pending, failed_jobs, disk_gb)
        if notified:
            state["last_notify"] = time.time()
        state["last_heartbeat"] = now
        state["last_health"] = health
        _save_state(state)

    conn.close()
    return status


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        parser = argparse.ArgumentParser(description="Agent Heartbeat — 30-minute system pulse")
        parser.add_argument("--dry-run", action="store_true", help="Print status without logging or notifying")
        parser.add_argument("--verbose", action="store_true", help="Detailed output")
        args = parser.parse_args()

        if args.dry_run:
            args.verbose = True

        result = run(dry_run=args.dry_run, verbose=args.verbose)

        if not args.verbose:
            print(f"[{result['health']}] heartbeat ok")
    workflow_execute(
        workflow_name='heartbeat',
        action=_workflow_entry,
        task_type='deterministic',
        actor='cli',
    )
