#!/usr/bin/env python3
"""AIBrain Workflow: Daily Planner — calendar + tasks → structured plan email."""

import argparse
import datetime
import json
import os
import smtplib
import sqlite3
import sys
import urllib.request
from email.mime.text import MIMEText
from pathlib import Path

from icalendar import Calendar
from dateutil import parser as dtparser

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

# ---------------------------------------------------------------------------
# Config & DB helpers
# ---------------------------------------------------------------------------

from aibrain_db import AIBRAIN_ROOT, get_db
_cfg_path = AIBRAIN_ROOT / "config.json"
CONFIG = json.loads(_cfg_path.read_text()) if _cfg_path.exists() else {}
def _find_db():
    """Find best DB path, checking both new and legacy names."""
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    configured = CONFIG.get("db_path")
    if configured and Path(configured).exists():
        return configured
    mem_db = AIBRAIN_ROOT / "memory" / "memory.db"
    if mem_db.exists():
        return str(mem_db)
    return str(AIBRAIN_ROOT / "aibrain.db")

MEMORY_DB = CONFIG.get("db_path", _find_db())


def get_db():
    db = get_db()
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    return db


def load_state(name):
    try:
        db = get_db()
        row = db.execute(
            "SELECT content FROM memories WHERE name=? AND active=1",
            (f"workflow_state:{name}",),
        ).fetchone()
        db.close()
        return json.loads(row["content"]) if row else {}
    except Exception:
        return {}


def save_state(name, state):
    db = get_db()
    try:
        now = datetime.datetime.now().isoformat()
        existing = db.execute(
            "SELECT id FROM memories WHERE name=? AND active=1",
            (f"workflow_state:{name}",),
        ).fetchone()
        if existing:
            db.execute("UPDATE memories SET content=?, updated=? WHERE id=?",
                       (json.dumps(state), now, existing["id"]))
        else:
            db.execute(
                "INSERT INTO memories (name,type,tags,content,created,updated,active) VALUES (?,?,?,?,?,?,1)",
                (f"workflow_state:{name}", "reference", "workflow,state",
                 json.dumps(state), now, now),
            )
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def send_email(to, subject, body, dry_run=False):
    if dry_run:
        print(f"TO: {to}\nSUBJECT: {subject}\n\n{body}")
        return
    agent_email = CONFIG.get("agent_email", "aibrain@localhost")
    agent_password = CONFIG.get("agent_email_password", CONFIG.get("email_app_password", ""))
    msg = MIMEText(body, "plain")
    msg["From"] = agent_email
    msg["To"] = to
    msg["Subject"] = subject
    with smtplib.SMTP_SSL(CONFIG.get("agent_smtp_host", CONFIG.get("email_smtp_host", "smtp.gmail.com")), 465) as s:
        s.login(agent_email, agent_password)
        s.send_message(msg)


# ---------------------------------------------------------------------------
# Calendar + Tasks
# ---------------------------------------------------------------------------

def fetch_calendar_events(ics_url, target_date):
    """Fetch ICS and extract events for target_date."""
    events = []
    try:
        with urllib.request.urlopen(ics_url, timeout=15) as resp:
            cal = Calendar.from_ical(resp.read())

        for component in cal.walk():
            if component.name != "VEVENT":
                continue
            dtstart = component.get("dtstart")
            if not dtstart:
                continue
            dt = dtstart.dt
            if isinstance(dt, datetime.datetime):
                event_date = dt.date()
            elif isinstance(dt, datetime.date):
                event_date = dt
            else:
                continue

            if event_date == target_date:
                summary = str(component.get("summary", "Untitled"))
                dtend = component.get("dtend")
                start_time = dt.strftime("%I:%M %p") if isinstance(dt, datetime.datetime) else "All day"
                end_time = ""
                if dtend and isinstance(dtend.dt, datetime.datetime):
                    end_time = dtend.dt.strftime("%I:%M %p")

                events.append({
                    "summary": summary,
                    "start": start_time,
                    "end": end_time,
                    "dt_sort": dt if isinstance(dt, datetime.datetime) else datetime.datetime.combine(dt, datetime.time()),
                })
    except Exception as e:
        print(f"Warning: calendar fetch failed: {e}", file=sys.stderr)

    events.sort(key=lambda x: x["dt_sort"])
    return events


def load_tasks():
    """Load todo/task items from memory DB."""
    tasks = []
    try:
        db = get_db()
        rows = db.execute(
            "SELECT name, content FROM memories WHERE active=1 AND "
            "(tags LIKE '%todo%' OR tags LIKE '%task%' OR tags LIKE '%priority%') "  # noqa:like-wildcard-injection — hardcoded static substrings, no user input
            "ORDER BY updated DESC LIMIT 20"
        ).fetchall()
        db.close()
        for row in rows:
            tasks.append({"name": row["name"], "content": row["content"][:200]})
    except Exception:
        pass
    return tasks


def load_priorities():
    """Load high-priority items from memory."""
    priorities = []
    try:
        db = get_db()
        rows = db.execute(
            "SELECT name, content FROM memories WHERE active=1 AND "
            "tags LIKE '%priority%' ORDER BY updated DESC LIMIT 5"  # noqa:like-wildcard-injection — hardcoded static substrings, no user input
        ).fetchall()
        db.close()
        for row in rows:
            priorities.append(row["name"])
    except Exception:
        pass
    return priorities


def fetch_daily_quote():
    """Fetch a motivational quote from ZenQuotes (free, no key needed)."""
    try:
        url = "https://zenquotes.io/api/random"
        req = urllib.request.Request(url, headers={"User-Agent": "AIBrain/1.0"})
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read().decode())
        if data and isinstance(data, list) and len(data) > 0:
            quote = data[0].get("q", "")
            author = data[0].get("a", "Unknown")
            if quote:
                return f'"{quote}" — {author}'
    except Exception as e:
        print(f"Warning: ZenQuotes fetch failed: {e}", file=sys.stderr)
    return None


def format_plan(events, tasks, priorities, target_date, quote=None):
    weekday = target_date.strftime("%A")
    lines = [
        f"DAILY PLAN — {weekday}, {target_date.strftime('%B %d, %Y')}",
        f"Generated: {datetime.datetime.now().strftime('%I:%M %p')}",
        "=" * 50,
        "",
    ]

    # Daily quote
    if quote:
        lines.append("QUOTE OF THE DAY")
        lines.append(f"  {quote}")
        lines.append("")

    # Calendar
    lines.append("SCHEDULE")
    if events:
        for ev in events:
            time_str = ev["start"]
            if ev["end"]:
                time_str += f" – {ev['end']}"
            lines.append(f"  {time_str:20s} {ev['summary']}")
    else:
        lines.append("  No calendar events today.")
    lines.append("")

    # Priorities
    if priorities:
        lines.append("TOP PRIORITIES")
        for i, p in enumerate(priorities, 1):
            lines.append(f"  {i}. {p}")
        lines.append("")

    # Tasks
    lines.append("TASK LIST")
    if tasks:
        for i, t in enumerate(tasks, 1):
            lines.append(f"  [ ] {t['name']}")
            if t["content"] and t["content"] != t["name"]:
                lines.append(f"      {t['content'][:100]}")
    else:
        lines.append("  No pending tasks in memory.")
    lines.append("")

    # Time blocks
    lines.append("SUGGESTED TIME BLOCKS")
    if events:
        lines.append("  (Based on gaps between calendar events)")
        # Find gaps
        for i in range(len(events)):
            if i + 1 < len(events):
                lines.append(f"  {events[i]['end'] or '?'} – {events[i+1]['start']}: Deep work / tasks")
    else:
        lines.append("  Open day — block time for top priorities")
    lines.append("")

    lines.append("—\nPowered by AIBrain + ZenQuotes.io")
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="AIBrain Daily Planner")
    parser.add_argument("--dry-run", action="store_true", help="Print instead of emailing")
    parser.add_argument("--date", help="Target date (YYYY-MM-DD), defaults to today")
    args = parser.parse_args()

    target_date = datetime.date.today()
    if args.date:
        target_date = datetime.date.fromisoformat(args.date)

    email_to = CONFIG.get("email_to", CONFIG.get("agent_email", ""))
    calendar_url = CONFIG.get("calendar_url", "")

    # Fetch data
    events = fetch_calendar_events(calendar_url, target_date) if calendar_url else []
    tasks = load_tasks()
    priorities = load_priorities()
    quote = fetch_daily_quote()

    if not events and not tasks and not priorities:
        quote_line = f"\n{quote}\n" if quote else ""
        plan = (
            f"DAILY PLAN — {target_date.strftime('%A %B %d, %Y')}\n\n"
            f"{quote_line}"
            "Nothing scheduled and no pending tasks.\n"
            "Consider: What's the one thing that would make today productive?\n\n"
            "—\nPowered by AIBrain + ZenQuotes.io"
        )
    else:
        plan = format_plan(events, tasks, priorities, target_date, quote=quote)

    if not email_to or args.dry_run:
        print(plan)
    else:
        weekday = target_date.strftime("%A")
        send_email(email_to, f"Daily Plan — {weekday}", plan)
        print(f"Sent daily plan to {email_to}")

    save_state("daily_planner", {"last_run": datetime.datetime.now().isoformat()})


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name='daily_planner',
        action=_workflow_entry,
        task_type='judgment',
        actor='cli',
    )
