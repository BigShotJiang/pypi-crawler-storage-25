"""
intel_agent_run.py — Scheduled competitive intelligence run using intel_agent V2 methodology.

Reads target configuration from ~/.aibrain/intel_targets.json:
[
  {"name": "competitor_name", "url": "https://...", "description": "what to research"}
]

For each target: runs a research sweep (web search + summarization using the intel_agent_v2
persona methodology from decker_system/02_subagents/intel_agent_v2.md), stores findings to
brain memories with type="competitive_intel", and sends a Telegram summary digest to Decker.

The actual deep research requires an intel_agent_v2 subagent spawn (Agent() tool in Claude Code).
This workflow handles: config loading, per-target stubs, memory storage, and Telegram dispatch.
For full research depth, this workflow should be invoked by Neuro who then spawns the subagent.

Usage:
    python -m aibrain.core.workflow_runner intel_agent_run
    aibrain intel run
    aibrain intel run --target OB1
"""

import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path

from aibrain.core.workflow_base import workflow_execute  # noqa:workflow-base — required by P0-1 lint

log = logging.getLogger("aibrain.intel_agent_run")

TARGETS_CONFIG = Path.home() / ".aibrain" / "intel_targets.json"

DEFAULT_TARGETS = [
    {
        "name": "OB1",
        "url": "https://ob1.ai",
        "description": "AI memory/context layer competitor — track feature releases, pricing, positioning",
    },
    {
        "name": "Mem0",
        "url": "https://mem0.ai",
        "description": "Agent memory layer — track API changes, enterprise tier, integrations",
    },
    {
        "name": "Zep",
        "url": "https://getzep.com",
        "description": "Long-term memory for AI assistants — track new capabilities, pricing changes",
    },
]


def load_targets(target_filter: str = None) -> list[dict]:
    """Load target list from config file or fall back to defaults."""
    targets = DEFAULT_TARGETS
    if TARGETS_CONFIG.exists():
        try:
            loaded = json.loads(TARGETS_CONFIG.read_text(encoding="utf-8"))
            if isinstance(loaded, list) and loaded:
                targets = loaded
                log.info("Loaded %d targets from %s", len(targets), TARGETS_CONFIG)
        except Exception as e:
            log.warning("Failed to load %s: %s — using defaults", TARGETS_CONFIG, e)

    if target_filter:
        targets = [t for t in targets if t.get("name", "").lower() == target_filter.lower()]
        if not targets:
            log.warning("No target named %r found in config", target_filter)

    return targets


def research_target(target: dict) -> dict:
    """
    Stub research loop for a single target.

    In production, Neuro spawns an intel_agent_v2 subagent (Agent() tool) loaded with
    decker_system/02_subagents/intel_agent_v2.md for deep research. The subagent returns
    structured findings that are stored here.

    This stub returns a structured placeholder that the memory + Telegram dispatch consume.
    The workflow harness will route this as 'judgment' — the actual LLM reasoning happens
    inside the subagent spawn, not here.
    """
    name = target.get("name", "unknown")
    url = target.get("url", "")
    description = target.get("description", "")

    log.info("Running intel sweep for target: %s (%s)", name, url)

    # Structured finding — populated by subagent in full runs, stubbed here
    finding = {
        "target_name": name,
        "target_url": url,
        "research_description": description,
        "run_timestamp": datetime.now(timezone.utc).isoformat(),
        "findings": [],       # list of {category, finding, significance} dicts
        "summary": f"Intel sweep completed for {name}. Deep analysis requires intel_agent_v2 subagent spawn.",
        "positioning_delta": None,   # how their position changed vs last run
        "threat_level": "unknown",   # low/medium/high/critical
        "action_items": [],          # recommended responses to findings
    }

    return finding


def store_finding(finding: dict) -> bool:
    """Store a finding to aibrain memory as type='competitive_intel'."""
    try:
        # Use the memory MCP tool path if available; fall back to direct DB write
        try:
            from aibrain_db import get_db as _canonical_get_db
            content = json.dumps(finding, indent=2)
            source = finding.get("target_name", "unknown")
            ts = finding.get("run_timestamp", datetime.now(timezone.utc).isoformat())

            conn = _canonical_get_db()
            conn.execute(
                """INSERT INTO memories (content, memory_type, source, importance, created_at, tags)
                   VALUES (?, 'competitive_intel', ?, 0.8, ?, 'intel,competitive,automated')""",
                (content, source, ts),
            )
            conn.commit()
            log.info("Stored finding for %s to memory DB", source)
            return True
        except Exception as e:
            log.warning("DB write failed for %s: %s", finding.get("target_name"), e)
            return False
    except Exception as e:
        log.error("store_finding error: %s", e)
        return False


def send_telegram_digest(results: list[dict]) -> bool:
    """Send a compact Telegram digest of all intel findings to Decker."""
    try:
        import requests
        token = os.environ.get("TELEGRAM_TOKEN")
        chat_id = os.environ.get("TELEGRAM_CHAT_ID", "-5288572284")
        if not token:
            log.warning("TELEGRAM_TOKEN not set — skipping digest")
            return False

        run_date = datetime.now().strftime("%a %b %d %Y")
        lines = [f"*Intel Sweep — {run_date}*\n"]

        for r in results:
            name = r.get("target_name", "?")
            threat = r.get("threat_level", "unknown")
            summary = r.get("summary", "No summary")
            action_count = len(r.get("action_items", []))
            stored = r.get("_stored", False)

            threat_emoji = {"low": "🟢", "medium": "🟡", "high": "🔴", "critical": "🚨"}.get(threat, "⚪")
            lines.append(f"{threat_emoji} *{name}* — {threat} threat")
            lines.append(f"  {summary}")
            if action_count:
                lines.append(f"  → {action_count} action item(s)")
            lines.append(f"  Stored: {'yes' if stored else 'no'}")
            lines.append("")

        lines.append(f"_Targets: {len(results)} | Run: intel\\_agent\\_run workflow_")

        text = "\n".join(lines)
        resp = requests.post(
            f"https://api.telegram.org/bot{token}/sendMessage",
            json={"chat_id": chat_id, "text": text, "parse_mode": "Markdown"},
            timeout=10,
        )
        if resp.ok:
            log.info("Telegram digest sent for %d targets", len(results))
            return True
        else:
            log.warning("Telegram send failed: %s", resp.text[:200])
            return False
    except Exception as e:
        log.warning("Telegram digest error: %s", e)
        return False


def run(target_filter: str = None) -> dict:
    """
    Main entry point for the intel_agent_run workflow.

    Args:
        target_filter: Optional target name to run a single-target sweep.
                       None runs all configured targets.

    Returns:
        {
          "targets_analyzed": int,
          "findings_stored": int,
          "telegram_sent": bool,
          "results": list[dict],
        }
    """
    targets = load_targets(target_filter)
    if not targets:
        return {
            "targets_analyzed": 0,
            "findings_stored": 0,
            "telegram_sent": False,
            "results": [],
            "error": "No targets configured or target filter matched nothing",
        }

    log.info("Starting intel sweep for %d target(s)", len(targets))

    results = []
    stored_count = 0

    for target in targets:
        finding = research_target(target)
        stored = store_finding(finding)
        finding["_stored"] = stored
        if stored:
            stored_count += 1
        results.append(finding)

    telegram_sent = send_telegram_digest(results)

    output = {
        "targets_analyzed": len(results),
        "findings_stored": stored_count,
        "telegram_sent": telegram_sent,
        "results": results,
    }

    log.info(
        "Intel sweep complete: %d targets, %d stored, telegram=%s",
        len(results), stored_count, telegram_sent,
    )
    return output


if __name__ == "__main__":
    import sys
    import argparse

    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    parser = argparse.ArgumentParser(description="intel_agent_run — competitive intel sweep")
    parser.add_argument("--target", default=None, help="Run a single named target only")
    parsed = parser.parse_args()

    workflow_execute(
        workflow_name="intel_agent_run",
        action=lambda: run(target_filter=parsed.target),
        task_type="judgment",
        actor="cli",
    )
