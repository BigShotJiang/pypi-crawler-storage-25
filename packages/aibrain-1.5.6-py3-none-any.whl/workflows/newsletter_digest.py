#!/usr/bin/env python3
"""AIBrain Workflow: Newsletter Digest — aggregate newsletters from email into one summary."""

import argparse
import datetime
import email
import imaplib
import json
import os
import re
import smtplib
import sqlite3
import sys
import urllib.request
from email.header import decode_header
from email.mime.text import MIMEText
from pathlib import Path

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

from aibrain_db import AIBRAIN_ROOT, get_db
_cfg_path = AIBRAIN_ROOT / "config.json"
CONFIG = json.loads(_cfg_path.read_text()) if _cfg_path.exists() else {}
def _find_db():
    """Find best DB path, checking both new and legacy names."""
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    configured = CONFIG.get("db_path")
    if configured and Path(configured).exists():
        return configured
    mem_db = AIBRAIN_ROOT / "memory" / "memory.db"
    if mem_db.exists():
        return str(mem_db)
    return str(AIBRAIN_ROOT / "aibrain.db")

MEMORY_DB = CONFIG.get("db_path", _find_db())
API_BASE = os.environ.get("AIBRAIN_API", os.environ.get("AIBRAIN_API", "http://localhost:8001/api/agent"))


def log_activity(action, detail="", status="ok"):
    try:
        data = json.dumps({
            "action": action, "category": "email",
            "detail": detail, "status": status,
        }).encode()
        req = urllib.request.Request(
            f"{API_BASE}/activity", data=data,
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass


NEWSLETTER_PATTERNS = [
    "noreply", "newsletter", "digest", "updates", "weekly", "daily",
    "substack", "beehiiv", "mailchimp", "convertkit", "buttondown",
]


def get_db():
    db = get_db()
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    return db

def load_state(name):
    try:
        db = get_db()
        row = db.execute("SELECT content FROM memories WHERE name=? AND active=1",
                         (f"workflow_state:{name}",)).fetchone()
        db.close()
        return json.loads(row["content"]) if row else {}
    except Exception:
        return {}

def save_state(name, state):
    db = get_db()
    try:
        now = datetime.datetime.now().isoformat()
        existing = db.execute("SELECT id FROM memories WHERE name=? AND active=1",
                             (f"workflow_state:{name}",)).fetchone()
        if existing:
            db.execute("UPDATE memories SET content=?, updated=? WHERE id=?",
                       (json.dumps(state), now, existing["id"]))
        else:
            db.execute("INSERT INTO memories (name,type,tags,content,created,updated,active) VALUES (?,?,?,?,?,?,1)",
                       (f"workflow_state:{name}", "reference", "workflow,state", json.dumps(state), now, now))
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()

def send_email(to, subject, body, dry_run=False):
    if dry_run:
        print(f"TO: {to}\nSUBJECT: {subject}\n\n{body}")
        return
    agent_email = CONFIG.get("agent_email", "aibrain@localhost")
    agent_password = CONFIG.get("agent_email_password", CONFIG.get("email_app_password", ""))
    msg = MIMEText(body, "plain")
    msg["From"] = agent_email
    msg["To"] = to
    msg["Subject"] = subject
    with smtplib.SMTP_SSL(CONFIG.get("agent_smtp_host", CONFIG.get("email_smtp_host", "smtp.gmail.com")), 465) as s:
        s.login(agent_email, agent_password)
        s.send_message(msg)


def get_email_accounts():
    """Build list of all email accounts to monitor."""
    accounts = []
    # Primary agent email
    agent_email = CONFIG.get("agent_email", "")
    agent_password = CONFIG.get("agent_email_password", CONFIG.get("email_app_password", ""))
    agent_imap = CONFIG.get("agent_imap_host", CONFIG.get("email_imap_host", "imap.gmail.com"))
    if agent_email and agent_password:
        accounts.append({"label": "agent", "email": agent_email, "password": agent_password, "imap_host": agent_imap})
    # Additional monitored accounts
    for acct in CONFIG.get("email_accounts", []):
        if acct.get("monitor") and acct.get("email") and acct.get("app_password"):
            accounts.append({
                "label": acct.get("label", acct["email"].split("@")[0]),
                "email": acct["email"],
                "password": acct["app_password"],
                "imap_host": acct.get("imap_host", "imap.gmail.com"),
            })
    return accounts


def decode_mime_header(header):
    if not header:
        return ""
    parts = decode_header(header)
    decoded = []
    for part, charset in parts:
        if isinstance(part, bytes):
            decoded.append(part.decode(charset or "utf-8", errors="replace"))
        else:
            decoded.append(str(part))
    return " ".join(decoded)


def is_newsletter(sender, subject):
    s = f"{sender} {subject}".lower()
    return any(p in s for p in NEWSLETTER_PATTERNS)


def get_text_body(msg):
    if msg.is_multipart():
        for part in msg.walk():
            if part.get_content_type() == "text/plain":
                payload = part.get_payload(decode=True)
                if payload:
                    return payload.decode(part.get_content_charset() or "utf-8", errors="replace")
    else:
        payload = msg.get_payload(decode=True)
        if payload:
            return payload.decode(msg.get_content_charset() or "utf-8", errors="replace")
    return ""


def extract_links(text):
    return re.findall(r'https?://[^\s<>"]+', text)[:5]


def fetch_newsletters(imap_host, email_addr, password, days=7):
    newsletters = []
    try:
        mail = imaplib.IMAP4_SSL(imap_host, 993)
        mail.login(email_addr, password)
        mail.select("INBOX", readonly=True)

        since = (datetime.date.today() - datetime.timedelta(days=days)).strftime("%d-%b-%Y")
        _, data = mail.search(None, f'(SINCE "{since}")')
        msg_ids = data[0].split()

        for mid in msg_ids[-100:]:  # cap at 100
            _, msg_data = mail.fetch(mid, "(RFC822)")
            raw = msg_data[0][1]
            msg = email.message_from_bytes(raw)

            sender = decode_mime_header(msg.get("From", ""))
            subject = decode_mime_header(msg.get("Subject", ""))

            if is_newsletter(sender, subject):
                body = get_text_body(msg)
                links = extract_links(body)
                # Extract sender name
                match = re.match(r'"?([^"<]+)"?\s*<', sender)
                sender_name = match.group(1).strip() if match else sender[:30]

                newsletters.append({
                    "sender": sender_name,
                    "subject": subject,
                    "date": msg.get("Date", "")[:16],
                    "preview": body[:300].replace("\n", " ").strip(),
                    "links": links,
                })

        mail.logout()
    except Exception as e:
        print(f"IMAP error: {e}", file=sys.stderr)
    return newsletters


def format_digest(newsletters):
    lines = [
        f"NEWSLETTER DIGEST — {datetime.datetime.now().strftime('%A %B %d, %Y')}",
        f"Collected {len(newsletters)} newsletters from the past week",
        "=" * 50,
        "",
    ]

    # Group by sender
    by_sender = {}
    for nl in newsletters:
        by_sender.setdefault(nl["sender"], []).append(nl)

    for sender, items in sorted(by_sender.items(), key=lambda x: len(x[1]), reverse=True):
        lines.append(f"--- {sender} ({len(items)} issues) ---")
        for nl in items[:3]:
            lines.append(f"  {nl['subject']}")
            if nl["preview"]:
                lines.append(f"  {nl['preview'][:150]}...")
            if nl["links"]:
                lines.append(f"  Links: {nl['links'][0]}")
            lines.append("")

    if not newsletters:
        lines.append("No newsletters found in the past week.")

    lines.append("—\nPowered by AIBrain")
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="AIBrain Newsletter Digest — multi-account")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--days", type=int, default=7, help="Look back N days")
    args = parser.parse_args()

    accounts = get_email_accounts()
    if not accounts:
        print("Error: no email accounts configured in config.json", file=sys.stderr)
        sys.exit(1)

    email_to = CONFIG.get("email_to", CONFIG.get("agent_email", ""))

    # Fetch newsletters from all accounts
    all_newsletters = []
    per_account = {}
    for acct in accounts:
        print(f"Checking {acct['label']} ({acct['email']})...")
        nls = fetch_newsletters(acct["imap_host"], acct["email"], acct["password"], args.days)
        for nl in nls:
            nl["_account"] = acct["label"]
        all_newsletters.extend(nls)
        per_account[acct["label"]] = len(nls)
        print(f"  {len(nls)} newsletters found")

    # Format with account labels if multiple accounts
    if len(accounts) > 1 and all_newsletters:
        lines = [
            f"NEWSLETTER DIGEST — {datetime.datetime.now().strftime('%A %B %d, %Y')}",
            f"Collected {len(all_newsletters)} newsletters from {len(accounts)} accounts",
            "=" * 50,
            "",
        ]
        by_sender = {}
        for nl in all_newsletters:
            key = f"{nl['sender']} [{nl['_account']}]"
            by_sender.setdefault(key, []).append(nl)
        for sender, items in sorted(by_sender.items(), key=lambda x: len(x[1]), reverse=True):
            lines.append(f"--- {sender} ({len(items)} issues) ---")
            for nl in items[:3]:
                lines.append(f"  {nl['subject']}")
                if nl["preview"]:
                    lines.append(f"  {nl['preview'][:150]}...")
                if nl["links"]:
                    lines.append(f"  Links: {nl['links'][0]}")
                lines.append("")
        lines.append(f"\nACCOUNT SUMMARY:")
        for label, count in per_account.items():
            lines.append(f"  {label:20s} {count:3d} newsletters")
        lines.append("\n---\nPowered by AIBrain")
        digest = "\n".join(lines)
    else:
        digest = format_digest(all_newsletters)

    if not email_to or args.dry_run:
        print(digest)
    else:
        acct_label = f" ({len(accounts)} accounts)" if len(accounts) > 1 else ""
        send_email(email_to, f"Newsletter Digest — {len(all_newsletters)} collected{acct_label}", digest)
        print(f"Sent newsletter digest to {email_to}")

    save_state("newsletter_digest", {
        "last_run": datetime.datetime.now().isoformat(),
        "accounts_checked": len(accounts),
        "count": len(all_newsletters),
        "per_account": per_account,
    })

    log_activity("newsletter_digest_run",
                 f"accounts={len(accounts)} newsletters={len(all_newsletters)}")


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name='newsletter_digest',
        action=_workflow_entry,
        task_type='simple',
        actor='cli',
    )
