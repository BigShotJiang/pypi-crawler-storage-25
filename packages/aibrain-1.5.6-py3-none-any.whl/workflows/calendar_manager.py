#!/usr/bin/env python3
"""AIBrain Workflow: Calendar Manager — extract events from emails, create .ics files or push to Google Calendar."""

import argparse
import datetime
import email
import imaplib
import json
import os
import re
import sqlite3
import sys
import urllib.request
import uuid
from email.header import decode_header
from pathlib import Path

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

# ---------------------------------------------------------------------------
# Config & DB helpers
# ---------------------------------------------------------------------------

from aibrain_db import AIBRAIN_ROOT, get_db
_cfg_path = AIBRAIN_ROOT / "config.json"
CONFIG = json.loads(_cfg_path.read_text()) if _cfg_path.exists() else {}
def _find_db():
    """Find best DB path, checking both new and legacy names."""
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    configured = CONFIG.get("db_path")
    if configured and Path(configured).exists():
        return configured
    mem_db = AIBRAIN_ROOT / "memory" / "memory.db"
    if mem_db.exists():
        return str(mem_db)
    return str(AIBRAIN_ROOT / "aibrain.db")

MEMORY_DB = CONFIG.get("db_path", _find_db())
API_BASE = os.environ.get("AIBRAIN_API", os.environ.get("AIBRAIN_API", "http://localhost:8001/api/agent"))
ICS_DIR = AIBRAIN_ROOT / "data" / "calendar"

# Date/time extraction patterns
DATE_PATTERNS = [
    # 2026-03-20 or 2026/03/20
    (r"(\d{4}[-/]\d{1,2}[-/]\d{1,2})", "%Y-%m-%d"),
    # March 20, 2026 or Mar 20 2026
    (r"((?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{1,2},?\s+\d{4})", None),
    # 03/20/2026 or 3/20/2026
    (r"(\d{1,2}/\d{1,2}/\d{4})", "%m/%d/%Y"),
]

TIME_PATTERNS = [
    # 2:00 PM, 14:00, 2pm
    r"(\d{1,2}:\d{2}\s*(?:AM|PM|am|pm))",
    r"(\d{1,2}\s*(?:AM|PM|am|pm))",
    r"(\d{1,2}:\d{2})(?:\s|$|,|\.|;)",
]

EVENT_KEYWORDS = {
    "interview": "Interview",
    "meeting": "Meeting",
    "call": "Call",
    "deadline": "Deadline",
    "demo": "Demo",
    "presentation": "Presentation",
    "standup": "Standup",
    "sync": "Sync",
    "review": "Review",
    "webinar": "Webinar",
    "conference": "Conference",
    "appointment": "Appointment",
    "due": "Deadline",
    "submit": "Deadline",
    "followup": "Follow-up",
    "follow-up": "Follow-up",
    "onsite": "On-site",
    "screening": "Screening",
    "phone screen": "Phone Screen",
}


def log_activity(action, detail="", status="ok"):
    """Log activity to AIBrain API."""
    try:
        data = json.dumps({
            "action": action, "category": "productivity",
            "detail": detail, "status": status,
        }).encode()
        req = urllib.request.Request(
            f"{API_BASE}/activity", data=data,
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass


def get_db():
    db = get_db()
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    return db


def init_calendar_table():
    """Create calendar_events table if it doesn't exist."""
    db = get_db()
    db.execute("""
        CREATE TABLE IF NOT EXISTS calendar_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            uid TEXT UNIQUE NOT NULL,
            title TEXT NOT NULL,
            start_dt TEXT NOT NULL,
            end_dt TEXT NOT NULL,
            location TEXT DEFAULT '',
            description TEXT DEFAULT '',
            source TEXT DEFAULT '',
            ics_path TEXT DEFAULT '',
            gcal_id TEXT DEFAULT '',
            created TEXT NOT NULL,
            active INTEGER DEFAULT 1
        )
    """)
    db.commit()
    db.close()


def load_state(name):
    try:
        db = get_db()
        row = db.execute(
            "SELECT content FROM memories WHERE name=? AND active=1",
            (f"workflow_state:{name}",),
        ).fetchone()
        db.close()
        return json.loads(row["content"]) if row else {}
    except Exception:
        return {}


def save_state(name, state):
    db = get_db()
    try:
        now = datetime.datetime.now().isoformat()
        existing = db.execute(
            "SELECT id FROM memories WHERE name=? AND active=1",
            (f"workflow_state:{name}",),
        ).fetchone()
        if existing:
            db.execute("UPDATE memories SET content=?, updated=? WHERE id=?",
                       (json.dumps(state), now, existing["id"]))
        else:
            db.execute(
                "INSERT INTO memories (name,type,tags,content,created,updated,active) VALUES (?,?,?,?,?,?,1)",
                (f"workflow_state:{name}", "reference", "workflow,state",
                 json.dumps(state), now, now),
            )
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def send_email(to, subject, body, dry_run=False):
    if dry_run:
        print(f"TO: {to}\nSUBJECT: {subject}\n\n{body}")
        return
    from email.mime.text import MIMEText
    import smtplib
    agent_email = CONFIG.get("agent_email", "aibrain@localhost")
    agent_password = CONFIG.get("agent_email_password", CONFIG.get("email_app_password", ""))
    msg = MIMEText(body, "plain")
    msg["From"] = agent_email
    msg["To"] = to
    msg["Subject"] = subject
    with smtplib.SMTP_SSL(CONFIG.get("agent_smtp_host", CONFIG.get("email_smtp_host", "smtp.gmail.com")), 465) as s:
        s.login(agent_email, agent_password)
        s.send_message(msg)


# ---------------------------------------------------------------------------
# Date/time parsing
# ---------------------------------------------------------------------------

def parse_month_name(text):
    """Parse dates like 'March 20, 2026' or 'Mar 20 2026'."""
    months = {
        "jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6,
        "jul": 7, "aug": 8, "sep": 9, "oct": 10, "nov": 11, "dec": 12,
    }
    # Normalize
    clean = re.sub(r",", "", text).strip()
    parts = clean.split()
    if len(parts) < 3:
        return None
    month_str = parts[0][:3].lower()
    if month_str not in months:
        return None
    try:
        return datetime.date(int(parts[2]), months[month_str], int(parts[1]))
    except (ValueError, IndexError):
        return None


def extract_date(text):
    """Extract first date reference from text. Returns datetime.date or None."""
    # Relative dates
    lower = text.lower()
    today = datetime.date.today()

    if "tomorrow" in lower:
        return today + datetime.timedelta(days=1)
    if "next monday" in lower:
        days_ahead = (0 - today.weekday() + 7) % 7 or 7
        return today + datetime.timedelta(days=days_ahead)
    if "next tuesday" in lower:
        days_ahead = (1 - today.weekday() + 7) % 7 or 7
        return today + datetime.timedelta(days=days_ahead)
    if "next wednesday" in lower:
        days_ahead = (2 - today.weekday() + 7) % 7 or 7
        return today + datetime.timedelta(days=days_ahead)
    if "next thursday" in lower:
        days_ahead = (3 - today.weekday() + 7) % 7 or 7
        return today + datetime.timedelta(days=days_ahead)
    if "next friday" in lower:
        days_ahead = (4 - today.weekday() + 7) % 7 or 7
        return today + datetime.timedelta(days=days_ahead)

    # Absolute date patterns
    for pattern, fmt in DATE_PATTERNS:
        m = re.search(pattern, text, re.IGNORECASE)
        if m:
            date_str = m.group(1)
            if fmt is None:
                # Month-name format
                result = parse_month_name(date_str)
                if result:
                    return result
            else:
                try:
                    normalized = date_str.replace("/", "-") if fmt == "%Y-%m-%d" else date_str
                    return datetime.datetime.strptime(date_str, fmt).date()
                except ValueError:
                    continue
    return None


def extract_time(text):
    """Extract first time reference from text. Returns datetime.time or None."""
    for pattern in TIME_PATTERNS:
        m = re.search(pattern, text, re.IGNORECASE)
        if m:
            time_str = m.group(1).strip()
            # Try parsing various formats
            for fmt in ("%I:%M %p", "%I:%M%p", "%I %p", "%I%p", "%H:%M"):
                try:
                    return datetime.datetime.strptime(time_str, fmt).time()
                except ValueError:
                    continue
    return None


def detect_event_type(text):
    """Detect what kind of event this is based on keywords."""
    lower = text.lower()
    for keyword, label in EVENT_KEYWORDS.items():
        if keyword in lower:
            return label
    return None


def extract_events_from_email(sender, subject, body):
    """Attempt to extract calendar events from an email. Returns list of event dicts."""
    events = []
    full_text = f"{subject} {body}"

    event_type = detect_event_type(full_text)
    if not event_type:
        return events

    date = extract_date(full_text)
    if not date:
        return events

    time = extract_time(full_text) or datetime.time(9, 0)  # default 9 AM
    start_dt = datetime.datetime.combine(date, time)

    # Try to find duration or end time — default 60 min
    duration = 60
    dur_match = re.search(r"(\d+)\s*(?:min|minute)", full_text, re.IGNORECASE)
    if dur_match:
        duration = int(dur_match.group(1))
    hour_match = re.search(r"(\d+)\s*(?:hour|hr)", full_text, re.IGNORECASE)
    if hour_match:
        duration = int(hour_match.group(1)) * 60

    end_dt = start_dt + datetime.timedelta(minutes=duration)

    # Build title
    title = f"{event_type}: {subject[:60]}"

    # Try to extract location
    location = ""
    loc_match = re.search(r"(?:at|location|venue|address)[:\s]+([^\n,]{3,50})", full_text, re.IGNORECASE)
    if loc_match:
        location = loc_match.group(1).strip()

    # Check for video call links
    for link_pattern in [r"(https?://\S*zoom\S+)", r"(https?://\S*teams\S+)", r"(https?://\S*meet\.google\S+)"]:
        link_match = re.search(link_pattern, full_text, re.IGNORECASE)
        if link_match:
            location = link_match.group(1)
            break

    events.append({
        "title": title,
        "start_dt": start_dt,
        "end_dt": end_dt,
        "location": location,
        "description": f"Extracted from email: {subject}\nFrom: {sender}",
        "source": f"email:{sender}",
    })

    return events


# ---------------------------------------------------------------------------
# .ics generation
# ---------------------------------------------------------------------------

def generate_ics(event):
    """Generate an .ics file for a single event. Returns file path."""
    try:
        from icalendar import Calendar, Event, vText
        cal = Calendar()
        cal.add("prodid", "-//AIBrain Calendar Manager//EN")
        cal.add("version", "2.0")
        cal.add("calscale", "GREGORIAN")

        e = Event()
        e.add("summary", event["title"])
        e.add("dtstart", event["start_dt"])
        e.add("dtend", event["end_dt"])
        e.add("dtstamp", datetime.datetime.now())
        e["uid"] = event.get("uid", str(uuid.uuid4()))  # noqa:uuid4-security-token — calendar event UID, not a secret

        if event.get("location"):
            e["location"] = vText(event["location"])
        if event.get("description"):
            e["description"] = vText(event["description"])

        cal.add_component(e)

        ICS_DIR.mkdir(parents=True, exist_ok=True)
        safe_title = re.sub(r"[^\w\s-]", "", event["title"])[:40].strip().replace(" ", "_")
        date_str = event["start_dt"].strftime("%Y%m%d")
        filename = f"{date_str}_{safe_title}.ics"
        filepath = ICS_DIR / filename

        filepath.write_bytes(cal.to_ical())
        return str(filepath)

    except ImportError:
        # Fallback: manual .ics generation without icalendar library
        return _generate_ics_manual(event)


def _generate_ics_manual(event):
    """Generate .ics without the icalendar library (pure string approach)."""
    uid = event.get("uid", str(uuid.uuid4()))  # noqa:uuid4-security-token — calendar event UID, not a secret
    now = datetime.datetime.now().strftime("%Y%m%dT%H%M%SZ")
    dtstart = event["start_dt"].strftime("%Y%m%dT%H%M%S")
    dtend = event["end_dt"].strftime("%Y%m%dT%H%M%S")

    lines = [
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        "PRODID:-//AIBrain Calendar Manager//EN",
        "CALSCALE:GREGORIAN",
        "BEGIN:VEVENT",
        f"UID:{uid}",
        f"DTSTAMP:{now}",
        f"DTSTART:{dtstart}",
        f"DTEND:{dtend}",
        f"SUMMARY:{event['title']}",
    ]
    if event.get("location"):
        lines.append(f"LOCATION:{event['location']}")
    if event.get("description"):
        desc = event["description"].replace("\n", "\\n")
        lines.append(f"DESCRIPTION:{desc}")
    lines.extend(["END:VEVENT", "END:VCALENDAR"])

    ICS_DIR.mkdir(parents=True, exist_ok=True)
    safe_title = re.sub(r"[^\w\s-]", "", event["title"])[:40].strip().replace(" ", "_")
    date_str = event["start_dt"].strftime("%Y%m%d")
    filename = f"{date_str}_{safe_title}.ics"
    filepath = ICS_DIR / filename

    filepath.write_text("\r\n".join(lines), encoding="utf-8")
    return str(filepath)


# ---------------------------------------------------------------------------
# Google Calendar (optional)
# ---------------------------------------------------------------------------

def gcal_available():
    """Check if Google Calendar API credentials are configured."""
    creds_path = AIBRAIN_ROOT / "credentials" / "google_calendar.json"
    token_path = AIBRAIN_ROOT / "credentials" / "gcal_token.json"
    return creds_path.exists() or token_path.exists()


def push_to_gcal(event):
    """Push event to Google Calendar. Returns event ID or None."""
    try:
        from google.oauth2.credentials import Credentials
        from google_auth_oauthlib.flow import InstalledAppFlow
        from googleapiclient.discovery import build
        from google.auth.transport.requests import Request

        SCOPES = ["https://www.googleapis.com/auth/calendar.events"]
        creds_path = AIBRAIN_ROOT / "credentials" / "google_calendar.json"
        token_path = AIBRAIN_ROOT / "credentials" / "gcal_token.json"

        creds = None
        if token_path.exists():
            creds = Credentials.from_authorized_user_file(str(token_path), SCOPES)
        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                creds.refresh(Request())
            elif creds_path.exists():
                flow = InstalledAppFlow.from_client_secrets_file(str(creds_path), SCOPES)
                creds = flow.run_local_server(port=0)
            else:
                return None
            token_path.parent.mkdir(parents=True, exist_ok=True)
            token_path.write_text(creds.to_json())

        service = build("calendar", "v3", credentials=creds)
        gcal_event = {
            "summary": event["title"],
            "start": {"dateTime": event["start_dt"].isoformat(), "timeZone": "America/New_York"},
            "end": {"dateTime": event["end_dt"].isoformat(), "timeZone": "America/New_York"},
        }
        if event.get("location"):
            gcal_event["location"] = event["location"]
        if event.get("description"):
            gcal_event["description"] = event["description"]

        result = service.events().insert(calendarId="primary", body=gcal_event).execute()
        return result.get("id")

    except Exception as e:
        print(f"Google Calendar push failed: {e}", file=sys.stderr)
        return None


# ---------------------------------------------------------------------------
# Event storage
# ---------------------------------------------------------------------------

def store_event(event, ics_path="", gcal_id=""):
    """Store event in local SQLite table. Returns the uid."""
    uid = event.get("uid", str(uuid.uuid4()))  # noqa:uuid4-security-token — calendar event UID, not a secret
    db = get_db()
    now = datetime.datetime.now().isoformat()
    try:
        db.execute("""
            INSERT INTO calendar_events (uid, title, start_dt, end_dt, location, description, source, ics_path, gcal_id, created)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            uid,
            event["title"],
            event["start_dt"].isoformat(),
            event["end_dt"].isoformat(),
            event.get("location", ""),
            event.get("description", ""),
            event.get("source", "manual"),
            ics_path,
            gcal_id,
            now,
        ))
        db.commit()
    except sqlite3.IntegrityError:
        print(f"Event already exists: {uid}", file=sys.stderr)
    db.close()
    return uid


def is_duplicate(title, start_dt):
    """Check if a similar event already exists (same title prefix + same start time)."""
    db = get_db()
    try:
        row = db.execute(
            "SELECT id FROM calendar_events WHERE title=? AND start_dt=? AND active=1",
            (title, start_dt.isoformat()),
        ).fetchone()
        db.close()
        return row is not None
    except Exception:
        db.close()
        return False


# ---------------------------------------------------------------------------
# Email scanning (cron mode)
# ---------------------------------------------------------------------------

def decode_mime_header(header):
    if not header:
        return ""
    parts = decode_header(header)
    decoded = []
    for part, charset in parts:
        if isinstance(part, bytes):
            decoded.append(part.decode(charset or "utf-8", errors="replace"))
        else:
            decoded.append(str(part))
    return " ".join(decoded)


def get_body(msg):
    """Extract plain text body from email message."""
    if msg.is_multipart():
        for part in msg.walk():
            if part.get_content_type() == "text/plain":
                payload = part.get_payload(decode=True)
                if payload:
                    charset = part.get_content_charset() or "utf-8"
                    return payload.decode(charset, errors="replace")[:1000]
    else:
        payload = msg.get_payload(decode=True)
        if payload:
            charset = msg.get_content_charset() or "utf-8"
            return payload.decode(charset, errors="replace")[:1000]
    return ""


def scan_emails_for_events(dry_run=False):
    """Scan recent unread emails for date/time references and extract events."""
    accounts = []

    agent_email = CONFIG.get("agent_email", "")
    agent_password = CONFIG.get("agent_email_password", CONFIG.get("email_app_password", ""))
    agent_imap = CONFIG.get("agent_imap_host", CONFIG.get("email_imap_host", "imap.gmail.com"))
    if agent_email and agent_password:
        accounts.append({
            "label": "agent",
            "email": agent_email,
            "password": agent_password,
            "imap_host": agent_imap,
        })

    for acct in CONFIG.get("email_accounts", []):
        if acct.get("monitor") and acct.get("email") and acct.get("app_password"):
            accounts.append({
                "label": acct.get("label", acct["email"].split("@")[0]),
                "email": acct["email"],
                "password": acct["app_password"],
                "imap_host": acct.get("imap_host", "imap.gmail.com"),
            })

    if not accounts:
        print("No email accounts configured.", file=sys.stderr)
        return []

    all_events = []

    for acct in accounts:
        print(f"Scanning {acct['label']} ({acct['email']}) for calendar events...")
        try:
            mail = imaplib.IMAP4_SSL(acct["imap_host"], 993)
            mail.login(acct["email"], acct["password"])
            mail.select("INBOX", readonly=True)

            # Search recent emails (last 7 days)
            since_date = (datetime.date.today() - datetime.timedelta(days=7)).strftime("%d-%b-%Y")
            _, data = mail.search(None, f'(SINCE "{since_date}")')
            msg_ids = data[0].split()

            # Cap at 50
            if len(msg_ids) > 50:
                msg_ids = msg_ids[-50:]

            for mid in msg_ids:
                _, msg_data = mail.fetch(mid, "(RFC822)")
                raw = msg_data[0][1]
                msg = email.message_from_bytes(raw)

                sender = decode_mime_header(msg.get("From", ""))
                subject = decode_mime_header(msg.get("Subject", ""))
                body = get_body(msg)

                sender_match = re.search(r"[\w.+-]+@[\w.-]+", sender)
                sender_email = sender_match.group(0) if sender_match else sender

                events = extract_events_from_email(sender_email, subject, body)
                all_events.extend(events)

            mail.logout()
            print(f"  Found {len(all_events)} potential events")

        except Exception as e:
            print(f"  Error scanning {acct['label']}: {e}", file=sys.stderr)

    return all_events


# ---------------------------------------------------------------------------
# Event creation pipeline
# ---------------------------------------------------------------------------

def create_event(title, start_dt, end_dt, location="", description="", source="manual", dry_run=False):
    """Full event creation: store, generate .ics, optionally push to Google Calendar."""
    uid = str(uuid.uuid4())  # noqa:uuid4-security-token — calendar event UID, not a secret
    event = {
        "uid": uid,
        "title": title,
        "start_dt": start_dt,
        "end_dt": end_dt,
        "location": location,
        "description": description,
        "source": source,
    }

    if is_duplicate(title, start_dt):
        print(f"Skipping duplicate: {title} at {start_dt}")
        return None

    if dry_run:
        print(f"[DRY RUN] Would create event:")
        print(f"  Title:    {title}")
        print(f"  Start:    {start_dt}")
        print(f"  End:      {end_dt}")
        print(f"  Location: {location or '(none)'}")
        print(f"  Source:   {source}")
        return event

    # Generate .ics file
    ics_path = generate_ics(event)
    print(f"  .ics saved: {ics_path}")

    # Try Google Calendar
    gcal_id = ""
    if gcal_available():
        gcal_id = push_to_gcal(event) or ""
        if gcal_id:
            print(f"  Google Calendar event created: {gcal_id}")
        else:
            print("  Google Calendar push failed, .ics file is available")

    # Store in DB
    store_event(event, ics_path=ics_path, gcal_id=gcal_id)
    print(f"  Stored in DB: {uid}")

    return event


def format_summary(created_events):
    """Format a notification summary of created events."""
    if not created_events:
        return "Calendar Manager: No new events created."

    now = datetime.datetime.now()
    lines = [
        f"CALENDAR EVENTS CREATED — {now.strftime('%A %B %d, %Y %I:%M %p')}",
        f"New events: {len(created_events)}",
        "=" * 50,
        "",
    ]

    for event in created_events:
        lines.append(f"  {event['title']}")
        lines.append(f"    When: {event['start_dt'].strftime('%A %b %d, %Y %I:%M %p')} - {event['end_dt'].strftime('%I:%M %p')}")
        if event.get("location"):
            lines.append(f"    Where: {event['location']}")
        lines.append(f"    Source: {event.get('source', 'manual')}")
        lines.append("")

    lines.append("---\nPowered by AIBrain Calendar Manager")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="AIBrain Calendar Manager — create and track events")
    parser.add_argument("--dry-run", action="store_true", help="Print actions without executing")
    parser.add_argument("--scan", action="store_true", help="Scan recent emails for events (cron mode)")
    parser.add_argument("--title", type=str, help="Event title for direct creation")
    parser.add_argument("--date", type=str, help="Event date (YYYY-MM-DD)")
    parser.add_argument("--time", type=str, default="09:00", help="Event time (HH:MM, 24h format)")
    parser.add_argument("--duration", type=int, default=60, help="Duration in minutes (default: 60)")
    parser.add_argument("--location", type=str, default="", help="Event location or meeting link")
    parser.add_argument("--description", type=str, default="", help="Event description")
    args = parser.parse_args()

    init_calendar_table()
    created_events = []

    if args.scan:
        # ---- Cron mode: scan emails for events ----
        print("Scanning emails for calendar events...")
        events = scan_emails_for_events(dry_run=args.dry_run)

        for event_data in events:
            result = create_event(
                title=event_data["title"],
                start_dt=event_data["start_dt"],
                end_dt=event_data["end_dt"],
                location=event_data.get("location", ""),
                description=event_data.get("description", ""),
                source=event_data.get("source", "email"),
                dry_run=args.dry_run,
            )
            if result:
                created_events.append(result)

    elif args.title and args.date:
        # ---- Direct creation via CLI ----
        try:
            event_date = datetime.datetime.strptime(args.date, "%Y-%m-%d").date()
        except ValueError:
            print(f"Invalid date format: {args.date}. Use YYYY-MM-DD.", file=sys.stderr)
            sys.exit(1)

        try:
            event_time = datetime.datetime.strptime(args.time, "%H:%M").time()
        except ValueError:
            print(f"Invalid time format: {args.time}. Use HH:MM (24h).", file=sys.stderr)
            sys.exit(1)

        start_dt = datetime.datetime.combine(event_date, event_time)
        end_dt = start_dt + datetime.timedelta(minutes=args.duration)

        result = create_event(
            title=args.title,
            start_dt=start_dt,
            end_dt=end_dt,
            location=args.location,
            description=args.description,
            source="cli",
            dry_run=args.dry_run,
        )
        if result:
            created_events.append(result)

    else:
        parser.print_help()
        print("\nExamples:")
        print('  python calendar_manager.py --scan --dry-run')
        print('  python calendar_manager.py --title "Interview at Acme" --date 2026-03-20 --time 14:00 --duration 60')
        sys.exit(0)

    # Summary & notification
    summary = format_summary(created_events)
    print(f"\n{summary}")

    if created_events and not args.dry_run:
        email_to = CONFIG.get("email_to", CONFIG.get("agent_email", ""))
        if email_to:
            send_email(email_to, f"Calendar: {len(created_events)} event(s) created", summary, dry_run=args.dry_run)
            print(f"Summary sent to {email_to}")

    # Save workflow state
    save_state("calendar_manager", {
        "last_run": datetime.datetime.now().isoformat(),
        "mode": "scan" if args.scan else "cli",
        "events_created": len(created_events),
        "dry_run": args.dry_run,
    })

    log_activity("calendar_manager", f"{'Scanned emails' if args.scan else 'CLI create'}: {len(created_events)} event(s) created")


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name='calendar_manager',
        action=_workflow_entry,
        task_type='simple',
        actor='cli',
    )
