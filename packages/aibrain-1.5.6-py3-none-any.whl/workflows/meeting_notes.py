#!/usr/bin/env python3
"""AIBrain Workflow: Meeting Notes — summarize recent meeting transcripts into action items."""

import argparse
import json
import os
import sqlite3
import urllib.request
from datetime import datetime, timedelta
from pathlib import Path

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

from aibrain_db import AIBRAIN_ROOT, get_db
API_BASE = os.environ.get("AIBRAIN_API", os.environ.get("AIBRAIN_API", "http://localhost:8001/api/agent"))
CONFIG = json.loads((AIBRAIN_ROOT / "config.json").read_text()) if (AIBRAIN_ROOT / "config.json").exists() else {}
def _find_db():
    """Find best DB path, checking both new and legacy names."""
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    configured = CONFIG.get("db_path")
    if configured and Path(configured).exists():
        return configured
    mem_db = AIBRAIN_ROOT / "memory" / "memory.db"
    if mem_db.exists():
        return str(mem_db)
    return str(AIBRAIN_ROOT / "aibrain.db")

MEMORY_DB = CONFIG.get("db_path", _find_db())


def get_db():
    db = get_db()
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    return db


def log_activity(action, detail="", status="ok"):
    try:
        data = json.dumps({
            "action": action, "category": "productivity",
            "detail": detail, "status": status,
        }).encode()
        req = urllib.request.Request(
            f"{API_BASE}/activity", data=data,
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass


def find_meeting_notes(days=1):
    """Search memories for recent meeting-related content."""
    db = get_db()
    cutoff = (datetime.now() - timedelta(days=days)).isoformat()
    rows = db.execute("""
        SELECT id, name, content, tags, created FROM memories
        WHERE active = 1
        AND (
            name LIKE '%meeting%' OR name LIKE '%notes%' OR name LIKE '%transcript%'  # noqa:like-wildcard-injection — hardcoded static substrings, no user input
            OR name LIKE '%standup%' OR name LIKE '%sync%' OR name LIKE '%call%'  # noqa:like-wildcard-injection — hardcoded static substrings, no user input
            OR tags LIKE '%meeting%' OR tags LIKE '%notes%'  # noqa:like-wildcard-injection — hardcoded static substrings, no user input
        )
        AND created > ?
        ORDER BY created DESC
        LIMIT 20
    """, (cutoff,)).fetchall()
    db.close()
    return [dict(r) for r in rows]


def extract_action_items(content):
    """Simple extraction of action items from text."""
    lines = content.split("\n")
    actions = []
    triggers = [
        "action:", "todo:", "follow up", "next step",
        "- [ ]", "* [ ]", "will ", "need to ", "should ",
        "assigned to", "deadline:", "due:",
    ]
    for line in lines:
        stripped = line.strip().lower()
        if any(t in stripped for t in triggers):
            actions.append(line.strip())
    return actions


def run(dry_run=False, days=1):
    """Find recent meeting notes and extract action items."""
    print(f"[{datetime.now().strftime('%H:%M:%S')}] Scanning for meeting notes (last {days} day(s))...")

    notes = find_meeting_notes(days=days)
    if not notes:
        print("No recent meeting notes found in memory.")
        log_activity("meeting_notes", "No recent meetings found")
        return

    print(f"Found {len(notes)} meeting note(s):\n")

    all_actions = []
    for note in notes:
        print(f"  [{note['id']}] {note['name']} ({note['created'][:10]})")
        actions = extract_action_items(note["content"])
        if actions:
            for a in actions:
                print(f"    → {a}")
                all_actions.append({"source": note["name"], "action": a})
        else:
            print("    (no action items detected)")
        print()

    summary = f"Processed {len(notes)} meeting(s), found {len(all_actions)} action item(s)"
    print(summary)

    if dry_run:
        print("[dry-run] Not saving.")
        return

    # Save summary to memory
    if all_actions:
        db = get_db()
        now = datetime.now().isoformat()
        action_text = "\n".join(f"- [{a['source']}] {a['action']}" for a in all_actions)
        content = f"Meeting Action Items ({datetime.now().strftime('%Y-%m-%d')}):\n\n{action_text}"
        db.execute(
            "INSERT INTO memories (name,type,tags,content,created,updated,active) VALUES (?,?,?,?,?,?,1)",
            (f"Meeting Actions {datetime.now().strftime('%Y-%m-%d')}", "project",
             "meeting,actions,auto-generated", content, now, now),
        )
        db.commit()
        db.close()
        print(f"Saved action items to memory.")

    log_activity("meeting_notes", summary)


def main():
    parser = argparse.ArgumentParser(description="Extract action items from meeting notes")
    parser.add_argument("--dry-run", action="store_true", help="Preview without saving")
    parser.add_argument("--days", type=int, default=1, help="Look back N days (default: 1)")
    args = parser.parse_args()
    run(dry_run=args.dry_run, days=args.days)


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name='meeting_notes',
        action=_workflow_entry,
        task_type='judgment',
        actor='cli',
    )
