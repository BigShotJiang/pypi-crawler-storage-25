#!/usr/bin/env python3
"""
AIBrain Workflow: Auto-Experiment Harness

Eval harness + git manager for automated optimization loops.
Follows the auto-research pattern adapted for general-purpose use.

The calling agent reads a program.md skill file, generates hypotheses,
modifies the mutable file, then uses this harness to:
  - manage git branches and commits
  - run eval commands with timeout
  - parse metrics from eval output
  - keep improvements, revert failures
  - log all results to results.tsv

Usage:
    python auto_experiment.py --program skills/auto_experiment_template.md init --tag selroute
    python auto_experiment.py --program skills/auto_experiment_template.md pre-experiment --desc "increase threshold to 0.7"
    python auto_experiment.py --program skills/auto_experiment_template.md run-eval
    python auto_experiment.py --program skills/auto_experiment_template.md decide
    python auto_experiment.py --program skills/auto_experiment_template.md summary

Full loop (agent-driven):
    1. init --tag <name>
    2. Agent reads program.md, modifies mutable file
    3. pre-experiment --desc "what changed"
    4. run-eval
    5. decide
    6. Repeat 2-5 until --loops exhausted

Style A: function-based with argparse, no external dependencies.
"""

import argparse
import csv
import datetime
import logging
import os
import re
import subprocess
import sys
from pathlib import Path

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

from aibrain_db import AIBRAIN_ROOT
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger("auto_experiment")

# ---------------------------------------------------------------------------
# Program.md parser
# ---------------------------------------------------------------------------

def parse_program(program_path: str) -> dict:
    """Parse a program.md file with YAML frontmatter into config dict."""
    path = Path(program_path)
    if not path.exists():
        logger.error("Program file not found: %s", program_path)
        sys.exit(1)

    text = path.read_text(encoding="utf-8")

    # Extract YAML frontmatter between --- delimiters
    config = {}
    body = text
    fm_match = re.match(r"^---\s*\n(.*?)\n---\s*\n(.*)$", text, re.DOTALL)
    if fm_match:
        frontmatter = fm_match.group(1)
        body = fm_match.group(2)
        for line in frontmatter.strip().splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if ":" in line:
                key, _, value = line.partition(":")
                key = key.strip()
                value = value.strip().strip('"').strip("'")
                # Handle numeric values
                if value.isdigit():
                    value = int(value)
                elif re.match(r"^\d+\.\d+$", value):
                    value = float(value)
                config[key] = value

    config["body"] = body

    # Validate required fields
    required = ["mutable_file", "eval_command", "metric_name", "metric_direction"]
    missing = [k for k in required if k not in config]
    if missing:
        logger.error("Program.md missing required fields: %s", ", ".join(missing))
        sys.exit(1)

    if config["metric_direction"] not in ("higher", "lower"):
        logger.error("metric_direction must be 'higher' or 'lower', got: %s",
                     config["metric_direction"])
        sys.exit(1)

    return config


# ---------------------------------------------------------------------------
# Git helpers
# ---------------------------------------------------------------------------

def _git(*args, check=True, capture=True):
    """Run a git command from AIBRAIN_ROOT."""
    cmd = ["git"] + list(args)
    logger.debug("git %s", " ".join(args))
    result = subprocess.run(
        cmd,
        cwd=str(AIBRAIN_ROOT),
        capture_output=capture,
        text=True,
        check=False,
    )
    if check and result.returncode != 0:
        stderr = result.stderr.strip() if result.stderr else ""
        logger.error("git %s failed (rc=%d): %s", " ".join(args), result.returncode, stderr)
        sys.exit(1)
    return result


def _current_branch():
    r = _git("rev-parse", "--abbrev-ref", "HEAD")
    return r.stdout.strip()


def _current_commit():
    r = _git("rev-parse", "--short", "HEAD")
    return r.stdout.strip()


def _is_dirty():
    r = _git("status", "--porcelain", check=False)
    return bool(r.stdout.strip())


# ---------------------------------------------------------------------------
# Results TSV
# ---------------------------------------------------------------------------

RESULTS_HEADER = ["commit", "metric_value", "status", "description", "timestamp"]


def _results_path(tag: str) -> Path:
    return AIBRAIN_ROOT / "workflows" / "data" / f"auto_experiment_{tag}_results.tsv"


def _ensure_results(tag: str):
    """Create results.tsv with header if it doesn't exist."""
    p = _results_path(tag)
    p.parent.mkdir(parents=True, exist_ok=True)
    if not p.exists():
        with open(p, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f, delimiter="\t")
            writer.writerow(RESULTS_HEADER)
        logger.info("Created %s", p)


def _append_result(tag: str, commit: str, metric_value, status: str, description: str):
    """Append one row to results.tsv."""
    p = _results_path(tag)
    ts = datetime.datetime.now().isoformat(timespec="seconds")
    with open(p, "a", newline="", encoding="utf-8") as f:
        writer = csv.writer(f, delimiter="\t")
        writer.writerow([commit, metric_value, status, description, ts])
    logger.info("Recorded: commit=%s metric=%s status=%s", commit, metric_value, status)


def _read_results(tag: str) -> list:
    """Read all results rows as dicts."""
    p = _results_path(tag)
    if not p.exists():
        return []
    with open(p, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f, delimiter="\t")
        return list(reader)


def _best_metric(tag: str, direction: str):
    """Return the best metric value seen so far, or None."""
    rows = _read_results(tag)
    kept = [r for r in rows if r["status"] in ("kept", "baseline")]
    if not kept:
        return None
    values = []
    for r in kept:
        try:
            values.append(float(r["metric_value"]))
        except (ValueError, TypeError):
            continue
    if not values:
        return None
    return max(values) if direction == "higher" else min(values)


# ---------------------------------------------------------------------------
# State file (tracks current experiment context)
# ---------------------------------------------------------------------------

def _state_path(tag: str) -> Path:
    return AIBRAIN_ROOT / "workflows" / "data" / f"auto_experiment_{tag}_state.json"


def _load_state(tag: str) -> dict:
    import json
    p = _state_path(tag)
    if p.exists():
        return json.loads(p.read_text(encoding="utf-8"))
    return {}


def _save_state(tag: str, state: dict):
    import json
    p = _state_path(tag)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(state, indent=2), encoding="utf-8")


# ---------------------------------------------------------------------------
# Core functions
# ---------------------------------------------------------------------------

def init_run(tag: str, program_path: str):
    """Create experiment branch and initialize results.tsv."""
    branch_name = f"auto_experiment/{tag}"

    # Check if branch already exists
    r = _git("branch", "--list", branch_name, check=False)
    if r.stdout.strip():
        logger.info("Branch %s already exists, switching to it", branch_name)
        _git("checkout", branch_name)
    else:
        logger.info("Creating branch %s", branch_name)
        _git("checkout", "-b", branch_name)

    _ensure_results(tag)

    # Parse program and save state
    config = parse_program(program_path)
    state = {
        "tag": tag,
        "program_path": str(Path(program_path).resolve()),
        "branch": branch_name,
        "mutable_file": config["mutable_file"],
        "eval_command": config["eval_command"],
        "metric_name": config["metric_name"],
        "metric_direction": config["metric_direction"],
        "timeout": config.get("time_budget", 300),
        "experiment_count": 0,
        "started_at": datetime.datetime.now().isoformat(timespec="seconds"),
    }
    _save_state(tag, state)

    logger.info("Initialized auto_experiment/%s", tag)
    logger.info("  mutable_file: %s", config["mutable_file"])
    logger.info("  eval_command: %s", config["eval_command"])
    logger.info("  metric: %s (%s is better)", config["metric_name"], config["metric_direction"])

    return state


def pre_experiment(tag: str, description: str):
    """Commit the current state of the mutable file before eval."""
    state = _load_state(tag)
    if not state:
        logger.error("No experiment state for tag '%s'. Run init first.", tag)
        sys.exit(1)

    mutable = Path(state["mutable_file"])
    if not mutable.is_absolute():
        mutable = AIBRAIN_ROOT / mutable

    if not mutable.exists():
        logger.error("Mutable file not found: %s", mutable)
        sys.exit(1)

    # Stage and commit the mutable file
    _git("add", str(mutable))

    if not _is_dirty():
        # Check if there are staged changes
        r = _git("diff", "--cached", "--quiet", check=False)
        if r.returncode == 0:
            logger.warning("No changes to commit. Mutable file unchanged.")
            return _current_commit()

    n = state.get("experiment_count", 0) + 1
    msg = f"auto_experiment({tag}) #{n}: {description}"
    _git("commit", "-m", msg)

    state["experiment_count"] = n
    state["last_description"] = description
    state["last_commit"] = _current_commit()
    _save_state(tag, state)

    logger.info("Committed experiment #%d: %s", n, _current_commit())
    return _current_commit()


def run_eval(tag: str, timeout: int = None) -> dict:
    """Execute the eval command, capture output, parse metric."""
    state = _load_state(tag)
    if not state:
        logger.error("No experiment state for tag '%s'. Run init first.", tag)
        sys.exit(1)

    cmd = state["eval_command"]
    metric_name = state["metric_name"]
    if timeout is None:
        timeout = int(state.get("timeout", 300))

    logger.info("Running eval: %s (timeout: %ds)", cmd, timeout)

    # Split string commands into list to avoid shell=True (command injection risk)
    if isinstance(cmd, str):
        import shlex
        cmd = shlex.split(cmd)

    try:
        result = subprocess.run(
            cmd,
            shell=False,
            cwd=str(AIBRAIN_ROOT),
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        output = result.stdout + "\n" + result.stderr
        exit_code = result.returncode
    except subprocess.TimeoutExpired:
        logger.error("Eval timed out after %d seconds", timeout)
        output = ""
        exit_code = -1

    if exit_code != 0 and exit_code != -1:
        logger.warning("Eval exited with code %d", exit_code)

    # Parse metric from output
    metric_value = parse_metric(output, metric_name)

    eval_result = {
        "output": output,
        "exit_code": exit_code,
        "metric_value": metric_value,
        "metric_name": metric_name,
        "timed_out": exit_code == -1,
    }

    state["last_eval"] = {
        "exit_code": exit_code,
        "metric_value": metric_value,
        "timed_out": exit_code == -1,
        "timestamp": datetime.datetime.now().isoformat(timespec="seconds"),
    }
    _save_state(tag, state)

    if metric_value is not None:
        logger.info("Metric '%s' = %s", metric_name, metric_value)
    else:
        logger.warning("Could not parse metric '%s' from eval output", metric_name)

    # Print output for the calling agent to see
    print("--- EVAL OUTPUT ---")
    print(output.strip())
    print("--- END EVAL OUTPUT ---")
    if metric_value is not None:
        print(f"\nMETRIC: {metric_name} = {metric_value}")

    return eval_result


def parse_metric(output: str, metric_name: str):
    """
    Extract a named metric from eval output.

    Supports common formats:
      - metric_name: 0.85
      - metric_name = 0.85
      - metric_name=0.85
      - METRIC: metric_name 0.85
      - {"metric_name": 0.85}  (JSON-like)
    """
    if not output:
        return None

    # Normalize metric name for matching (case-insensitive)
    name_pattern = re.escape(metric_name).replace(r"\_", r"[_\s-]")

    patterns = [
        # key: value or key = value
        rf"(?i){name_pattern}\s*[:=]\s*(-?\d+(?:\.\d+)?(?:e[+-]?\d+)?)",
        # METRIC: name value
        rf"(?i)METRIC:\s*{name_pattern}\s+(-?\d+(?:\.\d+)?(?:e[+-]?\d+)?)",
        # JSON-style "name": value
        rf'(?i)"{metric_name}"\s*:\s*(-?\d+(?:\.\d+)?(?:e[+-]?\d+)?)',
    ]

    for pattern in patterns:
        match = re.search(pattern, output)
        if match:
            try:
                return float(match.group(1))
            except ValueError:
                continue

    return None


def keep_or_revert(tag: str) -> str:
    """
    Compare current metric against best. Keep if improved, revert if not.

    Returns: "kept", "reverted", "baseline", or "error"
    """
    state = _load_state(tag)
    if not state:
        logger.error("No experiment state for tag '%s'.", tag)
        return "error"

    last_eval = state.get("last_eval", {})
    metric_value = last_eval.get("metric_value")
    direction = state["metric_direction"]
    commit = state.get("last_commit", _current_commit())
    description = state.get("last_description", "")

    # Handle eval failure
    if last_eval.get("timed_out"):
        logger.warning("Eval timed out — reverting")
        _append_result(tag, commit, "TIMEOUT", "reverted", description)
        _git("reset", "--hard", "HEAD~1")
        state["last_eval"] = {}
        _save_state(tag, state)
        print("DECISION: reverted (eval timed out)")
        return "reverted"

    if last_eval.get("exit_code", 0) != 0 and metric_value is None:
        logger.warning("Eval failed with no metric — reverting")
        _append_result(tag, commit, "EVAL_FAIL", "reverted", description)
        _git("reset", "--hard", "HEAD~1")
        state["last_eval"] = {}
        _save_state(tag, state)
        print("DECISION: reverted (eval failed)")
        return "reverted"

    if metric_value is None:
        logger.warning("No metric parsed — reverting")
        _append_result(tag, commit, "NO_METRIC", "reverted", description)
        _git("reset", "--hard", "HEAD~1")
        state["last_eval"] = {}
        _save_state(tag, state)
        print("DECISION: reverted (no metric parsed)")
        return "reverted"

    best = _best_metric(tag, direction)

    # First result is baseline
    if best is None:
        logger.info("First measurement — recording as baseline: %s", metric_value)
        _append_result(tag, commit, metric_value, "baseline", description)
        state["last_eval"] = {}
        _save_state(tag, state)
        print(f"DECISION: baseline ({state['metric_name']} = {metric_value})")
        return "baseline"

    # Compare
    improved = (
        (direction == "higher" and metric_value > best) or
        (direction == "lower" and metric_value < best)
    )

    if improved:
        logger.info("Improved: %s -> %s (best was %s) — keeping", metric_value, metric_value, best)
        _append_result(tag, commit, metric_value, "kept", description)
        state["last_eval"] = {}
        _save_state(tag, state)
        delta = metric_value - best
        print(f"DECISION: kept ({state['metric_name']} = {metric_value}, "
              f"delta = {delta:+.6f}, best was {best})")
        return "kept"
    else:
        logger.info("No improvement: %s vs best %s — reverting", metric_value, best)
        _append_result(tag, commit, metric_value, "reverted", description)
        _git("reset", "--hard", "HEAD~1")
        state["last_eval"] = {}
        _save_state(tag, state)
        print(f"DECISION: reverted ({state['metric_name']} = {metric_value}, "
              f"best = {best}, no improvement)")
        return "reverted"


def record_result(tag: str, metric_value, status: str, description: str):
    """Manually record a result (for agent-driven flows)."""
    commit = _current_commit()
    _append_result(tag, commit, metric_value, status, description)


def summary(tag: str):
    """Print experiment summary: best result, total runs, improvement from baseline."""
    state = _load_state(tag)
    rows = _read_results(tag)

    if not rows:
        print("No results yet.")
        return

    direction = state.get("metric_direction", "higher")

    # Gather stats
    total = len(rows)
    kept = [r for r in rows if r["status"] == "kept"]
    reverted = [r for r in rows if r["status"] == "reverted"]
    baselines = [r for r in rows if r["status"] == "baseline"]

    # Find baseline value
    baseline_val = None
    if baselines:
        try:
            baseline_val = float(baselines[0]["metric_value"])
        except (ValueError, TypeError):
            pass

    # Find best
    best_val = _best_metric(tag, direction)
    best_row = None
    if best_val is not None:
        for r in rows:
            try:
                if float(r["metric_value"]) == best_val and r["status"] in ("kept", "baseline"):
                    best_row = r
                    break
            except (ValueError, TypeError):
                continue

    print("=" * 60)
    print(f"Auto-Experiment Summary: {tag}")
    print("=" * 60)
    print(f"  Total experiments:  {total}")
    print(f"  Kept (improved):    {len(kept)}")
    print(f"  Reverted:           {len(reverted)}")
    print(f"  Baseline runs:      {len(baselines)}")
    print(f"  Metric:             {state.get('metric_name', '?')} ({direction} is better)")

    if baseline_val is not None:
        print(f"  Baseline value:     {baseline_val}")

    if best_val is not None:
        print(f"  Best value:         {best_val}")
        if best_row:
            print(f"  Best commit:        {best_row['commit']}")
            print(f"  Best description:   {best_row['description']}")

    if baseline_val is not None and best_val is not None and baseline_val != best_val:
        abs_improvement = best_val - baseline_val
        if baseline_val != 0:
            pct_improvement = (abs_improvement / abs(baseline_val)) * 100
            print(f"  Improvement:        {abs_improvement:+.6f} ({pct_improvement:+.2f}%)")
        else:
            print(f"  Improvement:        {abs_improvement:+.6f}")

    print("=" * 60)

    # Print last 10 results
    print("\nRecent results:")
    print(f"  {'Commit':<10} {'Metric':<15} {'Status':<10} {'Description'}")
    print(f"  {'-'*10} {'-'*15} {'-'*10} {'-'*30}")
    for r in rows[-10:]:
        print(f"  {r['commit']:<10} {r['metric_value']:<15} {r['status']:<10} "
              f"{r['description'][:40]}")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Auto-Experiment Harness — eval runner + git manager for optimization loops",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Subcommands:
  init             Create branch and initialize experiment
  pre-experiment   Commit mutable file changes before eval
  run-eval         Execute eval command and parse metric
  decide           Keep if improved, revert if not
  record           Manually record a result
  summary          Print experiment summary

Example agent-driven loop:
  python auto_experiment.py -p program.md init --tag selroute
  # agent modifies mutable file...
  python auto_experiment.py -p program.md pre-experiment --desc "increase temp"
  python auto_experiment.py -p program.md run-eval
  python auto_experiment.py -p program.md decide
  python auto_experiment.py -p program.md summary
        """,
    )
    parser.add_argument("-p", "--program", required=True,
                        help="Path to program.md skill file")
    parser.add_argument("--timeout", type=int, default=None,
                        help="Override eval timeout in seconds (default: from program.md)")
    parser.add_argument("--verbose", "-v", action="store_true",
                        help="Enable debug logging")

    sub = parser.add_subparsers(dest="command", required=True)

    # init
    p_init = sub.add_parser("init", help="Create branch and initialize experiment")
    p_init.add_argument("--tag", required=True,
                        help="Experiment tag (used for branch name and results file)")

    # pre-experiment
    p_pre = sub.add_parser("pre-experiment",
                           help="Commit mutable file changes before eval")
    p_pre.add_argument("--tag", required=True, help="Experiment tag")
    p_pre.add_argument("--desc", required=True,
                       help="Description of what changed")

    # run-eval
    p_eval = sub.add_parser("run-eval", help="Execute eval command and parse metric")
    p_eval.add_argument("--tag", required=True, help="Experiment tag")

    # decide
    p_decide = sub.add_parser("decide", help="Keep if improved, revert if not")
    p_decide.add_argument("--tag", required=True, help="Experiment tag")

    # record (manual)
    p_record = sub.add_parser("record", help="Manually record a result")
    p_record.add_argument("--tag", required=True, help="Experiment tag")
    p_record.add_argument("--metric", required=True, type=float, help="Metric value")
    p_record.add_argument("--status", required=True,
                          choices=["kept", "reverted", "baseline", "manual"],
                          help="Result status")
    p_record.add_argument("--desc", default="", help="Description")

    # summary
    p_summary = sub.add_parser("summary", help="Print experiment summary")
    p_summary.add_argument("--tag", required=True, help="Experiment tag")

    args = parser.parse_args()

    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    if args.command == "init":
        init_run(args.tag, args.program)

    elif args.command == "pre-experiment":
        pre_experiment(args.tag, args.desc)

    elif args.command == "run-eval":
        run_eval(args.tag, timeout=args.timeout)

    elif args.command == "decide":
        result = keep_or_revert(args.tag)
        sys.exit(0 if result in ("kept", "baseline") else 1)

    elif args.command == "record":
        record_result(args.tag, args.metric, args.status, args.desc)

    elif args.command == "summary":
        summary(args.tag)


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name='auto_experiment',
        action=_workflow_entry,
        task_type='complex',
        actor='cli',
    )
