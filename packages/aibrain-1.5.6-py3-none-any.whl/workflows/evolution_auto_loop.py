#!/usr/bin/env python3
"""
AIBrain Workflow: Evolution Auto-Loop

Wires knowledge graph insights into the evolution engine to create
an autonomous improvement cycle:

  1. Read knowledge graph (entities, facts, hyperedges)
  2. Detect cross-domain patterns and contradictions
  3. Generate improvement hypotheses automatically
  4. Check existing experiments — decide keep/revert for mature ones
  5. Start new experiments from top-priority hypotheses
  6. Apply accepted changes as principles

This runs on a schedule (default: every 12h) and drives the
self-improvement loop that makes the system compound its intelligence.

Usage:
    python evolution_auto_loop.py              # Full cycle
    python evolution_auto_loop.py --dry-run    # Analyze only, no changes
    python evolution_auto_loop.py --status     # Show current loop state
    python evolution_auto_loop.py --apply      # Apply all accepted hypotheses
"""

import argparse
import json
import logging
import os
import sqlite3
import sys
from datetime import datetime, timedelta
from pathlib import Path

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

from aibrain_db import AIBRAIN_ROOT, get_db
_cfg_path = AIBRAIN_ROOT / "config.json"
CONFIG = json.loads(_cfg_path.read_text()) if _cfg_path.exists() else {}

def _find_db():
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    return str(AIBRAIN_ROOT / "aibrain.db")

MEMORY_DB = CONFIG.get("db_path", _find_db())

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("evolution_auto_loop")

# Hypothesis generation thresholds
MIN_ENTITY_MENTIONS = 5       # entity must appear 5+ times to be worth analyzing
MIN_HYPEREDGE_OVERLAP = 3     # 3+ shared entities to consider cross-domain
CONTRADICTION_PREDICATES = {"replaces", "fixed_by", "caused_by"}
GROWTH_PREDICATES = {"uses", "depends_on", "integrates_with", "is_a"}

# ---------------------------------------------------------------------------
# DB helpers
# ---------------------------------------------------------------------------

def get_db():
    db = get_db()
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA journal_mode=WAL")
    return db


def _ensure_evolution_tables(db):
    """Ensure evolution tables exist (idempotent)."""
    # Import and run the schema creation
    sys.path.insert(0, str(AIBRAIN_ROOT / "backend"))
    try:
        from evolution_engine import get_evolution_db
        edb = get_evolution_db(Path(MEMORY_DB))
        edb.close()
    except ImportError:
        logger.warning("evolution_engine not found, tables may not exist")


def _log_activity(workflow, summary, db=None):
    """Log workflow activity to activity_log table."""
    close = False
    if db is None:
        db = get_db()
        close = True
    try:
        db.execute(
            "INSERT INTO activity_log (workflow, summary, created_at) VALUES (?, ?, ?)",
            (workflow, json.dumps(summary) if isinstance(summary, dict) else str(summary),
             datetime.utcnow().isoformat())
        )
        db.commit()
    except sqlite3.OperationalError:
        pass
    if close:
        db.close()


# ---------------------------------------------------------------------------
# Step 1: Read Knowledge Graph State
# ---------------------------------------------------------------------------

def read_graph_state(db):
    """Pull current knowledge graph statistics and key patterns."""
    state = {}

    # Entity counts and top entities
    try:
        state["total_entities"] = db.execute("SELECT COUNT(*) FROM entities").fetchone()[0]
        top = db.execute(
            "SELECT name, type, mention_count FROM entities WHERE mention_count >= ? ORDER BY mention_count DESC LIMIT 20",
            (MIN_ENTITY_MENTIONS,)
        ).fetchall()
        state["top_entities"] = [dict(r) for r in top]
    except sqlite3.OperationalError:
        state["total_entities"] = 0
        state["top_entities"] = []

    # Semantic facts
    try:
        state["total_facts"] = db.execute("SELECT COUNT(*) FROM semantic_facts").fetchone()[0]
        # Get facts by predicate
        predicates = db.execute(
            "SELECT predicate, COUNT(*) as cnt FROM semantic_facts GROUP BY predicate ORDER BY cnt DESC"
        ).fetchall()
        state["fact_predicates"] = {r["predicate"]: r["cnt"] for r in predicates}
    except sqlite3.OperationalError:
        state["total_facts"] = 0
        state["fact_predicates"] = {}

    # Hyperedges (cross-memory connections)
    try:
        state["total_hyperedges"] = db.execute("SELECT COUNT(*) FROM hyperedges").fetchone()[0]
    except sqlite3.OperationalError:
        state["total_hyperedges"] = 0

    # Co-occurrence links
    try:
        state["total_cooccurrences"] = db.execute("SELECT COUNT(*) FROM entity_cooccurrence").fetchone()[0]
        # Top co-occurring pairs
        top_cooc = db.execute(
            """SELECT e1.name as entity1, e2.name as entity2, c.co_count
               FROM entity_cooccurrence c
               JOIN entities e1 ON c.entity_id_1 = e1.id
               JOIN entities e2 ON c.entity_id_2 = e2.id
               ORDER BY c.co_count DESC LIMIT 10"""
        ).fetchall()
        state["top_cooccurrences"] = [dict(r) for r in top_cooc]
    except sqlite3.OperationalError:
        state["total_cooccurrences"] = 0
        state["top_cooccurrences"] = []

    return state


# ---------------------------------------------------------------------------
# Step 2: Detect Cross-Domain Patterns
# ---------------------------------------------------------------------------

def detect_cross_domain_patterns(db):
    """Find patterns that span multiple domains — these are hypothesis candidates."""
    patterns = []

    # Pattern A: Entities appearing in contradictory facts
    # e.g., X "replaces" Y but also X "depends_on" Y → tension worth investigating
    try:
        contradictions = db.execute(
            """SELECT f1.subject, f1.predicate as pred1, f1.object as obj1,
                      f2.predicate as pred2, f2.object as obj2
               FROM semantic_facts f1
               JOIN semantic_facts f2 ON f1.subject = f2.subject AND f1.id != f2.id
               WHERE f1.predicate IN ('replaces', 'fixed_by', 'caused_by')
                 AND f2.predicate IN ('uses', 'depends_on', 'integrates_with')
               LIMIT 20"""
        ).fetchall()
        for c in contradictions:
            patterns.append({
                "type": "contradiction",
                "description": f"'{c['subject']}' {c['pred1']} '{c['obj1']}' but also {c['pred2']} '{c['obj2']}'",
                "subject": c["subject"],
                "impact": 0.7,
                "confidence": 0.6,
            })
    except sqlite3.OperationalError:
        pass

    # Pattern B: High-frequency entities without corresponding workflows
    # Something mentioned a lot but not yet automated
    try:
        frequent = db.execute(
            """SELECT name, type, mention_count FROM entities
               WHERE mention_count >= 10 AND type IN ('tool', 'system', 'workflow', 'concept')
               ORDER BY mention_count DESC LIMIT 15"""
        ).fetchall()
        for e in frequent:
            patterns.append({
                "type": "high_frequency_entity",
                "description": f"'{e['name']}' ({e['type']}) mentioned {e['mention_count']}x — potential automation target",
                "subject": e["name"],
                "impact": 0.5,
                "confidence": 0.4,
            })
    except sqlite3.OperationalError:
        pass

    # Pattern C: Dense clusters via hyperedges — memories with many shared entities
    # indicate a topic that could benefit from consolidation or a dedicated workflow
    try:
        dense_hyperedges = db.execute(
            """SELECT h.id, h.label, h.confidence, COUNT(hm.memory_id) as member_count
               FROM hyperedges h
               JOIN hyperedge_members hm ON h.id = hm.hyperedge_id
               GROUP BY h.id
               HAVING member_count >= 4
               ORDER BY member_count DESC
               LIMIT 10"""
        ).fetchall()
        for h in dense_hyperedges:
            patterns.append({
                "type": "dense_cluster",
                "description": f"Hyperedge {h['id']}: {h['member_count']} memories share knowledge — potential consolidation target",
                "subject": f"hyperedge_{h['id']}",
                "impact": 0.6,
                "confidence": 0.5,
            })
    except sqlite3.OperationalError:
        pass

    # Pattern D: Facts with "learned" predicate — these are applied principles
    # that should be checked for consistency and reinforcement
    try:
        learned = db.execute(
            "SELECT subject, object FROM semantic_facts WHERE predicate = 'learned' ORDER BY created_at DESC LIMIT 10"
        ).fetchall()
        for l in learned:
            patterns.append({
                "type": "applied_learning",
                "description": f"Learned: '{l['subject']}' → '{l['object']}' — verify still valid",
                "subject": l["subject"],
                "impact": 0.4,
                "confidence": 0.7,
            })
    except sqlite3.OperationalError:
        pass

    return patterns


# ---------------------------------------------------------------------------
# Step 3: Generate Hypotheses from Patterns
# ---------------------------------------------------------------------------

def generate_hypotheses(db, patterns, dry_run=False):
    """Convert cross-domain patterns into evolution hypotheses."""
    generated = []

    for pattern in patterns:
        # Check if a hypothesis already exists for this subject
        existing = db.execute(
            """SELECT id FROM evolution_hypotheses
               WHERE hypothesis LIKE ? AND status IN ('proposed', 'testing', 'accepted')""",
            (f"%{pattern['subject'][:50]}%",)
        ).fetchone()

        if existing:
            continue  # Already have an active hypothesis for this

        # Find or create the evolution pattern
        evo_pattern = db.execute(
            "SELECT id FROM evolution_patterns WHERE pattern LIKE ? AND status = 'active'",
            (f"%{pattern['subject'][:50]}%",)
        ).fetchone()

        if not evo_pattern and not dry_run:
            cur = db.execute(
                "INSERT INTO evolution_patterns (pattern, frequency, severity) VALUES (?, 1, 'medium')",
                (pattern["description"],)
            )
            pattern_id = cur.lastrowid
        elif evo_pattern:
            pattern_id = evo_pattern["id"]
        else:
            pattern_id = None

        # Generate hypothesis based on pattern type
        if pattern["type"] == "contradiction":
            hypothesis = f"Resolve contradiction: {pattern['description']}. Investigate whether dependency is still needed or can be removed."
            change_type = "rule"
        elif pattern["type"] == "high_frequency_entity":
            hypothesis = f"Automate or optimize '{pattern['subject']}' — high mention frequency suggests manual overhead that could be reduced."
            change_type = "workflow"
        elif pattern["type"] == "dense_cluster":
            hypothesis = f"Consolidate knowledge in {pattern['subject']} — multiple memories overlap, consider merging or creating a summary workflow."
            change_type = "workflow"
        elif pattern["type"] == "applied_learning":
            hypothesis = f"Verify learned principle: {pattern['description']} — check if still valid and being applied consistently."
            change_type = "rule"
        else:
            hypothesis = f"Investigate: {pattern['description']}"
            change_type = "config"

        if not dry_run and pattern_id:
            cur = db.execute(
                """INSERT INTO evolution_hypotheses
                   (pattern_id, hypothesis, change_type, impact_score, confidence, status)
                   VALUES (?, ?, ?, ?, ?, 'proposed')""",
                (pattern_id, hypothesis, change_type, pattern["impact"], pattern["confidence"])
            )
            generated.append({
                "id": cur.lastrowid,
                "hypothesis": hypothesis,
                "type": change_type,
                "priority": pattern["impact"] * pattern["confidence"],
            })
        else:
            generated.append({
                "id": None,
                "hypothesis": hypothesis,
                "type": change_type,
                "priority": pattern["impact"] * pattern["confidence"],
            })

    return generated


# ---------------------------------------------------------------------------
# Step 4: Process Experiments
# ---------------------------------------------------------------------------

def process_experiments(db, dry_run=False):
    """Check experiments: decide mature ones, start new ones from top hypotheses."""
    results = {"decided": [], "started": []}

    # Decide mature experiments (runs_completed >= runs_target)
    ready = db.execute(
        """SELECT e.id, e.hypothesis_id, e.baseline_metrics, e.experiment_metrics,
                  e.runs_completed, e.runs_target, h.hypothesis, h.change_type
           FROM evolution_experiments e
           JOIN evolution_hypotheses h ON e.hypothesis_id = h.id
           WHERE e.decision IS NULL AND e.runs_completed >= e.runs_target"""
    ).fetchall()

    for exp in ready:
        baseline = json.loads(exp["baseline_metrics"]) if exp["baseline_metrics"] else {}
        current = json.loads(exp["experiment_metrics"]) if exp["experiment_metrics"] else {}

        # Simple decision: if any metric improved and none degraded significantly, keep
        if current and baseline:
            improved = any(current.get(k, 0) > baseline.get(k, 0) for k in baseline)
            degraded = any(current.get(k, 0) < baseline.get(k, 0) * 0.9 for k in baseline)
            decision = "keep" if improved and not degraded else "revert"
        else:
            decision = "extend"  # Not enough data

        reason = f"Auto-decided: improved={improved if current and baseline else 'N/A'}, degraded={degraded if current and baseline else 'N/A'}"

        if not dry_run:
            now = datetime.utcnow().isoformat()
            db.execute(
                """UPDATE evolution_experiments
                   SET ended_at = ?, decision = ?, decision_reason = ?
                   WHERE id = ?""",
                (now, decision, reason, exp["id"])
            )
            status = "accepted" if decision == "keep" else "rejected" if decision == "revert" else "testing"
            db.execute(
                "UPDATE evolution_hypotheses SET status = ? WHERE id = ?",
                (status, exp["hypothesis_id"])
            )

        results["decided"].append({
            "experiment_id": exp["id"],
            "hypothesis": exp["hypothesis"],
            "decision": decision,
            "reason": reason,
        })

    # Start new experiments from top-priority proposed hypotheses
    top = db.execute(
        """SELECT id, hypothesis, change_type, impact_score, confidence, priority
           FROM evolution_hypotheses
           WHERE status = 'proposed'
           ORDER BY priority DESC
           LIMIT 3"""
    ).fetchall()

    for hyp in top:
        # Check tier limit before starting new experiment
        try:
            from aibrain_licensing import check_limit
            check_limit("experiments_per_week")
        except ImportError:
            pass
        except Exception:
            logger.info("Experiment limit reached (free tier) — skipping new experiments")
            break

        if not dry_run:
            db.execute("UPDATE evolution_hypotheses SET status = 'testing' WHERE id = ?", (hyp["id"],))
            db.execute(
                """INSERT INTO evolution_experiments
                   (hypothesis_id, baseline_metrics, runs_target)
                   VALUES (?, '{}', 5)""",
                (hyp["id"],)
            )
        results["started"].append({
            "hypothesis_id": hyp["id"],
            "hypothesis": hyp["hypothesis"],
            "priority": hyp["priority"],
        })

    return results


# ---------------------------------------------------------------------------
# Step 5: Apply Accepted Principles
# ---------------------------------------------------------------------------

def apply_accepted_principles(db, dry_run=False):
    """Take accepted hypotheses and record them as positive patterns (applied principles)."""
    applied = []

    accepted = db.execute(
        """SELECT h.id, h.hypothesis, h.change_type, h.target, h.proposed_change,
                  p.pattern as source_pattern
           FROM evolution_hypotheses h
           LEFT JOIN evolution_patterns p ON h.pattern_id = p.id
           WHERE h.status = 'accepted'
           AND NOT EXISTS (
               SELECT 1 FROM evolution_positive_patterns pp
               WHERE pp.pattern LIKE '%' || SUBSTR(h.hypothesis, 1, 50) || '%'  # noqa:like-wildcard-injection — hardcoded static substrings, no user input
           )"""
    ).fetchall()

    for hyp in accepted:
        if not dry_run:
            db.execute(
                """INSERT INTO evolution_positive_patterns
                   (pattern, principle, source_domain, strength)
                   VALUES (?, ?, ?, 'confirmed')""",
                (hyp["hypothesis"],
                 f"Validated improvement: {hyp['change_type']} change to {hyp['target'] or 'system'}",
                 hyp["source_pattern"] or "unknown")
            )
        applied.append({
            "hypothesis": hyp["hypothesis"],
            "type": hyp["change_type"],
        })

    return applied


# ---------------------------------------------------------------------------
# Main Loop
# ---------------------------------------------------------------------------

def run_auto_loop(dry_run=False):
    """Execute the full evolution auto-loop."""
    logger.info("=== EVOLUTION AUTO-LOOP START ===")
    db = get_db()
    _ensure_evolution_tables(db)

    # Step 1: Read knowledge graph
    logger.info("Step 1: Reading knowledge graph state...")
    graph_state = read_graph_state(db)
    logger.info(f"  Entities: {graph_state['total_entities']}, Facts: {graph_state['total_facts']}, "
                f"Hyperedges: {graph_state['total_hyperedges']}")

    if graph_state["total_entities"] == 0:
        logger.warning("Knowledge graph is empty — run knowledge_graph_builder first")
        db.close()
        return {"error": "empty_graph", "message": "Run knowledge_graph_builder.py first"}

    # Step 2: Detect cross-domain patterns
    logger.info("Step 2: Detecting cross-domain patterns...")
    patterns = detect_cross_domain_patterns(db)
    logger.info(f"  Found {len(patterns)} patterns")

    # Step 3: Generate hypotheses
    logger.info("Step 3: Generating hypotheses...")
    hypotheses = generate_hypotheses(db, patterns, dry_run=dry_run)
    new_count = sum(1 for h in hypotheses if h["id"] is not None)
    logger.info(f"  Generated {new_count} new hypotheses ({len(hypotheses) - new_count} already existed)")

    # Step 4: Process experiments
    logger.info("Step 4: Processing experiments...")
    experiment_results = process_experiments(db, dry_run=dry_run)
    logger.info(f"  Decided: {len(experiment_results['decided'])}, Started: {len(experiment_results['started'])}")

    # Step 5: Apply accepted principles
    logger.info("Step 5: Applying accepted principles...")
    applied = apply_accepted_principles(db, dry_run=dry_run)
    logger.info(f"  Applied {len(applied)} new principles")

    if not dry_run:
        db.commit()

    summary = {
        "graph": {
            "entities": graph_state["total_entities"],
            "facts": graph_state["total_facts"],
            "hyperedges": graph_state["total_hyperedges"],
            "cooccurrences": graph_state["total_cooccurrences"],
        },
        "patterns_detected": len(patterns),
        "hypotheses_generated": new_count,
        "experiments_decided": len(experiment_results["decided"]),
        "experiments_started": len(experiment_results["started"]),
        "principles_applied": len(applied),
        "dry_run": dry_run,
        "top_hypotheses": sorted(hypotheses, key=lambda h: h["priority"], reverse=True)[:5],
        "decisions": experiment_results["decided"],
        "new_principles": applied,
    }

    _log_activity("evolution_auto_loop", summary, db)
    db.close()

    logger.info("=== EVOLUTION AUTO-LOOP COMPLETE ===")
    logger.info(f"  Patterns: {len(patterns)} | Hypotheses: {new_count} | "
                f"Decided: {len(experiment_results['decided'])} | "
                f"Started: {len(experiment_results['started'])} | "
                f"Applied: {len(applied)}")

    return summary


def show_status():
    """Show current evolution loop state."""
    db = get_db()
    _ensure_evolution_tables(db)

    print("\n=== EVOLUTION LOOP STATUS ===\n")

    # Active patterns
    patterns = db.execute(
        "SELECT COUNT(*) FROM evolution_patterns WHERE status = 'active'"
    ).fetchone()[0]
    print(f"Active patterns:     {patterns}")

    # Hypotheses by status
    for status in ["proposed", "testing", "accepted", "rejected"]:
        count = db.execute(
            "SELECT COUNT(*) FROM evolution_hypotheses WHERE status = ?", (status,)
        ).fetchone()[0]
        print(f"Hypotheses ({status:8s}): {count}")

    # Active experiments
    active_exp = db.execute(
        "SELECT COUNT(*) FROM evolution_experiments WHERE decision IS NULL"
    ).fetchone()[0]
    decided_exp = db.execute(
        "SELECT COUNT(*) FROM evolution_experiments WHERE decision IS NOT NULL"
    ).fetchone()[0]
    print(f"Experiments active:  {active_exp}")
    print(f"Experiments decided: {decided_exp}")

    # Positive patterns (applied principles)
    try:
        principles = db.execute("SELECT COUNT(*) FROM evolution_positive_patterns").fetchone()[0]
        print(f"Applied principles:  {principles}")
    except sqlite3.OperationalError:
        print(f"Applied principles:  0")

    # Last cycle
    try:
        last = db.execute(
            "SELECT completed_at, summary FROM evolution_cycles ORDER BY id DESC LIMIT 1"
        ).fetchone()
        if last:
            print(f"\nLast cycle: {last['completed_at']}")
    except sqlite3.OperationalError:
        pass

    # Top proposed hypotheses
    top = db.execute(
        """SELECT hypothesis, priority FROM evolution_hypotheses
           WHERE status = 'proposed' ORDER BY priority DESC LIMIT 5"""
    ).fetchall()
    if top:
        print("\nTop proposed hypotheses:")
        for h in top:
            print(f"  [{h['priority']:.2f}] {h['hypothesis'][:80]}")

    db.close()
    print()


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        parser = argparse.ArgumentParser(description="Evolution Auto-Loop")
        parser.add_argument("--dry-run", action="store_true", help="Analyze only, no changes")
        parser.add_argument("--status", action="store_true", help="Show current loop state")
        parser.add_argument("--apply", action="store_true", help="Apply all accepted hypotheses")
        args = parser.parse_args()

        if args.status:
            show_status()
        elif args.apply:
            db = get_db()
            _ensure_evolution_tables(db)
            applied = apply_accepted_principles(db)
            db.commit()
            db.close()
            print(f"Applied {len(applied)} principles")
        else:
            result = run_auto_loop(dry_run=args.dry_run)
            if "error" not in result:
                print(json.dumps(result, indent=2, default=str))
    workflow_execute(
        workflow_name='evolution_auto_loop',
        action=_workflow_entry,
        task_type='judgment',
        actor='cli',
    )
