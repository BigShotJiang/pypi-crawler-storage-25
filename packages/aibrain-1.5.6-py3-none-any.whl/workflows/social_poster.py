"""
social_poster.py — Format and distribute social media posts.

Usage:
    python social_poster.py --platform linkedin --text "Post text here"
    python social_poster.py --platform twitter --content post.md
    python social_poster.py --platform twitter --content post.md --thread
    python social_poster.py --platform linkedin --text "Post text" --clipboard
    python social_poster.py --platform linkedin --text "Post text" --telegram
    python social_poster.py --platform mastodon --text "Post text" --output formatted.txt

Platforms:
    linkedin  — Professional tone, hashtags, 1300 char max
    twitter   — Punchy, 280 chars, --thread for multi-tweet
    mastodon  — 500 char limit, hashtags

Current mode: format + output only. API posting when OAuth tokens are configured.
Reads tokens from ~/.decker_env (LINKEDIN_ACCESS_TOKEN, TWITTER_API_KEY, etc.)
"""

import argparse
import json
import os
import re
import subprocess
import sys
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import URLError

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

# Load credentials from .decker_env if env vars not set
DECKER_ENV = Path.home() / ".decker_env"
if DECKER_ENV.exists():
    for _line in DECKER_ENV.read_text(encoding="utf-8").splitlines():
        _line = _line.strip()
        if _line and not _line.startswith("#") and "=" in _line:
            _k, _v = _line.split("=", 1)
            os.environ.setdefault(_k.strip(), _v.strip())

TELEGRAM_TOKEN = os.environ.get("TELEGRAM_TOKEN", "")
TELEGRAM_CHAT_ID = os.environ.get("TELEGRAM_DM_ID", "8267616606")

PLATFORM_LIMITS = {
    "linkedin": 1300,
    "twitter": 280,
    "mastodon": 500,
}


def load_env() -> dict[str, str]:
    """Parse .decker_env into a dict."""
    env = {}
    if not DECKER_ENV.exists():
        return env
    for line in DECKER_ENV.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" in line:
            k, v = line.split("=", 1)
            env[k.strip()] = v.strip()
    return env


# ---------------------------------------------------------------------------
# Formatters
# ---------------------------------------------------------------------------

def format_linkedin(text: str) -> str:
    """Format text for LinkedIn: professional tone, add spacing, enforce limit."""
    formatted = text.strip()

    # Extract hashtag lines from the end
    lines = formatted.split("\n")
    hashtag_lines = []
    # Walk backwards, collecting hashtag-only lines
    i = len(lines) - 1
    while i >= 0:
        stripped = lines[i].strip()
        if stripped.startswith("#") and not stripped.startswith("# "):
            hashtag_lines.insert(0, lines[i])
            i -= 1
        elif stripped == "":
            i -= 1  # skip blank lines between content and hashtags
        else:
            break
    content_lines = lines[:i + 1]

    content = "\n".join(content_lines).strip() if content_lines else formatted
    hashtags = "\n".join(hashtag_lines).strip()

    # Enforce 1300 char limit
    limit = PLATFORM_LIMITS["linkedin"]
    if len(content) + len(hashtags) + 2 > limit:
        available = limit - len(hashtags) - 5  # room for "...\n\n"
        content = content[:available].rsplit(" ", 1)[0] + "..."

    result = content
    if hashtags:
        result += "\n\n" + hashtags

    return result


def format_twitter(text: str, thread: bool = False) -> str | list[str]:
    """Format for Twitter: punchy, 280 chars.

    If thread=True, split into multiple tweets.
    """
    limit = PLATFORM_LIMITS["twitter"]

    if not thread:
        if len(text) <= limit:
            return text.strip()
        # Truncate to fit
        return text[:limit - 3].rsplit(" ", 1)[0] + "..."

    # Thread mode: split on paragraph breaks or sentence boundaries
    paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]

    tweets = []
    current = ""

    for para in paragraphs:
        if len(current) + len(para) + 2 <= limit:
            current = (current + "\n\n" + para).strip() if current else para
        else:
            if current:
                tweets.append(current)
            # If a single paragraph exceeds limit, split on sentences
            if len(para) > limit:
                sentences = re.split(r'(?<=[.!?])\s+', para)
                current = ""
                for sentence in sentences:
                    if len(current) + len(sentence) + 1 <= limit:
                        current = (current + " " + sentence).strip() if current else sentence
                    else:
                        if current:
                            tweets.append(current)
                        current = sentence
            else:
                current = para

    if current:
        tweets.append(current)

    # Add thread numbering
    if len(tweets) > 1:
        total = len(tweets)
        tweets = [f"{t}\n\n({i+1}/{total})" for i, t in enumerate(tweets)]

    return tweets


def format_mastodon(text: str) -> str:
    """Format for Mastodon: 500 char limit."""
    limit = PLATFORM_LIMITS["mastodon"]
    if len(text) <= limit:
        return text.strip()
    return text[:limit - 3].rsplit(" ", 1)[0] + "..."


FORMATTERS = {
    "linkedin": format_linkedin,
    "twitter": format_twitter,
    "mastodon": format_mastodon,
}


# ---------------------------------------------------------------------------
# Output methods
# ---------------------------------------------------------------------------

def copy_to_clipboard(text: str):
    """Copy text to Windows clipboard via clip command."""
    try:
        process = subprocess.Popen(["clip"], stdin=subprocess.PIPE)
        process.communicate(text.encode("utf-16le"))
        print("[OK] Copied to clipboard.")
    except (FileNotFoundError, OSError) as e:
        print(f"[WARN] Clipboard copy failed: {e}")
        print("       Content printed to stdout instead.")


def send_telegram(message: str):
    """Send formatted post to Telegram. Fire-and-forget via daemon thread."""
    import threading

    def _send():
        url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
        payload = json.dumps({
            "chat_id": TELEGRAM_CHAT_ID,
            "text": message,
            "parse_mode": "Markdown",
            "disable_web_page_preview": True,
        }).encode("utf-8")
        req = Request(url, data=payload, headers={"Content-Type": "application/json"})
        try:
            with urlopen(req, timeout=10) as resp:
                if resp.status == 200:
                    print("[OK] Sent to Telegram (Decker DM).")
                else:
                    print(f"[WARN] Telegram returned status {resp.status}")
        except (URLError, OSError) as e:
            print(f"[WARN] Telegram send failed: {e}")

    threading.Thread(target=_send, daemon=True).start()


def save_output(text: str, path: str):
    """Save formatted text to file."""
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(text, encoding="utf-8")
    print(f"[OK] Saved to {path}")


# ---------------------------------------------------------------------------
# API posting (future — stubs)
# ---------------------------------------------------------------------------

def _linkedin_get_person_urn(token: str) -> str:
    """Get LinkedIn person URN (sub claim) via userinfo endpoint."""
    req = Request(
        "https://api.linkedin.com/v2/userinfo",
        headers={"Authorization": f"Bearer {token}"},
    )
    try:
        with urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read())
            return data["sub"]
    except (URLError, KeyError):
        pass
    # Fallback: /v2/me endpoint
    req = Request(
        "https://api.linkedin.com/v2/me",
        headers={"Authorization": f"Bearer {token}"},
    )
    with urlopen(req, timeout=10) as resp:
        data = json.loads(resp.read())
        return data["id"]


def post_linkedin(text: str, env: dict) -> bool:
    """Post to LinkedIn via API. Requires LINKEDIN_ACCESS_TOKEN."""
    token = env.get("LINKEDIN_ACCESS_TOKEN", "")
    if not token:
        print("[INFO] LinkedIn API not configured. Add LINKEDIN_ACCESS_TOKEN to .decker_env")
        print("       Formatted text available for manual posting.")
        return False

    try:
        person_id = _linkedin_get_person_urn(token)
    except Exception as e:
        print(f"[ERROR] Failed to get LinkedIn profile: {e}")
        return False

    author = f"urn:li:person:{person_id}"
    payload = json.dumps({
        "author": author,
        "lifecycleState": "PUBLISHED",
        "specificContent": {
            "com.linkedin.ugc.ShareContent": {
                "shareCommentary": {"text": text},
                "shareMediaCategory": "NONE",
            }
        },
        "visibility": {
            "com.linkedin.ugc.MemberNetworkVisibility": "PUBLIC"
        },
    }).encode("utf-8")

    req = Request(
        "https://api.linkedin.com/v2/ugcPosts",
        data=payload,
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "X-Restli-Protocol-Version": "2.0.0",
        },
    )
    try:
        with urlopen(req, timeout=15) as resp:
            if resp.status in (200, 201):
                result = json.loads(resp.read())
                post_id = result.get("id", "unknown")
                print(f"[OK] Posted to LinkedIn (id: {post_id})")
                return True
            else:
                print(f"[ERROR] LinkedIn API returned status {resp.status}")
                return False
    except URLError as e:
        print(f"[ERROR] LinkedIn post failed: {e}")
        return False


def post_twitter(text: str, env: dict) -> bool:
    """Post to Twitter/X via tweepy (API v2). Requires TWITTER_API_KEY, TWITTER_API_SECRET,
    TWITTER_ACCESS_TOKEN, TWITTER_ACCESS_TOKEN_SECRET in .decker_env."""
    api_key = env.get("TWITTER_API_KEY", "")
    api_secret = env.get("TWITTER_API_SECRET", "")
    access_token = env.get("TWITTER_ACCESS_TOKEN", "")
    access_token_secret = env.get("TWITTER_ACCESS_TOKEN_SECRET", "")

    missing = [k for k, v in {
        "TWITTER_API_KEY": api_key,
        "TWITTER_API_SECRET": api_secret,
        "TWITTER_ACCESS_TOKEN": access_token,
        "TWITTER_ACCESS_TOKEN_SECRET": access_token_secret,
    }.items() if not v]

    if missing:
        print(f"[INFO] Twitter API not configured. Add to .decker_env: {', '.join(missing)}")
        print("       Formatted text available for manual posting.")
        return False

    # Truncate to 280 chars
    tweet_text = text if len(text) <= 280 else text[:277] + "..."

    try:
        import tweepy
        client = tweepy.Client(
            consumer_key=api_key,
            consumer_secret=api_secret,
            access_token=access_token,
            access_token_secret=access_token_secret,
        )
        response = client.create_tweet(text=tweet_text)
        tweet_id = response.data["id"]
        print(f"[OK] Posted to Twitter (tweet_id: {tweet_id})")
        return True
    except ImportError:
        print("[ERROR] tweepy not installed. Run: pip install tweepy")
        return False
    except Exception as e:
        print(f"[ERROR] Twitter post failed: {e}")
        return False


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Social media post formatter.")
    parser.add_argument("--platform", required=True,
                        choices=["linkedin", "twitter", "mastodon"],
                        help="Target platform.")
    parser.add_argument("--text", help="Post text (inline).")
    parser.add_argument("--content", metavar="FILE.md",
                        help="Read post text from file.")
    parser.add_argument("--thread", action="store_true",
                        help="Twitter: split into thread.")
    parser.add_argument("--clipboard", action="store_true",
                        help="Copy formatted text to clipboard.")
    parser.add_argument("--telegram", action="store_true",
                        help="Send to Telegram for Decker to copy-paste.")
    parser.add_argument("--output", metavar="FILE",
                        help="Save formatted text to file.")
    parser.add_argument("--post", action="store_true",
                        help="Actually post via API (requires configured tokens).")

    args = parser.parse_args()

    # Get source text
    if args.content:
        if not Path(args.content).exists():
            print(f"[ERROR] File not found: {args.content}")
            sys.exit(1)
        raw_text = Path(args.content).read_text(encoding="utf-8")
    elif args.text:
        raw_text = args.text
    else:
        print("[ERROR] --text or --content is required.")
        sys.exit(1)

    # Format
    if args.platform == "twitter" and args.thread:
        result = format_twitter(raw_text, thread=True)
        if isinstance(result, list):
            display = "\n\n---\n\n".join(result)
            char_info = f"{len(result)} tweets"
        else:
            display = result
            char_info = f"{len(result)} chars"
    else:
        formatter = FORMATTERS[args.platform]
        result = formatter(raw_text)
        display = result
        char_info = f"{len(display)} chars"

    limit = PLATFORM_LIMITS[args.platform]
    print(f"\n=== {args.platform.upper()} ({char_info}, limit {limit}) ===\n")
    print(display)
    print(f"\n{'=' * 50}\n")

    # Output
    if args.clipboard:
        copy_to_clipboard(display)

    if args.telegram:
        header = f"*{args.platform.upper()} post ready for review:*\n\n"
        send_telegram(header + display)

    if args.output:
        save_output(display, args.output)

    if args.post:
        env = load_env()
        if args.platform == "linkedin":
            post_linkedin(display, env)
        elif args.platform == "twitter":
            post_twitter(display, env)
        else:
            print(f"[INFO] API posting not available for {args.platform}")

    # Default: if no output method specified, just print (already done above)


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name='social_poster',
        action=_workflow_entry,
        task_type='simple',
        actor='cli',
    )
