"""
GRC Nightly Compliance Snapshot — POSTs to the GRC executive snapshot endpoint
and logs the result. Runs nightly at 2am to capture compliance trend data.

Usage:
    python grc_snapshot.py              # run snapshot, log result
    python grc_snapshot.py --dry-run    # print what would happen, no POST
    python grc_snapshot.py --verbose    # detailed output
"""

import argparse
import json
import os
import urllib.request
import urllib.error
from datetime import datetime, timezone
from pathlib import Path

# Route execution through the harness
from aibrain.core.workflow_base import workflow_execute

# --- Config ---

GRC_SNAPSHOT_URL = os.environ.get(
    "GRC_SNAPSHOT_URL", "http://localhost:8002/api/reports/executive/snapshot"
)


def run(dry_run: bool = False, verbose: bool = False) -> dict:
    """POST to GRC executive snapshot endpoint. Returns dict with status and data."""
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")

    if dry_run:
        if verbose:
            print(f"GRC SNAPSHOT (dry-run) — {now}")
            print(f"  Would POST to: {GRC_SNAPSHOT_URL}")
        return {
            "status": "dry_run",
            "timestamp": now,
            "url": GRC_SNAPSHOT_URL,
            "snapshot": None,
        }

    try:
        req = urllib.request.Request(
            GRC_SNAPSHOT_URL,
            data=b"{}",
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=30) as resp:
            body = resp.read().decode("utf-8")
            snapshot = json.loads(body) if body.strip() else {}
            status = "success"
            if verbose:
                print(f"GRC SNAPSHOT — {now}")
                print(f"  URL: {GRC_SNAPSHOT_URL}")
                print(f"  HTTP {resp.status}")
                print(f"  Snapshot keys: {list(snapshot.keys()) if isinstance(snapshot, dict) else type(snapshot).__name__}")

    except urllib.error.HTTPError as exc:
        status = f"http_error_{exc.code}"
        snapshot = {"error": str(exc), "code": exc.code}
        print(f"[grc_snapshot] HTTP error {exc.code}: {exc}")
    except urllib.error.URLError as exc:
        status = "connection_error"
        snapshot = {"error": str(exc.reason)}
        print(f"[grc_snapshot] Connection error: {exc.reason}")
    except json.JSONDecodeError as exc:
        status = "json_error"
        snapshot = {"error": f"Invalid JSON in response: {exc}"}
        print(f"[grc_snapshot] JSON decode error: {exc}")
    except Exception as exc:  # noqa: BLE001
        status = "error"
        snapshot = {"error": str(exc)}
        print(f"[grc_snapshot] Unexpected error: {exc}")

    result = {
        "status": status,
        "timestamp": now,
        "url": GRC_SNAPSHOT_URL,
        "snapshot": snapshot,
    }

    if not verbose and status == "success":
        print(f"[grc_snapshot] ok — {now}")
    elif not verbose and status != "dry_run":
        print(f"[grc_snapshot] {status} — {now}")

    return result


if __name__ == "__main__":
    def _workflow_entry():
        parser = argparse.ArgumentParser(
            description="GRC Nightly Compliance Snapshot — POST to executive snapshot endpoint"
        )
        parser.add_argument("--dry-run", action="store_true", help="Print what would happen, no POST")
        parser.add_argument("--verbose", action="store_true", help="Detailed output")
        args = parser.parse_args()

        if args.dry_run:
            args.verbose = True

        result = run(dry_run=args.dry_run, verbose=args.verbose)

        if not args.verbose:
            print(f"[{result['status']}] grc_snapshot done")

    workflow_execute(
        workflow_name="grc_snapshot",
        action=_workflow_entry,
        task_type="deterministic",
        actor="cli",
    )
