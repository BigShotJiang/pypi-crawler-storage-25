#!/usr/bin/env python3
"""AIBrain Workflow: Habit Tracker — track daily habits, streaks, accountability emails."""

import argparse
import datetime
import json
import os
import smtplib
import sqlite3
import sys
import urllib.request
from email.mime.text import MIMEText
from pathlib import Path

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

from aibrain_db import AIBRAIN_ROOT, get_db
_cfg_path = AIBRAIN_ROOT / "config.json"
CONFIG = json.loads(_cfg_path.read_text()) if _cfg_path.exists() else {}
def _find_db():
    """Find best DB path, checking both new and legacy names."""
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    configured = CONFIG.get("db_path")
    if configured and Path(configured).exists():
        return configured
    mem_db = AIBRAIN_ROOT / "memory" / "memory.db"
    if mem_db.exists():
        return str(mem_db)
    return str(AIBRAIN_ROOT / "aibrain.db")

MEMORY_DB = CONFIG.get("db_path", _find_db())
API_BASE = os.environ.get("AIBRAIN_API", os.environ.get("AIBRAIN_API", "http://localhost:8001/api/agent"))


def log_activity(action, detail="", status="ok"):
    try:
        data = json.dumps({
            "action": action, "category": "productivity",
            "detail": detail, "status": status,
        }).encode()
        req = urllib.request.Request(
            f"{API_BASE}/activity", data=data,
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass


DEFAULT_HABITS = ["Exercise", "Read 30min", "Code 1hr", "Meditate", "Journal"]


def get_db():
    db = get_db()
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    return db

def load_state(name):
    try:
        db = get_db()
        row = db.execute("SELECT content FROM memories WHERE name=? AND active=1",
                         (f"workflow_state:{name}",)).fetchone()
        db.close()
        return json.loads(row["content"]) if row else {}
    except Exception:
        return {}

def save_state(name, state):
    db = get_db()
    try:
        now = datetime.datetime.now().isoformat()
        existing = db.execute("SELECT id FROM memories WHERE name=? AND active=1",
                             (f"workflow_state:{name}",)).fetchone()
        if existing:
            db.execute("UPDATE memories SET content=?, updated=? WHERE id=?",
                       (json.dumps(state), now, existing["id"]))
        else:
            db.execute("INSERT INTO memories (name,type,tags,content,created,updated,active) VALUES (?,?,?,?,?,?,1)",
                       (f"workflow_state:{name}", "reference", "workflow,state", json.dumps(state), now, now))
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()

def send_email(to, subject, body, dry_run=False):
    if dry_run:
        print(f"TO: {to}\nSUBJECT: {subject}\n\n{body}")
        return
    agent_email = CONFIG.get("agent_email", "aibrain@localhost")
    agent_password = CONFIG.get("agent_email_password", CONFIG.get("email_app_password", ""))
    msg = MIMEText(body, "plain")
    msg["From"] = agent_email
    msg["To"] = to
    msg["Subject"] = subject
    with smtplib.SMTP_SSL(CONFIG.get("agent_smtp_host", CONFIG.get("email_smtp_host", "smtp.gmail.com")), 465) as s:
        s.login(agent_email, agent_password)
        s.send_message(msg)


def fetch_cat_fact():
    """Fetch a random cat fact from catfact.ninja (free, no key needed)."""
    try:
        url = "https://catfact.ninja/fact"
        req = urllib.request.Request(url, headers={"User-Agent": "AIBrain/1.0"})
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read().decode())
        return data.get("fact", "")
    except Exception as e:
        print(f"Warning: Cat Facts fetch failed: {e}", file=sys.stderr)
    return None


def format_checklist(habits, state):
    today = datetime.date.today().isoformat()
    today_log = state.get("logs", {}).get(today, {})
    streaks = state.get("streaks", {})

    lines = [
        f"HABIT TRACKER — {datetime.datetime.now().strftime('%A %B %d, %Y')}",
        "=" * 50,
        "",
        "TODAY'S HABITS",
    ]

    for h in habits:
        done = today_log.get(h, False)
        streak = streaks.get(h, 0)
        check = "[X]" if done else "[ ]"
        streak_str = f" (streak: {streak} days)" if streak > 0 else ""
        lines.append(f"  {check} {h}{streak_str}")

    completed = sum(1 for h in habits if today_log.get(h, False))
    lines.append(f"\n  Progress: {completed}/{len(habits)} completed")

    # Weekly summary
    week_data = {}
    for i in range(7):
        d = (datetime.date.today() - datetime.timedelta(days=i)).isoformat()
        day_log = state.get("logs", {}).get(d, {})
        week_data[d] = sum(1 for h in habits if day_log.get(h, False))

    if any(week_data.values()):
        lines.append("\nTHIS WEEK")
        for d, count in sorted(week_data.items()):
            bar = "#" * count + "." * (len(habits) - count)
            day_name = datetime.date.fromisoformat(d).strftime("%a")
            lines.append(f"  {day_name} {d}: [{bar}] {count}/{len(habits)}")

    # Best streaks
    if streaks:
        lines.append("\nSTREAKS")
        for h in sorted(streaks, key=lambda x: streaks[x], reverse=True):
            if streaks[h] > 0:
                lines.append(f"  {h}: {streaks[h]} days")

    # Reward: cat fact when all habits are completed
    if completed == len(habits) and len(habits) > 0:
        cat_fact = fetch_cat_fact()
        if cat_fact:
            lines.append("\nALL HABITS COMPLETE! Here's your reward:")
            lines.append(f"  Cat Fact: {cat_fact}")

    lines.append("\n—\nPowered by AIBrain")
    return "\n".join(lines)


def log_habit(habits, state, habit_name, done=True):
    """Mark a habit as done/undone for today."""
    today = datetime.date.today().isoformat()
    if "logs" not in state:
        state["logs"] = {}
    if today not in state["logs"]:
        state["logs"][today] = {}
    state["logs"][today][habit_name] = done

    # Update streaks
    if "streaks" not in state:
        state["streaks"] = {}
    if done:
        state["streaks"][habit_name] = state["streaks"].get(habit_name, 0) + 1
    else:
        state["streaks"][habit_name] = 0

    return state


def main():
    parser = argparse.ArgumentParser(description="AIBrain Habit Tracker")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--log", help="Log a habit as done (e.g. --log 'Exercise')")
    parser.add_argument("--undo", help="Undo a habit (e.g. --undo 'Exercise')")
    args = parser.parse_args()

    habits = CONFIG.get("habits", DEFAULT_HABITS)
    email_to = CONFIG.get("email_to", CONFIG.get("agent_email", ""))
    state = load_state("habit_tracker")

    if args.log:
        state = log_habit(habits, state, args.log, True)
        save_state("habit_tracker", state)
        print(f"Logged: {args.log} done!")
        return

    if args.undo:
        state = log_habit(habits, state, args.undo, False)
        save_state("habit_tracker", state)
        print(f"Undone: {args.undo}")
        return

    # Default: show checklist and email
    checklist = format_checklist(habits, state)

    if not email_to or args.dry_run:
        print(checklist)
    else:
        send_email(email_to, "Daily Habits Checklist", checklist)
        print(f"Sent habit checklist to {email_to}")

    state["last_run"] = datetime.datetime.now().isoformat()
    # Trim logs older than 30 days
    cutoff = (datetime.date.today() - datetime.timedelta(days=30)).isoformat()
    if "logs" in state:
        state["logs"] = {k: v for k, v in state["logs"].items() if k >= cutoff}
    save_state("habit_tracker", state)

    today = datetime.date.today().isoformat()
    today_log = state.get("logs", {}).get(today, {})
    completed = sum(1 for h in habits if today_log.get(h, False))
    log_activity("habit_tracker", f"{completed}/{len(habits)} habits completed")


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name='habit_tracker',
        action=_workflow_entry,
        task_type='deterministic',
        actor='cli',
    )
