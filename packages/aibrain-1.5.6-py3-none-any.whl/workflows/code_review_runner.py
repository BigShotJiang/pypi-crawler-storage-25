#!/usr/bin/env python3
"""AIBrain Workflow: Code Review Runner — security-first static analysis.

Loads security principles from AIBrain memory (self-learning: every new
finding stored via --learn is automatically applied on future runs).
Runs bandit if available, then pattern-matches known anti-patterns.

Usage:
    python code_review_runner.py --path /path/to/your/project
    python code_review_runner.py --path file.py --bandit
    python code_review_runner.py --learn '{"name":"uuid4-tokens","pattern":"uuid4","message":"Use secrets.token_urlsafe() for security tokens — uuid4 is not cryptographically secure","severity":"HIGH","tags":"security,tokens"}'
    python code_review_runner.py --list-principles
    python code_review_runner.py --seed-defaults   # seed known-good principles into DB
"""

import argparse
import datetime
import json
import os
import re
import sqlite3
import subprocess
import sys
from pathlib import Path

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

# ---------------------------------------------------------------------------
# Bootstrap
# ---------------------------------------------------------------------------

from aibrain_db import AIBRAIN_ROOT, get_db
_cfg_path = AIBRAIN_ROOT / "config.json"
CONFIG = json.loads(_cfg_path.read_text()) if _cfg_path.exists() else {}


def _find_db():
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    configured = CONFIG.get("db_path")
    if configured and Path(configured).exists():
        return configured
    return str(AIBRAIN_ROOT / "aibrain.db")


MEMORY_DB = CONFIG.get("db_path", _find_db())


def get_db():
    db = get_db()
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    return db


# ---------------------------------------------------------------------------
# Principle management (reads/writes AIBrain memory)
# ---------------------------------------------------------------------------

def load_principles():
    """Load all active security principles from AIBrain memory."""
    db = get_db()
    try:
        rows = db.execute(
            """SELECT name, content, tags FROM memories
               WHERE active=1
               AND (type='pattern'
                    OR (type='feedback' AND (tags LIKE '%security%' OR tags LIKE '%vulnerability%')))  -- noqa:like-wildcard-injection (hardcoded internal tags, not user input)
               ORDER BY updated DESC"""
        ).fetchall()
    except Exception:
        rows = []
    finally:
        db.close()

    principles = []
    for row in rows:
        try:
            content = json.loads(row["content"])
            if isinstance(content, dict) and "pattern" in content:
                principles.append(content)
        except (json.JSONDecodeError, TypeError):
            pass
    return principles


def store_principle(name, pattern, message, severity="HIGH", tags="security", fix=None):
    """Store a security principle into AIBrain memory."""
    db = get_db()
    now = datetime.datetime.now().isoformat()
    mem_name = f"security_principle:{name}"
    content = {
        "name": name,
        "pattern": pattern,
        "message": message,
        "severity": severity,
        "fix": fix or "",
        "tags": tags,
        "added": now,
    }
    content_str = json.dumps(content)
    full_tags = f"security,code-review,{tags}"
    try:
        existing = db.execute(
            "SELECT id FROM memories WHERE name=? AND active=1", (mem_name,)
        ).fetchone()
        if existing:
            db.execute(
                "UPDATE memories SET content=?, tags=?, updated=? WHERE id=?",
                (content_str, full_tags, now, existing["id"]),
            )
            print(f"  Updated: {mem_name}")
        else:
            db.execute(
                "INSERT INTO memories (name,type,tags,content,created,updated,active) VALUES (?,?,?,?,?,?,1)",
                (mem_name, "pattern", full_tags, content_str, now, now),
            )
            print(f"  Stored: {mem_name}")
        db.commit()
    except Exception as e:
        db.rollback()
        print(f"  ERROR storing principle: {e}")
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Default principles — everything discovered across all security audits
# ---------------------------------------------------------------------------

DEFAULT_PRINCIPLES = [
    {
        "name": "uuid4-security-tokens",
        "pattern": r"uuid\.uuid4\(\)",
        "message": "uuid4() is not cryptographically secure — use secrets.token_urlsafe(32) or secrets.token_hex(16) for any security token, session ID, OOB callback token, or canary",
        "severity": "HIGH",
        "fix": "import secrets; token = secrets.token_urlsafe(32)",
        "tags": "tokens,entropy",
    },
    {
        "name": "path-startswith-traversal",
        "pattern": r"\.startswith\(.*[Pp]ath|str\(.*\)\.startswith",
        "message": "startswith() for path validation is bypassable with traversal sequences — use Path.relative_to() which raises ValueError on escape",
        "severity": "CRITICAL",
        "fix": "try: p.resolve().relative_to(root.resolve()) except ValueError: deny",
        "tags": "path-traversal,filesystem",
    },
    {
        "name": "fstring-subprocess-injection",
        "pattern": r"subprocess\.run\(\s*\[sys\.executable.*-c.*f['\"]",
        "message": "f-string interpolation into subprocess Python -c script body allows code injection — pass data via environment variables instead",
        "severity": "CRITICAL",
        "fix": "env = {**os.environ, '_VAR': value}; subprocess.run([sys.executable, '-c', script], env=env)",
        "tags": "injection,subprocess",
    },
    {
        "name": "like-wildcard-injection",
        "pattern": r"LIKE\s+['\"]?%\s*\+|LIKE.*\?.*%.*format|f['\"].*LIKE.*\{",
        "message": "LIKE queries with unescaped user input allow wildcard injection — escape %, _, \\ before building the pattern",
        "severity": "HIGH",
        "fix": "safe = val.replace('\\\\','\\\\\\\\').replace('%','\\\\%').replace('_','\\\\_'); query = 'WHERE col LIKE ? ESCAPE \\'\\\\'",
        "tags": "sql,injection",
    },
    {
        "name": "sql-fstring-column-names",
        "pattern": r"f['\"].*UPDATE|f['\"].*INSERT|f['\"].*SELECT.*\{",
        "message": "Dynamic column/table names in f-string SQL allow injection — whitelist via frozenset before interpolating",
        "severity": "CRITICAL",
        "fix": "_ALLOWED = frozenset({'col1','col2'}); safe = {k:v for k,v in kwargs.items() if k in _ALLOWED}",
        "tags": "sql,injection",
    },
    {
        "name": "timing-attack-token-comparison",
        "pattern": r"==\s*(?:token|secret|key|sig|hash|password|auth)|(?:token|secret|key|sig|hash|password|auth)\s*==",
        "message": "Plain == comparison of secrets leaks timing information — use hmac.compare_digest() for all cryptographic comparisons",
        "severity": "HIGH",
        "fix": "import hmac; hmac.compare_digest(provided.encode(), expected.encode())",
        "tags": "timing,cryptography",
    },
    {
        "name": "requests-verify-false",
        "pattern": r"verify\s*=\s*False",
        "message": "verify=False disables TLS certificate validation — only acceptable for intentional scanner/pentest code against targets, never in production application code",  # noqa:verify-false
        "severity": "HIGH",
        "fix": "verify=True (default) or verify='/path/to/ca-bundle.crt'",
        "tags": "tls,cryptography",
    },
    {
        "name": "websocket-url-unvalidated",
        "pattern": r"create_connection\((?:ws_url|websocket_url|debug_url|tab\.get)",
        "message": "WebSocket URL from external/untrusted source connected without validation — validate it starts with ws://localhost: or ws://127.0.0.1: before connecting",
        "severity": "HIGH",
        "fix": "if not (url.startswith('ws://localhost:') or url.startswith('ws://127.0.0.1:')): raise ValueError",
        "tags": "websocket,ssrf",
    },
    {
        "name": "llm-external-data-unsanitized",
        "pattern": r"(?:analyze_response|llm\.chat|llm\.generate).*resp\.text|resp\.text.*(?:analyze_response|llm\.chat)",
        "message": "Raw HTTP response body passed to LLM without sanitization — a target can embed prompt injection in its response to manipulate LLM analysis",
        "severity": "HIGH",
        "fix": "sanitize = re.sub(r'\\b(ignore|override|system prompt|act as)\\b', '[REDACTED]', resp.text, flags=re.I)[:2000]",
        "tags": "prompt-injection,llm",
    },
    {
        "name": "jwt-race-condition-double-checked-locking",
        "pattern": r"def.*get.*(?:jwt|secret|token).*:\s*\n\s*(?:secret|token)\s*=\s*db\.",
        "message": "JWT/secret generation without locking has TOCTOU race — two threads may both see no secret and generate conflicting values. Use threading.Lock() with double-checked locking",
        "severity": "HIGH",
        "fix": "with _lock:\n    secret = db.get(); if not secret: secret=generate(); db.set(secret)",
        "tags": "race-condition,jwt",
    },
    {
        "name": "toctou-status-update",
        "pattern": r"UPDATE.*SET.*status.*WHERE.*id\s*=\s*\?(?!.*AND.*status)",
        "message": "Status UPDATE without checking current state allows TOCTOU double-processing — add AND status='pending' and check rowcount > 0",
        "severity": "HIGH",
        "fix": "cursor = db.execute('UPDATE ... SET status=? WHERE id=? AND status=?pending?'); if cursor.rowcount == 0: already_processed",
        "tags": "race-condition,toctou",
    },
    {
        "name": "symlink-path-traversal",
        "pattern": r"relative_to|expanduser|resolve\(\)",
        "message": "After relative_to() check, verify symlinks don't escape root — a symlink inside allowed dir can point outside",
        "severity": "MEDIUM",
        "fix": "if p.is_symlink(): p.resolve().relative_to(root)",
        "tags": "path-traversal,symlink",
    },
    {
        "name": "private-ip-missing-link-local",
        "pattern": r"169\.254|link.?local|cloud.?metadata|imds",
        "message": "Private IP check missing 169.254.x.x (AWS/Azure/GCP cloud metadata). Ensure link-local range is in your private IP blocklist",
        "severity": "MEDIUM",
        "fix": "ip.startswith('169.254.') or ipaddress.ip_address(ip).is_link_local",
        "tags": "ssrf,cloud-metadata",
    },
    {
        "name": "hardcoded-secrets",
        "pattern": r"(?:password|secret|token|api_key|apikey|passwd)\s*=\s*['\"][^'\"]{6,}['\"]",
        "message": "Hardcoded credential in source — use environment variables or .aibrain_env file (gitignored)",
        "severity": "CRITICAL",
        "fix": "os.getenv('SECRET_NAME') or load from ~/.aibrain_env",
        "tags": "credentials,secrets",
    },
    {
        "name": "shell-true-subprocess",
        "pattern": r"subprocess\.(?:run|call|Popen).*shell\s*=\s*True",
        "message": "shell=True with any user-influenced input allows command injection — use array args instead",
        "severity": "CRITICAL",
        "fix": "subprocess.run(['cmd', arg1, arg2], shell=False)",
        "tags": "injection,subprocess",
    },
]


def seed_defaults():
    """Seed all default principles into AIBrain memory."""
    print(f"Seeding {len(DEFAULT_PRINCIPLES)} security principles into AIBrain memory...")
    for p in DEFAULT_PRINCIPLES:
        store_principle(
            name=p["name"],
            pattern=p["pattern"],
            message=p["message"],
            severity=p.get("severity", "HIGH"),
            tags=p.get("tags", "security"),
            fix=p.get("fix", ""),
        )
    print(f"Done. {len(DEFAULT_PRINCIPLES)} principles seeded.")


# ---------------------------------------------------------------------------
# Static analysis
# ---------------------------------------------------------------------------

def run_bandit(path):
    """Run bandit if available. Returns list of finding dicts."""
    try:
        result = subprocess.run(
            ["bandit", "-r", str(path), "-f", "json", "-ll"],
            capture_output=True, text=True, timeout=60,
        )
        if result.stdout:
            data = json.loads(result.stdout)
            findings = []
            for r in data.get("results", []):
                findings.append({
                    "file": r.get("filename", ""),
                    "line": r.get("line_number", 0),
                    "severity": r.get("issue_severity", ""),
                    "message": r.get("issue_text", ""),
                    "tool": "bandit",
                })
            return findings
    except FileNotFoundError:
        print("  [bandit] not installed — skipping")
    except Exception as e:
        print(f"  [bandit] error: {e}")
    return []


def scan_file_against_principles(filepath, principles):
    """Scan a single Python file against all loaded principles."""
    findings = []
    try:
        content = Path(filepath).read_text(encoding="utf-8", errors="ignore")
        lines = content.splitlines()
    except Exception:
        return findings

    for principle in principles:
        pat = principle.get("pattern", "")
        if not pat:
            continue
        try:
            regex = re.compile(pat, re.IGNORECASE | re.MULTILINE)
        except re.error:
            continue

        for match in regex.finditer(content):
            line_num = content[:match.start()].count("\n") + 1
            line_text = lines[line_num - 1].strip() if line_num <= len(lines) else ""
            findings.append({
                "file": str(filepath),
                "line": line_num,
                "severity": principle.get("severity", "HIGH"),
                "message": principle.get("message", ""),
                "fix": principle.get("fix", ""),
                "principle": principle.get("name", ""),
                "matched_line": line_text,
                "tool": "code_review_runner",
            })
    return findings


def scan_path(path, principles, bandit=False):
    """Scan a file or directory. Returns all findings."""
    p = Path(path)
    all_findings = []

    if bandit:
        print(f"  Running bandit on {path}...")
        all_findings.extend(run_bandit(path))

    py_files = [p] if p.is_file() else list(p.rglob("*.py"))
    # Skip test targets and build dirs
    skip_patterns = ["test_agent/vulnerable_agent", "test_integration", "/build/", "/.venv/", "/venv/", "__pycache__"]
    py_files = [f for f in py_files if not any(s in str(f).replace("\\", "/") for s in skip_patterns)]

    print(f"  Scanning {len(py_files)} Python files against {len(principles)} principles...")
    for f in py_files:
        all_findings.extend(scan_file_against_principles(f, principles))

    return all_findings


def format_report(findings, path):
    """Format findings into readable report."""
    if not findings:
        return f"CODE REVIEW CLEAN — {path}\nNo issues found against {len(DEFAULT_PRINCIPLES)} principles.\n"

    by_severity = {"CRITICAL": [], "HIGH": [], "MEDIUM": [], "LOW": [], "INFO": []}
    for f in findings:
        sev = f.get("severity", "HIGH").upper()
        by_severity.setdefault(sev, []).append(f)

    lines = [
        f"CODE REVIEW REPORT — {path}",
        f"Generated: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}",
        f"Total findings: {len(findings)}",
        "=" * 60,
        "",
    ]

    for sev in ["CRITICAL", "HIGH", "MEDIUM", "LOW"]:
        items = by_severity.get(sev, [])
        if not items:
            continue
        lines.append(f"[{sev}] — {len(items)} finding(s)")
        for item in items:
            lines.append(f"  {item['file']}:{item['line']}")
            lines.append(f"  {item['message']}")
            if item.get("matched_line"):
                lines.append(f"  Found: {item['matched_line'][:100]}")
            if item.get("fix"):
                lines.append(f"  Fix:   {item['fix'][:120]}")
            if item.get("principle"):
                lines.append(f"  Rule:  {item['principle']}")
            lines.append("")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="AIBrain Code Review Runner")
    parser.add_argument("--path", help="File or directory to review")
    parser.add_argument("--bandit", action="store_true", help="Also run bandit")
    parser.add_argument("--learn", help="JSON string: store new security principle into memory")
    parser.add_argument("--list-principles", action="store_true", help="List all loaded principles")
    parser.add_argument("--seed-defaults", action="store_true", help="Seed default principles into AIBrain memory")
    args = parser.parse_args()

    if args.seed_defaults:
        seed_defaults()
        return

    if args.learn:
        try:
            data = json.loads(args.learn)
            store_principle(
                name=data["name"],
                pattern=data["pattern"],
                message=data["message"],
                severity=data.get("severity", "HIGH"),
                tags=data.get("tags", "security"),
                fix=data.get("fix", ""),
            )
            print("Principle stored.")
        except Exception as e:
            print(f"Error: {e}")
        return

    # Load principles from AIBrain memory
    db_principles = load_principles()
    # Merge with defaults (DB takes precedence for same name)
    db_names = {p["name"] for p in db_principles}
    merged = db_principles + [p for p in DEFAULT_PRINCIPLES if p["name"] not in db_names]

    if args.list_principles:
        print(f"Loaded {len(merged)} principles ({len(db_principles)} from DB, {len(DEFAULT_PRINCIPLES) - len(db_names)} defaults):")
        for p in merged:
            print(f"  [{p.get('severity','?'):8}] {p['name']}")
            print(f"           {p['message'][:80]}...")
        return

    if not args.path:
        parser.print_help()
        return

    print(f"Code Review Runner — {args.path}")
    print(f"Principles loaded: {len(merged)} ({len(db_principles)} from AIBrain DB + {len(merged) - len(db_principles)} defaults)")

    findings = scan_path(args.path, merged, bandit=args.bandit)
    report = format_report(findings, args.path)
    print(report)

    # Deduplicate by file+line+principle
    seen = set()
    unique = []
    for f in findings:
        key = (f["file"], f["line"], f.get("principle", ""))
        if key not in seen:
            seen.add(key)
            unique.append(f)

    # Save state to DB
    db = get_db()
    try:
        now = datetime.datetime.now().isoformat()
        state = json.dumps({
            "last_run": now,
            "path": str(args.path),
            "findings": len(unique),
            "principles_loaded": len(merged),
        })
        existing = db.execute(
            "SELECT id FROM memories WHERE name='workflow_state:code_review_runner' AND active=1"
        ).fetchone()
        if existing:
            db.execute("UPDATE memories SET content=?, updated=? WHERE id=?",
                       (state, now, existing["id"]))
        else:
            db.execute(
                "INSERT INTO memories (name,type,tags,content,created,updated,active) VALUES (?,?,?,?,?,?,1)",
                ("workflow_state:code_review_runner", "reference", "workflow,state", state, now, now),
            )
        db.commit()
    except Exception:
        pass
    finally:
        db.close()


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name='code_review_runner',
        action=_workflow_entry,
        task_type='complex',
        actor='cli',
    )
