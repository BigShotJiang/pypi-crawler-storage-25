"""
PyInstaller runtime hook — runs before any user code.

Sets environment variables so that sentence-transformers / huggingface-hub
find the bundled MiniLM model instead of trying to download it from the internet.

At bundle time we placed the model snapshot at:
  _MEIPASS/huggingface_cache/hub/models--sentence-transformers--all-MiniLM-L6-v2/…

By pointing HF_HOME at _MEIPASS/huggingface_cache we override the default
~/.cache/huggingface lookup without changing any application code.
"""

import os
import sys

# _MEIPASS is set by PyInstaller to the temp extraction dir (one-dir: it's the dist dir)
_bundle_dir = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))

# Point HuggingFace to our bundled cache
_hf_cache = os.path.join(_bundle_dir, "huggingface_cache")
os.environ.setdefault("HF_HOME", _hf_cache)
os.environ.setdefault("HUGGINGFACE_HUB_CACHE", os.path.join(_hf_cache, "hub"))

# Tell huggingface-hub to work offline — no download attempts
os.environ.setdefault("HF_HUB_OFFLINE", "1")
os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")

# AIBRAIN_ROOT — mutable data directory (SQLite DBs, scheduled_jobs.json, uploads, etc.)
# When launched from Tauri the shell plugin sets AIBRAIN_ROOT before spawning this sidecar.
# When run standalone (e.g. from a terminal for debugging), fall back to a platform-
# appropriate user-data directory so the binary doesn't try to write inside the frozen bundle.
if not os.environ.get("AIBRAIN_ROOT"):
    if sys.platform == "win32":
        _appdata = os.environ.get("APPDATA", os.path.expanduser("~"))
        _default_root = os.path.join(_appdata, "aibrain")
    elif sys.platform == "darwin":
        _default_root = os.path.join(
            os.path.expanduser("~"), "Library", "Application Support", "aibrain"
        )
    else:
        _xdg = os.environ.get("XDG_DATA_HOME", os.path.join(os.path.expanduser("~"), ".local", "share"))
        _default_root = os.path.join(_xdg, "aibrain")

    os.makedirs(_default_root, exist_ok=True)
    os.environ["AIBRAIN_ROOT"] = _default_root

# Windows: force UTF-8 console output (prevents UnicodeEncodeError)
if sys.platform == "win32":
    os.environ.setdefault("PYTHONUTF8", "1")
