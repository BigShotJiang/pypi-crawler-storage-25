"""
license_activations_api.py — Backend endpoints for license activation tracking.

Three routes:
  POST /api/license/activations  — record a first activation (upsert by key_hash)
  POST /api/license/heartbeat    — increment total_validations, update last_seen_at
  GET  /api/license/stats        — aggregate counts (admin/X-API-Key required)

Privacy contract:
  - key_hash is SHA-256 of the raw license key — raw key never stored here
  - machine_fingerprint_hash is a salted hash; no raw hostname/MAC stored
  - No IP storage; country derivation (if ever needed) happens at edge then discarded
  - See docs/privacy.md for full policy
"""

import hashlib
import logging
import os
import sqlite3
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel

logger = logging.getLogger(__name__)

router = APIRouter()

# ---------------------------------------------------------------------------
# DB helper — uses the canonical aibrain_db connection
# ---------------------------------------------------------------------------

def _get_db() -> sqlite3.Connection:
    """Open a connection to the canonical aibrain DB."""
    # Prefer AIBRAIN_DB env var (test isolation), fall back to aibrain_db.AIBRAIN_ROOT
    db_path = os.environ.get("AIBRAIN_DB")
    if not db_path:
        # aibrain_db is already on sys.path from main.py
        import aibrain_db
        db_path = str(aibrain_db.AIBRAIN_ROOT / "aibrain.db")
    conn = sqlite3.connect(db_path, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


# ---------------------------------------------------------------------------
# Admin gate — reuses the X-API-Key mechanism already in security.py
# ---------------------------------------------------------------------------

def _require_admin(request: Request):
    """Raise 403 if the request does not carry a valid admin API key.

    We piggyback on the AuthMiddleware that wraps every /api/* route.
    The middleware already rejects unauthenticated requests before they
    reach route handlers. For the stats endpoint we add an *additional*
    role check: only requests carrying the AIBRAIN_ADMIN_TOKEN env var
    value (or X-API-Key when auth_mode is api_key) are allowed.

    If AIBRAIN_ADMIN_TOKEN is unset, we fall back to allowing any
    authenticated request (operator-local deployment).
    """
    admin_token = os.environ.get("AIBRAIN_ADMIN_TOKEN", "")
    if not admin_token:
        # No admin token configured — fail closed for non-localhost callers
        client_ip = request.client.host if request.client else ""
        if client_ip not in ("127.0.0.1", "::1", "localhost"):
            raise HTTPException(status_code=403, detail="Admin access requires AIBRAIN_ADMIN_TOKEN to be set")
        return
    incoming = request.headers.get("X-API-Key") or request.headers.get("Authorization", "").removeprefix("Bearer ")
    if not incoming or incoming != admin_token:
        raise HTTPException(status_code=403, detail="Admin access required")


# ---------------------------------------------------------------------------
# Request models
# ---------------------------------------------------------------------------

class ActivationRequest(BaseModel):
    key_hash: str                    # SHA-256(raw_key)
    email: Optional[str] = None
    machine_fingerprint_hash: Optional[str] = None  # logged only, not stored


class HeartbeatRequest(BaseModel):
    key_hash: str
    machine_fingerprint_hash: Optional[str] = None


class ValidateRequest(BaseModel):
    key: str                         # raw license key


# ---------------------------------------------------------------------------
# POST /api/license/validate
# ---------------------------------------------------------------------------

@router.post("/api/license/validate")
async def validate_license(body: ValidateRequest):
    """Validate a license key and return its tier, validity, and reason.

    Calls aibrain_licensing.validate_key() for offline signature + expiry
    checks.  Also checks the license_state table in the DB for subscription
    state (VALID/INVALID/GRACE).  Fails open on DB errors — the offline
    check is authoritative when the DB is unavailable.
    """
    try:
        import aibrain_licensing
    except ImportError:
        # aibrain_licensing not installed in this environment — fall back to
        # a minimal DB-only check so the endpoint stays functional.
        aibrain_licensing = None

    if aibrain_licensing is not None:
        lic = aibrain_licensing.validate_key(body.key)
        return {
            "valid": lic.valid,
            "tier": lic.tier,
            "reason": lic.reason or ("ok" if lic.valid else "invalid"),
            "expires_at": lic.expires_at or None,
            "email": lic.email or None,
        }

    # Fallback: check license_state table by SHA-256(key)
    import hashlib
    key_hash = hashlib.sha256(body.key.encode()).hexdigest()
    try:
        db = _get_db()
        try:
            row = db.execute(
                "SELECT tier, state, valid_until FROM license_state "
                "WHERE license_key = ? OR "
                "id IN (SELECT user_id FROM license_activations WHERE key_hash = ?)",
                (body.key, key_hash),
            ).fetchone()
        finally:
            db.close()
    except Exception as exc:
        logger.error("license validate: DB error: %s", exc)
        return {"valid": False, "tier": "free", "reason": "DB unavailable — try again"}

    if row is None:
        return {"valid": False, "tier": "free", "reason": "Key not found"}

    state = row["state"] if "state" in row.keys() else "VALID"
    valid = state in ("VALID", "GRACE")
    return {
        "valid": valid,
        "tier": row["tier"] if valid else "free",
        "reason": "ok" if valid else f"Subscription {state.lower()}",
        "expires_at": row["valid_until"] if "valid_until" in row.keys() else None,
    }


# ---------------------------------------------------------------------------
# POST /api/license/activations
# ---------------------------------------------------------------------------

@router.post("/api/license/activations")
async def record_activation(body: ActivationRequest):
    """Record or update a license activation.

    Upserts by key_hash:
      - First call: inserts with first_seen_at = last_seen_at = now
      - Subsequent calls from a *new* machine: increments machine_count
      - Always: updates last_seen_at, increments total_validations

    The machine_fingerprint_hash is accepted but not stored — it is only
    used server-side for machine_count dedup logic if we add that later.
    For now machine_count is incremented on every first-activation call
    for simplicity (callers only call this once per machine on save_license).
    """
    if not body.key_hash or len(body.key_hash) != 64:
        raise HTTPException(status_code=400, detail="key_hash must be a 64-char SHA-256 hex digest")

    now = datetime.now(timezone.utc).isoformat()

    try:
        db = _get_db()
        try:
            existing = db.execute(
                "SELECT key_hash, machine_count, total_validations FROM license_activations WHERE key_hash = ?",
                (body.key_hash,),
            ).fetchone()

            if existing is None:
                db.execute(
                    """INSERT INTO license_activations
                       (key_hash, email, first_seen_at, last_seen_at, machine_count, total_validations)
                       VALUES (?, ?, ?, ?, 1, 1)""",
                    (body.key_hash, body.email or None, now, now),
                )
                logger.info("license_activations: new activation key_hash=%.8s...", body.key_hash)
            else:
                db.execute(
                    """UPDATE license_activations
                       SET last_seen_at = ?,
                           machine_count = machine_count + 1,
                           total_validations = total_validations + 1
                       WHERE key_hash = ?""",
                    (now, body.key_hash),
                )
                logger.debug("license_activations: re-activation key_hash=%.8s...", body.key_hash)

            db.commit()
        finally:
            db.close()
    except Exception as exc:
        logger.error("license_activations: DB error: %s", exc)
        raise HTTPException(status_code=500, detail="Database error")

    return {"status": "ok", "recorded_at": now}


# ---------------------------------------------------------------------------
# POST /api/license/heartbeat
# ---------------------------------------------------------------------------

@router.post("/api/license/heartbeat")
async def record_heartbeat(body: HeartbeatRequest):
    """Increment total_validations and update last_seen_at for a known key.

    Called at most once per 24h per machine (rate limiting enforced client-side
    via ~/.aibrain/.heartbeat_sent mtime). Unknown keys are silently ignored —
    the heartbeat path is not a registration path.
    """
    if not body.key_hash or len(body.key_hash) != 64:
        raise HTTPException(status_code=400, detail="key_hash must be a 64-char SHA-256 hex digest")

    now = datetime.now(timezone.utc).isoformat()

    try:
        db = _get_db()
        try:
            result = db.execute(
                """UPDATE license_activations
                   SET last_seen_at = ?,
                       total_validations = total_validations + 1
                   WHERE key_hash = ?""",
                (now, body.key_hash),
            )
            db.commit()
            updated = result.rowcount
        finally:
            db.close()
    except Exception as exc:
        logger.error("license_activations heartbeat: DB error: %s", exc)
        raise HTTPException(status_code=500, detail="Database error")

    return {"status": "ok", "updated": updated > 0, "recorded_at": now}


# ---------------------------------------------------------------------------
# GET /api/license/stats — admin only
# ---------------------------------------------------------------------------

@router.get("/api/license/stats")
async def license_stats(request: Request, _admin=Depends(_require_admin)):
    """Return aggregate activation counts.

    Requires AIBRAIN_ADMIN_TOKEN env var to match X-API-Key header,
    or any valid API key when AIBRAIN_ADMIN_TOKEN is not configured.
    """
    try:
        db = _get_db()
        try:
            row = db.execute("""
                SELECT
                    COUNT(*)                    AS total_unique_keys,
                    COALESCE(SUM(machine_count), 0)       AS total_machines,
                    COALESCE(SUM(total_validations), 0)   AS total_validations,
                    MIN(first_seen_at)          AS earliest_activation,
                    MAX(last_seen_at)           AS latest_heartbeat
                FROM license_activations
            """).fetchone()

            # Active in the last 30 days
            active_row = db.execute("""
                SELECT COUNT(*) AS active_30d
                FROM license_activations
                WHERE last_seen_at >= datetime('now', '-30 days')
            """).fetchone()
        finally:
            db.close()
    except Exception as exc:
        logger.error("license_activations stats: DB error: %s", exc)
        raise HTTPException(status_code=500, detail="Database error")

    return {
        "total_unique_keys": row["total_unique_keys"],
        "total_machines": row["total_machines"],
        "total_validations": row["total_validations"],
        "active_last_30d": active_row["active_30d"],
        "earliest_activation": row["earliest_activation"],
        "latest_heartbeat": row["latest_heartbeat"],
    }
