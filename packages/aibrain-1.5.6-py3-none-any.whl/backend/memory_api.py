"""
memory_api.py — REST-only memory API for no-MCP agents.

Mirrors the MCP server's memory_store, memory_search, memory_recall, memory_stats
tools as plain REST endpoints. Uses the same underlying functions so behavior is
identical whether accessed via MCP or REST.

Endpoints:
    POST /api/memory/store        — same as memory_store MCP tool
    POST /api/memory/search       — same as memory_search MCP tool
    POST /api/memory/recall       — same as memory_recall MCP tool
    GET  /api/memory/stats        — same as memory_stats MCP tool
    POST /api/memory/brain/export — full brain export as JSON
    POST /api/memory/brain/import — import brain JSON with deduplication
"""

import logging
import sys
from pathlib import Path
from typing import Optional

from fastapi import APIRouter
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

# Ensure mcp_server module is importable
_aibrain_root = Path(__file__).resolve().parent.parent
if str(_aibrain_root) not in sys.path:
    sys.path.insert(0, str(_aibrain_root))

# Import MCP server's core functions — single source of truth for all memory ops
import mcp_server

# Import brain export/import from aibrain_db for sync endpoints
from aibrain_db import brain_export, brain_export_full, brain_import

# When imported as a module (not run via CLI), _db_path may be None.
# Initialize it to the standard AIBrain DB path so REST endpoints work.
if mcp_server._db_path is None:
    import os
    mcp_server._db_path = Path(
        os.environ.get("AIBRAIN_DB", _aibrain_root / "aibrain.db")
    )
    # Initialize embedder if available (non-blocking)
    try:
        mcp_server._init_embedder()
    except Exception:
        pass
    try:
        mcp_server._init_enricher()
    except Exception:
        pass

_store = mcp_server._store
_search = mcp_server._search
_recall = mcp_server._recall
_stats = mcp_server._stats

router = APIRouter(prefix="/api/memory", tags=["Memory (no-MCP)"])


# ---------------------------------------------------------------------------
# Pydantic request models — input validation matching MCP tool schemas
# ---------------------------------------------------------------------------

class MemoryStoreRequest(BaseModel):
    """Store a memory. Matches memory_store MCP tool input schema."""
    name: str = Field(..., min_length=1, max_length=500,
                      description="Short identifier for this memory")
    content: str = Field(..., min_length=1, max_length=100000,
                         description="The memory content — what to remember")
    type: str = Field(default="reference",
                      pattern=r"^(user|feedback|project|reference|pattern|decision)$",
                      description="Memory category")
    tags: str = Field(default="", max_length=2000,
                      description="Comma-separated tags for filtering")
    importance: float = Field(default=0.5, ge=0.0, le=1.0,
                              description="0.0 to 1.0 — higher means recalled more often")


class MemorySearchRequest(BaseModel):
    """Search memories. Matches memory_search MCP tool input schema."""
    query: str = Field(..., min_length=1, max_length=5000,
                       description="Search query — keywords, phrases, or questions")
    limit: int = Field(default=10, ge=1, le=50,
                       description="Max results to return")
    search_type: Optional[str] = Field(
        default=None,
        pattern=r"^(temporal|preference|multi_session|ss_user|ss_assistant|knowledge_update|factual)$",
        description="Optional routing hint. Auto-detected if omitted."
    )


class MemoryRecallRequest(BaseModel):
    """Recall top memories. Matches memory_recall MCP tool input schema."""
    type: Optional[str] = Field(
        default=None,
        pattern=r"^(user|feedback|project|reference|pattern|decision)$",
        description="Filter by memory type (optional)"
    )
    limit: int = Field(default=10, ge=1, le=50,
                       description="Max memories to return")


class BrainImportRequest(BaseModel):
    """Import a brain export JSON payload with deduplication."""
    metadata: dict = Field(default_factory=dict,
                           description="Export metadata (agent_name, export_date, counts)")
    memories: list = Field(default_factory=list, max_length=50000,
                           description="List of memory dicts to import")
    entities: list = Field(default_factory=list, max_length=50000,
                           description="List of entity_link dicts to import")
    facts: list = Field(default_factory=list, max_length=50000,
                        description="List of semantic_fact dicts to import")
    passages: list = Field(default_factory=list, max_length=100000,
                           description="List of memory_passage dicts to import")
    patterns: list = Field(default_factory=list, max_length=10000,
                           description="List of evolution_pattern dicts to import")


# ---------------------------------------------------------------------------
# REST endpoints — same logic as MCP tools, JSON responses
# ---------------------------------------------------------------------------

@router.post("/store")
async def memory_store(body: MemoryStoreRequest):
    """Store a new memory or update an existing one.

    Same behavior as the memory_store MCP tool:
    - Identical content with same name → no-op
    - Different content with same name → update
    - New name → add
    """
    try:
        result = _store(
            name=body.name,
            content=body.content,
            mem_type=body.type,
            tags=body.tags,
            importance=body.importance,
        )
        return result
    except Exception as e:
        logger.error("memory_store error: %s", e, exc_info=True)
        return JSONResponse(
            {"error": f"Store failed: {str(e)[:200]}"},
            status_code=500,
        )


@router.post("/search")
async def memory_search(body: MemorySearchRequest):
    """Search memories with selective routing.

    Same behavior as the memory_search MCP tool:
    - Auto-detects query type and routes to optimal retrieval pipeline
    - Supports temporal queries, preference queries, etc.
    """
    try:
        results = _search(
            query=body.query,
            limit=body.limit,
            search_type=body.search_type,
        )
        return {
            "query": body.query,
            "search_type": body.search_type or "auto",
            "count": len(results),
            "results": results,
        }
    except Exception as e:
        logger.error("memory_search error: %s", e, exc_info=True)
        return JSONResponse(
            {"error": f"Search failed: {str(e)[:200]}"},
            status_code=500,
        )


@router.post("/recall")
async def memory_recall(body: MemoryRecallRequest):
    """Recall top memories by importance and usage.

    Same behavior as the memory_recall MCP tool:
    - Returns most important memories, optionally filtered by type
    - Updates access counts on recalled memories
    """
    try:
        results = _recall(
            mem_type=body.type,
            limit=body.limit,
        )
        return {
            "type_filter": body.type,
            "count": len(results),
            "results": results,
        }
    except Exception as e:
        logger.error("memory_recall error: %s", e, exc_info=True)
        return JSONResponse(
            {"error": f"Recall failed: {str(e)[:200]}"},
            status_code=500,
        )


@router.get("/stats")
async def memory_stats():
    """Get memory system statistics.

    Same behavior as the memory_stats MCP tool, plus DB file size:
    - Total count, breakdown by type, embedding status, database path, file size
    """
    try:
        stats = _stats()
        # Add DB file size (not included in core _stats)
        db_path = Path(stats.get("db_path", ""))
        if db_path.exists():
            size_bytes = db_path.stat().st_size
            stats["db_size_bytes"] = size_bytes
            stats["db_size_human"] = (
                f"{size_bytes / (1024*1024):.1f} MB" if size_bytes >= 1024*1024
                else f"{size_bytes / 1024:.1f} KB"
            )
        return stats
    except Exception as e:
        logger.error("memory_stats error: %s", e, exc_info=True)
        return JSONResponse(
            {"error": f"Stats failed: {str(e)[:200]}"},
            status_code=500,
        )


# ---------------------------------------------------------------------------
# Brain sync endpoints — export/import full knowledge base
# ---------------------------------------------------------------------------

@router.post("/brain/export")
async def brain_export_endpoint():
    """Export the full brain as JSON.

    Returns all active memories, entity links, semantic facts,
    memory passages, and evolution patterns — same format as the
    CLI ``python aibrain_db.py brain export`` command.
    """
    try:
        import json as _json
        import tempfile as _tempfile

        # brain_export writes to a file; use a temp file and read it back
        with _tempfile.NamedTemporaryFile(suffix=".json", delete=False) as tmp:
            tmp_path = tmp.name
        brain_export_full(output_path=tmp_path)
        data = _json.loads(Path(tmp_path).read_text(encoding="utf-8"))
        Path(tmp_path).unlink(missing_ok=True)
        return data
    except Exception as e:
        logger.error("brain_export error: %s", e, exc_info=True)
        return JSONResponse(
            {"error": f"Brain export failed: {str(e)[:200]}"},
            status_code=500,
        )


@router.post("/brain/import")
async def brain_import_endpoint(body: BrainImportRequest):
    """Import a brain export JSON payload with deduplication.

    Accepts the same JSON structure produced by ``/brain/export``.
    Deduplicates memories by name+type, entities by full key,
    facts by subject+predicate+object.  Adds an ``imported_from``
    tag to every imported memory for provenance tracking.
    """
    try:
        import json as _json
        import tempfile as _tempfile

        # brain_import reads from a file; write body to a temp file
        export_data = body.model_dump()
        with _tempfile.NamedTemporaryFile(
            mode="w", suffix=".json", delete=False, encoding="utf-8"
        ) as tmp:
            _json.dump(export_data, tmp)
            tmp_path = tmp.name
        stats = brain_import(tmp_path)
        Path(tmp_path).unlink(missing_ok=True)
        return {"status": "ok", "stats": stats}
    except Exception as e:
        logger.error("brain_import error: %s", e, exc_info=True)
        return JSONResponse(
            {"error": f"Brain import failed: {str(e)[:200]}"},
            status_code=500,
        )
