"""Auth package for myaibrain.org user accounts.

Modules:
    password  — bcrypt hashing (cost 12+), password strength checks.
    sessions  — 32-byte random session tokens stored in SQLite + HttpOnly cookies.
    totp      — RFC 6238 TOTP with prev/next code tolerance (no pyotp dep).
    oauth     — GitHub/Google/Microsoft flows with PKCE, state, nonce.
    email     — SMTP send helper for reset + verification links.
    db        — thin sqlite3 connection helper pointed at aibrain.db.
"""
