"""Auth DB helper — opens aibrain.db with row_factory=Row.

Pointed at AIBRAIN_DB env var (for tests) or the repo's aibrain.db.
"""

import os
import sqlite3
from pathlib import Path


def _db_path() -> str:
    env = os.environ.get("AIBRAIN_DB")
    if env:
        return env
    # Walk up from this file to the aibrain repo root.
    return str(Path(__file__).resolve().parent.parent.parent / "aibrain.db")


def get_conn() -> sqlite3.Connection:
    """Return a fresh sqlite3 connection with row_factory=Row.

    Caller is responsible for closing. We open a new connection per call
    because sqlite3 connections are not safe to share across threads under
    FastAPI's default threadpool.
    """
    conn = sqlite3.connect(_db_path(), timeout=10, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def ensure_schema():
    """Run aibrain_db._migrate_schema against our DB (idempotent).

    Used in tests to make sure the auth tables exist in a fresh temp DB.
    """
    import sys
    repo_root = Path(__file__).resolve().parent.parent.parent
    if str(repo_root) not in sys.path:
        sys.path.insert(0, str(repo_root))
    # We can't call aibrain_db.get_db() because that caches a different path.
    # Instead, connect to our path and run the migration against it directly.
    conn = get_conn()
    try:
        # Need base schema first — run _init_schema against our connection.
        import aibrain_db
        aibrain_db._init_schema(conn)
        aibrain_db._migrate_schema(conn)
        conn.commit()
    finally:
        conn.close()
