"""OAuth flows for GitHub, Google, Microsoft — PKCE + state + nonce.

Design:
- All three providers share one state-machine. The start endpoint stores
  code_verifier + state + (optional) link_user_id in the oauth_states table.
- The callback endpoint looks up the state row, exchanges the code for a
  token, fetches the user profile, and either creates a user, links to an
  existing user, or logs in an existing user — depending on email match and
  whether link_user_id was set.
- Missing env vars = provider disabled. Never crash on missing config.

Test hook: set `_mock_provider_exchange` to a callable(provider, code) ->
(provider_user_id, email) to avoid real HTTP in tests.
"""

import base64
import hashlib
import json
import logging
import os
import secrets
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone
from typing import Callable, Optional

from .db import get_conn

logger = logging.getLogger(__name__)

# Test hook — when set, skip real HTTP and call this instead.
_mock_provider_exchange: Optional[Callable[[str, str], tuple[str, str]]] = None


def set_mock_exchange(fn):
    global _mock_provider_exchange
    _mock_provider_exchange = fn


def clear_mock_exchange():
    global _mock_provider_exchange
    _mock_provider_exchange = None


# ---------------------------------------------------------------------------
# Provider config
# ---------------------------------------------------------------------------

PROVIDERS = {
    "github": {
        "authorize_url": "https://github.com/login/oauth/authorize",
        "token_url": "https://github.com/login/oauth/access_token",
        "userinfo_url": "https://api.github.com/user",
        "email_url": "https://api.github.com/user/emails",
        "scope": "read:user user:email",
        "oidc": False,
    },
    "google": {
        "authorize_url": "https://accounts.google.com/o/oauth2/v2/auth",
        "token_url": "https://oauth2.googleapis.com/token",
        "userinfo_url": "https://www.googleapis.com/oauth2/v3/userinfo",
        "scope": "openid email profile",
        "oidc": True,
    },
    "microsoft": {
        "authorize_url": "https://login.microsoftonline.com/common/oauth2/v2.0/authorize",
        "token_url": "https://login.microsoftonline.com/common/oauth2/v2.0/token",
        "userinfo_url": "https://graph.microsoft.com/v1.0/me",
        "scope": "openid email profile User.Read",
        "oidc": True,
    },
}


def provider_configured(provider: str) -> bool:
    """Check that client_id and client_secret env vars are set."""
    if provider not in PROVIDERS:
        return False
    key = provider.upper()
    return bool(
        os.environ.get(f"{key}_OAUTH_CLIENT_ID")
        and os.environ.get(f"{key}_OAUTH_CLIENT_SECRET")
    )


def enabled_providers() -> list[str]:
    """Return the list of providers with env vars configured."""
    return [p for p in PROVIDERS if provider_configured(p)]


def _client_credentials(provider: str) -> tuple[str, str]:
    key = provider.upper()
    return (
        os.environ.get(f"{key}_OAUTH_CLIENT_ID", ""),
        os.environ.get(f"{key}_OAUTH_CLIENT_SECRET", ""),
    )


def _redirect_uri(provider: str, base_url: str | None = None) -> str:
    if base_url is None:
        base_url = os.environ.get("AIBRAIN_BASE_URL", "http://localhost:8001")
    return f"{base_url.rstrip('/')}/auth/oauth/{provider}/callback"


# ---------------------------------------------------------------------------
# PKCE helpers
# ---------------------------------------------------------------------------

def _pkce_verifier() -> str:
    # 43-128 chars per RFC 7636
    return secrets.token_urlsafe(64)[:96]


def _pkce_challenge(verifier: str) -> str:
    h = hashlib.sha256(verifier.encode("ascii")).digest()
    return base64.urlsafe_b64encode(h).rstrip(b"=").decode("ascii")


# ---------------------------------------------------------------------------
# State table operations
# ---------------------------------------------------------------------------

STATE_TTL_MINUTES = 10


def _iso(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%d %H:%M:%S")


def store_state(
    provider: str,
    code_verifier: str,
    nonce: str | None,
    link_user_id: str | None,
    redirect_to: str | None,
) -> str:
    state = secrets.token_urlsafe(32)
    now = datetime.now(timezone.utc)
    expires = now + timedelta(minutes=STATE_TTL_MINUTES)
    conn = get_conn()
    try:
        conn.execute(
            "INSERT INTO oauth_states (state, provider, code_verifier, nonce, "
            "link_user_id, redirect_to, created_at, expires_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (
                state, provider, code_verifier, nonce,
                link_user_id, redirect_to,
                _iso(now), _iso(expires),
            ),
        )
    finally:
        conn.close()
    return state


def consume_state(state: str) -> dict | None:
    """Look up and delete a state row. Returns dict or None if not found/expired."""
    if not state:
        return None
    conn = get_conn()
    try:
        row = conn.execute(
            "SELECT * FROM oauth_states WHERE state = ?", (state,)
        ).fetchone()
        if not row:
            return None
        conn.execute("DELETE FROM oauth_states WHERE state = ?", (state,))
        # Expiry check
        try:
            exp = datetime.strptime(row["expires_at"], "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
        except ValueError:
            exp = datetime.fromisoformat(row["expires_at"])
            if exp.tzinfo is None:
                exp = exp.replace(tzinfo=timezone.utc)
        if exp < datetime.now(timezone.utc):
            return None
        return {k: row[k] for k in row.keys()}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Authorize URL builder
# ---------------------------------------------------------------------------

def build_authorize_url(
    provider: str,
    link_user_id: str | None = None,
    redirect_to: str | None = None,
    base_url: str | None = None,
) -> tuple[str, str]:
    """Return (authorize_url, state). Raises if provider not configured."""
    if not provider_configured(provider):
        raise ValueError(f"OAuth provider not configured: {provider}")
    cfg = PROVIDERS[provider]
    client_id, _ = _client_credentials(provider)

    verifier = _pkce_verifier()
    challenge = _pkce_challenge(verifier)
    nonce = secrets.token_urlsafe(16) if cfg["oidc"] else None
    state = store_state(provider, verifier, nonce, link_user_id, redirect_to)

    params = {
        "response_type": "code",
        "client_id": client_id,
        "redirect_uri": _redirect_uri(provider, base_url),
        "scope": cfg["scope"],
        "state": state,
        "code_challenge": challenge,
        "code_challenge_method": "S256",
    }
    if nonce:
        params["nonce"] = nonce
    url = f"{cfg['authorize_url']}?{urllib.parse.urlencode(params)}"
    return url, state


# ---------------------------------------------------------------------------
# Token exchange + userinfo
# ---------------------------------------------------------------------------

def _http_post(url: str, data: dict, headers: dict = None) -> dict:
    body = urllib.parse.urlencode(data).encode("utf-8")
    hdrs = {
        "Accept": "application/json",
        "Content-Type": "application/x-www-form-urlencoded",
    }
    if headers:
        hdrs.update(headers)
    req = urllib.request.Request(url, data=body, headers=hdrs, method="POST")
    with urllib.request.urlopen(req, timeout=10) as resp:
        payload = resp.read().decode("utf-8")
    try:
        return json.loads(payload)
    except json.JSONDecodeError:
        # GitHub can return form-urlencoded if Accept header ignored
        return dict(urllib.parse.parse_qsl(payload))


def _http_get(url: str, token: str) -> dict | list:
    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/json",
            "User-Agent": "aibrain-auth",
        },
    )
    with urllib.request.urlopen(req, timeout=10) as resp:
        return json.loads(resp.read().decode("utf-8"))


def exchange_code_for_profile(
    provider: str,
    code: str,
    code_verifier: str,
    base_url: str | None = None,
) -> tuple[str, str]:
    """Exchange an OAuth code for (provider_user_id, email).

    Uses the _mock_provider_exchange hook when set (tests).
    """
    if _mock_provider_exchange is not None:
        return _mock_provider_exchange(provider, code)

    if not provider_configured(provider):
        raise ValueError(f"OAuth provider not configured: {provider}")

    cfg = PROVIDERS[provider]
    client_id, client_secret = _client_credentials(provider)

    token_resp = _http_post(
        cfg["token_url"],
        {
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": _redirect_uri(provider, base_url),
            "client_id": client_id,
            "client_secret": client_secret,
            "code_verifier": code_verifier,
        },
    )
    access_token = token_resp.get("access_token")
    if not access_token:
        raise ValueError(f"OAuth token exchange failed: {token_resp.get('error', 'unknown')}")

    # Fetch profile
    profile = _http_get(cfg["userinfo_url"], access_token)

    if provider == "github":
        uid = str(profile.get("id") or "")
        email = profile.get("email") or ""
        if not email:
            # Fetch emails endpoint — user may have no public email.
            emails = _http_get(cfg["email_url"], access_token)
            if isinstance(emails, list):
                primary = next((e for e in emails if e.get("primary")), None)
                if primary:
                    email = primary.get("email", "")
                elif emails:
                    email = emails[0].get("email", "")
    elif provider == "google":
        uid = str(profile.get("sub") or "")
        email = profile.get("email") or ""
    elif provider == "microsoft":
        uid = str(profile.get("id") or "")
        email = profile.get("mail") or profile.get("userPrincipalName") or ""
    else:
        raise ValueError(f"Unknown provider: {provider}")

    if not uid or not email:
        raise ValueError(f"OAuth profile missing id/email: {profile}")
    return uid, email.lower()
