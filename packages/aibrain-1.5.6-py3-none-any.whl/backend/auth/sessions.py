"""Session management — 32-byte random tokens in SQLite + HttpOnly cookies.

30-day sliding expiry. On every successful load we refresh expires_at so
active users stay logged in; inactive sessions die after 30 days.
"""

import secrets
from datetime import datetime, timedelta, timezone

from .db import get_conn

COOKIE_NAME = "aibrain_session"
SESSION_TTL_DAYS = 30
SESSION_TOKEN_BYTES = 32  # 256 bits


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%d %H:%M:%S")


def create_session(user_id: str, ip: str = "", user_agent: str = "") -> tuple[str, str]:
    """Create a new session row. Returns (token, expires_iso)."""
    token = secrets.token_urlsafe(SESSION_TOKEN_BYTES)
    now = _now()
    expires = now + timedelta(days=SESSION_TTL_DAYS)
    conn = get_conn()
    try:
        conn.execute(
            "INSERT INTO sessions (token, user_id, created_at, expires_at, ip, user_agent) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (token, user_id, _iso(now), _iso(expires), ip or "", user_agent or ""),
        )
    finally:
        conn.close()
    return token, _iso(expires)


def load_session(token: str) -> dict | None:
    """Look up a session by token. Returns user row dict or None.

    Also slides the expiry forward if the session is valid. Cleans up
    expired rows for the same user as a side-effect.
    """
    if not token:
        return None
    conn = get_conn()
    try:
        row = conn.execute(
            "SELECT s.token, s.user_id, s.expires_at, u.* "
            "FROM sessions s JOIN users u ON u.id = s.user_id "
            "WHERE s.token = ?",
            (token,),
        ).fetchone()
        if not row:
            return None
        # Parse expires_at and check expiry
        try:
            exp = datetime.strptime(row["expires_at"], "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
        except ValueError:
            # Handle ISO format too
            exp = datetime.fromisoformat(row["expires_at"].replace("Z", "+00:00"))
            if exp.tzinfo is None:
                exp = exp.replace(tzinfo=timezone.utc)
        if exp <= _now():
            # Expired — delete and return None
            conn.execute("DELETE FROM sessions WHERE token = ?", (token,))
            return None
        # Sliding expiry — refresh expires_at
        new_exp = _now() + timedelta(days=SESSION_TTL_DAYS)
        conn.execute(
            "UPDATE sessions SET expires_at = ? WHERE token = ?",
            (_iso(new_exp), token),
        )
        # Return flat dict
        return {k: row[k] for k in row.keys()}
    finally:
        conn.close()


def destroy_session(token: str) -> bool:
    """Delete a session by token. Returns True if a row was deleted."""
    if not token:
        return False
    conn = get_conn()
    try:
        cur = conn.execute("DELETE FROM sessions WHERE token = ?", (token,))
        return cur.rowcount > 0
    finally:
        conn.close()


def destroy_all_for_user(user_id: str) -> int:
    """Invalidate every session for a user (password change, 2FA disable)."""
    conn = get_conn()
    try:
        cur = conn.execute("DELETE FROM sessions WHERE user_id = ?", (user_id,))
        return cur.rowcount
    finally:
        conn.close()


def set_session_cookie(response, token: str):
    """Attach session cookie to a FastAPI response.

    HttpOnly + Secure + SameSite=Lax — standard hardening.
    Secure is forced on unless AIBRAIN_COOKIE_INSECURE=1 (dev / local tests).
    """
    import os
    insecure = os.environ.get("AIBRAIN_COOKIE_INSECURE") == "1"
    response.set_cookie(
        key=COOKIE_NAME,
        value=token,
        max_age=SESSION_TTL_DAYS * 24 * 3600,
        httponly=True,
        secure=not insecure,
        samesite="lax",
        path="/",
    )


def clear_session_cookie(response):
    response.delete_cookie(key=COOKIE_NAME, path="/")
