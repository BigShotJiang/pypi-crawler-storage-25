"""Minimal SMTP helper for reset + verification emails.

Reads SMTP config from env. In tests we monkey-patch `send_email` to capture
calls instead of hitting a real SMTP server.
"""

import logging
import os
import smtplib
from email.message import EmailMessage

logger = logging.getLogger(__name__)

# Test hook — tests set this to capture emails without SMTP.
_test_inbox: list[dict] | None = None


def enable_test_capture() -> list[dict]:
    """Redirect all sends into an in-memory list. Returns the list."""
    global _test_inbox
    _test_inbox = []
    return _test_inbox


def disable_test_capture():
    global _test_inbox
    _test_inbox = None


def send_email(to: str, subject: str, body: str, *, html: bool = False) -> bool:
    """Send an email. Returns True on success, False on any failure.

    When test capture is active, stores the message and returns True without
    hitting SMTP. When SMTP env vars are missing, logs a warning and returns
    False (signup still succeeds — email failure must not block signup).
    """
    global _test_inbox
    if _test_inbox is not None:
        _test_inbox.append({"to": to, "subject": subject, "body": body, "html": html})
        return True

    host = os.environ.get("SMTP_HOST")
    port = int(os.environ.get("SMTP_PORT", "587"))
    user = os.environ.get("SMTP_USER")
    password = os.environ.get("SMTP_PASSWORD")
    sender = os.environ.get("SMTP_FROM") or user or "noreply@myaibrain.org"

    if not host or not user or not password:
        logger.warning("SMTP not configured — email to %s not sent: %s", to, subject)
        return False

    msg = EmailMessage()
    msg["From"] = sender
    msg["To"] = to
    msg["Subject"] = subject
    if html:
        msg.set_content("This email requires an HTML-capable client.")
        msg.add_alternative(body, subtype="html")
    else:
        msg.set_content(body)

    try:
        with smtplib.SMTP(host, port, timeout=10) as s:
            s.starttls()
            s.login(user, password)
            s.send_message(msg)
        return True
    except Exception as e:
        logger.error("SMTP send failed: %s", e)
        return False
