"""RFC 6238 TOTP implementation — stdlib only, no pyotp dependency.

Why roll our own: pyotp adds a dep for ~40 lines of code. RFC 6238 is tiny
and the algorithm is stable since 2011.

Window: 30s. Tolerance: ±1 step (accept previous and next code for clock
skew). Compatible with Google Authenticator, Authy, 1Password, etc.
"""

import base64
import hashlib
import hmac
import secrets
import struct
import time
import urllib.parse

TOTP_DIGITS = 6
TOTP_STEP = 30  # seconds
TOTP_ALGORITHM = "SHA1"  # RFC 6238 default, universal compat


def generate_secret() -> str:
    """Generate a random base32 TOTP secret (160 bits, 32 base32 chars)."""
    # 20 random bytes = 160 bits entropy — RFC 4226 / 6238 recommendation.
    raw = secrets.token_bytes(20)
    return base64.b32encode(raw).decode("ascii").rstrip("=")


def _hotp(secret_b32: str, counter: int) -> str:
    """RFC 4226 HOTP — the underlying primitive for TOTP."""
    # base32 decoding needs padding restored.
    padding = "=" * ((8 - len(secret_b32) % 8) % 8)
    key = base64.b32decode(secret_b32.upper() + padding)
    # 8-byte big-endian counter
    counter_bytes = struct.pack(">Q", counter)
    digest = hmac.new(key, counter_bytes, hashlib.sha1).digest()
    # Dynamic truncation (RFC 4226 §5.3)
    offset = digest[-1] & 0x0F
    code_int = (
        ((digest[offset] & 0x7F) << 24)
        | ((digest[offset + 1] & 0xFF) << 16)
        | ((digest[offset + 2] & 0xFF) << 8)
        | (digest[offset + 3] & 0xFF)
    )
    code = code_int % (10 ** TOTP_DIGITS)
    return str(code).zfill(TOTP_DIGITS)


def current_code(secret_b32: str, now: float | None = None) -> str:
    """Current TOTP code for this secret (at `now` or wall clock)."""
    t = now if now is not None else time.time()
    counter = int(t // TOTP_STEP)
    return _hotp(secret_b32, counter)


def verify_code(secret_b32: str, code: str, now: float | None = None) -> bool:
    """Verify a TOTP code with ±1 step tolerance for clock skew.

    Uses constant-time comparison. Accepts None/empty code as False.
    """
    if not secret_b32 or not code:
        return False
    code = code.strip().replace(" ", "")
    if not code.isdigit() or len(code) != TOTP_DIGITS:
        return False
    t = now if now is not None else time.time()
    base_counter = int(t // TOTP_STEP)
    for delta in (-1, 0, 1):
        expected = _hotp(secret_b32, base_counter + delta)
        if hmac.compare_digest(expected, code):
            return True
    return False


def otpauth_uri(secret_b32: str, account: str, issuer: str = "myaibrain.org") -> str:
    """Build an otpauth:// URI for QR-code provisioning.

    Format: otpauth://totp/Issuer:account?secret=...&issuer=...&algorithm=SHA1&digits=6&period=30
    """
    label = f"{issuer}:{account}"
    params = {
        "secret": secret_b32,
        "issuer": issuer,
        "algorithm": TOTP_ALGORITHM,
        "digits": str(TOTP_DIGITS),
        "period": str(TOTP_STEP),
    }
    return f"otpauth://totp/{urllib.parse.quote(label)}?{urllib.parse.urlencode(params)}"
