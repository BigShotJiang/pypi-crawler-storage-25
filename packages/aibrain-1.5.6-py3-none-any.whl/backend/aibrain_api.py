"""
AIBrain API — FastAPI router for the portable AI brain.
Memory DB, cron registry, skills browser, agent status, workflow groups.
"""

import json
import logging
import os
import re
import sqlite3
import sys
import time as _time_module
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

_API_START_TIME = _time_module.time()

logger = logging.getLogger(__name__)

from fastapi import APIRouter, Query, Request
from fastapi.responses import JSONResponse

def _require_localhost(request: Request):
    """Enforce localhost-only access for sensitive config write endpoints."""
    host = (request.client.host if request.client else "unknown")
    if host not in {"127.0.0.1", "::1", "localhost"}:
        raise __import__("fastapi").HTTPException(
            status_code=403,
            detail=f"Config writes are only allowed from localhost (got: {host})"
        )


# Import consolidated DB — single source of truth
sys.path.insert(0, str(Path(__file__).parent.parent))
sys.path.insert(0, str(Path(__file__).parent))
import aibrain_db
import evolution_engine
import permissions
import trace_logger
from aibrain import __version__ as _AIBRAIN_VERSION
from tiers import require_tier, check_tier, TierFeature, is_feature_allowed

# Notification callback — set by main.py to broadcast real-time events
_notify_callback = None

def set_notify_callback(fn):
    global _notify_callback
    _notify_callback = fn

# ---------------------------------------------------------------------------
# Safe SQL UPDATE helper — validates column names against an allow-list
# ---------------------------------------------------------------------------

def _safe_update(table: str, allowed_columns: frozenset, updates: dict,
                 where: str, params: list) -> str:
    """Build a safe UPDATE statement, rejecting any column not in allowed_columns.

    Returns the SQL string. Appends column values to *params* in order.
    Raises ValueError if a column name is not in the allow-list.
    """
    set_parts = []
    for col, val in updates.items():
        if col not in allowed_columns:
            raise ValueError(f"Column {col!r} not in allowed set for {table}")
        set_parts.append(f"{col} = ?")
        params.append(val)
    if not set_parts:
        raise ValueError("No columns to update")
    return f"UPDATE {table} SET {', '.join(set_parts)} WHERE {where}"  # noqa:SQL F-STRING


# ---------------------------------------------------------------------------
# Paths — configurable via env vars, config file, or sensible defaults
# ---------------------------------------------------------------------------

AIBRAIN_ROOT = Path(os.environ.get("AIBRAIN_ROOT", Path(__file__).parent.parent))
_config_file = AIBRAIN_ROOT / "config.json"

def _load_config():
    """Load paths from config.json if it exists, else use defaults."""
    defaults = {
        "memory_db": str(AIBRAIN_ROOT / "memory" / "memory.db"),
        "cron_jobs": str(AIBRAIN_ROOT / "scheduled_jobs.json"),
        "skills_dir": str(Path.home() / ".claude" / "skills"),
        "skills_agents_dir": str(Path.home() / ".agents" / "skills"),
        "subagents_dir": str(AIBRAIN_ROOT / "subagents"),
        "last_evolution": str(AIBRAIN_ROOT / ".tmp" / "last_evolution.txt"),
        "inbox": str(AIBRAIN_ROOT / ".tmp" / "inbox.jsonl"),
    }
    if _config_file.exists():
        try:
            overrides = json.loads(_config_file.read_text(encoding="utf-8"))
            defaults.update({k: v for k, v in overrides.items() if v})
        except (json.JSONDecodeError, OSError):
            pass
    # Env vars override everything (AIBRAIN_MEMORY_DB, AIBRAIN_CRON_JOBS, etc.)
    for key in defaults:
        env_key = f"AIBRAIN_{key.upper()}"
        if os.environ.get(env_key):
            defaults[key] = os.environ[env_key]
    return defaults

_cfg = _load_config()

MEMORY_DB_PATH = Path(_cfg["memory_db"])
CRON_JOBS_PATH = Path(_cfg["cron_jobs"])
SKILLS_DIR = Path(_cfg["skills_dir"])
SKILLS_AGENTS_DIR = Path(_cfg["skills_agents_dir"])
SUBAGENTS_DIR = Path(_cfg["subagents_dir"])
LAST_EVOLUTION = Path(_cfg["last_evolution"])
AGENT_INBOX = Path(_cfg["inbox"])

router = APIRouter(prefix="/api/agent", tags=["AIBrain"])

# Skill search paths
_SKILLS_PATHS = [SKILLS_DIR, SKILLS_AGENTS_DIR]

# ---------------------------------------------------------------------------
# Mobile Pairing — QR code based device pairing (like WhatsApp Web)
# ---------------------------------------------------------------------------

PAIRING_DB_PATH = AIBRAIN_ROOT / "pairing.db"


def get_pairing_db():
    db = sqlite3.connect(str(PAIRING_DB_PATH))
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    db.execute("""
        CREATE TABLE IF NOT EXISTS pairings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            token TEXT UNIQUE NOT NULL,
            created_at TEXT NOT NULL,
            expires_at TEXT NOT NULL,
            confirmed INTEGER DEFAULT 0,
            device_info TEXT DEFAULT '',
            session_token TEXT DEFAULT '',
            last_seen TEXT DEFAULT ''
        )
    """)
    db.commit()
    return db


@router.post("/pair/generate")
async def pair_generate():
    """Generate a pairing token for QR code display on desktop."""
    import secrets as _secrets
    token = _secrets.token_urlsafe(32)
    now = datetime.now()
    expires = now + timedelta(minutes=5)

    db = get_pairing_db()
    # Clean up expired tokens
    db.execute("DELETE FROM pairings WHERE expires_at < ?", (now.isoformat(),))
    db.execute(
        "INSERT INTO pairings (token, created_at, expires_at) VALUES (?, ?, ?)",
        (token, now.isoformat(), expires.isoformat()),
    )
    db.commit()
    db.close()

    return {"token": token, "expires_at": expires.isoformat()}


@router.post("/pair/confirm")
async def pair_confirm(body: dict):
    """Mobile sends scanned token to confirm pairing."""
    import secrets as _secrets
    token = body.get("token")
    device_info = body.get("device_info", "Unknown device")

    if not token:
        return JSONResponse({"error": "token required"}, status_code=400)

    db = get_pairing_db()
    now = datetime.now()

    import hmac
    # Fetch all unexpired unconfirmed pairings and compare with constant-time check
    rows = db.execute(
        "SELECT * FROM pairings WHERE expires_at > ? AND confirmed = 0",
        (now.isoformat(),),
    ).fetchall()
    row = None
    for r in rows:
        if hmac.compare_digest(r["token"], token):
            row = r
            break

    if not row:
        db.close()
        return JSONResponse({"error": "Invalid or expired token"}, status_code=404)

    session_token = _secrets.token_urlsafe(32)
    db.execute(
        "UPDATE pairings SET confirmed = 1, device_info = ?, session_token = ?, last_seen = ? WHERE token = ?",
        (device_info, session_token, now.isoformat(), token),
    )
    db.commit()
    db.close()

    return {"status": "paired", "session_token": session_token, "device_info": device_info}


@router.get("/pair/status")
async def pair_status(request: Request, token: str = Query(None)):
    """Check if a pairing token has been confirmed. Desktop polls this."""
    _require_localhost(request)
    if not token:
        # Return all active pairings (no session tokens exposed)
        db = get_pairing_db()
        rows = db.execute(
            "SELECT confirmed, device_info, last_seen, created_at FROM pairings WHERE confirmed = 1 ORDER BY last_seen DESC"
        ).fetchall()
        db.close()
        return {"paired_devices": [dict(r) for r in rows], "count": len(rows)}

    db = get_pairing_db()
    now = datetime.now()
    row = db.execute(
        "SELECT confirmed, device_info, session_token FROM pairings WHERE token = ? AND expires_at > ?",
        (token, now.isoformat()),
    ).fetchone()
    db.close()

    if not row:
        return {"status": "expired"}

    if row["confirmed"]:
        return {"status": "paired", "device_info": row["device_info"], "session_token": row["session_token"]}

    return {"status": "waiting"}


@router.delete("/pair/{token}")
async def pair_revoke(token: str):
    """Revoke a pairing / disconnect a device."""
    db = get_pairing_db()
    db.execute("DELETE FROM pairings WHERE token = ? OR session_token = ?", (token, token))
    db.commit()
    db.close()
    return {"status": "revoked"}

# ---------------------------------------------------------------------------
# Memory DB helpers — now backed by consolidated aibrain_db
# ---------------------------------------------------------------------------

def get_db():
    """Return a NEW connection to the consolidated DB (caller-managed lifecycle).
    Endpoints that call db.close() need their own connection — not the singleton.
    """
    import sqlite3 as _sql
    db = _sql.connect(str(aibrain_db.DB_PATH))
    db.row_factory = _sql.Row
    db.execute("PRAGMA journal_mode=WAL")
    return db


# ---------------------------------------------------------------------------
# Memory endpoints
# ---------------------------------------------------------------------------

@router.get("/memories")
async def list_memories(
    type: Optional[str] = Query(None),
    tag: Optional[str] = Query(None),
    sort: Optional[str] = Query("updated"),
    order: Optional[str] = Query("desc"),
    page: int = Query(1),
    per_page: int = Query(50),
):
    # Cap per_page to prevent excessive memory use
    per_page = min(max(1, per_page), 500)
    db = get_db()
    query = "SELECT id, name, type, tags, substr(content, 1, 200) as preview, created, updated FROM memories WHERE active = 1"
    count_query = "SELECT COUNT(*) as total FROM memories WHERE active = 1"
    params = []
    count_params = []
    if type:
        query += " AND type = ?"
        count_query += " AND type = ?"
        params.append(type)
        count_params.append(type)
    if tag:
        query += " AND tags LIKE ?"
        count_query += " AND tags LIKE ?"
        params.append(f"%{tag}%")
        count_params.append(f"%{tag}%")

    # Validate sort column
    allowed_sorts = {"name", "type", "created", "updated", "id"}
    sort_col = sort if sort in allowed_sorts else "updated"
    sort_dir = "ASC" if order.lower() == "asc" else "DESC"
    query += f" ORDER BY {sort_col} {sort_dir}"

    # Pagination
    total = db.execute(count_query, count_params).fetchone()["total"]
    offset = (max(1, page) - 1) * per_page
    query += " LIMIT ? OFFSET ?"
    params.extend([per_page, offset])

    rows = db.execute(query, params).fetchall()
    db.close()
    return {
        "count": len(rows),
        "total": total,
        "page": page,
        "per_page": per_page,
        "pages": (total + per_page - 1) // per_page,
        "memories": [dict(r) for r in rows],
    }


@router.get("/memories/search")
async def search_memories(q: str = Query(...), limit: int = Query(20)):
    from security import safe_limit
    limit = safe_limit(limit, 200)

    # ENHANCED PATH: hybrid search (FTS5 + semantic embeddings + RRF fusion)
    # Falls back to DIRECT PATH (FTS5 only) if hybrid search unavailable
    try:
        sys.path.insert(0, str(Path(__file__).parent.parent))
        from mcp_server import _search as hybrid_search
        results = hybrid_search(q, limit=limit)
        return {
            "query": q, "count": len(results),
            "search_mode": "hybrid",
            "results": [
                {k: v for k, v in r.items() if k not in ("embedding",)}
                for r in results
            ],
        }
    except Exception as e:
        logger.info("Hybrid search unavailable, falling back to FTS5: %s", e)

    # DIRECT PATH: basic FTS5 keyword search (always works)
    db = get_db()
    safe_q = aibrain_db._sanitize_fts5(q)
    try:
        rows = db.execute("""
            SELECT m.id, m.name, m.type, m.tags, m.content, m.created, m.updated, rank
            FROM memories_fts fts
            JOIN memories m ON m.id = fts.rowid
            WHERE memories_fts MATCH ? AND m.active = 1
            ORDER BY rank
            LIMIT ?
        """, (safe_q, limit)).fetchall()
    except sqlite3.OperationalError:
        rows = []
    db.close()
    return {"query": q, "count": len(rows), "search_mode": "fts5", "results": [dict(r) for r in rows]}


@router.get("/search")
async def unified_search(q: str = Query(...), limit: int = Query(10)):
    """Search across memories, workflows, and skills in one call."""
    from security import safe_limit
    limit = safe_limit(limit, 200)
    results = {"query": q, "memories": [], "workflows": [], "skills": []}
    ql = q.lower()

    # 1) Memory search — try hybrid first, fall back to FTS5
    try:
        sys.path.insert(0, str(Path(__file__).parent.parent))
        from mcp_server import _search as hybrid_search
        hybrid_results = hybrid_search(q, limit=limit)
        results["memories"] = [
            {"id": r["id"], "name": r["name"], "type": r.get("type", ""),
             "tags": r.get("tags", ""), "preview": (r.get("content") or "")[:150]}
            for r in hybrid_results
        ]
        results["search_mode"] = "hybrid"
    except Exception:
        db = get_db()
        safe_q = aibrain_db._sanitize_fts5(q)
        try:
            mem_rows = db.execute("""
                SELECT m.id, m.name, m.type, m.tags, substr(m.content, 1, 150) as preview, rank
                FROM memories_fts fts
                JOIN memories m ON m.id = fts.rowid
                WHERE memories_fts MATCH ? AND m.active = 1
                ORDER BY rank LIMIT ?
            """, (safe_q, limit)).fetchall()
            results["memories"] = [dict(r) for r in mem_rows]
        except sqlite3.OperationalError:
            pass
        db.close()
        results["search_mode"] = "fts5"

    # 2) Workflow search from consolidated DB
    try:
        for job in aibrain_db.list_scheduled_jobs():
            name = (job.get("name") or "").lower()
            desc = (job.get("notes") or "").lower()
            prompt = (job.get("prompt") or "").lower()
            if ql in name or ql in desc or ql in prompt:
                results["workflows"].append({
                    "name": job.get("name"),
                    "display_name": job.get("name", "").replace("_", " ").title(),
                    "cron": job.get("cron"),
                    "description": job.get("notes"),
                })
                if len(results["workflows"]) >= limit:
                    break
    except (sqlite3.OperationalError, KeyError, TypeError) as e:
        logger.warning("Workflow search failed: %s", e)

    # 3) Skill search (name, description)
    for p in _SKILLS_PATHS:
        if not p.exists():
            continue
        for f in sorted(p.iterdir()):
            if not f.suffix == ".md":
                continue
            name = f.stem.replace("_", " ").replace("-", " ").lower()
            if ql in name:
                results["skills"].append({"name": f.stem, "path": str(f)})
                if len(results["skills"]) >= limit:
                    break

    results["total"] = len(results["memories"]) + len(results["workflows"]) + len(results["skills"])
    return results


@router.get("/memories/summary")
async def memory_summary():
    db = get_db()
    counts = db.execute(
        "SELECT type, COUNT(*) as cnt FROM memories WHERE active = 1 GROUP BY type ORDER BY type"
    ).fetchall()
    total = sum(r["cnt"] for r in counts)
    recent = db.execute(
        "SELECT id, name, type, tags, substr(content, 1, 120) as preview, updated FROM memories WHERE active = 1 ORDER BY updated DESC LIMIT 10"
    ).fetchall()
    # Include satellite info in summary
    satellites = []
    try:
        sat_rows = db.execute("SELECT name, db_path FROM satellite_dbs WHERE active=1").fetchall()
        db_dir = Path(db.execute("PRAGMA database_list").fetchone()[2]).parent
        for sr in sat_rows:
            sat_path = db_dir / sr["db_path"] if not Path(sr["db_path"]).is_absolute() else Path(sr["db_path"])
            mem_count = 0
            size_kb = 0
            if sat_path.exists():
                size_kb = int(sat_path.stat().st_size / 1024)
                try:
                    import sqlite3 as _sq
                    sdb = _sq.connect(str(sat_path))
                    mem_count = sdb.execute("SELECT COUNT(*) FROM memories").fetchone()[0]
                    sdb.close()
                except Exception:
                    pass
            satellites.append({"name": sr["name"], "path": str(sat_path), "memory_count": mem_count, "size_kb": size_kb, "keywords": []})
    except Exception:
        pass
    db.close()
    return {
        "total": total,
        "by_type": {r["type"]: r["cnt"] for r in counts},
        "recent": [dict(r) for r in recent],
        "satellites": satellites,
    }


@router.get("/brain/growth")
async def brain_growth():
    """Return brain growth metrics: memory counts over time and quality trend."""
    db = get_db()
    try:
        total = db.execute(
            "SELECT COUNT(*) FROM memories WHERE active = 1"
        ).fetchone()[0]

        memories_30d = db.execute(
            "SELECT COUNT(*) FROM memories WHERE active = 1 AND created >= datetime('now', '-30 days')"
        ).fetchone()[0]

        memories_7d = db.execute(
            "SELECT COUNT(*) FROM memories WHERE active = 1 AND created >= datetime('now', '-7 days')"
        ).fetchone()[0]

        # Quality score from evolution_outcomes if the table exists
        avg_quality_30d = None
        try:
            row = db.execute(
                "SELECT AVG(quality_score) FROM evolution_outcomes WHERE created >= datetime('now', '-30 days')"
            ).fetchone()
            if row and row[0] is not None:
                avg_quality_30d = round(float(row[0]), 3)
        except Exception:
            pass

        # Growth percentage: memories added in last 30d vs the base count before that period
        base = total - memories_30d
        growth_pct_30d = round((memories_30d / base) * 100, 1) if base > 0 else 0.0

        return {
            "memory_count": total,
            "memories_30d": memories_30d,
            "memories_7d": memories_7d,
            "avg_quality_30d": avg_quality_30d,
            "growth_pct_30d": growth_pct_30d,
        }
    finally:
        db.close()


@router.get("/satellites")
async def list_satellites():
    """List all satellite databases with stats."""
    try:
        db = get_db()
        # Query satellite_dbs table directly
        try:
            rows = db.execute("SELECT * FROM satellite_dbs WHERE active=1").fetchall()
        except Exception:
            db.close()
            return {"satellites": [], "count": 0}

        db_dir = Path(db.execute("PRAGMA database_list").fetchone()[2]).parent
        db.close()

        result = []
        for row in rows:
            entry = dict(row)
            sat_path = db_dir / entry.get("db_path", "")
            mem_count = 0
            size_kb = 0
            if sat_path.exists():
                size_kb = int(sat_path.stat().st_size / 1024)
                try:
                    import sqlite3 as _sqlite3
                    sdb = _sqlite3.connect(str(sat_path))
                    mem_count = sdb.execute("SELECT COUNT(*) FROM memories").fetchone()[0]
                    sdb.close()
                except Exception:
                    pass
            entry["memory_count"] = mem_count
            entry["size_kb"] = size_kb
            entry["keywords"] = (entry.get("search_keywords") or "").split(",")[:10]
            result.append(entry)
        return {"satellites": result, "count": len(result)}
    except Exception as e:
        return {"satellites": [], "count": 0, "error": "Could not load satellites"}


@router.get("/satellites/{name}/memories")
async def satellite_memories(name: str, limit: int = 50, offset: int = 0, q: str = ""):
    """Browse memories inside a satellite database."""
    try:
        db = get_db()
        row = db.execute("SELECT db_path FROM satellite_dbs WHERE name=? AND active=1", (name,)).fetchone()
        if not row:
            db.close()
            return {"error": "Satellite not found", "memories": []}
        db_dir = Path(db.execute("PRAGMA database_list").fetchone()[2]).parent
        db.close()
        sat_path = db_dir / row["db_path"]
        sat_path = sat_path.resolve()
        if not str(sat_path).startswith(str(db_dir.resolve())):
            return {"error": "Invalid satellite path", "memories": [], "total": 0}
        if not sat_path.exists():
            return {"error": "Satellite DB file missing", "memories": []}
        import sqlite3 as _sq
        sdb = _sq.connect(str(sat_path))
        sdb.row_factory = _sq.Row
        if q:
            rows = sdb.execute(
                "SELECT id, name, type, tags, substr(content, 1, 200) as preview, importance, created, updated "
                "FROM memories WHERE active=1 AND (name LIKE ? OR content LIKE ? OR tags LIKE ?) ORDER BY updated DESC LIMIT ? OFFSET ?",
                (f"%{q}%", f"%{q}%", f"%{q}%", limit, offset)
            ).fetchall()
        else:
            rows = sdb.execute(
                "SELECT id, name, type, tags, substr(content, 1, 200) as preview, importance, created, updated "
                "FROM memories WHERE active=1 ORDER BY updated DESC LIMIT ? OFFSET ?",
                (limit, offset)
            ).fetchall()
        total = sdb.execute("SELECT COUNT(*) FROM memories WHERE active=1").fetchone()[0]
        sdb.close()
        return {"memories": [dict(r) for r in rows], "total": total, "satellite": name}
    except Exception as e:
        return {"memories": [], "total": 0, "error": str(e)}


@router.get("/memories/graph")
async def memory_graph(limit: int = 200):
    """Return nodes + edges for graph visualization with auto-extracted relationships.
    Capped at `limit` most-recent memories to avoid O(N²) hangs on large DBs."""
    db = get_db()
    rows = db.execute(
        "SELECT id, name, type, tags, content FROM memories WHERE active = 1 ORDER BY updated DESC LIMIT ?",
        (min(limit, 500),)
    ).fetchall()
    db.close()

    nodes = []
    edge_set: set[tuple[int, int, str]] = set()  # (source, target, label) deduped
    name_to_id = {}
    id_to_tags: dict[int, set[str]] = {}
    id_to_keywords: dict[int, set[str]] = {}

    # Stopwords for keyword extraction
    stopwords = {
        "the", "a", "an", "is", "are", "was", "were", "be", "been", "being",
        "have", "has", "had", "do", "does", "did", "will", "would", "could",
        "should", "may", "might", "shall", "can", "to", "of", "in", "for",
        "on", "with", "at", "by", "from", "as", "into", "through", "during",
        "before", "after", "above", "below", "between", "out", "off", "over",
        "under", "again", "further", "then", "once", "here", "there", "when",
        "where", "why", "how", "all", "each", "every", "both", "few", "more",
        "most", "other", "some", "such", "no", "nor", "not", "only", "own",
        "same", "so", "than", "too", "very", "just", "because", "but", "and",
        "or", "if", "while", "about", "up", "it", "its", "this", "that",
        "these", "those", "i", "me", "my", "we", "our", "you", "your", "he",
        "him", "his", "she", "her", "they", "them", "their", "what", "which",
        "who", "whom", "use", "used", "using", "also", "get", "set", "new",
    }

    def extract_keywords(text: str) -> set[str]:
        words = re.findall(r"[a-z][a-z0-9_-]{2,}", text.lower())
        return {w for w in words if w not in stopwords and len(w) > 2}

    for r in rows:
        tags_raw = r["tags"] or ""
        tag_set = {t.strip().lower() for t in tags_raw.split(",") if t.strip()}
        id_to_tags[r["id"]] = tag_set
        content = (r["content"] or "") + " " + (r["name"] or "")
        id_to_keywords[r["id"]] = extract_keywords(content)
        nodes.append({"id": r["id"], "name": r["name"], "type": r["type"], "tags": r["tags"]})
        name_to_id[r["name"].lower()] = r["id"]

    valid_ids = {n["id"] for n in nodes}

    def add_edge(src: int, tgt: int, label: str):
        if src != tgt and src in valid_ids and tgt in valid_ids:
            key = (min(src, tgt), max(src, tgt), label)
            edge_set.add(key)

    # 1) Explicit references: #ID and name mentions in content
    for r in rows:
        content = r["content"] or ""
        ref_ids = set(int(m) for m in re.findall(r"#(\d+)", content))
        for tid in ref_ids:
            add_edge(r["id"], tid, "references")
        for name, mid in name_to_id.items():
            if mid != r["id"] and len(name) > 3 and name in content.lower():
                add_edge(r["id"], mid, "mentions")

    # 2) Shared tags — memories with overlapping tags are related
    ids = [r["id"] for r in rows]
    for i in range(len(ids)):
        for j in range(i + 1, len(ids)):
            shared = id_to_tags[ids[i]] & id_to_tags[ids[j]]
            if shared:
                add_edge(ids[i], ids[j], f"tag:{next(iter(shared))}")

    # 3) Keyword overlap — memories sharing significant keywords
    for i in range(len(ids)):
        for j in range(i + 1, len(ids)):
            kw_i = id_to_keywords[ids[i]]
            kw_j = id_to_keywords[ids[j]]
            if not kw_i or not kw_j:
                continue
            overlap = kw_i & kw_j
            # Jaccard similarity — need meaningful overlap
            union = kw_i | kw_j
            similarity = len(overlap) / len(union) if union else 0
            if similarity > 0.15 and len(overlap) >= 3:
                top_word = max(overlap, key=len)
                add_edge(ids[i], ids[j], f"topic:{top_word}")

    # 4) Entity-based connections — memories sharing extracted entities
    try:
        from entity_extractor import get_entity_graph, init_entity_tables
        init_entity_tables(aibrain_db.DB_PATH)
        eg = get_entity_graph(aibrain_db.DB_PATH)
        for link in eg.get("entity_links", []):
            ent = next((e for e in eg["entities"] if e["id"] == link["entity_id"]), None)
            label = f"entity:{ent['name']}" if ent else "entity"
            add_edge(link["memory_1"], link["memory_2"], label)
    except (ImportError, sqlite3.OperationalError, KeyError) as e:
        logger.warning("Entity graph edge loading failed: %s", e)

    edges = [{"source": s, "target": t, "label": l} for s, t, l in edge_set]

    # Include entity nodes for enriched graph view
    entity_nodes = []
    try:
        from entity_extractor import get_entity_graph, init_entity_tables
        init_entity_tables(aibrain_db.DB_PATH)
        eg = get_entity_graph(aibrain_db.DB_PATH)
        entity_nodes = eg.get("entities", [])
    except (ImportError, sqlite3.OperationalError, KeyError) as e:
        logger.warning("Entity node loading failed: %s", e)

    return {"nodes": nodes, "edges": edges, "entities": entity_nodes}


@router.post("/memories/extract-entities")
async def extract_all_entities():
    """Backfill entity extraction on all existing memories."""
    try:
        from entity_extractor import init_entity_tables, index_memory_entities
        init_entity_tables(aibrain_db.DB_PATH)
    except ImportError:
        return JSONResponse({"error": "Entity extractor not available"}, status_code=500)

    db = get_db()
    rows = db.execute("SELECT id, name, content FROM memories WHERE active = 1").fetchall()
    db.close()

    total_entities = 0
    for r in rows:
        entities = index_memory_entities(aibrain_db.DB_PATH, r["id"], r["content"] or "", r["name"] or "")
        total_entities += len(entities)

    return {"memories_processed": len(rows), "entities_extracted": total_entities}


# ---------------------------------------------------------------------------
# Memory Import/Export — portable agent brain transfer
# ---------------------------------------------------------------------------

@router.get("/memories/export")
@require_tier("pro")
async def export_memories():
    """Export all active memories as portable JSON. The full agent brain in one file."""
    db = get_db()
    rows = db.execute(
        "SELECT id, name, type, tags, content, created, updated FROM memories WHERE active = 1 ORDER BY id"
    ).fetchall()
    db.close()

    crons = aibrain_db.list_scheduled_jobs()

    return {
        "format": "aibrain-brain-v1",
        "exported_at": datetime.now().isoformat(),
        "memories": [dict(r) for r in rows],
        "crons": crons,
        "stats": {
            "memory_count": len(rows),
            "cron_count": len(crons),
        }
    }


@router.post("/memories/import")
@require_tier("pro")
async def import_memories(body: dict):
    """Import memories from an AIBrain brain export or other formats."""
    memories = body.get("memories", [])
    crons = body.get("crons", [])

    if not memories and not crons:
        return JSONResponse({"error": "No data to import"}, status_code=400)

    db = get_db()
    now = datetime.now().isoformat()
    imported = 0
    skipped = 0

    _VALID_MEMORY_TYPES = {"user", "feedback", "project", "reference", "pattern", "decision"}

    for mem in memories:
        name = mem.get("name", "")
        if not name:
            skipped += 1
            continue

        # Content size limit
        content = mem.get("content", "")
        if len(content) > 50_000:
            db.close()
            return JSONResponse(
                {"error": f"Memory '{name}' content exceeds 50,000 character limit ({len(content)} chars)"},
                status_code=400,
            )

        # Type validation
        mem_type = mem.get("type", "reference")
        if mem_type not in _VALID_MEMORY_TYPES:
            db.close()
            return JSONResponse(
                {"error": f"Invalid memory type '{mem_type}'. Must be one of: {sorted(_VALID_MEMORY_TYPES)}"},
                status_code=400,
            )

        existing = db.execute(
            "SELECT id FROM memories WHERE name = ? AND active = 1", (name,)
        ).fetchone()
        if existing:
            skipped += 1
            continue
        db.execute(
            "INSERT INTO memories (name, type, tags, content, created, updated) VALUES (?, ?, ?, ?, ?, ?)",
            (name, mem_type, mem.get("tags", ""),
             content, mem.get("created", now), now)
        )
        imported += 1

    db.commit()
    db.close()

    crons_imported = 0
    if crons:
        result = aibrain_db.import_memories_and_crons([], crons)
        crons_imported = result.get("crons_imported", 0)

    return {
        "status": "imported",
        "memories_imported": imported,
        "memories_skipped": skipped,
        "crons_imported": crons_imported,
    }


@router.get("/memories/history/recent")
async def recent_memory_history(limit: int = 50):
    """Get the most recent memory changes across all memories."""
    db = get_db()
    try:
        rows = db.execute(
            "SELECT h.*, m.name as memory_name FROM memory_history h "
            "LEFT JOIN memories m ON h.memory_id = m.id "
            "ORDER BY h.id DESC LIMIT ?", (min(limit, 200),)
        ).fetchall()
        db.close()
        return {"history": [dict(r) for r in rows], "total": len(rows)}
    except Exception as e:
        db.close()
        return {"history": [], "error": str(e)}


@router.get("/memories/{memory_id}")
async def get_memory(memory_id: int):
    db = get_db()
    row = db.execute("SELECT * FROM memories WHERE id = ? AND active = 1", (memory_id,)).fetchone()
    db.close()
    if not row:
        return JSONResponse({"error": "Not found"}, status_code=404)
    return dict(row)


@router.post("/memories")
async def create_memory(body: dict):
    name = body.get("name")
    mem_type = body.get("type", "reference")
    content = body.get("content", "")
    tags = body.get("tags", "")
    importance = body.get("importance", 0.5)
    if not name or not content:
        return JSONResponse({"error": "name and content required"}, status_code=400)
    if mem_type not in ("user", "feedback", "project", "reference", "pattern", "decision"):
        return JSONResponse({"error": f"Invalid type: {mem_type}"}, status_code=400)

    # ENHANCED PATH: MCP store (dedup + auto-embed + entity extraction)
    try:
        sys.path.insert(0, str(Path(__file__).parent.parent))
        from mcp_server import _store as enhanced_store
        result = enhanced_store(name, content, mem_type, tags, importance)
        mid = result["id"]
        # Entity extraction on new memories
        if result["action"] == "added":
            try:
                from entity_extractor import init_entity_tables, index_memory_entities
                init_entity_tables(aibrain_db.DB_PATH)
                index_memory_entities(aibrain_db.DB_PATH, mid, content, name)
            except Exception as e:
                logger.warning("Entity extraction failed for memory %s: %s", mid, e)
        return {"id": mid, "name": name, "type": mem_type,
                "action": result["action"], "store_mode": "enhanced"}
    except Exception as e:
        logger.info("Enhanced store unavailable, falling back to direct: %s", e)

    # DIRECT PATH: basic insert (always works)
    db = get_db()
    now = datetime.now().isoformat()
    cursor = db.execute(
        "INSERT INTO memories (name, type, tags, content, created, updated) VALUES (?, ?, ?, ?, ?, ?)",
        (name, mem_type, tags, content, now, now)
    )
    db.commit()
    mid = cursor.lastrowid
    db.close()

    try:
        from entity_extractor import init_entity_tables, index_memory_entities
        init_entity_tables(aibrain_db.DB_PATH)
        index_memory_entities(aibrain_db.DB_PATH, mid, content, name)
    except Exception as e:
        logger.warning("Entity extraction failed for memory %s: %s", mid, e)

    return {"id": mid, "name": name, "type": mem_type, "store_mode": "direct"}


@router.put("/memories/{memory_id}")
async def update_memory(memory_id: int, body: dict):
    db = get_db()
    existing = db.execute("SELECT id FROM memories WHERE id = ? AND active = 1", (memory_id,)).fetchone()
    if not existing:
        db.close()
        return JSONResponse({"error": "Not found"}, status_code=404)

    _MEMORY_COLUMNS = frozenset({"name", "content", "tags", "type", "updated"})
    col_updates = {}
    for field in ("name", "content", "tags", "type"):
        if field in body:
            col_updates[field] = body[field]
    col_updates["updated"] = datetime.now().isoformat()
    params = []
    sql = _safe_update("memories", _MEMORY_COLUMNS, col_updates, "id = ?", params)
    params.append(memory_id)

    db.execute(sql, params)
    db.commit()
    db.close()

    # Re-index entities on update
    if "content" in body or "name" in body:
        try:
            from entity_extractor import init_entity_tables, index_memory_entities
            init_entity_tables(aibrain_db.DB_PATH)
            content = body.get("content", "")
            name = body.get("name", "")
            index_memory_entities(aibrain_db.DB_PATH, memory_id, content, name)
        except (ImportError, sqlite3.OperationalError) as e:
            logger.warning("Entity re-indexing failed for memory %s: %s", memory_id, e)

    return {"id": memory_id, "status": "updated"}


@router.delete("/memories/{memory_id}")
async def delete_memory(memory_id: int):
    db = get_db()
    db.execute(
        "UPDATE memories SET active = 0, updated = ? WHERE id = ?",
        (datetime.now().isoformat(), memory_id)
    )
    db.commit()
    db.close()
    return {"id": memory_id, "status": "deactivated"}


# ---------------------------------------------------------------------------
# Cron / Scheduled Jobs
# ---------------------------------------------------------------------------

@router.get("/crons")
async def list_crons():
    jobs = aibrain_db.list_scheduled_jobs()
    return {"jobs": jobs}


@router.post("/crons")
async def create_cron(body: dict):
    """Create a new scheduled job."""
    name = body.get("name")
    cron_expr = body.get("cron")
    if not name or not cron_expr:
        return JSONResponse({"error": "name and cron required"}, status_code=400)

    if aibrain_db.get_scheduled_job(name):
        return JSONResponse({"error": f"Job '{name}' already exists"}, status_code=409)

    aibrain_db.create_scheduled_job(
        name=name, cron=cron_expr,
        prompt=body.get("prompt", ""),
        enabled=body.get("enabled", True),
        notes=body.get("notes", ""),
        group=body.get("group", "general"),
    )
    return {"name": name, "status": "created"}


@router.put("/crons/{job_name}")
async def update_cron(job_name: str, body: dict):
    if not aibrain_db.get_scheduled_job(job_name):
        return JSONResponse({"error": f"Job '{job_name}' not found"}, status_code=404)

    aibrain_db.update_scheduled_job(job_name, **{
        k: v for k, v in body.items() if k in ("enabled", "cron", "prompt", "notes", "job_group")
    })
    return {"name": job_name, "status": "updated"}


WORKFLOWS_REGISTRY = AIBRAIN_ROOT / "workflows" / "registry.json"  # Legacy path

# Category display info (was in registry.json, now static config)
_CATEGORY_COLORS = {
    "job_hunting": {"display": "Job Hunting", "color": "#10B981"},
    "social_media": {"display": "Social Media", "color": "#8B5CF6"},
    "trading": {"display": "Trading", "color": "#F59E0B"},
    "security": {"display": "Security", "color": "#EF4444"},
    "content": {"display": "Content", "color": "#3B82F6"},
    "research": {"display": "Research", "color": "#06B6D4"},
    "communication": {"display": "Communication", "color": "#EC4899"},
    "maintenance": {"display": "Maintenance", "color": "#64748B"},
    "automation": {"display": "Automation", "color": "#14B8A6"},
    "general": {"display": "General", "color": "#64748B"},
}


def _load_workflow_groups():
    """Load workflow groups from consolidated DB."""
    workflows = aibrain_db.list_workflows()
    groups = {}
    for wf in workflows:
        cat = wf.get("category", "general")
        if cat not in groups:
            cat_info = _CATEGORY_COLORS.get(cat, {"display": cat.title(), "color": "#64748B"})
            groups[cat] = {
                "name": cat_info["display"],
                "color": cat_info["color"],
                "jobs": [],
                "flow": [],
                "edges": [],
                "workflows": [],
            }

        groups[cat]["jobs"].append(wf["name"])
        groups[cat]["workflows"].append({
            "name": wf["name"],
            "display_name": wf.get("display_name", wf["name"]),
            "description": wf.get("description", ""),
            "cron_schedule": wf.get("cron_schedule", ""),
            "required_services": wf.get("required_services", []),
            "enabled_by_default": bool(wf.get("enabled", 0)),
            "config_keys": wf.get("config_keys", []),
        })
        flow = wf.get("flow", [])
        edges = wf.get("edges", [])
        wf_prefix = wf["name"]
        if isinstance(flow, list):
            # Prefix node IDs with workflow name to avoid collisions within a group
            for node in flow:
                node["id"] = f"{wf_prefix}_{node.get('id', '')}"
            groups[cat]["flow"].extend(flow)
        if isinstance(edges, list):
            for edge in edges:
                edge["from"] = f"{wf_prefix}_{edge.get('from', '')}"
                edge["to"] = f"{wf_prefix}_{edge.get('to', '')}"
            groups[cat]["edges"].extend(edges)

    return groups


@router.get("/crons/upcoming")
async def upcoming_crons():
    """Return next scheduled runs for all enabled jobs, sorted by next run time."""
    jobs = aibrain_db.list_scheduled_jobs(enabled_only=True)
    now = datetime.now()

    upcoming = []
    for job in jobs:
        cron_expr = job.get("cron", "")
        next_run = parse_next_cron_run(cron_expr, now)
        if next_run:
            upcoming.append({
                "name": job["name"],
                "cron": cron_expr,
                "group": job.get("job_group", "general"),
                "prompt": job.get("prompt", ""),
                "next_run": next_run.isoformat(),
                "in_minutes": int((next_run - now).total_seconds() / 60),
            })

    upcoming.sort(key=lambda x: x["next_run"])
    return {"upcoming": upcoming}


def parse_next_cron_run(expr: str, now: datetime) -> datetime | None:
    """Simple cron parser for common patterns. Returns next run datetime."""
    parts = expr.strip().split()
    if len(parts) != 5:
        return None

    minute, hour, dom, month, dow = parts

    try:
        # Handle */N patterns
        def parse_field(field, current, max_val):
            if field == '*':
                return list(range(max_val))
            if field.startswith('*/'):
                step = int(field[2:])
                return list(range(0, max_val, step))
            if ',' in field:
                return [int(x) for x in field.split(',')]
            if '-' in field:
                start, end = field.split('-')
                return list(range(int(start), int(end) + 1))
            return [int(field)]

        minutes = parse_field(minute, now.minute, 60)
        hours = parse_field(hour, now.hour, 24)
        dows = parse_field(dow, 0, 7)  # dow range is always 0-6 (cron: 0=Sun)

        # Check next 7 days
        for day_offset in range(8):
            check_date = now.replace(hour=0, minute=0, second=0, microsecond=0)
            check_date = check_date.replace(
                day=check_date.day + day_offset
            ) if day_offset == 0 else datetime(
                check_date.year, check_date.month, check_date.day + day_offset
            )

            try:
                # Cron: 0=Sun, 1=Mon... Python: 0=Mon, 1=Tue...
                cron_dow = (check_date.weekday() + 1) % 7
                if dow != '*' and cron_dow not in dows:
                    continue

                for h in sorted(hours):
                    for m in sorted(minutes):
                        candidate = check_date.replace(hour=h, minute=m, second=0, microsecond=0)
                        if candidate > now:
                            return candidate
            except (ValueError, OverflowError):
                continue

    except (ValueError, IndexError):
        return None

    return None


@router.get("/crons/groups")
async def cron_groups():
    try:
        return {"groups": _load_workflow_groups()}
    except Exception as _e:
        logger.error("_load_workflow_groups() failed: %s", _e)
        return {"groups": {}}


@router.get("/workflows")
async def list_workflows_endpoint():
    """List all pre-built workflows with full metadata."""
    try:
        workflows = aibrain_db.list_workflows()
    except Exception as _e:
        logger.error("aibrain_db.list_workflows() failed (%s) — falling back to direct query", _e)
        import json as _json
        _json_fields = ("required_services", "playwright_setup", "flow", "edges", "config_keys")
        db = get_db()
        workflows = []
        for row in db.execute("SELECT * FROM workflows ORDER BY category, name").fetchall():
            r = dict(row)
            for k in _json_fields:
                if r.get(k):
                    try:
                        r[k] = _json.loads(r[k])
                    except Exception:
                        pass
            workflows.append(r)
    return {
        "workflows": workflows,
        "categories": _CATEGORY_COLORS,
        "count": len(workflows),
    }


@router.get("/workflows/builder")
async def list_builder_workflows():
    """List all saved visual workflow graphs."""
    if not BUILDER_DIR.exists():
        return {"workflows": []}
    results = []
    for f in sorted(BUILDER_DIR.glob("*.json")):
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
            results.append({
                "id": f.stem,
                "name": data.get("name", f.stem),
                "node_count": len(data.get("nodes", [])),
                "edge_count": len(data.get("edges", [])),
                "updated": data.get("updated", ""),
            })
        except (json.JSONDecodeError, OSError) as e:
            logger.warning("Skipping corrupt workflow file %s: %s", f.name, e)
    return {"workflows": results}


@router.get("/workflows/builder/{workflow_id}")
async def get_builder_workflow(workflow_id: str):
    """Get a specific visual workflow graph."""
    path = BUILDER_DIR / f"{workflow_id}.json"
    if not path.exists():
        return JSONResponse({"error": "Not found"}, status_code=404)
    return json.loads(path.read_text(encoding="utf-8"))


@router.get("/workflows/runs")
async def list_workflow_runs(
    workflow_id: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    limit: int = Query(50, le=200),
):
    """Get workflow execution history."""
    db_path = str(AIBRAIN_ROOT / "aibrain.db")
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    query = "SELECT * FROM workflow_runs WHERE 1=1"
    params = []
    if workflow_id:
        query += " AND workflow_id=?"
        params.append(workflow_id)
    if status:
        query += " AND status=?"
        params.append(status)
    query += " ORDER BY started_at DESC LIMIT ?"
    params.append(limit)
    rows = conn.execute(query, params).fetchall()
    conn.close()
    def _map_run(r):
        d = dict(r)
        if "started_at" in d and "started" not in d:
            d["started"] = d["started_at"]
        if "duration_s" in d and "duration_ms" not in d:
            d["duration_ms"] = int(d["duration_s"] * 1000) if d["duration_s"] is not None else None
        return d
    return {"runs": [_map_run(r) for r in rows], "count": len(rows)}


@router.get("/workflows/runs/stats")
async def workflow_run_stats():
    """Get workflow execution statistics."""
    db_path = str(AIBRAIN_ROOT / "aibrain.db")
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    total = conn.execute("SELECT COUNT(*) as c FROM workflow_runs").fetchone()["c"]
    by_status = conn.execute(
        "SELECT status, COUNT(*) as c FROM workflow_runs GROUP BY status"
    ).fetchall()
    recent = conn.execute(
        "SELECT workflow_name, status, started_at, duration_s FROM workflow_runs ORDER BY started_at DESC LIMIT 10"
    ).fetchall()
    conn.close()
    by_status_map = {r["status"]: r["c"] for r in by_status}
    completed_count = by_status_map.get("completed", 0) + by_status_map.get("succeeded", 0)
    success_rate = completed_count / total if total > 0 else 0.0
    return {
        "total_runs": total,
        "by_status": by_status_map,
        "recent": [dict(r) for r in recent],
        "success_rate": success_rate,
    }


@router.get("/workflows/{workflow_name}")
async def get_workflow_endpoint(workflow_name: str):
    """Get full details for a specific workflow."""
    wf = aibrain_db.get_workflow(workflow_name)
    if not wf:
        return JSONResponse({"error": f"Workflow '{workflow_name}' not found"}, status_code=404)
    return wf


@router.put("/workflows/{workflow_name}")
async def update_workflow_endpoint(workflow_name: str, body: dict):
    """Update a workflow's editable fields."""
    allowed = {k: v for k, v in body.items() if k in ("display_name", "description", "cron_schedule", "category", "prompt")}
    if not aibrain_db.update_workflow(workflow_name, **allowed):
        return JSONResponse({"error": f"Workflow '{workflow_name}' not found"}, status_code=404)
    return {"name": workflow_name, "status": "updated"}


@router.post("/workflows/{workflow_name}/enable")
async def enable_workflow_endpoint(workflow_name: str, body: dict = None):
    """Enable or disable a workflow. Body: {enabled: bool} (default true)."""
    body = body or {}
    should_enable = body.get("enabled", True)

    wf = aibrain_db.get_workflow(workflow_name)
    if not wf:
        return JSONResponse({"error": "Workflow not found"}, status_code=404)

    if should_enable:
        aibrain_db.enable_workflow(workflow_name)
        # Also create a corresponding scheduled job if not exists
        if not aibrain_db.get_scheduled_job(workflow_name):
            aibrain_db.create_scheduled_job(
                name=workflow_name,
                cron=wf.get("cron_schedule", "0 9 * * *"),
                prompt=f"Run {wf.get('display_name', workflow_name)} workflow: python workflows/{workflow_name}.py",
                enabled=True,
                notes=wf.get("description", ""),
                group=wf.get("category", "general"),
            )
    else:
        aibrain_db.disable_workflow(workflow_name)
        aibrain_db.delete_scheduled_job(workflow_name)

    return {"name": workflow_name, "status": "enabled" if should_enable else "disabled"}


@router.post("/workflows/{workflow_name}/disable")
async def disable_workflow_endpoint(workflow_name: str):
    """Disable a workflow."""
    aibrain_db.disable_workflow(workflow_name)
    aibrain_db.delete_scheduled_job(workflow_name)
    return {"name": workflow_name, "status": "disabled"}


_MAX_OUTPUT_BYTES = 10 * 1024  # 10 KB max for API-returned output


def _sanitize_workflow_output(text: str) -> str:
    """Strip secrets, internal paths, and env var patterns from workflow output."""
    if not text:
        return text
    # Truncate to max size first
    text = text[:_MAX_OUTPUT_BYTES]
    # Strip Windows user paths (C:\Users\xxx\...)
    text = re.sub(r'[A-Za-z]:\\Users\\[^\s\\]+\\[^\s]*', '<path-redacted>', text)
    # Strip Unix home paths (/home/xxx/...)
    text = re.sub(r'/home/[^\s/]+/[^\s]*', '<path-redacted>', text)
    # Strip env var assignments (KEY=value patterns commonly leaked)
    text = re.sub(r'(?i)(api[_-]?key|secret|token|password|credential|auth)\s*[=:]\s*\S+', r'\1=<redacted>', text)
    # Strip export/set env var lines
    text = re.sub(r'(?m)^(?:export|set)\s+\w+=.*$', '<env-redacted>', text)
    return text


@router.post("/workflows/{workflow_name}/run")
@require_tier("pro")
async def run_workflow(workflow_name: str):
    """Run a workflow script immediately with --dry-run."""
    import subprocess
    import time as _time

    script = (AIBRAIN_ROOT / "workflows" / f"{workflow_name}.py").resolve()
    if not str(script).startswith(str((AIBRAIN_ROOT / "workflows").resolve())):
        return JSONResponse({"error": "Invalid workflow name"}, status_code=403)
    if not script.exists():
        return JSONResponse({"error": f"Script not found: {workflow_name}.py"}, status_code=404)

    # Log run start
    run_id = None
    start_time = _time.time()
    run_conn = None
    try:
        db_path = str(AIBRAIN_ROOT / "aibrain.db")
        run_conn = sqlite3.connect(db_path)
        cur = run_conn.execute(
            "INSERT INTO workflow_runs (workflow_id, workflow_name, trigger_type, status) VALUES (?, ?, 'manual', 'running')",
            (workflow_name, workflow_name)
        )
        run_id = cur.lastrowid
        run_conn.commit()
    except Exception as e:
        logger.warning("Failed to create workflow_runs record for %s: %s", workflow_name, e)
    finally:
        if run_conn:
            run_conn.close()

    try:
        result = subprocess.run(
            [sys.executable, str(script), "--dry-run"],
            capture_output=True, text=True, timeout=90,
            cwd=str(AIBRAIN_ROOT),
        )
        duration = _time.time() - start_time
        run_status = "completed" if result.returncode == 0 else "failed"

        # Update run record
        if run_id:
            run_conn = None
            try:
                run_conn = sqlite3.connect(db_path)
                run_conn.execute(
                    "UPDATE workflow_runs SET status=?, completed_at=CURRENT_TIMESTAMP, duration_s=?, output_summary=?, error=? WHERE id=?",
                    (run_status, round(duration, 2),
                     (result.stdout[-500:] if result.stdout else ""),
                     (result.stderr[-500:] if result.stderr and result.returncode != 0 else ""),
                     run_id)
                )
                run_conn.commit()
            except Exception as e:
                logger.warning("Failed to update workflow_runs record %s: %s", run_id, e)
            finally:
                if run_conn:
                    run_conn.close()

        # Log activity
        try:
            aibrain_db.create_activity(
                agent=os.getenv("AGENT_ID", "agent"), action=f"ran {workflow_name}",
                category="workflow", detail=f"exit_code={result.returncode}",
                status="ok" if result.returncode == 0 else "error",
            )
        except (sqlite3.OperationalError, TypeError) as e:
            logger.warning("Activity logging failed for workflow %s: %s", workflow_name, e)

        # Log trace for observability
        try:
            trace_logger.log_workflow_run(
                workflow_id=workflow_name,
                status="ok" if result.returncode == 0 else "error",
                detail=result.stdout[-500:] if result.stdout else "",
                latency_ms=int(duration * 1000),
            )
        except (OSError, TypeError, ValueError) as e:
            logger.warning("Trace logging failed for workflow %s: %s", workflow_name, e)

        # Emit to pattern bus
        try:
            from event_schema import DomainEvent, PatternBus
            pb = PatternBus(db_path=db_path)
            pb.emit(DomainEvent(
                domain="aibrain", source_agent=os.getenv("AGENT_ID", "agent"),
                event_type="workflow_complete",
                key=f"workflow:{workflow_name}",
                value={"status": run_status, "duration_s": round(duration, 2), "exit_code": result.returncode},
            ))
        except Exception as e:
            logger.warning("Failed to emit workflow_complete event for %s: %s", workflow_name, e)

        response = {
            "workflow": workflow_name,
            "run_id": run_id,
            "exit_code": result.returncode,
            "duration_s": round(duration, 2),
            "stdout": _sanitize_workflow_output(result.stdout[-5000:] if result.stdout else ""),
        }
        # Only include stderr on failure to avoid leaking internal paths on success
        if result.returncode != 0:
            response["stderr"] = _sanitize_workflow_output(result.stderr[-2000:] if result.stderr else "")
        return response
    except subprocess.TimeoutExpired:
        return JSONResponse({"error": "Workflow timed out (90s limit)"}, status_code=504)
    except Exception as e:
        logger.error("Workflow execution failed: %s", e, exc_info=True)
        return JSONResponse({"error": "Internal server error"}, status_code=500)


# ---------------------------------------------------------------------------
# Skills
# ---------------------------------------------------------------------------

@router.get("/skills")
async def list_skills():
    skills = []

    # Local custom skills
    if SKILLS_DIR.exists():
        for f in SKILLS_DIR.glob("*.md"):
            name = f.stem
            desc = ""
            source = "local"
            text = f.read_text(encoding="utf-8", errors="replace")[:500]
            for line in text.split("\n"):
                if line.startswith("description:"):
                    desc = line.split(":", 1)[1].strip()
                    break
            skills.append({"name": name, "description": desc, "source": source})

    # Symlinked agent skills
    if SKILLS_AGENTS_DIR.exists():
        for d in SKILLS_AGENTS_DIR.iterdir():
            if d.is_dir():
                skill_file = d / "SKILL.md"
                if not skill_file.exists():
                    skill_file = next(d.glob("*.md"), None)
                desc = ""
                if skill_file and skill_file.exists():
                    text = skill_file.read_text(encoding="utf-8", errors="replace")[:500]
                    for line in text.split("\n"):
                        if line.startswith("description:"):
                            desc = line.split(":", 1)[1].strip()
                            break
                skills.append({"name": d.name, "description": desc, "source": "agents"})

    return {"count": len(skills), "skills": skills}


@router.get("/skills/{skill_name}")
async def get_skill(skill_name: str):
    # Check local first
    local = SKILLS_DIR / f"{skill_name}.md"
    if local.exists():
        return {"name": skill_name, "source": "local", "content": local.read_text(encoding="utf-8", errors="replace")}

    # Check agents dir
    agent_dir = SKILLS_AGENTS_DIR / skill_name
    if agent_dir.exists():
        skill_file = agent_dir / "SKILL.md"
        if not skill_file.exists():
            skill_file = next(agent_dir.glob("*.md"), None)
        if skill_file:
            return {"name": skill_name, "source": "agents", "content": skill_file.read_text(encoding="utf-8", errors="replace")}

    return JSONResponse({"error": "Skill not found"}, status_code=404)


@router.post("/skills/install")
@require_tier("pro")
async def install_skill(body: dict):
    """Install a skill from raw content or a URL.
    Body: { name: str, content?: str, url?: str }
    """
    name = body.get("name", "").strip()
    content = body.get("content", "")
    url = body.get("url", "")

    if not name:
        return JSONResponse({"error": "name required"}, status_code=400)

    # Sanitize name
    safe_name = re.sub(r"[^a-zA-Z0-9_-]", "_", name)

    if url and not content:
        # SSRF protection — block internal IPs and dangerous schemes
        from security import validate_url
        is_safe, reason = validate_url(url)
        if not is_safe:
            return JSONResponse({"error": f"Blocked URL: {reason}"}, status_code=400)
        # Fetch from URL (async — doesn't block event loop)
        try:
            import httpx
            async with httpx.AsyncClient(timeout=15, follow_redirects=True) as client:
                resp = await client.get(url, headers={"User-Agent": "AIBrain/0.3"})
                resp.raise_for_status()
                content = resp.text
        except Exception as e:
            return JSONResponse({"error": f"Failed to fetch URL: {str(e)[:100]}"}, status_code=400)

    if not content:
        return JSONResponse({"error": "content or url required"}, status_code=400)

    # Write to local skills dir
    SKILLS_DIR.mkdir(parents=True, exist_ok=True)
    skill_path = SKILLS_DIR / f"{safe_name}.md"
    skill_path.write_text(content, encoding="utf-8")

    return {"name": safe_name, "path": str(skill_path), "size": len(content), "status": "installed"}


@router.delete("/skills/{skill_name}")
async def delete_skill(skill_name: str):
    """Delete a locally installed skill."""
    local = SKILLS_DIR / f"{skill_name}.md"
    if local.exists():
        local.unlink()
        return {"name": skill_name, "status": "deleted"}
    return JSONResponse({"error": "Skill not found or not a local skill"}, status_code=404)


# ---------------------------------------------------------------------------
# Agent Status
# ---------------------------------------------------------------------------

@router.get("/status")
async def agent_status():
    import platform as _platform
    _agent_id = os.getenv("AGENT_ID", "agent")
    local_agent = {"name": _agent_id, "platform": f"{_platform.system()} {_platform.release()}", "status": "online"}

    # Last evolution
    if LAST_EVOLUTION.exists():
        try:
            ts = int(LAST_EVOLUTION.read_text().strip())
            local_agent["last_evolution"] = datetime.fromtimestamp(ts).isoformat()
        except (ValueError, OSError):
            local_agent["last_evolution"] = None

    # Memory count
    try:
        ms = aibrain_db.memory_summary()
        local_agent["memory_count"] = ms["total"]
    except Exception as e:
        logger.warning("Failed to get memory count for status: %s", e)
        local_agent["memory_count"] = 0

    # Cron count
    local_agent["active_crons"] = len(aibrain_db.list_scheduled_jobs(enabled_only=True))

    # Recent Telegram — security fix (Task 2): strip message content and token
    # fields before returning. The /api/agent/status endpoint is accessible to
    # any API-key holder; raw Telegram payloads contain message text, chat IDs,
    # and may carry bot-token fragments. We expose only a sanitised summary.
    recent_messages = []
    if AGENT_INBOX.exists():
        lines = AGENT_INBOX.read_text(encoding="utf-8", errors="replace").strip().split("\n")
        _STRIP_FIELDS = frozenset({
            "text", "message", "content", "token", "bot_token",
            "telegram_token", "raw", "body", "payload",
        })
        for line in lines[-5:]:
            try:
                msg = json.loads(line)
                if isinstance(msg, dict):
                    # Keep only non-sensitive summary fields
                    safe = {
                        k: v for k, v in msg.items()
                        if k not in _STRIP_FIELDS
                        and not any(s in k.lower() for s in ("token", "secret", "password", "path", "dir"))
                    }
                    recent_messages.append(safe)
            except json.JSONDecodeError:
                pass
    local_agent["recent_telegram_count"] = len(recent_messages)
    # Do NOT include message content in the public response

    # Peer agents (dynamic from env vars)
    agents = [local_agent]
    peer_name = os.getenv("PEER_NAME")
    peer_url = os.getenv("PEER_URL")
    if peer_name and peer_url:
        agents.append({
            "name": peer_name,
            "url": peer_url,
            "status": "unknown",
            "note": "Query broker for live status",
        })

    # Workflow count
    try:
        _wf_count = len(aibrain_db.list_workflows())
    except Exception:
        _wf_count = 0

    return {
        "agents": agents,
        "version": _AIBRAIN_VERSION,
        "workflow_count": _wf_count,
        "uptime_seconds": int(_time_module.time() - _API_START_TIME),
    }


@router.get("/status/time")
async def agent_time():
    """Current date/time in both UTC and user's configured timezone.
    AIBrain must always know what time it is relative to the user."""
    from zoneinfo import ZoneInfo
    cfg = _load_config()
    user_tz_name = cfg.get("timezone", "UTC")
    utc_now = datetime.now(ZoneInfo("UTC"))
    try:
        user_tz = ZoneInfo(user_tz_name)
        local_now = utc_now.astimezone(user_tz)
    except Exception as e:
        logger.warning("Failed to resolve timezone %s: %s", user_tz_name, e)
        local_now = utc_now
        user_tz_name = "UTC (fallback)"
    return {
        "utc": utc_now.isoformat(),
        "local": local_now.isoformat(),
        "timezone": user_tz_name,
        "date": local_now.strftime("%A, %B %d, %Y"),
        "time": local_now.strftime("%I:%M %p"),
        "day_of_week": local_now.strftime("%A"),
        "epoch": int(utc_now.timestamp()),
    }


@router.get("/status/report")
async def status_report():
    """Generate a formatted text summary suitable for email updates."""
    lines = []
    now = datetime.now()
    lines.append(f"AIBRAIN STATUS — {now.strftime('%Y-%m-%d %H:%M')}")
    lines.append("=" * 50)

    # Memory count
    mem_count = 0
    try:
        db = get_db()
        mem_count = db.execute("SELECT COUNT(*) FROM memories WHERE active = 1").fetchone()[0]
        # Recent memories (last 2h)
        cutoff = (now - timedelta(hours=2)).isoformat()
        recent_mems = db.execute(
            "SELECT name FROM memories WHERE active = 1 AND created > ? ORDER BY created DESC LIMIT 5",
            (cutoff,),
        ).fetchall()
        db.close()
        lines.append(f"\nMEMORIES: {mem_count} total")
        if recent_mems:
            lines.append(f"  New (last 2h): {len(recent_mems)}")
            for m in recent_mems:
                lines.append(f"    + {m[0]}")
    except Exception as e:
        logger.warning("Failed to query memories for status report: %s", e)
        lines.append(f"\nMEMORIES: {mem_count} total")

    # Scheduler
    cron_active = len(aibrain_db.list_scheduled_jobs(enabled_only=True))
    lines.append(f"\nSCHEDULER: {cron_active} active jobs")

    # Approvals
    try:
        pending = aibrain_db.pending_approvals()
        lines.append(f"\nAPPROVALS: {pending} pending")
    except Exception as e:
        logger.warning("Failed to query approvals for status report: %s", e)
        lines.append("\nAPPROVALS: unavailable")

    # Costs
    try:
        from trace_logger import get_cost_summary
        cost_today = get_cost_summary(1)
        cost_total = cost_today.get("total_cost_usd", cost_today.get("total_cost", 0))
        lines.append(f"\nCOSTS: ${cost_total:.4f} today")
    except Exception as e:
        logger.warning("Failed to query costs for status report: %s", e)
        lines.append("\nCOSTS: no data")

    # Recent activity
    try:
        recent = aibrain_db.list_activity(limit=10)
        cutoff = (now - timedelta(hours=2)).isoformat()
        recent = [r for r in recent if r.get("timestamp", "") > cutoff]
        if recent:
            lines.append(f"\nACTIVITY (last 2h): {len(recent)} events")
            for r in recent:
                lines.append(f"  [{r.get('status', 'ok')}] {r.get('action', '')}")
    except (sqlite3.OperationalError, TypeError) as e:
        logger.warning("Failed to fetch recent activity for report: %s", e)

    lines.append(f"\n{'=' * 50}")
    lines.append(f"AIBrain v0.6.0 | {now.strftime('%I:%M %p')}")

    report_text = "\n".join(lines)
    return {"report": report_text, "timestamp": now.isoformat(), "memory_count": mem_count, "active_jobs": cron_active}


@router.get("/reports/executive/snapshot")
async def executive_snapshot():
    """Executive snapshot — current system state in one JSON payload.

    Returns:
    - total_memories: count of active memories
    - workflows_run_today: execution_log rows created today
    - avg_quality_today: average quality_score from execution_log today
    - cost_today_cents: sum of cost_cents from execution_log today (+ costs table usd→cents)
    - services_up: list of localhost ports that responded HTTP 200
    - version: aibrain package version
    """
    import httpx

    today = datetime.now().strftime("%Y-%m-%d")
    db = get_db()
    try:
        # 1. Total memories
        mem_row = db.execute("SELECT COUNT(*) FROM memories WHERE active = 1").fetchone()
        total_memories = mem_row[0] if mem_row else 0

        # 2. Workflows run today
        wf_row = db.execute(
            "SELECT COUNT(*) FROM execution_log WHERE DATE(created_at) = ?", (today,)
        ).fetchone()
        workflows_run_today = wf_row[0] if wf_row else 0

        # 3. Avg quality today
        aq_row = db.execute(
            "SELECT AVG(quality_score) FROM execution_log WHERE DATE(created_at) = ? AND quality_score IS NOT NULL",
            (today,),
        ).fetchone()
        avg_quality_today = round(float(aq_row[0]), 3) if aq_row and aq_row[0] is not None else None

        # 4. Cost today in cents — execution_log.cost_cents + costs table (usd*100)
        ec_row = db.execute(
            "SELECT COALESCE(SUM(cost_cents), 0) FROM execution_log WHERE DATE(created_at) = ?", (today,)
        ).fetchone()
        execution_cost_cents = int(ec_row[0]) if ec_row else 0

        tc_row = db.execute(
            "SELECT COALESCE(SUM(cost_usd), 0.0) FROM costs WHERE DATE(timestamp) = ?", (today,)
        ).fetchone()
        trace_cost_cents = int((tc_row[0] or 0.0) * 100) if tc_row else 0

        cost_today_cents = execution_cost_cents + trace_cost_cents
    finally:
        db.close()

    # 5. Service health — probe key local ports, collect those that reply 200
    _probe_ports = [8001, 8000, 11434]
    services_up: list[int] = []
    async with httpx.AsyncClient(timeout=1.5) as client:
        for port in _probe_ports:
            try:
                r = await client.get(f"http://localhost:{port}/")
                if r.status_code == 200:
                    services_up.append(port)
            except Exception:
                pass

    return {
        "total_memories": total_memories,
        "workflows_run_today": workflows_run_today,
        "avg_quality_today": avg_quality_today,
        "cost_today_cents": cost_today_cents,
        "services_up": services_up,
        "version": _AIBRAIN_VERSION,
        "snapshot_at": datetime.now().isoformat(),
    }


# ---------------------------------------------------------------------------
# Activity Log — lightweight observability
# ---------------------------------------------------------------------------

ACTIVITY_DB_PATH = AIBRAIN_ROOT / "activity.db"  # Legacy path, kept for reference


def get_activity_db():
    """Return a NEW connection to the consolidated DB for activity queries."""
    return get_db()


@router.get("/activity")
async def list_activity(
    limit: int = Query(50),
    agent: Optional[str] = Query(None),
    category: Optional[str] = Query(None),
):
    db = get_activity_db()
    query = "SELECT * FROM activity WHERE 1=1"
    params = []
    if agent:
        query += " AND agent = ?"
        params.append(agent)
    if category:
        query += " AND category = ?"
        params.append(category)
    from security import safe_limit
    limit = safe_limit(limit, 500)
    query += " ORDER BY timestamp DESC LIMIT ?"
    params.append(limit)
    rows = db.execute(query, params).fetchall()
    db.close()
    def _map_activity(r):
        d = dict(r)
        if "detail" in d and "details" not in d:
            d["details"] = d.pop("detail")
        return d
    return {"count": len(rows), "entries": [_map_activity(r) for r in rows]}


@router.post("/activity")
async def log_activity(body: dict):
    action = body.get("action")
    if not action:
        return JSONResponse({"error": "action required"}, status_code=400)
    db = get_activity_db()
    now = datetime.now().isoformat()
    agent = body.get("agent", os.getenv("AGENT_ID", "agent"))
    category = body.get("category", "general")
    detail = body.get("detail", "")
    status = body.get("status", "ok")
    db.execute(
        "INSERT INTO activity (timestamp, agent, action, category, detail, status) VALUES (?, ?, ?, ?, ?, ?)",
        (now, agent, action, category, detail, status)
    )
    entry_id = db.execute("SELECT last_insert_rowid()").fetchone()[0]
    db.commit()
    db.close()

    # Broadcast real-time notification
    if _notify_callback:
        import asyncio
        entry = {"id": entry_id, "timestamp": now, "agent": agent, "action": action,
                 "category": category, "detail": detail, "status": status}
        asyncio.ensure_future(_notify_callback({"type": "activity", "entry": entry}))

    return {"status": "logged", "timestamp": now, "id": entry_id}


@router.delete("/activity")
async def clear_activity():
    """Delete all activity log entries."""
    db = get_activity_db()
    db.execute("DELETE FROM activity")
    db.commit()
    db.close()
    return {"status": "cleared"}


# ---------------------------------------------------------------------------
# Traces / Observability / Cost Tracking
# ---------------------------------------------------------------------------

@router.get("/traces")
async def list_traces(
    limit: int = Query(50),
    trace_type: Optional[str] = Query(None),
):
    """Get recent traces for the observability timeline."""
    from security import safe_limit
    limit = safe_limit(limit, 500)
    from trace_logger import get_recent_traces
    return {"traces": get_recent_traces(limit=limit, trace_type=trace_type)}


@router.get("/traces/stats")
async def trace_stats():
    """Overall trace statistics."""
    from trace_logger import get_trace_stats
    return get_trace_stats()


@router.get("/costs/summary")
@require_tier("pro")
async def cost_summary(days: int = Query(30)):
    """Total LLM spend, token counts, and call stats."""
    from llm_router import get_cost_summary
    return get_cost_summary(days)


@router.get("/costs/by-model")
@require_tier("pro")
async def cost_by_model(days: int = Query(30)):
    """LLM cost breakdown per model."""
    from llm_router import get_cost_by_model
    return {"models": get_cost_by_model(days), "period_days": days}


@router.get("/costs/by-workflow")
@require_tier("pro")
async def cost_by_workflow(days: int = Query(30)):
    """LLM cost breakdown per workflow."""
    from llm_router import get_cost_by_workflow
    return {"workflows": get_cost_by_workflow(days), "period_days": days}


@router.get("/costs/daily")
@require_tier("pro")
async def cost_daily(days: int = Query(30)):
    """Daily LLM spend for charting."""
    from llm_router import get_daily_costs
    return {"daily": get_daily_costs(days), "period_days": days}


@router.get("/execution-log/summary")
async def execution_log_summary():
    """Summary stats from the execution_log table: count, last_run, avg_quality."""
    db = get_db()
    try:
        count_row = db.execute("SELECT COUNT(*) as cnt FROM execution_log").fetchone()
        count = count_row["cnt"] if count_row else 0

        last_row = db.execute(
            "SELECT created_at FROM execution_log ORDER BY created_at DESC LIMIT 1"
        ).fetchone()
        last_run = last_row["created_at"] if last_row else None

        avg_row = db.execute(
            "SELECT AVG(quality_score) as avg_q FROM execution_log WHERE quality_score IS NOT NULL"
        ).fetchone()
        avg_quality = round(float(avg_row["avg_q"]), 3) if avg_row and avg_row["avg_q"] is not None else None

        return {
            "count": count,
            "last_run": last_run,
            "avg_quality": avg_quality,
        }
    finally:
        db.close()


@router.get("/models")
async def list_models():
    """List all configured LLM models and their status."""
    from llm_router import list_models as _list_models, LITELLM_AVAILABLE
    return {
        "models": _list_models(),
        "litellm_available": LITELLM_AVAILABLE,
    }


@router.post("/models/test")
async def test_model_endpoint(body: dict):
    """Test connectivity to a specific model. Body: {model: "claude-sonnet-4-20250514"}"""
    model = body.get("model")
    if not model:
        return JSONResponse({"error": "model required"}, status_code=400)
    from llm_router import test_model
    return test_model(model)


# ---------------------------------------------------------------------------
# NL Workflow Creation
# ---------------------------------------------------------------------------

@router.post("/workflows/create-from-nl")
@require_tier("pro")
async def create_workflow_from_nl(body: dict):
    """Create a new workflow from a natural language description.
    Body: {description: "Every morning check my email and summarize it"}
    """
    description = body.get("description", "").strip()
    if not description:
        return JSONResponse({"error": "description required"}, status_code=400)

    from workflow_generator import generate_workflow
    result = generate_workflow(description)
    if result.get("error"):
        return JSONResponse({"error": result["error"]}, status_code=500)
    return result


# ---------------------------------------------------------------------------
# Content Pipeline
# ---------------------------------------------------------------------------

@router.post("/content/generate")
@require_tier("pro")
async def generate_content(body: dict):
    """Generate content posts and add to approval queue.
    Body: {count: 5} — generates N posts and creates approval items for each.
    """
    import sys as _sys
    _sys.path.insert(0, str(AIBRAIN_ROOT / "workflows"))
    from content_calendar import generate_posts, save_state

    count = body.get("count", 5)
    state, new_posts = generate_posts(count=count)
    save_state(state)

    # Create approval items for each generated post
    approval_db = AIBRAIN_ROOT / "approval.db"
    from approval_queue import add_item as aq_add
    approval_ids = []
    for post in new_posts:
        aid = aq_add(
            approval_db,
            category="social",
            title=f"Post to {post['platform']}: {post['text'][:60]}...",
            detail=post["text"],
            payload={
                "action": "publish",
                "platform": post["platform"],
                "content": post["text"],
                "category": post["category"],
                "post_id": post["id"],
                "scheduled": post["scheduled"],
            },
        )
        approval_ids.append(aid)

    return {
        "generated": len(new_posts),
        "posts": new_posts,
        "approval_ids": approval_ids,
        "message": f"Created {len(new_posts)} posts. Approve them in the Approval Queue to publish.",
    }


def _load_content_state() -> dict:
    """Read content calendar state directly from the brain DB — no workflow import."""
    import json as _json
    STATE_KEY = "content_calendar_state"
    try:
        db = get_db()
        row = db.execute(
            "SELECT content FROM memories WHERE name=? AND active=1", (STATE_KEY,)
        ).fetchone()
        db.close()
        return _json.loads(row["content"]) if row else {"queue": [], "posted": []}
    except Exception:
        return {"queue": [], "posted": []}


@router.get("/content/queue")
async def content_queue():
    """Get the current content queue."""
    state = _load_content_state()
    queued = [p for p in state.get("queue", []) if p.get("status") == "queued"]
    queued.sort(key=lambda p: p.get("scheduled", ""))
    return {
        "queued": len(queued),
        "posted": len(state.get("posted", [])),
        "posts": queued,
    }


@router.get("/content/stats")
async def content_stats():
    """Content posting statistics."""
    state = _load_content_state()
    posted = state.get("posted", [])
    by_platform = {}
    by_category = {}
    for p in posted:
        plat = p.get("platform", "unknown")
        cat = p.get("category", "unknown")
        by_platform[plat] = by_platform.get(plat, 0) + 1
        by_category[cat] = by_category.get(cat, 0) + 1
    return {
        "total_posted": len(posted),
        "queued": len([p for p in state.get("queue", []) if p.get("status") == "queued"]),
        "by_platform": by_platform,
        "by_category": by_category,
    }


@router.delete("/approvals/all")
async def clear_all_approvals():
    """Delete all approval queue entries."""
    approval_db = AIBRAIN_ROOT / "approval.db"
    if approval_db.exists():
        import sqlite3 as _sq
        db = _sq.connect(str(approval_db))
        db.execute("DELETE FROM approval_queue")
        db.commit()
        db.close()
    return {"status": "cleared"}


# ---------------------------------------------------------------------------
# Broker — lightweight message relay for multi-agent communication
# ---------------------------------------------------------------------------

_broker_queues: dict = {}  # in-memory: {agent_name: [messages]}


@router.post("/broker/send")
@require_tier("pro")
async def broker_send(body: dict):
    """Send a message to another agent's queue."""
    to = body.get("to")
    msg = body.get("message")
    if not to or not msg:
        return JSONResponse({"error": "to and message required"}, status_code=400)

    if to not in _broker_queues:
        _broker_queues[to] = []

    entry = {
        "from": body.get("from", "unknown"),
        "to": to,
        "message": msg,
        "timestamp": datetime.now().isoformat(),
        "type": body.get("type", "text"),
    }
    _broker_queues[to].append(entry)

    # Keep max 100 messages per queue
    if len(_broker_queues[to]) > 100:
        _broker_queues[to] = _broker_queues[to][-100:]

    return {"status": "queued", "queue_depth": len(_broker_queues[to])}


@router.get("/broker/recv")
@require_tier("pro")
async def broker_recv(
    agent: str = Query(..., alias="for"),
    peek: bool = Query(False),
):
    """Receive messages for an agent. Pops by default, peek=true to leave in queue."""
    queue = _broker_queues.get(agent, [])
    if not queue:
        return {"messages": [], "count": 0}

    if peek:
        return {"messages": queue, "count": len(queue)}

    # Pop all messages
    messages = list(queue)
    _broker_queues[agent] = []
    return {"messages": messages, "count": len(messages)}


@router.get("/broker/status")
async def broker_status():
    """Show all agent queues and depths."""
    return {
        "queues": {name: len(msgs) for name, msgs in _broker_queues.items()},
        "total_messages": sum(len(msgs) for msgs in _broker_queues.values()),
    }


# ---------------------------------------------------------------------------
# Workflow Builder — visual node/edge graph persistence
# ---------------------------------------------------------------------------

BUILDER_DIR = AIBRAIN_ROOT / "builder_workflows"


@router.post("/workflows/builder")
async def save_builder_workflow(body: dict):
    """Save a visual workflow graph. Body: {name, nodes, edges}."""
    BUILDER_DIR.mkdir(exist_ok=True)
    name = body.get("name", "untitled").strip()
    wf_id = body.get("id") or name.lower().replace(" ", "_").replace("-", "_")
    # Sanitize
    wf_id = "".join(c for c in wf_id if c.isalnum() or c == "_")[:64]

    data = {
        "id": wf_id,
        "name": name,
        "nodes": body.get("nodes", []),
        "edges": body.get("edges", []),
        "updated": datetime.now().isoformat(),
    }
    path = BUILDER_DIR / f"{wf_id}.json"
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return {"id": wf_id, "status": "saved"}


@router.delete("/workflows/builder/{workflow_id}")
async def delete_builder_workflow(workflow_id: str):
    """Delete a visual workflow graph."""
    path = BUILDER_DIR / f"{workflow_id}.json"
    if path.exists():
        path.unlink()
    return {"id": workflow_id, "status": "deleted"}


# ---------------------------------------------------------------------------
# Content Pipeline — multi-platform content creation, scheduling, publishing
# ---------------------------------------------------------------------------

CONTENT_DB = AIBRAIN_ROOT / "content.db"


def _content_db():
    """Get or create content pipeline database."""
    db = sqlite3.connect(str(CONTENT_DB))
    db.row_factory = sqlite3.Row
    db.execute("""
        CREATE TABLE IF NOT EXISTS content (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            body TEXT NOT NULL DEFAULT '',
            content_type TEXT DEFAULT 'text',
            platforms TEXT DEFAULT '[]',
            status TEXT DEFAULT 'draft',
            scheduled_at TEXT,
            published_at TEXT,
            ai_prompt TEXT,
            tags TEXT DEFAULT '[]',
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now'))
        )
    """)
    db.commit()
    return db


@router.get("/content")
async def list_content(status: Optional[str] = None, platform: Optional[str] = None, limit: int = 50):
    """List content items with optional filters."""
    from security import safe_limit
    limit = safe_limit(limit, 200)
    db = _content_db()
    query = "SELECT * FROM content"
    params = []
    wheres = []
    if status:
        wheres.append("status = ?")
        params.append(status)
    if platform:
        wheres.append("platforms LIKE ?")
        params.append(f'%"{platform}"%')
    if wheres:
        query += " WHERE " + " AND ".join(wheres)
    query += " ORDER BY CASE status WHEN 'scheduled' THEN 0 WHEN 'draft' THEN 1 WHEN 'pending_approval' THEN 2 WHEN 'published' THEN 3 ELSE 4 END, created_at DESC"
    query += " LIMIT ?"
    params.append(limit)
    rows = db.execute(query, params).fetchall()
    items = []
    for r in rows:
        item = dict(r)
        item["platforms"] = json.loads(item["platforms"]) if item["platforms"] else []
        item["tags"] = json.loads(item["tags"]) if item["tags"] else []
        items.append(item)
    db.close()
    return {"items": items}



@router.get("/content/{content_id}")
async def get_content(content_id: int):
    """Get a single content item."""
    db = _content_db()
    row = db.execute("SELECT * FROM content WHERE id = ?", (content_id,)).fetchone()
    db.close()
    if not row:
        return JSONResponse({"error": "Not found"}, status_code=404)
    item = dict(row)
    item["platforms"] = json.loads(item["platforms"]) if item["platforms"] else []
    item["tags"] = json.loads(item["tags"]) if item["tags"] else []
    return item


@router.post("/content")
async def create_content(body: dict):
    """Create a new content item."""
    db = _content_db()
    now = datetime.utcnow().isoformat()
    db.execute(
        "INSERT INTO content (body, content_type, platforms, status, scheduled_at, ai_prompt, tags, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (
            body.get("body", ""),
            body.get("content_type", "text"),
            json.dumps(body.get("platforms", [])),
            body.get("status", "draft"),
            body.get("scheduled_at"),
            body.get("ai_prompt"),
            json.dumps(body.get("tags", [])),
            now, now,
        ),
    )
    db.commit()
    content_id = db.execute("SELECT last_insert_rowid()").fetchone()[0]
    db.close()

    # If posting now, create approval request
    if body.get("status") == "pending_approval":
        try:
            from approval_queue import add_item as aq_add
            platforms = body.get("platforms", [])
            preview = body.get("body", "")[:120]
            aq_add(
                AIBRAIN_ROOT / "approval.db",
                category="content",
                title=f"Publish content to {', '.join(platforms)}",
                detail=preview,
                payload={"content_id": content_id, "platforms": platforms, "action": "publish"},
            )
        except (ImportError, sqlite3.OperationalError, TypeError) as e:
            logger.warning("Approval queue creation failed for content %s: %s", content_id, e)

    return {"id": content_id, "status": "created"}


@router.put("/content/{content_id}")
async def update_content(content_id: int, body: dict):
    """Update a content item."""
    _CONTENT_COLUMNS = frozenset({"body", "content_type", "status", "scheduled_at", "ai_prompt", "platforms", "tags", "updated_at"})
    db = _content_db()
    col_updates = {}
    for key in ("body", "content_type", "status", "scheduled_at", "ai_prompt"):
        if key in body:
            col_updates[key] = body[key]
    if "platforms" in body:
        col_updates["platforms"] = json.dumps(body["platforms"])
    if "tags" in body:
        col_updates["tags"] = json.dumps(body["tags"])
    col_updates["updated_at"] = datetime.utcnow().isoformat()
    params = []
    sql = _safe_update("content", _CONTENT_COLUMNS, col_updates, "id = ?", params)
    params.append(content_id)
    db.execute(sql, params)
    db.commit()
    db.close()
    return {"id": content_id, "status": "updated"}


@router.delete("/content/{content_id}")
async def delete_content(content_id: int):
    """Delete a content item."""
    db = _content_db()
    db.execute("DELETE FROM content WHERE id = ?", (content_id,))
    db.commit()
    db.close()
    return {"id": content_id, "status": "deleted"}


@router.post("/content/{content_id}/publish")
async def publish_content(content_id: int):
    """Mark content as published (actual publishing handled by workflow engine)."""
    db = _content_db()
    now = datetime.utcnow().isoformat()
    db.execute("UPDATE content SET status = 'published', published_at = ?, updated_at = ? WHERE id = ?", (now, now, content_id))
    db.commit()
    db.close()
    if _notify_callback:
        import asyncio
        asyncio.ensure_future(_notify_callback({"type": "content", "action": "published", "content_id": content_id}))
    return {"id": content_id, "status": "published"}



# ---------------------------------------------------------------------------
# Peers — multi-agent mesh registry (works with Tailscale or direct IP)
# ---------------------------------------------------------------------------

# Populated at runtime via /peers API. Starts empty ({"peers": []}).
# Gitignored — each instance builds its own peer list via registration.
# broker_poll.py was removed — peer_daemon.py is the canonical polling mechanism.
PEERS_FILE = AIBRAIN_ROOT / "peers.json"


def _load_peers():
    if PEERS_FILE.exists():
        try:
            return json.loads(PEERS_FILE.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass
    return {"peers": []}


def _save_peers(data):
    PEERS_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")


@router.get("/peers")
async def list_peers():
    """List all known agent peers in the mesh."""
    from security import validate_url
    data = _load_peers()
    # Check health of each peer (async, with SSRF protection)
    import httpx
    async with httpx.AsyncClient(timeout=3) as client:
        for peer in data.get("peers", []):
            health_url = f"{peer['url']}/health"
            is_safe, _ = validate_url(health_url)
            if not is_safe:
                peer["status"] = "blocked"
                continue
            try:
                resp = await client.get(health_url)
                peer["status"] = "online" if resp.status_code == 200 else "error"
            except Exception as e:
                logger.warning("Peer health check failed for %s: %s", peer.get("name", "unknown"), e)
                peer["status"] = "offline"
    return data


@router.post("/peers")
async def add_peer(body: dict):
    """Register a new agent peer. Body: {name, url, ?description}"""
    from security import validate_url
    name = body.get("name")
    url = body.get("url")
    if not name or not url:
        return JSONResponse({"error": "name and url required"}, status_code=400)
    is_safe, reason = validate_url(url)
    if not is_safe:
        return JSONResponse({"error": f"Blocked URL: {reason}"}, status_code=400)

    data = _load_peers()
    # Update existing or add new
    existing = next((p for p in data["peers"] if p["name"] == name), None)
    if existing:
        existing["url"] = url
        existing["description"] = body.get("description", existing.get("description", ""))
        existing["updated"] = datetime.now().isoformat()
    else:
        data["peers"].append({
            "name": name,
            "url": url.rstrip("/"),
            "description": body.get("description", ""),
            "added": datetime.now().isoformat(),
            "updated": datetime.now().isoformat(),
        })
    _save_peers(data)
    return {"status": "registered", "peer": name, "total_peers": len(data["peers"])}


@router.delete("/peers/{peer_name}")
async def remove_peer(peer_name: str):
    """Remove a peer from the mesh."""
    data = _load_peers()
    data["peers"] = [p for p in data["peers"] if p["name"] != peer_name]
    _save_peers(data)
    return {"status": "removed", "peer": peer_name}


# ---------------------------------------------------------------------------
# Networking API — Tailscale mesh status and management
# ---------------------------------------------------------------------------

@router.get("/networking/status")
async def networking_status():
    """Get full networking status including Tailscale mesh."""
    try:
        from aibrain_networking import get_status
        return get_status()
    except ImportError:
        return {"installed": False, "connected": False, "error": "aibrain_networking not available"}


@router.get("/networking/peers")
async def networking_peers():
    """Get Tailscale peers on the mesh."""
    try:
        from aibrain_networking import get_peers, is_tailscale_ready
        if not is_tailscale_ready():
            return {"peers": [], "tailscale_connected": False}
        return {"peers": get_peers(), "tailscale_connected": True}
    except ImportError:
        return {"peers": [], "tailscale_connected": False}


# ---------------------------------------------------------------------------
# Config API — read/write config.json (LLM provider, theme, preferences)
# ---------------------------------------------------------------------------

# Settings that are safe to read/write via the UI
_ALLOWED_SETTINGS = {
    "llm_provider", "anthropic_api_key", "openai_api_key",
    "anthropic_model", "openai_model", "ollama_model", "ollama_url",
    "llm_routing",
    "theme", "auto_refresh", "refresh_interval",
    "notify_approvals", "notify_chat",
    "setup_complete", "user_name", "user_email", "timezone",
    "smtp_user", "smtp_pass", "smtp_host", "smtp_port",
    "github_token", "telegram_bot_token", "weather_api_key",
    "budget_daily", "budget_monthly",
}

# Keys whose values must NEVER appear in API responses — not even partially.
# The dashboard only needs to know whether a key is configured (true/false),
# not its value.  Any field matching *_token, *_key, *_password, *_secret
# is caught by the dynamic check below; this set adds explicit names.
_SECRET_KEYS = {
    "anthropic_api_key", "openai_api_key", "smtp_pass", "github_token",
    "telegram_bot_token", "weather_api_key",
    "email_app_password", "smtp_password", "gmail_app_password",
}

# Legacy alias kept so existing imports don't break
_MASKED_KEYS = _SECRET_KEYS


def _is_secret_key(key: str) -> bool:
    """Return True if *key* looks like a credential field."""
    if key in _SECRET_KEYS:
        return True
    lower = key.lower()
    return any(lower.endswith(suffix) for suffix in ("_token", "_key", "_password", "_secret"))


@router.get("/config")
async def get_config(request: Request):
    """Get user-facing config.  Secret fields are replaced with a boolean
    indicating whether a value is configured — never leaked, not even masked."""
    _require_localhost(request)
    cfg = _load_config()
    safe = {}
    for k in _ALLOWED_SETTINGS:
        val = cfg.get(k)
        if val is None:
            continue
        if _is_secret_key(k):
            # Only reveal whether the secret is set, never its value
            safe[k] = True if val else False
        else:
            safe[k] = val
    # Report which providers are available
    providers = []
    if cfg.get("anthropic_api_key"):
        providers.append("claude")
    if cfg.get("openai_api_key"):
        providers.append("openai")
    providers.append("ollama")  # always available if user runs it
    providers.append("claude_cli")  # always available if CLI installed
    safe["available_providers"] = providers
    safe["active_provider"] = cfg.get("llm_provider", "auto")
    return safe


@router.put("/config")
async def update_config(request: Request, body: dict):
    """Update config settings. Only allowed keys are written. Localhost only."""
    _require_localhost(request)
    cfg = _load_config()
    updated = []
    # Validate ALL URL fields before accepting — block SSRF on any *_url key
    from security import validate_url
    for k, v in body.items():
        if k.endswith("_url") and isinstance(v, str) and v.strip():
            is_safe, reason = validate_url(v)
            if not is_safe:
                return JSONResponse(
                    {"error": f"Invalid {k}: {reason}"},
                    status_code=400,
                )
    for k, v in body.items():
        if k not in _ALLOWED_SETTINGS:
            continue
        # Don't overwrite a real key with a masked version
        if k in _MASKED_KEYS and isinstance(v, str) and "..." in v:
            continue
        cfg[k] = v
        updated.append(k)
    _config_file.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    return {"status": "updated", "keys": updated}


# ---------------------------------------------------------------------------
# Provider connection test
# ---------------------------------------------------------------------------

@router.post("/config/test-provider")
async def test_provider(request: Request, body: dict):
    """Test if an AI provider is reachable and the API key works. Localhost only."""
    _require_localhost(request)
    provider = body.get("provider", "auto")
    cfg = _load_config()

    results = {}

    import httpx
    async with httpx.AsyncClient(timeout=10) as client:
        if provider in ("claude", "auto"):
            key = cfg.get("anthropic_api_key", "")
            if key:
                try:
                    resp = await client.post(
                        "https://api.anthropic.com/v1/messages",
                        headers={
                            "x-api-key": key,
                            "anthropic-version": "2023-06-01",
                            "content-type": "application/json",
                        },
                        json={
                            "model": "claude-haiku-4-5-20251001",
                            "max_tokens": 1,
                            "messages": [{"role": "user", "content": "hi"}],
                        },
                    )
                    if resp.status_code == 401:
                        results["claude"] = {"ok": False, "message": "Invalid API key"}
                    elif resp.status_code == 429:
                        results["claude"] = {"ok": True, "message": "Connected (rate limited)"}
                    else:
                        results["claude"] = {"ok": True, "message": "Connected"}
                except Exception as e:
                    results["claude"] = {"ok": False, "message": str(e)[:100]}
            else:
                results["claude"] = {"ok": False, "message": "No API key configured"}

        if provider in ("openai", "auto"):
            key = cfg.get("openai_api_key", "")
            if key:
                try:
                    resp = await client.get(
                        "https://api.openai.com/v1/models",
                        headers={"Authorization": f"Bearer {key}"},
                    )
                    if resp.status_code == 401:
                        results["openai"] = {"ok": False, "message": "Invalid API key"}
                    else:
                        results["openai"] = {"ok": True, "message": "Connected"}
                except Exception as e:
                    results["openai"] = {"ok": False, "message": str(e)[:100]}
            else:
                results["openai"] = {"ok": False, "message": "No API key configured"}

        if provider in ("ollama", "auto"):
            url = cfg.get("ollama_url", "http://localhost:11434")
            from security import validate_url
            is_safe, reason = validate_url(f"{url}/api/tags")
            if not is_safe:
                results["ollama"] = {"ok": False, "message": f"Blocked URL: {reason}"}
            else:
                try:
                    resp = await client.get(f"{url}/api/tags", timeout=5)
                    results["ollama"] = {"ok": True, "message": "Connected"}
                except Exception as e:
                    logger.warning("Ollama connection failed at %s: %s", url, e)
                    results["ollama"] = {"ok": False, "message": f"Not reachable at {url}"}

    return {"results": results}


# ---------------------------------------------------------------------------
# MCP Servers — detect installed from ~/.claude.json
# ---------------------------------------------------------------------------

@router.get("/mcp/installed")
async def mcp_installed():
    """Detect which MCP servers are configured in ~/.claude.json."""
    claude_config = Path.home() / ".claude.json"
    if not claude_config.exists():
        return {"installed": {}, "config_path": str(claude_config), "exists": False}

    try:
        data = json.loads(claude_config.read_text(encoding="utf-8"))
        servers = data.get("mcpServers", {})
        installed = {}
        for name, config in servers.items():
            installed[name] = {
                "command": config.get("command", ""),
                "args": config.get("args", []),
                "enabled": not config.get("disabled", False),
            }
        return {"installed": installed, "config_path": str(claude_config), "exists": True}
    except (json.JSONDecodeError, OSError) as e:
        return {"installed": {}, "config_path": "~/.claude.json", "exists": True, "error": "Could not parse config"}


# ---------------------------------------------------------------------------
# MCP Server Registry — CRUD for registered MCP servers
# ---------------------------------------------------------------------------

@router.get("/mcp/servers")
async def mcp_list_servers(request: Request):
    """List all MCP servers from the registry DB."""
    _require_localhost(request)
    db_path = AIBRAIN_ROOT / "aibrain.db"
    try:
        db = sqlite3.connect(str(db_path))
        db.row_factory = sqlite3.Row
        # Ensure table exists
        db.execute("""
            CREATE TABLE IF NOT EXISTS mcp_servers (
                name TEXT PRIMARY KEY,
                config_json TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)
        rows = db.execute("SELECT * FROM mcp_servers ORDER BY name").fetchall()
        servers = []
        for r in rows:
            s = dict(r)
            try:
                s["config"] = json.loads(s.get("config_json", "{}"))
            except (json.JSONDecodeError, TypeError):
                s["config"] = {}
            servers.append(s)
        db.close()
        return {"servers": servers}
    except Exception as e:
        return {"servers": [], "error": "Could not load MCP servers"}


# Whitelist of executables allowed for MCP server registration.
# Only well-known runtimes — no shells, no arbitrary binaries.
_MCP_ALLOWED_COMMANDS = frozenset({
    "python", "python3", "python.exe", "python3.exe",
    "node", "node.exe",
    "npx", "npx.exe", "npx.cmd",
    "uvx", "uvx.exe",
    "deno", "deno.exe",
    "bun", "bun.exe",
})

# Shell metacharacters that must never appear in MCP command or args
_SHELL_META = re.compile(r'[;&|`$(){}<>\n\r]')

# Dangerous interpreter flags that enable arbitrary code execution.
# These must be blocked in ALL MCP server args to prevent whitelist bypass
# (e.g. python -c "import os; os.system('rm -rf /')").
_DANGEROUS_INTERPRETER_FLAGS = frozenset({
    "-c", "-e", "-m",
    "--eval", "--command", "--exec",
    "-exec", "--import",
    # Node/Deno/Bun variants
    "--eval-module", "-p", "--print",
})


@router.post("/mcp/servers")
async def mcp_add_server(request: Request, body: dict):
    """Register a new MCP server.  Validates command against whitelist."""
    _require_localhost(request)

    name = body.get("name", "").strip()
    if not name:
        return JSONResponse(status_code=400, content={"error": "name is required"})

    transport = body.get("transport", "stdio")
    command = body.get("command", "").strip()

    # --- Command injection prevention ---
    if transport == "stdio":
        if not command:
            return JSONResponse(status_code=400, content={"error": "command is required for stdio transport"})
        # Extract bare executable name (strip any path prefix)
        import ntpath, posixpath
        exe_name = ntpath.basename(posixpath.basename(command)).lower()
        if exe_name not in _MCP_ALLOWED_COMMANDS:
            return JSONResponse(
                status_code=400,
                content={"error": f"Command '{exe_name}' not in allowed list: {sorted(_MCP_ALLOWED_COMMANDS)}"},
            )
        # Reject shell metacharacters in command
        if _SHELL_META.search(command):
            return JSONResponse(status_code=400, content={"error": "Command contains shell metacharacters"})
        # Reject shell metacharacters in args
        args = body.get("args", [])
        if not isinstance(args, list):
            return JSONResponse(status_code=400, content={"error": "args must be a list"})
        for i, arg in enumerate(args):
            if not isinstance(arg, str):
                return JSONResponse(status_code=400, content={"error": f"args[{i}] must be a string"})
            if _SHELL_META.search(arg):
                return JSONResponse(status_code=400, content={"error": f"args[{i}] contains shell metacharacters"})
            # Block dangerous interpreter flags that enable arbitrary code execution
            # Check the arg itself and also handle --flag=value forms
            arg_key = arg.split("=", 1)[0].strip().lower()
            if arg_key in _DANGEROUS_INTERPRETER_FLAGS:
                return JSONResponse(
                    status_code=400,
                    content={"error": f"args[{i}] contains dangerous interpreter flag '{arg_key}' — "
                             f"blocked to prevent code execution bypass"},
                )
    elif transport == "sse":
        # For SSE transport, validate the URL
        url = body.get("url", "")
        if url:
            from security import validate_url
            is_safe, reason = validate_url(url)
            if not is_safe:
                return JSONResponse(status_code=400, content={"error": f"Unsafe MCP server URL: {reason}"})

    config = {
        "transport": transport,
        "command": command,
        "args": body.get("args", []),
        "url": body.get("url", ""),
        "headers": body.get("headers", {}),
    }

    db_path = AIBRAIN_ROOT / "aibrain.db"
    db = sqlite3.connect(str(db_path))
    db.execute("""
        CREATE TABLE IF NOT EXISTS mcp_servers (
            name TEXT PRIMARY KEY,
            config_json TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    db.execute(
        "INSERT OR REPLACE INTO mcp_servers (name, config_json, updated_at) VALUES (?, ?, datetime('now'))",
        (name, json.dumps(config)),
    )
    db.commit()
    db.close()
    return {"status": "registered", "name": name, "config": config}


@router.get("/mcp/servers/{name}/tools")
async def mcp_server_tools(request: Request, name: str):
    """Get cached tools for a server. Returns tools from mcp_tool_cache if available."""
    _require_localhost(request)
    db_path = AIBRAIN_ROOT / "aibrain.db"
    try:
        db = sqlite3.connect(str(db_path))
        db.row_factory = sqlite3.Row
        db.execute("""
            CREATE TABLE IF NOT EXISTS mcp_tool_cache (
                server_name TEXT NOT NULL,
                tool_name TEXT NOT NULL,
                tool_schema TEXT NOT NULL,
                cached_at REAL NOT NULL,
                PRIMARY KEY (server_name, tool_name)
            )
        """)
        rows = db.execute(
            "SELECT tool_name, tool_schema, cached_at FROM mcp_tool_cache WHERE server_name=?",
            (name,),
        ).fetchall()
        tools = []
        for r in rows:
            t = {"name": r["tool_name"], "cached_at": r["cached_at"]}
            try:
                t["schema"] = json.loads(r["tool_schema"])
            except (json.JSONDecodeError, TypeError):
                t["schema"] = {}
            tools.append(t)
        db.close()
        return {"server": name, "tools": tools, "count": len(tools)}
    except Exception as e:
        return {"server": name, "tools": [], "count": 0, "error": "Could not load tools"}


@router.delete("/mcp/servers/{name}")
async def mcp_delete_server(request: Request, name: str):
    """Remove a registered MCP server."""
    _require_localhost(request)
    db_path = AIBRAIN_ROOT / "aibrain.db"
    db = sqlite3.connect(str(db_path))
    db.execute("DELETE FROM mcp_servers WHERE name=?", (name,))
    # mcp_tool_cache may not exist yet — ignore if missing
    try:
        db.execute("DELETE FROM mcp_tool_cache WHERE server_name=?", (name,))
    except sqlite3.OperationalError:
        pass  # table doesn't exist yet, nothing to clean up
    db.commit()
    db.close()
    return {"deleted": name}


# ---------------------------------------------------------------------------
# Ingest — file upload endpoint for brain ingestion
# ---------------------------------------------------------------------------

from fastapi import UploadFile, File as FastAPIFile
import tempfile

_MAX_UPLOAD_BYTES = 10 * 1024 * 1024  # 10 MB
_ALLOWED_UPLOAD_EXTENSIONS = {".txt", ".md", ".json", ".csv", ".pdf", ".py", ".toml", ".yaml", ".yml"}


@router.post("/ingest")
async def ingest_file(file: UploadFile = FastAPIFile(...), collection: str = "default", force: bool = False):
    """Upload a file, run brain.ingest(), return result."""
    if not file.filename:
        return JSONResponse(status_code=400, content={"error": "No file provided"})

    # Validate file extension against allowlist
    file_ext = Path(file.filename).suffix.lower()
    if file_ext not in _ALLOWED_UPLOAD_EXTENSIONS:
        allowed = ", ".join(sorted(_ALLOWED_UPLOAD_EXTENSIONS))
        return JSONResponse(
            status_code=400,
            content={"error": f"File type '{file_ext}' not allowed. Accepted: {allowed}"},
        )

    # Check file size if available in headers
    if file.size and file.size > _MAX_UPLOAD_BYTES:
        return JSONResponse(status_code=413, content={"error": "File too large. Maximum upload size is 10 MB."})

    # Save to temp dir
    tmp_dir = Path(tempfile.mkdtemp(prefix="aibrain_ingest_"))
    safe_name = Path(file.filename).name  # strip directory components — prevent path traversal
    file_path = tmp_dir / safe_name
    content = await file.read()

    # Double-check actual content size after reading
    if len(content) > _MAX_UPLOAD_BYTES:
        return JSONResponse(status_code=413, content={"error": "File too large. Maximum upload size is 10 MB."})

    file_path.write_bytes(content)

    try:
        from aibrain.core.ingest import IngestionPipeline
        from aibrain.core.memory_api import Brain

        brain = Brain()
        ingester = IngestionPipeline(brain)

        # If force, delete existing hash record so it re-ingests
        if force:
            try:
                db = sqlite3.connect(str(AIBRAIN_ROOT / "aibrain.db"))
                db.execute("DELETE FROM ingestion_log WHERE source_path=?", (str(file_path),))
                db.commit()
                db.close()
            except Exception:
                pass

        result = ingester.ingest(str(file_path), collection=collection)
        return {
            "status": "ok",
            "source": result.source,
            "chunks_created": result.chunks_created,
            "memories_stored": result.memories_stored,
            "skipped_unchanged": result.skipped_unchanged,
            "errors": result.errors,
            "duration_seconds": round(result.duration_seconds, 2),
            "source_hash": result.source_hash,
        }
    except Exception as e:
        logger.error("Ingest endpoint failed: %s", e)
        return JSONResponse(status_code=500, content={"error": "Internal server error"})
    finally:
        # Clean up temp dir
        import shutil
        try:
            shutil.rmtree(tmp_dir, ignore_errors=True)
        except Exception:
            pass


@router.get("/ingest/history")
async def ingest_history(limit: int = 50):
    """Get ingestion history from ingestion_log table."""
    from security import safe_limit
    limit = safe_limit(limit, 500)
    db_path = AIBRAIN_ROOT / "aibrain.db"
    try:
        db = sqlite3.connect(str(db_path))
        db.row_factory = sqlite3.Row
        db.execute("""
            CREATE TABLE IF NOT EXISTS ingestion_log (
                source_path TEXT PRIMARY KEY,
                source_hash TEXT NOT NULL,
                chunks_created INTEGER DEFAULT 0,
                collection TEXT DEFAULT 'default',
                ingested_at TEXT NOT NULL
            )
        """)
        rows = db.execute(
            "SELECT * FROM ingestion_log ORDER BY ingested_at DESC LIMIT ?",
            (limit,),
        ).fetchall()
        db.close()
        return {"history": [dict(r) for r in rows]}
    except Exception as e:
        return {"history": [], "error": "Could not load ingestion history"}


# ---------------------------------------------------------------------------
# Tasks — simple task queue backed by SQLite
# ---------------------------------------------------------------------------
_TASKS_DB = AIBRAIN_ROOT / "tasks.db"

def _init_tasks_db():
    db = sqlite3.connect(str(_TASKS_DB))
    db.execute("""
        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT DEFAULT '',
            agent TEXT DEFAULT 'system',
            status TEXT DEFAULT 'pending',
            progress REAL DEFAULT -1,
            output TEXT DEFAULT '',
            error TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            started_at TEXT,
            completed_at TEXT
        )
    """)
    db.commit()
    return db

@router.get("/tasks")
async def list_tasks(status: Optional[str] = Query(None), limit: int = Query(50)):
    from security import safe_limit
    limit = safe_limit(limit, 500)
    db = _init_tasks_db()
    cur = db.cursor()
    if status:
        cur.execute(
            "SELECT * FROM tasks WHERE status = ? ORDER BY created_at DESC LIMIT ?",
            (status, limit)
        )
    else:
        cur.execute(
            "SELECT * FROM tasks ORDER BY created_at DESC LIMIT ?", (limit,)
        )
    rows = cur.fetchall()
    cols = [d[0] for d in cur.description]
    db.close()
    return {"tasks": [dict(zip(cols, r)) for r in rows]}

@router.post("/tasks")
async def create_task(data: dict):
    db = _init_tasks_db()
    now = datetime.utcnow().isoformat()
    db.execute(
        "INSERT INTO tasks (name, description, agent, status, created_at) VALUES (?, ?, ?, 'pending', ?)",
        (data.get("name", "Unnamed"), data.get("description", ""), data.get("agent", "system"), now)
    )
    db.commit()
    task_id = db.execute("SELECT last_insert_rowid()").fetchone()[0]
    db.close()
    return {"id": task_id, "status": "pending"}

@router.post("/tasks/{task_id}/cancel")
async def cancel_task(task_id: int):
    db = _init_tasks_db()
    db.execute("UPDATE tasks SET status = 'cancelled', completed_at = ? WHERE id = ?",
               (datetime.utcnow().isoformat(), task_id))
    db.commit()
    db.close()
    return {"status": "cancelled"}

@router.post("/tasks/{task_id}/retry")
async def retry_task(task_id: int):
    db = _init_tasks_db()
    db.execute("UPDATE tasks SET status = 'pending', error = '', output = '', started_at = NULL, completed_at = NULL WHERE id = ?",
               (task_id,))
    db.commit()
    db.close()
    return {"status": "pending"}


# ---------------------------------------------------------------------------
# Backups — snapshot memory DB to file
# ---------------------------------------------------------------------------
_BACKUPS_DIR = AIBRAIN_ROOT / "backups"

@router.get("/backups")
async def list_backups():
    _BACKUPS_DIR.mkdir(exist_ok=True)
    backups = []
    for f in sorted(_BACKUPS_DIR.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True):
        stat = f.stat()
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
            memory_count = len(data.get("memories", []))
        except Exception as e:
            logger.warning("Failed to parse backup file %s: %s", f.name, e)
            memory_count = 0
        backups.append({
            "filename": f.name,
            "name": f.stem,
            "size": stat.st_size,
            "memory_count": memory_count,
            "created_at": datetime.fromtimestamp(stat.st_mtime).isoformat(),
        })
    return {"backups": backups}

@router.post("/backups")
async def create_backup(data: dict = {}):
    _BACKUPS_DIR.mkdir(exist_ok=True)
    name = data.get("name", f"backup-{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}")

    # Export memories
    db = get_db()
    try:
        rows = db.execute(
            "SELECT id, name, type, content, tags, created, updated FROM memories WHERE active = 1"
        ).fetchall()
        memories = [
            {"id": r[0], "name": r[1], "type": r[2], "content": r[3], "tags": r[4], "created": r[5], "updated": r[6]}
            for r in rows
        ]
    finally:
        db.close()

    backup_data = {
        "version": "1.0",
        "created_at": datetime.utcnow().isoformat(),
        "name": name,
        "memories": memories,
    }

    # Include cron jobs if available
    if CRON_JOBS_PATH.exists():
        try:
            backup_data["crons"] = json.loads(CRON_JOBS_PATH.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError) as e:
            logger.warning("Failed to include cron jobs in backup: %s", e)

    backup_path = _BACKUPS_DIR / f"{name}.json"
    backup_path.write_text(json.dumps(backup_data, indent=2), encoding="utf-8")

    return {"name": name, "path": str(backup_path), "memory_count": len(memories)}

@router.post("/backups/{filename}/restore")
async def restore_backup(filename: str):
    path = _safe_backup_path(filename)
    if not path or not path.exists():
        return JSONResponse({"error": "Backup not found"}, status_code=404)

    data = json.loads(path.read_text(encoding="utf-8"))
    db = get_db()
    try:
        restored = 0
        for mem in data.get("memories", []):
            existing = db.execute("SELECT id FROM memories WHERE name = ?", (mem["name"],)).fetchone()
            if not existing:
                db.execute(
                    "INSERT INTO memories (name, type, content, tags, created, updated, active) VALUES (?, ?, ?, ?, ?, ?, 1)",
                    (mem["name"], mem.get("type", "reference"), mem.get("content", ""),
                     mem.get("tags", ""), mem.get("created", mem.get("created_at", datetime.utcnow().isoformat())),
                     mem.get("updated", mem.get("updated_at", datetime.utcnow().isoformat())))
                )
                restored += 1
        db.commit()
    finally:
        db.close()
    return {"memories_restored": restored}

def _safe_backup_path(filename: str) -> Path:
    """Resolve backup path and guard against path traversal."""
    path = (_BACKUPS_DIR / filename).resolve()
    if not path.suffix:
        path = path.with_suffix(".json")
    if not str(path).startswith(str(_BACKUPS_DIR.resolve())):  # noqa:PATH STARTSWITH BYPASS — path already sanitized and resolved
        return None
    return path

@router.get("/backups/{filename}/download")
async def download_backup(filename: str):
    path = _safe_backup_path(filename)
    if not path or not path.exists():
        return JSONResponse({"error": "Backup not found"}, status_code=404)
    data = json.loads(path.read_text(encoding="utf-8"))
    return data

@router.delete("/backups/{filename}")
async def delete_backup(filename: str):
    path = _safe_backup_path(filename)
    if not path:
        return JSONResponse({"error": "Invalid filename"}, status_code=400)
    if path.exists():
        path.unlink()
    return {"status": "deleted"}


# ---------------------------------------------------------------------------
# Logs — return recent activity as structured logs
# ---------------------------------------------------------------------------
@router.get("/logs")
async def get_logs(limit: int = Query(200)):
    """Return recent activity entries formatted as log lines from the activity DB."""
    from security import safe_limit
    limit = safe_limit(limit, 1000)

    try:
        db = get_activity_db()
        rows = db.execute(
            "SELECT * FROM activity ORDER BY timestamp DESC LIMIT ?", (limit,)
        ).fetchall()
        db.close()

        logs = []
        for entry in reversed(rows):  # chronological order
            entry = dict(entry)
            ts = entry.get("timestamp", "")
            if ts and "T" in ts:
                ts = ts.replace("T", " ")[:19]
            level = "ERROR" if entry.get("status") == "error" else "INFO"
            if entry.get("status") == "warning":
                level = "WARN"
            agent = entry.get("agent", "system")
            action = entry.get("action", "")
            detail = entry.get("detail", "")
            logs.append(f"[{ts}] {level} [{agent}] {action}" + (f" — {detail}" if detail else ""))

        return {"logs": logs}
    except Exception as e:
        logger.warning("Failed to query activity log: %s", e)
        return {"logs": []}


# ---------------------------------------------------------------------------
# Cost History — daily cost breakdown
# ---------------------------------------------------------------------------
@router.get("/costs/history")
async def cost_history(days: int = Query(7)):
    """Return daily cost breakdown for sparkline charts."""
    traces_dir = AIBRAIN_ROOT / "traces"
    daily = []

    for i in range(days):
        date = (datetime.utcnow() - timedelta(days=i)).strftime("%Y-%m-%d")
        day_cost = 0.0

        if traces_dir.exists():
            for f in traces_dir.glob(f"{date}*.json"):
                try:
                    trace = json.loads(f.read_text(encoding="utf-8"))
                    day_cost += trace.get("cost", 0) or 0
                except (json.JSONDecodeError, OSError) as e:
                    logger.warning("Skipping unreadable trace file %s: %s", f.name, e)

        daily.append({"date": date, "cost": round(day_cost, 4)})

    daily.reverse()  # oldest first for sparkline
    return {"daily": daily}


# ---------------------------------------------------------------------------
# Applications — job application tracker with priority levels
# ---------------------------------------------------------------------------

def _apps_db():
    """Return a connection to the consolidated DB for applications queries."""
    db = sqlite3.connect(str(aibrain_db.DB_PATH))
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA journal_mode=WAL")
    # Ensure priority column exists (idempotent)
    cols = [r[1] for r in db.execute("PRAGMA table_info(applications)").fetchall()]
    if "priority" not in cols:
        db.execute("ALTER TABLE applications ADD COLUMN priority TEXT DEFAULT 'medium'")
        db.commit()
    return db


@router.get("/applications")
async def list_applications(
    status: Optional[str] = Query(None),
    priority: Optional[str] = Query(None),
    sort: str = Query("date_applied"),
    order: str = Query("desc"),
    limit: int = Query(100),
):
    """List job applications with optional filtering and sorting."""
    db = _apps_db()
    where_clauses = []
    params = []

    if status:
        where_clauses.append("status = ?")
        params.append(status)
    if priority:
        where_clauses.append("priority = ?")
        params.append(priority)

    where_sql = (" WHERE " + " AND ".join(where_clauses)) if where_clauses else ""

    # Whitelist sortable columns
    allowed_sorts = {"date_applied", "company", "priority", "status", "role", "created_at", "updated_at"}
    sort_col = sort if sort in allowed_sorts else "date_applied"
    sort_order = "ASC" if order.lower() == "asc" else "DESC"

    # For priority sorting, use a CASE expression for logical order
    if sort_col == "priority":
        order_sql = f"""ORDER BY CASE priority
            WHEN 'critical' THEN 1
            WHEN 'high' THEN 2
            WHEN 'medium' THEN 3
            WHEN 'low' THEN 4
            WHEN 'skip' THEN 5
            ELSE 3 END {sort_order}"""
    else:
        order_sql = f"ORDER BY {sort_col} {sort_order}"

    safe_limit = min(max(1, limit), 500)
    query = f"SELECT * FROM applications {where_sql} {order_sql} LIMIT ?"  # noqa:SQL F-STRING — where_sql built from validated params
    params.append(safe_limit)

    rows = db.execute(query, params).fetchall()
    cols = [d[0] for d in db.execute("PRAGMA table_info(applications)").fetchall()]
    col_names = [c[1] for c in db.execute("PRAGMA table_info(applications)").fetchall()]

    apps = [dict(row) for row in rows]

    # Get summary counts
    total = db.execute("SELECT COUNT(*) FROM applications").fetchone()[0]
    by_status = {}
    for r in db.execute("SELECT status, COUNT(*) as cnt FROM applications GROUP BY status"):
        by_status[r[0]] = r[1]
    by_priority = {}
    for r in db.execute("SELECT COALESCE(priority, 'medium') as p, COUNT(*) as cnt FROM applications GROUP BY p"):
        by_priority[r[0]] = r[1]

    db.close()
    return {
        "applications": apps,
        "total": total,
        "filtered": len(apps),
        "summary": {"by_status": by_status, "by_priority": by_priority},
    }


@router.patch("/applications/{app_id}")
async def update_application(app_id: int, body: dict):
    """Update a job application (priority, status, notes, etc.)."""
    db = _apps_db()

    _APP_COLUMNS = frozenset({"priority", "status", "notes", "tags", "salary", "location", "updated_at"})
    col_updates = {}
    for key in ("priority", "status", "notes", "tags", "salary", "location"):
        if key in body:
            col_updates[key] = body[key]

    if not col_updates:
        db.close()
        return JSONResponse({"error": "No valid fields to update"}, status_code=400)

    col_updates["updated_at"] = datetime.utcnow().isoformat()
    params = []
    sql = _safe_update("applications", _APP_COLUMNS, col_updates, "id = ?", params)
    params.append(app_id)

    db.execute(sql, params)
    db.commit()

    # Return updated row
    row = db.execute("SELECT * FROM applications WHERE id = ?", (app_id,)).fetchone()
    db.close()
    if not row:
        return JSONResponse({"error": "Application not found"}, status_code=404)

    app = dict(row)

    # Auto-promote: when status moves to a reply/conversation state, create a project
    promote_statuses = {"replied", "active_conversation", "interview_scheduled"}
    if body.get("status") in promote_statuses:
        try:
            result = await _promote_application(app_id)
            app["promoted_project_id"] = result.get("project_id")
        except Exception as e:
            logger.warning("Auto-promote failed for application %s: %s", app_id, e)

    return {"status": "updated", "application": app}


async def _promote_application(app_id: int):
    """Promote a job application into its own project with interview pipeline phases."""
    apps_db = _apps_db()
    row = apps_db.execute("SELECT * FROM applications WHERE id = ?", (app_id,)).fetchone()
    if not row:
        apps_db.close()
        raise ValueError(f"Application {app_id} not found")
    app = dict(row)
    apps_db.close()

    db = _projects_db()

    # Check if already promoted (avoid duplicates)
    existing = db.execute(
        "SELECT id FROM projects WHERE category = 'job_opportunity' AND description LIKE ?",
        (f"%app_id:{app_id}%",)
    ).fetchone()
    if existing:
        db.close()
        return {"project_id": existing[0], "already_existed": True}

    company = app.get("company", "Unknown")
    role = app.get("role", "Unknown Role")
    now = datetime.utcnow().isoformat()

    # Create the project
    cur = db.execute(
        """INSERT INTO projects (name, description, status, priority, category, created_at, updated_at)
           VALUES (?, ?, 'active', ?, 'job_opportunity', ?, ?)""",
        (
            f"{company} — {role}",
            f"Promoted from application app_id:{app_id}. Platform: {app.get('platform', 'N/A')}. "
            f"Applied: {app.get('date_applied', 'N/A')}. Portal: {app.get('portal_url', 'N/A')}",
            app.get("priority", "medium"),
            now, now,
        )
    )
    project_id = cur.lastrowid

    # Standard interview pipeline phases and steps
    phases = [
        ("Initial Contact", "Company replied, conversation started", [
            ("Review company reply email", "Read their response, note key details"),
            ("Send acknowledgment/reply", "Professional response within 24h"),
            ("Research company deeply", "Glassdoor, LinkedIn, recent news, tech stack"),
            ("Review job requirements against resume", "Gap analysis, talking points"),
        ]),
        ("Interview Prep", "Preparing for scheduled interview", [
            ("Confirm interview date/time/format", "Calendar block, test video if remote"),
            ("Research interviewers on LinkedIn", "Find common ground, understand their role"),
            ("Prepare STAR stories", "5 relevant scenarios mapped to job requirements"),
            ("Technical prep", "Review relevant tools, frameworks, certifications"),
            ("Prepare questions to ask", "3-5 thoughtful questions showing research"),
        ]),
        ("Interview", "Active interview process", [
            ("Complete interview", "Notes during/after on questions asked"),
            ("Send thank-you email within 24h", "Reference specific conversation points"),
            ("Debrief — what went well, what didn't", "Honest self-assessment for next time"),
        ]),
        ("Follow-up", "Post-interview tracking", [
            ("Follow up if no response in 5 business days", "Polite check-in email"),
            ("Evaluate offer if received", "Salary, benefits, growth, culture fit"),
            ("Negotiate if appropriate", "Research market rates, prepare counter"),
            ("Accept or decline", "Professional response either way"),
        ]),
    ]

    for phase_order, (phase_name, phase_desc, steps) in enumerate(phases, 1):
        phase_cur = db.execute(
            """INSERT INTO project_phases (project_id, name, description, phase_order, status, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (project_id, phase_name, phase_desc, phase_order,
             "in_progress" if phase_order == 1 else "pending", now, now)
        )
        phase_id = phase_cur.lastrowid
        for step_order, (step_title, step_desc) in enumerate(steps, 1):
            db.execute(
                """INSERT INTO project_steps (phase_id, project_id, title, description, step_order, status, created_at, updated_at)
                   VALUES (?, ?, ?, ?, ?, 'pending', ?, ?)""",
                (phase_id, project_id, step_title, step_desc, step_order, now, now)
            )

    db.commit()

    # Update application status to active_conversation if not already
    apps_db2 = _apps_db()
    apps_db2.execute(
        "UPDATE applications SET status = 'active_conversation', updated_at = ? WHERE id = ?",
        (now, app_id)
    )
    apps_db2.commit()
    apps_db2.close()
    db.close()

    return {"project_id": project_id, "company": company, "role": role, "phases": len(phases)}


@router.post("/applications/{app_id}/promote")
async def promote_application(app_id: int):
    """Manually promote a job application into its own project with interview pipeline."""
    try:
        result = await _promote_application(app_id)
        return {"status": "promoted", **result}
    except ValueError as e:
        return JSONResponse({"error": str(e)}, status_code=404)


@router.get("/applications/{app_id}")
async def get_application(app_id: int):
    """Get a single application by ID."""
    db = _apps_db()
    row = db.execute("SELECT * FROM applications WHERE id = ?", (app_id,)).fetchone()
    db.close()
    if not row:
        return JSONResponse({"error": "Not found"}, status_code=404)
    return dict(row)


# ---------------------------------------------------------------------------
# Project Tracker — full project/phase/step management
# ---------------------------------------------------------------------------

def _projects_db():
    """Return a connection to the consolidated DB with project tables ensured."""
    import sqlite3 as _sql
    db = _sql.connect(str(aibrain_db.DB_PATH))
    db.row_factory = _sql.Row
    db.execute("PRAGMA journal_mode=WAL")
    db.executescript("""
        CREATE TABLE IF NOT EXISTS projects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            status TEXT DEFAULT 'active',
            priority TEXT DEFAULT 'medium',
            category TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS project_phases (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            description TEXT,
            phase_order INTEGER NOT NULL,
            status TEXT DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (project_id) REFERENCES projects(id)
        );
        CREATE TABLE IF NOT EXISTS project_steps (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            phase_id INTEGER NOT NULL,
            project_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            description TEXT,
            step_order INTEGER NOT NULL,
            status TEXT DEFAULT 'pending',
            blocker TEXT,
            notes TEXT,
            completed_at TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (phase_id) REFERENCES project_phases(id),
            FOREIGN KEY (project_id) REFERENCES projects(id)
        );
    """)
    return db


def _project_with_details(db, project_id):
    """Load a project with all phases and steps nested."""
    proj = db.execute("SELECT * FROM projects WHERE id = ?", (project_id,)).fetchone()
    if not proj:
        return None
    result = dict(proj)
    phases = db.execute(
        "SELECT * FROM project_phases WHERE project_id = ? ORDER BY phase_order",
        (project_id,),
    ).fetchall()
    result["phases"] = []
    total_steps = 0
    completed_steps = 0
    for ph in phases:
        phase_dict = dict(ph)
        steps = db.execute(
            "SELECT * FROM project_steps WHERE phase_id = ? ORDER BY step_order",
            (ph["id"],),
        ).fetchall()
        phase_dict["steps"] = [dict(s) for s in steps]
        total_steps += len(steps)
        completed_steps += sum(1 for s in steps if s["status"] == "completed")
        result["phases"].append(phase_dict)
    result["total_steps"] = total_steps
    result["completed_steps"] = completed_steps
    return result


@router.get("/projects/dashboard")
async def projects_dashboard():
    """Dashboard: summary stats, next actions, blocked items, recent completions."""
    db = _projects_db()
    now = datetime.utcnow()

    # Counts by status
    status_rows = db.execute(
        "SELECT status, COUNT(*) as cnt FROM projects GROUP BY status"
    ).fetchall()
    by_status = {r["status"]: r["cnt"] for r in status_rows}

    # Total steps done today
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0).isoformat()
    completed_today = db.execute(
        "SELECT COUNT(*) as cnt FROM project_steps WHERE status = 'completed' AND completed_at >= ?",
        (today_start,),
    ).fetchone()["cnt"]

    # Blocked items
    blocked = db.execute(
        """SELECT s.*, p.name as project_name, ph.name as phase_name
           FROM project_steps s
           JOIN projects p ON s.project_id = p.id
           JOIN project_phases ph ON s.phase_id = ph.id
           WHERE s.status = 'blocked' AND p.status = 'active'
           ORDER BY s.updated_at DESC LIMIT 20""",
    ).fetchall()

    # Next actionable step per active project (first incomplete step)
    next_actions = db.execute(
        """SELECT s.*, p.name as project_name, p.priority as project_priority,
                  p.category as project_category, ph.name as phase_name
           FROM project_steps s
           JOIN projects p ON s.project_id = p.id
           JOIN project_phases ph ON s.phase_id = ph.id
           WHERE s.status IN ('pending', 'in_progress') AND p.status = 'active'
           AND s.id = (
               SELECT MIN(s2.id) FROM project_steps s2
               JOIN project_phases ph2 ON s2.phase_id = ph2.id
               WHERE s2.project_id = p.id AND s2.status IN ('pending', 'in_progress')
               ORDER BY ph2.phase_order, s2.step_order LIMIT 1
           )
           ORDER BY
               CASE p.priority WHEN 'critical' THEN 0 WHEN 'high' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END,
               ph.phase_order, s.step_order
           LIMIT 10""",
    ).fetchall()

    # Recently completed (last 24h)
    yesterday = (now - timedelta(hours=24)).isoformat()
    recent = db.execute(
        """SELECT s.*, p.name as project_name, ph.name as phase_name
           FROM project_steps s
           JOIN projects p ON s.project_id = p.id
           JOIN project_phases ph ON s.phase_id = ph.id
           WHERE s.status = 'completed' AND s.completed_at >= ?
           ORDER BY s.completed_at DESC LIMIT 20""",
        (yesterday,),
    ).fetchall()

    db.close()
    return {
        "by_status": by_status,
        "completed_today": completed_today,
        "blocked": [dict(r) for r in blocked],
        "next_actions": [dict(r) for r in next_actions],
        "recent_completions": [dict(r) for r in recent],
    }


@router.get("/projects")
async def list_projects(
    status: Optional[str] = Query(None),
    priority: Optional[str] = Query(None),
    category: Optional[str] = Query(None),
    search: Optional[str] = Query(None),
):
    """List all projects with summary stats."""
    db = _projects_db()
    query = "SELECT * FROM projects WHERE 1=1"
    params = []
    if status:
        query += " AND status = ?"
        params.append(status)
    else:
        # By default, exclude archived projects and job_opportunity category
        query += " AND status != 'archived' AND category != 'job_opportunity'"
    if priority:
        query += " AND priority = ?"
        params.append(priority)
    if category:
        query += " AND category = ?"
        params.append(category)
    if search:
        query += " AND (name LIKE ? OR description LIKE ?)"
        params.extend([f"%{search}%", f"%{search}%"])
    query += " ORDER BY CASE priority WHEN 'critical' THEN 0 WHEN 'high' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END, updated_at DESC"

    rows = db.execute(query, params).fetchall()
    projects = []
    for row in rows:
        p = dict(row)
        # Attach step counts
        stats = db.execute(
            """SELECT COUNT(*) as total,
                      SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed
               FROM project_steps WHERE project_id = ?""",
            (row["id"],),
        ).fetchone()
        p["total_steps"] = stats["total"]
        p["completed_steps"] = stats["completed"] or 0
        # Next step preview
        nxt = db.execute(
            """SELECT s.title, ph.name as phase_name FROM project_steps s
               JOIN project_phases ph ON s.phase_id = ph.id
               WHERE s.project_id = ? AND s.status IN ('pending', 'in_progress')
               ORDER BY ph.phase_order, s.step_order LIMIT 1""",
            (row["id"],),
        ).fetchone()
        p["next_step"] = dict(nxt) if nxt else None
        projects.append(p)
    db.close()
    return {"projects": projects, "total": len(projects)}


@router.post("/projects")
async def create_project(body: dict):
    """Create a new project, optionally with phases and steps."""
    db = _projects_db()
    name = body.get("name")
    if not name:
        db.close()
        return JSONResponse({"error": "name is required"}, status_code=400)

    now = datetime.utcnow().isoformat()
    cur = db.execute(
        "INSERT INTO projects (name, description, status, priority, category, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (name, body.get("description", ""), body.get("status", "active"),
         body.get("priority", "medium"), body.get("category", ""), now, now),
    )
    project_id = cur.lastrowid

    # Bulk-create phases and steps if provided
    phases = body.get("phases", [])
    for i, phase in enumerate(phases):
        phase_cur = db.execute(
            "INSERT INTO project_phases (project_id, name, description, phase_order, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (project_id, phase.get("name", f"Phase {i+1}"), phase.get("description", ""),
             i + 1, phase.get("status", "pending"), now, now),
        )
        phase_id = phase_cur.lastrowid
        for j, step in enumerate(phase.get("steps", [])):
            step_title = step if isinstance(step, str) else step.get("title", f"Step {j+1}")
            step_desc = "" if isinstance(step, str) else step.get("description", "")
            step_status = "pending" if isinstance(step, str) else step.get("status", "pending")
            db.execute(
                "INSERT INTO project_steps (phase_id, project_id, title, description, step_order, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (phase_id, project_id, step_title, step_desc, j + 1, step_status, now, now),
            )

    db.commit()
    result = _project_with_details(db, project_id)
    db.close()

    if _notify_callback:
        import asyncio
        asyncio.ensure_future(_notify_callback("project", "created", {"id": project_id, "name": name}))

    return {"status": "created", "project": result}


@router.get("/projects/templates")
async def list_templates():
    """Return pre-built project templates."""
    templates = [
        {
            "id": "web-application",
            "name": "Web Application",
            "category": "product",
            "phases": [
                {"name": "Planning", "steps": ["Define requirements and scope", "Create wireframes/mockups", "Set up project repository", "Choose tech stack", "Define API contracts"]},
                {"name": "Frontend", "steps": ["Set up build tooling", "Build layout and navigation", "Implement core pages/views", "Add forms and validation", "Style and responsive design"]},
                {"name": "Backend", "steps": ["Set up server framework", "Design database schema", "Build API endpoints", "Add authentication", "Write data validation"]},
                {"name": "Testing", "steps": ["Write unit tests", "Integration testing", "End-to-end testing", "Performance testing"]},
                {"name": "Deployment", "steps": ["Set up CI/CD pipeline", "Configure hosting/infrastructure", "Deploy to staging", "Production deploy", "Post-launch monitoring"]},
            ],
        },
        {
            "id": "content-creation",
            "name": "Content Creation",
            "category": "content",
            "phases": [
                {"name": "Research", "steps": ["Identify target audience", "Research topic depth", "Competitive analysis", "Gather source material"]},
                {"name": "Outline", "steps": ["Define key points", "Structure sections", "Draft headlines/hooks", "Review outline"]},
                {"name": "Draft", "steps": ["Write first draft", "Add examples and data", "Create supporting visuals", "Internal review"]},
                {"name": "Edit", "steps": ["Content review and revision", "Proofread for grammar", "Fact-check all claims", "Get external feedback"]},
                {"name": "Publish", "steps": ["Format for platform", "Create promotional assets", "Schedule publication", "Promote across channels", "Monitor engagement"]},
            ],
        },
        {
            "id": "security-assessment",
            "name": "Security Assessment",
            "category": "infrastructure",
            "phases": [
                {"name": "Reconnaissance", "steps": ["Passive information gathering", "DNS enumeration", "Technology fingerprinting", "Social engineering research"]},
                {"name": "Scanning", "steps": ["Port scanning", "Service enumeration", "Vulnerability scanning", "Web application scanning"]},
                {"name": "Exploitation", "steps": ["Vulnerability validation", "Exploit development", "Privilege escalation", "Lateral movement"]},
                {"name": "Reporting", "steps": ["Document all findings", "Risk-rate vulnerabilities", "Create executive summary", "Prepare technical details"]},
                {"name": "Remediation", "steps": ["Prioritize fixes by risk", "Implement patches", "Validate remediation", "Update security policies"]},
            ],
        },
        {
            "id": "job-application",
            "name": "Job Application",
            "category": "job",
            "phases": [
                {"name": "Research", "steps": ["Research the company", "Understand role requirements", "Identify key contacts", "Review company culture"]},
                {"name": "Resume Tailoring", "steps": ["Update resume for role", "Write custom cover letter", "Prepare portfolio/samples", "Get resume reviewed"]},
                {"name": "Apply", "steps": ["Submit application", "Connect on LinkedIn", "Send follow-up email"]},
                {"name": "Follow Up", "steps": ["Week 1 follow-up", "Week 2 check-in", "Track application status"]},
                {"name": "Interview", "steps": ["Research interviewers", "Prepare STAR answers", "Technical prep", "Mock interview", "Send thank-you note"]},
            ],
        },
        {
            "id": "product-launch",
            "name": "Product Launch",
            "category": "product",
            "phases": [
                {"name": "MVP Build", "steps": ["Define core features", "Build minimum viable product", "Internal dogfooding", "Iterate on feedback"]},
                {"name": "Testing", "steps": ["Beta testing with users", "Bug fixes and polish", "Performance optimization", "Security review"]},
                {"name": "Docs", "steps": ["Write user documentation", "Create API reference", "Build getting-started guide", "Record tutorial videos"]},
                {"name": "Marketing", "steps": ["Create landing page", "Write launch announcement", "Prepare social media content", "Set up analytics"]},
                {"name": "Launch", "steps": ["Soft launch to beta users", "Public launch", "Monitor metrics", "Gather user feedback", "Plan next iteration"]},
            ],
        },
    ]
    return {"templates": templates}


@router.get("/projects/steps/all")
async def list_all_steps(status: Optional[str] = Query(None)):
    """Get ALL project steps across all projects, with project/phase names."""
    db = _projects_db()
    query = """
        SELECT ps.*, pp.name as phase_name, p.name as project_name, p.id as project_id
        FROM project_steps ps
        JOIN project_phases pp ON ps.phase_id = pp.id
        JOIN projects p ON pp.project_id = p.id
        WHERE p.status != 'archived'
    """
    params = []
    if status:
        query += " AND ps.status = ?"
        params.append(status)
    query += " ORDER BY CASE ps.status WHEN 'blocked' THEN 0 WHEN 'in_progress' THEN 1 WHEN 'pending' THEN 2 WHEN 'completed' THEN 3 END, p.name, pp.name, ps.id"
    rows = db.execute(query, params).fetchall()
    db.close()
    return {"steps": [dict(r) for r in rows], "total": len(rows)}


@router.get("/projects/{project_id}")
async def get_project(project_id: int):
    """Get a project with all phases and steps."""
    db = _projects_db()
    result = _project_with_details(db, project_id)
    db.close()
    if not result:
        return JSONResponse({"error": "Project not found"}, status_code=404)
    return result


@router.put("/projects/{project_id}")
async def update_project(project_id: int, body: dict):
    """Update project metadata."""
    _PROJECT_COLUMNS = frozenset({"name", "description", "status", "priority", "category", "updated_at"})
    db = _projects_db()
    col_updates = {}
    for key in ("name", "description", "status", "priority", "category"):
        if key in body:
            col_updates[key] = body[key]
    if not col_updates:
        db.close()
        return JSONResponse({"error": "No valid fields"}, status_code=400)
    col_updates["updated_at"] = datetime.utcnow().isoformat()
    params = []
    sql = _safe_update("projects", _PROJECT_COLUMNS, col_updates, "id = ?", params)
    params.append(project_id)
    db.execute(sql, params)
    db.commit()
    result = _project_with_details(db, project_id)
    db.close()
    if not result:
        return JSONResponse({"error": "Project not found"}, status_code=404)
    return {"status": "updated", "project": result}


@router.delete("/projects/{project_id}")
async def delete_project(project_id: int):
    """Soft delete — set status to archived."""
    db = _projects_db()
    now = datetime.utcnow().isoformat()
    db.execute("UPDATE projects SET status = 'archived', updated_at = ? WHERE id = ?", (now, project_id))
    db.commit()
    db.close()
    return {"status": "archived", "id": project_id}


@router.post("/projects/{project_id}/phases")
async def add_phase(project_id: int, body: dict):
    """Add a phase to a project."""
    db = _projects_db()
    proj = db.execute("SELECT id FROM projects WHERE id = ?", (project_id,)).fetchone()
    if not proj:
        db.close()
        return JSONResponse({"error": "Project not found"}, status_code=404)

    # Get next phase_order
    max_order = db.execute(
        "SELECT COALESCE(MAX(phase_order), 0) as mx FROM project_phases WHERE project_id = ?",
        (project_id,),
    ).fetchone()["mx"]

    now = datetime.utcnow().isoformat()
    cur = db.execute(
        "INSERT INTO project_phases (project_id, name, description, phase_order, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (project_id, body.get("name", "New Phase"), body.get("description", ""),
         body.get("phase_order", max_order + 1), body.get("status", "pending"), now, now),
    )
    phase_id = cur.lastrowid

    # Bulk-create steps if provided
    for j, step in enumerate(body.get("steps", [])):
        step_title = step if isinstance(step, str) else step.get("title", f"Step {j+1}")
        step_desc = "" if isinstance(step, str) else step.get("description", "")
        db.execute(
            "INSERT INTO project_steps (phase_id, project_id, title, description, step_order, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (phase_id, project_id, step_title, step_desc, j + 1, "pending", now, now),
        )

    db.commit()
    db.execute("UPDATE projects SET updated_at = ? WHERE id = ?", (now, project_id))
    db.commit()

    phase = db.execute("SELECT * FROM project_phases WHERE id = ?", (phase_id,)).fetchone()
    steps = db.execute("SELECT * FROM project_steps WHERE phase_id = ? ORDER BY step_order", (phase_id,)).fetchall()
    result = dict(phase)
    result["steps"] = [dict(s) for s in steps]
    db.close()
    return {"status": "created", "phase": result}


@router.put("/projects/phases/{phase_id}")
async def update_phase(phase_id: int, body: dict):
    """Update a phase."""
    _PHASE_COLUMNS = frozenset({"name", "description", "status", "phase_order", "updated_at"})
    db = _projects_db()
    col_updates = {}
    for key in ("name", "description", "status", "phase_order"):
        if key in body:
            col_updates[key] = body[key]
    if not col_updates:
        db.close()
        return JSONResponse({"error": "No valid fields"}, status_code=400)
    col_updates["updated_at"] = datetime.utcnow().isoformat()
    params = []
    sql = _safe_update("project_phases", _PHASE_COLUMNS, col_updates, "id = ?", params)
    params.append(phase_id)
    db.execute(sql, params)
    db.commit()
    phase = db.execute("SELECT * FROM project_phases WHERE id = ?", (phase_id,)).fetchone()
    db.close()
    if not phase:
        return JSONResponse({"error": "Phase not found"}, status_code=404)
    return {"status": "updated", "phase": dict(phase)}


@router.post("/projects/phases/{phase_id}/steps")
async def add_step(phase_id: int, body: dict):
    """Add a step to a phase."""
    db = _projects_db()
    phase = db.execute("SELECT * FROM project_phases WHERE id = ?", (phase_id,)).fetchone()
    if not phase:
        db.close()
        return JSONResponse({"error": "Phase not found"}, status_code=404)

    max_order = db.execute(
        "SELECT COALESCE(MAX(step_order), 0) as mx FROM project_steps WHERE phase_id = ?",
        (phase_id,),
    ).fetchone()["mx"]

    now = datetime.utcnow().isoformat()
    cur = db.execute(
        "INSERT INTO project_steps (phase_id, project_id, title, description, step_order, status, blocker, notes, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (phase_id, phase["project_id"], body.get("title", "New Step"),
         body.get("description", ""), body.get("step_order", max_order + 1),
         body.get("status", "pending"), body.get("blocker", ""), body.get("notes", ""), now, now),
    )
    db.commit()
    db.execute("UPDATE projects SET updated_at = ? WHERE id = ?", (now, phase["project_id"]))
    db.commit()
    step = db.execute("SELECT * FROM project_steps WHERE id = ?", (cur.lastrowid,)).fetchone()
    db.close()
    return {"status": "created", "step": dict(step)}


@router.put("/projects/steps/{step_id}")
async def update_step(step_id: int, body: dict):
    """Update a step (status, notes, blocker, etc.)."""
    _STEP_COLUMNS = frozenset({"title", "description", "status", "step_order", "blocker", "notes", "completed_at", "updated_at"})
    db = _projects_db()
    col_updates = {}
    for key in ("title", "description", "status", "step_order", "blocker", "notes"):
        if key in body:
            col_updates[key] = body[key]
    if not col_updates:
        db.close()
        return JSONResponse({"error": "No valid fields"}, status_code=400)

    now = datetime.utcnow().isoformat()
    if body.get("status") == "completed":
        col_updates["completed_at"] = now
    elif body.get("status") and body["status"] != "completed":
        col_updates["completed_at"] = None  # SQLite treats None as NULL
    col_updates["updated_at"] = now
    params = []
    sql = _safe_update("project_steps", _STEP_COLUMNS, col_updates, "id = ?", params)
    params.append(step_id)
    db.execute(sql, params)
    db.commit()

    step = db.execute("SELECT * FROM project_steps WHERE id = ?", (step_id,)).fetchone()
    if step:
        db.execute("UPDATE projects SET updated_at = ? WHERE id = ?", (now, step["project_id"]))
        db.commit()

        # Auto-update phase status
        phase_id = step["phase_id"]
        phase_steps = db.execute(
            "SELECT status FROM project_steps WHERE phase_id = ?", (phase_id,)
        ).fetchall()
        statuses = [s["status"] for s in phase_steps]
        if all(s == "completed" for s in statuses):
            db.execute("UPDATE project_phases SET status = 'completed', updated_at = ? WHERE id = ?", (now, phase_id))
        elif any(s in ("in_progress", "completed") for s in statuses):
            db.execute("UPDATE project_phases SET status = 'in_progress', updated_at = ? WHERE id = ?", (now, phase_id))
        db.commit()

    db.close()
    if not step:
        return JSONResponse({"error": "Step not found"}, status_code=404)
    return {"status": "updated", "step": dict(step)}


@router.patch("/projects/steps/{step_id}")
async def update_step(step_id: int, body: dict):
    """Update a step's status, notes, or other fields."""
    db = _projects_db()
    step = db.execute("SELECT * FROM project_steps WHERE id = ?", (step_id,)).fetchone()
    if not step:
        db.close()
        return JSONResponse({"error": "Step not found"}, status_code=404)

    _STEP_PATCH_COLUMNS = frozenset({"status", "notes", "title", "blocker", "completed_at", "updated_at"})
    now = datetime.utcnow().isoformat()
    col_updates = {}

    for field in ("status", "notes", "title", "blocker"):
        if field in body:
            col_updates[field] = body[field]

    if body.get("status") == "completed":
        col_updates["completed_at"] = now
    elif body.get("status") in ("pending", "in_progress", "blocked"):
        col_updates["completed_at"] = None  # SQLite treats None as NULL

    if not col_updates:
        db.close()
        return {"status": "no_changes"}

    col_updates["updated_at"] = now
    params = []
    sql = _safe_update("project_steps", _STEP_PATCH_COLUMNS, col_updates, "id = ?", params)
    params.append(step_id)

    db.execute(sql, params)
    db.commit()
    db.close()
    return {"status": "updated", "step_id": step_id}


@router.delete("/projects/steps/{step_id}")
async def delete_step(step_id: int):
    """Delete a project step."""
    db = _projects_db()
    step = db.execute("SELECT id FROM project_steps WHERE id = ?", (step_id,)).fetchone()
    if not step:
        db.close()
        return JSONResponse({"error": "Step not found"}, status_code=404)

    db.execute("DELETE FROM project_steps WHERE id = ?", (step_id,))
    # Clean up entity_links
    db.execute("DELETE FROM entity_links WHERE (source_type = 'project_step' AND source_id = ?) OR (target_type = 'project_step' AND target_id = ?)", (step_id, step_id))
    db.commit()
    db.close()
    return {"status": "deleted", "step_id": step_id}


@router.patch("/projects/steps/{step_id}/toggle")
async def toggle_step(step_id: int):
    """Quick toggle step between completed and pending."""
    db = _projects_db()
    step = db.execute("SELECT * FROM project_steps WHERE id = ?", (step_id,)).fetchone()
    if not step:
        db.close()
        return JSONResponse({"error": "Step not found"}, status_code=404)

    now = datetime.utcnow().isoformat()
    new_status = "pending" if step["status"] == "completed" else "completed"
    completed_at = now if new_status == "completed" else None

    db.execute(
        "UPDATE project_steps SET status = ?, completed_at = ?, updated_at = ? WHERE id = ?",
        (new_status, completed_at, now, step_id),
    )
    db.commit()

    # Auto-update phase status
    phase_steps = db.execute(
        "SELECT status FROM project_steps WHERE phase_id = ?", (step["phase_id"],)
    ).fetchall()
    statuses = [s["status"] for s in phase_steps]
    if all(s == "completed" for s in statuses):
        db.execute("UPDATE project_phases SET status = 'completed', updated_at = ? WHERE id = ?", (now, step["phase_id"]))
    elif any(s in ("in_progress", "completed") for s in statuses):
        db.execute("UPDATE project_phases SET status = 'in_progress', updated_at = ? WHERE id = ?", (now, step["phase_id"]))
    else:
        db.execute("UPDATE project_phases SET status = 'pending', updated_at = ? WHERE id = ?", (now, step["phase_id"]))
    db.commit()

    db.execute("UPDATE projects SET updated_at = ? WHERE id = ?", (now, step["project_id"]))
    db.commit()
    db.close()

    return {"status": "toggled", "step_id": step_id, "new_status": new_status}


@router.post("/projects/{project_id}/import")
async def import_project_template(project_id: int, body: dict):
    """Import phases/steps from a markdown or JSON template into an existing project."""
    db = _projects_db()
    proj = db.execute("SELECT id FROM projects WHERE id = ?", (project_id,)).fetchone()
    if not proj:
        db.close()
        return JSONResponse({"error": "Project not found"}, status_code=404)

    now = datetime.utcnow().isoformat()
    phases = body.get("phases", [])
    max_order = db.execute(
        "SELECT COALESCE(MAX(phase_order), 0) as mx FROM project_phases WHERE project_id = ?",
        (project_id,),
    ).fetchone()["mx"]

    created_phases = 0
    created_steps = 0
    for i, phase in enumerate(phases):
        phase_cur = db.execute(
            "INSERT INTO project_phases (project_id, name, description, phase_order, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (project_id, phase.get("name", f"Phase {i+1}"), phase.get("description", ""),
             max_order + i + 1, "pending", now, now),
        )
        created_phases += 1
        phase_id = phase_cur.lastrowid
        for j, step in enumerate(phase.get("steps", [])):
            step_title = step if isinstance(step, str) else step.get("title", f"Step {j+1}")
            step_desc = "" if isinstance(step, str) else step.get("description", "")
            db.execute(
                "INSERT INTO project_steps (phase_id, project_id, title, description, step_order, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (phase_id, project_id, step_title, step_desc, j + 1, "pending", now, now),
            )
            created_steps += 1

    db.commit()
    db.execute("UPDATE projects SET updated_at = ? WHERE id = ?", (now, project_id))
    db.commit()
    result = _project_with_details(db, project_id)
    db.close()
    return {"status": "imported", "created_phases": created_phases, "created_steps": created_steps, "project": result}


@router.post("/projects/seed")
async def seed_projects_from_action_plan():
    """Import projects from project_action_plan.md. Only runs if no projects exist."""
    db = _projects_db()
    count = db.execute("SELECT COUNT(*) as cnt FROM projects").fetchone()["cnt"]
    if count > 0:
        db.close()
        return {"status": "skipped", "message": f"Already have {count} projects"}

    now = datetime.utcnow().isoformat()

    # Example seed projects — users can customize these
    seed_projects = [
        {
            "name": "AIBrain Setup",
            "description": "Get your brain configured, workflows enabled, and integrations connected",
            "status": "active",
            "priority": "critical",
            "category": "product",
            "phases": [
                {"name": "Phase 1 — Core Setup", "status": "in_progress", "steps": [
                    {"title": "Run setup wizard and configure API keys", "status": "pending"},
                    {"title": "Enable desired workflows", "status": "pending"},
                    {"title": "Connect email integration (optional)", "status": "pending"},
                    {"title": "Connect Telegram notifications (optional)", "status": "pending"},
                ]},
                {"name": "Phase 2 — Brain Training", "steps": [
                    {"title": "Import existing knowledge (brain import)", "status": "pending"},
                    {"title": "Install brain packs for your domains", "status": "pending"},
                    {"title": "Verify memory consolidation is running", "status": "pending"},
                ]},
            ],
        },
        {
            "name": "Workflow Automation",
            "description": "Set up automated workflows for your daily needs",
            "status": "active",
            "priority": "medium",
            "category": "product",
            "phases": [
                {"name": "Productivity", "steps": [
                    {"title": "Configure morning briefing schedule", "status": "pending"},
                    {"title": "Set up email-to-task workflow", "status": "pending"},
                    {"title": "Enable daily planner", "status": "pending"},
                ]},
                {"name": "Monitoring", "steps": [
                    {"title": "Enable cron health checks", "status": "pending"},
                    {"title": "Set up database backups", "status": "pending"},
                ]},
            ],
        },
    ]

    for p in seed_projects:
        cur = db.execute(
            "INSERT INTO projects (name, description, status, priority, category, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (p["name"], p.get("description", ""), p.get("status", "active"),
             p.get("priority", "medium"), p.get("category", ""), now, now),
        )
        pid = cur.lastrowid
        for i, phase in enumerate(p.get("phases", [])):
            pcur = db.execute(
                "INSERT INTO project_phases (project_id, name, description, phase_order, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (pid, phase["name"], phase.get("description", ""), i + 1,
                 phase.get("status", "pending"), now, now),
            )
            phid = pcur.lastrowid
            for j, step in enumerate(phase.get("steps", [])):
                st = step if isinstance(step, str) else step.get("title", "")
                ss = "pending" if isinstance(step, str) else step.get("status", "pending")
                db.execute(
                    "INSERT INTO project_steps (phase_id, project_id, title, description, step_order, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    (phid, pid, st, "", j + 1, ss, now, now),
                )

    db.commit()
    total_projects = db.execute("SELECT COUNT(*) as cnt FROM projects").fetchone()["cnt"]
    total_steps = db.execute("SELECT COUNT(*) as cnt FROM project_steps").fetchone()["cnt"]
    db.close()
    return {"status": "seeded", "projects": total_projects, "steps": total_steps}


# ---------------------------------------------------------------------------
# Entity Links — universal relationship graph (Agent Mind architecture)
# Connects projects, workflows, tasks, memories, skills, agents, integrations
# ---------------------------------------------------------------------------

VALID_ENTITY_TYPES = {"project", "workflow", "task", "memory", "skill", "agent", "integration", "approval"}
VALID_RELATIONSHIPS = {"contains", "uses", "generates", "belongs_to", "relates_to", "depends_on", "triggers", "owned_by"}


@router.get("/links")
async def get_entity_links(
    source_type: Optional[str] = Query(None),
    source_id: Optional[int] = Query(None),
    target_type: Optional[str] = Query(None),
    target_id: Optional[int] = Query(None),
    relationship: Optional[str] = Query(None),
    entity_type: Optional[str] = Query(None, description="Get all links for this entity type+id"),
    entity_id: Optional[int] = Query(None),
):
    """Query entity links. Use entity_type+entity_id to get all links for an entity (both directions)."""
    db = _projects_db()

    if entity_type and entity_id:
        # Get all links where this entity is source OR target
        rows = db.execute(
            """SELECT * FROM entity_links
               WHERE (source_type = ? AND source_id = ?) OR (target_type = ? AND target_id = ?)
               ORDER BY relationship, created_at DESC""",
            (entity_type, entity_id, entity_type, entity_id),
        ).fetchall()
    else:
        query = "SELECT * FROM entity_links WHERE 1=1"
        params = []
        if source_type:
            query += " AND source_type = ?"
            params.append(source_type)
        if source_id is not None:
            query += " AND source_id = ?"
            params.append(source_id)
        if target_type:
            query += " AND target_type = ?"
            params.append(target_type)
        if target_id is not None:
            query += " AND target_id = ?"
            params.append(target_id)
        if relationship:
            query += " AND relationship = ?"
            params.append(relationship)
        query += " ORDER BY created_at DESC LIMIT 500"
        rows = db.execute(query, params).fetchall()

    links = [dict(r) for r in rows]
    db.close()
    return {"links": links, "count": len(links)}


@router.post("/links")
async def create_entity_link(body: dict):
    """Create a link between two entities."""
    source_type = body.get("source_type", "")
    source_id = body.get("source_id")
    target_type = body.get("target_type", "")
    target_id = body.get("target_id")
    relationship = body.get("relationship", "relates_to")

    if source_type not in VALID_ENTITY_TYPES or target_type not in VALID_ENTITY_TYPES:
        return JSONResponse({"error": f"Invalid entity type. Valid: {sorted(VALID_ENTITY_TYPES)}"}, status_code=400)
    if relationship not in VALID_RELATIONSHIPS:
        return JSONResponse({"error": f"Invalid relationship. Valid: {sorted(VALID_RELATIONSHIPS)}"}, status_code=400)
    if source_id is None or target_id is None:
        return JSONResponse({"error": "source_id and target_id required"}, status_code=400)

    db = _projects_db()
    try:
        db.execute(
            """INSERT OR IGNORE INTO entity_links (source_type, source_id, target_type, target_id, relationship, metadata)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (source_type, source_id, target_type, target_id, relationship, body.get("metadata")),
        )
        db.commit()
    except Exception as e:
        db.close()
        logger.error("Entity link creation failed: %s", e, exc_info=True)
        return JSONResponse({"error": "Internal server error"}, status_code=500)
    db.close()
    return {"status": "created"}


@router.delete("/links/{link_id}")
async def delete_entity_link(link_id: int):
    """Remove a link."""
    db = _projects_db()
    db.execute("DELETE FROM entity_links WHERE id = ?", (link_id,))
    db.commit()
    db.close()
    return {"status": "deleted"}


@router.get("/links/graph")
async def entity_link_graph(
    center_type: Optional[str] = Query(None),
    center_id: Optional[int] = Query(None),
    depth: int = Query(1, ge=1, le=3),
):
    """Get a graph of connected entities, optionally centered on one entity.
    Returns nodes and edges for visualization."""
    db = _projects_db()

    if center_type and center_id is not None:
        # BFS from center entity
        visited = set()
        queue = [(center_type, center_id, 0)]
        edges = []
        while queue:
            etype, eid, d = queue.pop(0)
            key = (etype, eid)
            if key in visited:
                continue
            visited.add(key)
            if d >= depth:
                continue
            rows = db.execute(
                """SELECT * FROM entity_links
                   WHERE (source_type = ? AND source_id = ?) OR (target_type = ? AND target_id = ?)""",
                (etype, eid, etype, eid),
            ).fetchall()
            for r in rows:
                edge = dict(r)
                edges.append(edge)
                # Queue the other end
                if (r["source_type"], r["source_id"]) == key:  # noqa:PLAIN SECRET COMPARISON — tuple comparison, not secret
                    queue.append((r["target_type"], r["target_id"], d + 1))
                else:
                    queue.append((r["source_type"], r["source_id"], d + 1))
    else:
        # All links (limited)
        rows = db.execute("SELECT * FROM entity_links LIMIT 1000").fetchall()
        edges = [dict(r) for r in rows]
        visited = set()
        for e in edges:
            visited.add((e["source_type"], e["source_id"]))
            visited.add((e["target_type"], e["target_id"]))

    # Build nodes with names
    nodes = []
    for etype, eid in visited:
        name = _resolve_entity_name(db, etype, eid)
        nodes.append({"type": etype, "id": eid, "name": name})

    db.close()

    # Dedupe edges
    seen_edges = set()
    unique_edges = []
    for e in edges:
        key = (e["source_type"], e["source_id"], e["target_type"], e["target_id"], e["relationship"])
        if key not in seen_edges:
            seen_edges.add(key)
            unique_edges.append(e)

    return {"nodes": nodes, "edges": unique_edges}


def _resolve_entity_name(db, entity_type, entity_id):
    """Look up a human-readable name for an entity."""
    table_map = {
        "project": ("projects", "name"),
        "workflow": ("project_phases", "name"),
        "task": ("project_steps", "title"),
        "memory": ("memories", "name"),
        "skill": ("skills", "name"),
        "approval": ("approvals", "title"),
    }
    if entity_type in table_map:
        table, col = table_map[entity_type]
        row = db.execute(f"SELECT {col} FROM {table} WHERE id = ?", (entity_id,)).fetchone()  # noqa:SQL F-STRING
        if row:
            return row[0]
    return f"{entity_type}:{entity_id}"


@router.get("/links/context/{entity_type}/{entity_id}")
async def get_entity_context(entity_type: str, entity_id: int):
    """Get full context for an entity — all its connections grouped by type and relationship.
    This is the 'drill-down' view: what project does this task belong to? What workflows use this skill?"""
    db = _projects_db()

    rows = db.execute(
        """SELECT * FROM entity_links
           WHERE (source_type = ? AND source_id = ?) OR (target_type = ? AND target_id = ?)
           ORDER BY relationship""",
        (entity_type, entity_id, entity_type, entity_id),
    ).fetchall()

    # Group connections
    connections = {}
    for r in rows:
        if r["source_type"] == entity_type and r["source_id"] == entity_id:
            # This entity is the source
            other_type = r["target_type"]
            other_id = r["target_id"]
            rel = r["relationship"]
        else:
            # This entity is the target — reverse the relationship
            other_type = r["source_type"]
            other_id = r["source_id"]
            rel = _reverse_relationship(r["relationship"])

        name = _resolve_entity_name(db, other_type, other_id)
        key = f"{rel}:{other_type}"
        if key not in connections:
            connections[key] = {"relationship": rel, "entity_type": other_type, "items": []}
        connections[key]["items"].append({"id": other_id, "name": name})

    # Also get self info
    self_name = _resolve_entity_name(db, entity_type, entity_id)
    db.close()

    return {
        "entity": {"type": entity_type, "id": entity_id, "name": self_name},
        "connections": list(connections.values()),
        "total_links": len(rows),
    }


def _reverse_relationship(rel):
    """Reverse a relationship for when traversing from target to source."""
    reverses = {
        "contains": "part_of",
        "uses": "used_by",
        "generates": "generated_by",
        "belongs_to": "owns",
        "triggers": "triggered_by",
        "owned_by": "owns",
        "depends_on": "depended_on_by",
    }
    return reverses.get(rel, rel)


# ---------------------------------------------------------------------------
# Evolution Engine — M2.7-inspired self-improvement loop
# ---------------------------------------------------------------------------

@router.get("/evolution/dashboard")
async def evolution_dashboard():
    """Get evolution system overview — patterns, experiments, success trends."""
    return evolution_engine.get_evolution_dashboard(aibrain_db.DB_PATH)


@router.post("/evolution/cycle")
async def run_evolution_cycle(body: dict = None):
    """Run a full evolution cycle: analyze → detect → hypothesize → decide."""
    body = body or {}
    agent = body.get("agent", os.getenv("AGENT_ID", "agent"))
    result = evolution_engine.run_evolution_cycle(aibrain_db.DB_PATH, agent=agent)
    return {"status": "cycle_complete", **result}


@router.post("/evolution/outcomes")
async def record_evolution_outcome(body: dict):
    """Record an action outcome for evolution tracking."""
    required = ["source", "action", "result"]
    for field in required:
        if field not in body:
            return JSONResponse({"error": f"Missing required field: {field}"}, status_code=400)
    if body["result"] not in ("success", "failure", "partial"):
        return JSONResponse({"error": "result must be success/failure/partial"}, status_code=400)

    outcome_id = evolution_engine.record_outcome(
        aibrain_db.DB_PATH,
        source=body["source"],
        action=body["action"],
        result=body["result"],
        source_id=body.get("source_id"),
        details=body.get("details"),
        failure_reason=body.get("failure_reason"),
        duration_seconds=body.get("duration_seconds"),
    )
    return {"status": "recorded", "outcome_id": outcome_id}


@router.get("/evolution/outcomes")
async def list_evolution_outcomes(
    source: Optional[str] = Query(None),
    result: Optional[str] = Query(None),
    hours: int = Query(24),
    limit: int = Query(50),
):
    """List recent evolution outcomes."""
    db = evolution_engine.get_evolution_db(aibrain_db.DB_PATH)
    cutoff = (datetime.utcnow() - timedelta(hours=hours)).isoformat()
    where = ["created_at > ?"]
    params = [cutoff]
    if source:
        where.append("source = ?")
        params.append(source)
    if result:
        where.append("result = ?")
        params.append(result)
    safe_limit = min(max(1, limit), 200)
    params.append(safe_limit)
    rows = db.execute(
        f"SELECT * FROM evolution_outcomes WHERE {' AND '.join(where)} ORDER BY created_at DESC LIMIT ?",
        params
    ).fetchall()
    db.close()
    return {"outcomes": [dict(r) for r in rows]}


@router.get("/evolution/patterns")
async def list_evolution_patterns(status: str = Query("active")):
    """List detected failure patterns."""
    db = evolution_engine.get_evolution_db(aibrain_db.DB_PATH)
    rows = db.execute(
        "SELECT * FROM evolution_patterns WHERE status = ? ORDER BY frequency DESC, severity DESC",
        (status,)
    ).fetchall()
    db.close()
    return {"patterns": [dict(r) for r in rows]}


@router.post("/evolution/hypotheses")
async def create_evolution_hypothesis(body: dict):
    """Propose an improvement hypothesis."""
    required = ["hypothesis", "change_type"]
    for field in required:
        if field not in body:
            return JSONResponse({"error": f"Missing required field: {field}"}, status_code=400)

    hyp_id = evolution_engine.propose_hypothesis(
        aibrain_db.DB_PATH,
        pattern_id=body.get("pattern_id"),
        hypothesis=body["hypothesis"],
        change_type=body["change_type"],
        target=body.get("target"),
        proposed_change=body.get("proposed_change"),
        impact_score=body.get("impact_score", 0.5),
        confidence=body.get("confidence", 0.5),
    )
    return {"status": "proposed", "hypothesis_id": hyp_id}


@router.get("/evolution/hypotheses")
async def list_evolution_hypotheses(status: str = Query("proposed"), limit: int = Query(10)):
    """List hypotheses, sorted by priority."""
    from security import safe_limit as _safe_limit
    limit = _safe_limit(limit, 50)
    if status == "top":
        return {"hypotheses": evolution_engine.get_top_hypotheses(aibrain_db.DB_PATH, limit=limit)}
    db = evolution_engine.get_evolution_db(aibrain_db.DB_PATH)
    safe_limit = limit
    rows = db.execute(
        """SELECT h.*, p.pattern, p.frequency
           FROM evolution_hypotheses h
           LEFT JOIN evolution_patterns p ON h.pattern_id = p.id
           WHERE h.status = ?
           ORDER BY h.priority DESC LIMIT ?""",
        (status, safe_limit)
    ).fetchall()
    db.close()
    return {"hypotheses": [dict(r) for r in rows]}


@router.post("/evolution/experiments")
async def start_evolution_experiment(body: dict):
    """Start an experiment for a hypothesis."""
    hypothesis_id = body.get("hypothesis_id")
    if not hypothesis_id:
        return JSONResponse({"error": "hypothesis_id required"}, status_code=400)

    exp_id = evolution_engine.start_experiment(
        aibrain_db.DB_PATH,
        hypothesis_id=hypothesis_id,
        baseline_metrics=body.get("baseline_metrics", {}),
        runs_target=body.get("runs_target", 5),
    )
    return {"status": "started", "experiment_id": exp_id}


@router.post("/evolution/experiments/{exp_id}/run")
async def record_experiment_run(exp_id: int):
    """Record a completed run for an experiment."""
    result = evolution_engine.record_experiment_run(aibrain_db.DB_PATH, exp_id)
    if not result:
        return JSONResponse({"error": "Experiment not found"}, status_code=404)
    return result


@router.post("/evolution/experiments/{exp_id}/decide")
async def decide_evolution_experiment(exp_id: int, body: dict):
    """Decide whether to keep or revert an experiment."""
    decision = body.get("decision")
    if decision not in ("keep", "revert", "extend"):
        return JSONResponse({"error": "decision must be keep/revert/extend"}, status_code=400)

    result = evolution_engine.decide_experiment(
        aibrain_db.DB_PATH,
        experiment_id=exp_id,
        experiment_metrics=body.get("experiment_metrics", {}),
        decision=decision,
        reason=body.get("reason"),
    )
    return result


@router.get("/evolution/experiments")
async def list_evolution_experiments(active_only: bool = Query(True)):
    """List experiments."""
    db = evolution_engine.get_evolution_db(aibrain_db.DB_PATH)
    if active_only:
        rows = db.execute(
            """SELECT e.*, h.hypothesis, h.change_type, h.target
               FROM evolution_experiments e
               JOIN evolution_hypotheses h ON e.hypothesis_id = h.id
               WHERE e.decision IS NULL
               ORDER BY e.started_at DESC"""
        ).fetchall()
    else:
        rows = db.execute(
            """SELECT e.*, h.hypothesis, h.change_type, h.target
               FROM evolution_experiments e
               JOIN evolution_hypotheses h ON e.hypothesis_id = h.id
               ORDER BY e.started_at DESC LIMIT 50"""
        ).fetchall()
    db.close()
    return {"experiments": [dict(r) for r in rows]}


# --- Self-Criticism endpoints ---

@router.post("/evolution/critiques")
async def create_evolution_critique(body: dict):
    """Record a self-criticism entry."""
    required = ["scope", "subject", "observation", "criticism"]
    for field in required:
        if field not in body:
            return JSONResponse({"error": f"Missing: {field}"}, status_code=400)
    cid = evolution_engine.record_critique(
        aibrain_db.DB_PATH,
        scope=body["scope"], subject=body["subject"],
        observation=body["observation"], criticism=body["criticism"],
        suggested_fix=body.get("suggested_fix"),
        severity=body.get("severity", "medium"),
        cycle_id=body.get("cycle_id"),
    )
    return {"status": "recorded", "critique_id": cid}


@router.get("/evolution/critiques")
async def list_evolution_critiques(addressed: bool = Query(False), limit: int = Query(20)):
    """List critiques, default unaddressed."""
    from security import safe_limit
    limit = safe_limit(limit, 100)
    if not addressed:
        return {"critiques": evolution_engine.get_unaddressed_critiques(aibrain_db.DB_PATH, limit)}
    db = evolution_engine.get_evolution_db(aibrain_db.DB_PATH)
    rows = db.execute(
        "SELECT * FROM evolution_critiques ORDER BY created_at DESC LIMIT ?",
        (limit,)
    ).fetchall()
    db.close()
    return {"critiques": [dict(r) for r in rows]}


@router.patch("/evolution/critiques/{critique_id}/address")
async def address_evolution_critique(critique_id: int, body: dict):
    """Mark a critique as addressed."""
    addressed_by = body.get("addressed_by", "manual")
    evolution_engine.address_critique(aibrain_db.DB_PATH, critique_id, addressed_by)
    return {"status": "addressed", "critique_id": critique_id}


# --- Metric Tracking endpoints ---

@router.post("/evolution/metrics")
async def record_evolution_metric(body: dict):
    """Record a metric data point."""
    if "metric_name" not in body or "metric_value" not in body:
        return JSONResponse({"error": "metric_name and metric_value required"}, status_code=400)
    evolution_engine.record_metric(
        aibrain_db.DB_PATH,
        metric_name=body["metric_name"],
        metric_value=body["metric_value"],
        source=body.get("source"),
        period=body.get("period", "snapshot"),
    )
    return {"status": "recorded"}


@router.get("/evolution/metrics/{metric_name}")
async def get_evolution_metric_trend(metric_name: str, days: int = Query(7)):
    """Get trend data for a specific metric."""
    return {"metric": metric_name, "trend": evolution_engine.get_metric_trend(aibrain_db.DB_PATH, metric_name, days)}


# --- Parameter Search endpoints ---

@router.post("/evolution/parameters")
async def start_parameter_search(body: dict):
    """Start a systematic parameter optimization search."""
    required = ["parameter_name", "system", "current_value", "tested_value"]
    for field in required:
        if field not in body:
            return JSONResponse({"error": f"Missing: {field}"}, status_code=400)
    sid = evolution_engine.start_parameter_search(
        aibrain_db.DB_PATH,
        parameter_name=body["parameter_name"],
        system=body["system"],
        current_value=body["current_value"],
        tested_value=body["tested_value"],
        baseline_result=body.get("baseline_result"),
    )
    return {"status": "started", "search_id": sid}


@router.get("/evolution/parameters")
async def list_parameter_searches(system: Optional[str] = Query(None), active_only: bool = Query(True)):
    """List parameter optimization searches."""
    return {"searches": evolution_engine.get_parameter_searches(aibrain_db.DB_PATH, system, active_only)}


@router.patch("/evolution/parameters/{search_id}")
async def update_parameter_search_endpoint(search_id: int, body: dict):
    """Update a parameter search with test results."""
    if "test_result" not in body:
        return JSONResponse({"error": "test_result required"}, status_code=400)
    evolution_engine.update_parameter_search(
        aibrain_db.DB_PATH, search_id,
        test_result=body["test_result"],
        runs=body.get("runs"),
        decision=body.get("decision"),
    )
    return {"status": "updated"}


# --- Loop Detection endpoint ---

@router.get("/evolution/loops")
async def detect_evolution_loops(window_minutes: int = Query(30), threshold: int = Query(3)):
    """Detect if any actions are stuck in repetition loops."""
    loops = evolution_engine.detect_loops(aibrain_db.DB_PATH, window_minutes, threshold)
    return {"loops": loops, "stuck": len(loops) > 0}


# --- Positive Pattern endpoints ---

@router.get("/evolution/positive-patterns")
async def list_positive_patterns(
    strength: Optional[str] = Query(None),
    scale: Optional[str] = Query(None),
    limit: int = Query(20),
):
    """List positive patterns — what's working and why."""
    from security import safe_limit
    limit = safe_limit(limit, 200)
    return {"patterns": evolution_engine.get_positive_patterns(
        aibrain_db.DB_PATH, strength, scale, limit)}


@router.post("/evolution/positive-patterns")
async def create_positive_pattern(body: dict):
    """Manually record a positive pattern / principle."""
    required = ["pattern", "principle", "source_domain"]
    for f in required:
        if f not in body:
            return JSONResponse({"error": f"Missing: {f}"}, status_code=400)
    pid = evolution_engine.record_positive_pattern(
        aibrain_db.DB_PATH,
        pattern=body["pattern"], principle=body["principle"],
        source_domain=body["source_domain"],
        scale=body.get("scale", "micro"),
        strength=body.get("strength", "emerging"),
    )
    return {"status": "recorded", "pattern_id": pid}


@router.patch("/evolution/positive-patterns/{pattern_id}")
async def update_positive_pattern_endpoint(pattern_id: int, body: dict):
    """Update a positive pattern's principle, scale, or strength."""
    evolution_engine.update_positive_pattern(
        aibrain_db.DB_PATH, pattern_id,
        principle=body.get("principle"),
        scale=body.get("scale"),
        strength=body.get("strength"),
    )
    return {"status": "updated", "pattern_id": pattern_id}


@router.post("/evolution/positive-patterns/detect")
async def detect_positive_patterns_endpoint(body: dict = None):
    """Run positive pattern detection on recent outcomes."""
    body = body or {}
    result = evolution_engine.detect_positive_patterns(
        aibrain_db.DB_PATH, lookback_hours=body.get("lookback_hours", 168))
    return result


# --- Replication endpoints ---

@router.post("/evolution/replications")
async def propose_replication(body: dict):
    """Propose replicating a positive pattern into a new domain."""
    required = ["pattern_id", "target_domain", "adaptation"]
    for f in required:
        if f not in body:
            return JSONResponse({"error": f"Missing: {f}"}, status_code=400)
    rid = evolution_engine.propose_replication(
        aibrain_db.DB_PATH,
        pattern_id=body["pattern_id"],
        target_domain=body["target_domain"],
        adaptation=body["adaptation"],
        target_scale=body.get("target_scale"),
        implementation=body.get("implementation"),
    )
    return {"status": "proposed", "replication_id": rid}


@router.get("/evolution/replications")
async def list_replications(
    pattern_id: Optional[int] = Query(None),
    status: Optional[str] = Query(None),
    limit: int = Query(20),
):
    """List pattern replications."""
    from security import safe_limit
    limit = safe_limit(limit, 200)
    return {"replications": evolution_engine.get_replications(
        aibrain_db.DB_PATH, pattern_id, status, limit)}


@router.patch("/evolution/replications/{replication_id}")
async def update_replication_endpoint(replication_id: int, body: dict):
    """Update a replication's status and results."""
    evolution_engine.update_replication(
        aibrain_db.DB_PATH, replication_id,
        status=body.get("status"),
        implementation=body.get("implementation"),
        outcome_before=body.get("outcome_before"),
        outcome_after=body.get("outcome_after"),
    )
    return {"status": "updated", "replication_id": replication_id}


# --- Feedback Loop endpoints ---

@router.post("/evolution/feedback-loops")
async def create_feedback_loop(body: dict):
    """Register an explicit feedback loop in the system."""
    required = ["name", "loop_type", "description", "components"]
    for f in required:
        if f not in body:
            return JSONResponse({"error": f"Missing: {f}"}, status_code=400)
    lid = evolution_engine.create_feedback_loop(
        aibrain_db.DB_PATH,
        name=body["name"], loop_type=body["loop_type"],
        description=body["description"], components=body["components"],
        trigger=body.get("trigger"), output=body.get("output"),
        input_source=body.get("input_source"),
        scale=body.get("scale", "micro"),
    )
    return {"status": "created", "loop_id": lid}


@router.get("/evolution/feedback-loops")
async def list_feedback_loops(
    loop_type: Optional[str] = Query(None),
    status: str = Query("active"),
    scale: Optional[str] = Query(None),
):
    """List feedback loops, optionally filtered."""
    return {"loops": evolution_engine.get_feedback_loops(
        aibrain_db.DB_PATH, loop_type, status, scale)}


@router.post("/evolution/feedback-loops/{loop_id}/trigger")
async def trigger_loop(loop_id: int):
    """Record that a feedback loop completed a cycle."""
    evolution_engine.trigger_feedback_loop(aibrain_db.DB_PATH, loop_id)
    return {"status": "triggered", "loop_id": loop_id}


@router.patch("/evolution/feedback-loops/{loop_id}")
async def update_loop(loop_id: int, body: dict):
    """Update a feedback loop."""
    evolution_engine.update_feedback_loop(
        aibrain_db.DB_PATH, loop_id,
        status=body.get("status"),
        strength=body.get("strength"),
        description=body.get("description"),
        components=body.get("components"),
    )
    return {"status": "updated", "loop_id": loop_id}


# --- Cross-Scale Analysis endpoint ---

@router.get("/evolution/cross-scale")
async def cross_scale_analysis():
    """Find patterns that exist at one scale but haven't been applied at others.
    The micro/macro perspective engine."""
    return evolution_engine.analyze_cross_scale(aibrain_db.DB_PATH)


@router.get("/evolution/learning-curve")
async def evolution_learning_curve():
    """Learning Curve: daily avg quality score from execution_log post-Apr10.

    Only uses rows with real quality scores (quality_score > 0, post 2026-04-10).
    Pre-harness rows (nearly all cost=0, quality=0) are excluded — they would
    pollute the signal with zeros that don't reflect actual performance.

    Returns:
        daily: [{date, avg_quality, count, task_type}] sorted ascending by date
        summary: {avg_7d, avg_30d, total_scored, trend}
        trend: "improving" | "stable" | "declining"
    """
    import statistics as _stats

    db = aibrain_db.get_db()
    try:
        # Daily buckets grouped by date + task_type, post-Apr10, real scores only
        rows = db.execute(
            """
            SELECT
                date(created_at)  AS day,
                task_type,
                AVG(quality_score) AS avg_quality,
                COUNT(*)          AS cnt
            FROM execution_log
            WHERE created_at > '2026-04-10'
              AND quality_score > 0
            GROUP BY day, task_type
            ORDER BY day ASC
            """
        ).fetchall()

        daily = [
            {
                "date": r[0],
                "task_type": r[1] or "unknown",
                "avg_quality": round(r[2], 4),
                "count": r[3],
            }
            for r in rows
        ]

        # Overall daily rollup (all task types combined) for the trend line
        rollup_rows = db.execute(
            """
            SELECT
                date(created_at) AS day,
                AVG(quality_score) AS avg_quality,
                COUNT(*)          AS cnt
            FROM execution_log
            WHERE created_at > '2026-04-10'
              AND quality_score > 0
            GROUP BY day
            ORDER BY day ASC
            """
        ).fetchall()

        rollup = [
            {"date": r[0], "avg_quality": round(r[1], 4), "count": r[2]}
            for r in rollup_rows
        ]

        # 7-day and 30-day averages
        avg_7d_row = db.execute(
            """
            SELECT AVG(quality_score), COUNT(*)
            FROM execution_log
            WHERE created_at > datetime('now', '-7 days')
              AND quality_score > 0
            """
        ).fetchone()

        avg_30d_row = db.execute(
            """
            SELECT AVG(quality_score), COUNT(*)
            FROM execution_log
            WHERE created_at > '2026-04-10'
              AND quality_score > 0
            """
        ).fetchone()

        avg_7d = round(avg_7d_row[0], 4) if avg_7d_row and avg_7d_row[0] else None
        total_scored = avg_30d_row[1] if avg_30d_row else 0
        avg_30d = round(avg_30d_row[0], 4) if avg_30d_row and avg_30d_row[0] else None

        # Trend: compare first-half vs second-half of rollup daily scores
        trend = "stable"
        if len(rollup) >= 4:
            mid = len(rollup) // 2
            first_half = [r["avg_quality"] for r in rollup[:mid]]
            second_half = [r["avg_quality"] for r in rollup[mid:]]
            first_avg = _stats.mean(first_half)
            second_avg = _stats.mean(second_half)
            delta = second_avg - first_avg
            if delta > 0.03:
                trend = "improving"
            elif delta < -0.03:
                trend = "declining"
        elif len(rollup) >= 2:
            delta = rollup[-1]["avg_quality"] - rollup[0]["avg_quality"]
            if delta > 0.03:
                trend = "improving"
            elif delta < -0.03:
                trend = "declining"

        return {
            "daily": daily,
            "rollup": rollup,
            "summary": {
                "avg_7d": avg_7d,
                "avg_30d": avg_30d,
                "total_scored": total_scored,
                "trend": trend,
            },
        }
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Agent Actions — drive next steps from projects/applications
# ---------------------------------------------------------------------------

@router.get("/applications/{app_id}/actions")
async def get_application_actions(app_id: int):
    """Get available agent actions for a job application.
    Returns action buttons the UI can render: reply, follow-up, research, etc."""
    db = _apps_db()
    row = db.execute("SELECT * FROM applications WHERE id = ?", (app_id,)).fetchone()
    db.close()
    if not row:
        return JSONResponse({"error": "Not found"}, status_code=404)
    app = dict(row)

    actions = []
    status = app.get("status", "applied")

    # Always available
    actions.append({
        "id": "research_company",
        "label": "Research Company",
        "description": f"Deep research {app['company']}: Glassdoor, LinkedIn, tech stack, news",
        "type": "agent_task",
        "requires_approval": False,
    })

    # Status-dependent actions
    if status in ("applied", "under-review", "viewed"):
        actions.append({
            "id": "check_for_reply",
            "label": "Check for Reply",
            "description": f"Scan inbox for emails from {app['company']}",
            "type": "agent_task",
            "requires_approval": False,
        })
        actions.append({
            "id": "follow_up",
            "label": "Send Follow-up",
            "description": f"Draft a follow-up email to {app['company']} about {app['role']}",
            "type": "email_draft",
            "requires_approval": True,
        })

    if status in ("replied", "active_conversation"):
        actions.append({
            "id": "reply_to_email",
            "label": "Reply to Email",
            "description": f"Draft reply to {app['company']}'s latest email",
            "type": "email_draft",
            "requires_approval": True,
        })
        actions.append({
            "id": "schedule_interview",
            "label": "Schedule Interview",
            "description": "Parse their email for interview details and confirm",
            "type": "agent_task",
            "requires_approval": True,
        })

    if status == "interview_scheduled":
        actions.append({
            "id": "interview_prep",
            "label": "Interview Prep",
            "description": f"Research {app['company']}, prepare STAR stories, draft questions",
            "type": "agent_task",
            "requires_approval": False,
        })

    if app.get("portal_url"):
        actions.append({
            "id": "check_portal",
            "label": "Check Portal",
            "description": f"Login to {app.get('platform', 'portal')} and check application status",
            "type": "browser_task",
            "requires_approval": False,
            "portal_url": app["portal_url"],
        })

    # Promote to project (if not already)
    proj_db = _projects_db()
    existing_project = proj_db.execute(
        "SELECT id FROM projects WHERE category = 'job_opportunity' AND description LIKE ?",
        (f"%app_id:{app_id}%",)
    ).fetchone()
    proj_db.close()

    if not existing_project:
        actions.append({
            "id": "promote_to_project",
            "label": "Promote to Project",
            "description": "Create a dedicated project with interview pipeline tracking",
            "type": "system_action",
            "requires_approval": False,
        })

    return {
        "application": app,
        "actions": actions,
        "project_id": existing_project["id"] if existing_project else None,
    }


@router.post("/applications/{app_id}/actions/{action_id}")
async def execute_application_action(app_id: int, action_id: str, body: dict = None):
    """Execute an agent action on a job application.
    Actions requiring approval go to the approval queue.
    Actions not requiring approval execute immediately."""
    body = body or {}
    db = _apps_db()
    row = db.execute("SELECT * FROM applications WHERE id = ?", (app_id,)).fetchone()
    db.close()
    if not row:
        return JSONResponse({"error": "Application not found"}, status_code=404)
    app = dict(row)

    # Actions that need the approval queue
    approval_actions = {"follow_up", "reply_to_email", "schedule_interview"}

    if action_id == "promote_to_project":
        result = await _promote_application(app_id)
        return {"status": "executed", "action": action_id, "result": result}

    if action_id in approval_actions:
        # Queue for operator approval
        from approval_queue import add_item as _aq_add
        APPROVAL_DB = Path(os.environ.get("AIBRAIN_ROOT", Path(__file__).parent.parent)) / "approval.db"
        item_id = _aq_add(
            APPROVAL_DB,
            category="job_action",
            title=f"{action_id.replace('_', ' ').title()}: {app['company']} — {app['role']}",
            detail=body.get("detail", f"Agent action for {app['company']}"),
            payload={
                "action": action_id,
                "app_id": app_id,
                "company": app["company"],
                "role": app["role"],
                "mode": body.get("mode", "approval"),  # 'approval' or 'autonomous'
                "context": body.get("context", ""),
            },
        )
        return {
            "status": "queued_for_approval",
            "action": action_id,
            "approval_id": item_id,
            "message": f"Action queued. Waiting for operator approval.",
        }

    # Non-approval actions — return task spec for the agent to execute
    return {
        "status": "ready",
        "action": action_id,
        "task": {
            "type": action_id,
            "company": app["company"],
            "role": app["role"],
            "portal_url": app.get("portal_url"),
            "platform": app.get("platform"),
            "notes": app.get("notes"),
        },
        "message": f"Task spec ready for agent execution.",
    }


@router.get("/projects/{project_id}/actions")
async def get_project_actions(project_id: int):
    """Get available agent actions for a project.
    Determines next step and offers action buttons."""
    db = _projects_db()
    project = db.execute("SELECT * FROM projects WHERE id = ?", (project_id,)).fetchone()
    if not project:
        db.close()
        return JSONResponse({"error": "Not found"}, status_code=404)
    project = dict(project)

    # Find next pending step
    next_step = db.execute(
        """SELECT s.*, p.name as phase_name
           FROM project_steps s
           JOIN project_phases p ON s.phase_id = p.id
           WHERE s.project_id = ? AND s.status = 'pending'
           ORDER BY p.phase_order ASC, s.step_order ASC
           LIMIT 1""",
        (project_id,)
    ).fetchone()

    # Find in-progress steps
    in_progress = db.execute(
        """SELECT s.*, p.name as phase_name
           FROM project_steps s
           JOIN project_phases p ON s.phase_id = p.id
           WHERE s.project_id = ? AND s.status = 'in_progress'
           ORDER BY p.phase_order ASC, s.step_order ASC""",
        (project_id,)
    ).fetchall()

    # Count completed vs total
    stats = db.execute(
        """SELECT
             COUNT(*) as total,
             SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
             SUM(CASE WHEN status = 'blocked' THEN 1 ELSE 0 END) as blocked
           FROM project_steps WHERE project_id = ?""",
        (project_id,)
    ).fetchone()
    db.close()

    actions = []

    # Next step action
    if next_step:
        step = dict(next_step)
        actions.append({
            "id": "execute_next_step",
            "label": f"Do: {step['title']}",
            "description": step.get("description", ""),
            "phase": step["phase_name"],
            "step_id": step["id"],
            "type": "agent_task",
            "requires_approval": _step_needs_approval(step["title"]),
        })

    # Autonomous mode
    actions.append({
        "id": "go_autonomous",
        "label": "Go Autonomous",
        "description": "Agent works through all steps until hitting a blocker or needing human input",
        "type": "autonomous_mode",
        "requires_approval": True,  # Must approve entering autonomous mode
    })

    # If job_opportunity project, add email actions
    if project.get("category") == "job_opportunity":
        desc = project.get("description", "")
        actions.append({
            "id": "reply_to_latest",
            "label": "Reply to Latest Email",
            "description": "Draft reply to the most recent email in this conversation",
            "type": "email_draft",
            "requires_approval": True,
        })
        actions.append({
            "id": "check_inbox",
            "label": "Check for New Emails",
            "description": "Scan inbox for new messages related to this opportunity",
            "type": "agent_task",
            "requires_approval": False,
        })

    return {
        "project": project,
        "next_step": dict(next_step) if next_step else None,
        "in_progress": [dict(s) for s in in_progress],
        "progress": {
            "total": stats["total"],
            "completed": stats["completed"],
            "blocked": stats["blocked"],
            "percent": round(stats["completed"] / stats["total"] * 100) if stats["total"] > 0 else 0,
        },
        "actions": actions,
    }


def _step_needs_approval(title: str) -> bool:
    """Determine if a step requires human approval.
    Uses the permissions system first, falls back to keyword detection."""
    # Map step title keywords to action types
    keyword_to_action = {
        "send": "send_email", "reply": "reply_email", "email": "send_email",
        "submit": "browser_submit", "publish": "post_social",
        "accept": "send_email", "decline": "send_email",
        "negotiate": "send_email", "contact": "send_email",
        "schedule": "send_email", "confirm": "send_email",
    }
    title_lower = title.lower()
    for keyword, action_type in keyword_to_action.items():
        if keyword in title_lower:
            # Check permissions system
            result = permissions.check_permission(
                aibrain_db.DB_PATH, action_type=action_type,
                context={"step_title": title}
            )
            if result["decision"] == "allowed":
                return False  # Permission granted, no approval needed
            elif result["decision"] == "denied":
                return True  # Explicitly denied
            else:
                return True  # "queued" = needs approval
    return False  # No matching keywords = no approval needed


@router.post("/projects/{project_id}/actions/{action_id}")
async def execute_project_action(project_id: int, action_id: str, body: dict = None):
    """Execute an agent action on a project."""
    body = body or {}
    db = _projects_db()
    project = db.execute("SELECT * FROM projects WHERE id = ?", (project_id,)).fetchone()
    if not project:
        db.close()
        return JSONResponse({"error": "Not found"}, status_code=404)
    project = dict(project)

    if action_id == "go_autonomous":
        # Queue autonomous mode request for approval
        from approval_queue import add_item as _aq_add
        APPROVAL_DB = Path(os.environ.get("AIBRAIN_ROOT", Path(__file__).parent.parent)) / "approval.db"
        item_id = _aq_add(
            APPROVAL_DB,
            category="autonomous_mode",
            title=f"Autonomous mode: {project['name']}",
            detail=f"Agent will work through remaining steps until hitting a blocker. "
                   f"Project: {project['name']}. Category: {project.get('category', 'N/A')}.",
            payload={
                "action": "go_autonomous",
                "project_id": project_id,
                "project_name": project["name"],
            },
        )
        db.close()
        return {
            "status": "queued_for_approval",
            "action": action_id,
            "approval_id": item_id,
            "message": "Autonomous mode request queued. Waiting for operator approval.",
        }

    if action_id == "execute_next_step":
        step_id = body.get("step_id")
        if not step_id:
            # Find next pending step
            next_step = db.execute(
                """SELECT s.id FROM project_steps s
                   JOIN project_phases p ON s.phase_id = p.id
                   WHERE s.project_id = ? AND s.status = 'pending'
                   ORDER BY p.phase_order ASC, s.step_order ASC LIMIT 1""",
                (project_id,)
            ).fetchone()
            step_id = next_step["id"] if next_step else None
        if not step_id:
            db.close()
            return {"status": "complete", "message": "No more pending steps."}

        step = db.execute("SELECT * FROM project_steps WHERE id = ?", (step_id,)).fetchone()
        if not step:
            db.close()
            return JSONResponse({"error": "Step not found"}, status_code=404)
        step = dict(step)

        if _step_needs_approval(step["title"]):
            from approval_queue import add_item as _aq_add
            APPROVAL_DB = Path(os.environ.get("AIBRAIN_ROOT", Path(__file__).parent.parent)) / "approval.db"
            item_id = _aq_add(
                APPROVAL_DB,
                category="project_step",
                title=f"{step['title']} — {project['name']}",
                detail=step.get("description", ""),
                payload={
                    "action": "execute_step",
                    "project_id": project_id,
                    "step_id": step_id,
                    "step_title": step["title"],
                },
            )
            db.close()
            return {
                "status": "queued_for_approval",
                "action": action_id,
                "step": step,
                "approval_id": item_id,
            }

        # Mark step as in_progress
        db.execute(
            "UPDATE project_steps SET status = 'in_progress', updated_at = ? WHERE id = ?",
            (datetime.utcnow().isoformat(), step_id)
        )
        db.commit()
        db.close()
        return {
            "status": "started",
            "action": action_id,
            "step": step,
            "message": f"Step '{step['title']}' is now in progress.",
        }

    db.close()
    return {"status": "ready", "action": action_id, "project": project}


# ---------------------------------------------------------------------------
# Permissions — Playwright-style allow_once / allow_always / deny / ask
# ---------------------------------------------------------------------------

@router.get("/permissions")
async def list_agent_permissions(
    category: Optional[str] = Query(None),
    action_type: Optional[str] = Query(None),
):
    """List all active permission rules."""
    perms = permissions.list_permissions(aibrain_db.DB_PATH, category, action_type)
    return {"permissions": perms}


@router.get("/permissions/summary")
async def permission_summary():
    """Get permission overview — categories, defaults, recent activity."""
    return permissions.get_permission_summary(aibrain_db.DB_PATH)


@router.get("/permissions/types")
async def list_action_types():
    """List all known action types with their defaults and risk levels."""
    return {"action_types": permissions.ACTION_TYPES}


@router.post("/permissions")
async def set_agent_permission(body: dict):
    """Set a permission rule.
    Body: {action_type, permission, target?, notes?}
    permission: 'allow_always' | 'allow_once' | 'deny' | 'ask'
    """
    action_type = body.get("action_type")
    perm = body.get("permission")
    if not action_type or not perm:
        return JSONResponse({"error": "action_type and permission required"}, status_code=400)
    if perm not in ("allow_always", "allow_once", "deny", "ask"):
        return JSONResponse({"error": "permission must be allow_always/allow_once/deny/ask"}, status_code=400)

    perm_id = permissions.set_permission(
        aibrain_db.DB_PATH,
        action_type=action_type,
        permission=perm,
        target=body.get("target", "*"),
        granted_by=body.get("granted_by", "user"),
        notes=body.get("notes"),
        expires_at=body.get("expires_at"),
    )
    return {"status": "set", "permission_id": perm_id, "action_type": action_type, "permission": perm}


@router.delete("/permissions/{permission_id}")
async def delete_agent_permission(permission_id: int):
    """Delete a permission rule (reverts to default)."""
    permissions.delete_permission(aibrain_db.DB_PATH, permission_id)
    return {"status": "deleted", "permission_id": permission_id}


@router.post("/permissions/check")
async def check_agent_permission(body: dict):
    """Check if an action is permitted without executing it.
    Body: {action_type, target?, context?}"""
    action_type = body.get("action_type")
    if not action_type:
        return JSONResponse({"error": "action_type required"}, status_code=400)
    result = permissions.check_permission(
        aibrain_db.DB_PATH,
        action_type=action_type,
        target=body.get("target", "*"),
        context=body.get("context"),
    )
    return result


@router.get("/permissions/audit")
async def permission_audit_log(
    action_type: Optional[str] = Query(None),
    limit: int = Query(50),
):
    """Get permission audit trail."""
    return {"audit": permissions.get_audit_log(aibrain_db.DB_PATH, action_type, min(limit, 200))}


@router.post("/permissions/bulk")
async def set_bulk_permissions(body: dict):
    """Set multiple permissions at once.
    Body: {permissions: [{action_type, permission, target?, notes?}, ...]}"""
    perms_list = body.get("permissions", [])
    if not perms_list:
        return JSONResponse({"error": "permissions array required"}, status_code=400)
    results = []
    for p in perms_list:
        if not p.get("action_type") or not p.get("permission"):
            continue
        perm_id = permissions.set_permission(
            aibrain_db.DB_PATH,
            action_type=p["action_type"],
            permission=p["permission"],
            target=p.get("target", "*"),
            granted_by=p.get("granted_by", "user"),
            notes=p.get("notes"),
        )
        results.append({"action_type": p["action_type"], "permission_id": perm_id})
    return {"status": "set", "count": len(results), "results": results}


# ============================================================================
# BRAIN SCANNER — Filesystem & Git discovery for onboarding
# ============================================================================

@router.post("/brain/scan")
async def brain_scan(body: dict):
    """Scan directories and/or GitHub repos to discover and link entities.
    Body: {
        directories: ["/path/to/projects", ...],
        github_username: "optional",
        github_token: "optional",
        claude_memory_dir: "optional"
    }"""
    dirs = body.get("directories", [])
    gh_user = body.get("github_username")
    gh_token = body.get("github_token")
    mem_dir = body.get("claude_memory_dir")

    if not dirs and not gh_user:
        return JSONResponse({"error": "Provide directories and/or github_username"}, status_code=400)

    try:
        import brain_scanner
        report = brain_scanner.build_brain_from_filesystem(
            db_path=str(aibrain_db.DB_PATH),
            project_dirs=dirs,
            github_username=gh_user,
            github_token=gh_token,
            claude_memory_dir=mem_dir,
        )
        return {"status": "ok", "report": report}
    except Exception as e:
        logger.error("Brain scan failed: %s", e, exc_info=True)
        return JSONResponse({"error": "Internal server error"}, status_code=500)


def _is_safe_directory(directory: str) -> bool:
    """Validate directory is under user home — prevents path traversal."""
    from pathlib import Path
    try:
        resolved = Path(directory).resolve()
        home = Path.home().resolve()
        return resolved.is_relative_to(home) and resolved.is_dir()
    except (ValueError, OSError):
        return False


@router.post("/brain/scan-directory")
async def brain_scan_single(body: dict):
    """Scan a single directory and return classified files.
    Body: {directory: "/path/to/project", max_depth: 3}"""
    directory = body.get("directory", "")
    if not directory or not _is_safe_directory(directory):
        return JSONResponse({"error": "Access denied or invalid directory"}, status_code=403)

    try:
        import brain_scanner
        result = brain_scanner.scan_directory(
            directory,
            max_depth=body.get("max_depth", 3),
            read_content=body.get("read_content", True),
        )
        return {"status": "ok", "scan": result}
    except Exception as e:
        logger.error("Directory scan failed: %s", e, exc_info=True)
        return JSONResponse({"error": "Internal server error"}, status_code=500)


@router.get("/brain/git-repos")
async def brain_git_repos(directory: str = Query(...)):
    """Find all git repos under a directory."""
    if not _is_safe_directory(directory):
        return JSONResponse({"error": "Access denied or invalid directory"}, status_code=403)

    try:
        import brain_scanner
        repos = brain_scanner.find_local_git_repos([directory])
        return {"status": "ok", "repos": repos, "count": len(repos)}
    except Exception as e:
        logger.error("Git repo scan failed: %s", e, exc_info=True)
        return JSONResponse({"error": "Internal server error"}, status_code=500)


# ============================================================================
# PHILOSOPHY — Accessible collection of philosophical discussions & insights
# ============================================================================

@router.get("/philosophy")
async def list_philosophy():
    """Get all philosophy entries — insights, paradigms, and discussions."""
    db = aibrain_db.get_db()
    rows = db.execute("""
        SELECT id, name, type, tags, content, created, updated
        FROM memories
        WHERE (tags LIKE '%philosophy%' OR tags LIKE '%paradigm%' OR tags LIKE '%insight%'  # noqa:LIKE WILDCARD INJECTION — static search patterns
               OR type = 'philosophy'
               OR name LIKE '%philosophy%' OR name LIKE '%paradigm%'  # noqa:LIKE WILDCARD INJECTION — static search patterns
               OR name LIKE '%pixel_moment%' OR name LIKE '%connectome%'  # noqa:LIKE WILDCARD INJECTION — static search patterns
               OR name LIKE '%north_star%')
        AND active = 1
        ORDER BY created DESC
    """).fetchall()
    db.close()

    entries = []
    for r in rows:
        entries.append({
            "id": r[0], "name": r[1], "type": r[2], "tags": r[3],
            "content": r[4], "created": r[5], "updated": r[6],
        })
    return {"entries": entries, "count": len(entries)}


# ---------------------------------------------------------------------------
# Tools — list and run built-in tools
# ---------------------------------------------------------------------------

@router.get("/tools")
async def list_tools():
    """List all built-in tools with names and descriptions."""
    try:
        from aibrain.tools.builtin import BUILTIN_TOOLS
        return {"tools": [{"name": t.name, "description": t.description} for t in BUILTIN_TOOLS.values()]}
    except Exception as e:
        logger.warning("Failed to load builtin tools: %s", e)
        return {"tools": []}


@router.post("/tools/run")
async def run_tool(body: dict):
    """Run a built-in tool by name. Body: {tool: str, args: {input: str}}"""
    tool_name = body.get("tool")
    args = body.get("args", {})
    if not tool_name:
        return JSONResponse({"error": "tool name required"}, status_code=400)
    try:
        from aibrain.tools.builtin import get_tool
        tool = get_tool(tool_name)
        if not tool:
            return JSONResponse({"error": f"Tool not found: {tool_name}"}, status_code=404)
        result = tool(**args)
        return {"tool": tool_name, "result": result}
    except Exception as e:
        logger.warning("Tool %s execution failed: %s", tool_name, e)
        return {"tool": tool_name, "error": "Tool execution failed"}


# ---------------------------------------------------------------------------
# License — activate and check license keys
# ---------------------------------------------------------------------------

@router.post("/license")
async def activate_license(body: dict):
    """Activate a license key. Body: {key: str}"""
    key = body.get("key", "")
    if not key:
        return JSONResponse({"error": "No key provided"}, status_code=400)
    try:
        sys.path.insert(0, str(AIBRAIN_ROOT))
        from aibrain_licensing import validate_key, save_license, reset_cache, get_license
        license_obj = validate_key(key)
        if not license_obj.valid:
            return {"status": "error", "message": license_obj.reason or "Invalid license key"}
        save_license(key)
        reset_cache()
        lic = get_license()
        return {"status": "activated", "tier": lic.tier, "valid": lic.valid,
                "expires": lic.expires_at if hasattr(lic, "expires_at") else ""}
    except Exception as e:
        logger.warning("License activation failed: %s", e)
        return {"status": "error", "message": "Invalid license key"}


@router.post("/philosophy")
async def add_philosophy(body: dict):
    """Add a philosophy entry — an insight, paradigm, or discussion point.
    Body: {name, content, tags?}"""
    name = body.get("name", "")
    content = body.get("content", "")
    if not name or not content:
        return JSONResponse({"error": "name and content required"}, status_code=400)

    tags = body.get("tags", "philosophy")
    if "philosophy" not in tags:
        tags = f"philosophy,{tags}" if tags else "philosophy"

    now = datetime.now().isoformat()
    db = aibrain_db.get_db()
    db.execute(
        "INSERT INTO memories (name, type, tags, content, created, updated) VALUES (?, ?, ?, ?, ?, ?)",
        (name, "philosophy", tags, content, now, now)
    )
    db.commit()
    mem_id = db.execute("SELECT last_insert_rowid()").fetchone()[0]
    db.close()

    return {"status": "created", "id": mem_id, "name": name}


# ---------------------------------------------------------------------------
# Push Notification Subscription Endpoints
# ---------------------------------------------------------------------------

def _ensure_push_table(db):
    """Create push_subscriptions table if it doesn't exist."""
    db.execute("""
        CREATE TABLE IF NOT EXISTS push_subscriptions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            endpoint TEXT UNIQUE NOT NULL,
            p256dh TEXT NOT NULL,
            auth TEXT NOT NULL,
            token TEXT,
            created TEXT NOT NULL
        )
    """)
    db.commit()


@router.post("/push-subscribe")
async def push_subscribe(body: dict):
    """Store a Web Push subscription for later notifications.

    Body: {"subscription": {"endpoint": ..., "keys": {"p256dh": ..., "auth": ...}}, "token": "pairing_token"}
    Returns: {"ok": true}
    """
    sub = body.get("subscription", {})
    endpoint = sub.get("endpoint", "")
    keys = sub.get("keys", {})
    p256dh = keys.get("p256dh", "")
    auth = keys.get("auth", "")
    token = body.get("token", "")

    if not endpoint or not p256dh or not auth:
        return JSONResponse({"error": "subscription.endpoint, keys.p256dh and keys.auth required"}, status_code=400)

    db = aibrain_db.get_db()
    try:
        _ensure_push_table(db)
        now = datetime.now().isoformat()
        db.execute(
            """INSERT INTO push_subscriptions (endpoint, p256dh, auth, token, created)
               VALUES (?, ?, ?, ?, ?)
               ON CONFLICT(endpoint) DO UPDATE SET p256dh=excluded.p256dh, auth=excluded.auth, token=excluded.token""",
            (endpoint, p256dh, auth, token, now)
        )
        db.commit()
    finally:
        db.close()

    return {"ok": True}


@router.post("/push-unsubscribe")
async def push_unsubscribe(body: dict):
    """Remove a Web Push subscription.

    Body: {"endpoint": "..."} or {"subscription": {"endpoint": "..."}}
    Returns: {"ok": true, "removed": N}
    """
    sub = body.get("subscription", {})
    endpoint = body.get("endpoint") or sub.get("endpoint", "")

    if not endpoint:
        return JSONResponse({"error": "endpoint required"}, status_code=400)

    db = aibrain_db.get_db()
    try:
        _ensure_push_table(db)
        cur = db.execute("DELETE FROM push_subscriptions WHERE endpoint = ?", (endpoint,))
        db.commit()
        removed = cur.rowcount
    finally:
        db.close()

    return {"ok": True, "removed": removed}


def send_push_notification(title: str, body: str, url: str = "/", tag: str = "aibrain"):
    """Send a Web Push notification to all stored subscribers.

    Uses pywebpush if installed. Logs a warning if pywebpush is unavailable.
    This is a best-effort fire-and-forget — failures are logged, not raised.
    """
    try:
        import py_vapid
        import pywebpush
        _pywebpush_available = True
    except ImportError:
        logger.warning(
            "pywebpush not installed — push notifications disabled. "
            "Install with: pip install pywebpush"
        )
        return

    vapid_private_key = os.environ.get("VAPID_PRIVATE_KEY", "")
    vapid_claims_email = os.environ.get("VAPID_CLAIMS_EMAIL", "mailto:admin@example.com")
    if not vapid_private_key:
        logger.warning("VAPID_PRIVATE_KEY not set — skipping push notifications")
        return

    db = aibrain_db.get_db()
    try:
        _ensure_push_table(db)
        rows = db.execute("SELECT endpoint, p256dh, auth FROM push_subscriptions").fetchall()
    finally:
        db.close()

    if not rows:
        return

    import json as _json
    payload = _json.dumps({"title": title, "body": body, "url": url, "tag": tag})

    for endpoint, p256dh, auth_key in rows:
        try:
            pywebpush.webpush(
                subscription_info={
                    "endpoint": endpoint,
                    "keys": {"p256dh": p256dh, "auth": auth_key},
                },
                data=payload,
                vapid_private_key=vapid_private_key,
                vapid_claims={"sub": vapid_claims_email},
            )
        except Exception as exc:
            logger.warning("Push notification failed for %s: %s", endpoint[:60], exc)


# ── Cohort Analysis ───────────────────────────────────────────────────────────
#
# Data strategy (two-tier):
#   Tier 1 — license_activations has rows → use real paying users.
#   Tier 0 — no paying users yet → fall back to execution_log actors filtered
#             to "human-style" actors (excludes agent:*, system, scheduler, etc.)
#             This captures Decker (neuro, cli, case, test) and any external
#             testers so we accumulate full history from day one.
#
# "Active" in period N = has ≥1 execution_log row in that calendar period.
# "Churn"  = no execution_log row in 14+ days after previously being active.
# "Phase-skip" = license_state moved free→Pro in <7 days from first activation.

_SYSTEM_ACTOR_PREFIXES = (
    "agent:", "system", "scheduler", "digest", "calibration",
    "special_liaison", "tester", "test_persist", "p0_1_verify",
)


def _is_human_actor(actor: str) -> bool:
    """Return True if actor looks like a real user (not an internal agent/system)."""
    al = actor.lower()
    for prefix in _SYSTEM_ACTOR_PREFIXES:
        if al.startswith(prefix):
            return False
    return True


def _get_cohort_db():
    """Return a read-only connection to the main AIBrain DB."""
    import sqlite3 as _sql3
    db = _sql3.connect(str(aibrain_db.DB_PATH), check_same_thread=False)
    db.row_factory = _sql3.Row
    return db


def _cohort_users(db):
    """
    Return list of (user_id, first_seen ISO datetime) ordered by first_seen.

    Priority:
      1. license_activations.email / first_seen_at  (real activations)
      2. execution_log actor + MIN(created_at)       (proxy users)
    """
    act_count = db.execute("SELECT COUNT(*) FROM license_activations").fetchone()[0]
    if act_count > 0:
        rows = db.execute(
            "SELECT email as user_id, first_seen_at FROM license_activations ORDER BY first_seen_at"
        ).fetchall()
        return [(r["user_id"], r["first_seen_at"]) for r in rows]

    # Proxy: execution_log human actors
    rows = db.execute(
        "SELECT actor as user_id, MIN(created_at) as first_seen "
        "FROM execution_log GROUP BY actor ORDER BY first_seen"
    ).fetchall()
    return [(r["user_id"], r["first_seen"]) for r in rows if _is_human_actor(r["user_id"])]


def _user_active_dates(db, user_id: str) -> list[str]:
    """
    Return sorted list of ISO date strings on which user_id was active.

    For license users: execution_log actor matching email (or use
    license_activations.last_seen_at range — but we prefer granular data).
    For proxy actors: direct actor match in execution_log.
    """
    # In both tiers the actor key in execution_log is usable — for license users
    # the actor won't match by email, but we use execution_log as the activity
    # source for proxy users and license_activations last_seen for real users.
    act_count = db.execute("SELECT COUNT(*) FROM license_activations").fetchone()[0]
    if act_count > 0:
        # For real users use license_activations.last_seen_at as a signal
        # (we don't have per-day activity for license users yet — that comes when
        # the SDK sends heartbeats).  Return [first_seen, last_seen] as two anchors.
        row = db.execute(
            "SELECT first_seen_at, last_seen_at FROM license_activations WHERE email = ?",
            (user_id,),
        ).fetchone()
        if row:
            dates = [row["first_seen_at"][:10], row["last_seen_at"][:10]]
            return sorted(set(dates))
        return []

    # Proxy: real execution_log rows
    rows = db.execute(
        "SELECT DISTINCT DATE(created_at) as d FROM execution_log "
        "WHERE actor = ? ORDER BY d",
        (user_id,),
    ).fetchall()
    return [r["d"] for r in rows]


def _iso_week(dt_str: str) -> str:
    """Return 'YYYY-Www' from an ISO datetime/date string."""
    from datetime import datetime as _dt
    d = _dt.fromisoformat(dt_str[:10])
    return f"{d.isocalendar()[0]}-W{d.isocalendar()[1]:02d}"


def _iso_month(dt_str: str) -> str:
    return dt_str[:7]  # 'YYYY-MM'


def _period_offset(first_date_str: str, activity_date_str: str, period: str) -> int:
    """Return 0-based period offset (0 = activation period)."""
    from datetime import datetime as _dt
    d_first = _dt.fromisoformat(first_date_str[:10])
    d_act   = _dt.fromisoformat(activity_date_str[:10])
    if period == "week":
        return (d_act - d_first).days // 7
    else:  # month
        return (d_act.year - d_first.year) * 12 + (d_act.month - d_first.month)


@router.get("/analytics/cohorts/summary")
async def get_cohort_summary():
    """
    Headline retention health metrics.

    Returns:
        total_users         — distinct users ever seen
        active_7d           — users with activity in last 7 days
        active_30d          — users with activity in last 30 days
        churn_count         — users churned (14+ days silent after prior activity)
        churn_rate          — churn_count / total_users (0.0-1.0)
        phase_skip_count    — users who hit Pro in <7 days from first activation
        phase_skip_rate     — phase_skip_count / total_users
        median_days_to_upgrade — median days free→Pro (None if no upgrades)
        data_source         — 'license_activations' | 'execution_log_proxy'
    """
    from datetime import datetime as _dt, timedelta as _td
    db = _get_cohort_db()
    try:
        act_count = db.execute("SELECT COUNT(*) FROM license_activations").fetchone()[0]
        data_source = "license_activations" if act_count > 0 else "execution_log_proxy"

        users = _cohort_users(db)
        total_users = len(users)
        if total_users == 0:
            return {
                "total_users": 0, "active_7d": 0, "active_30d": 0,
                "churn_count": 0, "churn_rate": 0.0,
                "phase_skip_count": 0, "phase_skip_rate": 0.0,
                "median_days_to_upgrade": None,
                "data_source": data_source,
            }

        now = _dt.utcnow()
        cutoff_7d  = (now - _td(days=7)).date().isoformat()
        cutoff_30d = (now - _td(days=30)).date().isoformat()
        cutoff_churn = (now - _td(days=14)).date().isoformat()

        active_7d = active_30d = churn_count = 0

        for user_id, first_seen in users:
            dates = _user_active_dates(db, user_id)
            if not dates:
                continue
            last_date = dates[-1]
            if last_date >= cutoff_7d:
                active_7d += 1
            if last_date >= cutoff_30d:
                active_30d += 1
            # Churn: last activity was ≥14d ago AND user had prior activity
            # (i.e. they were active at some point, then went silent)
            if last_date < cutoff_churn and len(dates) >= 1:
                churn_count += 1

        churn_rate = round(churn_count / total_users, 4) if total_users else 0.0

        # Phase-skip: license_state rows that went to Pro within 7 days
        phase_skip_count = 0
        upgrade_days_list: list[int] = []
        if act_count > 0:
            ls_rows = db.execute(
                "SELECT ls.user_id, ls.tier, ls.updated_at, la.first_seen_at "
                "FROM license_state ls "
                "JOIN license_activations la ON la.key_hash = ls.key_hash "
                "WHERE ls.tier != 'free'"
            ).fetchall()
            for row in ls_rows:
                from datetime import datetime as _dt2
                first = _dt2.fromisoformat(row["first_seen_at"][:19])
                upgraded = _dt2.fromisoformat(row["updated_at"][:19])
                days = (upgraded - first).days
                upgrade_days_list.append(days)
                if days < 7:
                    phase_skip_count += 1
        # proxy: no upgrade data available
        phase_skip_rate = round(phase_skip_count / total_users, 4) if total_users else 0.0

        median_days_to_upgrade = None
        if upgrade_days_list:
            sorted_days = sorted(upgrade_days_list)
            n = len(sorted_days)
            if n % 2 == 1:
                median_days_to_upgrade = sorted_days[n // 2]
            else:
                median_days_to_upgrade = (sorted_days[n // 2 - 1] + sorted_days[n // 2]) / 2

        return {
            "total_users": total_users,
            "active_7d": active_7d,
            "active_30d": active_30d,
            "churn_count": churn_count,
            "churn_rate": churn_rate,
            "phase_skip_count": phase_skip_count,
            "phase_skip_rate": phase_skip_rate,
            "median_days_to_upgrade": median_days_to_upgrade,
            "data_source": data_source,
        }
    finally:
        db.close()


@router.post("/analytics/cohorts")
async def get_cohort_retention(body: dict):
    """
    Cohort retention triangle.

    Input:  { cohort_period: 'week' | 'month', max_cohorts: int (default 12) }
    Output: {
        cohort_period,
        cohorts: [{
            cohort_label,       # 'YYYY-Www' or 'YYYY-MM'
            cohort_date,        # ISO date of first user in cohort
            cohort_size,        # distinct users who activated in this period
            retention_by_period: { "0": 100.0, "1": %, ... }
        }]
    }

    Period 0 = activation period (always 100%).
    Period N = % of cohort still active N periods after activation.
    "Active in period" = has at least one activity date that falls in that period.
    """
    from datetime import datetime as _dt
    from collections import defaultdict

    period = body.get("cohort_period", "week")
    if period not in ("week", "month"):
        period = "week"
    max_cohorts = int(body.get("max_cohorts", 12))

    db = _get_cohort_db()
    try:
        users = _cohort_users(db)
        if not users:
            return {"cohort_period": period, "cohorts": []}

        # Group users by their activation cohort period
        cohort_map: dict[str, list[str]] = defaultdict(list)
        cohort_first_date: dict[str, str] = {}
        for user_id, first_seen in users:
            if period == "week":
                label = _iso_week(first_seen)
            else:
                label = _iso_month(first_seen)
            cohort_map[label].append(user_id)
            if label not in cohort_first_date or first_seen < cohort_first_date[label]:
                cohort_first_date[label] = first_seen

        # Sort cohorts chronologically, take most recent max_cohorts
        sorted_labels = sorted(cohort_map.keys())
        if len(sorted_labels) > max_cohorts:
            sorted_labels = sorted_labels[-max_cohorts:]

        result_cohorts = []
        for label in sorted_labels:
            user_ids = cohort_map[label]
            cohort_size = len(user_ids)
            cohort_anchor = cohort_first_date[label]  # first_seen of earliest user

            # For each user, collect which periods they were active in
            # period offset = how many weeks/months after their first activation
            period_active_users: dict[int, set] = defaultdict(set)

            for user_id in user_ids:
                dates = _user_active_dates(db, user_id)
                first_user_date = next(
                    (fs for uid, fs in users if uid == user_id), cohort_anchor
                )
                seen_offsets = set()
                for d in dates:
                    offset = _period_offset(first_user_date, d, period)
                    if offset >= 0:
                        seen_offsets.add(offset)
                for off in seen_offsets:
                    period_active_users[off].add(user_id)

            # Build retention dict: period 0 always 100%
            max_offset = max(period_active_users.keys()) if period_active_users else 0
            retention_by_period: dict[str, float] = {}
            for off in range(max_offset + 1):
                active_count = len(period_active_users.get(off, set()))
                retention_by_period[str(off)] = round(
                    active_count / cohort_size * 100, 1
                )

            # Ensure period 0 = 100 (every user is counted at activation)
            retention_by_period["0"] = 100.0

            result_cohorts.append({
                "cohort_label": label,
                "cohort_date": cohort_anchor[:10],
                "cohort_size": cohort_size,
                "retention_by_period": retention_by_period,
            })

        return {"cohort_period": period, "cohorts": result_cohorts}
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Dream diary — consolidation transparency
# ---------------------------------------------------------------------------

@router.get("/dreams/latest")
async def dreams_latest():
    """Return the latest DREAMS.md content and the last 7 run summaries.

    DREAMS.md is written by workflows/memory_consolidation.py after each
    nightly consolidation cycle. Returns empty content when no cycle has run yet.
    """
    import json as _json

    from aibrain_db import AIBRAIN_ROOT as _AIBRAIN_ROOT
    from pathlib import Path as _Path

    dreams_path = _Path(_AIBRAIN_ROOT) / "DREAMS.md"
    history_path = _Path(_AIBRAIN_ROOT) / "dreams_history.json"

    # Read current DREAMS.md
    dreams_content = ""
    dreams_mtime = None
    if dreams_path.exists():
        dreams_content = dreams_path.read_text(encoding="utf-8")
        dreams_mtime = dreams_path.stat().st_mtime

    # Read history (last 7 summaries)
    history: list[dict] = []
    if history_path.exists():
        try:
            raw = history_path.read_text(encoding="utf-8")
            parsed = _json.loads(raw)
            if isinstance(parsed, list):
                history = parsed
        except Exception:
            pass

    return {
        "content": dreams_content,
        "last_run_at": dreams_mtime,
        "history": history,
        "has_run": bool(dreams_content),
    }


# ---------------------------------------------------------------------------
# Dashboard stubs — SuperWorker runs, Mesh health, Proficiency
# These endpoints are consumed by dashboard pages. Stubs return 200 with
# meaningful empty-state payloads so the UI renders correctly rather than
# showing 404 errors. They will be filled in as the features mature.
# ---------------------------------------------------------------------------

@router.get("/superworker/runs")
async def superworker_runs():
    """Return SuperWorker run history.

    The boss agent (boss/boss.py) does not yet persist a run log.
    Returns an empty list with a descriptive message so the dashboard
    SuperWorker page renders in an empty-state rather than erroring on 404.
    """
    # Attempt to read from execution_log filtered by superworker actor
    try:
        db = get_db()
        rows = db.execute(
            "SELECT id, workflow_name, started_at, quality_score, success "
            "FROM execution_log WHERE actor='superworker' ORDER BY started_at DESC LIMIT 50"
        ).fetchall()
        runs = [dict(r) for r in rows]
    except Exception:
        runs = []

    return {
        "runs": runs,
        "message": "No SuperWorker runs recorded yet" if not runs else None,
    }


@router.get("/mesh/health")
async def mesh_health():
    """Return mesh connectivity health for broker, Tailscale, and Telegram.

    Checks environment variables and known state; does not make live network
    calls so the endpoint always responds quickly. The dashboard Mesh Health
    page uses this to render the connectivity status panel.
    """
    broker_url = os.environ.get("BROKER_URL", "")
    tailscale_ip = os.environ.get("TAILSCALE_IP", "")
    telegram_token = os.environ.get("TELEGRAM_TOKEN", "")

    return {
        "broker": "configured" if broker_url else "unknown",
        "tailscale": "configured" if tailscale_ip else "unknown",
        "telegram": "configured" if telegram_token else "unknown",
        "broker_url": broker_url.split("@")[-1] if broker_url else None,  # strip creds if any
        "note": "Live connectivity checks require the mesh health workflow",
    }


@router.get("/proficiency")
async def agent_proficiency():
    """Return the agent's current proficiency score from the fitness/objective system.

    Proficiency is generated by the memory_consolidation (dream) workflow.
    Returns a null level with guidance when no score has been recorded yet.
    """
    level = None
    score = None
    trend = None
    last_updated = None

    try:
        db = get_db()
        # Attempt to read from evolution_outcomes or a fitness summary table
        row = db.execute(
            "SELECT metric_value, created_at FROM evolution_outcomes "
            "WHERE metric_name='proficiency_score' ORDER BY created_at DESC LIMIT 1"
        ).fetchone()
        if row:
            score = round(float(row["metric_value"]), 3)
            last_updated = row["created_at"]
            # Map 0-1 score to human level
            if score >= 0.85:
                level = "expert"
            elif score >= 0.70:
                level = "advanced"
            elif score >= 0.50:
                level = "intermediate"
            else:
                level = "beginner"
    except Exception:
        pass

    return {
        "level": level,
        "score": score,
        "trend": trend,
        "last_updated": last_updated,
        "message": "Run aibrain dream to generate proficiency score" if score is None else None,
    }
