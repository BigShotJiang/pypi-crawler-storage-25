"""
gumroad_checkout_api.py — Manual / Gumroad checkout endpoints.

Three routes mounted on the FastAPI app via include_router:
  POST /api/gumroad-checkout   — issue a license key for a Gumroad payment
  POST /api/activate           — bind a license key to a machine fingerprint
  GET  /api/license-status     — query license state by raw key (query param)

Design decisions:
  - No Stripe / no payment processor integration — payment_reference is stored
    as-is for manual reconciliation against Gumroad order IDs.
  - Uses gumroad_licenses table (standalone, no FK to users) so Gumroad buyers
    who don't have AIBrain accounts can still receive a valid license.
  - key_hash (SHA-256 of raw key) is used for indexed O(1) lookups; the raw
    key is only returned at checkout time and never stored in plain text anywhere
    else (the caller is responsible for saving it).
  - Machine binding: first activation sets machine_id; subsequent activations
    from the same fingerprint are idempotent; a different fingerprint gets 409.
"""

import hashlib
import logging
import os
import secrets
import sqlite3
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel, EmailStr, field_validator

logger = logging.getLogger(__name__)

router = APIRouter()

# ---------------------------------------------------------------------------
# DB helper — mirrors the pattern used in license_activations_api.py
# ---------------------------------------------------------------------------

def _get_db() -> sqlite3.Connection:
    """Open the canonical aibrain DB (or AIBRAIN_DB env var for test isolation)."""
    db_path = os.environ.get("AIBRAIN_DB")
    if not db_path:
        import aibrain_db  # already on sys.path from main.py
        db_path = str(aibrain_db.AIBRAIN_ROOT / "aibrain.db")
    conn = sqlite3.connect(db_path, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


def _ensure_schema(conn: sqlite3.Connection) -> None:
    """Create gumroad_licenses table if absent (idempotent, safe to call every request)."""
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS gumroad_licenses (
            key_hash          TEXT PRIMARY KEY,
            email             TEXT NOT NULL,
            tier              TEXT NOT NULL,
            payment_reference TEXT NOT NULL,
            valid_until       TEXT NOT NULL,
            grace_until       TEXT NOT NULL,
            machine_id        TEXT,
            activated_at      TEXT,
            created_at        TEXT NOT NULL DEFAULT (datetime('now')),
            updated_at        TEXT NOT NULL DEFAULT (datetime('now'))
        );
        CREATE INDEX IF NOT EXISTS idx_gumroad_licenses_email
            ON gumroad_licenses(email);
        CREATE INDEX IF NOT EXISTS idx_gumroad_licenses_payment_ref
            ON gumroad_licenses(payment_reference);
    """)
    conn.commit()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _sha256(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


def _generate_key(tier: str) -> str:
    """Generate a license key in the format AIBRAIN-{TIER}-{16 hex chars uppercase}."""
    prefix = tier.upper()  # PRO or TEAM
    token = secrets.token_hex(8).upper()
    return f"AIBRAIN-{prefix}-{token}"


def _now_utc() -> datetime:
    return datetime.now(timezone.utc)


def _valid_until_and_grace() -> tuple[str, str]:
    """Return (valid_until, grace_until) ISO strings: now+31d, now+34d."""
    now = _now_utc()
    valid_until = (now + timedelta(days=31)).strftime("%Y-%m-%dT%H:%M:%SZ")
    grace_until = (now + timedelta(days=34)).strftime("%Y-%m-%dT%H:%M:%SZ")
    return valid_until, grace_until


def _mask_machine_id(machine_id: Optional[str]) -> Optional[str]:
    """Return first 8 chars + *** for display, or None if unset."""
    if not machine_id:
        return None
    return machine_id[:8] + "***"


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------

class CheckoutRequest(BaseModel):
    email: str
    tier: str
    payment_reference: str

    @field_validator("tier")
    @classmethod
    def validate_tier(cls, v: str) -> str:
        v = v.lower().strip()
        if v not in ("pro", "team"):
            raise ValueError("tier must be 'pro' or 'team'")
        return v

    @field_validator("email")
    @classmethod
    def validate_email(cls, v: str) -> str:
        v = v.strip()
        if not v or "@" not in v:
            raise ValueError("email must be a valid email address")
        return v

    @field_validator("payment_reference")
    @classmethod
    def validate_payment_ref(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("payment_reference is required")
        return v


class ActivateRequest(BaseModel):
    license_key: str
    machine_fingerprint: str

    @field_validator("license_key")
    @classmethod
    def validate_key_format(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("license_key is required")
        return v

    @field_validator("machine_fingerprint")
    @classmethod
    def validate_fingerprint(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("machine_fingerprint is required")
        return v


# ---------------------------------------------------------------------------
# POST /api/gumroad-checkout
# ---------------------------------------------------------------------------

@router.post("/api/gumroad-checkout")
async def gumroad_checkout(body: CheckoutRequest):
    """Issue a license key for a verified Gumroad payment.

    Generates a new AIBRAIN-{TIER}-{TOKEN} key, stores a hashed record,
    and returns the raw key (the ONLY time it is returned in plain text).

    Body: {"email": str, "tier": "pro"|"team", "payment_reference": str}
    Returns: {"license_key": str, "tier": str, "valid_until": str, "email": str}
    """
    license_key = _generate_key(body.tier)
    key_hash = _sha256(license_key)
    valid_until, grace_until = _valid_until_and_grace()
    now_str = _now_utc().strftime("%Y-%m-%dT%H:%M:%SZ")

    try:
        db = _get_db()
        try:
            _ensure_schema(db)
            db.execute(
                """INSERT INTO gumroad_licenses
                   (key_hash, email, tier, payment_reference,
                    valid_until, grace_until, created_at, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (key_hash, body.email, body.tier, body.payment_reference,
                 valid_until, grace_until, now_str, now_str),
            )
            db.commit()
        finally:
            db.close()
    except Exception as exc:
        logger.error("gumroad_checkout: DB error: %s", exc)
        raise HTTPException(status_code=500, detail="Database error during checkout")

    logger.info(
        "gumroad_checkout: issued key_hash=%.8s... tier=%s email=%s ref=%s",
        key_hash, body.tier, body.email, body.payment_reference,
    )

    return {
        "license_key": license_key,
        "tier": body.tier,
        "valid_until": valid_until,
        "email": body.email,
    }


# ---------------------------------------------------------------------------
# POST /api/activate
# ---------------------------------------------------------------------------

@router.post("/api/activate")
async def activate_license(body: ActivateRequest):
    """Bind a license key to a machine fingerprint.

    - First activation: sets machine_id and activated_at, returns 200.
    - Same machine re-activating: idempotent, returns 200.
    - Different machine: returns 409 (key already bound to another machine).
    - Unknown key: returns 404.
    - Expired key (past grace_until): returns 403.

    Body: {"license_key": str, "machine_fingerprint": str}
    Returns: {"status": "activated", "tier": str, "expires_at": str}
    """
    key_hash = _sha256(body.license_key)
    now = _now_utc()
    now_str = now.strftime("%Y-%m-%dT%H:%M:%SZ")

    try:
        db = _get_db()
        try:
            _ensure_schema(db)
            row = db.execute(
                """SELECT tier, valid_until, grace_until, machine_id, activated_at
                   FROM gumroad_licenses WHERE key_hash = ?""",
                (key_hash,),
            ).fetchone()

            if row is None:
                raise HTTPException(status_code=404, detail="License key not found")

            row = dict(row)
            tier = row["tier"]
            valid_until_str = row.get("valid_until") or ""
            grace_until_str = row.get("grace_until") or ""
            existing_machine = row.get("machine_id") or ""

            # Expiry check — reject if past grace window
            if grace_until_str:
                try:
                    grace_dt = datetime.fromisoformat(
                        grace_until_str.replace("Z", "+00:00")
                    )
                    if now > grace_dt:
                        raise HTTPException(
                            status_code=403,
                            detail="License key has expired",
                        )
                except HTTPException:
                    raise
                except Exception:
                    pass  # malformed date — allow through (fail-open)

            # Machine binding check
            if existing_machine:
                if existing_machine != body.machine_fingerprint:
                    raise HTTPException(
                        status_code=409,
                        detail="License key is already bound to a different machine",
                    )
                # Same machine — idempotent OK, no DB write needed
            else:
                # First activation — bind machine
                db.execute(
                    """UPDATE gumroad_licenses
                       SET machine_id = ?, activated_at = ?, updated_at = ?
                       WHERE key_hash = ?""",
                    (body.machine_fingerprint, now_str, now_str, key_hash),
                )
                db.commit()

        finally:
            db.close()

    except HTTPException:
        raise
    except Exception as exc:
        logger.error("activate_license: DB error: %s", exc)
        raise HTTPException(status_code=500, detail="Database error during activation")

    logger.info(
        "activate_license: key_hash=%.8s... tier=%s machine=%.8s...",
        key_hash, tier, body.machine_fingerprint,
    )

    return {
        "status": "activated",
        "tier": tier,
        "expires_at": valid_until_str,
    }


# ---------------------------------------------------------------------------
# GET /api/license-status
# ---------------------------------------------------------------------------

@router.get("/api/license-status")
async def license_status_by_key(key: str):
    """Get license status by raw license key (query param).

    Query: ?key=AIBRAIN-PRO-...
    Returns: tier, expires_at, machine_id_masked, is_valid, is_grace_period
    """
    if not key or not key.strip():
        raise HTTPException(status_code=400, detail="key query parameter is required")

    key_hash = _sha256(key.strip())
    now = _now_utc()

    try:
        db = _get_db()
        try:
            _ensure_schema(db)
            row = db.execute(
                """SELECT tier, valid_until, grace_until, machine_id
                   FROM gumroad_licenses WHERE key_hash = ?""",
                (key_hash,),
            ).fetchone()
        finally:
            db.close()
    except Exception as exc:
        logger.error("license_status_by_key: DB error: %s", exc)
        raise HTTPException(status_code=500, detail="Database error")

    if row is None:
        raise HTTPException(status_code=404, detail="License key not found")

    row = dict(row)
    valid_until_str = row.get("valid_until") or ""
    grace_until_str = row.get("grace_until") or ""
    tier = row.get("tier", "")
    machine_id = row.get("machine_id") or ""

    is_valid = True
    is_grace_period = False

    if valid_until_str:
        try:
            vu_dt = datetime.fromisoformat(valid_until_str.replace("Z", "+00:00"))
            if now > vu_dt:
                is_valid = False
                # Check grace window
                if grace_until_str:
                    try:
                        gu_dt = datetime.fromisoformat(
                            grace_until_str.replace("Z", "+00:00")
                        )
                        if now <= gu_dt:
                            is_valid = True
                            is_grace_period = True
                    except (ValueError, TypeError):
                        pass
        except (ValueError, TypeError):
            pass

    return {
        "tier": tier,
        "expires_at": valid_until_str or None,
        "machine_id_masked": _mask_machine_id(machine_id),
        "is_valid": is_valid,
        "is_grace_period": is_grace_period,
    }
