"""
companies_api.py — REST API for Companies feature.

Endpoints for the dashboard to display and manage AI companies.
All endpoints require localhost access (same as agent config endpoints).
"""

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from typing import Optional, List
import sys
import json
import secrets
from pathlib import Path
from datetime import datetime, timezone

# Add parent to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from aibrain.core.companies import (
    create_company, list_companies, get_company,
    hire_agent, list_agents, get_agent,
    create_task, list_tasks, get_task, update_task, checkout_task, complete_task,
    request_approval, approve, reject, pending_approvals,
    create_team, list_teams, get_team, delete_team, run_team,
)
from aibrain.core.heartbeat import run_heartbeat, check_due_heartbeats, _get_db


def _require_localhost(request: Request):
    """Enforce localhost-only access for company management endpoints.

    Security fix (Task 1): previously only write-path endpoints called this
    helper explicitly; GET endpoints were accessible to any valid API-key holder
    from non-localhost.  By wiring this as a router-level dependency, ALL
    /api/companies/* routes are localhost-gated regardless of HTTP method.
    """
    host = (request.client.host if request.client else "unknown")
    if host not in {"127.0.0.1", "::1", "localhost"}:
        raise HTTPException(
            status_code=403,
            detail=f"Company API is only allowed from localhost (got: {host})"
        )


# Router-level dependency: every route under /api/companies/* requires localhost.
# Individual write endpoints also call _require_localhost explicitly (redundant
# but harmless — belt-and-suspenders) for clarity in the route handlers.
router = APIRouter(
    prefix="/api/companies",
    tags=["companies"],
    dependencies=[Depends(_require_localhost)],
)


# --- Models ---

class CompanyCreate(BaseModel):
    name: str
    mission: str = ""

class AgentHire(BaseModel):
    name: str
    role: str = "general"
    title: str = ""
    reports_to: Optional[str] = None
    model: str = "auto"
    capabilities: str = ""

class TaskCreate(BaseModel):
    title: str
    description: str = ""
    assignee_agent_id: Optional[str] = None
    priority: str = "medium"
    parent_id: Optional[str] = None

class ApprovalAction(BaseModel):
    note: str = ""


# --- Company endpoints ---

@router.get("/")
def api_list_companies():
    return list_companies()

@router.post("/")
def api_create_company(request: Request, data: CompanyCreate):
    _require_localhost(request)
    result = create_company(data.name, data.mission)
    if "error" in result:
        raise HTTPException(400, result["error"])
    return result

@router.get("/{company_id}")
def api_get_company(company_id: str):
    result = get_company(company_id)
    if not result:
        raise HTTPException(404, "Company not found")
    return result


@router.delete("/{company_id}")
def api_delete_company(request: Request, company_id: str):
    """Delete a company and all related data (agents, tasks, approvals, goals, teams, heartbeats)."""
    _require_localhost(request)
    db = _get_db()
    existing = db.execute("SELECT id FROM companies WHERE id=?", (company_id,)).fetchone()
    if not existing:
        db.close()
        raise HTTPException(404, "Company not found")
    for table in ["company_agents", "company_issues", "company_approvals",
                  "company_heartbeat_runs", "company_goals", "company_teams"]:
        try:
            db.execute(f"DELETE FROM {table} WHERE company_id=?", (company_id,))  # noqa:sql-injection
        except Exception:
            pass
    db.execute("DELETE FROM companies WHERE id=?", (company_id,))
    db.commit()
    db.close()
    return {"deleted": company_id}

@router.get("/{company_id}/dashboard")
def api_company_dashboard(company_id: str):
    """Single endpoint returning full dashboard overview."""
    db = _get_db()

    company = db.execute("SELECT * FROM companies WHERE id=?", (company_id,)).fetchone()
    if not company:
        db.close()
        raise HTTPException(404, "Company not found")

    agents = db.execute(
        "SELECT id, name, role, title, status, model, last_heartbeat_at FROM company_agents WHERE company_id=? AND status != 'terminated'",
        (company_id,)
    ).fetchall()

    tasks_by_status = {}
    for row in db.execute(
        "SELECT status, COUNT(*) as cnt FROM company_issues WHERE company_id=? GROUP BY status",
        (company_id,)
    ).fetchall():
        tasks_by_status[row["status"]] = row["cnt"]

    pending = db.execute(
        "SELECT COUNT(*) FROM company_approvals WHERE company_id=? AND status='pending'",
        (company_id,)
    ).fetchone()[0]

    recent_runs = [dict(r) for r in db.execute(
        "SELECT r.*, a.name as agent_name FROM company_heartbeat_runs r "
        "JOIN company_agents a ON r.agent_id = a.id "
        "WHERE r.company_id=? ORDER BY r.created_at DESC LIMIT 10",
        (company_id,)
    ).fetchall()]

    avg_quality = db.execute(
        "SELECT AVG(quality_score) FROM company_issues WHERE company_id=? AND quality_score IS NOT NULL",
        (company_id,)
    ).fetchone()[0] or 0

    db.close()

    return {
        "company": dict(company),
        "agents": [dict(a) for a in agents],
        "agents_count": len(agents),
        "agents_running": sum(1 for a in agents if a["status"] == "running"),
        "tasks_by_status": tasks_by_status,
        "tasks_total": sum(tasks_by_status.values()),
        "pending_approvals": pending,
        "recent_runs": recent_runs,
        "avg_quality": round(avg_quality, 2),
    }


# --- Agent endpoints ---

@router.get("/{company_id}/agents")
def api_list_agents(company_id: str):
    return list_agents(company_id)

@router.post("/{company_id}/agents")
def api_hire_agent(request: Request, company_id: str, data: AgentHire):
    _require_localhost(request)
    result = hire_agent(company_id, data.name, role=data.role, title=data.title,
                        reports_to=data.reports_to, model=data.model,
                        capabilities=data.capabilities)
    if "error" in result:
        raise HTTPException(400, result["error"])
    return result

@router.get("/{company_id}/agents/{agent_id}")
def api_get_agent(company_id: str, agent_id: str):
    result = get_agent(agent_id)
    if not result:
        raise HTTPException(404, "Agent not found")
    return result

@router.patch("/{company_id}/agents/{agent_id}")
def api_update_agent(company_id: str, agent_id: str, data: dict):
    """Update agent status or capabilities."""
    allowed = {"status", "capabilities", "title", "model", "name"}
    updates = {k: v for k, v in data.items() if k in allowed}
    if not updates:
        raise HTTPException(400, "No valid fields to update")
    db = _get_db()
    fields = ", ".join(f"{k}=?" for k in updates)
    values = list(updates.values()) + [agent_id, company_id]
    db.execute(
        f"UPDATE company_agents SET {fields} WHERE id=? AND company_id=?",
        values,
    )
    db.commit()
    return {"ok": True, "updated": list(updates.keys())}

@router.post("/{company_id}/agents/{agent_id}/heartbeat")
def api_run_heartbeat(company_id: str, agent_id: str):
    return run_heartbeat(agent_id)


import os as _os

SUBAGENTS_DIR = r"C:\Users\sinde\decker_system\02_subagents"

@router.get("/{company_id}/agents/{agent_id}/persona")
def api_get_agent_persona(company_id: str, agent_id: str):
    db = _get_db()
    row = db.execute("SELECT instructions, metadata FROM company_agents WHERE id=? AND company_id=?", [agent_id, company_id]).fetchone()
    db.close()
    if not row:
        raise HTTPException(404, "Agent not found")
    instructions = row["instructions"] or ""
    meta = {}
    try:
        meta = json.loads(row["metadata"] or "{}")
    except Exception:
        pass
    persona_file = meta.get("persona_file")
    if instructions:
        return {"content": instructions, "source": "instructions", "file_path": persona_file}
    if persona_file and _os.path.exists(persona_file):
        content = open(persona_file, encoding="utf-8").read()
        return {"content": content, "source": "file", "file_path": persona_file}
    return {"content": "", "source": "empty", "file_path": persona_file}


@router.put("/{company_id}/agents/{agent_id}/persona")
def api_put_agent_persona(company_id: str, agent_id: str, data: dict):
    content = data.get("content", "")
    write_to_file = data.get("write_to_file", False)
    db = _get_db()
    row = db.execute("SELECT metadata FROM company_agents WHERE id=? AND company_id=?", [agent_id, company_id]).fetchone()
    if not row:
        db.close()
        raise HTTPException(404, "Agent not found")
    db.execute("UPDATE company_agents SET instructions=?, updated_at=datetime('now') WHERE id=? AND company_id=?", [content, agent_id, company_id])
    db.commit()
    written_to_file = False
    if write_to_file:
        try:
            meta = json.loads(row["metadata"] or "{}")
            pf = meta.get("persona_file")
            if pf:
                open(pf, "w", encoding="utf-8").write(content)
                written_to_file = True
        except Exception:
            pass
    db.close()
    return {"ok": True, "written_to_file": written_to_file}


# --- Task endpoints ---

@router.get("/{company_id}/tasks")
def api_list_tasks(
    company_id: str,
    status: Optional[str] = None,
    limit: Optional[int] = 50,
    offset: int = 0,
):
    return list_tasks(company_id, status=status, limit=limit, offset=offset)

@router.post("/{company_id}/tasks")
def api_create_task(request: Request, company_id: str, data: TaskCreate):
    _require_localhost(request)
    return create_task(company_id, data.title, description=data.description,
                       assignee_agent_id=data.assignee_agent_id,
                       priority=data.priority, parent_id=data.parent_id)

@router.get("/{company_id}/tasks/{task_id}")
def api_get_task(company_id: str, task_id: str):
    task = get_task(task_id)
    if task is None:
        raise HTTPException(404, "Task not found")
    return task


class TaskPatch(BaseModel):
    status: Optional[str] = None
    priority: Optional[str] = None
    assignee_agent_id: Optional[str] = None


@router.patch("/{company_id}/tasks/{task_id}")
def api_update_task(company_id: str, task_id: str, data: TaskPatch):
    patch = {k: v for k, v in data.model_dump().items() if v is not None}
    try:
        return update_task(task_id, **patch)
    except ValueError:
        raise HTTPException(404, "Task not found")


@router.post("/{company_id}/tasks/{task_id}/checkout")
def api_checkout_task(request: Request, company_id: str, task_id: str, agent_id: str):
    _require_localhost(request)
    result = checkout_task(task_id, agent_id)
    if "error" in result:
        raise HTTPException(409, result["error"])
    return result

class CompleteTaskRequest(BaseModel):
    """Fix 3: Require output in API complete-task calls.

    quality_score is the caller's self-assessment (stored as self_score, not
    used as final score — the system runs independent evaluation).
    output is required: the system cannot measure quality without it, and
    storing quality_score=NULL for a completed task pollutes the audit trail.
    """
    quality_score: Optional[float] = None
    cost_cents: Optional[int] = None  # None = unmeasured (honest-rubric contract)
    output: Optional[str] = None  # required for high/critical; strongly recommended for all


@router.post("/{company_id}/tasks/{task_id}/complete")
def api_complete_task(request: Request, company_id: str, task_id: str,
                      data: CompleteTaskRequest = None):
    _require_localhost(request)
    """Complete a task with output evidence.

    quality_score is treated as self_score (caller's claim).
    The system runs independent evaluation and stores both scores.
    output is required for high/critical tasks and strongly recommended for all
    others — without it, quality cannot be measured and the completion will be
    rejected or stored as unverified.
    """
    if data is None:
        data = CompleteTaskRequest()
    return complete_task(
        task_id,
        quality_score=data.quality_score,
        cost_cents=data.cost_cents,
        output=data.output,
    )


# --- Approval endpoints ---

@router.get("/{company_id}/approvals")
def api_pending_approvals(company_id: str):
    return pending_approvals(company_id)

@router.post("/{company_id}/approvals/{approval_id}/approve")
def api_approve(request: Request, company_id: str, approval_id: str, data: ApprovalAction):
    _require_localhost(request)
    return approve(approval_id, data.note)

@router.post("/{company_id}/approvals/{approval_id}/reject")
def api_reject(request: Request, company_id: str, approval_id: str, data: ApprovalAction):
    _require_localhost(request)
    return reject(approval_id, data.note)


# --- Heartbeat endpoints ---

@router.post("/{company_id}/heartbeats/check")
def api_check_heartbeats(company_id: str):
    """Run all due heartbeats for this company."""
    return check_due_heartbeats()

# --- Secrets endpoints ---

@router.get("/{company_id}/secrets")
def api_list_secrets(company_id: str):
    from aibrain.core.secrets import list_secrets
    return list_secrets(company_id=company_id)

@router.post("/{company_id}/secrets")
def api_store_secret(request: Request, company_id: str, data: dict):
    _require_localhost(request)
    from aibrain.core.secrets import store_secret
    return store_secret(
        name=data["name"],
        value=data["value"],
        scope=data.get("scope", "company"),
        company_id=company_id,
        agent_id=data.get("agent_id"),
        created_by=data.get("created_by", "dashboard"),
    )

@router.delete("/{company_id}/secrets/{secret_name}")
def api_delete_secret(request: Request, company_id: str, secret_name: str):
    _require_localhost(request)
    from aibrain.core.secrets import delete_secret
    deleted = delete_secret(secret_name, company_id=company_id)
    if not deleted:
        raise HTTPException(404, "Secret not found")
    return {"deleted": secret_name}


@router.get("/{company_id}/heartbeats/recent")
def api_recent_heartbeats(company_id: str, limit: int = 20):
    limit = min(max(1, limit), 500)
    db = _get_db()
    runs = db.execute(
        "SELECT r.*, a.name as agent_name FROM company_heartbeat_runs r "
        "JOIN company_agents a ON r.agent_id = a.id "
        "WHERE r.company_id=? ORDER BY r.created_at DESC LIMIT ?",
        (company_id, limit)
    ).fetchall()
    db.close()
    return [dict(r) for r in runs]


# --- Goals ---

def _ensure_goals_table():
    db = _get_db()
    db.execute("""
        CREATE TABLE IF NOT EXISTS company_goals (
            id TEXT PRIMARY KEY,
            company_id TEXT NOT NULL,
            title TEXT NOT NULL,
            description TEXT DEFAULT '',
            status TEXT DEFAULT 'active',
            priority TEXT DEFAULT 'medium',
            target_date TEXT,
            progress REAL DEFAULT 0.0,
            milestones TEXT DEFAULT '[]',
            assigned_agent_id TEXT,
            parent_goal_id TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
    """)
    db.commit()
    db.close()

_ensure_goals_table()


class GoalCreate(BaseModel):
    title: str
    description: str = ""
    priority: str = "medium"
    target_date: Optional[str] = None
    assigned_agent_id: Optional[str] = None
    parent_goal_id: Optional[str] = None
    milestones: List[str] = []


class GoalUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    status: Optional[str] = None
    priority: Optional[str] = None
    target_date: Optional[str] = None
    progress: Optional[float] = None
    milestones: Optional[List[str]] = None
    assigned_agent_id: Optional[str] = None
    parent_goal_id: Optional[str] = None


@router.get("/{company_id}/goals")
def api_list_goals(company_id: str):
    db = _get_db()
    rows = db.execute(
        "SELECT * FROM company_goals WHERE company_id=? ORDER BY created_at DESC",
        (company_id,),
    ).fetchall()
    db.close()
    goals = []
    for r in rows:
        g = dict(r)
        g["milestones"] = json.loads(g.get("milestones") or "[]")
        goals.append(g)
    return goals


@router.post("/{company_id}/goals")
def api_create_goal(request: Request, company_id: str, data: GoalCreate):
    _require_localhost(request)
    now = datetime.now(timezone.utc).isoformat()
    goal_id = secrets.token_urlsafe(8)
    milestones_json = json.dumps(data.milestones)
    db = _get_db()
    db.execute(
        "INSERT INTO company_goals (id, company_id, title, description, status, priority, target_date, progress, milestones, assigned_agent_id, parent_goal_id, created_at, updated_at) "
        "VALUES (?, ?, ?, ?, 'active', ?, ?, 0.0, ?, ?, ?, ?, ?)",
        (goal_id, company_id, data.title, data.description, data.priority,
         data.target_date, milestones_json, data.assigned_agent_id,
         data.parent_goal_id, now, now),
    )
    db.commit()
    row = db.execute("SELECT * FROM company_goals WHERE id=?", (goal_id,)).fetchone()
    db.close()
    g = dict(row)
    g["milestones"] = json.loads(g.get("milestones") or "[]")
    return g


@router.put("/{company_id}/goals/{goal_id}")
def api_update_goal(request: Request, company_id: str, goal_id: str, data: GoalUpdate):
    _require_localhost(request)
    db = _get_db()
    existing = db.execute(
        "SELECT * FROM company_goals WHERE id=? AND company_id=?",
        (goal_id, company_id),
    ).fetchone()
    if not existing:
        db.close()
        raise HTTPException(404, "Goal not found")

    _GOAL_COLUMNS = frozenset({"title", "description", "status", "priority", "target_date", "progress", "assigned_agent_id", "parent_goal_id"})
    updates = {}
    for field in _GOAL_COLUMNS:
        val = getattr(data, field, None)
        if val is not None:
            updates[field] = val
    if data.milestones is not None:
        updates["milestones"] = json.dumps(data.milestones)

    if updates:
        updates["updated_at"] = datetime.now(timezone.utc).isoformat()
        safe_cols = [k for k in updates if k in _GOAL_COLUMNS or k == "milestones" or k == "updated_at"]
        set_clause = ", ".join(c + "=?" for c in safe_cols)  # noqa:SQL-FSTRING-WHITELIST
        vals = [updates[c] for c in safe_cols] + [goal_id, company_id]
        db.execute(
            "UPDATE company_goals SET " + set_clause + " WHERE id=? AND company_id=?",  # noqa:SQL-FSTRING
            vals,
        )
        db.commit()

    row = db.execute("SELECT * FROM company_goals WHERE id=?", (goal_id,)).fetchone()
    db.close()
    g = dict(row)
    g["milestones"] = json.loads(g.get("milestones") or "[]")
    return g


@router.delete("/{company_id}/goals/{goal_id}")
def api_delete_goal(request: Request, company_id: str, goal_id: str):
    _require_localhost(request)
    db = _get_db()
    existing = db.execute(
        "SELECT id FROM company_goals WHERE id=? AND company_id=?",
        (goal_id, company_id),
    ).fetchone()
    if not existing:
        db.close()
        raise HTTPException(404, "Goal not found")
    db.execute("DELETE FROM company_goals WHERE id=? AND company_id=?", (goal_id, company_id))
    db.commit()
    db.close()
    return {"deleted": goal_id}


# --- Company Config (strategy data) ---

_COMPANY_CONFIG_KEYS = {
    "company_vision",
    "company_twin_principle",
    "company_operating_rules",
    "company_strategic_decisions",
    "company_tools_inventory",
    "company_mission_notes",
}


@router.get("/{company_id}/config")
def api_get_company_config(company_id: str):
    import aibrain_db
    result = {}
    for key in _COMPANY_CONFIG_KEYS:
        val = aibrain_db.config_get(key)
        if val is not None:
            result[key] = val
    return result


class CompanyConfigUpdate(BaseModel):
    key: str
    value: str


@router.put("/{company_id}/config")
def api_update_company_config(request: Request, company_id: str, data: CompanyConfigUpdate):
    _require_localhost(request)
    if data.key not in _COMPANY_CONFIG_KEYS:
        raise HTTPException(400, f"Key not allowed: {data.key}")
    import aibrain_db
    aibrain_db.config_set(data.key, data.value, changed_by="dashboard")
    return {"key": data.key, "updated": True}


# --- Projects ---

@router.get("/{company_id}/projects")
def api_list_projects(company_id: str):
    db = _get_db()
    try:
        rows = db.execute(
            "SELECT * FROM company_projects WHERE company_id=? ORDER BY priority DESC, name",
            (company_id,),
        ).fetchall()
    except Exception:
        db.close()
        return []
    db.close()
    return [dict(r) for r in rows]


@router.post("/{company_id}/projects")
def api_create_project(request: Request, company_id: str, data: dict):
    _require_localhost(request)
    now = datetime.now(timezone.utc).isoformat()
    pid = secrets.token_urlsafe(8)
    db = _get_db()
    db.execute(
        "INSERT INTO company_projects (id, company_id, name, tagline, description, status, priority, repo, path, progress, tech_stack, created_at, updated_at) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (pid, company_id, data.get("name", ""), data.get("tagline", ""), data.get("description", ""),
         data.get("status", "active"), data.get("priority", "medium"), data.get("repo", ""),
         data.get("path", ""), data.get("progress", 0.0), data.get("tech_stack", ""), now, now),
    )
    db.commit()
    row = db.execute("SELECT * FROM company_projects WHERE id=?", (pid,)).fetchone()
    db.close()
    return dict(row)


# --- Teams ---

class TeamCreate(BaseModel):
    name: str
    agent_ids: Optional[List[str]] = None
    task_ids: Optional[List[str]] = None
    process: str = "sequential"


class TeamRun(BaseModel):
    inputs: Optional[dict] = None


@router.get("/{company_id}/teams")
def api_list_teams(company_id: str):
    return list_teams(company_id)


@router.post("/{company_id}/teams")
def api_create_team(request: Request, company_id: str, data: TeamCreate):
    _require_localhost(request)
    result = create_team(
        company_id, data.name,
        agent_ids=data.agent_ids,
        task_ids=data.task_ids,
        process=data.process,
    )
    if "error" in result:
        raise HTTPException(400, result["error"])
    return result


@router.get("/{company_id}/teams/{team_id}")
def api_get_team(company_id: str, team_id: str):
    result = get_team(team_id)
    if not result:
        raise HTTPException(404, "Team not found")
    return result


@router.delete("/{company_id}/teams/{team_id}")
def api_delete_team(request: Request, company_id: str, team_id: str):
    _require_localhost(request)
    deleted = delete_team(team_id)
    if not deleted:
        raise HTTPException(404, "Team not found")
    return {"deleted": team_id}


@router.post("/{company_id}/teams/{team_id}/run")
def api_run_team(request: Request, company_id: str, team_id: str, data: TeamRun = TeamRun()):
    _require_localhost(request)
    result = run_team(company_id, team_id, inputs=data.inputs)
    if "error" in result:
        raise HTTPException(400, result["error"])
    return result
