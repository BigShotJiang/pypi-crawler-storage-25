#!/usr/bin/env python3
"""
realtime_learner.py — Agent-agnostic real-time learning extraction.

Extracts learnings from AI conversation logs into aibrain.db. Works with
ANY AI model or system — not tied to Claude Code.

Three operating modes:
  1. Hook mode   — called by Claude Code hooks (PostToolUse/PreCompact/Stop)
  2. Watch mode  — background process that polls conversation log files
  3. Scan mode   — one-shot scan of a transcript file or directory

Hook mode is a bonus for Claude Code users. Watch mode is the generic
solution that works with ChatGPT exports, OpenClaw logs, Cursor sessions,
Copilot chats, or any system that writes conversation logs to files.

What it captures:
  - Error -> Fix patterns (something broke, then was fixed)
  - Corrections ("was wrong", "actually", "not X but Y")
  - Decisions with rationale ("chose X because Y")
  - Discoveries ("turns out", "realized", "discovered")
  - Task completions (what was done and why)

Usage:
  # Watch mode — polls log directories every N minutes (default: 15)
  python realtime_learner.py --watch --interval 15

  # Watch specific directories
  python realtime_learner.py --watch --log-dirs /path/to/logs /other/path

  # One-shot scan of a file or directory
  python realtime_learner.py --scan path/to/conversation.jsonl
  python realtime_learner.py --scan path/to/chat_exports/

  # Hook mode (Claude Code — auto-detected from stdin)
  # Just wire it up in settings.json hooks

  # Self-test
  python realtime_learner.py --test
"""

import argparse
import hashlib
import json
import os
import re
import sqlite3
import sys
from datetime import datetime, timezone
from pathlib import Path

# ---------------------------------------------------------------------------
# DB resolution — same pattern as all aibrain code
# ---------------------------------------------------------------------------

def _resolve_root():
    """Use the canonical resolver — see aibrain_db.AIBRAIN_ROOT."""
    from aibrain_db import AIBRAIN_ROOT
    return AIBRAIN_ROOT


def _resolve_db():
    root = _resolve_root()
    if "AIBRAIN_DB" in os.environ:
        return Path(os.environ["AIBRAIN_DB"])
    # Pick largest DB file
    best = root / "aibrain.db"
    return best


AIBRAIN_ROOT = _resolve_root()
DB_PATH = _resolve_db()

# State file — tracks last-read position per session
STATE_DIR = AIBRAIN_ROOT / "data"
STATE_FILE = STATE_DIR / "realtime_learner_state.json"

# ---------------------------------------------------------------------------
# Signal detection patterns
# ---------------------------------------------------------------------------

# Patterns that indicate a learning moment in conversation text.
#
# Each entry is {regex_list, allowed_roles} — allowed_roles restricts which
# conversation role can produce this signal. Praise ONLY counts when the
# USER says it; self_reflection ONLY counts when the ASSISTANT says it.
# Corrections can come from either role but carry different meaning — user
# corrections are external feedback, assistant "I was wrong" is
# self-reflection material.
#
# Three-signal learning model (feedback_extract_three_signals.md, Apr 10 2026):
# negative (corrections) + meta-cognitive (self_reflection) + positive (praise).
# Previously only corrections were extracted — this extractor was deaf to the
# other two signals. Decker explicitly flagged: "positive reinforcement is
# equally important as negative" — praise is at correction-level importance.

LEARNING_SIGNALS = {
    "correction": {
        "patterns": [
            r"was wrong",
            r"actually[,:]?\s",
            r"not (?:a )?regression",
            r"false positive",
            r"(?:root |real )?cause (?:was|is|turned)",
            r"turns out",
            r"realized",
            r"correction:",
            r"corrected",
            r"I was wrong",
            r"misidentified",
        ],
        "roles": ("human", "user", "assistant"),
    },
    "fix": {
        "patterns": [
            r"(?:I |we |the )?fix(?:ed|es|ing)\s(?:the|a|this|that|it)",
            r"(?:bug|issue|problem|error) (?:was|is|in)\s",
            r"root cause.*?(?:was|is|:)",
            r"hotfix",
            r"resolved? (?:the|a|this|by)",
        ],
        "roles": ("human", "user", "assistant"),
    },
    "decision": {
        "patterns": [
            r"(?:chose|choosing|decided|decision)\s",
            r"(?:went|going) with\s",
            r"(?:because|since|reason)\s.*(?:better|simpler|faster|safer)",
            r"trade-?off",
            r"(?:approved|rejected|selected)\s",
        ],
        "roles": ("human", "user", "assistant"),
    },
    "discovery": {
        "patterns": [
            r"discovered?\s",
            r"(?:found|finding) (?:that|out)",
            r"(?:it |this )(?:looks like|appears|seems)",
            r"(?:new|key) (?:insight|finding|observation)",
            r"didn'?t (?:know|realize|expect)",
        ],
        "roles": ("human", "user", "assistant"),
    },
    "completion": {
        "patterns": [
            r"(?:done|completed|finished|shipped|deployed|pushed|committed)",
            r"all (?:\d+ )?tests pass",
            r"(?:merged|landed)\s",
            r"working (?:now|correctly|properly)",
        ],
        "roles": ("human", "user", "assistant"),
    },
    # Meta-cognitive signals — the ASSISTANT recognizing it needs to reconsider.
    # These are strong learning signals even when no external correction was
    # given. Per feedback_extract_three_signals.md: self-reflection is the
    # ability to recognize you need to dig deeper.
    "self_reflection": {
        "patterns": [
            r"\b(?:i|I) should have\b",
            r"\blet me reconsider\b",
            r"\bon second thought\b",
            r"\b(?:I|i) realize(?:d)? (?:now|that|i)\b",
            r"\bi was wrong about\b",
            r"\bactually,? (?:that|this|i)'?s not\b",
            r"\blet me correct myself\b",
            r"\bwait,? (?:that|this)'?s not right\b",
            r"\b(?:I|i) need to rethink\b",
            r"\bthat doesn'?t (?:actually )?work because\b",
            r"\bhmm,? actually\b",
            r"\b(?:I|i) missed that\b",
            r"\bi should (?:check|verify|confirm) (?:that|this|first)\b",
        ],
        "roles": ("assistant",),
    },
    # Positive reinforcement — USER praising or confirming assistant actions.
    # Equally important as corrections per Decker (Apr 10 2026). These teach
    # the agent WHAT TO KEEP DOING in addition to what to stop doing.
    "praise": {
        "patterns": [
            r"\byes[!,.]? exactly\b",
            r"\bperfect[!,.]?\b(?! (?:square|match|fit(?:s|ting)?|pitch))",
            r"\bgreat work\b",
            r"\bwell done\b",
            r"\bgood job\b",
            r"\bgood call\b",
            r"\bnicely done\b",
            r"\bthat'?s (?:it|right|exactly right|perfect)\b",
            r"\bspot on\b",
            r"\bbeautiful[!.]",
            r"\bbrilliant[!.]",
            r"\blove (?:it|that)[!.]",
            r"\bkeep doing (?:that|this)\b",
            r"\bthat (?:is|was) (?:the right|exactly|great|perfect|amazing)\b",
            r"\bexcellent work\b",
            r"\bthis is (?:great|amazing|brilliant|perfect)\b",
            r"\bnice catch\b",
            r"\b(?:huge|great) (?:find|win|get)\b",
        ],
        "roles": ("human", "user"),
    },
}

# ---------------------------------------------------------------------------
# Config-driven constants — read from ~/.aibrain/learn.toml if present,
# otherwise fall back to original hardcoded defaults.
# ---------------------------------------------------------------------------
try:
    from aibrain.tools.learn.config import load_learn_config as _load_learn_config
    _learn_cfg = _load_learn_config()
except Exception:
    _learn_cfg = {
        'min_msg_length': 40, 'max_per_run': 10, 'precompact_limit': 25,
        'watch_interval_min': 15,
        'signals': {
            'corrections': True, 'fixes': True, 'discoveries': True,
            'decisions': True, 'completions': True,
            'self_reflections': True, 'praise': True,
        },
        'importance': {
            'corrections': 0.8, 'fixes': 0.7, 'discoveries': 0.7,
            'decisions': 0.6, 'completions': 0.4,
            'self_reflections': 0.75,  # meta-cognitive — high but not quite correction-level
            'praise': 0.8,              # equally important as corrections per Decker (Apr 10 2026)
        },
    }

# Minimum content length to consider a message worth analyzing
MIN_MSG_LENGTH = _learn_cfg.get('min_msg_length', 40)

# Maximum learnings per hook invocation (prevent flooding)
MAX_LEARNINGS_PER_RUN = _learn_cfg.get('max_per_run', 10)


# ---------------------------------------------------------------------------
# State management — track what we've already processed
# ---------------------------------------------------------------------------

def _load_state() -> dict:
    if STATE_FILE.exists():
        try:
            return json.loads(STATE_FILE.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass
    return {}


def _save_state(state: dict):
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    STATE_FILE.write_text(json.dumps(state, indent=2), encoding="utf-8")


# ---------------------------------------------------------------------------
# Transcript reading
# ---------------------------------------------------------------------------

def read_transcript(path: str, start_line: int = 0) -> list:
    """Read transcript JSONL file, optionally starting from a specific line."""
    messages = []
    try:
        with open(path, "r", encoding="utf-8") as f:
            for i, line in enumerate(f):
                if i < start_line:
                    continue
                line = line.strip()
                if not line:
                    continue
                try:
                    msg = json.loads(line)
                    msg["_line_num"] = i
                    messages.append(msg)
                except json.JSONDecodeError:
                    continue
    except (FileNotFoundError, OSError):
        pass
    return messages


def extract_text_from_message(msg: dict) -> str:
    """Extract readable text from a transcript message."""
    # Claude Code JSONL nests content inside msg["message"]["content"]
    # Check nested message first (Claude Code transcript format)
    inner = msg.get("message")
    if isinstance(inner, dict):
        return _extract_content(inner)

    # Direct content (standard chat format)
    return _extract_content(msg)


def _extract_content(obj: dict) -> str:
    """Extract text from a message object's content field.

    Only extracts human-authored text blocks. Tool call inputs (tool_use)
    and tool outputs (tool_result) are excluded — they are raw structured
    data (JSON, bash output, file listings) that pollute signal detection
    with false positives (e.g. "Bash completed" firing as a completion
    signal). Phase 6 retrolearn review found 434 polluted rows (6.6% of
    TIER 2 sweep) traced to tool_result content reaching detect_signals.
    """
    content = obj.get("content")
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for block in content:
            if isinstance(block, str):
                parts.append(block)
            elif isinstance(block, dict):
                # Only extract human-authored text blocks.
                # tool_use blocks contain JSON-encoded function arguments.
                # tool_result blocks contain raw shell/file output.
                # Both are structured data, not conversation prose.
                if block.get("type") == "text":
                    parts.append(block.get("text", ""))
                # tool_use and tool_result intentionally omitted.
        return "\n".join(parts)
    if obj.get("text"):
        return obj["text"]
    return ""


# ---------------------------------------------------------------------------
# Learning extraction from conversation
# ---------------------------------------------------------------------------

def detect_signals(text: str, role: str = None) -> list:
    """Detect learning signals in a piece of text. Returns list of signal type names.

    `role` filters role-restricted signals (praise only from user, self_reflection
    only from assistant). Pass None to bypass role filtering (legacy behavior,
    used by old callers and tests).

    Signals are returned in ROLE-AWARE PRIORITY ORDER so the primary signal
    (signals[0]) is the semantically correct one for the role:
      - assistant: self_reflection > correction > others
      - user:      praise > correction > others
    This fixes the Phase 1 finding that every assistant "I was wrong" was
    classified as correction instead of self_reflection because of iteration
    order. (TIER 2 retrolearn Phase 1 report, 2026-04-10.)
    """
    # Skip system/XML/tool-output noise
    if text.startswith("<") and ("task-notification" in text or "system-reminder" in text):
        return []
    # Guard: raw JSON tool call or tool output (any length).
    # tool_use blocks look like: {"type": "tool_use", "name": "...", "input": {...}}
    # Short raw JSON (<200 chars) is also caught here.
    if text.startswith("{"):
        if len(text) < 200:
            return []  # Short JSON blob — likely raw tool output
        # Longer JSON: check for tool_use/tool_result structural markers
        if '"type": "tool_use"' in text or '"type": "tool_result"' in text:
            return []

    # Compaction-summary pre-filter. Lines that begin with this exact phrase
    # are Claude Code post-compaction continuation summaries — not fresh signal,
    # but they contain enough trigger words to fire every signal pattern at
    # least once. Found 434 polluted rows (6.6% of TIER 2 sweep) from this
    # single source. Phase 6 SuperWorker quality review, 2026-04-10.
    if text.lstrip().startswith("This session is being continued from a previous conversation"):
        return []

    # Strip Claude Code transcript-UI chrome before analysis. These characters
    # are rendering artifacts from the live transcript view, not real content.
    # Without this filter the extractor misclassifies "(Bash completed with no
    # output)" and "⎿" lines as completion signals. (TIER 2 retrolearn Phase 1
    # finding, 2026-04-10.)
    _transcript_chrome_prefixes = ("⎿", "✻", "│", "╭", "╰", "├", "└", "─")
    _chrome_phrase_pat = re.compile(
        r"^\s*(?:\((?:Bash|Read|Write|Edit|Glob|Grep|WebFetch|WebSearch|"
        r"TaskCreate|Agent|Skill)[^)]*\)|\(Tool use error[^)]*\)|"
        r"\[REALTIME LEARNER\]|\[posttool\]|\[precompact\]|\[watcher\]|"
        r"\[historical_scan\]|\[session_end\]|\[fact_extract\])",
        re.IGNORECASE,
    )
    clean_lines = []
    for line in text.split("\n"):
        s = line.strip()
        if not s:
            continue
        if any(s.startswith(p) for p in _transcript_chrome_prefixes):
            continue
        if _chrome_phrase_pat.match(s):
            continue
        clean_lines.append(line)
    text = "\n".join(clean_lines)

    # Strip XML/HTML tags before analysis
    clean = re.sub(r"<[^>]+>", " ", text)
    if len(clean.strip()) < MIN_MSG_LENGTH:
        return []

    # Map LEARNING_SIGNALS keys (singular) to config keys (plural)
    _type_to_cfg = {
        "correction": "corrections",
        "fix": "fixes",
        "discovery": "discoveries",
        "decision": "decisions",
        "completion": "completions",
        "self_reflection": "self_reflections",
        "praise": "praise",
    }
    sig_cfg = _learn_cfg.get('signals', {})

    signals = []
    clean_lower = clean.lower()
    for signal_type, signal_def in LEARNING_SIGNALS.items():
        # Skip disabled signal types
        cfg_key = _type_to_cfg.get(signal_type, signal_type)
        if not sig_cfg.get(cfg_key, True):
            continue
        # Backward compat: signal_def may be the old list-of-patterns format
        if isinstance(signal_def, list):
            patterns = signal_def
            allowed_roles = None  # any role
        else:
            patterns = signal_def.get("patterns", [])
            allowed_roles = signal_def.get("roles")
        # Role filter
        if role is not None and allowed_roles is not None and role not in allowed_roles:
            continue
        for pattern in patterns:
            if re.search(pattern, clean_lower):
                signals.append(signal_type)
                break  # One match per type is enough

    # Role-aware priority reorder. callers use signals[0] as the "primary" signal
    # type for naming and importance weighting. Without this reorder the dict
    # iteration order wins, which put correction before self_reflection — so
    # every assistant "I was wrong" was classified as correction instead of
    # self_reflection (Phase 1 retrolearn finding, 2026-04-10).
    _role_priority = {
        "assistant": ["self_reflection", "correction", "fix", "discovery", "decision", "completion", "praise"],
        "user":      ["praise", "correction", "fix", "discovery", "decision", "completion", "self_reflection"],
        "human":     ["praise", "correction", "fix", "discovery", "decision", "completion", "self_reflection"],
    }
    if role in _role_priority and signals:
        priority = _role_priority[role]
        signals.sort(key=lambda s: priority.index(s) if s in priority else 999)
    return signals


def extract_learnings(messages: list) -> list:
    """Extract learnings from a list of transcript messages."""
    learnings = []
    seen_hashes = set()

    for msg in messages:
        # Claude Code JSONL uses "type" at top level AND "role" inside "message"
        role = msg.get("role", msg.get("type", "unknown"))
        inner = msg.get("message")
        if isinstance(inner, dict) and inner.get("role"):
            role = inner["role"]

        # Only analyze human and assistant messages, not raw tool results
        if role not in ("human", "user", "assistant"):
            continue

        text = extract_text_from_message(msg)
        if len(text) < MIN_MSG_LENGTH:
            continue

        signals = detect_signals(text, role=role)

        if not signals:
            continue

        # Create a dedup hash from first 200 chars
        content_hash = hashlib.md5(text[:200].encode()).hexdigest()[:10]
        if content_hash in seen_hashes:
            continue
        seen_hashes.add(content_hash)

        # Build the learning content — truncate to reasonable size
        # Use first 500 chars as the core content
        content_preview = text[:500].strip()
        if len(text) > 500:
            content_preview += "..."

        primary_signal = signals[0]  # Most important signal type
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")

        learnings.append({
            "name": f"conv_{primary_signal}_{content_hash}",
            "type": primary_signal,
            "content": content_preview,
            "signals": signals,
            "role": role,
            "importance": _signal_importance(signals),
            "tags": f"realtime,{primary_signal},conversation,auto-extracted",
            "line_num": msg.get("_line_num", 0),
        })

    # Cap at max per run
    if len(learnings) > MAX_LEARNINGS_PER_RUN:
        # Prioritize by importance
        learnings.sort(key=lambda l: l["importance"], reverse=True)
        learnings = learnings[:MAX_LEARNINGS_PER_RUN]

    return learnings


def _signal_importance(signals: list) -> float:
    """Calculate importance based on signal types (config-driven weights)."""
    # Map signal type names (singular in code) to config keys (plural in config)
    _type_to_cfg = {
        "correction": "corrections",
        "fix": "fixes",
        "discovery": "discoveries",
        "decision": "decisions",
        "completion": "completions",
        "self_reflection": "self_reflections",
        "praise": "praise",
    }
    imp_cfg = _learn_cfg.get('importance', {})
    weights = {
        stype: imp_cfg.get(cfg_key, 0.5)
        for stype, cfg_key in _type_to_cfg.items()
    }
    return max(weights.get(s, 0.5) for s in signals) if signals else 0.5


# ---------------------------------------------------------------------------
# Completion event gating
# ---------------------------------------------------------------------------

# Keywords that indicate a completion carries a reusable pattern or belief change.
_REUSABLE_INSIGHT_RE = re.compile(
    r"(?:pattern|always|never|rule|lesson|insight|realized|because|root cause|"
    r"trick|workaround|best practice|anti-?pattern|important|remember)",
    re.IGNORECASE,
)


def _completion_has_reusable_insight(learning: dict) -> bool:
    """Return True if a completion event contains a standing belief or reusable pattern.

    Plain session summaries and task-done logs return False and should go to
    execution_log instead of the memories table.
    """
    # Session summaries that extracted learnings are worth keeping
    if learning.get("learnings_count", 0) > 0:
        return True
    content = learning.get("content", "")
    # Check for reusable-pattern keywords in content
    if _REUSABLE_INSIGHT_RE.search(content):
        return True
    return False


# ---------------------------------------------------------------------------
# Save to DB
# ---------------------------------------------------------------------------

def save_learnings(learnings: list, mode: str = "realtime") -> int:
    """Save extracted learnings to aibrain.db. Returns count saved.

    Goes through aibrain_db.create_memory() so every write gets:
      - canonical_dedup (semantic + prediction-error gating)
      - embedding generation + memories_vec insert
      - satellite routing
      - event bus emission

    History: until 2026-04-10 this function did raw INSERT INTO memories,
    bypassing the embedding pipeline entirely. Result: ~44 vectorless
    rows/hour in active memory + silent semantic-search degradation.
    Same class as the Apr 6-10 lobotomy bug — silent inconsistency
    between two writers. Fixed by routing through the canonical writer.
    """
    if not learnings:
        return 0

    try:
        conn = sqlite3.connect(str(DB_PATH), timeout=3)
        conn.row_factory = sqlite3.Row
    except Exception as e:
        print(f"[REALTIME LEARNER] DB connect failed: {e} (path={DB_PATH})", file=sys.stderr)
        return 0

    # Fast-path: skip names that are already known auto-extracted memories.
    # canonical_dedup would also catch these semantically, but the name
    # check avoids paying the embedding cost for guaranteed dupes.
    existing = set()
    try:
        for row in conn.execute(
            "SELECT name FROM memories WHERE active=1 AND tags LIKE '%auto-extracted%'"  # noqa:LIKE WILDCARD INJECTION
        ).fetchall():
            existing.add(row[0])
    except Exception:
        pass

    # Lazy import — keeps the cold-import path fast for the hook entrypoint
    # that doesn't always need the full aibrain_db machinery.
    try:
        import aibrain_db as _adb
    except Exception as e:
        print(f"[REALTIME LEARNER] aibrain_db import failed: {e}", file=sys.stderr)
        conn.close()
        return 0

    saved = 0
    for l in learnings:
        if l["name"] in existing:
            continue

        # Gate: plain completion events go to execution_log, not memories.
        # Only completions that carry reusable learnings get promoted to memories.
        if l["type"] == "completion" and not _completion_has_reusable_insight(l):
            try:
                conn.execute("""
                    INSERT INTO execution_log (action, success, quality_score, task_type, created_at)
                    VALUES (?, 1, ?, ?, datetime('now'))
                """, (
                    f"[{mode}] {l['name']}",
                    l.get("importance", 0.3),
                    "completion",
                ))
                conn.commit()
            except Exception:
                pass
            saved += 1
            continue

        # Canonical write path — embedding + dedup + satellite routing.
        # source_agent='realtime_learner' enforces attribution for learning
        # signals (correction/feedback/praise/self_reflection) — the Apr 11
        # backfill revealed 1,171 NULL source_agent rows traced back here.
        try:
            result = _adb.create_memory(
                name=l["name"],
                mem_type=l["type"],
                content=f"[{mode}] {l['content']}",
                tags=l["tags"],
                memory_class="episodic",
                importance=l["importance"],
                source_agent="realtime_learner",
            )
            # create_memory returns int (new id) OR dict (dedup action).
            # Both count as "handled" — only true exceptions are failures.
            if result:
                saved += 1
        except Exception as e:
            print(f"[REALTIME LEARNER] create_memory failed: {e} name={l['name']}", file=sys.stderr)  # noqa:SQL F-STRING
            continue

    conn.close()
    return saved


# ---------------------------------------------------------------------------
# Session summary (for Stop hook)
# ---------------------------------------------------------------------------

def build_session_summary(messages: list) -> dict:
    """Build a concise session summary from full transcript."""
    # Count message types
    user_msgs = [m for m in messages if m.get("role") == "human" or m.get("role") == "user"]
    assistant_msgs = [m for m in messages if m.get("role") == "assistant"]
    tool_uses = [m for m in messages if m.get("role") == "tool" or m.get("type") == "tool_result"]

    # Extract all learnings
    learnings = extract_learnings(messages)

    # Get last user message for context
    last_user = ""
    if user_msgs:
        last_user = extract_text_from_message(user_msgs[-1])[:200]

    return {
        "name": f"session_summary_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}",
        "type": "completion",
        "content": (
            f"Session: {len(user_msgs)} user msgs, {len(assistant_msgs)} assistant msgs, "
            f"{len(tool_uses)} tool calls. "
            f"Learnings extracted: {len(learnings)} "
            f"({', '.join(set(l['type'] for l in learnings)) if learnings else 'none'}). "
            f"Last topic: {last_user[:150]}"
        ),
        "tags": "session,summary,auto-extracted",
        "importance": 0.3,
        "learnings_count": len(learnings),
    }


# ---------------------------------------------------------------------------
# Hook entry points
# ---------------------------------------------------------------------------

def run_posttool(hook_input: dict) -> dict:
    """PostToolUse hook — lightweight scan of new transcript lines."""
    transcript_path = hook_input.get("transcript_path", "")
    session_id = hook_input.get("session_id", "unknown")

    if not transcript_path or not Path(transcript_path).exists():
        return {"saved": 0}

    state = _load_state()
    last_line = state.get(f"last_line_{session_id}", 0)

    # Read only new lines since last check
    new_msgs = read_transcript(transcript_path, start_line=last_line)
    if not new_msgs:
        return {"saved": 0}

    # Update last-read position
    max_line = max(m.get("_line_num", 0) for m in new_msgs)
    state[f"last_line_{session_id}"] = max_line + 1
    _save_state(state)

    # Extract and save
    learnings = extract_learnings(new_msgs)
    saved = save_learnings(learnings, mode="posttool")

    return {"saved": saved, "scanned": len(new_msgs), "found": len(learnings)}


def run_precompact(hook_input: dict) -> dict:
    """PreCompact hook — thorough scan of ENTIRE transcript before context dies."""
    transcript_path = hook_input.get("transcript_path", "")

    if not transcript_path or not Path(transcript_path).exists():
        return {"saved": 0}

    # Read ALL messages (this is our last chance before compaction)
    all_msgs = read_transcript(transcript_path, start_line=0)
    if not all_msgs:
        return {"saved": 0}

    # Extract with higher limit for precompact (config-driven)
    global MAX_LEARNINGS_PER_RUN
    old_max = MAX_LEARNINGS_PER_RUN
    MAX_LEARNINGS_PER_RUN = _learn_cfg.get('precompact_limit', 25)
    learnings = extract_learnings(all_msgs)
    MAX_LEARNINGS_PER_RUN = old_max

    saved = save_learnings(learnings, mode="precompact")

    # Fact extraction — additional signal source
    fact_saved = 0
    try:
        from aibrain.core.fact_extractor import extract_facts_from_messages
        facts = extract_facts_from_messages(all_msgs)
        fact_saved = save_learnings(facts, mode="fact_extract")
    except Exception:
        pass  # Fact extraction is best-effort

    # Also run mini evolution (passage extraction for recent memories)
    evo_result = _run_mini_evolution()

    return {
        "saved": saved + fact_saved,
        "scanned": len(all_msgs),
        "found": len(learnings),
        "facts_extracted": fact_saved,
        "evolution": evo_result,
    }


def run_stop(hook_input: dict) -> dict:
    """Stop hook — save session summary."""
    transcript_path = hook_input.get("transcript_path", "")

    if not transcript_path or not Path(transcript_path).exists():
        return {"saved": 0}

    all_msgs = read_transcript(transcript_path, start_line=0)
    if not all_msgs:
        return {"saved": 0}

    # Build and save session summary
    summary = build_session_summary(all_msgs)
    saved = save_learnings([summary], mode="session_end")

    # Also extract any remaining learnings
    learnings = extract_learnings(all_msgs)
    saved += save_learnings(learnings, mode="session_end")

    # Fact extraction — additional signal source
    try:
        from aibrain.core.fact_extractor import extract_facts_from_messages
        facts = extract_facts_from_messages(all_msgs)
        saved += save_learnings(facts, mode="fact_extract")
    except Exception:
        pass  # Fact extraction is best-effort

    # Clean up state for this session
    session_id = hook_input.get("session_id", "")
    if session_id:
        state = _load_state()
        state.pop(f"last_line_{session_id}", None)
        _save_state(state)

    return {"saved": saved}


# ---------------------------------------------------------------------------
# Mini evolution (preserved from existing precompact hook)
# ---------------------------------------------------------------------------

def _run_mini_evolution() -> str:
    """Extract passages from recent memories that don't have them yet."""
    try:
        conn = sqlite3.connect(str(DB_PATH), timeout=3)

        recent = conn.execute("""
            SELECT m.id, m.name, m.content FROM memories m
            WHERE m.active=1
            AND m.updated > datetime('now', '-2 hours')
            AND m.id NOT IN (SELECT DISTINCT memory_id FROM memory_passages)
            LIMIT 20
        """).fetchall()

        passages_added = 0
        for mid, name, content in recent:
            if not content:
                continue
            chunks = [p.strip() for p in content.split('\n') if len(p.strip()) > 20]
            for i, chunk in enumerate(chunks[:10]):
                conn.execute(
                    "INSERT INTO memory_passages (memory_id, passage_index, content) VALUES (?, ?, ?)",
                    (mid, i, chunk[:500])
                )
                passages_added += 1

        if passages_added:
            conn.execute("""
                INSERT INTO activity (timestamp, agent, action, category, detail, status)
                VALUES (datetime('now'), ?, 'evolution_mini', 'system', ?, 'complete')
            """, (os.environ.get("AGENT_ID", "agent"), json.dumps({"trigger": "precompact", "passages": passages_added})))

        conn.commit()
        conn.close()
        return f"{passages_added} passages from {len(recent)} memories"
    except Exception as e:
        return f"error: {e}"


# ---------------------------------------------------------------------------
# Watch mode — generic background poller for ANY AI system
# ---------------------------------------------------------------------------

def _discover_log_dirs() -> list:
    """Auto-discover conversation log directories for various AI systems."""
    dirs = []
    home = Path.home()

    # Claude Code sessions (all platforms)
    for candidate in [
        home / ".claude" / "projects",
        home / ".claude",
    ]:
        if candidate.exists():
            dirs.append(candidate)

    # ChatGPT exports (common download location)
    for candidate in [
        home / "Downloads",
        home / "Documents" / "ChatGPT",
    ]:
        if candidate.exists():
            dirs.append(candidate)

    # Cursor / Windsurf / other IDE AI logs
    for candidate in [
        home / ".cursor" / "logs",
        home / ".windsurf" / "logs",
        home / ".continue" / "sessions",
    ]:
        if candidate.exists():
            dirs.append(candidate)

    # User-configured log directories from config.json
    cfg = {}
    cfg_path = AIBRAIN_ROOT / "config.json"
    if cfg_path.exists():
        try:
            cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
        except Exception:
            pass
    extra = cfg.get("conversation_log_dirs", [])
    for d in extra:
        p = Path(d).expanduser()
        if p.exists():
            dirs.append(p)

    return dirs


def _find_log_files(dirs: list, since_hours: float = 4) -> list:
    """Find conversation log files modified within the last N hours."""
    import time
    cutoff = time.time() - (since_hours * 3600)
    files = []
    extensions = {".jsonl", ".json", ".txt", ".md", ".log"}

    for d in dirs:
        if not d.exists():
            continue
        try:
            for f in d.rglob("*"):
                if f.is_file() and f.suffix in extensions and f.stat().st_mtime > cutoff:
                    # Skip tiny files and known non-conversation files
                    if f.stat().st_size > 100 and f.name not in ("MEMORY.md", "compaction_log.md"):
                        files.append(f)
        except PermissionError:
            continue

    return sorted(files, key=lambda f: f.stat().st_mtime, reverse=True)


def parse_generic_log(path: Path) -> list:
    """Parse conversation logs in various formats into normalized messages."""
    messages = []
    suffix = path.suffix.lower()

    try:
        if suffix == ".jsonl":
            # JSONL — Claude Code format, one JSON object per line
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                for i, line in enumerate(f):
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        msg = json.loads(line)
                        msg["_line_num"] = i
                        msg["_source"] = str(path)
                        messages.append(msg)
                    except json.JSONDecodeError:
                        continue

        elif suffix == ".json":
            # Full JSON — ChatGPT export format or generic
            data = json.loads(path.read_text(encoding="utf-8", errors="replace"))
            if isinstance(data, list):
                # Array of messages
                for i, msg in enumerate(data):
                    if isinstance(msg, dict):
                        msg["_line_num"] = i
                        msg["_source"] = str(path)
                        messages.append(msg)
            elif isinstance(data, dict):
                # ChatGPT export: {"mapping": {...}} structure
                mapping = data.get("mapping", {})
                if mapping:
                    for node_id, node in mapping.items():
                        msg_data = node.get("message")
                        if msg_data and isinstance(msg_data, dict):
                            content = msg_data.get("content", {})
                            parts = content.get("parts", [])
                            text = " ".join(str(p) for p in parts if p)
                            if text:
                                messages.append({
                                    "role": msg_data.get("author", {}).get("role", "unknown"),
                                    "content": text,
                                    "_source": str(path),
                                })
                else:
                    # Single conversation object with messages array
                    for key in ("messages", "conversation", "transcript", "chat"):
                        if key in data and isinstance(data[key], list):
                            for i, msg in enumerate(data[key]):
                                if isinstance(msg, dict):
                                    msg["_line_num"] = i
                                    msg["_source"] = str(path)
                                    messages.append(msg)
                            break

        elif suffix in (".txt", ".md", ".log"):
            # Plain text — treat each paragraph as a message
            text = path.read_text(encoding="utf-8", errors="replace")
            paragraphs = re.split(r"\n\s*\n", text)
            for i, para in enumerate(paragraphs):
                para = para.strip()
                if len(para) > MIN_MSG_LENGTH:
                    messages.append({
                        "role": "unknown",
                        "content": para,
                        "_line_num": i,
                        "_source": str(path),
                    })

    except Exception:
        pass

    return messages


def run_watch(log_dirs: list = None, interval_min: int = 15, once: bool = False):
    """Watch mode — poll log directories and extract learnings periodically.

    Args:
        log_dirs: Directories to watch (auto-discovered if None)
        interval_min: Minutes between polls
        once: If True, run once and exit (for cron use)
    """
    import time

    if not log_dirs:
        log_dirs = _discover_log_dirs()

    if not log_dirs:
        print("No conversation log directories found. Configure 'conversation_log_dirs' in config.json.")
        return

    print(f"AIBrain Realtime Learner — watching {len(log_dirs)} directories")
    for d in log_dirs:
        print(f"  {d}")
    print(f"  Poll interval: {interval_min} min | DB: {DB_PATH}")
    print()

    while True:
        state = _load_state()
        total_saved = 0
        total_scanned = 0

        files = _find_log_files(log_dirs, since_hours=4)
        for f in files[:50]:  # Cap at 50 files per cycle
            file_key = f"watched_{hashlib.md5(str(f).encode()).hexdigest()[:12]}"
            last_size = state.get(file_key, 0)
            current_size = f.stat().st_size

            if current_size <= last_size:
                continue  # No new content

            msgs = parse_generic_log(f)
            if not msgs:
                continue

            # Only process messages after the last-seen position
            # For JSONL, use line numbers; for others, use all if file grew
            if last_size > 0 and f.suffix == ".jsonl":
                last_line = state.get(f"{file_key}_line", 0)
                msgs = [m for m in msgs if m.get("_line_num", 0) >= last_line]

            learnings = extract_learnings(msgs)
            saved = save_learnings(learnings, mode="watcher")
            total_saved += saved
            total_scanned += len(msgs)

            # Update state
            state[file_key] = current_size
            if msgs:
                state[f"{file_key}_line"] = max(m.get("_line_num", 0) for m in msgs) + 1

        _save_state(state)

        ts = datetime.now().strftime("%H:%M:%S")
        if total_saved > 0 or total_scanned > 0:
            print(f"  [{ts}] Scanned {total_scanned} messages from {len(files)} files, saved {total_saved} learnings")
        else:
            print(f"  [{ts}] No new content")

        if once:
            break

        time.sleep(interval_min * 60)


def run_scan(path: str) -> dict:
    """One-shot scan of a file or directory."""
    p = Path(path)
    files = []
    if p.is_file():
        files = [p]
    elif p.is_dir():
        files = _find_log_files([p], since_hours=9999)  # No time limit for explicit scan

    total_saved = 0
    total_found = 0
    for f in files:
        msgs = parse_generic_log(f)
        learnings = extract_learnings(msgs)
        saved = save_learnings(learnings, mode="scan")
        total_saved += saved
        total_found += len(learnings)
        if learnings:
            print(f"  {f.name}: {len(learnings)} learnings ({saved} new)")

    return {"files": len(files), "found": total_found, "saved": total_saved}


def run_learn_history() -> dict:
    """Scan ALL historical conversation transcripts and training data.

    Discovers transcripts from Claude Code, ChatGPT, Cursor, and any
    configured log directories. Also imports training pair JSONL files
    (instruction/response format used for fine-tuning datasets).

    This is the "learn from your past" feature — run once after install
    to bootstrap your brain from existing conversations.
    """
    global MAX_LEARNINGS_PER_RUN
    old_max = MAX_LEARNINGS_PER_RUN
    MAX_LEARNINGS_PER_RUN = 50  # Higher limit for historical scan

    print("AIBrain — Learning from conversation history")
    print(f"  DB: {DB_PATH}")
    print()

    # Discover all transcript sources
    log_dirs = _discover_log_dirs()
    all_files = _find_log_files(log_dirs, since_hours=999999)  # No time limit

    # Also find training pair files (instruction/response JSONL)
    training_dirs = []
    # Standard location: AIBRAIN_ROOT/training_data/
    for candidate in [AIBRAIN_ROOT / "training_data"]:
        if candidate.exists():
            training_dirs.append(candidate)
    # Config-specified additional training dirs
    try:
        config_path = AIBRAIN_ROOT / "config.json"
        if config_path.exists():
            cfg = json.loads(config_path.read_text())
            for extra in cfg.get("training_data_dirs", []):
                p = Path(extra).expanduser()
                if p.exists():
                    training_dirs.append(p)
    except Exception:
        pass

    training_files = []
    for d in training_dirs:
        for f in d.rglob("*.jsonl"):
            training_files.append(f)

    # Import training pairs directly (they're curated — no signal filtering needed)
    training_saved = 0
    if training_files:
        print(f"  Importing {len(training_files)} training pair files...")
        training_saved = _import_training_pairs(training_files)
        print(f"  Imported {training_saved} training pairs as memories")
        print()

    # Sort conversation files by size descending (biggest sessions first)
    all_files.sort(key=lambda f: f.stat().st_size, reverse=True)

    print(f"  Found {len(all_files)} conversation transcript files")
    print()

    total_saved = 0
    total_found = 0
    files_with_learnings = 0

    for f in all_files:
        size_mb = f.stat().st_size / 1024 / 1024

        # Try conversation format first
        msgs = parse_generic_log(f)

        # If no messages found, try training pair format
        if not msgs:
            msgs = _parse_training_pairs(f)

        if not msgs:
            continue

        learnings = extract_learnings(msgs)
        if not learnings:
            continue

        saved = save_learnings(learnings, mode="historical_scan")
        total_found += len(learnings)
        total_saved += saved
        files_with_learnings += 1

        if saved > 0:
            print(f"  {f.name} ({size_mb:.1f}MB): {len(learnings)} found, {saved} new")

    MAX_LEARNINGS_PER_RUN = old_max

    grand_total = total_saved + training_saved
    print(f"\n  Conversation files: {len(all_files)} ({files_with_learnings} with learnings)")
    print(f"  Conversation learnings: {total_found} found, {total_saved} new")
    print(f"  Training pairs imported: {training_saved}")
    print(f"  Grand total new memories: {grand_total}")

    return {"files": len(all_files) + len(training_files),
            "found": total_found, "saved": grand_total}


def _parse_training_pairs(path: Path) -> list:
    """Parse training pair JSONL files (instruction/response format).

    Training pairs typically have:
    - {"instruction": "...", "response": "..."}
    - {"prompt": "...", "completion": "..."}
    - {"input": "...", "output": "..."}
    - {"messages": [{"role": "user", ...}, {"role": "assistant", ...}]}
    """
    messages = []
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            for i, line in enumerate(f):
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                except json.JSONDecodeError:
                    continue

                # Format 1: instruction/response
                if "instruction" in obj and "response" in obj:
                    messages.append({
                        "role": "user",
                        "content": obj["instruction"],
                        "_line_num": i,
                    })
                    messages.append({
                        "role": "assistant",
                        "content": obj["response"],
                        "_line_num": i,
                    })

                # Format 2: prompt/completion
                elif "prompt" in obj and "completion" in obj:
                    messages.append({
                        "role": "user",
                        "content": obj["prompt"],
                        "_line_num": i,
                    })
                    messages.append({
                        "role": "assistant",
                        "content": obj["completion"],
                        "_line_num": i,
                    })

                # Format 3: input/output
                elif "input" in obj and "output" in obj:
                    messages.append({
                        "role": "user",
                        "content": obj["input"],
                        "_line_num": i,
                    })
                    messages.append({
                        "role": "assistant",
                        "content": obj["output"],
                        "_line_num": i,
                    })

                # Format 4: messages array (ChatML)
                elif "messages" in obj and isinstance(obj["messages"], list):
                    for msg in obj["messages"]:
                        if isinstance(msg, dict) and "content" in msg:
                            messages.append({
                                "role": msg.get("role", "user"),
                                "content": msg["content"],
                                "_line_num": i,
                            })

    except (FileNotFoundError, OSError):
        pass

    return messages


def _import_training_pairs(training_files: list) -> int:
    """Directly import training pair JSONL files into the training_pairs satellite DB.

    Training pairs are curated data — they bypass signal detection and get
    imported directly. Each pair becomes one memory with prompt+response
    combined as content. Stored in a dedicated satellite DB to avoid bloating main.

    Deduplication: uses a content hash to avoid re-importing on subsequent runs.
    """
    # Route to satellite DB — create if it doesn't exist
    try:
        from aibrain_db import satellite_list, satellite_register, _get_satellite_db, SATELLITE_TEMPLATES
        existing_sats = {s["name"] for s in satellite_list()}
        if "training_pairs" not in existing_sats:
            tmpl = SATELLITE_TEMPLATES["training"]
            satellite_register(
                tmpl["name"], tmpl["db_path"], tmpl["desc"],
                tmpl["types"], tmpl["keywords"]
            )
            print("[REALTIME LEARNER] Created training_pairs satellite DB")
        conn = _get_satellite_db("training_pairs")
    except Exception as e:
        # Fallback to main DB if satellite system unavailable
        print(f"[REALTIME LEARNER] Satellite fallback to main DB: {e}", file=sys.stderr)
        try:
            conn = sqlite3.connect(str(DB_PATH), timeout=5)
            conn.row_factory = sqlite3.Row
        except Exception as e2:
            print(f"[REALTIME LEARNER] DB connect failed: {e2}", file=sys.stderr)
            return 0

    # Load existing training-import hashes for dedup
    existing_hashes = set()
    try:
        for row in conn.execute(
            "SELECT name FROM memories WHERE active=1 AND tags LIKE '%training-import%'"  # noqa:LIKE WILDCARD INJECTION
        ).fetchall():
            existing_hashes.add(row[0])
    except Exception:
        pass

    # Domain -> memory type mapping
    domain_type_map = {
        "security": "reference",
        "operations": "reference",
        "philosophy": "user",
        "engineering": "reference",
        "lessons": "feedback",
        "handovers": "project",
    }

    saved = 0
    for filepath in training_files:
        source_name = filepath.stem  # e.g. "playbook", "philosophy"
        try:
            with open(filepath, "r", encoding="utf-8", errors="replace") as f:
                for i, line in enumerate(f):
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        obj = json.loads(line)
                    except json.JSONDecodeError:
                        continue

                    # Extract prompt/response (or other formats)
                    prompt = obj.get("prompt") or obj.get("instruction") or obj.get("input", "")
                    response = obj.get("response") or obj.get("completion") or obj.get("output", "")

                    if not prompt or not response:
                        # Try ChatML messages format
                        msgs = obj.get("messages", [])
                        if isinstance(msgs, list) and len(msgs) >= 2:
                            prompt = msgs[0].get("content", "")
                            response = msgs[-1].get("content", "")
                        if not prompt or not response:
                            continue

                    # Build content and dedup key
                    content_hash = hashlib.md5(
                        (prompt[:200] + response[:200]).encode()
                    ).hexdigest()[:12]
                    name = f"tp:{source_name}:{content_hash}"

                    if name in existing_hashes:
                        continue

                    # Determine type from domain metadata or source filename
                    domain = obj.get("domain", source_name)
                    mem_type = domain_type_map.get(domain, "reference")

                    # Build tags
                    pair_tags = obj.get("tags", [])
                    if isinstance(pair_tags, str):
                        pair_tags = [pair_tags]
                    tags = json.dumps(["training-import", f"source:{source_name}",
                                       f"domain:{domain}"] + pair_tags)

                    # Truncate prompt for the content — keep full response
                    prompt_summary = prompt[:300]
                    if len(prompt) > 300:
                        prompt_summary += "..."
                    content = f"Q: {prompt_summary}\n\nA: {response}"

                    # Importance: curated data is high-value
                    importance = 0.7

                    try:
                        conn.execute("""
                            INSERT INTO memories (name, type, memory_class, tags, content,
                                                  importance, created, updated, active)
                            VALUES (?, ?, 'reference', ?, ?, ?, datetime('now'), datetime('now'), 1)
                        """, (name, mem_type, tags, content, importance))
                        saved += 1
                        existing_hashes.add(name)
                    except Exception as e:
                        print(f"[REALTIME LEARNER] Training import INSERT failed: {e}",  # noqa:SQL F-STRING
                              file=sys.stderr)
                        continue

        except (FileNotFoundError, OSError) as e:
            print(f"[REALTIME LEARNER] Could not read {filepath}: {e}", file=sys.stderr)
            continue

    try:
        conn.commit()
    except Exception as e:
        print(f"[REALTIME LEARNER] Training import COMMIT failed: {e}", file=sys.stderr)
    conn.close()

    return saved


# ---------------------------------------------------------------------------
# Main — multi-mode entry point
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="AIBrain real-time learning extractor (agent-agnostic)"
    )
    parser.add_argument("--watch", action="store_true",
                        help="Watch mode: poll log directories continuously")
    parser.add_argument("--interval", type=int,
                        default=_learn_cfg.get('watch_interval_min', 15),
                        help="Watch poll interval in minutes (default: from config or 15)")
    parser.add_argument("--log-dirs", nargs="*",
                        help="Directories to watch for conversation logs")
    parser.add_argument("--scan", metavar="PATH",
                        help="One-shot scan of a file or directory")
    parser.add_argument("--learn-history", action="store_true",
                        help="Scan ALL historical conversation transcripts and extract learnings")
    parser.add_argument("--transcript", help="Path to transcript JSONL (legacy)")
    parser.add_argument("--mode", choices=["posttool", "precompact", "stop"],
                        default="posttool", help="Hook mode (Claude Code)")
    parser.add_argument("--once", action="store_true",
                        help="Run watch mode once and exit (for cron)")
    parser.add_argument("--test", action="store_true", help="Run self-test")
    args = parser.parse_args()

    if args.test:
        _self_test()
        return

    if args.watch or args.once:
        dirs = [Path(d) for d in args.log_dirs] if args.log_dirs else None
        run_watch(log_dirs=dirs, interval_min=args.interval, once=args.once)
        return

    if args.scan:
        result = run_scan(args.scan)
        print(f"\nScan complete: {result['files']} files, {result['found']} learnings, {result['saved']} saved")
        return

    if args.learn_history:
        result = run_learn_history()
        print(f"\nHistory scan complete: {result['files']} files, "
              f"{result['found']} learnings, {result['saved']} new saved to DB")
        return

    if args.transcript:
        # Legacy standalone mode
        hook_input = {"transcript_path": args.transcript, "session_id": "standalone"}
        if args.mode == "precompact":
            result = run_precompact(hook_input)
        elif args.mode == "stop":
            result = run_stop(hook_input)
        else:
            result = run_posttool(hook_input)
        print(json.dumps(result, indent=2))
        return

    # No explicit mode — check if we're being called as a hook (stdin has JSON)
    stdin_data = ""
    try:
        if not sys.stdin.isatty():
            stdin_data = sys.stdin.read()
    except Exception:
        pass

    if stdin_data.strip():
        hook_input = {}
        try:
            hook_input = json.loads(stdin_data)
        except json.JSONDecodeError:
            pass

        hook_event = hook_input.get("hook_event_name", "").lower()

        if "compact" in hook_event:
            result = run_precompact(hook_input)
            msg = (
                f"[REALTIME LEARNER] PreCompact: extracted {result['found']} learnings, "
                f"saved {result['saved']} to aibrain.db. Evolution: {result.get('evolution', 'skipped')}. "
                f"SAVE any remaining important context to memory NOW."
            )
            output = {
                "hookSpecificOutput": {
                    "hookEventName": "PreCompact",
                    "additionalContext": msg,
                }
            }
            print(json.dumps(output))

        elif "stop" in hook_event:
            result = run_stop(hook_input)
            print(f"[REALTIME LEARNER] Session end: saved {result['saved']} learnings to aibrain.db")

        elif "tool" in hook_event:
            result = run_posttool(hook_input)
            if result["saved"] > 0:
                output = {
                    "hookSpecificOutput": {
                        "hookEventName": "PostToolUse",
                        "additionalContext": (
                            f"[REALTIME LEARNER] Captured {result['saved']} new learnings from conversation."
                        ),
                    }
                }
                print(json.dumps(output))

        else:
            result = run_posttool(hook_input)

    else:
        # No stdin, no args — show help
        parser.print_help()


def _self_test():
    """Quick self-test with synthetic data."""
    test_messages = [
        {"role": "user", "content": "The job search is returning 0 results, it was working before"},
        {"role": "assistant", "content": "I found the bug — headless=True gets blocked by Cloudflare bot detection. Fixed by switching to headless=False with anti-detection args. The root cause was that Indeed and Seek added stricter bot checks since March 18."},
        {"role": "user", "content": "Good, that fix works now. Also turns out entity_h 40 RCE was false positives from docker bridge self-loop, not a real regression."},
        {"role": "assistant", "content": "Correction noted — the 40 RCE / 51 owned was phantom data from docker bridge IP appearing as pivot target. Real count after dedup fix was ~10 RCE / 13 owned. This was actually documented in L22 but I didn't check."},
        {"role": "assistant", "content": "Decided to use config.json for all user-specific settings because hardcoding Adelaide/cyber queries means every user has to edit source code. Config-driven with generic defaults is the right approach."},
    ]

    learnings = extract_learnings(test_messages)
    print(f"Self-test: {len(test_messages)} messages -> {len(learnings)} learnings")
    for l in learnings:
        print(f"  [{l['type']:12s}] {l['name']} (importance={l['importance']:.1f})")
        print(f"    signals: {l['signals']}")
        print(f"    {l['content'][:100]}...")
    print("\nDB path:", DB_PATH)
    print("State file:", STATE_FILE)
    print("Self-test PASSED" if learnings else "Self-test FAILED — no learnings extracted")


if __name__ == "__main__":
    main()
