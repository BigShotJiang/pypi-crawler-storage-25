#!/usr/bin/env python3
"""
attack_graph.py — ATT&CK Knowledge Graph for AIBrain

Downloads MITRE ATT&CK STIX bundle, builds a SQLite graph with FTS5,
and provides query functions for techniques, mitigations, attack chains.

Inspired by TITAN (Simoni et al. 2025, arXiv:2510.14670) but lighter:
pure SQLite + stdlib, no Neo4j dependency.

Usage:
    python attack_graph.py build              # Download STIX + build graph
    python attack_graph.py search "phishing"  # FTS5 search
    python attack_graph.py technique T1566    # Full technique info
    python attack_graph.py mitigations T1566  # Mitigations for technique
    python attack_graph.py tactic initial-access  # Techniques by tactic
    python attack_graph.py related <stix-id>  # Related nodes
    python attack_graph.py chain <start> <end> [max_depth]  # Path finding
    python attack_graph.py stats              # Graph statistics
"""

import json
import os
import sqlite3
import sys
import threading
import urllib.request
from collections import deque
from datetime import datetime, timezone
from pathlib import Path
from textwrap import shorten

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
STIX_URL = (
    "https://raw.githubusercontent.com/mitre/cti/master/"
    "enterprise-attack/enterprise-attack.json"
)

def _resolve_root():
    """Use the canonical resolver — see aibrain_db.AIBRAIN_ROOT."""
    from aibrain_db import AIBRAIN_ROOT as _AR
    return _AR

AIBRAIN_ROOT = _resolve_root()
DB_PATH = Path(os.environ.get("ATTACK_GRAPH_DB",
                               AIBRAIN_ROOT / "attack_graph.db"))
CACHE_PATH = AIBRAIN_ROOT / "enterprise-attack.json"

_lock = threading.Lock()
_conn = None


# ---------------------------------------------------------------------------
# Database connection
# ---------------------------------------------------------------------------
def get_db() -> sqlite3.Connection:
    """Thread-safe singleton connection with WAL mode."""
    global _conn
    if _conn is not None:
        return _conn
    with _lock:
        if _conn is not None:
            return _conn
        DB_PATH.parent.mkdir(parents=True, exist_ok=True)
        _conn = sqlite3.connect(str(DB_PATH), check_same_thread=False)
        _conn.execute("PRAGMA journal_mode=WAL")
        _conn.execute("PRAGMA foreign_keys=ON")
        _conn.row_factory = sqlite3.Row
        _init_schema(_conn)
        return _conn


def _init_schema(conn: sqlite3.Connection):
    """Create tables if they don't exist."""
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS attack_nodes (
            id TEXT PRIMARY KEY,
            type TEXT NOT NULL,
            name TEXT NOT NULL,
            description TEXT DEFAULT '',
            mitre_id TEXT DEFAULT '',
            platforms TEXT DEFAULT '[]',
            tactics TEXT DEFAULT '[]',
            metadata TEXT DEFAULT '{}'
        );

        CREATE TABLE IF NOT EXISTS attack_edges (
            source_id TEXT NOT NULL,
            target_id TEXT NOT NULL,
            relationship TEXT NOT NULL,
            description TEXT DEFAULT '',
            FOREIGN KEY (source_id) REFERENCES attack_nodes(id),
            FOREIGN KEY (target_id) REFERENCES attack_nodes(id)
        );

        CREATE INDEX IF NOT EXISTS idx_edges_source ON attack_edges(source_id);
        CREATE INDEX IF NOT EXISTS idx_edges_target ON attack_edges(target_id);
        CREATE INDEX IF NOT EXISTS idx_edges_rel ON attack_edges(relationship);
        CREATE INDEX IF NOT EXISTS idx_nodes_type ON attack_nodes(type);
        CREATE INDEX IF NOT EXISTS idx_nodes_mitre_id ON attack_nodes(mitre_id);

        CREATE VIRTUAL TABLE IF NOT EXISTS attack_nodes_fts USING fts5(
            name, description, mitre_id
        );

        CREATE TABLE IF NOT EXISTS attack_meta (
            key TEXT PRIMARY KEY,
            value TEXT
        );
    """)


# ---------------------------------------------------------------------------
# Download + Build
# ---------------------------------------------------------------------------
def download_stix(force=False) -> Path:
    """Download enterprise-attack.json, cache locally."""
    if CACHE_PATH.exists() and not force:
        size_mb = CACHE_PATH.stat().st_size / (1024 * 1024)
        print(f"Using cached STIX bundle: {CACHE_PATH} ({size_mb:.1f} MB)")
        return CACHE_PATH

    print(f"Downloading ATT&CK STIX bundle from MITRE...")
    print(f"  URL: {STIX_URL}")

    req = urllib.request.Request(STIX_URL, headers={
        "User-Agent": "AIBrain-AttackGraph/1.0"
    })
    with urllib.request.urlopen(req, timeout=120) as resp:
        data = resp.read()

    CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
    CACHE_PATH.write_bytes(data)
    size_mb = len(data) / (1024 * 1024)
    print(f"  Saved: {CACHE_PATH} ({size_mb:.1f} MB)")
    return CACHE_PATH


def _extract_mitre_id(obj: dict) -> str:
    """Extract MITRE ID (e.g., T1566) from external_references."""
    for ref in obj.get("external_references", []):
        if ref.get("source_name") == "mitre-attack":
            return ref.get("external_id", "")
    return ""


def _extract_tactics(obj: dict) -> list:
    """Extract kill chain phase names (tactics)."""
    phases = obj.get("kill_chain_phases", [])
    return [p.get("phase_name", "") for p in phases
            if p.get("kill_chain_name") == "mitre-attack"]


def _extract_platforms(obj: dict) -> list:
    """Extract platform list."""
    return obj.get("x_mitre_platforms", [])


# STIX types we care about for nodes
_NODE_TYPES = {
    "attack-pattern",   # techniques
    "malware",          # malware
    "tool",             # tools
    "intrusion-set",    # threat groups
    "campaign",         # campaigns
    "course-of-action", # mitigations
    "x-mitre-tactic",   # tactics
    "x-mitre-data-source",
    "x-mitre-data-component",
}


def build_graph(stix_path: Path = None, force=False):
    """Parse STIX bundle and build SQLite graph."""
    if stix_path is None:
        stix_path = download_stix(force=force)

    print(f"Parsing STIX bundle...")
    with open(stix_path, "r", encoding="utf-8") as f:
        bundle = json.load(f)

    objects = bundle.get("objects", [])
    print(f"  Total STIX objects: {len(objects)}")

    db = get_db()

    # Clear existing data for rebuild
    db.execute("DELETE FROM attack_edges")
    db.execute("DELETE FROM attack_nodes")
    db.execute("DELETE FROM attack_nodes_fts")

    # Pass 1: Insert nodes
    node_count = 0
    node_ids = set()
    for obj in objects:
        obj_type = obj.get("type", "")
        if obj_type not in _NODE_TYPES:
            continue
        # Skip revoked/deprecated
        if obj.get("revoked", False) or obj.get("x_mitre_deprecated", False):
            continue

        stix_id = obj.get("id", "")
        name = obj.get("name", "")
        description = obj.get("description", "")
        mitre_id = _extract_mitre_id(obj)
        platforms = json.dumps(_extract_platforms(obj))
        tactics = json.dumps(_extract_tactics(obj))
        metadata = json.dumps(obj, default=str)

        db.execute("""
            INSERT OR REPLACE INTO attack_nodes
            (id, type, name, description, mitre_id, platforms, tactics, metadata)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (stix_id, obj_type, name, description, mitre_id,
              platforms, tactics, metadata))

        # FTS5 (separate table, not content-linked for simplicity)
        db.execute("""
            INSERT INTO attack_nodes_fts (rowid, name, description, mitre_id)
            VALUES (
                (SELECT rowid FROM attack_nodes WHERE id = ?),
                ?, ?, ?
            )
        """, (stix_id, name, description, mitre_id))

        node_ids.add(stix_id)
        node_count += 1

    # Pass 2: Insert edges from relationship objects
    edge_count = 0
    for obj in objects:
        if obj.get("type") != "relationship":
            continue
        if obj.get("revoked", False) or obj.get("x_mitre_deprecated", False):
            continue

        source = obj.get("source_ref", "")
        target = obj.get("target_ref", "")
        rel_type = obj.get("relationship_type", "")
        desc = obj.get("description", "")

        # Only insert edges where both endpoints exist
        if source in node_ids and target in node_ids:
            db.execute("""
                INSERT INTO attack_edges (source_id, target_id, relationship, description)
                VALUES (?, ?, ?, ?)
            """, (source, target, rel_type, desc))
            edge_count += 1

    # Store build metadata
    now = datetime.now(timezone.utc).isoformat()
    db.execute("INSERT OR REPLACE INTO attack_meta VALUES ('built_at', ?)", (now,))
    db.execute("INSERT OR REPLACE INTO attack_meta VALUES ('stix_version',?)",
               (bundle.get("spec_version", "unknown"),))
    db.execute("INSERT OR REPLACE INTO attack_meta VALUES ('node_count', ?)",
               (str(node_count),))
    db.execute("INSERT OR REPLACE INTO attack_meta VALUES ('edge_count', ?)",
               (str(edge_count),))

    db.commit()
    print(f"  Graph built: {node_count} nodes, {edge_count} edges")
    print(f"  Stored in: {DB_PATH}")
    return node_count, edge_count


# ---------------------------------------------------------------------------
# Query Functions
# ---------------------------------------------------------------------------
def attack_search(query: str, limit: int = 20) -> list:
    """FTS5 search across techniques, malware, tools, etc."""
    db = get_db()
    # Use FTS5 match syntax — quote the query for safety
    rows = db.execute("""
        SELECT n.id, n.type, n.name, n.mitre_id, n.tactics,
               snippet(attack_nodes_fts, 1, '>>>', '<<<', '...', 40) as snippet
        FROM attack_nodes_fts fts
        JOIN attack_nodes n ON fts.rowid = n.rowid
        WHERE attack_nodes_fts MATCH ?
        ORDER BY rank
        LIMIT ?
    """, (query, limit)).fetchall()
    return [dict(r) for r in rows]


def attack_technique_info(technique_id: str) -> dict:
    """Get full info for a technique by MITRE ID (e.g., T1566)."""
    db = get_db()
    row = db.execute("""
        SELECT * FROM attack_nodes WHERE mitre_id = ?
    """, (technique_id.upper(),)).fetchone()
    if not row:
        return {}
    result = dict(row)
    # Parse JSON fields
    result["platforms"] = json.loads(result.get("platforms", "[]"))
    result["tactics"] = json.loads(result.get("tactics", "[]"))
    # Get related nodes
    related = db.execute("""
        SELECT e.relationship, n.name, n.mitre_id, n.type, e.target_id
        FROM attack_edges e
        JOIN attack_nodes n ON e.target_id = n.id
        WHERE e.source_id = ?
        UNION ALL
        SELECT e.relationship, n.name, n.mitre_id, n.type, e.source_id
        FROM attack_edges e
        JOIN attack_nodes n ON e.source_id = n.id
        WHERE e.target_id = ?
    """, (row["id"], row["id"])).fetchall()
    result["related"] = [dict(r) for r in related]
    return result


def attack_related(node_id: str, relationship: str = None) -> list:
    """Find all related nodes for a given STIX ID or MITRE ID."""
    db = get_db()
    # Resolve MITRE ID to STIX ID if needed
    if not node_id.startswith(("attack-pattern", "malware", "tool",
                                "intrusion-set", "campaign",
                                "course-of-action", "x-mitre")):
        row = db.execute("SELECT id FROM attack_nodes WHERE mitre_id = ?",
                         (node_id.upper(),)).fetchone()
        if row:
            node_id = row["id"]
        else:
            return []

    if relationship:
        rows = db.execute("""
            SELECT e.relationship, n.id, n.type, n.name, n.mitre_id, 'outgoing' as direction
            FROM attack_edges e JOIN attack_nodes n ON e.target_id = n.id
            WHERE e.source_id = ? AND e.relationship = ?
            UNION ALL
            SELECT e.relationship, n.id, n.type, n.name, n.mitre_id, 'incoming' as direction
            FROM attack_edges e JOIN attack_nodes n ON e.source_id = n.id
            WHERE e.target_id = ? AND e.relationship = ?
        """, (node_id, relationship, node_id, relationship)).fetchall()
    else:
        rows = db.execute("""
            SELECT e.relationship, n.id, n.type, n.name, n.mitre_id, 'outgoing' as direction
            FROM attack_edges e JOIN attack_nodes n ON e.target_id = n.id
            WHERE e.source_id = ?
            UNION ALL
            SELECT e.relationship, n.id, n.type, n.name, n.mitre_id, 'incoming' as direction
            FROM attack_edges e JOIN attack_nodes n ON e.source_id = n.id
            WHERE e.target_id = ?
        """, (node_id, node_id)).fetchall()
    return [dict(r) for r in rows]


def attack_chain(start_id: str, end_id: str, max_depth: int = 4) -> list:
    """BFS to find paths between two nodes. Returns list of paths (each path is list of node dicts)."""
    db = get_db()

    # Resolve MITRE IDs to STIX IDs
    def resolve(mid):
        if not mid.startswith(("attack-pattern", "malware", "tool",
                                "intrusion-set", "campaign",
                                "course-of-action", "x-mitre")):
            row = db.execute("SELECT id FROM attack_nodes WHERE mitre_id = ?",
                             (mid.upper(),)).fetchone()
            return row["id"] if row else None
        return mid

    start = resolve(start_id)
    end = resolve(end_id)
    if not start or not end:
        return []

    # BFS
    queue = deque([(start, [start])])
    visited = {start}
    paths = []

    while queue:
        current, path = queue.popleft()
        if len(path) > max_depth + 1:
            continue

        # Get neighbors (both directions)
        neighbors = db.execute("""
            SELECT target_id as neighbor FROM attack_edges WHERE source_id = ?
            UNION
            SELECT source_id as neighbor FROM attack_edges WHERE target_id = ?
        """, (current, current)).fetchall()

        for row in neighbors:
            neighbor = row["neighbor"]
            if neighbor == end:
                full_path = path + [neighbor]
                # Resolve to node info
                resolved = []
                for nid in full_path:
                    n = db.execute("SELECT id, type, name, mitre_id FROM attack_nodes WHERE id = ?",
                                   (nid,)).fetchone()
                    if n:
                        resolved.append(dict(n))
                paths.append(resolved)
                if len(paths) >= 5:  # cap results
                    return paths
            elif neighbor not in visited:
                visited.add(neighbor)
                queue.append((neighbor, path + [neighbor]))

    return paths


def attack_by_tactic(tactic: str) -> list:
    """List all techniques for a given tactic (e.g., 'initial-access')."""
    db = get_db()
    tactic = tactic.lower().strip()
    # Tactics are stored as JSON arrays in the tactics column
    rows = db.execute("""
        SELECT id, type, name, mitre_id, tactics, platforms
        FROM attack_nodes
        WHERE type = 'attack-pattern'
          AND tactics LIKE ?
        ORDER BY mitre_id
    """, (f'%"{tactic}"%',)).fetchall()
    return [dict(r) for r in rows]


def attack_mitigations(technique_id: str) -> list:
    """Find mitigations for a technique by MITRE ID."""
    db = get_db()
    # Resolve technique
    tech = db.execute("SELECT id FROM attack_nodes WHERE mitre_id = ?",
                      (technique_id.upper(),)).fetchone()
    if not tech:
        return []

    # Mitigations use 'mitigates' relationship: course-of-action --mitigates--> attack-pattern
    rows = db.execute("""
        SELECT n.id, n.name, n.mitre_id, n.description, e.description as how
        FROM attack_edges e
        JOIN attack_nodes n ON e.source_id = n.id
        WHERE e.target_id = ? AND e.relationship = 'mitigates'
        ORDER BY n.mitre_id
    """, (tech["id"],)).fetchall()
    return [dict(r) for r in rows]


def attack_stats() -> dict:
    """Graph statistics."""
    db = get_db()
    stats = {}
    for row in db.execute("SELECT key, value FROM attack_meta").fetchall():
        stats[row["key"]] = row["value"]

    # Node type breakdown
    type_counts = db.execute("""
        SELECT type, COUNT(*) as count FROM attack_nodes GROUP BY type ORDER BY count DESC
    """).fetchall()
    stats["node_types"] = {r["type"]: r["count"] for r in type_counts}

    # Edge type breakdown
    rel_counts = db.execute("""
        SELECT relationship, COUNT(*) as count FROM attack_edges
        GROUP BY relationship ORDER BY count DESC
    """).fetchall()
    stats["edge_types"] = {r["relationship"]: r["count"] for r in rel_counts}

    return stats


# ---------------------------------------------------------------------------
# CLI Formatting
# ---------------------------------------------------------------------------
def _print_search_results(results: list):
    if not results:
        print("No results found.")
        return
    print(f"\n{'MITRE ID':<12} {'Type':<20} {'Name':<40}")
    print("-" * 72)
    for r in results:
        mid = r.get("mitre_id", "") or ""
        typ = r.get("type", "")
        name = shorten(r.get("name", ""), width=40, placeholder="...")
        print(f"{mid:<12} {typ:<20} {name:<40}")
    print(f"\n{len(results)} result(s)")


def _print_technique(info: dict):
    if not info:
        print("Technique not found.")
        return
    print(f"\n{'='*72}")
    print(f"  {info.get('mitre_id', '')}  {info.get('name', '')}")
    print(f"{'='*72}")
    print(f"  Type:      {info.get('type', '')}")
    print(f"  Platforms: {', '.join(info.get('platforms', []))}")
    print(f"  Tactics:   {', '.join(info.get('tactics', []))}")

    desc = info.get("description", "")
    if desc:
        # Truncate long descriptions
        lines = desc.strip().split("\n")
        print(f"\n  Description:")
        for line in lines[:10]:
            print(f"    {line.rstrip()}")
        if len(lines) > 10:
            print(f"    ... ({len(lines) - 10} more lines)")

    related = info.get("related", [])
    if related:
        print(f"\n  Related ({len(related)}):")
        # Group by relationship type
        by_rel = {}
        for r in related:
            rel = r.get("relationship", "unknown")
            by_rel.setdefault(rel, []).append(r)
        for rel, items in sorted(by_rel.items()):
            print(f"    [{rel}]")
            for item in items[:10]:
                mid = item.get("mitre_id", "") or ""
                name = item.get("name", "")
                typ = item.get("type", "")
                label = f"{mid} {name}".strip() if mid else name
                print(f"      - {label} ({typ})")
            if len(items) > 10:
                print(f"      ... and {len(items) - 10} more")
    print()


def _print_mitigations(mitigations: list, technique_id: str):
    if not mitigations:
        print(f"No mitigations found for {technique_id}.")
        return
    print(f"\nMitigations for {technique_id}:")
    print(f"{'='*72}")
    for m in mitigations:
        mid = m.get("mitre_id", "") or ""
        name = m.get("name", "")
        how = m.get("how", "")
        print(f"\n  {mid}  {name}")
        if how:
            lines = how.strip().split("\n")
            for line in lines[:5]:
                print(f"    {line.rstrip()}")
            if len(lines) > 5:
                print(f"    ... ({len(lines) - 5} more lines)")
    print()


def _print_tactic(results: list, tactic: str):
    if not results:
        print(f"No techniques found for tactic '{tactic}'.")
        return
    print(f"\nTechniques for tactic '{tactic}':")
    print(f"{'MITRE ID':<12} {'Name':<60}")
    print("-" * 72)
    for r in results:
        mid = r.get("mitre_id", "") or ""
        name = shorten(r.get("name", ""), width=60, placeholder="...")
        print(f"{mid:<12} {name:<60}")
    print(f"\n{len(results)} technique(s)")


def _print_chain(paths: list, start: str, end: str):
    if not paths:
        print(f"No path found between {start} and {end}.")
        return
    print(f"\nPaths from {start} to {end}:")
    for i, path in enumerate(paths, 1):
        labels = []
        for node in path:
            mid = node.get("mitre_id", "") or ""
            name = node.get("name", "")
            labels.append(f"{mid} {name}".strip() if mid else name)
        print(f"  Path {i}: {' -> '.join(labels)}")
    print()


def _print_stats(stats: dict):
    print(f"\nATT&CK Knowledge Graph Statistics")
    print(f"{'='*50}")
    print(f"  Built:       {stats.get('built_at', 'never')}")
    print(f"  STIX ver:    {stats.get('stix_version', 'unknown')}")
    print(f"  Nodes:       {stats.get('node_count', 0)}")
    print(f"  Edges:       {stats.get('edge_count', 0)}")

    node_types = stats.get("node_types", {})
    if node_types:
        print(f"\n  Node types:")
        for t, c in node_types.items():
            print(f"    {t:<30} {c:>6}")

    edge_types = stats.get("edge_types", {})
    if edge_types:
        print(f"\n  Edge types:")
        for t, c in edge_types.items():
            print(f"    {t:<30} {c:>6}")
    print()


# ---------------------------------------------------------------------------
# Main CLI
# ---------------------------------------------------------------------------
def main():
    args = sys.argv[1:]

    if not args or args[0] in ("-h", "--help", "help"):
        print(__doc__.strip())
        return

    cmd = args[0]

    if cmd == "build":
        force = "--force" in args
        download_stix(force=force)
        build_graph(force=force)

    elif cmd == "search":
        if len(args) < 2:
            print("Usage: attack_graph.py search <query>")
            return
        query = " ".join(args[1:])
        results = attack_search(query)
        _print_search_results(results)

    elif cmd == "technique":
        if len(args) < 2:
            print("Usage: attack_graph.py technique <MITRE-ID>")
            return
        info = attack_technique_info(args[1])
        _print_technique(info)

    elif cmd == "mitigations":
        if len(args) < 2:
            print("Usage: attack_graph.py mitigations <MITRE-ID>")
            return
        mits = attack_mitigations(args[1])
        _print_mitigations(mits, args[1])

    elif cmd == "tactic":
        if len(args) < 2:
            print("Usage: attack_graph.py tactic <tactic-name>")
            return
        tactic = args[1]
        results = attack_by_tactic(tactic)
        _print_tactic(results, tactic)

    elif cmd == "related":
        if len(args) < 2:
            print("Usage: attack_graph.py related <node-id> [relationship]")
            return
        rel = args[2] if len(args) > 2 else None
        results = attack_related(args[1], relationship=rel)
        if not results:
            print("No related nodes found.")
        else:
            print(f"\n{'Rel':<20} {'Dir':<10} {'MITRE ID':<12} {'Type':<20} {'Name':<30}")
            print("-" * 92)
            for r in results:
                mid = r.get("mitre_id", "") or ""
                print(f"{r['relationship']:<20} {r['direction']:<10} {mid:<12} "
                      f"{r['type']:<20} {shorten(r['name'], 30, placeholder='...'):<30}")
            print(f"\n{len(results)} result(s)")

    elif cmd == "chain":
        if len(args) < 3:
            print("Usage: attack_graph.py chain <start-id> <end-id> [max_depth]")
            return
        depth = int(args[3]) if len(args) > 3 else 4
        paths = attack_chain(args[1], args[2], max_depth=depth)
        _print_chain(paths, args[1], args[2])

    elif cmd == "stats":
        stats = attack_stats()
        _print_stats(stats)

    else:
        print(f"Unknown command: {cmd}")
        print("Run with --help for usage.")


if __name__ == "__main__":
    main()
