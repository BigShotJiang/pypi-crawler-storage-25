import io
import os
import re
from datetime import date as _date

from setuptools import find_packages
from setuptools import setup


def read(filename):
    filename = os.path.join(os.path.dirname(__file__), filename)
    text_type = type(u"")
    with io.open(filename, mode="r", encoding='utf-8') as fd:
        return re.sub(text_type(r':[a-z]+:`~?(.*?)`'), text_type(r'``\1``'), fd.read())


# Get version: env var (CI) or today's date (local dev)
_version = os.getenv('PACKAGE_VERSION') or _date.today().strftime('%Y.%m.%d')


setup(
    name="bpp-anubis",
    version=_version,
    url="https://gitlab.com/blueprintprep/bpp-qa/utilities/anubis",
    license='MIT',

    author="matthew bahloul",
    author_email="matthew.bahloul@blueprintprep.com",

    description="Run behave tests in parallel",
    long_description=read("README.rst"),

    packages=find_packages(exclude=('tests',)),

    install_requires=[
        'behave>=1.2.6',
    ],

    classifiers=[
        'Development Status :: 4 - Beta',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3.10',
    ],

    entry_points={
            'console_scripts': [
                'anubis = anubis.__main__:main',
            ],
        }
)
