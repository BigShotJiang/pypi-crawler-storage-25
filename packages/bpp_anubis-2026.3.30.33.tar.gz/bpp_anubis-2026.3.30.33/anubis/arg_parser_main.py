import logging
from argparse import Namespace, ArgumentParser
from pathlib import Path


def parse_arguments() -> tuple[Namespace, list]:
    known: Namespace
    unknown: list
    parser: ArgumentParser = ArgumentParser(
        prog='anubis',
        description='Run Behave BDD tests in parallel with result aggregation'
    )

    # anubis-specific arguments
    parser.add_argument(
        '--features',
        dest='features',
        type=str,
        default=['features'],
        nargs='*',
        help='Path(s) to feature files or directories (default: features)'
    )
    parser.add_argument(
        '--pass-threshold',
        type=float,
        default=1.0,
        help='Minimum pass rate required (0.0-1.0, default: 1.0)'
    )
    parser.add_argument(
        '--processes',
        type=int,
        default=1,
        help='Number of parallel worker processes (default: 1)'
    )
    parser.add_argument(
        '--unit',
        type=str,
        default='example',
        choices=['feature', 'scenario', 'example'],
        help='Test granularity level (default: example)'
    )
    parser.add_argument(
        '--log-level',
        type=int,
        default=logging.DEBUG,
        help='Logging level (default: DEBUG)'
    )

    # output file configuration
    parser.add_argument(
        '--aggregate',
        type=Path,
        default=None,
        help='Path to aggregated results JSON'
    )
    parser.add_argument(
        '--junit',
        type=Path,
        default=None,
        help='Path to JUnit XML results'
    )
    parser.add_argument(
        '--log-file',
        type=Path,
        default=None,
        help='Path to log file'
    )
    parser.add_argument(
        '--output',
        type=Path,
        default=Path('.output'),
        help='Output directory for results (default: .output)'
    )

    # execution flags
    parser.add_argument(
        '--dry-run',
        action='store_true',
        help='Parse and validate tests without execution'
    )
    parser.add_argument(
        '--hide-failed',
        action='store_true',
        help='Hide failed test details in output'
    )
    parser.add_argument(
        '--hide-passed',
        action='store_true',
        help='Hide passed test details in output'
    )
    parser.add_argument(
        '--hide-summary',
        action='store_true',
        help='Hide test summary in output'
    )
    parser.add_argument(
        '--pass-with-no-tests',
        action='store_true',
        help='Exit with 0 if no tests found'
    )
    parser.add_argument(
        '--quiet',
        action='store_true',
        help='Suppress console output'
    )
    parser.add_argument(
        '--delete-output',
        action='store_true',
        help='Delete output directory after completion'
    )
    parser.add_argument(
        '--log-std-out',
        action='store_true',
        help='Include logs in stdout'
    )

    # Behave pass-through arguments
    parser.add_argument(
        '--tags',
        type=str,
        nargs='*',
        action='append',
        default=[],
        help='Tag filters for Behave (e.g., @automated, ~@flaky)'
    )
    parser.add_argument(
        '-D',
        action='append',
        help='User-defined variables for Behave (format: key=value)'
    )

    known, unknown = parser.parse_known_args()
    known.aggregate = known.output.joinpath('results.json') if known.aggregate is None else known.aggregate
    known.junit = known.output.joinpath('results.xml') if known.junit is None else known.junit
    known.log_file = known.output.joinpath('logs', 'anubis.log') if known.log_file is None else known.log_file

    # update user definitions
    user_defs: Namespace = Namespace()
    if known.D:
        for user_def in known.D:
            data = user_def.split('=')
            setattr(user_defs, data[0], True if len(data) == 1 else data[-1])

    known.D = user_defs
    if known.log_std_out:
        known.D.LOGSTDOUT = True

    return known, unknown
