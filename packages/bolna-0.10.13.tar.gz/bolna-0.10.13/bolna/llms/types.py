from typing import Any, Optional, Union

from pydantic import BaseModel, ConfigDict


class APIParams(BaseModel):
    url: Optional[str] = None
    method: Optional[str] = "POST"
    api_token: Optional[str] = None
    param: Optional[Union[str, dict]] = None
    headers: Optional[Union[str, dict]] = None
    pre_call_message: Optional[Union[str, dict]] = None


class LatencyData(BaseModel):
    sequence_id: Optional[int] = None
    first_token_latency_ms: Optional[float] = None
    total_stream_duration_ms: Optional[float] = None
    service_tier: Optional[str] = None
    llm_host: Optional[str] = None


class FunctionCallPayload(BaseModel):
    model_config = ConfigDict(extra="allow", protected_namespaces=())

    url: Optional[str] = None
    method: Optional[str] = None
    param: Any = None
    api_token: Optional[str] = None
    headers: Optional[dict] = None
    model_args: dict = {}
    meta_info: dict = {}
    called_fun: str = ""
    model_response: list[dict] = []
    tool_call_id: str = ""
    textual_response: Optional[str] = None
    resp: Any = None


class LLMStreamChunk(BaseModel):
    """Single chunk yielded from LLM generate_stream methods."""

    data: Any = None
    end_of_stream: bool = False
    latency: Optional[LatencyData] = None
    is_function_call: bool = False
    function_name: Optional[str] = None
    function_message: Optional[Union[str, dict]] = None
    input_tokens: Optional[int] = None
    output_tokens: Optional[int] = None
    reasoning_tokens: Optional[int] = None
    cached_tokens: Optional[int] = None
    reasoning_content: Optional[str] = None
