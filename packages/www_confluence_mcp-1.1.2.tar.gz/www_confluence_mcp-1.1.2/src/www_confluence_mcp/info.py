"""Info tool for Confluence MCP server — server configuration information."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, TypedDict

from mcp.server.fastmcp import Context
from mcp.types import Icon, ToolAnnotations

from .config import (
    AUTH_TYPE,
    HTTP_PROXY,
    HTTPS_PROXY,
    MAX_RESULTS,
    PERSONAL_TOKEN,
    PROMPTS_DIR,
    READ_ONLY,
    SSL_PATH,
    SSL_VERIFY,
    SPACES_FILTER,
    TIMEOUT,
    URL,
    USERNAME,
)
from .server import mcp

logger = logging.getLogger("www-confluence-mcp")


# ---------------------------------------------------------------------------
# Tool metadata loading
# ---------------------------------------------------------------------------


def _load_tool_instructions() -> dict[str, dict[str, Any]]:
    """Load tool instructions from JSON file."""
    json_path = Path(__file__).parent / "data" / "tools.json"
    with open(json_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return data


TOOL_INSTRUCTIONS: dict[str, dict[str, Any]] = _load_tool_instructions()

# TOOL_CATALOG: list of tool dicts for test iteration
TOOL_CATALOG: list[dict[str, Any]] = [
    {"name": name, **meta} for name, meta in TOOL_INSTRUCTIONS.items()
]


# Optional tool metadata for host UIs.
# FastMCP's public tool decorator supports icons, annotations (hints), and meta.


class _IconSpec(TypedDict, total=False):
    src: str
    mimeType: str
    sizes: list[str]


class _ToolMetaSpec(TypedDict, total=False):
    tags: list[str]
    icons: list[_IconSpec]
    # ToolAnnotations fields, using readable snake_case keys.
    read_only: bool
    destructive: bool
    idempotent: bool
    open_world: bool


_TOOL_META: dict[str, _ToolMetaSpec] = {
    "confluence_mcp_status": {
        "tags": ["read-only", "health"],
        "read_only": True,
        "open_world": False,
    },
    "confluence_search": {
        "tags": ["read-only", "search"],
        "read_only": True,
        "open_world": False,
    },
    "confluence_get_page_content": {
        "tags": ["read-only", "page", "page-crud"],
        "read_only": True,
        "open_world": False,
    },
    "confluence_get_page_tree": {
        "tags": ["read-only", "page"],
        "read_only": True,
        "open_world": False,
    },
    "confluence_list_versions": {
        "tags": ["read-only", "page", "history"],
        "read_only": True,
        "open_world": False,
    },
    "confluence_list_ancestors": {
        "tags": ["read-only", "page", "navigation"],
        "read_only": True,
        "open_world": False,
    },
    "confluence_list_spaces": {
        "tags": ["read-only", "spaces"],
        "read_only": True,
        "open_world": False,
    },
    "confluence_list_comments": {
        "tags": ["read-only", "comments"],
        "read_only": True,
        "open_world": False,
    },
    "confluence_list_labels": {
        "tags": ["read-only", "labels"],
        "read_only": True,
        "open_world": False,
    },
    "confluence_list_attachments": {
        "tags": ["read-only", "attachments"],
        "read_only": True,
        "open_world": False,
    },
    "confluence_download_attachments": {
        "tags": ["read-only", "download", "attachments"],
        "read_only": True,
        "open_world": False,
    },
    "confluence_get_page_images": {
        "tags": ["read-only", "images"],
        "read_only": True,
        "open_world": False,
    },
    "confluence_get_user": {
        "tags": ["read-only", "users"],
        "read_only": True,
        "open_world": False,
    },
    "confluence_new_page": {
        "tags": ["write", "page-crud"],
        "read_only": False,
        "destructive": True,
        "idempotent": False,
        "open_world": False,
    },
    "confluence_update_page": {
        "tags": ["write", "page-crud"],
        "read_only": False,
        "destructive": True,
        "idempotent": False,
        "open_world": False,
    },
    "confluence_delete_pages": {
        "tags": ["write", "page-crud"],
        "read_only": False,
        "destructive": True,
        "idempotent": True,
        "open_world": False,
    },
    "confluence_move_page": {
        "tags": ["write", "page-crud"],
        "read_only": False,
        "destructive": True,
        "idempotent": False,
        "open_world": False,
    },
    "confluence_add_comment": {
        "tags": ["write", "comments"],
        "read_only": False,
        "destructive": True,
        "idempotent": False,
        "open_world": False,
    },
    "confluence_add_labels": {
        "tags": ["write", "labels"],
        "read_only": False,
        "destructive": True,
        "idempotent": False,
        "open_world": False,
    },
    "confluence_delete_labels": {
        "tags": ["write", "labels"],
        "read_only": False,
        "destructive": True,
        "idempotent": True,
        "open_world": False,
    },
    "confluence_upload_attachments": {
        "tags": ["write", "attachments"],
        "read_only": False,
        "destructive": True,
        "idempotent": False,
        "open_world": False,
    },
    "confluence_delete_attachments": {
        "tags": ["write", "attachments"],
        "read_only": False,
        "destructive": True,
        "idempotent": True,
        "open_world": False,
    },
    "confluence_validate_page": {
        "tags": ["read-only", "validation", "markdown", "diff"],
        "read_only": True,
        "open_world": False,
    },
    "confluence_mcp_info": {
        "tags": ["info"],
        "read_only": True,
        "open_world": False,
    },
}


def tool_meta(
    tool_name: str,
) -> tuple[list[Icon] | None, ToolAnnotations | None, dict[str, Any] | None]:
    """Return (icons, annotations, meta) for the given tool.

    meta currently includes ``tags`` for host UIs.
    """
    m = _TOOL_META.get(tool_name)
    if not m:
        return None, None, None

    icons_raw = m.get("icons")
    if isinstance(icons_raw, list):
        icons = [
            Icon(
                src=spec["src"],
                mimeType=spec.get("mimeType"),
                sizes=spec.get("sizes"),
            )
            for spec in icons_raw
            if spec.get("src")
        ]
        if not icons:
            icons = None
    else:
        icons = None

    hint_kwargs: dict[str, Any] = {}
    if "read_only" in m:
        hint_kwargs["readOnlyHint"] = bool(m["read_only"])
    if "destructive" in m:
        hint_kwargs["destructiveHint"] = bool(m["destructive"])
    if "idempotent" in m:
        hint_kwargs["idempotentHint"] = bool(m["idempotent"])
    if "open_world" in m:
        hint_kwargs["openWorldHint"] = bool(m["open_world"])

    annotations = ToolAnnotations(**hint_kwargs) if hint_kwargs else None

    meta: dict[str, Any] = {}
    tags = m.get("tags")
    if isinstance(tags, list) and tags:
        meta["tags"] = list(tags)

    return icons, annotations, meta or None


def tool_title(tool_name: str) -> str:
    """Get the title for a tool by name."""
    return str(TOOL_INSTRUCTIONS[tool_name]["title"])


def tool_description(tool_name: str) -> str:
    """Get the description for a tool by name."""
    return str(TOOL_INSTRUCTIONS[tool_name]["description"])


def tool_full_metadata(tool_name: str) -> dict[str, Any]:
    """Get complete metadata for a tool (for info responses)."""
    instr = TOOL_INSTRUCTIONS.get(tool_name, {})
    meta = _TOOL_META.get(tool_name, {})
    return {
        "name": tool_name,
        "title": instr.get("title", ""),
        "description": instr.get("description", ""),
        "use_cases": list(instr.get("use_cases", [])),
        "parameters": instr.get("parameters", {}),
        "examples": list(instr.get("examples", [])),
        "tags": list(meta.get("tags", [])),
        "read_only": meta.get("read_only"),
        "destructive": meta.get("destructive"),
        "idempotent": meta.get("idempotent"),
    }


# ---------------------------------------------------------------------------
# Tool: confluence_mcp_info
# ---------------------------------------------------------------------------


@mcp.tool(
    name="confluence_mcp_info",
    title=tool_title("confluence_mcp_info"),
    description=tool_description("confluence_mcp_info"),
)
async def confluence_mcp_info(
    ctx: Context | None = None,
) -> dict[str, Any]:
    """Welcome to the Confluence MCP Server configuration guide!

    This function provides a comprehensive overview of your server configuration, including:
    - All available environment variables with their current values
    - Detailed descriptions of each variable's purpose and usage
    - Default values and expected formats
    - Example configurations to help you get started
    - Authentication status and method detection
    - Helpful tips and best practices

    Whether you're setting up the server for the first time or troubleshooting an issue,
    this tool provides the information you need to configure your Confluence integration correctly.
    """
    # Extract credentials from request headers (HTTP mode)
    from .utils.auth import extract_credentials

    await extract_credentials(ctx)

    logger.info("confluence_mcp_info: returning server configuration info")

    # Build the environment variables information
    env_vars = [
        {
            "name": "CONFLUENCE_URL",
            "description": "Confluence Server/DC base URL (required)",
            "default": None,
            "current": URL or None,
            "format": "URL (https://confluence.example.com)",
            "example": "https://confluence.example.com",
            "purpose": "Base URL of your Confluence Server/Data Center instance",
        },
        {
            "name": "CONFLUENCE_PERSONAL_TOKEN",
            "description": "Personal Access Token for PAT authentication",
            "default": None,
            "current": "***" if PERSONAL_TOKEN else None,
            "format": "String token",
            "example": "NzI4NjU1MDc4NjQ5OnVzZXI=",
            "purpose": "PAT token for authentication (preferred over Basic auth)",
        },
        {
            "name": "CONFLUENCE_USERNAME",
            "description": "Username for Basic authentication",
            "default": None,
            "current": USERNAME or None,
            "format": "String username",
            "example": "admin",
            "purpose": "Username for Basic authentication (fallback when PAT not set)",
        },
        {
            "name": "CONFLUENCE_PASSWORD",
            "description": "Password for Basic authentication",
            "default": None,
            "current": "***" if USERNAME and not PERSONAL_TOKEN else None,
            "format": "String password",
            "example": "my-secure-password",
            "purpose": "Password for Basic authentication (CONFLUENCE_API_TOKEN is also accepted as fallback)",
        },
        {
            "name": "CONFLUENCE_SSL_VERIFY",
            "description": "Verify TLS certificates",
            "default": "true",
            "current": str(SSL_VERIFY).lower(),
            "format": "Boolean (true/false)",
            "example": "true",
            "purpose": "Controls TLS certificate verification (uses system trust store via truststore)",
        },
        {
            "name": "CONFLUENCE_SSL_PATH",
            "description": "Path to extra CA certificates",
            "default": None,
            "current": SSL_PATH,
            "format": "File path (PEM) or directory path (OpenSSL-hashed)",
            "example": "/etc/ssl/certs/custom-ca.pem",
            "purpose": "Additional trusted CA certificates (loaded in addition to system trust store)",
        },
        {
            "name": "CONFLUENCE_TIMEOUT",
            "description": "HTTP request timeout in seconds",
            "default": "30",
            "current": str(TIMEOUT),
            "format": "Integer (1-3600)",
            "example": "60",
            "purpose": "Timeout for HTTP requests to Confluence API",
        },
        {
            "name": "CONFLUENCE_MAX_RESULTS",
            "description": "Default max results per query",
            "default": "25",
            "current": str(MAX_RESULTS),
            "format": "Integer (1-100)",
            "example": "50",
            "purpose": "Default limit for query results (can be overridden per request)",
        },
        {
            "name": "CONFLUENCE_READ_ONLY",
            "description": "Disable write tools",
            "default": "true",
            "current": str(READ_ONLY).lower(),
            "format": "Boolean (true/false)",
            "example": "false",
            "purpose": "Controls whether write tools (create, update, delete) are available",
        },
        {
            "name": "CONFLUENCE_SPACES_FILTER",
            "description": "Comma-separated space keys to filter searches",
            "default": None,
            "current": SPACES_FILTER or None,
            "format": "Comma-separated string",
            "example": "DEV,QA,PROD",
            "purpose": "Filter search results to only include specified spaces",
        },
        {
            "name": "CONFLUENCE_HTTP_PROXY",
            "description": "HTTP proxy URL",
            "default": None,
            "current": HTTP_PROXY,
            "format": "URL",
            "example": "http://proxy.example.com:8080",
            "purpose": "HTTP proxy for API requests",
        },
        {
            "name": "CONFLUENCE_HTTPS_PROXY",
            "description": "HTTPS proxy URL",
            "default": None,
            "current": HTTPS_PROXY,
            "format": "URL",
            "example": "http://proxy.example.com:8080",
            "purpose": "HTTPS proxy for API requests",
        },
        {
            "name": "CONFLUENCE_DEBUG",
            "description": "Enable debug logging",
            "default": "false",
            "current": "true" if logger.isEnabledFor(logging.DEBUG) else "false",
            "format": "Boolean (1/true/yes/on or 0/false/no/off)",
            "example": "true",
            "purpose": "Enable detailed debug logging for troubleshooting",
        },
        {
            "name": "CONFLUENCE_PROMPTS_DIR",
            "description": "Directory for custom prompt definitions",
            "default": None,
            "current": PROMPTS_DIR or None,
            "format": "Directory path",
            "example": "/path/to/prompts.d",
            "purpose": "Directory containing custom prompt JSON/YAML files",
        },
    ]

    # Authentication status
    auth_status = {
        "type": AUTH_TYPE if AUTH_TYPE else "not_configured",
        "configured": bool(AUTH_TYPE),
        "method": "Personal Access Token"
        if AUTH_TYPE == "pat"
        else "Basic Auth"
        if AUTH_TYPE == "basic"
        else "None",
    }

    return {
        "status": "ok",
        "server_name": "www-confluence-mcp",
        "auth": auth_status,
        "environment_variables": env_vars,
        "tools": [
            tool_full_metadata(name) for name in sorted(TOOL_INSTRUCTIONS.keys())
        ],
        "tool_count": len(TOOL_INSTRUCTIONS),
        "notes": [
            "PAT authentication is preferred over Basic auth for security",
            "CONFLUENCE_API_TOKEN is accepted as a fallback for CONFLUENCE_PASSWORD",
            "Write tools are only available when CONFLUENCE_READ_ONLY=false",
            "SSL certificates are verified by default using the system trust store",
        ],
    }
