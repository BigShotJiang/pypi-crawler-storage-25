"""MCP server for Confluence Server/Data Center integration."""

from __future__ import annotations

import logging
import os
from threading import Lock

from mcp.server.fastmcp import FastMCP

from .config import READ_ONLY

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

logging.basicConfig(
    level=logging.DEBUG if os.getenv("CONFLUENCE_DEBUG") else logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("www-confluence-mcp")

# ---------------------------------------------------------------------------
# Request counter (for testing)
# ---------------------------------------------------------------------------

_request_count = 0
_request_count_lock = Lock()


def get_request_count() -> int:
    """Return the current request count."""
    with _request_count_lock:
        return _request_count


def increment_request_count() -> int:
    """Increment and return the new request count."""
    global _request_count  # noqa: PLW0603
    with _request_count_lock:
        _request_count += 1
        return _request_count


# ---------------------------------------------------------------------------
# MCP instance
# ---------------------------------------------------------------------------

_READ_INSTRUCTIONS = (
    "Confluence Server/Data Center integration tools.\n"
    "\nSearch & Navigation:\n"
    "- confluence_search: Search content by text or CQL query.\n"
    "- confluence_get_page_content: Get page by ID, title + space_key, or URL.\n"
    "- confluence_list_ancestors: List ancestor pages (breadcrumb).\n"
    "\nSpaces:\n"
    "- confluence_list_spaces: List spaces or get one by key.\n"
    "\nComments:\n"
    "- confluence_list_comments: List comments on a page.\n"
    "\nLabels:\n"
    "- confluence_list_labels: List labels on a page.\n"
    "\nAttachments:\n"
    "- confluence_list_attachments: List attachments on a page.\n"
    "- confluence_download_attachments: Download attachments to disk.\n"
    "\nPages:\n"
    "- confluence_get_page_tree: Get pages from a space (tree) or children of a page.\n"
    "- confluence_list_versions: List page version history.\n"
    "\nUsers:\n"
    "- confluence_get_user: Search for users.\n"
    "\\nImages:\\n"
    "- confluence_get_page_images: Get page images as base64.\\n"
    "\\nValidation:\\n"
    "- confluence_validate_page: Validate page content and round-trip.\\n"
    "\\nServer:\\n"
    "- confluence_mcp_info: Get MCP server info and configuration.\\n"
    "- confluence_mcp_status: Check server status and connectivity.\\n"
    "- confluence_mcp_prompts: List loaded external prompts.\\n"
)

_WRITE_INSTRUCTIONS = (
    "\nComments:\n"
    "- confluence_add_comment: Add a comment to a page.\n"
    "\nLabels:\n"
    "- confluence_add_labels: Add labels to a page.\n"
    "- confluence_delete_labels: Remove labels from pages.\n"
    "\nAttachments:\n"
    "- confluence_upload_attachments: Upload one or more files as attachments to a page.\n"
    "- confluence_delete_attachments: Delete attachments.\n"
    "\nPage CRUD:\n"
    "- confluence_new_page: Create a new page.\n"
    "- confluence_update_page: Update an existing page (requires version_number).\n"
    "- confluence_delete_pages: Delete pages in batch.\n"
    "- confluence_move_page: Move page to another space/parent.\n"
    "\\nPrompt management:\\n"
    "- confluence_mcp_prompts: List all loaded prompts, or get full prompt content by name.\\n"
)

mcp = FastMCP(
    name="www-confluence-mcp",
    instructions=_READ_INSTRUCTIONS + (_WRITE_INSTRUCTIONS if not READ_ONLY else ""),
)

# ---------------------------------------------------------------------------
# Load tools
# ---------------------------------------------------------------------------

from . import tools  # noqa: F401, E402 — registers all MCP tools
from . import info  # noqa: F401, E402 — registers info tool
from . import resources  # noqa: F401, E402 — registers MCP resources
from . import prompt_generate  # noqa: F401, E402 — registers prompt generation/listing tools

# ---------------------------------------------------------------------------
# Load prompts from bundled defaults + user directory
# ---------------------------------------------------------------------------
from pathlib import Path  # noqa: E402

from .config import PROMPTS_DIR  # noqa: E402
from .prompt_loader import load_prompts_from_dir  # noqa: E402

# Built-in prompts shipped with the package
_builtin_dir = Path(__file__).parent / "prompts.d"
_count = load_prompts_from_dir(_builtin_dir)
if _count:
    logger.info("Loaded %d built-in prompt(s)", _count)

# User-defined prompts (override built-ins if same name)
if PROMPTS_DIR:
    _count = load_prompts_from_dir(Path(PROMPTS_DIR))
    if _count:
        logger.info("Loaded %d user prompt(s) from %s", _count, PROMPTS_DIR)


def main() -> None:
    """Start the Confluence MCP server.

    Initializes logging, loads all tools and prompts, then runs the MCP
    server using stdio or HTTP transport for communication with the host client.
    """
    transport = os.getenv("CONFLUENCE_MCP_TRANSPORT", "stdio")
    logger.info(
        "Starting www-confluence-mcp (transport=%s, READ_ONLY=%s)",
        transport,
        READ_ONLY,
    )
    if transport == "http":
        import uvicorn

        host = os.getenv("CONFLUENCE_MCP_HOST", "127.0.0.1")  # nosec B104
        port = int(os.getenv("CONFLUENCE_MCP_PORT", "8080"))
        app = mcp.streamable_http_app()
        uvicorn.run(app, host=host, port=port)
    else:
        mcp.run(transport="stdio")
