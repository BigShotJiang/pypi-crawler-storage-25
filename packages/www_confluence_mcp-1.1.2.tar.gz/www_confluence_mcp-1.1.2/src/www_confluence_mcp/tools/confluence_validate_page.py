"""MCP tool: Validate Confluence page with XHTML validation and diff support."""

from __future__ import annotations


import logging
from pathlib import Path
from typing import Any

from mcp.server.fastmcp import Context

from ..api.pages import get_page
from ..info import tool_description, tool_title
from ..server import mcp
from ..utils.url import get_page_id
from ..utils.converter import (
    storage_to_markdown,
    markdown_to_storage,
    validate_roundtrip,
)
from ..utils.content import to_dict
from ..utils.xhtml_validator import validate_xhtml, is_markdown_content
from ..utils.roundtrip_validator import roundtrip_validator
from .read_helpers import resolve_content_to_storage, fetch_page_storage
from ._error import make_error_response

logger = logging.getLogger("www-confluence-mcp.tools.validate_page")


@mcp.tool(
    name="confluence_validate_page",
    title=tool_title("confluence_validate_page"),
    description=tool_description("confluence_validate_page"),
)
async def confluence_validate_page(
    page: str | None = None,
    file: str | None = None,
    content: str | None = None,
    page_diff: str | None = None,
    file_diff: str | None = None,
    content_diff: str | None = None,
    ctx: Context | None = None,
) -> dict[str, Any]:
    # Extract credentials from request headers (HTTP mode)
    from ..utils.auth import extract_credentials

    await extract_credentials(ctx)

    """Validate Confluence page with XHTML validation and round-trip checking.

    Three modes of operation:

    Mode 1: page - Fetch page from Confluence, run round-trip validation,
            and validate restored XHTML.
    Mode 2: file - Read file, convert if markdown, validate XHTML.
    Mode 3: content - Same as file but from string input.

    Exactly one of page, file, or content must be provided.

    Optional diff mode: Exactly one of page_diff, file_diff, or content_diff
    can be provided to compare source against diff target.

    Args:
        page: Confluence page ID or URL to validate (Mode 1).
        file: Path to file to validate (Mode 2).
        content: String content to validate (Mode 3).
        page_diff: Confluence page ID or URL to compare against.
        file_diff: Path to file to compare against.
        content_diff: String content to compare against.

    Returns:
        Dictionary with validation results including:
            - is_valid: Overall validation status
            - xhtml_valid: XHTML validation status
            - roundtrip_valid: Round-trip validation status (Mode 1 only)
            - errors: List of error messages
            - element_counts: Counts of Confluence elements
            - In diff mode: comparison results with warnings, element counts
    """
    # Validate that exactly one source is selected
    sources_provided = sum(
        [
            page is not None,
            file is not None,
            content is not None,
        ]
    )

    if sources_provided == 0:
        return make_error_response(
            ValueError("One of page, file, or content must be provided"),
            tool_name="confluence_validate_page",
        )

    if sources_provided > 1:
        return make_error_response(
            ValueError("Only one of page, file, or content can be provided"),
            tool_name="confluence_validate_page",
        )

    # Validate diff parameters (at most one)
    diff_params = [page_diff, file_diff, content_diff]
    diff_count = sum(1 for p in diff_params if p is not None)

    if diff_count > 1:
        return make_error_response(
            ValueError(
                "Only one of page_diff, file_diff, or content_diff can be provided"
            ),
            tool_name="confluence_validate_page",
        )

    try:
        if diff_count > 0:
            # Diff mode: compare source against diff target
            return await _validate_with_diff(
                page=page,
                file=file,
                content=content,
                page_diff=page_diff,
                file_diff=file_diff,
                content_diff=content_diff,
            )
        elif page is not None:
            return await _validate_page_mode(page)
        elif file is not None:
            return await _validate_file_mode(file)
        else:  # content is not None
            if content is None:
                raise ValueError("content must not be None")
            return await _validate_content_mode(content)
    except Exception as e:
        return make_error_response(
            e,
            tool_name="confluence_validate_page",
            page=page,
            file=file,
            content=content,
            page_diff=page_diff,
            file_diff=file_diff,
            content_diff=content_diff,
        )


async def _validate_with_diff(
    page: str | None = None,
    file: str | None = None,
    content: str | None = None,
    page_diff: str | None = None,
    file_diff: str | None = None,
    content_diff: str | None = None,
) -> dict[str, Any]:
    """Validate source against diff target.

    Both source and diff are resolved to storage HTML, XHTML-validated,
    and structurally compared.

    Args:
        page, file, content: Source (exactly one must be provided).
        page_diff, file_diff, content_diff: Diff target (exactly one must be provided).

    Returns:
        Dictionary with diff comparison results.
    """
    # Resolve source to storage HTML
    if page is not None:
        page_id = await get_page_id(page)
        source_storage, source_label, _ = await fetch_page_storage(page_id)
    elif file is not None:
        source_storage, source_label, _ = await resolve_content_to_storage(
            file_path=file
        )
    else:  # content
        source_storage, source_label, _ = await resolve_content_to_storage(
            content=content
        )

    # Validate source XHTML
    source_xhtml_valid, source_xhtml_errors, source_xhtml_info = validate_xhtml(
        source_storage
    )

    # Resolve diff to storage HTML
    if page_diff is not None:
        page_diff_id = await get_page_id(page_diff)
        diff_storage, diff_label, _ = await fetch_page_storage(page_diff_id)
    elif file_diff is not None:
        diff_storage, diff_label, _ = await resolve_content_to_storage(
            file_path=file_diff
        )
    else:  # content_diff
        diff_storage, diff_label, _ = await resolve_content_to_storage(
            content=content_diff
        )

    # Validate diff XHTML
    diff_xhtml_valid, diff_xhtml_errors, diff_xhtml_info = validate_xhtml(diff_storage)

    # Compare using RoundTripValidator
    warnings = roundtrip_validator.validate(source_storage, diff_storage)

    # Count elements for both
    def count_elements(html: str) -> dict[str, int]:
        return {
            "macros": html.count("<ac:structured-macro"),
            "images": html.count("<ac:image"),
            "users": html.count("<ri:user"),
            "pages": html.count("<ri:page"),
            "attachments": html.count("<ri:attachment"),
            "task_lists": html.count("<ac:task-list"),
        }

    return {
        "mode": "diff",
        "source": source_label,
        "destination": diff_label,
        "is_identical": len(warnings) == 0,
        "source_xhtml_valid": source_xhtml_valid,
        "destination_xhtml_valid": diff_xhtml_valid,
        "warnings": warnings,
        "source_length": len(source_storage),
        "destination_length": len(diff_storage),
        "source_elements": count_elements(source_storage),
        "destination_elements": count_elements(diff_storage),
        "errors": {
            "source_xhtml": source_xhtml_errors,
            "destination_xhtml": diff_xhtml_errors,
        },
        "info": {
            "source_xhtml": source_xhtml_info,
            "destination_xhtml": diff_xhtml_info,
        },
    }


async def _validate_page_mode(page: str) -> dict[str, Any]:
    """Validate a Confluence page by ID or URL (Mode 1).

    Fetches page from Confluence, runs round-trip conversion,
    and validates the restored XHTML.

    Args:
        page: Confluence page ID or URL to validate.

    Returns:
        Dictionary with validation results.
    """
    # Resolve page ID
    page_id = await get_page_id(page)

    # Fetch page from Confluence
    page_data = await get_page(page_id, body_format="storage")
    page_dict = to_dict(page_data)
    original_html = page_dict.get("body", {}).get("storage", {}).get("value", "")

    # Run round-trip conversion
    md_content = storage_to_markdown(original_html, page_dict)
    restored_html = markdown_to_storage(md_content)

    # Validate round-trip
    rt_is_valid, rt_errors = validate_roundtrip(original_html, restored_html)

    # Validate XHTML of restored HTML
    xhtml_is_valid, xhtml_errors, xhtml_info = validate_xhtml(restored_html)

    # Also validate original HTML
    orig_xhtml_valid, orig_xhtml_errors, orig_xhtml_info = validate_xhtml(original_html)

    # Count elements
    def count_elements(html: str) -> dict[str, int]:
        return {
            "macros": html.count("<ac:structured-macro"),
            "images": html.count("<ac:image"),
            "users": html.count("<ri:user"),
            "pages": html.count("<ri:page"),
            "attachments": html.count("<ri:attachment"),
            "task_lists": html.count("<ac:task-list"),
        }

    return {
        "page_id": page_id,
        "is_valid": rt_is_valid and xhtml_is_valid,
        "roundtrip_valid": rt_is_valid,
        "xhtml_valid": xhtml_is_valid,
        "original_xhtml_valid": orig_xhtml_valid,
        "errors": {
            "roundtrip": rt_errors,
            "xhtml_restored": xhtml_errors,
            "xhtml_original": orig_xhtml_errors,
        },
        "info": {
            "xhtml_restored": xhtml_info,
            "xhtml_original": orig_xhtml_info,
        },
        "original_elements": count_elements(original_html),
        "restored_elements": count_elements(restored_html),
    }


async def _validate_file_mode(file: str) -> dict[str, Any]:
    """Validate a file (Mode 2).

    Reads file, detects if markdown or HTML, converts if needed,
    and validates XHTML.

    Args:
        file: Path to file to validate.

    Returns:
        Dictionary with validation results.
    """
    file_path = Path(file)

    if not file_path.exists():
        return make_error_response(
            FileNotFoundError(f"File not found: {file}"),
            tool_name="confluence_validate_page",
            file=file,
        )

    content = file_path.read_text(encoding="utf-8")

    return await _process_content(content, str(file_path))


async def _validate_content_mode(content: str) -> dict[str, Any]:
    """Validate string content (Mode 3).

    Detects if markdown or HTML, converts if needed,
    and validates XHTML.

    Args:
        content: String content to validate.

    Returns:
        Dictionary with validation results.
    """
    return await _process_content(content, None)


async def _process_content(content: str, source_path: str | None) -> dict[str, Any]:
    """Process content for validation (shared by file and content modes).

    Args:
        content: Content string to validate.
        source_path: Optional source path for context.

    Returns:
        Dictionary with validation results.
    """
    # Detect if markdown or HTML
    is_md = is_markdown_content(content, source_path)

    if is_md:
        # Convert markdown to storage format
        try:
            restored_html = markdown_to_storage(content)
        except Exception as e:
            return {
                "source": source_path or "content",
                "content_type": "markdown",
                "is_valid": False,
                "xhtml_valid": False,
                "conversion_error": str(e),
                "errors": {
                    "conversion": [str(e)],
                    "xhtml": [],
                },
            }

        # Validate the converted XHTML
        xhtml_is_valid, xhtml_errors, xhtml_info = validate_xhtml(restored_html)

        return {
            "source": source_path or "content",
            "content_type": "markdown",
            "is_valid": xhtml_is_valid,
            "xhtml_valid": xhtml_is_valid,
            "errors": {
                "xhtml": xhtml_errors,
            },
            "info": {
                "xhtml": xhtml_info,
            },
            "converted_html_length": len(restored_html),
            "element_counts": {
                "macros": restored_html.count("<ac:structured-macro"),
                "images": restored_html.count("<ac:image"),
                "users": restored_html.count("<ri:user"),
                "pages": restored_html.count("<ri:page"),
                "task_lists": restored_html.count("<ac:task-list"),
            },
        }
    else:
        # Raw HTML - validate directly
        xhtml_is_valid, xhtml_errors, xhtml_info = validate_xhtml(content)

        return {
            "source": source_path or "content",
            "content_type": "html",
            "is_valid": xhtml_is_valid,
            "xhtml_valid": xhtml_is_valid,
            "errors": {
                "xhtml": xhtml_errors,
            },
            "info": {
                "xhtml": xhtml_info,
            },
            "html_length": len(content),
            "element_counts": {
                "macros": content.count("<ac:structured-macro"),
                "images": content.count("<ac:image"),
                "users": content.count("<ri:user"),
                "pages": content.count("<ri:page"),
                "task_lists": content.count("<ac:task-list"),
            },
        }
