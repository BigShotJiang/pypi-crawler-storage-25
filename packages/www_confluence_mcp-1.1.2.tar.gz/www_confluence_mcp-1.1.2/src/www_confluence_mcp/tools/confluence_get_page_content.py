"""Get Confluence page tool - retrieve page by ID, URL, or save to file."""

from __future__ import annotations

import logging
from typing import Any

from mcp.server.fastmcp import Context

from ..api.pages import get_page
from ..config import IS_HTTP_MODE
from ..info import tool_description, tool_title
from ..server import mcp
from ..utils.content import extract_page_metadata, to_dict
from ..utils.converter import storage_to_markdown
from ..utils.io import ensure_file_extension
from ..utils.markdown import strip_confluence_wrappers
from ..utils.url import get_page_id

logger = logging.getLogger("www-confluence-mcp")


async def _confluence_get_page_impl(
    page: str,
    file_path: str | None = None,
    format: str = "markdown",
    ctx: Context | None = None,
) -> dict[str, Any]:
    """Common implementation for confluence_get_page_content."""
    # Extract credentials from request headers (HTTP mode)
    from ..utils.auth import extract_credentials

    await extract_credentials(ctx)

    # Validate format parameter
    valid_formats = ("markdown", "html", "plain_markdown")
    if format not in valid_formats:
        raise ValueError(
            f"format must be 'markdown', 'html', or 'plain_markdown', got: {format}"
        )

    # Resolve page ID from page parameter
    page_id = await get_page_id(page)

    logger.info(
        "confluence_get_page_content: page=%s file_path=%s format=%s",
        page,
        file_path,
        format,
    )
    page_data = await get_page(page_id, body_format="storage")

    if page_data is None:
        raise ValueError(f"Page not found: {page_id}")

    # Convert Pydantic model to dict for dict-style access
    page_data = to_dict(page_data)

    # Get storage HTML (always fetched from API)
    storage_html = page_data.get("body", {}).get("storage", {}).get("value", "")

    # Determine content based on format
    if format == "html":
        content = storage_html
    elif format == "plain_markdown":
        content = strip_confluence_wrappers(
            storage_to_markdown(storage_html, page_data)
        )
    else:  # format == "markdown"
        content = storage_to_markdown(storage_html, page_data)

    # Save to file if requested
    if file_path:
        if format == "html":
            # Force .html extension for html format
            file_path = ensure_file_extension(file_path, ".html")
        else:  # format == "markdown" or "plain_markdown"
            # Force .md extension for markdown formats
            file_path = ensure_file_extension(file_path, ".md")

        with open(file_path, "w", encoding="utf-8") as f:
            f.write(content)
        logger.info(
            "confluence_get_page_content: saved to %s (format=%s)", file_path, format
        )
        return {
            "status": "ok",
            **extract_page_metadata(page_data),
            "file_path": file_path,
            "format": format,
        }

    # Return content string
    return {
        "status": "ok",
        **extract_page_metadata(page_data),
        "content": content,
        "format": format,
    }


if IS_HTTP_MODE:

    @mcp.tool(
        name="confluence_get_page_content",
        title=tool_title("confluence_get_page_content"),
        description=tool_description("confluence_get_page_content"),
    )
    async def confluence_get_page_content(
        page: str,
        format: str = "markdown",
        ctx: Context | None = None,
    ) -> dict[str, Any]:
        """Get a Confluence page by ID or URL.

        Accepts page ID or Confluence URL. Supports three URL formats:
            - Query param: https://host/pages/viewpage.action?pageId=123
            - Cloud: https://host/wiki/spaces/SPACE/pages/123/Title
            - Display: https://host/display/SPACE/TITLE

        Args:
            page: The Confluence page ID or URL.
            format: Output format - "markdown" (default), "html", or "plain_markdown".
                "markdown": convert to markdown with CONFLUENCE_* comment wrappers
                "html": return/save raw Confluence Storage Format HTML, save as .html
                "plain_markdown": convert to clean markdown without wrappers, save as .md

        Returns:
            Dictionary with page data. Includes 'content' key with the content string.
            Also includes 'format' key.
        """
        return await _confluence_get_page_impl(
            page, file_path=None, format=format, ctx=ctx
        )
else:

    @mcp.tool(
        name="confluence_get_page_content",
        title=tool_title("confluence_get_page_content"),
        description=tool_description("confluence_get_page_content"),
    )
    async def confluence_get_page_content(
        page: str,
        file_path: str | None = None,
        format: str = "markdown",
        ctx: Context | None = None,
    ) -> dict[str, Any]:
        """Get content of a Confluence page by ID or URL.

        Accepts page ID or Confluence URL. Supports three URL formats:
            - Query param: https://host/pages/viewpage.action?pageId=123
            - Cloud: https://host/wiki/spaces/SPACE/pages/123/Title
            - Display: https://host/display/SPACE/TITLE

        Args:
            page: The Confluence page ID or URL.
            file_path: Optional file path to save content.
            format: Output format - "markdown" (default), "html", or "plain_markdown".
                "markdown": convert to markdown with CONFLUENCE_* comment wrappers
                "html": return/save raw Confluence Storage Format HTML, save as .html
                "plain_markdown": convert to clean markdown without wrappers, save as .md

        Returns:
            Dictionary with page data. If file_path is provided, includes
            'file_path' key with the saved file path. Otherwise includes
            'content' key with the content string. Also includes 'format' key.

        Raises:
            ValueError: If format is not "markdown", "html", or "plain_markdown".
        """
        return await _confluence_get_page_impl(
            page, file_path=file_path, format=format, ctx=ctx
        )
