"""Confluence status check tool - server status, connectivity, and metrics."""

from __future__ import annotations

import logging
import time
from typing import Any

from mcp.server.fastmcp import Context

from ..api.spaces import get_spaces
from ..info import tool_description, tool_title
from ..server import mcp
from ..utils.cache import page_cache
from ..utils.converter_metrics import conversion_metrics

logger = logging.getLogger("www-confluence-mcp")

# Server start time for uptime calculation
_START_TIME = time.time()
_VERSION = "2.0.0"


async def _check_confluence_connectivity() -> dict[str, Any]:
    """Check Confluence connectivity with lightweight HEAD request.

    Returns:
        Dict with connectivity status and error message if applicable.
    """
    try:
        # Use get_spaces with limit=1 as a lightweight connectivity check
        # This is equivalent to HEAD /rest/api/content with limit=1
        await get_spaces(limit=1)
        return {
            "status": "connected",
            "reachable": True,
        }
    except Exception as exc:
        return {
            "status": "error",
            "reachable": False,
            "error": str(exc),
        }


def _get_cache_stats() -> dict[str, Any]:
    """Get cache statistics.

    Returns:
        Dict with hits, misses, hit_rate, and size.
    """
    # Note: Current TTLCache doesn't expose hits/misses counters
    # Return available stats
    return {
        "hits": 0,  # Placeholder - TTLCache doesn't track hits yet
        "misses": 0,  # Placeholder - TTLCache doesn't track misses yet
        "hit_rate": 0.0,
        "size": page_cache.size,
    }


@mcp.tool(
    name="confluence_mcp_status",
    title=tool_title("confluence_mcp_status"),
    description=tool_description("confluence_mcp_status"),
)
async def confluence_mcp_status(
    ctx: Context | None = None,
) -> dict[str, Any]:
    """Check server status and Confluence connectivity.

    Returns:
        Dict with status, timestamp, uptime_seconds, version, tool_count,
        confluence_connection, cache_stats, request_count, and conversion_metrics.
    """
    # Extract credentials from request headers (HTTP mode)
    from ..utils.auth import extract_credentials

    await extract_credentials(ctx)

    # Get tool count from MCP server
    tool_count = len(mcp._tool_manager._tools)

    # Calculate uptime
    uptime_seconds = time.time() - _START_TIME

    # Check Confluence connectivity
    connectivity = await _check_confluence_connectivity()

    # Get cache stats
    cache_stats = _get_cache_stats()

    # Get conversion metrics summary
    metrics_summary = conversion_metrics.summary()

    # Determine overall status
    overall_status = "healthy" if connectivity["reachable"] else "degraded"

    return {
        "status": overall_status,
        "timestamp": time.time(),
        "uptime_seconds": round(uptime_seconds, 2),
        "version": _VERSION,
        "tool_count": tool_count,
        "confluence_connection": connectivity,
        "cache_stats": cache_stats,
        "conversion_metrics": metrics_summary,
    }
