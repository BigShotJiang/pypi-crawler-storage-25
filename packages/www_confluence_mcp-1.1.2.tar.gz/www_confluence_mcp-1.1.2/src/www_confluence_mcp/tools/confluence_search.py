"""Confluence search tool - search content using CQL or simple text queries."""

from __future__ import annotations

import logging
from typing import Any

from mcp.server.fastmcp import Context

from ..api.search import search_cql
from ..config import MAX_RESULTS
from ..info import tool_description, tool_title
from ..server import mcp
from ..utils.pagination import extract_next_start
from ..utils.content import to_dict

logger = logging.getLogger("www-confluence-mcp")


def _apply_spaces_filter(spaces: list[str] | None) -> list[str] | None:
    """Return caller-provided spaces, or fall back to the global SPACES_FILTER."""
    from ..config import SPACES_FILTER

    if spaces:
        return spaces
    if SPACES_FILTER:
        return [s.strip() for s in SPACES_FILTER.split(",") if s.strip()]
    return None


@mcp.tool(
    name="confluence_search",
    title=tool_title("confluence_search"),
    description=tool_description("confluence_search"),
)
async def confluence_search(
    query: str,
    spaces: list[str] | None = None,
    content_types: list[str] | None = None,
    limit: int = MAX_RESULTS,
    start: str | None = None,
    ctx: Context | None = None,
) -> dict[str, Any]:
    # Extract credentials from request headers (HTTP mode)
    from ..utils.auth import extract_credentials

    await extract_credentials(ctx)

    query = query.strip()
    if not query:
        raise ValueError("query must not be empty")
    spaces = _apply_spaces_filter(spaces)
    logger.info("confluence_search: query=%r limit=%d", query, limit)
    start_int = int(start) if start else 0
    data = await search_cql(
        query, spaces=spaces, content_types=content_types, limit=limit, start=start_int
    )
    if data is None:
        return {
            "status": "no_results",
            "query": query,
            "result_count": 0,
            "results": [],
        }
    # Convert Pydantic model to dict for backward compatibility
    data_dict = to_dict(data)
    results = data_dict.get("results", [])
    links = data_dict.get("links", data_dict.get("_links", {}))
    return {
        "status": "ok" if results else "no_results",
        "query": query,
        "result_count": len(results),
        "results": results,
        "next_start": extract_next_start(links),
    }
