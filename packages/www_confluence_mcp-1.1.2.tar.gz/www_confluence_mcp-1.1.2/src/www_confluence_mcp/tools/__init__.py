"""MCP tool wrappers for Confluence operations."""

from __future__ import annotations

# Import all tool modules to register @mcp.tool() decorators
from . import confluence_mcp_status  # noqa: F401
from . import confluence_search  # noqa: F401
from . import confluence_get_page_content  # noqa: F401
from . import confluence_get_page_tree  # noqa: F401
from . import confluence_list_versions  # noqa: F401
from . import confluence_list_ancestors  # noqa: F401
from . import confluence_list_spaces  # noqa: F401
from . import confluence_list_comments  # noqa: F401
from . import confluence_list_labels  # noqa: F401
from . import confluence_list_attachments  # noqa: F401
from . import confluence_download_attachments  # noqa: F401
from . import confluence_get_page_images  # noqa: F401
from . import confluence_get_user  # noqa: F401
from . import confluence_new_page  # noqa: F401
from . import confluence_update_page  # noqa: F401
from . import confluence_delete_pages  # noqa: F401
from . import confluence_move_page  # noqa: F401
from . import confluence_add_comment  # noqa: F401
from . import confluence_add_labels  # noqa: F401
from . import confluence_delete_labels  # noqa: F401
from . import confluence_upload_attachments  # noqa: F401
from . import confluence_delete_attachments  # noqa: F401
from . import confluence_validate_page  # noqa: F401
