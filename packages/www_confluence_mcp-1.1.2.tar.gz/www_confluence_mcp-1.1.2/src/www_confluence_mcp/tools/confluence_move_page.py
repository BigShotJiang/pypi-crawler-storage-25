"""Move Confluence page tool - move page to different space/parent."""

from __future__ import annotations

import logging
from typing import Any

from mcp.server.fastmcp import Context

from ..api.pages import get_page, move_page
from ..info import tool_description, tool_title
from ..config import OptIdLike
from ..server import mcp
from ..utils.content import to_dict
from ..utils.url import get_page_id

logger = logging.getLogger("www-confluence-mcp")


@mcp.tool(
    name="confluence_move_page",
    title=tool_title("confluence_move_page"),
    description=tool_description("confluence_move_page"),
)
async def confluence_move_page(
    page: str,
    space_key_dest: str | None = None,
    dest_page: OptIdLike = None,
    ctx: Context | None = None,
) -> dict[str, Any]:
    """Move a page to another space and/or parent.

    Accepts page ID or Confluence URL.
    """
    # Extract credentials from request headers (HTTP mode)
    from ..utils.auth import extract_credentials

    await extract_credentials(ctx)

    page_id = await get_page_id(page)
    if dest_page is not None:
        dest_page = await get_page_id(str(dest_page), name="dest_page")
    if space_key_dest:
        space_key_dest = space_key_dest.strip()

    if not space_key_dest and not dest_page:
        raise ValueError("Provide space_key_dest and/or dest_page to move the page")
    logger.info(
        "confluence_move_page: page=%s space=%s dest_page=%s",
        page,
        space_key_dest,
        dest_page,
    )
    # Fetch page data first (separation of concerns: tool does GET, API does PUT)
    page_data = await get_page(page_id, body_format="storage")
    page_data = to_dict(page_data)
    data = await move_page(
        page_id,
        space_key=space_key_dest,
        parent_id=dest_page,
        page_data=page_data,
    )
    if data is None:
        return {"status": "moved", "page_id": page_id}
    data = to_dict(data)
    return {
        "status": "moved",
        "page_id": page_id,
        "title": data.get("title"),
        "version": data.get("version", {}).get("number"),
    }
