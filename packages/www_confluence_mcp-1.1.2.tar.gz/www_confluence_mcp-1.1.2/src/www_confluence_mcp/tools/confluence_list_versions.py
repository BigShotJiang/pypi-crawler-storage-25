"""List page versions tool - retrieve version history of a Confluence page."""

from __future__ import annotations

import logging
from typing import Any

from mcp.server.fastmcp import Context

from ..api.pages import get_page_history
from ..info import tool_description, tool_title
from ..server import mcp
from ..utils.url import get_page_id

logger = logging.getLogger("www-confluence-mcp")


@mcp.tool(
    name="confluence_list_versions",
    title=tool_title("confluence_list_versions"),
    description=tool_description("confluence_list_versions"),
)
async def confluence_list_versions(
    page: str,
    limit: int = 10,
    ctx: Context | None = None,
) -> dict[str, Any]:
    """List page version history.

    Accepts page ID or Confluence URL.

    Args:
        page: Confluence page ID or URL.
        limit: Maximum number of versions to return (default: 5).
            Note: Current API returns only version metadata, not paginated history.
        ctx: MCP context.
    """
    # Extract credentials from request headers (HTTP mode)
    from ..utils.auth import extract_credentials

    await extract_credentials(ctx)

    page_id = await get_page_id(page)
    logger.info("confluence_list_versions: page=%s", page)
    data = await get_page_history(page_id)
    return data if data is not None else {"results": []}
