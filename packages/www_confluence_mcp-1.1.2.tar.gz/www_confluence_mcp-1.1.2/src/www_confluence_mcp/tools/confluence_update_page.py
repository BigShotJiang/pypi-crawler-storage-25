"""Update Confluence page tool."""

from __future__ import annotations

import logging
from typing import Any

from mcp.server.fastmcp import Context

from ..api.pages import get_page, update_page
from ..info import tool_description, tool_title
from ..server import mcp
from ..utils.content import to_dict
from ..utils.url import get_page_id
from .read_helpers import resolve_content_to_storage

logger = logging.getLogger("www-confluence-mcp")


@mcp.tool(
    name="confluence_update_page",
    title=tool_title("confluence_update_page"),
    description=tool_description("confluence_update_page"),
)
async def confluence_update_page(
    page: str,
    title: str | None = None,
    file: str | None = None,
    content: str | None = None,
    ctx: Context | None = None,
) -> dict[str, Any]:
    """Update an existing Confluence page.

    Accepts page ID or Confluence URL.
    Auto-fetches current version and increments.
    Prefer file parameter (path to Markdown file) over content (string).
    Use content only when file is not available.
    Exactly one of file or content must be provided.

    Args:
        page: The Confluence page ID or URL to update.
        title: New page title (optional, uses existing title if not provided).
        file: Path to Markdown file with new content.
        content: Markdown content string with new content.

    Returns:
        Dictionary with update status and page info.

    Raises:
        ValueError: If neither or both file and content are provided.
    """
    # Extract credentials from request headers (HTTP mode)
    from ..utils.auth import extract_credentials

    await extract_credentials(ctx)

    page_id = await get_page_id(page)

    # Fetch page data (needed for auto-version and potentially for title)
    page_data = await get_page(page_id, body_format="storage")
    if page_data is None:
        raise ValueError(f"Page not found: {page_id}")
    page_data = to_dict(page_data)

    # Auto-increment version: use current version + 1
    current_version = page_data.get("version", {}).get("number", 0)
    if current_version < 1:
        raise ValueError(f"Invalid version for page {page_id}")
    version_number = current_version + 1

    # Validate title
    if title is None:
        title = page_data.get("title", "")
    else:
        title = title.strip()
        if not title:
            raise ValueError("title must not be empty")

    # Resolve content to storage format
    try:
        storage_html, _, _ = await resolve_content_to_storage(
            file_path=file,
            content=content,
            expected_page_id=page_id,
        )
    except ValueError as e:
        raise ValueError(f"Failed to resolve content: {e}") from e

    logger.info("confluence_update_page: page=%s version=%d", page, version_number)
    data = await update_page(
        page_id=page_id,
        title=title,
        body_value=storage_html,
        version_number=version_number,
        body_representation="storage",
        status="current",
    )
    if data is None:
        return {"status": "updated", "page_id": page_id, "version": version_number}
    data = to_dict(data)
    return {
        "status": "updated",
        "page_id": data.get("id"),
        "version": data.get("version", {}).get("number"),
    }
