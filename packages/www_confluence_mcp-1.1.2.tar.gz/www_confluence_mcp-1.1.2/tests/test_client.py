"""Unit tests for API modules using mocked HTTP (unittest.mock + pytest)."""

from __future__ import annotations

import niquests
import pytest
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

from www_confluence_mcp.api.session import (
    api_path,
    safe_path_segment,
)
from www_confluence_mcp.api.pages import (
    get_page,
    create_page,
    get_page_by_title,
    update_page,
    delete_page,
)
from www_confluence_mcp.api.search import search_cql
from www_confluence_mcp.api.spaces import get_spaces, get_space
from www_confluence_mcp.api.labels import get_page_labels, add_page_labels
from www_confluence_mcp.api.attachments import (
    get_attachments,
    upload_attachment,
    download_attachment,
    delete_attachment,
)
from www_confluence_mcp.api.comments import (
    get_footer_comments,
    create_comment,
    reply_to_comment,
)
from www_confluence_mcp.api.users import search_user
from www_confluence_mcp.api.images import get_page_images
from www_confluence_mcp.api.pages import (
    get_pages_in_space,
    get_child_pages,
    get_page_ancestors,
    move_page,
)
from www_confluence_mcp.exceptions import (
    ConfluenceNotFoundError,
    ConfluencePermissionError,
    ConfluenceConflictError,
    ConfluenceRateLimitError,
    ConfluenceAPIError,
    ConfluenceTimeoutError,
)


# ---------------------------------------------------------------------------
# Test Session Helpers
# ---------------------------------------------------------------------------


class TestSessionHelpers:
    """Test helper functions in session.py."""

    def test_api_path_prepends_prefix(self) -> None:
        """Test api_path prepends /rest/api prefix."""
        assert api_path("/content") == "/rest/api/content"
        assert api_path("/space") == "/rest/api/space"
        assert api_path("/search") == "/rest/api/search"

    def test_api_path_with_version(self) -> None:
        """Test api_path includes version segment when provided."""
        assert api_path("/content", version="2") == "/rest/api/2/content"
        assert api_path("/content", version="1.0") == "/rest/api/1.0/content"
        assert api_path("/space", version="latest") == "/rest/api/space"
        assert api_path("/space", version="") == "/rest/api/space"

    def test_safe_path_segment_encodes(self) -> None:
        """Test safe_path_segment encodes dangerous characters."""
        assert "/" not in safe_path_segment("a/b")
        assert safe_path_segment("a/b") == "a%2Fb"
        assert safe_path_segment("hello world") == "hello%20world"

    def test_safe_path_segment_preserves_safe(self) -> None:
        """Test safe_path_segment preserves safe alphanumeric strings."""
        assert safe_path_segment("123") == "123"
        assert safe_path_segment("abc") == "abc"
        assert safe_path_segment("ABC123") == "ABC123"

    def test_safe_path_segment_encodes_special_chars(self) -> None:
        """Test safe_path_segment encodes special characters."""
        assert safe_path_segment("test@123") == "test%40123"
        assert safe_path_segment("test#hash") == "test%23hash"
        assert safe_path_segment("test+plus") == "test%2Bplus"


# ---------------------------------------------------------------------------
# Test _request with mocked niquests
# ---------------------------------------------------------------------------


class TestRequest:
    """Test _request function with mocked niquests client."""

    @pytest.fixture
    def mock_client(self, monkeypatch: pytest.MonkeyPatch) -> MagicMock:
        """Create a mock niquests client and patch get_client."""
        client = MagicMock()
        client.gather = AsyncMock()

        async def mock_get_client() -> MagicMock:
            return client

        monkeypatch.setattr(
            "www_confluence_mcp.api.session.get_client", mock_get_client
        )
        return client

    @pytest.mark.asyncio
    async def test_request_success(self, mock_client: MagicMock) -> None:
        """Test _request returns parsed JSON on success."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.content = b'{"id": "1", "title": "Test"}'
        mock_response.json.return_value = {"id": "1", "title": "Test"}

        async def mock_request(*args, **kwargs):
            return mock_response

        mock_client.request = mock_request
        mock_client.gather = AsyncMock()

        from www_confluence_mcp.api.session import request

        result = await request("GET", "/test")

        assert result == {"id": "1", "title": "Test"}

    @pytest.mark.asyncio
    async def test_request_404_raises_not_found(self, mock_client: MagicMock) -> None:
        """Test _request raises ConfluenceNotFoundError on 404."""
        mock_response = MagicMock()
        mock_response.status_code = 404
        mock_response.text = "Not found"

        async def mock_request(*args, **kwargs):
            raise niquests.exceptions.HTTPError("404", response=mock_response)

        mock_client.request = mock_request

        from www_confluence_mcp.api.session import request

        with pytest.raises(ConfluenceNotFoundError):
            await request("GET", "/test")

    @pytest.mark.asyncio
    async def test_request_403_raises_permission_error(
        self, mock_client: MagicMock
    ) -> None:
        """Test _request raises ConfluencePermissionError on 403."""
        mock_response = MagicMock()
        mock_response.status_code = 403
        mock_response.text = "Forbidden"

        async def mock_request(*args, **kwargs):
            raise niquests.exceptions.HTTPError("403", response=mock_response)

        mock_client.request = mock_request

        from www_confluence_mcp.api.session import request

        with pytest.raises(ConfluencePermissionError):
            await request("GET", "/test")

    @pytest.mark.asyncio
    async def test_request_409_raises_conflict_error(
        self, mock_client: MagicMock
    ) -> None:
        """Test _request raises ConfluenceConflictError on 409."""
        mock_response = MagicMock()
        mock_response.status_code = 409
        mock_response.text = "Conflict"

        async def mock_request(*args, **kwargs):
            raise niquests.exceptions.HTTPError("409", response=mock_response)

        mock_client.request = mock_request

        from www_confluence_mcp.api.session import request

        with pytest.raises(ConfluenceConflictError):
            await request("GET", "/test")

    @pytest.mark.asyncio
    async def test_request_429_raises_rate_limit_error(
        self, mock_client: MagicMock
    ) -> None:
        """Test _request raises ConfluenceRateLimitError on 429."""
        mock_response = MagicMock()
        mock_response.status_code = 429
        mock_response.text = "Rate limit exceeded"
        mock_response.headers = {"Retry-After": "60"}

        async def mock_request(*args, **kwargs):
            raise niquests.exceptions.HTTPError("429", response=mock_response)

        mock_client.request = mock_request

        from www_confluence_mcp.api.session import request

        with pytest.raises(ConfluenceRateLimitError) as exc_info:
            await request("GET", "/test")

        assert exc_info.value.retry_after == 60.0

    @pytest.mark.asyncio
    async def test_request_500_raises_api_error(self, mock_client: MagicMock) -> None:
        """Test _request raises ConfluenceAPIError on 5xx."""
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.text = "Internal server error"

        async def mock_request(*args, **kwargs):
            raise niquests.exceptions.HTTPError("500", response=mock_response)

        mock_client.request = mock_request

        from www_confluence_mcp.api.session import request

        with pytest.raises(ConfluenceAPIError):
            await request("GET", "/test")

    @pytest.mark.asyncio
    async def test_request_timeout_raises_timeout_error(
        self, mock_client: MagicMock
    ) -> None:
        """Test _request raises ConfluenceTimeoutError on timeout."""

        async def mock_request(*args, **kwargs):
            raise niquests.exceptions.Timeout("Request timed out")

        mock_client.request = mock_request

        from www_confluence_mcp.api.session import request

        with pytest.raises(ConfluenceTimeoutError):
            await request("GET", "/test")

    @pytest.mark.asyncio
    async def test_request_204_returns_none(self, mock_client: MagicMock) -> None:
        """Test _request returns None on 204 No Content."""
        mock_response = MagicMock()
        mock_response.status_code = 204
        mock_response.content = b""

        async def mock_request(*args, **kwargs):
            return mock_response

        mock_client.request = mock_request
        mock_client.gather = AsyncMock()

        from www_confluence_mcp.api.session import request

        result = await request("DELETE", "/test")

        assert result is None


# ---------------------------------------------------------------------------
# Test Search CQL Detection
# ---------------------------------------------------------------------------


class TestSearch:
    """Test search function CQL detection and construction."""

    @pytest.mark.asyncio
    async def test_simple_text_wrapped_in_cql(self) -> None:
        """Test simple text query is wrapped in CQL text search."""
        mock_request = AsyncMock(return_value={"results": []})
        with patch("www_confluence_mcp.api.search.request", mock_request):
            await search_cql("hello")

        mock_request.assert_called_once()
        call_args = mock_request.call_args
        cql = call_args[1]["params"]["cql"]
        assert 'text ~ "hello"' in cql

    @pytest.mark.asyncio
    async def test_cql_passthrough(self) -> None:
        """Test CQL query passes through unchanged."""
        mock_request = AsyncMock(return_value={"results": []})
        with patch("www_confluence_mcp.api.search.request", mock_request):
            await search_cql("type=page AND space=DEV")

        mock_request.assert_called_once()
        call_args = mock_request.call_args
        cql = call_args[1]["params"]["cql"]
        assert "type=page AND space=DEV" in cql

    @pytest.mark.asyncio
    async def test_search_with_spaces_filter(self) -> None:
        """Test search adds space filter."""
        mock_request = AsyncMock(return_value={"results": []})
        with patch("www_confluence_mcp.api.search.request", mock_request):
            await search_cql("hello", spaces=["DEV", "TEST"])

        mock_request.assert_called_once()
        call_args = mock_request.call_args
        cql = call_args[1]["params"]["cql"]
        assert 'space = "DEV"' in cql or 'space = "TEST"' in cql

    @pytest.mark.asyncio
    async def test_search_with_content_types_filter(self) -> None:
        """Test search adds content type filter."""
        mock_request = AsyncMock(return_value={"results": []})
        with patch("www_confluence_mcp.api.search.request", mock_request):
            await search_cql("hello", content_types=["page", "blogpost"])

        mock_request.assert_called_once()
        call_args = mock_request.call_args
        cql = call_args[1]["params"]["cql"]
        assert 'type = "page"' in cql or 'type = "blogpost"' in cql

    @pytest.mark.asyncio
    async def test_cql_detection_with_field_operators(self) -> None:
        """Test CQL detection recognizes field operators."""
        mock_request = AsyncMock(return_value={"results": []})
        with patch("www_confluence_mcp.api.search.request", mock_request):
            await search_cql('title ~ "test"')

        mock_request.assert_called_once()
        call_args = mock_request.call_args
        cql = call_args[1]["params"]["cql"]
        assert 'title ~ "test"' in cql


# ---------------------------------------------------------------------------
# Test Page Functions
# ---------------------------------------------------------------------------


class TestPages:
    """Test page-related API functions."""

    @pytest.mark.asyncio
    async def test_get_page_calls_correct_url(self) -> None:
        """Test get_page constructs correct URL."""
        mock_request = AsyncMock(return_value={"id": "1", "title": "Test"})
        with patch("www_confluence_mcp.api.pages.request", mock_request):
            result = await get_page("123")

        mock_request.assert_called_once()
        call_args = mock_request.call_args
        assert call_args[0][0] == "GET"
        assert "/rest/api/content/123" in call_args[0][1]
        assert result.id == "1"

    @pytest.mark.asyncio
    async def test_get_page_with_body_format(self) -> None:
        """Test get_page uses correct body format."""
        mock_request = AsyncMock(return_value={"id": "1"})
        with patch("www_confluence_mcp.api.pages.request", mock_request):
            await get_page("123", body_format="view")

        call_args = mock_request.call_args
        params = call_args[1]["params"]
        assert "body.view" in params["expand"]

    @pytest.mark.asyncio
    async def test_create_page_constructs_payload(self) -> None:
        """Test create_page sends correct payload."""
        mock_request = AsyncMock(return_value={"id": "1", "title": "New Page"})
        with patch("www_confluence_mcp.api.pages.request", mock_request):
            result = await create_page(
                space_key="DEV",
                title="New Page",
                body_value="Hello World",
                parent_id="456",
            )

        mock_request.assert_called_once()
        call_args = mock_request.call_args
        assert call_args[0][0] == "POST"
        assert call_args[0][1] == "/rest/api/content"

        json_payload = call_args[1]["json"]
        assert json_payload["title"] == "New Page"
        assert json_payload["space"]["key"] == "DEV"
        assert json_payload["ancestors"] == [{"id": "456"}]
        assert result.id == "1"

    @pytest.mark.asyncio
    async def test_update_page_constructs_payload(self) -> None:
        """Test update_page sends correct payload."""
        mock_request = AsyncMock(return_value={"id": "1", "title": "Updated"})
        with patch("www_confluence_mcp.api.pages.request", mock_request):
            await update_page(
                page_id="123",
                title="Updated",
                body_value="New content",
                version_number=5,
            )

        mock_request.assert_called_once()
        call_args = mock_request.call_args
        assert call_args[0][0] == "PUT"
        assert "/rest/api/content/123" in call_args[0][1]

        json_payload = call_args[1]["json"]
        assert json_payload["version"]["number"] == 5
        assert json_payload["title"] == "Updated"

    @pytest.mark.asyncio
    async def test_delete_page_calls_correct_url(self) -> None:
        """Test delete_page constructs correct URL."""
        mock_request = AsyncMock(return_value=None)
        with patch("www_confluence_mcp.api.pages.request", mock_request):
            await delete_page("123")

        mock_request.assert_called_once()
        call_args = mock_request.call_args
        assert call_args[0][0] == "DELETE"
        assert "/rest/api/content/123" in call_args[0][1]

    @pytest.mark.asyncio
    async def test_get_page_by_title_searches_correctly(self) -> None:
        """Test get_page_by_title constructs correct search."""
        mock_request = AsyncMock(
            return_value={"results": [{"id": "1", "title": "Test"}]}
        )
        with patch("www_confluence_mcp.api.pages.request", mock_request):
            result = await get_page_by_title("DEV", "Test")

        mock_request.assert_called_once()
        call_args = mock_request.call_args
        params = call_args[1]["params"]
        assert params["spaceKey"] == "DEV"
        assert params["title"] == "Test"
        assert result.id == "1"


# ---------------------------------------------------------------------------
# Test Spaces Functions
# ---------------------------------------------------------------------------


class TestSpaces:
    """Test space-related API functions."""

    @pytest.mark.asyncio
    async def test_get_spaces_calls_correct_url(self) -> None:
        """Test get_spaces constructs correct URL."""
        mock_request = AsyncMock(return_value={"results": []})
        with patch("www_confluence_mcp.api.spaces.request", mock_request):
            await get_spaces()

        mock_request.assert_called_once()
        call_args = mock_request.call_args
        assert call_args[0][0] == "GET"
        assert call_args[0][1] == "/rest/api/space"

    @pytest.mark.asyncio
    async def test_get_space_encodes_space_key(self) -> None:
        """Test get_space URL-encodes space key."""
        mock_request = AsyncMock(return_value={"key": "DEV", "name": "Development"})
        with patch("www_confluence_mcp.api.spaces.request", mock_request):
            await get_space("DEV")

        mock_request.assert_called_once()
        call_args = mock_request.call_args
        assert call_args[0][0] == "GET"
        assert "/rest/api/space/DEV" in call_args[0][1]


# ---------------------------------------------------------------------------
# Test Labels Functions
# ---------------------------------------------------------------------------


class TestLabels:
    """Test label-related API functions."""

    @pytest.mark.asyncio
    async def test_get_page_labels_calls_correct_url(self) -> None:
        """Test get_page_labels constructs correct URL."""
        mock_request = AsyncMock(return_value={"results": []})
        with patch("www_confluence_mcp.api.labels.request", mock_request):
            await get_page_labels("123")

        mock_request.assert_called_once()
        call_args = mock_request.call_args
        assert call_args[0][0] == "GET"
        assert "/rest/api/content/123/label" in call_args[0][1]

    @pytest.mark.asyncio
    async def test_add_page_labels_constructs_payload(self) -> None:
        """Test add_page_labels sends correct payload."""
        mock_request = AsyncMock(return_value={"results": [{"name": "test-label"}]})
        with patch("www_confluence_mcp.api.labels.request", mock_request):
            await add_page_labels("123", ["test-label", "another-label"])

        mock_request.assert_called_once()
        call_args = mock_request.call_args
        json_payload = call_args[1]["json"]
        assert len(json_payload) == 2
        assert json_payload[0]["name"] == "test-label"
        assert json_payload[0]["prefix"] == "global"


# ---------------------------------------------------------------------------
# Test Page Cache
# ---------------------------------------------------------------------------


class TestPageCache:
    """Test page caching functionality."""

    async def test_get_page_cached_hits_cache(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Second call returns cached data without API call."""
        from www_confluence_mcp.api.caching import get_page_cached
        from www_confluence_mcp.utils.cache import page_cache

        await page_cache.clear()
        call_count = 0

        async def mock_get_page(page_id: str, body_format: str = "storage") -> dict:
            nonlocal call_count
            call_count += 1
            return {"id": page_id, "title": "Test"}

        monkeypatch.setattr("www_confluence_mcp.api.pages.get_page", mock_get_page)

        r1 = await get_page_cached("123")
        r2 = await get_page_cached("123")

        assert r1 == r2
        assert call_count == 1  # Only one API call

        await page_cache.clear()

    async def test_invalidate_page_cache(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """invalidate_page_cache forces next fetch from API."""
        from www_confluence_mcp.api.caching import (
            get_page_cached,
            invalidate_page_cache,
        )
        from www_confluence_mcp.utils.cache import page_cache

        await page_cache.clear()
        call_count = 0

        async def mock_get_page(page_id: str, body_format: str = "storage") -> dict:
            nonlocal call_count
            call_count += 1
            return {"id": page_id, "title": "Test"}

        monkeypatch.setattr("www_confluence_mcp.api.pages.get_page", mock_get_page)

        await get_page_cached("123")
        await invalidate_page_cache("123")
        await get_page_cached("123")

        assert call_count == 2  # Two API calls (cache invalidated)

        await page_cache.clear()


# ---------------------------------------------------------------------------
# Test Attachments Functions
# ---------------------------------------------------------------------------


class TestAttachments:
    """Test attachment-related API functions."""

    @pytest.mark.asyncio
    async def test_get_attachments_calls_correct_url(self) -> None:
        """Test get_attachments constructs correct URL."""
        mock_request = AsyncMock(return_value={"results": []})
        with patch("www_confluence_mcp.api.attachments.request", mock_request):
            result = await get_attachments("123")

        mock_request.assert_called_once()
        call_args = mock_request.call_args
        assert call_args[0][0] == "GET"
        assert "/rest/api/content/123/child/attachment" in call_args[0][1]
        params = call_args[1]["params"]
        assert params["limit"] == 25
        assert params["start"] == 0
        assert params["expand"] == "version"
        assert result.results == []

    @pytest.mark.asyncio
    async def test_upload_attachment_sends_multipart(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Any
    ) -> None:
        """Test upload_attachment sends multipart form data."""
        # Create a temp file
        test_file = tmp_path / "test.txt"
        test_file.write_text("Hello World")

        # Mock get_client and niquests response
        mock_client = MagicMock()
        mock_client.gather = AsyncMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"id": "att1", "title": "test.txt"}

        mock_post = AsyncMock(return_value=mock_response)
        mock_client.post = mock_post
        mock_client.base_url = "https://example.atlassian.net"

        async def mock_get_client() -> MagicMock:
            return mock_client

        monkeypatch.setattr(
            "www_confluence_mcp.api.attachments.get_client", mock_get_client
        )

        result = await upload_attachment("123", str(test_file), comment="Test comment")

        assert result.id == "att1"
        # Verify post was called with files and data
        mock_post.assert_called_once()
        call_args = mock_post.call_args
        assert call_args[0][0] == "/rest/api/content/123/child/attachment"
        assert "file" in call_args[1]["files"]
        assert call_args[1]["data"]["comment"] == "Test comment"
        assert call_args[1]["headers"]["X-Atlassian-Token"] == "no-check"

    @pytest.mark.asyncio
    async def test_download_attachment_saves_file(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Any
    ) -> None:
        """Test download_attachment saves file to disk."""

        # Mock get_client
        mock_client = MagicMock()
        mock_client.base_url = "https://example.atlassian.net"
        mock_client.gather = AsyncMock()

        # Mock _request for metadata fetch
        mock_metadata = {
            "id": "att1",
            "_links": {"download": "/download/attachment/att1/test.txt"},
        }

        # Mock get response for streaming
        mock_get_response = MagicMock()
        mock_get_response.status_code = 200
        mock_get_response.content = b"Hello World"

        mock_get_response.raise_for_status = MagicMock()
        mock_get_response.close = MagicMock()

        async def mock_get(url: str, stream: bool = False):
            return mock_get_response

        mock_client.get = mock_get

        async def mock_get_client() -> MagicMock:
            return mock_client

        async def mock_request(
            method: str, path: str, params: dict[str, Any] | None = None
        ) -> dict[str, Any]:
            return mock_metadata

        monkeypatch.setattr(
            "www_confluence_mcp.api.attachments.get_client", mock_get_client
        )
        monkeypatch.setattr("www_confluence_mcp.api.attachments.request", mock_request)

        save_path = tmp_path / "downloaded.txt"
        result = await download_attachment("att1", str(save_path))

        assert result.status == "downloaded"
        assert result.attachment_id == "att1"
        assert result.bytes == 11  # "Hello World" = 11 bytes
        assert save_path.exists()
        assert save_path.read_text() == "Hello World"

    @pytest.mark.asyncio
    async def test_delete_attachment_calls_delete(self) -> None:
        """Test delete_attachment constructs correct DELETE request."""
        mock_request = AsyncMock(return_value=None)
        with patch("www_confluence_mcp.api.attachments.request", mock_request):
            await delete_attachment("att1")

        mock_request.assert_called_once()
        call_args = mock_request.call_args
        assert call_args[0][0] == "DELETE"
        assert "/rest/api/content/att1" in call_args[0][1]


# ---------------------------------------------------------------------------
# Test Comments Functions
# ---------------------------------------------------------------------------


class TestComments:
    """Test comment-related API functions."""

    @pytest.mark.asyncio
    async def test_get_footer_comments_calls_correct_url(self) -> None:
        """Test get_footer_comments constructs correct URL."""
        mock_request = AsyncMock(return_value={"results": []})
        with patch("www_confluence_mcp.api.comments.request", mock_request):
            result = await get_footer_comments("123")

        mock_request.assert_called_once()
        call_args = mock_request.call_args
        assert call_args[0][0] == "GET"
        assert "/rest/api/content/123/child/comment" in call_args[0][1]
        params = call_args[1]["params"]
        assert params["limit"] == 25
        assert params["start"] == 0
        assert params["expand"] == "version"
        assert result.results == []

    @pytest.mark.asyncio
    async def test_create_comment_sends_payload(self) -> None:
        """Test create_comment sends correct JSON payload."""
        mock_request = AsyncMock(
            return_value={"id": "c1", "body": {"storage": {"value": "Test comment"}}}
        )
        with patch("www_confluence_mcp.api.comments.request", mock_request):
            result = await create_comment("123", "Test comment")

        mock_request.assert_called_once()
        call_args = mock_request.call_args
        assert call_args[0][0] == "POST"
        assert call_args[0][1] == "/rest/api/content"

        json_payload = call_args[1]["json"]
        assert json_payload["type"] == "comment"
        assert json_payload["body"]["storage"]["value"] == "Test comment"
        assert json_payload["body"]["storage"]["representation"] == "storage"
        assert json_payload["container"]["id"] == "123"
        assert json_payload["container"]["type"] == "page"
        assert result.id == "c1"

    @pytest.mark.asyncio
    async def test_reply_to_comment_sends_payload(self) -> None:
        """Test reply_to_comment sends correct JSON payload."""
        mock_request = AsyncMock(
            return_value={"id": "c2", "body": {"storage": {"value": "Reply"}}}
        )
        with patch("www_confluence_mcp.api.comments.request", mock_request):
            result = await reply_to_comment("c1", "Reply")

        mock_request.assert_called_once()
        call_args = mock_request.call_args
        assert call_args[0][0] == "POST"
        assert call_args[0][1] == "/rest/api/content"

        json_payload = call_args[1]["json"]
        assert json_payload["type"] == "comment"
        assert json_payload["body"]["storage"]["value"] == "Reply"
        assert json_payload["container"]["id"] == "c1"
        assert json_payload["container"]["type"] == "comment"
        assert result.id == "c2"


# ---------------------------------------------------------------------------
# Test Users Functions
# ---------------------------------------------------------------------------


class TestUsers:
    """Test user-related API functions."""

    @pytest.mark.asyncio
    async def test_search_user_calls_correct_url(self) -> None:
        """Test search_user constructs correct CQL query."""
        mock_request = AsyncMock(return_value={"results": []})
        with patch("www_confluence_mcp.api.users.request", mock_request):
            result = await search_user("John Doe")

        mock_request.assert_called_once()
        call_args = mock_request.call_args
        assert call_args[0][0] == "GET"
        assert call_args[0][1] == "/rest/api/search"

        params = call_args[1]["params"]
        assert 'type=user AND user.fullname ~ "John Doe"' in params["cql"]
        assert params["limit"] == 25
        assert params["start"] == 0
        assert result == []


# ---------------------------------------------------------------------------
# Test Images Functions
# ---------------------------------------------------------------------------


class TestImages:
    """Test image-related API functions."""

    @pytest.mark.asyncio
    async def test_get_page_images_filters_by_mime(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test get_page_images filters attachments by MIME type."""
        from www_confluence_mcp.models import Attachment

        # Mock _fetch_all_attachments to return mixed attachments as Attachment models
        mock_attachments = [
            Attachment(
                id="att1",
                title="image.png",
                mediaType="image/png",
                _links={"download": "/download/att1"},
            ),
            Attachment(
                id="att2",
                title="doc.pdf",
                mediaType="application/pdf",
                _links={"download": "/download/att2"},
            ),
            Attachment(
                id="att3",
                title="photo.jpg",
                mediaType="image/jpeg",
                _links={"download": "/download/att3"},
            ),
        ]

        async def mock_fetch_all(page_id: str) -> list[Attachment]:
            return mock_attachments

        monkeypatch.setattr(
            "www_confluence_mcp.api.images._fetch_all_attachments", mock_fetch_all
        )

        # Mock get_client
        mock_client = MagicMock()
        mock_client.base_url = "https://example.atlassian.net"
        mock_client.gather = AsyncMock()

        # Mock HEAD response
        mock_head_resp = MagicMock()
        mock_head_resp.status_code = 200
        mock_head_resp.headers = {"content-length": "1000"}
        mock_client.head = AsyncMock(return_value=mock_head_resp)

        # Mock GET response
        mock_get_resp = MagicMock()
        mock_get_resp.status_code = 200
        mock_get_resp.content = b"fake_image_data"
        mock_get_resp.raise_for_status = MagicMock()
        mock_client.get = AsyncMock(return_value=mock_get_resp)

        async def mock_get_client() -> MagicMock:
            return mock_client

        monkeypatch.setattr("www_confluence_mcp.api.images.get_client", mock_get_client)

        result = await get_page_images("123")

        # Should only return images, not PDF
        assert len(result) == 2
        for img in result:
            assert img.status != "skipped" or img.mime_type is not None
            # Verify only image mime types
            if img.mime_type:
                assert img.mime_type in ["image/png", "image/jpeg"]


class TestPagesExtended:
    """Test extended page-related API functions."""

    @pytest.mark.asyncio
    async def test_get_pages_in_space_calls_correct_url(self) -> None:
        """Test get_pages_in_space constructs correct URL."""
        mock_request = AsyncMock(return_value={"results": []})
        with patch("www_confluence_mcp.api.pages.request", mock_request):
            result = await get_pages_in_space("DEV")

        mock_request.assert_called_once()
        call_args = mock_request.call_args
        assert call_args[0][0] == "GET"
        assert call_args[0][1] == "/rest/api/content"

        params = call_args[1]["params"]
        assert params["spaceKey"] == "DEV"
        assert params["status"] == "current"
        assert params["limit"] == 25
        assert params["start"] == 0
        assert params["expand"] == "version,space"
        assert result.results == []

    @pytest.mark.asyncio
    async def test_get_child_pages_calls_correct_url(self) -> None:
        """Test get_child_pages constructs correct URL."""
        mock_request = AsyncMock(return_value={"results": []})
        with patch("www_confluence_mcp.api.pages.request", mock_request):
            result = await get_child_pages("123")

        mock_request.assert_called_once()
        call_args = mock_request.call_args
        assert call_args[0][0] == "GET"
        assert "/rest/api/content/123/child/page" in call_args[0][1]

        params = call_args[1]["params"]
        assert params["limit"] == 25
        assert params["start"] == 0
        assert params["expand"] == "version,space"
        assert result.results == []

    @pytest.mark.asyncio
    async def test_get_page_ancestors_calls_correct_url(self) -> None:
        """Test get_page_ancestors constructs correct URL."""
        mock_request = AsyncMock(
            return_value={"id": "123", "ancestors": [{"id": "1", "title": "Parent"}]}
        )
        with patch("www_confluence_mcp.api.pages.request", mock_request):
            result = await get_page_ancestors("123")

        mock_request.assert_called_once()
        call_args = mock_request.call_args
        assert call_args[0][0] == "GET"
        assert "/rest/api/content/123" in call_args[0][1]

        params = call_args[1]["params"]
        assert params["expand"] == "ancestors"
        assert result == [{"id": "1", "title": "Parent"}]

    @pytest.mark.asyncio
    async def test_move_page_sends_payload(self) -> None:
        """Test move_page fetches current page and sends update payload."""
        call_sequence: list[tuple[str, str, dict[str, Any] | None, Any]] = []

        async def mock_request(
            method: str,
            path: str,
            params: dict[str, Any] | None = None,
            json: Any = None,
        ) -> dict[str, Any]:
            call_sequence.append((method, path, params, json))

            if method == "GET":
                # Fetch current page
                return {
                    "id": "123",
                    "title": "Page to Move",
                    "version": {"number": 5},
                    "space": {"key": "DEV"},
                    "ancestors": [{"id": "parent1"}],
                    "body": {"storage": {"value": "Page content"}},
                    "status": "current",
                }
            else:
                # PUT update
                return {
                    "id": "123",
                    "title": "Page to Move",
                    "version": {"number": 6},
                    "space": {"key": "NEW"},
                }

        with patch("www_confluence_mcp.api.pages.request", mock_request):
            await move_page("123", space_key="NEW")

        # Should have 2 calls: GET then PUT
        assert len(call_sequence) == 2
        assert call_sequence[0][0] == "GET"
        assert call_sequence[1][0] == "PUT"

        # Verify PUT payload
        put_json = call_sequence[1][3]
        assert put_json["version"]["number"] == 6  # incremented
        assert put_json["space"]["key"] == "NEW"
        assert put_json["title"] == "Page to Move"
