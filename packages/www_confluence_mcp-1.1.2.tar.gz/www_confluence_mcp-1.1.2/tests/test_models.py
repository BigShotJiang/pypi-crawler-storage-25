"""Tests for Pydantic models in www_confluence_mcp.models."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from www_confluence_mcp.models import (
    Attachment,
    AttachmentDownloadResult,
    AttachmentDeletionResult,
    AttachmentUploadResult,
    AttachmentUploadBatchResponse,
    ContentAttachmentDownloadResult,
    ContentAttachmentDownloadBatchResponse,
    Comment,
    ConfluenceMarkdownDocument,
    ConfluenceMarkdownMeta,
    ImageResult,
    Label,
    LabelResponse,
    Page,
    PageData,
    PageHistoryResult,
    SearchResult,
    Space,
    User,
    Version,
    ConfluenceMacroPreserved,
    ConversionResult,
)


class TestConfluenceMarkdownMeta:
    """Tests for ConfluenceMarkdownMeta model."""

    def test_required_fields_only(self):
        """Test creation with only required fields."""
        meta = ConfluenceMarkdownMeta(pageId="12345", space="DEV")
        assert meta.pageId == "12345"
        assert meta.space == "DEV"
        assert meta.title == ""
        assert meta.version == 1
        assert meta.last_updated == ""
        assert meta.url == ""

    def test_all_fields_provided(self):
        """Test creation with all fields provided."""
        meta = ConfluenceMarkdownMeta(
            pageId="67890",
            space="PROD",
            title="Production Guide",
            version=5,
            last_updated="2024-01-15T10:30:00Z",
            url="https://wiki.example.com/display/PROD/page",
        )
        assert meta.pageId == "67890"
        assert meta.space == "PROD"
        assert meta.title == "Production Guide"
        assert meta.version == 5
        assert meta.last_updated == "2024-01-15T10:30:00Z"
        assert meta.url == "https://wiki.example.com/display/PROD/page"

    def test_missing_required_pageid(self):
        """Test validation error when pageId is missing."""
        with pytest.raises(ValidationError) as exc_info:
            ConfluenceMarkdownMeta(space="DEV")
        assert "pageId" in str(exc_info.value)

    def test_missing_required_space(self):
        """Test validation error when space is missing."""
        with pytest.raises(ValidationError) as exc_info:
            ConfluenceMarkdownMeta(pageId="12345")
        assert "space" in str(exc_info.value)

    def test_default_values(self):
        """Test that default values are applied correctly."""
        meta = ConfluenceMarkdownMeta(pageId="111", space="TEST")
        assert meta.title == ""
        assert meta.version == 1
        assert meta.last_updated == ""
        assert meta.url == ""


class TestConfluenceMarkdownDocument:
    """Tests for ConfluenceMarkdownDocument model."""

    def test_with_nested_meta(self):
        """Test creation with nested ConfluenceMarkdownMeta."""
        meta = ConfluenceMarkdownMeta(pageId="999", space="DOC")
        doc = ConfluenceMarkdownDocument(confluence=meta)
        assert doc.confluence.pageId == "999"
        assert doc.confluence.space == "DOC"
        assert doc.format == "confluence_markdown"
        assert doc.conversion_timestamp == ""

    def test_all_fields_provided(self):
        """Test creation with all fields provided."""
        meta = ConfluenceMarkdownMeta(
            pageId="888",
            space="SPEC",
            title="Specification",
            version=3,
            last_updated="2024-02-20T14:00:00Z",
            url="https://wiki.example.com/display/SPEC/doc",
        )
        doc = ConfluenceMarkdownDocument(
            confluence=meta,
            format="custom_format",
            conversion_timestamp="2024-02-20T15:00:00Z",
        )
        assert doc.confluence.title == "Specification"
        assert doc.format == "custom_format"
        assert doc.conversion_timestamp == "2024-02-20T15:00:00Z"

    def test_extra_fields_allowed(self):
        """Test that extra fields are allowed in the model."""
        meta = ConfluenceMarkdownMeta(pageId="777", space="EXTRA")
        # Extra fields are allowed by Pydantic's extra="allow" config
        # Use model_construct to bypass type checking for extra fields
        doc = ConfluenceMarkdownDocument.model_construct(
            confluence=meta,
            custom_field="custom_value",
            another_field=42,
        )
        # Access extra fields via model_dump() for type safety
        dump = doc.model_dump()
        assert dump.get("custom_field") == "custom_value"
        assert dump.get("another_field") == 42

    def test_missing_required_confluence(self):
        """Test validation error when confluence is missing."""
        with pytest.raises(ValidationError):
            ConfluenceMarkdownDocument(**{})  # type: ignore[arg-type]


class TestConversionResult:
    """Tests for ConversionResult model."""

    def test_ok_status_minimal(self):
        """Test successful conversion with minimal fields."""
        result = ConversionResult(status="ok")
        assert result.status == "ok"
        assert result.page_id == ""
        assert result.title == ""
        assert result.format == ""
        assert result.file_path == ""
        assert result.elements_preserved == 0
        assert result.warnings == []
        assert result.error is None

    def test_ok_status_with_details(self):
        """Test successful conversion with all details."""
        result = ConversionResult(
            status="ok",
            page_id="555",
            title="Test Page",
            format="markdown",
            file_path="/output/test.md",
            elements_preserved=15,
            warnings=["Warning 1", "Warning 2"],
        )
        assert result.status == "ok"
        assert result.page_id == "555"
        assert result.title == "Test Page"
        assert result.format == "markdown"
        assert result.file_path == "/output/test.md"
        assert result.elements_preserved == 15
        assert result.warnings == ["Warning 1", "Warning 2"]
        assert result.error is None

    def test_error_status(self):
        """Test failed conversion with error message."""
        result = ConversionResult(
            status="error",
            page_id="444",
            error="Connection timeout to Confluence API",
        )
        assert result.status == "error"
        assert result.page_id == "444"
        assert result.error == "Connection timeout to Confluence API"

    def test_error_with_warnings(self):
        """Test error status with warnings."""
        result = ConversionResult(
            status="error",
            error="Failed to parse macro",
            warnings=["Partial content recovered"],
        )
        assert result.status == "error"
        assert result.error == "Failed to parse macro"
        assert result.warnings == ["Partial content recovered"]

    def test_missing_required_status(self):
        """Test validation error when status is missing."""
        with pytest.raises(ValidationError) as exc_info:
            ConversionResult()
        assert "status" in str(exc_info.value)


class TestConfluenceMacroPreserved:
    """Tests for ConfluenceMacroPreserved model."""

    def test_required_fields_only(self):
        """Test creation with only required fields."""
        macro = ConfluenceMacroPreserved(name="info")
        assert macro.name == "info"
        assert macro.schema_version == ""
        assert macro.macro_id == ""
        assert macro.parameters == {}
        assert macro.body_preview == ""
        assert macro.original_html == ""

    def test_all_fields_provided(self):
        """Test creation with all fields provided."""
        macro = ConfluenceMacroPreserved(
            name="code",
            schema_version="1.0",
            macro_id="macro-123",
            parameters={"language": "python", "theme": "dark"},
            body_preview="def hello():\n    print('Hello')",
            original_html='<ac:structured-macro ac:name="code">...</ac:structured-macro>',
        )
        assert macro.name == "code"
        assert macro.schema_version == "1.0"
        assert macro.macro_id == "macro-123"
        assert macro.parameters == {
            "language": "python",
            "theme": "dark",
        }
        assert macro.body_preview == "def hello():\n    print('Hello')"
        assert (
            macro.original_html
            == '<ac:structured-macro ac:name="code">...</ac:structured-macro>'
        )

    def test_missing_required_name(self):
        """Test validation error when name is missing."""
        with pytest.raises(ValidationError) as exc_info:
            ConfluenceMacroPreserved()
        assert "name" in str(exc_info.value)

    def test_empty_parameters_default(self):
        """Test that parameters default to empty dict."""
        macro = ConfluenceMacroPreserved(name="note")
        assert macro.parameters == {}
        assert isinstance(macro.parameters, dict)


class TestPageData:
    """Tests for PageData model."""

    def test_minimal_fields(self):
        """Test creation with minimal required fields."""
        page = PageData(id="100", title="Home")
        assert page.id == "100"
        assert page.title == "Home"
        assert page.type == "page"
        assert page.status == "current"
        assert page.space_key == ""
        assert page.version_number == 1
        assert page.version_when == ""
        assert page.body_storage == ""

    def test_all_fields_provided(self):
        """Test creation with all fields provided."""
        page = PageData(
            id="200",
            title="Documentation",
            type="blogpost",
            status="draft",
            space_key="DOC",
            version_number=7,
            version_when="2024-03-10T09:00:00Z",
            body_storage="<p>Content here</p>",
        )
        assert page.id == "200"
        assert page.title == "Documentation"
        assert page.type == "blogpost"
        assert page.status == "draft"
        assert page.space_key == "DOC"
        assert page.version_number == 7
        assert page.version_when == "2024-03-10T09:00:00Z"
        assert page.body_storage == "<p>Content here</p>"

    def test_extra_fields_allowed(self):
        """Test that extra fields are allowed."""
        # Extra fields are allowed by Pydantic's extra="allow" config
        # Use model_construct to bypass type checking for extra fields
        page = PageData.model_construct(
            id="300",
            title="Extra Page",
            custom_metadata={"key": "value"},
            extra_field=123,
        )
        dump = page.model_dump()
        assert dump.get("custom_metadata") == {"key": "value"}
        assert dump.get("extra_field") == 123

    def test_missing_required_id(self):
        """Test that id has default empty string when not provided."""
        page = PageData(title="No ID")
        assert page.id == ""
        assert page.title == "No ID"

    def test_missing_required_title(self):
        """Test that title has default empty string when not provided."""
        page = PageData(id="400")
        assert page.id == "400"
        assert page.title == ""

    def test_default_type_and_status(self):
        """Test default values for type and status."""
        page = PageData(id="500", title="Defaults Test")
        assert page.type == "page"
        assert page.status == "current"


class TestUser:
    """Tests for User model."""

    def test_minimal_fields(self):
        """Test creation with minimal fields."""
        user = User(username="jdoe", displayName="John Doe")
        assert user.username == "jdoe"
        assert user.displayName == "John Doe"
        assert user.email is None
        assert user.profile_picture is None
        assert user.links == {}

    def test_all_fields_provided(self):
        """Test creation with all fields provided."""
        user = User(
            username="jdoe",
            displayName="John Doe",
            email="jdoe@example.com",
            profile_picture="https://example.com/avatar.png",
            _links={"self": {"href": "/users/jdoe"}},
        )
        assert user.username == "jdoe"
        assert user.email == "jdoe@example.com"
        assert user.profile_picture == "https://example.com/avatar.png"
        assert user.links == {"self": {"href": "/users/jdoe"}}

    def test_extra_fields_allowed(self):
        """Test that extra fields are allowed."""
        # Extra fields are allowed by Pydantic's extra="allow" config
        # Use model_construct to bypass type checking for extra fields
        user = User.model_construct(
            username="jdoe",
            displayName="John Doe",
            custom_field="value",
        )
        dump = user.model_dump()
        assert dump.get("custom_field") == "value"


class TestSpace:
    """Tests for Space model."""

    def test_minimal_fields(self):
        """Test creation with minimal fields."""
        space = Space(id="123", key="DEV", name="Development")
        assert space.id == "123"
        assert space.key == "DEV"
        assert space.name == "Development"
        assert space.description is None
        assert space.type == "global"
        assert space.status == "current"

    def test_all_fields_provided(self):
        """Test creation with all fields provided."""
        space = Space(
            id="456",
            key="PROD",
            name="Production",
            description="Production documentation",
            type="personal",
            status="archived",
        )
        assert space.id == "456"
        assert space.key == "PROD"
        assert space.description == "Production documentation"
        assert space.type == "personal"
        assert space.status == "archived"


class TestVersion:
    """Tests for Version model."""

    def test_minimal_fields(self):
        """Test creation with minimal fields."""
        version = Version(number=1)
        assert version.number == 1
        assert version.when == ""
        assert version.message is None
        assert version.by is None

    def test_all_fields_provided(self):
        """Test creation with all fields provided."""
        by_user = User(username="editor", displayName="Editor")
        version = Version(
            number=5,
            when="2024-01-15T10:00:00Z",
            message="Updated content",
            by=by_user,
        )
        assert version.number == 5
        assert version.when == "2024-01-15T10:00:00Z"
        assert version.message == "Updated content"
        assert version.by is not None
        assert version.by.username == "editor"


class TestAttachment:
    """Tests for Attachment model."""

    def test_minimal_fields(self):
        """Test creation with minimal fields."""
        attachment = Attachment(id="att-123", title="file.pdf")
        assert attachment.id == "att-123"
        assert attachment.title == "file.pdf"
        assert attachment.type == "attachment"
        assert attachment.status == "current"
        assert attachment.mediaType is None
        assert attachment.fileSize is None

    def test_all_fields_provided(self):
        """Test creation with all fields provided."""
        version = Version(number=2)
        attachment = Attachment(
            id="att-456",
            title="document.pdf",
            mediaType="application/pdf",
            filename="document.pdf",
            fileSize=102400,
            extensions={"mediaType": "application/pdf", "fileSize": 102400},
            version=version,
            _links={"download": "/download/att-456"},
        )
        assert attachment.id == "att-456"
        assert attachment.mediaType == "application/pdf"
        assert attachment.fileSize == 102400
        assert attachment.version is not None
        assert attachment.version.number == 2


class TestComment:
    """Tests for Comment model."""

    def test_minimal_fields(self):
        """Test creation with minimal fields."""
        comment = Comment(id="comment-123", title="Re: Page")
        assert comment.id == "comment-123"
        assert comment.title == "Re: Page"
        assert comment.type == "comment"
        assert comment.status == "current"
        assert comment.body == {}

    def test_with_author(self):
        """Test creation with author."""
        author = User(username="commenter", displayName="Commenter")
        comment = Comment(
            id="comment-456",
            title="Comment",
            body={"storage": {"value": "<p>Text</p>"}},
            author=author,
        )
        assert comment.author is not None
        assert comment.author.username == "commenter"
        assert comment.body == {"storage": {"value": "<p>Text</p>"}}


class TestPage:
    """Tests for Page model."""

    def test_minimal_fields(self):
        """Test creation with minimal fields."""
        page = Page(id="page-123", title="Home")
        assert page.id == "page-123"
        assert page.title == "Home"
        assert page.type == "page"
        assert page.status == "current"
        assert page.space is None
        assert page.version is None

    def test_with_space_and_version(self):
        """Test creation with space and version."""
        space = Space(id="space-1", key="DEV", name="Development")
        version = Version(number=3)
        page = Page(
            id="page-456",
            title="Documentation",
            space=space,
            version=version,
            body={"storage": {"value": "<p>Content</p>"}},
        )
        assert page.space is not None
        assert page.space.key == "DEV"
        assert page.version is not None
        assert page.version.number == 3
        assert page.body == {"storage": {"value": "<p>Content</p>"}}


class TestSearchResult:
    """Tests for SearchResult model."""

    def test_minimal_fields(self):
        """Test creation with minimal fields."""
        result = SearchResult(id="search-123", title="Search Result")
        assert result.id == "search-123"
        assert result.title == "Search Result"
        assert result.type == ""
        assert result.status == "current"
        assert result.excerpt is None
        assert result.highlights == {}

    def test_with_space(self):
        """Test creation with space."""
        space = Space(id="space-1", key="TEST", name="Test")
        result = SearchResult(
            id="search-456",
            title="Test Page",
            type="page",
            space=space,
            excerpt="This is a search excerpt",
        )
        assert result.space is not None
        assert result.space.key == "TEST"
        assert result.excerpt == "This is a search excerpt"


class TestLabel:
    """Tests for Label model."""

    def test_minimal_fields(self):
        """Test creation with minimal fields."""
        label = Label(id="label-123", name="documentation")
        assert label.id == "label-123"
        assert label.name == "documentation"
        assert label.prefix == "global"

    def test_custom_prefix(self):
        """Test creation with custom prefix."""
        label = Label(id="label-456", name="my-label", prefix="my")
        assert label.name == "my-label"
        assert label.prefix == "my"


class TestLabelResponse:
    """Tests for LabelResponse model."""

    def test_empty_response(self):
        """Test empty label response."""
        response = LabelResponse()
        assert response.results == []
        assert response.start == 0
        assert response.limit == 25
        assert response.size == 0

    def test_with_results(self):
        """Test response with label results."""
        labels = [
            Label(id="l1", name="label1"),
            Label(id="l2", name="label2"),
        ]
        response = LabelResponse(
            results=labels,
            start=0,
            limit=10,
            size=2,
        )
        assert len(response.results) == 2
        assert response.results[0].name == "label1"
        assert response.size == 2


class TestAttachmentDownloadResult:
    """Tests for AttachmentDownloadResult model."""

    def test_minimal_fields(self):
        """Test creation with minimal fields."""
        result = AttachmentDownloadResult()
        assert result.status == "downloaded"
        assert result.attachment_id == ""
        assert result.saved_to == ""
        assert result.bytes == 0

    def test_all_fields_provided(self):
        """Test creation with all fields provided."""
        result = AttachmentDownloadResult(
            status="downloaded",
            attachment_id="att-123",
            saved_to="/path/to/file.pdf",
            bytes=102400,
        )
        assert result.attachment_id == "att-123"
        assert result.saved_to == "/path/to/file.pdf"
        assert result.bytes == 102400


class TestAttachmentDeletionResult:
    """Tests for AttachmentDeletionResult model."""

    def test_minimal_fields(self):
        """Test creation with minimal fields."""
        result = AttachmentDeletionResult()
        assert result.status == "deleted"
        assert result.attachment_id == ""

    def test_all_fields_provided(self):
        """Test creation with all fields provided."""
        result = AttachmentDeletionResult(
            status="deleted",
            attachment_id="att-123",
        )
        assert result.status == "deleted"
        assert result.attachment_id == "att-123"


class TestAttachmentUploadResult:
    """Tests for AttachmentUploadResult model."""

    def test_success_result(self):
        """Test successful upload result."""
        result = AttachmentUploadResult(
            id="att-123",
            title="file.pdf",
            status="uploaded",
        )
        assert result.id == "att-123"
        assert result.title == "file.pdf"
        assert result.status == "uploaded"
        assert result.reason is None

    def test_error_result(self):
        """Test failed upload result."""
        result = AttachmentUploadResult(
            title="file.pdf",
            status="error",
            reason="File not found",
        )
        assert result.id is None
        assert result.status == "error"
        assert result.reason == "File not found"


class TestAttachmentUploadBatchResponse:
    """Tests for AttachmentUploadBatchResponse model."""

    def test_empty_response(self):
        """Test empty batch response."""
        response = AttachmentUploadBatchResponse()
        assert response.results == []
        assert response.total == 0
        assert response.uploaded == 0
        assert response.failed == 0

    def test_with_mixed_results(self):
        """Test response with mixed success/failure results."""
        results = [
            AttachmentUploadResult(id="a1", title="file1.pdf", status="uploaded"),
            AttachmentUploadResult(
                title="file2.pdf", status="error", reason="Not found"
            ),
            AttachmentUploadResult(id="a3", title="file3.pdf", status="uploaded"),
        ]
        response = AttachmentUploadBatchResponse(
            results=results,
            total=3,
            uploaded=2,
            failed=1,
        )
        assert len(response.results) == 3
        assert response.uploaded == 2
        assert response.failed == 1


class TestContentAttachmentDownloadResult:
    """Tests for ContentAttachmentDownloadResult model."""

    def test_success_result(self):
        """Test successful download result."""
        result = ContentAttachmentDownloadResult(
            id="att-123",
            title="file.pdf",
            status="downloaded",
            bytes=1024,
            saved_to="/path/file.pdf",
        )
        assert result.id == "att-123"
        assert result.status == "downloaded"
        assert result.bytes == 1024
        assert result.saved_to == "/path/file.pdf"

    def test_skipped_result(self):
        """Test skipped download result."""
        result = ContentAttachmentDownloadResult(
            id="att-456",
            title="file2.pdf",
            status="skipped",
            reason="no download URL",
        )
        assert result.status == "skipped"
        assert result.reason == "no download URL"


class TestContentAttachmentDownloadBatchResponse:
    """Tests for ContentAttachmentDownloadBatchResponse model."""

    def test_empty_response(self):
        """Test empty batch response."""
        response = ContentAttachmentDownloadBatchResponse()
        assert response.results == []
        assert response.total == 0
        assert response.downloaded == 0
        assert response.skipped == 0
        assert response.failed == 0

    def test_with_mixed_results(self):
        """Test response with mixed results."""
        results = [
            ContentAttachmentDownloadResult(
                id="a1", title="f1.pdf", status="downloaded", bytes=100, saved_to="/f1"
            ),
            ContentAttachmentDownloadResult(
                id="a2", title="f2.pdf", status="skipped", reason="no URL"
            ),
            ContentAttachmentDownloadResult(
                id="a3", title="f3.pdf", status="error", reason="timeout"
            ),
        ]
        response = ContentAttachmentDownloadBatchResponse(
            results=results,
            total=3,
            downloaded=1,
            skipped=1,
            failed=1,
        )
        assert response.downloaded == 1
        assert response.skipped == 1
        assert response.failed == 1


class TestImageResult:
    """Tests for ImageResult model."""

    def test_success_result(self):
        """Test successful image result."""
        result = ImageResult(
            id="img-123",
            title="photo.png",
            mime_type="image/png",
            size=5000,
            data="base64encodeddata",
            status="ok",
        )
        assert result.id == "img-123"
        assert result.mime_type == "image/png"
        assert result.size == 5000
        assert result.data == "base64encodeddata"
        assert result.status == "ok"

    def test_skipped_result(self):
        """Test skipped image result."""
        result = ImageResult(
            id="img-456",
            title="large.png",
            status="skipped",
            reason="Image too large (5000000 bytes, max 1000000)",
        )
        assert result.status == "skipped"
        assert result.reason == "Image too large (5000000 bytes, max 1000000)"


class TestPageHistoryResult:
    """Tests for PageHistoryResult model."""

    def test_minimal_fields(self):
        """Test creation with minimal fields."""
        result = PageHistoryResult(page_id="page-123", title="Home")
        assert result.page_id == "page-123"
        assert result.title == "Home"
        assert result.version == {}
        assert result.history == {}

    def test_with_version_and_history(self):
        """Test creation with version and history data."""
        result = PageHistoryResult(
            page_id="page-456",
            title="Documentation",
            version={
                "number": 5,
                "by": "Editor",
                "when": "2024-01-15T10:00:00Z",
                "message": "Updated",
            },
            history={
                "created_by": "Creator",
                "created_date": "2023-01-01T00:00:00Z",
                "last_updated_by": "Editor",
                "last_updated_date": "2024-01-15T10:00:00Z",
            },
        )
        assert result.version["number"] == 5
        assert result.history["created_by"] == "Creator"
