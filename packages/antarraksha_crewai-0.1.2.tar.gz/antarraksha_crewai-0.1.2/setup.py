from setuptools import setup, find_packages

setup(
    name="antarraksha-crewai",
    version="0.1.2",
    description="Antarraksha AI Agent Enforcement SDK for Crewai",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Akash Kumar Dey",
    author_email="ad@antarraksha.ai",
    url="https://github.com/antarraksha/antarraksha-crewai",
    packages=find_packages(),
    install_requires=["requests>=2.28.0"],
    python_requires=">=3.9",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: Apache Software License",
        "Programming Language :: Python :: 3",
        "Topic :: Security",
    ],
    keywords="ai agent safety security enforcement crewai antarraksha",
)
