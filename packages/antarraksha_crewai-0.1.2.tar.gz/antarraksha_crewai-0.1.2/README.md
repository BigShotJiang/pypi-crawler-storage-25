# antarraksha-crewai

Antarraksha AI Agent Enforcement SDK for Crewai.

## Installation

```bash
pip install antarraksha-crewai
```

## Quick Start

```python
from antarraksha_crewai import AntarakshaClient

client = AntarakshaClient(
    base_url="https://antarraksha.ai",
    agent_id="my-agent",
    passport_id="ANTK-PASS-xxx",
)
client.register()
```
