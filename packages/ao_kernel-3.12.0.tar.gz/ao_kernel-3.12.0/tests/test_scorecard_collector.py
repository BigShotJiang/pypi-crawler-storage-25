"""v3.5 D3: scorecard collector + pytest plugin tests (11 pins)."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from ao_kernel._internal.scorecard.collector import (
    DEFAULT_OUTPUT_FILENAME,
    BenchmarkResult,
    PrimarySidecar,
    ScorecardCollectorError,
    ScorecardRegistry,
    build_result,
    build_scorecard,
    finalize_session,
    resolve_output_path,
)


def _write_events(run_dir: Path, events: list[dict]) -> None:
    run_dir.mkdir(parents=True, exist_ok=True)
    (run_dir / "events.jsonl").write_text(
        "\n".join(json.dumps(event) for event in events) + "\n",
        encoding="utf-8",
    )


def _write_run_state(path: Path, cost_limit: float, remaining: float) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            {
                "budget": {
                    "cost_usd": {"limit": cost_limit, "remaining": remaining},
                },
            }
        ),
        encoding="utf-8",
    )


def _write_review_findings(path: Path, score: float | None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload: dict = {"findings": [], "summary": "ok"}
    if score is not None:
        payload["score"] = score
    path.write_text(json.dumps(payload), encoding="utf-8")


class TestBuildResult:
    def test_happy_path_extraction(self, tmp_path: Path) -> None:
        events = [
            {"kind": "workflow_started", "ts": "2026-04-18T10:00:00+00:00"},
            {"kind": "step_completed", "ts": "2026-04-18T10:00:01+00:00"},
            {"kind": "workflow_completed", "ts": "2026-04-18T10:00:02+00:00"},
        ]
        _write_events(tmp_path / "run", events)
        state = tmp_path / "state.json"
        _write_run_state(state, 10.0, 9.5)
        findings = tmp_path / "review.json"
        _write_review_findings(findings, 0.88)

        sidecar = PrimarySidecar(
            scenario_id="governed_review",
            run_dir=tmp_path / "run",
            run_state_path=state,
            review_findings_path=findings,
        )
        result = build_result(sidecar)
        assert result.scenario == "governed_review"
        assert result.status == "pass"
        assert result.workflow_completed is True
        assert result.duration_ms == 2000
        assert result.cost_consumed_usd == pytest.approx(0.5)
        # v3.7 F2 legacy-drain compatibility: a positive budget drain
        # with no `llm_spend_recorded(source="adapter_path")` event
        # maps to the `mock_shim` label (historical artefact read).
        assert result.cost_source == "mock_shim"
        assert result.review_score == pytest.approx(0.88)

    def test_missing_workflow_completed_is_fail(self, tmp_path: Path) -> None:
        events = [
            {"kind": "workflow_started", "ts": "2026-04-18T10:00:00+00:00"},
        ]
        _write_events(tmp_path / "run", events)
        sidecar = PrimarySidecar(
            scenario_id="governed_bugfix",
            run_dir=tmp_path / "run",
        )
        result = build_result(sidecar)
        assert result.workflow_completed is False
        assert result.status == "fail"

    def test_workflow_failed_event_forces_fail(self, tmp_path: Path) -> None:
        events = [
            {"kind": "workflow_completed", "ts": "2026-04-18T10:00:00+00:00"},
            {"kind": "workflow_failed", "ts": "2026-04-18T10:00:01+00:00"},
        ]
        _write_events(tmp_path / "run", events)
        sidecar = PrimarySidecar(
            scenario_id="governed_bugfix",
            run_dir=tmp_path / "run",
        )
        result = build_result(sidecar)
        assert result.status == "fail"

    def test_missing_budget_gives_null_cost(self, tmp_path: Path) -> None:
        events = [{"kind": "workflow_completed", "ts": "2026-04-18T10:00:00+00:00"}]
        _write_events(tmp_path / "run", events)
        sidecar = PrimarySidecar(
            scenario_id="governed_bugfix",
            run_dir=tmp_path / "run",
            run_state_path=tmp_path / "missing.json",
        )
        result = build_result(sidecar)
        assert result.cost_consumed_usd is None
        assert result.cost_source is None

    def test_missing_review_findings_gives_null_score(self, tmp_path: Path) -> None:
        events = [{"kind": "workflow_completed", "ts": "2026-04-18T10:00:00+00:00"}]
        _write_events(tmp_path / "run", events)
        sidecar = PrimarySidecar(
            scenario_id="governed_review",
            run_dir=tmp_path / "run",
            review_findings_path=tmp_path / "missing.json",
        )
        result = build_result(sidecar)
        assert result.review_score is None

    def test_empty_run_dir(self, tmp_path: Path) -> None:
        (tmp_path / "empty").mkdir()
        sidecar = PrimarySidecar(
            scenario_id="governed_bugfix",
            run_dir=tmp_path / "empty",
        )
        result = build_result(sidecar)
        assert result.workflow_completed is False
        assert result.status == "fail"
        assert result.duration_ms is None


class TestCostSourceDetection:
    """v3.7 F2: collector chooses `cost_source` via events stream first,
    budget drain second, else None."""

    def test_real_adapter_wins_when_llm_spend_recorded_present(
        self,
        tmp_path: Path,
    ) -> None:
        """Event-backed detection: `llm_spend_recorded(source="adapter_path")`
        → `cost_source="real_adapter"` regardless of budget state."""
        run_dir = tmp_path / "run"
        events = [
            {"kind": "workflow_started", "ts": "2026-04-18T10:00:00+00:00"},
            {
                "kind": "llm_spend_recorded",
                "ts": "2026-04-18T10:00:01+00:00",
                "payload": {
                    "source": "adapter_path",
                    "cost_usd": 0.05,
                },
            },
            {"kind": "workflow_completed", "ts": "2026-04-18T10:00:02+00:00"},
        ]
        _write_events(run_dir, events)
        state = tmp_path / "state.json"
        _write_run_state(state, 10.0, 9.95)
        sidecar = PrimarySidecar(
            scenario_id="governed_review",
            run_dir=run_dir,
            run_state_path=state,
        )
        result = build_result(sidecar)
        assert result.cost_source == "real_adapter"
        # cost_consumed_usd still reflects the run-state axis.
        assert result.cost_consumed_usd == pytest.approx(0.05)

    def test_no_event_no_drain_yields_none(self, tmp_path: Path) -> None:
        """v3.7 F2 fast-mode post-shim: no `llm_spend_recorded` + no
        positive drain → `cost_source=None`. Previously the collector
        hardcoded `"mock_shim"` when drain>=0; F2 drops that hardcode."""
        run_dir = tmp_path / "run"
        _write_events(
            run_dir,
            [{"kind": "workflow_completed", "ts": "2026-04-18T10:00:00+00:00"}],
        )
        state = tmp_path / "state.json"
        # Axis seeded but not drained (fast-mode F2 contract).
        _write_run_state(state, 10.0, 10.0)
        sidecar = PrimarySidecar(
            scenario_id="governed_bugfix",
            run_dir=run_dir,
            run_state_path=state,
        )
        result = build_result(sidecar)
        assert result.cost_source is None
        assert result.cost_consumed_usd == pytest.approx(0.0)

    def test_legacy_drain_without_event_maps_to_mock_shim(
        self,
        tmp_path: Path,
    ) -> None:
        """Backward-compat: old artefacts produced by the removed
        `_maybe_consume_budget` shim show positive drain but no
        `llm_spend_recorded` event; collector keeps labelling those
        as `mock_shim`."""
        run_dir = tmp_path / "run"
        _write_events(
            run_dir,
            [{"kind": "workflow_completed", "ts": "2026-04-18T10:00:00+00:00"}],
        )
        state = tmp_path / "state.json"
        _write_run_state(state, 10.0, 9.5)
        sidecar = PrimarySidecar(
            scenario_id="governed_review",
            run_dir=run_dir,
            run_state_path=state,
        )
        result = build_result(sidecar)
        assert result.cost_source == "mock_shim"
        assert result.cost_consumed_usd == pytest.approx(0.5)


class TestBuildScorecard:
    def test_scorecard_sorted_by_scenario(self, tmp_path: Path) -> None:
        results = [
            BenchmarkResult("governed_review", "pass", True, 50, 0.01, "mock_shim", 0.8),
            BenchmarkResult("governed_bugfix", "pass", True, 75, 0.005, "mock_shim", None),
        ]
        scorecard = build_scorecard(results)
        assert scorecard["benchmarks"][0]["scenario"] == "governed_bugfix"
        assert scorecard["benchmarks"][1]["scenario"] == "governed_review"
        assert scorecard["schema_version"] == "v1"
        assert "git_sha" in scorecard
        assert "generated_at" in scorecard

    def test_cost_source_always_populated_when_cost_present(self) -> None:
        """Canonical marker pin #2: cost_source='mock_shim' v1."""
        results = [
            BenchmarkResult("s", "pass", True, 10, 0.01, "mock_shim", None),
        ]
        scorecard = build_scorecard(results)
        assert scorecard["benchmarks"][0]["cost_source"] == "mock_shim"


class TestFinalizeSession:
    def test_happy_path_writes_file(
        self,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        registry = ScorecardRegistry()
        events = [{"kind": "workflow_completed", "ts": "2026-04-18T10:00:00+00:00"}]
        _write_events(tmp_path / "rg", events)
        registry.record(PrimarySidecar("governed_bugfix", tmp_path / "rg"))
        events2 = [{"kind": "workflow_completed", "ts": "2026-04-18T10:00:00+00:00"}]
        _write_events(tmp_path / "rv", events2)
        registry.record(PrimarySidecar("governed_review", tmp_path / "rv"))

        out = tmp_path / "scorecard.json"
        written = finalize_session(registry, out)
        assert written == out
        payload = json.loads(out.read_text())
        assert [entry["scenario"] for entry in payload["benchmarks"]] == [
            "governed_bugfix",
            "governed_review",
        ]

    def test_duplicate_primary_marker_fails_session(self, tmp_path: Path) -> None:
        """Canonical marker pin #1: duplicate → session-fail diagnostic."""
        registry = ScorecardRegistry()
        _write_events(tmp_path / "a", [{"kind": "workflow_completed"}])
        _write_events(tmp_path / "b", [{"kind": "workflow_completed"}])
        registry.record(PrimarySidecar("governed_review", tmp_path / "a"))
        registry.record(PrimarySidecar("governed_review", tmp_path / "b"))
        with pytest.raises(ScorecardCollectorError, match="Duplicate"):
            finalize_session(registry, tmp_path / "out.json")
        assert not (tmp_path / "out.json").exists()

    def test_zero_primary_fails_when_expected_non_empty(
        self,
        tmp_path: Path,
    ) -> None:
        """AGREE iter-2 tighten #3 — missing primary also fail-closed."""
        registry = ScorecardRegistry()
        with pytest.raises(ScorecardCollectorError, match="Missing"):
            finalize_session(
                registry,
                tmp_path / "out.json",
                expected_scenarios=frozenset({"governed_review"}),
            )

    def test_partial_primary_subset_fails(self, tmp_path: Path) -> None:
        """Codex post-impl BLOCKER absorb — if ANY expected scenario
        is missing (not just fully empty), fail-close. Previously we
        only trapped the empty-observed case."""
        registry = ScorecardRegistry()
        _write_events(tmp_path / "r", [{"kind": "workflow_completed"}])
        registry.record(PrimarySidecar("governed_review", tmp_path / "r"))
        with pytest.raises(ScorecardCollectorError, match="governed_bugfix"):
            finalize_session(
                registry,
                tmp_path / "out.json",
                expected_scenarios=frozenset({"governed_bugfix", "governed_review"}),
            )
        assert not (tmp_path / "out.json").exists()

    def test_zero_primary_noop_when_expected_empty(self, tmp_path: Path) -> None:
        """Empty expected-set → no-op, no scorecard produced."""
        registry = ScorecardRegistry()
        result = finalize_session(
            registry,
            tmp_path / "out.json",
            expected_scenarios=frozenset(),
        )
        assert result is None
        assert not (tmp_path / "out.json").exists()


class TestSessionFinishExitStatus:
    """Codex post-impl BLOCKER absorb — canonical-input contract
    violations MUST propagate non-zero pytest exit status. Verified by
    invoking a tiny pytest subprocess with a seeded conftest."""

    def _run_pytest_with_conftest(
        self,
        tmp_path: Path,
        conftest_body: str,
        test_body: str,
    ) -> int:
        import subprocess
        import sys

        (tmp_path / "conftest.py").write_text(
            conftest_body,
            encoding="utf-8",
        )
        (tmp_path / "test_one.py").write_text(
            test_body,
            encoding="utf-8",
        )
        result = subprocess.run(
            [sys.executable, "-m", "pytest", str(tmp_path), "-q"],
            capture_output=True,
            text=True,
            timeout=60,
        )
        return result.returncode

    def test_duplicate_primary_sets_nonzero_exit(self, tmp_path: Path) -> None:
        conftest = """
import pytest

from ao_kernel._internal.scorecard.collector import (
    PrimarySidecar, ScorecardRegistry, finalize_session,
)


_REG = ScorecardRegistry()


def pytest_configure(config):
    config.addinivalue_line(
        "markers", "scorecard_primary: test marker"
    )


def pytest_sessionfinish(session, exitstatus):
    # Simulate duplicate marker: two sidecars for same scenario.
    r = session.config.stash.setdefault("_reg", ScorecardRegistry())
    try:
        finalize_session(r)
    except Exception as exc:
        session.config.get_terminal_writer().line(str(exc), red=True)
        misconfig = int(pytest.ExitCode.USAGE_ERROR)
        if int(session.exitstatus or 0) < misconfig:
            session.exitstatus = pytest.ExitCode(misconfig)


@pytest.fixture(autouse=True)
def _seed(request, tmp_path):
    reg = request.config.stash.setdefault("_reg", ScorecardRegistry())
    (tmp_path / "a").mkdir()
    (tmp_path / "a" / "events.jsonl").write_text('{"kind":"workflow_completed"}\\n')
    (tmp_path / "b").mkdir()
    (tmp_path / "b" / "events.jsonl").write_text('{"kind":"workflow_completed"}\\n')
    reg.record(PrimarySidecar("same", tmp_path / "a"))
    reg.record(PrimarySidecar("same", tmp_path / "b"))
    yield
"""
        test = """
def test_noop():
    assert True
"""
        rc = self._run_pytest_with_conftest(tmp_path, conftest, test)
        assert rc != 0
        # Pytest ExitCode.USAGE_ERROR = 4
        assert rc == 4, f"expected usage-error exit 4, got {rc}"

    def test_env_var_override(
        self,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        target = tmp_path / "custom" / "card.json"
        monkeypatch.setenv("AO_SCORECARD_OUTPUT", str(target))
        assert resolve_output_path() == target

    def test_default_path(
        self,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.delenv("AO_SCORECARD_OUTPUT", raising=False)
        assert resolve_output_path(tmp_path) == tmp_path / DEFAULT_OUTPUT_FILENAME
