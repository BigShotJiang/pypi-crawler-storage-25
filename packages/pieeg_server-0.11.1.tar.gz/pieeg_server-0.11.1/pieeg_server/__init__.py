"""PiEEG-16-server: One-command EEG data streaming server."""

__version__ = "0.11.1"
