from . import main


if __name__ == "__main__":
    main.main(prog="speculos")
