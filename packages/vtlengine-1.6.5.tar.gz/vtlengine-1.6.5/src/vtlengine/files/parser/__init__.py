import csv
import warnings
from csv import DictReader
from pathlib import Path
from typing import Any, Dict, List, Optional, Type, Union

import pandas as pd

from vtlengine.DataTypes import (
    SCALAR_TYPES_CLASS_REVERSE,
    Boolean,
    Date,
    Duration,
    Integer,
    Number,
    ScalarType,
    String,
    TimeInterval,
    TimePeriod,
)
from vtlengine.DataTypes._time_checking import (
    check_date,
    check_time,
    check_time_period,
)
from vtlengine.DataTypes.TimeHandling import PERIOD_IND_MAPPING
from vtlengine.Exceptions import DataLoadError, InputValidationException
from vtlengine.files.parser._rfc_dialect import register_rfc
from vtlengine.files.sdmx_handler import is_sdmx_datapoint_file, load_sdmx_datapoints
from vtlengine.Model import Component, Dataset, Role

TIME_CHECKS_MAPPING: Dict[Type[ScalarType], Any] = {
    Date: check_date,
    TimePeriod: check_time_period,
    TimeInterval: check_time,
}

SEPARATORS = "".join([",", ";", ":", "|", "\t"])


def _detect_delimiter(file_path: Union[str, Path], num_bytes: int = 4096) -> str:
    try:
        if _is_remote_path(file_path):
            import fsspec  # type: ignore[import-untyped]

            reader = fsspec.open
        else:
            reader = open

        with reader(file_path, "r", encoding="utf-8", errors="replace") as f:
            sample = f.read(num_bytes)
        if sample:
            return csv.Sniffer().sniff(sample, delimiters=SEPARATORS).delimiter
    except Exception:
        return ","
    return ","


def _validate_csv_path(components: Dict[str, Component], csv_path: Path) -> None:
    # GE1 check if the file is empty
    if not csv_path.exists():
        raise DataLoadError(code="0-3-1-1", file=csv_path)
    if not csv_path.is_file():
        raise DataLoadError(code="0-3-1-1", file=csv_path)
    register_rfc()
    try:
        delimiter = _detect_delimiter(csv_path)
        with open(csv_path, "r", errors="replace", encoding="utf-8") as f:
            reader = DictReader(f, delimiter=delimiter)
            csv_columns = reader.fieldnames
    except InputValidationException as ie:
        raise InputValidationException("{}".format(str(ie))) from None
    except Exception as e:
        raise InputValidationException(
            f"ERROR: {str(e)}, review file {str(csv_path.as_posix())}"
        ) from None

    if not csv_columns:
        raise InputValidationException(code="0-1-1-6", file=csv_path)

    if len(list(set(csv_columns))) != len(csv_columns):
        duplicates = list(set([item for item in csv_columns if csv_columns.count(item) > 1]))
        raise InputValidationException(
            code="0-1-2-3", element_type="Columns", element=f"{', '.join(duplicates)}"
        )

    comp_names = set([c.name for c in components.values() if c.role == Role.IDENTIFIER])
    comps_missing: Union[str, List[str]] = (
        [id_m for id_m in comp_names if id_m not in reader.fieldnames] if reader.fieldnames else []
    )
    if comps_missing:
        comps_missing = ", ".join(comps_missing)
        raise InputValidationException(code="0-1-1-8", ids=comps_missing, file=str(csv_path.name))


def _sanitize_pandas_columns(
    components: Dict[str, Component], csv_path: Union[str, Path], data: pd.DataFrame
) -> pd.DataFrame:
    # Fast loading from SDMX-CSV
    if (
        "DATAFLOW" in data.columns
        and data.columns[0] == "DATAFLOW"
        and "DATAFLOW" not in components
    ):
        data.drop(columns=["DATAFLOW"], inplace=True)
    if "STRUCTURE" in data.columns and data.columns[0] == "STRUCTURE":
        if "STRUCTURE" not in components:
            data.drop(columns=["STRUCTURE"], inplace=True)
        if "STRUCTURE_ID" in data.columns:
            data.drop(columns=["STRUCTURE_ID"], inplace=True)
        if "ACTION" in data.columns:
            data = data[data["ACTION"] != "D"]
            data.drop(columns=["ACTION"], inplace=True)

    # Validate identifiers
    comp_names = set([c.name for c in components.values() if c.role == Role.IDENTIFIER])
    comps_missing: Union[str, List[str]] = [id_m for id_m in comp_names if id_m not in data.columns]
    if comps_missing:
        comps_missing = ", ".join(comps_missing)
        file = csv_path if isinstance(csv_path, str) else csv_path.name
        raise InputValidationException(code="0-1-1-7", ids=comps_missing, file=file)

    # Fill rest of components with null values
    for comp_name, comp in components.items():
        if comp_name not in data:
            if not comp.nullable:
                raise InputValidationException(f"Component {comp_name} is missing in the file.")
            data[comp_name] = None
    return data


def _is_remote_path(csv_path: Union[str, Path]) -> bool:
    return isinstance(csv_path, str) and "://" in csv_path


def _pandas_load_csv(components: Dict[str, Component], csv_path: Union[str, Path]) -> pd.DataFrame:
    obj_dtypes = dict.fromkeys(components, "string[pyarrow]")

    na_values: Union[Dict[str, List[str]], List[str]]
    if components:
        na_values = {
            comp_name: ["", '""'] if comp.data_type != String else [""]
            for comp_name, comp in components.items()
        }
    else:
        na_values = {}

    sep = _detect_delimiter(csv_path)

    data = pd.read_csv(  # type: ignore[call-overload, unused-ignore]
        csv_path,
        dtype=obj_dtypes,
        engine="c",
        sep=sep,
        keep_default_na=False,
        na_values=na_values,
        encoding_errors="replace",
    )

    return _sanitize_pandas_columns(components, csv_path, data)


def _parse_boolean(value: str) -> bool:
    if isinstance(value, bool):
        return value
    result = value.lower() == "true" or value == "1"
    return result


def _check_extra_columns(
    components: Dict[str, Component], data: pd.DataFrame, dataset_name: str
) -> None:
    extra_columns = sorted(set(data.columns) - set(components))
    if extra_columns:
        raise DataLoadError("0-3-1-15", name=dataset_name, extra_columns=", ".join(extra_columns))


def _validate_pandas(
    components: Dict[str, Component], data: pd.DataFrame, dataset_name: str
) -> pd.DataFrame:
    warnings.filterwarnings("ignore", category=FutureWarning)
    # Identifier checking

    id_names = [comp_name for comp_name, comp in components.items() if comp.role == Role.IDENTIFIER]

    missing_columns = [name for name in components if name not in data.columns.tolist()]
    if missing_columns:
        for name in missing_columns:
            if components[name].nullable is False:
                raise DataLoadError("0-3-1-5", name=dataset_name, comp_name=name)
            data[name] = None

    _check_extra_columns(components, data, dataset_name)

    for id_name in id_names:
        if data[id_name].isnull().any():
            raise DataLoadError("0-3-1-3", null_identifier=id_name, name=dataset_name)

    if len(id_names) == 0 and len(data) > 1:
        raise DataLoadError("0-3-1-4", name=dataset_name)

    # Treat empty strings as null for non-String columns
    for comp_name, comp in components.items():
        if comp.data_type != String and comp_name in data.columns:
            data[comp_name] = data[comp_name].replace("", pd.NA)

    data = data.fillna(value=pd.NA)
    # Checking data types on all data types
    comp_name = ""
    try:
        for comp_name, comp in components.items():
            if comp.data_type in (Date, TimePeriod, TimeInterval):
                data[comp_name] = data[comp_name].map(
                    TIME_CHECKS_MAPPING[comp.data_type], na_action="ignore"
                )
            elif comp.data_type == Integer:
                data[comp_name] = data[comp_name].map(
                    lambda x: Integer.cast(float(str(x))), na_action="ignore"
                )
            elif comp.data_type == Number:
                data[comp_name] = data[comp_name].map(lambda x: float((str(x))), na_action="ignore")
            elif comp.data_type == Boolean:
                data[comp_name] = data[comp_name].map(
                    lambda x: _parse_boolean(str(x)), na_action="ignore"
                )
            elif comp.data_type == Duration:
                values_correct = (
                    data[comp_name]
                    .map(
                        lambda x: Duration.validate_duration(x),
                        na_action="ignore",
                    )
                    .all()
                )
                if not values_correct:
                    try:
                        values_correct = (
                            data[comp_name]
                            .map(
                                lambda x: x.replace(" ", "") in PERIOD_IND_MAPPING,  # type: ignore[union-attr, unused-ignore]
                                na_action="ignore",
                            )
                            .all()
                        )
                        if not values_correct:
                            raise ValueError(
                                f"Duration values are not correct in column {comp_name}"
                            )
                    except ValueError:
                        raise ValueError(f"Duration values are not correct in column {comp_name}")
            else:
                data[comp_name] = data[comp_name].map(
                    lambda x: str(x).replace('"', ""), na_action="ignore"
                )
            data[comp_name] = data[comp_name].astype(comp.data_type.dtype())  # type: ignore[call-overload]

    except (ValueError, InputValidationException) as e:
        str_comp = SCALAR_TYPES_CLASS_REVERSE.get(comp.data_type, "Null")
        error = e.args[0] if isinstance(e, InputValidationException) else str(e)
        raise DataLoadError(
            "0-3-1-6", name=dataset_name, column=comp_name, type=str_comp, error=error
        ) from None

    if id_names:
        check_identifiers_duplicity(data, id_names, dataset_name)

    return data


def check_identifiers_duplicity(data: pd.DataFrame, identifiers: List[str], name: str) -> None:
    dup_id_row = data.duplicated(subset=identifiers, keep=False)
    if dup_id_row.any():
        row_index = int(dup_id_row.idxmax()) + 1
        raise DataLoadError("0-3-1-7", name=name, row_index=row_index)


def load_datapoints(
    components: Dict[str, Component],
    dataset_name: str,
    csv_path: Optional[Union[Path, str]] = None,
) -> pd.DataFrame:
    """
    Load datapoints from a file into a pandas DataFrame.

    Supports multiple file formats:
    - Plain CSV: Standard comma-separated values
    - SDMX-CSV: CSV with SDMX structure columns (DATAFLOW, STRUCTURE, etc.)
    - SDMX-ML: XML files in SDMX format (.xml extension)

    Args:
        components: Expected components for validation.
        dataset_name: Name of the dataset for error messages.
        csv_path: Path to the data file (CSV or SDMX-ML).

    Returns:
        Validated pandas DataFrame with the loaded data.

    Raises:
        DataLoadError: If file cannot be read or parsed.
        InputValidationException: If csv_path is invalid type.
    """
    if csv_path is None or (isinstance(csv_path, Path) and not csv_path.exists()):
        return pd.DataFrame(columns=list(components.keys()))
    elif isinstance(csv_path, (str, Path)):
        # Convert string to Path for extension checking
        file_path = Path(csv_path) if isinstance(csv_path, str) else csv_path

        # Check if SDMX file by extension
        if is_sdmx_datapoint_file(file_path):
            data = load_sdmx_datapoints(components, dataset_name, file_path)
        else:
            # CSV file (plain or SDMX-CSV)
            if isinstance(csv_path, Path):
                _validate_csv_path(components, csv_path)
            data = _pandas_load_csv(components, csv_path)
    else:
        raise InputValidationException(code="0-1-1-2", input=csv_path)
    data = _validate_pandas(components, data, dataset_name)

    return data


def _fill_dataset_empty_data(dataset: Dataset) -> None:
    dataset.data = pd.DataFrame(columns=list(dataset.components.keys()))
