"""Tests for claude_usage.

These are integration tests that require:
- Linux environment
- Claude Code installed and on PATH (or in VS Code extensions)
- ~/.claude authenticated with a valid account

Run: pytest tests/ -v
"""

import json
import os
import shutil
import tempfile
from pathlib import Path

import pexpect
import pytest

from claude_usage import Usage, _find_claude, _parse_screen, get_usage, get_usage_multi


# ---------------------------------------------------------------------------
# Unit tests: _parse_screen
# ---------------------------------------------------------------------------


class TestParseScreen:
    """Test the screen parser against realistic /usage output."""

    CLEAN_SCREEN = """
  /usage
────────────────────────────────────────
  Current session
  █████████████████████████████     58% used
  Resets 11pm (UTC)

  Current week (all models)
  ████████████████▌                 33% used
  Resets Apr 7, 3pm (UTC)

  Current week (Sonnet only)
  ██████                            12% used
  Resets Apr 7, 5pm (UTC)

  Extra usage
  Extra usage not enabled
"""

    CORRUPTED_SCREEN = """
❯ /usage
  /usage                  Show plan usage limits
   StttususaConfig   Usage    i                 to keep working when limits are hit
                                         n     t  t    g       c    e
  Current session                  t       f       l     e
  █████████████████████████████▌    C         e     e59% usedics and activity
  Rese s 11pm (UTC)
  Current week (all models)
  ████████████████▌                                  33% used
  Resets Apr 7, 3pm (UTC)
  Current week (Sonnet only)
  ██████                                             12% used
  Resets Apr 7, 5pm (UTC)
  Extra usage
  Extra usage not enabled · /extra-usage to enable
  Esc to cancel
"""

    def test_parse_clean_screen(self):
        usage = _parse_screen(self.CLEAN_SCREEN)
        assert usage.five_hour_pct == 58.0
        assert usage.seven_day_pct == 33.0
        assert usage.sonnet_week_pct == 12.0

    def test_parse_clean_screen_resets(self):
        usage = _parse_screen(self.CLEAN_SCREEN)
        assert usage.five_hour_resets is not None
        assert "11pm" in usage.five_hour_resets
        assert usage.seven_day_resets is not None
        assert "Apr 7" in usage.seven_day_resets

    def test_parse_corrupted_screen(self):
        usage = _parse_screen(self.CORRUPTED_SCREEN)
        assert usage.five_hour_pct == 59.0
        assert usage.seven_day_pct == 33.0
        assert usage.sonnet_week_pct == 12.0

    def test_parse_empty_screen(self):
        usage = _parse_screen("")
        assert usage.five_hour_pct is None
        assert usage.seven_day_pct is None
        assert usage.sonnet_week_pct is None

    def test_parse_no_usage_data(self):
        usage = _parse_screen("Some random text\nwith no percentages")
        assert usage.five_hour_pct is None

    def test_parse_single_percentage(self):
        screen = """
  Current session
  ██████████                        25% used
  Resets 3am (UTC)
"""
        usage = _parse_screen(screen)
        assert usage.five_hour_pct == 25.0
        assert usage.seven_day_pct is None

    def test_parse_zero_percent(self):
        screen = """
  Current session
                                    0% used
  Resets 5pm (UTC)

  Current week (all models)
                                    0% used
  Resets Apr 10, 3pm (UTC)
"""
        usage = _parse_screen(screen)
        assert usage.five_hour_pct == 0.0
        assert usage.seven_day_pct == 0.0

    def test_parse_100_percent(self):
        screen = """
  Current session
  ██████████████████████████████  100% used
  Resets 2am (UTC)
"""
        usage = _parse_screen(screen)
        assert usage.five_hour_pct == 100.0

    def test_parse_stores_raw_output(self):
        """_parse_screen should store the original text in raw_output."""
        usage = _parse_screen(self.CLEAN_SCREEN)
        assert usage.raw_output is not None
        assert "58% used" in usage.raw_output

    def test_parse_empty_stores_raw_output(self):
        """Even empty input should be stored in raw_output."""
        usage = _parse_screen("")
        assert usage.raw_output == ""

    def test_parse_no_match_stores_raw_output(self):
        """Non-matching text should still be preserved in raw_output."""
        text = "Some random text\nwith no percentages"
        usage = _parse_screen(text)
        assert usage.raw_output == text


# ---------------------------------------------------------------------------
# Unit tests: Usage dataclass
# ---------------------------------------------------------------------------


class TestUsage:
    def test_to_dict(self):
        usage = Usage(five_hour_pct=50.0, seven_day_pct=30.0)
        d = usage.to_dict()
        assert d["five_hour_pct"] == 50.0
        assert d["seven_day_pct"] == 30.0
        assert d["sonnet_week_pct"] is None

    def test_to_dict_json_serializable(self):
        usage = Usage(five_hour_pct=50.0, five_hour_resets="11pm (UTC)")
        j = json.dumps(usage.to_dict())
        assert "50.0" in j

    def test_defaults_are_none(self):
        usage = Usage()
        d = usage.to_dict()
        assert d["five_hour_pct"] is None
        assert d["seven_day_pct"] is None
        assert d["sonnet_week_pct"] is None
        assert d["error"] is None

    def test_to_dict_excludes_raw_by_default(self):
        usage = Usage(five_hour_pct=50.0, raw_output="some raw text")
        d = usage.to_dict()
        assert "raw_output" not in d

    def test_to_dict_includes_raw_when_requested(self):
        usage = Usage(five_hour_pct=50.0, raw_output="some raw text")
        d = usage.to_dict(include_raw=True)
        assert d["raw_output"] == "some raw text"

    def test_error_field_default_none(self):
        usage = Usage()
        assert usage.error is None

    def test_error_field_stored(self):
        usage = Usage(error="TimeoutError: timed out")
        assert usage.error == "TimeoutError: timed out"


# ---------------------------------------------------------------------------
# Unit tests: _find_claude
# ---------------------------------------------------------------------------


class TestFindClaude:
    def test_find_claude_succeeds(self):
        path = _find_claude()
        assert path is not None
        assert os.path.exists(path) or shutil.which(path)

    def test_find_claude_returns_string(self):
        assert isinstance(_find_claude(), str)

    def test_claude_bin_env_var(self, tmp_path, monkeypatch):
        """CLAUDE_BIN env var should be used when set to a valid executable."""
        fake_bin = tmp_path / "my-claude"
        fake_bin.write_text("#!/bin/sh\n")
        fake_bin.chmod(0o755)
        monkeypatch.setenv("CLAUDE_BIN", str(fake_bin))
        assert _find_claude() == str(fake_bin)

    def test_claude_bin_env_var_missing_file(self, monkeypatch):
        """CLAUDE_BIN pointing to a non-existent file should raise."""
        monkeypatch.setenv("CLAUDE_BIN", "/nonexistent/claude")
        with pytest.raises(FileNotFoundError, match="CLAUDE_BIN"):
            _find_claude()

    def test_claude_bin_env_var_not_executable(self, tmp_path, monkeypatch):
        """CLAUDE_BIN pointing to a non-executable file should raise."""
        not_exec = tmp_path / "not-executable"
        not_exec.write_text("data")
        not_exec.chmod(0o644)
        monkeypatch.setenv("CLAUDE_BIN", str(not_exec))
        with pytest.raises(FileNotFoundError, match="CLAUDE_BIN"):
            _find_claude()


# ---------------------------------------------------------------------------
# Integration tests: get_usage (live, requires authenticated .claude)
# ---------------------------------------------------------------------------


@pytest.mark.integration
class TestGetUsageLive:
    """Live integration tests. These spawn a real claude process."""

    def test_default_usage_returns_data(self):
        usage = get_usage()
        assert isinstance(usage, Usage)
        # At least one percentage should be non-None
        assert usage.five_hour_pct is not None or usage.seven_day_pct is not None

    def test_default_usage_percentages_in_range(self):
        usage = get_usage()
        if usage.five_hour_pct is not None:
            assert 0 <= usage.five_hour_pct <= 100
        if usage.seven_day_pct is not None:
            assert 0 <= usage.seven_day_pct <= 100
        if usage.sonnet_week_pct is not None:
            assert 0 <= usage.sonnet_week_pct <= 100

    def test_default_usage_to_dict(self):
        usage = get_usage()
        d = usage.to_dict()
        assert isinstance(d, dict)
        assert "five_hour_pct" in d
        assert "seven_day_pct" in d

    def test_config_dir_swap(self, tmp_path):
        """Copy ~/.claude to a temp dir and verify get_usage works with it."""
        real_claude_dir = Path.home() / ".claude"
        if not real_claude_dir.exists():
            pytest.skip("~/.claude does not exist")

        # Copy credentials to temp
        temp_claude = tmp_path / ".claude"
        shutil.copytree(real_claude_dir, temp_claude)

        usage = get_usage(claude_dir=str(temp_claude))
        assert isinstance(usage, Usage)
        assert usage.five_hour_pct is not None or usage.seven_day_pct is not None

    def test_config_dir_swap_matches_default(self, tmp_path):
        """Usage from copied config should return the same account's data."""
        real_claude_dir = Path.home() / ".claude"
        if not real_claude_dir.exists():
            pytest.skip("~/.claude does not exist")

        temp_claude = tmp_path / ".claude"
        shutil.copytree(real_claude_dir, temp_claude)

        usage_default = get_usage()
        usage_copied = get_usage(claude_dir=str(temp_claude))

        # Same account, so 7-day should be identical (5hr may drift slightly)
        if usage_default.seven_day_pct is not None and usage_copied.seven_day_pct is not None:
            assert abs(usage_default.seven_day_pct - usage_copied.seven_day_pct) <= 2

    def test_no_creds_config_dir_proves_isolation(self, tmp_path):
        """Config dir with no creds must NOT return real usage data.

        This proves CLAUDE_CONFIG_DIR is actually being read. If the tool
        ignored it and fell back to ~/.claude, we'd get real percentages.
        Instead we should get a timeout (login prompt) or empty usage.
        """
        no_creds_dir = tmp_path / ".claude-no-creds"
        no_creds_dir.mkdir()
        (no_creds_dir / "settings.json").write_text("{}")

        try:
            usage = get_usage(claude_dir=str(no_creds_dir), timeout=30)
            # If it somehow returns, it must NOT have real data
            assert usage.five_hour_pct is None, (
                f"Got five_hour_pct={usage.five_hour_pct} from a dir with no creds — "
                "CLAUDE_CONFIG_DIR is being ignored"
            )
            assert usage.seven_day_pct is None, (
                f"Got seven_day_pct={usage.seven_day_pct} from a dir with no creds — "
                "CLAUDE_CONFIG_DIR is being ignored"
            )
        except TimeoutError:
            pass  # Expected — claude prompts for login, we timeout

    def test_config_dir_isolates_account(self, tmp_path):
        """Verify CLAUDE_CONFIG_DIR actually changes which account is used.

        Copies real creds to a temp dir, runs get_usage on it. If we get data,
        it proves the config dir was respected (not falling back to ~/.claude).
        """
        real_claude_dir = Path.home() / ".claude"
        creds_file = real_claude_dir / ".credentials.json"
        if not creds_file.exists():
            pytest.skip("~/.claude/.credentials.json does not exist")

        # Create a minimal config dir with just the credentials
        isolated_dir = tmp_path / ".claude-isolated"
        isolated_dir.mkdir()
        shutil.copy2(creds_file, isolated_dir / ".credentials.json")

        usage = get_usage(claude_dir=str(isolated_dir))
        assert isinstance(usage, Usage)
        # Should get real data because we copied valid credentials
        assert usage.five_hour_pct is not None or usage.seven_day_pct is not None


# ---------------------------------------------------------------------------
# Unit tests: get_usage_multi
# ---------------------------------------------------------------------------


class TestGetUsageClaudeBin:
    """Tests for the claude_bin parameter on get_usage / get_usage_multi."""

    def test_get_usage_skips_find_when_claude_bin_given(self, monkeypatch):
        """When claude_bin is passed, _find_claude should not be called."""
        find_called = {"called": False}
        orig_find = _find_claude

        def spy_find():
            find_called["called"] = True
            return orig_find()

        monkeypatch.setattr("claude_usage._find_claude", spy_find)

        # Mock pexpect.spawn so we don't actually launch a process
        import claude_usage

        class FakeChild:
            def read_nonblocking(self, size=4096, timeout=1):
                raise pexpect.TIMEOUT("")

            def send(self, s):
                pass

            def sendline(self, s):
                pass

            def close(self, force=False):
                pass

        monkeypatch.setattr(pexpect, "spawn", lambda *a, **kw: FakeChild())

        # We expect a TimeoutError because FakeChild never produces output,
        # but _find_claude should NOT have been called.
        try:
            get_usage(claude_bin="/usr/bin/fake-claude", timeout=2)
        except (TimeoutError, Exception):
            pass

        assert not find_called["called"], "_find_claude was called despite claude_bin being provided"

    def test_get_usage_multi_passes_claude_bin(self, monkeypatch):
        """claude_bin should be forwarded to each get_usage call."""
        captured_bins = []

        def capture_get_usage(claude_dir=None, claude_bin=None, timeout=60):
            captured_bins.append(claude_bin)
            return Usage(five_hour_pct=10.0)

        monkeypatch.setattr("claude_usage.get_usage", capture_get_usage)

        get_usage_multi(["/a", "/b"], claude_bin="/custom/claude")
        assert all(b == "/custom/claude" for b in captured_bins)

    def test_get_usage_multi_none_claude_bin_by_default(self, monkeypatch):
        """Without claude_bin, get_usage should receive None."""
        captured_bins = []

        def capture_get_usage(claude_dir=None, claude_bin=None, timeout=60):
            captured_bins.append(claude_bin)
            return Usage(five_hour_pct=10.0)

        monkeypatch.setattr("claude_usage.get_usage", capture_get_usage)

        get_usage_multi(["/a"])
        assert captured_bins == [None]


class TestGetUsageMulti:
    """Unit tests for get_usage_multi using mocked get_usage."""

    def test_returns_dict_keyed_by_dir(self, monkeypatch):
        fake_usage = Usage(five_hour_pct=42.0, seven_day_pct=10.0)
        monkeypatch.setattr("claude_usage.get_usage", lambda claude_dir=None, claude_bin=None, timeout=60: fake_usage)

        results = get_usage_multi(["/dir/a", "/dir/b"])
        assert isinstance(results, dict)
        assert set(results.keys()) == {"/dir/a", "/dir/b"}
        for usage in results.values():
            assert usage.five_hour_pct == 42.0

    def test_individual_failure_returns_none(self, monkeypatch):
        call_count = {"n": 0}

        def flaky_get_usage(claude_dir=None, claude_bin=None, timeout=60):
            call_count["n"] += 1
            if call_count["n"] % 2 == 0:
                raise TimeoutError("timed out")
            return Usage(five_hour_pct=50.0)

        monkeypatch.setattr("claude_usage.get_usage", flaky_get_usage)

        results = get_usage_multi(["/dir/a", "/dir/b", "/dir/c"])
        assert len(results) == 3
        none_count = sum(1 for v in results.values() if v is None)
        data_count = sum(1 for v in results.values() if v is not None)
        # At least one should succeed and at least one should fail
        assert none_count >= 1
        assert data_count >= 1

    def test_empty_list_returns_empty_dict(self):
        results = get_usage_multi([])
        assert results == {}

    def test_single_dir_works(self, monkeypatch):
        fake_usage = Usage(five_hour_pct=75.0)
        monkeypatch.setattr("claude_usage.get_usage", lambda claude_dir=None, claude_bin=None, timeout=60: fake_usage)

        results = get_usage_multi(["/only/one"])
        assert len(results) == 1
        assert results["/only/one"].five_hour_pct == 75.0

    def test_max_workers_respected(self, monkeypatch):
        fake_usage = Usage(five_hour_pct=10.0)
        monkeypatch.setattr("claude_usage.get_usage", lambda claude_dir=None, claude_bin=None, timeout=60: fake_usage)

        # Should not raise even with max_workers=1
        results = get_usage_multi(["/a", "/b", "/c"], max_workers=1)
        assert len(results) == 3

    def test_all_failures_returns_all_none(self, monkeypatch):
        def always_fail(claude_dir=None, claude_bin=None, timeout=60):
            raise Exception("boom")

        monkeypatch.setattr("claude_usage.get_usage", always_fail)

        results = get_usage_multi(["/a", "/b"])
        assert all(v is None for v in results.values())

    def test_failure_logs_warning(self, monkeypatch, caplog):
        """Failed probes should log a warning with the exception details."""
        import logging

        def always_fail(claude_dir=None, claude_bin=None, timeout=60):
            raise TimeoutError("timed out waiting for claude prompt")

        monkeypatch.setattr("claude_usage.get_usage", always_fail)

        with caplog.at_level(logging.WARNING, logger="claude_usage"):
            results = get_usage_multi(["/a"])

        assert results["/a"] is None
        assert any("TimeoutError" in r.message for r in caplog.records)
        assert any("/a" in r.message for r in caplog.records)

    def test_timeout_passed_through(self, monkeypatch):
        captured = {}

        def capture_timeout(claude_dir=None, claude_bin=None, timeout=60):
            captured[claude_dir] = timeout
            return Usage(five_hour_pct=1.0)

        monkeypatch.setattr("claude_usage.get_usage", capture_timeout)

        get_usage_multi(["/x", "/y"], timeout=30)
        assert all(t == 30 for t in captured.values())


# ---------------------------------------------------------------------------
# Integration tests: get_usage_multi (live)
# ---------------------------------------------------------------------------


@pytest.mark.integration
class TestGetUsageMultiLive:
    """Live integration tests for parallel usage checking."""

    def test_multi_same_account(self, tmp_path):
        """Probe the same account twice in parallel — results should agree."""
        real_claude_dir = Path.home() / ".claude"
        if not real_claude_dir.exists():
            pytest.skip("~/.claude does not exist")

        copy_a = tmp_path / "acct-a"
        copy_b = tmp_path / "acct-b"
        shutil.copytree(real_claude_dir, copy_a)
        shutil.copytree(real_claude_dir, copy_b)

        results = get_usage_multi([str(copy_a), str(copy_b)])
        assert len(results) == 2

        usages = [u for u in results.values() if u is not None]
        assert len(usages) == 2

        # Same account → 7-day should match within tolerance
        if usages[0].seven_day_pct is not None and usages[1].seven_day_pct is not None:
            assert abs(usages[0].seven_day_pct - usages[1].seven_day_pct) <= 2

    def test_multi_with_bad_dir(self, tmp_path):
        """One valid dir + one empty dir: valid should succeed, empty should be None."""
        real_claude_dir = Path.home() / ".claude"
        if not real_claude_dir.exists():
            pytest.skip("~/.claude does not exist")

        good = tmp_path / "good"
        shutil.copytree(real_claude_dir, good)

        bad = tmp_path / "bad"
        bad.mkdir()

        results = get_usage_multi([str(good), str(bad)], timeout=30)
        assert results[str(good)] is not None
        assert results[str(bad)] is None


# ---------------------------------------------------------------------------
# Unit tests: logging behavior
# ---------------------------------------------------------------------------


class TestLogging:
    """Test that appropriate log messages are emitted."""

    def test_parse_screen_warns_on_no_data(self, caplog):
        import logging

        with caplog.at_level(logging.WARNING, logger="claude_usage"):
            _parse_screen("no usage data here")
        assert any("No usage data parsed" in r.message for r in caplog.records)

    def test_parse_screen_no_warning_on_valid_data(self, caplog):
        import logging

        screen = """
  Current session
  ██████████                        25% used
  Resets 3am (UTC)
"""
        with caplog.at_level(logging.WARNING, logger="claude_usage"):
            _parse_screen(screen)
        assert not any("No usage data parsed" in r.message for r in caplog.records)


# ---------------------------------------------------------------------------
# Markers
# ---------------------------------------------------------------------------


def pytest_configure(config):
    config.addinivalue_line("markers", "integration: live tests requiring authenticated claude")
