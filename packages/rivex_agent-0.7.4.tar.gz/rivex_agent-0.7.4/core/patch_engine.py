"""Moteur de patching (Phase 2) pour l'agent Rivex.

Le serveur analyse les vulnerabilites detectees sur une machine et produit un
document JSON decrivant les correctifs a appliquer (mise a jour d'un paquet,
fermeture d'un port expose, desactivation d'un service risque, etc.).

Ce module:

- Charge un document de patch depuis un chemin local OU depuis une URL
  (http/https). La recuperation HTTP n'utilise que la stdlib.
- Applique chaque correctif via un handler dedie en fonction de l'OS de la
  machine (Linux: apt/dnf/yum, ufw/iptables, systemctl; Windows: winget/choco,
  netsh advfirewall, sc).
- Retourne un rapport structure (applied / failed / skipped) permettant au
  serveur de tracer ce qui a reellement ete execute.

Important (cf. AGENT_PLAN.md, section 3): le patch applique par cette
fonction ne touche jamais le fichier de configuration de l'agent. Il ne
concerne que les correctifs contre les vulnerabilites remontees par
l'analyse serveur. La mutation de `config.json` reste du ressort de la
synchronisation template / runtime et de `--update`.
"""

from __future__ import annotations

import json
import platform
import shutil
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


HTTP_USER_AGENT = "Rivex-Agent"


# ---------------------------------------------------------------------------
# Chargement du document de patch
# ---------------------------------------------------------------------------

def _load_patch_from_url(url: str, timeout: int = 15) -> Dict[str, Any]:
	request = Request(url, headers={"User-Agent": HTTP_USER_AGENT, "Accept": "application/json"})
	try:
		with urlopen(request, timeout=timeout) as response:
			raw = response.read().decode("utf-8", errors="replace").strip()
	except HTTPError as exc:
		raise ValueError(f"HTTP {exc.code} while fetching patch: {exc}") from exc
	except URLError as exc:
		raise ValueError(f"Network error while fetching patch: {exc}") from exc

	if not raw:
		raise ValueError("Empty patch payload returned by URL")
	try:
		data = json.loads(raw)
	except json.JSONDecodeError as exc:
		raise ValueError(f"Patch URL did not return valid JSON: {exc}") from exc
	if not isinstance(data, dict):
		raise ValueError("Patch payload must be a JSON object")
	return data


def _load_patch_from_file(path: Path) -> Dict[str, Any]:
	if not path.exists():
		raise FileNotFoundError(f"Patch file not found: {path}")
	try:
		raw = path.read_text(encoding="utf-8")
	except OSError as exc:
		raise ValueError(f"Unable to read patch file {path}: {exc}") from exc
	try:
		data = json.loads(raw)
	except json.JSONDecodeError as exc:
		raise ValueError(f"Patch file is not valid JSON: {exc}") from exc
	if not isinstance(data, dict):
		raise ValueError("Patch file must contain a JSON object")
	return data


def load_patch_document(source: str, timeout: int = 15) -> Dict[str, Any]:
	"""Charge un document de patch depuis un chemin local ou une URL.

	- `source` peut etre une URL http:// ou https://, sinon un chemin local
	  (absolu ou relatif au cwd).
	- Renvoie un dict. Leve `ValueError` / `FileNotFoundError` sur erreur.
	"""
	value = str(source or "").strip()
	if not value:
		raise ValueError("Patch source is required (file path or http/https URL)")

	lower = value.lower()
	if lower.startswith("http://") or lower.startswith("https://"):
		return _load_patch_from_url(value, timeout=timeout)

	path = Path(value)
	if not path.is_absolute():
		path = Path.cwd() / path
	return _load_patch_from_file(path)


def looks_like_vulnerability_patch(document: Dict[str, Any]) -> bool:
	"""Detecte si le document suit le nouveau format `vulnerabilites`.

	Permet de preserver la compatibilite descendante avec l ancien comportement
	de merge dans config.json (utilise notamment par la suite de tests CLI).
	"""
	if not isinstance(document, dict):
		return False
	for key in ("vulnerabilities", "patches", "fixes", "remediations"):
		value = document.get(key)
		if isinstance(value, list):
			return True
	return False


# ---------------------------------------------------------------------------
# Execution des actions de remediation
# ---------------------------------------------------------------------------

def _run(command: List[str], timeout: int = 120) -> subprocess.CompletedProcess[str]:
	return subprocess.run(
		command,
		capture_output=True,
		text=True,
		encoding="utf-8",
		errors="replace",
		timeout=timeout,
		check=False,
	)


def _command_result(
	command: List[str],
	process: subprocess.CompletedProcess[str],
) -> Dict[str, Any]:
	stdout_tail = [line for line in (process.stdout or "").splitlines()[-10:]]
	stderr_tail = [line for line in (process.stderr or "").splitlines()[-10:]]
	return {
		"command": command,
		"exit_code": process.returncode,
		"stdout_tail": stdout_tail,
		"stderr_tail": stderr_tail,
	}


# --- update_package ---------------------------------------------------------

def _update_package_linux(name: str, version: Optional[str]) -> Dict[str, Any]:
	# Ordre de resolution strict: apt-get -> yum -> pacman -> dnf.
	# Aligne sur core/system_deps.LINUX_PACKAGE_MANAGERS_ORDER.
	if shutil.which("apt-get"):
		spec = f"{name}={version}" if version else name
		cmd = ["apt-get", "install", "-y", "--only-upgrade", spec]
		process = _run(cmd, timeout=600)
		return {"manager": "apt-get", **_command_result(cmd, process)}

	if shutil.which("yum"):
		spec = f"{name}-{version}" if version else name
		cmd = ["yum", "update", "-y", spec]
		process = _run(cmd, timeout=600)
		return {"manager": "yum", **_command_result(cmd, process)}

	if shutil.which("pacman"):
		# Pacman n a pas de notion explicite de "seulement upgrade": on utilise
		# -Sy --noconfirm --needed qui installe ou met a jour au besoin. La
		# version specifique ne peut pas etre pinnee simplement via pacman
		# (les anciennes versions ne sont pas conservees dans les repos
		# officiels); on ignore donc le parametre version pour pacman et on
		# signale l information dans le resultat.
		cmd = ["pacman", "-S", "-y", "--noconfirm", "--needed", name]
		process = _run(cmd, timeout=600)
		result = {"manager": "pacman", **_command_result(cmd, process)}
		if version:
			result["version_note"] = (
				"pacman does not support pinning to a specific version via "
				"official repositories; installed latest available instead"
			)
		return result

	if shutil.which("dnf"):
		spec = f"{name}-{version}" if version else name
		cmd = ["dnf", "upgrade", "-y", spec]
		process = _run(cmd, timeout=600)
		return {"manager": "dnf", **_command_result(cmd, process)}

	return {
		"manager": None,
		"exit_code": -1,
		"error": (
			"package-manager non pris en charge "
			"(attendus dans l ordre: apt-get, yum, pacman, dnf)"
		),
	}


def _update_package_windows(name: str, version: Optional[str]) -> Dict[str, Any]:
	if shutil.which("winget"):
		cmd = [
			"winget", "upgrade", "--id", name,
			"--silent", "--accept-source-agreements", "--accept-package-agreements",
		]
		if version:
			cmd.extend(["--version", version])
		process = _run(cmd, timeout=900)
		return {"manager": "winget", **_command_result(cmd, process)}

	if shutil.which("choco"):
		cmd = ["choco", "upgrade", name, "-y"]
		if version:
			cmd.extend(["--version", version])
		process = _run(cmd, timeout=900)
		return {"manager": "choco", **_command_result(cmd, process)}

	return {
		"manager": None,
		"exit_code": -1,
		"error": "no_supported_package_manager (expected winget or choco)",
	}


def _handle_update_package(params: Dict[str, Any]) -> Dict[str, Any]:
	name = str(params.get("package") or params.get("name") or "").strip()
	version = str(params.get("version") or params.get("target_version") or "").strip() or None
	if not name:
		raise ValueError("update_package requires 'package' or 'name'")

	system = platform.system().lower()
	if system == "linux":
		return _update_package_linux(name, version)
	if system == "windows":
		return _update_package_windows(name, version)
	return {"manager": None, "exit_code": -1, "error": f"unsupported_platform: {system}"}


# --- remove_package / uninstall_package --------------------------------------

def _remove_package_linux(name: str, purge: bool) -> Dict[str, Any]:
	"""Désinstalle un paquet (même ordre de gestionnaires que update_package)."""
	if shutil.which("apt-get"):
		if purge:
			cmd = ["apt-get", "purge", "-y", name]
		else:
			cmd = ["apt-get", "remove", "-y", name]
		process = _run(cmd, timeout=600)
		return {"manager": "apt-get", "purge": purge, **_command_result(cmd, process)}

	if shutil.which("yum"):
		cmd = ["yum", "remove", "-y", name]
		process = _run(cmd, timeout=600)
		return {"manager": "yum", **_command_result(cmd, process)}

	if shutil.which("pacman"):
		cmd = ["pacman", "-Rns", "--noconfirm", name]
		process = _run(cmd, timeout=600)
		return {"manager": "pacman", **_command_result(cmd, process)}

	if shutil.which("dnf"):
		cmd = ["dnf", "remove", "-y", name]
		process = _run(cmd, timeout=600)
		return {"manager": "dnf", **_command_result(cmd, process)}

	return {
		"manager": None,
		"exit_code": -1,
		"error": (
			"package-manager non pris en charge "
			"(attendus: apt-get, yum, pacman, dnf)"
		),
	}


def _remove_package_windows(name: str) -> Dict[str, Any]:
	if shutil.which("winget"):
		cmd = [
			"winget", "uninstall", "--id", name,
			"--silent", "--accept-source-agreements",
		]
		process = _run(cmd, timeout=900)
		return {"manager": "winget", **_command_result(cmd, process)}

	if shutil.which("choco"):
		cmd = ["choco", "uninstall", name, "-y"]
		process = _run(cmd, timeout=900)
		return {"manager": "choco", **_command_result(cmd, process)}

	return {
		"manager": None,
		"exit_code": -1,
		"error": "no_supported_package_manager (expected winget or choco)",
	}


def _handle_remove_package(params: Dict[str, Any]) -> Dict[str, Any]:
	name = str(params.get("package") or params.get("name") or "").strip()
	if not name:
		raise ValueError("remove_package requires 'package' or 'name'")
	purge = bool(params.get("purge"))

	system = platform.system().lower()
	if system == "linux":
		return _remove_package_linux(name, purge)
	if system == "windows":
		return _remove_package_windows(name)
	return {"manager": None, "exit_code": -1, "error": f"unsupported_platform: {system}"}


# --- close_port -------------------------------------------------------------

def _close_port_linux(port: int, protocol: str) -> Dict[str, Any]:
	proto = "tcp" if protocol == "tcp" else "udp"
	if shutil.which("ufw"):
		cmd = ["ufw", "deny", f"{port}/{proto}"]
		process = _run(cmd, timeout=30)
		return {"firewall": "ufw", **_command_result(cmd, process)}
	if shutil.which("iptables"):
		cmd = [
			"iptables", "-A", "INPUT", "-p", proto,
			"--dport", str(port), "-j", "DROP",
		]
		process = _run(cmd, timeout=30)
		return {"firewall": "iptables", **_command_result(cmd, process)}
	return {
		"firewall": None,
		"exit_code": -1,
		"error": "no_supported_firewall (expected ufw or iptables)",
	}


def _close_port_windows(port: int, protocol: str) -> Dict[str, Any]:
	proto = "TCP" if protocol == "tcp" else "UDP"
	rule_name = f"RivexAgent_Block_{proto}_{port}"
	cmd = [
		"netsh", "advfirewall", "firewall", "add", "rule",
		f"name={rule_name}",
		"dir=in", "action=block",
		f"protocol={proto}",
		f"localport={port}",
	]
	process = _run(cmd, timeout=30)
	return {"firewall": "netsh", **_command_result(cmd, process)}


def _handle_close_port(params: Dict[str, Any]) -> Dict[str, Any]:
	try:
		port = int(params.get("port"))
	except (TypeError, ValueError) as exc:
		raise ValueError("close_port requires integer 'port'") from exc
	if port <= 0 or port > 65535:
		raise ValueError("close_port 'port' must be between 1 and 65535")

	protocol = str(params.get("protocol") or "tcp").strip().lower()
	if protocol not in {"tcp", "udp"}:
		raise ValueError("close_port 'protocol' must be 'tcp' or 'udp'")

	system = platform.system().lower()
	if system == "linux":
		return _close_port_linux(port, protocol)
	if system == "windows":
		return _close_port_windows(port, protocol)
	return {"firewall": None, "exit_code": -1, "error": f"unsupported_platform: {system}"}


# --- disable_service --------------------------------------------------------

def _handle_disable_service(params: Dict[str, Any]) -> Dict[str, Any]:
	name = str(params.get("service") or params.get("name") or "").strip()
	if not name:
		raise ValueError("disable_service requires 'service' or 'name'")

	system = platform.system().lower()
	if system == "linux":
		cmd = ["systemctl", "disable", "--now", name]
		process = _run(cmd, timeout=60)
		return {"manager": "systemd", **_command_result(cmd, process)}
	if system == "windows":
		stop_cmd = ["sc", "stop", name]
		stop = _run(stop_cmd, timeout=60)
		disable_cmd = ["sc", "config", name, "start=", "disabled"]
		disable = _run(disable_cmd, timeout=60)
		return {
			"manager": "sc",
			"stop": _command_result(stop_cmd, stop),
			"disable": _command_result(disable_cmd, disable),
			"exit_code": disable.returncode,
		}
	return {"manager": None, "exit_code": -1, "error": f"unsupported_platform: {system}"}


# --- Registre des handlers --------------------------------------------------

ACTION_HANDLERS = {
	"update_package": _handle_update_package,
	"upgrade_package": _handle_update_package,
	"remove_package": _handle_remove_package,
	"uninstall_package": _handle_remove_package,
	"close_port": _handle_close_port,
	"block_port": _handle_close_port,
	"disable_service": _handle_disable_service,
}


def supported_actions() -> List[str]:
	return sorted(set(ACTION_HANDLERS.keys()))


# ---------------------------------------------------------------------------
# Point d entree principal
# ---------------------------------------------------------------------------

def _normalize_remediation_entry(entry: Dict[str, Any]) -> Dict[str, Any]:
	action = str(entry.get("action") or "").strip().lower()
	params_raw = entry.get("params")
	if isinstance(params_raw, dict):
		params = dict(params_raw)
	else:
		# Permettre un format compact ou les parametres sont inlines
		params = {
			key: value for key, value in entry.items()
			if key not in {"action", "cve_id", "severity", "description", "params"}
		}
	return {
		"action": action,
		"cve_id": str(entry.get("cve_id") or "").strip(),
		"severity": str(entry.get("severity") or "").strip().lower() or None,
		"description": entry.get("description"),
		"params": params,
	}


def apply_vulnerability_patch(document: Dict[str, Any]) -> Dict[str, Any]:
	"""Applique un document de patch de vulnerabilites.

	Le document attend au moins l un des champs `vulnerabilities`, `patches`,
	`fixes` ou `remediations` contenant une liste d entrees.
	"""
	items: List[Dict[str, Any]] = []
	for key in ("vulnerabilities", "patches", "fixes", "remediations"):
		raw = document.get(key)
		if isinstance(raw, list):
			items = [entry for entry in raw if isinstance(entry, dict)]
			break

	if not items:
		raise ValueError(
			"Patch document must contain a non-empty list under "
			"'vulnerabilities', 'patches', 'fixes' or 'remediations'"
		)

	dry_run = bool(document.get("dry_run", False))

	# Les actions reelles (update_package / remove_package / close_port / disable_service)
	# exigent toutes des droits root/admin. On verifie l elevation une seule
	# fois, avant tout traitement, pour echouer proprement plutot que sur
	# chaque commande. Le dry-run est exempte (aucune commande executee).
	if not dry_run:
		try:
			from core.system_deps import ensure_elevated  # type: ignore

			ensure_elevated("apply_vulnerability_patch")
		except ImportError:
			# system_deps indisponible: on continue sans check explicite (les
			# commandes elles-memes retourneront un exit_code non-zero).
			pass
		except PermissionError as exc:
			return {
				"patch_applied": False,
				"patch_id": document.get("patch_id"),
				"mode": "vulnerability_remediation",
				"dry_run": False,
				"error": "elevation_required",
				"message": str(exc),
				"total": len(items),
				"applied": [],
				"failed": [],
				"skipped": [],
			}
	applied: List[Dict[str, Any]] = []
	failed: List[Dict[str, Any]] = []
	skipped: List[Dict[str, Any]] = []

	for raw_entry in items:
		entry = _normalize_remediation_entry(raw_entry)
		action = entry["action"]
		cve_id = entry["cve_id"]
		params = entry["params"]

		if not action:
			skipped.append({
				"cve_id": cve_id,
				"reason": "missing_action",
			})
			continue

		handler = ACTION_HANDLERS.get(action)
		if handler is None:
			skipped.append({
				"cve_id": cve_id,
				"action": action,
				"reason": "unsupported_action",
			})
			continue

		if dry_run:
			applied.append({
				"cve_id": cve_id,
				"action": action,
				"dry_run": True,
				"params": params,
			})
			continue

		try:
			result = handler(params)
			exit_code = result.get("exit_code")
			record = {
				"cve_id": cve_id,
				"action": action,
				"result": result,
			}
			if exit_code in (None, 0):
				applied.append(record)
			else:
				failed.append(record)
		except Exception as exc:
			failed.append({
				"cve_id": cve_id,
				"action": action,
				"error": f"{type(exc).__name__}: {exc}",
			})

	return {
		"patch_applied": True,
		"patch_id": document.get("patch_id"),
		"mode": "vulnerability_remediation",
		"dry_run": dry_run,
		"total": len(items),
		"applied": applied,
		"failed": failed,
		"skipped": skipped,
		"platform": platform.system().lower(),
	}
