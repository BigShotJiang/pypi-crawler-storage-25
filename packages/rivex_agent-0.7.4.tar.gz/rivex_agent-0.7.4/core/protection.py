"""Module de protection de l'agent Rivex.

Objectifs:

- Detecter une tentative de suppression ou de modification non autorisee des
  fichiers critiques de l'agent.
- Modes d integrite (voir :func:`integrity_profile`) :
  - **source_tree** (dev portable, tarball, installation ``pip`` / site-packages) :
    hash des modules ``.py`` + ``config.json`` a la racine du package.
  - **pyinstaller** (binaire Windows / Linux) : le code n existe pas en fichiers
    separes ; on hash l executable (``sys.executable``) et le modele
    ``config.json`` a cote du binaire s il est present.
- Maintenir localement un baseline de hash SHA-256 pour chaque cible, stocke
  dans ``.runtime/protection_baseline.json`` (hors Git). Un changement de
  profil (ex. passage sources -> binaire) reinitialise le baseline.
- Remonter une alerte au serveur via un endpoint dedie (POST JSON) quand un
  ecart par rapport au baseline est detecte, en s'appuyant sur le meme
  agent_token que le reste de l'API agent.
- Rester non-bloquant: si l'envoi echoue (reseau, endpoint non implemente
  cote serveur pour le moment), l'agent continue son execution et log
  l'incident localement pour analyse differee.
"""

from __future__ import annotations

import hashlib
import json
import platform
import socket
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin
from urllib.request import Request, urlopen


BASELINE_FILE_NAME = "protection_baseline.json"
DEFAULT_ALERT_PATH = "/api/agent/alerts"
INTEGRITY_PROFILE_SOURCE = "source_tree"
INTEGRITY_PROFILE_PYINSTALLER = "pyinstaller"
LEGACY_INTEGRITY_PROFILE = INTEGRITY_PROFILE_SOURCE  # baselines sans champ

# Chemins relatifs au dossier agent (mode source_tree : portable, pip, /opt/.../lib).
CRITICAL_SOURCE_RELATIVE_PATHS: Tuple[str, ...] = (
	"agent_launcher.py",
	"config.json",
	"core/__init__.py",
	"core/config_manager.py",
	"core/logger.py",
	"core/remote_commands.py",
	"core/scheduler.py",
	"core/updater.py",
	"core/protection.py",
	"core/patch_engine.py",
	"core/system_deps.py",
	"core/system_install.py",
	"core/install_paths.py",
	"rivex_agent.py",
)

# Compat. tests / imports existants
CRITICAL_RELATIVE_PATHS = CRITICAL_SOURCE_RELATIVE_PATHS


def _is_pyinstaller_frozen() -> bool:
	"""Aligne sur agent_launcher: AGENT_DIR = parent de sys.executable si frozen."""
	return bool(getattr(sys, "frozen", False))


def integrity_profile(_agent_dir: Path | None = None) -> str:
	"""Profil d integrite courant. ``_agent_dir`` est optionnel (API stable)."""
	return INTEGRITY_PROFILE_PYINSTALLER if _is_pyinstaller_frozen() else INTEGRITY_PROFILE_SOURCE


def critical_integrity_entries(agent_dir: Path) -> list[tuple[str, Path]]:
	"""Cles logiques + chemins absolus a inclure dans le snapshot."""
	base = agent_dir.resolve()
	if _is_pyinstaller_frozen():
		exe = Path(sys.executable).resolve()
		return [
			("agent_binary", exe),
			("config.json", base / "config.json"),
		]
	return [(rel, base / rel) for rel in CRITICAL_SOURCE_RELATIVE_PATHS]


def _baseline_file_was_present(baseline_state: Dict[str, Any]) -> bool:
	"""A l enregistrement du baseline, le fichier etait-il cense etre la ?"""
	if "exists" in baseline_state:
		return bool(baseline_state.get("exists"))
	return bool(baseline_state.get("hash"))


def _utc_now_iso() -> str:
	return datetime.now(timezone.utc).isoformat()


def _hash_file(path: Path) -> Optional[str]:
	try:
		digest = hashlib.sha256()
		with path.open("rb") as handle:
			for chunk in iter(lambda: handle.read(8192), b""):
				digest.update(chunk)
		return digest.hexdigest()
	except (OSError, PermissionError):
		return None


def _file_snapshot(path: Path) -> Dict[str, Any]:
	exists = path.exists() and path.is_file()
	if not exists:
		return {"exists": False, "hash": None, "size": None}
	try:
		size = path.stat().st_size
	except OSError:
		size = None
	return {
		"exists": True,
		"hash": _hash_file(path),
		"size": size,
	}


def current_integrity_snapshot(agent_dir: Path) -> Dict[str, Dict[str, Any]]:
	snapshot: Dict[str, Dict[str, Any]] = {}
	for key, full_path in critical_integrity_entries(agent_dir):
		snapshot[key] = _file_snapshot(full_path)
	return snapshot


def _baseline_path(runtime_dir: Path) -> Path:
	return runtime_dir / BASELINE_FILE_NAME


def load_baseline(runtime_dir: Path) -> Dict[str, Any]:
	path = _baseline_path(runtime_dir)
	if not path.exists():
		return {}
	try:
		data = json.loads(path.read_text(encoding="utf-8"))
	except Exception:
		return {}
	return data if isinstance(data, dict) else {}


def save_baseline(runtime_dir: Path, baseline: Dict[str, Any]) -> None:
	runtime_dir.mkdir(parents=True, exist_ok=True)
	_baseline_path(runtime_dir).write_text(
		json.dumps(baseline, indent=2, ensure_ascii=False),
		encoding="utf-8",
	)


def update_baseline(agent_dir: Path, runtime_dir: Path) -> Dict[str, Any]:
	snapshot = current_integrity_snapshot(agent_dir)
	payload = {
		"generated_at": _utc_now_iso(),
		"integrity_profile": integrity_profile(agent_dir),
		"host": socket.gethostname(),
		"platform": platform.system().lower(),
		"files": snapshot,
	}
	save_baseline(runtime_dir, payload)
	return payload


def _compare_snapshot_to_baseline(
	current: Dict[str, Dict[str, Any]],
	baseline_files: Dict[str, Any],
) -> Tuple[List[Dict[str, Any]], List[str]]:
	tampered: List[Dict[str, Any]] = []
	missing: List[str] = []

	for relative, current_state in current.items():
		baseline_state = baseline_files.get(relative)
		if not isinstance(baseline_state, dict):
			continue

		expected_hash = baseline_state.get("hash")
		if not current_state.get("exists"):
			# Defaut: absent au baseline et toujours absent = pas d alerte.
			# Un fichier present au baseline (hash ou exists) qui dispare = alerte.
			if not _baseline_file_was_present(baseline_state) and not expected_hash:
				continue
			missing.append(relative)
			tampered.append({
				"path": relative,
				"reason": "file_missing",
				"expected_hash": expected_hash,
				"current_hash": None,
			})
			continue

		current_hash = current_state.get("hash")
		if expected_hash and current_hash and expected_hash != current_hash:
			tampered.append({
				"path": relative,
				"reason": "hash_mismatch",
				"expected_hash": expected_hash,
				"current_hash": current_hash,
			})

	return tampered, missing


def detect_tampering(
	agent_dir: Path,
	runtime_dir: Path,
	auto_initialize: bool = True,
) -> Dict[str, Any]:
	"""Compare l etat courant au baseline et retourne un rapport.

	- Initialise silencieusement le baseline au premier passage si `auto_initialize`.
	- Ne leve jamais d exception: les erreurs d I/O sont tracees dans le rapport.
	"""
	baseline_payload = load_baseline(runtime_dir)
	if not isinstance(baseline_payload, dict):
		baseline_payload = {}
	baseline_files = baseline_payload.get("files", {}) if isinstance(baseline_payload.get("files"), dict) else {}
	current = current_integrity_snapshot(agent_dir)
	current_p = integrity_profile(agent_dir)

	if not baseline_files:
		if auto_initialize:
			update_baseline(agent_dir, runtime_dir)
			return {
				"tampered": False,
				"baseline_initialized": True,
				"baseline_generated_at": _utc_now_iso(),
				"integrity_profile": current_p,
				"files": current,
			}
		return {
			"tampered": False,
			"baseline_initialized": False,
			"reason": "no_baseline",
			"integrity_profile": current_p,
			"files": current,
		}

	stored_p = baseline_payload.get("integrity_profile")
	if stored_p is None:
		stored_p = LEGACY_INTEGRITY_PROFILE
	if stored_p != current_p:
		if auto_initialize:
			update_baseline(agent_dir, runtime_dir)
			current = current_integrity_snapshot(agent_dir)
			return {
				"tampered": False,
				"baseline_initialized": True,
				"integrity_profile_switched": True,
				"from_profile": stored_p,
				"to_profile": current_p,
				"baseline_generated_at": _utc_now_iso(),
				"integrity_profile": current_p,
				"files": current,
			}
		return {
			"tampered": False,
			"baseline_initialized": False,
			"reason": "integrity_profile_mismatch",
			"integrity_profile": current_p,
			"stored_profile": stored_p,
			"files": current,
		}

	tampered_files, missing_files = _compare_snapshot_to_baseline(current, baseline_files)
	return {
		"tampered": bool(tampered_files),
		"baseline_generated_at": baseline_payload.get("generated_at"),
		"integrity_profile": current_p,
		"tampered_files": tampered_files,
		"missing_files": missing_files,
		"files": current,
	}


def _resolve_alert_url(server_url: str, explicit_url: str) -> str:
	url = str(explicit_url or "").strip()
	if url:
		return url
	base = str(server_url or "").strip()
	if not base:
		return ""
	return urljoin(base.rstrip("/") + "/", DEFAULT_ALERT_PATH.lstrip("/"))


def send_tamper_alert(
	server_url: str,
	alert_url: str,
	auth_token: str,
	payload: Dict[str, Any],
	timeout_seconds: int = 10,
	agent_id: str = "",
	machine_id: str = "",
) -> Dict[str, Any]:
	"""Envoie un POST JSON au serveur. Non-bloquant: capture toutes les erreurs."""
	url = _resolve_alert_url(server_url, alert_url)
	if not url:
		return {
			"sent": False,
			"reason": "alert_url_not_configured",
		}

	body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
	headers = {
		"Content-Type": "application/json",
		"Accept": "application/json",
		"User-Agent": "Rivex-Agent",
	}
	token = str(auth_token or "").strip()
	aid = str(agent_id or "").strip()
	mid = str(machine_id or "").strip()
	if token and aid and mid:
		from core.agent_http_auth import rivex_agent_signature_headers

		headers.update(rivex_agent_signature_headers("POST", url, body, aid, mid, token))
	elif token:
		headers["Authorization"] = f"Bearer {token}"

	request = Request(url, data=body, headers=headers, method="POST")
	try:
		with urlopen(request, timeout=timeout_seconds) as response:
			raw = response.read().decode("utf-8", errors="replace").strip()
		try:
			parsed = json.loads(raw) if raw else {}
			if not isinstance(parsed, dict):
				parsed = {"message": raw}
		except json.JSONDecodeError:
			parsed = {"message": raw}
		return {
			"sent": True,
			"url": url,
			"response": parsed,
		}
	except HTTPError as exc:
		try:
			error_body = exc.read().decode("utf-8", errors="replace").strip()
		except Exception:
			error_body = ""
		return {
			"sent": False,
			"url": url,
			"http_status": int(exc.code),
			"error": error_body or str(exc),
		}
	except URLError as exc:
		return {
			"sent": False,
			"url": url,
			"error": f"network_error: {exc}",
		}
	except Exception as exc:
		return {
			"sent": False,
			"url": url,
			"error": f"{type(exc).__name__}: {exc}",
		}


def build_tamper_alert_payload(
	agent_uuid: str,
	machine_id: str,
	agent_version: str,
	tamper_report: Dict[str, Any],
) -> Dict[str, Any]:
	return {
		"alert_type": "agent_tamper_detected",
		"severity": "high",
		"detected_at": _utc_now_iso(),
		"agent_uuid": str(agent_uuid or ""),
		"machine_id": str(machine_id or ""),
		"agent_version": str(agent_version or ""),
		"host": socket.gethostname(),
		"platform": platform.system().lower(),
		"tampered_files": tamper_report.get("tampered_files", []),
		"missing_files": tamper_report.get("missing_files", []),
		"baseline_generated_at": tamper_report.get("baseline_generated_at"),
	}
