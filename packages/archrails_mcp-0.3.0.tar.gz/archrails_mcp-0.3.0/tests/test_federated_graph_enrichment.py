"""
Tests for shared.calm.federated_graph_enrichment.enrich_graph_with_federation.

The enricher folds federation reference rows + foreign node info from
their owner repo's live graph into a per-repo graph, so the dashboard
view of frontend renders web-gui with its arrows to account-service
(in accounts repo), trade-data-store (in data-platform repo), etc.,
without each team having to redeclare cross-repo edges in their CALM.
"""
from __future__ import annotations

import os
import sys
from unittest.mock import patch

this_dir = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(this_dir, ".."))

from shared.calm import federated_graph_enrichment as fge


TENANT = "TENANT#ghci#github.com#t1"
FRONTEND = "https://github.com/archrails/traderx-frontend"
ACCOUNTS = "https://github.com/archrails/traderx-accounts"
DATA_PLATFORM = "https://github.com/archrails/traderx-data-platform"


def _ref_row(*, target_repo, target_node, source_repo, source_node, rel_id, rel_type="connects"):
    return {
        "PK":                f"{TENANT}#{target_repo}#{target_node}",
        "SK":                f"{source_repo}#{source_node}#{rel_id}",
        "tenant_pk":         TENANT,
        "record_type":       "reference",
        "relationship_type": rel_type,
        "staging":           False,
    }


def test_enrichment_no_outbound_or_inbound_returns_unchanged_copy():
    graph = {"nodes": [{"id": "web-gui"}], "edges": []}
    with patch.object(fge, "query_outbound_references", return_value=[]), \
         patch.object(fge, "query_inbound_references",  return_value=[]):
        out = fge.enrich_graph_with_federation(
            graph=graph, tenant_pk=TENANT, repo_canonical=FRONTEND,
        )
    assert out == graph
    assert out is not graph  # caller-mutable copy


def test_enrichment_adds_inbound_external_node_and_edge():
    """Frontend's view of web-gui must show inbound callers (trader,
    trade-feed) — not just the outbound calls web-gui makes."""
    graph = {"nodes": [{"id": "web-gui", "type": "webclient"}], "edges": []}
    inbound = [
        {
            "PK":                f"{TENANT}#{FRONTEND}#web-gui",
            "SK":                "https://github.com/archrails/traderx-trading#trade-feed#trade-feed-web-gui",
            "tenant_pk":         TENANT,
            "record_type":       "reference",
            "relationship_type": "connects",
            "staging":           False,
        },
    ]
    foreign_trading_graph = {
        "nodes": [{"id": "trade-feed", "label": "Trade Feed", "node-type": "service"}],
        "edges": [],
    }
    with patch.object(fge, "query_outbound_references", return_value=[]), \
         patch.object(fge, "query_inbound_references",  return_value=inbound), \
         patch.object(fge, "build_repo_url_to_sk_map", return_value={
            "https://github.com/archrails/traderx-trading": "github#github.com#777",
         }), \
         patch.object(fge, "read_live_graph_for_repo_sk", return_value=foreign_trading_graph):
        out = fge.enrich_graph_with_federation(
            graph=graph, tenant_pk=TENANT, repo_canonical=FRONTEND,
        )

    node_ids = {n["id"] for n in out["nodes"]}
    assert "trade-feed" in node_ids   # source-side stub added
    edge_ids = {e["id"] for e in out["edges"]}
    assert "trade-feed-web-gui" in edge_ids
    edge = next(e for e in out["edges"] if e["id"] == "trade-feed-web-gui")
    assert edge["from"] == "trade-feed"
    assert edge["to"]   == "web-gui"


def test_enrichment_dedupes_when_same_edge_in_both_directions():
    """If the federation table somehow contains the same row indexed
    in both outbound and inbound shapes (shouldn't happen in practice
    but defense in depth), don't emit two edges."""
    graph = {"nodes": [{"id": "web-gui"}], "edges": []}
    rel = {
        "PK":                f"{TENANT}#{ACCOUNTS}#account-service",
        "SK":                f"{FRONTEND}#web-gui#web-gui-account-service",
        "tenant_pk":         TENANT,
        "record_type":       "reference",
        "relationship_type": "connects",
        "staging":           False,
    }
    with patch.object(fge, "query_outbound_references", return_value=[rel]), \
         patch.object(fge, "query_inbound_references",  return_value=[rel]), \
         patch.object(fge, "build_repo_url_to_sk_map", return_value={
            ACCOUNTS: "github#github.com#100", FRONTEND: "github#github.com#200",
         }), \
         patch.object(fge, "read_live_graph_for_repo_sk", return_value={"nodes": [], "edges": []}):
        out = fge.enrich_graph_with_federation(
            graph=graph, tenant_pk=TENANT, repo_canonical=FRONTEND,
        )
    edge_ids = [e["id"] for e in out["edges"]]
    assert edge_ids.count("web-gui-account-service") == 1


def test_enrichment_adds_external_node_with_foreign_interfaces():
    """The whole point: pull the foreign node's interfaces.host so the
    DB-boundary validator can resolve `host: 'trade-data-store'`."""
    graph = {"nodes": [{"id": "web-gui", "type": "webclient"}], "edges": []}
    outbound = [_ref_row(
        target_repo=DATA_PLATFORM, target_node="trade-data-store",
        source_repo=FRONTEND,      source_node="web-gui",
        rel_id="web-gui-trade-data-store",
    )]
    foreign_graph = {
        "nodes": [{
            "id":         "trade-data-store",
            "label":      "Trade Data Store",
            "node-type":  "database",
            "interfaces": {"primary": {"host": "trade-data-store", "port": 5432}},
        }],
        "edges": [],
    }
    with patch.object(fge, "query_outbound_references", return_value=outbound), \
         patch.object(fge, "query_inbound_references",  return_value=[]), \
         patch.object(fge, "build_repo_url_to_sk_map", return_value={
            DATA_PLATFORM: "github#github.com#999",
         }), \
         patch.object(fge, "read_live_graph_for_repo_sk", return_value=foreign_graph):
        out = fge.enrich_graph_with_federation(
            graph=graph, tenant_pk=TENANT, repo_canonical=FRONTEND,
        )

    node_ids = {n["id"] for n in out["nodes"]}
    assert "trade-data-store" in node_ids
    foreign = next(n for n in out["nodes"] if n["id"] == "trade-data-store")
    assert foreign["metadata"]["external"] is True
    assert foreign["metadata"]["repository"] == DATA_PLATFORM
    assert foreign["interfaces"] == {"primary": {"host": "trade-data-store", "port": 5432}}
    assert foreign["node-type"] == "database"

    edge_ids = {e["id"] for e in out["edges"]}
    assert "web-gui-trade-data-store" in edge_ids
    edge = next(e for e in out["edges"] if e["id"] == "web-gui-trade-data-store")
    assert edge["from"] == "web-gui"
    assert edge["to"] == "trade-data-store"
    assert edge["metadata"]["cross_repo"] is True


def test_enrichment_idempotent():
    """Running twice produces the same output (no duplicate stubs/edges)."""
    graph = {"nodes": [{"id": "web-gui"}], "edges": []}
    outbound = [_ref_row(
        target_repo=ACCOUNTS, target_node="account-service",
        source_repo=FRONTEND, source_node="web-gui",
        rel_id="web-gui-account-service",
    )]
    foreign_graph = {"nodes": [{"id": "account-service", "node-type": "service"}], "edges": []}
    with patch.object(fge, "query_outbound_references", return_value=outbound), \
         patch.object(fge, "query_inbound_references",  return_value=[]), \
         patch.object(fge, "build_repo_url_to_sk_map", return_value={
            ACCOUNTS: "github#github.com#100",
         }), \
         patch.object(fge, "read_live_graph_for_repo_sk", return_value=foreign_graph):
        once = fge.enrich_graph_with_federation(
            graph=graph, tenant_pk=TENANT, repo_canonical=FRONTEND,
        )
        twice = fge.enrich_graph_with_federation(
            graph=once, tenant_pk=TENANT, repo_canonical=FRONTEND,
        )
    assert len(twice["nodes"]) == len(once["nodes"])
    assert len(twice["edges"]) == len(once["edges"])


def test_enrichment_degrades_gracefully_on_federation_error():
    """If query_outbound_references blows up, return the input graph
    unchanged. Don't fail the validation/dashboard request."""
    graph = {"nodes": [{"id": "web-gui"}], "edges": []}
    with patch.object(fge, "query_outbound_references", side_effect=RuntimeError("boom")):
        out = fge.enrich_graph_with_federation(
            graph=graph, tenant_pk=TENANT, repo_canonical=FRONTEND,
        )
    assert out == graph


def test_tenant_db_hosts_pass_adds_undeclared_db_nodes():
    """When `include_tenant_db_hosts=True`, every database-typed node
    from EVERY OTHER repo in the tenant gets added as a bare external
    stub — even if no reference row connects it to the current repo.
    This is what makes AR-CTRL-DB-BOUNDARY-001 able to flag code that
    references e.g. `host: 'trade-data-store'` from frontend when no
    `connects` edge declares that path."""
    graph = {"nodes": [{"id": "web-gui", "type": "webclient"}], "edges": []}
    DATA_PLATFORM_GRAPH = {
        "nodes": [
            {"id": "trade-data-store", "node-type": "database",
             "interfaces": {"primary": {"host": "trade-data-store", "port": 5432}}},
            {"id": "user-directory",  "node-type": "ldap",
             "interfaces": {"primary": {"host": "user-directory", "port": 389}}},
            {"id": "security-master", "node-type": "service"},  # not a DB; skip
        ],
        "edges": [],
    }
    with patch.object(fge, "query_outbound_references", return_value=[]), \
         patch.object(fge, "query_inbound_references",  return_value=[]), \
         patch.object(fge, "build_repo_url_to_sk_map", return_value={
            DATA_PLATFORM: "github#github.com#999",
            FRONTEND:      "github#github.com#100",
         }), \
         patch.object(fge, "read_live_graph_for_repo_sk",
                      side_effect=lambda _t, sk: DATA_PLATFORM_GRAPH if sk == "github#github.com#999" else {"nodes": [], "edges": []}):
        out = fge.enrich_graph_with_federation(
            graph=graph, tenant_pk=TENANT, repo_canonical=FRONTEND,
            include_tenant_db_hosts=True,
        )

    node_ids = {n["id"] for n in out["nodes"]}
    assert "trade-data-store" in node_ids   # DB → added
    assert "user-directory"   in node_ids   # ldap → added
    assert "security-master"  not in node_ids   # service → skipped
    # Foreign DB stubs carry the boundary marker so downstream code can
    # distinguish "added because of an actual edge" from "added because
    # we wanted the host index populated."
    db_node = next(n for n in out["nodes"] if n["id"] == "trade-data-store")
    assert db_node["metadata"]["tenant_db_stub"] is True
    assert db_node["metadata"]["external"]      is True
    assert db_node["interfaces"] == {"primary": {"host": "trade-data-store", "port": 5432}}


def test_tenant_db_hosts_pass_off_by_default():
    """The default (off) keeps the dashboard view clean — DB nodes
    that aren't on any reference row touching this repo do not
    appear."""
    graph = {"nodes": [{"id": "web-gui"}], "edges": []}
    DATA_PLATFORM_GRAPH = {
        "nodes": [{"id": "trade-data-store", "node-type": "database"}],
        "edges": [],
    }
    with patch.object(fge, "query_outbound_references", return_value=[]), \
         patch.object(fge, "query_inbound_references",  return_value=[]), \
         patch.object(fge, "build_repo_url_to_sk_map", return_value={
            DATA_PLATFORM: "github#github.com#999",
         }), \
         patch.object(fge, "read_live_graph_for_repo_sk",
                      return_value=DATA_PLATFORM_GRAPH):
        out = fge.enrich_graph_with_federation(
            graph=graph, tenant_pk=TENANT, repo_canonical=FRONTEND,
        )
    node_ids = {n["id"] for n in out["nodes"]}
    assert "trade-data-store" not in node_ids


def test_enrichment_skips_when_tenant_or_repo_unset():
    graph = {"nodes": [], "edges": []}
    assert fge.enrich_graph_with_federation(
        graph=graph, tenant_pk="", repo_canonical=FRONTEND,
    ) == graph
    assert fge.enrich_graph_with_federation(
        graph=graph, tenant_pk=TENANT, repo_canonical="",
    ) == graph
