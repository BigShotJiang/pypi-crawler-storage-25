"""archrails CLI entry point.

Usage:
    archrails bootstrap                              # one-time setup for a new dev
    archrails login                                  # cache credentials for cloud MCP
    archrails logout                                 # clear cached credentials
    archrails mcp start --repo /path/to/repo         # default code-mode server
    archrails mcp start --repo . --mode architect    # architect mode (CALM-editing)
    archrails arch init                              # drop FINOS Claude skill
    archrails calm <subcommand>                      # wraps FINOS CALM CLI
    archrails calm install                           # install pinned FINOS CALM CLI
"""
from __future__ import annotations

import argparse
import asyncio
import logging
import sys
from pathlib import Path

# CRITICAL for MCP stdio: stdout is reserved for JSON-RPC. shared.logger
# (and several other libraries) default to StreamHandler(sys.stdout),
# which would corrupt the MCP framing. Patch StreamHandler so anything
# that would target sys.stdout — or that defaults — lands on sys.stderr.
# This must run before any module that creates loggers is imported.
_orig_stream_handler_init = logging.StreamHandler.__init__


def _stderr_default_init(self, stream=None):  # type: ignore[no-untyped-def]
    if stream is None or stream is sys.stdout:
        stream = sys.stderr
    return _orig_stream_handler_init(self, stream)


logging.StreamHandler.__init__ = _stderr_default_init  # type: ignore[assignment]


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="archrails",
        description="ArchRails CLI — MCP server, FINOS CALM tooling, and developer auth.",
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    # bootstrap
    boot = sub.add_parser(
        "bootstrap",
        help="One-time setup: install CALM CLI, sign in, wire IDE MCP config.",
    )
    boot.add_argument("--dashboard", default=None, help="Dashboard URL (default: env or built-in dev)")
    boot.add_argument("--api-base", default=None, help="API Gateway base URL")
    boot.add_argument("--mcp-url", default=None, help="Cloud MCP Function URL")
    boot.add_argument("--force", action="store_true", help="Replace existing credentials")
    boot.add_argument("--skip-login", action="store_true", help="Skip the sign-in step")
    boot.add_argument(
        "--no-calm-required",
        action="store_true",
        help="Continue bootstrap even if Node.js / CALM CLI install fails",
    )

    # login / logout
    login = sub.add_parser("login", help="Sign in via the dashboard and cache credentials.")
    login.add_argument("--dashboard", default=None)
    login.add_argument("--api-base", default=None)
    login.add_argument("--mcp-url", default=None)
    login.add_argument(
        "--paste",
        action="store_true",
        help="Use the manual paste flow instead of the browser callback.",
    )
    sub.add_parser("logout", help="Remove cached credentials.")

    # demo — copies the sample-payments-platform to the user's machine
    # and prints a refusal walk-through. No auth required.
    demo = sub.add_parser(
        "demo",
        help=(
            "Copy a tiny sample CALM architecture to your machine and "
            "walk through what ArchRails does when an agent proposes a "
            "forbidden change. No login required — kick the tires "
            "before setting up your own repo."
        ),
    )
    demo.add_argument(
        "--dir",
        default=None,
        help="Where to copy the sample (default: ~/archrails-demo).",
    )
    demo.add_argument(
        "--force",
        action="store_true",
        help="Overwrite the destination if it already exists.",
    )

    # check — direct CLI verb for "validate my local diff"
    check = sub.add_parser(
        "check",
        help=(
            "Run the ArchRails validator suite against your local git diff. "
            "Same brain as the merge gate — a clean response here means "
            "the PR would pass; a blocked verdict means the merge will block."
        ),
    )
    check.add_argument(
        "--repo",
        default=".",
        help="Path to the workspace (default: current dir).",
    )
    check.add_argument(
        "--against",
        default="HEAD",
        help=(
            "Git ref to diff against. Default 'HEAD' captures uncommitted + "
            "staged work. Use 'main' to compare working-tree vs main, or "
            "'main..HEAD' for branch-only changes (closest to 'what would "
            "land in a PR opened against main')."
        ),
    )
    check.add_argument(
        "--json",
        action="store_true",
        help=(
            "Emit the full server response as JSON instead of a human-"
            "readable report. Exit code is 0 iff allowed=true."
        ),
    )
    check.add_argument(
        "paths",
        nargs="*",
        help=(
            "Optional git pathspecs to scope the diff (e.g. "
            "'services/payment/**'). Useful for focusing on the file(s) "
            "you just edited."
        ),
    )

    # mcp start
    mcp = sub.add_parser("mcp", help="MCP server commands.")
    mcp_sub = mcp.add_subparsers(dest="mcp_cmd", required=True)
    start = mcp_sub.add_parser("start", help="Run the MCP stdio server.")
    start.add_argument(
        "--repo",
        default=".",
        help="Path to the workspace repo (default: current directory).",
    )
    start.add_argument(
        "--mode",
        choices=["code", "architect"],
        default="code",
        help=(
            "Server mode. `code` (default) — agent writes code, architecture "
            "files are read-only. `architect` — agent may edit CALM files / "
            "archrails.yml; mutation tools (validate_architecture, bind_path) "
            "are exposed and the read-only prohibition is lifted. The two "
            "modes are mutually exclusive — never run both in one session."
        ),
    )
    start.add_argument(
        "--repo-url",
        default=None,
        help=(
            "Override the repo URL the cloud uses to pick a graph. By default "
            "we read it from `git remote get-url origin` on --repo. Use this "
            "when auto-detection picks the wrong remote (forks, mirrors, "
            "multi-remote setups), when --repo doesn't have an `origin` "
            "remote, or when you want to pin the URL in your IDE's MCP "
            "config so it's immune to which folder Cursor inherits at "
            "launch. Also overridable via the ARCHRAILS_REPO_URL env var."
        ),
    )

    # arch — architecture-authoring helpers (architect-mode adjacent).
    arch = sub.add_parser(
        "arch",
        help="Architecture authoring helpers (drops the FINOS Claude skill, etc.).",
    )
    arch_sub = arch.add_subparsers(dest="arch_cmd", required=True)
    arch_init = arch_sub.add_parser(
        "init",
        help=(
            "Drop the FINOS CALM Claude skill into this repo "
            "(.claude/skills/calm/). Wraps `calm init-ai --provider claude`."
        ),
    )
    arch_init.add_argument(
        "--directory",
        default=".",
        help="Target directory (default: current working directory).",
    )

    # calm passthrough — argparse REMAINDER lets us forward arbitrary args
    calm = sub.add_parser(
        "calm",
        help="Wraps the FINOS CALM CLI. `archrails calm install` installs it.",
    )
    calm.add_argument("calm_args", nargs=argparse.REMAINDER)

    return parser


def main() -> int:
    # Special-case `archrails calm ...` so EVERYTHING after `calm` is
    # passed through to the FINOS CALM CLI — including bare flags like
    # `--version` that argparse would otherwise intercept.
    if len(sys.argv) >= 2 and sys.argv[1] == "calm":
        from archrails_mcp.cmd.calm import cmd_calm
        return cmd_calm(sys.argv[2:])

    parser = _build_parser()
    args = parser.parse_args()

    if args.cmd == "mcp" and args.mcp_cmd == "start":
        repo_path = Path(args.repo).resolve()
        if not repo_path.is_dir():
            print(f"[archrails] --repo not a directory: {repo_path}", file=sys.stderr)
            return 2
        # --repo-url override: explicit flag wins, then env var, then None
        # (let server.py auto-detect via git remote).
        import os as _os
        repo_url_override = args.repo_url or _os.environ.get("ARCHRAILS_REPO_URL") or None
        # Gate: unprovisioned machines cannot run the local MCP server.
        # See archrails_mcp.credentials.require_credentials for the env-var
        # escape hatch used by our own CI.
        from archrails_mcp import credentials
        try:
            credentials.require_credentials()
        except credentials.NotProvisioned as e:
            print(str(e), file=sys.stderr)
            return 2
        from archrails_mcp.server import main_async
        try:
            asyncio.run(main_async(
                repo_path,
                mode=args.mode,
                repo_url_override=repo_url_override,
            ))
        except KeyboardInterrupt:
            return 0
        return 0

    if args.cmd == "arch" and args.arch_cmd == "init":
        from archrails_mcp.cmd.arch import cmd_arch_init
        return cmd_arch_init(args)

    if args.cmd == "calm":
        from archrails_mcp.cmd.calm import cmd_calm
        return cmd_calm(args.calm_args or [])

    if args.cmd == "login":
        from archrails_mcp.cmd.login import cmd_login
        return cmd_login(args)

    if args.cmd == "logout":
        from archrails_mcp.cmd.login import cmd_logout
        return cmd_logout(args)

    if args.cmd == "bootstrap":
        from archrails_mcp.cmd.bootstrap import cmd_bootstrap
        return cmd_bootstrap(args)

    if args.cmd == "check":
        from archrails_mcp.cmd.check import cmd_check
        return cmd_check(args)

    if args.cmd == "demo":
        from archrails_mcp.cmd.demo import cmd_demo
        return cmd_demo(args)

    parser.print_help()
    return 1


if __name__ == "__main__":
    sys.exit(main())
