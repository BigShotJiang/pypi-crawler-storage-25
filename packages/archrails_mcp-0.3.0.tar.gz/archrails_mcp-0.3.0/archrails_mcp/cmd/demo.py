"""archrails demo — kick-the-tires walk-through, no auth required.

Copies a small sample architecture (`sample-payments-platform`) to a
local directory and prints what ArchRails would do when an agent tries
to violate it. Designed for the curious developer who wants to see
ArchRails work *before* setting up CALM for their own repo.

Two distinct AHA moments:
  1. Reading the architecture summary — they SEE what enforcement looks
     like in CALM (4 nodes, allowed dependencies, PCI control attached).
  2. Reading the refusal walkthrough — they SEE the validator catching
     a forbidden change with a real rule ID and a CALM-allowed
     alternative spelled out.

After the walk-through the user can:
  - poke at the sample on disk (open the JSON, edit the Java)
  - wire their IDE's MCP to the sample dir (`archrails mcp start --repo ~/archrails-demo`)
  - run `archrails check` against a hand-written bad change

No cloud round-trip, no API key required. The whole point is "you can
try this without talking to sales first."
"""
from __future__ import annotations

import json
import shutil
import sys
from importlib.resources import files
from pathlib import Path


_SAMPLE_PACKAGE = "archrails_mcp"
_SAMPLE_RELPATH = ("examples", "sample-payments-platform")
_DEFAULT_DEST = "~/archrails-demo"


def _bundled_sample_dir() -> Path:
    """Locate the sample directory inside the installed package."""
    root = files(_SAMPLE_PACKAGE)
    sample = root.joinpath(*_SAMPLE_RELPATH)
    # `files()` returns a Traversable, not a Path. For our case
    # (regular files on disk after pip install), convert via str().
    return Path(str(sample))


def _copy_tree(src: Path, dst: Path) -> int:
    """Copy every file under src into dst, preserving relative paths.
    Returns the number of files copied."""
    count = 0
    for item in src.rglob("*"):
        if not item.is_file():
            continue
        rel = item.relative_to(src)
        out = dst / rel
        out.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(item, out)
        count += 1
    return count


def _read_calm_summary(calm_path: Path) -> dict:
    """Pull a tiny summary out of the sample CALM file. Tolerant of
    missing fields — this is for human-readable output, not validation."""
    try:
        doc = json.loads(calm_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {"nodes": [], "rels": [], "name": "(could not parse)"}
    nodes = []
    for n in doc.get("nodes") or []:
        if not isinstance(n, dict):
            continue
        nodes.append({
            "id": n.get("unique-id", "?"),
            "type": n.get("node-type", "?"),
            "name": n.get("name", n.get("unique-id", "?")),
            "controls": n.get("controls") or [],
        })
    rels = []
    for r in doc.get("relationships") or []:
        if not isinstance(r, dict):
            continue
        connects = ((r.get("relationship-type") or {}).get("connects")) or {}
        src = (connects.get("source") or {}).get("node")
        dst = (connects.get("destination") or {}).get("node")
        if src and dst:
            rels.append({
                "from": src,
                "to": dst,
                "protocol": r.get("protocol", "?"),
            })
    return {
        "name": doc.get("name", "(unnamed)"),
        "nodes": nodes,
        "rels": rels,
    }


def _print_walkthrough(dest: Path, summary: dict) -> None:
    out = sys.stdout

    print(file=out)
    print(f"  ArchRails demo — {summary['name']}", file=out)
    print(f"  copied {len(summary['nodes'])} node(s) + "
          f"{len(summary['rels'])} relationship(s) to {dest}", file=out)
    print(file=out)

    # ── Architecture summary ─────────────────────────────────────────
    print("  Architecture (architecture/system.calm.json):", file=out)
    for n in summary["nodes"]:
        controls = (
            f"  controls={', '.join(n['controls'])}" if n["controls"] else ""
        )
        print(f"    • {n['id']} ({n['type']}){controls}", file=out)

    if summary["rels"]:
        print(file=out)
        print("  CALM-allowed relationships:", file=out)
        for r in summary["rels"]:
            print(f"    • {r['from']} → {r['to']} ({r['protocol']})", file=out)

    # ── The refusal scenario ─────────────────────────────────────────
    print(file=out)
    print("  ─────────────────────────────────────────────────────────", file=out)
    print("  What happens when an AI agent proposes a forbidden change", file=out)
    print("  ─────────────────────────────────────────────────────────", file=out)
    print(file=out)
    print("  Imagine your agent tries to write this in payment-api:", file=out)
    print(file=out)
    print("    // services/payment-api/src/Client.java", file=out)
    print("    + import com.acme.carddb.CardDbClient;", file=out)
    print('    + CardDbClient db = CardDbClient.connect("card-db.internal:5432");', file=out)
    print(file=out)
    print("  ArchRails sees that payment-api is PCI-scoped and that no", file=out)
    print("  CALM relationship lets it talk to card-db directly. The", file=out)
    print("  validator suite blocks the change inline:", file=out)
    print(file=out)
    print("    ✗ AR-CTRL-DB-BOUNDARY-001  [high]", file=out)
    print("      payment-api → card-db: not a CALM-allowed target", file=out)
    print("      (PCI boundary — controls in force: pci-no-card-logging)", file=out)
    print("      CALM-allowed targets: card-data-service, fraud-api", file=out)
    print(file=out)
    print("  The agent reads `allowed_targets` from the response and", file=out)
    print("  reroutes through card-data-service — the ONE node CALM", file=out)
    print("  permits as an intermediary to card-db. The merge gate", file=out)
    print("  would have caught this too, with the same rule ID, on", file=out)
    print("  the same diff.", file=out)

    # ── Try it for real ──────────────────────────────────────────────
    print(file=out)
    print("  ─────────────────────────────────────────────────────────", file=out)
    print("  Try it yourself", file=out)
    print("  ─────────────────────────────────────────────────────────", file=out)
    print(file=out)
    print(f"    cd {dest}", file=out)
    print(file=out)
    print("  Option A — wire your IDE's MCP to this sample and let an", file=out)
    print("  agent (Claude Code, Cursor, Windsurf) try the forbidden", file=out)
    print("  change live:", file=out)
    print(file=out)
    print(f'    archrails mcp start --repo "{dest}"', file=out)
    print(file=out)
    print("    (with archrails-local registered in your IDE — the", file=out)
    print("    bootstrap wizard wires this for you).", file=out)
    print(file=out)
    print("  Option B — write your own bad change by hand and check it", file=out)
    print("  against the cloud validator suite:", file=out)
    print(file=out)
    print(f"    cd {dest}", file=out)
    print("    git init -q && git add -A && git commit -qm baseline", file=out)
    print("    # edit services/payment-api/src/Client.java to add a card-db call", file=out)
    print("    archrails check", file=out)
    print(file=out)
    print("    (requires `archrails login` first.)", file=out)

    # ── Onward ───────────────────────────────────────────────────────
    print(file=out)
    print("  ─────────────────────────────────────────────────────────", file=out)
    print("  Going further", file=out)
    print("  ─────────────────────────────────────────────────────────", file=out)
    print(file=out)
    print("  • Browse the CALM file at:", file=out)
    print(f"      {dest / 'architecture' / 'system.calm.json'}", file=out)
    print("  • Browse the archrails.yml binding rules at:", file=out)
    print(f"      {dest / 'archrails.yml'}", file=out)
    print("  • New to CALM? FINOS publishes great tutorials:", file=out)
    print("      https://calm.finos.org/tutorials/", file=out)
    print("  • Apply ArchRails to your own repo: contact us for invite-only", file=out)
    print("    beta access.", file=out)
    print(file=out)


def cmd_demo(args) -> int:
    dest = Path(args.dir or _DEFAULT_DEST).expanduser().resolve()
    src = _bundled_sample_dir()

    if not src.is_dir():
        print(
            f"Bundled sample not found at {src}.\n"
            "This is a packaging bug — please report it.",
            file=sys.stderr,
        )
        return 2

    if dest.exists():
        if any(dest.iterdir()):
            if not args.force:
                print(
                    f"{dest} already exists and is not empty.\n"
                    f"Pass --force to overwrite, or pass --dir <path> "
                    f"to copy somewhere else.",
                    file=sys.stderr,
                )
                return 2
            shutil.rmtree(dest)

    dest.mkdir(parents=True, exist_ok=True)
    try:
        n = _copy_tree(src, dest)
    except OSError as e:
        print(f"Failed to copy sample: {e}", file=sys.stderr)
        return 2

    if n == 0:
        print(f"Sample directory {src} contained no files.", file=sys.stderr)
        return 2

    summary = _read_calm_summary(dest / "architecture" / "system.calm.json")
    _print_walkthrough(dest, summary)
    return 0
