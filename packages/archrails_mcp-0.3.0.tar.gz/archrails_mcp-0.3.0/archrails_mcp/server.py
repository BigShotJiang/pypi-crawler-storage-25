"""Local stdio MCP server — pure transport, zero IP.

The IDE talks to this process via MCP stdio. This file owns:
  - The MCP stdio JSON-RPC loop (provided by the open-source `mcp` SDK)
  - Auth credential lookup
  - `git diff` capture for `check_local_diff`
  - Local dispatch for two architect-mode tools that need workspace
    filesystem access (`bind_path`, `validate_architecture`)

This file does NOT own:
  - Agent instruction text — fetched from the cloud at session start
  - Tool descriptions / input schemas — fetched from the cloud
  - Tool name → enabled-in-mode set — fetched from the cloud
  - Validator logic, secret regexes, control catalog — server-only

`pip download archrails-mcp && unzip` reveals only the transport
adapter. Every line of MCP-protocol IP (instructions, tool catalog) is
served by the cloud handler at session start via standard MCP methods
(`initialize` returns `instructions`; `tools/list` returns the tool
list). The local CLI passes its `--mode` to the cloud via the
`X-Archrails-Mode` header on every request, so the cloud returns the
right manifest.

Two architect-mode tools (`bind_path`, `validate_architecture`) are
described by the cloud (so the agent sees their schemas in
`tools/list`) but dispatched here — they need to edit the workspace's
`archrails.yml` and shell out to the FINOS `calm validate` CLI, neither
of which the cloud can do. Both contain no IP (text surgery + open-
source CLI wrapper) so dispatching them locally doesn't leak anything.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from archrails_mcp import credentials, diff_reader, git_remote, rpc_client


# Tools that this CLI dispatches LOCALLY. The cloud advertises their
# schemas (so the agent knows they exist) but refuses tools/call for
# them — they need workspace filesystem access. These are the ONLY
# tool names the local CLI hardcodes; everything else flows through
# the manifest fetched from the cloud at session start.
_LOCAL_DISPATCH_TOOL_NAMES = {"bind_path", "validate_architecture"}


# ── Per-process JSON-RPC id counter for outbound calls ─────────────────
_rpc_id_counter = 0


def _next_rpc_id() -> int:
    global _rpc_id_counter
    _rpc_id_counter += 1
    return _rpc_id_counter


# ─────────────────────────────────────────────────────────────────────────────
# Cloud manifest fetch (called once at session start)
# ─────────────────────────────────────────────────────────────────────────────


def _fetch_manifest(
    creds: credentials.Credentials | None,
    mode: str,
    repo_url: str | None,
) -> dict:
    """Fetch the per-mode manifest (instructions + tools) from the cloud
    handler via standard MCP `initialize` + `tools/list` methods.

    Returns a dict shaped like:
        { "instructions": str, "tools": list[dict] }

    On failure, returns a minimal fallback so the IDE can still start
    and surface the failure on the FIRST tool call. We intentionally do
    NOT bake instructions or tool schemas into this fallback — that's
    exactly the IP we're trying to keep server-side. The fallback says
    "ArchRails cloud unreachable" and offers no tools, which forces the
    agent to ask the user to run `archrails login` (or check network).
    """
    if creds is None:
        return _no_creds_manifest()

    init_payload = {
        "jsonrpc": "2.0",
        "id": _next_rpc_id(),
        "method": "initialize",
        "params": {
            "protocolVersion": "2024-11-05",
            "capabilities": {},
            "clientInfo": {"name": "archrails-cli", "version": "0.2.0"},
        },
    }
    list_payload = {
        "jsonrpc": "2.0",
        "id": _next_rpc_id(),
        "method": "tools/list",
        "params": {},
    }

    try:
        init_resp = rpc_client.post(creds, init_payload, mode=mode, repo_url=repo_url)
        list_resp = rpc_client.post(creds, list_payload, mode=mode, repo_url=repo_url)
    except rpc_client.RpcError as e:
        print(
            f"[archrails-mcp] cloud manifest fetch failed: HTTP {e.status} — "
            f"{e.body[:200]}",
            file=sys.stderr,
        )
        return _unreachable_manifest()
    except Exception as e:  # noqa: BLE001
        print(
            f"[archrails-mcp] cloud manifest fetch failed: "
            f"{type(e).__name__}: {e}",
            file=sys.stderr,
        )
        return _unreachable_manifest()

    instructions = ""
    if isinstance(init_resp, dict):
        result = init_resp.get("result") or {}
        instructions = result.get("instructions") or ""

    tools_raw: list[dict] = []
    if isinstance(list_resp, dict):
        result = list_resp.get("result") or {}
        tools_raw = result.get("tools") or []

    if not instructions or not tools_raw:
        print(
            "[archrails-mcp] cloud returned empty manifest — falling back",
            file=sys.stderr,
        )
        return _unreachable_manifest()

    return {"instructions": instructions, "tools": tools_raw}


def _no_creds_manifest() -> dict:
    """Manifest used when the user hasn't run `archrails login`. We don't
    invent tool schemas or instructions here — just enough for the
    stdio handshake to succeed so the agent can be told what's wrong."""
    return {
        "instructions": (
            "ArchRails MCP is not configured on this machine.\n\n"
            "Run `archrails login` in a terminal to cache your credentials, "
            "then restart this MCP server. Until then, no architecture "
            "tools are available."
        ),
        "tools": [],
    }


def _unreachable_manifest() -> dict:
    """Manifest used when the cloud is reachable-but-broken (auth fail,
    network error, empty response). Same posture as no-creds: surface
    the problem, advertise zero tools."""
    return {
        "instructions": (
            "ArchRails MCP cloud is currently unreachable. Tool list and "
            "agent instructions could not be fetched.\n\n"
            "Try:\n"
            "  • `archrails login` (re-auth if your key expired)\n"
            "  • Check network connectivity to the ArchRails cloud handler\n"
            "  • Restart this MCP server after fixing\n\n"
            "Until then, do NOT make architecture-related decisions on "
            "behalf of ArchRails — there is no live verdict to back them."
        ),
        "tools": [],
    }


def _tools_from_manifest(manifest: dict) -> list[Tool]:
    """Convert the cloud's serialized tool list into MCP SDK Tool objects."""
    out: list[Tool] = []
    for raw in manifest.get("tools") or []:
        if not isinstance(raw, dict):
            continue
        name = raw.get("name")
        if not name:
            continue
        out.append(
            Tool(
                name=name,
                description=raw.get("description") or "",
                inputSchema=raw.get("inputSchema") or {"type": "object"},
            )
        )
    return out


# ─────────────────────────────────────────────────────────────────────────────
# Tool dispatch
# ─────────────────────────────────────────────────────────────────────────────


def _forward_tool_call(
    creds: credentials.Credentials,
    tool_name: str,
    arguments: dict,
    mode: str,
    repo_url: str | None,
) -> dict:
    """Forward a `tools/call` to the cloud handler. Returns the parsed
    `result.content[0].text` JSON dict (the actual tool response shape)
    — or {"error": ...} if the cloud returned a JSON-RPC error."""
    payload = {
        "jsonrpc": "2.0",
        "id": _next_rpc_id(),
        "method": "tools/call",
        "params": {"name": tool_name, "arguments": arguments},
    }
    try:
        resp = rpc_client.post(creds, payload, mode=mode, repo_url=repo_url)
    except rpc_client.RpcError as e:
        return {
            "error": f"cloud MCP returned HTTP {e.status}",
            "detail": e.body[:500],
        }
    except Exception as e:  # noqa: BLE001
        return {"error": f"failed to reach cloud MCP: {type(e).__name__}: {e}"}

    if not isinstance(resp, dict):
        return {"error": "cloud MCP returned no response body"}

    if "error" in resp:
        err = resp["error"] or {}
        return {
            "error": err.get("message", "unknown JSON-RPC error"),
            "code": err.get("code"),
        }

    result = resp.get("result") or {}
    contents = result.get("content") or []
    if not contents:
        return {"error": "cloud MCP returned empty content"}

    text = contents[0].get("text") if isinstance(contents[0], dict) else None
    if not isinstance(text, str):
        return {"error": "cloud MCP returned non-text content"}

    try:
        return json.loads(text)
    except json.JSONDecodeError as e:
        return {"error": f"cloud MCP returned invalid JSON: {e}", "raw": text[:500]}


def _dispatch_local_architect_tool(
    repo_path: Path,
    name: str,
    arguments: dict,
) -> dict:
    """Run an architect-mode local tool against the workspace. These tools
    contain no IP — they edit archrails.yml or shell out to `calm validate`.
    """
    # Lazy import: we don't want the local graph_loader (which imports
    # archrails_mcp._config) loaded for code-mode-only sessions.
    from archrails_mcp.graph_loader import load_graph
    from archrails_mcp.tools import bind_path, validate_architecture

    try:
        graph = load_graph(repo_path)
    except FileNotFoundError as e:
        return {"error": f"could not load workspace: {e}"}

    if name == "validate_architecture":
        return validate_architecture.run(graph)
    if name == "bind_path":
        return bind_path.run(graph, **arguments)
    return {"error": f"unknown architect-mode tool: {name}"}


def _handle_check_local_diff(
    creds: credentials.Credentials,
    repo_path: Path,
    arguments: dict,
    mode: str,
    repo_url: str | None,
) -> dict:
    """Inject `unified_diff` from `git diff HEAD` before forwarding."""
    scope_paths = arguments.get("scope_paths") or None
    try:
        unified_diff = diff_reader.read_workspace_diff(repo_path, scope_paths=scope_paths)
    except diff_reader.DiffReadError as e:
        return {"error": str(e)}

    forward_args = {"unified_diff": unified_diff}
    if scope_paths:
        forward_args["scope_paths"] = scope_paths
    return _forward_tool_call(creds, "check_local_diff", forward_args, mode, repo_url)


# ─────────────────────────────────────────────────────────────────────────────
# Build / serve
# ─────────────────────────────────────────────────────────────────────────────


def build_app(
    repo_path: Path,
    mode: str = "code",
    repo_url_override: str | None = None,
) -> Server:
    """Construct the MCP Server for stdio. Fetches the agent instructions
    + tool manifest from the cloud BEFORE constructing the Server so the
    initialize-response sent to the IDE includes the cloud-served
    instructions. The tool list returned to the IDE on `tools/list` is
    served from the same cached manifest.

    No instructions or tool descriptions are baked into this CLI. If the
    cloud is unreachable at startup, we serve a minimal fallback that
    advertises zero tools and tells the agent ArchRails is unreachable.

    Repo URL resolution (sent to the cloud as X-Archrails-Repo-URL on
    every request, used to pick which graph to load for tenant-scoped
    keys):
      1. `repo_url_override` explicit arg (CLI `--repo-url`, env var
         `ARCHRAILS_REPO_URL`). Use this when the workspace's git
         remote points at the wrong place — forks, mirrors, multi-
         remote setups, OR when you want to pin the URL in your IDE
         config so it's immune to which folder Cursor inherits at
         launch.
      2. Otherwise `git remote get-url origin` on `repo_path`.
      3. If both fail, send no header — the cloud will return an
         actionable error on the first tool call.
    """
    creds = credentials.load()

    if repo_url_override:
        repo_url: str | None = repo_url_override
        print(
            f"[archrails-mcp] repo URL override: {repo_url}",
            file=__import__("sys").stderr,
        )
    else:
        repo_url = git_remote.read_origin_url(repo_path)
        if repo_url is None:
            # Not a git repo, no `origin`, or git is missing. Tenant-
            # scoped keys will fail at the cloud's repo-resolution step
            # with a clear error message; repo-scoped keys still work.
            print(
                f"[archrails-mcp] no git origin remote at {repo_path} — "
                "tenant-scoped MCP keys will fail to resolve a repo. "
                "Either: (a) `cd` to a workspace with the right `origin` "
                "remote and restart, (b) start with `--repo-url <url>` "
                "to pin it explicitly, or (c) use a repo-scoped key.",
                file=__import__("sys").stderr,
            )
    manifest = _fetch_manifest(creds, mode, repo_url)

    tools = _tools_from_manifest(manifest)
    visible_names = {t.name for t in tools}

    app: Server = Server(
        "archrails-mcp",
        instructions=manifest.get("instructions") or "",
    )

    @app.list_tools()
    async def list_tools() -> list[Tool]:
        return tools

    @app.call_tool()
    async def call_tool(name: str, arguments: dict) -> list[TextContent]:
        if name not in visible_names:
            result: dict[str, Any] = {
                "error": f"tool {name!r} is not available in this session",
                "available_tools": sorted(visible_names),
                "hint": (
                    "If ArchRails reported 'unreachable' at startup, run "
                    "`archrails login` and restart this MCP server. To "
                    "switch between code and architect modes, restart "
                    "with the right `--mode` flag."
                ),
            }
        elif name in _LOCAL_DISPATCH_TOOL_NAMES:
            # bind_path / validate_architecture — run locally against
            # the workspace. No IP involved (text surgery / FINOS CLI
            # wrapper).
            result = _dispatch_local_architect_tool(repo_path, name, arguments)
        elif name == "check_local_diff":
            if creds is None:
                result = {"error": "no credentials cached — run `archrails login`"}
            else:
                result = _handle_check_local_diff(creds, repo_path, arguments, mode, repo_url)
        else:
            # All other tools forward to the cloud handler.
            if creds is None:
                result = {"error": "no credentials cached — run `archrails login`"}
            else:
                result = _forward_tool_call(creds, name, arguments, mode, repo_url)

        return [TextContent(type="text", text=json.dumps(result, indent=2))]

    return app


async def main_async(
    repo_path: Path,
    mode: str = "code",
    repo_url_override: str | None = None,
) -> None:
    app = build_app(repo_path, mode=mode, repo_url_override=repo_url_override)
    async with stdio_server() as (read_stream, write_stream):
        await app.run(read_stream, write_stream, app.create_initialization_options())
