'''Descriptors

Functions that are file descriptors.

Theese are the functions to use in the map method of Dlist

The original functions returns a dict or a value.

The decorator gives the maps list structure.
'''

import sys
import filetype
import time
import hashlib
from PIL import Image
import ffmpeg
import subprocess

def outFmt(func):
    '''Decorator for outputs
    '''
    def wrapper(*args, **kwargs):
        return [func(*args, **kwargs)]
    wrapper.__name__ = func.__name__
    return wrapper

def timeStamp():
    """returns a timestamp string

    Internal function used in hash.
    """
    return time.strftime("%Y-%m-%d_%H:%M:%S", time.localtime())

@outFmt
def hash(fname):
    """Calculates hash with sha3_256

    Args:
        fname (str): full pathname

    .. note::

        equivalent to linux command
        ``rhash --sha3-256 filename``

    """

    BLOCK_SIZE = 1048576

    file_hash = hashlib.sha3_256() 

    with open(fname, 'rb') as f: 
        fb = f.read(BLOCK_SIZE) 
        while len(fb) > 0: 
            file_hash.update(fb) 
            fb = f.read(BLOCK_SIZE) 

    return {'timeStamp': timeStamp(),
            'value': file_hash.hexdigest()}

def mtype(fname):
    """Mime type of file

    Args:
        fname (str): full pathname

    Returns:
        {ext, mime, type}: normal extention+mimetype

    On error gives all values to ''
    """

    kind = filetype.guess(fname)
    if kind is None:
        ext = fname.split('.')[-1]
        #check if video
        if ext.lower() in ['mp4','avi','mov','mkv']:
            return {'ext':ext, 
                    'mime':'',
                    'type':'video'}
        else:
            #print('Cannot guess file type!')
            return {'ext':ext, 
                    'mime':'',
                    'type':''}

    return {'ext':kind.extension, 
            'mime':kind.mime,
            'type':kind.mime.split('/')[0]}

@outFmt
def imgInfo(fname):
    """Image Formatclear

    Args:
        fname (str): full pathname

    Returns:
        format (str):   JPEG, BMP, GIF...
        size   (tuple):  (W, H)
        mode   (str):   bands: RGB, CMYK, HSV...

    .. note:: `Formats availables <https://pillow.readthedocs.io/en/latest/handbook/image-file-formats.html>`_

       BMP, DIB, EPS, GIF, ICNS, ICO, IM, JPEG, JPEG 2000, MSP,
       PCX, PNG, PPM, SGI, SPIDER, TGA, TIFF, WebP, XBM.

    .. note:: `Modes availables <https://pillow.readthedocs.io/en/latest/handbook/concepts.html#modes>`_
    
       1, L, P, RGB, RGBA, CMYK, YCbCr, LAB, HSV, I, F
       
    """
    try:
        with Image.open(fname) as im:
            #print(im.format, f"{im.size}x{im.mode}")
            return {'format':im.format,
                    'size'  :f'{im.size[0]}x{im.size[1]}',
                    'width' :str(im.size[0]),
                    'height':str(im.size[1]),
                    'mode'  :im.mode
                   }
    except OSError:
        pass

    return ''

@outFmt
def sndInfo(fname):
    """Audio Format

    Args:
        fname (str): full pathname

    Returns:
        format (str):   JPEG, BMP, GIF...
        size   (tuple):  (W, H)
        mode   (str):   bands: RGB, CMYK, HSV...

    Based on linux command ``soxi`` 

    .. note:: Install for extra formats

        $ sudo apt install libsox-fmt-all
       
    .. note:: Formats supported

        8svx aif aifc aiff aiffc al amb amr-nb amr-wb anb au avr awb 
        caf cdda cdr cvs cvsd cvu dat dvms f32 f4 f64 f8 fap flac fssd 
        gsm gsrt hcom htk ima ircam la lpc lpc10 lu mat mat4 mat5 maud 
        mp2 mp3 nist ogg paf prc pvf raw s1 s16 s2 s24 s3 s32 s4 s8 sb 
        sd2 sds sf sl sln smp snd sndfile sndr sndt sou sox sph sw txw 
        u1 u16 u2 u24 u3 u32 u4 u8 ub ul uw vms voc vorbis vox w64 wav 
        wavpcm wv wve xa xi
    """
    result = subprocess.run(['soxi', fname],
                            stdout=subprocess.PIPE).stdout.decode('utf-8')
    
    if 'FAIL' in result:
        return ''

    out = {}
    for line in result.split('\n'):
        sep = line.find(':')
        key = line[:sep].strip()
        key = key.replace('_','-').replace(' ','')
        if key in ['', 'InputFile']: continue
        if key=='SampleRate': key = 'Rate'
        if key=='SampleEncoding': key = 'Encoding'
        key = key.lower()
        if key =='comments': break

        val = line[sep+1:].strip()
        if key == 'duration':
            vals = val.split('=')
            out['duration'] = vals[0].strip()
            out['samples'] = vals[1].replace('samples','').strip()
        else:    
            out[key]=val

    return out

@outFmt
def vidInfo(fname):
    #ffmpeg.probe(fname, cmd='ffprobe', **kwargs)
    result = ffmpeg.probe(fname, cmd='ffprobe')

    if result !='[]':  #mejorar esto
        out = {'streams':{}}
        for st in result['streams']:
            out['streams'][f'stream-{str(st["index"]).strip()}'] = st
        
        for key in result:
            if key != 'streams':
                out[key] = result[key]

        return out
    else:
        return ''

@outFmt
def exif(fname):
    result = subprocess.run(['exiftool', fname],
                             stdout=subprocess.PIPE).stdout.decode('utf-8')

    out = {}
    for line in result.split('\n'):
        sep = line.find(':')
        key = line[:sep].strip()
        if key=='': continue
        key = key.replace('_','-').replace(' ','')
        val = line[sep+1:].strip()
        out[key]=val
    return out

def printDict(d,indent=0):
    if isinstance(d,list):
        d = d[0]
    for k,v in d.items():
        if isinstance(v,dict):
            print(' '*indent + f'  {k} =')
            printDict(v, indent=indent+3)
        else:
            print(' '*indent + f'  {k:<10} : {v}')

def main(fname):

    #fname = '/home/willy/Downloads/DSC_5007.pdf'
    #fname = '/home/willy/Pictures/DSC_4951.JPG'
    #fname = '/home/willy/Videos/DSC_5007.AVI'
    #fname = '/home/willy/Music/test.mp3'

    print(f'\n{fname.split("/")[-1]}')

    print('hash')
    printDict(hash(fname))

    print('mime')
    printDict(mtype(fname))

    if   mtype(fname)['type']=='image':
        print('Image Info')
        printDict(imgInfo(fname))
    elif mtype(fname)['type']=='video':
        print('Video Info')
        printDict(vidInfo(fname))
    elif mtype(fname)['type']=='audio':
        print('Audio Info')
        printDict(sndInfo(fname))

    print('Exif')
    printDict(exif(fname))

if __name__ == '__main__':
    sys.exit(main(sys.argv[1:2]))
