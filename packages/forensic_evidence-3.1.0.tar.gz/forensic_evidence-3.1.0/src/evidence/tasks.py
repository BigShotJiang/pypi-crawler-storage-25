"""Task registry for the Evidence queue system.

Tasks are Python functions registered by name. The queue runner
looks up tasks by name and calls them with the file path.

Built-in tasks wrap the descriptor functions from :mod:`evidence.descriptors`.

To register a custom task::

    from evidence.tasks import task

    @task('my_analysis')
    def my_analysis(file_path):
        # ... process file ...
        return {'key': 'value'}
"""

REGISTRY = {}


def task(name):
    """Decorator to register a queue task by name.

    Parameters:
        name (str): unique task name used in queue manifest

    Returns:
        decorator that registers the function
    """
    def wrapper(fn):
        REGISTRY[name] = fn
        return fn
    return wrapper


# ─── Built-in tasks ─────────────────────────────────────────────────

@task('exif')
def _exif_task(file_path):
    """Extract EXIF metadata via exiftool."""
    from . import descriptors as fdesc
    result = fdesc.exif(file_path)
    # exif returns [dict] due to @outFmt decorator
    return result[0] if isinstance(result, list) and len(result) == 1 else result


@task('snd_info')
def _snd_info_task(file_path):
    """Extract audio metadata via soxi."""
    from . import descriptors as fdesc
    result = fdesc.sndInfo(file_path)
    return result[0] if isinstance(result, list) and len(result) == 1 else result


@task('img_info')
def _img_info_task(file_path):
    """Extract image metadata via Pillow."""
    from . import descriptors as fdesc
    result = fdesc.imgInfo(file_path)
    return result[0] if isinstance(result, list) and len(result) == 1 else result


@task('vid_info')
def _vid_info_task(file_path):
    """Extract video metadata via ffprobe."""
    from . import descriptors as fdesc
    result = fdesc.vidInfo(file_path)
    return result[0] if isinstance(result, list) and len(result) == 1 else result


@task('hash')
def _hash_task(file_path):
    """Calculate SHA3-256 hash."""
    from . import descriptors as fdesc
    result = fdesc.hash(file_path)
    return result[0] if isinstance(result, list) and len(result) == 1 else result
