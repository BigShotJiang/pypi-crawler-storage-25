"""Evidence main object

Evidence instantiates a Dlist with the file information of the 
``dataPath`` init variable.

In that path, creates a hidden directory ``.evidence`` where will 
store, save and backup the processing information.

Exports the methods are :meth:`~evidence.Evidence.save` and :meth:`~evidence.Evidence.idf`, and 
is important to understand the :meth:`~evidence.Evidence.__init__` options.
"""

import os
import shutil
from os.path import exists
from glob import glob
import json
import time
from pathlib import Path
import fnmatch
from enum import IntEnum

from dlist import Dlist
from dlist.helpers import getDitem
from . import descriptors as fdesc
from .filename import Filename
from .config import load_config

# Load paths from configuration
_profile, _evidence_paths, _data_path = load_config()
EVIDENCE = _evidence_paths[0]
DATAPATH = _data_path

# Modes
class Mode(IntEnum):
    DEFAULT = 0
    SCAN    = 1
    LOAD    = 2
    ZERO    = 3
    RESCAN  = 4

verb = False

class Evidence(Dlist):
    '''Evidence class

    Dlist object with extra methods for load, scan, save and backup
    '''
    # format id
    digi = 4
    fmtStr = f"E{{:0{digi:d}d}}"
    
    def __init__(self, mode=Mode.DEFAULT, files=[], duplicates=False):
        '''Init Evidence

        Parameters:
            dataPath (str): full root path of data
            mode (int, declared): open mode
            files (list): list of files for LOAD mode
            duplicates (bool): if True, loads entries marked with duplicateof field

        *dataPath*: if not provided, reads value from ``~/.evidence.conf`` file

        *mode* values:

        * SCAN   (default if no previous register): reads all files and erases previous information.
        * LOAD   (default if previous register): reads previous information
        * ZERO   inits with no data
        * RESCAN reads only new files 

        *files* list:

        * if ``files=[]`` (default) loads all *.json* files
        * ``files.json`` is imported even if omitted
        * file names can be written without extension
        * if a file doesnt exits, silently continues
        
        *duplicates*:
        
        * if ``False`` (default): skips entries with ``duplicateof`` field
        * if ``True``: loads all entries including duplicates
        '''

        self.id = 'id'
        self.evidence_path = EVIDENCE
        self.data_path = DATAPATH
        self.saveFiles = True
        self.loadDuplicates = duplicates
        
        # Error
        if not EVIDENCE.exists():
            print(f'Evidence Error: {str(EVIDENCE)} must exist.')
            return
        if not DATAPATH.exists():
            print(f'Evidence Error: {str(DATAPATH)} must exist.')
            return
        
        self.ePath   = DATAPATH / 'database'
        self.files   = self.ePath  / 'files.json'

        # No data files
        if not self.ePath.exists():
            self.ePath.mkdir()
            mode = Mode.SCAN
        elif not self.files.exists():     
            mode = Mode.SCAN

        # Profile to load
        print(f"Profile: {_profile}")

        # Default 
        if mode==Mode.DEFAULT:
            mode = Mode.LOAD

        # modes
        if mode==Mode.SCAN:
            print('mode   : SCAN')
            self.scan()

        elif mode==Mode.LOAD:
            print('mode   : LOAD')
            self.load(files=files, duplicates=duplicates)

        elif mode==Mode.ZERO:
            print('mode   : ZERO')
            self.zero()
        elif mode==Mode.RESCAN:
            print('mode   : RESCAN')
            self.rescan()

        # Check for pending queue jobs
        self._print_queue_status()

    def _print_queue_status(self):
        '''Print a one-line summary of pending queue jobs, if any.'''
        try:
            from .queue import read_manifest
            manifest = read_manifest(self.data_path)
            pending = [e for e in manifest if e.get('status') != 'done']
            if pending:
                total_files = sum(e.get('file_count', 0) for e in pending)
                print(f'Queue  : {len(pending)} pending commands '
                      f'({total_files} files) — run: evidence-queue launch')
            else:
                print('Queue  : no pending commands')
        except Exception:
            pass

    ###############################################
    ### Modes

    def scan(self,  listofFiles=[]):
        '''Makes the list of files from EVIDENCE

        * omits hidden files
        * assigns ``id``
        * makes a backup
        * erases all data in ``-evidencce``
        * saves
        '''

        print('SCAN Files...', end='')
        # Init Dlist from disk
        super().__init__(self.readFromDisk(listofFiles=listofFiles), self.id)

        # Mark Evidence E:evidence A:archive
        self[self.filter(file__mime__type='audio')] = {'type':'E'}
        self[self.filter(file__mime__type='image')] = {'type':'E'}
        self[self.filter(file__mime__type='video')] = {'type':'E'}
        self[self.filter(type=False)] = {'type':'A'}

        # Renums
        ies = {'E':1, 'A':1}
        for i in range(len(self)):
            typ = self[i]['type'][0]
            self[i][self.id] = self.mkid(typ, ies[typ])
            ies[typ] += 1

        print(f' {len(self)} files.')
        print(f"   {len(self.filter(file__mime__type='audio')):3d} audios")
        print(f"   {len(self.filter(file__mime__type='image')):3d} images")
        print(f"   {len(self.filter(file__mime__type='video')):3d} videos")

        print()
        print('DISCOS')
        #   categoría dir0
        for d in self:
            self[d['id']] = {'cat':{'disk':d['file']['dir0']}}

        print()
        print('Saving...', end='')
        if listofFiles==[]:
            # Write Files (Backup and erase files)
            self.save(wipe=True)    
        print('done.')

        # Queue slow tasks for background processing
        print()
        self.queue('exif',     inputL=['file__pathName'], outputL=['exif'],
                   query={'type': 'E'})
        self.queue('snd_info', inputL=['file__pathName'], outputL=['format'],
                   query={'file__mime__type': 'audio'})
        self.queue('img_info', inputL=['file__pathName'], outputL=['format'],
                   query={'file__mime__type': 'image'})
        self.queue('vid_info', inputL=['file__pathName'], outputL=['format'],
                   query={'file__mime__type': 'video'})
        self.queue('hash',     inputL=['file__pathName'], outputL=['hash'])

    def _load_legacy(self, files=[], duplicates=None):
        '''Legacy loader: reads JSON files and merges via Dlist.assign

        Kept for reference. Replaced by :meth:`load` (DuckDB-based).

        Parameters:
            file (list): list of files to load
            duplicates (bool): if True, loads entries with duplicateof field

        * if ``files=[]`` (default) loads all *.json files
        * ``files.json`` is imported even if omited
        * file names can be written without extension
        * if a file doesnt exits, silently continues
        * entries with ``duplicateof`` field are skipped unless duplicates=True

        Example of use::

            >>> import evidence as ev
            >>> dl = ev.Evidence('myPath', ev.LOAD, files=['msgs'])

            # this imports the information in 
            # `files.json` and `msgs.json` if they exists
            # The internal structure of dict will be:

            dl.l[item] = {'id':'E0042', 'file':{...}, 'msg':...}

        '''

        # Use instance setting if not explicitly provided
        if duplicates is None:
            duplicates = self.loadDuplicates
        
        # Always loads files.json
        with open(self.files,'r') as f:
            data = json.load(f)
            # Filter out duplicates unless duplicates=True
            if not duplicates:
                data = [item for item in data if 'duplicateof' not in item]
            super().__init__(data, self.id)
        #   complete filePath
        for item in self.l:
            item['file']['pathName'] = str(EVIDENCE) + item['file']['fn']

        # Available files (basenames)
        avfiles = glob(str(self.ePath)+'/*.json')
        avfiles = list(map(lambda x: x.split('/')[-1], avfiles))

        # List of files to load (supports glob patterns)
        if files == []:
            files_to_load = avfiles
        else:
            # Normalize requested patterns to end with .json
            patterns = []
            for f in files:
                if not f.endswith('.json'):
                    f = f + '.json'
                patterns.append(f)

            files_to_load = []
            for pat in patterns:
                # If pattern contains glob wildcards, expand against available files
                if any(ch in pat for ch in ['*', '?', '[', ']']):
                    matches = fnmatch.filter(avfiles, pat)
                    for m in matches:
                        if m not in files_to_load:
                            files_to_load.append(m)
                else:
                    if pat in avfiles and pat not in files_to_load:
                        files_to_load.append(pat)

        if 'files.json' in files_to_load:
            files_to_load.remove('files.json')

        for fi in files_to_load:
            with open(str(self.ePath)+'/'+fi,'r') as f:
                di = json.load(f)

            # loads in Dlist
            for d in di:
                ID = d[self.id]
                # Skip if ID was filtered out (duplicate)
                try:
                    d.pop(self.id)
                    self[ID] = d
                except ValueError:
                    # ID not in dlist (was filtered as duplicate)
                    pass

    def load(self, files=[], duplicates=None):
        '''Loads information from previous session using DuckDB

        Delegates to :meth:`Dlist.read_pivot` for the heavy lifting,
        then applies Evidence-specific post-processing (duplicate
        filtering and pathName completion).

        Parameters:
            files (list): list of files to load
            duplicates (bool): if True, loads entries with duplicateof field

        * if ``files=[]`` (default) loads all *.json files
        * ``files.json`` is imported even if omited
        * file names can be written without extension
        * if a file doesnt exits, silently continues
        * entries with ``duplicateof`` field are skipped unless duplicates=True

        Example of use::

            >>> import evidence as ev
            >>> dl = ev.Evidence('myPath', ev.LOAD, files=['msgs'])

            # this imports the information in 
            # `files.json` and `msgs.json` if they exists
            # The internal structure of dict will be:

            dl.l[item] = {'id':'E0042', 'file':{...}, 'msg':...}

        '''
        if duplicates is None:
            duplicates = self.loadDuplicates

        # Available JSON files
        avfiles = glob(str(self.ePath)+'/*.json')
        avfiles = list(map(lambda x: x.split('/')[-1], avfiles))

        # Resolve which files to load
        if files == []:
            files_to_load = avfiles[:]
        else:
            patterns = []
            for f in files:
                if not f.endswith('.json'):
                    f = f + '.json'
                patterns.append(f)
            files_to_load = []
            for pat in patterns:
                if any(ch in pat for ch in ['*', '?', '[', ']']):
                    matches = fnmatch.filter(avfiles, pat)
                    for m in matches:
                        if m not in files_to_load:
                            files_to_load.append(m)
                else:
                    if pat in avfiles and pat not in files_to_load:
                        files_to_load.append(pat)

        # files.json is always included
        if 'files.json' not in files_to_load:
            files_to_load.insert(0, 'files.json')

        # Build {filepath: key_name} mapping for read_pivot
        pivot_files = {}
        for fname in files_to_load:
            fpath = str(self.ePath / fname)
            key_name = fname.replace('.json', '')
            # files.json nests under 'file', types.json under 'type', etc.
            # Convention: strip trailing 's' for the key name
            if key_name.endswith('s') and key_name != 'files':
                key_name = key_name[:-1]
            elif key_name == 'files':
                key_name = 'file'
            pivot_files[fpath] = key_name

        base_path = str(self.ePath / 'files.json')
        result = Dlist.read_pivot(pivot_files, pivot=self.id, base=base_path)

        # Filter duplicates
        if not duplicates:
            result.l = [item for item in result.l if 'duplicateof' not in item]

        super().__init__(result.l, self.id)

        # Complete filePath
        for item in self.l:
            if 'file' in item:
                item['file']['pathName'] = str(EVIDENCE) + item['file']['fn']

    def zero(self):
        '''Inits empty evidence object

        * makes a backup
        * erases data area
        '''

        # Init empty Dlist
        super().__init__([], self.id)
        # Backup and erase files
        self.backup(wipe=True)
        # Write Files
        self.save()    

    def rescan(self):
        '''Adds new files found on disk to the existing database

        * loads current data
        * walks the evidence directory for all files
        * detects files not yet registered (by pathName)
        * assigns type (E/A), cat__disk, exif, and media info to new files
        * saves
        '''

        # Load existing data
        self.load()

        # Read all files from disk
        all_files = Dlist(self.readFromDisk())

        # Already loaded pathNames
        loaded = set(self.vals('file__pathName'))

        # Collect new files
        new_items = [d for d in all_files
                     if getDitem(d, 'file__pathName', charSep=self.charSep) not in loaded]

        if not new_items:
            print('No new files found.')
            return

        # Build a temporary Dlist for the new files
        new = Dlist(new_items, self.id)

        # Mark type E:evidence A:archive
        new[new.filter(file__mime__type='audio')] = {'type': 'E'}
        new[new.filter(file__mime__type='image')] = {'type': 'E'}
        new[new.filter(file__mime__type='video')] = {'type': 'E'}
        new[new.filter(type=False)] = {'type': 'A'}

        # Assign IDs continuing from the current max
        Emax = max(int(v[1:]) for v in self.vals(self.id))
        for i in range(len(new)):
            Emax += 1
            typ = new[i]['type'][0]
            new[i][self.id] = self.mkid(typ, Emax)

        # cat__disk
        for d in new:
            new[d['id']] = {'cat': {'disk': d['file']['dir0']}}

        print(f'{len(new)} new files added.')

        # Merge into self and save
        self.l.extend(new.l)
        self.save()

        # Queue slow tasks for new files
        print()
        self.queue('exif',     inputL=['file__pathName'], outputL=['exif'],
                   query={'type': 'E'})
        self.queue('snd_info', inputL=['file__pathName'], outputL=['format'],
                   query={'file__mime__type': 'audio'})
        self.queue('img_info', inputL=['file__pathName'], outputL=['format'],
                   query={'file__mime__type': 'image'})
        self.queue('vid_info', inputL=['file__pathName'], outputL=['format'],
                   query={'file__mime__type': 'video'})
        self.queue('hash',     inputL=['file__pathName'], outputL=['hash'])

    def load_xtras(self, verb=False):
        '''External method to load extra data in DATAPATH
        '''

        def xtras(file_fn):
            fil = Filename(file_fn[1:], typ='ev', db=False,
                          evidence_path=EVIDENCE, data_path=DATAPATH,
                          ev_instance=self)
            out = fil.xtras()
            return out

        for i,dic in enumerate(self):
            x = xtras(self[i]['file']['fn'])
            if len(x)!=0:
                self[i] = {'xtras': x}
            else:
                self[i].pop('xtras', None)
            

    ###############################################
    ### Read an Save
    
    def readFromDisk(self, listofFiles=[]):
        '''Read list of files from disk

        Scans subdirectories. Omits hidden pathnames
        Returns a list of dictionaries with {'id':id, 'file':{...}}
        if listofFiles is given, only reads that files, if exists
        '''

        dataPath = str(EVIDENCE)

        if listofFiles ==[]:
            dat = os.walk(dataPath,followlinks=True)
            fl = []
            for item in dat:
                paths, dirs, files = item
                if len(files)!=0:
                    # dir without dataPath
                    dire = (paths+'/')[len(dataPath):] ## dir sin raíz
                    # No hidden directories
                    if not '/.' in paths:
                        for fi in sorted(files):
                            # No hidden files
                            if not fi.startswith('.'):
                                fl.append([dire,fi]) ## unsorted list of dir/files
        else:
            fl = []
            for item in listofFiles:
                fname = dataPath+'/'+item
                if exists(fname):
                    fi = fname.split('/')[-1]
                    dire = fname[len(dataPath):-len(fi)]
                    fl.append([dire,fi])
        
        ### Set Evidence number
        fl = sorted(fl,key = lambda x: (x[0],x[1]))
        fList = []
        iEv = 0
        for item in fl:
            dire,it  = item
            iEv +=1
            fList.append([self.fmtStr.format(iEv), dire, it])
            
        dl = self.fileAttr(fList)  
        return dl

    def save(self, wipe=False):
        '''Saves evidence data to '*.json' files
    
        * makes a backup
        * cleans previous ``.json`` files
        * saves each key in evdence in a different file (excapting ID, xtras, duplicateof)
        * ``duplicateof`` field is saved in ``files.json`` to prevent loading duplicates

        Example::

            >>> import evidence as ev
            >>> dl = ev.Evidence('myPath')

            # with this structure:

            dl.l[item] = {'id':'E0042', 'file':{...}, 'msg':...}

            # creates `files.json` and `msgs.json`
        '''

        # check if data to save
        if len(self.l)==0 or not self.saveFiles:
            return

        # backup
        self.backup(wipe=wipe)

        # cleans data saved
        avfiles = glob(str(self.ePath)+'/*.json')
        for fil in avfiles:
            os.remove(fil)

        ### Files to save 
        ks = self.keys()
        for ki in ks:
            if ki not in [self.id, 'xtras', 'duplicateof']:
                # file de salida
                fout = f'{self.ePath}/{ki}s.json'
                # subdict
                dout = self.filter(**{f'{ki}':True})
                out  = []
                for d in dout.l:
                    item = {'id':d['id'], ki:d[ki]}
                    # clean pathName and add duplicateof if in files
                    if Path(fout).stem == 'files':
                        item['file'].pop('pathName', None)
                        # Add duplicateof field if present
                        if 'duplicateof' in d:
                            item['duplicateof'] = d['duplicateof']
                    out.append(item)
 
                with open(fout,'w') as f:
                    json.dump(out, f, indent='   ') 

    def backup(self, wipe=False):
        '''Backups data 

        * copies all data in ``DATAPATH/backup`` in a zip file
        * filename of backup is a timestamp in directory `backup`
        * if ``wipe=True`` erases all data
        '''

        backupPath = '/backup/'
        ePath = self.ePath
        
        # list of files
        dat = os.walk(ePath,followlinks=True)
        fl  = [] # list of files
        df0 = [] # root dir,files
        for item in dat:
            paths, dirs, files = item
            if df0==[]:
                df0 = [dirs,files]
            if len(files)!=0: 
                # dir without ePath
                dire = (paths+'/')[len(str(ePath)):] ## dir sin raíz
                for fi in files:
                    if not dire.startswith(backupPath):
                        fl.append(dire+fi) ## list of dir/files

        # check if there is something to backup
        if len(fl)==0:
            return

        # check if backup Dir exists
        if not exists(str(ePath)+backupPath[:-1]):
            os.mkdir(str(ePath)+backupPath[:-1])

        # fileName
        bfN = time.strftime("%Y-%m-%d_%H:%M:%S", time.localtime())

        #zip
        #- copy to tmp dir
        bktmp = str(ePath)+backupPath+'tmp'
        if exists(bktmp):
            shutil.rmtree(bktmp)
        shutil.copytree(str(ePath), 
                        bktmp, 
                        ignore=shutil.ignore_patterns('backup'))
        #- make archive
        shutil.make_archive(str(ePath)+backupPath+bfN,
                            'zip',
                            bktmp)
        #- delete temp
        shutil.rmtree(bktmp)

        # erase files
        if wipe:
            ds,fs = df0
            for f in fs:
                os.remove(str(ePath)+'/'+f)
            for d in ds:
                if d != backupPath[1:-1]:                    
                    shutil.rmtree(str(ePath)+'/'+d)
                    pass

    ###############################################
    ### Utils

    def idf(self, s):
        '''Look up an entry by ID string.

        Returns the dictionary for the matched entry, or None.

        ``s`` can be:

        - a number: ``42`` → E0042
        - a string: ``"e42"`` → E0042
        - custom prefix: ``"c3"`` → C0003

        Uses :func:`evidence.idf.parse_id` for parsing.
        '''
        from .idf import parse_id

        parsed = parse_id(s)
        if parsed is None:
            print('Evidence idf: cannot parse input')
            return None

        if parsed.prefix in ("E", "A"):
            try:
                return self[parsed.full_id]
            except (ValueError, KeyError, IndexError):
                print(f'Evidence idf: {parsed.full_id} not found')
                return None
        else:
            id_key = f"id{parsed.prefix.lower()}"
            result = self.filter(**{id_key: parsed.full_id})

            if len(result) == 0:
                # Try shorter format (e.g. C003 instead of C0003)
                short_id = parsed.full_id[0] + parsed.full_id[2:]
                result = self.filter(**{id_key: short_id})

            if len(result) > 0:
                return result[0]

            print(f'Evidence idf: {parsed.full_id} not found')
            return None

    def fileAttr(self,ls):
        '''Dictionary of file Attributes

        Parameters:
            ls (list): [ [ID1, dir1, file1], ...]

        Returns:
            list of dictionaries

        =================  ===============================
        key                description
        =================  ===============================
        ``id``
        ``file__pathName``  dataPath/dire/fileName   <-- Este valor no se salva en disco
        ``dir0``                    dire = /dire0/dire1/...
        ``file__fn``                /dire/fileName
        ``file__dir``               /dire/
        ``file__fil``                     fileName
        ``file__ext``                       file extention
        ``file__ev``        (bool) ID starts with E
        =================  ===============================

        '''

        lsou = []
        for ID,dire,fn in ls:
            #fn = dire+fn
            if ID!='':
                if dire == '/':
                    dir0 = ''
                else:
                    dir0 = dire[1: dire.index('/',1)] 

                fN  = dire + fn
                fil = fn
                ext = fn.split('.')[-1]
                pathName = str(EVIDENCE) + dire + fn
                dic = {'pathName':pathName,  # dataPath/dire/fileName
                       'fn'  :fN,             #          dire/fileName
                       'dir' :dire,           #          dire
                       'dir0': dir0,
                       'fil' :fil,            #          fileName
                       'ext' :ext,            #          file extention
                       }
                mime = fdesc.mtype(pathName)
                if mime != '':
                    dic['mime'] = mime
                lsou.append({'id':ID, 'file':dic})
                
        return lsou

    def mkid(self, ch,i):
        ch = ch[0].upper()

        return self.fmtStr.replace('E',ch).format(i)

    ###############################################
    ### Queue

    def queue(self, task_name, inputL=[], outputL=[], query={}):
        '''Add a task to the execution queue.

        Same interface as :meth:`Dlist.map` but does not execute.
        Creates job files in ``DATAPATH/queue/`` for later processing
        by ``evidence-queue launch``.

        Parameters:
            task_name (str): registered task name (see :mod:`evidence.tasks`)
            inputL (list): input keys
            outputL (list): output keys
            query (dict): filter query

        Returns:
            str: queue command ID (e.g. ``'Q001'``)
        '''
        from .queue import queue_task
        return queue_task(self, task_name, inputL, outputL, query or {})

    ###############################################
    ### Pretty Outputs
    def __str__(self):
        from .formatting import strFileEv
        return strFileEv(self)
