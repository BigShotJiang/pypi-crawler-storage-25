"""CLI command to build / rebuild the Evidence database.

Usage::

    evidence-build-database              # scan (first time) or load
    evidence-build-database scan         # full scan from disk
    evidence-build-database rescan       # add only new files
    evidence-build-database load         # load existing database
"""

import typer
from rich.console import Console

console = Console()

app = typer.Typer(
    help="Build or rebuild the Evidence database.",
    invoke_without_command=True,
)


@app.callback(invoke_without_command=True)
def default(ctx: typer.Context):
    """Default: scan if no database exists, otherwise load."""
    if ctx.invoked_subcommand is not None:
        return
    from .main import Evidence, Mode
    console.print("[cyan]Building Evidence database (auto mode)...[/cyan]")
    ev = Evidence(mode=Mode.DEFAULT)
    console.print(f"[green]Done — {len(ev)} items.[/green]")


@app.command()
def scan():
    """Full scan: read all files from disk, assign IDs, and save."""
    from .main import Evidence, Mode
    console.print("[cyan]Full scan...[/cyan]")
    ev = Evidence(mode=Mode.SCAN)
    console.print(f"[green]Done — {len(ev)} items.[/green]")


@app.command()
def rescan():
    """Incremental scan: detect and add only new files."""
    from .main import Evidence, Mode
    console.print("[cyan]Rescan (incremental)...[/cyan]")
    ev = Evidence(mode=Mode.RESCAN)
    console.print(f"[green]Done — {len(ev)} items.[/green]")


@app.command()
def load():
    """Load existing database (verify it reads correctly)."""
    from .main import Evidence, Mode
    console.print("[cyan]Loading database...[/cyan]")
    ev = Evidence(mode=Mode.LOAD)
    console.print(f"[green]Done — {len(ev)} items.[/green]")
