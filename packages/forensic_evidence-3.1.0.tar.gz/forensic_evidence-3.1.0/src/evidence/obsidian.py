"""Obsidian vault builder for Evidence.

Generates a ready-to-use Obsidian vault from the Evidence database:
  - JPEG thumbnails for every image and video file
  - Markdown note per evidence item (card-friendly for Dataview / Kanban)

Usage::

    from evidence.obsidian import build
    build()              # uses active profile from env / config
"""

import os
import subprocess
import sys
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Optional
from urllib.parse import quote

from PIL import Image
from rich.console import Console
from rich.progress import Progress

from .config import load_config
from .main import Evidence, Mode

console = Console()

# ─── Thumbnail settings ────────────────────────────────────────────
THUMB_SIZE = (350, 350)
THUMB_EXT = ".jpg"           # JPEG: smaller files, good enough for cards
THUMB_QUALITY = 85


# ─── Helpers ────────────────────────────────────────────────────────

def _best_id(item: dict, db_path: Path) -> str:
    """Return the best ID for an evidence item (custom idx > Exxxx)."""
    from .fid import _lookup_custom_id
    eid = item["id"]
    custom = _lookup_custom_id(db_path, eid)
    return custom if custom else eid


def _placeholder_thumb(dst: Path) -> bool:
    """Generate a gray placeholder with crossed diagonals."""
    try:
        from PIL import ImageDraw
        w, h = THUMB_SIZE
        im = Image.new("RGB", (w, h), color=(80, 80, 80))
        draw = ImageDraw.Draw(im)
        draw.line([(0, 0), (w, h)], fill=(120, 120, 120), width=2)
        draw.line([(w, 0), (0, h)], fill=(120, 120, 120), width=2)
        im.save(dst, "JPEG", quality=THUMB_QUALITY)
        return True
    except Exception:
        return False


def _thumb_image(src: Path, dst: Path) -> bool:
    """Create a JPEG thumbnail from an image file."""
    try:
        with Image.open(src) as im:
            im.thumbnail(THUMB_SIZE)
            im = im.convert("RGB")
            im.save(dst, "JPEG", quality=THUMB_QUALITY)
        return True
    except Exception:
        return False


def _thumb_video(src: Path, dst: Path) -> bool:
    """Create a JPEG thumbnail from a video, picking a frame at ~10% duration.

    Falls back to 5 s if duration cannot be determined.
    """
    try:
        # Get duration via ffprobe
        probe = subprocess.run(
            ["ffprobe", "-v", "quiet", "-show_entries",
             "format=duration", "-of", "default=noprint_wrappers=1:nokey=1",
             str(src)],
            capture_output=True, text=True, timeout=15,
        )
        duration = float(probe.stdout.strip()) if probe.returncode == 0 else 0
        # Pick frame at 10 % of duration (min 2 s, max 30 s)
        seek = max(2, min(duration * 0.10, 30)) if duration > 4 else 0

        subprocess.run(
            ["ffmpeg", "-y", "-ss", str(seek), "-i", str(src),
             "-frames:v", "1", "-q:v", "5",
             "-vf", f"scale='min({THUMB_SIZE[0]},iw)':'min({THUMB_SIZE[1]},ih)':force_original_aspect_ratio=decrease",
             str(dst)],
            capture_output=True, timeout=30,
        )
        return dst.exists()
    except Exception:
        return False


def _make_thumb(src: str, dst: str, mime_type: str) -> bool:
    """Worker: create a thumbnail (called in a subprocess pool).

    Falls back to a gray placeholder with crossed diagonals if the
    real thumbnail cannot be created.
    """
    ok = False
    if mime_type == "image":
        ok = _thumb_image(Path(src), Path(dst))
    elif mime_type == "video":
        ok = _thumb_video(Path(src), Path(dst))
    if not ok:
        ok = _placeholder_thumb(Path(dst))
    return ok


def _portable_path(abs_path: str, evidence_root: str) -> str:
    """Return /~/relative path if under evidence root, else absolute."""
    root = evidence_root.rstrip("/")
    if abs_path.startswith(root + "/"):
        return "/~" + abs_path[len(root):]
    return abs_path


def _flat(v):
    """Collapse any embedded newlines so the value stays on one callout line."""
    return str(v).replace("\n", " ").strip()


def _render_value(lines, val, depth=0, callout_depth=999):
    """Recursively render a value into callout lines.

    The first *callout_depth* levels of nested dicts use collapsed
    callouts.  Deeper levels use nested blockquotes.

    Obsidian nested callout syntax::

        > [!warning]- outer        ← depth 0, prefix ">"
        >> [!warning]- inner       ← depth 1, prefix ">>"
        >>> **key:** value         ← depth 2, prefix ">>>"
    """
    bq = ">" * (depth + 1)  # prefix for content at this depth

    if isinstance(val, dict):
        first = True
        for k, v in val.items():
            if isinstance(v, (dict, list)) and depth < callout_depth:
                # Blank separator line to close previous sibling callout
                if not first:
                    lines.append(bq)
                first = False
                inner = ">" * (depth + 2)
                lines.append(f"{inner} [!warning]- {k}")
                _render_value(lines, v, depth + 1, callout_depth)
            elif isinstance(v, (dict, list)):
                lines.append(f"{bq} **{k}:**")
                _render_value(lines, v, depth + 1, callout_depth)
            else:
                first = False
                lines.append(f"{bq} **{k}:** {_flat(v)}")
    elif isinstance(val, list):
        for item in val:
            if isinstance(item, (dict, list)):
                _render_value(lines, item, depth, callout_depth)
            else:
                lines.append(f"{bq} - {_flat(item)}")
    else:
        lines.append(f"{bq} {_flat(val)}")


def _write_note(
    out_dir: Path,
    best_id: str,
    item: dict,
    evidence_root: Path,
    has_thumb: bool,
    cat_list_keys: set = frozenset(),
) -> None:
    """Write an Obsidian markdown note for one evidence item."""
    rel_fn = item.get("file", {}).get("fn", "")
    cat_info = item.get("cat", {})
    mime_type = item.get("file", {}).get("mime", {}).get("type", "")

    # Portable path for gotime-compatible link
    abs_path = str(evidence_root) + rel_fn
    portable = _portable_path(abs_path, str(evidence_root))

    lines = []

    ev_type = item.get("type", "")  # E or A

    # ── YAML frontmatter ──
    lines.append("---")
    # essentials first
    lines.append("cssclasses:")
    lines.append("  - evidence-note")
    lines.append("tags:")
    lines.append("  - evidence")
    if has_thumb:
        thumb_name = f"{best_id}{THUMB_EXT}"
        lines.append(f"cover: \"[[{thumb_name}]]\"")
    # type info
    lines.append(f"mime_type: \"{mime_type}\"")
    lines.append(f"type: \"{ev_type}\"")
    # id
    lines.append(f"evidence_id: \"{best_id}\"")
    # extra properties (not id*, file, cat, type, exif, format, xtras)
    skip_props = {"id", "file", "cat", "type", "exif", "format", "xtras"}
    for key, val in item.items():
        if key in skip_props or key.startswith("id"):
            continue
        # Parse string-encoded lists like "['A', 'B']"
        if isinstance(val, str) and val.startswith("["):
            try:
                import ast
                val = ast.literal_eval(val)
            except (ValueError, SyntaxError):
                pass
        if isinstance(val, list):
            lines.append(f"{key}:")
            for li in val:
                lines.append(f"  - \"{li}\"")
        elif isinstance(val, dict):
            lines.append(f"{key}:")
            for dk, dv in val.items():
                lines.append(f"  {dk}: \"{dv}\"")
        else:
            lines.append(f"{key}: \"{val}\"")
    # cat last — flat keys: cat_disk, cat_loc, cat_time etc.
    if isinstance(cat_info, dict):
        for ck, cv in cat_info.items():
            # Parse string-encoded lists like "['A', 'B']"
            if isinstance(cv, str) and cv.startswith("["):
                try:
                    import ast
                    cv = ast.literal_eval(cv)
                except (ValueError, SyntaxError):
                    pass
            # Keys identified as lists: always render as YAML list
            if ck in cat_list_keys:
                if isinstance(cv, str):
                    cv = [p.strip() for p in cv.split("+") if p.strip()]
                if not isinstance(cv, list):
                    cv = [cv] if cv else []
                lines.append(f"cat_{ck}:")
                for li in cv:
                    lines.append(f"  - \"{li}\"")
            elif isinstance(cv, list):
                lines.append(f"cat_{ck}:")
                for li in cv:
                    lines.append(f"  - \"{li}\"")
            else:
                lines.append(f"cat_{ck}: \"{cv}\"")
    else:
        lines.append(f"cat: \"{cat_info}\"")
    lines.append("---")
    lines.append("")

    # ── Title ──
    #lines.append(f"# {best_id}")
    #lines.append("")

    # ── Filename ──
    encoded = quote(portable, safe='/:~')
    file_url = f"file://{encoded}"
    if has_thumb:
        lines.append(f"`{rel_fn}`")
    else:
        lines.append(f"[{rel_fn}]({file_url})")
    lines.append("")

    # ── Thumbnail with gotime link ──
    if has_thumb:
        thumb_name = f"{best_id}{THUMB_EXT}"
        lines.append(f"[![center]({thumb_name})]({file_url})")
        lines.append("")

    # ── Data fields as collapsed callouts (only exif and format) ──
    callout_keys = ("exif", "format")
    for key in callout_keys:
        val = item.get(key)
        if val is None:
            continue
        lines.append(f"> [!warning]- {key}")
        _render_value(lines, val, depth=0)
        lines.append("")

    # ── End line ──
    lines.append("---")

    md_path = out_dir / f"{best_id}.md"
    md_path.write_text("\n".join(lines), encoding="utf-8")


# ─── Main build function ───────────────────────────────────────────

def build() -> None:
    """Build an Obsidian vault from the Evidence database.

    Creates ``obsidian/`` inside the Evidence data path with:
      - A JPEG thumbnail per image/video item
      - A Markdown note per evidence item
    """
    _profile, evidence_paths, data_path = load_config()
    evidence_root = evidence_paths[0]
    db_path = data_path / "database"

    # Output directory
    out_dir = data_path / "obsidian"
    out_dir.mkdir(exist_ok=True)

    # Load full database
    console.print(f"[cyan]Loading evidence database...[/cyan]")
    ev = Evidence(mode=Mode.LOAD)

    console.print(f"[green]{len(ev)} items loaded.[/green]")
    console.print(f"[cyan]Building Obsidian vault in[/cyan] {out_dir}")

    workers = max(1, (os.cpu_count() or 1) * 2 // 3)

    # ── Single-pass preparation: resolve IDs, collect thumb jobs, detect list keys ──
    console.print("[dim]Preparing...[/dim]")
    items_info = []      # (best_id, item, abs_path, mime_type)
    thumb_jobs = []      # (best_id, src, dst, mime_type)
    thumb_skip_ids = set()
    cat_list_keys = set()

    for item in ev:
        best_id = _best_id(item, db_path)
        mime_type = item.get("file", {}).get("mime", {}).get("type", "")
        abs_path = str(evidence_root) + item.get("file", {}).get("fn", "")
        items_info.append((best_id, item, abs_path, mime_type))

        # Thumbnail status
        thumb_dst = out_dir / f"{best_id}{THUMB_EXT}"
        if thumb_dst.exists():
            thumb_skip_ids.add(best_id)
        elif mime_type in ("image", "video") and Path(abs_path).exists():
            thumb_jobs.append((best_id, abs_path, str(thumb_dst), mime_type))

        # Detect list-type cat keys
        cat = item.get("cat", {})
        if isinstance(cat, dict):
            for k, v in cat.items():
                if isinstance(v, list):
                    cat_list_keys.add(k)
                elif isinstance(v, str):
                    if v.startswith("["):
                        cat_list_keys.add(k)
                    elif "+" in v:
                        parts = [p.strip() for p in v.split("+") if p.strip()]
                        if len(parts) > 1:
                            cat_list_keys.add(k)

    # ── Phase 1: Thumbnails (parallel processes) ─────────────────
    thumbs_ok = 0
    thumbs_skip = len(thumb_skip_ids)
    thumbs_fail = 0
    thumb_results = {}  # best_id → bool

    if thumb_jobs:
        console.print(f"[cyan]Generating {len(thumb_jobs)} thumbnails ({workers} workers)...[/cyan]")
        with Progress() as progress:
            task = progress.add_task("Thumbnails...", total=len(thumb_jobs))
            with ProcessPoolExecutor(max_workers=workers) as pool:
                futures = {
                    pool.submit(_make_thumb, src, dst, mt): bid
                    for bid, src, dst, mt in thumb_jobs
                }
                for future in as_completed(futures):
                    bid = futures[future]
                    try:
                        ok = future.result()
                    except Exception:
                        ok = False
                    thumb_results[bid] = ok
                    if ok:
                        thumbs_ok += 1
                    else:
                        thumbs_fail += 1
                    progress.advance(task)
    else:
        console.print(f"[dim]Thumbnails: {thumbs_skip} already exist, nothing to generate.[/dim]")

    # ── Phase 2: Markdown notes (parallel threads) ────────────────
    notes_ok = 0
    with Progress() as progress:
        task = progress.add_task("Writing notes...", total=len(items_info))
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = []
            for best_id, item, abs_path, mime_type in items_info:
                has_thumb = (
                    best_id in thumb_skip_ids
                    or thumb_results.get(best_id, False)
                )
                futures.append(pool.submit(
                    _write_note, out_dir, best_id, item,
                    evidence_root, has_thumb, cat_list_keys,
                ))
            for future in as_completed(futures):
                future.result()
                notes_ok += 1
                progress.advance(task)

    console.print()
    console.print(f"[green]Done![/green]")
    console.print(f"  Thumbnails: {thumbs_ok} created, {thumbs_skip} skipped, {thumbs_fail} failed")
    console.print(f"  Notes:      {notes_ok} created")
    console.print(f"  Output:     {out_dir}")


# ─── CLI entry point ───────────────────────────────────────────────

def main():
    """Entry point for the ``evidence-obsidian`` command."""
    build()
    return 0


if __name__ == "__main__":
    sys.exit(main())
