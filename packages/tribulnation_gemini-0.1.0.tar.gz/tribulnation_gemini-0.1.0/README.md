# Tribulnation Gemini SDK

> An SDK to connect Gemini with the Tribulnation ecosystem.

🚧 Under construction.