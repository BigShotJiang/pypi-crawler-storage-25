"""GraphQL types for session management."""

from __future__ import annotations

from collections.abc import Iterable
from datetime import datetime
from enum import StrEnum
from typing import Any, Self, cast
from uuid import UUID

import strawberry
from strawberry import ID, Info
from strawberry.relay import Connection, Edge, NodeID

from ai.backend.common.contexts.user import current_user
from ai.backend.common.dto.manager.v2.common import (
    ResourceSlotEntryInput as ResourceSlotEntryInputDTO,
)
from ai.backend.common.dto.manager.v2.kernel.request import AdminSearchKernelsInput
from ai.backend.common.dto.manager.v2.session.request import (
    BatchConfigInput as BatchConfigInputDTO,
)
from ai.backend.common.dto.manager.v2.session.request import (
    EnqueueSessionInput as EnqueueSessionInputDTO,
)
from ai.backend.common.dto.manager.v2.session.request import (
    MountItemInput as MountItemInputDTO,
)
from ai.backend.common.dto.manager.v2.session.request import (
    ResourceOptsInput as ResourceOptsInputDTO,
)
from ai.backend.common.dto.manager.v2.session.request import (
    SessionFilter,
    SessionOrder,
)
from ai.backend.common.dto.manager.v2.session.response import (
    EnqueueSessionPayload as EnqueueSessionPayloadDTO,
)
from ai.backend.common.dto.manager.v2.session.response import (
    SessionLifecycleInfoGQLDTO,
    SessionMetadataInfoGQLDTO,
    SessionNetworkInfo,
    SessionNode,
    SessionResourceInfoGQLDTO,
    SessionRuntimeInfoGQLDTO,
)
from ai.backend.common.dto.manager.v2.session.response import (
    TerminateSessionsPayload as TerminateSessionsPayloadDTO,
)
from ai.backend.common.dto.manager.v2.session.types import (
    ProjectSessionScope,
    SessionStatusFilter,
)
from ai.backend.common.types import ImageID, SessionId
from ai.backend.manager.api.gql.base import OrderDirection, StringFilter, UUIDFilter, encode_cursor
from ai.backend.manager.api.gql.common.types import (
    ClusterModeGQL,
    SessionV2ResultGQL,
    SessionV2TypeGQL,
)
from ai.backend.manager.api.gql.common_types import BinarySizeInputGQL
from ai.backend.manager.api.gql.decorators import (
    BackendAIGQLMeta,
    PydanticInputMixin,
    gql_added_field,
    gql_connection_type,
    gql_enum,
    gql_field,
    gql_node_type,
    gql_pydantic_input,
    gql_pydantic_type,
)
from ai.backend.manager.api.gql.deployment.types.revision import EnvironmentVariablesGQL
from ai.backend.manager.api.gql.domain_v2.types.node import DomainV2GQL
from ai.backend.manager.api.gql.image.types import ImageV2ConnectionGQL
from ai.backend.manager.api.gql.kernel.types import (
    KernelV2ConnectionGQL,
    KernelV2EdgeGQL,
    KernelV2GQL,
    ResourceAllocationGQL,
)
from ai.backend.manager.api.gql.project_v2.types.node import ProjectV2GQL
from ai.backend.manager.api.gql.pydantic_compat import PydanticNodeMixin
from ai.backend.manager.api.gql.resource_group.types import ResourceGroupGQL
from ai.backend.manager.api.gql.types import StrawberryGQLContext
from ai.backend.manager.api.gql.user.types.node import UserV2GQL
from ai.backend.manager.errors.user import UserNotFound


@gql_enum(
    BackendAIGQLMeta(added_version="26.3.0", description="Status of a session in its lifecycle."),
    name="SessionV2Status",
)
class SessionV2StatusGQL(StrEnum):
    """GraphQL enum for session status."""

    PENDING = "PENDING"
    SCHEDULED = "SCHEDULED"
    PREPARING = "PREPARING"
    PREPARED = "PREPARED"
    CREATING = "CREATING"
    RUNNING = "RUNNING"
    DEPRIORITIZING = "DEPRIORITIZING"
    TERMINATING = "TERMINATING"
    TERMINATED = "TERMINATED"
    CANCELLED = "CANCELLED"


# ========== Order and Filter Types ==========


@gql_enum(
    BackendAIGQLMeta(added_version="26.3.0", description="Fields available for ordering sessions."),
    name="SessionV2OrderField",
)
class SessionV2OrderFieldGQL(StrEnum):
    CREATED_AT = "created_at"
    TERMINATED_AT = "terminated_at"
    STATUS = "status"
    ID = "id"
    NAME = "name"


@gql_pydantic_input(
    BackendAIGQLMeta(description="Filter for session status.", added_version="26.3.0"),
    name="SessionV2StatusFilter",
)
class SessionV2StatusFilterGQL(PydanticInputMixin[SessionStatusFilter]):
    equals: SessionV2StatusGQL | None = None
    in_: list[SessionV2StatusGQL] | None = gql_field(
        description="The in  field.", name="in", default=None
    )
    not_equals: SessionV2StatusGQL | None = gql_field(
        description="Excludes exact status match.", name="notEquals", default=None
    )
    not_in: list[SessionV2StatusGQL] | None = None


@gql_pydantic_input(
    BackendAIGQLMeta(
        description="Filter criteria for querying sessions.",
        added_version="26.3.0",
    ),
    name="SessionV2Filter",
)
class SessionV2FilterGQL(PydanticInputMixin[SessionFilter]):
    id: UUIDFilter | None = None
    status: SessionV2StatusFilterGQL | None = None
    name: StringFilter | None = None
    domain_name: StringFilter | None = None
    project_id: UUIDFilter | None = None
    user_uuid: UUIDFilter | None = None

    AND: list[Self] | None = None
    OR: list[Self] | None = None
    NOT: list[Self] | None = None


@gql_pydantic_input(
    BackendAIGQLMeta(description="Ordering specification for sessions.", added_version="26.3.0"),
    name="SessionV2OrderBy",
)
class SessionV2OrderByGQL(PydanticInputMixin[SessionOrder]):
    field: SessionV2OrderFieldGQL
    direction: OrderDirection = OrderDirection.DESC


# ========== Scope Types ==========


@gql_pydantic_input(
    BackendAIGQLMeta(
        description="Scope for session operations within a specific project.",
        added_version="26.4.2",
    ),
    name="ProjectSessionV2Scope",
)
class ProjectSessionScopeGQL(PydanticInputMixin[ProjectSessionScope]):
    """Scope for project-level session operations."""

    project_id: UUID = gql_field(description="Project UUID to scope the session operation.")


# ========== Session Info Sub-Types ==========


@gql_pydantic_type(
    BackendAIGQLMeta(
        added_version="26.3.0",
        description="Metadata information for a session.",
    ),
    model=SessionMetadataInfoGQLDTO,
    name="SessionV2MetadataInfo",
)
class SessionV2MetadataInfoGQL:
    creation_id: str = gql_field(
        description="Server-generated unique token for tracking session creation."
    )
    name: str = gql_field(description="Human-readable name of the session.")
    session_type: SessionV2TypeGQL = gql_field(
        description="Type of the session (interactive, batch, inference)."
    )
    access_key: str = gql_field(description="Access key used to create this session.")
    cluster_mode: ClusterModeGQL = gql_field(
        description="Cluster mode for distributed sessions (single-node, multi-node)."
    )
    cluster_size: int = gql_field(description="Number of nodes in the cluster.")
    priority: int = gql_field(description="Scheduling priority of the session.")
    is_preemptible: bool = gql_field(
        description="Whether this session is eligible for preemption by higher-priority sessions."
    )
    tag: str | None = gql_field(description="Optional user-provided tag for the session.")


@gql_pydantic_type(
    BackendAIGQLMeta(
        added_version="26.3.0",
        description="Resource allocation information for a session.",
    ),
    model=SessionResourceInfoGQLDTO,
    name="SessionV2ResourceInfo",
)
class SessionV2ResourceInfoGQL:
    allocation: ResourceAllocationGQL = gql_field(
        description="Resource allocation with requested and occupied slots."
    )
    resource_group_name: str | None = gql_field(
        description="The resource group (scaling group) this session is assigned to."
    )


@gql_pydantic_type(
    BackendAIGQLMeta(
        added_version="26.3.0",
        description="Lifecycle status and timestamps for a session.",
    ),
    model=SessionLifecycleInfoGQLDTO,
    name="SessionV2LifecycleInfo",
)
class SessionV2LifecycleInfoGQL:
    status: SessionV2StatusGQL = gql_field(description="Current status of the session.")
    result: SessionV2ResultGQL = gql_field(
        description="Result of the session execution (success, failure, etc.)."
    )
    created_at: datetime | None = gql_field(description="Timestamp when the session was created.")
    terminated_at: datetime | None = gql_field(
        description="Timestamp when the session was terminated. Null if still active."
    )
    starts_at: datetime | None = gql_field(
        description="Scheduled start time for the session, if applicable."
    )
    batch_timeout: int | None = gql_field(
        description="Batch execution timeout in seconds. Applicable to batch sessions."
    )


@gql_pydantic_type(
    BackendAIGQLMeta(
        added_version="26.3.0",
        description="Runtime execution configuration for a session.",
    ),
    model=SessionRuntimeInfoGQLDTO,
    name="SessionV2RuntimeInfo",
)
class SessionV2RuntimeInfoGQL:
    environ: EnvironmentVariablesGQL | None = gql_field(
        description="Environment variables for the session."
    )
    bootstrap_script: str | None = gql_field(
        description="Bootstrap script to run before the main process."
    )
    startup_command: str | None = gql_field(
        description="Startup command to execute when the session starts."
    )
    callback_url: str | None = gql_field(
        description="URL to call back when the session completes (e.g., for batch sessions)."
    )


@gql_pydantic_type(
    BackendAIGQLMeta(
        added_version="26.3.0",
        description="Network configuration for a session.",
    ),
    model=SessionNetworkInfo,
    name="SessionV2NetworkInfo",
)
class SessionV2NetworkInfoGQL:
    use_host_network: strawberry.auto
    network_type: strawberry.auto
    network_id: strawberry.auto


# ========== Main Session Type ==========


@gql_node_type(
    BackendAIGQLMeta(
        added_version="26.3.0",
        description="Represents a compute session in Backend.AI.",
    ),
    name="SessionV2",
)
class SessionV2GQL(PydanticNodeMixin[SessionNode]):
    """Session type representing a compute session."""

    id: NodeID[str]

    # Image IDs for this session (used by images resolver)
    image_ids: list[strawberry.ID] | None = gql_field(
        description=(
            "UUIDs of the images used by this session. "
            "Multiple images are possible in multi-kernel (cluster) sessions."
        ),
    )

    # Fields used as keys for dynamic resolvers
    domain_name: str
    user_id: ID
    project_id: ID

    metadata: SessionV2MetadataInfoGQL = gql_field(
        description="Metadata including domain, project, and user information."
    )
    resource: SessionV2ResourceInfoGQL = gql_field(
        description="Resource allocation and cluster information."
    )
    lifecycle: SessionV2LifecycleInfoGQL = gql_field(description="Lifecycle status and timestamps.")
    runtime: SessionV2RuntimeInfoGQL = gql_field(description="Runtime execution configuration.")
    network: SessionV2NetworkInfoGQL = gql_field(description="Network configuration.")

    @gql_added_field(
        BackendAIGQLMeta(added_version="26.3.0", description="The domain this session belongs to.")
    )  # type: ignore[misc]
    async def domain(self, info: Info[StrawberryGQLContext]) -> DomainV2GQL | None:
        return await info.context.data_loaders.domain_loader.load(self.domain_name)

    @gql_added_field(
        BackendAIGQLMeta(added_version="26.3.0", description="The user who owns this session.")
    )  # type: ignore[misc]
    async def user(self, info: Info[StrawberryGQLContext]) -> UserV2GQL | None:
        user_data = await info.context.data_loaders.user_loader.load(UUID(str(self.user_id)))
        if user_data is None:
            return None
        return user_data

    @gql_added_field(
        BackendAIGQLMeta(added_version="26.3.0", description="The project this session belongs to.")
    )  # type: ignore[misc]
    async def project(self, info: Info[StrawberryGQLContext]) -> ProjectV2GQL | None:
        project_data = await info.context.data_loaders.project_loader.load(
            UUID(str(self.project_id))
        )
        if project_data is None:
            return None
        return project_data

    @gql_added_field(
        BackendAIGQLMeta(
            added_version="26.3.0", description="The resource group this session is assigned to."
        )
    )  # type: ignore[misc]
    async def resource_group(self, info: Info[StrawberryGQLContext]) -> ResourceGroupGQL | None:
        if self.resource.resource_group_name is None:
            return None
        resource_group_data = await info.context.data_loaders.resource_group_loader.load(
            self.resource.resource_group_name
        )
        if resource_group_data is None:
            return None
        return resource_group_data

    @gql_added_field(
        BackendAIGQLMeta(
            added_version="26.4.3",
            description="The images used by this session. Multiple images are possible in multi-kernel (cluster) sessions.",
        )
    )  # type: ignore[misc]
    async def images(self, info: Info[StrawberryGQLContext]) -> ImageV2ConnectionGQL:
        from ai.backend.manager.api.gql.image.types import ImageV2EdgeGQL

        if not self.image_ids:
            return ImageV2ConnectionGQL(
                edges=[],
                page_info=strawberry.relay.PageInfo(
                    has_next_page=False,
                    has_previous_page=False,
                    start_cursor=None,
                    end_cursor=None,
                ),
                count=0,
            )

        unique_ids = list(dict.fromkeys(ImageID(UUID(str(iid))) for iid in self.image_ids))
        results = await info.context.data_loaders.image_loader.load_many(unique_ids)
        nodes = [img for img in results if img is not None]
        edges = [ImageV2EdgeGQL(node=node, cursor=encode_cursor(node.id)) for node in nodes]
        return ImageV2ConnectionGQL(
            edges=edges,
            page_info=strawberry.relay.PageInfo(
                has_next_page=False,
                has_previous_page=False,
                start_cursor=edges[0].cursor if edges else None,
                end_cursor=edges[-1].cursor if edges else None,
            ),
            count=len(nodes),
        )

    @gql_added_field(
        BackendAIGQLMeta(
            added_version="26.3.0", description="The kernels belonging to this session."
        )
    )  # type: ignore[misc]
    async def kernels(self, info: Info[StrawberryGQLContext]) -> KernelV2ConnectionGQL:
        user = current_user()
        if user is None:
            raise UserNotFound("User not found in context")

        session_id = SessionId(UUID(str(self.id)))
        payload = await info.context.adapters.session.search_kernels_by_session(
            session_id, AdminSearchKernelsInput()
        )
        nodes = [KernelV2GQL.from_pydantic(kernel) for kernel in payload.items]
        edges = [KernelV2EdgeGQL(node=node, cursor=encode_cursor(node.id)) for node in nodes]
        return KernelV2ConnectionGQL(
            edges=edges,
            page_info=strawberry.relay.PageInfo(
                has_next_page=payload.has_next_page,
                has_previous_page=payload.has_previous_page,
                start_cursor=edges[0].cursor if edges else None,
                end_cursor=edges[-1].cursor if edges else None,
            ),
            count=payload.total_count,
        )

    # TODO: Add `vfolder_mounts` dynamic field (VFolder connection type needed)

    @classmethod
    async def resolve_nodes(  # type: ignore[override]  # Strawberry Node uses AwaitableOrValue overloads incompatible with async def
        cls,
        *,
        info: Info[StrawberryGQLContext],
        node_ids: Iterable[str],
        required: bool = False,
    ) -> Iterable[Self | None]:
        results = await info.context.data_loaders.session_loader.load_many([
            SessionId(UUID(nid)) for nid in node_ids
        ])
        return cast(list[Self | None], results)


# ========== Connection Types ==========


SessionV2EdgeGQL = Edge[SessionV2GQL]


@gql_connection_type(
    BackendAIGQLMeta(
        added_version="26.3.0",
        description="Connection type for paginated session results.",
    ),
    name="SessionV2Connection",
)
class SessionV2ConnectionGQL(Connection[SessionV2GQL]):
    count: int

    def __init__(self, *args: Any, count: int, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self.count = count


# ========== Create Session Input Types ==========


@gql_enum(
    BackendAIGQLMeta(
        added_version="26.4.2",
        description="Session types allowed for user-initiated creation.",
    ),
    name="CreateSessionType",
)
class CreateSessionTypeGQL(StrEnum):
    INTERACTIVE = "interactive"
    BATCH = "batch"


@gql_enum(
    BackendAIGQLMeta(
        added_version="26.4.2",
        description="Cluster networking modes for session creation.",
    ),
    name="SessionClusterMode",
)
class SessionClusterModeGQL(StrEnum):
    SINGLE_NODE = "single-node"
    MULTI_NODE = "multi-node"


@gql_pydantic_input(
    BackendAIGQLMeta(
        description="A single resource slot allocation entry.",
        added_version="26.4.2",
    ),
    name="SessionResourceSlotEntryInput",
)
class SessionResourceSlotEntryInputGQL(PydanticInputMixin[ResourceSlotEntryInputDTO]):
    resource_type: str = gql_field(description="Resource type identifier.")
    quantity: str = gql_field(description="Quantity as a decimal string.")


@gql_pydantic_input(
    BackendAIGQLMeta(
        description="Additional resource options for session creation.",
        added_version="26.4.2",
    ),
    name="SessionResourceOptsInput",
)
class SessionResourceOptsInputGQL(PydanticInputMixin[ResourceOptsInputDTO]):
    shmem: BinarySizeInputGQL | None = gql_field(
        default=None, description="Shared memory size (e.g., '1g')."
    )


@gql_pydantic_input(
    BackendAIGQLMeta(
        description="A virtual folder mount specification.",
        added_version="26.4.2",
    ),
    name="SessionMountItemInput",
)
class SessionMountItemInputGQL(PydanticInputMixin[MountItemInputDTO]):
    vfolder_id: ID = gql_field(description="Virtual folder UUID.")
    mount_path: str | None = gql_field(default=None, description="Custom mount path.")
    permission: str | None = gql_field(default=None, description="Mount permission ('rw' or 'ro').")


@gql_pydantic_input(
    BackendAIGQLMeta(
        description="Batch session specific configuration.",
        added_version="26.4.2",
    ),
    name="SessionBatchConfigInput",
)
class SessionBatchConfigInputGQL(PydanticInputMixin[BatchConfigInputDTO]):
    startup_command: str = gql_field(description="Shell command to execute.")
    starts_at: str | None = gql_field(default=None, description="Scheduled start time (ISO 8601).")
    batch_timeout: int | None = gql_field(default=None, description="Execution timeout in seconds.")


@gql_pydantic_input(
    BackendAIGQLMeta(
        description="Input for creating a new compute session.",
        added_version="26.4.2",
    ),
    name="EnqueueSessionInput",
)
class EnqueueSessionInputGQL(PydanticInputMixin[EnqueueSessionInputDTO]):
    session_name: str = gql_field(description="Session name.")
    session_type: CreateSessionTypeGQL = gql_field(description="Session type.")
    image_id: ID = gql_field(description="Image UUID.")

    resource_entries: list[SessionResourceSlotEntryInputGQL] = gql_field(
        description="Resource slot allocations."
    )
    resource_group: str | None = gql_field(default=None, description="Scaling group name.")
    resource_opts: SessionResourceOptsInputGQL | None = gql_field(
        default=None, description="Additional resource options."
    )
    cluster_mode: SessionClusterModeGQL = gql_field(
        default=SessionClusterModeGQL.SINGLE_NODE, description="Cluster mode."
    )
    cluster_size: int = gql_field(default=1, description="Number of containers.")

    mounts: list[SessionMountItemInputGQL] | None = gql_field(
        default=None, description="Virtual folder mounts."
    )

    environ: strawberry.scalars.JSON | None = gql_field(
        default=None, description="Environment variables."
    )
    preopen_ports: list[int] | None = gql_field(default=None, description="Ports to pre-open.")
    bootstrap_script: str | None = gql_field(default=None, description="Bootstrap script.")

    priority: int = gql_field(default=10, description="Scheduling priority (0-100).")
    is_preemptible: bool = gql_field(default=True, description="Whether preemptible.")
    dependencies: list[ID] | None = gql_field(default=None, description="Dependent session IDs.")
    agent_list: list[str] | None = gql_field(default=None, description="Designated agent IDs.")
    attach_network: ID | None = gql_field(default=None, description="Network UUID to attach.")

    tag: str | None = gql_field(default=None, description="User-defined tag.")
    callback_url: str | None = gql_field(default=None, description="Webhook URL.")

    batch: SessionBatchConfigInputGQL | None = gql_field(
        default=None, description="Batch configuration."
    )
    project_id: ID | None = gql_field(default=None, description="Project UUID.")


# ========== Create Session Payload ==========


@gql_pydantic_type(
    BackendAIGQLMeta(
        added_version="26.4.2",
        description="Payload returned after creating a session.",
    ),
    model=EnqueueSessionPayloadDTO,
    name="EnqueueSessionPayload",
)
class EnqueueSessionPayloadGQL:
    session: SessionV2GQL = gql_field(description="Created session details.")


@gql_pydantic_type(
    BackendAIGQLMeta(
        added_version="26.4.2",
        description="Payload returned after terminating sessions.",
    ),
    model=TerminateSessionsPayloadDTO,
    name="TerminateSessionsPayload",
)
class TerminateSessionsPayloadGQL:
    cancelled: list[ID] = gql_field(description="Sessions cancelled from PENDING.")
    terminating: list[ID] = gql_field(description="Sessions marked TERMINATING.")
    force_terminated: list[ID] = gql_field(description="Sessions force-terminated.")
    skipped: list[ID] = gql_field(description="Sessions already terminated or not found.")
