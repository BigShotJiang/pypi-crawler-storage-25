"""GraphQL types for session management."""

from __future__ import annotations

from .resolver import (
    admin_sessions_v2,
    enqueue_session,
    project_sessions_v2,
    terminate_project_sessions_v2,
)
from .types import (
    EnqueueSessionInputGQL,
    EnqueueSessionPayloadGQL,
    ProjectSessionScopeGQL,
    SessionV2ConnectionGQL,
    SessionV2EdgeGQL,
    SessionV2FilterGQL,
    SessionV2GQL,
    SessionV2LifecycleInfoGQL,
    SessionV2MetadataInfoGQL,
    SessionV2NetworkInfoGQL,
    SessionV2OrderByGQL,
    SessionV2OrderFieldGQL,
    SessionV2ResourceInfoGQL,
    SessionV2RuntimeInfoGQL,
    SessionV2StatusFilterGQL,
    SessionV2StatusGQL,
    TerminateSessionsPayloadGQL,
)

__all__ = [
    # Resolvers
    "admin_sessions_v2",
    "enqueue_session",
    "project_sessions_v2",
    "terminate_project_sessions_v2",
    # V2 types
    "EnqueueSessionInputGQL",
    "EnqueueSessionPayloadGQL",
    "ProjectSessionScopeGQL",
    "SessionV2ConnectionGQL",
    "SessionV2EdgeGQL",
    "SessionV2FilterGQL",
    "SessionV2LifecycleInfoGQL",
    "SessionV2MetadataInfoGQL",
    "SessionV2NetworkInfoGQL",
    "SessionV2OrderByGQL",
    "SessionV2OrderFieldGQL",
    "SessionV2ResourceInfoGQL",
    "SessionV2RuntimeInfoGQL",
    "SessionV2StatusFilterGQL",
    "SessionV2StatusGQL",
    "SessionV2GQL",
    "TerminateSessionsPayloadGQL",
]
