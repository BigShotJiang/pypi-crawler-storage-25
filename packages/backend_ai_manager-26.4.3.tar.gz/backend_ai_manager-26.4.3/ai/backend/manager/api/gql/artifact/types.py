from __future__ import annotations

import uuid
from collections.abc import Iterable
from datetime import datetime
from typing import Any, Self, cast

import strawberry
from strawberry import ID, UNSET, Info
from strawberry.relay import Connection, Edge, NodeID
from strawberry.scalars import JSON

from ai.backend.common.data.artifact.types import (
    ArtifactRegistryType,
)
from ai.backend.common.dto.manager.v2.artifact.request import (
    AdminSearchArtifactRevisionsInput,
    ArtifactGQLFilterInputDTO,
    ArtifactGQLOrderByInputDTO,
    ArtifactRevisionGQLFilterInputDTO,
    ArtifactRevisionGQLOrderByInputDTO,
    ArtifactRevisionRemoteStatusFilterDTO,
    ArtifactRevisionStatusFilterDTO,
    ArtifactStatusChangedInputDTO,
)
from ai.backend.common.dto.manager.v2.artifact.request import (
    ApproveArtifactInput as ApproveArtifactInputDTO,
)
from ai.backend.common.dto.manager.v2.artifact.request import (
    CancelImportTaskInput as CancelArtifactInputDTO,
)
from ai.backend.common.dto.manager.v2.artifact.request import (
    CleanupRevisionsInput as CleanupArtifactRevisionsInputDTO,
)
from ai.backend.common.dto.manager.v2.artifact.request import (
    DelegateeTargetInput as DelegateeTargetInputDTO,
)
from ai.backend.common.dto.manager.v2.artifact.request import (
    DelegateImportArtifactsInput as DelegateImportArtifactsInputDTO,
)
from ai.backend.common.dto.manager.v2.artifact.request import (
    DelegateScanArtifactsInput as DelegateScanArtifactsInputDTO,
)
from ai.backend.common.dto.manager.v2.artifact.request import (
    DeleteArtifactsInput as DeleteArtifactsInputDTO,
)
from ai.backend.common.dto.manager.v2.artifact.request import (
    ImportArtifactsInput as ImportArtifactsInputDTO,
)
from ai.backend.common.dto.manager.v2.artifact.request import (
    ImportArtifactsOptionsInput as ImportArtifactsOptionsInputDTO,
)
from ai.backend.common.dto.manager.v2.artifact.request import (
    ModelTargetInput as ModelTargetInputDTO,
)
from ai.backend.common.dto.manager.v2.artifact.request import (
    RejectArtifactInput as RejectArtifactInputDTO,
)
from ai.backend.common.dto.manager.v2.artifact.request import (
    RestoreArtifactsInput as RestoreArtifactsInputDTO,
)
from ai.backend.common.dto.manager.v2.artifact.request import (
    ScanArtifactModelsInput as ScanArtifactModelsInputDTO,
)
from ai.backend.common.dto.manager.v2.artifact.request import (
    ScanArtifactsInput as ScanArtifactsInputDTO,
)
from ai.backend.common.dto.manager.v2.artifact.request import (
    UpdateArtifactGQLInput as UpdateArtifactGQLInputDTO,
)
from ai.backend.common.dto.manager.v2.artifact.response import (
    ApproveArtifactGQLPayload,
    ArtifactGQLNode,
    ArtifactImportProgressUpdatedGQLPayload,
    ArtifactNode,
    ArtifactRevisionImportTaskInfoGQL,
    ArtifactRevisionNode,
    ArtifactStatusChangedGQLPayload,
    ArtifactVerificationGQLResultDTO,
    ArtifactVerifierGQLResultDTO,
    ArtifactVerifierGQLResultEntryDTO,
    ArtifactVerifierMetadataDTO,
    ArtifactVerifierMetadataEntryDTO,
    CancelImportArtifactGQLPayload,
    CleanupArtifactRevisionsGQLPayload,
    DelegateImportArtifactsGQLPayload,
    DelegateScanArtifactsGQLPayload,
    DeleteArtifactsGQLPayload,
    ImportArtifactsGQLPayload,
    RejectArtifactGQLPayload,
    RestoreArtifactsGQLPayload,
    ScanArtifactModelsGQLPayload,
    ScanArtifactsGQLPayload,
    SourceInfoDTO,
    UpdateArtifactGQLPayload,
)
from ai.backend.manager.api.gql.base import (
    ByteSize,
    IntFilter,
    OrderDirection,
    StringFilter,
    UUIDFilter,
    encode_cursor,
)
from ai.backend.manager.api.gql.data_loader.data_loaders import DataLoaders
from ai.backend.manager.api.gql.decorators import (
    BackendAIGQLMeta,
    gql_added_field,
    gql_connection_type,
    gql_field,
    gql_node_type,
    gql_pydantic_input,
    gql_pydantic_type,
)
from ai.backend.manager.api.gql.pydantic_compat import (
    PydanticInputMixin,
    PydanticNodeMixin,
    PydanticOutputMixin,
)
from ai.backend.manager.api.gql.types import GQLOrderBy, StrawberryGQLContext
from ai.backend.manager.api.gql.utils import dedent_strip
from ai.backend.manager.data.artifact.types import (
    ArtifactAvailability,
    ArtifactOrderField,
    ArtifactRemoteStatus,
    ArtifactRevisionOrderField,
    ArtifactStatus,
    ArtifactType,
)
from ai.backend.manager.errors.artifact_registry import ArtifactRegistryNotFoundError
from ai.backend.manager.models.artifact_revision.conditions import ArtifactRevisionConditions


async def get_registry_url(
    data_loaders: DataLoaders,
    registry_id: uuid.UUID,
    registry_type: ArtifactRegistryType,
) -> str:
    """Get the URL for a registry based on its type."""
    match registry_type:
        case ArtifactRegistryType.HUGGINGFACE:
            hf_registry = await data_loaders.huggingface_registry_loader.load(registry_id)
            if hf_registry is None:
                raise ArtifactRegistryNotFoundError(f"HuggingFace registry {registry_id} not found")
            return hf_registry.url
        case ArtifactRegistryType.RESERVOIR:
            reservoir_registry = await data_loaders.reservoir_registry_loader.load(registry_id)
            if reservoir_registry is None:
                raise ArtifactRegistryNotFoundError(f"Reservoir registry {registry_id} not found")
            return reservoir_registry.endpoint
    raise ArtifactRegistryNotFoundError(f"Unknown registry type: {registry_type}")


@gql_pydantic_type(
    BackendAIGQLMeta(
        added_version="26.1.0",
        description="A single key-value entry representing metadata from an artifact verifier. Contains additional information about the verification process.",
    ),
    model=ArtifactVerifierMetadataEntryDTO,
    name="ArtifactVerifierMetadataEntry",
)
class ArtifactVerifierMetadataEntryGQL:
    key: strawberry.auto
    value: strawberry.auto


@gql_pydantic_type(
    BackendAIGQLMeta(
        added_version="26.1.0",
        description="A collection of metadata from an artifact verifier. Contains key-value pairs providing additional information about the verification.",
    ),
    model=ArtifactVerifierMetadataDTO,
    name="ArtifactVerifierMetadata",
)
class ArtifactVerifierMetadataGQL(PydanticOutputMixin[ArtifactVerifierMetadataDTO]):
    """Metadata containing multiple key-value entries."""

    entries: list[ArtifactVerifierMetadataEntryGQL] = gql_field(
        description="List of metadata entries. Each entry contains a key-value pair."
    )


@gql_pydantic_type(
    BackendAIGQLMeta(
        added_version="25.17.0",
        description="Result from a single malware verifier containing scan results and metadata. Each verifier scans the artifact for potential security issues and reports findings including infected file count, scan time, and any errors encountered.",
    ),
    model=ArtifactVerifierGQLResultDTO,
    name="ArtifactVerifierResult",
)
class ArtifactVerifierGQLResult(PydanticOutputMixin[ArtifactVerifierGQLResultDTO]):
    success: bool = gql_field(description="Whether the verification completed successfully")
    infected_count: int = gql_field(description="Number of infected or suspicious files detected")
    scanned_at: datetime = gql_field(description="Timestamp when verification started")
    scan_time: float = gql_field(description="Time taken to complete verification in seconds")
    scanned_count: int = gql_field(description="Total number of files scanned")
    metadata: ArtifactVerifierMetadataGQL = gql_added_field(
        BackendAIGQLMeta(
            added_version="26.1.0", description="Additional metadata from the verifier."
        )
    )
    error: str | None = gql_field(
        description="Fatal error message if the verifier failed to complete"
    )


@gql_pydantic_type(
    BackendAIGQLMeta(
        added_version="25.17.0",
        description="Entry for a single verifier's result in the verification results. Associates a verifier name with its scan results.",
    ),
    model=ArtifactVerifierGQLResultEntryDTO,
    name="ArtifactVerifierResultEntry",
)
class ArtifactVerifierGQLResultEntry(PydanticOutputMixin[ArtifactVerifierGQLResultEntryDTO]):
    name: str = gql_field(description="Name of the verifier (e.g., 'clamav', 'custom')")
    result: ArtifactVerifierGQLResult = gql_field(description="Scan result from this verifier")


@gql_pydantic_type(
    BackendAIGQLMeta(
        added_version="25.17.0",
        description="Complete verification result containing results from all configured verifiers. Artifacts undergo malware scanning through multiple verifiers after being imported. This type aggregates results from all verifiers that were run on the artifact.",
    ),
    model=ArtifactVerificationGQLResultDTO,
    name="ArtifactVerificationResult",
)
class ArtifactVerificationGQLResult(PydanticOutputMixin[ArtifactVerificationGQLResultDTO]):
    verifiers: list[ArtifactVerifierGQLResultEntry] = gql_field(
        description="Results from each verifier that scanned the artifact"
    )


@gql_pydantic_input(
    BackendAIGQLMeta(
        description=dedent_strip("""
        Filter options for artifacts based on various criteria such as type, name, registry,
        source, and availability status.

        Supports logical operations (AND, OR, NOT) for complex filtering scenarios.
        """),
        added_version="25.14.0",
    ),
    name="ArtifactFilter",
)
class ArtifactFilter(PydanticInputMixin[ArtifactGQLFilterInputDTO]):
    type: list[ArtifactType] | None = None
    name: StringFilter | None = None
    registry: StringFilter | None = None
    source: StringFilter | None = None
    availability: list[ArtifactAvailability] | None = None

    AND: list[Self] | None = None
    OR: list[Self] | None = None
    NOT: list[Self] | None = None


@gql_pydantic_input(
    BackendAIGQLMeta(
        description=dedent_strip("""
            Specifies the field and direction for ordering artifacts in queries.
        """),
        added_version="24.09.0",
    ),
)
class ArtifactOrderBy(PydanticInputMixin[ArtifactGQLOrderByInputDTO], GQLOrderBy):
    field: ArtifactOrderField
    direction: OrderDirection = OrderDirection.ASC


@gql_pydantic_input(
    BackendAIGQLMeta(
        description=dedent_strip("""
            Filter for artifact revision status. Supports exact match or inclusion in a list of statuses.
        """),
        added_version="24.09.0",
    ),
)
class ArtifactRevisionStatusFilter(PydanticInputMixin[ArtifactRevisionStatusFilterDTO]):
    in_: list[ArtifactStatus] | None = gql_field(
        description="The in  field.", name="in", default=None
    )
    equals: ArtifactStatus | None = None


@gql_pydantic_input(
    BackendAIGQLMeta(description="", added_version="25.16.0"),
)
class ArtifactRevisionRemoteStatusFilter(PydanticInputMixin[ArtifactRevisionRemoteStatusFilterDTO]):
    in_: list[ArtifactRemoteStatus] | None = gql_field(
        description="The in  field.", name="in", default=None
    )
    equals: ArtifactRemoteStatus | None = None


@gql_pydantic_input(
    BackendAIGQLMeta(
        description=dedent_strip("""
        Filter options for artifact revisions based on status, version, artifact ID, and file size.

        Supports logical operations (AND, OR, NOT) for complex filtering scenarios.
        """),
        added_version="25.14.0",
    ),
    name="ArtifactRevisionFilter",
)
class ArtifactRevisionFilter(PydanticInputMixin[ArtifactRevisionGQLFilterInputDTO]):
    status: ArtifactRevisionStatusFilter | None = None
    remote_status: ArtifactRevisionRemoteStatusFilter | None = gql_added_field(
        BackendAIGQLMeta(
            added_version="25.16.0",
            description="Filter by remote synchronization status.",
        ),
        default=None,
    )
    version: StringFilter | None = None
    artifact_id: UUIDFilter | None = gql_field(description="The artifact id field.", default=None)
    size: IntFilter | None = None

    AND: list[Self] | None = None
    OR: list[Self] | None = None
    NOT: list[Self] | None = None


@gql_pydantic_input(
    BackendAIGQLMeta(
        description=dedent_strip("""
            Specifies the field and direction for ordering artifact revisions in queries.
        """),
        added_version="24.09.0",
    ),
)
class ArtifactRevisionOrderBy(PydanticInputMixin[ArtifactRevisionGQLOrderByInputDTO], GQLOrderBy):
    field: ArtifactRevisionOrderField
    direction: OrderDirection = OrderDirection.ASC


@gql_pydantic_input(
    BackendAIGQLMeta(
        description=dedent_strip("""
            Input for scanning artifacts from external registries (HuggingFace, Reservoir).

            Discovers available artifacts and registers their metadata in the system.
            Artifacts remain in SCANNED status until explicitly imported via import_artifacts.
        """),
        added_version="24.09.0",
    ),
)
class ScanArtifactsInput(PydanticInputMixin[ScanArtifactsInputDTO]):
    registry_id: ID | None = None
    limit: int = gql_field(description="The limit field.")
    artifact_type: ArtifactType | None = None
    search: str | None = None


@gql_pydantic_input(
    BackendAIGQLMeta(
        description=dedent_strip("""
            Options for importing artifact revisions.

            Controls import behavior such as forcing re-download regardless of digest freshness.
        """),
        added_version="24.09.0",
    ),
)
class ImportArtifactsOptionsGQL(PydanticInputMixin[ImportArtifactsOptionsInputDTO]):
    force: bool = gql_field(
        description="Force re-download regardless of digest freshness check.", default=False
    )


@gql_pydantic_input(
    BackendAIGQLMeta(
        description=dedent_strip("""
            Input for importing scanned artifact revisions from external registries.

            Downloads artifact files from the external source and transitions them through:
            SCANNED → PULLING → PULLED → AVAILABLE status progression.
        """),
        added_version="24.09.0",
    ),
)
class ImportArtifactsInput(PydanticInputMixin[ImportArtifactsInputDTO]):
    artifact_revision_ids: list[ID]
    vfolder_id: ID | None = gql_added_field(
        BackendAIGQLMeta(
            added_version="26.1.0",
            description="Target vfolder ID to store the imported artifacts.",
        ),
        default=None,
    )
    options: ImportArtifactsOptionsGQL | None = gql_added_field(
        BackendAIGQLMeta(
            added_version="26.1.0",
            description="Options controlling import behavior such as forcing re-download.",
        ),
        default=None,
    )


@gql_pydantic_input(
    BackendAIGQLMeta(description="", added_version="25.15.0"),
)
class DelegateeTarget(PydanticInputMixin[DelegateeTargetInputDTO]):
    delegatee_reservoir_id: ID
    target_registry_id: ID


@gql_pydantic_input(
    BackendAIGQLMeta(
        description=dedent_strip("""
            Input type for delegated scanning of artifacts from a delegatee reservoir registry's remote registry.
        """),
        added_version="24.09.0",
    ),
)
class DelegateScanArtifactsInput(PydanticInputMixin[DelegateScanArtifactsInputDTO]):
    delegator_reservoir_id: ID | None = gql_field(
        description="ID of the reservoir registry to delegate the scan request to", default=None
    )
    delegatee_target: DelegateeTarget | None = gql_field(
        description="Target delegatee reservoir registry and its remote registry to scan",
        default=None,
    )
    limit: int = gql_field(description="The limit field.")
    artifact_type: ArtifactType | None = gql_field(
        description="Filter artifacts by type (e.g., model, image, package)", default=None
    )
    search: str | None = gql_field(
        description="Search term to filter artifacts by name or description", default=None
    )


@gql_pydantic_input(
    BackendAIGQLMeta(
        description=dedent_strip("""
            Input type for delegated import of artifact revisions from a reservoir registry's remote registry.
            Used to specify which artifact revisions should be imported from the remote registry source
            into the local reservoir registry storage.
        """),
        added_version="24.09.0",
    ),
)
class DelegateImportArtifactsInput(PydanticInputMixin[DelegateImportArtifactsInputDTO]):
    artifact_revision_ids: list[ID] = gql_field(
        description="List of artifact revision IDs of delegatee artifact registry"
    )
    delegator_reservoir_id: ID | None = gql_field(
        description="ID of the reservoir registry to delegate the import request to", default=None
    )
    artifact_type: ArtifactType | None = gql_field(
        description="The artifact type field.", default=None
    )
    delegatee_target: DelegateeTarget | None = gql_field(
        description="The delegatee target field.", default=None
    )
    options: ImportArtifactsOptionsGQL | None = gql_added_field(
        BackendAIGQLMeta(
            added_version="26.1.0",
            description="Options controlling import behavior such as forcing re-download.",
        ),
        default=None,
    )


@gql_pydantic_input(
    BackendAIGQLMeta(
        description=dedent_strip("""
            Input for updating artifact metadata properties.

            Modifies artifact metadata such as readonly status and description.
            This operation does not affect the actual artifact files or revisions.
        """),
        added_version="24.09.0",
    ),
)
class UpdateArtifactInput(PydanticInputMixin[UpdateArtifactGQLInputDTO]):
    artifact_id: ID
    readonly: bool | None = UNSET
    description: str | None = UNSET


@gql_pydantic_input(
    BackendAIGQLMeta(
        description=dedent_strip("""
            Input for canceling an in-progress artifact import operation.

            Stops the download process and reverts the artifact revision status back to SCANNED.
        """),
        added_version="24.09.0",
    ),
)
class CancelArtifactInput(PydanticInputMixin[CancelArtifactInputDTO]):
    artifact_revision_id: ID


@gql_pydantic_input(
    BackendAIGQLMeta(
        description=dedent_strip("""
            Input for cleaning up stored artifact revision data.

            Removes downloaded files from storage and transitions the artifact revision
            back to SCANNED status, freeing up storage space.
        """),
        added_version="24.09.0",
    ),
)
class CleanupArtifactRevisionsInput(PydanticInputMixin[CleanupArtifactRevisionsInputDTO]):
    artifact_revision_ids: list[ID]


@gql_pydantic_input(
    BackendAIGQLMeta(
        description=dedent_strip("""
            Input for soft-deleting artifacts from the system.

            Marks artifacts as deleted without permanently removing them.
            Deleted artifacts can be restored using restore_artifacts.
        """),
        added_version="24.09.0",
    ),
)
class DeleteArtifactsInput(PydanticInputMixin[DeleteArtifactsInputDTO]):
    artifact_ids: list[ID]


@gql_pydantic_input(
    BackendAIGQLMeta(
        description=dedent_strip("""
            Input for restoring previously deleted artifacts.

            Reverses the soft-delete operation, making the artifacts available again.
        """),
        added_version="24.09.0",
    ),
)
class RestoreArtifactsInput(PydanticInputMixin[RestoreArtifactsInputDTO]):
    artifact_ids: list[ID]


@gql_pydantic_input(
    BackendAIGQLMeta(
        description=dedent_strip("""
            Input for approving an artifact revision.

            Admin-only operation to approve artifact revisions for general use.
        """),
        added_version="24.09.0",
    ),
)
class ApproveArtifactInput(PydanticInputMixin[ApproveArtifactInputDTO]):
    artifact_revision_id: ID


@gql_pydantic_input(
    BackendAIGQLMeta(
        description=dedent_strip("""
            Input for rejecting an artifact revision.

            Admin-only operation to reject artifact revisions, preventing their use.
        """),
        added_version="24.09.0",
    ),
)
class RejectArtifactInput(PydanticInputMixin[RejectArtifactInputDTO]):
    artifact_revision_id: ID


@gql_pydantic_input(
    BackendAIGQLMeta(
        description=dedent_strip("""
            Input for subscribing to artifact status change notifications.

            Used with artifact_status_changed subscription to receive real-time updates
            when artifact revision statuses change.
        """),
        added_version="24.09.0",
    ),
)
class ArtifactStatusChangedInput(PydanticInputMixin[ArtifactStatusChangedInputDTO]):
    artifact_revision_ids: list[ID]


@gql_pydantic_input(
    BackendAIGQLMeta(
        description=dedent_strip("""
            Specifies a target model for scanning operations.

            Used to identify specific models in external registries for detailed scanning.
            If revision is not specified, defaults to 'main' revision.
        """),
        added_version="24.09.0",
    ),
)
class ModelTarget(PydanticInputMixin[ModelTargetInputDTO]):
    model_id: str
    revision: str | None = None


@gql_pydantic_input(
    BackendAIGQLMeta(
        description=dedent_strip("""
            Input for batch scanning of specific models from external registries.

            Scans multiple specified models and retrieves detailed information including
            README content and file sizes. This operation performs immediate detailed scanning
            unlike the general scan_artifacts which only retrieves basic metadata.
        """),
        added_version="24.09.0",
    ),
)
class ScanArtifactModelsInput(PydanticInputMixin[ScanArtifactModelsInputDTO]):
    models: list[ModelTarget]
    registry_id: uuid.UUID | None = None


# Object Types
@gql_pydantic_type(
    BackendAIGQLMeta(
        added_version="25.14.0",
        description="Information about the source or registry of an artifact. Contains the name and URL of the registry where the artifact is stored or originates from.",
    ),
    model=SourceInfoDTO,
)
class SourceInfo:
    name: strawberry.auto
    url: strawberry.auto


@gql_node_type(
    BackendAIGQLMeta(
        added_version="25.14.0",
        description="An artifact represents AI models, packages, images, or other resources that can be stored, managed, and used within Backend.AI. Artifacts are discovered through scanning external registries and can have multiple revisions. Each artifact contains metadata and references to its source registry. Key concepts: Type (MODEL, PACKAGE, or IMAGE), Availability (ALIVE or DELETED), Source (original external registry where it was discovered).",
    ),
)
class Artifact(PydanticNodeMixin[ArtifactGQLNode]):
    id: NodeID[str]
    name: str
    type: ArtifactType
    description: str | None
    registry: SourceInfo
    source: SourceInfo
    readonly: bool
    extra: JSON | None
    scanned_at: datetime
    updated_at: datetime
    availability: ArtifactAvailability

    @gql_field(description="The revisions of this entity.")  # type: ignore[misc]
    async def revisions(
        self,
        info: Info[StrawberryGQLContext],
        filter: ArtifactRevisionFilter | None = None,
        order_by: list[ArtifactRevisionOrderBy] | None = None,
        before: str | None = None,
        after: str | None = None,
        first: int | None = None,
        last: int | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> ArtifactRevisionConnection:
        pydantic_filter = filter.to_pydantic() if filter is not None else None
        pydantic_order = [o.to_pydantic() for o in order_by] if order_by is not None else None

        base_conditions = [ArtifactRevisionConditions.by_artifact_id(uuid.UUID(self.id))]

        search_input = AdminSearchArtifactRevisionsInput(
            filter=pydantic_filter,
            order=pydantic_order,
            first=first,
            after=after,
            last=last,
            before=before,
            limit=limit,
            offset=offset,
        )
        payload = await info.context.adapters.artifact.search_revisions_gql(
            search_input,
            base_conditions=base_conditions,
        )

        edges = []
        for item in payload.items:
            revision = ArtifactRevision(
                id=ID(str(item.id)),
                status=ArtifactStatus(item.status.value),
                remote_status=ArtifactRemoteStatus(item.remote_status)
                if item.remote_status
                else None,
                readme=None,
                version=item.version,
                size=ByteSize(item.size) if item.size is not None else None,
                created_at=item.created_at,
                updated_at=item.updated_at,
                digest=None,
                verification_result=None,
            )
            cursor = encode_cursor(item.id)
            edges.append(ArtifactRevisionEdge(node=revision, cursor=cursor))

        page_info = strawberry.relay.PageInfo(
            has_next_page=payload.has_next_page,
            has_previous_page=payload.has_previous_page,
            start_cursor=edges[0].cursor if edges else None,
            end_cursor=edges[-1].cursor if edges else None,
        )

        return ArtifactRevisionConnection(
            count=payload.total_count,
            edges=edges,
            page_info=page_info,
        )


@gql_node_type(
    BackendAIGQLMeta(
        added_version="25.14.0",
        description="A specific version/revision of an artifact containing the actual file data. Artifact revisions progress through different statuses: SCANNED (discovered in external registry, metadata only), PULLING (currently downloading from external source), PULLED (downloaded to temporary storage), AVAILABLE (ready for use by users). Contains version information, file size, README content, and timestamps. Most HuggingFace models only have a 'main' revision.",
    ),
)
class ArtifactRevision(PydanticNodeMixin[ArtifactRevisionNode]):
    id: NodeID[str]
    status: ArtifactStatus
    remote_status: ArtifactRemoteStatus | None = gql_added_field(
        BackendAIGQLMeta(
            added_version="25.15.0",
            description="Remote synchronization status of the artifact revision.",
        )
    )
    version: str
    readme: str | None
    size: ByteSize | None
    created_at: datetime | None
    updated_at: datetime | None
    digest: str | None = gql_added_field(
        BackendAIGQLMeta(
            added_version="25.17.0",
            description="Digest at the time of import. None for models that have not been imported.",
        )
    )
    verification_result: ArtifactVerificationGQLResult | None = gql_added_field(
        BackendAIGQLMeta(
            added_version="25.17.0",
            description="Verification result containing malware scan results from all verifiers. None if not yet verified.",
        )
    )

    @classmethod
    async def resolve_nodes(  # type: ignore[override]  # Strawberry Node uses AwaitableOrValue overloads incompatible with async def
        cls,
        *,
        info: Info[StrawberryGQLContext],
        node_ids: Iterable[str],
        required: bool = False,
    ) -> Iterable[Self | None]:
        # DataLoader already returns ArtifactRevision | None via from_pydantic.
        # cast is required because mypy cannot unify list[ArtifactRevision | None]
        # with Iterable[Self | None] across generic DataLoader[UUID, ArtifactRevision | None].
        results = await info.context.data_loaders.artifact_revision_loader.load_many([
            uuid.UUID(nid) for nid in node_ids
        ])
        return cast(list[Self | None], results)

    @gql_field(description="The artifact of this entity.")  # type: ignore[misc]
    async def artifact(self, info: Info[StrawberryGQLContext]) -> Artifact:
        revision_node = await info.context.adapters.artifact.get_revision(uuid.UUID(self.id))
        artifact_node = await info.context.adapters.artifact.get(revision_node.artifact_id)

        data_loaders = info.context.data_loaders
        registry_url = await get_registry_url(
            data_loaders,
            artifact_node.registry_id,
            artifact_node.registry_type,
        )
        source_url = await get_registry_url(
            data_loaders,
            artifact_node.source_registry_id,
            artifact_node.source_registry_type,
        )

        return Artifact.from_pydantic(to_artifact_gql_node(artifact_node, registry_url, source_url))


def to_artifact_gql_node(node: ArtifactNode, registry_url: str, source_url: str) -> ArtifactGQLNode:
    """Build an ArtifactGQLNode DTO from an ArtifactNode and resolved registry URLs."""
    return ArtifactGQLNode(
        id=node.id,
        name=node.name,
        type=node.type,
        description=node.description,
        registry=SourceInfoDTO(name=node.registry_type.value, url=registry_url),
        source=SourceInfoDTO(name=node.source_registry_type.value, url=source_url),
        readonly=node.readonly,
        extra=node.extra,
        scanned_at=node.scanned_at,
        updated_at=node.updated_at,
        availability=node.availability,
    )


def make_artifact_revision_from_node(node: ArtifactRevisionNode) -> ArtifactRevision:
    """Create an ArtifactRevision GQL type from an ArtifactRevisionNode DTO (search result)."""
    return ArtifactRevision(
        id=ID(str(node.id)),
        status=ArtifactStatus(node.status.value),
        remote_status=ArtifactRemoteStatus(node.remote_status) if node.remote_status else None,
        readme=None,
        version=node.version,
        size=ByteSize(node.size) if node.size is not None else None,
        created_at=node.created_at,
        updated_at=node.updated_at,
        digest=None,
        verification_result=None,
    )


ArtifactEdge = Edge[Artifact]
ArtifactRevisionEdge = Edge[ArtifactRevision]


@gql_connection_type(
    BackendAIGQLMeta(
        added_version="25.14.0",
        description="Paginated connection for artifacts with total count information. Used for relay-style pagination with cursor-based navigation.",
    ),
)
class ArtifactConnection(Connection[Artifact]):
    count: int

    def __init__(self, *args: Any, count: int, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self.count = count


@gql_connection_type(
    BackendAIGQLMeta(
        added_version="25.14.0",
        description="Paginated connection for artifact revisions with total count information. Used for relay-style pagination with cursor-based navigation.",
    ),
)
class ArtifactRevisionConnection(Connection[ArtifactRevision]):
    count: int

    def __init__(self, *args: Any, count: int, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self.count = count


@gql_pydantic_type(
    BackendAIGQLMeta(
        added_version="25.14.0",
        description="Payload for artifact import progress subscription events. Provides real-time updates during the artifact import process, including progress percentage and current status.",
    ),
    model=ArtifactImportProgressUpdatedGQLPayload,
)
class ArtifactImportProgressUpdatedPayload:
    artifact_id: ID = gql_field(description="Artifact revision ID.")
    progress: float = gql_field(description="Import progress as a percentage.")
    status: ArtifactStatus = gql_field(description="Current import status.")


@gql_pydantic_type(
    BackendAIGQLMeta(
        added_version="25.14.0",
        description="Response payload for artifact scanning operations. Contains the list of artifacts discovered during scanning of external registries. These artifacts are registered with SCANNED status and can be imported for actual use.",
    ),
    model=ScanArtifactsGQLPayload,
)
class ScanArtifactsPayload(PydanticOutputMixin[ScanArtifactsGQLPayload]):
    artifacts: list[Artifact]


@gql_pydantic_type(
    BackendAIGQLMeta(
        added_version="25.15.0",
        description="Response payload for delegated artifact scanning operation. Contains the list of artifacts discovered during the scan of a reservoir registry's remote registry. These artifacts are now available for import or direct use.",
    ),
    model=DelegateScanArtifactsGQLPayload,
)
class DelegateScanArtifactsPayload(PydanticOutputMixin[DelegateScanArtifactsGQLPayload]):
    artifacts: list[Artifact] = gql_field(
        description="List of artifacts discovered during the delegated scan from the reservoir registry's remote registry"
    )


@gql_pydantic_type(
    BackendAIGQLMeta(
        added_version="25.14.0",
        description="Represents a background task for importing an artifact revision. Contains the task ID for monitoring progress and the associated artifact revision being imported from external registries.",
    ),
    model=ArtifactRevisionImportTaskInfoGQL,
)
class ArtifactRevisionImportTask(PydanticOutputMixin[ArtifactRevisionImportTaskInfoGQL]):
    task_id: ID | None
    artifact_revision: ArtifactRevision


# Mutation Payloads
@gql_pydantic_type(
    BackendAIGQLMeta(
        added_version="25.14.0",
        description="Response payload for artifact import operations. Contains the imported artifact revisions and their associated background tasks. Tasks can be monitored to track the import progress from SCANNED to AVAILABLE status.",
    ),
    model=ImportArtifactsGQLPayload,
)
class ImportArtifactsPayload(PydanticOutputMixin[ImportArtifactsGQLPayload]):
    artifact_revisions: ArtifactRevisionConnection
    tasks: list[ArtifactRevisionImportTask]


@gql_pydantic_type(
    BackendAIGQLMeta(
        added_version="25.15.0",
        description="Response payload for delegated artifact import operation. Contains the imported artifact revisions and associated background tasks. The tasks can be monitored to track the progress of the import operation.",
    ),
    model=DelegateImportArtifactsGQLPayload,
)
class DelegateImportArtifactsPayload(PydanticOutputMixin[DelegateImportArtifactsGQLPayload]):
    artifact_revisions: ArtifactRevisionConnection = gql_field(
        description="Connection of artifact revisions that were imported from the reservoir registry's remote registry"
    )
    tasks: list[ArtifactRevisionImportTask] = gql_field(
        description="List of background tasks created for importing the artifact revisions"
    )


@gql_pydantic_type(
    BackendAIGQLMeta(
        added_version="25.14.0",
        description="Response payload for artifact update operations. Returns the updated artifact with modified metadata properties.",
    ),
    model=UpdateArtifactGQLPayload,
)
class UpdateArtifactPayload(PydanticOutputMixin[UpdateArtifactGQLPayload]):
    artifact: Artifact


@gql_pydantic_type(
    BackendAIGQLMeta(
        added_version="25.14.0",
        description="Response payload for artifact revision cleanup operations. Contains the cleaned artifact revisions that have had their stored data removed, transitioning them back to SCANNED status to free storage space.",
    ),
    model=CleanupArtifactRevisionsGQLPayload,
)
class CleanupArtifactRevisionsPayload(PydanticOutputMixin[CleanupArtifactRevisionsGQLPayload]):
    artifact_revisions: ArtifactRevisionConnection


@gql_pydantic_type(
    BackendAIGQLMeta(
        added_version="25.14.0",
        description="Response payload for artifact revision approval operations. Contains the approved artifact revision. Admin-only operation.",
    ),
    model=ApproveArtifactGQLPayload,
)
class ApproveArtifactPayload(PydanticOutputMixin[ApproveArtifactGQLPayload]):
    artifact_revision: ArtifactRevision


@gql_pydantic_type(
    BackendAIGQLMeta(
        added_version="25.14.0",
        description="Response payload for artifact revision rejection operations. Contains the rejected artifact revision. Admin-only operation.",
    ),
    model=RejectArtifactGQLPayload,
)
class RejectArtifactPayload(PydanticOutputMixin[RejectArtifactGQLPayload]):
    artifact_revision: ArtifactRevision


@gql_pydantic_type(
    BackendAIGQLMeta(
        added_version="25.14.0",
        description="Response payload for canceling artifact import operations. Contains the artifact revision whose import was canceled, reverting its status back to SCANNED.",
    ),
    model=CancelImportArtifactGQLPayload,
)
class CancelImportArtifactPayload(PydanticOutputMixin[CancelImportArtifactGQLPayload]):
    artifact_revision: ArtifactRevision


@gql_pydantic_type(
    BackendAIGQLMeta(
        added_version="25.14.0",
        description="Payload for artifact status change subscription events. Provides real-time notifications when artifact revision statuses change during import, cleanup, or other operations.",
    ),
    model=ArtifactStatusChangedGQLPayload,
)
class ArtifactStatusChangedPayload(PydanticOutputMixin[ArtifactStatusChangedGQLPayload]):
    artifact_revision: ArtifactRevision


@gql_pydantic_type(
    BackendAIGQLMeta(
        added_version="25.14.0",
        description="Response payload for batch model scanning operations. Contains the artifact revisions discovered during detailed scanning of specific models, including README content and file size information.",
    ),
    model=ScanArtifactModelsGQLPayload,
)
class ScanArtifactModelsPayload(PydanticOutputMixin[ScanArtifactModelsGQLPayload]):
    artifact_revision: ArtifactRevisionConnection


@gql_pydantic_type(
    BackendAIGQLMeta(
        added_version="25.15.0",
        description="Response payload for artifact deletion operations. Contains the artifacts that were soft-deleted. These can be restored later.",
    ),
    model=DeleteArtifactsGQLPayload,
)
class DeleteArtifactsPayload(PydanticOutputMixin[DeleteArtifactsGQLPayload]):
    artifacts: list[Artifact]


@gql_pydantic_type(
    BackendAIGQLMeta(
        added_version="25.15.0",
        description="Response payload for artifact restoration operations. Contains the artifacts that were restored from soft-deleted state.",
    ),
    model=RestoreArtifactsGQLPayload,
)
class RestoreArtifactsPayload(PydanticOutputMixin[RestoreArtifactsGQLPayload]):
    artifacts: list[Artifact]
