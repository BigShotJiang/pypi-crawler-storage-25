from typing import override

from ai.backend.common.contexts.user import current_user
from ai.backend.manager.actions.action import BaseActionTriggerMeta
from ai.backend.manager.actions.action.single_entity import BaseSingleEntityAction
from ai.backend.manager.actions.validator.single_entity import SingleEntityActionValidator
from ai.backend.manager.data.permission.role import ScopeChainPermissionCheckInput
from ai.backend.manager.errors.permission import NotEnoughPermission
from ai.backend.manager.errors.user import UserNotFound
from ai.backend.manager.repositories.permission_controller.repository import (
    PermissionControllerRepository,
)


class SingleEntityActionRBACValidator(SingleEntityActionValidator):
    def __init__(
        self,
        repository: PermissionControllerRepository,
    ) -> None:
        self._repository = repository

    @override
    async def validate(self, action: BaseSingleEntityAction, meta: BaseActionTriggerMeta) -> None:
        user = current_user()
        if user is None:
            raise UserNotFound("User not found in context")
        if user.is_superadmin:
            return

        allowed = await self._repository.check_permission_with_scope_chain(
            ScopeChainPermissionCheckInput(
                user_id=user.user_id,
                target_element_ref=action.target_element(),
                operation=action.operation_type().to_permission_operation(),
                permission_entity_type=None,
            )
        )
        if not allowed:
            raise NotEnoughPermission(
                f"User {user.user_id} lacks permission "
                f"{action.operation_type().to_permission_operation()} "
                f"on {action.target_element()}"
            )
