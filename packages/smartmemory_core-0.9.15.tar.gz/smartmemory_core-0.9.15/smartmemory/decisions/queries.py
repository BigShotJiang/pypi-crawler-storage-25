"""Decision query patterns.

Path C migration (CORE-MANAGED-TYPE-FRAMEWORK-1 Phase 2): subclass of the
framework-derived `_DecisionQueriesBase`. Domain-specific methods (provenance
chains, causal traversal) stay handwritten; standard list/lookup methods are
inherited from the base.
"""

from __future__ import annotations

import logging
from typing import Any, Literal

from smartmemory.decisions.declaration import _DecisionQueriesBase

logger = logging.getLogger(__name__)


class DecisionQueries(_DecisionQueriesBase):
    """Query patterns for decisions - filtered retrieval, provenance, causal chains.

    Usage:
        queries = DecisionQueries(smart_memory)
        active = queries.get_active_decisions(domain="preferences")
        chain = queries.get_causal_chain(decision_id, direction="causes")
    """

    # ---- Hydration override (content fallback) -------------------------

    def _hydrate(self, item: Any):
        """Convert a MemoryItem (or dict) to a Decision with content fallback.

        Mirrors legacy DecisionQueries._to_decision (queries.py:241-255).
        """
        from smartmemory.models.decision import Decision

        if item is None:
            return None
        if isinstance(item, Decision):
            return item
        metadata = getattr(item, "metadata", None)
        if isinstance(item, dict):
            metadata = item.get("metadata", item)
        if not isinstance(metadata, dict):
            return None
        if "content" not in metadata or not metadata["content"]:
            content = getattr(item, "content", None) or (item.get("content") if isinstance(item, dict) else "")
            metadata["content"] = content
        return Decision.from_dict(metadata)

    # alias used by existing tests
    _to_decision = _hydrate

    # ---- Filtered retrieval (legacy API surface) -----------------------

    def get_active_decisions(
        self,
        domain: str | None = None,
        decision_type: str | None = None,
        min_confidence: float = 0.0,
        limit: int = 50,
    ) -> list:
        """Get all active decisions, optionally filtered.

        Uses direct graph query first (decisions are INDEXED — no embeddings,
        so search(query="*") is unreliable). Falls back to search() if the
        graph query path isn't available.
        """
        items = self._list_decisions_via_graph(limit * 2)
        if not items:
            try:
                items = self.memory.search(query="*", memory_type="decision", top_k=limit * 2)
            except Exception:
                items = []
            if not items:
                try:
                    items = self.memory.search(query="decision", memory_type="decision", top_k=limit * 2)
                except Exception:
                    items = []
            if not items:
                try:
                    items = self.memory.search(query="decision choice belief policy", top_k=limit * 2)
                    items = [i for i in items if getattr(i, "memory_type", None) == "decision"]
                except Exception as e:
                    logger.warning(f"Failed to search for decisions: {e}")
                    return []

        decisions = []
        for item in items:
            d = self._hydrate(item)
            if d is None or not d.is_active:
                continue
            if domain and d.domain != domain:
                continue
            if decision_type and d.decision_type != decision_type:
                continue
            if d.confidence < min_confidence:
                continue
            decisions.append(d)
            if len(decisions) >= limit:
                break

        return decisions

    def _list_decisions_via_graph(self, limit: int) -> list:
        """Direct graph query for decision nodes — bypasses vector search."""
        try:
            graph = getattr(self.memory, "_graph", None) or getattr(self.memory, "graph", None)
            if graph is None:
                return []
            backend = getattr(graph, "backend", None) or getattr(graph, "_backend", None)
            if backend is None:
                return []
            # Scope by workspace if available (SecureSmartMemory injects scope)
            scope = getattr(self.memory, "_scope_provider", None)
            ws_id = None
            if scope:
                try:
                    ws_id = scope.workspace.id
                except Exception:
                    pass
            if ws_id:
                query = (
                    "MATCH (n) WHERE n.memory_type = 'decision' AND n.item_id STARTS WITH 'dec_' "
                    "AND n.workspace_id = $ws "
                    "RETURN n ORDER BY n.created_at DESC LIMIT $limit"
                )
                result = backend.graph.query(query, {"ws": ws_id, "limit": limit})
            else:
                result = backend.graph.query(
                    "MATCH (n) WHERE n.memory_type = 'decision' AND n.item_id STARTS WITH 'dec_' "
                    "RETURN n ORDER BY n.created_at DESC LIMIT $limit",
                    {"limit": limit},
                )
            # FalkorDB nodes carry Decision fields as top-level properties
            # (decision_id, status, superseded_by, created_at, ...). _hydrate()'s
            # dict branch falls back to `item.get("metadata", item)`, so passing
            # the raw props dict lets Decision.from_dict() see every field.
            # Wrapping as MemoryItem first would strip the decision-specific fields.
            items = []
            for row in result.result_set:
                node = row[0]
                props = node.properties if hasattr(node, "properties") else node
                items.append(props)
            return items
        except Exception as e:
            logger.debug(f"Graph-based decision listing failed, will fall back to search: {e}")
            return []

    def get_decisions_about(self, topic: str, limit: int = 20) -> list:
        """Get active decisions related to a topic via semantic search."""
        try:
            items = self.memory.search(query=topic, memory_type="decision", top_k=limit)
        except Exception as e:
            logger.warning(f"Failed to search decisions for topic '{topic}': {e}")
            return []

        decisions = []
        for item in items:
            d = self._hydrate(item)
            if d is not None and d.is_active:
                decisions.append(d)

        return decisions

    # ---- Graph traversal (domain-specific) -----------------------------

    def get_decision_provenance(self, decision_id: str) -> dict[str, Any]:
        """Get full provenance chain for a decision."""
        result: dict[str, Any] = {
            "decision": None,
            "reasoning_trace": None,
            "evidence": [],
            "superseded": [],
        }

        item = self.memory.get(decision_id)
        if item is None:
            return result
        result["decision"] = self._hydrate(item)

        if not self.graph:
            return result

        incoming = self.graph.get_incoming_neighbors(decision_id, edge_type="PRODUCED")
        if incoming:
            trace_node = incoming[0]
            result["reasoning_trace"] = trace_node

        # SmartGraph.get_neighbors returns [(MemoryItem, edge_type), ...] — unpack
        # the tuple before passing to consumers. Skipping this unwrap silently
        # drops every neighbor: _hydrate(tuple) returns None, and getattr(tuple,
        # "item_id", None) is None too.
        neighbors = self.graph.get_neighbors(decision_id, edge_type="DERIVED_FROM")
        if neighbors:
            for entry in neighbors:
                node = entry[0] if isinstance(entry, tuple) else entry
                node_id = node.get("item_id") if isinstance(node, dict) else getattr(node, "item_id", None)
                result["evidence"].append({
                    "memory": node,
                    "memory_id": node_id,
                })

        superseded = self.graph.get_neighbors(decision_id, edge_type="SUPERSEDES")
        if superseded:
            for entry in superseded:
                node = entry[0] if isinstance(entry, tuple) else entry
                d = self._hydrate(node)
                if d:
                    result["superseded"].append(d)

        return result

    def get_decisions_with_provenance(
        self,
        memory_id: str,
        *,
        max_depth: int = 3,
        limit: int = 50,
        domain: str | None = None,
        decision_type: str | None = None,
        min_confidence: float = 0.0,
    ) -> list[Any]:
        """Find active decisions whose provenance subgraph contains ``memory_id``.

        Inverse of ``get_decision_provenance``: walks **incoming** ``DERIVED_FROM``
        and ``CAUSED_BY`` edges from the seed memory back toward decisions. Mirrors
        the edge vocabulary of ``_traverse_causes`` but uses
        ``graph.get_incoming_neighbors`` (the inverse direction of the forward walk).

        Scope-gated at both ends via ``self.memory.get()``: the seed memory must be
        visible to the caller (else returns ``[]``), and each candidate decision
        must also be visible before inclusion. Required because ``self.graph`` binds
        to raw ``memory._graph`` and backend traversal is unscoped
        (``framework.py:800``). The dual gate makes this safe to expose at the
        ``GET /memory/decisions?provenance_memory_id=`` route surface without
        leaking cross-workspace existence.

        In-query filter composition: ``domain`` / ``decision_type`` /
        ``min_confidence`` consume candidates **before** they count against
        ``limit``. A call with ``limit=10`` returns exactly 10 matching-and-filtered
        decisions when that many exist, never silently fewer.

        Visited set guards against cycles; ``seen_decisions`` dict guards against
        emitting the same decision twice when multiple provenance paths converge
        on the seed memory. (NB: the pre-existing ``_traverse_causes`` /
        ``_traverse_effects`` at queries.py:239+ lack both — they should be patched
        with the same pattern in a follow-up, but that is out of scope for
        CORE-DECISION-PROVENANCE-LOOKUP-1.)
        """
        # Entry scope gate: verify the seed memory is visible to the caller.
        # Returns [] (not 404 / not raise) for unknown OR out-of-scope ids — these
        # two cases must be indistinguishable to prevent existence leakage.
        seed = self.memory.get(memory_id)
        if seed is None:
            return []
        if not self.graph:
            return []

        visited: set[str] = {memory_id}
        seen_decisions: dict[str, Any] = {}
        queue: list[tuple[str, int]] = [(memory_id, 0)]

        while queue and len(seen_decisions) < limit:
            node_id, depth = queue.pop(0)
            if depth >= max_depth:
                continue

            for edge_type in ("DERIVED_FROM", "CAUSED_BY"):
                try:
                    incoming = self.graph.get_incoming_neighbors(node_id, edge_type=edge_type)
                except Exception as e:
                    logger.warning("get_incoming_neighbors(%s, %s) failed: %s", node_id, edge_type, e)
                    continue

                for neighbor in incoming or []:
                    neighbor_id = (
                        neighbor.get("item_id") if isinstance(neighbor, dict)
                        else getattr(neighbor, "item_id", None)
                    )
                    if not neighbor_id or neighbor_id in visited:
                        continue
                    visited.add(neighbor_id)

                    memory_type = (
                        neighbor.get("memory_type") if isinstance(neighbor, dict)
                        else getattr(neighbor, "memory_type", None)
                    )

                    if memory_type == "decision":
                        # Exit scope gate: re-fetch via SecureSmartMemory so the
                        # caller's scope filter is applied. None ⇒ out of scope ⇒ skip.
                        item = self.memory.get(neighbor_id)
                        if item is None:
                            continue
                        decision = self._hydrate(item)
                        if decision is None:
                            continue
                        # Active-only (mirrors get_active_decisions default contract).
                        if not getattr(decision, "is_active", True):
                            continue
                        # In-query filter predicates. Consume before counting against limit.
                        if domain is not None and getattr(decision, "domain", None) != domain:
                            continue
                        if decision_type is not None and getattr(decision, "decision_type", None) != decision_type:
                            continue
                        if (getattr(decision, "confidence", 0.0) or 0.0) < min_confidence:
                            continue
                        seen_decisions[neighbor_id] = decision
                        if len(seen_decisions) >= limit:
                            break
                    else:
                        # Non-decision intermediate node — continue BFS.
                        queue.append((neighbor_id, depth + 1))

                if len(seen_decisions) >= limit:
                    break

        # Match the existing list path's contract: newest-first.
        # (Codex review of the diff 2026-05-23 — without this, BFS edge-enumeration
        # order leaks into the API surface and `limit` becomes non-deterministic.)
        decisions_out = list(seen_decisions.values())
        decisions_out.sort(
            key=lambda d: getattr(d, "created_at", "") or "",
            reverse=True,
        )
        return decisions_out

    def get_causal_chain(
        self,
        decision_id: str,
        direction: Literal["causes", "effects", "both"] = "both",
        max_depth: int = 3,
    ) -> dict[str, Any]:
        """Trace causal chain from a decision."""
        item = self.memory.get(decision_id)
        result: dict[str, Any] = {
            "decision": self._hydrate(item) if item else None,
            "causes": [],
            "effects": [],
        }

        if not self.graph or item is None:
            return result

        if direction in ("causes", "both"):
            result["causes"] = self._traverse_causes(decision_id, max_depth)

        if direction in ("effects", "both"):
            result["effects"] = self._traverse_effects(decision_id, max_depth)

        return result

    def _traverse_causes(self, node_id: str, max_depth: int, current_depth: int = 0) -> list[dict[str, Any]]:
        """Recursively traverse cause edges (DERIVED_FROM, CAUSED_BY)."""
        if current_depth >= max_depth or not self.graph:
            return []

        causes: list[dict[str, Any]] = []

        for edge_type in ["DERIVED_FROM", "CAUSED_BY"]:
            neighbors = self.graph.get_neighbors(node_id, edge_type=edge_type)
            if not neighbors:
                continue
            for node in neighbors:
                node_id_val = node.get("item_id") if isinstance(node, dict) else getattr(node, "item_id", None)
                causes.append({
                    "node": node,
                    "node_id": node_id_val,
                    "relationship": edge_type,
                    "depth": current_depth + 1,
                    "causes": self._traverse_causes(node_id_val, max_depth, current_depth + 1) if node_id_val else [],
                })

        return causes

    def _traverse_effects(self, node_id: str, max_depth: int, current_depth: int = 0) -> list[dict[str, Any]]:
        """Recursively traverse effect edges (CAUSES, INFLUENCES, PRODUCED)."""
        if current_depth >= max_depth or not self.graph:
            return []

        effects: list[dict[str, Any]] = []

        for edge_type in ["CAUSES", "INFLUENCES", "PRODUCED"]:
            neighbors = self.graph.get_neighbors(node_id, edge_type=edge_type)
            if not neighbors:
                continue
            for node in neighbors:
                node_id_val = node.get("item_id") if isinstance(node, dict) else getattr(node, "item_id", None)
                effects.append({
                    "node": node,
                    "node_id": node_id_val,
                    "relationship": edge_type,
                    "depth": current_depth + 1,
                    "effects": self._traverse_effects(node_id_val, max_depth, current_depth + 1) if node_id_val else [],
                })

        return effects
