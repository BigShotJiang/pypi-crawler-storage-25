"""
AMI SDK - Python Client for Memrail Adaptive Memory Intelligence API.

Public API exports.
"""

__version__ = "0.1.0"

# Atom builders and utilities
from memrail.atoms import atoms_from_dict
from memrail.builders import StateObject
from memrail.client import AMIClient
from memrail.async_client import AsyncAMIClient

# Prompt Registry models
from memrail.prompts import (
    PromptCreate,
    PromptUpdate,
    PromptMove,
    FolderCreate,
)

# Tool Registry exports
from memrail.tools import (
    # Registry and Executor
    ToolRegistry,
    ActionExecutor,
    ClaudeBridge,
    create_mcp_tool_handler,
    # Models
    ToolDefinition,
    ActionHandlers,
    Decision,
    ExecutionResult,
    AckResult,
    InvokeAndExecuteResult,
    ExecutorConfig,
    ShadowConfig,
    CanaryConfig,
    ExecutorSchema,
    # Enums
    ShadowMode,
    LifecycleState,
    MissingToolBehavior,
    # Configuration
    AMIToolConfig,
    ToolConfigError,
    load_config,
)

__all__ = [
    "__version__",
    # Builders
    "atoms_from_dict",
    "StateObject",
    # Clients
    "AMIClient",
    "AsyncAMIClient",
    # Prompt Registry Models
    "PromptCreate",
    "PromptUpdate",
    "PromptMove",
    "FolderCreate",
    # Tool Registry
    "ToolRegistry",
    "ActionExecutor",
    "ClaudeBridge",
    "create_mcp_tool_handler",
    # Tool Models
    "ToolDefinition",
    "ActionHandlers",
    "Decision",
    "ExecutionResult",
    "AckResult",
    "InvokeAndExecuteResult",
    "ExecutorConfig",
    "ShadowConfig",
    "CanaryConfig",
    "ExecutorSchema",
    # Enums
    "ShadowMode",
    "LifecycleState",
    "MissingToolBehavior",
    # Configuration
    "AMIToolConfig",
    "ToolConfigError",
    "load_config",
]
