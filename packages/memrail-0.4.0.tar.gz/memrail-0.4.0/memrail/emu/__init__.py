"""EMU (Executable Memory Unit) authoring and management."""
