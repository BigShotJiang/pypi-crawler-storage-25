"""
AMI CLI - Command-line tools for EMU management.

This package provides CLI tools for:
- Registering EMUs from project directories
- Validating EMU definitions locally
- Listing registered EMUs
- Managing AMI projects
"""

__version__ = "0.1.0"
