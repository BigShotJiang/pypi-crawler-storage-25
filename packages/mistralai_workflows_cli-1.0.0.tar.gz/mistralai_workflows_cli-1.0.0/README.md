# mistralai-workflows-cli

CLI to bootstrap a python project with mistralai Workflows SDK.

## Usage

```bash
uvx mistralai-workflows-cli setup
```

Or with options:

```bash
uvx mistralai-workflows-cli setup --api-key sk-... --project-name my-project
```

The `setup` command will:

1. Ask for a project name (or use `--project-name`)
2. Ask for a Mistral API key (or use `--api-key` / `MISTRAL_API_KEY` env var)
3. Scaffold a new project from the [workflows-starter-app](https://github.com/mistralai/workflows-starter-app) template
4. Suggest running `vibe` to start coding

## Development

```bash
cd tools/mistral-workflows
uv sync
uv run mistral-workflows --help
```

## Publishing

Tag with `mistral-workflows-cli/v<version>` to trigger the PyPI publish workflow.

```bash
git tag mistral-workflows-cli/v0.1.0
git push origin mistral-workflows-cli/v0.1.0
```
