from __future__ import annotations

from unittest.mock import patch

import pytest
from click.testing import CliRunner

from mistral_workflows_cli.main import cli
from mistral_workflows_cli.setup import run_setup


@pytest.fixture
def runner() -> CliRunner:
    return CliRunner()


def test_cli_has_setup_command(runner: CliRunner) -> None:
    result = runner.invoke(cli, ["--help"])
    assert result.exit_code == 0
    assert "setup" in result.output


def test_setup_fails_without_api_key(tmp_path: object) -> None:
    with patch("mistral_workflows_cli.setup.Prompt.ask", return_value=""):
        with pytest.raises(SystemExit) as exc_info:
            run_setup(api_key=None, output_dir=str(tmp_path), project_name="test-proj")
        assert exc_info.value.code == 1


def test_setup_fails_if_dir_exists(tmp_path: object) -> None:
    import pathlib

    (pathlib.Path(str(tmp_path)) / "existing").mkdir()
    with pytest.raises(SystemExit) as exc_info:
        run_setup(api_key="sk-test", output_dir=str(tmp_path), project_name="existing")
    assert exc_info.value.code == 1
