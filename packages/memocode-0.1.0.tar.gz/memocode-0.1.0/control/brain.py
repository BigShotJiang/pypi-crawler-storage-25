"""
Brain: control layer entry point.
Agentic tool-use loop — LLM decides when/which tools to call.
"""
from __future__ import annotations
import sys
import os
import threading
import time

# Insert paths first so control/chatmem/ (bundled) takes priority
_ROOT = os.path.dirname(os.path.dirname(__file__))
_CONTROL = os.path.dirname(__file__)
_DATA_DIR = os.path.expanduser("~/.mcode")
sys.path.insert(0, _ROOT)
sys.path.insert(0, _CONTROL)

from prompt_toolkit import prompt as _pt_prompt
from chatmem import ContextManager, ContextConfig
from .llm import make_adapter, ToolCall
from .planner import Task  # Task dataclass used for safety interface
from .audit import AuditLog
from .project_manager import ProjectManager
from .fmt import p_dim, p_info, p_warn, p_ok, p_err, dim, cyan, yellow, green, red, fmt_task_line
from tools.registry import ToolRegistry
from tools.shell import SHELL_TOOL
from tools.file import FILE_READ_TOOL, FILE_WRITE_TOOL, FILE_EDIT_TOOL, GLOB_TOOL, GREP_TOOL
from tools.loader import load_external_tools
import safety.safety as _safety


_CODE_BLOCK_RE = __import__("re").compile(r"```[^\n]*\n(.*?)```", __import__("re").DOTALL)
_THINK_RE = __import__("re").compile(r"<think>.*?</think>", __import__("re").DOTALL)
_MAX_CODE_LINES = 20


def _truncate_code_blocks(text: str) -> str:
    """Replace code blocks exceeding _MAX_CODE_LINES with a truncation notice."""
    def _replace(m):
        lang_line = m.group(0).split("\n", 1)[0]  # e.g. ```python
        body = m.group(1)
        lines = body.splitlines()
        if len(lines) <= _MAX_CODE_LINES:
            return m.group(0)
        return (
            f"{lang_line}\n"
            + "\n".join(lines[:_MAX_CODE_LINES])
            + f"\n```\n> ⚠️  代码已截断（共 {len(lines)} 行）。请让我用 file_write 写入文件。"
        )
    return _CODE_BLOCK_RE.sub(_replace, text)


def _tool_hint(call: ToolCall) -> str:
    """Return a one-line hint for the header line (first line only)."""
    if call.name == "shell_exec":
        cmd = call.args.get("command", "")
        first = next((l for l in cmd.splitlines() if l.strip()), cmd)
        return dim(f"$ {first}")
    if call.name in ("file_read", "file_write"):
        return dim(call.args.get("path", ""))
    return ""


def _print_tool_header(call: ToolCall):
    """Print tool call header + full multiline command if applicable."""
    hint = _tool_hint(call)
    print(cyan(f"▶  {call.name}") + (f"  {hint}" if hint else ""))
    if call.name == "shell_exec":
        lines = call.args.get("command", "").splitlines()
        if len(lines) > 1:
            for extra in lines[1:]:
                print(dim(f"   {extra}"))
    print(dim("   " + "─" * 56))


def _resolve_task_paths(tasks: list, work_dir: str) -> list:
    """Legacy helper kept for any remaining callers."""
    result = []
    for t in tasks:
        path_args = {
            "file_read": ["path"], "file_write": ["path"],
        }.get(t.tool, [])
        if not path_args:
            result.append(t)
            continue
        args = dict(t.args)
        for arg_name in path_args:
            p = args.get(arg_name, "")
            if (isinstance(p, str) and p
                    and not os.path.isabs(p)
                    and not p.startswith("~")
                    and "task_" not in p):   # skip {{task_N_output}} placeholders
                args[arg_name] = os.path.join(work_dir, p)
        result.append(Task(
            id=t.id, tool=t.tool, args=args,
            description=t.description, depends_on=t.depends_on,
            reversible=t.reversible, backup_paths=t.backup_paths,
        ))
    return result


_DEFAULT_CHATMEM = {
    "llm": {},
    "dimensions": {
        "identity":      {"label": "Who I am",         "stability": 50.0},
        "values":        {"label": "What I believe",   "stability": 40.0},
        "goals":         {"label": "What I want",      "stability": 30.0},
        "preferences":   {"label": "Likes / dislikes", "stability": 25.0},
        "capabilities":  {"label": "What I can do",    "stability": 30.0},
        "emotional":     {"label": "How I react",      "stability": 20.0},
        "autobiography": {"label": "Key experiences",  "stability": 35.0},
    },
}

_DEFAULT_AGENT = {
    "auto_confirm": True,
    "verbose": False,
    "llm_timeout": 30,
    "max_tool_iter": 40,
    "max_tool_output": 20000,
    "require_confirm_on_irreversible": True,
    "active_model": "",
    "models": {},
}


def _init_data_dir() -> tuple[str, str]:
    """
    Ensure ~/.mcode/ exists with agent.json and chatmem.json.
    Migrates from control/ if old files exist and new ones don't.
    Returns (agent_json_path, chatmem_json_path).
    """
    import json as _json
    import shutil as _shutil

    os.makedirs(_DATA_DIR, exist_ok=True)
    os.makedirs(os.path.join(_DATA_DIR, "tools"), exist_ok=True)

    agent_path = os.path.join(_DATA_DIR, "agent.json")
    chatmem_path = os.path.join(_DATA_DIR, "chatmem.json")

    # Migrate agent.json from old location
    old_agent = os.path.join(_CONTROL, "agent.json")
    if not os.path.exists(agent_path):
        if os.path.exists(old_agent):
            _shutil.copy2(old_agent, agent_path)
        else:
            with open(agent_path, "w") as f:
                _json.dump(_DEFAULT_AGENT, f, indent=2, ensure_ascii=False)
                f.write("\n")

    # Migrate chatmem.json from old location (only dimensions, llm is auto-managed)
    old_chatmem = os.path.join(_CONTROL, "chatmem.json")
    if not os.path.exists(chatmem_path):
        if os.path.exists(old_chatmem):
            _shutil.copy2(old_chatmem, chatmem_path)
        else:
            with open(chatmem_path, "w") as f:
                _json.dump(_DEFAULT_CHATMEM, f, indent=2, ensure_ascii=False)
                f.write("\n")

    return agent_path, chatmem_path


def _sync_active_model(agent_cfg: dict, chatmem_json_path: str | None):
    """Write the active model profile into chatmem.json's llm section."""
    if not chatmem_json_path or not os.path.exists(chatmem_json_path):
        return
    models = agent_cfg.get("models", {})
    active = agent_cfg.get("active_model", "")
    profile = models.get(active)
    if not profile:
        return
    import json as _json
    with open(chatmem_json_path) as f:
        data = _json.load(f)
    # Replace llm section with profile entirely (don't merge — avoids stale keys from previous model)
    # Preserve non-LLM keys in existing llm section that aren't model-specific (none currently)
    data["llm"] = dict(profile)
    with open(chatmem_json_path, "w") as f:
        _json.dump(data, f, indent=2, ensure_ascii=False)
        f.write("\n")


class Brain:
    def __init__(
        self,
        auto_confirm: bool | None = None,
        config_path: str | None = None,
        verbose: bool | None = None,
        project: str | None = None,
    ):
        # Ensure ~/.mcode/ exists; migrate old files if needed
        agent_path, chatmem_path = _init_data_dir()

        self._agent_cfg_path = agent_path
        self._config_path = config_path or chatmem_path

        import json as _json
        agent_cfg: dict = {}
        if os.path.exists(self._agent_cfg_path):
            with open(self._agent_cfg_path) as f:
                agent_cfg = _json.load(f)

        # Sync active model profile → chatmem.json before loading ContextConfig
        _sync_active_model(agent_cfg, chatmem_path)

        cfg = ContextConfig.from_json(chatmem_path)

        # Agent-level config (CLI args override chatmem.json)
        self.auto_confirm = auto_confirm if auto_confirm is not None else agent_cfg.get("auto_confirm", True)
        self.verbose = verbose if verbose is not None else agent_cfg.get("verbose", False)
        llm_timeout: int = agent_cfg.get("llm_timeout", 30)
        self._agent_cfg = agent_cfg

        self.llm = make_adapter(cfg, timeout=llm_timeout)

        # Validate API key is resolvable (fail fast with a clear message)
        # Resolve API key — resolve_api_key() returns None (doesn't raise) when missing
        _api_key = cfg.llm.resolve_api_key()
        if not _api_key:
            active = agent_cfg.get("active_model", "")
            profile = agent_cfg.get("models", {}).get(active, {})
            env_var = profile.get("api_key_env", "")
            msg = f"API key not found for model '{active}'."
            if env_var:
                msg += f" Set the {env_var} environment variable."
            raise RuntimeError(msg)

        # Project/session management
        self.projects = ProjectManager()
        if project:
            self.projects.switch_project(project)
        else:
            self.projects.find_or_create_for_cwd()

        # Memory layer — one DB per project, core DB shared
        self.memory = ContextManager.create(
            config=cfg,
            api_key=_api_key,
            db_path=self.projects.project_db_path,
            core_db_path=self.projects.core_db_path,
        )

        # Audit log
        self.audit = AuditLog(os.path.join(_DATA_DIR, "audit.db"))

        # Tool registry — built-ins + auto-discovered externals
        self.registry = ToolRegistry()
        self.registry.register(SHELL_TOOL)
        self.registry.register(FILE_READ_TOOL)
        self.registry.register(FILE_WRITE_TOOL)
        self.registry.register(FILE_EDIT_TOOL)
        self.registry.register(GLOB_TOOL)
        self.registry.register(GREP_TOOL)
        load_external_tools(self.registry)

        self._max_tool_iter: int = agent_cfg.get("max_tool_iter", 20)
        self._max_tool_output: int = agent_cfg.get("max_tool_output", 20000)

        # Interrupt support
        self._stop_event = threading.Event()
        self._last_was_action = False
        self._spinner_stop: threading.Event | None = None  # set by run.py before each turn

    # ------------------------------------------------------------------
    # Main entry point
    # ------------------------------------------------------------------

    def run(self, user_input: str, dry_run: bool = False) -> str:
        """Process one user turn. Returns response string."""
        return "".join(self.stream_run(user_input, dry_run=dry_run))

    def stream_run(self, user_input: str, dry_run: bool = False):
        """Generator for the REPL. Yields text chunks."""
        self._stop_event.clear()
        yield from self._agent_loop(user_input, dry_run=dry_run)

    def _agent_loop(self, user_input: str, dry_run: bool = False):
        """
        Tool-use agentic loop. Generator — yields text chunks.
        LLM decides when and which tools to call. No separate intent classifier.
        """
        _system = (
            "You are a capable AI agent with access to tools. "
            "When the user asks you to execute, run, create, write, delete, or perform any concrete action, "
            "you MUST call the appropriate tool — do NOT just output the command as text. "
            "When the user references 'the above', 'the previous', or 'these commands/files', "
            "infer what they mean from context and execute it via tool calls. "
            "Only respond in plain text when the user is asking a question or requesting discussion. "
            "Tool usage guidelines:\n"
            "- file_write: create or fully rewrite a file\n"
            "- file_edit: make a targeted change to an existing file (preferred over rewriting)\n"
            "- file_read: read a file before editing it\n"
            "- grep: search file contents by regex pattern\n"
            "- glob: find files by name pattern\n"
            "- shell_exec: run shell commands\n"
            "Never output code blocks longer than 10 lines in your text response — write them to files instead."
        )
        user_msg = [
            {"role": "system", "content": _system},
            {"role": "user", "content": user_input},
        ]
        enriched = self.memory._build_context(user_msg)
        loop_msgs = list(enriched)
        tools = self.registry.to_openai_tools()

        any_tool_called = False
        final_text = ""
        tool_log = []
        _interrupted = False

        for iteration in range(self._max_tool_iter):
            if self._stop_event.is_set():
                break

            # Stream connection for Ctrl+C interruptibility; buffer locally
            text_chunks: list[str] = []
            response = None
            try:
                for item in self.llm.stream_with_tools(loop_msgs, tools):
                    if self._stop_event.is_set():
                        break
                    if isinstance(item, str):
                        text_chunks.append(item)
                    else:
                        response = item
            except KeyboardInterrupt:
                self._stop_event.set()
                _interrupted = True
                print()
                break

            if response is None or self._stop_event.is_set():
                break

            if not response.tool_calls:
                self._last_was_action = any_tool_called
                clean = _THINK_RE.sub("", response.text).strip()
                final_text = _truncate_code_blocks(clean)
                yield final_text
                break

            # Append assistant message with tool_calls
            loop_msgs.append(response.assistant_msg)
            any_tool_called = True

            tool_results = []
            for call in response.tool_calls:
                if self._stop_event.is_set():
                    break

                print()  # blank line before each tool call

                # Build Task for safety interface
                task = Task(
                    id=iteration * 100 + len(tool_results),
                    tool=call.name,
                    args=call.args,
                    description=f"{call.name}({call.args})",
                    depends_on=[],
                )
                # Inject work_dir for path resolution
                exec_args = dict(call.args)
                work_dir = self.projects.work_dir
                if work_dir:
                    if call.name == "shell_exec" and "cwd" not in exec_args:
                        exec_args["cwd"] = work_dir
                    elif call.name in ("file_read", "file_write", "file_edit", "grep"):
                        p = exec_args.get("path", "")
                        if p and not os.path.isabs(p) and not p.startswith("~"):
                            exec_args["path"] = os.path.join(work_dir, p)
                    elif call.name == "glob":
                        if "base_dir" not in exec_args:
                            exec_args["base_dir"] = work_dir

                # Stop spinner before any user-visible output or confirmation prompt
                if self._spinner_stop and not self._spinner_stop.is_set():
                    self._spinner_stop.set()
                    time.sleep(0.05)

                if not self._confirm_tool_call(task, dry_run=dry_run):
                    # User said no — stop the loop, let them decide next step
                    self._stop_event.set()
                    yield "\n" + yellow("Operation cancelled. What would you like to do instead?")
                    break
                else:

                    # Show file_write/file_edit diff before executing
                    if call.name == "file_write":
                        self._show_write_diff(call.args)
                    elif call.name == "file_edit":
                        self._show_edit_diff(exec_args)

                    _print_tool_header(call)

                    try:
                        result = self.registry.call(
                            call.name, exec_args,
                            output_cb=lambda line: print(f"  {line}"),
                        )
                    except KeyboardInterrupt:
                        self._stop_event.set()
                        print(red("\n🚫  interrupted"))
                        break
                    icon = green("✓") if result.success else red("✗")
                    summary = (result.output if result.success else result.error)[:120].splitlines()[0]
                    print(dim("   " + "─" * 56))
                    print(f"{icon}  {dim(summary)}")
                    content = result.output if result.success else f"ERROR: {result.error}"

                    # Truncate tool output sent to LLM
                    if len(content) > self._max_tool_output:
                        omitted = len(content) - self._max_tool_output
                        content = content[:self._max_tool_output] + f"\n... [truncated, {omitted} chars omitted]"
                    tool_log.append({
                        "tool": call.name, "args": call.args,
                        "success": result.success, "output": content[:500],
                    })

                tool_results.append({
                    "role": "tool",
                    "tool_call_id": call.id,
                    "content": content,
                })

            loop_msgs.extend(tool_results)
        else:
            # Hit max iterations
            final_text = f"(stopped after {self._max_tool_iter} iterations)"
            yield final_text

        # Save to memory — skip if interrupted (avoid empty/partial turn polluting context)
        if not _interrupted:
            self.memory._post_turn(user_input, final_text, user_msg)

        if any_tool_called:
            self.audit.record(user_input, user_input, [], True, tool_log,
                              project=self.projects.current_project)

    # ------------------------------------------------------------------
    # Per-tool safety + confirmation
    # ------------------------------------------------------------------

    def _confirm_tool_call(self, task: Task, dry_run: bool = False) -> bool:
        from safety.policy import is_always_allowed, remember_always, get_allowed_paths
        from safety.backup import backup_files

        work_dir = self.projects.work_dir
        result = _safety.check(task, work_dir=work_dir, allowed_paths=get_allowed_paths())

        if result.violation:
            print(red(f"\n🛑  BLOCKED  {task.description}"))
            print(dim(f"   {result.reason}"))
            return False

        if result.backup_paths:
            backed_up = backup_files(result.backup_paths, backup_dir=self.projects.backup_dir)
            for orig, bp in backed_up.items():
                print(dim(f"💾  backup → {bp}"))

        if result.requires_confirmation:
            op = result.operation_class
            if op and is_always_allowed(op):
                return True

            if dry_run:
                print(yellow(f"[dry-run] ⚠️  {result.reason}"))
                return False

            if result.script_path and os.path.isfile(result.script_path):
                try:
                    content = open(result.script_path).read()
                    print(yellow(f"\n📄  Script: {result.script_path}"))
                    print(dim("─" * 60))
                    for line in content.splitlines()[:40]:
                        print(dim(f"   {line}"))
                    print(dim("─" * 60))
                except OSError:
                    pass

            print(yellow(f"\n⚠️   {result.reason}"))
            print(dim(f"    {task.description}"))

            if result.can_always:
                raw = _pt_prompt("    Proceed? [y]es  [n]o  [a]lways ❯ ").strip().lower()
            else:
                raw = _pt_prompt("    Proceed? [y]es  [n]o ❯ ").strip().lower()

            if raw in ("a", "always") and result.can_always:
                remember_always(op)
                print(cyan(f"📌  policy saved: always allow [{op}]"))
            elif raw not in ("y", "yes"):
                print(red("🚫  cancelled"))
                return False
            return True

        if not self.auto_confirm:
            raw = _pt_prompt(yellow("▶   Proceed? [y]es  [n]o ❯ ")).strip().lower()
            return raw in ("y", "yes")

        return True

    # ------------------------------------------------------------------
    # File write diff
    # ------------------------------------------------------------------

    def _show_write_diff(self, args: dict):
        """Show a unified diff before file_write executes (if file exists)."""
        import difflib
        path = args.get("path", "")
        new_content = args.get("content", "")
        if not path:
            return
        full_path = os.path.expanduser(path)
        if not os.path.isabs(full_path):
            full_path = os.path.join(self.projects.work_dir, full_path)
        if not os.path.isfile(full_path):
            return  # new file, no diff needed
        try:
            old_content = open(full_path).read()
        except OSError:
            return
        if old_content == new_content:
            print(dim("  (no changes)"))
            return
        diff = list(difflib.unified_diff(
            old_content.splitlines(keepends=True),
            new_content.splitlines(keepends=True),
            fromfile=f"a/{path}",
            tofile=f"b/{path}",
            lineterm="",
        ))
        print()
        for line in diff[:60]:  # cap at 60 lines for readability
            if line.startswith("+"):
                print(green(f"  {line}"))
            elif line.startswith("-"):
                print(red(f"  {line}"))
            else:
                print(dim(f"  {line}"))
        if len(diff) > 60:
            print(dim(f"  ... ({len(diff)-60} more lines)"))
        print()

    def _show_edit_diff(self, args: dict):
        """Show a unified diff before file_edit executes."""
        import difflib
        path = args.get("path", "")
        old_str = args.get("old_str", "")
        new_str = args.get("new_str", "")
        if not path or not old_str:
            return
        full_path = os.path.expanduser(path)
        if not os.path.isabs(full_path):
            full_path = os.path.join(self.projects.work_dir, full_path)
        if not os.path.isfile(full_path):
            return
        try:
            old_content = open(full_path).read()
        except OSError:
            return
        new_content = old_content.replace(old_str, new_str, 1)
        if old_content == new_content:
            return
        diff = list(difflib.unified_diff(
            old_content.splitlines(keepends=True),
            new_content.splitlines(keepends=True),
            fromfile=f"a/{path}",
            tofile=f"b/{path}",
            lineterm="",
        ))
        print()
        for line in diff[:60]:
            if line.startswith("+"):
                print(green(f"  {line}"))
            elif line.startswith("-"):
                print(red(f"  {line}"))
            else:
                print(dim(f"  {line}"))
        if len(diff) > 60:
            print(dim(f"  ... ({len(diff)-60} more lines)"))
        print()

    # ------------------------------------------------------------------
    # Model switching
    # ------------------------------------------------------------------

    def list_models(self) -> dict:
        """Return the models dict from agent.json."""
        return self._agent_cfg.get("models", {})

    def switch_model(self, name: str):
        """Switch to a named model profile. Updates agent.json + chatmem.json + live adapters."""
        import json as _json
        models = self._agent_cfg.get("models", {})
        if name not in models:
            raise KeyError(f"Model '{name}' not found in agent.json models")
        # Update agent.json
        self._agent_cfg["active_model"] = name
        with open(self._agent_cfg_path, "w") as f:
            _json.dump(self._agent_cfg, f, indent=2, ensure_ascii=False)
            f.write("\n")
        # Sync to chatmem.json and rebuild adapters
        _sync_active_model(self._agent_cfg, self._config_path)
        cfg = ContextConfig.from_json(self._config_path) if self._config_path else ContextConfig()
        key = cfg.llm.resolve_api_key()
        if not key:
            profile = models.get(name, {})
            env_var = profile.get("api_key_env", "")
            msg = f"API key not found for model '{name}'."
            if env_var:
                msg += f" Set the {env_var} environment variable."
            raise RuntimeError(msg)
        timeout = self._agent_cfg.get("llm_timeout", 30)
        self.llm = make_adapter(cfg, timeout=timeout)
        self._reinit_memory()

    # ------------------------------------------------------------------
    # Project / session switching
    # ------------------------------------------------------------------

    def switch_project(self, name: str):
        self.memory.end_session()
        self.projects.switch_project(name)
        self._reinit_memory()

    def _reinit_memory(self):
        cfg = ContextConfig.from_json(self._config_path) if self._config_path else ContextConfig()
        self.memory = ContextManager.create(
            config=cfg,
            api_key=cfg.llm.resolve_api_key(),
            db_path=self.projects.project_db_path,
            core_db_path=self.projects.core_db_path,
        )
        pass

    # ------------------------------------------------------------------
    # Session lifecycle
    # ------------------------------------------------------------------

    def end_session(self):
        self.memory.end_session()
