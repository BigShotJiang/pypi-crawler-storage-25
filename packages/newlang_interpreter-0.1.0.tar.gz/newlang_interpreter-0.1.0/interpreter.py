class Interpreter:
    def __init__(self):
        self.variables = {}

    def visit(self, node):
        method_name = f"visit_{type(node).__name__}"
        method = getattr(self, method_name)
        return method(node)
    
    def visit_Num(self, node):
        return node.value
    
    def visit_BinOp(self, node):
        left = self.visit(node.left)
        right = self.visit(node.right)

        if node.op.type == "PLUS":
           return left + right
        elif node.op.type == "MINUS":
           return left - right
        elif node.op.type == "MUL":
           return left * right
        elif node.op.type == "DIV":
           return left / right
        elif node.op.type == "GT":
           return left > right
        elif node.op.type == "LT":
           return left < right
        elif node.op.type == "EQ":
           return left == right
        
    def visit_Var(self,node):
        return self.variables.get(node.name,0)
    
    def visit_Assign(self, node):
        value = self.visit(node.value)
        self.variables[node.name] = value
        return value
    
    def visit_Print(self, node):
        value = self.visit(node.value)
        print(value)
        return value
    
    def visit_If(self, node):
        condition = self.visit(node.condition)

        if node.body is None:
           return condition

        if condition:
           return self.visit(node.body)

        return None