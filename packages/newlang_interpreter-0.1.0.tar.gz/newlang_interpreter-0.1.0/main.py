import argparse
import sys

from runtime import run_file


def cli(argv=None):
    parser = argparse.ArgumentParser(description="Run newLang source files")
    parser.add_argument("source", help="Path to a .nl source file")
    args = parser.parse_args(argv)

    try:
        run_file(args.source)
    except FileNotFoundError:
        print(f"File not found: {args.source}", file=sys.stderr)
        return 1
    except Exception as exc:
        print(f"Runtime error: {exc}", file=sys.stderr)
        return 1

    return 0


if __name__ == "__main__":
    raise SystemExit(cli())