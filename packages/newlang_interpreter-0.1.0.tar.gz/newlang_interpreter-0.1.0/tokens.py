NUMBER ="NUMBER"
PLUS = "PLUS"
MINUS = "MINUS"
MUL = "MUL"
DIV = "DIV"
LPAREN = "LPAREN"
RPAREN = "RPAREN"
EOF = "EOF"
IDENTIFIER = "IDENTIFIER"
ASSIGN = "ASSIGN"
PRINT="PRINT"
GT= "GT"
LT= "LT"
EQ= "EQ"
IF= "IF"
COLON= "COLON"


class Token:
    def __init__(self, type_, value=None):
        self.type=type_
        self.value=value
    
    def __repr__(self):
        return f"{self.type}:{self.value}"