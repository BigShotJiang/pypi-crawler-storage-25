# newLang

newLang is a tiny educational programming language with variables, arithmetic, print statements, and indentation-based if blocks.

## Features

- Integer numbers
- Variables and assignment
- Arithmetic: `+`, `-`, `*`, `/`
- Comparisons: `>`, `<`, `==`
- `print(...)`
- `if condition:` with indented blocks

## Install

From this project directory:

```bash
pip install .
```

For development mode:

```bash
pip install -e .
```

## Run a Program

Create a source file, for example `example.nl`:

```txt
x = 20
if x > 10:
    print(x)
```

Run it:

```bash
newlang example.nl
```

Expected output:

```txt
20
```

## Language Notes

- Indentation controls blocks for `if` statements.
- Tabs are supported and treated as width 4.
- Empty lines are ignored.
- Variables default to `0` if read before assignment.
