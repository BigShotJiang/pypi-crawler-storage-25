class Num:
    def __init__(self, value):
        self.value = value

    def __repr__(self):
        return f"Num({self.value})"


class BinOp:
    def __init__(self, left, op, right):
        self.left = left
        self.op = op
        self.right = right

    def __repr__(self):
        return f"BinOp({self.left}, {self.op.type}, {self.right})"


class Var:
    def __init__(self, name):
        self.name = name

    def __repr__(self):
        return f"Var({self.name})"


class Assign:
    def __init__(self, name, value):
        self.name = name
        self.value = value

    def __repr__(self):
        return f"Assign({self.name}, {self.value})"

class If:
    def __init__(self, condition, body):
        self.condition = condition
        self.body = body

    def __repr__(self):
        return f"If({self.condition}, {self.body})"

class Print:
    def __init__(self, value):
        self.value = value

    def __repr__(self):
        return f"Print({self.value})"
    
from tokens import *

class Parser:
    def __init__(self, lexer):
        self.lexer = lexer
        self.current_token = lexer.get_next_token()

    def eat(self, token_type):
        if self.current_token.type == token_type:
            self.current_token = self.lexer.get_next_token()
        else:
            raise Exception(f"Invalid syntax. Expected {token_type}, got {self.current_token.type}")

    # factor → NUMBER | IDENTIFIER
    def factor(self):
        token = self.current_token

        if token.type == NUMBER:
            self.eat(NUMBER)
            return Num(token.value)

        elif token.type == IDENTIFIER:
            self.eat(IDENTIFIER)
            return Var(token.value)

        elif token.type == LPAREN:
            self.eat(LPAREN)
            node = self.expr()
            self.eat(RPAREN)
            return node

        raise Exception(f"Invalid syntax near token {token.type}")

    # term → factor ((* or /) factor)*
    def term(self):
        node = self.factor()

        while self.current_token.type in (MUL, DIV):
            token = self.current_token
            if token.type == MUL:
                self.eat(MUL)
            elif token.type == DIV:
                self.eat(DIV)

            node = BinOp(node, token, self.factor())

        return node

    # expr → term ((+ or -) term)*
    def expr(self):
        node = self.term()

        while self.current_token.type in (PLUS, MINUS):
            token = self.current_token
            if token.type == PLUS:
                self.eat(PLUS)
            elif token.type == MINUS:
                self.eat(MINUS)

            node = BinOp(node, token, self.term())

        return node

    # statement → IDENTIFIER = expr
    def assignment(self):
        var_name = self.current_token.value
        self.eat(IDENTIFIER)
        self.eat(ASSIGN)
        value = self.expr()
        return Assign(var_name, value)

    # statement → print(expr)
    def print_stmt(self):
        self.eat(PRINT)
        self.eat(LPAREN)
        value = self.expr()
        self.eat(RPAREN)
        return Print(value)

    def statement(self):
        if self.current_token.type == IF:
           return self.if_statement()
        elif self.current_token.type == IDENTIFIER:
            return self.assignment()
        elif self.current_token.type == PRINT:
            return self.print_stmt()
        else:
            return self.expr()
        
    def comparison(self):
        node = self.expr()

        if self.current_token.type in (GT, LT, EQ):
            token = self.current_token

            if token.type == GT:
                self.eat(GT)
            elif token.type == LT:
                self.eat(LT)
            elif token.type == EQ:
                self.eat(EQ)

            node = BinOp(node, token, self.expr())

        return node
    
    def if_statement(self):
        self.eat(IF)
        condition = self.comparison()
        self.eat(COLON)

        # Support multi-line blocks where the body is parsed separately.
        if self.current_token.type == EOF:
            body = None
        else:
            body = self.statement()

        return If(condition, body)

    def parse_statement(self):
        node = self.statement()
        if self.current_token.type != EOF:
            raise Exception(f"Unexpected token after statement: {self.current_token.type}")
        return node