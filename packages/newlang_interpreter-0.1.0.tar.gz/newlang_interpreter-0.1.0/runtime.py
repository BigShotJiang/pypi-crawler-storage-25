from interpreter import Interpreter
from lexer import Lexer
from parser import Parser


def _indent_width(line):
    width = 0
    for char in line:
        if char == " ":
            width += 1
        elif char == "\t":
            width += 4
        else:
            break
    return width


def _next_nonempty_line(lines, start):
    for idx in range(start, len(lines)):
        if lines[idx].strip():
            return idx
    return None


def _parse_statement(line):
    lexer = Lexer(line.strip())
    parser = Parser(lexer)
    return parser.parse_statement()


def _execute_block(lines, start_index, block_indent, interpreter, should_execute):
    i = start_index

    while i < len(lines):
        raw_line = lines[i]
        stripped = raw_line.strip()

        if not stripped:
            i += 1
            continue

        indent = _indent_width(raw_line)

        if indent < block_indent:
            break

        if indent > block_indent:
            raise Exception(f"Unexpected indentation at line {i + 1}")

        tree = _parse_statement(stripped)
        is_block_if = stripped.startswith("if ") and stripped.endswith(":") and tree.body is None

        if is_block_if:
            next_line_index = _next_nonempty_line(lines, i + 1)
            if next_line_index is None:
                raise Exception(f"Expected an indented block after if at line {i + 1}")

            child_indent = _indent_width(lines[next_line_index])
            if child_indent <= block_indent:
                raise Exception(f"Expected an indented block after if at line {i + 1}")

            condition = interpreter.visit(tree) if should_execute else False
            i = _execute_block(
                lines,
                i + 1,
                child_indent,
                interpreter,
                should_execute and bool(condition),
            )
            continue

        if should_execute:
            interpreter.visit(tree)

        i += 1

    return i


def run_code(source_code, interpreter=None):
    active_interpreter = interpreter or Interpreter()
    lines = source_code.splitlines()
    _execute_block(lines, 0, 0, active_interpreter, True)
    return active_interpreter


def run_file(path, interpreter=None, encoding="utf-8"):
    with open(path, "r", encoding=encoding) as source_file:
        return run_code(source_file.read(), interpreter=interpreter)
