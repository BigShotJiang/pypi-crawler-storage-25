from tokens import *

class Lexer:
    def __init__(self,text):
        self.text=text
        self.pos=0
        self.current_char= text[self.pos] if text else None

    def advance(self):
        self.pos +=1
        if self.pos >=len(self.text):
            self.current_char=None
        else:
            self.current_char=self.text[self.pos]
        
    def skip_whitespace(self):
        while self.current_char and self.current_char.isspace():
            self.advance()
    
    def number(self):
        result = ""
        while self.current_char and self.current_char.isdigit():
            result += self.current_char
            self.advance()
        return Token(NUMBER, int(result))

    def identifier(self):
        result = ""
        while self.current_char and (self.current_char.isalnum() or self.current_char == "_"):
            result += self.current_char
            self.advance()

        if result == "print":
            return Token(PRINT)
        elif result == "if":
            return Token(IF)
        return Token(IDENTIFIER, result)

    def get_next_token(self):
        while self.current_char:

            if self.current_char.isspace():
                self.skip_whitespace()
                continue

            if self.current_char == '#':
                while self.current_char and self.current_char != '\n':
                    self.advance()
                continue

            if self.current_char.isdigit():
                return self.number()

            if self.current_char.isalpha() or self.current_char == "_":
                return self.identifier()
            if self.current_char == '>':
                self.advance()
                return Token(GT)

            if self.current_char == '<':
                self.advance()
                return Token(LT)

            if self.current_char == ':':
                self.advance()
                return Token(COLON)

            if self.current_char == '+':
                self.advance()
                return Token(PLUS)

            if self.current_char == '-':
                self.advance()
                return Token(MINUS)

            if self.current_char == '*':
                self.advance()
                return Token(MUL)

            if self.current_char == '/':
                self.advance()
                return Token(DIV)

            if self.current_char == '=':
                self.advance()
                if self.current_char == '=':
                   self.advance()
                   return Token(EQ)
                return Token(ASSIGN)
            if self.current_char == '(':
                self.advance()
                return Token(LPAREN)

            if self.current_char == ')':
                self.advance()
                return Token(RPAREN)

            raise Exception(f"Invalid character: {self.current_char}")

        return Token(EOF)