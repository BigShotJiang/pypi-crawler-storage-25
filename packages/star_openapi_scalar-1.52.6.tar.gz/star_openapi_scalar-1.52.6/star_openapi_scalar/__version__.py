# -*- coding: utf-8 -*-

__version__ = "1.52.6"
