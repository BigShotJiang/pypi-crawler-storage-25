#!/usr/bin/env python3

DEFAULT_KEYS_REQUIRED = ["name", "type", "default"]
DEFAULT_KEYS_POSSIBLE = [
    'name',
    'type',
    'default',
    'env_name',
    'terminal_help',
    'terminal_name',
    'terminal_name_short',
]
DEFAULT_ACCEPTED_KEY_TYPES = ["string", "bool", "int", "float", "list", "dict"]
DEFAULT_ACCEPTED_FILE_TYPES = ["yaml", "yml", "json", "toml", "ini" ]
DEFAULT_INI_SECTION = "default"
DEFAULT_APP_DESCRIPTION = "This is app is settings the configuration values using the 'fejao_config_parser' package. You can change the description of the app by setting the 'description' parameter in the 'my_config' function, like so: my_config(config=<LIST_DICT>, description='My App Description'). Please refer to the documentation for more details."
