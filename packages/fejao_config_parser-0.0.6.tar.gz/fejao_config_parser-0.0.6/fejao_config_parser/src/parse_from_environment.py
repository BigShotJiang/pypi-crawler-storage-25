#!/usr/bin/env python3

import os

### LOCAL
from .values_default import DEFAULT_ACCEPTED_KEY_TYPES
# from .values_check import ValuesCheck
from .values_check import ValuesCheck, ValuesFromType

class ParseFromEnvironment:

    def __init__(self, config: list) -> None:

        self.config = config
        self.value_from_type = ValuesFromType(source_name="environment")

        self.__set_values__()
        self.__check_values__()

    def __set_values__(self) -> None:

        ret_dict = {}
        for item in self.config:
            found = os.environ.get(item.get("env_name"))
            if found is not None:
                ret_dict[item["name"]] = self.value_from_type.get_value(
                    value_type=item["type"],
                    value_found=found
                )

        self.values = ret_dict

    def __check_values__(self) -> None:
        ValuesCheck(config=self.config, values_found=self.values, info_string="environment values")

    def get_values(self) -> dict:
        return self.values