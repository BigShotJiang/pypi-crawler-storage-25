#!/usr/bin/env python3


### LOCAL
from .values_default import DEFAULT_ACCEPTED_KEY_TYPES

class ValuesCheck:

    def __init__(self, config: list, values_found: dict, info_string: str) -> None:

        self.config = config
        self.values_found = values_found
        self.info_string = info_string
        self.__check_values__()

    def __check_values__(self) -> None:

        for item in self.config:

            if item['name'] in self.values_found.keys():
                name_value = self.values_found[item['name']]
                if item["type"].lower() == "string" or item["type"].lower() == "str":
                    if not isinstance(name_value, str):
                        raise ValueError(f"\n\nError checking the configuration values for '{self.info_string}'. The value found for the name '{item['name']}' that wanted to be used as type '{item['type']}' but the value parsed is: '{name_value}'.\n")
                elif item["type"].lower() == "bool" or item["type"].lower() == "boolean":
                    if not isinstance(name_value, bool):
                        raise ValueError(f"\n\nError checking the configuration values for '{self.info_string}'. The value found for the name '{item['name']}' that wanted to be used as type '{item['type']}' but the value parsed is: '{name_value}'.\n")
                elif item["type"].lower() == "int" or item["type"].lower() == "integer":
                    if not isinstance(name_value, int):
                        raise ValueError(f"\n\nError checking the configuration values for '{self.info_string}'. The value found for the name '{item['name']}' that wanted to be used as type '{item['type']}' but the value parsed is: '{name_value}'.\n")
                elif item["type"].lower() == "float" or item["type"].lower() == "double":
                    if not isinstance(name_value, float):
                        raise ValueError(f"\n\nError checking the configuration values for '{self.info_string}'. The value found for the name '{item['name']}' that wanted to be used as type '{item['type']}' but the value parsed is: '{name_value}'.\n")
                elif item["type"].lower() == "list":
                    if not isinstance(name_value, list):
                        raise ValueError(f"\n\nError checking the configuration values for '{self.info_string}'. The value found for the name '{item['name']}' that wanted to be used as type '{item['type']}' but the value parsed is: '{name_value}'.\n")
                elif item["type"].lower() == "dict" or item["type"].lower() == "dictionary":
                    if not isinstance(name_value, dict):
                        raise ValueError(f"\n\nError checking the configuration values for '{self.info_string}'. The value found for the name '{item['name']}' that wanted to be used as type '{item['type']}' but the value parsed is: '{name_value}'.\n")
                else:
                    raise ValueError(f"\n\nError checking the configuration values for '{self.info_string}'. The type '{item['type']}' for the name '{item['name']}' is not supported. The accepted types are: {DEFAULT_ACCEPTED_KEY_TYPES}. Please refer to the documentation for more details.\n")


class ValuesFromType:

    # def __init__(self, value_type: str, value_found: str | int | float | bool | list | dict) -> None:
    def __init__(self, source_name: str) -> None:

        self.source_name = source_name

        # self.value_type = value_type
        # self.value_found = value_found
        # self.value = self.__value_from_type__()

    # def __value_from_type__(self) -> str | int | float | bool | list | dict:
    def get_value(self, value_type: str, value_found: str | int | float | bool | list | dict) -> str | int | float | bool | list | dict:

        # import pdb; pdb.set_trace()
        # value_type


        # STRING
        if value_type.lower() == "string" or value_type.lower() == "str":
            return str(value_found)

        # BOOL
        elif value_type.lower() == "bool" or value_type.lower() == "boolean":

            if isinstance(value_found, bool):
                return value_found

            if value_found in ["True", "true", "TRUE", "Yes", "yes", "YES", "On", "on", "ON"]:
                return True
            elif value_found in ["False", "false", "FALSE", "No", "no", "NO", "Off", "off", "OFF"]:
                return False
            else:
                raise ValueError(f"\n\nError parsing the '{self.source_name}' variable for the type '{value_type}'. The value found is: '{value_found}'. The accepted values for boolean types are: 'true', 'yes', 'on', 'false', 'no', 'off'. Please refer to the documentation for more details.\n")

        # INT
        elif value_type.lower() == "int" or value_type.lower() == "integer":
            try:
                return int(value_found)
            except ValueError:
                raise ValueError(f"\n\nError parsing the '{self.source_name}' variable for the type '{value_type}'. The value found is: '{value_found}'. The value cannot be converted to an integer. Please refer to the documentation for more details.\n")

        # FLOAT
        elif value_type.lower() == "float" or value_type.lower() == "double":
            try:
                return float(value_found)
            except ValueError:
                raise ValueError(f"\n\nError parsing the '{self.source_name}' variable for the type '{value_type}'. The value found is: '{value_found}'. The value cannot be converted to a float. Please refer to the documentation for more details.\n")

        # LIST
        elif value_type.lower() == "list":

            if isinstance(value_found, list):
                return value_found

            try:
                return eval(value_found)
            except Exception as e:
                raise ValueError(f"\n\nError parsing the '{self.source_name}' variable for the type '{value_type}'. The value found is: '{value_found}'. The value cannot be converted to a list. The error found was: {e}. Please refer to the documentation for more details.\n")

        # DICT
        elif value_type.lower() == "dict" or value_type.lower() == "dictionary":

            if isinstance(value_found, dict):
                return value_found

            try:
                return eval(value_found)
            except Exception as e:
                raise ValueError(f"\n\nError parsing the '{self.source_name}' variable for the type '{value_type}'. The value found is: '{value_found}'. The value cannot be converted to a dictionary. The error found was: {e}. Please refer to the documentation for more details.\n")

        # NOT SUPPORTED
        else:
            raise ValueError(f"\n\nError parsing the '{self.source_name}' variable for the type '{value_type}'. The type is not supported. The accepted types are: {DEFAULT_ACCEPTED_KEY_TYPES}. Please refer to the documentation for more details.\n")