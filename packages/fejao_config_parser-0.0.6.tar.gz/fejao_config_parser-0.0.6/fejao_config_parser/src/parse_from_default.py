#!/usr/bin/env python3

### LOCAL
from .values_check import ValuesCheck

class ParseFromDefault:

    def __init__(self, config: list) -> None:

        self.config = config

        self.__set_values__()
        self.__check_values__()

    def __set_values__(self) -> None:

        ret_dict = {}
        for item in self.config:
            ret_dict[item["name"]] = item["default"]

        self.values = ret_dict

    def __check_values__(self) -> None:
        ValuesCheck(config=self.config, values_found=self.values, info_string="default values")

    def get_values(self) -> dict:
        return self.values
