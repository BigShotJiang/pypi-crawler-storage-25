#!/usr/bin/env python3

import argparse

### LOCAL IMPORTS
from .values_default import DEFAULT_APP_DESCRIPTION
from .values_check import ValuesCheck, ValuesFromType

class ParseFromTerminal:

    def __init__(self, config: list, description: str = None) -> None:

        self.config = config
        self.description = description
        self.value_from_type = ValuesFromType(source_name="terminal")

        self.__set_values__()
        self.__check_values__()

    def __set_value_bool__(self, parser: argparse.ArgumentParser, entry: dict) -> None:

        if entry.get("terminal_name_short") == '' or entry.get("terminal_name_short") is None:
            parser.add_argument(
                f'--{entry.get("terminal_name")}',
                help=entry.get("terminal_help"),
                default=entry.get("default"),
                action='store_true'
            )

        else:
            parser.add_argument(
                f'-{entry.get("terminal_name_short")}',
                f'--{entry.get("terminal_name")}',
                help=entry.get("terminal_help"),
                default=entry.get("default"),
                action='store_true'
            )

    def __set_value_non_bool__(self, parser: argparse.ArgumentParser, entry: dict) -> None:

        if entry.get("terminal_name_short") == '' or entry.get("terminal_name_short") is None:
            parser.add_argument(
                f'--{entry.get("terminal_name")}',
                help=entry.get("terminal_help"),
                default=entry.get("default"),
                type=str
            )

        else:
            parser.add_argument(
                f'-{entry.get("terminal_name_short")}',
                f'--{entry.get("terminal_name")}',
                help=entry.get("terminal_help"),
                default=entry.get("default"),
                type=str
            )

    def __set_values__(self) -> None:

        if self.description is not None:
            description = self.description
        else:
            description = DEFAULT_APP_DESCRIPTION

        parser = argparse.ArgumentParser(description=description)

        for item in self.config:
            # Only if set
            if item.get("terminal_name") is not None and item.get("terminal_help") is not None:
                if str(item["type"]).lower() in ["bool", "boolean"]:
                    self.__set_value_bool__(parser=parser, entry=item)
                else:
                    self.__set_value_non_bool__(parser=parser, entry=item)

        # Check Parsed Values and Convert Types
        ret_dict = {}
        from_terminal_dict = parser.parse_args().__dict__
        for item in self.config:
            ret_dict[item["name"]] = self.value_from_type.get_value(
                value_type=item["type"],
                value_found=from_terminal_dict.get(item.get("terminal_name"))
            )

        self.values = ret_dict

    def __check_values__(self) -> None:
        ValuesCheck(config=self.config, values_found=self.values, info_string="terminal values")

    def get_values(self) -> dict:
        return self.values