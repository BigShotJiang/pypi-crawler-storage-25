

import pyaml_env
import json
import tomli # Works for Python 3.11 and earlier, since tomllib is only available in Python 3.11+
import configparser
import ast
import re
# from typing import Any, Dict, List, Union
from typing import Any

### LOCAL IMPORTS
from .values_default import DEFAULT_ACCEPTED_FILE_TYPES, DEFAULT_INI_SECTION
from .values_check import ValuesCheck


class ParseFromFile:

    def __init__(self, config: list, config_file_path: str) -> None:

        self.config = config
        self.config_file_path = config_file_path

        self.__check_file_exists__()
        self.__set_values__()
        self.__check_values__()

    def __check_file_exists__(self) -> None:

        try:
            with open(self.config_file_path, 'r') as file:
                pass

        except Exception as e:
            raise ValueError(f"\n\nError at the configuration file. The file path provided '{self.config_file_path}' does not exist or is not accessible. The error found was: '{e}'\n")

    def __get_file_type__(self) -> None:

        for file_type in DEFAULT_ACCEPTED_FILE_TYPES:
            if file_type in self.config_file_path.lower():
                return file_type

        raise ValueError(f"\n\nError at the configuration file. The file type of the configuration file is not supported. The accepted file types are: {DEFAULT_ACCEPTED_FILE_TYPES}. Please refer to the documentation for more details.\n")

    def __values_from_yaml__(self) -> None:

        try:
            return pyaml_env.parse_config(self.config_file_path)

        except Exception as e:
            raise ValueError(f"\n\nError parsing the configuration from a YAML file. The error found was: {e}. Please refer to the documentation for more details.\n")

    def __values_from_json__(self) -> None:

        try:
            with open(self.config_file_path, 'r') as file:
                return json.load(file)

        except Exception as e:
            raise ValueError(f"\n\nError parsing the configuration from a JSON file. The error found was: {e}. Please refer to the documentation for more details.\n")

    def __values_from_ini__(self) -> None:

        def parse_value(value: str) -> Any:
            """
            Parse a string value into appropriate Python type including lists, dicts, etc.
            I still don't know how people still using INI files for configuration nowadays, but here we go.
            """
            value = value.strip()

            # empty string
            if not value:
                return None

            # quoted strings
            if value[0] in ('"', "'") and value[0] == value[-1]:
                return value[1:-1].encode().decode('unicode_escape')

            # None
            if value.lower() in ('none', 'null', 'nil', '~'):
                return None

            # booleans
            if value.lower() in ('true', 'yes', 'on'):
                return True
            if value.lower() in ('false', 'no', 'off'):
                return False

            # complex types using ast.literal_eval
            if (value.startswith('[') and value.endswith(']')) or \
            (value.startswith('(') and value.endswith(')')) or \
            (value.startswith('{') and value.endswith('}')) or \
            (value.startswith('{') and value.endswith('}') and ':' in value):
                try:
                    evaluated = ast.literal_eval(value)
                    if isinstance(evaluated, tuple):
                        return list(evaluated)
                    return evaluated
                except (SyntaxError, ValueError):
                    pass

            # lists without brackets (comma-separated)
            if ',' in value and ' ' in value and not any(c in value for c in '[](){}'):
                parts = [p.strip() for p in value.split(',')]
                return [parse_value(p) for p in parts]

            # integers
            if re.match(r'^-?\d+$', value):
                return int(value)

            # floats
            if re.match(r'^-?\d+\.\d+$', value):
                return float(value)

            # default -> return as string
            return value

        try:
            config = configparser.ConfigParser()
            config.read(self.config_file_path)

            result = {}
            for section in config.sections():
                if section == DEFAULT_INI_SECTION:
                    for key, value in config.items(section):
                        result[key] = parse_value(value)

            return result

        except Exception as e:
            raise ValueError(f"\n\nError parsing the configuration from a INI file. The error found was: {e}. Please refer to the documentation for more details.\n")

    def __values_from_toml__(self) -> None:

        try:
            with open("config.toml", "rb") as file:
                return tomli.load(file)

        except Exception as e:
            raise ValueError(f"\n\nError parsing the configuration from a TOML file. The error found was: {e}. Please refer to the documentation for more details.\n")

    def __set_values__(self) -> None:

        file_type = self.__get_file_type__()

        if file_type not in DEFAULT_ACCEPTED_FILE_TYPES:
            raise ValueError(f"\n\nError at the configuration file. The file type of the configuration file is not supported. The accepted file types are: {DEFAULT_ACCEPTED_FILE_TYPES}. Please refer to the documentation for more details.\n")

        if file_type.lower() in ["yaml", "yml"]:
            self.values = self.__values_from_yaml__()
        elif file_type.lower() == "json":
            self.values = self.__values_from_json__()
        elif file_type.lower() == "toml":
            self.values = self.__values_from_toml__()
        elif file_type.lower() == "ini":
            self.values = self.__values_from_ini__()
        else:
            raise ValueError(f"\n\nError at the configuration file. The file type of the configuration file is not supported. The accepted file types are: {DEFAULT_ACCEPTED_FILE_TYPES}. Please refer to the documentation for more details.\n")

    def __check_values__(self) -> None:
        ValuesCheck(config=self.config, values_found=self.values, info_string="configuration file")

    def get_values(self) -> dict:
        return self.values