#!/usr/bin/env python3

from pydantic import BaseModel

class ValuesModel(BaseModel):
    """A class representing all the resolved configuration values from different sources."""
    from_default: dict = None
    from_file:  dict = None
    from_environment:  dict = None
    from_terminal:  dict = None
