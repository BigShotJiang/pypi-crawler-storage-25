#!/usr/bin/env python3

# File for the main functionality of the fejao_config_parser package. This file is used to define the core functions and classes of the package.

### LOCAL IMPORTS
from .values_model import ValuesModel
from .values_default import DEFAULT_KEYS_REQUIRED, DEFAULT_KEYS_POSSIBLE
from .parse_from_default import ParseFromDefault
from .parse_from_file import ParseFromFile
from .parse_from_environment import ParseFromEnvironment
from .parse_from_terminal import ParseFromTerminal


class GetConfig:

    def __init__(self, config: list, config_file_path: str | None, description: str | None, debug: bool = False) -> None:


        self.config = config
        self.description = description
        self.debug = debug
        self.values_model = ValuesModel()
        self.values_set_info = {}

        self.__check_values_used__()
        self.__get_config_default__()

        if config_file_path is not None:
            self.config_file_path = config_file_path
            self.__get_config_from_file__()

        self.__get_config_from_environment__()
        self.__get_config_from_terminal__()
        self.__set_values_used__()

        if self.debug:
            self.__print_debug__()

    def __check_values_used__(self) -> None:

        keys_possible = set(DEFAULT_KEYS_POSSIBLE)

        for i, item in enumerate(self.config):


            if not isinstance(item, dict):
                raise ValueError("\n\nError at the configuration. Each item in the 'config' list must be a dictionary. Please refer to the documentation for more details.\n")

            for key in DEFAULT_KEYS_REQUIRED:
                if key not in item:
                    raise ValueError(f"\n\nError at the configuration. Each dictionary in the 'config' list must contain the key '{key}'. Please refer to the documentation for more details.\n")

            item_keys = set(item.keys())

            # Find unexpected keys
            extra_keys = item_keys - keys_possible
            if extra_keys:
                raise ValueError(f"\n\nError checking the configuration values. Unknown parsed key name {extra_keys} in config at the item {i}. \nPossible keys to be used are: {DEFAULT_KEYS_POSSIBLE} \nPlease refer to the documentation for more details.\n")

    def __get_config_default__(self) -> None:
        parser = ParseFromDefault(config=self.config)
        self.values_model.from_default = parser.get_values()

    def __get_config_from_file__(self) -> None:
        parser = ParseFromFile(config=self.config, config_file_path=self.config_file_path)
        self.values_model.from_file = parser.get_values()

    def __get_config_from_environment__(self) -> None:
        parser = ParseFromEnvironment(config=self.config)
        self.values_model.from_environment = parser.get_values()

    def __get_config_from_terminal__(self) -> None:
        parser = ParseFromTerminal(config=self.config, description=self.description)
        self.values_model.from_terminal = parser.get_values()

    def __set_single_value__(self, value_name: str) -> str | int | float | bool | list | dict:

        ### FROM DEFAULT
        value_from_default = self.values_model.from_default.get(value_name)

        ### FROM TERMINAL
        from_terminal = self.values_model.from_terminal.get(value_name)
        if isinstance(from_terminal, bool) and from_terminal != value_from_default:
            self.values_set_info[value_name] = {"value": from_terminal, "source": "terminal"}
            return from_terminal

        if from_terminal is not None and from_terminal != value_from_default:
            self.values_set_info[value_name] = {"value": from_terminal, "source": "terminal"}
            return from_terminal

        ### FROM ENVIRONMENT
        from_environment = self.values_model.from_environment.get(value_name)
        if from_environment is not None:
            self.values_set_info[value_name] = {"value": from_environment, "source": "environment"}
            return from_environment

        ### FROM CONFIG FILE
        from_config_file = self.values_model.from_file.get(value_name)
        if from_config_file is not None:
            # self.values_set_info[value_name] = {"value": from_config_file, "source": "config_file"}
            self.values_set_info[value_name] = {"value": from_config_file, "source": self.config_file_path}
            return from_config_file

        ### If nothing else was set, use default values
        self.values_set_info[value_name] = {"value": value_from_default, "source": "default"}
        return value_from_default

    def __set_values_used__(self) -> None:

        for value in self.config:
            setattr(self, value.get("name"), self.__set_single_value__(value_name=value.get("name")))


    def __print_debug__(self) -> None:

        color_red = "\033[91m"
        color_green = "\033[92m"
        color_yellow = "\033[93m"
        color_blue_dark = "\033[94m"
        color_blue_light = "\033[96m"
        color_end = "\033[0m"

        print(color_green + "\nCONFIGURATION VALUES DEBUG INFO:" + color_end)

        for key, value in self.values_set_info.items():
            print(color_yellow + "\nValue name: " + color_blue_light + f"'{key}'" +
                  color_yellow + "\nValue set: " + color_red + f"'{value.get('value')}'" +
                  color_yellow + "\nValue source: " + color_blue_dark + f"'{value.get('source')}'" +
                  color_end
            )

        print("")
