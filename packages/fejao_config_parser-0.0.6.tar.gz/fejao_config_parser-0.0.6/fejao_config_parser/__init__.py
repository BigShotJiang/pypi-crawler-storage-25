# fejao_config_parser package

from .main import my_config

__all__ = ["my_config"]
