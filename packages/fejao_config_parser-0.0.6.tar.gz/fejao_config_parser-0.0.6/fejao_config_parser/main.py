#!/usr/bin/env python3

# File for the main functionality of the fejao_config_parser package. This file is used to define the core functions and classes of the package.

### LOCAL IMPORTS
from .src.get_config import GetConfig


def my_config(config: list, config_file_path: str = None, description: str = None, debug: bool = None) -> dict:

    if not isinstance(config, list):
        raise ValueError("\n\nError parsing the configuration. The variable 'config' must be a list of dictionaries. Please refer to the documentation for more details.\n")

    get_config = GetConfig(config=config, config_file_path=config_file_path, description=description, debug=debug)

    return get_config
