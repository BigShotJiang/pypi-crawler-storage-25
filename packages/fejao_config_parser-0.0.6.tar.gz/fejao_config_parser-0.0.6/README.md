# fejao-config-parser

This is a package for setting up the variables that you need to you on your project from a list of dictionaries.

I was tired of everytime that I needed to set a project that should have input/variables to be set from a configuration file, environment variables or from terminal to write this code again and again. Then the unit-test. And so on and on...

I hope that you also find this tiredsome work not needed anymore for using this package.

## To Do
- [] Finish README.md file

## A


---

## Using

### Config file

#### toml
If you want to use a toml file, you need to have it installed
```bash
pip install tomli
```

```bash
EXAMPLE_STRING=aaa EXAMPLE_BOOL=true  EXAMPLE_INT=2 EXAMPLE_FLOAT=1.23 EXAMPLE_LIST=[7,8,9,0] EXAMPLE_DICTIONARY='{"a":"b", "c":"d"}' python main.py
```
```bash
python main.py -es bbbbb -eb -ei 55 -ef 6.43 -el '[5,4,3]' -ed '{"q":"w", "e":"r"}'
```

---

## Testing

- ### Lint

- ### Unit-tests
  For running the unit tests, just run the command:
  ```bash
  python -m unittest tests/test_from_environment.py
  ```





## Authors and acknowledgment
Show your appreciation to those who have contributed to the project.

## License
For open source projects, say how it is licensed.

## Project status
If you have run out of energy or time for your project, put a note at the top of the README saying that development has slowed down or stopped completely. Someone may choose to fork your project or volunteer to step in as a maintainer or owner, allowing your project to keep going. You can also make an explicit request for maintainers.
