#!/usr/bin/env python3

# File for setting the configuration of the fejao_config_parser package for distribution.

from setuptools import setup, find_packages
from os import path

working_directory = path.abspath(path.dirname(__file__))

with open(path.join(working_directory, "README_PACKAGE.md"), "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="fejao_config_parser",
    version="0.0.6",
    author="fejao",
    description="A Python package for parsing configuration from various sources such as files, environment variables, and command-line arguments.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "pydantic>=2.0.0",
        "pyaml_env>=1.0.0",
        "argparse>=1.4.0",
        "configparser>=5.0.0",
        "tomli>=2.2.1",
    ],
    # entry_points={
    #     "console_scripts": [
    #         "fejao-config-parser-hello = fejao_config_parser:hello",
    #     ],
    # },
)
