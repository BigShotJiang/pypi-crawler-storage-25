"""Summary Stack MCP Core - shared tools for Summary Stack MCP servers.

This package provides core MCP tools that can be imported and registered
by connector-specific MCP servers (e.g., Obsidian, Notion).

Usage:
    from summary_stack_mcp_core import (
        search_corpus,
        get_stack,
        list_stacks,
        create_summary_stack,
    )

    # Register with FastMCP
    mcp = FastMCP("my-connector")
    mcp.tool()(search_corpus)
    mcp.tool()(get_stack)
    mcp.tool()(list_stacks)
    mcp.tool()(create_summary_stack)

Environment Variables:
    SUMMARY_STACK_API_URL: Base URL of the Summary Stack API
    SUMMARY_STACK_API_KEY: API key for authentication
"""

from .api_client import SummaryStackCoreAPIClient, SummaryStackCoreAPIError
from .config import CoreConfig, load_config
from .models import CorpusSearchResponse, CorpusSearchResult
from .tools import create_summary_stack, get_stack, list_stacks, search_corpus


__all__ = [
    # Tools (primary exports)
    "search_corpus",
    "get_stack",
    "list_stacks",
    "create_summary_stack",
    # Models
    "CorpusSearchResult",
    "CorpusSearchResponse",
    # Config
    "CoreConfig",
    "load_config",
    # Client (for advanced usage)
    "SummaryStackCoreAPIClient",
    "SummaryStackCoreAPIError",
]
