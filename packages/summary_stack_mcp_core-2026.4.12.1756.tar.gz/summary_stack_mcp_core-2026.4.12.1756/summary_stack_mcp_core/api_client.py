"""HTTP client for Summary Stack API."""

import asyncio
import json
import logging
from typing import Any

import httpx
from summary_stack_models import (
    StackListResponse,
    SummaryStackData,
)

from .models import CorpusSearchResponse, CorpusSearchResult


logger = logging.getLogger(__name__)


POLL_INTERVAL_SECONDS = 2.0
MAX_POLL_TIMEOUT_SECONDS = 300.0  # 5 minutes


class SummaryStackCoreAPIError(Exception):
    """Error from Summary Stack API."""

    def __init__(self, message: str, status_code: int | None = None):
        super().__init__(message)
        self.status_code = status_code


class SummaryStackCoreAPIClient:
    """HTTP client for Summary Stack list and get endpoints."""

    def __init__(self, api_url: str, api_key: str):
        """Initialize the API client.

        Args:
            api_url: Base URL of the Summary Stack API
            api_key: API key for authentication
        """
        self.api_url = api_url.rstrip("/")
        self.api_key = api_key

    def _headers(self) -> dict[str, str]:
        """Get default request headers."""
        return {
            "X-API-Key": self.api_key,
            "Content-Type": "application/json",
        }

    async def list_stacks(self, limit: int = 20, offset: int = 0) -> StackListResponse:
        """List user's most recent summary stacks.

        Args:
            limit: Maximum results to return
            offset: Pagination offset

        Returns:
            Paginated list of stack summaries

        Raises:
            SummaryStackCoreAPIError: If API request fails
        """
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{self.api_url}/api/v1/stacks",
                params={"limit": limit, "offset": offset},
                headers=self._headers(),
                timeout=30.0,
            )

            self._raise_for_status(response)
            return StackListResponse.model_validate(response.json())

    async def get_stack(self, stack_id: str) -> SummaryStackData:
        """Get full details of a specific summary stack.

        Args:
            stack_id: Summary stack UUID

        Returns:
            Full summary stack data

        Raises:
            SummaryStackCoreAPIError: If API request fails or stack not found
        """
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{self.api_url}/api/v1/stacks/{stack_id}",
                headers=self._headers(),
                timeout=30.0,
            )

            self._raise_for_status(response)
            return SummaryStackData.model_validate(response.json())

    async def create_stack(self, url: str) -> str:
        """Initiate stack creation from a URL.

        Args:
            url: URL to process into a summary stack

        Returns:
            session_id for polling status

        Raises:
            SummaryStackCoreAPIError: If API request fails
        """
        headers = self._headers()
        headers["Content-Type"] = "application/x-www-form-urlencoded"

        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self.api_url}/api/v1/stacks",
                data={"uri": url},
                headers=headers,
                timeout=30.0,
            )

            if response.status_code == 202:
                data: dict[str, Any] = response.json()
                session_id = data.get("session_id")
                if not session_id:
                    raise SummaryStackCoreAPIError("API response missing session_id")
                logger.info(f"Stack creation initiated, session_id: {session_id}")
                return str(session_id)

            self._raise_for_status(response)
            raise SummaryStackCoreAPIError(f"Unexpected response status: {response.status_code}")

    async def poll_session_status(self, session_id: str) -> dict[str, Any]:
        """Poll session status endpoint.

        Args:
            session_id: Session ID from create_stack response

        Returns:
            Status response dict with 'status' and additional fields

        Raises:
            SummaryStackCoreAPIError: If API request fails
        """
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{self.api_url}/api/v1/sessions/{session_id}/status",
                headers=self._headers(),
                timeout=30.0,
            )
            self._raise_for_status(response)
            result: dict[str, Any] = response.json()
            return result

    async def create_and_wait(self, url: str) -> SummaryStackData:
        """Create a summary stack and wait for completion.

        High-level method that creates a stack, polls for completion,
        and returns the full stack data.

        Args:
            url: URL to process into a summary stack

        Returns:
            Full SummaryStackData for the created stack

        Raises:
            SummaryStackCoreAPIError: If processing fails or times out
        """
        session_id = await self.create_stack(url)

        elapsed = 0.0
        while elapsed < MAX_POLL_TIMEOUT_SECONDS:
            status_response = await self.poll_session_status(session_id)
            status = status_response.get("status")

            if status == "complete":
                summary_stack_id = status_response.get("summary_stack_id")
                if not summary_stack_id:
                    raise SummaryStackCoreAPIError("Complete status missing summary_stack_id")
                logger.info(f"Processing complete, fetching stack: {summary_stack_id}")
                return await self.get_stack(summary_stack_id)

            if status == "error":
                error_msg = status_response.get("error", "Unknown processing error")
                raise SummaryStackCoreAPIError(f"Processing error: {error_msg}")

            if status == "not_found":
                raise SummaryStackCoreAPIError(f"Session not found: {session_id}")

            current_step = status_response.get("current_step", "unknown")
            logger.debug(f"Processing in progress: {current_step} (elapsed: {elapsed:.1f}s)")

            await asyncio.sleep(POLL_INTERVAL_SECONDS)
            elapsed += POLL_INTERVAL_SECONDS

        raise SummaryStackCoreAPIError(f"Processing timeout after {MAX_POLL_TIMEOUT_SECONDS}s")

    async def search_corpus(self, query: str, limit: int = 10) -> CorpusSearchResponse:
        """Search user's corpus (library + knowledge graph).

        Calls the corpus SSE endpoint and waits for the corpus_search_complete event.

        Args:
            query: Search query
            limit: Maximum results to return

        Returns:
            CorpusSearchResponse with search results

        Raises:
            SummaryStackCoreAPIError: If API request fails or no results event received
        """
        headers = self._headers()
        headers["Accept"] = "text/event-stream"

        async with (
            httpx.AsyncClient() as client,
            client.stream(
                "POST",
                f"{self.api_url}/api/v1/corpus/sse",
                json={"query": query},
                headers=headers,
                timeout=60.0,
            ) as response,
        ):
            if not response.is_success:
                await response.aread()
                self._raise_for_status(response)

            results = await self._parse_corpus_sse_stream(response, limit)
            return CorpusSearchResponse(results=results)

    async def _parse_corpus_sse_stream(self, response: httpx.Response, limit: int) -> list[CorpusSearchResult]:
        """Parse SSE stream from corpus endpoint.

        Args:
            response: Streaming HTTP response
            limit: Maximum results to return

        Returns:
            List of corpus search results

        Raises:
            SummaryStackCoreAPIError: If stream ends without results
        """
        buffer = ""

        async for chunk in response.aiter_text():
            buffer += chunk

            while "\n\n" in buffer:
                event_str, buffer = buffer.split("\n\n", 1)

                for line in event_str.split("\n"):
                    if line.startswith("data: "):
                        data_str = line[6:]
                        try:
                            data = json.loads(data_str)
                        except json.JSONDecodeError:
                            logger.warning(f"Failed to parse SSE data: {data_str}")
                            continue

                        event_type = data.get("type")

                        if event_type == "corpus_search_complete":
                            raw_results = data.get("metadata", {}).get("results", [])
                            results = [CorpusSearchResult.model_validate(r) for r in raw_results[:limit]]
                            return results

                        if event_type == "error":
                            error_msg = data.get("metadata", {}).get("error", "Unknown error")
                            raise SummaryStackCoreAPIError(message=f"Corpus search error: {error_msg}")

        raise SummaryStackCoreAPIError(message="Corpus search stream ended without results")

    def _raise_for_status(self, response: httpx.Response) -> None:
        """Raise exception for error responses.

        Args:
            response: HTTP response

        Raises:
            SummaryStackCoreAPIError: If response indicates an error
        """
        if response.is_success:
            return

        try:
            detail = response.json().get("detail", response.text)
        except Exception:
            detail = response.text

        raise SummaryStackCoreAPIError(
            message=f"API error: {detail}",
            status_code=response.status_code,
        )
