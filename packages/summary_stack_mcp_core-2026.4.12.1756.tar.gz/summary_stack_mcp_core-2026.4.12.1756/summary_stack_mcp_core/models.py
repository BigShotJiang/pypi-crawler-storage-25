"""Response models for Summary Stack MCP core."""

from pydantic import BaseModel


class CorpusSearchResult(BaseModel):
    """A single result from corpus search."""

    summary_stack_id: str
    title: str
    uri: str
    source_type: str
    source_domain: str | None = None
    thumbnail_url: str | None = None
    created_at: str | None = None
    executive_summary: str | None = None
    key_insights: list[str] | None = None
    matching_chunks: list[str] | None = None
    similarity: float | None = None
    search_source: str | None = None  # "rag" for vector search, "graph" for knowledge graph


class CorpusSearchResponse(BaseModel):
    """Response from corpus search endpoint."""

    results: list[CorpusSearchResult]
