"""Tests for SummaryStackCoreAPIClient."""

from unittest.mock import AsyncMock, Mock, patch

import pytest
from summary_stack_mcp_core.api_client import SummaryStackCoreAPIClient, SummaryStackCoreAPIError
from summary_stack_models import SummaryStackData


@pytest.fixture
def api_client() -> SummaryStackCoreAPIClient:
    """Create API client instance."""
    return SummaryStackCoreAPIClient(
        api_url="https://api.example.com",
        api_key="test-api-key",
    )


@pytest.fixture
def sample_stack_response() -> dict:
    """Create sample API response matching SummaryStackData schema."""
    return {
        "summary_stack_id": "test-stack-123",
        "title": "Test Document",
        "source_metadata": {
            "uri": "https://example.com/article",
            "source_type": "url",
            "document_type": "technical",
            "classification_confidence": "high",
            "source_domain": "example.com",
        },
        "executive_summary": {
            "summary": "This is a test summary.",
            "bullets": [
                {"text": "First insight", "source_phrase": "phrase 1", "theme": "Theme1"},
                {"text": "Second insight", "source_phrase": "phrase 2", "theme": "Theme2"},
            ],
            "metadata": {},
        },
        "synthesized_content": {
            "overview": "Overview text",
            "key_takeaways": "Key takeaways text",
            "core_ideas": "Core ideas text",
            "evidence_intro": "Evidence intro",
        },
        "passages": [],
        "word_count": 1000,
    }


@pytest.mark.asyncio
class TestGetStack:
    """Tests for get_stack() method."""

    async def test_returns_summary_stack_data_directly(
        self,
        api_client: SummaryStackCoreAPIClient,
        sample_stack_response: dict,
    ) -> None:
        """Should deserialize response directly to SummaryStackData."""
        mock_response = Mock()
        mock_response.is_success = True
        mock_response.json.return_value = sample_stack_response

        with patch("httpx.AsyncClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client_class.return_value.__aenter__.return_value = mock_client
            mock_client.get.return_value = mock_response

            result = await api_client.get_stack("test-stack-123")

        assert isinstance(result, SummaryStackData)
        assert result.summary_stack_id == "test-stack-123"
        assert result.title == "Test Document"
        assert result.executive_summary.summary == "This is a test summary."
        assert len(result.executive_summary.bullets) == 2
        assert result.executive_summary.bullets[0].theme == "Theme1"
        assert result.executive_summary.bullets[0].source_phrase == "phrase 1"
        assert result.synthesized_content is not None
        assert result.synthesized_content.overview == "Overview text"

    async def test_calls_correct_endpoint(
        self,
        api_client: SummaryStackCoreAPIClient,
        sample_stack_response: dict,
    ) -> None:
        """Should call GET /api/v1/stacks/{stack_id}."""
        mock_response = Mock()
        mock_response.is_success = True
        mock_response.json.return_value = sample_stack_response

        with patch("httpx.AsyncClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client_class.return_value.__aenter__.return_value = mock_client
            mock_client.get.return_value = mock_response

            await api_client.get_stack("test-stack-123")

        mock_client.get.assert_called_once_with(
            "https://api.example.com/api/v1/stacks/test-stack-123",
            headers={"X-API-Key": "test-api-key", "Content-Type": "application/json"},
            timeout=30.0,
        )

    async def test_raises_error_on_404(
        self,
        api_client: SummaryStackCoreAPIClient,
    ) -> None:
        """Should raise SummaryStackCoreAPIError on 404."""
        mock_response = Mock()
        mock_response.is_success = False
        mock_response.status_code = 404
        mock_response.json.return_value = {"detail": "Stack not found"}
        mock_response.text = "Stack not found"

        with patch("httpx.AsyncClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client_class.return_value.__aenter__.return_value = mock_client
            mock_client.get.return_value = mock_response

            with pytest.raises(SummaryStackCoreAPIError) as exc_info:
                await api_client.get_stack("nonexistent")

        assert exc_info.value.status_code == 404
        assert "Stack not found" in str(exc_info.value)


class TestCardToStackDataRemoved:
    """Verify _card_to_stack_data conversion method has been removed."""

    def test_card_to_stack_data_method_does_not_exist(self) -> None:
        """Should NOT have _card_to_stack_data method anymore."""
        api_client = SummaryStackCoreAPIClient(
            api_url="https://api.example.com",
            api_key="test-api-key",
        )
        assert not hasattr(api_client, "_card_to_stack_data")
