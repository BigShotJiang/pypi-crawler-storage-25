"""Tests for MCP tools output formatting."""

from unittest.mock import AsyncMock, patch

import pytest
from summary_stack_mcp_core.tools import get_stack
from summary_stack_models import (
    ExecutiveSummary,
    ExecutiveSummaryBullet,
    Passage,
    SourceMetadata,
    SourceType,
    SummaryStackData,
    SynthesizedContent,
)


pytestmark = pytest.mark.asyncio


@pytest.fixture
def sample_stack_with_synthesized() -> SummaryStackData:
    """Create sample stack with synthesized content."""
    return SummaryStackData(
        summary_stack_id="test-stack-123",
        title="Test Document",
        source_metadata=SourceMetadata(
            uri="https://example.com/article",
            source_type=SourceType.URL,
            document_type="technical",
            classification_confidence="high",
            source_domain="example.com",
        ),
        executive_summary=ExecutiveSummary(
            summary="This is a test summary.",
            bullets=[
                ExecutiveSummaryBullet(text="First insight", source_phrase="original phrase 1", theme="Architecture"),
                ExecutiveSummaryBullet(text="Second insight", source_phrase="original phrase 2", theme="Performance"),
            ],
            metadata={},
        ),
        synthesized_content=SynthesizedContent(
            overview="This is the overview.",
            key_takeaways="These are the key takeaways.",
            core_ideas="These are the core ideas.",
            evidence_intro="Evidence introduction.",
        ),
        passages=[
            Passage(id=1, text="Passage 1", reason="Core insight", criterion="core_argument", phrases=[]),
            Passage(id=2, text="Passage 2", reason="Evidence", criterion="specific_evidence", phrases=[]),
            Passage(id=3, text="Passage 3", reason="Framework", criterion="novel_framework", phrases=[]),
        ],
    )


@pytest.fixture
def sample_stack_without_synthesized() -> SummaryStackData:
    """Create sample stack without synthesized content."""
    return SummaryStackData(
        summary_stack_id="test-stack-456",
        title="Basic Document",
        source_metadata=SourceMetadata(
            uri="https://example.com/basic",
            source_type=SourceType.URL,
            source_domain="example.com",
        ),
        executive_summary=ExecutiveSummary(
            summary="Basic summary.",
            bullets=[
                ExecutiveSummaryBullet(text="Simple insight", source_phrase="simple phrase", theme="General"),
            ],
            metadata={},
        ),
        synthesized_content=None,
        passages=[],
    )


class TestGetStackOutputFormat:
    """Tests for get_stack tool output formatting."""

    @patch("summary_stack_mcp_core.tools.load_config")
    @patch("summary_stack_mcp_core.tools.SummaryStackCoreAPIClient")
    async def test_includes_themed_bullets_with_source_phrases(
        self,
        mock_client_class,
        mock_load_config,
        sample_stack_with_synthesized: SummaryStackData,
    ) -> None:
        """Should include themed bullets with source phrases."""
        mock_config = AsyncMock()
        mock_config.api_url = "https://api.example.com"
        mock_config.api_key = "test-key"
        mock_load_config.return_value = mock_config

        mock_client = AsyncMock()
        mock_client.get_stack.return_value = sample_stack_with_synthesized
        mock_client_class.return_value = mock_client

        result = await get_stack("test-stack-123")

        assert "## Key Insights" in result
        assert "[Architecture] First insight" in result
        assert "[Performance] Second insight" in result
        assert '> Source: "original phrase 1"' in result
        assert '> Source: "original phrase 2"' in result

    @patch("summary_stack_mcp_core.tools.load_config")
    @patch("summary_stack_mcp_core.tools.SummaryStackCoreAPIClient")
    async def test_includes_synthesized_content_sections(
        self,
        mock_client_class,
        mock_load_config,
        sample_stack_with_synthesized: SummaryStackData,
    ) -> None:
        """Should include synthesized content sections when present."""
        mock_config = AsyncMock()
        mock_config.api_url = "https://api.example.com"
        mock_config.api_key = "test-key"
        mock_load_config.return_value = mock_config

        mock_client = AsyncMock()
        mock_client.get_stack.return_value = sample_stack_with_synthesized
        mock_client_class.return_value = mock_client

        result = await get_stack("test-stack-123")

        assert "## Synthesized Content" in result
        assert "### Overview" in result
        assert "This is the overview." in result
        assert "### Key Takeaways" in result
        assert "These are the key takeaways." in result
        assert "### Core Ideas" in result
        assert "These are the core ideas." in result

    @patch("summary_stack_mcp_core.tools.load_config")
    @patch("summary_stack_mcp_core.tools.SummaryStackCoreAPIClient")
    async def test_shows_placeholder_when_no_synthesized_content(
        self,
        mock_client_class,
        mock_load_config,
        sample_stack_without_synthesized: SummaryStackData,
    ) -> None:
        """Should show placeholder when synthesized content not available."""
        mock_config = AsyncMock()
        mock_config.api_url = "https://api.example.com"
        mock_config.api_key = "test-key"
        mock_load_config.return_value = mock_config

        mock_client = AsyncMock()
        mock_client.get_stack.return_value = sample_stack_without_synthesized
        mock_client_class.return_value = mock_client

        result = await get_stack("test-stack-456")

        assert "## Synthesized Content" in result
        assert "Synthesized content not available." in result
        assert "### Overview" not in result

    @patch("summary_stack_mcp_core.tools.load_config")
    @patch("summary_stack_mcp_core.tools.SummaryStackCoreAPIClient")
    async def test_includes_classification_info(
        self,
        mock_client_class,
        mock_load_config,
        sample_stack_with_synthesized: SummaryStackData,
    ) -> None:
        """Should include document type and classification confidence."""
        mock_config = AsyncMock()
        mock_config.api_url = "https://api.example.com"
        mock_config.api_key = "test-key"
        mock_load_config.return_value = mock_config

        mock_client = AsyncMock()
        mock_client.get_stack.return_value = sample_stack_with_synthesized
        mock_client_class.return_value = mock_client

        result = await get_stack("test-stack-123")

        assert "## Source" in result
        assert "**Document Type:**" in result
        assert "TECHNICAL" in result.upper()
        assert "**Classification Confidence:** high" in result

    @patch("summary_stack_mcp_core.tools.load_config")
    @patch("summary_stack_mcp_core.tools.SummaryStackCoreAPIClient")
    async def test_includes_passage_count(
        self,
        mock_client_class,
        mock_load_config,
        sample_stack_with_synthesized: SummaryStackData,
    ) -> None:
        """Should include total passage count."""
        mock_config = AsyncMock()
        mock_config.api_url = "https://api.example.com"
        mock_config.api_key = "test-key"
        mock_load_config.return_value = mock_config

        mock_client = AsyncMock()
        mock_client.get_stack.return_value = sample_stack_with_synthesized
        mock_client_class.return_value = mock_client

        result = await get_stack("test-stack-123")

        assert "## Content Depth" in result
        assert "**3 passages**" in result

    @patch("summary_stack_mcp_core.tools.load_config")
    @patch("summary_stack_mcp_core.tools.SummaryStackCoreAPIClient")
    async def test_includes_zero_passages_when_empty(
        self,
        mock_client_class,
        mock_load_config,
        sample_stack_without_synthesized: SummaryStackData,
    ) -> None:
        """Should show 0 passages when list is empty."""
        mock_config = AsyncMock()
        mock_config.api_url = "https://api.example.com"
        mock_config.api_key = "test-key"
        mock_load_config.return_value = mock_config

        mock_client = AsyncMock()
        mock_client.get_stack.return_value = sample_stack_without_synthesized
        mock_client_class.return_value = mock_client

        result = await get_stack("test-stack-456")

        assert "**0 passages**" in result
