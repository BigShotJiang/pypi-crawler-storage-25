# Examples index

## 1. Canonical mTLS tour (localhost:8001)

**[`canonical_mtls_localhost_8001.py`](canonical_mtls_localhost_8001.py)** — full operational walkthrough of **`EmbeddingClient`** against **localhost:8001** with **mTLS**, using **`mtls_certificates/client/`** and **`mtls_certificates/ca/`** (see **`mtls_certificates/README.md`** if present).

| Environment | Purpose |
|-------------|---------|
| **`RUN_CANONICAL_MTLS_E2E=1`** | Perform live JSON-RPC/WebSocket calls (requires a matching server) |
| **`CANONICAL_EMBED_FILE_SERVER_PATH`** | Optional server-visible path; includes **`embed_file`** in the tour when set |

Dry run (no network):

```bash
python examples/canonical_mtls_localhost_8001.py
```

Execution-based tests: **[`tests/test_canonical_mtls_example.py`](../tests/test_canonical_mtls_example.py)**.

## 2. Local `json_array` file → `embed_file` (CLI)

Sample input: **[`data/embed_file_json_array_sample.json`](data/embed_file_json_array_sample.json)** (UTF-8 JSON array of strings).

**Flow for Markdown** (e.g. repo root **`7d-00-48.md`** — YAML front matter is not valid **`json_array`** as-is): prepare JSON on disk, then **`embed-file-json`**. **`prepare-embed-file-json`** splits the body **only** on **double newlines** (**`\n\n`**): each non-empty paragraph is one JSON string; there is no semantic or byte-level auto-chunking, so each paragraph must stay under the UTF-8 byte limit or preparation errors. Large documents: use **`--max-chunks`** on prepare to **truncate** the paragraph list for a subset smoke test.

```bash
python -m embed_client prepare-embed-file-json ./7d-00-48.md -o /tmp/7d_embed.json --max-chunks 5
embed-vectorize --config /path/to/config.json embed-file-json /tmp/7d_embed.json --show-progress
```

With a suitable config and a running service (direct sample JSON):

```bash
embed-vectorize --config /path/to/config.json embed-file-json examples/data/embed_file_json_array_sample.json
```

Equivalent module invocation:

```bash
python -m embed_client --config /path/to/config.json embed-file-json examples/data/embed_file_json_array_sample.json
```

Minimal programmatic twin of **`embed-file-json`**: **[`embed_file_json_local.py`](embed_file_json_local.py)** (requires env/config for **`ClientFactory`**).

See **`CLI_README.md`** (`prepare-embed-file-json`, `embed-file-json`) and **`docs/api_format.md`** (`embed_file`).

## 3. Other scripts

| Script | Description |
|--------|-------------|
| [`async_testing_client_example.py`](async_testing_client_example.py) | Generate sample config, validate with **`ConfigValidator`**, smoke **`EmbeddingClient`** |
| [`security_examples.py`](security_examples.py) | English demos of security modes via **`argparse`** |
| [`security_examples_ru.py`](security_examples_ru.py) | Russian demos of security modes (same ideas) |

Sample JSON under **`examples/configs/`** may be created by the security examples when run.
