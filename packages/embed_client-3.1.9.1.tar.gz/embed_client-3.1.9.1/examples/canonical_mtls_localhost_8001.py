#!/usr/bin/env python3
# flake8: noqa: E501 — long man-page docstring lines are intentional.

"""
NAME
    canonical_mtls_localhost_8001 — end-to-end :class:`~embed_client.embedding_client.EmbeddingClient` walkthrough against the real embedding service

SYNOPSIS
    From the repository root (so ``mtls_certificates/`` resolves)::

        python examples/canonical_mtls_localhost_8001.py

    Optional real-server integration check (same host/port, mTLS)::

        RUN_CANONICAL_MTLS_E2E=1 python examples/canonical_mtls_localhost_8001.py

DESCRIPTION
    This script is **runnable documentation** for the migrated client. It targets
    **localhost:8001** with **mutual TLS**, using the repository’s **client**
    certificate bundle under ``mtls_certificates/client/`` and the **CA** under
    ``mtls_certificates/ca/`` (see ``mtls_certificates/README.md``).

    In one asyncio task chain it exercises the **public surface** of
    :class:`embed_client.embedding_client.EmbeddingClient` that is meaningful
    without deployment-specific server filesystem paths:

    - :meth:`~embed_client.embedding_client.EmbeddingClient.health`
    - :meth:`~embed_client.embedding_client.EmbeddingClient.models`
    - :meth:`~embed_client.embedding_client.EmbeddingClient.list_commands`
    - :meth:`~embed_client.embedding_client.EmbeddingClient.cmd` (``embed``)
    - :meth:`~embed_client.embedding_client.EmbeddingClient.embed` (``wait=True`` synchronous-style result)
    - :meth:`~embed_client.embedding_client.EmbeddingClient.embed` (``wait=False``) +
      :meth:`~embed_client.embedding_client.EmbeddingClient.wait_for_job` when a ``job_id`` is returned
    - :meth:`~embed_client.embedding_client.EmbeddingClient.job_status` (poll path smoke)
    - :meth:`~embed_client.embedding_client.EmbeddingClient.list_queued_commands`
    - :meth:`~embed_client.embedding_client.EmbeddingClient.timing_stats`
    - :meth:`~embed_client.embedding_client.EmbeddingClient.fetch_openapi_schema`
    - :meth:`~embed_client.embedding_client.EmbeddingClient.http_get` (e.g. ``/docs``)
    - :meth:`~embed_client.embedding_client.EmbeddingClient.jsonrpc` (low-level JSON-RPC)
    - :meth:`~embed_client.embedding_client.EmbeddingClient.embed_file` — **only if**
      ``CANONICAL_EMBED_FILE_SERVER_PATH`` is set to a **server-visible** UTF-8 file path
      (optional; skipped with a log line when unset). See :meth:`~embed_client.embedding_client.EmbeddingClient.embed_file`.

    When ``RUN_CANONICAL_MTLS_E2E`` is unset, the script runs a **dry** path:
    it still loads config and prints the planned steps (for CI/import checks).
    When set to ``1``, it opens a real client and runs the network calls; failures
    are printed and the process exits with non-zero status.

ENVIRONMENT
    RUN_CANONICAL_MTLS_E2E
        If ``1``, perform live calls to ``localhost:8001``. Otherwise print the
        configuration summary and exit successfully (no network).

    CANONICAL_EMBED_FILE_SERVER_PATH
        Optional. If set to a non-empty, server-visible path, the tour calls
        :meth:`~embed_client.embedding_client.EmbeddingClient.embed_file` with
        ``wait=True``, ``wait_timeout=600``, ``error_policy="continue"``.
        If unset or whitespace-only, a single skip line is logged instead.

FILES
    ``mtls_certificates/client/embedding-service.crt``
    ``mtls_certificates/client/embedding-service.key``
    ``mtls_certificates/ca/ca.crt``

EXIT STATUS
    0 on success (or dry run). Non-zero if any live step raises and
    ``RUN_CANONICAL_MTLS_E2E=1``.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

import asyncio
import os
import sys
from pathlib import Path
from typing import Any, Dict, List

_ROOT = Path(__file__).resolve().parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from embed_client.embedding_client import EmbeddingClient  # noqa: E402
from embed_client.exceptions import EmbedClientError  # noqa: E402


def _cert_paths(root: Path) -> Dict[str, str]:
    base = root / "mtls_certificates"
    return {
        "cert_file": str(base / "client" / "embedding-service.crt"),
        "key_file": str(base / "client" / "embedding-service.key"),
        "ca_cert_file": str(base / "ca" / "ca.crt"),
    }


def build_mtls_localhost_8001_config(root: Path) -> Dict[str, Any]:
    """Return a config dict for mTLS to localhost:8001 using repository certs."""
    c = _cert_paths(root)
    for k, p in c.items():
        if not Path(p).is_file():
            raise FileNotFoundError(f"Missing {k}: {p}")
    return {
        "protocol": "mtls",
        "server": {"host": "localhost", "port": 8001},
        "auth": {
            "method": "certificate",
            "certificate": {
                "enabled": True,
                "cert_file": c["cert_file"],
                "key_file": c["key_file"],
                "ca_cert_file": c["ca_cert_file"],
            },
        },
        "ssl": {
            "enabled": True,
            "verify_mode": "CERT_REQUIRED",
            "check_hostname": False,
            "check_expiry": False,
            "cert_file": c["cert_file"],
            "key_file": c["key_file"],
            "ca_cert_file": c["ca_cert_file"],
        },
        "client": {"timeout": 120.0},
    }


async def run_live_capabilities(client: EmbeddingClient) -> List[str]:
    """Execute capability checks; return human-readable step log lines."""
    lines: List[str] = []

    h = await client.health()
    lines.append(f"health: {repr(h)[:200]}")

    m = await client.models()
    lines.append(f"models keys: {list(m.keys()) if isinstance(m, dict) else type(m)}")

    lc = await client.list_commands()
    lines.append(f"list_commands: {str(lc)[:200]}")

    emb_cmd = await client.cmd(
        "embed",
        {"texts": ["canonical cmd embed"], "error_policy": "continue"},
    )
    lines.append(f"cmd(embed): {str(emb_cmd)[:200]}...")

    sync_result = await client.embed(
        ["hello from wait=True"],
        wait=True,
        wait_timeout=120,
        error_policy="continue",
    )
    lines.append(f"embed(wait=True): has results = {'results' in sync_result}")

    queued = await client.embed(["queued path"], wait=False, error_policy="continue")
    jid = queued.get("job_id") if isinstance(queued, dict) else None
    lines.append(f"embed(wait=False): job_id={jid!r}")
    if jid:
        st = await client.job_status(jid)
        lines.append(f"job_status({jid}): {str(st)[:200]}...")
        try:
            done = await client.wait_for_job(jid, timeout=120)
            lines.append(
                f"wait_for_job: keys={list(done.keys()) if isinstance(done, dict) else type(done)}"
            )
        except (EmbedClientError, TimeoutError, asyncio.TimeoutError) as ex:
            lines.append(f"wait_for_job: {ex!r}")

    lq = await client.list_queued_commands(limit=5)
    lines.append(f"list_queued_commands: {str(lq)[:200]}...")

    try:
        ts = await client.timing_stats()
        lines.append(f"timing_stats: {str(ts)[:200]}...")
    except EmbedClientError as ex:
        lines.append(f"timing_stats (optional): {ex}")

    try:
        oa = await client.fetch_openapi_schema()
        lines.append(f"fetch_openapi_schema: top keys={list(oa.keys())[:8]}")
    except Exception as ex:  # noqa: BLE001 — surface server differences
        lines.append(f"fetch_openapi_schema (optional): {ex!r}")

    try:
        code, body = await client.http_get("/docs")
        lines.append(f"http_get(/docs): status={code} len={len(body)}")
    except Exception as ex:  # noqa: BLE001
        lines.append(f"http_get (optional): {ex!r}")

    jr = await client.jsonrpc("health", {})
    lines.append(f"jsonrpc(health): {str(jr)[:200]}...")

    path_raw = os.environ.get("CANONICAL_EMBED_FILE_SERVER_PATH")
    if path_raw is None or not str(path_raw).strip():
        lines.append(
            "embed_file skipped; set CANONICAL_EMBED_FILE_SERVER_PATH to a "
            "server-visible path to include embed_file in this tour."
        )
    else:
        input_file = str(path_raw).strip()
        ef = await client.embed_file(
            input_file,
            wait=True,
            wait_timeout=600,
            error_policy="continue",
        )
        lines.append(f"embed_file: {str(ef)[:200]}")

    return lines


async def main() -> None:
    cfg = build_mtls_localhost_8001_config(_ROOT)
    live = os.environ.get("RUN_CANONICAL_MTLS_E2E") == "1"
    print("canonical_mtls_localhost_8001")
    print("  repo root:", _ROOT)
    print("  live E2E:", live)

    if not live:
        print("Dry run — set RUN_CANONICAL_MTLS_E2E=1 for localhost:8001 mTLS calls.")
        print(
            "Optional: CANONICAL_EMBED_FILE_SERVER_PATH=<server-visible path> for embed_file."
        )
        print("Config protocol:", cfg.get("protocol"), "port:", cfg["server"]["port"])
        return

    async with EmbeddingClient.from_config_dict(cfg) as client:
        lines = await run_live_capabilities(client)
    for ln in lines:
        print(ln)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
