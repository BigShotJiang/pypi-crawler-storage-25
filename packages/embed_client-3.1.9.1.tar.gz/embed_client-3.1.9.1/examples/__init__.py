"""Runnable documentation and configuration samples (not part of the installed package)."""
