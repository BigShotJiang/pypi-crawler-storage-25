#!/usr/bin/env python3
"""
Minimal example: local UTF-8 ``json_array`` file → ``embed_file_from_local_json_file``.

Uses the same path as CLI ``embed-file-json`` (validate → upload → ``embed_file``).
JSON from ``prepare-embed-file-json`` uses paragraph blocks split on ``\\n\\n`` only.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
import time

from embed_client.client_factory import ClientFactory
from embed_client.embed_file_output_validate import (
    EmbedFileJobPerfReport,
    format_perf_report_lines,
    format_validation_checklist_lines,
    validate_embed_file_job_result,
)
from embed_client.embedding_client import EmbeddingClient
from embed_client.exceptions import EmbedClientError
from embed_client.json_embed_file_preflight import iter_json_array_block_texts


async def _run(json_path: str) -> int:
    blocks = iter_json_array_block_texts(json_path)
    client: EmbeddingClient = ClientFactory.from_environment()
    async with client:
        t0 = time.perf_counter()
        out = await client.embed_file_from_local_json_file(
            json_path,
            wait_timeout=600,
        )
        elapsed = time.perf_counter() - t0
        perf = EmbedFileJobPerfReport(total_seconds=elapsed, block_count=len(blocks))
        for ln in format_perf_report_lines(perf):
            print(ln, file=sys.stderr, flush=True)
        try:
            vreport = validate_embed_file_job_result(blocks, out, rpc_dimension=None)
        except EmbedClientError as exc:
            print(f"embed_file output validation error: {exc}", file=sys.stderr)
            print(json.dumps(out, indent=2))
            return 1
        for ln in format_validation_checklist_lines(vreport):
            print(ln, file=sys.stderr, flush=True)
        if not vreport.ok:
            print("embed_file output validation failed.", file=sys.stderr)
            print(json.dumps(out, indent=2))
            return 1
        print(json.dumps(out, indent=2))
    return 0


def main() -> None:
    p = argparse.ArgumentParser(
        description="embed_file_from_local_json_file example (requires running service)"
    )
    p.add_argument(
        "json_path",
        help="UTF-8 JSON array of strings (see json_embed_file_preflight)",
    )
    args = p.parse_args()
    path = os.path.abspath(args.json_path)
    if not os.path.isfile(path):
        print(f"not a file: {path}", file=sys.stderr)
        sys.exit(1)
    sys.exit(asyncio.run(_run(path)))


if __name__ == "__main__":
    main()
