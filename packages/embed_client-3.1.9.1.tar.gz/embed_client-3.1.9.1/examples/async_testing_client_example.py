#!/usr/bin/env python3
# flake8: noqa: E501 — long man-page docstring lines are intentional.
"""
NAME
    async_testing_client_example — minimal smoke test for
    :class:`~embed_client.embedding_client.EmbeddingClient` with generated config

SYNOPSIS
    From the repository root::

        python examples/async_testing_client_example.py

DESCRIPTION
    Inserts the repository root into ``sys.path``, then:

    #. Uses :class:`~embed_client.config_generator.ClientConfigGenerator` to emit a
       sample HTTP config under ``configs/_example_generated_http.json``.
    #. Validates that file with :class:`~embed_client.config_validator.ConfigValidator`.
    #. Opens :class:`~embed_client.embedding_client.EmbeddingClient` from the file and
       calls :meth:`~embed_client.embedding_client.EmbeddingClient.health`.

    Legacy ``EmbeddingServiceAsyncClient`` was removed; this script uses **EmbeddingClient** only.

SEE ALSO
    docs/client_integration_guide.md — integration and JSON-RPC semantics.
    README.md — package overview.
    CLI_README.md — ``embed-config-generator`` and ``embed-config-validator`` console scripts.

EXIT STATUS
    **0** on success. Uncaught exceptions propagate (non-zero).

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from embed_client.config_generator import ClientConfigGenerator  # noqa: E402
from embed_client.config_validator import ConfigValidator  # noqa: E402
from embed_client.embedding_client import EmbeddingClient  # noqa: E402


async def main() -> None:
    gen = ClientConfigGenerator()
    out = _ROOT / "configs" / "_example_generated_http.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    config = gen.generate_http_config(
        host="localhost",
        port=8001,
        output_path=out,
    )
    print(
        "Generated config dict keys:",
        list(config.keys()) if isinstance(config, dict) else type(config),
    )

    valid, errors = ConfigValidator().validate_config_file(str(out))
    print("validate_config:", valid, errors)

    async with EmbeddingClient.from_config_file(out) as client:
        h = await client.health()
        print("health:", h)


if __name__ == "__main__":
    asyncio.run(main())
