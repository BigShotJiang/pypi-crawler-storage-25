#!/usr/bin/env python3
"""
NAME
    security_examples — CLI-driven demos of :class:`~embed_client.embedding_client.EmbeddingClient` security patterns

SYNOPSIS
    From the repository root::

        python examples/security_examples.py
        python examples/security_examples.py --config path/to/config.json

DESCRIPTION
    The project deploy matrix defines **eight** server modes (HTTP; HTTP+token;
    HTTP+token+roles; HTTPS; HTTPS+token; HTTPS+token+roles; mTLS; mTLS+roles).
    This script implements **six** runnable ``example_*`` flows (plain HTTP/HTTPS,
    token, mTLS, and roles-focused demos). For the full matrix and field mapping,
    see ``docs/SERVER_MODES_AND_CLIENT.md`` and ``CONFIGURATION.md``.

    Canonical end-to-end tour (localhost:8001, mTLS): ``examples/canonical_mtls_localhost_8001.py``.

SEE ALSO
    docs/SERVER_MODES_AND_CLIENT.md
    examples/canonical_mtls_localhost_8001.py

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import argparse
import asyncio
import json
import os
from typing import Optional

from embed_client.embedding_client import EmbeddingClient
from embed_client.config import ClientConfig
from embed_client.client_factory import (
    ClientFactory,
    create_client_from_env,
    detect_security_mode,
)


def _client_label(client) -> str:
    return f"{client.protocol}://{client.host}:{client.port}"


async def example_1_http_plain(config_path: Optional[str] = None):
    """Example 1: HTTP - plain HTTP without authentication."""
    print("=== Example 1: HTTP - Plain HTTP without authentication ===")

    if config_path:
        async with EmbeddingClient.from_config_file(config_path) as client:
            print(f"Client: {_client_label(client)}")
            print(f"SSL enabled: {(client.protocol in ('https', 'mtls'))}")
            print(f"Authenticated: {bool(client._token)}")
            health = await client.health()
            print(f"Health: {health}")
        return

    # Method 1: Direct client creation
    async with EmbeddingClient.from_base_url_port("http://localhost", 8001) as client:
        print(f"Client: {_client_label(client)}")
        print(f"SSL enabled: {(client.protocol in ('https', 'mtls'))}")
        print(f"Authenticated: {bool(client._token)}")

        # Test health check
        health = await client.health()
        print(f"Health: {health}")

    # Method 2: Using configuration dictionary
    config_dict = {
        "server": {"host": "http://localhost", "port": 8001},
        "auth": {"method": "none"},
        "ssl": {"enabled": False},
    }

    async with EmbeddingClient.from_config_dict(config_dict) as client:
        health = await client.health()
        print(f"Health via config: {health}")

    # Method 3: Using ClientFactory
    client = ClientFactory.create_http_client("http://localhost", 8001)
    print(f"Factory client: {_client_label(client)}")
    await client.close()


async def example_2_http_token(config_path: Optional[str] = None):
    """Example 2: HTTP + Token - HTTP with API Key authentication."""
    print("\n=== Example 2: HTTP + Token - HTTP with API Key authentication ===")

    if config_path:
        async with EmbeddingClient.from_config_file(config_path) as client:
            print(f"Client: {_client_label(client)}")
            print(f"SSL enabled: {(client.protocol in ('https', 'mtls'))}")
            print(f"Authenticated: {bool(client._token)}")
            print(f"Auth method: {'api_key' if client._token else 'none'}")
        return

    # Method 1: Using with_auth class method
    async with EmbeddingClient.with_auth(
        "http://localhost", 8001, "api_key", api_key="your_api_key"
    ) as client:
        print(f"Client: {_client_label(client)}")
        print(f"SSL enabled: {(client.protocol in ('https', 'mtls'))}")
        print(f"Authenticated: {bool(client._token)}")
        print(f"Auth method: {'api_key' if client._token else 'none'}")
        print("Auth headers:", {"X-API-Key": client._token} if client._token else {})

    # Method 2: Using configuration dictionary
    config_dict = {
        "server": {"host": "http://localhost", "port": 8001},
        "auth": {"method": "api_key", "api_keys": {"user": "your_api_key"}},
        "ssl": {"enabled": False},
    }

    async with EmbeddingClient.from_config_dict(config_dict) as client:
        print(f"Auth method via config: {'api_key' if client._token else 'none'}")

    # Method 3: Using ClientFactory
    client = ClientFactory.create_http_token_client(
        "http://localhost", 8001, "api_key", api_key="your_api_key"
    )
    print(f"Factory client auth: {'api_key' if client._token else 'none'}")
    await client.close()


async def example_3_https_plain(config_path: Optional[str] = None):
    """Example 3: HTTPS - HTTPS with server certificate verification."""
    print("\n=== Example 3: HTTPS - HTTPS with server certificate verification ===")

    if config_path:
        async with EmbeddingClient.from_config_file(config_path) as client:
            print(f"Client: {_client_label(client)}")
            print(f"SSL enabled: {(client.protocol in ('https', 'mtls'))}")
            print(f"Authenticated: {bool(client._token)}")
            if client.protocol in ("https", "mtls"):
                ssl_config = {"protocol": client.protocol}
                print(f"SSL config: {ssl_config}")
        return

    # Method 1: Direct client creation with HTTPS
    config_dict = {
        "server": {"host": "https://localhost", "port": 8443},
        "auth": {"method": "none"},
        "ssl": {
            "enabled": True,
            "verify_mode": "CERT_REQUIRED",
            "check_hostname": True,
            "check_expiry": True,
        },
    }

    async with EmbeddingClient.from_config_dict(config_dict) as client:
        print(f"Client: {_client_label(client)}")
        print(f"SSL enabled: {(client.protocol in ('https', 'mtls'))}")
        print(f"Authenticated: {bool(client._token)}")
        if client.protocol in ("https", "mtls"):
            ssl_config = {"protocol": client.protocol}
            print(f"SSL config: {ssl_config}")

    # Method 2: Using ClientFactory
    client = ClientFactory.create_https_client("https://localhost", 8443)
    print(f"Factory HTTPS client: {_client_label(client)}")
    await client.close()


async def example_4_https_token(config_path: Optional[str] = None):
    """Example 4: HTTPS + Token - HTTPS with server certificates + authentication."""
    print(
        "\n=== Example 4: HTTPS + Token - HTTPS with server certificates + authentication ==="
    )

    if config_path:
        async with EmbeddingClient.from_config_file(config_path) as client:
            print(f"Client: {_client_label(client)}")
            print(f"SSL enabled: {(client.protocol in ('https', 'mtls'))}")
            print(f"Authenticated: {bool(client._token)}")
            print(f"Auth method: {'api_key' if client._token else 'none'}")
        return

    # Method 1: Using with_auth with HTTPS
    async with EmbeddingClient.with_auth(
        "https://localhost",
        8443,
        "basic",
        username="admin",
        password="secret",
        ssl_enabled=True,
        verify_mode="CERT_REQUIRED",
        check_hostname=True,
    ) as client:
        print(f"Client: {_client_label(client)}")
        print(f"SSL enabled: {(client.protocol in ('https', 'mtls'))}")
        print(f"Authenticated: {bool(client._token)}")
        print(f"Auth method: {'api_key' if client._token else 'none'}")
        print("Auth headers:", {"X-API-Key": client._token} if client._token else {})

    # Method 2: Using configuration dictionary
    config_dict = {
        "server": {"host": "https://localhost", "port": 8443},
        "auth": {
            "method": "jwt",
            "jwt": {
                "secret": "your_jwt_secret",
                "username": "admin",
                "password": "secret",
            },
        },
        "ssl": {
            "enabled": True,
            "verify_mode": "CERT_REQUIRED",
            "check_hostname": True,
            "check_expiry": True,
        },
    }

    async with EmbeddingClient.from_config_dict(config_dict) as client:
        print(f"JWT auth method: {'api_key' if client._token else 'none'}")

    # Method 3: Using ClientFactory
    client = ClientFactory.create_https_token_client(
        "https://localhost", 8443, "api_key", api_key="your_api_key"
    )
    print(f"Factory HTTPS+Token client: {'api_key' if client._token else 'none'}")
    await client.close()


async def example_5_mtls(config_path: Optional[str] = None):
    """Example 5: mTLS - mutual TLS with client and server certificates."""
    print("\n=== Example 5: mTLS - Mutual TLS with client and server certificates ===")

    if config_path:
        async with EmbeddingClient.from_config_file(config_path) as client:
            print(f"Client: {_client_label(client)}")
            print(f"SSL enabled: {(client.protocol in ('https', 'mtls'))}")
            print(f"mTLS enabled: {(client.protocol == 'mtls')}")
            print(f"Authenticated: {bool(client._token)}")
            health = await client.health()
            print(f"Health: {health}")
        return

    # Method 1: Using with_auth with certificates
    async with EmbeddingClient.with_auth(
        "https://localhost",
        8443,
        "certificate",
        cert_file="mtls_certificates/client/embedding-service.crt",
        key_file="mtls_certificates/client/embedding-service.key",
        ca_cert_file="mtls_certificates/ca/ca.crt",
        ssl_enabled=True,
        verify_mode="CERT_REQUIRED",
        check_hostname=True,
    ) as client:
        print(f"Client: {_client_label(client)}")
        print(f"SSL enabled: {(client.protocol in ('https', 'mtls'))}")
        print(f"mTLS enabled: {(client.protocol == 'mtls')}")
        print(f"Authenticated: {bool(client._token)}")
        print(f"Auth method: {'api_key' if client._token else 'none'}")
        if client.protocol in ("https", "mtls"):
            ssl_config = {"protocol": client.protocol}
            print(f"SSL config: {ssl_config}")

    # Method 2: Using configuration dictionary
    config_dict = {
        "server": {"host": "https://localhost", "port": 8443},
        "auth": {
            "method": "certificate",
            "certificate": {
                "cert_file": "mtls_certificates/client/embedding-service.crt",
                "key_file": "mtls_certificates/client/embedding-service.key",
                "ca_cert_file": "mtls_certificates/ca/ca.crt",
            },
        },
        "ssl": {
            "enabled": True,
            "verify_mode": "CERT_REQUIRED",
            "check_hostname": True,
            "check_expiry": True,
            "cert_file": "mtls_certificates/client/embedding-service.crt",
            "key_file": "mtls_certificates/client/embedding-service.key",
            "ca_cert_file": "mtls_certificates/ca/ca.crt",
        },
    }

    async with EmbeddingClient.from_config_dict(config_dict) as client:
        print(f"mTLS auth method: {'api_key' if client._token else 'none'}")
        print(f"mTLS enabled: {(client.protocol == 'mtls')}")

    # Method 3: Using ClientFactory
    client = ClientFactory.create_mtls_client(
        "https://localhost",
        "mtls_certificates/client/embedding-service.crt",
        "mtls_certificates/client/embedding-service.key",
        8443,
    )
    print(f"Factory mTLS client: {(client.protocol == 'mtls')}")
    await client.close()


async def example_6_mtls_roles(config_path: Optional[str] = None):
    """Example 6: mTLS + Roles - mTLS with role-based access control."""
    print("\n=== Example 6: mTLS + Roles - mTLS with role-based access control ===")

    if config_path:
        async with EmbeddingClient.from_config_file(config_path) as client:
            print(f"Client: {_client_label(client)}")
            print(f"SSL enabled: {(client.protocol in ('https', 'mtls'))}")
            print(f"mTLS enabled: {(client.protocol == 'mtls')}")
            print(f"Authenticated: {bool(client._token)}")
            print(f"Auth method: {'api_key' if client._token else 'none'}")
        return

    # Method 1: Using configuration dictionary with roles
    config_dict = {
        "server": {"host": "https://localhost", "port": 8443},
        "auth": {
            "method": "certificate",
            "certificate": {
                "cert_file": "mtls_certificates/client/embedding-service.crt",
                "key_file": "mtls_certificates/client/embedding-service.key",
                "ca_cert_file": "mtls_certificates/ca/ca.crt",
            },
        },
        "ssl": {
            "enabled": True,
            "verify_mode": "CERT_REQUIRED",
            "check_hostname": True,
            "check_expiry": True,
            "cert_file": "mtls_certificates/client/embedding-service.crt",
            "key_file": "mtls_certificates/client/embedding-service.key",
            "ca_cert_file": "mtls_certificates/ca/ca.crt",
        },
        "roles": ["admin", "user", "embedding-service"],
        "role_attributes": {
            "department": "IT",
            "service": "embedding",
            "permissions": ["read", "write", "embed"],
        },
    }

    async with EmbeddingClient.from_config_dict(config_dict) as client:
        print(f"Client: {_client_label(client)}")
        print(f"SSL enabled: {(client.protocol in ('https', 'mtls'))}")
        print(f"mTLS enabled: {(client.protocol == 'mtls')}")
        print(f"Authenticated: {bool(client._token)}")
        print(f"Auth method: {'api_key' if client._token else 'none'}")

    # Method 2: Using ClientFactory with roles
    client = ClientFactory.create_mtls_roles_client(
        "https://localhost",
        "mtls_certificates/client/embedding-service.crt",
        "mtls_certificates/client/embedding-service.key",
        8443,
        roles=["admin", "user"],
        role_attributes={"department": "IT"},
    )
    print(f"Factory mTLS+Roles client: {(client.protocol == 'mtls')}")
    await client.close()


async def example_automatic_detection():
    """Example: Automatic security mode detection."""
    print("\n=== Example: Automatic Security Mode Detection ===")

    test_cases = [
        ("http://localhost", None, None, None, None, "HTTP"),
        ("http://localhost", "api_key", None, None, None, "HTTP + Token"),
        ("https://localhost", None, None, None, None, "HTTPS"),
        ("https://localhost", "api_key", None, None, None, "HTTPS + Token"),
        ("https://localhost", None, None, "cert.pem", "key.pem", "mTLS"),
        (
            "https://localhost",
            None,
            None,
            "cert.pem",
            "key.pem",
            "mTLS + Roles",
            {"roles": ["admin"]},
        ),
    ]

    for case in test_cases:
        if len(case) == 6:
            base_url, auth_method, ssl_enabled, cert_file, key_file, expected = case
            kwargs = {}
        else:
            (
                base_url,
                auth_method,
                ssl_enabled,
                cert_file,
                key_file,
                expected,
                kwargs,
            ) = case

        try:
            mode = detect_security_mode(
                base_url, auth_method, ssl_enabled, cert_file, key_file, **kwargs
            )
            print(
                f"  {base_url} + {auth_method or 'none'} + {cert_file or 'no cert'} -> {mode} ({expected})"
            )
        except Exception as e:
            print(f"  Error detecting mode for {base_url}: {e}")


async def example_configuration_files():
    """Example: Using configuration files."""
    print("\n=== Example: Using Configuration Files ===")

    # Create sample configuration files
    configs = {
        "http_simple.json": {
            "server": {"host": "http://localhost", "port": 8001},
            "auth": {"method": "none"},
            "ssl": {"enabled": False},
        },
        "https_token.json": {
            "server": {"host": "https://localhost", "port": 8443},
            "auth": {"method": "api_key", "api_keys": {"user": "your_api_key"}},
            "ssl": {
                "enabled": True,
                "verify_mode": "CERT_REQUIRED",
                "check_hostname": True,
            },
        },
        "mtls_roles.json": {
            "server": {"host": "https://localhost", "port": 8443},
            "auth": {
                "method": "certificate",
                "certificate": {
                    "cert_file": "mtls_certificates/client/embedding-service.crt",
                    "key_file": "mtls_certificates/client/embedding-service.key",
                    "ca_cert_file": "mtls_certificates/ca/ca.crt",
                },
            },
            "ssl": {
                "enabled": True,
                "verify_mode": "CERT_REQUIRED",
                "check_hostname": True,
                "cert_file": "mtls_certificates/client/embedding-service.crt",
                "key_file": "mtls_certificates/client/embedding-service.key",
                "ca_cert_file": "mtls_certificates/ca/ca.crt",
            },
            "roles": ["admin", "user"],
            "role_attributes": {"department": "IT"},
        },
    }

    # Create config directory if it doesn't exist
    os.makedirs("examples/configs", exist_ok=True)

    # Save configuration files
    for filename, config in configs.items():
        filepath = f"examples/configs/{filename}"
        with open(filepath, "w") as f:
            json.dump(config, f, indent=2)
        print(f"Created: {filepath}")

    # Example: Load configuration from file
    try:
        config = ClientConfig()
        config.load_config_file("examples/configs/http_simple.json")

        async with EmbeddingClient.from_config(config) as client:
            print(f"Loaded from file: {_client_label(client)}")
            print(f"Auth method: {'api_key' if client._token else 'none'}")
    except Exception as e:
        print(f"Error loading config file: {e}")


async def example_environment_variables():
    """Example: Using environment variables."""
    print("\n=== Example: Using Environment Variables ===")

    # Set environment variables (in real usage, these would be set externally)
    env_vars = {
        "EMBED_CLIENT_BASE_URL": "http://localhost",
        "EMBED_CLIENT_PORT": "8001",
        "EMBED_CLIENT_AUTH_METHOD": "api_key",
        "EMBED_CLIENT_API_KEY": "your_api_key",
    }

    # Set environment variables
    for key, value in env_vars.items():
        os.environ[key] = value
        print(f"Set {key}={value}")

    # Create client from environment variables
    try:
        client = create_client_from_env()
        print(f"Client from env: {_client_label(client)}")
        print(f"Auth method: {'api_key' if client._token else 'none'}")
        await client.close()
    except Exception as e:
        print(f"Error creating client from env: {e}")

    # Clean up environment variables
    for key in env_vars.keys():
        if key in os.environ:
            del os.environ[key]


async def example_embedding_generation(config_path: Optional[str] = None):
    """Example: Generate embeddings with different security modes."""
    print("\n=== Example: Generate Embeddings with Different Security Modes ===")

    texts = [
        "Hello, world!",
        "This is a test sentence.",
        "Embedding service is working!",
    ]

    if config_path:
        async with EmbeddingClient.from_config_file(config_path) as client:
            result = await client.cmd("embed", {"texts": texts})
            if result.get("success"):
                print(
                    f"Config mode: Generated {len(result.get('result', {}).get('data', []))} embeddings"
                )
            else:
                print(f"Config mode: Failed - {result.get('error')}")
        return

    # HTTP mode
    try:
        async with EmbeddingClient.from_base_url_port(
            "http://localhost", 8001
        ) as client:
            result = await client.cmd("embed", {"texts": texts})
            if result.get("success"):
                print(
                    f"HTTP mode: Generated {len(result.get('result', {}).get('data', []))} embeddings"
                )
            else:
                print(f"HTTP mode: Failed - {result.get('error')}")
    except Exception as e:
        print(f"HTTP mode error: {e}")

    # API Key mode
    try:
        async with EmbeddingClient.with_auth(
            "http://localhost", 8001, "api_key", api_key="your_api_key"
        ) as client:
            result = await client.cmd("embed", {"texts": texts})
            if result.get("success"):
                print(
                    f"API Key mode: Generated {len(result.get('result', {}).get('data', []))} embeddings"
                )
            else:
                print(f"API Key mode: Failed - {result.get('error')}")
    except Exception as e:
        print(f"API Key mode error: {e}")


def parse_args():
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(
        description="Run embed-client security examples. "
        "Use --config to run live server examples with a given config (e.g. mTLS on 8001)."
    )
    parser.add_argument(
        "--config",
        type=str,
        default=None,
        help="Config file path; when set, examples 1-6 and embedding generation use this config",
    )
    return parser.parse_args()


async def main():
    """Run all examples."""
    args = parse_args()
    config_path: Optional[str] = getattr(args, "config", None)

    print("🚀 embed-client Security Examples")
    print("=" * 50)
    if config_path:
        print(f"Using config for live examples: {config_path}")
        print()

    try:
        await example_1_http_plain(config_path)
        await example_2_http_token(config_path)
        await example_3_https_plain(config_path)
        await example_4_https_token(config_path)
        await example_5_mtls(config_path)
        await example_6_mtls_roles(config_path)
        await example_automatic_detection()
        await example_configuration_files()
        await example_environment_variables()
        await example_embedding_generation(config_path)

        print("\n✅ All examples completed successfully!")

    except Exception as e:
        print(f"\n❌ Error running examples: {e}")
        import traceback

        traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(main())
