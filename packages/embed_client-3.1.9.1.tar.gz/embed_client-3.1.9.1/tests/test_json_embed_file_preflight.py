"""
Tests for json_array local file preflight validation.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

import json

import pytest

from embed_client.exceptions import EmbedClientError
from embed_client.json_embed_file_preflight import (
    validate_local_json_embed_file,
)


def test_validate_ok(tmp_path, monkeypatch):
    monkeypatch.delenv("EMBED_CLIENT_MAX_JSON_BLOCK_BYTES", raising=False)
    p = tmp_path / "b.json"
    p.write_text(json.dumps(["hello"]), encoding="utf-8")
    validate_local_json_embed_file(str(p))


def test_validate_block_too_large(tmp_path, monkeypatch):
    monkeypatch.delenv("EMBED_CLIENT_MAX_JSON_BLOCK_BYTES", raising=False)
    p = tmp_path / "b.json"
    p.write_text(json.dumps(["x" * 20]), encoding="utf-8")
    with pytest.raises(EmbedClientError, match="exceeds max block"):
        validate_local_json_embed_file(str(p), max_block_bytes=10)


def test_validate_not_array_root(tmp_path):
    p = tmp_path / "b.json"
    p.write_text('{"text": "nope"}', encoding="utf-8")
    with pytest.raises(EmbedClientError, match="must be a JSON array at root"):
        validate_local_json_embed_file(str(p))


def test_validate_invalid_json(tmp_path):
    p = tmp_path / "b.json"
    p.write_text("[{", encoding="utf-8")
    with pytest.raises(EmbedClientError, match="invalid JSON"):
        validate_local_json_embed_file(str(p))


def test_validate_item_not_string(tmp_path):
    p = tmp_path / "b.json"
    p.write_text("[{}]", encoding="utf-8")
    with pytest.raises(EmbedClientError, match="must be a string"):
        validate_local_json_embed_file(str(p))


def test_env_max_override(tmp_path, monkeypatch):
    p = tmp_path / "b.json"
    p.write_text(json.dumps(["abcd"]), encoding="utf-8")
    monkeypatch.setenv("EMBED_CLIENT_MAX_JSON_BLOCK_BYTES", "3")
    with pytest.raises(EmbedClientError, match="exceeds max block"):
        validate_local_json_embed_file(str(p))
    monkeypatch.setenv("EMBED_CLIENT_MAX_JSON_BLOCK_BYTES", "4")
    validate_local_json_embed_file(str(p))
