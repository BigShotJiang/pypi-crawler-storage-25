"""
Tests for immediate JSON-RPC embed result (no queue job_id).

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import pytest
from unittest.mock import AsyncMock, patch

from embed_client.embedding_client import EmbeddingClient


@pytest.mark.asyncio
async def test_embed_wait_false_immediate_payload() -> None:
    """When server returns full data without job_id, embed returns business payload."""
    client = EmbeddingClient(protocol="http", host="localhost", port=8001)

    async def fake_jsonrpc(method: str, params: dict) -> dict:
        assert method == "embed"
        return {
            "result": {
                "success": True,
                "data": {
                    "results": [{"body": "t", "embedding": [0.1, 0.2]}],
                    "embeddings": [[0.1, 0.2]],
                    "model": "m",
                },
            }
        }

    with patch.object(
        client.client,
        "jsonrpc_call",
        new=AsyncMock(side_effect=fake_jsonrpc),
    ):
        out = await client.embed(["t"], wait=False)

    assert "job_id" not in out
    assert "results" in out


@pytest.mark.asyncio
async def test_embed_wait_false_queued_job_id() -> None:
    """When server returns job_id without full results, embed returns queue metadata."""
    client = EmbeddingClient(protocol="http", host="localhost", port=8001)

    async def fake_jsonrpc(method: str, params: dict) -> dict:
        assert method == "embed"
        return {
            "result": {
                "success": True,
                "data": {
                    "job_id": "job-123",
                    "status": "pending",
                    "message": "accepted",
                },
            }
        }

    with patch.object(
        client.client,
        "jsonrpc_call",
        new=AsyncMock(side_effect=fake_jsonrpc),
    ):
        out = await client.embed(["t"], wait=False)

    assert out["job_id"] == "job-123"
    assert out["status"] == "pending"
