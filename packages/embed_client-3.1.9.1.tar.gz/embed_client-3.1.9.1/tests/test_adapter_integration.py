"""
Integration tests for EmbeddingClient with JsonRpcClient.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import pytest
from mcp_proxy_adapter.client.jsonrpc_client import JsonRpcClient

from embed_client.client_factory import ClientFactory
from embed_client.embedding_client import EmbeddingClient


class TestAdapterIntegration:
    """Integration tests for JsonRpcClient-backed client."""

    def test_factory_creates_client_with_jsonrpc(self):
        client = ClientFactory.create_client(base_url="http://localhost", port=8001)

        assert client.client is not None
        assert isinstance(client.client, JsonRpcClient)

    def test_client_from_config_uses_jsonrpc(self):
        config_dict = {
            "server": {"host": "http://localhost", "port": 8001},
            "client": {"timeout": 30.0},
        }

        client = EmbeddingClient.from_config_dict(config_dict)

        assert client.client is not None
        assert isinstance(client.client, JsonRpcClient)

    def test_all_security_modes_create_jsonrpc(self):
        security_modes = [
            ("http", "http://localhost", 8001, False, None, None),
            ("https", "https://localhost", 8443, True, None, None),
            (
                "mtls",
                "https://localhost",
                8443,
                True,
                "/path/to/cert.crt",
                "/path/to/key.key",
            ),
        ]

        for _mode, base_url, port, ssl, cert, key in security_modes:
            client = ClientFactory.create_client(
                base_url=base_url,
                port=port,
                ssl_enabled=ssl,
                cert_file=cert,
                key_file=key,
            )

            assert client.client is not None
            assert isinstance(client.client, JsonRpcClient)

    @pytest.mark.asyncio
    async def test_context_manager(self):
        client = EmbeddingClient.from_config_dict(
            {
                "server": {"host": "http://localhost", "port": 8001},
                "client": {"timeout": 30.0},
            }
        )

        async with client:
            assert client.client is not None
            assert isinstance(client.client, JsonRpcClient)
