"""
Execution-based checks for ``examples/canonical_mtls_localhost_8001.py``.

Dry run exercises config resolution and imports; optional live mTLS requires
``RUN_CANONICAL_MTLS_E2E=1`` and a server on localhost:8001.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

_ROOT = Path(__file__).resolve().parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))


def test_canonical_mtls_config_paths_exist():
    from examples.canonical_mtls_localhost_8001 import (
        build_mtls_localhost_8001_config,
    )

    cfg = build_mtls_localhost_8001_config(_ROOT)
    assert cfg["protocol"] == "mtls"
    assert cfg["server"]["port"] == 8001
    for key in ("cert_file", "key_file", "ca_cert_file"):
        p = cfg["ssl"][key]
        assert Path(p).is_file(), f"missing {key}: {p}"


@pytest.mark.asyncio
async def test_canonical_mtls_main_dry_run_no_network(monkeypatch):
    monkeypatch.delenv("RUN_CANONICAL_MTLS_E2E", raising=False)
    from examples import canonical_mtls_localhost_8001 as mod

    await mod.main()


@pytest.mark.asyncio
async def test_canonical_mtls_live_smoke_mocked(monkeypatch):
    """Live branch without a real server: mocked client completes the capability chain."""

    monkeypatch.setenv("RUN_CANONICAL_MTLS_E2E", "1")

    async def fake_run_live(_client):
        return ["step_ok"]

    mock_cm = AsyncMock()
    mock_cm.__aenter__.return_value = mock_cm
    mock_cm.__aexit__.return_value = None

    with patch(
        "examples.canonical_mtls_localhost_8001.EmbeddingClient.from_config_dict",
        return_value=mock_cm,
    ), patch(
        "examples.canonical_mtls_localhost_8001.run_live_capabilities",
        new=fake_run_live,
    ):
        from examples import canonical_mtls_localhost_8001 as mod

        await mod.main()


@pytest.mark.asyncio
async def test_canonical_mtls_embed_file_env_skip_message(monkeypatch):
    """Unset CANONICAL_EMBED_FILE_SERVER_PATH appends the documented skip line."""
    monkeypatch.delenv("CANONICAL_EMBED_FILE_SERVER_PATH", raising=False)
    from examples.canonical_mtls_localhost_8001 import run_live_capabilities

    c = MagicMock()
    c.health = AsyncMock(return_value={"ok": True})
    c.models = AsyncMock(return_value={})
    c.list_commands = AsyncMock(return_value={})
    c.cmd = AsyncMock(return_value={})
    c.embed = AsyncMock(side_effect=[{"results": []}, {}])
    c.job_status = AsyncMock(return_value={})
    c.wait_for_job = AsyncMock(return_value={})
    c.list_queued_commands = AsyncMock(return_value={})
    c.timing_stats = AsyncMock(return_value={})
    c.fetch_openapi_schema = AsyncMock(return_value={})
    c.http_get = AsyncMock(return_value=(200, ""))
    c.jsonrpc = AsyncMock(return_value={})

    lines = await run_live_capabilities(c)
    joined = "\n".join(lines)
    assert "embed_file skipped" in joined
    assert "server-visible path" in joined


@pytest.mark.asyncio
async def test_canonical_mtls_embed_file_env_calls_embed_file(monkeypatch):
    monkeypatch.setenv(
        "CANONICAL_EMBED_FILE_SERVER_PATH", "/tmp/canonical_embed_test.txt"
    )
    from examples.canonical_mtls_localhost_8001 import run_live_capabilities

    c = MagicMock()
    c.health = AsyncMock(return_value={"ok": True})
    c.models = AsyncMock(return_value={})
    c.list_commands = AsyncMock(return_value={})
    c.cmd = AsyncMock(return_value={})
    c.embed = AsyncMock(side_effect=[{"results": []}, {}])
    c.job_status = AsyncMock(return_value={})
    c.wait_for_job = AsyncMock(return_value={})
    c.list_queued_commands = AsyncMock(return_value={})
    c.timing_stats = AsyncMock(return_value={})
    c.fetch_openapi_schema = AsyncMock(return_value={})
    c.http_get = AsyncMock(return_value=(200, ""))
    c.jsonrpc = AsyncMock(return_value={})
    c.embed_file = AsyncMock(return_value={"status": "ok"})

    lines = await run_live_capabilities(c)
    c.embed_file.assert_awaited_once()
    call_kw = c.embed_file.await_args
    assert call_kw[0][0] == "/tmp/canonical_embed_test.txt"
    assert call_kw[1]["wait"] is True
    assert call_kw[1]["wait_timeout"] == 600
    assert call_kw[1]["error_policy"] == "continue"
    assert any("embed_file:" in ln for ln in lines)


@pytest.mark.integration
@pytest.mark.asyncio
async def test_canonical_mtls_real_server_optional():
    """Real localhost:8001 mTLS; skipped unless RUN_CANONICAL_MTLS_E2E=1 in env."""

    if os.environ.get("RUN_CANONICAL_MTLS_E2E") != "1":
        pytest.skip(
            "Set RUN_CANONICAL_MTLS_E2E=1 and start the service on :8001 (mTLS)."
        )

    from examples.canonical_mtls_localhost_8001 import (
        build_mtls_localhost_8001_config,
        run_live_capabilities,
    )
    from embed_client.embedding_client import EmbeddingClient

    cfg = build_mtls_localhost_8001_config(_ROOT)
    async with EmbeddingClient.from_config_dict(cfg) as client:
        lines = await run_live_capabilities(client)
    assert len(lines) >= 5
