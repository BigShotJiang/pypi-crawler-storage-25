"""
Adapter-centric tests for EmbeddingClient (JsonRpcClient via mcp-proxy-adapter).

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from unittest.mock import patch

from mcp_proxy_adapter.client.jsonrpc_client import JsonRpcClient

from embed_client.embedding_client import EmbeddingClient


class TestEmbeddingClientAdapter:
    """Tests for EmbeddingClient built on JsonRpcClient."""

    def test_client_init_uses_jsonrpc(self):
        config_dict = {
            "server": {"host": "localhost", "port": 8001},
            "auth": {"method": "none"},
            "ssl": {"enabled": False},
        }
        client = EmbeddingClient.from_config_dict(config_dict)

        assert hasattr(client, "client")
        assert isinstance(client.client, JsonRpcClient)

    def test_client_init_uses_adapter_config_factory(self):
        config_dict = {
            "server": {"host": "localhost", "port": 8001},
            "auth": {"method": "none"},
            "ssl": {"enabled": False},
        }
        from embed_client.adapter_config_factory import AdapterConfigFactory

        with patch.object(
            AdapterConfigFactory,
            "from_config_dict",
            wraps=AdapterConfigFactory.from_config_dict,
        ) as mock_factory:
            client = EmbeddingClient.from_config_dict(config_dict)

            assert mock_factory.called
            assert hasattr(client, "client")
            assert isinstance(client.client, JsonRpcClient)

    def test_client_no_legacy_transport(self):
        client = EmbeddingClient.from_config_dict(
            {"server": {"host": "localhost", "port": 8001}}
        )

        assert not hasattr(client, "_session")
        assert not hasattr(client, "_aiohttp_session")
        assert hasattr(client, "client")

    def test_client_config_to_connection_params(self):
        config_dict = {
            "server": {"host": "http://localhost", "port": 8001},
            "auth": {"method": "api_key", "api_keys": {"user": "key123"}},
            "ssl": {"enabled": False},
        }
        client = EmbeddingClient.from_config_dict(config_dict)

        assert client.protocol == "http"
        assert client.host == "localhost"
        assert client.port == 8001
        assert client._token == "key123"

    def test_client_init_without_auth_manager(self):
        config_dict = {"server": {"host": "localhost", "port": 8001}}
        client = EmbeddingClient.from_config_dict(config_dict)

        assert client is not None
        assert isinstance(client.client, JsonRpcClient)

    def test_client_carries_token_for_auth(self):
        config_dict = {
            "server": {"host": "localhost", "port": 8001},
            "auth": {"method": "api_key", "api_keys": {"user": "key123"}},
        }
        client = EmbeddingClient.from_config_dict(config_dict)

        assert client._token == "key123"
