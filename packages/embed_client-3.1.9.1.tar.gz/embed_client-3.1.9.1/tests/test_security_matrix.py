"""
Comprehensive Security Matrix Validation Tests

Tests all 8 required security modes using adapter-backed client:
- http (no auth)
- http + token
- http + token + roles
- https (no auth)
- https + token
- https + token + roles
- mtls (no auth)
- mtls + roles

All tests validate adapter-backed transport usage (no custom auth/transport logic).

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import os
from pathlib import Path
from typing import Any, Dict

import pytest
from mcp_proxy_adapter.client.jsonrpc_client import JsonRpcClient

from embed_client.embedding_client import EmbeddingClient
from embed_client.exceptions import (
    EmbedConfigError,
    ModelServerUnavailableError,
)

_REPO_ROOT = Path(__file__).resolve().parent.parent


def _repo(*parts: str) -> str:
    return str(_REPO_ROOT.joinpath(*parts))


# Live server + certs required; run: RUN_SECURITY_MATRIX=1 pytest tests/test_security_matrix.py
pytestmark = pytest.mark.skipif(
    os.environ.get("RUN_SECURITY_MATRIX") != "1",
    reason="Set RUN_SECURITY_MATRIX=1 and start the embedding service (see scripts/run_*).",
)


def create_test_config(
    mode: str, host: str = "localhost", port: int = 8000, **overrides: Any
) -> Dict[str, Any]:
    """
    Create test configuration dictionary for a specific security mode.

    Args:
        mode: Security mode name. Must be one of: "http", "http_token",
            "http_token_roles", "https", "https_token", "https_token_roles",
            "mtls", "mtls_roles"
        host: Server host (default: "localhost")
        port: Server port (default: 8000)
        **overrides: Optional config overrides to merge into the base config

    Returns:
        Configuration dictionary compatible with EmbeddingClient.from_config()
        or EmbeddingClient(config_dict=...)

    Raises:
        ValueError: If mode is not recognized
    """
    config: Dict[str, Any] = {}
    server_config: Dict[str, Any] = {"host": host, "port": port}
    auth_config: Dict[str, Any] = {}
    ssl_config: Dict[str, Any] = {}
    security_config: Dict[str, Any] = {}

    if mode == "http":
        server_config["protocol"] = "http"
        ssl_config["enabled"] = False
        auth_config["method"] = "none"
        security_config["enabled"] = False
    elif mode == "http_token":
        server_config["protocol"] = "http"
        ssl_config["enabled"] = False
        auth_config["method"] = "api_key"
        security_config["enabled"] = True
        security_config["tokens"] = {
            "admin": "admin-secret-key",
            "user": "user-secret-key",
        }
    elif mode == "http_token_roles":
        server_config["protocol"] = "http"
        ssl_config["enabled"] = False
        auth_config["method"] = "api_key"
        security_config["enabled"] = True
        security_config["tokens"] = {
            "admin": "admin-secret-key",
            "user": "user-secret-key",
            "readonly": "readonly-secret-key",
        }
        security_config["roles"] = {
            "admin": ["read", "write", "delete", "admin"],
            "user": ["read", "write"],
            "readonly": ["read"],
        }
    elif mode == "https":
        server_config["protocol"] = "https"
        ssl_config["enabled"] = True
        ssl_config["verify_mode"] = "CERT_NONE"
        ssl_config["check_hostname"] = False
        ssl_config["cert_file"] = overrides.get(
            "cert_file",
            _repo("mtls_certificates", "server", "embedding-service.crt"),
        )
        ssl_config["key_file"] = overrides.get(
            "key_file",
            _repo("mtls_certificates", "server", "embedding-service.key"),
        )
        auth_config["method"] = "none"
        security_config["enabled"] = False
    elif mode == "https_token":
        server_config["protocol"] = "https"
        ssl_config["enabled"] = True
        ssl_config["verify_mode"] = "CERT_NONE"
        ssl_config["check_hostname"] = False
        ssl_config["cert_file"] = overrides.get(
            "cert_file",
            _repo("mtls_certificates", "server", "embedding-service.crt"),
        )
        ssl_config["key_file"] = overrides.get(
            "key_file",
            _repo("mtls_certificates", "server", "embedding-service.key"),
        )
        auth_config["method"] = "api_key"
        security_config["enabled"] = True
        security_config["tokens"] = {
            "admin": "admin-secret-key",
            "user": "user-secret-key",
        }
    elif mode == "https_token_roles":
        server_config["protocol"] = "https"
        ssl_config["enabled"] = True
        ssl_config["verify_mode"] = "CERT_NONE"
        ssl_config["check_hostname"] = False
        ssl_config["cert_file"] = overrides.get(
            "cert_file",
            _repo("mtls_certificates", "server", "embedding-service.crt"),
        )
        ssl_config["key_file"] = overrides.get(
            "key_file",
            _repo("mtls_certificates", "server", "embedding-service.key"),
        )
        auth_config["method"] = "api_key"
        security_config["enabled"] = True
        security_config["tokens"] = {
            "admin": "admin-secret-key",
            "user": "user-secret-key",
            "readonly": "readonly-secret-key",
        }
        security_config["roles"] = {
            "admin": ["read", "write", "delete", "admin"],
            "user": ["read", "write"],
            "readonly": ["read"],
        }
    elif mode == "mtls":
        server_config["protocol"] = "mtls"
        ssl_config["enabled"] = True
        ssl_config["verify_mode"] = "CERT_REQUIRED"
        ssl_config["check_hostname"] = True
        ssl_config["cert_file"] = overrides.get(
            "cert_file",
            _repo("mtls_certificates", "client", "embedding-service.crt"),
        )
        ssl_config["key_file"] = overrides.get(
            "key_file",
            _repo("mtls_certificates", "client", "embedding-service.key"),
        )
        ssl_config["ca_cert_file"] = overrides.get(
            "ca_cert_file",
            _repo("mtls_certificates", "ca", "ca.crt"),
        )
        auth_config["method"] = "certificate"
        security_config["enabled"] = False
    elif mode == "mtls_roles":
        server_config["protocol"] = "mtls"
        ssl_config["enabled"] = True
        ssl_config["verify_mode"] = "CERT_REQUIRED"
        ssl_config["check_hostname"] = True
        ssl_config["cert_file"] = overrides.get(
            "cert_file",
            _repo("mtls_certificates", "client", "embedding-service.crt"),
        )
        ssl_config["key_file"] = overrides.get(
            "key_file",
            _repo("mtls_certificates", "client", "embedding-service.key"),
        )
        ssl_config["ca_cert_file"] = overrides.get(
            "ca_cert_file",
            _repo("mtls_certificates", "ca", "ca.crt"),
        )
        auth_config["method"] = "certificate"
        security_config["enabled"] = True
        security_config["roles"] = {
            "admin": ["read", "write", "delete", "admin"],
            "user": ["read", "write"],
            "readonly": ["read"],
        }
    else:
        raise ValueError(
            f"Unknown security mode: {mode}. Must be one of: "
            "http, http_token, http_token_roles, https, https_token, "
            "https_token_roles, mtls, mtls_roles"
        )

    config["server"] = server_config
    config["auth"] = auth_config
    config["ssl"] = ssl_config
    config["security"] = security_config

    # Deep merge overrides into config
    if overrides:
        for key, value in overrides.items():
            if (
                key in config
                and isinstance(config[key], dict)
                and isinstance(value, dict)
            ):
                # Recursive merge for nested dicts
                for nested_key, nested_value in value.items():
                    config[key][nested_key] = nested_value
            else:
                # Replace non-dict values or top-level keys
                config[key] = value

    return config


class TestSecurityMatrix:
    """Test suite for security matrix validation across all 8 required modes."""

    @pytest.mark.asyncio
    async def test_http_mode(self):
        """
        Test HTTP mode (no authentication).

        Validates:
        - Client construction succeeds
        - Command execution succeeds (embed, models)
        - Adapter-backed transport is used
        """
        config = create_test_config("http", host="localhost", port=8000)
        await self._test_security_mode("http", config)

    @pytest.mark.asyncio
    async def test_http_token_mode(self):
        """
        Test HTTP + token mode.

        Validates:
        - Client construction succeeds with token config
        - Command execution succeeds with token auth
        - Adapter-backed transport is used
        """
        config = create_test_config("http_token", host="localhost", port=8000)
        await self._test_security_mode("http_token", config)

    @pytest.mark.asyncio
    async def test_http_token_roles_mode(self):
        """
        Test HTTP + token + roles mode.

        Validates:
        - Client construction succeeds with token and roles config
        - Command execution succeeds with role-based auth
        - Adapter-backed transport is used
        """
        config = create_test_config("http_token_roles", host="localhost", port=8000)
        await self._test_security_mode("http_token_roles", config)

    @pytest.mark.asyncio
    async def test_https_mode(self):
        """
        Test HTTPS mode (no authentication).

        Validates:
        - Client construction succeeds with SSL config
        - Command execution succeeds over HTTPS
        - Adapter-backed transport is used
        """
        config = create_test_config("https", host="localhost", port=8000)
        await self._test_security_mode("https", config)

    @pytest.mark.asyncio
    async def test_https_token_mode(self):
        """
        Test HTTPS + token mode.

        Validates:
        - Client construction succeeds with SSL and token config
        - Command execution succeeds over HTTPS with token auth
        - Adapter-backed transport is used
        """
        config = create_test_config("https_token", host="localhost", port=8000)
        await self._test_security_mode("https_token", config)

    @pytest.mark.asyncio
    async def test_https_token_roles_mode(self):
        """
        Test HTTPS + token + roles mode.

        Validates:
        - Client construction succeeds with SSL, token, and roles config
        - Command execution succeeds over HTTPS with role-based auth
        - Adapter-backed transport is used
        """
        config = create_test_config("https_token_roles", host="localhost", port=8000)
        await self._test_security_mode("https_token_roles", config)

    @pytest.mark.asyncio
    async def test_mtls_mode(self):
        """
        Test mTLS mode (no roles).

        Validates:
        - Client construction succeeds with client certificates
        - Command execution succeeds over mTLS
        - Adapter-backed transport is used
        """
        config = create_test_config("mtls", host="localhost", port=8000)
        await self._test_security_mode("mtls", config)

    @pytest.mark.asyncio
    async def test_mtls_roles_mode(self):
        """
        Test mTLS + roles mode.

        Validates:
        - Client construction succeeds with client certificates and roles
        - Command execution succeeds over mTLS with role-based access
        - Adapter-backed transport is used
        """
        config = create_test_config("mtls_roles", host="localhost", port=8000)
        await self._test_security_mode("mtls_roles", config)

    async def _test_security_mode(self, mode_name: str, config: Dict[str, Any]) -> None:
        """
        Helper method to test a security mode.

        Args:
            mode_name: Name of the security mode (for logging/error messages)
            config: Configuration dictionary for the security mode

        Validates:
        - Client construction succeeds
        - embed() command executes successfully
        - models() command executes successfully
        - Result structure is valid
        - Adapter-backed transport is used (no custom auth/transport)

        Raises:
            AssertionError: If any validation fails
            EmbedConfigError: If config is invalid
            ModelServerUnavailableError: If connection fails
            EmbedAPIError: If API call fails
        """
        # Client Construction
        async with EmbeddingClient.from_config_dict(config) as client:
            assert hasattr(
                client, "client"
            ), f"Client must expose JsonRpcClient for {mode_name}"
            assert isinstance(
                client.client, JsonRpcClient
            ), f"Expected JsonRpcClient for {mode_name}"

            # Test embed() Command (Immediate Mode)
            result = await client.embed(texts=["test text 1", "test text 2"])
            assert (
                result is not None
            ), f"embed() result must not be None for {mode_name} mode"
            assert isinstance(
                result, dict
            ), f"embed() result must be a dict for {mode_name} mode"
            assert (
                "result" in result or "embeddings" in result or "results" in result
            ), (
                f"embed() result must contain 'result', 'embeddings', or 'results' "
                f"for {mode_name} mode. Got: {list(result.keys())}"
            )

            # Test embed() Command (Queued Mode - if supported)
            queued_result = await client.embed(texts=["test text 3"], wait=False)
            if "job_id" in queued_result:
                assert isinstance(
                    queued_result.get("job_id"), str
                ), f"job_id must be a string for {mode_name} mode"
                assert (
                    len(queued_result["job_id"]) > 0
                ), f"job_id must not be empty for {mode_name} mode"
                status_result = await client.job_status(queued_result["job_id"])
                assert (
                    status_result is not None
                ), f"job_status() result must not be None for {mode_name} mode"
                assert isinstance(
                    status_result, dict
                ), f"job_status() result must be a dict for {mode_name} mode"

            # Test models() Command
            models_result = await client.models()
            assert (
                models_result is not None
            ), f"models() result must not be None for {mode_name} mode"
            assert isinstance(
                models_result, dict
            ), f"models() result must be a dict for {mode_name} mode"

            # Test Error Handling (Invalid Config)
            invalid_config = config.copy()
            invalid_config["server"] = config["server"].copy()
            invalid_config["server"]["port"] = -1

            with pytest.raises((EmbedConfigError, ModelServerUnavailableError)):
                async with EmbeddingClient.from_config_dict(invalid_config):
                    # Should not reach here - exception should be raised
                    pass
