"""
Tests for embed_file downloaded JSON validation helpers.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from embed_client.exceptions import EmbedClientError
from embed_client.embed_file_output_validate import (
    load_embed_file_output_json_file,
    parse_embed_file_output_records,
    resolve_embed_file_output_payload,
    validate_embed_file_job_result,
    validate_embed_file_output_against_blocks,
)


def _canonical_payload(n: int = 2, dim: int = 4) -> dict:
    texts = [f"block{i}" for i in range(n)]
    results = []
    for i, t in enumerate(texts):
        results.append(
            {
                "body": t,
                "embedding": [float(i * dim + j) for j in range(dim)],
                "tokens": [],
                "bm25_tokens": [],
            }
        )
    return {
        "success": True,
        "data": {
            "model": "m",
            "dimension": dim,
            "results": results,
        },
    }


def test_parse_canonical_records():
    pl = _canonical_payload()
    rows, dim, hint = parse_embed_file_output_records(pl)
    assert hint == "data.results"
    assert dim == 4
    assert len(rows) == 2


def test_parse_top_level_results_only():
    pl = _canonical_payload()
    inner = pl["data"]
    rows, dim, hint = parse_embed_file_output_records(inner)
    assert hint == "results"
    assert dim == 4
    assert len(rows) == 2


def test_validate_ok():
    pl = _canonical_payload()
    inp = ["block0", "block1"]
    r = validate_embed_file_output_against_blocks(inp, pl, rpc_dimension=4)
    assert r.ok
    assert not r.errors


def test_validate_count_mismatch():
    pl = _canonical_payload(n=1)
    inp = ["block0", "block1"]
    r = validate_embed_file_output_against_blocks(inp, pl, rpc_dimension=4)
    assert not r.ok
    assert any("count mismatch" in e for e in r.errors)


def test_validate_dimension_mismatch():
    pl = _canonical_payload()
    r = validate_embed_file_output_against_blocks(
        ["block0", "block1"], pl, rpc_dimension=99
    )
    assert not r.ok
    assert any("embedding length" in e for e in r.errors)


def test_validate_body_order_mismatch():
    pl = _canonical_payload()
    pl["data"]["results"][0]["body"] = "wrong"
    r = validate_embed_file_output_against_blocks(
        ["block0", "block1"], pl, rpc_dimension=4
    )
    assert not r.ok
    assert any("does not match input" in e for e in r.errors)


def test_validate_success_false():
    pl = _canonical_payload()
    pl["success"] = False
    r = validate_embed_file_output_against_blocks(["block0", "block1"], pl)
    assert not r.ok


def test_load_from_file(tmp_path: Path):
    pl = _canonical_payload()
    p = tmp_path / "out.json"
    p.write_text(json.dumps(pl), encoding="utf-8")
    got = load_embed_file_output_json_file(str(p))
    assert got["success"] is True


def test_resolve_payload_from_local_output_path(tmp_path: Path):
    pl = _canonical_payload()
    p = tmp_path / "dl.json"
    p.write_text(json.dumps(pl), encoding="utf-8")
    er = {"local_output_path": str(p), "job_id": "x"}
    got, src = resolve_embed_file_output_payload(er)
    assert "local_output_path" in src
    rows, _, _ = parse_embed_file_output_records(got)
    assert len(rows) == 2


def test_resolve_missing_raises():
    with pytest.raises(EmbedClientError, match="cannot validate"):
        resolve_embed_file_output_payload({"job_id": "only"})


def test_validate_embed_file_job_result_inline_path(tmp_path: Path):
    pl = _canonical_payload()
    p = tmp_path / "o.json"
    p.write_text(json.dumps(pl), encoding="utf-8")
    er = {"local_output_path": str(p)}
    r = validate_embed_file_job_result(["block0", "block1"], er, rpc_dimension=4)
    assert r.ok


def test_per_row_error_instead_of_embedding():
    pl = _canonical_payload(n=1)
    pl["data"]["results"][0] = {
        "body": "block0",
        "embedding": None,
        "error": {"code": "x", "message": "fail"},
    }
    r = validate_embed_file_output_against_blocks(["block0"], pl, rpc_dimension=4)
    assert r.ok
