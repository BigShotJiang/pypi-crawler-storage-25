"""
Tests for Markdown → json_array preparation for embed_file.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

import json

import pytest

from embed_client.exceptions import EmbedClientError
from embed_client.md_embed_file_prep import (
    build_embed_file_json_array_from_markdown_text,
    prepare_markdown_path_to_json_file,
    split_body_into_text_blocks,
    strip_optional_yaml_front_matter,
)


def test_strip_front_matter_7d_style():
    raw = "---\n%%7d-00%%\n---\n\n# Title\n\nbody\n"
    body = strip_optional_yaml_front_matter(raw)
    assert body.strip().startswith("# Title")


def test_strip_no_op_without_opening_fence():
    raw = "no front\n---\n"
    assert strip_optional_yaml_front_matter(raw) == raw


def test_split_two_paragraphs():
    assert split_body_into_text_blocks("a\n\nb", max_block_bytes=100) == ["a", "b"]


def test_split_crlf_normalized():
    assert split_body_into_text_blocks("a\r\n\r\nb", max_block_bytes=100) == ["a", "b"]


def test_split_consecutive_blank_lines_collapse():
    assert split_body_into_text_blocks("a\n\n\n\nb", max_block_bytes=100) == ["a", "b"]


def test_paragraph_exceeds_max_block_bytes_raises():
    with pytest.raises(EmbedClientError, match="paragraph exceeds max_block_bytes"):
        split_body_into_text_blocks("abcd", max_block_bytes=2)


def test_single_codepoint_exceeds_max_block_bytes_raises():
    with pytest.raises(EmbedClientError, match="paragraph exceeds max_block_bytes"):
        split_body_into_text_blocks("€", max_block_bytes=2)


def test_build_from_md_with_max_chunks(tmp_path):
    text = "a\n\nb\n\nc\n\nd\n\ne"
    arr = build_embed_file_json_array_from_markdown_text(
        text, max_block_bytes=100, max_chunks=3
    )
    assert arr == ["a", "b", "c"]


def test_prepare_writes_valid_json(tmp_path, monkeypatch):
    monkeypatch.delenv("EMBED_CLIENT_MAX_JSON_BLOCK_BYTES", raising=False)
    md = tmp_path / "x.md"
    md.write_text("---\nx: 1\n---\n\nhello world\n", encoding="utf-8")
    out = tmp_path / "out.json"
    p = prepare_markdown_path_to_json_file(str(md), str(out), max_block_bytes=100)
    assert p == str(out.resolve())
    data = json.loads(out.read_text(encoding="utf-8"))
    assert isinstance(data, list) and len(data) >= 1
    assert isinstance(data[0], str) and data[0]


def test_empty_body_raises():
    with pytest.raises(EmbedClientError, match="no non-empty"):
        build_embed_file_json_array_from_markdown_text("", max_block_bytes=10)
