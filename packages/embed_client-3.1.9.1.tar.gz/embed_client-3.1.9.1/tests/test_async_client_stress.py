"""
Stress tests for EmbeddingClient.

These tests verify the client's behavior under heavy load with parallel processing
of large text batches.
"""

import pytest
import pytest_asyncio
import asyncio
import time
import random
from typing import Any, Dict, List

from embed_client.embedding_client import EmbeddingClient

BASE_URL = "http://localhost"
PORT = 8001

# Constants for retry logic
MAX_RETRIES = 3
RETRY_DELAY = 1.0  # seconds
MAX_CONCURRENT_TASKS = 100  # Limit concurrent tasks to prevent system overload


def generate_test_texts(count: int) -> List[str]:
    """Generate test texts with unique content."""
    return [f"Test text {i} for stress testing" for i in range(count)]


def validate_result_data(data: Any) -> None:
    """Validate result data format, supporting both old and new formats."""
    # Support both old and new formats
    if isinstance(data, dict) and "embeddings" in data:
        # Old format: data.embeddings
        assert isinstance(
            data["embeddings"], list
        ), f"'embeddings' is not a list: {data}"
    elif isinstance(data, list):
        # New format: data[].embedding
        for i, item in enumerate(data):
            assert isinstance(item, dict), f"Item {i} is not a dict: {item}"
            assert "body" in item, f"Item {i} missing 'body': {item}"
            assert "embedding" in item, f"Item {i} missing 'embedding': {item}"
            assert "chunks" in item, f"Item {i} missing 'chunks': {item}"
            assert isinstance(
                item["embedding"], list
            ), f"Item {i} embedding is not a list: {item}"
    else:
        raise AssertionError(f"Unexpected data format: {data}")


async def process_with_retry(
    client: EmbeddingClient,
    texts: List[str],
    max_retries: int = MAX_RETRIES,
    retry_delay: float = RETRY_DELAY,
) -> Dict[str, Any]:
    """
    Process texts with retry logic for handling runtime exceptions.

    Args:
        client: EmbeddingClient instance
        texts: List of texts to process
        max_retries: Maximum number of retry attempts
        retry_delay: Delay between retries in seconds

    Returns:
        Dict containing the result or error information
    """
    for attempt in range(max_retries):
        try:
            return await client.cmd("embed", params={"texts": texts})
        except Exception as e:
            if attempt == max_retries - 1:  # Last attempt
                return {
                    "error": f"Failed after {max_retries} attempts: {str(e)}",
                    "exception": str(e),
                    "attempts": attempt + 1,
                }
            await asyncio.sleep(retry_delay * (attempt + 1))  # Exponential backoff


async def process_batch(
    client: EmbeddingClient,
    texts: List[str],
    batch_size: int,
    max_concurrent: int = MAX_CONCURRENT_TASKS,
) -> List[Dict[str, Any]]:
    """
    Process a batch of texts in parallel with controlled concurrency.

    Args:
        client: EmbeddingClient instance
        texts: List of texts to process
        batch_size: Size of each batch
        max_concurrent: Maximum number of concurrent tasks

    Returns:
        List of results for each batch
    """
    semaphore = asyncio.Semaphore(max_concurrent)

    async def process_with_semaphore(batch: List[str]) -> Dict[str, Any]:
        async with semaphore:
            return await process_with_retry(client, batch)

    tasks = []
    for i in range(0, len(texts), batch_size):
        batch = texts[i : i + batch_size]
        task = asyncio.create_task(process_with_semaphore(batch))
        tasks.append(task)

    return await asyncio.gather(*tasks, return_exceptions=True)


@pytest_asyncio.fixture
async def stress_client():
    """Create a client instance for stress testing."""
    async with EmbeddingClient(base_url=BASE_URL, port=PORT) as client:
        yield client


@pytest.mark.asyncio
@pytest.mark.stress
async def test_parallel_processing(stress_client):
    """Test parallel processing of 10K texts."""
    total_texts = 10_000
    batch_size = 100  # Process 100 texts at a time
    texts = generate_test_texts(total_texts)

    start_time = time.time()
    results = await process_batch(stress_client, texts, batch_size)
    end_time = time.time()

    # Verify results
    success_count = 0
    error_count = 0
    exception_count = 0

    for result in results:
        if isinstance(result, Exception):
            exception_count += 1
            continue
        # Сначала assert на error/result
        assert ("error" in result) or (
            "result" in result
        ), f"Neither 'error' nor 'result' in response: {result}"
        if "error" in result:
            error_count += 1
            if "exception" in result:
                print(f"Error with exception: {result['error']}")
        elif "result" in result:
            res = result["result"]
            assert isinstance(res, dict), f"result is not a dict: {res}"
            if "success" in res and res["success"] is False:
                error_count += 1
                if "error" in res:
                    print(f"Error in result: {res['error']}")
            else:
                success_count += 1
                assert "data" in res, f"No 'data' in result: {res}"
                data = res["data"]
                assert isinstance(data, dict), f"data is not a dict: {data}"
                assert "embeddings" in data, f"No 'embeddings' in data: {data}"
                assert isinstance(
                    data["embeddings"], list
                ), f"'embeddings' is not a list: {data}"

    # Calculate statistics
    total_time = end_time - start_time
    texts_per_second = total_texts / total_time

    print("\nStress Test Results:")
    print(f"Total texts processed: {total_texts}")
    print(f"Successful batches: {success_count}")
    print(f"Failed batches: {error_count}")
    print(f"Exception batches: {exception_count}")
    print(f"Total time: {total_time:.2f} seconds")
    print(f"Processing speed: {texts_per_second:.2f} texts/second")

    # Assertions
    assert success_count > 0, "No successful batches processed"
    assert total_time > 0, "Invalid processing time"
    # Allow some errors and exceptions under stress
    assert (
        error_count + exception_count < total_texts * 0.1
    ), "Too many errors/exceptions"


@pytest.mark.asyncio
@pytest.mark.stress
async def test_concurrent_connections(stress_client):
    """Test multiple concurrent connections to the service."""
    total_connections = 50
    texts_per_connection = 200
    texts = generate_test_texts(texts_per_connection)

    async def single_connection() -> Dict[str, Any]:
        try:
            async with EmbeddingClient(base_url=BASE_URL, port=PORT) as client:
                return await process_with_retry(client, texts)
        except Exception as e:
            return {"error": f"Connection failed: {str(e)}", "exception": str(e)}

    start_time = time.time()
    tasks = [asyncio.create_task(single_connection()) for _ in range(total_connections)]
    results = await asyncio.gather(*tasks, return_exceptions=True)
    end_time = time.time()

    # Verify results
    success_count = 0
    error_count = 0
    exception_count = 0

    for result in results:
        if isinstance(result, Exception):
            exception_count += 1
            continue
        # Сначала assert на error/result
        assert ("error" in result) or (
            "result" in result
        ), f"Neither 'error' nor 'result' in response: {result}"
        if "error" in result:
            error_count += 1
            if "exception" in result:
                print(f"Error with exception: {result['error']}")
        elif "result" in result:
            res = result["result"]
            assert isinstance(res, dict), f"result is not a dict: {res}"
            if "success" in res and res["success"] is False:
                error_count += 1
                if "error" in res:
                    print(f"Error in result: {res['error']}")
            else:
                success_count += 1
                assert "data" in res, f"No 'data' in result: {res}"
                data = res["data"]
                assert isinstance(data, dict), f"data is not a dict: {data}"
                assert "embeddings" in data, f"No 'embeddings' in data: {data}"
                assert isinstance(
                    data["embeddings"], list
                ), f"'embeddings' is not a list: {data}"

    # Calculate statistics
    total_time = end_time - start_time
    total_texts = total_connections * texts_per_connection
    texts_per_second = total_texts / total_time

    print("\nConcurrent Connections Test Results:")
    print(f"Total connections: {total_connections}")
    print(f"Texts per connection: {texts_per_connection}")
    print(f"Total texts processed: {total_texts}")
    print(f"Successful connections: {success_count}")
    print(f"Failed connections: {error_count}")
    print(f"Exception connections: {exception_count}")
    print(f"Total time: {total_time:.2f} seconds")
    print(f"Processing speed: {texts_per_second:.2f} texts/second")

    # Assertions
    assert success_count > 0, "No successful connections"
    assert total_time > 0, "Invalid processing time"
    # Allow some errors and exceptions under stress
    assert (
        error_count + exception_count < total_connections * 0.2
    ), "Too many errors/exceptions"


@pytest.mark.asyncio
@pytest.mark.stress
async def test_error_handling_under_load(stress_client):
    """Test error handling under load with mixed valid and invalid inputs."""
    total_texts = 5_000
    batch_size = 50
    texts = generate_test_texts(total_texts)

    # Add some invalid inputs
    invalid_texts = [None, "", " " * 1000]  # Empty, None, and very long text
    texts.extend(invalid_texts)

    # Add some random delays to simulate real-world conditions
    async def process_with_delay(batch: List[str]) -> Dict[str, Any]:
        await asyncio.sleep(random.uniform(0.1, 0.5))
        return await process_with_retry(stress_client, batch)

    start_time = time.time()
    tasks = []
    for i in range(0, len(texts), batch_size):
        batch = texts[i : i + batch_size]
        task = asyncio.create_task(process_with_delay(batch))
        tasks.append(task)
    results = await asyncio.gather(*tasks, return_exceptions=True)
    end_time = time.time()

    # Verify results
    success_count = 0
    error_count = 0
    exception_count = 0

    for result in results:
        if isinstance(result, Exception):
            exception_count += 1
            continue
        # Сначала assert на error/result
        assert ("error" in result) or (
            "result" in result
        ), f"Neither 'error' nor 'result' in response: {result}"
        if "error" in result:
            error_count += 1
            if "exception" in result:
                print(f"Error with exception: {result['error']}")
        elif "result" in result:
            res = result["result"]
            assert isinstance(res, dict), f"result is not a dict: {res}"
            if "success" in res and res["success"] is False:
                error_count += 1
                if "error" in res:
                    print(f"Error in result: {res['error']}")
            else:
                success_count += 1
                assert "data" in res, f"No 'data' in result: {res}"
                data = res["data"]
                assert isinstance(data, dict), f"data is not a dict: {data}"
                assert "embeddings" in data, f"No 'embeddings' in data: {data}"
                assert isinstance(
                    data["embeddings"], list
                ), f"'embeddings' is not a list: {data}"

    # Calculate statistics
    total_time = end_time - start_time
    texts_per_second = total_texts / total_time

    print("\nError Handling Under Load Test Results:")
    print(f"Total texts processed: {total_texts}")
    print(f"Successful batches: {success_count}")
    print(f"Failed batches: {error_count}")
    print(f"Exception batches: {exception_count}")
    print(f"Total time: {total_time:.2f} seconds")
    print(f"Processing speed: {texts_per_second:.2f} texts/second")

    # Assertions
    assert success_count > 0, "No successful batches processed"
    assert error_count > 0, "No errors detected with invalid inputs"
    assert total_time > 0, "Invalid processing time"
    # Allow some exceptions under stress
    assert exception_count < total_texts * 0.05, "Too many exceptions"
