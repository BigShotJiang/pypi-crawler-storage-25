"""
Tests for local JSON → upload → embed_file orchestration.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

import json
from dataclasses import replace
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest

from mcp_proxy_adapter.transfer.models import TransferReceipt

from embed_client.exceptions import EmbedClientError
from embed_client.embedding_client import EmbeddingClient
from embed_client.local_json_embed_file import embed_file_from_local_json_file


def _receipt() -> TransferReceipt:
    return TransferReceipt(
        transfer_id="tid-1",
        filename="up.json",
        size_bytes=100,
        checksum_algorithm="sha256",
        checksum_value="a" * 64,
        compression="identity",
        chunk_size=65536,
        offset=100,
        status="uploaded",
        completed=True,
        expires_at=None,
    )


@pytest.mark.asyncio
async def test_embed_file_from_local_json_calls_upload_session_and_embed(tmp_path):
    p = tmp_path / "blocks.json"
    p.write_text(json.dumps(["hi"]), encoding="utf-8")
    c = SimpleNamespace()
    c.upload_file = AsyncMock(return_value=_receipt())
    c.embed_file = AsyncMock(return_value={"done": True})
    c.client = SimpleNamespace(
        get_upload_session=AsyncMock(
            return_value={"storage_path": "/srv/staged/up.json"}
        )
    )

    def _cb(_msg):
        return None

    out = await embed_file_from_local_json_file(
        c, str(p), wait_timeout=120, on_ws_event=_cb
    )
    assert out == {"done": True}
    c.upload_file.assert_awaited_once()
    c.client.get_upload_session.assert_awaited_once_with("tid-1")
    call_kw = c.embed_file.await_args
    assert call_kw is not None
    assert call_kw[0][0] == "/srv/staged/up.json"
    assert call_kw.kwargs.get("file_format") == "json_array"
    assert call_kw.kwargs.get("local_source_path") == str(p.resolve())
    assert call_kw.kwargs.get("on_ws_event") is _cb


@pytest.mark.asyncio
async def test_upload_incomplete_raises(tmp_path):
    p = tmp_path / "blocks.json"
    p.write_text(json.dumps(["hi"]), encoding="utf-8")
    bad = replace(_receipt(), completed=False)
    c = SimpleNamespace()
    c.upload_file = AsyncMock(return_value=bad)
    c.embed_file = AsyncMock()
    c.client = SimpleNamespace(get_upload_session=AsyncMock())
    with pytest.raises(EmbedClientError, match="upload did not complete"):
        await embed_file_from_local_json_file(c, str(p))


@pytest.mark.asyncio
async def test_missing_storage_path_raises(tmp_path):
    p = tmp_path / "blocks.json"
    p.write_text(json.dumps(["hi"]), encoding="utf-8")
    c = SimpleNamespace()
    c.upload_file = AsyncMock(return_value=_receipt())
    c.embed_file = AsyncMock()
    c.client = SimpleNamespace(get_upload_session=AsyncMock(return_value={}))
    with pytest.raises(EmbedClientError, match="storage_path"):
        await embed_file_from_local_json_file(c, str(p))


@pytest.mark.asyncio
async def test_embed_file_requires_nonempty_input_file() -> None:
    ec = object.__new__(EmbeddingClient)
    ec.client = SimpleNamespace(jsonrpc_call=AsyncMock())
    with pytest.raises(EmbedClientError, match="input_file is required"):
        await EmbeddingClient.embed_file(ec, "", wait=False)
