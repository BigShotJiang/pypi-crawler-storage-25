"""
Focused tests for ClientSSLManager configuration validation (no legacy SSLContext APIs).

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from embed_client.ssl_manager import ClientSSLManager, create_ssl_manager


class TestClientSSLManagerValidation:
    def test_get_ssl_config_and_flags_disabled(self):
        cfg = {"ssl": {"enabled": False}}
        m = ClientSSLManager(cfg)
        assert m.get_ssl_config() == {"enabled": False}
        assert m.is_ssl_enabled() is False
        assert m.is_mtls_enabled() is False
        assert m.validate_ssl_config() == []

    def test_mtls_requires_cert_and_key_paths_in_config(self):
        cfg = {
            "ssl": {
                "enabled": True,
                "cert_file": "a.crt",
                "key_file": "a.key",
            }
        }
        m = ClientSSLManager(cfg)
        assert m.is_mtls_enabled() is True

    def test_mtls_false_when_cert_missing(self):
        cfg = {"ssl": {"enabled": True, "key_file": "a.key"}}
        assert ClientSSLManager(cfg).is_mtls_enabled() is False

    def test_validate_ssl_config_reports_missing_files(self):
        cfg = {
            "ssl": {
                "enabled": True,
                "cert_file": "/nonexistent/path/client.crt",
                "key_file": "/nonexistent/path/client.key",
                "ca_cert_file": "/nonexistent/ca.crt",
            }
        }
        errors = ClientSSLManager(cfg).validate_ssl_config()
        assert len(errors) >= 2
        assert any("Certificate file not found" in e for e in errors)
        assert any("Key file not found" in e for e in errors)
        assert any("CA certificate file not found" in e for e in errors)

    def test_get_supported_protocols(self):
        m = ClientSSLManager({"ssl": {"enabled": True}})
        protos = m.get_supported_protocols()
        assert "TLSv1.2" in protos and "TLSv1.3" in protos

    def test_create_ssl_manager_factory(self):
        cfg = {"ssl": {"enabled": False}}
        m = create_ssl_manager(cfg)
        assert isinstance(m, ClientSSLManager)
