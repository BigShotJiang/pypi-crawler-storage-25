"""
CLI wiring tests for embed-file-json (progress callback).

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest

from embed_client.cli_core import VectorizationCLI, _embed_file_ws_progress_stderr


def _minimal_valid_embed_file_result() -> dict:
    """Inline shape resolvable by ``resolve_embed_file_output_payload`` (one block)."""
    return {
        "embed_file_output": {
            "success": True,
            "data": {
                "dimension": 4,
                "results": [
                    {
                        "body": "block one",
                        "embedding": [0.0, 0.0, 0.0, 0.0],
                    }
                ],
            },
        }
    }


@pytest.mark.asyncio
async def test_embed_file_local_json_show_progress_forwards_stderr_callback(tmp_path):
    blocks_file = tmp_path / "blocks.json"
    blocks_file.write_text('["block one"]', encoding="utf-8")

    cli = VectorizationCLI()
    cli.client = SimpleNamespace()
    cli.client.embed_file_from_local_json_file = AsyncMock(
        return_value=_minimal_valid_embed_file_result()
    )

    ok = await cli.embed_file_local_json(str(blocks_file), show_progress=True)
    assert ok is True
    kw = cli.client.embed_file_from_local_json_file.await_args.kwargs
    assert kw.get("on_ws_event") is _embed_file_ws_progress_stderr


@pytest.mark.asyncio
async def test_embed_file_local_json_default_no_progress_callback(tmp_path):
    blocks_file = tmp_path / "blocks.json"
    blocks_file.write_text('["block one"]', encoding="utf-8")

    cli = VectorizationCLI()
    cli.client = SimpleNamespace()
    cli.client.embed_file_from_local_json_file = AsyncMock(
        return_value=_minimal_valid_embed_file_result()
    )

    await cli.embed_file_local_json(str(blocks_file), show_progress=False)
    kw = cli.client.embed_file_from_local_json_file.await_args.kwargs
    assert kw.get("on_ws_event") is None
