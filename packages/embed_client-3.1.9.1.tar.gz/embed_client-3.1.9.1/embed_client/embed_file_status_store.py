"""
In-memory embed_file job status store (per EmbeddingClient instance).

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

import copy
import threading
import time
from typing import Any, Dict, List, Optional


class EmbedFileJobStatusStore:
    """
    Thread-safe accumulation of embed_file RPC submit payload and WebSocket frames.

    Keys are ``job_id`` strings. Each entry may include ``submit``, ``messages``,
    ``last_event``, and timestamps. Payloads are deep-copied on write.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._jobs: Dict[str, Dict[str, Any]] = {}

    def record_submit(self, job_id: str, submit_payload: Dict[str, Any]) -> None:
        """Record the initial ``embed_file`` RPC success payload for ``job_id``."""
        with self._lock:
            entry = self._jobs.setdefault(
                job_id,
                {
                    "job_id": job_id,
                    "messages": [],
                },
            )
            entry["submit"] = copy.deepcopy(submit_payload)
            entry["submit_at"] = time.time()

    def record_message(self, job_id: str, event: Dict[str, Any]) -> None:
        """Append one WebSocket JSON payload (queue job subscription) for ``job_id``."""
        with self._lock:
            entry = self._jobs.setdefault(
                job_id,
                {
                    "job_id": job_id,
                    "messages": [],
                },
            )
            entry["messages"].append(copy.deepcopy(event))
            entry["last_event"] = copy.deepcopy(event)
            entry["last_message_at"] = time.time()

    def snapshot(self, job_id: str) -> Optional[Dict[str, Any]]:
        """Return a deep copy of stored state for ``job_id``, or ``None`` if unknown."""
        with self._lock:
            if job_id not in self._jobs:
                return None
            return copy.deepcopy(self._jobs[job_id])

    def messages(self, job_id: str) -> List[Dict[str, Any]]:
        """Return a deep copy of accumulated WS messages for ``job_id``."""
        with self._lock:
            if job_id not in self._jobs:
                return []
            return copy.deepcopy(self._jobs[job_id].get("messages", []))

    def clear(self, job_id: str) -> None:
        """Remove stored data for ``job_id``."""
        with self._lock:
            self._jobs.pop(job_id, None)

    def job_ids(self) -> List[str]:
        """List all ``job_id`` keys currently present."""
        with self._lock:
            return list(self._jobs.keys())


__all__ = ["EmbedFileJobStatusStore"]
