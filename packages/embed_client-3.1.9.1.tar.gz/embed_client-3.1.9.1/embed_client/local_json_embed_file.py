"""
Upload a validated local JSON file, resolve the server-side storage path, and run
:meth:`EmbeddingClient.embed_file` with ``input_file`` set to that path (same pattern
as the reference ``upload_file`` → ``get_upload_session`` → ``embed_file`` flow).

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

import os
from typing import TYPE_CHECKING, Any, Dict, Optional

from embed_client.exceptions import EmbedClientError
from embed_client.json_embed_file_preflight import validate_local_json_embed_file

if TYPE_CHECKING:
    from embed_client.embedding_client import EmbeddingClient


async def embed_file_from_local_json_file(
    client: "EmbeddingClient",
    local_path: str,
    *,
    max_block_bytes: Optional[int] = None,
    upload_filename: Optional[str] = None,
    **embed_file_kwargs: Any,
) -> Dict[str, Any]:
    """
    Validate a local ``json_array`` file, upload via the adapter, resolve
    ``storage_path`` via ``JsonRpcClient.get_upload_session``, then
    :meth:`~embed_client.embedding_client.EmbeddingClient.embed_file` with
    ``input_file`` set to that server-visible path and ``format=json_array``.

    ``local_source_path`` is set to *local_path* so optional server-side input
    checksum verification can match the uploaded bytes.
    """
    validate_local_json_embed_file(local_path, max_block_bytes=max_block_bytes)
    ap = os.path.abspath(local_path)
    receipt = await client.upload_file(ap, filename=upload_filename)
    if receipt.completed is not True:
        raise EmbedClientError(
            "adapter upload did not complete before embed_file "
            f"(transfer_id={receipt.transfer_id!r})"
        )
    session = await client.client.get_upload_session(receipt.transfer_id)
    if not isinstance(session, dict):
        raise EmbedClientError(
            "get_upload_session did not return a mapping; cannot run embed_file "
            f"(transfer_id={receipt.transfer_id!r})"
        )
    storage_path = session.get("storage_path")
    if not isinstance(storage_path, str) or not storage_path.strip():
        raise EmbedClientError(
            "upload session did not return storage_path; cannot run embed_file "
            f"(transfer_id={receipt.transfer_id!r})"
        )
    server_input = storage_path.strip()
    # Drop kwargs that would collide with our contract
    embed_file_kwargs.pop("file_format", None)
    embed_file_kwargs.pop("input_file", None)
    embed_file_kwargs.pop("inbound_transfer", None)
    embed_file_kwargs.pop("local_source_path", None)
    return await client.embed_file(
        server_input,
        local_source_path=ap,
        file_format="json_array",
        **embed_file_kwargs,
    )


__all__ = ["embed_file_from_local_json_file"]
