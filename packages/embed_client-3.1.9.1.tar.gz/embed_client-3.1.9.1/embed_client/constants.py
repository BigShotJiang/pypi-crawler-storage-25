"""
Shared constants for embed-client package (aligned with embedding service server).

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from pathlib import Path
from typing import Union

# ---------------------------------------------------------------------------
# Embed command (schema, default policy) — matches server embed/constants.py
# ---------------------------------------------------------------------------
EMBED_COMMAND_SCHEMA_DEFAULT_ERROR_POLICY = "fail_fast"

# ---------------------------------------------------------------------------
# Environment variable names for embedding service connection
# ---------------------------------------------------------------------------
EMBEDDING_SERVICE_BASE_URL_ENV: str = "EMBEDDING_SERVICE_BASE_URL"
EMBEDDING_SERVICE_PORT_ENV: str = "EMBEDDING_SERVICE_PORT"

# Default connection settings
DEFAULT_BASE_URL: str = "http://localhost"
DEFAULT_PORT: int = 8001

# Default poll interval (seconds) when waiting for queued job completion
DEFAULT_POLL_INTERVAL: float = 0.3

# Max UTF-8 bytes per string item in local json_array preflight (override via
# EMBED_CLIENT_MAX_JSON_BLOCK_BYTES).
DEFAULT_MAX_JSON_EMBED_BLOCK_BYTES: int = 1_048_576


def get_embed_project_root(module_file: Union[str, Path]) -> Path:
    """
    Return project root (parent of parent of the given module file).

    Use from main or CLI: ``get_embed_project_root(__file__)``.
    """
    return Path(module_file).resolve().parent.parent


__all__ = [
    "EMBED_COMMAND_SCHEMA_DEFAULT_ERROR_POLICY",
    "EMBEDDING_SERVICE_BASE_URL_ENV",
    "EMBEDDING_SERVICE_PORT_ENV",
    "DEFAULT_BASE_URL",
    "DEFAULT_PORT",
    "DEFAULT_POLL_INTERVAL",
    "DEFAULT_MAX_JSON_EMBED_BLOCK_BYTES",
    "get_embed_project_root",
]
