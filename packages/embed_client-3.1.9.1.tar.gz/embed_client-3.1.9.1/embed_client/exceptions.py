"""
Project-wide custom exceptions for embed-client (aligned with embedding service server).

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from typing import Any


class EmbedError(Exception):
    """Base exception for all embed package errors."""

    def __init__(self, message: str, *args: object, **kwargs: object) -> None:
        super().__init__(message, *args, **kwargs)
        self.message = message


class EmbedConfigError(EmbedError):
    """Config load, parse or validation failure."""


class EmbedQueueError(EmbedError):
    """Queue not initialized, submit failed, or job not found in queue."""


class EmbedClientError(EmbedError):
    """
    Client-facing failure: embed failed, job not found, status check failed,
    or models list failed.
    """


class EmbedServiceError(EmbedError):
    """Generic service or runtime failure (e.g. model load, encode, I/O)."""


class ModelServerUnavailableError(EmbedError):
    """Model server health check failed or connection error; use direct service."""


class EmbedGpuOutOfMemoryError(EmbedError):
    """
    GPU ran out of memory while loading or running the embedding model.
    User message suggests using CPU (embedding.device=cpu) or freeing GPU memory.
    """


class EmbedHTTPError(EmbedClientError):
    """
    HTTP layer error (4xx, 5xx) from transport or adapter.

    Attributes:
        status: HTTP status code returned by the server.
        message: Short human-readable message (same as historical client).
    """

    def __init__(self, status: int, message: str) -> None:
        super().__init__(f"HTTP {status}: {message}")
        self.status = status
        self.message = message


class EmbedAPIError(EmbedClientError):
    """
    Error returned by the Embedding Service API in the response body.

    The raw error payload from the API is stored in the ``error`` attribute.
    """

    def __init__(self, error: Any) -> None:
        super().__init__(f"API error: {error}")
        self.error = error


class EmbedTimeoutError(EmbedClientError):
    """Request to the Embedding Service timed out."""


class EmbedJSONError(EmbedClientError):
    """JSON parsing of a response body failed."""


__all__ = [
    "EmbedError",
    "EmbedConfigError",
    "EmbedQueueError",
    "EmbedClientError",
    "EmbedServiceError",
    "ModelServerUnavailableError",
    "EmbedGpuOutOfMemoryError",
    "EmbedHTTPError",
    "EmbedAPIError",
    "EmbedTimeoutError",
    "EmbedJSONError",
]
