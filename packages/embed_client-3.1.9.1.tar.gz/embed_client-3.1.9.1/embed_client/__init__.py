"""
embed-client: client for the Embedding Service API with authentication,
SSL/TLS, and mTLS configuration.

Canonical runtime client is :class:`EmbeddingClient` (direct JSON-RPC via
``mcp_proxy_adapter.client.jsonrpc_client.JsonRpcClient``).

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from importlib.metadata import PackageNotFoundError, version

from embed_client.auth import ClientAuthManager
from embed_client.config import ClientConfig
from embed_client.config_generator import ClientConfigGenerator
from embed_client.config_validator import ConfigValidator
from embed_client.embedding_client import EmbeddingClient
from embed_client.embedding_client_helpers import (
    list_commands_via_client,
    wait_for_job_poll,
)
from embed_client.ssl_manager import ClientSSLManager
from embed_client.client_factory import ClientFactory

try:
    __version__ = version("embed-client")
except PackageNotFoundError:
    # Editable checkout without install metadata (e.g. some unit-test sandboxes).
    __version__ = "3.1.9.1"

__all__ = [
    "EmbeddingClient",
    "wait_for_job_poll",
    "list_commands_via_client",
    "ClientConfig",
    "ClientAuthManager",
    "ClientSSLManager",
    "ClientFactory",
    "ClientConfigGenerator",
    "ConfigValidator",
]
