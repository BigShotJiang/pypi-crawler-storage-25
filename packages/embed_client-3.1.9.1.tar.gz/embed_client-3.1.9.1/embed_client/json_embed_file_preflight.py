"""
Client-side validation for local JSON files used with ``embed_file`` (``json_array``).

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

import json
import os
from typing import Any, List, Optional

from embed_client.constants import DEFAULT_MAX_JSON_EMBED_BLOCK_BYTES
from embed_client.exceptions import EmbedClientError


def resolve_max_json_block_bytes(explicit: Optional[int] = None) -> int:
    """
    Return max UTF-8 byte length per ``json_array`` item (one string per array element).

    Order: *explicit* if set, else ``EMBED_CLIENT_MAX_JSON_BLOCK_BYTES``, else
    :data:`DEFAULT_MAX_JSON_EMBED_BLOCK_BYTES`.
    """
    if explicit is not None:
        if explicit < 1:
            raise EmbedClientError("max_block_bytes must be >= 1")
        return explicit
    raw = os.environ.get("EMBED_CLIENT_MAX_JSON_BLOCK_BYTES", "").strip()
    if raw:
        try:
            v = int(raw, 10)
        except ValueError as e:
            raise EmbedClientError(
                "EMBED_CLIENT_MAX_JSON_BLOCK_BYTES must be a positive integer"
            ) from e
        if v < 1:
            raise EmbedClientError("EMBED_CLIENT_MAX_JSON_BLOCK_BYTES must be >= 1")
        return v
    return DEFAULT_MAX_JSON_EMBED_BLOCK_BYTES


def validate_local_json_embed_file(
    path: str, *, max_block_bytes: Optional[int] = None
) -> None:
    """
    Ensure *path* is a readable file, content is JSON, root is a non-empty array
    of strings (UTF-8 text per item, as the server ``embed_file`` ``json_array``
    format expects); each item's UTF-8 size is within the configured maximum.

    Raises:
        EmbedClientError: On missing file, non-JSON content, or schema/size violations.
    """
    if not path or not path.strip():
        raise EmbedClientError("local JSON embed file path is empty")
    ap = os.path.abspath(path)
    if not os.path.isfile(ap):
        raise EmbedClientError(f"not a file or not found: {ap}")
    if not os.access(ap, os.R_OK):
        raise EmbedClientError(f"file not readable: {ap}")

    try:
        with open(ap, "rb") as f:
            raw = f.read()
    except OSError as e:
        raise EmbedClientError(f"cannot read file: {ap}: {e}") from e

    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError as e:
        raise EmbedClientError(f"file must be UTF-8 (with optional BOM): {ap}") from e

    stripped = text.lstrip()
    if not stripped:
        raise EmbedClientError(f"file is empty: {ap}")
    if stripped[0] != "[":
        raise EmbedClientError(
            f"json_array embed file must be a JSON array at root (starts with '['): {ap}"
        )

    try:
        data: Any = json.loads(text)
    except json.JSONDecodeError as e:
        raise EmbedClientError(f"invalid JSON in {ap}: {e}") from e

    if not isinstance(data, list):
        raise EmbedClientError(
            f"JSON root must be an array for json_array format: {ap}"
        )
    if len(data) == 0:
        raise EmbedClientError(f"JSON array must not be empty: {ap}")

    max_b = resolve_max_json_block_bytes(max_block_bytes)
    for i, item in enumerate(data):
        if not isinstance(item, str):
            raise EmbedClientError(
                f"item {i} must be a string (UTF-8 text to embed), "
                f"got {type(item).__name__}: {ap}"
            )
        nbytes = len(item.encode("utf-8"))
        if nbytes > max_b:
            raise EmbedClientError(
                f"item {i} exceeds max block size ({nbytes} > {max_b} bytes): {ap}"
            )


def iter_json_array_block_texts(path: str) -> List[str]:
    """
    After :func:`validate_local_json_embed_file`, load and return array strings
    in order (for tests / introspection).
    """
    with open(path, "rb") as f:
        raw = f.read()
    text = raw.decode("utf-8-sig")
    data = json.loads(text)
    assert isinstance(data, list)
    out: List[str] = []
    for item in data:
        assert isinstance(item, str)
        out.append(item)
    return out


__all__ = [
    "iter_json_array_block_texts",
    "resolve_max_json_block_bytes",
    "validate_local_json_embed_file",
]
