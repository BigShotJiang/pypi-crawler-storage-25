#!/usr/bin/env python3
"""
CLI Application for Text Vectorization
Command-line interface for embedding text using embed-client.

This CLI is fully based on the embed-client library and uses:
- ClientFactory for client creation
- ClientConfig for configuration management
- response_parsers for data extraction
- All authentication methods (API Key, JWT, Basic, Certificate)
- Queue management commands

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import argparse
import asyncio
import sys
from typing import Any, Dict  # noqa: F401

from embed_client.config import ClientConfig
from embed_client.cli_core import VectorizationCLI, create_config_from_args
from embed_client.constants import DEFAULT_POLL_INTERVAL


async def main():
    """Main CLI function."""
    parser = argparse.ArgumentParser(
        description="CLI Application for Text Vectorization (fully based on embed-client library)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Vectorize text from command line
  python -m embed_client vectorize "hello world" "test text"

  # Vectorize text from file
  python -m embed_client vectorize --file texts.txt

  # Server-side embed_file: local JSON array file (upload + json_array), not line-based embed
  python -m embed_client embed-file-json ./blocks.json

  # Markdown → json_array (YAML front matter strip; body split on \\n\\n; per-block UTF-8 cap); then embed-file-json
  python -m embed_client prepare-embed-file-json ./doc.md -o ./doc_embed_file.json
  python -m embed_client embed-file-json ./doc_embed_file.json --show-progress

  # Use HTTPS with API key authentication
  python -m embed_client vectorize "hello world" --host https://localhost --port 8443 --api-key your-key

  # Use mTLS with client certificates
  python -m embed_client vectorize "hello world" --ssl --cert-file client.crt --key-file client.key

  # Use JWT authentication
  python -m embed_client vectorize "hello" --jwt-secret secret --jwt-username user --jwt-password pass

  # Use config file
  python -m embed_client --config config.json vectorize "hello"

  # Queue management
  python -m embed_client queue-list
  python -m embed_client queue-status JOB_ID
  python -m embed_client queue-cancel JOB_ID
  python -m embed_client queue-wait JOB_ID

  # Get help from service
  python -m embed_client help

  # Check service health
  python -m embed_client health

  # List available models
  python -m embed_client models

  # Get timing statistics (when server has timing_registration enabled)
  python -m embed_client timing-stats
  python -m embed_client timing-stats --file-path /path/to/timings.jsonl
        """,
    )

    # Global options
    parser.add_argument(
        "--config", "-c", help="Path to configuration file (JSON or YAML)"
    )
    parser.add_argument(
        "--host",
        default="http://localhost",
        help="Server host (default: http://localhost)",
    )
    parser.add_argument(
        "--port", type=int, default=8001, help="Server port (default: 8001)"
    )
    parser.add_argument(
        "--timeout", type=float, default=30.0, help="Request timeout in seconds"
    )

    # Authentication options
    auth_group = parser.add_argument_group("authentication")
    auth_group.add_argument("--api-key", help="API key for authentication")
    auth_group.add_argument(
        "--api-key-header", help="API key header name (default: X-API-Key)"
    )
    auth_group.add_argument("--jwt-secret", help="JWT secret for authentication")
    auth_group.add_argument("--jwt-username", help="JWT username")
    auth_group.add_argument("--jwt-password", help="JWT password")
    auth_group.add_argument("--basic-username", help="Basic auth username")
    auth_group.add_argument("--basic-password", help="Basic auth password")

    # SSL/TLS options
    ssl_group = parser.add_argument_group("ssl/tls")
    ssl_group.add_argument("--ssl", action="store_true", help="Enable SSL/TLS")
    ssl_group.add_argument("--cert-file", help="Client certificate file")
    ssl_group.add_argument("--key-file", help="Client private key file")
    ssl_group.add_argument("--ca-cert-file", help="CA certificate file")

    # Commands
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Vectorize command
    vectorize_parser = subparsers.add_parser("vectorize", help="Vectorize text")
    vectorize_parser.add_argument("texts", nargs="*", help="Texts to vectorize")
    vectorize_parser.add_argument(
        "--file", "-f", help="File containing texts (one per line)"
    )
    vectorize_parser.add_argument(
        "--format",
        choices=["json", "csv", "vectors"],
        default="json",
        help="Output format (default: json)",
    )
    vectorize_parser.add_argument(
        "--full-data",
        action="store_true",
        help="Show full embedding data (body, embedding, tokens, bm25_tokens)",
    )
    vectorize_parser.add_argument(
        "--model",
        help="Model name (server-side, optional)",
    )
    vectorize_parser.add_argument(
        "--dimension",
        type=int,
        help="Expected vector dimension (server-side, optional)",
    )
    vectorize_parser.add_argument(
        "--error-policy",
        choices=["continue", "fail_fast"],
        default="continue",
        help="Error policy: continue (per-item errors) or fail_fast (default: continue)",
    )
    vectorize_parser.add_argument(
        "--device",
        choices=["auto", "cpu", "cuda", "cuda:0"],
        help="Device for embedding (server-side: auto, cpu, cuda, cuda:0)",
    )
    vectorize_parser.add_argument(
        "--wait-timeout",
        type=float,
        default=None,
        metavar="SECS",
        dest="wait_timeout",
        help="Wait up to SECS seconds for job completion (default: no wait). Use 0 for unlimited.",
    )

    embed_file_json = subparsers.add_parser(
        "embed-file-json",
        help="Local JSON array file → adapter upload → embed_file (json_array)",
    )
    embed_file_json.add_argument(
        "json_path",
        help="Path to UTF-8 JSON file: non-empty array of strings (json_array)",
    )
    embed_file_json.add_argument(
        "--max-block-bytes",
        type=int,
        default=None,
        metavar="N",
        help="Max UTF-8 bytes per block (default: env EMBED_CLIENT_MAX_JSON_BLOCK_BYTES or 1 MiB)",
    )
    embed_file_json.add_argument(
        "--upload-filename",
        default=None,
        help="Optional filename hint for the transfer (default: basename of json_path)",
    )
    embed_file_json.add_argument(
        "--wait-timeout",
        type=float,
        default=None,
        metavar="SECS",
        dest="embed_file_wait_timeout",
        help="embed_file WebSocket wait timeout in seconds (omit for server default)",
    )
    embed_file_json.add_argument(
        "--download-to",
        default=None,
        help="Write server result JSON to this path (omit for temp file)",
    )
    embed_file_json.add_argument(
        "--skip-download",
        action="store_true",
        help="Skip HTTP download; still send transfer_ack when applicable",
    )
    embed_file_json.add_argument(
        "--model",
        help="Model name (server-side, optional)",
    )
    embed_file_json.add_argument(
        "--dimension",
        type=int,
        help="Expected vector dimension (server-side, optional)",
    )
    embed_file_json.add_argument(
        "--device",
        choices=["auto", "cpu", "cuda", "cuda:0"],
        help="Device for embedding (server-side)",
    )
    embed_file_json.add_argument(
        "--error-policy",
        choices=["continue", "fail_fast"],
        default="continue",
        help="Error policy for embed_file (default: continue)",
    )
    embed_file_json.add_argument(
        "--show-progress",
        action="store_true",
        help="Print WebSocket/status JSON lines to stderr while waiting for embed_file",
    )

    prepare_embed = subparsers.add_parser(
        "prepare-embed-file-json",
        help="Markdown/text → UTF-8 json_array (split body on blank lines \\n\\n; per-block UTF-8 cap; no network)",
    )
    prepare_embed.add_argument(
        "md_path",
        help="Path to UTF-8 Markdown or plain text (.md) file",
    )
    prepare_embed.add_argument(
        "-o",
        "--output",
        default=None,
        metavar="PATH",
        help="Output JSON path (default: <input_stem>_embed_file.json beside input)",
    )
    prepare_embed.add_argument(
        "--max-block-bytes",
        type=int,
        default=None,
        metavar="N",
        dest="max_block_bytes",
        help="Max UTF-8 bytes per paragraph block after \\n\\n split (default: env or 1 MiB; error if exceeded)",
    )
    prepare_embed.add_argument(
        "--max-chunks",
        type=int,
        default=None,
        metavar="N",
        help="Emit at most N blocks (smoke tests on huge files; omit for full document)",
    )
    prepare_embed.add_argument(
        "--no-strip-front-matter",
        action="store_true",
        help="Do not strip YAML front matter between first pair of --- lines",
    )

    # Health command
    subparsers.add_parser("health", help="Check service health")

    # Models command
    subparsers.add_parser("models", help="List available embedding models")

    # Timing stats command
    timing_parser = subparsers.add_parser(
        "timing-stats",
        help="Get timing statistics (server must have timing_registration enabled)",
    )
    timing_parser.add_argument(
        "--file-path",
        help="Path to timing file on server (optional, uses server default if omitted)",
    )

    # Help command
    help_parser = subparsers.add_parser("help", help="Get help from service")
    help_parser.add_argument("--command", help="Specific command to get help for")

    # Commands command
    subparsers.add_parser("commands", help="Get available commands")

    # Queue commands
    queue_list_parser = subparsers.add_parser("queue-list", help="List queued commands")
    queue_list_parser.add_argument("--status", help="Filter by status")
    queue_list_parser.add_argument("--limit", type=int, help="Limit number of results")

    queue_status_parser = subparsers.add_parser("queue-status", help="Get job status")
    queue_status_parser.add_argument("job_id", help="Job identifier")

    queue_cancel_parser = subparsers.add_parser("queue-cancel", help="Cancel a job")
    queue_cancel_parser.add_argument("job_id", help="Job identifier")

    queue_wait_parser = subparsers.add_parser(
        "queue-wait", help="Wait for job completion"
    )
    queue_wait_parser.add_argument("job_id", help="Job identifier")
    queue_wait_parser.add_argument(
        "--timeout", type=float, default=60.0, help="Timeout in seconds"
    )
    queue_wait_parser.add_argument(
        "--poll-interval",
        type=float,
        default=DEFAULT_POLL_INTERVAL,
        help=f"Poll interval in seconds (default: {DEFAULT_POLL_INTERVAL})",
    )

    queue_logs_parser = subparsers.add_parser("queue-logs", help="Get job logs")
    queue_logs_parser.add_argument("job_id", help="Job identifier")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    if args.command == "prepare-embed-file-json":
        from embed_client.md_embed_file_prep import prepare_markdown_cli_main

        return prepare_markdown_cli_main(args)

    # Load configuration
    config = None
    config_dict = None

    if args.config:
        # Load from config file using ClientConfig
        config = ClientConfig(args.config)
        config.load_config()
    else:
        # Create config from command line arguments
        config_dict = create_config_from_args(args)

    # Create CLI instance
    cli = VectorizationCLI()

    try:
        # Connect to service
        if not await cli.connect(config=config, config_dict=config_dict):
            return 1

        # Execute command
        if args.command == "vectorize":
            texts = args.texts
            if args.file:
                # Use async file reading to avoid blocking the event loop
                # Read file in executor to avoid blocking
                loop = asyncio.get_event_loop()

                def read_file_sync(file_path: str) -> list[str]:
                    """Read file synchronously in executor."""
                    with open(file_path, "r", encoding="utf-8") as f:
                        return [line.strip() for line in f if line.strip()]

                file_texts = await loop.run_in_executor(None, read_file_sync, args.file)
                texts.extend(file_texts)

            if not texts:
                print("❌ No texts provided", file=sys.stderr)
                return 1

            await cli.vectorize_texts(
                texts,
                args.format,
                args.full_data,
                timeout=getattr(args, "wait_timeout", None),
                model=getattr(args, "model", None),
                dimension=getattr(args, "dimension", None),
                error_policy=getattr(args, "error_policy", "continue"),
                device=getattr(args, "device", None),
            )

        elif args.command == "embed-file-json":
            ok = await cli.embed_file_local_json(
                args.json_path,
                max_block_bytes=getattr(args, "max_block_bytes", None),
                upload_filename=getattr(args, "upload_filename", None),
                wait_timeout=getattr(args, "embed_file_wait_timeout", None),
                download_to=getattr(args, "download_to", None),
                skip_download=bool(getattr(args, "skip_download", False)),
                model=getattr(args, "model", None),
                dimension=getattr(args, "dimension", None),
                device=getattr(args, "device", None),
                error_policy=getattr(args, "error_policy", "continue"),
                show_progress=bool(getattr(args, "show_progress", False)),
            )
            if not ok:
                return 1

        elif args.command == "health":
            await cli.health_check()

        elif args.command == "help":
            await cli.get_help(getattr(args, "command", None))

        elif args.command == "commands":
            await cli.get_commands()

        elif args.command == "models":
            await cli.get_models()

        elif args.command == "timing-stats":
            await cli.get_timing_stats(getattr(args, "file_path", None))

        elif args.command == "queue-list":
            await cli.queue_list(
                getattr(args, "status", None), getattr(args, "limit", None)
            )

        elif args.command == "queue-status":
            await cli.queue_status(args.job_id)

        elif args.command == "queue-cancel":
            await cli.queue_cancel(args.job_id)

        elif args.command == "queue-wait":
            await cli.queue_wait(
                args.job_id,
                timeout=getattr(args, "timeout", 60.0),
                poll_interval=getattr(args, "poll_interval", DEFAULT_POLL_INTERVAL),
            )

        elif args.command == "queue-logs":
            await cli.queue_logs(args.job_id)

        return 0

    except KeyboardInterrupt:
        print("\n🛑 Interrupted by user", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"❌ Error: {e}", file=sys.stderr)
        import traceback

        traceback.print_exc()
        return 1
    finally:
        await cli.disconnect()


def cli_main():
    """Synchronous entry point for CLI command."""
    return asyncio.run(main())


if __name__ == "__main__":
    sys.exit(cli_main())
