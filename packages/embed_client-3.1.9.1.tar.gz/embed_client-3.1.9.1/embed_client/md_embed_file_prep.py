"""
Prepare Markdown (or plain text) files as UTF-8 ``json_array`` inputs for ``embed_file``.

Reads a ``.md`` file, optionally strips YAML front matter between the first pair of
``---`` lines, splits the body on blank lines (``\\n\\n``) into paragraph blocks,
enforces a per-block UTF-8 byte cap via
:func:`~embed_client.json_embed_file_preflight.resolve_max_json_block_bytes`,
and writes a top-level JSON array of strings suitable for
:func:`~embed_client.local_json_embed_file.embed_file_from_local_json_file`.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

import json
import os
from typing import Any, List, Optional

from embed_client.exceptions import EmbedClientError
from embed_client.json_embed_file_preflight import (
    resolve_max_json_block_bytes,
    validate_local_json_embed_file,
)


def strip_optional_yaml_front_matter(text: str) -> str:
    """
    If *text* begins with a line ``---`` (after optional BOM, already decoded),
    return the substring after the next line that is exactly ``---`` (stripped).
    Otherwise return *text* unchanged.

    If an opening ``---`` is present but no closing ``---`` line is found, returns
    *text* unchanged (no strip).
    """
    if not text:
        return text
    lines = text.splitlines(keepends=True)
    if not lines:
        return text
    if lines[0].strip() != "---":
        return text
    for i in range(1, len(lines)):
        if lines[i].strip() == "---":
            return "".join(lines[i + 1 :])
    return text


def split_body_into_text_blocks(body: str, max_block_bytes: int) -> List[str]:
    """
    Split *body* on double newlines (paragraph boundaries) only.

    Line endings are normalized to ``\\n`` (``\\r\\n`` and lone ``\\r`` → ``\\n``)
    before splitting on the two-character separator ``\\n\\n``. Each segment is
    stripped of leading/trailing whitespace, and segments empty after strip are
    dropped (runs of blank lines collapse to one boundary).

    Each non-empty block must encode to at most *max_block_bytes* UTF-8 bytes.
    If any block exceeds the cap, raises :class:`~embed_client.exceptions.EmbedClientError`
    (no byte-level re-chunking).
    """
    if max_block_bytes < 1:
        raise EmbedClientError("max_block_bytes must be >= 1")
    normalized = body.replace("\r\n", "\n").replace("\r", "\n")
    paragraphs = normalized.split("\n\n")
    out: List[str] = []
    for raw in paragraphs:
        block = raw.strip()
        if not block:
            continue
        encoded = block.encode("utf-8")
        if len(encoded) > max_block_bytes:
            raise EmbedClientError(
                "paragraph exceeds max_block_bytes after split on blank lines "
                f"({len(encoded)} bytes > {max_block_bytes}); shorten the paragraph "
                "or increase --max-block-bytes / EMBED_CLIENT_MAX_JSON_BLOCK_BYTES"
            )
        out.append(block)
    return out


def build_embed_file_json_array_from_markdown_text(
    text: str,
    *,
    max_block_bytes: Optional[int] = None,
    strip_front_matter: bool = True,
    max_chunks: Optional[int] = None,
) -> List[str]:
    """
    Return a non-empty list of strings (``json_array`` items) from Markdown/plain text.

    Raises:
        EmbedClientError: Empty output, or size/schema issues after splitting.
    """
    max_b = resolve_max_json_block_bytes(max_block_bytes)
    body = strip_optional_yaml_front_matter(text) if strip_front_matter else text
    blocks = split_body_into_text_blocks(body, max_b)
    if max_chunks is not None:
        if max_chunks < 1:
            raise EmbedClientError("max_chunks must be >= 1 when set")
        blocks = blocks[:max_chunks]
    if not blocks:
        raise EmbedClientError(
            "no non-empty text blocks after preparation (empty file or body?)"
        )
    return list(blocks)


def prepare_markdown_path_to_json_file(
    md_path: str,
    output_path: str,
    *,
    max_block_bytes: Optional[int] = None,
    strip_front_matter: bool = True,
    max_chunks: Optional[int] = None,
) -> str:
    """
    Read UTF-8 (with optional BOM) from *md_path*, build ``json_array``, write *output_path*,
    then run :func:`~embed_client.json_embed_file_preflight.validate_local_json_embed_file`
    on the result.

    Returns:
        Absolute path to *output_path*.
    """
    if not md_path or not md_path.strip():
        raise EmbedClientError("markdown input path is empty")
    ap_in = os.path.abspath(md_path)
    if not os.path.isfile(ap_in):
        raise EmbedClientError(f"not a file or not found: {ap_in}")
    if not os.access(ap_in, os.R_OK):
        raise EmbedClientError(f"file not readable: {ap_in}")
    try:
        with open(ap_in, "rb") as f:
            raw = f.read()
    except OSError as e:
        raise EmbedClientError(f"cannot read file: {ap_in}: {e}") from e
    try:
        decoded = raw.decode("utf-8-sig")
    except UnicodeDecodeError as e:
        raise EmbedClientError(
            f"file must be UTF-8 (with optional BOM): {ap_in}"
        ) from e

    data = build_embed_file_json_array_from_markdown_text(
        decoded,
        max_block_bytes=max_block_bytes,
        strip_front_matter=strip_front_matter,
        max_chunks=max_chunks,
    )
    ap_out = os.path.abspath(output_path)
    _parent = os.path.dirname(ap_out)
    if _parent:
        os.makedirs(_parent, exist_ok=True)
    try:
        with open(ap_out, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False)
    except OSError as e:
        raise EmbedClientError(f"cannot write file: {ap_out}: {e}") from e

    validate_local_json_embed_file(ap_out, max_block_bytes=max_block_bytes)
    return ap_out


def prepare_markdown_cli_main(args: Any) -> int:
    """
    CLI entry for ``prepare-embed-file-json`` (expects argparse namespace attributes).
    """
    import sys
    from pathlib import Path

    try:
        out_path = getattr(args, "output", None)
        if not out_path:
            base = Path(args.md_path).resolve()
            out_path = str(base.parent / f"{base.stem}_embed_file.json")
        out = prepare_markdown_path_to_json_file(
            args.md_path,
            out_path,
            max_block_bytes=getattr(args, "max_block_bytes", None),
            strip_front_matter=not bool(getattr(args, "no_strip_front_matter", False)),
            max_chunks=getattr(args, "max_chunks", None),
        )
        print(out, file=sys.stdout)
        return 0
    except EmbedClientError as e:
        print(f"❌ prepare-embed-file-json: {e}", file=sys.stderr)
        return 1


__all__ = [
    "build_embed_file_json_array_from_markdown_text",
    "prepare_markdown_cli_main",
    "prepare_markdown_path_to_json_file",
    "split_body_into_text_blocks",
    "strip_optional_yaml_front_matter",
]
