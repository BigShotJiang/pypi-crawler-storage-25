Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

## Embedding Service – Client Integration Guide

### 1. Transport & endpoints

**Transport**

- **Protocol**: JSON‑RPC 2.0 over HTTP(S) / mTLS
- **Typical base URL (mTLS in Docker)**: `https://<embedding-service-host>:8001`

**HTTP endpoints**

- `GET /health` – liveness / readiness check
- `POST /api/jsonrpc` – JSON‑RPC endpoint for all commands:
  - `embed`
  - `models`
  - `help`
  - other service commands

**mTLS client certificates (outside Docker)**

Use certificates from `mtls_certificates`:

- **Client certificate / key**:
  - `mtls_certificates/client/embedding-service.crt`
  - `mtls_certificates/client/embedding-service.key`
- **CA certificate**:
  - `mtls_certificates/ca/ca.crt`

When using the `embed-client` library, these paths are passed via the client configuration (`server`, `auth`, `ssl`, `security` sections) and translated into `mcp_proxy_adapter` parameters by the adapter layer.

---

### 2. JSON‑RPC `embed` request

**Endpoint & method**

- **Endpoint**: `POST /api/jsonrpc`
- **JSON‑RPC method**: `embed`

**Example request**

```json
{
  "jsonrpc": "2.0",
  "method": "embed",
  "params": {
    "texts": [
      "This is a test sentence.",
      "Another text to embed."
    ],
    "model": "all-MiniLM-L6-v2",
    "dimension": 384,
    "error_policy": "continue"
  },
  "id": 1
}
```

**Parameters**

- **`texts` (required, `string[]`)**
  - One embedding per element: `texts[i] → result[i]`
- **`model` (optional, `string`)**
  - Explicit model name (e.g. `"all-MiniLM-L6-v2"`)
  - If omitted, the service default model is used
- **`dimension` (optional, `int > 0`)**
  - Expected embedding dimension
  - Must be a positive integer; non‑positive or non‑integer values are rejected
- **`error_policy` (optional, `"fail_fast"` | `"continue"`)**
  - `"fail_fast"` – **legacy behavior**:
    - Any invalid item in the batch → **top‑level JSON‑RPC error**, no partial result
  - `"continue"` – **recommended for new clients**:
    - Top‑level call succeeds
    - For each input `texts[i]`:
      - On success → normal embedding and `error: null`
      - On validation problem → `embedding: null` + per‑item `error` object

> **Recommendation**: For all new batch integrations (SVO chunker, doc‑pipelines, etc.) always send `error_policy: "continue"`.

---

### 3. Success response shape

On success (either with `error_policy = "continue"` or `"fail_fast"` with no validation issues), the response has the following shape:

```json
{
  "jsonrpc": "2.0",
  "result": {
    "success": true,
    "data": {
      "embeddings": [
        [0.1, 0.2, 0.3, "..."],
        null
      ],
      "results": [
        {
          "body": "This is a test sentence.",
          "embedding": [0.1, 0.2, 0.3, "..."],
          "tokens": ["This", "is", "a", "test", "sentence", "."],
          "bm25_tokens": ["this", "test", "sentence"],
          "error": null
        },
        {
          "body": "   ",
          "embedding": null,
          "tokens": [],
          "bm25_tokens": [],
          "error": {
            "code": "only_special_chars",
            "message": "Text at index 1 contains only special characters"
          }
        }
      ],
      "model": "all-MiniLM-L6-v2",
      "dimension": 384
    }
  },
  "id": 1
}
```

**Positional guarantees**

- `len(data.embeddings) == len(params.texts)`
- `len(data.results)    == len(params.texts)`

Items are **positionally aligned by index**:

- Input: `texts[i]`
- Output:
  - `data.embeddings[i]` – embedding or `null`
  - `data.results[i]` – object with `body`, `embedding`, `tokens`, `bm25_tokens`, `error`

---

### 4. Top‑level error vs per‑item error

#### 4.1. Top‑level JSON‑RPC error (no `data.results`)

Top‑level error means **no embeddings at all**:

```json
{
  "jsonrpc": "2.0",
  "error": {
    "code": -32602,
    "message": "Empty texts list provided"
  },
  "id": 1
}
```

Typical causes:

- Structurally invalid request:
  - `texts` missing or not a list
  - `dimension` non‑positive or not an integer
  - `error_policy` not in `["fail_fast", "continue"]`
- `error_policy = "fail_fast"` and at least one text fails validation

**Client behavior**

- Treat this as “no embeddings at all”
- Abort current operation and surface/log the error

#### 4.2. Per‑item errors (`error_policy = "continue"`)

With `error_policy = "continue"`:

- Top‑level call returns `result.success: true`
- For each `texts[i]`:
  - On success:
    - `embeddings[i]` is a numeric vector (list of floats)
    - `results[i].embedding` is the same vector
    - `results[i].error` is `null`
  - On validation problem:
    - `embeddings[i]` is `null`
    - `results[i].embedding` is `null`
    - `results[i].error` is an object describing the problem

Non‑exhaustive list of `results[i].error.code` values:

- `"too_short"` – empty text / only whitespace
- `"too_long"` – text exceeds max length
- `"only_special_chars"` – no letters/digits (e.g. `"!!!"`)
- `"invalid_characters"` – encoding or character set issues
- `"batch_limit_exceeded"` – batch size exceeds server limit
- `"validation_error"` – other validation issues

---

### 5. Recommended client behavior

#### 5.1. New clients (SVO chunker, doc‑pipelines, etc.)

**Always**:

- Set `error_policy: "continue"` for batch `embed` calls
- Iterate outputs **by index** and inspect per‑item errors:

```python
texts = [...]  # input batch
result = ...   # JSON-RPC result

data = result["result"]["data"]
items = data["results"]

for i, text in enumerate(texts):
    item = items[i]
    err = item["error"]

    if err is None:
        embedding = item["embedding"]
        use_embedding(text, embedding)
    else:
        log_warning(
            f"Embedding error for index {i}: "
            f"{err['code']} - {err['message']}"
        )
        # Decide how to handle:
        # - skip this item
        # - fallback to another model
        # - mark the chunk as invalid
```

**Never**:

- Assume that all `embeddings[i]` are present
- Ignore `item["error"]` when `embedding` is `null`

#### 5.2. Legacy compatibility

If the call returns a **top‑level error** (no `result.data`):

- Behave like old clients:
  - Abort operation
  - Log and surface the error to the caller

#### 5.3. Retry & batching strategy

- Prefer **smaller batches** (e.g. `32–128` items) to:
  - Limit the blast radius of transient infrastructure errors
  - Avoid hitting `batch_limit_exceeded`
- On `batch_limit_exceeded`:
  - Retry with a smaller batch size, or
  - Degrade to single‑item calls for critical items

---

### 6. Client library: `EmbeddingClient`

The **`embed-client`** package exposes **`EmbeddingClient`** (`from embed_client import EmbeddingClient`). It uses **`mcp_proxy_adapter.client.jsonrpc_client.JsonRpcClient`** for HTTP(S)/mTLS and JSON-RPC.

#### 6.1. Initialization

- **From config dict:** `async with EmbeddingClient.from_config_dict(cfg) as client:`
- **From file:** `EmbeddingClient.from_config_file(path)`
- **From base URL (HTTP):** `EmbeddingClient.from_base_url_port("http://localhost", 8001)`

Configuration uses the same top-level keys documented in **`CONFIGURATION.md`** (`protocol`, `server`, `auth`, `ssl`, …).

#### 6.2. Embedding and queue behavior

- **`await client.embed(texts, error_policy="continue", wait=True)`** — high-level batch embed; normalizes sync vs queue responses.
- **`await client.cmd("embed", params={...})`** — low-level JSON-RPC with the same parameter contract as in sections 2–5.
- **`await client.wait_for_job(job_id, ...)`** / **`await client.job_status(job_id)`** — when the server returns a **`job_id`** (queue mode).
- **`await client.list_queued_commands(...)`** — inspect the queue.

#### 6.3. WebSocket completion

When the adapter exposes WebSocket job completion, **`wait_for_job`** prefers the adapter’s **`wait_for_job`** / WebSocket path before HTTP polling. Advanced use: **`open_bidirectional_ws_channel`** on **`EmbeddingClient`** delegates to the underlying **`JsonRpcClient`**.

#### 6.4. Errors

Use exceptions from **`embed_client.exceptions`**, for example **`EmbedClientError`**, **`EmbedHTTPError`**, **`EmbedConfigError`**. Map JSON-RPC top-level errors and HTTP failures to these types per call site.

---

### 7. CLI (installed scripts)

- **`embed-vectorize`** — vectorization and service commands (`vectorize`, `health`, `models`, queue helpers, …). Same implementation as **`python -m embed_client`**.
- **`embed-config-generator`** / **`embed-config-validator`** — configuration tooling.

See **`CLI_README.md`** at the repository root for flags and examples.

---

### 8. Configuration generator and validator

Generate JSON for all security modes with **`embed-config-generator`**; validate with **`embed-config-validator`**. Generated files work with **`EmbeddingClient.from_config_file`** and **`ClientConfig`**.

---

### 9. Summary

- JSON-RPC **`embed`** on **`POST /api/jsonrpc`**; positional alignment **`texts[i]`** ↔ **`results[i]`** with **`error_policy: "continue"`** recommended.
- **`EmbeddingClient`** is the supported Python API; see **`embed_client/embedding_client.py`** for method list.
- CLI and config tools ship as console scripts listed in **`pyproject.toml`**.

