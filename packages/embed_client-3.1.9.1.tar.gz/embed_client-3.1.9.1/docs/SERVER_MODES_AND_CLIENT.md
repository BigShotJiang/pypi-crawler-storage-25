# Server modes (sync vs queue) and client mapping

**Author:** Vasiliy Zdanovskiy  
**Email:** vasilyvz@gmail.com

## Deploy verification matrix (8 modes)

Before release, the project expects the real test server to be exercised in these modes (see deploy rule):

| # | Mode |
|---|------|
| 1 | HTTP |
| 2 | HTTP + token |
| 3 | HTTP + token + roles |
| 4 | HTTPS |
| 5 | HTTPS + token |
| 6 | HTTPS + token + roles |
| 7 | mTLS |
| 8 | mTLS + roles |

Example scripts (`examples/security_examples.py`, `examples/security_examples_ru.py`) demonstrate **six** primary runnable patterns (plain HTTP/HTTPS/mTLS and token/roles variants where applicable). For **`http_token_roles`** and **`https_token_roles`**, use generated configs from **`embed-config-generator`** or full field tables in **CONFIGURATION.md**.

## Server behaviour

1. **Sync mode** (queue disabled): response includes full **`data`** with **`results`** in one shot; no **`job_id`**.
2. **Queue mode**: first response may include **`job_id`**; client must poll **`embed_job_status`** (or equivalent) until completion.

## Client behaviour (`EmbeddingClient`)

- **`embed`** abstracts sync vs queue: if a **`job_id`** appears, the client waits (WebSocket when available, else polling) and returns a normalized result dict.
- **`wait_for_job`** / **`job_status`** expose queue operations when you need explicit control.
- **`list_queued_commands`** lists outstanding work when the server supports it.

## Local file upload and `embed_file` (`json_array`)

When the input exists only on the **client** (no shared server filesystem), the supported path is: **validate** a local UTF-8 JSON **`json_array`** file (array of strings) → **upload** via the adapter (same HTTP/TLS and authentication as JSON-RPC) → **`get_upload_session`** → pass **`storage_path`** as **`input_file`** to **`embed_file`** with **`format=json_array`**.

- **CLI:** **`prepare-embed-file-json`** (no network) turns Markdown or plain text into a **`json_array`** file built from **paragraph blocks** split **only** on **`\n\n`** (blank-line boundaries; no semantic chunking): optional YAML front matter strip (first pair of **`---`** lines), per-paragraph UTF-8 cap (same semantics as **`EMBED_CLIENT_MAX_JSON_BLOCK_BYTES`** / **`--max-block-bytes`**; oversize paragraphs **fail** preparation with no auto-split), optional **`--max-chunks`** to truncate the block list for smoke tests on very large sources. Then **`embed-file-json`** runs the upload and **`embed_file`** wait. Pass **`--show-progress`** to print WebSocket/status JSON lines to **stderr** while waiting for **`embed_file`** completion.
- **Programmatic:** **`EmbeddingClient.embed_file_from_local_json_file`** — same pipeline; optional **`on_ws_event`** matches the CLI progress hook.

When the file is already on the **server**, use **`embed_file`** with **`input_file`** (server-visible path), e.g. the canonical tour with **`CANONICAL_EMBED_FILE_SERVER_PATH`**.

See **`CLI_README.md`**, **`docs/api_format.md`**, and **`CONFIGURATION.md`** (`EMBED_CLIENT_MAX_JSON_BLOCK_BYTES`).

## Configuration mapping

Each mode maps to **`protocol`** (`http` | `https` | `mtls`), **`auth.method`** and related blocks, **`ssl`**, and optional **`security`** (roles). Use **`embed-config-generator --mode …`** to emit valid JSON, then **`EmbeddingClient.from_config_dict`** or **`from_config_file`**.

See also **`examples/security_examples.py`** for concrete **`EmbeddingClient`** construction patterns.
