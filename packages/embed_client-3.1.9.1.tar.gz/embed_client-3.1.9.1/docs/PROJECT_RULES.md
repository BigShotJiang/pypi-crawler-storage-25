<!--
Template: project rules for any repository.
On project bootstrap, fill §0 and keep IDs (CR-*, LAYOUT-*, NAME-*) stable.
Author: Vasiliy Zdanovskiy — vasilyvz@gmail.com
-->

# Project rules (canonical template)

Use rule IDs: `CR-*`, `LAYOUT-*`, `NAME-*` (e.g. `CR-007`, `LAYOUT-02`).

Optional: [`docs/assistant_rules_inventory.md`](assistant_rules_inventory.md) for MCP, transcripts, §24–§25.

Active subagent file in `.cursor/agents/*.md` overrides conflicting rows in this document for that role.

---

## 0. Project profile (fill once per repository)

Replace placeholders when **creating** or **adopting** a project. Models should write this table on first scaffold. **This repository** uses the **Value** column below; keep it aligned with the package layout.

| Key | Value (this repository) | Description |
|-----|-------------------------|-------------|
| `PROJECT_SLUG` | `embed_client` | Short ASCII id for paths and package naming (Python package directory name). |
| `PRIMARY_LANGUAGE` | `Python` | Main implementation language (`Python`, `TypeScript`, …). |
| `PACKAGE_ROOT` | `embed_client/` | Root directory for production code (**no `src/`** unless profile explicitly allows). |
| `TEST_FRAMEWORK` | `pytest` | Default test runner for CR-007 analogues. |
| `VENV_DIR` | `.venv` | Virtual environment directory at repo root (if applicable). |
| `CHAT_LOCALE` | `ru` | Language for **chat** with the user. |
| `ARTIFACT_LOCALE` | `en` | Language for code, comments, docstrings, tests, `docs/` unless a named doc specifies otherwise. |
| `HEADER_AUTHOR` | `Vasiliy Zdanovskiy` | Required author string in file headers (see CR-012). |
| `HEADER_EMAIL` | `vasilyvz@gmail.com` | Required email in file headers. |
| `DOC_FILENAME_STYLE` | `snake_case` | `snake_case` or `kebab-case` for new Markdown under `docs/` (stay consistent). |
| `USE_CODE_MAP` | `yes` | If `yes`, run the project’s **code map / index** tool after logical code-structure changes (`code_mapper` → `code_analysis/`). |

### Placeholder tokens (portable `rules_template/` bundle)

When adopting the template in a **new** repo, replace angle-bracket tokens everywhere they appear until none remain:

| Token | Where to set |
|-------|----------------|
| `<PROJECT_SLUG>` | §0 `PROJECT_SLUG`; title in `docs/agents/project_overlay.md`; path segments under repo root |
| `<Name>` | §0 `HEADER_AUTHOR`; optional HTML comment headers atop Markdown files |
| `<email>` | §0 `HEADER_EMAIL`; same as above |
| `PACKAGE_ROOT` | Often literal `<PROJECT_SLUG>/` — must match the real package directory |

**This repository:** values are set in §0 and [`docs/agents/project_overlay.md`](agents/project_overlay.md); PyPI distribution name is `embed-client` (see `pyproject.toml`).

See also: project [`README.md`](../README.md); binding **`rules_template.zip`** → [`rules_bundle_README.md`](rules_bundle_README.md).

---

## 1. Precedence (highest first)

| Rank | Layer |
|------|--------|
| 1 | **Current user message** — explicit instruction wins. |
| 2 | **Safety / repo boundary** — `CR-002`. |
| 3 | **Active subagent role** — `.cursor/agents/<name>.md` if present. |
| 4 | **This file** — `CR-*`, `LAYOUT-*`, `NAME-*`, and §0 profile. |
| 5 | **`docs/assistant_rules_inventory.md`** — if present. |
| 6 | Tool / IDE defaults. |

---

## 2. Core rules (`CR-*`)

| ID | P | Rule |
|----|---|------|
| **CR-001** | 0 | Execute the **current task** literally; do not skip or dilute stacked instructions. |
| **CR-002** | 0 | **Do not modify paths outside this repository** without explicit user permission. |
| **CR-003** | 0 | If the profile requires a **project id file** (e.g. `projectid` JSON with `id` UUID4 + `description`): it must exist and be valid. Missing/invalid → **stop and report** to the user. |
| **CR-004** | 0 | **Questions** (analysis-only): answer in **chat**, not unsolicited files. Durable docs/bugs/plans only when the task is to write them. |
| **CR-005** | 1 | **Python / venv:** use **`VENV_DIR`** (default `.venv` in repo root). It must be **active** before `python`, `pip`, tests, and linters. On **`ModuleNotFoundError`**, missing dependency, wrong interpreter path, or **`pip install` / environment errors**: **first** verify activation (`which python`, `$VIRTUAL_ENV` on Unix, or Windows equivalents); activate (`source <VENV_DIR>/bin/activate` or project script) and **retry** — do not treat “package missing” as proven until the interpreter is confirmed to be the venv’s. |
| **CR-015** | 0 | **Forbidden:** `pip install --break-system-packages` and other **PEP 668** / externally-managed-environment **override** flags **unless** the user **explicitly authorizes that exact shell command** in this conversation (silence or “fix it” is **not** permission). |
| **CR-006** | 1 | If `USE_CODE_MAP` = `yes`: after each **logically finished** structural change (split file, remove symbol + references, new package), refresh the project index (e.g. `code_mapper` → `code_analysis/`). If the tool is missing, state that clearly. |
| **CR-007** | 1 | After changing production code, run the repo’s **required linters/formatters/typecheckers** on touched paths (for Python template defaults: `black`, `flake8`, `mypy`) and fix findings. Adjust in §0 if the stack differs. |
| **CR-008** | 1 | **Module size (Python default):** ~**350** lines → prefer split; **≤ ~400** → acceptable; **≥ ~450** → **must** split. For other languages, define limits in §0. |
| **CR-009** | 1 | **Documentation in code:** modules, classes, and public functions/methods need docstrings (or equivalent); parameters and returns typed or described; non-obvious logic: short comments. **Abstract** API → language-appropriate failure (`NotImplementedError`, `abc.abstractmethod`, etc.) — not a silent stub. |
| **CR-010** | 1 | **Chat** in `CHAT_LOCALE`; **repository artifacts** in `ARTIFACT_LOCALE` unless the user specifies a document language. When `CHAT_LOCALE` is `ru` and `ARTIFACT_LOCALE` is `en`: **Russian only in chat** — not for committed `.md`, code, comments, or subagent role bodies. |
| **CR-011** | 2 | **Version control:** commit after a logical batch; **push** only when the user asks. |
| **CR-012** | 2 | **Headers:** in each required file type, include `HEADER_AUTHOR` and `HEADER_EMAIL` (or project’s standard header block). |
| **CR-013** | 2 | **Imports / includes** at top of file unless lazy-loading is intentional. |
| **CR-014** | 3 | If the project defines numeric **log importance** (0–10), use the project scale consistently. |
| **CR-016** | 1 | **Parallelism:** where **dependencies allow**, run **independent** work **in parallel** (parallel delegations, parallel specialist tasks, parallel waves). **Do not** serialize independent subtasks without a **stated** dependency or resource reason. Orchestrators **must** decompose so unrelated units can execute **concurrently** when the runtime supports it (see also full-stack caps in `.cursor/agents/orchestrator.md` where applicable). |
| **CR-017** | 0 | **ТЗ and plans in files:** Any **durable** technical specification (**ТЗ**) **or implementation plan** (global / tactical / atomic decomposition meant to drive work) **must** be written under the **`docs/specs/<specname>/`** tree (**LAYOUT-09**). **Do not** keep the only copy of ТЗ or the plan in chat — **always** materialize to the paths in **LAYOUT-09**. **Chat-only** output does **not** replace files when the task is to produce a spec or plan. |
| **CR-018** | 0 | **Orchestrators — required subagent unavailable:** If a **required** subagent type for the current workflow **cannot be invoked** (missing from the runtime, disabled, invocation fails before work starts, or a subordinate reports downstream unavailability), **every** orchestrator in **`.cursor/agents/orchestrator.md`**, **`orchestrator_debug.md`**, **`orchestrator_tactical.md`**, **`orchestrator_tactical_debug.md`** **must**: **(1)** **stop all subordinate work** — no new delegations; cancel or cease **every** parallel branch and downstream specialist under that orchestrator’s control for this assignment; **(2)** **not** substitute the missing role with direct repo tools, ad-hoc edits, or a different agent where the chain requires the missing type; **(3)** ensure the **user is informed** — **`orchestrator`** / **`orchestrator_debug`** message the user **in the same turn** (which role is missing, what was halted, what is needed); **`orchestrator_tactical`** / **`orchestrator_tactical_debug`** **escalate immediately** to the parent with the same facts so the parent can message the user. **Silent** halt, partial continuation, or “work around the gap” is **forbidden**. |

**P:** **0** governance / stop, **1** quality, **2** hygiene, **3** optional classification.

---

## 3. Repository layout (`LAYOUT-*`)

Default for new projects; adjust in §0 if monorepo or polyglot requires extra roots.

| ID | Rule |
|----|------|
| **LAYOUT-01** | **No `src/` by default.** Production code lives under **`PACKAGE_ROOT`** at repository root (e.g. `<slug>/`, `app/`). Add `src/` only if §0 explicitly allows. |
| **LAYOUT-02** | **Automated tests** under **`tests/`** (or profile path), mirroring package structure where helpful. |
| **LAYOUT-03** | **Runtime logs** under **`logs/`** (gitignore by default); no secrets in tracked logs. |
| **LAYOUT-04** | **Sample / non-secret configuration** under **`configs/`**; production secrets not in git. |
| **LAYOUT-05** | **Durable documentation** under **`docs/`** (guides, specs, stable references). |
| **LAYOUT-06** | **Working AI outputs** (reports, in-progress bugs, session dumps the user asked to save) under **`docs/ai_reports/`**. Promote finished write-ups into the appropriate `docs/` subtree. |
| **LAYOUT-07** | **`scripts/`** — **All** operational and maintenance tooling (CI helpers, local dev utilities, one-off migrations, smoke runners, wrappers). **Non-pytest** checks and manual / integration harnesses belong here, **not** under **`tests/`** (pytest suite stays in **`tests/`** per LAYOUT-02). |
| **LAYOUT-08** | **`docs/` subtrees (canonical for this repository).** New durable documentation belongs **under** these directories (not loose at repo root unless the task explicitly calls for it). **`docs/agents/`** — Cursor/agent shared context (`project_overlay.md`, pointers to §0–§3). **`docs/ai_reports/`** — working AI outputs per **LAYOUT-06**; promote finished work into **`docs/specs/`**, guides, or **`docs/bugreports/`** — not into removed duplicate trees. **`docs/specs/`** — container for file-backed ТЗ and plans; **each** spec lives under **`docs/specs/<specname>/`** (**LAYOUT-09**, **CR-017**); epic example: **`docs/specs/server_client_convergence_and_release/`**. **`docs/plans/`** — planning notes and roadmaps outside the strict per-spec task tree. **`docs/bugreports/`** — stable bug write-ups. **`docs/EN/`** and **`docs/RU/`** — localized user-facing trees; keep parallel paths where both exist (e.g. **`api/`**, guides). **`docs/reports/`** — **local scratch only** (session dumps, informal notes); **gitignored** — do not commit; promote anything worth keeping into `docs/bugreports/`, `docs/specs/`, or root `docs/*.md`. **`docs/*.md`** at `docs/` root — cross-cutting guides (e.g. `PROJECT_RULES.md`, `development.md`). Optional: **`docs/projectid.example.json`** as sample for **CR-003** when a repo-root `projectid` is used. Duplicate documentation trees that previously existed under **`docs/tech_spec/`** and **`docs/specs/tech_spec/`** were **removed from the repository** as part of documentation normalization (server/client convergence epic); do not recreate them. |
| **LAYOUT-09** | **File-backed specifications (ТЗ) and plan tree.** **Canonical program-of-record** for file-backed specs and plans: **`docs/specs/<specname>/`** per **CR-017** (repository **`docs/`** per **LAYOUT-05**). Epic example: **`docs/specs/server_client_convergence_and_release/`**. Durable ТЗ **and** durable plans **must** be stored **under that directory** (not only under `docs/specs/` without a `<specname>` folder). **Mandatory layout** (copy from **`docs/specs/_template/`** when bootstrapping): **`docs/specs/<specname>/spec.md`** — root ТЗ / epic spec; **`docs/specs/<specname>/<global_step_slug>/spec.md`** — global step (goal, scope, exit criteria); **`docs/specs/<specname>/<global_step_slug>/<tactical_step_slug>/spec.md`** — tactical step (work packages, dependencies); **`docs/specs/<specname>/<global_step_slug>/<tactical_step_slug>/<atomic_step_slug>.md`** — one file per **atomic** step (single PR-sized unit). **Atomic step content** must be **unambiguous**, **complete** for its scope, and **consistent** with parent specs (see **`planner_auto`**); exhaustive “weakest model” / LLAMA-style detail is **not** required. Name **`specname`**, slugs, and atomic basenames with **`DOC_FILENAME_STYLE`** and **`NAME-*`** (default: **`snake_case`** unless an existing spec uses another style). Pre-epic duplicate trees under **`docs/tech_spec/`** and **`docs/specs/tech_spec/`** were **removed from the repository** as part of documentation normalization (server/client convergence epic); the codebase and **`docs/specs/<specname>/`** are authoritative. |

```text
<repo>/
  <PACKAGE_ROOT>/      # production code (no src/ unless profile says otherwise)
  tests/
  scripts/             # ops, maintenance, non-pytest harnesses (LAYOUT-07)
  logs/
  configs/
  docs/                # LAYOUT-05, LAYOUT-08
    agents/
    ai_reports/
    specs/             # LAYOUT-09: per-spec root docs/specs/<specname>/ (spec.md + steps)
    plans/
    bugreports/
    EN/                # localized (e.g. api/, guides)
    RU/
    reports/           # local only (ignored by git) — see LAYOUT-08
    …                  # root-level *.md guides as needed
  projectid            # if CR-003 enabled for this project
  <VENV_DIR>/          # local, usually not committed
```

Optional generated indices (if `USE_CODE_MAP` = yes): e.g. `code_analysis/` — name in profile.

**Also read:** [`docs/agents/project_overlay.md`](agents/project_overlay.md). **Section map:** [`docs/agents/universal_project_context.md`](agents/universal_project_context.md).

---

## 4. Naming conventions (`NAME-*`)

**Default below = Python** (PEP 8). If `PRIMARY_LANGUAGE` is not Python, add a **§0 override row** or attach a short annex; until then, apply the closest idiomatic standard for that language.

| ID | Scope | Rule |
|----|--------|------|
| **NAME-01** | **Files (Python modules)** | `snake_case.py`; one conceptual module per file; avoid redundant words (`utils_helpers.py` → narrow the name). |
| **NAME-02** | **Test files** | `test_<module_or_feature>.py` under `tests/` (pytest style); mirror path of code under test when practical (`tests/pkg/test_foo.py` ↔ `pkg/foo.py`). |
| **NAME-03** | **Packages (directories)** | Lowercase, short; prefer single word; multi-word → `snake_case` (no hyphens in import path). |
| **NAME-04** | **Classes / exceptions** | `PascalCase`. Exception classes end with `Error` where applicable. |
| **NAME-05** | **Functions / methods** | `snake_case`; verb-led (`get_`, `create_`, `parse_`). |
| **NAME-06** | **Variables / parameters / attributes** | `snake_case`; avoid 1–2 character names except loop indices (`i`, `j`, `k`) and well-known math symbols in scope. |
| **NAME-07** | **Constants** | `UPPER_SNAKE_CASE` at module or class level for true constants. |
| **NAME-08** | **Privacy** | One leading `_` for **internal** module API not meant for importers; **never** use trailing underscore unless avoiding a keyword clash. |
| **NAME-09** | **Properties (`@property`)** | Same as public attributes: `snake_case`; avoid Java-style `get_foo()` **and** a `foo` property duplicating the same — pick one style per class. |
| **NAME-10** | **Type aliases / TypeVars** | `PascalCase` for `TypeAlias` names; `TypeVar` names short `T`, `T_co`, or descriptive `PascalCase`. |
| **NAME-11** | **Enums** | Class `PascalCase`; members `UPPER_SNAKE_CASE` if they behave as constants. |
| **NAME-12** | **Markdown / docs filenames** | Use **`DOC_FILENAME_STYLE`** from §0 consistently (`design_notes.md` vs `design-notes.md`). |
| **NAME-13** | **Config keys (JSON/YAML)** | `snake_case` keys unless integrating an external schema that requires another convention (then document in §0). |

---

## 5. Anti-patterns (naming & layout)

- Mixed `camelCase` / `snake_case` for Python **module-level** public APIs without documented reason.
- Generic names: `data`, `info`, `handle`, `manager` without qualifier.
- Abbreviations only clear to one author (`usr_mgr_cfg`); prefer readable length over cryptic short names.
- Test files that do not start with `test_` (pytest discovery) unless configured otherwise in §0.

---

## 6. Where to duplicate in tooling

- Prefer **one line** in IDE User Rules: “Follow `docs/PROJECT_RULES.md` IDs; fill §0 profile.”
- Keep **5–10 line** emergency checklist in User Rules only if files are not always loaded.

---

## 7. Filled profile — target repository (optional)

Authoritative profile keys for **embed-client** are in **§0** above.

**Project id file (CR-003):** not used in this repository unless a repo-root `projectid` JSON is added (see [`projectid.example.json`](projectid.example.json)).

**Documentation tree:** canonical **`docs/`** subtrees — **LAYOUT-08** (§3); file-backed ТЗ and plans — **LAYOUT-09** / **CR-017** (`docs/specs/<specname>/`). Quick reference: [`docs/agents/project_overlay.md`](agents/project_overlay.md).
