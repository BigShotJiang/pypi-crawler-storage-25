# Tactical task DN-02: Root product documentation and PyPI metadata surface

## Purpose

Rewrite the repository root user-facing documents (`README.md`, `CONFIGURATION.md`, `CLI_README.md`) and align `pyproject.toml` `[project]` metadata so they match the canonical `embed_client.EmbeddingClient` API, actual public exports, runtime dependency set, and entry points, eliminating broken imports and stale legacy product narrative.

## Parent links

| Document | Path |
|----------|------|
| Epic | `docs/specs/server_client_convergence_and_release/spec.md` |
| Global plan | `docs/specs/server_client_convergence_and_release/plan.md` |
| Global step | `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md` |
| Baseline code evidence | `docs/ai_reports/baseline_audit_code_research.md` |
| Migration completion | `docs/ai_reports/production_migration_completion_report.md` |

## Scope

**Included**

- `README.md`: installation, `EmbeddingClient` quick start, canonical `localhost:8001` + `mTLS` example prominence, correct error names, valid imports, correct test/dev pointers.
- `CONFIGURATION.md`: current configuration model, `ClientConfig` / validator / generator alignment, recommended localhost `8001` mTLS integration with `mtls_certificates`.
- `CLI_README.md`: current entry points and CLI workflows only.
- `pyproject.toml`: user-facing package description must describe the migrated `EmbeddingClient` API and not deleted queue method names or removed client classes.

**Excluded**

- `docs/client_integration_guide.md`, `docs/api_format.md`, `docs/SERVER_MODES_AND_CLIENT.md`, `examples/**` content rewrites (DN-03).
- Legacy tree deletion and governance file cleanup (DN-01).

## Boundaries

- Do **not** document removed `EmbeddingServiceAsyncClient`, `adapter_transport`, or `testing_client` surfaces.
- Do **not** add backward-compatibility sections.
- Do **not** claim undeclared runtime dependencies.

## Dependencies

- DN-01 complete, or at minimum DN-01 link removals known so root docs do not point to deleted trees.

## Parallelization note

- Can run in parallel with DN-03 after terminology is synchronized on `EmbeddingClient` and the canonical mTLS example path.

## Expected outcome

1. Root docs and PyPI-facing metadata describe only the migrated client.
2. Copy-paste imports from `README.md` work on the current package.
3. Canonical mTLS example is a primary user entry point from root docs.

## Correction items

- Broken `README.md` legacy import and stale `pyproject.toml` product description had to be replaced with `EmbeddingClient`-centric wording.

## Questions / escalation rule

- If PyPI long-description packaging requires structural change beyond text alignment, escalate to global orchestrator.

---

## File inventory

| action | path | purpose |
|--------|------|---------|
| modify | `README.md` | Root product docs and canonical example placement. |
| modify | `CONFIGURATION.md` | Current config story and localhost:8001 mTLS guidance. |
| modify | `CLI_README.md` | CLI docs for current package commands. |
| modify | `pyproject.toml` | User-facing package description alignment. |

## Class/function inventory

- `embed_client.EmbeddingClient` — base class `None`; canonical public client.
  - `from_base_url_port(base_url: str, port: Optional[int] = None, *, timeout: float = 30.0) -> "EmbeddingClient"`: build a client from URL/port.
  - `from_config_dict(config_dict: Dict[str, Any]) -> "EmbeddingClient"`: build from config dict.
  - `from_config_file(config_path: Union[str, Path]) -> "EmbeddingClient"`: build from config file.
  - `embed(...) -> Dict[str, Any]`: submit or execute embedding requests.
  - `wait_for_job(job_id: str, timeout: Union[int, float] = 60, poll_interval: float = 1.0) -> Dict[str, Any]`: wait for queue completion.
  - `job_status(job_id: str) -> Dict[str, Any]`: fetch queue/job status.
  - `embed_file(...) -> Dict[str, Any]`: submit file embedding job.
  - `models() -> Dict[str, Any]`, `list_commands() -> Dict[str, Any]`, `cmd(...) -> Dict[str, Any]`, `timing_stats(...) -> Dict[str, Any]`, `fetch_openapi_schema() -> Dict[str, Any]`, `http_get(path: str) -> tuple[int, str]`, `jsonrpc(method: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]`: introspection and transport helpers.

## Data structures

**None** created by this tactical task; prose must align with existing config structures only.

## Import map

**Markdown only.** Embedded code snippets must use:

- `from embed_client import EmbeddingClient`
- `from embed_client.exceptions import EmbedClientError`

## Error handling map

- Refer only to `embed_client.exceptions` hierarchy.
- If a snippet mentions HTTP failures, use `EmbedHTTPError`.
- If a snippet mentions API/JSON/timeout issues, use the corresponding current exception classes rather than deleted names.

## Config dependency

- `protocol`: string; documented in `CONFIGURATION.md`.
- `server.host`: string; documented in `CONFIGURATION.md`.
- `server.port`: integer; documented in `CONFIGURATION.md`.
- `ssl.cert`, `ssl.key`, `ssl.ca`, `ssl.check_hostname`: current mTLS keys; documented in `CONFIGURATION.md`.
- `auth.token`, `auth.token_header`: documented only if current config supports them.

## Test plan

| file | test / verification | expectation |
|------|---------------------|-------------|
| `README.md` | `researcher_code` alignment audit | only current symbols/imports |
| `CONFIGURATION.md` | `researcher_doc` consistency audit | localhost:8001 mTLS section present |
| `CLI_README.md` | `researcher_doc` consistency audit | matches package entry points |
| `pyproject.toml` | `researcher_code` audit | description matches current API names |

## Concrete examples

- Input: user copies README sample. Output: `from embed_client import EmbeddingClient` import succeeds.
- Input: user follows localhost example in `CONFIGURATION.md`. Output: config points to `localhost:8001` with repo certificates under `mtls_certificates`.

## Algorithm / logic description

1. Replace legacy root narrative with `EmbeddingClient`.
2. Make the canonical mTLS example visible before secondary workflows.
3. Ensure configuration and CLI docs point to current package entry points.
4. Align `pyproject.toml` description text with the actual public API and runtime dependencies.

## Forbidden approaches

- Do not mention removed async/adapter/testing clients as supported usage.
- Do not hide the canonical mTLS example deep in the document set.
# Tactical task DN-02: Root product documentation and PyPI metadata surface

## Purpose

Rewrite the repository root user-facing documents (`README.md`, `CONFIGURATION.md`, `CLI_README.md`) and align `pyproject.toml` `[project]` metadata (especially `description` and dependency-related prose) so they match the canonical `embed_client.EmbeddingClient` API, actual `embed_client.__all__` exports, runtime dependency set from `pyproject.toml`, and entry points — eliminating broken imports such as `embed_client.async_client.EmbeddingServiceAsyncClient` reported by `researcher_code`.

## Parent links

| Document | Path |
|----------|------|
| Epic | `docs/specs/server_client_convergence_and_release/spec.md` |
| Global plan | `docs/specs/server_client_convergence_and_release/plan.md` |
| Global step | `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md` |
| Code evidence | `docs/ai_reports/baseline_audit_code_research.md`, `docs/ai_reports/production_migration_completion_report.md` |

## Scope

**Included**

- `README.md`: English (or repo-standard) product overview; installation; quick start with `from embed_client import EmbeddingClient`; **prominent section** “Canonical real-server E2E (localhost:8001, mTLS)” linking to `examples/canonical_mtls_localhost_8001.py`, `RUN_CANONICAL_MTLS_E2E`, `mtls_certificates/` layout, and `tests/test_canonical_mtls_example.py` per `researcher_doc` recommendations; remove/replace all `EmbeddingServiceAsyncClient`, `async_client`, nonexistent test module names; align feature list with `EmbeddingClient` capabilities from `researcher_code` inventory.
- `CONFIGURATION.md`: JSON/config schema narrative aligned with `ClientConfig` / `ConfigValidator` / generator CLI; section “Recommended local integration (mTLS, port 8001)” consistent with certificate paths used by canonical example.
- `CLI_README.md`: commands `embed-config-generator`, `embed-config-validator`, `embed-vectorize` / `python -m embed_client.cli` — match actual entry points in `pyproject.toml`.
- `pyproject.toml`: `[project]` `name`, `version`, `description`, `readme`, `dependencies` prose in `description` must not claim queue methods `submit_job`, `get_job_status_or_result`, `list_queue` if those are not the public `EmbeddingClient` API (per `researcher_code` mismatch report); describe `EmbeddingClient`, `embed`, `wait_for_job`, `job_status`, `list_queued_commands`, `cmd`, optional `embed_file`, introspection (`list_commands`, `models`, `fetch_openapi_schema`, `http_get`, `timing_stats`), TLS (`is_mtls_enabled`, `get_ssl_config`), file status store hooks if public.

**Excluded**

- Full rewrite of `docs/client_integration_guide.md` (DN-03).
- Legacy tree deletion (DN-01).

## Boundaries

- Do **not** add backward-compatibility sections for removed APIs.
- Do **not** list PyJWT, `cryptography`, or `pydantic` as **core** runtime dependencies unless `researcher_code` re-verifies imports in `embed_client/` after edits.

## Dependencies

- **DN-01** complete **or** verified that README does not link to paths deleted in DN-01 (if DN-02 runs first, avoid linking into `docs/tech_spec/`).

## Parallelization note

- **Parallel with DN-03** after shared terminology (EmbeddingClient, canonical example path) is agreed — preferably DN-02 publishes README anchor first, DN-03 links examples README back.

## Expected outcome

1. `pip install` / PyPI reader sees accurate package description and correct API names.
2. Copy-paste imports from `README.md` work against current package layout.
3. Configuration documentation matches validator/generator behavior.

## Correction items

- `researcher_code` identified `README.md` broken import — **must** be fixed.
- `pyproject.toml` description mismatch — **must** be fixed.

## Questions / escalation rule

- If `long_description` should be moved to external file for PyPI, escalate to **global orchestrator** (scope creep).

---

## File inventory

| action | path | purpose |
|--------|------|---------|
| modify | `README.md` | User-facing root documentation; canonical mTLS block. |
| modify | `CONFIGURATION.md` | Config schema and modes. |
| modify | `CLI_README.md` | CLI reference. |
| modify | `pyproject.toml` | `[project]` description and metadata alignment. |

## Class/function inventory

**Documentation only.** Must accurately name:

- `embed_client.EmbeddingClient` — `from embed_client import EmbeddingClient`
- Helpers: `wait_for_job_poll`, `list_commands_via_client` if mentioned
- Factory/config: `ClientFactory`, `ClientConfigGenerator`, `ConfigValidator`, `ClientConfig`, `ClientAuthManager`, `ClientSSLManager`

Signatures in prose must match `embed_client/embedding_client.py` public methods per `researcher_code` table (no invented methods).

## Data structures

**None** in prose beyond describing JSON config fields matching `ClientConfig` / normalized config dict.

## Import map

**N/A** (markdown). Examples embedded in README must use valid imports:

- `from embed_client import EmbeddingClient`
- `from embed_client.exceptions import EmbedClientError, EmbedHTTPError, ...` when demonstrating errors

## Error handling map

Prose should reference `embed_client.exceptions` hierarchy per `production_migration_completion_report.md`, not deleted exception names.

## Config dependency

Document keys consistent with `ConfigValidator` / `ClientConfigGenerator` output — **researcher_code** may list keys from `embed_client/config.py` if needed in atomic step.

## Test plan

| test file | asserts |
|-----------|---------|
| No new tests required for markdown-only | `tester_auto`: full suite unchanged |
| Optional | `tests/test_canonical_mtls_example.py` still discoverable from README path |

## Concrete examples

- **Wrong:** `from embed_client.async_client import EmbeddingServiceAsyncClient`
- **Right:** `from embed_client import EmbeddingClient` then `EmbeddingClient(protocol="https", host="localhost", port=8001, cert="...", key="...", ca="...", check_hostname=False)`

## Algorithm / logic description (README structure)

1. Title and one-paragraph purpose (migrated server-aligned client).
2. Installation (`pip install embed-client` / editable dev).
3. **Canonical E2E** block (mTLS, 8001, certs, env, test module).
4. Minimal code sample: `EmbeddingClient` + `embed` or `health`.
5. Pointers to `CONFIGURATION.md`, `CLI_README.md`, `examples/README.md`.
6. Security modes matrix summary (link to `SERVER_MODES` or examples) without duplicating full matrix.
7. Development / tests (accurate pytest invocation via `pyproject.toml`).

## Forbidden approaches

- Do not document `EmbeddingServiceAsyncClient`, `adapter_transport`, `testing_client`.
- Do not reference deleted test file names.
