# Tactical task DN-04: Alignment verification and closure report

## Purpose

Complete the specialist verification chain for `documentation_normalization`, prove that the surviving docs/examples align with the migrated code and package metadata, and materialize the closure report `docs/ai_reports/documentation_normalization_closure_report.md` with exact removed, rewritten, and surviving artifacts plus residual publication risks.

## Parent links

| Document | Path |
|----------|------|
| Epic | `docs/specs/server_client_convergence_and_release/spec.md` |
| Global step | `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md` |
| Atomic steps index | `docs/specs/server_client_convergence_and_release/documentation_normalization/steps/ATOMIC_STEPS_INDEX.md` |

## Scope

**Included**

- `researcher_code`: verify user-facing docs/examples vs the current `EmbeddingClient` API and canonical example contract.
- `researcher_doc`: verify surviving doc set, link integrity, governance consistency, and absence of stale references to deleted legacy trees in active documentation.
- `tester_auto`: run required validation for the changed worktree (`pytest`, relevant format/lint/type gates).
- `doc_writer`: write or update `docs/ai_reports/documentation_normalization_closure_report.md` with exact removed/re-written paths, canonical example placement, `embed_file` contract, subordinate state, and residual blockers/risks.

**Excluded**

- New product/code changes beyond what verification requires as corrective follow-up.

## Boundaries

- Tactical orchestrator does not run tests or perform code/doc research directly.
- Closure is invalid until `tester_auto` reports all required tests pass.

## Dependencies

- DN-01, DN-02, DN-03 completed on disk.

## Parallelization note

- `researcher_code` and `researcher_doc` can run in parallel.
- `tester_auto` can run in parallel once file writes are stable.
- `doc_writer` runs after evidence packets are available.

## Expected outcome

1. Evidence-backed PASS/FAIL for code alignment, doc alignment, and tests.
2. Closure report exists on disk at `docs/ai_reports/documentation_normalization_closure_report.md`.
3. Final report states clearly that `docs/tech_spec/branches/documentation_normalization/` remains as the active tactical subtree while legacy `docs/specs/tech_spec/` and other legacy `docs/tech_spec/` content are removed.

## Correction items

- If `researcher_doc` finds stale links or inaccurate closure-report wording, `doc_writer` must update the report and the affected documents before closure.
- If `researcher_code` finds remaining legacy support narrative in active user docs/examples, assign a corrective doc-writing pass before accepting closure.

## Questions / escalation rule

- Any contradiction between current docs and the global step acceptance criteria that cannot be resolved within documentation scope must be escalated to the global orchestrator.

---

## File inventory

| action | path | purpose |
|--------|------|---------|
| modify | `docs/ai_reports/documentation_normalization_closure_report.md` | Final closure report with corrected removed/rewritten/remaining state. |

## Class/function inventory

**None** created by this tactical task.

## Data structures

**None**.

## Import map

**N/A**.

## Error handling map

**N/A** beyond specialist verdict handling.

## Config dependency

**None** directly; this task reports previously documented example env vars rather than introducing new ones.

## Test plan

| agent | verification | expectation |
|-------|--------------|-------------|
| `researcher_code` | API/docs/example alignment | PASS or exact file-path mismatches |
| `researcher_doc` | doc/link/governance coherence | PASS or exact file-path mismatches |
| `tester_auto` | `pytest`, lint, type gates | PASS with exact command list |
| `doc_writer` | closure report update | file exists and reflects actual repo state |

## Concrete examples

- Output report must list removed legacy docs separately from the preserved active tactical subtree `docs/tech_spec/branches/documentation_normalization/`.
- Output report must state that `examples/canonical_mtls_localhost_8001.py` is the canonical real-server `localhost:8001` + `mTLS` + `mtls_certificates` example and explain the `CANONICAL_EMBED_FILE_SERVER_PATH` contract.

## Algorithm / logic description

1. Gather code-alignment evidence from `researcher_code`.
2. Gather documentation/link evidence from `researcher_doc`.
3. Gather validation verdict from `tester_auto`.
4. If any evidence is FAIL, correct affected docs and repeat verification for the changed scope.
5. When all evidence is acceptable, update the closure report and verify its content on disk.

## Forbidden approaches

- Do not close the branch without a real `tester_auto` PASS.
- Do not describe `docs/tech_spec/` as fully removed while the active tactical subtree remains.
# Tactical task DN-04: Documentation alignment verification and closure report

## Purpose

Run the specialist verification chain to prove documentation/code alignment after DN-01–DN-03, and produce the **closure report** required by the global step: lists of removed/rewritten/added docs, how the canonical mTLS example is positioned in final user documentation, and residual risks for release publication.

## Parent links

| Document | Path |
|----------|------|
| Global step | `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md` |
| Epic | `docs/specs/server_client_convergence_and_release/spec.md` |

## Scope

**Included**

- **`researcher_code`**: Grep-based verification: no `EmbeddingServiceAsyncClient`, `async_client`, `adapter_transport`, `testing_client` in surviving user-facing paths (`README.md`, `CONFIGURATION.md`, `CLI_README.md`, `examples/**`, `docs/*.md` excluding `docs/ai_reports/**`, `docs/specs/server_client_convergence_and_release/**`); confirm `pyproject.toml` `[project]` text matches public API keywords; confirm `examples/canonical_mtls_localhost_8001.py` documents `CANONICAL_EMBED_FILE_SERVER_PATH` if implemented.
- **`researcher_doc`**: Link check for broken references to deleted trees; consistency of `docs/PROJECT_RULES.md` with actual `docs/` layout after DN-01.
- **`tester_auto`**: Run full `pytest`, linters, typecheck per project rules (`CR-007`); report verdict.
- **`doc_writer`**: Write closure report file `docs/ai_reports/documentation_normalization_closure_report.md` with sections:
  1. Removed paths (from DN-01 and any additional deletes)
  2. Rewritten paths (DN-02, DN-03)
  3. Added paths (if any)
  4. Canonical mTLS example: file path, env vars, user doc entry points (README, CONFIGURATION, examples README), relationship to `tests/test_canonical_mtls_example.py`
  5. Blockers / residual risks (e.g. PyPI long description drift, optional real-server-only validation)
  6. Subordinate agents state table

**Excluded**

- Implementing DN-01–DN-03 content (completed by prior tasks).

## Boundaries

- Tactical orchestrator **does not** run tests or grep personally; **tester_auto** and **researcher_*** produce evidence.

## Dependencies

- **DN-01, DN-02, DN-03** complete (all file writes merged).

## Parallelization note

- **researcher_code** and **researcher_doc** may run in parallel; **tester_auto** after code changes from DN-03; **doc_writer** after evidence packets received.

## Expected outcome

1. Verdict: **PASS** or **FAIL** with concrete file:line defects.
2. Closure report on disk at `docs/ai_reports/documentation_normalization_closure_report.md`.
3. No unresolved broken links in governance files (or listed as residual risk with ticket).

## Correction items

- If verification fails, open corrective atomic steps via **planner_auto** brief to **coder_auto** / **doc_writer**, then re-run **tester_auto**.

## Questions / escalation rule

- Release-blocking mismatch between docs and code → escalate **global orchestrator** with **researcher_code** evidence.

---

## File inventory

| action | path | purpose |
|--------|------|---------|
| create | `docs/ai_reports/documentation_normalization_closure_report.md` | Closure report (doc_writer). |
| modify | none expected | Verification only |

## Class/function inventory

**None.**

## Data structures

**None.**

## Import map

**N/A**

## Error handling map

**N/A**

## Config dependency

**None.**

## Test plan

| agent | action |
|-------|--------|
| `tester_auto` | `pytest` full suite; ruff/flake8/mypy per repo |
| `researcher_code` | grep legacy symbols |
| `researcher_doc` | markdown link sanity / governance coherence |

## Concrete examples

- Closure report excerpt: “Removed: `docs/tech_spec/` (N files), `docs/specs/tech_spec/` (M files), …”

## Algorithm / logic description

1. Confirm DN-01–DN-03 merges on default branch.
2. Parallel: `researcher_code` grep packet; `researcher_doc` link packet.
3. `tester_auto` full run.
4. `doc_writer` synthesize closure report from task outcomes + evidence.
5. Tactical orchestrator reviews report completeness; if large, report path only to parent (already materialized as named file).

## Forbidden approaches

- Do not claim PASS without **tester_auto** transcript/summary.
- Do not omit “removed docs” list even if deletion was in DN-01.
