# Tactical task DN-03: Secondary guides, examples, and canonical mTLS completeness

## Purpose

Normalize the remaining user-facing guides under `docs/` and the surviving example set so that examples are first-class operational documentation aligned with `embed_client.EmbeddingClient`, with `examples/canonical_mtls_localhost_8001.py` positioned as the canonical real-server `localhost:8001` + `mTLS` + `mtls_certificates` end-to-end example and with the `embed_file` contract documented explicitly.

## Parent links

| Document | Path |
|----------|------|
| Epic | `docs/specs/server_client_convergence_and_release/spec.md` |
| Global step | `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md` |
| Server reference | `../embed/docs/CLIENT_DEVELOPER_GUIDE.md` |
| Cleanup closure | `docs/ai_reports/tests_scripts_and_dependency_cleanup_closure_report.md` |

## Scope

**Included**

- `docs/client_integration_guide.md`, `docs/api_format.md`, `docs/SERVER_MODES_AND_CLIENT.md`: align narrative with `EmbeddingClient`, queue/status behavior, JSON-RPC usage, security modes, and the migrated package.
- `examples/README.md`: canonical mTLS tour must be the first example entry.
- `examples/async_testing_client_example.py`, `examples/security_examples.py`, `examples/security_examples_ru.py`: examples and module docstrings updated for the migrated package.
- `embed_client/example_async_usage.py`, `embed_client/example_async_usage_demo.py`, `embed_client/example_async_usage_ru.py`, `embed_client/example_async_usage_ru_demo.py`: help text and guide links aligned with surviving docs.
- `examples/canonical_mtls_localhost_8001.py`: dry/live behavior documented; `RUN_CANONICAL_MTLS_E2E` required for live run; `CANONICAL_EMBED_FILE_SERVER_PATH` explicitly documents the precondition for `embed_file`.
- `tests/test_canonical_mtls_example.py`: verification of canonical example behavior, including `embed_file` skip/call contract.

**Excluded**

- Root product docs and `pyproject.toml` rewrite (DN-02).
- Legacy tree deletion and governance cleanup (DN-01).

## Boundaries

- Do **not** change `EmbeddingClient` public API.
- Do **not** claim `embed_file` always runs without a server-visible input path.
- Do **not** present legacy examples as still supported.

## Dependencies

- DN-02 root docs terminology established.

## Parallelization note

- Parallel with DN-02 once shared terminology is aligned; serial only for cross-links that point back into README/CONFIGURATION.

## Expected outcome

1. Surviving guides and examples are free of legacy support narrative.
2. `examples/canonical_mtls_localhost_8001.py` is a first-class user entry point.
3. `embed_file` is documented honestly via explicit precondition/environment-variable contract.

## Correction items

- Legacy references in `examples/README.md` and guide files had to be removed.
- The canonical example needed explicit `embed_file` representation to satisfy the global step requirement.

## Questions / escalation rule

- If the canonical example cannot safely cover `embed_file` under the documented precondition, escalate to the global orchestrator.

---

## File inventory

| action | path | purpose |
|--------|------|---------|
| modify | `docs/client_integration_guide.md` | Main user integration narrative. |
| modify | `docs/api_format.md` | Current JSON-RPC / result narrative. |
| modify | `docs/SERVER_MODES_AND_CLIENT.md` | Security-mode guidance. |
| modify | `examples/README.md` | Canonical example promoted to section 1. |
| modify | `examples/async_testing_client_example.py` | Example/help text alignment. |
| modify | `examples/security_examples.py` | Security example docs alignment. |
| modify | `examples/security_examples_ru.py` | Same in Russian where file already exists. |
| modify | `embed_client/example_async_usage.py` | Current guide links and example help text. |
| modify | `embed_client/example_async_usage_demo.py` | Supporting demo text alignment. |
| modify | `embed_client/example_async_usage_ru.py` | Russian example help alignment. |
| modify | `embed_client/example_async_usage_ru_demo.py` | Russian demo text alignment. |
| modify | `examples/canonical_mtls_localhost_8001.py` | Canonical mTLS + `embed_file` contract. |
| modify | `tests/test_canonical_mtls_example.py` | Canonical example behavior verification. |

## Class/function inventory

- `embed_client.EmbeddingClient` — base class `None`; user-facing client documented across guides.
  - `embed_file(...) -> Dict[str, Any]`: documented with explicit server-visible path precondition.
- `examples.canonical_mtls_localhost_8001.build_mtls_localhost_8001_config(...) -> Dict[str, Any]`: builds the localhost:8001 mTLS config using repository certificates.
- `examples.canonical_mtls_localhost_8001` runner functions: dry/live execution helpers must mention `RUN_CANONICAL_MTLS_E2E` and `CANONICAL_EMBED_FILE_SERVER_PATH`.

## Data structures

- Environment variable `RUN_CANONICAL_MTLS_E2E`: string flag; live real-server execution is enabled when set to a truthy value expected by the script.
- Environment variable `CANONICAL_EMBED_FILE_SERVER_PATH`: string; optional server-visible path for the canonical `embed_file` step. Empty/unset means explicit skip with documented message.

## Import map

Relevant files use existing imports only; the documented canonical example must include:

- `from embed_client import EmbeddingClient`
- `from pathlib import Path`
- `import os`

## Error handling map

- Missing certificate files: `FileNotFoundError`; script/docstring must explain that certificates come from `mtls_certificates`.
- Example transport/API failures: current `embed_client.exceptions` classes; documentation must not mention deleted exceptions.

## Config dependency

- `RUN_CANONICAL_MTLS_E2E`: live-run gate for the canonical example.
- `CANONICAL_EMBED_FILE_SERVER_PATH`: optional `embed_file` contract.

## Test plan

| file | test / verification | expectation |
|------|---------------------|-------------|
| `examples/canonical_mtls_localhost_8001.py` | `tests/test_canonical_mtls_example.py` | dry run, live mock path, `embed_file` skip/call behavior |
| Guides / example readmes | `researcher_doc` | canonical example is primary entry point |
| Example modules | `researcher_code` | no legacy support narrative beyond explicitly deprecated context if retained |

## Concrete examples

- Input: `RUN_CANONICAL_MTLS_E2E=1`, `CANONICAL_EMBED_FILE_SERVER_PATH=/data/sample.txt`. Output: canonical script includes `embed_file` step using a server-visible path.
- Input: `RUN_CANONICAL_MTLS_E2E=1`, `CANONICAL_EMBED_FILE_SERVER_PATH` unset. Output: script explicitly reports that `embed_file` is skipped unless the environment variable is provided.

## Algorithm / logic description

1. Re-anchor guides and examples on `EmbeddingClient`.
2. Promote the canonical localhost:8001 mTLS example into the first user-facing example positions.
3. Document the `embed_file` precondition explicitly instead of implying universal availability.
4. Keep tests aligned with the documented example contract.

## Forbidden approaches

- Do not hide the `embed_file` precondition.
- Do not leave the canonical example as a secondary example.
- Do not describe removed legacy clients as supported workflows.
# Tactical task DN-03: Secondary guides, examples as first-class docs, canonical mTLS completeness

## Purpose

Rewrite remaining user-facing guides under `docs/`, normalize `examples/` and `embed_client/example_*.py` so examples are first-class operational documentation with man-page-level module docstrings, align `docs/client_integration_guide.md`, `docs/api_format.md`, and `docs/SERVER_MODES_AND_CLIENT.md` with `EmbeddingClient`, and close the gap between epic exit criteria (“all supported client capabilities in one operational flow”) and the current `examples/canonical_mtls_localhost_8001.py` behavior regarding `embed_file`.

## Parent links

| Document | Path |
|----------|------|
| Epic | `docs/specs/server_client_convergence_and_release/spec.md` |
| Global step | `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md` |
| Server reference (quality bar) | `../embed/docs/CLIENT_DEVELOPER_GUIDE.md` (read-only; path outside repo) |
| Prior wave handoff | `docs/ai_reports/tests_scripts_and_dependency_cleanup_closure_report.md` |

## Scope

**Included**

- `docs/client_integration_guide.md`: replace `EmbeddingServiceAsyncClient` with `EmbeddingClient`; align sections to mirror server guide topics listed in `researcher_doc` report (Overview, initialization, embedding, queue polling, job status, error handling, API reference, troubleshooting) with **imports** from `embed_client`.
- `docs/api_format.md`: ensure JSON-RPC / result shapes described match `EmbeddingClient` usage (no adapter-only paths).
- `docs/SERVER_MODES_AND_CLIENT.md`: align security modes with deploy matrix and `examples/security_examples.py` patterns.
- `examples/README.md`: first entry = canonical `canonical_mtls_localhost_8001.py`; remove `EmbeddingServiceAsyncClient` snippets; table of other examples.
- `embed_client/example_async_usage.py`, `example_async_usage_demo.py`, `example_async_usage_ru.py`, `example_async_usage_ru_demo.py`: docstrings and inline help reference updated guides; no broken links to removed paths.
- `examples/async_testing_client_example.py`, `examples/security_examples.py`, `examples/security_examples_ru.py`: man-page-level module docstrings where missing; terminology `EmbeddingClient` only.
- **`examples/canonical_mtls_localhost_8001.py`**: extend so the **single runnable flow** exercises **all** public capabilities that are safe to call against a real server, including **`embed_file`** when an environment variable provides a **server-visible** input path (decision locked below). When the variable is unset, run a **documented dry skip** that still prints the exact `embed_file` call signature users would use (so documentation + code stay honest). **coder_auto** implements; **doc_writer** keeps docstring and README sections in sync.
- Cross-links: `embed_client/example_async_usage.py` references to `docs/client_integration_guide.md` must resolve post-rewrite.

**Excluded**

- Root `README.md` / `pyproject.toml` (DN-02) except cross-link consistency.
- Legacy tree deletion (DN-01).

## Boundaries

- Do **not** change `EmbeddingClient` public API in this task (if doc reveals a bug, escalate to **global orchestrator** / release branch).
- Do **not** add Russian prose to new English docs unless file already bilingual (follow `ARTIFACT_LOCALE` / repo rules).

## Dependencies

- **DN-02** should expose stable README anchors for canonical example (soft dependency — can use fixed paths).
- **DN-01** complete before editing `project_overlay` final cross-links if DN-01 touched it (coordinate).

## Parallelization note

- **Parallel with DN-02** once DN-01 has removed conflicting paths (or confirmed no link to deleted trees).

## Expected outcome

1. No `EmbeddingServiceAsyncClient` in user-facing `docs/` or `examples/` (grep-verified in DN-04).
2. Canonical example is referenced from root README (DN-02) and `examples/README.md` as **the** full tour.
3. `embed_file` is either executed in the canonical flow (when env provides server path) or explicitly documented with env contract and skip behavior — satisfying “complete capability” narrative without hiding `embed_file`.
4. Example modules meet man-page-level docstring standard (module-level: purpose, prerequisites, env vars, exit codes, links to tests).

## Correction items

- `researcher_code`: `examples/README.md` still contains legacy client name — **rewrite required**.
- `researcher_doc`: exit criterion “all capabilities in one flow” vs missing `embed_file` — **resolve via env-gated `embed_file` in canonical script**.

## Questions / escalation rule

- If real-server `embed_file` cannot be automated safely in CI, escalate **test strategy** to **global orchestrator** (e.g. keep mocked path only in CI).

---

## File inventory

| action | path | purpose |
|--------|------|---------|
| modify | `docs/client_integration_guide.md` | Integration narrative for `EmbeddingClient`. |
| modify | `docs/api_format.md` | API contract documentation. |
| modify | `docs/SERVER_MODES_AND_CLIENT.md` | Security modes vs client. |
| modify | `examples/README.md` | Example index; canonical first. |
| modify | `examples/async_testing_client_example.py` | Docstrings / imports. |
| modify | `examples/security_examples.py` | Docstrings / patterns. |
| modify | `examples/security_examples_ru.py` | Same (Russian). |
| modify | `embed_client/example_async_usage.py` | Help text and guide links. |
| modify | `embed_client/example_async_usage_demo.py` | Demo helpers docstrings. |
| modify | `embed_client/example_async_usage_ru.py` | RU CLI docstrings. |
| modify | `embed_client/example_async_usage_ru_demo.py` | RU demo helpers. |
| modify | `examples/canonical_mtls_localhost_8001.py` | Optional `embed_file` + docstring updates. |
| modify | `tests/test_canonical_mtls_example.py` | Adjust expectations if new env branch added (`coder_auto` + `tester_auto`). |

## Class/function inventory

**Python (for docstrings and optional code paths only)**

- `embed_client.embedding_client.EmbeddingClient.embed_file(...)` — public; must appear in canonical flow when env set.
- Existing functions in `examples/canonical_mtls_localhost_8001.py` per file (e.g. `build_mtls_localhost_8001_config`, `run_*`) — extend with `embed_file` step **without** renaming public CLI of the script.

## Data structures

- Environment variable: **`CANONICAL_EMBED_FILE_SERVER_PATH`** (string, optional). When set to a non-empty string, canonical script calls `embed_file` with that path as `input_file` (and documents that it must be visible to the server). When unset, script logs skip and lists the env var name.

## Import map

- `from embed_client import EmbeddingClient`
- `from pathlib import Path`
- `import os`
- Standard logging if already in file

## Error handling map

| situation | exception | behavior |
|-----------|-----------|----------|
| Missing certs | `FileNotFoundError` | Already in builder — document in module docstring. |
| `embed_file` fails | `EmbedClientError` / subclasses | Catch in example script, print structured message, non-zero exit optional — match existing script style. |

## Config dependency

- None beyond env vars already used (`RUN_CANONICAL_MTLS_E2E`, new `CANONICAL_EMBED_FILE_SERVER_PATH`).

## Test plan

| test file | asserts |
|-----------|---------|
| `tests/test_canonical_mtls_example.py` | Dry-run still passes; if tests mock `embed_file`, add case for env branch or document skip in test docstring. |
| `tester_auto` | Full `pytest` + linters |

## Concrete examples

- **Input:** `RUN_CANONICAL_MTLS_E2E=1`, `CANONICAL_EMBED_FILE_SERVER_PATH=/data/sample.txt`  
- **Expected:** script calls `embed_file(input_file="/data/sample.txt", ...)` after other steps, logs job id, respects wait semantics.

- **Input:** `CANONICAL_EMBED_FILE_SERVER_PATH` unset  
- **Expected:** script prints single banner line: `embed_file skipped; set CANONICAL_EMBED_FILE_SERVER_PATH to a server-visible path to include embed_file in this tour.`

## Algorithm / logic description (canonical script extension)

1. After existing steps (health, models, embed, queue, etc.), read `CANONICAL_EMBED_FILE_SERVER_PATH`.
2. If set, call `client.embed_file(...)` with documented kwargs consistent with server (wait True, reasonable timeout).
3. If unset, print skip message (not silent).
4. Update module docstring to list **all** public methods touched in order.

## Forbidden approaches

- Do not reintroduce `EmbeddingServiceAsyncClient`.
- Do not claim full E2E without mentioning `embed_file` or the env gate.
- Do not hardcode user-local paths like `/home/...` in committed docs.
