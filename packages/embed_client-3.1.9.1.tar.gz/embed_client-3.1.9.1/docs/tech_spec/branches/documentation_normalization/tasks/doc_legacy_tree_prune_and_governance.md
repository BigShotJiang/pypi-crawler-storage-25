# Tactical task DN-01: Legacy documentation tree prune and governance alignment

## Purpose

Remove obsolete, duplicate, speculative, and adapter-centric documentation trees that contradict the canonical migrated `embed_client.EmbeddingClient` implementation, and update governance documents so `docs/PROJECT_RULES.md` and agent overlays describe a single coherent layout without pointing to deleted subtrees as active program-of-record.

## Parent links

| Document | Path |
|----------|------|
| Epic | `docs/specs/server_client_convergence_and_release/spec.md` |
| Global plan | `docs/specs/server_client_convergence_and_release/plan.md` |
| Global step | `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md` |
| Baseline doc evidence | `docs/ai_reports/baseline_audit_doc_research.md` |
| Production migration handoff | `docs/ai_reports/production_migration_completion_report.md` |

## Scope

**Included**

- Delete entire directory tree `docs/specs/tech_spec/` (full subtree).
- Under `docs/tech_spec/`, delete **all** legacy content **except** the preserved tactical branch `docs/tech_spec/branches/documentation_normalization/` (this branch’s tasks and README must survive DN-01 so planning artifacts are not destroyed). Remove other `docs/tech_spec/branches/*` directories, root files (`tech_spec.md`, `implementation_plan.md`, `CROSS_DOCUMENT_COHERENCE_AUDIT.md`), and `docs/tech_spec/steps/`.
- Delete session-adjacent or obsolete root-level docs under `docs/`:
  - `docs/performance_test_results.md` (references `EmbeddingServiceAsyncClient`, `testing_client.py` per `researcher_code` grep evidence)
  - `docs/TEST_SUITE_HANG_ANALYSIS.md` (adapter transport tests per baseline §2.2)
- Evaluate and delete or fold: `docs/specs/client_server_alignment_migration/remove_legacy_and_normalize_verification/legacy_cleanup_and_verification/spec.md` if parent epic folder is absent and fragment is orphaned (confirm with `researcher_doc` one-liner before delete).
- Modify `docs/PROJECT_RULES.md`: **LAYOUT-08** / **LAYOUT-09** — replace pointers to deleted `docs/tech_spec/` as active legacy spec with a single statement that technical program-of-record for the migrated client is the epic under `docs/specs/server_client_convergence_and_release/` and code; remove claims that `docs/specs/tech_spec/` mirrors `docs/tech_spec/` if both are removed.
- Modify `docs/agents/project_overlay.md`: remove adapter-centric client description, `pytest.ini` references (pytest config lives in `pyproject.toml` per cleanup closure), and paths to deleted trees; add pointer to canonical user docs and `examples/canonical_mtls_localhost_8001.py` after DN-03 completes (coordinate: minimal placeholder in DN-01, finalize cross-links when DN-03 lands).

**Excluded**

- Epic specs under `docs/specs/server_client_convergence_and_release/**` (keep).
- `docs/specs/_template/**` (keep per governance).
- `docs/ai_reports/**` (keep as historical evidence; do not delete completion reports).
- Root `README.md`, `CONFIGURATION.md`, `CLI_README.md` (DN-02).
- `examples/**` content rewrites (DN-03).

## Boundaries

- Do **not** delete `docs/specs/server_client_convergence_and_release/**`.
- Do **not** delete `docs/PROJECT_RULES.md`, `docs/agents/universal_project_context.md`, `docs/agents/common_agent_rules.md`, `docs/agents/README.md`, `docs/agents/MAINTAINERS.md` — only update where listed.
- Do **not** reintroduce backward-compatibility narrative for removed APIs.

## Dependencies

**none** (parallel with DN-02 after repo-wide grep for cross-links — if `grep` shows README-only links, DN-01 can run first; preferred order: **DN-01 before DN-02** so root docs do not link to deleted paths).

## Parallelization note

- **Serial with DN-02:** DN-01 should complete **before** DN-02 finalizes README links if README currently points into `docs/tech_spec/`.
- **Parallel with DN-03** only after file inventory confirms no overlapping paths (DN-03 touches `project_overlay` finalize — use checkpoint after DN-01).

## Expected outcome

1. Listed obsolete trees/files are absent from disk.
2. `docs/PROJECT_RULES.md` contains no stale references to deleted paths as authoritative.
3. `docs/agents/project_overlay.md` reflects `EmbeddingClient`-centric package layout and current test configuration location.
4. No broken internal links from remaining governance files to deleted subtrees (verified by `researcher_doc` in DN-04).

## Correction items

- If `git grep` finds remaining references to `docs/tech_spec/` or `docs/specs/tech_spec/` in surviving files after prune, add follow-up file list to DN-02/DN-03.

## Questions / escalation rule

- If legal/compliance requires retaining **historical** technical specs for audit, **stop** and escalate to **global orchestrator** to choose **archive tarball** vs **git branch** vs **delete** — tactical default per epic is **delete duplicate legacy spec trees** in the repo working tree.

---

## File inventory

| action | path | purpose |
|--------|------|---------|
| delete | `docs/specs/tech_spec/` (entire tree) | Superseded adapter-centric program-of-record (baseline audit). |
| delete | `docs/tech_spec/**` **except** `docs/tech_spec/branches/documentation_normalization/**` | Remove duplicate legacy tree while preserving this global step’s tactical artifacts. |
| delete | `docs/performance_test_results.md` | Stale client references. |
| delete | `docs/TEST_SUITE_HANG_ANALYSIS.md` | Stale adapter transport analysis. |
| delete | `docs/specs/client_server_alignment_migration/remove_legacy_and_normalize_verification/legacy_cleanup_and_verification/spec.md` | Orphan fragment — only if parent spec missing (verify first). |
| modify | `docs/PROJECT_RULES.md` | LAYOUT-08/09 coherence after deletes. |
| modify | `docs/agents/project_overlay.md` | Remove legacy architecture; fix pytest pointer. |

## Class/function inventory

**None** — documentation and governance only; no Python production modules.

## Data structures

**None.**

## Import map

**N/A** (markdown only).

## Error handling map

**N/A.**

## Config dependency

**None.**

## Test plan

| test file | test name | asserts |
|-------------|-----------|---------|
| N/A for markdown-only deletes | — | `tester_auto`: repo still passes `pytest` if no code changed; if any test referenced deleted path, `coder_auto` fixes test in sibling task. |

**researcher_doc** (DN-04): grep for broken `](docs/tech_spec` / `docs/specs/tech_spec` links in repo.

## Concrete examples

- **Before:** `docs/PROJECT_RULES.md` lists `docs/tech_spec/` as legacy — **After:** states that pre-epic technical spec trees were removed; canonical planning is `docs/specs/server_client_convergence_and_release/`.

## Algorithm / logic description

1. List `docs/specs/tech_spec` and `docs/tech_spec` top-level files for record (optional changelog line in closure report).
2. Delete both trees and listed files.
3. Search `docs/PROJECT_RULES.md` and `docs/agents/project_overlay.md` for removed paths.
4. Rewrite sections to remove dead links and state epic + code as authority.
5. If `tests/` or `README.md` reference deleted paths, open corrective task to DN-02/DN-03.

## Forbidden approaches

- Do not delete `docs/specs/server_client_convergence_and_release/**`.
- Do not partially delete `docs/tech_spec/branches/` without deleting the full duplicate policy per baseline — avoids half-broken trees.
- Do not use “compatibility shims” in documentation for removed APIs.
