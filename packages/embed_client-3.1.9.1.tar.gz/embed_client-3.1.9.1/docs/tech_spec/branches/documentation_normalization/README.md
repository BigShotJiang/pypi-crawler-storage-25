<!--
Tactical branch for global step documentation_normalization.
Author: tactical orchestrator (epic server_client_convergence_and_release).
-->

# Branch: `documentation_normalization`

## Parent links

| Document | Path |
|----------|------|
| Epic | `docs/specs/server_client_convergence_and_release/spec.md` |
| Global plan | `docs/specs/server_client_convergence_and_release/plan.md` |
| Global step | `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md` |
| Legacy tech spec | `docs/specs/tech_spec/` removed by DN-AT-01; `docs/tech_spec/` pruned to **only** `branches/documentation_normalization/` |

## Tactical tasks (this branch)

| ID | File | Summary |
|----|------|---------|
| DN-01 | `tasks/doc_legacy_tree_prune_and_governance.md` | Remove obsolete/duplicate doc trees and session artifacts; align `docs/PROJECT_RULES.md` LAYOUT-08/09 pointers. |
| DN-02 | `tasks/doc_root_metadata_and_pypi_surface.md` | Rewrite `README.md`, `CONFIGURATION.md`, `CLI_README.md`; align `pyproject.toml` `[project]` narrative with `EmbeddingClient` and real dependencies. |
| DN-03 | `tasks/doc_guides_examples_canonical_mtls.md` | Rewrite secondary guides; normalize `examples/` and `embed_client/example_*.py`; core user placement for canonical mTLS; optional `embed_file` in canonical flow per evidence. |
| DN-04 | `tasks/doc_alignment_verification_and_closure.md` | Specialist verification chain and closure report artifact. |

## Atomic steps

Materialized under `docs/specs/server_client_convergence_and_release/documentation_normalization/steps/` (`ATOMIC_STEPS_INDEX.md`, `DN-AT-01.md` … `DN-AT-22.md`).

## Evidence consolidated (2026-03-30)

- `docs/ai_reports/baseline_audit_doc_research.md`
- `docs/ai_reports/baseline_audit_code_research.md`
- `docs/ai_reports/production_migration_completion_report.md`
- `docs/ai_reports/tests_scripts_and_dependency_cleanup_closure_report.md`
- Subordinate runs: `researcher_code` (API inventory, grep legacy symbols, canonical example gap), `researcher_doc` (exit-criteria gap analysis, delete/keep/rewrite table).

## Subordinate agents state (template)

| Agent | Status | Scope |
|-------|--------|--------|
| `researcher_code` | Done (pre-tactical evidence) | Post-migration API, example inventory, legacy grep |
| `researcher_doc` | Done (pre-tactical evidence) | Gap vs exit criteria, delete/rewrite map |
| `planner_auto` | Done | 22 atomic steps + index under `documentation_normalization/steps/` |
| `doc_writer` | Pending | Markdown rewrites per DN-AT-02–18, DN-AT-21–22; pair with `coder_auto` on DN-AT-01 deletes if needed |
| `coder_auto` | Pending | DN-AT-01 (filesystem), DN-AT-07 (`pyproject.toml`), DN-AT-12–20 (Python); then `tester_auto` |
| `tester_auto` | Pending | After `coder_auto` / `doc_writer` merge: `pytest`, linters, `CR-007` |
