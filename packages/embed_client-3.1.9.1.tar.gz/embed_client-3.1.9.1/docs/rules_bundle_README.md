<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# Подключение проекта к шаблону правил и субагентов

Этот файл — руководство по подключению. В архиве **`rules_template.zip`** он лежит как **`rules_template/README.md`**. В репозитории-источнике шаблона тот же текст обычно хранят как **`docs/rules_bundle_README.md`** и при сборке бандла копируют в корень **`rules_template/README.md`**.

Бандл **`rules_template/`** — переносимое дерево: **`docs/PROJECT_RULES.md`** (идентификаторы `CR-*`, `LAYOUT-*`, `NAME-*`), общий контекст агентов в **`docs/agents/`**, роли субагентов в **`.cursor/agents/*.md`**, правило Cursor **`.cursor/rules/project_canonical.mdc`**, каркас ТЗ в **`docs/specs/_template/`**.

---

## Справочник плейсхолдеров

Подставьте реальные значения вместо угловых скобок и проверьте, что в репозитории не осталось «сырых» токенов.

| Плейсхолдер | Где заменить |
|-------------|----------------|
| `<PROJECT_SLUG>` | §0 в `docs/PROJECT_RULES.md` (`PROJECT_SLUG`); заголовок в `docs/agents/project_overlay.md`; каталог пакета, если он совпадает со slug |
| `<Name>` | §0 (`HEADER_AUTHOR`); опционально HTML-комментарии `Author:` в шапках `.md` |
| `<email>` | §0 (`HEADER_EMAIL`); опционально в тех же шапках |
| `PACKAGE_ROOT` | §0 — путь к продакшен-коду от корня репо (часто подкаталог с тем же именем, что и `PROJECT_SLUG`) |
| Строки *italic* в `project_overlay.md` | Раздел **Functional context** — одна строка о продукте, тесты, пути |

Детали идентификаторов профиля — в **`docs/PROJECT_RULES.md` §0** и подсекции **Placeholder tokens** там же.

---

## Содержимое бандла

```text
rules_template/
  README.md                 ← этот файл
  docs/
    PROJECT_RULES.md
    projectid.example.json  ← образец для CR-003 (если включите projectid)
    agents/
      universal_project_context.md
      common_agent_rules.md
      project_overlay.md      ← заготовка; замените под продукт
      README.md
      MAINTAINERS.md
    specs/_template/          ← копия → docs/specs/<имя_спека>/
  .cursor/
    rules/project_canonical.mdc
    agents/*.md               ← роли субагентов
```

---

## Новый репозиторий

1. Распакуйте архив в **корень** нового репо **или** скопируйте каталог `rules_template/` так, чтобы на верхнем уровне оказались `docs/` и `.cursor/` (слить с пустыми папками, не вкладывать `rules_template/rules_template/`).
2. Заполните **`docs/PROJECT_RULES.md` §0** (профиль проекта). При необходимости добавьте **§7** с теми же ключами или оставьте только §0.
3. Замените заготовку **`docs/agents/project_overlay.md`**: роль продукта, пути к пакету, тестам, специфичные каталоги.
4. Проставьте плейсхолдеры в шапках файлов (см. таблицу выше), если используете **CR-012**.
5. Создайте каталоги из **LAYOUT-*** при необходимости: `tests/`, `scripts/`, `logs/`, `configs/`, `docs/ai_reports/`, `docs/specs/` (см. §3 в `PROJECT_RULES.md`).
6. Настройте **Cursor** (следующий раздел).
7. Инициализируйте окружение (**CR-005**, **CR-007**): venv, линтеры из профиля.

---

## Существующий репозиторий

1. **Сделайте коммит или ветку** перед слиянием.
2. Скопируйте содержимое `rules_template/` в корень целевого репо:
   - **`.cursor/rules/`** и **`.cursor/agents/`** — объединить с уже существующими файлами; при конфликте имён решите вручную (часто выгодно **сохранить шаблон** для `project_canonical.mdc` и ролей, если старые карточки не использовались).
   - **`docs/agents/`** — добавьте файлы из бандла; если уже есть `PROJECT_RULES.md`, сравните: идентификаторы `CR-*` лучше не переименовывать; объедините §0 с вашими реальными значениями.
   - **`docs/specs/_template/`** — добавьте, если папки ещё не было.
3. Если в проекте уже был **`docs/PROJECT_RULES.md`**, перенесите в него строки из §0 шаблона и сохраните ваши локальные дополнения; не дублируйте противоречивые правила.
4. Заполните **`project_overlay.md`** под ваш продукт (не оставляйте заголовок с `<PROJECT_SLUG>`).
5. Проверьте ссылки в **`docs/agents/README.md`** и в **`universal_project_context.md`**.
6. Настройте Cursor (ниже).

---

## Привязка в Cursor (правила и субагенты)

### Правила проекта

1. Убедитесь, что в репозитории есть **`.cursor/rules/project_canonical.mdc`** — он ссылается на **`docs/PROJECT_RULES.md`** и на **`docs/agents/`** (короткий указатель, **always apply**).
2. В настройках Cursor (**Rules / Project Rules**, название может меняться в версиях IDE) добавьте ссылку или правило вида: *следовать `docs/PROJECT_RULES.md` и заполненному §0/§7*.
3. В **User Rules** (глобально) достаточно одной строки-напоминания, если файлы проекта всегда подхватываются — см. **§6** в `PROJECT_RULES.md`.

### Субагенты: файлы и роли

Файлы лежат в **`.cursor/agents/*.md`**. В начале каждого файла — блок **контекстных документов** (ссылки на `docs/agents/...`); **его нужно сохранять** при правках.

| Файл | Назначение (кратко) |
|------|---------------------|
| `orchestrator.md` | Активное ведение эпика: ТЗ/глобальные шаги структурируют работу; сам вызывает `orchestrator_tactical` (не перекладывает запуск на пользователя); параллель тактических веток ≤ числа глобальных шагов (**CR-016** внутри этого предела) |
| `orchestrator_tactical.md` | Тактический уровень под `orchestrator` |
| `orchestrator_debug.md`, `orchestrator_tactical_debug.md` | То же для небольших задач **без** формального дерева в `docs/specs/` |
| `planner_auto.md` | Разбиение на атомарные шаги |
| `coder_auto.md` | Реализация кода по шагам |
| `tester_auto.md` | Проверка и тесты |
| `researcher_code.md`, `researcher_doc.md` | Исследование кода и документации |
| `doc_writer.md` | Тексты и документация |

Оркестраторы **не** пишут код сами — см. **`docs/agents/common_agent_rules.md`** (в т.ч. про «конверт» инструментов и иерархию).

Как **вызвать** роль: в интерфейсе агента Cursor выберите соответствующий субагент / режим с тем же именем, что у файла (без `.md`), или опишите задачу так, чтобы модель загрузила нужный файл из **`.cursor/agents/`** (в зависимости от версии продукта — через список агентов, `@`-ссылку на файл или инструкцию пользователя «работай по роли `coder_auto`»).

### Индексация и MCP

- Если в §0 **`USE_CODE_MAP` = yes**, после крупных структурных изменений обновляйте индекс (**CR-006**), как принято в проекте (`code_mapper` → `code_analysis/` и т.п.).
- Расширенные правила (MCP, журналы) — опционально через **`docs/assistant_rules_inventory.md`**, если добавите его из зрелого репо.

---

## ТЗ, `projectid`, спеки

- **ТЗ и планы на диске:** **`docs/specs/<specname>/`** (**CR-017**, **LAYOUT-09**). Каркас: скопируйте **`docs/specs/_template/`** → **`docs/specs/<ваш_спек>/`**, переименуйте slug’и.
- **`projectid`** (опционально, **CR-003**): скопируйте **`docs/projectid.example.json`** в корень репозитория как **`projectid`**, заполните UUID и описание.

---

## Проверка после внедрения

- [ ] В §0 нет незаполненных `<...>` в обязательных для вас полях.
- [ ] `project_overlay.md` описывает ваш продукт, а не заготовку.
- [ ] `.cursor/rules/project_canonical.mdc` на месте; Cursor видит `docs/PROJECT_RULES.md`.
- [ ] Выбранный стек линтеров/типизации согласован с **CR-007** (или §0 обновлён под ваш стек).
- [ ] При необходимости созданы `docs/specs/`, `docs/ai_reports/`, `tests/`, `scripts/`.

---

## Полная адаптация (расширенный чеклист)

| Шаг | Действие |
|-----|----------|
| 1 | Заполнить **`docs/PROJECT_RULES.md` §0** (и при желании §7). |
| 2 | Заменить **`docs/agents/project_overlay.md`**. |
| 3 | Обновить шапки **`docs/PROJECT_RULES.md`** (owner / email), если используете. |
| 4 | **CR-003:** при необходимости корневой **`projectid`**. |
| 5 | **Python:** `.venv` по **`VENV_DIR`**, **CR-005** / **CR-015** / **CR-007**. |
| 6 | **`USE_CODE_MAP`:** при `no` — убрать ожидания по `code_analysis/` из overlay. |
| 7 | Укоротить тела **`.cursor/agents/*.md`**, если workflow проще; **не удалять** блок контекста в шапке. |
| 8 | Создать каталоги по **LAYOUT-*** при отсутствии. |
| 9 | Новый спек: **`docs/specs/_template/`** → **`docs/specs/<name>/`**. |

---

## После слияния

Запустите тесты и линтеры один раз, чтобы убедиться, что **CR-007** выполним в вашем репо. Зафиксируйте изменения в git.

---

## Пересборка `rules_template.zip` в репозитории-источнике

Из корня репозитория, где живут актуальные правила:

```bash
cp -f .cursor/rules/project_canonical.mdc rules_template/.cursor/rules/
cp -f .cursor/agents/*.md rules_template/.cursor/agents/
cp -f docs/agents/common_agent_rules.md docs/agents/README.md \
      docs/agents/universal_project_context.md docs/agents/MAINTAINERS.md rules_template/docs/agents/
cp -f docs/PROJECT_RULES.md rules_template/docs/
# Для универсального zip: после копирования верните в rules_template/docs/PROJECT_RULES.md нейтральный §7 (без заполненной таблицы профиля конкретного продукта).
cp -f docs/rules_bundle_README.md rules_template/README.md
cp -rf docs/specs/_template rules_template/docs/specs/
cp -f docs/projectid.example.json rules_template/docs/
# Восстановите заготовку project_overlay и нейтральный §7 шаблона, если копия затёрла их:
# см. историю git или MAINTAINERS.md
```

Затем:

```bash
zip -r rules_template.zip rules_template -x "rules_template/.git/*"
```

Не используйте `-x "*.git*"` — отфильтруются файлы вроде **`scripts/.gitkeep`**.
