<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# `docs/agents/` file index

| File | Contents |
|------|----------|
| [`universal_project_context.md`](universal_project_context.md) | Map → `PROJECT_RULES.md` §0–§5. |
| [`project_overlay.md`](project_overlay.md) | This repository: extra paths, behavior, restrictions. |
| [`common_agent_rules.md`](common_agent_rules.md) | Shared rules for all hierarchy subagents. |
| [`../PROJECT_RULES.md`](../PROJECT_RULES.md) | `CR-*`, `LAYOUT-*`, `NAME-*`, §0 profile and §7 overrides for this clone. |
| [`../assistant_rules_inventory.md`](../assistant_rules_inventory.md) | Optional extended reference. |
| [`MAINTAINERS.md`](MAINTAINERS.md) | Human-only template fork steps (do not load into agents). |
| `.cursor/agents/` (repo root) | Cursor subagent definitions; includes **`orchestrator_debug`** / **`orchestrator_tactical_debug`** for work **without** `docs/tech_spec/` formal plans. |
| `spec_*.md` | Optional per-role long specs if present. |
| [`../rules_bundle_README.md`](../rules_bundle_README.md) | How to bind **`rules_template.zip`** (bootstrap `.cursor/`, `docs/agents/`, `docs/specs/_template/`, …). |
