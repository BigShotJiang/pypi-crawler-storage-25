# Acceptance retest — facts from `7d-00-48.md` + embed-client file-vectorization code

**Source constraint for the input document:** acceptance examples use the repository file  
`/home/vasilyvz/projects/embed-client/7d-00-48.md` (not sample JSON under `examples/data/`).

---

## 1. `7d-00-48.md` — existence and structure

| Property | Value |
|----------|--------|
| Path | `/home/vasilyvz/projects/embed-client/7d-00-48.md` |
| Size | **1 710 389 bytes** (~1.71 MiB) |
| Lines | **27 212** |

**Observed structure (head):** YAML-style front matter between `---` lines (`%%7d-00%%`), then a Markdown title and sections (Russian). `prepare-embed-file-json` **strips** optional YAML front matter by default (`strip_optional_yaml_front_matter` in `embed_client/md_embed_file_prep.py`).

---

## 2. Client-facing file-vectorization flow (prep → live → validate)

### 2.1 Preparation (no network)

1. **CLI:** `prepare-embed-file-json` — `embed_client/cli.py` dispatches to `prepare_markdown_cli_main` **before** `VectorizationCLI.connect()` (no server).
2. **Module:** `embed_client/md_embed_file_prep.py`
   - `prepare_markdown_cli_main(args)` → `prepare_markdown_path_to_json_file(...)`
   - Reads UTF-8 (BOM allowed), optionally strips front matter, splits body with `split_body_into_text_blocks` using `resolve_max_json_block_bytes` from `json_embed_file_preflight`
   - Writes JSON array of strings; then **`validate_local_json_embed_file`** (`embed_client/json_embed_file_preflight.py`) on the output file.

### 2.2 Live call to embedding server

1. **CLI:** `embed-file-json` → `VectorizationCLI.embed_file_local_json` (`embed_client/cli_core.py`).
2. **Preflight (same process):** `iter_json_array_block_texts(json_path)` loads ordered block strings for validation/perf counting (`json_embed_file_preflight.py`).
3. **Network path:** `EmbeddingClient.embed_file_from_local_json_file` → `embed_client/local_json_embed_file.py::embed_file_from_local_json_file`:
   - `validate_local_json_embed_file(local_path, ...)`
   - `upload_file` → `get_upload_session` → `storage_path`
   - `client.embed_file(server_input, local_source_path=..., file_format="json_array", ...)`

### 2.3 Output validation (after job completes)

- **`embed_client/embed_file_output_validate.py`**
  - `validate_embed_file_job_result(input_block_texts, embed_result, rpc_dimension=...)`
  - Uses `resolve_embed_file_output_payload` (reads `local_output_path` file or inline keys `embed_file_output` / `output_json` / nested `result`)
  - `validate_embed_file_output_against_blocks`: `success`, record count, `embedding` length vs dimension, `body` vs input order, per-row errors.

**CLI wiring:** `VectorizationCLI.embed_file_local_json` prints `format_perf_report_lines` then `format_validation_checklist_lines` to **stderr**; final JSON result to **stdout** on success (`cli_core.py`).

---

## 3. Exact entry points for acceptance (using `7d-00-48.md` literally)

Assume working directory is the repo root; paths can be absolute as below.

### (a) Prepare **from** a given `.md` path

**CLI (recommended):**

```bash
python -m embed_client prepare-embed-file-json /home/vasilyvz/projects/embed-client/7d-00-48.md \
  -o /home/vasilyvz/projects/embed-client/7d-00-48_embed_file.json
```

Default output if `-o` omitted: same directory as input, `7d-00-48_embed_file.json` (stem + `_embed_file.json`). See `prepare_markdown_cli_main` in `md_embed_file_prep.py`.

**Python API:**

- `embed_client.md_embed_file_prep.prepare_markdown_path_to_json_file(md_path, output_path, max_block_bytes=..., strip_front_matter=True, max_chunks=...)`

### (b) Live vectorization with **visible server progress**

**CLI:** WebSocket/status lines go to **stderr** when `--show-progress` is set; implementation uses `_embed_file_ws_progress_stderr` → `print(json.dumps(msg), file=sys.stderr)` (`cli_core.py`).

```bash
python -m embed_client embed-file-json /home/vasilyvz/projects/embed-client/7d-00-48_embed_file.json --show-progress
```

Configure transport/auth via `--config`, or global flags (`--host`, `--port`, `--ssl`, `--cert-file`, `--key-file`, `--ca-cert-file`, `--api-key`, etc.) as in `embed_client/cli.py`.

**Python:** `EmbeddingClient.embed_file_from_local_json_file(..., on_ws_event=callback)` — CLI passes `_embed_file_ws_progress_stderr` when `show_progress=True`.

**Example script (same perf + validation pattern, no `--show-progress` unless extended):**  
`python examples/embed_file_json_local.py /home/vasilyvz/projects/embed-client/7d-00-48_embed_file.json`  
(`examples/embed_file_json_local.py` uses `ClientFactory.from_environment()` and fixed `wait_timeout=600`.)

### (c) Validate received output — what checks

| Location | What runs |
|----------|-----------|
| **`embed-file-json` CLI** | After success: `validate_embed_file_job_result(blocks, result, rpc_dimension=dimension)` (`cli_core.py`) |
| **`examples/embed_file_json_local.py`** | Same: `validate_embed_file_job_result` |
| **Module** | `embed_file_output_validate.py`: payload resolution (`local_output_path` download vs inline), `parse_embed_file_output_records` (`data.results` or top-level `results`), row/body/embedding/dimension checks vs input blocks |

Standalone reuse: load blocks with `iter_json_array_block_texts`, call `validate_embed_file_job_result(blocks, embed_result_dict, rpc_dimension=...)`.

---

## 4. Metrics: total time, mean/median per block, speed

### 4.1 Client-side (implemented)

**Class:** `EmbedFileJobPerfReport` in `embed_client/embed_file_output_validate.py`

- **`total_seconds`:** single `time.perf_counter()` interval around `embed_file_from_local_json_file` in `VectorizationCLI.embed_file_local_json` (`cli_core.py`) and in `examples/embed_file_json_local.py`.
- **`block_count`:** `len(iter_json_array_block_texts(json_path))`.
- **`mean_seconds_per_block` / `median_seconds_per_block`:** both equal **`total_seconds / N`** — dataclass **note** states per-block timings are **not** measured; median equals mean by design.
- **`blocks_per_second`:** `block_count / total_seconds` (also exposed as `mean_blocks_per_second` / `median_blocks_per_second`).

**Human-readable lines:** `format_perf_report_lines(report)` → printed to **stderr** by CLI and example.

### 4.2 Server-side timing (optional)

**CLI:** `python -m embed_client timing-stats` and `timing-stats --file-path ...` → `VectorizationCLI.get_timing_stats` → `EmbeddingClient.timing_stats` (`cli_core.py`). Requires server **timing_registration** enabled; not the same as per-chunk embed_file latency unless the server exposes that in the returned stats.

### 4.3 Logs

- **Progress:** stderr JSON lines from `--show-progress` (WebSocket/status objects), not aggregated into latency histograms in-client.
- **Validation:** stderr lines from `format_validation_checklist_lines`.

---

## 5. File reference index

| Role | Path |
|------|------|
| Input doc (acceptance) | `/home/vasilyvz/projects/embed-client/7d-00-48.md` |
| CLI entry | `embed_client/cli.py` (`prepare-embed-file-json`, `embed-file-json`) |
| Core CLI logic | `embed_client/cli_core.py` (`VectorizationCLI.embed_file_local_json`, `_embed_file_ws_progress_stderr`) |
| MD → json_array | `embed_client/md_embed_file_prep.py` |
| JSON validation / block list | `embed_client/json_embed_file_preflight.py` |
| Upload + embed_file | `embed_client/local_json_embed_file.py` |
| Client API | `embed_client/embedding_client.py` (`embed_file_from_local_json_file`) |
| Output validation + perf report | `embed_client/embed_file_output_validate.py` |
| Example runner | `examples/embed_file_json_local.py` |
