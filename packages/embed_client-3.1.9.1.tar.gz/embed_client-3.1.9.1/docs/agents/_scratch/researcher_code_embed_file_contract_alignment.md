# embed_file contract alignment: `../embed` (reference) vs `embed-client`

Scope: file vectorization / `embed_file` only. Server source of truth: `../embed`.

## Canonical server (`../embed`)

- Command: `embed/commands/embed_file_command.py` — `EmbedFileCommand` (`validate_params`, `execute`, `get_schema`).
- Input JSON (`format=json_array`): `_load_json_array` — top-level JSON array; **each element must be a `str`**.
- Line chunks for staging: `embed/embed_file_line_chunks.py` — `write_embed_file_json_array` writes **array of strings**.
- Outbound result registration: `embed/services/embed_file_transfer.py` — `register_embed_file_output_for_download` (`delete_source_on_ack=True`).
- Reference staging flow (upload → path → RPC): `tests/helpers/embed_file_upload_chain.py` (`server_storage_path_after_upload`), `scripts/embed_file_smoke_e2e.py`, `tests/integration/test_embed_file_long.py` — **`embed_file(storage_path, file_format="json_array", ...)`** with **`input_file`** = server-visible path from `get_upload_session`, not `transfer_id` in `embed_file` params.
- In-repo client: `embed/client/embedding_client.py` — `embed_file(input_file: str, ...)` only (no `inbound_transfer`).

## Ordered mismatches (severity)

1. **Blocker — `json_array` on-disk shape**  
   Server expects **JSON array of strings** (`embed_file_command.py` `_load_json_array`, lines 95–106).  
   embed-client validates and generates **array of objects** with string **`text`** (`json_embed_file_preflight.py`, `md_embed_file_prep.py`). Files produced by the CLI path will fail server validation (`JSON array item N must be a string`).

2. **Major — staged upload → `embed_file` wire contract**  
   Reference embed resolves **`storage_path`** via `get_upload_session(transfer_id)` then passes **`input_file`** only (`embedding_client.py` params use `"input_file": input_file`).  
   embed-client **`embed_file`** with **`inbound_transfer`** sends **`transfer_id`**, **`filename`**, **`compression`**, **`checksum_*`** and omits `input_file` (`embedding_client.py` ~979–989). Server **`validate_params`** and **`get_schema`** require **`input_file`** and do not list transfer fields (`embed_file_command.py` 148–159, 367–393). Alignment depends entirely on **mcp-proxy-adapter** merging transfer into `input_file` before command validation — **not implemented in `../embed` repo**.

3. **Major — documentation vs server**  
   embed-client `docs/api_format.md` states server `json_array` uses objects with **`text`**; **`../embed` implementation uses strings only** — doc is false relative to reference server.

4. **Minor — JSON-RPC schema strictness**  
   Server `get_schema` has `"additionalProperties": false` (`embed_file_command.py` 392). embed-client may add optional **`checksum_value`** on inbound transfer (`embedding_client.py` ~985–987). Whether this is stripped before schema validation is adapter-dependent; not specified in `../embed`.

5. **Minor — progress/status**  
   Server emits **`job_processing_step`** via `push_queue_job_ws_payload` (`embed_file_command.py` `_emit_processing_step`). embed-client waits via **`wait_for_job`** and optional **`on_ws_event`** (`embedding_client.py` `_wait_for_job_via_adapter_ws`). No shape conflict found in-repo; behavior depends on adapter forwarding step events to the same WS channel.

6. **Aligned — download + `transfer_ack`**  
   Client: download by **`outbound_transfer_id`/`transfer_id`**, verify **`checksum_value`**, then **`transfer_ack`** with **`outbound_transfer_id`**, **`checksum_algorithm`**, **`checksum_value`**, optional **`job_id`** (`embedding_client.py` ~1077–1152). Server registers outbound session for ACK semantics (`embed_file_transfer.py`). Same pattern in `../embed` `embed/client/embedding_client.py`.

7. **Aligned — defaults**  
   `error_policy` default **`fail_fast`** matches (`embed/embed/constants.py` vs `embed_client/constants.py`).

## embed-client line references (primary)

| Topic | Location |
|------|----------|
| `inbound_transfer` / `input_file` RPC params | `embed_client/embedding_client.py` ~893–989 |
| Post-wait download + ACK | `embed_client/embedding_client.py` ~1054–1152 |
| Local JSON validation (`text` objects) | `embed_client/json_embed_file_preflight.py` ~43–106 |
| Markdown → JSON pipeline | `embed_client/md_embed_file_prep.py` ~78–157 |
| Upload → `embed_file` orchestration | `embed_client/local_json_embed_file.py` ~21–55 |
| Misleading server semantics | `docs/api_format.md` ~29–40 |

## `../embed` line references (canonical)

| Topic | Location |
|------|----------|
| Command validation + execution | `embed/commands/embed_file_command.py` (full file; schema 367–393) |
| `json_array` loader (strings only) | `embed/commands/embed_file_command.py` 95–106 |
| Reference JSON staging | `embed/embed_file_line_chunks.py` 54–56 |
| Outbound transfer | `embed/services/embed_file_transfer.py` |
| Incremental output file shape | `embed/services/embed_file_incremental.py` |
| In-repo `embed_file` client | `embed/client/embedding_client.py` 662–889 |
