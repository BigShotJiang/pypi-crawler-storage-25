# Live file-vectorization acceptance — code research (embed-client)

**Repo:** `/home/vasilyvz/projects/embed-client`  
**Reference sibling:** `../embed` (server scripts/contracts; alignment noted in `docs/specs/server_client_convergence_and_release/spec.md`, `scripts/run_file_chunking_check_8001.py` docstring).  
**Role:** researcher_code (read-only analysis).

---

## 1) Exact paths: scripts, CLI, modules

### A. Canonical live tour (mTLS localhost:8001), optional `embed_file` with **server-visible** path

| Artifact | Path |
|----------|------|
| Script | `/home/vasilyvz/projects/embed-client/examples/canonical_mtls_localhost_8001.py` |
| Entry | `asyncio.run(main())`; live when `RUN_CANONICAL_MTLS_E2E=1` |
| Core | `run_live_capabilities()` → `EmbeddingClient.embed_file(...)` when `CANONICAL_EMBED_FILE_SERVER_PATH` is non-empty |
| Config builder | `build_mtls_localhost_8001_config()` |

### B. Documented **live** path: real Markdown/text → `json_array` → upload → `embed_file` (aligned with “client-only file” workflow; large doc example `7d-00-48.md` at repo root)

| Step | Path / symbol |
|------|-----------------|
| Docs / commands | `/home/vasilyvz/projects/embed-client/examples/README.md` (§2), `/home/vasilyvz/projects/embed-client/CLI_README.md` |
| CLI entry | `/home/vasilyvz/projects/embed-client/embed_client/cli.py` — subcommands `prepare-embed-file-json`, `embed-file-json`; wrapper `cli_main()` → `asyncio.run(main())` |
| CLI core | `/home/vasilyvz/projects/embed-client/embed_client/cli_core.py` — `VectorizationCLI.embed_file_local_json()`, `_embed_file_ws_progress_stderr()` |
| Prepare (no network) | `/home/vasilyvz/projects/embed-client/embed_client/md_embed_file_prep.py` — `build_embed_file_json_array_from_markdown_text()`, `split_body_into_text_blocks()`, `prepare_markdown_path_to_json_file()`, `prepare_markdown_cli_main()` |
| Preflight validation | `/home/vasilyvz/projects/embed-client/embed_client/json_embed_file_preflight.py` — `validate_local_json_embed_file()`, `resolve_max_json_block_bytes()`, `iter_json_array_block_texts()` |
| Upload + call | `/home/vasilyvz/projects/embed-client/embed_client/local_json_embed_file.py` — `embed_file_from_local_json_file()` |
| Client API | `/home/vasilyvz/projects/embed-client/embed_client/embedding_client.py` — `EmbeddingClient.upload_file()`, `EmbeddingClient.embed_file()`, `EmbeddingClient.embed_file_from_local_json_file()` |
| Minimal example | `/home/vasilyvz/projects/embed-client/examples/embed_file_json_local.py` |
| Sample JSON | `/home/vasilyvz/projects/embed-client/examples/data/embed_file_json_array_sample.json` |

### C. `../embed`-style **file → embed(texts)** (not `embed_file` RPC; line/batch batches like `../embed/scripts/bulk_load_data.py`)

| Artifact | Path |
|----------|------|
| Script | `/home/vasilyvz/projects/embed-client/scripts/run_file_chunking_check_8001.py` |
| Uses | `EmbeddingClient.embed()` with file-derived `texts`; `read_txt_items()` mirrors server `BulkDataLoader.read_txt_file` semantics per docstring |

### D. “File” via CLI without `embed_file`

| Artifact | Path |
|----------|------|
| CLI | `/home/vasilyvz/projects/embed-client/embed_client/cli.py` — `vectorize` + `--file` reads lines locally |
| Core | `/home/vasilyvz/projects/embed-client/embed_client/cli_core.py` — `VectorizationCLI.vectorize_texts()` → `EmbeddingClient.embed()` |

### E. Package entry point

| Declaration | `/home/vasilyvz/projects/embed-client/pyproject.toml` — `embed-vectorize` → `embed_client.cli:cli_main` |

---

## 2) How the flow calls the server and expected response shape

### `embed_file` (true file vectorization on server)

1. **JSON-RPC:** `embed_file` with `params` including `input_file` (server path), `format` (`lines` | `json_array`), optional `model`, `dimension`, `device`, `error_policy` — `/home/vasilyvz/projects/embed-client/embed_client/embedding_client.py` (`EmbeddingClient.embed_file`, ~960–973).
2. **Success envelope:** `result.success`; errors via `EmbedClientError` on RPC/result failure (~975–987).
3. **Wait path:** `job_id` from nested `data`; `_wait_for_job_via_adapter_ws()` (~1028–1030); terminal payload normalized via `_normalize_terminal_job_payload` / `_merge_jsonrpc_result_data_layers` (see ~1119–135 in same file).
4. **Failure in queue result:** `_embed_file_queue_result_error_message(data)` inspects nested `result.success` / `error` (~96–116).
5. **Optional outbound file:** if `outbound_transfer_id` or `transfer_id` present, `download_file` + SHA256 verify against `checksum_value`, then `transfer_ack` (~1051–1126).
6. **Local upload pipeline:** `embed_file_from_local_json_file` in `local_json_embed_file.py`: `validate_local_json_embed_file` → `client.upload_file` → `get_upload_session` → `storage_path` as `input_file` + `file_format="json_array"` (~39–69).

**Wire/API reference:** `/home/vasilyvz/projects/embed-client/docs/api_format.md` — section “JSON-RPC `embed_file`”.

### `vectorize --file` / bulk script

- **`embed` RPC**, not `embed_file`: batch of strings; response normalized in `vectorize_texts` via `data.get("embeddings")` / `extract_embeddings` — `cli_core.py` ~197–224; doc `docs/api_format.md` “JSON-RPC `embed` (batch)”.

---

## 3) Where success is only (or mostly) exit-code based

| Location | Behavior |
|----------|----------|
| `/home/vasilyvz/projects/embed-client/embed_client/cli_core.py` — `embed_file_local_json()` | Returns `True` after printing JSON; `False` on exception (~127–156). **CLI maps:** `if not ok: return 1` in `cli.py` ~377–392. |
| `/home/vasilyvz/projects/embed-client/embed_client/cli_core.py` — `vectorize_texts()` | On failure prints to stderr and returns **`None`** (~233–235). **`cli.py` does not check** the return value; falls through to **`return 0`** (~366–430). So failed vectorization can still exit **0**. |
| `/home/vasilyvz/projects/embed-client/examples/embed_file_json_local.py` | `_run()` returns `0`; only non-zero if uncaught exception (~23–31, 46). |
| `/home/vasilyvz/projects/embed-client/examples/canonical_mtls_localhost_8001.py` | `embed_file` **EmbedClientError** caught inside `run_live_capabilities`; appends `"embed_file: ERROR: ..."` to log lines **without re-raising** (~200–211). **`main()`** exits normally → **0** unless another uncaught exception (~237–242). So **embed_file failure there is not reflected in exit code** when error is caught. |

**Note:** `EmbeddingClient.embed_file` itself raises on checksum mismatch, failed job, bad `transfer_ack`, etc. — those propagate unless caught by callers.

---

## 4) Input blocks/chunks vs output records mapping

### `json_array` → `embed_file`

- **Input:** ordered list of strings — one **array element** per logical block after `md_embed_file_prep.split_body_into_text_blocks()` (UTF-8 byte cap per block) — `md_embed_file_prep.py` ~49–76, ~79–103.
- **Client:** does **not** assert `len(server embeddings) == len(json_array)`; returns merged **`data`** from WebSocket completion plus optional **`local_output_path`**, **`transfer_ack_result`** — `embedding_client.py` ~952–955, ~1122–1126.
- **Alignment semantics** for per-item results live in the **downloaded result JSON** (server-defined), not enforced in client code beyond checksums on staged input/output bytes.

### `embed` batch (`vectorize`, `run_file_chunking_check_8001.py`)

- **Docs:** `results` / `embeddings` indexed with **`texts`** — `docs/api_format.md` ~17–18.
- **`run_file_chunking_check_8001.py`:** merges batch line metadata with `_result_rows(result)` via `_merge_batch_results()` (~266–272, ~91+); prints `texts=` vs `rows=` per batch (~279–281) for **observability**, not a hard assertion.

---

## 5) Timing and validation

### Timing

| Mechanism | Where |
|-----------|--------|
| **`wait_timeout`** | `EmbeddingClient.embed_file(..., wait_timeout=...)` — default 600s; CLI `embed-file-json` passes `--wait-timeout` → `embed_file_wait_timeout` — `cli.py` / `cli_core.py`. |
| **Canonical script** | `embed_file(..., wait_timeout=600)` — `canonical_mtls_localhost_8001.py` ~203–207. |
| **`timing_stats()`** | Optional call in `run_live_capabilities()` (~173–177); failures logged, not fatal. |
| **Wall-clock per batch** | `scripts/run_file_chunking_check_8001.py` — `time.perf_counter()` for batches and totals (~221–287, ~306–311). |
| **`--show-progress`** | Streams WebSocket/status JSON lines to stderr during wait — `cli_core._embed_file_ws_progress_stderr` (~24–26); not latency metrics. |

### Validation (client-side)

| Check | Where |
|-------|--------|
| JSON schema / UTF-8 / per-item max bytes | `json_embed_file_preflight.validate_local_json_embed_file()` |
| Upload completion | `local_json_embed_file.embed_file_from_local_json_file()` — `receipt.completed is True` (~42–46) |
| **`storage_path`** present | same file (~53–58) |
| Job failure message | `_embed_file_queue_result_error_message` after WS completion |
| **Input SHA-256** vs server `input_checksum_value` | `embedding_client.embed_file` when `local_source_path` set (~1036–1048) |
| **Downloaded file** vs `checksum_value` | ~1079–1091 |
| **`transfer_ack`** RPC success | ~1112–1120 |

No automated check in this repo that **output embedding count** matches **input block count** for `embed_file`.

---

## 6) Key symbols (quick index)

- `EmbeddingClient.embed_file`, `embed_file_from_local_json_file` — `embed_client/embedding_client.py`
- `embed_file_from_local_json_file` — `embed_client/local_json_embed_file.py`
- `validate_local_json_embed_file` — `embed_client/json_embed_file_preflight.py`
- `VectorizationCLI.embed_file_local_json`, `vectorize_texts` — `embed_client/cli_core.py`
- CLI routing — `embed_client/cli.py`
- `_embed_file_queue_result_error_message`, `_wait_for_job_via_adapter_ws` — `embed_client/embedding_client.py`

---

*End of report.*
