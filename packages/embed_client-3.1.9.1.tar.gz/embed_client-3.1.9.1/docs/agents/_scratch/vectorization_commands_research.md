# Vectorization scripts and commands (researcher_code)

Repository: `/home/vasilyvz/projects/embed-client`

## Terminology (two “file” meanings)

1. **Server-side file path (`embed_file` RPC)** — сервер читает файл по пути; клиент вызывает `EmbeddingClient.embed_file(...)`.
2. **Клиент читает локальный файл и шлёт тексты через `embed`** — `embed-vectorize --file`, `run_file_chunking_check_8001.py`; это не `embed_file`.

## A) «Файловая векторизация» (embed_file / file on server)

| Command / invocation | Path |
|----------------------|------|
| `CANONICAL_EMBED_FILE_SERVER_PATH=<server-visible-path> RUN_CANONICAL_MTLS_E2E=1 python examples/canonical_mtls_localhost_8001.py` | `examples/canonical_mtls_localhost_8001.py` |

- **Что делает:** live E2E на `localhost:8001`, mTLS, в т.ч. ветка `embed_file` если задан путь, видимый серверу.
- **Документы:** RV-04 `docs/specs/.../rv04-execute-canonical-mtls-real-server-gate.md`, `README.md`, `examples/README.md`.

**Альтернатива (pytest, без реального сервера):** `pytest tests/test_canonical_mtls_example.py -q` — контракт skip/call для `embed_file` (моки).

## B) «Плоская / базовая векторизация» (text → `embed`, без `embed_file`)

| Command / invocation | Path / entry |
|----------------------|--------------|
| `embed-vectorize --config ./configs/mtls_8001.json vectorize "hello"` | `pyproject.toml` → `embed-vectorize` = `embed_client.cli:cli_main`; см. `CLI_README.md` |
| Эквивалент: `python -m embed_client --config ./configs/mtls_8001.json vectorize "hello"` | `embed_client/cli.py` |

- **Что делает:** официальный smoke RV-02; текст с CLI → `embed` через клиент.
- **Спека:** `docs/specs/.../rv02-execute-localhost-vectorization-mtls-8001.md`.

**Другие кандидаты (embed-текст, 8001 / метрики):**

- `python scripts/direct_vectorization_server.py --base-url https://localhost --port 8001` — `scripts/direct_vectorization_server.py` (HTTP `/cmd` **без** `embed_client`; «голый» embed).
- `python scripts/compare_direct_vs_client.py` — сравнение таймингов direct vs `EmbeddingClient.embed`.
- `python scripts/run_embed_contract_8001.py` — контракт `embed` по 8 режимам на порту 8001.
- `python scripts/run_chunking_vectorization_metrics_8001.py` — метрики embed (батчи, длинные тексты).
- `python scripts/run_long_text_vectorization.py` — длинные тексты, mTLS 8001.
- `python scripts/run_timeout_vectorization.py` — таймауты embed, mTLS 8001.

Минимальный пример из README: `EmbeddingClient.from_base_url_port("http://localhost", 8001)` + `embed(["hello"], ...)`.

## C) Векторизация с локального файла через `embed` (не `embed_file`)

| Command | Path |
|---------|------|
| `embed-vectorize --config ./configs/mtls_8001.json vectorize --file /path/to/lines.txt` | `embed_client/cli.py` (читает строки, вызывает `vectorize_texts` → `embed`) |
| `python scripts/run_file_chunking_check_8001.py --file README.md [--config configs/mtls_8001.json]` | `scripts/run_file_chunking_check_8001.py` |

- **Что делает:** чтение файла на стороне клиента, батчевый/строчный `embed`.

## Правила проекта (localhost:8001, mtls, тестовый сервер)

- `.cursor/rules/deploy.mdc`: все 8 режимов на тестовом сервере; на **реальном** `localhost:8001` (обычно mTLS) — векторизация; сертификаты в `mtls_certificates/`.
- RV-02 явно: сервер на **127.0.0.1:8001**, конфиг **`configs/mtls_8001.json`** (не `mtls_8001_test.json`).

## CI / Makefile

- В репозитории **нет** корневого `Makefile` и **нет** `.github/workflows/*.yml` (поиск по workspace); pytest задаётся в `pyproject.toml`.

## Pyproject entry points

- `embed-config-generator`, `embed-config-validator`, `embed-vectorize` — см. `[project.scripts]` в `pyproject.toml`.
