<!--
Research deliverable (researcher_doc). Read-only doc/spec review; no repo edits beyond this scratch file.
Date: 2026-03-30
-->

# File vectorization: documentation and spec analysis (client–server contract, adapters)

**Repository:** `/home/vasilyvz/projects/embed-client`  
**Scope:** Existing specs and user-facing docs only — no new normative spec invented here.

---

## 1. Documented intended flow: file vectorization vs `embed_file` vs adapters

### From docs

**Terminology (consistent across scratch research and `vectorization_commands_research.md`):** “File vectorization” in operator language can mean two different things:

| Meaning | Mechanism | What docs say |
|--------|-----------|-----------------|
| **Server-side file path** | JSON-RPC **`embed_file`** | Client sends a **path string** (`input_file`); the **embedding server** opens and reads that file on the **server** host. Documented in root **`README.md`**, **`examples/README.md`**, **`docs/agents/project_overlay.md`**, **`docs/api_format.md`** (pointer to **`EmbeddingClient.embed_file`**), RV-04 specs, and **`EmbeddingClient.embed_file`** docstring in **`embed_client/embedding_client.py`**. |
| **Client reads local file → text batch embed** | CLI **`embed-vectorize vectorize --file`** (and security CLI equivalent) | Client process reads UTF-8 lines locally and calls **`embed`** with a list of strings — **not** `embed_file`. Documented in **`CLI_README.md`** (subcommand `vectorize` + `--file`), RV-02 (**`embed-vectorize ... vectorize "<text>"`**, no `embed_file`), and internal scratch **`vectorization_commands_research.md`**. |

**Adapter role (high level):** **`docs/agents/project_overlay.md`** and **`README.md`** state that the client uses **`mcp-proxy-adapter`**’s **`JsonRpcClient`** for HTTP(S)/mTLS and JSON-RPC (queue/command execution). **`docs/client_integration_guide.md`** §6 repeats **`JsonRpcClient`** and notes WebSocket preference for job completion when the adapter exposes it.

**Release / gate intent:**

- **RV-02** (`docs/specs/.../rv_localhost_vectorization/spec.md`): smoke **`embed-vectorize`** with benign text against **`localhost:8001`** mTLS — **excludes** changing the example for `embed_file`; **does not** exercise `embed_file`.
- **RV-04** (`docs/specs/.../rv_canonical_mtls_real_server_gate/spec.md` and atomic step `rv04-execute-canonical-mtls-real-server-gate.md`): canonical example must run live; **`CANONICAL_EMBED_FILE_SERVER_PATH`** must be a **server-visible** UTF-8 path for a **passing** full-capability gate so **`embed_file`** actually runs; if unset, output must show the **documented skip** (substrings **`embed_file skipped`** and **`CANONICAL_EMBED_FILE_SERVER_PATH`**).

**`embed_file` contract in durable user docs (short form):** server-readable path; optional inclusion in the canonical tour when the env var is set — **no** description in root **`README.md`** / **`examples/README.md`** of post-job **HTTP download** or **`transfer_ack`** (those appear in **`EmbeddingClient.embed_file`** docstring only; see §3).

### If not documented say so

- **Exact server-internal pipeline** (order of: validate path → read file → chunk/embed → write temp JSON → register outbound transfer id) is **not** specified in reviewed **`docs/*.md`**, **`README.md`**, or release specs — only the **client-visible** story: queue job, server reads **`input_file`**, result may include transfer metadata (**from code docstring**, not from RV/README tables).
- **`CONFIGURATION.md`** does not mention **`embed_file`**, WebSocket, or file transfer fields (confirmed by grep: no matches).
- **Operational matrix** **`docs/SERVER_MODES_AND_CLIENT.md`** documents sync vs queue for **`embed`** and polling **`embed_job_status`**; it does **not** mention **`embed_file`** at all — so readers using only that file miss the server-path vs client-file distinction (noted in prior `researcher_doc_vectorization_adapter_alignment.md`).

---

## 2. Expected server-side order (from docs, examples, OpenAPI, README, adapter contracts)

### From docs

**What is explicitly stated:**

1. **`embed_file` is a server command / queue job** — **`EmbeddingClient.embed_file`** docstring: “Matches server command **`embed_file`** (queue job).”
2. **Server reads input from disk:** “Run `embed_file` on the server: **read texts from `input_file`, write JSON**” (`embedding_client.py` docstring).
3. **`input_file` is on the server:** absolute path on the **server** filesystem; client-side file requires prior upload to a server-visible path (**same docstring** references **`JsonRpcClient.upload_file`** / **`execute_command_with_file`** as examples — **not** automated in this package).
4. **After completion (client side, adapter contract in docstring):** wait via **WebSocket**; if the job result has an **outbound transfer id**, client uses **HTTP** **`download_file`**, then **`transfer_ack`** (so the server can remove temp output when **`delete_source_on_ack`** applies — **docstring** wording).

**Examples / README:**

- **`examples/README.md`**: env **`CANONICAL_EMBED_FILE_SERVER_PATH`** = optional **server-visible** path to **include `embed_file` in the tour**.
- **RV-04 atomic step:** operator chooses a path that **exists on the server filesystem** and is **readable by the service** — **no** ordering of internal server steps beyond “readable path → successful tour line”.

**OpenAPI (`docs/openapi-8001.json`):**

- **`CommandRequest`** enum lists **`embed`, `models`, `health`, `help`, `config` only** — **no `embed_file`**, no queue/transfer endpoints in this snapshot.
- Describes **`POST /cmd`** style JSON-RPC; **does not** document **`embed_file`**, **`transfer_ack`**, or adapter WebSocket paths.

**Root README:**

- Public API list includes optional **`embed_file`**; points to **`embedding_client.py`** for the full method list — **no** step-by-step server or adapter ordering.

### If not documented say so

- **No durable project document** reviewed here gives a numbered **server-side** sequence (e.g. “server must read file before enqueue” vs “enqueue then worker reads”) — **only** the **client** sequence is spelled out in **`embed_file`** docstring (JSON-RPC submit → WS wait → optional download → `transfer_ack`).
- **Bundled OpenAPI** is **not** aligned with the **`embed_file`** + transfer pipeline (missing methods) — treat as **incomplete for `embed_file`** relative to the Python client contract.
- **`fetch_openapi_schema`** / runtime schema may differ; **no** spec in-repo mandates that **`docs/openapi-8001.json`** stay current with **`embed_file`**.

---

## 3. Contradictions, gaps, or clarifications vs the code path

**Read-only cross-check:** authoritative implementation is **`embed_client/embedding_client.py`** (`embed`, `embed_file`, `_wait_for_job_via_adapter_ws`, `download_file`, `transfer_ack`). Prior code research (`researcher_code_vectorization_adapter_chain.md`) traces paths; below is **documentation-facing** alignment.

### From docs (stated mismatches or underdocumentation)

| Topic | Doc / artifact | Issue |
|-------|----------------|--------|
| **Queue completion** | **`docs/SERVER_MODES_AND_CLIENT.md`** | Says client may poll **`embed_job_status`** in queue mode; **`README.md`** / **`embed`** behavior emphasize **WebSocket when available**. Not a hard contradiction — **simplification** — but **`embed_file`** is **omitted** from this file entirely. |
| **Outbound transfer** | **`README.md`**, **`examples/README.md`**, **`CONFIGURATION.md`** | Do **not** describe **`download_file`** + **`transfer_ack`** after **`embed_file`**; **code docstring** does — **user-facing gap**. |
| **OpenAPI vs client** | **`docs/openapi-8001.json`** | No **`embed_file`**; client uses JSON-RPC method **`embed_file`** per implementation. |
| **RV-04 line references** | **`rv04-execute-canonical-mtls-real-server-gate.md`** | References example lines for skip behavior; **line numbers can drift** vs `examples/canonical_mtls_localhost_8001.py` (minor; noted in `researcher_doc_vectorization_adapter_alignment.md`). |
| **`api_format.md`** | **`docs/api_format.md`** | Correctly points **`embed_file`** → **server-side path** and **`EmbeddingClient.embed_file`** docstring; **does not** detail transfer/ACK. |

### If not documented say so

- **Whether the server always returns a `job_id` for `embed_file`** vs sync-style **`output_path`** — **behavior** is handled in code (`embed_file` branches on `job_id` vs `output_path`); **release specs** do not define this branch in prose.
- **WebSocket payload size limits** for large **`embed`** / **`embed_file`** results — **not** stated in reviewed `docs/`; **scripts** (e.g. chunking runners) may carry operational notes — **not** elevated to a durable spec in this review.
- **Inbound upload** for client-local files: **docstring** describes manual **`upload_file`** / **`execute_command_with_file`**; **repository** has **no** calls to those helpers — **alignment** is “documented optional manual step,” **not** “implemented in embed-client.”

---

## 4. Key takeaways (concise)

1. **Documented product story:** distinguish **`embed_file`** (server path string, server reads file) from **CLI `vectorize --file`** (client reads lines, **`embed`** RPC with texts).
2. **Adapter story in short docs:** JSON-RPC + **`JsonRpcClient`**; **full `embed_file` story** adds **WebSocket completion** and optional **HTTP download + `transfer_ack`** — **primarily in `EmbeddingClient.embed_file` docstring**, not in README/CONFIGURATION.
3. **OpenAPI snapshot** in-repo **does not** document **`embed_file`** or transfer methods — **do not** use it alone as the **`embed_file`** contract.
4. **`SERVER_MODES_AND_CLIENT.md`** is **incomplete** for **`embed_file`**-specific guidance.

---

## 5. Sources consulted (existing specs/docs)

| Kind | Paths |
|------|--------|
| Root / CLI | `README.md`, `CLI_README.md`, `CONFIGURATION.md` (no `embed_file` hits) |
| Docs | `docs/api_format.md`, `docs/SERVER_MODES_AND_CLIENT.md`, `docs/client_integration_guide.md`, `docs/agents/project_overlay.md`, `docs/openapi-8001.json` |
| Specs | `docs/specs/.../rv_localhost_vectorization/spec.md`, `docs/specs/.../rv_canonical_mtls_real_server_gate/spec.md`, `steps/rv02-execute-localhost-vectorization-mtls-8001.md`, `steps/rv04-execute-canonical-mtls-real-server-gate.md` |
| Examples | `examples/README.md` |
| Code (alignment read-only) | `embed_client/embedding_client.py` — `embed_file` docstring and body |
| Prior scratch (context) | `docs/agents/_scratch/vectorization_commands_research.md`, `researcher_doc_vectorization_adapter_alignment.md`, `researcher_code_vectorization_adapter_chain.md`, `orch_tactical_debug_7d00_embed_file_vectorization.md` |

---

*End of deliverable.*
