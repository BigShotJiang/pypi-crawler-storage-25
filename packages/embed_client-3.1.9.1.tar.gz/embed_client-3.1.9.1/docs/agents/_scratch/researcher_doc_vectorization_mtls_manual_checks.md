# Research (researcher_doc): vectorization verification, test URLs, mTLS, manual modes

**Scope:** `docs/`, root `README*`, `CLI_README.md`, `CONFIGURATION.md`, `.cursor/rules/deploy.mdc`, release-validation specs.

## 1. Plain text vs file (vectorization)

| Mechanism | What docs say |
|-----------|----------------|
| **Plain / inline text** | `embed-vectorize` subcommand **`vectorize`** with positional texts. Release gate RV-02: `embed-vectorize --config ./configs/mtls_8001.json vectorize "hello"`. See `docs/specs/.../steps/rv02-execute-localhost-vectorization-mtls-8001.md`, `rv_localhost_vectorization/spec.md`. |
| **CLI file (local lines)** | `CLI_README.md` § embed-vectorize: subcommand **`vectorize`** accepts optional **`--file`** (and docstring in `embed_client/cli.py`: file with texts one per line). Distinct from API **`embed_file`**. |
| **Server-side file (`embed_file`)** | Canonical example `examples/canonical_mtls_localhost_8001.py`: env **`CANONICAL_EMBED_FILE_SERVER_PATH`** = server-visible UTF-8 path; RV-04 full-capability gate requires it for **`embed_file`** coverage. See `README.md`, `examples/README.md`, `docs/agents/project_overlay.md`, `rv04-execute-canonical-mtls-real-server-gate.md`. |

## 2. Test server URL, mTLS, certificates

- **Host/port:** **`127.0.0.1:8001` / `localhost:8001`** with **mTLS** matching `configs/mtls_8001.json` (RV-02). `.cursor/rules/deploy.mdc`: vectorization on real **`localhost:8001`** (usually mTLS); certs in **`mtls_certificates`**.
- **Cert paths (typical):** `mtls_certificates/client/embedding-service.crt`, `.../embedding-service.key`, `mtls_certificates/ca/ca.crt` — `CONFIGURATION.md` § “Recommended local integration”, `mtls_certificates/README.md`.
- **Forbidden for RV-02:** substituting **`configs/mtls_8001_test.json`**; mocking transport or plain HTTP when the gate requires mTLS on 8001 (`rv02-execute-localhost-vectorization-mtls-8001.md` §9–10).

## 3. Required modes / environment for manual checks

**Deploy (pre-publication):** All **eight** modes on a **test server** — http; http+token; http+token+roles; https; https+token; https+token+roles; mtls; mtls+roles — `.cursor/rules/deploy.mdc`, `docs/SERVER_MODES_AND_CLIENT.md` (matrix).

**Vectorization smoke:** Real server **`localhost:8001`**, **`configs/mtls_8001.json`**, venv active (**CR-005** per RV-02 step), `embed-vectorize` on PATH (`pip install -e ".[dev]"` if needed).

**Canonical mTLS E2E:** **`RUN_CANONICAL_MTLS_E2E=1`** for live network; optional **`CANONICAL_EMBED_FILE_SERVER_PATH`** for `embed_file`. Dry run: script without `RUN_CANONICAL_MTLS_E2E=1` exits successfully without network (`README.md`, `examples/README.md`).

**Security matrix pytest:** `RUN_SECURITY_MATRIX=1` (module skip otherwise) — see prior scratch `orch_tactical_debug_release_research_code.md`; default test port in matrix docs may differ from 8001 (8000) — use for automated matrix, not RV-02.

## 4. Key cited paths

| Path | Role |
|------|------|
| `.cursor/rules/deploy.mdc` | Eight modes + localhost:8001 vectorization + mtls_certificates |
| `docs/specs/.../rv02-execute-localhost-vectorization-mtls-8001.md` | Atomic procedure RV-02 |
| `docs/specs/.../rv_localhost_vectorization/spec.md` | Tactical spec RV-02 |
| `docs/specs/.../rv04-execute-canonical-mtls-real-server-gate.md` | RV-04 live gate + `CANONICAL_EMBED_FILE_SERVER_PATH` |
| `CLI_README.md` | `embed-vectorize`, `--file` on vectorize |
| `CONFIGURATION.md` | Recommended local mTLS layout |
| `mtls_certificates/README.md` | Certificate suite layout |
| `README.md`, `examples/README.md`, `docs/agents/project_overlay.md` | Canonical script + env vars |
| `docs/SERVER_MODES_AND_CLIENT.md` | Eight-mode deploy matrix |

## 5. Recommended procedure (summary)

1. Activate `.venv`; ensure embedding service on **localhost:8001** with mTLS aligned to **`configs/mtls_8001.json`** and repo **`mtls_certificates/`**.
2. **Text smoke:** `embed-vectorize --config ./configs/mtls_8001.json vectorize "hello"` → exit **0** (RV-02).
3. **Optional CLI file input:** same config + `vectorize --file <local-lines.txt>` per `CLI_README.md` / `embed_client/cli.py` docstring.
4. **Broader API / embed_file:** `RUN_CANONICAL_MTLS_E2E=1 python examples/canonical_mtls_localhost_8001.py`; for full-capability RV-04, set **`CANONICAL_EMBED_FILE_SERVER_PATH`** to a server-visible file path.
5. **Pre-release deploy matrix:** exercise all eight modes on the **test server** per deploy rule (not limited to 8001 in the rule text — “найди в проекте”).

**Constraints:** Do not use **`mtls_8001_test.json`** for RV-02; do not claim RV-04 full pass if output shows **`embed_file skipped`** without setting the env var; run canonical example from **repository root** so cert paths resolve.
