# Comparative code analysis: embed-client vs ../embed (file vectorization / embed_file)

**Role:** researcher_code (read-only). **Repos:** A `/home/vasilyvz/projects/embed-client`, B `/home/vasilyvz/projects/embed` (resolved `../embed` from A). **Date:** 2026-03-30.

---

## Findings (by severity)

### Critical — Inbound transfer without `input_file` vs embed server contract

- **embed-client** (`EmbeddingClient.embed_file`): when `inbound_transfer` is set, JSON-RPC params include `transfer_id`, `filename`, `compression`, `checksum_algorithm`, optional `checksum_value`, and **omit** `input_file` (`embed_client/embedding_client.py`, `embed_file` branch ~968–989).
- **embed** server command `EmbedFileCommand.validate_params` requires `input_file` and raises `InvalidParamsError("input_file is required")` if missing (`embed/commands/embed_file_command.py`, lines 148–150). Execution then opens that path (`execute`, ~161–170). There is **no** branch that resolves `transfer_id` to staged bytes for `embed_file`.
- **Inference:** A deployment whose worker runs this `embed` code cannot complete `embed_file` jobs submitted with **only** transfer metadata; behavior matches reported live errors (`input_file is required` at job execution). Aligning live behavior with embed-client requires **server/proxy** changes or **client** switching to the storage-path pattern (below).

### High — `json_array` on-disk shape: objects with `text` vs array of strings

- **embed-client** `prepare-embed-file-json` / `build_embed_file_json_array_from_markdown_text` writes `[{"text": "..."}, ...]`; `validate_local_json_embed_file` requires each item to be an object with string `text` (`embed_client/md_embed_file_prep.py`, `embed_client/json_embed_file_preflight.py`).
- **embed** `_load_json_array` requires a **top-level JSON array of strings**; non-strings yield `InvalidParamsError` (`embed/commands/embed_file_command.py`, lines 95–107).
- **embed** integration/smoke paths use `write_embed_file_json_array` → array of strings (`embed/embed_file_line_chunks.py` `write_embed_file_json_array`; `scripts/embed_file_smoke_e2e.py`, `tests/integration/test_embed_file_long.py`).
- **Inference:** Files produced by embed-client Markdown prep are **not** aligned with the embed repo server’s `json_array` parser unless an extra normalization step converts objects to strings (not present in embed server).

### Medium — Documentation drift in embed-client

- `docs/api_format.md` states `json_array` items are objects with a `text` field (server semantics). The **embed** server implementation uses **strings only** for `json_array` (`embed_file_command.py`). The **embed** client library docstring for `embed_file` correctly describes server-side `input_file` and upload-then-path workflow (`embed/client/embedding_client.py`, ~690–693).

### Medium — “Staged upload” meaning differs

- **embed** canonical flow: **upload** → **`get_upload_session(transfer_id)`** → read **`storage_path`** → **`embed_file(storage_path, file_format="json_array", ...)`** with **`input_file` = server filesystem path** (`scripts/embed_file_smoke_e2e.py` ~403–433; `tests/helpers/embed_file_upload_chain.py` `server_storage_path_after_upload`; `tests/integration/test_embed_file_long.py` ~124–141). Staging = local temp JSON + HTTP upload; **inbound addressing** = resolved path, not JSON-RPC transfer fields alone.
- **embed-client** “staged” path: **upload** → **`embed_file(inbound_transfer=receipt)`** without `input_file` (`embed_client/local_json_embed_file.py`, `embedding_client.py`).

### Lower — Client API surface

- **embed-client** exposes CLI `prepare-embed-file-json`, `embed-file-json` (`embed_client/cli.py`), programmatic `embed_file_from_local_json_file`, `EmbeddingClient.embed_file` / `upload_file` (`embed_client/local_json_embed_file.py`, `embedding_client.py`).
- **embed** ships `EmbeddingClient.embed_file(input_file, ...)` only (no `inbound_transfer` kwarg) (`embed/client/embedding_client.py` ~662–741); file E2E is via **scripts** and **tests**, not a separate `embed-file-json` CLI in the same shape as embed-client.

---

## Proven facts vs inferred conclusions

### Proven (from repository files)

| Fact | Evidence |
|------|----------|
| Repo B exists and is a Python package tree under `embed/` | Glob/list under `/home/vasilyvz/projects/embed`; `embed/__init__.py` |
| embed server raises **`input_file is required`** when params lack `input_file` | `embed/commands/embed_file_command.py` `validate_params` ~148–150 |
| embed server **`json_array`** reads **array of strings** | `_load_json_array` ~95–107 |
| embed-client **`embed_file`** omits `input_file` when `inbound_transfer` is set | `embed_client/embedding_client.py` ~980–989 |
| embed-client local validation expects **`[{"text": ...}]`** | `embed_client/json_embed_file_preflight.py` ~93–101 |
| embed E2E uses **`storage_path`** + **`embed_file(server_path)`** | `scripts/embed_file_smoke_e2e.py` ~410–433; `test_embed_file_long.py` ~130–134 |
| embed **`EmbeddingClient.embed_file`** always sends `input_file` in params | `embed/client/embedding_client.py` ~727–729 |
| String **`"input_file is required"`** appears in embed (not only live logs) | `embed/commands/embed_file_command.py` line 150 |

### Inferred

| Inference | Basis |
|-----------|--------|
| Live “embedding service” worker behavior matches **embed** `EmbedFileCommand` if it shares this code | Structural match: same validation message and no `transfer_id` input path in command |
| **embed-client** `prepare-embed-file-json` output may fail **embed** `json_array` parsing | Objects vs strings mismatch |
| Preferred portable client pattern for **embed**-compatible servers: resolve **`storage_path`** after upload, then call **`embed_file` with `input_file`** | Same as embed smoke + integration tests |

---

## Repo B layout (embedding-relevant)

- **`embed/`** — service: `commands/` (`embed_file_command.py`, …), `services/`, `worker/`, `client/embedding_client.py`, `embed_file_line_chunks.py`.
- **`scripts/`** — `embed_file_smoke_e2e.py` (documented upload → path → embed_file).
- **`tests/`** — `integration/test_embed_file_long.py`, `helpers/embed_file_upload_chain.py`, `unit/test_embedding_client_embed_file.py`.

---

## Entrypoints (both repos)

| Layer | embed-client | embed |
|-------|--------------|-------|
| CLI | `python -m embed_client prepare-embed-file-json`, `embed-file-json` (`cli.py`) | No equivalent first-party CLI for the same upload+embed_file-json_array UX; use `scripts/embed_file_smoke_e2e.py` |
| Public API | `EmbeddingClient.embed_file`, `embed_file_from_local_json_file`, `upload_file` (`embedding_client.py`, `local_json_embed_file.py`) | `EmbeddingClient.embed_file` (`embed/client/embedding_client.py`) |
| Server / command | N/A (client-only repo) | `EmbedFileCommand` (`embed/commands/embed_file_command.py`) |

---

## End-to-end flow comparison

| Aspect | embed-client | embed (reference implementation + server) |
|--------|----------------|---------------------------------------------|
| **Local prep / validation** | `validate_local_json_embed_file`, MD prep `prepare_markdown_path_to_json_file` | Smoke/test: `line_chunks_from_embed_file` + `write_embed_file_json_array` (strings); server validates `input_file` + format |
| **Upload** | Single `upload_file` → `TransferReceipt` (`local_json_embed_file.py`) | Single `upload_file` then `get_upload_session` for `storage_path` |
| **embed_file request** | Params: `transfer_*` fields, **no** `input_file`, `format=json_array` | Params: **`input_file`** (required), `format`, model fields (`embedding_client.py` embed fork) |
| **Progress** | WS via `on_ws_event`; CLI `--show-progress` → stderr JSON lines (`cli_core.py`) | Same family: `job_processing_step` in command + client wait; smoke prints `[status]` lines |
| **Result download / cleanup** | `download_file` + `transfer_ack` in `embed_file` completion path (`embedding_client.py`, same pattern as embed client) | Same pattern in `embed/client/embedding_client.py` post-wait |

---

## Staged upload / inbound-transfer (goal 4)

- **embed** documents and implements: **inbound transfer materializes as a server-local path** (`storage_path` from upload session), then **`embed_file` uses `input_file`**. It does **not** implement an **`embed_file` command path that accepts only `transfer_id`** without `input_file` in `EmbedFileCommand`.
- **embed-client** documents and implements: **`embed_file` RPC with transfer metadata and without `input_file`** (`docs/api_format.md`, `embedding_client.py`).

---

## `input_file is required` (goal 5)

- **embed** implements the exact validation string in **`EmbedFileCommand.validate_params`** (`embed/commands/embed_file_command.py`, line 150).
- **embed-client** implements a **client-side** guard with a different message: `"embed_file: input_file is required unless inbound_transfer is set"` (`embed_client/embedding_client.py` ~974–976).

---

## Mismatch matrix (goal 6)

| embed-client current behavior | ../embed behavior | Live server expectation (inferred from comparison) |
|-------------------------------|-------------------|---------------------------------------------------|
| `embed_file` may omit `input_file` when `inbound_transfer` is set; sends `transfer_id`, etc. | Server requires `input_file`; no transfer-only execution in `EmbedFileCommand` | If worker matches **embed**: job fails with **`input_file is required`** unless proxy injects `input_file` before execute |
| Local JSON prep: `[{ "text": "..." }]` validated client-side | Server `json_array`: array of **strings** | If worker matches **embed**: invalid params or per-item error when loading file |
| CLI `embed-file-json` + `prepare-embed-file-json` | Smoke: chunk to **string array** JSON + upload + **path** + `embed_file` | E2E compatible with **embed** when client uses **`storage_path` as `input_file`** and string array file |
| `docs/api_format.md` describes transfer metadata replacing `input_file` | Server code + embed `EmbeddingClient` use **`input_file` only** for RPC | Published OpenAPI may list `input_file` required; align client or server |
| Download/ACK/WebSocket wait patterns | Same conceptual adapter flow in `embed/client/embedding_client.py` | Likely compatible when `embed_file` completes successfully |

---

## Key file / symbol index

- **embed-client:** `embed_client/embedding_client.py` — `EmbeddingClient.embed_file`, `upload_file`; `embed_client/local_json_embed_file.py` — `embed_file_from_local_json_file`; `embed_client/json_embed_file_preflight.py` — `validate_local_json_embed_file`; `embed_client/md_embed_file_prep.py` — `prepare_markdown_path_to_json_file`; `embed_client/cli.py` — `embed-file-json`, `prepare-embed-file-json`; `docs/api_format.md`.
- **embed:** `embed/commands/embed_file_command.py` — `EmbedFileCommand`, `validate_params`, `_load_json_array`; `embed/client/embedding_client.py` — `EmbeddingClient.embed_file`; `embed/embed_file_line_chunks.py` — `write_embed_file_json_array`; `scripts/embed_file_smoke_e2e.py`; `tests/integration/test_embed_file_long.py`; `tests/helpers/embed_file_upload_chain.py`.

---

## Scope note

Repo B was **accessible**; analysis covers both trees. No tests were executed (researcher_code constraint).
