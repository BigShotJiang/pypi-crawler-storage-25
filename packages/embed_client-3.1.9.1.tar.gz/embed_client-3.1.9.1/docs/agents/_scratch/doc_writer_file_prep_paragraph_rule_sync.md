# Doc sync: file prep paragraph rule (orchestrator handoff)

**Author:** Vasiliy Zdanovskiy (doc_writer)  
**Date:** 2026-03-30  

Public documentation was aligned with the authoritative Markdown/plain prep rule in **`embed_client/md_embed_file_prep.py`**: the body is split **only** on **`\n\n`** (paragraph / blank-line boundaries) after optional front-matter strip and line-ending normalization; there is **no** semantic analysis or smart chunking and **no** automatic byte-level re-split — a paragraph whose UTF-8 encoding exceeds the configured cap causes preparation to **fail**; **`--max-chunks`** only truncates the resulting string list. Updates were applied to **`CLI_README.md`** (expanded **`prepare-embed-file-json`** description), **`README.md`** (short clause on prepare flow), **`docs/SERVER_MODES_AND_CLIENT.md`** (replaced misleading “chunked **`json_array`**” with paragraph-block / **`\n\n`** wording), **`examples/README.md`** (§2: double-newline split, per-paragraph byte limit, truncation semantics for **`--max-chunks`**), **`CONFIGURATION.md`** (**`EMBED_CLIENT_MAX_JSON_BLOCK_BYTES`** tied to per-paragraph blocks after prep split), and **`docs/api_format.md`** (one line under **`json_array`** plus cross-links to **`CLI_README.md`** and root **`README.md`**). Source recommendations: **`docs/agents/_scratch/researcher_doc_file_prep_paragraph_rule_audit.md`**.

**Paths changed:** `CLI_README.md`, `README.md`, `docs/SERVER_MODES_AND_CLIENT.md`, `examples/README.md`, `CONFIGURATION.md`, `docs/api_format.md`, `docs/agents/_scratch/doc_writer_file_prep_paragraph_rule_sync.md`.

**Orchestrator:** deliverable path for follow-up — **`docs/agents/_scratch/doc_writer_file_prep_paragraph_rule_sync.md`**.
