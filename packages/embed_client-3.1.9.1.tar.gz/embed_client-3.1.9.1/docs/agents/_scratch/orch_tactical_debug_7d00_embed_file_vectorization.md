# orch_tactical_debug — `7d-00-48.md`, `embed_file`, CLI fallback

## 1) Resolved reference `7d-00-48.md`

- **Found:** `/home/vasilyvz/projects/embed-client/7d-00-48.md` (repository root).

## 2) Server-side `embed_file` (canonical mTLS E2E)

- **Source:** `examples/canonical_mtls_localhost_8001.py` passes `os.environ["CANONICAL_EMBED_FILE_SERVER_PATH"]` (trimmed) to `EmbeddingClient.embed_file(...)`.
- **Semantics (from `embed_client/embedding_client.py` `embed_file` docstring):** `input_file` must be an **absolute path** to a UTF-8 file on the **server** filesystem. The client sends the string to the server via JSON-RPC `embed_file`; the **server** opens and reads the file.
- **Must exist on server:** Yes — operationally the path must be readable by the embedding service on the **server** host. The client does not upload the file in this tour.

## 3) Client-repo-only file

- A path that exists only under the **client** checkout (e.g. `/home/vasilyvz/projects/embed-client/7d-00-48.md`) **does not** make `embed_file` work unless the **same** path exists and is readable on the **server** (shared mount, bind mount, copy, etc.). Otherwise use client-side vectorization (CLI `--file` reading locally + `embed`).

## 4) Tester commands (absolute paths)

**A) Full `embed_file` attempt (replace `<SERVER_ABS_PATH>` with a path valid on the server process, not the client path unless identical):**

```bash
cd /home/vasilyvz/projects/embed-client
CANONICAL_EMBED_FILE_SERVER_PATH='<SERVER_ABS_PATH>' RUN_CANONICAL_MTLS_E2E=1 python examples/canonical_mtls_localhost_8001.py
```

If the deployment exposes the repo file at the same absolute path on the server (unusual), use:

`CANONICAL_EMBED_FILE_SERVER_PATH='/home/vasilyvz/projects/embed-client/7d-00-48.md'`

**B) Fallback — client reads file, `embed` (not `embed_file`):**

From repo root so relative cert paths work; mTLS to `localhost:8001`:

```bash
cd /home/vasilyvz/projects/embed-client
embed-vectorize --host https://localhost --port 8001 --ssl \
  --cert-file /home/vasilyvz/projects/embed-client/mtls_certificates/client/embedding-service.crt \
  --key-file /home/vasilyvz/projects/embed-client/mtls_certificates/client/embedding-service.key \
  --ca-cert-file /home/vasilyvz/projects/embed-client/mtls_certificates/ca/ca.crt \
  --timeout 120 \
  vectorize --file /home/vasilyvz/projects/embed-client/7d-00-48.md
```

Equivalent: `python -m embed_client` with the same flags. Optional: `--config` pointing to a generated mTLS JSON (see `CLI_README.md` / `embed-config-generator`).

## 5) `mtls_certificates` and cwd

- **Canonical example:** run from **repository root** so `build_mtls_localhost_8001_config` resolves `mtls_certificates/client/*.crt|key` and `mtls_certificates/ca/ca.crt` (see script `_ROOT` and `_cert_paths`).
- **CLI fallback:** use **absolute** paths to certs (as above) so cwd does not matter; or run from repo root with relative `mtls_certificates/...` paths.
