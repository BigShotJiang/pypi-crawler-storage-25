# Research: E2E file vectorization (client-facing) for `7d-00-48.md`

Facts from current code (read-only). No server binary in this repo.

## 1) Location of `7d-00-48.md`

| Fact | Detail |
|------|--------|
| **Present** | Yes — repository **root** |
| **Path** | `/home/vasilyvz/projects/embed-client/7d-00-48.md` |

## 2) CLI entry points and subcommands (prepare → upload pipeline)

| Item | Symbol / path |
|------|----------------|
| **Console script** | `embed-vectorize` → `embed_client.cli:cli_main` (`pyproject.toml` `[project.scripts]`) |
| **Module** | `python -m embed_client` (same `cli_main`) |
| **Prepare MD → JSON (no network)** | Subcommand **`prepare-embed-file-json`**, wired in `embed_client/cli.py` → `prepare_markdown_cli_main` in `embed_client/md_embed_file_prep.py` |
| **Key prep symbols** | `prepare_markdown_cli_main`, `prepare_markdown_path_to_json_file`, `build_embed_file_json_array_from_markdown_text` (`md_embed_file_prep.py`) |
| **Upload + embed_file (json_array)** | Subcommand **`embed-file-json`**, handled in `cli.py` → `VectorizationCLI.embed_file_local_json` (`embed_client/cli_core.py`) → `EmbeddingClient.embed_file_from_local_json_file` (`embedding_client.py` / `local_json_embed_file.py`) |

**Typical two-step CLI for Markdown like `7d-00-48.md`:**

1. `prepare-embed-file-json ./7d-00-48.md -o <out.json> [--max-chunks N] [--max-block-bytes N]`
2. `embed-file-json <out.json> [--show-progress] [--config ... | --host/--port/...]`

`prepare-embed-file-json` returns early with exit code from `prepare_markdown_cli_main` **before** any `VectorizationCLI.connect` (see `cli.py`: prepare branch exits before config/connect).

## 3) “Whole file” upload via adapter (no client-side partial upload)

The client does **not** split the JSON file into multiple upload RPCs for this path: one **`upload_file`** call, then **`embed_file`** with transfer metadata.

| Step | Module / symbol | Behavior |
|------|-----------------|----------|
| Validate local JSON | `validate_local_json_embed_file` (`json_embed_file_preflight.py`) | Ensures UTF-8 `json_array` schema and block sizes before upload |
| Single upload | `embed_file_from_local_json_file` (`local_json_embed_file.py`) | `receipt = await client.upload_file(ap, filename=...)`; requires `receipt.completed is True` or raises `EmbedClientError` |
| RPC | `EmbeddingClient.embed_file` (`embedding_client.py`) | With `inbound_transfer=receipt`, passes `transfer_id`, `filename`, `compression`, `checksum_algorithm`, optional `checksum_value` in JSON-RPC `embed_file` params — **not** `input_file` |
| Delegation | `EmbeddingClient.upload_file` | Delegates to `self.client.upload_file` (mcp-proxy-adapter `JsonRpcClient`) — “Stage a local file via the adapter HTTP upload” |

Chunking of **content** happens only in **prepare** (`split_body_into_text_blocks` → multiple `{"text": ...}` objects in one JSON file), not as multiple HTTP uploads.

## 4) Pointing the client at `localhost:8001`

| Mechanism | Detail |
|-----------|--------|
| **CLI defaults** | `--host` default `http://localhost`, `--port` default **8001** (`embed_client/cli.py`) |
| **Config dict from CLI** | `create_config_from_args` → `"server": {"host": args.host, "port": args.port}` (`cli_core.py`) |
| **Constants** | `DEFAULT_BASE_URL = "http://localhost"`, `DEFAULT_PORT = 8001` (`embed_client/constants.py`); also string names `EMBEDDING_SERVICE_BASE_URL_ENV` / `EMBEDDING_SERVICE_PORT_ENV` (exported constants only — not wired as alternate env readers in grepped code) |
| **`ClientFactory.from_environment`** | `EMBED_CLIENT_BASE_URL` (default `http://localhost`), `EMBED_CLIENT_PORT` (default `"8001"`), plus `EMBED_CLIENT_SSL_ENABLED`, auth-related `EMBED_CLIENT_*` (`client_factory.py`) — used by `examples/embed_file_json_local.py` |
| **`EmbeddingClient.from_base_url_port`** | If URL has no port, falls back to argument or **8001** (`embedding_client.py`) |

For **mTLS** to localhost:8001, use **`--config`** with a JSON/YAML that sets protocol/ssl (see `examples/canonical_mtls_localhost_8001.py` / `CONFIGURATION.md`) or global CLI `--ssl` + cert flags per `create_config_from_args`.

## 5) Server progress / status: streamed or printed?

| Aspect | Detail |
|--------|--------|
| **Job completion** | `embed_file(..., wait=True)` waits via **`_wait_for_job_via_adapter_ws`** → prefers `JsonRpcClient.wait_for_job` (WebSocket `/ws` queue subscription) with optional per-event callback; fallback `wait_for_job_via_websocket` (`embedding_client.py`) |
| **CLI visibility** | **`--show-progress`** on `embed-file-json` sets `on_ws_event` to **`_embed_file_ws_progress_stderr`**, which prints **one JSON object per line to stderr** (`cli_core.py`) |
| **Default** | Without `--show-progress`, user does **not** get per-frame stderr lines; final merged result is **printed to stdout** as indented JSON from `embed_file_local_json` |

So: **WebSocket-driven job events** (adapter), optionally **printed** as JSON lines — not a separate HTTP streaming upload progress API in this client.

## 6) Example scripts matching the acceptance case (`7d-00-48.md` / json_array → embed)

| File | Role |
|------|------|
| **`examples/README.md`** §2 | Documents flow for repo root **`7d-00-48.md`**: `prepare-embed-file-json ... --max-chunks` then `embed-vectorize ... embed-file-json ... --show-progress` |
| **`examples/data/embed_file_json_array_sample.json`** | Small valid **`json_array`** input for direct `embed-file-json` |
| **`examples/embed_file_json_local.py`** | Minimal **`ClientFactory.from_environment()`** + `embed_file_from_local_json_file` (programmatic twin of CLI upload path) |
| **`examples/canonical_mtls_localhost_8001.py`** | **Different** path: optional **`CANONICAL_EMBED_FILE_SERVER_PATH`** for **server-side** `embed_file(input_file=...)` on localhost:8001 — **not** the local JSON upload pipeline |

---

**Summary for `7d-00-48.md` E2E (client upload path):** file exists at repo root; convert with **`prepare-embed-file-json`**, then run **`embed-file-json`** against a running service with correct TLS/auth config; upload is a **single** `upload_file` + **`embed_file`** with **`inbound_transfer`**; progress lines are **optional** via **`--show-progress`**.
