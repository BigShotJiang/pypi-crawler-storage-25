# Code research: file vectorization runtime vs `7d-00-48.md`

**Scope:** `embed-client` repository — CLI, `local_json_embed_file`, `json_embed_file_preflight`, `EmbeddingClient.embed_file`, progress/status plumbing.  
**Date:** 2026-03-30 (researcher_code).

---

## 1) Location of `7d-00-48.md`

| Item | Detail |
|------|--------|
| **Resolved path** | `/home/vasilyvz/projects/embed-client/7d-00-48.md` (repository **root**) |
| **If missing** | Same verification role: keep a **stable, documented path** (repo root or `examples/data/` with README pointer). Scratch notes already use root: `docs/agents/_scratch/orch_tactical_debug_7d00_embed_file_vectorization.md`. |

**Content shape (first lines):** YAML front matter + Markdown headings — **not** a JSON array:

```1:7:/home/vasilyvz/projects/embed-client/7d-00-48.md
---
%%7d-00%%
---

# 📑 Структура документа: Теория материи в 7-мерном фазовом пространстве-времени

## Введение
```

The file is very large (~27k+ lines in tooling view); treat as a **stress** artifact for line-based `vectorize --file` and as **invalid** for `json_array` preflight.

---

## 2) Client-facing path: file vectorization

### A. `embed-file-json` — **server `embed_file` with `json_array` + adapter upload**

1. **CLI:** `python -m embed_client embed-file-json <path>` — `embed_client/cli.py` (parser `embed-file-json`, dispatch ~327–341).
2. **Core:** `VectorizationCLI.embed_file_local_json` — `embed_client/cli_core.py` ~108–146: calls `self.client.embed_file_from_local_json_file(...)`, then **`print(json.dumps(result, indent=2))`** on success.
3. **Library:** `EmbeddingClient.embed_file_from_local_json_file` — `embed_client/embedding_client.py` ~1124–1149: thin wrapper to `embed_client.local_json_embed_file.embed_file_from_local_json_file`.
4. **Orchestration:** `embed_client/local_json_embed_file.py` ~21–55:
   - `validate_local_json_embed_file(local_path, ...)` (preflight),
   - `await client.upload_file(ap, filename=upload_filename)`,
   - `await client.embed_file(inbound_transfer=receipt, local_source_path=ap, file_format="json_array", **embed_file_kwargs)`.

### B. `vectorize --file` — **NOT `embed_file`; line-based `embed` RPC**

1. **CLI:** `vectorize` + `--file` — `embed_client/cli.py` ~297–325: reads file in executor, **one string per non-empty line** (`read_file_sync` strips lines).
2. **Core:** `VectorizationCLI.vectorize_texts` — `embed_client/cli_core.py` ~148–225: `await self.client.embed(texts, ..., wait=True, ...)`.
3. **Effect:** Entire list of line strings goes to **`embed`**, not `embed_file`. For a huge `.md`, this becomes a **very large batch** (see gaps).

### C. Server-side path only (API): `EmbeddingClient.embed_file`

- `embed_file` — `embed_client/embedding_client.py` ~870–1122: JSON-RPC `embed_file` with either `input_file` (path on **server**) **or** `inbound_transfer` (upload receipt). Params include `"format": file_format` (`lines` or `json_array`).

**How a Markdown file becomes API input:**

| Flow | What reaches the server |
|------|-------------------------|
| `embed-file-json` | Staged bytes from **validated** local JSON file → `upload_file` → `embed_file` with transfer metadata + `format=json_array`. |
| `vectorize --file` | **No** file upload: UTF-8 lines → list of strings → **`embed`** JSON-RPC (not `embed_file`). |
| `embed_file(input_file=...)` (programmatic) | Server reads **`input_file` on server FS** — client path like `.../7d-00-48.md` is irrelevant unless shared mount. |

---

## 3) Is JSON-only required? `.md` → file vectorization

### `embed_file` **local** path via `embed-file-json`: **yes, JSON `json_array` only**

`validate_local_json_embed_file` — `embed_client/json_embed_file_preflight.py` ~43–106:

- File must be UTF-8 (optional BOM).
- After strip, root must start with **`[`** (line ~76–78).
- `json.loads` → root **non-empty array** of **objects**, each with string **`"text"`**.
- Each `text` UTF-8 length ≤ `resolve_max_json_block_bytes` (default **1 MiB** per block) — `constants.DEFAULT_MAX_JSON_EMBED_BLOCK_BYTES` = 1_048_576 (`embed_client/constants.py` ~29–31).

**`7d-00-48.md`** fails preflight immediately (starts with `---`, not `[`; not JSON).

**Preparation step:** There is **no** built-in Markdown→`json_array` converter in this repo. Needed externally: chunk/split content into `{ "text": "..." }` objects, respect per-block byte cap and total upload limits. Optional env: `EMBED_CLIENT_MAX_JSON_BLOCK_BYTES` (see `json_embed_file_preflight.resolve_max_json_block_bytes`).

### Alternative: `vectorize --file` with `.md`

- No JSON required; treats **lines** as separate texts.
- Semantics differ from semantic chunking: raw lines, not structured blocks.

---

## 4) Server progress / status → console

### Default CLI (`embed-file-json`)

- **No** incremental progress printed. Success path only: `print(json.dumps(result, indent=2))` — `cli_core.py` ~142.
- Errors: `print(..., file=sys.stderr)` — ~145.

### Where WebSocket events are handled (library)

- `embed_file(..., wait=True)` → `_wait_for_job_via_adapter_ws` — `embedding_client.py` ~725–776:
  - Prefer `JsonRpcClient.wait_for_job(job_id, on_event=_on_event)` **or**
  - Fallback `wait_for_job_via_websocket(..., on_inbound_message=on_ws_event)`.
- `embed_file` accepts optional **`on_ws_event`** — docstring ~924–925: callback per WS JSON payload while waiting; **CLI does not wire this**, so **no streaming status to stdout/stderr** from the default CLI.

### Optional recording (not enabled for default client)

- `EmbeddingClient(..., enable_embed_file_status_store=True)` — ~162–208: in-memory `EmbedFileJobStatusStore` (`embed_client/embed_file_status_store.py`).
- `embedding_client_from_config_dict` — `embedding_client.py` ~1302–1323: constructs `EmbeddingClient(...)` **without** `enable_embed_file_status_store` → stays **`False`**.
- When store is on + `embed_file`, WS frames can be recorded (`record_message`) unless adapter job registry absorbs them — see ~1016–1027 and `_uses_adapter_job_message_registry` (~41–43).

### Queue-oriented CLI commands

- `queue-status`, `queue-wait`, `queue-logs`, etc. — `cli_core.py` ~258–309: separate JSON-RPC helpers; **not** automatically invoked by `embed-file-json`.

**Bottom line:** Progress is **WebSocket-driven internally** until terminal job payload; **default CLI shows only final JSON result**, not live progress.

---

## 5) Gaps blocking E2E verification with `7d-00-48.md`

| Gap | Evidence |
|-----|----------|
| **`embed-file-json` rejects `.md`** | Preflight requires JSON array root `[` + `"text"` fields — `json_embed_file_preflight.py` ~76–101. |
| **No client-side MD→JSON pipeline** | Only validation + upload + `embed_file` — no conversion utility in traced modules. |
| **`vectorize --file` scale risk** | ~27k lines → ~27k strings in one `embed` batch — memory/RPC/timeout risk; documented concern in scratch `researcher_code_vectorization_adapter_chain.md`. |
| **Server-only `input_file` path** | Same repo path on client does not imply server visibility — see `orch_tactical_debug_7d00_embed_file_vectorization.md`. |
| **No live progress in CLI** | `on_ws_event` unused; `enable_embed_file_status_store` default off for config-built client. |

**Minimal E2E for file-vectorization semantics:** produce a **valid `json_array` file** (from any source), run `embed-file-json` against a running adapter/server. **`7d-00-48.md` as-is** is a **negative test** for preflight, not a drop-in input for `embed-file-json`.

---

## File:line index (quick reference)

| Topic | Location |
|-------|----------|
| `vectorize` + `--file` read | `embed_client/cli.py` ~297–325 |
| `embed-file-json` dispatch | `embed_client/cli.py` ~327–341 |
| `embed_file_local_json` | `embed_client/cli_core.py` ~108–146 |
| Preflight | `embed_client/json_embed_file_preflight.py` ~43–106 |
| Upload + `embed_file` | `embed_client/local_json_embed_file.py` ~21–55 |
| `embed_file` RPC + WS wait | `embed_client/embedding_client.py` ~870–1122, ~725–776 |
| Status store | `embed_client/embed_file_status_store.py`; `EmbeddingClient` ~162–208, ~391–514 |
| Default max block bytes | `embed_client/constants.py` ~29–31 |

---

**Materialized path:** `docs/agents/_scratch/orch_tactical_debug_7d00_research_code.md`
