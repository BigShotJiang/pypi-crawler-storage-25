# Live file-vectorization validation — handoff

**Date:** 2026-03-30  
**Repository:** `/home/vasilyvz/projects/embed-client`

## Files changed

| Path | Role |
|------|------|
| `embed_client/embed_file_output_validate.py` | New: parse `../embed`-aligned output JSON, validate vs input blocks, perf report helpers |
| `embed_client/cli_core.py` | `embed_file_local_json`: `perf_counter`, perf lines on stderr, validation after success |
| `examples/embed_file_json_local.py` | Same perf + validation pattern as CLI |
| `examples/canonical_mtls_localhost_8001.py` | `embed_file` errors no longer swallowed (propagate → non-zero exit under `RUN_CANONICAL_MTLS_E2E=1`) |
| `tests/test_embed_file_output_validate.py` | Unit tests for validation helpers |

## How to run a live test

1. Activate venv (CR-005): `source .venv/bin/activate` from repo root.
2. Ensure the embedding service is reachable per your config (e.g. mTLS `localhost:8001`).
3. Example script:  
   `python examples/embed_file_json_local.py path/to/blocks.json`
4. CLI (same pipeline):  
   `python -m embed_client embed-file-json path/to/blocks.json`  
   (or the documented `embed-vectorize` entry if configured.)

## What validation runs

- Resolves payload from `local_output_path` in the `embed_file` result (downloaded JSON), or from inline structures if present (see `resolve_embed_file_output_payload`).
- Expects canonical shape `{"success": true, "data": {"dimension", "results": [...]}}` (same as `EmbedFileIncrementalJsonWriter` in `../embed`) or simplified top-level `results`.
- Checks: `success` is not false; row count equals local `json_array` block count; embeddings non-empty and length matches `dimension` from RPC arg or payload; per-row `error` allowed instead of embedding; `body` vs input order when comparable.
- Human-readable checklist and performance lines go to **stderr**; merged job JSON remains on **stdout** (last print).

## Fixes (2026-03-30, tester follow-up)

1. **`tests/test_cli_embed_file_json.py`** — Tests no longer use a non-existent `"blocks.json"` path. They write a minimal UTF-8 **json_array** file under `tmp_path` (`["block one"]`) and pass its path into `embed_file_local_json`. The mocked `embed_file_from_local_json_file` return value was updated to a minimal payload that passes `resolve_embed_file_output_payload` / output validation (one row, `body` + `embedding` aligned with the file).

2. **`embed_client/client_factory.py` — `ClientFactory.from_environment()`** — Reads `EMBED_CLIENT_CERT_FILE`, `EMBED_CLIENT_KEY_FILE`, and `EMBED_CLIENT_CA_CERT_FILE` (non-empty after strip) and passes them into `create_client` as `cert_file` / `key_file` / `ca_cert_file`, so with `EMBED_CLIENT_SSL_ENABLED=true` the factory selects mTLS and populates `ssl` like `build_mtls_localhost_8001_config()` / explicit `create_mtls_client`.

3. **`tests/test_client_factory.py`** — `test_from_environment_passes_ssl_paths_from_env` asserts the constructed config dict includes those paths under `ssl`.

**Validation:** `pytest tests/test_cli_embed_file_json.py tests/test_embed_file_output_validate.py -q` (plus the new factory test); `black` / `flake8` / `mypy` on touched modules.

## Limitations

- **Single wall-clock interval:** Average and median “per block” time are both `total_seconds / N` because the client does not receive per-block timings; throughput is `N / total_seconds` blocks/s over the whole job.
- **`skip_download` / no file:** If there is no readable `local_output_path` and no inline `results` in the result dict, validation raises `EmbedClientError` and the CLI returns failure.
- **Ordering:** Strict index-wise `body` comparison; if the server omits `body` or normalizes text, the checklist notes that ordering was not strictly verified.
