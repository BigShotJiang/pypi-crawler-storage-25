# Comparative documentation research: embed-client vs embed (file vectorization)

**Role:** researcher_doc (read-only docs + read-only code for alignment verification).  
**Date:** 2026-03-30  
**Scope:** File vectorization, `embed_file`, upload, staged/inbound transfer, `input_file`; contracts and flows; server error `input_file is required`.

---

## Documentation overview

| Repository | User-facing docs on `embed_file` / uploads | Density |
|------------|---------------------------------------------|---------|
| **embed-client** | `README.md`, `docs/api_format.md`, `docs/SERVER_MODES_AND_CLIENT.md`, `CLI_README.md`, `examples/README.md`, `CONFIGURATION.md` (cross-links) | **Strong** — two input modes (server path vs staged upload) are spelled out |
| **embed** (service) | Root `README.md` → points to `docs/`; `embed/README.md` (Russian) API section lists `embed` / `models` / `health` only | **Sparse for `embed_file`** — no `embed_file` in the main API examples; narrative lives in scripts/reports, not in canonical `docs/*.md` user guides |

**Explicit conclusion:** In **embed**, end-user documentation under `embed/README.md` does **not** document the `embed_file` command, upload staging, or `input_file`. Supplementary material exists in **`reports/`**, **`.cursor/`**, and **script docstrings** (e.g. `scripts/embed_file_smoke_e2e.py`), which are not equivalent to a stable public doc set.

---

## Findings by severity

### High — Cross-repo contract mismatch (documented client intent vs service README omission)

- **embed-client** states a **dual** contract for `embed_file`: exactly one of (1) **`input_file`** on the server host, or (2) **staged upload** via **`upload_file`** then params derived from **`TransferReceipt`** / **`inbound_transfer`** (`transfer_id`, `filename`, `compression`, `checksum_algorithm`, …), with **`EmbeddingClient`** omitting `input_file` in the second case.

  **Citations:**
  - `embed-client/docs/api_format.md` — section «JSON-RPC `embed_file`», bullets (1) server-side `input_file`, (2) staged upload / `transfer_id` / transfer metadata; notes CLI `embed-file-json` and `embed_file_from_local_json_file`.
  - `embed-client/README.md` — paragraph «`embed_file` vs local JSON without shared server disk» (server-visible `input_file` vs validate → upload → `embed_file` with `format=json_array` and staged transfer metadata).
  - `embed-client/docs/SERVER_MODES_AND_CLIENT.md` — «Local file upload and `embed_file` (`json_array`)»; server-side path via `input_file` + `CANONICAL_EMBED_FILE_SERVER_PATH`.

- **embed** `embed/README.md` — «API» / «Команды» documents **`embed`**, **`models`**, **`health`** only; **no** `embed_file`, no upload, no `input_file`. Operators reading only this file get **no** stated contract for file vectorization.

**Proven fact:** File paths and absence of `embed_file` in `embed/README.md` (API section ends after `health` examples).  
**Inference:** Any «full product» contract for file flows must be assembled from code, tests, or non-`docs/` reports — not from the primary Russian service README.

---

### High — Explanation for server error `input_file is required` (docs vs code)

- **embed-client documentation** does **not** define the error string `input_file is required` as a first-class troubleshooting entry. The **intended** behavior is: if using inbound transfer, the client does **not** send `input_file` (see `docs/api_format.md`).

- **embed service implementation** (read for alignment; **not** user docs): `EmbedFileCommand.validate_params` rejects missing/empty `input_file` with **`InvalidParamsError("input_file is required")`** (`embed/commands/embed_file_command.py`, `validate_params`).

**Proven fact:** Exact error text and trigger (`if not params.get("input_file")`) in `embed/embed/commands/embed_file_command.py`.  
**Inference:** A client that sends only `transfer_id`/transfer metadata and no resolvable server path matches **embed-client** docs but hits this validation if the worker executes **`EmbedFileCommand`** without a prior step that maps staged bytes to a local path and injects `input_file`. That resolution path is **not** described in **embed**’s public `embed/README.md`.

**Secondary doc citation (troubleshooting narrative, embed-client repo scratch):** `.agent-tactical-debug/coder_auto_7d00_e2e_handoff.md` records live OpenAPI showing `input_file` required and no `transfer_id` in schema — **not** canonical product docs; use as incident report only.

---

### Medium — Flow descriptions: aligned where both sides speak, else one-sided

| Flow | embed-client docs | embed docs |
|------|-------------------|------------|
| Validate local JSON → upload → `embed_file` + `format=json_array` + transfer metadata | `CLI_README.md` (`embed-file-json`), `docs/api_format.md`, `SERVER_MODES_AND_CLIENT.md` | **No** parallel section in `embed/README.md`. Script `scripts/embed_file_smoke_e2e.py` docstring describes «local file → … upload → embed_file → download» (executable narrative, not `docs/`). |
| `embed_file` with file already on server (`input_file`) | `README.md`, `examples/README.md` (`CANONICAL_EMBED_FILE_SERVER_PATH`), `docs/api_format.md` | `reports/orch_tactical_embed_file_probe_research.md` (research report) describes tests using **`input_file`** as server-visible path; **`embed/README.md` does not**. |
| WebSocket / queue completion for `embed_file` | `CLI_README.md` (`--show-progress`), `SERVER_MODES_AND_CLIENT.md` | `docs/EMBED_REQUEST_LIFECYCLE.md` covers **`embed`** push path only — **not** `embed_file` queue + `/ws` (different from file pipeline). |

**Proven fact:** `docs/EMBED_REQUEST_LIFECYCLE.md` title and content refer to `embed(..., wait=True, use_push=True)`, not `embed_file`.  
**Inference:** Readers must not assume the same lifecycle doc applies to `embed_file` without cross-checking client docs or server code.

---

### Low — Terminology and `json_array` shape (embed-client docs vs embed code)

- **embed-client** `docs/api_format.md`: for `format=json_array`, «each with a string **`text`** field per block» (objects).

- **embed** `EmbedFileCommand` uses `_load_json_array` expecting a **top-level JSON array of strings** (`embed/commands/embed_file_command.py`), not objects with a `text` key — this is **implementation**, not stated in `embed/README.md`.

**Proven fact:** embed-client doc wording in `docs/api_format.md` § `embed_file`.  
**Proven fact (code):** `_load_json_array` requires `isinstance(item, str)` for each element.  
**Inference:** Client-side prep (`prepare-embed-file-json` / CLI) may emit objects with `text`; if the server strictly follows current `_load_json_array`, a transform layer or format variant would be required — **this is a code/pipeline alignment question**, not resolved by **embed** public docs (which are silent on `json_array`).

---

## Proven facts (documentation)

1. **embed-client** documents two `embed_file` input modes and points to CLI/programmatic helpers for the upload path (`docs/api_format.md`, `README.md`, `docs/SERVER_MODES_AND_CLIENT.md`, `CLI_README.md`).
2. **embed** `embed/README.md` API section documents three commands (`embed`, `models`, `health`) and does **not** document `embed_file`, upload, or `input_file`.
3. **embed** `docs/EMBED_REQUEST_LIFECYCLE.md` describes the **`embed`** job push lifecycle, not `embed_file`.
4. **embed** internal/research artifacts (e.g. `reports/orch_tactical_embed_file_probe_research.md`, `reports/embed_file_smoke_research.md`) discuss `embed_file` and `input_file` in a test/script context.

---

## Inference (not duplicated as facts)

1. **Gap:** There is **no** single **embed** `docs/*.md` file that mirrors **embed-client**’s stated dual contract for `embed_file`; integration expectations are **asymmetric** across repositories.
2. **Error `input_file is required`:** Explained by **server** `validate_params` requiring `input_file`; **embed-client** user docs do not list this string — users infer from JSON-RPC invalid-params semantics or incident notes.
3. **OpenAPI / schema vs client docs:** If published schema marks only `input_file` required, that aligns with **embed** `EmbedFileCommand` validation and **conflicts** with **embed-client**’s documented inbound-transfer-only payload — **deployment/schema** verification is outside pure doc parity (see `.agent-tactical-debug/coder_auto_7d00_e2e_handoff.md` for a recorded investigation).

---

## File reference index (primary)

### embed-client

| Path | Relevance |
|------|-----------|
| `docs/api_format.md` | `embed_file` params; `input_file` vs staged upload; `upload_file` / `transfer_ack` |
| `README.md` | `embed_file` vs `embed-file-json`; staged transfer metadata; `prepare-embed-file-json` |
| `docs/SERVER_MODES_AND_CLIENT.md` | Local upload + `inbound_transfer`; server `input_file` |
| `CLI_README.md` | `prepare-embed-file-json`, `embed-file-json` pipeline |
| `examples/README.md` | `CANONICAL_EMBED_FILE_SERVER_PATH`, sample JSON, commands |
| `CONFIGURATION.md` | Config (TLS/auth); not a full `embed_file` API spec |

### embed

| Path | Relevance |
|------|-----------|
| `README.md` | Project entry; minimal; no `embed_file` API |
| `embed/README.md` | Service overview; API examples for `embed`/`models`/`health` only — **no `embed_file`** |
| `docs/EMBED_REQUEST_LIFECYCLE.md` | `embed` push lifecycle only |
| `scripts/embed_file_smoke_e2e.py` (module docstring) | Describes upload → `embed_file` → download flow (non-`docs/`) |
| `reports/orch_tactical_embed_file_probe_research.md` | Research: `input_file`, integration test, return shapes |
| `reports/embed_file_smoke_research.md` | Research: smoke script flow with `input_file` / upload |

### embed implementation (alignment only; not «documentation»)

| Path | Relevance |
|------|-----------|
| `embed/commands/embed_file_command.py` | `validate_params`: **`input_file is required`**; executes on filesystem path |

---

## Recommendations (documentation; informational)

1. **embed:** Add a short **`docs/`** page (or extend `embed/README.md`) for **`embed_file`**: required params as implemented, relationship to adapter upload, and pointer to client `embed-file-json` / inbound transfer expectations — to reduce asymmetry with **embed-client**.
2. **embed-client:** Optionally add a troubleshooting line under `docs/api_format.md` noting that some deployments may surface **`input_file is required`** when the server worker does not accept inbound-only params (operational caveat; wording should match support policy).

---

*End of report.*
