# Live acceptance run: `7d-00-48.md`

**Acceptance source:** `/home/vasilyvz/projects/embed-client/7d-00-48.md` only (no sample JSON from `examples/data`).

**Environment:** Repository venv `/home/vasilyvz/projects/embed-client/.venv`. Initial `python -m embed_client` failed with `ModuleNotFoundError: No module named 'mcp_proxy_adapter'` until dependencies were installed:

```bash
cd /home/vasilyvz/projects/embed-client && source .venv/bin/activate && pip install -e ".[dev]"
```

---

## 1. Prepare (Markdown → `json_array` JSON)

**Command (copy-paste):**

```bash
cd /home/vasilyvz/projects/embed-client && source .venv/bin/activate && python -m embed_client prepare-embed-file-json /home/vasilyvz/projects/embed-client/7d-00-48.md -o /home/vasilyvz/projects/embed-client/7d-00-48_embed_file.json
```

**Result:** Exit code **0** (success).  
**Output path printed:** `/home/vasilyvz/projects/embed-client/7d-00-48_embed_file.json`  
**Approximate size:** **1781455 bytes** (`stat -c '%s bytes'`).

---

## 2. Live `embed-file-json` (localhost:8001, mTLS, `--show-progress`)

**Certificates (project convention):**

- `mtls_certificates/client/embedding-service.crt`
- `mtls_certificates/client/embedding-service.key`
- `mtls_certificates/ca/ca.crt`

**Failed attempt (wrong argument order — global flags after subcommand):** argparse error, exit **2**. stderr contained `unrecognized arguments: --host https://localhost ...`

**Successful command (copy-paste):** global `--host` / `--port` / `--timeout` / TLS flags **before** `embed-file-json`:

```bash
cd /home/vasilyvz/projects/embed-client && source .venv/bin/activate && python -m embed_client --host https://localhost --port 8001 --timeout 600 --ssl --cert-file /home/vasilyvz/projects/embed-client/mtls_certificates/client/embedding-service.crt --key-file /home/vasilyvz/projects/embed-client/mtls_certificates/client/embedding-service.key --ca-cert-file /home/vasilyvz/projects/embed-client/mtls_certificates/ca/ca.crt embed-file-json /home/vasilyvz/projects/embed-client/7d-00-48_embed_file.json --show-progress
```

**Result:** Exit code **0** (success).

**Stdout:** Valid JSON object (pretty-printed) — job result with `local_output_path`, checksums, `transfer_ack_result`, etc. (success-shaped payload).

**Stderr — server / progress:** Yes. Lines included WebSocket-style JSON, e.g. `job_processing_step` with `progress_percent`, and `job_completed` with nested `result`.

---

## 3. Validation outcome (`validate_embed_file_job_result` / checklist)

From stderr block `--- embed_file output validation ---`:

- `Artifact source: local_output_path file (...).`
- `Parsed output records from data.results.`
- `Expected embedding dimension: 384 (RPC or payload).`
- `Record count matches input blocks (2).`
- `Body text matches input block order (index-wise).`
- `All embedding / error-field checks passed for parsed rows.`

No `Issues:` list; no `❌ embed_file output validation` messages.

**Validation:** **PASSED**.

---

## 4. Metrics (`format_perf_report_lines` / `EmbedFileJobPerfReport`)

Definitions from code (`embed_client/embed_file_output_validate.py`):

- **`EmbedFileJobPerfReport.total_seconds`:** single `perf_counter` interval over upload, queue wait, download, and ACK (wall-clock).
- **`block_count`:** `N` = number of input blocks from local `json_array` iteration.
- **`mean_seconds_per_block`:** `total_seconds / N` when `N > 0`.
- **`median_seconds_per_block`:** by implementation, equals mean when per-block timings are not available (`median_seconds_per_block` property returns `mean_seconds_per_block`).
- **`blocks_per_second`:** `block_count / total_seconds` when `total_seconds > 0` (reported as “Throughput” and “Mean/Median speed”).

**Values observed on stderr:**

| Metric | Value |
|--------|--------|
| Total wall time (`total_seconds`) | 32.452180 s |
| Input blocks (`block_count`) | 2 |
| Throughput / blocks/s | 0.061629 |
| Mean time per block | 16.226090 s/block |
| Median time per block | 16.226090 s/block |
| Mean speed | 0.061629 blocks/s |
| Median speed | 0.061629 blocks/s |

Median equals mean here, consistent with the report note that only one wall-clock interval is measured and per-block timings are unavailable from this client.

---

## 5. Verdict

| Criterion | Status |
|-----------|--------|
| Prepare from `7d-00-48.md` | **OK** |
| Live embed via mTLS :8001 | **OK** |
| Progress lines on stderr | **Yes** |
| `validate_embed_file_job_result` / checklist | **PASSED** |

**Acceptance on `7d-00-48.md`:** **GREEN**
