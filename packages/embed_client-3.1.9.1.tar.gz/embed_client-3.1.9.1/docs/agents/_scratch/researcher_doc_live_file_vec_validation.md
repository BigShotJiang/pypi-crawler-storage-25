# File vectorization / `embed_file` — docs vs `../embed` contract & client-side validation

**Date:** 2026-03-30  
**Repository:** `/home/vasilyvz/projects/embed-client`  
**Scope:** Documentation and client code only (normative server wire/schema for full output JSON lives in **`../embed`**, not vendored here).

---

## 1. Documentation overview

| Topic | Where it is documented in embed-client | Notes |
|--------|----------------------------------------|--------|
| **`embed_file` RPC params** | `docs/api_format.md` (§ JSON-RPC `embed_file`) | `input_file`, `format` (`lines` \| `json_array`), optional `model`, `dimension`, `device`, `error_policy`; staged file → `upload_file` → `get_upload_session` → **`storage_path` as `input_file`**. |
| **Input `json_array` shape** | `docs/api_format.md`, `docs/SERVER_MODES_AND_CLIENT.md`, `CLI_README.md`, `README.md`, `CONFIGURATION.md` (`EMBED_CLIENT_MAX_JSON_BLOCK_BYTES`) | **UTF-8 JSON file whose root is a non-empty array of strings** (one text block per element). |
| **Local pipeline (no shared server disk)** | `docs/SERVER_MODES_AND_CLIENT.md` § Local file upload; `CLI_README.md` (`prepare-embed-file-json`, `embed-file-json`); `README.md` | Validate → upload → `get_upload_session` → `embed_file` with `format=json_array`. Matches `embed_client/local_json_embed_file.py`. |
| **Response / result shape of `embed_file`** | **Partially** | `docs/api_format.md` describes **`embed`** batch results (`results[]`, `dimension`, etc.), **not** the **`embed_file` job completion payload** or the **downloaded output JSON file** layout. |
| **Reference server contract (`../embed`)** | Not in-tree; cross-referenced in scratch research | `docs/agents/_scratch/researcher_code_embed_file_contract_alignment.md` maps: `embed/commands/embed_file_command.py` (params, `_load_json_array`), `embed/embed_file_line_chunks.py`, `embed/services/embed_file_transfer.py`, `embed/services/embed_file_incremental.py` (incremental output), `embed/client/embedding_client.py`. |

**Quality note:** Older scratch files (e.g. `orch_tactical_debug_embed_compare_research_code.md`) may claim **`[{"text": ...}]`** or **`inbound_transfer`** without `input_file`. **Current** `embed_client/json_embed_file_preflight.py` validates **array of strings**; `embed_client/local_json_embed_file.py` uses **`storage_path` → `embed_file(..., input_file=..., file_format="json_array")`**; `embedding_client.py` has **no** `inbound_transfer` branch. Treat stale scratch lines as superseded by current code + `docs/api_format.md`.

---

## 2. Request contract (aligned docs + code)

| Field | Documented | Code |
|--------|------------|------|
| `input_file` | Server-visible path | `EmbeddingClient.embed_file` (`embed_client/embedding_client.py`) always sends `input_file` and `format` in params. |
| `format` | `lines` \| `json_array` | Same (`file_format` → `"format"`). |
| `json_array` file content | Array of strings per `docs/api_format.md` | `validate_local_json_embed_file` enforces non-empty array, each element `str`, UTF-8 byte length ≤ cap (`json_embed_file_preflight.py`). |
| `model`, `dimension`, `device`, `error_policy` | Same semantics as `embed` (`docs/api_format.md`, `embedding_client` docstrings) | Passed through to JSON-RPC params (`embedding_client.py`). |

**Reference (`../embed`):** `EmbedFileCommand` / `_load_json_array` — items must be **strings** (`researcher_code_embed_file_contract_alignment.md`).

---

## 3. Response schema (job completion + file)

### 3.1 What embed-client documents

- **`docs/api_format.md`**: detailed **`embed`** success shape only; for **`embed_file`** it lists params and upload flow, not **`result.data`** after job completion.
- **`EmbeddingClient.embed_file` docstring** (`embedding_client.py`): queue job; when `wait=True`, waits on WebSocket; may **download** via outbound transfer id; **`transfer_ack`**; returns merged job **`data`**, optional **`local_output_path`**, **`transfer_ack_result`**.
- **Submit response:** JSON-RPC `result.success`, nested `job_id` / `data` (same file as `_embed_file_queue_result_error_message`, `_normalize_terminal_job_payload`).

### 3.2 What the client actually validates (post-job)

| Check | Purpose |
|--------|---------|
| `success: false` / error in normalized WS payload | `_embed_file_queue_result_error_message` |
| Optional **`local_source_path`**: SHA-256 vs **`input_checksum_value`** in job data | Ensures uploaded bytes match what server hashed |
| **`download_file`** then SHA-256 vs **`checksum_value`** | Ensures downloaded artifact matches server metadata |
| **`skip_download`**: requires **`checksum_value`** present | No local file to hash |
| **`transfer_ack`** with `outbound_transfer_id`, `checksum_*`, optional `job_id` | Adapter/server cleanup contract |

### 3.3 Output JSON file (blocks, embeddings, dimensions, ordering)

- **Not** specified in `docs/api_format.md`. For **semantic** definition of the **written** embedding JSON (per-block embeddings, ordering, dimensions), the **source of truth** is the **`../embed`** service (e.g. incremental/output helpers referenced in `researcher_code_embed_file_contract_alignment.md`: `embed_file_incremental.py`).
- **Ordering:** Input **`json_array`** is a **JSON array**; server and client **iterate in array index order** (`iter_json_array_block_texts` returns strings in order). Any **output** ordering is expected to follow **input block order** for a well-behaved server; **client-side proof** requires parsing the downloaded JSON against **`../embed`** schema (not duplicated in embed-client docs).

### 3.4 `dimension`

- **Request:** optional RPC param `dimension` (same as `embed`).
- **Response:** `docs/api_format.md` documents **`dimension`** on the normalized **`embed`** return dict, not explicitly on **`embed_file`** completion. Whether job completion **`data`** or the **downloaded file** includes **`model`/`dimension`** depends on server; **validate client-side** only if the consumer parses the output JSON / job payload and compares to requested `dimension` / model metadata.

---

## 4. What can be validated client-side (checklist)

**Before network (local input file)**

1. Path exists, readable; UTF-8 (with optional BOM) — `validate_local_json_embed_file`.
2. Valid JSON; root is `[` … `]`; **non-empty** array.
3. Every element is a **`str`** (not `{"text": ...}` — that would fail validation and **`../embed`** `_load_json_array`).
4. Each string’s UTF-8 byte length ≤ **`EMBED_CLIENT_MAX_JSON_BLOCK_BYTES`** / CLI `--max-block-bytes` / `DEFAULT_MAX_JSON_EMBED_BLOCK_BYTES`.
5. **Markdown prep** (`md_embed_file_prep.py`): produces **`List[str]`** written as JSON array; chunk order is deterministic (split order).

**After job (integrity)**

6. **`input_checksum_value`** vs local file SHA-256 when `local_source_path` set (upload path).
7. **`checksum_value`** vs downloaded file SHA-256 when download runs.
8. **`transfer_ack`** success (if required by deployment).

**Semantic / schema (optional, requires spec)**

9. Parse downloaded JSON and assert **number of blocks** equals input array length (if server guarantees 1:1).
10. Assert each embedding vector **length** equals expected **dimension** (from request or from payload).
11. **Ordering:** compare block indices or embedded IDs **if** the output format includes them (`../embed` schema).

---

## 5. Consistency & gaps

| Issue | Detail |
|--------|--------|
| **`embed_file` output JSON** | No normative schema in durable `docs/`; rely on **`../embed`** + integration tests there. |
| **`docs/api_format.md` vs `embed`** | Readers may confuse **`embed`** `results[]` documentation with **`embed_file`**; only **`embed`** section describes per-item `embedding` / `error` alignment. |
| **Scratch docs** | Some files still describe obsolete `text`-object rows or `inbound_transfer-only` RPC; **current** implementation is **strings + `storage_path` → `input_file`**. |

---

## 6. File references (embed-client)

| Path | Relevance |
|------|-----------|
| `docs/api_format.md` | `embed_file` params; `json_array` = array of strings; upload/session pattern. |
| `docs/SERVER_MODES_AND_CLIENT.md` | Local upload vs server path; CLI/programmatic pointers. |
| `CLI_README.md` | `prepare-embed-file-json`, `embed-file-json`, flags (`--dimension`, checksum/download). |
| `README.md` | High-level `embed_file` vs `embed-file-json` / `embed_file_from_local_json_file`. |
| `CONFIGURATION.md` | `EMBED_CLIENT_MAX_JSON_BLOCK_BYTES`. |
| `embed_client/embedding_client.py` | `embed_file`, `embed_file_from_local_json_file`; checksums, download, `transfer_ack`. |
| `embed_client/json_embed_file_preflight.py` | Local validation rules for `json_array`. |
| `embed_client/local_json_embed_file.py` | Upload → `get_upload_session` → `embed_file`. |
| `embed_client/md_embed_file_prep.py` | Markdown/plain text → array of strings. |
| `examples/data/embed_file_json_array_sample.json` | Sample input shape. |
| `docs/agents/_scratch/researcher_code_embed_file_contract_alignment.md` | **`../embed`** file map and historical mismatch notes (verify against current code). |

---

## 7. Key findings (orchestrator summary)

- **Aligned with `../embed` for input:** non-empty JSON **array of strings**; `embed_file` with **`input_file`** + **`format=json_array`** after staging resolves **`storage_path`**.
- **Durable docs do not define** the **`embed_file` output JSON** schema (blocks/embeddings/dimensions); **`docs/api_format.md`** focuses on **`embed`** for vector shapes.
- **Client-side validation** is strong for **input file structure and size**, **byte integrity** (checksums), and **ACK**; **semantic** validation of embeddings (dimension count, order vs input) needs **output format spec from `../embed`** or parsed JSON checks.

---

*End of report.*
