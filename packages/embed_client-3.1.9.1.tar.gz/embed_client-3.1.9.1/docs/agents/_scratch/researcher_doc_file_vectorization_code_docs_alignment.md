# File vectorization — documentation vs code & examples (alignment report)

**Repository:** embed-client  
**Scope:** `docs/`, `examples/`, root `README.md`, `CLI_README.md`, `CONFIGURATION.md`  
**Code cross-check (read-only):** `embed_client/cli.py`, `cli_core.py`, `embedding_client.py`, `local_json_embed_file.py`, `json_embed_file_preflight.py`  
**Date:** 2026-03-30

---

## 1. Where file-related vectorization is mentioned (vs behavior)

| Location | What is described | Match to implementation |
|----------|-------------------|-------------------------|
| **README.md** | Optional canonical E2E: `CANONICAL_EMBED_FILE_SERVER_PATH` → `embed_file` on **server-visible** path; paragraph distinguishing **`embed_file` + `input_file`** vs **`embed-file-json` / `embed_file_from_local_json_file`** (validate → upload → `embed_file` `json_array`) | **Aligned** with `canonical_mtls_localhost_8001.py` and `EmbeddingClient.embed_file` / `embed_file_from_local_json_file`. |
| **CLI_README.md** | `embed-vectorize`: `vectorize` (incl. `--file`); separate **`embed-file-json`**: local UTF-8 JSON array, per-block limit (`EMBED_CLIENT_MAX_JSON_BLOCK_BYTES` / `--max-block-bytes`), adapter upload, server **`embed_file`** `format=json_array`; contrast with **`vectorize --file`** → line-based → **`embed`** | **Aligned** with `cli.py` (file reads non-empty stripped lines → `vectorize_texts` → `client.embed`) and `embed_file_local_json` → `embed_file_from_local_json_file`. |
| **CONFIGURATION.md** | **`EMBED_CLIENT_MAX_JSON_BLOCK_BYTES`** — client-side validation before **`embed_file`** (`json_array`); same adapter transport/auth as JSON-RPC for upload | **Aligned** with `json_embed_file_preflight.resolve_max_json_block_bytes` / `validate_local_json_embed_file` and `local_json_embed_file.embed_file_from_local_json_file`. |
| **docs/api_format.md** | **`embed_file`**: exactly one of (1) **`input_file`** on server, (2) **staged upload** via **`upload_file`** → params from **`TransferReceipt`** / **`inbound_transfer`**; `format` `lines` \| `json_array`; CLI **`embed-file-json`**; **`EmbeddingClient.embed_file_from_local_json_file`** | **Aligned** with `EmbeddingClient.embed_file` (XOR `input_file` / `inbound_transfer`) and local JSON pipeline. |
| **examples/README.md** | §1: canonical mTLS + optional **`embed_file`** via env; §2: **`embed-file-json`** with **`examples/data/embed_file_json_array_sample.json`** | **Aligned**; sample file exists on disk. |
| **examples/canonical_mtls_localhost_8001.py** | Documents **`embed_file`** only when **`CANONICAL_EMBED_FILE_SERVER_PATH`** set (server path); does **not** demo upload/`embed-file-json` | **Aligned** — intentional subset of API surface. |
| **docs/SERVER_MODES_AND_CLIENT.md** | *(grep: no `embed_file`, `embed-file`, `json_array`, `vectorize`)* | **Gap** — security modes doc does not mention file/transfer flows. |

**Note:** The term **“file vectorization”** does not appear as a defined glossary term; docs use **`embed_file`**, **`embed-vectorize`**, **`embed-file-json`**, and **`vectorize --file`** precisely.

**Stale material:** Older notes under `docs/agents/_scratch/researcher_doc_file_vectorization_docs_examples_report.md` and `researcher_doc_file_vectorization_adapter_audit.md` still claim **`docs/api_format.md`** omits the **inbound transfer** path — **that is outdated**; current `docs/api_format.md` §`embed_file` lists both modes.

---

## 2. Gaps or contradictions (documentation perspective)

- **`docs/SERVER_MODES_AND_CLIENT.md`**: No coverage of adapter **file upload**, **`embed_file`**, or how TLS/auth apply to transfer HTTP — operators comparing modes get no file-pipeline context (CONFIGURATION partially fills this via one env var only).
- **`embed_file` `format=lines`**: API doc lists **`lines`** \| **`json_array`**. The **CLI** documents **`embed-file-json`** only for **`json_array`**. Not a contradiction — but readers may miss that **server-path** **`embed_file`** with **`lines`** is API/client-method only unless they use **`EmbeddingClient.embed_file(..., file_format="lines")`** (not exposed as a dedicated CLI subcommand).
- **Programmatic API discoverability:** README references **`embed_file_from_local_json_file`** as a method on **`EmbeddingClient`** (correct). It is **not** re-exported from **`embed_client.__init__`** `__all__` — acceptable but worth knowing for doc readers expecting a top-level import.
- **Preflight module naming:** **`json_embed_file_preflight`** is detailed in code/docstrings; durable user docs say “validates” without pointing to the module name — minor discoverability gap, not a behavior mismatch.

**No material contradiction** found between **CLI_README**, **README**, **api_format**, and the **embed-file-json** / **`vectorize --file`** code paths.

---

## 3. Recommendations (doc / examples updates)

- Add a **short subsection** to **`docs/SERVER_MODES_AND_CLIENT.md`**: JSON-RPC and adapter **file upload** use the same TLS/auth profile as other adapter HTTP; reference **`embed_file`** input modes and **`EMBED_CLIENT_MAX_JSON_BLOCK_BYTES`** with a link to **CONFIGURATION.md** / **CLI_README.md**.
- In **CONFIGURATION.md** “Environment variables”, add one **cross-link** to **`CLI_README.md`** **`embed-file-json`** so operators connect env tuning to the CLI entry point.
- Optionally add **`examples/embed_file_json_local.py`** (minimal `asyncio` script calling **`EmbeddingClient.embed_file_from_local_json_file`**) mirroring §2 of **examples/README.md** — improves parity with “runnable documentation” style of **`canonical_mtls_localhost_8001.py`** for the **upload** path.
- Optionally extend **canonical** tour documentation (**README** / **examples/README**) with one line: **`embed-file-json`** is **not** part of **`canonical_mtls_localhost_8001.py`** (by design); use §2 + sample JSON for local **`json_array`** without a server-shared file.
- **Housekeeping:** Archive or refresh **`docs/agents/_scratch/researcher_doc_file_vectorization_docs_examples_report.md`** / **`researcher_doc_file_vectorization_adapter_audit.md`** so they do not assert **`api_format`** is incomplete — **current tree is fixed**.

---

## 4. Orchestrator handoff

**Single response file for orchestrator `Read`:**

`/home/vasilyvz/projects/embed-client/docs/agents/_scratch/researcher_doc_file_vectorization_code_docs_alignment.md`
