# File vectorization — client-side network adapter audit (`embed_client`)

**Repository:** `/home/vasilyvz/projects/embed-client`  
**Scope:** All **file-vectorization-related** flows: local JSON → `embed_file` (`json_array`), direct `embed_file` (server path or `inbound_transfer`), CLI `embed-file-json`, CLI `vectorize --file` (line-based embed, not `embed_file`), optional status-store / ancillary APIs reachable from these flows.  
**Adapter definition:** `mcp_proxy_adapter.client.jsonrpc_client.JsonRpcClient` (and its methods: `jsonrpc_call`, `upload_file`, `download_file`, `wait_for_job`, `wait_for_job_via_websocket`, `execute_async`, `get_async_http_client`, `health`, `get_openapi_schema`, `get_job_messages`, `clear_job_tracking`, `queue_*`, etc.).  
**Date:** 2026-03-30

---

## Executive summary

| Severity | Finding |
|----------|---------|
| **Highest (network bypass of adapter)** | **None.** Every HTTP/WebSocket operation in the audited file-vectorization paths is implemented **only** via `EmbeddingClient.client` (`JsonRpcClient`). There is no `requests`, `urllib.request`, `aiohttp`, or raw `socket` usage in `embed_client` for these flows. |
| **Medium (local I/O only)** | Preflight validation, CLI file reads, and SHA-256 verification use **local filesystem** only — not “adapter bypass” for network; they are expected. |
| **Low (behavioral / not embed_file path)** | `wait_for_job` can fall back to **HTTP polling** via `job_status` when `JsonRpcClient.wait_for_job` is missing — **not** used by `embed_file` completion (see below). |

---

## Flow map (call chains)

### A. Local JSON array → server (`embed_file` with `inbound_transfer`)

1. `EmbeddingClient.embed_file_from_local_json_file` → `embed_client.local_json_embed_file.embed_file_from_local_json_file`
2. `validate_local_json_embed_file` (local read, no network)
3. `client.client.upload_file(...)` — **adapter**
4. `client.embed_file(inbound_transfer=receipt, local_source_path=..., file_format="json_array", ...)` — **adapter** RPC + WS + optional download + ACK

### B. CLI `embed-file-json`

`embed_client.cli` → `VectorizationCLI.embed_file_local_json` → same as chain A.

### C. Direct `embed_file` (server-side `input_file` or pre-staged `inbound_transfer`)

No upload in `embed_client` when only `input_file` is set; RPC/WS/download/ACK same as step 4 in chain A.

### D. CLI `vectorize --file` (related “file + vectorization”, **not** `embed_file`)

`cli.py` reads lines locally → `vectorize_texts` → `EmbeddingClient.embed` → `_embed_via_execute_async` → `client.execute_async("embed_execute", ...)` — **adapter** (WS result delivery per docstring).

### E. Optional: `examples/canonical_mtls_localhost_8001.py`

Calls `EmbeddingClient.embed_file` with server path when env is set — same as chain C.

---

## Operations ordered by severity

### 1. Network bypass of `JsonRpcClient` (highest severity)

**No entries.** Grep across `embed_client/` found no `requests`, `urllib.request`, `aiohttp`, or direct `socket` usage. Comment references to `httpx` are in docstrings pointing at the adapter’s shared client (`get_async_http_client`).

### 2. Adapter-based network operations (reference list — file-vectorization flows)

| File:line | Operation | Role | Adapter? |
|-----------|-----------|------|----------|
| `local_json_embed_file.py:39` | `await client.client.upload_file(ap, filename=upload_filename)` | Upload local JSON bytes to staging; yields `TransferReceipt` | **Yes** |
| `embedding_client.py:959` | `await self.client.jsonrpc_call("embed_file", params)` | Submit `embed_file` queue job (transfer metadata or `input_file`) | **Yes** |
| `embedding_client.py:748-752` | `await self.client.wait_for_job(job_id, timeout=..., on_event=...)` | Primary path: wait for terminal job event over **WebSocket** | **Yes** |
| `embedding_client.py:765-768` | `await self.client.wait_for_job_via_websocket(...)` | Fallback when `wait_for_job` absent: still **adapter** WS API | **Yes** |
| `embedding_client.py:1059` | `await self.client.download_file(tid, local_path)` | Download outbound result JSON when `outbound_transfer_id` / `transfer_id` present and `skip_download` is false | **Yes** |
| `embedding_client.py:1092` | `await self.client.jsonrpc_call("transfer_ack", ack_params)` | Acknowledge transfer (server may delete temp file) | **Yes** |

### 3. Local-only operations (not network; listed to avoid false “bypass” reports)

| File:line | What | Notes |
|-----------|------|--------|
| `json_embed_file_preflight.py:62-66` (and reads in `iter_json_array_block_texts`) | `open` / `read` local file | Preflight |
| `json_embed_file_preflight.py:81-84` | `json.loads` | Preflight |
| `local_json_embed_file.py:37` | `validate_local_json_embed_file` | Before upload |
| `embedding_client.py:51-56`, `1023`, `1066` | `_sha256_hex_file` | Verify local file vs server checksums |
| `cli.py:302-310` | `run_in_executor` + read `--file` lines | Feeds `vectorize`, not `embed_file` |
| `embedding_client.py:273-274` | `urllib.parse.urlparse` in `from_base_url_port` | **URL parsing only**, no I/O |

### 4. Related APIs (same `EmbeddingClient`; adapter; not always invoked in minimal `embed_file` path)

| File:line | Operation | Adapter? |
|-----------|-----------|----------|
| `391-428`, `431-453`, `455-490` | `get_embed_file_status_snapshot`, `aget_embed_file_status_snapshot`, message listers | **Yes** when `get_job_messages` exists (`client.get_job_messages`) |
| `492-504` | `clear_embed_file_status` | Local store + optional `client.clear_job_tracking` (**Yes**) |
| `516-523` | `health` → `client.health()` | **Yes** (CLI `health` command uses this) |
| `637-678` | `wait_for_job` | **Yes** WS path, or **Yes** poll via `job_status` → `jsonrpc_call` |
| `803-852` | `job_status` | `jsonrpc_call("queue_get_job_status")` then `jsonrpc_call("embed_job_status")` — **Yes** |
| `681-723` | `_embed_via_execute_async` | `execute_async` — **Yes** (`vectorize` wait path) |
| `778-801` | `open_bidirectional_ws_channel` | Re-exports adapter helper with `self.client` — **Yes** |
| `1245-1247` | `close` → `client.close()` | **Yes** |
| `1248-1255` | `fetch_openapi_schema` | **Yes** |
| `1257-1274` | `http_get` | Uses `get_async_http_client()` + `.get()` — **Yes** (shared httpx client) |

### 5. `embed_file` vs HTTP poll fallback

- **`embed_file` completion** uses only `_wait_for_job_via_adapter_ws` (`embedding_client.py:1012-1014`), which calls **either** `wait_for_job` **or** `wait_for_job_via_websocket` — both on `JsonRpcClient`. **No** `wait_for_job_poll` / `job_status` loop in the `embed_file` path.
- **`wait_for_job` (`637-678`)** HTTP polling via `embedding_client_helpers.wait_for_job_poll` applies to **generic** queue jobs when the adapter lacks async `wait_for_job` — relevant to `queue-wait` CLI / direct `wait_for_job` calls, **not** to `embed_file` wait logic.

---

## Exact operations audited (checklist)

- [x] `embed_client/local_json_embed_file.py` — full file  
- [x] `embed_client/json_embed_file_preflight.py` — full file  
- [x] `embed_client/embedding_client.py` — `embed_file`, `embed_file_from_local_json_file`, `_wait_for_job_via_adapter_ws`, status store helpers, `wait_for_job`, `job_status`, `close`  
- [x] `embed_client/cli.py` — `vectorize` (incl. `--file`), `embed-file-json`  
- [x] `embed_client/cli_core.py` — `embed_file_local_json`, `vectorize_texts`, `connect`/`health_check`  
- [x] `embed_client/embedding_client_helpers.py` — `wait_for_job_poll` (reachability from `embed_file`)  
- [x] `embed_client/constants.py` — no network primitives  
- [x] `embed_client/` grep: `upload_file`, `download_file`, `jsonrpc`, `httpx`, `requests`, `urllib`, `websocket`  

---

## Residual exceptions / notes

1. **Dependency boundary:** All wire protocol details (TLS, headers, WS subscription, transfer HTTP endpoints) live in **`mcp_proxy_adapter`**; this repo only orchestrates calls on `JsonRpcClient`. Auditing the adapter package itself is out of scope for this file.
2. **Cannot be “adapter-based” by design:** Local validation (`json_embed_file_preflight`), local SHA-256 checks, and CLI line-file reading must remain local FS operations.
3. **Status snapshot consistency:** If `get_embed_file_status_snapshot` is used **under a running event loop** while the adapter tracks WS in the registry, the docstring directs callers to `aget_embed_file_status_snapshot` — this is **API usage**, not a network bypass.
4. **`vectorize --file`** does **not** call `embed_file`; it uses **`embed` → `execute_async("embed_execute", ...)`** when `wait=True`. Still **adapter-only** for network.

---

## Verdict

**All client-side network operations on the audited file-vectorization paths go through the embedding adapter (`JsonRpcClient`).** No severity-1 bypasses were found in `embed_client`.
