# Research (researcher_doc): vectorization, `embed_file`, adapter alignment

**Scope:** Read-only review of `docs/PROJECT_RULES.md`, release-validation specs, `docs/agents/*`, root `README.md`, and related user-facing docs; cross-check with `embed_client/embedding_client.py` and `examples/canonical_mtls_localhost_8001.py`.  
**Date:** 2026-03-30.

---

## Documentation overview

Project documentation consistently distinguishes **three** ways to get “file-related” vectorization:

1. **Server-side path (`embed_file` RPC):** client sends a **path string**; the **server** reads the file. No upload of file content in the canonical tour (`README.md`, `examples/README.md`, `docs/agents/project_overlay.md`, RV-04 atomic steps).
2. **Client reads local lines → `embed`:** `embed-vectorize vectorize --file` (CLI `CLI_README.md`).
3. **Operational note:** a path valid on the **client** checkout is **not** sufficient for `embed_file` unless the same path is visible on the **server** (scratch note `docs/agents/_scratch/orch_tactical_debug_7d00_embed_file_vectorization.md`).

**Adapter role** is stated at a high level: JSON-RPC and queue via **`mcp-proxy-adapter`**’s `JsonRpcClient` (`README.md`, `docs/agents/project_overlay.md`). Deeper behavior (WebSocket job completion, HTTP file transfer for outputs) is documented primarily in **code docstrings**, not in the same depth in root `README.md` / `CONFIGURATION.md`.

---

## Consistency analysis

| Topic | Finding |
|--------|---------|
| **Server path vs upload** | `README.md` (lines 31–32), `examples/README.md` (lines 9–10), `docs/agents/project_overlay.md` (lines 21–22), and `docs/specs/.../rv04-execute-canonical-mtls-real-server-gate.md` all agree: **`CANONICAL_EMBED_FILE_SERVER_PATH`** is a **server-visible** path; no contradiction. |
| **Queue / WebSocket** | `docs/SERVER_MODES_AND_CLIENT.md` says queue mode may use **`embed_job_status`** polling; `README.md` and `EmbeddingClient` docstring state **`embed`** uses **WebSocket when available**. This is a **simplification vs implementation**, not a direct contradiction (implementation prefers WS for job completion). |
| **RV-04 line references** | `docs/specs/.../steps/rv04-execute-canonical-mtls-real-server-gate.md` cites `examples/canonical_mtls_localhost_8001.py` lines **196–198** for the skip substring. In the current file, the **skip message text** spans **197–198**; line **196** is `lines.append(`. The **skip** substrings **`embed_file skipped`** and **`CANONICAL_EMBED_FILE_SERVER_PATH`** appear in **197**. Minor **line-number drift** in the spec table vs. current source. |

---

## Completeness assessment

| Gap | Detail |
|-----|--------|
| **Outbound transfer / `download_file`** | `embed_client/embedding_client.py` `embed_file` docstring documents: after the job, if the result includes an **outbound transfer id**, the client uses **`JsonRpcClient.download_file`** and **`transfer_ack`** (`embedding_client.py`, `embed_file` docstring ~lines 875–879). **`README.md`**, **`examples/README.md`**, and **`CONFIGURATION.md`** do **not** describe this download/ACK path for operators running the canonical example. |
| **Client-side file → server** | Same docstring states: to embed a file from the **client** machine, **upload first** (e.g. `JsonRpcClient.upload_file` or `execute_command_with_file`) then pass the server path. This **recovery path** is absent from **`README.md`** / **`examples/README.md`** (they only describe server-visible path + `CANONICAL_EMBED_FILE_SERVER_PATH`). |
| **`CONFIGURATION.md`** | No mention of **`embed_file`**, WebSocket, or transfer APIs — configuration-focused docs do not cover this API surface. |
| **WebSocket frame / message size limits** | No durable project doc under `docs/` (reviewed tree) states **WS payload size limits** or failure modes tied to large **`embed_file`** results. `docs/IDENTIFIER_ANALYSIS_REPORT.md` mentions lack of identifiers for WS channels / JSON-RPC for **debugging**, not size limits. |
| **`7d-00` / `7d-00-48.md`** | Referenced only in **scratch** (`docs/agents/_scratch/orch_tactical_debug_7d00_embed_file_vectorization.md`) as an example client-only path; **not** in `PROJECT_RULES.md`, `README.md`, or release specs. |

---

## Code-documentation alignment

### Canonical example (`embed_file` branch)

- **Docs:** RV-04 and `examples/README.md` require **`RUN_CANONICAL_MTLS_E2E=1`** for live calls and optional **`CANONICAL_EMBED_FILE_SERVER_PATH`** for `embed_file`.
- **Code:** `examples/canonical_mtls_localhost_8001.py` calls `client.embed_file(..., wait=True, wait_timeout=600, error_policy="continue")` when path is set (lines 203–208); skip message when unset (lines 194–199). **Aligned** with documented behavior and skip contract.

### `EmbeddingClient.embed_file` vs marketing docs

- **Code:** Full pipeline = JSON-RPC **`embed_file`** → wait via **adapter WebSocket** → optional **HTTP download** of result JSON by transfer id → **`transfer_ack`** (`embedding_client.py`).
- **User-facing README layer:** Describes **input** as server path only; does **not** document **output** download or optional **`local_source_path`** checksum verification. **Partial documentation** of the public method (acceptable if docstrings are the API contract, but **not** a full match between README and method semantics).

### Adapter responsibilities (intent vs code)

| Documented intent (high level) | Code behavior |
|--------------------------------|----------------|
| Transport via **`mcp-proxy-adapter`** / `JsonRpcClient` | `EmbeddingClient` constructs `JsonRpcClient`; uses **`jsonrpc_call`**, **`wait_for_job`** / **`wait_for_job_via_websocket`**, **`download_file`** (`embedding_client.py`). |
| “File vectorization” in README/examples | Emphasizes **server reads `input_file`**; **does not** state that **adapter HTTP** is used for **outbound** JSON **after** the job. |
| **Inbound** file to server | Not part of **`embed_file` RPC`**; code documents **upload** as a **separate** step (`embedding_client.py` docstring). |

**Conclusion:** Docs are **accurate** that the **RPC does not upload** the input file. They are **incomplete** relative to code regarding **post-job file transfer** (download + ACK) and **upload-then-path** workflows.

---

## Structural issues

- Release-validation specs (`docs/specs/server_client_convergence_and_release/release_validation_and_pypi_publication/`) are **coherent** on RV-02 vs RV-04 and **`embed_file`** gating (`rv_canonical_mtls_real_server_gate/spec.md`, `rv04-execute-canonical-mtls-real-server-gate.md`).
- **`docs/SERVER_MODES_AND_CLIENT.md`** omits **`embed_file`** entirely; readers relying only on that file miss the server-path vs client-file distinction.

---

## Key findings (focused)

1. **Adapter file transfer:** User-facing docs describe **adapter** as **JSON-RPC + queue**; **code** adds **WebSocket** completion and **HTTP `download_file` + `transfer_ack`** for **`embed_file`** outputs. **Intent** in short docs = “server reads path”; **full behavior** includes **outbound** transfer — **underdocumented** outside `embedding_client.py`.
2. **WebSocket size limits:** **No** matching statements in reviewed `docs/` (no operational note on max frame/message size for `embed_file` or generic WS).
3. **`7d-00` failures:** **No** durable spec tying **`7d-00-48.md`** or **`7d-00`** to failures; only **scratch** orchestration note explains client-only path vs **`embed_file`** (`docs/agents/_scratch/orch_tactical_debug_7d00_embed_file_vectorization.md`).

---

## Recommendations (for doc maintainers; not applied by researcher_doc)

1. Optionally extend **`README.md`** or **`examples/README.md`** with one sentence: successful **`embed_file`** may **download** result JSON via the adapter and **ACK** the transfer (point to `embed_client/embedding_client.py` or `CONFIGURATION.md` if extended).
2. Fix **RV-04** atomic step line reference if the spec requires **exact** line numbers (currently **197–198** carry the skip string; **196** is `lines.append(`).
3. If WS limits matter for operators, add a **server/adapter** note (likely outside this repo or in adapter docs) — **not present** here.

---

## Citations (paths reviewed)

| Path | Relevance |
|------|-----------|
| `docs/PROJECT_RULES.md` | Layout, CR rules; **no** vectorization/adapter detail. |
| `README.md` | Canonical mTLS, **`CANONICAL_EMBED_FILE_SERVER_PATH`**, `embed_file` optional. |
| `docs/agents/project_overlay.md` | **`JsonRpcClient`**, canonical example env vars. |
| `docs/agents/universal_project_context.md` | Pointer to `PROJECT_RULES.md` only. |
| `docs/SERVER_MODES_AND_CLIENT.md` | **`embed`**, queue; **no** `embed_file`. |
| `CLI_README.md` | **`vectorize --file`** vs API `embed_file`. |
| `docs/specs/.../release_validation_and_pypi_publication/steps/rv04-execute-canonical-mtls-real-server-gate.md` | Full RV-04 procedure, skip line contract. |
| `docs/specs/.../rv_canonical_mtls_real_server_gate/spec.md` | **`embed_file`** gate semantics. |
| `docs/specs/.../steps/rv02-execute-localhost-vectorization-mtls-8001.md` | RV-02 smoke (no `embed_file`). |
| `examples/README.md` | Env vars for canonical example. |
| `embed_client/embedding_client.py` | Authoritative **`embed_file`** + adapter WS/transfer behavior. |
| `examples/canonical_mtls_localhost_8001.py` | Skip/success **`embed_file`** lines. |
| `docs/agents/_scratch/orch_tactical_debug_7d00_embed_file_vectorization.md` | **`7d-00-48`** + server vs client path (scratch). |

---

## Appendix: `PROJECT_RULES.md` and vectorization

`docs/PROJECT_RULES.md` does **not** contain operational statements about **`embed_file`**, vectorization, or adapters beyond generic **`docs/`** layout (**LAYOUT-08**, **LAYOUT-09**).
