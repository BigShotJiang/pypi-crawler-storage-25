# File vectorization (client) — network operations audit

**Scope:** Client-side flow for **local JSON array → upload → `embed_file` (json_array)** in repository `embed-client`.  
**Entry points reviewed:** `embed_client/local_json_embed_file.py`, `embed_client/json_embed_file_preflight.py`, `embed_client/embedding_client.py`, `embed_client/cli_core.py`, `embed_client/cli.py`, `embed_client/embedding_client_helpers.py`, `embed_client/client_factory.py`, `embed_client/adapter_config_factory.py` (imports only for wiring).

**Abstraction definition:** “Adapter-routed” means traffic goes through `EmbeddingClient.client`, an `mcp_proxy_adapter.client.jsonrpc_client.JsonRpcClient` instance (HTTP client, JSON-RPC, file transfer, WebSocket helpers). **Bypass** would mean direct use of `httpx`/`aiohttp`/`urllib`/`socket` in this repo for the same flow — **none found**.

**External package:** Actual TLS/HTTP/WebSocket implementation lives in **`mcp_proxy_adapter`** (not vendored in this repo). From this codebase’s perspective, all remote I/O for the flow below is **adapter-only**.

---

## 1) Findings by severity

### High — bypass of adapter in file-vectorization flow
**None.** No network calls in the local-JSON `embed_file` chain bypass `JsonRpcClient`.

### Medium — alternate paths (not used by `embed_file` local JSON, but related)
- **`EmbeddingClient.wait_for_job`** (`embedding_client.py`) may fall back to **`wait_for_job_poll`** → **`job_status`** → `jsonrpc_call("queue_get_job_status" | "embed_job_status")` when `JsonRpcClient.wait_for_job` is **missing**. That is still **adapter JSON-RPC (HTTP)**, not a bypass — but it is **HTTP polling instead of WebSocket**. This path is **not** invoked by **`embed_file`** / **`embed_file_from_local_json_file`**, which always use **`_wait_for_job_via_adapter_ws`** (WebSocket via adapter only).

### Low / informational
- **`json_embed_file_preflight.validate_local_json_embed_file`**: disk read + JSON parse — **no network**.
- **`EmbeddingClient.__aenter__`**: delegates to adapter client entry (no extra parallel stack in this repo).
- **Optional API surface** on `EmbeddingClient` (`http_get`, `fetch_openapi_schema`, `open_bidirectional_ws_channel`) uses adapter or adapter exports — **not** called by `embed_file_from_local_json_file` / CLI `embed-file-json`.

---

## 2) Operation → symbol → adapter or bypass

| Operation | Where (file / function) | Adapter vs bypass |
|-----------|-------------------------|-------------------|
| Local input validation | `json_embed_file_preflight.validate_local_json_embed_file` | **N/A** (local I/O only) |
| Staged **input file upload** (HTTP transfer) | `local_json_embed_file.embed_file_from_local_json_file` → `EmbeddingClient.upload_file` → `JsonRpcClient.upload_file` | **Adapter** |
| **RPC:** submit `embed_file` command | `EmbeddingClient.embed_file` → `self.client.jsonrpc_call("embed_file", params)` | **Adapter** |
| **WebSocket:** wait for queue job completion | `EmbeddingClient.embed_file` → `_wait_for_job_via_adapter_ws` → `JsonRpcClient.wait_for_job` **or** `JsonRpcClient.wait_for_job_via_websocket` | **Adapter** |
| **HTTP:** download result blob by transfer id | `EmbeddingClient.embed_file` → `self.client.download_file(tid, local_path)` (skipped if `skip_download=True`) | **Adapter** |
| **RPC:** `transfer_ack` (cleanup / ack outbound transfer) | `EmbeddingClient.embed_file` → `self.client.jsonrpc_call("transfer_ack", ack_params)` | **Adapter** |
| Optional: job message history (if store + adapter registry) | `EmbeddingClient.aget_embed_file_status_snapshot` / `alist_embed_file_status_messages` → `JsonRpcClient.get_job_messages` | **Adapter** |
| Optional: clear tracking | `EmbeddingClient.clear_embed_file_status` → `JsonRpcClient.clear_job_tracking` | **Adapter** |
| CLI wiring | `cli.py` `embed-file-json` → `VectorizationCLI.embed_file_local_json` → `EmbeddingClient.embed_file_from_local_json_file` | **Adapter** (only via `EmbeddingClient`) |
| CLI **connect** | `VectorizationCLI.connect` → `EmbeddingClient.from_config` / `embedding_client_from_config_dict` / `ClientFactory.from_environment` | **Adapter** (constructs `JsonRpcClient`; no parallel HTTP stack) |

---

## 3) Residual exceptions / rationale

1. **`wait_for_job_poll` / HTTP job status polling** — reachable from **`EmbeddingClient.wait_for_job`** and CLI **`queue-wait`** (`cli_core.queue_wait`), **not** from **`embed_file`**. Still **adapter-routed** JSON-RPC, not a second HTTP stack in this repo.

2. **Dependency boundary** — All TCP/TLS/WebSocket details are inside **`mcp_proxy_adapter`**. This audit cannot classify internal adapter implementation (e.g. whether `wait_for_job_via_websocket` shares the same httpx client as JSON-RPC); contractually, everything is the **same `JsonRpcClient` abstraction**.

3. **Scripts** (e.g. `scripts/direct_vectorization_server.py` uses `urllib`) — **out of scope** for the **`embed_client`** library path above.

---

## 4) Call chain summary (local JSON → embed_file)

1. `validate_local_json_embed_file` — local.
2. `client.upload_file` — adapter HTTP upload.
3. `client.embed_file(..., inbound_transfer=receipt, ...)` — adapter `jsonrpc_call("embed_file")`.
4. `_wait_for_job_via_adapter_ws` — adapter WebSocket wait.
5. If outbound transfer id present: `client.download_file` — adapter HTTP download (unless `skip_download`).
6. `jsonrpc_call("transfer_ack", ...)` — adapter RPC.

---

**Report file path (for orchestrator):** `/home/vasilyvz/projects/embed-client/docs/agents/_scratch/researcher_code_file_vectorization_client_network_audit.md`
