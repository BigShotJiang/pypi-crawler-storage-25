# Documentation audit — file vectorization / JSON embed file / adapter (researcher_doc)

**Repository:** embed-client  
**Scope:** CLI_README.md, root docs, specs touching vectorization / embed_file / adapter / mTLS; alignment with current code (read-only verification).

## What durable docs claim about adapter routing (file vectorization)

### CLI_README.md (authoritative for CLI)

- **`embed-file-json`** (aka subcommand `embed-file-json`): validates a **local** UTF-8 JSON file (non-empty array of objects, string **`text`** per block), per-block size limit (default 1 MiB; **`EMBED_CLIENT_MAX_JSON_BLOCK_BYTES`** / **`--max-block-bytes`**), then **“uploads via the adapter”**, then server-side **`embed_file`** with **`format=json_array`**.
- Explicitly contrasts with **`vectorize --file`**, which is **line-based** and targets **`embed`**, not **`embed_file`**.

**Routing implied (not spelled out in CLI_README):** staging upload on the adapter, then JSON-RPC **`embed_file`** using transfer metadata instead of a server filesystem path — details live in **`EmbeddingClient`** / module docstrings in code.

### README.md, project_overlay.md, RV-04 atomic step

- Describe **`embed_file`** in the **canonical mTLS E2E** context via **`CANONICAL_EMBED_FILE_SERVER_PATH`**: a **server-visible** path the service reads — i.e. the **`input_file`** (legacy server-path) flow.
- **Do not** mention **`embed-file-json`** or local JSON → upload → **`inbound_transfer`**.

### docs/api_format.md

- States **`embed_file`** — **“server-side path”** and points to **`EmbeddingClient.embed_file`** docstring.

### docs/SERVER_MODES_AND_CLIENT.md

- Deploy matrix (HTTP…mTLS + roles); client behaviour for **`embed`** / queue; **no** **`embed_file`**, upload, or transfer semantics.

### CONFIGURATION.md

- **No** matches for **`embed_file`**, **`json_array`**, transfer fields (grep) — no configuration narrative for file/transfer flows.

## Code alignment (verified in `embed_client/`)

- **`embed_file_from_local_json_file`** (`local_json_embed_file.py`): `validate_local_json_embed_file` → **`client.upload_file`** → **`embed_file(..., inbound_transfer=receipt, local_source_path=..., file_format="json_array")`**; upload must **`completed`** before RPC.
- **`EmbeddingClient.embed_file`**: exactly one of **`input_file`** (server path) **or** **`inbound_transfer`** (`transfer_id`, `filename`, `compression`, `checksum_algorithm` in JSON-RPC params); WS wait; optional download/ack — matches docstring claim of parity with **`execute_command_with_file`** merge semantics.
- **Transport:** `ClientFactory` / adapter — JSON-RPC and upload share adapter HTTP client (see **`upload_file`** docstring).

**Conclusion:** CLI_README’s short description of **`embed-file-json`** matches the implementation. Root README / RV-04 describe a **different** **`embed_file`** entry path (server path only), not contradictory if read as “two supported modes.”

## Contradictions and gaps

| Issue | Severity |
|-------|----------|
| **docs/api_format.md** reduces **`embed_file`** to “server-side path” only — **incomplete / misleading** vs code and **`EmbeddingClient.embed_file`** (second mode: **`inbound_transfer`** after **`upload_file`**). | **Critical** for API doc accuracy |
| **README / overlay / RV-04** omit **`embed-file-json`** and transfer-based **`embed_file`**; readers may assume **`embed_file`** always means “path on server.” | Completeness (risk of confusion) |
| **CONFIGURATION.md** / **SERVER_MODES** omit **`embed_file`** variants and staging upload — operators lack a single durable reference. | Gap |
| Scratch / tactical notes that claimed “adapter upload not in repo” are **stale** relative to current **`local_json_embed_file`**. | Ignore obsolete scratch; do not merge into specs without refresh |

**No contradiction** found between CLI_README **`embed-file-json`** paragraph and code.

## Recommended doc updates (critical only; doc_writer to apply)

1. **`docs/api_format.md`:** Extend the **`embed_file`** bullet to state **two** input modes — server **`input_file`** **or** completed **`inbound_transfer`** from **`upload_file`** (same RPC field bundle as adapter file execution). Optionally one line pointing to CLI **`embed-file-json`** for local **`json_array`** files.

**Optional (non-blocking):** One sentence in **README.md** under documentation or minimal usage distinguishing canonical **server-path** **`embed_file`** vs **`embed-file-json`** for local JSON arrays.

---

**Deliverable path (orchestrator):** `/home/vasilyvz/projects/embed-client/docs/agents/_scratch/researcher_doc_file_vectorization_adapter_audit.md`
