# Doc map: real file vectorization E2E (localhost:8001, whole-file vs local JSON, md→json)

Scope: `README.md`, `CONFIGURATION.md`, `CLI_README.md`, `docs/SERVER_MODES_AND_CLIENT.md`, `examples/README.md` (per task). Focus: `embed-file` / `embed_file`, `json_array` / `embed-file-json`, Markdown prep, mTLS, port **8001**, progress output.

---

## 1. localhost:8001 + mTLS (canonical E2E entry)

- **`README.md` L23–L36** — Section «Canonical real-server E2E (localhost:8001, mTLS)»: script `examples/canonical_mtls_localhost_8001.py`, `RUN_CANONICAL_MTLS_E2E=1` for live calls, optional **`CANONICAL_EMBED_FILE_SERVER_PATH`** (server-visible path) to include **`embed_file`** in the tour.
- **`examples/README.md` L3–L16** — Same: mTLS against **localhost:8001**, certs under `mtls_certificates/`, env vars table, dry-run vs E2E.

---

## 2. Whole-file / server-path `embed_file` (shared disk)

- **`README.md` L58** — When input already exists on the service host: use **`embed_file`** with server-visible **`input_file`**; contrasts with client-only **`json_array`** path.
- **`docs/SERVER_MODES_AND_CLIENT.md` L41** — Explicit: server-side **`input_file`**; points to canonical tour with **`CANONICAL_EMBED_FILE_SERVER_PATH`**.
- **`examples/README.md` L9–L10** — Env **`CANONICAL_EMBED_FILE_SERVER_PATH`** documents optional inclusion of **`embed_file`** in the canonical script.

---

## 3. Markdown (or text) → `json_array` → `embed-file-json` (no shared server file)

- **`README.md` L58** — Pipeline: **`prepare-embed-file-json`** → valid **`json_array`** file → **`embed-file-json`**; **`--show-progress`** streams WebSocket/status lines to **stderr** during job wait; defers detail to **`CLI_README.md`**.
- **`CLI_README.md` L72–L74** — **`prepare-embed-file-json`**: Markdown/plain text, optional YAML front matter strip (`---` pair), **`json_array`** blocks, **`-o`**, **`--max-block-bytes`**, **`--max-chunks`**, **`--no-strip-front-matter`**. **`embed-file-json`**: validate local JSON, upload, server **`embed_file`** with **`format=json_array`**; **`--show-progress`** = WebSocket/status JSON to **stderr** while waiting.
- **`docs/SERVER_MODES_AND_CLIENT.md` L34–L39** — Validate → upload (same TLS/auth as JSON-RPC) → **`embed_file`** + **`inbound_transfer`** + **`format=json_array`**; CLI bullet matches prepare + **`--show-progress`** on **stderr**; programmatic **`embed_file_from_local_json_file`** + **`on_ws_event`** for progress parity.
- **`CONFIGURATION.md` L245–L246** — **`EMBED_CLIENT_MAX_JSON_BLOCK_BYTES`** (and pointer to CLI + **`SERVER_MODES`** for local upload vs server path).
- **`examples/README.md` L20–L28** — Concrete flow for Markdown (e.g. **`7d-00-48.md`**): **`prepare-embed-file-json`** … then **`embed-vectorize --config … embed-file-json … --show-progress`**.

---

## 4. mTLS config + port 8001 (wiring for CLI)

- **`CONFIGURATION.md` L8–L22** — «Recommended local integration (mTLS, port 8001)»: cert paths, **`build_mtls_localhost_8001_config()`** in `examples/canonical_mtls_localhost_8001.py`, typical fields **`protocol` `"mtls"`**, **`server.port` `8001`**, SSL/auth certificate layout.
- **`CLI_README.md` L26–L33** — **`embed-config-generator --mode mtls --host localhost --port 8001`** with repo cert paths → **`./configs/mtls.json`** (example).

---

## 5. Gaps / friction (documentation only)

1. **Single copy-paste E2E for «md → json_array → embed-file-json on :8001 mTLS»** — Not assembled in one place: user combines **`CLI_README.md`** (mTLS config generation) + **`examples/README.md` §2** (prepare + `embed-vectorize … embed-file-json`), where §2 still uses placeholder **`/path/to/config.json`** without stating «use generated `mtls.json` for localhost:8001».
2. **`README.md` «Minimal usage» (L45–L46)** — Shows **`EmbeddingClient.from_base_url_port("http://localhost", 8001)`** (HTTP), not mTLS; easy to misread next to the mTLS E2E section unless user follows the canonical example script.
3. **`CONFIGURATION.md` mTLS JSON example (L212–L216)** — Uses **`port`: 8443**, while the «Recommended local integration» subsection standardizes **8001**; readers must reconcile by section intent (generic vs local).
4. **Progress semantics** — Documented consistently as **`--show-progress`** → stderr WebSocket/status JSON (**`README.md` L58**, **`CLI_README.md` L74**, **`docs/SERVER_MODES_AND_CLIENT.md` L38**); no conflicting definition found in these five files.

---

*researcher_doc subagent — file vectorization E2E doc trace*
