# researcher_code: file vectorization, `embed_file`, adapter transfer, WebSocket payload (`embed-client`)

**Repository:** `/home/vasilyvz/projects/embed-client`  
**Scope:** Read-only trace of code paths; dependency `mcp-proxy-adapter` is external (not vendored).

---

## Findings by severity

### High — `embed_file` is server-path RPC; input upload is not automated

- **Evidence:** `EmbeddingClient.embed_file` builds `params` with only `input_file` (string), `format`, model/dimension/device/error_policy; calls `jsonrpc_call("embed_file", params)`. Docstring states the path is on the **server** host; client-side upload is suggested as a manual step via `JsonRpcClient.upload_file` / `execute_command_with_file` (types live in `mcp_proxy_adapter`, not in this repo).
- **Implication:** “Adapter transfers file” for **input** is **not** part of the `embed_file` implementation in this package; only **outbound** `download_file` + `transfer_ack` is wired after job completion when a transfer id is present.

### High — WebSocket completion carries full job `result`; huge jobs exceed typical WS frame limits

- **Evidence:** `_wait_for_job_via_adapter_ws` → `JsonRpcClient.wait_for_job` (or `wait_for_job_via_websocket`) → `_normalize_terminal_job_payload` merges nested `result`/`data` from terminal events (`job_completed`, `delivery_completed`, etc.).
- **Operational note (in-repo):** `scripts/run_file_chunking_check_8001.py` documents that **whole-file** `embed` can produce a WS reply larger than ~4 MiB, and recommends `--format lines` / `--bulk-lines` for bulk-style processing.

### Medium — CLI `vectorize --file` loads **all** non-empty lines into **one** `embed()` call

- **Evidence:** `embed_client/cli.py` extends `texts` with every stripped non-empty line, then `vectorize_texts` → `EmbeddingClient.embed` with the full list. For multi-megabyte, multi-thousand-line files (e.g. `7d-00-48.md`), this creates a very large JSON-RPC request and an equally large terminal WS payload (per-text embeddings/results).

### Low — `upload_file` / `execute_command_with_file` unused in this codebase

- **Evidence:** `rg` finds mentions only in `embed_client/embedding_client.py` (docstring guidance). No call sites in `embed_client/`, `examples/`, or `scripts/`.

---

## File:symbol references (primary)

| Area | Location |
|------|----------|
| CLI entry | `pyproject.toml` → `embed-vectorize = "embed_client.cli:cli_main"` |
| CLI `vectorize` + `--file` | `embed_client/cli.py` — `read_file_sync`, `vectorize_texts` |
| CLI core embed | `embed_client/cli_core.py` — `VectorizationCLI.vectorize_texts` → `EmbeddingClient.embed` |
| Security CLI | `embed_client/security_cli.py` — same pattern for `vectorize` + `--file` |
| Public client | `embed_client/embedding_client.py` — `EmbeddingClient` |
| `embed` + WS wait | `EmbeddingClient.embed`, `_embed_via_execute_async`, `wait_for_job`, `_wait_for_job_via_adapter_ws` |
| `embed_file` | `EmbeddingClient.embed_file` — `jsonrpc_call("embed_file")`, `_wait_for_job_via_adapter_ws`, `download_file`, `jsonrpc_call("transfer_ack")` |
| Transport | `from mcp_proxy_adapter.client.jsonrpc_client import JsonRpcClient` (`embedding_client.py` L23) |
| Config → client | `embed_client/adapter_config_factory.py` — `AdapterConfigFactory.from_config_dict`; `embedding_client_from_config_dict` |
| Canonical E2E + `embed_file` | `examples/canonical_mtls_localhost_8001.py` — `CANONICAL_EMBED_FILE_SERVER_PATH`, `client.embed_file(...)` |
| Bulk/file embed (documents WS size) | `scripts/run_file_chunking_check_8001.py` |
| Direct HTTP (no embed_client) | `scripts/direct_vectorization_server.py` — `POST /cmd` |
| Failing artifact | `/home/vasilyvz/projects/embed-client/7d-00-48.md` (repo root; very large) |

---

## Call-chain map per path

### Path A — `embed-vectorize vectorize` (text and optional `--file`)

1. `embed_client.cli:cli_main` → `main()` (`cli.py`).
2. `VectorizationCLI.connect` (`cli_core.py`): `EmbeddingClient.from_config` / `embedding_client_from_config_dict` → `JsonRpcClient(...)`.
3. `vectorize`: if `--file`, executor reads UTF-8 lines → `texts` list (`cli.py`).
4. `VectorizationCLI.vectorize_texts` → `EmbeddingClient.embed(..., wait=True, ...)` (`cli_core.py`).
5. `EmbeddingClient.embed` with `wait=True` → `_embed_via_execute_async` → `JsonRpcClient.execute_async("embed_execute", params, on_result=...)` then WS completion normalized via `_normalize_terminal_job_payload` (`embedding_client.py`).

**Transport:** JSON-RPC / adapter `execute_async` + WebSocket (`/ws`) for completion — not raw file upload.

### Path B — `python -m embed_client` / `embed-vectorize` (same as A)

Same as Path A (`cli.py` is the script entry).

### Path C — Security matrix CLI `vectorize`

`embed_client/security_cli.py`: reads `--file` like `cli.py`, then `SecurityCLI.vectorize_texts` → `EmbeddingClient.embed` (pattern aligned with main CLI).

### Path D — `EmbeddingClient.embed_file` (API / canonical example)

1. Caller (e.g. `examples/canonical_mtls_localhost_8001.py`): `await client.embed_file(input_file, wait=True, ...)`.
2. `jsonrpc_call("embed_file", {"input_file", "format", ...})` — **only path strings and options** (`embedding_client.py`).
3. On success with `job_id` and `wait=True`: `_wait_for_job_via_adapter_ws` → `JsonRpcClient.wait_for_job` (preferred) or `wait_for_job_via_websocket` → `_normalize_terminal_job_payload`.
4. If `outbound_transfer_id` / `transfer_id` present and not `skip_download`: `JsonRpcClient.download_file(tid, local_path)` (HTTP transfer API on adapter), checksum verify, then `jsonrpc_call("transfer_ack", {...})`.

**Transport:** JSON-RPC submit; WebSocket for job terminal event; optional **HTTP download** for output file — **no** `upload_file` in this chain.

### Path E — `scripts/run_file_chunking_check_8001.py`

- **lines / auto→lines for `.md`:** batched `embed(texts=batch, wait=True)` — reduces per-message size.
- **whole:** `embed([raw], wait=True)` — documented risk of large WS replies.

### Path F — `scripts/direct_vectorization_server.py`

urllib `POST /cmd` — bypasses `EmbeddingClient`; not adapter JSON-RPC WebSocket path.

---

## Question answers (evidence-based)

### 1) User-facing entry points

- **CLIs:** `embed-vectorize` (`embed_client.cli:cli_main`), `python -m embed_client`, security CLI (`security_cli.py`).
- **Examples:** `examples/canonical_mtls_localhost_8001.py` (`embed`, `embed_file` when env set).
- **Scripts:** `run_file_chunking_check_8001.py`, `direct_vectorization_server.py`, others under `scripts/` that call `EmbeddingClient` (grep “EmbeddingClient” for full list).
- **Public API:** `embed_client.embedding_client.EmbeddingClient` — `embed`, `embed_file`, `wait_for_job`, `job_status`, `cmd`, etc.

### 2) Exact chains

See **Call-chain map** above (functions/modules named).

### 3) Where file bytes are read

- **`vectorize --file`:** Client process reads file (`cli.py` / `security_cli.py`).
- **`embed_file`:** Client sends **path string** only; docstring and params imply **server** opens `input_file`.
- **`embed_file` output:** Client may read bytes via **`JsonRpcClient.download_file`** into `local_path` (adapter HTTP API).
- **`run_file_chunking_check_8001.py`:** Client reads file content for `embed` inputs.

### 4) Adapter file transfer / upload

- **Dedicated APIs (dependency):** Docstring references `JsonRpcClient.upload_file`, `execute_command_with_file`, `download_file` (`mcp_proxy_adapter.client.jsonrpc_client`).
- **Used in this repo:** `download_file` and `transfer_ack` are called from `embed_file` when a transfer id exists. **`upload_file` / `execute_command_with_file` are not called anywhere** in this repository — documentation-only / manual integration.
- **Conditions for download path:** Terminal job data contains non-empty `outbound_transfer_id` or `transfer_id`, and `skip_download` is false (default).

### 5) Failing case `7d-00-48.md`

- **Location:** `/home/vasilyvz/projects/embed-client/7d-00-48.md` (repository root; on-disk size/order of **~1.7M characters**, **tens of thousands of lines** — too large to load fully in tools).
- **Why a too-large WebSocket payload was attempted (mechanism):**
  - **`embed(wait=True)` path** delivers completion through the adapter WebSocket; the terminal message includes merged `result`/`data` (`_normalize_terminal_job_payload`). For a massive **batch embed** (e.g. CLI `--file` aggregating all lines into one `embed` call) or a **whole-file** embed with rich per-result fields, the JSON serialized over WS exceeds typical **max message size** (commonly single-digit MiB in many stacks). This is explicitly called out in `run_file_chunking_check_8001.py` (whole-mode warning and closing note).
  - **Not** because the markdown file bytes were embedded in the `embed_file` RPC request (that RPC only sends the path string); failure aligns with **large completion payloads** on **`embed` / queue completion**, not with uploading the file body in `embed_file`.

### 6) `embed_file` contract: server-visible path vs upload

- **RPC:** `embed_file` with params including **`input_file`: string path** — **server-visible path only** in this client; no file body in the JSON-RPC request traced in `embedding_client.py`.
- **Completion:** WebSocket terminal event; optional **HTTP `download_file`** for large JSON output when the server uses transfer ids — **outbound** transfer, not input upload.

### 7) Architectural gap: “adapter transfers file” vs actual behavior

- **Documented intent:** `embed_file` docstring describes uploading a client-local file first via adapter helpers, then passing the server path.
- **Actual in-package behavior:** No automatic upload; **`embed_file` only sends the path**. Outbound **`download_file`** is implemented for results. Input upload remains a **manual / out-of-band** step relative to this codebase.

---

## Verdict: Is adapter upload used in the file vectorization path?

- **Proven:** **No.** Repository contains **zero** calls to `upload_file` or `execute_command_with_file`. File vectorization via CLI uses **local read + `embed`**. `embed_file` uses **path string + optional `download_file`** for output.
- **Inferred:** Servers that require client-local data must integrate upload **outside** this package or extend callers to invoke adapter upload APIs explicitly.

---

## High-confidence fix direction (no code)

1. **For huge local files:** Avoid single giant `embed()` batches (CLI `--file` behavior); use line batching / chunking scripts (`run_file_chunking_check_8001.py` patterns) or server-side streaming/batching conventions.
2. **For `embed_file` from client-local paths:** Implement or document an explicit **upload → server path → `embed_file`** sequence using `mcp-proxy-adapter` APIs, or rely on shared storage / identical absolute paths — **do not assume `embed_file` uploads**.
3. **For WS size limits:** Prefer designs where large outputs use **`outbound_transfer_id` + HTTP download** (already supported in `embed_file` completion path) rather than embedding full results in the WS frame — server/adapter contract dependent.

---

## Related in-repo notes

- `docs/agents/_scratch/orch_tactical_debug_7d00_embed_file_vectorization.md` — operational guidance for `7d-00-48.md`, server path vs CLI fallback.
- `docs/ai_reports/baseline_audit_code_research.md` — historical parity notes on `embed_file` / transfer pipeline.
