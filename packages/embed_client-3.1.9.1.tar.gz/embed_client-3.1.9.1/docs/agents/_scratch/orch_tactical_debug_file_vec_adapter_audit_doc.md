# File vectorization: network paths vs adapter — doc audit (researcher_doc)

**Path:** `/home/vasilyvz/projects/embed-client/docs/agents/_scratch/orch_tactical_debug_file_vec_adapter_audit_doc.md`  
**Scope:** Documented expectations for **server-visible paths**, **adapter** (`mcp-proxy-adapter` / `JsonRpcClient`), and **CLI** file flows; gaps vs architecture implied by code + CLI.

---

## 1. Documented expectations (by source)

### `docs/agents/project_overlay.md`

- Client: queue and commands via **`mcp-proxy-adapter`**’s **`JsonRpcClient`** (HTTP/HTTPS/mTLS, auth).
- Canonical mTLS: optional **`CANONICAL_EMBED_FILE_SERVER_PATH`** — **server-visible** path to include **`embed_file`** in the tour (`examples/canonical_mtls_localhost_8001.py`).

### `CLI_README.md` (embed-vectorize)

- **`vectorize --file`:** client reads UTF-8 lines → **`embed`** (not `embed_file`).
- **`embed-file-json`:** validates local JSON blocks (`text` per object), size limits (`EMBED_CLIENT_MAX_JSON_BLOCK_BYTES` / `--max-block-bytes`), **uploads via the adapter**, then server-side **`embed_file`** with **`format=json_array`**. Explicit **adapter** use for **inbound** bytes on this subcommand.

### Root `README.md` / examples index (short)

- **`embed_file`** in the canonical tour only when **`CANONICAL_EMBED_FILE_SERVER_PATH`** is set — **server** reads file; **no** mention of CLI upload or `embed-file-json`.

### Scratch / prior research (`docs/agents/_scratch/`)

| File | Adapter / path claims |
|------|------------------------|
| `researcher_doc_vectorization_adapter_alignment.md` | Three “file” meanings: (1) server path `embed_file`, (2) CLI lines→`embed`, (3) client path ≠ server unless shared. Adapter: JSON-RPC + queue; full pipeline adds **WS** + **HTTP `download_file`** + **`transfer_ack`** — mostly in **`EmbeddingClient.embed_file`** docstring, not README. **Inbound** upload documented as **manual** (`upload_file` / `execute_command_with_file`), not inside `embed_file` RPC. |
| `researcher_doc_vectorization_flow_debug.md` | Same split; RV-02 = text smoke (no `embed_file`); RV-04 = server-visible path for live `embed_file`. OpenAPI snapshot lacks `embed_file` / transfer. |
| `vectorization_commands_research.md` | Two “file” meanings: `embed_file` vs `vectorize --file`; canonical E2E via env + example script. |
| `orch_tactical_debug_7d00_embed_file_vectorization.md` | Client-only repo path fails **`embed_file`** unless server sees same path; fallback = **`vectorize --file`** (→ `embed`). |
| `researcher_code_vectorization_adapter_chain.md` (code trace) | `embed_file`: JSON-RPC + WS + optional **`download_file`**/`transfer_ack`; **`upload_file`** not called in-repo (before `embed-file-json` work — see gap below). |

### `researcher_doc_vectorization_mtls_manual_checks.md`

- Deploy rule: eight modes + **`localhost:8001`** vectorization; RV-02/04 procedures; **no** `embed-file-json` line (predates or out of scope).

---

## 2. Network vs adapter: stable mental model from docs

1. **`embed_file` with server path:** JSON-RPC passes **`input_file`** string; **server** reads disk. **No** file bytes on the wire for input in the canonical README story.
2. **Post-job (code/docstring contract, underdocumented in README/CONFIGURATION):** adapter **WebSocket** for job completion; optional **HTTP** **`download_file`** + **`transfer_ack`** for outbound result file.
3. **`vectorize --file`:** file bytes read **locally**; payloads go through normal **`embed`** JSON-RPC/WS — not `embed_file`.
4. **`embed-file-json` (CLI only in durable user docs):** **inbound** upload **via adapter**, then **`embed_file`** with **`format=json_array`** — fills the gap between “client has a structured file” and “server runs `embed_file`” without requiring a pre-staged server path.

---

## 3. Gaps vs intended architecture

| Topic | Gap |
|-------|-----|
| **Scratch vs CLI (March 2026 research)** | Prior docs stated **inbound** adapter upload was **manual / out-of-repo** only. **`CLI_README.md`** now documents **`embed-file-json`** as **upload via adapter** + **`embed_file`**. Scratch files that say “no upload in package” are **stale** for CLI; **`EmbeddingClient`** may still expose upload only via lower-level adapter APIs for non-CLI callers — verify in code when updating specs. |
| **README / examples** | No pointer to **`embed-file-json`**; operators may still assume only server path or line-based **`vectorize --file`**. |
| **`docs/SERVER_MODES_AND_CLIENT.md`** | Omits **`embed_file`** and any **upload/download** transfer story — easy to miss WS + HTTP facets of **`embed_file`**. |
| **`CONFIGURATION.md`** | No **`embed_file`** / transfer fields (per prior grep-based notes). |
| **`docs/openapi-8001.json`** | No **`embed_file`** / transfer — not a complete contract surface for file pipeline. |
| **Transport matrix** | Durable docs do not explicitly state that **`download_file`** (and upload for `embed-file-json`) follow the **same** TLS/auth as JSON-RPC for all deploy modes (reasonable inference only). |
| **Single authoritative spec** | Distinction **`vectorize --file`** vs **`embed_file`** vs **`embed-file-json`** is split across **CLI_README** + scratch + RV specs; **no** one `docs/specs/.../spec.md` dedicated to the three CLI/API paths + adapter boundaries. |

---

## 4. Key findings (concise)

- **Adapter contract in prose:** **project_overlay** = **`JsonRpcClient`** for RPC/queue; **full `embed_file`** behavior adds **WS** + optional **HTTP download/ACK** (docstring-heavy). **`embed-file-json`** is the **only** durable user-facing doc line that ties **inbound** adapter upload to **`embed_file`** in one CLI command.
- **Server path vs adapter:** Docs consistently separate **path string for server** from **line-based CLI**; **new** third CLI path (**`embed-file-json`**) explicitly **uses adapter for upload**, aligning operator story with “file reaches server without shared filesystem” — **under-reflected** in README/examples and older scratch.
- **Intended architecture cross-check:** If “file vectorization” means **JSON blocks + `embed_file` without manual staging**, **`embed-file-json`** is the documented client path; if it means **canonical RV-04 / README tour**, still **server-visible path** only.

---

## 5. Citations (primary)

- `docs/agents/project_overlay.md` — JsonRpcClient, `CANONICAL_EMBED_FILE_SERVER_PATH`
- `CLI_README.md` — `vectorize --file`, **`embed-file-json`**
- `README.md` — optional `embed_file` via server path env var
- `docs/agents/_scratch/researcher_doc_vectorization_adapter_alignment.md`, `researcher_doc_vectorization_flow_debug.md`, `vectorization_commands_research.md`, `orch_tactical_debug_7d00_embed_file_vectorization.md`, `researcher_code_vectorization_adapter_chain.md`
- `docs/agents/_scratch/researcher_doc_vectorization_mtls_manual_checks.md` — RV/deploy, no `embed-file-json`

*End.*
