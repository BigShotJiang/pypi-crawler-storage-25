# Markdown / file text preparation before embedding — paragraph split rule (code facts)

**Repository:** `/home/vasilyvz/projects/embed-client`  
**Scope:** Authoritative implementation for MD → `json_array` prep (`md_embed_file_prep`), local JSON upload path (`local_json_embed_file`), CLI wiring. Facts from source only.

## Authoritative implementation

The **only** implementation that turns Markdown/plain text into `json_array` string blocks for `embed_file` is **`embed_client/md_embed_file_prep.py`**.

- **`split_body_into_text_blocks(body, max_block_bytes)`** (lines 50–80) performs the split.
- **`build_embed_file_json_array_from_markdown_text`** (lines 83–107) applies optional front-matter strip, calls `split_body_into_text_blocks`, optional `max_chunks` truncation, empty-output check.
- **`prepare_markdown_path_to_json_file`** (lines 110–162) reads the file as UTF-8 (BOM allowed), builds the array, writes JSON, then re-validates the file.

CLI:

- **`prepare-embed-file-json`:** `embed_client/cli.py` lines 321–324 dispatch to `prepare_markdown_cli_main` from `md_embed_file_prep.py` (lines 165–188). Parser/help: `cli.py` lines 228–262.
- **`embed-file-json`:** `embed_client/cli.py` lines 377–392 → `VectorizationCLI.embed_file_local_json` in `embed_client/cli_core.py` lines 122–187 → `EmbeddingClient.embed_file_from_local_json_file` (`embedding_client.py` re-exports) → `embed_client/local_json_embed_file.py` `embed_file_from_local_json_file` (lines 22–70).

Programmatic local JSON path (no MD prep): **`embed_file_from_local_json_file`** validates and uploads; it does **not** split text — it expects an existing `json_array` file.

## Paragraph boundary rule (`\n\n` only)

**Confirmed in code:**

1. Line endings are normalized: `\r\n` and lone `\r` become `\n` (`md_embed_file_prep.py` lines 65–66).
2. Split uses the **two-character separator** `"\n\n"` only: `paragraphs = normalized.split("\n\n")` (line 66).
3. Each segment is **stripped**; segments empty after strip are **skipped**, so multiple blank lines collapse to one boundary (lines 68–71, docstring lines 56–57).

**Module docstring** (lines 1–9) and **`split_body_into_text_blocks` docstring** (lines 50–61) state explicitly: split on double newlines / blank lines (`\n\n`), paragraph boundaries only.

**No semantic / smart chunking in this prep step**

- Docstring states oversized blocks raise `EmbedClientError` and **“(no byte-level re-chunking)”** (`md_embed_file_prep.py` lines 59–61, 72–78).
- There is no tokenizer, sentence detector, heading-aware splitter, or sliding window in this module.

**`max_chunks`** (`build_embed_file_json_array_from_markdown_text` lines 99–102, CLI `--max-chunks` `cli.py` 251–257) only **truncates** the list of already-split blocks (`blocks[:max_chunks]`); it does not change how paragraphs are formed.

## Where per-block (per string) size validation runs

| Stage | Location | Behavior |
|-------|----------|----------|
| During MD prep, after `\n\n` split | `md_embed_file_prep.py` 72–78 | Each non-empty block UTF-8-encoded; `len(encoded) > max_block_bytes` → `EmbedClientError`. |
| After writing prep output | `md_embed_file_prep.py` 161 | `validate_local_json_embed_file(ap_out, max_block_bytes=...)` |
| Local JSON before upload | `local_json_embed_file.py` 39 | `validate_local_json_embed_file(local_path, max_block_bytes=...)` |
| Preflight implementation | `json_embed_file_preflight.py` 93–104 | Loop over JSON array items; `len(item.encode("utf-8")) > max_b` → `EmbedClientError`. |

`resolve_max_json_block_bytes` (`json_embed_file_preflight.py` 18–40) resolves the cap (explicit arg → env → `DEFAULT_MAX_JSON_EMBED_BLOCK_BYTES` from `constants`).

## Key file:line references

- `embed_client/md_embed_file_prep.py` — module doc 1–9; `strip_optional_yaml_front_matter` 28–46; `split_body_into_text_blocks` 50–80; `build_embed_file_json_array_from_markdown_text` 83–107; `prepare_markdown_path_to_json_file` 110–162; `prepare_markdown_cli_main` 165–188.
- `embed_client/json_embed_file_preflight.py` — `resolve_max_json_block_bytes` 18–40; `validate_local_json_embed_file` 43–104.
- `embed_client/local_json_embed_file.py` — `embed_file_from_local_json_file` 22–70 (validation at 39).
- `embed_client/cli.py` — examples 41–45; `embed-file-json` parser 164–226; `prepare-embed-file-json` parser 228–262; dispatch `prepare-embed-file-json` 321–324; dispatch `embed-file-json` 377–392.
- `embed_client/cli_core.py` — `embed_file_local_json` 122–187.
- `tests/test_md_embed_file_prep.py` — `test_split_two_paragraphs` 33–35; CRLF 37–39; consecutive blanks 42–44; max bytes 46–48.

## Docstrings / comments vs paragraph rule

**No contradiction found** in `md_embed_file_prep.py` or the related CLI help strings: all describe blank-line / `\n\n` paragraph splitting and cap-without-rechunking.

**Minor precision (not a contradiction):** `build_embed_file_json_array_from_markdown_text` short docstring (lines 90–95) says “from Markdown/plain text” but does not repeat the `\n\n` rule there; the rule is in the module doc and in `split_body_into_text_blocks`.

**Out of scope but factual:** `iter_json_array_block_texts` (`json_embed_file_preflight.py` 107–111) docstring says to call it “after” `validate_local_json_embed_file`; `cli_core.py` 157 calls it **before** `embed_file_from_local_json_file`, while validation still occurs inside `embed_file_from_local_json_file` at line 39. This does not affect the paragraph-split rule.

---

**Deliverable path:** `docs/agents/_scratch/researcher_code_file_prep_paragraph_rule.md`
