# Release-completion research (facts only) — `researcher_code`

Generated for orchestrator consumption. No recommendations.

## 1. `examples/canonical_mtls_localhost_8001.py`

- **Invocation:** From repository root so `mtls_certificates/` resolves: `python examples/canonical_mtls_localhost_8001.py`. Docstring also shows `RUN_CANONICAL_MTLS_E2E=1 python examples/canonical_mtls_localhost_8001.py`.
- **`_ROOT`:** `Path(__file__).resolve().parent.parent` (repo root); inserted into `sys.path` before importing `EmbeddingClient`.
- **`RUN_CANONICAL_MTLS_E2E`:** Read via `os.environ.get("RUN_CANONICAL_MTLS_E2E") == "1"`. If not `"1"`, script prints config summary (“Dry run”) and exits successfully **without** network. If `"1"`, builds config, opens `EmbeddingClient.from_config_dict(cfg)` in `async with`, runs `run_live_capabilities`; failures print and exit non-zero via `asyncio.run` exception handler.
- **`CANONICAL_EMBED_FILE_SERVER_PATH`:** Optional. If unset or whitespace-only, logs skip lines referencing `embed_file skipped` and `CANONICAL_EMBED_FILE_SERVER_PATH`. If set to non-empty trimmed string, calls `embed_file(input_file, wait=True, wait_timeout=600, error_policy="continue")`.
- **Target service:** `localhost:8001`, `protocol` `"mtls"` in returned config dict.
- **mTLS cert paths (function `_cert_paths`):** Under repo root `mtls_certificates/`:
  - `client/embedding-service.crt`
  - `client/embedding-service.key`
  - `ca/ca.crt`
- **`build_mtls_localhost_8001_config`:** Raises `FileNotFoundError` if any of the three files is missing. Populates `auth.certificate` and `ssl` with those paths; `ssl.check_hostname` False, `check_expiry` False, `verify_mode` `"CERT_REQUIRED"`.

## 2. Packaging / PyPI

- **`pyproject.toml`:** Present. `[build-system]` requires `["setuptools"]`, `build-backend = "setuptools.build_meta"`.
- **`setup.cfg`:** Not present in repository (glob search: 0 files).
- **Version:** `[project].version = "3.1.7.28"` in `pyproject.toml`.
- **`embed_client/__init__.py`:** `__version__` from `importlib.metadata.version("embed-client")` with `PackageNotFoundError` fallback `"3.1.7.28"` (matches `pyproject.toml` string).
- **Package name on PyPI-style metadata:** `name = "embed-client"` (hyphen).
- **Entry points (`[project.scripts]`):** `embed-config-generator`, `embed-config-validator`, `embed-vectorize`.
- **`MANIFEST.in`:** Includes README, LICENSE, CONFIGURATION, pyproject.toml; recursive-include examples, docs, configs; **recursive-excludes** include `tests`, `mtls_certificates`, `logs`, `test_environment`.
- **In-repo automated CI for publish:** No `.github/workflows` or `.gitlab-ci.yml` found in workspace (no checked-in GitHub Actions / GitLab CI file).
- **Twine / publish:** No `twine` shell script in repo root from grep of common patterns; publication steps exist **only as documentation** under `docs/specs/server_client_convergence_and_release/release_validation_and_pypi_publication/` (e.g. steps `rv05-build-artifacts-twine-version-gate.md`, `rv06-pypi-upload.md` describing `python -m build`, `twine check dist/*`, `twine upload dist/*`). Same folder references `TWINE_USERNAME` / `TWINE_PASSWORD` or `~/.pypirc` in prose.

## 3. Release / test-server mode matrix (in-repo artifacts)

- **Cursor rule `.cursor/rules/deploy.mdc`:** Lists eight modes to test on a test server before publication: http; http + token; http + token + roles; https; https + token; https + token + roles; mtls; mtls + roles. Also states vectorization on real `localhost:8001` (usually mTLS) and certs in `mtls_certificates`.
- **`docs/SERVER_MODES_AND_CLIENT.md`:** Same eight-mode table; points to `examples/security_examples.py`, `examples/security_examples_ru.py`, `embed-config-generator`, `CONFIGURATION.md`, and `examples/security_examples.py` for patterns.
- **`examples/security_examples.py`:** Docstring states eight-mode deploy matrix and that the script implements six `example_*` flows; references `docs/SERVER_MODES_AND_CLIENT.md`, `CONFIGURATION.md`, and `examples/canonical_mtls_localhost_8001.py` for canonical mTLS tour.
- **`tests/test_security_matrix.py`:** Documents eight modes (http, http+token, http+token+roles, https, …, mtls, mtls+roles). Entire module skipped unless `RUN_SECURITY_MATRIX=1`; skip reason references `scripts/run_*`. Default `create_test_config` uses `port=8000` and tests call `localhost` with `port=8000` for each mode (per file grep).
- **`scripts/run_all_modes_8001.py`:** Docstring: “Comprehensive Test Pipeline for All Security Modes on localhost:8001”; class uses `base_port = 8001`, loads certs from `mtls_certificates` via `ClientConfigGenerator.generate_all_configs`.
- **Release-validation spec tree:** `docs/specs/server_client_convergence_and_release/release_validation_and_pypi_publication/` defines RV-01 (automated security matrix pytest), RV-02 (`embed-vectorize` with `configs/mtls_8001.json`, localhost:8001), RV-03 (examples sweep), RV-04 (canonical script with `RUN_CANONICAL_MTLS_E2E=1`), RV-05 (build + twine check), RV-06 (twine upload). Index: `README.md`, `steps/ATOMIC_STEPS_INDEX.md`.

## 4. Deliverable

- **This file:** `docs/agents/_scratch/orch_tactical_debug_release_research_code.md`
