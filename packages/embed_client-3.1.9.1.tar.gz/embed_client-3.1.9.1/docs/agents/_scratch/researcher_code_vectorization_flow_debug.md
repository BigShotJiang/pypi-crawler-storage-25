# Client-side file vectorization — deep code analysis

**Scope:** Repository `embed-client` — client code and in-repo references to transport (`mcp-proxy-adapter`). **No server implementation** in this repo.

**Output convention:** Sections label claims as **proven from code** (directly traceable in this repository) vs **inferred** (reasonable implication or dependency behavior not fully defined here).

---

## 1. User-facing file vectorization commands (CLI)

### 1.1 Console entry points (**proven from code**)

| Mechanism | Target | Source |
|-----------|--------|--------|
| `embed-vectorize` | `embed_client.cli:cli_main` | `pyproject.toml` `[project.scripts]` (~L71–73) |
| `python -m embed_client` | `embed_client.__main__` → `embed_client.cli.main` | `embed_client/__main__.py` |
| `python -m embed_client.security_cli` | `embed_client.security_cli:main` | `embed_client/security_cli.py` |

### 1.2 Subcommands related to “vectorization” (**proven from code**)

- **`vectorize`** — primary user-facing vectorization command in:
  - `embed_client/cli.py` — subparser `"vectorize"` (~L112–155), optional **`--file` / `-f`**: “File containing texts (one per line)” (~L114–115).
  - `embed_client/security_cli.py` — subparser `"vectorize"` (~L105–109), same `--file` / `-f` (~L107–108).

- **`embed_file` is not exposed as a CLI subcommand** in this repository. The RPC-style API exists only as `EmbeddingClient.embed_file` in `embed_client/embedding_client.py` (~L853+). **Proven:** grep of `embed_client/*.py` shows no argparse entry for `embed_file`.

### 1.3 Scripts / examples (not argparse “commands” but relevant)

- `examples/canonical_mtls_localhost_8001.py` calls `EmbeddingClient.embed_file` when env sets a server path — **API usage**, not a packaged CLI (**proven:** file references `embed_file`).

---

## 2. Exact order of operations (call chains)

### 2.A Path: `embed-vectorize` / `python -m embed_client` + `vectorize` (**proven from code**)

1. **`cli_main()`** → `asyncio.run(main())` — `embed_client/cli.py` (~L316–322).
2. **`main()`** parses args; for `command == "vectorize"`:
   - If `--file`: `run_in_executor` + synchronous read → list of non-empty stripped lines; merged into `texts` (~L237–248).
   - **`VectorizationCLI.vectorize_texts(...)`** — `embed_client/cli_core.py` (~L254–263 from `cli.py` dispatch, method ~L108–185).
3. **`VectorizationCLI.connect`** — `EmbeddingClient.from_config` / `embedding_client_from_config_dict` / `ClientFactory.from_environment` — `cli_core.py` (~L37–72).
4. **`vectorize_texts`** calls **`await self.client.embed(..., wait=True, wait_timeout=wt)`** — `cli_core.py` (~L147–156).  
   - `wt = 60 if timeout is None else int(timeout)` (~L147).

5. **`EmbeddingClient.embed`** (`embedding_client.py` ~L524–634):
   - **If `wait` is True** (CLI always passes `wait=True`): **`return await self._embed_via_execute_async(params, wait_timeout)`** (~L602–603).  
   - **Does not** take the branch `jsonrpc_call("embed", params)` when `wait=True` (~L605).

6. **`_embed_via_execute_async`** (~L680–722):
   - **`await self.client.execute_async("embed_execute", params, on_result=..., timeout=timeout_sec)`** (~L698–703).
   - Waits on a `Future` filled by `on_result` (~L694–705).
   - Normalizes terminal WS-like events: `job_failed` vs `job_completed` / `job_completed_success` / `delivery_completed` (~L711–722).

**Transport:** `self.client` is **`mcp_proxy_adapter.client.jsonrpc_client.JsonRpcClient`** — constructed in `EmbeddingClient.__init__` (~L182–193). **Proven:** import and instantiation in `embedding_client.py`.

### 2.B Path: `python -m embed_client.security_cli` + `vectorize` (**proven from code**)

1. **`security_cli.main`** — `embed_client/security_cli.py` (~L21–196).
2. For `vectorize`: same file read pattern as main CLI (~L154–166).
3. **`SecurityCLI.vectorize_texts`** — `embed_client/security_cli_core.py` (~L53–78):
   - **`await self.client.cmd("embed", params={"texts": texts})`** (~L63–64).
4. **`EmbeddingClient.cmd`** → **`self.client.execute_command_unified(command="embed", params=..., use_cmd_endpoint=False, auto_poll=True)`** — `embedding_client.py` (~L1125–1138).

**Important divergence (proven):** the **main** CLI uses **`embed()` → `execute_async("embed_execute", ...)`** when waiting for results; the **security** CLI uses **`cmd("embed")` → `execute_command_unified`**. These are different public methods on `EmbeddingClient` with different adapter code paths.

### 2.C Path: API `EmbeddingClient.embed_file` (**proven from code**)

1. Build `params`: `input_file`, `format` (default `"lines"`), optional `model`, `dimension`, `device`, `error_policy` (default from `EMBED_COMMAND_SCHEMA_DEFAULT_ERROR_POLICY` in `constants.py`) — `embedding_client.py` (~L918–931).
2. **`await self.client.jsonrpc_call("embed_file", params)`** (~L933).
3. Parse `result.success`, extract `job_id` from nested `data` — (~L937–950).
4. Optional **`EmbedFileJobStatusStore.record_submit`** — (~L952–955).
5. If `wait` (default `True`): **`await self._wait_for_job_via_adapter_ws(job_id_str, tw, on_ws_event=...)`** (~L986–988).
6. **`_wait_for_job_via_adapter_ws`** (~L724–775): prefers **`self.client.wait_for_job(...)`** if present; else **`wait_for_job_via_websocket`** (~L762–768).
7. After normalized `data`, optional **local source SHA-256 check** vs `input_checksum_value` — (~L990–1003).
8. If `outbound_transfer_id` or `transfer_id` present (~L1005–1009):
   - Unless `skip_download`: **`await self.client.download_file(tid, local_path)`** (~L1033).
   - Verify **`checksum_value`** against downloaded file (~L1034–1046).
   - If `skip_download`: require `checksum_value` in payload (~L1016–1022).
9. **`await self.client.jsonrpc_call("transfer_ack", ack_params)`** with `outbound_transfer_id`, `checksum_algorithm`, `checksum_value`, optional `job_id` — (~L1058–1066, ~L1076–1079).

### 2.D Fallback: `embed` with `wait=False` (**proven from code**)

- **`jsonrpc_call("embed", params)`** — (~L605).
- Returns either sync `data` with `results`, or **`job_id`** + status — (~L618–634).
- Not used by default CLI `vectorize_texts` (which always uses `wait=True`).

### 2.E Fallback: `wait_for_job` without adapter `wait_for_job` (**proven from code**)

- **`wait_for_job_poll(self.job_status, ...)`** — `embedding_client.py` (~L676–677), implementation in `embedding_client_helpers.py` (~L15–53), polling **`queue_get_job_status`** / **`embed_job_status`** via `job_status` (~L818–849).

---

## 3. Distinction: `vectorize --file` vs `embed_file` vs adapter upload/download

| Aspect | `vectorize --file` (main & security CLI) | `embed_file` API |
|--------|------------------------------------------|------------------|
| **What the file is** | **Local UTF-8 text**: lines read on the **client**; each line becomes a string in `texts`. | **`input_file` is a path on the server** (docstring ~L881–884, ~L887). |
| **RPC / execution** | Main CLI: `execute_async("embed_execute", ...)` with `texts` in params. Security CLI: `execute_command_unified("embed", ...)`. | `jsonrpc_call("embed_file", {input_file, format, ...})` then WS wait + optional `download_file` + `transfer_ack`. |
| **Server reads user file?** | **No** — only text payloads are sent (embedded in JSON-RPC / adapter execution). **Proven** by flow: no path sent for the local `--file` except as strings in `texts`. | **Yes** — server reads `input_file` path on its filesystem. |
| **Adapter download** | Not used for standard vectorize. | Used when result includes **`outbound_transfer_id` / `transfer_id`**: `download_file` + `transfer_ack`. **Proven:** ~L1005–1079. |
| **Adapter upload** | N/A for this flow. | **Not wrapped** in `EmbeddingClient`; docstring tells callers to use **`JsonRpcClient.upload_file`** or **`execute_command_with_file`** on the **underlying** client (~L881–883). **Proven:** only references in docstring + `download_file` call site. |

---

## 4. Key symbols, paths, and line references

| Concern | Location |
|---------|----------|
| CLI argparse, `--file` merge | `embed_client/cli.py` ~L112–116, ~L235–263 |
| Security CLI argparse | `embed_client/security_cli.py` ~L105–109, ~L154–173 |
| `VectorizationCLI` + `embed()` | `embed_client/cli_core.py` ~L24–185 |
| `SecurityCLI` + `cmd("embed")` | `embed_client/security_cli_core.py` ~L53–78 |
| `EmbeddingClient.embed` | `embed_client/embedding_client.py` ~L524–634 |
| `_embed_via_execute_async` | same file ~L680–722 |
| `_wait_for_job_via_adapter_ws` | same file ~L724–775 |
| `embed_file` | same file ~L853–1080 |
| WS terminal normalization | `_normalize_terminal_job_payload` ~L96–111; `_merge_jsonrpc_result_data_layers` ~L65–93 |
| Poll fallback | `embed_client/embedding_client_helpers.py` `wait_for_job_poll` |
| JSON-RPC surface re-exports | `EmbeddingClient.jsonrpc`, `health`, `models`, `timing_stats`, queue helpers ~L515–1183 |
| Dependency: `JsonRpcClient` | `from mcp_proxy_adapter.client.jsonrpc_client import JsonRpcClient` — `embedding_client.py` ~L23 |

---

## 5. Server contract implied by client code only

All of the following are **method names and payload keys as literals in this repo** (**proven**). Exact HTTP URL paths for JSON-RPC are **not** defined in `embed-client` source (delegated to `mcp-proxy-adapter`); **inferred:** typical single JSON-RPC endpoint + `/ws` for WebSocket as stated in class docstring (`embedding_client.py` ~L124–126).

### 5.1 `vectorize` (main CLI) — `wait=True`

- **Adapter RPC:** `execute_async` with command name **`"embed_execute"`** — (~L698–699).
- **Params shape:** `texts`, optional `model`, `dimension`, `job_id`, `error_policy`, `device` — built in `embed` (~L585–598).
- **Completion:** WS events: `job_failed`, or `job_completed` / `job_completed_success` / `delivery_completed` — (~L711–717, ~L715–717 in `_embed_via_execute_async`).

### 5.2 `vectorize` (security CLI)

- **`execute_command_unified`** with **`command="embed"`**, `params={"texts": texts}` — (`security_cli_core.py` ~L63–64, `embedding_client.py` ~L1125–1138).
- **Inferred:** response shape consumed by `extract_embeddings` from `response_parsers` (not expanded here).

### 5.3 `embed` with `wait=False` (not default CLI)

- **`jsonrpc_call("embed", params)`** — same param dict as above — (~L605).

### 5.4 `embed_file`

- **Submit:** **`jsonrpc_call("embed_file", params)`** with at least `input_file`, `format` (`file_format` → key `"format"`), optional `model`, `dimension`, `device`, `error_policy` — (~L918–933).
- **Wait:** WebSocket job completion; normalized fields include **`input_checksum_value`**, **`outbound_transfer_id`** / **`transfer_id`**, **`checksum_algorithm`**, **`checksum_value`** — used ~L990–1045.
- **Download:** **`download_file(transfer_id, local_path)`** on `JsonRpcClient` — (~L1033). **Inferred:** separate HTTP transfer API inside adapter (not specified in this repo).
- **Ack:** **`jsonrpc_call("transfer_ack", {outbound_transfer_id, checksum_algorithm, checksum_value, job_id?})`** — (~L1058–1066).

### 5.5 Other RPC names referenced in client

- `health` — (~L522)
- `queue_get_job_status`, `embed_job_status` — (~L820–836)
- `models` — (~L1102)
- `timing_stats` — (~L1171)
- `list` / `help` / `commands` via `list_commands_via_client` — (`embedding_client_helpers.py` ~L56–68)
- Queue: `queue_list_jobs` (via `client.queue_list_jobs`), `queue_stop_job`, `queue_delete_job`, `queue_get_job_logs` — (~L1146–1164)

---

## 6. Divergence from “adapter-based file transfer” (intent vs structure)

**Proven from code:**

1. **Class docstring** states WebSocket for job results when `wait=True` and contrasts optional **embed_file status store** with **adapter** job registry (`JobTrackingMixin`) — `embedding_client.py` ~L124–137.

2. **`embed_file` docstring** explicitly describes the **download** path as **adapter transfer HTTP API** (`download_file`) and **`transfer_ack`** — (~L876–879). **Upload** for bringing a client file to the server is **documented as caller responsibility** via raw `JsonRpcClient` methods — not an `EmbeddingClient` wrapper — (~L881–884). That is a deliberate **thin API**: file transfer for **output** is integrated; for **input** it is not.

3. **Main CLI `vectorize --file`** never uses adapter file transfer: it only reads bytes/strings locally and sends **text** through **`embed_execute`**. So “file vectorization” in the CLI sense is **not** server-side file ingestion; naming can collide with **`embed_file`** semantics — **proven** by `cli.py` read + `embed` chain.

**Inferred:**

- The split between **`execute_async("embed_execute")`** (main CLI wait path) and **`jsonrpc_call("embed")`** / **`execute_command_unified`** (security CLI) suggests **two server/integration paths** for the same user intent (“embed these texts”), possibly for latency or queue behavior; this repo documents **`embed_execute`** in `_embed_via_execute_async` as “in-process … no queue, no worker spawn” (~L684–687).

---

## 7. Supplementary: `wait_timeout` / CLI help (**inferred from code behavior**)

- CLI advertises `--wait-timeout` “Use 0 for unlimited” — `cli.py` ~L149–154.
- `VectorizationCLI.vectorize_texts` passes `wt = 60 if timeout is None else int(timeout)` — `cli_core.py` ~L147.
- `_embed_via_execute_async` uses `timeout_sec = float(timeout) if timeout > 0 else 60.0` — `embedding_client.py` ~L690. So **`0` becomes 60 seconds**, not unlimited — **proven** mismatch between help text and implementation unless another layer overrides (none visible here).

---

**Deliverable path:** `/home/vasilyvz/projects/embed-client/docs/agents/_scratch/researcher_code_vectorization_flow_debug.md`
