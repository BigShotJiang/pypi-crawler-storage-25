# File vectorization / JSON embed — documentation & examples report

**Date:** 2026-03-30  
**Scope:** `CLI_README.md`, `docs/` (excluding transient analysis detail where noted), `examples/`, root `README.md`. Cross-check: `embed_client/cli_core.py`, `local_json_embed_file.py`, `json_embed_file_preflight.py`.

---

## 1. Where topics appear

| Topic | Durable user-facing docs | Notes |
|--------|---------------------------|--------|
| **File vectorization** (informal) | Implicit: `CLI_README.md` (`embed-vectorize`, `embed-file-json`, `vectorize`); `README.md` / `examples/README.md` (`embed_file` via server path + canonical tour) | No single glossary term “file vectorization” in root docs. |
| **JSON embed file / `json_array`** | **`CLI_README.md`** — local UTF-8 JSON array, `text` per object, `format=json_array` via `embed_file` | Primary durable description. |
| **Preflight** (local validation before upload) | **Not named** in durable docs. Behavior described as “validates … JSON file” in `CLI_README.md`. | Implementation: `json_embed_file_preflight.validate_local_json_embed_file` (module name “preflight” only in code/tests/scratch). |
| **Adapter upload** | **`CLI_README.md`** — “uploads via the adapter” for `embed-file-json` | Matches `local_json_embed_file.embed_file_from_local_json_file` → `upload_file` → `embed_file(..., inbound_transfer=...)`. |
| **`embed_file` server path** | `README.md`, `examples/README.md`, `docs/agents/project_overlay.md`, `docs/specs/server_client_convergence_and_release/.../README.md` (RV-04) | `CANONICAL_EMBED_FILE_SERVER_PATH`; no `embed-file-json` there. |
| **`docs/api_format.md`** | One bullet: **`embed_file`** — “server-side path”; points to `EmbeddingClient.embed_file` docstring | Omits **inbound transfer** path. |
| **`CONFIGURATION.md`**, **`docs/SERVER_MODES_AND_CLIENT.md`** | **No** `embed_file`, `embed-file-json`, upload/transfer narrative (verified by grep). | Gap for operators. |
| **`docs/agents/_scratch/`** | Multiple research notes (`researcher_doc_file_vectorization_adapter_audit.md`, `orch_tactical_debug_file_vec_*.md`, etc.) | Detailed; some lines **stale** (e.g. older “upload not in repo” superseded by `local_json_embed_file`). |

---

## 2. Alignment with code (brief)

| Documented claim | Code | Verdict |
|------------------|------|--------|
| `embed-file-json`: validate local JSON → adapter upload → `embed_file` with `json_array` | `cli_core.embed_file_local_json` → `EmbeddingClient.embed_file_from_local_json_file` | **Aligned.** |
| Per-block size limit; env / CLI override | `resolve_max_json_block_bytes`, CLI `--max-block-bytes` | **Aligned** with `CLI_README.md`. |
| `vectorize --file` vs `embed-file-json` | Line-based `embed` vs `embed_file` path above | **Aligned.** |
| `docs/api_format.md`: `embed_file` = server-side path only | `EmbeddingClient.embed_file` supports **`input_file`** XOR **`inbound_transfer`** | **Doc incomplete / misleading** for API overview. |
| README canonical tour: `embed_file` when server sees file | `input_file`-style usage in example | **Aligned** for that mode; second mode not mentioned. |

---

## 3. Examples covering file vectorization

- **Present:** `examples/canonical_mtls_localhost_8001.py` + env `CANONICAL_EMBED_FILE_SERVER_PATH` — **server-visible path** `embed_file` only (`examples/README.md`).
- **Absent:** No sample JSON file for `json_array`, no snippet invoking **`embed-file-json`** or **`embed_file_from_local_json_file`** under `examples/`.

**Where a minimal example should live (per project layout):**  
- **`examples/`** is the indexed location (`README.md` → `examples/README.md`, tech-spec DN-03 points to canonical mTLS here).  
- Minimal additions that fit conventions: e.g. **`examples/data/embed_file_json_array_sample.json`** (tiny valid array) + **`examples/README.md`** row documenting **`embed-vectorize embed-file-json examples/data/embed_file_json_array_sample.json`** (with `--config` as other examples), or a short **`examples/embed_file_json_local.py`** calling `embed_file_from_local_json_file` (parallel to async/security examples).  
- A **durable spec** under **`docs/specs/<specname>/`** is optional (LAYOUT-09); not required for a minimal user example.

---

## 4. Concrete doc/example updates for alignment

1. **`docs/api_format.md`** — Extend the `embed_file` bullet: **two** input modes — (a) server **`input_file`**, (b) **`inbound_transfer`** after successful **`upload_file`** (same transfer fields as adapter file execution); optional pointer to **`embed-file-json`** for local `json_array` files.
2. **`README.md`** — One sentence in Documentation or Minimal usage: distinguish **server-path** `embed_file` (canonical tour) vs **`embed-file-json`** for local JSON arrays without a shared server filesystem; link **`CLI_README.md`**.
3. **`CONFIGURATION.md`** / **`docs/SERVER_MODES_AND_CLIENT.md`** — Short subsection or bullets: **`EMBED_CLIENT_MAX_JSON_BLOCK_BYTES`**, that file/transfer HTTP uses same TLS/auth as JSON-RPC where applicable; reference **`embed_file`** modes.
4. **`examples/README.md`** — New row: minimal **`embed-file-json`** command + optional sample JSON path (once file exists).
5. **Scratch / tactical docs** — When promoting content out of `_scratch`, **refresh** any statement that inbound upload is not implemented in-package.
6. **Release / manual check docs** (`docs/specs/...`, deploy rule) — If “vectorization on localhost:8001” should include **JSON file → embed_file**, add an explicit **`embed-file-json`** checkline (optional; policy decision).

---

**Deliverable path:** `/home/vasilyvz/projects/embed-client/docs/agents/_scratch/researcher_doc_file_vectorization_docs_examples_report.md`
