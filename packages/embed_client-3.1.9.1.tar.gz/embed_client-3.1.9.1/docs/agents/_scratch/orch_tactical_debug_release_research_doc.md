# Release / validation requirements — researcher_doc extraction

**Sources (authoritative for this note):** `docs/PROJECT_RULES.md` (§0 profile, CR-007 quality gate — linters after code changes; no dedicated “deploy matrix” in CR-*), `docs/agents/project_overlay.md`, `.cursor/rules/deploy.mdc`, `README.md`, `CONFIGURATION.md`, plus cross-check `docs/SERVER_MODES_AND_CLIENT.md` (explicit “before release” matrix).

---

## Mandatory pre-publication validation chain (deploy rule)

**Binding rule:** `.cursor/rules/deploy.mdc` (`alwaysApply: true`).

1. **Before publication**, exercise the client against a **real test server** in **all** of the following **eight** security modes (order not specified in sources):
   - http
   - http + token
   - http + token + roles
   - https
   - https + token
   - https + token + roles
   - mtls
   - mtls + roles

2. **Vectorization on real `localhost:8001`:** test **vectorization** against **actual** `localhost:8001` (documentation states this is **usually mTLS**).

3. **Certificates:** use / rely on material under **`mtls_certificates/`** (deploy rule; detailed layout in `CONFIGURATION.md` and `mtls_certificates/README.md` when present).

**Aligned narrative:** `docs/SERVER_MODES_AND_CLIENT.md` § “Deploy verification matrix (8 modes)” duplicates the same eight modes and states that **before release** the **real test server** must be exercised accordingly. `README.md` § “Security modes” points to the deploy rule and to `CONFIGURATION.md` / `docs/SERVER_MODES_AND_CLIENT.md` for mapping.

---

## Canonical mTLS example (localhost:8001)

| Item | Authority |
|------|-----------|
| **Script** | `examples/canonical_mtls_localhost_8001.py` — `build_mtls_localhost_8001_config()`, tour of `EmbeddingClient` with repo certs (`project_overlay.md`, `README.md`, `CONFIGURATION.md` § “Recommended local integration”) |
| **Tests** | `tests/test_canonical_mtls_example.py` |
| **Cert paths (typical)** | Client: `mtls_certificates/client/embedding-service.crt`, `.../embedding-service.key`; CA: `mtls_certificates/ca/ca.crt` (`CONFIGURATION.md`) |
| **Dry vs live** | Default run can be dry / config check; **live** JSON-RPC/WebSocket requires env (below) |

---

## Environment variables (canonical E2E)

| Variable | Role |
|----------|------|
| **`RUN_CANONICAL_MTLS_E2E=1`** | Enables **live** network calls in the canonical mTLS example (`project_overlay.md`, `README.md`, `examples/README.md`). |
| **`CANONICAL_EMBED_FILE_SERVER_PATH`** | Optional **server-visible** filesystem path; when set, includes **`embed_file`** in the tour (`project_overlay.md`, `README.md`, `examples/README.md`). |

**Commands (from `README.md`):**

```bash
python examples/canonical_mtls_localhost_8001.py
RUN_CANONICAL_MTLS_E2E=1 python examples/canonical_mtls_localhost_8001.py
```

---

## `PROJECT_RULES.md` — relevance to “release”

- **§0 / §7:** Profile and pointers; no separate release checklist beyond general **CR-007** (linters/formatters/typecheckers after production code changes).
- **LAYOUT-08** / **CR-017:** Durable ТЗ under `docs/specs/<specname>/`; epic example `docs/specs/server_client_convergence_and_release/` may contain **additional** staged release-validation steps (RV-*) — **not** duplicated here; use if the task is program-of-record for PyPI/convergence work.

---

## Summary checklist (operator-facing)

- [ ] All **8** server modes verified on **test server** (deploy rule + `docs/SERVER_MODES_AND_CLIENT.md`).
- [ ] **Vectorization** verified on **real localhost:8001** (deploy rule; typically mTLS per docs).
- [ ] Certs from **`mtls_certificates/`** as documented.
- [ ] Optional: canonical mTLS tour with **`RUN_CANONICAL_MTLS_E2E=1`**; optional **`CANONICAL_EMBED_FILE_SERVER_PATH`** for `embed_file` coverage.

**File path:** `docs/agents/_scratch/orch_tactical_debug_release_research_doc.md`
