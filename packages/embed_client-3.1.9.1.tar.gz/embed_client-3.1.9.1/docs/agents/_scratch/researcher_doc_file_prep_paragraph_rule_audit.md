# Audit: file prep / chunking narrative vs authoritative paragraph rule

**Role:** researcher_doc (read-only).  
**Repository:** `/home/vasilyvz/projects/embed-client`  
**Date:** 2026-03-30  

## Authoritative rule (code)

Source: `embed_client/md_embed_file_prep.py` — `split_body_into_text_blocks` and module docstring.

- After optional YAML front-matter strip, the **body** is split **only** on the two-character separator **`\n\n`** (after normalizing `\r\n` / `\r` → `\n`).
- Each segment is **stripped**; empty segments after strip are **dropped** (runs of blank lines act as one boundary).
- **No** semantic analysis, **no** “smart” chunking, **no** byte-level re-splitting: if a paragraph block’s UTF-8 encoding exceeds `max_block_bytes`, preparation **fails** with `EmbedClientError`.
- `--max-chunks` only **truncates** the resulting list (smoke tests on large files).

Cross-check: `embed_client/cli.py` epilog and `prepare-embed-file-json` / `--max-block-bytes` help strings state `\n\n` and “error if exceeded”.

---

## Findings ordered by severity

### 1) Wrong / misleading (relative to paragraph-only split or stale facts)

| Path | Issue |
|------|--------|
| `docs/agents/_scratch/orch_tactical_debug_embed_compare_research_code.md` | Claims **embed-client** `prepare-embed-file-json` output is `[{"text": "..."}, ...]` and aligns validation to **objects** — **false** for current tree (`json_embed_file_preflight` + `md_embed_file_prep` use **array of strings**). Misleading for anyone treating scratch as truth. |
| `docs/agents/_scratch/orch_tactical_debug_embed_compare_research_doc.md` | § “Low — Terminology and `json_array` shape” cites **`docs/api_format.md`** as describing objects with a **`text`** field; **current** `docs/api_format.md` (§ JSON-RPC `embed_file`) states **`json_array`** as **array of strings**. Scratch inference that “prep may emit objects with `text`” is **stale / incorrect** vs current client code and top-level API doc. |
| `docs/SERVER_MODES_AND_CLIENT.md` (line ~38) | Phrase **“chunked `json_array` file”** suggests generic chunking rather than **fixed paragraph boundaries (`\n\n`)**; risks confusion with **`vectorize --file`** / line-based batching or server-side chunking. |
| `docs/agents/_scratch/orch_tactical_debug_7d00_acceptance_research_doc.md` (line ~33) | Same **“chunked `json_array`”** wording without `\n\n`-only clarification. |

### 2) Missing detail (accurate but incomplete for the stated rule)

| Path | Issue |
|------|--------|
| `CLI_README.md` (~72) | Says prep **“splits the body into `json_array` blocks respecting the per-block UTF-8 cap”** but does **not** state **delimiter = `\n\n` only**, **no** semantic splitting, **no** automatic sub-split when over cap (user must shorten paragraph or raise limit). |
| `README.md` (~58) | Describes **`prepare-embed-file-json`** → **`json_array`** then **`embed-file-json`**; **no** split semantics. |
| `examples/README.md` (~24–28) | Markdown flow and **`--max-chunks`** documented; **no** explanation that blocks = paragraphs separated by **blank lines** (`\n\n`) or that oversized paragraphs error out. |
| `CONFIGURATION.md` (~245) | **`EMBED_CLIENT_MAX_JSON_BLOCK_BYTES`** explains per-string validation for local **`json_array`**; **does not** tie to prep’s **paragraph** boundaries (readers may think arbitrary chunking is allowed). |
| `docs/api_format.md` (~36–38) | **`json_array`** wire shape (array of strings) is correct; **silent** on how client-side Markdown prep builds those strings — acceptable as API doc, but **no cross-link** to the paragraph rule for operators using **`prepare-embed-file-json`**. |
| `embed_client/embedding_client.py` — `embed_file_from_local_json_file` docstring (~1136–1142) | Points to **`json_embed_file_preflight`**; **does not** mention that **`md_embed_file_prep`** is the Markdown/plain-text **`\n\n`** splitter (fine for API-only readers, **gap** for holistic “file prep” story). |
| `examples/embed_file_json_local.py` | Describes upload + **`embed_file_from_local_json_file`**; **no** prep/split semantics (acceptable as minimal example; still a **coverage gap** vs “how blocks were produced”). |
| `examples/canonical_mtls_localhost_8001.py` | **`embed_file`** with server path only; **no** local JSON prep narrative — **N/A** for split rule unless extended (not wrong). |

### 3) OK / aligned

| Path | Note |
|------|------|
| `embed_client/md_embed_file_prep.py` | Module docstring + `split_body_into_text_blocks` docstring match the authoritative rule explicitly (**`\n\n`**, no byte-level re-chunking). |
| `embed_client/cli.py` | Top epilog (~43–44): **“body split on `\n\n`”**; subparser help (~230, ~248–249): blank lines / paragraph block / error if exceeded; **`--max-chunks`** (~256): “blocks”, smoke tests — consistent. |
| `embed_client/json_embed_file_preflight.py` | Documents **validation** per array element (strings, UTF-8 size); does not claim Markdown splitting — **correct scope**. |
| `CLI_README.md` (~74) | Contrast **`embed-file-json`** vs **`vectorize --file`** (line-based **`embed`**) is **correct** and reduces confusion between pipelines. |

### 4) Internal scratch / research (mixed; not primary user-facing)

These **mention** embed-file prep / blocks / metrics; several **omit** `\n\n`-only wording or use “chunk” loosely. Treat as **follow-up** unless promoted to canonical docs:

- `docs/agents/_scratch/orch_tactical_debug_7d00_acceptance_research_code.md` — flow accurate; refers to `split_body_into_text_blocks` without spelling `\n\n` in prose.
- `docs/agents/_scratch/researcher_code_live_file_vec_validation_metrics.md` — references `split_body_into_text_blocks` + byte cap; OK; “chunk” appears in **script names** / **`embed`** batch context (different from prep).
- `docs/agents/_scratch/researcher_doc_live_file_vec_validation.md` — “chunk order is deterministic (split order)” (~74); could be tightened to **“`\n\n` paragraph order”**.
- `docs/agents/_scratch/researcher_code_7d00_e2e_flow.md`, `docs/agents/_scratch/coder_auto_7d00_live_acceptance_run.md`, `docs/agents/_scratch/tester_auto_7d00_acceptance_verdict.md` — procedural; low prep semantics detail.
- `docs/agents/_scratch/vectorization_commands_research.md` — distinguishes **`embed_file`** vs **`--file`** / `run_file_chunking_check_8001.py`; no embed-file prep split detail.

---

## Recommended concrete edits (by file)

- **`CLI_README.md`** (`prepare-embed-file-json` bullet): Add 1–2 sentences: body split **only** on **double newline** (`\n\n`) into paragraph blocks; **no** semantic chunking; blocks over **`--max-block-bytes`** / env cap **fail** preparation (no automatic split); optional note that **`--max-chunks`** only truncates the block list.

- **`README.md`** (paragraph on `prepare-embed-file-json`): One short clause: prep splits Markdown/plain body on **blank lines (`\n\n`)** into strings; oversized paragraphs require editing or raising the byte cap.

- **`docs/SERVER_MODES_AND_CLIENT.md`**: Replace **“chunked `json_array`”** with **“`json_array` built from paragraph blocks (split on `\n\n` only)”** or equivalent; keep front-matter / byte cap / `--max-chunks` bullets.

- **`examples/README.md`**: Under §2, add one line: **`prepare-embed-file-json`** splits on **double newlines** only; each non-empty paragraph is one JSON string; very long paragraphs must stay under the byte limit or preparation errors.

- **`CONFIGURATION.md`** (`EMBED_CLIENT_MAX_JSON_BLOCK_BYTES`): Add that for **`prepare-embed-file-json`**, the same limit applies **per paragraph block** after **`\n\n`** splitting (no auto-split).

- **`docs/api_format.md`** (optional, one line under `json_array`): Point to **`CLI_README.md`** / **`prepare-embed-file-json`** for **client-side** Markdown/plain-text paragraph splitting rules (so API readers know prep is not arbitrary chunking).

- **`embed_client/embedding_client.py`**: In `embed_file_from_local_json_file` docstring, optional “See also” to **`embed_client.md_embed_file_prep`** when strings were produced by **`prepare-embed-file-json`**.

- **`docs/agents/_scratch/orch_tactical_debug_embed_compare_research_*.md`**: **Correct or archive** object-with-`text` / stale **`api_format`** claims so scratch does not contradict **`json_embed_file_preflight`** + current **`docs/api_format.md`**.

- **`docs/agents/_scratch/orch_tactical_debug_7d00_acceptance_research_doc.md`**: Replace **“chunked `json_array`”** with paragraph / `\n\n` wording for consistency with product docs.

---

## Summary table (user-facing primary docs)

| File | Severity vs rule | Notes |
|------|------------------|--------|
| `embed_client/md_embed_file_prep.py` | OK | Defines rule |
| `embed_client/cli.py` (help/epilog) | OK | Matches rule |
| `CLI_README.md` | Missing detail | Add `\n\n`-only + fail-on-oversize |
| `README.md` | Missing detail | Add one clause |
| `docs/SERVER_MODES_AND_CLIENT.md` | Misleading term | “chunked” → paragraph / `\n\n` |
| `docs/api_format.md` | Missing (optional) | Cross-link to prep semantics |
| `CONFIGURATION.md` | Missing detail | Tie env var to prep paragraphs |
| `examples/README.md` | Missing detail | One short paragraph |
| `examples/embed_file_json_local.py` | Missing (low) | Optional comment/docstring line |
| `embed_client/json_embed_file_preflight.py` | OK | Validation only |
| `embed_client/embedding_client.py` | Missing (low) | Optional cross-ref to prep module |

---

**Deliverable path (for `orchestrator_tactical_debug`):**  
`/home/vasilyvz/projects/embed-client/docs/agents/_scratch/researcher_doc_file_prep_paragraph_rule_audit.md`
