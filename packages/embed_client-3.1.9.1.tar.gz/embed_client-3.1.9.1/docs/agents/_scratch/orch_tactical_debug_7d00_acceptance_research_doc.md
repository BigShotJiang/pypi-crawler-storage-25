# orch_tactical_debug — 7d00 acceptance (document-backed research)

**Scope:** Facts extracted for acceptance review using **`/home/vasilyvz/projects/embed-client/7d-00-48.md`** as the designated acceptance source file, cross-referenced with project documentation only from: **`README.md`**, **`CONFIGURATION.md`**, **`CLI_README.md`**, **`docs/SERVER_MODES_AND_CLIENT.md`**, **`examples/README.md`**.

---

## 1. Acceptance source file `7d-00-48.md` (what the repo documents about it)

- The file begins with YAML-style front matter (`---` / `%%7d-00%%` / `---`) and is a long Markdown body (theory content). It is **not** valid **`json_array`** as-is.
- **`examples/README.md`** explicitly names repo root **`7d-00-48.md`** as the Markdown example and states that YAML front matter is not valid **`json_array`** without preparation; it gives a **documented command sequence** (prepare → embed) using that path (see section 2.5).

**Note:** Deeper in the same file there are YAML blocks labeled **`acceptance:`** (e.g. cosmology/GW criteria). Those blocks describe **physics/model acceptance**, not embed-client CLI behavior. Repository docs that cite **`7d-00-48.md`** do so only as a **sample Markdown input** for the local **`json_array`** → **`embed_file`** workflow.

---

## 2. Documented steps: Markdown preparation and live file embedding / vectorization

### 2.1 `README.md`

- **When** the input is only on the client (no shared disk with the server): use CLI **`embed-file-json`** (or **`embed_file_from_local_json_file`**) so the client **validates**, **uploads** via the adapter, resolves **`storage_path`** via **`get_upload_session`**, then runs **`embed_file`** with **`format=json_array`**.
- **For Markdown** (including YAML front matter): run **`prepare-embed-file-json`** first to produce a valid **`json_array`** (array of strings), then **`embed-file-json`**.
- Optional: **`--show-progress`** to stream server WebSocket/status lines to **stderr** during the job wait (details in **`CLI_README.md`**).

### 2.2 `CLI_README.md`

- **`prepare-embed-file-json`** (no server connection): reads UTF-8 **Markdown** or plain text; optionally strips YAML front matter between the **first pair of `---` lines**; splits the body into **`json_array`** blocks with a per-block UTF-8 cap; writes a JSON file. Options: **`-o` / `--output`** (default `<input_stem>_embed_file.json` beside input), **`--max-block-bytes`**, **`--max-chunks`**, **`--no-strip-front-matter`**. **Then** run **`embed-file-json`** on that JSON file.
- **`embed-file-json`**: **validates** local UTF-8 JSON (non-empty array of strings), enforces per-item UTF-8 size (default 1 MiB; **`EMBED_CLIENT_MAX_JSON_BLOCK_BYTES`** or **`--max-block-bytes`**), **uploads**, resolves **`storage_path`**, runs server **`embed_file`** with **`input_file`** = that path and **`format=json_array`**. Optional **`--show-progress`**: print WebSocket/status JSON lines to **stderr** while waiting. Other flags include **`--wait-timeout`**, **`--download-to`**, **`--skip-download`**, **`--model`**, **`--dimension`**, **`--device`**, **`--error-policy`**, **`--upload-filename`**.
- **`vectorize --file`** is documented as **line-based text for `embed`**, not the same path as **`embed-file-json`**.

### 2.3 `docs/SERVER_MODES_AND_CLIENT.md`

- **Pipeline (client-only file):** **validate** local UTF-8 JSON **`json_array`** → **upload** (same HTTP/TLS + auth as JSON-RPC) → **`get_upload_session`** → **`embed_file`** with **`storage_path`** as **`input_file`**, **`format=json_array`**.
- **CLI:** **`prepare-embed-file-json`** (Markdown/plain text → chunked **`json_array`**, optional front-matter strip, **`--max-chunks`** for smoke tests) → **`embed-file-json`** (upload + **`embed_file`** wait). **`--show-progress`**: WebSocket/status JSON lines to **stderr** while waiting.
- **Programmatic:** **`EmbeddingClient.embed_file_from_local_json_file`**; optional **`on_ws_event`** described as matching the CLI progress hook.
- **Server-side file already visible to the service:** use **`embed_file`** with server-visible **`input_file`** (e.g. canonical tour with **`CANONICAL_EMBED_FILE_SERVER_PATH`** — see **`examples/README.md`** / **`README.md`**).

### 2.4 `CONFIGURATION.md`

- **`EMBED_CLIENT_MAX_JSON_BLOCK_BYTES`:** optional cap on UTF-8 byte length of **each string item** when **validating** a local JSON file before **`embed_file`** (`json_array`); default 1 MiB if unset. **Validation is local on the client**; upload uses the same adapter transport and auth as JSON-RPC. Pointers to **`CLI_README.md`** (**`embed-file-json`**, **`prepare-embed-file-json`**) and **`docs/SERVER_MODES_AND_CLIENT.md`**.

### 2.5 `examples/README.md` (concrete recipe using `7d-00-48.md`)

- **Sample JSON:** **`examples/data/embed_file_json_array_sample.json`**.
- **Markdown flow** (calls out repo root **`7d-00-48.md`**: YAML front matter is not valid **`json_array`** as-is): prepare JSON on disk, then **`embed-file-json`**; large docs: **`--max-chunks`** on prepare for a subset smoke test.

```bash
python -m embed_client prepare-embed-file-json ./7d-00-48.md -o /tmp/7d_embed.json --max-chunks 5
embed-vectorize --config /path/to/config.json embed-file-json /tmp/7d_embed.json --show-progress
```

- Direct JSON without prepare step (with config + running service):

```bash
embed-vectorize --config /path/to/config.json embed-file-json examples/data/embed_file_json_array_sample.json
```

- Cross-refs: **`CLI_README.md`**, **`docs/api_format.md`** (`embed_file`) — the latter is outside the five-file list but listed here as referenced by examples.

---

## 3. Documented requirement: server progress visibility in console

- **Not** framed as a hard “requirement” in these docs; it is an **optional** behavior:
  - **`--show-progress`** on **`embed-file-json`**: print **WebSocket/status JSON lines to stderr** while waiting for completion (**`README.md`**, **`CLI_README.md`**, **`docs/SERVER_MODES_AND_CLIENT.md`**).
  - **`README.md`** describes this as streaming server WebSocket/status lines to **stderr** during the job wait.

---

## 4. Documented validation vs command exit code

**Within the five scoped documents:**

- **Documented validation (local, pre-upload / pre-`embed_file`):** non-empty JSON array of strings; per-item UTF-8 size limits (**`EMBED_CLIENT_MAX_JSON_BLOCK_BYTES`**, **`--max-block-bytes`**); **`prepare-embed-file-json`** output semantics (front matter, block splitting). This is **input** validation before the server job, not a documented rule tying **HTTP/RPC response body** to **process exit code**.
- **Exit codes:** the five files **do not** specify that the CLI must exit non-zero when the server returns a structurally successful RPC but output fails downstream checks, nor do they document **`embed-vectorize embed-file-json`** exit-code matrix. **`embed-config-validator`** is documented for **configuration JSON** validation (separate from **`embed-file-json`**).

**Gap (documentation completeness):** alignment of **semantic validation of `embed_file` job results** with **CLI exit status** is **not** described in **`README.md`**, **`CONFIGURATION.md`**, **`CLI_README.md`**, **`docs/SERVER_MODES_AND_CLIENT.md`**, or **`examples/README.md`**. (Implementation may exist in code/examples elsewhere; that is outside this doc-only extraction.)

---

## 5. Summary table

| Topic | Where documented | Content |
|--------|------------------|---------|
| MD → `json_array` | CLI_README, SERVER_MODES, README, examples | `prepare-embed-file-json`; optional `---` front matter strip; `--max-chunks`, `--max-block-bytes` |
| Live embed from local JSON | Same + CONFIGURATION | `embed-file-json` / `embed_file_from_local_json_file`; upload + `embed_file` |
| Sample using `7d-00-48.md` | examples/README | Commands with `./7d-00-48.md` and `/tmp/7d_embed.json` |
| Progress in console | README, CLI_README, SERVER_MODES | Optional `--show-progress` → stderr |
| Validation vs exit code | Scoped docs | Local JSON validation documented; **no** documented exit-code contract for post-response validation |

---

*Researcher role: read-only on repository tree; deliverable written per orchestrator request.*
