<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# Project overlay — embed-client

Repository-specific paths, behavior, and restrictions. Universal layout: [`PROJECT_RULES.md`](../PROJECT_RULES.md) §3 (`LAYOUT-*`).

## Functional context

- **Role:** Async Python client for the Embedding Service API: HTTP/HTTPS/mTLS, auth (API key and related modes), queue and command execution via **`mcp-proxy-adapter`**’s `JsonRpcClient`.
- **User-facing entry points:** **`EmbeddingClient`** (runtime), **`ClientFactory`** / **`create_client`** (construction), **`ConfigValidator`**, **`ClientConfigGenerator`** (config tooling).
- **Main package / application root:** `embed_client/` — production code (see §0 `PACKAGE_ROOT`).
- **Tests:** `tests/` with **pytest**; configuration in **`pyproject.toml`** (`[tool.pytest.ini_options]`). There is **no** `pytest.ini` at the repository root.
- **Planning stack:** ТЗ and durable plans under **`docs/specs/<specname>/`** per **LAYOUT-09** / **CR-017** only; optional informal notes under `docs/plans/`. The duplicate **`docs/specs/tech_spec/`** tree was **removed**. **`docs/tech_spec/`** was **pruned** so that only **`docs/tech_spec/branches/documentation_normalization/`** remains (archived tactical-branch material). Do not treat `docs/tech_spec/` as an active planning root; authoritative specs live under **`docs/specs/<specname>/`**.

## Canonical mTLS example (localhost:8001)

- **Script:** [`canonical_mtls_localhost_8001.py`](../../examples/canonical_mtls_localhost_8001.py) — runnable tour of **`EmbeddingClient`** with repo **`mtls_certificates/`** bundles; see [`mtls_certificates/README.md`](../../mtls_certificates/README.md) if present.
- **Tests:** [`test_canonical_mtls_example.py`](../../tests/test_canonical_mtls_example.py).
- **Environment:** **`RUN_CANONICAL_MTLS_E2E=1`** — live calls; **`CANONICAL_EMBED_FILE_SERVER_PATH`** — optional server-visible path to include **`embed_file`** in the tour.
- **Root docs:** [`README.md`](../../README.md), [`examples/README.md`](../../examples/README.md).

## Canonical `docs/` subtrees (**LAYOUT-08**)

Place new **durable** documentation in the subtree that matches its role. Details and IDs: [`PROJECT_RULES.md`](../PROJECT_RULES.md) §3.

| Subtree | Purpose |
|---------|---------|
| `docs/agents/` | Shared agent context: overlay, universal pointers, maintainer notes. |
| `docs/ai_reports/` | Working AI outputs; promote finished text into `docs/specs/`, guides, `docs/bugreports/`. |
| `docs/specs/` | Per-spec root **`docs/specs/<specname>/`** (**LAYOUT-09**): `spec.md` plus nested global / tactical / atomic `.md` files; scaffold → **`docs/specs/_template/`**. |
| `docs/plans/` | Roadmaps and planning documents outside the strict per-spec task tree. |
| `docs/bugreports/` | Stable bug analyses and postmortems. |
| `docs/EN/` | English user-facing docs (e.g. `api/`, guides); use **`DOC_FILENAME_STYLE`** from **§0** / **§7**. |
| `docs/RU/` | Russian mirror; **mirror path** under `docs/EN/` when both exist. |
| `docs/reports/` | **Local scratch only**, gitignored — informal session output; nothing durable here. |
| `docs/*.md` (root of `docs/`) | Cross-cutting guides (`PROJECT_RULES.md`, `rules_bundle_README.md`, …). |

## Directories and files beyond the universal skeleton

| Path | Note |
|------|------|
| `code_analysis/` | Generated code map / index (`USE_CODE_MAP` = yes, **CR-006**); do not hand-edit. |
| `mtls_certificates/` | Sample / test certificates for mTLS and local integration (see deploy testing rule). |
| `configs/` | Sample configuration files (non-secret). |
| `examples/` | Usage examples outside the main package. |
| `scripts/` | Ops, CI helpers, smoke runners, non-pytest tooling (**LAYOUT-07**). |
| `test_environment/` | Local integration / environment assets for manual testing. |
| `keys/` | Key material for local testing only; never commit real production secrets. |
| `logs/` | Runtime logs (typically gitignored). |
| Root `README.md`, `CONFIGURATION.md`, `CLI_README.md` | User-facing entry points and configuration reference. |

## Project-specific restrictions

- **Secrets:** Never add real credentials, API keys, or production private keys to the repo.
- **Scope:** Changes stay within **this** repository unless the user explicitly allows other paths.
- **Generated artifacts:** **`code_mapper`** output under `code_analysis/` — regenerate when **CR-006** applies; do not hand-edit.

## Filled profile pointer

Concrete profile keys: [`PROJECT_RULES.md`](../PROJECT_RULES.md) **§0** and **§7**.
