<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# Baseline audit: documentation migration (embed-client → server-internal client)

### Migration baseline — authoritative links

- [Tactical task (`migration_baseline_deliverable`)](../specs/server_client_convergence_and_release/baseline_audit_and_contract_capture/migration_baseline_deliverable/spec.md)
- [Global step (baseline audit and contract capture)](../specs/server_client_convergence_and_release/baseline_audit_and_contract_capture/spec.md)
- [Epic (server–client convergence and release)](../specs/server_client_convergence_and_release/spec.md)

This file is **evidence** for `migration_baseline_deliverable`, and **Decisions locked for downstream** in the [tactical spec](../specs/server_client_convergence_and_release/baseline_audit_and_contract_capture/migration_baseline_deliverable/spec.md) are the authoritative checklist against sections **1–7** below (source-of-truth split, durable doc inventory, deletion and rewrite candidates, server doc gaps, and normalization notes).

Research scope: documentation that must be removed, rewritten, or superseded when replacing the current `embed-client` implementation with the client from `/home/vasilyvz/projects/embed`. Aligns with `docs/PROJECT_RULES.md` **LAYOUT-08** / **LAYOUT-09** and epic `docs/specs/server_client_convergence_and_release/spec.md` (server-internal client is source of truth when contracts differ; backward compatibility forbidden).

---

## 1. Source-of-truth split (baseline)

| Layer | Path | Role after migration |
|--------|------|----------------------|
| Migration epic (keep, authoritative for repo work) | `/home/vasilyvz/projects/embed-client/docs/specs/server_client_convergence_and_release/spec.md` | Defines convergence objective, non-goals, acceptance criteria |
| Migration plan | `/home/vasilyvz/projects/embed-client/docs/specs/server_client_convergence_and_release/plan.md` | Wave 3 `documentation_normalization` depends on settled code |
| Documentation normalization step | `/home/vasilyvz/projects/embed-client/docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md` | Exit criteria for surviving docs |
| Server-owned client API (external reference) | `/home/vasilyvz/projects/embed/docs/CLIENT_DEVELOPER_GUIDE.md` | User-facing `EmbeddingClient` (`embed.client.embedding_client`), queue/embed behavior |
| Server-owned implementation (external reference) | `/home/vasilyvz/projects/embed/embed/client/embedding_client.py` | Ground truth for public methods and transport assumptions |

**Conflict:** Prior embed-client technical work assumed an **adapter-centric** stack (`mcp-proxy-adapter`, `embed_client/adapter_*.py`, `EmbeddingServiceAsyncClient`). The convergence epic makes **server-internal `EmbeddingClient`** canonical. Documentation rooted in the adapter model is **not** durable truth for the post-migration repo.

---

## 2. Inventory: durable embed-client docs tied to the old client

### 2.1 User-facing and repo-root product docs

| Path | Tie to old client |
|------|-------------------|
| `/home/vasilyvz/projects/embed-client/README.md` | Russian feature list, `EmbeddingServiceAsyncClient`, `ClientConfig`, `embed_client/example_async_usage.py`, config generator/validator as core story |
| `/home/vasilyvz/projects/embed-client/CONFIGURATION.md` | Configuration model for current package layout |
| `/home/vasilyvz/projects/embed-client/CLI_README.md` | `python -m embed_client.cli`, install `embed-client` |

### 2.2 `docs/` root analytical / session-adjacent markdown

| Path | Tie to old client |
|------|-------------------|
| `/home/vasilyvz/projects/embed-client/docs/performance_test_results.md` | `EmbeddingServiceAsyncClient`, WebSocket push, `embed_client/testing_client.py` |
| `/home/vasilyvz/projects/embed-client/docs/TEST_SUITE_HANG_ANALYSIS.md` | `tests/test_adapter_transport_coverage.py`, adapter transport |

### 2.3 Agent and governance overlays (describe old architecture)

| Path | Tie to old client |
|------|-------------------|
| `/home/vasilyvz/projects/embed-client/docs/agents/project_overlay.md` | States adapter-based client, `embed-config-generator` / `embed-config-validator`, `embed_client/` as main package; points legacy ТЗ to `docs/tech_spec/` (see section 6) |

### 2.4 Stable governance (templates; not product narrative — update references only)

| Path | Note |
|------|------|
| `/home/vasilyvz/projects/embed-client/docs/PROJECT_RULES.md` | §0 `PACKAGE_ROOT` `embed_client/` persists as name until rename decision; **LAYOUT-08** lists `docs/tech_spec/` for legacy |
| `/home/vasilyvz/projects/embed-client/docs/agents/universal_project_context.md` | Universal pointers |
| `/home/vasilyvz/projects/embed-client/docs/agents/common_agent_rules.md` | Universal rules |
| `/home/vasilyvz/projects/embed-client/docs/agents/README.md` | Index |
| `/home/vasilyvz/projects/embed-client/docs/agents/MAINTAINERS.md` | Maintainers |
| `/home/vasilyvz/projects/embed-client/docs/rules_bundle_README.md` | Rules bundle |
| `/home/vasilyvz/projects/embed-client/docs/specs/_template/README.md` | **LAYOUT-09** scaffold |
| `/home/vasilyvz/projects/embed-client/docs/specs/_template/spec.md` | Template |
| `/home/vasilyvz/projects/embed-client/docs/specs/_template/example_global_step/spec.md` | Template |
| `/home/vasilyvz/projects/embed-client/docs/specs/_template/example_global_step/example_tactical_step/spec.md` | Template |
| `/home/vasilyvz/projects/embed-client/docs/specs/_template/example_global_step/example_tactical_step/example_atomic_step.md` | Template |

### 2.5 Epic under `docs/specs/` (migration — keep)

| Path |
|------|
| `/home/vasilyvz/projects/embed-client/docs/specs/server_client_convergence_and_release/spec.md` |
| `/home/vasilyvz/projects/embed-client/docs/specs/server_client_convergence_and_release/plan.md` |
| `/home/vasilyvz/projects/embed-client/docs/specs/server_client_convergence_and_release/baseline_audit_and_contract_capture/spec.md` |
| `/home/vasilyvz/projects/embed-client/docs/specs/server_client_convergence_and_release/production_migration_and_legacy_removal/spec.md` |
| `/home/vasilyvz/projects/embed-client/docs/specs/server_client_convergence_and_release/tests_scripts_and_dependency_cleanup/spec.md` |
| `/home/vasilyvz/projects/embed-client/docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md` |
| `/home/vasilyvz/projects/embed-client/docs/specs/server_client_convergence_and_release/release_validation_and_pypi_publication/spec.md` |

### 2.6 Overlapping tactical spec (pre-convergence wording)

| Path | Note |
|------|------|
| `/home/vasilyvz/projects/embed-client/docs/specs/client_server_alignment_migration/remove_legacy_and_normalize_verification/legacy_cleanup_and_verification/spec.md` | References `embed_client/` migration alignment with `../embed`; parent `docs/specs/client_server_alignment_migration/spec.md` is **absent** in tree — fragment only |

### 2.7 Legacy technical-spec tree (adapter-centric program of record)

**Root and indexes:**

| Path |
|------|
| `/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/tech_spec.md` |
| `/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/implementation_plan.md` |
| `/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/CROSS_DOCUMENT_COHERENCE_AUDIT.md` |

**Global step stubs:**

| Path |
|------|
| `/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/steps/adapter-centric-client-foundation.md` |
| `/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/steps/embed-command-and-result-contract-alignment.md` |
| `/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/steps/queue-and-websocket-identifier-separation.md` |
| `/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/steps/verification-matrix-and-runtime-validation.md` |

**Branch `adapter-centric-client-foundation` (all paths under):**

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/adapter-centric-client-foundation/tasks/cleanup-adapter-transport-token-generation.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/adapter-centric-client-foundation/tasks/cleanup-adapter-transport-token-generation/steps/ATOMIC_STEPS_INDEX.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/adapter-centric-client-foundation/tasks/cleanup-adapter-transport-token-generation/steps/remove-token-generation-method.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/adapter-centric-client-foundation/tasks/remove-fake-auth-execution.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/adapter-centric-client-foundation/tasks/remove-fake-auth-execution/steps/ATOMIC_STEPS_INDEX.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/adapter-centric-client-foundation/tasks/remove-fake-auth-execution/steps/remove-fake-auth-methods-from-clientauthmanager.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/adapter-centric-client-foundation/tasks/remove-fake-auth-execution/steps/update-async-client-remove-auth-manager-execution.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/adapter-centric-client-foundation/tasks/remove-fake-auth-execution/steps/update-init-exports-for-clientauthmanager.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/adapter-centric-client-foundation/tasks/update-tests-adapter-centric.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/adapter-centric-client-foundation/tasks/update-tests-adapter-centric/steps/index.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/adapter-centric-client-foundation/tasks/update-tests-adapter-centric/steps/parallel-waves.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/adapter-centric-client-foundation/tasks/update-tests-adapter-centric/steps/update-test-adapter-integration.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/adapter-centric-client-foundation/tasks/update-tests-adapter-centric/steps/update-test-adapter-transport.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/adapter-centric-client-foundation/tasks/update-tests-adapter-centric/steps/update-test-async-client.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/adapter-centric-client-foundation/tasks/update-tests-adapter-centric/steps/update-test-auth-manager.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/adapter-centric-client-foundation/tasks/update-tests-adapter-centric/steps/update-test-client-factory.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/adapter-centric-client-foundation/tasks/verify-client-construction-paths.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/adapter-centric-client-foundation/tasks/verify-client-construction-paths/steps/ATOMIC_PARALLEL_WAVES.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/adapter-centric-client-foundation/tasks/verify-client-construction-paths/steps/ATOMIC_STEPS_INDEX.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/adapter-centric-client-foundation/tasks/verify-client-construction-paths/steps/verify-async-client-adapter-usage.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/adapter-centric-client-foundation/tasks/verify-client-construction-paths/steps/verify-client-factory-adapter-usage.md`

**Branch `embed-command-and-result-contract-alignment` (all paths under):**

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/embed-command-contract-alignment.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/embed-command-contract-alignment/steps/ATOMIC_INDEX.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/embed-command-contract-alignment/steps/PARALLEL_WAVES.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/embed-command-contract-alignment/steps/validate-and-align-async-client-api-mixin-embed.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/embed-command-contract-alignment/steps/validate-and-align-testing-client-embed.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/embed-job-status-alignment.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/embed-job-status-alignment/steps/adapter-transport-queue-get-job-status.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/embed-job-status-alignment/steps/async-client-queue-mixin-job-status-methods.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/embed-job-status-alignment/steps/ATOMIC_INDEX.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/embed-job-status-alignment/steps/PARALLEL_WAVES.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/embed-job-status-alignment/steps/testing-client-job-status.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/embed-result-mode-handling.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/embed-result-mode-handling/steps/async-client-api-mixin-embed-result-handling.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/embed-result-mode-handling/steps/ATOMIC_INDEX.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/embed-result-mode-handling/steps/ATOMIC_PARALLEL_WAVES.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/embed-result-mode-handling/steps/extract-job-id-from-adapter-response.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/embed-result-mode-handling/steps/testing-client-embed-result-handling.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/models-timing-stats-alignment.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/models-timing-stats-alignment/steps/async-client-api-mixin-models-timing-stats.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/models-timing-stats-alignment/steps/ATOMIC_INDEX.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/models-timing-stats-alignment/steps/ATOMIC_PARALLEL_WAVES.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/embed-command-and-result-contract-alignment/tasks/models-timing-stats-alignment/steps/testing-client-models-timing-stats.md`

**Branch `queue-and-websocket-identifier-separation` (all paths under):**

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/identifier-extraction-and-type-separation.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/identifier-extraction-and-type-separation/steps/ATOMIC_INDEX.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/identifier-extraction-and-type-separation/steps/ATOMIC_PARALLEL_WAVES.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/identifier-extraction-and-type-separation/steps/create-identifier-types-module.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/identifier-extraction-and-type-separation/steps/update-api-mixin-extraction-functions.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/identifier-extraction-and-type-separation/steps/update-queue-mixin-submit-job.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/identifier-focused-tests.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/identifier-focused-tests/steps/ATOMIC_INDEX.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/identifier-focused-tests/steps/PARALLEL_WAVES.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/identifier-focused-tests/steps/test-identifier-extraction.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/identifier-focused-tests/steps/test-identifier-separation.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/public-api-identifier-documentation.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/public-api-identifier-documentation/steps/ATOMIC_INDEX.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/public-api-identifier-documentation/steps/ATOMIC_PARALLEL_WAVES.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/public-api-identifier-documentation/steps/step-01-update-embed-docstring-async-client-api-mixin.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/public-api-identifier-documentation/steps/step-02-update-cmd-docstring-async-client-api-mixin.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/public-api-identifier-documentation/steps/step-03-update-embed-docstring-testing-client.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/queue-polling-identifier-handling.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/queue-polling-identifier-handling/steps/ATOMIC_INDEX.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/queue-polling-identifier-handling/steps/ATOMIC_PARALLEL_WAVES.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/queue-polling-identifier-handling/steps/update-adapter-transport-queue-get-job-status.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/queue-polling-identifier-handling/steps/update-async-client-queue-mixin-methods.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/queue-polling-identifier-handling/steps/update-testing-client-queue-methods.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/websocket-correlation-identifier-handling.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/websocket-correlation-identifier-handling/steps/ATOMIC_INDEX.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/websocket-correlation-identifier-handling/steps/ATOMIC_PARALLEL_WAVES.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/websocket-correlation-identifier-handling/steps/update-adapter-transport-docstrings.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/websocket-correlation-identifier-handling/steps/update-queue-mixin-docstrings.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/queue-and-websocket-identifier-separation/tasks/websocket-correlation-identifier-handling/steps/update-testing-client-docstrings.md`

**Branch `verification-matrix-and-runtime-validation` (all paths under):**

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/identifier-separation-validation-tests.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/identifier-separation-validation-tests/steps/ATOMIC_STEPS_INDEX.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/identifier-separation-validation-tests/steps/create-identifier-separation-test-file.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/result-mode-validation-tests.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/result-mode-validation-tests/steps/ATOMIC_INDEX.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/result-mode-validation-tests/steps/test-embed-immediate-mode.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/result-mode-validation-tests/steps/test-embed-queued-mode.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/result-mode-validation-tests/steps/test-websocket-completion.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/security-matrix-validation-tests.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/security-matrix-validation-tests/steps/create-security-matrix-test-file.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/update-maintained-real-server-scripts.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/update-maintained-real-server-scripts/steps/ATOMIC_PARALLEL_WAVES_TIMEOUT.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/update-maintained-real-server-scripts/steps/ATOMIC_STEPS_INDEX.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/update-maintained-real-server-scripts/steps/ATOMIC_STEPS_TIMEOUT_INDEX.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/update-maintained-real-server-scripts/steps/update-compare-direct-vs-client.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/update-maintained-real-server-scripts/steps/update-run-batch-performance.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/update-maintained-real-server-scripts/steps/update-run-bidirectional-ws-performance.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/update-maintained-real-server-scripts/steps/update-run-cuda-stress.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/update-maintained-real-server-scripts/steps/update-run-real-server-mtls-test.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/update-maintained-real-server-scripts/steps/update-run-real-server-performance.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/update-maintained-real-server-scripts/steps/update-run-testing-client-performance.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/update-maintained-real-server-scripts/steps/update-run-timing-statistics.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/update-maintained-real-server-scripts/steps/update-timeout-batch-performance.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/update-maintained-real-server-scripts/steps/update-timeout-bidirectional-ws-performance.md`

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/update-maintained-real-server-scripts/steps/update-timeout-compare-direct-vs-client.md`

**Branch `fix-test-hanging-issues`:**

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/branches/fix-test-hanging-issues/tasks/fix-critical-test-hangs.md`

---

## 3. Deletion candidates (post-migration / documentation_normalization)

**Entire subtree — superseded as program of record by `server_client_convergence_and_release` and contradicts “server-internal client is canonical”:**

`/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/`

**Rationale:** `tech_spec.md` mandates `mcp-proxy-adapter`-only transport and lists `embed_client/adapter_*.py`, `async_client*.py`, `testing_client.py` as the reconciliation surface. After migration, that work item is obsolete; keeping it invites false authority.

**Session / analytical docs tied to removed modules:**

| Path |
|------|
| `/home/vasilyvz/projects/embed-client/docs/performance_test_results.md` |
| `/home/vasilyvz/projects/embed-client/docs/TEST_SUITE_HANG_ANALYSIS.md` |

**Unless preserved as historical archive elsewhere:** delete or move to non-tracked scratch per **LAYOUT-08** `docs/reports/` policy — default recommendation: **delete** when tests/scripts they reference are gone.

**Optional deletion after merge decision:** `/home/vasilyvz/projects/embed-client/docs/specs/client_server_alignment_migration/remove_legacy_and_normalize_verification/legacy_cleanup_and_verification/spec.md` — redundant with `production_migration_and_legacy_removal` / `documentation_normalization` if parent epic is abandoned; if kept, needs explicit parent `spec.md` under **LAYOUT-09**.

---

## 4. Rewrite / supersede candidates (not bare deletion)

| Path | Action |
|------|--------|
| `/home/vasilyvz/projects/embed-client/README.md` | Full rewrite: imports, features, CLI, security matrix must match migrated package and `pyproject.toml` entry points |
| `/home/vasilyvz/projects/embed-client/CONFIGURATION.md` | Align with server-internal client config surface (may differ from `ClientConfig` / adapter config) |
| `/home/vasilyvz/projects/embed-client/CLI_README.md` | Align with actual module path and CLI after migration (`embed_client.cli` may change) |
| `/home/vasilyvz/projects/embed-client/docs/agents/project_overlay.md` | Replace adapter-centric description with migrated layout; fix legacy path pointer (`docs/tech_spec/` vs actual `docs/specs/tech_spec/` until deletion) |

**Governance:** `/home/vasilyvz/projects/embed-client/docs/PROJECT_RULES.md` — update §0 / §7 rows if package directory or PyPI name changes; **LAYOUT-08** row for `docs/tech_spec/` should reflect whether legacy tree is removed or relocated.

---

## 5. Gaps vs server-internal truth (embed repository)

Documentation and code paths on the server side that should drive contract capture and post-migration docs (concrete paths only):

| Path | Relevance |
|------|-----------|
| `/home/vasilyvz/projects/embed/docs/CLIENT_DEVELOPER_GUIDE.md` | Primary user-facing client API and usage patterns |
| `/home/vasilyvz/projects/embed/docs/coalescing_plan/09_embed_command_routing.md` | Embed command routing context |
| `/home/vasilyvz/projects/embed/docs/coalescing_plan/08_embed_job_status.md` | Job status semantics |
| `/home/vasilyvz/projects/embed/docs/coalescing_plan/11_timing_and_timing_stats.md` | Timing/stats fields |
| `/home/vasilyvz/projects/embed/docs/EMBED_REQUEST_LIFECYCLE.md` | Request lifecycle |
| `/home/vasilyvz/projects/embed/docs/openapi_server_setup_guide.md` | Server/OpenAPI setup (integration context) |
| `/home/vasilyvz/projects/embed/embed/client/embedding_client.py` | Implementation truth for public API |
| `/home/vasilyvz/projects/embed/embed/client/embedding_client_helpers.py` | Helper behavior |
| `/home/vasilyvz/projects/embed/embed/commands/embed_command_schema.py` | Command schema |
| `/home/vasilyvz/projects/embed/embed/commands/embed_router.py` | Router behavior |
| `/home/vasilyvz/projects/embed/embed/commands/embed_job_status_command.py` | Job status command |
| `/home/vasilyvz/projects/embed/embed/commands/models_command.py` | Models command |

**Gap:** embed-client docs do not document `embed.client.embedding_client.EmbeddingClient` at all; they document `EmbeddingServiceAsyncClient` and adapter layers. After migration, user-facing docs must be reconciled with `CLIENT_DEVELOPER_GUIDE.md` (or a single derived copy in this repo) to avoid drift.

---

## 6. Coherence notes for `documentation_normalization` (wave 3)

1. **Single epic authority:** Treat `/home/vasilyvz/projects/embed-client/docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md` as the gate for “what may remain.” Legacy `docs/specs/tech_spec/` should not be updated in parallel — remove or archive first to prevent dual truth.

2. **LAYOUT-08 path mismatch:** Canonical rules cite `/home/vasilyvz/projects/embed-client/docs/tech_spec/` for legacy material; the actual legacy tree is `/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/`. `implementation_plan.md` references `docs/tech_spec/tech_spec.md` which does not exist at that path. Normalization should fix pointers in `PROJECT_RULES.md` and `project_overlay.md` after the legacy tree is deleted or moved.

3. **LAYOUT-09 orphan:** `/home/vasilyvz/projects/embed-client/docs/specs/client_server_alignment_migration/` lacks a root `spec.md`. Either add parent epic or fold content into `server_client_convergence_and_release`.

4. **External mirror:** If `/home/vasilyvz/projects/embed/docs/CLIENT_DEVELOPER_GUIDE.md` remains the authoritative user guide, embed-client README should link to it or duplicate with a stated “upstream” line to prevent PyPI consumers from seeing conflicting APIs.

5. **Deploy rule alignment:** Repository rule `.cursor/rules/deploy.mdc` (security matrix + localhost vectorization) still applies; surviving docs must describe how to run those checks against the **migrated** client entry points, not `EmbeddingServiceAsyncClient.from_config`.

---

## 7. Key findings (summary)

- The durable technical program under `/home/vasilyvz/projects/embed-client/docs/specs/tech_spec/` is **architecturally incompatible** with the convergence epic’s decision to adopt the server-internal `EmbeddingClient`.
- Product-facing markdown at repo root and under `/home/vasilyvz/projects/embed-client/docs/` is **entirely anchored** to `embed_client.async_client` / adapter modules.
- Server-side contract documentation exists primarily under `/home/vasilyvz/projects/embed/docs/` with **`CLIENT_DEVELOPER_GUIDE.md`** as the closest user-facing contract; embed-client lacks an equivalent for the target API.
- **LAYOUT-08** / **LAYOUT-09** housekeeping: resolve `docs/tech_spec/` vs `docs/specs/tech_spec/` and the orphan `client_server_alignment_migration` fragment during the same wave as deletions.

---

*Report path:* `/home/vasilyvz/projects/embed-client/docs/ai_reports/baseline_audit_doc_research.md`
