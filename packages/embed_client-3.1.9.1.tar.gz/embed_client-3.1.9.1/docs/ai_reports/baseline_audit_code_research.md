# Baseline audit — code research (server_client_convergence_and_release)

### Migration baseline — authoritative links

- [Tactical task (`migration_baseline_deliverable`)](../specs/server_client_convergence_and_release/baseline_audit_and_contract_capture/migration_baseline_deliverable/spec.md)
- [Global step (baseline audit and contract capture)](../specs/server_client_convergence_and_release/baseline_audit_and_contract_capture/spec.md)
- [Epic (server–client convergence and release)](../specs/server_client_convergence_and_release/spec.md)

This file is **evidence** for `migration_baseline_deliverable`, and **Decisions locked for downstream** in the [tactical spec](../specs/server_client_convergence_and_release/baseline_audit_and_contract_capture/migration_baseline_deliverable/spec.md) are the authoritative checklist against sections **B–F** below (**B**–**C** implementation paths and contracts, **D** runtime dependencies, **E**–**F** consolidation and risks).

**Scope:** Read-only comparison of `/home/vasilyvz/projects/embed-client` (PyPI-style package) vs `/home/vasilyvz/projects/embed` (server-internal canonical client). **Server is source of truth** for runtime contracts where they differ.

**Date:** 2026-03-29

---

## A) `embed_client` package map (embed-client repo)

### Entry points

| Mechanism | Location |
|-----------|----------|
| Console scripts | `pyproject.toml` → `embed-config-generator`, `embed-config-validator`, `embed-vectorize` → `embed_client.config_generator_cli:main`, `embed_client.config_validator_cli:main`, `embed_client.cli:cli_main` |
| Module CLI | `embed_client/__main__.py` (vectorization / CLI entry) |

### Public API (`embed_client/__init__.py`)

Exported names include: `EmbeddingServiceAsyncClient`, `ClientConfig`, `ClientAuthManager`, `ClientSSLManager`, `ClientFactory`, `ClientConfigGenerator`, `ConfigValidator`, `AsyncClientConfigMixin`, `EmbeddingServiceClient`, deprecated alias `TestingEmbeddingClient`, `wait_for_job_poll`, `list_commands_via_client`.

Package docstring states transport is **only** `JsonRpcClient` via `AdapterTransport` — *"This package does not ship a parallel HTTP/WebSocket stack"* (`embed_client/__init__.py`, lines 5–8).

**Version drift:** `__init__.__version__` is `"3.1.7.25"` while `pyproject.toml` has `version = "3.1.7.28"` — packaging inconsistency to fix in a migration branch.

### Composition: async client

`EmbeddingServiceAsyncClient` (`embed_client/async_client.py`) mixes:

- `AsyncClientConfigMixin`, `AsyncClientResponseMixin`, `AsyncClientLifecycleMixin`
- `AsyncClientAPIMixin` — `cmd`, `embed`, `models`, `timing_stats`, `health`, OpenAPI helpers
- `AsyncClientQueueMixin` — `wait_for_job`, `wait_for_job_via_websocket`, `job_status`, queue listing, `submit_job`, etc.
- `AsyncClientIntrospectionMixin`, `AsyncClientFactoryMixin`

### Adapter layer

`embed_client/adapter_transport.py` — sole owner of `mcp_proxy_adapter.client.jsonrpc_client.JsonRpcClient` construction; exposes `jsonrpc_call`, `health`, `execute_async`, `execute_command_unified`, `queue_get_job_status`, queue list/stop/delete, WebSocket helpers.

### Auth / SSL (configuration-only)

- `embed_client/auth.py` — `ClientAuthManager`: validates config, builds header dicts (`api_key`, `Bearer` for JWT token, `Basic`); **does not** import PyJWT or perform token minting.
- `embed_client/ssl_manager.py` — file existence / structure checks only; **does not** import `cryptography`.

### “Second client” surface

`embed_client/testing_client.py` defines `EmbeddingServiceClient` — adapter-based client aligned with server-style kwargs (`protocol`, `host`, `port`, …) and overlapping features with `EmbeddingServiceAsyncClient` (config dict vs flat args). This is a **parallel** public API for tests/scripts, not a separate transport.

---

## B) `../embed` — canonical client code paths

### Core migratable unit (embedding service client)

| Path | Role |
|------|------|
| `embed/client/embedding_client.py` | **`EmbeddingClient`** — main class; constructs `JsonRpcClient` directly; `embed`, `wait_for_job`, `job_status`, `embed_file`, `models`, `list_commands`, `jsonrpc`, `fetch_openapi_schema`, `http_get`, `open_bidirectional_ws_channel`, optional embed_file status store |
| `embed/client/embedding_client_helpers.py` | `wait_for_job_poll`, `list_commands_via_client` (same helpers reimplemented under `embed_client.testing_client_helpers`) |
| `embed/client/embed_file_status_store.py` | In-memory job/message store for optional `enable_embed_file_status_store` |
| `embed/client/__init__.py` | Exports `EmbeddingClient`, `BidirectionalWsChannel`, `open_bidirectional_ws_channel` from adapter |

### Shared server package dependencies (not transport-specific)

| Path | Role |
|------|------|
| `embed/constants.py` | e.g. `EMBED_COMMAND_SCHEMA_DEFAULT_ERROR_POLICY = "fail_fast"` |
| `embed/exceptions.py` | `EmbedClientError`, hierarchy |

### Adjacent / not the minimal client library

| Path | Role |
|------|------|
| `embed/client/service_manager_health.py` | Health checks for **service manager**; imports **`httpx`** directly (line 19) and `EmbeddingClient` — **deployment glue**, not part of the slim JSON-RPC client unit. |

### Server repo dependency pin (reference)

`requirements.txt` (embed repo) includes `mcp-proxy-adapter>=6.10.0` (line 15), matching embed-client’s lower bound.

---

## C) Contract comparison (commands, job status, identifiers, result modes)

**Legend:** *Server* = `embed/client/embedding_client.py` (`EmbeddingClient`). *Client* = `embed_client` async stack + `AdapterTransport`.

### Embed command & wait semantics

- **Server** (`EmbeddingClient.embed`): `wait=True` uses **`execute_async("embed_execute", params, …)`** — in-process embed path with WS completion; `wait=False` uses `jsonrpc_call("embed", params)` (lines 412–417, 334–446).
- **Client** (`AsyncClientAPIMixin.embed`): uses **`execute_command_unified(command="embed", …, auto_poll=False)`** then branches on `job_id` / `deliver_id` and `wait` / `use_push` (`embed_client/async_client_api_mixin.py` ~734–797).

Both assume adapter ≥ 6.10 for job tracking / WS; **wire method names align with server** (`embed`, `embed_execute` on wait path).

### Default error policy

- Server: `EMBED_COMMAND_SCHEMA_DEFAULT_ERROR_POLICY` — `"fail_fast"` (`embed/constants.py` line 17).
- Client: `EMBED_DEFAULT_ERROR_POLICY` — `"fail_fast"` (`embed_client/constants.py` line 20).

**Aligned.**

### Job status RPC preference

- **Server** `job_status`: tries **`queue_get_job_status` first**, then **`embed_job_status`** (lines 627–658).
- **Client** `AdapterTransport.queue_get_job_status`: tries **`embed_job_status` first**, then falls back to **`queue_get_job_status`** (`embed_client/adapter_transport.py` lines 326–370).

**Mismatch (server wins):** order of precedence differs; server prefers queue API first to match queue-native jobs.

### `wait_for_job` implementation strategy

- **Server** `wait_for_job`: if `JsonRpcClient.wait_for_job` exists, uses **WebSocket** path; else **`wait_for_job_poll`** (`embedding_client.py` 472–487).
- **Client** `AsyncClientQueueMixin.wait_for_job`: **HTTP polling loop** via `job_status` / `queue_get_job_status` (`async_client_queue_mixin.py` 37–219); docstring states it *"polls queue status via HTTP"* (lines 46–50). Separate **`wait_for_job_via_websocket`** exists for push.

**Mismatch:** default “wait_for_job” on the standalone client is poll-centric; server client defaults to WS when the adapter provides `wait_for_job`. Public behavior should converge on **server semantics** (WS-first when available).

### Identifiers

- Both stacks distinguish **queue `job_id`** vs **adapter `deliver_id`** for `execute_async` / WS (`embed_client/async_client_api_mixin.py` `_extract_job_id_from_response` / `_extract_deliver_id_from_response`, lines 31–119; server embed path uses `execute_async` for wait=True).

### Result modes / terminal WS events

Both accept overlapping terminal events, e.g. `job_completed`, `job_completed_success`, `delivery_completed` (server `_normalize_terminal_job_payload` / `_embed_via_execute_async`, lines 92–107, 520–528; client `wait_for_job_via_websocket`, `async_client_queue_mixin.py` 262–271).

### Server-only surface (large)

**`embed_file`** (server `embedding_client.py` 662–889): full pipeline with `download_file`, `transfer_ack`, checksum verification — **not** present as a single method on `EmbeddingServiceAsyncClient` in the reviewed mixins; migration must either port this API or explicitly scope it out.

---

## D) `pyproject.toml` dependencies vs migrated `../embed` imports

### Declared (embed-client `pyproject.toml` lines 60–65)

```
PyJWT>=2.0.0
cryptography>=3.0.0
pydantic>=2.0.0
mcp-proxy-adapter>=6.10.0
```

### What migrated server client code imports

From `embed/client/embedding_client.py` (lines 8–26): **stdlib**, `embed.client.embed_file_status_store`, `mcp_proxy_adapter.client.jsonrpc_client.JsonRpcClient`, `embed.client.embedding_client_helpers`, `embed.constants`, `embed.exceptions`.

**Conclusion:** For the **Python code** of `EmbeddingClient` itself, **`mcp-proxy-adapter>=6.10.0` is the only third-party runtime requirement** mirrored in embed-client. `httpx` is used **inside** the adapter (and in `EmbeddingClient.close` docstring: *"adapter HTTP client (httpx)"*, line 935) — **not** declared in embed-client; acceptable as **transitive** via `mcp-proxy-adapter`.

### Direct deps: evidence of use / obsolescence

| Dependency | Evidence |
|------------|----------|
| **mcp-proxy-adapter** | `embed_client/adapter_transport.py` line 17 — `from mcp_proxy_adapter.client.jsonrpc_client import ...` |
| **pydantic** | **No** `import pydantic` / `from pydantic` under `embed_client/`. **Scripts only:** e.g. `scripts/run_embedding_test_server.py` line 20, `scripts/run_https_test_server.py` line 21 |
| **PyJWT** | **No** `import jwt` or `from jwt` anywhere in repo except JWT-related **strings** in config (`grep` across `*.py`). **Not used by package code.** |
| **cryptography** | **No** `import cryptography` in `embed_client/`. Comment-only reference in `tests/test_ssl_manager.py` line 146 |

**Assessment:** `mcp-proxy-adapter>=6.10.0` is **necessary and sufficient** for the **same logical imports** as server `embedding_client.py`. **`PyJWT` and `cryptography` appear unused** as direct imports in the current tree; **`pydantic` is unused by the `embed_client` package** but used by optional **scripts** — if scripts stay in-repo, either move pydantic to optional extras or add script-specific dependency notes.

---

## E) Explicit deletion / consolidation candidates (legacy or duplicate paths)

These are **candidates for a later migration branch**, not automatic deletes — verify consumers first.

1. **Dual client implementations:** `EmbeddingServiceAsyncClient` (config-heavy) vs `EmbeddingServiceClient` (`testing_client.py`) vs server `EmbeddingClient` — overlapping responsibilities; convergence should leave **one** supported user-facing story plus thin test helpers.
2. **Examples / demos with stale APIs:** `embed_client/auth_examples.py` calls `auth_manager.create_jwt_token` / `authenticate_jwt` / `authenticate_api_key` (e.g. lines 101–127) — **`ClientAuthManager` in `auth.py` does not define these methods** (it ends at `get_supported_methods`). These modules are **broken or dead** as runnable demos.
3. **Stress / coverage-oriented tests:** e.g. `tests/test_async_client_stress*.py`, `test_*_coverage*.py` — often tied to internal layout; revisit after API freeze.
4. **Scripts** under `scripts/` that duplicate CI or manual server runners — prune after unified test strategy (many assume localhost:8001 / mtls per project rules).

**Not** candidates: `AdapterTransport`, factory/config/validator CLIs — they support the standalone package’s distribution story unless explicitly replaced by server copies.

---

## F) Risks and blockers for downstream migration

1. **Contract ordering:** `queue_get_job_status` vs `embed_job_status` precedence must match server (`embedding_client.job_status`) or queue jobs may hit wrong RPC first on some deployments (`adapter_transport.py` vs server lines 627–658).
2. **Wait semantics:** Align `EmbeddingServiceAsyncClient.wait_for_job` with server **WS-first** when `JsonRpcClient.wait_for_job` exists; otherwise document poll-only mode as intentional divergence.
3. **`embed_file` + transfer pipeline:** Full server client includes **`download_file` / `transfer_ack`** flows; absent from async public API — gap for parity.
4. **Module namespace:** Server uses `embed.*`; package uses `embed_client.*` — mechanical rename plus **exception** type mapping (`EmbedClientError` vs `EmbeddingService*`).
5. **`service_manager_health.py`:** Requires **`httpx`** — if ported into embed-client, either add explicit dependency or reimplement via `JsonRpcClient` only.
6. **Unused / misleading dependencies:** `PyJWT`, `cryptography`, and package-level `pydantic` risk **audit noise** and false security surface unless justified or removed/ref scoped.
7. **Version fields:** `__version__` vs `pyproject.toml` mismatch blocks trustworthy release notes.

---

## Summary table

| Area | embed-client | ../embed (server) |
|------|--------------|-------------------|
| Transport | `AdapterTransport` → `JsonRpcClient` | Direct `JsonRpcClient` in `EmbeddingClient` |
| Public class names | `EmbeddingServiceAsyncClient`, `EmbeddingServiceClient` | `EmbeddingClient` |
| Job status RPC order | `embed_job_status` first | `queue_get_job_status` first (**canonical**) |
| Default wait | Poll in `wait_for_job` mixin | WS via `wait_for_job` when present (**canonical**) |
| `embed_file` | Not on async client (in reviewed API) | Full implementation |
| Extra deps in pyproject | PyJWT, pydantic, cryptography + adapter | Adapter pinned in `requirements.txt` |

---

*End of report.*
