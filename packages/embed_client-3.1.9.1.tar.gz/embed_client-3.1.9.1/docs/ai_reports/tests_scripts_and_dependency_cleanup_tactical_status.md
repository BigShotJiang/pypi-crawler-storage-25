# Tactical status — `tests_scripts_and_dependency_cleanup`

**Date:** 2026-03-29  
**Audience:** global orchestrator (`server_client_convergence_and_release`)  
**Author:** tactical orchestrator (coordination only; no code edits or test execution by this agent)

## Subordinate agents state

| Agent | Status | Scope / notes |
|--------|--------|----------------|
| `planner_auto` | **Idle (atomics pre-materialized)** | TSC-01 … TSC-08 under `docs/specs/server_client_convergence_and_release/tests_scripts_and_dependency_cleanup/steps/` |
| `coder_auto` | **Not executed in this session** | Implementation of TSC-01 … TSC-08 not run from this chat |
| `tester_auto` | **Not executed in this session** | No fresh pytest / linter verdict from this chat |
| `researcher_code` | **Evidence on disk** | `docs/ai_reports/tests_scripts_dependency_cleanup_code_research.md` (2026-03-29) |
| `researcher_doc` | **Evidence on disk** | `docs/ai_reports/tests_scripts_dependency_cleanup_doc_research.md` |
| `doc_writer` | **Not invoked** | Examples man-page docstrings / Wave 3 overlap per epic |

**Blocker:** This runtime does not expose invocable `coder_auto` / `tester_auto` / `planner_auto` tools. Per tactical rules, the tactical orchestrator **must not** substitute manual coding, repository research, or test execution. **Escalation:** run TSC-01 … TSC-08 via the specialist chain in an environment where those agents are available, or authorize a single coding/testing agent.

## Tactical artifacts created/updated (this session)

| Artifact | Path |
|----------|------|
| Branch README | `docs/tech_spec/branches/tests_scripts_and_dependency_cleanup/README.md` |
| Tactical umbrella task | `docs/tech_spec/branches/tests_scripts_and_dependency_cleanup/tasks/tests_scripts_and_dependency_cleanup.md` |
| Global step pointer | `docs/specs/server_client_convergence_and_release/tests_scripts_and_dependency_cleanup/spec.md` (Execution status — orchestration layout links) |
| This report | `docs/ai_reports/tests_scripts_and_dependency_cleanup_tactical_status.md` |

## Dependency verdict (pre-implementation; from research + baseline)

**Final “exact resulting `pyproject.toml` diff” is not available** until `coder_auto` completes TSC-02 and `tester_auto` confirms.

**Intended direction (locked):**

- **Keep:** `mcp-proxy-adapter>=6.10.0` in core runtime dependencies.
- **Remove from core unless re-proven by grep on final tree:** `PyJWT`, `cryptography`, `pydantic` (no direct imports under `embed_client/` per research).
- **Add optional extra** (name TBD in TSC-02, e.g. `scripts` / `dev-servers`) including **pydantic** for: `scripts/run_embedding_test_server.py`, `scripts/run_https_test_server.py`, `test_environment/examples/full_application/proxy_endpoints.py`.
- **Version:** eliminate drift — TSC-01 aligns `embed_client.__version__` with `[project].version` or uses metadata-derived version (research noted drift `pyproject` `3.1.7.28` vs `__init__` `3.1.7.25`; production migration report claims alignment at `3.1.7.28` — **reconcile during TSC-01**).

## Tests / scripts / examples — removed or updated (expected targets; not execution-confirmed)

Per `docs/ai_reports/tests_scripts_dependency_cleanup_code_research.md` and atomic steps (not applied in this session):

| Area | Action |
|------|--------|
| `embed_client/auth_examples.py` | Fix to current `ClientAuthManager` or remove (TSC-03) |
| `tests/test_async_client.py` | Strip legacy aiohttp bulk; extract adapter tests (TSC-04) |
| `tests/test_auth_helpers.py`, `tests/test_auth.py`, `tests/test_ssl_manager.py` | Delete or replace with narrow tests (TSC-05) |
| `pytest.ini` vs `[tool.pytest.ini_options]` | Single source (TSC-06) |
| `scripts/*.py` hard-coded `.venv/lib/python3.12/...` | Portable resolution (TSC-07) |
| Redundant coverage modules | Consolidate (TSC-08) |

**Git status at conversation start** showed many deleted/modified test files from parallel migration work; final list after cleanup must come from `coder_auto` + `tester_auto` reports.

## Verification status

| Gate | Status |
|------|--------|
| Atomics indexed | **Done** — `steps/ATOMIC_STEPS_INDEX.md` |
| Tactical docs under `docs/tech_spec/branches/...` | **Done** |
| Code + dependency changes | **Pending** — `coder_auto` |
| Full test + lint/typecheck | **Pending** — `tester_auto` |
| Examples: full capability coverage + man-page docstrings + execution tests | **Partially overlapping** Wave 3; parent step requires execution checks when examples are touched |

## Remaining blockers for docs / release

1. **Specialist execution gap:** no `coder_auto` / `tester_auto` run from this tactical orchestrator session.
2. **Residual from migration report:** optional httpx `DeprecationWarning` in `tests/test_all_security_modes.py` — cosmetic follow-up.
3. **Documentation wave:** README/CONFIG normalization remains for `documentation_normalization` per production migration handoff.

## Parallelism (CR-016)

W1: TSC-01 ∥ TSC-02 → W2: TSC-03 … TSC-07 in parallel → W3: TSC-08 after TSC-04 + TSC-05. See `ATOMIC_STEPS_INDEX.md`.

---

*End of report.*
