<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# Tests, scripts, and dependency migration — inventory

**Date:** 2026-03-30

**Epic:** `docs/specs/server_client_convergence_and_release/spec.md`  
**Global step:** `tests_scripts_and_dependency_cleanup`

This note records the current layout of linting, package code, tests, scripts, examples, and dependencies for that global step. It does not restate locked epic decisions beyond alignment: backward compatibility is out of scope (see epic **Non-goals** and **Fixed decisions**).

---

## Linter / typecheck configuration (current)

### `.flake8`

- **max-line-length:** 120  
- **extend-ignore:** `E203` (Black-compatible slice spacing; avoids false positives with the formatter)  
- **extend-exclude:** augments flake8 defaults so virtualenvs, VCS, caches, IDE folders, and build/install trees are not linted (e.g. `.venv`, `venv`, `env`, `__pycache__`, `.mypy_cache`, `.pytest_cache`, `.ruff_cache`, `build`, `dist`, `*.egg-info`, `.eggs`, `node_modules`, `.cursor`, `.tox`, `.nox`, `.hypothesis`, `htmlcov`, `.idea`, `.vscode`, `wheels`, `site-packages`).

### `[tool.mypy]` in `pyproject.toml`

- **python_version:** `"3.9"`  
- **exclude:** list of regexes matched against file paths; same intent as flake8 exclusions—venv roots, VCS, caches, build/install trees, IDE/service directories.  
- **Note:** A comment in `pyproject.toml` states that **flake8 reads the root `.flake8` only**; `[tool.flake8]` is unused unless a flake8 pyproject plugin is installed.

---

## Code

- **Package:** flat `embed_client` layout under the repository root.  
- **Scale:** 37 Python modules (including `__init__.py`).  
- **Version:** `__version__` from `importlib.metadata.version("embed-client")`, with fallback `"3.1.7.28"` when package metadata is missing (e.g. editable checkouts in some sandboxes).

---

## Tests

- **Layout:** `tests/` with **21** test modules plus `conftest.py` (**22** Python files total).  
- **`[tool.pytest.ini_options]` (summary):** `testpaths = ["tests"]`; markers `integration` and `stress`; `asyncio_default_fixture_loop_scope = "function"`; **timeout** 300s, **timeout_method** `thread`; **addopts** `-n auto` (parallel workers).  
- **Stress behavior:** tests marked `@pytest.mark.stress` are **skipped** unless pytest is run with **`--use-stress`** (see `tests/conftest.py`).

---

## Scripts / `test_environment`

- **`scripts/` (~32 Python harnesses):** operational runners for modes, performance, security CLI, embedding/vectorization checks, test servers, and repo helpers (plus `_repo_path.py` and a metrics JSON artifact). Purpose: manual and semi-automated validation outside the core pytest suite.  
- **`test_environment/` (~39 files):** JSON configs (HTTP/HTTPS/mTLS, roles), certificate and key material for local/proxy-style testing, embedded sample apps under `examples/`, and cert-generation scripts under `scripts/`. Purpose: reproducible local configs and TLS assets for integration-style runs.

---

## Examples

Key files under `examples/`:

| Item | Role |
|------|------|
| `README.md` | Overview of the example set |
| **`canonical_mtls_localhost_8001.py`** | **Canonical** end-to-end example (real server, mTLS, repo certs) |
| `security_examples.py`, `security_examples_ru.py` | Security-mode demonstrations |
| `async_testing_client_example.py` | Async testing-client usage |
| `configs/http_simple.json`, `configs/https_token.json`, `configs/mtls_roles.json` | Sample client configs |

---

## Dependencies

- **Runtime:** `mcp-proxy-adapter>=6.10.0` (see `pyproject.toml` `[project] dependencies`).  
- **Optional extras:** `scripts` (e.g. Pydantic), `test` (pytest stack), `dev` (test stack + black, flake8, mypy).

---

## Documentation pointers

| Document | Purpose |
|----------|---------|
| `docs/specs/server_client_convergence_and_release/spec.md` | Epic specification |
| `docs/specs/server_client_convergence_and_release/plan.md` | Plan |
| `docs/specs/server_client_convergence_and_release/tests_scripts_and_dependency_cleanup/spec.md` | Global step spec for this inventory |
| `docs/specs/server_client_convergence_and_release/tests_scripts_and_dependency_cleanup/tasks/tsc_linter_exclusions_and_migration_inventory.md` | Related task |
| `docs/specs/server_client_convergence_and_release/tests_scripts_and_dependency_cleanup/steps/ATOMIC_STEPS_INDEX.md` | Step index for this global step |
| `docs/ai_reports/tests_scripts_and_dependency_cleanup_closure_report.md` | Closure report |
| `docs/ai_reports/tests_scripts_and_dependency_cleanup_tactical_status.md` | Tactical status |
| `docs/ai_reports/tests_scripts_dependency_cleanup_code_research.md` | Code research |
| `docs/ai_reports/tests_scripts_dependency_cleanup_doc_research.md` | Doc research |

---

## Verification status

| Check | Result | Notes |
|-------|--------|--------|
| pytest | **PASS** | 165 passed, 67 skipped |
| black | **PASS** | — |
| flake8 | **PASS** | — |
| mypy (`embed_client`) | **PASS** | — |
| httpx | — | DeprecationWarnings observed; cosmetic / upstream, not treated as gate failures |

---

## Section checklist (required coverage)

1. Title and date; epic + global step — **above**  
2. Linter / typecheck (flake8, mypy, pyproject comment) — **§ Linter / typecheck**  
3. Code (flat package, ~37 modules, version) — **§ Code**  
4. Tests (modules, conftest, pytest options, stress) — **§ Tests**  
5. Scripts / test_environment — **§ Scripts / test_environment**  
6. Examples — **§ Examples**  
7. Dependencies — **§ Dependencies**  
8. Documentation pointers — **§ Documentation pointers**  
9. Verification status — **§ Verification status**
