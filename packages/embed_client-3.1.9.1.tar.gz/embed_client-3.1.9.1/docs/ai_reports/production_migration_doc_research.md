<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# Production migration and legacy removal: documentation handoff (researcher_doc)

**Scope:** Implementation handoff facts for `docs/specs/server_client_convergence_and_release/production_migration_and_legacy_removal/spec.md` — not full doc rewrite (reserved for `documentation_normalization`, Wave 3 per `docs/specs/server_client_convergence_and_release/plan.md`).

**Baseline:** `docs/ai_reports/baseline_audit_doc_research.md`

**Authoritative locked decisions:** `docs/specs/server_client_convergence_and_release/baseline_audit_and_contract_capture/migration_baseline_deliverable/spec.md` (“Decisions locked for downstream”) and epic `docs/specs/server_client_convergence_and_release/spec.md` (“Fixed decisions”).

---

## 1. Verified user-facing paths (exist on disk)

| Path | Status |
|------|--------|
| `README.md` | Present (repo root) |
| `CONFIGURATION.md` | Present |
| `CLI_README.md` | Present |
| `docs/agents/project_overlay.md` | Present |

---

## 2. Git status vs `tech_spec` location

**Observed (this workspace, `git status`):**

- **Tracked path `docs/tech_spec/**`:** many files show **`D` (deleted)** relative to `HEAD` — the directory **`docs/tech_spec/` is absent** on disk.
- **`docs/specs/tech_spec/`:** directory **exists** on disk with a full legacy tree (baseline inventory aligns with content), but git reports it as **`??` (untracked)** — i.e. not the same as “tracked deletions under `docs/specs/tech_spec`”; the staged/tracked legacy tree was under **`docs/tech_spec/`**, not under `docs/specs/tech_spec/`.

**Implication for handoff:** locked decision #4 states the legacy program under `docs/specs/tech_spec/` is **superseded** by the convergence epic. The tree on disk under `docs/specs/tech_spec/` must be **removed or deliberately excluded**, not maintained as parallel authority. `PROJECT_RULES.md` / `project_overlay.md` still describe **`docs/tech_spec/`** for legacy (**LAYOUT-08**), which no longer matches the physical layout (`docs/specs/tech_spec/` untracked copy vs deleted `docs/tech_spec/`).

---

## 3. Documentation files that will need updates **after** code migration

Paths only (includes governance/agent docs whose path templates or role descriptions become wrong once the migrated API and package layout exist). Full narrative rewrites belong to Wave 3; this list is what implementers should **not forget** when handing off “implementation facts” for docs.

- `README.md`
- `CONFIGURATION.md`
- `CLI_README.md`
- `docs/agents/project_overlay.md`
- `docs/PROJECT_RULES.md`
- `docs/agents/common_agent_rules.md`
- `docs/agents/README.md`
- `docs/performance_test_results.md` *(or delete per baseline deletion candidates)*
- `docs/TEST_SUITE_HANG_ANALYSIS.md` *(or delete per baseline deletion candidates)*
- `examples/README.md`

**Optional / conditional (only if still in tree after migration decisions):**

- `docs/specs/client_server_alignment_migration/remove_legacy_and_normalize_verification/legacy_cleanup_and_verification/spec.md` — baseline notes redundancy with `production_migration_and_legacy_removal` / `documentation_normalization`; resolve or fold, not “user-facing” but affects doc coherence.

**Out of scope for this branch (epic wording):** long-form end-user documentation and PyPI mechanics are deferred; the list above still captures **minimum** touch points so Wave 3 is not blocked on silent drift.

---

## 4. Contradictions or tension vs locked / fixed decisions

1. **`README.md` — backward compatibility:** Current text claims API backward compatibility (“Обратная совместимость — API формат не изменился…”). Epic **fixed decision:** backward compatibility is **forbidden**. After migration, README must not retain that claim.

2. **`project_overlay.md` — architecture:** Describes adapter-centric execution, `embed-config-generator` / `embed-config-validator`, and legacy ТЗ under `docs/tech_spec/`. **Locked:** canonical implementation from `../embed`, server wins on contracts, legacy `docs/specs/tech_spec/` program superseded; root README/CONFIGURATION/CLI and `project_overlay.md` require rewrite against migrated API (`migration_baseline_deliverable` #4).

3. **Legacy spec path — three-way mismatch:** **LAYOUT-08** / overlay cite `docs/tech_spec/`; baseline inventory documented `docs/specs/tech_spec/`; git shows **deletions** under `docs/tech_spec/` and an **untracked** `docs/specs/tech_spec/`. That contradicts a single canonical location and aligns with baseline **§6** (“LAYOUT-08 path mismatch”) — must be resolved in normalization, not by parallel edits to the old adapter program.

4. **`production_migration_and_legacy_removal` vs epic documentation completeness:** This global step’s **out of scope** excludes long-form end-user docs; the epic **acceptance criteria** require surviving documentation to be complete and aligned. **Resolution:** not a logical contradiction — phased delivery: this branch supplies **implementation facts**; Wave **`documentation_normalization`** closes completeness. Handoff should explicitly list **which** user-facing files still describe the pre-migration client (section 3).

5. **Deploy rule (`.cursor/rules/deploy.mdc`):** Baseline notes surviving docs must describe running the security matrix / localhost vectorization against **migrated** entry points, not `EmbeddingServiceAsyncClient.from_config`. The rule file itself is not product docs; **README** / **CONFIGURATION** / runbooks under `docs/` are the usual place to align instructions.

---

## 5. Key findings (short)

- All four checked user-facing entry paths **exist**.
- Git **deletions** apply to **`docs/tech_spec/`** (tracked tree removed); **`docs/specs/tech_spec/`** is present but **untracked** — different from “deletions under `docs/specs/tech_spec`” in git.
- Post-migration doc updates must cover root product markdown, **`project_overlay`**, **`PROJECT_RULES`**, agent path conventions, **`examples/README.md`**, and session/analytical docs under **`docs/`** unless deleted per baseline.
- Strongest **content** contradiction with locked decisions: **backward compatibility** claim in **`README.md`** vs epic non-goal; **adapter-centric** overlay vs server-internal **`EmbeddingClient`** canonical story.

---

*Report path:* `/home/vasilyvz/projects/embed-client/docs/ai_reports/production_migration_doc_research.md`
