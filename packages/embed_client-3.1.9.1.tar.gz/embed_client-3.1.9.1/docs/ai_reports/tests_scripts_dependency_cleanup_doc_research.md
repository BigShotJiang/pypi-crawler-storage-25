<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# Documentation research: tests / scripts / dependency cleanup vs `documentation_normalization`

**Scope:** Repository `embed-client` at `/home/vasilyvz/projects/embed-client`.  
**Branch context:** `tests_scripts_and_dependency_cleanup` (cleanup tests, scripts, deps); **`documentation_normalization` is a later wave** — this report lists documentation that will likely need updates when that wave runs, after the cleanup changes land.

**Research question:** Which documented paths, commands, inventories, or dependency claims would become **false or misleading** after: removing legacy tests, pruning scripts, normalizing `pyproject.toml` dependencies (e.g. dropping `PyJWT` / `cryptography` unless justified, revising `pydantic` placement)?

---

## Documentation overview

- **User-facing and root docs** (`README.md`, `CLI_README.md`) carry **explicit runtime dependency bullets** and **concrete pytest / script commands** — highest risk of drift.
- **Operational / analysis docs** (`docs/TEST_SUITE_HANG_ANALYSIS.md`, `docs/performance_test_results.md`) are **snapshots tied to specific test modules and scripts** — high risk if those files are removed or renamed.
- **Specs under `docs/specs/tech_spec/`** describe **maintained scripts** and **hang-mitigation work** against **named legacy test runners** — reconcile or archive when scripts/tests change.
- **AI baseline reports** (`docs/ai_reports/baseline_audit_*.md`) already record **current** dependency analysis; they will need **refresh or supersession** if decisions change (not necessarily “wrong” today).
- **Governance docs** (`docs/PROJECT_RULES.md`, `docs/agents/project_overlay.md`) are mostly **structural** (pytest, `scripts/`) but may need tweaks if test layout or pytest configuration location changes.

---

## Per-file inventory (paths to revisit in `documentation_normalization`)

| Path | Note |
|------|------|
| **`README.md`** | **Runtime deps:** Lists `PyJWT`, `cryptography`, `pydantic` with rationale strings — must match post-cleanup `pyproject.toml` / extras. **Testing:** Example commands name `tests/test_async_client.py`, `test_config.py`, `test_auth.py`, `test_ssl_manager.py` — update if modules removed/renamed. **Script:** `python scripts/run_embed_contract_8001.py` — verify script still exists or replace workflow. **Marketing line:** “84+ тестов” — update if suite size changes materially. |
| **`CLI_README.md`** | **Testing** section: `python scripts/run_cli_manual.py` — fails doc if script pruned; replace with standard pytest/CLI validation story. |
| **`CONFIGURATION.md`** | No explicit pip dependency list; JWT/schema sections describe **config fields**, not `PyJWT` package. **Low** direct risk for dep drops; confirm wording still matches auth implementation if JWT handling changes. |
| **`docs/performance_test_results.md`** | Entire doc is anchored to **five named scripts** under `scripts/` (`run_chunking_vectorization_metrics_8001.py`, `run_batch_performance.py`, `run_real_server_performance.py`, `run_bidirectional_ws_performance.py`, `run_testing_client_performance.py`) and sample shell commands — **full rewrite or archive** if scripts are pruned or renamed. |
| **`docs/TEST_SUITE_HANG_ANALYSIS.md`** | References **`pytest.ini`**, `tests/conftest.py`, **`test_async_client_real_fixtures`**, stress markers, **“52 test files”**, and **many concrete paths**: `tests/run_all_tests.py`, `tests/run_comprehensive_tests.py`, `test_comprehensive_server.py`, `test_server_runner.py`, `test_async_client_stress*.py`, `test_*_coverage.py`, `test_adapter_transport_coverage.py`, etc. **Substantial refresh** if legacy runners/stress/coverage tests are removed; sections claiming **no pytest-xdist in pyproject** are already **stale** vs current `[project.optional-dependencies]` (pyproject lists `pytest-xdist`, `pytest-timeout`). |
| **`examples/README.md`** | Generic “Test files in tests/” pointer — low risk; **no** named legacy modules. |
| **`pyproject.toml` (readme / long description)** | Packaged metadata describes features (CLI, vectorization); **dependencies** live in `[project]` — user-facing **README** should stay aligned; long `description` does not enumerate `PyJWT` by name in the visible excerpt — still verify after edits. |
| **`docs/agents/project_overlay.md`** | Says tests use **pytest** with **`pytest.ini`** — still true if `pytest.ini` remains; if config is consolidated into `pyproject.toml` only, update this line. References **`scripts/`** for non-pytest harnesses — still valid structurally after pruning. |
| **`docs/PROJECT_RULES.md`** | **LAYOUT-07** / **NAME-02**: generic `tests/` / `scripts/` rules — update only if project conventions change (e.g. fewer integration harnesses). |
| **`docs/rules_bundle_README.md`** | Checklist mentions creating `tests/`, `scripts/` — generic; **low** priority. |
| **`docs/ai_reports/baseline_audit_code_research.md`** | Contains **explicit** `PyJWT` / `cryptography` / `pydantic` lines, **`requirements.txt`** mention (file may not exist in repo), **script examples** (`run_embedding_test_server.py`, `run_https_test_server.py`), **stress/coverage test naming** — either **update as evidence refresh** or **supersede** so it does not contradict post-cleanup reality. |
| **`docs/ai_reports/baseline_audit_doc_research.md`** | Indexes **`docs/performance_test_results.md`**, **`docs/TEST_SUITE_HANG_ANALYSIS.md`**, and **many `docs/specs/tech_spec/.../update-maintained-real-server-scripts/`** step paths — **cross-links break** if legacy tech_spec tree or referenced docs are deleted/moved during normalization. |
| **`docs/specs/server_client_convergence_and_release/baseline_audit_and_contract_capture/migration_baseline_deliverable/spec.md`** | **Locked verdict** on `PyJWT`, `cryptography`, `pydantic` vs `embed_client/` — if dependencies change, either **amend tactical spec** or add a **follow-on decision** doc so evidence chain stays coherent. |
| **`docs/specs/server_client_convergence_and_release/baseline_audit_and_contract_capture/migration_baseline_deliverable/freeze-migration-baseline-evidence-links.md`** | Points readers to **`baseline_audit_*` reports** — same refresh need as those reports when dependency story changes. |
| **`docs/specs/tech_spec/branches/fix-test-hanging-issues/tasks/fix-critical-test-hangs.md`** | **Heavy** references to **`tests/test_async_client_real_fixtures.py`**, **`tests/run_all_tests.py`**, **`tests/run_comprehensive_tests.py`**, **`test_server_runner.py`**, optional-deps structure — **historical task doc**; archive or rewrite if those tests are removed. |
| **`docs/specs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/update-maintained-real-server-scripts.md`** | **Enumerates scripts** (`run_real_server_mtls_test.py`, `run_cuda_stress.py`, `compare_direct_vs_client.py`, …) — **must match** surviving `scripts/` after pruning. |
| **`docs/specs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/update-maintained-real-server-scripts/steps/*.md`** | Per-script atomic steps (e.g. **`update-run-cuda-stress.md`**, **`update-timeout-bidirectional-ws-performance.md`**, batch/real-server performance) — **obsolete** if corresponding scripts go away; normalization should **dedupe with** `docs/performance_test_results.md` or drop. |
| **`docs/specs/server_client_convergence_and_release/tests_scripts_and_dependency_cleanup/spec.md`** | Defines **branch intent** — not stale by cleanup; no file-level renames needed unless exit criteria wording is tightened. |
| **`docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md`** | **Meta:** this wave should consume the present list as input for **rewrite / deletion** decisions. |
| **`docs/specs/client_server_alignment_migration/.../legacy_cleanup_and_verification/spec.md`** | Strategic mention of **`tests/`** and **`scripts/`** — align with final layout after cleanup. |
| **`rules_template/**` (if shipped or copied)** | Template `PROJECT_RULES.md` / `project_overlay.md` mirror production docs — sync when canonical **`docs/`** copies change. |

---

## Consistency analysis (documentation vs upcoming changes)

- **Dependency narrative split:** `README.md` presents **`PyJWT` / `cryptography` / `pydantic`** as core runtime deps; baseline specs and **`baseline_audit_code_research.md`** already argue several are **not used by `embed_client/`** — after cleanup, public docs must **not** contradict the minimal dependency story.
- **`docs/TEST_SUITE_HANG_ANALYSIS.md` vs `pyproject.toml`:** Report states **no pytest-xdist** in dependencies; **`pyproject.toml`** now includes **`pytest-xdist`** and **`pytest-timeout`** under optional deps — **internal inconsistency** even before test deletion; normalization should fix or archive the hang report.
- **`requirements.txt`:** Referenced in **`baseline_audit_code_research.md`** as embed-server pin context; **file absent** at repo root in this snapshot — avoid implying a client **`requirements.txt`** unless it is reintroduced.

---

## Completeness assessment (gaps for later doc work)

- **Single “supported scripts” list** for post-cleanup repo (if any scripts remain) is missing as a **user-facing** artifact; today, script inventory is **spread** across `README.md`, `performance_test_results.md`, and **`tech_spec`** tasks.
- **Optional extras:** If `pydantic` moves to **`[project.optional-dependencies]`** for tooling/scripts, **README** / packaging docs should state **who** needs which extra.

---

## Code-documentation alignment (documentation claims vs current repo snapshot)

- **`README.md` dependency bullets** align with **`pyproject.toml` `[project.dependencies]`** today; **alignment will break** if those lines are removed from `pyproject.toml` without README updates.
- **`CLI_README.md`** manual script path should be checked against **`scripts/run_cli_manual.py`** existence after pruning.
- **`docs/TEST_SUITE_HANG_ANALYSIS.md`** file counts and file paths should be treated as **point-in-time**; verify against **`tests/`** after legacy removal.

---

## Structural issues

- **Duplication:** Performance numbers and script names appear in both **`docs/performance_test_results.md`** and **`tech_spec`** maintenance tasks — **`documentation_normalization`** should merge or clearly mark **one** canonical location.
- **Legacy tree:** Multiple references to **`docs/tech_spec/`** paths appear in older specs; **`docs/PROJECT_RULES.md`** / overlay already discuss **`docs/specs/tech_spec/`** — path cleanup is a **normalization** concern tied to this inventory.

---

## Key findings (actionable for `documentation_normalization`)

1. **`README.md`** is the **primary** file to update for **dependency list**, **example pytest commands**, **contract script**, and **test-count** claims.
2. **`docs/TEST_SUITE_HANG_ANALYSIS.md`** and **`docs/performance_test_results.md`** are **high-churn** and **file-specific** — expect **major edits or archival** after test/script cleanup.
3. **`docs/specs/tech_spec/...`** script and hang-fix tasks are **candidates for archival** if the underlying files disappear.
4. **`docs/ai_reports/baseline_audit_*.md`** should be **refreshed or explicitly frozen** with a pointer to a newer report so dependency/test claims do not **contradict** the cleaned tree.

---

## Recommendations

1. After **`tests_scripts_and_dependency_cleanup`**, produce a **short internal manifest**: surviving test modules (or “pytest discovers under `tests/` only”), surviving `scripts/`, and **final** runtime vs optional dependencies.
2. Apply **`documentation_normalization`** starting with **`README.md`**, **`CLI_README.md`**, then **`docs/TEST_SUITE_HANG_ANALYSIS.md`** / **`docs/performance_test_results.md`** (either update metrics or move historical content out of the canonical doc set).
3. For **`docs/specs/tech_spec/`**, either **migrate** still-valid procedures into `docs/specs/server_client_convergence_and_release/` or mark as **historical** to avoid broken script names.

---

## Summary table: files most likely to need edits

**High:** `README.md`, `docs/TEST_SUITE_HANG_ANALYSIS.md`, `docs/performance_test_results.md`, `CLI_README.md`, `docs/ai_reports/baseline_audit_code_research.md`.

**Medium:** `docs/specs/tech_spec/branches/fix-test-hanging-issues/tasks/fix-critical-test-hangs.md`, `docs/specs/tech_spec/branches/verification-matrix-and-runtime-validation/tasks/update-maintained-real-server-scripts.md` (+ steps), `docs/ai_reports/baseline_audit_doc_research.md`, `docs/specs/.../migration_baseline_deliverable/spec.md`.

**Low / structural:** `docs/agents/project_overlay.md`, `docs/PROJECT_RULES.md`, `examples/README.md`, `CONFIGURATION.md`.

---

*End of report.*
