<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# Documentation normalization — closure report

This report summarizes DN-AT-01 through DN-AT-21 execution for the `documentation_normalization` global step. Verification: full `pytest` run and linters/typecheck after changes (see section 6).

## Removed / pruned paths

| Path | Note |
|------|------|
| `docs/specs/tech_spec/` | Removed from disk (duplicate tree; root `tech_spec.md` and peers no longer present). |
| `docs/tech_spec/` | **Pruned**, not fully deleted: all legacy tactical-branch material was removed **except** the preserved active subtree **`docs/tech_spec/branches/documentation_normalization/`** (archived tactical-branch docs for this normalization effort). |
| `docs/performance_test_results.md` | Obsolete report |
| `docs/TEST_SUITE_HANG_ANALYSIS.md` | Stale analysis |
| `docs/specs/client_server_alignment_migration/` | Orphan subtree (empty dirs after nested `spec.md` removal per DN-AT-01) |

Authoritative durable specs and plans remain under **`docs/specs/<specname>/`** per **LAYOUT-09** / **CR-017**. Agent-facing notes: **`docs/agents/common_agent_rules.md`** and **`docs/agents/project_overlay.md`** describe the removal of `docs/specs/tech_spec/` and the pruning of `docs/tech_spec/` as above.

## Rewritten paths

| Area | Files |
|------|--------|
| Governance | `docs/PROJECT_RULES.md`, `docs/agents/project_overlay.md` |
| Root / PyPI surface | `README.md`, `CONFIGURATION.md`, `CLI_README.md`, `pyproject.toml` (`[project].description`) |
| Guides | `docs/client_integration_guide.md`, `docs/api_format.md`, `docs/SERVER_MODES_AND_CLIENT.md` |
| Examples index | `examples/README.md` |
| Example scripts | `examples/async_testing_client_example.py`, `examples/security_examples.py`, `examples/security_examples_ru.py`, `examples/canonical_mtls_localhost_8001.py` |
| Package examples | `embed_client/example_async_usage.py`, `embed_client/example_async_usage_demo.py`, `embed_client/example_async_usage_ru.py`, `embed_client/example_async_usage_ru_demo.py` |
| Tests | `tests/test_canonical_mtls_example.py` |

## Added paths

| Path | Note |
|------|------|
| `docs/ai_reports/documentation_normalization_closure_report.md` | This report |

## Canonical mTLS example (mandatory real-server reference)

- **Script:** **`examples/canonical_mtls_localhost_8001.py`** is the **canonical** runnable tour for **`localhost:8001`** + **`mTLS`** + repository **`mtls_certificates/`**. It is the mandatory reference for real-server validation in that configuration (dry run by default; live E2E with **`RUN_CANONICAL_MTLS_E2E=1`**).
- **`CANONICAL_EMBED_FILE_SERVER_PATH`:** optional environment variable. When set, it supplies a **server-visible** filesystem path for the **`embed_file`** capability so the tour can include that call; it is the **contract precondition** for exercising **`embed_file`** against a live server (the client only sends the path the server must read). When unset, the example/doc flow documents or skips **`embed_file`** as appropriate for the environment.
- **Tests:** **`tests/test_canonical_mtls_example.py`** — config paths, dry run, mocked live branch, **`embed_file`** skip/call coverage, optional integration.
- **Entry points:** **`README.md`** (canonical section), **`CONFIGURATION.md`** (recommended mTLS localhost:8001), **`examples/README.md`** (section 1).

## Blockers / residual risks

- **PyPI description** must stay aligned with `embedding_client.py` when the public API changes (`pyproject.toml` `[project].description`).
- **Real-server validation** for all eight deploy modes remains environment-dependent; documentation points to scripts and `docs/SERVER_MODES_AND_CLIENT.md` rather than guaranteeing CI coverage of every mode.
- **Residual legacy path mentions (non-blocking):** `researcher_code` reported acceptable **PASS** with only non-blocking residual references in **`examples/async_testing_client_example.py`** and **`docs/api_format.md`** (historical path strings or comments); authoritative spec locations are under **`docs/specs/<specname>/`**.

## Subordinate agents state table

| Agent | Action | Verdict | Notes |
|-------|--------|---------|--------|
| researcher_code | Symbol/link-oriented audit | **PASS** | Non-blocking residual legacy mentions in `examples/async_testing_client_example.py`, `docs/api_format.md` |
| researcher_doc | Stale/broken doc links (`docs/specs/tech_spec/`, removed `docs/tech_spec/branches/tests_scripts_and_dependency_cleanup/`, agent legacy-path lists) | **PASS** | Blockers addressed in the documentation pass that updated this closure report and linked specs |
| tester_auto | Full test + lint/typecheck gate | **PASS** | See verification evidence below |
| doc_writer | Authored/updated this report and linked docs | **Done** | English, `ARTIFACT_LOCALE` |

## Verification evidence (this session)

| Check | Result |
|-------|--------|
| `pytest -q` | **165 passed**, **67 skipped** |
| `pytest -q tests/test_canonical_mtls_example.py` | **5 passed**, **1 skipped** |
| `flake8` | **PASS** |
| `black --check` | **PASS** |
| `mypy embed_client` | **PASS** (**37 files**) |

The preserved active tactical subtree **`docs/tech_spec/branches/documentation_normalization/`** remains on disk and is the only survivor under **`docs/tech_spec/`**; this report’s “pruned paths” section matches that layout. **`docs/specs/tech_spec/`** is **removed** and must not be referenced as a current location.
