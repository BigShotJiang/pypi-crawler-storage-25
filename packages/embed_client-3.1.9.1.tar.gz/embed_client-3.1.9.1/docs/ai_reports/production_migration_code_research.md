# Production migration (no backward compatibility): code research report

**Scope:** Factual comparison of standalone package `embed-client` (`/home/vasilyvz/projects/embed-client`) with server canonical client under `embed` (`/home/vasilyvz/projects/embed`). **Server wins** on contract semantics where noted.

---

## 1. Canonical migratable units (server baseline)

Absolute paths under `/home/vasilyvz/projects/embed`:

| Path | Exists | Lines | Key public symbols |
|------|--------|-------|---------------------|
| `embed/client/embedding_client.py` | Yes | 967 | **`EmbeddingClient`** (holds **`JsonRpcClient`** as **`self.client`** in `__init__`), helpers used at module level: `_client_has_async_method`, `_uses_adapter_job_message_registry`, `_normalize_terminal_job_payload`; **public instance API (non-private):** `get_embed_file_status_snapshot`, `aget_embed_file_status_snapshot`, `list_embed_file_status_messages`, `alist_embed_file_status_messages`, `clear_embed_file_status`, `list_embed_file_status_job_ids`, `health`, `embed`, **`wait_for_job`**, `open_bidirectional_ws_channel`, **`job_status`**, `embed_file`, `jsonrpc`, `models`, `list_commands`, `close`, `fetch_openapi_schema`, `http_get`, `__repr__`. Private: `_embed_via_execute_async`, `_wait_for_job_via_adapter_ws`. |
| `embed/client/embedding_client_helpers.py` | Yes | 68 | **`wait_for_job_poll`**, **`list_commands_via_client`** |
| `embed/client/embed_file_status_store.py` | Yes | 77 | **`EmbedFileJobStatusStore`** (`record_submit`, `record_message`, `snapshot`, `messages`, `clear`, `job_ids`) |
| `embed/constants.py` | Yes | 49 | **`EMBED_COMMAND_SCHEMA_DEFAULT_ERROR_POLICY`**, service-manager constants (`EMBED_SERVICE_MANAGER_*`), **`get_embed_project_root`** |
| `embed/exceptions.py` | Yes | 48 | **`EmbedError`**, **`EmbedConfigError`**, **`EmbedQueueError`**, **`EmbedClientError`**, **`EmbedServiceError`**, **`ModelServerUnavailableError`**, **`EmbedGpuOutOfMemoryError`** |

**Related server file (not in baseline list but relevant to §6):**  
`/home/vasilyvz/projects/embed/embed/client/service_manager_health.py` — `embedding_client_params_for_service_manager`, **`health_via_embedding_client`**; imports **`httpx`** (used for `httpx.HTTPStatusError` in error handling).

---

## 2. Current `embed_client` package vs server `EmbeddingClient` pattern

### 2.1 `__init__.py` exports (`/home/vasilyvz/projects/embed-client/embed_client/__init__.py`)

Exported names: **`EmbeddingServiceAsyncClient`**, **`ClientConfig`**, **`ClientAuthManager`**, **`ClientSSLManager`**, **`ClientFactory`**, **`ClientConfigGenerator`**, **`ConfigValidator`**, **`AsyncClientConfigMixin`**, **`EmbeddingServiceClient`**, **`TestingEmbeddingClient`** (alias), **`wait_for_job_poll`**, **`list_commands_via_client`**, **`__version__`**.

Docstring states: all API traffic via **`AdapterTransport`** → **`JsonRpcClient`** (no parallel HTTP stack for API).

### 2.2 Main modules (46 Python files under `embed_client/`)

Representative layout:

| Area | Paths |
|------|--------|
| Primary async API | `async_client.py` (**`EmbeddingServiceAsyncClient`** — mixins), `async_client_*_mixin.py` (api, queue, config, factory, lifecycle, response, introspection) |
| Transport | `adapter_transport.py` (**`AdapterTransport`**), `adapter_config_factory.py`, `adapter_config_normalizer.py`, `adapter_generator_bridge.py` |
| Second client surface | `testing_client.py` (**`EmbeddingServiceClient`**), `testing_client_helpers.py` |
| Config / CLI | `config.py`, `config_*.py`, `cli.py`, `cli_core.py`, `client_factory.py`, etc. |
| Shared | `constants.py`, `exceptions.py`, `identifier_types.py`, `response_normalizer.py`, `response_parsers.py` |

### 2.3 Server pattern (baseline)

`/home/vasilyvz/projects/embed/embed/client/embedding_client.py`: **`EmbeddingClient`** constructs **`JsonRpcClient`** directly (`self.client = JsonRpcClient(...)`); no **`AdapterTransport`** indirection in the canonical tree.

### 2.4 REPLACE vs DELETE (convergence target: server `EmbeddingClient` + helpers + store + `embed.constants` / `embed.exceptions`)

| Action | What |
|--------|------|
| **REPLACE** | The **`EmbeddingServiceAsyncClient`** stack (`async_client.py` + `async_client_*_mixin.py` modules) and transport abstraction that duplicates server behavior, with a port/adaptation of **`EmbeddingClient`** (direct **`JsonRpcClient`**) plus aligned **`embedding_client_helpers`**, **`embed_file_status_store`**, constants/exceptions naming per server (or thin re-exports). |
| **REPLACE / realign** | **`adapter_transport.AdapterTransport.queue_get_job_status`** implementation to match server **`EmbeddingClient.job_status`** precedence (see §3). |
| **REPLACE** | **`AsyncClientQueueMixin.wait_for_job`** to match server: **WebSocket-first** when **`JsonRpcClient.wait_for_job`** exists (see §3). |
| **DELETE (no backward compat)** | Redundant second full client **`EmbeddingServiceClient`** in **`testing_client.py`** and duplicate helpers surface if superseded by server-aligned module(s); deprecated alias **`TestingEmbeddingClient`**; overlapping mixin layers once a single **`EmbeddingClient`**-shaped API is the only public client. Exact deletion set is a follow-up cut once imports are rewired. |
| **Evaluate** | **`ClientFactory`** / **`AdapterConfigFactory`** — server client uses kwargs to **`EmbeddingClient`**; factory may shrink to config→constructor mapping only. |

---

## 3. Contract fixes (server wins)

### 3.1 `queue_get_job_status` vs `embed_job_status` precedence

- **Server** (`/home/vasilyvz/projects/embed/embed/client/embedding_client.py`, **`job_status`**): tries **`queue_get_job_status`** first via **`jsonrpc_call`**, then falls back to **`embed_job_status`** on failure/unavailability (see docstring and implementation around the `queue_get_job_status` call).

- **embed-client** (`/home/vasilyvz/projects/embed-client/embed_client/adapter_transport.py`, **`queue_get_job_status`**): **tries `embed_job_status` first** (lines ~326–360 area), then falls back to **`queue_get_job_status`**. Comments claim avoiding `MethodNotFoundError` for non-embed jobs — **this order inverts the server contract**.

**Required fix:** align **`AdapterTransport.queue_get_job_status`** (and any callers) with server: **`queue_get_job_status` first**, then **`embed_job_status`** as fallback.

### 3.2 `wait_for_job`: WS-first when `JsonRpcClient.wait_for_job` exists

- **Server** (`embedding_client.py`, **`wait_for_job`**): if **`_client_has_async_method(self.client, "wait_for_job")`**, delegates to **`await self.client.wait_for_job(...)`** and normalizes payload; else uses **`wait_for_job_poll(self.job_status, ...)`**.

- **embed-client** (`/home/vasilyvz/projects/embed-client/embed_client/async_client_queue_mixin.py`, **`wait_for_job`**): documents **HTTP polling only** via **`job_status`**; does **not** branch on **`JsonRpcClient.wait_for_job`**.

**Required fix:** implement the same guard as server: **prefer adapter `wait_for_job`** when present; otherwise poll (via **`job_status`** / helpers).

---

## 4. Duplicate / legacy surfaces to remove

| Surface | Path | Note |
|---------|------|------|
| **`EmbeddingServiceAsyncClient`** | `/home/vasilyvz/projects/embed-client/embed_client/async_client.py` | Large mixin-based async client; overlaps server **`EmbeddingClient`** role for production migration. |
| **`EmbeddingServiceClient`** | `/home/vasilyvz/projects/embed-client/embed_client/testing_client.py` | Parallel “thin” adapter client; name collides semantically with “service client”; overlaps **`EmbeddingServiceAsyncClient`** + server **`EmbeddingClient`**. |
| **`TestingEmbeddingClient`** | `/home/vasilyvz/projects/embed-client/embed_client/__init__.py` | Alias of **`EmbeddingServiceClient`**; remove with rename strategy. |
| **Duplicate helpers** | `/home/vasilyvz/projects/embed-client/embed_client/testing_client_helpers.py` | **`wait_for_job_poll`**, **`list_commands_via_client`** — same responsibilities as server **`embedding_client_helpers.py`**. |
| **Overlapping transport + queue docs** | `adapter_transport.py` vs server direct **`JsonRpcClient`** | Two ways to reach the same RPCs until convergence. |

Tests and scripts referencing **`EmbeddingServiceAsyncClient`** / **`EmbeddingServiceClient`** are widespread under `/home/vasilyvz/projects/embed-client/tests/`, `/home/vasilyvz/projects/embed-client/scripts/`, `/home/vasilyvz/projects/embed-client/examples/` — migration will require bulk import and API updates (expected under “no backward compatibility”).

---

## 5. Version mismatch

| Source | Value |
|--------|--------|
| `/home/vasilyvz/projects/embed-client/pyproject.toml` → `[project] version` | **`3.1.7.28`** |
| `/home/vasilyvz/projects/embed-client/embed_client/__init__.py` → **`__version__`** | **`3.1.7.25`** |

These are inconsistent; release/build should use a single source of truth.

---

## 6. Porting blockers and notes

### 6.1 Namespace: `embed` vs `embed_client`

Server modules use imports such as **`from embed.client.embed_file_status_store import ...`**, **`from embed.constants import ...`**, **`from embed.exceptions import ...`**.  
Standalone package uses **`embed_client.*`**. Porting files verbatim requires **import rewrites** (or a compatibility shim layer — excluded if truly no backward compatibility and single package name is chosen).

### 6.2 `httpx` in `service_manager_health` (server)

File: **`/home/vasilyvz/projects/embed/embed/client/service_manager_health.py`**.  
Uses **`import httpx`** and catches **`httpx.HTTPStatusError`**. **`embed-client`** `pyproject.toml` does **not** list **`httpx`** as a dependency; canonical client path uses **`JsonRpcClient`** internally (which may use httpx inside **`mcp-proxy-adapter`**). If this module is ported into **`embed-client`**, either:

- add an explicit **`httpx`** dependency for exception typing, or  
- map errors to **`embed_client`** exception types without importing **`httpx`** at module level (depends on adapter behavior).

### 6.3 Constants / exceptions naming drift

- Server: **`EMBED_COMMAND_SCHEMA_DEFAULT_ERROR_POLICY`**, **`EmbedClientError`**.  
- embed-client: **`EMBED_DEFAULT_ERROR_POLICY`**, **`EmbeddingServiceError`** / **`EmbeddingServiceAPIError`**, etc.

Unification under server names (or documented aliases only during transition) avoids silent semantic drift.

---

## 7. References (absolute paths)

- Server canonical: `/home/vasilyvz/projects/embed/embed/client/embedding_client.py`  
- Server helpers: `/home/vasilyvz/projects/embed/embed/client/embedding_client_helpers.py`  
- Server store: `/home/vasilyvz/projects/embed/embed/client/embed_file_status_store.py`  
- Server constants: `/home/vasilyvz/projects/embed/embed/constants.py`  
- Server exceptions: `/home/vasilyvz/projects/embed/embed/exceptions.py`  
- Service manager health (httpx): `/home/vasilyvz/projects/embed/embed/client/service_manager_health.py`  
- embed-client package root: `/home/vasilyvz/projects/embed-client/embed_client/`  
- Version: `/home/vasilyvz/projects/embed-client/pyproject.toml`, `/home/vasilyvz/projects/embed-client/embed_client/__init__.py`

---

*Generated as factual code research for production migration branch; no runtime tests executed.*
