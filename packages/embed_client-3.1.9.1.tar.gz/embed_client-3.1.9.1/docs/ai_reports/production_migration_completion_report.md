# Production migration — completion report

**Epic:** `server_client_convergence_and_release`  
**Global step:** `production_migration_and_legacy_removal`  
**Date:** 2026-03-29

## Subordinate agents state (branch closure)

| Agent | Status | Notes |
|--------|--------|--------|
| `researcher_code` | Done | Baseline + gap analysis vs atomics; import/symbol mismatches flagged |
| `coder_auto` | Done | Constants/exceptions alignment, restored config bridges, tests/scripts/examples updates |
| `tester_auto` | Done | `pytest`: 160 passed, 68 skipped, 0 failed; `import embed_client` OK |
| `planner_auto` | N/A (pre-materialized) | Atomics `atomic-01`…`atomic-07` already under `canonical_client_migration/` |
| `researcher_doc` | Not invoked | Doc normalization is Wave 3 |
| `doc_writer` | Not invoked | Same |

## Canonical production code ported or reshaped

| Area | Location / notes |
|------|------------------|
| Core client | `embed_client/embedding_client.py` — `EmbeddingClient` with direct `JsonRpcClient`; `job_status` uses `queue_get_job_status` then `embed_job_status`; `wait_for_job` WS-first when adapter supports it; `embed_file` and status store hooks |
| Helpers | `embed_client/embedding_client_helpers.py` — `wait_for_job_poll`, `list_commands_via_client` |
| File job store | `embed_client/embed_file_status_store.py` — `EmbedFileJobStatusStore` |
| Constants | `embed_client/constants.py` — server-aligned (`EMBED_COMMAND_SCHEMA_DEFAULT_ERROR_POLICY`, `get_embed_project_root`, env/DEFAULT_* ) |
| Exceptions | `embed_client/exceptions.py` — server-aligned hierarchy plus `EmbedHTTPError` / `EmbedAPIError` / `EmbedTimeoutError` / `EmbedJSONError` for former HTTP/API/timeout/JSON surfaces |
| Public exports | `embed_client/__init__.py` — `EmbeddingClient`, helpers, config/SSL/factory/validator; `__version__` matches `pyproject.toml` (`3.1.7.28`) |
| Config tooling | `embed_client/adapter_config_factory.py` retained; **`adapter_config_normalizer.py`** and **`adapter_generator_bridge.py`** restored (required by `ConfigValidator` / `ClientConfigGenerator`; not the removed `AdapterTransport` stack) |

**Explicitly not ported (per baseline):** `embed/client/service_manager_health.py` (httpx deployment glue).

## Legacy production code removed (representative)

- `EmbeddingServiceAsyncClient` stack: `async_client.py`, `async_client_*_mixin.py` modules  
- `adapter_transport.py` (transport abstraction replaced by direct `JsonRpcClient` in `EmbeddingClient`)  
- `testing_client.py`, `testing_client_helpers.py`  
- `adapter_config_normalizer.py` / `adapter_generator_bridge.py` were **temporarily** removed during migration; **restored** as non-legacy config support (see above)

**Tests removed or replaced** (obsolete surfaces): e.g. modules tied to old async client, adapter transport-only coverage, mixin-heavy coverage files — see git history / `coder_auto` report for exact list.

## Downstream facts (tests / docs / release)

1. **Primary class:** `embed_client.EmbeddingClient` (`from embed_client import EmbeddingClient`).  
2. **Public `__all__`:** `EmbeddingClient`, `wait_for_job_poll`, `list_commands_via_client`, `ClientConfig`, `ClientAuthManager`, `ClientSSLManager`, `ClientFactory`, `ClientConfigGenerator`, `ConfigValidator`.  
3. **Exceptions:** use `embed_client.exceptions` — `EmbedClientError`, `EmbedHTTPError` (`.status`, `.message`), `EmbedAPIError`, etc.; old `EmbeddingService*` names are gone.  
4. **Constants:** default embed error policy is `EMBED_COMMAND_SCHEMA_DEFAULT_ERROR_POLICY` in `embed_client.constants`.  
5. **Contract precedence (locked):** job status RPC order and WS-first `wait_for_job` are implemented in `EmbeddingClient` (see `embedding_client.py`).  
6. **Dependency cleanup wave:** `pyproject.toml` may still list runtime deps unused by pure `EmbeddingClient` (e.g. PyJWT, cryptography) — baseline flagged for `tests_scripts_and_dependency_cleanup`.  
7. **Documentation wave:** long-form README/CONFIG rewrites remain **out of scope** for this step; handoff lists in `docs/ai_reports/production_migration_doc_research.md` still apply for rewrites.  
8. **Examples:** surviving examples under `embed_client/example_*.py` and `examples/` were updated to `EmbeddingClient` and new exceptions; **man-page docstrings + execution validation** remain obligations for `documentation_normalization` / release branches.  
9. **Security matrix:** repository rules still require full deployment-mode checks before publish — not replaced by unit tests alone.

## Blockers

**None** for declaring this global step’s **production migration and legacy removal** objectives met at the **current repo + test gate**.

Residual: httpx `DeprecationWarning` in `tests/test_all_security_modes.py` (cert kwarg) — cosmetic; optional follow-up in cleanup branch.

## Tactical artifact pointer

- `docs/tech_spec/branches/production_migration_and_legacy_removal/README.md` → canonical tactical path under `docs/specs/.../canonical_client_migration/`.
