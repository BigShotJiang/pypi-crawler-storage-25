# Code research: tests, scripts, dependency cleanup

**Epic:** `server_client_convergence_and_release`  
**Global step:** `tests_scripts_and_dependency_cleanup`  
**Scope:** `/home/vasilyvz/projects/embed-client`  
**Date:** 2026-03-29  
**Role:** researcher_code (read-only analysis)

---

## 1. `pyproject.toml`: dependencies, version, scripts

### 1.1 Runtime `dependencies` (lines 60–65)

| Package | Constraint |
|---------|------------|
| PyJWT | `>=2.0.0` |
| cryptography | `>=3.0.0` |
| pydantic | `>=2.0.0` |
| mcp-proxy-adapter | `>=6.10.0` |

**Note:** Baseline locks **mcp-proxy-adapter>=6.10.0** — already satisfied.

### 1.2 Optional dependencies

- **`[project.optional-dependencies].test`** (lines 67–73): `pytest`, `pytest-asyncio`, `pytest-xdist`, `pytest-timeout`
- **`dev`** (lines 74–82): same as test plus `black`, `flake8`, `mypy`

No dedicated extras for scripts/test servers that use **pydantic** (see §4).

### 1.3 Version field

- **`[project].version`** (line 7): `"3.1.7.28"`

### 1.4 Console scripts (`[project.scripts]`, lines 91–94)

| Entry point | Target |
|-------------|--------|
| `embed-config-generator` | `embed_client.config_generator_cli:main` |
| `embed-config-validator` | `embed_client.config_validator_cli:main` |
| `embed-vectorize` | `embed_client.cli:cli_main` |

### 1.5 Mismatch: `__version__` vs `pyproject.toml`

| Location | Value |
|----------|--------|
| `pyproject.toml` line 7 | `3.1.7.28` |
| `embed_client/__init__.py` line 34 | `3.1.7.25` |

**Drift:** patch segment differs (`28` vs `25`). Single source of truth should be enforced (e.g. dynamic version from `importlib.metadata` or CI check).

### 1.6 Pytest tool config

- `[tool.pytest.ini_options]` (lines 101–102): only `asyncio_default_fixture_loop_scope = "function"`.
- Root **`pytest.ini`** duplicates/overrides collection behavior (see §5).

---

## 2. `embed_client/`: third-party imports

### 2.1 Direct imports

Grep for `^import jwt`, `^from jwt`, `^import pydantic`, `^from pydantic`, `^import cryptography`, `^from cryptography` under `embed_client/**/*.py`: **no matches**.

### 2.2 Effective usage vs declared dependencies

- **PyJWT / cryptography:** Not imported in `embed_client/`. Docstrings and config keys refer to “JWT” as an auth **mode**, not the PyJWT library. **`ClientAuthManager`** (`embed_client/auth.py`) only validates config and builds headers; it does not mint or verify JWTs.
- **pydantic:** No usage in `embed_client/`.
- **mcp-proxy-adapter:** Used (e.g. `embed_client/adapter_transport.py` imports `mcp_proxy_adapter.client.jsonrpc_client`).

### 2.3 Packaged demos/examples inside `embed_client/` (stale API risk)

**`embed_client/auth_examples.py`** — calls methods that **do not exist** on current `ClientAuthManager`:

| Lines | Symbols used | Evidence in `embed_client/auth.py` |
|-------|----------------|-------------------------------------|
| 101 | `authenticate_api_key` | Not defined on `ClientAuthManager` |
| 123–127 | `create_jwt_token`, `authenticate_jwt` | Not defined (removed per adapter-centric design; `tests/test_auth_manager.py` asserts absence, lines 178–187) |
| 148 | `authenticate_basic` | Not defined |
| 167–169 | `authenticate_certificate` | Not defined |

Running `python -m embed_client.auth_examples` would **fail** at runtime. This is a **broken import/API** relative to current `auth.py`, not merely “legacy.”

---

## 3. `tests/`: inventory, categories, stale flags

### 3.1 File list (40 Python files under `tests/`)

Includes: `conftest.py`, `test_adapter_*.py`, `test_async_client*.py`, `test_auth*.py`, `test_client_factory*.py`, `test_config.py`, `test_coverage_*.py`, `test_embed_*.py`, `test_example_async_usage*.py`, `test_final_*.py`, `test_identifier_*.py`, `test_queue_methods.py`, `test_remaining_coverage.py`, `test_security_matrix.py`, `test_ssl_manager.py`, `test_websocket_completion.py`, `test_with_auth.py`, etc.

### 3.2 Category map

| Category | Files | Notes |
|----------|--------|------|
| **Adapter / integration (current)** | `test_adapter_transport.py`, `test_adapter_integration.py`, `test_adapter_phase1.py`, `test_adapter_phase2.py`, `test_websocket_completion.py`, `test_identifier_extraction.py`, `test_identifier_separation.py`, `test_queue_methods.py`, parts of `test_async_client.py` | Target architecture |
| **Real server / fixtures** | `test_async_client_real.py`, `test_async_client_real_fixtures.py`, `test_all_security_modes.py` | Integration; need running service |
| **Security matrix (opt-in)** | `test_security_matrix.py` | Skipped unless `RUN_SECURITY_MATRIX=1` (lines 31–35) |
| **Legacy aiohttp transport** | `test_async_client.py` (bulk) | Mocks `client._session`; **skipped** by `conftest.py` except `TestEmbeddingServiceAsyncClientAdapter` |
| **Stress** | `test_async_client_stress.py`, `test_async_client_stress_new.py`, `test_async_client_stress_updated.py`, one test in `test_all_security_modes.py` | `@pytest.mark.stress`; default **skipped** without `--use-stress` (`conftest.py` 20–27) |
| **Coverage / 90%+ suites** | `test_coverage_90_plus.py`, `test_all_modules_coverage.py`, `test_final_90_plus_coverage.py`, `test_final_coverage.py`, `test_remaining_coverage.py`, `test_embed_overrides_coverage.py`, `test_adapter_transport_coverage.py`, `test_api_mixin_90_plus.py` | Large overlap; maintenance cost |
| **Async completeness / API shape** | `test_async_completeness.py` | Inspects async methods on client/mixins |
| **Entirely skipped modules** | `test_auth_helpers.py` (lines 22–27), `test_ssl_manager.py` (lines 28–30), `test_example_async_usage_ru.py` (module-level skip) | See below |
| **Aggregator with misleading skip** | `test_auth.py` | Module-level `pytestmark` skip (lines 20–25); file only re-exports classes — **does not disable** `test_auth_manager.py` tests |

### 3.3 `conftest.py` behavior (high impact)

- **`--use-stress`:** Stress-marked tests skipped unless flag set (lines 11–27).
- **Legacy skip for `test_async_client.py`:** All tests in that file are skipped **unless** they belong to class `TestEmbeddingServiceAsyncClientAdapter` (lines 29–43). Result: **~1500+ lines** of aiohttp mocks are dead weight in default CI.

### 3.4 `test_async_client.py` — evidence of legacy assumptions

- Lines 20–36: Comment states legacy aiohttp transport; current client has **`_adapter_transport`**, not `_session`.
- Example: `test_health` (lines 93–104) patches `client._session` — incompatible with current `EmbeddingServiceAsyncClient`.
- **Non-skipped** portion: `TestEmbeddingServiceAsyncClientAdapter` (from line ~1530): asserts `_adapter_transport`, no `_session`, adapter params — **aligned with current code**.

**Recommendation shape:** **delete or relocate** legacy body to archive; keep a **small** `test_async_client_adapter.py` with only adapter tests; drop **top-level `import aiohttp`** from the default test path.

### 3.5 Skipped / redundant tests — coder_auto targets

| Action | File | Evidence |
|--------|------|----------|
| **Delete or rewrite** | `tests/test_auth_helpers.py` | Entire module skipped; duplicates concepts covered by `test_auth_manager.py` + adapter |
| **Delete or slim** | `tests/test_auth.py` | Only imports + skip; no unique tests; confusing |
| **Delete or replace with narrow unit tests** | `tests/test_ssl_manager.py` | Entire module skipped; `ClientSSLManager` is validation-only — short tests could live in a single file |
| **Keep but optional** | `tests/test_example_async_usage_ru.py` | Skipped smoke; decide if examples are tested elsewhere |
| **Major trim** | `tests/test_async_client.py` | See §3.4 |
| **Consolidate** | `test_*coverage*.py`, `test_*90_plus*.py` | Multiple files chase same coverage goal — dedupe after measuring real coverage |

### 3.6 Hidden dependency: **aiohttp**

- `pyproject.toml` does **not** list `aiohttp`.
- `tests/test_async_client.py` line 14: `import aiohttp` at module level.
- Any environment that collects this module **must** have aiohttp installed even though almost all tests are skipped. **Declare as dev/extra** or remove legacy module to avoid fragile environments.

### 3.7 Positive signals (no change required for “fake auth” removal)

- `tests/test_auth_manager.py` `test_fake_auth_methods_removed` (lines 178–187): asserts `authenticate_jwt`, `create_jwt_token`, etc. **absent** — matches current `auth.py`.

---

## 4. `scripts/` and `examples/`, `test_environment/`

### 4.1 **pydantic** usage

| File | Usage |
|------|--------|
| `scripts/run_embedding_test_server.py` | Line 20: `from pydantic import BaseModel` |
| `scripts/run_https_test_server.py` | Line 21: `from pydantic import BaseModel` |
| `test_environment/examples/full_application/proxy_endpoints.py` | Line 8: `from pydantic import BaseModel` |

If **pydantic** is dropped from core `[project].dependencies`, these paths need **`[project.optional-dependencies]`** (e.g. `scripts` or `dev-servers`) or vendored minimal models.

### 4.2 Hard-coded venv paths (fragile)

Several scripts inject:

`.venv/lib/python3.12/site-packages`

Examples: `scripts/run_all_tests.py` (lines 17–21), `scripts/run_client_examples_manual.py` (lines 17–21).

**Risk:** Breaks on other Python versions/machines; cleanup should normalize to `sys.executable` / project venv discovery.

### 4.3 `examples/` (project root)

- `examples/async_testing_client_example.py` — uses `EmbeddingServiceAsyncClient`, `EmbeddingServiceClient`, adapter-oriented APIs; **no pydantic** in the first 80 lines; appears **current**.

### 4.4 Broken in-package demo

- **`embed_client/auth_examples.py`** — see §2.3; not under `scripts/` but shipped with package and **broken**.

---

## 5. Root / tooling: pytest, CI, tox

| Item | Location | Content |
|------|----------|---------|
| **pytest.ini** | repo root | `testpaths = tests`, markers `integration` / `stress`, `asyncio_default_fixture_loop_scope = function`, **`timeout = 300`**, **`addopts = -n auto`** (pytest-xdist) |
| **pyproject** | `[tool.pytest.ini_options]` | Only asyncio loop scope — **partial overlap** with `pytest.ini` |
| **tox** | — | **Not found** |
| **GitHub Actions / GitLab CI** | — | **No workflow files found** in workspace (may live only on remote) |

**Implications:**

- `-n auto` requires `pytest-xdist` (listed in optional deps, not core).
- Timeout plugin: `pytest-timeout` in optional deps — aligns with `timeout = 300` in `pytest.ini`.
- Two config sources (`pytest.ini` vs `pyproject`) — consider **single** pytest config during cleanup to avoid drift.

---

## 6. Prioritized recommendations for `coder_auto`

1. **Unify version:** Set `embed_client/__init__.py` `__version__` to match `pyproject.toml`, or read version from package metadata at runtime; add a check in CI or a small test.
2. **Trim runtime dependencies:** Remove **PyJWT**, **cryptography**, **pydantic** from `[project].dependencies` if no remaining code path needs them; add **pydantic** to an extra used by `scripts/run_*_test_server.py` and document install for dev servers.
3. **Fix or remove `embed_client/auth_examples.py`:** Either rewrite demos to **header validation + `validate_auth_config` only**, or delete / move to docs-only snippets.
4. **Reduce `tests/test_async_client.py`:** Extract `TestEmbeddingServiceAsyncClientAdapter` to a dedicated small module; **delete** skipped aiohttp tests **or** gate the file behind an optional extra `aiohttp` + explicit marker; remove unconditional `import aiohttp` from default test collection.
5. **Purge or merge skipped suites:** `test_auth_helpers.py`, empty/skip-only `test_auth.py`, skipped `test_ssl_manager.py` — replace with **short** active tests or delete.
6. **Consolidate coverage tests:** After one coverage pass, merge `test_*90_plus*.py` / `test_remaining_coverage.py` / `test_final_coverage.py` where redundant.
7. **Stress tests:** Keep behind `--use-stress`; document in README/spec; ensure stress files don’t assume removed APIs (they use `client.cmd("embed", ...)` — verify against adapter).
8. **Scripts:** Replace hard-coded `.venv/lib/python3.12/...` with portable path logic; group script-only deps under extras.
9. **pytest config:** Consolidate `pytest.ini` and `[tool.pytest.ini_options]` into one source.

---

## 7. References (quick)

- Version drift: `pyproject.toml:7`, `embed_client/__init__.py:34`
- No pydantic/jwt/crypto imports in `embed_client/`: grep result (§2.1)
- Broken demos: `embed_client/auth_examples.py` (calls listed in §2.3)
- Legacy test skip: `tests/conftest.py:29-43`, `tests/test_async_client.py:20-36`, `1530-1638`
- Pydantic in scripts: `scripts/run_embedding_test_server.py:20`, `scripts/run_https_test_server.py:21`

---

*End of report.*
