# Embedding Service API — request and response shapes (client view)

**Author:** Vasiliy Zdanovskiy  
**Email:** vasilyvz@gmail.com

This document describes JSON-RPC usage as seen by **`EmbeddingClient`** (`cmd`, `jsonrpc`, `embed`). The wire transport is JSON-RPC 2.0 over **`POST /api/jsonrpc`** (or the MCP Proxy equivalent with the same method names).

## JSON-RPC `embed` (batch)

**Method:** `embed`  
**Params (typical):**

- `texts` (array of strings, required)
- `model`, `dimension`, `device` (optional)
- `error_policy`: `"continue"` | `"fail_fast"` — use **`"continue"`** for per-item errors without failing the whole batch

**Success (`error_policy = "continue"`):** top-level `result.success` is true; `result.data` contains **`results`** (and often **`embeddings`**) aligned by index with **`texts`**. Each **`results[i]`** may include **`body`**, **`embedding`**, **`tokens`**, **`bm25_tokens`**, **`error`** (null on success).

**Per-item error:** `results[i].embedding` may be null and **`results[i].error`** an object with **`code`** and **`message`**.

**Top-level JSON-RPC error:** no `result.data`; used for structural invalid requests or **`fail_fast`** validation failures.

## What `EmbeddingClient.embed` returns

After normalization, callers typically receive a **dict** with keys such as **`results`**, **`model`**, **`dimension`**, **`device`**, and optionally **`embeddings`**, matching the server’s sync completion shape. In queue mode the client may poll or use WebSocket completion before returning the same high-level shape.

Use **`response_parsers`** helpers when consuming raw **`cmd`** responses.

## JSON-RPC `embed_file`

**Method:** `embed_file`  
**Params (high level):** `input_file` (path on the **embedding server** host), `format` (`lines` | `json_array`), optional `model`, `dimension`, `device`, `error_policy`.

The wire shape matches the server command: **`input_file`** is always the server-visible path. For a client-staged file, call **`upload_file`**, then **`get_upload_session(transfer_id)`** and use the returned **`storage_path`** as **`input_file`** (same pattern as the reference integration tests).

For **`format=json_array`**, the input file must be a JSON **array of strings** (UTF-8 text per element), matching the server’s embed service semantics. Client-side Markdown/plain preparation (**`prepare-embed-file-json`**) builds those strings by splitting the body **only** on **`\n\n`** into paragraph blocks, with per-string UTF-8 limits and no semantic chunking — see **`CLI_README.md`** and the package **`README.md`**.

**CLI (local file without server filesystem access):** **`embed-vectorize embed-file-json`** or **`python -m embed_client embed-file-json`** validates a **local** UTF-8 JSON file client-side, uploads via the adapter, resolves **`storage_path`**, then calls **`embed_file`** with **`format=json_array`** — see **`CLI_README.md`**. Programmatic equivalent: **`EmbeddingClient.embed_file_from_local_json_file`**.

## Other methods

- **`models`**, **`help`**, service-specific commands — JSON-RPC `result` as returned by the server.
- **`upload_file`** / **`transfer_ack`** — adapter file staging and completion; used with **`embed_file`** inbound/outbound transfers.
- **`job_status`** / queue — dict payloads from **`embed_job_status`** or queue APIs depending on server capabilities.

## Deprecated narratives

Older `POST /cmd` or adapter-transport-only documentation paths are **not** used by **`EmbeddingClient`**; all calls go through **`JsonRpcClient`** JSON-RPC.
