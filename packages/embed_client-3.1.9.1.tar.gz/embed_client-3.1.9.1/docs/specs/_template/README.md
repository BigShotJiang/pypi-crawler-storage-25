<!--
Template: copy this tree when starting a new file-backed spec (ТЗ) and plan.
-->

# Spec tree template (`docs/specs/_template/`)

**Rule:** Durable ТЗ and implementation plans live **only** under the **per-spec root** **`docs/specs/<specname>/`** (**CR-017**, **LAYOUT-09**). Do not place the tree directly in `docs/specs/` without a `<specname>` directory. Chat is not the system of record.

## How to bootstrap

1. Copy the folder: `docs/specs/_template/` → `docs/specs/<your_specname>/`.
2. Rename `example_global_step` / `example_tactical_step` / `example_atomic_step.md` to real **`snake_case`** slugs.
3. Replace placeholder headings in each `spec.md` and atomic `.md` file.
4. Delete this `README.md` from the new spec folder if you do not want it tracked (or keep a one-line pointer to `PROJECT_RULES.md` §3).

## On-disk layout (canonical)

```text
docs/specs/<specname>/spec.md
docs/specs/<specname>/<global_step_slug>/spec.md
docs/specs/<specname>/<global_step_slug>/<tactical_step_slug>/spec.md
docs/specs/<specname>/<global_step_slug>/<tactical_step_slug>/<atomic_step_slug>.md
```

Full policy: [`../PROJECT_RULES.md`](../PROJECT_RULES.md) — **CR-017**, **LAYOUT-09**.
