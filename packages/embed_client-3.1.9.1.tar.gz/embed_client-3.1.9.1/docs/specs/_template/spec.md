# <Spec title> (`<specname>`)

## Purpose

<!-- Why this work exists; link to issues or prior context if any. -->

## Scope

**In scope:**

<!-- … -->

**Out of scope:**

<!-- … -->

## Requirements

<!-- Functional and non-functional constraints; acceptance criteria at epic level. -->

## Risks and open questions

<!-- … -->

## Global steps

<!-- List of `global_step_slug` directories under this spec; keep in sync with disk. -->

- [ ] `example_global_step/` — …

## References

<!-- Design docs, APIs, related specs. -->
