# Global step: <short name> (`example_global_step`)

## Goal

<!-- What this global step achieves for the epic. -->

## Exit criteria

<!-- Observable conditions that mean this step is done. -->

## Tactical steps

<!-- List of `tactical_step_slug` directories; keep in sync with disk. -->

- [ ] `example_tactical_step/` — …

## Notes

<!-- Dependencies, sequencing, hand-offs. -->
