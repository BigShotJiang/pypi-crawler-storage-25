# Tactical step: <short name> (`example_tactical_step`)

## Objective

<!-- Work packages and intent at tactical granularity. -->

## Dependencies

<!-- Other tactical or global steps that must complete first. -->

## Atomic steps

<!-- One row per `<atomic_step_slug>.md` in this directory. -->

| File | Summary | Status |
|------|---------|--------|
| `example_atomic_step.md` | … | todo |

## Completion checklist

<!-- Optional: release / review gates for this tactical unit. -->
