# Atomic step: <short name> (`example_atomic_step`)

## Intent

<!-- Single PR-sized outcome; one clear deliverable. Atomic steps must be unambiguous, complete, and consistent with parents — not necessarily exhaustive “weak model” handoffs. -->

## Tasks

- [ ] …

## Definition of done

<!-- Tests, docs, review — be specific. -->

## Notes

<!-- Implementation hints only if they avoid duplicating the tactical spec. -->
