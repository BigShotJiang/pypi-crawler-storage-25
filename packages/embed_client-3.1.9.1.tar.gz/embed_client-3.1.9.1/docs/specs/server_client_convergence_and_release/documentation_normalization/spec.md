<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# Documentation normalization

## Goal

Reduce the documentation tree to the necessary set of documents and rewrite that surviving set so it is complete, detailed, normalized, deduplicated, and aligned with the migrated codebase.

## In scope

- Remove obsolete, duplicate, speculative, or legacy-oriented documentation.
- Rewrite or restructure surviving documentation to match the final code, package metadata, configuration model, and supported workflows.
- Treat examples as first-class documentation artifacts and normalize them using the server-internal client examples as the quality reference.
- Ensure one canonical example documents the complete real-server workflow against `localhost:8001` over `mTLS` using certificates from `mtls_certificates`.
- Ensure the remaining documentation is internally coherent and suitable for release.

## Out of scope

- Production code changes except where doc inaccuracies reveal a release-blocking implementation mismatch that must be escalated.

## Exit criteria

- Only necessary documentation remains.
- The remaining documentation is complete, detailed, normalized, and code-aligned.
- Release consumers can understand installation, configuration, runtime behavior, and supported workflows from the surviving docs.
- The example set serves as complete operational documentation for supported client capabilities, with man-page-level docstrings aligned to the final code.
- The documentation set includes one canonical `localhost:8001` `mTLS` end-to-end example using `mtls_certificates` that covers all supported client capabilities in a single operational flow.
