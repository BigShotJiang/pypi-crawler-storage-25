<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# DN-AT-09 — `docs/api_format.md`

## Executor role

`coder_auto` (Markdown).

## Execution directive

Ensure JSON-RPC / response shapes described match **`EmbeddingClient`** usage paths (e.g. **`cmd`**, **`jsonrpc`**, **`embed`** return structures). Remove adapter-only or pre-migration transport narratives.

## Parent links

| Document | Path |
|----------|------|
| Global step | `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md` |
| Tactical task | `docs/tech_spec/branches/documentation_normalization/tasks/doc_guides_examples_canonical_mtls.md` |

## Tech spec reference

- `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md`

## Step scope

- **Target file:** `docs/api_format.md`
- **Action:** modify

## Dependency contract

- **Depends on:** DN-AT-01

## Read first

1. `embed_client/response_parsers.py` / `response_normalizer.py` if API shapes documented there
2. `embed_client/embedding_client.py` — methods that return dicts / lists
3. Current `docs/api_format.md`

## Expected file change

- Example payloads must match what `EmbeddingClient` returns after normalization (cite actual keys from code or tests).

## Mandatory validation

```bash
pytest -q
```

## Forbidden patterns

- Do not document removed `adapter_transport` module.

## LLAMA-readiness supplement

**Edge case:** If server returns extra fields, document “may include” only if tests show passthrough.
