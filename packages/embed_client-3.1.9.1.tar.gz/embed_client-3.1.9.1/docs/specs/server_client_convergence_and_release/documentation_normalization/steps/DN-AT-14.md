<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# DN-AT-14 — `examples/security_examples_ru.py` module documentation

## Executor role

`coder_auto` (Python).

## Execution directive

Mirror **DN-AT-13** for Russian module docstring: man-page level (Russian), consistent security-mode narrative with deploy matrix, links to Russian/English docs as appropriate. **`EmbeddingClient`** terminology only.

## Parent links

| Document | Path |
|----------|------|
| Global step | `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md` |
| Tactical task | `docs/tech_spec/branches/documentation_normalization/tasks/doc_guides_examples_canonical_mtls.md` |

## Tech spec reference

- `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md`

## Step scope

- **Target file:** `examples/security_examples_ru.py`
- **Action:** modify

## Dependency contract

- **Depends on:** DN-AT-01  
- **Soft:** align mode-count prose with **DN-AT-13** after both edited.

## Read first

1. `examples/security_examples_ru.py` (full)
2. `examples/security_examples.py` (after DN-AT-13 for parity)

## Expected file change

- Russian module docstring: prerequisites, run instructions, SEE ALSO with paths like `docs/SERVER_MODES_AND_CLIENT.md`.

## Mandatory validation

```bash
black examples/security_examples_ru.py
flake8 examples/security_examples_ru.py
pytest -q
```

## Forbidden patterns

- Do not translate code identifiers to Russian.
- Do not add Russian to `ARTIFACT_LOCALE` English files other than this file (this file is RU by convention).

## LLAMA-readiness

- **Author line:** keep `Author: Vasiliy Zdanovskiy` / `email: vasilyvz@gmail.com` in module docstring if present.
