<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# DN-AT-13 — `examples/security_examples.py` module documentation

## Executor role

`coder_auto` (Python).

## Execution directive

Upgrade **module docstring** to man-page level (purpose, prerequisites, env vars if any, how to run with `argparse`, link to `docs/SERVER_MODES_AND_CLIENT.md` and canonical mTLS example). Align **security mode count** with project deploy matrix (**8** modes: http; http+token; http+token+roles; https; https+token; https+token+roles; mtls; mtls+roles) — update numbered list and prose if it still says **6**.

## Parent links

| Document | Path |
|----------|------|
| Global step | `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md` |
| Tactical task | `docs/tech_spec/branches/documentation_normalization/tasks/doc_guides_examples_canonical_mtls.md` |

## Tech spec reference

- `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md`

## Step scope

- **Target file:** `examples/security_examples.py`
- **Action:** modify

## Dependency contract

- **Depends on:** DN-AT-01

## Read first

1. `.cursor/rules/deploy.mdc` (mode list)
2. Full `examples/security_examples.py` (which examples exist — map to 8 modes or document subset honestly)
3. `embed_client/client_factory.py` (`detect_security_mode` or related)

## Expected file change

- Module docstring expansion; fix mode count mismatch **only** if `example_*` functions cover 8 modes or document explicitly which modes are illustrated vs deferred to other docs.
- Terminology: **`EmbeddingClient`** only.

## Imports (preserve file imports; do not add unused)

Existing top imports remain; no new imports unless needed for a docstring cross-reference (prefer plain backticks in docstring, not imports).

## Mandatory validation

```bash
black examples/security_examples.py
flake8 examples/security_examples.py
pytest -q
```

## Method logic

- If code only implements 6 demos, docstring must say “demonstrates N operational patterns” and point to full matrix in `docs/SERVER_MODES_AND_CLIENT.md` rather than falsely claiming 8 runnable demos.

## Forbidden patterns

- Do not rename `example_*` functions in this step (scope creep).

## Edge cases

- Long file: change only module docstring and comments that reference wrong mode count unless tactical requires inline fixes for `EmbeddingServiceAsyncClient` string (grep file).
