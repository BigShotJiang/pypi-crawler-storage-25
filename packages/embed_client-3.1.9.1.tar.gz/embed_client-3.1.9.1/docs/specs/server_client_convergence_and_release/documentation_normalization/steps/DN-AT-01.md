<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# DN-AT-01 — Legacy documentation tree prune (grep + batch delete)

## Executor role

`coder_auto` (filesystem + git operations only; no production Python edits in this step).

## Execution directive

Execute the pre-delete grep protocol, record hits, then delete the listed obsolete documentation paths. Do not modify `docs/PROJECT_RULES.md` or `docs/agents/project_overlay.md` in this step (DN-AT-02 / DN-AT-03).

## Parent links

| Document | Path |
|----------|------|
| Global step (epic sub-step) | `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md` |
| Tactical task | `docs/tech_spec/branches/documentation_normalization/tasks/doc_legacy_tree_prune_and_governance.md` |

## Tech spec reference

- `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md` (goal: reduce doc tree; remove obsolete program-of-record).

## Step scope

- **Target:** Multiple repository paths (not a single file). **Action:** delete trees and files per tactical inventory.
- **Deliverable:** Listed paths absent from working tree; grep log saved or pasted into commit message / follow-up for DN-02 if README hits found.

## Dependency contract

- **Inputs:** None (first wave).
- **Outputs:** Deleted paths; follow-up list of files that still reference `docs/tech_spec/` or `docs/specs/tech_spec/` for DN-AT-04 / DN-AT-08+ if any hits outside deleted trees.

## Required context

- Tactical **Forbidden approaches:** do not delete `docs/specs/server_client_convergence_and_release/**`; do not partially delete only part of `docs/tech_spec/branches/` without removing the full duplicate policy tree.

## Read first

1. `docs/tech_spec/branches/documentation_normalization/tasks/doc_legacy_tree_prune_and_governance.md`
2. `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md`

## Expected file change

- **Remove** directories and files from disk (git `rm -r` or delete + stage).

## Forbidden alternatives

- Do not delete `docs/specs/server_client_convergence_and_release/**`, `docs/specs/_template/**`, `docs/ai_reports/**`.
- Do not use compatibility shims or stub files in place of deleted trees.

## Atomic operations

1. Run **pre-delete grep** from repository root and capture output (or save to a temporary note for the closure report):
   - `git grep -n "docs/tech_spec" -- . || true`
   - `git grep -n "docs/specs/tech_spec" -- . || true`
   - Optionally: `git grep -n "](docs/tech_spec" README.md docs/ || true` for markdown link patterns.
2. If **README.md** or other **DN-02** targets link into paths about to be deleted, **do not** edit them in this step; add their paths to the handoff list for DN-AT-04+.
3. Delete entire tree: `docs/specs/tech_spec/` (if present).
4. **Under `docs/tech_spec/` (if present), delete everything except the preserved subtree**  
   `docs/tech_spec/branches/documentation_normalization/`  
   (active tactical tasks for this global step). Concretely: remove `docs/tech_spec/tech_spec.md`, `implementation_plan.md`, `CROSS_DOCUMENT_COHERENCE_AUDIT.md`, `steps/`, and **all other** `docs/tech_spec/branches/*` sibling directories (legacy tactical branches), without touching `documentation_normalization/`.
5. Delete file: `docs/performance_test_results.md` (if present).
6. Delete file: `docs/TEST_SUITE_HANG_ANALYSIS.md` (if present).
7. **Orphan fragment:** If `docs/specs/client_server_alignment_migration/` contains only the nested `remove_legacy_and_normalize_verification/legacy_cleanup_and_verification/spec.md` and no sibling epic `spec.md` at `docs/specs/client_server_alignment_migration/spec.md`, delete that `spec.md` file, then remove empty parent directories up to and including `docs/specs/client_server_alignment_migration/` if the directory becomes empty. If additional tracked files exist under that epic folder, delete **only** the listed `legacy_cleanup_and_verification/spec.md` and stop (escalate if ambiguous).

## Expected deliverables

- Absent paths on disk: `test ! -d docs/specs/tech_spec`; under `docs/tech_spec/`, only `branches/documentation_normalization/` may remain (verify sibling legacy branches are gone).
- Staged deletions ready for commit.

## Mandatory validation

```bash
# After deletes (from repo root, venv active per CR-005):
test ! -e docs/performance_test_results.md
test ! -e docs/TEST_SUITE_HANG_ANALYSIS.md
pytest -q
```

**Expected:** `pytest` exits **0** (full suite green). If any test imports deleted markdown paths, stop and hand off corrective step (should not occur for pure doc deletes).

## Decision rules

- If `docs/specs/tech_spec` or `docs/tech_spec` does not exist, skip that delete (no error).
- If legal/compliance requires retaining historical specs, **stop** and escalate global orchestrator (do not proceed per tactical default).

## Blackstops

- Any `git grep` hit inside **surviving** authoritative docs that still points to deleted trees as **active** spec location → list for DN-AT-02/DN-AT-04; do not invent redirects in this step.

## Handoff package

- Grep output summary (paths + line counts).
- List of files needing link fixes in later steps (if any).
- Confirmation orphan `client_server_alignment_migration` subtree removal completed or partial.

## LLAMA-readiness supplement

| Field | Value |
|-------|--------|
| Target path | N/A (multi-path delete); **action:** delete |
| Module docstring | N/A |
| Imports | N/A (no Python) |
| Class/function skeleton | N/A |
| Constants | N/A |

## Forbidden patterns

- Do not run `pip install --break-system-packages`.
- Do not delete `docs/ai_reports/` content.
