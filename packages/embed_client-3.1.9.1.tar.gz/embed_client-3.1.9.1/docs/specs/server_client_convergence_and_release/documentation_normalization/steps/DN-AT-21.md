<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# DN-AT-21 — `docs/agents/project_overlay.md` finalize cross-links (post DN-03)

## Executor role

`coder_auto` (Markdown).

## Execution directive

Finalize **`docs/agents/project_overlay.md`** after **`examples/README.md`**, **`canonical_mtls_localhost_8001.py`**, and root **`README.md`** are updated. Replace DN-AT-03 placeholders with concrete links: **`examples/canonical_mtls_localhost_8001.py`**, **`tests/test_canonical_mtls_example.py`**, env vars **`RUN_CANONICAL_MTLS_E2E`**, **`CANONICAL_EMBED_FILE_SERVER_PATH`**, **`pyproject.toml`** for pytest.

## Parent links

| Document | Path |
|----------|------|
| Global step | `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md` |
| Tactical task | `docs/tech_spec/branches/documentation_normalization/tasks/doc_guides_examples_canonical_mtls.md` |

## Tech spec reference

- `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md`

## Step scope

- **Target file:** `docs/agents/project_overlay.md`
- **Action:** modify

## Dependency contract

- **Depends on:** DN-AT-03, DN-AT-11, DN-AT-19 (and logically DN-AT-04 for README anchors)

## Read first

1. Current `docs/agents/project_overlay.md`
2. `README.md` (canonical section)
3. `examples/README.md` (first section)

## Expected file change

- **Functional context:** single paragraph naming **`EmbeddingClient`**, **`ClientFactory`**, **`ConfigValidator`**, **`ClientConfigGenerator`** as user-facing entry points.
- **Tests row:** `pytest` configuration in **`pyproject.toml`** `[tool.pytest.ini_options]` — no `pytest.ini`.
- **Planning stack:** only `docs/specs/<specname>/` + optional `docs/plans/` — no `docs/tech_spec/`.
- **Canonical example block:** bullet list: script path, test module path, env vars, link to `mtls_certificates/README.md`.

## Mandatory validation

```bash
pytest -q
```

## Forbidden patterns

- Do not duplicate full README content; use pointers.

## Blackstops

- If DN-AT-03 placeholder text was removed entirely, re-add concise canonical example subsection.

## LLAMA-readiness

- Relative links: `../PROJECT_RULES.md`, `../../examples/canonical_mtls_localhost_8001.py` — use correct depth from `docs/agents/` (`../examples/` is wrong; from `docs/agents/` examples are `../../examples/...`).

## Atomic operations

1. Open `docs/agents/project_overlay.md`.
2. Fix relative URL to `examples/canonical_mtls_localhost_8001.py`: from `docs/agents/` the repo-relative markdown link is `[canonical example](../../examples/canonical_mtls_localhost_8001.py)`.
3. Fix test file link: `[tests/test_canonical_mtls_example.py](../../tests/test_canonical_mtls_example.py)`.
