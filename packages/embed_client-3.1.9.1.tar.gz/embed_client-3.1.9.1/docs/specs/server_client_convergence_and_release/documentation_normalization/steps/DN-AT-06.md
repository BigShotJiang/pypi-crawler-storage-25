<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# DN-AT-06 — `CLI_README.md` entry points

## Executor role

`coder_auto` (Markdown).

## Execution directive

Rewrite `CLI_README.md` so documented commands match **`pyproject.toml`** `[project.scripts]`:

- `embed-config-generator` → `embed_client.config_generator_cli:main`
- `embed-config-validator` → `embed_client.config_validator_cli:main`
- `embed-vectorize` → `embed_client.cli:cli_main`

Include `python -m embed_client.cli` (or equivalent module invocation) only if actually supported; verify against `embed_client/cli_core.py` / `cli` package exports.

## Parent links

| Document | Path |
|----------|------|
| Global step | `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md` |
| Tactical task | `docs/tech_spec/branches/documentation_normalization/tasks/doc_root_metadata_and_pypi_surface.md` |

## Tech spec reference

- `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md`

## Step scope

- **Target file:** `CLI_README.md`
- **Action:** modify

## Dependency contract

- **Depends on:** DN-AT-01

## Read first

1. `pyproject.toml` `[project.scripts]`
2. `embed_client/config_generator_cli.py` (entry `main`)
3. `embed_client/config_validator_cli.py` (entry `main`)
4. `embed_client/cli.py` or `cli_core.py` for `cli_main`
5. Current `CLI_README.md`

## Expected file change

- Per-command sections: purpose, minimal example, common flags (as implemented).
- No references to deleted modules.

## Mandatory validation

```bash
pytest -q
```

## Forbidden patterns

- Do not invent CLI flags; copy from `--help` output or source `ArgumentParser` definitions.

## LLAMA-readiness supplement

**Exact script names (constants):**

- `embed-config-generator`
- `embed-config-validator`
- `embed-vectorize`
