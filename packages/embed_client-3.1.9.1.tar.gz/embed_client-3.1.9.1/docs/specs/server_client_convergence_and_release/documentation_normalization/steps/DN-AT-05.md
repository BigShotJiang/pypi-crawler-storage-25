<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# DN-AT-05 — `CONFIGURATION.md` configuration narrative

## Executor role

`coder_auto` (Markdown).

## Execution directive

Rewrite `CONFIGURATION.md` so JSON/config schema narrative matches **`ClientConfig`**, **`ConfigValidator`**, and **`ClientConfigGenerator`** / generator CLI behavior. Add a section **“Recommended local integration (mTLS, port 8001)”** with certificate paths consistent with `examples/canonical_mtls_localhost_8001.py` and `mtls_certificates/` layout.

## Parent links

| Document | Path |
|----------|------|
| Global step | `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md` |
| Tactical task | `docs/tech_spec/branches/documentation_normalization/tasks/doc_root_metadata_and_pypi_surface.md` |

## Tech spec reference

- `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md`

## Step scope

- **Target file:** `CONFIGURATION.md`
- **Action:** modify

## Dependency contract

- **Depends on:** DN-AT-01

## Read first

1. `embed_client/config.py` or module defining `ClientConfig` (field names and nesting)
2. `embed_client/config_validator.py` (validation rules summary)
3. `embed_client/config_generator.py` or `config_generator_cli.py` (CLI flags / output shape)
4. `examples/canonical_mtls_localhost_8001.py` (`build_mtls_localhost_8001_config` dict structure)
5. Current `CONFIGURATION.md`

## Expected file change

- Document protocol values **`http`**, **`https`**, **`mtls`** and field requirements per validator.
- mTLS section: paths under **`mtls_certificates/client/`** and **`mtls_certificates/ca/`** matching repository layout (no hardcoded `/home/...`).
- Remove legacy client names and adapter-only narratives.

## Atomic operations (documentation algorithm)

1. Map each major JSON top-level key to prose (`protocol`, `server`, `auth`, `ssl`, `client`, … as actually present in code).
2. For each security mode, state which fields must be non-null.
3. Insert “Recommended local integration (mTLS, port 8001)” after general overview.
4. Cross-link `CLI_README.md` for generator/validator commands without duplicating full CLI text.

## Mandatory validation

```bash
pytest -q
```

## Forbidden patterns

- Do not list PyJWT / cryptography / pydantic as **core** runtime deps unless imports exist in `embed_client/` production code (tactical: verify before asserting).

## LLAMA-readiness supplement

| Field | Value |
|-------|--------|
| Imports | N/A |

## Blackstops

- Example JSON snippets must be valid for `ConfigValidator` (run generator CLI mentally or copy from tests).
