<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# DN-AT-18 — `embed_client/example_async_usage_ru_demo.py` docstrings

## Executor role

`coder_auto` (Python).

## Execution directive

Mirror **DN-AT-16** in Russian for module and function docstrings; **`EmbeddingClient`** terminology; link to `example_async_usage_ru.py` parent.

## Parent links

| Document | Path |
|----------|------|
| Global step | `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md` |
| Tactical task | `docs/tech_spec/branches/documentation_normalization/tasks/doc_guides_examples_canonical_mtls.md` |

## Tech spec reference

- `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md`

## Step scope

- **Target file:** `embed_client/example_async_usage_ru_demo.py`
- **Action:** modify

## Dependency contract

- **Depends on:** DN-AT-01

## Read first

1. Full `embed_client/example_async_usage_ru_demo.py`

## Imports

```
from __future__ import annotations

import ssl
from typing import Any, Dict, List

from embed_client.embedding_client import EmbeddingClient
from embed_client.exceptions import EmbedError
from embed_client.client_factory import ClientFactory, detect_security_mode
from embed_client.response_parsers import extract_embeddings
```

## Mandatory validation

```bash
black embed_client/example_async_usage_ru_demo.py
flake8 embed_client/example_async_usage_ru_demo.py
mypy embed_client/example_async_usage_ru_demo.py
pytest -q
```

## Forbidden patterns

- Do not remove `import ssl` if used in file body.
