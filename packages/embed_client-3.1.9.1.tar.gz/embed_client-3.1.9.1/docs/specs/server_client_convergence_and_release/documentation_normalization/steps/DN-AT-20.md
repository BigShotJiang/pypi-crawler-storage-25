<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# DN-AT-20 — `tests/test_canonical_mtls_example.py` expectations for `CANONICAL_EMBED_FILE_SERVER_PATH`

## Executor role

`coder_auto` (Python tests).

## Execution directive

Update tests so **`DN-AT-19`** behavior is covered: dry-run unchanged; mocked live branch still completes; add test that when **`CANONICAL_EMBED_FILE_SERVER_PATH`** is unset, skip message appears in output **or** lines list from `run_live_capabilities` (depending on refactor); when set in mocked test, ensure **`embed_file`** is invoked or patched path exercised without requiring real server.

## Parent links

| Document | Path |
|----------|------|
| Global step | `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md` |
| Tactical task | `docs/tech_spec/branches/documentation_normalization/tasks/doc_guides_examples_canonical_mtls.md` |

## Tech spec reference

- `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md`

## Step scope

- **Target file:** `tests/test_canonical_mtls_example.py`
- **Action:** modify

## Dependency contract

- **Depends on:** DN-AT-19

## Read first

1. `tests/test_canonical_mtls_example.py` (full)
2. `examples/canonical_mtls_localhost_8001.py` after DN-AT-19

## Expected file change

- Extend **`test_canonical_mtls_live_smoke_mocked`** or add sibling test:
  - Patch `EmbeddingClient.embed_file` to `AsyncMock` if needed so live mocked path does not require file on disk.
  - Assert skip line substring when env unset and `RUN_CANONICAL_MTLS_E2E=1` with mocks (call `run_live_capabilities` directly with a mock client if easier).
- **`test_canonical_mtls_main_dry_run_no_network`**: must still pass; dry run should not require `embed_file` network.

## Exact test expectations (minimum)

1. **`test_canonical_mtls_config_paths_exist`**: unchanged assertions unless config builder changed (should not).
2. New or updated test: **`test_canonical_mtls_embed_file_env_skip_message`** (name may vary): `monkeypatch.delenv("CANONICAL_EMBED_FILE_SERVER_PATH", raising=False)`, mock client, await `run_live_capabilities`, assert **`embed_file skipped`** substring in joined output/lines.
3. Optional: **`test_canonical_mtls_embed_file_env_calls_embed_file`**: set env to **`"/tmp/canonical_embed_test.txt"`**, mock `client.embed_file` → assert called with `input_file` matching.

## Mandatory validation

```bash
black tests/test_canonical_mtls_example.py
flake8 tests/test_canonical_mtls_example.py
pytest tests/test_canonical_mtls_example.py -v
pytest -q
```

## Forbidden patterns

- Do not mark new tests `@pytest.mark.integration` if they use mocks only.
- Do not require real server for new tests.

## Imports (add as needed)

```
from unittest.mock import AsyncMock, patch, MagicMock
```

(Use existing imports from file first.)

## Error handling

- Tests must not leak env vars: use `monkeypatch` for env.

## LLAMA-readiness

- If `run_live_capabilities` is not imported in tests, use `from examples.canonical_mtls_localhost_8001 import run_live_capabilities` inside test or module level per existing style.
