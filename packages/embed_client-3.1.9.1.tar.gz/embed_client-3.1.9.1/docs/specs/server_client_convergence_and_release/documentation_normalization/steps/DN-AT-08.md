<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# DN-AT-08 — `docs/client_integration_guide.md`

## Executor role

`coder_auto` (Markdown).

## Execution directive

Replace all **`EmbeddingServiceAsyncClient`** and legacy adapter client references with **`EmbeddingClient`**. Structure sections to cover: Overview, initialization, embedding, queue polling, job status, error handling, API reference (links to methods), troubleshooting — with **valid** `from embed_client import …` / `embed_client.exceptions` imports.

## Parent links

| Document | Path |
|----------|------|
| Global step | `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md` |
| Tactical task | `docs/tech_spec/branches/documentation_normalization/tasks/doc_guides_examples_canonical_mtls.md` |

## Tech spec reference

- `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md`

## Step scope

- **Target file:** `docs/client_integration_guide.md`
- **Action:** modify

## Dependency contract

- **Depends on:** DN-AT-01

## Read first

1. `embed_client/embedding_client.py` (public API)
2. `embed_client/exceptions.py` (exception hierarchy)
3. Current `docs/client_integration_guide.md`

## Expected file change

- Full rewrite pass for terminology; no links to `docs/tech_spec/` deleted paths.
- Internal links to `docs/api_format.md`, `docs/SERVER_MODES_AND_CLIENT.md` must remain valid relative paths.

## Mandatory validation

```bash
pytest -q
```

## Forbidden patterns

- Russian prose in this file unless file was already bilingual (tactical: **English** for new content).
- Do not modify `README.md` in this step.

## LLAMA-readiness supplement

**Valid import examples:**

- `from embed_client import EmbeddingClient`
- `from embed_client.exceptions import EmbedClientError, EmbedHTTPError` (verify exact names in `exceptions.py`)
