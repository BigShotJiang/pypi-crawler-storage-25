<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# DN-AT-12 — `examples/async_testing_client_example.py` module documentation

## Executor role

`coder_auto` (Python: docstrings only unless trivial comment fixes).

## Execution directive

Expand the **module-level docstring** to man-page standard: purpose, prerequisites, how to run, links to `docs/client_integration_guide.md` and config CLIs, exit behavior. Ensure terminology **`EmbeddingClient`** only; no stale class names in body text.

## Parent links

| Document | Path |
|----------|------|
| Global step | `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md` |
| Tactical task | `docs/tech_spec/branches/documentation_normalization/tasks/doc_guides_examples_canonical_mtls.md` |

## Tech spec reference

- `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md`

## Step scope

- **Target file:** `examples/async_testing_client_example.py`
- **Action:** modify

## Dependency contract

- **Depends on:** DN-AT-01

## Read first

1. Full `examples/async_testing_client_example.py`
2. `docs/client_integration_guide.md` (after DN-AT-08 path — use current file on disk)

## Expected file change

- Module docstring: **NAME**, **SYNOPSIS**, **DESCRIPTION**, **SEE ALSO** (relative paths to docs).
- Do not rename functions or change logic unless a broken string references deleted paths.

## Imports (unchanged unless broken)

```
from __future__ import annotations
import asyncio
import sys
from pathlib import Path
from embed_client.config_generator import ClientConfigGenerator
from embed_client.config_validator import ConfigValidator
from embed_client.embedding_client import EmbeddingClient
```

## Mandatory validation

```bash
black examples/async_testing_client_example.py
flake8 examples/async_testing_client_example.py
pytest -q
```

**Expected:** black reformats or OK; flake8 **0**; pytest **all passed**.

## Forbidden patterns

- Do not add `from typing import Any` unless needed.
- Do not use `print()` for new logging of secrets.

## LLAMA-readiness — module docstring algorithm

1. State script runs from repo root; inserts `_ROOT` into `sys.path`.
2. List what `main()` does in order (generate → validate → client smoke).
3. Link `ConfigValidator`, `ClientConfigGenerator`, `EmbeddingClient` by reStructuredText `:class:` if used elsewhere in repo examples.

## Error handling

- No change to exception behavior unless docstring describes existing behavior incorrectly.

## Edge cases

- If `configs/_example_generated_http.json` path is documented, state it is written under `configs/`.

## Blackstops

- Broken relative link to `docs/client_integration_guide.md` — must be valid from repo root perspective (examples often use `docs/...` from README context; in docstring use path string `docs/client_integration_guide.md`).
