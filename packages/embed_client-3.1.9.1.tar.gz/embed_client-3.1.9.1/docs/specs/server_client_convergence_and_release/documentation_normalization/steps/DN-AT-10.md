<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# DN-AT-10 — `docs/SERVER_MODES_AND_CLIENT.md`

## Executor role

`coder_auto` (Markdown).

## Execution directive

Align security modes matrix with deploy rule expectations and patterns in `examples/security_examples.py` / `examples/security_examples_ru.py`. Use **`EmbeddingClient`** only; map each mode to configuration fields and constructor/`from_config_dict` usage.

## Parent links

| Document | Path |
|----------|------|
| Global step | `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md` |
| Tactical task | `docs/tech_spec/branches/documentation_normalization/tasks/doc_guides_examples_canonical_mtls.md` |

## Tech spec reference

- `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md`

## Step scope

- **Target file:** `docs/SERVER_MODES_AND_CLIENT.md`
- **Action:** modify

## Dependency contract

- **Depends on:** DN-AT-01

## Read first

1. `.cursor/rules/deploy.mdc` or project deploy testing matrix (8 modes: http, http+token, http+token+roles, https, https+token, https+token+roles, mtls, mtls+roles)
2. `examples/security_examples.py` (structure)
3. Current `docs/SERVER_MODES_AND_CLIENT.md`

## Expected file change

- Table or list: mode name → protocol/auth/ssl summary → pointer to example function or config snippet.

## Mandatory validation

```bash
pytest -q
```

## Forbidden patterns

- Do not reference `EmbeddingServiceAsyncClient`.
