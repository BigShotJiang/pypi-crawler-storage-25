<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# DN-AT-04 — `README.md` root product documentation

## Executor role

`coder_auto` (Markdown).

## Execution directive

Rewrite `README.md` for `EmbeddingClient`-centric quick start, installation, canonical mTLS E2E section, pointers to `CONFIGURATION.md`, `CLI_README.md`, `examples/README.md`, and development/testing with **pytest via `pyproject.toml`**. Remove **`EmbeddingServiceAsyncClient`**, **`async_client`**, **`testing_client`**, **`adapter_transport`**, and nonexistent module names.

## Parent links

| Document | Path |
|----------|------|
| Global step | `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md` |
| Tactical task | `docs/tech_spec/branches/documentation_normalization/tasks/doc_root_metadata_and_pypi_surface.md` |

## Tech spec reference

- `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md`

## Step scope

- **Target file:** `README.md`
- **Action:** modify

## Dependency contract

- **Depends on:** DN-AT-01 (no links to deleted `docs/tech_spec/` paths).

## Read first

1. `embed_client/__init__.py` (`__all__`)
2. `embed_client/embedding_client.py` (public methods list — read class docstring and public `async def` names)
3. `docs/tech_spec/branches/documentation_normalization/tasks/doc_root_metadata_and_pypi_surface.md`
4. `examples/canonical_mtls_localhost_8001.py` (first 80 lines for env vars and purpose)
5. `tests/test_canonical_mtls_example.py` (for README citation of test module path)

## Expected file change

**Required section order (algorithm):**

1. Title + one-paragraph purpose: migrated server-aligned client; **`from embed_client import EmbeddingClient`**.
2. Installation: `pip install embed-client` and editable dev (`pip install -e .`).
3. **Prominent heading:** “Canonical real-server E2E (localhost:8001, mTLS)” linking to:
   - `examples/canonical_mtls_localhost_8001.py`
   - env var **`RUN_CANONICAL_MTLS_E2E`**
   - **`mtls_certificates/`** layout (pointer to `mtls_certificates/README.md` if exists)
   - **`tests/test_canonical_mtls_example.py`**
   - After DN-AT-19 lands: mention **`CANONICAL_EMBED_FILE_SERVER_PATH`** in this block (if README is edited before DN-AT-19, add “optional `embed_file` via env” placeholder consistent with tactical DN-03).
4. Minimal code sample: `EmbeddingClient` construction + `embed` or `health` with valid imports from `embed_client` and `embed_client.exceptions` if showing errors.
5. Pointers: `CONFIGURATION.md`, `CLI_README.md`, `examples/README.md`.
6. Security modes: short summary + link to `docs/SERVER_MODES_AND_CLIENT.md` (not full matrix duplication).
7. Development / tests: run **`pytest`** (config in **`pyproject.toml`** `[tool.pytest.ini_options]`); no `pytest.ini`.

## Forbidden alternatives

- Do not document `submit_job`, `get_job_status_or_result`, `list_queue` as the public **`EmbeddingClient`** API unless verified in `embedding_client.py` (tactical: use **`embed`**, **`wait_for_job`**, **`job_status`**, **`list_queued_commands`**, **`cmd`**).

## Mandatory validation

```bash
pytest -q
```

## Error handling / edge cases

- N/A (documentation).

## Constants and literals

- Port **8001**, host **localhost** for canonical example references.
- Env var names: **`RUN_CANONICAL_MTLS_E2E`**, **`CANONICAL_EMBED_FILE_SERVER_PATH`** (document when DN-AT-19 merged).

## Forbidden patterns

- Do not modify `CONFIGURATION.md`, `pyproject.toml`, or `examples/` in this step.

## Handoff package

- None.

## LLAMA-readiness supplement

| Field | Value |
|-------|--------|
| Valid import line | `from embed_client import EmbeddingClient` |
| Invalid (forbidden in prose) | `from embed_client.async_client import EmbeddingServiceAsyncClient` |
