<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# DN-AT-19 — `examples/canonical_mtls_localhost_8001.py` — `CANONICAL_EMBED_FILE_SERVER_PATH` and docstring sync

## Executor role

`coder_auto` (Python).

## Execution directive

Extend **`run_live_capabilities`** so that after the existing **`jsonrpc`** step (or immediately before `return lines`), implement **`embed_file`** behavior gated by environment variable **`CANONICAL_EMBED_FILE_SERVER_PATH`**. Update the module docstring **ENVIRONMENT**, **DESCRIPTION** method list, and **embed_file** subsection to match runtime behavior.

## Parent links

| Document | Path |
|----------|------|
| Global step | `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md` |
| Tactical task | `docs/tech_spec/branches/documentation_normalization/tasks/doc_guides_examples_canonical_mtls.md` |

## Tech spec reference

- `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md`

## Step scope

- **Target file:** `examples/canonical_mtls_localhost_8001.py`
- **Action:** modify

## Dependency contract

- **Depends on:** DN-AT-01

## Read first

1. Full `examples/canonical_mtls_localhost_8001.py`
2. `embed_client/embedding_client.py` — method `embed_file` full signature (lines ~853+)
3. Tactical task concrete examples block (env values)

## Target file

- `examples/canonical_mtls_localhost_8001.py` — **action:** modify

## File header

Keep existing shebang, `# flake8: noqa: E501` if present, and module docstring Author/email; **extend** docstring sections only.

## Imports (complete list after edits)

```
from __future__ import annotations

import asyncio
import os
import sys
from pathlib import Path
from typing import Any, Dict, List

# sys.path bootstrap unchanged
from embed_client.embedding_client import EmbeddingClient
from embed_client.exceptions import EmbedClientError
```

## Class/function skeleton (no renames)

- `def _cert_paths(root: Path) -> Dict[str, str]:`
- `def build_mtls_localhost_8001_config(root: Path) -> Dict[str, Any]:`
- `async def run_live_capabilities(client: EmbeddingClient) -> List[str]:` — **extend**
- `async def main() -> None:` — optional: print env hint for new variable in dry run

## Method logic — `run_live_capabilities` (append steps)

**Algorithm (numbered):**

1. Execute existing steps through **`jsonrpc("health", {})`** and append lines as today.
2. Read `path_raw = os.environ.get("CANONICAL_EMBED_FILE_SERVER_PATH")`.
3. If `path_raw` is **None** or `path_raw.strip()` is empty: append one line with **exact text:** `embed_file skipped; set CANONICAL_EMBED_FILE_SERVER_PATH to a server-visible path to include embed_file in this tour.` Then go to step 6.
4. Set `input_file = path_raw.strip()`.
5. Try `await client.embed_file(input_file, wait=True, wait_timeout=600, error_policy="continue")` (keyword args; defaults for other parameters per `EmbeddingClient.embed_file` signature in `embed_client/embedding_client.py`). On success append `embed_file: ...` truncated to ~200 chars. On **`EmbedClientError`** append `embed_file: ERROR: {exc!r}`.
6. `return lines` (existing function exit).

**Exact call (reference signature):**

- `embed_file(self, input_file: str, *, file_format: str = "lines", ..., error_policy: Optional[str] = None, wait: bool = True, wait_timeout: int = 600, ...) -> Dict[str, Any]`

Use **`error_policy="continue"`** as a string literal matching **`embed`** examples in the same file.

## Error handling

| Condition | Behavior |
|-----------|----------|
| `embed_file` raises `EmbedClientError` | Append error line to `lines`; do not re-raise inside `run_live_capabilities` (consistent with `timing_stats` optional pattern). |
| Empty env | Single skip line **exact** wording per tactical task. |

## Return value specification

- `run_live_capabilities` still returns `List[str]` log lines.

## Edge cases

- **Whitespace-only env:** treat as unset → skip branch (same as empty).
- **Nonexistent file on client filesystem:** still call `embed_file` if env set — server may accept path server-side; if client validates file existence, follow existing `embed_file` implementation (read source).

## Constants and literals

- Env var name: **`CANONICAL_EMBED_FILE_SERVER_PATH`** (exact ASCII).
- `wait_timeout`: **600** (integer seconds) for `embed_file` call.
- `error_policy`: **`"continue"`** (string).

## Module docstring updates

1. **ENVIRONMENT** subsection: document **`CANONICAL_EMBED_FILE_SERVER_PATH`** (optional; server-visible path).
2. **DESCRIPTION**: add bullet for **`embed_file`** in the executed chain; remove obsolete paragraph that says script does not cover `embed_file` **or** rewrite to say it is env-gated.
3. List **all** methods touched in order matching `run_live_capabilities` execution order.

## Forbidden alternatives

- Do not hardcode `/home/...` paths.
- Do not rename `RUN_CANONICAL_MTLS_E2E` behavior.

## Mandatory validation

```bash
black examples/canonical_mtls_localhost_8001.py
flake8 examples/canonical_mtls_localhost_8001.py
mypy examples/canonical_mtls_localhost_8001.py
pytest tests/test_canonical_mtls_example.py -v
pytest -q
```

**Expected:** all **PASSED**; flake8 **exit 0**.

## Forbidden patterns

- Do not add new dependencies.
- Do not use `Any` for new variables unless necessary.

## Handoff package

- Note for DN-AT-20: new env branch may require mock/patch updates.
