<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# DN-AT-07 — `pyproject.toml` `[project]` description alignment

## Executor role

`coder_auto` (TOML edit).

## Execution directive

Rewrite **`[project]`** field **`description`** (multi-line string) so it:

- Names **`EmbeddingClient`** as the canonical client (not only “async client” without naming the class).
- Describes public API keywords consistent with **`embed_client/embedding_client.py`**: **`embed`**, **`wait_for_job`**, **`job_status`**, **`list_queued_commands`**, **`cmd`**, optional **`embed_file`**, introspection (**`list_commands`**, **`models`**, **`fetch_openapi_schema`**, **`http_get`**, **`timing_stats`**), TLS helpers (**`is_mtls_enabled`**, **`get_ssl_config`**) if public.
- **Removes** incorrect claims that the three queue methods are **`submit_job`**, **`get_job_status_or_result`**, **`list_queue`** unless those exact names exist as **public** methods on **`EmbeddingClient`** (verify with `grep` on class body).

## Parent links

| Document | Path |
|----------|------|
| Global step | `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md` |
| Tactical task | `docs/tech_spec/branches/documentation_normalization/tasks/doc_root_metadata_and_pypi_surface.md` |

## Tech spec reference

- `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md`

## Step scope

- **Target file:** `pyproject.toml`
- **Action:** modify (only `[project]` metadata fields needed for description alignment: primarily **`description`**; do not change version or dependencies unless required by typo fix — **avoid** scope creep).

## Dependency contract

- **Depends on:** DN-AT-01

## Read first

1. `embed_client/embedding_client.py` — list all `async def` public methods on `EmbeddingClient` (exclude private `_` prefixed).
2. `embed_client/__init__.py` — `__all__`
3. Current `pyproject.toml` `[project]` block
4. `docs/ai_reports/baseline_audit_code_research.md` if present for mismatch notes (optional)

## Expected file change

- Single coherent **`description`** block replacing lines that mention wrong queue API names.
- Preserve **`readme`**, **`dependencies`**, **`scripts`**, **`urls`** unless a one-line fix is required for consistency.

## Method verification algorithm

1. Run `grep -n "async def " embed_client/embedding_client.py` inside class `EmbeddingClient`.
2. Build allow-list of method names for prose.
3. Rewrite description bullet list to use only allow-listed names.

## Error handling

- N/A

## Edge cases

- If `description` length exceeds PyPI norms, still complete correctness first (tactical: escalate long_description split to orchestrator — **do not** split in this step unless user approved).

## Mandatory validation

```bash
python -c "import tomllib, pathlib; tomllib.loads(pathlib.Path('pyproject.toml').read_text())"
pytest -q
```

**Expected:** TOML parses; pytest **0**.

## Forbidden patterns

- Do not add optional deps as `dependencies` entries.
- Do not modify `[tool.pytest.ini_options]` in this step unless fixing a pre-existing error (avoid).

## LLAMA-readiness supplement

**Constants:** Package name string **`embed-client`** unchanged.

## Blackstops

- If `submit_job` appears in `embedding_client.py` as public API, reconcile tactical prohibition with actual code — **truth is code**; document what exists.
