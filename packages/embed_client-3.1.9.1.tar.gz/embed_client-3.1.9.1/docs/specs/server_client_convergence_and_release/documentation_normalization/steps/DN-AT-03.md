<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# DN-AT-03 — `docs/agents/project_overlay.md` minimal governance (DN-01 checkpoint)

## Executor role

`coder_auto` (Markdown only).

## Execution directive

Update `docs/agents/project_overlay.md` to remove adapter-centric client description, remove **`pytest.ini`** references (pytest configuration lives in **`pyproject.toml`**), and remove paths to deleted `docs/tech_spec/` trees. Add a **short placeholder** sentence that the canonical real-server example script is `examples/canonical_mtls_localhost_8001.py` (full cross-links finalized in DN-AT-21).

## Parent links

| Document | Path |
|----------|------|
| Global step | `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md` |
| Tactical task | `docs/tech_spec/branches/documentation_normalization/tasks/doc_legacy_tree_prune_and_governance.md` |

## Tech spec reference

- `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md`

## Step scope

- **Target file:** `docs/agents/project_overlay.md`
- **Action:** modify

## Dependency contract

- **Depends on:** DN-AT-01

## Read first

1. Current `docs/agents/project_overlay.md`
2. `docs/tech_spec/branches/documentation_normalization/tasks/doc_legacy_tree_prune_and_governance.md`
3. `pyproject.toml` (confirm `[tool.pytest.ini_options]` or pytest config location)

## Expected file change

- **Functional context** bullet: describe **`EmbeddingClient`** as the canonical runtime client (not generic “async client via adapter” without naming `EmbeddingClient`).
- Replace “tests with pytest (`pytest.ini`)” with “tests with **pytest**; configuration in **`pyproject.toml`**”.
- **Planning stack:** remove “legacy material may still live under `docs/tech_spec/`”.
- **Subtree table:** remove or rewrite rows that cite `docs/tech_spec/` as active; align `docs/ai_reports/` promotion targets to `docs/specs/`, guides, `bugreports` — not `tech_spec/`.
- Add one line: canonical localhost:8001 mTLS walkthrough: `examples/canonical_mtls_localhost_8001.py` (details in README / examples README after DN-02/DN-03).

## Forbidden alternatives

- Do not claim `pytest.ini` exists at repo root.
- Do not finalize duplicate prose that DN-AT-21 will expand; keep placeholder minimal.

## Atomic operations

1. Grep `project_overlay.md` for `tech_spec`, `pytest.ini`, `adapter`, `EmbeddingServiceAsyncClient`.
2. Apply replacements per Expected file change.
3. Ensure relative link to `PROJECT_RULES.md` still works (`../PROJECT_RULES.md`).

## Expected deliverables

- Updated `docs/agents/project_overlay.md` only.

## Mandatory validation

```bash
pytest -q
```

**Expected:** exit code **0**.

## Decision rules

- If a section duplicates `PROJECT_RULES.md` extensively, trim duplication in overlay to pointers rather than copying full LAYOUT tables.

## Blackstops

- Any remaining `docs/tech_spec/` presented as a current planning location → fix.

## Handoff package

- Note for DN-AT-21: “finalize overlay links after canonical example + examples README”.

## LLAMA-readiness supplement

| Field | Value |
|-------|--------|
| Imports | N/A |
| Constants | PyPI name `embed-client` unchanged in overlay if already present |

## Forbidden patterns

- Do not modify `docs/agents/universal_project_context.md` or `docs/agents/common_agent_rules.md` in this step.
