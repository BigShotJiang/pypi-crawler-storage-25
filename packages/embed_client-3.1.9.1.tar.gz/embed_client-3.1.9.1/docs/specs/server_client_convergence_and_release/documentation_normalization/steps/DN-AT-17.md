<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# DN-AT-17 — `embed_client/example_async_usage_ru.py` docstrings and CLI help

## Executor role

`coder_auto` (Python).

## Execution directive

Mirror **DN-AT-15** for Russian: module docstring links to `docs/client_integration_guide.md` (path remains English); RU help text in `ArgumentParser`; product name consistency with **`EmbeddingClient`**. Add pointer to **`examples/canonical_mtls_localhost_8001.py`** in Russian SEE ALSO if appropriate.

## Parent links

| Document | Path |
|----------|------|
| Global step | `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md` |
| Tactical task | `docs/tech_spec/branches/documentation_normalization/tasks/doc_guides_examples_canonical_mtls.md` |

## Tech spec reference

- `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md`

## Step scope

- **Target file:** `embed_client/example_async_usage_ru.py`
- **Action:** modify

## Dependency contract

- **Depends on:** DN-AT-01

## Read first

1. `embed_client/example_async_usage_ru.py` (full)
2. `embed_client/example_async_usage.py` (after DN-AT-15 for parity)

## Imports

```
import argparse
import asyncio
import json
import os
import sys
from typing import Any, Dict

from embed_client.embedding_client import EmbeddingClient
from embed_client.exceptions import EmbedConfigError
from embed_client.config import ClientConfig
from embed_client.client_factory import ClientFactory, create_client
from embed_client.example_async_usage_ru_demo import (
    run_client_examples,
    demonstrate_security_modes,
    demonstrate_automatic_detection,
)
```

## Mandatory validation

```bash
black embed_client/example_async_usage_ru.py
flake8 embed_client/example_async_usage_ru.py
mypy embed_client/example_async_usage_ru.py
pytest -q
```

## Forbidden patterns

- Do not translate module path strings (`embed_client` package name stays ASCII).
