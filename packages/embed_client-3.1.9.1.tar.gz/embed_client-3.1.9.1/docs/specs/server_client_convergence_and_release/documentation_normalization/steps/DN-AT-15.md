<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# DN-AT-15 — `embed_client/example_async_usage.py` docstrings and CLI help

## Executor role

`coder_auto` (Python).

## Execution directive

Update module docstring and `argparse.ArgumentParser` `description` strings to say **Embedding Client example** (not “Async Client” as product name if misleading). Ensure “see also” links use paths **`docs/client_integration_guide.md`**, **`README.md`**, **`examples/canonical_mtls_localhost_8001.py`** where relevant. Remove any reference to deleted `docs/tech_spec/` paths.

## Parent links

| Document | Path |
|----------|------|
| Global step | `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md` |
| Tactical task | `docs/tech_spec/branches/documentation_normalization/tasks/doc_guides_examples_canonical_mtls.md` |

## Tech spec reference

- `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md`

## Step scope

- **Target file:** `embed_client/example_async_usage.py`
- **Action:** modify

## Dependency contract

- **Depends on:** DN-AT-01

## Read first

1. Full `embed_client/example_async_usage.py`
2. `docs/client_integration_guide.md`

## Expected file change

- Module docstring: add **ENVIRONMENT**, **EXIT STATUS** if `main()` uses `sys.exit`.
- `get_params()` parser `description=` string: replace “Embedding Service Async Client Example” with wording centered on **`EmbeddingClient`**.
- Grep file for `tech_spec`, `AsyncClient`, `EmbeddingServiceAsyncClient` → remove.

## Imports (complete list — preserve existing)

```
import argparse
import asyncio
import json
import os
import sys
from typing import Any, Dict

from embed_client.embedding_client import EmbeddingClient
from embed_client.exceptions import EmbedConfigError
from embed_client.config import ClientConfig
from embed_client.client_factory import ClientFactory, create_client
from embed_client.example_async_usage_demo import (
    run_client_examples,
    demonstrate_security_modes,
    demonstrate_automatic_detection,
    demonstrate_with_auth_method,
)
```

## Mandatory validation

```bash
black embed_client/example_async_usage.py
flake8 embed_client/example_async_usage.py
mypy embed_client/example_async_usage.py
pytest -q
```

## Forbidden patterns

- Do not change `get_params()` argument names (CLI compatibility).
- Do not use `Any` in new annotations beyond existing `get_params() -> Any` unless refactoring (avoid).

## LLAMA-readiness — algorithms

**`get_params()`:** no logic change; only update `description=` strings and help text that reference legacy names.
