<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# DN-AT-16 — `embed_client/example_async_usage_demo.py` docstrings

## Executor role

`coder_auto` (Python).

## Execution directive

Expand module and public function docstrings to man-page level: purpose of each `demonstrate_*` and `run_client_examples`, expected console output character, link to parent `example_async_usage.py`. English only. **`EmbeddingClient`** type hints unchanged.

## Parent links

| Document | Path |
|----------|------|
| Global step | `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md` |
| Tactical task | `docs/tech_spec/branches/documentation_normalization/tasks/doc_guides_examples_canonical_mtls.md` |

## Tech spec reference

- `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md`

## Step scope

- **Target file:** `embed_client/example_async_usage_demo.py`
- **Action:** modify

## Dependency contract

- **Depends on:** DN-AT-01

## Read first

1. Full `embed_client/example_async_usage_demo.py`

## Imports

```
from __future__ import annotations

from typing import Any, Dict, List

from embed_client.embedding_client import EmbeddingClient
from embed_client.exceptions import EmbedError
from embed_client.client_factory import ClientFactory, detect_security_mode
from embed_client.response_parsers import extract_embeddings
```

## Class/function skeleton (document only; do not rename)

- `async def run_client_examples(client: EmbeddingClient) -> None`
- Other `async def` / `def` functions: add one-line summary + extended docstring where missing.

## Mandatory validation

```bash
black embed_client/example_async_usage_demo.py
flake8 embed_client/example_async_usage_demo.py
mypy embed_client/example_async_usage_demo.py
pytest -q
```

## Forbidden patterns

- No new `print` statements except if fixing obvious typos in existing print content (avoid).

## Error handling specification

- Docstrings describe existing `except EmbedError` behavior; do not change exception types.
