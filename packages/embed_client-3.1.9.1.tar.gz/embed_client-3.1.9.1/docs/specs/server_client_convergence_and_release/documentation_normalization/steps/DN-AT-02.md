<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# DN-AT-02 — `docs/PROJECT_RULES.md` governance after legacy prune

## Executor role

`coder_auto` (Markdown only).

## Execution directive

Update **LAYOUT-08** and **LAYOUT-09** (and related diagram lines) so they no longer describe `docs/tech_spec/` or `docs/specs/tech_spec/` as active or legacy mirrored program-of-record. State that durable technical specs and plans for the migrated client live under `docs/specs/<specname>/` (with epic `docs/specs/server_client_convergence_and_release/`) and the codebase; remove claims that `docs/specs/tech_spec/` mirrors `docs/tech_spec/` if both were removed in DN-AT-01.

## Parent links

| Document | Path |
|----------|------|
| Global step | `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md` |
| Tactical task | `docs/tech_spec/branches/documentation_normalization/tasks/doc_legacy_tree_prune_and_governance.md` |

## Tech spec reference

- `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md`

## Step scope

- **Target file (repo root relative):** `docs/PROJECT_RULES.md`
- **Action:** modify

## Dependency contract

- **Depends on:** DN-AT-01 complete (deleted trees must not be referenced as existing).

## Required context

- Preserve existing rule IDs (`CR-*`, `LAYOUT-*`, `NAME-*`) and §0 table structure.
- **ARTIFACT_LOCALE:** English for `docs/`.

## Read first

1. `docs/PROJECT_RULES.md` (full file, especially §3 LAYOUT-08 / LAYOUT-09 and any diagram).
2. `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md`
3. `docs/tech_spec/branches/documentation_normalization/tasks/doc_legacy_tree_prune_and_governance.md`

## Expected file change

- Replace paragraphs/table rows that name `docs/tech_spec/` as the legacy spec tree with wording that those duplicate trees were **removed** and canonical file-backed specs are under `docs/specs/<specname>/` per **LAYOUT-09** / **CR-017**.
- Update ASCII tree under LAYOUT-08 if it shows `tech_spec/` as a current subtree — remove or mark as removed.

## Forbidden alternatives

- Do not reintroduce `docs/tech_spec/` as an active destination for new work.
- Do not add Russian prose outside existing bilingual allowances.

## Atomic operations

1. Search within `docs/PROJECT_RULES.md` for `tech_spec`, `specs/tech_spec`, `branches/`.
2. Rewrite **LAYOUT-08** row so `docs/specs/` is the canonical ТЗ container; omit or replace the bullet that lists `docs/tech_spec/` as legacy until migrated.
3. Ensure **LAYOUT-09** remains the authoritative description of `docs/specs/<specname>/` layout; add one explicit sentence that pre-epic duplicate trees under `docs/tech_spec/` and `docs/specs/tech_spec/` were **removed from the repository** as part of documentation normalization (server/client convergence epic).
4. Fix internal links in this file if any pointed to deleted paths.

## Expected deliverables

- Single modified `docs/PROJECT_RULES.md` with no stale authoritative pointers to deleted subtrees.

## Mandatory validation

```bash
# Markdown-only: no Python change required; run full suite for regression:
pytest -q
```

**Expected:** exit code **0**.

## Decision rules

- If a sentence is ambiguous between “historical archive” and “active path”, prefer **removed / not present in repo** per tactical default.

## Blackstops

- Any remaining `docs/tech_spec/` string that implies the folder still exists for new specs → fix before completing.

## Handoff package

- None beyond file diff.

## LLAMA-readiness supplement

| Field | Value |
|-------|--------|
| File header | Preserve existing HTML comment header at top of `docs/PROJECT_RULES.md` (Author/email). |
| Imports | N/A (Markdown) |
| Skeleton | N/A |

**Exact phrases to use (minimum):**  
- Canonical program-of-record for file-backed specs: `docs/specs/<specname>/` per **LAYOUT-09** / **CR-017**; epic example path: `docs/specs/server_client_convergence_and_release/`.

## Forbidden patterns

- Do not edit files other than `docs/PROJECT_RULES.md`.
