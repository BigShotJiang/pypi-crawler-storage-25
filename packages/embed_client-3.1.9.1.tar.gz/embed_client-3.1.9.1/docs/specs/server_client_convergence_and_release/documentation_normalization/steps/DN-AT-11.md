<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# DN-AT-11 — `examples/README.md`

## Executor role

`coder_auto` (Markdown).

## Execution directive

Rewrite `examples/README.md` so the **first** documented example is **`canonical_mtls_localhost_8001.py`** (the full operational tour). Remove **`EmbeddingServiceAsyncClient`** snippets. Add table of other examples with one-line descriptions.

## Parent links

| Document | Path |
|----------|------|
| Global step | `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md` |
| Tactical task | `docs/tech_spec/branches/documentation_normalization/tasks/doc_guides_examples_canonical_mtls.md` |

## Tech spec reference

- `docs/specs/server_client_convergence_and_release/documentation_normalization/spec.md`

## Step scope

- **Target file:** `examples/README.md`
- **Action:** modify

## Dependency contract

- **Depends on:** DN-AT-01

## Read first

1. List `examples/*.py` (directory listing)
2. `examples/canonical_mtls_localhost_8001.py` module docstring (first 70 lines)
3. Current `examples/README.md`

## Expected file change

- H1 or H2: Examples index.
- Section 1: Canonical mTLS — path, env vars **`RUN_CANONICAL_MTLS_E2E`**, **`CANONICAL_EMBED_FILE_SERVER_PATH`** (after DN-AT-19), link to `tests/test_canonical_mtls_example.py`.
- Following sections: remaining scripts.

## Mandatory validation

```bash
pytest -q
```

## Forbidden patterns

- Do not use Russian in this file unless already present and required for parity (tactical: examples README is typically English).
