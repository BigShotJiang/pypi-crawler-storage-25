<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# Atomic steps index — documentation normalization (epic global step)

**Program-of-record:** [`../spec.md`](../spec.md)  
**Parent epic:** [`../../spec.md`](../../spec.md)

## Summary

| Field | Value |
|-------|--------|
| Goal | Execute DN-01–DN-04: prune legacy docs, rewrite root + guides + examples, verify and close. |
| Atomic step count | 22 (`DN-AT-01` … `DN-AT-22`) |
| Dependency chain | See table below |

## Dependency order

1. **DN-AT-01** — legacy tree prune (grep + deletes)  
2. **DN-AT-02**, **DN-AT-03** — depend on **DN-AT-01**  
3. **DN-AT-04**–**DN-AT-07** — depend on **DN-AT-01** (and should not link to removed paths; align with **DN-AT-02** where governance overlaps)  
4. **DN-AT-08**–**DN-AT-18** — depend on **DN-AT-01**; soft dependency on **DN-AT-04** for stable terminology  
5. **DN-AT-19** — canonical mTLS example (`CANONICAL_EMBED_FILE_SERVER_PATH`)  
6. **DN-AT-20** — depends on **DN-AT-19**  
7. **DN-AT-21** — finalize `project_overlay.md`; depends on **DN-AT-03**, **DN-AT-11**, **DN-AT-19**  
8. **DN-AT-22** — closure report (**doc_writer**); depends on **DN-AT-01**–**DN-AT-21** merged

## Parallel waves

| Wave | Steps | Notes |
|------|--------|--------|
| W1 | DN-AT-01 | Must finish before governance and README waves that assume deleted trees. |
| W2 | DN-AT-02, DN-AT-03 | Parallel after W1. |
| W3 | DN-AT-04, DN-AT-05, DN-AT-06, DN-AT-07 | Parallel after W1 (and after W2 if README must not contradict **PROJECT_RULES**). |
| W4 | DN-AT-08, DN-AT-09, DN-AT-10 | Parallel guides. |
| W5 | DN-AT-11, DN-AT-12, DN-AT-13, DN-AT-14 | Examples index + example scripts (parallel). |
| W6 | DN-AT-15, DN-AT-16, DN-AT-17, DN-AT-18 | `embed_client` example modules (parallel). |
| W7 | DN-AT-19 | Single file; after W4–W6 optional for docstring cross-links. |
| W8 | DN-AT-20 | After W7. |
| W9 | DN-AT-21 | After W5 (11), W2 (03), W7 (19). |
| W10 | DN-AT-22 | After DN-01–DN-03 deliverables merged and verification inputs available. |

## Step index

| ID | Target file(s) | Parent tactical | Depends on |
|----|----------------|-----------------|------------|
| DN-AT-01 | Filesystem (deletes) | DN-01 | — |
| DN-AT-02 | `docs/PROJECT_RULES.md` | DN-01 | DN-AT-01 |
| DN-AT-03 | `docs/agents/project_overlay.md` | DN-01 | DN-AT-01 |
| DN-AT-04 | `README.md` | DN-02 | DN-AT-01 |
| DN-AT-05 | `CONFIGURATION.md` | DN-02 | DN-AT-01 |
| DN-AT-06 | `CLI_README.md` | DN-02 | DN-AT-01 |
| DN-AT-07 | `pyproject.toml` | DN-02 | DN-AT-01 |
| DN-AT-08 | `docs/client_integration_guide.md` | DN-03 | DN-AT-01 |
| DN-AT-09 | `docs/api_format.md` | DN-03 | DN-AT-01 |
| DN-AT-10 | `docs/SERVER_MODES_AND_CLIENT.md` | DN-03 | DN-AT-01 |
| DN-AT-11 | `examples/README.md` | DN-03 | DN-AT-01 |
| DN-AT-12 | `examples/async_testing_client_example.py` | DN-03 | DN-AT-01 |
| DN-AT-13 | `examples/security_examples.py` | DN-03 | DN-AT-01 |
| DN-AT-14 | `examples/security_examples_ru.py` | DN-03 | DN-AT-01 |
| DN-AT-15 | `embed_client/example_async_usage.py` | DN-03 | DN-AT-01 |
| DN-AT-16 | `embed_client/example_async_usage_demo.py` | DN-03 | DN-AT-01 |
| DN-AT-17 | `embed_client/example_async_usage_ru.py` | DN-03 | DN-AT-01 |
| DN-AT-18 | `embed_client/example_async_usage_ru_demo.py` | DN-03 | DN-AT-01 |
| DN-AT-19 | `examples/canonical_mtls_localhost_8001.py` | DN-03 | DN-AT-01 |
| DN-AT-20 | `tests/test_canonical_mtls_example.py` | DN-03 | DN-AT-19 |
| DN-AT-21 | `docs/agents/project_overlay.md` | DN-03 | DN-AT-03, DN-AT-11, DN-AT-19 |
| DN-AT-22 | `docs/ai_reports/documentation_normalization_closure_report.md` | DN-04 | DN-AT-01 … DN-AT-21 |

## Step files

All step definitions live alongside this index:

- [`DN-AT-01.md`](DN-AT-01.md) … [`DN-AT-22.md`](DN-AT-22.md)
