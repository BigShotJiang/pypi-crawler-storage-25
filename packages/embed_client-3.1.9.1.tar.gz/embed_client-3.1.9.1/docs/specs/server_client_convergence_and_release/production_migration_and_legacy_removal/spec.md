<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# Production migration and legacy removal

## Goal

Replace the current production implementation with the server-internal client architecture and remove superseded legacy production code, compatibility paths, and dead modules from this repository.

## In scope

- Port the canonical client implementation from `../embed` into this repository.
- Align runtime code, package exports, CLIs, and configuration handling with the migrated implementation.
- Remove old production code that no longer belongs in the repository after migration.

## Out of scope

- Long-form end-user documentation and PyPI publication mechanics, except for implementation facts required by those branches.

## Exit criteria

- The runtime package reflects the migrated canonical implementation.
- No obsolete production code or compatibility layer remains for removed behavior.
- The branch hands off final implementation facts needed for tests, docs, and release validation.
