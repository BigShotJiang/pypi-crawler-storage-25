<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# Atomic steps index — canonical client migration

**Executor:** `coder_auto` (per step files).

## Parent documents

| Role | Path |
|------|------|
| Epic / root ТЗ | [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md) |
| Global step | [`docs/specs/server_client_convergence_and_release/production_migration_and_legacy_removal/spec.md`](../spec.md) |
| Tactical task | [`docs/specs/server_client_convergence_and_release/production_migration_and_legacy_removal/canonical_client_migration/spec.md`](./spec.md) |

## Tactical goal (summary)

Single canonical runtime **`EmbeddingClient`** (direct `JsonRpcClient`), ported from `../embed` into `embed_client.*`, legacy surfaces removed, `__version__` aligned with `pyproject.toml`, minimal entry points rewired. No backward compatibility.

## Dependency order (strict)

1. [`atomic-01-port-constants-and-exceptions.md`](./atomic-01-port-constants-and-exceptions.md)
2. [`atomic-02-port-embedding-client-helpers-and-status-store.md`](./atomic-02-port-embedding-client-helpers-and-status-store.md)
3. [`atomic-03-port-embedding-client-core.md`](./atomic-03-port-embedding-client-core.md)
4. [`atomic-04-package-init-version-and-canonical-exports.md`](./atomic-04-package-init-version-and-canonical-exports.md)
5. [`atomic-05-remove-legacy-async-stack-and-adapter-transport.md`](./atomic-05-remove-legacy-async-stack-and-adapter-transport.md)
6. [`atomic-06-remove-testing-client-and-duplicate-helpers.md`](./atomic-06-remove-testing-client-and-duplicate-helpers.md)
7. [`atomic-07-rewire-cli-factory-and-minimal-entry-points.md`](./atomic-07-rewire-cli-factory-and-minimal-entry-points.md)

## Steps ↔ primary targets

| ID | Slug | Primary deliverables |
|----|------|----------------------|
| 01 | port-constants-and-exceptions | `embed_client/constants.py`, `embed_client/exceptions.py` + call-site renames in-repo |
| 02 | port-embedding-client-helpers-and-status-store | `embed_client/embedding_client_helpers.py`, `embed_client/embed_file_status_store.py` |
| 03 | port-embedding-client-core | `embed_client/embedding_client.py` |
| 04 | package-init-version-and-canonical-exports | `embed_client/__init__.py` |
| 05 | remove-legacy-async-stack-and-adapter-transport | delete/replace: async client + mixins + adapter transport stack (see step) |
| 06 | remove-testing-client-and-duplicate-helpers | `testing_client.py`, `testing_client_helpers.py` removed; exports cleaned |
| 07 | rewire-cli-factory-and-minimal-entry-points | `cli.py`, `cli_core.py`, `client_factory.py`, `__main__.py`, related helpers as needed |

## Notes

- **Do not port** `embed/client/service_manager_health.py` in this tactical branch (tactical spec; `httpx` follow-up).
- Full test-suite overhaul is out of scope for the epic branch `tests_scripts_and_dependency_cleanup`; each step still requires **all tests pass** after minimal fixes required for touched code (tactical `spec.md`).
