<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# Atomic 05 — Remove legacy async client stack and AdapterTransport

**Executor:** `coder_auto`

## Parent links

- Epic / root ТЗ: [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md)
- Global step: [`docs/specs/server_client_convergence_and_release/production_migration_and_legacy_removal/spec.md`](../spec.md)
- Tactical task: [`docs/specs/server_client_convergence_and_release/production_migration_and_legacy_removal/canonical_client_migration/spec.md`](./spec.md)

## Intent

**(C)** Remove **`EmbeddingServiceAsyncClient`**, the mixin stack that exists only to implement it, **`AdapterTransport`** and adapter-only indirection superseded by direct **`JsonRpcClient`** via **`EmbeddingClient`**, and related bridge/normalizer modules so there is **no parallel transport layer** for the same RPCs (tactical locked decisions). Satisfies acceptance criterion: **`AdapterTransport.queue_get_job_status`** removed (no alignment patch needed once port is sole path).

## Scope

- **Delete** (or reduce to zero lines with file removal — prefer **delete files**) at minimum:
  - `embed_client/async_client.py` — **`EmbeddingServiceAsyncClient`**
  - `embed_client/async_client_api_mixin.py`
  - `embed_client/async_client_queue_mixin.py`
  - `embed_client/async_client_config_mixin.py`
  - `embed_client/async_client_factory_mixin.py`
  - `embed_client/async_client_lifecycle_mixin.py`
  - `embed_client/async_client_introspection_mixin.py`
  - `embed_client/async_client_response_mixin.py`
  - `embed_client/adapter_transport.py` — **`AdapterTransport`**
  - `embed_client/adapter_config_factory.py`
  - `embed_client/adapter_config_normalizer.py`
  - `embed_client/adapter_generator_bridge.py`
- **In scope:** Remove any remaining imports of deleted modules across **`embed_client/`** (production package only in this step; tests/scripts **minimal** fix per tactical).
- **In scope:** If `identifier_types.py`, `response_normalizer.py`, `response_parsers.py` are **only** used by deleted code, delete them or fold minimal needed pieces into remaining modules — **material decision:** keep a file **only** if **`EmbeddingClient`** port or remaining config/CLI still imports it; otherwise delete.
- **Out of scope:** `testing_client.py` / `testing_client_helpers.py` (atomic 06); CLI/factory (atomic 07).

## Read first

- Tactical `spec.md` (legacy removal list).
- [`docs/ai_reports/production_migration_code_research.md`](../../../../ai_reports/production_migration_code_research.md) §2.2–2.4, §3, §4.
- Grep for `async_client`, `AdapterTransport`, `adapter_` across repo after deletion list is fixed.

## Expected change

1. Delete the listed modules; fix all broken imports in `embed_client/` to point to **`EmbeddingClient`** / helpers / config modules that remain.
2. Ensure no import cycle and no dead `__init__.py` exports referencing deleted symbols.

## Forbidden alternatives

- No stub files that re-export old class names.
- No keeping **`AdapterTransport`** “for tests” — tests migrate to canonical client or are minimally adjusted.

## Validation

- **CR-007** on touched paths.
- **All tests pass** (minimal test updates for removed symbols).

## Dependencies

- **Depends on:** [`atomic-04-package-init-version-and-canonical-exports.md`](./atomic-04-package-init-version-and-canonical-exports.md).

## Definition of done

- No **`EmbeddingServiceAsyncClient`** implementation in tree; no **`AdapterTransport`**; mixin stack for old async client **gone**.
- **All tests pass.**
