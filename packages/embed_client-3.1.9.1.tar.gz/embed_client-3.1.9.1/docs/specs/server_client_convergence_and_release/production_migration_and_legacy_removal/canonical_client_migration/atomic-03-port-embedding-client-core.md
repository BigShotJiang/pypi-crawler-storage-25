<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# Atomic 03 — Port EmbeddingClient core module

**Executor:** `coder_auto`

## Parent links

- Epic / root ТЗ: [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md)
- Global step: [`docs/specs/server_client_convergence_and_release/production_migration_and_legacy_removal/spec.md`](../spec.md)
- Tactical task: [`docs/specs/server_client_convergence_and_release/production_migration_and_legacy_removal/canonical_client_migration/spec.md`](./spec.md)

## Intent

Port **`EmbeddingClient`** from the server tree into this repository as **`embed_client.embedding_client`** (single module path: **`embed_client/embedding_client.py`**) with **direct `JsonRpcClient`** construction (`self.client = JsonRpcClient(...)`) and **no `AdapterTransport`**. This satisfies tactical goals **(A)** port, **(D)** contract alignment: server **`job_status`** order (**`queue_get_job_status` before `embed_job_status`**) and **`wait_for_job`** **WebSocket-first** when `JsonRpcClient.wait_for_job` exists — by preserving server implementation semantics from [`docs/ai_reports/production_migration_code_research.md`](../../../../ai_reports/production_migration_code_research.md) §3.

## Scope

- **Primary file:** `embed_client/embedding_client.py` (ported from `../embed/embed/client/embedding_client.py`).
- **In scope:** Rewrite imports: `embed_client.constants`, `embed_client.exceptions`, `embed_client.embedding_client_helpers`, `embed_client.embed_file_status_store`, and **`JsonRpcClient`** (and any adapter types) from the **same dependency entrypoints** already used by this repo — resolve via `pyproject.toml` and existing `embed_client` usage patterns.
- **In scope:** Port private helpers at module level as on server (`_client_has_async_method`, `_uses_adapter_job_message_registry`, `_normalize_terminal_job_payload`, etc.) so behavior matches server.
- **Out of scope:** `service_manager_health.py` (not ported per tactical). If the server file imports it, remove or gate that integration in the port **without** adding an `httpx` dependency (tactical: track follow-up).
- **Out of scope:** `__init__.py` public exports (atomic 04); deleting `async_client` / `AdapterTransport` (atomics 05–06).

## Read first

- Tactical `spec.md` (parity: full server method set including **`embed_file`**, job status, wait semantics).
- [`docs/ai_reports/production_migration_code_research.md`](../../../../ai_reports/production_migration_code_research.md) §1 (public API list), §3 (contract fixes), §6.1–6.2.
- **Atomic 01–02** outputs.
- `../embed/embed/client/embedding_client.py` (full read).

## Expected change

1. Add `embed_client/embedding_client.py` with class **`EmbeddingClient`** and the server’s public instance API (non-private methods per research §1).
2. Ensure **`job_status`** and **`wait_for_job`** match server behavior (no inversion vs current `adapter_transport` / `async_client_queue_mixin` — those are superseded by this port).
3. No `embed.` package imports.

## Forbidden alternatives

- Do not reintroduce **`AdapterTransport`** inside this module.
- Do not implement an alternate job-status precedence “to match old clients.”

## Validation

- **CR-007** on `embed_client/embedding_client.py` and any small glue edited to satisfy imports.
- **All tests pass** (may still exercise old entry points until atomic 04+; if tests import only legacy client, minimal package-level fixes only if required to avoid import errors — prefer leaving tests to later atomics unless broken by this file’s addition).

## Dependencies

- **Depends on:** [`atomic-02-port-embedding-client-helpers-and-status-store.md`](./atomic-02-port-embedding-client-helpers-and-status-store.md).

## Definition of done

- `from embed_client.embedding_client import EmbeddingClient` works; class behavior matches server baseline for locked contracts (§3).
- **All tests pass.**
