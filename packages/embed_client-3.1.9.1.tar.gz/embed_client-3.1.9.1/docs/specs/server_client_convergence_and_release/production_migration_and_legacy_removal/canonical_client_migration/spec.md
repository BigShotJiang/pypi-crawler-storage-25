<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# Canonical client migration (tactical)

## Parent links

- Epic: [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md)
- Global plan: [`docs/specs/server_client_convergence_and_release/plan.md`](../../plan.md)
- Global step: [`docs/specs/server_client_convergence_and_release/production_migration_and_legacy_removal/spec.md`](../spec.md)
- Baseline tactical: [`docs/specs/server_client_convergence_and_release/baseline_audit_and_contract_capture/migration_baseline_deliverable/spec.md`](../../baseline_audit_and_contract_capture/migration_baseline_deliverable/spec.md)

## Evidence (do not re-derive architecture)

- Code: [`docs/ai_reports/baseline_audit_code_research.md`](../../../../ai_reports/baseline_audit_code_research.md), [`docs/ai_reports/production_migration_code_research.md`](../../../../ai_reports/production_migration_code_research.md)
- Docs inventory (handoff only): [`docs/ai_reports/production_migration_doc_research.md`](../../../../ai_reports/production_migration_doc_research.md)

## Goal

Replace the production `embed_client` implementation with the server-internal client architecture from `../embed`, using **`EmbeddingClient`** (direct `JsonRpcClient`) as the single canonical runtime class. **Backward compatibility is forbidden.** Prefer **deletion** over shims, aliases, or dual surfaces.

## Locked decisions (non-negotiable)

- **Source of truth:** `../embed` paths: `embed/client/embedding_client.py`, `embedding_client_helpers.py`, `embed_file_status_store.py`, `embed/constants.py`, `embed/exceptions.py` — port into this package with **`embed_client.*` imports** (no `embed.*` compatibility layer).
- **Server wins on contracts:** `job_status` / queue polling tries **`queue_get_job_status` before `embed_job_status`**; **`wait_for_job`** uses **WebSocket-first** when `JsonRpcClient.wait_for_job` exists, else poll helpers.
- **Parity:** `embed_file` and related server behavior must exist on the migrated public client where the server exposes them (no reduced “async-only” subset unless explicitly scoped out here — **not** scoped out; full server method set for `EmbeddingClient` public API).
- **Legacy removal:** Remove `EmbeddingServiceAsyncClient`, mixin stack used only by it, `EmbeddingServiceClient` / `TestingEmbeddingClient` in `testing_client.py`, and duplicate `testing_client_helpers` once server helpers are the single implementation. Remove **`AdapterTransport`** and related adapter-only indirection **if** the canonical path is direct `JsonRpcClient` only — **no parallel transport layer** for the same RPCs.
- **Out of scope for this tactical step:** Long-form README/CONFIG rewrites (Wave `documentation_normalization`); PyPI publish. **In scope:** align `__version__` with `pyproject.toml` (single source of truth).
- **Do not port** `embed/client/service_manager_health.py` in this branch (requires `httpx` — track as follow-up in handoff if anything still needed).

## Boundaries

- **Writes:** This repository only; **reading** `../embed` for copy/adapt is approved.
- **Tests/scripts/examples:** May be left broken or minimally adjusted only if required to land the production package; full test-suite rewrite is **`tests_scripts_and_dependency_cleanup`** — coder should not expand scope beyond what is necessary for import coherence and **`tester_auto`** gate on touched code.

## Acceptance criteria

1. Package runtime implements **`EmbeddingClient`** (or module path agreed in atomics) with the same **public** methods as the server class for embedding service use (including **`embed_file`**, job status, wait semantics per locked order).
2. **`embed_client/__init__.py`** exports the canonical names required for a single client story (no `EmbeddingServiceAsyncClient` as primary; remove deprecated aliases).
3. Legacy production modules listed in evidence reports as superseded are **removed** or reduced to non-imported dead code **zero** — no duplicate client classes.
4. **`AdapterTransport.queue_get_job_status`** either **removed** or **aligned** — if any code path remains, it must match server precedence (prefer port so mixin deletion is complete).
5. Version: **`embed_client.__version__`** matches **`pyproject.toml`** `[project].version`.
6. Atomic step files exist under this tactical folder per **LAYOUT-09**; **`planner_auto`** materialized them.

## Handoff for downstream branches

Materialize in completion report (and optional `docs/ai_reports/` if too large):

- Final public export list and primary class name(s).
- Removed file/module list.
- Dependency deltas for **`tests_scripts_and_dependency_cleanup`** (e.g. unused `PyJWT` / `cryptography` — not necessarily edited here).
- Doc paths still describing the old client (from `production_migration_doc_research.md`).

## Atomic steps

Delegated to **`planner_auto`**. Atomics live beside this file: `docs/specs/server_client_convergence_and_release/production_migration_and_legacy_removal/canonical_client_migration/<atomic_step_slug>.md` per **LAYOUT-09**.
