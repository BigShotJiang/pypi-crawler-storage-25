<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# Atomic 02 — Port embedding client helpers and embed file status store

**Executor:** `coder_auto`

## Parent links

- Epic / root ТЗ: [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md)
- Global step: [`docs/specs/server_client_convergence_and_release/production_migration_and_legacy_removal/spec.md`](../spec.md)
- Tactical task: [`docs/specs/server_client_convergence_and_release/production_migration_and_legacy_removal/canonical_client_migration/spec.md`](./spec.md)

## Intent

Add the server modules **`embedding_client_helpers`** and **`embed_file_status_store`** into this package as first-class modules with **`embed_client.*`** imports, replacing the need for duplicate helper logic later.

## Scope

- **Primary files (new or replace):**
  - `embed_client/embedding_client_helpers.py` — from `../embed/embed/client/embedding_client_helpers.py`
  - `embed_client/embed_file_status_store.py` — from `../embed/embed/client/embed_file_status_store.py`
- **In scope:** Rewrite imports to `embed_client.constants`, `embed_client.exceptions`, and any other `embed_client` modules per ported content.
- **Out of scope:** Deleting `testing_client_helpers.py` (atomic 06); wiring `EmbeddingClient` (atomic 03).

## Read first

- Tactical `spec.md` (locked decisions).
- [`docs/ai_reports/production_migration_code_research.md`](../../../../ai_reports/production_migration_code_research.md) §1 (symbols tables), §4 (duplicate helpers).
- Completed **atomic 01** outputs: `embed_client/constants.py`, `embed_client/exceptions.py`.
- Server sources: `../embed/embed/client/embedding_client_helpers.py`, `../embed/embed/client/embed_file_status_store.py`.

## Expected change

1. Port both modules; preserve public API: **`wait_for_job_poll`**, **`list_commands_via_client`**; **`EmbedFileJobStatusStore`** with `record_submit`, `record_message`, `snapshot`, `messages`, `clear`, `job_ids`.
2. Ensure no `embed.` imports remain in these files.

## Forbidden alternatives

- Do not keep a parallel copy of the same helpers under another module name after this step completes the port (single implementation path).

## Validation

- **CR-007** on touched paths.
- **All tests pass** (minimal fixes if imports break only where this step requires).

## Dependencies

- **Depends on:** [`atomic-01-port-constants-and-exceptions.md`](./atomic-01-port-constants-and-exceptions.md).

## Definition of done

- Both modules exist under `embed_client/`, importable, and use only `embed_client.*` dependencies.
- **All tests pass.**
