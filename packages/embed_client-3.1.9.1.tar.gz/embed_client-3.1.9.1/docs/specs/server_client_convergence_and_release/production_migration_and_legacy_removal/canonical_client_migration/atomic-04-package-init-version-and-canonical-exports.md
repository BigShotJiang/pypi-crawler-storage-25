<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# Atomic 04 — Package `__init__`: version sync and canonical exports

**Executor:** `coder_auto`

## Parent links

- Epic / root ТЗ: [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md)
- Global step: [`docs/specs/server_client_convergence_and_release/production_migration_and_legacy_removal/spec.md`](../spec.md)
- Tactical task: [`docs/specs/server_client_convergence_and_release/production_migration_and_legacy_removal/canonical_client_migration/spec.md`](./spec.md)

## Intent

**(B)** Export **`EmbeddingClient`** as the **canonical** public client; **(E)** set **`embed_client.__version__`** to match **`pyproject.toml`** `[project].version` (single source of truth: version string must equal published package version — e.g. align literal or derive via `importlib.metadata.version("embed-client")` if project convention allows). Remove **`EmbeddingServiceAsyncClient`** and other legacy client classes from **primary** public exports per tactical “no duplicate client classes.”

## Scope

- **Primary file:** `embed_client/__init__.py`.
- **Secondary (read-only alignment):** `pyproject.toml` `[project] version` — **do not** bump version in this step unless tactical/release task says so; **only** align `__version__` to the current `pyproject` value.
- **In scope:** Export list: must include **`EmbeddingClient`** and supporting names still required after migration (config/auth/ssl/factory only if still part of the single-client story — trim dead exports).
- **In scope:** Remove or stop exporting **`EmbeddingServiceAsyncClient`**, **`EmbeddingServiceClient`**, **`TestingEmbeddingClient`** as part of public surface (complete removal of modules is atomic 05–06; this step adjusts **`__all__`** / imports so the story is canonical).
- **Out of scope:** Deleting implementation files (05–06).

## Read first

- Tactical `spec.md` (acceptance criteria 2, 5).
- [`docs/ai_reports/production_migration_code_research.md`](../../../../ai_reports/production_migration_code_research.md) §2.1, §5.
- Current `embed_client/__init__.py` and **`atomic 03`** module path.

## Expected change

1. **`__version__`:** Match `pyproject.toml` exactly (research noted drift `3.1.7.25` vs `3.1.7.28` — fix to current project version).
2. **Exports:** Export **`EmbeddingClient`** from `embed_client.embedding_client`; export **`wait_for_job_poll`** / **`list_commands_via_client`** from `embed_client.embedding_client_helpers` if they remain part of the public API (server parity). Drop **`EmbeddingServiceAsyncClient`**, **`EmbeddingServiceClient`**, and **`TestingEmbeddingClient`** from public exports. If dropping top-level names breaks **`tests/`** or **`scripts/`** before legacy modules are deleted in atomic 05, apply **minimal** import rewrites there (submodule imports or direct `EmbeddingClient`) so the suite stays green — tactical task allows this; full test rewrite stays epic step `tests_scripts_and_dependency_cleanup`.

## Forbidden alternatives

- No `EmbeddingServiceAsyncClient = EmbeddingClient` alias.
- No leaving `__version__` out of sync with `pyproject.toml`.

## Validation

- **CR-007** on `embed_client/__init__.py`.
- **All tests pass.**

## Dependencies

- **Depends on:** [`atomic-03-port-embedding-client-core.md`](./atomic-03-port-embedding-client-core.md).

## Definition of done

- **`embed_client.__version__`** equals **`[project].version`** in `pyproject.toml`.
- **`EmbeddingClient`** is the documented canonical import from `embed_client`; legacy client names are not primary exports.
- **All tests pass.**
