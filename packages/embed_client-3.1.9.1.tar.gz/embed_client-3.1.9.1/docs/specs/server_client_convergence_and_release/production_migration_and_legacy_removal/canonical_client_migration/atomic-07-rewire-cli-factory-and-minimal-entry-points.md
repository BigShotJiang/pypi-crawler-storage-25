<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# Atomic 07 — Rewire CLI, factory, and minimal entry points to EmbeddingClient

**Executor:** `coder_auto`

## Parent links

- Epic / root ТЗ: [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md)
- Global step: [`docs/specs/server_client_convergence_and_release/production_migration_and_legacy_removal/spec.md`](../spec.md)
- Tactical task: [`docs/specs/server_client_convergence_and_release/production_migration_and_legacy_removal/canonical_client_migration/spec.md`](./spec.md)

## Intent

**(F)** Rewire **minimal entry points** — CLI modules, **`ClientFactory`** / **`client_factory.py`** (and **`client_factory_helpers.py`** if needed), **`__main__.py`**, **`cli_core.py`**, security CLIs if they construct the old client — so they build and use **`EmbeddingClient`** with **`JsonRpcClient`**-compatible kwargs per server pattern (research §2.3–2.4: kwargs to **`EmbeddingClient`**; factory may shrink to config→constructor mapping).

## Scope

- **Primary files (edit as needed — not all may require changes):**
  - `embed_client/cli.py`
  - `embed_client/cli_core.py`
  - `embed_client/client_factory.py`
  - `embed_client/client_factory_helpers.py`
  - `embed_client/__main__.py`
  - `embed_client/security_cli.py`, `embed_client/security_cli_core.py`, `embed_client/demo_cli.py`, `embed_client/config_generator_cli.py`, `embed_client/config_validator_cli.py` — **only if** they instantiate the removed client classes
- **In scope:** Replace construction of **`EmbeddingServiceAsyncClient`** / **`AdapterTransport`** / **`EmbeddingServiceClient`** with **`EmbeddingClient`** (import from `embed_client.embedding_client`).
- **In scope:** Remove dead code paths that only served adapter generator / adapter config factory if modules were deleted in atomic 05.
- **Out of scope:** README/CONFIG long-form docs; PyPI; broad example rewrites (tactical).

## Read first

- Tactical `spec.md` (boundaries, handoff).
- [`docs/ai_reports/production_migration_code_research.md`](../../../../ai_reports/production_migration_code_research.md) §2.4 (factory evaluate).
- `embed_client/embedding_client.py` constructor signature and `ClientConfig` / config modules still in use.
- Completed **atomics 01–06**.

## Expected change

1. Every **documented** CLI and factory entry path that created the legacy client must create **`EmbeddingClient`** (or delegate to a single small factory function that does).
2. `python -m embed_client` (or project’s documented invocation) remains functional for the supported workflows **or** fails with a clear error if a removed subcommand depended on deleted code — **material:** prefer **working** happy path for at least one config flow matching project norms.

## Forbidden alternatives

- No reintroduction of **`AdapterTransport`** in factories “for compatibility.”

## Validation

- **CR-007** on all edited files.
- Run **pytest** full suite.
- If project documents a **smoke** script for CLI, run it; otherwise at least **import** and **instantiation** test path for factory/CLI (add minimal test only if needed and within tactical scope).

## Dependencies

- **Depends on:** [`atomic-06-remove-testing-client-and-duplicate-helpers.md`](./atomic-06-remove-testing-client-and-duplicate-helpers.md).

## Definition of done

- No production code path constructs **`EmbeddingServiceAsyncClient`** or **`AdapterTransport`**.
- CLI/factory/`__main__` aligned with **`EmbeddingClient`**.
- **All tests pass.**
