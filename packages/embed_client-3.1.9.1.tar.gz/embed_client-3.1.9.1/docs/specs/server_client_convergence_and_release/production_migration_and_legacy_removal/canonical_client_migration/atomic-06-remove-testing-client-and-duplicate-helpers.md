<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# Atomic 06 — Remove testing client surfaces and duplicate helpers

**Executor:** `coder_auto`

## Parent links

- Epic / root ТЗ: [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md)
- Global step: [`docs/specs/server_client_convergence_and_release/production_migration_and_legacy_removal/spec.md`](../spec.md)
- Tactical task: [`docs/specs/server_client_convergence_and_release/production_migration_and_legacy_removal/canonical_client_migration/spec.md`](./spec.md)

## Intent

**(C)** Remove **`EmbeddingServiceClient`**, **`TestingEmbeddingClient`** alias path, and **`testing_client_helpers.py`** duplicate of server **`embedding_client_helpers`** so a single helper implementation remains (`embed_client/embedding_client_helpers.py` from atomic 02).

## Scope

- **Delete:** `embed_client/testing_client.py`, `embed_client/testing_client_helpers.py`.
- **In scope:** Remove any package exports and internal imports referencing these modules (`__init__.py` if not already clean, `example_*.py`, `client_factory.py`, etc. — fix in **atomic 07** if primarily CLI/factory; this step must leave **no import** of deleted modules from remaining production files).
- **In scope:** Minimal grep-driven fixes under `tests/`, `scripts/`, `examples/` only where required so **tests pass** (full rewrite deferred to `tests_scripts_and_dependency_cleanup` epic step).

## Read first

- Tactical `spec.md` (legacy removal).
- [`docs/ai_reports/production_migration_code_research.md`](../../../../ai_reports/production_migration_code_research.md) §4 (table).
- **Atomic 05** state (no legacy async stack).

## Expected change

1. Delete both files.
2. Update any remaining `embed_client` production modules that imported them to use **`EmbeddingClient`** or **`embedding_client_helpers`** only.

## Forbidden alternatives

- No renaming **`EmbeddingServiceClient`** to **`EmbeddingClient`** in a thin wrapper file — delete the parallel surface.

## Validation

- **CR-007** on touched paths.
- **All tests pass.**

## Dependencies

- **Depends on:** [`atomic-05-remove-legacy-async-stack-and-adapter-transport.md`](./atomic-05-remove-legacy-async-stack-and-adapter-transport.md).

## Definition of done

- `testing_client.py` and `testing_client_helpers.py` **absent**; no duplicate **`wait_for_job_poll`** / **`list_commands_via_client`** module.
- **All tests pass.**
