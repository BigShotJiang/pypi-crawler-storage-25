<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# Atomic 01 — Port constants and exceptions (server names)

**Executor:** `coder_auto`

## Parent links

- Epic / root ТЗ: [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md)
- Global step: [`docs/specs/server_client_convergence_and_release/production_migration_and_legacy_removal/spec.md`](../spec.md)
- Tactical task: [`docs/specs/server_client_convergence_and_release/production_migration_and_legacy_removal/canonical_client_migration/spec.md`](./spec.md)

## Intent

Align `embed_client` **constants** and **exceptions** with the server baseline (`../embed/embed/constants.py`, `../embed/embed/exceptions.py`) so downstream ported modules use **`embed_client.*`** imports and **server symbol names** (no `embed.*` compatibility layer). Resolves naming drift called out in [`docs/ai_reports/production_migration_code_research.md`](../../../../ai_reports/production_migration_code_research.md) (§6.3).

## Scope

- **Primary files:** `embed_client/constants.py`, `embed_client/exceptions.py`.
- **In scope:** Replace or merge content so public symbols match server semantics and names required for `EmbeddingClient` port (e.g. `EMBED_COMMAND_SCHEMA_DEFAULT_ERROR_POLICY`, `EmbedClientError`, `EmbedQueueError`, etc. per research table).
- **In scope:** Update **all in-package references** under `embed_client/` that still use old symbol names (`EMBED_DEFAULT_ERROR_POLICY`, `EmbeddingServiceError`, etc.) so the package remains import-coherent after this step.
- **Out of scope:** Porting `embedding_client.py` (atomic 03); deleting legacy client modules (later atomics).

## Read first

- Tactical `spec.md` (locked decisions, boundaries).
- [`docs/ai_reports/production_migration_code_research.md`](../../../../ai_reports/production_migration_code_research.md) §6.1, §6.3.
- Current `embed_client/constants.py`, `embed_client/exceptions.py` and ripgrep for symbols being renamed.
- Server sources (read-only): `../embed/embed/constants.py`, `../embed/embed/exceptions.py`.

## Expected change

1. Port/adapt server constants and exceptions into the two primary files, rewriting imports to **`embed_client.…`** only.
2. Propagate renames through **`embed_client/`** Python modules that reference the old names (minimal set to keep imports working; do not rewrite tests/scripts beyond what tactical task allows unless required for green tests).

## Forbidden alternatives

- No `embed.*` shim package or namespace compatibility layer.
- No leaving duplicate exception classes with old names “for compatibility” (backward compatibility is forbidden).

## Validation

- **CR-007:** Run project linters/formatters/typecheckers on touched paths.
- Run **full** `pytest` (or project-documented test entrypoint); fix only what this step’s edits require.

## Dependencies

- **None** (first step in chain).

## Definition of done

- `embed_client.constants` / `embed_client.exceptions` match the tactical requirement: server-aligned names for the canonical migration path.
- No remaining **in-package** references to removed/renamed symbols without an intentional re-export (there should be none per “no backward compat”).
- **All tests pass.**
