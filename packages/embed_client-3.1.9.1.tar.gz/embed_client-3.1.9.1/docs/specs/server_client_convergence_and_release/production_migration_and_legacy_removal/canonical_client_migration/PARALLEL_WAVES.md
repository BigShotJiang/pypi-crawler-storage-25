<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# Parallel waves — canonical client migration

**Parent:** [`spec.md`](./spec.md) · Epic: [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md)

## Rule

Steps in the **same wave** may run in parallel only if they touch **disjoint primary target files** and have **no dependency** on each other. This tactical task is **sequential by design**: each step builds on or removes code that prior steps introduced.

## Waves

| Wave | Atomic steps | Parallel? |
|------|----------------|------------|
| 1 | `atomic-01` | Single step only |
| 2 | `atomic-02` | Depends on 01 — **no** parallel with 01 |
| 3 | `atomic-03` | Depends on 02 |
| 4 | `atomic-04` | Depends on 03 |
| 5 | `atomic-05` | Depends on 04 |
| 6 | `atomic-06` | Depends on 05 |
| 7 | `atomic-07` | Depends on 06 |

**Conclusion:** **No parallel execution** of distinct atomic steps within this tactical folder; run **01 → 07** in order. Parallelism across **other** tactical tasks or repos is out of scope here.
