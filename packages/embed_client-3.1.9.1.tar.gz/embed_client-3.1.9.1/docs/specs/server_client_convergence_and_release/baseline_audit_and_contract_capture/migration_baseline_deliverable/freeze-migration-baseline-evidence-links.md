<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# MB-1 — Freeze migration baseline evidence (parent links and citation alignment)

## Executor role

`doc_writer` (documentation-only; no production, test, or script code).

## Parent links (mandatory)

| Document | Path |
|----------|------|
| Epic (root ТЗ) | [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md) |
| Global step | [`docs/specs/server_client_convergence_and_release/baseline_audit_and_contract_capture/spec.md`](../spec.md) |
| Tactical task | [`docs/specs/server_client_convergence_and_release/baseline_audit_and_contract_capture/migration_baseline_deliverable/spec.md`](./spec.md) |

**Root specification reference:** [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md).

## Step scope

Finalize **citation alignment** for the migration baseline so downstream branches can cite the tactical task and the two AI reports without ambiguity. Edits are limited to the two evidence markdown files listed below—no other paths.

## Primary target files (full repository-relative paths)

1. `docs/ai_reports/baseline_audit_code_research.md`
2. `docs/ai_reports/baseline_audit_doc_research.md`

## Read first

- [`docs/specs/server_client_convergence_and_release/baseline_audit_and_contract_capture/migration_baseline_deliverable/spec.md`](./spec.md) — especially **Evidence deliverables**, **Decisions locked for downstream**, and **Acceptance criteria**.
- Both target files in full (or the sections you will touch).

## Expected change

1. **Baseline freeze block** — Near the top of each target file (after the title or existing front matter), add a short subsection (e.g. “Migration baseline — authoritative links”) that includes:
   - Relative links to the **tactical task** spec and the **global step** spec (and epic if not already present).
   - One sentence stating that this file is **evidence** for `migration_baseline_deliverable` and that locked decisions are listed in the tactical spec.
2. **Locked decisions** — Ensure the four numbered decisions in the tactical spec (canonical implementation paths, server-wins contract notes, runtime dependency verdict, documentation posture) are either explicitly summarized with pointers to report sections or clearly cross-referenced so a reader can verify consistency without re-deriving architecture.
3. **Do not** edit production code, tests, `pyproject.toml`, or specs outside the two `docs/ai_reports/` targets. **Do not** change global `plan.md` or the epic spec.

## Forbidden alternatives

- Opening a `coder_auto` PR for implementation work (out of scope for this tactical task).
- Duplicating large bodies of the tactical spec into the reports; prefer links plus minimal alignment text.

## Validation

- Diff review: only the two `docs/ai_reports/` files changed.
- Manual read-through: tactical **Acceptance criteria** satisfied (reports internally consistent with the tactical spec; downstream can cite tactical spec + both reports).
- **Tests:** No application code changes; run the project’s standard test command per **`docs/PROJECT_RULES.md`** (venv, linters where applicable). **All tests must pass** (result should match a clean baseline—documentation-only edits must not affect test outcomes).

## Dependencies

None.

## Definition of done

- Both evidence files carry explicit backlinks to the tactical task (and global step / epic as appropriate).
- Locked decisions are cross-verifiable against the tactical spec without contradiction.
- Validation commands completed; **all tests pass**.
