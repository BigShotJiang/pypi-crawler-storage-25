<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# Migration baseline deliverable (tactical)

## Parent links

- Epic: [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md)
- Global step: [`docs/specs/server_client_convergence_and_release/baseline_audit_and_contract_capture/spec.md`](../spec.md)

## Goal

Materialize a **migration baseline** for downstream global steps by combining code and documentation research on `embed-client` vs `../embed`, without editing production code in this branch.

## Evidence deliverables (authoritative)

| Deliverable | Path |
|-------------|------|
| Code and contract comparison | `docs/ai_reports/baseline_audit_code_research.md` |
| Documentation inventory and deletion/rewrite candidates | `docs/ai_reports/baseline_audit_doc_research.md` |

## Decisions locked for downstream (see reports for file-level evidence)

1. **Canonical implementation** migrates from `../embed`: `embed/client/embedding_client.py`, `embedding_client_helpers.py`, `embed_file_status_store.py`, `embed/constants.py`, `embed/exceptions.py`; optional adjacent `embed/client/service_manager_health.py` (uses direct `httpx` — separate dependency decision).
2. **Server wins** on contract differences: job-status RPC order (`queue_get_job_status` before `embed_job_status`); `wait_for_job` semantics (WS-first when adapter supports it); full `embed_file` pipeline parity is an explicit gap vs current `EmbeddingServiceAsyncClient` surface.
3. **Runtime dependency verdict:** `mcp-proxy-adapter>=6.10.0` matches server pin and covers `EmbeddingClient` imports; `PyJWT`, `cryptography`, and package-level `pydantic` are not justified by current `embed_client/` imports (scripts may still use `pydantic`).
4. **Documentation:** Legacy program under `docs/specs/tech_spec/` is superseded by this epic; root README/CONFIGURATION/CLI and `docs/agents/project_overlay.md` require rewrite against migrated API; server reference: `../embed/docs/CLIENT_DEVELOPER_GUIDE.md`.

## Out of scope (this tactical task)

- Code, test, or script edits; global `plan.md` / root epic edits.

## Acceptance criteria

- Both evidence files exist and are internally consistent with this tactical spec.
- Downstream branches can cite this tactical spec and the two reports without re-deriving architecture.

## Atomic steps

Delegated to **`planner_auto`**. This branch is **analysis-only**: if no PR-sized coding units apply, **`planner_auto`** records that fact in the atomic index (no fictitious code steps).
