<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# Atomic steps index — `migration_baseline_deliverable`

## Parent links (mandatory)

| Document | Path |
|----------|------|
| Epic (root ТЗ) | [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md) |
| Global step | [`docs/specs/server_client_convergence_and_release/baseline_audit_and_contract_capture/spec.md`](../spec.md) |
| Tactical task | [`docs/specs/server_client_convergence_and_release/baseline_audit_and_contract_capture/migration_baseline_deliverable/spec.md`](./spec.md) |

## Tactical task goal (summary)

Materialize a **migration baseline** for downstream global steps using code and documentation research on `embed-client` vs `../embed`, without editing production code in this branch. Authoritative evidence lives in two AI reports under `docs/ai_reports/`.

## `coder_auto` pull requests

**Zero.** This tactical task is **analysis-only**. No production code, tests, scripts, or configs are in scope. Do not open PR-sized coding units for `coder_auto` under this task.

Evidence and locked decisions are recorded in existing files; any remaining work is **documentation consolidation** in those evidence paths only (see atomic step below).

## Evidence deliverables (authoritative)

| Deliverable | Path |
|-------------|------|
| Code and contract comparison | [`docs/ai_reports/baseline_audit_code_research.md`](../../../../ai_reports/baseline_audit_code_research.md) |
| Documentation inventory and deletion/rewrite candidates | [`docs/ai_reports/baseline_audit_doc_research.md`](../../../../ai_reports/baseline_audit_doc_research.md) |

## Atomic steps

| ID | File | Primary target(s) | Dependencies |
|----|------|-------------------|--------------|
| MB-1 | [`freeze-migration-baseline-evidence-links.md`](./freeze-migration-baseline-evidence-links.md) | `docs/ai_reports/baseline_audit_code_research.md`, `docs/ai_reports/baseline_audit_doc_research.md` | None |

## Dependency order

1. **MB-1** (optional consolidation only if gaps remain; see step file). No serial chain beyond this single doc step.

## Parallel execution

Only one executable atomic step is defined. No parallel waves apply.

## Reference to root specification

The epic specification is the durable ТЗ for this program of work: [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md) (**LAYOUT-09**, **CR-017**).
