<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# Baseline audit and contract capture

## Goal

Establish a trustworthy migration baseline by comparing the current `embed-client` repository against the server-internal client in `../embed`, with special focus on runtime dependencies, package metadata, public contracts, configuration behavior, test surfaces, scripts, and documentation obligations.

## In scope

- Inventory current client implementation and server-internal client implementation.
- Identify the canonical modules, contracts, and dependency declarations to migrate.
- Produce an explicit list of legacy code, compatibility behavior, tests, scripts, and documentation that must be removed.
- Confirm whether the current dependency declarations in `pyproject.toml` match the migrated implementation needs.

## Out of scope

- Editing production code or docs in this branch beyond tactical planning artifacts and branch-owned deliverables.

## Exit criteria

- A migration baseline exists with explicit source-of-truth decisions.
- Dependency and packaging gaps are identified with concrete file-level evidence.
- Downstream branches can execute without re-deciding architectural direction.
