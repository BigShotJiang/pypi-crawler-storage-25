<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# Global plan

## Execution model

This epic is executed as a dependency-aware parallel program:

- Wave 1: `baseline_audit_and_contract_capture`
- Wave 2: `production_migration_and_legacy_removal`, `tests_scripts_and_dependency_cleanup`
- Wave 3: `documentation_normalization`
- Wave 4: `release_validation_and_pypi_publication`

## Dependency rules

- `baseline_audit_and_contract_capture` must complete first because all later work depends on its code, dependency, and contract decisions.
- `production_migration_and_legacy_removal` and `tests_scripts_and_dependency_cleanup` may run in parallel after the baseline is locked, but must continuously synchronize on breaking contract changes.
- `documentation_normalization` starts after the migrated implementation and surviving tests/scripts are settled enough to document the final system rather than an intermediate state.
- `release_validation_and_pypi_publication` starts only after implementation, cleanup, and documentation branches have closed with acceptable verification.

## Management rules

- Prefer deletion over compatibility code when a legacy path no longer serves the migrated implementation.
- Prefer a single canonical implementation over adapters, wrappers, or dual code paths.
- Treat missing PyPI credentials, missing publish permissions, or failing mandatory validation as blockers for the publication branch.
