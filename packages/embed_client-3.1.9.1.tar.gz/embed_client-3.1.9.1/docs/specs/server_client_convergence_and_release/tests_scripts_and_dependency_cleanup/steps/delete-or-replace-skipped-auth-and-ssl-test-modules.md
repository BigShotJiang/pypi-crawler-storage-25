<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# TSC-05 — Remove or replace skipped-only modules: `test_auth_helpers`, `test_auth`, `test_ssl_manager`

**Executor:** `coder_auto`

## Parent links

| Document | Path |
|----------|------|
| Epic | [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md) |
| Global plan | [`docs/specs/server_client_convergence_and_release/plan.md`](../../plan.md) |
| Tactical task | [`docs/specs/server_client_convergence_and_release/tests_scripts_and_dependency_cleanup/spec.md`](../spec.md) |

## Goal

Eliminate **skipped-only** or **misleading** test modules per tactical §5 and research §3.5: `tests/test_auth_helpers.py`, `tests/test_auth.py` (skip aggregator), `tests/test_ssl_manager.py` — **delete** or replace with **narrow active tests** that assert current behavior.

## Scope / files

| Role | Path |
|------|------|
| Primary | `tests/test_auth_helpers.py`, `tests/test_auth.py`, `tests/test_ssl_manager.py` |
| Optional follow-up | `tests/test_example_async_usage_ru.py` (research: module-level skip; decide delete vs narrow active smoke vs leave documented opt-in — must not remain meaningless skip-only noise if tactical prefers deletion) |
| Read first | [`docs/ai_reports/tests_scripts_dependency_cleanup_code_research.md`](../../../../ai_reports/tests_scripts_dependency_cleanup_code_research.md) §3.5; `tests/test_auth_manager.py`; shipped `ClientSSLManager` / auth APIs |

## Expected change

1. **`test_auth_helpers.py`:** Delete module if entirely skipped and redundant with `test_auth_manager.py` + adapter tests; **or** replace with a **short** active test file — **no** module-level skip covering 100% of content without value.
2. **`test_auth.py`:** Remove if it only re-exports + skip (research); ensure **`test_auth_manager.py`** remains collected and unaffected.
3. **`test_ssl_manager.py`:** Delete skipped bulk **or** add **minimal** tests for `ClientSSLManager` validation behavior if that type remains — **no** skip-only file.

**Forbidden:** Leaving files that are entirely skipped without replacing them with meaningful assertions or deletion.

## Acceptance criteria

- No skip-only dead modules for these three paths unless explicitly justified by a **single** narrow skipped test with a documented reason (prefer deletion per epic).

## Validation

- `pytest` reports no pointless empty/skipped-only modules for these filenames (or files removed).
- **All tests pass.**

## Dependencies

- **TSC-08** should run after this step if coverage files referenced deleted modules.

## Notes for coder

- `test_auth.py` skip does **not** disable `test_auth_manager.py` — do not delete `test_auth_manager.py` by mistake.
- For SSL, prefer a **small** file with real assertions on validation-only behavior over a skipped placeholder.
- If `test_example_async_usage_ru.py` is out of scope for this PR, document the decision in the step PR description and track for a follow-up.

## Definition of done

Three paths resolved per above; **all tests pass.**
