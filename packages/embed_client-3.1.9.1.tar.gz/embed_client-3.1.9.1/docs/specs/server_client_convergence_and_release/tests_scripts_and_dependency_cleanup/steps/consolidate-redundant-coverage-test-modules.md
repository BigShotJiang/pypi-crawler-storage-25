<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# TSC-08 — Consolidate redundant coverage-oriented test modules

**Executor:** `coder_auto`

## Parent links

| Document | Path |
|----------|------|
| Epic | [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md) |
| Global plan | [`docs/specs/server_client_convergence_and_release/plan.md`](../../plan.md) |
| Tactical task | [`docs/specs/server_client_convergence_and_release/tests_scripts_and_dependency_cleanup/spec.md`](../spec.md) |

## Goal

Reduce maintenance cost from **overlapping** “coverage / 90%+” suites per research §3.2, §3.5, §6 item 6 — merge or delete redundant files **where safe**, without lowering meaningful assertions on the migrated client.

## Scope / files

| Role | Path |
|------|------|
| Primary | Subset of `tests/test_*coverage*.py`, `tests/test_*90_plus*.py`, etc. — **only after** confirming overlap (research lists candidates; tree may differ) |
| Typical candidates | `test_coverage_90_plus.py`, `test_all_modules_coverage.py`, `test_final_90_plus_coverage.py`, `test_final_coverage.py`, `test_remaining_coverage.py`, `test_embed_overrides_coverage.py`, `test_adapter_transport_coverage.py`, `test_api_mixin_90_plus.py` |
| Read first | [`docs/ai_reports/tests_scripts_dependency_cleanup_code_research.md`](../../../../ai_reports/tests_scripts_dependency_cleanup_code_research.md) §3.2, §3.5, §6; outcomes of **TSC-04** and **TSC-05** |

## Expected change

1. **Inventory** duplicate scenarios (same public API exercised multiple times across files).
2. **Consolidate** into fewer modules with clear naming; **delete** true duplicates.
3. Preserve **unique** edge-case coverage when not duplicated elsewhere.

**Forbidden:** Blind merge that drops distinct assertions; one giant file with unrelated concerns unless tactical explicitly allows (prefer **logical** grouping in 1–2 consolidated files).

## Acceptance criteria

- Measurable reduction in redundant coverage modules **or** merged files with the same total assertion strength on public APIs (no silent removal of unique checks).

## Validation

- Coverage or targeted pytest runs per project practice; **all tests pass.**
- No new undeclared optional imports in default collection.

## Dependencies

- **After TSC-04** (async client layout) and **TSC-05** (auth/ssl modules) to avoid churn conflicts.

## Notes for coder

- Run a quick duplicate-scenario pass (same public method tested in multiple files) before merging; keep one stronger test, not two weak duplicates.
- If consolidation risks regression, split into two PRs: inventory + delete obvious duplicates first, then merge modules.

## Definition of done

Redundant coverage files merged or removed with tests green; **all tests pass.**
