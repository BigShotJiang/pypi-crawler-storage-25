<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# TSC-01 — Align `embed_client.__version__` with `pyproject.toml` (or dynamic metadata)

**Executor:** `coder_auto`

## Parent links

| Document | Path |
|----------|------|
| Epic | [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md) |
| Global plan | [`docs/specs/server_client_convergence_and_release/plan.md`](../../plan.md) |
| Tactical task | [`docs/specs/server_client_convergence_and_release/tests_scripts_and_dependency_cleanup/spec.md`](../spec.md) |

## Goal

Eliminate **version drift** between `[project].version` in `pyproject.toml` and `embed_client.__version__` (research: `3.1.7.28` vs `3.1.7.25`). Enforce a **single source of truth** per tactical locked decisions.

## Scope / files

| Role | Path |
|------|------|
| Primary | `embed_client/__init__.py` |
| Reference | `pyproject.toml` (`[project].version`) |
| Read first | [`docs/ai_reports/tests_scripts_dependency_cleanup_code_research.md`](../../../../ai_reports/tests_scripts_dependency_cleanup_code_research.md) §1.3–1.5 |

## Expected change

Choose **one** approach (pre-resolve; do not leave both a stale string and metadata):

1. **Preferred:** Read version at runtime via `importlib.metadata.version("embed-client")` (or equivalent supported by the project’s packaging), with a narrow fallback only if the project rules require it; **or**
2. Set `__version__` string to **exactly** match `[project].version` in `pyproject.toml`.

**Forbidden:** Leaving mismatched patch/minor segments; duplicating version in two places without a defined owner.

If a **regression test** is added (optional but recommended), keep it minimal (assert `embed_client.__version__` equals metadata or `pyproject` parse) and place it in an existing appropriate test module.

## Acceptance criteria

- `embed_client.__version__` reflects the same release identity as package metadata / `pyproject.toml`.
- No unexplained version constants elsewhere in `embed_client/` for the same purpose.

## Validation

- Run full test suite and project linters/typecheck per **CR-007** / `tester_auto` expectations.
- **All tests pass.**

## Dependencies

- None (may run in parallel with **TSC-02**).

## Notes for coder

- Prefer `importlib.metadata.version("embed-client")` only after editable/installable metadata is reliable in dev; if the project already documents a string convention, match it exactly to `pyproject.toml`.
- Avoid introducing a second version constant in `setup.cfg` or unrelated modules.

## Definition of done

Implementation merged; validation green; **all tests pass.**
