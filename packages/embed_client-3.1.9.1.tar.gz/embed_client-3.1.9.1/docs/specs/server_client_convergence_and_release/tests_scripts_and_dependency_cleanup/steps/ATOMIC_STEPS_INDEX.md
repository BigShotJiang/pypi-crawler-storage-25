<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# Atomic steps index — `tests_scripts_and_dependency_cleanup`

**Executor:** `coder_auto` (per step files).

## Parent documents

| Role | Path |
|------|------|
| Epic / root ТЗ | [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md) |
| Global plan (Wave 2 — step `tests_scripts_and_dependency_cleanup`) | [`docs/specs/server_client_convergence_and_release/plan.md`](../../plan.md) |
| Tactical task | [`docs/specs/server_client_convergence_and_release/tests_scripts_and_dependency_cleanup/spec.md`](../spec.md) |

The tactical [`spec.md`](../spec.md) expands global step id `tests_scripts_and_dependency_cleanup`. Epic [`spec.md`](../../spec.md) lists this step under Global steps (item 3).

## Reference specification

- Durable technical context: epic [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md) — this tactical step expands global item **tests_scripts_and_dependency_cleanup** under that epic.

## Evidence (authoritative for filenames and rationale)

- [`docs/ai_reports/tests_scripts_dependency_cleanup_code_research.md`](../../../../ai_reports/tests_scripts_dependency_cleanup_code_research.md)

## Tactical goal (summary)

Verification-ready tests/scripts and minimal accurate dependency metadata: aligned version, trimmed core deps with `mcp-proxy-adapter>=6.10.0`, optional extras for script-only needs, no default collection of undeclared imports, stale/broken examples removed or fixed, pytest config unified, portable script paths, plus **one canonical `localhost:8001` mTLS example** (`mtls_certificates/`, man-page docstring, execution-based tests — **TSC-09**).

## Dependency order

1. **TSC-01** — [`align-package-version-with-pyproject-metadata.md`](./align-package-version-with-pyproject-metadata.md)
2. **TSC-02** — [`normalize-pyproject-runtime-deps-and-optional-extras.md`](./normalize-pyproject-runtime-deps-and-optional-extras.md)
3. **TSC-03** — [`fix-or-remove-embed-client-auth-examples.md`](./fix-or-remove-embed-client-auth-examples.md)
4. **TSC-04** — [`extract-async-client-adapter-tests-remove-legacy-aiohttp.md`](./extract-async-client-adapter-tests-remove-legacy-aiohttp.md)
5. **TSC-05** — [`delete-or-replace-skipped-auth-and-ssl-test-modules.md`](./delete-or-replace-skipped-auth-and-ssl-test-modules.md)
6. **TSC-06** — [`consolidate-pytest-configuration-single-source.md`](./consolidate-pytest-configuration-single-source.md)
7. **TSC-07** — [`replace-hardcoded-venv-site-packages-in-scripts-and-tests.md`](./replace-hardcoded-venv-site-packages-in-scripts-and-tests.md)
8. **TSC-08** — [`consolidate-redundant-coverage-test-modules.md`](./consolidate-redundant-coverage-test-modules.md)
9. **TSC-09** — [`canonical-localhost-8001-mtls-example-and-execution-tests.md`](./canonical-localhost-8001-mtls-example-and-execution-tests.md)

**Serial constraint:** **TSC-08** runs after **TSC-04** and **TSC-05** (stable test layout and removed modules before merging coverage-oriented files).

**Canonical mTLS example:** **TSC-09** implements the locked **`localhost:8001` + `mTLS` + `mtls_certificates/`** scenario with man-page-level documentation and execution-based validation (inventories and rationale: [`docs/ai_reports/tests_scripts_dependency_cleanup_code_research.md`](../../../../ai_reports/tests_scripts_dependency_cleanup_code_research.md); tactical [`spec.md`](../spec.md)). **TSC-09** is **not** a substitute for **TSC-01**–**TSC-08**; it closes the gap left by those steps on example/test artifacts.

## Parallel execution (CR-016)

| Wave | Steps | Notes |
|------|-------|--------|
| **W1** | TSC-01, TSC-02 | No mutual dependency; both touch metadata/version surface. |
| **W2** | TSC-03, TSC-04, TSC-05, TSC-06, TSC-07, TSC-09 | Parallel after W1 completes (recommended). **TSC-09** depends on W1 only (package/deps stable); it does **not** require TSC-08. If CI requires strict ordering, run W2 steps sequentially — still valid. |
| **W3** | TSC-08 | After W2; depends on TSC-04 + TSC-05 outcomes. |

## Steps ↔ primary targets

| ID | Slug | Primary artifacts |
|----|------|-------------------|
| TSC-01 | align-package-version-with-pyproject-metadata | `embed_client/__init__.py`; optional tiny test |
| TSC-02 | normalize-pyproject-runtime-deps-and-optional-extras | `pyproject.toml` |
| TSC-03 | fix-or-remove-embed-client-auth-examples | `embed_client/auth_examples.py`, package exports if needed |
| TSC-04 | extract-async-client-adapter-tests-remove-legacy-aiohttp | `tests/test_async_client.py`, new test module, `tests/conftest.py` |
| TSC-05 | delete-or-replace-skipped-auth-and-ssl-test-modules | `tests/test_auth_helpers.py`, `tests/test_auth.py`, `tests/test_ssl_manager.py`; optional: `tests/test_example_async_usage_ru.py` |
| TSC-06 | consolidate-pytest-configuration-single-source | `pytest.ini`, `pyproject.toml` |
| TSC-07 | replace-hardcoded-venv-site-packages-in-scripts-and-tests | `scripts/*.py`, `tests/test_all_security_modes.py` (per research grep) |
| TSC-08 | consolidate-redundant-coverage-test-modules | `tests/test_*coverage*.py`, `tests/test_*90_plus*.py`, etc. |
| TSC-09 | canonical-localhost-8001-mtls-example-and-execution-tests | `examples/canonical_mtls_localhost_8001.py`, `tests/test_canonical_mtls_example.py`, `examples/README.md`, `examples/__init__.py`; optional touch: `tests/test_security_matrix.py` for portable cert paths / discoverability |

## Definition of done (global)

Per tactical [`spec.md`](../spec.md): **`tester_auto`** acceptable verdict (full test suite + linters/typecheck per project rules). Each step file restates validation; **all tests must pass** before the step is considered complete.
