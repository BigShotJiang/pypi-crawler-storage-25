<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# TSC-09 — Canonical `localhost:8001` mTLS example, man-page docstring, execution-based validation

**Executor:** `coder_auto`

## Parent links

| Document | Path |
|----------|------|
| Epic | [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md) |
| Global plan | [`docs/specs/server_client_convergence_and_release/plan.md`](../../plan.md) |
| Tactical task | [`docs/specs/server_client_convergence_and_release/tests_scripts_and_dependency_cleanup/spec.md`](../spec.md) |
| Evidence (inventories / algorithms) | [`docs/ai_reports/tests_scripts_dependency_cleanup_code_research.md`](../../../../ai_reports/tests_scripts_dependency_cleanup_code_research.md) |

## Goal

Deliver the **locked** canonical runnable scenario: real-server target **`localhost:8001`** over **`mTLS`**, certificates from repository **`mtls_certificates/`**, **`EmbeddingClient`**-only surface, **man-page-level** module docstring (operational documentation quality), and **execution-based** checks — not import-only or syntax-only validation. Satisfies tactical [`spec.md`](../spec.md) acceptance criteria **7–9** and the canonical mTLS expectations recorded in [`docs/ai_reports/tests_scripts_dependency_cleanup_code_research.md`](../../../../ai_reports/tests_scripts_dependency_cleanup_code_research.md) (including **Expected outcome** / **Test plan** items where documented there).

## Scope / files

| Role | Path |
|------|------|
| Primary (create or complete) | `examples/canonical_mtls_localhost_8001.py` |
| Primary (create or complete) | `tests/test_canonical_mtls_example.py` |
| Secondary | `examples/README.md`, `examples/__init__.py` — discoverability, short pointer to the canonical script |
| Secondary | `tests/test_security_matrix.py` — only if needed for **portable** cert path references / matrix alignment with the canonical example (no hard-coded home paths) |
| Read first | [`docs/ai_reports/tests_scripts_dependency_cleanup_code_research.md`](../../../../ai_reports/tests_scripts_dependency_cleanup_code_research.md) — class/function inventory, import map, error handling map, config dependency, concrete examples, algorithm (as recorded there); tactical [`spec.md`](../spec.md) for acceptance criteria |

**Out of scope for this step:** PyPI, full repo README; duplicate prose already captured in code research — implement to match locked names and behaviors below.

## Expected change

1. **`examples/canonical_mtls_localhost_8001.py`**
   - Resolve repo root from the example file location; absolute paths under `mtls_certificates/` (client cert/key, CA) per code research **Concrete examples** §1.
   - Implement the **named** helpers with the signatures and roles recorded in code research: `_cert_paths`, `build_mtls_localhost_8001_config`, `run_live_capabilities`, `main` (dry-run default; live only when env gate is set).
   - **Man-page-level** top-of-module docstring: purpose, prerequisites, env vars (`RUN_CANONICAL_MTLS_E2E`), certificate layout, dry-run vs live behavior, non-zero exit expectations, and explicit limitation for `embed_file` if deployment-specific paths apply (code research **Forbidden approaches**).
   - Ordered live capability flow per code research **Concrete examples** §3–4; tolerate optional failures (e.g. `timing_stats`) per code research **Error handling map** without masking connection/setup failures.
2. **`tests/test_canonical_mtls_example.py`**
   - Implement the **named** tests from code research: cert paths exist; dry-run **no network**; mocked live branch covering the documented flow; optional real-server branch gated by **`RUN_CANONICAL_MTLS_E2E=1`** (imports per code research **Import map**).
3. **Examples index** — `examples/README.md` (and `examples/__init__.py` if present) updated so the canonical script is **discoverable** and paths are described consistently.

**Forbidden:** Hard-coded absolute home-directory certificate paths; inventing fake `embed_file` server paths; reintroducing removed client APIs.

## Acceptance criteria

- Tactical [`spec.md`](../spec.md): criteria **7** (man-page-style examples), **8** (execution-based validation), **9** (canonical `localhost:8001` **mTLS**, `mtls_certificates`, one runnable capability flow).
- Code research [`tests_scripts_dependency_cleanup_code_research.md`](../../../../ai_reports/tests_scripts_dependency_cleanup_code_research.md): **Expected outcome** item 6 and **Test plan** items 1–3 (dry-run, mocked live, optional real E2E), where those sections exist in the file.

## Validation

- `pytest` on `tests/test_canonical_mtls_example.py` passes in default CI (dry-run + mocked; real branch skipped unless env set).
- Optional: manual `python -m examples.canonical_mtls_localhost_8001` (or documented entry) dry-run succeeds without server.
- Full suite + linters/typecheck per project rules after merge with sibling steps (**`tester_auto`** global gate).

## Dependencies

- **After Wave 1:** **TSC-01**, **TSC-02** (stable package identity and dependency metadata for `EmbeddingClient` and test collection).
- **No dependency on** **TSC-08** (coverage consolidation); coordinate file overlap with **TSC-07** if both touch the same security test module — prefer **TSC-07** first for `tests/test_all_security_modes.py`; this step owns **`test_canonical_mtls_example`** and canonical **`examples/`** files.

## Notes for coder

- Certificate filenames and layout: **`mtls_certificates/client/embedding-service.{crt,key}`**, **`mtls_certificates/ca/ca.crt`** (code research **Concrete examples**).
- **`FileNotFoundError`** when any required cert file is missing (fail fast).
- Keep **parallelism** with other W2 steps: avoid editing the same primary paths as **TSC-03** (`auth_examples`) unless resolving an import conflict.

## Definition of done

Canonical example and tests match the inventories in code research; acceptance criteria satisfied; **all tests pass** with **`tester_auto`** acceptable verdict after full wave.
