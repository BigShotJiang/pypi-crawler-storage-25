<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# TSC-04 — Trim `tests/test_async_client.py`: extract adapter tests; remove legacy aiohttp bulk

**Executor:** `coder_auto`

## Parent links

| Document | Path |
|----------|------|
| Epic | [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md) |
| Global plan | [`docs/specs/server_client_convergence_and_release/plan.md`](../../plan.md) |
| Tactical task | [`docs/specs/server_client_convergence_and_release/tests_scripts_and_dependency_cleanup/spec.md`](../spec.md) |

## Goal

Remove **legacy aiohttp-oriented** tests and **unconditional** `import aiohttp` from default collection; keep **adapter-aligned** tests in a **small dedicated module** (research: class `TestEmbeddingServiceAsyncClientAdapter` and similar). Update **`tests/conftest.py`** skip logic that exists only to support the legacy bulk in `test_async_client.py`.

## Scope / files

| Role | Path |
|------|------|
| Primary | `tests/test_async_client.py` (delete or drastically shrink legacy aiohttp sections) |
| New | Dedicated small module (e.g. `tests/test_async_client_adapter.py`; name per project convention, must be adapter-only) |
| Secondary | `tests/conftest.py` (~29–43: legacy skip for `test_async_client.py`) |
| Read first | [`docs/ai_reports/tests_scripts_dependency_cleanup_code_research.md`](../../../../ai_reports/tests_scripts_dependency_cleanup_code_research.md) §3.3–3.4, §3.6; current `EmbeddingServiceAsyncClient` |

## Expected change

1. **Move** surviving adapter tests into the new module; preserve behavior/assertions relevant to `_adapter_transport` and current client.
2. **Delete** skipped legacy aiohttp tests that mock `client._session` / old transport (or relocate to a non-default optional path **only if** tactical explicitly required — tactical prefers **deletion**).
3. Remove **top-level** `import aiohttp` from the default-collected module(s) unless `aiohttp` is added as an optional test dependency project-wide (tactical prefers **removal** of legacy path).
4. Simplify **`conftest.py`** so it does not skip entire `test_async_client.py` classes except the adapter class — after extraction, skips targeting the old file layout should be **removed or rewritten**.

**Forbidden:** Leaving ~1500+ lines of dead skipped aiohttp mocks in default tree; requiring `aiohttp` for default `pytest` collection without declaring it.

## Acceptance criteria

- Default test collection does not import `aiohttp` solely for skipped legacy code (tactical §3–4).
- Adapter coverage remains in a maintainable layout.

## Validation

- `pytest` collection without optional extras does not fail on missing `aiohttp` if it is no longer imported at module level in collected tests.
- Full test run; **all tests pass.**

## Dependencies

- Logical prerequisite for **TSC-08** (coverage consolidation runs after layout is stable).

## Notes for coder

- Preserve assertions for `_adapter_transport`, absence of legacy `_session` mocking, and adapter constructor params from `TestEmbeddingServiceAsyncClientAdapter` (research §3.4).
- After extraction, run `pytest --collect-only` and confirm no stray `aiohttp` import on the default path.
- If `test_async_client.py` is deleted entirely, remove dead `conftest` hooks that only existed for its skip layout.

## Definition of done

Legacy bulk removed or isolated; conftest aligned; **all tests pass.**
