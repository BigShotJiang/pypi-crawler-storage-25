<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# TSC-06 — Consolidate pytest configuration (`pytest.ini` vs `pyproject.toml`)

**Executor:** `coder_auto`

## Parent links

| Document | Path |
|----------|------|
| Epic | [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md) |
| Global plan | [`docs/specs/server_client_convergence_and_release/plan.md`](../../plan.md) |
| Tactical task | [`docs/specs/server_client_convergence_and_release/tests_scripts_and_dependency_cleanup/spec.md`](../spec.md) |

## Goal

Single **canonical** pytest configuration to avoid drift between root **`pytest.ini`** and **`[tool.pytest.ini_options]`** in `pyproject.toml` (research §5).

## Scope / files

| Role | Path |
|------|------|
| Primary | `pytest.ini`, `pyproject.toml` (`[tool.pytest.ini_options]`) |
| Read first | [`docs/ai_reports/tests_scripts_dependency_cleanup_code_research.md`](../../../../ai_reports/tests_scripts_dependency_cleanup_code_research.md) §5 |

## Expected change

1. Merge **all** meaningful options into **one** location per project convention (typically **`pyproject.toml`** `[tool.pytest.ini_options]` **or** retain **`pytest.ini`** — choose **one** source; remove duplicate keys from the other).
2. Preserve behavior: `testpaths`, markers (`integration`, `stress`), `asyncio_default_fixture_loop_scope`, `addopts` (e.g. `-n auto`), `timeout`, etc., as currently relied upon.
3. Delete redundant file **or** make it a one-line pointer only if project policy forbids deleting `pytest.ini` — prefer **no** conflicting duplicates.

**Forbidden:** Two divergent copies of the same keys; silently dropping `pytest-xdist` / `pytest-timeout` assumptions from `addopts`/`timeout` without verifying optional deps still match.

## Acceptance criteria

- `pytest --help` / collection behavior unchanged for default workflows.
- One authoritative config source.

## Validation

- Run pytest (with and without xdist if applicable per project docs).
- Linters/typecheck; **all tests pass.**

## Dependencies

- None (parallel with **TSC-03**–**TSC-05**, **TSC-07**).

## Notes for coder

- Preserve `addopts` (`-n auto`), `timeout`, markers, and `testpaths` — verify `pytest-xdist` / `pytest-timeout` remain in optional deps after any docstring change.
- If moving everything to `pyproject.toml`, delete `pytest.ini` or leave a one-line redirect only if policy requires a root file.

## Definition of done

Config unified; **all tests pass.**
