<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# TSC-03 — Fix or remove `embed_client/auth_examples.py`

**Executor:** `coder_auto`

## Parent links

| Document | Path |
|----------|------|
| Epic | [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md) |
| Global plan | [`docs/specs/server_client_convergence_and_release/plan.md`](../../plan.md) |
| Tactical task | [`docs/specs/server_client_convergence_and_release/tests_scripts_and_dependency_cleanup/spec.md`](../spec.md) |

## Goal

Remove **broken** packaged examples that call **non-existent** `ClientAuthManager` methods, or rewrite them to match **current** `embed_client/auth.py` (e.g. config validation, header construction only) per tactical §Acceptance criteria item 6.

## Scope / files

| Role | Path |
|------|------|
| Primary | `embed_client/auth_examples.py` |
| Secondary | `embed_client/__init__.py`, package `__all__` / docs references if module removed |
| Read first | `embed_client/auth.py` (`ClientAuthManager`); [`docs/ai_reports/tests_scripts_dependency_cleanup_code_research.md`](../../../../ai_reports/tests_scripts_dependency_cleanup_code_research.md) §2.3 |

## Expected change

- **Option A (preferred when demos add no value):** Delete `auth_examples.py` and remove references (imports, `python -m` docs, console expectations).
- **Option B:** Rewrite examples so they only use **existing** APIs (e.g. `validate_auth_config`, header-related helpers) and run without error under `python -m embed_client.auth_examples` if that entry remains meaningful.

**Forbidden:** Shipping examples that call `authenticate_api_key`, `create_jwt_token`, `authenticate_jwt`, `authenticate_basic`, `authenticate_certificate`, or other removed methods.

## Acceptance criteria

- No runtime failure from packaged auth examples path.
- Tactical §6 satisfied.

## Validation

- Manual or automated smoke: importing/running the module does not raise.
- Full test suite; **all tests pass.**

## Dependencies

- None (parallel with **TSC-04**–**TSC-07** after **TSC-01**/**TSC-02** recommended).

## Notes for coder

- `tests/test_auth_manager.py` already asserts removed fake-auth methods — align examples with **header validation** and **`validate_auth_config`** only; do not reintroduce removed APIs for demos.
- If deleting the module, search the repo for `auth_examples` imports and `python -m embed_client.auth_examples`.

## Definition of done

Broken API usage eliminated; **all tests pass.**
