<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# TSC-02 — Normalize `pyproject.toml`: core deps, `mcp-proxy-adapter`, optional `pydantic` extra

**Executor:** `coder_auto`

## Parent links

| Document | Path |
|----------|------|
| Epic | [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md) |
| Global plan | [`docs/specs/server_client_convergence_and_release/plan.md`](../../plan.md) |
| Tactical task | [`docs/specs/server_client_convergence_and_release/tests_scripts_and_dependency_cleanup/spec.md`](../spec.md) |

## Goal

Make **`[project].dependencies`** complete and minimal for the **surviving package**: keep **`mcp-proxy-adapter>=6.10.0`**; remove **unjustified** direct **PyJWT**, **cryptography**, and **pydantic** from core if research still holds (no imports under `embed_client/`). Declare **pydantic** under an **optional extra** (e.g. `scripts`, `dev-servers`, or combined with existing dev extras) for `scripts/run_embedding_test_server.py`, `scripts/run_https_test_server.py`, and `test_environment/examples/full_application/proxy_endpoints.py` per research §4.1.

## Scope / files

| Role | Path |
|------|------|
| Primary | `pyproject.toml` |
| Consumers (verify after edit) | `scripts/run_embedding_test_server.py`, `scripts/run_https_test_server.py`, `test_environment/examples/full_application/proxy_endpoints.py` |
| Read first | Tactical [`spec.md`](../spec.md) §Locked decisions; [`docs/ai_reports/tests_scripts_dependency_cleanup_code_research.md`](../../../../ai_reports/tests_scripts_dependency_cleanup_code_research.md) §1–2, §4.1 |

## Expected change

1. **Core `[project].dependencies`:** retain **`mcp-proxy-adapter>=6.10.0`**; remove **PyJWT**, **cryptography**, **pydantic** unless a **concrete** import in shipped `embed_client/` or required tooling appears after re-scan (tactical: remove unless proven).
2. **`[project.optional-dependencies]`:** add or extend an extra that includes **pydantic** for script/test-server paths that import it; name the extra clearly (e.g. `scripts` or `dev-servers`).
3. Do **not** add unrelated packages; do not drop **mcp-proxy-adapter** pin below **6.10.0**.

**Forbidden:** Leaving pydantic only in core while scripts need it without an extra; re-adding PyJWT/cryptography to core without evidence.

## Acceptance criteria

- Runtime deps match real imports for `embed_client/` after cleanup.
- Pydantic consumers are installable via documented optional extra (e.g. `pip install -e ".[…]"`).
- Tactical acceptance criteria §1 satisfied.

## Validation

- `pip install` / editable install paths still work for dev workflows documented in project rules.
- Full tests + linters/typecheck; **all tests pass.**

## Dependencies

- None relative to **TSC-01** (parallel-safe).

## Notes for coder

- Re-grep `embed_client/` for `jwt`, `cryptography`, `pydantic` before removing; absence of imports is the baseline — do not add core deps for doc-only mentions of “JWT mode”.
- Name the pydantic extra clearly (`scripts`, `dev-servers`, or similar) and document the install line where those entrypoints are described (minimal — avoid new README scope unless already planned).
- Keep **`mcp-proxy-adapter>=6.10.0`** in core; do not relax the floor.

## Definition of done

`pyproject.toml` updated; optional extra wired; **all tests pass.**
