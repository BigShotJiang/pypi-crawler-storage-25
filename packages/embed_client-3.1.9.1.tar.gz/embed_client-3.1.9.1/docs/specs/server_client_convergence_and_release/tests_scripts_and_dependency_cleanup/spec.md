<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# Tests, scripts, and dependency cleanup (tactical)

## Parent links

- Epic: [`../spec.md`](../spec.md)
- Global plan: [`../plan.md`](../plan.md)
- Global step id: `tests_scripts_and_dependency_cleanup` — this file is the **tactical** expansion for that step (goal, evidence links, acceptance criteria, atomics pointer).

## Evidence and coordination

| Deliverable | Path |
|-------------|------|
| Code / tests / scripts / deps research | `docs/ai_reports/tests_scripts_dependency_cleanup_code_research.md` |
| Documentation impact (for later `documentation_normalization`) | `docs/ai_reports/tests_scripts_dependency_cleanup_doc_research.md` |
| Baseline (locked decisions) | [`../baseline_audit_and_contract_capture/migration_baseline_deliverable/spec.md`](../baseline_audit_and_contract_capture/migration_baseline_deliverable/spec.md) |
| Baseline code evidence | `docs/ai_reports/baseline_audit_code_research.md` |
| Baseline doc evidence | `docs/ai_reports/baseline_audit_doc_research.md` |

## Locked decisions (non-negotiable)

- Backward compatibility is **forbidden**; only the migrated server-style client surface and adapter-backed implementation are in scope.
- **`mcp-proxy-adapter>=6.10.0`** remains required and aligned with the server pin.
- **`PyJWT`** and **`cryptography`**: remove from runtime dependencies unless this branch proves concrete final-state imports in surviving package or required tooling; baseline shows none under `embed_client/`.
- **`pydantic`**: not justified by `embed_client/` imports; if scripts or `test_environment` need it, declare under an **optional extra** (e.g. dev servers / scripts), not core `[project].dependencies`.
- Eliminate **version drift** between `pyproject.toml` `[project].version` and `embed_client.__version__` (single source of truth).
- Remove or rewrite **stale** tests, stress/coverage-only duplicates, broken demos (`embed_client/auth_examples.py` per research), and scripts that assume removed legacy APIs; prefer **deletion** over compatibility shims.
- Examples are treated as documentation and must be rebuilt against the migrated client using the server-internal client examples as the quality reference.
- The surviving example set must cover all supported client capabilities, have man-page-level docstrings, and be validated by execution-based tests.
- One surviving example must be the canonical end-to-end real-server scenario for `localhost:8001` over `mTLS`, using repository certificates from `mtls_certificates` and exercising all supported client capabilities in one flow.
- `flake8` and `mypy` must be configured so they do not traverse the virtual environment or repository service files that are outside the intended maintained source, test, and example surface.
- The branch must produce an inventory of the migration state after cleanup, covering code, tests, scripts, examples, documentation, and verification outcomes.

## Tactical goal

Deliver a **verification-ready** test and script surface and **minimal, accurate** dependency metadata: runtime deps match real imports; optional groups cover test/dev and script-only needs; tests collect without hidden optional imports unless declared; broken packaged examples are removed or fixed; the final example suite is runnable documentation for the migrated client rather than leftover demos, including one canonical `localhost:8001` `mTLS` end-to-end scenario; and quality tools are scoped so they do not waste effort on the virtual environment or non-maintained service artifacts.

## Boundaries

- **In scope:** `pyproject.toml`, `[project.scripts]`, `embed_client/__init__.py` version alignment, `tests/`, `scripts/`, `examples/`, `test_environment/` where needed for pydantic/script alignment, consolidation of pytest configuration (`pytest.ini` vs `[tool.pytest.ini_options]`), portable script path logic (no hard-coded `.venv/lib/python3.12/...`).
- **Out of scope:** PyPI publish, full README rewrite (track via doc research for `documentation_normalization`), production migration edits that belong to `production_migration_and_legacy_removal` unless required to unblock tests/deps for this branch.

## Acceptance criteria

1. Runtime dependencies in `pyproject.toml` are **complete and minimal** for the surviving package: **`mcp-proxy-adapter>=6.10.0`** plus any dependency proven necessary by imports after cleanup; **PyJWT** / **cryptography** removed unless evidence of use; **pydantic** moved to extras or removed if unused.
2. **`embed_client.__version__`** matches release metadata (or is derived from metadata) — no drift vs `pyproject.toml`.
3. Default test collection does not require undeclared packages (e.g. legacy **`aiohttp`** import) unless explicitly added to an optional test extra or legacy block removed.
4. Legacy aiohttp-based bulk in `tests/test_async_client.py` is **removed or isolated**; surviving adapter tests are in a maintainable layout (e.g. dedicated small module per research).
5. Skipped-only or empty modules (`test_auth_helpers.py`, skip-only `test_auth.py`, skipped `test_ssl_manager.py` per research) are **deleted or replaced** with narrow active tests.
6. **`embed_client/auth_examples.py`** is **fixed or removed** — no shipped broken calls to removed `ClientAuthManager` methods.
7. Surviving examples cover all supported client capabilities and use docstrings detailed enough to serve as man-page-style operational documentation.
8. Surviving examples are exercised by real execution checks, not only import or syntax checks.
9. A canonical real-server example exists for `localhost:8001` over `mTLS`, uses repository certificates from `mtls_certificates`, and exercises all supported client capabilities in one runnable flow.
10. `flake8` and `mypy` are configured to ignore the virtual environment and repository service files outside the maintained project surface.
11. The branch emits an inventory report of the resulting migration state and verification results.
12. **`tester_auto`** reports an acceptable verdict (tests + linters/typecheck per project rules) after implementation.

## Atomic steps

Delegated to **`planner_auto`** — materialize PR-sized atomic `*.md` under this global-step folder (e.g. `steps/` per **LAYOUT-09**), indexed for parallel execution where safe.

## Execution status

- Orchestration layout: the historical `docs/tech_spec/branches/tests_scripts_and_dependency_cleanup/` tree was removed during documentation normalization. Authoritative context for this global step is this tactical [`spec.md`](spec.md), the epic [`spec.md`](../spec.md), and `docs/ai_reports/tests_scripts_dependency_cleanup_code_research.md` / `docs/ai_reports/tests_scripts_dependency_cleanup_doc_research.md`.
- Research: complete — see `docs/ai_reports/tests_scripts_dependency_cleanup_code_research.md` and doc impact report.
- Atomics: materialized — [`steps/ATOMIC_STEPS_INDEX.md`](steps/ATOMIC_STEPS_INDEX.md) (TSC-01 … TSC-08).
- Implementation: delegated to **`coder_auto`** per atomics.
- Verification: delegated to **`tester_auto`** after code changes.
