<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# Tactical task: Linter scope (flake8/mypy) + migration inventory report

## Purpose

Lock repository-level `flake8` and `mypy` configuration so quality tools never traverse the virtual environment (`.venv` per `docs/PROJECT_RULES.md` §0 `VENV_DIR`) or non-maintained “service” paths (IDE, caches, build artifacts, vendored trees), while preserving checks on the maintained Python surface (`embed_client/`, `tests/`, `examples/`, `scripts/`, `test_environment/` as applicable). Produce a single durable **migration inventory** report summarizing current code, tests, scripts/examples, documentation, dependencies/metadata, and verification status after this change set.

## Parent links

- Epic spec: `docs/specs/server_client_convergence_and_release/spec.md`
- Global plan: `docs/specs/server_client_convergence_and_release/plan.md`
- Global step (authoritative): `docs/specs/server_client_convergence_and_release/tests_scripts_and_dependency_cleanup/spec.md`
- Tech baseline / locked decisions: `docs/specs/server_client_convergence_and_release/baseline_audit_and_contract_capture/migration_baseline_deliverable/spec.md`

## Scope

**Included:**

- Update root `.flake8` with explicit `exclude` (and `extend-exclude` if needed) covering at minimum: `.venv`, `venv`, `env`, `.git`, `__pycache__`, `.mypy_cache`, `.pytest_cache`, `.ruff_cache`, `build`, `dist`, `*.egg-info` / `.eggs`, `node_modules`, `.cursor` (repository service / IDE), and any other generated or non-source trees that should not be linted when tools are invoked from the repo root.
- Extend `[tool.mypy]` in `pyproject.toml` with explicit `exclude` patterns (regex, mypy 1.x style) so the interpreter never type-checks files under `.venv/` or the same service/non-maintained paths; optionally narrow `files` / explicit packages if that is the chosen approach — **must** preserve current intent: primary package `embed_client` remains fully checked; tests/examples/scripts remain type-checkable when passed to mypy per project conventions.
- Remove redundancy or contradiction between `.flake8` and `[tool.flake8]` in `pyproject.toml` (flake8 does not read `pyproject.toml` unless a plugin is used — prefer a single source of truth documented in the inventory report).
- New report: `docs/ai_reports/tests_scripts_and_dependency_migration_inventory.md` — concise inventory (see Expected outcome).

**Excluded:**

- Changing runtime dependencies, example semantics, or test logic except where required to satisfy linter config validation.
- Reopening production migration or documentation normalization decisions.

## Boundaries

- Do not modify `docs/specs/` epic content except this tactical task file if corrections are needed.
- Do not add backward-compatibility shims; forbidden by global step locked decisions.

## Dependencies

- None (can run in parallel with documentation-only workstreams if paths do not conflict).

## Parallelization note

- Config edits (`coder_auto`) can run in parallel with `researcher_code` inventory gathering; `tester_auto` runs after config merge; `doc_writer` runs after inventory evidence + tester verdict are available.

## Expected outcome

1. `flake8` invoked from repo root (with project-default paths or documented command) does not read `.venv` or listed service paths.
2. `mypy` configuration prevents checking `.venv` and listed service paths; maintained trees remain checkable with the project’s standard commands (document exact commands in the inventory report).
3. `docs/ai_reports/tests_scripts_and_dependency_migration_inventory.md` exists and lists: package layout, test suite summary, scripts/examples, key documentation pointers, `pyproject.toml` dependency/extras summary, and verification status (from `tester_auto`).
4. `tester_auto` reports PASS for `pytest tests/`, `black --check`, `flake8`, `mypy` per CR-007.

## Correction items

- If `[tool.flake8]` in `pyproject.toml` is misleading (unused), align or document — do not leave duplicate conflicting lengths without explanation.

## Questions / escalation

- Escalate to global orchestrator if mypy `files`/`exclude` interaction would drop required packages from analysis or if maintained surface definition conflicts with epic spec.

## File inventory (coder)

| action | path | purpose |
|--------|------|---------|
| modify | `.flake8` | Add excludes for venv + service/non-maintained paths |
| modify | `pyproject.toml` | Extend `[tool.mypy]` (and optional flake8 alignment note) |

## Forbidden approaches

- Broad `ignore_errors` or `# type: ignore` blanket fixes to silence real issues.
- Excluding `embed_client/`, `tests/`, `examples/`, or `scripts/` from lint/typecheck unless explicitly justified by a new global decision.

## Test plan (tester_auto)

- Full `pytest tests/`
- `black --check embed_client tests examples` (or project default scope)
- `flake8` with project default path list
- `mypy` with project default invocation
- Confirm no tool walks `.venv` (e.g. dry-run or verbose if available)

## LLAMA note

Concrete regex patterns and final path lists are to be implemented by `coder_auto` from this task and verified by `tester_auto`; this document does not duplicate atomic-step-level edits.
