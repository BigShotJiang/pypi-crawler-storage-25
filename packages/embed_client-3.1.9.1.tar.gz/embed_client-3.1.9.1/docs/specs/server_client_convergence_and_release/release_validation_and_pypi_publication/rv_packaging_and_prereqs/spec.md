<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# RV-05 — Build artifacts and publication prerequisites

## Purpose

Produce **sdist** and **wheel** for **`embed-client`**, run **`twine check`** (or project-standard equivalent) on the artifacts, and confirm **`pyproject.toml`** version matches **`embed_client.__version__`** before any upload.

## Parent links

| Document | Path |
|----------|------|
| Epic spec | [`../../spec.md`](../../spec.md) |
| Global step | [`../spec.md`](../spec.md) |
| Tactical index | [`../README.md`](../README.md) |

## Scope

**Included:**

- Clean build from repo root using **PEP 517** tooling: `python -m build` after installing the external **`build`** package into the active venv. The repository build backend in `pyproject.toml` is **`setuptools.build_meta`**.
- **`twine check dist/*`** (or check each artifact).
- Version consistency: **`[project].version`** in `pyproject.toml` vs **`embed_client.__version__`**.

**Excluded:** Uploading to PyPI (RV-06).

## Boundaries

- Do not bump version without **global** release approval (orchestrator / maintainer).

## Dependencies

- **RV-01–RV-04** must be **green** or explicitly **waived** by governance (default: **no waiver**).

## Parallelization note

**Sequential** after validation gates.

## Expected outcome

- **`dist/`** contains **`.tar.gz`** and **`.whl`** for the current version.
- **`twine check`** passes.
- Version match **confirmed** (string equality).

## Correction items

- If **`twine check`** fails, **`coder_auto`** fixes packaging metadata.

## Questions / escalation

- **Global orchestrator** for version bump policy.

## File inventory

| action | path | purpose |
|--------|------|---------|
| read | `pyproject.toml` | Name, version, build backend |
| read | `embed_client/__init__.py` | `__version__` |
| create (gitignored) | `dist/` | Build output |

## Class/function inventory

Not applicable.

## Data structures

Not applicable.

## Import map

Not applicable.

## Error handling map

| Condition | Response |
|-----------|----------|
| `python -m build` missing | `pip install build` in **venv** |
| Twine fails validation | Fix metadata (**coder_auto**) |

## Config dependency

- None beyond standard `pyproject.toml`.

## Test plan

| Executor | Action |
|----------|--------|
| **`tester_auto`** or operator | Run build + twine check; record hashes |

## Concrete examples

- **Version** `3.1.7.28` in both `pyproject.toml` and `embed_client.__version__` → **pass** consistency check.

## Algorithm / procedure

1. Activate **venv**.
2. `python -c "import embed_client; print(embed_client.__version__)"`
3. Compare to `pyproject.toml` **version**.
4. `python -m build`
5. `twine check dist/*`

## Forbidden approaches

- Publishing directly from this task **without** RV-06.
