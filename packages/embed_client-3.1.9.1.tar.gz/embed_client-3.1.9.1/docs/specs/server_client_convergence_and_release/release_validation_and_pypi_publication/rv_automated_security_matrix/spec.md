<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# RV-01 — Automated security-mode matrix

## Purpose

Run the repository’s **pytest** harness that exercises **all** security modes mandated by [`.cursor/rules/deploy.mdc`](../../../../../.cursor/rules/deploy.mdc): http; http + token; http + token + roles; https; https + token; https + token + roles; mtls; mtls + roles. Failures block release.

## Parent links

| Document | Path |
|----------|------|
| Epic spec | [`../../spec.md`](../../spec.md) |
| Global step | [`../spec.md`](../spec.md) |
| Tactical index | [`../README.md`](../README.md) |

## Scope

**Included:** Executing `tests/test_all_security_modes.py` (or the project’s current equivalent if renamed) with **active `.venv`**, required **test server / fixtures** as documented in that module or `scripts/`, capturing **pass/fail** and logs.

**Excluded:** Editing production code unless a **release-blocking** defect is found (then escalate corrective work to **`coder_auto`** via a new atomic step).

## Boundaries

- Do not change **`pyproject.toml`** version or metadata in this task unless a packaging defect blocks the matrix (escalate).
- Do not substitute a reduced subset of modes; the **full** matrix is required.

## Dependencies

- **none** (may run in parallel with RV-02 and RV-03 per [`../README.md`](../README.md)).

## Parallelization note

**Parallelizable** with RV-02 and RV-03 if **machine resources** and **test-server ports** do not conflict; otherwise serialize. Document the chosen schedule in the closure evidence.

## Expected outcome

- **`tester_auto`** verdict: **all** targeted tests **passed**.
- A run that finishes with broad **`pytest.skip(...)`** because backing services are absent does **not** satisfy this gate, even if pytest exits **0**. Missing mode backends are a **release blocker**, not a pass.
- Evidence artifact: command line, exit code, and log excerpt stored in `docs/ai_reports/` or CI log reference.

## Correction items

- If the matrix fails due to **httpx** deprecation warnings only, record as **non-blocking** only if project policy allows; otherwise **`coder_auto`** fixes per atomic step.

## Questions / escalation

- **Global orchestrator:** if the harness no longer matches **deploy.mdc** mode list or ports conflict with other waves.
- **Tactical orchestrator:** if **`tester_auto`** is unavailable (stop branch per **CR-018**).

## File inventory

| action | path | purpose |
|--------|------|---------|
| read | `tests/test_all_security_modes.py` | Primary automated matrix |
| read | `pyproject.toml` `[tool.pytest.ini_options]` | Markers, asyncio mode |
| optional read | `scripts/` test-server helpers | How to bring up backing services |

No production files modified unless a corrective atomic step is approved.

## Class/function inventory

Not applicable — **no code changes** in the default path. **`EmbeddingClient`** is exercised **indirectly** by tests only.

## Data structures

Not applicable.

## Import map

Not applicable (execution task).

## Error handling map

| Condition | Response |
|-----------|----------|
| Test failure | Block release; record traceback; optional **`coder_auto`** fix |
| Missing venv | Activate **`.venv`** per **CR-005** and retry |
| Test server not reachable | Blocker: document host/port and fix environment |
| Test skipped because service unavailable | Blocker: the full security matrix was not proven |

## Config dependency

- Pytest and optional env vars **as defined in** `tests/test_all_security_modes.py` (e.g. server ports **10001+** — confirm in file). No additional keys invented here.

## Test plan

| Executor | Scope |
|----------|--------|
| **`tester_auto`** | Run full matrix; report verdict |

**Example command (verify against current repo):**

```bash
# From repository root, venv active:
pytest tests/test_all_security_modes.py -vv --tb=short
```

## Concrete examples

- **Input:** healthy test backends on expected ports, venv active. **Expected:** exit code **0**, all mode tests **passed**.

## Algorithm / procedure

1. Activate **`.venv`** (**CR-005**).
2. Install test extras if required (`pip install -e ".[dev]"` or `[test]`).
3. Start or confirm **test servers** required by `TEST_CONFIGS` in `tests/test_all_security_modes.py`.
4. Run pytest on `tests/test_all_security_modes.py`.
5. Capture logs and verdict for the closure report.

## Forbidden approaches

- Skipping entire mode groups to “save time”.
- Running against production servers instead of the **documented** test configuration unless the epic explicitly allows (it does not for this harness).
