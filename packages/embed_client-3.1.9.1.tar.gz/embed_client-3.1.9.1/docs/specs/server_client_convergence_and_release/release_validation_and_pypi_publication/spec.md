<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# Release validation and PyPI publication

## Parent links

- Epic: [`../spec.md`](../spec.md)
- Global plan: [`../plan.md`](../plan.md)
- Tactical index (child tasks): [`README.md`](README.md)

## Goal

Validate the final package against repository release requirements and publish to PyPI when implementation, tests, examples, and documentation are aligned and mandatory gates pass.

## In scope

- Run the **security-mode validation matrix** and **localhost vectorization** checks required by [`.cursor/rules/deploy.mdc`](../../../../.cursor/rules/deploy.mdc) and the epic spec.
- Execute the **surviving example suite** as real processes (not import-only).
- Enforce the **canonical** `examples/canonical_mtls_localhost_8001.py` **real-server** gate at `localhost:8001` with `mtls_certificates`, including explicit reporting of the **`CANONICAL_EMBED_FILE_SERVER_PATH`** contract for **`embed_file`**.
- **Build** sdist/wheel, verify **twine check** (or equivalent), and **publish** to PyPI only if gates pass and credentials exist.

## Out of scope

- New features or non-release-blocking refactors (escalate if a gate failure requires a product change).

## Exit criteria

- Mandatory validation has **passed** or produced a **concrete blocker report** with evidence.
- Packaging prerequisites verified.
- Examples executed; canonical real-server gate satisfied per [`rv_canonical_mtls_real_server_gate/spec.md`](rv_canonical_mtls_real_server_gate/spec.md).
- **Published to PyPI** with version evidence, **or** exact blocker(s) documented.

## Related reports

| Report | Path |
|--------|------|
| Production migration closure | `docs/ai_reports/production_migration_completion_report.md` |
| Tests/scripts/deps closure | `docs/ai_reports/tests_scripts_and_dependency_cleanup_closure_report.md` |
| Migration inventory | `docs/ai_reports/tests_scripts_and_dependency_migration_inventory.md` |
| Documentation normalization closure | `docs/ai_reports/documentation_normalization_closure_report.md` |

## Tactical decomposition

See [`README.md`](README.md) for task ids **RV-01**–**RV-06**, dependencies, and parallelization notes.

## Atomic steps

Delegated to **`planner_auto`** — see [`steps/ATOMIC_STEPS_INDEX.md`](steps/ATOMIC_STEPS_INDEX.md) when present.

## Execution status

| Track | State |
|-------|--------|
| Tactical docs | Materialized under this directory per **LAYOUT-09** |
| Specialist execution (`tester_auto`, `coder_auto`, `planner_auto`) | **Blocked** when those agents cannot be invoked in the parent runtime — see `docs/ai_reports/release_validation_and_pypi_publication_closure_report.md` |
