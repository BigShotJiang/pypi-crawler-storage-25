<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# Release validation and PyPI publication — tactical index

## Parent links

| Document | Path |
|----------|------|
| Epic spec | [`../spec.md`](../spec.md) |
| Global plan | [`../plan.md`](../plan.md) |
| This global step (goal, exit criteria) | [`spec.md`](spec.md) |

## Tactical tasks (child specs)

| Id | Tactical task | Spec | Dependencies | Parallel with |
|----|---------------|------|----------------|---------------|
| RV-01 | Automated security-mode matrix (pytest harness) | [`rv_automated_security_matrix/spec.md`](rv_automated_security_matrix/spec.md) | none | RV-02, RV-03 (resource permitting) |
| RV-02 | Localhost vectorization check (real `localhost:8001`, usually mTLS) | [`rv_localhost_vectorization/spec.md`](rv_localhost_vectorization/spec.md) | none | RV-01, RV-03 |
| RV-03 | Surviving examples — executable sweep (non-canonical) | [`rv_surviving_examples_executable/spec.md`](rv_surviving_examples_executable/spec.md) | none | RV-01, RV-02 |
| RV-04 | Canonical mTLS real-server release gate | [`rv_canonical_mtls_real_server_gate/spec.md`](rv_canonical_mtls_real_server_gate/spec.md) | RV-01 recommended first (fail-fast on client regressions); real server must be up | after RV-01 if sharing one maintainer |
| RV-05 | Build artifacts and publication prerequisites | [`rv_packaging_and_prereqs/spec.md`](rv_packaging_and_prereqs/spec.md) | RV-01–RV-04 passed or blockers documented | none (sequential gate before publish) |
| RV-06 | PyPI publication | [`rv_pypi_publication/spec.md`](rv_pypi_publication/spec.md) | RV-05 satisfied; credentials available | none |

## Locked requirements (from epic + deploy rules)

- **No backward compatibility** obligation; release gates are forward-only.
- **Security modes** to cover: http; http + token; http + token + roles; https; https + token; https + token + roles; mtls; mtls + roles — enforced via repository test harness (see **RV-01**).
- **Vectorization** on real **`localhost:8001`** (usually mTLS), certs under **`mtls_certificates`** — **RV-02**.
- **Surviving examples** must run as real processes — **RV-03**.
- **`examples/canonical_mtls_localhost_8001.py`** against real **`localhost:8001`**, **`RUN_CANONICAL_MTLS_E2E=1`**, repo certs — **RV-04**; **`embed_file`** precondition: **`CANONICAL_EMBED_FILE_SERVER_PATH`** must be set to a **server-visible** path when the release gate is used to prove **all supported client capabilities**. If it is unset, the run must still capture the documented skip line, but that state is a **release blocker** for the full-capability gate.
- **Publish** only if all mandatory gates pass and **PyPI** credentials / access exist — **RV-06**.

## Atomic steps

Materialized under [`steps/`](steps/) by **`planner_auto`** when the runtime can invoke that agent. Do not duplicate tactical detail inside atomics beyond PR-sized units.

## Orchestration status

- **Tactical branch:** this README + child `spec.md` files are the program-of-record for the global step.
- **Execution:** validation, builds, and upload require **`tester_auto`** (pytest / harness), **`coder_auto`** (only if a release-blocking fix is needed), and optionally **`researcher_code`** for evidence audits — **not invocable from every Cursor agent runtime** (see closure report under `docs/ai_reports/`).
