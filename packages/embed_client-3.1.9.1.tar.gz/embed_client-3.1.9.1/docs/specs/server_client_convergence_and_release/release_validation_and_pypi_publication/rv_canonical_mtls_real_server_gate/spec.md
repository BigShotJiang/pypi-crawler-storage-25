<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# RV-04 — Canonical mTLS real-server release gate (`localhost:8001`)

## Purpose

Execute **`examples/canonical_mtls_localhost_8001.py`** against the **real** embedding server at **`localhost:8001`** with **mTLS**, using certificates from **`mtls_certificates`**, with **`RUN_CANONICAL_MTLS_E2E=1`**. This is a **mandatory** release gate: it must demonstrate **all supported client capabilities** that are safe to call on a live server.

## Parent links

| Document | Path |
|----------|------|
| Epic spec | [`../../spec.md`](../../spec.md) |
| Global step | [`../spec.md`](../spec.md) |
| Tactical index | [`../README.md`](../README.md) |
| Example README | [`../../../../../examples/README.md`](../../../../../examples/README.md) |

## Scope

**Included:**

- Running the canonical example in **live** mode per its docstring.
- **Reporting** the **`embed_file`** contract precisely:
  - Environment variable **`CANONICAL_EMBED_FILE_SERVER_PATH`** is the documented precondition for exercising **`embed_file`** in this tour.
  - For the **release gate**, it **must be set** to a **server-visible** UTF-8 path so **`embed_file`** is exercised and the branch proves **all supported client capabilities**.
  - When **unset** or empty, output must still include the **documented skip** line (exact substring behavior per **implementation** — current implementation references **`embed_file skipped`** and **`CANONICAL_EMBED_FILE_SERVER_PATH`** in `examples/canonical_mtls_localhost_8001.py`), but that run is **evidence of the contract only**, not a passing release gate.
- Capturing **full stdout/stderr**, exit code **0**, and listing which capabilities ran.

**Excluded:** Changing settled documentation design (per user constraint); only **release-blocking** code fixes go through **`coder_auto`**.

## Boundaries

- Certs: only **`mtls_certificates/`** paths as in the example (`client/`, `ca/` per repo layout).
- Do not fake the server; this gate is **live** only.

## Dependencies

- **RV-01** recommended first (fail-fast). **Real server** must be available on **8001**.

## Parallelization note

**Not parallel** with other **live** tests that exhaust the same server quota if unstable; otherwise may follow RV-02.

## Expected outcome

- Exit code **0** from the canonical example with **`RUN_CANONICAL_MTLS_E2E=1`**.
- Closure report documents **`CANONICAL_EMBED_FILE_SERVER_PATH`** state:
  - **Set:** path value used (non-secret path only) and confirmation **`embed_file`** ran.
  - **Unset:** explicit quote of the **skip** line from output proving the contract was enforced and visible, and the report marks this as a **release blocker** because full capability coverage was not demonstrated.

## Correction items

- If a capability is **missing** from the tour, **`researcher_code`** diffs vs **public API** list in `pyproject.toml` / `embed_client/__init__.py`; **`coder_auto`** extends example **only** via atomic step.

## Questions / escalation

- **Global orchestrator** if “all supported capabilities” definition conflicts with server safety (e.g. destructive ops).

## File inventory

| action | path | purpose |
|--------|------|---------|
| read | `examples/canonical_mtls_localhost_8001.py` | Canonical gate implementation |
| read | `tests/test_canonical_mtls_example.py` | Contract tests (dry/mock) |
| read | `examples/README.md` | User-facing run instructions |

## Class/function inventory

| Module | Symbol | Purpose |
|--------|--------|---------|
| `examples.canonical_mtls_localhost_8001` | `run_live_capabilities` (name per file) | Live tour — **verify** exact name via **`researcher_code`** if needed |
| `examples.canonical_mtls_localhost_8001` | `build_mtls_localhost_8001_config` (or equivalent) | Builds JSON config for **localhost:8001** **mTLS** |

**Signatures:** obtain exact signatures from the file via **`researcher_code`** when atomics are written; do not guess.

## Data structures

Not applicable at tactical level.

## Import map

Not applicable (execution).

## Error handling map

| Condition | Response |
|-----------|----------|
| `RUN_CANONICAL_MTLS_E2E` not set | Live gate **not executed** — **blocker** |
| TLS failure | Check certs and server trust |
| `CANONICAL_EMBED_FILE_SERVER_PATH` unset or blank | Record the exact skip line as contract evidence, then mark the release gate **failed** because `embed_file` was not exercised |

## Config dependency

| Key | Meaning |
|-----|---------|
| `RUN_CANONICAL_MTLS_E2E` | Must be **`1`** for live gate |
| `CANONICAL_EMBED_FILE_SERVER_PATH` | Required **server-visible** path for the release gate to exercise **`embed_file`**; unset/blank only proves the documented skip contract |

## Test plan

| Executor | Scope |
|----------|--------|
| **`tester_auto`** | Live run + capture logs |
| **`pytest`** | `tests/test_canonical_mtls_example.py` for dry/mock contract (supplementary, not replacing live gate) |

## Concrete examples

- **Unset `CANONICAL_EMBED_FILE_SERVER_PATH`:** Output line contains **`embed_file skipped`** (or exact string from source) and **`CANONICAL_EMBED_FILE_SERVER_PATH`**; release gate remains **blocked**.
- **Set path:** Tour includes successful **`embed_file`** call or documented server error if file unreadable (latter may be **blocker** — operator must pick valid path).

## Algorithm / procedure

1. Start **real** server **localhost:8001** **mTLS**.
2. Export **`RUN_CANONICAL_MTLS_E2E=1`**.
3. Export **`CANONICAL_EMBED_FILE_SERVER_PATH`** to a **server-readable** file.
4. Run **`python examples/canonical_mtls_localhost_8001.py`** from repo root (or `python -m` if documented).
5. Verify exit code **0** and capability coverage per docstring.

## Forbidden approaches

- Passing the gate using **only** pytest mocks **without** the **live** run.
- Omitting **`embed_file`** contract reporting from the closure report.
