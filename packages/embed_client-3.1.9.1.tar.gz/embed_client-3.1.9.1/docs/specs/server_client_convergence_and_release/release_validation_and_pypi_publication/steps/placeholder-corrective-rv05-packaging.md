<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# PLACEHOLDER — Corrective work after RV-05 packaging failure

## Activation

**Activate only if** [`rv05-build-artifacts-twine-version-gate.md`](rv05-build-artifacts-twine-version-gate.md) fails on **`twine check`**, **`python -m build`**, or **version mismatch**, and **`coder_auto`** is authorized.

## 1. Executor role

`coder_auto`.

## 2. Execution directive

Fix **`pyproject.toml`** metadata (README paths, classifiers, long description, `MANIFEST.in`, package data) or **`embed_client/__init__.py`** version fallback **only** as needed for **`twine check`** and version consistency — **minimal** diff.

## 3. Parent links (mandatory)

| Document | Path |
|----------|------|
| Epic | [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md) |
| Global step | [`docs/specs/server_client_convergence_and_release/release_validation_and_pypi_publication/spec.md`](../spec.md) |
| Owning tactical task | [`docs/specs/server_client_convergence_and_release/release_validation_and_pypi_publication/rv_packaging_and_prereqs/spec.md`](../rv_packaging_and_prereqs/spec.md) |

## 4. Step scope

| Field | Value |
|-------|--------|
| Target file | **TBD** — `pyproject.toml` and/or `embed_client/__init__.py` and/or `MANIFEST.in` (orchestrator assigns **one** primary file per PR) |

## 5. Dependency contract

- Twine / build error logs.

## 6–14. Deferred

LLAMA-complete when target file(s) assigned.

## 15. Mandatory validation

- Re-run [`rv05-build-artifacts-twine-version-gate.md`](rv05-build-artifacts-twine-version-gate.md) → **PASS**.
- **CR-007** on touched files.
