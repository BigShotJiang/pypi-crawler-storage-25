<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# PLACEHOLDER — Corrective actions after RV-06 upload failure

## Activation

**Activate only if** [`rv06-pypi-upload.md`](rv06-pypi-upload.md) fails with:

- **HTTP 401/403** (auth / permissions), **or**
- **Duplicate version** (file already exists for that version on PyPI), **or**
- Other **upload** errors after **`twine`** validation passed.

**Do not** use this placeholder for **RV-05** `twine check` / build failures — use [`placeholder-corrective-rv05-packaging.md`](placeholder-corrective-rv05-packaging.md).

## 1. Executor role

- **Auth/permissions:** maintainer / infrastructure — **no** token in repo.
- **Duplicate version:** **`coder_auto`** after **global** approval to bump **`pyproject.toml`** `[project].version` and matching **`embed_client.__version__`** fallback literal in **`embed_client/__init__.py`** (and any other version source per project policy).

## 2. Execution directive

- **Auth:** obtain credentials or trusted publishing — **retry** [`rv06-pypi-upload.md`](rv06-pypi-upload.md) **without** code changes.
- **Duplicate:** orchestrator approves new version **V+1**; single atomic step targeting **both** `pyproject.toml` and `embed_client/__init__.py` **must** be planned as a **separate fully LLAMA-resolved** atom — this file remains a **pointer** until refreshed.

## 3. Parent links (mandatory)

| Document | Path |
|----------|------|
| Epic | [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md) |
| Global step | [`docs/specs/server_client_convergence_and_release/release_validation_and_pypi_publication/spec.md`](../spec.md) |
| Owning tactical task | [`docs/specs/server_client_convergence_and_release/release_validation_and_pypi_publication/rv_pypi_publication/spec.md`](../rv_pypi_publication/spec.md) |

## 4. Step scope

| Case | Action |
|------|--------|
| Auth | No repo file change |
| Version bump | **TBD** — `pyproject.toml` + `embed_client/__init__.py` per orchestrator |

## 5. Mandatory validation (after version bump)

- Re-run [`rv05-build-artifacts-twine-version-gate.md`](rv05-build-artifacts-twine-version-gate.md).
- Re-run [`rv06-pypi-upload.md`](rv06-pypi-upload.md).

## 6. Forbidden

- Silent version bump without **global** approval (**RV-06** tactical **Correction items**).
