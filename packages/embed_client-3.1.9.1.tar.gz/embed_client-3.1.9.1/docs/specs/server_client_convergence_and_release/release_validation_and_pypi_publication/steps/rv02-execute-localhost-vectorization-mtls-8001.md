<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# RV-02 — Localhost vectorization smoke (`localhost:8001`, mTLS)

## 1. Executor role

`tester_auto` or release operator with active `.venv` and a **real** embedding server on **localhost:8001** using **mTLS**.

## 2. Execution directive

Run **`embed-vectorize`** once with **`configs/mtls_8001.json`** (not `configs/mtls_8001_test.json`) and benign sample text. Capture **exit code 0** and stdout/stderr excerpt for the closure report.

## 3. Parent links (mandatory)

| Document | Path |
|----------|------|
| Epic | [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md) |
| Global step | [`docs/specs/server_client_convergence_and_release/release_validation_and_pypi_publication/spec.md`](../spec.md) |
| Owning tactical task | [`docs/specs/server_client_convergence_and_release/release_validation_and_pypi_publication/rv_localhost_vectorization/spec.md`](../rv_localhost_vectorization/spec.md) |

## 4. Step scope

| Field | Value |
|-------|--------|
| Target repository file | **none** |
| Deliverable | Evidence in `docs/ai_reports/` or CI log (non-secret) |

## 5. Dependency contract

- **Upstream:** None (Wave A, parallel with RV-01/03 if ports isolated — **8001** vs **100xx**).
- **Downstream:** **RV-05** expects RV-02 green or documented blocker.

## 6. Required context

- Server listening on **127.0.0.1:8001** with **mTLS** matching `configs/mtls_8001.json`.
- Certificates under `mtls_certificates/` as referenced by that JSON.

## 7. Read first

- `CLI_README.md` — `embed-vectorize` subcommands.
- `configs/mtls_8001.json` — **required** config for this gate (**do not** substitute `configs/mtls_8001_test.json`).
- `mtls_certificates/README.md` (if present).

## 8. Expected file change

- Optional evidence note only under `docs/ai_reports/`.

## 9. Forbidden alternatives

- Using **`configs/mtls_8001_test.json`** for this gate.
- Mocking transport or using plain HTTP for this check when the rule calls for **mTLS** on **8001**.

## 10. Atomic operations

1. Activate `.venv` (**CR-005**).
2. Install package editable if needed: `pip install -e ".[dev]"` so `embed-vectorize` is on `PATH`.
3. Confirm real server on **localhost:8001** (operator responsibility).
4. From repository root:

   ```bash
   embed-vectorize --config ./configs/mtls_8001.json vectorize "hello"
   ```

   If `CLI_README.md` documents a different invocation order or flags for the same operation, follow **`CLI_README.md`** but **always** pass **`./configs/mtls_8001.json`** as the config path.

5. Record exit code (must be **0**), and stdout/stderr (truncate secrets if any — there should be none in config).

## 11. Expected deliverables

- Evidence: exact command line, exit code **0**, success output indicating vectorization completed or vectors returned per CLI behavior.

## 12. Mandatory validation

| Check | Expected |
|-------|----------|
| Exit code | **0** |
| Config path in command | **`./configs/mtls_8001.json`** (or equivalent relative path resolving to that file) |

**Mandatory completion:** This step’s own command succeeds; full-repo pytest is out of scope unless closure template requires it.

## 13. Decision rules

- **PASS:** exit **0** with real server.
- **BLOCKER:** connection refused, TLS handshake failure, non-zero exit, or wrong config file used.

## 14. Blackstops

- Server not running — stop; fix environment; do not fake success.

## 15. Handoff package

- Log + verdict **PASS**/**BLOCKER**.
- On failure needing code: [`placeholder-corrective-rv02-vectorization.md`](placeholder-corrective-rv02-vectorization.md).

---

## LLAMA-readiness (execution step)

| Field | Value |
|-------|--------|
| Target file full path | **none** |
| Complete import list | **N/A** |
| Constants | Config: **`configs/mtls_8001.json`**; sample text: **`hello`**; host/port from JSON: **localhost**, **8001**; protocol **mtls** |
| Forbidden patterns | Substituting **`mtls_8001_test.json`** |
