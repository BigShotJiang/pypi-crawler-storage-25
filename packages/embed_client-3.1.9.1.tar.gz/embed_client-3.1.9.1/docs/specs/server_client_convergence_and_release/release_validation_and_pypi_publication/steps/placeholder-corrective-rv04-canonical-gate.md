<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# PLACEHOLDER — Corrective work after RV-04 canonical live gate failure

## Activation

**Activate only if** [`rv04-execute-canonical-mtls-real-server-gate.md`](rv04-execute-canonical-mtls-real-server-gate.md) fails due to **code/example** defect (not server ops), or [`rv04-supplementary-pytest-canonical-example-contract.md`](rv04-supplementary-pytest-canonical-example-contract.md) fails, and governance approves **`coder_auto`** work.

## 1. Executor role

`coder_auto`; optional `researcher_code` for API parity vs `embed_client/__init__.py` / `pyproject.toml`.

## 2. Execution directive

Extend or fix **`examples/canonical_mtls_localhost_8001.py`** and/or **`tests/test_canonical_mtls_example.py`** **only** as needed so the **live** tour matches **all supported client capabilities** (per tactical task) — **minimal** diff.

## 3. Parent links (mandatory)

| Document | Path |
|----------|------|
| Epic | [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md) |
| Global step | [`docs/specs/server_client_convergence_and_release/release_validation_and_pypi_publication/spec.md`](../spec.md) |
| Owning tactical task | [`docs/specs/server_client_convergence_and_release/release_validation_and_pypi_publication/rv_canonical_mtls_real_server_gate/spec.md`](../rv_canonical_mtls_real_server_gate/spec.md) |

## 4. Step scope

| Field | Value |
|-------|--------|
| Target file | **TBD at activation** — typically **`examples/canonical_mtls_localhost_8001.py`** **or** **`tests/test_canonical_mtls_example.py`** (one PR per assigned file) |

## 5. Dependency contract

- Traceback / missing capability list from RV-04 evidence.

## 6–14. Deferred

Full LLAMA detail when target file is fixed.

## 15. Mandatory validation

- Re-run [`rv04-supplementary-pytest-canonical-example-contract.md`](rv04-supplementary-pytest-canonical-example-contract.md) if tests changed.
- Re-run [`rv04-execute-canonical-mtls-real-server-gate.md`](rv04-execute-canonical-mtls-real-server-gate.md) for **live** path.
- **CR-007** on touched Python.
