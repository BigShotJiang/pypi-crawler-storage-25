<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# RV-04 — Supplementary: pytest contract for canonical example (dry/mock)

## 1. Executor role

`tester_auto` or operator.

## 2. Execution directive

Run **`tests/test_canonical_mtls_example.py`** to validate **dry/mock** contracts. This **supplements** but **does not replace** the **live** gate in [`rv04-execute-canonical-mtls-real-server-gate.md`](rv04-execute-canonical-mtls-real-server-gate.md).

## 3. Parent links (mandatory)

| Document | Path |
|----------|------|
| Epic | [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md) |
| Global step | [`docs/specs/server_client_convergence_and_release/release_validation_and_pypi_publication/spec.md`](../spec.md) |
| Owning tactical task | [`docs/specs/server_client_convergence_and_release/release_validation_and_pypi_publication/rv_canonical_mtls_real_server_gate/spec.md`](../rv_canonical_mtls_real_server_gate/spec.md) |

## 4. Step scope

| Field | Value |
|-------|--------|
| Target repository file | **none** |

## 5. Dependency contract

- **Upstream:** None — may run in **Wave A** (parallel with RV-01, RV-02, RV-03) because **no** `localhost:8001` server required for typical dry tests.
- **Downstream:** Optional fail-fast signal before live **RV-04**; **live** gate still mandatory.

## 6. Required context

- Active `.venv`; `pip install -e ".[test]"` or `".[dev]"`.

## 7. Read first

- `tests/test_canonical_mtls_example.py`
- `examples/canonical_mtls_localhost_8001.py` — `build_mtls_localhost_8001_config`, `run_live_capabilities`, `main`

## 8. Expected file change

- None.

## 9. Forbidden alternatives

- Claiming **RV-04** complete with **only** this pytest run.

## 10. Atomic operations

1. From repository root with `.venv` active:

   ```bash
   pytest tests/test_canonical_mtls_example.py -vv --tb=short
   ```

2. Record exit code (must be **0**) and failures if any.

## 11. Expected deliverables

- Log excerpt; verdict **PASS**/**FAIL**.

## 12. Mandatory validation

- Exit code **0**; all tests **passed** (no **skipped** substituting for live gate).

## 13. Decision rules

- Failure here → fix tests or example **via** corrective atom before release, but **live** [`rv04-execute-canonical-mtls-real-server-gate.md`](rv04-execute-canonical-mtls-real-server-gate.md) remains required.

## 14. Blackstops

- N/A.

## 15. Handoff package

- Evidence for closure report “supplementary pytest” line.

---

## LLAMA-readiness

| Field | Value |
|-------|--------|
| Validation command | `pytest tests/test_canonical_mtls_example.py -vv --tb=short` |
| Expected | Exit **0**, all **passed** |
