<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# RV-05 — Build sdist/wheel, twine check, version consistency

## 1. Executor role

`tester_auto` or operator with `.venv` and permission to create **`dist/`**.

## 2. Execution directive

Install the external **`build`** package, run **`python -m build`** (PEP 517 — repository build backend is **`setuptools.build_meta`** per `pyproject.toml` `[build-system]`), run **`twine check`** on artifacts, and verify **`[project].version`** in **`pyproject.toml`** matches **`embed_client.__version__`** when the package is installed per §10.

## 3. Parent links (mandatory)

| Document | Path |
|----------|------|
| Epic | [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md) |
| Global step | [`docs/specs/server_client_convergence_and_release/release_validation_and_pypi_publication/spec.md`](../spec.md) |
| Owning tactical task | [`docs/specs/server_client_convergence_and_release/release_validation_and_pypi_publication/rv_packaging_and_prereqs/spec.md`](../rv_packaging_and_prereqs/spec.md) |

## 4. Step scope

| Field | Value |
|-------|--------|
| Target repository file | **none** (artifacts under `dist/` gitignored) |

## 5. Dependency contract

- **Upstream:** **RV-01**, **RV-02**, **RV-03**, **RV-04** **PASS** or governance **waiver** (default: no waiver) — **Wave C** after validation gates.

## 6. Required context

- Clean or acceptable `dist/` (remove old artifacts if policy requires **clean** build: `rm -rf dist/ build/ *.egg-info` before build — follow repo hygiene).

## 7. Read first

- `pyproject.toml` — `[build-system]` (`requires`, `build-backend`), `[project]` `name`, `version`.
- `embed_client/__init__.py` — `__version__` (via `importlib.metadata.version("embed-client")` when installed).

## 8. Expected file change

- `dist/*.tar.gz`, `dist/*.whl` (local only, not committed).

## 9. Forbidden alternatives

- Uploading to PyPI in this step (**RV-06** only).
- Bumping version without **global** approval.

## 10. Atomic operations

1. Activate `.venv`.
2. Ensure editable install so metadata matches release: `pip install -e .` (or project-standard equivalent).
3. **Version consistency:**

   ```bash
   python -c "import embed_client; print(embed_client.__version__)"
   ```

   Compare the printed string to **`version = "..."`** in **`pyproject.toml`** under **`[project]`** — must be **identical**.

4. Install the **`build`** frontend **into the venv** (external package, not the stdlib):

   ```bash
   pip install build
   ```

5. Build:

   ```bash
   python -m build
   ```

   This invokes **`setuptools.build_meta`** as declared in **`pyproject.toml`** — do **not** replace with a custom backend unless orchestrator changes the spec.

6. Check:

   ```bash
   twine check dist/*
   ```

7. Record: filenames in **`dist/`**, **`twine check`** output (**passed**), and version string.

## 11. Expected deliverables

- **`dist/`** contains **`.tar.gz`** and **`.whl`** for the current **`[project].version`**.
- **`twine check`** success.
- Version match **documented**.

## 12. Mandatory validation

| Step | Command / check | Expected |
|------|-------------------|----------|
| Version | String compare | `pyproject.toml` `[project].version` == `embed_client.__version__` |
| Build | `python -m build` | Exit **0** |
| Twine | `twine check dist/*` | Exit **0**, no errors |

**Full test suite:** optional in this atom; tactical **mandatory completion** is **all tests pass** for the release branch — run full **`pytest`** per **CR-007** if closure report requires it **after** this gate or as part of final sign-off.

## 13. Decision rules

- **BLOCKER:** `twine check` failure, version mismatch, or `python -m build` failure.
- Escalate to [`placeholder-corrective-rv05-packaging.md`](placeholder-corrective-rv05-packaging.md).

## 14. Blackstops

- Missing **`build`** package: `pip install build` and retry **before** declaring failure.

## 15. Handoff package

- Artifact names + SHA256 (optional) + twine output.
- Next: [`rv06-pypi-upload.md`](rv06-pypi-upload.md).

---

## LLAMA-readiness (execution)

| Field | Value |
|-------|--------|
| Build backend | **`setuptools.build_meta`** (`pyproject.toml` `[build-system]`) |
| Build invocation | **`python -m build`** after **`pip install build`** |
| Twine | **`twine check dist/*`** |
| Constants | Package name **`embed-client`**; version from **`pyproject.toml`** |
