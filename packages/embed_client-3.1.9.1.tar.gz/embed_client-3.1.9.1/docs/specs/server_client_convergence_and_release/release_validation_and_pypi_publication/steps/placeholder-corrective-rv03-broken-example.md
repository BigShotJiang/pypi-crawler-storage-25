<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# PLACEHOLDER — Corrective work after RV-03 example failure

## Activation

**Activate only if** [`rv03-execute-surviving-examples-sweep.md`](rv03-execute-surviving-examples-sweep.md) reports a **release-blocking** failure (import error, crash) in an example that should work under documented preconditions.

## 1. Executor role

`coder_auto` to repair the **single** broken example file; `tester_auto` re-runs the sweep.

## 2. Execution directive

Fix **removed symbols**, broken imports, or docstring/run mismatch with **minimal** edits to the **one** example file assigned at activation.

## 3. Parent links (mandatory)

| Document | Path |
|----------|------|
| Epic | [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md) |
| Global step | [`docs/specs/server_client_convergence_and_release/release_validation_and_pypi_publication/spec.md`](../spec.md) |
| Owning tactical task | [`docs/specs/server_client_convergence_and_release/release_validation_and_pypi_publication/rv_surviving_examples_executable/spec.md`](../rv_surviving_examples_executable/spec.md) |

## 4. Step scope

| Field | Value |
|-------|--------|
| Target file | **TBD at activation** — one of `examples/*.py` or `embed_client/example_async_usage*.py` (**not** the excluded demo helpers unless orchestrator explicitly scopes a different fix) |
| action | **modify** |

## 5. Dependency contract

- Traceback from RV-03 table row.

## 6–14. Deferred

LLAMA-complete step **after** target path and failure mode are fixed by orchestrator.

## 15. Mandatory validation

- Re-run [`rv03-execute-surviving-examples-sweep.md`](rv03-execute-surviving-examples-sweep.md) for the affected row → exit **0**.
- **CR-007** on modified file.
