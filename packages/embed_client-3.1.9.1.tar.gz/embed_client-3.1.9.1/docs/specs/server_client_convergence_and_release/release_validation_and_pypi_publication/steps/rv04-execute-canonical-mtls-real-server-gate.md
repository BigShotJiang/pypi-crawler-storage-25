<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# RV-04 — Canonical mTLS real-server release gate (`localhost:8001`)

## 1. Executor role

`tester_auto` or operator with real server on **localhost:8001** (**mTLS**) and repo certs.

## 2. Execution directive

Run **`python examples/canonical_mtls_localhost_8001.py`** from repository root with **`RUN_CANONICAL_MTLS_E2E=1`**. For a **passing** full-capability release gate, set **`CANONICAL_EMBED_FILE_SERVER_PATH`** to a **non-empty, server-visible UTF-8 path** to a file the embedding server can read so **`embed_file`** executes. If **`CANONICAL_EMBED_FILE_SERVER_PATH`** is **unset** or **blank**, stdout must still show the documented **skip** line containing **`embed_file skipped`** and **`CANONICAL_EMBED_FILE_SERVER_PATH`** — that proves the **skip contract** but is a **release blocker** for the full-capability gate (per tactical spec and [`../README.md`](../README.md)).

## 3. Parent links (mandatory)

| Document | Path |
|----------|------|
| Epic | [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md) |
| Global step | [`docs/specs/server_client_convergence_and_release/release_validation_and_pypi_publication/spec.md`](../spec.md) |
| Owning tactical task | [`docs/specs/server_client_convergence_and_release/release_validation_and_pypi_publication/rv_canonical_mtls_real_server_gate/spec.md`](../rv_canonical_mtls_real_server_gate/spec.md) |

## 4. Step scope

| Field | Value |
|-------|--------|
| Target repository file | **none** |
| Deliverable | Full **stdout/stderr** capture, exit code, closure report subsection |

## 5. Dependency contract

- **Recommended upstream:** [`rv01-execute-automated-security-matrix.md`](rv01-execute-automated-security-matrix.md) **PASS** (fail-fast).
- **Parallel:** May follow [`rv02-execute-localhost-vectorization-mtls-8001.md`](rv02-execute-localhost-vectorization-mtls-8001.md) when server quota allows — **Wave B**.

## 6. Required context

- Real embedding server **localhost:8001** with **mTLS**; certs **`mtls_certificates/client/`**, **`mtls_certificates/ca/`** per `examples/canonical_mtls_localhost_8001.py`.
- A **server-readable** file path for **`CANONICAL_EMBED_FILE_SERVER_PATH`** (operator-chosen; **non-secret**; document basename only in reports if needed).

## 7. Read first

- `examples/canonical_mtls_localhost_8001.py` — `build_mtls_localhost_8001_config`, `run_live_capabilities`, `main`, **`embed_file`** branch (lines using **`CANONICAL_EMBED_FILE_SERVER_PATH`**).
- `examples/README.md`

## 8. Expected file change

- Optional evidence under `docs/ai_reports/` only.

## 9. Forbidden alternatives

- Passing the release using **only** [`rv04-supplementary-pytest-canonical-example-contract.md`](rv04-supplementary-pytest-canonical-example-contract.md) **without** this **live** run.
- Claiming full-capability **PASS** when output contains **`embed_file skipped`** (i.e. **`CANONICAL_EMBED_FILE_SERVER_PATH`** unset/blank).

## 10. Atomic operations

1. Start/confirm real server on **8001** (**mTLS**).
2. Choose a **`CANONICAL_EMBED_FILE_SERVER_PATH`** value that exists on the **server** filesystem and is readable by the service (operator responsibility).
3. From repository root:

   ```bash
   export RUN_CANONICAL_MTLS_E2E=1
   export CANONICAL_EMBED_FILE_SERVER_PATH="<server-visible-path>"
   python examples/canonical_mtls_localhost_8001.py
   ```

4. **Release gate PASS criteria:**
   - Exit code **0**.
   - Stdout includes a line proving **`embed_file`** ran successfully (e.g. line starting with **`embed_file:`** from the success branch — see implementation in `run_live_capabilities`), **not** the **`embed_file skipped;`** line.
5. **Contract-only run (blocker for full gate):** If **`CANONICAL_EMBED_FILE_SERVER_PATH`** is **unset** or **whitespace-only**, run the same command **without** setting the variable (or set it empty). Expect exit **0** and a line containing **`embed_file skipped`** and **`CANONICAL_EMBED_FILE_SERVER_PATH`**. Record this as **skip contract verified** and mark overall **RV-04 full-capability gate FAILED (blocker)** in the closure report.
6. List which capabilities printed (health, models, …) per stdout for the **PASS** case.

## 11. Expected deliverables

- **PASS path:** logs + confirmation **`embed_file`** executed + **`CANONICAL_EMBED_FILE_SERVER_PATH`** noted (non-secret).
- **Unset path (documentation only):** exact quoted **skip** line in report + **BLOCKER** flag.

## 12. Mandatory validation

| Check | Expected for PASS |
|-------|-------------------|
| `RUN_CANONICAL_MTLS_E2E` | **`1`** |
| Exit code | **0** |
| `CANONICAL_EMBED_FILE_SERVER_PATH` | **Set**, non-whitespace, **server-visible** file |
| Stdout | Must **not** contain **`embed_file skipped;`** for PASS |

## 13. Decision rules

- **`RUN_CANONICAL_MTLS_E2E` ≠ `1`:** live gate **not executed** → **BLOCKER**.
- **Skip line present:** contract documented → **BLOCKER** for full release until path set and re-run **PASS**.

## 14. Blackstops

- TLS failures → fix certs/server before claiming PASS.

## 15. Handoff package

- Evidence + verdict; on code gap → [`placeholder-corrective-rv04-canonical-gate.md`](placeholder-corrective-rv04-canonical-gate.md).

---

## LLAMA-readiness (execution)

| Field | Value |
|-------|--------|
| Env | `RUN_CANONICAL_MTLS_E2E` = **`1`** |
| Env (PASS) | `CANONICAL_EMBED_FILE_SERVER_PATH` = **non-empty** server path |
| Skip line substring (contract) | **`embed_file skipped;`** and **`CANONICAL_EMBED_FILE_SERVER_PATH`** (exact text in source lines 196–198 of `examples/canonical_mtls_localhost_8001.py`) |
| Command | `python examples/canonical_mtls_localhost_8001.py` from repo root |
| Key functions | `build_mtls_localhost_8001_config`, `run_live_capabilities`, `main` |
