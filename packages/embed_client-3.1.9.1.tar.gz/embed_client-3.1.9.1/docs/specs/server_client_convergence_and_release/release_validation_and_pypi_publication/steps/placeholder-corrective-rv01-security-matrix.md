<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# PLACEHOLDER — Corrective work after RV-01 security matrix failure

## Activation

**Activate only if** [`rv01-execute-automated-security-matrix.md`](rv01-execute-automated-security-matrix.md) ends in **BLOCKER** and governance approves a **code or test harness** fix (not environment provisioning).

## 1. Executor role

`coder_auto` (implementation) with findings from `tester_auto` / traceback; `tester_auto` re-runs the matrix after the fix.

## 2. Execution directive

Implement the **minimal** change to restore a **true** pass of `tests/test_all_security_modes.py` **without** masking missing backends via broad skips. Do not weaken the **full** eight-mode requirement from [`.cursor/rules/deploy.mdc`](../../../../../.cursor/rules/deploy.mdc).

## 3. Parent links (mandatory)

| Document | Path |
|----------|------|
| Epic | [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md) |
| Global step | [`docs/specs/server_client_convergence_and_release/release_validation_and_pypi_publication/spec.md`](../spec.md) |
| Owning tactical task | [`docs/specs/server_client_convergence_and_release/release_validation_and_pypi_publication/rv_automated_security_matrix/spec.md`](../rv_automated_security_matrix/spec.md) |

## 4. Step scope

| Field | Value |
|-------|--------|
| Target file(s) | **TBD at activation** — exactly one PR per corrective atomic step; typical candidates: `tests/test_all_security_modes.py`, or client code if contract bug proven |
| action | **modify** (or **create** only if orchestrator adds a new helper module) |

**Pre-resolution at activation:** The parent orchestrator must assign **one** target file path for this placeholder instance.

## 5. Dependency contract

- **Depends on:** failed RV-01 evidence (traceback, failing test name).
- **Blocks:** re-run of [`rv01-execute-automated-security-matrix.md`](rv01-execute-automated-security-matrix.md).

## 6. Required context

- Root cause category: (a) client regression, (b) harness bug, (c) deprecation/policy, (d) test server script drift.

## 7. Read first

- Failing test and `tests/test_all_security_modes.py`.
- `docs/specs/server_client_convergence_and_release/release_validation_and_pypi_publication/rv_automated_security_matrix/spec.md` — **Correction items**.

## 8. Expected file change

- Minimal diff fixing the **observed** failure; **no** drive-by refactors.

## 9. Forbidden alternatives

- Replacing `pytest.skip` with silent `pass` while services are still down.
- Removing integration tests to “green” CI.

## 10. Atomic operations

**Deferred** until activation: import lists, signatures, and algorithms are **filled by the next `planner_auto` refresh** after the target file is known, **or** by `orchestrator_tactical` handoff with the same LLAMA detail.

## 11. Expected deliverables

- Green re-run per [`rv01-execute-automated-security-matrix.md`](rv01-execute-automated-security-matrix.md).

## 12. Mandatory validation

- `pytest tests/test_all_security_modes.py -vv --tb=short -ra` → exit **0**, **no** service-absence **skipped** lines in summary.
- If target file is Python: **black**, **flake8**, **mypy** on that file per **CR-007**.

## 13. Decision rules

- If failure was **only** missing Docker/test servers → **do not** use this placeholder; fix **environment** and re-run RV-01.

## 14. Blackstops

- Multiple unrelated target files needed → split into separate corrective atoms via orchestrator.

## 15. Handoff package

- PR link + re-run logs satisfying RV-01.

---

## LLAMA-readiness note

This file is intentionally a **placeholder**: full LLAMA fields (imports, signatures, step-by-step algorithms) **must** be completed when the **single target file** is assigned at activation.
