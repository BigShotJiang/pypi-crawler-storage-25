<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# RV-01 — Execute automated security-mode matrix (pytest)

## 1. Executor role

`tester_auto` or release operator with shell access and active `.venv`.

## 2. Execution directive

Run the full integration matrix in `tests/test_all_security_modes.py` with all backing test servers available so that **no test is skipped** for missing services. Capture evidence for the closure report. Do **not** treat `pytest` exit code **0** alone as success if the run contains broad **`pytest.skip(...)`** due to absent backends.

## 3. Parent links (mandatory)

| Document | Path |
|----------|------|
| Epic (program-of-record) | [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md) |
| Global step (this branch) | [`docs/specs/server_client_convergence_and_release/release_validation_and_pypi_publication/spec.md`](../spec.md) |
| Owning tactical task | [`docs/specs/server_client_convergence_and_release/release_validation_and_pypi_publication/rv_automated_security_matrix/spec.md`](../rv_automated_security_matrix/spec.md) |

**Coherence:** This step implements the default path of **RV-01**. It must satisfy [`../rv_automated_security_matrix/spec.md`](../rv_automated_security_matrix/spec.md), including the rule that missing services leading to skips are a **release blocker**, not a pass.

## 4. Step scope

| Field | Value |
|-------|--------|
| Target repository file | **none** (`action: none`) |
| Deliverable | Terminal transcript and/or CI log reference **and** a short evidence note under `docs/ai_reports/` (filename at operator discretion, e.g. `release_validation_rv01_security_matrix.md`) |

## 5. Dependency contract

- **Upstream:** None (Wave A).
- **Downstream:** **RV-04** may assume **RV-01** green for fail-fast policy; **RV-05** requires **RV-01** green or documented waiver.

## 6. Required context

- Test ports **10001–10003**, **10011–10013**, **10021–10022** per `TEST_CONFIGS` in `tests/test_all_security_modes.py` must have matching test-server processes as documented for this repository.
- Virtualenv active per **CR-005** (`.venv`).

## 7. Read first (exact paths)

- `tests/test_all_security_modes.py` — `TEST_CONFIGS`, `is_service_available`, skip messages.
- `pyproject.toml` — `[tool.pytest.ini_options]` (`addopts`, markers, timeout).
- Optional: `scripts/` — any documented test-server startup for the matrix.

## 8. Expected file change

- **Optional:** append or create a **non-secret** evidence file under `docs/ai_reports/` with command, exit code, and pytest short summary (no tokens).

## 9. Forbidden alternatives

- Interpreting **skipped** integration tests as a passing release gate.
- Running a **subset** of modes or deleting tests to force green.
- Pointing the harness at undocumented production hosts without epic approval.

## 10. Atomic operations (procedure)

1. `cd` to repository root.
2. Activate `.venv` (**CR-005**).
3. Ensure dev/test deps: `pip install -e ".[dev]"` or `pip install -e ".[test]"` as needed.
4. Start or confirm all **test servers** required for every `TEST_CONFIGS` key (http_simple … mtls_roles) on **localhost** ports **10001–10003**, **10011–10013**, **10021–10022** until `is_service_available(<mode>)` would return **True** for each mode (or follow project scripts that guarantee that).
5. Run:

   ```bash
   pytest tests/test_all_security_modes.py -vv --tb=short -ra
   ```

   If the repo’s pytest `addopts` (e.g. `-n auto`) causes issues with integration fixtures, re-run with explicit override only if **documented** for this repo, e.g. `pytest tests/test_all_security_modes.py -vv --tb=short -ra -n0` — prefer the **default** `pyproject.toml` settings unless they prevent the matrix from running.

6. **Pass/fail for release (in addition to pytest exit code 0):**
   - Parse the pytest **short test summary** (`-ra`): **zero** tests **skipped** for reasons like `HTTP simple service not available`, `mTLS simple service not available`, etc.
   - If **any** such skip appears, classify the gate as **FAILED (blocker)** per tactical spec, even if exit code is **0**.

7. Record: full command line, exit code, and the **skipped/passed/failed** counts from the summary.

## 11. Expected deliverables

- Evidence artifact (log or `docs/ai_reports/` snippet) showing **all** mode tests **passed** and **no service-absence skips**.
- Verdict line for closure report: **PASS** or **BLOCKER (skips present / failures)**.

## 12. Mandatory validation

| Check | Expected |
|-------|----------|
| `pytest` exit code | **0** |
| Skip count for service-unavailable messages | **0** |
| Tests exercised | All async integration tests under `tests/test_all_security_modes.py` that correspond to the eight deploy.mdc modes |

**Project validation (if code touched — not expected here):** N/A.

**Mandatory completion:** All **project** tests are **not** required in this single step beyond this file’s pytest scope; the tactical task requires this matrix specifically. Full-repo `pytest` may be required elsewhere per **CR-007** — follow closure report template.

## 13. Decision rules

- **PASS:** exit **0** and **no** `pytest.skip` triggered for missing services in this file’s run.
- **BLOCKER:** any skip as above, or any failed test, or non-zero exit code.
- **Escalation to** [`placeholder-corrective-rv01-security-matrix.md`](placeholder-corrective-rv01-security-matrix.md) **only** on failure that requires code or harness changes.

## 14. Blackstops

- Stop and report **BLOCKER** if test servers cannot be provisioned — do not waive.
- Stop if **`tester_auto`** / operator cannot run shell commands (**CR-018**).

## 15. Handoff package

- Log excerpt showing **0 skipped** (service-unavailable) and **0 failed**.
- If blocker: pointer to [`placeholder-corrective-rv01-security-matrix.md`](placeholder-corrective-rv01-security-matrix.md).

---

## LLAMA-readiness (execution step)

| Field | Value |
|-------|--------|
| Target file full path | **none** |
| File header | N/A |
| Complete import list | **N/A** — no Python module produced |
| Class/function skeleton | **N/A** |
| Method logic | **N/A** |
| Error handling | Shell: non-zero pytest → BLOCKER; skips → BLOCKER per §10 |
| Return value | Exit code and summary text captured in evidence |
| Edge cases | `pytest -n auto` / xdist: ensure workers do not break fixtures; use documented overrides only |
| Exact validation commands | See §10 step 5–6 |
| Exact test expectations | Every `test_*` in `tests/test_all_security_modes.py` for the eight modes: **passed**, not **skipped** |
| Forbidden patterns | Claiming pass when summary shows skips |
| Constants and literals | Ports: **10001, 10002, 10003, 10011, 10012, 10013, 10021, 10022** from `TEST_CONFIGS` |
