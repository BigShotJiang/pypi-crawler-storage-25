<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# PLACEHOLDER — Corrective work after RV-02 vectorization failure

## Activation

**Activate only if** [`rv02-execute-localhost-vectorization-mtls-8001.md`](rv02-execute-localhost-vectorization-mtls-8001.md) fails with a **client-side defect** (not operator/server-down), and governance approves code changes.

## 1. Executor role

`coder_auto`; `tester_auto` verifies.

## 2. Execution directive

Minimal fix to `embed_client.cli` (or documented config resolution) so **`embed-vectorize --config ./configs/mtls_8001.json vectorize "hello"`** succeeds against a healthy server — **without** switching this gate to `mtls_8001_test.json`.

## 3. Parent links (mandatory)

| Document | Path |
|----------|------|
| Epic | [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md) |
| Global step | [`docs/specs/server_client_convergence_and_release/release_validation_and_pypi_publication/spec.md`](../spec.md) |
| Owning tactical task | [`docs/specs/server_client_convergence_and_release/release_validation_and_pypi_publication/rv_localhost_vectorization/spec.md`](../rv_localhost_vectorization/spec.md) |

## 4. Step scope

| Field | Value |
|-------|--------|
| Target file | **TBD at activation** — typically `embed_client/cli.py` or related helper (single file per corrective PR unless orchestrator splits) |
| action | **modify** |

## 5. Dependency contract

- Depends on: RV-02 failure logs.
- Blocks: RV-02 re-run.

## 6–15. Deferred detail

Full LLAMA import lists, signatures, and algorithms **must** be completed when the target file is assigned. **Forbidden:** changing [`rv02-execute-localhost-vectorization-mtls-8001.md`](rv02-execute-localhost-vectorization-mtls-8001.md) to use **`configs/mtls_8001_test.json`** as the release gate — that would violate **RV-02** tactical spec.

## Mandatory validation (post-fix)

- Re-run [`rv02-execute-localhost-vectorization-mtls-8001.md`](rv02-execute-localhost-vectorization-mtls-8001.md) → **PASS**.
- **CR-007** on modified Python files.
