<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# RV-06 — PyPI publication (twine upload)

## 1. Executor role

Maintainer or `tester_auto` with **PyPI** credentials (**API token** or trusted publishing) — **never** logged or committed.

## 2. Execution directive

Upload **`dist/*`** from **RV-05** to **PyPI** using **`twine upload`**, only if **RV-01–RV-05** evidence is **PASS** (or waived per governance) and maintainer **authorizes** release. Record **version** and **public** verification (project page or `pip install` smoke).

## 3. Parent links (mandatory)

| Document | Path |
|----------|------|
| Epic | [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md) |
| Global step | [`docs/specs/server_client_convergence_and_release/release_validation_and_pypi_publication/spec.md`](../spec.md) |
| Owning tactical task | [`docs/specs/server_client_convergence_and_release/release_validation_and_pypi_publication/rv_pypi_publication/spec.md`](../rv_pypi_publication/spec.md) |

## 4. Step scope

| Field | Value |
|-------|--------|
| Target repository file | **none** |

## 5. Dependency contract

- **Upstream:** [`rv05-build-artifacts-twine-version-gate.md`](rv05-build-artifacts-twine-version-gate.md) **PASS** — **Wave D**.

## 6. Required context

- Artifacts present under **`dist/`** from RV-05.
- **`TWINE_USERNAME`** / **`TWINE_PASSWORD`** (API token) or **`~/.pypirc`** — **values not** written in repo or chat logs.

## 7. Read first

- [`docs/specs/server_client_convergence_and_release/release_validation_and_pypi_publication/rv_pypi_publication/spec.md`](../rv_pypi_publication/spec.md)
- `pyproject.toml` — `[project]` `name` (**embed-client**)

## 8. Expected file change

- None in repository.

## 9. Forbidden alternatives

- Upload when **RV-01–RV-05** failed.
- Embedding API tokens in logs, commits, or atomic step edits.

## 10. Atomic operations

1. Confirm closure evidence for **RV-01–RV-05**.
2. Confirm credentials available (boolean only in report — **no** secret values).
3. Upload:

   ```bash
   twine upload dist/*
   ```

   Or explicit repository: `twine upload --repository pypi dist/*` per local config.

4. Record **success** with **version** **V** from **`pyproject.toml`** / upload log, and **filenames** uploaded.
5. Optional verification: `pip install embed-client==V` in a **clean** venv (network permitting).

## 11. Expected deliverables

- **Either:** PyPI project page shows version **V** with matching artifacts + **SHA256** from PyPI **or** upload log **or**
- **Or:** **Exact blocker** (401/403, duplicate version, network) — **no** publish.

## 12. Mandatory validation

| Outcome | Check |
|---------|--------|
| Success | `twine` exit **0**; web UI or `pip` shows **V** |
| Duplicate version | **Stop** — use [`placeholder-corrective-rv06-duplicate-version-or-auth.md`](placeholder-corrective-rv06-duplicate-version-or-auth.md) only after approval |

## 13. Decision rules

- Missing credentials → **BLOCKER** report (exact reason: no token / no permission).
- **403/401** → permissions blocker.

## 14. Blackstops

- Do not upload if validation gates not green.

## 15. Handoff package

- Closure report section: **Published V** with **date** **or** **blocker** text.

---

## LLAMA-readiness (execution)

| Field | Value |
|-------|--------|
| Command | `twine upload dist/*` |
| Distribution name | **embed-client** (PyPI normalized name may differ display; use project metadata) |
| Secrets | Environment or keyring only — **never** in files |
