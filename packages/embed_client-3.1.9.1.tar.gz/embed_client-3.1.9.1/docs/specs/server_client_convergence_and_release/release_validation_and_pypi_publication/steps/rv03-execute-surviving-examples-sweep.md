<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# RV-03 — Surviving examples executable sweep

## 1. Executor role

`tester_auto` or operator; optional `researcher_code` to confirm the file list against inventory.

## 2. Execution directive

Execute every **standalone runnable** example as a **real Python process** per module docstrings. Build a **path → command → exit code → notes** table for the closure report. **Exclude** helper-only modules **`embed_client/example_async_usage_demo.py`** and **`embed_client/example_async_usage_ru_demo.py`** as **standalone** targets (they are imported by other examples, not separate CLI entry points). **Exclude** the **live** path of **`examples/canonical_mtls_localhost_8001.py`** with **`RUN_CANONICAL_MTLS_E2E=1`** from this task — that is **RV-04**; you may still run the **dry** path (without **`RUN_CANONICAL_MTLS_E2E`**) if the docstring allows import/no-network success.

## 3. Parent links (mandatory)

| Document | Path |
|----------|------|
| Epic | [`docs/specs/server_client_convergence_and_release/spec.md`](../../spec.md) |
| Global step | [`docs/specs/server_client_convergence_and_release/release_validation_and_pypi_publication/spec.md`](../spec.md) |
| Owning tactical task | [`docs/specs/server_client_convergence_and_release/release_validation_and_pypi_publication/rv_surviving_examples_executable/spec.md`](../rv_surviving_examples_executable/spec.md) |

## 4. Step scope

| Field | Value |
|-------|--------|
| Target repository file | **none** (optional evidence under `docs/ai_reports/`) |

## 5. Dependency contract

- **Upstream:** None (Wave A with RV-01/02).
- **Downstream:** Closure report table required before **RV-05**.

## 6. Required context

- Active `.venv`; `pip install -e ".[dev]"` so examples resolve imports.

## 7. Read first

- `docs/ai_reports/tests_scripts_and_dependency_migration_inventory.md` — baseline.
- Each file’s module docstring under the paths below.

**Authoritative runnable set (verify against tree at execution time; if drift, inventory wins):**

| Path | Notes |
|------|--------|
| `examples/security_examples.py` | Run per `__main__` / docstring |
| `examples/security_examples_ru.py` | Same |
| `examples/async_testing_client_example.py` | Same |
| `examples/canonical_mtls_localhost_8001.py` | **Dry only** here unless docstring allows no-network success without **`RUN_CANONICAL_MTLS_E2E`**; **do not** substitute **RV-04** live gate |
| `embed_client/example_async_usage.py` | Runnable (`if __name__ == "__main__"`) |
| `embed_client/example_async_usage_ru.py` | Runnable |

**Explicit exclusions (standalone execution):**

- `embed_client/example_async_usage_demo.py` — **do not** run as standalone.
- `embed_client/example_async_usage_ru_demo.py` — **do not** run as standalone.

## 8. Expected file change

- Optional: evidence markdown in `docs/ai_reports/`.

## 9. Forbidden alternatives

- Import-only or `py_compile` **without** subprocess execution for listed runnables.
- Hiding failures in a harness `try/except` without reporting.
- Running **`canonical_mtls_localhost_8001.py`** with **`RUN_CANONICAL_MTLS_E2E=1`** **instead of** executing **RV-04** (this sweep may still document “deferred to RV-04” for that live path).

## 10. Atomic operations

1. Confirm repository file list matches §7 (adjust if `glob` shows new `examples/*.py` or `embed_client/example_*.py`).
2. For each **included** file, read “how to run” in the docstring.
3. For **dry-run safe** examples: run from repo root, e.g. `python examples/security_examples.py` with documented flags if any — expect exit **0**.
4. For **live server** examples: run **only** when preconditions (server, env) are met; if not met, record **SKIP (explicit reason)** in the table — **not silent** (per tactical task).
5. For **`examples/canonical_mtls_localhost_8001.py`**: if default invocation hits live server without **`RUN_CANONICAL_MTLS_E2E`**, follow docstring — typically dry summary exits **0**; do **not** use this step to claim **RV-04** completeness.
6. Assemble the **table** for the closure report.

## 11. Expected deliverables

- Markdown table: **path | command | exit code | notes**.
- **PASS** if every **required** example for available environment **exits 0** and no unexpected failures.

## 12. Mandatory validation

- Each included script invoked as **subprocess** or equivalent interactive run with captured exit code.
- **Forbidden:** marking “reviewed” without execution.

## 13. Decision rules

- **BLOCKER:** unexpected import error, non-zero exit on dry-safe path, or silent omission of a listed runnable.
- **SKIP with reason:** acceptable **only** for live-only rows when server/env missing — must be explicit in table (still may block release if governance requires full run).

## 14. Blackstops

- Structural disagreement between inventory and tree → escalate per **RV-03** tactical spec.

## 15. Handoff package

- Table + verdict.
- On code fix needed: [`placeholder-corrective-rv03-broken-example.md`](placeholder-corrective-rv03-broken-example.md).

---

## LLAMA-readiness (execution step)

| Field | Value |
|-------|--------|
| Excluded paths (no `python <path>`) | `embed_client/example_async_usage_demo.py`, `embed_client/example_async_usage_ru_demo.py` |
| Canonical live gate | Deferred to [`rv04-execute-canonical-mtls-real-server-gate.md`](rv04-execute-canonical-mtls-real-server-gate.md) |
