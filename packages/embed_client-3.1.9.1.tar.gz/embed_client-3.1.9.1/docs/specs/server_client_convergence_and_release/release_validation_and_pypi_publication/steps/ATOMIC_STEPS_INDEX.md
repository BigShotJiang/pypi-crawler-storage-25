<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# Atomic steps index — `release_validation_and_pypi_publication`

**Parent:** [`../README.md`](../README.md) (tactical tasks **RV-01**–**RV-06**).  
**Epic:** [`../../spec.md`](../../spec.md).  
**Global step (this branch):** [`../spec.md`](../spec.md).

## Summary

| Goal | Execute release validation gates (security matrix, vectorization, examples, canonical mTLS, packaging) then optional PyPI upload. |
| Atomic steps (primary) | **12** execution/evidence steps + **6** on-failure placeholders |
| Dependency order | Wave **A** → **B** → **C** → **D**; placeholders activate only on failure |

## Dependency order (execution)

1. **Wave A (parallel, resource permitting):**
   - [`rv01-execute-automated-security-matrix.md`](rv01-execute-automated-security-matrix.md) — **RV-01**
   - [`rv02-execute-localhost-vectorization-mtls-8001.md`](rv02-execute-localhost-vectorization-mtls-8001.md) — **RV-02**
   - [`rv03-execute-surviving-examples-sweep.md`](rv03-execute-surviving-examples-sweep.md) — **RV-03**
   - [`rv04-supplementary-pytest-canonical-example-contract.md`](rv04-supplementary-pytest-canonical-example-contract.md) — **RV-04** (supplementary; no **8001** server)

2. **Wave B (after Wave A recommended for fail-fast; requires real server on 8001):**
   - [`rv04-execute-canonical-mtls-real-server-gate.md`](rv04-execute-canonical-mtls-real-server-gate.md) — **RV-04** (mandatory live gate)

3. **Wave C (after RV-01–RV-04 green or waived):**
   - [`rv05-build-artifacts-twine-version-gate.md`](rv05-build-artifacts-twine-version-gate.md) — **RV-05**

4. **Wave D (after RV-05):**
   - [`rv06-pypi-upload.md`](rv06-pypi-upload.md) — **RV-06**

## On-failure placeholders (do not schedule in normal waves)

Activate only when the referenced primary step fails and governance approves corrective work.

| Placeholder | If primary fails |
|-------------|------------------|
| [`placeholder-corrective-rv01-security-matrix.md`](placeholder-corrective-rv01-security-matrix.md) | [`rv01-execute-automated-security-matrix.md`](rv01-execute-automated-security-matrix.md) |
| [`placeholder-corrective-rv02-vectorization.md`](placeholder-corrective-rv02-vectorization.md) | [`rv02-execute-localhost-vectorization-mtls-8001.md`](rv02-execute-localhost-vectorization-mtls-8001.md) |
| [`placeholder-corrective-rv03-broken-example.md`](placeholder-corrective-rv03-broken-example.md) | [`rv03-execute-surviving-examples-sweep.md`](rv03-execute-surviving-examples-sweep.md) |
| [`placeholder-corrective-rv04-canonical-gate.md`](placeholder-corrective-rv04-canonical-gate.md) | [`rv04-execute-canonical-mtls-real-server-gate.md`](rv04-execute-canonical-mtls-real-server-gate.md) or supplementary RV-04 pytest |
| [`placeholder-corrective-rv05-packaging.md`](placeholder-corrective-rv05-packaging.md) | [`rv05-build-artifacts-twine-version-gate.md`](rv05-build-artifacts-twine-version-gate.md) |
| [`placeholder-corrective-rv06-duplicate-version-or-auth.md`](placeholder-corrective-rv06-duplicate-version-or-auth.md) | [`rv06-pypi-upload.md`](rv06-pypi-upload.md) |

## Parallel waves (quick reference)

| Wave | Steps | Notes |
|------|--------|--------|
| **A** | RV-01, RV-02, RV-03, RV-04 supplementary pytest | RV-02 uses **8001**; RV-01 uses **100xx** — usually safe in parallel |
| **B** | RV-04 live canonical | Serialize with other **8001**-heavy jobs if unstable |
| **C** | RV-05 | Sequential packaging gate |
| **D** | RV-06 | Single upload |

## Rule links (locked)

- **RV-01:** Service-absence **skips** → **blocker**, not pass.
- **RV-02:** Config **`configs/mtls_8001.json`** only (not **`mtls_8001_test.json`**).
- **RV-03:** Exclude standalone runs of **`embed_client/example_async_usage_demo.py`**, **`embed_client/example_async_usage_ru_demo.py`**.
- **RV-04:** **`CANONICAL_EMBED_FILE_SERVER_PATH`** must be set for full-capability **PASS**; skip line proves contract only → **blocker** for full gate.
- **RV-05:** **`pip install build`** then **`python -m build`**; backend **`setuptools.build_meta`**.

## Atomic file list (alphabetical)

- [`ATOMIC_STEPS_INDEX.md`](ATOMIC_STEPS_INDEX.md) — this index
- [`placeholder-corrective-rv01-security-matrix.md`](placeholder-corrective-rv01-security-matrix.md)
- [`placeholder-corrective-rv02-vectorization.md`](placeholder-corrective-rv02-vectorization.md)
- [`placeholder-corrective-rv03-broken-example.md`](placeholder-corrective-rv03-broken-example.md)
- [`placeholder-corrective-rv04-canonical-gate.md`](placeholder-corrective-rv04-canonical-gate.md)
- [`placeholder-corrective-rv05-packaging.md`](placeholder-corrective-rv05-packaging.md)
- [`placeholder-corrective-rv06-duplicate-version-or-auth.md`](placeholder-corrective-rv06-duplicate-version-or-auth.md)
- [`rv01-execute-automated-security-matrix.md`](rv01-execute-automated-security-matrix.md)
- [`rv02-execute-localhost-vectorization-mtls-8001.md`](rv02-execute-localhost-vectorization-mtls-8001.md)
- [`rv03-execute-surviving-examples-sweep.md`](rv03-execute-surviving-examples-sweep.md)
- [`rv04-execute-canonical-mtls-real-server-gate.md`](rv04-execute-canonical-mtls-real-server-gate.md)
- [`rv04-supplementary-pytest-canonical-example-contract.md`](rv04-supplementary-pytest-canonical-example-contract.md)
- [`rv05-build-artifacts-twine-version-gate.md`](rv05-build-artifacts-twine-version-gate.md)
- [`rv06-pypi-upload.md`](rv06-pypi-upload.md)
