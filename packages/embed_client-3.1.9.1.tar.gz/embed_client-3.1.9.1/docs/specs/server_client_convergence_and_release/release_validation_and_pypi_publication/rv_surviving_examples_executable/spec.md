<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# RV-03 — Surviving examples (executable sweep)

## Purpose

Run every **standalone runnable** surviving example in `examples/` and the runnable `embed_client/example_*.py` entry points as **real Python processes** — not merely **import** or **compile** checks — so executable validation matches epic acceptance criteria. Failures block release.

## Parent links

| Document | Path |
|----------|------|
| Epic spec | [`../../spec.md`](../../spec.md) |
| Global step | [`../spec.md`](../spec.md) |
| Tactical index | [`../README.md`](../README.md) |
| Inventory reference | `docs/ai_reports/tests_scripts_and_dependency_migration_inventory.md` |

## Scope

**Included:** Building the authoritative **file list** of **standalone runnable** examples (from inventory + `examples/` + runnable `embed_client/example_*.py` entry points), classifying each as **dry-run safe** vs **requires live server / env**, running **all dry-run safe** entries with **zero exit code**, and running **live** entries only where environment matches documented preconditions.

**Excluded:** The **canonical** `examples/canonical_mtls_localhost_8001.py` **live** path — that is **RV-04**; this task still lists it and may run **dry** modes if the script supports them without **`RUN_CANONICAL_MTLS_E2E`**.

## Boundaries

- Do not add new examples in this task.
- Do not weaken failures into warnings.
- Do not treat helper modules that lack a standalone CLI entry point as release examples to execute. Specifically, `embed_client/example_async_usage_demo.py` and `embed_client/example_async_usage_ru_demo.py` are helper modules imported by runnable examples, not separate execution targets.

## Dependencies

- **none** (parallel with RV-01, RV-02).

## Parallelization note

**Parallelizable** with RV-01/02 **for dry-run examples**; **live** examples may **serialize** behind server availability.

## Expected outcome

- Table of **example path → command → exit code → notes** attached to closure report.
- **`tester_auto`** (or scripted harness) confirms **no unexpected failures**.

## Correction items

- If an example **imports removed symbols**, **`coder_auto`** repairs per atomic step (not ad-hoc).

## Questions / escalation

- **Global orchestrator** if inventory and tree disagree structurally.

## File inventory

| action | path | purpose |
|--------|------|---------|
| read | `docs/ai_reports/tests_scripts_and_dependency_migration_inventory.md` | Baseline list |
| enumerate | `examples/` | Runnable modules |
| enumerate | `embed_client/example_*.py` | Packaged runnable examples; exclude helper-only demo modules without `__main__` entry points |

## Class/function inventory

Not applicable unless **`coder_auto`** must fix a broken example — then follow **`researcher_code`** findings.

## Data structures

Not applicable.

## Import map

Not applicable.

## Error handling map

| Condition | Response |
|-----------|----------|
| Example requires missing optional dep | Install declared extra or mark **blocker** |
| Example requires live server | Run only when preconditions met; otherwise **skip** with explicit **reported** reason (not silent) |

## Config dependency

- Per-example env vars documented in each module docstring (e.g. **`RUN_CANONICAL_MTLS_E2E`**, **`CANONICAL_EMBED_FILE_SERVER_PATH`**).

## Test plan

| Executor | Scope |
|----------|--------|
| **`tester_auto`** | Execute sweep matrix |

## Concrete examples

- **Dry:** `python examples/<name>.py` with documented **no-network** flags if any — **exit 0**.
- **Live:** only with server + env per docstring.

## Algorithm / procedure

1. **`researcher_code`** produces authoritative **list** of example files and **run instructions** (or use inventory + verification).
2. For each file, read **module docstring** “how to run”.
3. Execute in **venv**; record outcomes.
4. Roll up pass/fail.

## Forbidden approaches

- Marking examples “reviewed” without execution.
- Hiding failures inside **try/except** in ad-hoc harnesses (fail loud).
