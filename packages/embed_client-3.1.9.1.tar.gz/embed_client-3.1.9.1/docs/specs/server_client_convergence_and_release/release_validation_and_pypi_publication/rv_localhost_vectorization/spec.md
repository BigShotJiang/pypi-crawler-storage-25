<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# RV-02 — Localhost vectorization check (real `localhost:8001`)

## Purpose

Satisfy the deploy rule: on **real** **`localhost:8001`** (usually **mTLS**), run a **vectorization** smoke that proves the client can embed text end-to-end. Certificates come from **`mtls_certificates`** as per repository conventions.

## Parent links

| Document | Path |
|----------|------|
| Epic spec | [`../../spec.md`](../../spec.md) |
| Global step | [`../spec.md`](../spec.md) |
| Tactical index | [`../README.md`](../README.md) |

## Scope

**Included:** Running the **`embed-vectorize`** CLI (entry point `embed_client.cli:cli_main`) or **documented equivalent** against a config pointing to **`localhost:8001`** with **mTLS**; capturing stdout/stderr and exit code.

**Excluded:** Changing server code; changing example source unless a defect is release-blocking.

## Boundaries

- Use **`configs/mtls_8001.json`** for this gate. It points to **`localhost:8001`**, protocol **`mtls`**, and repository certificates under **`mtls_certificates/`**. Do **not** substitute **`configs/mtls_8001_test.json`** here because that file uses a different certificate layout.
- Do not commit secrets; configs must remain non-secret per **LAYOUT-04**.

## Dependencies

- **none** (parallel with RV-01, RV-03 if the real server tolerates concurrent load).

## Parallelization note

**Parallelizable** with RV-01 **only if** the automated matrix uses **isolated test ports** (e.g. 100xx) and does not rely on **8001** — typically **safe**. If uncertain, **run RV-02 after** RV-01 completes.

## Expected outcome

- **`tester_auto`** (or manual operator with evidence) reports **success** for at least one **`vectorize`** invocation with benign sample text against **`localhost:8001`** over **mTLS**.
- Evidence: exact command, config path, exit code **0**.

## Correction items

- If CLI fails due to **config mismatch**, **`researcher_code`** may trace **`embed_client.cli`** expectations; **`coder_auto`** fixes only via atomic step.

## Questions / escalation

- **Global orchestrator** if **8001** is permanently moved in infrastructure.
- Stop if **`tester_auto`** cannot run shell validation and no human operator substitutes with logged evidence.

## File inventory

| action | path | purpose |
|--------|------|---------|
| read | `CLI_README.md` | `embed-vectorize` subcommands and flags |
| read | `configs/mtls_8001.json` | Required **8001** mTLS config for this gate |
| read | `mtls_certificates/README.md` | Cert layout if present |

## Class/function inventory

Default path: **no code edits**. CLI entry: `embed_client.cli:cli_main` (see `pyproject.toml` `[project.scripts]` **`embed-vectorize`**).

## Data structures

Not applicable.

## Import map

Not applicable.

## Error handling map

| Condition | Response |
|-----------|----------|
| Connection refused | Server not running — blocker until resolved |
| TLS / cert error | Verify **`mtls_certificates`** paths in config |

## Config dependency

- JSON fields from **`configs/mtls_8001.json`** only: protocol **`mtls`**, server host **`localhost`**, server port **`8001`**, and certificate paths under **`mtls_certificates/`**.

## Test plan

| Executor | Action |
|----------|--------|
| **`tester_auto`** | Run vectorization smoke; attach log |

**Example procedure (verify paths):**

```bash
# venv active; server listening on localhost:8001 with mTLS
embed-vectorize --config ./configs/mtls_8001.json vectorize "hello"
```

(Adjust config filename to the repo file that targets **8001**.)

## Concrete examples

- **Input:** Server up, valid mTLS trust. **Expected:** embedded result or success output, exit code **0**.

## Algorithm / procedure

1. Confirm **real** server on **localhost:8001** (operator responsibility).
2. Use **`configs/mtls_8001.json`** without substitution.
3. Run **`embed-vectorize ... vectorize "<text>"`** per **`CLI_README.md`**.
4. Record evidence.

## Forbidden approaches

- Mocking transport for this gate (must be **real** server per deploy rule).
- Using **HTTP** on **8001** when the rule requires **mTLS** for this check.
