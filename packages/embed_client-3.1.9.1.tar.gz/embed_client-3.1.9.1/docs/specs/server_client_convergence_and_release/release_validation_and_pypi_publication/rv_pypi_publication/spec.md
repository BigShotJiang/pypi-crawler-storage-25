<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# RV-06 — PyPI publication

## Purpose

Upload the **sdist** and **wheel** built in **RV-05** to **PyPI** using **secure** credentials (**API token** or **trusted publishing**), only when **RV-01–RV-05** are satisfied and maintainer authorizes release.

## Parent links

| Document | Path |
|----------|------|
| Epic spec | [`../../spec.md`](../../spec.md) |
| Global step | [`../spec.md`](../spec.md) |
| Tactical index | [`../README.md`](../README.md) |

## Scope

**Included:** `twine upload dist/*` (or `twine upload --repository pypi dist/*`) with credentials in environment or **keyring**; verification via **PyPI project page** or **`pip install embed-client==<version>`** smoke (optional post-publish).

**Excluded:** TestPyPI unless policy explicitly uses it first (document if chosen).

## Boundaries

- **Never** commit tokens or **`.pypirc`** secrets.
- If credentials or **maintainer permissions** are missing, **stop** and report **exact blocker**.

## Dependencies

- **RV-05** complete.

## Parallelization note

**None** — single upload.

## Expected outcome

- Package **visible** on PyPI at version **V** with **upload timestamp** / **file hashes** recorded in closure report **or**
- **Not published** with **exact** reason (auth, 403, duplicate version, validation).

## Correction items

- **Duplicate version:** bump version in **`pyproject.toml`** + **`embed_client.__version__`** via **approved** global step — **not** silent in this task.

## Questions / escalation

- **Global orchestrator** for **TestPyPI** vs **production** policy.

## File inventory

| action | path | purpose |
|--------|------|---------|
| read | `dist/` | Artifacts from RV-05 |
| read | `pyproject.toml` | Distribution name **`embed-client`** |

## Class/function inventory

Not applicable.

## Data structures

Not applicable.

## Import map

Not applicable.

## Error handling map

| Condition | Response |
|-----------|----------|
| `401` / `403` | Report **permissions** blocker |
| Version exists | **Stop** — need new version |
| Network | Retry policy; then blocker |

## Config dependency

- **`TWINE_USERNAME`** / **`TWINE_PASSWORD`** or **`~/.pypirc`** — **not** documented with values.

## Test plan

Post-publish (optional): `pip install embed-client==<ver>` in clean venv.

## Concrete examples

- **Success:** `twine upload` returns success; **https://pypi.org/project/embed-client/V/** shows files.

## Algorithm / procedure

1. Confirm **RV-01–RV-05** evidence attached.
2. Confirm **credentials** available (**without** logging secrets).
3. Run **`twine upload dist/*`** targeting **PyPI**.
4. Record **version**, **filename(s)**, **SHA256** from **PyPI** or upload log.

## Forbidden approaches

- Upload when **validation** failed.
- Embedding **API tokens** in repo or chat logs.
