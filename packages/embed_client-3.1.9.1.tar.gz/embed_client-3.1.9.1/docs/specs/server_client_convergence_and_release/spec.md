<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

# Server client convergence and release

## Objective

Replace the current `embed-client` implementation with the client code and contracts that are currently embedded inside `../embed`, make the server-embedded client the new canonical source for this repository, remove obsolete client-side legacy behavior without preserving backward compatibility, normalize the remaining documentation to match the resulting codebase, and publish the package to PyPI.

## Scope

- Analyze the current client repository and the server repository at `../embed`, including the server-internal client implementation, dependency declarations, command contracts, tests, scripts, and documentation.
- Migrate the server-internal client implementation into this repository as the canonical implementation.
- Remove superseded legacy production code, tests, scripts, compatibility shims, and outdated documentation.
- Normalize package metadata and dependency declarations so they are complete, minimal, and consistent with the migrated code.
- Normalize examples using the server-internal client examples as the quality reference, because examples are part of the documentation surface in this repository.
- Validate release readiness, including the repository-specific deployment matrix and local vectorization checks, and publish the resulting package to PyPI.

## Non-goals

- Preserve backward compatibility with previous public APIs, configs, scripts, or docs.
- Maintain parallel legacy implementations after migration.
- Leave speculative or duplicate documentation in the tree.

## Fixed decisions

- Backward compatibility is explicitly forbidden.
- The server-internal client from `../embed` is the source of truth when contracts differ from the current client implementation.
- The final repository state must contain only code, tests, scripts, and documentation that are necessary for the migrated client.
- Documentation in the repository must be complete, detailed, normalized, and aligned with code.
- Examples are part of the documentation surface, not optional extras.
- The surviving example set must cover all supported client capabilities of the final migrated client.
- Example docstrings must be at least as detailed as a man page for the workflow they demonstrate.
- All surviving examples must be validated by real execution, not only static review.
- One canonical end-to-end example must reproduce all supported client capabilities against the real server at `localhost:8001`.
- That canonical real-server example must use `mTLS` and repository certificates from `mtls_certificates`.
- Work must maximize safe parallelism, but only when dependency ordering still preserves correctness.

## Constraints

- The current repository is the only write target unless an additional write target is explicitly approved.
- Analysis of `../embed` is allowed for comparison and migration planning because the user explicitly identified it as the server source repository.
- The release path must respect existing project rules for environment use, validation, and deployment checks.
- Publish to PyPI only after code, tests, scripts, dependencies, and documentation are aligned with the migrated implementation.

## Acceptance criteria

- The package implementation matches the server-internal client architecture and contracts where the migration requires a choice.
- Package dependencies are explicitly correct for runtime, test, and development workflows after the migration.
- Legacy code paths, compatibility layers, stale tests, stale scripts, and stale docs are removed rather than retained.
- The surviving automated tests and validation scripts are cleaned up to target only the new implementation.
- The surviving documentation is complete, detailed, normalized, deduplicated, and consistent with the code and package metadata.
- The surviving examples cover all supported client capabilities, contain man-page-level docstrings, and pass execution-based validation.
- The repository contains one canonical real-server `localhost:8001` `mTLS` example using `mtls_certificates` that exercises all supported client capabilities end to end.
- Release validation passes, including the security-mode coverage required by repository rules and the localhost vectorization check.
- The package is published to PyPI, or a concrete external blocker is reported with exact evidence.

## Global steps

1. `baseline_audit_and_contract_capture`
2. `production_migration_and_legacy_removal`
3. `tests_scripts_and_dependency_cleanup`
4. `documentation_normalization`
5. `release_validation_and_pypi_publication`
