<!-- @wbx-modified copilot-a3f7·MTN | 2026-04-24 | Wk2: enterprise/ skeleton (BSL) | prev: NEW -->
# Recall Enterprise

> **License:** [BSL 1.1](../LICENSE-COMMERCIAL.md). Free for non-production use
> and for production by any single organization with ≤5 seats. Larger
> production use requires a commercial license. Each version converts to MIT
> three (3) years after its tagged release date.

This tree contains commercial-grade implementations layered on top of the MIT
core (`src/recall/`). Nothing in here is required to run a single-tenant
Recall deployment — the OSS Docker image at
`ghcr.io/recallworks/recall:0.1.0` ships only the MIT core.

## Modules (skeleton — implementations land in v0.3+)

| Module | Purpose | Status |
|---|---|---|
| `multitenant/` | Per-tenant logical isolation on a shared store. Tenant-scoped namespaces, query-time row filters, salt-per-tenant for hashed identifiers. | stub |
| `sso/` | OIDC + SAML connectors for Entra ID, Okta, Google Workspace. Maps `iss` + `sub` to tenant_id. | interface |
| `audit/` | Tamper-evident append-only log of every tool call (who, when, args hash, result hash). Exportable for SOC 2 evidence. | interface |
| `controlplane/` | Managed-cloud control plane stub: provision tenant, rotate keys, suspend, evict. | placeholder |

## Why a separate tree

The OSS core stays focused, auditable, and licensable to anyone. Enterprise
features are quarantined under BSL so a hosted-Recall competitor cannot stand
up a paid clone on day one. After three years they convert to MIT
automatically.

## Layering rules

- `enterprise/*` MAY import from `src/recall/*`.
- `src/recall/*` MUST NOT import from `enterprise/*`.
- A single CI check (`tests/test_no_oss_to_enterprise_imports.py`, TODO) will
  enforce this.

## Contributing

External contributions to `enterprise/` are accepted under the same BSL terms
as the rest of the tree (CLA + DCO sign-off; see `CONTRIBUTING.md`). If you
want a feature here MIT-licensed, propose it for the OSS core instead.
