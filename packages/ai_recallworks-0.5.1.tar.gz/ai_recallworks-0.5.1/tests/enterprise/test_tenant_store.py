# @wbx-modified copilot-a3f7·MTN | 2026-04-24 | TenantStore isolation tests (BSL 1.1)
"""Tenant-isolation guarantees for enterprise.multitenant.TenantStore.

LICENSE: BSL 1.1 (see /LICENSE-COMMERCIAL.md).
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from enterprise.multitenant.tenant_store import (  # noqa: E402
    TenantContext,
    TenantIsolationError,
    TenantStore,
)


class FakeStore:
    """In-memory Store-shaped fake for testing isolation logic.

    Mirrors recall.store.Store: count/upsert/query/get/delete.
    """

    def __init__(self) -> None:
        self.rows: dict[str, dict] = {}

    def count(self) -> int:
        return len(self.rows)

    def upsert(self, ids, documents, metadatas) -> None:
        for cid, doc, meta in zip(ids, documents, metadatas):
            self.rows[cid] = {"document": doc, "metadata": dict(meta or {})}

    def query(self, query_texts, n_results, where=None):
        matched = [
            (cid, r) for cid, r in self.rows.items()
            if not where or all(r["metadata"].get(k) == v for k, v in where.items())
        ][:n_results]
        return {
            "ids": [[cid for cid, _ in matched]],
            "documents": [[r["document"] for _, r in matched]],
            "metadatas": [[r["metadata"] for _, r in matched]],
        }

    def get(self, where=None, limit=100, include=None):
        matched = [
            (cid, r) for cid, r in self.rows.items()
            if not where or all(r["metadata"].get(k) == v for k, v in where.items())
        ][:limit]
        return {
            "ids": [cid for cid, _ in matched],
            "documents": [r["document"] for _, r in matched],
            "metadatas": [r["metadata"] for _, r in matched],
        }

    def delete(self, ids) -> None:
        for cid in ids:
            self.rows.pop(cid, None)


@pytest.fixture
def acme():
    return TenantContext(tenant_id="acme", tenant_salt=os.urandom(32), seats=5, tier="team")


@pytest.fixture
def globex():
    return TenantContext(tenant_id="globex", tenant_salt=os.urandom(32), seats=20, tier="enterprise")


def test_reserved_tenant_id_rejected():
    salt = os.urandom(32)
    for bad in ["", "system", "*", "all"]:
        with pytest.raises(ValueError):
            TenantStore(FakeStore(), TenantContext(tenant_id=bad, tenant_salt=salt, seats=1, tier="team"))


def test_short_salt_rejected():
    with pytest.raises(ValueError):
        TenantStore(FakeStore(), TenantContext(tenant_id="acme", tenant_salt=b"too short", seats=1, tier="team"))


def test_upsert_tags_metadata_with_tenant_id(acme):
    inner = FakeStore()
    store = TenantStore(inner, acme)
    store.upsert(ids=["c1", "c2"], documents=["d1", "d2"], metadatas=[{}, {"foo": "bar"}])
    assert inner.rows["c1"]["metadata"]["tenant_id"] == "acme"
    assert inner.rows["c2"]["metadata"]["tenant_id"] == "acme"
    assert inner.rows["c2"]["metadata"]["foo"] == "bar"


def test_query_scopes_by_tenant_id(acme, globex):
    inner = FakeStore()
    a = TenantStore(inner, acme)
    g = TenantStore(inner, globex)
    a.upsert(ids=["a1"], documents=["acme-secret"], metadatas=[{}])
    g.upsert(ids=["g1"], documents=["globex-secret"], metadatas=[{}])
    res = a.query(query_texts=["any"], n_results=10)
    assert res["ids"][0] == ["a1"]
    assert "g1" not in res["ids"][0]


def test_get_scopes_by_tenant_id(acme, globex):
    inner = FakeStore()
    a = TenantStore(inner, acme)
    g = TenantStore(inner, globex)
    a.upsert(ids=["a1", "a2"], documents=["x", "y"], metadatas=[{}, {}])
    g.upsert(ids=["g1"], documents=["z"], metadatas=[{}])
    assert sorted(a.get()["ids"]) == ["a1", "a2"]
    assert g.get()["ids"] == ["g1"]


def test_count_scopes_by_tenant_id(acme, globex):
    inner = FakeStore()
    a = TenantStore(inner, acme)
    g = TenantStore(inner, globex)
    a.upsert(ids=["a1", "a2", "a3"], documents=["a", "b", "c"], metadatas=[{}, {}, {}])
    g.upsert(ids=["g1"], documents=["z"], metadatas=[{}])
    assert a.count() == 3
    assert g.count() == 1


def test_caller_cannot_override_tenant_in_where(acme):
    inner = FakeStore()
    a = TenantStore(inner, acme)
    a.upsert(ids=["a1"], documents=["x"], metadatas=[{}])
    with pytest.raises(TenantIsolationError):
        a.query(query_texts=["any"], n_results=10, where={"tenant_id": "globex"})
    with pytest.raises(TenantIsolationError):
        a.get(where={"tenant_id": "globex"})


def test_caller_can_pass_matching_tenant_in_where(acme):
    inner = FakeStore()
    a = TenantStore(inner, acme)
    a.upsert(ids=["a1"], documents=["x"], metadatas=[{}])
    res = a.query(query_texts=["any"], n_results=10, where={"tenant_id": "acme"})
    assert res["ids"][0] == ["a1"]


def test_delete_only_owned_chunks(acme, globex):
    inner = FakeStore()
    a = TenantStore(inner, acme)
    g = TenantStore(inner, globex)
    a.upsert(ids=["a1"], documents=["x"], metadatas=[{}])
    g.upsert(ids=["g1"], documents=["z"], metadatas=[{}])
    with pytest.raises(TenantIsolationError):
        a.delete(ids=["g1"])  # foreign id
    assert "g1" in inner.rows
    a.delete(ids=["a1"])  # own id
    assert "a1" not in inner.rows


def test_upsert_parallel_lengths_enforced(acme):
    a = TenantStore(FakeStore(), acme)
    with pytest.raises(ValueError):
        a.upsert(ids=["a1", "a2"], documents=["x"], metadatas=[{}, {}])
