# @wbx-modified copilot-a3f7·MTN | 2026-04-24 | put repo root on sys.path so enterprise/ is importable in tests
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
