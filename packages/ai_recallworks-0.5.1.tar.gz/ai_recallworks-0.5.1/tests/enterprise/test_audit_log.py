# @wbx-modified copilot-a3f7·MTN | 2026-04-24 | HashChainAuditLog tests (BSL 1.1)
"""Hash-chain integrity + tamper-detection tests.

LICENSE: BSL 1.1 (see /LICENSE-COMMERCIAL.md).
"""
from __future__ import annotations

import sqlite3
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from enterprise.audit.log import (  # noqa: E402
    ANCHOR_HASH,
    AuditEntry,
    HashChainAuditLog,
    compute_entry_hash,
)


def _record(log: HashChainAuditLog, *, tenant: str = "acme", tool: str = "remember") -> AuditEntry:
    return log.append_record(
        ts_iso="2026-04-24T22:00:00.000000Z",
        tenant_id=tenant,
        actor="alice@acme.test",
        tool=tool,
        args_sha256="a" * 64,
        result_sha256="b" * 64,
    )


def test_first_entry_anchors_to_zero(tmp_path):
    log = HashChainAuditLog(str(tmp_path / "audit.db"))
    e = _record(log)
    assert e.prev_hash == ANCHOR_HASH
    assert e.entry_hash == compute_entry_hash(e)


def test_chain_links(tmp_path):
    log = HashChainAuditLog(str(tmp_path / "audit.db"))
    e1 = _record(log, tool="remember")
    e2 = _record(log, tool="recall")
    e3 = _record(log, tool="checkpoint")
    assert e2.prev_hash == e1.entry_hash
    assert e3.prev_hash == e2.entry_hash
    assert log.verify_chain() is True


def test_verify_chain_detects_tamper(tmp_path):
    db = tmp_path / "audit.db"
    log = HashChainAuditLog(str(db))
    _record(log)
    _record(log)
    _record(log)
    # Mutate row 2's tool field directly. Hash chain should now fail.
    cx = sqlite3.connect(db)
    cx.execute("UPDATE entries SET tool='evil' WHERE id=2")
    cx.commit()
    cx.close()
    assert log.verify_chain() is False


def test_iter_filters_by_tenant(tmp_path):
    log = HashChainAuditLog(str(tmp_path / "audit.db"))
    _record(log, tenant="acme")
    _record(log, tenant="globex")
    _record(log, tenant="acme")
    acme = list(log.iter(tenant_id="acme"))
    assert len(acme) == 2
    assert all(e.tenant_id == "acme" for e in acme)


def test_append_rejects_wrong_prev_hash(tmp_path):
    log = HashChainAuditLog(str(tmp_path / "audit.db"))
    e1 = _record(log)
    bogus = AuditEntry(
        ts_iso="2026-04-24T22:00:01Z",
        tenant_id="acme",
        actor="x",
        tool="t",
        args_sha256="c" * 64,
        result_sha256="d" * 64,
        prev_hash="0" * 64,  # wrong - chain head is e1.entry_hash
        entry_hash="ignored",
    )
    with pytest.raises(ValueError):
        log.append(bogus)


def test_append_rejects_wrong_entry_hash(tmp_path):
    log = HashChainAuditLog(str(tmp_path / "audit.db"))
    e1 = _record(log)
    bogus = AuditEntry(
        ts_iso="2026-04-24T22:00:01Z",
        tenant_id="acme",
        actor="x",
        tool="t",
        args_sha256="c" * 64,
        result_sha256="d" * 64,
        prev_hash=e1.entry_hash,
        entry_hash="0" * 64,  # wrong
    )
    with pytest.raises(ValueError):
        log.append(bogus)
