# code-normalizer-pro

![PyPI](https://img.shields.io/pypi/v/code-normalizer-pro?style=flat-square)
![Python](https://img.shields.io/badge/python-3.10%2B-blue?style=flat-square)
![License](https://img.shields.io/badge/license-MIT-green?style=flat-square)

**code-normalizer-pro** is a Python CLI for **code normalization**, **whitespace cleanup**, **line ending normalization**, and **encoding normalization** across entire repositories.

It helps clean source trees by converting supported text files to UTF-8, normalizing CRLF/LF line endings, removing trailing whitespace, and enforcing a final newline. It is designed for codebase cleanup, CI preparation, refactoring prep, and repository hygiene.

## Install

```bash
pip install code-normalizer-pro
```

## Quick Start

Preview changes:

```bash
code-normalizer-pro . --dry-run -e .py
```

Apply changes in place:

```bash
code-normalizer-pro . --in-place -e .py
```

Run syntax checks after normalization:

```bash
code-normalizer-pro . --dry-run -e .py --check
```

## What This Tool Is For

Use `code-normalizer-pro` when you need:

- code normalization across a repository
- encoding normalization to UTF-8
- line ending normalization to LF
- whitespace cleanup before commits
- consistent source files before CI or refactoring
- reduced diff noise in Git history

## Features

- UTF-8 normalization for supported text encodings
- line ending normalization
- trailing whitespace removal
- final newline enforcement
- dry-run mode
- in-place normalization
- extension filtering
- parallel processing
- incremental caching
- interactive approval mode
- optional syntax checking
- git pre-commit hook installation

## Common Workflows

Normalize a full project:

```bash
code-normalizer-pro . --in-place
```

Normalize only Python and JavaScript files:

```bash
code-normalizer-pro . -e .py -e .js --in-place
```

Use parallel processing on a larger codebase:

```bash
code-normalizer-pro . --parallel --in-place
```

Install the pre-commit hook:

```bash
code-normalizer-pro --install-hook
```

## Before and After

Before:

```python
def add(a, b):    
    return a + b    
```

After:

```python
def add(a, b):
    return a + b
```

## CLI Options

| Option | Description |
|---|---|
| `--dry-run` | preview changes without writing files |
| `--in-place` | modify files directly |
| `--check` | run syntax validation |
| `--parallel` | enable multi-core processing |
| `--workers` | set worker count |
| `--interactive` | approve changes per file |
| `--no-cache` | disable incremental cache |
| `--no-backup` | disable backups |
| `--install-hook` | install a git pre-commit hook |
| `-e, --ext` | process only specific extensions |
| `-v, --verbose` | show detailed output |

## Safety

- deterministic, non-semantic cleanup only
- binary files are skipped
- dry-run mode allows safe preview
- backups are enabled by default for in-place edits
- syntax checks can validate normalized output

## Supported Encodings

- utf-8
- utf-8-sig
- utf-16
- utf-16-le
- utf-16-be
- windows-1252
- latin-1
- iso-8859-1

## Supported Syntax Checks

- Python
- JavaScript
- TypeScript
- Go
- Rust
- C
- C++
- Java

## Use Cases

- cleaning legacy repositories
- standardizing source files before CI
- preparing code for linting or formatting
- reducing whitespace-only diffs
- improving repository hygiene for teams
- normalizing files before AI-assisted code workflows

## License

MIT License
