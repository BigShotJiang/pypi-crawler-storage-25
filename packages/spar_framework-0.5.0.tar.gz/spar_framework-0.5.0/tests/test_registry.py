import json
from pathlib import Path

from spar_framework import __version__
from spar_framework.registry import GapSpec, ModelSpec, gap_registry_snapshot, model_registry_snapshot


def test_model_registry_snapshot_counts_models():
    snapshot = model_registry_snapshot(
        [ModelSpec("m1", "Model 1", "Production", "Test scope")]
    )
    assert snapshot["total_models"] == 1


def test_gap_registry_snapshot_counts_states():
    snapshot = gap_registry_snapshot(
        [GapSpec("C1", "Gap 1", "partial", "Test", ("m1",))]
    )
    assert snapshot["state_counts"]["partial"] == 1


def test_run_review_emits_registry_snapshots():
    from spar_framework.engine import ReviewRuntime, run_review
    from spar_framework.result_types import CheckResult

    runtime = ReviewRuntime(
        build_layer_a=lambda **_: [CheckResult("A1", "anchor", "PASS", "ok")],
        build_layer_b=lambda **_: [CheckResult("B1", "scope", "PASS", "ok")],
        build_layer_c=lambda **_: [CheckResult("C1", "maturity", "GAP", "stale")],
        build_model_registry_snapshot=lambda: {"total_models": 1},
        build_gap_registry_snapshot=lambda: {"total_gaps": 1},
        slop_check=lambda report_text: (0, []),
    )

    result = run_review(runtime=runtime, subject="demo", source="unit", gate="PASS", report_text="ok")
    payload = result.to_dict()

    assert payload["score"] == 95
    assert payload["verdict"] == "ACCEPT"
    assert payload["model_registry_snapshot"]["total_models"] == 1
    assert payload["gap_registry_snapshot"]["total_gaps"] == 1
    assert payload["framework_declared"] == []


def test_run_review_emits_safe_context_summary():
    from spar_framework.engine import ReviewRuntime, run_review
    from spar_framework.result_types import CheckResult

    runtime = ReviewRuntime(
        build_layer_a=lambda **_: [CheckResult("A1", "anchor", "PASS", "ok")],
        build_layer_b=lambda **_: [CheckResult("B1", "scope", "PASS", "ok")],
        build_layer_c=lambda **_: [CheckResult("C1", "maturity", "PASS", "ok")],
    )

    result = run_review(
        runtime=runtime,
        subject="demo",
        memory_context={"project_name": "mica-demo", "mode": "memory_injection"},
        leda_injection={
            "source": {"analyzer": "LEDA", "generated_at": "2026-04-12T00:00:00Z"},
            "security": {"classification": "restricted"},
            "claim_risk": [{"id": "registry_drift", "severity": "high"}],
            "maturity": {"suggested_current": "partial"},
            "spar_review_hints": {"preferred_layers": ["Layer C"]},
        },
    )

    payload = result.to_dict()
    assert payload["context_summary"]["sources"] == ["mica", "leda"]
    assert payload["context_summary"]["leda"]["claim_risk_count"] == 1
    assert payload["context_summary"]["leda"]["suggested_maturity"] == "partial"


def test_run_contextual_review_loads_redacted_leda(tmp_path):
    import yaml

    from spar_domain_physics.runtime import get_review_runtime
    from spar_framework.workflow import run_contextual_review

    mica_path = tmp_path / "mica.yaml"
    mica_path.write_text("project_name: demo\nmode: memory_injection\n", encoding="utf-8")
    leda_path = tmp_path / "leda.yaml"
    leda_path.write_text(
        yaml.safe_dump(
            {
                "project": {"name": "demo", "root": "/secret/root"},
                "source": {
                    "analyzer": "LEDA",
                    "generated_at": "2026-04-12T00:00:00Z",
                    "config_path": "/secret/config",
                    "history_db": "/secret/history.db",
                },
                "security": {"classification": "internal"},
                "claim_risk": [
                    {
                        "id": "registry_drift",
                        "severity": "high",
                        "layer_hint": "Layer C",
                        "evidence": ["secret"],
                    }
                ],
                "maturity": {"suggested_current": "partial"},
                "spar_review_hints": {"preferred_layers": ["Layer C"]},
                "overrides": {"configured_override_count": 1},
            },
            sort_keys=False,
        ),
        encoding="utf-8",
    )

    result = run_contextual_review(
        runtime=get_review_runtime(),
        subject={
            "beta_G_norm": 0.0,
            "beta_B_norm": 0.0,
            "beta_Phi_norm": 0.0,
            "sidrce_omega": 1.0,
            "eft_m_kk_gev": 1.0e16,
            "ricci_norm": 0.02,
        },
        source="flat minkowski",
        gate="PASS",
        mica_context_path=str(mica_path),
        leda_injection_path=str(leda_path),
    )

    payload = result.to_dict()
    assert payload["context_summary"]["mica"]["state"] == "INVOCATION_MODE"
    assert payload["context_summary"]["mica"]["mode"] == "memory_injection"
    assert payload["context_summary"]["leda"]["classification"] == "restricted"
    assert payload["context_summary"]["leda"]["claim_risk_count"] == 1
    assert "claim_risk_ids" not in payload["context_summary"]["leda"]


def test_discover_mica_runtime_invocation_mode(tmp_path):
    from spar_framework.mica import discover_mica_runtime, load_mica_runtime_context

    (tmp_path / "memory").mkdir()
    (tmp_path / "mica.yaml").write_text(
        "\n".join(
            [
                "mica_spec: \"0.2.2\"",
                "name: demo-project",
                "mode: memory_injection",
                "layers:",
                "  - name: archive",
                "    path: memory/demo.mica.v1.0.0.json",
                "invocation_protocol:",
                "  primary_pattern: hook_trigger",
            ]
        ),
        encoding="utf-8",
    )
    (tmp_path / "memory" / "demo.mica.v1.0.0.json").write_text(
        json.dumps(
            {
                "project": {"name": "demo-project"},
                "design_invariants": [
                    {"id": "DI-001", "severity": "critical"},
                    {"id": "DI-002", "severity": "high"},
                ],
                "operation_meta": {
                    "archive_id": "MICA-DEMO-001",
                    "last_updated": "2026-04-12",
                    "current_state": "active",
                },
            }
        ),
        encoding="utf-8",
    )

    discovery = discover_mica_runtime(tmp_path)
    context = load_mica_runtime_context(project_root=tmp_path)

    assert discovery["state"] == "INVOCATION_MODE"
    assert context is not None
    assert context["_mica_runtime"]["state"] == "INVOCATION_MODE"
    assert context["invariants"]["critical"] == 1
    assert context["pattern"] == "hook_trigger"


def test_discover_mica_runtime_legacy_mode(tmp_path):
    from spar_framework.mica import discover_mica_runtime, load_mica_runtime_context

    (tmp_path / "memory").mkdir()
    (tmp_path / "memory" / "legacy.mica.v1.0.0.json").write_text(
        json.dumps(
            {
                "mica_spec": "0.2.2",
                "project": {"name": "legacy-demo"},
                "design_invariants": [{"id": "DI-001", "severity": "critical"}],
                "operation_meta": {
                    "archive_id": "MICA-LEGACY-001",
                    "last_updated": "2026-04-11",
                    "current_state": "active",
                    "operating_mode": "protocol_evolution",
                },
            }
        ),
        encoding="utf-8",
    )

    discovery = discover_mica_runtime(tmp_path)
    context = load_mica_runtime_context(project_root=tmp_path)

    assert discovery["state"] == "LEGACY_MODE"
    assert context is not None
    assert context["_mica_runtime"]["state"] == "LEGACY_MODE"
    assert context["archive_id"] == "MICA-LEGACY-001"


def test_physics_adapter_seed_emits_grouped_registry():
    from spar_domain_physics.registry_seed import physics_model_registry_snapshot

    snapshot = physics_model_registry_snapshot()

    assert snapshot["total_models"] >= 1
    assert "core_physics_models" in snapshot["groups"]


def test_physics_adapter_seed_exposes_gap_states():
    from spar_domain_physics.registry_seed import physics_gap_registry_snapshot

    snapshot = physics_gap_registry_snapshot()

    assert snapshot["total_gaps"] >= 1
    assert "partial" in snapshot["state_counts"]


def test_physics_layer_a_matches_flat_ground_truth():
    from spar_domain_physics.layer_a import build_layer_a

    checks = build_layer_a(
        subject={
            "beta_G_norm": 0.0,
            "beta_B_norm": 0.0,
            "beta_Phi_norm": 0.0,
            "sidrce_omega": 1.0,
            "eft_m_kk_gev": 1.0e16,
        },
        source="flat minkowski",
        gate="PASS",
        params={},
    )

    assert checks[0].status == "CONSISTENT"
    assert checks[3].status == "CONSISTENT"


def test_planck_mass_constant_is_single_source():
    from spar_domain_physics.ground_truth import PLANCK_MASS_GEV as truth_planck
    from spar_domain_physics.layer_a_runtime_checks import PLANCK_MASS_GEV as layer_a_planck

    assert layer_a_planck == truth_planck


def test_physics_layer_a_flags_gate_mismatch():
    from spar_domain_physics.layer_a import build_layer_a

    checks = build_layer_a(
        subject={
            "beta_G_norm": 0.0,
            "sidrce_omega": 0.2,
        },
        source="de_sitter",
        gate="PASS",
        params={},
    )

    assert checks[3].status == "ANOMALY"


def test_matcher_does_not_misclassify_ads_dilaton_as_linear_dilaton():
    from spar_domain_physics.matcher import match_ground_truth_source

    assert match_ground_truth_source("ads dilaton") == "ads"


def test_physics_layer_b_flags_eft_scope_failure():
    from spar_domain_physics.layer_b import build_layer_b

    checks = build_layer_b(
        subject={
            "eft_m_kk_gev": 2.0e19,
            "ricci_norm": 0.001,
        },
        source="flat minkowski",
        gate="PASS",
        report_text="Tight bounded statement.",
    )

    assert checks[0].status == "FAIL"
    assert checks[1].status == "PASS"


def test_physics_layer_b_warns_on_slop_phrase():
    from spar_domain_physics.layer_b import build_layer_b

    checks = build_layer_b(
        subject={
            "eft_m_kk_gev": 1.0e16,
            "ricci_norm": 0.02,
        },
        source="ads",
        gate="PASS",
        report_text="This is a groundbreaking result that opens up new possibilities.",
    )

    assert checks[1].status == "WARN"
    assert checks[2].status == "WARN"
    assert checks[3].status == "CANNOT_CHECK"
    assert checks[4].status == "CANNOT_CHECK"


def test_physics_layer_b_reads_leda_claim_surface():
    from spar_domain_physics.layer_b import build_layer_b

    checks = build_layer_b(
        subject={
            "eft_m_kk_gev": 1.0e16,
            "ricci_norm": 0.02,
        },
        source="ads",
        gate="PASS",
        report_text="Tight bounded statement.",
        context={
            "leda_injection": {
                "claim_risk": [{"id": "registry_drift"}],
                "maturity": {"suggested_current": "partial"},
                "spar_review_hints": {"preferred_layers": ["Layer C"]},
            }
        },
    )

    assert checks[3].status == "WARN"
    assert checks[4].status == "CANNOT_CHECK"


def test_physics_layer_b_reads_mica_runtime_state():
    from spar_domain_physics.layer_b import build_layer_b

    checks = build_layer_b(
        subject={
            "eft_m_kk_gev": 1.0e16,
            "ricci_norm": 0.02,
        },
        source="ads",
        gate="PASS",
        report_text="Tight bounded statement.",
        context={
            "memory_context": {
                "archive_id": "MICA-DEMO-001",
                "invariants": {"critical": 2, "high": 1},
                "_mica_runtime": {"state": "INVOCATION_MODE"},
            }
        },
    )

    assert checks[4].status == "PASS"


def test_physics_runtime_emits_slop_hits_and_registry_snapshots():
    from spar_domain_physics.runtime import get_review_runtime
    from spar_framework.engine import run_review

    result = run_review(
        runtime=get_review_runtime(),
        subject={
            "beta_G_norm": 0.0,
            "beta_B_norm": 0.0,
            "beta_Phi_norm": 0.0,
            "sidrce_omega": 1.0,
            "eft_m_kk_gev": 1.0e16,
            "ricci_norm": 0.02,
        },
        source="flat minkowski",
        gate="PASS",
        report_text="A groundbreaking result.",
    )

    payload = result.to_dict()

    assert payload["model_registry_snapshot"]["total_models"] >= 1
    assert payload["gap_registry_snapshot"]["total_gaps"] >= 1
    assert "groundbreaking" in payload["slop_hits"]


def test_physics_framework_declared_surfaces_are_separate_from_layer_c():
    from spar_domain_physics.layer_c import build_layer_c
    from spar_domain_physics.layer_c_advanced import build_framework_declared_checks

    layer_c = build_layer_c(
        subject={
            "sidrce_omega": 0.7,
            "ricci_norm": 0.001,
            "partial_G": {"dummy": 1},
            "F2": {"dummy": 1},
        },
        source="flat minkowski",
        gate="PASS",
        params={},
    )
    framework_declared = build_framework_declared_checks(
        subject={
            "sidrce_omega": 0.7,
            "ricci_norm": 0.001,
            "partial_G": {"dummy": 1},
            "F2": {"dummy": 1},
        }
    )

    assert all(check.check_id != "C7" for check in layer_c)
    c7 = next(check for check in framework_declared if check.check_id == "C7")
    assert c7.status == "DECLARED_CLOSED"
    assert c7.basis == "framework_declared"


def test_physics_layer_c_flags_missing_omega_as_cannot_determine():
    from spar_domain_physics.layer_c import build_layer_c

    checks = build_layer_c(
        subject={},
        source="wzw background",
        gate="PASS",
        params={},
    )

    c9 = next(check for check in checks if check.check_id == "C9")
    assert c9.status == "CANNOT_CHECK"
    c10 = next(check for check in checks if check.check_id == "C10")
    assert c10.status == "CANNOT_CHECK"


def test_physics_layer_c_reads_leda_maturity_alignment():
    from spar_domain_physics.layer_c import build_layer_c

    checks = build_layer_c(
        subject={},
        source="wzw background",
        gate="PASS",
        params={},
        context={
            "leda_injection": {
                "security": {"classification": "restricted"},
                "maturity": {"suggested_current": "partial", "confidence": 0.77},
            }
        },
    )

    c9 = next(check for check in checks if check.check_id == "C9")
    assert c9.status == "APPROXIMATION"
    c10 = next(check for check in checks if check.check_id == "C10")
    assert c10.status == "CANNOT_CHECK"


def test_physics_layer_c_reads_mica_invariant_continuity():
    from spar_domain_physics.layer_c import build_layer_c

    checks = build_layer_c(
        subject={},
        source="wzw background",
        gate="PASS",
        params={},
        context={
            "memory_context": {
                "pct_status": "active",
                "invariants": {"critical": 2, "high": 1},
                "_mica_runtime": {"state": "INVOCATION_MODE"},
            }
        },
    )

    c10 = next(check for check in checks if check.check_id == "C10")
    assert c10.status == "GENUINE"


def test_physics_layer_c_marks_legacy_mica_as_approximation():
    from spar_domain_physics.layer_c import build_layer_c

    checks = build_layer_c(
        subject={},
        source="wzw background",
        gate="PASS",
        params={},
        context={
            "memory_context": {
                "pct_status": "active",
                "invariants": {"critical": 1, "high": 0},
                "_mica_runtime": {"state": "LEGACY_MODE"},
            }
        },
    )

    c10 = next(check for check in checks if check.check_id == "C10")
    assert c10.status == "APPROXIMATION"


def test_public_leda_payload_is_not_ingested_by_physics_layers():
    from spar_domain_physics.layer_b import build_layer_b
    from spar_domain_physics.layer_c import build_layer_c

    b_checks = build_layer_b(
        subject={
            "eft_m_kk_gev": 1.0e16,
            "ricci_norm": 0.02,
        },
        source="ads",
        gate="PASS",
        report_text="Tight bounded statement.",
        context={
            "leda_injection": {
                "security": {"classification": "public", "ingestible_by_spar": False},
                "claim_risk": [{"id": "registry_drift"}],
                "maturity": {"suggested_current": "partial", "confidence": 0.77},
            }
        },
    )
    c_checks = build_layer_c(
        subject={},
        source="wzw background",
        gate="PASS",
        params={},
        context={
            "leda_injection": {
                "security": {"classification": "public", "ingestible_by_spar": False},
                "claim_risk": [{"id": "registry_drift"}],
                "maturity": {"suggested_current": "partial", "confidence": 0.77},
            }
        },
    )

    assert b_checks[3].status == "CANNOT_CHECK"
    c9 = next(check for check in c_checks if check.check_id == "C9")
    assert c9.status == "CANNOT_CHECK"


def test_physics_runtime_framework_declared_does_not_affect_score():
    from spar_domain_physics.runtime import get_review_runtime
    from spar_framework.engine import run_review

    result = run_review(
        runtime=get_review_runtime(),
        subject={
            "beta_G_norm": 0.0,
            "beta_B_norm": 0.0,
            "beta_Phi_norm": 0.0,
            "sidrce_omega": 0.9,
            "eft_m_kk_gev": 1.0e16,
            "ricci_norm": 0.02,
        },
        source="flat minkowski",
        gate="PASS",
        report_text="Clean report.",
    )

    payload = result.to_dict()

    assert payload["score"] == 93
    assert any(check["check_id"] == "C4" for check in payload["framework_declared"])
    assert all(check["check_id"] != "C4" for check in payload["layer_c"])


def test_spar_context_review_cli_writes_json(tmp_path):
    import yaml

    from spar_framework.cli import main

    subject_path = tmp_path / "subject.json"
    subject_path.write_text(
        json.dumps(
            {
                "beta_G_norm": 0.0,
                "beta_B_norm": 0.0,
                "beta_Phi_norm": 0.0,
                "sidrce_omega": 1.0,
                "eft_m_kk_gev": 1.0e16,
                "ricci_norm": 0.02,
            }
        ),
        encoding="utf-8",
    )
    mica_path = tmp_path / "mica.yaml"
    mica_path.write_text("project_name: demo\nmode: memory_injection\n", encoding="utf-8")
    leda_path = tmp_path / "leda.yaml"
    leda_path.write_text(
        yaml.safe_dump(
            {
                "source": {"analyzer": "LEDA", "generated_at": "2026-04-12T00:00:00Z"},
                "security": {"classification": "restricted"},
                "claim_risk": [{"id": "registry_drift", "severity": "high"}],
                "maturity": {"suggested_current": "partial"},
                "spar_review_hints": {"preferred_layers": ["Layer C"]},
            },
            sort_keys=False,
        ),
        encoding="utf-8",
    )
    output_path = tmp_path / "review.json"

    import sys
    from unittest.mock import patch

    with patch.object(
        sys,
        "argv",
        [
            "spar-context-review",
            "--subject-json",
            str(subject_path),
            "--source",
            "flat minkowski",
            "--gate",
            "PASS",
            "--mica-context",
            str(mica_path),
            "--leda-injection",
            str(leda_path),
            "--output-json",
            str(output_path),
        ],
    ):
        rc = main()

    assert rc == 0
    payload = json.loads(output_path.read_text(encoding="utf-8"))
    assert payload["context_summary"]["sources"] == ["mica", "leda"]
    assert any(check["check_id"] == "C9" for check in payload["layer_c"])


def test_spar_context_review_cli_can_auto_discover_mica(tmp_path):
    import yaml

    from spar_framework.cli import main

    (tmp_path / "memory").mkdir()
    subject_path = tmp_path / "subject.json"
    subject_path.write_text(
        json.dumps(
            {
                "beta_G_norm": 0.0,
                "beta_B_norm": 0.0,
                "beta_Phi_norm": 0.0,
                "sidrce_omega": 1.0,
                "eft_m_kk_gev": 1.0e16,
                "ricci_norm": 0.02,
            }
        ),
        encoding="utf-8",
    )
    (tmp_path / "mica.yaml").write_text(
        "\n".join(
            [
                "mica_spec: \"0.2.2\"",
                "name: demo-project",
                "mode: memory_injection",
                "layers:",
                "  - name: archive",
                "    path: memory/demo.mica.v1.0.0.json",
                "invocation_protocol:",
                "  primary_pattern: readme_protocol",
            ]
        ),
        encoding="utf-8",
    )
    (tmp_path / "memory" / "demo.mica.v1.0.0.json").write_text(
        json.dumps(
            {
                "project": {"name": "demo-project"},
                "design_invariants": [{"id": "DI-001", "severity": "critical"}],
                "operation_meta": {
                    "archive_id": "MICA-DEMO-CLI-001",
                    "last_updated": "2026-04-12",
                    "current_state": "active",
                },
            }
        ),
        encoding="utf-8",
    )
    leda_path = tmp_path / "leda.yaml"
    leda_path.write_text(
        yaml.safe_dump(
            {
                "source": {"analyzer": "LEDA", "generated_at": "2026-04-12T00:00:00Z"},
                "security": {"classification": "restricted", "ingestible_by_spar": True},
                "claim_risk": [{"id": "registry_drift", "severity": "high"}],
                "maturity": {"suggested_current": "partial"},
                "spar_review_hints": {"preferred_layers": ["Layer C"]},
            },
            sort_keys=False,
        ),
        encoding="utf-8",
    )
    output_path = tmp_path / "review.json"

    import sys
    from unittest.mock import patch

    with patch.object(
        sys,
        "argv",
        [
            "spar-context-review",
            "--subject-json",
            str(subject_path),
            "--source",
            "flat minkowski",
            "--gate",
            "PASS",
            "--project-root",
            str(tmp_path),
            "--leda-injection",
            str(leda_path),
            "--output-json",
            str(output_path),
        ],
    ):
        rc = main()

    assert rc == 0
    payload = json.loads(output_path.read_text(encoding="utf-8"))
    assert payload["context_summary"]["mica"]["state"] == "INVOCATION_MODE"
    assert payload["context_summary"]["mica"]["archive_id"] == "MICA-DEMO-CLI-001"


def test_spar_review_subcommand_writes_json(tmp_path):
    from spar_framework.cli import main

    subject_path = tmp_path / "subject.json"
    subject_path.write_text(
        json.dumps(
            {
                "beta_G_norm": 0.0,
                "beta_B_norm": 0.0,
                "beta_Phi_norm": 0.0,
                "sidrce_omega": 1.0,
                "eft_m_kk_gev": 1.0e16,
                "ricci_norm": 0.02,
            }
        ),
        encoding="utf-8",
    )
    output_path = tmp_path / "review.json"

    rc = main(
        [
            "review",
            "--subject-json",
            str(subject_path),
            "--source",
            "flat minkowski",
            "--gate",
            "PASS",
            "--output-json",
            str(output_path),
        ]
    )

    assert rc == 0
    payload = json.loads(output_path.read_text(encoding="utf-8"))
    assert payload["verdict"] == "ACCEPT"
    assert payload["score"] == 93
    assert payload["context_summary"] is None


def test_spar_explain_subcommand_emits_summary(tmp_path, capsys):
    from spar_framework.cli import main

    review_path = tmp_path / "review.json"
    review_path.write_text(
        json.dumps(
            {
                "verdict": "MINOR_REVISION",
                "score": 78,
                "grade": "WARN",
                "context_summary": {"sources": ["mica"]},
                "layer_a": [{"check_id": "A1", "status": "PASS"}],
                "layer_b": [{"check_id": "B5", "status": "WARN"}],
                "layer_c": [{"check_id": "C10", "status": "APPROXIMATION"}],
                "framework_declared": [{"check_id": "C6", "status": "DECLARED_HEURISTIC"}],
            }
        ),
        encoding="utf-8",
    )

    rc = main(["explain", "--review-json", str(review_path), "--format", "text"])

    assert rc == 0
    out = capsys.readouterr().out
    assert "verdict: MINOR_REVISION" in out
    assert "layer_b_flags: B5" in out
    assert "framework_declared_flags: C6" in out
    assert "context_sources: mica" in out


def test_spar_explain_subcommand_handles_null_context_summary(tmp_path, capsys):
    from spar_framework.cli import main

    review_path = tmp_path / "review.json"
    review_path.write_text(
        json.dumps(
            {
                "verdict": "MINOR_REVISION",
                "score": 78,
                "grade": "WARN",
                "context_summary": None,
                "layer_a": [{"check_id": "A1", "status": "PASS"}],
                "layer_b": [],
                "layer_c": [],
                "framework_declared": [],
            }
        ),
        encoding="utf-8",
    )

    rc = main(["explain", "--review-json", str(review_path), "--format", "text"])

    assert rc == 0
    out = capsys.readouterr().out
    assert "context_sources: none" in out


def test_spar_discover_subcommand_reports_profiles(tmp_path, capsys):
    from spar_framework.cli import main

    rc = main(["discover", "--project-root", str(tmp_path), "--adapter", "physics"])

    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["adapter"] == "physics"
    assert payload["mica"]["state"] == "INACTIVE"
    assert payload["leda"]["recommended_profile"] == "restricted"


def test_spar_schema_subcommand_emits_subject_contract(capsys):
    from spar_framework.cli import main

    rc = main(["schema", "subject"])

    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["title"] == "SPAR Physics Subject"
    assert "beta_G_norm" in payload["properties"]


def test_spar_schema_subcommand_writes_schema_file(tmp_path):
    from spar_framework.cli import main

    output_path = tmp_path / "subject-schema.json"

    rc = main(["schema", "subject", "--output-json", str(output_path)])

    assert rc == 0
    payload = json.loads(output_path.read_text(encoding="utf-8"))
    assert payload["title"] == "SPAR Physics Subject"


def test_spar_example_subcommand_writes_example(tmp_path):
    from spar_framework.cli import main

    output_path = tmp_path / "example.json"

    rc = main(["example", "--source", "flat", "--output-json", str(output_path)])

    assert rc == 0
    payload = json.loads(output_path.read_text(encoding="utf-8"))
    assert payload["source"] == "flat"
    assert payload["subject"]["beta_G_norm"] == 0.0


def test_spar_review_accepts_wrapped_example_payload(tmp_path):
    from spar_framework.cli import main

    example_path = tmp_path / "example.json"
    review_path = tmp_path / "review.json"
    rc = main(["example", "--source", "flat", "--output-json", str(example_path)])
    assert rc == 0

    rc = main(
        [
            "review",
            "--subject-json",
            str(example_path),
            "--source",
            "flat minkowski",
            "--gate",
            "PASS",
            "--output-json",
            str(review_path),
        ]
    )

    assert rc == 0
    payload = json.loads(review_path.read_text(encoding="utf-8"))
    assert payload["verdict"] == "ACCEPT"
    assert payload["score"] == 93
    assert any(check["check_id"] == "C7" for check in payload["framework_declared"])


def test_spar_unknown_subcommand_returns_structured_error(capsys):
    from spar_framework.cli import EXIT_INPUT_ERROR, main

    rc = main(["frobnicate"])

    assert rc == EXIT_INPUT_ERROR
    payload = json.loads(capsys.readouterr().out)
    assert payload["error"] == "unknown_command"
    assert "frobnicate" in payload["detail"]


def test_load_schema_reads_packaged_artifact():
    from spar_framework.schema_loader import load_schema

    subject_schema = load_schema("subject")
    result_schema = load_schema("result")
    context_schema = load_schema("context")

    assert subject_schema["title"] == "SPAR Physics Subject"
    assert result_schema["title"] == "SPAR Review Result"
    assert context_schema["title"] == "SPAR Context Contracts"


def test_mica_archive_version_tracks_package_version():
    archive = json.loads(
        Path("memory/spar-framework.mica.v1.0.0.json").read_text(encoding="utf-8")
    )

    assert archive["project"]["version"] == __version__
    assert archive["operation_meta"]["baseline_ref"].startswith(f"v{__version__}-")


# ---------------------------------------------------------------------------
# v0.2.0 new-field regression tests
# ---------------------------------------------------------------------------


def test_check_result_scope_defaults_to_subject():
    from spar_framework.result_types import CheckResult

    check = CheckResult("A1", "label", "PASS", "detail")
    assert check.scope == "subject"
    assert check.to_dict()["scope"] == "subject"


def test_framework_declared_checks_have_adapter_limitation_scope():
    from spar_domain_physics.layer_c_advanced import build_framework_declared_checks

    checks = build_framework_declared_checks(subject={})
    for check in checks:
        assert check.scope == "adapter_limitation", f"{check.check_id} scope={check.scope!r}"
        assert check.to_dict()["scope"] == "adapter_limitation"


def test_review_result_exposes_claim_drift_and_coverage_rate():
    from spar_framework.engine import ReviewRuntime, run_review
    from spar_framework.result_types import CheckResult

    runtime = ReviewRuntime(
        build_layer_a=lambda **_: [CheckResult("A1", "anchor", "PASS", "ok")],
        build_layer_b=lambda **_: [CheckResult("B1", "scope", "WARN", "warn")],
        build_layer_c=lambda **_: [CheckResult("C1", "maturity", "GAP", "gap")],
    )

    result = run_review(runtime=runtime, subject="demo", source="unit", gate="PASS")
    payload = result.to_dict()

    assert "claim_drift" in payload
    assert "coverage_rate" in payload
    # WARN=-3, GAP=-5 => claim_drift=8; score=100-3-5=92
    assert result.claim_drift == 8
    assert result.score == 92


def test_claim_drift_excludes_slop_penalty():
    from spar_domain_physics.runtime import get_review_runtime
    from spar_framework.engine import run_review

    result_with_slop = run_review(
        runtime=get_review_runtime(),
        subject={
            "beta_G_norm": 0.0,
            "beta_B_norm": 0.0,
            "beta_Phi_norm": 0.0,
            "sidrce_omega": 1.0,
            "eft_m_kk_gev": 1.0e16,
            "ricci_norm": 0.02,
        },
        source="flat minkowski",
        gate="PASS",
        report_text="A groundbreaking result.",
    )

    result_clean = run_review(
        runtime=get_review_runtime(),
        subject={
            "beta_G_norm": 0.0,
            "beta_B_norm": 0.0,
            "beta_Phi_norm": 0.0,
            "sidrce_omega": 1.0,
            "eft_m_kk_gev": 1.0e16,
            "ricci_norm": 0.02,
        },
        source="flat minkowski",
        gate="PASS",
        report_text="Clean report.",
    )

    # B3 is a subject check that detects language slop -> raises claim_drift.
    # slop_rules is a separate mechanism that raises slop_penalty only.
    # Therefore: score_gap > drift_gap, and slop_hits is non-empty.
    # Relation: score_gap == drift_gap + slop_penalty.
    score_gap = result_clean.score - result_with_slop.score
    drift_gap = result_with_slop.claim_drift - result_clean.claim_drift
    assert result_with_slop.slop_hits, "slop_hits must be populated"
    assert score_gap > drift_gap > 0


def test_coverage_rate_excludes_cannot_check_and_framework_declared():
    from spar_domain_physics.runtime import get_review_runtime
    from spar_framework.engine import run_review

    result = run_review(
        runtime=get_review_runtime(),
        subject={
            "beta_G_norm": 0.0,
            "beta_B_norm": 0.0,
            "beta_Phi_norm": 0.0,
            "sidrce_omega": 0.9,
            "eft_m_kk_gev": 1.0e16,
            "ricci_norm": 0.02,
        },
        source="flat minkowski",
        gate="PASS",
        report_text="Clean report.",
    )

    # framework_declared (C4-C8) must not be in denominator
    fd_ids = {c.check_id for c in result.framework_declared}
    assert "C4" in fd_ids

    # coverage_rate < 1.0 because B4, B5, C9, C10 are CANNOT_CHECK
    assert 0.0 < result.coverage_rate < 1.0
    # score parity: score == 93 unchanged
    assert result.score == 93


def test_scoring_policy_loaded_from_json():
    from spar_framework.scoring import default_policy

    assert default_policy.score_table["ANOMALY"] == -15
    assert default_policy.score_table["FAIL"] == -10
    assert default_policy.score_table["GAP"] == -5
    assert default_policy.score_table["WARN"] == -3
    assert default_policy.score_table["APPROXIMATION"] == -2
    assert default_policy.accept_threshold == 85
    assert default_policy.minor_revision_threshold == 70
    assert default_policy.major_revision_threshold == 50


def test_model_spec_external_ref_appears_in_snapshot():
    from spar_domain_physics.registry_seed import physics_model_registry_snapshot

    snapshot = physics_model_registry_snapshot()
    external_models = [m for m in snapshot["models"] if m.get("external_ref")]
    assert len(external_models) == 4
    model_ids = {m["model_id"] for m in external_models}
    assert model_ids == {"beta_residual", "chi_squared_omega", "qgb", "rg_flow_linearized"}


def test_model_spec_without_external_ref_omits_field():
    from spar_framework.registry import ModelSpec, model_registry_snapshot

    snapshot = model_registry_snapshot([ModelSpec("m1", "M1", "Production", "test scope")])
    assert "external_ref" not in snapshot["models"][0]


# ---------------------------------------------------------------------------
# v0.2.1 policy externalization regression tests
# ---------------------------------------------------------------------------


def test_slop_penalty_per_hit_loaded_from_policy():
    from spar_domain_physics.slop_rules import slop_check
    from spar_framework.scoring import default_policy

    assert default_policy.slop_penalty_per_hit == 10
    penalty, hits = slop_check("A groundbreaking result.")
    assert hits == ["groundbreaking"]
    assert penalty == default_policy.slop_penalty_per_hit * len(hits)
    assert penalty == 10


def test_coverage_rate_precision_loaded_from_policy():
    from spar_framework.result_types import CheckResult
    from spar_framework.scoring import compute_coverage_rate, default_policy

    assert default_policy.coverage_rate_precision == 4

    layer = [
        CheckResult("A1", "anchor", "PASS", "ok"),
        CheckResult("A2", "anchor", "CANNOT_CHECK", "no data"),
        CheckResult("A3", "anchor", "WARN", "warn"),
    ]
    rate = compute_coverage_rate(layer, [], [])
    assert rate == round(2 / 3, 4)
    decimal_places = len(str(rate).split(".")[-1]) if "." in str(rate) else 0
    assert decimal_places <= default_policy.coverage_rate_precision


# ---------------------------------------------------------------------------
# v0.2.2 physics adapter threshold policy wiring regression tests
# ---------------------------------------------------------------------------


def test_layer_c_thresholds_loaded_from_physics_policy():
    from spar_domain_physics.policy_loader import get_layer_c_thresholds

    thresholds = get_layer_c_thresholds()
    assert thresholds["beta_b_near_zero_threshold"] == 1e-9
    assert thresholds["brst_ricci_gap_above"] == 0.1
    assert thresholds["brst_ricci_approx_above"] == 0.01


def test_brst_ricci_boundary_uses_policy_threshold():
    from spar_domain_physics.layer_c_foundation_helpers import evaluate_brst_genuineness

    # exactly at gap threshold -> GAP
    status_gap, _ = evaluate_brst_genuineness({"ricci_norm": 0.1}, source="flat minkowski")
    assert status_gap == "GAP"

    # just below approx threshold -> GENUINE
    status_genuine, _ = evaluate_brst_genuineness({"ricci_norm": 0.005}, source="flat minkowski")
    assert status_genuine == "GENUINE"

    # between thresholds -> APPROXIMATION
    status_approx, _ = evaluate_brst_genuineness({"ricci_norm": 0.05}, source="flat minkowski")
    assert status_approx == "APPROXIMATION"


# ---------------------------------------------------------------------------
# v0.2.3 slop_check policy parameterization regression tests
# ---------------------------------------------------------------------------


def test_slop_check_accepts_policy_override():
    from dataclasses import replace

    from spar_domain_physics.slop_rules import slop_check
    from spar_framework.scoring import default_policy

    custom_policy = replace(default_policy, slop_penalty_per_hit=5)

    penalty_default, hits_default = slop_check("A groundbreaking result.")
    penalty_custom, hits_custom = slop_check("A groundbreaking result.", policy=custom_policy)

    assert hits_default == hits_custom == ["groundbreaking"]
    assert penalty_default == 10
    assert penalty_custom == 5


def test_slop_check_partial_binding_matches_direct_call():
    from functools import partial

    from spar_domain_physics.slop_rules import slop_check
    from spar_framework.scoring import default_policy

    bound = partial(slop_check, policy=default_policy)
    assert bound("A revolutionary claim.") == slop_check("A revolutionary claim.")
