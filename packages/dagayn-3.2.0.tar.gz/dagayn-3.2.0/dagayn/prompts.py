"""MCP prompt templates for Dagayn.

Provides 5 pre-built prompt workflows, all enforcing token-efficient
detail_level="minimal" first patterns with get_minimal_context entry point.

1. review_changes   - pre-commit review using review_tool
2. architecture_map - architecture docs using communities, flows, Mermaid
3. debug_issue      - guided debugging using search, flow tracing
4. onboard_developer - new dev orientation using stats, architecture, flows
5. pre_merge_check  - PR readiness with risk scoring, test gaps, dead code
"""

from __future__ import annotations

_TOKEN_EFFICIENCY_PREAMBLE = (  # nosec B105 — prompt template, not a password
    """\
## Rules for Token-Efficient Graph Usage
1. ALWAYS call `get_minimal_context` first with a task description.
2. Use `detail_level="minimal"` on all tool calls unless the minimal output \
is insufficient.
3. Only escalate to `detail_level="standard"` or `"verbose"` for the specific \
entities that need deeper inspection.
4. Never request more than 3 tool calls per turn unless absolutely necessary.
5. Prefer targeted queries (query_graph with a specific symbol) over broad \
architecture_analysis drill-downs.
6. When reviewing changes: review_tool(mode="changes", detail_level="minimal") → only \
expand on high-risk items.
"""
)


def review_changes_prompt(base: str = "HEAD~1") -> list[dict]:
    """Pre-commit review workflow.

    Args:
        base: Git ref to diff against. Default: HEAD~1.
    """
    return [
        {
            "role": "user",
            "content": (
                f"{_TOKEN_EFFICIENCY_PREAMBLE}\n"
                f"## Review Workflow\n"
                f'1. Call `get_minimal_context(task="review changes against '
                f'{base}")` to get risk overview.\n'
                f'2. If risk is "low": call '
                f'`review_tool(mode="changes", detail_level="minimal")` → report summary '
                f"+ any test gaps.\n"
                f'3. If risk is "medium" or "high":\n'
                f'   a. Call `review_tool(mode="changes", detail_level="standard")` for '
                f"full change list.\n"
                f"   b. For each high-risk function, call "
                f'`query_graph(pattern="callers_of", target=<func>, '
                f'detail_level="minimal")`.\n'
                f'   c. Call `review_tool(mode="affected_flows", detail_level="minimal")` '
                f"only if >3 changed functions.\n"
                f"4. Summarize: risk level, what changed, test gaps, "
                f"specific improvements needed.\n\n"
                f'Do NOT call review_tool(mode="context") unless you need '
                f"source code snippets for a specific function."
            ),
        }
    ]


def architecture_map_prompt() -> list[dict]:
    """Architecture documentation workflow."""
    return [
        {
            "role": "user",
            "content": (
                f"{_TOKEN_EFFICIENCY_PREAMBLE}\n"
                "## Architecture Mapping Workflow\n"
                '1. Call `get_minimal_context(task="map architecture")`.\n'
                '2. Call `architecture_analysis_tool(mode="overview", '
                'detail_level="minimal")` for community coupling summary.\n'
                '3. Call `flow_tool(mode="list", detail_level="minimal")` for critical '
                "flow names + criticality scores.\n"
                '4. Only call `architecture_analysis_tool(mode="community", '
                "community_name=<X>)` for the 1-2 communities the user is most "
                "interested in.\n"
                "5. Produce a concise Mermaid diagram showing communities as "
                "boxes and key flows as arrows."
            ),
        }
    ]


def debug_issue_prompt(description: str = "") -> list[dict]:
    """Guided debugging workflow.

    Args:
        description: Description of the issue to debug.
    """
    desc_part = description or "<description>"
    return [
        {
            "role": "user",
            "content": (
                f"{_TOKEN_EFFICIENCY_PREAMBLE}\n"
                "## Debug Workflow\n"
                f'1. Call `get_minimal_context(task="debug: '
                f'{desc_part}")`.\n'
                "2. Call `semantic_search_nodes(query=<keywords from "
                'description>, detail_level="minimal", limit=5)`.\n'
                "3. For the top 1-2 results, call "
                '`query_graph(pattern="callers_of", target=<name>, '
                'detail_level="minimal")`.\n'
                "4. If the issue involves execution flow: call "
                '`flow_tool(mode="get", flow_name=<relevant flow>)` for the single most '
                "relevant flow.\n"
                '5. Only call `review_tool(mode="context")` or `review_tool(mode="impact")` '
                "if you need to trace the blast radius of a specific change."
            ),
        }
    ]


def onboard_developer_prompt() -> list[dict]:
    """New developer orientation workflow."""
    return [
        {
            "role": "user",
            "content": (
                f"{_TOKEN_EFFICIENCY_PREAMBLE}\n"
                "## Onboarding Workflow\n"
                '1. Call `get_minimal_context(task="onboard developer")`.\n'
                "2. Call `list_graph_stats()` for technology overview.\n"
                '3. Call `architecture_analysis_tool(mode="overview", '
                'detail_level="minimal")` for the 30-second mental model.\n'
                '4. Call `architecture_analysis_tool(mode="communities", '
                'detail_level="minimal")` — '
                "present as a table of module names + sizes.\n"
                '5. Call `flow_tool(mode="list", detail_level="minimal")` — highlight '
                "the top 3 critical flows.\n"
                "6. Only drill into a specific community or flow if the "
                "developer asks."
            ),
        }
    ]


def pre_merge_check_prompt(base: str = "HEAD~1") -> list[dict]:
    """PR readiness check workflow.

    Args:
        base: Git ref to diff against. Default: HEAD~1.
    """
    return [
        {
            "role": "user",
            "content": (
                f"{_TOKEN_EFFICIENCY_PREAMBLE}\n"
                "## Pre-Merge Check Workflow\n"
                '1. Call `get_minimal_context(task="pre-merge check")`.\n'
                '2. Call `review_tool(mode="changes", detail_level="minimal")` for risk '
                "score and test gaps.\n"
                "3. If risk > 0.4: call "
                '`review_tool(mode="affected_flows", detail_level="minimal")`.\n'
                "4. If test_gap_count > 0: call "
                '`query_graph(pattern="tests_for", '
                'target=<each untested function>, detail_level="minimal")` '
                "for up to 3 functions.\n"
                '5. Call `refactor(mode="dead_code", '
                'detail_level="minimal")` to check for newly dead code.\n'
                '6. Only call `find_large_functions` or `review_tool(mode="impact")` '
                "if risk > 0.7.\n"
                "7. Output: GO/NO-GO recommendation with 1-sentence "
                "justification + list of required follow-ups."
            ),
        }
    ]
