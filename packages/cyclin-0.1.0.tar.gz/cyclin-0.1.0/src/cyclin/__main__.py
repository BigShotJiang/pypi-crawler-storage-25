"""Entry point for `python -m cyclin` and the `cyclin` console script."""

from cyclin.core import _cli


def main() -> None:
    _cli()


if __name__ == "__main__":
    main()
