"""cyclin — Due.app reminder manager.

Cyclins accumulate, trigger cell-cycle events at target time, and degrade via
APC/C ubiquitination when the task is done. Same pattern for Due reminders.
"""

from cyclin.core import CyclinError, ChangeSet

__version__ = "0.1.0"
__all__ = ["CyclinError", "ChangeSet", "__version__"]
