# cyclin

Due.app reminder manager — a terminal-native interface for the Due iOS/macOS reminder app.

**Biology:** Cyclins are proteins that accumulate during the cell cycle, trigger specific events at target phases, then get destroyed via APC/C ubiquitination once their job is done. Same pattern for Due reminders — they persist, fire at a target time, and get deleted on completion.

## Install

```bash
uv tool install cyclin
# or
pipx install cyclin
```

## Requirements

- macOS with [Due.app](https://www.dueapp.com/) installed
- Python 3.12+

## Usage

```bash
cyclin ls                           # list all reminders
cyclin add "Call Alice" --date 2026-04-15 --time 14:00
cyclin rm <id>                       # delete a reminder
cyclin edit <id> --title "New title"
cyclin log                           # completion history
cyclin snapshot                      # git-commit a snapshot of the DB
cyclin search "alice"                # launch Due and search
```

## Status

Alpha. Tested only on macOS with Due 4.x. The Due database format is not
publicly documented; breakage on Due updates is possible.

## License

MIT
