"""
Mutation Engine — generates cognitive mutations from observed metrics.

The controller does not say "reason better".
It says: "deduction is banned", "analogy is required", "compress to 2 concepts".
Every mutation is a formal operator, not a suggestion.
"""

from __future__ import annotations

from .types import CognitiveMetrics, CognitiveMove, Mutation, MutationType


def generate_mutations(metrics: CognitiveMetrics, cycle: int) -> list[Mutation]:
    """Produce a list of mutations based on current cognitive metrics.
    Pressure increases with cycle count — improvisation through constraint."""
    mutations: list[Mutation] = []

    # Ban dominant strategy
    if metrics.dominant_move:
        mutations.append(Mutation(
            type=MutationType.BAN,
            target=metrics.dominant_move,
            reason=f"Move '{metrics.dominant_move.value}' dominates ({cycle=})",
        ))

    # Low entropy → require a move not yet seen
    if metrics.entropy < 1.5:
        forced = _pick_absent_move(metrics)
        if forced:
            mutations.append(Mutation(
                type=MutationType.REQUIRE,
                target=forced,
                reason=f"Low entropy ({metrics.entropy:.2f}), forcing diversity",
            ))

    # Strategy repetition → force inversion + ban most frequent move
    if metrics.strategy_repetition > 0.0:
        mutations.append(Mutation(
            type=MutationType.INVERT_CAUSALITY,
            reason=f"Strategy repetition ({metrics.strategy_repetition:.2f}), forcing inversion",
        ))
        mutations.append(Mutation(
            type=MutationType.FORCE_COMPRESSION,
            parameter=2,
            reason=f"Strategy repetition — compress to break pattern",
        ))

    # Premature closure → require contradiction search
    if metrics.premature_closure > 0.6:
        mutations.append(Mutation(
            type=MutationType.REQUIRE_CONTRADICTION,
            reason=f"Premature closure score {metrics.premature_closure:.2f}",
        ))

    # Depth without novelty → compress
    if metrics.depth_without_novelty >= 2:
        mutations.append(Mutation(
            type=MutationType.FORCE_COMPRESSION,
            parameter=2,
            reason=f"Depth without novelty = {metrics.depth_without_novelty}",
        ))

    # Progressive pressure: tighten depth limit over cycles
    if cycle >= 2:
        max_depth = max(2, 6 - cycle)
        mutations.append(Mutation(
            type=MutationType.LIMIT_DEPTH,
            parameter=max_depth,
            reason=f"Progressive pressure at {cycle=}",
        ))

    # Every cycle after the first: always perturb to prevent stasis
    if cycle >= 1 and not mutations:
        mutations.append(Mutation(
            type=MutationType.REQUIRE,
            target=_pick_absent_move(metrics) or CognitiveMove.NARRATIVE_SIMULATION,
            reason="Baseline perturbation — no cycle without mutation",
        ))

    return mutations


def _pick_absent_move(metrics: CognitiveMetrics) -> CognitiveMove | None:
    """Pick a cognitive move that hasn't been dominant."""
    candidates = [m for m in CognitiveMove if m != metrics.dominant_move]
    # Prefer structurally disruptive moves
    priority = [
        CognitiveMove.CONTRADICTION,
        CognitiveMove.ANALOGY,
        CognitiveMove.ABDUCTION,
        CognitiveMove.COMPRESSION,
        CognitiveMove.INDUCTION,
    ]
    for p in priority:
        if p in candidates:
            return p
    return candidates[0] if candidates else None
