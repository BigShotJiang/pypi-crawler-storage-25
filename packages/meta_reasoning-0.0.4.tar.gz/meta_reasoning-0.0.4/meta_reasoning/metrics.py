"""
Cognitive Metrics — the semantically-blind observation layer.

These metrics do NOT measure accuracy, correctness, or truth.
They measure form, trajectory, redundancy, stall, and premature convergence.
"""

from __future__ import annotations

import math
from collections import Counter

from .types import CognitiveMetrics, CognitiveMove, Mutation, MutationType, ReasoningTrace


def compute_metrics(
    trace: ReasoningTrace,
    history: list[ReasoningTrace],
    active_mutations: list[Mutation],
) -> CognitiveMetrics:
    """Compute all cognitive metrics for a single reasoning trace."""
    return CognitiveMetrics(
        entropy=_move_entropy(trace.moves),
        strategy_repetition=_strategy_repetition(trace, history),
        depth_without_novelty=_depth_without_novelty(trace, history),
        constraint_violations=_count_violations(trace, active_mutations),
        premature_closure=_premature_closure(trace),
        dominant_move=_dominant_move(trace.moves),
    )


def _move_entropy(moves: list[CognitiveMove]) -> float:
    if not moves:
        return 0.0
    counts = Counter(moves)
    total = len(moves)
    return -sum((c / total) * math.log2(c / total) for c in counts.values())


def _strategy_repetition(trace: ReasoningTrace, history: list[ReasoningTrace]) -> float:
    if not history:
        return 0.0
    current = tuple(trace.moves)
    matches = sum(1 for h in history if tuple(h.moves) == current)
    return matches / len(history)


def _depth_without_novelty(trace: ReasoningTrace, history: list[ReasoningTrace]) -> int:
    if not history:
        return 0
    seen_types = set()
    for h in history:
        seen_types.update(h.moves)
    novel = set(trace.moves) - seen_types
    if novel:
        return 0
    # count consecutive history entries also without novelty (backwards)
    streak = 1
    all_seen = set()
    for h in reversed(history):
        all_seen.update(h.moves)
        remaining = set(trace.moves) - all_seen
        if not remaining:
            streak += 1
        else:
            break
    return streak


def _count_violations(trace: ReasoningTrace, mutations: list[Mutation]) -> int:
    violations = 0
    for m in mutations:
        if m.type == MutationType.BAN and m.target in trace.moves:
            violations += 1
        if m.type == MutationType.REQUIRE and m.target not in trace.moves:
            violations += 1
        if m.type == MutationType.LIMIT_DEPTH and isinstance(m.parameter, int):
            if trace.depth > m.parameter:
                violations += 1
    return violations


def _premature_closure(trace: ReasoningTrace) -> float:
    if not trace.moves:
        return 0.0
    unique_ratio = len(set(trace.moves)) / len(CognitiveMove)
    depth_factor = min(trace.depth / 5, 1.0)
    # high closure = low diversity + low depth
    return max(0.0, 1.0 - (unique_ratio * 0.6 + depth_factor * 0.4))


def _dominant_move(moves: list[CognitiveMove]) -> CognitiveMove | None:
    if not moves:
        return None
    counts = Counter(moves)
    most_common, freq = counts.most_common(1)[0]
    if freq / len(moves) > 0.5:
        return most_common
    return None
