"""
Mutation Plugin System.

An open ecosystem where the community can define:
- New mutation operators
- New cognitive constraints
- New metrics

Not a closed framework — a cognitive ecosystem.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

from .types import CognitiveMetrics, Mutation, ReasoningTrace


# ---------------------------------------------------------------------------
# Plugin types
# ---------------------------------------------------------------------------

@dataclass
class MutationPlugin:
    """A community-defined mutation operator."""
    name: str
    description: str
    generate: Callable[[CognitiveMetrics, int], list[Mutation]]


@dataclass
class MetricPlugin:
    """A community-defined cognitive metric."""
    name: str
    description: str
    compute: Callable[[ReasoningTrace, list[ReasoningTrace]], float]


# ---------------------------------------------------------------------------
# Plugin Registry
# ---------------------------------------------------------------------------

class PluginRegistry:
    """Central registry for cognitive plugins."""

    def __init__(self) -> None:
        self._mutation_plugins: dict[str, MutationPlugin] = {}
        self._metric_plugins: dict[str, MetricPlugin] = {}

    def register_mutation(self, plugin: MutationPlugin) -> None:
        self._mutation_plugins[plugin.name] = plugin

    def register_metric(self, plugin: MetricPlugin) -> None:
        self._metric_plugins[plugin.name] = plugin

    def get_mutations(self, metrics: CognitiveMetrics, cycle: int) -> list[Mutation]:
        """Run all registered mutation plugins and collect results."""
        mutations: list[Mutation] = []
        for plugin in self._mutation_plugins.values():
            mutations.extend(plugin.generate(metrics, cycle))
        return mutations

    def compute_custom_metrics(
        self, trace: ReasoningTrace, history: list[ReasoningTrace]
    ) -> dict[str, float]:
        """Compute all registered custom metrics."""
        return {
            name: plugin.compute(trace, history)
            for name, plugin in self._metric_plugins.items()
        }

    @property
    def mutation_plugins(self) -> list[str]:
        return list(self._mutation_plugins.keys())

    @property
    def metric_plugins(self) -> list[str]:
        return list(self._metric_plugins.keys())


# Global default registry
_default_registry = PluginRegistry()


def get_default_registry() -> PluginRegistry:
    return _default_registry
