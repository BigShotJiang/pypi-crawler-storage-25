"""
Formal types for the Meta-Reasoning SDK.

Defines the finite alphabet of cognitive moves, structured output protocol,
and mutation operators. These are not psychological categories — they are
observable, measurable instrumentation units.
"""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# 1. Cognitive Move Taxonomy — the finite alphabet
# ---------------------------------------------------------------------------

class CognitiveMove(str, Enum):
    """Minimal, extensible taxonomy of observable reasoning moves."""
    ASSUMPTION = "assumption"
    DEDUCTION = "deduction"
    INDUCTION = "induction"
    ABDUCTION = "abduction"
    ANALOGY = "analogy"
    CONTRADICTION = "contradiction"
    ENUMERATION = "enumeration"
    COMPRESSION = "compression"
    NARRATIVE_SIMULATION = "narrative_simulation"


# ---------------------------------------------------------------------------
# 2. Structured Output Protocol — making reasoning observable
# ---------------------------------------------------------------------------

class ReasoningTrace(BaseModel):
    """Formal trace attached to every LLM generation.
    This is instrumentation, not introspection."""
    moves: list[CognitiveMove]
    depth: int = Field(ge=0, description="Nesting depth of reasoning chain")
    confidence_markers: int = Field(ge=0, description="Count of hedging / certainty signals")
    abstraction_level: str = Field(description="low | medium | high")


class StructuredOutput(BaseModel):
    """Every LLM response MUST conform to this protocol."""
    content: str
    reasoning_trace: ReasoningTrace
    raw: dict[str, Any] | None = Field(default=None, description="Original LLM response payload")


# ---------------------------------------------------------------------------
# 3. Mutation Operators — formal cognitive constraints
# ---------------------------------------------------------------------------

class MutationType(str, Enum):
    """Types of cognitive mutations the controller can impose."""
    BAN = "ban"              # Forbid a move
    REQUIRE = "require"      # Force a move
    LIMIT_DEPTH = "limit_depth"
    FORCE_COMPRESSION = "force_compression"
    INVERT_CAUSALITY = "invert_causality"
    REQUIRE_CONTRADICTION = "require_contradiction"


class Mutation(BaseModel):
    """A single cognitive mutation operator."""
    type: MutationType
    target: CognitiveMove | None = None
    parameter: int | str | None = None
    reason: str = ""

    def to_prompt_constraint(self) -> str:
        """Translate mutation into a natural-language constraint for the LLM."""
        match self.type:
            case MutationType.BAN:
                return f"You MUST NOT use {self.target.value} in your reasoning."
            case MutationType.REQUIRE:
                return f"You MUST include at least one {self.target.value} move."
            case MutationType.LIMIT_DEPTH:
                return f"Your reasoning chain MUST NOT exceed depth {self.parameter}."
            case MutationType.FORCE_COMPRESSION:
                return f"Compress your reasoning to at most {self.parameter} core concepts."
            case MutationType.INVERT_CAUSALITY:
                return "Invert the causal direction of your argument."
            case MutationType.REQUIRE_CONTRADICTION:
                return "You MUST find and articulate an internal contradiction."


# ---------------------------------------------------------------------------
# 4. Cognitive Metrics Snapshot — what the controller observes
# ---------------------------------------------------------------------------

class CognitiveMetrics(BaseModel):
    """Metrics computed by the controller. None of these measure accuracy."""
    entropy: float = Field(ge=0, description="Shannon entropy of move distribution")
    strategy_repetition: float = Field(ge=0, le=1, description="Fraction of repeated move sequences")
    depth_without_novelty: int = Field(ge=0, description="Consecutive depth steps with no new move type")
    constraint_violations: int = Field(ge=0, description="Number of active mutations violated")
    premature_closure: float = Field(ge=0, le=1, description="Score indicating early convergence")
    dominant_move: CognitiveMove | None = None


# ---------------------------------------------------------------------------
# 5. Ledger Entry — what gets recorded in epistemic memory
# ---------------------------------------------------------------------------

class LedgerEntry(BaseModel):
    """A single record in the Epistemic Ledger.
    Not content — cognitive trajectory."""
    cycle: int
    trace: ReasoningTrace
    metrics: CognitiveMetrics
    mutations_applied: list[Mutation]
    outcome: str = Field(description="'continued' | 'failed' | 'terminated'")
    failure_reason: str | None = None
