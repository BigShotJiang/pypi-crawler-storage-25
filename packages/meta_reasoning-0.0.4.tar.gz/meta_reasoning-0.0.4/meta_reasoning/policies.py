"""
Reasoning Policies — cognitive governance as code.

Policies are formal rules that translate observed metrics into mutations.
They replace the default mutation engine, making reasoning:
- Versionable (git-trackable)
- Testable (unit-testable predicates)
- Reviewable (code review, not prompt review)

This is the leap from "prompting" to cognitive infrastructure.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

from .types import CognitiveMetrics, CognitiveMove, Mutation, MutationType


@dataclass
class PolicyRule:
    """A single cognitive governance rule."""
    name: str
    condition: Callable[[CognitiveMetrics, int], bool]
    mutations: Callable[[CognitiveMetrics, int], list[Mutation]]
    description: str = ""


class ReasoningPolicy:
    """A composable set of cognitive governance rules."""

    def __init__(self, name: str = "default") -> None:
        self.name = name
        self._rules: list[PolicyRule] = []

    def add_rule(self, rule: PolicyRule) -> None:
        self._rules.append(rule)

    def rule(
        self, name: str, description: str = ""
    ) -> Callable[[Callable[[CognitiveMetrics, int], list[Mutation]]], PolicyRule]:
        """Decorator to register a rule with an inline condition."""
        def decorator(fn: Callable) -> PolicyRule:
            # fn should return (condition_bool, mutations_list) given (metrics, cycle)
            r = PolicyRule(name=name, condition=lambda m, c: bool(fn(m, c)), mutations=fn, description=description)
            self._rules.append(r)
            return r
        return decorator

    def evaluate(self, metrics: CognitiveMetrics, cycle: int) -> list[Mutation]:
        """Evaluate all rules and collect mutations from those that fire."""
        mutations: list[Mutation] = []
        for rule in self._rules:
            if rule.condition(metrics, cycle):
                mutations.extend(rule.mutations(metrics, cycle))
        return mutations

    @property
    def rules(self) -> list[PolicyRule]:
        return list(self._rules)


# ---------------------------------------------------------------------------
# Built-in policies
# ---------------------------------------------------------------------------

def strict_diversity_policy() -> ReasoningPolicy:
    """Ban dominant moves aggressively, always require novelty."""
    p = ReasoningPolicy("strict_diversity")

    p.add_rule(PolicyRule(
        name="ban_dominant",
        description="If any move exceeds 50%, ban it",
        condition=lambda m, c: m.dominant_move is not None,
        mutations=lambda m, c: [Mutation(type=MutationType.BAN, target=m.dominant_move, reason="strict_diversity: dominant")],
    ))

    p.add_rule(PolicyRule(
        name="force_novelty",
        description="If entropy < 1.5, require contradiction",
        condition=lambda m, c: m.entropy < 1.5,
        mutations=lambda m, c: [Mutation(type=MutationType.REQUIRE, target=CognitiveMove.CONTRADICTION, reason="strict_diversity: low entropy")],
    ))

    p.add_rule(PolicyRule(
        name="progressive_compression",
        description="After cycle 3, compress to 2 concepts",
        condition=lambda m, c: c >= 3,
        mutations=lambda m, c: [Mutation(type=MutationType.FORCE_COMPRESSION, parameter=2, reason="strict_diversity: progressive")],
    ))

    return p


def adversarial_policy() -> ReasoningPolicy:
    """Make the task progressively harder. Failure is the goal."""
    p = ReasoningPolicy("adversarial")

    p.add_rule(PolicyRule(
        name="always_contradict",
        description="Every cycle must search for contradictions",
        condition=lambda m, c: True,
        mutations=lambda m, c: [Mutation(type=MutationType.REQUIRE_CONTRADICTION, reason="adversarial: always contradict")],
    ))

    p.add_rule(PolicyRule(
        name="shrink_depth",
        description="Depth limit decreases every cycle",
        condition=lambda m, c: c >= 1,
        mutations=lambda m, c: [Mutation(type=MutationType.LIMIT_DEPTH, parameter=max(1, 4 - c), reason="adversarial: shrinking depth")],
    ))

    p.add_rule(PolicyRule(
        name="invert_after_stall",
        description="If repetition detected, invert causality",
        condition=lambda m, c: m.strategy_repetition > 0.0,
        mutations=lambda m, c: [Mutation(type=MutationType.INVERT_CAUSALITY, reason="adversarial: break stall")],
    ))

    return p
