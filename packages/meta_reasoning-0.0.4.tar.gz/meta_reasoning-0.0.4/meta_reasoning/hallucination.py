"""
Anti-Hallucination via Governance.

Instead of filtering output after the fact, this module detects
cognitive patterns that correlate with hallucination and breaks them
before they produce output. Governance, not fact-checking.

Hallucination-prone patterns:
- High confidence + low depth (asserting without reasoning)
- Single-strategy dominance (no cross-validation)
- Premature closure (converging before exploring)
- Depth without novelty (elaborating without new evidence)
"""

from __future__ import annotations

from dataclasses import dataclass

from .types import CognitiveMetrics, CognitiveMove, Mutation, MutationType


@dataclass
class HallucinationRisk:
    """Assessment of hallucination risk for a single cycle."""
    score: float  # 0.0 = safe, 1.0 = high risk
    triggers: list[str]
    preventive_mutations: list[Mutation]


def assess_hallucination_risk(
    metrics: CognitiveMetrics,
    confidence_markers: int,
    depth: int,
) -> HallucinationRisk:
    """Assess hallucination risk and generate preventive mutations."""
    score = 0.0
    triggers: list[str] = []
    mutations: list[Mutation] = []

    # High confidence + low depth = asserting without reasoning
    if confidence_markers >= 3 and depth <= 2:
        score += 0.35
        triggers.append(f"high_confidence_low_depth (conf={confidence_markers}, depth={depth})")
        mutations.append(Mutation(
            type=MutationType.REQUIRE_CONTRADICTION,
            reason="Anti-hallucination: high confidence without depth",
        ))

    # Single-strategy dominance = no cross-validation
    if metrics.dominant_move and metrics.entropy < 1.0:
        score += 0.25
        triggers.append(f"single_strategy ({metrics.dominant_move.value}, entropy={metrics.entropy:.2f})")
        mutations.append(Mutation(
            type=MutationType.BAN,
            target=metrics.dominant_move,
            reason="Anti-hallucination: single-strategy dominance",
        ))
        mutations.append(Mutation(
            type=MutationType.REQUIRE,
            target=CognitiveMove.CONTRADICTION,
            reason="Anti-hallucination: force cross-validation",
        ))

    # Premature closure
    if metrics.premature_closure > 0.7:
        score += 0.2
        triggers.append(f"premature_closure ({metrics.premature_closure:.2f})")
        mutations.append(Mutation(
            type=MutationType.FORCE_COMPRESSION,
            parameter=2,
            reason="Anti-hallucination: premature closure",
        ))

    # Depth without novelty = elaborating without evidence
    if metrics.depth_without_novelty >= 2:
        score += 0.2
        triggers.append(f"depth_without_novelty ({metrics.depth_without_novelty})")
        mutations.append(Mutation(
            type=MutationType.INVERT_CAUSALITY,
            reason="Anti-hallucination: depth without novelty",
        ))

    return HallucinationRisk(
        score=min(score, 1.0),
        triggers=triggers,
        preventive_mutations=mutations,
    )
