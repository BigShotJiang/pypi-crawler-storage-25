"""
Epistemic Ledger (Level 3) — structural memory.

Not "memory" in the RAG sense. This is:
- a trace of cognitive transformations
- a history of strategies used
- a map of failures

Its purpose: never return to the same mental state.
"""

from __future__ import annotations

import json
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path

from .types import CognitiveMove, LedgerEntry, MutationType


# ---------------------------------------------------------------------------
# Feature 5: Failure Atlas
# ---------------------------------------------------------------------------

@dataclass
class FailureAtlas:
    """Queryable map of cognitive failures.
    Instead of hiding failures, we map them, visualize them, make them queryable."""

    _failures: list[LedgerEntry] = field(default_factory=list)

    def __init__(self, failures: list[LedgerEntry]) -> None:
        self._failures = failures

    @property
    def count(self) -> int:
        return len(self._failures)

    def by_reason(self) -> dict[str, list[LedgerEntry]]:
        """Group failures by their reason."""
        groups: dict[str, list[LedgerEntry]] = {}
        for f in self._failures:
            key = f.failure_reason or "unknown"
            groups.setdefault(key, []).append(f)
        return groups

    def by_dominant_move(self) -> dict[str, list[LedgerEntry]]:
        """Which moves were dominant when the system failed?"""
        groups: dict[str, list[LedgerEntry]] = {}
        for f in self._failures:
            key = f.metrics.dominant_move.value if f.metrics.dominant_move else "none"
            groups.setdefault(key, []).append(f)
        return groups

    def stall_inducing_mutations(self) -> list[tuple[str, int]]:
        """Which mutation combinations preceded failures? Returns (mutation_desc, count)."""
        combos: list[str] = []
        for f in self._failures:
            if f.mutations_applied:
                desc = " + ".join(f"{m.type.value}:{m.target.value if m.target else ''}" for m in f.mutations_applied)
                combos.append(desc)
        return Counter(combos).most_common()

    def unstable_strategies(self) -> list[tuple[tuple[CognitiveMove, ...], int]]:
        """Which move sequences led to failure?"""
        seqs = [tuple(f.trace.moves) for f in self._failures]
        return Counter(seqs).most_common()

    def query(self, *, min_entropy: float | None = None, max_entropy: float | None = None,
             dominant_move: CognitiveMove | None = None) -> list[LedgerEntry]:
        """Query failures by metric criteria."""
        results = self._failures
        if min_entropy is not None:
            results = [f for f in results if f.metrics.entropy >= min_entropy]
        if max_entropy is not None:
            results = [f for f in results if f.metrics.entropy <= max_entropy]
        if dominant_move is not None:
            results = [f for f in results if f.metrics.dominant_move == dominant_move]
        return results

    def summary(self) -> str:
        lines = [f"Failure Atlas: {self.count} failures"]
        for reason, entries in self.by_reason().items():
            lines.append(f"  {reason}: {len(entries)}x")
        stalls = self.stall_inducing_mutations()
        if stalls:
            lines.append("  Stall-inducing mutations:")
            for desc, count in stalls[:5]:
                lines.append(f"    {desc} ({count}x)")
        return "\n".join(lines)


class EpistemicLedger:
    """Append-only cognitive trajectory store."""

    def __init__(self) -> None:
        self._entries: list[LedgerEntry] = []

    @property
    def entries(self) -> list[LedgerEntry]:
        return list(self._entries)

    @property
    def size(self) -> int:
        return len(self._entries)

    def record(self, entry: LedgerEntry) -> None:
        self._entries.append(entry)

    def failures(self) -> list[LedgerEntry]:
        return [e for e in self._entries if e.outcome == "failed"]

    def strategies_tried(self) -> list[tuple[CognitiveMove, ...]]:
        return [tuple(e.trace.moves) for e in self._entries]

    # -----------------------------------------------------------------------
    # Feature 5: Failure Atlas — map, visualize, query failures
    # -----------------------------------------------------------------------

    def failure_atlas(self) -> FailureAtlas:
        """Build a queryable atlas of all failures in this ledger."""
        return FailureAtlas(self.failures())

    def summary_for_prompt(self, max_entries: int = 5) -> str:
        """Generate a concise summary for the substrate to avoid repetition."""
        if not self._entries:
            return ""
        recent = self._entries[-max_entries:]
        lines = []
        for e in recent:
            moves_str = ", ".join(m.value for m in e.trace.moves)
            status = e.outcome
            if e.failure_reason:
                status += f" ({e.failure_reason})"
            lines.append(f"  Cycle {e.cycle}: [{moves_str}] → {status}")
        return "\n".join(lines)

    def save(self, path: str | Path) -> None:
        path = Path(path)
        data = [e.model_dump(mode="json") for e in self._entries]
        path.write_text(json.dumps(data, indent=2))

    def load(self, path: str | Path) -> None:
        path = Path(path)
        if not path.exists():
            return
        data = json.loads(path.read_text())
        self._entries = [LedgerEntry.model_validate(d) for d in data]
