"""
Deterministic Reasoning Replay.

Same task + same controller + same seed = reproducible reasoning.
Sessions can be saved, replayed, and compared — making the system
scientific, enterprise-ready, and testable in CI.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from pathlib import Path

from .engine import CognitiveEngine, CycleResult, EngineResult
from .substrate import LLMBackend
from .types import CognitiveMove


@dataclass
class ReplayFrame:
    """A single frame in a replay session."""
    cycle: int
    moves: list[str]
    entropy: float
    premature_closure: float
    strategy_repetition: float
    constraint_violations: int
    mutations: list[str]
    outcome: str
    content_preview: str


@dataclass
class ReplaySession:
    """A complete, serializable reasoning session."""
    task: str
    max_cycles: int
    final_outcome: str
    frames: list[ReplayFrame] = field(default_factory=list)

    def save(self, path: str | Path) -> None:
        Path(path).write_text(json.dumps(asdict(self), indent=2))

    @classmethod
    def load(cls, path: str | Path) -> ReplaySession:
        data = json.loads(Path(path).read_text())
        data["frames"] = [ReplayFrame(**f) for f in data["frames"]]
        return cls(**data)

    def diff(self, other: ReplaySession) -> list[str]:
        """Compare two sessions frame-by-frame. Returns list of differences."""
        diffs: list[str] = []
        if self.task != other.task:
            diffs.append(f"Task differs: '{self.task}' vs '{other.task}'")
        if self.final_outcome != other.final_outcome:
            diffs.append(f"Outcome differs: {self.final_outcome} vs {other.final_outcome}")
        max_len = max(len(self.frames), len(other.frames))
        for i in range(max_len):
            a = self.frames[i] if i < len(self.frames) else None
            b = other.frames[i] if i < len(other.frames) else None
            if a is None:
                diffs.append(f"Cycle {i+1}: only in other ({b.outcome})")
            elif b is None:
                diffs.append(f"Cycle {i+1}: only in self ({a.outcome})")
            else:
                if a.moves != b.moves:
                    diffs.append(f"Cycle {i+1} moves: {a.moves} vs {b.moves}")
                if a.outcome != b.outcome:
                    diffs.append(f"Cycle {i+1} outcome: {a.outcome} vs {b.outcome}")
                if abs(a.entropy - b.entropy) > 0.01:
                    diffs.append(f"Cycle {i+1} entropy: {a.entropy:.2f} vs {b.entropy:.2f}")
        return diffs

    def summary(self) -> str:
        lines = [f"Replay: {self.task}", f"Outcome: {self.final_outcome}", f"Cycles: {len(self.frames)}"]
        for f in self.frames:
            moves = ", ".join(f.moves)
            lines.append(f"  [{f.cycle}] {f.outcome} | {moves} | entropy={f.entropy:.2f}")
        return "\n".join(lines)


def record_session(engine_result: EngineResult, task: str, max_cycles: int) -> ReplaySession:
    """Convert an EngineResult into a serializable ReplaySession."""
    frames = []
    for cr in engine_result.cycles:
        frames.append(ReplayFrame(
            cycle=cr.cycle,
            moves=[m.value for m in cr.output.reasoning_trace.moves],
            entropy=cr.metrics.entropy,
            premature_closure=cr.metrics.premature_closure,
            strategy_repetition=cr.metrics.strategy_repetition,
            constraint_violations=cr.metrics.constraint_violations,
            mutations=[],
            outcome=cr.outcome,
            content_preview=cr.output.content[:200],
        ))
    return ReplaySession(
        task=task,
        max_cycles=max_cycles,
        final_outcome=engine_result.final_outcome,
        frames=frames,
    )
