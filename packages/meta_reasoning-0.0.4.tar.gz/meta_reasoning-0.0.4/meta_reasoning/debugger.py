"""
Reasoning Debugger — "put a breakpoint in thought".

Step-by-step inspection of the cognitive loop with:
- Cycle-by-cycle replay
- Mutation inspection (why was a strategy banned?)
- Rewind to any previous cognitive state
- Breakpoint predicates (pause when a condition is met)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

from .engine import CognitiveEngine, CycleResult, EngineResult
from .substrate import LLMBackend
from .types import CognitiveMetrics, Mutation


# A breakpoint is a predicate on cycle metrics
BreakpointFn = Callable[[int, CognitiveMetrics, list[Mutation]], bool]


@dataclass
class DebugSnapshot:
    """Frozen state at a single cycle — rewindable."""
    cycle: int
    result: CycleResult
    mutations_before: list[Mutation]
    mutations_after: list[Mutation]

    def explain(self) -> str:
        lines = [f"=== Cycle {self.cycle} [{self.result.outcome}] ==="]
        moves = ", ".join(m.value for m in self.result.output.reasoning_trace.moves)
        lines.append(f"  Moves:      {moves}")
        lines.append(f"  Entropy:    {self.result.metrics.entropy:.2f}")
        lines.append(f"  Repetition: {self.result.metrics.strategy_repetition:.2f}")
        lines.append(f"  Closure:    {self.result.metrics.premature_closure:.2f}")
        lines.append(f"  Violations: {self.result.metrics.constraint_violations}")
        if self.result.metrics.dominant_move:
            lines.append(f"  Dominant:   {self.result.metrics.dominant_move.value}")
        if self.mutations_before:
            lines.append("  Constraints imposed:")
            for m in self.mutations_before:
                lines.append(f"    - {m.to_prompt_constraint()}  ({m.reason})")
        if self.mutations_after:
            lines.append("  Mutations generated for next cycle:")
            for m in self.mutations_after:
                lines.append(f"    - {m.to_prompt_constraint()}  ({m.reason})")
        return "\n".join(lines)


class ReasoningDebugger:
    """Wraps CognitiveEngine with full debuggability."""

    def __init__(self, backend: LLMBackend, max_cycles: int = 6, max_violations: int = 2) -> None:
        self._engine = CognitiveEngine(backend=backend, max_cycles=max_cycles, max_violations=max_violations)
        self._snapshots: list[DebugSnapshot] = []
        self._breakpoints: list[BreakpointFn] = []

    @property
    def snapshots(self) -> list[DebugSnapshot]:
        return list(self._snapshots)

    @property
    def engine(self) -> CognitiveEngine:
        return self._engine

    def add_breakpoint(self, fn: BreakpointFn) -> None:
        """Add a breakpoint predicate. The debugger yields control when it fires."""
        self._breakpoints.append(fn)

    def run(self, task: str) -> EngineResult:
        """Run the full loop, collecting snapshots. Returns on completion or breakpoint."""
        result = EngineResult()
        ctrl = self._engine.controller
        substrate = self._engine._substrate
        ledger = self._engine.ledger

        for _ in range(self._engine._max_cycles):
            mutations_before = ctrl.get_mutations()
            history_summary = ledger.summary_for_prompt()
            output = substrate.generate(task=task, mutations=mutations_before, history_summary=history_summary or None)
            metrics = ctrl.observe(output)
            outcome = ctrl.decide(output, metrics)
            mutations_after = ctrl.get_mutations()

            cr = CycleResult(cycle=ctrl.cycle, output=output, metrics=metrics, outcome=outcome)
            result.cycles.append(cr)

            snap = DebugSnapshot(
                cycle=ctrl.cycle,
                result=cr,
                mutations_before=mutations_before,
                mutations_after=mutations_after,
            )
            self._snapshots.append(snap)

            # Check breakpoints
            for bp in self._breakpoints:
                if bp(ctrl.cycle, metrics, mutations_after):
                    result.final_outcome = "breakpoint"
                    return result

            if outcome in ("failed", "terminated"):
                result.final_outcome = outcome
                return result

        result.final_outcome = "max_cycles_reached"
        return result

    def rewind_to(self, cycle: int) -> DebugSnapshot | None:
        """Get the snapshot at a specific cycle."""
        for s in self._snapshots:
            if s.cycle == cycle:
                return s
        return None

    def explain_all(self) -> str:
        """Full step-by-step explanation of the reasoning session."""
        return "\n\n".join(s.explain() for s in self._snapshots)
