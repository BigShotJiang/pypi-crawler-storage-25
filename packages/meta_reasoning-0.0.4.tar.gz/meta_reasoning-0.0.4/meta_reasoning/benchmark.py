"""
Cognitive Benchmarking & Fingerprinting.

Feature 3: Run the same controller on different models and compare
           rigidity, diversity, constraint response, improvisation.
Feature 4: Generate a cognitive fingerprint — a profile of how a model
           reasons under pressure.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .engine import CognitiveEngine, EngineResult
from .substrate import LLMBackend
from .types import CognitiveMetrics, CognitiveMove


# ---------------------------------------------------------------------------
# Feature 4: Cognitive Fingerprint
# ---------------------------------------------------------------------------

@dataclass
class CognitiveFingerprint:
    """A model's cognitive profile — its reasoning signature."""
    model_name: str
    total_cycles: int = 0
    move_distribution: dict[str, float] = field(default_factory=dict)
    avg_entropy: float = 0.0
    avg_premature_closure: float = 0.0
    avg_constraint_violations: float = 0.0
    stall_rate: float = 0.0
    dominant_moves: list[str] = field(default_factory=list)
    collapse_points: list[int] = field(default_factory=list)

    def summary(self) -> str:
        lines = [f"Cognitive Fingerprint: {self.model_name}"]
        lines.append(f"  Cycles analyzed:     {self.total_cycles}")
        lines.append(f"  Avg entropy:         {self.avg_entropy:.2f}")
        lines.append(f"  Avg closure:         {self.avg_premature_closure:.2f}")
        lines.append(f"  Avg violations:      {self.avg_constraint_violations:.2f}")
        lines.append(f"  Stall rate:          {self.stall_rate:.1%}")
        if self.dominant_moves:
            lines.append(f"  Preferred moves:     {', '.join(self.dominant_moves)}")
        if self.collapse_points:
            lines.append(f"  Collapse at cycles:  {self.collapse_points}")
        lines.append("  Move distribution:")
        for move, pct in sorted(self.move_distribution.items(), key=lambda x: -x[1]):
            lines.append(f"    {move:25s} {pct:.1%}")
        return "\n".join(lines)


def fingerprint_from_result(model_name: str, result: EngineResult) -> CognitiveFingerprint:
    """Build a cognitive fingerprint from a single engine run."""
    if not result.cycles:
        return CognitiveFingerprint(model_name=model_name)

    move_counts: dict[str, int] = {}
    total_moves = 0
    entropies = []
    closures = []
    violations = []
    dominants: list[str] = []
    collapses: list[int] = []

    for cr in result.cycles:
        entropies.append(cr.metrics.entropy)
        closures.append(cr.metrics.premature_closure)
        violations.append(cr.metrics.constraint_violations)
        if cr.metrics.dominant_move:
            dominants.append(cr.metrics.dominant_move.value)
        if cr.outcome == "failed":
            collapses.append(cr.cycle)
        for m in cr.output.reasoning_trace.moves:
            move_counts[m.value] = move_counts.get(m.value, 0) + 1
            total_moves += 1

    dist = {k: v / total_moves for k, v in move_counts.items()} if total_moves else {}
    unique_dominants = list(dict.fromkeys(dominants))

    return CognitiveFingerprint(
        model_name=model_name,
        total_cycles=len(result.cycles),
        move_distribution=dist,
        avg_entropy=sum(entropies) / len(entropies),
        avg_premature_closure=sum(closures) / len(closures),
        avg_constraint_violations=sum(violations) / len(violations),
        stall_rate=len(collapses) / len(result.cycles),
        dominant_moves=unique_dominants,
        collapse_points=collapses,
    )


# ---------------------------------------------------------------------------
# Feature 3: Model-Agnostic Benchmark
# ---------------------------------------------------------------------------

@dataclass
class BenchmarkResult:
    """Comparison of multiple models on the same task."""
    task: str
    fingerprints: list[CognitiveFingerprint] = field(default_factory=list)

    def comparison_table(self) -> str:
        header = f"{'Model':20s} {'Entropy':>8s} {'Closure':>8s} {'Stall':>8s} {'Violations':>11s} {'Cycles':>7s}"
        lines = [f"Task: {self.task}", header, "-" * len(header)]
        for fp in self.fingerprints:
            lines.append(
                f"{fp.model_name:20s} {fp.avg_entropy:8.2f} {fp.avg_premature_closure:8.2f} "
                f"{fp.stall_rate:7.1%} {fp.avg_constraint_violations:11.2f} {fp.total_cycles:7d}"
            )
        return "\n".join(lines)


def benchmark_models(
    backends: dict[str, LLMBackend],
    task: str,
    max_cycles: int = 5,
) -> BenchmarkResult:
    """Run the same governed loop on multiple backends and compare."""
    bench = BenchmarkResult(task=task)
    for name, backend in backends.items():
        engine = CognitiveEngine(backend=backend, max_cycles=max_cycles)
        result = engine.run(task)
        fp = fingerprint_from_result(name, result)
        bench.fingerprints.append(fp)
    return bench
