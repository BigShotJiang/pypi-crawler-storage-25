"""
Generative Substrate (Level 1) — the LLM interface.

The model is stateless by design. It does not decide objectives, strategies,
or validity. It is a linguistic machine, not a mind.
This module handles prompt construction and structured output parsing.
"""

from __future__ import annotations

import json
from typing import Any, Protocol

from .types import (
    CognitiveMove,
    Mutation,
    ReasoningTrace,
    StructuredOutput,
)

# ---------------------------------------------------------------------------
# System prompt that enforces the structured output protocol
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = """You are a generative substrate. You produce structured reasoning output.

EVERY response MUST be valid JSON with this exact schema:
{
  "content": "<your answer>",
  "reasoning_trace": {
    "moves": ["<move1>", "<move2>", ...],
    "depth": <integer>,
    "confidence_markers": <integer>,
    "abstraction_level": "<low|medium|high>"
  }
}

Valid moves: assumption, deduction, induction, abduction, analogy, contradiction, enumeration, compression, narrative_simulation.

You MUST classify every reasoning step you take using these moves.
Do NOT add any text outside the JSON object."""


class LLMBackend(Protocol):
    """Protocol for any LLM backend (OpenAI, Anthropic, local, mock)."""
    def generate(self, messages: list[dict[str, str]]) -> dict[str, Any]: ...


class Substrate:
    """Wraps an LLM backend, enforcing structured output and cognitive constraints."""

    def __init__(self, backend: LLMBackend) -> None:
        self._backend = backend

    def generate(
        self,
        task: str,
        mutations: list[Mutation] | None = None,
        history_summary: str | None = None,
    ) -> StructuredOutput:
        messages = [{"role": "system", "content": SYSTEM_PROMPT}]

        if history_summary:
            messages.append({
                "role": "system",
                "content": f"Cognitive history (avoid repeating these patterns):\n{history_summary}",
            })

        constraint_block = self._build_constraints(mutations or [])
        user_content = f"{constraint_block}\n\nTask: {task}" if constraint_block else f"Task: {task}"
        messages.append({"role": "user", "content": user_content})

        raw = self._backend.generate(messages)
        return self._parse(raw)

    @staticmethod
    def _build_constraints(mutations: list[Mutation]) -> str:
        if not mutations:
            return ""
        lines = ["COGNITIVE CONSTRAINTS (you MUST obey these):"]
        for i, m in enumerate(mutations, 1):
            lines.append(f"  {i}. {m.to_prompt_constraint()}")
        return "\n".join(lines)

    @staticmethod
    def _parse(raw: dict[str, Any]) -> StructuredOutput:
        text = raw.get("content", "") or raw.get("text", "") or ""
        # Try to extract JSON from the response
        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            # Fallback: wrap raw text as unstructured output
            return StructuredOutput(
                content=text,
                reasoning_trace=ReasoningTrace(
                    moves=[CognitiveMove.ASSUMPTION],
                    depth=1,
                    confidence_markers=0,
                    abstraction_level="low",
                ),
                raw=raw,
            )

        moves_raw = data.get("reasoning_trace", {}).get("moves", [])
        valid_moves = []
        for m in moves_raw:
            try:
                valid_moves.append(CognitiveMove(m))
            except ValueError:
                continue

        trace = ReasoningTrace(
            moves=valid_moves or [CognitiveMove.ASSUMPTION],
            depth=data.get("reasoning_trace", {}).get("depth", 1),
            confidence_markers=data.get("reasoning_trace", {}).get("confidence_markers", 0),
            abstraction_level=data.get("reasoning_trace", {}).get("abstraction_level", "low"),
        )

        return StructuredOutput(content=data.get("content", text), reasoning_trace=trace, raw=raw)
