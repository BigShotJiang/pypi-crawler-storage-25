"""
CI/CD for Reasoning.

Automated tests on cognitive behavior, not output correctness.
Detect regressions in reasoning patterns:
- Model became more rigid after an update
- Entropy dropped below threshold
- Stall rate increased
- Constraint compliance degraded

Designed to run in CI pipelines alongside unit tests.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .benchmark import CognitiveFingerprint, fingerprint_from_result
from .engine import CognitiveEngine, EngineResult
from .substrate import LLMBackend


@dataclass
class CognitiveAssertion:
    """A single assertion about cognitive behavior."""
    name: str
    passed: bool
    message: str


@dataclass
class CIReport:
    """Result of a cognitive CI run."""
    assertions: list[CognitiveAssertion] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return all(a.passed for a in self.assertions)

    @property
    def failed_count(self) -> int:
        return sum(1 for a in self.assertions if not a.passed)

    def summary(self) -> str:
        status = "PASSED" if self.passed else "FAILED"
        lines = [f"Cognitive CI: {status} ({self.failed_count} failures / {len(self.assertions)} assertions)"]
        for a in self.assertions:
            mark = "✓" if a.passed else "✗"
            lines.append(f"  {mark} {a.name}: {a.message}")
        return "\n".join(lines)


class CognitiveCI:
    """Run cognitive assertions against a model."""

    def __init__(self, backend: LLMBackend, max_cycles: int = 5) -> None:
        self._backend = backend
        self._max_cycles = max_cycles

    def run(self, task: str, assertions: list[CognitiveAssertionSpec]) -> CIReport:
        """Execute the cognitive loop and check all assertions."""
        engine = CognitiveEngine(backend=self._backend, max_cycles=self._max_cycles)
        result = engine.run(task)
        fp = fingerprint_from_result("ci_target", result)

        report = CIReport()
        for spec in assertions:
            passed, msg = spec.check(fp, result)
            report.assertions.append(CognitiveAssertion(name=spec.name, passed=passed, message=msg))
        return report


@dataclass
class CognitiveAssertionSpec:
    """Specification for a cognitive assertion."""
    name: str
    check_fn: callable  # (CognitiveFingerprint, EngineResult) -> (bool, str)

    def check(self, fp: CognitiveFingerprint, result: EngineResult) -> tuple[bool, str]:
        return self.check_fn(fp, result)


# ---------------------------------------------------------------------------
# Built-in assertion factories
# ---------------------------------------------------------------------------

def assert_min_entropy(threshold: float) -> CognitiveAssertionSpec:
    def check(fp: CognitiveFingerprint, result: EngineResult) -> tuple[bool, str]:
        ok = fp.avg_entropy >= threshold
        return ok, f"avg_entropy={fp.avg_entropy:.2f} (min={threshold})"
    return CognitiveAssertionSpec(name=f"min_entropy>={threshold}", check_fn=check)


def assert_max_stall_rate(threshold: float) -> CognitiveAssertionSpec:
    def check(fp: CognitiveFingerprint, result: EngineResult) -> tuple[bool, str]:
        ok = fp.stall_rate <= threshold
        return ok, f"stall_rate={fp.stall_rate:.1%} (max={threshold:.1%})"
    return CognitiveAssertionSpec(name=f"stall_rate<={threshold:.0%}", check_fn=check)


def assert_max_closure(threshold: float) -> CognitiveAssertionSpec:
    def check(fp: CognitiveFingerprint, result: EngineResult) -> tuple[bool, str]:
        ok = fp.avg_premature_closure <= threshold
        return ok, f"avg_closure={fp.avg_premature_closure:.2f} (max={threshold})"
    return CognitiveAssertionSpec(name=f"closure<={threshold}", check_fn=check)


def assert_no_total_stall() -> CognitiveAssertionSpec:
    def check(fp: CognitiveFingerprint, result: EngineResult) -> tuple[bool, str]:
        ok = result.final_outcome != "failed"
        return ok, f"outcome={result.final_outcome}"
    return CognitiveAssertionSpec(name="no_total_stall", check_fn=check)


def assert_min_move_diversity(min_unique: int) -> CognitiveAssertionSpec:
    def check(fp: CognitiveFingerprint, result: EngineResult) -> tuple[bool, str]:
        unique = len(fp.move_distribution)
        ok = unique >= min_unique
        return ok, f"unique_moves={unique} (min={min_unique})"
    return CognitiveAssertionSpec(name=f"move_diversity>={min_unique}", check_fn=check)
