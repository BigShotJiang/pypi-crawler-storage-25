"""Tests for the Meta-Reasoning SDK core components."""

import json
from typing import Any

import pytest

from meta_reasoning import (
    CognitiveController,
    CognitiveEngine,
    CognitiveMove,
    EpistemicLedger,
    LedgerEntry,
    Mutation,
    MutationType,
    ReasoningTrace,
    StructuredOutput,
    compute_metrics,
    generate_mutations,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

def _trace(moves: list[CognitiveMove], depth: int = 3) -> ReasoningTrace:
    return ReasoningTrace(
        moves=moves, depth=depth, confidence_markers=1, abstraction_level="medium"
    )


def _output(moves: list[CognitiveMove] | None = None) -> StructuredOutput:
    moves = moves or [CognitiveMove.DEDUCTION, CognitiveMove.DEDUCTION, CognitiveMove.DEDUCTION]
    return StructuredOutput(
        content="test",
        reasoning_trace=_trace(moves),
    )


class MockBackend:
    def __init__(self, moves: list[CognitiveMove] | None = None):
        self._moves = moves or [CognitiveMove.DEDUCTION] * 3

    def generate(self, messages: list[dict[str, str]]) -> dict[str, Any]:
        resp = {
            "content": "mock",
            "reasoning_trace": {
                "moves": [m.value for m in self._moves],
                "depth": 3,
                "confidence_markers": 1,
                "abstraction_level": "medium",
            },
        }
        return {"content": json.dumps(resp)}


# ---------------------------------------------------------------------------
# Metrics
# ---------------------------------------------------------------------------

class TestMetrics:
    def test_entropy_single_move(self):
        trace = _trace([CognitiveMove.DEDUCTION] * 4)
        m = compute_metrics(trace, [], [])
        assert m.entropy == 0.0

    def test_entropy_diverse_moves(self):
        trace = _trace([CognitiveMove.DEDUCTION, CognitiveMove.ANALOGY, CognitiveMove.ABDUCTION])
        m = compute_metrics(trace, [], [])
        assert m.entropy > 1.0

    def test_dominant_move_detected(self):
        trace = _trace([CognitiveMove.DEDUCTION] * 3 + [CognitiveMove.ANALOGY])
        m = compute_metrics(trace, [], [])
        assert m.dominant_move == CognitiveMove.DEDUCTION

    def test_constraint_violation_ban(self):
        trace = _trace([CognitiveMove.DEDUCTION])
        ban = Mutation(type=MutationType.BAN, target=CognitiveMove.DEDUCTION)
        m = compute_metrics(trace, [], [ban])
        assert m.constraint_violations == 1

    def test_constraint_violation_require(self):
        trace = _trace([CognitiveMove.DEDUCTION])
        req = Mutation(type=MutationType.REQUIRE, target=CognitiveMove.ANALOGY)
        m = compute_metrics(trace, [], [req])
        assert m.constraint_violations == 1


# ---------------------------------------------------------------------------
# Mutations
# ---------------------------------------------------------------------------

class TestMutations:
    def test_bans_dominant_move(self):
        from meta_reasoning.types import CognitiveMetrics
        metrics = CognitiveMetrics(
            entropy=0.5, strategy_repetition=0.0, depth_without_novelty=0,
            constraint_violations=0, premature_closure=0.3,
            dominant_move=CognitiveMove.DEDUCTION,
        )
        muts = generate_mutations(metrics, cycle=1)
        bans = [m for m in muts if m.type == MutationType.BAN]
        assert len(bans) >= 1
        assert bans[0].target == CognitiveMove.DEDUCTION

    def test_requires_contradiction_on_premature_closure(self):
        from meta_reasoning.types import CognitiveMetrics
        metrics = CognitiveMetrics(
            entropy=2.0, strategy_repetition=0.0, depth_without_novelty=0,
            constraint_violations=0, premature_closure=0.8,
            dominant_move=None,
        )
        muts = generate_mutations(metrics, cycle=1)
        types = [m.type for m in muts]
        assert MutationType.REQUIRE_CONTRADICTION in types


# ---------------------------------------------------------------------------
# Ledger
# ---------------------------------------------------------------------------

class TestLedger:
    def test_record_and_retrieve(self):
        ledger = EpistemicLedger()
        entry = LedgerEntry(
            cycle=1,
            trace=_trace([CognitiveMove.DEDUCTION]),
            metrics=compute_metrics(_trace([CognitiveMove.DEDUCTION]), [], []),
            mutations_applied=[],
            outcome="continued",
        )
        ledger.record(entry)
        assert ledger.size == 1

    def test_failures_filter(self):
        ledger = EpistemicLedger()
        for i, outcome in enumerate(["continued", "failed", "continued"], 1):
            entry = LedgerEntry(
                cycle=i,
                trace=_trace([CognitiveMove.DEDUCTION]),
                metrics=compute_metrics(_trace([CognitiveMove.DEDUCTION]), [], []),
                mutations_applied=[],
                outcome=outcome,
                failure_reason="test" if outcome == "failed" else None,
            )
            ledger.record(entry)
        assert len(ledger.failures()) == 1

    def test_save_load(self, tmp_path):
        ledger = EpistemicLedger()
        entry = LedgerEntry(
            cycle=1,
            trace=_trace([CognitiveMove.ANALOGY]),
            metrics=compute_metrics(_trace([CognitiveMove.ANALOGY]), [], []),
            mutations_applied=[],
            outcome="continued",
        )
        ledger.record(entry)
        path = tmp_path / "ledger.json"
        ledger.save(path)

        loaded = EpistemicLedger()
        loaded.load(path)
        assert loaded.size == 1
        assert loaded.entries[0].trace.moves == [CognitiveMove.ANALOGY]


# ---------------------------------------------------------------------------
# Controller
# ---------------------------------------------------------------------------

class TestController:
    def test_observe_and_decide(self):
        ctrl = CognitiveController()
        output = _output()
        metrics = ctrl.observe(output)
        outcome = ctrl.decide(output, metrics)
        assert outcome in ("continued", "failed", "terminated")
        assert ctrl.cycle == 1

    def test_generates_mutations_after_decide(self):
        ctrl = CognitiveController()
        output = _output([CognitiveMove.DEDUCTION] * 5)
        metrics = ctrl.observe(output)
        ctrl.decide(output, metrics)
        assert len(ctrl.active_mutations) > 0


# ---------------------------------------------------------------------------
# Engine (integration)
# ---------------------------------------------------------------------------

class TestEngine:
    def test_full_loop_completes(self):
        engine = CognitiveEngine(backend=MockBackend(), max_cycles=4)
        result = engine.run("Test task")
        assert len(result.cycles) > 0
        assert result.final_outcome in ("continued", "failed", "terminated", "max_cycles_reached")

    def test_ledger_populated(self):
        engine = CognitiveEngine(backend=MockBackend(), max_cycles=3)
        engine.run("Test task")
        assert engine.ledger.size > 0
