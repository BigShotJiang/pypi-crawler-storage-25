# SPDX-License-Identifier: Apache-2.0
# Base architecture from waybarrios/vllm-mlx. _BatchOffsetSafeCache, hybrid SSM
# cache merge, MoE CacheList support, and vision encoding pipeline added by
# Jinho Jang (eric@jangq.ai) for vMLX (github.com/jjang-ai/vmlx).
"""
MLLM Batch Generator -- continuous batching engine for multimodal models.

This module is the low-level generation engine that the MLLMScheduler delegates
to. It handles vision preprocessing, prefill, cache management, and batched
token-by-token decode on Apple Metal.

KEY INSIGHT
-----------
VLM models have a ``model.language_model`` which is a standard LLM.
After the initial forward pass with vision encoding, text generation uses
only the language model -- which CAN be batched using the same BatchKVCache
pattern as pure LLM inference.

GENERATION PIPELINE
-------------------
::

    _process_prompts()                        step()
    ==================                        ======
    For each request:                         For all active requests:
    1. _preprocess_request()                  1. language_model(y, cache=cache)
       - Pixel processing + tokenization      2. Sample next token
       - Vision cache lookup                  3. Check stop conditions
    2. Cache fetch (paged/memory/legacy/disk)  4. Return responses
    3. _run_vision_encoding()                  5. Filter finished requests
       - Full VLM forward (vision + LM)
       - Populates KV cache
    4. Capture SSM state (hybrid models)
    5. Merge per-request caches -> BatchKVCache
    6. Return MLLMBatch

CACHE FETCH ORDER (in _process_prompts)
-----------------------------------------
Each request tries caches in this priority::

    1. Paged cache (block_aware_cache.fetch_cache)
       +-- Hybrid model: also check HybridSSMStateCache
    2. Memory-aware or legacy cache (fetch/fetch_cache)
    3. Disk cache L2 fallback (disk_cache.fetch)

On cache HIT for pure attention models:
  - ``req.prompt_cache`` = reconstructed KV cache
  - ``req.input_ids`` trimmed to remaining (uncached) tokens
  - ``req.pixel_values/attention_mask/image_grid_thw`` = None (no re-encoding)

On cache HIT for hybrid models (KV + SSM):
  - With SSM companion HIT: full cache (KV + SSM), skip all prefix tokens
  - Without SSM companion: forced full prefill (SSM state is path-dependent)

HYBRID MODEL HANDLING
---------------------
Hybrid models (e.g., Qwen3.5-VL 122B: 36 SSM + 12 attention layers) require
special treatment because SSM state is cumulative -- you can't skip prefix
computation for SSM layers even if you have the KV cache.

``HybridSSMStateCache``:
  - Companion LRU cache (max 50 entries) storing SSM layer states
  - Keyed by hash(tuple(token_ids[:prompt_len]))
  - Stored after prefill (before cache merge destroys per-request state)
  - Deep-copies SSM arrays with mx.contiguous() for safety
  - Enables groundbreaking full prefix skip for hybrid VLMs

``_fix_hybrid_cache()``:
  - Expands KV-only reconstructed cache to full layer count
  - Inserts fresh ArraysCache at SSM positions from model.make_cache() template
  - Pre-computed ``_hybrid_kv_positions`` and ``_hybrid_num_layers`` for speed

METAL OPTIMIZATIONS
-------------------
- ``mx.metal.set_cache_limit()``: 25% of max working set (floor 512MB)
  Bounds the Metal allocator's free-list so prefix cache and OS get memory.
- ``mx.async_eval()``: Used in prefill loop for GPU/CPU overlap.
  Submits sampled token + cache states to GPU without blocking.
- ``mx.contiguous()``: Applied to extracted cache keys/values in
  ``MLLMBatch.extract_cache()`` to release batch tensor references.
- ``mx.new_stream()``: Dedicated Metal stream for generation.
- Old limits restored in ``close()`` for clean teardown.

KEY CLASSES
-----------
- ``HybridSSMStateCache`` -- Companion LRU cache for SSM layer states
- ``MLLMBatchRequest`` -- Per-request data (tokens, pixels, sampling params)
- ``MLLMBatchResponse`` -- Per-request step output (token, logprobs, cache)
- ``MLLMBatch`` -- Active batch state (all requests being generated together)
- ``MLLMBatchStats`` -- Throughput and timing statistics
- ``MLLMBatchGenerator`` -- Main batch generator class

HELPER FUNCTIONS
----------------
- ``_dequantize_cache()`` -- QuantizedKVCache -> KVCache for batch generation
- ``_fix_hybrid_cache()`` -- Expand KV-only cache for hybrid models
- ``_merge_caches()`` -- Merge per-request caches into batch-aware caches
"""

import logging
import os
import time
from collections import OrderedDict
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

import mlx.core as mx
import mlx.nn as nn

from .vision_embedding_cache import VisionEmbeddingCache

logger = logging.getLogger(__name__)

# TurboQuantKVCache class name for isinstance-free detection.
# TQ is a drop-in replacement for KVCache (positional, sliceable, has .state/.keys/.values)
# but does NOT inherit from KVCache. This constant enables KV-like detection without
# importing TQ (which may not be installed for non-JANG users).
_TQ_CLASS_NAME = "TurboQuantKVCache"


def _is_kv_like(c) -> bool:
    """Check if cache is KVCache-compatible (KVCache or TurboQuantKVCache)."""
    from mlx_lm.models.cache import KVCache
    return isinstance(c, KVCache) or type(c).__name__ == _TQ_CLASS_NAME


def _recompress_to_tq(cache: List[Any], language_model) -> List[Any]:
    """Re-wrap reconstructed KVCache layers into TurboQuantKVCache and compress.

    After paged cache reconstruction, KV layers are full-precision float16.
    If the model uses TurboQuant, this wastes 5.3x memory vs the 3-bit
    compressed form used during generation. This function:
    1. Gets a TQ template from model.make_cache() to extract TQ config
    2. For each KVCache layer, creates a matching TurboQuantKVCache
    3. Copies keys/values and calls .compress() to restore 3-bit storage

    Returns the cache list with KV layers replaced by compressed TQ layers.
    Non-KV layers (SSM/ArraysCache) pass through unchanged.
    """
    if not hasattr(language_model, 'make_cache'):
        return cache
    # Guard: cache must be a list, not a BatchKVCache or other non-list type.
    if not isinstance(cache, list):
        return cache

    try:
        from jang_tools.turboquant.cache import TurboQuantKVCache
        from mlx_lm.models.cache import KVCache
    except ImportError:
        return cache

    # Get template and check if it contains ANY TurboQuantKVCache objects.
    # This is more robust than checking make_cache.__name__ which can vary.
    try:
        template = language_model.make_cache()
    except Exception:
        return cache
    if not isinstance(template, list) or not any(type(t).__name__ == _TQ_CLASS_NAME for t in template):
        return cache  # No TQ layers in template — not a TQ model

    tq_count = 0
    result = list(cache)
    for i, layer in enumerate(result):
        if not isinstance(layer, KVCache):
            continue
        if layer.keys is None or layer.offset == 0:
            continue
        # Find matching TQ template layer
        if i >= len(template) or type(template[i]).__name__ != _TQ_CLASS_NAME:
            continue
        tpl = template[i]
        # Create TQ cache with actual tensor dimensions (not template dims).
        # MLA models have different key/value dims than template due to
        # compression (e.g. template key_dim=128, actual KV dim=256).
        actual_key_dim = layer.keys.shape[-1]
        actual_val_dim = layer.values.shape[-1]
        tq = TurboQuantKVCache(
            key_dim=actual_key_dim,
            value_dim=actual_val_dim,
            key_bits=tpl.key_bits,
            value_bits=tpl.value_bits,
            sink_tokens=tpl.sink_tokens,
        )
        # Copy reconstructed float16 data into TQ
        tq.keys = layer.keys
        tq.values = layer.values
        tq.offset = layer.offset
        tq.step = getattr(layer, 'step', layer.keys.shape[2]) if layer.keys.ndim >= 3 else layer.offset
        # Compress to 3-bit — this creates _joined_k/_joined_v and clears .keys/.values
        tq.compress()
        result[i] = tq
        tq_count += 1

    if tq_count > 0:
        logger.info(f"Re-compressed {tq_count} KV layers to TurboQuant (5x memory savings)")
    return result


def _dequantize_cache(cache: List[Any]) -> List[Any]:
    """Dequantize QuantizedKVCache layers to KVCache for batch generation.

    BatchGenerator requires full-precision KVCache objects for merge/extract.
    Returns original cache unmodified if no quantized layers found.
    Recurses into CacheList sub-caches for MoE models.
    """
    try:
        from mlx_lm.models.cache import KVCache, QuantizedKVCache
        try:
            from mlx_lm.models.cache import CacheList as _CacheList
        except ImportError:
            _CacheList = None
    except ImportError:
        return cache

    has_quantized = any(isinstance(c, QuantizedKVCache) for c in cache)
    has_cachelist = _CacheList is not None and any(isinstance(c, _CacheList) for c in cache)
    if not has_quantized and not has_cachelist:
        return cache

    result = []
    for layer_cache in cache:
        if _CacheList is not None and isinstance(layer_cache, _CacheList):
            # MoE: recurse into each sub-cache
            dequantized_subs = []
            for sc in layer_cache.caches:
                if isinstance(sc, QuantizedKVCache):
                    if sc.keys is not None:
                        try:
                            kv = KVCache()
                            kv.keys = mx.dequantize(
                                sc.keys[0], sc.keys[1],
                                sc.keys[2], sc.group_size, sc.bits,
                            )
                            kv.values = mx.dequantize(
                                sc.values[0], sc.values[1],
                                sc.values[2], sc.group_size, sc.bits,
                            )
                            kv.offset = sc.offset
                            dequantized_subs.append(kv)
                        except Exception as e:
                            logger.warning(f"KV dequantization failed in CacheList sub-cache: {e}")
                            return None
                    else:
                        dequantized_subs.append(KVCache())
                else:
                    dequantized_subs.append(sc)
            result.append(_CacheList(*dequantized_subs))
        elif isinstance(layer_cache, QuantizedKVCache):
            if layer_cache.keys is not None:
                try:
                    kv = KVCache()
                    kv.keys = mx.dequantize(
                        layer_cache.keys[0], layer_cache.keys[1],
                        layer_cache.keys[2], layer_cache.group_size, layer_cache.bits,
                    )
                    kv.values = mx.dequantize(
                        layer_cache.values[0], layer_cache.values[1],
                        layer_cache.values[2], layer_cache.group_size, layer_cache.bits,
                    )
                    kv.offset = layer_cache.offset
                    result.append(kv)
                except Exception as e:
                    logger.warning(f"KV dequantization failed: {e}, discarding cached prefix")
                    return None  # Caller should do full prefill instead of using broken cache
            else:
                # QuantizedKVCache with keys=None — empty layer, use fresh KVCache
                # (cannot pass QuantizedKVCache to BatchGenerator)
                result.append(KVCache())
        else:
            result.append(layer_cache)
    return result


def _fix_hybrid_cache(
    cache: List[Any],
    language_model: nn.Module,
    kv_positions: Optional[List[int]] = None,
    num_model_layers: Optional[int] = None,
) -> List[Any]:
    """Fix reconstructed cache for hybrid models (SSM + attention layers).

    Prefix cache stores ONLY KVCache (attention) layers — SSM/ArraysCache layers
    are cumulative state and get skipped during extraction. This means the
    reconstructed cache list has fewer entries than total model layers.

    For example, Qwen3.5 9B has 32 layers (8 attention + 24 SSM), but prefix
    cache only stores the 8 attention layers. The reconstructed list of 8 must
    be expanded back to 32 by inserting fresh ArraysCache at SSM positions.

    Args:
        cache: Reconstructed cache list (may be shorter than model layers)
        language_model: The language model (for make_cache() template)
        kv_positions: Pre-computed KVCache layer indices (skips recomputation)
        num_model_layers: Pre-computed total layer count
    """
    if not hasattr(language_model, 'make_cache'):
        return cache
    # Guard: cache must be a list, not BatchKVCache or other non-list type
    if not isinstance(cache, list):
        return cache

    try:
        from mlx_lm.models.cache import KVCache

        # Fast path: use pre-computed positions to check if fix is needed
        if kv_positions is not None and num_model_layers is not None:
            # Not a hybrid model (all layers are KVCache) — no fix needed
            if len(kv_positions) == num_model_layers:
                return cache
            # Cache already correct length — still need type-mismatch check below
            if len(cache) == num_model_layers:
                pass  # Fall through to type-mismatch repair at line 203+
            # Cache length doesn't match expected KV layer count — return fresh cache
            elif len(cache) != len(kv_positions):
                logger.warning(
                    f"Cache length mismatch: {len(cache)} reconstructed vs "
                    f"{len(kv_positions)} KV positions in {num_model_layers}-layer model, "
                    "returning fresh cache"
                )
                return language_model.make_cache()

        # Need make_cache() for fresh SSM objects at non-KV positions
        template = language_model.make_cache()
        n_layers = len(template)

        if len(cache) == n_layers:
            # Same length — check for type mismatches (KVCache at SSM positions)
            fixed = False
            result = list(cache)
            for i, (tmpl, cached) in enumerate(zip(template, cache)):
                if not _is_kv_like(tmpl) and _is_kv_like(cached):
                    result[i] = tmpl
                    fixed = True
            if fixed:
                logger.debug("Fixed hybrid cache: replaced KVCache at SSM positions")
            return result

        # Cache shorter than model — expand using template
        positions = kv_positions if kv_positions is not None else [
            i for i, t in enumerate(template) if _is_kv_like(t)
        ]
        if len(cache) != len(positions):
            logger.warning(
                f"Cache length mismatch: {len(cache)} reconstructed vs "
                f"{len(positions)} KV positions in {n_layers}-layer model, "
                "returning fresh cache"
            )
            return template

        result = list(template)
        for cache_idx, model_idx in enumerate(positions):
            result[model_idx] = cache[cache_idx]

        logger.debug(
            f"Expanded hybrid cache: {len(cache)} KV layers -> "
            f"{n_layers} total ({len(positions)} KV + "
            f"{n_layers - len(positions)} SSM)"
        )
        return result
    except Exception as e:
        logger.warning(f"_fix_hybrid_cache failed: {e}, returning fresh cache")
        if hasattr(language_model, 'make_cache'):
            return language_model.make_cache()
        return cache


# SSM companion cache moved to vmlx_engine/utils/ssm_companion_cache.py per
# REQ-A3-001 (option C — Agent 3 owns the file forever, Agent 2 owns the
# call sites). Imported here as `HybridSSMStateCache` (back-compat alias) so
# existing call sites in this file and `scheduler.py` continue to work.
# The new class signature is:
#   store(token_ids, num_tokens, ssm_states, is_complete: bool = True)
#   fetch(token_ids, num_tokens) -> Optional[Tuple[List[Any], bool]]
# Fetch sites in this file have been updated to unpack the new tuple.
# See `agentprogress/3/notes-to-2.md` for the migration guide and
# `agentprogress/2/decisions.md` D-A2-007 for the option-C rationale.
from .utils.ssm_companion_cache import HybridSSMStateCache, SSMCompanionCache  # noqa: F401


@dataclass
class MLLMBatchRequest:
    """
    Request data for MLLM batch processing.

    Contains all information needed to process a multimodal request
    within the batch generator.
    """

    uid: int  # Unique identifier within the batch generator
    request_id: str  # External request ID
    prompt: str  # Text prompt
    images: Optional[List[str]] = None  # Image paths/URLs/base64
    videos: Optional[List[str]] = None  # Video inputs
    max_tokens: int = 256
    temperature: float = 0.7
    top_p: float = 0.9
    top_k: int = 0
    min_p: float = 0.0
    repetition_penalty: float = 1.0

    # Video processing parameters (per-request overrides)
    video_fps: Optional[float] = None
    video_max_frames: Optional[int] = None

    # Processed inputs (set after vision preprocessing)
    input_ids: Optional[mx.array] = None
    pixel_values: Optional[mx.array] = None
    attention_mask: Optional[mx.array] = None
    image_grid_thw: Optional[mx.array] = None
    extra_kwargs: Dict[str, Any] = field(default_factory=dict)

    # Generation state
    num_tokens: int = 0  # Tokens generated so far
    output_tokens: List[int] = field(default_factory=list)

    # Vision state
    vision_encoded: bool = False

    # Prefix cache state
    prompt_cache: Optional[List[Any]] = None  # Pre-filled KV cache from Prefix Cache or Disk Cache


@dataclass
class MLLMBatchResponse:
    """
    Response from a batch generation step.

    Contains the generated token and metadata for a single request.
    """

    uid: int  # Batch generator UID
    request_id: str  # External request ID
    token: int  # Generated token
    logprobs: mx.array  # Log probabilities
    # "stop", "length", "error", or None. "error" is used for prefill failures
    # that the batched engine catches and converts into a client-visible error
    # (see Issue #56 Bug 1). Without a distinct reason, silent prefill crashes
    # look like normal empty completions to the client.
    finish_reason: Optional[str] = None
    prompt_cache: Optional[Callable[[], List[Any]]] = None  # Cache extraction function
    prompt_token_ids: Optional[List[int]] = None  # Original tokenized prompt for prefix key
    cached_tokens: int = 0  # Number of prompt tokens served from cache
    # Generation-prefix tokens captured from the untruncated prompt tail
    # (e.g. [<|im_start|>, assistant, \n, <think>, \n] for Qwen 3.6 thinking-on).
    # Thinking models occasionally re-emit these as their first output tokens
    # when prior assistant history lacks a reasoning_content wrapper; the
    # scheduler uses this list to suppress the echoed prefix from the output
    # stream. Empty when no gen-prefix was stripped.
    gen_prefix_tokens: Optional[List[int]] = None
    # Optional human-readable error message attached when finish_reason="error".
    # Scheduler and server.py lift this into an HTTP error response so users
    # can see the actual mlx / mlx_vlm traceback instead of an empty 200.
    error: Optional[str] = None


@dataclass
class MLLMBatch:
    """
    Represents an active batch of MLLM requests.

    Manages the batch state including tokens, caches, and metadata
    for all requests being processed together.
    """

    uids: List[int]
    request_ids: List[str]
    y: mx.array  # Current token(s) for each request [batch_size]
    logprobs: List[mx.array]  # Log probs for each request
    max_tokens: List[int]  # Max tokens per request
    num_tokens: List[int]  # Tokens generated per request
    cache: List[Any]  # BatchKVCache for language model
    requests: List[MLLMBatchRequest]  # Full request data

    def __len__(self) -> int:
        return len(self.uids)

    def filter(self, keep_idx: List[int]) -> None:
        """
        Filter batch to keep only requests at specified indices.

        Args:
            keep_idx: Indices of requests to keep
        """
        self.uids = [self.uids[k] for k in keep_idx]
        self.request_ids = [self.request_ids[k] for k in keep_idx]
        self.logprobs = [self.logprobs[k] for k in keep_idx]
        self.max_tokens = [self.max_tokens[k] for k in keep_idx]
        self.num_tokens = [self.num_tokens[k] for k in keep_idx]
        self.requests = [self.requests[k] for k in keep_idx]

        keep_idx_array = mx.array(keep_idx, mx.int32)
        self.y = self.y[keep_idx_array]

        # Filter cache entries
        try:
            from mlx_lm.models.cache import CacheList as _CacheList
        except ImportError:
            _CacheList = None
        for c in self.cache:
            if _CacheList is not None and isinstance(c, _CacheList):
                # CacheList (MoE models): filter each sub-cache independently
                for sc in c.caches:
                    if hasattr(sc, "filter"):
                        sc.filter(keep_idx_array)
            elif hasattr(c, "filter"):
                c.filter(keep_idx_array)

    def extend(self, other: "MLLMBatch") -> None:
        """
        Extend this batch with another batch's requests.

        Merges all metadata lists and extends cache layers. Both batches
        must have batch-aware caches (BatchKVCache/BatchMambaCache) — raw
        KVCache/ArraysCache cannot be extended.

        Args:
            other: Another MLLMBatch to merge into this one
        """
        self.uids.extend(other.uids)
        self.request_ids.extend(other.request_ids)
        self.y = mx.concatenate([self.y, other.y])
        self.logprobs.extend(other.logprobs)
        self.max_tokens.extend(other.max_tokens)
        self.num_tokens.extend(other.num_tokens)
        self.requests.extend(other.requests)
        try:
            from mlx_lm.models.cache import CacheList as _CacheList
        except ImportError:
            _CacheList = None
        for c, o in zip(self.cache, other.cache):
            if _CacheList is not None and isinstance(c, _CacheList):
                # CacheList (MoE models): extend each sub-cache independently
                for sc, so in zip(c.caches, o.caches):
                    sc.extend(so)
            else:
                c.extend(o)

    def extract_cache(self, idx: int) -> List[Any]:
        """
        Extract cache for a single request (for caching).

        Args:
            idx: Index of request in batch

        Returns:
            Cache state for that request
        """
        extracted = []
        try:
            from mlx_lm.models.cache import CacheList as _CacheList
        except ImportError:
            _CacheList = None
        for c in self.cache:
            if _CacheList is not None and isinstance(c, _CacheList):
                # CacheList (MoE models): extract from each sub-cache
                sub_extracted = []
                for sc in c.caches:
                    if hasattr(sc, "extract"):
                        layer = sc.extract(idx)
                        if hasattr(layer, "keys") and layer.keys is not None:
                            layer.keys = mx.contiguous(layer.keys)
                            layer.values = mx.contiguous(layer.values)
                        sub_extracted.append(layer)
                    elif idx == 0:
                        sub_extracted.append(sc)
                    else:
                        sub_extracted.append(None)
                extracted.append(_CacheList(*sub_extracted))
            elif hasattr(c, "extract"):
                # Batched cache (BatchKVCache, BatchMambaCache) — extract single request
                layer = c.extract(idx)
                # Make extracted keys/values contiguous: BatchKVCache.extract()
                # returns sliced views that reference the full batch tensor.
                # Without contiguous(), the full batch tensor stays alive in memory
                # even after the batch is freed.
                if hasattr(layer, "keys") and layer.keys is not None:
                    layer.keys = mx.contiguous(layer.keys)
                    layer.values = mx.contiguous(layer.values)
                extracted.append(layer)
            elif idx == 0:
                # Unbatched cache (KVCache, ArraysCache) from single-request path —
                # return the cache itself since there's only one request
                extracted.append(c)
            else:
                extracted.append(None)
        return extracted


class MLLMBatchStats:
    """Statistics for MLLM batch generation."""

    def __init__(self):
        self.prompt_tokens: int = 0
        self.prompt_time: float = 0
        self.generation_tokens: int = 0
        self.generation_time: float = 0
        self.vision_encoding_time: float = 0
        self.num_images_processed: int = 0
        self.peak_memory: float = 0

    @property
    def prompt_tps(self) -> float:
        if self.prompt_time == 0:
            return 0
        return self.prompt_tokens / self.prompt_time

    @property
    def generation_tps(self) -> float:
        if self.generation_time == 0:
            return 0
        return self.generation_tokens / self.generation_time

    def to_dict(self) -> Dict[str, Any]:
        return {
            "prompt_tokens": self.prompt_tokens,
            "prompt_time": self.prompt_time,
            "prompt_tps": self.prompt_tps,
            "generation_tokens": self.generation_tokens,
            "generation_time": self.generation_time,
            "generation_tps": self.generation_tps,
            "vision_encoding_time": self.vision_encoding_time,
            "num_images_processed": self.num_images_processed,
            "peak_memory": self.peak_memory,
        }



def _merge_caches(caches: List[List[Any]]) -> List[Any]:
    """
    Merge a list of per-request caches into batch-aware caches.

    Handles KVCache→BatchKVCache, RotatingKVCache→BatchRotatingKVCache,
    QuantizedKVCache→BatchKVCache (dequantize first),
    MambaCache/ArraysCache→BatchMambaCache, CacheList (recursive),
    and any type with a compatible .merge() class method.
    """
    from mlx_lm.models.cache import BatchKVCache, KVCache, RotatingKVCache, ArraysCache
    try:
        from mlx_lm.models.cache import MambaCache as _MambaCache
    except ImportError:
        _MambaCache = ArraysCache
    try:
        from mlx_lm.models.cache import QuantizedKVCache as _QuantizedKVCache
    except ImportError:
        _QuantizedKVCache = None
    try:
        from mlx_lm.models.cache import CacheList as _CacheList
    except ImportError:
        _CacheList = None
    try:
        from mlx_lm.generate import BatchRotatingKVCache
    except ImportError:
        BatchRotatingKVCache = None

    batch_cache = []
    for i in range(len(caches[0])):
        layer_cache = caches[0][i]
        layer_caches = [c[i] for c in caches]

        try:
            if _QuantizedKVCache is not None and isinstance(layer_cache, _QuantizedKVCache):
                # Dequantize all layers before merging as regular KVCache
                dequantized = []
                for qkv in layer_caches:
                    if qkv.keys is None:
                        dequantized.append(KVCache())
                    else:
                        kv = KVCache()
                        kv.keys = mx.dequantize(
                            qkv.keys[0], qkv.keys[1], qkv.keys[2],
                            qkv.group_size, qkv.bits,
                        )
                        kv.values = mx.dequantize(
                            qkv.values[0], qkv.values[1], qkv.values[2],
                            qkv.group_size, qkv.bits,
                        )
                        kv.offset = qkv.offset
                        dequantized.append(kv)
                batch_cache.append(BatchKVCache.merge(dequantized))
            elif isinstance(layer_cache, RotatingKVCache):
                if BatchRotatingKVCache is not None:
                    batch_cache.append(BatchRotatingKVCache.merge(layer_caches))
                else:
                    logger.warning(f"Layer {i}: RotatingKVCache but BatchRotatingKVCache unavailable")
                    batch_cache.append(BatchKVCache([0] * len(caches)))
            elif _is_kv_like(layer_cache):
                # TQ: .keys buffer is over-allocated in 256-token chunks.
                # BatchKVCache.merge() reads .keys directly, so convert to
                # properly sliced KVCache via .state before merging.
                if type(layer_cache).__name__ == _TQ_CLASS_NAME:
                    converted = []
                    for tq in layer_caches:
                        kv = KVCache()
                        k, v = tq.state
                        if k is not None and hasattr(k, 'shape'):
                            kv.keys = k
                            kv.values = v
                            kv.offset = tq.offset
                        converted.append(kv)
                    batch_cache.append(BatchKVCache.merge(converted))
                else:
                    batch_cache.append(BatchKVCache.merge(layer_caches))
            elif isinstance(layer_cache, (_MambaCache, ArraysCache)):
                from .utils.mamba_cache import BatchMambaCache
                batch_cache.append(BatchMambaCache.merge(layer_caches))
            elif _CacheList is not None and isinstance(layer_cache, _CacheList):
                # CacheList: merge each sub-cache independently across requests
                num_sub = len(layer_cache.caches)
                merged_subs = []
                for j in range(num_sub):
                    # Collect sub-cache j from all requests' CacheList at this layer
                    sub_caches = [[c.caches[j]] for c in layer_caches]
                    sub_merged = _merge_caches(sub_caches)[0]
                    merged_subs.append(sub_merged)
                batch_cache.append(_CacheList(*merged_subs))
            elif hasattr(layer_cache, "merge"):
                batch_cache.append(type(layer_cache).merge(layer_caches))
            else:
                logger.warning(f"Layer {i}: {type(layer_cache).__name__} has no merge(), using empty BatchKVCache")
                batch_cache.append(BatchKVCache([0] * len(caches)))
        except Exception as e:
            logger.warning(f"Layer {i} merge failed ({type(layer_cache).__name__}), using fallback empty cache: {e}")
            if isinstance(layer_cache, (_MambaCache, ArraysCache)):
                from .utils.mamba_cache import BatchMambaCache
                batch_cache.append(BatchMambaCache(size=2, left_padding=[0] * len(caches)))
            else:
                batch_cache.append(BatchKVCache([0] * len(caches)))
    return batch_cache


def _ensure_batch_cache(cache: List[Any]) -> List[Any]:
    """Convert unbatched caches to batch-aware format for a single request.

    When a batch was created with a single request, _process_prompts() keeps
    raw KVCache/ArraysCache to preserve integer offsets (needed by Qwen3.5).
    When a second request needs to extend() into this batch, the cache must
    be converted to BatchKVCache/BatchMambaCache first.

    This wraps each layer cache using merge([cache]) which creates the
    batch-aware version with batch_size=1.
    """
    from mlx_lm.models.cache import KVCache, ArraysCache, BatchKVCache
    try:
        from mlx_lm.models.cache import QuantizedKVCache
    except ImportError:
        QuantizedKVCache = None
    try:
        from mlx_lm.models.cache import RotatingKVCache
    except ImportError:
        RotatingKVCache = None
    try:
        from mlx_lm.models.cache import CacheList as _CacheList
    except ImportError:
        _CacheList = None
    try:
        from mlx_lm.generate import BatchRotatingKVCache
    except ImportError:
        BatchRotatingKVCache = None

    converted = []
    for c in cache:
        if isinstance(c, BatchKVCache):
            converted.append(c)  # Already batch-aware
        elif QuantizedKVCache is not None and isinstance(c, QuantizedKVCache):
            # QuantizedKVCache (sibling of KVCache, both extend _BaseCache)
            # must be dequantized before merge — .keys is a tuple, not array
            dq = _dequantize_cache([c])
            if dq and len(dq) == 1:
                converted.append(BatchKVCache.merge([dq[0]]))
            else:
                # Dequant failed — use fresh KVCache
                converted.append(BatchKVCache.merge([KVCache()]))
        elif _is_kv_like(c):
            # TQ: convert via .state to avoid over-allocated buffer
            if type(c).__name__ == _TQ_CLASS_NAME:
                kv = KVCache()
                k, v = c.state
                if k is not None and hasattr(k, 'shape'):
                    kv.keys = k
                    kv.values = v
                    kv.offset = c.offset
                converted.append(BatchKVCache.merge([kv]))
            else:
                converted.append(BatchKVCache.merge([c]))
        elif RotatingKVCache is not None and isinstance(c, RotatingKVCache):
            if BatchRotatingKVCache is not None:
                converted.append(BatchRotatingKVCache.merge([c]))
            else:
                converted.append(BatchKVCache.merge([c]))
        elif isinstance(c, ArraysCache):
            from .utils.mamba_cache import BatchMambaCache
            converted.append(BatchMambaCache.merge([c]))
        elif _CacheList is not None and isinstance(c, _CacheList):
            # Recursively convert each sub-cache
            inner = _ensure_batch_cache(list(c.caches))
            converted.append(_CacheList(*inner))
        elif hasattr(c, "merge"):
            converted.append(type(c).merge([c]))
        else:
            # Unknown type — wrap as single-element merge via _merge_caches
            converted.append(c)
    return converted


class _BatchOffsetSafeCache:
    """Proxy that ensures cache.offset returns a scalar int, not mx.array.

    Several VL model attention layers (Qwen3.5, Qwen2.5-VL, Qwen2-VL, Qwen3-VL,
    Qwen3-VL-MoE, Qwen3-Omni-MoE) use cache.offset directly in slice operations
    like ``mask[..., :kv_seq_len]`` which requires a Python int. When multiple
    requests are batched, BatchKVCache.offset is an mx.array of per-request
    offsets, causing "Slice indices must be integers or None".

    This proxy wraps a BatchKVCache and intercepts .offset reads to return
    the **maximum** offset as a scalar int. Using max (not first element) ensures
    the attention mask is wide enough for ALL sequences in the batch, preventing
    broadcast shape mismatches when sequences have different lengths. The mask's
    built-in left_padding handling already masks out invalid positions for shorter
    sequences.

    Only applied during _step() when batch_size > 1. Single-request batches
    keep original KVCache objects (which already have int offsets).
    """

    __slots__ = ("_inner",)

    def __init__(self, inner):
        object.__setattr__(self, "_inner", inner)

    @property
    def offset(self):
        raw = self._inner.offset
        if isinstance(raw, mx.array):
            return (raw if raw.ndim == 0 else raw.max()).item()
        return raw

    @offset.setter
    def offset(self, value):
        self._inner.offset = value

    def __getattr__(self, name):
        return getattr(self._inner, name)

    def __setattr__(self, name, value):
        if name in _BatchOffsetSafeCache.__slots__:
            object.__setattr__(self, name, value)
        else:
            setattr(self._inner, name, value)

    def __bool__(self):
        # BatchKVCache is always truthy when it exists (used in `if cache:` checks)
        return True

    def __len__(self):
        if hasattr(self._inner, "__len__"):
            return len(self._inner)
        # BatchKVCache doesn't implement __len__; return batch size from offset
        raw = self._inner.offset
        if isinstance(raw, mx.array) and raw.ndim > 0:
            return raw.shape[0]
        return 1

    def __iter__(self):
        if hasattr(self._inner, "__iter__"):
            return iter(self._inner)
        raise TypeError(f"'{type(self._inner).__name__}' object is not iterable")

    def __repr__(self):
        return f"_BatchOffsetSafeCache({self._inner!r})"


def _wrap_batch_caches(cache: List[Any]) -> List[Any]:
    """Wrap BatchKVCache objects with offset-safe proxies for VL model compat.

    Returns the list with BatchKVCache entries wrapped in _BatchOffsetSafeCache.
    Non-BatchKVCache entries (MambaCache, ArraysCache, etc.) pass through unchanged.
    """
    try:
        from mlx_lm.models.cache import BatchKVCache
    except ImportError:
        return cache

    wrapped = []
    for c in cache:
        if isinstance(c, BatchKVCache):
            wrapped.append(_BatchOffsetSafeCache(c))
        else:
            wrapped.append(c)
    return wrapped


class MLLMBatchGenerator:
    """Batch generator for Vision Language Models on Apple Metal.

    This is the low-level generation engine. The MLLMScheduler creates one
    instance and delegates all prefill/decode work to it.

    **Two-phase generation:**

    1. **Prefill** (``_process_prompts``):
       Vision encoding + language model forward pass, per-request.
       Each request gets its own KVCache/ArraysCache, then all are merged
       into batch-aware caches (BatchKVCache/BatchMambaCache) for decode.

    2. **Decode** (``step``):
       Language model generates one token for ALL active requests at once.
       Uses batched cache for efficient parallel generation.

    **Cache integration:**

    Receives cache objects (paged, memory-aware, legacy, disk) from the
    scheduler. Handles cache fetch in _process_prompts (before prefill)
    and exposes cache extraction via MLLMBatchResponse.prompt_cache
    (after generation, for store by scheduler).

    **Hybrid model support:**

    Pre-computes ``_hybrid_kv_positions`` and ``_hybrid_num_layers`` at init.
    Maintains ``HybridSSMStateCache`` for SSM state at prompt boundary.
    Uses ``_fix_hybrid_cache()`` to expand KV-only reconstructed caches.

    **Metal memory:**

    Sets ``mx.metal.set_cache_limit()`` at 25% of max working set,
    uses ``mx.async_eval()`` in prefill, ``mx.contiguous()`` on extracted
    cache. Restores old limits in ``close()``.

    Example::

        generator = MLLMBatchGenerator(model, processor)
        uids = generator.insert([request1, request2])
        while responses := generator.next():
            for resp in responses:
                print(f"Request {resp.request_id}: token={resp.token}")
    """

    # Generation stream for async eval
    _stream = None

    def __init__(
        self,
        model: nn.Module,
        processor: Any,
        max_tokens: int = 256,
        stop_tokens: Optional[set] = None,
        sampler: Optional[Callable[[mx.array], mx.array]] = None,
        prefill_batch_size: int = 4,  # Smaller for MLLM due to vision overhead
        completion_batch_size: int = 16,  # Can be larger for text generation
        prefill_step_size: int = 1024,
        enable_vision_cache: bool = True,
        vision_cache_size: int = 16,
        paged_cache_manager: Optional[Any] = None,
        block_aware_cache: Optional[Any] = None,
        memory_aware_cache: Optional[Any] = None,
        prefix_cache: Optional[Any] = None,
        disk_cache: Optional[Any] = None,
        kv_cache_bits: int = 0,
        kv_cache_group_size: int = 64,
        ssm_state_cache_size: int = 50,
    ):
        """
        Initialize MLLM batch generator.

        Args:
            model: The VLM model (must have model.language_model)
            processor: The VLM processor for tokenization and image processing
            max_tokens: Default max tokens per request
            stop_tokens: Set of stop token IDs
            sampler: Sampling function (default: argmax)
            prefill_batch_size: Max requests to prefill together
            completion_batch_size: Max requests for completion batching
            prefill_step_size: Tokens to process per prefill step
            enable_vision_cache: Enable vision embedding caching
            vision_cache_size: Max entries in vision cache
            paged_cache_manager: Optional PagedCacheManager
            block_aware_cache: Optional BlockAwarePrefixCache
            memory_aware_cache: Optional MemoryAwarePrefixCache
            prefix_cache: Optional PrefixCacheManager (legacy)
            disk_cache: Optional DiskCacheManager (L2)
            kv_cache_bits: Quantization bits (0=none, 4=q4, 8=q8)
            kv_cache_group_size: Quantization group size
            ssm_state_cache_size: Max entries in HybridSSMStateCache (LRU)
        """
        self.model = model
        self.processor = processor
        self.paged_cache_manager = paged_cache_manager
        self.block_aware_cache = block_aware_cache
        self.memory_aware_cache = memory_aware_cache
        self.prefix_cache = prefix_cache
        self.disk_cache = disk_cache
        self._kv_cache_bits = kv_cache_bits
        self._kv_cache_group_size = kv_cache_group_size

        # Companion SSM state cache for hybrid models (MambaCache + KVCache).
        # Stores SSM layer states at prompt boundary so hybrid cache HITs can
        # skip the full prefix instead of wasting the KV cache hit.
        self._ssm_state_cache = HybridSSMStateCache(max_entries=ssm_state_cache_size)

        # Async rederive queue for MLLM thinking models. When we capture SSM
        # state post-full-prefill (is_complete=False, gpl-contaminated), we
        # queue a deferred clean-prefill task that runs during idle cycles
        # (no active requests). The clean prefill processes just prompt[:-gpl]
        # tokens so the captured state matches its key — future fetches hit
        # with is_complete=True. Capped at 20 entries.
        self._ssm_rederive_queue: List[Tuple[List[int], int, str]] = []
        self._ssm_rederive_queue_max = 20

        # Get language model for text generation
        self.language_model = getattr(model, "language_model", model)

        # Check if this is actually a VLM with separate language model
        self.is_vlm = hasattr(model, "language_model")
        if self.is_vlm:
            logger.info(
                "MLLMBatchGenerator: Using VLM's language_model for batched generation"
            )
        else:
            logger.warning(
                "MLLMBatchGenerator: Model does not have language_model, using model directly"
            )

        self.max_tokens = max_tokens
        self.stop_tokens = stop_tokens or set()
        self.sampler = sampler or (lambda x: mx.argmax(x, axis=-1))

        self.prefill_batch_size = prefill_batch_size
        self.completion_batch_size = max(completion_batch_size, prefill_batch_size)
        self.prefill_step_size = prefill_step_size

        # Request management
        self.unprocessed_requests: List[MLLMBatchRequest] = []
        self.active_batch: Optional[MLLMBatch] = None
        self.uid_counter = 0
        self._prefill_errors: List[MLLMBatchResponse] = []  # Failed requests from prefill

        # Statistics
        self._stats = MLLMBatchStats()

        # Pre-compute hybrid cache template info (avoids make_cache() per request)
        self._hybrid_kv_positions: Optional[List[int]] = None
        self._hybrid_num_layers: Optional[int] = None
        if hasattr(self.language_model, 'make_cache'):
            try:
                from mlx_lm.models.cache import KVCache
                template = self.language_model.make_cache()
                self._hybrid_num_layers = len(template)
                self._hybrid_kv_positions = [i for i, t in enumerate(template) if _is_kv_like(t)]
            except Exception as e:
                logger.warning(f"Failed to pre-compute hybrid cache info: {e}")

        # Pre-computed bool: is this a hybrid model (SSM + attention)?
        # Used throughout _process_prompts and _run_vision_encoding to gate
        # hybrid-specific logic (SSM companion cache, chunked prefill skip, etc.)
        self._is_hybrid: bool = (
            self._hybrid_kv_positions is not None
            and self._hybrid_num_layers is not None
            and len(self._hybrid_kv_positions) < self._hybrid_num_layers
        )

        # Vision embedding cache for repeated images
        self.vision_cache = VisionEmbeddingCache(
            max_pixel_entries=vision_cache_size,
            enabled=enable_vision_cache,
        )
        if enable_vision_cache:
            logger.info(
                f"MLLMBatchGenerator: Vision cache enabled (size={vision_cache_size})"
            )

        # Generation stream
        if MLLMBatchGenerator._stream is None:
            MLLMBatchGenerator._stream = mx.new_stream(mx.default_device())

        # Memory management
        self._old_wired_limit = None
        self._old_cache_limit = None
        if mx.metal.is_available():
            # Use non-deprecated API when available (MLX ≥ 0.25)
            _device_info = getattr(mx, 'device_info', None) or mx.metal.device_info
            _set_cache = getattr(mx, 'set_cache_limit', None) or mx.metal.set_cache_limit
            if True:  # Always set Metal limits (smelt mode doesn't need special limits)
                self._old_wired_limit = mx.set_wired_limit(
                    _device_info()["max_recommended_working_set_size"]
                )
                # Set Metal allocator cache limit.
                # mlxstudio#78: previously was a hard `max_ws * 0.25`, which
                # on a 64GB M4 Max loading Gemma-4-31B (~41GB active) would
                # reserve 12GB for cache on top of 41GB model → 53GB required
                # vs 48GB max working set → Metal command buffer OOM on the
                # FIRST request before a single token is generated.
                #
                # New policy: cap at min(25% of max_ws, 50% of FREE memory
                # after model load). Floor at 512MB. This keeps the original
                # behavior on machines with plenty of headroom (bounds the
                # free-list so the OS can reclaim memory when pressured)
                # while adapting on tight-memory systems where the model
                # already consumed most of the budget.
                try:
                    max_ws = _device_info()["max_recommended_working_set_size"]
                    _get_active = (
                        getattr(mx, "get_active_memory", None)
                        or mx.metal.get_active_memory
                    )
                    active = _get_active()
                    free = max(0, max_ws - active)
                    # Base policy: 25% of max_ws (unchanged semantics on
                    # big-headroom systems).
                    base_limit = int(max_ws * 0.25)
                    # Safety cap: don't reserve more than 50% of FREE
                    # memory, so activations + KV + attention_scores have
                    # the other half to live in without forcing the
                    # allocator to release pooled blocks back to Metal.
                    safety_limit = int(free * 0.5)
                    cache_limit = max(
                        512 * 1024 * 1024, min(base_limit, safety_limit)
                    )
                    self._old_cache_limit = _set_cache(cache_limit)
                    logger.info(
                        f"Metal cache limit set to {cache_limit / (1024**3):.2f}GB "
                        f"(max_ws={max_ws / (1024**3):.1f}GB, "
                        f"active={active / (1024**3):.1f}GB, "
                        f"free={free / (1024**3):.1f}GB; "
                        f"base={base_limit / (1024**3):.2f}GB "
                        f"safety={safety_limit / (1024**3):.2f}GB; "
                        f"mlxstudio#78)"
                    )
                    if safety_limit < base_limit:
                        logger.warning(
                            "Tight-memory configuration detected: model is "
                            "using a large fraction of max working set. "
                            "Cache limit adjusted downward. If requests OOM, "
                            "try a more aggressively quantized model or "
                            "reduce prompt length. (mlxstudio#78)"
                        )
                except Exception as e:
                    logger.debug(f"Metal cache limit not available: {e}")
            else:
                logger.info("Disk-streaming mode: skipping wired limit + cache limit override")

    def close(self) -> None:
        """Release resources and reset wired/cache limits."""
        if self._old_wired_limit is not None:
            mx.synchronize(MLLMBatchGenerator._stream)
            mx.set_wired_limit(self._old_wired_limit)
            self._old_wired_limit = None
        if self._old_cache_limit is not None:
            try:
                _set_cache = getattr(mx, 'set_cache_limit', None) or mx.metal.set_cache_limit
                _set_cache(self._old_cache_limit)
            except Exception:
                pass
            self._old_cache_limit = None

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass

    def insert(
        self,
        requests: List[MLLMBatchRequest],
        caches: Optional[List[Optional[List[Any]]]] = None,
    ) -> List[int]:
        """
        Insert requests for batch processing with optional prompt caches.

        Args:
            requests: List of MLLMBatchRequest to process
            caches: Optional list of prompt caches, one per request. None means no cache.

        Returns:
            List of UIDs assigned to requests
        """
        if caches is None:
            caches = [None] * len(requests)

        uids = []
        for req, c in zip(requests, caches):
            req.uid = self.uid_counter
            self.uid_counter += 1
            if c is not None:
                req.prompt_cache = c
            self.unprocessed_requests.append(req)
            uids.append(req.uid)

        # Sort by estimated complexity (no images = simpler)
        self.unprocessed_requests = sorted(
            self.unprocessed_requests,
            key=lambda x: (
                0 if not x.images and not x.videos else 1,
                len(x.images or []) + len(x.videos or []),
            ),
        )

        logger.debug(f"Inserted {len(requests)} requests, UIDs: {uids}")
        return uids

    def remove(self, uids: List[int]) -> None:
        """
        Remove requests from processing.

        Args:
            uids: List of UIDs to remove
        """
        uid_set = set(uids)

        # Remove from active batch
        if self.active_batch is not None:
            keep_idx = [
                i for i, uid in enumerate(self.active_batch.uids) if uid not in uid_set
            ]
            if keep_idx:
                self.active_batch.filter(keep_idx)
            else:
                self.active_batch = None

        # Remove from unprocessed
        self.unprocessed_requests = [
            r for r in self.unprocessed_requests if r.uid not in uid_set
        ]

    def _preprocess_request(self, request: MLLMBatchRequest) -> None:
        """
        Preprocess a single MLLM request (vision encoding).

        This prepares the inputs by:
        1. Processing images/videos through the processor
        2. Tokenizing the prompt with image tokens
        3. Running vision encoder to get features

        Uses vision cache to skip processing for repeated images.
        **Fast-path**: text-only requests (no images/videos) skip the full
        VLM processor pipeline and use the tokenizer directly, avoiding
        ~100ms+ of vision processor overhead per request.

        Args:
            request: Request to preprocess
        """
        tic = time.perf_counter()

        # FAST PATH: text-only requests skip VLM processor entirely.
        # For API-driven workloads (e.g. MMLU benchmarks with 14k short requests),
        # per-request VLM processor overhead dominates. The tokenizer alone is
        # sufficient when no images or videos are present.
        is_text_only = not request.images and not request.videos
        if is_text_only:
            tokenizer = getattr(self.processor, "tokenizer", self.processor)
            # Use add_special_tokens=False because the prompt has already been
            # through apply_chat_template() which embeds BOS/EOS tokens.
            # Calling encode() with default add_special_tokens=True would
            # double-add BOS, misaligning prefix cache keys.
            try:
                token_ids = tokenizer.encode(request.prompt, add_special_tokens=False)
            except TypeError:
                # Tokenizer doesn't support add_special_tokens kwarg.
                # Fall through to the full VLM processor path to avoid
                # double-BOS from default add_special_tokens=True on
                # an already-formatted prompt.
                logger.debug(
                    f"Tokenizer {type(tokenizer).__name__} does not support "
                    f"add_special_tokens; falling back to VLM processor path"
                )
                is_text_only = False  # force slow path
            if is_text_only:
                request.input_ids = mx.array(token_ids)
                request.pixel_values = None
                request.attention_mask = None
                request.image_grid_thw = None
                request.extra_kwargs = {}
                processing_time = time.perf_counter() - tic
                logger.debug(
                    f"Text-only fast-path for {request.request_id}: "
                    f"{len(token_ids)} tokens ({processing_time*1000:.1f}ms)"
                )
                return

        from mlx_vlm.utils import prepare_inputs

        # Collect all images (including video frames)
        all_images = []

        if request.images:
            from .models.mllm import process_image_input

            for img in request.images:
                try:
                    path = process_image_input(img)
                    all_images.append(path)
                except Exception as e:
                    logger.warning(f"Failed to process image: {e}")

        if request.videos:
            from .models.mllm import (
                process_video_input,
                extract_video_frames_smart,
                save_frames_to_temp,
                DEFAULT_FPS,
                MAX_FRAMES,
            )

            fps = request.video_fps or DEFAULT_FPS
            max_frames = request.video_max_frames or MAX_FRAMES

            for video in request.videos:
                try:
                    video_path = process_video_input(video)
                    frames = extract_video_frames_smart(
                        video_path,
                        fps=fps,
                        max_frames=max_frames,
                    )
                    frame_paths = save_frames_to_temp(frames)
                    all_images.extend(frame_paths)
                except Exception as e:
                    logger.warning(f"Failed to process video: {e}")

        # Check pixel cache first
        cached_pixels = self.vision_cache.get_pixel_cache(all_images, request.prompt)
        if cached_pixels is not None:
            # Cache hit - use cached pixel values
            request.input_ids = cached_pixels.input_ids
            request.pixel_values = cached_pixels.pixel_values
            request.attention_mask = cached_pixels.attention_mask
            request.image_grid_thw = cached_pixels.image_grid_thw
            request.extra_kwargs = dict(cached_pixels.extra_kwargs)

            logger.debug(
                f"Pixel cache HIT for request {request.request_id}: "
                f"saved {cached_pixels.processing_time:.2f}s"
            )
            return

        # Cache miss - process images
        # Get model config
        model_config = getattr(self.model, "config", None)
        image_token_index = (
            getattr(model_config, "image_token_index", None) if model_config else None
        )

        # Prepare inputs using mlx_vlm.
        # prepare_inputs has a BaseImageProcessor path that hardcodes split("<image>").
        # Models using a different image token (e.g. Gemma 4 uses "<|image|>") never
        # get their images processed through that path. When the prompt has images but
        # no "<image>" literal, bypass prepare_inputs and call process_inputs directly
        # which invokes the processor's native __call__ (handles any image token format).
        if all_images and "<image>" not in request.prompt:
            from mlx_vlm.utils import process_inputs
            inputs = process_inputs(
                self.processor,
                prompts=request.prompt,
                images=all_images,
                add_special_tokens=False,
            )
        else:
            inputs = prepare_inputs(
                self.processor,
                images=all_images if all_images else None,
                prompts=request.prompt,
                image_token_index=image_token_index,
            )

        # Issue #56 Bug 1 root fix — normalize input_ids to mx.int32.
        # mlx_vlm's various processors (Mistral3 / Pixtral / Gemma4 / Qwen3.5-VL)
        # return input_ids as numpy arrays, torch tensors, or mx arrays with
        # varying dtypes depending on the upstream transformers version. When a
        # quantized embedding (`nn.QuantizedEmbedding` packed uint32 weights)
        # receives a numpy/torch index or an mx int64, MLX raises
        # `ValueError: Cannot index mlx array using the given type` — and the
        # batched engine's outer prefill-except then silently queued an empty
        # "stop" response (#56). The SimpleEngine path never hit this because
        # mlx_vlm.generate() does its own dtype normalization before forward.
        def _ensure_mx_array(x, target_dtype=None):
            """Normalize numpy / torch / list / mx inputs to an mx.array,
            optionally casting to a specific dtype. Pixtral / Mistral 3 /
            Qwen3.5-VL processors all return different wire formats; the
            batched engine then passes the raw value straight into forward,
            which chokes with either `Cannot index mlx array using the given
            type` (QuantizedEmbedding) or `Cannot interpret mlx.core.bfloat16
            as a data type` (numpy.astype against an mx dtype). Normalizing
            once here makes all downstream layer calls match the SimpleEngine
            path."""
            if x is None:
                return None
            if not isinstance(x, mx.array):
                try:
                    if hasattr(x, "tolist"):
                        x = mx.array(x.tolist())
                    else:
                        x = mx.array(x)
                except Exception:
                    return x  # give up gracefully, downstream will error
            if target_dtype is not None and x.dtype != target_dtype:
                try:
                    x = x.astype(target_dtype)
                except Exception:
                    pass
            return x

        # Issue #56 — normalize input_ids + pixel_values + attention_mask
        # before storing on the request. Covers Mistral 3 / Pixtral,
        # Qwen3.5-VL, Gemma 4, and future VLM families without having to
        # special-case each processor's output format.
        request.input_ids = _ensure_mx_array(inputs.get("input_ids"), mx.int32)
        request.pixel_values = _ensure_mx_array(inputs.get("pixel_values"))
        request.attention_mask = _ensure_mx_array(inputs.get("attention_mask"))

        # Extract extra kwargs
        request.extra_kwargs = {
            k: v
            for k, v in inputs.items()
            if k not in ["input_ids", "pixel_values", "attention_mask"]
        }
        request.image_grid_thw = request.extra_kwargs.pop("image_grid_thw", None)

        processing_time = time.perf_counter() - tic

        # Store in pixel cache for future reuse
        if all_images and request.pixel_values is not None:
            self.vision_cache.set_pixel_cache(
                images=all_images,
                prompt=request.prompt,
                pixel_values=request.pixel_values,
                input_ids=request.input_ids,
                attention_mask=request.attention_mask,
                image_grid_thw=request.image_grid_thw,
                extra_kwargs=request.extra_kwargs,
                processing_time=processing_time,
            )

        self._stats.num_images_processed += len(all_images)
        self._stats.vision_encoding_time += processing_time

        logger.debug(
            f"Preprocessed request {request.request_id}: "
            f"{len(all_images)} images, {request.input_ids.size if request.input_ids is not None else 0} tokens "
            f"({processing_time:.2f}s)"
        )

    def _run_vision_encoding(self, request: MLLMBatchRequest, cache: Optional[List[Any]] = None) -> mx.array:
        """
        Run the initial VLM forward pass to encode vision and get first logits.

        For image requests: runs full VLM model (vision + language) in one shot
        (vision encoding cannot be chunked).

        For text-only requests or long prompts after cache hit: uses chunked prefill
        via prefill_step_size to reduce peak GPU memory and enable interleaving.

        Args:
            request: Preprocessed request with input_ids and pixel_values
            cache: Optional pre-initialized BatchKVCache list

        Returns:
            Logits from the forward pass
        """
        kwargs = dict(request.extra_kwargs)
        # Only pass pixel_values when non-None. Smelt-loaded models use a
        # text-only wrapper whose __call__ does NOT accept pixel_values at
        # all — passing even None triggers `unexpected keyword argument
        # 'pixel_values'`. For standard VLM models, pixel_values=None is a
        # no-op that the vision encoder skips, so omitting it is safe.
        if request.pixel_values is not None:
            kwargs["pixel_values"] = request.pixel_values
        if request.attention_mask is not None:
            kwargs["mask"] = request.attention_mask
        if request.image_grid_thw is not None:
            kwargs["image_grid_thw"] = request.image_grid_thw
        if cache is not None:
            kwargs["cache"] = cache

        input_ids = request.input_ids
        if input_ids.ndim == 1:
            input_ids = input_ids[None, :]

        has_images = request.pixel_values is not None
        seq_len = input_ids.shape[1]

        # vmlx#89: opt-in chunked prefill for hybrid SSM models on text-only
        # requests. Hybrid models default to one-shot prefill because their
        # mask computation uses cache-position indexing (fa_idx/ssm_idx) that
        # was only tested for full-sequence processing. However, long prompts
        # (>~34K tokens) trigger Metal single-buffer OOM (~72 GB cap per
        # allocation) because `attention_scores` blows up to
        # (1, heads, seq_len, seq_len) * 2 bytes — 147 GB at seq_len=48K.
        #
        # Qwen3.5 hybrid (GatedDeltaNet + attention) was verified safe with
        # chunked prefill: both `KVCache.make_mask(N)` and `ArraysCache.state`
        # carry across chunks correctly. Reporter opt-in so other hybrid
        # architectures keep default behavior until verified.
        _allow_hybrid_chunked = os.environ.get(
            "VMLX_ALLOW_HYBRID_CHUNKED_PREFILL"
        ) in ("1", "true", "True", "yes", "on")
        _hybrid_blocks_chunk = self._is_hybrid and not _allow_hybrid_chunked

        # TEXT-ONLY FAST PATH: use language_model directly, skip VLM wrapper.
        # The VLM wrapper adds overhead from vision encoder path and some VLM
        # wrappers (e.g. Gemma 4 loaded via smelt) may not accept pixel_values.
        # Using language_model directly avoids this entirely.
        # Hybrid SSM models must go through the full model for correct mask
        # computation UNLESS the opt-in env var is set (vmlx#89).
        if not has_images and not _hybrid_blocks_chunk:
            lm = getattr(self.model, 'language_model', None)
            if lm is not None and cache is not None:
                if seq_len <= self.prefill_step_size * 2:
                    # Short text: single-shot through language_model
                    output = lm(input_ids, cache=cache)
                    request.vision_encoded = True
                    if hasattr(output, "logits"):
                        return output.logits
                    return output

        # Chunked prefill for text-only VLM requests with long prompts.
        # Image requests must run in one shot (vision encoder needs full sequence).
        # Hybrid SSM default: one-shot (safe). Opt-in via
        # VMLX_ALLOW_HYBRID_CHUNKED_PREFILL=1 for hybrid architectures that
        # have been verified cache-aware (Qwen3.5 GatedDeltaNet + attention).
        if not has_images and seq_len > self.prefill_step_size * 2 and not _hybrid_blocks_chunk:
            # Use language_model directly for chunked text prefill
            lm = getattr(self.model, 'language_model', None)
            if lm is not None and cache is not None:
                processed = 0
                chunk_num = 0
                while processed < seq_len - 1:  # -1: keep last token for final logits
                    chunk_size = min(self.prefill_step_size, seq_len - 1 - processed)
                    chunk = input_ids[:, processed:processed + chunk_size]
                    try:
                        lm(chunk, cache=cache)
                    except Exception as chunk_err:
                        # Log cache state at failure point for diagnosis
                        _cache_diag = []
                        for ci, cc in enumerate(cache[:6]):
                            if hasattr(cc, 'keys') and cc.keys is not None:
                                _cache_diag.append(f"L{ci}:KV={cc.keys.shape}")
                            elif hasattr(cc, 'cache') and isinstance(cc.cache, list):
                                shapes = [a.shape if a is not None else 'None' for a in cc.cache]
                                _cache_diag.append(f"L{ci}:SSM={shapes}")
                            elif hasattr(cc, 'offset'):
                                _cache_diag.append(f"L{ci}:off={cc.offset}")
                            else:
                                _cache_diag.append(f"L{ci}:{type(cc).__name__}")
                        logger.error(
                            f"Chunked prefill failed at chunk {chunk_num} "
                            f"(processed={processed}, chunk_size={chunk_size}, "
                            f"total={seq_len}): {chunk_err} "
                            f"[cache: {', '.join(_cache_diag)}]"
                        )
                        raise
                    mx.eval([c.state for c in cache if hasattr(c, 'state')])
                    processed += chunk_size
                    chunk_num += 1
                    mx.clear_cache()

                # Final chunk: get logits from last token
                last_chunk = input_ids[:, processed:]
                output = lm(last_chunk, cache=cache)
                request.vision_encoded = True
                if hasattr(output, "logits"):
                    return output.logits
                return output

        # Standard single-shot VLM forward (image requests or short text).
        # For text-only requests, try language_model first to avoid passing
        # pixel_values to models that may not accept it (e.g. smelt-loaded VLM
        # where the VLM wrapper's __call__ signature differs from standard mlx-vlm).
        if not has_images:
            lm = getattr(self.model, 'language_model', None)
            if lm is not None:
                lm_kwargs = {}
                if cache is not None:
                    lm_kwargs["cache"] = cache
                output = lm(input_ids, **lm_kwargs)
                request.vision_encoded = True
                if hasattr(output, "logits"):
                    return output.logits
                return output

        output = self.model(input_ids, **kwargs)
        request.vision_encoded = True

        if hasattr(output, "logits"):
            return output.logits
        return output

    def _process_prompts(
        self, requests: List[MLLMBatchRequest], force_batch_cache: bool = False
    ) -> MLLMBatch:
        """Prefill all requests: vision encoding, cache fetch, and batch merge.

        This is the most complex method in the batch generator. For each request:

        1. **Preprocess**: tokenize prompt + process pixel values via mlx-vlm processor.
           Save original token IDs before any cache mutation.
        2. **Cache fetch** (3 tiers + disk L2 fallback):
           - Paged: block_aware_cache.fetch_cache() -> reconstruct -> hybrid check
           - Memory-aware/Legacy: cache_obj.fetch() -> hybrid check
           - Disk L2: disk_cache.fetch() (only if in-memory missed)
           On HIT: set req.prompt_cache, trim req.input_ids, clear pixel_values.
           On HIT (hybrid + SSM companion): inject SSM state into full cache.
        3. **Vision encoding**: _run_vision_encoding() does full VLM forward pass.
           Uses req.prompt_cache if available (cache HIT = shorter prefix).
        4. **Async submit**: mx.async_eval() submits sampled token + cache states
           to GPU without blocking, enabling CPU/GPU overlap across requests.
        5. **SSM state capture** (hybrid models only): after prefill of fresh
           prompts, deep-copy SSM layer states into HybridSSMStateCache. Uses
           _original_token_ids (pre-mutation) for consistent keying.
        6. **Cache merge**: merge per-request caches into batch-aware caches
           (KVCache->BatchKVCache, MambaCache->BatchMambaCache). Single request
           optimization: keep original caches to preserve integer offsets.

        Returns:
            MLLMBatch with merged cache, first tokens, and request metadata.
        """
        tic = time.perf_counter()

        for req in requests:
            self._preprocess_request(req)
            # Save full token list BEFORE cache fetch can mutate req.input_ids.
            # Used later for SSM state cache keying (must be consistent with fetch key).
            _all_tokens = (
                req.input_ids.tolist()
                if req.input_ids is not None and req.input_ids.ndim == 1
                else req.input_ids[0].tolist()
                if req.input_ids is not None
                else []
            )
            # Strip generation prompt tokens from the cache key.
            # Chat templates append assistant role tokens (e.g. <|im_start|>assistant\n<think>\n)
            # at the end. The store path in mllm_scheduler._cleanup_finished() strips these
            # before storing block hashes. The fetch key here MUST match.
            _gpl = getattr(req, '_gen_prompt_len', 0)
            if _gpl > 0 and _gpl < len(_all_tokens):
                # Capture the gen-prefix tokens BEFORE trimming so the
                # scheduler's output-side re-emit suppressor can compare
                # against them. Without this, thinking models on dense
                # multi-turn history (no reasoning_content wrapper in prior
                # assistant messages) re-emit `<|im_start|>assistant\n<think>\n`
                # as their first output tokens, corrupting the reasoning
                # stream for the user.
                req._gen_prefix_tokens = list(_all_tokens[-_gpl:])
                _all_tokens = _all_tokens[:-_gpl]
            else:
                req._gen_prefix_tokens = []
            req._original_token_ids = _all_tokens
            # Track how many prompt tokens were served from cache (for usage reporting)
            req._cached_tokens = 0
            # After preprocessing, the prompt is fully tokenized including image patches.
            # Query the BlockAwarePrefixCache for reusable KV blocks.
            # fetch_cache returns (block_table, remaining_tokens) — NOT cache objects!
            # IMPORTANT: Skip prefix cache for requests WITH images — image placeholder
            # tokens are identical for same-sized images regardless of content, so a
            # cache hit would serve KV states from a different image's vision encoding.
            # Text-only follow-up requests (no new images) can safely use prefix cache.
            has_images = req.pixel_values is not None
            # Per-request cache bypass (cache_salt / skip_prefix_cache).
            # When set, skip every VLM prefix-cache layer — paged, memory-aware,
            # legacy prefix, disk L2, SSM companion — so benchmark runs get
            # fresh execution without pollution from prior multimodal requests.
            _mllm_bypass = bool(getattr(req, "_bypass_prefix_cache", False))
            if self.block_aware_cache is not None and req.prompt_cache is None and not has_images and not _mllm_bypass:
                if req.input_ids is not None:
                    try:
                        _full_token_list = req.input_ids.tolist() if req.input_ids.ndim == 1 else req.input_ids[0].tolist()
                        # Strip gen_prompt_len from fetch key to match store key.
                        # CRITICAL: keep the stripped gpl suffix — after fetching we MUST
                        # prepend it back to `remaining` so the model re-sees the
                        # `<|im_start|>assistant\n<think>\n` template tokens on turn 2.
                        # Without this the model's prefill skips the thinking marker and
                        # jumps straight to content, producing "1 completion token → EOS"
                        # symptoms on hybrid thinking models (Qwen 3.5/3.6 VL, Nemotron
                        # Cascade, MiniMax). See bug trace 2026-04-21.
                        _gpl = getattr(req, '_gen_prompt_len', 0)
                        if _gpl > 0 and _gpl < len(_full_token_list):
                            token_list = _full_token_list[:-_gpl]
                            _gpl_suffix = _full_token_list[-_gpl:]
                        else:
                            token_list = _full_token_list
                            _gpl_suffix = []
                        block_table, remaining = self.block_aware_cache.fetch_cache(req.request_id, token_list)
                        if block_table is not None:
                                # Hybrid models (SSM + attention, e.g. Qwen3.5-VL):
                                # Prefix cache stores only KVCache (attention) layers.
                                # SSM layers are cumulative state that must process ALL tokens.
                                # For hybrid models without companion SSM state, the cached
                                # KV blocks are useless — skip reconstruction entirely to
                                # avoid allocating huge tensors that will be thrown away.
                                is_hybrid = self._is_hybrid

                                if is_hybrid:
                                    # Check companion SSM state cache BEFORE reconstruction.
                                    # Use actual prompt token count (not block-aligned) to match
                                    # the store key which also uses len(all_tokens).
                                    # REQ-A3-001: fetch now returns Optional[Tuple[List[Any], bool]].
                                    # is_complete unused here (live MLLM fetch path, not the trie
                                    # path) — Agent 1's PrefixCacheManager consumes it.
                                    _fetch_num = block_table.num_tokens
                                    _entry = self._ssm_state_cache.fetch(
                                        token_list, _fetch_num
                                    ) if _fetch_num > 0 else None
                                    if _entry is None:
                                        ssm_states = None
                                    else:
                                        ssm_states, _is_complete = _entry
                                        # is_complete=False means the stored SSM state
                                        # was captured AFTER processing the full prompt
                                        # including the gen_prompt_len (<think>\n) suffix.
                                        # The state represents more tokens than the key
                                        # claims — re-using it while re-feeding the gpl
                                        # suffix double-applies those tokens and causes
                                        # <think></think> generation loops. Reject the
                                        # hit and fall back to full prefill until we have
                                        # a proper pre-gpl capture path.
                                        if not _is_complete:
                                            logger.info(
                                                f"SSM companion for {req.request_id}: "
                                                f"is_complete=False (gpl-contaminated), "
                                                f"rejecting hit — full prefill"
                                            )
                                            ssm_states = None
                                    if ssm_states is None:
                                        # vmlx#91: exact SSM state miss — resume from the
                                        # longest stored checkpoint whose tokens are a strict
                                        # prefix of the current query. Default ON in v1.3.66;
                                        # set VMLX_DISABLE_SSM_PREFIX_RESUME=1 to force the
                                        # legacy full-prefill path.
                                        import os as _os
                                        _enable_resume = _os.environ.get(
                                            "VMLX_DISABLE_SSM_PREFIX_RESUME"
                                        ) not in ("1", "true", "True", "yes", "on")
                                        _missed_ck = None
                                        _fn = getattr(
                                            self._ssm_state_cache,
                                            "fetch_longest_prefix",
                                            None,
                                        )
                                        if _enable_resume and _fn is not None and _fetch_num > 0:
                                            try:
                                                _missed_ck = _fn(token_list, _fetch_num)
                                            except Exception:
                                                _missed_ck = None

                                        if _enable_resume and _missed_ck is not None:
                                            _ck_len, _ck_states, _ck_complete = _missed_ck
                                            if not _ck_complete:
                                                # Checkpoint was captured post-gpl-prefill
                                                # — state reflects more tokens than the
                                                # stored key. Reject to avoid the same
                                                # <think></think> loop seen on direct hits.
                                                logger.info(
                                                    f"vmlx#91 RESUME skipped for {req.request_id}: "
                                                    f"checkpoint at {_ck_len} has is_complete=False "
                                                    f"(gpl-contaminated) — full prefill"
                                                )
                                                self.block_aware_cache.release_cache(req.request_id)
                                                continue
                                            # Trim the block_table down to block-aligned
                                            # <= _ck_len so KV + SSM stay aligned.
                                            trimmed = self.block_aware_cache.trim_block_table(
                                                req.request_id, _ck_len
                                            )
                                            if trimmed is not None and trimmed.num_tokens > 0:
                                                block_table = trimmed
                                                ssm_states = _ck_states
                                                logger.info(
                                                    f"vmlx#91 RESUME for {req.request_id}: "
                                                    f"trimmed KV to {trimmed.num_tokens} tokens "
                                                    f"(block-aligned from checkpoint at {_ck_len}), "
                                                    f"SSM state reused from checkpoint. "
                                                    f"Prefill tail: {_fetch_num - trimmed.num_tokens} tokens"
                                                )
                                                # Fall through to reconstruct with the trimmed
                                                # block_table + ssm_states.
                                            else:
                                                # Trim returned None (e.g. checkpoint below
                                                # one block) — fall back to full prefill.
                                                logger.info(
                                                    f"vmlx#91 RESUME skipped for {req.request_id}: "
                                                    f"checkpoint at {_ck_len} below one block — "
                                                    f"full prefill required"
                                                )
                                                self.block_aware_cache.release_cache(req.request_id)
                                                continue
                                        else:
                                            if _missed_ck is not None:
                                                _ck_len, _, _ = _missed_ck
                                                logger.info(
                                                    f"VLM prefix cache MISS for {req.request_id}: "
                                                    f"{block_table.num_tokens} KV blocks found but "
                                                    f"resume path disabled (VMLX_DISABLE_SSM_PREFIX_RESUME=1); "
                                                    f"stored checkpoint at {_ck_len} tokens was available. "
                                                    f"Full prefill required."
                                                )
                                            else:
                                                logger.info(
                                                    f"VLM prefix cache MISS for {req.request_id}: "
                                                    f"{block_table.num_tokens} KV blocks found but "
                                                    f"no SSM companion state — full prefill required"
                                                )
                                            # Release the block refs that fetch_cache incremented
                                            # to prevent ref_count leak → OOM on subsequent requests.
                                            self.block_aware_cache.release_cache(req.request_id)
                                            continue  # Skip reconstruction

                                # Either non-hybrid OR hybrid with SSM state — reconstruct
                                reconstructed = self.block_aware_cache.reconstruct_cache(block_table)
                                if reconstructed is not None:
                                    reconstructed = _dequantize_cache(reconstructed)
                                    if reconstructed is None:
                                        # Dequantize failed — release block refs to prevent leak
                                        self.block_aware_cache.release_cache(req.request_id)
                                        continue
                                if is_hybrid and ssm_states is not None and reconstructed is not None:
                                    # Full hybrid cache reconstruction:
                                    # KV from paged cache + SSM from companion cache
                                    full_cache = _fix_hybrid_cache(
                                        reconstructed, self.language_model,
                                        kv_positions=self._hybrid_kv_positions,
                                        num_model_layers=self._hybrid_num_layers,
                                    )
                                    # Inject stored SSM states at non-KV positions
                                    kv_set = set(self._hybrid_kv_positions or [])
                                    ssm_idx = 0
                                    for layer_idx in range(len(full_cache)):
                                        if layer_idx not in kv_set and ssm_idx < len(ssm_states):
                                            full_cache[layer_idx] = ssm_states[ssm_idx]
                                            ssm_idx += 1
                                    # TQ recompress safe: blocks now store original float16
                                    req.prompt_cache = full_cache
                                    req._cached_tokens = block_table.num_tokens
                                    # Re-attach the gen-prompt suffix: fetch key was
                                    # gpl-stripped but the model MUST see the template
                                    # suffix (<|im_start|>assistant\n<think>\n) to enter
                                    # thinking mode on turn 2.
                                    _full_remaining = (remaining or []) + list(_gpl_suffix)
                                    if _full_remaining:
                                        req.input_ids = mx.array([_full_remaining])
                                        req.pixel_values = None
                                        req.attention_mask = None
                                        req.image_grid_thw = None
                                        logger.info(
                                            f"VLM HYBRID cache HIT for {req.request_id}: "
                                            f"{block_table.num_tokens} cached (KV+SSM), "
                                            f"{len(_full_remaining)} remaining "
                                            f"(incl. {len(_gpl_suffix)}-token gen-prompt suffix)"
                                        )
                                    else:
                                        req.input_ids = mx.array([token_list[-1:]])
                                        req.pixel_values = None
                                        req.attention_mask = None
                                        req.image_grid_thw = None
                                        logger.info(
                                            f"VLM HYBRID cache FULL HIT for {req.request_id}: "
                                            f"{block_table.num_tokens} cached (KV+SSM)"
                                        )
                                elif not is_hybrid and reconstructed is not None:
                                    # Pure attention VLM: TQ recompress safe (original float16)
                                    req.prompt_cache = reconstructed
                                    req._cached_tokens = block_table.num_tokens
                                    # Re-attach gen-prompt suffix (see hybrid branch above
                                    # for full rationale — same correctness requirement
                                    # for attention-only thinking VLMs).
                                    _full_remaining = (remaining or []) + list(_gpl_suffix)
                                    if _full_remaining:
                                        # Check if remaining tokens contain image placeholders.
                                        # If so, we'd need partial pixel_values which is complex —
                                        # fall back to full prefill instead.
                                        model_config = getattr(self.model, "config", None)
                                        img_token_id = (
                                            getattr(model_config, "image_token_index", None)
                                            if model_config else None
                                        )
                                        has_images = img_token_id is not None and img_token_id in _full_remaining
                                        if has_images:
                                            req.prompt_cache = None
                                            req._cached_tokens = 0  # reset — full prefill needed
                                            logger.info(
                                                f"VLM prefix cache HIT for {req.request_id}: "
                                                f"{block_table.num_tokens} cached tokens, "
                                                f"remaining has images — full prefill"
                                            )
                                        else:
                                            req.input_ids = mx.array([_full_remaining])
                                            req.pixel_values = None
                                            req.attention_mask = None
                                            req.image_grid_thw = None
                                            logger.info(
                                                f"VLM prefix cache HIT for {req.request_id}: "
                                                f"{block_table.num_tokens} cached, "
                                                f"{len(_full_remaining)} remaining "
                                                f"(incl. {len(_gpl_suffix)}-token gen-prompt suffix)"
                                            )
                                    else:
                                        # All tokens cached. Need at least the last token
                                        # for a forward pass to get logits for sampling.
                                        req.input_ids = mx.array([token_list[-1:]])
                                        req.pixel_values = None
                                        req.attention_mask = None
                                        req.image_grid_thw = None
                                        logger.info(
                                            f"VLM prefix cache FULL HIT for {req.request_id}: "
                                            f"{block_table.num_tokens} cached tokens"
                                        )
                    except Exception as e:
                        logger.warning(f"Failed to fetch paged cache for {req.request_id}: {e}")

            # Memory-aware or legacy prefix cache fetch (non-paged paths)
            elif (self.memory_aware_cache is not None or self.prefix_cache is not None) and req.prompt_cache is None and not _mllm_bypass:
                if req.input_ids is not None:
                    try:
                        _full_token_list = req.input_ids.tolist() if req.input_ids.ndim == 1 else req.input_ids[0].tolist()
                        # Strip gen_prompt_len from fetch key, keep suffix to re-attach
                        # to `remaining` so the model re-sees the template suffix
                        # (<|im_start|>assistant\n<think>\n). See paged-path comment.
                        _gpl = getattr(req, '_gen_prompt_len', 0)
                        if _gpl > 0 and _gpl < len(_full_token_list):
                            token_list = _full_token_list[:-_gpl]
                            _gpl_suffix = _full_token_list[-_gpl:]
                        else:
                            token_list = _full_token_list
                            _gpl_suffix = []

                        # Try memory-aware cache first, then legacy
                        cache_obj = self.memory_aware_cache or self.prefix_cache
                        fetch_fn = getattr(cache_obj, 'fetch', None) or getattr(cache_obj, 'fetch_cache', None)
                        if fetch_fn is not None:
                            cache, remaining = fetch_fn(token_list)
                            if cache:
                                # Dequantize if KV cache quantization is active
                                if self._kv_cache_bits:
                                    cache = _dequantize_cache(cache)
                                    if cache is None:
                                        continue  # Dequantize failed, full prefill

                                # Hybrid model check (same logic as paged path)
                                is_hybrid = self._is_hybrid
                                if is_hybrid:
                                    logger.info(
                                        f"VLM memory/legacy cache HIT for {req.request_id}: "
                                        f"{len(token_list) - len(remaining)} cached tokens "
                                        f"(hybrid model — full prefill required)"
                                    )
                                else:
                                    req.prompt_cache = cache
                                    num_cached = len(token_list) - len(remaining)
                                    _full_remaining = (remaining or []) + list(_gpl_suffix)
                                    if _full_remaining:
                                        model_config = getattr(self.model, "config", None)
                                        img_token_id = (
                                            getattr(model_config, "image_token_index", None)
                                            if model_config else None
                                        )
                                        has_images = img_token_id is not None and img_token_id in _full_remaining
                                        if has_images:
                                            req.prompt_cache = None
                                            logger.info(
                                                f"VLM cache HIT for {req.request_id}: "
                                                f"remaining has images — full prefill"
                                            )
                                        else:
                                            req._cached_tokens = num_cached
                                            req.input_ids = mx.array([_full_remaining])
                                            req.pixel_values = None
                                            req.attention_mask = None
                                            req.image_grid_thw = None
                                            logger.info(
                                                f"VLM cache HIT for {req.request_id}: "
                                                f"{num_cached} cached, "
                                                f"{len(_full_remaining)} remaining "
                                                f"(incl. {len(_gpl_suffix)}-token gen-prompt suffix)"
                                            )
                                    else:
                                        req._cached_tokens = len(token_list)
                                        req.input_ids = mx.array([_full_token_list[-1:]])
                                        req.pixel_values = None
                                        req.attention_mask = None
                                        req.image_grid_thw = None
                                        logger.info(
                                            f"VLM cache FULL HIT for {req.request_id}: "
                                            f"{len(token_list)} cached tokens"
                                        )
                    except Exception as e:
                        logger.warning(f"Failed to fetch VLM cache for {req.request_id}: {e}")

            # L2: Disk cache fallback when in-memory cache missed.
            # DiskCacheManager.fetch() returns Optional[List[Any]] (exact match only,
            # no partial prefix), NOT a tuple like prefix_cache.fetch_cache().
            if req.prompt_cache is None and self.disk_cache is not None and not _mllm_bypass:
                if req.input_ids is not None:
                    try:
                        _full_token_list = req.input_ids.tolist() if req.input_ids.ndim == 1 else req.input_ids[0].tolist()
                        # Strip gen_prompt_len from fetch key, keep suffix to re-feed.
                        _gpl = getattr(req, '_gen_prompt_len', 0)
                        if _gpl > 0 and _gpl < len(_full_token_list):
                            token_list = _full_token_list[:-_gpl]
                            _gpl_suffix = _full_token_list[-_gpl:]
                        else:
                            token_list = _full_token_list
                            _gpl_suffix = []
                        disk_result = self.disk_cache.fetch(token_list)
                        if disk_result is not None:
                            if not self._is_hybrid:
                                # Check for image tokens in remaining suffix
                                model_config = getattr(self.model, "config", None)
                                img_token_id = (
                                    getattr(model_config, "image_token_index", None)
                                    if model_config else None
                                )
                                has_images = img_token_id is not None and img_token_id in token_list
                                if has_images:
                                    logger.info(
                                        f"VLM disk cache (L2) HIT for {req.request_id}: "
                                        f"has images — full prefill"
                                    )
                                else:
                                    # Dequantize if KV cache quantization is active
                                    if self._kv_cache_bits:
                                        disk_result = _dequantize_cache(disk_result)
                                    if disk_result is None:
                                        pass  # Dequantize failed, full prefill
                                    else:
                                        req.prompt_cache = disk_result
                                        req._cached_tokens = len(token_list)
                                        # Disk cache is exact-match on the gpl-stripped
                                        # prefix. Feed gpl suffix + last stripped token
                                        # so the model sees <|im_start|>assistant\n<think>\n
                                        # before sampling.
                                        _tail = _full_token_list[-(1 + len(_gpl_suffix)):] if _gpl_suffix else _full_token_list[-1:]
                                        req.input_ids = mx.array([_tail])
                                        req.pixel_values = None
                                        req.attention_mask = None
                                        req.image_grid_thw = None
                                        # Annotate cache_detail: "disk+tq" for TQ-native files,
                                        # "disk" for standard float16 format.
                                        _tq_disk = (
                                            hasattr(self.disk_cache, '_last_fetch_tq_native')
                                            and self.disk_cache._last_fetch_tq_native
                                        )
                                        req._cache_detail = "disk+tq" if _tq_disk else "disk"
                                        logger.info(
                                            f"VLM disk cache (L2) HIT for {req.request_id}: "
                                            f"{len(token_list)} cached tokens"
                                            f"{' (TQ-native)' if _tq_disk else ''}"
                                        )
                    except Exception as e:
                        logger.debug(f"VLM disk cache fetch failed for {req.request_id}: {e}")

        # Get token sequences and lengths
        input_ids_list = [
            req.input_ids.tolist() if req.input_ids is not None else [0]
            for req in requests
        ]
        lengths = [len(ids) for ids in input_ids_list]

        self._stats.prompt_tokens += sum(lengths)

        per_request_caches = []
        first_tokens = []
        all_logprobs = []
        succeeded_requests = []

        for i, req in enumerate(requests):
          try:
            with mx.stream(MLLMBatchGenerator._stream):
                # Reset stale per-batch module state on the language model before
                # each request's forward pass.
                #
                # Some mlx_vlm language models (Qwen3.5 / Qwen3.5-Moe hybrid SSM
                # family) cache `_rope_deltas` and `_position_ids` at module level
                # as an optimization for multi-step generation within a single
                # request. The upstream code only clears them when `pixel_values`
                # is not None (new vision request). On text-only follow-ups,
                # request N reuses request N-1's cached position_ids which has
                # the WRONG seq_length, producing broadcast errors like
                # `(1, 16, 56, 64) vs (1, 1, 20, 64)` at the first linear_attention
                # layer — because the slice `_position_ids[:, :, 0:L_new]` ends
                # up shorter than `L_new` and then broadcasts against the full
                # queries tensor. Fresh per-request clears fix this universally
                # and are a no-op for models that don't use these attributes.
                try:
                    _lm = self.language_model
                    for _attr in ("_rope_deltas", "_position_ids"):
                        if hasattr(_lm, _attr):
                            setattr(_lm, _attr, None)
                except Exception:
                    pass

                if req.prompt_cache is not None:
                    # Dequantize before _fix_hybrid_cache (it checks KVCache,
                    # not QuantizedKVCache which inherits from _BaseCache)
                    if self._kv_cache_bits:
                        cache_for_fix = _dequantize_cache(req.prompt_cache)
                        if cache_for_fix is None:
                            req.prompt_cache = None
                    else:
                        cache_for_fix = req.prompt_cache
                if req.prompt_cache is not None:
                    req_cache = _fix_hybrid_cache(
                        cache_for_fix, self.language_model,
                        kv_positions=self._hybrid_kv_positions,
                        num_model_layers=self._hybrid_num_layers,
                    )
                    pass  # TQ recompress removed from fetch paths
                else:
                    try:
                        if hasattr(self.language_model, 'make_cache'):
                            req_cache = self.language_model.make_cache()
                        else:
                            from mlx_lm.models.cache import KVCache
                            req_cache = [KVCache() for _ in self.language_model.layers]
                    except Exception as e:
                        logger.warning(f"model.make_cache() failed, falling back to KVCache: {e}")
                        from mlx_lm.models.cache import KVCache
                        req_cache = [KVCache() for _ in self.language_model.layers]

                try:
                    logits = self._run_vision_encoding(req, cache=req_cache)
                except ValueError as ve:
                    if "broadcast" in str(ve).lower():
                        # Cache shape mismatch (e.g., GQA head count differs between
                        # stored cache and model's current KV projection — root cause:
                        # BatchKVCache.merge() inflates H to max across all caches,
                        # so if any cache had expanded n_heads, extracted caches
                        # inherit inflated H and get stored in blocks with wrong shape).
                        # Discard cached prefix and retry with full prefill.
                        logger.warning(
                            f"Cache shape mismatch for {req.request_id}, "
                            f"retrying without prefix cache: {ve}"
                        )
                        # Release stale blocks so they can be evicted/overwritten —
                        # without this, next turn would hit the same stale block
                        # and retry every single turn
                        if self.block_aware_cache is not None:
                            try:
                                self.block_aware_cache.release_cache(req.request_id)
                            except Exception:
                                pass
                        req.prompt_cache = None
                        req.input_ids = mx.array([req._original_token_ids])
                        req.attention_mask = None
                        try:
                            if hasattr(self.language_model, 'make_cache'):
                                req_cache = self.language_model.make_cache()
                            else:
                                from mlx_lm.models.cache import KVCache
                                req_cache = [KVCache() for _ in self.language_model.layers]
                        except Exception:
                            # make_cache() failed — use KVCache as last resort.
                            # For hybrid models this will likely fail too
                            # (SSM layers need ArraysCache), but at least we tried.
                            from mlx_lm.models.cache import KVCache
                            req_cache = [KVCache() for _ in self.language_model.layers]
                        logits = self._run_vision_encoding(req, cache=req_cache)
                    else:
                        raise
                per_request_caches.append(req_cache)

                # Free pixel_values and vision tensors after encoding —
                # they're never needed again and can be very large for
                # high-res multi-image requests (fixes OOM on 122B + images)
                req.pixel_values = None
                req.attention_mask = None
                req.image_grid_thw = None
                req.extra_kwargs = {}

                last_logits = logits[:, -1, :]
                mx.eval(last_logits)  # materialize before freeing logits buffer
                del logits
                mx.clear_cache()
                logprobs = last_logits - mx.logsumexp(
                    last_logits, axis=-1, keepdims=True
                )
                req_sampler = self._make_request_sampler(req)
                sampled = req_sampler(logprobs)

                # Async submit cache states to GPU for CPU/GPU overlap
                try:
                    cache_states = []
                    for c in req_cache:
                        if hasattr(c, 'state'):
                            st = c.state
                            if isinstance(st, (list, tuple)):
                                cache_states.extend(x for x in st if x is not None)
                            elif st is not None:
                                cache_states.append(st)
                        elif hasattr(c, 'cache'):
                            cache_states.extend(x for x in c.cache if x is not None)
                    mx.async_eval(sampled, logprobs, *cache_states)
                except Exception as e:
                    logger.warning(f"Cache state submission error (non-fatal): {e}")
                    mx.async_eval(sampled, logprobs)

                first_tokens.append(sampled.item())
                all_logprobs.append(logprobs.squeeze(0))
                succeeded_requests.append(req)

                # Capture SSM state at prompt boundary for hybrid models.
                # Must fire on BOTH cache-miss AND cache-hit turns: on a hit,
                # the SSM state advances during prefill of remaining tokens,
                # so the next turn needs a fresh companion keyed on the longer
                # token list.  (Fixes alternating miss/hit pattern — #45)
                if self._is_hybrid:
                    # Guard: skip SSM capture+rederive on tokens containing
                    # image placeholder IDs. Rederive's text-only forward
                    # pass would produce wrong state at vision positions,
                    # corrupting text-only follow-up resume.
                    _img_id = getattr(getattr(self.model, "config", None), "image_token_index", None)
                    _tp = getattr(req, '_original_token_ids', None) or input_ids_list[i]
                    if _img_id is not None and _img_id in _tp:
                        continue
                    try:
                        kv_set = set(self._hybrid_kv_positions)
                        ssm_layers = []
                        for layer_idx, c in enumerate(req_cache):
                            if layer_idx not in kv_set:
                                if hasattr(c, 'cache') and isinstance(c.cache, list):
                                    from copy import deepcopy
                                    cloned = deepcopy(c)
                                    # Ensure MLX arrays are fully materialized copies
                                    cloned.cache = [
                                        mx.contiguous(mx.array(a)) if a is not None else None
                                        for a in c.cache
                                    ]
                                    ssm_layers.append(cloned)
                                else:
                                    ssm_layers.append(c)
                        if ssm_layers:
                            all_tokens = getattr(req, '_original_token_ids', None)
                            if all_tokens is None:
                                all_tokens = input_ids_list[i]
                            # MLLM paged cache stores at N-1 (truncated for re-feed)
                            # and block_table.num_tokens returns N-1 on fetch.
                            # SSM companion key must match.
                            prompt_len = len(all_tokens) - 1 if len(all_tokens) > 1 else len(all_tokens)
                            if prompt_len > 0:
                                # When gen_prompt_len > 0 (thinking models with
                                # a `<think>\n` template suffix), the captured
                                # SSM state covers the FULL prompt including
                                # those template tokens. Subsequent turns with
                                # the same exact template are fine, but mark
                                # is_complete=False so the fetch path can
                                # decide whether to trust the entry for
                                # differently-templated prefixes.
                                _gpl_for_flag = getattr(req, '_gen_prompt_len', 0)
                                _is_complete_flag = (_gpl_for_flag == 0)
                                if _is_complete_flag:
                                    # gpl=0 path — post-prefill state matches
                                    # its key, safe to store directly.
                                    self._ssm_state_cache.store(
                                        all_tokens, prompt_len, ssm_layers,
                                        is_complete=True,
                                    )
                                else:
                                    # gpl>0 (thinking models): queue deferred
                                    # clean re-prefill. Queue the FIRST
                                    # prompt_len tokens (not the full
                                    # all_tokens list), so _prefill_for_clean_ssm
                                    # produces state-at-prompt_len that matches
                                    # the key exactly. Passing full all_tokens
                                    # here produces state-at-N while the key is
                                    # N-1 → T2 HIT re-feeds token N-1 + gpl on
                                    # top of an already-advanced SSM state,
                                    # causing infinite generation loops
                                    # (v1.3.77 regression, v1.3.78 fix).
                                    _rq = self._ssm_rederive_queue
                                    if len(_rq) >= self._ssm_rederive_queue_max:
                                        _rq.pop(0)
                                    _rq.append(
                                        (list(all_tokens[:prompt_len]), prompt_len, req.request_id)
                                    )
                                logger.info(
                                    f"Captured SSM state for "
                                    f"{req.request_id}: {len(ssm_layers)} layers, "
                                    f"{prompt_len}-token key, "
                                    f"is_complete={_is_complete_flag} "
                                    f"(gen_prompt_len={_gpl_for_flag})"
                                )
                    except Exception as e:
                        logger.debug(f"SSM state capture failed for {req.request_id}: {e}")
          except Exception as prefill_err:
                # Broadcast shape errors from stale cache (prefix, paged blocks, or
                # residual batch state) — retry with completely fresh cache.
                # Don't require req.prompt_cache to be set: the stale shapes can come
                # from paged cache blocks that were fetched but didn't set prompt_cache,
                # or from batch KV cache state left over from the previous generation.
                if "broadcast" in str(prefill_err).lower():
                    # Log diagnostic info to identify stale shape source
                    _diag_parts = []
                    _diag_parts.append(f"prompt_cache={'set' if req.prompt_cache is not None else 'None'}")
                    _diag_parts.append(f"input_ids_shape={req.input_ids.shape if req.input_ids is not None else 'None'}")
                    _diag_parts.append(f"attn_mask={'set' if req.attention_mask is not None else 'None'}")
                    _diag_parts.append(f"pixel_values={'set' if req.pixel_values is not None else 'None'}")
                    if req.prompt_cache is not None:
                        for ci, cc in enumerate(req.prompt_cache[:3]):
                            if hasattr(cc, 'keys') and cc.keys is not None:
                                _diag_parts.append(f"cache[{ci}].keys={cc.keys.shape}")
                                break
                    logger.warning(
                        f"Cache shape mismatch for {req.request_id}, "
                        f"retrying without prefix cache: {prefill_err} "
                        f"[diag: {', '.join(_diag_parts)}]"
                    )
                    if self.block_aware_cache is not None:
                        try:
                            self.block_aware_cache.release_cache(req.request_id)
                        except Exception:
                            pass
                    req.prompt_cache = None
                    req.input_ids = mx.array([req._original_token_ids])
                    # Reset vision fields — on broadcast retry we do full prefill from scratch
                    req.pixel_values = None
                    req.attention_mask = None
                    req.image_grid_thw = None
                    req.extra_kwargs = {}
                    # Flush stale GPU state before retry
                    mx.clear_cache()
                    try:
                        from mlx_lm.models.cache import KVCache
                        try:
                            req_cache = self.language_model.make_cache()
                        except Exception:
                            req_cache = [KVCache() for _ in self.language_model.layers]
                        logits = self._run_vision_encoding(req, cache=req_cache)
                        per_request_caches.append(req_cache)
                        last_logits = logits[:, -1, :]
                        mx.eval(last_logits)  # materialize before freeing logits buffer
                        del logits
                        mx.clear_cache()
                        logprobs = last_logits - mx.logsumexp(last_logits, axis=-1, keepdims=True)
                        req_sampler = self._make_request_sampler(req)
                        sampled = req_sampler(logprobs)
                        mx.async_eval(sampled, logprobs)
                        first_tokens.append(sampled.item())
                        all_logprobs.append(logprobs.squeeze(0))
                        succeeded_requests.append(req)
                        continue  # Successfully retried
                    except Exception as retry_err:
                        # Nuclear retry: clear ALL paged cache blocks and try once more.
                        # Hybrid models (Mamba+Attention) can have stale state that
                        # persists even through make_cache() and mx.clear_cache().
                        if "broadcast" in str(retry_err).lower() and self.block_aware_cache is not None:
                            logger.warning(f"Retry failed with broadcast — clearing ALL paged cache and retrying once more: {retry_err}")
                            try:
                                self.block_aware_cache.clear()
                            except Exception:
                                pass
                            # A3→A2-001 (audit 2026-04-08): do NOT call
                            # _ssm_state_cache.clear() here. The previous nuclear
                            # clear dropped EVERY active session's SSM companion
                            # entries on a single failed prefill (multi-tenant
                            # blast radius). The retry below uses make_cache()
                            # which constructs a fresh hybrid cache instance —
                            # it does not read from the SSM companion. Other
                            # requests' stored entries are isolated by the
                            # deep-copy fetch contract (session 2026-03-28b
                            # root-cause fix), so leaving them in place is safe.
                            mx.clear_cache()
                            try:
                                # MUST use make_cache() for hybrid models — it returns
                                # the correct mix of KVCache + ArraysCache. Plain
                                # [KVCache() for _] breaks hybrid models that need
                                # ArraysCache.create_attention_mask().
                                if hasattr(self.language_model, 'make_cache'):
                                    req_cache = self.language_model.make_cache()
                                else:
                                    req_cache = [KVCache() for _ in self.language_model.layers]
                                logits = self._run_vision_encoding(req, cache=req_cache)
                                per_request_caches.append(req_cache)
                                last_logits = logits[:, -1, :]
                                mx.eval(last_logits)  # materialize before freeing logits buffer
                                del logits
                                mx.clear_cache()
                                logprobs = last_logits - mx.logsumexp(last_logits, axis=-1, keepdims=True)
                                req_sampler = self._make_request_sampler(req)
                                sampled = req_sampler(logprobs)
                                mx.async_eval(sampled, logprobs)
                                first_tokens.append(sampled.item())
                                all_logprobs.append(logprobs.squeeze(0))
                                succeeded_requests.append(req)
                                continue
                            except Exception as nuclear_err:
                                logger.error(f"Nuclear retry also failed for {req.request_id}: {nuclear_err}")
                        else:
                            logger.error(f"Retry also failed for {req.request_id}: {retry_err}")
                # Per-request prefill failure (bad image, OOM, etc.)
                # Clean up vision tensors — without this, pixel_values and partial
                # cache from make_cache() leak until GC collects them (hundreds of MB
                # for 122B+ models with high-res images).
                req.pixel_values = None
                req.attention_mask = None
                req.image_grid_thw = None
                req.extra_kwargs = {}
                mx.clear_cache()
                # Queue an immediate error response instead of killing the entire batch.
                # Issue #56 Bug 1: use finish_reason="error" + error string so the
                # scheduler → server path can raise an HTTP 500 with the real
                # traceback instead of a silent 200 with empty content. Previously
                # the client saw `{"content": null, "finish_reason": "stop",
                # "prompt_tokens": 0}` and had no way to distinguish "empty
                # completion" from "prefill crashed".
                import traceback as _tb
                _err_detail = f"{type(prefill_err).__name__}: {prefill_err}"
                logger.error(
                    f"Prefill failed for {req.request_id}: {_err_detail}\n"
                    f"{_tb.format_exc()}\n"
                    f"— other requests in batch will continue"
                )
                self._prefill_errors.append(MLLMBatchResponse(
                    uid=req.uid,
                    request_id=req.request_id,
                    token=0,
                    logprobs=mx.zeros((1,)),
                    finish_reason="error",
                    error=_err_detail,
                ))

        # Use only the successfully prefilled requests for the batch
        requests = succeeded_requests

        y = mx.array(first_tokens)

        # If all requests failed prefill, return empty batch
        if not succeeded_requests:
            self._stats.prompt_time += time.perf_counter() - tic
            return None

        # Merge per-request caches into batch-aware caches for batched decode.
        # Handles KVCache→BatchKVCache, MambaCache→BatchMambaCache, etc.
        try:
            if len(per_request_caches) == 1 and not force_batch_cache:
                # Single request with no active batch: keep raw KVCache/ArraysCache
                # to preserve integer offsets (Qwen3.5 needs cache.offset as int).
                # If force_batch_cache is True, we're extending into an active batch
                # and MUST produce batch-aware caches for extend() compatibility.
                batch_cache = per_request_caches[0]
            else:
                batch_cache = _merge_caches(per_request_caches)
        except Exception as e:
            logger.error(f"Cache merge failed: {e}")
            for req in requests:
                self._prefill_errors.append(
                    MLLMBatchResponse(
                        uid=req.uid,
                        request_id=req.request_id,
                        token=0,
                        logprobs=mx.zeros((1,)),
                        finish_reason="stop",
                    )
                )
            return None

        self._stats.prompt_time += time.perf_counter() - tic

        return MLLMBatch(
            uids=[req.uid for req in requests],
            request_ids=[req.request_id for req in requests],
            y=y,
            logprobs=all_logprobs,
            max_tokens=[req.max_tokens for req in requests],
            num_tokens=[0] * len(requests),
            cache=batch_cache,
            requests=requests,
        )

    def _make_request_sampler(self, request: MLLMBatchRequest) -> Callable[[mx.array], mx.array]:
        """Create a sampler for a specific request's sampling parameters.

        Each request can have different temperature/top_p/top_k/min_p.
        Repetition penalty is applied via logits_processors when set.
        Samplers are cached on the request to avoid per-step reconstruction.
        """
        cached = getattr(request, '_cached_sampler', None)
        if cached is not None:
            return cached

        from mlx_lm.sample_utils import make_sampler
        base_sampler = make_sampler(
            temp=request.temperature,
            top_p=request.top_p,
            top_k=request.top_k if request.top_k > 0 else 0,
            min_p=request.min_p if request.min_p > 0 else 0.0,
        )

        # Apply repetition penalty if set for this request
        rep_penalty = getattr(request, "repetition_penalty", 1.0)
        if rep_penalty is not None and rep_penalty != 1.0:
            from mlx_lm.sample_utils import make_logits_processors
            logits_procs = make_logits_processors(repetition_penalty=rep_penalty)
            # Use _original_token_ids (saved before cache fetch trims input_ids)
            # so repetition penalty covers the full prompt, not just uncached tokens.
            prompt_list = getattr(request, '_original_token_ids', None)
            if prompt_list is None:
                ids = request.input_ids
                prompt_list = ids[0].tolist() if ids is not None and ids.ndim > 1 else (
                    ids.tolist() if ids is not None else []
                )
            def sampler_with_penalty(logits, _req=request, _prompt_list=prompt_list):
                # Build full token sequence (prompt + generated) so penalty
                # applies to already-generated tokens, not just the prompt.
                all_tokens = mx.array(_prompt_list + _req.output_tokens)
                processed = logits
                for proc in logits_procs:
                    processed = proc(all_tokens, processed)
                return base_sampler(processed)
            request._cached_sampler = sampler_with_penalty
            return sampler_with_penalty

        request._cached_sampler = base_sampler
        return base_sampler

    def _step(
        self, input_tokens: mx.array, cache: List[Any]
    ) -> Tuple[mx.array, List[mx.array]]:
        """
        Run one generation step through the language model.

        Args:
            input_tokens: Input tokens [batch_size, 1] or [batch_size]
            cache: BatchKVCache for the language model

        Returns:
            Tuple of (sampled tokens, logprobs list)
        """
        # Ensure correct shape
        if input_tokens.ndim == 1:
            input_tokens = input_tokens[:, None]

        # Wrap BatchKVCache with offset-safe proxies for VL models.
        # Several Qwen VL attention layers use cache.offset in slice ops that
        # require int, but BatchKVCache.offset is mx.array. The proxy converts it.
        # Always wrap: a batch that started with N>1 requests can filter down to 1
        # while cache remains BatchKVCache (offset still mx.array). The proxy is a
        # no-op when offset is already int (single-request path with raw KVCache).
        cache = _wrap_batch_caches(cache)

        # Run language model only (not full VLM)
        output = self.language_model(input_tokens, cache=cache)

        # Handle LanguageModelOutput or plain tensor
        if hasattr(output, "logits"):
            logits = output.logits
        else:
            logits = output

        logits = logits[:, -1, :]

        # Per-request sampling using each request's sampling parameters
        logprobs = logits - mx.logsumexp(logits, axis=-1, keepdims=True)
        batch = self.active_batch
        if batch and len(batch.requests) == logprobs.shape[0]:
            tokens = []
            for i, req in enumerate(batch.requests):
                req_sampler = self._make_request_sampler(req)
                tokens.append(req_sampler(logprobs[i:i+1]))
            sampled = mx.concatenate(tokens, axis=0)
        else:
            sampled = self.sampler(logprobs)

        return sampled, list(logprobs)

    def _next(self) -> List[MLLMBatchResponse]:
        """
        Internal next() with true continuous batching.

        New requests can join the active batch mid-generation:
        1. Finish pending async GPU work
        2. Prefill new requests (with batch-aware caches)
        3. Convert existing batch cache if needed
        4. Extend active batch with new requests
        5. Continue decode step for the merged batch

        Returns:
            List of MLLMBatchResponse for this step
        """
        tic = time.perf_counter()

        prompt_processing = False
        batch = self.active_batch
        num_active = len(batch) if batch else 0
        num_to_add = self.completion_batch_size - num_active

        # Process new prompts — fresh batch or extend into active one
        if num_to_add > 0 and self.unprocessed_requests:
            requests = self.unprocessed_requests[:num_to_add]

            if num_active == 0:
                # No active batch — create fresh
                new_batch = self._process_prompts(requests)
                self.unprocessed_requests = self.unprocessed_requests[len(requests):]
                self.active_batch = new_batch
                prompt_processing = True
            else:
                # Active batch exists — prefill new requests and extend.
                # Must finish pending async work before extending cache arrays.
                mx.synchronize()
                self._stats.generation_time += time.perf_counter() - tic
                tic = time.perf_counter()

                # force_batch_cache=True: even single new request produces
                # batch-aware caches (BatchKVCache/BatchMambaCache) for extend().
                new_batch = self._process_prompts(requests, force_batch_cache=True)
                self.unprocessed_requests = self.unprocessed_requests[len(requests):]

                if new_batch is not None:
                    # Convert existing batch cache from raw KVCache to BatchKVCache
                    # if it was a single-request batch (Qwen3.5 offset optimization).
                    from mlx_lm.models.cache import BatchKVCache, KVCache
                    needs_convert = any(
                        _is_kv_like(c) and not isinstance(c, BatchKVCache)
                        for c in batch.cache
                    )
                    if needs_convert:
                        batch.cache = _ensure_batch_cache(batch.cache)

                    batch.extend(new_batch)
                    # Free peak memory from prefill before continuing decode
                    mx.clear_cache()
                    prompt_processing = True

        elif num_active == 0:
            # No active batch and no pending requests
            self.active_batch = None
            return []

        # Drain any per-request prefill errors (from M6 per-request isolation)
        prefill_errors = list(self._prefill_errors)
        self._prefill_errors.clear()

        # Generate next token for active batch
        batch = self.active_batch
        if batch is None:
            return prefill_errors

        y, logprobs = batch.y, batch.logprobs
        batch.y, batch.logprobs = self._step(y[:, None], batch.cache)

        y = y.tolist()
        toc = time.perf_counter()

        # Note: prompt_time is already counted in _process_prompts().
        # Only count the first decode step after prompt processing as generation time.
        if not prompt_processing:
            self._stats.generation_time += toc - tic

        # Build responses and track finished
        keep_idx = []
        end_idx = []
        responses = []

        for i, (token, uid, request_id, num_tok, max_tok, req) in enumerate(
            zip(
                y,
                batch.uids,
                batch.request_ids,
                batch.num_tokens,
                batch.max_tokens,
                batch.requests,
            )
        ):
            num_tok += 1
            batch.num_tokens[i] = num_tok
            req.num_tokens = num_tok
            req.output_tokens.append(token)

            finish_reason = None
            cache_fn = None

            if token in self.stop_tokens:
                finish_reason = "stop"
                end_idx.append(i)
            elif num_tok >= max_tok:
                finish_reason = "length"
                end_idx.append(i)
            else:
                keep_idx.append(i)

            if finish_reason is not None:
                # Extract cache NOW before batch.filter() invalidates indices.
                # Do NOT TQ-compress here — the scheduler needs original float16
                # for block extraction. TQ recompress happens on the fetch path.
                captured_cache = batch.extract_cache(i)
                cache_fn = lambda c=captured_cache: c

            responses.append(
                MLLMBatchResponse(
                    uid=uid,
                    request_id=request_id,
                    token=token,
                    logprobs=logprobs[i],
                    finish_reason=finish_reason,
                    prompt_cache=cache_fn,
                    prompt_token_ids=(
                        getattr(req, '_original_token_ids', None)
                        or (req.input_ids[0].tolist() if req.input_ids is not None and req.input_ids.ndim > 1
                            else req.input_ids.tolist() if req.input_ids is not None
                            else [])
                    ),
                    cached_tokens=getattr(req, '_cached_tokens', 0),
                    gen_prefix_tokens=getattr(req, '_gen_prefix_tokens', None),
                )
            )

        # Remove finished requests from batch
        if end_idx:
            if keep_idx:
                batch.filter(keep_idx)
            else:
                self.active_batch = None
                # All requests done — release Metal cache to reclaim GPU memory.
                # Without this, MLX holds freed buffers in its allocator free-list
                # indefinitely, causing apparent memory bloat after long prefills.
                try:
                    mx.clear_cache()
                except Exception:
                    pass

        self._stats.generation_tokens += len(responses)
        return prefill_errors + responses

    def next(self) -> List[MLLMBatchResponse]:
        """
        Generate next token for all requests in the batch.

        Returns:
            List of MLLMBatchResponse, one per active request
        """
        with mx.stream(MLLMBatchGenerator._stream):
            return self._next()

    def stats(self) -> MLLMBatchStats:
        """
        Get generation statistics.

        Returns:
            MLLMBatchStats with timing and token counts
        """
        self._stats.peak_memory = mx.get_peak_memory() / 1e9
        return self._stats

    def get_vision_cache_stats(self) -> Dict[str, Any]:
        """Get vision cache statistics."""
        return self.vision_cache.get_stats()

    def has_pending(self) -> bool:
        """Check if there are pending or active requests."""
        return bool(self.unprocessed_requests or self.active_batch)

    def _prefill_for_clean_ssm(self, tokens: List[int]) -> Optional[List[Any]]:
        """Run a clean prompt-only prefill to capture SSM state matching its key.

        Mirrors Scheduler._prefill_for_prompt_only_cache for the MLLM path.
        Returned cache covers exactly `tokens` worth of processing — no
        gen_prompt_len suffix, no generation output. Safe to store with
        is_complete=True.
        """
        if not tokens or self.language_model is None:
            return None
        try:
            fresh_cache = (
                self.language_model.make_cache()
                if hasattr(self.language_model, "make_cache")
                else None
            )
            if fresh_cache is None:
                from mlx_lm.models.cache import KVCache
                fresh_cache = [KVCache() for _ in range(len(self.language_model.layers))]
            chunk_size = 2048
            for start in range(0, len(tokens), chunk_size):
                chunk = tokens[start : start + chunk_size]
                input_ids = mx.array([chunk])
                _ = self.language_model(input_ids, cache=fresh_cache)
                materialize: List[Any] = []
                for c in fresh_cache:
                    if hasattr(c, "keys") and c.keys is not None:
                        if isinstance(c.keys, tuple):
                            materialize.extend(c.keys)
                            materialize.extend(c.values)
                        else:
                            materialize.extend([c.keys, c.values])
                    elif hasattr(c, "cache") and isinstance(c.cache, list):
                        for arr in c.cache:
                            if hasattr(arr, "shape"):
                                materialize.append(arr)
                if materialize:
                    mx.eval(*materialize)
            return fresh_cache
        except Exception as ex:
            logger.warning(f"MLLM clean SSM prefill failed: {ex}")
            return None

    def run_idle_rederive(self) -> bool:
        """Process one SSM rederive task from the queue (scheduler idle tick).

        Returns True if a task was processed, False if queue was empty.
        Caps at one task per tick so decode latency is unaffected.
        """
        if not self._ssm_rederive_queue or self._ssm_state_cache is None:
            return False
        if not self._hybrid_kv_positions:
            self._ssm_rederive_queue.clear()
            return False
        tokens, prompt_len, orig_rid = self._ssm_rederive_queue.pop(0)
        logger.info(
            f"MLLM SSM re-derive: clean prefill for {orig_rid} "
            f"({prompt_len} prompt tokens, {len(self._ssm_rederive_queue)} remaining)"
        )
        try:
            clean_cache = self._prefill_for_clean_ssm(list(tokens))
            if clean_cache is None:
                return True
            kv_set = set(self._hybrid_kv_positions or [])
            ssm_layers: List[Any] = []
            for layer_idx, c in enumerate(clean_cache):
                if layer_idx in kv_set:
                    continue
                if hasattr(c, "cache") and isinstance(c.cache, list):
                    from copy import deepcopy
                    cloned = deepcopy(c)
                    cloned.cache = [
                        mx.contiguous(mx.array(a)) if a is not None else None
                        for a in c.cache
                    ]
                    ssm_layers.append(cloned)
                else:
                    ssm_layers.append(c)
            if ssm_layers:
                self._ssm_state_cache.store(
                    tokens, prompt_len, ssm_layers, is_complete=True,
                )
                logger.info(
                    f"MLLM SSM re-derive: stored clean companion for {orig_rid}: "
                    f"{len(ssm_layers)} SSM layers, {prompt_len}-token key"
                )
            del clean_cache
            try:
                mx.clear_cache()
            except Exception:
                pass
        except Exception as ex:
            logger.warning(f"MLLM SSM re-derive failed for {orig_rid}: {ex}")
        return True
