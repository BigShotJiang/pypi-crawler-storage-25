"""Type stubs for ProllyTree Python bindings"""

from typing import Optional, Dict, List, Tuple, Union

class TreeConfig:
    """Configuration for ProllyTree"""

    def __init__(
        self,
        base: int = 4,
        modulus: int = 64,
        min_chunk_size: int = 1,
        max_chunk_size: int = 4096,
        pattern: int = 0
    ) -> None: ...

class ProllyTree:
    """A probabilistic tree for efficient storage and retrieval of ordered data"""

    def __init__(
        self,
        storage_type: str = "memory",
        path: Optional[str] = None,
        config: Optional[TreeConfig] = None
    ) -> None:
        """
        Create a new ProllyTree instance.

        Args:
            storage_type: Type of storage to use ("memory" or "file")
            path: Path for file storage (required if storage_type is "file")
            config: Tree configuration (uses defaults if not provided)
        """
        ...

    def insert(self, key: bytes, value: bytes) -> None:
        """Insert a key-value pair into the tree"""
        ...

    def insert_batch(self, items: List[Tuple[bytes, bytes]]) -> None:
        """Insert multiple key-value pairs in a single batch operation"""
        ...

    def find(self, key: bytes) -> Optional[bytes]:
        """Find and return the value associated with a key"""
        ...

    def update(self, key: bytes, value: bytes) -> None:
        """Update the value for an existing key"""
        ...

    def delete(self, key: bytes) -> None:
        """Delete a key from the tree"""
        ...

    def delete_batch(self, keys: List[bytes]) -> None:
        """Delete multiple keys in a single batch operation"""
        ...

    def size(self) -> int:
        """Return the number of key-value pairs in the tree"""
        ...

    def depth(self) -> int:
        """Return the depth of the tree"""
        ...

    def get_root_hash(self) -> bytes:
        """Get the root hash of the tree"""
        ...

    def stats(self) -> Dict[str, int]:
        """Get statistics about the tree structure"""
        ...

    def generate_proof(self, key: bytes) -> bytes:
        """Generate a Merkle proof for a key"""
        ...

    def verify_proof(
        self,
        proof: bytes,
        key: bytes,
        expected_value: Optional[bytes] = None
    ) -> bool:
        """Verify a Merkle proof for a key"""
        ...

    def diff(self, other: "ProllyTree") -> Dict[str, Union[Dict[bytes, bytes], Dict[bytes, Dict[str, bytes]]]]:
        """
        Compare two trees and return the differences from this tree to other.

        Note: Currently returns empty results due to implementation limitations.
        The diff operation works at the tree structure level, but probabilistic trees
        can have different structures for the same logical data.

        Returns a dictionary with:
        - "added": Dict of keys/values present in other but not in this tree
        - "removed": Dict of keys/values present in this tree but not in other
        - "modified": Dict of keys with different values (maps to {"old": value_in_self, "new": value_in_other})
        """
        ...

    def traverse(self) -> str:
        """Return a string representation of the tree structure"""
        ...

    def save_config(self) -> None:
        """Save the tree configuration to storage"""
        ...

class StorageBackend:
    """Enum representing different storage backend types for VersionedKvStore.

    Available backends:
        - Git: Full git versioning with branch/merge support (default)
        - File: File-based persistent storage in .git/prolly/nodes/files/
        - InMemory: Volatile in-memory storage (data lost on exit)
        - RocksDB: High-performance persistent storage (requires rocksdb_storage feature)
    """
    InMemory: "StorageBackend"
    File: "StorageBackend"
    Git: "StorageBackend"
    RocksDB: "StorageBackend"

    def __str__(self) -> str: ...

class MergeConflict:
    """Represents a merge conflict between branches"""

    @property
    def key(self) -> bytes:
        """The key that has a conflict"""
        ...

    @property
    def base_value(self) -> Optional[bytes]:
        """The value in the common base commit"""
        ...

    @property
    def source_value(self) -> Optional[bytes]:
        """The value in the source branch"""
        ...

    @property
    def destination_value(self) -> Optional[bytes]:
        """The value in the destination branch"""
        ...

class ConflictResolution:
    """Enum representing different conflict resolution strategies"""
    IgnoreAll: "ConflictResolution"
    TakeSource: "ConflictResolution"
    TakeDestination: "ConflictResolution"

class DiffOperation:
    """Represents a difference operation (Added, Removed, or Modified)"""

    @property
    def operation_type(self) -> str:
        """The type of operation: 'Added', 'Removed', or 'Modified'"""
        ...

    @property
    def value(self) -> Optional[bytes]:
        """For Added/Removed operations, the value involved"""
        ...

    @property
    def old_value(self) -> Optional[bytes]:
        """For Modified operations, the old value"""
        ...

    @property
    def new_value(self) -> Optional[bytes]:
        """For Modified operations, the new value"""
        ...

class KvDiff:
    """Represents a key-value difference between two references"""

    @property
    def key(self) -> bytes:
        """The key that changed"""
        ...

    @property
    def operation(self) -> DiffOperation:
        """The operation that occurred on this key"""
        ...

class VersionedKvStore:
    """A versioned key-value store backed by Git and ProllyTree.

    Supports multiple storage backends for different use cases:
    - Git (default): Full git versioning with branch/merge/diff support
    - File: Persistent file-based storage without full git features
    - InMemory: Fast volatile storage for testing
    - RocksDB: High-performance persistent storage
    """

    def __init__(
        self,
        path: str,
        storage_backend: Optional[StorageBackend] = None
    ) -> None:
        """
        Initialize a new versioned key-value store.

        Args:
            path: Directory path for the store (must be within a git repository)
            storage_backend: Storage backend to use. Options:
                - StorageBackend.Git (default): Full git versioning with branch/merge
                - StorageBackend.File: File-based storage in .git/prolly/nodes/files/
                - StorageBackend.InMemory: Volatile in-memory storage
                - StorageBackend.RocksDB: RocksDB storage (requires rocksdb_storage feature)

        Example:
            # Default Git backend
            store = VersionedKvStore("./data")

            # Explicit backend selection
            store = VersionedKvStore("./data", StorageBackend.File)
            store = VersionedKvStore("./data", StorageBackend.InMemory)
        """
        ...

    @staticmethod
    def open(
        path: str,
        storage_backend: Optional[StorageBackend] = None
    ) -> "VersionedKvStore":
        """
        Open an existing versioned key-value store.

        Args:
            path: Directory path where the store is located
            storage_backend: Storage backend to use (default: Git)
        """
        ...

    def insert(self, key: bytes, value: bytes) -> None:
        """
        Insert a key-value pair (stages the change).

        Args:
            key: The key as bytes
            value: The value as bytes
        """
        ...

    def get(self, key: bytes) -> Optional[bytes]:
        """
        Get a value by key.

        Args:
            key: The key to look up

        Returns:
            The value as bytes, or None if not found
        """
        ...

    def update(self, key: bytes, value: bytes) -> bool:
        """
        Update an existing key-value pair (stages the change).

        Args:
            key: The key to update
            value: The new value

        Returns:
            True if the key existed and was updated, False otherwise
        """
        ...

    def delete(self, key: bytes) -> bool:
        """
        Delete a key-value pair (stages the change).

        Args:
            key: The key to delete

        Returns:
            True if the key existed and was deleted, False otherwise
        """
        ...

    def list_keys(self) -> List[bytes]:
        """
        List all keys in the store (includes staged changes).

        Returns:
            List of keys as bytes
        """
        ...

    def status(self) -> List[Tuple[bytes, str]]:
        """
        Show current staging area status.

        Returns:
            List of tuples (key, status) where status is "added", "modified", or "deleted"
        """
        ...

    def commit(self, message: str) -> str:
        """
        Commit staged changes.

        Args:
            message: Commit message

        Returns:
            Commit hash as hex string
        """
        ...

    def branch(self, name: str) -> None:
        """
        Create a new branch.

        Args:
            name: Name of the new branch
        """
        ...

    def create_branch(self, name: str) -> None:
        """
        Create a new branch and switch to it.

        Args:
            name: Name of the new branch
        """
        ...

    def checkout(self, branch_or_commit: str) -> None:
        """
        Switch to a different branch or commit.

        Args:
            branch_or_commit: Branch name or commit hash
        """
        ...

    def current_branch(self) -> str:
        """
        Get the current branch name.

        Returns:
            Current branch name
        """
        ...

    def list_branches(self) -> List[str]:
        """
        List all branches in the repository.

        Returns:
            List of branch names
        """
        ...

    def log(self) -> List[Dict[str, Union[str, int]]]:
        """
        Get commit history.

        Returns:
            List of commit dictionaries with id, author, committer, message, and timestamp
        """
        ...

    def get_commits_for_key(self, key: bytes) -> List[Dict[str, Union[str, int]]]:
        """
        Get all commits that contain changes to a specific key.

        For InMemory backend, historical access only works within the same session
        since nodes are not persisted.

        Args:
            key: The key to search for

        Returns:
            List of commit dictionaries with id, author, committer, message, and timestamp
        """
        ...


    def get_commit_history(self) -> List[Dict[str, Union[str, int]]]:
        """
        Get the commit history for the repository.

        Returns:
            List of commit dictionaries with id, author, committer, message, and timestamp
        """
        ...

    def merge(
        self,
        source_branch: str,
        conflict_resolution: Optional[ConflictResolution] = None
    ) -> str:
        """
        Merge another branch into the current branch.

        Args:
            source_branch: Name of the branch to merge from
            conflict_resolution: Strategy for resolving conflicts (default: IgnoreAll)

        Returns:
            The commit ID of the merge commit

        Raises:
            ValueError: If merge fails or has unresolved conflicts
        """
        ...

    def try_merge(self, source_branch: str) -> Tuple[bool, List[MergeConflict]]:
        """
        Attempt to merge another branch and return any conflicts.

        Args:
            source_branch: Name of the branch to merge from

        Returns:
            Tuple of (success, conflicts) where:
            - success: True if merge succeeded, False if there were conflicts
            - conflicts: List of MergeConflict objects if success is False
        """
        ...

    def storage_backend(self) -> StorageBackend:
        """
        Get the current storage backend type.

        Returns:
            Storage backend enum value
        """
        ...

    def generate_proof(self, key: bytes) -> bytes:
        """
        Generate a cryptographic proof for a key's existence and value in the versioned store.

        Args:
            key: The key to generate proof for

        Returns:
            Serialized proof as bytes
        """
        ...

    def verify_proof(
        self,
        proof: bytes,
        key: bytes,
        expected_value: Optional[bytes] = None
    ) -> bool:
        """
        Verify a cryptographic proof for a key-value pair in the versioned store.

        Args:
            proof: The serialized proof to verify
            key: The key that the proof claims to prove
            expected_value: Optional expected value to verify against

        Returns:
            True if the proof is valid, False otherwise
        """
        ...

    def get_keys_at_ref(self, reference: str) -> List[Tuple[bytes, bytes]]:
        """
        Get all key-value pairs at a specific reference (commit, branch, or tag).

        This method provides historical access to the complete state of the store
        at any point in its history.

        The method reconstructs the historical state by:
        1. Reading the root hash from the committed config file
        2. Loading the tree from the content-addressed node storage
        3. Traversing the tree to collect all key-value pairs

        For InMemory backend, historical access only works within the same session
        since nodes are not persisted to disk.

        Args:
            reference: A git reference - can be a branch name (e.g., "main", "feature/xyz"),
                      commit hash (full or abbreviated), tag name, or relative reference
                      (e.g., "HEAD", "HEAD~1", "main^")

        Returns:
            List of (key, value) tuples representing all key-value pairs at that reference

        Raises:
            ValueError: If the reference cannot be resolved

        Example:
            # Get all keys at a specific commit
            pairs = store.get_keys_at_ref("abc123def")

            # Get all keys from the main branch
            pairs = store.get_keys_at_ref("main")

            # Get all keys from the previous commit
            pairs = store.get_keys_at_ref("HEAD~1")
        """
        ...

    def diff(self, from_ref: str, to_ref: str) -> List[KvDiff]:
        """
        Compare two commits or branches and return all keys that are added, updated or deleted.

        Args:
            from_ref: Reference (branch or commit) to compare from
            to_ref: Reference (branch or commit) to compare to

        Returns:
            List of KvDiff objects representing the differences between the two references

        Example:
            # Compare two commits
            diffs = store.diff("abc123", "def456")

            # Compare two branches
            diffs = store.diff("main", "feature-branch")

            # Check what changed from last commit
            diffs = store.diff("HEAD~1", "HEAD")
        """
        ...

    def current_commit(self) -> str:
        """
        Get the current commit's object ID.

        Returns:
            The hexadecimal string representation of the current commit ID

        Example:
            commit_id = store.current_commit()
            print(f"Current commit: {commit_id}")
        """
        ...
