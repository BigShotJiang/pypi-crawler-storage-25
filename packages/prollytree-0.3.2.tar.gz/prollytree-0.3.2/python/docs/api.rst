API Reference
=============

This page contains the complete API reference for ProllyTree Python bindings.

Core Classes
------------

.. automodule:: prollytree
   :members:
   :undoc-members:
   :show-inheritance:

ProllyTree
~~~~~~~~~~

.. autoclass:: prollytree.ProllyTree
   :members:
   :undoc-members:
   :show-inheritance:

TreeConfig
~~~~~~~~~~

.. autoclass:: prollytree.TreeConfig
   :members:
   :undoc-members:
   :show-inheritance:

Versioned Storage
-----------------

VersionedKvStore
~~~~~~~~~~~~~~~~

.. autoclass:: prollytree.VersionedKvStore
   :members:
   :undoc-members:
   :show-inheritance:

StorageBackend
~~~~~~~~~~~~~~

.. autoclass:: prollytree.StorageBackend
   :members:
   :undoc-members:
   :show-inheritance:

Merge Operations
----------------

MergeConflict
~~~~~~~~~~~~~

.. autoclass:: prollytree.MergeConflict
   :members:
   :undoc-members:
   :show-inheritance:

ConflictResolution
~~~~~~~~~~~~~~~~~~

.. autoclass:: prollytree.ConflictResolution
   :members:
   :undoc-members:
   :show-inheritance:

SQL Support
-----------

ProllySQLStore
~~~~~~~~~~~~~~

.. autoclass:: prollytree.ProllySQLStore
   :members:
   :undoc-members:
   :show-inheritance:
