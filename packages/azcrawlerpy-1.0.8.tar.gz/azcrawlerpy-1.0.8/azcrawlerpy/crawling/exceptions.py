"""
Custom exceptions for the crawler framework.

All exceptions include context about the step and selector where the error occurred
to enable effective debugging. Supports AI agent diagnostics when debug mode enabled.

CrawlRestartError is a control flow signal (not a CrawlerError subclass) used to
trigger a full browser restart when a step's wait_for condition fails. It is caught
by the crawl() retry loop, not by the general error handler.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Self

if TYPE_CHECKING:
    from .diagnostics import PageDiagnostics
    from .models import CrawlResult


class CrawlRestartError(Exception):
    """
    Control flow signal raised when a step with restart_crawl=True has its wait_for timeout.

    Not a CrawlerError subclass - this is intentional. The crawl() retry loop catches
    CrawlRestartError separately from CrawlerError/Exception. On catch, it:
        1. Increments the per-step restart attempt counter
        2. Checks against the step's max_restarts budget
        3. If budget remains: closes the browser (via context manager exit), loops back
           to create a fresh browser, re-navigates to the start URL, and replays all steps
        4. If budget exhausted: raises CrawlerTimeoutError with the original selector/timeout

    Attributes:
        step_name: Name of the step that triggered the restart.
        selector: The wait_for CSS selector that timed out.
        timeout_ms: The timeout value in milliseconds that was exceeded.

    """

    def __init__(self, step_name: str, selector: str, timeout_ms: int) -> None:
        self.step_name = step_name
        self.selector = selector
        self.timeout_ms = timeout_ms
        message = (
            f"Crawl restart requested: wait_for timeout on step='{step_name}' "
            f"selector='{selector}' after {timeout_ms}ms"
        )
        super().__init__(message)


class CrawlerError(Exception):
    """
    Base exception for all crawler framework errors.

    Preserves partial crawl results (including screenshots) when crawl fails,
    allowing callers to access captured data even on failure.
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self.diagnostics: PageDiagnostics | None = None
        self.partial_result: CrawlResult | None = None
        self.original_error: Exception | None = None

    def with_diagnostics(self, diagnostics: PageDiagnostics) -> Self:
        """Attach diagnostics and return self for chaining."""
        self.diagnostics = diagnostics
        return self

    def with_partial_result(self, partial_result: CrawlResult) -> Self:
        """Attach partial crawl result and return self for chaining."""
        self.partial_result = partial_result
        return self

    def with_original_error(self, original_error: Exception) -> Self:
        """Attach original error and return self for chaining."""
        self.original_error = original_error
        return self

    def to_dict(self) -> dict[str, Any]:
        """Serialize exception for JSON output."""
        result: dict[str, Any] = {
            "error_type": self.__class__.__name__,
            "message": str(self),
            "diagnostics": self.diagnostics.to_dict() if self.diagnostics else None,
        }
        if self.partial_result:
            result["partial_result"] = {
                "url": self.partial_result.url,
                "final_url": self.partial_result.final_url,
                "steps_completed": self.partial_result.steps_completed,
                "screenshot_count": len(self.partial_result.screenshots),
                "extracted_data": self.partial_result.extracted_data,
            }
        if self.original_error:
            result["original_error"] = {
                "type": type(self.original_error).__name__,
                "message": str(self.original_error),
            }
        return result

    def __str__(self) -> str:
        """Return message with diagnostics if available."""
        base_message = super().__str__()
        if self.diagnostics:
            return base_message + self.diagnostics.format_for_exception()
        return base_message


class FieldNotFoundError(CrawlerError):
    """Raised when a form field cannot be located on the page."""

    def __init__(self, selector: str, step_name: str, field_type: str) -> None:
        self.selector = selector
        self.step_name = step_name
        self.field_type = field_type
        message = f"Field not found: selector='{selector}' type='{field_type}' in step='{step_name}'"
        super().__init__(message)


class NavigationError(CrawlerError):
    """Raised when navigation between form steps fails."""

    def __init__(self, step_name: str, action_type: str, selector: str, reason: str) -> None:
        self.step_name = step_name
        self.action_type = action_type
        self.selector = selector
        self.reason = reason
        message = f"Navigation failed: action='{action_type}' selector='{selector}' in step='{step_name}': {reason}"
        super().__init__(message)


class CrawlerTimeoutError(CrawlerError):
    """Raised when waiting for an element or condition times out."""

    def __init__(self, selector: str, step_name: str, timeout_ms: int) -> None:
        self.selector = selector
        self.step_name = step_name
        self.timeout_ms = timeout_ms
        message = f"Timeout waiting for selector='{selector}' in step='{step_name}' after {timeout_ms}ms"
        super().__init__(message)


class InvalidInstructionError(CrawlerError):
    """Raised when the instruction JSON is invalid or malformed."""

    def __init__(self, reason: str) -> None:
        self.reason = reason
        message = f"Invalid instruction: {reason}"
        super().__init__(message)


class MissingDataError(CrawlerError):
    """Raised when required input data is missing for a field."""

    def __init__(self, data_key: str, step_name: str) -> None:
        self.data_key = data_key
        self.step_name = step_name
        message = f"Missing required data: key='{data_key}' in step='{step_name}'"
        super().__init__(message)


class FieldInteractionError(CrawlerError):
    """Raised when interaction with a field fails."""

    def __init__(self, selector: str, step_name: str, field_type: str, reason: str) -> None:
        self.selector = selector
        self.step_name = step_name
        self.field_type = field_type
        self.reason = reason
        message = f"Field interaction failed: selector='{selector}' type='{field_type}' in step='{step_name}': {reason}"
        super().__init__(message)


class IframeNotFoundError(CrawlerError):
    """Raised when an iframe cannot be located."""

    def __init__(self, iframe_selector: str, step_name: str) -> None:
        self.iframe_selector = iframe_selector
        self.step_name = step_name
        message = f"Iframe not found: selector='{iframe_selector}' in step='{step_name}'"
        super().__init__(message)


class UnsupportedFieldTypeError(CrawlerError):
    """Raised when an unsupported field type is encountered."""

    def __init__(self, field_type: str, step_name: str) -> None:
        self.field_type = field_type
        self.step_name = step_name
        message = f"Unsupported field type: '{field_type}' in step='{step_name}'"
        super().__init__(message)


class UnsupportedActionTypeError(CrawlerError):
    """Raised when an unsupported action type is encountered."""

    def __init__(self, action_type: str, step_name: str) -> None:
        self.action_type = action_type
        self.step_name = step_name
        message = f"Unsupported action type: '{action_type}' in step='{step_name}'"
        super().__init__(message)


class DataExtractionError(CrawlerError):
    """Raised when data extraction from the final page fails."""

    def __init__(self, field_name: str, selector: str, reason: str) -> None:
        self.field_name = field_name
        self.selector = selector
        self.reason = reason
        message = f"Data extraction failed: field='{field_name}' selector='{selector}': {reason}"
        super().__init__(message)
