"""
Utility functions for the crawler framework.

Date formatting, selector utilities, and other helper functions.
"""

import contextlib
import logging
from datetime import datetime
from typing import IO, Any, Protocol, runtime_checkable

from .config import CSS_ATTRIBUTE_VALUE_ESCAPE_CHARS, CSS_SELECTOR_ESCAPE_CHARS
from .exceptions import InvalidInstructionError


@runtime_checkable
class LoggerLike(Protocol):
    """
    Structural type accepted by the crawler for logging.

    Matches stdlib ``logging.Logger`` and azpaddypy ``AzureLogger`` so either
    can be injected without importing azpaddypy as a hard dependency.
    """

    def debug(self, msg: object, /, *args: Any, **kwargs: Any) -> None: ...
    def info(self, msg: object, /, *args: Any, **kwargs: Any) -> None: ...
    def warning(self, msg: object, /, *args: Any, **kwargs: Any) -> None: ...
    def error(self, msg: object, /, *args: Any, **kwargs: Any) -> None: ...
    def exception(self, msg: object, /, *args: Any, **kwargs: Any) -> None: ...
    def critical(self, msg: object, /, *args: Any, **kwargs: Any) -> None: ...


_LOG_FORMATTER = logging.Formatter(
    "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)


def setup_logger(name: str) -> logging.Logger:
    """Create a structured logger for the crawler framework."""
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(_LOG_FORMATTER)
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
    return logger


def flush_logger(logger: LoggerLike) -> None:
    """
    Best-effort flush of every handler reachable from ``logger``, its parents
    and the root logger. Called on timeout / teardown paths so buffered log
    records reach their sinks before the process is torn down (e.g. by a
    container runtime SIGKILL-ing after a function-app timeout).

    Silently swallows per-handler errors: a failing flush must never mask the
    original exception that triggered the teardown.
    """
    targets: list[logging.Logger] = [logging.getLogger()]
    if isinstance(logger, logging.Logger):
        cur: logging.Logger | None = logger
        while cur is not None:
            targets.append(cur)
            cur = cur.parent
    seen: set[int] = set()
    for lg in targets:
        for handler in list(lg.handlers):
            if id(handler) in seen:
                continue
            seen.add(id(handler))
            with contextlib.suppress(Exception):
                handler.flush()


def attach_stream_handler(logger: LoggerLike, stream: IO[str]) -> logging.StreamHandler:
    """
    Attach a ``StreamHandler`` writing to ``stream`` to both ``logger`` (when
    it's a stdlib ``Logger``) and the root logger, so third-party libraries
    that log via their own named loggers are captured too. The ``stream`` can
    be any file-like (an open file, an ``io.StringIO`` buffer, ...).
    """
    handler = logging.StreamHandler(stream)
    handler.setFormatter(_LOG_FORMATTER)
    if isinstance(logger, logging.Logger):
        logger.addHandler(handler)
    logging.getLogger().addHandler(handler)
    return handler


def detach_stream_handler(logger: LoggerLike, handler: logging.StreamHandler | None) -> None:
    """Remove, flush and close a handler added by ``attach_stream_handler``."""
    if handler is None:
        return
    if isinstance(logger, logging.Logger):
        logger.removeHandler(handler)
    logging.getLogger().removeHandler(handler)
    with contextlib.suppress(Exception):
        handler.flush()
        handler.close()


class TeeStream:
    """
    File-like wrapper that mirrors every write to a second stream.

    Used to tee ``sys.stdout`` / ``sys.stderr`` into an on-disk log so
    ``print()`` calls from the framework or user code survive an abrupt
    process teardown. Attribute access falls through to the primary stream
    so downstream code that pokes at ``fileno``, ``isatty``, ``encoding``
    etc. keeps working.
    """

    def __init__(self, primary: IO[str], mirror: IO[str]) -> None:
        self._primary = primary
        self._mirror = mirror

    def write(self, data: str) -> int:
        written = 0
        with contextlib.suppress(Exception):
            written = self._primary.write(data)
        with contextlib.suppress(Exception):
            self._mirror.write(data)
        return written if isinstance(written, int) else len(data)

    def flush(self) -> None:
        for stream in (self._primary, self._mirror):
            with contextlib.suppress(Exception):
                stream.flush()

    def __getattr__(self, name: str) -> Any:
        return getattr(self._primary, name)


def format_date(value: str, target_format: str) -> str:
    """
    Convert a date string to the target format.

    Input format is expected to be ISO 8601 (YYYY-MM-DD).
    Target format uses strftime directives mapped from common patterns.

    Args:
        value: Date string in ISO 8601 format (YYYY-MM-DD)
        target_format: Target format pattern (e.g., "DD.MM.YYYY", "MM/DD/YYYY")

    Returns:
        Formatted date string

    """
    # Using naive datetime intentionally - we're only converting date formats, not handling timezones
    input_date = datetime.strptime(value, "%Y-%m-%d")  # noqa: DTZ007

    format_mapping: dict[str, str] = {
        "DD.MM.YYYY": "%d.%m.%Y",
        "MM/DD/YYYY": "%m/%d/%Y",
        "YYYY-MM-DD": "%Y-%m-%d",
        "DD/MM/YYYY": "%d/%m/%Y",
        "YYYY/MM/DD": "%Y/%m/%d",
        "DD-MM-YYYY": "%d-%m-%Y",
        "MM-DD-YYYY": "%m-%d-%Y",
    }

    strftime_format = format_mapping.get(target_format)
    if strftime_format is None:
        msg = f"Unsupported date format: {target_format}"
        raise InvalidInstructionError(msg)

    return input_date.strftime(strftime_format)


def normalize_selector(selector: str) -> str:
    """
    Normalize a CSS selector for consistent usage.

    Strips whitespace and validates basic selector syntax.

    Args:
        selector: CSS selector string

    Returns:
        Normalized selector string

    """
    normalized = selector.strip()
    if not normalized:
        msg = "Empty selector provided"
        raise InvalidInstructionError(msg)
    return normalized


def escape_css_id(element_id: str) -> str:
    """
    Escape special characters in CSS ID selectors.

    Characters like :, [], (), etc. need backslash escaping.

    Args:
        element_id: Raw element ID

    Returns:
        Escaped ID safe for use in CSS selectors

    """
    return "".join("\\" + char if char in CSS_SELECTOR_ESCAPE_CHARS else char for char in element_id)


def escape_css_attribute_value(value: str) -> str:
    """
    Escape special characters in CSS attribute selector values.

    Handles quotes, backslashes, and bracket characters that could break
    attribute selectors like [data-cy='value'].

    Args:
        value: Raw value to use in attribute selector

    Returns:
        Escaped value safe for use in CSS attribute selectors

    """
    return "".join("\\" + char if char in CSS_ATTRIBUTE_VALUE_ESCAPE_CHARS else char for char in value)


def interpolate_selector_value(selector: str, value: str) -> str:
    """
    Safely interpolate a value into a selector placeholder.

    Replaces ${value} placeholder with an escaped version of the value.

    Args:
        selector: Selector template containing ${value} placeholder
        value: Value to interpolate

    Returns:
        Selector with value safely interpolated

    """
    escaped_value = escape_css_attribute_value(str(value))
    return selector.replace("${value}", escaped_value)
