"""
Field type handlers for form interactions.

Each handler class is responsible for a specific field type (text, dropdown, etc.).
Uses composition pattern with a dispatch dictionary for field type routing.
All handlers support optional retry via field.retry_config and use click_with_fallback
for click interactions (escalating: normal -> force -> JS dispatch -> JS direct).
Text/textarea handlers verify filled values against expected values after interaction.
"""

from abc import ABC, abstractmethod
from collections.abc import Awaitable, Callable
from typing import Any

from playwright.async_api import (
    Error as PlaywrightError,
)
from playwright.async_api import (
    FrameLocator,
    Locator,
    Page,
)
from playwright.async_api import (
    TimeoutError as PlaywrightTimeoutError,
)

from .config import (
    COMBOBOX_POST_CLEAR_DELAY_MIN_MS,
    COMBOBOX_POST_ENTER_DELAY_MIN_MS,
    COMBOBOX_PRE_TYPE_DELAY_MIN_MS,
    FIELD_OPTION_VISIBLE_TIMEOUT_MIN_MS,
    FIELD_POST_CLICK_DELAY_MIN_MS,
    FIELD_TYPE_DELAY_MIN_MS,
    FIELD_VISIBLE_TIMEOUT_MIN_MS,
    FIELD_WAIT_AFTER_CLICK_MIN_MS,
    FIELD_WAIT_AFTER_TYPE_MIN_MS,
    WaitConfig,
    WaitExecutor,
    click_with_fallback,
    retry_async,
)
from .exceptions import (
    FieldInteractionError,
    FieldNotFoundError,
    IframeNotFoundError,
    UnsupportedFieldTypeError,
)
from .models import (
    ClickSelectFieldConfig,
    ComboboxFieldConfig,
    DateFieldConfig,
    DropdownFieldConfig,
    FieldDefinition,
    FieldType,
)
from .utils import format_date, interpolate_selector_value, setup_logger

logger = setup_logger(__name__)


class BaseFieldHandler(ABC):
    """
    Abstract base class for field handlers.

    Provides common methods for locating fields, ensuring visibility,
    retrieving values from input data, and executing interactions with
    optional retry (via _execute_with_retry). Subclasses implement specific
    interaction logic for each field type.
    """

    @abstractmethod
    async def handle(
        self,
        page: Page,
        field: FieldDefinition,
        input_data: dict[str, Any],
        step_name: str,
    ) -> None:
        """
        Handle the field interaction.

        Args:
            page: Playwright page instance
            field: Field definition from instructions
            input_data: Dictionary of field values
            step_name: Current step name for error context

        """

    def _get_locator(
        self,
        page: Page,
        field: FieldDefinition,
        step_name: str,
    ) -> Locator:
        """
        Get the locator for a field, handling iframes if necessary.

        Args:
            page: Playwright page instance
            field: Field definition with selector and optional iframe_selector
            step_name: Current step name for error context

        Returns:
            Playwright Locator for the field element

        """
        if field.iframe_selector:
            try:
                frame_loc: FrameLocator = page.frame_locator(field.iframe_selector)
                locator = frame_loc.locator(field.selector)
            except (PlaywrightTimeoutError, PlaywrightError) as e:
                raise IframeNotFoundError(
                    iframe_selector=field.iframe_selector,
                    step_name=step_name,
                ) from e
        else:
            locator = page.locator(field.selector)

        return locator

    async def _ensure_visible(
        self,
        page: Page,
        locator: Locator,
        field: FieldDefinition,
        step_name: str,
    ) -> bool:
        """
        Ensure the field is visible before interaction.

        Args:
            page: Playwright page instance
            locator: Playwright Locator for the field
            field: Field definition with optional visibility timeout
            step_name: Current step name for error context

        Returns:
            True if the field is visible, False if the field is optional and not found

        Raises:
            FieldNotFoundError: If field does not become visible within timeout and is not optional

        """
        waiter = WaitExecutor(page=page)
        field_visible_timeout = WaitConfig.create(field.field_visible_timeout_ms, default=FIELD_VISIBLE_TIMEOUT_MIN_MS)
        try:
            await waiter.wait_visible(locator=locator, config=field_visible_timeout)
            return True
        except (PlaywrightTimeoutError, PlaywrightError) as e:
            if field.optional:
                logger.info(
                    f"Optional field not found, skipping: selector='{field.selector}' type='{field.type.value}' step='{step_name}'"
                )
                return False
            raise FieldNotFoundError(
                selector=field.selector,
                step_name=step_name,
                field_type=field.type.value,
            ) from e

    async def _execute_with_retry(
        self,
        operation: Callable[[], Awaitable[None]],
        field: FieldDefinition,
        step_name: str,
    ) -> None:
        """
        Execute a field interaction with optional retry on Playwright errors.

        Wraps the operation in retry_async when field.retry_config is set.
        Handles optional field skipping on failure.

        """
        try:
            if field.retry_config:
                await retry_async(
                    operation=operation,
                    config=field.retry_config,
                    retryable_exceptions=(PlaywrightTimeoutError, PlaywrightError),
                    context=f"field type='{field.type.value}' selector='{field.selector}' step='{step_name}'",
                )
            else:
                await operation()
        except (PlaywrightTimeoutError, PlaywrightError) as e:
            if field.optional:
                logger.info(
                    f"Optional field interaction failed, skipping: selector='{field.selector}' step='{step_name}': {e}"
                )
                return
            raise FieldInteractionError(
                selector=field.selector,
                step_name=step_name,
                field_type=field.type.value,
                reason=str(e),
            ) from e

    def _get_value(
        self,
        field: FieldDefinition,
        input_data: dict[str, Any],
        step_name: str,
    ) -> Any | None:
        """
        Get the value for a field from input data.

        Args:
            field: Field definition with data_key
            input_data: Dictionary of field values
            step_name: Current step name (unused, kept for signature consistency)

        Returns:
            Field value from input_data, or None if field should be skipped

        """
        if field.data_key is None:
            return None
        return input_data.get(field.data_key)


class TextFieldHandler(BaseFieldHandler):
    """Handler for standard text input fields (text, email, password, etc.)."""

    async def handle(
        self,
        page: Page,
        field: FieldDefinition,
        input_data: dict[str, Any],
        step_name: str,
    ) -> None:
        value = self._get_value(field=field, input_data=input_data, step_name=step_name)
        if value is None:
            logger.info(f"Skipping text field: data_key='{field.data_key}' step='{step_name}'")
            return

        locator = self._get_locator(page=page, field=field, step_name=step_name)
        if not await self._ensure_visible(page=page, locator=locator, field=field, step_name=step_name):
            return

        async def _do_fill() -> None:
            await locator.focus()
            await locator.fill(str(value))

            if field.skip_verification:
                logger.info(
                    f"Filled text field (verification skipped): selector='{field.selector}' value='{value}' step='{step_name}'"
                )
            else:
                actual_value = await locator.input_value()
                if str(value) != actual_value:
                    raise FieldInteractionError(
                        selector=field.selector,
                        step_name=step_name,
                        field_type=field.type.value,
                        reason=f"Value mismatch after fill: expected='{value}' actual='{actual_value}'",
                    )
                logger.info(
                    f"Filled text field: selector='{field.selector}' value='{value}' actual='{actual_value}' step='{step_name}'"
                )

        await self._execute_with_retry(operation=_do_fill, field=field, step_name=step_name)


class TextareaFieldHandler(BaseFieldHandler):
    """Handler for multi-line text areas."""

    async def handle(
        self,
        page: Page,
        field: FieldDefinition,
        input_data: dict[str, Any],
        step_name: str,
    ) -> None:
        value = self._get_value(field=field, input_data=input_data, step_name=step_name)
        if value is None:
            logger.info(f"Skipping textarea field: data_key='{field.data_key}' step='{step_name}'")
            return

        locator = self._get_locator(page=page, field=field, step_name=step_name)
        if not await self._ensure_visible(page=page, locator=locator, field=field, step_name=step_name):
            return

        async def _do_fill() -> None:
            await locator.fill(str(value))

            if not field.skip_verification:
                actual_value = await locator.input_value()
                if str(value) != actual_value:
                    raise FieldInteractionError(
                        selector=field.selector,
                        step_name=step_name,
                        field_type=field.type.value,
                        reason=f"Value mismatch after fill: expected='{value}' actual='{actual_value}'",
                    )

            logger.info(f"Filled textarea: selector='{field.selector}' step='{step_name}'")

        await self._execute_with_retry(operation=_do_fill, field=field, step_name=step_name)


class DropdownFieldHandler(BaseFieldHandler):
    """Handler for native HTML select elements with option selection."""

    async def handle(
        self,
        page: Page,
        field: FieldDefinition,
        input_data: dict[str, Any],
        step_name: str,
    ) -> None:
        value = self._get_value(field=field, input_data=input_data, step_name=step_name)
        if value is None:
            logger.info(f"Skipping dropdown field: data_key='{field.data_key}' step='{step_name}'")
            return

        locator = self._get_locator(page=page, field=field, step_name=step_name)
        if not await self._ensure_visible(page=page, locator=locator, field=field, step_name=step_name):
            return

        if not isinstance(field.type_config, DropdownFieldConfig):
            raise FieldInteractionError(
                selector=field.selector,
                step_name=step_name,
                field_type=field.type.value,
                reason="Dropdown field requires type_config of type DropdownFieldConfig",
            )

        async def _do_select() -> None:
            select_by = field.type_config.select_by  # type: ignore[union-attr]

            if select_by == "value":
                await locator.select_option(value=str(value))
            elif select_by == "index":
                await locator.select_option(index=int(value))
            else:
                await locator.select_option(label=str(value))

            logger.info(f"Selected dropdown option: selector='{field.selector}' value='{value}' step='{step_name}'")

        await self._execute_with_retry(operation=_do_select, field=field, step_name=step_name)


class RadioFieldHandler(BaseFieldHandler):
    """Handler for radio button selection with value interpolation and optional force click."""

    async def handle(
        self,
        page: Page,
        field: FieldDefinition,
        input_data: dict[str, Any],
        step_name: str,
    ) -> None:
        value = self._get_value(field=field, input_data=input_data, step_name=step_name)
        if value is None:
            logger.info(f"Skipping radio field: data_key='{field.data_key}' step='{step_name}'")
            return

        selector = field.selector
        has_value_placeholder = "${value}" in selector

        if has_value_placeholder:
            selector = interpolate_selector_value(selector=selector, value=str(value))

        if field.iframe_selector:
            frame_loc = page.frame_locator(field.iframe_selector)
            locator = frame_loc.locator(selector)
        else:
            locator = page.locator(selector)

        if not await self._ensure_visible(page=page, locator=locator, field=field, step_name=step_name):
            return

        waiter = WaitExecutor(page=page)

        async def _do_radio() -> None:
            if field.force_click:
                await click_with_fallback(
                    page=page,
                    locator=locator,
                    selector=selector,
                    context=f"radio selector='{selector}' step='{step_name}'",
                    force_first=True,
                )
                logger.info(
                    f"Selected radio option (fallback chain): selector='{selector}' value='{value}' step='{step_name}'"
                )
            else:
                await locator.check()
                logger.info(f"Selected radio option: selector='{selector}' value='{value}' step='{step_name}'")

            if field.post_click_delay_ms is not None:
                post_click_delay = WaitConfig(min_ms=field.post_click_delay_ms, randomize=True)
                await waiter.delay(config=post_click_delay)

        await self._execute_with_retry(operation=_do_radio, field=field, step_name=step_name)


class CheckboxFieldHandler(BaseFieldHandler):
    """Handler for checkbox fields with check/uncheck based on boolean value."""

    async def handle(
        self,
        page: Page,
        field: FieldDefinition,
        input_data: dict[str, Any],
        step_name: str,
    ) -> None:
        value = self._get_value(field=field, input_data=input_data, step_name=step_name)
        if value is None:
            logger.info(f"Skipping checkbox field: data_key='{field.data_key}' step='{step_name}'")
            return

        locator = self._get_locator(page=page, field=field, step_name=step_name)
        if not await self._ensure_visible(page=page, locator=locator, field=field, step_name=step_name):
            return

        async def _do_checkbox() -> None:
            should_check = bool(value)
            if should_check:
                await locator.check()
            else:
                await locator.uncheck()
            logger.info(f"Set checkbox: selector='{field.selector}' checked={should_check} step='{step_name}'")

        await self._execute_with_retry(operation=_do_checkbox, field=field, step_name=step_name)


class DateFieldHandler(BaseFieldHandler):
    """Handler for date input fields with format conversion."""

    async def handle(
        self,
        page: Page,
        field: FieldDefinition,
        input_data: dict[str, Any],
        step_name: str,
    ) -> None:
        value = self._get_value(field=field, input_data=input_data, step_name=step_name)
        if value is None:
            logger.info(f"Skipping date field: data_key='{field.data_key}' step='{step_name}'")
            return

        locator = self._get_locator(page=page, field=field, step_name=step_name)
        if not await self._ensure_visible(page=page, locator=locator, field=field, step_name=step_name):
            return

        async def _do_date() -> None:
            input_type = await locator.get_attribute("type")
            is_native_date_input = input_type == "date"

            if is_native_date_input:
                fill_value = str(value)
                logger.info(f"Native date input detected, using ISO format: {fill_value}")
            elif isinstance(field.type_config, DateFieldConfig):
                fill_value = format_date(value=str(value), target_format=field.type_config.format)
            else:
                fill_value = str(value)

            await locator.fill(fill_value)
            logger.info(f"Filled date field: selector='{field.selector}' value='{fill_value}' step='{step_name}'")

        await self._execute_with_retry(operation=_do_date, field=field, step_name=step_name)


class SliderFieldHandler(BaseFieldHandler):
    """Handler for range slider fields."""

    async def handle(
        self,
        page: Page,
        field: FieldDefinition,
        input_data: dict[str, Any],
        step_name: str,
    ) -> None:
        value = self._get_value(field=field, input_data=input_data, step_name=step_name)
        if value is None:
            logger.info(f"Skipping slider field: data_key='{field.data_key}' step='{step_name}'")
            return

        locator = self._get_locator(page=page, field=field, step_name=step_name)
        if not await self._ensure_visible(page=page, locator=locator, field=field, step_name=step_name):
            return

        async def _do_slider() -> None:
            await locator.fill(str(value))
            logger.info(f"Set slider value: selector='{field.selector}' value='{value}' step='{step_name}'")

        await self._execute_with_retry(operation=_do_slider, field=field, step_name=step_name)


class FileFieldHandler(BaseFieldHandler):
    """Handler for file upload fields using file path from input data."""

    async def handle(
        self,
        page: Page,
        field: FieldDefinition,
        input_data: dict[str, Any],
        step_name: str,
    ) -> None:
        value = self._get_value(field=field, input_data=input_data, step_name=step_name)
        if value is None:
            logger.info(f"Skipping file field: data_key='{field.data_key}' step='{step_name}'")
            return

        locator = self._get_locator(page=page, field=field, step_name=step_name)
        if not await self._ensure_visible(page=page, locator=locator, field=field, step_name=step_name):
            return

        async def _do_file() -> None:
            file_path = str(value)
            await locator.set_input_files(file_path)
            logger.info(f"Uploaded file: selector='{field.selector}' path='{file_path}' step='{step_name}'")

        await self._execute_with_retry(operation=_do_file, field=field, step_name=step_name)


class IframeFieldHandler(BaseFieldHandler):
    """Handler for text fields inside iframes requiring iframe_selector."""

    async def handle(
        self,
        page: Page,
        field: FieldDefinition,
        input_data: dict[str, Any],
        step_name: str,
    ) -> None:
        value = self._get_value(field=field, input_data=input_data, step_name=step_name)
        if value is None:
            logger.info(f"Skipping iframe field: data_key='{field.data_key}' step='{step_name}'")
            return

        if not field.iframe_selector:
            raise FieldInteractionError(
                selector=field.selector,
                step_name=step_name,
                field_type=field.type.value,
                reason="iframe_field type requires iframe_selector to be specified",
            )

        locator = self._get_locator(page=page, field=field, step_name=step_name)
        if not await self._ensure_visible(page=page, locator=locator, field=field, step_name=step_name):
            return

        async def _do_iframe_fill() -> None:
            await locator.fill(str(value))
            logger.info(
                f"Filled iframe field: iframe='{field.iframe_selector}' selector='{field.selector}' step='{step_name}'"
            )

        await self._execute_with_retry(operation=_do_iframe_fill, field=field, step_name=step_name)


class ClickOnlyFieldHandler(BaseFieldHandler):
    """Handler for click-only elements with optional value-driven selector interpolation."""

    async def handle(
        self,
        page: Page,
        field: FieldDefinition,
        input_data: dict[str, Any],
        step_name: str,
    ) -> None:
        value = self._get_value(field=field, input_data=input_data, step_name=step_name)
        selector = field.selector
        has_value_placeholder = "${value}" in selector

        if field.data_key is not None and value is None:
            logger.info(f"Skipping click_only field: data_key='{field.data_key}' step='{step_name}'")
            return

        if has_value_placeholder:
            if value is None:
                raise FieldInteractionError(
                    selector=selector,
                    step_name=step_name,
                    field_type=field.type.value,
                    reason="Selector contains ${value} placeholder but no data_key specified or value is null",
                )
            selector = interpolate_selector_value(selector=selector, value=str(value))

        if field.iframe_selector:
            frame_loc = page.frame_locator(field.iframe_selector)
            locator = frame_loc.locator(selector)
        else:
            locator = page.locator(selector)

        if not await self._ensure_visible(page=page, locator=locator, field=field, step_name=step_name):
            return

        waiter = WaitExecutor(page=page)
        post_click_delay = WaitConfig.create(field.post_click_delay_ms, default=FIELD_POST_CLICK_DELAY_MIN_MS)

        async def _do_click_only() -> None:
            await click_with_fallback(
                page=page,
                locator=locator,
                selector=selector,
                context=f"click_only selector='{selector}' step='{step_name}'",
                force_first=bool(field.force_click),
            )
            logger.info(f"Clicked element: selector='{selector}' step='{step_name}'")
            await waiter.delay(config=post_click_delay)

        await self._execute_with_retry(operation=_do_click_only, field=field, step_name=step_name)


class ComboboxFieldHandler(BaseFieldHandler):
    """Handler for combobox/autocomplete fields using type-wait-select pattern."""

    async def handle(
        self,
        page: Page,
        field: FieldDefinition,
        input_data: dict[str, Any],
        step_name: str,
    ) -> None:
        value = self._get_value(field=field, input_data=input_data, step_name=step_name)
        if value is None:
            logger.info(f"Skipping combobox field: data_key='{field.data_key}' step='{step_name}'")
            return

        locator = self._get_locator(page=page, field=field, step_name=step_name)
        if not await self._ensure_visible(page=page, locator=locator, field=field, step_name=step_name):
            return

        if not isinstance(field.type_config, ComboboxFieldConfig):
            raise FieldInteractionError(
                selector=field.selector,
                step_name=step_name,
                field_type=field.type.value,
                reason="Combobox field requires type_config of type ComboboxFieldConfig",
            )

        config = field.type_config
        waiter = WaitExecutor(page=page)
        base_type_delay = WaitConfig.create(config.type_delay_ms, default=FIELD_TYPE_DELAY_MIN_MS)
        wait_after_type = WaitConfig.create(config.wait_after_type_ms, default=FIELD_WAIT_AFTER_TYPE_MIN_MS)
        pre_type_delay = WaitConfig.create(default=COMBOBOX_PRE_TYPE_DELAY_MIN_MS)
        post_clear_delay = WaitConfig.create(default=COMBOBOX_POST_CLEAR_DELAY_MIN_MS)
        post_enter_delay = WaitConfig.create(default=COMBOBOX_POST_ENTER_DELAY_MIN_MS)
        option_visible_timeout = WaitConfig.create(
            config.option_visible_timeout_ms, default=FIELD_OPTION_VISIBLE_TIMEOUT_MIN_MS
        )

        # Track attempt number for degraded retry (slower typing on retries)
        attempt_counter = [0]

        async def _do_combobox() -> None:
            attempt_counter[0] += 1
            attempt = attempt_counter[0]

            # On retry: scale typing delay by 1.5^(attempt-1) for slower, more reliable typing
            type_delay_ms = base_type_delay.resolve_ms()
            if attempt > 1:
                type_delay_ms = int(type_delay_ms * (1.5 ** (attempt - 1)))
                logger.info(f"Combobox retry attempt {attempt}: type_delay_ms={type_delay_ms} step='{step_name}'")

            await locator.click()
            await waiter.delay(config=pre_type_delay)

            # On retry: always clear to start fresh, even if clear_before_type is False
            if config.clear_before_type or attempt > 1:
                await locator.clear()
                await waiter.delay(config=post_clear_delay)

            if type_delay_ms > 0:
                await locator.press_sequentially(str(value), delay=type_delay_ms)
            else:
                await locator.fill(str(value))

            await waiter.delay(config=wait_after_type)

            option_context: Page | FrameLocator = page
            if field.iframe_selector:
                option_context = page.frame_locator(field.iframe_selector)

            option_selector = interpolate_selector_value(selector=config.option_selector, value=str(value))
            option_locator = option_context.locator(option_selector).first

            await waiter.wait_visible(locator=option_locator, config=option_visible_timeout)
            await option_locator.click()

            if config.press_enter:
                await locator.press("Enter")
                await waiter.delay(config=post_enter_delay)

            logger.info(f"Filled combobox: selector='{field.selector}' value='{value}' step='{step_name}'")

        await self._execute_with_retry(operation=_do_combobox, field=field, step_name=step_name)


class ClickSelectFieldHandler(BaseFieldHandler):
    """Handler for custom dropdown components using click-to-open, select-option pattern."""

    async def handle(
        self,
        page: Page,
        field: FieldDefinition,
        input_data: dict[str, Any],
        step_name: str,
    ) -> None:
        value = self._get_value(field=field, input_data=input_data, step_name=step_name)
        if value is None:
            logger.info(f"Skipping click_select field: data_key='{field.data_key}' step='{step_name}'")
            return

        locator = self._get_locator(page=page, field=field, step_name=step_name)
        if not await self._ensure_visible(page=page, locator=locator, field=field, step_name=step_name):
            return

        if not isinstance(field.type_config, ClickSelectFieldConfig):
            raise FieldInteractionError(
                selector=field.selector,
                step_name=step_name,
                field_type=field.type.value,
                reason="ClickSelect field requires type_config of type ClickSelectFieldConfig",
            )

        config = field.type_config
        waiter = WaitExecutor(page=page)
        post_click_delay = WaitConfig.create(field.post_click_delay_ms, default=FIELD_WAIT_AFTER_CLICK_MIN_MS)
        option_visible_timeout = WaitConfig.create(
            config.option_visible_timeout_ms, default=FIELD_OPTION_VISIBLE_TIMEOUT_MIN_MS
        )

        async def _do_click_select() -> None:
            await click_with_fallback(
                page=page,
                locator=locator,
                selector=field.selector,
                context=f"click_select open selector='{field.selector}' step='{step_name}'",
                force_first=bool(field.force_click),
            )
            await waiter.delay(config=post_click_delay)

            option_context: Page | FrameLocator = page
            if field.iframe_selector:
                option_context = page.frame_locator(field.iframe_selector)

            option_selector = interpolate_selector_value(selector=config.option_selector, value=str(value))
            option_locator = option_context.locator(option_selector).first

            await waiter.wait_visible(locator=option_locator, config=option_visible_timeout)
            await option_locator.click()

            logger.info(f"Selected click_select option: selector='{field.selector}' value='{value}' step='{step_name}'")

        await self._execute_with_retry(operation=_do_click_select, field=field, step_name=step_name)


FIELD_HANDLERS: dict[FieldType, type[BaseFieldHandler]] = {
    FieldType.TEXT: TextFieldHandler,
    FieldType.TEXTAREA: TextareaFieldHandler,
    FieldType.DROPDOWN: DropdownFieldHandler,
    FieldType.RADIO: RadioFieldHandler,
    FieldType.CHECKBOX: CheckboxFieldHandler,
    FieldType.DATE: DateFieldHandler,
    FieldType.SLIDER: SliderFieldHandler,
    FieldType.FILE: FileFieldHandler,
    FieldType.IFRAME_FIELD: IframeFieldHandler,
    FieldType.CLICK_ONLY: ClickOnlyFieldHandler,
    FieldType.COMBOBOX: ComboboxFieldHandler,
    FieldType.CLICK_SELECT: ClickSelectFieldHandler,
}


def get_field_handler(field_type: FieldType, step_name: str) -> BaseFieldHandler:
    """
    Get the appropriate handler for a field type.

    Args:
        field_type: FieldType enum value
        step_name: Current step name for error context

    Returns:
        Instantiated handler for the field type

    Raises:
        UnsupportedFieldTypeError: If field_type has no registered handler

    """
    handler_class = FIELD_HANDLERS.get(field_type)
    if handler_class is None:
        raise UnsupportedFieldTypeError(
            field_type=field_type.value,
            step_name=step_name,
        )
    return handler_class()
