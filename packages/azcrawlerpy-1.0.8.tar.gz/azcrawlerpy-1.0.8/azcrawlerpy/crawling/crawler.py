"""
Main FormCrawler class for navigating and filling multi-step web forms.

This module contains the core crawler implementation that orchestrates
field handlers and action executors to complete form workflows.

Supports both Camoufox (anti-detect Firefox) and Chromium (standard Playwright)
browser engines, selected via browser_type in instructions.json.

Resilience features:
    - restart_crawl: Steps can trigger a full browser restart when wait_for
      times out (broken page loads, partial renders). The crawl loop tears down
      the browser, creates a fresh instance, re-navigates to the start URL,
      and replays all steps from the beginning. Each step configures its own
      max_restarts budget. Profiler results are reused across restart attempts.
"""

import asyncio
import contextlib
import copy
import io
import os
import sys
import tempfile
import time
from collections.abc import AsyncGenerator, Iterator
from contextlib import asynccontextmanager, contextmanager
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

from browserforge.fingerprints import Screen
from camoufox.async_api import AsyncCamoufox
from playwright.async_api import Error as PlaywrightError
from playwright.async_api import Page, Route, async_playwright
from playwright.async_api import TimeoutError as PlaywrightTimeoutError

from .actions import get_action_executor
from .browser_utils import handle_captcha, handle_cookie_consent
from .data_extraction import apply_regex, extract_data
from .diagnostics import CrawlContext, build_diagnostic_payload, capture_page_diagnostics
from .exceptions import CrawlerError, CrawlerTimeoutError, CrawlRestartError
from .field_handlers import get_field_handler
from .models import (
    BrowserType,
    CrawlerBrowserConfig,
    CrawlResult,
    DebugMode,
    Instructions,
    StepDefinition,
    StepExtractionDefinition,
)
from .utils import (
    LoggerLike,
    TeeStream,
    attach_stream_handler,
    detach_stream_handler,
    flush_logger,
)


def _get_platform_logs_dir(logger: LoggerLike) -> Path | None:
    r"""
    Return the Azure App Service Plan log directory, or None when not present.

    Works for every Azure App Service Plan target (Web App, Function App,
    Web App / Function App in a container, Container Apps on ASP) on both
    Linux ($HOME=/home, logs at /home/LogFiles) and Windows
    ($HOME=C:\home or D:\home, logs at <HOME>\LogFiles).
    Returns None on local dev and any non-App-Service environment, logging
    the exact reason at INFO (expected) or WARNING (unexpected) level.
    """
    home = os.environ.get("HOME")
    if not home:
        logger.info("Platform log capture skipped: $HOME not set (not an Azure App Service target)")
        return None
    candidate = Path(home) / "LogFiles"
    try:
        if candidate.is_dir():
            logger.info(f"Platform log source resolved: path='{candidate}'")
            return candidate
        if candidate.exists():
            logger.warning(f"Platform log capture skipped: '{candidate}' exists but is not a directory")
            return None
        logger.info(f"Platform log capture skipped: '{candidate}' not found (not an Azure App Service target)")
    except OSError as exc:
        logger.warning(f"Platform log capture skipped: cannot stat '{candidate}' error={exc}")
    return None


def _log_platform_log_activation(
    debug_mode: DebugMode,
    logger: LoggerLike,
) -> None:
    """
    Log an upfront summary of whether the Azure App Service platform log
    capture will activate at the end of the crawl.

    Evaluates both gates -- ``debug_mode == DebugMode.ALL`` and the
    presence of ``$HOME/LogFiles/`` -- so operators can see exactly which
    one blocked activation without waiting for the post-crawl finally
    block. Uses a silent probe (no nested log lines) because the
    end-of-crawl capture emits its own detailed outcome messages.
    """
    debug_mode_is_all = debug_mode == DebugMode.ALL

    home = os.environ.get("HOME")
    logfiles_path = Path(home) / "LogFiles" if home else None
    logfiles_found = False
    if logfiles_path is not None:
        try:
            logfiles_found = logfiles_path.is_dir()
        except OSError:
            logfiles_found = False

    active = debug_mode_is_all and logfiles_found

    logger.info(
        f"Platform log capture preflight: active={active} "
        f"debug_mode='{debug_mode.value}' (requires 'all') "
        f"logfiles_path='{logfiles_path}' logfiles_found={logfiles_found} (requires True)"
    )


def _collect_platform_logs(logger: LoggerLike) -> dict[str, bytes]:
    """
    Read the full Azure App Service LogFiles tree into a dict mapping each
    relative path to its raw bytes, so the caller (who owns the sink) can
    route it wherever they like. Best-effort: per-file errors are logged
    and skipped. Returns an empty dict when the source is missing.
    """
    logger.info("Platform log capture starting")
    source = _get_platform_logs_dir(logger=logger)
    if source is None:
        return {}

    collected: dict[str, bytes] = {}
    files_collected = 0
    bytes_collected = 0
    errors = 0

    try:
        for src_path in source.rglob("*"):
            try:
                if not src_path.is_file():
                    continue
                rel = str(src_path.relative_to(source)).replace(os.sep, "/")
                data = src_path.read_bytes()
                collected[rel] = data
                files_collected += 1
                bytes_collected += len(data)
            except OSError as exc:
                errors += 1
                logger.warning(f"Failed to read platform log: src='{src_path}' error={exc}")
    except OSError as exc:
        logger.warning(f"Failed to enumerate platform logs: source='{source}' error={exc}")

    if files_collected == 0 and errors == 0:
        logger.warning(
            f"Platform log capture found source but collected nothing: source='{source}' "
            f"(directory is empty or contains no regular files)"
        )
    else:
        logger.info(
            f"Platform logs collected: source='{source}' "
            f"files={files_collected} bytes={bytes_collected} errors={errors}"
        )
    return collected


@dataclass
class _RuntimeArtifacts:
    """
    Bytes captured by ``_capture_runtime_artifacts`` for stitching onto
    the returned ``CrawlResult``. Populated by the context manager's
    ``__exit__`` so callers can read them after the with-block completes.
    """

    crawler_log: bytes = b""
    stdout_log: bytes = b""
    stderr_log: bytes = b""
    playwright_debug_log: bytes = b""


@contextmanager
def _capture_runtime_artifacts(
    debug_mode: DebugMode,
    logger: LoggerLike,
) -> Iterator[_RuntimeArtifacts]:
    """
    Capture everything worth keeping when the crawl is abruptly torn down,
    entirely in memory (plus a single throw-away tempfile for Playwright's
    node-side ``DEBUG_FILE`` which must be a real path).

    When ``debug_mode != NONE`` this:
      * attaches a ``StreamHandler`` (backed by an ``io.StringIO``) to the
        injected logger AND the root logger so third-party libraries are
        captured too;
      * tees ``sys.stdout`` / ``sys.stderr`` into in-memory buffers so bare
        ``print()`` output is preserved;
      * points ``DEBUG_FILE`` at a ``tempfile`` before the Playwright node
        subprocess is spawned, so Playwright's ``pw:api`` / ``pw:browser*``
        debug stream lands in a file we control and slurp back into bytes
        on teardown rather than disappearing into the parent stderr on
        SIGKILL.

    On exit (success, exception, or ``CancelledError`` from
    ``asyncio.timeout``) every sink is flushed, the collected bytes are
    written onto the yielded ``_RuntimeArtifacts`` object, and the tempfile
    is removed. Silent best-effort throughout; teardown failures must not
    mask the original exception.
    """
    artifacts = _RuntimeArtifacts()

    if debug_mode == DebugMode.NONE:
        yield artifacts
        return

    stdout_buf = io.StringIO()
    stderr_buf = io.StringIO()
    log_buf = io.StringIO()

    orig_stdout, orig_stderr = sys.stdout, sys.stderr
    sys.stdout = TeeStream(orig_stdout, stdout_buf)
    sys.stderr = TeeStream(orig_stderr, stderr_buf)

    log_handler = attach_stream_handler(logger, log_buf)

    fd, pw_debug_str = tempfile.mkstemp(suffix=".log", prefix="pw_debug_")
    os.close(fd)
    pw_debug_path = Path(pw_debug_str)
    prev_debug_file = os.environ.get("DEBUG_FILE")
    if prev_debug_file is None:
        os.environ["DEBUG_FILE"] = pw_debug_str

    try:
        yield artifacts
    finally:
        flush_logger(logger)
        detach_stream_handler(logger, log_handler)
        for stream in (sys.stdout, sys.stderr):
            with contextlib.suppress(Exception):
                stream.flush()
        sys.stdout, sys.stderr = orig_stdout, orig_stderr

        artifacts.crawler_log = log_buf.getvalue().encode("utf-8", errors="replace")
        artifacts.stdout_log = stdout_buf.getvalue().encode("utf-8", errors="replace")
        artifacts.stderr_log = stderr_buf.getvalue().encode("utf-8", errors="replace")
        with contextlib.suppress(OSError):
            artifacts.playwright_debug_log = pw_debug_path.read_bytes()

        if prev_debug_file is None:
            os.environ.pop("DEBUG_FILE", None)
        with contextlib.suppress(OSError):
            pw_debug_path.unlink()


@dataclass
class _CrawlState:
    """
    Internal state for a single crawl execution.

    Tracks debug configuration, output paths, screenshot numbering,
    in-memory results, and extracted data during the crawl lifecycle.

    Recreated on each crawl attempt when restart_crawl triggers a retry.
    The profiler_visited_urls are preserved across restarts by passing them
    into each new _CrawlState instance.
    """

    debug_mode: DebugMode
    context: CrawlContext
    screenshot_counter: int = 0
    current_step_name: str | None = None
    steps_completed: int = 0
    in_memory_screenshots: list[bytes] = field(default_factory=list)
    extracted_data: dict[str, Any] = field(default_factory=dict)
    profiler_visited_urls: list[str] = field(default_factory=list)
    in_memory_platform_logs: dict[str, bytes] = field(default_factory=dict)
    error_diagnostics: dict[str, Any] | None = None


class FormCrawler:
    """
    Crawler for navigating multi-step web flows: fills form fields, runs
    arbitrary actions (click/wait/scroll), handles cookie banners and
    CAPTCHA interstitials, and extracts data along the way.

    Supports Camoufox (anti-detect Firefox) and Chromium (standard Playwright)
    browser engines, selected via browser_type in instructions.json.

    When a step has restart_crawl=True and its wait_for selector times out,
    the crawler tears down the browser, creates a fresh instance, and replays
    the entire crawl from the start URL. Each step's max_restarts limits how
    many times that step can trigger a restart before raising CrawlerTimeoutError.
    """

    def __init__(
        self,
        headless: bool | Literal["virtual"],
        browser_config: CrawlerBrowserConfig | None,
        logger: LoggerLike,
    ) -> None:
        """
        Args:
            headless: Run the browser in headless mode. Use ``"virtual"`` on
                Linux to run inside Xvfb without a display.
            browser_config: Playwright / Camoufox launch overrides (proxy,
                humanize, geoip, user-agent, etc.).
            logger: Any logger with stdlib-shaped methods (``debug``/``info``/
                ``warning``/``error``/``exception``/``critical``). In practice
                pass the ``AzureLogger`` from ``azpaddypy`` so crawl telemetry
                flows to Application Insights with correlation IDs and
                OpenTelemetry spans.

        """
        self._headless: bool | Literal["virtual"] = headless
        self._browser_config: CrawlerBrowserConfig | None = browser_config
        self._logger: LoggerLike = logger

        # Enable Playwright debug logs by default unless user has overridden.
        # Must be set before the browser subprocess is spawned to take effect.
        if "DEBUG" not in os.environ:
            os.environ["DEBUG"] = "pw:api,pw:browser*"

        try:
            import camoufox as _camoufox

            camoufox_version = getattr(_camoufox, "__version__", "unknown")
        except Exception as exc:  # noqa: BLE001 - diagnostic-only version probe, must never mask crawl init
            camoufox_version = f"<error: {exc!r}>"

        self._logger.info(
            f"FormCrawler initialized: headless={headless} "
            f"camoufox_version={camoufox_version} "
            f"DEBUG={os.environ.get('DEBUG')}"
        )
        if browser_config:
            self._logger.info(f"Browser config: {browser_config.model_dump_json(indent=2)}")

    async def crawl(
        self,
        url: str,
        input_data: dict[str, Any],
        instructions: dict[str, Any],
        debug_mode: DebugMode | str = DebugMode.ALL,
        strict: bool = True,
        global_timeout_ms: int | None = None,
    ) -> CrawlResult:
        """
        Navigate and fill the form, returning results.

        If any step has restart_crawl=True and its wait_for selector times out,
        the entire crawl restarts with a fresh browser. The profiler runs once
        and its result is reused across restart attempts. Each step tracks its
        own restart attempt count against its max_restarts budget. When the
        budget is exhausted, raises CrawlerTimeoutError.

        Args:
            url: Starting URL where the form begins
            input_data: Field values to fill (key-value pairs)
            instructions: Navigation and field selectors (JSON structure)
            debug_mode: Screenshot mode (none, start, end, all)
            strict: If True, raise errors when elements not found; if False, continue gracefully
            global_timeout_ms: Wall-clock budget for the entire crawl (including
                profiler, navigation, steps and final capture). When exceeded,
                raises CrawlerTimeoutError with a partial CrawlResult attached
                via ``with_partial_result`` containing whatever state was
                collected so far (screenshots, extracted_data, steps_completed,
                profiler_visited_urls, platform_logs, crawler_log, stdout_log,
                stderr_log, playwright_debug_log). The live page is torn down
                by the cancellation, so ``html`` and ``final_url`` on the
                partial result are not populated. None disables the global
                timeout.

        Returns:
            CrawlResult with every artifact held in memory (screenshots, HTML,
            platform logs, captured stdout/stderr, Playwright debug log,
            etc.). The caller owns the sink -- nothing is written to disk.

        Raises:
            CrawlerTimeoutError: When a step's restart budget is exhausted or
                a non-restartable step times out with strict=True.

        """
        if isinstance(debug_mode, str):
            debug_mode = DebugMode(debug_mode)

        # Deep-copy to prevent model_validate from mutating the original dict
        # (_coerce_type_config replaces type_config dicts with Pydantic model instances in-place)
        validated_instructions = Instructions.model_validate(copy.deepcopy(instructions))

        # Populated by _crawl_execute each while-loop iteration so the
        # global-timeout handler below can build a partial result after the
        # task is cancelled without having to re-enter the page.
        latest_state_box: list[_CrawlState | None] = [None]

        timeout_seconds = global_timeout_ms / 1000 if global_timeout_ms is not None else None

        # Slots populated inside the with-block, stitched with artifacts
        # after the context manager exits so the final log/stdout/stderr/pw
        # bytes reflect everything that happened in the crawl -- including
        # the "Global timeout exhausted" log line and any platform-log
        # capture performed in the inner finally.
        success_result: CrawlResult | None = None
        deferred_exc: BaseException | None = None

        with _capture_runtime_artifacts(
            debug_mode=debug_mode,
            logger=self._logger,
        ) as artifacts:
            try:
                async with asyncio.timeout(timeout_seconds):
                    success_result = await self._crawl_execute(
                        url=url,
                        input_data=input_data,
                        instructions=instructions,
                        debug_mode=debug_mode,
                        strict=strict,
                        validated_instructions=validated_instructions,
                        latest_state_box=latest_state_box,
                    )
            except TimeoutError as te:
                # Reachable only when global_timeout_ms was set and the budget was
                # exceeded. Build a partial result from whatever state the current
                # iteration had collected before cancellation propagated. The page
                # is being torn down by the cancellation, so html/final_url are
                # not captured here -- screenshots, extracted data, steps count,
                # profiler_visited_urls and platform_logs (collected by the
                # inner finally during cancellation) are preserved.
                self._logger.exception(f"Global timeout exhausted: timeout_ms={global_timeout_ms}")
                flush_logger(self._logger)
                timeout_error = CrawlerTimeoutError(
                    selector="<global>",
                    step_name="<global_timeout>",
                    timeout_ms=global_timeout_ms or 0,
                )
                state = latest_state_box[0]
                if state is not None:
                    partial = CrawlResult(
                        url=url,
                        input_data=input_data,
                        instructions=instructions,
                        screenshots=state.in_memory_screenshots,
                        html="",
                        final_url=url,
                        steps_completed=state.steps_completed,
                        extracted_data=state.extracted_data,
                        profiler_visited_urls=state.profiler_visited_urls,
                        platform_logs=state.in_memory_platform_logs,
                        error_diagnostics=state.error_diagnostics,
                    )
                    timeout_error.with_partial_result(partial_result=partial)
                timeout_error.__cause__ = te
                deferred_exc = timeout_error
            except CrawlerError as ce:
                deferred_exc = ce

        # Context manager has exited: artifacts now carry the final bytes.
        # Stitch them onto the result (success) or the exception's
        # partial_result, then either return or re-raise.
        target: CrawlResult | None = success_result
        if target is None and isinstance(deferred_exc, CrawlerError):
            target = deferred_exc.partial_result
        if target is not None:
            target.crawler_log = artifacts.crawler_log
            target.stdout_log = artifacts.stdout_log
            target.stderr_log = artifacts.stderr_log
            target.playwright_debug_log = artifacts.playwright_debug_log

        if deferred_exc is not None:
            raise deferred_exc
        assert success_result is not None
        return success_result

    async def _crawl_execute(
        self,
        *,
        url: str,
        input_data: dict[str, Any],
        instructions: dict[str, Any],
        debug_mode: DebugMode,
        strict: bool,
        validated_instructions: Instructions,
        latest_state_box: list["_CrawlState | None"],
    ) -> CrawlResult:
        """
        Run the core crawl loop.

        Extracted from ``crawl()`` so the public entry point can wrap the
        full run in ``asyncio.timeout()`` without introducing an extra
        indent level across the body. ``latest_state_box`` is a 1-element
        list used as a mutable slot: updated on every while-loop iteration
        so the global-timeout handler in ``crawl()`` can build a partial
        result after the task has been cancelled.
        """
        # Tracks whether the inner finally (which runs BEFORE browser cleanup)
        # successfully collected platform logs. The outer finally only runs
        # a collection when this is False -- i.e. when the loop never got
        # far enough for the inner finally to fire (profiler-phase failure).
        logs_collected_in_loop = False

        debug_enabled = debug_mode != DebugMode.NONE

        # Seed latest_state_box with a placeholder so the outer finally and
        # the global-timeout handler in crawl() have somewhere to stash
        # in-memory platform logs if the while loop never runs (e.g. the
        # profiler raises before the first iteration). The loop overwrites
        # this on entry with the real per-iteration state.
        if latest_state_box[0] is None:
            latest_state_box[0] = _CrawlState(
                debug_mode=debug_mode,
                context=CrawlContext(debug_enabled=debug_enabled),
            )

        try:
            self._logger.info(
                f"Starting crawl: url='{url}' steps={len(validated_instructions.steps)} debug='{debug_mode.value}'"
            )
            _log_platform_log_activation(debug_mode=debug_mode, logger=self._logger)

            browser_config = validated_instructions.browser_config
            viewport_width = browser_config.viewport_width
            viewport_height = browser_config.viewport_height
            browser_type = browser_config.browser_type

            self._logger.info(f"Using browser: type='{browser_type.value}'")

            # Run profiler if configured (builds browser profile before main crawl)
            # Profiler runs once and the result is reused across restart attempts
            storage_state: Path | dict[str, Any] | None = None
            profiler_visited_urls: list[str] = []
            if validated_instructions.profiler is not None:
                from .profiler import run_profiler

                self._logger.info("Profiler config found, building browser profile")
                profiler_result = await run_profiler(
                    config=validated_instructions.profiler,
                    browser_type=browser_type,
                    browser_config=browser_config,
                    crawler_browser_config=self._browser_config,
                    headless=self._headless,
                    logger=self._logger,
                )
                profiler_visited_urls = profiler_result.visited_urls
                # In-memory Chromium returns dict, disk/Camoufox returns Path
                if profiler_result.storage_state is not None:
                    storage_state = profiler_result.storage_state
                elif profiler_result.storage_state_path is not None:
                    storage_state = profiler_result.storage_state_path
                self._logger.info(
                    f"Profile built: storage_type={type(storage_state).__name__} "
                    f"visited_urls={profiler_result.visited_urls}"
                )

            # Build max restart budget per step from instructions
            restart_budgets: dict[str, int] = {}
            for step in validated_instructions.steps:
                if step.restart_crawl and step.max_restarts is not None:
                    restart_budgets[step.name] = step.max_restarts

            restart_attempts: dict[str, int] = {}

            while True:
                state = _CrawlState(
                    debug_mode=debug_mode,
                    context=CrawlContext(debug_enabled=debug_enabled),
                    profiler_visited_urls=profiler_visited_urls,
                )
                # Expose the live iteration state to the global-timeout
                # handler in crawl(); must happen before any await so a
                # cancellation during _create_page still sees this state.
                latest_state_box[0] = state

                async with self._create_page(
                    browser_type=browser_type,
                    viewport_width=viewport_width,
                    viewport_height=viewport_height,
                    storage_state=storage_state,
                ) as page:
                    self._setup_event_handlers(page=page, state=state)

                    if self._browser_config and self._browser_config.init_scripts:
                        for script in self._browser_config.init_scripts:
                            await page.add_init_script(script=script)
                        self._logger.info(f"Injected {len(self._browser_config.init_scripts)} init scripts")

                    if browser_config.blocked_url_patterns:
                        await self._setup_blocked_routes(
                            page=page,
                            blocked_url_patterns=browser_config.blocked_url_patterns,
                        )

                    steps_completed = 0
                    # Captured so the inner finally can stitch platform_logs
                    # onto the returned CrawlResult without re-invoking the
                    # capture helper.
                    final_result: CrawlResult | None = None
                    try:
                        await page.goto(url=url, wait_until="domcontentloaded")
                        self._logger.info(f"Navigated to starting URL: url='{url}'")

                        if validated_instructions.cookie_consent:
                            await handle_cookie_consent(
                                page=page,
                                config=validated_instructions.cookie_consent,
                                strict=False,
                            )

                        if debug_mode in (DebugMode.START, DebugMode.ALL):
                            await self._take_debug_screenshot(page=page, label="start", state=state)

                        for step in validated_instructions.steps:
                            await self._process_step(
                                page=page,
                                step=step,
                                input_data=input_data,
                                state=state,
                                strict=strict,
                            )
                            steps_completed += 1
                            # Mirror onto state so the global-timeout handler
                            # can read the count after cancellation.
                            state.steps_completed = steps_completed

                        if validated_instructions.captcha:
                            await handle_captcha(
                                page=page,
                                config=validated_instructions.captcha,
                                strict=False,
                            )

                        final_result = await self._capture_final_page(
                            page=page,
                            instructions=validated_instructions,
                            steps_completed=steps_completed,
                            url=url,
                            input_data=input_data,
                            raw_instructions=instructions,
                            state=state,
                            strict=strict,
                        )
                        # Intentional two-step: the inner finally needs the
                        # reference to stitch platform_logs onto the result.
                        return final_result  # noqa: RET504

                    except CrawlRestartError as restart:
                        step_name = restart.step_name
                        restart_attempts[step_name] = restart_attempts.get(step_name, 0) + 1
                        attempt = restart_attempts[step_name]
                        budget = restart_budgets.get(step_name, 0)

                        if attempt > budget:
                            self._logger.exception(
                                f"Max restarts exhausted: step='{step_name}' attempts={attempt} max={budget}"
                            )
                            # Attach a partial_result so the inner finally can
                            # stitch platform_logs onto it via sys.exc_info().
                            # Without this, the CrawlerTimeoutError surfacing
                            # to the harness has partial_result=None and the
                            # in-memory platform_logs never reach the caller.
                            timeout_error = CrawlerTimeoutError(
                                selector=restart.selector,
                                step_name=step_name,
                                timeout_ms=restart.timeout_ms,
                            )
                            partial_result = await self._build_partial_result(
                                page=page,
                                url=url,
                                input_data=input_data,
                                raw_instructions=instructions,
                                steps_completed=steps_completed,
                                state=state,
                            )
                            timeout_error.with_partial_result(partial_result=partial_result)
                            raise timeout_error from restart

                        self._logger.warning(f"Restarting crawl: step='{step_name}' attempt={attempt}/{budget}")
                        continue  # browser closes via context manager, loop creates fresh one

                    except Exception as e:
                        if isinstance(e, CrawlerError):
                            if state.context.debug_enabled:
                                await self._capture_error_diagnostics(page=page, error=e, state=state)
                                if e.diagnostics and e.diagnostics.screenshot_bytes:
                                    state.in_memory_screenshots.append(e.diagnostics.screenshot_bytes)
                            partial_result = await self._build_partial_result(
                                page=page,
                                url=url,
                                input_data=input_data,
                                raw_instructions=instructions,
                                steps_completed=steps_completed,
                                state=state,
                            )
                            e.with_partial_result(partial_result=partial_result)
                            raise

                        crawler_error = CrawlerError(str(e))
                        crawler_error.with_original_error(original_error=e)
                        if state.context.debug_enabled:
                            await self._capture_error_diagnostics(page=page, error=crawler_error, state=state)
                            if crawler_error.diagnostics and crawler_error.diagnostics.screenshot_bytes:
                                state.in_memory_screenshots.append(crawler_error.diagnostics.screenshot_bytes)
                        partial_result = await self._build_partial_result(
                            page=page,
                            url=url,
                            input_data=input_data,
                            raw_instructions=instructions,
                            steps_completed=steps_completed,
                            state=state,
                        )
                        crawler_error.with_partial_result(partial_result=partial_result)
                        raise crawler_error from e

                    finally:
                        # Collect platform logs BEFORE the async with exits (i.e.
                        # before the browser subprocess is closed). This makes
                        # the capture robust to stalls during browser cleanup,
                        # which can happen when a CancelledError is injected
                        # while page.goto or driver I/O is hung: harnesses with
                        # tight grace periods (e.g. a 100s function timeout)
                        # can SIGKILL the process during cleanup, so we capture
                        # first. Synchronous work; safe inside a cancelled task.
                        if debug_mode == DebugMode.ALL:
                            collected = _collect_platform_logs(logger=self._logger)
                            state.in_memory_platform_logs = collected
                            # Stitch onto the success-path result (which was
                            # built before this finally ran with an empty
                            # dict) and onto any in-flight CrawlerError's
                            # partial_result. Pydantic v2 models allow
                            # attribute assignment, so this is a simple rebind.
                            if collected and final_result is not None:
                                final_result.platform_logs = collected
                                if state.error_diagnostics is not None:
                                    final_result.error_diagnostics = state.error_diagnostics
                            if collected:
                                in_flight = sys.exc_info()[1]
                                if isinstance(in_flight, CrawlerError):
                                    partial = in_flight.partial_result
                                    if isinstance(partial, CrawlResult):
                                        partial.platform_logs = collected
                            logs_collected_in_loop = True
        finally:
            # Safety net: only fires when the inner finally never ran
            # (typically profiler-phase failure, before the while loop
            # reaches an iteration). Stash onto latest_state_box[0] so the
            # global-timeout handler in crawl() can attach the logs to its
            # partial result.
            if not logs_collected_in_loop and debug_mode == DebugMode.ALL:
                collected = _collect_platform_logs(logger=self._logger)
                if collected:
                    slot = latest_state_box[0]
                    if slot is not None:
                        slot.in_memory_platform_logs = collected

    def _build_proxy_dict(self) -> dict[str, str] | None:
        """Build proxy dict from browser config, or None if no proxy configured."""
        if self._browser_config is None or self._browser_config.proxy is None:
            return None

        proxy_config = self._browser_config.proxy
        if not proxy_config.enabled:
            self._logger.info("Proxy disabled via ProxyConfig.enabled=False")
            return None

        assert proxy_config.server is not None  # guaranteed by ProxyConfig validator
        proxy_dict: dict[str, str] = {"server": proxy_config.server}
        if proxy_config.username is not None:
            proxy_dict["username"] = proxy_config.username
        if proxy_config.password is not None:
            proxy_dict["password"] = proxy_config.password

        self._logger.info(f"Using proxy: server='{proxy_config.server}'")
        return proxy_dict

    def _build_proxy_kwargs(self) -> dict[str, Any]:
        """Build proxy kwargs for AsyncCamoufox if proxy is configured."""
        proxy_dict = self._build_proxy_dict()
        if proxy_dict is None:
            return {}
        return {"proxy": proxy_dict}

    def _build_page_kwargs(self) -> dict[str, Any]:
        """Build page kwargs for browser.new_page() if SSL bypass is configured."""
        if self._browser_config is None or self._browser_config.ignore_https_errors is None:
            return {}

        self._logger.info(f"Ignoring HTTPS errors: ignore_https_errors={self._browser_config.ignore_https_errors}")
        return {"ignore_https_errors": self._browser_config.ignore_https_errors}

    def _build_humanize_kwargs(self) -> dict[str, Any]:
        """
        Build humanize kwargs for AsyncCamoufox if humanize is configured.

        Camoufox uses C++ level human-like cursor movement with distance-aware
        trajectories. This makes click interactions appear more natural.

        See: https://camoufox.com/fingerprint/cursor-movement/
        """
        if self._browser_config is None or self._browser_config.humanize is None:
            return {}

        humanize_config = self._browser_config.humanize
        if not humanize_config.enabled:
            return {}

        if humanize_config.max_time_seconds is not None:
            self._logger.info(f"Human-like cursor movement enabled: max_time={humanize_config.max_time_seconds}s")
            return {"humanize": humanize_config.max_time_seconds}

        self._logger.info("Human-like cursor movement enabled with default timing")
        return {"humanize": True}

    def _build_geoip_kwargs(self) -> dict[str, Any]:
        """
        Build geoip kwargs for AsyncCamoufox if geoip is configured.

        When enabled, Camoufox automatically detects geolocation based on IP address.
        This is useful with proxies to ensure browser geolocation matches the exit IP location.

        See: https://camoufox.com/
        """
        if self._browser_config is None or self._browser_config.geoip is None:
            return {}

        self._logger.info(f"Geoip auto-detection: geoip={self._browser_config.geoip}")
        return {"geoip": self._browser_config.geoip}

    def _build_os_kwargs(self) -> dict[str, str]:
        """Build os kwargs for AsyncCamoufox if os is configured."""
        if self._browser_config is None or self._browser_config.os is None:
            return {}

        self._logger.info(f"OS fingerprint spoofing: os={self._browser_config.os}")
        return {"os": self._browser_config.os}

    @asynccontextmanager
    async def _create_page(
        self,
        browser_type: BrowserType,
        viewport_width: int,
        viewport_height: int,
        storage_state: Path | dict[str, Any] | None = None,
    ) -> AsyncGenerator[Page]:
        """Create a browser page using the specified engine."""
        if browser_type == BrowserType.CAMOUFOX:
            # Camoufox only accepts a Path for persistent context dir
            persistent_context_dir = storage_state if isinstance(storage_state, Path) else None
            async with self._create_camoufox_page(
                viewport_width=viewport_width,
                viewport_height=viewport_height,
                persistent_context_dir=persistent_context_dir,
            ) as page:
                yield page
        else:
            async with self._create_chromium_page(
                viewport_width=viewport_width,
                viewport_height=viewport_height,
                storage_state=storage_state,
            ) as page:
                yield page

    @asynccontextmanager
    async def _create_camoufox_page(
        self,
        viewport_width: int,
        viewport_height: int,
        persistent_context_dir: Path | None = None,
    ) -> AsyncGenerator[Page]:
        screen_constraints = Screen(max_width=viewport_width, max_height=viewport_height)
        proxy_kwargs = self._build_proxy_kwargs()
        humanize_kwargs = self._build_humanize_kwargs()
        geoip_kwargs = self._build_geoip_kwargs()
        os_kwargs = self._build_os_kwargs()

        camoufox_kwargs: dict[str, Any] = {
            "headless": self._headless,
            "screen": screen_constraints,
            **proxy_kwargs,
            **humanize_kwargs,
            **geoip_kwargs,
            **os_kwargs,
        }

        if persistent_context_dir is not None:
            camoufox_kwargs["persistent_context"] = True
            camoufox_kwargs["user_data_dir"] = str(persistent_context_dir)
            self._logger.info(f"Loading camoufox profile: path='{persistent_context_dir}'")

        self._logger.info(
            f"Starting AsyncCamoufox: headless={self._headless} "
            f"kwargs_keys={list(camoufox_kwargs.keys())} "
            f"persistent={persistent_context_dir is not None}"
        )
        _t0 = time.monotonic()
        camoufox_cm = AsyncCamoufox(**camoufox_kwargs)
        self._logger.info(f"AsyncCamoufox instance constructed in {time.monotonic() - _t0:.2f}s, entering context...")
        _t1 = time.monotonic()
        async with camoufox_cm as browser_or_context:
            self._logger.info(
                f"AsyncCamoufox launched in {time.monotonic() - _t1:.2f}s (type={type(browser_or_context).__name__})"
            )
            if persistent_context_dir is not None:
                self._logger.info("Creating new page in persistent context...")
                page = await browser_or_context.new_page()
            else:
                page_kwargs = self._build_page_kwargs()
                self._logger.info(f"Creating new page: kwargs_keys={list(page_kwargs.keys())}")
                page = await browser_or_context.new_page(**page_kwargs)
            self._logger.info("Page created, yielding to caller")
            yield page

    @asynccontextmanager
    async def _create_chromium_page(
        self,
        viewport_width: int,
        viewport_height: int,
        storage_state: Path | dict[str, Any] | None = None,
    ) -> AsyncGenerator[Page]:
        headless = True if self._headless == "virtual" else self._headless

        launch_kwargs = self._build_chromium_launch_kwargs()
        context_kwargs = self._build_chromium_context_kwargs(
            viewport_width=viewport_width,
            viewport_height=viewport_height,
        )

        if storage_state is not None:
            if isinstance(storage_state, dict):
                context_kwargs["storage_state"] = storage_state
                self._logger.info("Loading chromium storage state from in-memory dict")
            else:
                context_kwargs["storage_state"] = str(storage_state)
                self._logger.info(f"Loading chromium storage state: path='{storage_state}'")

        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=headless, **launch_kwargs)
            context = await browser.new_context(**context_kwargs)
            page = await context.new_page()
            yield page

    def _build_chromium_launch_kwargs(self) -> dict[str, Any]:
        """Build launch kwargs for Playwright chromium."""
        kwargs: dict[str, Any] = {}
        proxy_dict = self._build_proxy_dict()
        if proxy_dict is not None:
            kwargs["proxy"] = proxy_dict
        return kwargs

    def _build_chromium_context_kwargs(
        self,
        viewport_width: int,
        viewport_height: int,
    ) -> dict[str, Any]:
        """Build context kwargs for Playwright chromium."""
        kwargs: dict[str, Any] = {
            "viewport": {"width": viewport_width, "height": viewport_height},
        }

        if self._browser_config is not None:
            if self._browser_config.ignore_https_errors is not None:
                kwargs["ignore_https_errors"] = self._browser_config.ignore_https_errors

            if self._browser_config.context_options is not None:
                opts = self._browser_config.context_options
                if opts.user_agent is not None:
                    kwargs["user_agent"] = opts.user_agent
                if opts.locale is not None:
                    kwargs["locale"] = opts.locale
                if opts.timezone_id is not None:
                    kwargs["timezone_id"] = opts.timezone_id
                if opts.permissions is not None:
                    kwargs["permissions"] = opts.permissions
                if opts.geolocation is not None:
                    kwargs["geolocation"] = {
                        "latitude": opts.geolocation.latitude,
                        "longitude": opts.geolocation.longitude,
                        "accuracy": opts.geolocation.accuracy,
                    }

        return kwargs

    async def _setup_blocked_routes(self, page: Page, blocked_url_patterns: list[str]) -> None:
        """Block requests matching URL patterns using page.route()."""

        async def abort_route(route: Route) -> None:
            await route.abort()

        for pattern in blocked_url_patterns:
            await page.route(pattern, abort_route)
            self._logger.info(f"Blocking requests matching: {pattern}")

    def _setup_event_handlers(self, page: Page, state: _CrawlState) -> None:
        def on_console(msg: Any) -> None:
            state.context.console_messages.append(
                {
                    "type": msg.type,
                    "text": msg.text,
                }
            )

        def on_request_failed(request: Any) -> None:
            state.context.failed_requests.append(
                {
                    "url": request.url,
                    "method": request.method,
                    "failure": request.failure,
                }
            )

        def on_response(response: Any) -> None:
            if response.request.resource_type in ("xhr", "fetch"):
                state.context.api_responses.append(
                    {
                        "url": response.url,
                        "status": response.status,
                        "method": response.request.method,
                    }
                )

        page.on("console", on_console)
        page.on("requestfailed", on_request_failed)
        page.on("response", on_response)

    async def _capture_error_diagnostics(
        self,
        page: Page,
        error: CrawlerError,
        state: _CrawlState,
    ) -> None:
        failed_selector = getattr(error, "selector", None)
        step_name = state.current_step_name

        label = step_name if step_name else "unknown"

        diagnostics = await capture_page_diagnostics(
            page=page,
            context=state.context,
            failed_selector=failed_selector,
            step_name=step_name,
            label=label,
        )

        error.with_diagnostics(diagnostics)
        state.error_diagnostics = build_diagnostic_payload(error=error, diagnostics=diagnostics)

    async def _build_partial_result(
        self,
        page: Page,
        url: str,
        input_data: dict[str, Any],
        raw_instructions: dict[str, Any],
        steps_completed: int,
        state: _CrawlState,
    ) -> CrawlResult:
        """
        Build partial result from current state when crawl fails.

        Captures whatever data is available at the time of failure,
        including any screenshots already taken during the crawl.
        """
        try:
            html_content = await page.content()
        except PlaywrightError:
            html_content = ""

        try:
            final_url = page.url
        except PlaywrightError:
            final_url = url

        return CrawlResult(
            url=url,
            input_data=input_data,
            instructions=raw_instructions,
            screenshots=state.in_memory_screenshots,
            html=html_content,
            final_url=final_url,
            steps_completed=steps_completed,
            extracted_data=state.extracted_data,
            profiler_visited_urls=state.profiler_visited_urls,
            platform_logs=state.in_memory_platform_logs,
            error_diagnostics=state.error_diagnostics,
        )

    async def _take_debug_screenshot(self, page: Page, label: str, state: _CrawlState) -> None:
        state.screenshot_counter += 1
        screenshot_bytes = await page.screenshot(full_page=True)
        state.in_memory_screenshots.append(screenshot_bytes)
        self._logger.info(f"Debug screenshot captured: label='{label}'")

    async def _extract_step_data(
        self,
        page: Page,
        extractions: list[StepExtractionDefinition],
        step_name: str,
        state: _CrawlState,
    ) -> None:
        for extraction in extractions:
            if extraction.wait_before_ms is not None:
                await page.wait_for_timeout(timeout=extraction.wait_before_ms)
                self._logger.info(f"Step extraction wait_before: ms={extraction.wait_before_ms} step='{step_name}'")

            if extraction.click_before is not None:
                if extraction.dismiss_modal_selector is not None and not (extraction.force_click or False):
                    await page.click(selector=extraction.click_before, force=True)
                    self._logger.info(
                        f"Step extraction click (force for modal): selector='{extraction.click_before}' step='{step_name}'"
                    )
                    await page.evaluate(
                        "(sel) => document.querySelector(sel).click()",
                        extraction.click_before,
                    )
                    self._logger.info(
                        f"Step extraction JS click: selector='{extraction.click_before}' step='{step_name}'"
                    )
                else:
                    await page.click(selector=extraction.click_before, force=extraction.force_click or False)
                    self._logger.info(
                        f"Step extraction click: selector='{extraction.click_before}' force={extraction.force_click} step='{step_name}'"
                    )

                if extraction.wait_after_click_ms is not None:
                    await page.wait_for_timeout(timeout=extraction.wait_after_click_ms)

            locator = page.locator(extraction.selector)
            count = await locator.count()

            if count == 0:
                self._logger.warning(
                    f"Step extraction no match: name='{extraction.name}' selector='{extraction.selector}' step='{step_name}'"
                )
                state.extracted_data[extraction.name] = None
                continue

            element = locator.first
            raw_value = (
                await element.get_attribute(name=extraction.attribute)
                if extraction.attribute
                else await element.text_content()
            )

            processed_value = apply_regex(value=raw_value, pattern=extraction.regex)
            state.extracted_data[extraction.name] = processed_value
            self._logger.info(f"Step extraction: name='{extraction.name}' value='{processed_value}' step='{step_name}'")

            if extraction.dismiss_modal_selector is not None:
                modal_locator = page.locator(extraction.dismiss_modal_selector)
                if await modal_locator.count() > 0:
                    await modal_locator.first.click(force=True)
                    self._logger.info(
                        f"Step extraction dismissed modal: selector='{extraction.dismiss_modal_selector}' step='{step_name}'"
                    )

    async def _process_step(
        self,
        page: Page,
        step: StepDefinition,
        input_data: dict[str, Any],
        state: _CrawlState,
        strict: bool,
    ) -> None:
        """
        Process a single form step under a hard wall-clock budget.

        ``step.timeout_ms`` is enforced as an upper bound on the complete
        step -- wait_for, data_extraction, field handlers (incl. retries),
        next_action (incl. retries/delays) and post_field_extraction. The
        wrapper here translates an exceeded budget via
        ``asyncio.timeout(...)`` into the same priority chain that a
        wait_for_selector timeout uses, so callers see identical behavior
        regardless of where inside the step the budget ran out.

        Priority (first match wins) for both wait_for timeouts AND step
        budget exhaustion:
            1. restart_crawl=True: raises CrawlRestartError to trigger a
               full crawl restart.
            2. optional=True: skips the step silently.
            3. strict=True: raises CrawlerTimeoutError.
            4. strict=False: logs a warning and returns.

        Raises:
            CrawlRestartError: When restart_crawl=True and the step budget
                is exceeded (or wait_for times out). Caught by
                ``_crawl_execute`` to trigger a full browser restart.
            CrawlerTimeoutError: When the step budget is exceeded (or
                wait_for times out) on a non-optional step with strict=True
                and restart_crawl is not set.

        """
        try:
            async with asyncio.timeout(step.timeout_ms / 1000):
                await self._process_step_body(
                    page=page,
                    step=step,
                    input_data=input_data,
                    state=state,
                    strict=strict,
                )
        except TimeoutError as te:
            # Reached only when the step's total wall-clock budget was
            # exhausted somewhere after wait_for_selector (extractions,
            # field handlers, action, retries). wait_for_selector's own
            # Playwright timeout handler inside _process_step_body catches
            # its PlaywrightTimeoutError first and converts to the correct
            # exception, so this branch is specifically the "rest of the
            # step took too long" case.
            if step.restart_crawl:
                self._logger.warning(
                    f"Restart requested (step budget exhausted): step='{step.name}' timeout_ms={step.timeout_ms}"
                )
                raise CrawlRestartError(
                    step_name=step.name,
                    selector=step.wait_for,
                    timeout_ms=step.timeout_ms,
                ) from te
            if step.optional:
                self._logger.info(
                    f"Optional step skipped (step budget exhausted): step='{step.name}' timeout_ms={step.timeout_ms}"
                )
                return
            if strict:
                raise CrawlerTimeoutError(
                    selector=step.wait_for,
                    step_name=step.name,
                    timeout_ms=step.timeout_ms,
                ) from te
            self._logger.warning(f"Step budget exhausted (non-strict): step='{step.name}' timeout_ms={step.timeout_ms}")

    async def _process_step_body(
        self,
        *,
        page: Page,
        step: StepDefinition,
        input_data: dict[str, Any],
        state: _CrawlState,
        strict: bool,
    ) -> None:
        """
        Inner body of :meth:`_process_step`, run under an ``asyncio.timeout``.

        Extracted so the public wrapper can enforce ``step.timeout_ms`` as
        a hard wall-clock cap on the entire step without re-indenting the
        body.
        """
        state.current_step_name = step.name
        self._logger.info(f"Processing step: name='{step.name}'")

        try:
            await page.wait_for_selector(
                selector=step.wait_for,
                state="visible",
                timeout=step.timeout_ms,
            )
            self._logger.info(f"Wait condition met: selector='{step.wait_for}' step='{step.name}'")
        except (PlaywrightTimeoutError, PlaywrightError) as e:
            if step.restart_crawl:
                self._logger.warning(
                    f"Restart requested (wait_for failed): selector='{step.wait_for}' step='{step.name}'"
                )
                raise CrawlRestartError(
                    step_name=step.name,
                    selector=step.wait_for,
                    timeout_ms=step.timeout_ms,
                ) from e
            if step.optional:
                self._logger.info(
                    f"Optional step skipped (wait_for not found): selector='{step.wait_for}' step='{step.name}'"
                )
                return
            if strict:
                raise CrawlerTimeoutError(
                    selector=step.wait_for,
                    step_name=step.name,
                    timeout_ms=step.timeout_ms,
                ) from e
            self._logger.warning(f"Step wait timeout (non-strict): selector='{step.wait_for}' step='{step.name}'")

        if step.data_extraction is not None:
            await self._extract_step_data(
                page=page,
                extractions=step.data_extraction,
                step_name=step.name,
                state=state,
            )

        for field_def in step.fields:
            try:
                handler = get_field_handler(field_type=field_def.type, step_name=step.name)
                await handler.handle(
                    page=page,
                    field=field_def,
                    input_data=input_data,
                    step_name=step.name,
                )

                if state.debug_mode == DebugMode.ALL:
                    label = f"{step.name}_{field_def.data_key}"
                    await self._take_debug_screenshot(page=page, label=label, state=state)
            except CrawlerError as e:
                if strict:
                    raise
                self._logger.warning(
                    f"Field failed (non-strict): selector='{field_def.selector}' step='{step.name}' error={e}"
                )

        if step.post_field_extraction is not None:
            await self._extract_step_data(
                page=page,
                extractions=step.post_field_extraction,
                step_name=step.name,
                state=state,
            )

        try:
            executor = get_action_executor(action_type=step.next_action.type, step_name=step.name)
            await executor.execute(
                page=page,
                action=step.next_action,
                step_name=step.name,
                input_data=input_data,
            )

            if state.debug_mode == DebugMode.ALL:
                await self._take_debug_screenshot(page=page, label=f"{step.name}_after_action", state=state)
        except CrawlerError as e:
            if strict:
                raise
            self._logger.warning(
                f"Action failed (non-strict): action='{step.next_action.type}' step='{step.name}' error={e}"
            )

        self._logger.info(f"Step completed: name='{step.name}'")

    async def _capture_final_page(
        self,
        page: Page,
        instructions: Instructions,
        steps_completed: int,
        url: str,
        input_data: dict[str, Any],
        raw_instructions: dict[str, Any],
        state: _CrawlState,
        strict: bool,
    ) -> CrawlResult:
        final_page = instructions.final_page

        if final_page.wait_for_data_key is not None:
            text_value = input_data.get(final_page.wait_for_data_key)
            if text_value is None:
                msg = f"Data key '{final_page.wait_for_data_key}' not found in input_data"
                raise ValueError(msg)
            wait_for_selector = f'text="{text_value}"'
        elif final_page.wait_for is not None:
            wait_for_selector = final_page.wait_for
        else:
            msg = "Either 'wait_for' or 'wait_for_data_key' must be provided in final_page config"
            raise ValueError(msg)

        try:
            await page.wait_for_selector(
                selector=wait_for_selector,
                state="visible",
                timeout=final_page.timeout_ms,
            )
            self._logger.info(f"Final page loaded: selector='{wait_for_selector}'")
        except (PlaywrightTimeoutError, PlaywrightError) as e:
            if strict:
                raise CrawlerTimeoutError(
                    selector=wait_for_selector,
                    step_name="final_page",
                    timeout_ms=final_page.timeout_ms,
                ) from e
            self._logger.warning(f"Final page wait timeout (non-strict): selector='{wait_for_selector}'")

        if final_page.post_wait_delay_ms > 0:
            self._logger.info(f"Waiting for SPA content to render: delay_ms={final_page.post_wait_delay_ms}")
            await page.wait_for_timeout(final_page.post_wait_delay_ms)

        if state.debug_mode in (DebugMode.END, DebugMode.ALL):
            await self._take_debug_screenshot(page=page, label="end", state=state)

        html_content = await page.content()
        final_url = page.url

        extracted_data: dict[str, Any] = dict(state.extracted_data)
        if instructions.data_extraction is not None:
            final_page_data = await extract_data(
                page=page,
                config=instructions.data_extraction,
            )
            extracted_data.update(final_page_data)
            self._logger.info(f"Final page extraction complete: fields_extracted={len(final_page_data)}")
        self._logger.info(f"Total extracted data: fields={len(extracted_data)}")

        if state.debug_mode != DebugMode.NONE:
            if final_page.screenshot_selector:
                locator = page.locator(final_page.screenshot_selector)
                final_screenshot = await locator.screenshot()
            else:
                final_screenshot = await page.screenshot(full_page=True)

            state.in_memory_screenshots.append(final_screenshot)
            self._logger.info("Captured final screenshot")

        # platform_logs / error_diagnostics are still default here (the inner
        # finally in _crawl_execute runs AFTER this returns). That finally
        # stitches the collected values onto this result. Passed at
        # construction anyway for symmetry with _build_partial_result and to
        # guarantee the attributes are never unset.
        return CrawlResult(
            url=url,
            input_data=input_data,
            instructions=raw_instructions,
            screenshots=state.in_memory_screenshots,
            html=html_content,
            final_url=final_url,
            steps_completed=steps_completed,
            extracted_data=extracted_data,
            profiler_visited_urls=state.profiler_visited_urls,
            platform_logs=state.in_memory_platform_logs,
            error_diagnostics=state.error_diagnostics,
        )
