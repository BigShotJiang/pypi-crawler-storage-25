import os
from typing import Optional, Any

import torch
import xarray as xr
from torch.utils.data import Dataset
import torch.nn.functional as F


class MussDataset(Dataset):
    def __init__(
        self,
        cache_dir: str,
        modalities: Optional[list] = None,
        transform: Optional[Any] = None,
        normalize: bool = True,
    ):
        self.cache_dir = cache_dir

        # ✅ each folder = one tile
        self.tiles = sorted([
            os.path.join(cache_dir, d)
            for d in os.listdir(cache_dir)
            if os.path.isdir(os.path.join(cache_dir, d))
        ])

        if len(self.tiles) == 0:
            raise RuntimeError(f"No tiles found in {cache_dir}")

        self.modalities = modalities
        self.transform = transform
        self.normalize = normalize

    def __len__(self):
        return len(self.tiles)

    def _load_modality(self, tile_path, modality):
        zarr_path = os.path.join(tile_path, f"{modality}.zarr")

        if not os.path.exists(zarr_path):
            return None

        try:
            da = xr.open_zarr(zarr_path)

            # 🔥 important: convert Dataset → DataArray if needed
            if isinstance(da, xr.Dataset):
                da = list(da.data_vars.values())[0]

            return da

        except Exception as e:
            print(f"[WARN] Failed loading {modality}: {e}")
            return None

    def _to_tensor(self, tile_path):
        tensors = []

        # if modalities not specified → load all available
        modalities = self.modalities
        if modalities is None:
            modalities = [
                f.replace(".zarr", "")
                for f in os.listdir(tile_path)
                if f.endswith(".zarr")
            ]

        for modality in modalities:
            da = self._load_modality(tile_path, modality)

            if da is None:
                continue

            arr = da.values  # (band, y, x) OR (y, x)

            if arr.ndim == 2:
                arr = arr[None, ...]

            tensor = torch.from_numpy(arr).float()
            tensors.append(tensor)

        if len(tensors) == 0:
            raise RuntimeError("No valid modalities found in dataset")

        x = torch.cat(tensors, dim=0)
        return x

    def _normalize(self, x):
        mean = x.mean()
        std = x.std()

        if std == 0:
            return x

        return (x - mean) / (std + 1e-6)
    def _fix_size(self, x, size=(256, 256)):
        _, h, w = x.shape

        target_h, target_w = size

        # crop if too big
        x = x[:, :target_h, :target_w]

        # recompute after crop
        _, h, w = x.shape

        # pad if too small
        pad_h = target_h - h
        pad_w = target_w - w

        if pad_h > 0 or pad_w > 0:
            x = F.pad(x, (0, pad_w, 0, pad_h), mode="constant", value=0)

        return x
    def _pad_to_size(self, x, size=(256, 256)):
        _, h, w = x.shape
        pad_h = size[0] - h
        pad_w = size[1] - w

        if pad_h < 0 or pad_w < 0:
            return x[:, :size[0], :size[1]]

        return F.pad(x, (0, pad_w, 0, pad_h), mode="constant", value=0)

    def __getitem__(self, idx):
        tile_path = self.tiles[idx]

        try:
            x = self._to_tensor(tile_path)
            x = torch.nan_to_num(x)
            x = self._fix_size(x, (256, 256))
            if self.normalize:
                x = self._normalize(x)

            if self.transform:
                x = self.transform(x)
            # print(x.shape)
            return {"image": x}

        except Exception as e:
            print(f"[SKIP] {tile_path}: {e}")
            return self.__getitem__((idx + 1) % len(self))