from collections.abc import Callable
from datetime import datetime
from pathlib import Path

import pytest
from pydantic import SecretStr
from sqlalchemy import MetaData, select
from sqlalchemy.engine import Engine

from postino_core.enums import (
    MailboxStatus,
    PasswordScheme,
)
from postino_core.errors import (
    AlreadyExistsError,
    CapacityError,
    FilesystemError,
    HookError,
    NotFoundError,
)
from postino_core.fs import FilesystemAdapter
from postino_core.hooks import HookRunner
from postino_core.models import MailboxCreate
from postino_core.providers.local import LocalProvider
from postino_core.services.mailbox import MailboxService

pytestmark = pytest.mark.integration


def _build_service(
    db: Engine,
    fs: FilesystemAdapter,
    hook: HookRunner,
    clock: Callable[[], datetime],
) -> MailboxService:
    md = MetaData()
    md.reflect(bind=db)
    return MailboxService(
        engine=db,
        identity=LocalProvider(metadata=md, clock=clock),
        fs=fs,
        hooks=hook,
        clock=clock,
        metadata=md,
    )


def _seed_domain(db: Engine, domain: str, max_mailboxes: int) -> None:
    md = MetaData()
    md.reflect(bind=db)
    with db.begin() as conn:
        conn.execute(
            md.tables["domain"]
            .insert()
            .values(
                domain=domain,
                description="",
                aliases=0,
                mailboxes=max_mailboxes,
                maxquota=0,
                quota=0,
                transport="virtual",
                backupmx=0,
                active=1,
            )
        )


def test_mailbox_add_happy_path(
    db: Engine,
    tmp_mail_root: Path,
    fake_postcreation_hook: Path,
    frozen_clock: datetime,
) -> None:
    _seed_domain(db, "example.com", max_mailboxes=10)
    fs = FilesystemAdapter(mail_root=tmp_mail_root, vmail_uid=-1, vmail_gid=-1)
    hook = HookRunner(script_path=fake_postcreation_hook)
    svc = _build_service(db, fs, hook, lambda: frozen_clock)

    created = svc.add(
        MailboxCreate(
            username="foo@example.com",
            password=SecretStr("hunter2"),
            name="Foo",
            quota_bytes=5 * 1024**3,
            scheme=PasswordScheme.BCRYPT,
        )
    )
    assert created.username == "foo@example.com"
    assert created.status is MailboxStatus.ACTIVE
    assert (tmp_mail_root / "example.com" / "foo").is_dir()


def test_mailbox_add_duplicate_raises(
    db: Engine,
    tmp_mail_root: Path,
    fake_postcreation_hook: Path,
    frozen_clock: datetime,
) -> None:
    _seed_domain(db, "example.com", max_mailboxes=10)
    svc = _build_service(
        db,
        FilesystemAdapter(mail_root=tmp_mail_root, vmail_uid=-1, vmail_gid=-1),
        HookRunner(script_path=fake_postcreation_hook),
        lambda: frozen_clock,
    )
    create = MailboxCreate(
        username="foo@example.com",
        password=SecretStr("h"),
        name="",
        quota_bytes=0,
        scheme=PasswordScheme.BCRYPT,
    )
    svc.add(create)
    with pytest.raises(AlreadyExistsError):
        svc.add(create)


def test_mailbox_add_unknown_domain_raises(
    db: Engine,
    tmp_mail_root: Path,
    fake_postcreation_hook: Path,
    frozen_clock: datetime,
) -> None:
    svc = _build_service(
        db,
        FilesystemAdapter(mail_root=tmp_mail_root, vmail_uid=-1, vmail_gid=-1),
        HookRunner(script_path=fake_postcreation_hook),
        lambda: frozen_clock,
    )
    with pytest.raises(NotFoundError):
        svc.add(
            MailboxCreate(
                username="foo@noexist.example.org",
                password=SecretStr("h"),
                name="",
                quota_bytes=0,
                scheme=PasswordScheme.BCRYPT,
            )
        )


def test_mailbox_add_capacity_exceeded(
    db: Engine,
    tmp_mail_root: Path,
    fake_postcreation_hook: Path,
    frozen_clock: datetime,
) -> None:
    _seed_domain(db, "tiny.example.org", max_mailboxes=1)
    svc = _build_service(
        db,
        FilesystemAdapter(mail_root=tmp_mail_root, vmail_uid=-1, vmail_gid=-1),
        HookRunner(script_path=fake_postcreation_hook),
        lambda: frozen_clock,
    )
    svc.add(
        MailboxCreate(
            username="a@tiny.example.org",
            password=SecretStr("p"),
            name="",
            quota_bytes=0,
            scheme=PasswordScheme.BCRYPT,
        )
    )
    with pytest.raises(CapacityError):
        svc.add(
            MailboxCreate(
                username="b@tiny.example.org",
                password=SecretStr("p"),
                name="",
                quota_bytes=0,
                scheme=PasswordScheme.BCRYPT,
            )
        )


def test_mailbox_add_fs_failure_rolls_back_db(
    db: Engine,
    tmp_path: Path,
    fake_postcreation_hook: Path,
    frozen_clock: datetime,
) -> None:
    _seed_domain(db, "example.com", max_mailboxes=10)
    # mail_root is a *file*, not a dir — mkdir will fail.
    bad_root = tmp_path / "not-a-dir"
    bad_root.write_text("blocker")
    fs = FilesystemAdapter(mail_root=bad_root, vmail_uid=-1, vmail_gid=-1)
    svc = _build_service(
        db, fs, HookRunner(script_path=fake_postcreation_hook), lambda: frozen_clock
    )
    with pytest.raises(FilesystemError):
        svc.add(
            MailboxCreate(
                username="foo@example.com",
                password=SecretStr("p"),
                name="",
                quota_bytes=0,
                scheme=PasswordScheme.BCRYPT,
            )
        )
    md = MetaData()
    md.reflect(bind=db)
    with db.begin() as conn:
        n = conn.execute(
            select(md.tables["mailbox"]).where(md.tables["mailbox"].c.username == "foo@example.com")
        ).fetchone()
    assert n is None  # rolled back


def test_mailbox_add_hook_failure_row_deleted_even_if_maildir_cleanup_fails(
    db: Engine,
    tmp_mail_root: Path,
    failing_postcreation_hook: Path,
    frozen_clock: datetime,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """H2: compensation must not let a maildir-cleanup error mask the
    original HookError or strand the DB row. Row delete runs first."""
    _seed_domain(db, "example.com", max_mailboxes=10)
    fs = FilesystemAdapter(mail_root=tmp_mail_root, vmail_uid=-1, vmail_gid=-1)
    svc = _build_service(
        db, fs, HookRunner(script_path=failing_postcreation_hook), lambda: frozen_clock
    )
    real_remove = fs.remove_maildir

    def remove_then_fail(relative: Path) -> None:
        real_remove(relative)
        raise OSError("simulated rmtree EACCES")

    monkeypatch.setattr(fs, "remove_maildir", remove_then_fail)
    with pytest.raises(HookError):
        svc.add(
            MailboxCreate(
                username="foo@example.com",
                password=SecretStr("p"),
                name="",
                quota_bytes=0,
                scheme=PasswordScheme.BCRYPT,
            )
        )
    md = MetaData()
    md.reflect(bind=db)
    with db.begin() as conn:
        mrow = conn.execute(
            select(md.tables["mailbox"]).where(md.tables["mailbox"].c.username == "foo@example.com")
        ).fetchone()
    assert mrow is None  # row delete must have run before maildir cleanup


def test_mailbox_add_hook_failure_rolls_back_row_quota_and_maildir(
    db: Engine,
    tmp_mail_root: Path,
    failing_postcreation_hook: Path,
    frozen_clock: datetime,
) -> None:
    _seed_domain(db, "example.com", max_mailboxes=10)
    fs = FilesystemAdapter(mail_root=tmp_mail_root, vmail_uid=-1, vmail_gid=-1)
    svc = _build_service(
        db, fs, HookRunner(script_path=failing_postcreation_hook), lambda: frozen_clock
    )
    with pytest.raises(HookError):
        svc.add(
            MailboxCreate(
                username="foo@example.com",
                password=SecretStr("p"),
                name="",
                quota_bytes=0,
                scheme=PasswordScheme.BCRYPT,
            )
        )
    md = MetaData()
    md.reflect(bind=db)
    mailbox = md.tables["mailbox"]
    quota2 = md.tables["quota2"]
    with db.begin() as conn:
        mrow = conn.execute(
            select(mailbox).where(mailbox.c.username == "foo@example.com")
        ).fetchone()
        qrow = conn.execute(select(quota2).where(quota2.c.username == "foo@example.com")).fetchone()
    assert mrow is None
    assert qrow is None
    assert not (tmp_mail_root / "example.com" / "foo").exists()


def test_mailbox_add_duplicate_keeps_first_mailbox_maildir(
    db: Engine,
    tmp_mail_root: Path,
    fake_postcreation_hook: Path,
    frozen_clock: datetime,
) -> None:
    _seed_domain(db, "example.com", max_mailboxes=10)
    svc = _build_service(
        db,
        FilesystemAdapter(mail_root=tmp_mail_root, vmail_uid=-1, vmail_gid=-1),
        HookRunner(script_path=fake_postcreation_hook),
        lambda: frozen_clock,
    )
    create = MailboxCreate(
        username="foo@example.com",
        password=SecretStr("p"),
        name="",
        quota_bytes=0,
        scheme=PasswordScheme.BCRYPT,
    )
    svc.add(create)
    assert (tmp_mail_root / "example.com" / "foo").is_dir()
    with pytest.raises(AlreadyExistsError):
        svc.add(create)
    # Pre-existing maildir from the first successful add must survive
    # the duplicate's compensation path.
    assert (tmp_mail_root / "example.com" / "foo").is_dir()


def test_mailbox_add_unknown_domain_cleans_up_fresh_maildir(
    db: Engine,
    tmp_mail_root: Path,
    fake_postcreation_hook: Path,
    frozen_clock: datetime,
) -> None:
    svc = _build_service(
        db,
        FilesystemAdapter(mail_root=tmp_mail_root, vmail_uid=-1, vmail_gid=-1),
        HookRunner(script_path=fake_postcreation_hook),
        lambda: frozen_clock,
    )
    with pytest.raises(NotFoundError):
        svc.add(
            MailboxCreate(
                username="foo@noexist.example.org",
                password=SecretStr("p"),
                name="",
                quota_bytes=0,
                scheme=PasswordScheme.BCRYPT,
            )
        )
    assert not (tmp_mail_root / "noexist.example.org").exists()


def test_delete_mailbox_removes_row_and_maildir(
    db: Engine,
    tmp_mail_root: Path,
    fake_postcreation_hook: Path,
    frozen_clock: datetime,
) -> None:
    _seed_domain(db, "example.com", max_mailboxes=10)
    svc = _build_service(
        db,
        FilesystemAdapter(mail_root=tmp_mail_root, vmail_uid=-1, vmail_gid=-1),
        HookRunner(script_path=fake_postcreation_hook),
        lambda: frozen_clock,
    )
    svc.add(
        MailboxCreate(
            username="foo@example.com",
            password=SecretStr("p"),
            name="",
            quota_bytes=0,
            scheme=PasswordScheme.BCRYPT,
        )
    )
    svc.delete("foo@example.com", keep_maildir=False)
    assert svc.get("foo@example.com") is None
    assert not (tmp_mail_root / "example.com" / "foo").exists()


def test_delete_mailbox_keep_maildir(
    db: Engine,
    tmp_mail_root: Path,
    fake_postcreation_hook: Path,
    frozen_clock: datetime,
) -> None:
    _seed_domain(db, "example.com", max_mailboxes=10)
    svc = _build_service(
        db,
        FilesystemAdapter(mail_root=tmp_mail_root, vmail_uid=-1, vmail_gid=-1),
        HookRunner(script_path=fake_postcreation_hook),
        lambda: frozen_clock,
    )
    svc.add(
        MailboxCreate(
            username="foo@example.com",
            password=SecretStr("p"),
            name="",
            quota_bytes=0,
            scheme=PasswordScheme.BCRYPT,
        )
    )
    svc.delete("foo@example.com", keep_maildir=True)
    assert (tmp_mail_root / "example.com" / "foo").is_dir()


def test_list_returns_all_mailboxes_for_domain(
    db: Engine,
    tmp_mail_root: Path,
    fake_postcreation_hook: Path,
    frozen_clock: datetime,
) -> None:
    _seed_domain(db, "example.com", max_mailboxes=10)
    svc = _build_service(
        db,
        FilesystemAdapter(mail_root=tmp_mail_root, vmail_uid=-1, vmail_gid=-1),
        HookRunner(script_path=fake_postcreation_hook),
        lambda: frozen_clock,
    )
    for u in ("a@example.com", "b@example.com"):
        svc.add(
            MailboxCreate(
                username=u,
                password=SecretStr("p"),
                name="",
                quota_bytes=0,
                scheme=PasswordScheme.BCRYPT,
            )
        )
    out = svc.list(domain="example.com", include_disabled=True)
    assert {m.username for m in out} == {"a@example.com", "b@example.com"}


def test_set_password_changes_hash(
    db: Engine,
    tmp_mail_root: Path,
    fake_postcreation_hook: Path,
    frozen_clock: datetime,
) -> None:
    _seed_domain(db, "example.com", max_mailboxes=10)
    svc = _build_service(
        db,
        FilesystemAdapter(mail_root=tmp_mail_root, vmail_uid=-1, vmail_gid=-1),
        HookRunner(script_path=fake_postcreation_hook),
        lambda: frozen_clock,
    )
    svc.add(
        MailboxCreate(
            username="foo@example.com",
            password=SecretStr("a"),
            name="",
            quota_bytes=0,
            scheme=PasswordScheme.BCRYPT,
        )
    )
    svc.set_password("foo@example.com", SecretStr("b"), PasswordScheme.BCRYPT)
    # verified via Provider in its own tests; here we simply ensure no error.


def test_set_status(
    db: Engine,
    tmp_mail_root: Path,
    fake_postcreation_hook: Path,
    frozen_clock: datetime,
) -> None:
    _seed_domain(db, "example.com", max_mailboxes=10)
    svc = _build_service(
        db,
        FilesystemAdapter(mail_root=tmp_mail_root, vmail_uid=-1, vmail_gid=-1),
        HookRunner(script_path=fake_postcreation_hook),
        lambda: frozen_clock,
    )
    svc.add(
        MailboxCreate(
            username="foo@example.com",
            password=SecretStr("p"),
            name="",
            quota_bytes=0,
            scheme=PasswordScheme.BCRYPT,
        )
    )
    svc.set_status("foo@example.com", MailboxStatus.DISABLED)
    m = svc.get("foo@example.com")
    assert m is not None and m.status is MailboxStatus.DISABLED


def test_mailbox_add_resets_stale_quota_row(
    db: Engine,
    tmp_mail_root: Path,
    fake_postcreation_hook: Path,
    frozen_clock: datetime,
) -> None:
    """A prior partial add can leave a quota2 row with stale counters.
    A subsequent successful add for the same username must zero them
    out (UPSERT semantics) — otherwise the new mailbox starts already
    over its quota."""
    _seed_domain(db, "example.com", max_mailboxes=10)
    md = MetaData()
    md.reflect(bind=db)
    quota2 = md.tables["quota2"]
    with db.begin() as conn:
        conn.execute(
            quota2.insert().values(username="foo@example.com", bytes=999_999_999, messages=42)
        )

    svc = _build_service(
        db,
        FilesystemAdapter(mail_root=tmp_mail_root, vmail_uid=-1, vmail_gid=-1),
        HookRunner(script_path=fake_postcreation_hook),
        lambda: frozen_clock,
    )
    svc.add(
        MailboxCreate(
            username="foo@example.com",
            password=SecretStr("p"),
            name="",
            quota_bytes=0,
            scheme=PasswordScheme.BCRYPT,
        )
    )
    with db.begin() as conn:
        row = conn.execute(
            select(quota2.c.bytes, quota2.c.messages).where(quota2.c.username == "foo@example.com")
        ).fetchone()
    assert row is not None
    assert int(row[0]) == 0  # type: ignore[arg-type]  # WHY: SQLAlchemy Row indexing yields Any.
    assert int(row[1]) == 0  # type: ignore[arg-type]  # WHY: SQLAlchemy Row indexing yields Any.


def test_delete_logs_warning_for_orphan_aliases(
    db: Engine,
    tmp_mail_root: Path,
    fake_postcreation_hook: Path,
    frozen_clock: datetime,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """Deleting a mailbox referenced by an alias's goto must surface a
    WARNING — the alias survives but now points at a missing recipient."""
    import logging

    _seed_domain(db, "example.com", max_mailboxes=10)
    svc = _build_service(
        db,
        FilesystemAdapter(mail_root=tmp_mail_root, vmail_uid=-1, vmail_gid=-1),
        HookRunner(script_path=fake_postcreation_hook),
        lambda: frozen_clock,
    )
    svc.add(
        MailboxCreate(
            username="foo@example.com",
            password=SecretStr("p"),
            name="",
            quota_bytes=0,
            scheme=PasswordScheme.BCRYPT,
        )
    )
    md = MetaData()
    md.reflect(bind=db)
    with db.begin() as conn:
        conn.execute(
            md.tables["alias"]
            .insert()
            .values(
                address="team@example.com",
                goto="foo@example.com,bar@example.com",
                domain="example.com",
                created=frozen_clock,
                modified=frozen_clock,
                active=1,
            )
        )
    with caplog.at_level(logging.WARNING, logger="postino_core.services.mailbox"):
        svc.delete("foo@example.com", keep_maildir=True)
    messages = [r.getMessage() for r in caplog.records]
    assert any("team@example.com" in m and "foo@example.com" in m for m in messages)


def test_delete_does_not_warn_on_substring_only_match(
    db: Engine,
    tmp_mail_root: Path,
    fake_postcreation_hook: Path,
    frozen_clock: datetime,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """`bbob@example.com` referenced by an alias must not trip the orphan
    warning when `bob@example.com` is deleted — comma-split exact match
    only."""
    import logging

    _seed_domain(db, "example.com", max_mailboxes=10)
    svc = _build_service(
        db,
        FilesystemAdapter(mail_root=tmp_mail_root, vmail_uid=-1, vmail_gid=-1),
        HookRunner(script_path=fake_postcreation_hook),
        lambda: frozen_clock,
    )
    svc.add(
        MailboxCreate(
            username="bob@example.com",
            password=SecretStr("p"),
            name="",
            quota_bytes=0,
            scheme=PasswordScheme.BCRYPT,
        )
    )
    md = MetaData()
    md.reflect(bind=db)
    with db.begin() as conn:
        conn.execute(
            md.tables["alias"]
            .insert()
            .values(
                address="x@example.com",
                goto="bbob@example.com",
                domain="example.com",
                created=frozen_clock,
                modified=frozen_clock,
                active=1,
            )
        )
    with caplog.at_level(logging.WARNING, logger="postino_core.services.mailbox"):
        svc.delete("bob@example.com", keep_maildir=True)
    assert not caplog.records


def test_set_quota(
    db: Engine,
    tmp_mail_root: Path,
    fake_postcreation_hook: Path,
    frozen_clock: datetime,
) -> None:
    _seed_domain(db, "example.com", max_mailboxes=10)
    svc = _build_service(
        db,
        FilesystemAdapter(mail_root=tmp_mail_root, vmail_uid=-1, vmail_gid=-1),
        HookRunner(script_path=fake_postcreation_hook),
        lambda: frozen_clock,
    )
    svc.add(
        MailboxCreate(
            username="foo@example.com",
            password=SecretStr("p"),
            name="",
            quota_bytes=0,
            scheme=PasswordScheme.BCRYPT,
        )
    )
    svc.set_quota("foo@example.com", 5 * 1024**3)
    m = svc.get("foo@example.com")
    assert m is not None and m.quota_bytes == 5 * 1024**3
