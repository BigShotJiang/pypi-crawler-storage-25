"""IdentityProvider Protocol — the seam between local and external identity backends.

Two implementations ship in this build:

* ``LocalProvider`` — passwords stored in PA ``mailbox.password``. The
  CLI provisions them. ``supports_password_change`` and
  ``supports_local_provisioning`` both return True.
* ``NoAuthProvider`` — ``mailbox.password`` is left as ``{NOAUTH}``. An
  external IdP authenticates dovecot via passdb. The CLI cannot
  provision or rotate passwords; both ``supports_*`` predicates return
  False.

Boundary types: ``username`` is a plain ``str`` here. The
``EmailStr`` validation lives at the CLI / model boundary
(``MailboxCreate.username: EmailStr``); providers receive an already-
validated string and do not re-validate.
"""

from __future__ import annotations

from typing import Protocol

from pydantic import SecretStr
from sqlalchemy.engine import Connection

from postino_core.enums import PasswordScheme

# Sentinel value written to PA `mailbox.password` whenever postino
# cannot fill the column with a real hash — either as the bootstrap
# placeholder before LocalProvider replaces it, or as the permanent
# value under NoAuthProvider. Dovecot's passdb-sql query treats
# `{NOAUTH}` as "no local credential; defer to other passdbs".
SENTINEL_NOAUTH = "{NOAUTH}"


class IdentityProvider(Protocol):
    """Owner of authentication identity for a mailbox."""

    def create_identity(
        self,
        conn: Connection,
        username: str,
        name: str,
        password: SecretStr | None,
        scheme: PasswordScheme | None,
    ) -> None:
        """Establish the identity. Called immediately after the mailbox
        row INSERT (with the ``{NOAUTH}`` sentinel password).

        ``LocalProvider`` UPDATEs the password column with the hash
        derived from ``password``/``scheme``, and raises ``ConfigError``
        if either is None. ``NoAuthProvider`` is a no-op (the sentinel
        already in place is the permanent value)."""
        ...

    def set_password(
        self,
        conn: Connection,
        username: str,
        password: SecretStr,
        scheme: PasswordScheme,
    ) -> None:
        """Change the password for an existing identity.

        Returns None on success.
        Raises NotFoundError if identity is absent; ConfigError if scheme
        is unsupported."""
        ...

    def delete_identity(
        self,
        conn: Connection,
        username: str,
    ) -> None:
        """Remove identity (idempotent — no error if absent).

        For LocalProvider this is a no-op (the mailbox row deletion in
        MailboxService.delete already drops the row's password)."""
        ...

    def supports_password_change(self) -> bool:
        """Whether ``postino user passwd`` is exposed."""
        ...

    def supports_local_provisioning(self) -> bool:
        """Whether ``postino user add`` accepts a password.

        Returns False for backends where the IdP owns user lifecycle —
        in that mode users must be created in the IdP first and the
        mailbox row gets the ``{NOAUTH}`` sentinel."""
        ...
