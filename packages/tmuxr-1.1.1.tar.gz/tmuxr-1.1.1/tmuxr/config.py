from dataclasses import dataclass, field
from pathlib import Path

import yaml


class TmuxrConfigError(Exception):
    """Raised when the tmuxr config file is invalid."""


VALID_RESTART_VALUES = {"never", "on-failure", "always"}


@dataclass
class WindowConfig:
    name: str
    cmd: str
    dir: str = "."
    restart: str = "never"
    env_file: str | None = None
    pre_cmd: str | None = None
    down_cmd: str | None = None
    wait_for: str | None = None
    wait_timeout: int = 60
    wait_interval: int = 2


@dataclass
class TmuxrConfig:
    session: str
    windows: list[WindowConfig]
    env_file: str | None = None
    config_dir: Path = field(default_factory=lambda: Path("."))


CONFIG_FILENAMES = ["tmuxfile.yml", ".tmuxfile.yml"]


def find_config(filename: str | None = None) -> Path | None:
    """Walk up directories to find config, like git does."""
    current = Path.cwd()
    filenames = [filename] if filename else CONFIG_FILENAMES
    while current != current.parent:
        for name in filenames:
            candidate = current / name
            if candidate.exists():
                return candidate
        current = current.parent
    return None


def _validate_raw(raw: dict) -> None:
    """Validate raw YAML dict before constructing config objects."""
    if not isinstance(raw, dict):
        raise TmuxrConfigError("Config file must be a YAML mapping, got empty or invalid content.")

    if "session" not in raw or not isinstance(raw["session"], str) or not raw["session"].strip():
        raise TmuxrConfigError("Config must have a non-empty 'session' name.")

    if "windows" not in raw:
        raise TmuxrConfigError("Config must have a 'windows' list.")

    if not isinstance(raw["windows"], list) or len(raw["windows"]) == 0:
        raise TmuxrConfigError("Config 'windows' must be a non-empty list.")

    for i, w in enumerate(raw["windows"]):
        if not isinstance(w, dict):
            raise TmuxrConfigError(f"Window #{i + 1} must be a mapping.")
        if "name" not in w or not isinstance(w["name"], str) or not w["name"].strip():
            raise TmuxrConfigError(f"Window #{i + 1} must have a non-empty 'name'.")
        if "cmd" not in w or not isinstance(w["cmd"], str) or not w["cmd"].strip():
            raise TmuxrConfigError(f"Window '{w.get('name', i + 1)}' must have a non-empty 'cmd'.")
        restart = w.get("restart", "never")
        if restart not in VALID_RESTART_VALUES:
            raise TmuxrConfigError(
                f"Window '{w['name']}' has invalid restart value '{restart}'. "
                f"Must be one of: {', '.join(sorted(VALID_RESTART_VALUES))}"
            )

        down_cmd = w.get("down_cmd")
        if down_cmd is not None and (not isinstance(down_cmd, str) or not down_cmd.strip()):
            raise TmuxrConfigError(
                f"Window '{w['name']}' has invalid 'down_cmd' — must be a non-empty string."
            )

        wait_for = w.get("wait_for")
        if wait_for is not None and (not isinstance(wait_for, str) or not wait_for.strip()):
            raise TmuxrConfigError(
                f"Window '{w['name']}' has invalid 'wait_for' — must be a non-empty string."
            )

        wait_timeout = w.get("wait_timeout", 60)
        if not isinstance(wait_timeout, (int, float)) or wait_timeout <= 0:
            raise TmuxrConfigError(
                f"Window '{w['name']}' has invalid 'wait_timeout' — must be a positive number."
            )

        wait_interval = w.get("wait_interval", 2)
        if not isinstance(wait_interval, (int, float)) or wait_interval <= 0:
            raise TmuxrConfigError(
                f"Window '{w['name']}' has invalid 'wait_interval' — must be a positive number."
            )


def _resolve_paths(config: TmuxrConfig) -> None:
    """Resolve all relative paths to absolute, relative to config_dir."""
    base = config.config_dir

    if config.env_file:
        config.env_file = str((base / config.env_file).resolve())

    for w in config.windows:
        w.dir = str((base / w.dir).resolve())
        if w.env_file:
            w.env_file = str((base / w.env_file).resolve())


def load_config(path: Path) -> TmuxrConfig:
    """Load and validate a tmuxfile.yml config file."""
    try:
        with open(path) as f:
            raw = yaml.safe_load(f)
    except yaml.YAMLError as e:
        raise TmuxrConfigError(f"Invalid YAML in {path}: {e}") from e

    _validate_raw(raw)

    try:
        windows = [WindowConfig(**w) for w in raw["windows"]]
    except TypeError as e:
        raise TmuxrConfigError(f"Invalid window config: {e}") from e

    config = TmuxrConfig(
        session=raw["session"],
        windows=windows,
        env_file=raw.get("env_file"),
        config_dir=path.parent.resolve(),
    )

    _resolve_paths(config)
    return config
