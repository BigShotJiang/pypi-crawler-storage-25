import os


def human_bytes(n):
    for unit in ("B", "KB", "MB", "GB"):
        if abs(n) < 1024:
            return f"{n:.1f} {unit}" if unit != "B" else f"{n} B"
        n /= 1024
    return f"{n:.1f} TB"


def env_int(key, default):
    value = os.getenv(key)
    if value is None or value == "":
        return default
    try:
        return int(value)
    except ValueError:
        return default


def env_bool(key, default=False):
    value = os.getenv(key)
    if value is None or value == "":
        return default
    return value.strip().lower() in ("1", "true", "yes", "y", "on")


def env_float(key, default):
    value = os.getenv(key)
    if value is None or value == "":
        return default
    try:
        return float(value)
    except ValueError:
        return default


BATCH_JSON_PREFIX_BYTES = len('{"steps":[')
BATCH_JSON_SUFFIX_BYTES = len("]}")
BATCH_JSON_ITEM_SEPARATOR_BYTES = 1
BATCH_JSON_ITEM_FIXED_BYTES = len('{"step":') + len(',"value":"') + len('"}')


def estimate_base64_chars(raw_len):
    return ((int(raw_len) + 2) // 3) * 4


def estimate_batch_item_wire_bytes(step, raw_len):
    return BATCH_JSON_ITEM_FIXED_BYTES + len(str(int(step))) + estimate_base64_chars(raw_len)


def estimate_batch_body_wire_bytes(items, content_key="value"):
    total = BATCH_JSON_PREFIX_BYTES + BATCH_JSON_SUFFIX_BYTES
    for index, item in enumerate(items):
        if index:
            total += BATCH_JSON_ITEM_SEPARATOR_BYTES
        total += estimate_batch_item_wire_bytes(item["step"], len(item[content_key]))
    return total


def next_run_name(current_run_name, response):
    try:
        payload = response.json()
    except ValueError:
        payload = {}

    suggested_name = payload.get("suggested_name")
    if suggested_name:
        return str(suggested_name)

    if "-" in current_run_name and current_run_name.rsplit("-", 1)[1].isdigit():
        base_name, suffix = current_run_name.rsplit("-", 1)
        return f"{base_name}-{int(suffix) + 1}"
    return f"{current_run_name}-2"
