import gzip
import base64
import json
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import click
import requests

from . import auth
from ._util import (
    BATCH_JSON_ITEM_SEPARATOR_BYTES,
    BATCH_JSON_PREFIX_BYTES,
    BATCH_JSON_SUFFIX_BYTES,
    env_bool,
    env_int,
    estimate_batch_body_wire_bytes,
    estimate_batch_item_wire_bytes,
    human_bytes,
    next_run_name,
)


SYNC_STATE_FILENAME = "remote-sync-state.json"
SYNC_STATE_VERSION = 1
DEFAULT_SYNC_INTERVAL_S = 5.0
DEFAULT_SYNC_BATCH_SIZE = 128
DEFAULT_SYNC_MAX_BATCH_BYTES = 5 * 1024 * 1024
_STATUS_LINE_WIDTH = 80


def _get_sync_upload_config():
    return {
        "batch_size": env_int("GRADEXP_BATCH_SIZE", DEFAULT_SYNC_BATCH_SIZE),
        "max_batch_bytes": env_int("GRADEXP_MAX_BATCH_BYTES", DEFAULT_SYNC_MAX_BATCH_BYTES),
        "gzip_upload": env_bool("GRADEXP_GZIP_UPLOAD", default=False),
        "gzip_level": env_int("GRADEXP_GZIP_LEVEL", 1),
        "max_chunk_bytes": env_int("GRADEXP_MAX_CHUNK_BYTES", 4 * 1024 * 1024),
    }


def _build_step_batch_body(steps):
    payload = {
        "steps": [
            {
                "step": int(item["step"]),
                "value": base64.b64encode(item["value"]).decode("ascii"),
            }
            for item in steps
        ]
    }
    return json.dumps(payload, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


@dataclass
class SyncSummary:
    store_available: bool = True
    runs_created: int = 0
    tensors_created: int = 0
    step_batches_uploaded: int = 0
    steps_uploaded: int = 0
    bytes_uploaded: int = 0
    statuses_updated: int = 0

    def changed(self):
        return any(
            (
                self.runs_created,
                self.tensors_created,
                self.step_batches_uploaded,
                self.steps_uploaded,
                self.bytes_uploaded,
                self.statuses_updated,
            )
        )


@dataclass
class LocalSyncStatus:
    store_available: bool = False
    local_bytes: int = 0
    total_runs: int = 0
    unsynced_runs: int = 0
    total_tensors: int = 0
    total_steps: int = 0
    unsynced_tensors: int = 0
    unsynced_steps: int = 0
    unsynced_bytes: int = 0
    error: Optional[str] = None

    def is_fully_synced(self):
        return (
            self.store_available
            and not self.error
            and self.unsynced_runs == 0
            and self.unsynced_tensors == 0
            and self.unsynced_steps == 0
        )


class HostedSyncClient:
    def __init__(self, api_key, api_base_url=None, session=None):
        self.api_key = api_key
        self.api_base_url = (api_base_url or auth.get_api_base_url(prefer_local=False)).rstrip("/")
        self._session = session or requests.Session()
        self._upload_config = _get_sync_upload_config()

    def get_remote_user(self):
        response = self._session.get(self._url("/api/v1/me"), headers=self._headers(), timeout=30)
        response.raise_for_status()
        return response.json()

    def create_run(self, project_name, run_name, source="sync"):
        current_run_name = run_name
        while True:
            response = self._session.post(
                self._url("/api/v1/runs"),
                headers=self._headers(),
                json={"project_name": project_name, "run_name": current_run_name, "source": source},
                timeout=30,
            )

            if response.status_code == 409:
                current_run_name = next_run_name(current_run_name, response)
                continue

            response.raise_for_status()
            payload = response.json()
            return {
                "project_id": payload.get("project_id"),
                "run_id": payload.get("run_id"),
                "run_name": current_run_name,
            }

    def update_run_status(self, run_id, status):
        response = self._session.patch(
            self._url(f"/api/v1/runs/{run_id}"),
            headers=self._headers(),
            json={"status": status},
            timeout=30,
        )
        response.raise_for_status()

    def create_tensor(self, run_id, tensor):
        payload = {
            "name": str(tensor.get("name") or ""),
            "dtype": str(tensor.get("dtype") or ""),
            "shape": [int(value) for value in (tensor.get("shape") or [])],
            "dimension_labels": list(tensor.get("dimensionLabels") or []),
        }
        tag = tensor.get("tag")
        if tag:
            payload["tag"] = str(tag)
        response = self._session.post(
            self._url(f"/api/v1/runs/{run_id}/tensors"),
            headers=self._headers(),
            json=payload,
            timeout=30,
        )
        response.raise_for_status()
        return response.json()

    def upload_tensor_steps(self, tensor_id, steps):
        if not steps:
            return 0, 0

        if len(steps) == 1 and estimate_batch_body_wire_bytes(steps) > self._upload_config["max_batch_bytes"]:
            return self._upload_tensor_step_raw(tensor_id, steps[0])

        headers = self._headers()
        body = _build_step_batch_body(steps)
        if self._upload_config["gzip_upload"]:
            body = gzip.compress(
                body,
                compresslevel=max(0, min(9, self._upload_config["gzip_level"])),
            )
            headers["Content-Encoding"] = "gzip"

        try:
            response = self._session.post(
                self._url(f"/api/v1/tensors/{tensor_id}/steps"),
                headers=headers,
                data=body,
                timeout=60,
            )
            response.raise_for_status()
        except requests.exceptions.HTTPError as error:
            if error.response.status_code == 413 and len(steps) > 1:
                midpoint = len(steps) // 2
                left_count, left_bytes = self.upload_tensor_steps(tensor_id, steps[:midpoint])
                right_count, right_bytes = self.upload_tensor_steps(tensor_id, steps[midpoint:])
                return left_count + right_count, left_bytes + right_bytes
            if error.response.status_code == 413 and len(steps) == 1:
                return self._upload_tensor_step_raw(tensor_id, steps[0])
            raise

        return len(steps), sum(len(item["value"]) for item in steps)

    def _upload_tensor_step_raw(self, tensor_id, step_item):
        headers = self._headers(content_type="application/octet-stream")
        body = step_item["value"]
        if self._upload_config["gzip_upload"]:
            body = gzip.compress(body, compresslevel=max(0, min(9, self._upload_config["gzip_level"])))
            headers["Content-Encoding"] = "gzip"

        try:
            response = self._session.post(
                self._url(f"/api/v1/tensors/{tensor_id}/step?step={int(step_item['step'])}"),
                headers=headers,
                data=body,
                timeout=60,
            )
            response.raise_for_status()
        except requests.exceptions.HTTPError as error:
            if error.response is not None and error.response.status_code == 413:
                return self._upload_tensor_step_chunked(tensor_id, step_item)
            raise
        return 1, len(step_item["value"])

    def _upload_tensor_step_chunked(self, tensor_id, step_item):
        chunk_size = self._upload_config.get("max_chunk_bytes", 4 * 1024 * 1024)
        data = step_item["value"]
        step = int(step_item["step"])
        total_chunks = (len(data) + chunk_size - 1) // chunk_size
        click.echo(
            f"    ↻ step {step} too large ({human_bytes(len(data))}), "
            f"uploading in {total_chunks} chunks"
        )

        for i in range(total_chunks):
            chunk = data[i * chunk_size : (i + 1) * chunk_size]
            headers = self._headers(content_type="application/octet-stream")
            if self._upload_config["gzip_upload"]:
                chunk = gzip.compress(chunk, compresslevel=max(0, min(9, self._upload_config["gzip_level"])))
                headers["Content-Encoding"] = "gzip"
            response = self._session.post(
                self._url(f"/api/v1/tensors/{tensor_id}/step/chunked?step={step}&chunk_index={i}&total_chunks={total_chunks}"),
                headers=headers,
                data=chunk,
                timeout=60,
            )
            response.raise_for_status()

        return 1, len(data)

    def _headers(self, content_type="application/json"):
        headers = {
            "Authorization": f"Bearer {self.api_key}",
        }
        if content_type:
            headers["Content-Type"] = content_type
        return headers

    def _url(self, path):
        normalized_path = path if path.startswith("/") else f"/{path}"
        return f"{self.api_base_url}{normalized_path}"


def run_local_sync(data_dir=None, once=False, interval=DEFAULT_SYNC_INTERVAL_S):  # noqa: C901
    resolved_data_dir = Path(data_dir).expanduser() if data_dir else auth.get_local_data_dir()
    resolved_data_dir.mkdir(parents=True, exist_ok=True)

    sync_client, remote_user = _build_hosted_sync_client()
    remote_user_label = _remote_user_label(remote_user)

    if once:
        click.echo(f"Syncing {resolved_data_dir} → {sync_client.api_base_url} ({remote_user_label})")
        try:
            summary = sync_local_data_once(resolved_data_dir, sync_client, remote_user)
        except Exception as error:
            raise click.ClickException(str(error)) from error
        _report_sync_cycle(summary, resolved_data_dir, remote_user_label, is_watch=False)
        return summary

    click.echo(
        f"Syncing local data from {resolved_data_dir} to {sync_client.api_base_url} for {remote_user_label}. Press Ctrl+C to stop."
    )
    missing_store_reported = False
    idle_since = None
    try:
        while True:
            try:
                summary = sync_local_data_once(resolved_data_dir, sync_client, remote_user)
                if not summary.store_available:
                    _clear_status_line()
                    if not missing_store_reported:
                        click.echo(f"Waiting for local data in {resolved_data_dir}")
                        missing_store_reported = True
                    idle_since = None
                elif summary.changed():
                    _clear_status_line()
                    missing_store_reported = False
                    idle_since = None
                    _report_sync_cycle(summary, resolved_data_dir, remote_user_label, is_watch=True)
                else:
                    missing_store_reported = False
                    if idle_since is None:
                        idle_since = time.time()
                    elapsed = int(time.time() - idle_since)
                    click.echo(f"\r{_DIM}↻ watching (no new data) · idle {elapsed}s{_RESET}  ", nl=False)
            except Exception as error:
                _clear_status_line()
                click.echo(f"Sync error: {error}")
                idle_since = None
            time.sleep(interval)
    except KeyboardInterrupt:
        _clear_status_line()
        click.echo("Stopping local sync.")
        return None


def sync_local_data_once(data_dir, sync_client, remote_user):
    resolved_data_dir = Path(data_dir).expanduser()
    local_store = _load_local_store(resolved_data_dir)
    if local_store is None:
        return SyncSummary(store_available=False)

    sync_state = _load_sync_state(resolved_data_dir)
    account_state = _get_account_state(sync_state, sync_client.api_base_url, remote_user)
    summary = SyncSummary()

    projects_by_id = {
        str(project["projectId"]): project
        for project in local_store.get("projects", [])
        if isinstance(project, dict) and project.get("projectId")
    }
    tensors_by_run = {}
    for tensor in local_store.get("tensors", []):
        if not isinstance(tensor, dict):
            continue
        run_id = str(tensor.get("runId") or "")
        if not run_id:
            continue
        tensors_by_run.setdefault(run_id, []).append(tensor)

    runs = [
        run
        for run in local_store.get("runs", [])
        if isinstance(run, dict) and run.get("runId") and run.get("projectId") in projects_by_id
    ]
    runs.sort(key=lambda item: str(item.get("createdAt") or ""))

    max_tensor_name_len = max(
        (len(str(t.get("name") or "")) for ts in tensors_by_run.values() for t in ts),
        default=0,
    )

    state_dirty = False
    for run in runs:
        local_run_id = str(run["runId"])
        project = projects_by_id[str(run["projectId"])]
        run_state = account_state["runs"].setdefault(local_run_id, {})

        if not run_state.get("remote_run_id"):
            created_run = sync_client.create_run(str(project.get("name") or "default"), str(run.get("name") or "run"))
            local_status = str(run.get("status") or "active")
            run_state.update(
                {
                    "remote_project_id": created_run.get("project_id"),
                    "remote_run_id": created_run.get("run_id"),
                    "remote_run_name": created_run.get("run_name"),
                    "last_synced_status": local_status,
                }
            )
            # Set correct status immediately so synced runs don't appear as 'active' during upload
            if local_status != "active":
                sync_client.update_run_status(run_state["remote_run_id"], local_status)
            summary.runs_created += 1
            state_dirty = True
            _save_sync_state(resolved_data_dir, sync_state)
            click.echo(f"  + run '{run_state['remote_run_name']}' in project '{project.get('name')}'  [{local_status}]")

        pending_upload_entries = []
        for tensor in sorted(tensors_by_run.get(local_run_id, []), key=lambda item: str(item.get("createdAt") or "")):
            local_tensor_id = str(tensor.get("tensorId") or "")
            if not local_tensor_id:
                continue

            tensor_state = account_state["tensors"].setdefault(local_tensor_id, {"last_synced_step": -1})
            try:
                if not tensor_state.get("remote_tensor_id"):
                    created_tensor = sync_client.create_tensor(run_state["remote_run_id"], tensor)
                    tensor_state["remote_tensor_id"] = created_tensor.get("tensor_id")
                    summary.tensors_created += 1
                    state_dirty = True
                    _save_sync_state(resolved_data_dir, sync_state)
                    click.echo(f"  + tensor '{tensor.get('name')}' ({tensor.get('dtype')}, shape={tensor.get('shape')})")

                pending_steps = _count_pending_steps(tensor, tensor_state)
                if pending_steps > 0:
                    for batch in _iter_pending_step_batches(resolved_data_dir, tensor, tensor_state):
                        pending_upload_entries.append(
                            {
                                "local_tensor_id": local_tensor_id,
                                "tensor_name": str(tensor.get("name") or ""),
                                "tensor_state": tensor_state,
                                "remote_tensor_id": tensor_state["remote_tensor_id"],
                                "pending_steps": pending_steps,
                                "batch": batch,
                                "group_meta": _batch_group_metadata(batch),
                            }
                        )
            except Exception as error:
                click.echo(f"  ⚠ tensor '{tensor.get('name')}': {error}")
                continue

        group_totals = {}
        for entry in pending_upload_entries:
            group_key = _step_group_key(entry["group_meta"])
            if group_key:
                group_totals[group_key] = group_totals.get(group_key, 0) + len(entry["batch"])

        tensor_progress = {}
        group_progress = {}
        failed_tensors = set()
        active_group_key = None
        for entry in pending_upload_entries:
            if entry["local_tensor_id"] in failed_tensors:
                continue

            group_key = _step_group_key(entry["group_meta"])
            if active_group_key is not None and active_group_key != group_key:
                click.echo("")
                active_group_key = None

            try:
                loaded_batch = _load_pending_step_batch(entry["batch"])
                uploaded_steps, uploaded_bytes = sync_client.upload_tensor_steps(entry["remote_tensor_id"], loaded_batch)
                entry["tensor_state"]["last_synced_step"] = max(
                    int(entry["tensor_state"].get("last_synced_step", -1)),
                    int(entry["batch"][-1]["step"]),
                )
                summary.step_batches_uploaded += 1
                summary.steps_uploaded += uploaded_steps
                summary.bytes_uploaded += uploaded_bytes
                state_dirty = True
                _save_sync_state(resolved_data_dir, sync_state)

                if group_key:
                    progress = group_progress.setdefault(group_key, {"uploaded": 0, "bytes": 0})
                    progress["uploaded"] += uploaded_steps
                    progress["bytes"] += uploaded_bytes
                    total_group_steps = group_totals.get(group_key, progress["uploaded"])
                    _print_group_progress(
                        entry["group_meta"],
                        progress["uploaded"],
                        total_group_steps,
                        progress["bytes"],
                        entry["tensor_name"],
                    )
                    if progress["uploaded"] >= total_group_steps:
                        active_group_key = None
                    else:
                        active_group_key = group_key
                else:
                    progress = tensor_progress.setdefault(
                        entry["local_tensor_id"],
                        {"uploaded": 0, "bytes": 0, "total": entry["pending_steps"]},
                    )
                    progress["uploaded"] += uploaded_steps
                    progress["bytes"] += uploaded_bytes
                    _print_progress(
                        entry["tensor_name"],
                        progress["uploaded"],
                        progress["total"],
                        progress["bytes"],
                        max_tensor_name_len,
                    )
            except Exception as error:
                click.echo(f"  ⚠ tensor '{entry['tensor_name']}': {error}")
                failed_tensors.add(entry["local_tensor_id"])
                active_group_key = None
                continue

        local_status = str(run.get("status") or "active")
        if local_status != str(run_state.get("last_synced_status") or "active"):
            sync_client.update_run_status(run_state["remote_run_id"], local_status)
            run_state["last_synced_status"] = local_status
            summary.statuses_updated += 1
            state_dirty = True
            _save_sync_state(resolved_data_dir, sync_state)

    if state_dirty:
        _save_sync_state(resolved_data_dir, sync_state)
    return summary


def _build_hosted_sync_client():
    api_base_url = auth.get_api_base_url(prefer_local=False)
    candidate_tokens = []

    env_token = os.getenv("GRADEXP_API_KEY")
    if env_token:
        candidate_tokens.append(env_token)

    saved_token = auth.load_saved_token()
    if saved_token and saved_token not in candidate_tokens:
        candidate_tokens.append(saved_token)

    if not candidate_tokens:
        raise click.ClickException("No hosted API key found. Run `gradexp login` to sync local data.")

    last_error = None
    for token in candidate_tokens:
        client = HostedSyncClient(token, api_base_url=api_base_url)
        try:
            return client, client.get_remote_user()
        except requests.exceptions.HTTPError as error:
            last_error = error
            if error.response is not None and error.response.status_code == 401:
                continue
            raise click.ClickException(f"Hosted sync failed: {error}") from error
        except requests.exceptions.RequestException as error:
            raise click.ClickException(f"Hosted sync failed: {error}") from error

    raise click.ClickException(
        "Hosted authentication failed. Run `gradexp login` to sync local data."
    ) from last_error


def get_local_sync_status(data_dir):
    resolved_data_dir = Path(data_dir).expanduser()
    summary = LocalSyncStatus(local_bytes=_measure_local_data_bytes(resolved_data_dir))

    try:
        local_store = _load_local_store(resolved_data_dir)
    except RuntimeError as error:
        summary.error = str(error)
        return summary

    if local_store is None:
        return summary

    summary.store_available = True
    sync_state = _load_sync_state(resolved_data_dir)
    best_run_state = _best_known_run_sync_state(sync_state)
    best_tensor_state = _best_known_tensor_sync_state(sync_state)

    for run in local_store.get("runs", []):
        if not isinstance(run, dict):
            continue

        run_id = str(run.get("runId") or "")
        if not run_id:
            continue

        summary.total_runs += 1
        run_state = best_run_state.get(run_id, {"has_remote_run": False})
        if not run_state["has_remote_run"]:
            summary.unsynced_runs += 1

    for tensor in local_store.get("tensors", []):
        if not isinstance(tensor, dict):
            continue

        tensor_id = str(tensor.get("tensorId") or "")
        if not tensor_id:
            continue

        steps = _sorted_tensor_steps(tensor.get("steps") or [])
        summary.total_tensors += 1
        summary.total_steps += len(steps)

        tensor_state = best_tensor_state.get(
            tensor_id,
            {"has_remote_tensor": False, "last_synced_step": -1},
        )
        pending_steps, pending_bytes = _measure_pending_tensor_data(
            resolved_data_dir,
            tensor_id,
            steps,
            int(tensor_state["last_synced_step"]),
        )

        if not tensor_state["has_remote_tensor"] or pending_steps:
            summary.unsynced_tensors += 1
            summary.unsynced_steps += pending_steps
            summary.unsynced_bytes += pending_bytes

    return summary


def _load_local_store(data_dir):
    state_path = Path(data_dir) / "store.json"
    if not state_path.exists():
        return None

    try:
        payload = json.loads(state_path.read_text())
    except json.JSONDecodeError as error:
        raise RuntimeError(f"Could not read local store from {state_path}: {error}") from error

    if not isinstance(payload, dict):
        raise RuntimeError(f"Local store at {state_path} is not a JSON object.")
    return payload


def _sync_state_path(data_dir):
    return Path(data_dir) / SYNC_STATE_FILENAME


def _load_sync_state(data_dir):
    state_path = _sync_state_path(data_dir)
    if not state_path.exists():
        return {"version": SYNC_STATE_VERSION, "accounts": {}}

    try:
        payload = json.loads(state_path.read_text())
    except json.JSONDecodeError:
        return {"version": SYNC_STATE_VERSION, "accounts": {}}

    if not isinstance(payload, dict):
        return {"version": SYNC_STATE_VERSION, "accounts": {}}
    payload.setdefault("version", SYNC_STATE_VERSION)
    payload.setdefault("accounts", {})
    if not isinstance(payload["accounts"], dict):
        payload["accounts"] = {}
    return payload


def _save_sync_state(data_dir, sync_state):
    state_path = _sync_state_path(data_dir)
    tmp_path = state_path.with_suffix(".tmp")
    tmp_path.write_text(json.dumps(sync_state, indent=2))
    tmp_path.replace(state_path)


def _get_account_state(sync_state, api_base_url, remote_user):
    remote_user_id = _remote_user_id(remote_user)
    account_key = f"{api_base_url}|{remote_user_id}"
    account_state = sync_state["accounts"].setdefault(
        account_key,
        {
            "remote_api_base_url": api_base_url,
            "remote_user_id": remote_user_id,
            "runs": {},
            "tensors": {},
        },
    )
    account_state.setdefault("runs", {})
    account_state.setdefault("tensors", {})
    return account_state


def _remote_user_id(remote_user):
    remote_user_id = remote_user.get("id") or remote_user.get("userId") or remote_user.get("username")
    if not remote_user_id:
        raise RuntimeError("Hosted sync could not determine the remote user ID.")
    return str(remote_user_id)


def _remote_user_label(remote_user):
    return str(remote_user.get("username") or remote_user.get("id") or "your hosted account")


def _count_pending_steps(tensor, tensor_state):
    last_synced_step = int(tensor_state.get("last_synced_step", -1))
    return sum(1 for step in (tensor.get("steps") or []) if int(step) > last_synced_step)


def _measure_local_data_bytes(data_dir):
    resolved_data_dir = Path(data_dir).expanduser()
    total_bytes = 0

    for filename in ("store.json", SYNC_STATE_FILENAME):
        file_path = resolved_data_dir / filename
        try:
            if file_path.is_file():
                total_bytes += file_path.stat().st_size
        except OSError:
            continue

    blobs_root = resolved_data_dir / "blobs"
    if not blobs_root.exists():
        return total_bytes

    for root, _, filenames in os.walk(blobs_root):
        for filename in filenames:
            try:
                total_bytes += (Path(root) / filename).stat().st_size
            except OSError:
                continue

    return total_bytes


def _best_known_tensor_sync_state(sync_state):
    best_state = {}
    accounts = sync_state.get("accounts") if isinstance(sync_state, dict) else {}
    if not isinstance(accounts, dict):
        return best_state

    for account_state in accounts.values():
        if not isinstance(account_state, dict):
            continue

        tensor_states = account_state.get("tensors")
        if not isinstance(tensor_states, dict):
            continue

        for tensor_id, tensor_state in tensor_states.items():
            if not isinstance(tensor_state, dict):
                continue

            best_entry = best_state.setdefault(
                str(tensor_id),
                {"has_remote_tensor": False, "last_synced_step": -1},
            )
            if tensor_state.get("remote_tensor_id"):
                best_entry["has_remote_tensor"] = True

            try:
                last_synced_step = int(tensor_state.get("last_synced_step", -1))
            except (TypeError, ValueError):
                last_synced_step = -1
            if last_synced_step > best_entry["last_synced_step"]:
                best_entry["last_synced_step"] = last_synced_step

    return best_state


def _best_known_run_sync_state(sync_state):
    best_state = {}
    accounts = sync_state.get("accounts") if isinstance(sync_state, dict) else {}
    if not isinstance(accounts, dict):
        return best_state

    for account_state in accounts.values():
        if not isinstance(account_state, dict):
            continue

        run_states = account_state.get("runs")
        if not isinstance(run_states, dict):
            continue

        for run_id, run_state in run_states.items():
            if not isinstance(run_state, dict):
                continue

            best_entry = best_state.setdefault(str(run_id), {"has_remote_run": False})
            if run_state.get("remote_run_id"):
                best_entry["has_remote_run"] = True

    return best_state


def _sorted_tensor_steps(steps):
    normalized_steps = []
    for step in steps:
        try:
            normalized_steps.append(int(step))
        except (TypeError, ValueError):
            continue
    return sorted(normalized_steps)


def _measure_pending_tensor_data(data_dir, tensor_id, steps, last_synced_step):
    pending_steps = 0
    pending_bytes = 0

    for step in steps:
        if step <= last_synced_step:
            continue

        pending_steps += 1
        step_path = Path(data_dir) / "blobs" / tensor_id / f"{step}.bin"
        try:
            pending_bytes += step_path.stat().st_size
        except OSError:
            continue

    return pending_steps, pending_bytes


def _normalize_step_group_metadata(step_metadata):
    if not isinstance(step_metadata, dict):
        return None

    kind = str(step_metadata.get("kind") or "").strip()
    group_id = str(step_metadata.get("group_id") or "").strip()
    if not kind or not group_id:
        return None

    normalized = {
        "kind": kind,
        "group_id": group_id,
    }
    try:
        normalized["step"] = int(step_metadata.get("step"))
    except (TypeError, ValueError):
        pass
    try:
        normalized["created_at_ns"] = int(step_metadata.get("created_at_ns"))
    except (TypeError, ValueError):
        pass
    return normalized


def _get_tensor_step_group_metadata(tensor, step):
    step_metadata = tensor.get("stepMetadata")
    if not isinstance(step_metadata, dict):
        return None
    return _normalize_step_group_metadata(step_metadata.get(str(int(step))))


def _step_group_key(step_metadata):
    if not step_metadata:
        return None
    return f"{step_metadata['kind']}:{step_metadata['group_id']}"


def _batch_group_metadata(batch):
    if not batch:
        return None
    return batch[0].get("local_step_metadata")


def _group_display_label(step_metadata):
    if not step_metadata:
        return "grouped upload"
    kind = str(step_metadata.get("kind") or "").strip()
    if kind == "gradient_stats":
        return "gradient stats"
    return kind.replace("_", " ")


def _load_pending_step_batch(batch):
    loaded_batch = []
    for item in batch:
        step_path = item["path"]
        try:
            value = step_path.read_bytes()
        except OSError as error:
            raise RuntimeError(f"Missing local tensor step payload: {step_path}") from error
        loaded_batch.append({"step": item["step"], "value": value})
    return loaded_batch


_BAR_COLOR = "\033[38;5;151m"
_DIM = "\033[2m"
_RESET = "\033[0m"

def _print_progress(tensor_name, uploaded, total, batch_bytes, name_width=0):
    pct = uploaded / total if total else 1
    bar_width = 20
    filled = int(bar_width * pct)
    bar = f"{_BAR_COLOR}{'█' * filled}{_DIM}{'░' * (bar_width - filled)}{_RESET}"
    padded_name = str(tensor_name or "").ljust(name_width)
    stats = f"{uploaded}/{total} steps ({human_bytes(batch_bytes)})"
    click.echo(f"\r    ↑ {padded_name}  {bar} {stats}", nl=(uploaded >= total))


def _print_group_progress(step_metadata, uploaded, total, batch_bytes, current_tensor_name):
    pct = uploaded / total if total else 1
    bar_width = 20
    filled = int(bar_width * pct)
    bar = f"{_BAR_COLOR}{'█' * filled}{_DIM}{'░' * (bar_width - filled)}{_RESET}"
    step_label = f"step {step_metadata['step']}" if step_metadata and "step" in step_metadata else "step ?"
    stats = f"{uploaded}/{total} tensors ({human_bytes(batch_bytes)})"
    current_tensor = f"  {_DIM}{current_tensor_name}{_RESET}" if current_tensor_name else ""
    click.echo(
        f"\r    ↑ {_group_display_label(step_metadata)} · {step_label}  {bar} {stats}{current_tensor}",
        nl=(uploaded >= total),
    )


def _iter_pending_step_batches(data_dir, tensor, tensor_state):
    tensor_id = str(tensor.get("tensorId") or "")
    if not tensor_id:
        return

    upload_config = _get_sync_upload_config()
    last_synced_step = int(tensor_state.get("last_synced_step", -1))
    sorted_steps = sorted(int(step) for step in (tensor.get("steps") or []))

    batch = []
    batch_wire_bytes = BATCH_JSON_PREFIX_BYTES + BATCH_JSON_SUFFIX_BYTES
    for step in sorted_steps:
        if step <= last_synced_step:
            continue

        step_path = Path(data_dir) / "blobs" / tensor_id / f"{step}.bin"
        if not step_path.exists():
            raise RuntimeError(f"Missing local tensor step payload: {step_path}")
        raw_size = step_path.stat().st_size
        step_metadata = _get_tensor_step_group_metadata(tensor, step)
        projected_wire_bytes = (
            batch_wire_bytes
            + estimate_batch_item_wire_bytes(step, raw_size)
            + (BATCH_JSON_ITEM_SEPARATOR_BYTES if batch else 0)
        )
        if batch and (
            len(batch) >= upload_config["batch_size"]
            or projected_wire_bytes > upload_config["max_batch_bytes"]
            or _step_group_key(_batch_group_metadata(batch)) != _step_group_key(step_metadata)
        ):
            yield batch
            batch = []
            batch_wire_bytes = BATCH_JSON_PREFIX_BYTES + BATCH_JSON_SUFFIX_BYTES
            projected_wire_bytes = batch_wire_bytes + estimate_batch_item_wire_bytes(step, raw_size)

        batch.append(
            {
                "step": step,
                "path": step_path,
                "size": raw_size,
                "local_step_metadata": step_metadata,
            }
        )
        batch_wire_bytes = projected_wire_bytes

    if batch:
        yield batch


def _report_sync_cycle(summary, data_dir, remote_user_label, is_watch):
    if not summary.store_available:
        if not is_watch:
            click.echo(f"No local data found in {data_dir}")
        return

    if summary.changed():
        parts = []
        if summary.runs_created:
            parts.append(f"{summary.runs_created} run{'s' if summary.runs_created != 1 else ''}")
        if summary.tensors_created:
            parts.append(f"{summary.tensors_created} tensor{'s' if summary.tensors_created != 1 else ''}")
        if summary.steps_uploaded:
            parts.append(f"{summary.steps_uploaded} step{'s' if summary.steps_uploaded != 1 else ''} ({human_bytes(summary.bytes_uploaded)})")
        if summary.statuses_updated:
            parts.append(f"{summary.statuses_updated} status update{'s' if summary.statuses_updated != 1 else ''}")
        click.echo(f"Sync complete for {remote_user_label}: {', '.join(parts)}.")
        return

    if not is_watch:
        click.echo(f"Local data in {data_dir} is already synced.")


def _clear_status_line():
    click.echo(f"\r{' ' * _STATUS_LINE_WIDTH}\r", nl=False)
