/**
 * GradExp Schema Definitions -- Documentation
 * 
 * Defines the data structures for the new GradExp API (Projects -> Runs -> Tensors -> Steps).
 * 
 * Endpoints:
 * - POST /api/v1/runs (Create Run, presumably handles Project creation/lookup)
 * - POST /api/v1/runs/{run_id}/tensors (Create Tensor)
 * - POST /api/v1/tensors/{tensor_id}/step (Log Tensor Value)
 */

/**
 * Payload for creating a run.
 * POST /api/v1/runs
 */
export interface CreateRunRequest {
    project_name: string;
    run_name: string;
}

export interface CreateRunResponse {
    run_id: string;
    project_id: string;
    name: string;
    status: 'active' | 'complete';
}

/**
 * Payload for creating a tensor.
 * POST /api/v1/runs/{run_id}/tensors
 */
export interface CreateTensorRequest {
    name: string;
    dtype: 'float32' | 'float16' | 'bfloat16';
    shape: number[];
    dimension_labels?: string[];
    tag?: string;
}

export interface CreateTensorResponse {
    tensor_id: string;
    run_id: string;
    name: string;
    dtype: 'float32' | 'float16' | 'bfloat16';
    shape: number[];
    dimension_labels?: string[];
    tag?: string;
}

/**
 * Payload for logging a step value.
 * POST /api/v1/tensors/{tensor_id}/step?step={step}
 * 
 * The body should be the raw binary data of the tensor.
 */
// export interface LogStepRequest { ... } (Removed as it's no longer JSON)


/**
 * Payload for updating run status.
 * PATCH /api/v1/runs/{run_id}
 */
export interface UpdateRunStatusRequest {
    status: 'complete' | 'stopped' | 'stalled';
}
