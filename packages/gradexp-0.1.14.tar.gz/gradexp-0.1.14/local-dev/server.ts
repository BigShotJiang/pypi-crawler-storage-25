import { randomUUID } from 'node:crypto';
import { createServer, IncomingMessage, ServerResponse } from 'node:http';
import {
  existsSync,
  mkdirSync,
  readFileSync,
  statSync,
  writeFileSync,
} from 'node:fs';
import { extname, resolve } from 'node:path';
import { gunzipSync } from 'node:zlib';

type RunStatus = 'active' | 'complete' | 'stopped' | 'stalled';

interface ServerOptions {
  appDir: string;
  dataDir: string;
  appPort: number;
  apiPort: number;
  localAuthToken: string;
  apiKey: string;
  validateOnly: boolean;
  apiOnly: boolean;
}

interface LocalUserRecord {
  userId: string;
  apiKey: string;
  createdAt: string;
}

interface ProjectRecord {
  projectId: string;
  userId: string;
  name: string;
  createdAt: string;
}

interface RunRecord {
  runId: string;
  projectId: string;
  name: string;
  status: RunStatus;
  createdAt: string;
  lastActivityAt: string;
}

interface TensorRecord {
  tensorId: string;
  runId: string;
  name: string;
  dtype: string;
  shape: number[];
  dimensionLabels: string[];
  tag?: string;
  createdAt: string;
  updatedAt: string;
  stepCount: number;
  minStep: number | null;
  maxStep: number | null;
  steps: number[];
}

interface LegacyDataRecord {
  id: number;
  userId: string;
  content: string;
  createdAt: string;
}

interface DemoLogRecord {
  id: string;
  createdAt: string;
  flops: number;
  bandwidth: number;
  fps: number;
  dimension: number;
  render_views: number;
  timestamp: string;
  hardware: Record<string, unknown>;
}

interface StoreState {
  version: number;
  user: LocalUserRecord;
  projects: ProjectRecord[];
  runs: RunRecord[];
  tensors: TensorRecord[];
  legacyData: LegacyDataRecord[];
  demoLogs: DemoLogRecord[];
}

interface HistogramBucket {
  min: number;
  max: number;
  count: number;
}

interface AggregateStats {
  min: number;
  max: number;
  avg: number;
  median: number;
  p10: number;
  p90: number;
}

const DEFAULT_USER_ID = 'local-user';
const DEFAULT_LOCAL_AUTH_TOKEN = 'gradexp-local-token';
const DEFAULT_LOCAL_API_KEY = 'gradexp-local-api-key';

function parseArgs(argv: string[]): ServerOptions {
  const options: ServerOptions = {
    appDir: '',
    dataDir: '',
    appPort: 3000,
    apiPort: 3001,
    localAuthToken: DEFAULT_LOCAL_AUTH_TOKEN,
    apiKey: DEFAULT_LOCAL_API_KEY,
    validateOnly: false,
    apiOnly: false,
  };

  for (let index = 0; index < argv.length; index += 1) {
    const argument = argv[index];
    const nextValue = argv[index + 1];

    if (!argument.startsWith('--')) {
      continue;
    }

    if (argument === '--validate-only') {
      options.validateOnly = true;
      continue;
    }

    if (argument === '--api-only') {
      options.apiOnly = true;
      continue;
    }

    if (!nextValue || nextValue.startsWith('--')) {
      throw new Error(`Missing value for ${argument}`);
    }

    switch (argument) {
      case '--app-dir':
        options.appDir = resolve(nextValue);
        break;
      case '--data-dir':
        options.dataDir = resolve(nextValue);
        break;
      case '--app-port':
        options.appPort = Number(nextValue);
        break;
      case '--api-port':
        options.apiPort = Number(nextValue);
        break;
      case '--local-auth-token':
        options.localAuthToken = nextValue;
        break;
      case '--api-key':
        options.apiKey = nextValue;
        break;
      default:
        throw new Error(`Unknown argument: ${argument}`);
    }

    index += 1;
  }

  if (!options.apiOnly && !options.appDir) {
    throw new Error('Missing --app-dir');
  }
  if (!options.dataDir) {
    throw new Error('Missing --data-dir');
  }
  if (!Number.isInteger(options.appPort) || options.appPort <= 0) {
    throw new Error(`Invalid app port: ${options.appPort}`);
  }
  if (!Number.isInteger(options.apiPort) || options.apiPort <= 0) {
    throw new Error(`Invalid api port: ${options.apiPort}`);
  }

  return options;
}

function ensureDirectory(directoryPath: string) {
  mkdirSync(directoryPath, { recursive: true });
}

function createInitialState(apiKey: string): StoreState {
  const createdAt = new Date().toISOString();
  return {
    version: 1,
    user: {
      userId: DEFAULT_USER_ID,
      apiKey,
      createdAt,
    },
    projects: [],
    runs: [],
    tensors: [],
    legacyData: [],
    demoLogs: [],
  };
}

function loadState(statePath: string, apiKey: string): StoreState {
  if (!existsSync(statePath)) {
    return createInitialState(apiKey);
  }

  const rawText = readFileSync(statePath, 'utf8');
  const parsed = JSON.parse(rawText) as Partial<StoreState>;
  const initialState = createInitialState(apiKey);

  return {
    ...initialState,
    ...parsed,
    user: {
      ...initialState.user,
      ...(parsed.user || {}),
      apiKey,
    },
    projects: Array.isArray(parsed.projects) ? parsed.projects : [],
    runs: Array.isArray(parsed.runs) ? parsed.runs : [],
    tensors: Array.isArray(parsed.tensors) ? parsed.tensors : [],
    legacyData: Array.isArray(parsed.legacyData) ? parsed.legacyData : [],
    demoLogs: Array.isArray(parsed.demoLogs) ? parsed.demoLogs : [],
  };
}

function toHttpDate(value?: string | null) {
  return value ? new Date(value).toUTCString() : undefined;
}

function parseIfModifiedSince(headerValue: string | undefined) {
  if (!headerValue) {
    return null;
  }
  const timestamp = Date.parse(headerValue);
  return Number.isNaN(timestamp) ? null : timestamp;
}

function maybeSendNotModified(
  request: IncomingMessage,
  response: ServerResponse,
  lastModified?: string | null,
) {
  if (!lastModified) {
    return false;
  }

  const clientTimestamp = parseIfModifiedSince(request.headers['if-modified-since']);
  if (clientTimestamp === null) {
    return false;
  }

  const serverTimestamp = Date.parse(lastModified);
  if (Number.isNaN(serverTimestamp)) {
    return false;
  }

  if (serverTimestamp <= clientTimestamp + 999) {
    setApiHeaders(response);
    response.writeHead(304, {
      'Last-Modified': toHttpDate(lastModified),
    });
    response.end();
    return true;
  }

  return false;
}

class LocalStore {
  private readonly statePath: string;

  private readonly blobsRoot: string;

  private state: StoreState;

  constructor(dataDir: string, apiKey: string) {
    ensureDirectory(dataDir);
    this.statePath = resolve(dataDir, 'store.json');
    this.blobsRoot = resolve(dataDir, 'blobs');
    ensureDirectory(this.blobsRoot);
    this.state = loadState(this.statePath, apiKey);
    this.persist();
  }

  private persist() {
    writeFileSync(this.statePath, JSON.stringify(this.state, null, 2));
  }

  private now() {
    return new Date().toISOString();
  }

  private getProject(projectId: string) {
    return this.state.projects.find((project) => project.projectId === projectId) || null;
  }

  private getRun(runId: string) {
    return this.state.runs.find((run) => run.runId === runId) || null;
  }

  private getTensor(tensorId: string) {
    return this.state.tensors.find((tensor) => tensor.tensorId === tensorId) || null;
  }

  private getProjectByName(projectName: string) {
    return this.state.projects.find((project) => project.name === projectName) || null;
  }

  private getTensorStepPath(tensorId: string, step: number) {
    return resolve(this.blobsRoot, tensorId, `${step}.bin`);
  }

  private updateTensorStats(tensor: TensorRecord, now: string) {
    const sortedSteps = [...tensor.steps].sort((left, right) => left - right);
    tensor.steps = sortedSteps;
    tensor.stepCount = sortedSteps.length;
    tensor.minStep = sortedSteps.length > 0 ? sortedSteps[0] : null;
    tensor.maxStep = sortedSteps.length > 0 ? sortedSteps[sortedSteps.length - 1] : null;
    tensor.updatedAt = now;
  }

  private writeTensorStepInternal(tensor: TensorRecord, step: number, value: Buffer, now: string) {
    const stepDirectory = resolve(this.blobsRoot, tensor.tensorId);
    ensureDirectory(stepDirectory);

    const wasAlreadyPresent = tensor.steps.includes(step);
    writeFileSync(this.getTensorStepPath(tensor.tensorId, step), value);

    if (!wasAlreadyPresent) {
      tensor.steps.push(step);
    }

    this.updateTensorStats(tensor, now);

    const run = this.getRun(tensor.runId);
    if (run) {
      run.lastActivityAt = now;
    }

    return !wasAlreadyPresent;
  }

  private getProjectLastModified(project: ProjectRecord) {
    const relatedRuns = this.state.runs.filter((run) => run.projectId === project.projectId);
    const timestamps = [project.createdAt, ...relatedRuns.map((run) => run.lastActivityAt || run.createdAt)];
    return timestamps.sort().slice(-1)[0] || project.createdAt;
  }

  private nextAvailableRunName(projectId: string, baseName: string) {
    const existingNames = new Set(
      this.state.runs
        .filter((run) => run.projectId === projectId)
        .map((run) => run.name),
    );

    if (!existingNames.has(baseName)) {
      return baseName;
    }

    let suffix = 2;
    while (existingNames.has(`${baseName}-${suffix}`)) {
      suffix += 1;
    }
    return `${baseName}-${suffix}`;
  }

  getUser() {
    return this.state.user;
  }

  getTableInfo() {
    return {
      message: "Table 'user_content' ready",
      tableName: 'user_content',
      tableExists: true,
      indexExists: true,
      columns: [
        { name: 'id', dataType: 'integer', isNullable: 'NO' },
        { name: 'user_id', dataType: 'text', isNullable: 'NO' },
        { name: 'content', dataType: 'text', isNullable: 'YES' },
        { name: 'created_at', dataType: 'timestamp with time zone', isNullable: 'YES' },
      ],
      userRowCount: this.state.legacyData.length,
      userId: this.state.user.userId,
    };
  }

  listLegacyData() {
    return [...this.state.legacyData].sort((left, right) => right.id - left.id);
  }

  createLegacyData(content: string) {
    const nextId = this.state.legacyData.reduce((maxId, item) => Math.max(maxId, item.id), 0) + 1;
    const record: LegacyDataRecord = {
      id: nextId,
      userId: this.state.user.userId,
      content,
      createdAt: this.now(),
    };
    this.state.legacyData.push(record);
    this.persist();
    return record;
  }

  listProjects() {
    const projects = [...this.state.projects]
      .sort((left, right) => right.createdAt.localeCompare(left.createdAt))
      .map((project) => ({
        project_id: project.projectId,
        name: project.name,
        created_at: project.createdAt,
        last_run_updated_at: this.getProjectLastModified(project),
      }));

    const activeRuns = [...this.state.runs]
      .filter((run) => run.status === 'active')
      .sort((left, right) => right.lastActivityAt.localeCompare(left.lastActivityAt))
      .map((run) => {
        const project = this.getProject(run.projectId);
        return {
          run_id: run.runId,
          project_id: run.projectId,
          project_name: project?.name || 'unknown',
          name: run.name,
          status: run.status,
          created_at: run.createdAt,
          updated_at: run.lastActivityAt,
        };
      });

    const lastModified = projects
      .map((project) => project.last_run_updated_at || project.created_at)
      .sort()
      .slice(-1)[0] || null;

    return {
      lastModified,
      payload: {
        projects,
        active_runs: activeRuns,
      },
    };
  }

  listRuns(projectName: string) {
    const project = this.getProjectByName(projectName);
    if (!project) {
      return {
        status: 404,
        payload: { error: `Project not found: ${projectName}` },
      };
    }

    const runs = [...this.state.runs]
      .filter((run) => run.projectId === project.projectId)
      .sort((left, right) => right.createdAt.localeCompare(left.createdAt))
      .map((run) => ({
        run_id: run.runId,
        project_id: run.projectId,
        name: run.name,
        status: run.status,
        created_at: run.createdAt,
        last_activity_at: run.lastActivityAt,
      }));

    const lastModified = runs
      .map((run) => run.last_activity_at || run.created_at)
      .sort()
      .slice(-1)[0] || null;

    return {
      status: 200,
      lastModified,
      payload: runs,
    };
  }

  listTensors(runId: string) {
    const run = this.getRun(runId);
    if (!run) {
      return {
        status: 404,
        payload: { error: `Run not found: ${runId}` },
      };
    }

    const tensors = [...this.state.tensors]
      .filter((tensor) => tensor.runId === runId)
      .sort((left, right) => left.createdAt.localeCompare(right.createdAt))
      .map((tensor) => ({
        tensor_id: tensor.tensorId,
        run_id: tensor.runId,
        name: tensor.name,
        dtype: tensor.dtype,
        shape: tensor.shape,
        dimension_labels: tensor.dimensionLabels,
        created_at: tensor.createdAt,
        updated_at: tensor.updatedAt,
        step_count: tensor.stepCount,
        min_step: tensor.minStep,
        max_step: tensor.maxStep,
      }));

    return {
      status: 200,
      lastModified: run.lastActivityAt || run.createdAt,
      payload: tensors,
    };
  }

  getStepValues(runId: string, step: number) {
    const run = this.getRun(runId);
    if (!run) {
      return {
        status: 404,
        payload: { error: `Run not found: ${runId}` },
      };
    }

    const values = this.state.tensors
      .filter((tensor) => tensor.runId === runId && tensor.steps.includes(step))
      .map((tensor) => ({
        name: tensor.name,
        dtype: tensor.dtype,
        shape: tensor.shape,
        value: readFileSync(this.getTensorStepPath(tensor.tensorId, step)).toString('base64'),
      }));

    return {
      status: 200,
      payload: values,
    };
  }

  getTensorValues(tensorId: string) {
    const tensor = this.getTensor(tensorId);
    if (!tensor) {
      return {
        status: 404,
        payload: { error: `Tensor not found: ${tensorId}` },
      };
    }

    const steps = [...tensor.steps]
      .sort((left, right) => left - right)
      .map((step) => ({
        step,
        value: readFileSync(this.getTensorStepPath(tensor.tensorId, step)).toString('base64'),
      }));

    return {
      status: 200,
      lastModified: tensor.updatedAt || tensor.createdAt,
      payload: steps,
    };
  }

  createRun(projectName: string, runName: string) {
    if (!projectName || !runName) {
      return {
        status: 400,
        payload: { error: 'project_name and run_name are required' },
      };
    }

    let project = this.getProjectByName(projectName);
    const now = this.now();

    if (!project) {
      project = {
        projectId: randomUUID(),
        userId: this.state.user.userId,
        name: projectName,
        createdAt: now,
      };
      this.state.projects.push(project);
    }

    const conflict = this.state.runs.find(
      (run) => run.projectId === project?.projectId && run.name === runName,
    );
    if (conflict) {
      return {
        status: 409,
        payload: {
          error: 'Run already exists in this project',
          suggested_name: this.nextAvailableRunName(project.projectId, runName),
        },
      };
    }

    const run: RunRecord = {
      runId: randomUUID(),
      projectId: project.projectId,
      name: runName,
      status: 'active',
      createdAt: now,
      lastActivityAt: now,
    };
    this.state.runs.push(run);
    this.persist();

    return {
      status: 201,
      payload: {
        project_id: project.projectId,
        run_id: run.runId,
      },
    };
  }

  updateRun(runId: string, update: { name?: string; status?: RunStatus }) {
    const run = this.getRun(runId);
    if (!run) {
      return {
        status: 404,
        payload: { error: `Run not found: ${runId}` },
      };
    }

    if (update.name) {
      run.name = update.name;
    }
    if (update.status) {
      run.status = update.status;
    }
    this.persist();

    return {
      status: 200,
      payload: { status: 'success' },
    };
  }

  createTensor(runId: string, input: { name: string; dtype: string; shape: number[]; dimension_labels?: string[]; tag?: string }) {
    const run = this.getRun(runId);
    if (!run) {
      return {
        status: 404,
        payload: { error: `Run not found: ${runId}` },
      };
    }

    if (!input.name || !input.dtype || !Array.isArray(input.shape)) {
      return {
        status: 400,
        payload: { error: 'name, dtype and shape are required' },
      };
    }

    const now = this.now();
    const tensor: TensorRecord = {
      tensorId: randomUUID(),
      runId,
      name: input.name,
      dtype: input.dtype,
      shape: input.shape.map((value) => Number(value)),
      dimensionLabels: Array.isArray(input.dimension_labels) ? input.dimension_labels : [],
      ...(input.tag ? { tag: input.tag } : {}),
      createdAt: now,
      updatedAt: now,
      stepCount: 0,
      minStep: null,
      maxStep: null,
      steps: [],
    };

    this.state.tensors.push(tensor);
    this.persist();

    return {
      status: 201,
      payload: { tensor_id: tensor.tensorId },
    };
  }

  logTensorStep(tensorId: string, step: number, value: Buffer) {
    const tensor = this.getTensor(tensorId);
    if (!tensor) {
      return {
        status: 404,
        payload: { error: `Tensor not found: ${tensorId}` },
      };
    }

    const inserted = this.writeTensorStepInternal(tensor, step, value, this.now());
    this.persist();

    return {
      status: 200,
      payload: { status: 'success', inserted },
    };
  }

  batchLogTensorSteps(tensorId: string, steps: Array<{ step: number; value: Buffer }>) {
    const tensor = this.getTensor(tensorId);
    if (!tensor) {
      return {
        status: 404,
        payload: { error: `Tensor not found: ${tensorId}` },
      };
    }

    const now = this.now();
    let inserted = 0;

    for (const item of steps) {
      if (this.writeTensorStepInternal(tensor, item.step, item.value, now)) {
        inserted += 1;
      }
    }

    this.persist();

    return {
      status: 200,
      payload: { inserted },
    };
  }

  logDemo(payload: Record<string, unknown>) {
    const demoLog: DemoLogRecord = {
      id: randomUUID(),
      createdAt: this.now(),
      flops: Number(payload.flops || 0),
      bandwidth: Number(payload.bandwidth || 0),
      fps: Number(payload.fps || 0),
      dimension: Number(payload.dimension || 0),
      render_views: Number(payload.render_views || 0),
      timestamp: String(payload.timestamp || ''),
      hardware: typeof payload.hardware === 'object' && payload.hardware !== null
        ? payload.hardware as Record<string, unknown>
        : {},
    };

    this.state.demoLogs.push(demoLog);
    this.persist();

    return {
      status: 201,
      payload: { status: 'success' },
    };
  }

  getHistogram(field: string, bucketCount: number, scale: 'linear' | 'log', userValue?: number) {
    const valueGetter = {
      flops: (entry: DemoLogRecord) => entry.flops,
      bandwidth: (entry: DemoLogRecord) => entry.bandwidth,
      fps: (entry: DemoLogRecord) => entry.fps,
      dimension: (entry: DemoLogRecord) => entry.dimension,
    }[field];

    if (!valueGetter) {
      return {
        status: 400,
        payload: { error: 'Invalid field. Use: flops, bandwidth, fps, dimension' },
      };
    }

    const values = this.state.demoLogs
      .map((entry) => valueGetter(entry))
      .filter((value) => Number.isFinite(value) && value > 0);

    if (values.length === 0) {
      return {
        status: 200,
        payload: {
          buckets: [],
          field,
          bucket_count: bucketCount,
          total: 0,
          stats: emptyStats(),
          scale,
        },
      };
    }

    const stats = calculateStats(values);
    const buckets = scale === 'log'
      ? buildLogHistogram(values, bucketCount)
      : buildLinearHistogram(values, bucketCount);
    const sortedValues = [...values].sort((left, right) => left - right);

    const userMarker = userValue && userValue > 0
      ? calculateUserMarker(userValue, buckets, sortedValues)
      : undefined;

    return {
      status: 200,
      payload: {
        buckets,
        field,
        bucket_count: bucketCount,
        total: values.length,
        stats,
        scale,
        user_marker: userMarker,
      },
    };
  }
}

function emptyStats(): AggregateStats {
  return {
    min: 0,
    max: 0,
    avg: 0,
    median: 0,
    p10: 0,
    p90: 0,
  };
}

function percentile(sortedValues: number[], proportion: number) {
  if (sortedValues.length === 0) {
    return 0;
  }
  if (sortedValues.length === 1) {
    return sortedValues[0];
  }

  const position = (sortedValues.length - 1) * proportion;
  const lowerIndex = Math.floor(position);
  const upperIndex = Math.ceil(position);
  const weight = position - lowerIndex;

  if (lowerIndex === upperIndex) {
    return sortedValues[lowerIndex];
  }

  return (
    sortedValues[lowerIndex]
    + (sortedValues[upperIndex] - sortedValues[lowerIndex]) * weight
  );
}

function calculateStats(values: number[]): AggregateStats {
  const sortedValues = [...values].sort((left, right) => left - right);
  const sum = sortedValues.reduce((accumulator, value) => accumulator + value, 0);
  return {
    min: sortedValues[0],
    max: sortedValues[sortedValues.length - 1],
    avg: sum / sortedValues.length,
    median: percentile(sortedValues, 0.5),
    p10: percentile(sortedValues, 0.1),
    p90: percentile(sortedValues, 0.9),
  };
}

function buildLinearHistogram(values: number[], bucketCount: number): HistogramBucket[] {
  const minValue = Math.min(...values);
  const maxValue = Math.max(...values);

  if (minValue === maxValue) {
    return Array.from({ length: bucketCount }, (_, index) => ({
      min: minValue,
      max: maxValue,
      count: index === 0 ? values.length : 0,
    }));
  }

  const bucketWidth = (maxValue - minValue) / bucketCount;
  const buckets = Array.from({ length: bucketCount }, (_, index) => ({
    min: minValue + bucketWidth * index,
    max: index === bucketCount - 1 ? maxValue : minValue + bucketWidth * (index + 1),
    count: 0,
  }));

  for (const value of values) {
    const bucketIndex = Math.min(
      bucketCount - 1,
      Math.floor((value - minValue) / bucketWidth),
    );
    buckets[bucketIndex].count += 1;
  }

  return buckets;
}

function buildLogHistogram(values: number[], bucketCount: number): HistogramBucket[] {
  const positiveValues = values.filter((value) => value > 0);
  const minValue = Math.min(...positiveValues);
  const maxValue = Math.max(...positiveValues);

  if (minValue === maxValue) {
    return Array.from({ length: bucketCount }, (_, index) => ({
      min: minValue,
      max: maxValue,
      count: index === 0 ? positiveValues.length : 0,
    }));
  }

  const logMin = Math.log10(minValue);
  const logMax = Math.log10(maxValue);
  const bucketWidth = (logMax - logMin) / bucketCount;

  const buckets = Array.from({ length: bucketCount }, (_, index) => ({
    min: Math.pow(10, logMin + bucketWidth * index),
    max: index === bucketCount - 1
      ? maxValue
      : Math.pow(10, logMin + bucketWidth * (index + 1)),
    count: 0,
  }));

  for (const value of positiveValues) {
    const bucketIndex = Math.min(
      bucketCount - 1,
      Math.floor((Math.log10(value) - logMin) / bucketWidth),
    );
    buckets[bucketIndex].count += 1;
  }

  return buckets;
}

function calculateUserMarker(value: number, buckets: HistogramBucket[], sortedValues: number[]) {
  const betterThan = sortedValues.filter((entry) => entry < value).length;
  const percentileValue = sortedValues.length === 0 ? 0 : (betterThan / sortedValues.length) * 100;

  let bucketIndex = buckets.findIndex((bucket, index) => {
    if (index === buckets.length - 1) {
      return value >= bucket.min && value <= bucket.max;
    }
    return value >= bucket.min && value < bucket.max;
  });

  if (bucketIndex === -1) {
    bucketIndex = value < buckets[0]?.min ? 0 : buckets.length - 1;
  }

  return {
    value,
    percentile: Math.round(percentileValue * 10) / 10,
    bucket: bucketIndex,
    message: `Better than ${Math.round(percentileValue * 10) / 10}% of local benchmark logs`,
  };
}

function setApiHeaders(response: ServerResponse) {
  response.setHeader('Access-Control-Allow-Origin', '*');
  response.setHeader('Access-Control-Allow-Headers', 'Authorization, Content-Type, If-Modified-Since');
  response.setHeader('Access-Control-Allow-Methods', 'GET, POST, PATCH, OPTIONS');
  response.setHeader('Access-Control-Expose-Headers', 'Content-Type, Last-Modified');
  response.setHeader('Content-Type', 'application/json; charset=utf-8');
}

function sendJson(
  response: ServerResponse,
  statusCode: number,
  payload: unknown,
  lastModified?: string | null,
) {
  setApiHeaders(response);

  const headers: Record<string, string> = {};
  const httpDate = toHttpDate(lastModified);
  if (httpDate) {
    headers['Last-Modified'] = httpDate;
  }

  response.writeHead(statusCode, headers);
  response.end(JSON.stringify(payload));
}

function sendError(response: ServerResponse, statusCode: number, message: string) {
  sendJson(response, statusCode, { error: message });
}

function getBearerToken(request: IncomingMessage) {
  const authorization = request.headers.authorization;
  if (!authorization) {
    return null;
  }

  const [scheme, token] = authorization.split(' ');
  if (scheme !== 'Bearer' || !token) {
    return null;
  }

  return token.trim();
}

function requireProtectedUser(request: IncomingMessage, response: ServerResponse) {
  const token = getBearerToken(request);
  if (!token) {
    sendError(response, 401, 'Missing Authorization header');
    return null;
  }
  return DEFAULT_USER_ID;
}

function requireApiKey(
  request: IncomingMessage,
  response: ServerResponse,
  options: ServerOptions,
  store: LocalStore,
) {
  const token = getBearerToken(request);
  if (!token) {
    sendError(response, 401, 'Missing Authorization header');
    return null;
  }

  const allowedTokens = new Set([
    options.apiKey,
    options.localAuthToken,
    store.getUser().apiKey,
  ]);
  if (!allowedTokens.has(token)) {
    sendError(response, 401, 'Invalid API Key');
    return null;
  }

  return DEFAULT_USER_ID;
}

async function readRequestBody(request: IncomingMessage) {
  const chunks: Buffer[] = [];
  for await (const chunk of request) {
    chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
  }

  let body = Buffer.concat(chunks);
  if (request.headers['content-encoding'] === 'gzip') {
    body = gunzipSync(body);
  }
  return body;
}

async function readJsonBody<T>(request: IncomingMessage, response: ServerResponse) {
  const body = await readRequestBody(request);
  try {
    return JSON.parse(body.toString('utf8')) as T;
  } catch (error) {
    console.error('Invalid JSON body:', error);
    sendError(response, 400, 'Invalid request body');
    return null;
  }
}

function getMimeType(filePath: string) {
  const mimeTypes: Record<string, string> = {
    '.css': 'text/css; charset=utf-8',
    '.html': 'text/html; charset=utf-8',
    '.ico': 'image/x-icon',
    '.js': 'text/javascript; charset=utf-8',
    '.json': 'application/json; charset=utf-8',
    '.svg': 'image/svg+xml',
    '.wasm': 'application/wasm',
    '.bin': 'application/octet-stream',
    '.map': 'application/json; charset=utf-8',
  };
  return mimeTypes[extname(filePath)] || 'application/octet-stream';
}

function serveStaticApp(appDir: string, request: IncomingMessage, response: ServerResponse) {
  const url = new URL(request.url || '/', 'http://127.0.0.1');
  const pathname = decodeURIComponent(url.pathname);

  const serveFile = (filePath: string) => {
    response.writeHead(200, {
      'Content-Type': getMimeType(filePath),
    });
    response.end(readFileSync(filePath));
  };

  const requestedPath = pathname === '/' ? '/index.html' : pathname;
  const resolvedPath = resolve(appDir, `.${requestedPath}`);

  if (
    resolvedPath === appDir
    || resolvedPath.startsWith(`${appDir}/`)
    || resolvedPath.startsWith(`${appDir}\\`)
  ) {
    if (existsSync(resolvedPath) && statSync(resolvedPath).isFile()) {
      serveFile(resolvedPath);
      return;
    }
  }

  if (requestedPath.includes('.')) {
    response.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    response.end(`Asset not found: ${requestedPath}`);
    return;
  }

  const indexPath = resolve(appDir, 'index.html');
  serveFile(indexPath);
}

async function handleApiRequest(
  request: IncomingMessage,
  response: ServerResponse,
  store: LocalStore,
  options: ServerOptions,
) {
  if (request.method === 'OPTIONS') {
    setApiHeaders(response);
    response.writeHead(204);
    response.end();
    return;
  }

  const url = new URL(request.url || '/', 'http://127.0.0.1');
  const pathname = url.pathname;
  const segments = pathname.split('/').filter(Boolean);

  if (pathname === '/version' && request.method === 'GET') {
    sendJson(response, 200, {
      version: 'local-dev',
      mode: 'local',
      data_dir: options.dataDir,
    });
    return;
  }

  if (segments[0] === 'demo') {
    if (segments.length === 1 && request.method === 'POST') {
      const payload = await readJsonBody<Record<string, unknown>>(request, response);
      if (!payload) {
        return;
      }
      const result = store.logDemo(payload);
      sendJson(response, result.status, result.payload);
      return;
    }

    if (segments.length === 2 && segments[1] === 'histogram' && request.method === 'GET') {
      const field = url.searchParams.get('field') || 'flops';
      const requestedBucketCount = Number(url.searchParams.get('buckets') || 20);
      const bucketCount = Number.isFinite(requestedBucketCount)
        ? Math.max(5, Math.min(100, requestedBucketCount))
        : 20;
      const scale = url.searchParams.get('scale') === 'log' ? 'log' : 'linear';
      const valueParam = url.searchParams.get('value');
      const userValue = valueParam ? Number(valueParam) : undefined;
      const result = store.getHistogram(field, bucketCount, scale, userValue);
      sendJson(response, result.status, result.payload);
      return;
    }
  }

  if (segments[0] === 'protected') {
    const userId = requireProtectedUser(request, response);
    if (!userId) {
      return;
    }

    if (segments.length === 1 && request.method === 'GET') {
      sendJson(response, 200, { message: 'Authenticated', userId });
      return;
    }

    if (segments[1] === 'get-or-create-table' && request.method === 'GET') {
      sendJson(response, 200, store.getTableInfo());
      return;
    }

    if (segments[1] === 'data' && request.method === 'GET') {
      sendJson(response, 200, store.listLegacyData());
      return;
    }

    if (segments[1] === 'data' && request.method === 'POST') {
      const payload = await readJsonBody<{ content?: string }>(request, response);
      if (!payload) {
        return;
      }
      const content = String(payload.content || '').trim();
      if (!content) {
        sendError(response, 400, 'Content cannot be empty.');
        return;
      }
      const record = store.createLegacyData(content);
      sendJson(response, 201, {
        id: record.id,
        message: 'Data saved successfully',
      });
      return;
    }

    if (segments[1] === 'api-key' && (request.method === 'GET' || request.method === 'POST')) {
      sendJson(response, request.method === 'GET' ? 200 : 201, {
        apiKey: store.getUser().apiKey,
      });
      return;
    }

    if (segments[1] === 'projects' && segments.length === 2 && request.method === 'GET') {
      const result = store.listProjects();
      if (maybeSendNotModified(request, response, result.lastModified)) {
        return;
      }
      sendJson(response, 200, result.payload, result.lastModified);
      return;
    }

    if (segments[1] === 'projects' && segments[3] === 'runs' && request.method === 'GET') {
      const projectName = decodeURIComponent(segments[2] || '');
      const result = store.listRuns(projectName);
      if (result.status === 200 && maybeSendNotModified(request, response, result.lastModified)) {
        return;
      }
      sendJson(response, result.status, result.payload, result.lastModified);
      return;
    }

    if (segments[1] === 'runs' && segments[3] === 'tensors' && request.method === 'GET') {
      const runId = segments[2];
      const result = store.listTensors(runId);
      if (result.status === 200 && maybeSendNotModified(request, response, result.lastModified)) {
        return;
      }
      sendJson(response, result.status, result.payload, result.lastModified);
      return;
    }

    if (segments[1] === 'runs' && segments[3] === 'steps' && request.method === 'GET') {
      const runId = segments[2];
      const step = Number(segments[4]);
      const result = store.getStepValues(runId, step);
      sendJson(response, result.status, result.payload);
      return;
    }

    if (segments[1] === 'tensors' && segments[3] === 'values' && request.method === 'GET') {
      const tensorId = segments[2];
      const result = store.getTensorValues(tensorId);
      if (result.status === 200 && maybeSendNotModified(request, response, result.lastModified)) {
        return;
      }
      sendJson(response, result.status, result.payload, result.lastModified);
      return;
    }
  }

  if (segments[0] === 'api' && segments[1] === 'v1') {
    const userId = requireApiKey(request, response, options, store);
    if (!userId) {
      return;
    }

    if (segments[2] === 'me' && request.method === 'GET') {
      sendJson(response, 200, { id: userId, username: `user_${userId}` });
      return;
    }

    if (segments[2] === 'runs' && segments.length === 3 && request.method === 'POST') {
      const payload = await readJsonBody<{ project_name?: string; run_name?: string }>(request, response);
      if (!payload) {
        return;
      }
      const result = store.createRun(
        String(payload.project_name || ''),
        String(payload.run_name || ''),
      );
      sendJson(response, result.status, result.payload);
      return;
    }

    if (segments[2] === 'runs' && segments.length === 4 && request.method === 'PATCH') {
      const payload = await readJsonBody<{ name?: string; status?: RunStatus }>(request, response);
      if (!payload) {
        return;
      }
      const result = store.updateRun(segments[3], payload);
      sendJson(response, result.status, result.payload);
      return;
    }

    if (segments[2] === 'runs' && segments[4] === 'tensors' && request.method === 'POST') {
      const payload = await readJsonBody<{
        name?: string;
        dtype?: string;
        shape?: number[];
        dimension_labels?: string[];
        tag?: string;
      }>(request, response);
      if (!payload) {
        return;
      }
      const result = store.createTensor(segments[3], {
        name: String(payload.name || ''),
        dtype: String(payload.dtype || ''),
        shape: Array.isArray(payload.shape) ? payload.shape.map((value) => Number(value)) : [],
        dimension_labels: Array.isArray(payload.dimension_labels) ? payload.dimension_labels : [],
        ...(payload.tag ? { tag: String(payload.tag) } : {}),
      });
      sendJson(response, result.status, result.payload);
      return;
    }

    if (segments[2] === 'tensors' && segments[4] === 'step' && request.method === 'POST') {
      const step = Number(url.searchParams.get('step'));
      if (!Number.isInteger(step)) {
        sendError(response, 400, 'Missing tensor_id or step');
        return;
      }
      const body = await readRequestBody(request);
      const result = store.logTensorStep(segments[3], step, body);
      sendJson(response, result.status, result.payload);
      return;
    }

    if (segments[2] === 'tensors' && segments[4] === 'steps' && request.method === 'POST') {
      const payload = await readJsonBody<{ steps?: Array<{ step?: number; value?: string }> }>(request, response);
      if (!payload) {
        return;
      }

      const steps = Array.isArray(payload.steps) ? payload.steps : [];
      if (steps.length === 0) {
        sendError(response, 400, 'No steps provided');
        return;
      }

      const decodedSteps = steps.map((item) => ({
        step: Number(item.step),
        value: Buffer.from(String(item.value || ''), 'base64'),
      }));
      const result = store.batchLogTensorSteps(segments[3], decodedSteps);
      sendJson(response, result.status, result.payload);
      return;
    }

    if (segments[2] === 'data-instances' && request.method === 'POST' && segments.length === 5) {
      const status = segments[4] as RunStatus;
      const result = store.updateRun(segments[3], { status });
      sendJson(response, result.status, result.payload);
      return;
    }
  }

  sendError(response, 404, `Route not found: ${pathname}`);
}

function main() {
  const options = parseArgs(process.argv.slice(2));

  if (!options.apiOnly && (!existsSync(options.appDir) || !statSync(options.appDir).isDirectory())) {
    throw new Error(`App directory does not exist: ${options.appDir}`);
  }

  const store = new LocalStore(options.dataDir, options.apiKey);

  if (options.validateOnly) {
    const targetDescription = options.apiOnly ? 'api-only mode' : options.appDir;
    console.log(`validated local server configuration for ${targetDescription}`);
    void store;
    return;
  }

  const apiServer = createServer((request, response) => {
    handleApiRequest(request, response, store, options).catch((error) => {
      console.error('API request failed:', error);
      sendError(response, 500, 'Internal server error');
    });
  });

  const appServer = options.apiOnly
    ? null
    : createServer((request, response) => {
        try {
          serveStaticApp(options.appDir, request, response);
        } catch (error) {
          console.error('Static request failed:', error);
          response.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' });
          response.end('Failed to serve application');
        }
      });

  apiServer.listen(options.apiPort, '127.0.0.1', () => {
    console.log(`local api listening on http://127.0.0.1:${options.apiPort}`);
  });

  if (appServer) {
    appServer.listen(options.appPort, '127.0.0.1', () => {
      console.log(`local app listening on http://127.0.0.1:${options.appPort}`);
    });
  } else {
    console.log('local app server disabled (--api-only)');
  }

  const shutdown = () => {
    apiServer.close();
    if (appServer) {
      appServer.close(() => {
        process.exit(0);
      });
      return;
    }
    process.exit(0);
  };

  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

main();
