# Rubkey - Rubika Bot API Library

> **Official Rubika Channel:** [@library_rubkey](https://rubika.ir/library_rubkey)

A simple and powerful Python library for creating Rubika bots.

## Source Code

For source code of the Rubkey library, visit the GitHub page:

[https://github.com/codetansarian/Source-code-of-the-Rubkey-library](https://github.com/codetansarian/Source-code-of-the-Rubkey-library)

## Features

- Send text messages with Chat Keypad and Inline Keypad
- Send polls
- Chat Keypad with button types: Simple, AskMyPhoneNumber, Textbox
- Inline Keypad with auto-updating data (counter, stats, etc.)
- Textbox button with SingleLine/MultiLine and String/Number keypad
- Admin system with ADMIN_ID and ADMIN_PASSWORD
- Admin-specific commands, buttons, and keypads
- Edit and delete messages
- Edit message with Inline Keypad update
- Edit and remove Chat Keypad
- Message handlers for commands, buttons, and all messages
- Session management with auto offset saving
- Contact receiving from users
- Built-in user counter (total_users, user_ids)

## Methods

- `send_message(chat_id, text, keypad=None, inline_keypad=None, reply_to=None)`  Send text message
- `edit_message(chat_id, message_id, text, inline_keypad=None)`  Edit message with optional Inline Keypad
- `delete_message(chat_id, message_id)`  Delete message
- `send_poll(chat_id, question, options)`  Send poll
- `get_chat(chat_id)`  Get chat information
- `get_me()`  Get bot information
- `remove_keypad(chat_id)`  Remove Chat Keypad
- `edit_chat_keypad(chat_id, keypad)`  Edit Chat Keypad
- `set_commands(commands)`  Set bot commands
- `delete_commands()`  Delete all commands
- `get_updates(limit=10)`  Get updates
- `poll_updates(limit=10, sleep=1)`  Continuous updates generator
- `run()`  Start bot polling

## Handlers

- `@bot.command("name")`  Handle specific command
- `@bot.on_message()`  Handle all messages
- `@bot.on_button("button_id")`  Handle button clicks (Chat Keypad)

## Admin System

- `bot.ADMIN_ID`  Set admin by sender_id or chat_id
- `bot.ADMIN_PASSWORD`  Set admin by password
- `@bot.admin_command("name")`  Admin-only command
- `@bot.admin_on_message()`  Handle all admin messages
- `@bot.admin_on_button("button_id")`  Handle admin button clicks

## Keypad Classes

- `Keypad(resize=True, one_time=False)`  Create Chat Keypad
- `KeyButton(button_id, text, button_type="Simple")`  Create Chat Keypad button
- `TextboxButton(button_id, text, type_line="SingleLine", type_keypad="String", place_holder="", title="")`  Create Textbox button
- `InlineKeypad()`  Create Inline Keypad
- `InlineButton(button_id, text, button_type="Simple")`  Create Inline Keypad button

## Message Object

- `msg.text`  Message text
- `msg.chat_id`  Chat ID
- `msg.message_id`  Message ID
- `msg.sender_id`  Sender ID
- `msg.button_id`  Clicked button ID
- `msg.contact`  Contact information
- `msg.reply(text, keypad=None, inline_keypad=None)`  Reply to message
- `msg.edit(text, inline_keypad=None)`  Edit message with optional Inline Keypad
- `msg.delete()`  Delete message"New text content")
```

Forward message

```python
from rubkey import Rubkey

bot = Rubkey("YOUR_BOT_TOKEN")
bot.forward_message("from_chat_id", "to_chat_id", "message_id")
```

Set bot commands

```python
from rubkey import Rubkey, BotCommand

bot = Rubkey("YOUR_BOT_TOKEN")

commands = [
    BotCommand("start", "Start the bot"),
    BotCommand("help", "Get help"),
    BotCommand("about", "About this bot")
]

bot.set_commands(commands)
```

Get updates manually

```python
from rubkey import Rubkey

bot = Rubkey("YOUR_BOT_TOKEN")

updates = bot.get_updates(limit=10)
for update in updates:
    if update.new_message:
        print(update.new_message.text)
```

Poll updates continuously

```python
from rubkey import Rubkey

bot = Rubkey("YOUR_BOT_TOKEN")

for update in bot.poll_updates(limit=10, sleep=1):
    if update.new_message:
        msg = update.new_message
        if msg.text == "/start":
            bot.send_message(update.chat_id, "Welcome!")
```

Advanced Examples

Button with selection list

```python
from rubkey import Rubkey, Button, InlineKeypad
from rubkey.enums import ButtonType, SelectionType, SelectionSearch, SelectionGet
from rubkey.keypad import ButtonSelectionItem

bot = Rubkey("YOUR_BOT_TOKEN")

items = [
    ButtonSelectionItem("Option 1"),
    ButtonSelectionItem("Option 2"),
    ButtonSelectionItem("Option 3")
]

button = Button("select_btn", "Choose Option", ButtonType.SELECTION)
button.set_selection(
    selection_id="menu_1",
    items=[item.to_dict() for item in items],
    search_type=SelectionSearch.LOCAL,
    get_type=SelectionGet.LOCAL,
    is_multi_selection=False,
    columns_count="1",
    title="Select an option"
)

keypad = InlineKeypad().add_row(button)
bot.send_message("chat_id", "Please select:", inline_keypad=keypad)
```

Button with calendar

```python
from rubkey import Rubkey, Button, InlineKeypad
from rubkey.enums import ButtonType, CalendarType

bot = Rubkey("YOUR_BOT_TOKEN")

button = Button("date_btn", "Select Date", ButtonType.CALENDAR)
button.set_calendar(
    title="Choose a date",
    default_value="1400-01-01",
    calendar_type=CalendarType.PERSIAN,
    min_year="1390",
    max_year="1410"
)

keypad = InlineKeypad().add_row(button)
bot.send_message("chat_id", "Select your birth date:", inline_keypad=keypad)
```

Button with number picker

```python
from rubkey import Rubkey, Button, InlineKeypad
from rubkey.enums import ButtonType

bot = Rubkey("YOUR_BOT_TOKEN")

button = Button("num_btn", "Select Quantity", ButtonType.NUMBER_PICKER)
button.set_number_picker(
    title="Choose quantity",
    min_value=1,
    max_value=100,
    default_value=10
)

keypad = InlineKeypad().add_row(button)
bot.send_message("chat_id", "How many items?", inline_keypad=keypad)
```

Button with textbox

```python
from rubkey import Rubkey, Button, InlineKeypad
from rubkey.enums import ButtonType, TextboxLineType, TextboxKeypadType

bot = Rubkey("YOUR_BOT_TOKEN")

button = Button("text_btn", "Write Message", ButtonType.TEXTBOX)
button.set_textbox(
    title="Enter your message",
    place_holder="Type here...",
    default_value="Hello",
    type_line=TextboxLineType.MULTI_LINE,
    type_keypad=TextboxKeypadType.STRING
)

keypad = InlineKeypad().add_row(button)
bot.send_message("chat_id", "Please write your message:", inline_keypad=keypad)
```

Button with location picker

```python
from rubkey import Rubkey, Button, InlineKeypad, Location
from rubkey.enums import ButtonType, LocationType

bot = Rubkey("YOUR_BOT_TOKEN")

default_location = Location({"latitude": "35.6892", "longitude": "51.3890"})

button = Button("loc_btn", "Select Location", ButtonType.LOCATION)
button.set_location(
    title="Pick a location",
    default_pointer_location=default_location,
    default_map_location=default_location,
    location_type=LocationType.PICKER
)

keypad = InlineKeypad().add_row(button)
bot.send_message("chat_id", "Please select your location:", inline_keypad=keypad)
```

Chat keypad (keyboard at bottom)

```python
from rubkey import Rubkey, Button, ChatKeypad
from rubkey.enums import ButtonType

bot = Rubkey("YOUR_BOT_TOKEN")

button1 = Button("btn1", "Option A", ButtonType.SIMPLE)
button2 = Button("btn2", "Option B", ButtonType.SIMPLE)
button3 = Button("btn3", "Option C", ButtonType.SIMPLE)

keypad = ChatKeypad(resize_keyboard=True, one_time_keyboard=False)
keypad.add_row(button1, button2).add_row(button3)

bot.send_message("chat_id", "Choose an option:", chat_keypad=keypad, chat_keypad_type="New")
```

Remove chat keypad

```python
from rubkey import Rubkey

bot = Rubkey("YOUR_BOT_TOKEN")
bot.remove_chat_keypad("chat_id")
```

API Reference

Rubkey Class

Method Description
get_me() Get bot information
get_updates(limit=10) Get new updates
poll_updates(limit=10, sleep=1) Generator for continuous polling
send_message() Send text message with optional keypad and metadata
send_poll() Send poll
send_location() Send location
send_contact() Send contact
send_file() Send file
request_send_file(file_type) Get upload URL for file
upload_file(upload_url, file_path) Upload file to server
get_file(file_id) Get file download URL
get_chat(chat_id) Get chat information
delete_message(chat_id, message_id) Delete message
edit_message_text(chat_id, message_id, text) Edit message text
edit_message_keypad(chat_id, message_id, inline_keypad) Edit message keypad
forward_message(from_chat_id, to_chat_id, message_id) Forward message
ban_chat_member(chat_id, user_id) Ban user from group
unban_chat_member(chat_id, user_id) Unban user from group
set_commands(commands) Set bot commands
edit_chat_keypad(chat_id, chat_keypad, chat_keypad_type) Edit chat keypad
remove_chat_keypad(chat_id) Remove chat keypad
update_bot_endpoints(url, endpoint_type) Update webhook endpoints

License

MIT License (c) 2026 taha ansarianpour