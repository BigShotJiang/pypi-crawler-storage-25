import requests
import json
import time
import threading
import os
from .types import Message

class Bot:
    def __init__(self, token, session_file=None):
        self.token = token
        self.api_url = f"https://botapi.rubika.ir/v3/{token}"
        self.handlers = {}
        self.button_handlers = {}
        self.default_handler = None
        self._running = False
        self.session_file = session_file
        self.offset = None
        self.ADMIN_ID = None
        self.ADMIN_PASSWORD = None
        self.admin_handlers = {}
        self.admin_button_handlers = {}
        self.admin_default_handler = None
        self.admin_verified = set()
        self.total_users = 0
        self.user_ids = set()
        if session_file:
            self.session_file = session_file if session_file.endswith('.rubkey') else f"{session_file}.rubkey"
            self._load_offset()
    def _api(self, method, data=None):
        if data is None:
            data = {}
        try:
            r = requests.post(f"{self.api_url}/{method}", json=data, timeout=30)
            if r.status_code == 200 and r.text.strip():
                return r.json()
        except Exception as e:
            print(f"API Error: {e}")
        return {}
    def _load_offset(self):
        if self.session_file and os.path.exists(self.session_file):
            try:
                with open(self.session_file, "r") as f:
                    data = f.read().strip()
                    self.offset = data if data else None
            except:
                pass
    def _save_offset(self):
        if self.session_file and self.offset:
            try:
                with open(self.session_file, "w") as f:
                    f.write(str(self.offset))
            except:
                pass
    def _is_admin(self, msg):
        if self.ADMIN_ID:
            if msg.sender_id == self.ADMIN_ID or msg.chat_id == self.ADMIN_ID:
                return True
        if self.ADMIN_PASSWORD:
            if msg.sender_id in self.admin_verified:
                return True
        return False
    def get_updates(self, limit=10):
        body = {"limit": limit}
        if self.offset:
            body["offset_id"] = self.offset
        result = self._api("getUpdates", body)
        data = result.get("data", result)
        if data.get("next_offset_id"):
            self.offset = data["next_offset_id"]
            self._save_offset()
        updates = []
        for update in data.get("updates", []):
            msg_data = update.get("new_message") or update.get("updated_message")
            if msg_data:
                msg_data["chat_id"] = update.get("chat_id", "")
                updates.append(Message(msg_data, bot=self))
        return updates
    def poll_updates(self, limit=10, sleep=1):
        print("Please wait...")
        if self.offset:
            while True:
                result = self._api("getUpdates", {"limit": 50, "offset_id": self.offset})
                data = result.get("data", result)
                updates = data.get("updates", [])
                if not updates:
                    break
                if data.get("next_offset_id"):
                    self.offset = data["next_offset_id"]
                else:
                    break
        else:
            result = self._api("getUpdates", {"limit": 1})
            data = result.get("data", result)
            if data.get("next_offset_id"):
                self.offset = data["next_offset_id"]
                while True:
                    result = self._api("getUpdates", {"limit": 50, "offset_id": self.offset})
                    data = result.get("data", result)
                    updates = data.get("updates", [])
                    if not updates:
                        break
                    if data.get("next_offset_id"):
                        self.offset = data["next_offset_id"]
                    else:
                        break
        self._save_offset()
        print("Rubkey bot run...")
        self._running = True
        while self._running:
            try:
                updates = self.get_updates(limit=limit)
                for update in updates:
                    threading.Thread(target=self._process_message, args=(update._data,), daemon=True).start()
                time.sleep(sleep)
            except KeyboardInterrupt:
                print("\nBot stopped.")
                break
            except Exception as e:
                print(f"Error: {e}")
                time.sleep(2)
    def send_message(self, chat_id, text, keypad=None, inline_keypad=None, reply_to=None):
        data = {"chat_id": chat_id, "text": text}
        if keypad:
            data["chat_keypad_type"] = "New"
            data["chat_keypad"] = keypad.to_dict()
        if inline_keypad:
            data["inline_keypad"] = inline_keypad.to_dict()
        if reply_to:
            data["reply_to_message_id"] = reply_to
        result = self._api("sendMessage", data)
        return result.get("data", result)
    def edit_message(self, chat_id, message_id, text, inline_keypad=None):
        data = {"chat_id": chat_id, "message_id": message_id, "text": text}
        if inline_keypad:
            data["inline_keypad"] = inline_keypad.to_dict()
        result = self._api("editMessageText", data)
        return result.get("data", result)
    def delete_message(self, chat_id, message_id):
        result = self._api("deleteMessage", {"chat_id": chat_id, "message_id": message_id})
        return result.get("data", result)
    def send_poll(self, chat_id, question, options):
        result = self._api("sendPoll", {"chat_id": chat_id, "question": question, "options": options})
        return result.get("data", result)
    def get_chat(self, chat_id):
        result = self._api("getChat", {"chat_id": chat_id})
        return result.get("data", result)
    def get_me(self):
        result = self._api("getMe", {})
        return result.get("data", result)
    def remove_keypad(self, chat_id):
        result = self._api("editChatKeypad", {"chat_id": chat_id, "chat_keypad_type": "Remove"})
        return result.get("data", result)
    def edit_chat_keypad(self, chat_id, keypad):
        result = self._api("editChatKeypad", {"chat_id": chat_id, "chat_keypad_type": "New", "chat_keypad": keypad.to_dict()})
        return result.get("data", result)
    def set_commands(self, commands):
        result = self._api("setCommands", {"bot_commands": commands})
        return result.get("data", result)
    def delete_commands(self):
        result = self._api("setCommands", {"bot_commands": []})
        return result.get("data", result)
    def command(self, name):
        def decorator(func):
            self.handlers[name] = func
            return func
        return decorator
    def on_message(self):
        def decorator(func):
            self.default_handler = func
            return func
        return decorator
    def on_button(self, button_id):
        def decorator(func):
            self.button_handlers[button_id] = func
            return func
        return decorator
    def admin_command(self, name):
        def decorator(func):
            self.admin_handlers[name] = func
            return func
        return decorator
    def admin_on_message(self):
        def decorator(func):
            self.admin_default_handler = func
            return func
        return decorator
    def admin_on_button(self, button_id):
        def decorator(func):
            self.admin_button_handlers[button_id] = func
            return func
        return decorator
    def _process_message(self, msg_data):
        msg = Message(msg_data, bot=self)
        text = (msg.text or "").strip()
        button_id = msg.button_id
        if text == "/start" and msg.sender_id not in self.user_ids:
            self.user_ids.add(msg.sender_id)
            self.total_users = len(self.user_ids)
        if self.ADMIN_PASSWORD and text == self.ADMIN_PASSWORD:
            self.admin_verified.add(msg.sender_id)
            return
        if self._is_admin(msg):
            if button_id and button_id in self.admin_button_handlers:
                self.admin_button_handlers[button_id](msg)
                return
            if text.startswith("/"):
                cmd = text[1:].split()[0]
                if cmd in self.admin_handlers:
                    self.admin_handlers[cmd](msg)
                    return
            if text in self.admin_handlers:
                self.admin_handlers[text](msg)
                return
            if self.admin_default_handler:
                self.admin_default_handler(msg)
                return
        if button_id and button_id in self.button_handlers:
            self.button_handlers[button_id](msg)
            return
        if text.startswith("/"):
            cmd = text[1:].split()[0]
            if cmd in self.handlers:
                self.handlers[cmd](msg)
                return
        if text in self.handlers:
            self.handlers[text](msg)
            return
        if self.default_handler:
            self.default_handler(msg)
    def run(self):
        self.poll_updates()