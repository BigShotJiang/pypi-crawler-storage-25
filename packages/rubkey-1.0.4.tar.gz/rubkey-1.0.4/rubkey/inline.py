class InlineKeypad:
    def __init__(self):
        self.rows = []
    def add_row(self, *buttons):
        self.rows.append(list(buttons))
        return self
    def to_dict(self):
        return {
            "rows": [{"buttons": [btn.to_dict() for btn in row]} for row in self.rows]
        }

class InlineButton:
    def __init__(self, button_id, text, button_type="Simple"):
        self.id = button_id
        self.text = text
        self.type = button_type
    def to_dict(self):
        return {"id": self.id, "type": self.type, "button_text": self.text}