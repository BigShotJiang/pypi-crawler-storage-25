"""Entry point for python -m aicippy."""

from aicippy.cli.main import app

if __name__ == "__main__":
    app()
