"""Agent status tracking for AiCippy."""

from __future__ import annotations

from dataclasses import dataclass, field

from aicippy.utils.logging import get_logger

logger = get_logger(__name__)


@dataclass(slots=True)
class AgentInfo:
    """Information about a single agent."""

    id: str
    type: str
    status: str
    progress: int
    message: str = ""


@dataclass(slots=True)
class StatusInfo:
    """Overall status information."""

    session_id: str | None = None
    connected: bool = False
    active_agents: int = 0
    total_tokens: int = 0
    agents: list[AgentInfo] = field(default_factory=list)


async def get_agent_status() -> StatusInfo:
    """Retrieve current agent status from the platform API.

    Returns local session state when the platform API is unreachable.
    """
    try:
        from aicippy.platform import get_platform_client

        client = get_platform_client()
        # Use validate_plan + get_credits as a connectivity / status check.
        subscription = await client.validate_plan()
        wallet = await client.get_credits()
        return StatusInfo(
            session_id=subscription.get("id"),
            connected=True,
            active_agents=0,
            total_tokens=0,
            agents=[],
        )
    except Exception as exc:
        logger.debug("agent_status_fallback_local", reason=str(exc))
        return StatusInfo()
