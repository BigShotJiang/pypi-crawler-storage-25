"""Universal AIGP Governance Client.

Implements RFC-010 AI Governance Protocol:
- REGISTER (heartbeat with use_case declaration)
- REQUEST (pre-invocation policy check)
- RECORD (post-invocation telemetry)

Handles: HMAC-SHA256 signing, decision caching, REPORT (fail-open) / ENFORCE (fail-closed).
"""

import asyncio
import hashlib
import hmac
import json
import logging
import time
from datetime import datetime, timezone
from typing import Optional

import httpx

logger = logging.getLogger(__name__)


class GovernanceDecision:
    """Result of a pre-invocation policy check."""

    def __init__(self, data: dict):
        self.allowed = data.get("decision") in ("ALLOW", "ALLOW_WITH_CONSTRAINTS")
        self.denied = data.get("decision") == "DENY"
        self.decision = data.get("decision", "ALLOW")
        self.request_id = data.get("request_id", "")
        self.constraints = data.get("constraints", {})
        self.budget_status = data.get("budget_status", {})
        self.ttl = data.get("ttl_seconds", 300)
        self.reason = data.get("reason", "")


class AigpClient:
    """Universal AIGP client — consent-based AI governance protocol.

    Args:
        gov_url: GOV_APP base URL (e.g. https://www.cyber-ai-gov.com)
        app_id: Application identifier registered with GOV_APP
        hmac_secret: HMAC-SHA256 shared secret for request signing
        enabled: Whether governance is active (False = all calls pass through)
        mode: REPORT (fail-open) or ENFORCE (fail-closed)
        use_cases: List of declared use cases (sent on heartbeat)
    """

    def __init__(self, gov_url: str, app_id: str, hmac_secret: str,
                 enabled: bool = True, mode: str = "REPORT",
                 use_cases: Optional[list[dict]] = None,
                 use_cases_file: Optional[str] = None):
        self._url = gov_url.rstrip("/")
        self._app_id = app_id
        self._secret = hmac_secret
        self._enabled = enabled
        self._mode = mode
        self._decision_cache: dict = {}
        self._http = httpx.AsyncClient(timeout=5.0)
        self._last_heartbeat: str = ""
        self._use_cases: list[dict] = use_cases or self._load_use_cases(use_cases_file)

    @staticmethod
    def _load_use_cases(path: Optional[str] = None) -> list[dict]:
        """Load use cases from JSON file. Searches common paths if not specified."""
        import os
        candidates = [path] if path else [
            "aigp-use-cases.json",
            "/app/aigp-use-cases.json",
            os.path.join(os.path.dirname(__file__), "..", "aigp-use-cases.json"),
        ]
        for f in candidates:
            if f and os.path.isfile(f):
                with open(f) as fh:
                    data = json.load(fh)
                    return data.get("use_cases", data) if isinstance(data, dict) else data
        return []

    @property
    def is_enforce(self) -> bool:
        """True if running in ENFORCE mode (fail-closed)."""
        return self._mode == "ENFORCE"

    @property
    def status(self) -> dict:
        """Current governance status for dashboards."""
        return {
            "enabled": self._enabled,
            "mode": self._mode,
            "url": self._url,
            "app_id": self._app_id,
            "last_heartbeat": self._last_heartbeat,
            "use_cases": self._use_cases,
            "cache_size": len(self._decision_cache),
        }

    async def start_heartbeat(self, interval_seconds: int = 3600):
        """Send heartbeat every interval. Run as asyncio background task."""
        while True:
            await self.heartbeat()
            await asyncio.sleep(interval_seconds)

    def _now(self) -> str:
        return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    def _sign(self, method: str, path: str, body: bytes) -> dict:
        """Compute HMAC-SHA256 signature per RFC-010 §4."""
        ts = self._now()
        body_hash = hashlib.sha256(body).hexdigest()
        message = f"{ts}\n{method}\n{path}\n{body_hash}"
        sig = hmac.new(self._secret.encode(), message.encode(), hashlib.sha256).hexdigest()
        return {
            "X-AIGP-Signature": f"hmac-sha256={sig}",
            "X-AIGP-Timestamp": ts,
            "X-AIGP-App-Id": self._app_id,
        }

    async def heartbeat(self):
        """REGISTER — send heartbeat with mode and declared use_cases."""
        if not self._enabled:
            return
        path = f"/api/v1/register/{self._app_id}"
        body = json.dumps({"mode": self._mode, "use_cases": self._use_cases}).encode()
        try:
            await self._http.post(
                f"{self._url}{path}", content=body,
                headers={**self._sign("POST", path, body), "Content-Type": "application/json"},
            )
            self._last_heartbeat = self._now()
        except Exception as e:
            logger.warning("AIGP heartbeat failed: %s", e)

    async def check(self, use_case: str, model_id: str,
                    estimated_tokens: int = 0, user_id: str = "",
                    data_classification: str = "MEDIUM") -> GovernanceDecision:
        """REQUEST — pre-invocation policy check.

        Returns ALLOW in REPORT mode if GOV_APP is unreachable.
        Returns DENY in ENFORCE mode if GOV_APP is unreachable.
        """
        if not self._enabled:
            return GovernanceDecision({"decision": "ALLOW"})

        cache_key = f"{use_case}:{model_id}"
        if cached := self._decision_cache.get(cache_key):
            if time.time() - cached["ts"] < cached["ttl"]:
                return cached["decision"]

        path = "/api/v1/request"
        body = json.dumps({
            "protocol_version": "1", "message_type": "REQUEST",
            "app_id": self._app_id, "request_id": f"req-{int(time.time()*1000)}",
            "use_case": use_case, "model_id": model_id,
            "user_id": user_id, "estimated_input_tokens": estimated_tokens,
            "data_classification": data_classification,
        }).encode()

        try:
            resp = await self._http.post(
                f"{self._url}{path}", content=body,
                headers={**self._sign("POST", path, body), "Content-Type": "application/json"},
            )
            decision = GovernanceDecision(resp.json())
            self._decision_cache[cache_key] = {"decision": decision, "ts": time.time(), "ttl": decision.ttl}
            return decision
        except Exception as e:
            logger.warning("AIGP check failed: %s (mode=%s)", e, self._mode)
            if self.is_enforce:
                return GovernanceDecision({"decision": "DENY", "reason": f"GOV_APP unreachable: {e}"})
            return GovernanceDecision({"decision": "ALLOW"})

    async def record(self, use_case: str, model_id: str,
                     input_tokens: int, output_tokens: int,
                     duration_ms: float, status: str = "SUCCESS",
                     user_id: str = "", request_id: str = "",
                     guardrail_applied: bool = False,
                     guardrail_intervention: bool = False,
                     system_prompt: str = "", prompt_arn: str = "",
                     output_ref: str = "") -> None:
        """RECORD — post-invocation telemetry. Fire-and-forget."""
        if not self._enabled:
            return

        path = "/api/v1/record"
        prompt_hash = hashlib.sha256(system_prompt.encode()).hexdigest() if system_prompt else ""
        body = json.dumps({
            "protocol_version": "1", "message_type": "RECORD",
            "app_id": self._app_id, "request_id": request_id,
            "use_case": use_case, "model_id": model_id,
            "user_id": user_id, "timestamp": self._now(),
            "duration_ms": int(duration_ms), "status": status,
            "tokens": {"input_tokens": input_tokens, "output_tokens": output_tokens,
                       "total_tokens": input_tokens + output_tokens},
            "guardrail": {"applied": guardrail_applied, "intervention": guardrail_intervention},
            "prompt_metadata": {
                "source": "bedrock_prompt_management" if prompt_arn else "built_in_fallback",
                "prompt_arn": prompt_arn, "system_prompt_hash": prompt_hash,
            },
            "output_ref": output_ref,
        }).encode()

        try:
            await self._http.post(
                f"{self._url}{path}", content=body,
                headers={**self._sign("POST", path, body), "Content-Type": "application/json"},
            )
        except Exception as e:
            logger.warning("AIGP record failed: %s", e)

    async def close(self):
        """Close the HTTP client."""
        await self._http.aclose()

    # ═══════════════════════════════════════════════════════════════════════
    # Prompt Policy — check if a prompt is approved for use
    # ═══════════════════════════════════════════════════════════════════════

    async def check_model_policy(self, model_id: str, use_case: str = "") -> dict:
        """Check if a model has an active policy for this use case.

        In ENFORCE mode, DENY blocks the invocation.
        """
        if not self._enabled:
            return {"decision": "ALLOW"}

        path = "/api/v1/prompt/model/check"
        body = json.dumps({
            "app_id": self._app_id,
            "model_id": model_id,
            "use_case": use_case,
        }).encode()

        try:
            resp = await self._http.post(
                f"{self._url}{path}", content=body,
                headers={**self._sign("POST", path, body), "Content-Type": "application/json"},
            )
            return resp.json()
        except Exception as e:
            logger.warning("AIGP check_model_policy failed: %s", e)
            if self.is_enforce:
                return {"decision": "DENY", "reason": f"Model policy check unreachable: {e}"}
            return {"decision": "ALLOW"}

    async def check_prompt(self, prompt_name: str, prompt_version: str = "",
                           prompt_hash: str = "", use_case: str = "",
                           model_id: str = "") -> dict:
        """Check if a prompt is approved. Returns decision dict.

        In ENFORCE mode, DENY blocks the invocation.
        In REPORT mode, logs but allows.
        """
        if not self._enabled:
            return {"decision": "ALLOW", "prompt_status": "UNCHECKED"}

        path = "/api/v1/prompt/check"
        body = json.dumps({
            "app_id": self._app_id,
            "prompt_ref": {
                "type": "bedrock",
                "identifier": prompt_name,
                "version": prompt_version,
                "hash": prompt_hash,
            },
            "use_case": use_case,
            "model_id": model_id,
        }).encode()

        try:
            resp = await self._http.post(
                f"{self._url}{path}", content=body,
                headers={**self._sign("POST", path, body), "Content-Type": "application/json"},
            )
            return resp.json()
        except Exception as e:
            logger.warning("AIGP check_prompt failed: %s", e)
            if self.is_enforce:
                return {"decision": "DENY", "reason": f"Prompt policy unreachable: {e}"}
            return {"decision": "ALLOW", "prompt_status": "UNCHECKED"}

    # ═══════════════════════════════════════════════════════════════════════
    # Provider Proxy — all AI calls go through here. No direct boto3.
    # ═══════════════════════════════════════════════════════════════════════

    def _get_bedrock(self, region: str = "us-east-1"):
        """Lazy-init bedrock-runtime client."""
        if not hasattr(self, "_bedrock_clients"):
            self._bedrock_clients = {}
        if region not in self._bedrock_clients:
            import boto3
            self._bedrock_clients[region] = boto3.client("bedrock-runtime", region_name=region)
        return self._bedrock_clients[region]

    def _get_bedrock_agent(self, region: str = "us-east-1"):
        """Lazy-init bedrock-agent-runtime client."""
        if not hasattr(self, "_agent_clients"):
            self._agent_clients = {}
        if region not in self._agent_clients:
            import boto3
            self._agent_clients[region] = boto3.client("bedrock-agent-runtime", region_name=region)
        return self._agent_clients[region]

    async def invoke(self, model_id: str, messages: list[dict],
                     system_prompt: str = "", use_case: str = "ai_invoke",
                     user_id: str = "", region: str = "us-east-1",
                     max_tokens: int = 4096, temperature: float = 0.7,
                     prompt_name: str = "", prompt_version: str = "") -> dict:
        """Invoke a model via Bedrock Converse API — with governance.

        Returns the full Converse response dict.
        """
        import asyncio as _aio
        import time as _time

        # 1. CHECK
        decision = await self.check(use_case, model_id, user_id=user_id)
        if decision.denied:
            raise ValueError(f"AIGP DENIED: {decision.reason}")

        # 1b. PROMPT POLICY CHECK (ENFORCE mode only)
        if self.is_enforce and system_prompt and prompt_name:
            prompt_decision = await self.check_prompt(
                prompt_name=prompt_name, prompt_version=prompt_version,
                prompt_hash=hashlib.sha256(system_prompt.encode()).hexdigest(),
                use_case=use_case, model_id=model_id,
            )
            if prompt_decision.get("decision") == "DENY":
                raise ValueError(f"AIGP PROMPT DENIED: {prompt_decision.get('reason', 'not approved')}")

        # 1c. MODEL POLICY CHECK (ENFORCE mode only)
        if self.is_enforce:
            model_decision = await self.check_model_policy(model_id, use_case=use_case)
            if model_decision.get("decision") == "DENY":
                raise ValueError(f"AIGP MODEL POLICY DENIED: {model_decision.get('reason', 'no active policy')}")

        # 2. INVOKE
        client = self._get_bedrock(region)
        kwargs = {"modelId": model_id, "messages": messages,
                  "inferenceConfig": {"maxTokens": max_tokens, "temperature": temperature}}
        if system_prompt:
            kwargs["system"] = [{"text": system_prompt}]
        # Apply guardrail from governance constraints
        if decision.constraints.get("guardrail_id"):
            kwargs["guardrailConfig"] = {
                "guardrailIdentifier": decision.constraints["guardrail_id"],
                "guardrailVersion": str(decision.constraints.get("guardrail_version", "DRAFT")),
            }

        start = _time.time()
        status = "SUCCESS"
        resp = {}
        try:
            resp = await _aio.to_thread(client.converse, **kwargs)
        except Exception:
            status = "ERROR"
            raise
        finally:
            duration_ms = (_time.time() - start) * 1000
            usage = resp.get("usage", {})
            # 3. RECORD
            await self.record(
                use_case=use_case, model_id=model_id,
                input_tokens=usage.get("inputTokens", 0),
                output_tokens=usage.get("outputTokens", 0),
                duration_ms=duration_ms, status=status,
                user_id=user_id, system_prompt=system_prompt,
            )
        return resp

    async def invoke_text(self, model_id: str, prompt: str,
                          system_prompt: str = "", use_case: str = "ai_invoke",
                          user_id: str = "", region: str = "us-east-1",
                          prompt_name: str = "", prompt_version: str = "") -> str:
        """Convenience: invoke and return just the text response."""
        messages = [{"role": "user", "content": [{"text": prompt}]}]
        resp = await self.invoke(model_id, messages, system_prompt=system_prompt,
                                 use_case=use_case, user_id=user_id, region=region,
                                 prompt_name=prompt_name, prompt_version=prompt_version)
        return resp.get("output", {}).get("message", {}).get("content", [{}])[0].get("text", "")

    async def retrieve(self, kb_id: str, query: str,
                       num_results: int = 5, use_case: str = "kb_retrieve",
                       user_id: str = "", region: str = "us-east-1") -> list[dict]:
        """Retrieve from a Bedrock Knowledge Base — with governance.

        Returns list of retrieval results.
        """
        import asyncio as _aio
        import time as _time

        decision = await self.check(use_case, f"kb:{kb_id}", user_id=user_id)
        if decision.denied:
            raise ValueError(f"AIGP DENIED: {decision.reason}")

        client = self._get_bedrock_agent(region)
        start = _time.time()
        status = "SUCCESS"
        results = []
        try:
            resp = await _aio.to_thread(
                client.retrieve,
                knowledgeBaseId=kb_id,
                retrievalQuery={"text": query},
                retrievalConfiguration={"vectorSearchConfiguration": {"numberOfResults": num_results}},
            )
            results = resp.get("retrievalResults", [])
        except Exception:
            status = "ERROR"
            raise
        finally:
            duration_ms = (_time.time() - start) * 1000
            await self.record(
                use_case=use_case, model_id=f"kb:{kb_id}",
                input_tokens=len(query) // 4, output_tokens=sum(len(r.get("content", {}).get("text", "")) for r in results) // 4,
                duration_ms=duration_ms, status=status, user_id=user_id,
            )
        return results

    async def retrieve_and_generate(self, kb_id: str, query: str, model_arn: str,
                                     use_case: str = "kb_rag",
                                     user_id: str = "", region: str = "us-east-1") -> str:
        """Retrieve & Generate (RAG) from a Bedrock KB — with governance.

        Returns the generated text response.
        """
        import asyncio as _aio
        import time as _time

        decision = await self.check(use_case, f"kb:{kb_id}", user_id=user_id)
        if decision.denied:
            raise ValueError(f"AIGP DENIED: {decision.reason}")

        client = self._get_bedrock_agent(region)
        start = _time.time()
        status = "SUCCESS"
        output_text = ""
        try:
            resp = await _aio.to_thread(
                client.retrieve_and_generate,
                input={"text": query},
                retrieveAndGenerateConfiguration={
                    "type": "KNOWLEDGE_BASE",
                    "knowledgeBaseConfiguration": {
                        "knowledgeBaseId": kb_id,
                        "modelArn": model_arn,
                    },
                },
            )
            output_text = resp.get("output", {}).get("text", "")
        except Exception:
            status = "ERROR"
            raise
        finally:
            duration_ms = (_time.time() - start) * 1000
            await self.record(
                use_case=use_case, model_id=model_arn.split("/")[-1] if "/" in model_arn else model_arn,
                input_tokens=len(query) // 4, output_tokens=len(output_text) // 4,
                duration_ms=duration_ms, status=status, user_id=user_id,
            )
        return output_text
