"""AIGP Client — Universal AI Governance Protocol client package.

Usage:
    from aigp_client import AigpClient

    client = AigpClient(gov_url="https://www.cyber-ai-gov.com",
                        app_id="MY_APP", hmac_secret="...", mode="REPORT")

    # Provider proxy — all AI calls go through here:
    text = await client.invoke_text("us.amazon.nova-pro-v1:0", "Hello", use_case="chat")
    results = await client.retrieve("CN7UAQYKMG", "HIPAA requirements", use_case="compliance")
    answer = await client.retrieve_and_generate(kb_id, query, model_arn, use_case="baseline")

    # Low-level (if needed):
    decision = await client.check("my_use_case", "model-id")
    await client.record("my_use_case", "model-id", input_tokens=100, output_tokens=50, duration_ms=1200)
"""

__version__ = "1.5.0"

from .client import AigpClient, GovernanceDecision

__all__ = ["AigpClient", "GovernanceDecision"]
