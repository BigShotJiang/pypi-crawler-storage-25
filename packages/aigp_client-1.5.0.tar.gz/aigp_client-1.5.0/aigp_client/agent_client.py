# Copyright (c) 2025-2026 Evan Erwee. All rights reserved.
# Licensed under the AIGP Proprietary License. See LICENSE.md.

"""AIGP Agentic Governance Client.

Extends the base AigpClient with agentic governance capabilities:
- TOOL_REQUEST (pre-tool-invocation authorization)
- Agent identity signing via X-AIGP-Agent-Id header
- Scope envelope caching

Implements protocol_version "1.1" messages per the Agentic Governance Extension.
"""

import json
import logging
import uuid
from typing import Optional

from .client import AigpClient, GovernanceDecision

logger = logging.getLogger(__name__)


class AigpAgentClient(AigpClient):
    """Extended AIGP client for agentic governance.

    Inherits all base protocol methods (heartbeat, check, record)
    and adds agentic governance methods.

    Args:
        gov_url: GOV_APP base URL (e.g. https://www.cyber-ai-gov.com)
        app_id: Application identifier registered with GOV_APP
        hmac_secret: HMAC-SHA256 shared secret for request signing
        agent_id: Unique agent identifier for this agent instance
        agent_private_key: Agent's proof-of-possession private key for identity signing
        enabled: Whether governance is active (False = all calls pass through)
        mode: REPORT (fail-open) or ENFORCE (fail-closed)
        use_cases: List of declared use cases (sent on heartbeat)
    """

    def __init__(self, gov_url: str, app_id: str, hmac_secret: str,
                 agent_id: str, agent_private_key: str,
                 enabled: bool = True, mode: str = "ENFORCE",
                 use_cases: Optional[list[dict]] = None):
        super().__init__(gov_url, app_id, hmac_secret, enabled, mode, use_cases)
        self._agent_id = agent_id
        self._agent_key = agent_private_key
        self._scope_envelope: Optional[dict] = None
        self._autonomy_budget: dict = {}
        self._plan_id: Optional[str] = None

    @property
    def scope_envelope(self) -> Optional[dict]:
        """Get the cached scope envelope for this agent."""
        return self._scope_envelope

    def set_scope_envelope(self, envelope: dict) -> None:
        """Cache a scope envelope for this agent.

        Args:
            envelope: The scope envelope dict issued by the Governance Authority.
        """
        self._scope_envelope = envelope

    def _build_agent_headers(self) -> dict:
        """Build standard AIGP headers with the additional X-AIGP-Agent-Id header.

        Returns:
            Dict containing Content-Type and X-AIGP-Agent-Id headers.
        """
        return {
            "Content-Type": "application/json",
            "X-AIGP-Agent-Id": self._agent_id,
        }

    async def tool_request(self, tool_id: str, tool_version: str,
                           input_params_hash: str,
                           plan_id: Optional[str] = None,
                           step_number: Optional[int] = None) -> dict:
        """TOOL_REQUEST — pre-tool-invocation authorization.

        Must be called before every tool invocation. The Governance Authority
        evaluates the request against the agent's Scope Envelope and returns
        ALLOW, ALLOW_WITH_CONSTRAINTS, or DENY.

        In ENFORCE mode, blocks if GOV_APP is unreachable (fail-closed).

        Args:
            tool_id: Identifier of the tool to invoke.
            tool_version: Version string of the tool.
            input_params_hash: SHA-256 hash of the tool's input parameters.
            plan_id: Optional plan identifier if executing within an approved plan.
            step_number: Optional step number within the execution plan.

        Returns:
            Response dict from the Governance Authority containing decision,
            request_id, constraints, and budget_remaining.
        """
        if not self._enabled:
            return {"decision": "ALLOW", "request_id": "", "constraints": {}, "budget_remaining": {}}

        request_id = f"treq-{uuid.uuid4().hex[:16]}"
        effective_plan_id = plan_id or self._plan_id

        # Build execution context
        execution_context: dict = {}
        if effective_plan_id:
            execution_context["plan_id"] = effective_plan_id
        if step_number is not None:
            execution_context["step_number"] = step_number

        # Build TOOL_REQUEST message body per design doc
        body_dict = {
            "protocol_version": "1.1",
            "message_type": "TOOL_REQUEST",
            "agent_id": self._agent_id,
            "app_id": self._app_id,
            "request_id": request_id,
            "scope_envelope_id": self._scope_envelope.get("scope_envelope_id") if self._scope_envelope else None,
            "tool_id": tool_id,
            "tool_version": tool_version,
            "tool_manifest_hash": "sha256:placeholder",
            "input_parameters_hash": input_params_hash,
            "execution_context": execution_context,
        }

        path = "/api/v1/agent/tool-request"
        body = json.dumps(body_dict).encode()

        # Build headers: HMAC signature + agent identity
        headers = {**self._sign("POST", path, body), **self._build_agent_headers()}

        try:
            resp = await self._http.post(
                f"{self._url}{path}", content=body, headers=headers,
            )
            result = resp.json()

            # Update autonomy budget from response
            if "budget_remaining" in result:
                self._autonomy_budget = result["budget_remaining"]

            return result
        except Exception as e:
            logger.warning("AIGP tool_request failed: %s (mode=%s)", e, self._mode)
            if self.is_enforce:
                return {
                    "decision": "DENY",
                    "request_id": request_id,
                    "reason": f"GOV_APP unreachable: {e}",
                    "constraints": {},
                    "budget_remaining": {},
                }
            return {
                "decision": "ALLOW",
                "request_id": request_id,
                "constraints": {},
                "budget_remaining": {},
            }

    async def plan_submit(self, steps: list[dict],
                          estimated_tokens: int = 0,
                          estimated_cost_usd: float = 0.0) -> dict:
        """PLAN_SUBMIT — submit execution plan for governance approval.

        Submits a multi-step execution plan to the Governance Authority for
        evaluation against the agent's Scope Envelope and configured Approval Gates.
        Returns APPROVED, APPROVED_WITH_MODIFICATIONS, or REJECTED.

        Args:
            steps: Ordered list of plan steps. Each step should contain
                step_number, action, tool_id/model_id, description,
                estimated_tokens, and reversible flag.
            estimated_tokens: Total estimated token consumption for the plan.
            estimated_cost_usd: Total estimated cost in USD for the plan.

        Returns:
            Response dict from the Governance Authority containing decision,
            plan_id, modifications (if any), and approval_expires_at.
        """
        if not self._enabled:
            return {"decision": "APPROVED", "plan_id": "", "modifications": []}

        plan_id = f"plan-{uuid.uuid4().hex[:16]}"
        self._plan_id = plan_id

        body_dict = {
            "protocol_version": "1.1",
            "message_type": "PLAN_SUBMIT",
            "agent_id": self._agent_id,
            "app_id": self._app_id,
            "plan_id": plan_id,
            "scope_envelope_id": self._scope_envelope.get("scope_envelope_id") if self._scope_envelope else None,
            "steps": steps,
            "estimated_total_tokens": estimated_tokens,
            "estimated_total_cost_usd": estimated_cost_usd,
        }

        path = "/api/v1/agent/plan-submit"
        body = json.dumps(body_dict).encode()
        headers = {**self._sign("POST", path, body), **self._build_agent_headers()}

        try:
            resp = await self._http.post(
                f"{self._url}{path}", content=body, headers=headers,
            )
            return resp.json()
        except Exception as e:
            logger.warning("AIGP plan_submit failed: %s (mode=%s)", e, self._mode)
            if self.is_enforce:
                return {
                    "decision": "DENY",
                    "plan_id": plan_id,
                    "reason": f"GOV_APP unreachable: {e}",
                    "modifications": [],
                }
            return {
                "decision": "APPROVED",
                "plan_id": plan_id,
                "modifications": [],
            }

    async def escalate(self, reason: str, action: dict,
                       timeout_seconds: int = 300,
                       timeout_action: str = "DENY") -> dict:
        """ESCALATE — request human-in-the-loop approval.

        Sent when an agent needs human approval for an action that exceeds
        its autonomy tier, or when its autonomy budget is depleted.
        Blocks until a human responds or the timeout is reached.

        Args:
            reason: Reason for escalation (e.g. "ACTION_REQUIRES_APPROVAL",
                "BUDGET_DEPLETED", "RISK_THRESHOLD_EXCEEDED").
            action: Dict describing the action requiring approval, including
                tool_id, description, and risk_level.
            timeout_seconds: Maximum time to wait for human response.
            timeout_action: Action to take on timeout ("DENY" or "ALLOW").

        Returns:
            Response dict from the Governance Authority containing
            escalation_id, decision, approved_by, and constraints.
        """
        if not self._enabled:
            return {"decision": "APPROVED", "escalation_id": "", "constraints": {}}

        escalation_id = f"esc-{uuid.uuid4().hex[:16]}"

        body_dict = {
            "protocol_version": "1.1",
            "message_type": "ESCALATE",
            "agent_id": self._agent_id,
            "app_id": self._app_id,
            "escalation_id": escalation_id,
            "reason": reason,
            "action": action,
            "context": {
                "plan_id": self._plan_id,
                "budget_remaining": self._autonomy_budget,
            },
            "timeout_seconds": timeout_seconds,
            "timeout_action": timeout_action,
        }

        path = "/api/v1/agent/escalate"
        body = json.dumps(body_dict).encode()
        headers = {**self._sign("POST", path, body), **self._build_agent_headers()}

        try:
            resp = await self._http.post(
                f"{self._url}{path}", content=body, headers=headers,
            )
            return resp.json()
        except Exception as e:
            logger.warning("AIGP escalate failed: %s (mode=%s)", e, self._mode)
            if self.is_enforce:
                return {
                    "decision": "DENY",
                    "escalation_id": escalation_id,
                    "reason": f"GOV_APP unreachable: {e}",
                    "constraints": {},
                }
            return {
                "decision": "APPROVED",
                "escalation_id": escalation_id,
                "constraints": {},
            }

    async def delegate(self, target_agent_id: str,
                       requested_scope: dict,
                       task_description: str) -> dict:
        """DELEGATE — delegate work to a sub-agent with narrowed scope.

        Requests the Governance Authority to issue a narrowed Scope Envelope
        for the target agent. The target's scope is computed as the intersection
        of this agent's scope and the requested scope (scope narrowing rule).

        Args:
            target_agent_id: Identifier of the agent to delegate to.
            requested_scope: Dict specifying the requested scope for the
                target agent (tools, models, max_actions, max_tokens, etc.).
            task_description: Human-readable description of the delegated task.

        Returns:
            Response dict from the Governance Authority containing decision,
            delegation_id, issued_scope_envelope_id, scope_envelope, and
            delegation_depth.
        """
        if not self._enabled:
            return {"decision": "ALLOW", "delegation_id": "", "scope_envelope": {}}

        delegation_id = f"del-{uuid.uuid4().hex[:16]}"

        # Build delegation chain from scope envelope or default to self
        delegation_chain = [self._agent_id]

        body_dict = {
            "protocol_version": "1.1",
            "message_type": "DELEGATE",
            "delegating_agent_id": self._agent_id,
            "target_agent_id": target_agent_id,
            "app_id": self._app_id,
            "delegation_id": delegation_id,
            "requested_scope": requested_scope,
            "delegation_chain": delegation_chain,
            "task_description": task_description,
        }

        path = "/api/v1/agent/delegate"
        body = json.dumps(body_dict).encode()
        headers = {**self._sign("POST", path, body), **self._build_agent_headers()}

        try:
            resp = await self._http.post(
                f"{self._url}{path}", content=body, headers=headers,
            )
            return resp.json()
        except Exception as e:
            logger.warning("AIGP delegate failed: %s (mode=%s)", e, self._mode)
            if self.is_enforce:
                return {
                    "decision": "DENY",
                    "delegation_id": delegation_id,
                    "reason": f"GOV_APP unreachable: {e}",
                    "scope_envelope": {},
                }
            return {
                "decision": "ALLOW",
                "delegation_id": delegation_id,
                "scope_envelope": {},
            }

    async def attest_input(self, segments: list[dict]) -> dict:
        """ATTEST_INPUT — submit input attestation for context window content.

        Submits attestation information for content segments entering the
        agent's context window. The Governance Authority evaluates each
        segment against the agent's Scope Envelope to verify the content
        source is authorized and the content has not been tampered with.

        Args:
            segments: List of content segments to attest. Each segment should
                contain source_type, source_id, content_hash, classification,
                and optionally attestation_signature.

        Returns:
            Response dict from the Governance Authority containing decisions
            (per-segment ALLOW/DENY), all_allowed flag, and attestation_id.
        """
        if not self._enabled:
            return {"decisions": [], "all_allowed": True, "attestation_id": ""}

        attestation_id = f"att-{uuid.uuid4().hex[:16]}"

        body_dict = {
            "protocol_version": "1.1",
            "message_type": "ATTEST_INPUT",
            "agent_id": self._agent_id,
            "app_id": self._app_id,
            "attestation_id": attestation_id,
            "scope_envelope_id": self._scope_envelope.get("scope_envelope_id") if self._scope_envelope else None,
            "segments": segments,
        }

        path = "/api/v1/agent/attest-input"
        body = json.dumps(body_dict).encode()
        headers = {**self._sign("POST", path, body), **self._build_agent_headers()}

        try:
            resp = await self._http.post(
                f"{self._url}{path}", content=body, headers=headers,
            )
            return resp.json()
        except Exception as e:
            logger.warning("AIGP attest_input failed: %s (mode=%s)", e, self._mode)
            if self.is_enforce:
                return {
                    "decisions": [],
                    "all_allowed": False,
                    "attestation_id": attestation_id,
                    "reason": f"GOV_APP unreachable: {e}",
                }
            return {
                "decisions": [],
                "all_allowed": True,
                "attestation_id": attestation_id,
            }

    async def memory_write(self, memory_scope: str, data_classification: str,
                           content_hash: str, retention_seconds: int,
                           purpose: str) -> dict:
        """MEMORY_WRITE — request permission to persist state.

        Sent when an agent writes to persistent memory. The Governance
        Authority evaluates the request against the agent's Memory_Scope
        policy and returns ALLOW or DENY.

        Args:
            memory_scope: The memory isolation scope (e.g. "AGENT_PRIVATE",
                "SHARED", "SESSION").
            data_classification: Classification level of the data being
                persisted (e.g. "LOW", "MEDIUM", "HIGH").
            content_hash: SHA-256 hash of the content to persist.
            retention_seconds: Requested retention duration in seconds.
            purpose: Human-readable description of why the data is being
                persisted.

        Returns:
            Response dict from the Governance Authority containing decision,
            memory_id, actual_retention_seconds, and storage_location.
        """
        if not self._enabled:
            return {
                "decision": "ALLOW",
                "memory_id": "",
                "actual_retention_seconds": retention_seconds,
                "storage_location": "governed",
            }

        memory_id = f"mem-{uuid.uuid4().hex[:16]}"

        body_dict = {
            "protocol_version": "1.1",
            "message_type": "MEMORY_WRITE",
            "agent_id": self._agent_id,
            "app_id": self._app_id,
            "memory_id": memory_id,
            "memory_scope": memory_scope,
            "data_classification": data_classification,
            "content_hash": content_hash,
            "retention_seconds": retention_seconds,
            "purpose": purpose,
        }

        path = "/api/v1/agent/memory-write"
        body = json.dumps(body_dict).encode()
        headers = {**self._sign("POST", path, body), **self._build_agent_headers()}

        try:
            resp = await self._http.post(
                f"{self._url}{path}", content=body, headers=headers,
            )
            return resp.json()
        except Exception as e:
            logger.warning("AIGP memory_write failed: %s (mode=%s)", e, self._mode)
            if self.is_enforce:
                return {
                    "decision": "DENY",
                    "memory_id": memory_id,
                    "reason": f"GOV_APP unreachable: {e}",
                }
            return {
                "decision": "ALLOW",
                "memory_id": memory_id,
                "actual_retention_seconds": retention_seconds,
                "storage_location": "governed",
            }

    async def step_complete(self, plan_id: str, step_number: int,
                            status: str, tokens_used: int = 0) -> dict:
        """STEP_COMPLETE — report step completion within an approved plan.

        Sent after each step in an approved execution plan completes,
        enabling the Governance Authority to track progress and revoke
        approval if conditions change.

        Args:
            plan_id: Identifier of the execution plan.
            step_number: The step number that completed.
            status: Completion status (e.g. "SUCCESS", "FAILED", "SKIPPED").
            tokens_used: Number of tokens consumed by this step.

        Returns:
            Response dict from the Governance Authority acknowledging
            the step completion.
        """
        if not self._enabled:
            return {"acknowledged": True, "plan_id": plan_id, "step_number": step_number}

        body_dict = {
            "protocol_version": "1.1",
            "message_type": "STEP_COMPLETE",
            "agent_id": self._agent_id,
            "app_id": self._app_id,
            "plan_id": plan_id,
            "step_number": step_number,
            "status": status,
            "tokens_used": tokens_used,
        }

        path = "/api/v1/agent/step-complete"
        body = json.dumps(body_dict).encode()
        headers = {**self._sign("POST", path, body), **self._build_agent_headers()}

        try:
            resp = await self._http.post(
                f"{self._url}{path}", content=body, headers=headers,
            )
            return resp.json()
        except Exception as e:
            logger.warning("AIGP step_complete failed: %s (mode=%s)", e, self._mode)
            if self.is_enforce:
                return {
                    "acknowledged": False,
                    "plan_id": plan_id,
                    "step_number": step_number,
                    "reason": f"GOV_APP unreachable: {e}",
                }
            return {
                "acknowledged": True,
                "plan_id": plan_id,
                "step_number": step_number,
            }
