# Copyright (c) 2025-2026 Evan Erwee. All rights reserved.
# Licensed under the AIGP Proprietary License. See LICENSE.md.

"""Tests for AigpAgentClient orchestration methods (plan_submit, escalate, delegate, step_complete)."""

import json
import pytest
import respx
import httpx

from aigp_client.agent_client import AigpAgentClient


@pytest.fixture
def client():
    """Create an AigpAgentClient instance for testing."""
    return AigpAgentClient(
        gov_url="https://gov.example.com",
        app_id="TEST_APP",
        hmac_secret="test-secret-key",
        agent_id="agent-test-001",
        agent_private_key="test-private-key",
        enabled=True,
        mode="ENFORCE",
    )


@pytest.fixture
def disabled_client():
    """Create a disabled AigpAgentClient instance."""
    return AigpAgentClient(
        gov_url="https://gov.example.com",
        app_id="TEST_APP",
        hmac_secret="test-secret-key",
        agent_id="agent-test-001",
        agent_private_key="test-private-key",
        enabled=False,
        mode="ENFORCE",
    )


@pytest.fixture
def report_client():
    """Create an AigpAgentClient in REPORT mode (fail-open)."""
    return AigpAgentClient(
        gov_url="https://gov.example.com",
        app_id="TEST_APP",
        hmac_secret="test-secret-key",
        agent_id="agent-test-001",
        agent_private_key="test-private-key",
        enabled=True,
        mode="REPORT",
    )


# --- plan_submit tests ---

class TestPlanSubmit:
    @pytest.mark.asyncio
    async def test_disabled_returns_passthrough(self, disabled_client):
        result = await disabled_client.plan_submit(steps=[{"step_number": 1}])
        assert result == {"decision": "APPROVED", "plan_id": "", "modifications": []}

    @respx.mock
    @pytest.mark.asyncio
    async def test_successful_plan_submit(self, client):
        response_data = {
            "decision": "APPROVED",
            "plan_id": "plan-abc123",
            "modifications": [],
            "approval_expires_at": "2026-06-01T01:00:00Z",
        }
        respx.post("https://gov.example.com/api/v1/agent/plan-submit").mock(
            return_value=httpx.Response(200, json=response_data)
        )

        steps = [
            {"step_number": 1, "action": "tool_invoke", "tool_id": "iam_create_user"},
            {"step_number": 2, "action": "tool_invoke", "tool_id": "iam_add_to_group"},
        ]
        result = await client.plan_submit(steps, estimated_tokens=2800, estimated_cost_usd=0.12)

        assert result["decision"] == "APPROVED"
        # Verify plan_id was stored
        assert client._plan_id is not None
        assert client._plan_id.startswith("plan-")

    @respx.mock
    @pytest.mark.asyncio
    async def test_plan_submit_sends_correct_body(self, client):
        client.set_scope_envelope({"scope_envelope_id": "scope-env-001"})
        respx.post("https://gov.example.com/api/v1/agent/plan-submit").mock(
            return_value=httpx.Response(200, json={"decision": "APPROVED"})
        )

        steps = [{"step_number": 1, "action": "tool_invoke", "tool_id": "test_tool"}]
        await client.plan_submit(steps, estimated_tokens=500, estimated_cost_usd=0.05)

        request = respx.calls.last.request
        body = json.loads(request.content)
        assert body["protocol_version"] == "1.1"
        assert body["message_type"] == "PLAN_SUBMIT"
        assert body["agent_id"] == "agent-test-001"
        assert body["app_id"] == "TEST_APP"
        assert body["plan_id"].startswith("plan-")
        assert body["scope_envelope_id"] == "scope-env-001"
        assert body["steps"] == steps
        assert body["estimated_total_tokens"] == 500
        assert body["estimated_total_cost_usd"] == 0.05

    @respx.mock
    @pytest.mark.asyncio
    async def test_plan_submit_enforce_mode_fail_closed(self, client):
        respx.post("https://gov.example.com/api/v1/agent/plan-submit").mock(
            side_effect=httpx.ConnectError("Connection refused")
        )

        result = await client.plan_submit(steps=[{"step_number": 1}])
        assert result["decision"] == "DENY"
        assert "GOV_APP unreachable" in result["reason"]

    @respx.mock
    @pytest.mark.asyncio
    async def test_plan_submit_report_mode_fail_open(self, report_client):
        respx.post("https://gov.example.com/api/v1/agent/plan-submit").mock(
            side_effect=httpx.ConnectError("Connection refused")
        )

        result = await report_client.plan_submit(steps=[{"step_number": 1}])
        assert result["decision"] == "APPROVED"


# --- escalate tests ---

class TestEscalate:
    @pytest.mark.asyncio
    async def test_disabled_returns_passthrough(self, disabled_client):
        result = await disabled_client.escalate(reason="TEST", action={})
        assert result == {"decision": "APPROVED", "escalation_id": "", "constraints": {}}

    @respx.mock
    @pytest.mark.asyncio
    async def test_successful_escalate(self, client):
        response_data = {
            "escalation_id": "esc-001",
            "decision": "APPROVED",
            "approved_by": "admin@example.com",
            "constraints": {"one_time_only": True},
        }
        respx.post("https://gov.example.com/api/v1/agent/escalate").mock(
            return_value=httpx.Response(200, json=response_data)
        )

        action = {"tool_id": "iam_remove_user", "description": "Remove user", "risk_level": "HIGH"}
        result = await client.escalate(
            reason="ACTION_REQUIRES_APPROVAL",
            action=action,
            timeout_seconds=300,
            timeout_action="DENY",
        )

        assert result["decision"] == "APPROVED"
        assert result["approved_by"] == "admin@example.com"

    @respx.mock
    @pytest.mark.asyncio
    async def test_escalate_sends_correct_body(self, client):
        client._plan_id = "plan-existing"
        client._autonomy_budget = {"actions": 12, "tokens": 45000}
        respx.post("https://gov.example.com/api/v1/agent/escalate").mock(
            return_value=httpx.Response(200, json={"decision": "APPROVED"})
        )

        action = {"tool_id": "iam_remove_user", "risk_level": "HIGH"}
        await client.escalate("BUDGET_DEPLETED", action, timeout_seconds=600, timeout_action="ALLOW")

        request = respx.calls.last.request
        body = json.loads(request.content)
        assert body["protocol_version"] == "1.1"
        assert body["message_type"] == "ESCALATE"
        assert body["agent_id"] == "agent-test-001"
        assert body["app_id"] == "TEST_APP"
        assert body["escalation_id"].startswith("esc-")
        assert body["reason"] == "BUDGET_DEPLETED"
        assert body["action"] == action
        assert body["context"]["plan_id"] == "plan-existing"
        assert body["context"]["budget_remaining"] == {"actions": 12, "tokens": 45000}
        assert body["timeout_seconds"] == 600
        assert body["timeout_action"] == "ALLOW"

    @respx.mock
    @pytest.mark.asyncio
    async def test_escalate_enforce_mode_fail_closed(self, client):
        respx.post("https://gov.example.com/api/v1/agent/escalate").mock(
            side_effect=httpx.ConnectError("Connection refused")
        )

        result = await client.escalate(reason="TEST", action={})
        assert result["decision"] == "DENY"
        assert "GOV_APP unreachable" in result["reason"]

    @respx.mock
    @pytest.mark.asyncio
    async def test_escalate_report_mode_fail_open(self, report_client):
        respx.post("https://gov.example.com/api/v1/agent/escalate").mock(
            side_effect=httpx.ConnectError("Connection refused")
        )

        result = await report_client.escalate(reason="TEST", action={})
        assert result["decision"] == "APPROVED"


# --- delegate tests ---

class TestDelegate:
    @pytest.mark.asyncio
    async def test_disabled_returns_passthrough(self, disabled_client):
        result = await disabled_client.delegate("agent-target", {}, "task")
        assert result == {"decision": "ALLOW", "delegation_id": "", "scope_envelope": {}}

    @respx.mock
    @pytest.mark.asyncio
    async def test_successful_delegate(self, client):
        response_data = {
            "decision": "ALLOW",
            "delegation_id": "del-001",
            "issued_scope_envelope_id": "scope-env-002",
            "scope_envelope": {"tools": {"mode": "allowlist", "allowed": ["iam_create_user"]}},
            "delegation_depth": 1,
        }
        respx.post("https://gov.example.com/api/v1/agent/delegate").mock(
            return_value=httpx.Response(200, json=response_data)
        )

        result = await client.delegate(
            target_agent_id="agent-executor-001",
            requested_scope={"tools": ["iam_create_user"], "max_actions": 10},
            task_description="Onboard new employee",
        )

        assert result["decision"] == "ALLOW"
        assert result["delegation_depth"] == 1

    @respx.mock
    @pytest.mark.asyncio
    async def test_delegate_sends_correct_body(self, client):
        respx.post("https://gov.example.com/api/v1/agent/delegate").mock(
            return_value=httpx.Response(200, json={"decision": "ALLOW"})
        )

        scope = {"tools": ["tool_a", "tool_b"], "max_tokens": 50000}
        await client.delegate("agent-target-001", scope, "Do the thing")

        request = respx.calls.last.request
        body = json.loads(request.content)
        assert body["protocol_version"] == "1.1"
        assert body["message_type"] == "DELEGATE"
        assert body["delegating_agent_id"] == "agent-test-001"
        assert body["target_agent_id"] == "agent-target-001"
        assert body["app_id"] == "TEST_APP"
        assert body["delegation_id"].startswith("del-")
        assert body["requested_scope"] == scope
        assert body["delegation_chain"] == ["agent-test-001"]
        assert body["task_description"] == "Do the thing"

    @respx.mock
    @pytest.mark.asyncio
    async def test_delegate_enforce_mode_fail_closed(self, client):
        respx.post("https://gov.example.com/api/v1/agent/delegate").mock(
            side_effect=httpx.ConnectError("Connection refused")
        )

        result = await client.delegate("agent-target", {}, "task")
        assert result["decision"] == "DENY"
        assert "GOV_APP unreachable" in result["reason"]

    @respx.mock
    @pytest.mark.asyncio
    async def test_delegate_report_mode_fail_open(self, report_client):
        respx.post("https://gov.example.com/api/v1/agent/delegate").mock(
            side_effect=httpx.ConnectError("Connection refused")
        )

        result = await report_client.delegate("agent-target", {}, "task")
        assert result["decision"] == "ALLOW"


# --- step_complete tests ---

class TestStepComplete:
    @pytest.mark.asyncio
    async def test_disabled_returns_passthrough(self, disabled_client):
        result = await disabled_client.step_complete("plan-123", 1, "SUCCESS")
        assert result == {"acknowledged": True, "plan_id": "plan-123", "step_number": 1}

    @respx.mock
    @pytest.mark.asyncio
    async def test_successful_step_complete(self, client):
        response_data = {"acknowledged": True, "plan_id": "plan-abc", "step_number": 2}
        respx.post("https://gov.example.com/api/v1/agent/step-complete").mock(
            return_value=httpx.Response(200, json=response_data)
        )

        result = await client.step_complete("plan-abc", 2, "SUCCESS", tokens_used=500)
        assert result["acknowledged"] is True

    @respx.mock
    @pytest.mark.asyncio
    async def test_step_complete_sends_correct_body(self, client):
        respx.post("https://gov.example.com/api/v1/agent/step-complete").mock(
            return_value=httpx.Response(200, json={"acknowledged": True})
        )

        await client.step_complete("plan-xyz", 3, "FAILED", tokens_used=1200)

        request = respx.calls.last.request
        body = json.loads(request.content)
        assert body["protocol_version"] == "1.1"
        assert body["message_type"] == "STEP_COMPLETE"
        assert body["agent_id"] == "agent-test-001"
        assert body["app_id"] == "TEST_APP"
        assert body["plan_id"] == "plan-xyz"
        assert body["step_number"] == 3
        assert body["status"] == "FAILED"
        assert body["tokens_used"] == 1200

    @respx.mock
    @pytest.mark.asyncio
    async def test_step_complete_enforce_mode_fail_closed(self, client):
        respx.post("https://gov.example.com/api/v1/agent/step-complete").mock(
            side_effect=httpx.ConnectError("Connection refused")
        )

        result = await client.step_complete("plan-123", 1, "SUCCESS")
        assert result["acknowledged"] is False
        assert "GOV_APP unreachable" in result["reason"]

    @respx.mock
    @pytest.mark.asyncio
    async def test_step_complete_report_mode_fail_open(self, report_client):
        respx.post("https://gov.example.com/api/v1/agent/step-complete").mock(
            side_effect=httpx.ConnectError("Connection refused")
        )

        result = await report_client.step_complete("plan-123", 1, "SUCCESS")
        assert result["acknowledged"] is True
