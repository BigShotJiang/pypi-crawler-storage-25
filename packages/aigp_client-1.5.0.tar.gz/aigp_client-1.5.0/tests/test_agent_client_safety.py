# Copyright (c) 2025-2026 Evan Erwee. All rights reserved.
# Licensed under the AIGP Proprietary License. See LICENSE.md.

"""Tests for AigpAgentClient safety methods (attest_input, memory_write)."""

import json
import pytest
import respx
import httpx

from aigp_client.agent_client import AigpAgentClient


@pytest.fixture
def client():
    """Create an AigpAgentClient instance for testing."""
    return AigpAgentClient(
        gov_url="https://gov.example.com",
        app_id="TEST_APP",
        hmac_secret="test-secret-key",
        agent_id="agent-test-001",
        agent_private_key="test-private-key",
        enabled=True,
        mode="ENFORCE",
    )


@pytest.fixture
def disabled_client():
    """Create a disabled AigpAgentClient instance."""
    return AigpAgentClient(
        gov_url="https://gov.example.com",
        app_id="TEST_APP",
        hmac_secret="test-secret-key",
        agent_id="agent-test-001",
        agent_private_key="test-private-key",
        enabled=False,
        mode="ENFORCE",
    )


@pytest.fixture
def report_client():
    """Create an AigpAgentClient in REPORT mode (fail-open)."""
    return AigpAgentClient(
        gov_url="https://gov.example.com",
        app_id="TEST_APP",
        hmac_secret="test-secret-key",
        agent_id="agent-test-001",
        agent_private_key="test-private-key",
        enabled=True,
        mode="REPORT",
    )


# --- attest_input tests ---

class TestAttestInput:
    @pytest.mark.asyncio
    async def test_disabled_returns_passthrough(self, disabled_client):
        result = await disabled_client.attest_input(segments=[])
        assert result == {"decisions": [], "all_allowed": True, "attestation_id": ""}

    @respx.mock
    @pytest.mark.asyncio
    async def test_successful_attest_input(self, client):
        response_data = {
            "decisions": [{"segment_index": 0, "decision": "ALLOW"}],
            "all_allowed": True,
            "attestation_id": "att-abc123",
        }
        respx.post("https://gov.example.com/api/v1/agent/attest-input").mock(
            return_value=httpx.Response(200, json=response_data)
        )

        segments = [
            {
                "source_type": "user",
                "source_id": "user-session-001",
                "content_hash": "sha256:abc123",
                "classification": "LOW",
            }
        ]
        result = await client.attest_input(segments)

        assert result["all_allowed"] is True
        assert len(result["decisions"]) == 1

    @respx.mock
    @pytest.mark.asyncio
    async def test_attest_input_sends_correct_body(self, client):
        client.set_scope_envelope({"scope_envelope_id": "scope-env-001"})
        respx.post("https://gov.example.com/api/v1/agent/attest-input").mock(
            return_value=httpx.Response(200, json={"decisions": [], "all_allowed": True})
        )

        segments = [
            {
                "source_type": "tool_response",
                "source_id": "tool-iam-001",
                "content_hash": "sha256:def456",
                "classification": "MEDIUM",
                "attestation_signature": "sig-xyz",
            }
        ]
        await client.attest_input(segments)

        request = respx.calls.last.request
        body = json.loads(request.content)
        assert body["protocol_version"] == "1.1"
        assert body["message_type"] == "ATTEST_INPUT"
        assert body["agent_id"] == "agent-test-001"
        assert body["app_id"] == "TEST_APP"
        assert body["attestation_id"].startswith("att-")
        assert body["scope_envelope_id"] == "scope-env-001"
        assert body["segments"] == segments

    @respx.mock
    @pytest.mark.asyncio
    async def test_attest_input_enforce_mode_fail_closed(self, client):
        respx.post("https://gov.example.com/api/v1/agent/attest-input").mock(
            side_effect=httpx.ConnectError("Connection refused")
        )

        result = await client.attest_input(segments=[])
        assert result["all_allowed"] is False
        assert result["attestation_id"].startswith("att-")
        assert "GOV_APP unreachable" in result["reason"]

    @respx.mock
    @pytest.mark.asyncio
    async def test_attest_input_report_mode_fail_open(self, report_client):
        respx.post("https://gov.example.com/api/v1/agent/attest-input").mock(
            side_effect=httpx.ConnectError("Connection refused")
        )

        result = await report_client.attest_input(segments=[])
        assert result["all_allowed"] is True
        assert result["attestation_id"].startswith("att-")
        assert "reason" not in result


# --- memory_write tests ---

class TestMemoryWrite:
    @pytest.mark.asyncio
    async def test_disabled_returns_passthrough(self, disabled_client):
        result = await disabled_client.memory_write(
            memory_scope="AGENT_PRIVATE",
            data_classification="LOW",
            content_hash="sha256:abc",
            retention_seconds=3600,
            purpose="Cache state",
        )
        assert result == {
            "decision": "ALLOW",
            "memory_id": "",
            "actual_retention_seconds": 3600,
            "storage_location": "governed",
        }

    @respx.mock
    @pytest.mark.asyncio
    async def test_successful_memory_write(self, client):
        response_data = {
            "decision": "ALLOW",
            "memory_id": "mem-001",
            "actual_retention_seconds": 86400,
            "storage_location": "governed",
        }
        respx.post("https://gov.example.com/api/v1/agent/memory-write").mock(
            return_value=httpx.Response(200, json=response_data)
        )

        result = await client.memory_write(
            memory_scope="AGENT_PRIVATE",
            data_classification="MEDIUM",
            content_hash="sha256:f7g8h9",
            retention_seconds=86400,
            purpose="Cache onboarding workflow state for retry",
        )

        assert result["decision"] == "ALLOW"
        assert result["actual_retention_seconds"] == 86400

    @respx.mock
    @pytest.mark.asyncio
    async def test_memory_write_sends_correct_body(self, client):
        respx.post("https://gov.example.com/api/v1/agent/memory-write").mock(
            return_value=httpx.Response(200, json={"decision": "ALLOW"})
        )

        await client.memory_write(
            memory_scope="SESSION",
            data_classification="HIGH",
            content_hash="sha256:xyz789",
            retention_seconds=7200,
            purpose="Store intermediate results",
        )

        request = respx.calls.last.request
        body = json.loads(request.content)
        assert body["protocol_version"] == "1.1"
        assert body["message_type"] == "MEMORY_WRITE"
        assert body["agent_id"] == "agent-test-001"
        assert body["app_id"] == "TEST_APP"
        assert body["memory_id"].startswith("mem-")
        assert body["memory_scope"] == "SESSION"
        assert body["data_classification"] == "HIGH"
        assert body["content_hash"] == "sha256:xyz789"
        assert body["retention_seconds"] == 7200
        assert body["purpose"] == "Store intermediate results"

    @respx.mock
    @pytest.mark.asyncio
    async def test_memory_write_enforce_mode_fail_closed(self, client):
        respx.post("https://gov.example.com/api/v1/agent/memory-write").mock(
            side_effect=httpx.ConnectError("Connection refused")
        )

        result = await client.memory_write(
            memory_scope="AGENT_PRIVATE",
            data_classification="LOW",
            content_hash="sha256:abc",
            retention_seconds=3600,
            purpose="Test",
        )
        assert result["decision"] == "DENY"
        assert result["memory_id"].startswith("mem-")
        assert "GOV_APP unreachable" in result["reason"]

    @respx.mock
    @pytest.mark.asyncio
    async def test_memory_write_report_mode_fail_open(self, report_client):
        respx.post("https://gov.example.com/api/v1/agent/memory-write").mock(
            side_effect=httpx.ConnectError("Connection refused")
        )

        result = await report_client.memory_write(
            memory_scope="AGENT_PRIVATE",
            data_classification="LOW",
            content_hash="sha256:abc",
            retention_seconds=3600,
            purpose="Test",
        )
        assert result["decision"] == "ALLOW"
        assert result["memory_id"].startswith("mem-")
        assert result["actual_retention_seconds"] == 3600
        assert result["storage_location"] == "governed"
