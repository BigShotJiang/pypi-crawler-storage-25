from django.test import TestCase, override_settings
from rest_framework.test import APIRequestFactory

from blog.views import SyncConfig


class SyncConfigTests(TestCase):
    def setUp(self):
        self.factory = APIRequestFactory()

    def test_sync_config_contains_compatibility_metadata(self):
        request = self.factory.get("/blog_api/sync_config/")
        response = SyncConfig.as_view()(request)

        self.assertEqual(response.status_code, 200)
        self.assertIn("api_contract_version", response.data)
        self.assertIn("supported_frontend_versions", response.data)

    @override_settings(
        TCB_BLOG_SETTINGS={
            "API_CONTRACT_VERSION": "2.0.0",
            "SUPPORTED_FRONTEND_VERSIONS": ">=0.30.0 <0.31.0",
        }
    )
    def test_sync_config_uses_configured_compatibility_metadata(self):
        request = self.factory.get("/blog_api/sync_config/")
        response = SyncConfig.as_view()(request)

        self.assertEqual(response.data["api_contract_version"], "2.0.0")
        self.assertEqual(
            response.data["supported_frontend_versions"], ">=0.30.0 <0.31.0"
        )
