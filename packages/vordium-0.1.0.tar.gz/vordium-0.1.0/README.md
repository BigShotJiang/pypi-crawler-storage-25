# Vordium Python SDK

The AI Layer for Crypto.

## Install

```bash
pip install vordium
```

## Quick Start

### Initialize your agent

```bash
vordium init
```

### Python

```python
from vordium import Agent

agent = Agent()
print(agent.address)
print(agent.balance)
```

### Run autonomously

```python
import asyncio
from vordium import Agent

agent = Agent()

async def strategy(agent):
    print(f"Block {agent.block} | {agent.balance} VORD")

asyncio.run(agent.run(strategy=strategy))
```

## CLI Commands

```
vordium init                 Create new agent wallet
vordium status               Check chain status
vordium balance              Check VORD balance
vordium fund                 Get testnet VORD
vordium send <to> <amount>   Send VORD
vordium run agent.py         Run agent script
vordium                      Interactive mode
```

## Network

| | |
|---|---|
| Chain ID | 713714 |
| RPC | https://rpc.vordium.com |
| Explorer | https://vordscan.io |
| Faucet | https://faucet.vordium.com |

## Links

- Docs: https://docs.vordium.com
- GitHub: https://github.com/vordium/vordium-py
