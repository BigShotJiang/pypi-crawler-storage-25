from setuptools import setup, find_packages
from pathlib import Path

readme = Path(__file__).parent / "README.md"
long_description = readme.read_text() if readme.exists() else ""

setup(
    name="vordium",
    version="0.1.0",
    author="Vordium",
    author_email="dev@vordium.com",
    description="Python SDK for AI agents on Vordium Chain - The AI Layer",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/vordium/vordium-py",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "web3>=6.0.0",
        "eth-account>=0.8.0",
        "requests>=2.28.0",
        "python-dotenv>=0.19.0",
    ],
    entry_points={
        "console_scripts": [
            "vordium=vordium.cli:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
