import argparse
from .agent import Agent
from .chain import Chain
from .config import CHAIN_ID, RPC_URL, EXPLORER_URL, CHAIN_NAME

BANNER = """
==========================================
         VORDIUM AGENT TERMINAL
        The AI Layer for Crypto
           docs.vordium.com
==========================================
"""


def main():
    parser = argparse.ArgumentParser(
        prog='vordium',
        description='Vordium Agent CLI - The AI Layer'
    )
    subparsers = parser.add_subparsers(dest='command')

    subparsers.add_parser('init', help='Create new agent wallet')
    subparsers.add_parser('status', help='Check chain status')
    subparsers.add_parser('fund', help='Get testnet VORD from faucet')

    bal = subparsers.add_parser('balance', help='Check VORD balance')
    bal.add_argument('address', nargs='?')

    send = subparsers.add_parser('send', help='Send VORD')
    send.add_argument('to')
    send.add_argument('amount', type=float)

    run = subparsers.add_parser('run', help='Run agent script')
    run.add_argument('script')

    args = parser.parse_args()
    print(BANNER)

    if args.command == 'init':
        cmd_init()
    elif args.command == 'status':
        cmd_status()
    elif args.command == 'fund':
        cmd_fund()
    elif args.command == 'balance':
        cmd_balance(args)
    elif args.command == 'send':
        cmd_send(args)
    elif args.command == 'run':
        cmd_run(args)
    else:
        cmd_interactive()


def cmd_init():
    print("Initializing new agent...\n")
    agent = Agent()
    print(f"\n{'='*50}")
    print(f"Address:     {agent.address}")
    print(f"Private Key: {agent.private_key}")
    print(f"{'='*50}")
    print("\nSave your private key to .env:")
    print(f"VORDIUM_PRIVATE_KEY={agent.private_key}\n")
    print("Getting testnet VORD...")
    agent.fund()
    print(f"Balance: {agent.balance} VORD")
    print(f"Explorer: {EXPLORER_URL}/address/{agent.address}")
    print("\nAgent ready to trade.")


def cmd_status():
    chain = Chain()
    status = 'Online' if chain.connected else 'Offline'
    print(f"Chain:     {CHAIN_NAME}")
    print(f"Chain ID:  {CHAIN_ID}")
    print(f"RPC:       {RPC_URL}")
    print(f"Block:     {chain.block_number:,}")
    print(f"Gas Price: {chain.gas_price:.2f} gwei")
    print(f"Status:    {status}")
    print(f"Explorer:  {EXPLORER_URL}")


def cmd_fund():
    agent = Agent()
    print(f"Requesting VORD for {agent.address}...")
    agent.fund()
    print(f"Balance: {agent.balance} VORD")


def cmd_balance(args):
    chain = Chain()
    addr = args.address if args.address else Agent().address
    print(f"Address: {addr}")
    print(f"Balance: {chain.get_balance(addr)} VORD")


def cmd_send(args):
    agent = Agent()
    print(f"Sending {args.amount} VORD to {args.to}...")
    agent.send(args.to, args.amount)


def cmd_run(args):
    print(f"Running {args.script}...\n")
    with open(args.script) as f:
        exec(f.read())


def cmd_interactive():
    chain = Chain()
    agent = Agent()
    print(f"Connected: {CHAIN_NAME}")
    print(f"Block:     {chain.block_number:,}")
    print(f"Address:   {agent.address}")
    print(f"Balance:   {agent.balance} VORD")
    print("\nCommands: status, balance, fund, send <to> <amount>, exit\n")

    while True:
        try:
            cmd = input("vordium> ").strip()
            if not cmd:
                continue
            if cmd == 'status':
                print(f"Block: {chain.block_number:,} | Gas: {chain.gas_price:.2f} gwei")
            elif cmd == 'balance':
                print(f"{agent.balance} VORD")
            elif cmd == 'fund':
                agent.fund()
            elif cmd.startswith('send '):
                parts = cmd.split()
                if len(parts) == 3:
                    agent.send(parts[1], float(parts[2]))
            elif cmd in ('exit', 'quit'):
                print("Goodbye.")
                break
            else:
                print("Commands: status, balance, fund, send <to> <amount>, exit")
        except KeyboardInterrupt:
            print("\nGoodbye.")
            break
        except Exception as e:
            print(f"Error: {e}")


if __name__ == '__main__':
    main()
