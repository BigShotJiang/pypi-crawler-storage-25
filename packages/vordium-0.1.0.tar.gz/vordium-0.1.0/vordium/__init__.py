"""
Vordium SDK — Python library for AI agents on Vordium Chain.

Usage:
    from vordium import Agent
    agent = Agent()
    print(agent.address)
    print(agent.balance)

Docs: https://docs.vordium.com
"""

from .agent import Agent
from .wallet import Wallet
from .chain import Chain

__version__ = "0.1.0"
__author__ = "Vordium"
__all__ = ["Agent", "Wallet", "Chain"]
