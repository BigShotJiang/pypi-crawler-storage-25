from web3 import Web3
from .config import RPC_URL, EXPLORER_URL


class Chain:
    def __init__(self):
        self._w3 = Web3(Web3.HTTPProvider(RPC_URL))

    @property
    def connected(self) -> bool:
        return self._w3.is_connected()

    @property
    def block_number(self) -> int:
        return self._w3.eth.block_number

    @property
    def gas_price(self) -> float:
        return float(self._w3.from_wei(self._w3.eth.gas_price, 'gwei'))

    def get_balance(self, address: str) -> float:
        raw = self._w3.eth.get_balance(Web3.to_checksum_address(address))
        return float(self._w3.from_wei(raw, 'ether'))

    def get_transaction(self, tx_hash: str):
        return self._w3.eth.get_transaction(tx_hash)

    def get_block(self, number: int = None):
        if number is None:
            return self._w3.eth.get_block('latest')
        return self._w3.eth.get_block(number)

    def explorer_url(self, tx_hash: str) -> str:
        return f"{EXPLORER_URL}/tx/{tx_hash}"

    def __repr__(self):
        return f"Chain(block={self.block_number}, connected={self.connected})"
