# Mimir — The Ultimate Memory Architecture
# Copyright (c) 2026 Kronic90. All rights reserved.
# Licensed under PolyForm Noncommercial 1.0.0
# https://polyformproject.org/licenses/noncommercial/1.0.0/

"""VividMimir — install via ``pip install vividmimir``."""

__version__ = "1.0.2"

from .mimir import (          # noqa: F401  — public re-exports
    Mimir,
    Memory,
    Lesson,
    Attempt,
    Reminder,
    ShortTermFact,
    TaskRecord,
    ActionRecord,
    SolutionPattern,
    ArtifactRecord,
    EMOTION_VECTORS,
)
