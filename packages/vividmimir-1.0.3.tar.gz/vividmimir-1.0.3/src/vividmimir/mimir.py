# Mimir — The Ultimate Memory Architecture
# Copyright (c) 2026 Kronic90. All rights reserved.
# Licensed under PolyForm Noncommercial 1.0.0
# https://polyformproject.org/licenses/noncommercial/1.0.0/
# Free for personal and research use. Commercial use requires a separate license.

"""Mimir — The Ultimate Memory Architecture

Orchestrates VividnessMem's neurochemistry engine and VividEmbed's semantic
retrieval layer, then adds sixteen neuroscience mechanisms on top:

    1. Flashbulb Memory           (Brown & Kulik 1977)
    2. Reconsolidation            (Nader et al 2000)
    3. State-Dependent Memory     (Godden & Baddeley 1975)
    4. Spreading Activation       (Collins & Loftus 1975)
    5. Retrieval-Induced Forgetting (Anderson 1994)
    6. Zeigarnik Effect           (Zeigarnik 1927)
    7. Involuntary Recall         (Berntsen 2009)
    8. Temporal Gist              (Reyna & Brainerd 1995)
    9. Temporal / Episodic        (Tulving 1972)
   10. Visual / Mental Imagery    (Kosslyn 1980 / Paivio 1986)
   11. Huginn (Thought)           — pattern detection
   12. Muninn (Memory)            — consolidation daemon
   13. Yggdrasil (World Tree)     — memory graph
   14. Völva's Vision             — dream synthesis
   15. Novelty-Modulated Encoding (Ranganath & Rainer 2003)
   16. Enhanced Drift Analysis    — cognitive bias detection

Additional systems:
    - Hippocampal Pattern Separation — distinctiveness via importance nudge
    - Narrative Arc Tracking — setup→climax→resolution arc positions
    - Task / Project Branch  — projects, tasks, actions, solutions, artifacts
    - Optional LLM Integration — query decomposition, agentic ops, reflection
    - Visualization toolkit  — lazy matplotlib charts (VividViz bridge)
    - Encryption at rest     — Fernet + PBKDF2 for JSON files

Migration (import from VividnessMem / Lela):
    Mimir.migrate_from_vividnessmem("lela_data", "mimir_data")

Installation (engines are optional but recommended):
    pip install vividnessmem vividembed

Usage:
    from Mimir import Mimir
    m = Mimir(data_dir="my_mind")
    mem = m.remember("A thought worth keeping", "curious", 7)
"""

from __future__ import annotations

import base64
import hashlib
import json
import math
import os
import random
import re
import uuid
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Callable

# ── Engine imports (pip first → local fallback → None) ────────────────────

_NeuroChemistry = None
try:
    from vividnessmem.vividnessmem import NeuroChemistry as _NeuroChemistry
except ImportError:
    try:
        import sys as _sys
        _sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        from VividnessMem import NeuroChemistry as _NeuroChemistry
    except ImportError:
        pass

_EmotionalAuditLog = None
try:
    from vividnessmem.vividnessmem import EmotionalAuditLog as _EmotionalAuditLog
except ImportError:
    try:
        from VividnessMem import EmotionalAuditLog as _EmotionalAuditLog
    except ImportError:
        pass

_VividEmbed = None
try:
    from vividembed import VividEmbed as _VividEmbed
except ImportError:
    try:
        from VividEmbed import VividEmbed as _VividEmbed
    except ImportError:
        pass

# ── Visual memory (Pillow — optional) ─────────────────────────────────────
_PIL_Image = None
try:
    from PIL import Image as _PIL_Image
except ImportError:
    pass

# ── Encryption at rest (optional) ─────────────────────────────────────────
_Fernet = None
_PBKDF2 = None
try:
    from cryptography.fernet import Fernet as _Fernet
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC as _PBKDF2
    from cryptography.hazmat.primitives import hashes as _crypto_hashes
except ImportError:
    _crypto_hashes = None


# ═══════════════════════════════════════════════════════════════════════════
#  Emotion → PAD vector mapping (Pleasure-Arousal-Dominance)
# ═══════════════════════════════════════════════════════════════════════════

EMOTION_VECTORS: dict[str, tuple[float, float, float]] = {
    # positive-calm
    "content":      ( 0.7, -0.3,  0.3),
    "peaceful":     ( 0.8, -0.5,  0.4),
    "serene":       ( 0.8, -0.6,  0.3),
    "grateful":     ( 0.8,  0.1,  0.4),
    "appreciative": ( 0.7,  0.0,  0.3),
    "hopeful":      ( 0.6,  0.2,  0.3),
    "warm":         ( 0.7,  0.1,  0.3),
    "tender":       ( 0.6, -0.1,  0.0),
    "affectionate": ( 0.7,  0.2,  0.2),
    # positive-active
    "happy":        ( 0.8,  0.4,  0.5),
    "joyful":       ( 0.9,  0.6,  0.5),
    "excited":      ( 0.7,  0.8,  0.5),
    "enthusiastic": ( 0.7,  0.7,  0.5),
    "proud":        ( 0.7,  0.4,  0.7),
    "amused":       ( 0.6,  0.5,  0.4),
    "playful":      ( 0.7,  0.6,  0.4),
    "inspired":     ( 0.7,  0.5,  0.5),
    "curious":      ( 0.5,  0.6,  0.3),
    "fascinated":   ( 0.6,  0.6,  0.3),
    "motivated":    ( 0.6,  0.5,  0.6),
    "triumphant":   ( 0.8,  0.6,  0.8),
    "delighted":    ( 0.9,  0.5,  0.5),
    # neutral / reflective
    "neutral":      ( 0.0,  0.0,  0.0),
    "thoughtful":   ( 0.2,  0.1,  0.3),
    "reflective":   ( 0.2, -0.1,  0.2),
    "contemplative":( 0.2, -0.2,  0.2),
    "nostalgic":    ( 0.3, -0.1,  0.1),
    "bittersweet":  ( 0.1,  0.0,  0.0),
    "wistful":      ( 0.1, -0.2,  0.0),
    "understanding":( 0.4,  0.0,  0.4),
    # negative-low arousal
    "sad":          (-0.6, -0.3, -0.3),
    "lonely":       (-0.7, -0.4, -0.5),
    "melancholy":   (-0.5, -0.4, -0.2),
    "disappointed": (-0.5, -0.2, -0.3),
    "guilty":       (-0.5,  0.1, -0.6),
    "insecure":     (-0.4,  0.2, -0.5),
    "vulnerable":   (-0.3,  0.1, -0.5),
    # negative-high arousal
    "anxious":      (-0.5,  0.7, -0.4),
    "frustrated":   (-0.5,  0.6, -0.2),
    "angry":        (-0.7,  0.8,  0.2),
    "hurt":         (-0.6,  0.3, -0.5),
    "confused":     (-0.3,  0.4, -0.3),
    "overwhelmed":  (-0.4,  0.7, -0.5),
    "embarrassed":  (-0.5,  0.5, -0.6),
    "jealous":      (-0.6,  0.6, -0.2),
    "afraid":       (-0.7,  0.8, -0.6),
    "resentful":    (-0.6,  0.5, -0.1),
}


# ═══════════════════════════════════════════════════════════════════════════
#  Constants — Neuroscience mechanisms
# ═══════════════════════════════════════════════════════════════════════════

# ── 1. Flashbulb memory ───────────────────────────────────────────────────
FLASHBULB_STABILITY_FLOOR  = 120.0   # very high stability — resists decay
FLASHBULB_AROUSAL_THRESHOLD = 0.6    # PAD arousal |A| above this + high importance
FLASHBULB_IMPORTANCE_MIN   = 8       # minimum importance for flashbulb encoding
FLASHBULB_VIVIDNESS_FLOOR  = 0.85    # flashbulb memories never drop below 85 % of importance

# ── 2. Reconsolidation ───────────────────────────────────────────────────
RECONSOLIDATION_DRIFT_RATE = 0.05    # PAD drift per recall (5 %)
DRIFT_ALERT_THRESHOLD      = 0.4     # PAD distance to flag significant drift

# ── 3. State-dependent memory ────────────────────────────────────────────
STATE_DEPENDENT_BOOST      = 0.3     # extra vividness when retrieval mood matches encoding mood

# ── 4. Spreading activation ──────────────────────────────────────────────
PRIMING_BOOST              = 1.5     # activation added per related word
PRIMING_DECAY              = 0.8     # multiplicative decay per tick

# Full graph-based spreading activation (Collins & Loftus 1975)
SPREADING_ACTIVATION_HOPS       = 3     # max hops from seed nodes
SPREADING_ACTIVATION_DECAY      = 0.5   # activation halves per hop
SPREADING_ACTIVATION_THRESHOLD  = 0.08  # min accumulated activation to surface
SPREADING_ACTIVATION_MAX_DISCOVER = 10  # cap on newly-discovered memories per recall

# ── 5. Retrieval-induced forgetting ──────────────────────────────────────
INTERFERENCE_THRESHOLD     = 0.7     # overlap ratio above which RIF applies
INTERFERENCE_PENALTY       = 0.15    # stability reduction for suppressed memories

# ── 6. Zeigarnik effect ──────────────────────────────────────────────────
ZEIGARNIK_BOOST            = 0.5     # vividness multiplier for unresolved failures

# ── 7. Involuntary / Proustian recall ────────────────────────────────────
INVOLUNTARY_RECALL_PROB    = 0.05    # 5 % chance per resonate() call

# ── 8. Temporal gist extraction ──────────────────────────────────────────
GIST_AGE_THRESHOLD_DAYS    = 90      # after 90 days detail fades to gist
GIST_PRESERVE_WORDS        = 15      # words kept in the compressed gist

# ── Spaced-repetition (mirrored from VividnessMem) ───────────────────────
INITIAL_STABILITY  = 3.0
SPACING_BONUS      = 1.8
MIN_SPACING_DAYS   = 0.5
STABILITY_CAP      = 180.0
DIMINISHING_RATE   = 0.85

# ── Anchors ──────────────────────────────────────────────────────────────
ANCHOR_STABILITY_FLOOR  = 90.0
ANCHOR_VIVIDNESS_FLOOR  = 0.30

# ── Dedup ────────────────────────────────────────────────────────────────
_DEDUP_THRESHOLD = 0.55
_DEDUP_STOP = frozenset({
    "the", "a", "an", "is", "was", "are", "were", "be", "been", "being",
    "have", "has", "had", "do", "does", "did", "will", "would", "shall",
    "should", "may", "might", "must", "can", "could", "and", "but", "or",
    "not", "so", "yet", "both", "either", "neither", "each", "every",
    "all", "any", "few", "more", "most", "other", "some", "such", "no",
    "only", "own", "same", "than", "too", "very", "just", "of", "at",
    "by", "for", "with", "about", "against", "between", "through",
    "during", "before", "after", "above", "below", "to", "from", "up",
    "down", "in", "out", "on", "off", "over", "under", "again", "then",
    "here", "there", "when", "where", "why", "how", "this", "that",
    "these", "those", "i", "me", "my", "myself", "we", "our", "you",
    "your", "he", "him", "his", "she", "her", "it", "its", "they",
    "them", "their", "what", "which", "who", "whom",
})

# ── Hybrid retrieval bridge ──────────────────────────────────────────────
RECALL_LIMIT               = 10     # default max entries from recall()
_RECENCY_HALF_LIFE_DAYS    = 5.0    # half-life for recency scoring

# Composite re-rank weights (must sum to 1.0)
_W_KEYWORD   = 0.30   # BM25 keyword match strength
_W_SEMANTIC  = 0.30   # VividEmbed semantic similarity
_W_VIVIDNESS = 0.20   # importance × organic decay
_W_MOOD      = 0.10   # mood congruence (PAD dot product)
_W_RECENCY   = 0.10   # freshness (exponential decay)

# ── 9. Temporal / Episodic memory (Tulving 1972) ─────────────────────────
TEMPORAL_PROXIMITY_DAYS    = 3.0     # window for temporal clustering boost
TEMPORAL_PROXIMITY_BOOST   = 0.08   # added to composite for same-window hits
PROSPECTIVE_IMPORTANCE_MIN = 4      # minimum importance to auto-create reminder

# Temporal awareness — how far ahead/behind Mimir "looks" automatically
TEMPORAL_LOOKAHEAD_DAYS    = 7      # surface memories about the next N days
TEMPORAL_LOOKBEHIND_DAYS   = 2      # surface memories about the last N days
TEMPORAL_SALIENCE_BOOST    = 0.12   # recall() boost for temporally-near memories

# ── 10. Visual memory (Kosslyn 1980 — Mental Imagery) ────────────────────
VISUAL_MAX_EDGE            = 1920   # resize if any edge exceeds this
VISUAL_QUALITY_FULL        = 80     # WebP quality for vivid images
VISUAL_QUALITY_FADED       = 30     # WebP quality for fading thumbnail
VISUAL_VIVID_THRESHOLD     = 0.7    # above → full res available
VISUAL_GIST_THRESHOLD      = 0.3    # below → description only, no image
VISUAL_BOOST               = 0.05   # recall() bonus for visual memories (Paivio Dual Coding)

# ── 11. Huginn — Thought (pattern detection) ─────────────────────────────
HUGINN_PATTERN_MIN         = 3      # min memories sharing theme for pattern
HUGINN_OPEN_THREAD_WORDS   = frozenset({
    "should", "need", "want", "plan", "going", "hope",
    "intend", "must", "will", "trying",
})

# ── 12. Muninn — Memory (consolidation) ──────────────────────────────────
MUNINN_PRUNE_THRESHOLD     = 0.01   # vividness below → prune
MUNINN_MERGE_THRESHOLD     = 0.40   # Jaccard overlap for auto-merge
MUNINN_COACTIVATION_BOOST  = 1.05   # stability multiplier for co-active

# ── 21. Memory Chunking (Miller 1956 — 7±2 capacity) ─────────────────────
CHUNK_OVERLAP_THRESHOLD   = 0.30   # word overlap to consider related
CHUNK_MIN_GROUP           = 3      # minimum memories to form a chunk
CHUNK_MAX_CONTENT_WORDS   = 120    # max words in a chunked composite

# ── 13. Yggdrasil — World Tree (memory graph) ────────────────────────────
YGGDRASIL_WORD_EDGE_MIN    = 0.20   # content-word overlap for lexical edge
YGGDRASIL_WORD_EDGE_MAX    = 0.55   # below dedup — related, not duplicate
YGGDRASIL_TEMPORAL_DAYS    = 3.0    # same-window temporal edge
YGGDRASIL_MAX_EDGES        = 8      # max edges per node
YGGDRASIL_BOOST            = 0.03   # recall bonus per connected retrieved neighbour

# ── 14. Völva's Vision — Dream synthesis ─────────────────────────────────
VOLVA_SAMPLE_PAIRS         = 10     # random pairs to sample during dream
VOLVA_INSIGHT_IMPORTANCE   = 5      # default importance for dream insights

# ── 15. Novelty-modulated encoding (Ranganath & Rainer 2003) ─────────────
NOVELTY_MAX_COMPARE        = 20     # compare against N most recent memories
NOVELTY_HIGH_THRESHOLD     = 0.85   # avg similarity below this → high novelty
NOVELTY_LOW_THRESHOLD      = 0.40   # avg similarity above this → low novelty
NOVELTY_BOOST_FACTOR       = 1.3    # importance multiplier for high novelty
NOVELTY_DECAY_FACTOR       = 0.85   # importance multiplier for low novelty (redundant)

# ── 16. Enhanced drift analysis ──────────────────────────────────────────
DRIFT_VELOCITY_WINDOW      = 5      # last N touches to compute drift velocity
COGNITIVE_BIAS_THRESHOLD   = 0.75   # 75%+ same-valence → potential bias alert

# ── 17. Hippocampal Pattern Separation (Yassa & Stark 2011) ──────────────
# When two different memories are too similar, nudge importance apart
PATTERN_SEP_THRESHOLD      = 0.80   # Jaccard overlap triggering separation
PATTERN_SEP_NUDGE          = 1      # importance points to separate by

# ── 18. Narrative Arc Tracking ───────────────────────────────────────────
ARC_POSITIONS = ("setup", "rising", "climax", "falling", "resolution")
_ARC_KEYWORDS: dict[str, list[str]] = {
    "setup":      ["beginning", "started", "first", "new", "introduce", "meet"],
    "rising":     ["growing", "building", "developing", "learning", "discovering"],
    "climax":     ["breakthrough", "crisis", "turning", "realized", "moment", "peak",
                   "confronted", "decided", "revelation", "changed"],
    "falling":    ["after", "settled", "processing", "reflecting", "consequence"],
    "resolution": ["resolved", "concluded", "peace", "accepted", "closure",
                   "understood", "finally", "lesson"],
}

# ── Task / Project branch ────────────────────────────────────────────────
PROJECT_DECAY_ACTIVE_DAYS  = 7
PROJECT_DECAY_COOLING_DAYS = 30
PROJECT_DECAY_COLD_MULT    = 6.0
SOLUTION_INITIAL_IMPORTANCE = 8
SOLUTION_REUSE_BOOST       = 0.3    # importance bump per reuse (capped +3)

# ── LLM integration ─────────────────────────────────────────────────────
# Type alias for optional LLM function
LLMCallable = Callable[[list[dict[str, str]]], str]

# Month lookup for date extraction
_MONTH_MAP = {
    "january": 1, "february": 2, "march": 3, "april": 4,
    "may": 5, "june": 6, "july": 7, "august": 8,
    "september": 9, "october": 10, "november": 11, "december": 12,
    "jan": 1, "feb": 2, "mar": 3, "apr": 4,
    "jun": 6, "jul": 7, "aug": 8, "sep": 9, "sept": 9,
    "oct": 10, "nov": 11, "dec": 12,
}

_WEEKDAY_MAP = {
    "monday": 0, "tuesday": 1, "wednesday": 2, "thursday": 3,
    "friday": 4, "saturday": 5, "sunday": 6,
}


# ═══════════════════════════════════════════════════════════════════════════
#  Helpers
# ═══════════════════════════════════════════════════════════════════════════

def _emotion_to_vector(emotion: str) -> tuple[float, float, float] | None:
    """Map an emotion label to its PAD vector, or None if unknown."""
    if not emotion:
        return None
    key = emotion.lower().strip()
    if key in EMOTION_VECTORS:
        return EMOTION_VECTORS[key]
    for k, v in EMOTION_VECTORS.items():
        if key.startswith(k) or k.startswith(key):
            return v
    return None


def _closest_emotion(pad: tuple[float, float, float]) -> str:
    """Find the EMOTION_VECTORS label nearest to a PAD vector."""
    best, best_dist = "neutral", float("inf")
    for label, vec in EMOTION_VECTORS.items():
        dist = math.sqrt(sum((a - b) ** 2 for a, b in zip(pad, vec)))
        if dist < best_dist:
            best_dist = dist
            best = label
    return best


def _content_words(text: str) -> set[str]:
    """Extract meaningful non-stop words from text."""
    return set(text.lower().split()) - _DEDUP_STOP


def _overlap_ratio(a: set[str], b: set[str]) -> float:
    """Jaccard similarity."""
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def _resonance_words(text: str) -> set[str]:
    """Extract resonance-quality words (>= 3 chars, non-stop)."""
    return {
        w for w in re.sub(r'[^a-z0-9\s]', '', text.lower()).split()
        if len(w) >= 3 and w not in _DEDUP_STOP
    }


def _extract_dates(text: str, reference: datetime | None = None
                   ) -> list[str]:
    """Extract date references from natural text → list of ISO date strings.

    Handles:
      - ISO:       2024-03-15
      - US slash:  03/15/2024, 3/15/24
      - Written:   March 15, 2024 / March 15th / 15th March 2024
      - Relative:  tomorrow, yesterday, next Tuesday, last Monday
    """
    ref = (reference or datetime.now()).date()
    found: set[str] = set()

    # Pattern 1: ISO  YYYY-MM-DD
    for m in re.finditer(r'\b(\d{4})-(\d{1,2})-(\d{1,2})\b', text):
        try:
            d = datetime(int(m.group(1)), int(m.group(2)),
                         int(m.group(3))).date()
            found.add(d.isoformat())
        except ValueError:
            pass

    # Pattern 2: US slash  M/D/YYYY or M/D/YY
    for m in re.finditer(r'\b(\d{1,2})/(\d{1,2})/(\d{2,4})\b', text):
        yr = int(m.group(3))
        if yr < 100:
            yr += 2000
        try:
            d = datetime(yr, int(m.group(1)), int(m.group(2))).date()
            found.add(d.isoformat())
        except ValueError:
            pass

    # Pattern 3: Written  "March 15, 2024" / "March 15th" / "15th March 2024"
    month_pat = '|'.join(_MONTH_MAP.keys())
    # Month Day[suffix][, Year]
    for m in re.finditer(
            rf'\b({month_pat})\s+(\d{{1,2}})(?:st|nd|rd|th)?'
            rf'(?:\s*,?\s*(\d{{4}}))?\b',
            text, re.IGNORECASE):
        mo = _MONTH_MAP.get(m.group(1).lower())
        day = int(m.group(2))
        yr = int(m.group(3)) if m.group(3) else ref.year
        if mo:
            try:
                d = datetime(yr, mo, day).date()
                found.add(d.isoformat())
            except ValueError:
                pass
    # Day Month[, Year]
    for m in re.finditer(
            rf'\b(\d{{1,2}})(?:st|nd|rd|th)?\s+({month_pat})'
            rf'(?:\s*,?\s*(\d{{4}}))?\b',
            text, re.IGNORECASE):
        mo = _MONTH_MAP.get(m.group(2).lower())
        day = int(m.group(1))
        yr = int(m.group(3)) if m.group(3) else ref.year
        if mo:
            try:
                d = datetime(yr, mo, day).date()
                found.add(d.isoformat())
            except ValueError:
                pass

    # Pattern 4: Relative days
    lower = text.lower()
    if "tomorrow" in lower:
        found.add((ref + timedelta(days=1)).isoformat())
    if "yesterday" in lower:
        found.add((ref - timedelta(days=1)).isoformat())

    # "next <weekday>" / "last <weekday>"
    for m in re.finditer(
            r'\b(next|last)\s+(monday|tuesday|wednesday|thursday'
            r'|friday|saturday|sunday)\b',
            text, re.IGNORECASE):
        direction = m.group(1).lower()
        target_wd = _WEEKDAY_MAP[m.group(2).lower()]
        current_wd = ref.weekday()
        if direction == "next":
            delta = (target_wd - current_wd) % 7
            if delta == 0:
                delta = 7
        else:  # last
            delta = -((current_wd - target_wd) % 7)
            if delta == 0:
                delta = -7
        found.add((ref + timedelta(days=delta)).isoformat())

    return sorted(found)


# ═══════════════════════════════════════════════════════════════════════════
#  Visual memory helpers — content-addressable image store
# ═══════════════════════════════════════════════════════════════════════════

def _visual_hash(data: bytes) -> str:
    """SHA-256 content hash for an image (hex, first 32 chars)."""
    return hashlib.sha256(data).hexdigest()[:32]


def _compress_image(data: bytes, quality: int = VISUAL_QUALITY_FULL,
                    max_edge: int = VISUAL_MAX_EDGE) -> tuple[bytes, tuple[int, int]]:
    """Compress raw image bytes → WebP, return (webp_bytes, (w, h)).

    Resizes if either dimension exceeds *max_edge*, preserving aspect ratio.
    Requires Pillow; raises RuntimeError if not installed.
    """
    if _PIL_Image is None:
        raise RuntimeError("Pillow is required for visual memory: pip install Pillow")
    import io
    img = _PIL_Image.open(io.BytesIO(data))
    img = img.convert("RGB")  # strip alpha for consistent hashing
    # Resize if needed
    w, h = img.size
    if max(w, h) > max_edge:
        scale = max_edge / max(w, h)
        w, h = int(w * scale), int(h * scale)
        img = img.resize((w, h), _PIL_Image.LANCZOS)
    buf = io.BytesIO()
    img.save(buf, format="WEBP", quality=quality)
    return buf.getvalue(), (w, h)


def _decompress_image(data: bytes, quality: int | None = None) -> bytes:
    """Re-encode stored WebP at a different quality (for faded recall).

    If *quality* is None, returns the original bytes untouched.
    """
    if quality is None or _PIL_Image is None:
        return data
    import io
    img = _PIL_Image.open(io.BytesIO(data))
    buf = io.BytesIO()
    img.save(buf, format="WEBP", quality=quality)
    return buf.getvalue()


def _infer_arc_position(content: str, emotion: str) -> str:
    """Infer narrative arc position from content keywords + arousal level."""
    lower = content.lower()
    scores: dict[str, int] = {}
    for pos, keywords in _ARC_KEYWORDS.items():
        scores[pos] = sum(1 for kw in keywords if kw in lower)
    # Arousal biases: high arousal → climax, low → resolution
    vec = _emotion_to_vector(emotion)
    if vec:
        if abs(vec[1]) >= 0.6:
            scores["climax"] = scores.get("climax", 0) + 2
        elif abs(vec[1]) <= 0.2:
            scores["resolution"] = scores.get("resolution", 0) + 1
    best = max(scores, key=lambda k: scores[k])
    return best if scores[best] > 0 else "rising"  # default to rising


# ═══════════════════════════════════════════════════════════════════════════
#  Memory — single episodic memory with neuroscience extensions
# ═══════════════════════════════════════════════════════════════════════════

class Memory:
    """A single memory with organic vividness decay and neuroscience layers.

    Compared to base VividnessMem Memory, Mimir's Memory adds:
    - Flashbulb encoding (_is_flashbulb) with stability + vividness floors
    - Encoding mood (_encoding_mood) for state-dependent retrieval
    - Reconsolidation drift on touch()
    - Temporal gist compression (.gist property)
    """

    __slots__ = (
        "content", "emotion", "importance", "timestamp",
        "source", "entity", "_access_count", "_last_access",
        "_stability", "why_saved",
        # Neuroscience extensions
        "original_emotion",   # immutable baseline — never drifts
        "_is_flashbulb", "_encoding_mood", "_emotion_pad",
        # Temporal / Episodic (Tulving 1972)
        "_mentioned_dates",
        # VividEmbed sync
        "_embed_uid",
        # Visual memory (Kosslyn 1980)
        "_visual_hash", "_visual_description", "_visual_dimensions",
        # Intentional reframe tracking
        "_reframed", "_reframe_reason",
        # VividnessMem-compatible fields
        "_anchor", "_cherished", "_privacy",
        "_regret", "_believed_importance", "_rescore_survived",
        # Novelty-modulated encoding
        "_novelty_score",
        # Enhanced drift tracking
        "_drift_history",
        # Narrative arc (Freytag 1863)
        "_arc_position",
    )

    def __init__(self, content: str, emotion: str = "neutral",
                 importance: int = 5, source: str = "reflection",
                 entity: str = "", why_saved: str = ""):
        self.content = content
        self.emotion = emotion
        self.importance = max(1, min(10, importance))
        self.timestamp = datetime.now().isoformat()
        self.source = source
        self.entity = entity
        self._access_count: int = 0
        self._last_access: str = self.timestamp
        self._stability: float = INITIAL_STABILITY
        self.why_saved = why_saved
        # Neuroscience
        self.original_emotion: str = emotion   # immutable baseline — never drifts
        self._is_flashbulb: bool = False
        self._encoding_mood: tuple[float, float, float] = (0.0, 0.0, 0.0)
        self._emotion_pad: tuple[float, float, float] | None = None
        # Temporal
        self._mentioned_dates: list[str] = []
        # VividEmbed sync
        self._embed_uid: str = ""
        # Visual memory (Kosslyn 1980)
        self._visual_hash: str = ""
        self._visual_description: str = ""
        self._visual_dimensions: tuple[int, int] = (0, 0)
        # VividnessMem compat
        self._anchor: bool = False
        self._cherished: bool = False
        self._privacy: str = "public"
        self._reframed: bool = False
        self._reframe_reason: str = ""
        self._regret: float = 0.0
        self._believed_importance: int = 0
        self._rescore_survived: int = 0
        # Novelty-modulated encoding
        self._novelty_score: float = 0.5  # 0 = redundant, 1 = completely novel
        # Enhanced drift tracking
        self._drift_history: list[tuple[str, str, float]] = []  # (timestamp, emotion, magnitude)
        # Narrative arc
        self._arc_position: str = ""  # setup / rising / climax / falling / resolution

    # ── Spaced-repetition touch + reconsolidation ─────────────────────
    def touch(self, current_mood: tuple[float, float, float] | None = None):
        """Record an access.  Well-spaced touches increase stability.

        If *current_mood* is provided and the memory is not a flashbulb,
        reconsolidation occurs: the memory's emotion subtly drifts toward
        the current mood context (Nader et al 2000).
        """
        now = datetime.now()
        last = datetime.fromisoformat(self._last_access)
        gap_days = (now - last).total_seconds() / 86400

        if gap_days >= MIN_SPACING_DAYS:
            effective_bonus = (
                1.0 + (SPACING_BONUS - 1.0)
                * (DIMINISHING_RATE ** self._access_count)
            )
            self._stability = min(
                self._stability * effective_bonus, STABILITY_CAP)
        self._access_count += 1
        self._last_access = now.isoformat()

        # ── Reconsolidation instability ───────────────────────────────
        # Each recall in a new emotional context shifts the memory's
        # emotion slightly.  Flashbulb memories resist this — they are
        # encoded too strongly to be rewritten.
        # We drift the raw PAD vector (not the quantized label) so that
        # small per-touch drifts accumulate across multiple recalls.
        if current_mood and not self._is_flashbulb:
            if self._emotion_pad is None:
                self._emotion_pad = (
                    _emotion_to_vector(self.emotion) or (0.0, 0.0, 0.0))
            self._emotion_pad = tuple(
                self._emotion_pad[i]
                + RECONSOLIDATION_DRIFT_RATE
                * (current_mood[i] - self._emotion_pad[i])
                for i in range(3)
            )
            self.emotion = _closest_emotion(self._emotion_pad)

    # ── Vividness (organic decay) ─────────────────────────────────────
    @property
    def vividness(self) -> float:
        age_days = (
            datetime.now() - datetime.fromisoformat(self.timestamp)
        ).total_seconds() / 86400
        effective_stability = self._stability
        if self._anchor:
            effective_stability = max(
                effective_stability, ANCHOR_STABILITY_FLOOR)
        if self._is_flashbulb:
            effective_stability = max(
                effective_stability, FLASHBULB_STABILITY_FLOOR)
        retention = math.exp(-age_days / max(effective_stability, 0.1))
        raw = self.importance * retention
        if self._is_flashbulb:
            return max(raw, self.importance * FLASHBULB_VIVIDNESS_FLOOR)
        if self._anchor:
            return max(raw, self.importance * ANCHOR_VIVIDNESS_FLOOR)
        return raw

    # ── Mood-adjusted vividness (state-dependent memory) ──────────────
    def mood_adjusted_vividness(
        self, mood_vector: tuple[float, float, float]
    ) -> float:
        """Vividness boosted when retrieval mood matches the memory.

        Two boosts stack:
        1. Standard mood congruence — current mood matches memory emotion.
        2. State-dependent encoding — current mood matches the mood when
           the memory was originally formed (Godden & Baddeley 1975).
        """
        base = self.vividness
        mem_vec = _emotion_to_vector(self.emotion)
        if not mem_vec or mood_vector == (0.0, 0.0, 0.0):
            return base

        # Standard mood congruence
        dot = sum(a * b for a, b in zip(mem_vec, mood_vector))
        congruence = max(-1.0, min(1.0, dot))
        mood_boost = 1.0 + congruence * 0.3

        # State-dependent boost (encoding-context match)
        if self._encoding_mood != (0.0, 0.0, 0.0):
            enc_dot = sum(
                a * b for a, b in zip(mood_vector, self._encoding_mood))
            enc_match = max(0.0, min(1.0, enc_dot))
            mood_boost += enc_match * STATE_DEPENDENT_BOOST

        return base * mood_boost

    # ── Temporal gist extraction ──────────────────────────────────────
    @property
    def gist(self) -> str:
        """Return the memory's content, or a compressed gist if old.

        Flashbulb memories resist gist compression — they stay vivid
        in full detail (like 'where were you when…' memories).
        """
        if self._is_flashbulb:
            return self.content
        age_days = (
            datetime.now() - datetime.fromisoformat(self.timestamp)
        ).total_seconds() / 86400
        if age_days < GIST_AGE_THRESHOLD_DAYS:
            return self.content
        words = self.content.split()
        if len(words) <= GIST_PRESERVE_WORDS:
            return self.content
        preserved = " ".join(words[:GIST_PRESERVE_WORDS])
        return f"[faded memory — {self.emotion}] {preserved}…"

    # ── Helpers ───────────────────────────────────────────────────────
    @property
    def content_words(self) -> set[str]:
        return _content_words(self.content)

    # ── Visual memory properties (Kosslyn 1980) ──────────────────────
    @property
    def has_visual(self) -> bool:
        """Whether this memory has an attached image."""
        return bool(self._visual_hash)

    @property
    def can_show(self) -> bool:
        """Whether the image is vivid enough to display.

        Above VISUAL_VIVID_THRESHOLD → full res available.
        Between GIST and VIVID → faded thumbnail.
        Below VISUAL_GIST_THRESHOLD → too faded, description only.
        """
        return self.has_visual and self.vividness >= VISUAL_GIST_THRESHOLD

    @property
    def drift_magnitude(self) -> float:
        """Euclidean PAD distance between original and current emotion."""
        orig_pad = _emotion_to_vector(self.original_emotion)
        if orig_pad is None:
            return 0.0
        curr_pad = self._emotion_pad or orig_pad
        return math.sqrt(sum(
            (a - b) ** 2 for a, b in zip(orig_pad, curr_pad)))

    @property
    def has_drifted(self) -> bool:
        """True if reconsolidation drift exceeds the alert threshold."""
        return self.drift_magnitude >= DRIFT_ALERT_THRESHOLD

    @property
    def visual_clarity(self) -> str:
        """Human-readable visual fading tier."""
        if not self.has_visual:
            return "none"
        v = self.vividness
        if v >= VISUAL_VIVID_THRESHOLD:
            return "vivid"
        elif v >= VISUAL_GIST_THRESHOLD:
            return "faded"
        return "gist_only"

    # ── Serialization ─────────────────────────────────────────────────
    def to_dict(self) -> dict:
        d: dict[str, Any] = {
            "content":       self.content,
            "emotion":       self.emotion,
            "importance":    self.importance,
            "timestamp":     self.timestamp,
            "source":        self.source,
            "entity":        self.entity,
            "access_count":  self._access_count,
            "last_access":   self._last_access,
            "stability":     self._stability,
            "why_saved":     self.why_saved,
            "original_emotion": self.original_emotion,
            "encoding_mood": list(self._encoding_mood),
            "is_flashbulb":  self._is_flashbulb,
            "emotion_pad":   list(self._emotion_pad) if self._emotion_pad else None,
        }
        if self._mentioned_dates:
            d["mentioned_dates"] = self._mentioned_dates
        if self._embed_uid:
            d["embed_uid"] = self._embed_uid
        if self._visual_hash:
            d["visual_hash"] = self._visual_hash
            d["visual_description"] = self._visual_description
            d["visual_dimensions"] = list(self._visual_dimensions)
        if self._anchor:
            d["anchor"] = True
            d["rescore_survived"] = self._rescore_survived
        if self._cherished:
            d["cherished"] = True
        if self._reframed:
            d["reframed"] = True
            d["reframe_reason"] = self._reframe_reason
        if self._privacy != "public":
            d["privacy"] = self._privacy
        regret = self._regret
        if regret > 0:
            d["regret"] = round(regret, 3)
            d["believed_importance"] = self._believed_importance
        if self._novelty_score != 0.5:
            d["novelty_score"] = round(self._novelty_score, 3)
        if self._drift_history:
            d["drift_history"] = self._drift_history
        if self._arc_position:
            d["arc_position"] = self._arc_position
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "Memory":
        obj = cls.__new__(cls)
        obj.content       = d.get("content", "")
        obj.emotion       = d.get("emotion", "neutral")
        obj.importance    = max(1, min(10, d.get("importance", 5)))
        obj.timestamp     = d.get("timestamp", datetime.now().isoformat())
        obj.source        = d.get("source", "reflection")
        obj.entity        = d.get("entity", "")
        obj._access_count = d.get("access_count", 0)
        obj._last_access  = d.get("last_access", obj.timestamp)
        obj._stability    = d.get("stability", INITIAL_STABILITY)
        obj.why_saved     = d.get("why_saved", "")
        # Neuroscience
        obj.original_emotion = d.get("original_emotion", obj.emotion)
        enc = d.get("encoding_mood", [0.0, 0.0, 0.0])
        obj._encoding_mood = tuple(enc) if isinstance(enc, list) else enc
        obj._is_flashbulb  = d.get("is_flashbulb", False)
        epad = d.get("emotion_pad")
        obj._emotion_pad = tuple(epad) if epad else None
        # Temporal
        obj._mentioned_dates = d.get("mentioned_dates", [])
        # VividEmbed sync
        obj._embed_uid = d.get("embed_uid", "")
        # Visual memory
        obj._visual_hash = d.get("visual_hash", "")
        obj._visual_description = d.get("visual_description", "")
        vdim = d.get("visual_dimensions", [0, 0])
        obj._visual_dimensions = tuple(vdim) if isinstance(vdim, list) else vdim
        # VividnessMem compat
        obj._anchor            = d.get("anchor", False)
        obj._rescore_survived  = d.get("rescore_survived", 0)
        obj._cherished         = d.get("cherished", False)
        obj._reframed          = d.get("reframed", False)
        obj._reframe_reason    = d.get("reframe_reason", "")
        obj._privacy           = d.get("privacy", "public")
        obj._regret            = d.get("regret", 0.0)
        obj._believed_importance = d.get("believed_importance", 0)
        obj._novelty_score     = d.get("novelty_score", 0.5)
        obj._drift_history     = d.get("drift_history", [])
        obj._arc_position      = d.get("arc_position", "")
        return obj


# ═══════════════════════════════════════════════════════════════════════════
#  Lesson — procedural memory with Zeigarnik effect
# ═══════════════════════════════════════════════════════════════════════════

class Lesson:
    """A learned procedure or skill.

    Unresolved failures make the lesson stay extra vivid (Zeigarnik 1927):
    the mind keeps incomplete tasks in the foreground until resolved.
    """

    __slots__ = (
        "id", "topic", "context_trigger", "strategy",
        "created", "importance", "_stability",
        "attempts", "consecutive_failures", "total_attempts",
        "last_attempt",
        # Cross-hierarchy link to origin Memory index
        "_source_memory_idx",
    )

    def __init__(self, topic: str, context_trigger: str = "",
                 strategy: str = "", importance: int = 5):
        self.id = str(uuid.uuid4())
        self.topic = topic
        self.context_trigger = context_trigger
        self.strategy = strategy
        self.created = datetime.now().isoformat()
        self.importance = importance
        self._stability: float = 30.0  # lessons are more stable than episodes
        self.attempts: list[Attempt] = []
        self.consecutive_failures: int = 0
        self.total_attempts: int = 0
        self.last_attempt: str | None = None
        self._source_memory_idx: int = -1  # cross-hierarchy link

    @property
    def vividness(self) -> float:
        age_days = (
            datetime.now() - datetime.fromisoformat(self.created)
        ).total_seconds() / 86400
        retention = math.exp(-age_days / max(self._stability, 0.1))
        base = self.importance * retention
        if self.consecutive_failures > 0:
            base *= (1.0 + ZEIGARNIK_BOOST)
        return base

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "topic": self.topic,
            "context_trigger": self.context_trigger,
            "strategy": self.strategy,
            "created": self.created,
            "importance": self.importance,
            "stability": self._stability,
            "consecutive_failures": self.consecutive_failures,
            "total_attempts": self.total_attempts,
            "last_attempt": self.last_attempt,
            "attempts": [a.to_dict() for a in self.attempts],
            "source_memory_idx": self._source_memory_idx,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "Lesson":
        obj = cls.__new__(cls)
        obj.id = d.get("id", str(uuid.uuid4()))
        obj.topic = d.get("topic", "")
        obj.context_trigger = d.get("context_trigger", "")
        obj.strategy = d.get("strategy", "")
        obj.created = d.get("created", datetime.now().isoformat())
        obj.importance = d.get("importance", 5)
        obj._stability = d.get("stability", 30.0)
        obj.consecutive_failures = d.get("consecutive_failures", 0)
        obj.total_attempts = d.get("total_attempts", 0)
        obj.last_attempt = d.get("last_attempt")
        obj.attempts = [
            Attempt.from_dict(a) for a in d.get("attempts", [])
        ]
        obj._source_memory_idx = d.get("source_memory_idx", -1)
        return obj


# ═══════════════════════════════════════════════════════════════════════════
#  Attempt — outcome of a lesson application
# ═══════════════════════════════════════════════════════════════════════════

class Attempt:
    __slots__ = ("action", "result", "diagnosis", "timestamp")

    def __init__(self, action: str, result: str, diagnosis: str = ""):
        self.action = action
        self.result = result
        self.diagnosis = diagnosis
        self.timestamp = datetime.now().isoformat()

    def to_dict(self) -> dict:
        return {
            "action": self.action,
            "result": self.result,
            "diagnosis": self.diagnosis,
            "timestamp": self.timestamp,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "Attempt":
        obj = cls.__new__(cls)
        obj.action = d.get("action", "")
        obj.result = d.get("result", "")
        obj.diagnosis = d.get("diagnosis", "")
        obj.timestamp = d.get("timestamp", datetime.now().isoformat())
        return obj


# ═══════════════════════════════════════════════════════════════════════════
#  Reminder — time-triggered notification
# ═══════════════════════════════════════════════════════════════════════════

class Reminder:
    __slots__ = ("text", "trigger_at", "created", "fired")

    def __init__(self, text: str, trigger_at: str):
        self.text = text
        self.trigger_at = trigger_at
        self.created = datetime.now().isoformat()
        self.fired = False

    @property
    def is_due(self) -> bool:
        return (not self.fired
                and datetime.now() >= datetime.fromisoformat(self.trigger_at))

    def to_dict(self) -> dict:
        return {
            "text": self.text,
            "trigger_at": self.trigger_at,
            "created": self.created,
            "fired": self.fired,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "Reminder":
        obj = cls.__new__(cls)
        obj.text = d.get("text", "")
        obj.trigger_at = d.get("trigger_at", datetime.now().isoformat())
        obj.created = d.get("created", datetime.now().isoformat())
        obj.fired = d.get("fired", False)
        return obj


# ═══════════════════════════════════════════════════════════════════════════
#  ShortTermFact — volatile factual memory with aggressive decay
# ═══════════════════════════════════════════════════════════════════════════

class ShortTermFact:
    """A volatile fact (e.g. 'Scott's monitor is 27 inches').

    Decays much faster than episodic memories — 12-hour half-life.
    """

    __slots__ = ("entity", "attribute", "value", "timestamp")

    _HALF_LIFE_HOURS = 12.0

    def __init__(self, entity: str, attribute: str, value: str):
        self.entity = entity
        self.attribute = attribute
        self.value = value
        self.timestamp = datetime.now().isoformat()

    @property
    def vividness(self) -> float:
        age_hours = (
            datetime.now() - datetime.fromisoformat(self.timestamp)
        ).total_seconds() / 3600
        return math.exp(-0.693 * age_hours / self._HALF_LIFE_HOURS)

    def to_dict(self) -> dict:
        return {
            "entity": self.entity,
            "attribute": self.attribute,
            "value": self.value,
            "timestamp": self.timestamp,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "ShortTermFact":
        obj = cls.__new__(cls)
        obj.entity = d.get("entity", "")
        obj.attribute = d.get("attribute", "")
        obj.value = d.get("value", "")
        obj.timestamp = d.get("timestamp", datetime.now().isoformat())
        return obj


# ═══════════════════════════════════════════════════════════════════════════
#  NullChemistry — no-op fallback when VividnessMem is not installed
# ═══════════════════════════════════════════════════════════════════════════

class _NullChemistry:
    """Minimal no-op chemistry for standalone operation."""
    enabled = False
    _dampening_active = False
    _dampening_turns_left = 0

    def tick(self, dt_minutes: float | None = None): pass
    def on_emotion(self, emotion: str, intensity: float = 0.7): pass
    def on_event(self, event_type: str, intensity: float = 0.7): pass
    def cognitive_override(self, emotion: str, intensity: float = 0.7): pass
    def request_dampening(self, turns: int = 5, intensity: float = 0.3): pass
    def end_dampening(self): pass
    def tick_dampening(self): pass
    def sleep_reset(self, hours: float = 8.0): pass
    def describe(self) -> str: return "(chemistry not installed)"
    def to_dict(self) -> dict: return {}
    @classmethod
    def from_dict(cls, d: dict) -> "_NullChemistry": return cls()
    @property
    def is_dampened(self) -> bool: return False

    def get_modifiers(self) -> dict:
        return {
            "encoding_boost": 1.0, "attention_width": 1.0,
            "mood_decay_mult": 1.0, "mood_influence_mult": 1.0,
            "social_boost": 1.0, "warmth_nudge_mult": 1.0,
            "consolidation_bonus": 1.0, "flashbulb": False,
            "yerkes_dodson": 1.0,
        }


# ═══════════════════════════════════════════════════════════════════════════
#  NullAuditLog — no-op fallback when VividnessMem is not installed
# ═══════════════════════════════════════════════════════════════════════════

class _NullAuditLog:
    """Minimal no-op audit log for standalone operation."""
    def log(self, event_type: str, emotion: str = "",
            source: str = "", details: dict | None = None): pass
    def get_recent(self, n: int = 20) -> list[dict]: return []
    def query_by_type(self, event_type: str, n: int = 10) -> list[dict]: return []
    def describe_recent(self, n: int = 5) -> str: return ""
    def load_recent_from_disk(self, n: int = 50): pass


# ═══════════════════════════════════════════════════════════════════════════
#  Task / Project branch — project management with organic memory properties
# ═══════════════════════════════════════════════════════════════════════════

class TaskRecord:
    """A single task within a project.  Lifecycle: active → completed | failed | abandoned."""
    __slots__ = ("task_id", "description", "status", "priority",
                 "created_at", "completed_at", "outcome",
                 "parent_id", "project", "tags",
                 # Cross-hierarchy links to Memory indices
                 "_memory_indices")

    def __init__(self, description: str, project: str = "",
                 priority: int = 5, parent_id: str = "",
                 tags: list[str] | None = None):
        self.task_id = uuid.uuid4().hex[:12]
        self.description = description
        self.status = "active"
        self.priority = max(1, min(10, priority))
        self.created_at = datetime.now().isoformat()
        self.completed_at = ""
        self.outcome = ""
        self.parent_id = parent_id
        self.project = project
        self.tags = tags or []
        self._memory_indices: list[int] = []  # cross-hierarchy links

    def complete(self, outcome: str = ""):
        self.status = "completed"
        self.completed_at = datetime.now().isoformat()
        self.outcome = outcome

    def fail(self, reason: str = ""):
        self.status = "failed"
        self.completed_at = datetime.now().isoformat()
        self.outcome = reason

    def to_dict(self) -> dict:
        d = {k: getattr(self, k) for k in self.__slots__}
        d["memory_indices"] = d.pop("_memory_indices", [])
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "TaskRecord":
        obj = cls.__new__(cls)
        for k in cls.__slots__:
            if k == "_memory_indices":
                continue
            setattr(obj, k, d.get(k, "" if k != "tags" else []))
        obj.priority = max(1, min(10, int(obj.priority or 5)))
        obj._memory_indices = d.get("memory_indices", [])
        return obj


class ActionRecord:
    """A single action taken on a task — success, failure, or partial."""
    __slots__ = ("task_id", "action", "result", "error",
                 "fix", "timestamp", "importance")

    def __init__(self, task_id: str, action: str, result: str = "success",
                 error: str = "", fix: str = "", importance: int = 5):
        self.task_id = task_id
        self.action = action
        self.result = result
        self.error = error
        self.fix = fix
        self.timestamp = datetime.now().isoformat()
        self.importance = max(1, min(10, importance))

    def to_dict(self) -> dict:
        return {k: getattr(self, k) for k in self.__slots__}

    @classmethod
    def from_dict(cls, d: dict) -> "ActionRecord":
        obj = cls.__new__(cls)
        for k in cls.__slots__:
            setattr(obj, k, d.get(k, ""))
        obj.importance = max(1, min(10, int(obj.importance or 5)))
        return obj


class SolutionPattern:
    """A reusable problem→solution pattern with spaced-repetition decay."""
    __slots__ = ("problem_signature", "failed_approaches", "solution",
                 "context_tags", "times_applied", "importance",
                 "timestamp", "_stability")

    def __init__(self, problem: str, solution: str,
                 failed_approaches: list[str] | None = None,
                 tags: list[str] | None = None,
                 importance: int = SOLUTION_INITIAL_IMPORTANCE):
        self.problem_signature = problem
        self.solution = solution
        self.failed_approaches = failed_approaches or []
        self.context_tags = tags or []
        self.times_applied = 0
        self.importance = max(1, min(10, importance))
        self.timestamp = datetime.now().isoformat()
        self._stability = 30.0  # solutions are more stable than episodes

    def apply(self):
        """Mark as reused — boosts importance and resets decay."""
        self.times_applied += 1
        self.importance = min(10, self.importance
                              + min(3, round(SOLUTION_REUSE_BOOST
                                             * self.times_applied)))
        self._stability = min(STABILITY_CAP, self._stability * 1.5)

    @property
    def vividness(self) -> float:
        age = (datetime.now()
               - datetime.fromisoformat(self.timestamp)).total_seconds() / 86400
        return self.importance * math.exp(-age / max(self._stability, 0.1))

    @property
    def search_text(self) -> str:
        return " ".join([self.problem_signature, self.solution]
                        + self.failed_approaches + self.context_tags)

    def to_dict(self) -> dict:
        return {k: getattr(self, k) for k in self.__slots__}

    @classmethod
    def from_dict(cls, d: dict) -> "SolutionPattern":
        obj = cls.__new__(cls)
        for k in cls.__slots__:
            default = [] if k in ("failed_approaches", "context_tags") else ""
            setattr(obj, k, d.get(k, default))
        obj.importance = max(1, min(10, int(obj.importance or 8)))
        obj._stability = float(obj._stability or 30.0)
        obj.times_applied = int(obj.times_applied or 0)
        return obj


class ArtifactRecord:
    """A tracked artifact within a project (file, function, API, concept)."""
    __slots__ = ("name", "artifact_type", "description", "importance",
                 "dependencies", "current_state", "last_updated")

    def __init__(self, name: str, artifact_type: str = "file",
                 description: str = "", importance: int = 5,
                 dependencies: list[str] | None = None):
        self.name = name
        self.artifact_type = artifact_type
        self.description = description
        self.importance = max(1, min(10, importance))
        self.dependencies = dependencies or []
        self.current_state = "active"
        self.last_updated = datetime.now().isoformat()

    def to_dict(self) -> dict:
        return {k: getattr(self, k) for k in self.__slots__}

    @classmethod
    def from_dict(cls, d: dict) -> "ArtifactRecord":
        obj = cls.__new__(cls)
        for k in cls.__slots__:
            default = [] if k == "dependencies" else ""
            setattr(obj, k, d.get(k, default))
        obj.importance = max(1, min(10, int(obj.importance or 5)))
        return obj


# ═══════════════════════════════════════════════════════════════════════════
#  Mimir — The Orchestrator
# ═══════════════════════════════════════════════════════════════════════════

class Mimir:
    """The ultimate memory architecture.

    Composes:
    - Organic episodic decay (spaced repetition, vividness)
    - NeuroChemistry from VividnessMem (dopamine, serotonin, cortisol,
      oxytocin, norepinephrine)
    - Semantic retrieval from VividEmbed (384-d MiniLM + PAD + meta)
    - Fourteen neuroscience mechanisms (flashbulb, reconsolidation,
      state-dependent, spreading activation, RIF, Zeigarnik,
      involuntary recall, temporal gist, temporal/episodic,
      visual / mental imagery, Huginn, Muninn, Yggdrasil,
      Völva's Vision)

    God-tier features:
    - Huginn (Thought): background insight generation from memory patterns
    - Muninn (Memory): consolidation daemon — merge, prune, strengthen
    - Yggdrasil (World Tree): memory graph for structural retrieval
    - Völva's Vision: dream synthesis during sleep_reset()

    Migration from VividnessMem:
        Mimir.migrate_from_vividnessmem("lela_data", "mimir_data")
    """

    ACTIVE_SELF_LIMIT = 10
    RESONANCE_LIMIT   = 5
    RECALL_LIMIT      = 10

    def __init__(self, data_dir: str | Path = "mimir_data",
                 embed_model: str | None = None,
                 chemistry: bool = True,
                 visual: bool = True,
                 encryption_key: str | None = None,
                 llm_fn: LLMCallable | None = None):
        self._data_dir = Path(data_dir)
        self._data_dir.mkdir(parents=True, exist_ok=True)

        # ── Encryption at rest ────────────────────────────────────────
        self._fernet = None
        if encryption_key and _Fernet is not None and _PBKDF2 is not None:
            salt = hashlib.sha256(
                str(data_dir).encode()).digest()[:16]
            kdf = _PBKDF2(
                algorithm=_crypto_hashes.SHA256(), length=32,
                salt=salt, iterations=600_000)
            key = base64.urlsafe_b64encode(
                kdf.derive(encryption_key.encode()))
            self._fernet = _Fernet(key)

        # ── Optional LLM integration ─────────────────────────────────
        self._llm_fn: LLMCallable | None = llm_fn

        # ── Core state ────────────────────────────────────────────────
        self._reflections: list[Memory] = []
        self._social: dict[str, list[Memory]] = {}
        self._lessons: list[Lesson] = []
        self._reminders: list[Reminder] = []
        self._facts: list[ShortTermFact] = []
        self._mood: tuple[float, float, float] = (0.0, 0.0, 0.0)
        self._priming_buffer: dict[str, float] = {}

        # ── Task / Project branch ─────────────────────────────────────
        self._active_project: str = ""
        self._project_tasks: list[TaskRecord] = []
        self._project_actions: list[ActionRecord] = []
        self._solutions: list[SolutionPattern] = []
        self._artifacts: list[ArtifactRecord] = []

        # ── LLM-inferred relational edges (Enhanced Relational Reasoning)
        self._inferred_edges: dict[tuple[int, int], float] = {}

        # ── Visual memory (Kosslyn 1980) ──────────────────────────────
        self._visual_enabled = visual and _PIL_Image is not None
        self._visual_dir = self._data_dir / "visual"
        if self._visual_enabled:
            self._visual_dir.mkdir(parents=True, exist_ok=True)

        # ── Word index for fast lexical retrieval ─────────────────────
        self._word_index: dict[str, set[int]] = {}

        # ── Date index for temporal retrieval (Tulving 1972) ──────────
        self._date_index: dict[str, set[int]] = {}   # ISO date → indices

        # ── Session tracking ──────────────────────────────────────────
        self._session_count: int = 0

        # ── Yggdrasil — memory graph (World Tree) ────────────────────
        # adjacency list: idx → [(target_idx, edge_type, strength)]
        self._yggdrasil: dict[int, list[tuple[int, str, float]]] = {}

        # ── Chemistry engine (VividnessMem) ───────────────────────────
        if chemistry and _NeuroChemistry is not None:
            self._chemistry = _NeuroChemistry(enabled=True)
        else:
            self._chemistry = _NullChemistry()

        # ── Emotional audit log (VividnessMem) ────────────────────────
        if _EmotionalAuditLog is not None:
            self._audit = _EmotionalAuditLog(self._data_dir)
            self._audit.load_recent_from_disk()
        else:
            self._audit = _NullAuditLog()

        # ── Embedding engine (VividEmbed) ─────────────────────────────
        self._embed = None
        if _VividEmbed is not None:
            try:
                embed_dir = str(self._data_dir / "embed")
                if embed_model:
                    self._embed = _VividEmbed(
                        persist_dir=embed_dir, model_name=embed_model)
                else:
                    self._embed = _VividEmbed(persist_dir=embed_dir)
            except Exception:
                self._embed = None

        # ── Load persisted data ───────────────────────────────────────
        self._load()

    # ──────────────────────────────────────────────────────────────────
    #  Properties
    # ──────────────────────────────────────────────────────────────────

    @property
    def self_reflections(self) -> list[Memory]:
        return self._reflections

    @property
    def social_impressions(self) -> dict[str, list[Memory]]:
        return self._social

    @property
    def mood(self) -> tuple[float, float, float]:
        return self._mood

    @property
    def mood_label(self) -> str:
        return _closest_emotion(self._mood)

    @property
    def chemistry(self):
        return self._chemistry

    @property
    def session_count(self) -> int:
        return self._session_count

    def bump_session(self) -> int:
        """Increment session counter.  Returns the new count."""
        self._session_count += 1
        return self._session_count

    @property
    def visual_enabled(self) -> bool:
        return self._visual_enabled

    # ══════════════════════════════════════════════════════════════════
    #  Migration — import from VividnessMem / Lela
    # ══════════════════════════════════════════════════════════════════

    @classmethod
    def migrate_from_vividnessmem(cls, src_dir: str | Path,
                                  dest_dir: str | Path | None = None
                                  ) -> "Mimir":
        """Import memories from a VividnessMem data directory.

        Reads VividnessMem files:
            self_memory.json, social/*.json, brief.json,
            neurochemistry.json

        Writes Mimir files:
            reflections.json, social/*.json, meta.json,
            chemistry.json, lessons.json, reminders.json, facts.json

        All existing memories are preserved with their timestamps,
        stability, access counts, and emotional tags intact.  New
        Mimir-specific fields are back-filled automatically:
            encoding_mood  ← from brief.json mood
            emotion_pad    ← derived from EMOTION_VECTORS
            mentioned_dates← extracted from content text
            is_flashbulb   ← retroactive detection

        Returns a live Mimir instance loaded from the new data.
        """
        src = Path(src_dir)
        dst = Path(dest_dir) if dest_dir else src

        # ── Read VividnessMem data ────────────────────────────────────
        def _rj(p: Path):
            try:
                with open(p, "r", encoding="utf-8") as f:
                    return json.load(f)
            except (FileNotFoundError, json.JSONDecodeError):
                return None

        # Brief → mood
        brief = _rj(src / "brief.json") or {}
        mood_list = brief.get("mood", [0.0, 0.0, 0.0])
        mood_tuple = tuple(mood_list) if isinstance(mood_list, list) else (0.0, 0.0, 0.0)

        # Self memories
        raw_mems = _rj(src / "self_memory.json") or []

        # Social memories
        raw_social: dict[str, list[dict]] = {}
        social_dir = src / "social"
        if social_dir.exists():
            for fp in social_dir.glob("*.json"):
                data = _rj(fp)
                if isinstance(data, list) and data:
                    entity = data[0].get("entity", fp.stem)
                    raw_social[entity] = data

        # Chemistry
        raw_chem = _rj(src / "neurochemistry.json")

        # ── Back-fill Mimir-specific fields ───────────────────────────
        def _backfill(d: dict) -> dict:
            # encoding_mood ← from session mood at migration time
            if "encoding_mood" not in d:
                d["encoding_mood"] = list(mood_tuple)
            # emotion_pad ← derive from emotion label
            if "emotion_pad" not in d:
                vec = _emotion_to_vector(d.get("emotion", "neutral"))
                d["emotion_pad"] = list(vec) if vec else None
            # mentioned_dates ← extract from content
            if "mentioned_dates" not in d:
                d["mentioned_dates"] = _extract_dates(
                    d.get("content", ""))
            # Retroactive flashbulb detection
            if "is_flashbulb" not in d:
                imp = d.get("importance", 5)
                emo = d.get("emotion", "neutral")
                vec = _emotion_to_vector(emo)
                arousal = abs(vec[1]) if vec else 0.0
                d["is_flashbulb"] = (
                    arousal >= FLASHBULB_AROUSAL_THRESHOLD
                    and imp >= FLASHBULB_IMPORTANCE_MIN)
            return d

        backfilled_mems = [_backfill(dict(d)) for d in raw_mems]
        backfilled_social = {
            entity: [_backfill(dict(d)) for d in mems]
            for entity, mems in raw_social.items()
        }

        # ── Write Mimir-format data ───────────────────────────────────
        dst = Path(dst)
        dst.mkdir(parents=True, exist_ok=True)

        def _wj(p: Path, data):
            p.parent.mkdir(parents=True, exist_ok=True)
            tmp = p.with_suffix(".tmp")
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=1)
            tmp.replace(p)

        _wj(dst / "reflections.json", backfilled_mems)

        social_out = dst / "social"
        social_out.mkdir(parents=True, exist_ok=True)
        for entity, mems in backfilled_social.items():
            fname = re.sub(r'[^\w]', '_', entity.lower()) + ".json"
            _wj(social_out / fname, mems)

        _wj(dst / "meta.json", {"mood": list(mood_tuple),
                                "session_count": brief.get("session_count", 0)})

        if raw_chem:
            _wj(dst / "chemistry.json", raw_chem)

        # Empty containers for Mimir-only types
        for name in ("lessons.json", "reminders.json", "facts.json"):
            p = dst / name
            if not p.exists():
                _wj(p, [])

        # Copy emotional audit log if present
        audit_src = src / "emotional_audit.jsonl"
        if audit_src.exists():
            import shutil
            shutil.copy2(audit_src, dst / "emotional_audit.jsonl")

        # Copy VividEmbed index if present (embed_index/ → embed/)
        embed_src = src / "embed_index"
        embed_dst = dst / "embed"
        if embed_src.exists():
            import shutil
            embed_dst.mkdir(parents=True, exist_ok=True)
            for fp in embed_src.glob("*"):
                if fp.is_file():
                    shutil.copy2(fp, embed_dst / fp.name)

        # ── Return a live Mimir instance ──────────────────────────────
        instance = cls(data_dir=str(dst), chemistry=raw_chem is not None)

        # Bulk-index into VividEmbed if it loaded but has no entries
        if (instance._embed is not None
                and not instance._embed._entries):
            all_dicts = list(backfilled_mems)
            for mems in backfilled_social.values():
                all_dicts.extend(mems)
            try:
                instance._embed.index_from_vividnessmem(all_dicts)
                instance._embed.save()
            except Exception:
                pass  # embed is optional; migration still succeeds

        return instance

    # ══════════════════════════════════════════════════════════════════
    #  Reconsolidation drift detection (enhanced — mechanism #16)
    # ══════════════════════════════════════════════════════════════════

    def detect_drift(self, include_reframed: bool = False) -> list[Memory]:
        """Return memories whose emotion has drifted significantly
        from their original encoding.

        Compares the current PAD vector against the original_emotion
        baseline.  Memories exceeding DRIFT_ALERT_THRESHOLD are
        returned sorted by magnitude (largest first) and logged to
        the audit trail.

        Deliberately reframed memories are excluded by default.
        Pass *include_reframed=True* to see them too.
        """
        drifted = [
            m for m in self._reflections
            if m.has_drifted
            and m.source not in ("huginn", "volva")
            and (include_reframed or not m._reframed)]
        drifted.sort(key=lambda m: m.drift_magnitude, reverse=True)
        for m in drifted:
            self._audit.log(
                "reconsolidation_drift",
                emotion=m.emotion,
                source="drift_monitor",
                details={
                    "original_emotion": m.original_emotion,
                    "current_emotion": m.emotion,
                    "drift_magnitude": round(m.drift_magnitude, 3),
                    "content_preview": m.content[:60],
                })
        return drifted

    def drift_analysis(self) -> dict:
        """Enhanced drift detection — deeper pattern analysis.

        Returns a dict with:
        - drifted: list of drifted memories (same as detect_drift)
        - drift_direction: dict mapping each dimension shift
        - cognitive_biases: detected bias patterns
        - drift_velocity: how fast drift is occurring (per drifted memory)
        """
        drifted = self.detect_drift(include_reframed=True)

        # ── Drift direction analysis ──────────────────────────────────
        # Classify drifts by which PAD dimension shifted most
        directions: list[dict] = []
        for m in drifted:
            orig = _emotion_to_vector(m.original_emotion)
            curr = m._emotion_pad
            if not orig or not curr:
                continue
            deltas = {
                "pleasure": curr[0] - orig[0],
                "arousal": curr[1] - orig[1],
                "dominance": curr[2] - orig[2],
            }
            primary = max(deltas, key=lambda k: abs(deltas[k]))
            directions.append({
                "memory": m.content[:60],
                "original": m.original_emotion,
                "current": m.emotion,
                "magnitude": round(m.drift_magnitude, 3),
                "primary_axis": primary,
                "delta": {k: round(v, 3) for k, v in deltas.items()},
                "reframed": m._reframed,
            })

        # ── Cognitive bias detection ──────────────────────────────────
        biases: list[dict] = []

        # Negativity bias: are most memories drifting toward negative?
        if len(drifted) >= 3:
            neg_drift = sum(
                1 for d in directions
                if d["delta"]["pleasure"] < -0.1)
            if neg_drift / len(drifted) >= COGNITIVE_BIAS_THRESHOLD:
                biases.append({
                    "type": "negativity_drift",
                    "description": (
                        f"{neg_drift}/{len(drifted)} memories drifting "
                        f"toward negative — possible negativity bias"),
                    "severity": round(neg_drift / len(drifted), 2),
                })

        # Positivity fixation: opposite direction
        if len(drifted) >= 3:
            pos_drift = sum(
                1 for d in directions
                if d["delta"]["pleasure"] > 0.1)
            if pos_drift / len(drifted) >= COGNITIVE_BIAS_THRESHOLD:
                biases.append({
                    "type": "positivity_fixation",
                    "description": (
                        f"{pos_drift}/{len(drifted)} memories drifting "
                        f"toward positive — possible rose-tinting"),
                    "severity": round(pos_drift / len(drifted), 2),
                })

        # Arousal escalation: memories getting more intense
        if len(drifted) >= 3:
            arousal_up = sum(
                1 for d in directions
                if d["delta"]["arousal"] > 0.1)
            if arousal_up / len(drifted) >= COGNITIVE_BIAS_THRESHOLD:
                biases.append({
                    "type": "arousal_escalation",
                    "description": (
                        f"{arousal_up}/{len(drifted)} memories gaining "
                        f"arousal — emotional amplification pattern"),
                    "severity": round(arousal_up / len(drifted), 2),
                })

        # Emotional tunnel: overall memory valence one-sided
        all_mems = [m for m in self._reflections
                    if m.source not in ("huginn", "volva")]
        if len(all_mems) >= 5:
            pleasures = []
            for m in all_mems:
                v = _emotion_to_vector(m.emotion)
                if v:
                    pleasures.append(v[0])
            if pleasures:
                pos_count = sum(1 for p in pleasures if p > 0.2)
                neg_count = sum(1 for p in pleasures if p < -0.2)
                total = len(pleasures)
                if pos_count / total >= COGNITIVE_BIAS_THRESHOLD:
                    biases.append({
                        "type": "positive_tunnel",
                        "description": (
                            f"{pos_count}/{total} memories are positive-valence "
                            f"— may be neglecting negative experiences"),
                        "severity": round(pos_count / total, 2),
                    })
                elif neg_count / total >= COGNITIVE_BIAS_THRESHOLD:
                    biases.append({
                        "type": "negative_tunnel",
                        "description": (
                            f"{neg_count}/{total} memories are negative-valence "
                            f"— may be neglecting positive experiences"),
                        "severity": round(neg_count / total, 2),
                    })

        # Log biases to audit
        for b in biases:
            self._audit.log(
                "cognitive_bias_detected",
                source="drift_analysis",
                details=b)

        return {
            "drifted": drifted,
            "directions": directions,
            "cognitive_biases": biases,
            "total_memories": len(self._reflections),
            "drift_rate": (
                round(len(drifted) / max(len(self._reflections), 1), 3)),
        }

    # ══════════════════════════════════════════════════════════════════
    #  Huginn — Thought (pattern detection, mechanism #11)
    # ══════════════════════════════════════════════════════════════════

    def huginn(self) -> list[Memory]:
        """Odin's raven of Thought — scans all memories for emergent
        patterns and generates insight memories the agent never
        explicitly stored.

        Detects:
        1. Entity sentiment arcs  (3+ impressions -> trend direction)
        2. Recurring theme clusters (3+ memories sharing keywords)
        3. Open threads            (unresolved intentions)
        4. Reconsolidation drift   (emotions that shifted from baseline)

        Returns newly created insight memories (source='huginn').
        """
        insights: list[Memory] = []

        # ── 1. Entity sentiment arcs ──────────────────────────────────
        for entity, mems in self._social.items():
            if len(mems) < HUGINN_PATTERN_MIN:
                continue
            # Sort by timestamp
            sorted_mems = sorted(mems, key=lambda m: m.timestamp)
            # Map emotions to pleasure dimension
            pleasures = []
            for m in sorted_mems:
                vec = _emotion_to_vector(m.emotion)
                if vec:
                    pleasures.append(vec[0])
            if len(pleasures) < HUGINN_PATTERN_MIN:
                continue
            # Simple trend: compare first half avg to second half avg
            mid = len(pleasures) // 2
            first_avg = sum(pleasures[:mid]) / max(mid, 1)
            second_avg = sum(pleasures[mid:]) / max(len(pleasures) - mid, 1)
            delta = second_avg - first_avg
            if abs(delta) < 0.15:
                continue  # no meaningful trend
            direction = "warming" if delta > 0 else "cooling"
            early_emo = sorted_mems[0].emotion
            recent_emo = sorted_mems[-1].emotion
            content = (
                f"My relationship with {entity} has been {direction} — "
                f"early on I felt {early_emo}, more recently {recent_emo}")
            # Check we haven't already generated this insight
            if not any(entity in m.content and "relationship" in m.content
                       for m in self._reflections if m.source == "huginn"):
                mem = self.remember(
                    content, emotion="reflective",
                    importance=6, source="huginn",
                    why_saved="pattern detected by Huginn")
                insights.append(mem)

        # ── 2. Recurring theme clusters ───────────────────────────────
        # Build word→memory mapping (skip huginn/volva insights)
        word_mems: dict[str, list[int]] = {}
        for i, m in enumerate(self._reflections):
            if m.source in ("huginn", "volva"):
                continue
            for w in m.content_words:
                if len(w) >= 4:  # skip short words
                    if w not in word_mems:
                        word_mems[w] = []
                    word_mems[w].append(i)
        # Find words appearing in HUGINN_PATTERN_MIN+ distinct memories
        for word, indices in word_mems.items():
            if len(indices) < HUGINN_PATTERN_MIN:
                continue
            mems_for_word = [self._reflections[i] for i in indices]
            emotions = [m.emotion for m in mems_for_word]
            # Get the dominant emotion
            emotion_counts: dict[str, int] = {}
            for e in emotions:
                emotion_counts[e] = emotion_counts.get(e, 0) + 1
            dominant = max(emotion_counts, key=emotion_counts.get)
            content = (
                f"I notice '{word}' comes up often in my memories "
                f"(mentioned {len(indices)} times) — the feeling is "
                f"usually {dominant}")
            if not any(f"'{word}'" in m.content
                       for m in self._reflections if m.source == "huginn"):
                mem = self.remember(
                    content, emotion="thoughtful",
                    importance=4, source="huginn",
                    why_saved="recurring theme detected by Huginn")
                insights.append(mem)

        # ── 3. Open threads (unresolved intentions) ───────────────────
        for i, m in enumerate(self._reflections):
            if m.source in ("huginn", "volva"):
                continue
            words = set(m.content.lower().split())
            if not words & HUGINN_OPEN_THREAD_WORDS:
                continue
            # Check if any later memory resolves it
            m_words = m.content_words
            resolved = False
            for j in range(i + 1, len(self._reflections)):
                later = self._reflections[j]
                if later.source in ("huginn", "volva"):
                    continue
                overlap = _overlap_ratio(m_words, later.content_words)
                if overlap >= 0.3:
                    resolved = True
                    break
            if not resolved and m.vividness > 0.05:
                age_days = (
                    datetime.now()
                    - datetime.fromisoformat(m.timestamp)
                ).total_seconds() / 86400
                if age_days > 3:  # only flag if it's been a while
                    content = (
                        f"Unresolved thread: '{m.content[:80]}' "
                        f"— this has been on my mind for "
                        f"{int(age_days)} days")
                    if not any(m.content[:40] in mem.content
                               for mem in self._reflections
                               if mem.source == "huginn"):
                        mem = self.remember(
                            content, emotion="thoughtful",
                            importance=5, source="huginn",
                            why_saved="open thread detected by Huginn")
                        insights.append(mem)

        # ── 4. Reconsolidation drift alerts ────────────────────────
        drifted = self.detect_drift()
        for m in drifted:
            content = (
                f"Drift alert: my memory of '{m.content[:60]}' "
                f"was originally {m.original_emotion} but now "
                f"feels {m.emotion} (drift: {m.drift_magnitude:.2f})")
            if not any(m.content[:40] in mem.content
                       for mem in self._reflections
                       if mem.source == "huginn"):
                mem = self.remember(
                    content, emotion="thoughtful",
                    importance=4, source="huginn",
                    why_saved="reconsolidation drift detected by Huginn")
                insights.append(mem)

        return insights

    # ══════════════════════════════════════════════════════════════════
    #  Muninn — Memory (consolidation daemon, mechanism #12)
    # ══════════════════════════════════════════════════════════════════

    def muninn(self) -> dict:
        """Odin's raven of Memory — consolidation daemon.

        1. Merge near-duplicate memories (Jaccard 0.55–0.65)
        2. Prune dead memories (vividness < 0.01, unless protected)
        3. Strengthen co-activated memory pairs (same entity/day)

        Returns stats: {'merged': N, 'pruned': N, 'strengthened': N}
        """
        merged = 0
        pruned = 0
        strengthened = 0

        # ── 1. Merge near-duplicates ──────────────────────────────────
        # Find pairs above merge threshold but not yet deduped
        to_remove: set[int] = set()
        n = len(self._reflections)
        for i in range(n):
            if i in to_remove:
                continue
            mi = self._reflections[i]
            wi = mi.content_words
            if not wi:
                continue
            for j in range(i + 1, n):
                if j in to_remove:
                    continue
                mj = self._reflections[j]
                overlap = _overlap_ratio(wi, mj.content_words)
                if overlap >= MUNINN_MERGE_THRESHOLD:
                    # Merge j into i (keep the one with more content)
                    keeper, donor = (mi, mj) if len(mi.content) >= len(mj.content) else (mj, mi)
                    keeper.importance = max(keeper.importance, donor.importance)
                    keeper._stability = max(
                        keeper._stability, donor._stability)
                    keeper._access_count += donor._access_count
                    if donor._is_flashbulb:
                        keeper._is_flashbulb = True
                    if donor._cherished:
                        keeper._cherished = True
                    if donor._anchor:
                        keeper._anchor = True
                    # Remove embed entry for donor
                    if self._embed and donor._embed_uid:
                        try:
                            self._embed.remove(donor._embed_uid)
                        except Exception:
                            pass
                    to_remove.add(j if keeper is mi else i)
                    merged += 1

        # ── 2. Prune dead memories ────────────────────────────────────
        for i in range(n):
            if i in to_remove:
                continue
            m = self._reflections[i]
            if (m.vividness < MUNINN_PRUNE_THRESHOLD
                    and not m._is_flashbulb
                    and not m._anchor
                    and not m._cherished
                    and m.source not in ("huginn", "volva")):
                # Remove embed entry
                if self._embed and m._embed_uid:
                    try:
                        self._embed.remove(m._embed_uid)
                    except Exception:
                        pass
                to_remove.add(i)
                pruned += 1

        # Apply removals
        if to_remove:
            self._reflections = [
                m for i, m in enumerate(self._reflections)
                if i not in to_remove]
            self._rebuild_index()

        # ── 3. Strengthen co-activated pairs ──────────────────────────
        # Memories about the same entity or created on the same day
        day_groups: dict[str, list[Memory]] = {}
        for m in self._reflections:
            day = m.timestamp[:10]  # YYYY-MM-DD
            if day not in day_groups:
                day_groups[day] = []
            day_groups[day].append(m)

        for day, group in day_groups.items():
            if len(group) >= 2:
                for m in group:
                    m._stability = min(
                        m._stability * MUNINN_COACTIVATION_BOOST,
                        STABILITY_CAP)
                    strengthened += 1

        self._audit.log("muninn_consolidation",
                        details={"merged": merged, "pruned": pruned,
                                 "strengthened": strengthened})

        return {"merged": merged, "pruned": pruned,
                "strengthened": strengthened}

    # ══════════════════════════════════════════════════════════════════
    #  Gist Compression (Reyna & Brainerd 1995 — Fuzzy Trace Theory)
    # ══════════════════════════════════════════════════════════════════

    def _compress_to_gist(self) -> int:
        """Compress old, low-importance memories to gist form.

        Memories older than GIST_AGE_THRESHOLD_DAYS that are not protected
        (flashbulb, anchor, cherished) get their stored content truncated
        to GIST_PRESERVE_WORDS — mimicking how episodic detail fades to
        semantic knowledge over time.

        Returns the number of memories compressed.
        """
        now = datetime.now()
        compressed = 0
        for m in self._reflections:
            if m._is_flashbulb or m._anchor or m._cherished:
                continue
            if m.source in ("huginn", "volva"):
                continue
            try:
                age_days = (
                    now - datetime.fromisoformat(m.timestamp)
                ).total_seconds() / 86400
            except Exception:
                continue
            if age_days < GIST_AGE_THRESHOLD_DAYS:
                continue
            words = m.content.split()
            if len(words) <= GIST_PRESERVE_WORDS:
                continue
            preserved = " ".join(words[:GIST_PRESERVE_WORDS])
            m.content = f"[gist — {m.emotion}] {preserved}…"
            m._content_words = None  # force re-computation
            compressed += 1
        if compressed:
            self._rebuild_index()
        return compressed

    # ══════════════════════════════════════════════════════════════════
    #  Memory Chunking (Miller 1956 — 7±2 capacity)
    # ══════════════════════════════════════════════════════════════════

    def chunk_memories(self) -> int:
        """Fuse clusters of related memories into richer composite chunks.

        Finds groups of 3+ memories with overlapping content words (above
        CHUNK_OVERLAP_THRESHOLD but below dedup threshold), then merges
        each cluster into a single composite memory.  Protected memories
        (flashbulb, anchor, cherished) survive as standalone.

        Returns the number of chunks created.
        """
        n = len(self._reflections)
        if n < CHUNK_MIN_GROUP:
            return 0

        word_sets = [m.content_words for m in self._reflections]
        adjacency: dict[int, set[int]] = {i: set() for i in range(n)}
        for i in range(n):
            if not word_sets[i]:
                continue
            mi = self._reflections[i]
            if mi.source in ("huginn", "volva", "chunk"):
                continue
            for j in range(i + 1, n):
                if not word_sets[j]:
                    continue
                mj = self._reflections[j]
                if mj.source in ("huginn", "volva", "chunk"):
                    continue
                overlap = _overlap_ratio(word_sets[i], word_sets[j])
                if CHUNK_OVERLAP_THRESHOLD <= overlap < _DEDUP_THRESHOLD:
                    adjacency[i].add(j)
                    adjacency[j].add(i)

        used: set[int] = set()
        clusters: list[list[int]] = []
        nodes_by_degree = sorted(adjacency.keys(),
                                 key=lambda x: len(adjacency[x]), reverse=True)
        for seed in nodes_by_degree:
            if seed in used:
                continue
            if len(adjacency[seed]) < CHUNK_MIN_GROUP - 1:
                continue
            cluster = {seed}
            for neighbor in adjacency[seed]:
                if neighbor not in used:
                    cluster.add(neighbor)
            if len(cluster) >= CHUNK_MIN_GROUP:
                clusters.append(sorted(cluster))
                used |= cluster

        chunks_created = 0
        to_remove: set[int] = set()
        for cluster in clusters:
            mems = [self._reflections[i] for i in cluster]
            all_words: list[str] = []
            seen_words: set[str] = set()
            for m in sorted(mems, key=lambda x: x.importance, reverse=True):
                for w in m.content.split():
                    lw = w.lower().strip(".,!?;:'\"")
                    if lw not in seen_words and lw not in _DEDUP_STOP:
                        all_words.append(w)
                        seen_words.add(lw)
                    if len(all_words) >= CHUNK_MAX_CONTENT_WORDS:
                        break

            emotion_counts: dict[str, int] = {}
            for m in mems:
                emotion_counts[m.emotion] = emotion_counts.get(m.emotion, 0) + 1
            dominant_emotion = max(emotion_counts, key=emotion_counts.get)

            entity = ""
            for m in sorted(mems, key=lambda x: x.importance, reverse=True):
                if m.entity:
                    entity = m.entity
                    break

            chunk_content = " ".join(all_words)
            max_imp = max(m.importance for m in mems)
            max_stab = max(m._stability for m in mems)

            chunk_mem = Memory(
                content=f"[chunk: {len(mems)} memories] {chunk_content}",
                emotion=dominant_emotion,
                importance=min(10, max_imp + 1),
                source="chunk",
                entity=entity,
                why_saved=f"chunked from {len(mems)} related memories")
            chunk_mem._stability = min(max_stab * 1.2, STABILITY_CAP)
            chunk_mem._encoding_mood = self._mood
            if any(m._is_flashbulb for m in mems):
                chunk_mem._is_flashbulb = True
            if any(m._cherished for m in mems):
                chunk_mem._cherished = True
            if any(m._anchor for m in mems):
                chunk_mem._anchor = True

            self._reflections.append(chunk_mem)

            for i in cluster:
                m = self._reflections[i]
                if not (m._is_flashbulb or m._anchor or m._cherished):
                    if self._embed and m._embed_uid:
                        try:
                            self._embed.remove(m._embed_uid)
                        except Exception:
                            pass
                    to_remove.add(i)

            if self._embed is not None:
                try:
                    entry = self._embed.add(
                        content=chunk_mem.content,
                        emotion=dominant_emotion,
                        importance=chunk_mem.importance,
                        stability=chunk_mem._stability)
                    chunk_mem._embed_uid = entry.uid
                except Exception:
                    pass

            chunks_created += 1

        if to_remove:
            self._reflections = [
                m for i, m in enumerate(self._reflections)
                if i not in to_remove]
            self._rebuild_index()

        if chunks_created:
            self._audit.log("chunk_memories",
                            details={"chunks_created": chunks_created,
                                     "memories_absorbed": len(to_remove)})

        return chunks_created

    # ══════════════════════════════════════════════════════════════════
    #  Yggdrasil — World Tree (memory graph, mechanism #13)
    # ══════════════════════════════════════════════════════════════════

    def _build_yggdrasil(self):
        """Build the memory graph from scratch.

        Six edge types:
        - entity:       memories sharing the same entity reference
        - lexical:      significant word overlap (related, not duplicate)
        - temporal:     created within the same 3-day window
        - emotional:    same emotion label
        - task_origin:  memories linked to the same task
        - caused_lesson: memory that spawned a lesson, or vice versa
        """
        self._yggdrasil = {}
        n = len(self._reflections)
        if n < 2:
            return

        # Pre-compute per-memory data
        words = [m.content_words for m in self._reflections]
        days = []
        for m in self._reflections:
            try:
                days.append(
                    datetime.fromisoformat(m.timestamp).timestamp()
                    / 86400)
            except Exception:
                days.append(0.0)
        entities = [m.entity.lower() for m in self._reflections]
        emotions = [m.emotion.lower() for m in self._reflections]

        # ── Cross-hierarchy index: gather memory indices linked to
        #    the same task or lesson ──────────────────────────────────
        task_groups: dict[str, list[int]] = {}
        for t in self._project_tasks:
            if t._memory_indices:
                task_groups[t.task_id] = [
                    i for i in t._memory_indices if i < n]

        lesson_linked: set[tuple[int, int]] = set()
        for les in self._lessons:
            if les._source_memory_idx >= 0 and les._source_memory_idx < n:
                # Link the source memory to other memories near it
                src = les._source_memory_idx
                for i in range(max(0, src - 2), min(n, src + 3)):
                    if i != src:
                        lesson_linked.add((src, i))
                        lesson_linked.add((i, src))

        # Build edges
        for i in range(n):
            edges: list[tuple[int, str, float]] = []
            for j in range(n):
                if i == j:
                    continue
                best_type = None
                best_strength = 0.0

                # Entity edge
                if entities[i] and entities[i] == entities[j]:
                    best_type = "entity"
                    best_strength = 0.8

                # Lexical edge
                if words[i] and words[j]:
                    overlap = _overlap_ratio(words[i], words[j])
                    if (YGGDRASIL_WORD_EDGE_MIN <= overlap
                            <= YGGDRASIL_WORD_EDGE_MAX):
                        if overlap > best_strength:
                            best_type = "lexical"
                            best_strength = overlap

                # Temporal edge
                if abs(days[i] - days[j]) <= YGGDRASIL_TEMPORAL_DAYS:
                    temporal_str = 1.0 - (
                        abs(days[i] - days[j]) / YGGDRASIL_TEMPORAL_DAYS)
                    if temporal_str > best_strength:
                        best_type = "temporal"
                        best_strength = temporal_str

                # Emotional edge (same emotion, decent vividness)
                if (emotions[i] == emotions[j]
                        and emotions[i] != "neutral"):
                    if 0.5 > best_strength:
                        best_type = "emotional"
                        best_strength = 0.5

                if best_type and best_strength >= YGGDRASIL_WORD_EDGE_MIN:
                    edges.append((j, best_type, best_strength))

                # Cross-hierarchy edges are additive — they represent
                # structural relationships that coexist with content edges.
                is_task_linked = False
                for _, members in task_groups.items():
                    if i in members and j in members:
                        is_task_linked = True
                        break
                if is_task_linked:
                    edges.append((j, "task_origin", 0.75))

                if (i, j) in lesson_linked:
                    edges.append((j, "caused_lesson", 0.65))

            # Keep only top N edges per node (sorted by strength)
            edges.sort(key=lambda e: e[2], reverse=True)
            self._yggdrasil[i] = edges[:YGGDRASIL_MAX_EDGES]

        # ── LLM-inferred edges (if available) ─────────────────────────
        if self._llm_fn and self._inferred_edges:
            for (src, tgt), strength in self._inferred_edges.items():
                if src < n and tgt < n:
                    edges = self._yggdrasil.get(src, [])
                    # Only add if not already connected
                    existing_targets = {e[0] for e in edges}
                    if tgt not in existing_targets:
                        edges.append((tgt, "inferred", strength))
                        edges.sort(key=lambda e: e[2], reverse=True)
                        self._yggdrasil[src] = edges[:YGGDRASIL_MAX_EDGES]

    def _infer_relations(self, mem_idx: int):
        """Use LLM to discover implicit relationships between a new memory
        and recent memories that lexical/temporal overlap alone would miss.

        This is the Enhanced Relational Reasoning layer — it finds connections
        like 'hiking' being related to 'sunny weather' even when they share
        no words. Runs only when llm_fn is available.
        """
        if not self._llm_fn or mem_idx >= len(self._reflections):
            return

        new_mem = self._reflections[mem_idx]
        # Sample recent memories (max 15) that aren't already connected
        existing_targets = {
            e[0] for e in self._yggdrasil.get(mem_idx, [])}
        candidates = []
        for i in range(max(0, mem_idx - 30), mem_idx):
            if i not in existing_targets:
                candidates.append((i, self._reflections[i]))
        if not candidates:
            return

        # Build a compact prompt
        mem_lines = []
        for i, (idx, m) in enumerate(candidates[-15:]):
            mem_lines.append(f"[{i}] {m.gist}")

        prompt = (
            "Given this NEW memory and these EXISTING memories, identify "
            "which existing memories are implicitly related (not by shared "
            "words, but by causal, thematic, or contextual connections). "
            "Return ONLY the indices of related memories, one per line, "
            "with a confidence score 0.3-0.9. Format: idx score\n"
            "Return nothing if no implicit connections exist.\n\n"
            f"NEW: {new_mem.gist}\n\n"
            "EXISTING:\n" + "\n".join(mem_lines)
        )
        try:
            response = self._llm_fn(prompt)
        except Exception:
            return

        # Parse response and store inferred edges
        sample = candidates[-15:]
        for line in response.strip().split("\n"):
            parts = line.strip().split()
            if len(parts) < 2:
                continue
            try:
                local_idx = int(parts[0])
                strength = float(parts[1])
            except (ValueError, IndexError):
                continue
            if 0 <= local_idx < len(sample) and 0.3 <= strength <= 0.9:
                real_idx = sample[local_idx][0]
                # Store bidirectionally
                self._inferred_edges[(mem_idx, real_idx)] = strength
                self._inferred_edges[(real_idx, mem_idx)] = strength
                # Add directly to live graph
                for src, tgt in [(mem_idx, real_idx), (real_idx, mem_idx)]:
                    edges = self._yggdrasil.get(src, [])
                    existing = {e[0] for e in edges}
                    if tgt not in existing:
                        edges.append((tgt, "inferred", strength))
                        edges.sort(key=lambda e: e[2], reverse=True)
                        self._yggdrasil[src] = edges[:YGGDRASIL_MAX_EDGES]

    def _spreading_activation(
        self,
        seed_indices: set[int],
        hops: int = SPREADING_ACTIVATION_HOPS,
        decay: float = SPREADING_ACTIVATION_DECAY,
        threshold: float = SPREADING_ACTIVATION_THRESHOLD,
    ) -> dict[int, float]:
        """Collins & Loftus 1975 — true spreading activation on Yggdrasil.

        Fire activation from seed nodes (the initial recall candidates
        found by BM25 + semantic search).  Activation propagates through
        Yggdrasil's edge types with exponential decay per hop and
        attenuation by edge strength.

        Returns {memory_index: accumulated_activation} for every node
        that received activation above *threshold*.  Nodes NOT in the
        seed set represent organically-discovered associative memories.
        """
        if not self._yggdrasil:
            return {}

        activation: dict[int, float] = {}
        for idx in seed_indices:
            activation[idx] = 1.0

        frontier = set(seed_indices)
        for hop in range(hops):
            next_frontier: set[int] = set()
            hop_decay = decay ** (hop + 1)
            for node in frontier:
                for target, _etype, strength in self._yggdrasil.get(node, []):
                    transmitted = hop_decay * strength
                    if transmitted < threshold:
                        continue
                    prev = activation.get(target, 0.0)
                    activation[target] = prev + transmitted
                    if target not in seed_indices:
                        next_frontier.add(target)
            frontier = next_frontier
            if not frontier:
                break

        return activation

    def enrich_yggdrasil(self, batch_size: int = 20) -> int:
        """Batch-enrich Yggdrasil with LLM-inferred relationships.

        Scans recent memories without inferred edges and runs relational
        reasoning on them. Returns the number of new edges created.
        """
        if not self._llm_fn:
            return 0
        n = len(self._reflections)
        before = len(self._inferred_edges)
        start = max(0, n - batch_size)
        for i in range(start, n):
            # Skip if already has inferred edges
            has_inferred = any(
                src == i for (src, _) in self._inferred_edges)
            if not has_inferred:
                self._infer_relations(i)
        return (len(self._inferred_edges) - before) // 2  # bidirectional

    def yggdrasil_roots(self) -> list[Memory]:
        """Return the roots of the World Tree — anchor and high-importance
        memories that form the foundation of identity."""
        roots = [
            m for m in self._reflections
            if m._anchor or m._is_flashbulb or m.importance >= 9]
        return sorted(roots, key=lambda m: m.vividness, reverse=True)

    def yggdrasil_branches(self, memory: Memory) -> list[Memory]:
        """Return memories connected to the given memory in the graph."""
        try:
            idx = self._reflections.index(memory)
        except ValueError:
            return []
        edges = self._yggdrasil.get(idx, [])
        result = []
        for target_idx, edge_type, strength in edges:
            if target_idx < len(self._reflections):
                result.append(self._reflections[target_idx])
        return result

    def yggdrasil_traverse(self, memory: Memory,
                           depth: int = 2) -> list[Memory]:
        """BFS traversal from a memory, returning all reachable nodes
        within *depth* hops."""
        try:
            start = self._reflections.index(memory)
        except ValueError:
            return []
        visited: set[int] = {start}
        frontier = [start]
        for _ in range(depth):
            next_frontier: list[int] = []
            for idx in frontier:
                for target, _, _ in self._yggdrasil.get(idx, []):
                    if target not in visited and target < len(self._reflections):
                        visited.add(target)
                        next_frontier.append(target)
            frontier = next_frontier
        visited.discard(start)
        return [self._reflections[i] for i in sorted(visited)]

    def yggdrasil_path(self, a: Memory, b: Memory) -> list[Memory]:
        """Find shortest path between two memories in the graph.

        Returns the path as a list of Memory objects (including a and b),
        or an empty list if no path exists.
        """
        try:
            start = self._reflections.index(a)
            end = self._reflections.index(b)
        except ValueError:
            return []
        if start == end:
            return [a]

        # BFS
        from collections import deque
        queue: deque[list[int]] = deque([[start]])
        visited: set[int] = {start}
        while queue:
            path = queue.popleft()
            current = path[-1]
            for target, _, _ in self._yggdrasil.get(current, []):
                if target == end:
                    full = path + [target]
                    return [self._reflections[i] for i in full]
                if target not in visited and target < len(self._reflections):
                    visited.add(target)
                    queue.append(path + [target])
        return []

    # ══════════════════════════════════════════════════════════════════
    #  Völva's Vision — Dream Synthesis (mechanism #14)
    # ══════════════════════════════════════════════════════════════════

    def volva_dream(self, n_samples: int | None = None) -> list[Memory]:
        """The Völva's trance — dream synthesis during rest.

        Samples random pairs of memories and seeks hidden connections:
        1. Emotional arcs   — same entity/topic, different emotions
        2. Temporal patterns — events clustering at similar times
        3. Theme bridges     — distant memories sharing a hidden thread

        Returns newly created dream-insight memories (source='volva').
        """
        n = n_samples or VOLVA_SAMPLE_PAIRS
        if len(self._reflections) < 4:
            return []

        # Filter out previous insights so we dream about real memories
        real_mems = [
            m for m in self._reflections
            if m.source not in ("huginn", "volva")]
        if len(real_mems) < 4:
            return []

        insights: list[Memory] = []
        seen_pairs: set[tuple[str, str]] = set()

        for _ in range(n):
            a, b = random.sample(real_mems, 2)
            # Avoid duplicate pair analysis
            pair_key = tuple(sorted([a.timestamp, b.timestamp]))
            if pair_key in seen_pairs:
                continue
            seen_pairs.add(pair_key)

            a_words = a.content_words
            b_words = b.content_words
            shared = a_words & b_words

            # ── Emotional arc: same topic, different emotions ─────────
            if (shared and len(shared) >= 2
                    and a.emotion != b.emotion):
                # Determine chronological order
                earlier, later = (
                    (a, b) if a.timestamp <= b.timestamp else (b, a))
                bridge_words = ", ".join(sorted(shared)[:3])
                content = (
                    f"Dream insight: regarding '{bridge_words}', "
                    f"my feeling shifted from {earlier.emotion} to "
                    f"{later.emotion} over time")
                if not any(bridge_words in m.content
                           for m in self._reflections
                           if m.source == "volva"):
                    mem = self.remember(
                        content, emotion="reflective",
                        importance=VOLVA_INSIGHT_IMPORTANCE,
                        source="volva",
                        why_saved="dream synthesis by Völva")
                    insights.append(mem)
                continue

            # ── Theme bridge: distant memories with hidden thread ─────
            if shared and len(shared) >= 3:
                age_a = (datetime.now()
                         - datetime.fromisoformat(a.timestamp)
                         ).total_seconds() / 86400
                age_b = (datetime.now()
                         - datetime.fromisoformat(b.timestamp)
                         ).total_seconds() / 86400
                if abs(age_a - age_b) > 30:  # at least a month apart
                    bridge = ", ".join(sorted(shared)[:4])
                    content = (
                        f"Dream insight: a thread connects two distant "
                        f"memories through '{bridge}' — perhaps there's "
                        f"a deeper pattern here")
                    if not any(bridge in m.content
                               for m in self._reflections
                               if m.source == "volva"):
                        mem = self.remember(
                            content, emotion="contemplative",
                            importance=VOLVA_INSIGHT_IMPORTANCE,
                            source="volva",
                            why_saved="dream synthesis by Völva")
                        insights.append(mem)
                continue

            # ── Temporal cluster: events on the same day ──────────────
            if a.timestamp[:10] == b.timestamp[:10]:
                day = a.timestamp[:10]
                same_day = [
                    m for m in real_mems if m.timestamp[:10] == day]
                if len(same_day) >= 3:
                    emotions = set(m.emotion for m in same_day)
                    content = (
                        f"Dream insight: a lot happened on {day} — "
                        f"I felt {', '.join(sorted(emotions))}. "
                        f"That was a significant day.")
                    if not any(day in m.content
                               for m in self._reflections
                               if m.source == "volva"):
                        mem = self.remember(
                            content, emotion="nostalgic",
                            importance=VOLVA_INSIGHT_IMPORTANCE,
                            source="volva",
                            why_saved="dream synthesis by Völva")
                        insights.append(mem)

        self._audit.log("volva_dream",
                        details={"insights_generated": len(insights)})
        return insights

    # ──────────────────────────────────────────────────────────────────
    #  Core: remember
    # ──────────────────────────────────────────────────────────────────

    def remember(self, content: str, emotion: str = "neutral",
                 importance: int = 5, source: str = "reflection",
                 why_saved: str = "") -> Memory:
        """Store an episodic memory.

        Neurochemistry modulates encoding.  High-arousal + high-importance
        memories become flashbulbs.  Novelty modulates encoding strength:
        highly novel memories get boosted importance, redundant ones get
        attenuated.  The current mood is captured for state-dependent
        retrieval later.
        """
        # Chemistry modulation
        mods = self._chemistry.get_modifiers()
        effective_importance = importance
        if mods["encoding_boost"] != 1.0:
            effective_importance = max(1, min(10, round(
                importance * mods["encoding_boost"])))

        self._chemistry.on_emotion(emotion)

        # ── Novelty detection (Ranganath & Rainer 2003) ───────────────
        # Compare against recent memories to gauge how novel this is
        new_words = _content_words(content)
        novelty = 1.0  # default: fully novel
        if self._reflections and new_words:
            recent = self._reflections[-NOVELTY_MAX_COMPARE:]
            overlaps = []
            for existing in recent:
                overlap = _overlap_ratio(new_words, existing.content_words)
                overlaps.append(overlap)
            avg_overlap = sum(overlaps) / len(overlaps)
            novelty = 1.0 - avg_overlap  # 0 = identical to recent, 1 = unique

            # Adaptive encoding: novel experiences encoded more strongly
            if novelty >= NOVELTY_HIGH_THRESHOLD:
                effective_importance = max(1, min(10, round(
                    effective_importance * NOVELTY_BOOST_FACTOR)))
            elif novelty <= NOVELTY_LOW_THRESHOLD:
                effective_importance = max(1, min(10, round(
                    effective_importance * NOVELTY_DECAY_FACTOR)))

        # Dedup check
        for i, existing in enumerate(self._reflections):
            if _overlap_ratio(new_words, existing.content_words) >= _DEDUP_THRESHOLD:
                merged = Memory(
                    content=content, emotion=emotion,
                    importance=max(effective_importance, existing.importance),
                    source=source, why_saved=why_saved or existing.why_saved)
                merged._access_count = existing._access_count
                merged._stability = existing._stability
                merged._last_access = existing._last_access
                merged.timestamp = existing.timestamp
                merged._encoding_mood = existing._encoding_mood or self._mood
                merged._is_flashbulb = existing._is_flashbulb
                merged._anchor = existing._anchor
                merged._cherished = existing._cherished
                merged._mentioned_dates = (
                    existing._mentioned_dates or _extract_dates(content))
                # Sync VividEmbed: remove stale entry, add updated one
                if self._embed is not None and existing._embed_uid:
                    try:
                        self._embed.remove(existing._embed_uid)
                    except Exception:
                        pass
                self._reflections[i] = merged
                self._rebuild_index()
                # Re-add merged content to VividEmbed
                if self._embed is not None:
                    try:
                        entry = self._embed.add(
                            content=content, emotion=emotion,
                            importance=merged.importance,
                            stability=merged._stability)
                        merged._embed_uid = entry.uid
                    except Exception:
                        pass
                return merged

        mem = Memory(content=content, emotion=emotion,
                     importance=effective_importance, source=source,
                     why_saved=why_saved)

        # Record novelty score for this memory
        mem._novelty_score = novelty

        # State-dependent encoding — capture the mood at creation
        mem._encoding_mood = self._mood

        # ── Narrative arc position (Freytag 1863) ─────────────────────
        mem._arc_position = _infer_arc_position(content, emotion)

        # ── Flashbulb detection ───────────────────────────────────────
        # High arousal + high importance → indelible encoding
        vec = _emotion_to_vector(emotion)
        arousal = abs(vec[1]) if vec else 0.0
        if (arousal >= FLASHBULB_AROUSAL_THRESHOLD
                and effective_importance >= FLASHBULB_IMPORTANCE_MIN):
            mem._is_flashbulb = True
            mem._stability = max(
                mem._stability, FLASHBULB_STABILITY_FLOOR)

        # Chemistry flashbulb (cortisol)
        if mods["flashbulb"] and not mem._is_flashbulb:
            mem._stability = max(mem._stability, STABILITY_CAP * 0.6)

        self._reflections.append(mem)
        self._index_memory(len(self._reflections) - 1, mem)

        # ── Hippocampal pattern separation (Yassa & Stark 2011) ───────
        # When two memories are similar but NOT identical, nudge their
        # importance apart so retrieval can distinguish them.
        new_idx = len(self._reflections) - 1
        for i, other in enumerate(self._reflections[:-1]):
            overlap = _overlap_ratio(new_words, other.content_words)
            if _DEDUP_THRESHOLD <= overlap < PATTERN_SEP_THRESHOLD:
                continue  # too similar → handled by dedup above
            if overlap >= PATTERN_SEP_THRESHOLD and overlap < 1.0:
                # Similar-but-different — separate by nudging importance
                if mem.importance >= other.importance:
                    mem._importance = min(10, mem.importance + PATTERN_SEP_NUDGE)
                    other._importance = max(1, other.importance - PATTERN_SEP_NUDGE)
                else:
                    other._importance = min(10, other.importance + PATTERN_SEP_NUDGE)
                    mem._importance = max(1, mem.importance - PATTERN_SEP_NUDGE)

        # ── Temporal date extraction (Tulving 1972) ───────────────────
        mem._mentioned_dates = _extract_dates(content)
        # Index dates
        idx = len(self._reflections) - 1
        for ds in mem._mentioned_dates:
            if ds not in self._date_index:
                self._date_index[ds] = set()
            self._date_index[ds].add(idx)

        # ── Prospective memory (Einstein & McDaniel 1990) ─────────────
        # Future-dated content auto-creates linked reminders
        if mem._mentioned_dates and effective_importance >= PROSPECTIVE_IMPORTANCE_MIN:
            now_date = datetime.now().date()
            for ds in mem._mentioned_dates:
                try:
                    mention_date = datetime.fromisoformat(ds).date()
                except ValueError:
                    continue
                if mention_date > now_date:
                    # Auto-create a reminder for 9 AM on that date
                    trigger = datetime(
                        mention_date.year, mention_date.month,
                        mention_date.day, 9, 0)
                    r = Reminder(content, trigger.isoformat())
                    self._reminders.append(r)

        # ── VividEmbed indexing ────────────────────────────────────────
        if self._embed is not None:
            try:
                entry = self._embed.add(
                    content=content, emotion=emotion,
                    importance=effective_importance,
                    stability=mem._stability)
                mem._embed_uid = entry.uid
            except Exception:
                pass

        # ── LLM-inferred relational reasoning ─────────────────────────
        # Discover non-obvious connections that lexical overlap misses
        if self._llm_fn and len(self._reflections) >= 5:
            self._infer_relations(len(self._reflections) - 1)

        return mem

    # ──────────────────────────────────────────────────────────────────
    #  Core: remember_visual (Kosslyn 1980 — Mental Imagery)
    # ──────────────────────────────────────────────────────────────────

    def remember_visual(
        self,
        image_data: bytes,
        description: str,
        emotion: str = "neutral",
        importance: int = 5,
        why_saved: str = "",
        source: str = "visual",
    ) -> Memory:
        """Store a visual memory with a compressed image attachment.

        The agent decides *whether* an image is worth keeping — it calls
        this method only when it judges the visual to be meaningful.

        The image is compressed to WebP and stored on disk; the Memory
        object tracks it via a content-addressable hash.  The text
        *description* (what the agent "sees") is indexed for retrieval.

        If visual memory is disabled (no Pillow or ``visual=False``),
        falls back to a regular text memory using the description.

        Returns the Memory (which has ``has_visual=True``).
        """
        if not self._visual_enabled:
            # Graceful fallback: store as text-only memory
            return self.remember(
                content=f"[image] {description}",
                emotion=emotion, importance=importance,
                source=source, why_saved=why_saved)

        # Compress and store image
        webp_bytes, dimensions = _compress_image(image_data)
        img_hash = _visual_hash(webp_bytes)
        img_path = self._visual_dir / f"{img_hash}.webp"
        if not img_path.exists():
            img_path.write_bytes(webp_bytes)

        # Create the episodic memory (description = searchable content)
        mem = self.remember(
            content=description,
            emotion=emotion, importance=importance,
            source=source, why_saved=why_saved)

        # Attach the visual reference
        mem._visual_hash = img_hash
        mem._visual_description = description
        mem._visual_dimensions = dimensions

        self._audit.log("visual_memory", emotion=emotion,
                        details={"hash": img_hash,
                                 "importance": importance})
        return mem

    def get_visual(self, memory: Memory) -> dict:
        """Retrieve a visual memory's image data with fading applied.

        Returns a dict with keys:
        - ``available``:   bool — whether any image can be shown
        - ``clarity``:     "vivid" | "faded" | "gist_only" | "none"
        - ``description``: str — the agent's original description
        - ``image_bytes``: bytes | None — WebP image data (if available)
        - ``dimensions``:  (w, h) tuple
        - ``hash``:        str — content hash

        The caller (UI layer) decides how to present the image.
        The agent decides *whether* to present it at conversation time.
        """
        result: dict[str, Any] = {
            "available": False,
            "clarity": memory.visual_clarity,
            "description": memory._visual_description,
            "image_bytes": None,
            "dimensions": memory._visual_dimensions,
            "hash": memory._visual_hash,
        }

        if not memory.has_visual:
            return result

        img_path = self._visual_dir / f"{memory._visual_hash}.webp"
        if not img_path.exists():
            return result

        raw = img_path.read_bytes()
        clarity = memory.visual_clarity

        if clarity == "vivid":
            # Full resolution — the agent "sees it clearly"
            result["image_bytes"] = raw
            result["available"] = True
        elif clarity == "faded":
            # Reduced quality — degraded mental image
            result["image_bytes"] = _decompress_image(
                raw, quality=VISUAL_QUALITY_FADED)
            result["available"] = True
        # gist_only → description available but no image

        return result

    def forget_visual(self, memory: Memory) -> bool:
        """Remove the visual attachment from a memory.

        The text description remains — only the image file is deleted.
        """
        if not memory.has_visual:
            return False
        img_path = self._visual_dir / f"{memory._visual_hash}.webp"
        # Only delete if no other memory references this hash
        refs = sum(1 for m in self._reflections
                   if m._visual_hash == memory._visual_hash)
        for mlist in self._social.values():
            refs += sum(1 for m in mlist
                        if m._visual_hash == memory._visual_hash)
        if refs <= 1 and img_path.exists():
            img_path.unlink()
        memory._visual_hash = ""
        memory._visual_dimensions = (0, 0)
        return True

    # ──────────────────────────────────────────────────────────────────
    #  Core: update_mood
    # ──────────────────────────────────────────────────────────────────

    def update_mood(self, emotions: list[str]):
        """Shift mood toward given emotion labels using EMA blending."""
        if not emotions:
            return
        vectors = [_emotion_to_vector(e) for e in emotions]
        vectors = [v for v in vectors if v is not None]
        if not vectors:
            return
        avg = tuple(
            sum(v[i] for v in vectors) / len(vectors) for i in range(3))
        mods = self._chemistry.get_modifiers()
        alpha = 0.3 * mods.get("mood_decay_mult", 1.0)
        alpha = max(0.1, min(0.5, alpha))
        self._mood = tuple(
            round(self._mood[i] * (1 - alpha) + avg[i] * alpha, 4)
            for i in range(3))
        for emo in emotions:
            self._chemistry.on_emotion(emo)
        self._audit.log("mood_shift", emotion=_closest_emotion(self._mood),
                        source="conversation",
                        details={"emotions": emotions})

    # ──────────────────────────────────────────────────────────────────
    #  Internal: touch memory + sync VividEmbed
    # ──────────────────────────────────────────────────────────────────

    def _touch_memory(self, mem: Memory):
        """Touch a memory and propagate to VividEmbed if uid is set."""
        mem.touch(current_mood=self._mood)
        if self._embed is not None and mem._embed_uid:
            try:
                self._embed.touch(mem._embed_uid)
            except Exception:
                pass

    # ──────────────────────────────────────────────────────────────────
    #  Core: get_active_self + spreading activation
    # ──────────────────────────────────────────────────────────────────

    def get_active_self(self, context: str = "") -> list[Memory]:
        """Return the most vivid self-memories, mood-weighted.

        Populates the spreading-activation priming buffer with content
        words from activated memories (Collins & Loftus 1975).
        """
        self._chemistry.tick()

        mods = self._chemistry.get_modifiers()
        limit = max(3, round(
            self.ACTIVE_SELF_LIMIT * mods.get("attention_width", 1.0)))

        if context:
            ctx_words = _resonance_words(context)
            ctx_primed = {
                w for w in ctx_words if w in self._priming_buffer}

            def _score(mem: Memory) -> float:
                base = mem.mood_adjusted_vividness(self._mood)
                mem_words = _resonance_words(
                    f"{mem.content} {mem.emotion}")
                overlap = len(ctx_words & mem_words)
                relevance = 1.0 + min(
                    overlap / max(len(ctx_words), 1), 1.0)
                # Priming boost from spreading activation
                primed_hits = sum(
                    self._priming_buffer.get(w, 0.0)
                    for w in mem_words if w in self._priming_buffer)
                return base * relevance + primed_hits * 0.1

            ranked = sorted(self._reflections, key=_score, reverse=True)
        else:
            ranked = sorted(
                self._reflections,
                key=lambda m: m.mood_adjusted_vividness(self._mood),
                reverse=True)

        active = ranked[:limit]

        # ── Spreading activation: populate priming buffer ─────────────
        for mem in active:
            for w in _resonance_words(f"{mem.content} {mem.emotion}"):
                if len(w) >= 4:
                    self._priming_buffer[w] = (
                        self._priming_buffer.get(w, 0.0) + PRIMING_BOOST)

        # Touch relevant memories
        if context:
            ctx_words = _resonance_words(context)
            for mem in active:
                mem_words = _resonance_words(
                    f"{mem.content} {mem.emotion}")
                if ctx_words & mem_words:
                    self._touch_memory(mem)
        else:
            for mem in active:
                self._touch_memory(mem)

        return active

    # ──────────────────────────────────────────────────────────────────
    #  Core: decay_priming
    # ──────────────────────────────────────────────────────────────────

    def decay_priming(self):
        """Decay the spreading-activation priming buffer."""
        dead = []
        for w in self._priming_buffer:
            self._priming_buffer[w] *= PRIMING_DECAY
            if self._priming_buffer[w] < 0.01:
                dead.append(w)
        for w in dead:
            del self._priming_buffer[w]

    # ──────────────────────────────────────────────────────────────────
    #  Core: recall (hybrid retrieval bridge)
    # ──────────────────────────────────────────────────────────────────

    def recall(self, context: str, limit: int | None = None,
               mood: tuple[float, float, float] | None = None) -> list[Memory]:
        """Hybrid retrieval: BM25 keyword + VividEmbed semantic → composite re-rank.

        Stage 1 — Broad Recall:
            BM25 keyword search catches exact matches (names, dates, facts).
            VividEmbed semantic search catches meaning-level matches.
            Union of both → wider candidate pool.

        Stage 2 — Composite Re-rank:
            All candidates scored on 5 signals: keyword strength, semantic
            similarity, vividness (organic decay), mood congruence, recency.
            Top K returned.

        This bridges the gap between keyword-based RAG retrieval and
        VividnessMem's emotion-aware memory system.
        """
        k = limit or self.RECALL_LIMIT
        current_mood = mood or self._mood

        if not context or not self._reflections:
            return []

        query_words = _resonance_words(context)
        if not query_words:
            return []

        # ── Stage 1a: BM25 keyword search ─────────────────────────────
        bm25 = self._bm25_scores(query_words)
        max_bm25 = max(bm25.values()) if bm25 else 1.0
        bm25_norm = (
            {idx: s / max_bm25 for idx, s in bm25.items()}
            if max_bm25 > 0 else {}
        )

        # Take top 2×k candidates from BM25
        bm25_top = sorted(
            bm25.items(), key=lambda x: x[1], reverse=True)[:2 * k]
        candidates: dict[int, dict] = {}
        for idx, _ in bm25_top:
            candidates[idx] = {
                "bm25": bm25_norm.get(idx, 0.0), "semantic": 0.0}

        # ── Stage 1a½: Date-index lookup ──────────────────────────────
        # If the query mentions dates, pull in all memories tagged with
        # those dates — this catches temporal questions that BM25 might
        # rank poorly because the memory text uses a different date format.
        query_dates = _extract_dates(context)
        for ds in query_dates:
            for idx in self._date_index.get(ds, set()):
                if idx not in candidates:
                    candidates[idx] = {
                        "bm25": bm25_norm.get(idx, 0.0),
                        "semantic": 0.0,
                    }

        # ── Stage 1b: VividEmbed semantic search ──────────────────────
        if self._embed is not None:
            try:
                embed_results = self._embed.query(
                    context, top_k=2 * k,
                    mood=_closest_emotion(current_mood))
                for r in embed_results:
                    content = r.get("content", "")
                    score = r.get("score", 0.0)
                    for idx, mem in enumerate(self._reflections):
                        if mem.content == content:
                            if idx not in candidates:
                                candidates[idx] = {
                                    "bm25": bm25_norm.get(idx, 0.0),
                                    "semantic": 0.0,
                                }
                            candidates[idx]["semantic"] = max(
                                candidates[idx]["semantic"], score)
                            break
            except Exception:
                pass

        # Normalize semantic scores to [0, 1]
        max_sem = max(
            (c["semantic"] for c in candidates.values()), default=1.0)
        if max_sem > 0:
            for c in candidates.values():
                c["semantic"] /= max_sem

        if not candidates:
            return []

        # ── Stage 1c: Spreading Activation (Collins & Loftus 1975) ────
        # Fire from current candidates through Yggdrasil — organic associative recall.
        seed_indices = set(candidates.keys())
        activation = self._spreading_activation(seed_indices)
        discovered = [
            (act, idx) for idx, act in activation.items()
            if idx not in seed_indices
            and act >= SPREADING_ACTIVATION_THRESHOLD
            and idx < len(self._reflections)
        ]
        discovered.sort(key=lambda x: x[0], reverse=True)
        for act, idx in discovered[:SPREADING_ACTIVATION_MAX_DISCOVER]:
            candidates[idx] = {
                "bm25": bm25_norm.get(idx, 0.0),
                "semantic": 0.0,
            }

        # ── Stage 2: Composite re-rank ────────────────────────────────
        now = datetime.now()
        scored: list[tuple[float, int]] = []

        # Pre-compute which memories are temporally salient right now
        _salient = self._temporally_salient_indices()

        for idx, signals in candidates.items():
            mem = self._reflections[idx]

            # Signal 1: Keyword match (BM25)
            s_keyword = signals["bm25"]

            # Signal 2: Semantic similarity
            s_semantic = signals["semantic"]

            # Signal 3: Vividness (organic decay + importance)
            s_vividness = mem.vividness / 10.0  # normalize to ~[0, 1]

            # Signal 4: Mood congruence
            mem_vec = _emotion_to_vector(mem.emotion)
            if mem_vec and current_mood != (0.0, 0.0, 0.0):
                dot = sum(a * b for a, b in zip(mem_vec, current_mood))
                s_mood = (dot + 1.0) / 2.0  # map [-1, 1] → [0, 1]
            else:
                s_mood = 0.5

            # Signal 5: Recency
            age_days = (
                now - datetime.fromisoformat(mem.timestamp)
            ).total_seconds() / 86400
            s_recency = math.exp(
                -0.693 * age_days / _RECENCY_HALF_LIFE_DAYS)

            # Composite score
            composite = (
                _W_KEYWORD   * s_keyword
                + _W_SEMANTIC  * s_semantic
                + _W_VIVIDNESS * s_vividness
                + _W_MOOD      * s_mood
                + _W_RECENCY   * s_recency
            )

            # Bonus: cherished memories get a nudge
            if mem._cherished:
                composite *= 1.1

            # Bonus: priming buffer activation
            mem_words = _resonance_words(
                f"{mem.content} {mem.emotion}")
            primed = sum(
                self._priming_buffer.get(w, 0.0) for w in mem_words)
            if primed > 0:
                composite += primed * 0.02

            # Bonus: temporal date match — if this memory's mentioned
            # dates overlap with dates extracted from the query, boost it
            if query_dates and mem._mentioned_dates:
                date_overlap = set(query_dates) & set(mem._mentioned_dates)
                if date_overlap:
                    composite += TEMPORAL_PROXIMITY_BOOST * len(date_overlap)

            # Bonus: ambient temporal salience — memories about dates
            # near today are "on the mind" even without date queries
            if idx in _salient:
                composite += TEMPORAL_SALIENCE_BOOST

            # Bonus: Paivio's Dual Coding — visual memories get a
            # small boost because pictures + words encode richer traces
            if mem.has_visual:
                composite += VISUAL_BOOST

            # Bonus: Yggdrasil connectivity — memories connected to
            # other already-scored candidates get a graph bonus
            ygg_edges = self._yggdrasil.get(idx, [])
            if ygg_edges:
                connected_hits = sum(
                    1 for t, _, _ in ygg_edges if t in candidates)
                if connected_hits > 0:
                    composite += YGGDRASIL_BOOST * connected_hits

            scored.append((composite, idx))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [self._reflections[idx] for _, idx in scored[:k]]

    # ──────────────────────────────────────────────────────────────────
    #  Core: recall_unified (cross-type retrieval — mechanism #15)
    # ──────────────────────────────────────────────────────────────────

    def recall_unified(self, context: str, limit: int = 8
                       ) -> dict[str, list]:
        """Cross-type retrieval bridging episodic, semantic, and procedural stores.

        Searches across reflections, social impressions, facts, AND
        lessons in a single query — returning the most relevant items
        from each store ranked by keyword overlap + vividness.

        Returns dict with keys: reflections, impressions, facts, lessons
        Each value is a list of the matching items (Memory, ShortTermFact, Lesson).
        """
        if not context:
            return {"reflections": [], "impressions": [],
                    "facts": [], "lessons": []}

        query_words = _content_words(context.lower())
        if not query_words:
            return {"reflections": [], "impressions": [],
                    "facts": [], "lessons": []}

        per_type = max(2, limit // 3)

        # ── Reflections (use existing recall for full hybrid scoring) ──
        reflections = self.recall(context, limit=per_type)

        # ── Social impressions (keyword + vividness) ──────────────────
        imp_scored: list[tuple[float, Memory]] = []
        for entity, mems in self._social.items():
            for m in mems:
                overlap = _overlap_ratio(query_words, m.content_words)
                if overlap > 0.05:
                    score = overlap * 0.6 + (m.vividness / 10.0) * 0.4
                    imp_scored.append((score, m))
        imp_scored.sort(key=lambda x: x[0], reverse=True)
        impressions = [m for _, m in imp_scored[:per_type]]

        # ── Facts (keyword match on entity + attribute + value) ───────
        fact_scored: list[tuple[float, ShortTermFact]] = []
        for f in self._facts:
            if f.vividness < 0.1:
                continue
            fact_text = f"{f.entity} {f.attribute} {f.value}".lower()
            fact_words = _content_words(fact_text)
            overlap = _overlap_ratio(query_words, fact_words)
            if overlap > 0.05:
                score = overlap * 0.5 + f.vividness * 0.5
                fact_scored.append((score, f))
        fact_scored.sort(key=lambda x: x[0], reverse=True)
        facts = [f for _, f in fact_scored[:per_type]]

        # ── Lessons (keyword match on topic + strategy + trigger) ─────
        lesson_scored: list[tuple[float, Lesson]] = []
        for ls in self._lessons:
            ls_text = f"{ls.topic} {ls.strategy} {ls.context_trigger}".lower()
            ls_words = _content_words(ls_text)
            overlap = _overlap_ratio(query_words, ls_words)
            if overlap > 0.05:
                score = overlap * 0.5 + (ls.vividness / 10.0) * 0.5
                lesson_scored.append((score, ls))
        lesson_scored.sort(key=lambda x: x[0], reverse=True)
        lessons = [ls for _, ls in lesson_scored[:per_type]]

        return {
            "reflections": reflections,
            "impressions": impressions,
            "facts": facts,
            "lessons": lessons,
        }

    # ──────────────────────────────────────────────────────────────────
    #  Core: resonate (hybrid recall + neuroscience)
    # ──────────────────────────────────────────────────────────────────

    def resonate(self, context: str, limit: int | None = None) -> list[Memory]:
        """Find old faded memories resonating with current context.

        Uses the hybrid retrieval bridge (BM25 + semantic → composite
        re-rank), then layers neuroscience mechanisms on top:
        - Retrieval-induced forgetting (Anderson 1994)
        - Involuntary Proustian recall (Berntsen 2009)
        """
        hard_cap = max(limit or self.RESONANCE_LIMIT, 8)
        if not context or not self._reflections:
            return []

        # ── Hybrid retrieval — cast wider net than final cap ──────────
        recalled = self.recall(
            context, limit=max(hard_cap * 2, self.RECALL_LIMIT))

        resonant = recalled[:hard_cap]
        active_ids = {id(m) for m in resonant}

        # ── Retrieval-induced forgetting ──────────────────────────────
        # Memories not retrieved but highly similar to retrieved ones
        # get a small stability penalty (suppressed by competition).
        if resonant:
            retrieved_words = set()
            for mem in resonant:
                retrieved_words |= _resonance_words(mem.content)
            for ref in self._reflections:
                if id(ref) in active_ids:
                    continue
                ref_words = _resonance_words(ref.content)
                if not ref_words:
                    continue
                overlap = (
                    len(retrieved_words & ref_words) / len(ref_words))
                if overlap >= INTERFERENCE_THRESHOLD:
                    ref._stability = max(
                        INITIAL_STABILITY * 0.5,
                        ref._stability * (1.0 - INTERFERENCE_PENALTY))

        # ── Involuntary / Proustian recall ────────────────────────────
        # Small probability of a random distant memory surfacing
        if (len(self._reflections) > 3
                and random.random() < INVOLUNTARY_RECALL_PROB):
            candidate = random.choice(self._reflections)
            if id(candidate) not in active_ids:
                resonant.append(candidate)

        for r in resonant:
            self._touch_memory(r)

        return resonant

    # ──────────────────────────────────────────────────────────────────
    #  Core: recall_period (temporal navigation)
    # ──────────────────────────────────────────────────────────────────

    def recall_period(self, start: str | datetime, end: str | datetime,
                      limit: int = 20) -> list[Memory]:
        """Retrieve memories from a time window (Tulving 1972).

        Matches on both the memory's creation timestamp AND any
        mentioned dates extracted from the content.  Results are sorted
        by timestamp (oldest first) for chronological readback.

        *start* / *end* can be ISO date strings or datetime objects.
        """
        if isinstance(start, str):
            start = datetime.fromisoformat(start)
        if isinstance(end, str):
            end = datetime.fromisoformat(end)

        start_d = start.date() if hasattr(start, 'date') else start
        end_d = end.date() if hasattr(end, 'date') else end

        hits: set[int] = set()

        # 1. Memories created in the window
        for i, mem in enumerate(self._reflections):
            ts = datetime.fromisoformat(mem.timestamp).date()
            if start_d <= ts <= end_d:
                hits.add(i)

        # 2. Memories that *mention* dates in the window
        for ds, indices in self._date_index.items():
            try:
                d = datetime.fromisoformat(ds).date()
            except ValueError:
                continue
            if start_d <= d <= end_d:
                hits |= indices

        # Sort chronologically and clamp
        ordered = sorted(hits, key=lambda i: self._reflections[i].timestamp)
        return [self._reflections[i] for i in ordered[:limit]]

    # ──────────────────────────────────────────────────────────────────
    #  Temporal awareness — proactive time-based surfacing
    # ──────────────────────────────────────────────────────────────────

    def get_temporal_context(
        self,
        now: datetime | None = None,
        lookahead: int | None = None,
        lookbehind: int | None = None,
    ) -> dict[str, list[tuple[str, Memory]]]:
        """Proactive temporal awareness — returns memories about *now*.

        Scans all dated memories and returns three buckets:
          - **today**: memories whose mentioned dates match today
          - **upcoming**: mentioned dates within the next *lookahead* days
          - **recent**: mentioned dates in the past *lookbehind* days

        Each entry is a (date_str, Memory) pair so the caller knows
        *which* date triggered the hit.

        An AI using Mimir calls this at conversation start (or
        periodically) so it can proactively say things like:
          "Hey, your dentist appointment is tomorrow!"
          "How did the job interview go yesterday?"
        """
        ref = (now or datetime.now()).date()
        ahead = lookahead if lookahead is not None else TEMPORAL_LOOKAHEAD_DAYS
        behind = lookbehind if lookbehind is not None else TEMPORAL_LOOKBEHIND_DAYS

        today_bucket:    list[tuple[str, Memory]] = []
        upcoming_bucket: list[tuple[str, Memory]] = []
        recent_bucket:   list[tuple[str, Memory]] = []

        for ds, indices in self._date_index.items():
            try:
                d = datetime.fromisoformat(ds).date()
            except ValueError:
                continue
            delta = (d - ref).days
            for idx in indices:
                if idx >= len(self._reflections):
                    continue
                mem = self._reflections[idx]
                pair = (ds, mem)
                if delta == 0:
                    today_bucket.append(pair)
                elif 1 <= delta <= ahead:
                    upcoming_bucket.append(pair)
                elif -behind <= delta < 0:
                    recent_bucket.append(pair)

        # Sort upcoming by date ascending, recent by date descending
        upcoming_bucket.sort(key=lambda p: p[0])
        recent_bucket.sort(key=lambda p: p[0], reverse=True)

        return {
            "today": today_bucket,
            "upcoming": upcoming_bucket,
            "recent": recent_bucket,
        }

    def _temporally_salient_indices(self) -> set[int]:
        """Return indices of memories with dates near today.

        Used by recall() to give these an ambient salience boost
        even when the query doesn't explicitly mention dates.
        """
        ref = datetime.now().date()
        salient: set[int] = set()
        for ds, indices in self._date_index.items():
            try:
                d = datetime.fromisoformat(ds).date()
            except ValueError:
                continue
            delta_abs = abs((d - ref).days)
            if delta_abs <= max(TEMPORAL_LOOKAHEAD_DAYS,
                                TEMPORAL_LOOKBEHIND_DAYS):
                salient |= indices
        return salient

    # ──────────────────────────────────────────────────────────────────
    #  Social impressions
    # ──────────────────────────────────────────────────────────────────

    def add_social_impression(self, entity: str, content: str,
                              emotion: str = "neutral",
                              importance: int = 5,
                              why_saved: str = "") -> Memory:
        """Store a memory about someone."""
        mods = self._chemistry.get_modifiers()
        combined = mods["encoding_boost"] * mods.get("social_boost", 1.0)
        eff_imp = max(1, min(10, round(importance * combined)))
        self._chemistry.on_emotion(emotion)

        if entity not in self._social:
            self._social[entity] = []

        mem = Memory(content=content, emotion=emotion,
                     importance=eff_imp, source="social",
                     entity=entity, why_saved=why_saved)
        mem._encoding_mood = self._mood
        self._social[entity].append(mem)
        return mem

    # ──────────────────────────────────────────────────────────────────
    #  Lessons (procedural memory)
    # ──────────────────────────────────────────────────────────────────

    def add_lesson(self, topic: str, context_trigger: str = "",
                   strategy: str = "", importance: int = 5,
                   source_memory_idx: int = -1) -> Lesson:
        """Record a learned procedure or skill.

        If *source_memory_idx* is given, creates a cross-hierarchy link
        between this lesson and the originating episodic memory.
        """
        lesson = Lesson(topic, context_trigger, strategy, importance)
        lesson._source_memory_idx = source_memory_idx
        self._lessons.append(lesson)
        return lesson

    def record_outcome(self, lesson_id: str, action: str, result: str,
                       diagnosis: str = ""):
        """Log the outcome of applying a lesson.

        Cross-hierarchy reinforcement: when a lesson succeeds, any linked
        origin memory gets a stability boost (the experience proved useful).
        """
        lesson = next(
            (l for l in self._lessons if l.id == lesson_id), None)
        if not lesson:
            return
        attempt = Attempt(action, result, diagnosis)
        lesson.attempts.append(attempt)
        lesson.total_attempts += 1
        lesson.last_attempt = datetime.now().isoformat()
        if result == "failure":
            lesson.consecutive_failures += 1
        else:
            lesson.consecutive_failures = 0
            # Cross-hierarchy reinforcement: success strengthens
            # the origin memory that spawned this lesson
            idx = lesson._source_memory_idx
            if 0 <= idx < len(self._reflections):
                mem = self._reflections[idx]
                mem._stability = min(
                    STABILITY_CAP, mem._stability * 1.15)

    def get_active_lessons(self) -> list[Lesson]:
        """Return lessons sorted by vividness (Zeigarnik-boosted)."""
        return sorted(
            self._lessons, key=lambda l: l.vividness, reverse=True)

    @property
    def lessons(self) -> list[Lesson]:
        """Public accessor for the lessons list."""
        return self._lessons

    def retrieve_lessons(self, query: str,
                         limit: int = 10) -> list[tuple[Lesson, float]]:
        """BM25-lite keyword search over lessons.

        Tokenises *query* and each lesson's topic + context_trigger +
        strategy, then scores by weighted term-overlap so benchmarks and
        retrieval pipelines can fetch the most relevant procedural
        knowledge for a given situation.

        Returns a list of ``(Lesson, score)`` tuples, descending by score.
        """
        if not self._lessons:
            return []

        q_tokens = set(query.lower().split())
        if not q_tokens:
            return []

        scored: list[tuple[Lesson, float]] = []
        for lesson in self._lessons:
            text = (f"{lesson.topic} {lesson.context_trigger} "
                    f"{lesson.strategy}").lower()
            doc_tokens = set(text.split())
            if not doc_tokens:
                continue
            overlap = q_tokens & doc_tokens
            if not overlap:
                continue
            tf = len(overlap) / len(q_tokens)
            score = tf * (0.5 + 0.5 * min(lesson.vividness / 10.0, 1.0))
            scored.append((lesson, score))

        scored.sort(key=lambda x: x[1], reverse=True)
        return scored[:limit]

    # ──────────────────────────────────────────────────────────────────
    #  Reminders
    # ──────────────────────────────────────────────────────────────────

    def set_reminder(self, text: str, hours: float = 1.0) -> Reminder:
        """Create a time-triggered reminder."""
        trigger = datetime.now() + timedelta(hours=hours)
        reminder = Reminder(text, trigger.isoformat())
        self._reminders.append(reminder)
        return reminder

    def get_due_reminders(self) -> list[Reminder]:
        """Return all reminders that have triggered but not yet fired."""
        due = [r for r in self._reminders if r.is_due]
        for r in due:
            r.fired = True
        return due

    def sleep_reset(self, hours: float = 8.0):
        """Between-session neurochemistry reset + god-tier consolidation.

        Call this at the start of a new conversation to let chemistry
        drift back toward baseline (as if the user slept/rested).

        During sleep, five processes run:
        1. Muninn (consolidation) — merge, prune, strengthen
        2. Gist compression      — old episodic memories → semantic gists
        3. Chunking (Miller 1956) — fuse related memory clusters
        4. Huginn (thought)       — detect patterns → insight memories
        5. Völva  (dream)         — synthesise new insights from random
                                    memory pairing
        """
        self._chemistry.sleep_reset(hours)
        self._audit.log("sleep_reset", details={"hours": hours})

        # ── Muninn: consolidation (Odin's raven of Memory) ────────────
        muninn_stats = self.muninn()

        # ── Gist compression (Reyna & Brainerd 1995) ─────────────────
        gist_count = self._compress_to_gist()

        # ── Chunking (Miller 1956) ───────────────────────────────────
        chunk_count = self.chunk_memories()

        # ── Huginn: pattern detection (Odin's raven of Thought) ───────
        huginn_insights = self.huginn()

        # ── Völva: dream synthesis ────────────────────────────────────
        volva_insights = self.volva_dream()

        # Rebuild Yggdrasil after consolidation changes
        self._build_yggdrasil()

    # ──────────────────────────────────────────────────────────────────
    #  Emotional pipeline — full NeuroChemistry integration
    # ──────────────────────────────────────────────────────────────────

    def on_event(self, event_type: str, intensity: float = 0.7):
        """Signal a life event to the neurochemistry engine.

        Routes through NeuroChemistry (which internally filters via
        EmotionalFirewall for manipulation detection + dampening).

        Event types: reward, loss, social_bond, social_rejection,
        surprise, threat, achievement, betrayal, comfort, loneliness.
        """
        self._chemistry.on_event(event_type, intensity)
        self._audit.log("event", source=event_type,
                        details={"intensity": intensity})

    def request_dampening(self, turns: int = 5, intensity: float = 0.3):
        """Activate emotional dampening (protective self-regulation).

        The AI requests this when it detects emotional flooding or
        potential manipulation.  Dampened emotions have reduced impact
        on neurochemistry for the next *turns* conversation turns.
        """
        self._chemistry.request_dampening(turns, intensity)
        self._audit.log("dampening_activated",
                        details={"turns": turns, "intensity": intensity})

    def end_dampening(self):
        """Manually end emotional dampening early."""
        self._chemistry.end_dampening()
        self._audit.log("dampening_ended")

    def tick_dampening(self):
        """Advance dampening by one conversation turn.

        Call this once per conversation turn so time-limited dampening
        can expire naturally.
        """
        self._chemistry.tick_dampening()

    def cognitive_override(self, emotion: str, intensity: float = 0.7):
        """Apply a deliberate cognitive reappraisal.

        Unlike organic emotions, this represents the AI choosing to
        reinterpret a situation — e.g. reframing anxiety as excitement.
        Logged to the audit trail for transparency.
        """
        self._chemistry.cognitive_override(emotion, intensity)
        self._audit.log("cognitive_override", emotion=emotion,
                        details={"intensity": intensity})

    @property
    def is_dampened(self) -> bool:
        """Whether emotional dampening is currently active."""
        return getattr(self._chemistry, 'is_dampened', False)

    @property
    def audit_log(self):
        """Direct access to the emotional audit log."""
        return self._audit

    # ──────────────────────────────────────────────────────────────────
    #  Short-term facts
    # ──────────────────────────────────────────────────────────────────

    def add_fact(self, entity: str, attribute: str,
                 value: str) -> ShortTermFact:
        """Store a volatile fact (aggressive 12h decay)."""
        # Upsert: replace existing fact for same entity + attribute
        for i, f in enumerate(self._facts):
            if f.entity == entity and f.attribute == attribute:
                self._facts[i] = ShortTermFact(entity, attribute, value)
                return self._facts[i]
        fact = ShortTermFact(entity, attribute, value)
        self._facts.append(fact)
        return fact

    def get_facts(self, entity: str = "") -> list[ShortTermFact]:
        """Return still-vivid facts, optionally filtered by entity."""
        alive = [f for f in self._facts if f.vividness > 0.1]
        if entity:
            alive = [f for f in alive if f.entity == entity]
        return alive

    # ──────────────────────────────────────────────────────────────────
    #  Anchor + cherished management
    # ──────────────────────────────────────────────────────────────────

    def promote_to_anchor(self, memory: Memory) -> bool:
        """Mark a memory as a formative anchor (resists full decay)."""
        if memory._anchor:
            return False
        all_mems = list(self._reflections)
        for mlist in self._social.values():
            all_mems.extend(mlist)
        if memory not in all_mems:
            return False
        memory._anchor = True
        memory._stability = max(memory._stability, ANCHOR_STABILITY_FLOOR)
        return True

    def cherish(self, memory: Memory) -> bool:
        """Mark a memory as a sentimental favourite."""
        if memory._cherished:
            return False
        all_mems = list(self._reflections)
        for mlist in self._social.values():
            all_mems.extend(mlist)
        if memory not in all_mems:
            return False
        memory._cherished = True
        return True

    def uncherish(self, memory: Memory) -> bool:
        """Remove the cherished mark."""
        if not memory._cherished:
            return False
        memory._cherished = False
        return True

    def reframe(self, memory: Memory, new_emotion: str,
                reason: str = "") -> bool:
        """Deliberately shift a memory's emotion (intentional reframe).

        Unlike passive reconsolidation drift, this records the change
        as a conscious choice.  ``original_emotion`` is preserved,
        ``_reframed`` is set, and the reason is logged to the audit
        trail so the drift monitor can distinguish intentional
        reinterpretation from involuntary mood bleed.
        """
        all_mems = list(self._reflections)
        for mlist in self._social.values():
            all_mems.extend(mlist)
        if memory not in all_mems:
            return False
        old_emotion = memory.emotion
        new_pad = _emotion_to_vector(new_emotion)
        if new_pad is None:
            return False
        memory.emotion = new_emotion
        memory._emotion_pad = new_pad
        memory._reframed = True
        memory._reframe_reason = reason or f"reframed from {old_emotion}"
        self._audit.log(
            "intentional_reframe",
            emotion=new_emotion,
            source="reframe",
            details={
                "old_emotion": old_emotion,
                "new_emotion": new_emotion,
                "original_emotion": memory.original_emotion,
                "reason": memory._reframe_reason,
                "content_preview": memory.content[:60],
            })
        return True

    def reflect_on_cherished(self) -> list[Memory]:
        """Deliberately revisit cherished memories (photo album moment)."""
        cherished = [
            m for m in self._reflections if m._cherished]
        for mlist in self._social.values():
            cherished.extend(m for m in mlist if m._cherished)
        if not cherished:
            return []
        for mem in cherished:
            self._touch_memory(mem)
        if self._chemistry.enabled:
            self._chemistry.on_emotion("nostalgic", 0.3)
        return sorted(cherished, key=lambda m: m.vividness, reverse=True)

    def relive(self, memory: Memory) -> dict:
        """Mental Time Travel — experientially re-enter a past memory.

        Restores the encoding mood, triggers matching neurochemistry,
        activates connected memories via Yggdrasil spreading activation,
        and returns the full experiential context.

        This goes beyond simple recall — it recreates the *inner state*
        that existed when the memory was formed.
        """
        # 1. Touch the memory (spaced-repetition + reconsolidation)
        self._touch_memory(memory)

        # 2. Restore the encoding mood — temporarily shift toward
        #    the emotional state at the time of encoding
        old_mood = self._mood
        encoding_mood = memory._encoding_mood
        if encoding_mood and any(v != 0 for v in encoding_mood):
            alpha = 0.6  # strong shift — we're deliberately re-entering
            self._mood = tuple(
                round(old_mood[i] * (1 - alpha) + encoding_mood[i] * alpha, 4)
                for i in range(3))

        # 3. Trigger matching neurochemistry based on the memory's emotion
        if self._chemistry.enabled:
            # Map emotions to plausible life-event triggers
            emo = memory.emotion.lower()
            event_map = {
                "joy": "reward", "happiness": "reward",
                "excitement": "surprise", "surprise": "surprise",
                "love": "social_bond", "gratitude": "social_bond",
                "trust": "comfort", "nostalgia": "comfort",
                "sadness": "loss", "grief": "loss",
                "fear": "threat", "anxiety": "threat",
                "anger": "betrayal",
                "loneliness": "loneliness",
                "pride": "achievement", "satisfaction": "achievement",
            }
            event_type = event_map.get(emo)
            if event_type:
                # Moderate intensity — it's a re-experience, not the
                # original event
                self._chemistry.on_event(event_type, 0.4)

        # 4. Yggdrasil spreading activation — surface connected memories
        try:
            idx = self._reflections.index(memory)
        except ValueError:
            idx = -1

        connected: list[Memory] = []
        if idx >= 0:
            edges = self._yggdrasil.get(idx, [])
            for target_idx, edge_type, strength in edges:
                if target_idx < len(self._reflections):
                    neighbour = self._reflections[target_idx]
                    # Prime connected memories for easier future retrieval
                    for w in _resonance_words(neighbour.content):
                        self._priming_buffer[w] = max(
                            self._priming_buffer.get(w, 0.0),
                            strength)
                    connected.append(neighbour)

        # 5. Build the experiential context
        arc = memory._arc_position or "unclassified"
        drift_info = None
        if memory.has_drifted:
            drift_info = {
                "original_emotion": memory._original_emotion,
                "current_emotion": memory.emotion,
                "magnitude": round(memory.drift_magnitude, 3),
            }

        return {
            "memory": memory,
            "gist": memory.gist,
            "emotion": memory.emotion,
            "original_emotion": memory.original_emotion,
            "encoding_mood": encoding_mood,
            "restored_mood": self._mood,
            "previous_mood": old_mood,
            "arc_position": arc,
            "is_flashbulb": memory._is_flashbulb,
            "is_cherished": memory._cherished,
            "vividness": round(memory.vividness, 3),
            "drift": drift_info,
            "connected_memories": [m.gist for m in connected],
            "connected_count": len(connected),
        }

    # ──────────────────────────────────────────────────────────────────
    #  VividEmbed advanced retrieval
    # ──────────────────────────────────────────────────────────────────

    def query_by_emotion(self, emotion: str, top_k: int = 5,
                         min_importance: int = 0) -> list[dict]:
        """Find memories by emotional similarity in PAD space.

        Delegates to VividEmbed.query_by_emotion() — useful for
        "what memories feel like this?" searches.
        """
        if self._embed is None:
            return []
        try:
            return self._embed.query_by_emotion(
                emotion, top_k=top_k, min_importance=min_importance)
        except Exception:
            return []

    def find_contradictions(self, text: str, emotion: str = "neutral",
                            threshold: float = 0.70) -> list[dict]:
        """Find stored memories that might contradict the given text.

        Uses VividEmbed to detect high semantic similarity +
        opposite emotional valence — useful for self-consistency checks.
        """
        if self._embed is None:
            return []
        try:
            return self._embed.find_contradictions(
                text, emotion=emotion, threshold=threshold)
        except Exception:
            return []

    def update_importance(self, memory: Memory,
                          new_importance: int) -> bool:
        """Update a memory's importance and sync to VividEmbed."""
        memory.importance = max(1, min(10, new_importance))
        if self._embed is not None and memory._embed_uid:
            try:
                self._embed.update_importance(
                    memory._embed_uid, memory.importance)
            except Exception:
                pass
        return True

    # ──────────────────────────────────────────────────────────────────
    #  Context block
    # ──────────────────────────────────────────────────────────────────

    def get_context_block(self, current_entity: str = "",
                          conversation_context: str = "") -> str:
        """Build a full memory context block for injection into a prompt.

        Includes mood, active memories (foreground + background),
        social impressions, active lessons, due reminders, and
        resonant old memories.
        """
        lines: list[str] = []

        # Mood
        label = self.mood_label
        if label != "neutral":
            lines.append(f"(Feeling: {label})")
            lines.append("")

        # Active memories
        active = self.get_active_self(context=conversation_context)
        fg_count = max(3, len(active) // 2)
        foreground = active[:fg_count]
        background = active[fg_count:]

        if foreground:
            lines.append("=== THINGS ON MY MIND ===")
            for m in foreground:
                lines.append(
                    f"— {m.gist} ({m.emotion})")
            lines.append("")

        if background:
            lines.append("=== BACKGROUND KNOWLEDGE ===")
            for m in background:
                content = m.gist
                if len(content) > 80:
                    cut = content[:80].rfind(" ")
                    content = content[:max(cut, 30)] + "…"
                lines.append(f"· {content} [{m.emotion}]")
            lines.append("")

        # Social impressions
        if current_entity:
            impressions = self._social.get(current_entity, [])
            if impressions:
                vivid = sorted(
                    impressions,
                    key=lambda m: m.mood_adjusted_vividness(self._mood),
                    reverse=True)[:5]
                lines.append(
                    f"=== MY IMPRESSIONS OF "
                    f"{current_entity.upper()} ===")
                for m in vivid:
                    lines.append(
                        f"— {m.content} ({m.emotion})")
                lines.append("")

        # Active lessons (Zeigarnik: failures float to top)
        active_lessons = self.get_active_lessons()[:3]
        if active_lessons:
            lines.append("=== THINGS I'M LEARNING ===")
            for l in active_lessons:
                status = (
                    f"[{l.consecutive_failures} failures]"
                    if l.consecutive_failures > 0 else "[OK]")
                lines.append(
                    f"— {l.topic}: {l.strategy} {status}")
            lines.append("")

        # Due reminders
        due = self.get_due_reminders()
        if due:
            lines.append("=== REMINDERS (just triggered) ===")
            for r in due:
                lines.append(f"— {r.text}")
            lines.append("")

        # Temporal awareness — proactively surface time-relevant memories
        temporal = self.get_temporal_context()
        if temporal["today"]:
            lines.append("=== HAPPENING TODAY ===")
            seen: set[int] = set()
            for ds, mem in temporal["today"]:
                mid = id(mem)
                if mid not in seen:
                    seen.add(mid)
                    lines.append(f"— {mem.gist} ({mem.emotion})")
            lines.append("")
        if temporal["upcoming"]:
            lines.append("=== COMING UP ===")
            seen = set()
            for ds, mem in temporal["upcoming"]:
                mid = id(mem)
                if mid not in seen:
                    seen.add(mid)
                    try:
                        d = datetime.fromisoformat(ds).date()
                        delta = (d - datetime.now().date()).days
                        when = (f"in {delta} day{'s' if delta != 1 else ''}"
                                if delta > 0 else "soon")
                    except ValueError:
                        when = "soon"
                    lines.append(f"— {mem.gist} [{when}] ({mem.emotion})")
            lines.append("")
        if temporal["recent"]:
            lines.append("=== JUST HAPPENED ===")
            seen = set()
            for ds, mem in temporal["recent"]:
                mid = id(mem)
                if mid not in seen:
                    seen.add(mid)
                    try:
                        d = datetime.fromisoformat(ds).date()
                        delta = (datetime.now().date() - d).days
                        when = (f"{delta} day{'s' if delta != 1 else ''} ago"
                                if delta > 0 else "recently")
                    except ValueError:
                        when = "recently"
                    lines.append(f"— {mem.gist} [{when}] ({mem.emotion})")
            lines.append("")

        # Visual memories — let the agent know which images it "can see"
        visual_mems = [m for m in self._reflections
                       if m.has_visual and m.can_show]
        if visual_mems:
            vivid_vis = sorted(
                visual_mems,
                key=lambda m: m.mood_adjusted_vividness(self._mood),
                reverse=True)[:5]
            lines.append("=== IMAGES I REMEMBER ===")
            for m in vivid_vis:
                clarity = m.visual_clarity
                tag = "[vivid]" if clarity == "vivid" else "[fading]"
                lines.append(
                    f"— {m._visual_description} {tag} ({m.emotion})")
            lines.append("")

        # Reconsolidation drift alerts
        drifted = [m for m in self._reflections if m.has_drifted]
        if drifted:
            top_drifted = sorted(
                drifted, key=lambda m: m.drift_magnitude,
                reverse=True)[:3]
            lines.append("=== DRIFT MONITOR ===")
            for m in top_drifted:
                lines.append(
                    f"— '{m.gist[:50]}' was {m.original_emotion} "
                    f"-> now {m.emotion} "
                    f"(drift: {m.drift_magnitude:.2f})")
            lines.append("")

        # Resonant memories
        if conversation_context:
            resonant = self.resonate(conversation_context)
            if resonant:
                lines.append(
                    "=== SOMETHING THIS REMINDS ME OF ===")
                for m in resonant[:3]:
                    lines.append(
                        f"— {m.gist} ({m.emotion})")
                lines.append("")

        # Chemistry
        if self._chemistry.enabled:
            lines.append(f"=== NEUROCHEMISTRY ===")
            lines.append(self._chemistry.describe())
            if self.is_dampened:
                lines.append("  [shield] Emotional dampening active")
            lines.append("")

        # Emotional audit trail (recent events)
        audit_summary = self._audit.describe_recent(5)
        if audit_summary:
            lines.append("=== EMOTIONAL AUDIT ===")
            lines.append(audit_summary)
            lines.append("")

        # Huginn / Völva insights — show recent pattern discoveries
        insight_mems = [
            m for m in self._reflections
            if m.source in ("huginn", "volva") and m.vividness > 0.3]
        if insight_mems:
            recent_insights = sorted(
                insight_mems, key=lambda m: m.timestamp,
                reverse=True)[:3]
            lines.append("=== INSIGHTS (Huginn & Völva) ===")
            for m in recent_insights:
                tag = "thought" if m.source == "huginn" else "dream"
                lines.append(f"— [{tag}] {m.gist}")
            lines.append("")

        return "\n".join(lines) if lines else ""

    # ──────────────────────────────────────────────────────────────────
    #  Task / Project Branch  (mirrors VividnessMem's task management)
    # ──────────────────────────────────────────────────────────────────

    def set_active_project(self, name: str) -> str:
        """Set (or switch) the active project context."""
        prev = self._active_project
        self._active_project = name
        if prev and prev != name:
            return f"Switched project context: {prev!r} → {name!r}"
        return f"Active project: {name!r}"

    def start_task(self, description: str, priority: int = 5,
                   project: str = "") -> TaskRecord:
        """Create a new task under the active project."""
        proj = project or self._active_project
        t = TaskRecord(description=description, priority=priority,
                       project=proj)
        self._project_tasks.append(t)
        # Zeigarnik-style: unfinished tasks get a memory anchor
        mem = self.remember(
            content=f"[task-started] {description}",
            emotion="determination", importance=priority,
            source="task_branch",
            why_saved="tracking an active task")
        # Cross-hierarchy link: task ↔ memory
        mem_idx = len(self._reflections) - 1
        t._memory_indices.append(mem_idx)
        return t

    def complete_task(self, task_id: str, outcome: str = "") -> bool:
        """Mark a task as completed, releasing its Zeigarnik tension."""
        for t in self._project_tasks:
            if t.task_id == task_id and t.status == "active":
                t.complete(outcome)
                mem = self.remember(
                    content=f"[task-done] {t.description}: {outcome}" if outcome
                           else f"[task-done] {t.description}",
                    emotion="satisfaction", importance=t.priority,
                    source="task_branch",
                    why_saved="recording task completion")
                # Cross-hierarchy link
                t._memory_indices.append(len(self._reflections) - 1)
                return True
        return False

    def fail_task(self, task_id: str, reason: str = "") -> bool:
        """Mark a task as failed, recording the lesson."""
        for t in self._project_tasks:
            if t.task_id == task_id and t.status == "active":
                t.fail(reason)
                # Also create a Lesson so Mimir's Zeigarnik loop can help
                lesson = self.add_lesson(
                    topic=f"[task-failed] {t.description}",
                    strategy=reason or "unknown failure")
                # Cross-hierarchy: link lesson to the task's origin memory
                if t._memory_indices:
                    lesson._source_memory_idx = t._memory_indices[0]
                return True
        return False

    def get_active_tasks(self) -> list[TaskRecord]:
        """Return all currently active tasks."""
        return [t for t in self._project_tasks if t.status == "active"]

    def log_action(self, task_id: str, action: str,
                   result: str = "", error: str = "",
                   fix: str = "") -> ActionRecord:
        """Log an action taken for a task."""
        a = ActionRecord(task_id=task_id, action=action,
                         result=result, error=error, fix=fix)
        self._project_actions.append(a)
        return a

    def record_solution(self, problem: str, solution: str,
                        importance: int = 0) -> SolutionPattern:
        """Store a reusable problem→solution pattern."""
        imp = importance or SOLUTION_INITIAL_IMPORTANCE
        s = SolutionPattern(problem=problem, solution=solution,
                            importance=imp)
        self._solutions.append(s)
        # Also store as a lesson for the Zeigarnik engine
        self.add_lesson(topic=problem, strategy=solution)
        return s

    def find_solutions(self, problem: str, top_k: int = 3) -> list[SolutionPattern]:
        """Find matching solution patterns, boosting reuse count."""
        query_words = _resonance_words(problem)
        scored: list[tuple[float, SolutionPattern]] = []
        for s in self._solutions:
            sol_words = _resonance_words(s.search_text)
            overlap = len(query_words & sol_words)
            if overlap == 0:
                continue
            score = overlap * s.vividness
            scored.append((score, s))
        scored.sort(key=lambda x: x[0], reverse=True)
        results = [s for _, s in scored[:top_k]]
        for s in results:
            s.apply()  # boost reuse
        return results

    def track_artifact(self, name: str, artifact_type: str = "file",
                       description: str = "", importance: int = 5,
                       dependencies: list[str] | None = None) -> ArtifactRecord:
        """Track a project artifact (file, model, dataset, etc.)."""
        a = ArtifactRecord(name=name, artifact_type=artifact_type,
                           description=description, importance=importance,
                           dependencies=dependencies or [])
        self._artifacts.append(a)
        return a

    def update_artifact(self, name: str, **updates) -> bool:
        """Update an artifact's fields."""
        for a in self._artifacts:
            if a.name == name:
                for k, v in updates.items():
                    if hasattr(a, k):
                        setattr(a, k, v)
                return True
        return False

    def get_project_overview(self) -> dict:
        """Snapshot of the current project state."""
        active = self.get_active_tasks()
        done = [t for t in self._project_tasks if t.status == "completed"]
        failed = [t for t in self._project_tasks if t.status == "failed"]
        return {
            "project": self._active_project,
            "tasks_active": len(active),
            "tasks_completed": len(done),
            "tasks_failed": len(failed),
            "actions_logged": len(self._project_actions),
            "solutions_stored": len(self._solutions),
            "artifacts_tracked": len(self._artifacts),
            "active_task_descriptions": [t.description for t in active],
        }

    # ──────────────────────────────────────────────────────────────────
    #  LLM Integration  (optional — graceful when no llm_fn)
    # ──────────────────────────────────────────────────────────────────

    def decompose_query(self, query: str) -> list[str]:
        """Use LLM to break a vague query into focused sub-queries.

        Falls back to returning the original query if no LLM is available.
        """
        if not self._llm_fn:
            return [query]
        prompt = (
            "Break this memory query into 2-4 specific sub-queries "
            "that would help retrieve relevant memories. Return ONLY "
            "the sub-queries, one per line, no numbering.\n\n"
            f"Query: {query}"
        )
        try:
            response = self._llm_fn(prompt)
            lines = [l.strip() for l in response.strip().split("\n")
                     if l.strip()]
            return lines[:4] if lines else [query]
        except Exception:
            return [query]

    def edit_memories(self, instruction: str) -> dict:
        """LLM-driven agentic memory operations.

        Supports: UPDATE, PROMOTE, DEMOTE, FORGET
        Returns a dict describing what was changed.
        """
        if not self._llm_fn:
            return {"error": "no LLM function configured"}

        # Build a compact summary of recent memories for the LLM
        recent = sorted(self._reflections, key=lambda m: m.timestamp,
                        reverse=True)[:20]
        mem_lines = []
        for i, m in enumerate(recent):
            mem_lines.append(
                f"[{i}] imp={m.importance} emo={m.emotion} "
                f"content={m.gist}")

        prompt = (
            "You are a memory editor. Given these recent memories and "
            "an instruction, output operations as one-per-line:\n"
            "  PROMOTE idx — boost importance by 2\n"
            "  DEMOTE idx — reduce importance by 2\n"
            "  FORGET idx — mark as forgotten (importance=0)\n"
            "  UPDATE idx new_content — replace content\n\n"
            "Memories:\n" + "\n".join(mem_lines) + "\n\n"
            f"Instruction: {instruction}\n"
            "Output operations only, no explanation."
        )
        try:
            response = self._llm_fn(prompt)
        except Exception as e:
            return {"error": str(e)}

        changes = {"promoted": 0, "demoted": 0,
                   "forgotten": 0, "updated": 0}
        for line in response.strip().split("\n"):
            parts = line.strip().split(None, 2)
            if len(parts) < 2:
                continue
            op = parts[0].upper()
            try:
                idx = int(parts[1])
            except (ValueError, IndexError):
                continue
            if idx < 0 or idx >= len(recent):
                continue
            mem = recent[idx]
            if op == "PROMOTE":
                mem._importance = min(10, mem.importance + 2)
                changes["promoted"] += 1
            elif op == "DEMOTE":
                mem._importance = max(1, mem.importance - 2)
                changes["demoted"] += 1
            elif op == "FORGET":
                mem._importance = 0
                changes["forgotten"] += 1
            elif op == "UPDATE" and len(parts) == 3:
                mem._content = parts[2]
                mem._content_words = None
                changes["updated"] += 1
        return changes

    def reflect(self) -> str:
        """LLM-driven periodic self-analysis of the memory system.

        Produces insights about patterns, gaps, and emotional trends.
        """
        if not self._llm_fn:
            return ""

        s = self.stats()
        # Build a compact state summary for the LLM
        summary = (
            f"Memories: {s['total_reflections']}, "
            f"Flashbulbs: {s['flashbulb_count']}, "
            f"Cherished: {s['cherished_count']}, "
            f"Mood: {s['mood']}, "
            f"Lessons: {s['total_lessons']}, "
            f"Drifted: {s['drifted_memories']}, "
            f"Avg novelty: {s['avg_novelty']}"
        )
        # Sample some recent memories for context
        recent = sorted(self._reflections, key=lambda m: m.timestamp,
                        reverse=True)[:10]
        mem_text = "\n".join(f"- {m.gist} (emo={m.emotion})"
                            for m in recent)
        prompt = (
            "You are an introspective memory system. Analyze this state "
            "and produce 2-3 brief observations about patterns, emotional "
            "trends, or notable gaps. Be concise.\n\n"
            f"State: {summary}\n\n"
            f"Recent memories:\n{mem_text}"
        )
        try:
            response = self._llm_fn(prompt)
            # Store the reflection as a Huginn insight
            if response.strip():
                self.remember(
                    content=f"[reflection] {response.strip()[:300]}",
                    emotion="contemplative", importance=4,
                    source="huginn",
                    why_saved="periodic self-analysis")
            return response.strip()
        except Exception:
            return ""

    # ──────────────────────────────────────────────────────────────────
    #  Visualization
    # ──────────────────────────────────────────────────────────────────

    def memory_timeline(self) -> list[dict]:
        """Build a timeline of memories for visualization.

        Returns a list of dicts suitable for plotting.
        """
        return [
            {
                "timestamp": m.timestamp,
                "importance": m.importance,
                "emotion": m.emotion,
                "vividness": round(m.vividness, 3),
                "is_flashbulb": m._is_flashbulb,
                "is_cherished": m._cherished,
                "arc_position": m._arc_position,
                "gist": m.gist,
            }
            for m in sorted(self._reflections, key=lambda m: m.timestamp)
        ]

    def emotion_distribution(self) -> dict[str, int]:
        """Count memories by emotion for visualization."""
        dist: dict[str, int] = {}
        for m in self._reflections:
            dist[m.emotion] = dist.get(m.emotion, 0) + 1
        return dict(sorted(dist.items(), key=lambda x: x[1], reverse=True))

    def importance_histogram(self) -> dict[int, int]:
        """Distribution of memories by importance level (1-10)."""
        hist: dict[int, int] = {i: 0 for i in range(1, 11)}
        for m in self._reflections:
            level = max(1, min(10, m.importance))
            hist[level] += 1
        return hist

    def arc_distribution(self) -> dict[str, int]:
        """Distribution of memories across narrative arc positions."""
        dist: dict[str, int] = {}
        for m in self._reflections:
            pos = m._arc_position or "unclassified"
            dist[pos] = dist.get(pos, 0) + 1
        return dist

    def drift_report(self) -> list[dict]:
        """Memories that have emotionally drifted, with magnitude."""
        return [
            {
                "gist": m.gist,
                "original_emotion": m._original_emotion,
                "current_emotion": m.emotion,
                "drift_magnitude": round(m.drift_magnitude, 3),
                "timestamp": m.timestamp,
            }
            for m in self._reflections
            if m.has_drifted
        ]

    def neurochemistry_snapshot(self) -> dict:
        """Current neurochemistry state for visualization."""
        if not self._chemistry.enabled:
            return {"enabled": False}
        try:
            return self._chemistry.to_dict()
        except Exception:
            return {"enabled": True, "error": "cannot serialize"}

    def yggdrasil_graph(self) -> dict[str, list[str]]:
        """Export the Yggdrasil graph as adjacency list for visualization.

        Keys are memory gists, values are lists of connected memory gists.
        """
        graph: dict[str, list[str]] = {}
        n = len(self._reflections)
        for idx, neighbors in self._yggdrasil.items():
            if idx < n:
                key = self._reflections[idx].gist
                connected = [
                    self._reflections[j].gist
                    for j, _, _ in neighbors if j < n]
                graph[key] = connected
        return graph

    def viz_summary(self) -> dict:
        """All-in-one visualization payload."""
        return {
            "timeline": self.memory_timeline(),
            "emotions": self.emotion_distribution(),
            "importance": self.importance_histogram(),
            "arcs": self.arc_distribution(),
            "drift": self.drift_report(),
            "chemistry": self.neurochemistry_snapshot(),
            "yggdrasil_edges": sum(
                len(e) for e in self._yggdrasil.values()),
            "project": self.get_project_overview(),
        }

    # ──────────────────────────────────────────────────────────────────
    #  Persistence
    # ──────────────────────────────────────────────────────────────────

    def save(self):
        """Persist all memory data to disk."""
        self._data_dir.mkdir(parents=True, exist_ok=True)

        # Reflections
        self._write_json(
            self._data_dir / "reflections.json",
            [m.to_dict() for m in self._reflections])

        # Social impressions
        social_dir = self._data_dir / "social"
        social_dir.mkdir(exist_ok=True)
        for entity, impressions in self._social.items():
            fname = re.sub(r'[^\w]', '_', entity.lower()) + ".json"
            self._write_json(
                social_dir / fname,
                [m.to_dict() for m in impressions])

        # Lessons
        self._write_json(
            self._data_dir / "lessons.json",
            [l.to_dict() for l in self._lessons])

        # Reminders
        self._write_json(
            self._data_dir / "reminders.json",
            [r.to_dict() for r in self._reminders])

        # Facts
        self._write_json(
            self._data_dir / "facts.json",
            [f.to_dict() for f in self._facts])

        # Chemistry
        if self._chemistry.enabled:
            self._write_json(
                self._data_dir / "chemistry.json",
                self._chemistry.to_dict())

        # Meta (mood, session, etc.)
        self._write_json(
            self._data_dir / "meta.json",
            {"mood": list(self._mood),
             "session_count": self._session_count,
             "active_project": self._active_project})

        # Task branch
        self._write_json(
            self._data_dir / "tasks.json",
            [t.to_dict() for t in self._project_tasks])
        self._write_json(
            self._data_dir / "actions.json",
            [a.to_dict() for a in self._project_actions])
        self._write_json(
            self._data_dir / "solutions.json",
            [s.to_dict() for s in self._solutions])
        self._write_json(
            self._data_dir / "artifacts.json",
            [a.to_dict() for a in self._artifacts])

        # Inferred relational edges
        if self._inferred_edges:
            edges_serializable = {
                f"{k[0]},{k[1]}": v
                for k, v in self._inferred_edges.items()}
            self._write_json(
                self._data_dir / "inferred_edges.json",
                edges_serializable)

        # VividEmbed
        if self._embed is not None:
            try:
                self._embed.save()
            except Exception:
                pass

    def _load(self):
        """Load persisted data from disk."""
        # Reflections
        rpath = self._data_dir / "reflections.json"
        if rpath.exists():
            data = self._read_json(rpath)
            if isinstance(data, list):
                self._reflections = [Memory.from_dict(d) for d in data]
                self._rebuild_index()

        # Social
        social_dir = self._data_dir / "social"
        if social_dir.exists():
            for f in social_dir.glob("*.json"):
                data = self._read_json(f)
                if isinstance(data, list) and data:
                    entity = data[0].get("entity", f.stem)
                    self._social[entity] = [
                        Memory.from_dict(d) for d in data]

        # Lessons
        lpath = self._data_dir / "lessons.json"
        if lpath.exists():
            data = self._read_json(lpath)
            if isinstance(data, list):
                self._lessons = [Lesson.from_dict(d) for d in data]

        # Reminders
        rpath = self._data_dir / "reminders.json"
        if rpath.exists():
            data = self._read_json(rpath)
            if isinstance(data, list):
                self._reminders = [Reminder.from_dict(d) for d in data]

        # Facts
        fpath = self._data_dir / "facts.json"
        if fpath.exists():
            data = self._read_json(fpath)
            if isinstance(data, list):
                self._facts = [ShortTermFact.from_dict(d) for d in data]

        # Chemistry
        cpath = self._data_dir / "chemistry.json"
        if cpath.exists() and _NeuroChemistry is not None:
            data = self._read_json(cpath)
            if isinstance(data, dict):
                try:
                    self._chemistry = _NeuroChemistry.from_dict(data)
                except Exception:
                    pass

        # Meta
        mpath = self._data_dir / "meta.json"
        if mpath.exists():
            data = self._read_json(mpath)
            if isinstance(data, dict):
                mood = data.get("mood", [0, 0, 0])
                self._mood = tuple(mood)
                self._session_count = data.get("session_count", 0)
                self._active_project = data.get("active_project", "")

        # Task branch
        tpath = self._data_dir / "tasks.json"
        if tpath.exists():
            data = self._read_json(tpath)
            if isinstance(data, list):
                self._project_tasks = [TaskRecord.from_dict(d) for d in data]

        apath = self._data_dir / "actions.json"
        if apath.exists():
            data = self._read_json(apath)
            if isinstance(data, list):
                self._project_actions = [ActionRecord.from_dict(d) for d in data]

        spath = self._data_dir / "solutions.json"
        if spath.exists():
            data = self._read_json(spath)
            if isinstance(data, list):
                self._solutions = [SolutionPattern.from_dict(d) for d in data]

        artpath = self._data_dir / "artifacts.json"
        if artpath.exists():
            data = self._read_json(artpath)
            if isinstance(data, list):
                self._artifacts = [ArtifactRecord.from_dict(d) for d in data]

        # Inferred relational edges
        iepath = self._data_dir / "inferred_edges.json"
        if iepath.exists():
            data = self._read_json(iepath)
            if isinstance(data, dict):
                self._inferred_edges = {}
                for key_str, strength in data.items():
                    parts = key_str.split(",")
                    if len(parts) == 2:
                        try:
                            self._inferred_edges[
                                (int(parts[0]), int(parts[1]))] = float(strength)
                        except ValueError:
                            pass

        # ── Rebuild Yggdrasil graph ───────────────────────────────────
        if len(self._reflections) >= 2:
            self._build_yggdrasil()

    # ──────────────────────────────────────────────────────────────────
    #  Stats
    # ──────────────────────────────────────────────────────────────────

    def stats(self) -> dict:
        """Summary of the memory system's state."""
        return {
            "total_reflections": len(self._reflections),
            "flashbulb_count": sum(
                1 for m in self._reflections if m._is_flashbulb),
            "anchor_count": sum(
                1 for m in self._reflections if m._anchor),
            "cherished_count": sum(
                1 for m in self._reflections if m._cherished),
            "embed_synced": sum(
                1 for m in self._reflections if m._embed_uid),
            "social_entities": list(self._social.keys()),
            "total_social": sum(
                len(v) for v in self._social.values()),
            "total_lessons": len(self._lessons),
            "unresolved_lessons": sum(
                1 for l in self._lessons
                if l.consecutive_failures > 0),
            "total_reminders": len(self._reminders),
            "pending_reminders": sum(
                1 for r in self._reminders if not r.fired),
            "priming_buffer_size": len(self._priming_buffer),
            "mood": self.mood_label,
            "chemistry_active": self._chemistry.enabled,
            "embed_active": self._embed is not None,
            "dampening_active": self.is_dampened,
            "audit_events": len(self._audit.get_recent(100)),
            "dated_memories": sum(
                1 for m in self._reflections if m._mentioned_dates),
            "unique_dates_indexed": len(self._date_index),
            "visual_memories": sum(
                1 for m in self._reflections if m.has_visual),
            "visual_enabled": self._visual_enabled,
            "huginn_insights": sum(
                1 for m in self._reflections if m.source == "huginn"),
            "volva_insights": sum(
                1 for m in self._reflections if m.source == "volva"),
            "yggdrasil_edges": sum(
                len(e) for e in self._yggdrasil.values()),
            "yggdrasil_roots": len(self.yggdrasil_roots()),
            "yggdrasil_inferred_edges": len(self._inferred_edges) // 2,
            "yggdrasil_edge_types": self._yggdrasil_edge_type_counts(),
            "drifted_memories": sum(
                1 for m in self._reflections if m.has_drifted),
            "max_drift": max(
                (m.drift_magnitude for m in self._reflections),
                default=0.0),
            "avg_novelty": round(
                sum(m._novelty_score for m in self._reflections)
                / max(len(self._reflections), 1), 3),
            "total_facts": len(self._facts),
            "live_facts": sum(1 for f in self._facts if f.vividness > 0.1),
            # Task branch
            "active_project": self._active_project,
            "total_tasks": len(self._project_tasks),
            "active_tasks": sum(
                1 for t in self._project_tasks if t.status == "active"),
            "completed_tasks": sum(
                1 for t in self._project_tasks if t.status == "completed"),
            "total_actions": len(self._project_actions),
            "total_solutions": len(self._solutions),
            "total_artifacts": len(self._artifacts),
            # Arc tracking
            "arc_positions": self.arc_distribution(),
            # Encryption / LLM status
            "encryption_active": self._fernet is not None,
            "llm_active": self._llm_fn is not None,
        }

    # ──────────────────────────────────────────────────────────────────
    #  Internal: Yggdrasil edge type summary
    # ──────────────────────────────────────────────────────────────────

    def _yggdrasil_edge_type_counts(self) -> dict[str, int]:
        counts: dict[str, int] = {}
        for edges in self._yggdrasil.values():
            for _, edge_type, _ in edges:
                counts[edge_type] = counts.get(edge_type, 0) + 1
        return counts

    # ──────────────────────────────────────────────────────────────────
    #  Internal: word index for fast retrieval
    # ──────────────────────────────────────────────────────────────────

    def _rebuild_index(self):
        self._word_index = {}
        self._date_index = {}
        for i, mem in enumerate(self._reflections):
            self._index_memory(i, mem)

    def _index_memory(self, idx: int, mem: Memory):
        for w in _resonance_words(f"{mem.content} {mem.emotion}"):
            if w not in self._word_index:
                self._word_index[w] = set()
            self._word_index[w].add(idx)
        # Index mentioned dates
        for ds in mem._mentioned_dates:
            if ds not in self._date_index:
                self._date_index[ds] = set()
            self._date_index[ds].add(idx)

    def _candidate_indices(self, query_words: set[str]) -> set[int]:
        indices: set[int] = set()
        for w in query_words:
            indices |= self._word_index.get(w, set())
            # Prefix matching for partial words
            if len(w) >= 5:
                prefix = w[:5]
                for iw, idxs in self._word_index.items():
                    if iw.startswith(prefix):
                        indices |= idxs
        return indices

    def _bm25_scores(self, query_words: set[str]) -> dict[int, float]:
        """BM25-style keyword scores using IDF weighting.

        Rare distinctive words (names, places, dates) score higher than
        common words — exactly what catches the keyword matches that
        pure semantic search misses.
        """
        N = len(self._reflections)
        if N == 0 or not query_words:
            return {}

        scores: dict[int, float] = {}
        for word in query_words:
            matching = self._word_index.get(word, set())
            if not matching:
                # Prefix fallback for partial words
                if len(word) >= 5:
                    prefix = word[:5]
                    matching = set()
                    for iw, idxs in self._word_index.items():
                        if iw.startswith(prefix):
                            matching |= idxs
                if not matching:
                    continue

            # IDF: rare words matter more
            df = len(matching)
            idf = math.log((N - df + 0.5) / (df + 0.5) + 1.0)

            for idx in matching:
                if idx < N:
                    scores[idx] = scores.get(idx, 0.0) + idf

        return scores

    # ──────────────────────────────────────────────────────────────────
    #  Internal: JSON I/O  (with optional encryption at rest)
    # ──────────────────────────────────────────────────────────────────

    def _write_json(self, path: Path, data):
        path.parent.mkdir(parents=True, exist_ok=True)
        raw = json.dumps(data, ensure_ascii=False, indent=1).encode("utf-8")
        if self._fernet is not None:
            raw = self._fernet.encrypt(raw)
            tmp = path.with_suffix(".tmp")
            with open(tmp, "wb") as f:
                f.write(raw)
            tmp.replace(path)
        else:
            tmp = path.with_suffix(".tmp")
            with open(tmp, "w", encoding="utf-8") as f:
                f.write(raw.decode("utf-8"))
            tmp.replace(path)

    def _read_json(self, path: Path):
        try:
            if self._fernet is not None:
                with open(path, "rb") as f:
                    raw = self._fernet.decrypt(f.read())
                return json.loads(raw.decode("utf-8"))
            else:
                with open(path, "r", encoding="utf-8") as f:
                    return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError, Exception):
            return None
