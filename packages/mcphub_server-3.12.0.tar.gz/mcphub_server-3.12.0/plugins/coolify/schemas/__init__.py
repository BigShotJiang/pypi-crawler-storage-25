"""Coolify Plugin Schemas"""
