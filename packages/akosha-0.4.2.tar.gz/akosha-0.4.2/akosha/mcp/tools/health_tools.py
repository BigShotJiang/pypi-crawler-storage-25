"""Health check MCP tools for Akosha.

These tools provide standardized health check endpoints following the
mcp-common health infrastructure pattern.

Design: docs/plans/2026-02-27-health-check-system-design.md
"""

from __future__ import annotations

import time
from typing import Any

from mcp_common.health import (
    DependencyConfig,
    register_health_tools,
)

# Service metadata
SERVICE_NAME = "akosha"
SERVICE_VERSION = "0.1.0"
SERVICE_START_TIME = time.time()

# Default dependencies for Akosha
# These can be overridden via environment variables:
# AKOSHA_HEALTH__DEPENDENCIES__SESSION_BUDDY__HOST=remote-host  # noqa: ERA001
DEFAULT_DEPENDENCIES: dict[str, DependencyConfig] = {
    "session_buddy": DependencyConfig(
        host="localhost",
        port=8678,
        required=False,  # Optional - for session context
        timeout_seconds=10,
    ),
    "mahavishnu": DependencyConfig(
        host="localhost",
        port=8680,
        required=False,  # Optional - for orchestration
        timeout_seconds=10,
    ),
}


def register_health_tools_akosha(app: Any) -> None:
    """Register health check tools with Akosha MCP server.

    This uses mcp-common's register_health_tools directly since
    Akosha uses FastMCP app directly (not the registry pattern).

    Tools registered:
        - health_check_service: Check health of a specific service
        - health_check_all: Check all configured dependencies
        - wait_for_dependency: Wait for a dependency to become healthy
        - wait_for_all_dependencies: Wait for all dependencies
        - get_liveness: Basic liveness probe
        - get_readiness: Readiness probe with dependency checks

    Args:
        app: FastMCP application instance
    """
    register_health_tools(
        mcp=app,
        service_name=SERVICE_NAME,
        version=SERVICE_VERSION,
        start_time=SERVICE_START_TIME,
        dependencies=DEFAULT_DEPENDENCIES,
    )


__all__ = ["register_health_tools_akosha"]
