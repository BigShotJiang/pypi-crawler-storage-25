#!/usr/bin/env python3
from __future__ import annotations
"""
Flowtriq DDoS Detection Agent
Monitors network traffic on Linux servers and reports to the Flowtriq API.
"""

import argparse
import collections
import json
import logging
import math
import os
import re
import signal
import sys
import threading
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

VERSION = "1.8.2"
CONFIG_PATH = "/etc/ftagent/config.json"
DEFAULT_CONFIG = {
    "api_key": "",
    "node_uuid": "",  # Required — copy from Flowtriq dashboard → Nodes
    "api_base": "https://flowtriq.com/api/v1",
    "interface": "auto",
    "pcap_enabled": True,
    "pcap_mode": "tcpdump",  # "tcpdump" (recommended, near-zero CPU) or "scapy" (per-packet Python analysis — high CPU on busy servers)
    "pcap_dir": "/var/lib/ftagent/pcaps",
    "log_file": "/var/log/ftagent.log",
    "log_level": "INFO",
    "dynamic_threshold": True,
    "baseline_window": 300,
    "health_port": 9100,
    "auto_update": True,
    # Flow protocol collector (sFlow/NetFlow/IPFIX)
    "flow_enabled": False,
    "flow_protocol": "auto",  # "auto", "sflow", "netflow_v5", "netflow_v9", "ipfix"
    "flow_port": 0,           # 0 = use protocol default (6343/2055/4739)
    "flow_bind": "0.0.0.0",
    "flow_sample_rate": 0,    # Override sample rate (0 = use what's in the packets)
    "flow_source_ips": [],    # Allowed source IPs (empty = accept all)
}

# Flow collector (built-in, no extra deps)
from ftagent.flow_collector import FlowCollector

# Optional dependency imports
try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

try:
    from scapy.all import IP, TCP, UDP, ICMP, DNS, Raw, PcapWriter, sniff
    SCAPY_AVAILABLE = True
except ImportError:
    SCAPY_AVAILABLE = False

try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False

try:
    from colorama import Fore, Style, init as colorama_init
    colorama_init()
    COLOR = True
except ImportError:
    COLOR = False


# ---------------------------------------------------------------------------
# Update Checker
# ---------------------------------------------------------------------------

def check_for_updates(force: bool = False, interactive: bool = True) -> None:
    """Check GitHub releases for a newer agent version. Optionally prompt to upgrade."""
    import urllib.request
    import json as _json

    # Throttle: only check once per day unless forced
    state_file = os.path.expanduser("~/.ftagent_update_check")
    if not force:
        try:
            mtime = os.path.getmtime(state_file)
            if time.time() - mtime < 86400:
                return
        except OSError:
            pass

    try:
        # Try GitHub releases first, fall back to tags
        latest = None
        for api_url in [
            "https://api.github.com/repos/Flowtriq/ftagent/releases/latest",
            "https://api.github.com/repos/Flowtriq/ftagent/tags?per_page=1",
        ]:
            try:
                req = urllib.request.Request(api_url, headers={"User-Agent": f"ftagent/{VERSION}"})
                with urllib.request.urlopen(req, timeout=10) as resp:
                    data = _json.loads(resp.read().decode())
                if isinstance(data, list) and data:
                    latest = data[0].get("name", "").lstrip("v")
                elif isinstance(data, dict):
                    latest = data.get("tag_name", "").lstrip("v")
                if latest:
                    break
            except Exception:
                continue

        if not latest:
            return

        # Record check time
        Path(state_file).touch()

        def _ver(v):
            try:
                return tuple(int(x) for x in v.split("."))
            except (ValueError, AttributeError):
                return (0,)

        if _ver(latest) <= _ver(VERSION):
            return  # Up to date

        msg = f"A newer version of ftagent is available: v{latest} (you have v{VERSION})"

        if not interactive:
            # Running as daemon: just log it
            try:
                logger.warning("%s. Run: pip install --upgrade ftagent", msg)
            except Exception:
                print(f"  {msg}")
                print("  Run: pip install --upgrade ftagent")
            return

        # Interactive: prompt to upgrade
        print(f"\n  {msg}")
        print(f"  Release: https://github.com/Flowtriq/ftagent/releases/tag/v{latest}\n")

        try:
            answer = input("  Would you like to update now? [y/N] ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            return

        if answer not in ("y", "yes"):
            return

        _do_pip_upgrade()

    except Exception:
        pass  # Never let update check break the agent


def _do_pip_upgrade() -> None:
    """Run pip upgrade, handling --break-system-packages for PEP 668."""
    import subprocess as _sp

    pip_cmd = [sys.executable, "-m", "pip", "install", "--upgrade", "ftagent"]

    print("  Updating ftagent...")
    result = _sp.run(pip_cmd, capture_output=True, text=True)

    if result.returncode == 0:
        print("  Updated successfully. Restart the agent to use the new version.")
        print("  Run: systemctl restart ftagent")
        return

    # PEP 668: externally managed Python (Debian 12+, Ubuntu 23.04+)
    if "externally-managed-environment" in result.stderr:
        print("  System Python detected. Retrying with --break-system-packages...")
        pip_cmd.insert(-1, "--break-system-packages")
        result = _sp.run(pip_cmd, capture_output=True, text=True)
        if result.returncode == 0:
            print("  Updated successfully. Restart the agent to use the new version.")
            print("  Run: systemctl restart ftagent")
            return

    print(f"  Update failed: {result.stderr.strip()}")
    print("  Try manually: pip install --upgrade ftagent")


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

logger = logging.getLogger("ftagent")


def setup_logging(log_file: str, log_level: str) -> None:
    from logging.handlers import RotatingFileHandler

    level = getattr(logging, log_level.upper(), logging.INFO)
    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s",
                            datefmt="%Y-%m-%d %H:%M:%S")
    logger.setLevel(level)
    logger.handlers.clear()

    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(fmt)
    logger.addHandler(sh)

    try:
        Path(log_file).parent.mkdir(parents=True, exist_ok=True)
        fh = RotatingFileHandler(
            log_file, maxBytes=10 * 1024 * 1024, backupCount=5)
        fh.setFormatter(fmt)
        logger.addHandler(fh)
    except OSError as exc:
        logger.warning("Cannot open log file %s: %s", log_file, exc)


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

def load_config(path: str) -> dict:
    cfg = dict(DEFAULT_CONFIG)
    try:
        with open(path) as f:
            cfg.update(json.load(f))
    except FileNotFoundError:
        logger.warning("Config not found at %s — using defaults", path)
    except json.JSONDecodeError as exc:
        logger.error("Invalid JSON in %s: %s", path, exc)
    return cfg


def save_config(path: str, cfg: dict) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(cfg, f, indent=2)
    os.chmod(path, 0o600)
    logger.info("Config saved to %s", path)


# ---------------------------------------------------------------------------
# API Client
# ---------------------------------------------------------------------------

class APIClient:
    # Circuit breaker settings
    CB_FAILURE_THRESHOLD = 5       # consecutive failures to trip open
    CB_RECOVERY_TIMEOUT  = 60      # seconds before half-open probe
    CB_HALF_OPEN_MAX     = 1       # probes allowed in half-open state

    def __init__(self, cfg: dict):
        self.base = cfg["api_base"].rstrip("/")
        self.api_key = cfg["api_key"]
        self.node_uuid = cfg["node_uuid"]
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {self.api_key}",
            "X-Node-UUID": self.node_uuid,
            "Content-Type": "application/json",
            "User-Agent": f"ftagent/{VERSION}",
        })
        self.retry_queue: collections.deque = collections.deque(maxlen=2000)
        # Circuit breaker state
        self._cb_state = "closed"          # closed | open | half-open
        self._cb_failures = 0
        self._cb_last_failure: float = 0.0
        self._cb_lock = threading.Lock()

    def _cb_record_success(self) -> None:
        with self._cb_lock:
            self._cb_failures = 0
            if self._cb_state != "closed":
                logger.info("Circuit breaker closed — API recovered")
                self._cb_state = "closed"

    def _cb_record_failure(self) -> None:
        with self._cb_lock:
            self._cb_failures += 1
            self._cb_last_failure = time.monotonic()
            if self._cb_failures >= self.CB_FAILURE_THRESHOLD and self._cb_state == "closed":
                self._cb_state = "open"
                logger.warning("Circuit breaker OPEN after %d consecutive failures — "
                               "blocking API calls for %ds",
                               self._cb_failures, self.CB_RECOVERY_TIMEOUT)

    def _cb_allow_request(self) -> bool:
        with self._cb_lock:
            if self._cb_state == "closed":
                return True
            elapsed = time.monotonic() - self._cb_last_failure
            if self._cb_state == "open" and elapsed >= self.CB_RECOVERY_TIMEOUT:
                self._cb_state = "half-open"
                logger.info("Circuit breaker half-open — allowing probe request")
                return True
            if self._cb_state == "half-open":
                return True  # allow the single probe
            return False

    @property
    def circuit_breaker_state(self) -> str:
        return self._cb_state

    def _post(self, path: str, payload: dict, timeout: int = 10,
              retries: int = 3) -> Optional[dict]:
        if not self._cb_allow_request():
            self.retry_queue.append(("POST", path, payload, timeout))
            return None
        url = f"{self.base}{path}"
        for attempt in range(1, retries + 1):
            try:
                resp = self.session.post(url, json=payload, timeout=timeout)
                if resp.status_code == 503:
                    retry_after = resp.headers.get("Retry-After")
                    if retry_after:
                        try:
                            delay = int(retry_after)
                        except ValueError:
                            delay = 2 ** attempt
                    else:
                        delay = min(2 ** attempt, 16)
                    logger.warning(
                        "API POST %s returned 503 (attempt %d/%d), "
                        "retrying in %ds", path, attempt, retries, delay)
                    if attempt < retries:
                        time.sleep(delay)
                        continue
                    else:
                        self._cb_record_failure()
                        self.retry_queue.append(("POST", path, payload, timeout))
                        return None
                resp.raise_for_status()
                self._cb_record_success()
                if resp.content:
                    return resp.json()
                return {}
            except Exception as exc:
                logger.warning("API POST %s attempt %d/%d failed: %s",
                               path, attempt, retries, exc)
                if attempt < retries:
                    time.sleep(min(2 ** attempt, 10))
                else:
                    self._cb_record_failure()
                    self.retry_queue.append(("POST", path, payload, timeout))
        return None

    def _get(self, path: str, timeout: int = 10,
             retries: int = 3) -> Optional[dict]:
        if not self._cb_allow_request():
            return None
        url = f"{self.base}{path}"
        for attempt in range(1, retries + 1):
            try:
                resp = self.session.get(url, timeout=timeout)
                if resp.status_code == 503:
                    retry_after = resp.headers.get("Retry-After")
                    if retry_after:
                        try:
                            delay = int(retry_after)
                        except ValueError:
                            delay = 2 ** attempt
                    else:
                        delay = min(2 ** attempt, 16)
                    logger.warning(
                        "API GET %s returned 503 (attempt %d/%d), "
                        "retrying in %ds", path, attempt, retries, delay)
                    if attempt < retries:
                        time.sleep(delay)
                        continue
                    else:
                        self._cb_record_failure()
                        return None
                resp.raise_for_status()
                self._cb_record_success()
                return resp.json()
            except Exception as exc:
                logger.warning("API GET %s attempt %d/%d failed: %s",
                               path, attempt, retries, exc)
                if attempt < retries:
                    time.sleep(min(2 ** attempt, 10))
                else:
                    self._cb_record_failure()
        return None

    def send_metrics(self, data: dict) -> None:
        self._post("/agent/metrics", data, timeout=5)

    def open_incident(self, data: dict) -> Optional[dict]:
        return self._post("/agent/incidents", data, timeout=15, retries=3)

    def update_incident(self, inc_uuid: str, data: dict) -> None:
        self._post(f"/agent/incidents/{inc_uuid}", data, timeout=10, retries=3)

    def resolve_incident(self, inc_uuid: str, data: dict) -> None:
        self._post(f"/agent/incidents/{inc_uuid}/resolve", data, timeout=15,
                   retries=3)

    def upload_pcap(self, inc_uuid: str, filepath: str,
                    retries: int = 3) -> None:
        url = f"{self.base}/agent/incidents/{inc_uuid}/pcap"
        file_size = os.path.getsize(filepath)
        chunk_size = 2 * 1024 * 1024  # 2 MB chunks

        for attempt in range(1, retries + 1):
            try:
                if file_size <= chunk_size:
                    # Small file: single upload
                    with open(filepath, "rb") as f:
                        resp = self.session.post(
                            url,
                            files={"pcap": (os.path.basename(filepath), f,
                                            "application/octet-stream")},
                            headers={"Content-Type": None},
                            timeout=120,
                        )
                        resp.raise_for_status()
                else:
                    # Large file: chunked streaming upload
                    total_chunks = math.ceil(file_size / chunk_size)
                    logger.info("PCAP chunked upload: %d chunks (%.1f MB)",
                                total_chunks, file_size / 1048576)
                    with open(filepath, "rb") as f:
                        for i in range(total_chunks):
                            chunk_data = f.read(chunk_size)
                            if not chunk_data:
                                break
                            resp = self.session.post(
                                url,
                                data=chunk_data,
                                headers={
                                    "Content-Type": "application/octet-stream",
                                    "X-Chunk-Index": str(i),
                                    "X-Chunk-Total": str(total_chunks),
                                },
                                timeout=60,
                            )
                            resp.raise_for_status()
                            logger.debug("Chunk %d/%d uploaded", i + 1,
                                         total_chunks)

                logger.info("PCAP uploaded for incident %s (attempt %d)",
                            inc_uuid, attempt)
                return
            except Exception as exc:
                logger.warning("PCAP upload attempt %d/%d failed for %s: %s",
                               attempt, retries, inc_uuid, exc)
                if attempt < retries:
                    time.sleep(min(2 ** attempt, 15))

        logger.error("PCAP upload failed after %d attempts for %s",
                     retries, inc_uuid)

    def heartbeat(self, data: dict) -> None:
        result = self._post("/agent/heartbeat", data, timeout=10)
        if result is not None:
            self.flush_retry_queue()

    def get_config(self) -> Optional[dict]:
        return self._get("/agent/config", timeout=10)

    def flush_retry_queue(self) -> None:
        flushed = 0
        while self.retry_queue:
            method, path, payload, timeout = self.retry_queue.popleft()
            url = f"{self.base}{path}"
            try:
                resp = self.session.post(url, json=payload, timeout=timeout)
                resp.raise_for_status()
                flushed += 1
            except Exception:
                break
        if flushed:
            logger.info("Flushed %d queued requests", flushed)

    def test_connectivity(self) -> bool:
        try:
            resp = self.session.post(
                f"{self.base}/agent/heartbeat",
                json={"version": VERSION, "baseline_ready": False,
                      "baseline_avg_pps": 0, "baseline_p99_pps": 0},
                timeout=10,
            )
            resp.raise_for_status()
            return True
        except Exception as exc:
            logger.error("Connectivity test failed: %s", exc)
            return False


# ---------------------------------------------------------------------------
# PPS Monitor — reads /proc/net/dev and /proc/net/snmp
# ---------------------------------------------------------------------------

class PPSMonitor:
    def __init__(self, interface: str = "auto"):
        self.interface = self._resolve_interface(interface)
        self.prev_rx_packets = 0
        self.prev_rx_bytes = 0
        self.prev_time = 0.0
        self.prev_tcp = 0
        self.prev_udp = 0
        self.prev_icmp = 0
        self.first_read = True
        self.pps = 0.0
        self.bps = 0.0
        self.tcp_pct = 0.0
        self.udp_pct = 0.0
        self.icmp_pct = 0.0
        self.conn_count = 0
        self._conn_count_interval = 15  # seconds between /proc/net/tcp reads
        self._last_conn_read = 0.0
        logger.info("Monitoring interface: %s", self.interface)

    @staticmethod
    def _resolve_interface(iface: str) -> str:
        if iface != "auto":
            return iface
        # Pick the non-lo interface with the most received bytes.
        # Handles servers with docker0, br-*, veth*, virbr*, dummy*, tun*, etc.
        skip = {"lo", "docker0"}
        skip_prefix = ("br-", "veth", "virbr", "dummy", "tun", "tap", "flannel", "cni", "cali")
        best_name = None
        best_bytes = -1
        try:
            with open("/proc/net/dev") as f:
                for line in f:
                    parts = line.strip().split(":")
                    if len(parts) != 2:
                        continue
                    name = parts[0].strip()
                    if name in skip or name.startswith(skip_prefix):
                        continue
                    fields = parts[1].split()
                    if len(fields) >= 1:
                        rx_bytes = int(fields[0])
                        if rx_bytes > best_bytes:
                            best_bytes = rx_bytes
                            best_name = name
        except (OSError, ValueError):
            pass
        if best_name:
            return best_name
        # Fallback: first non-lo interface
        try:
            with open("/proc/net/dev") as f:
                for line in f:
                    parts = line.strip().split(":")
                    if len(parts) == 2:
                        name = parts[0].strip()
                        if name != "lo":
                            return name
        except OSError:
            pass
        return "eth0"

    def read(self) -> bool:
        now = time.monotonic()
        rx_packets, rx_bytes = self._read_dev()
        tcp_in, udp_in, icmp_in = self._read_snmp()

        if self.first_read:
            self.prev_rx_packets = rx_packets
            self.prev_rx_bytes = rx_bytes
            self.prev_time = now
            self.prev_tcp = tcp_in
            self.prev_udp = udp_in
            self.prev_icmp = icmp_in
            self.first_read = False
            return False

        dt = now - self.prev_time
        if dt <= 0:
            return False

        self.pps = (rx_packets - self.prev_rx_packets) / dt
        self.bps = (rx_bytes - self.prev_rx_bytes) * 8 / dt

        d_tcp = tcp_in - self.prev_tcp
        d_udp = udp_in - self.prev_udp
        d_icmp = icmp_in - self.prev_icmp
        total_proto = d_tcp + d_udp + d_icmp

        if total_proto > 0:
            self.tcp_pct = round(d_tcp / total_proto * 100, 1)
            self.udp_pct = round(d_udp / total_proto * 100, 1)
            self.icmp_pct = round(d_icmp / total_proto * 100, 1)

        # /proc/net/tcp is expensive (kernel serializes full socket table).
        # Read every 15s instead of every tick — not needed for detection.
        if now - self._last_conn_read >= self._conn_count_interval:
            self.conn_count = self._read_conn_count()
            self._last_conn_read = now

        self.prev_rx_packets = rx_packets
        self.prev_rx_bytes = rx_bytes
        self.prev_time = now
        self.prev_tcp = tcp_in
        self.prev_udp = udp_in
        self.prev_icmp = icmp_in
        return True

    def _read_dev(self) -> tuple:
        try:
            with open("/proc/net/dev") as f:
                for line in f:
                    if self.interface in line:
                        fields = line.split(":")[1].split()
                        return int(fields[1]), int(fields[0])
        except (OSError, IndexError, ValueError):
            pass
        return 0, 0

    @staticmethod
    def _read_snmp() -> tuple:
        tcp_in = udp_in = icmp_in = 0
        try:
            with open("/proc/net/snmp") as f:
                lines = f.readlines()
            for i in range(0, len(lines) - 1, 2):
                header = lines[i].strip()
                values = lines[i + 1].strip()
                if header.startswith("Tcp:"):
                    cols = header.split()
                    vals = values.split()
                    if "InSegs" in cols:
                        tcp_in = int(vals[cols.index("InSegs")])
                elif header.startswith("Udp:"):
                    cols = header.split()
                    vals = values.split()
                    if "InDatagrams" in cols:
                        udp_in = int(vals[cols.index("InDatagrams")])
                elif header.startswith("Icmp:"):
                    cols = header.split()
                    vals = values.split()
                    if "InMsgs" in cols:
                        icmp_in = int(vals[cols.index("InMsgs")])
        except (OSError, IndexError, ValueError):
            pass
        return tcp_in, udp_in, icmp_in

    @staticmethod
    def _read_conn_count() -> int:
        count = 0
        for path in ("/proc/net/tcp", "/proc/net/tcp6"):
            try:
                with open(path) as f:
                    count += sum(1 for _ in f) - 1
            except OSError:
                pass
        return max(count, 0)


# ---------------------------------------------------------------------------
# Baseline Manager
# ---------------------------------------------------------------------------

class BaselineManager:
    _RECALC_EVERY = 10  # recalculate percentiles every N samples
    # Use a low default floor (150 PPS) only before baseline is established.
    # Once baseline is ready, threshold is purely data-driven (p99 * 3).
    _DEFAULT_FLOOR = 150

    def __init__(self, window: int = 300):
        self.WINDOW = window
        self.samples: collections.deque = collections.deque(maxlen=self.WINDOW)
        self.avg_pps = 0.0
        self.p95_pps = 0.0
        self.p99_pps = 0.0
        self.threshold = self._DEFAULT_FLOOR
        self.baseline_ready = False
        self._since_recalc = 0
        self._running_sum = 0.0

    def add(self, pps: float) -> None:
        # Track evicted sample for running sum
        if len(self.samples) == self.samples.maxlen:
            self._running_sum -= self.samples[0]
        self.samples.append(pps)
        self._running_sum += pps
        n = len(self.samples)
        if n < 2:
            return

        self.avg_pps = self._running_sum / n
        self._since_recalc += 1

        # Full percentile sort only every N ticks (expensive O(n log n))
        if self._since_recalc >= self._RECALC_EVERY:
            self._since_recalc = 0
            sorted_s = sorted(self.samples)
            self.p95_pps = sorted_s[int(n * 0.95)]
            self.p99_pps = sorted_s[int(n * 0.99)]
            # Before baseline is ready, use a low floor so low-traffic nodes
            # can still detect attacks. Once ready, go purely data-driven.
            if self.baseline_ready:
                self.threshold = self.p99_pps * 3
            else:
                self.threshold = max(self.p99_pps * 3, self._DEFAULT_FLOOR)

        if n >= self.WINDOW:
            self.baseline_ready = True


# ---------------------------------------------------------------------------
# Traffic Analyser
# ---------------------------------------------------------------------------

class TrafficAnalyser:
    def __init__(self):
        self.reset()

    # Memory safety caps — prevent OOM on large botnets (10M+ source IPs)
    MAX_SRC_IPS = 100_000       # max unique source IPs tracked
    MAX_PKT_SAMPLES = 50_000    # max packet length / TTL samples
    MAX_DNS_QUERIES = 10_000    # max unique DNS query names
    MAX_IOC_HITS = 5_000        # max IOC match entries
    MAX_TTL_PER_IP = 10         # max unique TTLs per source IP

    def reset(self) -> None:
        self.tcp_flags = {"SYN": 0, "ACK": 0, "RST": 0, "FIN": 0,
                          "PSH": 0, "URG": 0}
        self.src_ips: dict = {}        # ip -> count
        self.src_ip_detail: dict = {}  # ip -> {tcp, udp, icmp, syn, ack, bytes, ttls}
        self.dst_ports: dict = {}
        self.pkt_lengths: list = []
        self.ttl_values: list = []
        self.dns_queries: dict = {}
        self.total_packets = 0
        self.ioc_hits: list = []
        self._src_ip_overflow = False   # flag: True once we hit cap

    def process_packet(self, pkt, ioc_matcher=None) -> None:
        self.total_packets += 1

        if not SCAPY_AVAILABLE:
            return

        if pkt.haslayer(IP):
            ip = pkt[IP]
            src = ip.src

            # Bounded src_ips: only track new IPs if under cap
            if src in self.src_ips:
                self.src_ips[src] += 1
            elif len(self.src_ips) < self.MAX_SRC_IPS:
                self.src_ips[src] = 1
            else:
                if not self._src_ip_overflow:
                    self._src_ip_overflow = True
                    logger.warning("Source IP tracking cap reached (%d IPs) — additional IPs not individually tracked", self.MAX_SRC_IPS)

            # Bounded packet length / TTL samples
            if len(self.pkt_lengths) < self.MAX_PKT_SAMPLES:
                self.pkt_lengths.append(len(pkt))
            if len(self.ttl_values) < self.MAX_PKT_SAMPLES:
                self.ttl_values.append(ip.ttl)

            # Bounded per-IP detail tracking
            if src in self.src_ip_detail:
                d = self.src_ip_detail[src]
            elif len(self.src_ip_detail) < self.MAX_SRC_IPS:
                d = {"tcp": 0, "udp": 0, "icmp": 0, "syn": 0, "ack": 0, "bytes": 0, "ttls": set()}
                self.src_ip_detail[src] = d
            else:
                d = None

            if d is not None:
                d["bytes"] += len(pkt)
                if len(d["ttls"]) < self.MAX_TTL_PER_IP:
                    d["ttls"].add(ip.ttl)

            if pkt.haslayer(TCP):
                tcp = pkt[TCP]
                self.dst_ports[tcp.dport] = self.dst_ports.get(tcp.dport, 0) + 1
                d["tcp"] += 1
                flags = tcp.flags
                if flags & 0x02:
                    self.tcp_flags["SYN"] += 1
                    d["syn"] += 1
                if flags & 0x10:
                    self.tcp_flags["ACK"] += 1
                    d["ack"] += 1
                if flags & 0x04:
                    self.tcp_flags["RST"] += 1
                if flags & 0x01:
                    self.tcp_flags["FIN"] += 1
                if flags & 0x08:
                    self.tcp_flags["PSH"] += 1
                if flags & 0x20:
                    self.tcp_flags["URG"] += 1

            elif pkt.haslayer(UDP):
                self.dst_ports[pkt[UDP].dport] = (
                    self.dst_ports.get(pkt[UDP].dport, 0) + 1)
                d["udp"] += 1

            elif pkt.haslayer(ICMP):
                d["icmp"] += 1

            if pkt.haslayer(DNS) and pkt[DNS].qr == 0:
                try:
                    qname = pkt[DNS].qd.qname.decode(errors="ignore")
                    if qname in self.dns_queries or len(self.dns_queries) < self.MAX_DNS_QUERIES:
                        self.dns_queries[qname] = self.dns_queries.get(qname, 0) + 1
                except Exception:
                    pass

        if ioc_matcher and pkt.haslayer(Raw):
            hit = ioc_matcher.check(bytes(pkt[Raw].load))
            if hit and len(self.ioc_hits) < self.MAX_IOC_HITS:
                self.ioc_hits.append(hit)

    def src_ip_entropy(self) -> float:
        total = sum(self.src_ips.values())
        if total == 0:
            return 0.0
        entropy = 0.0
        for count in self.src_ips.values():
            p = count / total
            if p > 0:
                entropy -= p * math.log2(p)
        return round(entropy, 3)

    def ttl_entropy(self) -> float:
        if not self.ttl_values:
            return 0.0
        freq: dict = {}
        for t in self.ttl_values:
            freq[t] = freq.get(t, 0) + 1
        total = len(self.ttl_values)
        entropy = 0.0
        for count in freq.values():
            p = count / total
            if p > 0:
                entropy -= p * math.log2(p)
        return round(entropy, 3)

    def spoofing_detected(self) -> bool:
        return self.ttl_entropy() < 1.5 and len(self.src_ips) > 100

    def botnet_detected(self) -> bool:
        return len(self.src_ips) > 300

    def top_src_ips(self, n: int = 20) -> list:
        total = self.total_packets or 1
        result = []
        for ip, c in sorted(self.src_ips.items(),
                             key=lambda x: x[1], reverse=True)[:n]:
            entry = {"ip": ip, "count": c}
            d = self.src_ip_detail.get(ip)
            if d:
                pct = c / total
                # Confidence scoring: higher = more likely attacker
                conf = 0
                # High packet contribution = likely attacker
                if pct > 0.05: conf += 30
                elif pct > 0.02: conf += 15
                # SYN-only (no ACK) = likely SYN flood source
                if d["tcp"] > 0 and d["ack"] == 0 and d["syn"] > 0:
                    conf += 25
                # Single TTL = likely spoofed
                if len(d["ttls"]) <= 1 and c > 50:
                    conf += 20
                # Pure single-protocol = more suspicious
                protos_used = (1 if d["tcp"] > 0 else 0) + \
                              (1 if d["udp"] > 0 else 0) + \
                              (1 if d["icmp"] > 0 else 0)
                if protos_used == 1 and c > 100:
                    conf += 10
                # Very high packet count (>500 in capture window)
                if c > 500: conf += 15
                elif c > 200: conf += 5
                # Low byte/pkt ratio for UDP = amplification
                avg_pkt = d["bytes"] / max(c, 1)
                if d["udp"] > d["tcp"] and avg_pkt < 100 and c > 100:
                    conf += 10

                conf = min(conf, 100)
                entry["confidence"] = conf
                entry["tcp"] = d["tcp"]
                entry["udp"] = d["udp"]
                entry["icmp"] = d["icmp"]
                entry["ttl_unique"] = len(d["ttls"])
                entry["pct"] = round(pct * 100, 2)
            result.append(entry)
        return result

    def top_dst_ports(self, n: int = 20) -> list:
        return [{"port": p, "count": c}
                for p, c in sorted(self.dst_ports.items(),
                                   key=lambda x: x[1], reverse=True)[:n]]

    def protocol_breakdown(self) -> dict:
        """Compute protocol percentages from actual packet inspection (scapy).
        This is authoritative — unlike /proc/net/snmp which misses dropped packets."""
        tcp_total = udp_total = icmp_total = 0
        for d in self.src_ip_detail.values():
            tcp_total += d["tcp"]
            udp_total += d["udp"]
            icmp_total += d["icmp"]
        grand = tcp_total + udp_total + icmp_total
        if grand == 0:
            return {"tcp": 0, "udp": 0, "icmp": 0}
        return {
            "tcp": round(tcp_total / grand * 100, 1),
            "udp": round(udp_total / grand * 100, 1),
            "icmp": round(icmp_total / grand * 100, 1),
        }

    def syn_ratio(self) -> float:
        """SYN ratio from captured TCP flags."""
        total = sum(self.tcp_flags.values())
        return (self.tcp_flags["SYN"] / total) if total > 0 else 0.0

    def pkt_length_histogram(self) -> dict:
        buckets = {"0-64": 0, "65-128": 0, "129-256": 0, "257-512": 0,
                   "513-1024": 0, "1025-1500": 0, "1500+": 0}
        for length in self.pkt_lengths:
            if length <= 64:
                buckets["0-64"] += 1
            elif length <= 128:
                buckets["65-128"] += 1
            elif length <= 256:
                buckets["129-256"] += 1
            elif length <= 512:
                buckets["257-512"] += 1
            elif length <= 1024:
                buckets["513-1024"] += 1
            elif length <= 1500:
                buckets["1025-1500"] += 1
            else:
                buckets["1500+"] += 1
        return buckets

    def ttl_distribution(self) -> dict:
        dist: dict = {}
        for t in self.ttl_values:
            dist[t] = dist.get(t, 0) + 1
        return dict(sorted(dist.items(), key=lambda x: x[1], reverse=True)[:15])

    def avg_pkt_length(self) -> float:
        if not self.pkt_lengths:
            return 0.0
        return round(sum(self.pkt_lengths) / len(self.pkt_lengths), 1)

    def dns_query_stats(self) -> dict:
        return {
            "total": sum(self.dns_queries.values()),
            "unique": len(self.dns_queries),
            "top": sorted(self.dns_queries.items(),
                          key=lambda x: x[1], reverse=True)[:10],
        }


# ---------------------------------------------------------------------------
# IOC Matcher
# ---------------------------------------------------------------------------

class IOCMatcher:
    def __init__(self):
        self.patterns: list = []

    def load(self, patterns: list) -> None:
        self.patterns = patterns
        logger.info("Loaded %d IOC patterns", len(patterns))

    def check(self, payload: bytes) -> Optional[str]:
        for p in self.patterns:
            try:
                if p["pattern"].encode() in payload:
                    return f"{p['attack_name']}:{p['attack_family']}"
            except Exception:
                continue
        return None


# ---------------------------------------------------------------------------
# PCAP Capture
# ---------------------------------------------------------------------------

class PcapCapture:
    def __init__(self, cfg: dict, iface: str, analyser: TrafficAnalyser,
                 ioc_matcher: IOCMatcher):
        self.pcap_mode = cfg.get("pcap_mode", "tcpdump")
        self.enabled = cfg.get("pcap_enabled", True) and (SCAPY_AVAILABLE or self.pcap_mode == "tcpdump")
        self.config_path = cfg.get("_config_path", CONFIG_PATH)
        self.pcap_dir = cfg.get("pcap_dir", "/var/lib/ftagent/pcaps")
        self.iface = iface
        self._tcpdump_proc = None
        self._ring_dir = None
        self.analyser = analyser
        self.ioc_matcher = ioc_matcher
        self.ring_buffer: collections.deque = collections.deque(maxlen=1000)
        self.capture_packets: list = []
        self.capturing = False
        self.max_capture = 10000
        self._thread = None
        self._stop_event = threading.Event()
        self._pkt_counter = 0
        self._analyse_every = 10  # deep-analyse every Nth packet during capture

    def background_ring(self, shutdown: threading.Event) -> None:
        if not self.enabled:
            return

        if self.pcap_mode == "tcpdump":
            self._background_ring_tcpdump(shutdown)
        else:
            self._background_ring_scapy(shutdown)

    def _tcpdump_unavailable(self, reason: str) -> None:
        """Handle tcpdump being unavailable — warn the user, prompt to disable
        pcap or let them fix it.  Never silently fall back to scapy."""
        border = "=" * 72
        msg = f"""
{border}
  PCAP CAPTURE UNAVAILABLE — tcpdump could not be started
{border}

  Reason: {reason}

  Your pcap_mode is set to "tcpdump", which is the recommended mode for
  servers handling significant traffic.  tcpdump captures packets at
  native speed with near-zero CPU overhead.

  The alternative "scapy" mode processes every packet in Python and WILL
  cause extremely high CPU usage (90%+) on busy servers — such as game
  servers, proxies, or anything above a few thousand packets/sec.
  If you still want to use scapy, you can change pcap_mode to "scapy"
  in your config file:  {self.config_path}

  You can also ingest traffic data from an upstream router or switch
  using our built-in flow collector instead of local packet capture.
  We support sFlow, NetFlow v5, NetFlow v9, and IPFIX.
  Enable it in your config with "flow_enabled": true — see docs for
  details.

{border}
"""
        # Log it so it always appears in journalctl / log file
        for line in msg.strip().splitlines():
            logger.error(line)

        # Interactive prompt — if stdin is available, let the user choose.
        # In daemon/systemd context this will fall through to disabling pcap.
        try:
            if sys.stdin is not None and sys.stdin.isatty():
                print(msg, file=sys.stderr)
                print(
                    "  WARNING: Disabling packet capture removes a core feature\n"
                    "  of the Flowtriq agent.  Attack analysis, traffic fingerprinting,\n"
                    "  and PCAP evidence collection will all be unavailable.\n"
                    "  This will severely limit our ability to analyze and mitigate attacks.\n",
                    file=sys.stderr,
                )
                answer = input("  Disable packet capture and continue without it? [y/N] ").strip().lower()
                if answer == "y":
                    logger.warning("Packet capture disabled by user — running without PCAP")
                    print("\n  Packet capture disabled.  The agent will continue running but\n"
                          "  attack analysis capabilities are severely reduced.\n",
                          file=sys.stderr)
                    self.enabled = False
                    return
                else:
                    logger.error("User chose not to disable pcap — exiting so tcpdump can be fixed")
                    print("\n  Please install tcpdump and restart the agent.\n"
                          "  On Debian/Ubuntu:  apt-get install -y tcpdump\n"
                          "  On RHEL/CentOS:    yum install -y tcpdump\n"
                          "  On Alpine:         apk add tcpdump\n",
                          file=sys.stderr)
                    os._exit(1)
            else:
                # Non-interactive (systemd, nohup, etc.) — cannot prompt, disable pcap
                logger.error(
                    "Non-interactive session — disabling packet capture.  "
                    "Install tcpdump and restart the agent to restore full functionality."
                )
                self.enabled = False
        except (EOFError, OSError):
            logger.error(
                "Cannot prompt for input — disabling packet capture.  "
                "Install tcpdump and restart the agent to restore full functionality."
            )
            self.enabled = False

    def _background_ring_tcpdump(self, shutdown: threading.Event) -> None:
        """Use tcpdump for continuous capture. Native speed, near-zero CPU.
        Rotates files every 30s, keeps last 3 as a ring buffer.
        Full-fidelity capture of every packet at any PPS."""
        import subprocess
        ring_dir = os.path.join(self.pcap_dir, "_ring")
        os.makedirs(ring_dir, mode=0o777, exist_ok=True)
        os.chmod(ring_dir, 0o777)  # writable by any user (tcpdump may drop privs)
        self._ring_dir = ring_dir

        ring_file = os.path.join(ring_dir, "ring_%Y%m%d_%H%M%S.pcap")
        tcpdump_cmd = [
            "tcpdump", "-i", self.iface, "-w", ring_file,
            "-G", "30", "-W", "3", "-s", "0", "-q",
        ]

        logger.info("PCAP ring buffer active on %s (tcpdump mode)", self.iface)
        try:
            import subprocess

            # Auto-install tcpdump if not present
            if subprocess.run(["which", "tcpdump"], capture_output=True).returncode != 0:
                logger.info("tcpdump not found, attempting to install...")
                installed = False
                for pm_cmd in [
                    ["apt-get", "install", "-y", "tcpdump"],
                    ["yum", "install", "-y", "tcpdump"],
                    ["dnf", "install", "-y", "tcpdump"],
                    ["apk", "add", "tcpdump"],
                    ["pacman", "-S", "--noconfirm", "tcpdump"],
                ]:
                    try:
                        r = subprocess.run(pm_cmd, capture_output=True, timeout=60)
                        if r.returncode == 0:
                            logger.info("tcpdump installed via %s", pm_cmd[0])
                            installed = True
                            break
                    except (FileNotFoundError, subprocess.TimeoutExpired):
                        continue
                if not installed:
                    self._tcpdump_unavailable(
                        "tcpdump is not installed and automatic installation failed.  "
                        "Install it manually (e.g. apt-get install tcpdump) and restart the agent."
                    )
                    return

            # Also ensure mergecap is available (for merging ring files on capture stop)
            if subprocess.run(["which", "mergecap"], capture_output=True).returncode != 0:
                for pm_cmd in [
                    ["apt-get", "install", "-y", "wireshark-common"],
                    ["yum", "install", "-y", "wireshark-cli"],
                    ["dnf", "install", "-y", "wireshark-cli"],
                ]:
                    try:
                        r = subprocess.run(pm_cmd, capture_output=True, timeout=120)
                        if r.returncode == 0:
                            logger.info("mergecap installed via %s", pm_cmd[0])
                            break
                    except (FileNotFoundError, subprocess.TimeoutExpired):
                        continue

            self._tcpdump_proc = subprocess.Popen(
                tcpdump_cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
            )
            _restarts = 0
            while not shutdown.is_set():
                shutdown.wait(1)
                if self._tcpdump_proc.poll() is not None:
                    stderr = self._tcpdump_proc.stderr.read().decode(errors="replace")
                    logger.warning("tcpdump exited (code %d): %s",
                                   self._tcpdump_proc.returncode, stderr[:200])
                    _restarts += 1
                    if _restarts > 5:
                        self._tcpdump_unavailable(
                            f"tcpdump crashed {_restarts} times consecutively.  "
                            "It may be incompatible with this system or missing permissions."
                        )
                        return
                    shutdown.wait(5)
                    if not shutdown.is_set():
                        logger.info("Restarting tcpdump (attempt %d)...", _restarts)
                        self._tcpdump_proc = subprocess.Popen(
                            tcpdump_cmd, stdout=subprocess.DEVNULL,
                            stderr=subprocess.PIPE)

            self._tcpdump_proc.terminate()
            try:
                self._tcpdump_proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self._tcpdump_proc.kill()

        except FileNotFoundError:
            self._tcpdump_unavailable(
                "tcpdump binary not found on this system."
            )
        except Exception as exc:
            self._tcpdump_unavailable(f"Unexpected error starting tcpdump: {exc}")

    def _background_ring_scapy(self, shutdown: threading.Event) -> None:
        """Scapy sniff mode — per-packet Python analysis. Only runs when
        pcap_mode is explicitly set to 'scapy' in the config."""
        logger.warning("PCAP ring buffer active on %s (scapy mode — high CPU on busy servers)", self.iface)
        try:
            sniff(iface=self.iface, prn=self._ring_cb, store=False,
                  stop_filter=lambda _: shutdown.is_set())
        except Exception as exc:
            logger.warning("Ring buffer sniff error: %s", exc)

    def _ring_cb(self, pkt) -> None:
        self.ring_buffer.append(pkt)
        if self.capturing and len(self.capture_packets) < self.max_capture:
            self.capture_packets.append(pkt)
            self._pkt_counter += 1
            if self._pkt_counter % self._analyse_every == 0:
                self.analyser.process_packet(pkt, self.ioc_matcher)

    def start_capture(self, incident_uuid: str = "",
                       api_client=None) -> None:
        if self.pcap_mode == "tcpdump" and self._ring_dir:
            # In tcpdump mode, snapshot the current ring files as the pre-attack sample
            import glob
            import shutil
            self._tcpdump_capture_dir = os.path.join(self.pcap_dir, f"_capture_{incident_uuid[:8]}")
            os.makedirs(self._tcpdump_capture_dir, exist_ok=True)
            for rf in sorted(glob.glob(os.path.join(self._ring_dir, "ring*"))):
                try:
                    shutil.copy2(rf, self._tcpdump_capture_dir)
                except Exception:
                    pass
            # Start a dedicated tcpdump for this incident
            import subprocess
            self._capture_file = os.path.join(self._tcpdump_capture_dir, "attack.pcap")
            try:
                self._capture_proc = subprocess.Popen(
                    ["tcpdump", "-i", self.iface, "-w", self._capture_file,
                     "-s", "0", "-Z", "root", "-c", str(self.max_capture), "-q"],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except FileNotFoundError:
                self._capture_proc = None
        else:
            self._tcpdump_capture_dir = None
            self._capture_proc = None

        self.capture_packets = list(self.ring_buffer)
        self.capturing = True
        self._incident_uuid = incident_uuid
        self._api_client = api_client
        self._chunk_index = 0
        self._chunk_size = 500  # packets per chunk file (small for fast first upload)
        self._uploaded_chunks: list = []
        logger.info("PCAP capture started (%d pre-attack packets)",
                    len(self.capture_packets))
        # Start background chunk uploader thread
        if api_client and incident_uuid:
            self._chunk_stop = threading.Event()
            # Immediately flush pre-buffer packets so backend gets early sample
            if len(self.capture_packets) >= 50:
                threading.Thread(
                    target=self._flush_chunk, daemon=True,
                    name="pcap-early-flush").start()
            self._chunk_thread = threading.Thread(
                target=self._chunk_upload_loop, daemon=True,
                name="pcap-chunk-upload")
            self._chunk_thread.start()

    def _chunk_upload_loop(self) -> None:
        """Periodically write and upload PCAP chunks during an attack."""
        while not self._chunk_stop.is_set():
            self._chunk_stop.wait(10)  # check every 10 seconds
            if self._chunk_stop.is_set():
                break
            pkt_count = len(self.capture_packets)
            threshold = (self._chunk_index + 1) * self._chunk_size
            if pkt_count >= threshold:
                self._flush_chunk()

    def _flush_chunk(self) -> Optional[str]:
        """Write current packets to a chunk file and upload it."""
        start_idx = self._chunk_index * self._chunk_size
        end_idx = start_idx + self._chunk_size
        chunk_pkts = self.capture_packets[start_idx:end_idx]
        if not chunk_pkts:
            return None
        Path(self.pcap_dir).mkdir(parents=True, exist_ok=True)
        ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        filepath = os.path.join(
            self.pcap_dir,
            f"{self._incident_uuid}_{ts}_chunk{self._chunk_index}.pcap")
        try:
            writer = PcapWriter(filepath, append=False, sync=True)
            for pkt in chunk_pkts:
                writer.write(pkt)
            writer.close()
            logger.info("PCAP chunk %d written: %s (%d packets)",
                        self._chunk_index, filepath, len(chunk_pkts))
            self._chunk_index += 1
            # Upload in background
            if self._api_client:
                threading.Thread(
                    target=self._api_client.upload_pcap,
                    args=(self._incident_uuid, filepath),
                    daemon=True,
                ).start()
            self._uploaded_chunks.append(filepath)
            return filepath
        except Exception as exc:
            logger.error("PCAP chunk write failed: %s", exc)
            return None

    def stop_capture(self, incident_uuid: str) -> Optional[str]:
        self.capturing = False

        # tcpdump mode: stop capture process and merge files
        if self.pcap_mode == "tcpdump" and hasattr(self, '_capture_proc') and self._capture_proc:
            self._capture_proc.terminate()
            try:
                self._capture_proc.wait(timeout=5)
            except Exception:
                self._capture_proc.kill()

            # Merge ring snapshots + attack capture into one file
            import glob
            Path(self.pcap_dir).mkdir(parents=True, exist_ok=True)
            ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
            filepath = os.path.join(self.pcap_dir, f"{incident_uuid}_{ts}.pcap")

            ring_files = sorted(glob.glob(os.path.join(self._tcpdump_capture_dir, "ring*")))
            attack_file = os.path.join(self._tcpdump_capture_dir, "attack.pcap")
            all_files = ring_files + ([attack_file] if os.path.exists(attack_file) else [])

            if all_files:
                try:
                    # Use mergecap if available, else simple concat
                    import subprocess
                    merge_result = subprocess.run(
                        ["mergecap", "-w", filepath] + all_files,
                        capture_output=True, timeout=30)
                    if merge_result.returncode != 0:
                        # Fallback: concatenate (works for pcap, not pcapng)
                        with open(filepath, "wb") as out:
                            for f in all_files:
                                with open(f, "rb") as inp:
                                    out.write(inp.read())
                    logger.info("PCAP merged: %s (%d source files)", filepath, len(all_files))
                except FileNotFoundError:
                    # No mergecap, just use the attack file
                    if os.path.exists(attack_file):
                        import shutil
                        shutil.move(attack_file, filepath)
                except Exception as exc:
                    logger.error("PCAP merge failed: %s", exc)

            # Cleanup temp dir
            import shutil
            shutil.rmtree(self._tcpdump_capture_dir, ignore_errors=True)

            if os.path.exists(filepath) and os.path.getsize(filepath) > 0:
                return filepath
            return None

        # Stop chunk upload thread
        if hasattr(self, '_chunk_stop'):
            self._chunk_stop.set()
        if not self.capture_packets:
            return None
        Path(self.pcap_dir).mkdir(parents=True, exist_ok=True)
        ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        filepath = os.path.join(self.pcap_dir, f"{incident_uuid}_{ts}.pcap")
        try:
            writer = PcapWriter(filepath, append=False, sync=True)
            for pkt in self.capture_packets:
                writer.write(pkt)
            writer.close()
            logger.info("PCAP written: %s (%d packets)",
                        filepath, len(self.capture_packets))
            self.capture_packets = []
            return filepath
        except Exception as exc:
            logger.error("PCAP write failed: %s", exc)
            return None


# ---------------------------------------------------------------------------
# L7 (HTTP) Detection Module
# ---------------------------------------------------------------------------

WEB_SERVER_LOG_PATHS = {
    "nginx": [
        "/var/log/nginx/access.log",
        "/var/log/nginx/access_log",
        "/usr/local/nginx/logs/access.log",
    ],
    "apache": [
        "/var/log/apache2/access.log",
        "/var/log/apache2/other_vhosts_access.log",
        "/var/log/httpd/access_log",
        "/var/log/httpd/access.log",
        "/var/log/apache/access.log",
    ],
    "caddy": ["/var/log/caddy/access.log"],
    "litespeed": [
        "/var/log/litespeed/access.log",
        "/usr/local/lsws/logs/access.log",
    ],
    "haproxy": ["/var/log/haproxy.log"],
}

LOG_PATTERN_COMBINED = re.compile(
    r'^(\S+)\s+\S+\s+\S+\s+\[([^\]]+)\]\s+"(\S+)\s+(\S+)\s+\S+"\s+(\d{3})\s+(\S+)'
    r'(?:\s+"[^"]*"\s+"([^"]*)")?'
)

# Additional log format patterns for more web servers
LOG_PATTERN_TOMCAT = re.compile(
    r'^(\S+)\s+\S+\s+\S+\s+\[([^\]]+)\]\s+"(\S+)\s+(\S+)\s+\S+"\s+(\d{3})\s+(\S+)'
    r'(?:\s+(\d+))?'  # optional response time in ms
)
LOG_PATTERN_GUNICORN = re.compile(
    r'^(\S+)\s+-\s+-\s+\[([^\]]+)\]\s+"(\S+)\s+(\S+)\s+\S+"\s+(\d{3})\s+(\S+)'
    r'(?:\s+"[^"]*"\s+"([^"]*)")?'
)

# ── L7 threat pattern signatures ──
L7_THREAT_PATTERNS = {
    "sqli": re.compile(
        r"(?:union\s+select|'?\s*or\s+['\d]|select\s+.*from\s|insert\s+into|"
        r"drop\s+table|update\s+\w+\s+set|;\s*(?:drop|delete|alter)\s)", re.I),
    "xss": re.compile(
        r"(?:<script|javascript:|on(?:error|load|click|mouseover)\s*=|"
        r"eval\s*\(|document\.(?:cookie|write)|alert\s*\()", re.I),
    "path_traversal": re.compile(r"(?:\.\./|\.\.\\|%2e%2e[%/])", re.I),
    "rfi_lfi": re.compile(
        r"(?:(?:file|php|zip|data|expect|glob|phar)://|/etc/(?:passwd|shadow)|"
        r"/proc/self/)", re.I),
    "wordpress": re.compile(
        r"(?:/wp-(?:admin|login|content|includes|config|cron)|/xmlrpc\.php|"
        r"/wp-json/wp/)", re.I),
    "scanner_probe": re.compile(
        r"(?:/\.env|/\.git/|/config\.php|/phpinfo|/server-status|/actuator|"
        r"/containers/json|/debug/vars|/solr/admin|/_cat/indices|/elmah\.axd|"
        r"/telescope/requests|/\.well-known/security\.txt)", re.I),
    "shell_shock": re.compile(r"\(\)\s*\{", re.I),
    "log4j": re.compile(r"\$\{(?:jndi|lower|upper|env):", re.I),
    "api_abuse": re.compile(
        r"(?:/graphql|/api/v\d+/(?:admin|users|tokens|keys)|/oauth/token|"
        r"/\.well-known/openid)", re.I),
    "cve_exploit": re.compile(
        r"(?:/cgi-bin/|/shell|/cmd\.php|/c99\.php|/r57\.php|"
        r"/eval-stdin\.php|/vendor/phpunit)", re.I),
}

# ── Known bot User-Agent patterns ──
L7_BOT_UA_PATTERNS = re.compile(
    r"(?:python-requests|python-urllib|Go-http-client|java/|curl/|"
    r"wget/|libwww-perl|PHP/|Scrapy|nikto|sqlmap|nmap|masscan|"
    r"zgrab|httpx|nuclei|dirsearch|gobuster|ffuf|wfuzz|"
    r"bot|spider|crawl|scan|attack|exploit|hack)", re.I)

# ── L7 subtype classification helpers ──
def _classify_l7_subtype(stats: dict) -> str:
    """Classify L7 attack subtype from traffic characteristics."""
    rps = stats.get("rps", 0)
    unique_ips = stats.get("unique_ips", 0)
    error_rate = stats.get("error_rate", 0)
    top_paths = stats.get("top_paths", {})
    top_ips = stats.get("top_ips", {})
    total = stats.get("total_requests", 0)

    if not total:
        return "l7_flood"

    # Single source abuse
    if unique_ips <= 2 and total > 50:
        return "single_source_abuse"

    # Check path concentration for scraping / endpoint targeting
    if top_paths:
        top_path, top_count = max(top_paths.items(), key=lambda x: x[1])
        path_pct = top_count / max(total, 1)

        # Credential stuffing: high error rate on auth endpoints
        auth_paths = {"/login", "/signin", "/auth", "/oauth", "/api/login",
                      "/wp-login.php", "/admin/login", "/user/login"}
        if path_pct > 0.5 and error_rate > 40:
            for ap in auth_paths:
                if ap in top_path.lower():
                    return "credential_stuffing"

        # Scraping: one path hammered, low error rate
        if path_pct > 0.7 and error_rate < 20:
            return "scraping"

        # API abuse: targeting API endpoints
        if "/api/" in top_path.lower() or "/graphql" in top_path.lower():
            return "api_abuse"

    # Slowloris: low RPS but from many IPs (agent won't catch true slowloris
    # since it's connection-based, but low-and-slow patterns show up)
    if rps < 50 and unique_ips > 20 and error_rate > 60:
        return "slow_rate"

    # High volume from many sources = volumetric HTTP flood
    if rps > 500 and unique_ips > 10:
        return "volumetric_flood"

    return "l7_flood"


def detect_web_server() -> dict:
    """Auto-detect running web server and locate access log files."""
    import subprocess

    result = {"web_server": None, "server_version": None, "detected_paths": []}
    checks = [
        ("nginx",     ["nginx", "-v"]),
        ("apache",    ["apache2", "-v"]),
        ("apache",    ["httpd", "-v"]),
        ("caddy",     ["caddy", "version"]),
        ("litespeed", ["litespeed", "-v"]),
        ("haproxy",   ["haproxy", "-v"]),
    ]

    for name, cmd in checks:
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
            if r.returncode == 0 or (r.stderr and name in r.stderr.lower()):
                version_text = (r.stderr or r.stdout).strip().split("\n")[0]
                result["web_server"] = name
                result["server_version"] = version_text[:100]
                break
        except (FileNotFoundError, subprocess.TimeoutExpired):
            continue

    if not result["web_server"]:
        try:
            r = subprocess.run(["ps", "aux"], capture_output=True, text=True, timeout=5)
            ps_out = r.stdout.lower()
            for name in ["nginx", "apache2", "httpd", "caddy", "litespeed", "haproxy"]:
                if name in ps_out:
                    result["web_server"] = "apache" if name in ("apache2", "httpd") else name
                    break
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

    if not result["web_server"]:
        return result

    candidates = WEB_SERVER_LOG_PATHS.get(result["web_server"], [])
    all_paths = set()
    for paths in WEB_SERVER_LOG_PATHS.values():
        all_paths.update(paths)
    ordered = list(candidates) + [p for p in all_paths if p not in candidates]

    for path in ordered:
        if os.path.isfile(path) and os.access(path, os.R_OK):
            result["detected_paths"].append(path)

    return result


class L7Monitor:
    """Monitors HTTP access logs for L7 attack patterns."""

    def __init__(self, log_path: str, api: APIClient, l7_config: dict = None):
        self.log_path = log_path
        self.api = api
        self.file = None
        self.inode = 0
        self._window = 10
        self._requests: list = []
        self._baseline_rps: float = 0.0
        self._baseline_samples: int = 0
        self._attack_active = False
        self._attack_start = 0.0
        self._attack_uuid = ""
        self._attack_peak_rps = 0.0
        # Configurable thresholds (from server config)
        cfg = l7_config or {}
        self._rps_threshold_override = cfg.get("rps_threshold")       # None = auto
        self._error_rate_threshold = cfg.get("error_rate_threshold", 50)
        sensitivity = cfg.get("sensitivity", "medium")
        self._sensitivity_multiplier = {"low": 8, "medium": 5, "high": 3}.get(sensitivity, 5)
        self._min_rps = {"low": 250, "medium": 150, "high": 75}.get(sensitivity, 150)
        # Accumulated attack-wide stats
        self._attack_ua_counts: dict = {}
        self._attack_threat_hits: dict = {}
        self._attack_status_totals: dict = {}
        self._attack_path_totals: dict = {}
        self._attack_ip_totals: dict = {}
        self._attack_total_requests: int = 0

    def open(self) -> bool:
        try:
            self.file = open(self.log_path, "r")
            self.file.seek(0, 2)
            self.inode = os.stat(self.log_path).st_ino
            logger.info("L7: tailing %s", self.log_path)
            return True
        except (OSError, IOError) as exc:
            logger.error("L7: cannot open %s: %s", self.log_path, exc)
            return False

    def tick(self) -> Optional[dict]:
        if not self.file:
            return None

        try:
            current_inode = os.stat(self.log_path).st_ino
            if current_inode != self.inode:
                logger.info("L7: log rotated, reopening %s", self.log_path)
                self.file.close()
                self.open()
        except OSError:
            pass

        new_lines = []
        try:
            while True:
                line = self.file.readline()
                if not line:
                    break
                new_lines.append(line.rstrip("\n"))
        except (OSError, IOError):
            pass

        now = time.time()
        for line in new_lines:
            parsed = self._parse_line(line)
            if parsed:
                self._requests.append((now, *parsed))

        cutoff = now - self._window
        self._requests = [r for r in self._requests if r[0] >= cutoff]

        if not self._requests:
            return None
        return self._compute_stats(now)

    def _parse_line(self, line: str) -> Optional[tuple]:
        # JSON format (nginx json_combined, Caddy, Node.js Morgan/Pino, Go, Python)
        if line.startswith("{"):
            try:
                d = json.loads(line)
                ip = (d.get("remote_addr") or d.get("client_ip") or d.get("host")
                      or d.get("remoteAddress") or d.get("remote_ip")  # Node.js / Go
                      or d.get("clientip") or "")                      # Gunicorn
                method = (d.get("method") or d.get("request_method")
                          or d.get("httpMethod") or "GET")
                path = (d.get("uri") or d.get("path") or d.get("request_uri")
                        or d.get("url") or d.get("pathname") or "/")
                status = int(d.get("status") or d.get("status_code")
                             or d.get("statusCode") or d.get("response_code") or 0)
                size = int(d.get("body_bytes_sent") or d.get("bytes")
                           or d.get("content_length") or d.get("responseSize") or 0)
                ua = (d.get("http_user_agent") or d.get("user_agent")
                      or d.get("userAgent") or d.get("user-agent") or "")
                resp_time = d.get("request_time") or d.get("response_time") or d.get("duration") or d.get("latency")
                if resp_time is not None:
                    try:
                        resp_time = float(resp_time)
                        # Normalize: if > 1000, assume already ms; otherwise assume seconds
                        if resp_time < 100:
                            resp_time = resp_time * 1000
                    except (ValueError, TypeError):
                        resp_time = None
                if ip and status:
                    return (ip, method, path, status, size, ua, resp_time)
            except (json.JSONDecodeError, ValueError, TypeError):
                pass
            return None

        # Standard combined/CLF format (nginx, Apache, Tomcat, Gunicorn, LiteSpeed, HAProxy)
        m = LOG_PATTERN_COMBINED.match(line)
        if m:
            ip = m.group(1)
            method, path = m.group(3), m.group(4)
            status = int(m.group(5))
            size_str = m.group(6)
            ua = m.group(7) or ""
            size = int(size_str) if size_str != "-" else 0
            path = path.split("?")[0] if "?" in path else path
            return (ip, method, path, status, size, ua, None)
        return None

    def _compute_stats(self, now: float) -> dict:
        n = len(self._requests)
        elapsed = max(1.0, now - self._requests[0][0]) if n > 1 else self._window
        rps = n / elapsed

        ip_counts: dict = {}
        path_counts: dict = {}
        status_counts: dict = {}
        ua_counts: dict = {}
        threat_hits: dict = {}
        resp_times: list = []
        bot_request_count = 0

        for req in self._requests:
            ts, ip, method, path, status, size, ua = req[0], req[1], req[2], req[3], req[4], req[5], req[6]
            resp_time = req[7] if len(req) > 7 else None

            ip_counts[ip] = ip_counts.get(ip, 0) + 1
            path_counts[path] = path_counts.get(path, 0) + 1
            code_group = f"{status // 100}xx"
            status_counts[code_group] = status_counts.get(code_group, 0) + 1

            # User-Agent tracking
            if ua:
                ua_short = ua[:120]
                ua_counts[ua_short] = ua_counts.get(ua_short, 0) + 1
                if L7_BOT_UA_PATTERNS.search(ua):
                    bot_request_count += 1

            # Threat pattern detection on path + query.
            # Fast-path: skip regex if path is short and has no suspicious chars.
            # This avoids 12 regex matches on clean paths like "/", "/index.html".
            full_path = path
            _lp = full_path.lower()
            if len(full_path) > 6 or "'" in _lp or "." in _lp or "$" in _lp or "<" in _lp or "(" in _lp or "/" in _lp[1:]:
                for pattern_name, pattern_re in L7_THREAT_PATTERNS.items():
                    if pattern_re.search(full_path):
                        threat_hits[pattern_name] = threat_hits.get(pattern_name, 0) + 1

            if resp_time is not None:
                resp_times.append(resp_time)

        error_count = status_counts.get("4xx", 0) + status_counts.get("5xx", 0)
        error_rate = (error_count / max(n, 1)) * 100

        top_ips = sorted(ip_counts.items(), key=lambda x: x[1], reverse=True)[:50]
        top_paths = sorted(path_counts.items(), key=lambda x: x[1], reverse=True)[:20]
        top_uas = sorted(ua_counts.items(), key=lambda x: x[1], reverse=True)[:20]
        avg_resp_ms = round(sum(resp_times) / len(resp_times), 1) if resp_times else None

        return {
            "rps": round(rps, 1),
            "error_rate": round(error_rate, 1),
            "unique_ips": len(ip_counts),
            "total_requests": n,
            "top_paths": dict(top_paths),
            "top_ips": dict(top_ips),
            "status_codes": status_counts,
            "window_seconds": round(elapsed, 1),
            "top_user_agents": dict(top_uas),
            "threat_patterns": threat_hits,
            "bot_request_pct": round((bot_request_count / max(n, 1)) * 100, 1),
            "avg_response_ms": avg_resp_ms,
            "status_5xx": status_counts.get("5xx", 0),
            "status_4xx": status_counts.get("4xx", 0),
        }

    def check_attack(self, stats: dict) -> Optional[dict]:
        rps = stats["rps"]
        total = stats["total_requests"]
        unique_ips = stats.get("unique_ips", 0)
        error_rate = stats.get("error_rate", 0)

        # Need enough requests in the window to make a judgement
        if total < 15:
            if self._attack_active:
                self._accumulate_attack_stats(stats)
                return self._check_attack_end(stats)
            return None

        # Update baseline only when NOT under attack and traffic looks clean.
        # Skip baseline learning if error rate is very high (likely attack traffic
        # arriving during warmup) or RPS is already extreme.
        if not self._attack_active:
            is_clean = (error_rate < 60
                        and (self._baseline_samples < 3 or rps < self._baseline_rps * 10))
            if is_clean:
                if self._baseline_samples < 300:
                    alpha = 1 / (self._baseline_samples + 1)
                else:
                    alpha = 0.01
                self._baseline_rps = (1 - alpha) * self._baseline_rps + alpha * rps
                self._baseline_samples += 1

        signals = 0
        reasons = []
        warmup = self._baseline_samples < 10
        baseline_ready = self._baseline_samples >= 30

        # RPS threshold: use override if set, otherwise auto-calculate.
        # During warmup (< 10 samples), use a high floor to avoid false positives.
        # Once baseline is established (>= 30 samples), go purely data-driven.
        if self._rps_threshold_override:
            rps_threshold = self._rps_threshold_override
        elif warmup:
            # Not enough data yet -- use high absolute floor
            rps_threshold = 500
        elif baseline_ready:
            # Baseline established -- purely data-driven, no minimum floor
            mult = self._sensitivity_multiplier
            rps_threshold = self._baseline_rps * mult if self._baseline_rps > 1 else 100
        else:
            # Partial baseline -- use data but keep a modest floor
            mult = self._sensitivity_multiplier
            rps_threshold = max(self._baseline_rps * mult, self._min_rps) if self._baseline_rps > 5 else self._min_rps
        if rps > rps_threshold:
            signals += 2
            reasons.append(f"RPS spike: {rps:.0f} (threshold {rps_threshold:.0f})")

        if stats["top_ips"]:
            top_ip_name, top_ip_count = max(stats["top_ips"].items(), key=lambda x: x[1])
            ip_pct = top_ip_count / max(total, 1)
            if ip_pct > 0.3 and top_ip_count > 20:
                signals += 1
                reasons.append(f"IP concentration: {top_ip_name} = {ip_pct:.0%}")

        if stats["top_paths"]:
            top_path_name, top_path_count = max(stats["top_paths"].items(), key=lambda x: x[1])
            path_pct = top_path_count / max(total, 1)
            if path_pct > 0.6 and top_path_count > 30:
                signals += 1
                reasons.append(f"Path focus: {top_path_name} = {path_pct:.0%}")

        # Error rate anomaly (configurable threshold)
        err_threshold = self._error_rate_threshold
        if stats["error_rate"] > err_threshold and total > 20:
            signals += 1
            reasons.append(f"Error rate: {stats['error_rate']:.0f}% (threshold {err_threshold:.0f}%)")

        # 5xx spike: backend under stress (separate signal from general error rate)
        if stats.get("status_5xx", 0) > max(total * 0.3, 15):
            signals += 1
            reasons.append(f"5xx spike: {stats['status_5xx']} server errors")

        # High bot UA percentage
        bot_pct = stats.get("bot_request_pct", 0)
        if bot_pct > 70 and total > 30:
            signals += 1
            reasons.append(f"Bot traffic: {bot_pct:.0f}% from known bot UAs")

        # Threat pattern hits (SQLi, XSS, path traversal, etc.)
        threat_total = sum(stats.get("threat_patterns", {}).values())
        if threat_total > max(total * 0.2, 10):
            signals += 1
            top_threat = max(stats["threat_patterns"].items(), key=lambda x: x[1])[0] if stats.get("threat_patterns") else "unknown"
            reasons.append(f"Threat patterns: {threat_total} hits (top: {top_threat})")

        # Need at least 2 signals AND multiple source IPs (single IP = scanner, not flood)
        if signals >= 2 and unique_ips >= 3 and not self._attack_active:
            self._attack_active = True
            self._attack_start = time.time()
            self._attack_peak_rps = rps
            self._below_count = 0
            self._reset_attack_accumulators()
            self._accumulate_attack_stats(stats)
            subtype = _classify_l7_subtype(stats)
            return {
                "type": "l7_flood",
                "attack_family": "http_flood",
                "attack_subtype": subtype,
                "rps": rps,
                "baseline_rps": round(self._baseline_rps, 1),
                "reasons": reasons,
                "stats": stats,
            }
        elif self._attack_active:
            if rps > self._attack_peak_rps:
                self._attack_peak_rps = rps
            self._accumulate_attack_stats(stats)
            return self._check_attack_end(stats)

        return None

    def _reset_attack_accumulators(self):
        """Reset accumulated attack-wide stats for a new incident."""
        self._attack_ua_counts = {}
        self._attack_threat_hits = {}
        self._attack_status_totals = {}
        self._attack_path_totals = {}
        self._attack_ip_totals = {}
        self._attack_total_requests = 0

    def _accumulate_attack_stats(self, stats: dict):
        """Merge per-window stats into attack-wide accumulators."""
        self._attack_total_requests += stats.get("total_requests", 0)
        for ua, cnt in stats.get("top_user_agents", {}).items():
            self._attack_ua_counts[ua] = self._attack_ua_counts.get(ua, 0) + cnt
        for pat, cnt in stats.get("threat_patterns", {}).items():
            self._attack_threat_hits[pat] = self._attack_threat_hits.get(pat, 0) + cnt
        for code, cnt in stats.get("status_codes", {}).items():
            self._attack_status_totals[code] = self._attack_status_totals.get(code, 0) + cnt
        for path, cnt in stats.get("top_paths", {}).items():
            self._attack_path_totals[path] = self._attack_path_totals.get(path, 0) + cnt
        for ip, cnt in stats.get("top_ips", {}).items():
            self._attack_ip_totals[ip] = self._attack_ip_totals.get(ip, 0) + cnt

    def get_attack_summary(self) -> dict:
        """Return accumulated attack-wide data for incident enrichment."""
        top_uas = sorted(self._attack_ua_counts.items(), key=lambda x: x[1], reverse=True)[:20]
        top_paths = sorted(self._attack_path_totals.items(), key=lambda x: x[1], reverse=True)[:20]
        top_ips = sorted(self._attack_ip_totals.items(), key=lambda x: x[1], reverse=True)[:50]
        return {
            "top_user_agents": dict(top_uas),
            "threat_patterns": self._attack_threat_hits,
            "status_codes": self._attack_status_totals,
            "top_paths": dict(top_paths),
            "top_ips": dict(top_ips),
            "total_requests": self._attack_total_requests,
        }

    def _check_attack_end(self, stats: dict) -> Optional[dict]:
        rps = stats["rps"]
        total = stats.get("total_requests", 0)
        error_rate = stats.get("error_rate", 0)
        elapsed = time.time() - self._attack_start

        # Minimum 15s before allowing resolve to prevent rapid open/close flapping
        if elapsed < 15:
            return {"type": "l7_flood_update", "rps": rps, "peak_rps": self._attack_peak_rps, "stats": stats}

        # Resolve when traffic has clearly calmed down. Check multiple conditions:
        # 1. RPS dropped to low absolute level (under 50 RPS)
        # 2. OR error rate normalized AND RPS dropped significantly from peak
        # 3. OR very few requests in the window (traffic stopped)
        should_resolve = False
        if total < 10:
            should_resolve = True
        elif rps < 50:
            should_resolve = True
        elif rps < self._attack_peak_rps * 0.1 and error_rate < 30:
            should_resolve = True
        elif self._baseline_rps > 5 and rps < self._baseline_rps * 2 and error_rate < 30:
            should_resolve = True

        if should_resolve:
            self._below_count = getattr(self, '_below_count', 0) + 1
            if self._below_count >= 3:
                self._attack_active = False
                self._below_count = 0
                # Reset baseline so it relearns from clean traffic
                self._baseline_rps = max(rps, 1.0)
                self._baseline_samples = 1
                summary = self.get_attack_summary()
                subtype = _classify_l7_subtype(stats)
                return {
                    "type": "l7_flood_end",
                    "duration_seconds": round(elapsed, 1),
                    "peak_rps": round(self._attack_peak_rps, 1),
                    "attack_subtype": subtype,
                    "stats": stats,
                    "attack_summary": summary,
                }
            return {"type": "l7_flood_update", "rps": rps, "peak_rps": self._attack_peak_rps, "stats": stats}

        self._below_count = 0
        return {"type": "l7_flood_update", "rps": rps, "peak_rps": self._attack_peak_rps, "stats": stats}


# ---------------------------------------------------------------------------
# Attack Classifier
# ---------------------------------------------------------------------------

def classify_attack(tcp_pct: float, udp_pct: float, icmp_pct: float,
                    syn_ratio: float = 0.0, dns_detected: bool = False,
                    top_ports: list = None, tcp_flags: dict = None) -> str:
    if dns_detected:
        return "dns_flood"
    if udp_pct > 45:
        return "udp_flood"
    if tcp_pct > 45 and syn_ratio > 0.5:
        return "syn_flood"
    if icmp_pct > 30:
        return "icmp_flood"
    elevated = sum(1 for v in (tcp_pct, udp_pct, icmp_pct) if v > 15)
    if elevated >= 2:
        return "multi_vector"
    # Last resort: pick dominant protocol.
    if udp_pct >= tcp_pct and udp_pct >= icmp_pct and udp_pct > 5:
        return "udp_flood"
    if tcp_pct >= udp_pct and tcp_pct >= icmp_pct and tcp_pct > 5:
        if syn_ratio >= 0.3:
            return "syn_flood"
        return "unknown"
    if icmp_pct > 5:
        return "icmp_flood"
    return "unknown"


def classify_subtype(family: str, top_ports: list = None,
                     tcp_flags: dict = None, avg_pkt_len: int = 0) -> str:
    """Derive attack subtype from port/flag/size evidence."""
    if not family or family == "unknown":
        return ""

    ports = top_ports or []
    top_port = 0
    if ports:
        entry = ports[0]
        top_port = entry.get("port", 0) if isinstance(entry, dict) else int(entry)

    # ── UDP subtypes ──
    if family == "udp_flood":
        if top_port == 53:
            return "dns_amplification"
        if top_port == 123:
            return "ntp_amplification"
        if top_port == 1900:
            return "ssdp_amplification"
        if top_port == 11211:
            return "memcached_amplification"
        if top_port == 389:
            return "cldap_amplification"
        if top_port == 19:
            return "chargen_amplification"
        if top_port == 161:
            return "snmp_amplification"
        if avg_pkt_len > 0 and avg_pkt_len < 100:
            return "small_packet_flood"
        if avg_pkt_len > 1200:
            return "amplification_generic"
        return "volumetric"

    # ── TCP subtypes (beyond SYN flood) ──
    if family == "syn_flood":
        return "syn_flood"

    # ── DNS subtypes ──
    if family == "dns_flood":
        if top_port == 53 and avg_pkt_len > 512:
            return "dns_amplification"
        return "dns_query_flood"

    # ── ICMP subtypes ──
    if family == "icmp_flood":
        if avg_pkt_len > 1000:
            return "ping_of_death"
        return "ping_flood"

    return ""


def classify_tcp_subtype(tcp_flags: dict) -> str:
    """Classify TCP attack subtype from flag distribution.
    Only called when tcp_pct is dominant but SYN ratio is below flood threshold."""
    if not tcp_flags:
        return ""
    total = sum(tcp_flags.values())
    if total == 0:
        return ""
    syn_r = tcp_flags.get("SYN", 0) / total
    ack_r = tcp_flags.get("ACK", 0) / total
    rst_r = tcp_flags.get("RST", 0) / total
    fin_r = tcp_flags.get("FIN", 0) / total
    psh_r = tcp_flags.get("PSH", 0) / total

    if rst_r > 0.5:
        return "rst_flood"
    if fin_r > 0.4:
        return "fin_flood"
    if ack_r > 0.6 and syn_r < 0.1:
        return "ack_flood"
    if psh_r > 0.4 and ack_r > 0.3:
        return "psh_ack_flood"
    return ""


# ---------------------------------------------------------------------------
# Health Check Server
# ---------------------------------------------------------------------------

class HealthCheckHandler:
    """Minimal HTTP health endpoint on localhost."""

    def __init__(self, agent, port: int = 9100):
        self._agent = agent
        self._port = port
        self._server = None

    def start(self) -> None:
        from http.server import HTTPServer, BaseHTTPRequestHandler

        agent_ref = self._agent

        class _Handler(BaseHTTPRequestHandler):
            def do_GET(self):  # noqa: N802
                body = json.dumps({
                    "status": "ok",
                    "version": VERSION,
                    "uptime_seconds": round(time.monotonic() - agent_ref._start_mono, 1),
                    "interface": agent_ref.monitor.interface,
                    "current_pps": round(agent_ref.monitor.pps, 1),
                    "current_bps": round(agent_ref.monitor.bps, 1),
                    "baseline_ready": agent_ref.baseline.baseline_ready,
                    "baseline_avg_pps": round(agent_ref.baseline.avg_pps, 1),
                    "baseline_threshold": round(agent_ref.threshold, 1),
                    "attack_active": agent_ref.attacking,
                    "incident_uuid": agent_ref.incident_uuid or None,
                }).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, format, *args):
                # Suppress default stderr logging
                pass

        try:
            self._server = HTTPServer(("127.0.0.1", self._port), _Handler)
            logger.info("Health check listening on 127.0.0.1:%d", self._port)
            self._server.serve_forever()
        except OSError as exc:
            logger.warning("Health check server failed to start on port %d: %s",
                           self._port, exc)


# ---------------------------------------------------------------------------
# Agent Core
# ---------------------------------------------------------------------------

class Agent:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.shutdown = threading.Event()
        self.api = APIClient(cfg)
        self.monitor = PPSMonitor(cfg.get("interface", "auto"))
        self.baseline = BaselineManager(
            window=cfg.get("baseline_window", 300))
        self.analyser = TrafficAnalyser()
        self.ioc_matcher = IOCMatcher()
        self.pcap = PcapCapture(cfg, self.monitor.interface,
                                self.analyser, self.ioc_matcher)

        # Flow collector (sFlow/NetFlow/IPFIX)
        self.flow: Optional[FlowCollector] = None
        if cfg.get("flow_enabled"):
            self.flow = FlowCollector(cfg)

        # L7 monitoring (configured via server config)
        self.l7: Optional[L7Monitor] = None
        self.l7_enabled = False
        self.l7_thread_running = False
        self.l7_incident_uuid = ""
        self.l7_last_metric_push: float = 0.0

        self.attacking = False
        self.attack_start: float = 0.0
        self.incident_uuid: str = ""
        self.peak_pps: float = 0.0
        self.peak_bps: float = 0.0
        self.below_count: int = 0
        self.velocity_curve: list = []
        self.last_update: float = 0.0
        self.server_threshold: float | None = None

        # Metrics batching: buffer locally, POST every N seconds
        self._metrics_interval = 5  # seconds between API POSTs
        self._metrics_buffer: list = []
        self._last_metrics_push: float = 0.0
        self._start_mono: float = time.monotonic()

    @property
    def threshold(self) -> float:
        if self.server_threshold is not None:
            return self.server_threshold
        return self.baseline.threshold

    def _proto_breakdown(self) -> dict:
        """Protocol breakdown from the best available source:
        1. Scapy packet inspection (ground truth — sees drops)
        2. Flow collector data (upstream router visibility)
        3. /proc/net/snmp (kernel counters only)"""
        scapy_proto = self.analyser.protocol_breakdown()
        if sum(scapy_proto.values()) > 0:
            return scapy_proto
        # Flow collector has per-protocol breakdowns from flow records
        if self.flow and self.flow.aggregator.flow_count > 0:
            return {
                "tcp": self.flow.aggregator.tcp_pct,
                "udp": self.flow.aggregator.udp_pct,
                "icmp": self.flow.aggregator.icmp_pct,
            }
        return {
            "tcp": self.monitor.tcp_pct,
            "udp": self.monitor.udp_pct,
            "icmp": self.monitor.icmp_pct,
        }

    def run(self) -> None:
        logger.info("Flowtriq Agent %s starting on %s",
                    VERSION, self.monitor.interface)

        # Check for updates on startup
        check_for_updates()

        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)

        threads = [
            threading.Thread(target=self._heartbeat_loop, daemon=True,
                             name="heartbeat"),
            threading.Thread(target=self._config_loop, daemon=True,
                             name="config"),
            threading.Thread(target=self._command_poll_loop, daemon=True,
                             name="command-poll"),
        ]

        # PCAP sniffer thread (tracked for watchdog restart)
        self._sniffer_thread = None
        if self.pcap.enabled:
            self._sniffer_thread = threading.Thread(
                target=self.pcap.background_ring, args=(self.shutdown,),
                daemon=True, name="pcap-ring")
            threads.append(self._sniffer_thread)

        # Health check HTTP server
        health_port = self.cfg.get("health_port", 9100)
        if health_port:
            health = HealthCheckHandler(self, port=health_port)
            threads.append(threading.Thread(
                target=health.start, daemon=True, name="health-check"))

        # Flow collector thread (sFlow/NetFlow/IPFIX)
        if self.flow:
            threads.append(threading.Thread(
                target=self.flow.start, args=(self.shutdown,),
                daemon=True, name="flow-collector"))

        # Auto-update thread
        if self.cfg.get("auto_update", False):
            threads.append(threading.Thread(
                target=self._auto_update_loop, daemon=True,
                name="auto-update"))

        for t in threads:
            t.start()

        self._fetch_config()

        # Start L7 thread if enabled by server config
        if self.l7 and self.l7_enabled and not self.l7_thread_running:
            self.l7_thread_running = True
            l7t = threading.Thread(target=self._l7_loop, daemon=True, name="l7-monitor")
            l7t.start()

        logger.info("Entering main monitoring loop")
        last_watchdog = time.monotonic()
        while not self.shutdown.is_set():
            loop_start = time.monotonic()
            try:
                self._tick()
            except Exception as exc:
                logger.error("Tick error: %s", exc)

            # Watchdog: check sniffer thread health every 60s
            if (self._sniffer_thread is not None
                    and loop_start - last_watchdog >= 60):
                last_watchdog = loop_start
                if not self._sniffer_thread.is_alive():
                    logger.warning(
                        "Sniffer thread died, restarting...")
                    self._sniffer_thread = threading.Thread(
                        target=self.pcap.background_ring,
                        args=(self.shutdown,),
                        daemon=True, name="pcap-ring")
                    self._sniffer_thread.start()

            elapsed = time.monotonic() - loop_start
            sleep_for = max(0, 1.0 - elapsed)
            self.shutdown.wait(sleep_for)

        logger.info("Agent shutting down")

    def _signal_handler(self, signum, frame) -> None:
        logger.info("Received signal %d, shutting down...", signum)
        self.shutdown.set()

    def _tick(self) -> None:
        if not self.monitor.read():
            return

        pps = self.monitor.pps
        bps = self.monitor.bps

        # Merge flow collector data when active — flow data provides richer
        # protocol breakdown and source IP visibility from upstream routers.
        # Use flow PPS/BPS if higher than local /proc/net/dev (flow sees
        # traffic before it reaches the kernel, e.g. upstream aggregation).
        if self.flow and self.flow.aggregator.read(dt=1.0):
            flow_pps = self.flow.aggregator.pps
            flow_bps = self.flow.aggregator.bps
            if flow_pps > pps:
                pps = flow_pps
                bps = flow_bps

        # Don't pollute baseline with attack traffic — it would inflate the
        # threshold and make future detection less sensitive.
        # Also skip samples above the absolute floor when baseline isn't ready,
        # so a new node getting attacked doesn't build a baseline from attack data.
        _abs_floor = self.server_threshold or 10000
        if not self.attacking and (self.baseline.baseline_ready or pps < _abs_floor):
            self.baseline.add(pps)

        # Buffer metrics locally, flush every _metrics_interval seconds.
        # Detection still runs every 1s tick — only the API POST is batched.
        # Use flow protocol breakdown when flow data is richer than /proc/net/snmp
        tcp_pct = self.monitor.tcp_pct
        udp_pct = self.monitor.udp_pct
        icmp_pct = self.monitor.icmp_pct
        if self.flow and self.flow.aggregator.flow_count > 0:
            tcp_pct = self.flow.aggregator.tcp_pct
            udp_pct = self.flow.aggregator.udp_pct
            icmp_pct = self.flow.aggregator.icmp_pct
        self._metrics_buffer.append({
            "pps": round(pps, 1),
            "bps": round(bps, 1),
            "tcp_pct": tcp_pct,
            "udp_pct": udp_pct,
            "icmp_pct": icmp_pct,
            "conn_count": self.monitor.conn_count,
            "threshold": round(self.threshold, 1),
        })
        now = time.monotonic()
        if now - self._last_metrics_push >= self._metrics_interval:
            self._last_metrics_push = now
            self._flush_metrics()

        if not self.attacking:
            # Two detection paths:
            # 1. Baseline-driven: PPS exceeds the dynamic threshold (p99 * 3)
            # 2. Absolute floor: if baseline isn't ready yet and PPS exceeds
            #    a hard floor (10K), treat it as an attack immediately.
            #    This catches attacks on brand-new nodes before enough
            #    samples exist for a meaningful baseline.
            _absolute_floor = self.server_threshold or 10000
            _trigger = pps > self.threshold
            if not self.baseline.baseline_ready and pps >= _absolute_floor:
                _trigger = True

            if _trigger:
                # Flush buffered metrics immediately so the dashboard sees the spike
                self._flush_metrics()
                self._last_metrics_push = now
                self._begin_attack()
        else:
            if pps > self.peak_pps:
                self.peak_pps = pps
            if bps > self.peak_bps:
                self.peak_bps = bps

            if pps < self.threshold:
                self.below_count += 1
            else:
                self.below_count = 0

            if self.below_count >= 10:
                # Flush metrics immediately so dashboard sees the resolution
                self._flush_metrics()
                self._last_metrics_push = now
                self._end_attack()
            elif time.monotonic() - self.last_update >= 5:
                self._update_attack()

    def _flush_metrics(self) -> None:
        """Aggregate buffered metrics and send a single API POST."""
        buf = self._metrics_buffer
        if not buf:
            return
        n = len(buf)
        # Send the latest snapshot with peak values from the buffer window
        agg = {
            "pps":       round(max(m["pps"] for m in buf), 1),
            "bps":       round(max(m["bps"] for m in buf), 1),
            "tcp_pct":   buf[-1]["tcp_pct"],
            "udp_pct":   buf[-1]["udp_pct"],
            "icmp_pct":  buf[-1]["icmp_pct"],
            "conn_count": buf[-1]["conn_count"],
            "threshold": buf[-1]["threshold"],
            "avg_pps":   round(sum(m["pps"] for m in buf) / n, 1),
            "samples":   n,
        }
        self._metrics_buffer = []
        self.api.send_metrics(agg)

    def _begin_attack(self) -> None:
        self.attacking = True
        self.attack_start = time.time()
        self.peak_pps = self.monitor.pps
        self.peak_bps = self.monitor.bps
        self.below_count = 0
        self.velocity_curve = []
        self.analyser.reset()
        self.last_update = time.monotonic()

        # Flush buffered metrics immediately so dashboard sees the spike
        self._flush_metrics()

        # Estimate protocol breakdown + SYN ratio from ring buffer for accurate
        # initial classification.  /proc/net/snmp misses dropped flood packets,
        # so we inspect the actual captured packets from scapy's ring buffer.
        _syn_est = 0.0
        _ring_tcp = _ring_udp = _ring_icmp = 0
        if SCAPY_AVAILABLE and self.pcap.ring_buffer:
            try:
                _ring_snapshot = list(self.pcap.ring_buffer)
            except RuntimeError:
                _ring_snapshot = []
            _syn_c = _ack_c = 0
            for _rpkt in _ring_snapshot:
                if _rpkt.haslayer(TCP):
                    _ring_tcp += 1
                    _f = _rpkt[TCP].flags
                    if _f & 0x02: _syn_c += 1
                    if _f & 0x10: _ack_c += 1
                elif _rpkt.haslayer(UDP):
                    _ring_udp += 1
                elif _rpkt.haslayer(ICMP):
                    _ring_icmp += 1
            if _syn_c + _ack_c > 0:
                _syn_est = _syn_c / (_syn_c + _ack_c)

        # tcpdump mode: parse ring files for protocol classification
        if self.pcap.pcap_mode == "tcpdump" and _ring_total == 0 and self.pcap._ring_dir:
            try:
                import glob, subprocess
                ring_files = sorted(glob.glob(os.path.join(self.pcap._ring_dir, "ring_*.pcap")))
                if ring_files:
                    # Use the most recent ring file
                    latest = ring_files[-1]
                    out = subprocess.run(
                        ["tcpdump", "-nn", "-r", latest, "-c", "500", "-q"],
                        capture_output=True, text=True, timeout=10)
                    for _tline in out.stdout.splitlines():
                        if "UDP" in _tline or "udp" in _tline:
                            _ring_udp += 1
                        elif "TCP" in _tline or "Flags" in _tline:
                            _ring_tcp += 1
                            if " S " in _tline or "[S]" in _tline:
                                _syn_c += 1
                            if "[.]" in _tline or " ack " in _tline:
                                _ack_c += 1
                        elif "ICMP" in _tline or "icmp" in _tline:
                            _ring_icmp += 1
                    if _syn_c + _ack_c > 0:
                        _syn_est = _syn_c / (_syn_c + _ack_c)
            except Exception as _e:
                logger.debug("tcpdump ring parse for classify: %s", _e)

        # Use ring buffer protocol data if available, fall back to SNMP
        _ring_total = _ring_tcp + _ring_udp + _ring_icmp
        if _ring_total > 10:
            _init_tcp = round(_ring_tcp / _ring_total * 100, 1)
            _init_udp = round(_ring_udp / _ring_total * 100, 1)
            _init_icmp = round(_ring_icmp / _ring_total * 100, 1)
        else:
            _init_tcp = self.monitor.tcp_pct
            _init_udp = self.monitor.udp_pct
            _init_icmp = self.monitor.icmp_pct

        family = classify_attack(_init_tcp, _init_udp, _init_icmp,
                                 syn_ratio=_syn_est)
        started_at = datetime.now(timezone.utc).isoformat()

        logger.warning("ATTACK DETECTED — PPS=%.0f threshold=%.0f family=%s",
                       self.peak_pps, self.threshold, family)

        # Alert-first: open incident before starting PCAP capture
        inc_data = {
            "peak_pps": round(self.peak_pps, 1),
            "peak_bps": round(self.peak_bps, 1),
            "started_at": started_at,
            "attack_family": family,
            "baseline_pps": round(self.baseline.avg_pps, 1),
            "duration": 0,
        }
        # Include flow collector source IPs + ports for immediate visibility
        if self.flow and self.flow.aggregator.src_ip_count > 0:
            inc_data["top_src_ips"] = [
                {"ip": ip, "packets": pkts}
                for ip, pkts in self.flow.aggregator.top_src_ips(20)
            ]
            inc_data["top_dst_ports"] = [
                {"port": port, "packets": pkts}
                for port, pkts in self.flow.aggregator.top_dst_ports(20)
            ]
            inc_data["source_ip_count"] = self.flow.aggregator.src_ip_count
        result = self.api.open_incident(inc_data)

        if result and "uuid" in result:
            self.incident_uuid = result["uuid"]
            logger.info("Incident opened: %s", self.incident_uuid)
            # Apply auto-mitigation commands returned with the incident response
            # so firewall rules take effect immediately without waiting for next poll
            if "pending_commands" in result and result["pending_commands"]:
                logger.info("Applying %d auto-mitigation command(s) from incident response",
                            len(result["pending_commands"]))
                for cmd in result["pending_commands"]:
                    self._execute_command(cmd)
        else:
            self.incident_uuid = str(uuid.uuid4())
            logger.warning("Using local incident UUID: %s", self.incident_uuid)

        if self.pcap.enabled:
            self.pcap.start_capture(
                incident_uuid=self.incident_uuid,
                api_client=self.api)

        self.velocity_curve.append({
            "t": 0,
            "pps": round(self.peak_pps, 1),
        })

        # Immediately fetch config to pick up any mitigation commands
        # queued by the server in response to the incident we just opened
        threading.Thread(target=self._fetch_config, daemon=True,
                         name="attack-config-fetch").start()

    def _update_attack(self) -> None:
        if not self.incident_uuid:
            logger.warning("Skipping attack update — no incident UUID")
            return
        self.last_update = time.monotonic()
        elapsed = time.time() - self.attack_start
        self.velocity_curve.append({
            "t": round(elapsed, 1),
            "pps": round(self.monitor.pps, 1),
        })

        proto = self._proto_breakdown()
        family = classify_attack(proto["tcp"], proto["udp"], proto["icmp"])

        self.api.update_incident(self.incident_uuid, {
            "peak_pps": round(self.peak_pps, 1),
            "peak_bps": round(self.peak_bps, 1),
            "attack_family": family,
            "protocol_breakdown": proto,
            "source_ip_count": len(self.analyser.src_ips),
            "total_packets": self.analyser.total_packets,
            "top_src_ips": self.analyser.top_src_ips(),
            "top_dst_ports": self.analyser.top_dst_ports(),
            "ioc_hits": list(set(self.analyser.ioc_hits)),
            "spoofing_detected": self.analyser.spoofing_detected(),
            "botnet_detected": self.analyser.botnet_detected(),
        })

    def _end_attack(self) -> None:
        duration = time.time() - self.attack_start
        proto = self._proto_breakdown()
        _top_ports = self.analyser.top_dst_ports()
        _flags = dict(self.analyser.tcp_flags)
        _avg_pkt = self.analyser.avg_pkt_length()
        family = classify_attack(
            proto["tcp"], proto["udp"], proto["icmp"],
            syn_ratio=self.analyser.syn_ratio(),
            dns_detected=bool(self.analyser.dns_queries),
        )
        # Derive subtype from port/flag/size evidence
        subtype = classify_subtype(family, _top_ports, _flags, _avg_pkt)
        # For TCP-dominant traffic that isn't SYN flood, check for other TCP subtypes
        if family == "unknown" and proto["tcp"] > 40:
            tcp_sub = classify_tcp_subtype(_flags)
            if tcp_sub:
                subtype = tcp_sub

        logger.warning("ATTACK ENDED — duration=%.0fs peak_pps=%.0f family=%s subtype=%s",
                       duration, self.peak_pps, family, subtype or "none")

        if not self.incident_uuid:
            logger.error("Cannot resolve incident — UUID is empty (open_incident likely failed)")
            self.attacking = False
            return

        self.api.resolve_incident(self.incident_uuid, {
            "duration_seconds": round(duration, 1),
            "peak_pps": round(self.peak_pps, 1),
            "peak_bps": round(self.peak_bps, 1),
            "attack_family": family,
            "attack_subtype": subtype or None,
            "protocol_breakdown": proto,
            "ioc_hits": list(set(self.analyser.ioc_hits)),
            "spoofing_detected": self.analyser.spoofing_detected(),
            "botnet_detected": self.analyser.botnet_detected(),
            "total_packets": self.analyser.total_packets,
            "source_ip_count": len(self.analyser.src_ips),
            "src_ip_entropy": self.analyser.src_ip_entropy(),
            "tcp_flag_breakdown": _flags,
            "dns_query_stats": self.analyser.dns_query_stats(),
            "pkt_length_histogram": self.analyser.pkt_length_histogram(),
            "ttl_distribution": self.analyser.ttl_distribution(),
            "velocity_curve": self.velocity_curve,
            "top_src_ips": self.analyser.top_src_ips(),
            "top_dst_ports": self.analyser.top_dst_ports(),
            "avg_pkt_length": self.analyser.avg_pkt_length(),
        })

        if self.pcap.enabled:
            pcap_path = self.pcap.stop_capture(self.incident_uuid)
            if pcap_path:
                threading.Thread(
                    target=self.api.upload_pcap,
                    args=(self.incident_uuid, pcap_path),
                    daemon=True,
                ).start()

        self.attacking = False
        self.incident_uuid = ""

    def _heartbeat_loop(self) -> None:
        _last_update_check = time.monotonic()
        while not self.shutdown.is_set():
            self.shutdown.wait(30)
            if self.shutdown.is_set():
                break
            try:
                hb = {
                    "version": VERSION,
                    "baseline_ready": self.baseline.baseline_ready,
                    "baseline_avg_pps": round(self.baseline.avg_pps, 1),
                    "baseline_p99_pps": round(self.baseline.p99_pps, 1),
                    "circuit_breaker": self.api.circuit_breaker_state,
                    "retry_queue_size": len(self.api.retry_queue),
                }
                # Export analyser overflow metrics
                if hasattr(self, 'analyser'):
                    hb["src_ip_overflow"] = self.analyser._src_ip_overflow
                    hb["src_ip_count"] = len(self.analyser.src_ips)
                    hb["pkt_samples_count"] = len(self.analyser.pkt_lengths)
                # Export flow collector stats
                if self.flow:
                    hb["flow_collector"] = self.flow.stats
                self.api.heartbeat(hb)
            except Exception as exc:
                logger.error("Heartbeat error: %s", exc)

            # Check for updates every 6 hours
            if time.monotonic() - _last_update_check >= 21600:
                _last_update_check = time.monotonic()
                check_for_updates()

    def _auto_update_loop(self) -> None:
        """Check PyPI for newer version; upgrade if auto_update is on.
        First check after 60 seconds (catch updates quickly), then every 6 hours."""
        first_run = True
        while not self.shutdown.is_set():
            wait_time = 60 if first_run else 21600  # 60s first, then 6 hours
            first_run = False
            self.shutdown.wait(wait_time)
            if self.shutdown.is_set():
                break
            try:
                import urllib.request
                url = "https://pypi.org/pypi/ftagent/json"
                req = urllib.request.Request(
                    url, headers={"User-Agent": f"ftagent/{VERSION}"})
                resp = urllib.request.urlopen(req, timeout=15)
                data = json.loads(resp.read())
                latest = data.get("info", {}).get("version", "")
                if not latest:
                    continue

                def _ver_tuple(v):
                    parts = []
                    for p in v.split("."):
                        try:
                            parts.append(int(p))
                        except ValueError:
                            parts.append(0)
                    return tuple(parts)

                if _ver_tuple(latest) > _ver_tuple(VERSION):
                    logger.info(
                        "Auto-update: newer version %s available (current %s), "
                        "upgrading...", latest, VERSION)
                    import subprocess
                    pip_cmd = [sys.executable, "-m", "pip", "install",
                               "--upgrade", "ftagent"]
                    result = subprocess.run(
                        pip_cmd, capture_output=True, text=True, timeout=120,
                    )
                    # Handle PEP 668 (externally managed Python on Debian 12+, Ubuntu 23.04+)
                    if result.returncode != 0 and "externally-managed-environment" in result.stderr:
                        pip_cmd.insert(-1, "--break-system-packages")
                        result = subprocess.run(
                            pip_cmd, capture_output=True, text=True, timeout=120,
                        )
                    if result.returncode == 0:
                        logger.info(
                            "Auto-update: ftagent upgraded to %s. "
                            "Restarting service...", latest)
                        # Auto-restart via systemd if running as service
                        try:
                            subprocess.run(
                                ["systemctl", "restart", "ftagent"],
                                capture_output=True, timeout=30,
                            )
                        except Exception:
                            logger.info("Auto-update: restart ftagent manually to use v%s", latest)
                    else:
                        logger.warning(
                            "Auto-update: pip upgrade failed: %s",
                            result.stderr.strip()[:500])
            except Exception as exc:
                logger.debug("Auto-update check failed: %s", exc)

    def _command_poll_loop(self) -> None:
        """Poll for pending commands (iptables rules).
        Normal: every 5 minutes. During attack: every 10 seconds for fast mitigation."""
        while not self.shutdown.is_set():
            interval = 10 if self.attacking else 300
            self.shutdown.wait(interval)
            if self.shutdown.is_set():
                break
            try:
                data = self.api.get_config()
                if data and "pending_commands" in data and data["pending_commands"]:
                    for cmd in data["pending_commands"]:
                        self._execute_command(cmd)
                    logger.info("Command poll: processed %d commands",
                                len(data["pending_commands"]))
            except Exception as exc:
                logger.error("Command poll error: %s", exc)

    def _config_loop(self) -> None:
        while not self.shutdown.is_set():
            self.shutdown.wait(300)
            if self.shutdown.is_set():
                break
            self._fetch_config()

    def _fetch_config(self) -> None:
        try:
            data = self.api.get_config()
            if data is None:
                return
            if "pps_threshold" in data and data["pps_threshold"]:
                self.server_threshold = float(data["pps_threshold"])
                logger.info("Server threshold: %.0f", self.server_threshold)
            elif data.get("dynamic_threshold", True):
                self.server_threshold = None
            if "ioc_patterns" in data:
                self.ioc_matcher.load(data["ioc_patterns"])
            if "pcap_enabled" in data:
                self.pcap.enabled = data["pcap_enabled"] and SCAPY_AVAILABLE
            # Process pending commands (iptables rules from dashboard)
            if "pending_commands" in data and data["pending_commands"]:
                for cmd in data["pending_commands"]:
                    self._execute_command(cmd)

            # Flow collector config from server (dashboard can enable/configure per node)
            flow_cfg = data.get("flow", {})
            if flow_cfg.get("enabled") and not self.flow:
                # Server enabled flow collection — start collector
                merged = dict(self.cfg)
                merged["flow_enabled"] = True
                merged["flow_protocol"] = flow_cfg.get("protocol", "auto")
                merged["flow_port"] = flow_cfg.get("port", 0)
                merged["flow_sample_rate"] = flow_cfg.get("sample_rate", 0)
                merged["flow_source_ips"] = flow_cfg.get("source_ips", [])
                self.flow = FlowCollector(merged)
                self.flow.aggregator.node_ip = flow_cfg.get("node_ip", "")
                threading.Thread(
                    target=self.flow.start, args=(self.shutdown,),
                    daemon=True, name="flow-collector").start()
                logger.info("Flow collector enabled by server config: %s port %d (filtering dst_ip=%s)",
                           merged["flow_protocol"], self.flow.port, flow_cfg.get("node_ip", ""))
            elif flow_cfg.get("enabled") and self.flow:
                # Update node IP filter (in case node IP changes)
                self.flow.aggregator.node_ip = flow_cfg.get("node_ip", "")
            elif not flow_cfg.get("enabled") and self.flow:
                logger.info("Flow collector disabled by server config")
                self.flow = None  # thread will exit on next shutdown check

            # L7 config from server
            l7_cfg = data.get("l7", {})
            if l7_cfg.get("enabled"):
                was_enabled = self.l7_enabled
                self.l7_enabled = True
                action = l7_cfg.get("action")
                if action == "auto_detect" and not self.l7:
                    self._l7_auto_detect()
                elif l7_cfg.get("log_path"):
                    self._l7_start(l7_cfg["log_path"], l7_config=l7_cfg)
                    # Start L7 thread if not already running
                    if self.l7 and not self.l7_thread_running:
                        self.l7_thread_running = True
                        l7t = threading.Thread(
                            target=self._l7_loop, daemon=True, name="l7-monitor")
                        l7t.start()
            elif self.l7:
                logger.info("L7: disabled by server config")
                self.l7 = None
                self.l7_enabled = False

        except Exception as exc:
            logger.error("Config fetch error: %s", exc)

    # ── L7 Methods ─────────────────────────────────────────────────────────

    def _l7_auto_detect(self) -> None:
        logger.info("L7: running web server auto-detection...")
        result = detect_web_server()
        self.api._post("/agent/l7/detect", {
            "web_server": result["web_server"],
            "server_version": result.get("server_version"),
            "detected_paths": result["detected_paths"],
        }, retries=2)
        if result["web_server"]:
            logger.info("L7: detected %s, paths: %s",
                        result["web_server"], result["detected_paths"])
        else:
            logger.info("L7: no web server detected")

    def _l7_start(self, log_path: str, l7_config: dict = None) -> None:
        if self.l7 and self.l7.log_path == log_path:
            # Update thresholds on existing monitor without restarting
            if l7_config and self.l7:
                cfg = l7_config
                if cfg.get("rps_threshold"):
                    self.l7._rps_threshold_override = cfg["rps_threshold"]
                if cfg.get("error_rate_threshold"):
                    self.l7._error_rate_threshold = cfg["error_rate_threshold"]
                sens = cfg.get("sensitivity", "medium")
                self.l7._sensitivity_multiplier = {"low": 8, "medium": 5, "high": 3}.get(sens, 5)
                self.l7._min_rps = {"low": 250, "medium": 150, "high": 75}.get(sens, 150)
            return
        self._l7_log_path = log_path
        logger.info("L7: starting access log monitoring on %s", log_path)
        self.l7 = L7Monitor(log_path, self.api, l7_config=l7_config)
        if not self.l7.open():
            logger.warning("L7: %s not available yet, will retry on next cycle", log_path)
            self.l7 = None
            # Don't report failure -- file may appear after log rotation
        else:
            # Tell server we're actively monitoring this path
            self.api._post("/agent/l7/detect", {
                "web_server": "detected",
                "detected_paths": [log_path],
                "active_log_path": log_path,
            }, retries=1)

    def _l7_loop(self) -> None:
        logger.info("L7: monitoring thread started")
        _l7_retry_count = 0
        while not self.shutdown.is_set():
            self.shutdown.wait(1)
            if self.shutdown.is_set():
                break
            if not self.l7:
                # File wasn't available (log rotation). Retry every 30s.
                _l7_retry_count += 1
                if _l7_retry_count % 30 == 0:  # every 30s (30 * 1s)
                    cfg = {"log_path": getattr(self, '_l7_log_path', None)}
                    if cfg["log_path"]:
                        self._l7_start(cfg["log_path"])
                        if self.l7:
                            _l7_retry_count = 0
                continue
            try:
                stats = self.l7.tick()
                if not stats:
                    continue
                now = time.monotonic()
                if now - self.l7_last_metric_push >= 10:
                    self.l7_last_metric_push = now
                    self.api._post("/agent/l7/metrics", stats, retries=1)
                attack_info = self.l7.check_attack(stats)
                if not attack_info:
                    continue
                # Suppress L7 detection when an L3/L4 attack is already active —
                # web server stress during a volumetric flood is a side effect,
                # not a separate L7 attack.
                if attack_info["type"] == "l7_flood" and self.attacking:
                    logger.debug("L7: suppressed — L3/L4 attack already active")
                    self.l7._attack_active = False
                    continue
                if attack_info["type"] == "l7_flood":
                    self._l7_begin_attack(attack_info)
                elif attack_info["type"] == "l7_flood_end":
                    self._l7_end_attack(attack_info)
                elif attack_info["type"] == "l7_flood_update":
                    self._l7_update_attack(attack_info)
            except Exception as exc:
                logger.error("L7 tick error: %s", exc)

    def _l7_begin_attack(self, info: dict) -> None:
        rps = info["rps"]
        baseline_rps = info.get("baseline_rps", 0)
        subtype = info.get("attack_subtype", "l7_flood")
        logger.warning("L7 ATTACK DETECTED — type=%s RPS=%.0f baseline=%.0f reasons=%s",
                       subtype, rps, baseline_rps, info["reasons"])
        self.l7_peak_rps = rps
        self.l7_baseline_rps = baseline_rps
        self.l7_velocity_curve = [{"t": 0, "rps": round(rps, 1)}]
        self.l7_attack_start = time.time()
        stats = info.get("stats", {})
        result = self.api.open_incident({
            "peak_pps": 0,
            "peak_bps": 0,
            "rps": round(rps),
            "baseline_rps": round(baseline_rps, 1),
            "started_at": datetime.now(timezone.utc).isoformat(),
            "attack_family": "http_flood",
            "attack_subtype": subtype,
        })
        if result and "uuid" in result:
            self.l7_incident_uuid = result["uuid"]
        else:
            self.l7_incident_uuid = str(uuid.uuid4())

        # Trigger PCAP capture for L7 attacks too
        if self.pcap.enabled:
            self.pcap.start_capture(
                incident_uuid=self.l7_incident_uuid,
                api_client=self.api)

        # Use real protocol data from scapy/SNMP instead of hardcoding
        real_proto = self._proto_breakdown()
        self.api.update_incident(self.l7_incident_uuid, {
            "attack_family": "http_flood",
            "attack_subtype": subtype,
            "rps": round(rps),
            "baseline_rps": round(baseline_rps, 1),
            "source_ip_count": stats.get("unique_ips", 0),
            "top_src_ips": [{"ip": ip, "count": cnt}
                           for ip, cnt in list(stats.get("top_ips", {}).items())[:50]],
            "top_dst_ports": stats.get("top_paths", {}),
            "protocol_breakdown": real_proto,
            # New L7-specific fields
            "l7_error_rate": stats.get("error_rate", 0),
            "l7_status_codes": stats.get("status_codes", {}),
            "l7_top_user_agents": stats.get("top_user_agents", {}),
            "l7_threat_patterns": stats.get("threat_patterns", {}),
        })

    def _l7_update_attack(self, info: dict) -> None:
        if not self.l7_incident_uuid:
            return
        rps = info.get("rps", 0)
        if rps > getattr(self, 'l7_peak_rps', 0):
            self.l7_peak_rps = rps
        stats = info.get("stats", {})
        subtype = _classify_l7_subtype(stats) if stats else "l7_flood"

        # Track RPS velocity curve
        elapsed = time.time() - getattr(self, 'l7_attack_start', time.time())
        curve = getattr(self, 'l7_velocity_curve', [])
        curve.append({"t": round(elapsed, 1), "rps": round(rps, 1)})
        self.l7_velocity_curve = curve

        bot_pct = stats.get("bot_request_pct", 0)
        # Use accumulated attack-wide data for IPs, paths, UAs, status codes
        # so dashboard shows running totals, not just the last 10-second window
        accum = self.l7.get_attack_summary() if self.l7 else {}
        accum_ips = accum.get("top_ips", stats.get("top_ips", {}))
        accum_paths = accum.get("top_paths", stats.get("top_paths", {}))
        accum_total = accum.get("total_requests", stats.get("total_requests", 0))

        self.api.update_incident(self.l7_incident_uuid, {
            "attack_family": "http_flood",
            "attack_subtype": subtype,
            "rps": round(rps),
            "baseline_rps": round(getattr(self, 'l7_baseline_rps', 0), 1),
            "source_ip_count": len(accum_ips),
            "total_packets": accum_total,
            "top_src_ips": [{"ip": ip, "count": cnt}
                           for ip, cnt in list(accum_ips.items())[:50]],
            "top_dst_ports": accum_paths,
            "protocol_breakdown": self._proto_breakdown(),
            "botnet_detected": bot_pct > 70,
            "l7_error_rate": stats.get("error_rate", 0),
            "l7_status_codes": accum.get("status_codes", stats.get("status_codes", {})),
            "l7_top_user_agents": accum.get("top_user_agents", stats.get("top_user_agents", {})),
            "l7_threat_patterns": accum.get("threat_patterns", stats.get("threat_patterns", {})),
        })

    def _l7_end_attack(self, info: dict) -> None:
        if not self.l7_incident_uuid:
            return
        duration = info.get("duration_seconds", 0)
        peak_rps = getattr(self, 'l7_peak_rps', info.get("peak_rps", 0))
        baseline_rps = getattr(self, 'l7_baseline_rps', 0)
        subtype = info.get("attack_subtype", "l7_flood")
        logger.warning("L7 ATTACK ENDED — type=%s duration=%.0fs peak_rps=%.0f",
                       subtype, duration, peak_rps)

        # Stop PCAP capture
        try:
            if self.pcap.capturing:
                self.pcap.stop_capture(self.l7_incident_uuid)
        except Exception as exc:
            logger.error("L7: PCAP stop error: %s", exc)

        stats = info.get("stats", {})
        summary = info.get("attack_summary", {})
        bot_pct = stats.get("bot_request_pct", summary.get("bot_request_pct", 0))

        # Finalize velocity curve
        velocity = getattr(self, 'l7_velocity_curve', [])
        velocity.append({"t": round(duration, 1), "rps": round(info.get("rps", 0), 1)})

        self.api.resolve_incident(self.l7_incident_uuid, {
            "duration_seconds": duration,
            "peak_pps": 0,
            "peak_bps": 0,
            "peak_rps": round(peak_rps),
            "baseline_rps": round(baseline_rps, 1),
            "attack_family": "http_flood",
            "attack_subtype": subtype,
            "protocol_breakdown": self._proto_breakdown(),
            "source_ip_count": len(summary.get("top_ips", stats.get("top_ips", {}))),
            "total_packets": summary.get("total_requests", stats.get("total_requests", 0)),
            "botnet_detected": bot_pct > 70,
            "velocity_curve": velocity,
            # Use accumulated attack-wide data (summary), not last-window (stats)
            "top_src_ips": [{"ip": ip, "count": cnt}
                           for ip, cnt in list(summary.get("top_ips", stats.get("top_ips", {})).items())[:50]],
            "top_dst_ports": summary.get("top_paths", stats.get("top_paths", {})),
            # Full attack-wide L7 enrichment
            "l7_error_rate": summary.get("error_rate", stats.get("error_rate", 0)),
            "l7_status_codes": summary.get("status_codes", stats.get("status_codes", {})),
            "l7_top_user_agents": summary.get("top_user_agents", stats.get("top_user_agents", {})),
            "l7_targeted_paths": summary.get("top_paths", stats.get("top_paths", {})),
            "l7_threat_patterns": summary.get("threat_patterns", stats.get("threat_patterns", {})),
        })
        self.l7_incident_uuid = ""
        self.l7_peak_rps = 0

    def _execute_command(self, cmd: dict) -> None:
        """Execute a pending command (iptables/sysctl/xdp) from the dashboard."""
        cmd_id = cmd.get("id", 0)
        cmd_type = cmd.get("command_type", "iptables")
        cmd_text = cmd.get("command_text", "")
        title = cmd.get("title", "")

        if not cmd_text:
            return

        logger.info("Executing %s command #%d: %s", cmd_type, cmd_id, title)

        # XDP/eBPF commands: JSON-based spec, handled separately
        if cmd_type == "xdp":
            result = self._execute_xdp_command(cmd_id, cmd_text, title)
            return

        allowed_prefixes = (
            "iptables ", "ip6tables ", "ipset ", "sysctl ",
            "nft ", "ufw ", "firewall-cmd ", "tc ", "ip route ",
            "fail2ban-client ", "nginx ", "apache2ctl ",
            "echo ", "sed ", "rm -f /etc/nginx/conf.d/ft_",
            "rm -f /etc/apache2/conf-enabled/ft_",
            "for cc in ",
        )
        errors = []
        applied = 0

        for line in cmd_text.strip().split("\n"):
            line = line.strip()
            if not line:
                continue
            # Safety: only allow iptables/ipset/sysctl commands
            if not any(line.startswith(p) for p in allowed_prefixes):
                errors.append(f"Blocked unsafe command: {line}")
                logger.warning("Blocked unsafe command: %s", line)
                continue
            try:
                import subprocess
                result = subprocess.run(
                    line, shell=True, capture_output=True, text=True,
                    timeout=30,
                )
                if result.returncode == 0:
                    applied += 1
                    logger.info("Applied: %s", line)
                else:
                    err = result.stderr.strip() or f"exit code {result.returncode}"
                    errors.append(f"{line}: {err}")
                    logger.warning("Command failed: %s — %s", line, err)
            except Exception as exc:
                errors.append(f"{line}: {exc}")
                logger.error("Command error: %s — %s", line, exc)

        # Report back to server
        status = "applied" if not errors else ("failed" if not applied else "applied")
        error_msg = "; ".join(errors) if errors else None
        self.api._post("/agent/commands/ack", {
            "command_id": cmd_id,
            "status": status,
            "error": error_msg,
        }, retries=2)

    def _execute_xdp_command(self, cmd_id: int, spec_json: str, title: str) -> None:
        """Execute an XDP/eBPF filter command.

        XDP filters provide kernel-bypass packet filtering at line rate,
        orders of magnitude faster than iptables for high-PPS attacks.

        Supports two modes:
        1. nftables-based (fallback): uses nft for filtering when XDP tools unavailable
        2. XDP-native: uses ip link + BPF programs when xdp-loader/bpftool available

        Spec format (JSON):
        {
            "type": "xdp_filter" | "xdp_filter_remove",
            "target": "192.0.2.1",
            "proto": "udp" | "tcp" | "icmp" | "any",
            "dport": 53,           // optional
            "action": "drop" | "pass",
            "rate_pps": 10000      // optional, packets per second
        }
        """
        import json as _json
        import subprocess

        errors = []
        applied = 0

        try:
            spec = _json.loads(spec_json)
        except Exception as exc:
            self.api._post("/agent/commands/ack", {
                "command_id": cmd_id,
                "status": "failed",
                "error": f"Invalid XDP spec JSON: {exc}",
            }, retries=2)
            return

        spec_type = spec.get("type", "")
        target = spec.get("target", "")
        proto = spec.get("proto", "any")
        dport = spec.get("dport")
        action = spec.get("action", "drop")
        rate_pps = spec.get("rate_pps")

        if not target:
            self.api._post("/agent/commands/ack", {
                "command_id": cmd_id,
                "status": "failed",
                "error": "XDP spec missing target IP",
            }, retries=2)
            return

        # Sanitize target IP (prevent injection)
        import re
        if not re.match(r'^[\da-fA-F.:]+$', target):
            self.api._post("/agent/commands/ack", {
                "command_id": cmd_id,
                "status": "failed",
                "error": f"Invalid target IP: {target}",
            }, retries=2)
            return

        # Use nftables for high-performance filtering (widely available, fast path in kernel)
        # XDP-native would require precompiled BPF programs; nft is the practical approach
        nft_table = "flowtriq_xdp"
        nft_chain = "filter"
        nft_comment = f"flowtriq_xdp_{target.replace('.', '_').replace(':', '_')}"

        if spec_type == "xdp_filter_remove":
            # Remove all nft rules matching this target
            cmds = [
                f"nft delete rule inet {nft_table} {nft_chain} comment \"{nft_comment}\" 2>/dev/null || true",
            ]
            # Also try removing by handle (more reliable)
            cmds.append(
                f"for h in $(nft -a list chain inet {nft_table} {nft_chain} 2>/dev/null "
                f"| grep '{nft_comment}' | grep -oP 'handle \\K\\d+'); do "
                f"nft delete rule inet {nft_table} {nft_chain} handle $h; done 2>/dev/null || true"
            )
        elif spec_type == "xdp_filter":
            # Ensure table and chain exist
            cmds = [
                f"nft add table inet {nft_table} 2>/dev/null || true",
                f"nft add chain inet {nft_table} {nft_chain} "
                f"{{ type filter hook ingress priority -500\\; policy accept\\; }} 2>/dev/null || true",
            ]

            # Build the match expression
            match_parts = [f"ip daddr {target}"]
            if proto in ("tcp", "udp"):
                match_parts.append(f"meta l4proto {proto}")
                if dport:
                    match_parts.append(f"th dport {int(dport)}")
            elif proto == "icmp":
                match_parts.append("meta l4proto icmp")

            match_expr = " ".join(match_parts)

            if rate_pps:
                # Rate-limit mode: allow up to rate_pps, drop excess
                cmds.append(
                    f"nft add rule inet {nft_table} {nft_chain} "
                    f"{match_expr} limit rate over {int(rate_pps)}/second "
                    f"drop comment \"{nft_comment}\""
                )
            else:
                # Full drop mode
                nft_action = "drop" if action == "drop" else "accept"
                cmds.append(
                    f"nft add rule inet {nft_table} {nft_chain} "
                    f"{match_expr} {nft_action} comment \"{nft_comment}\""
                )
        else:
            self.api._post("/agent/commands/ack", {
                "command_id": cmd_id,
                "status": "failed",
                "error": f"Unknown XDP spec type: {spec_type}",
            }, retries=2)
            return

        # Execute nft commands
        for c in cmds:
            try:
                result = subprocess.run(
                    c, shell=True, capture_output=True, text=True, timeout=15,
                )
                if result.returncode == 0:
                    applied += 1
                    logger.info("XDP/nft applied: %s", c)
                else:
                    err = result.stderr.strip() or f"exit code {result.returncode}"
                    errors.append(f"{c}: {err}")
                    logger.warning("XDP/nft failed: %s — %s", c, err)
            except Exception as exc:
                errors.append(f"{c}: {exc}")
                logger.error("XDP/nft error: %s — %s", c, exc)

        status = "applied" if not errors else ("failed" if not applied else "applied")
        error_msg = "; ".join(errors) if errors else None
        logger.info("XDP command #%d: %s (%d applied, %d errors)", cmd_id, status, applied, len(errors))
        self.api._post("/agent/commands/ack", {
            "command_id": cmd_id,
            "status": status,
            "error": error_msg,
        }, retries=2)


# ---------------------------------------------------------------------------
# CLI: Setup Wizard
# ---------------------------------------------------------------------------

def setup_wizard(config_path: str) -> None:
    print("\n  Flowtriq Agent Setup Wizard\n")
    cfg = dict(DEFAULT_CONFIG)

    cfg["api_key"] = input("  API Key: ").strip()
    node = ""
    while not node:
        node = input("  Node UUID (from your Flowtriq dashboard): ").strip()
        if not node:
            print("  Node UUID is required. Copy it from your Flowtriq dashboard → Nodes.")
    cfg["node_uuid"] = node
    base = input(f"  API Base URL [{cfg['api_base']}]: ").strip()
    if base:
        cfg["api_base"] = base
    iface = input(f"  Network interface [{cfg['interface']}]: ").strip()
    if iface:
        cfg["interface"] = iface
    pcap = input("  Enable PCAP capture? [Y/n]: ").strip().lower()
    cfg["pcap_enabled"] = pcap != "n"

    if cfg["pcap_enabled"]:
        print("\n  PCAP capture mode:")
        print("    1. scapy   - Real-time per-packet analysis (default)")
        print("                 Best for most servers. Higher CPU at very high PPS (50K+).")
        print("    2. tcpdump - Native kernel-speed capture, near-zero CPU")
        print("                 Best for high-traffic servers or nodes that regularly see 10K+ PPS.")
        pcap_choice = input("  Choose [1/2, default=1]: ").strip()
        if pcap_choice == "2":
            cfg["pcap_mode"] = "tcpdump"
            print("  Using tcpdump mode. The agent will auto-install tcpdump if needed.")
        else:
            cfg["pcap_mode"] = "scapy"

    save_config(config_path, cfg)
    print(f"\n  Config written to {config_path}")
    print(f"  Node UUID: {cfg['node_uuid']}\n")


# ---------------------------------------------------------------------------
# CLI: Install systemd service
# ---------------------------------------------------------------------------

SYSTEMD_UNIT = """[Unit]
Description=Flowtriq DDoS Detection Agent
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/usr/bin/python3 {script_path}
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target
"""


def install_service() -> None:
    script = os.path.abspath(__file__)
    unit = SYSTEMD_UNIT.format(script_path=script)
    svc_path = "/etc/systemd/system/ftagent.service"
    try:
        with open(svc_path, "w") as f:
            f.write(unit)
        print(f"  Service file written to {svc_path}")
        os.system("systemctl daemon-reload")
        print("  Run: systemctl enable --now ftagent")
    except PermissionError:
        print("  Error: must run as root to install service.")
        sys.exit(1)


# ---------------------------------------------------------------------------
# CLI: Test connectivity
# ---------------------------------------------------------------------------

def test_connectivity(config_path: str) -> None:
    if not REQUESTS_AVAILABLE:
        print("  Error: 'requests' package is required. pip install requests")
        sys.exit(1)
    cfg = load_config(config_path)
    if not cfg["api_key"]:
        print("  Error: api_key not set. Run --setup first.")
        sys.exit(1)
    client = APIClient(cfg)
    print(f"  Testing connection to {cfg['api_base']} ...")
    if client.test_connectivity():
        ok = f"{Fore.GREEN}OK{Style.RESET_ALL}" if COLOR else "OK"
        print(f"  Connection: {ok}")
    else:
        fail = f"{Fore.RED}FAILED{Style.RESET_ALL}" if COLOR else "FAILED"
        print(f"  Connection: {fail}")
        sys.exit(1)


# ---------------------------------------------------------------------------
# Entrypoint
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description=f"Flowtriq DDoS Detection Agent v{VERSION}")
    parser.add_argument("--version", action="version",
                        version=f"ftagent {VERSION}")
    parser.add_argument("--config", default=CONFIG_PATH,
                        help="Path to config file")
    parser.add_argument("--setup", action="store_true",
                        help="Run interactive setup wizard")
    parser.add_argument("--test", action="store_true",
                        help="Test API connectivity")
    parser.add_argument("--install-service", action="store_true",
                        help="Install systemd service unit")
    parser.add_argument("--update", action="store_true",
                        help="Check for and install agent updates")
    parser.add_argument("--no-update-check", action="store_true",
                        help="Skip automatic update check on startup")
    args = parser.parse_args()

    if args.update:
        check_for_updates(force=True, interactive=True)
        return

    if args.setup:
        setup_wizard(args.config)
        return

    if args.install_service:
        install_service()
        return

    if not REQUESTS_AVAILABLE:
        print("Error: 'requests' package is required. pip install requests")
        sys.exit(1)

    cfg = load_config(args.config)
    cfg["_config_path"] = args.config  # pass through so PcapCapture can reference it
    setup_logging(cfg["log_file"], cfg["log_level"])

    if args.test:
        test_connectivity(args.config)
        return

    if not cfg["api_key"]:
        logger.error("No api_key configured. Run: ftagent --setup")
        sys.exit(1)

    if not cfg["node_uuid"]:
        logger.error("No node_uuid configured. Set it to the Node UUID from your Flowtriq dashboard. Run: ftagent --setup")
        sys.exit(1)

    # Check for updates on startup (non-blocking, logs only)
    if not args.no_update_check:
        check_for_updates(force=False, interactive=False)

    agent = Agent(cfg)
    agent.run()


if __name__ == "__main__":
    main()
