"""TestMu binding for Playwright Python.

Public API:
    testmu.test          — decorator for test functions
    testmu.step(...)     — step context manager
    testmu.run(fn)       — session lifecycle runner
    var(template)        — variable/template resolver
    set_var(name, value) — store variable
    expect               — PW expect with custom matchers
    testmu.<helper>(...)  — helper functions (execute_js, vision_query, etc.)
"""

from importlib.metadata import PackageNotFoundError, version as _pkg_version

try:
    __version__ = _pkg_version("testmuai-playwright-bindings")
except PackageNotFoundError:
    __version__ = "0.0.0+unknown"

# Load .env BEFORE any submodule import so module-level os.getenv() reads
# (in _config, _helpers/vision, etc.) see values from a developer's local
# .env file. On HyperExecute env vars are injected by the platform, so
# python-dotenv is absent there and this is a no-op.
try:
    from dotenv import load_dotenv as _load_dotenv
    _load_dotenv()
except ImportError:
    pass

from testmu._configure import configure
from testmu._decorator import test
from testmu._step import step
from testmu._session import run
from testmu._vars import var, set_var
from testmu._matchers import expect
from testmu._errors import TestmuConfigError

# Helpers — vision functions ported; remaining stubs will be replaced in Layer B
from testmu._helpers import (
    execute_js,
    execute_api,
    execute_db,
    vision_query,
    textual_query,
    vision_wait,
    vision_action,
    verify_assertion,
    evaluate_branch,
    network_query,
    evaluate_network_assertion,
    evaluate_math,
    smartui_snapshot,
    switch_tab,
    click_drag,
    execute_kane_cli,
    check_until_condition,
    get_vision_coordinates,
)

# Install PW-specific heal patch
import testmu.playwright_async  # noqa: F401 — triggers _install_heal()

__all__ = [
    "__version__",
    "configure",
    "test",
    "step",
    "run",
    "var",
    "set_var",
    "expect",
    "execute_js",
    "execute_api",
    "execute_db",
    "vision_query",
    "textual_query",
    "vision_wait",
    "vision_action",
    "verify_assertion",
    "evaluate_branch",
    "network_query",
    "evaluate_network_assertion",
    "evaluate_math",
    "smartui_snapshot",
    "switch_tab",
    "click_drag",
    "execute_kane_cli",
    "check_until_condition",
    "get_vision_coordinates",
    "TestmuConfigError",
]
