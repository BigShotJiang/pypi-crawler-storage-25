"""Heal patch for Playwright Locator methods.

Installs wrappers on Locator action methods that catch TimeoutError
(element not found) and attempt heal via a pluggable heal function.

The patch only fires inside a testmu.step() block (ContextVar check).
Outside a step, the wrapper is a pure passthrough.

heal_fn contract:
    async def heal_fn(page, description, method_name, *args, **kwargs) -> bool

    Returns True if heal handled the action (wrapper returns normally).
    Returns False if heal couldn't help (wrapper re-raises original error).

    Today's default heal does a coordinate lookup via vision API and clicks
    at the returned coordinates for click/hover methods. Other methods are
    not supported until locator re-resolution lands.
"""
import functools
import logging
from testmu._step import _current_step
from testmu._heal_cache import get_cache

_log = logging.getLogger("testmu")

# Resolve Playwright's TimeoutError once at import time. Playwright raises
# `playwright.async_api.TimeoutError` (a subclass of Playwright's internal
# Error, NOT of Python's built-in TimeoutError) when a Locator action's
# auto-wait expires. Catch both so unit tests using the built-in keep
# working alongside real PW calls.
try:
    from playwright.async_api import TimeoutError as _PWTimeoutError
    _TIMEOUT_EXCS: tuple = (_PWTimeoutError, TimeoutError)
except ImportError:
    _TIMEOUT_EXCS = (TimeoutError,)

_originals = {}


def install(target_class, method_names, heal_fn):
    """Patch methods on target_class with heal-on-failure behavior.

    Skips methods missing from the class and methods already wrapped.
    Each method's install is independent — one failure doesn't stop the rest.
    """
    for name in method_names:
        try:
            original = getattr(target_class, name, None)
            if original is None:
                _log.debug("heal patch: %s.%s not present, skipping", target_class.__name__, name)
                continue
            if getattr(original, "_testmu_heal_wrapped", False):
                continue  # idempotent — re-import won't double-wrap
            wrapper = _make_wrapper(name, original, heal_fn)
            wrapper._testmu_heal_wrapped = True
            _originals[(target_class, name)] = original
            setattr(target_class, name, wrapper)
        except Exception as e:
            _log.warning("heal patch: failed to wrap %s.%s (%s) — skipping", target_class.__name__, name, e)


def uninstall(target_class, method_names):
    """Restore original methods."""
    for name in method_names:
        key = (target_class, name)
        original = _originals.pop(key, None)
        if original is not None:
            setattr(target_class, name, original)


def _make_wrapper(name, original, heal_fn):
    @functools.wraps(original)
    async def wrapper(self, *args, **kwargs):
        step = _current_step.get()
        if step is None:
            return await original(self, *args, **kwargs)

        # Cache fast-path: this locator was already remapped in this step.
        cache = get_cache()
        if cache is not None:
            try:
                cached = cache.get(self)
            except TypeError:
                cached = None  # locator class lacks weakref support
            if cached is not None:
                # Positive entry: skip stale, run on fresh.
                fresh = self.page.locator(cached)
                return await original(fresh, *args, **kwargs)
            elif self in cache:
                # Negative entry: heal already missed for this locator. Run
                # the original so the user sees PW's real diagnostic.
                return await original(self, *args, **kwargs)

        try:
            return await original(self, *args, **kwargs)
        except _TIMEOUT_EXCS:
            if await self.count() > 0:
                raise  # element exists but not actionable — heal won't help
            handled = await heal_fn(
                self.page, step.description, name, self, *args, **kwargs
            )
            if not handled:
                raise

    return wrapper
