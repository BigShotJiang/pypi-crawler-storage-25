"""@testmu.test decorator.

Wraps test functions for lifecycle reporting:
- begin_test / pass_test / fail_test
- screenshot on failure (best-effort)

Does NOT own browser launch (that's testmu.run).
Does NOT override PW methods (that's the heal patch).
"""
import asyncio
import functools

from testmu._reporter import reporter


def _find_page(args, kwargs):
    """Extract the page argument from args/kwargs."""
    if "page" in kwargs:
        return kwargs["page"]
    for arg in args:
        if hasattr(arg, "screenshot") and hasattr(arg, "locator"):
            return arg
    return None


def test(fn):
    if asyncio.iscoroutinefunction(fn):
        @functools.wraps(fn)
        async def async_wrapper(*args, **kwargs):
            rep = reporter()
            await rep.begin_test(fn.__name__)
            try:
                result = await fn(*args, **kwargs)
                await rep.pass_test()
                return result
            except Exception as e:
                # Screenshot-on-failure disabled — attach_screenshot is a stub
                # that doesn't upload bytes anywhere. Re-enable once LT CDP upload
                # is wired up.
                # page = _find_page(args, kwargs)
                # if page is not None:
                #     try:
                #         screenshot = await page.screenshot()
                #         await rep.attach_screenshot(screenshot)
                #     except Exception:
                #         pass
                await rep.fail_test(e)
                raise
        return async_wrapper
    else:
        @functools.wraps(fn)
        def sync_wrapper(*args, **kwargs):
            raise NotImplementedError(
                "Sync test functions are not yet supported. Use 'async def'."
            )
        return sync_wrapper
