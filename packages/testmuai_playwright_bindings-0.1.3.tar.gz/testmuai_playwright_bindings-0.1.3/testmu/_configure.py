"""Export-time configuration for testmu.

testmu.configure() is called at the top of generated test files to
pass values that were known at export time (test name, build ID,
variables, chrome options, etc.) into the binding runtime.

This replaces the old pattern of baking values into capability.py
and test.py as string literals.
"""
import logging

_log = logging.getLogger("testmu")

# All config fields with defaults
_config_data = {
    "build": "",
    "name": "",
    "tc_id": "",
    "network": False,
    "timezone": "",
    "chrome_options": [],
    "custom_headers": {},
    "multiple_profiles": False,
    "variables": {},
    "test_params": {},
    "global_variables": [],
    "uploaded_files": [],
    "environment_id": 0,
}

# Keys explicitly set via configure() — used to distinguish "not configured"
# from "configured to the default value" (important for bool fields).
_configured_keys: set = set()


def configure(**kwargs):
    """Set export-time configuration values.

    Called once at the top of generated test files before @testmu.test.
    Values are consumed by _capability.py, _vars.py, and _session.py.
    """
    for key, value in kwargs.items():
        if key not in _config_data:
            _log.warning(f"testmu.configure: unknown key '{key}', ignoring")
            continue
        _config_data[key] = value
        _configured_keys.add(key)

    # Populate variable stores immediately
    from testmu._vars import set_var, _test_params, _global_variables
    for var_name, var_value in _config_data.get("variables", {}).items():
        set_var(var_name, var_value)
    _test_params.update(_config_data.get("test_params", {}))
    _global_variables.clear()
    _global_variables.extend(_config_data.get("global_variables", []))


def get(key, default=None):
    """Read a config value."""
    return _config_data.get(key, default)


def was_set(key) -> bool:
    """Return True if key was explicitly passed to configure()."""
    return key in _configured_keys


def _reset():
    """Reset all config and variable stores (for testing)."""
    for key in _config_data:
        if isinstance(_config_data[key], dict):
            _config_data[key] = {}
        elif isinstance(_config_data[key], list):
            _config_data[key] = []
        elif isinstance(_config_data[key], bool):
            _config_data[key] = False
        else:
            _config_data[key] = ""
    _configured_keys.clear()
    # Also reset variable stores populated by configure()
    from testmu._vars import _reset_store
    _reset_store()
