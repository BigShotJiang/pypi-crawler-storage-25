import logging

_log = logging.getLogger("testmu")


async def switch_tab(context, tab_index):
    """Switch to a browser tab by 0-based index, waiting if needed.

    If the tab doesn't exist yet (e.g. click opened target="_blank"),
    waits for the CDP page creation event before switching.
    """
    pages = context.pages
    _log.info("    [switch_tab] target_index=%d current_tabs=%d", tab_index, len(pages))
    if tab_index >= len(pages):
        try:
            # Tab not in list yet — wait for CDP Target.targetCreated
            await context.wait_for_event("page", timeout=5000)
        except Exception:
            pass  # Playwright TimeoutError isn't Python's built-in TimeoutError
        pages = context.pages
    if tab_index >= len(pages):
        raise ValueError(f"Tab {tab_index} does not exist ({len(pages)} tabs open)")
    page = pages[tab_index]
    await page.bring_to_front()
    _log.info("    [switch_tab] switched to tab %d (url=%s)", tab_index, page.url)
    return page
