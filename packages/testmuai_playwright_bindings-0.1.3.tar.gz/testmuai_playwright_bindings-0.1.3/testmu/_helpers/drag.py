import logging

_log = logging.getLogger("testmu")


async def click_drag(page, x1, y1, x2, y2, steps=20):
    """Perform click-and-drag from start to end coordinates with intermediate steps."""
    _log.info("    [click_drag] (%d, %d) → (%d, %d) over %d steps", x1, y1, x2, y2, steps)
    await page.mouse.move(x1, y1)
    await page.mouse.down()
    await page.mouse.move(x2, y2, steps=steps)
    await page.mouse.up()
    _log.info("    [click_drag] completed")
