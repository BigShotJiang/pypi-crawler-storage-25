"""Assertion and branch evaluation helpers.

Two helpers:
    verify_assertion(page, claim, assertion_tree) → dict
    evaluate_branch(sub_checks, composite_operator) → bool

Each has two internal paths:
- Deterministic (store_key present in sub_checks, or evaluate_branch): resolves
  variables from _variable_store and calls POST /api/v1/evaluate.
- Visual (no store_key, verify_assertion only): takes a screenshot and calls
  POST /api/v1/assertions/verify — only runs when smart mode is ON.

When smart is OFF verify_assertion always takes the deterministic path even if
there are no store_keys (skips the visual fallback).
"""
import base64
import logging
import os

import aiohttp

from testmu._helpers._http import create_session

_AI_API_HOST = os.getenv("TESTMU_AI_API_HOST", "https://kaneai-api.lambdatest.com/v16-server")

from testmu import _config
from testmu._vars import _variable_store, var

_log = logging.getLogger("testmu")


async def _resolve(text):
    """Resolve {{...}} / ${...} placeholders via testmu.var()."""
    if isinstance(text, str) and ("{{" in text or "${" in text):
        try:
            resolved = var(text)
            if resolved is None:
                return text
            return str(resolved)
        except Exception:
            return text
    return text if text is not None else ""


def _build_eval_sub_checks(sub_checks):
    """Return a coroutine that resolves sub_checks fields (helper for reuse)."""
    return sub_checks  # actual resolution is async — see _resolve_sub_checks


async def _resolve_sub_checks(sub_checks):
    """Resolve variable placeholders in each sub_check dict."""
    result = []
    for sc in sub_checks:
        # V16 SubCheckResult uses "expected"; legacy uses "expected_value"
        # Coerce None → "" since /api/v1/evaluate requires non-null strings
        raw_expected = sc.get("expected_value") or sc.get("expected") or ""
        raw_description = sc.get("description") or ""
        raw_extracted = sc.get("extracted_value") or ""
        result.append({
            "description": await _resolve(raw_description),
            "expected_value": await _resolve(raw_expected),
            "extracted_value": await _resolve(raw_extracted),
            "operator": sc.get("operator") or "contains",
            "transforms": sc.get("transforms") or ["strip"],
        })
    return result


async def _call_evaluate_api(claim, composite_op, eval_sub_checks):
    """POST /api/v1/evaluate and return the result dict."""
    request_body = {
        "claim": claim,
        "composite_operator": composite_op,
        "sub_checks": eval_sub_checks,
    }
    async with create_session() as session:
        async with session.post(
            f"{_AI_API_HOST}/api/v1/evaluate",
            json=request_body,
            timeout=aiohttp.ClientTimeout(total=60),
        ) as response:
            if response.status != 200:
                text = await response.text()
                raise Exception(f"Evaluate API error {response.status}: {text}")
            return await response.json()


async def _evaluate_deterministic(claim, composite_op, sub_checks):
    """Deterministic path: resolve variables then call /api/v1/evaluate."""
    _log.info("    [assertion] deterministic claim=%s", claim[:80])
    eval_sub_checks = await _resolve_sub_checks(sub_checks)
    result = await _call_evaluate_api(claim, composite_op, eval_sub_checks)
    _log.info("    [assertion] result status=%s", result.get("status", "unknown"))
    return result


async def _verify_visual(page, claim, composite_op, sub_checks, assertion_tree):
    """Visual path: screenshot + LLM-based assertion via /api/v1/assertions/verify."""
    _log.info("    [assertion] visual claim=%s", claim[:80])

    screenshot_bytes = await page.screenshot()
    screenshot_b64 = base64.b64encode(screenshot_bytes).decode("utf-8")
    current_url = page.url

    verification = (assertion_tree or {}).get("verification")
    request_body = {
        "screenshot_b64": screenshot_b64,
        "claim": claim,
        "current_url": current_url,
        "composite_operator": composite_op,
        "sub_checks": sub_checks,
        "step": 0,
    }
    if verification:
        request_body["verification"] = verification

    async with create_session() as session:
        async with session.post(
            f"{_AI_API_HOST}/api/v1/assertions/verify",
            json=request_body,
            timeout=aiohttp.ClientTimeout(total=60),
        ) as response:
            if response.status != 200:
                text = await response.text()
                raise Exception(f"Assertion API error {response.status}: {text}")
            result = await response.json()

    _log.info("    [assertion] result status=%s", result.get("status", "unknown"))
    return result


async def verify_assertion(page, claim: str, assertion_tree: dict = None) -> dict:
    """Verify an assertion.

    Two paths:
    1. Deterministic (store_key present in sub_checks OR smart mode is OFF):
       Resolves variables from _variable_store, calls POST /api/v1/evaluate.
    2. Visual (no store_key AND smart mode is ON): Takes screenshot, calls
       POST /api/v1/assertions/verify (LLM-based).

    Args:
        page: Playwright page object.
        claim: Assertion description.
        assertion_tree: Dict with sub_checks, claim, composite_operator.

    Returns:
        dict with status ("passed"/"failed") and sub_results.
    """
    sub_checks = (assertion_tree or {}).get("sub_checks", [])
    composite_op = (assertion_tree or {}).get("composite_operator", "and")
    assertion_claim = (assertion_tree or {}).get("claim", claim)

    has_store_keys = any(sc.get("store_key") for sc in sub_checks)

    # Deterministic path: store_keys present, or smart is OFF (no vision available)
    if has_store_keys or not _config.smart:
        return await _evaluate_deterministic(assertion_claim, composite_op, sub_checks)

    # Visual path: smart mode ON, no store_keys → screenshot-based verification
    return await _verify_visual(page, assertion_claim, composite_op, sub_checks, assertion_tree)


async def evaluate_branch(sub_checks: list, composite_operator: str = "and") -> bool:
    """Evaluate a conditional branch's sub_checks via /api/v1/evaluate.

    Resolves {{var}} and ${param} references in description, expected_value,
    and extracted_value from testmu._vars._variable_store, then calls
    POST /api/v1/evaluate.

    Args:
        sub_checks: List of dicts with description, expected_value,
            extracted_value, operator, transforms.
        composite_operator: "and" or "or" for combining sub_check results.

    Returns:
        True if the branch condition is satisfied, False otherwise.
    """
    _log.info("[if/else] evaluating %s of %d sub-check(s)",
              composite_operator, len(sub_checks))

    eval_sub_checks = await _resolve_sub_checks(sub_checks)

    if not eval_sub_checks:
        _log.info("[if/else] result=False (no valid sub-checks) → taking false branch")
        return False

    result = await _call_evaluate_api(
        f"Branch condition ({composite_operator})",
        composite_operator,
        eval_sub_checks,
    )

    passed = result.get("status") == "passed"
    _log.info("[if/else] result=%s → taking %s branch",
              passed, "true" if passed else "false")
    return passed
