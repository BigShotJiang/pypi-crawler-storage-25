"""Step context manager for testmu.

Dual-protocol: supports both `with testmu.step(...)` (sync) and
`async with testmu.step(...)` (async). Sets a ContextVar that the
heal patch reads to get the step description.

The async path calls reporter.begin_step/end_step.
The sync path does not (no async context available for page.evaluate).
"""
import contextvars

from testmu._heal_cache import set_cache, reset_cache, new_cache

_current_step = contextvars.ContextVar("testmu_step", default=None)


class _Step:
    __slots__ = ("description", "timeout_ms", "on_failure", "_token", "_cache_token")

    def __init__(self, description, timeout_ms=None, on_failure=None):
        self.description = description
        self.timeout_ms = timeout_ms
        self.on_failure = on_failure
        self._token = None
        self._cache_token = None

    # ── Sync protocol (no reporter — no async context available) ──

    def __enter__(self):
        self._token = _current_step.set(self)
        self._cache_token = set_cache(new_cache())
        return self

    def __exit__(self, exc_type, exc_val, tb):
        if self._cache_token is not None:
            reset_cache(self._cache_token)
            self._cache_token = None
        if self._token is not None:
            _current_step.reset(self._token)
            self._token = None
        if exc_type is not None and self.on_failure == "continue":
            return True  # suppress exception
        return False

    # ── Async protocol (with reporter) ──

    async def __aenter__(self):
        self._token = _current_step.set(self)
        self._cache_token = set_cache(new_cache())
        from testmu._reporter import reporter
        await reporter().begin_step(self.description)
        return self

    async def __aexit__(self, exc_type, exc_val, tb):
        from testmu._reporter import reporter
        await reporter().end_step(self.description, ok=exc_type is None, error=exc_val)
        if self._cache_token is not None:
            reset_cache(self._cache_token)
            self._cache_token = None
        if self._token is not None:
            _current_step.reset(self._token)
            self._token = None
        if exc_type is not None and self.on_failure == "continue":
            return True  # suppress exception
        return False


def step(description, timeout_ms=None, on_failure=None):
    return _Step(description, timeout_ms=timeout_ms, on_failure=on_failure)
