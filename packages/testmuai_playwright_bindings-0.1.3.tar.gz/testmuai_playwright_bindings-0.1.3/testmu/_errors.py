"""Testmu exception classes."""


class TestmuConfigError(Exception):
    """Raised when a required configuration is missing (no LT creds, no env fallback)."""
    pass
