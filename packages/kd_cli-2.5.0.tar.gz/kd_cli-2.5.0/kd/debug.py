"""Progressive debug logging.

Three verbosity levels via stacking ``-D`` flags:

- ``-D``   (info):  high-level flow — config source, API status, item count
- ``-DD``  (debug): request details, config chain, retries, elapsed timestamps
- ``-DDD`` (trace): full bodies, headers, per-source walk, correlation ID

All output goes to **stderr** so stdout remains pipeable.
"""

from __future__ import annotations

import sys
import time
import uuid
from enum import IntEnum


class DebugLevel(IntEnum):
    """Verbosity levels for diagnostic output."""

    SILENT = 0
    INFO = 1
    DEBUG = 2
    TRACE = 3


class DebugLog:
    """Component-tagged diagnostic logger writing to stderr.

    Create once per invocation and thread through the call stack
    or retrieve via :func:`get_debug_log`.
    """

    def __init__(self, level: DebugLevel = DebugLevel.SILENT) -> None:
        self._level = level
        self._start = time.monotonic()
        self._correlation_id = uuid.uuid4().hex[:8]

    @property
    def level(self) -> DebugLevel:
        """Current verbosity level (read-only)."""
        return self._level

    def info(self, component: str, message: str) -> None:
        """Emit at level 1 (info) — high-level flow."""
        if self._level >= DebugLevel.INFO:
            self._emit("info", component, message)

    def debug(self, component: str, message: str) -> None:
        """Emit at level 2 (debug) — request details, config chain."""
        if self._level >= DebugLevel.DEBUG:
            self._emit("debug", component, message)

    def trace(self, component: str, message: str) -> None:
        """Emit at level 3 (trace) — full bodies, headers, walk."""
        if self._level >= DebugLevel.TRACE:
            self._emit("trace", component, message)

    def _emit(self, level: str, component: str, message: str) -> None:
        parts: list[str] = [f"[{level:<5}]", f"({component})"]
        if self._level >= DebugLevel.TRACE:
            parts.append(f"[{self._correlation_id}]")
        if self._level >= DebugLevel.DEBUG:
            elapsed = time.monotonic() - self._start
            parts.append(f"+{elapsed:.1f}s")
        parts.append(message)
        print("  ".join(parts), file=sys.stderr)


def redact_token(token: str) -> str:
    """Redact an API token for debug display.

    Shows the first 8 characters followed by ``***``.
    Short or empty tokens become just ``***``.
    """
    if len(token) >= 8:
        return token[:8] + "***"
    return "***"


# ── Module-level singleton ──────────────────────────────────────────

_log: DebugLog | None = None


def init_debug_log(level: DebugLevel) -> DebugLog:
    """Create and store the module-level :class:`DebugLog`.

    Called once from ``main()`` after parsing the ``-D`` flags.
    Returns the new instance for explicit threading.
    """
    global _log  # noqa: PLW0603
    _log = DebugLog(level)
    return _log


def get_debug_log() -> DebugLog:
    """Return the module-level :class:`DebugLog`.

    Returns a silent (level 0) instance when :func:`init_debug_log`
    has not been called — callers never need to guard against ``None``.
    """
    if _log is not None:
        return _log
    return DebugLog()
