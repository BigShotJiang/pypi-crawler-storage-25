"""Operating guide loader.

Reads the bundled ``kd/resources/operating-guide.md`` for ``kd --guide``.
The guide carries durable operating doctrine (product boundary, primer
workflow, cost classes, YouTrack gotchas) — a complement to the
syntax-focused ``kd --reference``.
"""

from __future__ import annotations

import importlib.resources


def load_guide() -> str:
    """Read the bundled operating guide as text."""
    return (
        importlib.resources.files("kd.resources")
        .joinpath("operating-guide.md")
        .read_text(encoding="utf-8")
    )
