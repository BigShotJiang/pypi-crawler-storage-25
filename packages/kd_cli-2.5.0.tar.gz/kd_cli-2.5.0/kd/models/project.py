"""Project models."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field

from kd.models.common import IdEntity, NamedEntity


class Project(IdEntity):
    """Full project representation."""

    name: str
    short_name: str = Field(alias="shortName")
    description: str | None = None
    archived: bool = False
    ring_id: str | None = Field(default=None, alias="ringId")
    leader: NamedEntity | None = None


class BundleValue(BaseModel):
    """A single allowed value within an enum or state bundle."""

    model_config = ConfigDict(populate_by_name=True)

    name: str
    ordinal: int = 0
    is_resolved: bool | None = Field(default=None, alias="isResolved")


class ProjectCustomField(BaseModel):
    """Custom field attached to a project (flattened from nested API shape).

    Constructed by the SDK from the raw API response, not parsed directly.
    """

    name: str
    field_type_id: str
    project_field_type: str
    can_be_empty: bool = True
    empty_field_text: str | None = None
    bundle_values: list[BundleValue] = Field(default_factory=list)


class ProjectCreate(BaseModel):
    """Input for creating a project."""

    model_config = ConfigDict(populate_by_name=True)

    name: str
    short_name: str = Field(alias="shortName")
    leader: IdEntity | None = None  # Create only needs id


class TimeTrackingSettings(BaseModel):
    """Time tracking configuration per project."""

    model_config = ConfigDict(populate_by_name=True)

    enabled: bool = False
