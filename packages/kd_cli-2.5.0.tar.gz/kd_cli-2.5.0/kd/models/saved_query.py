"""Saved query models."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict

from kd.models.common import IdEntity, NamedEntity


class SavedQuery(IdEntity):
    """YouTrack saved query (saved search).

    Minimal field set: id, name, query text, owner reference. Sharing settings
    (``readSharingSettings`` / ``updateSharingSettings``) are intentionally
    excluded from the default field parameter — personal CRUD works without
    them, and modelling them pulls in a permissions surface that belongs to
    a future milestone.
    """

    name: str
    query: str
    owner: NamedEntity | None = None


class SavedQueryCreate(BaseModel):
    """Input for creating a saved query."""

    model_config = ConfigDict(populate_by_name=True)

    name: str
    query: str


class SavedQueryUpdate(BaseModel):
    """Partial update for a saved query.

    All fields optional. Dump with ``exclude_none=True`` so the POST body only
    carries the fields the caller actually wants to change; YouTrack preserves
    omitted fields.
    """

    model_config = ConfigDict(populate_by_name=True)

    name: str | None = None
    query: str | None = None


class QueryValidationResult(BaseModel):
    """Result of validating a query string against the YouTrack search API."""

    valid: bool
    query: str
    error: str | None = None
    suggestion: str | None = None
