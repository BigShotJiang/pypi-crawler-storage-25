"""Pydantic models for YouTrack entities.

All models use field aliases to map between Python snake_case
and YouTrack's camelCase API responses.
"""

from kd.models.article import Article, ArticleCreate, ArticleRef, ArticleUpdate
from kd.models.assist import AssistResponse, AssistSuggestion
from kd.models.attachment import Attachment
from kd.models.comment import Comment, CommentCreate
from kd.models.common import FieldSet, IdEntity, NamedEntity
from kd.models.issue import CustomField, Issue, IssueCreate, IssueUpdate
from kd.models.project import (
    BundleValue,
    Project,
    ProjectCreate,
    ProjectCustomField,
    TimeTrackingSettings,
)
from kd.models.saved_query import (
    QueryValidationResult,
    SavedQuery,
    SavedQueryCreate,
    SavedQueryUpdate,
)
from kd.models.search import SearchResult
from kd.models.tag import Tag, TagColor, TagCreateResult
from kd.models.tag_entities import EntityRef, KindMeta, TagEntitiesResult
from kd.models.user import Group, ProjectTeam, User, UserCreate
from kd.models.work_item import (
    Duration,
    WorkItem,
    WorkItemCreate,
    WorkItemType,
    WorkItemUpdate,
)

__all__ = [
    "Article",
    "ArticleCreate",
    "ArticleRef",
    "ArticleUpdate",
    "AssistResponse",
    "AssistSuggestion",
    "Attachment",
    "BundleValue",
    "Comment",
    "CommentCreate",
    "CustomField",
    "Duration",
    "EntityRef",
    "FieldSet",
    "Group",
    "IdEntity",
    "NamedEntity",
    "Issue",
    "IssueCreate",
    "IssueUpdate",
    "KindMeta",
    "QueryValidationResult",
    "Project",
    "ProjectCreate",
    "ProjectCustomField",
    "ProjectTeam",
    "SavedQuery",
    "SavedQueryCreate",
    "SavedQueryUpdate",
    "SearchResult",
    "Tag",
    "TagColor",
    "TagCreateResult",
    "TagEntitiesResult",
    "TimeTrackingSettings",
    "User",
    "UserCreate",
    "WorkItem",
    "WorkItemCreate",
    "WorkItemType",
    "WorkItemUpdate",
]
