"""Issue models."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from kd.models.attachment import Attachment
from kd.models.comment import Comment
from kd.models.common import IdEntity, NamedEntity
from kd.models.tag import Tag


class CustomField(BaseModel):
    """Custom field value representation.

    ``value`` is Any because YouTrack custom fields can be dicts with
    a ``name`` key, primitives, or lists depending on field type.
    ``field_type`` serializes as ``$type`` — required by YouTrack for
    create/update operations on enum custom fields.
    """

    model_config = ConfigDict(populate_by_name=True)

    name: str
    value: Any = None
    field_type: str | None = Field(default=None, alias="$type")


class Issue(IdEntity):
    """Full issue representation.

    The ``comments``, ``links``, and ``attachments`` fields are populated
    only when a rich field set is requested from the API.
    """

    id_readable: str = Field(alias="idReadable")
    summary: str
    description: str | None = None
    project: NamedEntity | None = None
    reporter: NamedEntity | None = None
    created: int | None = None
    updated: int | None = None
    custom_fields: list[CustomField] = Field(default_factory=list, alias="customFields")
    comments: list[Comment] | None = None
    links: list[dict[str, Any]] | None = None
    attachments: list[Attachment] | None = None
    tags: list[Tag] = Field(default_factory=list)


class IssueCreate(BaseModel):
    """Input for creating an issue."""

    model_config = ConfigDict(populate_by_name=True)

    project: IdEntity
    summary: str
    description: str | None = None
    custom_fields: list[CustomField] | None = Field(default=None, alias="customFields")


class IssueUpdate(BaseModel):
    """Input for updating an issue."""

    model_config = ConfigDict(populate_by_name=True)

    summary: str | None = None
    description: str | None = None
    custom_fields: list[CustomField] | None = Field(default=None, alias="customFields")
