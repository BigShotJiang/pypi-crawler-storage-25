"""Attachment models."""

from __future__ import annotations

from pydantic import Field

from kd.models.common import IdEntity, NamedEntity


class Attachment(IdEntity):
    """Issue or article attachment metadata."""

    name: str
    size: int | None = None
    mime_type: str | None = Field(default=None, alias="mimeType")
    extension: str | None = None
    author: NamedEntity | None = None
    created: int | None = None
    updated: int | None = None
    url: str | None = None
