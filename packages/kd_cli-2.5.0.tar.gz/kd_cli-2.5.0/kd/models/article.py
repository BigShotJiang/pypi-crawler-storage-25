"""Article models."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field

from kd.models.common import IdEntity, NamedEntity
from kd.models.tag import Tag


class ArticleRef(IdEntity):
    """Lightweight cross-reference to an article.

    Carries ``id_readable`` because articles are addressed by their
    readable id (e.g. ``FB-A-1``) in the CLI. ``NamedEntity`` only has
    ``id`` and ``name`` and is reused for leaders, reporters, authors —
    entities that do not have a human-readable id — so a dedicated type
    keeps the shared base clean.
    """

    model_config = ConfigDict(populate_by_name=True)

    id_readable: str | None = Field(default=None, alias="idReadable")
    name: str | None = None


class Article(IdEntity):
    """Knowledge base article.

    The ``content`` field is populated only when detail fields are
    requested (get, create, update responses). List responses omit it
    to keep payloads lightweight.
    """

    id_readable: str = Field(alias="idReadable")
    summary: str
    content: str | None = None
    project: NamedEntity | None = None
    reporter: NamedEntity | None = None
    created: int | None = None
    updated: int | None = None
    has_children: bool = Field(default=False, alias="hasChildren")
    parent_article: ArticleRef | None = Field(default=None, alias="parentArticle")
    tags: list[Tag] = Field(default_factory=list)


class ArticleCreate(BaseModel):
    """Input for creating an article."""

    model_config = ConfigDict(populate_by_name=True)

    project: IdEntity
    summary: str
    content: str | None = None
    parent_article: IdEntity | None = Field(default=None, alias="parentArticle")


class ArticleUpdate(BaseModel):
    """Input for updating an article."""

    model_config = ConfigDict(populate_by_name=True)

    summary: str | None = None
    content: str | None = None
