"""Shared model types."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class IdEntity(BaseModel):
    """Base for all entities with an id field."""

    model_config = ConfigDict(populate_by_name=True)

    id: str


class NamedEntity(IdEntity):
    """Entity with id and name — used for nested references (leader, reporter, author)."""

    name: str | None = None


class FieldSet:
    """Helper for building YouTrack's explicit field selection strings.

    Usage::

        str(FieldSet("id", "name", leader=FieldSet("id", "name")))
        # => "id,name,leader(id,name)"
    """

    def __init__(self, *fields: str, **nested: FieldSet) -> None:
        self._fields = fields
        self._nested = nested

    def __str__(self) -> str:
        parts: list[str] = list(self._fields)
        for name, subset in self._nested.items():
            parts.append(f"{name}({subset})")
        return ",".join(parts)
