"""Search result model for cross-entity search."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class SearchResult(BaseModel):
    """Normalized result from cross-entity search.

    Each result carries a type discriminator so consumers can identify
    the source entity kind without inspecting the id format.
    """

    model_config = ConfigDict(populate_by_name=True)

    type: str
    id: str
    title: str
    project: str
