"""User models (Hub API entities)."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field

from kd.models.common import IdEntity, NamedEntity


class User(IdEntity):
    """User representation (works for both YT and Hub API responses)."""

    login: str
    name: str
    email: str | None = None
    ring_id: str | None = Field(default=None, alias="ringId")
    banned: bool = False
    guest: bool = False


class UserCreate(BaseModel):
    """Input for creating a user via Hub API."""

    model_config = ConfigDict(populate_by_name=True)

    login: str
    name: str
    email: str


class Group(IdEntity):
    """User group representation."""

    name: str
    users_count: int | None = Field(default=None, alias="usersCount")


class ProjectTeam(IdEntity):
    """Project team (auto-created group per project)."""

    name: str
    project: NamedEntity | None = None
