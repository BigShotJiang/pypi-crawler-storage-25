"""Query and command assist models.

Used for ``/api/search/assist`` and ``/api/commands/assist`` — YouTrack's
autocomplete helpers for search queries and issue-command strings.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field


class AssistSuggestion(BaseModel):
    """One suggestion returned by an assist endpoint.

    ``option`` is the replacement string; the caret position fields describe
    where the replacement should be inserted and which part of the current
    input it matched. ``prefix``/``suffix`` are the characters to wrap around
    ``option`` when inserting (e.g. ``{`` / ``}`` for project keys with
    spaces).
    """

    model_config = ConfigDict(populate_by_name=True)

    option: str
    description: str | None = None
    prefix: str | None = None
    suffix: str | None = None
    completion_start: int | None = Field(default=None, alias="completionStart")
    completion_end: int | None = Field(default=None, alias="completionEnd")
    matching_start: int | None = Field(default=None, alias="matchingStart")
    matching_end: int | None = Field(default=None, alias="matchingEnd")
    group: str | None = None


class AssistResponse(BaseModel):
    """Envelope returned by both assist endpoints.

    ``query`` and ``caret`` echo the caller's input when requested in the
    field set; ``commands/assist`` does not always return ``caret``. Both are
    optional to accommodate the partial shape.
    """

    model_config = ConfigDict(populate_by_name=True)

    query: str | None = None
    caret: int | None = None
    suggestions: list[AssistSuggestion] = Field(default_factory=list)
