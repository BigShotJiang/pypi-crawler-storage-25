"""Comment models."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict

from kd.models.common import IdEntity, NamedEntity


class Comment(IdEntity):
    """Issue or article comment."""

    model_config = ConfigDict(populate_by_name=True)

    text: str
    author: NamedEntity | None = None
    created: int | None = None
    updated: int | None = None
    pinned: bool | None = None


class CommentCreate(BaseModel):
    """Input for adding a comment."""

    text: str
