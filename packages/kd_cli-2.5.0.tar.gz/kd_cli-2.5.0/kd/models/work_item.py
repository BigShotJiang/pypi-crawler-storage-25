"""Work item (time tracking) models.

Note: REST API requires type ID, not name. The SDK resolves names to IDs.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field

from kd.models.common import IdEntity, NamedEntity


class WorkItemType(IdEntity):
    """Work item type (Development, Testing, Documentation, etc.)."""

    name: str
    auto_attached: bool = Field(default=False, alias="autoAttached")


class Duration(BaseModel):
    """Duration in minutes, matching the API's duration object."""

    model_config = ConfigDict(populate_by_name=True)

    minutes: int


class WorkItem(IdEntity):
    """Time entry on an issue."""

    model_config = ConfigDict(populate_by_name=True)

    duration: Duration
    text: str | None = None
    type: WorkItemType | None = None
    author: NamedEntity | None = None
    date: int | None = None


class WorkItemCreate(BaseModel):
    """Input for logging work."""

    model_config = ConfigDict(populate_by_name=True)

    duration: Duration
    text: str | None = None
    type: IdEntity | None = None
    date: int | None = None


class WorkItemUpdate(BaseModel):
    """Input for editing a work item. All fields optional."""

    model_config = ConfigDict(populate_by_name=True)

    duration: Duration | None = None
    text: str | None = None
    type: IdEntity | None = None
    date: int | None = None
