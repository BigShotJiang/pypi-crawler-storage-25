"""Release notes loader and parser.

Reads the bundled `kd/resources/CHANGELOG.md` (Keep-a-Changelog Lite)
and exposes slice helpers used by `kd /release-notes`.
"""

from __future__ import annotations

import importlib.resources
import re
from dataclasses import dataclass

from packaging.version import InvalidVersion, Version

_HEADER_RE = re.compile(
    r"^## \[(?P<version>[^\]]+)\](?:\s+[—-]\s+(?P<date>\d{4}-\d{2}-\d{2}))?\s*$",
    re.MULTILINE,
)


@dataclass(frozen=True)
class ReleaseSection:
    """One version's entry from the changelog.

    ``version`` is the literal bracket content (e.g. ``"2.1.0"`` or
    ``"Unreleased"``). ``date`` is the ISO date on the header or None.
    ``body`` is the markdown body as written, excluding the header line.
    """

    version: str
    date: str | None
    body: str


def load_changelog() -> str:
    """Read the bundled CHANGELOG.md as text."""
    return (
        importlib.resources.files("kd.resources")
        .joinpath("CHANGELOG.md")
        .read_text(encoding="utf-8")
    )


def parse_changelog(text: str) -> list[ReleaseSection]:
    """Split *text* into ReleaseSection entries in file order.

    Raises ValueError if the file has no version headers at all.
    """
    matches = list(_HEADER_RE.finditer(text))
    if not matches:
        raise ValueError("changelog has no version headers matching '## [X.Y.Z] — DATE'")

    sections: list[ReleaseSection] = []
    for i, match in enumerate(matches):
        start = match.end()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        body = text[start:end].strip("\n")
        sections.append(
            ReleaseSection(
                version=match.group("version"),
                date=match.group("date"),
                body=body,
            )
        )
    return sections


def get_version(sections: list[ReleaseSection], version: str) -> ReleaseSection | None:
    """Return the section with the given version literal, or None."""
    for section in sections:
        if section.version == version:
            return section
    return None


def filter_since(sections: list[ReleaseSection], since: str) -> list[ReleaseSection]:
    """Return sections strictly newer than *since*, excluding [Unreleased].

    Raises packaging.version.InvalidVersion if *since* is not a valid
    PEP 440 version string.
    """
    threshold = Version(since)
    out: list[ReleaseSection] = []
    for section in sections:
        if section.version == "Unreleased":
            continue
        try:
            v = Version(section.version)
        except InvalidVersion:
            continue
        if v > threshold:
            out.append(section)
    return out


def latest(sections: list[ReleaseSection]) -> ReleaseSection | None:
    """Return the first released section, skipping [Unreleased]."""
    for section in sections:
        if section.version != "Unreleased":
            return section
    return None


def render_section(section: ReleaseSection) -> str:
    """Render a section back to markdown, matching the source shape."""
    header = f"## [{section.version}]"
    if section.date:
        header += f" — {section.date}"
    if not section.body:
        return header
    return f"{header}\n\n{section.body}"
