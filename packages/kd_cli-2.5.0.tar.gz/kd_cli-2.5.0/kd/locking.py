"""Advisory file locking for read-modify-write transactions on kd-managed files.

Provides :func:`file_transaction` — a context manager that acquires an
exclusive advisory lock on a sidecar lockfile (``<path>.lock``) for the
duration of a load → mutate → save cycle.  Concurrent kd processes that
enter the same transaction serialize rather than clobber each other.

Design notes:

* **Sidecar lockfile, not the target file.**  Atomic writes elsewhere in
  kd use ``tempfile.mkstemp`` + ``os.replace``, which changes the target
  file's inode on every write.  Holding ``flock`` on the target inode
  would not protect a second writer that opens the freshly-replaced file.
  Locking a separate sidecar file that nobody rewrites keeps the lock
  stable across atomic replaces of the data file.

* **No unlink on release.**  Removing the lockfile after releasing the
  lock is a classic race: process B can open the doomed inode while
  process C creates a fresh one, and both end up holding "exclusive"
  locks on different inodes.  Empty sidecar files are cheap; leave them.

* **POSIX only.**  ``fcntl`` is imported lazily inside the context
  manager so that unrelated kd commands remain importable on Windows.
  On non-POSIX platforms, :func:`file_transaction` raises ``ConfigError``
  with a suggestion to run the command sequentially.

* **NFS caveat.**  ``flock`` on NFS has been unreliable historically.
  Modern Linux kernels implement it correctly, but operators using a
  networked ``$HOME`` should be aware that concurrency guarantees weaken.
  Local ``.kd/`` directories inside a repo are unaffected.
"""

from __future__ import annotations

import os
import sys
import time
from collections.abc import Generator
from contextlib import contextmanager
from pathlib import Path

from kd.exceptions import ConfigError

LOCK_SUFFIX = ".lock"
_POLL_INTERVAL_SECONDS = 0.05


@contextmanager
def file_transaction(path: Path, *, timeout: float = 30.0) -> Generator[None, None, None]:
    """Hold an exclusive advisory lock on ``<path>.lock`` for the ``with`` body.

    The sidecar lockfile is created if missing (``O_RDWR | O_CREAT``,
    never truncated).  Acquisition polls non-blocking ``flock`` until
    the lock is granted or *timeout* seconds elapse.  On timeout, raises
    :class:`ConfigError` naming the contested file.  The lockfile is
    intentionally left on disk after release.

    Raises :class:`ConfigError` on non-POSIX platforms.
    """
    if sys.platform == "win32":
        raise ConfigError(
            "File locking is not available on this platform (POSIX only).",
            suggestion="Run the kd command sequentially; concurrent mutations are not supported on Windows.",
        )

    import fcntl  # noqa: PLC0415 — lazy import keeps kd importable on Windows

    lock_path = path.with_name(path.name + LOCK_SUFFIX)
    lock_path.parent.mkdir(parents=True, exist_ok=True)

    fd = os.open(lock_path, os.O_RDWR | os.O_CREAT, 0o644)
    try:
        deadline = time.monotonic() + timeout
        while True:
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                if time.monotonic() >= deadline:
                    raise ConfigError(
                        f"Another kd process is writing to {path}; retry in a moment.",
                        suggestion=f"If no other kd process is running, remove the stale lockfile: {lock_path}",
                    ) from None
                time.sleep(_POLL_INTERVAL_SECONDS)

        try:
            yield
        finally:
            try:
                fcntl.flock(fd, fcntl.LOCK_UN)
            except OSError:
                pass
    finally:
        try:
            os.close(fd)
        except OSError:
            pass
