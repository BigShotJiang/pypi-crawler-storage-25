"""Output formatting.

Renders command results in multiple formats:
- table: human-readable tabular output (unconditional default)
- json: JSON output for piping to jq
- yaml: YAML output
- md: Markdown table

Default is ``table`` regardless of stdout context; TTY state does not
influence format (ADR-006 — TTY detection stays config-first). Consumers
that want JSON or YAML pass ``-o json`` / ``-o yaml`` explicitly.

Value normalization runs before serialization: epoch-ms timestamps become
ISO 8601, enums become their ``.value``, and nested collections render
cleanly in every format.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any

import yaml
from tabulate import tabulate

from kd.cli.core.command_base import CommandResult
from kd.cli.tree import TreeNode, render_tree

# Fields whose int values are Unix-epoch milliseconds.
TIMESTAMP_FIELDS = frozenset({"created", "updated", "resolved"})

# Fields whose int values are epoch-ms but semantically a date (no time component).
DATE_FIELDS = frozenset({"date"})

# Threshold: timestamps below this are normal ints, not epoch-ms.
# 1_000_000_000_000 ms ≈ 2001-09-09 — all YouTrack timestamps exceed this.
_EPOCH_MS_FLOOR = 1_000_000_000_000

# Detail-table scalars longer than this (or containing newlines) render as
# separate unindented blocks rather than being padded into the key column by
# tabulate. 80 matches the common terminal width; shorter values fit inline
# without padding damage.
_LONG_TEXT_THRESHOLD = 80


def _is_long_text(value: Any) -> bool:
    """Detect scalar strings that should render as their own block."""
    return isinstance(value, str) and ("\n" in value or len(value) > _LONG_TEXT_THRESHOLD)


def emit_warning(code: str, message: str, **context: Any) -> dict[str, Any]:
    """Build a warning entry for the command-result envelope.

    Shape: ``{code, message, context}``.  Callers attach the returned dict
    to a ``warnings: list[...]`` key on the command's result dict.  Table
    and markdown render each warning as ``warning [<code>]: <message>``
    after the normal output block; JSON and YAML pass the list through
    unchanged.  Exit status stays 0 — warnings are advisory, not failures.
    """
    entry: dict[str, Any] = {"code": code, "message": message}
    if context:
        entry["context"] = context
    return entry


def _format_timestamp(epoch_ms: int) -> str:
    """Convert Unix-epoch milliseconds to ``YYYY-MM-DD HH:MM UTC``."""
    dt = datetime.fromtimestamp(epoch_ms / 1000, tz=timezone.utc)
    return dt.strftime("%Y-%m-%d %H:%M UTC")


def _format_date(epoch_ms: int) -> str:
    """Convert Unix-epoch milliseconds to ``YYYY-MM-DD`` (UTC)."""
    dt = datetime.fromtimestamp(epoch_ms / 1000, tz=timezone.utc)
    return dt.strftime("%Y-%m-%d")


class OutputFormatter:
    """Formats CommandResult for display."""

    def format(
        self,
        data: CommandResult,
        fmt: str | None = None,
        fields: str | None = None,
        display_hint: str | None = None,
    ) -> str:
        """Format data for output.

        Args:
            data: Structured data from a command.
            fmt: Output format. Defaults to ``"table"`` when None; TTY state
                does not influence the default (ADR-006).
            fields: Comma-separated field names to include.
            display_hint: Rendering hint from the command (e.g. ``"tree"``).
        """
        if data is None:
            return ""
        if isinstance(data, str):
            return data

        normalized: list[dict[str, Any]] | dict[str, Any] = self._normalize(data)

        if fmt is None:
            fmt = "table"

        # Warnings envelope: commands attach a ``warnings`` list to advise the
        # user without failing.  Table/md pull it out and render each warning
        # as a trailing ``warning [<code>]: <message>`` line; json/yaml pass
        # the field through unchanged so structured consumers can read it.
        warnings_suffix = ""
        if (
            isinstance(normalized, dict)
            and isinstance(normalized.get("warnings"), list)
            and fmt in ("table", "md")
        ):
            warnings_list = normalized.pop("warnings")
            warnings_suffix = self._render_warnings(warnings_list)

        # Tree display: table/md render as pretty tree, json/yaml serialize structure.
        if display_hint == "tree" and isinstance(normalized, dict) and fmt in ("table", "md"):
            return self._append_warnings(self._render_tree_display(normalized), warnings_suffix)

        # Primer show: table/md formats drop empty sections so a notes-only
        # primer renders without an empty "articles" row. When both sections
        # are empty, show a populate hint. json/yaml pass through unchanged.
        if (
            display_hint == "primer_show"
            and fmt in ("table", "md")
            and isinstance(normalized, dict)
        ):
            if (
                not normalized.get("notes")
                and not normalized.get("tags")
                and not normalized.get("articles")
            ):
                return self._append_warnings(
                    "Primer is empty.\n"
                    '  Populate with: kd /primer/note add "<text>"\n'
                    "                 kd /primer/tag add <TAG_NAME>\n"
                    "                 kd /primer/article add <ARTICLE_ID>",
                    warnings_suffix,
                )
            normalized = {k: v for k, v in normalized.items() if v}

        # Tag entities: table/md render groups-by-kind with completeness footer;
        # json/yaml return the raw {results, meta} envelope unchanged.
        if (
            display_hint == "tag_entities"
            and fmt in ("table", "md")
            and isinstance(normalized, dict)
        ):
            return self._append_warnings(
                self._render_tag_entities_table(normalized), warnings_suffix
            )

        field_list = [f.strip() for f in fields.split(",")] if fields else None

        match fmt:
            case "table":
                return self._append_warnings(
                    self._format_table(normalized, field_list), warnings_suffix
                )
            case "json":
                return self._format_json(normalized, field_list)
            case "yaml":
                return self._format_yaml(normalized, field_list)
            case "md":
                return self._append_warnings(
                    self._format_markdown(normalized, field_list), warnings_suffix
                )
            case _:
                return self._append_warnings(
                    self._format_table(normalized, field_list), warnings_suffix
                )

    # ------------------------------------------------------------------
    # Normalization
    # ------------------------------------------------------------------

    def _normalize(self, data: Any) -> Any:
        """Walk *data* and normalize values for safe serialization."""
        if isinstance(data, dict):
            return {k: self._normalize_value(k, v) for k, v in data.items()}
        if isinstance(data, list):
            return [self._normalize(item) for item in data]
        return data

    def _normalize_value(self, key: str, value: Any) -> Any:
        """Normalize a single value based on its key and type."""
        if isinstance(value, int) and key in DATE_FIELDS and value > _EPOCH_MS_FLOOR:
            return _format_date(value)
        if isinstance(value, int) and key in TIMESTAMP_FIELDS and value > _EPOCH_MS_FLOOR:
            return _format_timestamp(value)
        if hasattr(value, "value") and hasattr(value, "name"):  # enum
            return value.value
        if isinstance(value, dict):
            return self._normalize(value)
        if isinstance(value, list):
            return [self._normalize(item) for item in value]
        return value

    # ------------------------------------------------------------------
    # Warnings rendering
    # ------------------------------------------------------------------

    @staticmethod
    def _render_warnings(warnings: list[Any]) -> str:
        """Render the warnings list as one ``warning [code]: message`` line per entry."""
        lines: list[str] = []
        for w in warnings:
            if not isinstance(w, dict):
                continue
            code = w.get("code", "warning")
            message = w.get("message", "")
            lines.append(f"warning [{code}]: {message}")
        return "\n".join(lines)

    @staticmethod
    def _append_warnings(body: str, warnings_suffix: str) -> str:
        """Attach the warnings suffix after the main render with a blank separator."""
        if not warnings_suffix:
            return body
        if not body:
            return warnings_suffix
        return f"{body}\n\n{warnings_suffix}"

    # ------------------------------------------------------------------
    # Tree rendering
    # ------------------------------------------------------------------

    @staticmethod
    def _render_tree_display(data: dict[str, Any]) -> str:
        """Render nested tree dict as pretty box-drawing output."""

        def _to_node(d: dict[str, Any]) -> TreeNode:
            return TreeNode(
                id=d.get("id", ""),
                label=d.get("summary", d.get("id", "")),
                has_children=bool(d.get("children")),
            )

        def _fetch_children(node_id: str) -> list[TreeNode]:
            # Walk the tree dict to find the node and return its children
            children = _find_children(data, node_id)
            return [_to_node(c) for c in children]

        def _find_children(node: dict[str, Any], target_id: str) -> list[dict[str, Any]]:
            kids: list[dict[str, Any]] = node.get("children", [])
            if node.get("id") == target_id:
                return kids
            for child in kids:
                result = _find_children(child, target_id)
                if result is not None:
                    return result
            return []

        root = _to_node(data)
        return render_tree(root, _fetch_children)

    # ------------------------------------------------------------------
    # Tag entities rendering
    # ------------------------------------------------------------------

    @staticmethod
    def _render_tag_entities_table(data: dict[str, Any]) -> str:
        """Render /tag entities output as grouped-by-kind tables with footer.

        Row columns: id, updated, project, summary.  Tag membership is
        implicit given the query, so the tags column is omitted.

        The footer reports per-kind completeness (``complete`` / ``truncated``)
        and any per-kind errors (``error: <code>``).  Structured consumers
        must still read ``meta`` — exit 0 does not mean every kind succeeded.
        """
        results = data.get("results", [])
        meta = data.get("meta", {})
        if not results and not any(m.get("error") for m in meta.values()):
            return "(no entries)"

        groups: dict[str, list[dict[str, Any]]] = {"article": [], "issue": []}
        for row in results:
            kind = row.get("kind")
            if kind in groups:
                groups[kind].append(row)

        parts: list[str] = []
        for kind in ("article", "issue"):
            rows = groups[kind]
            if not rows:
                continue
            heading = f"{kind}s ({len(rows)})"
            parts.append(heading)
            sub_rows = [
                [
                    r.get("id_readable", ""),
                    r.get("updated", ""),
                    r.get("project", ""),
                    r.get("summary", ""),
                ]
                for r in rows
            ]
            parts.append(
                "  "
                + tabulate(
                    sub_rows,
                    headers=["id", "updated", "project", "summary"],
                    tablefmt="simple",
                ).replace("\n", "\n  ")
            )
            parts.append("")

        footer_bits: list[str] = []
        for kind in ("article", "issue"):
            m = meta.get(kind)
            if m is None:
                continue
            count = m.get("count", 0)
            label = f"{count} {kind}s"
            if m.get("error"):
                err = m["error"]
                code = err.get("code", "error") if isinstance(err, dict) else "error"
                footer_bits.append(f"{label} (error: {code})")
                continue
            if m.get("complete") == "unknown":
                footer_bits.append(f"{label} (completeness unknown)")
            elif m.get("truncated"):
                flag = f"--limit-{kind}s"
                footer_bits.append(f"{label} (truncated — use {flag} K or --kind {kind})")
            else:
                footer_bits.append(f"{label} (complete)")

        if footer_bits:
            parts.append("Showing " + ", ".join(footer_bits) + ".")
        return "\n".join(parts).rstrip()

    # ------------------------------------------------------------------
    # Format dispatchers
    # ------------------------------------------------------------------

    def _format_table(
        self, data: list[dict[str, Any]] | dict[str, Any], fields: list[str] | None
    ) -> str:
        """Format as plain text table."""
        if isinstance(data, dict):
            filtered_dict = self._filter_dict(data, fields)
            return self._render_detail_table(filtered_dict)

        filtered_rows = self._filter_list(data, fields)
        if not filtered_rows:
            return "(no entries)"
        headers = list(filtered_rows[0].keys())
        rows = [list(row.values()) for row in filtered_rows]
        result: str = tabulate(rows, headers=headers, tablefmt="simple")
        return result

    def _render_detail_table(self, data: dict[str, Any]) -> str:
        """Render a single-entity detail view.

        Scalar fields are aligned in a two-column key/value block.
        Nested lists of dicts become indented sub-tables with a header.
        Long-text scalars (newlines or > ``_LONG_TEXT_THRESHOLD`` chars)
        are lifted out of the scalar block and rendered unindented so
        multi-line markdown stays copy-paste clean.
        """
        parts: list[str] = []
        rows: list[list[Any]] = []

        def _flush_rows() -> None:
            if rows:
                parts.append(tabulate(rows, tablefmt="plain"))
                rows.clear()

        for key, value in data.items():
            if isinstance(value, list) and value and isinstance(value[0], dict):
                _flush_rows()
                parts.append(f"\n{key}")
                sub_headers = list(value[0].keys())
                sub_rows = [list(item.values()) for item in value]
                parts.append(
                    "  "
                    + tabulate(sub_rows, headers=sub_headers, tablefmt="simple").replace(
                        "\n", "\n  "
                    )
                )
            elif _is_long_text(value):
                _flush_rows()
                parts.append(f"\n{key}:")
                parts.append(str(value))
            else:
                rows.append([key, value])
        _flush_rows()
        return "\n".join(parts)

    def _format_json(
        self, data: list[dict[str, Any]] | dict[str, Any], fields: list[str] | None
    ) -> str:
        """Format as JSON."""
        filtered = self._filter(data, fields)
        return json.dumps(filtered, indent=2)

    def _format_yaml(
        self, data: list[dict[str, Any]] | dict[str, Any], fields: list[str] | None
    ) -> str:
        """Format as YAML."""
        filtered = self._filter(data, fields)
        result: str = yaml.safe_dump(
            filtered,
            default_flow_style=False,
            sort_keys=False,
            allow_unicode=True,
        )
        return result.rstrip()

    def _format_markdown(
        self, data: list[dict[str, Any]] | dict[str, Any], fields: list[str] | None
    ) -> str:
        """Format as Markdown table."""
        if isinstance(data, dict):
            filtered_dict = self._filter_dict(data, fields)
            rows = [[k, v] for k, v in filtered_dict.items()]
            result: str = tabulate(rows, headers=["Key", "Value"], tablefmt="github")
            return result

        filtered_rows = self._filter_list(data, fields)
        if not filtered_rows:
            return ""
        headers = list(filtered_rows[0].keys())
        rows = [list(row.values()) for row in filtered_rows]
        result = tabulate(rows, headers=headers, tablefmt="github")
        return result

    def _filter(
        self,
        data: list[dict[str, Any]] | dict[str, Any],
        fields: list[str] | None,
    ) -> list[dict[str, Any]] | dict[str, Any]:
        """Apply field filtering to data."""
        if isinstance(data, dict):
            return self._filter_dict(data, fields)
        return self._filter_list(data, fields)

    def _filter_dict(self, data: dict[str, Any], fields: list[str] | None) -> dict[str, Any]:
        """Filter dict keys to only requested fields."""
        if not fields:
            return data
        return {k: v for k, v in data.items() if k in fields}

    def _filter_list(
        self, data: list[dict[str, Any]], fields: list[str] | None
    ) -> list[dict[str, Any]]:
        """Filter list of dicts to only requested fields."""
        if not fields:
            return data
        return [{k: v for k, v in row.items() if k in fields} for row in data]
