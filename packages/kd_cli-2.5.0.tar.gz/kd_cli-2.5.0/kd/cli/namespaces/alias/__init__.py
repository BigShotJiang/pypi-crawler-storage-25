"""Alias namespace: /alias

Commands: list, show
Displays and inspects user-defined command aliases from config.
"""

from __future__ import annotations

from typing import Any

from kd.cli.core.command_base import Command, CommandResult
from kd.cli.core.namespaces import Namespace
from kd.cli.core.option_registry import ResolvedOptions
from kd.config import resolve_config
from kd.exceptions import ValidationError


class AliasListCommand(Command):
    """List all defined aliases."""

    def __init__(self) -> None:
        super().__init__(
            "list",
            "List all defined aliases with their expansions",
            usage="kd /alias list",
            examples=[
                "kd /alias list",
                "kd /alias list --output json",
            ],
            see_also=["/alias show"],
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        rc = resolve_config()
        rows: list[dict[str, str]] = []
        seen: set[str] = set()
        for source_label, aliases in [("local", rc.local_aliases), ("global", rc.global_aliases)]:
            for name, command in sorted(aliases.items()):
                if name in seen:
                    continue
                seen.add(name)
                rows.append({"name": name, "command": command, "source": source_label})
        return rows


class AliasShowCommand(Command):
    """Show the expansion for a single alias."""

    def __init__(self) -> None:
        super().__init__(
            "show",
            "Show what an alias expands to",
            usage="kd /alias show NAME",
            examples=[
                "kd /alias show my-bugs",
            ],
            see_also=["/alias list"],
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        if not args:
            raise ValidationError("Usage: kd /alias show NAME")
        name = args[0]
        rc = resolve_config()

        # Check local first (higher priority), then global
        if name in rc.local_aliases:
            return {"name": name, "command": rc.local_aliases[name], "source": "local"}
        if name in rc.global_aliases:
            return {"name": name, "command": rc.global_aliases[name], "source": "global"}

        defined = sorted(rc.aliases.keys())
        if defined:
            raise ValidationError(f"No alias named '{name}'. Defined aliases: {', '.join(defined)}")
        raise ValidationError(f"No alias named '{name}'. No aliases defined in config.")


def create_alias_namespace() -> Namespace:
    """Build the /alias namespace."""
    ns = Namespace("alias", "Command aliases", path="alias")
    ns.register_command("list", AliasListCommand())
    ns.register_command("show", AliasShowCommand())
    return ns
