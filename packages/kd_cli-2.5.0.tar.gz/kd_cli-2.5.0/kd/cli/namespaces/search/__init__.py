"""Search command: /search

Cross-entity aggregated search across issues, users, tags, projects,
and articles. Backed by composed calls to multiple YouTrack REST API
endpoints (client-side aggregation, not a single upstream endpoint).

Registered as a root command (not a namespace) so that the first
positional argument is the search query, not a subcommand name.
"""

from __future__ import annotations

from typing import Any

from kd.cli.core.command_base import Command, CommandResult
from kd.cli.core.option_registry import (
    OptionDeclaration,
    OptionLayer,
    ResolvedOptions,
    limit_option,
    project_option,
)
from kd.exceptions import ValidationError


class SearchCommand(Command):
    """Cross-entity search."""

    def __init__(self) -> None:
        super().__init__(
            "search",
            "Search across entity types",
            requires_client=True,
            usage="kd /search QUERY [--types TYPE,...] [--project P] [--limit N]",
            long_description=(
                "Aggregated search across issues, users, tags, projects, and articles. "
                "Issue and user searches use server-side query APIs. Tag, project, and "
                "article searches use client-side substring matching."
            ),
            examples=[
                'kd /search "router"',
                'kd /search "router" --types issue,article',
                'kd /search "alice" --types user',
                'kd /search "dns" --project FB',
                'kd /search "router" --limit 10',
            ],
            see_also=["/issue list"],
        )

    def _register_options(self) -> None:
        self.register_option(
            OptionDeclaration(
                name="types",
                layer=OptionLayer.COMMAND,
                type=str,
                default=None,
                help_text="Comma-separated entity types: issue,user,tag,project,article",
            )
        )
        self.register_option(project_option(help_text="Scope issues and articles to a project"))
        self.register_option(limit_option())

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        if not args:
            raise ValidationError("Usage: kd /search QUERY")
        query = args[0]
        types_raw = options.command.get("types")
        types = types_raw.split(",") if types_raw else None
        project = options.command.get("project")
        limit = options.command.get("limit", 50)
        results = client.search.search(query, types=types, project=project, limit=limit)
        return [
            {
                "type": r.type,
                "id": r.id,
                "title": r.title,
                "project": r.project,
            }
            for r in results
        ]
