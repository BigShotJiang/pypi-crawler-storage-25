"""Init command: kd init

Scaffolds a kd config file at the local tier (.kd/config.yaml in the
current directory, with .gitignore management) or the global tier
(~/.config/kd/config.yaml, parent directory created as needed).
"""

from __future__ import annotations

from typing import Any

from kd.cli.core.command_base import Command, CommandResult
from kd.cli.core.option_registry import OptionDeclaration, OptionLayer, ResolvedOptions
from kd.config import init_project_config


class InitCommand(Command):
    """Initialize project config."""

    def __init__(self) -> None:
        super().__init__(
            "init",
            "Initialize kd config (.kd/config.yaml or ~/.config/kd/config.yaml)",
            usage="kd init [URL] [--global]",
            long_description=(
                "Creates a config file. Default is .kd/config.yaml in the "
                "current directory, with .kd/ added to .gitignore when inside "
                "a git repository. With --global (-g), writes "
                "~/.config/kd/config.yaml instead, creating the parent "
                "directory if needed. Optionally pre-fills the YouTrack URL."
            ),
            examples=[
                "kd init",
                "kd init https://example.youtrack.cloud",
                "kd init --global https://example.youtrack.cloud",
            ],
            see_also=["/system/config list", "/system/config which"],
        )

    def _register_options(self) -> None:
        self.register_option(
            OptionDeclaration(
                name="global",
                layer=OptionLayer.COMMAND,
                type=bool,
                short_name="g",
                help_text="Scaffold global config at ~/.config/kd/config.yaml",
            )
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        url = args[0] if args else None
        use_global = options.command.get("global", False)
        result = init_project_config(url=url, global_tier=use_global)
        return {
            "created": str(result.created),
            "gitignore": result.gitignore_action,
            "next": "Run 'kd /system/config keys' to list configurable paths.",
        }
