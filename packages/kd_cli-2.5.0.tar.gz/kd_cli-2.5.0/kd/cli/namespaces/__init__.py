"""Namespace command implementations.

Each sub-package exports a create_*_namespace() factory function
that returns a configured Namespace with registered commands.
"""

from kd.cli.core.namespaces import NamespaceRegistry, apply_synonyms, load_synonyms
from kd.cli.namespaces.alias import create_alias_namespace
from kd.cli.namespaces.article import create_article_namespace
from kd.cli.namespaces.init import InitCommand
from kd.cli.namespaces.issue import create_issue_namespace
from kd.cli.namespaces.primer import create_primer_namespace
from kd.cli.namespaces.project import create_project_namespace
from kd.cli.namespaces.query import create_query_namespace
from kd.cli.namespaces.release_notes import ReleaseNotesCommand
from kd.cli.namespaces.search import SearchCommand
from kd.cli.namespaces.system import create_system_namespace
from kd.cli.namespaces.tag import create_tag_namespace
from kd.cli.namespaces.time import create_time_namespace
from kd.cli.namespaces.user import create_user_namespace


def register_all_namespaces(registry: NamespaceRegistry) -> None:
    """Register all namespace trees in the registry."""
    registry.root.register_command("init", InitCommand())
    registry.root.register_command("release-notes", ReleaseNotesCommand())
    registry.root.register_command("search", SearchCommand())
    registry.register_namespace(create_alias_namespace())
    registry.register_namespace(create_article_namespace())
    registry.register_namespace(create_system_namespace())
    registry.register_namespace(create_project_namespace())
    registry.register_namespace(create_issue_namespace())
    registry.register_namespace(create_primer_namespace())
    registry.register_namespace(create_query_namespace())
    registry.register_namespace(create_tag_namespace())
    registry.register_namespace(create_user_namespace())
    registry.register_namespace(create_time_namespace())

    # Apply built-in command synonyms (KDCLI-8)
    apply_synonyms(registry.root, load_synonyms())
