"""System namespace: /system

Commands: info, history, restore, diff
Sub-namespaces: /system/config (list, get, set, keys, which)
Manages CLI configuration, displays server info, and provides
copy-on-write history for config and primer files.
"""

from __future__ import annotations

import difflib
import platform as _platform
from dataclasses import asdict
from pathlib import Path
from typing import Any

from kd import __version__ as _kd_version
from kd.cli.core.command_base import Command, CommandResult
from kd.cli.core.namespaces import Namespace
from kd.cli.core.option_registry import OptionDeclaration, OptionLayer, ResolvedOptions
from kd.config import (
    DEFAULT_CONFIG_PATH,
    FLAT_KEYS,
    ResolvedConfig,
    ShadowWarning,
    detect_shadow,
    find_local_config,
    resolve_config,
    update_config_path,
    walk_option_layers,
)
from kd.config_read import get_config_path
from kd.config_schema import MISSING, ConfigKeyEntry, resolve_path, walk_schema
from kd.exceptions import ConfigError, ValidationError
from kd.history import (
    SnapshotInfo,
    atomic_write_text,
    diff_text,
    get_snapshot_path,
    list_snapshots,
    snapshot_before_write,
)
from kd.primer import PRIMER_FILENAME, require_workspace_dir


class SystemInfoCommand(Command):
    """Show server info and connection status."""

    def __init__(self) -> None:
        super().__init__(
            "info",
            "Show server info and connection status",
            requires_client=True,
            usage="kd /system info",
            long_description="Connects to the YouTrack instance and displays the current "
            "user, server URL, and connection status, plus kd client/runtime metadata "
            "(`kd_version`, `python_version`, `platform`) so bug reports are "
            "self-describing without hand-typing the version. Uses the active "
            "connection (selected via -c or 'default_connection').",
            examples=[
                "kd /system info",
                "kd /system info -o yaml",
                "kd -c upstream /system info",
            ],
            see_also=["/system/config list"],
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        me = client._yt_api.get_me()
        base_url = str(client._yt_http._client.base_url).rstrip("/")
        # Strip /api suffix to show the instance URL
        if base_url.endswith("/api"):
            base_url = base_url[:-4]
        return {
            "url": base_url,
            "user": me.get("login", "unknown"),
            "name": me.get("name", ""),
            "email": me.get("email", ""),
            "kd_version": _kd_version,
            "python_version": _platform.python_version(),
            "platform": _platform.platform(),
        }


class ConfigListCommand(Command):
    """Show all config values with source tracking."""

    # Flat keys to display — derived from YtctlConfig schema.
    _FLAT_KEYS = FLAT_KEYS

    def __init__(self) -> None:
        super().__init__(
            "list",
            "Show all config values and their sources",
            requires_config=True,
            usage="kd /system/config list",
            examples=[
                "kd /system/config list",
                "kd /system/config list --output json",
            ],
            see_also=["/system/config get", "/system/config set", "/system/config which"],
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        rc = self.config
        rows: list[dict[str, Any]] = []

        # Flat keys
        for key in self._FLAT_KEYS:
            rv = rc.get(key)
            if rv is None:
                continue
            rows.append({"key": key, "value": rv.value, "source": rv.source, "origin": rv.origin})

        # Connections
        for conn_name, conn_cfg in rc.connections.items():
            origin = rc.connection_origins.get(conn_name)
            prefix = f"connections.{conn_name}"

            def _attrib(key_name: str) -> tuple[str, str]:
                if origin is None:
                    return "", ""
                key_origin = origin.keys.get(key_name)
                if key_origin is not None:
                    return key_origin.source, key_origin.path
                return origin.source, origin.path

            url_source, url_path = _attrib("url")
            rows.append(
                {
                    "key": f"{prefix}.url",
                    "value": conn_cfg.url,
                    "source": url_source,
                    "origin": url_path,
                }
            )
            if conn_cfg.default_project:
                dp_source, dp_path = _attrib("default_project")
                rows.append(
                    {
                        "key": f"{prefix}.default_project",
                        "value": conn_cfg.default_project,
                        "source": dp_source,
                        "origin": dp_path,
                    }
                )

        # Defaults section (local then global, deduped)
        seen_defaults: set[str] = set()
        for source_label, defaults in [
            ("local", rc.local_defaults),
            ("global", rc.global_defaults),
        ]:
            for cmd_key, opts in sorted(defaults.items()):
                for opt_name, opt_val in sorted(opts.items()):
                    dotted = f"defaults.{cmd_key}.{opt_name}"
                    if dotted in seen_defaults:
                        continue
                    seen_defaults.add(dotted)
                    rows.append(
                        {
                            "key": dotted,
                            "value": str(opt_val),
                            "source": source_label,
                            "origin": "",
                        }
                    )

        # Projects section (local then global, deduped)
        seen_projects: set[str] = set()
        for source_label, projects in [
            ("local", rc.local_projects),
            ("global", rc.global_projects),
        ]:
            for proj_key, proj_data in sorted(projects.items()):
                if not isinstance(proj_data, dict):
                    continue
                # Field aliases
                aliases = proj_data.get("field_aliases", {})
                if isinstance(aliases, dict):
                    for alias_name, alias_val in sorted(aliases.items()):
                        dotted = f"projects.{proj_key}.field_aliases.{alias_name}"
                        if dotted in seen_projects:
                            continue
                        seen_projects.add(dotted)
                        rows.append(
                            {
                                "key": dotted,
                                "value": str(alias_val),
                                "source": source_label,
                                "origin": "",
                            }
                        )
                # Project defaults
                proj_defaults = proj_data.get("defaults", {})
                if isinstance(proj_defaults, dict):
                    for cmd_key, opts in sorted(proj_defaults.items()):
                        if not isinstance(opts, dict):
                            continue
                        for opt_name, opt_val in sorted(opts.items()):
                            dotted = f"projects.{proj_key}.defaults.{cmd_key}.{opt_name}"
                            if dotted in seen_projects:
                                continue
                            seen_projects.add(dotted)
                            rows.append(
                                {
                                    "key": dotted,
                                    "value": str(opt_val),
                                    "source": source_label,
                                    "origin": "",
                                }
                            )

        # Aliases section (local then global, deduped)
        seen_aliases: set[str] = set()
        for source_label, aliases in [
            ("local", rc.local_aliases),
            ("global", rc.global_aliases),
        ]:
            for alias_name, alias_cmd in sorted(aliases.items()):
                dotted = f"aliases.{alias_name}"
                if dotted in seen_aliases:
                    continue
                seen_aliases.add(dotted)
                rows.append(
                    {
                        "key": dotted,
                        "value": alias_cmd,
                        "source": source_label,
                        "origin": "",
                    }
                )

        return rows


class ConfigGetCommand(Command):
    """Get a config value."""

    def __init__(self) -> None:
        super().__init__(
            "get",
            "Get a config value and its source",
            requires_config=True,
            usage="kd /system/config get PATH",
            long_description=(
                "Accepts any path listed by `kd /system/config keys` — top-level "
                "flat keys, connection sub-paths, structured-section leaves. "
                "Returns the winning value plus its source and origin."
            ),
            examples=[
                "kd /system/config get default_connection",
                "kd /system/config get connections.corp.default_project",
                "kd /system/config get history.retention",
            ],
            see_also=["/system/config set", "/system/config keys", "/system/config list"],
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        if not args:
            raise ValidationError("Usage: kd /system/config get PATH")
        path = args[0]
        if resolve_path(path) is None:
            raise ConfigError(
                f"Unknown config path: {path}. "
                "Run 'kd /system/config keys' to list available paths."
            )
        rc = self.config
        # Top-level flat keys: reuse the existing source-tracked entry.
        if path in FLAT_KEYS:
            rv = rc.get(path)
            if rv is None:
                return {"key": path, "value": None}
            return {
                "key": path,
                "value": rv.value,
                "source": str(rv.source),
                "origin": rv.origin,
            }
        resolved = get_config_path(rc, path)
        if resolved is None:
            return {"path": path, "value": None}
        return resolved


class ConfigSetCommand(Command):
    """Set a config value."""

    def __init__(self) -> None:
        super().__init__(
            "set",
            "Set a config value",
            usage="kd /system/config set PATH VALUE [--local | --global]",
            long_description=(
                "Accepts any path listed by `kd /system/config keys`. Writes to "
                "local .kd/config.yaml if it exists, otherwise to "
                "~/.config/kd/config.yaml. Use --local or --global to force target. "
                "Values are coerced through the schema and the whole config is "
                "revalidated after the write — failures roll back to the prior file."
            ),
            examples=[
                "kd /system/config set default_connection corp",
                "kd /system/config set connections.support.default_project BCO --local",
                "kd /system/config set history.retention 50 --global",
            ],
            see_also=["/system/config get", "/system/config keys", "/system/config list"],
        )

    def _register_options(self) -> None:
        self.register_option(
            OptionDeclaration(
                name="local",
                layer=OptionLayer.COMMAND,
                type=bool,
                help_text="Write to local .kd/config.yaml",
            )
        )
        self.register_option(
            OptionDeclaration(
                name="global",
                layer=OptionLayer.COMMAND,
                type=bool,
                help_text="Write to global ~/.config/kd/config.yaml",
            )
        )
        self.register_option(
            OptionDeclaration(
                name="no-shadow-warning",
                layer=OptionLayer.COMMAND,
                type=bool,
                help_text="Suppress the shadow-warning check after writing",
            )
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        if len(args) < 2:
            raise ValidationError("Usage: kd /system/config set PATH VALUE")
        path = args[0]
        value = " ".join(args[1:])

        use_local = options.command.get("local", False)
        use_global = options.command.get("global", False)
        if use_local and use_global:
            raise ValidationError("Cannot use both --local and --global")

        if use_local:
            local_path = find_local_config()
            if local_path is None:
                raise ConfigError("No local config found. Run 'kd init' first.")
            target = local_path
            tier = "local"
        elif use_global:
            target = DEFAULT_CONFIG_PATH
            tier = "global"
        else:
            # Default: local if it exists, otherwise global
            local_path = find_local_config()
            if local_path is not None:
                target = local_path
                tier = "local"
            else:
                target = DEFAULT_CONFIG_PATH
                tier = "global"

        resolved_path, coerced = update_config_path(path, value, target)
        result: dict[str, Any] = {
            "ok": True,
            "action": "set",
            "path": resolved_path,
            "value": coerced,
            "file": str(target),
        }

        if not options.command.get("no-shadow-warning", False):
            rc = resolve_config()
            warning = detect_shadow(resolved_path, tier, rc, default_lookup=_lookup_builtin_default)
            if warning is not None:
                result["warning"] = asdict(warning)
                _emit_shadow_warning(warning)

        return result


def _lookup_builtin_default(command_key: str, option_name: str) -> Any:
    """Option-registry accessor passed to :func:`detect_shadow` for layer-10 hints."""
    try:
        options_map = _command_options_map()
    except Exception:
        return None
    decl = options_map.get(command_key, {}).get(option_name)
    return decl.default if decl is not None else None


def _emit_shadow_warning(warning: ShadowWarning) -> None:
    """Render the shadow warning to stderr — non-fatal, user-readable."""
    import sys

    written = warning.written
    winning = warning.winning
    lines = [
        "",
        (
            f"Warning: wrote {warning.option} = {written['value']!r} at layer "
            f"{written['layer']} ({written['source']}), but layer {winning['layer']} "
            f"({winning['source']}) = {winning['value']!r} shadows it."
        ),
        f"Run 'kd /system/config which {warning.option}' for the full chain.",
    ]
    if warning.hint_path:
        lines.append("Hint: to override at a higher-priority layer, set:")
        lines.append(f"  kd /system/config set {warning.hint_path} {written['value']!r}")
    print("\n".join(lines), file=sys.stderr)


class ConfigKeysCommand(Command):
    """Enumerate every settable config path with type, default, and description."""

    def __init__(self) -> None:
        super().__init__(
            "keys",
            "List every configurable path with type, default, and description",
            usage="kd /system/config keys",
            long_description=(
                "Enumerates every settable config path derived from the schema. "
                "Variadic dict segments render as placeholders: <name> for "
                "connections, <key> for projects, <command_key>/<option> for "
                "command defaults, <alias> for field aliases."
            ),
            examples=[
                "kd /system/config keys",
                "kd /system/config keys -o json",
            ],
            see_also=["/system/config get", "/system/config set", "/system/config list"],
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        return [_catalog_row(entry) for entry in walk_schema()]


def _catalog_row(entry: ConfigKeyEntry) -> dict[str, Any]:
    return {
        "path": entry.path,
        "type": entry.type_label,
        "default": _render_default(entry.default),
        "description": entry.description or "",
    }


def _render_default(default: Any) -> str:
    if default is MISSING:
        return "(required)"
    if default is None:
        return ""
    if isinstance(default, bool):
        return "true" if default else "false"
    if isinstance(default, (dict, list)) and not default:
        return ""
    return str(default)


class ConfigWhichCommand(Command):
    """Show which config files are active, or trace a single option's resolution."""

    def __init__(self) -> None:
        super().__init__(
            "which",
            "Show active config files or trace an option's resolution chain",
            requires_config=True,
            usage="kd /system/config which [PATH]",
            long_description=(
                "With no argument, prints the active local and global config paths. "
                "With a flat key from `kd /system/config keys`, returns the winning "
                "value and its origin. With a dotted option path like `<cmd>.<opt>` "
                "(e.g. `primer_show.output`, `issue_list.limit`), walks the 10-layer "
                "command-option chain and reports each layer's value plus which is "
                "winning, shadowed, not set, or n/a. Use --project / --connection to "
                "explore resolution under a different context."
            ),
            examples=[
                "kd /system/config which",
                "kd /system/config which default_connection",
                "kd /system/config which primer_show.output",
                "kd /system/config which issue_list.limit --connection kb",
                "kd /system/config which primer_show.output -o json",
            ],
            see_also=[
                "/system/config list",
                "/system/config keys",
                "/system/config get",
            ],
        )

    def _register_options(self) -> None:
        self.register_option(
            OptionDeclaration(
                name="project",
                layer=OptionLayer.COMMAND,
                type=str,
                help_text="Trace resolution under this project key",
            )
        )
        self.register_option(
            OptionDeclaration(
                name="connection",
                layer=OptionLayer.COMMAND,
                type=str,
                help_text="Trace resolution under this connection name",
            )
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        if not args:
            return _which_files()

        path = args[0]
        rc = self.config

        # Flat-key form — single token matching a top-level scalar field.
        if "." not in path:
            if path not in FLAT_KEYS:
                raise ConfigError(
                    f"Unknown config path: {path}. "
                    "Run 'kd /system/config keys' to list available paths."
                )
            return _which_flat(rc, path)

        # Option-path form — <command_key>.<option>.
        command_key, _, option_name = path.partition(".")
        project_override = options.command.get("project")
        connection_override = options.command.get("connection")
        return _which_option_path(
            rc,
            command_key,
            option_name,
            project_override=project_override,
            connection_override=connection_override,
        )


def _which_files() -> dict[str, Any]:
    """Back-compat: no-argument form returns active config file paths."""
    local_path = find_local_config()
    result: dict[str, Any] = {
        "global": str(DEFAULT_CONFIG_PATH),
        "global_exists": DEFAULT_CONFIG_PATH.exists(),
    }
    if local_path:
        result["local"] = str(local_path)
        result["local_exists"] = True
    else:
        result["local"] = None
        result["local_exists"] = False
    return result


def _which_flat(rc: ResolvedConfig, key: str) -> dict[str, Any]:
    rv = rc.get(key)
    if rv is None:
        return {"key": key, "value": None}
    return {
        "key": key,
        "value": rv.value,
        "source": str(rv.source),
        "origin": rv.origin,
    }


def _which_option_path(
    rc: ResolvedConfig,
    command_key: str,
    option_name: str,
    *,
    project_override: str | None,
    connection_override: str | None,
) -> dict[str, Any]:
    options_map = _command_options_map()
    if command_key not in options_map:
        raise ConfigError(
            f"Unknown command key: {command_key}. "
            "Run 'kd /system/config keys' for the catalog or "
            "'kd --help' to list commands.",
            suggestion=_closest_suggestion(command_key, sorted(options_map)),
        )
    declared = options_map[command_key]
    if option_name not in declared:
        raise ConfigError(
            f"Unknown option '{option_name}' for command '{command_key}'. "
            f"Declared options: {', '.join(sorted(declared)) or '(none)'}.",
            suggestion=_closest_suggestion(option_name, list(declared)),
        )
    decl = declared[option_name]
    builtin_default = decl.default

    active_rc = rc
    if connection_override is not None:
        if connection_override not in rc.connections:
            known = ", ".join(sorted(rc.connections)) or "(none)"
            raise ConfigError(f"Unknown connection: {connection_override}. Known: {known}.")
        active_rc = rc.with_active_connection(connection_override)
    active_project = project_override  # None → no project layer

    states = walk_option_layers(
        option_name,
        command_key,
        active_project,
        active_rc,
        builtin_default=builtin_default,
    )
    winner = next((s for s in states if s.status == "winning"), None)
    return {
        "option": f"{command_key}.{option_name}",
        "command_key": command_key,
        "option_name": option_name,
        "resolved": (
            {
                "layer": winner.layer,
                "source": winner.source,
                "value": winner.value,
                "origin": winner.origin,
            }
            if winner is not None
            else None
        ),
        "layers": [
            {
                "layer": s.layer,
                "source": s.source,
                "value": s.value,
                "status": s.status,
                "origin": s.origin,
            }
            for s in states
        ],
    }


def _command_options_map() -> dict[str, dict[str, OptionDeclaration]]:
    """Walk the registered namespace tree and return ``{command_key: {opt: decl}}``.

    Called only from ``/system/config which <option_path>``, so the one-time
    registry construction cost is paid exactly when needed.
    """
    from kd.cli.core.namespaces import NamespaceRegistry
    from kd.cli.core.option_registry import OUTPUT_OPTIONS
    from kd.cli.namespaces import register_all_namespaces

    registry = NamespaceRegistry()
    register_all_namespaces(registry)

    result: dict[str, dict[str, OptionDeclaration]] = {}

    def walk(ns: Any) -> None:
        prefix = ns.path.replace("/", "_")
        for cmd_name, cmd in ns.commands.items():
            key = f"{prefix}_{cmd_name}" if prefix else cmd_name
            result[key] = {d.name: d for d in cmd.get_options() + OUTPUT_OPTIONS}
        for sub in ns.sub_namespaces.values():
            walk(sub)

    walk(registry.root)
    return result


def _closest_suggestion(given: str, choices: list[str], limit: int = 3) -> str | None:
    """Return a short 'did you mean' suggestion string, or None."""
    matches = difflib.get_close_matches(given, choices, n=limit, cutoff=0.5)
    if not matches:
        return None
    return "Did you mean: " + ", ".join(matches)


# ---------------------------------------------------------------------------
# History helpers
# ---------------------------------------------------------------------------

_VALID_TARGETS = ("config", "primer")


def _resolve_target(name: str) -> tuple[Path, Path, str]:
    """Resolve a history target name to (live_path, history_dir, filename).

    Raises ``ValidationError`` for unknown target names and ``ConfigError``
    when the required ``.kd/`` directory is missing.
    """
    if name == "config":
        live = find_local_config()
        if live is None:
            raise ConfigError("No local config found. Run 'kd init' first.")
        return live, live.parent / "history", live.name
    if name == "primer":
        workspace_dir = require_workspace_dir()
        live = workspace_dir / PRIMER_FILENAME
        return live, workspace_dir / "history", PRIMER_FILENAME
    raise ValidationError(f"Unknown target: {name}. Valid targets: {', '.join(_VALID_TARGETS)}")


def _diff_summary(snapshot: SnapshotInfo, current_text: str) -> str:
    """One-line diff summary: ``+N -M`` lines vs current file."""
    snap_lines = snapshot.path.read_text().splitlines()
    curr_lines = current_text.splitlines()
    added = removed = 0
    for line in difflib.unified_diff(snap_lines, curr_lines, n=0):
        if line.startswith("+") and not line.startswith("+++"):
            added += 1
        elif line.startswith("-") and not line.startswith("---"):
            removed += 1
    return f"+{added} -{removed}"


# ---------------------------------------------------------------------------
# History commands
# ---------------------------------------------------------------------------


class SystemHistoryCommand(Command):
    """List copy-on-write snapshots for config or primer."""

    def __init__(self) -> None:
        super().__init__(
            "history",
            "List config/primer snapshots",
            usage="kd /system history [config|primer]",
            long_description="Lists copy-on-write snapshots for config, primer, or both "
            "(default). Each entry shows the timestamp, file size, and a summary of lines "
            "changed relative to the current file.",
            examples=[
                "kd /system history",
                "kd /system history config",
                "kd /system history primer",
            ],
            see_also=["/system restore", "/system diff"],
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        targets = [args[0]] if args else list(_VALID_TARGETS)
        rows: list[dict[str, Any]] = []
        for target_name in targets:
            live_path, history_dir, filename = _resolve_target(target_name)
            current_text = live_path.read_text() if live_path.exists() else ""
            for snap in list_snapshots(history_dir, filename):
                rows.append(
                    {
                        "file": target_name,
                        "timestamp": snap.timestamp,
                        "size": snap.size,
                        "changes": _diff_summary(snap, current_text),
                    }
                )
        return rows


class SystemRestoreCommand(Command):
    """Restore a config or primer file from a snapshot."""

    def __init__(self) -> None:
        super().__init__(
            "restore",
            "Restore config/primer from a snapshot",
            usage="kd /system restore <config|primer> <timestamp>",
            long_description="Replaces the live file with the specified snapshot. "
            "The current file is snapshotted first, so restore is itself undoable.",
            examples=[
                "kd /system restore config 2026-04-09T10-30-00",
                "kd /system restore primer 2026-04-09T14-20-00",
            ],
            see_also=["/system history", "/system diff"],
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        if len(args) < 2:
            raise ValidationError("Usage: kd /system restore <config|primer> <timestamp>")
        target_name, timestamp = args[0], args[1]
        live_path, history_dir, filename = _resolve_target(target_name)
        snap_path = get_snapshot_path(history_dir, filename, timestamp)
        # Snapshot current before restoring (so restore is undoable)
        snapshot_before_write(live_path)
        restored_text = snap_path.read_text()
        atomic_write_text(live_path, restored_text)
        return {
            "ok": True,
            "action": "restore",
            "target": target_name,
            "timestamp": timestamp,
            "file": str(live_path),
        }


class SystemDiffCommand(Command):
    """Show a unified diff for a config or primer snapshot."""

    def __init__(self) -> None:
        super().__init__(
            "diff",
            "Diff config/primer snapshots",
            usage="kd /system diff <config|primer> <timestamp> [<timestamp>]",
            long_description="With one timestamp, shows the diff between the snapshot "
            "and the current file. With two timestamps, diffs the two snapshots.",
            examples=[
                "kd /system diff config 2026-04-09T10-30-00",
                "kd /system diff primer 2026-04-09T10-00-00 2026-04-09T14-00-00",
            ],
            see_also=["/system history", "/system restore"],
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        if len(args) < 2:
            raise ValidationError(
                "Usage: kd /system diff <config|primer> <timestamp> [<timestamp>]"
            )
        target_name = args[0]
        live_path, history_dir, filename = _resolve_target(target_name)

        snap_a = get_snapshot_path(history_dir, filename, args[1])
        text_a = snap_a.read_text()
        label_a = f"{filename}.{args[1]}"

        if len(args) >= 3:
            snap_b = get_snapshot_path(history_dir, filename, args[2])
            text_b = snap_b.read_text()
            label_b = f"{filename}.{args[2]}"
        else:
            text_b = live_path.read_text() if live_path.exists() else ""
            label_b = filename

        result = diff_text(text_a, text_b, label_a, label_b)
        if not result:
            return "No differences."
        return result


def create_system_namespace() -> Namespace:
    """Build the /system namespace tree."""
    system_ns = Namespace("system", "System management and configuration", path="system")
    system_ns.register_command("info", SystemInfoCommand())
    system_ns.register_command("history", SystemHistoryCommand())
    system_ns.register_command("restore", SystemRestoreCommand())
    system_ns.register_command("diff", SystemDiffCommand())

    config_ns = Namespace("config", "CLI configuration", path="system/config")
    config_ns.register_command("list", ConfigListCommand())
    config_ns.register_command("get", ConfigGetCommand())
    config_ns.register_command("set", ConfigSetCommand())
    config_ns.register_command("keys", ConfigKeysCommand())
    config_ns.register_command("which", ConfigWhichCommand())

    system_ns.register_sub_namespace(config_ns)
    return system_ns
