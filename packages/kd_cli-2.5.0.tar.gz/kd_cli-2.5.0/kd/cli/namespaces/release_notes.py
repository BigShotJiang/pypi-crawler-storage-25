"""Release-notes command: /release-notes

Serves the bundled `kd/resources/CHANGELOG.md`. Supports slicing by
`--version`, `--since`, or `--all`. Default returns the latest released
section.
"""

from __future__ import annotations

from typing import Any

from packaging.version import InvalidVersion

from kd.cli.core.command_base import Command, CommandResult
from kd.cli.core.option_registry import OptionDeclaration, OptionLayer, ResolvedOptions
from kd.exceptions import ValidationError
from kd.release_notes import (
    filter_since,
    get_version,
    latest,
    load_changelog,
    parse_changelog,
    render_section,
)


class ReleaseNotesCommand(Command):
    """Print release notes from the bundled changelog."""

    def __init__(self) -> None:
        super().__init__(
            "release-notes",
            "Print release notes from the bundled changelog",
            usage="kd /release-notes [VERSION] [--since X.Y.Z | --all]",
            long_description=(
                "Reads the bundled CHANGELOG.md and prints one or more "
                "release sections. Default returns the latest released "
                "section. Pass a version positionally to pin a specific "
                "release, --since to slice everything strictly newer than "
                "a given version, or --all for the complete file. Output "
                "defaults to markdown; -o json or -o yaml emits a "
                "structured list of {version, date, body} dicts for "
                "programmatic consumers. Source: kd/resources/CHANGELOG.md "
                "in the installed wheel."
            ),
            examples=[
                "kd /release-notes",
                "kd /release-notes 2.1.0",
                "kd /release-notes --since 2.0.5",
                "kd /release-notes --all -o json",
            ],
            see_also=["/primer show"],
        )

    def _register_options(self) -> None:
        self.register_option(
            OptionDeclaration(
                name="since",
                layer=OptionLayer.COMMAND,
                type=str,
                help_text="Return every version strictly newer than this",
            )
        )
        self.register_option(
            OptionDeclaration(
                name="all",
                layer=OptionLayer.COMMAND,
                type=bool,
                help_text="Return the complete changelog",
            )
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        version = args[0] if args else None
        since = options.command.get("since")
        show_all = options.command.get("all", False)

        chosen = [
            flag
            for flag, val in (("VERSION", version), ("--since", since), ("--all", show_all))
            if val
        ]
        if len(chosen) > 1:
            raise ValidationError(
                f"VERSION, --since, and --all are mutually exclusive; got {', '.join(chosen)}"
            )

        sections = parse_changelog(load_changelog())

        if version:
            section = get_version(sections, version)
            if section is None:
                raise ValidationError(
                    f"Version {version} not found in changelog. "
                    f"Run 'kd /release-notes --all' to see available versions."
                )
            result = [section]
        elif since:
            try:
                result = filter_since(sections, since)
            except InvalidVersion as exc:
                raise ValidationError(f"Invalid version '{since}': {exc}") from exc
        elif show_all:
            result = sections
        else:
            only = latest(sections)
            if only is None:
                raise ValidationError("Changelog has no released versions.")
            result = [only]

        fmt = options.output.get("output")
        if fmt in ("json", "yaml"):
            return [{"version": s.version, "date": s.date, "body": s.body} for s in result]
        return "\n\n".join(render_section(s) for s in result)
