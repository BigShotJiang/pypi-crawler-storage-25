"""CLI layer — thin wrapper over the SDK.

Parses arguments via namespace-based command routing,
calls SDK methods, formats output.
"""
