"""Tree rendering utility.

Renders hierarchical data as an indented tree with box-drawing characters::

    Root Node
    ├── Child 1
    │   └── Grandchild
    └── Child 2

Generic interface: provide a root node and a callback that fetches children.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable


@dataclass
class TreeNode:
    """A node in a tree display."""

    id: str
    label: str
    has_children: bool = False


def render_tree(
    root: TreeNode,
    fetch_children: Callable[[str], list[TreeNode]],
    max_depth: int = 5,
) -> str:
    """Render a tree as a string with box-drawing characters.

    Args:
        root: The root node to display.
        fetch_children: Callback that takes a node ID and returns child nodes.
        max_depth: Maximum depth to recurse (0 = root only).
    """
    lines: list[str] = [f"{root.label}"]
    if max_depth > 0 and root.has_children:
        children = fetch_children(root.id)
        _render_children(lines, children, fetch_children, "", max_depth - 1)
    return "\n".join(lines)


def _render_children(
    lines: list[str],
    children: list[TreeNode],
    fetch_children: Callable[[str], list[TreeNode]],
    prefix: str,
    remaining_depth: int,
) -> None:
    """Recursively render child nodes with correct box-drawing prefixes."""
    for i, child in enumerate(children):
        is_last = i == len(children) - 1
        connector = "└── " if is_last else "├── "
        lines.append(f"{prefix}{connector}{child.label}")

        if remaining_depth > 0 and child.has_children:
            extension = "    " if is_last else "│   "
            grandchildren = fetch_children(child.id)
            _render_children(
                lines, grandchildren, fetch_children, prefix + extension, remaining_depth - 1
            )
