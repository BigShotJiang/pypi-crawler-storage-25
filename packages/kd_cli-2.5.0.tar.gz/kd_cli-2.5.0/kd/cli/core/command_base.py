"""Command base class.

All CLI commands inherit from Command and implement execute().
Commands receive positional args, resolved options, and optionally
a YouTrackClient. They return structured data for output formatting.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

from kd.cli.core.option_registry import OptionDeclaration, ResolvedOptions

if TYPE_CHECKING:
    from kd.config import ResolvedConfig

# Commands return structured data — the output layer formats it.
# list[dict] -> table rows; dict -> key-value pairs; str -> passthrough; None -> no output
CommandResult = list[dict[str, Any]] | dict[str, Any] | str | None


class Command(ABC):
    """Base class for all CLI commands."""

    def __init__(
        self,
        name: str,
        description: str,
        *,
        requires_client: bool = False,
        requires_config: bool = False,
        usage: str = "",
        long_description: str = "",
        examples: list[str] | None = None,
        see_also: list[str] | None = None,
    ) -> None:
        self.name = name
        self.description = description
        self.requires_client = requires_client
        self.requires_config = requires_config
        self.usage = usage
        self.long_description = long_description
        self.examples: list[str] = examples or []
        self.see_also: list[str] = see_also or []
        self.display_hint: str | None = None
        self._options: list[OptionDeclaration] = []
        self._resolved_config: ResolvedConfig | None = None
        self._register_options()

    def set_config(self, config: ResolvedConfig) -> None:
        """Inject the resolved config. Called by the dispatcher when
        ``requires_config`` is True, before ``execute()`` runs.
        """
        self._resolved_config = config

    @property
    def config(self) -> ResolvedConfig:
        """The resolved config for this invocation.

        Only valid when the command declares ``requires_config=True``; the
        dispatcher calls :meth:`set_config` before :meth:`execute` in that
        case. Raises :class:`RuntimeError` otherwise.
        """
        if self._resolved_config is None:
            raise RuntimeError(f"{self.name}: config not set. Did you forget requires_config=True?")
        return self._resolved_config

    def _register_options(self) -> None:
        """Register command-specific options. Override in subclasses."""

    @abstractmethod
    def execute(
        self,
        args: list[str],
        options: ResolvedOptions,
        client: Any = None,
    ) -> CommandResult:
        """Execute the command. Return structured data for output formatting.

        Args:
            args: Positional arguments after namespace+command resolution.
            options: Resolved command and output options.
            client: YouTrackClient instance (None if requires_client is False).
        """

    def register_option(self, option: OptionDeclaration) -> None:
        """Add an option declaration to this command."""
        self._options.append(option)

    def get_options(self) -> list[OptionDeclaration]:
        """Return all option declarations for this command."""
        return list(self._options)

    def get_help_text(self) -> str:
        """Generate help text from command metadata and options."""
        lines = [self.description]

        if self.usage:
            lines.append("")
            lines.append(f"Usage: {self.usage}")

        if self.long_description:
            lines.append("")
            lines.append(self.long_description)

        if self._options:
            lines.append("")
            lines.append("Options:")
            for opt in self._options:
                flag = f"  --{opt.name}"
                if opt.short_name:
                    flag += f", -{opt.short_name}"
                if opt.aliases:
                    alias_str = ", ".join(f"--{a}" for a in opt.aliases)
                    flag += f" (alias: {alias_str})"
                if opt.help_text:
                    flag += f"    {opt.help_text}"
                lines.append(flag)

        if self.examples:
            lines.append("")
            lines.append("Examples:")
            for ex in self.examples:
                lines.append(f"  {ex}")

        if self.see_also:
            lines.append("")
            lines.append(f"See also: {', '.join(self.see_also)}")

        return "\n".join(lines)
