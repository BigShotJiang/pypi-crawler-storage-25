"""Two-phase command parser.

Phase 1 (parse_command): Resolve namespace + command from positional
args and tokenize options into a raw dict.  No validation.

Phase 2 (resolve_options): Validate types, choices, and required
options, producing the final ResolvedOptions.

The convenience method ``parse()`` runs both phases in one call.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from kd.cli.core.command_base import Command
from kd.cli.core.namespaces import Namespace, NamespaceRegistry
from kd.cli.core.option_registry import (
    OUTPUT_OPTIONS,
    OptionError,
    OptionRegistry,
    ResolvedOptions,
)


class ParseError(Exception):
    """Raised when command parsing fails."""


@dataclass
class UnresolvedCommand:
    """Phase-1 result: command identified, options tokenized but not validated."""

    namespace: Namespace
    command_name: str
    command: Command | None  # None if command not found
    args: list[str] = field(default_factory=list)
    raw_options: dict[str, Any] = field(default_factory=dict)


@dataclass
class ParsedCommand:
    """Result of parsing a command line."""

    namespace: Namespace
    command_name: str
    command: Command | None  # None if command not found
    args: list[str] = field(default_factory=list)
    options: ResolvedOptions = field(default_factory=ResolvedOptions)
    raw_options: dict[str, Any] = field(default_factory=dict)


class CommandParser:
    """Parses argv into a resolved command with options."""

    def __init__(self, registry: NamespaceRegistry) -> None:
        self._registry = registry

    def parse_command(self, argv: list[str]) -> UnresolvedCommand:
        """Phase 1: resolve command and tokenize options.  No validation.

        1. Split argv into positionals and option tokens
        2. Resolve namespace + command from positionals
        3. Build option registry from command declarations + OUTPUT_OPTIONS
        4. Parse option tokens into a raw dict (recovering misclassified positionals)
        """
        positionals, option_tokens = self._split_args(argv)
        namespace, command_name, remaining = self._registry.resolve(positionals)

        command = namespace.get_command(command_name) if command_name else None

        option_reg = self._build_option_registry(command)
        raw_options, recovered = self._parse_option_tokens(option_tokens, option_reg)

        # Recovered positionals are tokens that _split_args heuristically
        # consumed as option values but were actually after boolean flags.
        # Prepend them to args so the command sees them.
        if recovered:
            remaining = recovered + remaining

        return UnresolvedCommand(
            namespace=namespace,
            command_name=command_name,
            command=command,
            args=remaining,
            raw_options=raw_options,
        )

    def resolve_options(self, unresolved: UnresolvedCommand) -> ParsedCommand:
        """Phase 2: validate and resolve options.

        Builds the option registry, validates types/choices/required,
        and returns a fully resolved ``ParsedCommand``.
        """
        option_reg = self._build_option_registry(unresolved.command)
        try:
            resolved = option_reg.resolve(unresolved.raw_options)
        except OptionError as e:
            raise ParseError(str(e)) from e

        return ParsedCommand(
            namespace=unresolved.namespace,
            command_name=unresolved.command_name,
            command=unresolved.command,
            args=unresolved.args,
            options=resolved,
            raw_options=unresolved.raw_options,
        )

    def parse(self, argv: list[str]) -> ParsedCommand:
        """Full parse: resolve command + validate options in one call.

        Convenience wrapper equivalent to ``parse_command()`` then
        ``resolve_options()``.
        """
        return self.resolve_options(self.parse_command(argv))

    def _split_args(self, argv: list[str]) -> tuple[list[str], list[str]]:
        """Split argv into positional args and option tokens.

        Supports GNU-style mixed placement: options can appear anywhere
        in the command line (before, between, or after positionals).

        Slash-path expansion: the first positional token starting with
        ``/`` is expanded into namespace segments (``/a/b`` → ``a``, ``b``).
        Once any positional has been emitted, later ``/``-prefixed tokens
        are treated as literal arguments (file paths, etc.).
        A bare ``/`` expands to nothing (root namespace).

        The ``--`` separator ends option parsing: everything after it
        is positional.

        Heuristic: any ``--option`` followed by a non-dash token consumes
        it as a value. If the option turns out to be a boolean flag,
        ``_parse_option_tokens`` recovers the stray value (see there).
        A lone ``-`` is consumed as a value (stdin convention).
        """
        positionals: list[str] = []
        option_tokens: list[str] = []

        i = 0
        while i < len(argv):
            token = argv[i]

            # -- separator: everything after is positional
            if token == "--":
                positionals.extend(argv[i + 1 :])
                break

            if token.startswith("-") and len(token) > 1:
                # Option token
                option_tokens.append(token)

                # If not --key=value form, consume next token as value
                # (heuristic: assume non-dash options take a value)
                if "=" not in token and i + 1 < len(argv):
                    next_token = argv[i + 1]
                    if next_token != "--" and not (
                        next_token.startswith("-") and len(next_token) > 1
                    ):
                        option_tokens.append(next_token)
                        i += 2
                        continue
                i += 1
            else:
                # Positional token — expand slash path only for the first one
                if not positionals and token.startswith("/"):
                    segments = [s for s in token.split("/") if s]
                    positionals.extend(segments)
                else:
                    positionals.append(token)
                i += 1

        return positionals, option_tokens

    def _build_option_registry(self, command: Command | None) -> OptionRegistry:
        """Build option registry from command declarations + standard OUTPUT options."""
        registry = OptionRegistry()
        registry.register_all(OUTPUT_OPTIONS)
        if command:
            registry.register_all(command.get_options())
        return registry

    def _parse_option_tokens(
        self, tokens: list[str], registry: OptionRegistry
    ) -> tuple[dict[str, Any], list[str]]:
        """Parse option tokens into a raw name->value dict.

        Handles: --key value, --key=value, -k value, -k=value, boolean flags.

        Returns (raw_options, recovered_positionals). Recovered positionals
        are tokens that ``_split_args`` heuristically consumed as option values
        but actually follow boolean flags — they belong in the positional stream.
        """
        raw: dict[str, Any] = {}
        recovered: list[str] = []
        i = 0

        while i < len(tokens):
            token = tokens[i]

            if "=" in token:
                # --key=value or -k=value
                name_part, value = token.split("=", 1)
                name = name_part.lstrip("-")
                canonical = registry.resolve_name(name) or name
                self._set_option(raw, canonical, value, registry)
                i += 1
                continue

            if not token.startswith("-") or len(token) == 1:
                # Stray positional (includes lone `-`) — recover for command args
                recovered.append(token)
                i += 1
                continue

            name = token.lstrip("-")
            canonical = registry.resolve_name(name) or name

            # Boolean flag: no value consumed
            if registry.is_boolean_flag(name):
                raw[canonical] = True
                i += 1
                continue

            # Regular option: consume next token as value (lone `-` is valid)
            if i + 1 < len(tokens) and not (
                tokens[i + 1].startswith("-") and len(tokens[i + 1]) > 1
            ):
                self._set_option(raw, canonical, tokens[i + 1], registry)
                i += 2
            elif registry.get_declaration(name) is not None:
                raise ParseError(f"Option --{canonical} requires a value")
            else:
                raise ParseError(f"Unknown option: --{name}")

        return raw, recovered

    @staticmethod
    def _set_option(raw: dict[str, Any], name: str, value: str, registry: OptionRegistry) -> None:
        """Set an option value, appending to a list for repeatable options."""
        if registry.is_list_option(name):
            raw.setdefault(name, []).append(value)
        else:
            raw[name] = value
