"""Confirmation guard for irreversible destructive commands.

Some destructive commands bypass YouTrack's Deleted Items safety net —
project, tag, and user deletes in particular. This helper enforces an
opt-in ``--confirm`` flag: without it the command aborts with an
actionable multi-line error; with it the delete proceeds.

The error follows the ``_missing_tag_resolution`` pattern from
``kd.client``: a human-readable explanation plus a ``suggestion`` line
that spells out the literal retry command so an LLM reading the
stderr can proceed without extra reasoning.
"""

from __future__ import annotations

import shlex

from kd.exceptions import ValidationError


def require_confirm(
    *,
    confirmed: bool,
    command: str,
    entity_id: str,
    caveat: str,
) -> None:
    """Abort unless ``--confirm`` was passed.

    Args:
        confirmed: Whether the caller passed ``--confirm``.
        command: Full command path, e.g. ``/project delete``.
        entity_id: The target identifier as given on the command line.
        caveat: One or two sentences explaining why this particular
            delete is unsafe — the per-entity failure mode (issues
            vanishing, tag membership gone, identity refs detaching).
    """
    if confirmed:
        return
    raise ValidationError(
        f"kd {command} {entity_id} is irreversible. {caveat}",
        suggestion=(f"Retry with: kd {command} {shlex.quote(entity_id)} --confirm"),
    )
