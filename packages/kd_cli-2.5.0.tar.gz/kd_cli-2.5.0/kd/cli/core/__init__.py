"""CLI framework core — namespace system, command base, option registry."""

from kd.cli.core.command_base import Command, CommandResult
from kd.cli.core.namespaces import Namespace, NamespaceRegistry
from kd.cli.core.option_registry import (
    OUTPUT_OPTIONS,
    OptionDeclaration,
    OptionError,
    OptionLayer,
    OptionRegistry,
    ResolvedOptions,
)

__all__ = [
    "OUTPUT_OPTIONS",
    "Command",
    "CommandResult",
    "Namespace",
    "NamespaceRegistry",
    "OptionDeclaration",
    "OptionError",
    "OptionLayer",
    "OptionRegistry",
    "ResolvedOptions",
]
