"""Namespace tree and registry.

A Namespace is a node in the command tree (e.g., /system, /system/config).
Each namespace holds commands and optional sub-namespaces.
The NamespaceRegistry is the root of the tree.

Resolution is greedy left-to-right: ``kd system config set url value``
resolves to namespace=/system/config, command=set, args=[url, value].

Built-in command synonyms (e.g., ``get`` → ``show``) are loaded from
``kd/resources/command-synonyms.yaml`` and applied globally after
namespace registration. See :func:`load_synonyms` and :func:`apply_synonyms`.
"""

from __future__ import annotations

from importlib import resources as importlib_resources
from typing import TYPE_CHECKING

import yaml

if TYPE_CHECKING:
    from kd.cli.core.command_base import Command


class Namespace:
    """A node in the command tree."""

    def __init__(
        self,
        name: str,
        description: str,
        path: str = "",
    ) -> None:
        self.name = name
        self.description = description
        self.path = path
        self.commands: dict[str, Command] = {}
        self.sub_namespaces: dict[str, Namespace] = {}
        self.synonyms: dict[str, str] = {}

    def register_command(self, name: str, command: Command) -> None:
        """Register a command in this namespace."""
        self.commands[name] = command

    def register_sub_namespace(self, namespace: Namespace) -> None:
        """Register a child namespace."""
        self.sub_namespaces[namespace.name] = namespace

    def get_command(self, name: str) -> Command | None:
        """Look up a command by name, falling through to synonyms."""
        cmd = self.commands.get(name)
        if cmd is not None:
            return cmd
        canonical = self.synonyms.get(name)
        if canonical is not None:
            return self.commands.get(canonical)
        return None

    def get_sub_namespace(self, name: str) -> Namespace | None:
        """Look up a child namespace by name."""
        return self.sub_namespaces.get(name)


class NamespaceRegistry:
    """Root of the namespace tree. Resolves token sequences to commands."""

    def __init__(self) -> None:
        self.root = Namespace("kd", "Knowledge Dispatcher for issue trackers and knowledge bases")

    def register_namespace(self, namespace: Namespace) -> None:
        """Place a namespace in the tree by its path.

        Path segments are split on '/'. Intermediate namespaces are
        created automatically if they don't exist.

        Example: path="system/config" creates /system (if missing)
        then places the namespace as /system/config.
        """
        if not namespace.path:
            self.root.register_sub_namespace(namespace)
            return

        segments = namespace.path.split("/")
        parent = self.root

        # Navigate/create intermediate namespaces
        for segment in segments[:-1]:
            child = parent.get_sub_namespace(segment)
            if child is None:
                child = Namespace(segment, f"{segment} commands", path=segment)
                parent.register_sub_namespace(child)
            parent = child

        # Register using the last path segment as key (not namespace.name)
        parent.sub_namespaces[segments[-1]] = namespace

    def resolve(self, tokens: list[str]) -> tuple[Namespace, str, list[str]]:
        """Resolve tokens to (namespace, command_name, remaining_args).

        Uses greedy left-to-right matching: consumes tokens as namespace
        segments as long as matching sub-namespaces exist, then takes the
        next token as the command name.

        Returns empty command_name when no command token remains (bare
        namespace invocation — triggers discovery).

        Examples:
            ["system", "config", "set", "url", "val"]
            -> (system/config namespace, "set", ["url", "val"])

            ["system", "config"]
            -> (system/config namespace, "", [])

            []
            -> (root namespace, "", [])
        """
        if not tokens:
            return self.root, "", []

        current = self.root
        consumed = 0

        # Greedy namespace resolution
        for token in tokens:
            child = current.get_sub_namespace(token)
            if child is None:
                break
            current = child
            consumed += 1

        remaining = tokens[consumed:]

        if remaining:
            command_name = remaining[0]
            args = remaining[1:]
        else:
            command_name = ""
            args = []

        return current, command_name, args


# ---------------------------------------------------------------------------
# Built-in command synonyms
# ---------------------------------------------------------------------------


def load_synonyms() -> list[tuple[str, str]]:
    """Load synonym definitions from the YAML resource file.

    Returns a list of ``(synonym, canonical)`` pairs.
    """
    ref = importlib_resources.files("kd.resources").joinpath("command-synonyms.yaml")
    raw = yaml.safe_load(ref.read_text(encoding="utf-8"))
    return [(entry["synonym"], entry["canonical"]) for entry in raw]


def _apply_to_namespace(ns: Namespace, synonyms: list[tuple[str, str]]) -> None:
    """Apply synonyms to a single namespace (non-recursive)."""
    for synonym, canonical in synonyms:
        if canonical in ns.commands and synonym not in ns.commands:
            ns.synonyms[synonym] = canonical


def apply_synonyms(root: Namespace, synonyms: list[tuple[str, str]]) -> None:
    """Recursively apply synonym mappings to a namespace tree.

    For each namespace that has the canonical command and does *not*
    already define a command with the synonym name, a synonym entry
    is added.  Existing canonical commands are never overwritten.
    """
    _apply_to_namespace(root, synonyms)
    for child in root.sub_namespaces.values():
        apply_synonyms(child, synonyms)
