"""JetBrains Hub REST API wrapper.

Covers ``/hub/api/rest/...`` endpoints:
- Users: list, create, delete
- Project teams: list, add member
- Roles: list, assign to user for project

Hub uses UUIDs for all entity IDs. The ringId field on YT entities
bridges the two ID systems.
"""

from __future__ import annotations

from typing import Any

from kd.api.http import HttpClient
from kd.models import ProjectTeam, User, UserCreate


class HubAPI:
    """JetBrains Hub REST API wrapper (/hub/api/rest/...)."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    # --- Users ---

    def list_users(self, top: int = 100, skip: int = 0) -> list[User]:
        data = self._http.get(
            "/users",
            fields="id,login,name,email,banned",
            params={"$top": top, "$skip": skip},
        )
        users = data.get("users", data) if isinstance(data, dict) else data
        return [User.model_validate(u) for u in users]

    def create_user(self, user: UserCreate) -> User:
        data = self._http.post("/users", json=user.model_dump(exclude_none=True))
        return User.model_validate(data)

    def delete_user(self, hub_user_id: str) -> None:
        self._http.delete(f"/users/{hub_user_id}")

    # --- Project Teams ---

    def list_project_teams(self, top: int = 100, skip: int = 0) -> list[ProjectTeam]:
        data = self._http.get(
            "/projectteams",
            fields="id,name,project(id,name)",
            params={"$top": top, "$skip": skip},
        )
        teams = data.get("projectteams", data) if isinstance(data, dict) else data
        return [ProjectTeam.model_validate(t) for t in teams]

    def add_team_member(self, team_id: str, user_hub_id: str) -> None:
        self._http.post(f"/projectteams/{team_id}/users", json={"id": user_hub_id})

    # --- Roles ---

    def list_roles(self) -> list[dict[str, Any]]:
        data = self._http.get("/roles", fields="id,name,key", params={"$top": 50})
        roles: list[dict[str, Any]] = data.get("roles", data) if isinstance(data, dict) else data
        return roles

    def assign_role(self, hub_user_id: str, role_id: str, project_ring_id: str) -> None:
        self._http.post(
            f"/users/{hub_user_id}/projectroles",
            json={"role": {"id": role_id}, "project": {"id": project_ring_id}},
        )
