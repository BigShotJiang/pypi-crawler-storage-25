"""Saved queries REST API wrapper.

Covers ``/api/savedQueries`` CRUD plus the user-scoped listing at
``/api/users/{userID}/savedQueries``. Sharing settings
(``readSharingSettings`` / ``updateSharingSettings``) are deliberately
excluded from the default field set; M022 ships personal CRUD only and a
future milestone can layer permissions on top.
"""

from __future__ import annotations

from kd.api.http import HttpClient
from kd.models import FieldSet, SavedQuery, SavedQueryCreate, SavedQueryUpdate

_SAVED_QUERY_FIELDS = str(
    FieldSet(
        "id",
        "name",
        "query",
        owner=FieldSet("id", "name"),
    )
)


class SavedQueriesAPI:
    """Saved queries REST API wrapper (/api/savedQueries, /api/users/*/savedQueries)."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def list_saved_queries(self, top: int = 50, skip: int = 0) -> list[SavedQuery]:
        data = self._http.get(
            "/savedQueries",
            fields=_SAVED_QUERY_FIELDS,
            params={"$top": top, "$skip": skip},
        )
        return [SavedQuery.model_validate(sq) for sq in data]

    def get_saved_query(self, sq_id: str) -> SavedQuery:
        data = self._http.get(f"/savedQueries/{sq_id}", fields=_SAVED_QUERY_FIELDS)
        return SavedQuery.model_validate(data)

    def create_saved_query(self, sq: SavedQueryCreate) -> SavedQuery:
        data = self._http.post(
            "/savedQueries",
            json=sq.model_dump(by_alias=True),
            fields=_SAVED_QUERY_FIELDS,
        )
        return SavedQuery.model_validate(data)

    def update_saved_query(self, sq_id: str, update: SavedQueryUpdate) -> SavedQuery:
        data = self._http.post(
            f"/savedQueries/{sq_id}",
            json=update.model_dump(by_alias=True, exclude_none=True),
            fields=_SAVED_QUERY_FIELDS,
        )
        return SavedQuery.model_validate(data)

    def delete_saved_query(self, sq_id: str) -> None:
        self._http.delete(f"/savedQueries/{sq_id}")

    def list_user_saved_queries(
        self, user_id: str, top: int = 50, skip: int = 0
    ) -> list[SavedQuery]:
        """List saved queries owned by a specific user.

        The literal string ``"me"`` is accepted as ``user_id`` and resolves
        to the authenticated user server-side.
        """
        data = self._http.get(
            f"/users/{user_id}/savedQueries",
            fields=_SAVED_QUERY_FIELDS,
            params={"$top": top, "$skip": skip},
        )
        return [SavedQuery.model_validate(sq) for sq in data]
