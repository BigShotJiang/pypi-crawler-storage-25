"""Shared HTTP client.

Wraps httpx.Client with:
- Bearer token authentication
- Base URL management
- Explicit ``fields`` parameter support (YouTrack requires this)
- Error handling: maps HTTP errors to kd exceptions
- Retry logic for transient failures
"""

from __future__ import annotations

import json
import time
from typing import Any

import httpx

from kd.debug import DebugLog
from kd.exceptions import (
    APIError,
    AuthError,
    ConflictError,
    NotFoundError,
    PermissionDeniedError,
    enrich_error,
)

_RETRYABLE_STATUSES = {429, 502, 503}
_MAX_RETRIES = 3


class HttpClient:
    """Low-level HTTP client with auth, retry, and error mapping."""

    def __init__(
        self,
        base_url: str,
        token: str,
        timeout: float = 30.0,
        debug_log: DebugLog | None = None,
    ) -> None:
        self._debug = debug_log or DebugLog()
        self._client = httpx.Client(
            base_url=base_url,
            headers={
                "Authorization": f"Bearer {token}",
                "Accept": "application/json",
            },
            timeout=timeout,
        )

    def get(
        self,
        path: str,
        fields: str | None = None,
        params: dict[str, Any] | None = None,
    ) -> Any:
        """GET with automatic fields injection."""
        all_params: dict[str, Any] = dict(params or {})
        if fields:
            all_params["fields"] = fields
        response = self._request("GET", path, params=all_params)
        return self._decode_json(response)

    def post(
        self,
        path: str,
        json: dict[str, Any] | None = None,
        fields: str | None = None,
        params: dict[str, Any] | None = None,
    ) -> Any:
        """POST with optional fields on query string."""
        all_params: dict[str, Any] = dict(params or {})
        if fields:
            all_params["fields"] = fields
        response = self._request("POST", path, json=json, params=all_params or None)
        if response.status_code == 204 or not response.content:
            return {}
        return self._decode_json(response)

    def post_file(
        self,
        path: str,
        file_name: str,
        file_content: bytes,
        fields: str | None = None,
        params: dict[str, Any] | None = None,
    ) -> Any:
        """POST multipart file upload."""
        all_params: dict[str, Any] = dict(params or {})
        if fields:
            all_params["fields"] = fields
        response = self._request(
            "POST",
            path,
            files={"file": (file_name, file_content)},
            params=all_params or None,
        )
        if response.status_code == 204 or not response.content:
            return {}
        return self._decode_json(response)

    def get_bytes(
        self,
        path: str,
        params: dict[str, Any] | None = None,
    ) -> bytes:
        """GET raw bytes (for file downloads)."""
        response = self._request("GET", path, params=params)
        return response.content

    def delete(self, path: str) -> None:
        """DELETE. Returns nothing."""
        self._request("DELETE", path)

    def _request(self, method: str, path: str, **kwargs: Any) -> httpx.Response:
        """Execute request with retry and error mapping."""
        d = self._debug

        # Log request details before first attempt
        if params := kwargs.get("params"):
            d.debug("http", f"{method} {path}")
            d.debug("http", f"  params: {params}")
        else:
            d.debug("http", f"{method} {path}")

        if kwargs.get("json") is not None:
            d.trace("http", f"  body: {kwargs['json']}")
        d.trace("http", "  headers: Authorization=Bearer ***")

        start = time.monotonic()
        last_response: httpx.Response | None = None
        for attempt in range(_MAX_RETRIES):
            try:
                response = self._client.request(method, path, **kwargs)
            except httpx.HTTPError as e:
                d.info("http", f"{method} {path} -> connection error: {e}")
                raise APIError(0, f"Connection error: {e}") from e

            duration_ms = (time.monotonic() - start) * 1000

            if response.status_code < 400:
                d.info(
                    "http",
                    f"{method} {path} -> {response.status_code} ({duration_ms:.0f}ms)",
                )
                d.trace("http", f"  response: {response.text[:1000]}")
                return response

            last_response = response
            if response.status_code in _RETRYABLE_STATUSES and attempt < _MAX_RETRIES - 1:
                d.debug(
                    "http",
                    f"  retry {attempt + 1}/{_MAX_RETRIES} (status {response.status_code})",
                )
                continue

            d.info(
                "http",
                f"{method} {path} -> {response.status_code} ({duration_ms:.0f}ms) FAILED",
            )
            d.trace("http", f"  response: {response.text[:1000]}")
            self._raise_for_status(response)

        # Satisfy type checker — _raise_for_status always raises
        assert last_response is not None
        self._raise_for_status(last_response)
        raise AssertionError("unreachable")  # pragma: no cover

    @staticmethod
    def _decode_json(response: httpx.Response) -> Any:
        """Decode a 2xx response as JSON, guarding against non-JSON bodies.

        A misconfigured base URL (e.g. trailing slash producing ``//api/...``)
        can yield a 200 HTML page from YouTrack's web UI. Surface that as a
        clear APIError instead of letting ``JSONDecodeError`` bubble up.
        """
        content_type = response.headers.get("content-type", "")
        if "json" not in content_type.lower():
            url = str(response.request.url) if response.request else "<unknown>"
            raise APIError(
                response.status_code,
                (
                    f"Expected JSON response but got '{content_type or 'unknown'}' "
                    f"from {url}. Check the 'url' in your connection config — "
                    "a trailing slash or a non-YouTrack host can produce this."
                ),
                response.text[:500],
            )
        return response.json()

    @staticmethod
    def _extract_message(body: str) -> str:
        """Extract a human-readable message from a YouTrack error response.

        YouTrack returns structured JSON errors like::

            {"error": "invalid_query",
             "error_description": "Can't parse search query",
             "error_children": [{"error": "detail message"}]}

        This extracts the most specific message available, falling back
        to the raw body for non-JSON responses.
        """
        try:
            data = json.loads(body)
        except (json.JSONDecodeError, TypeError):
            return body

        if not isinstance(data, dict):
            return body

        # Most specific: child error messages
        children = data.get("error_children")
        if isinstance(children, list) and children:
            child_msgs = [c["error"] for c in children if isinstance(c, dict) and "error" in c]
            if child_msgs:
                return "; ".join(child_msgs)

        # Next: error_description
        desc = data.get("error_description")
        if desc:
            return str(desc)

        # Fallback: error field (often a code like "invalid_query")
        error = data.get("error")
        if error:
            return str(error)

        return body

    @staticmethod
    def _raise_for_status(response: httpx.Response) -> None:
        """Map HTTP status to kd exceptions. Always raises."""
        body = response.text
        status = response.status_code
        extracted = HttpClient._extract_message(body)
        request_path = response.request.url.path if response.request else None
        message, suggestion = enrich_error(extracted, status=status, path=request_path)
        if status == 401:
            raise AuthError(f"Authentication failed: {message}")
        if status == 403:
            body_lower = body.lower()
            if suggestion or "permission" in body_lower or "access" in body_lower:
                raise PermissionDeniedError(message, body, suggestion)
            raise APIError(403, f"Access denied: {message}", body, suggestion)
        if status == 404:
            raise NotFoundError(message, body, suggestion)
        if status == 409:
            raise ConflictError(message, body, suggestion)
        raise APIError(status, f"API error ({status}): {message}", body, suggestion)

    def close(self) -> None:
        """Close the underlying httpx client."""
        self._client.close()
