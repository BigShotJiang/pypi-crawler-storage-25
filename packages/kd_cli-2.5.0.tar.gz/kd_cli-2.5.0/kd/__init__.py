"""kd — knowledge dispatcher for live knowledge systems.

SDK-first design: import YouTrackClient for programmatic access,
or use the ``kd`` command for CLI operations.

Usage::

    from kd import YouTrackClient

    client = YouTrackClient(url="https://example.youtrack.cloud", token="...")
    projects = client.projects.list()
"""

from importlib.metadata import version as _pkg_version

__version__ = _pkg_version("kd-cli")

from kd.client import YouTrackClient
from kd.config import ConfigSource, ResolvedConfig, resolve_config
from kd.debug import DebugLevel, DebugLog
from kd.exceptions import (
    APIError,
    AuthError,
    ConfigError,
    ConflictError,
    NotFoundError,
    ValidationError,
    KdError,
)

__all__ = [
    "APIError",
    "AuthError",
    "ConfigError",
    "ConfigSource",
    "ConflictError",
    "DebugLevel",
    "DebugLog",
    "NotFoundError",
    "ResolvedConfig",
    "ValidationError",
    "YouTrackClient",
    "KdError",
    "resolve_config",
]
