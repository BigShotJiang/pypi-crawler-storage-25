"""Packaged resources for kd (config templates, etc.)."""
