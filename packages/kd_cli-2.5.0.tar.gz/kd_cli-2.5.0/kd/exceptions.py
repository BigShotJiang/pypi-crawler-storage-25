"""Exception hierarchy for kd.

All kd exceptions inherit from KdError. API-layer exceptions
carry the HTTP status code and response body for debugging.

Error messages from the YouTrack API are rewritten into user-friendly
text using regex mappings loaded from ``resources/error-messages.yaml``.
"""

from __future__ import annotations

import importlib.resources
import re
from typing import Any

import yaml


class KdError(Exception):
    """Base exception for all kd errors.

    Carries an optional :attr:`suggestion` that ``_print_error`` renders
    as a ``Hint:`` line. Subclasses may pass it through their own
    constructors or rely on this default.
    """

    def __init__(self, message: str, *, suggestion: str | None = None) -> None:
        self.suggestion = suggestion
        super().__init__(message)


class AuthError(KdError):
    """Token missing, invalid, or expired."""


class ConfigError(KdError):
    """Config file missing, malformed, or incomplete."""

    def __init__(self, message: str, suggestion: str | None = None) -> None:
        super().__init__(message, suggestion=suggestion)


class APIError(KdError):
    """HTTP error from YouTrack or Hub API."""

    def __init__(
        self,
        status_code: int,
        message: str,
        response_body: str = "",
        suggestion: str | None = None,
    ) -> None:
        self.status_code = status_code
        self.response_body = response_body
        super().__init__(message, suggestion=suggestion)


class NotFoundError(APIError):
    """404 — entity does not exist."""

    def __init__(
        self,
        message: str,
        response_body: str = "",
        suggestion: str | None = None,
    ) -> None:
        super().__init__(404, message, response_body, suggestion)


class ConflictError(APIError):
    """409 — duplicate project key, etc."""

    def __init__(
        self,
        message: str,
        response_body: str = "",
        suggestion: str | None = None,
    ) -> None:
        super().__init__(409, message, response_body, suggestion)


class PermissionDeniedError(APIError):
    """403 — insufficient permissions for the requested operation."""

    def __init__(
        self,
        message: str,
        response_body: str = "",
        suggestion: str | None = None,
    ) -> None:
        super().__init__(403, message, response_body, suggestion)


class ValidationError(KdError):
    """Invalid input before API call."""


class QueryLiteralError(KdError):
    """Name cannot be encoded as a YouTrack DSL value literal.

    Raised by :func:`kd.query_parser.youtrack_query_literal` for empty
    names or names containing characters kd cannot reliably brace-escape
    (``}`` or NUL). Callers that compose multi-term queries must fail
    the whole command; single-term callers can fall back to the
    ID-based tag endpoint.
    """


# ---------------------------------------------------------------------------
# Error message enrichment
# ---------------------------------------------------------------------------

_ErrorMapping = dict[str, Any]
_error_mappings: list[_ErrorMapping] | None = None


def _load_mappings() -> list[_ErrorMapping]:
    """Load and compile error message mappings from the resource file.

    Each entry supports three optional filters — ``status``, ``path``,
    and ``pattern`` — plus a required ``message`` and an optional
    ``suggestion``. All present filters must match for the rule to apply.
    """
    global _error_mappings  # noqa: PLW0603
    if _error_mappings is not None:
        return _error_mappings

    raw = (
        importlib.resources.files("kd.resources")
        .joinpath("error-messages.yaml")
        .read_text(encoding="utf-8")
    )
    entries: list[dict[str, Any]] = yaml.safe_load(raw) or []
    compiled: list[_ErrorMapping] = []
    for e in entries:
        compiled.append(
            {
                "status": e.get("status"),
                "path_re": re.compile(e["path"]) if e.get("path") else None,
                "msg_re": re.compile(e["pattern"]) if e.get("pattern") else None,
                "message": e["message"],
                "suggestion": e.get("suggestion", ""),
            }
        )
    _error_mappings = compiled
    return _error_mappings


def _substitute(
    template: str,
    named: dict[str, str],
    positional: tuple[str | None, ...],
) -> str:
    """Replace ``{name}`` and ``{1}..{N}`` placeholders in *template*.

    Unmatched optional groups (``None``) are skipped.
    """
    out = template
    for key, named_val in named.items():
        out = out.replace(f"{{{key}}}", named_val)
    for i, pos_val in enumerate(positional, 1):
        if pos_val is not None:
            out = out.replace(f"{{{i}}}", pos_val)
    return out


def enrich_error(
    message: str,
    *,
    status: int | None = None,
    path: str | None = None,
) -> tuple[str, str | None]:
    """Match *message* against known API error patterns.

    Rules may filter on HTTP ``status``, request URL ``path``, and/or
    the extracted response ``message`` text. All present filters must
    match. The first matching rule wins.

    Returns ``(rewritten_message, suggestion)`` if a rule matches,
    or ``(message, None)`` otherwise.
    """
    for mapping in _load_mappings():
        if mapping["status"] is not None and mapping["status"] != status:
            continue

        path_match: re.Match[str] | None = None
        if mapping["path_re"] is not None:
            if path is None:
                continue
            path_match = mapping["path_re"].search(path)
            if path_match is None:
                continue

        msg_match: re.Match[str] | None = None
        if mapping["msg_re"] is not None:
            msg_match = mapping["msg_re"].search(message)
            if msg_match is None:
                continue

        named: dict[str, str] = {}
        if path_match is not None:
            named.update({k: v for k, v in path_match.groupdict().items() if v is not None})
        if msg_match is not None:
            named.update({k: v for k, v in msg_match.groupdict().items() if v is not None})
        positional = msg_match.groups() if msg_match is not None else ()

        rewritten = _substitute(mapping["message"], named, positional)
        suggestion_tmpl = mapping["suggestion"] or None
        suggestion = _substitute(suggestion_tmpl, named, positional) if suggestion_tmpl else None
        return rewritten, suggestion
    return message, None
