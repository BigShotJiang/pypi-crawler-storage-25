"""Schema walker — Pydantic models are the single source of truth for config keys.

Walks :class:`kd.config.YtctlConfig` plus its nested models and yields one
:class:`ConfigKeyEntry` per settable leaf path. Variadic dict segments
(``connections.<name>``, ``projects.<key>``, ``defaults.<command_key>.<option>``)
are rendered as angle-bracketed placeholders.

Consumers:

- ``kd /system/config keys`` renders the catalog.
- ``kd /system/config set``/``get`` match a user-supplied dotted path against
  the catalog via :func:`resolve_path` and use the entry's ``annotation`` to
  coerce leaf values through Pydantic ``TypeAdapter``.
"""

from __future__ import annotations

import types
from dataclasses import dataclass
from typing import Any, Literal, Union, get_args, get_origin

from pydantic import BaseModel
from pydantic_core import PydanticUndefined

from kd.config import HistoryConfig, ProjectConfig, YtctlConfig
from kd.connection import CompatibilityConfig, ConnectionConfig


class _Missing:
    """Sentinel for 'required field, no default'."""

    _instance: _Missing | None = None

    def __new__(cls) -> _Missing:
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __repr__(self) -> str:
        return "MISSING"


MISSING = _Missing()


@dataclass(frozen=True)
class ConfigKeyEntry:
    """One settable config leaf path."""

    path: str
    annotation: Any
    type_label: str
    default: Any
    description: str | None


def walk_schema() -> list[ConfigKeyEntry]:
    """Enumerate every settable leaf path across the config schema."""
    entries: list[ConfigKeyEntry] = []
    _walk_model(YtctlConfig, prefix="", out=entries)
    return entries


def resolve_path(path: str) -> ConfigKeyEntry | None:
    """Match a concrete user path against the catalog.

    Variadic placeholder segments (``<name>``, ``<key>``, ``<alias>``,
    ``<command_key>``, ``<option>``) match any non-empty literal segment.
    Returns the catalog entry for the leaf, or ``None`` if no template matches.
    """
    user_segments = path.split(".")
    for entry in walk_schema():
        tmpl_segments = entry.path.split(".")
        if _segments_match(tmpl_segments, user_segments):
            return entry
    return None


def _segments_match(template: list[str], user: list[str]) -> bool:
    if len(template) != len(user):
        return False
    for t, u in zip(template, user):
        if not u:
            return False
        if _is_placeholder(t):
            continue
        if t != u:
            return False
    return True


def _is_placeholder(segment: str) -> bool:
    return segment.startswith("<") and segment.endswith(">")


# ---------------------------------------------------------------------------
# Walk helpers
# ---------------------------------------------------------------------------


def _walk_model(model: type[BaseModel], *, prefix: str, out: list[ConfigKeyEntry]) -> None:
    """Recurse into a Pydantic model, appending catalog entries."""
    for name, field in model.model_fields.items():
        path = f"{prefix}.{name}" if prefix else name
        annotation = field.annotation
        description = field.description
        default = _field_default(field)
        _walk_annotation(annotation, path, default, description, out)


def _walk_annotation(
    annotation: Any,
    path: str,
    default: Any,
    description: str | None,
    out: list[ConfigKeyEntry],
) -> None:
    """Dispatch an annotation: leaf, nested model, or dict[str, V]."""
    origin = get_origin(annotation)

    # Nested Pydantic model — descend.
    if origin is None and isinstance(annotation, type) and issubclass(annotation, BaseModel):
        _walk_model(annotation, prefix=path, out=out)
        return

    # dict[str, V] — descend with a variadic placeholder.
    if origin is dict:
        _walk_dict(annotation, path, description, out)
        return

    # Leaf.
    out.append(
        ConfigKeyEntry(
            path=path,
            annotation=annotation,
            type_label=_render_type(annotation),
            default=default,
            description=description,
        )
    )


def _walk_dict(
    annotation: Any,
    path: str,
    description: str | None,
    out: list[ConfigKeyEntry],
) -> None:
    """Render a ``dict[str, V]`` segment with a variadic placeholder."""
    _, value_type = get_args(annotation)
    placeholder = _placeholder_for(path)
    child_path = f"{path}.{placeholder}"

    if isinstance(value_type, type) and issubclass(value_type, BaseModel):
        _walk_model(value_type, prefix=child_path, out=out)
        return

    # dict[str, dict[str, Any]] — two levels of variadic placeholders.
    if get_origin(value_type) is dict:
        _, inner_value = get_args(value_type)
        inner_placeholder = _placeholder_for(child_path)
        inner_path = f"{child_path}.{inner_placeholder}"
        out.append(
            ConfigKeyEntry(
                path=inner_path,
                annotation=inner_value,
                type_label=_render_type(inner_value),
                default=MISSING,
                description=description,
            )
        )
        return

    # dict[str, scalar] — aliases.<name>, projects.<key>.field_aliases.<alias>, etc.
    out.append(
        ConfigKeyEntry(
            path=child_path,
            annotation=value_type,
            type_label=_render_type(value_type),
            default=MISSING,
            description=description,
        )
    )


# ---------------------------------------------------------------------------
# Placeholder names — one per dict segment, keyed on the parent path.
# ---------------------------------------------------------------------------

_PLACEHOLDERS: dict[str, str] = {
    "connections": "<name>",
    "projects": "<key>",
    "aliases": "<name>",
    "defaults": "<command_key>",
    "projects.<key>.defaults": "<command_key>",
    "projects.<key>.defaults.<command_key>": "<option>",
    "projects.<key>.field_aliases": "<alias>",
    "connections.<name>.defaults": "<command_key>",
    "connections.<name>.defaults.<command_key>": "<option>",
    "defaults.<command_key>": "<option>",
}


def _placeholder_for(path: str) -> str:
    return _PLACEHOLDERS.get(path, "<key>")


# ---------------------------------------------------------------------------
# Field defaults and type rendering
# ---------------------------------------------------------------------------


def _field_default(field: Any) -> Any:
    if field.default_factory is not None:
        try:
            return field.default_factory()
        except TypeError:
            return MISSING
    if field.default is PydanticUndefined:
        return MISSING
    return field.default


def _render_type(annotation: Any) -> str:
    """Human-readable type label for catalog output."""
    if annotation is Any:
        return "any"
    if annotation is type(None):
        return "None"

    origin = get_origin(annotation)
    if origin is Literal:
        args = get_args(annotation)
        inner = ", ".join(repr(a) for a in args)
        return f"Literal[{inner}]"

    if origin in (Union, types.UnionType):
        parts = [_render_type(a) for a in get_args(annotation)]
        return " | ".join(parts)

    if origin is dict:
        key_t, val_t = get_args(annotation)
        return f"dict[{_render_type(key_t)}, {_render_type(val_t)}]"

    if origin is list:
        (val_t,) = get_args(annotation)
        return f"list[{_render_type(val_t)}]"

    if isinstance(annotation, type):
        return annotation.__name__

    return str(annotation)


__all__ = [
    "ConfigKeyEntry",
    "MISSING",
    "walk_schema",
    "resolve_path",
    # Re-export model types for consumer convenience.
    "YtctlConfig",
    "ConnectionConfig",
    "CompatibilityConfig",
    "ProjectConfig",
    "HistoryConfig",
]
