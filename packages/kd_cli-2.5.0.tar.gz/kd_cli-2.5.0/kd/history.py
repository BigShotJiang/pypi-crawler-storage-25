"""Copy-on-write history for config and primer files.

Provides automatic snapshots before every mutation, retention pruning,
atomic file writes, and diff utilities. Snapshot files are stored in a
``history/`` subdirectory next to the original file.

Phase 1 — local snapshots only. Git auto-commit is deferred to Phase 2.
"""

from __future__ import annotations

import difflib
import logging
import os
import shutil
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import NamedTuple

from kd.exceptions import ConfigError, KdError

log = logging.getLogger(__name__)

DEFAULT_RETENTION = 20


# ---------------------------------------------------------------------------
# Atomic writes
# ---------------------------------------------------------------------------


def atomic_write_text(path: Path, text: str) -> None:
    """Write *text* to *path* atomically.

    Writes to a temp file in the same directory, then ``os.replace``
    to swap. Either the new content is fully committed or the old
    content is fully intact.
    """
    dir_ = str(path.parent) if str(path.parent) else "."
    fd, tmp = tempfile.mkstemp(dir=dir_, prefix=f".{path.name}.", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
            f.write(text)
        os.replace(tmp, path)
    except OSError as e:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise KdError(f"Cannot write to {path}: {e}") from e


# ---------------------------------------------------------------------------
# Timestamp helpers
# ---------------------------------------------------------------------------

_TS_FORMAT = "%Y-%m-%dT%H-%M-%S"


def _timestamp() -> str:
    """Return a filesystem-safe ISO 8601 timestamp (UTC, second precision)."""
    return datetime.now(timezone.utc).strftime(_TS_FORMAT)


def _parse_timestamp(ts: str) -> datetime:
    """Parse a filesystem-safe timestamp back to datetime."""
    return datetime.strptime(ts, _TS_FORMAT).replace(tzinfo=timezone.utc)


# ---------------------------------------------------------------------------
# Snapshot operations
# ---------------------------------------------------------------------------


def snapshot_before_write(path: Path, *, retention: int = DEFAULT_RETENTION) -> Path | None:
    """Copy *path* to ``<parent>/history/<name>.<timestamp>`` before mutation.

    Returns the snapshot path, or ``None`` if the file does not exist yet
    (first write — nothing to snapshot). Prunes oldest snapshots beyond
    *retention*. Best-effort: failures log a warning but do not block the
    caller's write.
    """
    if not path.exists():
        return None
    try:
        history_dir = path.parent / "history"
        history_dir.mkdir(parents=True, exist_ok=True)
        snapshot_name = f"{path.name}.{_timestamp()}"
        snapshot_path = history_dir / snapshot_name
        shutil.copy2(path, snapshot_path)
        _prune_snapshots(history_dir, path.name, retention)
        return snapshot_path
    except OSError as e:
        log.warning("Failed to snapshot %s: %s", path, e)
        return None


def _prune_snapshots(history_dir: Path, filename: str, retention: int) -> None:
    """Remove oldest snapshots of *filename* beyond *retention* count."""
    snapshots = _sorted_snapshots(history_dir, filename)
    for info in snapshots[retention:]:
        try:
            info.path.unlink()
        except OSError:
            pass


# ---------------------------------------------------------------------------
# Listing and lookup
# ---------------------------------------------------------------------------


class SnapshotInfo(NamedTuple):
    """Metadata for a single snapshot file."""

    path: Path
    timestamp: str
    size: int


def list_snapshots(history_dir: Path, filename: str) -> list[SnapshotInfo]:
    """Return snapshots for *filename*, newest first.

    Returns an empty list if the history directory does not exist.
    """
    if not history_dir.is_dir():
        return []
    return _sorted_snapshots(history_dir, filename)


def _sorted_snapshots(history_dir: Path, filename: str) -> list[SnapshotInfo]:
    """Glob and sort snapshots for *filename*, newest first."""
    prefix = f"{filename}."
    results: list[SnapshotInfo] = []
    for entry in history_dir.iterdir():
        if entry.name.startswith(prefix) and entry.is_file():
            ts = entry.name[len(prefix) :]
            try:
                _parse_timestamp(ts)
            except ValueError:
                continue  # skip files that don't match the timestamp format
            results.append(SnapshotInfo(path=entry, timestamp=ts, size=entry.stat().st_size))
    results.sort(key=lambda s: s.timestamp, reverse=True)
    return results


def get_snapshot_path(history_dir: Path, filename: str, timestamp: str) -> Path:
    """Resolve a snapshot by timestamp, or raise ``ConfigError``."""
    path = history_dir / f"{filename}.{timestamp}"
    if not path.is_file():
        raise ConfigError(f"Snapshot not found: {path.name}")
    return path


# ---------------------------------------------------------------------------
# Diff
# ---------------------------------------------------------------------------


def diff_text(text_a: str, text_b: str, label_a: str, label_b: str) -> str:
    """Return a unified diff between two text strings.

    Returns an empty string when the texts are identical.
    """
    lines_a = text_a.splitlines(keepends=True)
    lines_b = text_b.splitlines(keepends=True)
    diff = difflib.unified_diff(lines_a, lines_b, fromfile=label_a, tofile=label_b)
    return "".join(diff)
