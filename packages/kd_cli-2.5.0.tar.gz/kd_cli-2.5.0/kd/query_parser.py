"""Parse and compose YouTrack query fragments.

Two independent concerns live here:

* :func:`parse_article_query` extracts ``project:`` and ``tag:`` clauses
  from saved-query text so tag-based queries can be translated into
  article-tag lookups. Queries containing issue-specific fields (state,
  assignee, priority, etc.) are rejected with a clear error.
* :func:`youtrack_query_literal` is the inverse operation for tag/value
  literals: given a tag or value name supplied by the user, return the
  brace-wrapped form suitable for dropping into a ``tag: …`` predicate.
  Names that cannot be reliably escaped raise
  :class:`~kd.exceptions.QueryLiteralError`.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from kd.exceptions import QueryLiteralError, ValidationError

# Fields that only apply to issues and cannot be translated to article lookups.
_UNSUPPORTED_FIELDS = frozenset(
    {
        "state",
        "assignee",
        "for",
        "priority",
        "type",
        "has",
        "created",
        "updated",
        "resolved",
        "reporter",
        "sprint",
        "fix versions",
        "affected versions",
        "subsystem",
    }
)

_SUPPORTED_FIELDS = frozenset({"project", "tag"})

# Characters that force brace-wrapping in a YouTrack DSL value literal.
# Colons and whitespace are the common case (``kind:note``, ``Sprint 47``);
# comma/hash/parens/quotes/opening-brace are the tier-2 cases where the
# YouTrack parser would otherwise treat the character as syntax.
_MUST_WRAP_CHARS = frozenset(":,#(){'\"`")

# Characters kd refuses to encode — brace-wrapping cannot recover from them.
_REJECTED_CHARS = frozenset("}\x00")


@dataclass(frozen=True)
class ParsedQuery:
    """Result of parsing a YouTrack query for article-compatible fields."""

    project: str | None = None
    tags: list[str] = field(default_factory=list)


def parse_article_query(query: str) -> ParsedQuery:
    """Parse a YouTrack query string for article-compatible fields.

    Supported fields: ``project`` (at most one) and ``tag`` (zero or more).
    Raises :class:`~kd.exceptions.ValidationError` if unsupported
    issue-specific fields or ``#macros`` are found.
    """
    stripped = query.strip()
    if not stripped:
        return ParsedQuery()

    tokens = _tokenize(stripped)
    _reject_unsupported(tokens)

    project: str | None = None
    tags: list[str] = []

    for field_name, value in tokens:
        key = field_name.lower()
        if key == "project":
            project = value
        elif key == "tag":
            tags.append(value)

    return ParsedQuery(project=project, tags=tags)


def _tokenize(query: str) -> list[tuple[str, str]]:
    """Tokenize a YouTrack query into (field, value) pairs.

    Handles braced values (``tag: {multi word}``) and bare values
    (``tag: single``).  Also detects ``#macros`` like ``#Unresolved``.
    """
    tokens: list[tuple[str, str]] = []
    pos = 0
    length = len(query)

    while pos < length:
        # Skip whitespace.
        if query[pos].isspace():
            pos += 1
            continue

        # Detect #macros (e.g. #Unresolved, #Resolved).
        if query[pos] == "#":
            start = pos
            pos += 1
            while pos < length and not query[pos].isspace():
                pos += 1
            macro = query[start:pos]
            tokens.append(("#macro", macro))
            continue

        # Read a field name: word characters (letters, digits, underscore)
        # and spaces (for multi-word fields like "fix versions").
        field_start = pos
        while pos < length and query[pos] != ":":
            if query[pos].isspace():
                # Peek ahead: if there's a colon after optional words, it's
                # still part of a multi-word field name.  Otherwise stop.
                peek = pos
                while peek < length and query[peek].isspace():
                    peek += 1
                # If we hit a colon or another word char followed eventually
                # by a colon, continue.  Simple heuristic: look for colon
                # within the next token.
                colon_ahead = False
                scan = peek
                while scan < length and query[scan] not in (":", "#"):
                    if query[scan].isspace():
                        break
                    scan += 1
                if scan < length and query[scan] == ":":
                    # The next word ends with colon → multi-word field.
                    pos = peek
                    continue
                else:
                    colon_ahead = False  # noqa: F841
                    break
            pos += 1

        if pos >= length or query[pos] != ":":
            # Not a field: value pair — skip this word.
            pos += 1
            while pos < length and not query[pos].isspace():
                pos += 1
            continue

        field_name = query[field_start:pos].strip()
        pos += 1  # skip the colon

        # Skip whitespace after colon.
        while pos < length and query[pos].isspace():
            pos += 1

        if pos >= length:
            tokens.append((field_name, ""))
            break

        # Read the value: braced or bare.
        if query[pos] == "{":
            pos += 1  # skip opening brace
            value_start = pos
            while pos < length and query[pos] != "}":
                pos += 1
            value = query[value_start:pos]
            if pos < length:
                pos += 1  # skip closing brace
        else:
            value_start = pos
            while pos < length and not query[pos].isspace():
                pos += 1
            value = query[value_start:pos]

        tokens.append((field_name, value))

    return tokens


def _reject_unsupported(tokens: list[tuple[str, str]]) -> None:
    """Raise ValidationError if any tokens are unsupported for article queries."""
    unsupported: list[str] = []

    for field_name, value in tokens:
        if field_name == "#macro":
            unsupported.append(value)
            continue
        if field_name.lower() not in _SUPPORTED_FIELDS:
            unsupported.append(field_name)

    if unsupported:
        joined = ", ".join(unsupported)
        raise ValidationError(
            f"Cannot search articles with issue-specific fields: {joined}. "
            "Only project and tag are supported."
        )


def youtrack_query_literal(name: str) -> str:
    """Return *name* wrapped in braces when the YouTrack DSL requires it.

    Bare alphanumeric names (plus interior ``-``/``_``/``.``) pass
    through unchanged. Names containing ``:``, whitespace, ``,``, ``#``,
    ``(``, ``)``, ``{``, quote characters, or starting with ``-`` are
    wrapped as ``{name}``.

    Raises :class:`~kd.exceptions.QueryLiteralError` for names kd
    cannot reliably escape: empty string, ``}``, or embedded NUL.
    Callers that compose multi-term queries (e.g. ``tag: {A} tag: {B}``)
    must fail the whole command; single-term callers can fall back to
    the ID-based tag endpoint (``GET /api/tags/{id}/issues``).
    """
    if not name:
        raise QueryLiteralError(
            "Cannot encode an empty string as a YouTrack DSL value literal.",
            suggestion=(
                "Pass the tag or value name explicitly; an empty literal is "
                "never a valid query term."
            ),
        )

    rejected = _REJECTED_CHARS.intersection(name)
    if rejected:
        offender = "}" if "}" in rejected else "NUL"
        raise QueryLiteralError(
            f"Cannot encode {name!r} as a YouTrack DSL value literal (contains {offender}).",
            suggestion=(
                "For single-tag operations, resolve the tag by ID and use "
                "the ID-based endpoint (GET /api/tags/{id}/issues). Multi-tag "
                "operations must fail; rename the tag to a DSL-compatible form."
            ),
        )

    if (
        name.startswith("-")
        or any(ch.isspace() for ch in name)
        or not _MUST_WRAP_CHARS.isdisjoint(name)
    ):
        return f"{{{name}}}"

    return name
