"""Connection-aware token resolution.

Each connection resolves its token from one of two sources:

1. ``token_cmd`` — shell command that prints the token to stdout.
2. ``token_env`` — environment variable name containing the token.

Priority: ``token_cmd`` > ``token_env``.  Secrets never live in config
files — only references to external sources.
"""

from __future__ import annotations

import os
import subprocess
from typing import TYPE_CHECKING

from kd.exceptions import AuthError

if TYPE_CHECKING:
    from kd.config import ConnectionOrigin
    from kd.connection import ConnectionConfig
    from kd.debug import DebugLog


def resolve_connection_token(
    conn: ConnectionConfig,
    *,
    name: str | None = None,
    origin: ConnectionOrigin | None = None,
    debug_log: DebugLog | None = None,
) -> str:
    """Resolve the API token for a connection.

    Parameters
    ----------
    conn:
        The connection config whose auth sources to try.
    name:
        Optional connection name, used in error messages to name the
        failing connection.
    origin:
        Optional per-key origin map, used to cite the exact config file
        that declared the (now-broken) auth key.
    debug_log:
        Optional debug logger.

    Returns
    -------
    str
        The resolved token.

    Raises
    ------
    AuthError
        If no token can be resolved from any source. When *name* and
        *origin* are supplied, the error carries a multi-line
        ``.suggestion`` with connection-specific guidance and a
        ``Config: <path>`` pointer.
    """
    if conn.token_cmd:
        if debug_log:
            debug_log.info("auth", f"running token_cmd: {conn.token_cmd}")
        return _run_token_cmd(conn.token_cmd)

    if conn.token_env:
        if debug_log:
            debug_log.info("auth", f"reading token from env var: {conn.token_env}")
        value = os.environ.get(conn.token_env)
        if value:
            return value
        raise _missing_token_error(conn, name, origin)

    raise _no_auth_source_error(conn, name, origin)


def _run_token_cmd(cmd: str) -> str:
    """Execute a token command and return its stdout.

    Raises :class:`AuthError` on non-zero exit or empty output.
    """
    try:
        proc = subprocess.run(
            cmd,
            shell=True,  # noqa: S602 — user's own config, same trust as git credential.helper
            capture_output=True,
            text=True,
            timeout=10,
        )
    except subprocess.TimeoutExpired:
        raise AuthError(f"token_cmd timed out after 10s: {cmd}") from None

    if proc.returncode != 0:
        stderr = proc.stderr.strip()
        detail = f": {stderr}" if stderr else ""
        raise AuthError(f"token_cmd failed (exit {proc.returncode}){detail}: {cmd}")

    token = proc.stdout.strip()
    if not token:
        raise AuthError(f"token_cmd returned empty output: {cmd}")

    return token


def _missing_token_error(
    conn: ConnectionConfig,
    name: str | None,
    origin: ConnectionOrigin | None,
) -> AuthError:
    """Build an ``AuthError`` for a ``token_env`` that points at an unset var."""
    env_name = conn.token_env or "<token_env>"
    where = _describe_connection(conn, name)
    message = f"{where} needs a token — environment variable '{env_name}' is not set."
    suggestion = _build_suggestion(
        lines=[
            f"Either export {env_name} or configure `token_cmd:` on the connection:",
            f"  connections.{name or '<name>'}.token_cmd: gopass show -o path/to/token",
        ],
        origin=origin,
        key="token_env",
    )
    return AuthError(message, suggestion=suggestion)


def _no_auth_source_error(
    conn: ConnectionConfig,
    name: str | None,
    origin: ConnectionOrigin | None,
) -> AuthError:
    """Build an ``AuthError`` for a connection with no ``token_cmd`` or ``token_env``."""
    where = _describe_connection(conn, name)
    message = f"{where} has no auth source configured."
    suggestion = _build_suggestion(
        lines=[
            "Set one of `token_cmd:` or `token_env:` on the connection:",
            f"  connections.{name or '<name>'}.token_cmd: gopass show -o path/to/token",
            f"  connections.{name or '<name>'}.token_env: KD_{(name or 'NAME').upper()}_TOKEN",
        ],
        origin=origin,
        key=None,
    )
    return AuthError(message, suggestion=suggestion)


def _describe_connection(conn: ConnectionConfig, name: str | None) -> str:
    """Render the ``Connection '<name>' (<url>)`` prefix, degraded when no name."""
    if name:
        return f"Connection '{name}' ({conn.url})"
    return f"Connection ({conn.url})"


def _build_suggestion(
    *,
    lines: list[str],
    origin: ConnectionOrigin | None,
    key: str | None,
) -> str:
    """Assemble a multi-line suggestion, appending ``Config: <path>`` when known.

    When *origin* is provided, prefer the per-key origin for *key* (which
    points at the exact file declaring that key); fall back to the
    connection's primary path. Omit the line entirely when no origin is
    known so tests and ad-hoc callers don't see a dangling ``Config:``.
    """
    path: str | None = None
    if origin is not None:
        if key and key in origin.keys:
            path = origin.keys[key].path
        else:
            path = origin.path
    if path:
        lines = [*lines, f"Config: {path}"]
    return "\n".join(lines)
