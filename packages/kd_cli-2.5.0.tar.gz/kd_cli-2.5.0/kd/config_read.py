"""Path-oriented reads against a resolved config.

Inverse of :func:`kd.config.update_config_path`. Walks a dotted path
against a :class:`~kd.config.ResolvedConfig` and returns the leaf value
with source + origin attribution, matching the attribution shape that
``kd /system/config get`` surfaces.
"""

from __future__ import annotations

from typing import Any

import yaml

from kd.config import DEFAULT_CONFIG_PATH, ResolvedConfig, find_local_config, load_config


def get_config_path(rc: ResolvedConfig, path: str) -> dict[str, Any] | None:
    """Resolve a nested dotted path to ``{path, value, source, origin}``.

    Returns ``None`` when the path is legal but unset — callers wrap that
    into ``{path, value: None}``.
    """
    segments = path.split(".")
    root = segments[0]
    if root == "connections" and len(segments) >= 3:
        return _get_connection(rc, segments, path)
    if root == "defaults":
        return _get_from_section(
            path, segments[1:], [("local", rc.local_defaults), ("global", rc.global_defaults)]
        )
    if root == "projects":
        return _get_project(rc, segments, path)
    if root == "aliases" and len(segments) == 2:
        return _get_from_section(
            path, segments[1:], [("local", rc.local_aliases), ("global", rc.global_aliases)]
        )
    if root == "history" and len(segments) == 2:
        return _get_history(path, segments[1])
    return None


def _get_connection(rc: ResolvedConfig, segments: list[str], path: str) -> dict[str, Any] | None:
    name = segments[1]
    conn = rc.connections.get(name)
    if conn is None:
        return None
    # connections.<name>.<key>
    if len(segments) == 3:
        key = segments[2]
        value = getattr(conn, key, None)
        if value is None or (isinstance(value, (dict, list)) and not value):
            return None
        origin = rc.connection_origins.get(name)
        key_origin = origin.keys.get(key) if origin else None
        if key_origin is not None:
            return {
                "path": path,
                "value": _render_value(value),
                "source": key_origin.source,
                "origin": key_origin.path,
            }
        return {
            "path": path,
            "value": _render_value(value),
            "source": origin.source if origin else "",
            "origin": origin.path if origin else "",
        }
    # connections.<name>.compatibility.<field>
    if len(segments) == 4 and segments[2] == "compatibility":
        compat = conn.compatibility
        field_name = segments[3]
        value = getattr(compat, field_name, None)
        if value is None:
            return None
        origin = rc.connection_origins.get(name)
        key_origin = origin.keys.get("compatibility") if origin else None
        source = key_origin.source if key_origin else (origin.source if origin else "")
        origin_path = key_origin.path if key_origin else (origin.path if origin else "")
        return {
            "path": path,
            "value": _render_value(value),
            "source": source,
            "origin": origin_path,
        }
    # connections.<name>.defaults.<cmd>.<opt>
    if len(segments) == 5 and segments[2] == "defaults":
        cmd, opt = segments[3], segments[4]
        defaults = conn.defaults.get(cmd) if isinstance(conn.defaults, dict) else None
        if not isinstance(defaults, dict) or opt not in defaults:
            return None
        origin = rc.connection_origins.get(name)
        key_origin = origin.keys.get("defaults") if origin else None
        source = key_origin.source if key_origin else (origin.source if origin else "")
        origin_path = key_origin.path if key_origin else (origin.path if origin else "")
        return {
            "path": path,
            "value": _render_value(defaults[opt]),
            "source": source,
            "origin": origin_path,
        }
    return None


def _get_project(rc: ResolvedConfig, segments: list[str], path: str) -> dict[str, Any] | None:
    if len(segments) < 4:
        return None
    key = segments[1]
    section = segments[2]
    for source_label, projects in (("local", rc.local_projects), ("global", rc.global_projects)):
        proj = projects.get(key)
        if not isinstance(proj, dict):
            continue
        if section == "field_aliases" and len(segments) == 4:
            aliases = proj.get("field_aliases")
            if isinstance(aliases, dict) and segments[3] in aliases:
                return {
                    "path": path,
                    "value": _render_value(aliases[segments[3]]),
                    "source": source_label,
                    "origin": "",
                }
        if section == "defaults" and len(segments) == 5:
            defaults = proj.get("defaults")
            if isinstance(defaults, dict):
                cmd = defaults.get(segments[3])
                if isinstance(cmd, dict) and segments[4] in cmd:
                    return {
                        "path": path,
                        "value": _render_value(cmd[segments[4]]),
                        "source": source_label,
                        "origin": "",
                    }
    return None


def _get_from_section(
    path: str,
    remaining: list[str],
    sources: list[tuple[str, dict[str, Any]]],
) -> dict[str, Any] | None:
    """Walk a flat or nested dict section across local/global sources."""
    for source_label, section in sources:
        value = _walk_dict(section, remaining)
        if value is not None:
            return {
                "path": path,
                "value": _render_value(value),
                "source": source_label,
                "origin": "",
            }
    return None


def _walk_dict(data: Any, segments: list[str]) -> Any:
    current: Any = data
    for seg in segments:
        if not isinstance(current, dict) or seg not in current:
            return None
        current = current[seg]
    return current


def _get_history(path: str, key: str) -> dict[str, Any] | None:
    """``history`` is not exposed on ResolvedConfig — read both tiers directly."""
    for source_label, tier_path in (
        ("local", find_local_config()),
        ("global", DEFAULT_CONFIG_PATH),
    ):
        if tier_path is None or not tier_path.exists():
            continue
        cfg = load_config(tier_path)
        value = getattr(cfg.history, key, None)
        if value is None:
            continue
        # Only surface values actually written to the file, not schema defaults.
        raw = yaml.safe_load(tier_path.read_text()) or {}
        history_block = raw.get("history") if isinstance(raw.get("history"), dict) else {}
        if not isinstance(history_block, dict) or key not in history_block:
            continue
        return {
            "path": path,
            "value": _render_value(value),
            "source": source_label,
            "origin": str(tier_path),
        }
    return None


def _render_value(value: Any) -> Any:
    """Render a resolved value for output — keep scalars, stringify everything else."""
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)
