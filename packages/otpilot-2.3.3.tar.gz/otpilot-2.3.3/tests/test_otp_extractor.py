import pytest

from otpilot.otp_extractor import extract_otp


def test_extract_from_subject_basic():
    """Extracts OTP from subject when present."""
    emails = [{"subject": "Your OTP is 123456", "body": "Body", "sender": ""}]
    assert extract_otp(emails) == "123456"


def test_extract_4_digit_otp():
    """Extracts 4-digit OTPs from subject."""
    emails = [{"subject": "Your code is 1234", "body": "", "sender": ""}]
    assert extract_otp(emails) == "1234"


def test_extract_8_digit_otp():
    """Extracts 8-digit OTPs from subject."""
    emails = [{"subject": "Your code is 12345678", "body": "", "sender": ""}]
    assert extract_otp(emails) == "12345678"


def test_subject_match_beats_body_match():
    """Prefers subject match over body match in older emails."""
    emails = [
        {"subject": "Your code is 111111", "body": "", "sender": ""},
        {"subject": "", "body": "Your code is 222222", "sender": ""},
    ]
    assert extract_otp(emails) == "111111"


@pytest.mark.parametrize(
    "keyword",
    [
        "otp",
        "code",
        "verify",
        "verification",
        "one-time",
        "passcode",
        "pin",
        "token",
        "authentication",
        "confirm",
        "security",
        "login",
        "sign-in",
        "2fa",
        "mfa",
    ],
)
def test_all_context_keywords_trigger_extraction(keyword):
    """Extracts OTP for every context keyword."""
    emails = [{"subject": f"Your {keyword} is 123456", "body": "", "sender": ""}]
    assert extract_otp(emails) == "123456"


def test_does_not_extract_9_digit_number():
    """Does not extract 9-digit numbers."""
    emails = [{"subject": "Your otp is 123456789", "body": "", "sender": ""}]
    assert extract_otp(emails) is None


def test_does_not_extract_3_digit_number():
    """Does not extract 3-digit numbers."""
    emails = [{"subject": "Your otp is 123", "body": "", "sender": ""}]
    assert extract_otp(emails) is None


def test_does_not_extract_number_inside_larger_number():
    """Does not extract digits embedded in larger numbers."""
    emails = [{"subject": "Your otp is 1234567890", "body": "", "sender": ""}]
    assert extract_otp(emails) is None


def test_empty_email_list():
    """Returns None when no emails are supplied."""
    assert extract_otp([]) is None


def test_empty_subject_and_body():
    """Returns None for emails without content."""
    emails = [{"subject": "", "body": "", "sender": ""}]
    assert extract_otp(emails) is None


def test_no_context_keyword_no_extraction():
    """Does not extract numbers without context keywords."""
    emails = [{"subject": "Your number is 123456", "body": "", "sender": ""}]
    assert extract_otp(emails) is None


def test_multiple_emails_returns_first_subject_match():
    """Returns the first subject match across emails."""
    emails = [
        {"subject": "Your code is 123456", "body": "", "sender": ""},
        {"subject": "Your code is 654321", "body": "", "sender": ""},
    ]
    assert extract_otp(emails) == "123456"


def test_otp_in_body_only():
    """Extracts OTP from body when subject has none."""
    emails = [{"subject": "Hello", "body": "Your code is 123456", "sender": ""}]
    assert extract_otp(emails) == "123456"


def test_none_when_nothing_found():
    """Returns None when no OTPs are found."""
    emails = [{"subject": "Hello", "body": "No code here", "sender": ""}]
    assert extract_otp(emails) is None


def test_email_missing_subject_key():
    """Handles missing subject key gracefully."""
    emails = [{"body": "Your code is 123456", "sender": ""}]
    assert extract_otp(emails) == "123456"


def test_email_missing_body_key():
    """Handles missing body key gracefully."""
    emails = [{"subject": "Your code is 123456", "sender": ""}]
    assert extract_otp(emails) == "123456"


def test_extract_otp_surrounded_by_spaces():
    """Extracts OTP surrounded by extra whitespace."""
    emails = [{"subject": "Your code is  123456  ", "body": "", "sender": ""}]
    assert extract_otp(emails) == "123456"


def test_extract_otp_at_end_of_sentence():
    """Extracts OTP when followed by punctuation."""
    emails = [{"subject": "Your code is 123456.", "body": "", "sender": ""}]
    assert extract_otp(emails) == "123456"
