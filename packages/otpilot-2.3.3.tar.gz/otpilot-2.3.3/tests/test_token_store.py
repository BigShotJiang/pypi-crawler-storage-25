import json

from otpilot import token_store


class FakeKeyring:
    def __init__(self):
        self.store = {}

    def set_password(self, service, account, value):
        self.store[(service, account)] = value

    def get_password(self, service, account):
        return self.store.get((service, account))


def test_save_and_load_via_file_fallback(tmp_config_dir, monkeypatch):
    """Uses file fallback when keyring is unavailable."""
    monkeypatch.setattr(token_store, "_load_keytar", lambda: None)
    payload = {"access_token": "abc"}
    token_store.save_token(payload)
    loaded = token_store.load_token()
    assert loaded == payload


def test_save_and_load_via_keyring(monkeypatch):
    """Uses keyring storage when available."""
    keyring = FakeKeyring()
    monkeypatch.setattr(token_store, "_load_keytar", lambda: keyring)
    payload = {"access_token": "xyz"}
    token_store.save_token(payload)
    loaded = token_store.load_token()
    assert loaded == payload


def test_load_returns_none_when_no_token(tmp_config_dir, monkeypatch):
    """Returns None when no token is stored."""
    monkeypatch.setattr(token_store, "_load_keytar", lambda: None)
    assert token_store.load_token() is None


def test_token_exists_true_when_token_present(tmp_config_dir, monkeypatch):
    """Returns True when token exists in storage."""
    monkeypatch.setattr(token_store, "_load_keytar", lambda: None)
    token_store.save_token({"access_token": "abc"})
    assert token_store.token_exists() is True


def test_token_exists_false_when_missing(tmp_config_dir, monkeypatch):
    """Returns False when token is missing."""
    monkeypatch.setattr(token_store, "_load_keytar", lambda: None)
    assert token_store.token_exists() is False


def test_load_handles_corrupt_token_file(tmp_config_dir, monkeypatch):
    """Returns None when token file is corrupt."""
    monkeypatch.setattr(token_store, "_load_keytar", lambda: None)
    (tmp_config_dir / "token.json").write_text("not json", encoding="utf-8")
    assert token_store.load_token() is None


def test_keyring_failure_falls_back_to_file(tmp_config_dir, monkeypatch):
    """Falls back to file when keyring set_password fails."""
    class FailingKeyring(FakeKeyring):
        def set_password(self, service, account, value):
            raise RuntimeError("fail")

    monkeypatch.setattr(token_store, "_load_keytar", lambda: FailingKeyring())
    payload = {"access_token": "abc"}
    token_store.save_token(payload)
    saved = json.loads((tmp_config_dir / "token.json").read_text(encoding="utf-8"))
    assert saved == payload
