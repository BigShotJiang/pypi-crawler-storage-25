import importlib
import sys


class FakePlyerNotification:
    def __init__(self):
        self.calls = []

    def notify(self, **kwargs):
        self.calls.append(kwargs)


def test_notify_macos_calls_osascript(monkeypatch):
    """Calls osascript on macOS notifications."""
    import otpilot.notifier as notifier

    notifier = importlib.reload(notifier)
    called = {}

    def fake_popen(args, stdout=None, stderr=None):
        called["args"] = args
        return None

    monkeypatch.setattr(notifier.sys, "platform", "darwin")
    monkeypatch.setattr(notifier.subprocess, "Popen", fake_popen)
    monkeypatch.setattr(notifier, "get_config", lambda: {"notification_sound": False})

    notifier.notify("Title", "Message")

    assert called["args"][0] == "osascript"
    assert "display notification" in called["args"][2]


def test_notify_non_macos_calls_plyer(monkeypatch):
    """Calls plyer notification backend on non-macOS."""
    import otpilot.notifier as notifier

    notifier = importlib.reload(notifier)

    fake_notification = FakePlyerNotification()
    fake_plyer = type("fake", (), {"notification": fake_notification})
    monkeypatch.setitem(sys.modules, "plyer", fake_plyer)

    monkeypatch.setattr(notifier.sys, "platform", "linux")
    monkeypatch.setattr(notifier, "get_config", lambda: {"notification_sound": False})

    notifier.notify("Title", "Message")

    assert fake_notification.calls


def test_notify_swallows_exceptions(monkeypatch):
    """Swallows exceptions raised by notification backend."""
    import otpilot.notifier as notifier

    notifier = importlib.reload(notifier)

    monkeypatch.setattr(notifier.sys, "platform", "linux")
    monkeypatch.setattr(notifier, "_notify_plyer", lambda *args, **kwargs: (_ for _ in ()).throw(RuntimeError("fail")))

    notifier.notify("Title", "Message")


def test_sound_played_when_enabled(monkeypatch):
    """Plays sound when notification_sound is enabled."""
    import otpilot.notifier as notifier

    notifier = importlib.reload(notifier)
    called = {"sound": False}

    monkeypatch.setattr(notifier, "get_config", lambda: {"notification_sound": True})
    monkeypatch.setattr(notifier, "_notify_plyer", lambda *args, **kwargs: None)
    monkeypatch.setattr(notifier, "_play_notification_sound", lambda: called.update(sound=True))

    notifier.notify("Title", "Message")

    assert called["sound"] is True


def test_sound_not_played_when_disabled(monkeypatch):
    """Does not play sound when notification_sound is disabled."""
    import otpilot.notifier as notifier

    notifier = importlib.reload(notifier)
    called = {"sound": False}

    monkeypatch.setattr(notifier, "get_config", lambda: {"notification_sound": False})
    monkeypatch.setattr(notifier, "_notify_plyer", lambda *args, **kwargs: None)
    monkeypatch.setattr(notifier, "_play_notification_sound", lambda: called.update(sound=True))

    notifier.notify("Title", "Message")

    assert called["sound"] is False


def test_sound_failure_does_not_propagate(monkeypatch):
    """Swallows errors raised by notification sound."""
    import otpilot.notifier as notifier

    notifier = importlib.reload(notifier)

    monkeypatch.setattr(notifier, "get_config", lambda: {"notification_sound": True})
    monkeypatch.setattr(notifier, "_notify_plyer", lambda *args, **kwargs: None)
    monkeypatch.setattr(notifier, "_play_notification_sound", lambda: (_ for _ in ()).throw(RuntimeError("fail")))

    notifier.notify("Title", "Message")
