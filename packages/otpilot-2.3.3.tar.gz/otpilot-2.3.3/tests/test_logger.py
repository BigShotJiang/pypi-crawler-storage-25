import logging
import os


def _reset_logger(name):
    logger = logging.getLogger(name)
    for handler in list(logger.handlers):
        logger.removeHandler(handler)
    return logger


def test_logger_creates_log_file(tmp_config_dir, monkeypatch):
    """Creates log file on first write."""
    import otpilot.logger as logger_module

    monkeypatch.setattr(logger_module, "LOG_FILE", str(tmp_config_dir / "otpilot.log"))
    _reset_logger("otpilot-test")

    logger = logger_module.get_logger("otpilot-test")
    logger.info("hello")
    for handler in logger.handlers:
        handler.flush()

    assert (tmp_config_dir / "otpilot.log").exists()


def test_logger_writes_messages(tmp_config_dir, monkeypatch):
    """Writes log messages to log file."""
    import otpilot.logger as logger_module

    monkeypatch.setattr(logger_module, "LOG_FILE", str(tmp_config_dir / "otpilot.log"))
    _reset_logger("otpilot-write")

    logger = logger_module.get_logger("otpilot-write")
    logger.info("hello")
    for handler in logger.handlers:
        handler.flush()

    content = (tmp_config_dir / "otpilot.log").read_text(encoding="utf-8")
    assert "hello" in content


def test_get_logger_returns_same_instance_on_second_call(tmp_config_dir, monkeypatch):
    """Does not add duplicate handlers on repeated calls."""
    import otpilot.logger as logger_module

    monkeypatch.setattr(logger_module, "LOG_FILE", str(tmp_config_dir / "otpilot.log"))
    _reset_logger("otpilot-dup")

    logger1 = logger_module.get_logger("otpilot-dup")
    logger2 = logger_module.get_logger("otpilot-dup")

    assert logger1 is logger2
    assert len(logger1.handlers) == 1


def test_logger_rotates_at_max_bytes(tmp_config_dir, monkeypatch):
    """Rotates log file when max size is exceeded."""
    import otpilot.logger as logger_module

    monkeypatch.setattr(logger_module, "LOG_FILE", str(tmp_config_dir / "otpilot.log"))
    _reset_logger("otpilot-rotate")

    logger = logger_module.get_logger("otpilot-rotate")
    logger.info("warmup")
    logger.info("x" * 1_000_100)
    for handler in logger.handlers:
        handler.flush()

    assert os.path.exists(str(tmp_config_dir / "otpilot.log.1"))


def test_logger_keeps_correct_backup_count(tmp_config_dir, monkeypatch):
    """Keeps configured backup count on handler."""
    import otpilot.logger as logger_module

    monkeypatch.setattr(logger_module, "LOG_FILE", str(tmp_config_dir / "otpilot.log"))
    _reset_logger("otpilot-backup")

    logger = logger_module.get_logger("otpilot-backup")
    handler = logger.handlers[0]
    assert handler.backupCount == 3


def test_log_format_includes_level_and_name(tmp_config_dir, monkeypatch):
    """Includes level and logger name in log format."""
    import otpilot.logger as logger_module

    monkeypatch.setattr(logger_module, "LOG_FILE", str(tmp_config_dir / "otpilot.log"))
    _reset_logger("otpilot-format")

    logger = logger_module.get_logger("otpilot-format")
    logger.info("hello")
    for handler in logger.handlers:
        handler.flush()

    content = (tmp_config_dir / "otpilot.log").read_text(encoding="utf-8")
    assert "[INFO]" in content
    assert "otpilot-format" in content
