import pytest

from otpilot.clipboard import ClipboardError, copy_to_clipboard


def test_copy_to_clipboard_success(monkeypatch):
    """Copies to clipboard without error."""
    monkeypatch.setattr("otpilot.clipboard.pyperclip.copy", lambda *_: None)
    copy_to_clipboard("123456")


def test_copy_to_clipboard_raises_clipboard_error_on_pyperclip_failure(monkeypatch):
    """Raises ClipboardError on PyperclipException."""
    import pyperclip

    def raise_exc(_):
        raise pyperclip.PyperclipException("fail")

    monkeypatch.setattr("otpilot.clipboard.pyperclip.copy", raise_exc)
    with pytest.raises(ClipboardError):
        copy_to_clipboard("123456")


def test_copy_to_clipboard_raises_on_unexpected_exception(monkeypatch):
    """Raises ClipboardError on unexpected exception."""
    monkeypatch.setattr("otpilot.clipboard.pyperclip.copy", lambda *_: (_ for _ in ()).throw(RuntimeError("boom")))
    with pytest.raises(ClipboardError):
        copy_to_clipboard("123456")


def test_clipboard_error_default_message():
    """Uses default ClipboardError message."""
    assert str(ClipboardError())


def test_clipboard_error_custom_message():
    """Uses custom ClipboardError message."""
    assert str(ClipboardError("custom")) == "custom"
