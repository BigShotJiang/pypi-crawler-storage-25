import importlib
import json


def _reload_history(monkeypatch, tmp_config_dir):
    import otpilot.history as history

    history = importlib.reload(history)
    monkeypatch.setattr(history, "CONFIG_DIR", tmp_config_dir)
    monkeypatch.setattr(history, "HISTORY_FILE", tmp_config_dir / "history.json")
    return history


def test_save_entry_creates_file(tmp_config_dir, monkeypatch):
    """Creates history file when saving first entry."""
    history = _reload_history(monkeypatch, tmp_config_dir)
    monkeypatch.setattr(history, "get_config", lambda: {"otp_history_count": 10})

    history.save_entry("123456")

    assert (tmp_config_dir / "history.json").exists()


def test_save_entry_prepends_newest_first(tmp_config_dir, monkeypatch):
    """Prepends newest entry to history list."""
    history = _reload_history(monkeypatch, tmp_config_dir)
    monkeypatch.setattr(history, "get_config", lambda: {"otp_history_count": 10})

    history.save_entry("111111")
    history.save_entry("222222")

    data = json.loads((tmp_config_dir / "history.json").read_text(encoding="utf-8"))
    assert data[0]["otp"] == "222222"


def test_history_trimmed_to_otp_history_count(tmp_config_dir, monkeypatch):
    """Trims history to configured count."""
    history = _reload_history(monkeypatch, tmp_config_dir)
    monkeypatch.setattr(history, "get_config", lambda: {"otp_history_count": 2})

    history.save_entry("111111")
    history.save_entry("222222")
    history.save_entry("333333")

    data = json.loads((tmp_config_dir / "history.json").read_text(encoding="utf-8"))
    assert len(data) == 2


def test_load_history_returns_empty_list_when_missing(tmp_config_dir, monkeypatch):
    """Returns empty list when history file is missing."""
    history = _reload_history(monkeypatch, tmp_config_dir)
    assert history.load_history() == []


def test_load_history_returns_empty_list_on_corrupt_file(tmp_config_dir, monkeypatch):
    """Returns empty list when history file is corrupt."""
    history = _reload_history(monkeypatch, tmp_config_dir)
    (tmp_config_dir / "history.json").write_text("{bad}", encoding="utf-8")
    assert history.load_history() == []


def test_clear_history_empties_file(tmp_config_dir, monkeypatch):
    """Deletes history file when clearing."""
    history = _reload_history(monkeypatch, tmp_config_dir)
    (tmp_config_dir / "history.json").write_text("[]", encoding="utf-8")

    history.clear_history()

    assert not (tmp_config_dir / "history.json").exists()


def test_clear_history_noop_when_file_missing(tmp_config_dir, monkeypatch):
    """Does nothing when history file is missing."""
    history = _reload_history(monkeypatch, tmp_config_dir)
    history.clear_history()


def test_entry_schema_contains_required_keys(tmp_config_dir, monkeypatch):
    """Ensures history entries contain required keys."""
    history = _reload_history(monkeypatch, tmp_config_dir)
    monkeypatch.setattr(history, "get_config", lambda: {"otp_history_count": 10})

    history.save_entry("123456", sender="a", subject="b")

    data = json.loads((tmp_config_dir / "history.json").read_text(encoding="utf-8"))
    entry = data[0]
    assert set(entry.keys()) >= {"otp", "timestamp", "sender", "subject"}


def test_otp_history_count_zero_stores_nothing(tmp_config_dir, monkeypatch):
    """Does not store entries when otp_history_count is zero."""
    history = _reload_history(monkeypatch, tmp_config_dir)
    monkeypatch.setattr(history, "get_config", lambda: {"otp_history_count": 0})

    history.save_entry("123456")

    assert not (tmp_config_dir / "history.json").exists()


def test_otp_history_count_max_50_enforced(tmp_config_dir, monkeypatch):
    """Caps otp_history_count at 50."""
    history = _reload_history(monkeypatch, tmp_config_dir)
    monkeypatch.setattr(history, "get_config", lambda: {"otp_history_count": 100})

    for i in range(60):
        history.save_entry(str(i))

    data = json.loads((tmp_config_dir / "history.json").read_text(encoding="utf-8"))
    assert len(data) == 50
