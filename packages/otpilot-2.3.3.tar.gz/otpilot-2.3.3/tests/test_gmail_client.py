import base64
import importlib
from datetime import datetime, timedelta, timezone
from email.utils import format_datetime

import pytest
from googleapiclient.errors import HttpError


class FakeResp:
    def __init__(self, status):
        self.status = status
        self.reason = "error"


def _reload_gmail_client(monkeypatch, tmp_config_dir):
    import otpilot.logger as logger_module

    monkeypatch.setattr(logger_module, "LOG_FILE", str(tmp_config_dir / "otpilot.log"))

    import otpilot.gmail_client as gmail_client

    return importlib.reload(gmail_client)


def _make_message(subject, body, sender, date_value):
    data = base64.urlsafe_b64encode(body.encode("utf-8")).decode("utf-8")
    return {
        "payload": {
            "headers": [
                {"name": "Subject", "value": subject},
                {"name": "From", "value": sender},
                {"name": "Date", "value": date_value},
            ],
            "body": {"data": data},
        },
        "snippet": body,
    }


class FakeExec:
    def __init__(self, payload):
        self._payload = payload

    def execute(self):
        return self._payload


class FakeMessages:
    def __init__(self, message_ids, message_payloads):
        self._message_ids = message_ids
        self._message_payloads = message_payloads

    def list(self, userId, maxResults, labelIds):
        return FakeExec({"messages": [{"id": msg_id} for msg_id in self._message_ids]})

    def get(self, userId, id, format):
        return FakeExec(self._message_payloads[id])


class FakeUsers:
    def __init__(self, message_ids, message_payloads):
        self._messages = FakeMessages(message_ids, message_payloads)

    def messages(self):
        return self._messages


class FakeService:
    def __init__(self, message_ids, message_payloads):
        self._users = FakeUsers(message_ids, message_payloads)

    def users(self):
        return self._users


def test_fetch_recent_emails_returns_normalized_list(monkeypatch, tmp_config_dir):
    """Returns normalized emails with subject, body, sender, timestamp."""
    gmail_client = _reload_gmail_client(monkeypatch, tmp_config_dir)

    now = datetime.now(timezone.utc)
    date_value = format_datetime(now)
    payloads = {
        "1": _make_message("Subject", "Body", "sender@example.com", date_value)
    }

    monkeypatch.setattr(gmail_client, "_load_credentials", lambda: object())
    monkeypatch.setattr(gmail_client, "build", lambda *args, **kwargs: FakeService(["1"], payloads))
    monkeypatch.setattr(gmail_client, "get_config", lambda: {"email_fetch_count": 5, "otp_max_age_minutes": 10})

    emails = gmail_client.fetch_recent_emails()

    assert emails[0]["subject"] == "Subject"
    assert emails[0]["body"] == "Body"
    assert emails[0]["sender"] == "sender@example.com"
    assert "timestamp" in emails[0]


def test_fetch_recent_emails_empty_inbox(monkeypatch, tmp_config_dir):
    """Returns empty list when inbox has no messages."""
    gmail_client = _reload_gmail_client(monkeypatch, tmp_config_dir)

    monkeypatch.setattr(gmail_client, "_load_credentials", lambda: object())
    monkeypatch.setattr(gmail_client, "build", lambda *args, **kwargs: FakeService([], {}))
    monkeypatch.setattr(gmail_client, "get_config", lambda: {"email_fetch_count": 5, "otp_max_age_minutes": 10})

    assert gmail_client.fetch_recent_emails() == []


def test_fetch_recent_emails_skips_old_emails(monkeypatch, tmp_config_dir):
    """Skips emails older than otp_max_age_minutes."""
    gmail_client = _reload_gmail_client(monkeypatch, tmp_config_dir)

    old_time = datetime.now(timezone.utc) - timedelta(minutes=10)
    date_value = format_datetime(old_time)
    payloads = {
        "1": _make_message("Subject", "Body", "sender@example.com", date_value)
    }

    monkeypatch.setattr(gmail_client, "_load_credentials", lambda: object())
    monkeypatch.setattr(gmail_client, "build", lambda *args, **kwargs: FakeService(["1"], payloads))
    monkeypatch.setattr(gmail_client, "get_config", lambda: {"email_fetch_count": 5, "otp_max_age_minutes": 1})

    assert gmail_client.fetch_recent_emails() == []


def test_fetch_recent_emails_strips_html(monkeypatch, tmp_config_dir):
    """Strips HTML tags from email bodies."""
    gmail_client = _reload_gmail_client(monkeypatch, tmp_config_dir)

    now = datetime.now(timezone.utc)
    date_value = format_datetime(now)
    payloads = {
        "1": _make_message("Subject", "<b>Your code is 123456</b>", "sender@example.com", date_value)
    }

    monkeypatch.setattr(gmail_client, "_load_credentials", lambda: object())
    monkeypatch.setattr(gmail_client, "build", lambda *args, **kwargs: FakeService(["1"], payloads))
    monkeypatch.setattr(gmail_client, "get_config", lambda: {"email_fetch_count": 5, "otp_max_age_minutes": 10})

    emails = gmail_client.fetch_recent_emails()
    assert "<" not in emails[0]["body"]


def test_fetch_recent_emails_raises_not_authenticated_when_no_token(monkeypatch, tmp_config_dir):
    """Raises NotAuthenticatedError when no token exists."""
    gmail_client = _reload_gmail_client(monkeypatch, tmp_config_dir)

    monkeypatch.setattr(gmail_client, "load_token", lambda: None)

    with pytest.raises(gmail_client.NotAuthenticatedError):
        gmail_client.fetch_recent_emails()


def test_fetch_recent_emails_raises_gmail_auth_error_on_invalid_token(monkeypatch, tmp_config_dir):
    """Raises GmailAuthError when token payload is invalid."""
    gmail_client = _reload_gmail_client(monkeypatch, tmp_config_dir)

    monkeypatch.setattr(gmail_client, "load_token", lambda: {"access_token": None})

    with pytest.raises(gmail_client.GmailAuthError):
        gmail_client.fetch_recent_emails()


def test_retries_on_503(monkeypatch, tmp_config_dir):
    """Retries on 503 errors before succeeding."""
    gmail_client = _reload_gmail_client(monkeypatch, tmp_config_dir)

    calls = {"count": 0}
    monkeypatch.setattr(gmail_client.time, "sleep", lambda *_: None)

    def fn():
        calls["count"] += 1
        if calls["count"] < 3:
            raise HttpError(FakeResp(503), b"")
        return "ok"

    assert gmail_client._with_retry(fn, max_attempts=3, base_delay=0.1) == "ok"
    assert calls["count"] == 3


def test_retries_on_429(monkeypatch, tmp_config_dir):
    """Retries on 429 errors."""
    gmail_client = _reload_gmail_client(monkeypatch, tmp_config_dir)

    calls = {"count": 0}
    monkeypatch.setattr(gmail_client.time, "sleep", lambda *_: None)

    def fn():
        calls["count"] += 1
        if calls["count"] < 2:
            raise HttpError(FakeResp(429), b"")
        return "ok"

    assert gmail_client._with_retry(fn, max_attempts=3, base_delay=0.1) == "ok"
    assert calls["count"] == 2


def test_retries_on_connection_error(monkeypatch, tmp_config_dir):
    """Retries on network connection errors."""
    gmail_client = _reload_gmail_client(monkeypatch, tmp_config_dir)

    calls = {"count": 0}
    monkeypatch.setattr(gmail_client.time, "sleep", lambda *_: None)

    def fn():
        calls["count"] += 1
        if calls["count"] < 2:
            raise gmail_client.requests.exceptions.ConnectionError()
        return "ok"

    assert gmail_client._with_retry(fn, max_attempts=3, base_delay=0.1) == "ok"


def test_no_retry_on_401(monkeypatch, tmp_config_dir):
    """Does not retry on 401 errors."""
    gmail_client = _reload_gmail_client(monkeypatch, tmp_config_dir)

    calls = {"count": 0}

    def fn():
        calls["count"] += 1
        raise HttpError(FakeResp(401), b"")

    with pytest.raises(HttpError):
        gmail_client._with_retry(fn, max_attempts=3, base_delay=0.1)

    assert calls["count"] == 1


def test_no_retry_on_403(monkeypatch, tmp_config_dir):
    """Does not retry on 403 errors."""
    gmail_client = _reload_gmail_client(monkeypatch, tmp_config_dir)

    calls = {"count": 0}

    def fn():
        calls["count"] += 1
        raise HttpError(FakeResp(403), b"")

    with pytest.raises(HttpError):
        gmail_client._with_retry(fn, max_attempts=3, base_delay=0.1)

    assert calls["count"] == 1


def test_raises_after_max_retries_exceeded(monkeypatch, tmp_config_dir):
    """Raises after exhausting max retry attempts."""
    gmail_client = _reload_gmail_client(monkeypatch, tmp_config_dir)

    calls = {"count": 0}
    monkeypatch.setattr(gmail_client.time, "sleep", lambda *_: None)

    def fn():
        calls["count"] += 1
        raise HttpError(FakeResp(503), b"")

    with pytest.raises(HttpError):
        gmail_client._with_retry(fn, max_attempts=2, base_delay=0.1)

    assert calls["count"] == 2


def test_retry_succeeds_on_second_attempt(monkeypatch, tmp_config_dir):
    """Succeeds on the second attempt after retry."""
    gmail_client = _reload_gmail_client(monkeypatch, tmp_config_dir)

    calls = {"count": 0}
    monkeypatch.setattr(gmail_client.time, "sleep", lambda *_: None)

    def fn():
        calls["count"] += 1
        if calls["count"] == 1:
            raise HttpError(FakeResp(503), b"")
        return "ok"

    assert gmail_client._with_retry(fn, max_attempts=3, base_delay=0.1) == "ok"


def test_build_credentials_with_full_payload(monkeypatch, tmp_config_dir):
    """Credentials built with refresh_token and expiry when payload is complete."""
    gmail_client = _reload_gmail_client(monkeypatch, tmp_config_dir)

    payload = {
        "access_token": "token123",
        "refresh_token": "refresh123",
        "expires_at": int(datetime.now(timezone.utc).timestamp()) + 3600,
    }

    creds = gmail_client._build_credentials(payload)

    assert creds.token == "token123"
    assert creds.refresh_token == "refresh123"
    assert creds.expiry is not None


def test_build_credentials_legacy_payload_no_refresh(monkeypatch, tmp_config_dir):
    """Credentials built without refresh capability for old token payloads."""
    gmail_client = _reload_gmail_client(monkeypatch, tmp_config_dir)

    payload = {"access_token": "token123"}

    creds = gmail_client._build_credentials(payload)

    assert creds.token == "token123"
    assert creds.refresh_token is None


def test_build_credentials_raises_on_missing_access_token(monkeypatch, tmp_config_dir):
    """GmailAuthError raised when access_token key is absent."""
    gmail_client = _reload_gmail_client(monkeypatch, tmp_config_dir)

    with pytest.raises(gmail_client.GmailAuthError):
        gmail_client._build_credentials({})


def test_refresh_if_expired_skips_when_valid(monkeypatch, tmp_config_dir):
    """No refresh attempted when token expires more than 5 minutes from now."""
    gmail_client = _reload_gmail_client(monkeypatch, tmp_config_dir)

    payload = {
        "access_token": "token123",
        "refresh_token": "refresh123",
        "expires_at": int(datetime.now(timezone.utc).timestamp()) + 3600,
    }
    creds = gmail_client._build_credentials(payload)

    refreshed = gmail_client._refresh_if_expired(creds)

    assert refreshed is creds


def test_refresh_if_expired_refreshes_when_expired(monkeypatch, tmp_config_dir):
    """creds.refresh() called and new token persisted when token is expired."""
    gmail_client = _reload_gmail_client(monkeypatch, tmp_config_dir)

    payload = {
        "access_token": "token123",
        "refresh_token": "refresh123",
        "expires_at": int(datetime.now(timezone.utc).timestamp()) - 10,
    }
    creds = gmail_client._build_credentials(payload)

    refreshed = {"called": False}

    def fake_refresh(request):
        refreshed["called"] = True
        creds.token = "newtoken"
        creds.expiry = datetime.now(timezone.utc) + timedelta(hours=1)

    monkeypatch.setattr(creds, "refresh", fake_refresh)
    monkeypatch.setattr(gmail_client, "load_token", lambda: payload.copy())
    monkeypatch.setattr(gmail_client, "save_token", lambda *_: None)

    gmail_client._refresh_if_expired(creds)

    assert refreshed["called"] is True


def test_refresh_if_expired_raises_when_no_refresh_token(monkeypatch, tmp_config_dir):
    """GmailAuthError raised when token is expired and no refresh_token exists."""
    gmail_client = _reload_gmail_client(monkeypatch, tmp_config_dir)

    payload = {"access_token": "token123", "expires_at": int(datetime.now(timezone.utc).timestamp()) - 10}
    creds = gmail_client._build_credentials(payload)

    with pytest.raises(gmail_client.GmailAuthError):
        gmail_client._refresh_if_expired(creds)


def test_refresh_if_expired_raises_on_refresh_failure(monkeypatch, tmp_config_dir):
    """GmailAuthError raised when google-auth refresh call throws."""
    gmail_client = _reload_gmail_client(monkeypatch, tmp_config_dir)

    payload = {
        "access_token": "token123",
        "refresh_token": "refresh123",
        "expires_at": int(datetime.now(timezone.utc).timestamp()) - 10,
    }
    creds = gmail_client._build_credentials(payload)

    def fake_refresh(_request):
        raise RuntimeError("fail")

    monkeypatch.setattr(creds, "refresh", fake_refresh)

    with pytest.raises(gmail_client.GmailAuthError):
        gmail_client._refresh_if_expired(creds)


def test_refresh_persists_new_access_token(monkeypatch, tmp_config_dir):
    """Updated access_token and expires_at saved to token store after refresh."""
    gmail_client = _reload_gmail_client(monkeypatch, tmp_config_dir)

    payload = {
        "access_token": "token123",
        "refresh_token": "refresh123",
        "expires_at": int(datetime.now(timezone.utc).timestamp()) - 10,
    }
    creds = gmail_client._build_credentials(payload)

    def fake_refresh(_request):
        creds.token = "newtoken"
        creds.expiry = datetime.now(timezone.utc) + timedelta(hours=1)

    saved = {}
    monkeypatch.setattr(creds, "refresh", fake_refresh)
    monkeypatch.setattr(gmail_client, "load_token", lambda: payload.copy())
    monkeypatch.setattr(gmail_client, "save_token", lambda data: saved.update(data))

    gmail_client._refresh_if_expired(creds)

    assert saved["access_token"] == "newtoken"
    assert "expires_at" in saved


def test_load_credentials_raises_not_authenticated_when_no_token(monkeypatch, tmp_config_dir):
    """NotAuthenticatedError raised when token store is empty."""
    gmail_client = _reload_gmail_client(monkeypatch, tmp_config_dir)

    monkeypatch.setattr(gmail_client, "load_token", lambda: None)

    with pytest.raises(gmail_client.NotAuthenticatedError):
        gmail_client._load_credentials()


def test_load_credentials_returns_valid_creds(monkeypatch, tmp_config_dir):
    """Valid Credentials object returned when token is present and not expired."""
    gmail_client = _reload_gmail_client(monkeypatch, tmp_config_dir)

    payload = {
        "access_token": "token123",
        "refresh_token": "refresh123",
        "expires_at": int(datetime.now(timezone.utc).timestamp()) + 3600,
    }
    monkeypatch.setattr(gmail_client, "load_token", lambda: payload.copy())

    creds = gmail_client._load_credentials()

    assert creds.token == "token123"


def test_run_oauth_flow_stores_refresh_token(monkeypatch, tmp_config_dir):
    """refresh_token and expires_at saved when session endpoint returns them."""
    gmail_client = _reload_gmail_client(monkeypatch, tmp_config_dir)

    saved = {}

    def fake_get(url, timeout):
        class Resp:
            status_code = 200
            text = "ok"

            def json(self):
                return {
                    "provider_token": "token123",
                    "provider_refresh_token": "refresh123",
                    "expires_in": 3600,
                }

        return Resp()

    monkeypatch.setattr(gmail_client.webbrowser, "open", lambda *_: None)
    monkeypatch.setattr(gmail_client.requests, "get", fake_get)
    monkeypatch.setattr(gmail_client.time, "sleep", lambda *_: None)
    monkeypatch.setattr(gmail_client, "save_token", lambda payload: saved.update(payload))

    gmail_client.run_oauth_flow("https://example.com")

    assert saved["access_token"] == "token123"
    assert saved["refresh_token"] == "refresh123"
    assert "expires_at" in saved


def test_run_oauth_flow_works_without_refresh_token(monkeypatch, tmp_config_dir):
    """Flow completes gracefully when session endpoint omits refresh_token."""
    gmail_client = _reload_gmail_client(monkeypatch, tmp_config_dir)

    saved = {}

    def fake_get(url, timeout):
        class Resp:
            status_code = 200
            text = "ok"

            def json(self):
                return {"provider_token": "token123"}

        return Resp()

    monkeypatch.setattr(gmail_client.webbrowser, "open", lambda *_: None)
    monkeypatch.setattr(gmail_client.requests, "get", fake_get)
    monkeypatch.setattr(gmail_client.time, "sleep", lambda *_: None)
    monkeypatch.setattr(gmail_client, "save_token", lambda payload: saved.update(payload))

    gmail_client.run_oauth_flow("https://example.com")

    assert saved["access_token"] == "token123"


def test_run_oauth_flow_raises_on_timeout(monkeypatch, tmp_config_dir):
    """Raises when OAuth flow times out."""
    gmail_client = _reload_gmail_client(monkeypatch, tmp_config_dir)

    def fake_get(url, timeout):
        class Resp:
            status_code = 202
            text = "pending"

            def json(self):
                return {}

        return Resp()

    times = {"value": 0}

    def fake_time():
        times["value"] += 100
        return times["value"]

    monkeypatch.setattr(gmail_client.webbrowser, "open", lambda *_: None)
    monkeypatch.setattr(gmail_client.requests, "get", fake_get)
    monkeypatch.setattr(gmail_client.time, "time", fake_time)
    monkeypatch.setattr(gmail_client.time, "sleep", lambda *_: None)

    with pytest.raises(gmail_client.GmailAuthError):
        gmail_client.run_oauth_flow("https://example.com")


def test_run_oauth_flow_raises_on_bad_status(monkeypatch, tmp_config_dir):
    """Raises when OAuth session returns bad status."""
    gmail_client = _reload_gmail_client(monkeypatch, tmp_config_dir)

    def fake_get(url, timeout):
        class Resp:
            status_code = 500
            text = "error"

            def json(self):
                return {}

        return Resp()

    monkeypatch.setattr(gmail_client.webbrowser, "open", lambda *_: None)
    monkeypatch.setattr(gmail_client.requests, "get", fake_get)

    with pytest.raises(gmail_client.GmailAuthError):
        gmail_client.run_oauth_flow("https://example.com")


def test_run_oauth_flow_raises_when_no_provider_token(monkeypatch, tmp_config_dir):
    """Raises when provider token is missing."""
    gmail_client = _reload_gmail_client(monkeypatch, tmp_config_dir)

    def fake_get(url, timeout):
        class Resp:
            status_code = 200
            text = "ok"

            def json(self):
                return {}

        return Resp()

    monkeypatch.setattr(gmail_client.webbrowser, "open", lambda *_: None)
    monkeypatch.setattr(gmail_client.requests, "get", fake_get)

    with pytest.raises(gmail_client.GmailAuthError):
        gmail_client.run_oauth_flow("https://example.com")
