import json

from otpilot import config as config_module


def test_get_config_creates_file_when_missing(tmp_config_dir):
    """Creates config file when missing."""
    config_module.get_config()
    assert (tmp_config_dir / "config.json").exists()


def test_get_config_returns_defaults_when_missing(tmp_config_dir):
    """Returns defaults when config file is missing."""
    config = config_module.get_config()
    assert config["hotkey"] == config_module.DEFAULT_CONFIG["hotkey"]


def test_get_config_merges_stored_with_defaults(tmp_config_dir):
    """Merges stored values onto defaults."""
    (tmp_config_dir / "config.json").write_text(json.dumps({"hotkey": "ctrl+alt+x"}), encoding="utf-8")
    config = config_module.get_config()
    assert config["hotkey"] == "ctrl+alt+x"
    assert "notify_on_copy" in config


def test_get_config_recovers_from_corrupt_json(tmp_config_dir):
    """Recovers from corrupt JSON by restoring defaults."""
    (tmp_config_dir / "config.json").write_text("{bad json}", encoding="utf-8")
    config = config_module.get_config()
    assert config["hotkey"] == config_module.DEFAULT_CONFIG["hotkey"]


def test_save_config_writes_valid_json(tmp_config_dir):
    """Writes JSON config to disk."""
    data = {"hotkey": "ctrl+alt+y"}
    config_module.save_config(data)
    saved = json.loads((tmp_config_dir / "config.json").read_text(encoding="utf-8"))
    assert saved["hotkey"] == "ctrl+alt+y"


def test_get_value_returns_stored(tmp_config_dir):
    """Returns stored value when present."""
    config_module.save_config({"hotkey": "ctrl+alt+z"})
    assert config_module.get_value("hotkey") == "ctrl+alt+z"


def test_get_value_returns_default_when_missing(tmp_config_dir):
    """Returns default when value is missing."""
    config_module.save_config({"hotkey": "ctrl+alt+z"})
    assert config_module.get_value("notify_on_copy", False) is False


def test_set_value_persists(tmp_config_dir):
    """Persists values written via set_value."""
    config_module.set_value("hotkey", "ctrl+shift+p")
    data = json.loads((tmp_config_dir / "config.json").read_text(encoding="utf-8"))
    assert data["hotkey"] == "ctrl+shift+p"


def test_config_exists_false_when_missing(tmp_config_dir):
    """Returns False when config file is missing."""
    assert config_module.config_exists() is False


def test_config_exists_true_when_present(tmp_config_dir):
    """Returns True when config file exists."""
    config_module.save_config(config_module.DEFAULT_CONFIG.copy())
    assert config_module.config_exists() is True


def test_token_exists_delegates_to_token_store(tmp_config_dir, monkeypatch):
    """Delegates token_exists to token_store when available."""
    monkeypatch.setattr("otpilot.token_store.token_exists", lambda: True)
    assert config_module.token_exists() is True
