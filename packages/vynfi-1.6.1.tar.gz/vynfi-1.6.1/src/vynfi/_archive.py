"""Job archive extraction utilities.

Supports two backend formats transparently:

- **zip** -- legacy/local storage; entire archive returned as a zip file
- **managed_blob** -- TB-scale Azure Blob Storage; manifest with presigned URLs
"""

from __future__ import annotations

import io
import json
import zipfile
from pathlib import Path
from typing import Any

import httpx


class JobArchive:
    """Wrapper around a downloaded job archive for ergonomic file access.

    Transparently handles both zip archives and blob manifests::

        archive = client.jobs.download_archive(job_id)
        print(archive.files())               # list all files
        entries = archive.json("journal_entries.json")  # parse JSON directly
        archive.extract_to("./output")       # extract to disk

    For ``managed_blob`` archives, file content is fetched lazily over HTTP
    using presigned URLs included in the manifest.
    """

    def __init__(self, data: bytes) -> None:
        self._data = data
        self._zip: zipfile.ZipFile | None = None
        self._manifest: dict[str, Any] | None = None
        self._url_index: dict[str, dict[str, Any]] = {}
        self._http: httpx.Client | None = None

        # Detect format
        if data[:2] == b"PK":
            self._zip = zipfile.ZipFile(io.BytesIO(data))
        elif data[:1] == b"{":
            try:
                self._manifest = json.loads(data)
                if "files" in self._manifest:
                    for f in self._manifest["files"]:
                        self._url_index[f["path"]] = f
                    self._http = httpx.Client(timeout=60.0)
                else:
                    raise ValueError("Manifest missing 'files' key")
            except json.JSONDecodeError as e:
                raise ValueError(f"Cannot parse archive: not a zip or manifest: {e}") from e
        else:
            raise ValueError("Cannot parse archive: not a zip and not JSON")

    @property
    def backend(self) -> str:
        """The storage backend: ``"zip"`` or ``"managed_blob"``."""
        if self._zip is not None:
            return "zip"
        return self._manifest.get("type", "managed_blob") if self._manifest else "unknown"

    def files(self) -> list[str]:
        """List all file paths in the archive."""
        if self._zip is not None:
            return self._zip.namelist()
        return list(self._url_index.keys())

    def find(self, pattern: str) -> list[str]:
        """Find files matching a glob-like pattern."""
        import fnmatch

        return fnmatch.filter(self.files(), pattern)

    def categories(self) -> list[str]:
        """List top-level directories (categories) in the archive."""
        dirs: set[str] = set()
        for name in self.files():
            if "/" in name:
                dirs.add(name.split("/")[0])
        return sorted(dirs)

    def read(self, path: str) -> bytes:
        """Read a file from the archive as raw bytes.

        For ``managed_blob`` archives, this fetches the file lazily via the
        presigned URL.
        """
        if self._zip is not None:
            if path in self._zip.namelist():
                return self._zip.read(path)
            basename = path.rsplit("/", 1)[-1]
            for name in self._zip.namelist():
                if name.endswith("/" + basename) or name == basename:
                    return self._zip.read(name)
            raise KeyError(f"File not found in archive: {path}")

        # Manifest-backed: fetch via presigned URL
        entry: dict[str, Any] | None = self._url_index.get(path)
        if entry is None:
            basename = path.rsplit("/", 1)[-1]
            for p, e in self._url_index.items():
                if p == basename or p.endswith("/" + basename):
                    entry = e
                    break
        if entry is None:
            raise KeyError(f"File not found in manifest: {path}")
        assert self._http is not None
        resp = self._http.get(entry["url"])
        if resp.status_code >= 400:
            raise RuntimeError(
                f"Failed to fetch '{path}' from blob storage "
                f"(status {resp.status_code}). The presigned URL may have expired "
                f"(TTL: {self.ttl_seconds()}s) or the blob may not be ready yet. "
                f"Re-call download_archive() to get a fresh manifest."
            )
        return resp.content

    def text(self, path: str, encoding: str = "utf-8") -> str:
        """Read a file from the archive as a string."""
        return self.read(path).decode(encoding)

    def json(self, path: str) -> Any:
        """Read and parse a JSON file from the archive."""
        return json.loads(self.read(path))

    def size(self, path: str) -> int:
        """Get the uncompressed size of a file in bytes (without fetching)."""
        if self._zip is not None:
            return self._zip.getinfo(path).file_size
        if path in self._url_index:
            return int(self._url_index[path].get("size", 0))
        raise KeyError(f"File not found: {path}")

    def url(self, path: str) -> str | None:
        """Get the presigned URL for a file (managed_blob only).

        Returns None for zip-backed archives.
        """
        if self._zip is not None:
            return None
        if path in self._url_index:
            return str(self._url_index[path].get("url", ""))
        return None

    def ttl_seconds(self) -> int | None:
        """Get the manifest TTL in seconds (managed_blob only)."""
        if self._manifest:
            return self._manifest.get("ttl_seconds")
        return None

    def extract_to(self, directory: str | Path) -> Path:
        """Extract all files to a directory.

        For ``managed_blob`` archives, fetches each file via its presigned URL.
        """
        out = Path(directory)
        out.mkdir(parents=True, exist_ok=True)
        if self._zip is not None:
            self._zip.extractall(out)
        else:
            for path in self.files():
                target = out / path
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(self.read(path))
        return out

    def summary(self) -> dict[str, Any]:
        """Get a summary of the archive contents."""
        cats: dict[str, list[str]] = {}
        total_size = 0
        if self._zip is not None:
            for info in self._zip.infolist():
                total_size += info.file_size
                parts = info.filename.split("/")
                cat = parts[0] if len(parts) > 1 else "(root)"
                cats.setdefault(cat, []).append(info.filename)
            file_count = len(self._zip.infolist())
        else:
            for path, entry in self._url_index.items():
                total_size += int(entry.get("size", 0))
                parts = path.split("/")
                cat = parts[0] if len(parts) > 1 else "(root)"
                cats.setdefault(cat, []).append(path)
            file_count = len(self._url_index)
        return {
            "backend": self.backend,
            "total_files": file_count,
            "total_size_bytes": total_size,
            "categories": {k: len(v) for k, v in sorted(cats.items())},
        }

    def __repr__(self) -> str:
        s = self.summary()
        return (
            f"JobArchive(backend={self.backend!r}, "
            f"{s['total_files']} files, "
            f"{s['total_size_bytes'] / 1024 / 1024:.1f} MB)"
        )

    def audit_opinions(self) -> list[Any]:
        """Read `audit/audit_opinions.json` (DS 3.1.0+). Returns [] if missing."""
        try:
            data = self.json("audit/audit_opinions.json")
            return data if isinstance(data, list) else []
        except KeyError:
            return []

    def key_audit_matters(self) -> list[Any]:
        """Read `audit/key_audit_matters.json` (DS 3.1.0+). Returns [] if missing."""
        try:
            data = self.json("audit/key_audit_matters.json")
            return data if isinstance(data, list) else []
        except KeyError:
            return []

    def dataframes(
        self,
        *,
        include: list[str] | None = None,
        exclude: list[str] | None = None,
    ) -> Any:
        """Convert all JSON files in the archive to a dict of DataFrames.

        Applies sensible defaults: numeric coercion for ``*_amount``, ``*_rate``,
        ``*_percent``, ``*_score``, ``quantity`` columns; UTC datetime parsing
        for ``*_date``, ``*_at``, ``timestamp*`` columns; journal entry
        header/lines flattening.

        Requires ``pip install vynfi[pandas]``.

        Args:
            include: Only convert files matching these glob patterns.
            exclude: Skip files matching these glob patterns.

        Returns:
            dict[str, pd.DataFrame] keyed by archive path.
        """
        from .integrations.pandas import archive_to_dataframes

        return archive_to_dataframes(self, include=include, exclude=exclude)

    def __enter__(self) -> JobArchive:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def close(self) -> None:
        """Release any underlying resources."""
        if self._zip is not None:
            self._zip.close()
        if self._http is not None:
            self._http.close()
            self._http = None
