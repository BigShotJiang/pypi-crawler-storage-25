"""Aggregated quality reports for generated data."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ._archive import JobArchive


@dataclass
class DataSynthQualityReport:
    """One-call aggregator of the quality signals DataSynth produces.

    Pulls from both the archive (`analytics/*.json`, `balance_validation.json`,
    `data_quality_stats.json`) and the `/v1/jobs/{id}/analytics` endpoint,
    then merges them into a single object with ``.to_markdown()`` /
    ``.to_dict()`` renderers.

    Usage::

        from vynfi import VynFi, DataSynthQualityReport

        client = VynFi(api_key="...")
        archive = client.jobs.download_archive(job_id)
        report = DataSynthQualityReport.from_job(client, job_id, archive)
        print(report.to_markdown())
    """

    job_id: str = ""
    # Benford's Law
    benford_mad: float | None = None
    benford_conformity: str = ""
    benford_passes: bool = False
    # Amount distribution
    amount_skewness: float | None = None
    amount_kurtosis: float | None = None
    amount_round_number_ratio: float | None = None
    # Balance validation
    balance_is_balanced: bool | None = None
    balance_entries_processed: int = 0
    balance_total_debits: str = ""
    balance_total_credits: str = ""
    # Process variants
    variant_count: int = 0
    variant_entropy: float | None = None
    happy_path_concentration: float | None = None
    rework_rate: float | None = None
    skipped_step_rate: float | None = None
    out_of_order_rate: float | None = None
    # Banking
    banking_passes: bool | None = None
    banking_issues: list[str] = field(default_factory=list)
    fraud_propagation_rate: float | None = None
    velocity_coverage_rate: float | None = None
    false_positive_rate: float | None = None
    kyc_core_field_rate: float | None = None
    # Data quality
    duplicates: int = 0
    missing_values: int = 0
    records_with_issues: int = 0

    @classmethod
    def from_job(
        cls,
        client: Any,
        job_id: str,
        archive: JobArchive | None = None,
    ) -> DataSynthQualityReport:
        """Build a report from a completed job.

        Args:
            client: A :class:`VynFi` client.
            job_id: Completed job ID.
            archive: Optional pre-downloaded :class:`JobArchive`. If None,
                the report pulls from the analytics endpoint only.
        """
        r = cls(job_id=job_id)

        # Endpoint analytics (always works if job has analytics)
        try:
            a = client.jobs.analytics(job_id)
            if a.benford_analysis:
                r.benford_mad = a.benford_analysis.mad
                r.benford_conformity = a.benford_analysis.conformity
                r.benford_passes = a.benford_analysis.passes
            if a.amount_distribution:
                r.amount_skewness = a.amount_distribution.skewness
                r.amount_kurtosis = a.amount_distribution.kurtosis
                r.amount_round_number_ratio = a.amount_distribution.round_number_ratio
            if a.process_variant_summary:
                r.variant_count = a.process_variant_summary.variant_count
                r.variant_entropy = a.process_variant_summary.variant_entropy
                r.happy_path_concentration = a.process_variant_summary.happy_path_concentration
                r.rework_rate = a.process_variant_summary.rework_rate
                r.skipped_step_rate = a.process_variant_summary.skipped_step_rate
                r.out_of_order_rate = a.process_variant_summary.out_of_order_rate
            if a.banking_evaluation:
                r.banking_passes = a.banking_evaluation.passes
                r.banking_issues = list(a.banking_evaluation.issues)
                if a.banking_evaluation.cross_layer:
                    r.fraud_propagation_rate = (
                        a.banking_evaluation.cross_layer.fraud_propagation_rate
                    )
                if a.banking_evaluation.velocity:
                    r.velocity_coverage_rate = a.banking_evaluation.velocity.coverage_rate
                if a.banking_evaluation.false_positive:
                    r.false_positive_rate = a.banking_evaluation.false_positive.fp_rate
                if a.banking_evaluation.kyc:
                    r.kyc_core_field_rate = a.banking_evaluation.kyc.core_field_rate
        except Exception:
            pass

        # Archive-only signals (balance, data quality)
        if archive is not None:
            try:
                bv = archive.json("balance_validation.json")
                r.balance_is_balanced = bv.get("is_balanced")
                r.balance_entries_processed = bv.get("entries_processed", 0)
                r.balance_total_debits = str(bv.get("total_debits", ""))
                r.balance_total_credits = str(bv.get("total_credits", ""))
            except KeyError:
                pass
            try:
                dq = archive.json("data_quality_stats.json")
                r.duplicates = dq.get("duplicates", {}).get("total_duplicates", 0)
                r.missing_values = dq.get("missing_values", {}).get("total_missing", 0)
                r.records_with_issues = dq.get("records_with_issues", 0)
            except KeyError:
                pass

        return r

    def to_dict(self) -> dict[str, Any]:
        """Return a flat dict representation (suitable for DataFrame/JSON)."""
        return {
            "job_id": self.job_id,
            "benford_mad": self.benford_mad,
            "benford_conformity": self.benford_conformity,
            "benford_passes": self.benford_passes,
            "amount_skewness": self.amount_skewness,
            "amount_kurtosis": self.amount_kurtosis,
            "amount_round_number_ratio": self.amount_round_number_ratio,
            "balance_is_balanced": self.balance_is_balanced,
            "balance_entries_processed": self.balance_entries_processed,
            "balance_total_debits": self.balance_total_debits,
            "balance_total_credits": self.balance_total_credits,
            "variant_count": self.variant_count,
            "variant_entropy": self.variant_entropy,
            "happy_path_concentration": self.happy_path_concentration,
            "rework_rate": self.rework_rate,
            "skipped_step_rate": self.skipped_step_rate,
            "out_of_order_rate": self.out_of_order_rate,
            "banking_passes": self.banking_passes,
            "fraud_propagation_rate": self.fraud_propagation_rate,
            "velocity_coverage_rate": self.velocity_coverage_rate,
            "false_positive_rate": self.false_positive_rate,
            "kyc_core_field_rate": self.kyc_core_field_rate,
            "duplicates": self.duplicates,
            "missing_values": self.missing_values,
            "records_with_issues": self.records_with_issues,
        }

    def to_markdown(self) -> str:
        """Render the report as a Markdown table."""
        lines: list[str] = [
            f"# DataSynth Quality Report — `{self.job_id}`",
            "",
            "## Benford's Law",
            f"- Conformity: **{self.benford_conformity or 'N/A'}**",
            f"- MAD: **{self.benford_mad:.4f}**" if self.benford_mad is not None else "- MAD: N/A",
            f"- Passes: **{self.benford_passes}**",
            "",
            "## Amount distribution",
            f"- Skewness: {self.amount_skewness:.3f}"
            if self.amount_skewness is not None
            else "- Skewness: N/A",
            f"- Kurtosis: {self.amount_kurtosis:.3f}"
            if self.amount_kurtosis is not None
            else "- Kurtosis: N/A",
            f"- Round-number ratio: {self.amount_round_number_ratio:.2%}"
            if self.amount_round_number_ratio is not None
            else "- Round-number ratio: N/A",
            "",
            "## Balance validation",
            f"- Balanced: **{self.balance_is_balanced}**",
            f"- Entries processed: {self.balance_entries_processed:,}",
            f"- Total debits:  {self.balance_total_debits}",
            f"- Total credits: {self.balance_total_credits}",
            "",
            "## Process variants",
            f"- Variants: {self.variant_count}",
            f"- Entropy: {self.variant_entropy:.3f}"
            if self.variant_entropy is not None
            else "- Entropy: N/A",
            f"- Happy-path concentration: {self.happy_path_concentration:.1%}"
            if self.happy_path_concentration is not None
            else "- Happy-path concentration: N/A",
        ]
        if self.rework_rate is not None:
            lines += [
                f"- Rework rate: {self.rework_rate:.2%}",
                f"- Skipped-step rate: {self.skipped_step_rate:.2%}"
                if self.skipped_step_rate
                else "",
                f"- Out-of-order rate: {self.out_of_order_rate:.2%}"
                if self.out_of_order_rate
                else "",
            ]
        lines += [
            "",
            "## Banking evaluation",
            f"- Passes: **{self.banking_passes}**",
        ]
        if self.kyc_core_field_rate is not None:
            lines.append(f"- KYC core field rate: {self.kyc_core_field_rate:.1%}")
        if self.fraud_propagation_rate is not None:
            lines.append(f"- Fraud propagation rate: {self.fraud_propagation_rate:.1%}")
        if self.velocity_coverage_rate is not None:
            lines.append(f"- Velocity coverage: {self.velocity_coverage_rate:.1%}")
        if self.false_positive_rate is not None:
            lines.append(f"- AML false-positive rate: {self.false_positive_rate:.1%}")
        if self.banking_issues:
            lines.append(f"- Issues: {', '.join(self.banking_issues)}")
        lines += [
            "",
            "## Data quality stats",
            f"- Duplicates: {self.duplicates}",
            f"- Missing values: {self.missing_values}",
            f"- Records with issues: {self.records_with_issues}",
        ]
        return "\n".join(line for line in lines if line != "")
