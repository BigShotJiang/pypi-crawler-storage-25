"""Saved generation configs resource."""

from __future__ import annotations

from typing import Any, List, Optional

from .._client import SyncClient
from .._types import (
    CompanyConfigResponse,
    ComposeConfigResponse,
    DeletedResponse,
    EstimateCostResponse,
    EstimateSizeResponse,
    NlConfigResponse,
    RawConfigResponse,
    SavedConfig,
    ValidateConfigResponse,
)


class Configs:
    """Manage saved generation configs."""

    def __init__(self, client: SyncClient) -> None:
        self._client = client

    def create(
        self,
        *,
        name: str,
        config: dict[str, Any],
        description: Optional[str] = None,
        source_template_id: Optional[str] = None,
        visibility: Optional[str] = None,
        tags: Optional[List[str]] = None,
    ) -> SavedConfig:
        """Save a new generation config."""
        body: dict[str, Any] = {"name": name, "config": config}
        if description is not None:
            body["description"] = description
        if source_template_id is not None:
            body["sourceTemplateId"] = source_template_id
        if visibility is not None:
            body["visibility"] = visibility
        if tags is not None:
            body["tags"] = tags
        data = self._client.request("POST", "/v1/configs", json=body)
        return SavedConfig.model_validate(data)

    def list(
        self,
        *,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> List[SavedConfig]:
        """List saved configs with optional pagination."""
        params: dict[str, Any] = {}
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset
        data = self._client.request("GET", "/v1/configs", params=params)
        if isinstance(data, dict):
            data = data.get("configs") or data.get("data") or []
        return [SavedConfig.model_validate(c) for c in data]

    def get(self, config_id: str) -> SavedConfig:
        """Get a saved config by ID."""
        data = self._client.request("GET", f"/v1/configs/{config_id}")
        return SavedConfig.model_validate(data)

    def update(
        self,
        config_id: str,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
        config: Optional[dict[str, Any]] = None,
        visibility: Optional[str] = None,
        tags: Optional[List[str]] = None,
    ) -> SavedConfig:
        """Update a saved config."""
        body: dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if description is not None:
            body["description"] = description
        if config is not None:
            body["config"] = config
        if visibility is not None:
            body["visibility"] = visibility
        if tags is not None:
            body["tags"] = tags
        data = self._client.request("PATCH", f"/v1/configs/{config_id}", json=body)
        return SavedConfig.model_validate(data)

    def delete(self, config_id: str) -> DeletedResponse:
        """Delete a saved config."""
        data = self._client.request("DELETE", f"/v1/configs/{config_id}")
        if data is None:
            return DeletedResponse(deleted=True)
        return DeletedResponse.model_validate(data)

    def validate(
        self,
        *,
        config: dict[str, Any],
        partial: Optional[bool] = None,
        step: Optional[str] = None,
    ) -> ValidateConfigResponse:
        """Validate a generation config without saving.

        Args:
            config: The config to validate
            partial: Allow partial config (for step-by-step wizards)
            step: Which wizard step to validate
        """
        body: dict[str, Any] = {"config": config}
        if partial is not None:
            body["partial"] = partial
        if step is not None:
            body["step"] = step
        data = self._client.request("POST", "/v1/config/validate", json=body)
        return ValidateConfigResponse.model_validate(data)

    def estimate_cost(self, *, config: dict[str, Any]) -> EstimateCostResponse:
        """Estimate credit cost for a generation config."""
        data = self._client.request("POST", "/v1/config/estimate-cost", json={"config": config})
        return EstimateCostResponse.model_validate(data)

    def compose(self, *, layers: List[dict[str, Any]]) -> ComposeConfigResponse:
        """Compose a config from multiple layers."""
        data = self._client.request("POST", "/v1/config/compose", json={"layers": layers})
        return ComposeConfigResponse.model_validate(data)

    def estimate_size(self, *, config: dict[str, Any]) -> EstimateSizeResponse:
        """Estimate output archive size against your tier's storage quota.

        Returns total bytes, file count, tier quota, exceedance flag, and a
        per-domain breakdown. Used for TB-scale jobs to validate quota before
        submission.
        """
        data = self._client.request("POST", "/v1/configs/estimate-size", json={"config": config})
        return EstimateSizeResponse.model_validate(data)

    def submit_raw(
        self,
        *,
        yaml: str,
        name: Optional[str] = None,
    ) -> RawConfigResponse:
        """Submit a raw DataSynth YAML config for validation (Scale tier+).

        Args:
            yaml: Raw DataSynth YAML config string
            name: Optional name to persist as a saved config

        Returns:
            Validation result with credit estimate. If ``name`` is provided
            and validation succeeds, ``config_id`` will be set.
        """
        body: dict[str, Any] = {"yaml": yaml}
        if name is not None:
            body["name"] = name
        data = self._client.request("POST", "/v1/configs/raw", json=body)
        return RawConfigResponse.model_validate(data)

    def from_description(self, description: str) -> NlConfigResponse:
        """Build a full config from a natural-language dataset description (Scale+).

        Sends `description` to the portal LLM and returns the validated
        PortalGenerationConfig as both a dict (``.config``) and raw YAML
        (``.yaml``), plus a confidence score and a one-line note.
        """
        body = {"description": description}
        data = self._client.request("POST", "/v1/configs/from-description", json=body)
        return NlConfigResponse.model_validate(data)

    def from_company(
        self,
        *,
        uid: Optional[str] = None,
        name: Optional[str] = None,
        periods: Optional[int] = None,
        fraud_rate: Optional[float] = None,
    ) -> CompanyConfigResponse:
        """Build a config from a Swiss VynCo company profile (Scale+).

        Supply either ``uid`` (e.g. ``"CHE-123.456.789"``) or ``name``.
        Optional ``periods`` / ``fraud_rate`` override the LLM defaults.
        """
        if uid is None and name is None:
            raise ValueError("from_company() requires either uid or name.")
        body: dict[str, Any] = {}
        if uid is not None:
            body["uid"] = uid
        if name is not None:
            body["name"] = name
        if periods is not None:
            body["periods"] = periods
        if fraud_rate is not None:
            body["fraud_rate"] = fraud_rate
        data = self._client.request("POST", "/v1/configs/from-company", json=body)
        return CompanyConfigResponse.model_validate(data)
