"""Adversarial probing resource (DataSynth 3.0+, Enterprise only)."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import httpx

from .._client import SyncClient
from .._types import AdversarialProbeResponse, AdversarialProbeResults


class Adversarial:
    """ONNX model probing for fraud detection robustness testing (Enterprise).

    Upload an ONNX fraud detection model and probe its decision boundary to
    find vulnerabilities (adversarial samples, low-margin predictions).
    """

    def __init__(self, client: SyncClient) -> None:
        self._client = client

    def probe(
        self,
        model: str | Path | bytes,
        *,
        n_probes: int = 1000,
        perturbation_budget: float = 0.05,
        threshold: float = 0.5,
        n_features: int | None = None,
    ) -> AdversarialProbeResponse:
        """Submit an ONNX model for adversarial probing.

        Args:
            model: Path to an ONNX model file, or raw bytes (max 512 MB).
            n_probes: Number of adversarial probes (default 1000, max 100000).
            perturbation_budget: Max L2 perturbation per probe (default 0.05).
            threshold: Fraud decision threshold (default 0.5).
            n_features: Override the inferred feature count.

        Returns:
            An :class:`AdversarialProbeResponse` with the submitted job ID.
            Credits: ~100 per 1000 probes. Use :meth:`results` to fetch output.
        """
        if isinstance(model, (str, Path)):
            data = Path(model).read_bytes()
            filename = Path(model).name
        else:
            data = model
            filename = "model.onnx"

        cfg: dict[str, Any] = {
            "nProbes": n_probes,
            "perturbationBudget": perturbation_budget,
            "threshold": threshold,
        }
        if n_features is not None:
            cfg["nFeatures"] = n_features

        files: dict[str, Any] = {
            "model": (filename, data, "application/octet-stream"),
            "config": (None, json.dumps(cfg), "application/json"),
        }
        headers = {
            "Authorization": f"Bearer {self._client.api_key}",
            "User-Agent": "vynfi-python/1.5.0",
        }
        url = self._client._url("/v1/adversarial/probe")
        resp = httpx.post(url, headers=headers, files=files, timeout=600.0)
        if resp.status_code >= 400:
            from .._client import _raise_for_status

            _raise_for_status(resp)
        return AdversarialProbeResponse.model_validate(resp.json())

    def results(self, probe_id: str) -> AdversarialProbeResults:
        """Fetch probe results once the job has completed."""
        data = self._client.request("GET", f"/v1/adversarial/{probe_id}/results")
        return AdversarialProbeResults.model_validate(data)
