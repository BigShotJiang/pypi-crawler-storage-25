"""Template packs resource (VynFi API 4.1+, Team+ tier)."""

from __future__ import annotations

from typing import Any, List, Optional

from .._client import SyncClient
from .._types import (
    DeletedResponse,
    TemplatePack,
    TemplatePackCategoryContent,
    TemplatePackCategorySummary,
    TemplatePackEnrichResponse,
    TemplatePackList,
    TemplatePackValidation,
)


class TemplatePacks:
    """Manage user-uploaded DataSynth template packs (DS 3.2+)."""

    def __init__(self, client: SyncClient) -> None:
        self._client = client

    def list(self) -> TemplatePackList:
        """List every template pack owned by the authenticated user."""
        data = self._client.request("GET", "/v1/template-packs")
        return TemplatePackList.model_validate(data)

    def create(
        self,
        *,
        name: str,
        description: Optional[str] = None,
        merge_strategy: Optional[str] = None,
    ) -> TemplatePack:
        """Create a new (empty) template pack."""
        body: dict[str, Any] = {"name": name}
        if description is not None:
            body["description"] = description
        if merge_strategy is not None:
            body["mergeStrategy"] = merge_strategy
        data = self._client.request("POST", "/v1/template-packs", json=body)
        return TemplatePack.model_validate(data)

    def categories(self) -> List[str]:
        """List the supported category keys (e.g. ``vendor_names``)."""
        data = self._client.request("GET", "/v1/template-packs/categories")
        return list(data) if isinstance(data, list) else []

    def get(self, pack_id: str) -> TemplatePack:
        """Get a single pack by ID."""
        data = self._client.request("GET", f"/v1/template-packs/{pack_id}")
        return TemplatePack.model_validate(data)

    def update(
        self,
        pack_id: str,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
        merge_strategy: Optional[str] = None,
    ) -> TemplatePack:
        """Update pack metadata."""
        body: dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if description is not None:
            body["description"] = description
        if merge_strategy is not None:
            body["mergeStrategy"] = merge_strategy
        data = self._client.request("PUT", f"/v1/template-packs/{pack_id}", json=body)
        return TemplatePack.model_validate(data)

    def delete(self, pack_id: str) -> DeletedResponse:
        """Delete a pack."""
        data = self._client.request("DELETE", f"/v1/template-packs/{pack_id}")
        if data is None:
            return DeletedResponse(deleted=True)
        return DeletedResponse.model_validate(data)

    def validate(self, pack_id: str) -> TemplatePackValidation:
        """Re-validate every category on a pack."""
        data = self._client.request("POST", f"/v1/template-packs/{pack_id}/validate")
        return TemplatePackValidation.model_validate(data)

    def get_category(self, pack_id: str, category: str) -> TemplatePackCategoryContent:
        """Fetch the YAML content of a single category."""
        data = self._client.request("GET", f"/v1/template-packs/{pack_id}/categories/{category}")
        return TemplatePackCategoryContent.model_validate(data)

    def upsert_category(
        self, pack_id: str, category: str, *, content_yaml: str
    ) -> TemplatePackCategorySummary:
        """Create or replace a category's YAML content."""
        body = {"contentYaml": content_yaml}
        data = self._client.request(
            "PUT", f"/v1/template-packs/{pack_id}/categories/{category}", json=body
        )
        return TemplatePackCategorySummary.model_validate(data)

    def delete_category(self, pack_id: str, category: str) -> DeletedResponse:
        """Delete one category on a pack."""
        data = self._client.request("DELETE", f"/v1/template-packs/{pack_id}/categories/{category}")
        if data is None:
            return DeletedResponse(deleted=True)
        return DeletedResponse.model_validate(data)

    def enrich_category(
        self,
        pack_id: str,
        *,
        category: str,
        industry: Optional[str] = None,
        region: Optional[str] = None,
        sub_category: Optional[str] = None,
        count: Optional[int] = None,
        model: Optional[str] = None,
        seed: Optional[int] = None,
        target_pack_category: Optional[str] = None,
    ) -> TemplatePackEnrichResponse:
        """LLM-enrich a category on a pack (Scale+ tier).

        `category` must be one of ``vendor_name`` / ``customer_name`` /
        ``material_desc`` (CLI category). The server defaults
        ``count=50`` / ``industry="retail"`` / ``region="US"`` /
        ``model="anthropic/claude-sonnet-4.5"`` / ``seed=42`` when omitted.
        """
        body: dict[str, Any] = {"category": category}
        if industry is not None:
            body["industry"] = industry
        if region is not None:
            body["region"] = region
        if sub_category is not None:
            body["subCategory"] = sub_category
        if count is not None:
            body["count"] = count
        if model is not None:
            body["model"] = model
        if seed is not None:
            body["seed"] = seed
        if target_pack_category is not None:
            body["targetPackCategory"] = target_pack_category
        data = self._client.request("POST", f"/v1/template-packs/{pack_id}/enrich", json=body)
        return TemplatePackEnrichResponse.model_validate(data)
