"""AI co-pilot resource (DataSynth 3.0+, Scale+)."""

from __future__ import annotations

from typing import Any

from .._client import SyncClient
from .._types import AiChatResponse


class AI:
    """Free-text chat with the VynFi dashboard co-pilot (Scale+)."""

    def __init__(self, client: SyncClient) -> None:
        self._client = client

    def chat(self, message: str, *, page: str | None = None) -> AiChatResponse:
        """Send a message to the co-pilot.

        Args:
            message: The user question or request.
            page: Optional page-context hint (e.g. ``"quality"``) to prime
                  the model with dashboard state.
        """
        body: dict[str, Any] = {"message": message}
        if page is not None:
            body["page"] = page
        data = self._client.request("POST", "/v1/ai/chat", json=body)
        return AiChatResponse.model_validate(data)
