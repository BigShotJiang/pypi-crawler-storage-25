"""Audit optimizer resource (VynFi API 4.1+, DS 4.1.2+, Scale+)."""

from __future__ import annotations

from typing import Any

from .._client import SyncClient
from .._types import OptimizerResponse


class Optimizer:
    """Wrappers for the six `POST /v1/optimizer/*` endpoints.

    Each method shells through the portal to DS `datasynth-data optimizer
    <sub>` and returns the structured JSON report. DS 4.1.2 ships stub
    reports (`status: stub_report_v4_1_2`); deeper analytics light up in
    later 4.1.x / 4.2.x releases.
    """

    def __init__(self, client: SyncClient) -> None:
        self._client = client

    def risk_scope(
        self,
        *,
        engagement: dict[str, Any],
        top_n: int | None = None,
    ) -> OptimizerResponse:
        """Rank engagement accounts by residual risk."""
        body: dict[str, Any] = {"engagement": engagement}
        if top_n is not None:
            body["topN"] = top_n
        data = self._client.request("POST", "/v1/optimizer/risk-scope", json=body)
        return OptimizerResponse.model_validate(data)

    def portfolio(
        self,
        *,
        candidates: Any,
        budget_hours: int,
    ) -> OptimizerResponse:
        """Allocate audit hours across portfolio candidates.

        `budget_hours` must be in [1, 1_000_000] (server-validated).
        """
        body = {"candidates": candidates, "budgetHours": budget_hours}
        data = self._client.request("POST", "/v1/optimizer/portfolio", json=body)
        return OptimizerResponse.model_validate(data)

    def resources(self, *, schedule: Any) -> OptimizerResponse:
        """Produce a resource-phasing plan for an engagement schedule."""
        body = {"schedule": schedule}
        data = self._client.request("POST", "/v1/optimizer/resources", json=body)
        return OptimizerResponse.model_validate(data)

    def conformance(self, *, trace: Any, blueprint: Any) -> OptimizerResponse:
        """Compare an observed audit event trace against an FSM blueprint."""
        body = {"trace": trace, "blueprint": blueprint}
        data = self._client.request("POST", "/v1/optimizer/conformance", json=body)
        return OptimizerResponse.model_validate(data)

    def monte_carlo(
        self,
        *,
        engagement: dict[str, Any],
        runs: int | None = None,
        seed: int | None = None,
    ) -> OptimizerResponse:
        """Run a risk-weighted Monte Carlo simulation.

        `runs` must be in [1, 100_000] (server-validated). Defaults 1000 /
        seed 42 apply server-side when omitted.
        """
        body: dict[str, Any] = {"engagement": engagement}
        if runs is not None:
            body["runs"] = runs
        if seed is not None:
            body["seed"] = seed
        data = self._client.request("POST", "/v1/optimizer/monte-carlo", json=body)
        return OptimizerResponse.model_validate(data)

    def calibration(self, *, findings: Any) -> OptimizerResponse:
        """Fit optimizer weights against a historical findings payload."""
        body = {"findings": findings}
        data = self._client.request("POST", "/v1/optimizer/calibration", json=body)
        return OptimizerResponse.model_validate(data)
