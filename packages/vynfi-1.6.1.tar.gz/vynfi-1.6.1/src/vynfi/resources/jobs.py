"""Jobs and data generation resource."""

from __future__ import annotations

import contextlib
import time
from collections.abc import Iterator
from pathlib import Path
from typing import Any, List

from .._archive import JobArchive
from .._client import SyncClient
from .._types import (
    AiTuneResponse,
    AuditArtifacts,
    CancelJobResponse,
    FraudSplit,
    Job,
    JobAnalytics,
    JobFileList,
    JobList,
    QuickJobResponse,
    SubmitJobResponse,
)


class Jobs:
    """Manage generation jobs."""

    def __init__(self, client: SyncClient) -> None:
        self._client = client

    def generate(
        self,
        *,
        tables: list[dict[str, Any]],
        format: str | None = None,
        sector_slug: str | None = None,
        options: dict[str, Any] | None = None,
    ) -> SubmitJobResponse:
        """Submit an async generation job using the legacy tables format.

        Args:
            tables: List of table specs, e.g. [{"name": "journal_entries", "rows": 5000}]
            format: Output format — "json", "csv", or "parquet"
            sector_slug: Sector to generate from
            options: Additional generation options
        """
        body: dict[str, Any] = {"tables": tables}
        if format is not None:
            body["format"] = format
        if sector_slug is not None:
            body["sector_slug"] = sector_slug
        if options is not None:
            body["options"] = options
        data = self._client.request("POST", "/v1/generate", json=body)
        return SubmitJobResponse.model_validate(data)

    def generate_config(
        self,
        *,
        config: dict[str, Any],
        config_id: str | None = None,
    ) -> SubmitJobResponse:
        """Submit an async generation job using a config object.

        Args:
            config: Full generation config dict
            config_id: Optional saved config ID to use as base
        """
        body: dict[str, Any] = {"config": config}
        if config_id is not None:
            body["config_id"] = config_id
        data = self._client.request("POST", "/v1/generate", json=body)
        return SubmitJobResponse.model_validate(data)

    def generate_quick(
        self,
        *,
        tables: list[dict[str, Any]],
        format: str | None = None,
        sector_slug: str | None = None,
        options: dict[str, Any] | None = None,
    ) -> QuickJobResponse:
        """Submit a synchronous (quick) generation job.

        Returns the completed job directly. Max 10,000 rows, 30s timeout.
        """
        body: dict[str, Any] = {"tables": tables}
        if format is not None:
            body["format"] = format
        if sector_slug is not None:
            body["sector_slug"] = sector_slug
        if options is not None:
            body["options"] = options
        data = self._client.request("POST", "/v1/generate/quick", json=body)
        return QuickJobResponse.model_validate(data)

    def list(
        self,
        *,
        status: str | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> JobList:
        """List jobs with optional filtering and pagination.

        Args:
            status: Filter by status (e.g. "completed", "running")
            limit: Max jobs to return (default 20, max 100)
            offset: Pagination offset (default 0)
        """
        params: dict[str, Any] = {}
        if status is not None:
            params["status"] = status
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset
        data = self._client.request("GET", "/v1/jobs", params=params)
        if isinstance(data, list):
            return JobList(data=[Job.model_validate(j) for j in data])
        items = data.get("data") or []
        return JobList(data=[Job.model_validate(j) for j in items])

    def get(self, job_id: str) -> Job:
        """Get a single job by ID."""
        data = self._client.request("GET", f"/v1/jobs/{job_id}")
        return Job.model_validate(data)

    def cancel(self, job_id: str) -> CancelJobResponse:
        """Cancel a queued or running job."""
        data = self._client.request("DELETE", f"/v1/jobs/{job_id}")
        return CancelJobResponse.model_validate(data)

    def stream(self, job_id: str) -> Iterator[dict[str, Any]]:
        """Stream SSE progress events for a job.

        Yields dicts with 'event' and 'data' keys.
        Events: progress, complete, error.
        """
        yield from self._client.stream_sse(f"/v1/jobs/{job_id}/stream")

    def stream_ndjson(
        self,
        job_id: str,
        *,
        rate: int | None = None,
        burst: int | None = None,
        progress_interval: int | None = None,
        file: str | None = None,
    ) -> Iterator[dict[str, Any]]:
        """Stream NDJSON output records from a job (DataSynth 2.3+, Scale tier+).

        Each yielded dict is either a data record or a progress envelope::

            {"type": "_progress", "lines_emitted": 1000}

        Args:
            job_id: The job ID
            rate: Lines per second (1-10000, default 1000)
            burst: Burst capacity (max 1000, default 100)
            progress_interval: Progress envelope every N lines (default 1000)
            file: Output file to stream (default "stream.ndjson")
        """
        params: dict[str, Any] = {}
        if rate is not None:
            params["rate"] = rate
        if burst is not None:
            params["burst"] = burst
        if progress_interval is not None:
            params["progress_interval"] = progress_interval
        if file is not None:
            params["file"] = file
        yield from self._client.stream_ndjson(
            f"/v1/jobs/{job_id}/stream/ndjson", params=params or None
        )

    def analytics(self, job_id: str) -> JobAnalytics:
        """Get pre-built analytics for a completed job (DataSynth 2.3+).

        Returns merged analytics from the job's archive:
        - Benford's Law conformity (leading-digit distribution)
        - Amount distribution statistics (skew, kurtosis, log-normal fit)
        - Process variant summary (entropy, happy-path concentration)
        - Banking evaluation (KYC, AML, cross-layer coherence, velocity, false-positive)

        Returns 404 for jobs generated before DataSynth 2.3.
        """
        data = self._client.request("GET", f"/v1/jobs/{job_id}/analytics")
        return JobAnalytics.model_validate(data)

    def audit_artifacts(self, job_id: str) -> AuditArtifacts:
        """Fetch parsed audit/anomaly JSON for a completed job (VynFi API 4.1+).

        Aggregates `audit/audit_opinions.json`, `audit/key_audit_matters.json`,
        and `anomaly_labels.json` into a single response. Absent files map
        to ``None``. Returns 404 when none of the three files exist.
        """
        data = self._client.request("GET", f"/v1/jobs/{job_id}/audit-artifacts")
        return AuditArtifacts.model_validate(data)

    def fraud_split(self, job_id: str) -> FraudSplit:
        """Get the fraud-origin split for a completed job (DS 3.1.1+).

        Aggregates `journal_entries.json` into scheme-propagated (inherited
        from a source document marked as fraud) vs direct-injection
        (line-level anomaly injection). Also breaks down by fraud_type.

        Useful for stratified ML training: teach cross-document detectors
        on the scheme population and noise-robust detectors on the direct
        population.

        Returns a reduced/degraded :class:`FraudSplit` for pre-3.1 jobs
        that lack the `is_fraud_propagated` field (scheme count = 0).
        """
        data = self._client.request("GET", f"/v1/jobs/{job_id}/fraud-split")
        return FraudSplit.model_validate(data)

    def list_files(self, job_id: str) -> JobFileList:
        """List all files in a completed job's output archive with sizes and schemas.

        Args:
            job_id: The job ID

        Returns:
            A :class:`JobFileList` with file paths, sizes, content types, and
            per-file column schemas extracted from the first JSON record.
        """
        # The managed_blob index can lag a second or two behind job completion
        # — retry a couple of times on 404 before giving up.
        from .._exceptions import NotFoundError

        last: Exception | None = None
        for delay in (0.0, 1.5, 3.0):
            if delay:
                time.sleep(delay)
            try:
                data = self._client.request("GET", f"/v1/jobs/{job_id}/files")
                return JobFileList.model_validate(data)
            except NotFoundError as e:
                last = e
                continue
        assert last is not None
        raise last

    def download(self, job_id: str) -> bytes:
        """Download the output archive for a completed job as raw bytes."""
        resp = self._client.request_raw("GET", f"/v1/jobs/{job_id}/download")
        return resp.content

    def download_archive(self, job_id: str) -> JobArchive:
        """Download the output archive and return a :class:`JobArchive` for easy access.

        Usage::

            archive = client.jobs.download_archive(job_id)
            entries = archive.json("journal_entries.json")
            print(archive.files())
        """
        return JobArchive(self.download(job_id))

    def download_file(self, job_id: str, file: str) -> bytes:
        """Download a specific file from a job's output.

        Args:
            job_id: The job ID
            file: Artifact path, e.g. "journal_entries.json"
        """
        resp = self._client.request_raw("GET", f"/v1/jobs/{job_id}/download/{file}")
        return resp.content

    def download_to(self, job_id: str, path: str | Path) -> Path:
        """Download job output archive to a local file.

        Args:
            job_id: The job ID
            path: Local file path to write to

        Returns:
            The Path where the file was saved
        """
        data = self.download(job_id)
        out = Path(path)
        out.write_bytes(data)
        return out

    def wait(
        self,
        job_id: str,
        *,
        poll_interval: float = 2.0,
        timeout: float = 300.0,
    ) -> Job:
        """Poll until a job reaches a terminal state.

        Args:
            job_id: The job ID to wait on
            poll_interval: Seconds between polls (default 2)
            timeout: Max seconds to wait (default 300)

        Returns:
            The completed (or failed/cancelled) Job
        """
        deadline = time.monotonic() + timeout
        while True:
            job = self.get(job_id)
            if job.status in ("completed", "failed", "cancelled"):
                return job
            if time.monotonic() >= deadline:
                return job
            time.sleep(poll_interval)

    def wait_for_many(
        self,
        job_ids: List[str],
        *,
        poll_interval: float = 2.0,
        timeout: float = 600.0,
    ) -> List[Job]:
        """Poll until every job in ``job_ids`` reaches a terminal state.

        Polls sequentially in a tight loop (all jobs share the deadline), so
        in practice they finish concurrently server-side. Useful for the
        scenarios and sessions APIs, which routinely spawn paired jobs
        (baseline + counterfactual, period N + N+1, …).

        Args:
            job_ids: Iterable of job IDs to wait on.
            poll_interval: Seconds between polls (default 2).
            timeout: Total seconds to wait across all jobs (default 600).

        Returns:
            List of :class:`Job` objects in the same order as ``job_ids``,
            each in its final state (completed / failed / cancelled) or
            the last-seen state if the timeout was reached.
        """
        deadline = time.monotonic() + timeout
        results: dict[str, Job] = {}
        pending: List[str] = list(job_ids)
        terminal = {"completed", "failed", "cancelled"}
        while pending and time.monotonic() < deadline:
            for jid in list(pending):
                try:
                    job = self.get(jid)
                except Exception:
                    continue
                results[jid] = job
                if job.status in terminal:
                    pending.remove(jid)
            if pending:
                time.sleep(poll_interval)
        # Capture the last-known state for any still-pending ids
        for jid in list(pending):
            if jid not in results:
                with contextlib.suppress(Exception):
                    results[jid] = self.get(jid)
        return [results[jid] for jid in job_ids if jid in results]

    def tune(
        self,
        job_id: str,
        *,
        target_scores: dict[str, Any] | None = None,
        max_iterations: int | None = None,
    ) -> AiTuneResponse:
        """Get an AI-suggested config that improves a completed job's quality (DS 3.0+, Scale+).

        Reads the job's config and quality scores, prompts an LLM to patch the
        config for better outcomes, and returns both configs plus an explanation.

        Args:
            job_id: A completed job ID to tune from.
            target_scores: Optional target benchmarks (e.g. ``{"overall": 0.95}``).
            max_iterations: Reserved for multi-round tuning (Phase 3b).

        Returns:
            :class:`AiTuneResponse` with ``original_config``, ``suggested_config``,
            ``explanation``, and ``quality_summary``.
        """
        body: dict[str, Any] = {}
        if target_scores is not None:
            body["targetScores"] = target_scores
        if max_iterations is not None:
            body["maxIterations"] = max_iterations
        data = self._client.request("POST", f"/v1/jobs/{job_id}/tune", json=body)
        return AiTuneResponse.model_validate(data)
