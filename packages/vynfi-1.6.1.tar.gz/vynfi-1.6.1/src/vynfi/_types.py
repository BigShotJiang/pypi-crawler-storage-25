"""Pydantic models for VynFi API responses."""

from __future__ import annotations

from datetime import date, datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


def _to_camel(name: str) -> str:
    parts = name.split("_")
    return parts[0] + "".join(w.capitalize() for w in parts[1:])


class _CamelModel(BaseModel):
    """Base for models where the API returns camelCase keys."""

    model_config = ConfigDict(alias_generator=_to_camel, populate_by_name=True)


# ── Jobs ──────────────────────────────────────────────────────────────────────


class JobLinks(BaseModel):
    self_link: str = Field(default="", alias="self")
    stream: str = ""
    cancel: str = ""

    model_config = ConfigDict(populate_by_name=True)


class Job(BaseModel):
    id: str
    owner_id: str | None = None
    status: str
    config: Any = None
    progress: Any = None
    credits_reserved: int = 0
    credits_used: int | None = None
    artifacts: Any = None
    error_detail: str | None = None
    started_at: datetime | None = None
    completed_at: datetime | None = None
    created_at: datetime | None = None


class SubmitJobResponse(BaseModel):
    id: str
    status: str
    credits_reserved: int = 0
    estimated_duration_seconds: int = 0
    links: JobLinks | None = None


class QuickJobResponse(BaseModel):
    id: str
    status: str
    credits_used: int = 0
    rows_generated: int = 0
    download_url: str | None = None


class CancelJobResponse(BaseModel):
    id: str
    status: str
    credits_reserved: int = 0
    credits_used: int = 0
    credits_refunded: int = 0
    rows_generated: int = 0
    rows_total: int = 0


class JobList(BaseModel):
    data: list[Job] = Field(default_factory=list)


class FileSchema(BaseModel):
    name: str = ""
    type: str = ""


class JobFile(_CamelModel):
    path: str
    size_bytes: int = 0
    content_type: str = ""
    schema_: list[FileSchema] = Field(default_factory=list, alias="schema")


class JobFileList(_CamelModel):
    job_id: str = ""
    total_files: int = 0
    total_size_bytes: int = 0
    files: list[JobFile] = Field(default_factory=list)


# ── Analytics (DataSynth 2.3) ─────────────────────────────────────────────────


class BenfordAnalysis(BaseModel):
    """Benford's Law conformity analysis from analytics/benford_analysis.json."""

    sample_size: int = 0
    observed_frequencies: list[float] = Field(default_factory=list)
    observed_counts: list[int] = Field(default_factory=list)
    expected_frequencies: list[float] = Field(default_factory=list)
    chi_squared: float = 0.0
    degrees_of_freedom: int = 8
    p_value: float = 0.0
    mad: float = 0.0
    conformity: str = ""
    max_deviation: tuple[int, float] | None = None
    passes: bool = False
    anti_benford_score: float = 0.0


class AmountDistributionAnalysis(BaseModel):
    """Amount distribution statistics from analytics/amount_distribution.json."""

    sample_size: int = 0
    mean: str = "0"
    median: str = "0"
    std_dev: str = "0"
    min: str = "0"
    max: str = "0"
    percentile_1: str = "0"
    percentile_99: str = "0"
    skewness: float = 0.0
    kurtosis: float = 0.0
    lognormal_ks_stat: float | None = None
    lognormal_ks_pvalue: float | None = None
    fitted_mu: float | None = None
    fitted_sigma: float | None = None
    round_number_ratio: float = 0.0
    nice_number_ratio: float = 0.0
    passes: bool = False


class VariantAnalysis(BaseModel):
    """Process mining variant analysis from analytics/process_variant_summary.json.

    DS 3.1.0 adds per-variant deviation rates (rework, skipped steps,
    out-of-order events) so Inductive Miner fitness drops from a
    suspiciously perfect 1.0 to a realistic 0.7–0.9.
    """

    variant_count: int = 0
    total_cases: int = 0
    variant_entropy: float = 0.0
    happy_path_concentration: float = 0.0
    top_variants: list[tuple[str, float]] = Field(default_factory=list)
    passes: bool = False
    issues: list[str] = Field(default_factory=list)
    # DS 3.1.0 imperfection summary
    rework_rate: float = 0.0
    skipped_step_rate: float = 0.0
    out_of_order_rate: float = 0.0


class FraudTypeSplit(BaseModel):
    """Per-fraud-type scheme-vs-direct breakdown from the fraud_split endpoint."""

    total: int = 0
    scheme_propagated: int = 0
    direct_injection: int = 0


class FraudSplit(BaseModel):
    """Aggregated fraud-origin split for a job (DS 3.1.1 + VynFi API).

    Distinguishes fraud that was propagated from a fraudulent source document
    (scheme-level, like a procurement ring) from fraud that was directly
    injected into journal entry lines (line-level anomalies).
    """

    total_entries: int = 0
    fraud_entries: int = 0
    scheme_propagated: int = 0
    direct_injection: int = 0
    propagation_rate: float = 0.0
    by_fraud_type: dict[str, FraudTypeSplit] = Field(default_factory=dict)


class AuditOpinion(BaseModel):
    """ISA 700 audit opinion (DS 3.1.0+, archive: audit/audit_opinions.json)."""

    opinion_id: str = ""
    company_code: str = ""
    fiscal_year: int | None = None
    opinion_type: str = ""
    going_concern: str = ""
    basis_for_opinion: str = ""
    signed_by: str = ""
    signed_date: str = ""
    matters: list[Any] = Field(default_factory=list)


class KeyAuditMatter(BaseModel):
    """ISA 701 key audit matter (DS 3.1.0+, archive: audit/key_audit_matters.json)."""

    matter_id: str = ""
    company_code: str = ""
    fiscal_year: int | None = None
    title: str = ""
    description: str = ""
    audit_response: str = ""
    related_accounts: list[str] = Field(default_factory=list)
    risk_level: str = ""


class KycCompletenessAnalysis(BaseModel):
    core_field_rate: float = 0.0
    name_rate: float = 0.0
    dob_rate: float = 0.0
    address_rate: float = 0.0
    id_document_rate: float = 0.0
    risk_rating_rate: float = 0.0
    beneficial_owner_rate: float = 0.0
    verification_rate: float = 0.0
    total_profiles: int = 0
    passes: bool = False
    issues: list[str] = Field(default_factory=list)


class TypologyDetection(BaseModel):
    name: str = ""
    transaction_count: int = 0
    case_count: int = 0
    flag_rate: float = 0.0
    pattern_detected: bool = False


class AmlDetectabilityAnalysis(BaseModel):
    typology_coverage: float = 0.0
    scenario_coherence: float = 0.0
    per_typology: list[TypologyDetection] = Field(default_factory=list)
    total_transactions: int = 0
    passes: bool = False
    issues: list[str] = Field(default_factory=list)


class CrossLayerCoherenceAnalysis(BaseModel):
    total_bank_transactions: int = 0
    bridged_transactions: int = 0
    dangling_payment_refs: int = 0
    unpropagated_fraud_payments: int = 0
    total_fraud_payments: int = 0
    missing_gl_account: int = 0
    amount_mismatches: int = 0
    mirror_transactions: int = 0
    fraud_propagation_rate: float = 0.0
    passes: bool = False
    issues: list[str] = Field(default_factory=list)


class VelocityQualityAnalysis(BaseModel):
    total_transactions: int = 0
    with_velocity: int = 0
    coverage_rate: float = 0.0
    window_ordering_violations: int = 0
    amount_ordering_violations: int = 0
    zscore_mean: float = 0.0
    zscore_std: float = 0.0
    passes: bool = False
    issues: list[str] = Field(default_factory=list)


class FalsePositiveAnalysis(BaseModel):
    total_transactions: int = 0
    suspicious_count: int = 0
    false_positive_count: int = 0
    overlap_count: int = 0
    missing_reason_count: int = 0
    fp_rate: float = 0.0
    passes: bool = False
    issues: list[str] = Field(default_factory=list)


class BankingEvaluation(BaseModel):
    """Banking/AML evaluation aggregating sub-analyses (analytics/banking_evaluation.json)."""

    kyc: KycCompletenessAnalysis | None = None
    aml: AmlDetectabilityAnalysis | None = None
    cross_layer: CrossLayerCoherenceAnalysis | None = None
    velocity: VelocityQualityAnalysis | None = None
    false_positive: FalsePositiveAnalysis | None = None
    passes: bool = False
    issues: list[str] = Field(default_factory=list)


class JobAnalytics(BaseModel):
    """Merged analytics from a job's archive (GET /v1/jobs/{id}/analytics)."""

    benford_analysis: BenfordAnalysis | None = None
    amount_distribution: AmountDistributionAnalysis | None = None
    process_variant_summary: VariantAnalysis | None = None
    banking_evaluation: BankingEvaluation | None = None


class SseEvent(BaseModel):
    event: str = ""
    data: Any = None


# ── Catalog / Sectors ─────────────────────────────────────────────────────────


class Column(BaseModel):
    name: str
    data_type: str = ""
    description: str = ""
    nullable: bool = False
    example_values: list[str] | None = None


class TableDef(BaseModel):
    id: str | None = None
    slug: str | None = None
    name: str
    description: str = ""
    base_rate: float = 1.0
    columns: list[Column] = Field(default_factory=list)


class Sector(BaseModel):
    id: str | None = None
    slug: str
    name: str
    description: str = ""
    icon: str = ""
    multiplier: float = 1.0
    quality_score: int = 0
    popularity: int = 0
    tables: list[TableDef] = Field(default_factory=list)


class SectorSummary(BaseModel):
    id: str | None = None
    slug: str
    name: str
    description: str = ""
    icon: str = ""
    multiplier: float = 1.0
    quality_score: int = 0
    popularity: int = 0
    table_count: int = 0


class CatalogItem(BaseModel):
    id: str | None = None
    slug: str = ""
    name: str = ""
    description: str = ""
    icon: str = ""
    multiplier: float = 1.0
    quality_score: int = 0
    popularity: int = 0
    table_count: int = 0


class Fingerprint(BaseModel):
    sector: Any = None
    table: TableDef | None = None


class Template(_CamelModel):
    id: str
    slug: str
    name: str
    description: str = ""
    sector: str = ""
    country: str = ""
    framework: str = ""
    config: Any = None
    min_tier: str = ""
    sort_order: int = 0


# ── Usage ─────────────────────────────────────────────────────────────────────


class UsageSummary(BaseModel):
    balance: int = 0
    total_used: int = 0
    total_reserved: int = 0
    total_refunded: int = 0
    period_days: int = 30
    burn_rate: int = 0


class DailyUsage(BaseModel):
    date: date
    credits: int = 0


class TableUsage(BaseModel):
    table_name: str = ""
    credits: int = 0
    job_count: int = 0


class DailyUsageResponse(BaseModel):
    daily: list[DailyUsage] = Field(default_factory=list)
    by_table: list[TableUsage] = Field(default_factory=list)


# ── API Keys ──────────────────────────────────────────────────────────────────


class ApiKey(BaseModel):
    id: str
    name: str
    prefix: str = ""
    environment: str = ""
    status: str = "active"
    last_used_at: datetime | None = None
    created_at: datetime | None = None


class ApiKeyCreated(BaseModel):
    id: str
    name: str
    prefix: str = ""
    key: str = ""
    environment: str = ""
    created_at: datetime | None = None


class RevokeKeyResponse(BaseModel):
    id: str
    status: str = ""
    revoked_at: datetime | None = None


# ── Quality ───────────────────────────────────────────────────────────────────


class QualityScore(BaseModel):
    id: str
    job_id: str
    table_type: str = ""
    rows: int = 0
    overall_score: float = 0.0
    benford_score: float = 0.0
    correlation_score: float = 0.0
    distribution_score: float = 0.0
    created_at: datetime | None = None


class DailyQuality(BaseModel):
    date: date
    score: float = 0.0


# ── Webhooks ──────────────────────────────────────────────────────────────────


class Webhook(BaseModel):
    id: str
    url: str
    events: list[str] = Field(default_factory=list)
    status: str = "active"
    created_at: datetime | None = None


class WebhookCreated(BaseModel):
    id: str
    url: str
    events: list[str] = Field(default_factory=list)
    secret: str = ""
    status: str = "active"
    created_at: datetime | None = None


class WebhookDelivery(BaseModel):
    id: str
    webhook_id: str = ""
    event_type: str = ""
    payload: Any = None
    status_code: int | None = None
    response_body: str | None = None
    attempt: int = 0
    succeeded: bool = False
    created_at: datetime | None = None


class WebhookDetail(BaseModel):
    id: str
    url: str
    events: list[str] = Field(default_factory=list)
    secret: str | None = None
    status: str = ""
    created_at: datetime | None = None
    deliveries: list[WebhookDelivery] = Field(default_factory=list)


# ── Billing ───────────────────────────────────────────────────────────────────


class Subscription(BaseModel):
    tier: str = ""
    status: str = ""
    stripe_price_id: str | None = None
    current_period_end: datetime | None = None


class CheckoutResponse(BaseModel):
    checkout_url: str


class PortalResponse(BaseModel):
    portal_url: str


class Invoice(BaseModel):
    id: str = ""
    number: str | None = None
    amount_due: int = 0
    amount_paid: int = 0
    status: str = ""
    created: int = 0
    due_date: int | None = None
    hosted_invoice_url: str | None = None
    pdf: str | None = None


# ── Configs ───────────────────────────────────────────────────────────────────


class SavedConfig(_CamelModel):
    id: str
    owner_id: str = ""
    name: str = ""
    description: str = ""
    config: Any = None
    source_template_id: str | None = None
    version: int = 0
    visibility: str = ""
    tags: list[str] = Field(default_factory=list)
    last_used_at: datetime | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None
    schema_version: int | None = None


class DeletedResponse(BaseModel):
    deleted: bool = False


class ValidationFix(BaseModel):
    field: str = ""
    action: str = ""
    value: Any = None


class ValidationIssue(BaseModel):
    field: str = ""
    code: str = ""
    message: str = ""
    fix: ValidationFix | None = None


class ValidateConfigResponse(BaseModel):
    valid: bool = False
    errors: list[ValidationIssue] = Field(default_factory=list)
    warnings: list[ValidationIssue] = Field(default_factory=list)


class MultiplierEntry(BaseModel):
    source: str = ""
    factor: float = 0.0
    label: str = ""


class BalanceInfo(_CamelModel):
    current: int = 0
    after_job: int = 0
    status: str = ""


class OutputEstimate(_CamelModel):
    estimated_files: int = 0
    estimated_size_bytes: int = 0
    note: str = ""


class EstimateCostResponse(_CamelModel):
    base_credits: int = 0
    multipliers: list[MultiplierEntry] = Field(default_factory=list)
    total_credits: int = 0
    capped_at: float | None = None
    balance: BalanceInfo | None = None
    output: OutputEstimate | None = None


class ComposeConfigResponse(BaseModel):
    config: Any = None
    yaml: str = ""
    layers: list[Any] = Field(default_factory=list)


class SizeBucket(BaseModel):
    domain: str = ""
    bytes: int = 0


class EstimateSizeResponse(_CamelModel):
    """Response from POST /v1/configs/estimate-size — TB-scale storage validation."""

    estimated_bytes: int = 0
    estimated_files: int = 0
    tier_quota_bytes: int = 0
    exceeds_quota: bool = False
    warning: str | None = None
    breakdown: list[SizeBucket] = Field(default_factory=list)


class RawConfigResponse(_CamelModel):
    """Response from POST /v1/configs/raw — Scale+ tier raw YAML config submission."""

    valid: bool = False
    estimated_credits: int = 0
    warnings: list[str] = Field(default_factory=list)
    config_id: str | None = None


# ── Credits ───────────────────────────────────────────────────────────────────


class PurchaseCreditsResponse(BaseModel):
    checkout_url: str = ""


class PrepaidBatch(_CamelModel):
    id: str
    owner_id: str = ""
    pack: str = ""
    credits_purchased: int = 0
    credits_remaining: int = 0
    credits_forfeited: int = 0
    status: str = ""
    purchased_at: datetime | None = None
    expires_at: datetime | None = None
    created_at: datetime | None = None


class PrepaidBalanceResponse(BaseModel):
    total_prepaid_credits: int = 0
    batches: list[PrepaidBatch] = Field(default_factory=list)


class PrepaidHistoryResponse(BaseModel):
    batches: list[PrepaidBatch] = Field(default_factory=list)


# ── Sessions ──────────────────────────────────────────────────────────────────


class GenerationSession(_CamelModel):
    id: str
    name: str = ""
    status: str = ""
    fiscal_year_start: str = ""
    period_length_months: int = 0
    periods_total: int = 0
    periods_generated: int = 0
    periods: Any = None
    balance_snapshot: Any = None
    generation_config: Any = None
    created_at: datetime | None = None
    updated_at: datetime | None = None


class GenerateSessionResponse(_CamelModel):
    id: str
    name: str = ""
    status: str = ""
    fiscal_year_start: str = ""
    period_length_months: int = 0
    periods_total: int = 0
    periods_generated: int = 0
    periods: Any = None
    balance_snapshot: Any = None
    generation_config: Any = None
    created_at: datetime | None = None
    updated_at: datetime | None = None
    job_id: str = ""
    period_index: int = 0
    credits_reserved: int = 0
    period_start: str = ""
    period_end: str = ""


# ── Scenarios ─────────────────────────────────────────────────────────────────


class Scenario(_CamelModel):
    id: str
    name: str = ""
    template_id: str = ""
    status: str = ""
    interventions: Any = None
    generation_config: Any = None
    baseline_job_id: str | None = None
    counterfactual_job_id: str | None = None
    diff: Any = None
    created_at: datetime | None = None
    updated_at: datetime | None = None


class ScenarioTemplateNode(BaseModel):
    id: str
    label: str = ""
    x: int = 0
    y: int = 0


class ScenarioTemplateEdge(BaseModel):
    source: str = ""
    target: str = ""


class ScenarioTemplate(_CamelModel):
    id: str
    name: str = ""
    description: str = ""
    node_count: int = 0
    nodes: list[ScenarioTemplateNode] = Field(default_factory=list)
    edges: list[ScenarioTemplateEdge] = Field(default_factory=list)
    intervention_types: list[str] = Field(default_factory=list)


# ── Scenario Packs (DS 3.0) ───────────────────────────────────────────────────


class ScenarioPack(BaseModel):
    """A built-in DataSynth scenario pack (fraud, control_failure, macro, operational)."""

    name: str
    category: str = ""
    description: str = ""


class ScenarioPackList(BaseModel):
    packs: list[ScenarioPack] = Field(default_factory=list)


# ── Fingerprint Synthesis (DS 3.0) ────────────────────────────────────────────


class FingerprintSynthesisResponse(_CamelModel):
    """Response from POST /v1/fingerprint/synthesize."""

    job_id: str = ""
    status: str = ""
    rows: int = 0
    backend: str = ""


# ── Adversarial Probing (DS 3.0, Enterprise) ──────────────────────────────────


class AdversarialProbeResponse(BaseModel):
    """Response from POST /v1/adversarial/probe — job submission."""

    id: str
    status: str = ""
    message: str = ""


class ProbeSample(BaseModel):
    features: list[float] = Field(default_factory=list)
    score: float = 0.0
    predicted_positive: bool = False
    margin: float = 0.0


class AdversarialProbeResults(BaseModel):
    """Full probe results from GET /v1/adversarial/{id}/results."""

    n_probes: int = 0
    mean_score: float = 0.0
    std_score: float = 0.0
    positive_rate: float = 0.0
    mean_margin: float = 0.0
    boundary_samples: list[ProbeSample] = Field(default_factory=list)
    model_config = ConfigDict(protected_namespaces=())


# ── AI Tuning (DS 3.0, Scale+) ────────────────────────────────────────────────


class QualitySummary(_CamelModel):
    overall: str = ""
    benford: str = ""
    distribution: str = ""
    rows_analyzed: int = 0


class AiTuneResponse(_CamelModel):
    """Response from POST /v1/jobs/{id}/tune."""

    original_config: Any = None
    suggested_config: Any = None
    explanation: str = ""
    quality_summary: QualitySummary | None = None


# ── AI Chat (DS 3.0, Scale+) ──────────────────────────────────────────────────


class AiChatResponse(BaseModel):
    reply: str = ""


# ── Notifications ─────────────────────────────────────────────────────────────


class Notification(BaseModel):
    id: str
    user_id: str = ""
    type: str = Field(default="", alias="type")
    title: str = ""
    message: str = ""
    link: str | None = None
    read: bool = False
    created_at: datetime | None = None

    model_config = ConfigDict(populate_by_name=True)


# ── Optimizer (VynFi API 4.1+, DS 4.1.2+, Scale+) ─────────────────────────────


class OptimizerResponse(BaseModel):
    """Response wrapper for every `/v1/optimizer/*` endpoint.

    The `report` payload is the CLI's JSON output, left unstructured so the
    SDK doesn't have to evolve with each DS 4.1.x stub → real-analytics
    migration. Treat it as a read-only dict.
    """

    report: Any = None


# ── Template packs (VynFi API 4.1+, Team+ tier) ───────────────────────────────


class TemplatePackCategorySummary(_CamelModel):
    category: str
    size_bytes: int = 0
    updated_at: datetime | None = None


class TemplatePack(_CamelModel):
    id: str
    name: str
    description: str | None = None
    merge_strategy: str = "extend"
    created_at: datetime | None = None
    updated_at: datetime | None = None
    categories: list[TemplatePackCategorySummary] = Field(default_factory=list)


class TemplatePackList(_CamelModel):
    packs: list[TemplatePack] = Field(default_factory=list)
    limit: int = 0


class TemplatePackValidationIssue(BaseModel):
    category: str = ""
    message: str = ""


class TemplatePackValidation(_CamelModel):
    valid: bool = True
    categories_checked: list[str] = Field(default_factory=list)
    issues: list[TemplatePackValidationIssue] = Field(default_factory=list)


class TemplatePackCategoryContent(_CamelModel):
    category: str
    content_yaml: str = ""
    size_bytes: int = 0
    updated_at: datetime | None = None


class TemplatePackEnrichResponse(_CamelModel):
    category: str
    target_pack_category: str
    count_requested: int = 0
    size_bytes_after: int = 0
    model: str = ""
    seed: int = 0


# ── NL config (VynFi API 4.1+, Scale+) ────────────────────────────────────────


class NlConfigResponse(_CamelModel):
    """Response from `POST /v1/configs/from-description` and friends."""

    config: Any = None
    yaml: str = ""
    confidence: float = 0.0
    notes: str = ""


class CompanyConfigResponse(_CamelModel):
    """Response from `POST /v1/configs/from-company`."""

    company: Any = None
    config: Any = None
    yaml: str = ""
    notes: str = ""


class BatchCompanyResponse(_CamelModel):
    results: list[CompanyConfigResponse] = Field(default_factory=list)
    errors: list[str] = Field(default_factory=list)


# ── Audit artifacts (VynFi API 4.1+) ──────────────────────────────────────────


class AuditArtifacts(BaseModel):
    """Aggregated audit/anomaly JSON from `GET /v1/jobs/{id}/audit-artifacts`.

    Each optional field mirrors an archive file under `audit/` or the
    top-level `anomaly_labels.json`. Absent files stay `None`.
    """

    audit_opinions: Any = None
    key_audit_matters: Any = None
    anomaly_labels: Any = None
