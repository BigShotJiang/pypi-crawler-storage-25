"""VynFi fingerprint synthesis — privacy-preserving data generation (DS 3.0+).

Given a ``.dsf`` fingerprint file (statistical summary of a private dataset),
synthesize new records that match its distributions without exposing raw values.

Tier gates:
- Team+ for the ``statistical`` backend (default, fast)
- Scale+ for ``neural`` / ``hybrid`` backends (higher fidelity)

Credits: 2.0 x rows / 1000  (2x multiplier for synthesis).
"""

import os
from pathlib import Path

import vynfi

client = vynfi.VynFi(api_key=os.environ["VYNFI_API_KEY"])

# Pass a .dsf file path or bytes
fingerprint_path = Path(os.environ.get("VYNFI_FINGERPRINT", "./sample.dsf"))

if not fingerprint_path.exists():
    print(f"No fingerprint file at {fingerprint_path} — nothing to synthesize.")
    print("Usage: VYNFI_FINGERPRINT=/path/to/data.dsf python fingerprint_synthesis.py")
    # Exit 0 so regression runs treat a missing fingerprint as a skip, not a fail.
    raise SystemExit(0)

print(f"Uploading {fingerprint_path} ({fingerprint_path.stat().st_size:,} bytes)...")

# ── Submit synthesis job ────────────────────────────────────────────────────

submission = client.fingerprint.synthesize(
    fingerprint_path,
    rows=5000,
    backend="statistical",  # or "neural" / "hybrid" (Scale+)
    seed=42,
)

print(f"  Job: {submission.job_id}")
print(f"  Status: {submission.status}")
print(f"  Rows: {submission.rows}")
print(f"  Backend: {submission.backend}")

# ── Wait for completion ─────────────────────────────────────────────────────

job = client.jobs.wait(submission.job_id, timeout=600)
print(f"\nFinal status: {job.status}")

if job.status == "completed":
    archive = client.jobs.download_archive(job.id)
    print(f"Archive: {archive}")
    print("Synthesized files:")
    for f in archive.files()[:10]:
        print(f"  {f}")
