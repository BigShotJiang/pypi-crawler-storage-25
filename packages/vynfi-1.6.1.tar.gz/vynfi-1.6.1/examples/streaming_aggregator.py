"""VynFi Streaming — running aggregations over a live stream.

Compute statistics on journal entries as they stream through, without loading
the full archive into memory. Perfect for:
- Memory-constrained environments (serverless, edge)
- Very large jobs (TB-scale)
- Live dashboards that can't wait for batch ETL

Requires Scale tier.
"""

import os
import time
from collections import defaultdict
from decimal import Decimal, InvalidOperation

import vynfi

client = vynfi.VynFi(api_key=os.environ["VYNFI_API_KEY"])

job = client.jobs.list(status="completed", limit=1).data[0]
print(f"Aggregating stream from job: {job.id}")
print()


def to_dec(x: object) -> Decimal:
    """Parse a stringified decimal to Decimal, tolerating native numbers too."""
    if x is None or x == "":
        return Decimal("0")
    try:
        return Decimal(str(x))
    except InvalidOperation:
        return Decimal("0")


# Running aggregates — O(1) memory regardless of stream size
total_records = 0
total_debit = Decimal("0")
total_credit = Decimal("0")
by_process: dict[str, int] = defaultdict(int)
by_account: dict[str, Decimal] = defaultdict(lambda: Decimal("0"))
max_amount = Decimal("0")
max_amount_doc = ""

start = time.monotonic()

for env in client.jobs.stream_ndjson(
    job.id,
    file="journal_entries.json",
    rate=2000,             # 2000 lines/sec
    progress_interval=500,
):
    if env.get("type") == "_progress":
        elapsed = time.monotonic() - start
        rate = env["lines_emitted"] / max(elapsed, 0.001)
        print(f"  [progress] {env['lines_emitted']} lines @ {rate:.0f}/s")
        continue

    total_records += 1

    # Works for both nested (header + lines) and flat layouts
    header = env.get("header", env)
    bp = header.get("business_process", "UNKNOWN")
    by_process[bp] += 1

    lines = env.get("lines", [env]) if "lines" in env else [env]
    for line in lines:
        debit = to_dec(line.get("debit_amount"))
        credit = to_dec(line.get("credit_amount"))
        total_debit += debit
        total_credit += credit
        account = line.get("gl_account", "?")
        by_account[account] += debit + credit
        amount = max(debit, credit)
        if amount > max_amount:
            max_amount = amount
            max_amount_doc = str(header.get("document_id", "?"))[:30]

    # Stop after a reasonable sample for demo
    if total_records >= 100:
        break

elapsed = time.monotonic() - start
print()
print(f"Processed {total_records:,} entries in {elapsed:.1f}s")
print()
print("Running aggregates (O(1) memory, no disk I/O):")
print(f"  Total debits:   ${total_debit:>18,.2f}")
print(f"  Total credits:  ${total_credit:>18,.2f}")
print(f"  Balanced:       {abs(total_debit - total_credit) < Decimal('0.01')}")
print(f"  Max line item:  ${max_amount:>18,.2f}  (doc {max_amount_doc})")
print()
print("Business process distribution:")
for bp, count in sorted(by_process.items(), key=lambda x: -x[1]):
    print(f"  {bp:10s}  {count:5d}  ({count / total_records:.1%})")
print()
print("Top 10 GL accounts by activity:")
top_accounts = sorted(by_account.items(), key=lambda x: -x[1])[:10]
for acct, total in top_accounts:
    print(f"  {acct:12s}  ${total:>18,.2f}")
