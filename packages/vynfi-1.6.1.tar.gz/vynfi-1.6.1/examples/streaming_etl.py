"""VynFi Streaming ETL — chunk-batched DataFrame/Parquet writes.

Stream data from the API and write in batched chunks to pandas / Parquet.
This pattern scales to TB-sized jobs without OOMing the consumer.

Requires Scale tier. pandas + pyarrow for Parquet output.
"""

import os
import tempfile
import time
from decimal import Decimal, InvalidOperation
from pathlib import Path

import pandas as pd

import vynfi

client = vynfi.VynFi(api_key=os.environ["VYNFI_API_KEY"])

job = client.jobs.list(status="completed", limit=1).data[0]
print(f"ETL from job: {job.id}")
print()


def to_float(x: object) -> float | None:
    if x is None or x == "":
        return None
    try:
        return float(Decimal(str(x)))
    except InvalidOperation:
        return None


# ── Chunked stream → DataFrame → Parquet ────────────────────────────────────

CHUNK_SIZE = 200
output_dir = Path(tempfile.mkdtemp(prefix="vynfi_etl_"))
print(f"Output directory: {output_dir}")

chunk: list[dict] = []
chunks_written = 0
total_rows = 0
start = time.monotonic()

for env in client.jobs.stream_ndjson(
    job.id,
    file="journal_entries.json",
    rate=1000,
    progress_interval=500,
):
    if env.get("type") == "_progress":
        elapsed = time.monotonic() - start
        print(f"  [progress] {env['lines_emitted']} lines in {elapsed:.1f}s")
        continue

    # Flatten (header + lines) into one row per line item
    header = env.get("header", env)
    lines = env.get("lines", [env]) if "lines" in env else [env]
    for line in lines:
        chunk.append(
            {
                "document_id": header.get("document_id"),
                "company_code": header.get("company_code"),
                "posting_date": header.get("posting_date"),
                "business_process": header.get("business_process"),
                "document_type": header.get("document_type"),
                "is_fraud": header.get("is_fraud", False),
                "gl_account": line.get("gl_account"),
                "debit_amount": to_float(line.get("debit_amount")),
                "credit_amount": to_float(line.get("credit_amount")),
            }
        )

    # Write a chunk when full
    if len(chunk) >= CHUNK_SIZE:
        df = pd.DataFrame(chunk)
        out = output_dir / f"chunk_{chunks_written:04d}.parquet"
        try:
            df.to_parquet(out, index=False)
        except ImportError:
            out = out.with_suffix(".csv")
            df.to_csv(out, index=False)
        chunks_written += 1
        total_rows += len(chunk)
        print(f"  [write] chunk {chunks_written}: {len(chunk)} rows → {out.name}")
        chunk = []

    # Demo cap
    if chunks_written >= 3:
        break

# Final partial chunk
if chunk:
    df = pd.DataFrame(chunk)
    out = output_dir / f"chunk_{chunks_written:04d}.parquet"
    try:
        df.to_parquet(out, index=False)
    except ImportError:
        out = out.with_suffix(".csv")
        df.to_csv(out, index=False)
    chunks_written += 1
    total_rows += len(chunk)

elapsed = time.monotonic() - start
print()
print(f"ETL complete: {chunks_written} chunks, {total_rows:,} rows in {elapsed:.1f}s")
print(f"Files on disk:")
for p in sorted(output_dir.iterdir()):
    print(f"  {p.name}: {p.stat().st_size:,} bytes")

# Show how a consumer would read them back
print()
print("Reading back combined dataset:")
files = sorted(output_dir.glob("chunk_*"))
if files and files[0].suffix == ".parquet":
    combined = pd.concat([pd.read_parquet(f) for f in files], ignore_index=True)
else:
    combined = pd.concat([pd.read_csv(f) for f in files], ignore_index=True)
print(f"  Total rows: {len(combined):,}")
print(f"  Total debits: ${combined['debit_amount'].sum():,.2f}")
print(f"  Balanced: {abs(combined['debit_amount'].sum() - combined['credit_amount'].sum()) < 0.01}")
