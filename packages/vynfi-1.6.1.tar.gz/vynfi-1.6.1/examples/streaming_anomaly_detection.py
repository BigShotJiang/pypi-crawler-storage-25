"""VynFi Streaming — real-time anomaly detection.

Stream AML anomaly labels line-by-line and trigger alerts as they arrive.
This pattern is perfect for:
- Fraud monitoring dashboards
- SIEM/SOC integrations
- Compliance reporting pipelines
- ML inference at the edge

Requires Scale tier.
"""

import os
from collections import Counter

import vynfi

client = vynfi.VynFi(api_key=os.environ["VYNFI_API_KEY"])

# Find a recent completed job that supports NDJSON streaming (not every
# managed_blob archive exposes the stream endpoint).
job = None
for candidate in client.jobs.list(status="completed", limit=10).data:
    try:
        probe = client.jobs.stream_ndjson(candidate.id, file="labels/anomaly_labels.jsonl")
        next(probe)
        try:
            probe.close()  # type: ignore[union-attr]
        except AttributeError:
            pass
        job = candidate
        break
    except (vynfi.NotFoundError, StopIteration):
        continue
if job is None:
    raise SystemExit("No completed job with a streamable anomaly_labels.jsonl found.")
print(f"Streaming anomalies from job: {job.id}")
print()

# ── Real-time alerting as labels arrive ──────────────────────────────────────
#
# The archive includes `labels/anomaly_labels.jsonl` — true NDJSON, one anomaly
# per line. We stream it with rate control so a downstream consumer (dashboard,
# queue) isn't overwhelmed.

severity_counts: Counter = Counter()
doc_type_counts: Counter = Counter()
alerts_raised = 0
records_seen = 0

for env in client.jobs.stream_ndjson(
    job.id,
    file="labels/anomaly_labels.jsonl",
    rate=200,             # 200 anomalies/sec — realistic SOC ingestion rate
    progress_interval=100,
):
    if env.get("type") == "_progress":
        print(f"  [progress] processed {env['lines_emitted']} anomalies so far")
        continue

    records_seen += 1
    atype = env.get("anomaly_type", {})
    category = next(iter(atype)) if isinstance(atype, dict) else str(atype)
    subtype = atype.get(category, "") if isinstance(atype, dict) else ""

    severity_counts[category] += 1
    doc_type_counts[env.get("document_type", "unknown")] += 1

    # Alert policy: flag all "Relational" + "Statistical" anomalies
    if category in ("Relational", "Statistical"):
        alerts_raised += 1
        if alerts_raised <= 5:
            print(
                f"  [ALERT] {category}/{subtype} "
                f"doc={str(env.get('document_id', '?'))[:28]} "
                f"co={env.get('company_code', '?')}"
            )

print()
print(f"Processed {records_seen} anomalies")
print(f"  Raised {alerts_raised} real-time alerts")
print()
print("Anomaly category breakdown:")
for cat, count in severity_counts.most_common():
    print(f"  {cat:15s}  {count:5d}")
print()
print("Affected document types:")
for dtype, count in doc_type_counts.most_common(5):
    print(f"  {dtype:15s}  {count:5d}")
