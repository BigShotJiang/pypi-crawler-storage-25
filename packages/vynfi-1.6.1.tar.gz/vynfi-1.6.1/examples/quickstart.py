"""VynFi Quickstart — generate synthetic financial data in 10 lines of code."""

import os

import vynfi

# Initialize client
client = vynfi.VynFi(api_key=os.environ["VYNFI_API_KEY"])

# Browse available sectors
sectors = client.catalog.list_sectors()
for s in sectors:
    print(f"  {s.slug}: {s.name} ({s.table_count} tables, quality: {s.quality_score})")

# Submit an async generation job (preferred — no 30s server cap).
# Use `client.jobs.generate_quick(...)` for synchronous <10k-row runs.
job = client.jobs.generate_config(
    config={
        "sector": "retail",
        "rows": 100,
        "companies": 1,
        "periods": 1,
        "exportFormat": "json",
    },
)
result = client.jobs.wait(job.id, timeout=180)
print(f"\nJob {result.id}: {result.status} ({result.credits_used or 0} credits)")

# List files in the archive without downloading (lightweight metadata call)
file_list = client.jobs.list_files(result.id)
print(f"\nArchive: {file_list.total_files} files, {file_list.total_size_bytes / 1024 / 1024:.1f} MB")
for f in file_list.files[:5]:
    print(f"  {f.path} ({f.size_bytes:,} bytes)")
print(f"  ... and {file_list.total_files - 5} more")

# Download a single file (no need to pull the full archive)
import json

data = client.jobs.download_file(result.id, "journal_entries.json")
entries = json.loads(data)
print(f"\n{len(entries)} journal entries generated")
print(f"First entry document type: {entries[0]['header']['document_type']}")
print(f"First entry has {len(entries[0]['lines'])} line items")

# Or download the full archive for bulk access
archive = client.jobs.download_archive(result.id)
print(f"\nFull archive: {archive}")
print(f"Categories: {archive.categories()}")

# Check credit balance
usage = client.usage.summary()
print(f"\nCredit balance: {usage.balance} (burn rate: {usage.burn_rate}/day)")
