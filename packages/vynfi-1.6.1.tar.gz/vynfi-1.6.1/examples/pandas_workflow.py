"""VynFi + pandas — DataFrame-native financial data analysis workflow."""

import json
import os

import pandas as pd

import vynfi
from vynfi.integrations.pandas import archive_to_dataframes, job_to_dataframe

client = vynfi.VynFi(api_key=os.environ["VYNFI_API_KEY"])

# ── Generate data ────────────────────────────────────────────────────────────

print("Generating retail financial data...")
job = client.jobs.generate_config(
    config={
        "sector": "retail",
        "rows": 500,
        "companies": 1,
        "periods": 1,
        "exportFormat": "json",
    },
)
result = client.jobs.wait(job.id, timeout=180)
print(f"Job {result.id}: {result.status}")

# ── Preview archive contents without downloading ─────────────────────────────

file_list = client.jobs.list_files(result.id)
print(f"\nArchive: {file_list.total_files} files, {file_list.total_size_bytes / 1024 / 1024:.1f} MB")

# Show per-file schemas — know what columns to expect before loading
for f in file_list.files[:3]:
    cols = ", ".join(s.name for s in f.schema_[:5])
    more = f" + {len(f.schema_) - 5} more" if len(f.schema_) > 5 else ""
    print(f"  {f.path}: [{cols}{more}]")

# ── Option A: Download individual files (when you only need a few) ───────────

print("\n=== Per-file download ===")
je_data = client.jobs.download_file(result.id, "journal_entries.json")
je_df = job_to_dataframe(je_data)
print(f"Journal entries: {len(je_df)} rows x {len(je_df.columns)} cols")

# ── Option B: Download full archive (when you need everything) ───────────────

print("\n=== Full archive download ===")
archive = client.jobs.download_archive(result.id)
print(archive)

# Convert all JSON files to DataFrames at once
frames = archive_to_dataframes(archive, exclude=["banking/*"])

print(f"\nLoaded {len(frames)} DataFrames:")
for path, df in sorted(frames.items()):
    print(f"  {path}: {df.shape[0]} rows x {df.shape[1]} cols")

# ── Work with journal entries ────────────────────────────────────────────────

if "journal_entries.json" in frames:
    je = frames["journal_entries.json"]
    print(f"\n=== Journal Entries: {len(je)} line items ===")

    # Convert amount columns to numeric
    for col in ["debit_amount", "credit_amount"]:
        if col in je.columns:
            je[col] = pd.to_numeric(je[col], errors="coerce").fillna(0)

    # Debit/Credit totals
    total_debit = je["debit_amount"].sum()
    total_credit = je["credit_amount"].sum()
    print(f"  Total debits:  ${total_debit:,.2f}")
    print(f"  Total credits: ${total_credit:,.2f}")
    print(f"  Balanced: {abs(total_debit - total_credit) < 0.01}")

    # Top accounts
    print("\n  Top 10 GL accounts by transaction count:")
    top = je["gl_account"].value_counts().head(10)
    for account, count in top.items():
        print(f"    {account}: {count} transactions")

    # Business process distribution
    if "business_process" in je.columns:
        print("\n  Transactions by business process:")
        for proc, count in je["business_process"].value_counts().items():
            print(f"    {proc}: {count}")

# ── Work with master data ────────────────────────────────────────────────────

for path in ["master_data/vendors.json", "master_data/customers.json"]:
    if path in frames:
        df = frames[path]
        print(f"\n=== {path}: {len(df)} records ===")
        print(f"  Columns: {', '.join(df.columns[:8])}")

# ── Usage analytics as DataFrame ─────────────────────────────────────────────

from vynfi.integrations.pandas import usage_to_dataframe

usage_df = usage_to_dataframe(client, days=30)
if not usage_df.empty:
    print(f"\n=== Usage (last 30 days) ===")
    print(usage_df.to_string())
