"""VynFi DataSynth 3.1 — sector-specific causal DAG presets.

DS 3.1 adds four new presets for `scenarios.causalModel.preset`:

- `manufacturing`  supply-chain (supplier reliability, BOM, scrap, warranty)
- `retail`         O2C-centric (foot traffic, seasonal demand, shrinkage, DSO)
- `financial_services`  correspondent banking (KYC/AML, LCR, NPL, ECL)
- `custom`         bring-your-own DAG via `nodes` + `edges`

This script submits one scenario per preset and diffs the resulting
business-process mix so you can see the DAG shift the data distribution.

Note: the current live API may still fall back to the default 17-node DAG
for unsupported presets — the script handles that gracefully.
"""

import os
from collections import Counter

import vynfi

client = vynfi.VynFi(api_key=os.environ["VYNFI_API_KEY"], timeout=180.0)

# ── 1. List available templates from the API ────────────────────────────────

templates = client.scenarios.templates()
print(f"Available templates ({len(templates)}):")
for t in templates:
    print(f"  {t.id}: {t.name} ({t.node_count} nodes)")

# ── 2. Submit one scenario per preset ───────────────────────────────────────

presets = [
    ("manufacturing",      "manufacturing"),
    ("retail",             "retail"),
    ("financial_services", "financial_services"),
]

results = {}
for label, preset in presets:
    print(f"\n--- Running preset: {preset} ---")
    try:
        scenario = client.scenarios.create(
            name=f"preset-{preset}",
            generation_config={
                "sector": label,
                "country": "US",
                "accountingFramework": "us_gaap",
                "rows": 500,
                "companies": 2,
                "periods": 1,
                "periodLength": "monthly",
                "processModels": ["o2c", "p2p"],
                "exportFormat": "json",
                "scenarios": {
                    "enabled": True,
                    "causalModel": {"preset": preset},
                    "constraints": {"preserveAccountingIdentity": True},
                },
            },
        )
        print(f"  Scenario: {scenario.id}")
        running = client.scenarios.run(scenario.id)
        job_ids = [
            j for j in (running.baseline_job_id, running.counterfactual_job_id) if j
        ]
        if job_ids:
            jobs_done = client.jobs.wait_for_many(job_ids, timeout=300)
            # Grab the baseline job's archive
            base_job = next((j for j in jobs_done if j.status == "completed"), None)
            if base_job:
                archive = client.jobs.download_archive(base_job.id)
                je = archive.json("journal_entries.json")
                bp = Counter(e.get("header", e).get("business_process") for e in je)
                results[preset] = bp
                archive.close()
                print(f"  Business-process mix: {dict(bp.most_common(5))}")
    except vynfi.VynFiError as e:
        print(f"  {type(e).__name__}: {e}")

# ── 3. Compare presets side-by-side ─────────────────────────────────────────

if results:
    print("\n=== Business-process share by preset ===")
    all_processes = sorted({p for c in results.values() for p in c})
    header = f"{'process':<12s}" + "".join(f"{p:>22s}" for p in results.keys())
    print(header)
    for proc in all_processes:
        row = f"{proc:<12s}"
        for preset in results:
            n = results[preset].get(proc, 0)
            tot = sum(results[preset].values())
            pct = 100 * n / tot if tot else 0
            row += f"{n:>6d} ({pct:5.1f}%){'':>5s}"
        print(row)

print("""

Use cases for each preset:
- manufacturing: stress-test BOM accuracy, scrap rate drift, warranty provisioning
- retail: seasonal demand shocks, stockout/shrinkage deltas, DSO impact
- financial_services: sanctions regime change, NPL ratio spikes, ECL provision moves

Custom DAGs:
    "scenarios": {
        "causalModel": {
            "preset": "custom",
            "nodes": [{"id": "climate_shock", "kind": "macro"}],
            "edges": [{"source": "climate_shock", "target": "inventory_writedown"}],
        }
    }
""")
