"""VynFi DataSynth 3.1.1 — audit opinions + key audit matters.

DS 3.1.1 always materializes `audit/audit_opinions.json` and
`audit/key_audit_matters.json` (empty arrays when the audit phase is
disabled), so SDK manifest-driven clients always find them. This example
generates a job with the audit phase enabled and summarises the ISA 700
opinions and ISA 701 key audit matters.
"""

import json
import os

import vynfi

client = vynfi.VynFi(api_key=os.environ["VYNFI_API_KEY"], timeout=180.0)

config = {
    "sector": "retail",
    "country": "US",
    "accountingFramework": "us_gaap",
    "rows": 500,
    "companies": 3,
    "periods": 2,
    "periodLength": "monthly",
    "processModels": ["o2c", "p2p", "h2r", "audit"],
    "exportFormat": "json",
}

print("Submitting 3.1.1 config with audit phase enabled...")
job = client.jobs.generate_config(config=config)
done = client.jobs.wait(job.id, timeout=300)
print(f"Job: {done.id}  status: {done.status}")
if done.status != "completed":
    raise SystemExit(done.error_detail)

archive = client.jobs.download_archive(done.id)
job_id = done.id
print(f"Loading audit artifacts from job {job_id}")

opinions = archive.audit_opinions()
kams = archive.key_audit_matters()

print(f"\n{len(opinions)} audit opinions (ISA 700)")
print(f"{len(kams)} key audit matters (ISA 701)")

if opinions:
    print("\n=== Audit opinions ===")
    for op in opinions[:5]:
        print(
            f"- Company {op.get('company_code'):>6s}  FY{op.get('fiscal_year')}  "
            f"type={op.get('opinion_type')!r}  going_concern={op.get('going_concern')!r}"
        )
        if op.get("basis_for_opinion"):
            print(f"    basis: {op['basis_for_opinion'][:100]}")

if kams:
    print("\n=== Key Audit Matters ===")
    for k in kams[:5]:
        print(f"- {k.get('title', '(no title)')} ({k.get('risk_level', 'n/a')})")
        desc = k.get("description", "")[:200]
        if desc:
            print(f"    {desc}")
        accts = k.get("related_accounts", [])
        if accts:
            print(f"    related accounts: {', '.join(accts[:5])}")

# Export to CSVs for an audit workpaper file
if opinions or kams:
    from pathlib import Path

    out = Path("audit_workpapers")
    out.mkdir(exist_ok=True)
    if opinions:
        (out / "audit_opinions.json").write_text(json.dumps(opinions, indent=2, default=str))
    if kams:
        (out / "key_audit_matters.json").write_text(json.dumps(kams, indent=2, default=str))
    print(f"\nExported to {out}/")

archive.close()
