"""VynFi Config Management — validate, estimate cost, and compose generation configs."""

import json
import os

import vynfi

client = vynfi.VynFi(api_key=os.environ["VYNFI_API_KEY"])

# ── 1. Browse available templates ────────────────────────────────────────────

print("=== Available Templates ===")
templates = client.catalog.list_templates()
for t in templates:
    print(f"  {t.slug}")
    print(f"    {t.name} (sector={t.sector}, country={t.country}, framework={t.framework})")
    if t.description:
        print(f"    {t.description[:90]}...")
    print()

# ── 2. Validate a config before submitting ───────────────────────────────────

config = {
    "sector": "retail",
    "country": "US",
    "accountingFramework": "us_gaap",
    "rows": 10000,
    "companies": 5,
    "periods": 12,
    "periodLength": "monthly",
    "processModels": ["o2c", "p2p"],
    "exportFormat": "json",
    "fraudPacks": [],
    "fraudRate": 0.0,
}

print("=== Config Validation ===")
result = client.configs.validate(config=config)
print(f"  Valid: {result.valid}")
if result.errors:
    for e in result.errors:
        print(f"  ERROR: [{e.field}] {e.message}")
if result.warnings:
    for w in result.warnings:
        print(f"  WARNING: [{w.field}] {w.message}")
        if w.fix:
            print(f"    Suggested fix: {w.fix.action} {w.fix.field} = {w.fix.value}")
print()

# ── 3. Estimate credit cost and output size ──────────────────────────────────

print("=== Cost & Output Estimation ===")
estimate = client.configs.estimate_cost(config=config)
print(f"  Base credits: {estimate.base_credits}")
print(f"  Total credits: {estimate.total_credits}")
if estimate.multipliers:
    print("  Multipliers:")
    for m in estimate.multipliers:
        print(f"    {m.label}: {m.factor}x (source: {m.source})")
if estimate.balance:
    print(f"  Current balance: {estimate.balance.current}")
    print(f"  After job: {estimate.balance.after_job}")
    print(f"  Status: {estimate.balance.status}")
if estimate.output:
    print(f"  Expected output:")
    print(f"    Files: ~{estimate.output.estimated_files}")
    print(f"    Size:  ~{estimate.output.estimated_size_bytes / 1024 / 1024:.0f} MB")
    if estimate.output.note:
        print(f"    Note:  {estimate.output.note}")
print()

# ── 4. Save a config for reuse ──────────────────────────────────────────────

print("=== Save Config ===")
saved = client.configs.create(
    name="Retail O2C+P2P Monthly",
    config=config,
    description="Standard retail dataset with Order-to-Cash and Procure-to-Pay processes",
    tags=["retail", "audit", "monthly"],
)
print(f"  Saved config: {saved.id}")
print(f"  Name: {saved.name}")
print()

# List saved configs
print("=== Saved Configs ===")
configs = client.configs.list()
for c in configs:
    print(f"  {c.id}: {c.name}")
    if c.tags:
        print(f"    Tags: {', '.join(c.tags)}")
print()

# ── 5. Compose configs from layers (requires Team tier) ──────────────────────

print("=== Config Composition ===")
try:
    composed = client.configs.compose(
        layers=[
            {"sector": "retail", "country": "US", "accountingFramework": "us_gaap"},
            {"rows": 25000, "companies": 10, "periods": 12, "periodLength": "monthly"},
            {"processModels": ["o2c", "p2p", "h2r", "tax"]},
            {"fraudPacks": ["revenue_fraud"], "fraudRate": 0.03},
        ]
    )
    print(f"  Composed config:")
    print(f"  {json.dumps(composed.config, indent=2)}")
except vynfi.ForbiddenError:
    print("  Compose requires Team tier or above")
print()

# ── 6. Clean up ─────────────────────────────────────────────────────────────

print("=== Cleanup ===")
deleted = client.configs.delete(saved.id)
print(f"  Deleted: {deleted.deleted}")
