"""VynFi → ML training pipeline for fraud detection.

Backs the blog post "Building Financial AI Models? Here's Your Training Data Pipeline".

Full pipeline:
  1. Generate labeled fraud data (fraudPacks + fraudRate)
  2. Load into pandas with native numeric mode (DS 3.0+)
  3. Feature-engineer journal entries
  4. Train a RandomForest classifier
  5. Evaluate with stratified CV + precision/recall/F1
  6. Persist the model + feature columns

Requires: scikit-learn, joblib, pandas.
"""

import os
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score
from sklearn.model_selection import StratifiedKFold, cross_val_predict, train_test_split

import vynfi

client = vynfi.VynFi(api_key=os.environ["VYNFI_API_KEY"], timeout=180.0)

# ── 1. Generate labeled fraud data ───────────────────────────────────────────

print("=== 1. Generate labeled training data ===")
config = {
    "sector": "retail",
    "country": "US",
    "accountingFramework": "us_gaap",
    "rows": 1000,
    "companies": 3,
    "periods": 3,
    "periodLength": "monthly",
    "processModels": ["o2c", "p2p"],
    "exportFormat": "json",
    "fraudPacks": ["revenue_fraud"],
    "fraudRate": 0.05,
    "output": {"numericMode": "native"},  # DS 3.0 — skip pd.to_numeric boilerplate
}

job = client.jobs.generate_config(config=config)
done = client.jobs.wait(job.id, timeout=300)
print(f"  Job: {done.id}, status: {done.status}")
if done.status != "completed":
    print(f"  Error: {done.error_detail}")
    raise SystemExit(1)

archive = client.jobs.download_archive(done.id)
print(f"  Archive: {archive}")

# ── 2. Load & flatten journal entries ────────────────────────────────────────

print("\n=== 2. Load journal entries ===")
entries = archive.json("journal_entries.json")
rows = []
for e in entries:
    h = e.get("header", e)
    for line in e.get("lines", [e]) if "lines" in e else [e]:
        rows.append({**h, **line})
df = pd.DataFrame(rows)
print(f"  {len(df):,} line items")

# Coerce amounts in case string mode (backward compat)
for col in ("debit_amount", "credit_amount"):
    df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)
df["posting_date"] = pd.to_datetime(df["posting_date"], errors="coerce")

print(f"  Fraud prevalence: {df['is_fraud'].mean():.2%}")

# ── 3. Feature engineering ──────────────────────────────────────────────────

print("\n=== 3. Feature engineering ===")
df["amount"] = np.maximum(df["debit_amount"], df["credit_amount"])
df["log_amount"] = np.log1p(df["amount"])
df["is_round_1000"] = (df["amount"] % 1000 == 0) & (df["amount"] > 0)
df["is_round_100"] = (df["amount"] % 100 == 0) & (df["amount"] > 0)
df["is_weekend"] = df["posting_date"].dt.dayofweek >= 5
df["is_month_end"] = df["posting_date"].dt.day >= 28

# Categorical encodings (small cardinality)
for col in ("business_process", "document_type"):
    df[f"{col}_code"] = df[col].astype("category").cat.codes

# Account frequency (rare accounts may be riskier)
df["account_freq"] = df.groupby("gl_account")["gl_account"].transform("count")

# Manual-entry flag is already boolean
df["is_manual_int"] = df["is_manual"].astype(int)
df["is_post_close_int"] = df.get("is_post_close", False).astype(int)

# DS 3.1+: behavioral fraud patterns add measurable signal to these features.
# Previously they were ~0 % feature importance; 3.1 injects weekend/round/
# off-hours/post-close biases into fraud entries at 25-40 % rates.

# Stratified view: DS 3.1+ flags scheme-propagated fraud vs direct injection.
# Useful for training cross-document detectors separately from noise-robust ones.
df["is_fraud_propagated"] = df.get("is_fraud_propagated", False).astype(bool)
n_scheme = df.query("is_fraud and is_fraud_propagated").shape[0]
n_direct = df.query("is_fraud and not is_fraud_propagated").shape[0]
print(f"  Scheme-propagated fraud: {n_scheme}, directly-injected: {n_direct}")

feature_cols = [
    "log_amount", "is_round_1000", "is_round_100",
    "is_weekend", "is_month_end",
    "business_process_code", "document_type_code",
    "account_freq", "is_manual_int", "is_post_close_int",
]
X = df[feature_cols].astype(float).fillna(0).values
y = df["is_fraud"].astype(int).values
print(f"  Features: {len(feature_cols)}, samples: {len(X):,}")

# ── 4. Train / evaluate ─────────────────────────────────────────────────────

print("\n=== 4. Train RandomForest ===")
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, stratify=y, random_state=42
)

clf = RandomForestClassifier(
    n_estimators=200,
    max_depth=12,
    class_weight="balanced",
    random_state=42,
    n_jobs=-1,
)
clf.fit(X_train, y_train)

y_pred = clf.predict(X_test)
y_proba = clf.predict_proba(X_test)[:, 1]

print(f"\n  Confusion matrix (test):")
cm = confusion_matrix(y_test, y_pred)
print(f"    TN={cm[0,0]}  FP={cm[0,1]}")
print(f"    FN={cm[1,0]}  TP={cm[1,1]}")
print(f"\n  Classification report:")
print("    " + classification_report(y_test, y_pred, target_names=["legit", "fraud"]).replace("\n", "\n    "))
print(f"  ROC-AUC: {roc_auc_score(y_test, y_proba):.4f}")

# ── 5. Stratified 5-fold CV for a stable estimate ───────────────────────────

print("\n=== 5. 5-fold CV ===")
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
cv_proba = cross_val_predict(clf, X, y, cv=cv, method="predict_proba", n_jobs=-1)[:, 1]
print(f"  CV ROC-AUC: {roc_auc_score(y, cv_proba):.4f}")

# ── 6. Feature importance ───────────────────────────────────────────────────

print("\n=== 6. Feature importance ===")
importances = sorted(zip(feature_cols, clf.feature_importances_), key=lambda x: -x[1])
for name, imp in importances[:10]:
    print(f"  {name:28s}  {imp:.4f}  {'█' * int(imp * 60)}")

# ── 7. Persist the model ────────────────────────────────────────────────────

print("\n=== 7. Save model ===")
out = Path("fraud_model")
out.mkdir(exist_ok=True)
joblib.dump({"model": clf, "feature_cols": feature_cols}, out / "model.joblib")
print(f"  Saved to {out / 'model.joblib'}")

# How to reload and score
print("""
To reload and score new data:

  bundle = joblib.load("fraud_model/model.joblib")
  clf, cols = bundle["model"], bundle["feature_cols"]
  proba = clf.predict_proba(new_df[cols].fillna(0))[:, 1]
  flagged = new_df[proba > 0.5]
""")

archive.close()
