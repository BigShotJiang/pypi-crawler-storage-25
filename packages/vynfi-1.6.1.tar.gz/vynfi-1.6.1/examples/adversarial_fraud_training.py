"""VynFi adversarial — probe an ONNX fraud detector for decision-boundary weaknesses.

Backs the blog post "Training Fraud Models with Adversarial Synthetic Data".

End-to-end workflow:
  1. Generate labeled fraud data
  2. Train a simple fraud classifier
  3. Export it to ONNX
  4. Upload to VynFi and run adversarial probes
  5. Analyze low-margin samples (potential vulnerabilities)
  6. Use the feedback to re-train a more robust model

Requires: scikit-learn, skl2onnx, onnxruntime, joblib.
Tier: Enterprise (for the adversarial endpoint).
"""

import os
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.model_selection import train_test_split

import vynfi

client = vynfi.VynFi(api_key=os.environ["VYNFI_API_KEY"], timeout=180.0)

# ── 1. Generate labeled data ────────────────────────────────────────────────

print("=== 1. Generate labeled fraud data ===")
job = client.jobs.generate_config(config={
    "sector": "financial_services",
    "country": "US",
    "accountingFramework": "us_gaap",
    "rows": 1000, "companies": 3, "periods": 3, "periodLength": "monthly",
    "processModels": ["o2c", "p2p", "banking"],
    "exportFormat": "json",
    "fraudPacks": ["revenue_fraud"], "fraudRate": 0.05,
    "output": {"numericMode": "native"},
})
done = client.jobs.wait(job.id, timeout=300)
if done.status != "completed":
    print(f"Error: {done.error_detail}")
    raise SystemExit(1)

archive = client.jobs.download_archive(done.id)
print(f"  Archive: {archive}")

# ── 2. Train a small fraud classifier ───────────────────────────────────────

print("\n=== 2. Train a small gradient-boosting classifier ===")
entries = archive.json("journal_entries.json")
rows = []
for e in entries:
    h = e.get("header", e)
    for line in e.get("lines", [e]) if "lines" in e else [e]:
        rows.append({**h, **line})
df = pd.DataFrame(rows)
for col in ("debit_amount", "credit_amount"):
    df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)

df["amount"] = np.maximum(df["debit_amount"], df["credit_amount"])
df["log_amount"] = np.log1p(df["amount"])
df["is_round_1000"] = ((df["amount"] % 1000 == 0) & (df["amount"] > 0)).astype(float)
df["is_manual_int"] = df["is_manual"].astype(float)
df["is_post_close_int"] = df.get("is_post_close", False).astype(float)

features = ["log_amount", "is_round_1000", "is_manual_int", "is_post_close_int"]
X = df[features].fillna(0).astype(np.float32).values
y = df["is_fraud"].astype(int).values
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, stratify=y, random_state=42
)

clf = GradientBoostingClassifier(n_estimators=100, max_depth=4, random_state=42)
clf.fit(X_train, y_train)
print(f"  Trained. Test accuracy: {clf.score(X_test, y_test):.3f}")
print(f"  Features: {features}")

# ── 3. Export to ONNX ───────────────────────────────────────────────────────

print("\n=== 3. Export to ONNX ===")
try:
    from skl2onnx import convert_sklearn
    from skl2onnx.common.data_types import FloatTensorType
except ImportError:
    print("  Install skl2onnx to continue: pip install skl2onnx onnxruntime")
    raise SystemExit(0)

initial_type = [("features", FloatTensorType([None, len(features)]))]
onx = convert_sklearn(clf, initial_types=initial_type, target_opset=15)
onnx_path = Path(tempfile.gettempdir()) / "fraud_classifier.onnx"
onnx_path.write_bytes(onx.SerializeToString())
print(f"  Saved: {onnx_path} ({onnx_path.stat().st_size:,} bytes)")

# ── 4. Submit adversarial probe ─────────────────────────────────────────────

print("\n=== 4. Submit adversarial probe (Enterprise tier) ===")
try:
    probe = client.adversarial.probe(
        onnx_path,
        n_probes=1000,
        perturbation_budget=0.05,
        threshold=0.5,
        n_features=len(features),
    )
    print(f"  Probe: {probe.id}, status: {probe.status}")
    print(f"  Message: {probe.message}")
except vynfi.ForbiddenError:
    print("  403 — adversarial probing requires Enterprise tier.")
    print("  The rest of the pipeline below is the pattern for when it's enabled.")
    raise SystemExit(0)
except vynfi.VynFiError as e:
    print(f"  Upload failed: {e}")
    raise SystemExit(1)

# ── 5. Poll for results ─────────────────────────────────────────────────────

import time
print("\n=== 5. Wait for probe results ===")
deadline = time.monotonic() + 600
while time.monotonic() < deadline:
    try:
        results = client.adversarial.results(probe.id)
        if results.n_probes > 0:
            break
    except vynfi.NotFoundError:
        pass
    time.sleep(5)
else:
    print("  Timed out waiting for results")
    raise SystemExit(1)

print(f"  n_probes:       {results.n_probes}")
print(f"  mean_score:     {results.mean_score:.4f}")
print(f"  std_score:      {results.std_score:.4f}")
print(f"  positive_rate:  {results.positive_rate:.2%}")
print(f"  mean_margin:    {results.mean_margin:.4f}")
print(f"  boundary samples: {len(results.boundary_samples)}")

# ── 6. Inspect low-margin samples ───────────────────────────────────────────

if results.boundary_samples:
    print("\n=== 6. Top 5 low-margin samples (model uncertainty) ===")
    ordered = sorted(results.boundary_samples, key=lambda s: s.margin)
    for s in ordered[:5]:
        feat_str = ", ".join(f"{f:.3f}" for f in s.features[:6])
        print(f"  score={s.score:.3f}  margin={s.margin:+.4f}  feat=[{feat_str}...]")

print("""

Next steps:
- Fold these boundary samples back into training (adversarial augmentation).
- Iterate probe → retrain → probe until margins stabilize.
- Ship the ONNX bundle to production once mean_margin > 0.15.
""")

archive.close()
