"""VynFi AI Tune — LLM-powered config suggestion (DS 3.0+, Scale+).

After generating a dataset, ask the co-pilot to propose a better config based
on the actual quality scores. Perfect for:
- Automated QA pipelines that regenerate on low-score runs
- A/B testing different config strategies
- Teaching juniors what levers matter for specific quality dimensions
"""

import json
import os

import vynfi

client = vynfi.VynFi(api_key=os.environ["VYNFI_API_KEY"])

# ── 1. Find a recent completed job ──────────────────────────────────────────

jobs = client.jobs.list(status="completed", limit=5)
if not jobs.data:
    print("No completed jobs to tune. Generate data first.")
    raise SystemExit(1)

job = jobs.data[0]
print(f"Tuning based on job: {job.id}")
print()

# ── 2. Ask the co-pilot to suggest improvements ──────────────────────────────

result = client.jobs.tune(
    job.id,
    target_scores={"overall": 0.95, "benford": 0.95},
)

print("=== Quality summary ===")
if result.quality_summary:
    qs = result.quality_summary
    print(f"  Overall:      {qs.overall}")
    print(f"  Benford:      {qs.benford}")
    print(f"  Distribution: {qs.distribution}")
    print(f"  Rows:         {qs.rows_analyzed:,}")

print()
print("=== Co-pilot explanation ===")
print(f"  {result.explanation}")

print()
print("=== Config diff ===")

orig = result.original_config or {}
new = result.suggested_config or {}

all_keys = set(orig.keys()) | set(new.keys())
for key in sorted(all_keys):
    old_val = orig.get(key)
    new_val = new.get(key)
    if old_val != new_val:
        print(f"  {key}:")
        print(f"    -  {json.dumps(old_val, default=str)[:80]}")
        print(f"    +  {json.dumps(new_val, default=str)[:80]}")

# ── 3. Optionally, run the suggested config ─────────────────────────────────

print()
print("To run the suggested config:")
print("  new_job = client.jobs.generate_config(config=result.suggested_config)")
