"""VynFi scenario packs — built-in counterfactual simulations (DS 3.0+).

DataSynth 3.0 ships 11 pre-built scenario packs across four categories:
- fraud: vendor_collusion_ring, management_override, ghost_employee,
  procurement_kickback, channel_stuffing
- control_failure: sox_material_weakness, it_control_breakdown
- macro: recession_2008_replay, supply_chain_disruption_q3, interest_rate_shock_300bp
- operational: erp_migration_cutover

Each pack is a YAML scenario definition that runs as a paired baseline +
counterfactual generation, with computed diff for record-level and
aggregate comparison.

Tier gates: 1 pack (Free), 3 packs (Developer), unlimited (Team+).
Custom interventions require Scale+.
"""

import os
from collections import defaultdict

import vynfi

client = vynfi.VynFi(api_key=os.environ["VYNFI_API_KEY"])

# ── 1. List available packs ──────────────────────────────────────────────────

print("=== Built-in scenario packs ===")
packs = client.scenarios.packs()

by_category: dict[str, list[vynfi.ScenarioPack]] = defaultdict(list)
for p in packs:
    by_category[p.category].append(p)

for category, pack_list in sorted(by_category.items()):
    print(f"\n[{category}] ({len(pack_list)})")
    for p in pack_list:
        print(f"  {p.name:30s}  {p.description[:70]}")

# ── 2. Run a single scenario pack ────────────────────────────────────────────

print("\n=== Running 'management_override' scenario ===")
scenario = client.scenarios.create(
    name="Management override Q4",
    generation_config={
        "sector": "retail",
        "country": "US",
        "accountingFramework": "us_gaap",
        "rows": 1000,
        "companies": 3,
        "periods": 3,
        "periodLength": "monthly",
        "processModels": ["o2c", "p2p"],
        "exportFormat": "json",
        "scenarios": {
            "enabled": True,
            "packs": ["management_override"],
            "constraints": {
                "preserveAccountingIdentity": True,
                "preserveDocumentChains": True,
            },
            "diffFormats": ["summary", "aggregate"],
        },
    },
)
print(f"Scenario created: {scenario.id}")

running = client.scenarios.run(scenario.id)
print(f"  Status: {running.status}")
print(f"  Baseline job: {running.baseline_job_id}")
print(f"  Counterfactual job: {running.counterfactual_job_id}")

# ── 3. Wait for both jobs, then fetch diff ──────────────────────────────────
#
# client.scenarios.run() spawns two jobs concurrently. Wait for both, then
# pull the computed diff.

for jid in (running.baseline_job_id, running.counterfactual_job_id):
    if jid:
        print(f"  Waiting for {jid[:8]}...")
        client.jobs.wait(jid, timeout=600)

diffed = client.scenarios.diff(scenario.id)
if diffed.diff:
    print("\n=== Scenario diff ===")
    if isinstance(diffed.diff, dict):
        for k, v in diffed.diff.items():
            print(f"  {k}: {v}")
