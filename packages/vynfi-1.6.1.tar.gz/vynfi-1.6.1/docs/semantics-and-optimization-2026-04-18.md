# Semantic Analysis & Optimization — DataSynth 3.1 Live

**Date:** 2026-04-18 (post SDK v1.5.0, post DS 3.1 deploy)
**Based on:** A representative retail fraud job, `fraudRate=0.05`, 500 rows,
3 companies, 2 periods, DS 3.1.0 archive.

---

## TL;DR

DS + VynFi's advantage is the **cross-layer coherence with ground-truth
labels at scale**. No real bank can hand you 10k labeled OCEL events across
620 KYC profiles, 10k AML relationships, and 4k balanced journal entries
— DS does. What's still rough around the edges is **fraud-signal calibration**
(biases declared but not firing), **typology coverage** (API self-reports
0.000 vs 0.800 target), and **scenario template depth** (one DAG for all
sectors). Fixes here would make DS the clear default for audit/fraud ML
training and simulation work.

---

## What DS 3.1 + VynFi genuinely offers (the advantage)

### 1. Ground-truth labels at scale that nobody else can share

| Artifact | Sample size in one small job |
|---|---|
| Journal entry line items | 42,447 with `is_fraud` / `fraud_type` labels |
| OCEL events | 19,680 with `case_id`, `activity_id`, `resource_id` |
| OCEL objects | 7,277 with lifecycle, created_at / completed_at |
| Banking customers | 620 with risk_tier, is_pep, is_mule, kyc_profile |
| AML relationships | **10,525** (3.1 density 0.053 is 38× denser than 3.0) |
| Banking transactions | 697k with per-txn `is_suspicious` + `suspicion_reason` |
| Document flows | PO/GR/VI/Payment/SO/Del/CI chains with references |

A regulated bank can't share any of this. DS delivers it with config knobs.

### 2. Statistical calibration is consistently high

| Metric | Sample job | Comment |
|---|---|---|
| Benford MAD | **0.0026** | "Close" conformity, passes Benford tests |
| Amount skewness | 31.7 | Matches real financial data (long right tail) |
| Amount kurtosis | 4,843 | Consistent with real heavy-tailed distributions |
| Balance validation | 3,603 / 3,603 = **100%** | Every document balances to the cent |
| Round-number ratio | 4.6 % | Low — DS isn't generating "fake-looking" round amounts |

### 3. Cross-table coherence

Document references actually link up. AML labels match banking_customers IDs.
OCEL object_refs point at real document_ids. We verified this by walking
document chains, joining labels back to customers, and tracing OCEL events
to journal entries. All clean.

### 4. The data fits existing ecosystem tools

Verified live in this repo's examples:
- **pm4py** runs Inductive Miner on the event log with full fitness computation
- **networkx** + `louvain_communities` runs on the AML graph
- **pandas** / **scikit-learn** classifies fraud with ROC-AUC ~0.90
- **SAP BKPF/BSEG mapping** produces balanced trial balance (all $211M debits = $211M credits)
- **Celonis IBC** CSV format exports cleanly

### 5. Managed-blob pipeline is solid

- 90+ file archives served via manifest with presigned URLs
- Per-file fetch works
- Streaming (NDJSON) works for TB-scale jobs
- Scales past HTTP timeouts

---

## Semantic issues still visible (with measurements)

### 1. AML typology coverage is 0.0

The banking evaluation that DS writes to `analytics/banking_evaluation.json`
reports:

```
"issues": [
  "Core field rate 0.806 < 0.950",
  "Typology coverage 0.000 < 0.800"
]
```

This is DS self-flagging. `banking.typologies.networkTypologyRate` is set
(default 0.05), but `TypologyInjector` either isn't running or isn't
covering the typology catalog. The `NetworkGenerator` change in 3.1 made
the AML graph denser but the typology layer didn't follow.

### 2. Relationship topology is 97% low-signal

| Relationship type | Count | Share |
|---|---|---|
| `TransactionCounterparty` | 10,238 | **97.3%** |
| `BeneficialOwnership`     |    245 |   2.3% |
| `MuleLink`                |     42 |   0.4% |
| `ShellLink`               |      0 |   0.0% |

For AML training, only `MuleLink` + `ShellLink` + `BeneficialOwnership` are
meaningful — they're <3% of edges. `TransactionCounterparty` is just every
customer-to-counterparty link. A link-prediction model has almost no
positive class to learn from.

Shell link count of 0 despite `is_shell_link=True` being a declared field
suggests the shell-pyramid injector isn't wired.

### 3. Behavioral fraud biases partially fire

From a fraud classifier on real 3.1 output:

| Feature | Fraud rate | Baseline rate | Lift | Expected |
|---|---|---|---|---|
| `is_weekend`        | 0.77 % | 0.42 % | **1.83×** | 3× (30% bias) |
| `is_round_1000`     | **0.00 %** | 0.14 % | **0.0×** | >3× (40% bias) |
| `is_off_hours`      | **0.00 %** | 0.00 % | n/a   | >5× (35% bias) |
| `is_post_close_int` | 0.77 % | 0.00 % | ∞     | 3× (25% bias) |

Only `is_post_close` shows correct behavior. `is_round_1000` is *inverted*
(fraud has fewer round-dollar amounts than baseline — the opposite of the
declared 40 % bias). `is_off_hours` is zero on both — the `created_at`
shift isn't landing. `is_weekend` shows 1.83× but should be ~3× given
30 % injection.

This matters because these are canonical forensic signals; auditor tools
trained on DS data will fail to generalize if the signal isn't there.

### 4. Process variants still not populating

- `analytics/process_variant_summary.json` not in archive
- `/v1/jobs/{id}/analytics` returns null for `process_variant_summary`
- `DataSynthQualityReport` shows `variants: 0, entropy: None`

The 3.1 change-log says these should now exist. Possibly still a deploy-
lag issue; the orchestrator phase (18f) may not be emitting the summary
file.

### 5. `is_fraud_propagated` is declared but always False

- Field exists on `JournalEntryHeader` in the output
- **0 / 388 fraud entries** have it set to True
- Config `fraud.documentFraudRate: 0.05` + `propagateToLines: True` in request
- PO/VI/Payment do have some `is_fraud=True` (1-4/50), so doc-level fraud is
  running. The propagation back to derived JEs just isn't.

### 6. Still only one scenario DAG template in the registry

`client.scenarios.templates()` returns `tpl_financial_process_17` only.
The 3.1 change-log introduces `manufacturing` / `retail` / `financial_services`
presets but they're config-level, not template-level. `scenarios.create`
still accepts `template_id` as "required" (we fall back to the one default
in the SDK). If you want distinct DAG catalogs per sector, they need to be
registered as templates.

### 7. `fraudRate` semantic spec is clearer but still needs docs

Setting `fraudRate=0.05` on retail+revenue_fraud produces observed JE
is_fraud rates of 0.6%–2.9% depending on the job. 3.1 added
`documentFraudRate` as the doc-scoped knob, and the JE rate is something
like "documents × propagation × line-level rate." That's the right
architecture but the SDK caller has no way to ask for "2% of lines
labeled fraud" without trial and error.

### 8. Streaming / download quirks

- `exportLayout: "flat"` still hangs generation (no `error_detail`). 3.1
  release notes don't mention this.
- Presigned-URL fetches via manifest are serial-per-file; reading 20
  analytics + label files takes ~3 s of sequential HTTP.

---

## SDK-side optimizations we could ship

1. **Parallel `archive.json()` / `dataframes()` fetches** for `managed_blob`
   — thread-pool 8 concurrent presigned-URL pulls. On the GNN notebook
   this would cut read time from ~3 s to ~0.5 s.

2. **`vynfi.features.FraudFeatures`** — one-call featurizer that emits the
   13 columns every fraud example re-implements (log_amount, is_round_*,
   is_weekend, is_off_hours, account_freq, etc). Reduces each notebook by
   ~30 lines.

3. **`JobArchive.to_parquet_pack(dir)`** — dump the whole archive as
   Parquet files with the coercions already applied. For ML teams, this
   is the natural consumption format.

4. **`DataSynthQualityReport.from_many([ids])`** — cross-job comparison,
   e.g., baseline vs counterfactual vs ablation.

5. **`client.scenarios.run_and_diff(scenario_id)`** — spawn, wait for both
   jobs via `wait_for_many`, return the diff in one call.

6. **Auto-retry on 503 during deploy windows** — we saw these during every
   DS rollout. The client should absorb them with exponential backoff
   (currently only retries on 429).

These are all local SDK wins with no server dependency.

---

## Asks for the DataSynth core team

Ordered by impact / ease:

| # | Ask | Signal | Effort |
|---|---|---|---|
| 1 | Fix `round_dollar_bias` inversion — currently fraud has lower round-dollar rate than baseline | Critical for auditor-facing ML | small |
| 2 | Wire `off_hours_bias` — `created_at` time-of-day shift isn't firing (both 0 %) | Core forensic signal | small |
| 3 | Fix `is_fraud_propagated` back-annotation — 0 / 388 on a job with doc-level fraud active | Enables ML stratification | small |
| 4 | Write `process_variant_summary.json` to archive (3.1 claims to, current deploy doesn't) | Process mining quality gate | small |
| 5 | Write `audit/audit_opinions.json` + `key_audit_matters.json` to archive (declared in 3.1, missing in deploy) | Audit tool training | small |
| 6 | Fire `TypologyInjector` — banking_evaluation reports "typology coverage 0.000 < 0.800"; DS knows it's failing | AML training quality | medium |
| 7 | Balance relationship edge types — 97.3 % are TransactionCounterparty; boost the signal-bearing types | GNN training quality | medium |
| 8 | Register sector-specific DAGs as actual templates in `/v1/scenarios/templates` | Scenario discoverability | medium |
| 9 | Fix / remove `exportLayout: "flat"` — hangs silently with no error | UX gotcha | small |
| 10 | Document `fraudRate` vs `documentFraudRate` math — users can't hit a target line-level fraud prevalence | Dev ergonomics | trivial |

### One specific smoke test worth adding to DS CI

After any change to the fraud biases, assert on a trained RandomForest:

```python
# All behavioral biases should show ≥2× lift on fraud vs baseline
assert fraud[col].mean() / baseline[col].mean() > 2.0 for col in
    ["is_weekend", "is_round_1000", "is_off_hours", "is_post_close"]
```

That would have caught #1 and #2 before release.

---

## Net assessment

DS + VynFi is already the most capable synthetic-finance pipeline I've
seen up close. The cross-table coherence, Benford-level statistical
calibration, and TB-scale pipeline are differentiators real competitors
(Mostly AI, Synthesized, Gretel) don't match in the ERP/audit domain.

The items above are **polish on a product that works**, not foundational
gaps. The SDK (v1.5.0) is ready to expose every DS 3.1 feature the moment
the deploy catches up with the code.

If I were prioritizing the DS team's next two weeks: **fix the behavioral
bias firing (items 1-2-3) and publish the missing analytics/audit files
(items 4-5).** Those five are all small code changes and they collectively
close the "declared but not live" gap in one release.
