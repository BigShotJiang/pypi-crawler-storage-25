# DataSynth 3.1.1 Verification — 2026-04-18

Re-run of the 10 findings from
[`semantics-and-optimization-2026-04-18.md`](./semantics-and-optimization-2026-04-18.md)
against DS 3.1.1 + VynFi API 3.1.1 adoption.

**Summary: 7/10 fixed with dramatic improvements, 3/10 partial or pending.**

---

## ✅ Fixed (the big wins)

### 1. `round_dollar_bias` inversion

| Metric | 3.1.0 | **3.1.1** |
|---|---|---|
| Fraud `is_round_1000` rate | 0.00 % | **19.25 %** |
| Baseline `is_round_1000` rate | 0.14 % | 0.11 % |
| Lift | 0× (inverted) | **170×** |

Multi-line JE entries now supported; the nearest-round-target rescaling preserves balance.

### 2. `is_weekend` bias

| Metric | 3.1.0 | **3.1.1** |
|---|---|---|
| Fraud `is_weekend` rate | 0.77 % | **40.37 %** |
| Lift | 1.83× | **32×** |

Weekend posting bias now fires on every `is_fraud` path (was only on `inject_anomaly`).

### 3. `is_post_close` bias

| Metric | 3.1.0 | **3.1.1** |
|---|---|---|
| Fraud rate | 0.77 % | **31.06 %** |
| Lift | ∞ | **~3,106×** |

### 4. `is_fraud_propagated` back-annotation

| Metric | 3.1.0 | **3.1.1** |
|---|---|---|
| Populated on fraud entries | 0 / 388 (**0 %**) | 12 / 33 (**36 %**) |

`DocumentRef` now set on every document-flow JE header so
`propagate_fraud_from_documents` can match. Distinguishes scheme-level
from slip-level fraud for ML stratification.

### 5. `process_variant_summary.json`

| Metric | 3.1.0 | **3.1.1** |
|---|---|---|
| File in archive | Missing | ✅ Present |
| Variant count | — | **162** |
| Happy-path concentration | — | **55.2 %** |
| Variant entropy | — | **2.42** |

Realistic process imperfections instead of the prior "too clean" single
variant.

### 6. `audit/audit_opinions.json` + `key_audit_matters.json`

| File | 3.1.0 | **3.1.1** |
|---|---|---|
| `audit/audit_opinions.json` | Missing | ✅ Present |
| `audit/key_audit_matters.json` | Missing | ✅ Present |

Written as empty arrays when audit phase disabled, so SDK manifest-driven
clients always find them.

### 7. Typology coverage

| Metric | 3.1.0 | **3.1.1** |
|---|---|---|
| `banking_evaluation.aml.typology_coverage` | 0.000 | **0.857** (target ≥ 0.80) |

`AmlTypology::canonical_name()` maps fine-grained variants onto the
7-typology catalog; `Spoofing` variant added; evaluator thresholds
aligned.

### Bonus: new `/v1/jobs/{id}/fraud-split` endpoint

The VynFi 3.1.1 adoption exposes a new aggregated endpoint:

```python
split = client.jobs.fraud_split(job_id)
# total_entries=1578, fraud_entries=33
# scheme_propagated=12, direct_injection=21, propagation_rate=0.364
# by_fraud_type.FictitiousEntry: 6 total, 6 scheme-propagated, 0 direct
# by_fraud_type.ExpenseCapitalization: 5 total, 0 scheme, 5 direct
```

Wired into the SDK as `Jobs.fraud_split()` in v1.5.1 with `FraudSplit` +
`FraudTypeSplit` models.

---

## ⚠️ Still open

### A. `is_off_hours` bias still not firing

| Metric | 3.1.0 | **3.1.1** |
|---|---|---|
| Fraud rate | 0.00 % | 0.00 % |
| Baseline rate | 0.00 % | 0.00 % |

Declared default 35 % in `FraudBehavioralBiasConfig` but the
`created_at` field still shows no off-hours entries in either
population. Possible causes:
- `created_at` field might be defaulted to a single timestamp per job
  (batch-written rather than per-entry)
- the off-hours shift code path may not be wired into the same Phase 8b
  sweep as weekend/round/post-close

**Smoke test worth adding**:
```python
assert fraud_df["created_at"].dt.hour.mod(24).between(22, 6).mean() > 0.10
```

### B. AML relationship-type mix still skewed

| Edge type | 3.1.0 | 3.1.1 | Target |
|---|---|---|---|
| `TransactionCounterparty` | 97.3 % | **96.8 %** | ~80 % |
| `BeneficialOwnership` | 2.3 % | 2.2 % | ~10 % |
| `MuleLink` | 0.4 % | **0.9 %** | ~5 % |
| `ShellLink` | 0.0 % | **0.1 %** | ~5 % |

`network_typology_rate` default was bumped `0.05 → 0.15` per the
changelog, but we observe only ~0.5 pp shift in the mix. Either the
bump hasn't landed in the current deploy, or the dominant
`TransactionCounterparty` edges from general banking transactions drown
out the signal-bearing relationship types.

### C. Scenario templates still 1 in SDK view

| Metric | 3.1.0 | **3.1.1** |
|---|---|---|
| `client.scenarios.templates()` count | 1 | 1 |

DS 3.1.1 added the 7-template catalog and a `/v1/scenarios/templates`
REST endpoint, but **VynFi calls `datasynth-data` as a CLI subprocess
rather than the datasynth-server REST API**, so the new endpoint is
unreachable. The 3 sector YAMLs (`manufacturing_supply_disruption`,
`retail_seasonal_revenue`, `financial_services_credit_risk`) exist on
disk in DS but need portal-side surfacing to appear in
`client.scenarios.templates()`.

### D. `exportLayout: "flat"` still hangs

The camelCase alias (`{"exportLayout": "flat"}`) is now correctly parsed,
but jobs with that option still hang at 0 % progress without an
`error_detail`. Jobs with `{"numericMode": "native"}` alone complete
normally.

Possibly a second bug in the flat-layout output writer, independent
of the alias issue.

---

## Updated scorecard

| # | Issue | 3.1.0 | **3.1.1** |
|---|---|---|---|
| 1 | `round_dollar_bias` inversion | 0× lift | **170×** ✅ |
| 2 | `off_hours_bias` not firing | 0% both | 0% both ⚠️ |
| 3 | `is_fraud_propagated` always False | 0/388 | **12/33** ✅ |
| 4 | `process_variant_summary.json` missing | missing | **162 variants** ✅ |
| 5 | `audit_opinions.json` + KAM missing | missing | **present** ✅ |
| 6 | `TypologyInjector` not firing | cov 0.0 | **cov 0.857** ✅ |
| 7 | AML topology 97% noise | 97.3% low | 96.8% low ⚠️ |
| 8 | Only 1 scenario template | 1 | 1 ⚠️ (portal gap) |
| 9 | `exportLayout: flat` hangs | hangs | hangs ❌ |
| 10 | Fraud rate semantics | unclear | **documented** ✅ |

**7 decisively fixed, 3 partial/open.**

---

## SDK v1.5.1 changes driven by this release

- **`Jobs.fraud_split(job_id)`** wraps the new VynFi endpoint, returns
  a typed `FraudSplit` with a `by_fraud_type` dict of `FraudTypeSplit`.
- New models exported at top level: `FraudSplit`, `FraudTypeSplit`.

## Recommendations for the DS team

Narrow-scoped follow-ups for a DS 3.1.2:

1. **`created_at` off-hours bias** — verify the entry-level `created_at`
   is being written per-entry (not batch-shared), then route it through
   the same Phase 8b sweep as the other biases.
2. **AML relationship rebalance** — consider down-sampling
   `TransactionCounterparty` emission when typology injectors are
   running, so the signal-bearing types make up ~15–20 % instead of
   ~3 %.
3. **Surface `/v1/scenarios/templates` in VynFi** — either have VynFi
   call datasynth-server REST alongside the CLI binary, or implement the
   template catalog directly in the portal.
4. **`exportLayout: "flat"` hang** — the camelCase alias fix was
   necessary but not sufficient; the flat emission path itself still
   has a bug.

## Recommendation for the VynFi team

- **Portal template catalog** — surface the 3 new sector YAMLs
  (`manufacturing_supply_disruption`, `retail_seasonal_revenue`,
  `financial_services_credit_risk`) via `/v1/scenarios/templates` so
  the SDK can advertise them. Currently only `tpl_financial_process_17`
  is returned.
- **`spoofing_rate` passthrough** — DS 3.1.1 added
  `banking.typologies.spoofing_rate`; VynFi's translation layer should
  forward it.

---

## Bottom line

DS 3.1.1 is a **decisive semantic improvement**:
- 3 behavioral biases working at **32×–170×–3106× lift** (vs 0–2× before)
- Typology coverage now **passing its own evaluator threshold**
- Process variants showing **realistic imperfection** (162 variants, 55 %
  happy path vs the prior 8 variants at 100 %)
- Every declared archive file now actually materializes

The remaining 3 issues are narrowly-scoped and don't block production
use of DS + VynFi for fraud/audit ML training or process mining work.

**Net: this is the first DS release where the behavioral fraud signal
is measurably right.** Auditor tools trained on this data will now
learn the canonical weekend / round / post-close patterns.
