# DS 3.1.0 Follow-up Verification — 2026-04-18

Re-verification of the 12 findings from
[`insights-2026-04-18.md`](./insights-2026-04-18.md) after the DS 3.1.0 + VynFi API deploy.

**Summary: 5/12 fixed, 1/12 unchanged, 4/12 still broken, 2/12 mixed.**

---

## ✓ FIXED — the big ones

| # | Issue | Before | After |
|---|---|---|---|
| 2 | Nanosecond timestamps break `pd.to_datetime(utc=True)` | 95 % row loss (19,680 → 908 in pm4py) | **0/1000 dropped**. Truncated to microsecond. `2026-04-18T08:23:22.957768Z` format. |
| 3 | OCPM linkage only ~47 % on JE headers | 234/500 | **500/500 (100 %)**. Every JE header now carries `ocpm_event_ids` + `ocpm_case_id`. |
| 4 | AML networks too sparse to train on | 268 edges, density 0.0014, 0 mule/shell links | **10,268 edges, density 0.053, 38 mule_links, 4 shell_links**. New `TransactionCounterparty` + `MuleLink` + `ShellLink` relationship types. **38× richer.** |
| 10 | `download_file` returns 0 bytes for `managed_blob` | empty response | Works: fetched 299 bytes successfully. |
| 11 | `analytics/` archive ≠ `/v1/jobs/{id}/analytics` endpoint | 2 files | **3 files**: `benford_analysis.json`, `amount_distribution.json`, `banking_evaluation.json`. |

These are real, measurable improvements. The AML network change in
particular unlocks meaningful GNN training that was previously impossible.

---

## ✗ Still broken

| # | Issue | Status |
|---|---|---|
| 8 | `exportLayout: flat` crashes/hangs | Still 0 % progress at 240 s. Jobs fail silently with no `error_detail`. |
| 11.1 | `process_variant_summary.json` missing from archive | Neither in `analytics/` nor returned by the `/v1/jobs/{id}/analytics` endpoint. |
| 12 | Only 1 scenario template (`tpl_financial_process_17`) | No change. Sector-specific DAGs not yet shipped. |
| 6 | `scenarios.create()` still requires `templateId` | Calling with just `{name, generationConfig}` → **422**. Interventions duplication still present. |

---

## Mixed / regressions

### `numericMode: native` — flaky

In the morning run, `debit_amount` came back as `float` (FIXED in 2.3.1 cycle).
In this verification, same config returned the amount as `str` again.

Possible causes:
- Deploy not fully propagated (rolling update)
- Thread-local flag reset from 2.3.1 regressed
- Interaction with the `exportLayout: flat` hang — the server may be
  bailing before the numeric mode hook applies

**Recommendation:** server needs an integration test that generates with
`{numericMode: "native"}` alone and asserts the first line's amount is a JSON
number. Currently there's no fast feedback loop on this.

### Behavioral fraud patterns — no improvement

Feature importance from a RandomForest trained on the latest labeled data:

```
log_amount              0.9191  (was 0.4655)   ← even more dominant
is_manual_int           0.0307  (was 0.0424)
is_round_100            0.0228  (was 0.0059)   ← marginal gain
is_month_end            0.0151  (was 0.0821)   ← regressed
is_weekend              0.0050  (was 0.0012)
is_post_close_int       0.0043  (was 0.0000)   ← marginal gain
is_round_1000           0.0030  (was 0.0010)
```

The fraud signal is now **even more amount-dominated (92 %)** than before.
No evidence that behavioral patterns (weekend, round-dollar, post-close)
were added to the fraud engine. Any detector trained on this data will
over-fit to amount and generalize poorly.

### Fraud rate semantics — still document-scoped

`fraudRate: 0.05` → JE line-level `is_fraud=True` rate was 0.6 % in this run
(21 of 20,843 lines). Still document-scoped (and a smaller share of
documents flagged their lines this round).

---

## Scorecard

| Issue | Before 3.1.0 | After 3.1.0 | Status |
|---|---|---|---|
| Nanosecond timestamps | 95 % row loss | 0 % row loss | ✅ **FIXED** |
| OCPM linkage | 47 % | 100 % | ✅ **FIXED** |
| AML network density | 0.0014 | 0.053 (38×) | ✅ **FIXED** |
| mule/shell links | 0 / 0 | 38 / 4 | ✅ **FIXED** |
| `download_file` for blob | 0 bytes | 299 bytes | ✅ **FIXED** |
| `banking_evaluation.json` | missing | present | ✅ **FIXED** |
| `exportLayout: flat` | crashes | still crashes | ❌ |
| `process_variant_summary` | missing | still missing | ❌ |
| Scenario template diversity | 1 template | 1 template | ❌ |
| `scenarios.create` contract | `templateId` required | still required | ❌ |
| `numericMode: native` | intermittent | flaky (regression?) | ⚠️ |
| Behavioral fraud patterns | weak signal | weaker signal | ⚠️ (regressed) |

---

## Recommendations for the DS/VynFi teams

**Ship-blockers (fix before 3.2):**
1. `numericMode: native` needs an automated regression test that asserts
   the first JE line's `debit_amount` is a JSON number. We've now seen it
   work then break across two same-day runs.
2. `exportLayout: flat` needs either a fix or a feature flag — users
   submitting that config get a 0 % progress hang with no error.
3. Add `process_variant_summary.json` to the analytics archive. The
   `banking_evaluation.json` landing shows this is a small lift.

**Nice-to-have (3.2 or later):**
4. Add at least 2 more scenario DAG templates (one retail-specific,
   one banking-specific). The current 17-node template is too generic.
5. Drop the redundant `interventions` field from scenarios.create's
   request body — keep them in `generationConfig.scenarios.interventions`.
6. Extend the fraud engine with behavioral patterns (weekend, round
   dollars, post-close). These are canonical forensic signals and the
   current output doesn't contain them.
7. Consider exposing `fraudRate` at two levels: `fraudRate.documents`
   and `fraudRate.lines`, so ML trainers can request a specific
   positive-class prevalence.

---

## Overall assessment

**Net positive release.** The timestamp, OCPM, and AML network fixes are
substantial — they unblock use cases that were effectively impossible
before (pm4py at scale, meaningful GNN training, complete process mining
metadata on JEs).

The remaining issues are a mix of known upstream work (flat layout,
variant analytics) and design debt (scenarios contract, template
diversity, behavioral fraud). None block the v1.4.0 SDK in production.
