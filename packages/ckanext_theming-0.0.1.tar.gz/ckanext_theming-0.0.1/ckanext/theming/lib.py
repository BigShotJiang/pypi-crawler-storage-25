"""Theme and UI classes for CKAN theming system.

A theme is a directory containing templates and static files, and
optionally extending a parent theme. A UI provides access to a set of
functions that can be used in templates for building the user interface.

Themes can be registered by CKAN plugins using the ITheme interface.

Example usage::

    theme = get_theme(config["ckan.ui.theme"])
    ui = theme.build_ui(app)
    btn = ui.link("Click me!", href="https://ckan.org")
"""

from __future__ import annotations

import abc
import dataclasses
import datetime
import logging
import os
import uuid
from collections import defaultdict
from collections.abc import Iterable, Iterator
from typing import Any, Protocol, cast

from flask import current_app
from jinja2 import Template
from jinja2.runtime import Macro
from markupsafe import Markup
from typing_extensions import override
from werkzeug.local import LocalProxy

import ckan.plugins as p
import ckan.plugins.toolkit as tk
from ckan import types
from ckan.common import config
from ckan.exceptions import CkanConfigurationException
from ckan.lib.helpers import helper_functions as h

from .interfaces import ITheme

log = logging.getLogger(__name__)

NAMESPACE_UI = uuid.uuid5(uuid.NAMESPACE_OID, "ui")


class PElement(Protocol):
    def __call__(self, *args: Any, **kwargs: Any) -> Markup: ...


class Util:
    _storage_key: str = "ui_storage"
    _theme: Theme
    _attr_groups: list[tuple[str, str]] = [
        ("aria", "aria-"),
        ("data", "data-"),
        ("on", "on"),
        ("hx", "hx-"),
        ("attrs", ""),
    ]

    def _escape_attr_value(self, value: str) -> str:
        """Escape a string for safe inclusion in HTML attributes."""
        return value.replace("&", "&amp;").replace('"', "&quot;")

    def __init__(self, theme: Theme):
        self._theme = theme

    def attrs(self, kwargs: dict[str, Any], defaults: dict[str, Any] | None = None):
        """Helper method to render HTML attributes from a dictionary.

        This method takes a dictionary of attributes and their values, and an
        optional dictionary of default attributes. It combines the two
        dictionaries, giving precedence to the provided attributes, and renders
        them as a string of HTML attributes.

        If attributes contain an "_extra_class" key, its value is appended to
        the "class" attribute. In this way additional classes can be added to
        the list of default classes provided by component. Example:

            # definition
            {% macro button(content, **kwargs) %}
              {% set defaults = {"class": "btn btn-primary"} %}
              <button {{ ui.attrs(kwargs, defaults) }}>{{ content }}</button>
            {% endmacro %}

            # call
            {{ ui.button("Click me!", _extra_class="custom-button-class") }}

            # result
            <button class="btn btn-primary custom-button-class">Click me!</button>

        :param kwargs: A dictionary of attributes to render.
        :param defaults: An optional dictionary of default attributes.
        :return: A Markup object containing the rendered HTML attributes.

        """
        if not kwargs and not defaults:
            return ""
        if defaults is None:
            defaults = {}

        parts = []
        for key, prefix in self._attr_groups:
            base = defaults.get(key, {})
            base.update(kwargs.get(key, {}))
            if not base:
                continue
            extra_class: str | None
            if key == "attrs" and (extra_class := kwargs.get("_extra_class")):
                base["class"] = " ".join([base.get("class", ""), extra_class])
            parts.append(" ".join(f'{prefix}{k}="{self._escape_attr_value(str(v))}"' for k, v in base.items()))

        return h.literal(" ".join(parts)) if parts else ""

    def tag(self, content: str, tag: str, is_void: bool = False, /, **kwargs: Any):
        """Helper method to render an HTML tag with the specified content, tag name, and attributes.

        Empty tag name will render content without any wrapper - this can be
        used to apply wrapper conditionally. For example, `ui.util.tag(content,
        tag if condition else "")` will render `content` wrapped in `tag` if
        `condition` is True, and just `content` without wrapper otherwise.

        If `is_void` is True, renders a void tag (e.g., <img />) instead of a
        normal tag(e.g., <img></img>).

        :param content: The content to be enclosed within the tag.
        :param tag: The name of the HTML tag to render.
        :param is_void: If True, renders a void tag (e.g., <img />). Defaults to False.
        :param kwargs: Additional attributes for the tag.
        :return: A Markup object containing the rendered HTML tag.

        """
        if not tag:
            return content

        attrs = self.attrs(kwargs)
        if is_void:
            return h.literal(f"<{tag} {attrs}/>")

        return h.literal(f"<{tag} {attrs}>{content}</{tag}>")

    def call(self, el: PElement, /, *args: Any, caller: Macro, **kwargs: Any) -> Markup:
        """Call an inline element as a block element.

        Allows passing complex content into an element using a Jinja2
        caller. For example, following simple macro does not contain `caller()`::

            {% macro button(content) %}
                <button>{{ content }}</button>
            {% endmacro %}

        As result, it cannot be called in form `{% call ui.button() %}` and
        rendering button with nested HTML turns into a verbose task. But using
        `ui.util.call`, `button` can be used with `call`::

            {% call ui.util.call(ui.button) %}
                <i class="icon"/>
                Click!
            {% endcall %}

        The content of the `call` block will be passed as a first argument into
        the target macro. Any other positional and named arguments of the
        `ui.util.call` will be redirected into `ui.button` as well.
        """
        return el(caller(), *args, **kwargs)

    def map(self, el: PElement, items: Iterable[Any], /, *args: Any, **kwargs: Any) -> Markup:
        """Map an element over a collection of items.

        Renders the specified element for each item in the collection and
        concatenates the results.

        :param el: The element to render for each item.
        :param items: The collection of items.
        :param args: Positional arguments to pass to the element.
        :param kwargs: Named arguments to pass to the element.
        :return: A Markup object containing the concatenated results.
        """
        return Markup().join(el(item, *args, **kwargs) for item in items)

    def now(self, tz: datetime.timezone = datetime.timezone.utc):
        """Get the current UTC datetime.

        :param tz: Timezone for the returned datetime. Defaults to UTC.
        :return: Current datetime with the specified timezone.
        """
        return datetime.datetime.now(tz)

    def id(self, value: str | None = None, prefix: str = "id-"):
        """Generate a unique identifier.

        If `value` is provided, a UUID5 based on the value is generated,
        otherwise a random UUID4 is generated.

        Useful for generating unique HTML element IDs.

        :param value: Optional value to base the UUID5 on.
        :param prefix: Prefix to prepend to the identifier.
        :return: An identifier string.
        """
        result = uuid.uuid5(NAMESPACE_UI, value) if value else uuid.uuid4()
        return f"{prefix}{result.hex}"

    def keep_item(self, category: str, key: str, value: Any):
        """Keep an item in the UI storage under the specified category.

        This method allows storing arbitrary items in a per-request storage
        associated with the UI. Items can be retrieved later during the same
        request.

        :param category: The category under which to store the item.
        :param key: The key for the item.
        :param value: The item to store.
        """
        storage = tk.g.setdefault(self._storage_key, defaultdict(dict))
        storage[category][key] = value

    def pop_items(
        self, category: str, key: str | None = None, default: Any = None, keep: bool = False
    ) -> dict[str, Any] | Any:
        """Pop items from the UI storage under the specified category.

        :param category: The category from which to pop items.
        :param key: Optional key of the item to pop. If not provided, all items
                    under the category are popped.
        :param default: Default value to return if the key is not found.
        :param keep: If True, items will not be removed from storage after popping.
        :return: The popped item(s) from the UI storage.
        """
        storage = tk.g.setdefault(self._storage_key, defaultdict(dict))
        items = storage[category]
        if key:
            if keep:
                return items.get(key, default)
            return items.pop(key, default)

        if not keep:
            del storage[category]

        return items

    def icon(self, name: str) -> str:
        """Normalize icon name.

        Maps common icon names to their corresponding names in the theme's icon
        set. If no mapping exists, returns the original name. This allows using
        consistent icon names across different themes. For example, "search" is
        mapped to "magnifying-glass" if the theme does not have icon with ID
        `search`. Themes can override these mappings as needed.

        :param name: Common name of the icon.
        :return: The name of the corresponding icon provided by theme

        """
        return self._theme.icon_map.get(name, name)


class UI(Iterable[str], abc.ABC):
    """Abstract base class for theme UIs.

    A UI provides access to a set of function that can be used in
    templates. Each function corresponds to a UI element, such as buttons,
    links, forms, etc. The UI class maintains an inventory of available
    elements that can be accessed by name.

    """

    util: Util
    _inv: dict[str, PElement]

    def __init__(self, app: types.CKANApp, util: Util):
        self.util = util
        self._inv = {}

    @override
    def __iter__(self) -> Iterator[str]:
        """Return an iterable of element names provided by this UI.

        :return: An iterable of element names.
        """
        return iter(self._inv)

    def __getattr__(self, name: str) -> PElement:
        """Get an element factory by name.

        :param name: The name of the element.
        :return: A callable that produces the element.
        """
        if name not in self._inv:
            raise AttributeError(name)

        return self._inv[name]

    def add_component(self, name: str, component: PElement):
        """Add a new component to the UI inventory.

        :param name: The name of the component.
        :param component: A callable that produces the component.
        """
        self._inv[name] = component


class MacroUI(UI):
    """A UI implementation that loads macros from a Jinja2 template.

    The template should define macros for each UI element. The default template
    is "macros/ui.html".

    :param source: The path to the Jinja2 template containing the macros.
    """

    _sources: list[str] = ["macros/ui.html"]

    __templates: list[Template]

    @override
    def __init__(self, app: types.CKANApp, util: Util):
        super().__init__(app, util)

        if hasattr(app, "_wsgi_app"):
            app = cast(types.CKANApp, app._wsgi_app)  # pyright: ignore[reportAttributeAccessIssue]

        self.__env = app.jinja_env

        sources = self._sources.copy()
        for plugin in p.PluginImplementations(ITheme):
            sources += plugin.get_additional_theme_ui_sources()

        self.__templates = [self.__env.get_template(source) for source in sources]

        self._fill_inventory()

    def _fill_inventory(self):
        for tpl in self.__templates:
            mod = tpl.module
            for name in dir(mod):
                if name.startswith("_"):
                    continue
                self.add_component(name, getattr(mod, name))

    @override
    def __getattr__(self, name: str):
        # reset macro cache at the beginning of the request in debug mode. This
        # allows to edit UI macros without restarting the server. New macros
        # are not detected in this way and still require restart.
        if config["debug"] and not getattr(tk.g, "_ui_compiled", False):
            for tpl in self.__templates:
                tpl._module = tpl.make_module()  # pyright: ignore[reportPrivateUsage]

            tk.g._ui_compiled = True
            self._fill_inventory()

        return super().__getattr__(name)


@dataclasses.dataclass
class Theme:
    """Information about a theme.

    :param name: Name of the theme.
    :param path: Path to the theme directory.
    :param parent: Name of the parent theme, or None.
    :param template_folder: Subdirectory for templates.
    :param public_folder: Subdirectory for public static files.
    :param asset_folder: Subdirectory for asset files.
    :param ui_factory: Factory class for creating the UI instance.
    :param util_factory: Factory class for creating the Util instance.
    :param icon_map: Mapping of common icon names to theme-specific names.
    """

    name: str
    path: str | None
    parent: str | None = None

    template_folder: str = "templates"
    public_folder: str = "public"
    asset_folder: str = "assets"
    ui_factory: type[UI] = MacroUI
    util_factory: type[Util] = Util
    icon_map: dict[str, str] = dataclasses.field(default_factory=dict)

    def build_ui(self, app: types.CKANApp) -> UI:
        """Build a UI instance for this theme.

        :param app: The CKAN application instance.
        :return: A UI instance.
        """
        ui = self.ui_factory(app, self.util_factory(self))
        for plugin in p.PluginImplementations(ITheme):
            plugin.patch_theme_ui(self, ui)

        return ui

    def template_path(self):
        """Get the path to the theme's templates directory."""
        if self.path:
            return os.path.join(self.path, self.template_folder)

    def public_path(self):
        """Get the path to the theme's public directory."""
        if self.path:
            return os.path.join(self.path, self.public_folder)

    def asset_path(self):
        """Get the path to the theme's assets directory."""
        if self.path:
            return os.path.join(self.path, self.asset_folder)


def get_theme(name: str):
    """Get theme by name.

    :raises KeyError: if theme not found
    """
    themes = collect_themes()
    return themes[name]


def collect_themes() -> dict[str, Theme]:
    """Collect available themes from core and plugins."""
    # ckan_root = os.path.dirname(os.path.abspath(ckan.__file__))
    themes: dict[str, Theme] = {
        # Theme("classic", os.path.join(ckan_root, "templates")),
        # Theme("midnight-blue", os.path.join(ckan_root, "templates-midnight-blue")),
    }
    for plugin in p.PluginImplementations(ITheme):
        themes.update({theme.name: theme for theme in plugin.register_themes()})

    return themes


def resolve_paths(theme: str | None) -> list[str]:
    """Resolve theme paths including parent themes.

    :raises KeyError: if the parent theme is not found
    """
    themes = collect_themes()
    paths: list[str] = []
    while theme:
        info = themes[theme]
        if info.path:
            paths.append(info.path)
        theme = info.parent

    return paths


def enable_theme(name: str, config: Any):
    """Enable the specified theme.

    This function updates the CKAN configuration to include template and
    static file directories from the specified theme and its parent themes.

    :param name: The name of the theme to switch to.
    :param config: The CKAN configuration dictionary.
    :raises CkanConfigurationException: if the theme or its parent is not found

    """
    themes = collect_themes()
    enabled_themes: list[Theme] = []

    while True:
        theme = themes.pop(name, None)
        if not theme:
            msg = f"Theme '{name}' is not recognised."
            raise CkanConfigurationException(msg)

        enabled_themes.append(theme)
        if not theme.parent:
            break
        name = theme.parent

    here = os.path.dirname(__file__)

    for theme in reversed(enabled_themes):
        if (path := theme.template_path()) and os.path.isdir(path):
            tk.add_template_directory(config, os.path.relpath(path, here))

        if (path := theme.asset_path()) and os.path.isdir(path):
            tk.add_resource(os.path.relpath(path, here), f"theming/{theme.name}")

        if (path := theme.public_path()) and os.path.isdir(path):
            tk.add_public_directory(config, os.path.relpath(path, here))

    UIManager.reset()


class UIManager:
    ui: UI | None = None

    @classmethod
    def get(cls):
        """Get the current UI instance. Creates one if it doesn't exist."""
        if cls.ui is None:
            cls.set(tk.config["ckan.ui.theme"])

        return cls.ui

    @classmethod
    def set(cls, theme: str, app: types.CKANApp = current_app):  # pyright: ignore[reportArgumentType]
        """Set the UI instance to a new theme."""
        cls.ui = get_theme(theme).build_ui(app)

    @classmethod
    def reset(cls):
        """Reset the UI instance to None."""
        cls.ui = None


ui = LocalProxy(UIManager.get)
