from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional, List, Tuple
from PyQt5.QtGui import QPainter, QFont, QFontMetricsF, QPen, QColor, QPixmap, QImage
from PyQt5.QtCore import Qt, QRectF, QPointF

FONT_FAMILY        = "Times New Roman"
FONT_SIZE_NORMAL   = 22
FONT_SIZE_SMALL    = 15
FONT_SIZE_TINY     = 11
FONT_SIZE_OP_LARGE = 32
FRAC_BAR_THICK     = 1.5
FRAC_BAR_MARGIN    = 3.0
SQRT_OVERHANG      = 4.0
SQRT_TICK_W        = 9.0
SQRT_TICK_H_RATIO  = 0.38
SUP_OFFSET         = 0.46
SUB_OFFSET         = 0.28
PAREN_MARGIN       = 4.0
INTEGRAL_W_RATIO   = 0.55
INTEGRAL_H_EXTRA   = 18.0
SUM_EXTRA          = 12.0
COLOR_FG           = QColor(30, 30, 30)
COLOR_PLACEHOLDER  = QColor(180, 180, 180)
COLOR_SELECT       = QColor(180, 210, 255, 160)
COLOR_CURSOR       = QColor(30, 30, 200)
CURSOR_WIDTH       = 2
PLACEHOLDER_TEXT   = "..."


@dataclass
class RenderMetrics:
    width: float = 0.0
    ascent: float = 0.0
    descent: float = 0.0
    @property
    def height(self) -> float:
        return self.ascent + self.descent


@dataclass
class HitRegion:
    node_id: int = 0
    rect: QRectF = field(default_factory=QRectF)
    cursor_x_before: float = 0.0
    cursor_x_after: float = 0.0
    is_placeholder: bool = False


def _font(painter: QPainter, size: int, italic: bool = False, bold: bool = False) -> QFont:
    f = QFont(FONT_FAMILY, size)
    f.setItalic(italic)
    f.setBold(bold)
    f.setStyleStrategy(QFont.PreferAntialias)
    return f


def _fm(painter: QPainter, font: QFont) -> QFontMetricsF:
    return QFontMetricsF(font)


class FormulaNode:
    _counter = 0
    def __init__(self):
        FormulaNode._counter += 1
        self.node_id = FormulaNode._counter
    def measure(self, painter: QPainter) -> RenderMetrics:
        raise NotImplementedError
    def draw(self, painter: QPainter, x: float, y: float,
             hits: List[HitRegion], selected: set, cursor_id: Optional[int]):
        raise NotImplementedError
    def collect_ids(self) -> List[int]:
        return [self.node_id]
    def to_sympy(self) -> str:
        return ""
    def to_latex(self) -> str:
        return ""
    def to_text(self) -> str:
        return ""
    def clone(self) -> "FormulaNode":
        import copy
        return copy.deepcopy(self)


class TextNode(FormulaNode):
    def __init__(self, text: str, size: int = FONT_SIZE_NORMAL,
                 italic: bool = True, bold: bool = False,
                 color: Optional[QColor] = None):
        super().__init__()
        self.text = text
        self.size = size
        self.italic = italic
        self.bold = bold
        self.color = color or COLOR_FG
    def measure(self, painter: QPainter) -> RenderMetrics:
        f = _font(painter, self.size, self.italic, self.bold)
        fm = _fm(painter, f)
        return RenderMetrics(fm.horizontalAdvance(self.text), fm.ascent(), fm.descent())
    def draw(self, painter: QPainter, x: float, y: float,
             hits: List[HitRegion], selected: set, cursor_id: Optional[int]):
        f = _font(painter, self.size, self.italic, self.bold)
        fm = _fm(painter, f)
        w = fm.horizontalAdvance(self.text)
        m = RenderMetrics(w, fm.ascent(), fm.descent())
        r = QRectF(x, y - m.ascent, w, m.height)
        if self.node_id in selected:
            painter.fillRect(r, COLOR_SELECT)
        if cursor_id == self.node_id:
            pen = painter.pen()
            painter.setPen(QPen(COLOR_CURSOR, CURSOR_WIDTH))
            painter.drawLine(QPointF(x, y - m.ascent), QPointF(x, y + m.descent))
            painter.setPen(pen)
        painter.setFont(f)
        painter.setPen(QPen(self.color))
        painter.drawText(QPointF(x, y), self.text)
        hits.append(HitRegion(self.node_id, r, x, x + w))
    def to_sympy(self) -> str:
        return self.text
    def to_latex(self) -> str:
        return self.text
    def to_text(self) -> str:
        return self.text


class PlaceholderNode(FormulaNode):
    def __init__(self, size: int = FONT_SIZE_NORMAL):
        super().__init__()
        self.size = size
    def measure(self, painter: QPainter) -> RenderMetrics:
        f = _font(painter, self.size, False)
        fm = _fm(painter, f)
        return RenderMetrics(fm.horizontalAdvance(PLACEHOLDER_TEXT), fm.ascent(), fm.descent())
    def draw(self, painter: QPainter, x: float, y: float,
             hits: List[HitRegion], selected: set, cursor_id: Optional[int]):
        f = _font(painter, self.size, False)
        fm = _fm(painter, f)
        w = fm.horizontalAdvance(PLACEHOLDER_TEXT)
        m = RenderMetrics(w, fm.ascent(), fm.descent())
        r = QRectF(x, y - m.ascent, w, m.height)
        if self.node_id in selected:
            painter.fillRect(r, COLOR_SELECT)
        if cursor_id == self.node_id:
            pen = painter.pen()
            painter.setPen(QPen(COLOR_CURSOR, CURSOR_WIDTH))
            painter.drawLine(QPointF(x, y - m.ascent), QPointF(x, y + m.descent))
            painter.setPen(pen)
        painter.setFont(f)
        painter.setPen(QPen(COLOR_PLACEHOLDER))
        painter.drawText(QPointF(x, y), PLACEHOLDER_TEXT)
        hits.append(HitRegion(self.node_id, r, x, x + w, True))
    def to_sympy(self) -> str:
        return "x"
    def to_latex(self) -> str:
        return r"\square"
    def to_text(self) -> str:
        return "_"


class SeqNode(FormulaNode):
    def __init__(self, children: List[FormulaNode]):
        super().__init__()
        self.children = children
    def measure(self, painter: QPainter) -> RenderMetrics:
        if not self.children:
            return RenderMetrics(0, 0, 0)
        w = sum(c.measure(painter).width for c in self.children)
        asc = max(c.measure(painter).ascent for c in self.children)
        desc = max(c.measure(painter).descent for c in self.children)
        return RenderMetrics(w, asc, desc)
    def draw(self, painter: QPainter, x: float, y: float,
             hits: List[HitRegion], selected: set, cursor_id: Optional[int]):
        cx = x
        for c in self.children:
            c.draw(painter, cx, y, hits, selected, cursor_id)
            cx += c.measure(painter).width
    def collect_ids(self) -> List[int]:
        ids = [self.node_id]
        for c in self.children:
            ids.extend(c.collect_ids())
        return ids
    def to_sympy(self) -> str:
        return "".join(c.to_sympy() for c in self.children)
    def to_latex(self) -> str:
        return "".join(c.to_latex() for c in self.children)
    def to_text(self) -> str:
        return "".join(c.to_text() for c in self.children)


class FracNode(FormulaNode):
    def __init__(self, num: FormulaNode, den: FormulaNode):
        super().__init__()
        self.num = num
        self.den = den
    def measure(self, painter: QPainter) -> RenderMetrics:
        nm = self.num.measure(painter)
        dm = self.den.measure(painter)
        w = max(nm.width, dm.width) + FRAC_BAR_MARGIN * 2
        return RenderMetrics(w,
                             nm.height + FRAC_BAR_MARGIN + FRAC_BAR_THICK,
                             dm.height + FRAC_BAR_MARGIN)
    def draw(self, painter: QPainter, x: float, y: float,
             hits: List[HitRegion], selected: set, cursor_id: Optional[int]):
        nm = self.num.measure(painter)
        dm = self.den.measure(painter)
        m = self.measure(painter)
        pen = painter.pen()
        painter.setPen(QPen(COLOR_FG, FRAC_BAR_THICK))
        painter.drawLine(QPointF(x, y), QPointF(x + m.width, y))
        painter.setPen(pen)
        self.num.draw(painter, x + (m.width - nm.width) / 2,
                      y - FRAC_BAR_MARGIN - nm.descent, hits, selected, cursor_id)
        self.den.draw(painter, x + (m.width - dm.width) / 2,
                      y + FRAC_BAR_MARGIN + dm.ascent, hits, selected, cursor_id)
    def collect_ids(self) -> List[int]:
        return [self.node_id] + self.num.collect_ids() + self.den.collect_ids()
    def to_sympy(self) -> str:
        return f"({self.num.to_sympy()}) / ({self.den.to_sympy()})"
    def to_latex(self) -> str:
        return r"\frac{" + self.num.to_latex() + "}{" + self.den.to_latex() + "}"
    def to_text(self) -> str:
        return f"({self.num.to_text()}) / ({self.den.to_text()})"


class SqrtNode(FormulaNode):
    def __init__(self, body: FormulaNode, index: Optional[FormulaNode] = None):
        super().__init__()
        self.body = body
        self.index = index
    def measure(self, painter: QPainter) -> RenderMetrics:
        bm = self.body.measure(painter)
        return RenderMetrics(SQRT_TICK_W + bm.width + SQRT_OVERHANG,
                             bm.ascent + SQRT_OVERHANG, bm.descent)
    def draw(self, painter: QPainter, x: float, y: float,
             hits: List[HitRegion], selected: set, cursor_id: Optional[int]):
        bm = self.body.measure(painter)
        m = self.measure(painter)
        top_y = y - m.ascent
        pen = painter.pen()
        painter.setPen(QPen(COLOR_FG, FRAC_BAR_THICK))
        painter.drawLine(QPointF(x, y - bm.height * SQRT_TICK_H_RATIO),
                         QPointF(x + SQRT_TICK_W * 0.4, y + bm.descent))
        painter.drawLine(QPointF(x + SQRT_TICK_W * 0.4, y + bm.descent),
                         QPointF(x + SQRT_TICK_W, top_y))
        painter.drawLine(QPointF(x + SQRT_TICK_W, top_y),
                         QPointF(x + m.width - SQRT_OVERHANG / 2, top_y))
        painter.setPen(pen)
        self.body.draw(painter, x + SQRT_TICK_W, y, hits, selected, cursor_id)
        if self.index:
            idxm = self.index.measure(painter)
            self.index.draw(painter, x, top_y + idxm.ascent * 0.5,
                            hits, selected, cursor_id)
    def collect_ids(self) -> List[int]:
        ids = [self.node_id] + self.body.collect_ids()
        if self.index:
            ids.extend(self.index.collect_ids())
        return ids
    def to_sympy(self) -> str:
        if self.index:
            return f"({self.body.to_sympy()}) ** (1 / ({self.index.to_sympy()}))"
        return f"sqrt({self.body.to_sympy()})"
    def to_latex(self) -> str:
        if self.index:
            return r"\sqrt[" + self.index.to_latex() + "]{" + self.body.to_latex() + "}"
        return r"\sqrt{" + self.body.to_latex() + "}"
    def to_text(self) -> str:
        return f"sqrt({self.body.to_text()})"


class PowerNode(FormulaNode):
    def __init__(self, base: FormulaNode, exp: FormulaNode):
        super().__init__()
        self.base = base
        self.exp = exp
    def measure(self, painter: QPainter) -> RenderMetrics:
        bm = self.base.measure(painter)
        em = self.exp.measure(painter)
        return RenderMetrics(bm.width + em.width,
                             bm.ascent + em.height * SUP_OFFSET, bm.descent)
    def draw(self, painter: QPainter, x: float, y: float,
             hits: List[HitRegion], selected: set, cursor_id: Optional[int]):
        bm = self.base.measure(painter)
        em = self.exp.measure(painter)
        self.base.draw(painter, x, y, hits, selected, cursor_id)
        self.exp.draw(painter, x + bm.width,
                      y - bm.ascent + em.ascent * (1 - SUP_OFFSET),
                      hits, selected, cursor_id)
    def collect_ids(self) -> List[int]:
        return [self.node_id] + self.base.collect_ids() + self.exp.collect_ids()
    def to_sympy(self) -> str:
        return f"({self.base.to_sympy()}) ** ({self.exp.to_sympy()})"
    def to_latex(self) -> str:
        return self.base.to_latex() + "^{" + self.exp.to_latex() + "}"
    def to_text(self) -> str:
        return f"({self.base.to_text()})^({self.exp.to_text()})"


class SubNode(FormulaNode):
    def __init__(self, base: FormulaNode, sub: FormulaNode):
        super().__init__()
        self.base = base
        self.sub = sub
    def measure(self, painter: QPainter) -> RenderMetrics:
        bm = self.base.measure(painter)
        sm = self.sub.measure(painter)
        return RenderMetrics(bm.width + sm.width,
                             bm.ascent, bm.descent + sm.height * SUB_OFFSET)
    def draw(self, painter: QPainter, x: float, y: float,
             hits: List[HitRegion], selected: set, cursor_id: Optional[int]):
        bm = self.base.measure(painter)
        sm = self.sub.measure(painter)
        self.base.draw(painter, x, y, hits, selected, cursor_id)
        self.sub.draw(painter, x + bm.width,
                      y + bm.descent + sm.ascent * SUB_OFFSET,
                      hits, selected, cursor_id)
    def collect_ids(self) -> List[int]:
        return [self.node_id] + self.base.collect_ids() + self.sub.collect_ids()
    def to_sympy(self) -> str:
        return self.base.to_sympy()
    def to_latex(self) -> str:
        return self.base.to_latex() + "_{" + self.sub.to_latex() + "}"
    def to_text(self) -> str:
        return f"{self.base.to_text()}_{self.sub.to_text()}"


class PowerSubNode(FormulaNode):
    def __init__(self, base: FormulaNode, exp: FormulaNode, sub: FormulaNode):
        super().__init__()
        self.base = base
        self.exp = exp
        self.sub = sub
    def measure(self, painter: QPainter) -> RenderMetrics:
        bm = self.base.measure(painter)
        em = self.exp.measure(painter)
        sm = self.sub.measure(painter)
        script_w = max(em.width, sm.width)
        return RenderMetrics(bm.width + script_w,
                             bm.ascent + em.height * SUP_OFFSET,
                             bm.descent + sm.height * SUB_OFFSET)
    def draw(self, painter: QPainter, x: float, y: float,
             hits: List[HitRegion], selected: set, cursor_id: Optional[int]):
        bm = self.base.measure(painter)
        em = self.exp.measure(painter)
        sm = self.sub.measure(painter)
        self.base.draw(painter, x, y, hits, selected, cursor_id)
        self.exp.draw(painter, x + bm.width,
                      y - bm.ascent + em.ascent * (1 - SUP_OFFSET),
                      hits, selected, cursor_id)
        self.sub.draw(painter, x + bm.width,
                      y + bm.descent + sm.ascent * SUB_OFFSET,
                      hits, selected, cursor_id)
    def collect_ids(self) -> List[int]:
        return ([self.node_id] + self.base.collect_ids()
                + self.exp.collect_ids() + self.sub.collect_ids())
    def to_sympy(self) -> str:
        return f"({self.base.to_sympy()}) ** ({self.exp.to_sympy()})"
    def to_latex(self) -> str:
        return (self.base.to_latex()
                + "^{" + self.exp.to_latex() + "}"
                + "_{" + self.sub.to_latex() + "}")


class ParenNode(FormulaNode):
    def __init__(self, body: FormulaNode,
                 left: str = "(", right: str = ")"):
        super().__init__()
        self.body = body
        self.left = left
        self.right = right
    def _paren_w(self, painter: QPainter) -> float:
        f = _font(painter, FONT_SIZE_NORMAL, False)
        return _fm(painter, f).horizontalAdvance("(")
    def measure(self, painter: QPainter) -> RenderMetrics:
        bm = self.body.measure(painter)
        pw = self._paren_w(painter)
        return RenderMetrics(bm.width + pw * 2,
                             bm.ascent + PAREN_MARGIN, bm.descent + PAREN_MARGIN)
    def draw(self, painter: QPainter, x: float, y: float,
             hits: List[HitRegion], selected: set, cursor_id: Optional[int]):
        bm = self.body.measure(painter)
        m = self.measure(painter)
        f = _font(painter, FONT_SIZE_NORMAL, False)
        fm = _fm(painter, f)
        pw = fm.horizontalAdvance("(")
        base_h = fm.ascent() + fm.descent()
        scale = m.height / base_h if base_h > 0 else 1.0
        painter.save()
        painter.translate(x, y - bm.ascent / 2 + bm.descent / 2)
        painter.scale(1.0, scale)
        painter.setFont(f)
        painter.setPen(QPen(COLOR_FG))
        painter.drawText(QPointF(0, 0), self.left)
        painter.restore()
        self.body.draw(painter, x + pw, y, hits, selected, cursor_id)
        painter.save()
        painter.translate(x + pw + bm.width, y - bm.ascent / 2 + bm.descent / 2)
        painter.scale(1.0, scale)
        painter.setFont(f)
        painter.setPen(QPen(COLOR_FG))
        painter.drawText(QPointF(0, 0), self.right)
        painter.restore()
    def collect_ids(self) -> List[int]:
        return [self.node_id] + self.body.collect_ids()
    def to_sympy(self) -> str:
        return f"({self.body.to_sympy()})"
    def to_latex(self) -> str:
        return r"\left" + self.left + self.body.to_latex() + r"\right" + self.right
    def to_text(self) -> str:
        return f"{self.left}{self.body.to_text()}{self.right}"


class AbsNode(FormulaNode):
    def __init__(self, body: FormulaNode):
        super().__init__()
        self.body = body
    def measure(self, painter: QPainter) -> RenderMetrics:
        bm = self.body.measure(painter)
        f = _font(painter, FONT_SIZE_NORMAL, False)
        pw = _fm(painter, f).horizontalAdvance("|")
        return RenderMetrics(bm.width + pw * 2,
                             bm.ascent + PAREN_MARGIN, bm.descent + PAREN_MARGIN)
    def draw(self, painter: QPainter, x: float, y: float,
             hits: List[HitRegion], selected: set, cursor_id: Optional[int]):
        bm = self.body.measure(painter)
        m = self.measure(painter)
        f = _font(painter, FONT_SIZE_NORMAL, False)
        fm = _fm(painter, f)
        pw = fm.horizontalAdvance("|")
        scale = m.height / (fm.ascent() + fm.descent()) if (fm.ascent() + fm.descent()) > 0 else 1.0
        for bar_x in (x, x + pw + bm.width):
            painter.save()
            painter.translate(bar_x, y - bm.ascent / 2 + bm.descent / 2)
            painter.scale(1.0, scale)
            painter.setFont(f)
            painter.setPen(QPen(COLOR_FG))
            painter.drawText(QPointF(0, 0), "|")
            painter.restore()
        self.body.draw(painter, x + pw, y, hits, selected, cursor_id)
    def collect_ids(self) -> List[int]:
        return [self.node_id] + self.body.collect_ids()
    def to_sympy(self) -> str:
        return f"Abs({self.body.to_sympy()})"
    def to_latex(self) -> str:
        return r"\left|" + self.body.to_latex() + r"\right|"
    def to_text(self) -> str:
        return f"|{self.body.to_text()}|"


class IntegralNode(FormulaNode):
    def __init__(self, body: FormulaNode, var: FormulaNode,
                 lower: Optional[FormulaNode] = None,
                 upper: Optional[FormulaNode] = None):
        super().__init__()
        self.body = body
        self.var = var
        self.lower = lower
        self.upper = upper
    def _sign_dim(self, painter: QPainter) -> Tuple[float, float, float]:
        f = _font(painter, FONT_SIZE_OP_LARGE, False)
        fm = _fm(painter, f)
        w = fm.horizontalAdvance("\u222B") * INTEGRAL_W_RATIO + 6
        h = fm.height() + INTEGRAL_H_EXTRA
        return w, h * 0.55, h * 0.45
    def measure(self, painter: QPainter) -> RenderMetrics:
        sw, sa, sd = self._sign_dim(painter)
        bm = self.body.measure(painter)
        vm = self.var.measure(painter)
        lw = max((self.lower.measure(painter).width if self.lower else 0),
                 (self.upper.measure(painter).width if self.upper else 0))
        fw = _fm(painter, _font(painter, FONT_SIZE_NORMAL, False)).horizontalAdvance("d")
        return RenderMetrics(sw + lw + bm.width + fw + vm.width + 8,
                             max(sa, bm.ascent), max(sd, bm.descent))
    def draw(self, painter: QPainter, x: float, y: float,
             hits: List[HitRegion], selected: set, cursor_id: Optional[int]):
        sw, sa, sd = self._sign_dim(painter)
        bm = self.body.measure(painter)
        lw = max((self.lower.measure(painter).width if self.lower else 0),
                 (self.upper.measure(painter).width if self.upper else 0))
        f_big = _font(painter, FONT_SIZE_OP_LARGE, False)
        painter.setFont(f_big)
        painter.setPen(QPen(COLOR_FG))
        painter.drawText(QPointF(x, y + sa * 0.28), "\u222B")
        if self.lower:
            lm = self.lower.measure(painter)
            self.lower.draw(painter, x + sw, y + sd * 0.55,
                            hits, selected, cursor_id)
        if self.upper:
            um = self.upper.measure(painter)
            self.upper.draw(painter, x + sw, y - sa * 0.65,
                            hits, selected, cursor_id)
        cx = x + sw + lw
        self.body.draw(painter, cx, y, hits, selected, cursor_id)
        f_dx = _font(painter, FONT_SIZE_NORMAL, False)
        fm_dx = _fm(painter, f_dx)
        dw = fm_dx.horizontalAdvance("d")
        dx_x = cx + bm.width + 5
        painter.setFont(f_dx)
        painter.setPen(QPen(COLOR_FG))
        painter.drawText(QPointF(dx_x, y), "d")
        self.var.draw(painter, dx_x + dw, y, hits, selected, cursor_id)
    def collect_ids(self) -> List[int]:
        ids = [self.node_id] + self.body.collect_ids() + self.var.collect_ids()
        if self.lower: ids.extend(self.lower.collect_ids())
        if self.upper: ids.extend(self.upper.collect_ids())
        return ids
    def to_sympy(self) -> str:
        v = self.var.to_sympy()
        b = self.body.to_sympy()
        if self.lower and self.upper:
            return f"integrate({b}, ({v}, {self.lower.to_sympy()}, {self.upper.to_sympy()}))"
        return f"integrate({b}, {v})"
    def to_latex(self) -> str:
        lim = ""
        if self.lower:
            lim += "_{" + self.lower.to_latex() + "}"
        if self.upper:
            lim += "^{" + self.upper.to_latex() + "}"
        return r"\int" + lim + " " + self.body.to_latex() + r"\,d" + self.var.to_latex()


class LimitNode(FormulaNode):
    def __init__(self, body: FormulaNode, var: FormulaNode,
                 approach: FormulaNode, direction: str = ""):
        super().__init__()
        self.body = body
        self.var = var
        self.approach = approach
        self.direction = direction
    def _lim_label(self, painter: QPainter) -> Tuple[float, float, float]:
        f = _font(painter, FONT_SIZE_NORMAL, False, True)
        fm = _fm(painter, f)
        w = fm.horizontalAdvance("lim")
        return w, fm.ascent(), fm.descent()
    def measure(self, painter: QPainter) -> RenderMetrics:
        lw, la, ld = self._lim_label(painter)
        bm = self.body.measure(painter)
        vm = self.var.measure(painter)
        am = self.approach.measure(painter)
        sub_w = vm.width + _fm(painter, _font(painter, FONT_SIZE_TINY)).horizontalAdvance("\u2192") + am.width
        sym_w = max(lw, sub_w)
        extra = FONT_SIZE_TINY * 1.3
        return RenderMetrics(sym_w + bm.width + 6,
                             bm.ascent + extra, bm.descent)
    def draw(self, painter: QPainter, x: float, y: float,
             hits: List[HitRegion], selected: set, cursor_id: Optional[int]):
        lw, la, ld = self._lim_label(painter)
        bm = self.body.measure(painter)
        vm = self.var.measure(painter)
        am = self.approach.measure(painter)
        f_lim = _font(painter, FONT_SIZE_NORMAL, False, True)
        fm_lim = _fm(painter, f_lim)
        sym_w = max(lw, vm.width + 8 + am.width)
        painter.setFont(f_lim)
        painter.setPen(QPen(COLOR_FG))
        painter.drawText(QPointF(x + (sym_w - lw) / 2, y), "lim")
        f_sub = _font(painter, FONT_SIZE_TINY, True)
        fm_sub = _fm(painter, f_sub)
        sub_y = y + ld + fm_sub.ascent() * 0.8
        painter.setFont(f_sub)
        arr_w = fm_sub.horizontalAdvance("\u2192")
        self.var.draw(painter, x, sub_y, hits, selected, cursor_id)
        painter.setFont(f_sub)
        painter.setPen(QPen(COLOR_FG))
        painter.drawText(QPointF(x + vm.width, sub_y), "\u2192")
        self.approach.draw(painter, x + vm.width + arr_w, sub_y,
                           hits, selected, cursor_id)
        if self.direction:
            painter.setFont(f_sub)
            painter.setPen(QPen(COLOR_FG))
            painter.drawText(QPointF(x + vm.width + arr_w + am.width, sub_y),
                             self.direction)
        self.body.draw(painter, x + sym_w + 6, y, hits, selected, cursor_id)
    def collect_ids(self) -> List[int]:
        return ([self.node_id] + self.body.collect_ids()
                + self.var.collect_ids() + self.approach.collect_ids())
    def to_sympy(self) -> str:
        d = {"+" : "'+'" , "-": "'-'", "": "'+'"}.get(self.direction, "'+'")
        return f"limit({self.body.to_sympy()}, {self.var.to_sympy()}, {self.approach.to_sympy()}, {d})"
    def to_latex(self) -> str:
        sub = self.var.to_latex() + r"\to " + self.approach.to_latex()
        if self.direction:
            sub += "^{" + self.direction + "}"
        return r"\lim_{" + sub + "} " + self.body.to_latex()


class SumProdNode(FormulaNode):
    def __init__(self, kind: str, body: FormulaNode,
                 var: Optional[FormulaNode] = None,
                 lower: Optional[FormulaNode] = None,
                 upper: Optional[FormulaNode] = None):
        super().__init__()
        self.kind = kind
        self.body = body
        self.var = var
        self.lower = lower
        self.upper = upper
        self._sym = "\u03A3" if kind == "sum" else "\u03A0"
    def _sym_dim(self, painter: QPainter) -> Tuple[float, float, float]:
        f = _font(painter, FONT_SIZE_NORMAL + 8, False, True)
        fm = _fm(painter, f)
        w = fm.horizontalAdvance(self._sym) + 4
        return w, fm.ascent(), fm.descent()
    def measure(self, painter: QPainter) -> RenderMetrics:
        bm = self.body.measure(painter)
        sw, sa, sd = self._sym_dim(painter)
        lw = max((self.lower.measure(painter).width if self.lower else 0),
                 (self.upper.measure(painter).width if self.upper else 0))
        sym_w = max(sw, lw)
        return RenderMetrics(sym_w + bm.width + 4,
                             bm.ascent + SUM_EXTRA, bm.descent + SUM_EXTRA)
    def draw(self, painter: QPainter, x: float, y: float,
             hits: List[HitRegion], selected: set, cursor_id: Optional[int]):
        bm = self.body.measure(painter)
        sw, sa, sd = self._sym_dim(painter)
        lw = max((self.lower.measure(painter).width if self.lower else 0),
                 (self.upper.measure(painter).width if self.upper else 0))
        sym_w = max(sw, lw)
        f = _font(painter, FONT_SIZE_NORMAL + 8, False, True)
        painter.setFont(f)
        painter.setPen(QPen(COLOR_FG))
        painter.drawText(QPointF(x + (sym_w - sw) / 2, y), self._sym)
        if self.lower:
            lm = self.lower.measure(painter)
            self.lower.draw(painter, x + (sym_w - lm.width) / 2,
                            y + sd + SUM_EXTRA * 0.6, hits, selected, cursor_id)
        if self.upper:
            um = self.upper.measure(painter)
            self.upper.draw(painter, x + (sym_w - um.width) / 2,
                            y - sa - SUM_EXTRA * 0.3, hits, selected, cursor_id)
        self.body.draw(painter, x + sym_w + 4, y, hits, selected, cursor_id)
    def collect_ids(self) -> List[int]:
        ids = [self.node_id] + self.body.collect_ids()
        if self.var: ids.extend(self.var.collect_ids())
        if self.lower: ids.extend(self.lower.collect_ids())
        if self.upper: ids.extend(self.upper.collect_ids())
        return ids
    def to_sympy(self) -> str:
        b = self.body.to_sympy()
        v = self.var.to_sympy() if self.var else "k"
        fn = "Sum" if self.kind == "sum" else "Product"
        if self.lower and self.upper:
            return f"{fn}({b}, ({v}, {self.lower.to_sympy()}, {self.upper.to_sympy()}))"
        return b
    def to_latex(self) -> str:
        sym = r"\sum" if self.kind == "sum" else r"\prod"
        lim = ""
        if self.lower:
            v = self.var.to_latex() if self.var else "k"
            lim += "_{" + v + "=" + self.lower.to_latex() + "}"
        if self.upper:
            lim += "^{" + self.upper.to_latex() + "}"
        return sym + lim + " " + self.body.to_latex()


class MatrixNode(FormulaNode):
    def __init__(self, rows: List[List[FormulaNode]],
                 left: str = "(", right: str = ")"):
        super().__init__()
        self.rows = rows
        self.left = left
        self.right = right
    def _dims(self, painter: QPainter) -> Tuple[List[float], List[float], List[float]]:
        col_w = [0.0] * (max(len(r) for r in self.rows) if self.rows else 0)
        row_asc = []
        row_desc = []
        for row in self.rows:
            ra, rd = 0.0, 0.0
            for ci, cell in enumerate(row):
                m = cell.measure(painter)
                col_w[ci] = max(col_w[ci], m.width + 12)
                ra = max(ra, m.ascent)
                rd = max(rd, m.descent)
            row_asc.append(ra)
            row_desc.append(rd)
        return col_w, row_asc, row_desc
    def measure(self, painter: QPainter) -> RenderMetrics:
        col_w, row_asc, row_desc = self._dims(painter)
        total_w = sum(col_w) + 8
        total_h = sum(a + d for a, d in zip(row_asc, row_desc)) + 6 * len(self.rows)
        f = _font(painter, FONT_SIZE_NORMAL, False)
        pw = _fm(painter, f).horizontalAdvance("(") * 1.2
        return RenderMetrics(total_w + pw * 2, total_h / 2 + 4, total_h / 2 + 4)
    def draw(self, painter: QPainter, x: float, y: float,
             hits: List[HitRegion], selected: set, cursor_id: Optional[int]):
        col_w, row_asc, row_desc = self._dims(painter)
        m = self.measure(painter)
        f = _font(painter, FONT_SIZE_NORMAL, False)
        fm = _fm(painter, f)
        pw = fm.horizontalAdvance("(") * 1.2
        scale = m.height / (fm.ascent() + fm.descent()) if (fm.ascent() + fm.descent()) > 0 else 1.0
        for bar_x, sym in ((x, self.left), (x + m.width - pw, self.right)):
            painter.save()
            painter.translate(bar_x, y - m.ascent / 2 + m.descent / 2)
            painter.scale(1.0, scale)
            painter.setFont(f)
            painter.setPen(QPen(COLOR_FG))
            painter.drawText(QPointF(0, 0), sym)
            painter.restore()
        cy = y - m.ascent + 4
        for ri, row in enumerate(self.rows):
            cy += row_asc[ri]
            cx = x + pw
            for ci, cell in enumerate(row):
                cell.draw(painter, cx, cy, hits, selected, cursor_id)
                cx += col_w[ci]
            cy += row_desc[ri] + 6
    def collect_ids(self) -> List[int]:
        ids = [self.node_id]
        for row in self.rows:
            for cell in row:
                ids.extend(cell.collect_ids())
        return ids
    def to_latex(self) -> str:
        env = "pmatrix" if self.left == "(" else "bmatrix"
        rows = r" \\ ".join(" & ".join(c.to_latex() for c in row) for row in self.rows)
        return r"\begin{" + env + "}" + rows + r"\end{" + env + "}"
    def to_sympy(self) -> str:
        rows = ", ".join("[" + ", ".join(c.to_sympy() for c in row) + "]" for row in self.rows)
        return f"Matrix([{rows}])"


class OverlineNode(FormulaNode):
    def __init__(self, body: FormulaNode):
        super().__init__()
        self.body = body
    def measure(self, painter: QPainter) -> RenderMetrics:
        bm = self.body.measure(painter)
        return RenderMetrics(bm.width, bm.ascent + 4, bm.descent)
    def draw(self, painter: QPainter, x: float, y: float,
             hits: List[HitRegion], selected: set, cursor_id: Optional[int]):
        bm = self.body.measure(painter)
        self.body.draw(painter, x, y, hits, selected, cursor_id)
        pen = painter.pen()
        painter.setPen(QPen(COLOR_FG, FRAC_BAR_THICK))
        painter.drawLine(QPointF(x, y - bm.ascent - 2),
                         QPointF(x + bm.width, y - bm.ascent - 2))
        painter.setPen(pen)
    def collect_ids(self) -> List[int]:
        return [self.node_id] + self.body.collect_ids()
    def to_latex(self) -> str:
        return r"\overline{" + self.body.to_latex() + "}"
    def to_sympy(self) -> str:
        return f"conjugate({self.body.to_sympy()})"


class UnderlineNode(FormulaNode):
    def __init__(self, body: FormulaNode):
        super().__init__()
        self.body = body
    def measure(self, painter: QPainter) -> RenderMetrics:
        bm = self.body.measure(painter)
        return RenderMetrics(bm.width, bm.ascent, bm.descent + 4)
    def draw(self, painter: QPainter, x: float, y: float,
             hits: List[HitRegion], selected: set, cursor_id: Optional[int]):
        bm = self.body.measure(painter)
        self.body.draw(painter, x, y, hits, selected, cursor_id)
        pen = painter.pen()
        painter.setPen(QPen(COLOR_FG, FRAC_BAR_THICK))
        painter.drawLine(QPointF(x, y + bm.descent + 2),
                         QPointF(x + bm.width, y + bm.descent + 2))
        painter.setPen(pen)
    def collect_ids(self) -> List[int]:
        return [self.node_id] + self.body.collect_ids()
    def to_latex(self) -> str:
        return r"\underline{" + self.body.to_latex() + "}"
    def to_sympy(self) -> str:
        return self.body.to_sympy()
