from __future__ import annotations
import copy
from typing import Optional, List, Dict, Tuple
from ._renderer import (
    FormulaNode, SeqNode, TextNode, PlaceholderNode,
    FracNode, SqrtNode, PowerNode, SubNode, PowerSubNode,
    ParenNode, AbsNode, IntegralNode, SumProdNode, LimitNode,
    MatrixNode, OverlineNode, UnderlineNode,
    FONT_SIZE_NORMAL, FONT_SIZE_SMALL, FONT_SIZE_TINY,
)

GREEK_MAP: Dict[str, str] = {
    "alpha": "\u03B1", "beta": "\u03B2", "gamma": "\u03B3", "delta": "\u03B4",
    "epsilon": "\u03B5", "varepsilon": "\u03B5", "zeta": "\u03B6", "eta": "\u03B7",
    "theta": "\u03B8", "vartheta": "\u03D1", "iota": "\u03B9", "kappa": "\u03BA",
    "lambda": "\u03BB", "mu": "\u03BC", "nu": "\u03BD", "xi": "\u03BE",
    "pi": "\u03C0", "varpi": "\u03D6", "rho": "\u03C1", "varrho": "\u03F1",
    "sigma": "\u03C3", "varsigma": "\u03C2", "tau": "\u03C4", "upsilon": "\u03C5",
    "phi": "\u03C6", "varphi": "\u03D5", "chi": "\u03C7", "psi": "\u03C8",
    "omega": "\u03C9",
    "Alpha": "\u0391", "Beta": "\u0392", "Gamma": "\u0393", "Delta": "\u0394",
    "Epsilon": "\u0395", "Zeta": "\u0396", "Eta": "\u0397", "Theta": "\u0398",
    "Iota": "\u0399", "Kappa": "\u039A", "Lambda": "\u039B", "Mu": "\u039C",
    "Nu": "\u039D", "Xi": "\u039E", "Pi": "\u03A0", "Rho": "\u03A1",
    "Sigma": "\u03A3", "Tau": "\u03A4", "Upsilon": "\u03A5", "Phi": "\u03A6",
    "Chi": "\u03A7", "Psi": "\u03A8", "Omega": "\u03A9",
    "inf": "\u221E", "infty": "\u221E", "partial": "\u2202",
    "nabla": "\u2207", "hbar": "\u210F",
}

OPERATOR_MAP: Dict[str, str] = {
    "+": "+", "-": "\u2212", "*": "\u00B7", "/": "/", "=": "=",
    "!=": "\u2260", "<=": "\u2264", ">=": "\u2265", "<": "<", ">": ">",
    "->": "\u2192", "<-": "\u2190", "<->": "\u2194", "=>": "\u21D2",
    "pm": "\u00B1", "mp": "\u2213", "times": "\u00D7", "div": "\u00F7",
    "cdot": "\u00B7", "approx": "\u2248", "sim": "\u223C", "equiv": "\u2261",
    "propto": "\u221D", "in": "\u2208", "notin": "\u2209",
    "subset": "\u2282", "supset": "\u2283", "cup": "\u222A", "cap": "\u2229",
    "forall": "\u2200", "exists": "\u2203",
    "oplus": "\u2295", "otimes": "\u2297", "circ": "\u2218",
}


def _ph(size: int = FONT_SIZE_NORMAL) -> PlaceholderNode:
    return PlaceholderNode(size)


def _t(text: str, size: int = FONT_SIZE_NORMAL,
       italic: bool = True, bold: bool = False) -> TextNode:
    return TextNode(text, size, italic, bold)


def _op(text: str) -> TextNode:
    return TextNode(text, FONT_SIZE_NORMAL, False)


def _seq(*nodes: FormulaNode) -> SeqNode:
    return SeqNode(list(nodes))


class FormulaModel:
    MAX_HISTORY = 120
    def __init__(self):
        self._root: FormulaNode = _seq(_ph())
        self._cursor_id: Optional[int] = self._root.collect_ids()[1]
        self._selected: set = set()
        self._history: List[FormulaNode] = []
        self._redo: List[FormulaNode] = []
    @property
    def root(self) -> FormulaNode:
        return self._root
    @property
    def cursor_id(self) -> Optional[int]:
        return self._cursor_id
    @property
    def selected_ids(self) -> set:
        return self._selected
    def _save(self):
        self._history.append(copy.deepcopy(self._root))
        self._redo.clear()
        if len(self._history) > self.MAX_HISTORY:
            self._history.pop(0)
    def _ids(self) -> List[int]:
        return self._root.collect_ids()
    def _find_seq(self, root: FormulaNode, target: int
                  ) -> Optional[Tuple[SeqNode, int]]:
        if isinstance(root, SeqNode):
            for i, c in enumerate(root.children):
                if c.node_id == target:
                    return root, i
                r = self._find_seq(c, target)
                if r:
                    return r
        for attr in ("num", "den", "body", "base", "exp", "sub",
                     "var", "lower", "upper", "index", "approach"):
            child = getattr(root, attr, None)
            if child is None:
                continue
            if child.node_id == target:
                wrap = SeqNode([child])
                return wrap, 0
            r = self._find_seq(child, target)
            if r:
                return r
        if hasattr(root, "rows"):
            for row in root.rows:
                for cell in row:
                    if cell.node_id == target:
                        wrap = SeqNode([cell])
                        return wrap, 0
                    r = self._find_seq(cell, target)
                    if r:
                        return r
        return None
    def _cursor_seq(self) -> Optional[Tuple[SeqNode, int]]:
        if self._cursor_id is None:
            return None
        return self._find_seq(self._root, self._cursor_id)
    def undo(self):
        if not self._history:
            return
        self._redo.append(copy.deepcopy(self._root))
        self._root = self._history.pop()
        ids = self._ids()
        self._cursor_id = ids[0] if ids else None
        self._selected.clear()
    def redo(self):
        if not self._redo:
            return
        self._history.append(copy.deepcopy(self._root))
        self._root = self._redo.pop()
        ids = self._ids()
        self._cursor_id = ids[0] if ids else None
        self._selected.clear()
    def can_undo(self) -> bool:
        return bool(self._history)
    def can_redo(self) -> bool:
        return bool(self._redo)
    def move_left(self):
        ids = self._ids()
        if self._cursor_id not in ids:
            return
        idx = ids.index(self._cursor_id)
        if idx > 0:
            self._cursor_id = ids[idx - 1]
    def move_right(self):
        ids = self._ids()
        if self._cursor_id not in ids:
            return
        idx = ids.index(self._cursor_id)
        if idx < len(ids) - 1:
            self._cursor_id = ids[idx + 1]
    def set_cursor(self, node_id: int):
        if node_id in self._ids():
            self._cursor_id = node_id
    def insert_node(self, node: FormulaNode):
        self._save()
        res = self._cursor_seq()
        if res is None:
            return
        seq, idx = res
        if isinstance(seq.children[idx], PlaceholderNode):
            seq.children[idx] = node
            ids = node.collect_ids()
            self._cursor_id = ids[-1]
        else:
            seq.children.insert(idx + 1, node)
            ids = node.collect_ids()
            self._cursor_id = ids[-1]
    def insert_text(self, text: str, italic: bool = True):
        self.insert_node(_t(text, FONT_SIZE_NORMAL, italic))
    def insert_operator(self, op: str):
        sym = OPERATOR_MAP.get(op, op)
        self.insert_node(_op(sym))
    def insert_greek(self, name: str):
        sym = GREEK_MAP.get(name, name)
        self.insert_node(_t(sym, FONT_SIZE_NORMAL, True))
    def insert_frac(self):
        self._save()
        res = self._cursor_seq()
        if res is None:
            return
        seq, idx = res
        n, d = _ph(), _ph()
        node = FracNode(_seq(n), _seq(d))
        seq.children.insert(idx + 1, node)
        self._cursor_id = n.node_id
    def insert_sqrt(self, nth: bool = False):
        self._save()
        res = self._cursor_seq()
        if res is None:
            return
        seq, idx = res
        b = _ph()
        idx_node = _ph(FONT_SIZE_TINY) if nth else None
        node = SqrtNode(_seq(b), _seq(idx_node) if idx_node else None)
        seq.children.insert(idx + 1, node)
        self._cursor_id = b.node_id
    def insert_power(self, wrap_current: bool = True):
        self._save()
        res = self._cursor_seq()
        if res is None:
            return
        seq, idx = res
        e = _ph(FONT_SIZE_SMALL)
        base = seq.children[idx] if (wrap_current and not isinstance(seq.children[idx], PlaceholderNode)) else _ph()
        node = PowerNode(base if wrap_current else _ph(), _seq(e))
        if wrap_current and not isinstance(seq.children[idx], PlaceholderNode):
            seq.children[idx] = node
        else:
            seq.children.insert(idx + 1, node)
        self._cursor_id = e.node_id
    def insert_subscript(self, wrap_current: bool = True):
        self._save()
        res = self._cursor_seq()
        if res is None:
            return
        seq, idx = res
        s = _ph(FONT_SIZE_SMALL)
        base = seq.children[idx]
        if wrap_current and not isinstance(base, PlaceholderNode):
            node = SubNode(base, _seq(s))
            seq.children[idx] = node
        else:
            node = SubNode(_ph(), _seq(s))
            seq.children.insert(idx + 1, node)
        self._cursor_id = s.node_id
    def insert_power_sub(self):
        self._save()
        res = self._cursor_seq()
        if res is None:
            return
        seq, idx = res
        e, s = _ph(FONT_SIZE_SMALL), _ph(FONT_SIZE_SMALL)
        base = seq.children[idx]
        if not isinstance(base, PlaceholderNode):
            node = PowerSubNode(base, _seq(e), _seq(s))
            seq.children[idx] = node
        else:
            node = PowerSubNode(_ph(), _seq(e), _seq(s))
            seq.children.insert(idx + 1, node)
        self._cursor_id = e.node_id
    def insert_parens(self, left: str = "(", right: str = ")"):
        self._save()
        res = self._cursor_seq()
        if res is None:
            return
        seq, idx = res
        b = _ph()
        node = ParenNode(_seq(b), left, right)
        seq.children.insert(idx + 1, node)
        self._cursor_id = b.node_id
    def insert_abs(self):
        self._save()
        res = self._cursor_seq()
        if res is None:
            return
        seq, idx = res
        b = _ph()
        node = AbsNode(_seq(b))
        seq.children.insert(idx + 1, node)
        self._cursor_id = b.node_id
    def insert_integral(self, definite: bool = True):
        self._save()
        res = self._cursor_seq()
        if res is None:
            return
        seq, idx = res
        b, v = _ph(), _ph(FONT_SIZE_SMALL)
        lo = _ph(FONT_SIZE_TINY) if definite else None
        hi = _ph(FONT_SIZE_TINY) if definite else None
        node = IntegralNode(_seq(b), _seq(v),
                            _seq(lo) if lo else None,
                            _seq(hi) if hi else None)
        seq.children.insert(idx + 1, node)
        self._cursor_id = b.node_id
    def insert_sum(self, with_limits: bool = True):
        self._save()
        res = self._cursor_seq()
        if res is None:
            return
        seq, idx = res
        b = _ph()
        var = _t("k", FONT_SIZE_SMALL)
        lo = _ph(FONT_SIZE_TINY) if with_limits else None
        hi = _ph(FONT_SIZE_TINY) if with_limits else None
        node = SumProdNode("sum", _seq(b), _seq(var),
                           _seq(lo) if lo else None,
                           _seq(hi) if hi else None)
        seq.children.insert(idx + 1, node)
        self._cursor_id = b.node_id
    def insert_product(self, with_limits: bool = True):
        self._save()
        res = self._cursor_seq()
        if res is None:
            return
        seq, idx = res
        b = _ph()
        var = _t("k", FONT_SIZE_SMALL)
        lo = _ph(FONT_SIZE_TINY) if with_limits else None
        hi = _ph(FONT_SIZE_TINY) if with_limits else None
        node = SumProdNode("prod", _seq(b), _seq(var),
                           _seq(lo) if lo else None,
                           _seq(hi) if hi else None)
        seq.children.insert(idx + 1, node)
        self._cursor_id = b.node_id
    def insert_limit(self):
        self._save()
        res = self._cursor_seq()
        if res is None:
            return
        seq, idx = res
        b = _ph()
        v = _t("x", FONT_SIZE_TINY)
        a = _ph(FONT_SIZE_TINY)
        node = LimitNode(_seq(b), _seq(v), _seq(a))
        seq.children.insert(idx + 1, node)
        self._cursor_id = b.node_id
    def insert_matrix(self, rows: int = 2, cols: int = 2,
                      bracket: str = "("):
        self._save()
        res = self._cursor_seq()
        if res is None:
            return
        seq, idx = res
        right = {"(": ")", "[": "]", "|": "|", "{": "}"}.get(bracket, ")")
        grid = [[_ph() for _ in range(cols)] for _ in range(rows)]
        node = MatrixNode(grid, bracket, right)
        seq.children.insert(idx + 1, node)
        self._cursor_id = grid[0][0].node_id
    def insert_overline(self):
        self._save()
        res = self._cursor_seq()
        if res is None:
            return
        seq, idx = res
        b = _ph()
        node = OverlineNode(_seq(b))
        seq.children.insert(idx + 1, node)
        self._cursor_id = b.node_id
    def insert_underline(self):
        self._save()
        res = self._cursor_seq()
        if res is None:
            return
        seq, idx = res
        b = _ph()
        node = UnderlineNode(_seq(b))
        seq.children.insert(idx + 1, node)
        self._cursor_id = b.node_id
    def insert_func(self, name: str):
        self._save()
        res = self._cursor_seq()
        if res is None:
            return
        seq, idx = res
        fn = TextNode(name, FONT_SIZE_NORMAL, False)
        b = _ph()
        paren = ParenNode(_seq(b))
        seq.children.insert(idx + 1, fn)
        seq.children.insert(idx + 2, paren)
        self._cursor_id = b.node_id
    def delete_at_cursor(self):
        self._save()
        res = self._cursor_seq()
        if res is None:
            return
        seq, idx = res
        if isinstance(seq.children[idx], PlaceholderNode):
            if len(seq.children) > 1:
                seq.children.pop(idx)
                self._cursor_id = seq.children[max(0, idx - 1)].node_id
            return
        if idx > 0:
            seq.children.pop(idx)
            self._cursor_id = seq.children[idx - 1].node_id
        elif len(seq.children) > 1:
            seq.children.pop(idx)
            self._cursor_id = seq.children[0].node_id
        else:
            seq.children[0] = _ph()
            self._cursor_id = seq.children[0].node_id
    def clear(self):
        self._save()
        ph = _ph()
        self._root = _seq(ph)
        self._cursor_id = ph.node_id
        self._selected.clear()
    def to_sympy(self) -> str:
        return self._root.to_sympy()
    def to_latex(self) -> str:
        return self._root.to_latex()
    def to_text(self) -> str:
        return self._root.to_text()
    def set_from_text(self, text: str):
        self.clear()
        for ch in text:
            if ch.isprintable():
                self.insert_text(ch, italic=False)
