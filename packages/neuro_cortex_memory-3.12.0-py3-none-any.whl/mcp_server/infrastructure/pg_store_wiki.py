"""Wiki schema DB operations (Phase 1 of redesign).

Upserts and queries over wiki.pages / wiki.concepts / wiki.claim_events /
wiki.drafts / wiki.links / wiki.citations / wiki.memos.

Files on disk remain the source of truth for wiki.pages; this module
maintains the query index. All writes are idempotent (UPSERT by rel_path
or body_hash). Triggers on wiki.links and wiki.citations maintain the
denormalised counters on wiki.pages.

Pure infrastructure — no core imports, no handler imports.
"""

from __future__ import annotations

import hashlib
import json
from typing import Any

from psycopg import Connection
from psycopg.rows import dict_row


# ── Hashing helper ─────────────────────────────────────────────────────


def body_hash(body: str) -> str:
    """Deterministic hash of a page body — drives idempotent upserts."""
    return hashlib.sha256(body.encode("utf-8")).hexdigest()


# ── wiki.pages ─────────────────────────────────────────────────────────


def upsert_page(conn: Connection, page: dict[str, Any]) -> tuple[int, bool]:
    """Upsert a page row by rel_path.

    Returns ``(page_id, was_modified)`` where ``was_modified`` is True
    when the row was inserted or actually updated, False when the
    body_hash matched and nothing changed.

    Required fields: rel_path, slug, kind, title.
    Optional: all other columns.
    """
    required = ("rel_path", "slug", "kind", "title")
    for k in required:
        if k not in page:
            raise ValueError(f"upsert_page missing required field: {k}")

    body = page.get("body", "")
    bh = page.get("body_hash") or body_hash(body)

    # Use xmax=0 (Postgres trick) to detect INSERT vs UPDATE: xmax is 0
    # only on a fresh INSERT. We also OR in body_hash equality to detect
    # no-op updates that the WHERE clause filtered out.
    sql = """
    INSERT INTO wiki.pages (
        memory_id, concept_id, rel_path, slug, kind, title, domain, domains,
        tags, audience, requires, status, lifecycle_state, supersedes,
        superseded_by, verified, lead, sections, body_hash
    ) VALUES (
        %(memory_id)s, %(concept_id)s, %(rel_path)s, %(slug)s, %(kind)s,
        %(title)s, %(domain)s, %(domains)s::jsonb, %(tags)s::jsonb,
        %(audience)s::jsonb, %(requires)s::jsonb, %(status)s,
        %(lifecycle_state)s, %(supersedes)s, %(superseded_by)s, %(verified)s,
        %(lead)s, %(sections)s::jsonb, %(body_hash)s
    )
    ON CONFLICT (rel_path) DO UPDATE SET
        memory_id = EXCLUDED.memory_id,
        concept_id = EXCLUDED.concept_id,
        slug = EXCLUDED.slug,
        kind = EXCLUDED.kind,
        title = EXCLUDED.title,
        domain = EXCLUDED.domain,
        domains = EXCLUDED.domains,
        tags = EXCLUDED.tags,
        audience = EXCLUDED.audience,
        requires = EXCLUDED.requires,
        status = EXCLUDED.status,
        lifecycle_state = EXCLUDED.lifecycle_state,
        supersedes = EXCLUDED.supersedes,
        superseded_by = EXCLUDED.superseded_by,
        verified = EXCLUDED.verified,
        lead = EXCLUDED.lead,
        sections = EXCLUDED.sections,
        body_hash = EXCLUDED.body_hash,
        tended = NOW()
    WHERE wiki.pages.body_hash <> EXCLUDED.body_hash
    RETURNING id, (xmax = 0) AS inserted;
    """
    params = {
        "memory_id": page.get("memory_id"),
        "concept_id": page.get("concept_id"),
        "rel_path": page["rel_path"],
        "slug": page["slug"],
        "kind": page["kind"],
        "title": page["title"],
        "domain": page.get("domain", ""),
        "domains": json.dumps(page.get("domains", [])),
        "tags": json.dumps(page.get("tags", [])),
        "audience": json.dumps(page.get("audience", [])),
        "requires": json.dumps(page.get("requires", [])),
        "status": page.get("status", "seedling"),
        "lifecycle_state": page.get("lifecycle_state", "active"),
        "supersedes": page.get("supersedes"),
        "superseded_by": page.get("superseded_by"),
        "verified": page.get("verified"),
        "lead": page.get("lead", ""),
        "sections": json.dumps(page.get("sections", {})),
        "body_hash": bh,
    }
    with conn.cursor() as cur:
        cur.execute(sql, params)
        row = cur.fetchone()
        if row is not None:
            # Row was inserted or actually updated.
            if isinstance(row, dict):
                return row["id"], True
            return row[0], True
        # WHERE clause filtered the UPDATE out → body_hash matched, no-op.
        cur.execute(
            "SELECT id FROM wiki.pages WHERE rel_path = %s", (page["rel_path"],)
        )
        existing = cur.fetchone()
        if existing is None:
            return -1, False
        existing_id = existing["id"] if isinstance(existing, dict) else existing[0]
        return existing_id, False


def get_page_by_slug(conn: Connection, slug: str) -> dict | None:
    """Return a page row by slug, or None."""
    with conn.cursor(row_factory=dict_row) as cur:
        cur.execute("SELECT * FROM wiki.pages WHERE slug = %s LIMIT 1", (slug,))
        return cur.fetchone()


def get_page_by_rel_path(conn: Connection, rel_path: str) -> dict | None:
    """Return a page row by rel_path, or None."""
    with conn.cursor(row_factory=dict_row) as cur:
        cur.execute("SELECT * FROM wiki.pages WHERE rel_path = %s LIMIT 1", (rel_path,))
        return cur.fetchone()


# ── wiki.links ─────────────────────────────────────────────────────────


def upsert_link(
    conn: Connection,
    src_page_id: int,
    dst_slug: str,
    link_kind: str = "see-also",
    dst_page_id: int | None = None,
) -> None:
    """Insert a link, resolving dst_page_id by slug if not provided.

    ON CONFLICT DO UPDATE lets a stale dst_page_id be refreshed when
    the target page appears later.
    """
    if dst_page_id is None:
        p = get_page_by_slug(conn, dst_slug)
        dst_page_id = p["id"] if p else None

    sql = """
    INSERT INTO wiki.links (src_page_id, dst_slug, dst_page_id, link_kind)
    VALUES (%s, %s, %s, %s)
    ON CONFLICT (src_page_id, dst_slug, link_kind) DO UPDATE SET
        dst_page_id = EXCLUDED.dst_page_id
    WHERE wiki.links.dst_page_id IS DISTINCT FROM EXCLUDED.dst_page_id;
    """
    with conn.cursor() as cur:
        cur.execute(sql, (src_page_id, dst_slug, dst_page_id, link_kind))


def delete_links_from(conn: Connection, src_page_id: int) -> int:
    """Remove all outgoing links from a page (used before re-indexing)."""
    with conn.cursor() as cur:
        cur.execute("DELETE FROM wiki.links WHERE src_page_id = %s", (src_page_id,))
        return cur.rowcount


def get_backlinks(conn: Connection, dst_page_id: int) -> list[dict]:
    """Return rows linking TO this page."""
    with conn.cursor(row_factory=dict_row) as cur:
        cur.execute(
            """
            SELECT l.*, p.title AS src_title, p.rel_path AS src_rel_path
              FROM wiki.links l
              JOIN wiki.pages p ON p.id = l.src_page_id
             WHERE l.dst_page_id = %s
            """,
            (dst_page_id,),
        )
        return list(cur.fetchall())


def resolve_unresolved_links(conn: Connection) -> int:
    """Second-pass link resolution: fill in dst_page_id for links whose
    target didn't exist at insert time. Returns rows updated."""
    with conn.cursor() as cur:
        cur.execute(
            """
            UPDATE wiki.links l
               SET dst_page_id = p.id
              FROM wiki.pages p
             WHERE p.slug = l.dst_slug
               AND l.dst_page_id IS NULL
            """
        )
        return cur.rowcount


# ── wiki.claim_events ──────────────────────────────────────────────────


def insert_claim_events(conn: Connection, claims: list[dict]) -> list[int]:
    """Bulk insert ClaimEvent rows. Returns the new ids in order.

    Each ``claims`` dict requires: ``text``, ``claim_type``. Optional:
    memory_id, session_id, entity_ids, evidence_refs, confidence,
    supersedes, embedding (vector or None).

    All inserted in one cursor cycle for throughput.
    """
    if not claims:
        return []

    sql = """
    INSERT INTO wiki.claim_events (
        memory_id, session_id, text, claim_type, entity_ids,
        evidence_refs, confidence, supersedes
    ) VALUES (
        %(memory_id)s, %(session_id)s, %(text)s, %(claim_type)s,
        %(entity_ids)s, %(evidence_refs)s::jsonb, %(confidence)s,
        %(supersedes)s
    ) RETURNING id;
    """
    out: list[int] = []
    with conn.cursor() as cur:
        for c in claims:
            params = {
                "memory_id": c.get("memory_id"),
                "session_id": c.get("session_id", ""),
                "text": c["text"][:1900],
                "claim_type": c.get("claim_type", "assertion"),
                "entity_ids": c.get("entity_ids", []),
                "evidence_refs": json.dumps(c.get("evidence_refs", [])),
                "confidence": c.get("confidence", 0.5),
                "supersedes": c.get("supersedes"),
            }
            cur.execute(sql, params)
            row = cur.fetchone()
            out.append(row["id"] if isinstance(row, dict) else row[0])
    return out


def delete_claims_for_memory(conn: Connection, memory_id: int) -> int:
    """Remove all claim_events derived from a single memory.

    Used before re-extraction to keep the table clean of stale claims.
    """
    with conn.cursor() as cur:
        cur.execute("DELETE FROM wiki.claim_events WHERE memory_id = %s", (memory_id,))
        return cur.rowcount


def get_claims_for_memory(conn: Connection, memory_id: int) -> list[dict]:
    """Return all claim_events derived from a single memory."""
    with conn.cursor(row_factory=dict_row) as cur:
        cur.execute(
            "SELECT * FROM wiki.claim_events WHERE memory_id = %s ORDER BY id",
            (memory_id,),
        )
        return list(cur.fetchall())


def get_entities_by_memory(
    conn: Connection, memory_ids: list[int]
) -> dict[int, list[int]]:
    """Pre-fetch memory_id → list[entity_id] for a batch of memories."""
    if not memory_ids:
        return {}
    with conn.cursor() as cur:
        cur.execute(
            "SELECT memory_id, entity_id FROM memory_entities "
            "WHERE memory_id = ANY(%s)",
            (list(memory_ids),),
        )
        rows = cur.fetchall()
    out: dict[int, list[int]] = {}
    for r in rows:
        if isinstance(r, dict):
            mid, eid = r["memory_id"], r["entity_id"]
        else:
            mid, eid = r[0], r[1]
        out.setdefault(mid, []).append(eid)
    return out


def get_entity_name_index(conn: Connection, limit: int = 5000) -> dict[str, int]:
    """Return name → entity_id map for inline-mention matching.

    Limit caps the index size for in-memory matching against claim text.
    Heat-ranked so the most frequently-touched entities win.
    """
    with conn.cursor() as cur:
        cur.execute(
            "SELECT name, id FROM entities ORDER BY heat DESC NULLS LAST LIMIT %s",
            (limit,),
        )
        rows = cur.fetchall()
    out: dict[str, int] = {}
    for r in rows:
        if isinstance(r, dict):
            name, eid = r["name"], r["id"]
        else:
            name, eid = r[0], r[1]
        if name and len(name) >= 3:
            out[name] = eid
    return out


def get_claims_by_entity(
    conn: Connection,
    entity_ids: list[int],
    exclude_claim_ids: list[int] | None = None,
) -> dict[int, list[dict]]:
    """For each entity_id, fetch claims that already reference it.

    Used by the resolver to find supersedes / conflict candidates.
    Excludes the claims being resolved (avoid self-matches).
    """
    if not entity_ids:
        return {}
    excl = exclude_claim_ids or []
    with conn.cursor(row_factory=dict_row) as cur:
        cur.execute(
            """
            SELECT id, memory_id, text, claim_type, entity_ids, supersedes,
                   extracted_at
              FROM wiki.claim_events
             WHERE entity_ids && %s::int[]
               AND (%s::bigint[] IS NULL OR NOT (id = ANY(%s::bigint[])))
            """,
            (list(entity_ids), excl or None, excl or None),
        )
        rows = list(cur.fetchall())
    out: dict[int, list[dict]] = {}
    for r in rows:
        # entity_ids returns as a list already (PG INT[] → Python list)
        for eid in r.get("entity_ids") or []:
            if eid in entity_ids:
                out.setdefault(eid, []).append(r)
    return out


def update_claim_entities(
    conn: Connection, updates: list[tuple[int, list[int]]]
) -> int:
    """Bulk update wiki.claim_events.entity_ids. Returns rows updated.

    Idempotent: only writes when the new list differs from the current.
    """
    if not updates:
        return 0
    written = 0
    with conn.cursor() as cur:
        for claim_id, eids in updates:
            cur.execute(
                """
                UPDATE wiki.claim_events
                   SET entity_ids = %s::int[]
                 WHERE id = %s
                   AND entity_ids IS DISTINCT FROM %s::int[]
                """,
                (eids, claim_id, eids),
            )
            written += cur.rowcount
    return written


def update_claim_supersedes(conn: Connection, updates: list[tuple[int, int]]) -> int:
    """Bulk update wiki.claim_events.supersedes. Returns rows updated.

    ``updates`` is [(new_claim_id, superseded_claim_id), ...].
    """
    if not updates:
        return 0
    written = 0
    with conn.cursor() as cur:
        for new_id, sup_id in updates:
            cur.execute(
                """
                UPDATE wiki.claim_events
                   SET supersedes = %s
                 WHERE id = %s
                   AND (supersedes IS NULL OR supersedes <> %s)
                """,
                (sup_id, new_id, sup_id),
            )
            written += cur.rowcount
    return written


# ── wiki.pages — bulk thermodynamic updates ───────────────────────────


def list_pages_for_decay(
    conn: Connection,
    *,
    limit: int = 5000,
    include_archived: bool = False,
) -> list[dict]:
    """Pages eligible for a thermodynamic sweep.

    Skips evergreen by default (never decays) and archived unless
    ``include_archived`` is True (only useful to detect revivals,
    which we handle via the citation trigger anyway).
    """
    states = ["active", "area"]
    if include_archived:
        states.append("archived")
    sql = """
    SELECT id, heat, lifecycle_state, tended, is_stale, lead, sections
      FROM wiki.pages
     WHERE lifecycle_state = ANY(%s)
     ORDER BY id LIMIT %s
    """
    with conn.cursor(row_factory=dict_row) as cur:
        cur.execute(sql, (states, limit))
        return list(cur.fetchall())


def apply_thermo_decisions(conn: Connection, decisions: list[Any]) -> int:
    """Bulk apply HeatDecision rows. Returns count of pages written.

    Idempotent — UPDATE only fires when at least one of (heat,
    lifecycle_state, archived_at) differs from current.
    """
    if not decisions:
        return 0
    written = 0
    with conn.cursor() as cur:
        for d in decisions:
            cur.execute(
                """
                UPDATE wiki.pages
                   SET heat = %s,
                       lifecycle_state = %s,
                       archived_at = COALESCE(%s::timestamptz, archived_at),
                       tended = NOW()
                 WHERE id = %s
                   AND (
                     ABS(heat - %s) > 0.001
                     OR lifecycle_state <> %s
                     OR (%s::timestamptz IS NOT NULL AND archived_at IS NULL)
                   )
                """,
                (
                    d.new_heat,
                    d.new_lifecycle,
                    d.archived_at,
                    d.page_id,
                    d.new_heat,
                    d.new_lifecycle,
                    d.archived_at,
                ),
            )
            written += cur.rowcount
    return written


def apply_staleness_decisions(conn: Connection, decisions: list[Any]) -> int:
    """Bulk apply StalenessDecision rows. Returns transitions written."""
    if not decisions:
        return 0
    written = 0
    with conn.cursor() as cur:
        for d in decisions:
            if not d.transitioned:
                continue
            cur.execute(
                "UPDATE wiki.pages SET is_stale = %s WHERE id = %s",
                (d.is_stale_now, d.page_id),
            )
            written += cur.rowcount
    return written


def get_claim_file_refs_for_pages(
    conn: Connection, page_ids: list[int]
) -> dict[int, list[str]]:
    """For each page, return the file paths cited by its source memory's claims.

    Joins wiki.pages → memories → wiki.claim_events; pulls evidence_refs
    of kind='file'. Returns {page_id: [file_path, ...]}.
    """
    if not page_ids:
        return {}
    sql = """
    SELECT p.id AS page_id,
           c.evidence_refs
      FROM wiki.pages p
      JOIN wiki.claim_events c ON c.memory_id = p.memory_id
     WHERE p.id = ANY(%s)
    """
    out: dict[int, set[str]] = {}
    with conn.cursor(row_factory=dict_row) as cur:
        cur.execute(sql, (list(page_ids),))
        for row in cur.fetchall():
            page_id = row["page_id"]
            refs = row["evidence_refs"] or []
            for ref in refs:
                if isinstance(ref, dict) and ref.get("kind") == "file":
                    out.setdefault(page_id, set()).add(ref["target"])
    return {k: sorted(v) for k, v in out.items()}


# ── wiki.concepts ──────────────────────────────────────────────────────


def list_concepts(
    conn: Connection,
    *,
    status: str | None = None,
    limit: int = 200,
) -> list[dict]:
    """Return concept rows, optionally filtered by status."""
    if status:
        sql = "SELECT * FROM wiki.concepts WHERE status = %s ORDER BY id LIMIT %s"
        params: tuple = (status, limit)
    else:
        sql = "SELECT * FROM wiki.concepts ORDER BY id LIMIT %s"
        params = (limit,)
    with conn.cursor(row_factory=dict_row) as cur:
        cur.execute(sql, params)
        return list(cur.fetchall())


def get_concepts_by_entity_overlap(
    conn: Connection, entity_ids: list[int]
) -> list[dict]:
    """Return concepts whose entity_ids intersect the given list."""
    if not entity_ids:
        return []
    with conn.cursor(row_factory=dict_row) as cur:
        cur.execute(
            "SELECT * FROM wiki.concepts WHERE entity_ids && %s::int[]",
            (list(entity_ids),),
        )
        return list(cur.fetchall())


def insert_concept(conn: Connection, concept: dict[str, Any]) -> int:
    """Insert a new concept. Returns wiki.concepts.id."""
    sql = """
    INSERT INTO wiki.concepts (
        label, status, entity_ids, grounding_memory_ids,
        grounding_claim_ids, properties, axial_slots,
        saturation_rate, saturation_streak
    ) VALUES (
        %(label)s, %(status)s, %(entity_ids)s::int[],
        %(grounding_memory_ids)s::int[], %(grounding_claim_ids)s::bigint[],
        %(properties)s::jsonb, %(axial_slots)s::jsonb,
        %(saturation_rate)s, %(saturation_streak)s
    ) RETURNING id;
    """
    params = {
        "label": concept["label"],
        "status": concept.get("status", "candidate"),
        "entity_ids": concept.get("entity_ids", []),
        "grounding_memory_ids": concept.get("grounding_memory_ids", []),
        "grounding_claim_ids": concept.get("grounding_claim_ids", []),
        "properties": json.dumps(concept.get("properties", {})),
        "axial_slots": json.dumps(concept.get("axial_slots", {})),
        "saturation_rate": float(concept.get("saturation_rate", 1.0)),
        "saturation_streak": int(concept.get("saturation_streak", 0)),
    }
    with conn.cursor() as cur:
        cur.execute(sql, params)
        row = cur.fetchone()
        return row["id"] if isinstance(row, dict) else row[0]


def update_concept(conn: Connection, concept_id: int, fields: dict[str, Any]) -> bool:
    """Patch a concept row. Returns True if updated."""
    if not fields:
        return False
    sets: list[str] = []
    params: list = []
    for k, v in fields.items():
        if k in ("entity_ids", "grounding_memory_ids"):
            sets.append(f"{k} = %s::int[]")
            params.append(v)
        elif k == "grounding_claim_ids":
            sets.append(f"{k} = %s::bigint[]")
            params.append(v)
        elif k in ("properties", "axial_slots"):
            sets.append(f"{k} = %s::jsonb")
            params.append(json.dumps(v))
        elif k == "last_property_at":
            sets.append(f"{k} = NOW()")
        else:
            sets.append(f"{k} = %s")
            params.append(v)
    params.append(concept_id)
    sql = f"UPDATE wiki.concepts SET {', '.join(sets)} WHERE id = %s"
    with conn.cursor() as cur:
        cur.execute(sql, params)
        return cur.rowcount > 0


# ── wiki.drafts ────────────────────────────────────────────────────────


def insert_draft(conn: Connection, draft: dict[str, Any]) -> int:
    """Insert a draft row. Returns the new wiki.drafts.id.

    Required: title, kind. Optional: concept_id, memory_id, lead,
    sections (list of dicts), frontmatter, provenance, synth_prompt,
    synth_model, confidence, status.
    """
    sql = """
    INSERT INTO wiki.drafts (
        concept_id, memory_id, title, kind, lead, sections,
        frontmatter, provenance, synth_prompt, synth_model,
        confidence, status
    ) VALUES (
        %(concept_id)s, %(memory_id)s, %(title)s, %(kind)s, %(lead)s,
        %(sections)s::jsonb, %(frontmatter)s::jsonb,
        %(provenance)s::jsonb, %(synth_prompt)s, %(synth_model)s,
        %(confidence)s, %(status)s
    ) RETURNING id;
    """
    params = {
        "concept_id": draft.get("concept_id"),
        "memory_id": draft.get("memory_id"),
        "title": draft["title"],
        "kind": draft["kind"],
        "lead": draft.get("lead", ""),
        "sections": json.dumps(draft.get("sections", [])),
        "frontmatter": json.dumps(draft.get("frontmatter", {})),
        "provenance": json.dumps(draft.get("provenance", {})),
        "synth_prompt": draft.get("synth_prompt"),
        "synth_model": draft.get("synth_model"),
        "confidence": float(draft.get("confidence", 0.5)),
        "status": draft.get("status", "pending"),
    }
    with conn.cursor() as cur:
        cur.execute(sql, params)
        row = cur.fetchone()
        return row["id"] if isinstance(row, dict) else row[0]


def get_draft(conn: Connection, draft_id: int) -> dict | None:
    with conn.cursor(row_factory=dict_row) as cur:
        cur.execute("SELECT * FROM wiki.drafts WHERE id = %s", (draft_id,))
        return cur.fetchone()


def list_drafts(
    conn: Connection,
    *,
    status: str | None = None,
    kind: str | None = None,
    limit: int = 50,
) -> list[dict]:
    where: list[str] = []
    params: list = []
    if status:
        where.append("status = %s")
        params.append(status)
    if kind:
        where.append("kind = %s")
        params.append(kind)
    where_sql = ("WHERE " + " AND ".join(where)) if where else ""
    sql = f"""
    SELECT * FROM wiki.drafts {where_sql}
    ORDER BY created_at DESC LIMIT %s
    """
    params.append(limit)
    with conn.cursor(row_factory=dict_row) as cur:
        cur.execute(sql, params)
        return list(cur.fetchall())


def update_draft(
    conn: Connection,
    draft_id: int,
    *,
    title: str | None = None,
    lead: str | None = None,
    sections: list | None = None,
    frontmatter: dict | None = None,
    confidence: float | None = None,
    synth_prompt: str | None = None,
    synth_model: str | None = None,
) -> bool:
    """Patch a draft's content fields. Returns True if a row was updated.

    Used by Path B (LLM refinement) — Claude submits a refined draft
    by updating the in-DB record. Status transitions go through
    update_draft_status.
    """
    sets: list[str] = []
    params: list = []
    if title is not None:
        sets.append("title = %s")
        params.append(title)
    if lead is not None:
        sets.append("lead = %s")
        params.append(lead)
    if sections is not None:
        sets.append("sections = %s::jsonb")
        params.append(json.dumps(sections))
    if frontmatter is not None:
        sets.append("frontmatter = %s::jsonb")
        params.append(json.dumps(frontmatter))
    if confidence is not None:
        sets.append("confidence = %s")
        params.append(float(confidence))
    if synth_prompt is not None:
        sets.append("synth_prompt = %s")
        params.append(synth_prompt)
    if synth_model is not None:
        sets.append("synth_model = %s")
        params.append(synth_model)
    if not sets:
        return False
    params.append(draft_id)
    sql = f"UPDATE wiki.drafts SET {', '.join(sets)} WHERE id = %s"
    with conn.cursor() as cur:
        cur.execute(sql, params)
        return cur.rowcount > 0


def update_draft_status(
    conn: Connection,
    draft_id: int,
    *,
    status: str,
    published_page_id: int | None = None,
) -> bool:
    """Transition a draft's status. Stamps reviewed_at automatically."""
    if status not in ("pending", "approved", "rejected", "published"):
        raise ValueError(f"invalid status: {status}")
    with conn.cursor() as cur:
        cur.execute(
            """
            UPDATE wiki.drafts
               SET status = %s,
                   published_page_id = COALESCE(%s, published_page_id),
                   reviewed_at = NOW()
             WHERE id = %s
            """,
            (status, published_page_id, draft_id),
        )
        return cur.rowcount > 0


def find_draft_for_source(
    conn: Connection, *, memory_id: int | None = None, concept_id: int | None = None
) -> dict | None:
    """Return the most recent draft for a given source, or None."""
    if not memory_id and not concept_id:
        return None
    if memory_id is not None:
        sql = (
            "SELECT * FROM wiki.drafts WHERE memory_id = %s "
            "ORDER BY created_at DESC LIMIT 1"
        )
        params: tuple = (memory_id,)
    else:
        sql = (
            "SELECT * FROM wiki.drafts WHERE concept_id = %s "
            "ORDER BY created_at DESC LIMIT 1"
        )
        params = (concept_id,)
    with conn.cursor(row_factory=dict_row) as cur:
        cur.execute(sql, params)
        return cur.fetchone()


# ── wiki.citations ─────────────────────────────────────────────────────


def insert_citation(
    conn: Connection,
    page_id: int,
    session_id: str = "",
    domain: str = "",
    memory_id: int | None = None,
) -> int:
    """Record that a page was cited. Trigger bumps heat + citation_count."""
    sql = """
    INSERT INTO wiki.citations (page_id, session_id, domain, memory_id)
    VALUES (%s, %s, %s, %s)
    RETURNING id;
    """
    with conn.cursor() as cur:
        cur.execute(sql, (page_id, session_id, domain, memory_id))
        row = cur.fetchone()
        return row["id"] if isinstance(row, dict) else row[0]


# ── wiki.memos (grounded-theory audit trail) ──────────────────────────


def insert_memo(
    conn: Connection,
    subject_type: str,
    subject_id: int,
    decision: str,
    rationale: str = "",
    alternatives: list | None = None,
    inputs: dict | None = None,
    confidence: float = 0.5,
    author: str = "system",
) -> int:
    sql = """
    INSERT INTO wiki.memos (
        subject_type, subject_id, decision, rationale,
        alternatives, inputs, confidence, author
    )
    VALUES (%s, %s, %s, %s, %s::jsonb, %s::jsonb, %s, %s)
    RETURNING id;
    """
    with conn.cursor() as cur:
        cur.execute(
            sql,
            (
                subject_type,
                subject_id,
                decision,
                rationale,
                json.dumps(alternatives or []),
                json.dumps(inputs or {}),
                confidence,
                author,
            ),
        )
        row = cur.fetchone()
        return row["id"] if isinstance(row, dict) else row[0]


# ── Diagnostics ────────────────────────────────────────────────────────


def wiki_stats(conn: Connection) -> dict:
    """Counts across the wiki schema."""
    with conn.cursor(row_factory=dict_row) as cur:
        cur.execute(
            """
            SELECT
              (SELECT COUNT(*) FROM wiki.pages) AS pages,
              (SELECT COUNT(*) FROM wiki.pages WHERE lifecycle_state='active') AS active,
              (SELECT COUNT(*) FROM wiki.pages WHERE lifecycle_state='archived') AS archived,
              (SELECT COUNT(*) FROM wiki.concepts) AS concepts,
              (SELECT COUNT(*) FROM wiki.drafts WHERE status='pending') AS pending_drafts,
              (SELECT COUNT(*) FROM wiki.claim_events) AS claim_events,
              (SELECT COUNT(*) FROM wiki.links) AS links,
              (SELECT COUNT(*) FROM wiki.citations) AS citations,
              (SELECT COUNT(*) FROM wiki.memos) AS memos
            """
        )
        return cur.fetchone()
