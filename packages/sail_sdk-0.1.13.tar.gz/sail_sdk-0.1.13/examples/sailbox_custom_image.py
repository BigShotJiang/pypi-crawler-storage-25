from __future__ import annotations

"""Build and run a sailbox with a custom Debian image.

Usage:
    cd sdk/python
    export SAIL_MODE=prod  # optional; prod is also the default
    export SAIL_API_KEY=your_api_key_here
    uv run python examples/sailbox_custom_image.py
"""

import os
import sys

import sail
from sail._config import Config


def main() -> int:
    api_key = os.environ.get("SAIL_API_KEY", "")
    if not api_key:
        print("Set SAIL_API_KEY before running this script.", file=sys.stderr)
        return 2

    cfg = Config.from_env()

    print(f"Finding or minting app via API {cfg.api_url}...")
    app = sail.App.find(name="sailbox-custom-image", mint_if_missing=True)

    print("Defining custom image...")
    image = (
        sail.Image.debian_arm64.apt_install("git", "curl")
        .pip_install("requests")
        .run_commands(
            "git clone https://github.com/pallets/flask.git /opt/flask-src",
            "python3 -m pip show requests >/tmp/requests.txt",
        )
        .env(
            {
                "APP_ENV": "custom-image-demo",
                "DEMO_MESSAGE": "hello-from-custom-image",
            }
        )
    )

    print(
        f"Creating sailbox from custom image via imagebuilder {cfg.imagebuilder_url}..."
    )
    sb = sail.Sailbox.create(
        app=app,
        image=image,
        name="custom-image-demo",
        image_build_timeout=1800,
        cpu=1,
        memory_mib=1024,
    )

    print("Sailbox ready:")
    print(f"  sailbox_id: {sb.sailbox_id}")
    print(f"  worker:     {sb.worker_address}")

    print("Verifying installed packages, build output, and runtime env...")
    result = sb.exec(
        "python3 - <<'PY'\n"
        "import os\n"
        "import requests\n"
        "print('requests=' + requests.__version__)\n"
        "print('app_env=' + os.environ['APP_ENV'])\n"
        "print('demo_message=' + os.environ['DEMO_MESSAGE'])\n"
        "PY\n"
        "test -d /opt/flask-src/.git\n"
        "cat /tmp/requests.txt | head -n 5\n",
        timeout=30,
    ).wait()
    print(result.stdout)
    if result.stderr:
        print(result.stderr, file=sys.stderr)
    print(f"return code: {result.returncode}")

    print("Terminating sailbox...")
    sb.terminate()
    print("Terminated.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
