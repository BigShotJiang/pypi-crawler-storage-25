from __future__ import annotations

import atexit
import contextvars
import json
import os
import re
import secrets
import threading
import time
import urllib.parse
import warnings
import weakref
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Mapping, NamedTuple, Optional, Set, Tuple, Union

from sail._config import Config
from sail._http_client import HTTPClient
from sail.errors import VoyageError, VoyageHTTPError, VoyageNotFoundError

VOYAGE_ID_HEADER = "X-Sail-Voyage-Id"
_VOYAGE_STARTED_KIND = "voyage.started"
_VOYAGE_COMPLETED_KIND = "voyage.completed"
_VOYAGE_FAILED_KIND = "voyage.failed"
_VOYAGE_ERROR_KIND = "voyage.error"
_SPAN_STARTED_KIND = "span.started"
_SPAN_COMPLETED_KIND = "span.completed"
_SPAN_FAILED_KIND = "span.failed"
_EVENTS_DROPPED_KIND = "sdk.events_dropped"
_PRESERVED_EVENT_KINDS = {
    _VOYAGE_STARTED_KIND,
    _VOYAGE_COMPLETED_KIND,
    _VOYAGE_FAILED_KIND,
}
_VALID_LEVELS = {"debug", "info", "warn", "error"}
_MAX_EVENT_BATCH_SIZE = 256
_DEFAULT_BUFFER_CAP = 10_000
_DEFAULT_FLUSH_INTERVAL_SECONDS = 1.0
_BACKGROUND_FLUSH_TIMEOUT_SECONDS = 10.0
_BACKGROUND_BACKOFF_INITIAL_SECONDS = 1.0
_BACKGROUND_BACKOFF_MAX_SECONDS = 30.0
_MAX_JS_SAFE_SEQUENCE_ID = 9_007_199_254_740_991
_MAX_AUTOMATIC_SEQUENCE_ID = _MAX_JS_SAFE_SEQUENCE_ID
_ATTACHED_SEQUENCE_ID_START_MIN = 1_000_000_000_000
_ATTACHED_SEQUENCE_ID_HEADROOM = 1_000_000
_ATTACHED_SEQUENCE_ID_RANDOM_SPAN = (
    _MAX_JS_SAFE_SEQUENCE_ID
    - _ATTACHED_SEQUENCE_ID_START_MIN
    - _ATTACHED_SEQUENCE_ID_HEADROOM
)

_KIND_MAX_CODE_POINTS = 128
_SHORT_FIELD_MAX_CODE_POINTS = 128
_MESSAGE_MAX_BYTES = 4 * 1024
_PAYLOAD_MAX_BYTES = 64 * 1024
_MAX_SEQUENCE_ID = 9_223_372_036_854_775_807
_RFC3339_TIMESTAMP_RE = re.compile(
    r"^(?P<year>\d{4})-(?P<month>\d{2})-(?P<day>\d{2})"
    r"T(?P<hour>\d{2}):(?P<minute>\d{2}):(?P<second>\d{2})"
    r"(?P<fraction>\.\d{1,9})?"
    r"(?P<tz>Z|(?P<tz_sign>[+-])(?P<tz_hour>\d{2}):(?P<tz_minute>\d{2}))$"
)
_RFC3339_NO_TIMEZONE_RE = re.compile(
    r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,9})?$"
)

_current_lock = threading.Lock()
_current_voyage: Optional[Union["Voyage", "NoopVoyage"]] = None
_live_voyages_lock = threading.Lock()
_live_voyages = weakref.WeakSet()
_atexit_registered = False
_active_span_stack = contextvars.ContextVar("sail_voyage_span_stack", default=())
_active_agent_context = contextvars.ContextVar("sail_voyage_agent_context", default=())


class _SpanFrame(NamedTuple):
    voyage_id: str
    span_id: str
    parent_span_id: Optional[str]


class _AgentFrame(NamedTuple):
    voyage_id: str
    agent_id: Optional[str]
    agent_name: Optional[str]
    agent_role: Optional[str]


class Voyage:
    """A Sail Voyage attached to the current process."""

    def __init__(
        self,
        *,
        id: str,
        dashboard_url: Optional[str] = None,
        status: Optional[str] = None,
        name: Optional[str] = None,
        sailbox_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        client: Optional[HTTPClient] = None,
        _start_background: bool = True,
        _buffer_cap: int = _DEFAULT_BUFFER_CAP,
        _flush_interval: float = _DEFAULT_FLUSH_INTERVAL_SECONDS,
        _sequence_id_start: int = 0,
    ) -> None:
        if not id:
            raise ValueError("id must be non-empty")
        self.id = id
        self.dashboard_url = dashboard_url
        self.status = status
        self.name = name
        self.sailbox_id = sailbox_id
        self.metadata = metadata or {}
        self._client = client
        self._buffer: List[Dict[str, Any]] = []
        self._sequence_id = max(0, int(_sequence_id_start))
        self._reserved_sequence_ids: Set[int] = set()
        self._buffer_lock = threading.Lock()
        self._flush_lock = threading.Lock()
        self._flush_signal = threading.Event()
        self._stop_signal = threading.Event()
        self._last_flush_error: Optional[VoyageError] = None
        self._dropped_event_count = 0
        self._buffer_cap = max(1, int(_buffer_cap))
        self._flush_interval = max(0.01, float(_flush_interval))
        self._background_thread: Optional[threading.Thread] = None

        if self._client is not None and _start_background:
            self._start_background_flusher()

    def headers(self, existing: Optional[Mapping[str, str]] = None) -> Dict[str, str]:
        result = dict(existing or {})
        for key in list(result):
            if key.lower() == VOYAGE_ID_HEADER.lower():
                del result[key]
        result[VOYAGE_ID_HEADER] = self.id
        return result

    def event(
        self,
        kind: str,
        level: str = "info",
        message: Optional[str] = None,
        payload: Optional[Dict[str, Any]] = None,
        agent_id: Optional[str] = None,
        agent_name: Optional[str] = None,
        agent_role: Optional[str] = None,
        span_id: Optional[str] = None,
        parent_span_id: Optional[str] = None,
        error_type: Optional[str] = None,
        occurred_at: Optional[str] = None,
        sequence_id: Optional[int] = None,
    ) -> None:
        agent_id, agent_name, agent_role, use_env_agent_defaults = (
            _resolve_agent_fields(
                self,
                agent_id,
                agent_name,
                agent_role,
            )
        )
        span_id, parent_span_id = _resolve_span_fields(self, span_id, parent_span_id)
        event = _build_event(
            kind=kind,
            level=level,
            message=message,
            payload=payload,
            agent_id=agent_id,
            agent_name=agent_name,
            agent_role=agent_role,
            span_id=span_id,
            parent_span_id=parent_span_id,
            error_type=error_type,
            occurred_at=occurred_at,
            use_env_agent_defaults=use_env_agent_defaults,
        )
        with self._buffer_lock:
            event["sequence_id"] = self._next_sequence_id_locked(sequence_id)
            self._enqueue_event_locked(event)
            if len(self._buffer) >= _MAX_EVENT_BATCH_SIZE:
                self._flush_signal.set()

    def span(
        self,
        span_name: Optional[str] = None,
        *,
        message: Optional[str] = None,
        payload: Optional[Dict[str, Any]] = None,
        agent_id: Optional[str] = None,
        name: Optional[str] = None,
        role: Optional[str] = None,
        agent_name: Optional[str] = None,
        agent_role: Optional[str] = None,
        span_id: Optional[str] = None,
        parent_span_id: Optional[str] = None,
    ) -> "_SpanContextManager":
        resolved_span_name, resolved_agent_name = _resolve_span_name_and_agent_name(
            span_name,
            name,
            agent_name,
        )
        resolved_agent_role = _resolve_alias("role", role, "agent_role", agent_role)
        return _SpanContextManager(
            self,
            span_name=resolved_span_name,
            message=message,
            payload=payload,
            agent_id=agent_id,
            agent_name=resolved_agent_name,
            agent_role=resolved_agent_role,
            span_id=span_id,
            parent_span_id=parent_span_id,
        )

    def agent(
        self,
        agent_id: str,
        *,
        name: Optional[str] = None,
        role: Optional[str] = None,
    ) -> "_AgentContextManager":
        return _AgentContextManager(self, agent_id, name=name, role=role)

    def error(
        self,
        error_type: Optional[str] = None,
        message: Optional[str] = None,
        payload: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.event(
            _VOYAGE_ERROR_KIND,
            level="error",
            message=message,
            payload=payload,
            error_type=error_type,
        )

    def complete(
        self,
        message: Optional[str] = None,
        payload: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.event(
            _VOYAGE_COMPLETED_KIND,
            level="info",
            message=message,
            payload=payload,
        )
        self.flush()

    def fail(
        self,
        error_type: str = "harness_error",
        message: Optional[str] = None,
        payload: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.event(
            _VOYAGE_FAILED_KIND,
            level="error",
            message=message,
            payload=payload,
            error_type=_validate_required_short_field(error_type, "error_type"),
        )
        self.flush()

    def flush(self, timeout: Optional[float] = None) -> None:
        if self._client is None:
            return None

        deadline = _deadline(timeout)
        if not _acquire_lock(self._flush_lock, deadline):
            raise VoyageError("timed out waiting to flush voyage events")
        try:
            while True:
                with self._buffer_lock:
                    if not self._buffer:
                        return None
                if deadline is not None and time.monotonic() >= deadline:
                    raise VoyageError("timed out flushing voyage events")
                remaining = _remaining(deadline)
                self._flush_one_batch(timeout=remaining, raise_errors=True)
        finally:
            self._flush_lock.release()

    def _next_sequence_id_locked(self, sequence_id: Optional[int]) -> int:
        if sequence_id is None:
            if self._sequence_id >= _MAX_AUTOMATIC_SEQUENCE_ID:
                raise ValueError(
                    "automatic sequence_id must be at most 9007199254740991"
                )
            self._sequence_id += 1
            return self._sequence_id
        _validate_sequence_id(sequence_id)
        if sequence_id > self._sequence_id:
            self._sequence_id = sequence_id
        return sequence_id

    def _enqueue_event_locked(self, event: Dict[str, Any]) -> None:
        sequence_id = event.get("sequence_id")
        if not isinstance(sequence_id, int):
            raise ValueError("voyage event missing sequence_id")
        if sequence_id in self._reserved_sequence_ids:
            raise ValueError("sequence_id duplicates a buffered voyage event")

        if len(self._buffer) < self._buffer_cap:
            self._buffer.append(event)
            self._reserved_sequence_ids.add(sequence_id)
            return

        drop_idx = self._oldest_non_preserved_event_index_locked()
        preserved = _is_preserved_event(event)
        if drop_idx is None:
            if preserved:
                raise VoyageError(
                    "voyage event buffer is full; cannot preserve terminal event"
                )
            self._dropped_event_count += 1
            _debug_warn("dropped voyage event because the local buffer is full")
            return

        dropped = self._buffer[drop_idx]
        del self._buffer[drop_idx]
        self._reserved_sequence_ids.discard(dropped.get("sequence_id"))
        self._dropped_event_count += 1
        self._buffer.append(event)
        self._reserved_sequence_ids.add(sequence_id)

    def _oldest_non_preserved_event_index_locked(self) -> Optional[int]:
        for idx, event in enumerate(self._buffer):
            if not _is_preserved_event(event):
                return idx
        return None

    def _take_batch_locked(self) -> List[Dict[str, Any]]:
        batch = self._buffer[:_MAX_EVENT_BATCH_SIZE]
        del self._buffer[: len(batch)]
        return batch

    def _requeue_batch_front(self, batch: List[Dict[str, Any]]) -> None:
        with self._buffer_lock:
            self._buffer[0:0] = batch
            self._trim_requeued_buffer_locked()

    def _trim_requeued_buffer_locked(self) -> None:
        while len(self._buffer) > self._buffer_cap:
            drop_idx = self._newest_non_preserved_event_index_locked()
            if drop_idx is None:
                _debug_warn(
                    "voyage event buffer exceeded its cap to preserve terminal events"
                )
                return
            dropped = self._buffer[drop_idx]
            del self._buffer[drop_idx]
            self._reserved_sequence_ids.discard(dropped.get("sequence_id"))
            self._dropped_event_count += 1

    def _newest_non_preserved_event_index_locked(self) -> Optional[int]:
        for idx in range(len(self._buffer) - 1, -1, -1):
            if not _is_preserved_event(self._buffer[idx]):
                return idx
        return None

    def _flush_one_batch(
        self,
        *,
        timeout: Optional[float],
        raise_errors: bool,
    ) -> bool:
        with self._buffer_lock:
            if not self._buffer:
                return False
            batch = self._take_batch_locked()

        try:
            data = self._send_batch(batch, timeout=timeout)
        except Exception as exc:
            err = _coerce_voyage_error(exc)
            self._last_flush_error = err
            self._requeue_batch_front(batch)
            if raise_errors:
                raise err
            _debug_warn(f"background voyage flush failed: {err}")
            return False

        self._last_flush_error = None
        self._release_batch_sequences(batch)
        status = data.get("status") if isinstance(data, dict) else None
        if isinstance(status, str):
            self.status = status
        self._enqueue_drop_notice_after_success()
        return True

    def _release_batch_sequences(self, batch: List[Dict[str, Any]]) -> None:
        with self._buffer_lock:
            for event in batch:
                self._reserved_sequence_ids.discard(event.get("sequence_id"))

    def _send_batch(
        self,
        batch: List[Dict[str, Any]],
        *,
        timeout: Optional[float],
    ) -> Dict[str, Any]:
        if self._client is None:
            raise VoyageError("voyage has no HTTP client")
        status, data = self._client.post(
            _voyage_events_path(self.id),
            {"events": batch},
            timeout=timeout,
        )
        if status >= 400:
            _raise_voyage_http_error(status, data, "failed to flush voyage events")
        return data

    def _enqueue_drop_notice_after_success(self) -> None:
        with self._buffer_lock:
            if self._dropped_event_count <= 0:
                return
            dropped = self._dropped_event_count
            self._dropped_event_count = 0
            if self._sequence_id >= _MAX_AUTOMATIC_SEQUENCE_ID:
                _debug_warn(
                    "skipped sdk.events_dropped because voyage sequence IDs are exhausted"
                )
                return
            event = _build_event(
                kind=_EVENTS_DROPPED_KIND,
                level="warn",
                message=f"Dropped {dropped} Voyage event(s) from the local buffer.",
                payload={"dropped": dropped},
                agent_id=None,
                agent_name=None,
                agent_role=None,
                span_id=None,
                parent_span_id=None,
                error_type=None,
                occurred_at=None,
                use_env_agent_defaults=False,
            )
            event["sequence_id"] = self._next_sequence_id_locked(None)
            self._enqueue_event_locked(event)
            self._flush_signal.set()

    def _start_background_flusher(self) -> None:
        _register_live_voyage(self)
        self._background_thread = threading.Thread(
            target=_run_background_flusher,
            args=(
                weakref.ref(self),
                self._flush_signal,
                self._stop_signal,
                self._flush_lock,
                self._flush_interval,
            ),
            name=f"sail-voyage-flush-{self.id}",
            daemon=True,
        )
        self._background_thread.start()

    def _stop_background_for_tests(self) -> None:
        self._stop_signal.set()
        self._flush_signal.set()
        if self._background_thread is not None:
            self._background_thread.join(timeout=1.0)


class NoopVoyage:
    """No-op Voyage used when SAIL_API_KEY is absent."""

    id: Optional[str] = None
    dashboard_url: Optional[str] = None
    status: Optional[str] = None

    def headers(self, existing: Optional[Mapping[str, str]] = None) -> Dict[str, str]:
        return dict(existing or {})

    def event(self, *args: Any, **kwargs: Any) -> None:
        return None

    def span(self, *args: Any, **kwargs: Any) -> "_NoopContextManager":
        return _NoopContextManager()

    def agent(self, *args: Any, **kwargs: Any) -> "_NoopContextManager":
        return _NoopContextManager()

    def error(self, *args: Any, **kwargs: Any) -> None:
        return None

    def complete(self, *args: Any, **kwargs: Any) -> None:
        return None

    def fail(self, *args: Any, **kwargs: Any) -> None:
        return None

    def flush(self, timeout: Optional[float] = None) -> None:
        return None


class _NoopContextManager:
    span_id: Optional[str] = None

    def __enter__(self) -> "_NoopContextManager":
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> bool:
        return False


class _AgentContextManager:
    def __init__(
        self,
        voyage: Voyage,
        agent_id: str,
        *,
        name: Optional[str],
        role: Optional[str],
    ) -> None:
        self._agent = _AgentFrame(
            voyage.id,
            _validate_required_short_field(agent_id, "agent_id"),
            _validate_optional_short_field(name, "agent_name"),
            _validate_optional_short_field(role, "agent_role"),
        )
        self._token: Optional[contextvars.Token] = None

    def __enter__(self) -> "_AgentContextManager":
        stack = _active_agent_context.get()
        self._token = _active_agent_context.set(stack + (self._agent,))
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> bool:
        if self._token is not None:
            _active_agent_context.reset(self._token)
            self._token = None
        return False


class _SpanContextManager:
    def __init__(
        self,
        voyage: Voyage,
        *,
        span_name: str,
        message: Optional[str],
        payload: Optional[Dict[str, Any]],
        agent_id: Optional[str],
        agent_name: Optional[str],
        agent_role: Optional[str],
        span_id: Optional[str],
        parent_span_id: Optional[str],
    ) -> None:
        self._voyage = voyage
        self._span_name = span_name
        self._message = message
        self._payload = _validate_payload(payload)
        self._agent_id = _validate_optional_short_field(agent_id, "agent_id")
        self._agent_name = _validate_optional_short_field(agent_name, "agent_name")
        self._agent_role = _validate_optional_short_field(agent_role, "agent_role")
        self.span_id = (
            _validate_optional_short_field(span_id, "span_id") or _new_span_id()
        )
        self.parent_span_id = _validate_optional_short_field(
            parent_span_id,
            "parent_span_id",
        )
        self._span_token: Optional[contextvars.Token] = None
        self._agent_token: Optional[contextvars.Token] = None
        self._agent: Optional[_AgentFrame] = None
        active_agent = _active_agent_for_voyage(self._voyage)
        frame_agent_name = self._agent_name
        frame_agent_role = self._agent_role
        if active_agent is not None and self._agent_id == active_agent.agent_id:
            frame_agent_name = frame_agent_name or active_agent.agent_name
            frame_agent_role = frame_agent_role or active_agent.agent_role
        if (
            self._agent_id is not None
            or self._agent_name is not None
            or self._agent_role is not None
        ):
            self._agent = _AgentFrame(
                self._voyage.id,
                self._agent_id,
                frame_agent_name,
                frame_agent_role,
            )

    def __enter__(self) -> "_SpanContextManager":
        stack = _active_span_stack.get()
        active_parent = _active_span_for_voyage(self._voyage)
        if self.parent_span_id is None and active_parent is not None:
            self.parent_span_id = active_parent.span_id

        if self._agent is not None:
            agent_stack = _active_agent_context.get()
            self._agent_token = _active_agent_context.set(agent_stack + (self._agent,))
        try:
            self._voyage.event(
                _SPAN_STARTED_KIND,
                message=self._message or self._span_name,
                payload=self._payload,
                agent_id=self._agent_id,
                agent_name=self._agent_name,
                agent_role=self._agent_role,
                span_id=self.span_id,
                parent_span_id=self.parent_span_id,
            )
        except Exception:
            if self._agent_token is not None:
                _active_agent_context.reset(self._agent_token)
                self._agent_token = None
            raise
        self._span_token = _active_span_stack.set(
            stack + (_SpanFrame(self._voyage.id, self.span_id, self.parent_span_id),)
        )
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> bool:
        try:
            if exc_type is None:
                self._voyage.event(
                    _SPAN_COMPLETED_KIND,
                    message=self._message or self._span_name,
                    payload=self._payload,
                    agent_id=self._agent_id,
                    agent_name=self._agent_name,
                    agent_role=self._agent_role,
                    span_id=self.span_id,
                    parent_span_id=self.parent_span_id,
                )
            else:
                try:
                    self._voyage.event(
                        _SPAN_FAILED_KIND,
                        level="error",
                        message=_span_failure_message(exc, self._span_name),
                        payload=self._payload,
                        agent_id=self._agent_id,
                        agent_name=self._agent_name,
                        agent_role=self._agent_role,
                        span_id=self.span_id,
                        parent_span_id=self.parent_span_id,
                        error_type=exc_type.__name__,
                    )
                except Exception as emit_exc:
                    _debug_warn(f"failed to emit span.failed: {emit_exc}")
        finally:
            if self._agent_token is not None:
                _active_agent_context.reset(self._agent_token)
                self._agent_token = None
            if self._span_token is not None:
                _active_span_stack.reset(self._span_token)
                self._span_token = None
        return False


def _run_background_flusher(
    voyage_ref: "weakref.ReferenceType[Voyage]",
    flush_signal: threading.Event,
    stop_signal: threading.Event,
    flush_lock: threading.Lock,
    flush_interval: float,
) -> None:
    backoff = _BACKGROUND_BACKOFF_INITIAL_SECONDS
    while not stop_signal.is_set():
        flush_signal.wait(flush_interval)
        flush_signal.clear()
        if stop_signal.is_set():
            return

        voyage = voyage_ref()
        if voyage is None:
            return
        if not flush_lock.acquire(blocking=False):
            del voyage
            continue

        should_backoff = False
        try:
            while not stop_signal.is_set():
                delivered = voyage._flush_one_batch(
                    timeout=_BACKGROUND_FLUSH_TIMEOUT_SECONDS,
                    raise_errors=False,
                )
                if not delivered:
                    break
                backoff = _BACKGROUND_BACKOFF_INITIAL_SECONDS
            should_backoff = voyage._last_flush_error is not None
        finally:
            flush_lock.release()
            del voyage

        if should_backoff:
            stop_signal.wait(backoff)
            backoff = min(backoff * 2, _BACKGROUND_BACKOFF_MAX_SECONDS)


def init(
    *,
    name: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
    sailbox_id: Optional[str] = None,
    voyage_id: Optional[str] = None,
) -> Union[Voyage, NoopVoyage]:
    """Create or attach to a Voyage and make it current for this process."""
    if not os.environ.get("SAIL_API_KEY"):
        _debug_warn("sail.voyage is disabled because SAIL_API_KEY is not set")
        noop = NoopVoyage()
        _set_current(noop)
        return noop

    config = Config.from_env_optional_api_key()
    attach_id = _clean(voyage_id) or _clean(os.environ.get("SAIL_VOYAGE_ID"))

    client = HTTPClient(config)
    if attach_id:
        voyage = _attach_voyage(client, attach_id)
        _set_current(voyage)
        return voyage

    voyage = _create_voyage(
        client,
        name=name,
        metadata=metadata,
        sailbox_id=sailbox_id,
    )
    _set_current(voyage)
    try:
        voyage.event(_VOYAGE_STARTED_KIND)
        voyage.flush(timeout=_BACKGROUND_FLUSH_TIMEOUT_SECONDS)
    except Exception as exc:
        _debug_warn(f"failed to emit voyage.started: {exc}")
    return voyage


def id() -> Optional[str]:
    current = _get_current()
    return current.id if current is not None else None


def dashboard_url() -> Optional[str]:
    current = _get_current()
    return current.dashboard_url if current is not None else None


def headers(existing: Optional[Mapping[str, str]] = None) -> Dict[str, str]:
    current = _get_current()
    if current is None:
        return dict(existing or {})
    return current.headers(existing)


def event(
    kind: str,
    level: str = "info",
    message: Optional[str] = None,
    payload: Optional[Dict[str, Any]] = None,
    agent_id: Optional[str] = None,
    agent_name: Optional[str] = None,
    agent_role: Optional[str] = None,
    span_id: Optional[str] = None,
    parent_span_id: Optional[str] = None,
    error_type: Optional[str] = None,
    occurred_at: Optional[str] = None,
    sequence_id: Optional[int] = None,
) -> None:
    current = _get_current()
    if current is None:
        return None
    return current.event(
        kind,
        level=level,
        message=message,
        payload=payload,
        agent_id=agent_id,
        agent_name=agent_name,
        agent_role=agent_role,
        span_id=span_id,
        parent_span_id=parent_span_id,
        error_type=error_type,
        occurred_at=occurred_at,
        sequence_id=sequence_id,
    )


def span(
    span_name: Optional[str] = None,
    *,
    message: Optional[str] = None,
    payload: Optional[Dict[str, Any]] = None,
    agent_id: Optional[str] = None,
    name: Optional[str] = None,
    role: Optional[str] = None,
    agent_name: Optional[str] = None,
    agent_role: Optional[str] = None,
    span_id: Optional[str] = None,
    parent_span_id: Optional[str] = None,
) -> Union["_SpanContextManager", "_NoopContextManager"]:
    current = _get_current()
    if current is None:
        return _NoopContextManager()
    return current.span(
        span_name,
        message=message,
        payload=payload,
        agent_id=agent_id,
        name=name,
        role=role,
        agent_name=agent_name,
        agent_role=agent_role,
        span_id=span_id,
        parent_span_id=parent_span_id,
    )


def agent(
    agent_id: str,
    *,
    name: Optional[str] = None,
    role: Optional[str] = None,
) -> Union["_AgentContextManager", "_NoopContextManager"]:
    current = _get_current()
    if current is None:
        return _NoopContextManager()
    return current.agent(agent_id, name=name, role=role)


def error(
    error_type: Optional[str] = None,
    message: Optional[str] = None,
    payload: Optional[Dict[str, Any]] = None,
) -> None:
    current = _get_current()
    if current is not None:
        current.error(error_type=error_type, message=message, payload=payload)


def complete(
    message: Optional[str] = None,
    payload: Optional[Dict[str, Any]] = None,
) -> None:
    current = _get_current()
    if current is not None:
        current.complete(message=message, payload=payload)


def fail(
    error_type: str = "harness_error",
    message: Optional[str] = None,
    payload: Optional[Dict[str, Any]] = None,
) -> None:
    current = _get_current()
    if current is not None:
        current.fail(error_type=error_type, message=message, payload=payload)


def flush(timeout: Optional[float] = None) -> None:
    current = _get_current()
    if current is not None:
        current.flush(timeout=timeout)


def _create_voyage(
    client: HTTPClient,
    *,
    name: Optional[str],
    metadata: Optional[Dict[str, Any]],
    sailbox_id: Optional[str],
) -> Voyage:
    body: Dict[str, Any] = {}
    if name is not None:
        body["name"] = name

    default_sailbox_id = os.environ.get("SAILBOX_ID")
    resolved_sailbox_id = sailbox_id if sailbox_id is not None else default_sailbox_id
    resolved_sailbox_id = _clean(resolved_sailbox_id)
    if resolved_sailbox_id:
        body["sailbox_id"] = resolved_sailbox_id

    if metadata is not None:
        body["metadata"] = _validate_metadata(metadata)

    status, data = client.post("/v1/voyages", body)
    if status >= 400:
        _raise_voyage_http_error(status, data, "failed to create voyage")
    return _voyage_from_response(data, client=client)


def _attach_voyage(client: HTTPClient, voyage_id: str) -> Voyage:
    status, data = client.get(_voyage_path(voyage_id))
    if status >= 400:
        _raise_voyage_http_error(status, data, "failed to attach voyage")
    return _voyage_from_response(
        data,
        client=client,
        sequence_id_start=_attached_sequence_id_start(),
    )


def _build_event(
    *,
    kind: str,
    level: str,
    message: Optional[str],
    payload: Optional[Dict[str, Any]],
    agent_id: Optional[str],
    agent_name: Optional[str],
    agent_role: Optional[str],
    span_id: Optional[str],
    parent_span_id: Optional[str],
    error_type: Optional[str],
    occurred_at: Optional[str],
    use_env_agent_defaults: bool = True,
) -> Dict[str, Any]:
    kind = _validate_kind(kind)
    level = _validate_level(level)
    payload = _validate_payload(payload)
    message = _validate_optional_message(message)
    occurred_at = _validate_optional_occurred_at(occurred_at)

    if use_env_agent_defaults:
        agent_id_value = (
            agent_id if agent_id is not None else os.environ.get("SAIL_AGENT_ID")
        )
        agent_name_value = (
            agent_name if agent_name is not None else os.environ.get("SAIL_AGENT_NAME")
        )
        agent_role_value = (
            agent_role if agent_role is not None else os.environ.get("SAIL_AGENT_ROLE")
        )
    else:
        agent_id_value = agent_id
        agent_name_value = agent_name
        agent_role_value = agent_role

    event_agent_id = _validate_optional_short_field(agent_id_value, "agent_id")
    event_agent_name = _validate_optional_short_field(agent_name_value, "agent_name")
    event_agent_role = _validate_optional_short_field(agent_role_value, "agent_role")

    event = {
        "occurred_at": occurred_at or datetime.now(timezone.utc).isoformat(),
        "source": "sdk",
        "kind": kind,
        "level": level,
        "payload": payload,
    }
    optional_fields = {
        "message": message,
        "agent_id": event_agent_id,
        "agent_name": event_agent_name,
        "agent_role": event_agent_role,
        "span_id": _validate_optional_short_field(span_id, "span_id"),
        "parent_span_id": _validate_optional_short_field(
            parent_span_id, "parent_span_id"
        ),
        "error_type": _validate_optional_short_field(error_type, "error_type"),
    }
    for key, value in optional_fields.items():
        if value is not None:
            event[key] = value
    return event


def _resolve_agent_fields(
    voyage: Voyage,
    agent_id: Optional[str],
    agent_name: Optional[str],
    agent_role: Optional[str],
) -> Tuple[Optional[str], Optional[str], Optional[str], bool]:
    active_agent = _active_agent_for_voyage(voyage)
    if active_agent is None:
        return agent_id, agent_name, agent_role, True
    if agent_id is not None and agent_id != active_agent.agent_id:
        return agent_id, agent_name, agent_role, False
    return (
        agent_id if agent_id is not None else active_agent.agent_id,
        agent_name if agent_name is not None else active_agent.agent_name,
        agent_role if agent_role is not None else active_agent.agent_role,
        False,
    )


def _active_agent_for_voyage(voyage: Voyage) -> Optional[_AgentFrame]:
    for frame in reversed(_active_agent_context.get()):
        if frame.voyage_id == voyage.id:
            return frame
    return None


def _resolve_span_fields(
    voyage: Voyage,
    span_id: Optional[str],
    parent_span_id: Optional[str],
) -> Tuple[Optional[str], Optional[str]]:
    if span_id is not None:
        return span_id, parent_span_id
    active_span = _active_span_for_voyage(voyage)
    if active_span is None:
        return span_id, parent_span_id
    return active_span.span_id, (
        parent_span_id if parent_span_id is not None else active_span.parent_span_id
    )


def _active_span_for_voyage(voyage: Voyage) -> Optional[_SpanFrame]:
    for frame in reversed(_active_span_stack.get()):
        if frame.voyage_id == voyage.id:
            return frame
    return None


def _resolve_span_name_and_agent_name(
    span_name: Optional[str],
    name: Optional[str],
    agent_name: Optional[str],
) -> Tuple[str, Optional[str]]:
    if span_name is None:
        if name is None:
            raise TypeError("span name is required")
        return _validate_required_span_name(name), agent_name
    return _validate_required_span_name(span_name), _resolve_alias(
        "name",
        name,
        "agent_name",
        agent_name,
    )


def _resolve_alias(
    alias_field: str,
    alias_value: Optional[str],
    canonical_field: str,
    canonical_value: Optional[str],
) -> Optional[str]:
    if alias_value is None:
        return canonical_value
    if canonical_value is None:
        return alias_value
    if alias_value != canonical_value:
        raise ValueError(f"{alias_field} and {canonical_field} must match")
    return canonical_value


def _new_span_id() -> str:
    return "span_" + secrets.token_hex(16)


def _span_failure_message(exc: Any, fallback: str) -> str:
    message = str(exc) if exc is not None else fallback
    return _truncate_message(message or fallback)


def _truncate_message(message: str) -> str:
    encoded = message.encode("utf-8")
    if len(encoded) <= _MESSAGE_MAX_BYTES:
        return message
    suffix = "... [truncated]"
    suffix_bytes = suffix.encode("utf-8")
    available = max(0, _MESSAGE_MAX_BYTES - len(suffix_bytes))
    return encoded[:available].decode("utf-8", errors="ignore") + suffix


def _validate_kind(kind: str) -> str:
    if not isinstance(kind, str):
        raise TypeError("kind must be a string")
    kind = kind.strip()
    if not kind:
        raise ValueError("kind must be non-empty")
    _reject_nul(kind, "kind")
    if len(kind) > _KIND_MAX_CODE_POINTS:
        raise ValueError("kind must be at most 128 characters")
    return kind


def _validate_level(level: str) -> str:
    if not isinstance(level, str):
        raise TypeError("level must be a string")
    level = level.strip()
    if level not in _VALID_LEVELS:
        raise ValueError("level must be one of debug, info, warn, error")
    return level


def _validate_required_short_field(value: str, field: str) -> str:
    if not isinstance(value, str):
        raise TypeError(f"{field} must be a string")
    value = _clean(value)
    if value is None:
        raise ValueError(f"{field} must be non-empty")
    _reject_nul(value, field)
    if len(value) > _SHORT_FIELD_MAX_CODE_POINTS:
        raise ValueError(f"{field} must be at most 128 characters")
    return value


def _validate_required_span_name(value: str) -> str:
    if not isinstance(value, str):
        raise TypeError("span name must be a string")
    value = value.strip()
    if not value:
        raise ValueError("span name must be non-empty")
    _reject_nul(value, "span name")
    if len(value.encode("utf-8")) > _MESSAGE_MAX_BYTES:
        raise ValueError("span name must be at most 4096 bytes")
    return value


def _validate_optional_short_field(value: Optional[str], field: str) -> Optional[str]:
    if value is not None and not isinstance(value, str):
        raise TypeError(f"{field} must be a string")
    value = _clean(value)
    if value is None:
        return None
    _reject_nul(value, field)
    if len(value) > _SHORT_FIELD_MAX_CODE_POINTS:
        raise ValueError(f"{field} must be at most 128 characters")
    return value


def _validate_optional_message(message: Optional[str]) -> Optional[str]:
    if message is None:
        return None
    if not isinstance(message, str):
        raise TypeError("message must be a string")
    _reject_nul(message, "message")
    if len(message.encode("utf-8")) > _MESSAGE_MAX_BYTES:
        raise ValueError("message must be at most 4096 bytes")
    return message


def _validate_optional_occurred_at(occurred_at: Optional[str]) -> Optional[str]:
    if occurred_at is None:
        return None
    if not isinstance(occurred_at, str):
        raise TypeError("occurred_at must be a string")
    raw = occurred_at.strip()
    if not raw:
        raise ValueError("occurred_at must be an RFC3339 timestamp")
    match = _RFC3339_TIMESTAMP_RE.match(raw)
    if match is None:
        if _RFC3339_NO_TIMEZONE_RE.match(raw):
            raise ValueError("occurred_at must include a timezone")
        raise ValueError("occurred_at must be an RFC3339 timestamp")

    fraction = match.group("fraction")
    microsecond = 0
    if fraction is not None:
        microsecond = int((fraction[1:] + "000000")[:6])

    if match.group("tz") == "Z":
        tzinfo = timezone.utc
    else:
        sign = -1 if match.group("tz_sign") == "-" else 1
        tz_hour = int(match.group("tz_hour"))
        tz_minute = int(match.group("tz_minute"))
        if tz_hour > 23 or tz_minute > 59:
            raise ValueError("occurred_at must be an RFC3339 timestamp")
        offset = timedelta(
            hours=tz_hour,
            minutes=tz_minute,
        )
        tzinfo = timezone(sign * offset)

    try:
        parsed = datetime(
            year=int(match.group("year")),
            month=int(match.group("month")),
            day=int(match.group("day")),
            hour=int(match.group("hour")),
            minute=int(match.group("minute")),
            second=int(match.group("second")),
            microsecond=microsecond,
            tzinfo=tzinfo,
        )
    except ValueError as exc:
        raise ValueError("occurred_at must be an RFC3339 timestamp") from exc
    return parsed.isoformat()


def _validate_payload(payload: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    if payload is None:
        return {}
    if not isinstance(payload, dict):
        raise ValueError("payload must be a JSON object")
    try:
        encoded = json.dumps(payload, allow_nan=False).encode("utf-8")
    except (TypeError, ValueError) as exc:
        raise ValueError("payload must be JSON serializable") from exc
    if len(encoded) > _PAYLOAD_MAX_BYTES:
        raise ValueError("payload exceeds 64 KiB")
    decoded = json.loads(encoded)
    _reject_json_nul(decoded, "payload")
    return decoded


def _reject_nul(value: str, field: str) -> None:
    if "\x00" in value:
        raise ValueError(f"{field} must not contain NUL bytes")


def _reject_json_nul(value: Any, field: str) -> None:
    if isinstance(value, str):
        _reject_nul(value, field)
        return
    if isinstance(value, list):
        for item in value:
            _reject_json_nul(item, field)
        return
    if isinstance(value, dict):
        for key, item in value.items():
            if isinstance(key, str):
                _reject_nul(key, field)
            _reject_json_nul(item, field)


def _validate_sequence_id(sequence_id: int) -> None:
    if isinstance(sequence_id, bool) or not isinstance(sequence_id, int):
        raise TypeError("sequence_id must be an integer")
    if sequence_id <= 0:
        raise ValueError("sequence_id must be a positive integer")
    if sequence_id > _MAX_SEQUENCE_ID:
        raise ValueError("sequence_id must be at most 9223372036854775807")


def _is_preserved_event(event: Mapping[str, Any]) -> bool:
    return event.get("kind") in _PRESERVED_EVENT_KINDS


def _coerce_voyage_error(exc: Exception) -> VoyageError:
    if isinstance(exc, VoyageError):
        return exc
    return VoyageError(str(exc))


def _deadline(timeout: Optional[float]) -> Optional[float]:
    if timeout is None:
        return None
    if timeout < 0:
        raise ValueError("timeout must be non-negative")
    return time.monotonic() + timeout


def _remaining(deadline: Optional[float]) -> Optional[float]:
    if deadline is None:
        return None
    return max(0.0, deadline - time.monotonic())


def _acquire_lock(lock: threading.Lock, deadline: Optional[float]) -> bool:
    if deadline is None:
        lock.acquire()
        return True
    return lock.acquire(timeout=_remaining(deadline))


def _register_live_voyage(voyage: Voyage) -> None:
    global _atexit_registered
    with _live_voyages_lock:
        _live_voyages.add(voyage)
        if not _atexit_registered:
            atexit.register(_flush_live_voyages)
            _atexit_registered = True


def _flush_live_voyages(timeout_per_voyage: float = 2.0) -> None:
    with _live_voyages_lock:
        voyages = list(_live_voyages)
    for voyage in voyages:
        try:
            voyage.flush(timeout=timeout_per_voyage)
        except Exception as exc:
            _debug_warn(f"atexit voyage flush failed: {exc}")


def _buffered_events_for_tests(voyage: Voyage) -> List[Dict[str, Any]]:
    with voyage._buffer_lock:
        return list(voyage._buffer)


def _flush_one_background_batch_for_tests(voyage: Voyage) -> bool:
    if not voyage._flush_lock.acquire(blocking=False):
        return False
    try:
        return voyage._flush_one_batch(
            timeout=_BACKGROUND_FLUSH_TIMEOUT_SECONDS,
            raise_errors=False,
        )
    finally:
        voyage._flush_lock.release()


def _attached_sequence_id_start() -> int:
    # GET /v1/voyages/{id} does not expose max sequence_id; use a high,
    # JS-safe random range so child processes do not replay sequence 1.
    return _ATTACHED_SEQUENCE_ID_START_MIN + secrets.randbelow(
        _ATTACHED_SEQUENCE_ID_RANDOM_SPAN
    )


def _voyage_from_response(
    data: Mapping[str, Any],
    *,
    client: HTTPClient,
    sequence_id_start: int = 0,
) -> Voyage:
    raw_id = data.get("id")
    if not isinstance(raw_id, str) or not raw_id:
        raise VoyageError("voyage response missing id")

    metadata = data.get("metadata")
    return Voyage(
        id=raw_id,
        dashboard_url=_optional_str(data.get("dashboard_url")),
        status=_optional_str(data.get("status")),
        name=_optional_str(data.get("name")),
        sailbox_id=_optional_str(data.get("sailbox_id")),
        metadata=metadata if isinstance(metadata, dict) else None,
        client=client,
        _sequence_id_start=sequence_id_start,
    )


def _validate_metadata(metadata: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(metadata, dict):
        raise ValueError("metadata must be a JSON object")
    try:
        encoded = json.dumps(metadata, allow_nan=False).encode("utf-8")
    except (TypeError, ValueError) as exc:
        raise ValueError("metadata must be JSON serializable") from exc
    if len(encoded) > 64 * 1024:
        raise ValueError("metadata exceeds 64 KiB")
    return metadata


def _raise_voyage_http_error(
    status: int, data: Mapping[str, Any], fallback: str
) -> None:
    message = _error_message(data, fallback)
    if status == 404:
        raise VoyageNotFoundError(status, message, dict(data))
    raise VoyageHTTPError(status, message, dict(data))


def _error_message(data: Mapping[str, Any], fallback: str) -> str:
    err = data.get("error")
    if isinstance(err, dict):
        message = err.get("message")
        if isinstance(message, str) and message:
            return message
    return fallback


def _voyage_path(voyage_id: str) -> str:
    return "/v1/voyages/" + urllib.parse.quote(voyage_id, safe="")


def _voyage_events_path(voyage_id: str) -> str:
    return _voyage_path(voyage_id) + "/events"


def _optional_str(value: Any) -> Optional[str]:
    return value if isinstance(value, str) else None


def _clean(value: Optional[str]) -> Optional[str]:
    if value is None:
        return None
    value = value.strip()
    return value or None


def _set_current(voyage: Union[Voyage, NoopVoyage]) -> None:
    global _current_voyage
    with _current_lock:
        _current_voyage = voyage


def _get_current() -> Optional[Union[Voyage, NoopVoyage]]:
    with _current_lock:
        return _current_voyage


def _debug_enabled() -> bool:
    raw = os.environ.get("SAIL_VOYAGE_DEBUG", "").strip().lower()
    return raw not in ("", "0", "false", "no", "off")


def _debug_warn(message: str) -> None:
    if _debug_enabled():
        warnings.warn(message, RuntimeWarning, stacklevel=2)


def _reset_for_tests() -> None:
    global _current_voyage
    with _live_voyages_lock:
        voyages = list(_live_voyages)
        _live_voyages.clear()
    for voyage in voyages:
        voyage._stop_background_for_tests()
    with _current_lock:
        _current_voyage = None
    _active_span_stack.set(())
    _active_agent_context.set(())
