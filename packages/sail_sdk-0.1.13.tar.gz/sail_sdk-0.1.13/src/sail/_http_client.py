from __future__ import annotations

import json
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, Dict, Mapping, Optional, Tuple

from sail._config import Config


class _HTTPGetDescriptor:
    def __get__(self, obj: Optional["HTTPClient"], objtype: type) -> Any:
        if obj is None:

            def singleton_get() -> "HTTPClient":
                if objtype._instance is None:
                    objtype._instance = objtype()
                return objtype._instance

            return singleton_get

        return obj._get_json


class HTTPClient:
    """Thin HTTP client for the Sail REST API."""

    _instance: Optional["HTTPClient"] = None
    get = _HTTPGetDescriptor()

    def __init__(self, config: Optional[Config] = None) -> None:
        self._config = config or Config.from_env()
        if not self._config.api_url:
            raise ValueError(
                "SAIL_API_URL must be set (e.g. https://api.sailresearch.com)"
            )

    @classmethod
    def reset(cls) -> None:
        """Close and discard the singleton (useful for tests)."""
        cls._instance = None

    def _get_json(
        self,
        path: str,
        query: Optional[Mapping[str, Any]] = None,
        headers: Optional[Mapping[str, str]] = None,
        timeout: Optional[float] = None,
    ) -> Tuple[int, Dict]:
        """GET {api_url}{path}, return (status_code, parsed_json)."""
        url = self._url(path, query=query)
        req = urllib.request.Request(
            url,
            headers=self._headers(headers),
            method="GET",
        )
        return self._open_json(req, timeout=timeout)

    def post(
        self,
        path: str,
        body: Dict,
        headers: Optional[Mapping[str, str]] = None,
        timeout: Optional[float] = None,
    ) -> Tuple[int, Dict]:
        """POST JSON to {api_url}{path}, return (status_code, parsed_json)."""
        url = self._url(path)
        data = json.dumps(body).encode()
        req = urllib.request.Request(
            url,
            data=data,
            headers=self._headers(headers, content_type_json=True),
            method="POST",
        )
        return self._open_json(req, timeout=timeout)

    def _url(self, path: str, query: Optional[Mapping[str, Any]] = None) -> str:
        url = self._config.api_url.rstrip("/") + path
        if query:
            encoded = urllib.parse.urlencode(query, doseq=True)
            if encoded:
                separator = "&" if "?" in url else "?"
                url = url + separator + encoded
        return url

    def _headers(
        self,
        extra: Optional[Mapping[str, str]] = None,
        *,
        content_type_json: bool = False,
    ) -> Dict[str, str]:
        headers: Dict[str, str] = {}
        if self._config.api_key:
            headers["Authorization"] = f"Bearer {self._config.api_key}"
        if content_type_json:
            headers["Content-Type"] = "application/json"

        protected = {"authorization"}
        if content_type_json:
            protected.add("content-type")

        for key, value in (extra or {}).items():
            if key.lower() in protected:
                continue
            headers[key] = value
        return headers

    def _open_json(
        self,
        req: urllib.request.Request,
        *,
        timeout: Optional[float] = None,
    ) -> Tuple[int, Dict]:
        try:
            if timeout is None:
                resp_ctx = urllib.request.urlopen(req)
            else:
                resp_ctx = urllib.request.urlopen(req, timeout=timeout)
            with resp_ctx as resp:
                return resp.status, json.loads(resp.read())
        except urllib.error.HTTPError as e:
            body_bytes = e.read()
            try:
                return e.code, _sanitize_json(
                    json.loads(body_bytes), self._config.api_key
                )
            except (json.JSONDecodeError, ValueError):
                return e.code, {
                    "error": {
                        "message": _sanitize_error_message(
                            body_bytes.decode(errors="replace"),
                            self._config.api_key,
                        )
                    }
                }


def _sanitize_json(value: Any, api_key: str) -> Any:
    if isinstance(value, str):
        return _sanitize_error_message(value, api_key)
    if isinstance(value, list):
        return [_sanitize_json(item, api_key) for item in value]
    if isinstance(value, dict):
        return {key: _sanitize_json(item, api_key) for key, item in value.items()}
    return value


def _sanitize_error_message(message: str, api_key: str) -> str:
    if not api_key:
        return message
    sanitized = message.replace(f"Bearer {api_key}", "Bearer [redacted]")
    return sanitized.replace(api_key, "[redacted]")
