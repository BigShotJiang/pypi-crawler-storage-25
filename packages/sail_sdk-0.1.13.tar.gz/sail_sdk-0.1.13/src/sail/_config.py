from __future__ import annotations

import os
from typing import NamedTuple


class _EnvDefaults(NamedTuple):
    scheduler_url: str
    imagebuilder_url: str
    api_url: str
    sailbox_ingress_url: str


# Default endpoints for each named environment. When SAIL_MODE is unset,
# from_env() reads from the "prod" entry.
_ENV_DEFAULTS: dict[str, _EnvDefaults] = {
    "prod": _EnvDefaults(
        scheduler_url="sailbox-scheduler.sailresearch.com:443",
        imagebuilder_url="sailbox-imagebuilder-dispatcher.sailresearch.com:443",
        api_url="https://api.sailresearch.com",
        sailbox_ingress_url="https://api.sailresearch.com",
    ),
    "dev": _EnvDefaults(
        scheduler_url="sailbox-scheduler.dev.sailresearch.com:443",
        imagebuilder_url="sailbox-imagebuilder-dispatcher.dev.sailresearch.com:443",
        api_url="https://dev.sailresearch.com",
        sailbox_ingress_url="https://dev.sailresearch.com",
    ),
    "staging": _EnvDefaults(
        scheduler_url="sailbox-scheduler.staging.sailresearch.com:443",
        imagebuilder_url="sailbox-imagebuilder-dispatcher.staging.sailresearch.com:443",
        api_url="https://staging.sailresearch.com",
        sailbox_ingress_url="https://staging.sailresearch.com",
    ),
    "local": _EnvDefaults(
        scheduler_url="localhost:50051",
        imagebuilder_url="localhost:50061",
        api_url="https://dev.sailresearch.com",
        sailbox_ingress_url="http://localhost:18080",
    ),
}


def _read_mode() -> str:
    """Return the normalized SAIL_MODE.

    Empty string means "no mode declared" and is treated as prod by from_env().
    Any non-empty value must match one of _ENV_DEFAULTS; unrecognized values raise.
    """
    mode = os.environ.get("SAIL_MODE", "").strip().lower()
    if mode and mode not in _ENV_DEFAULTS:
        raise ValueError(
            f"SAIL_MODE={mode!r} is not recognized; "
            "use SAIL_MODE=prod|dev|staging|local"
        )
    return mode


class Config:
    """SDK configuration loaded from environment variables.

    SAIL_MODE selects a named environment (prod|dev|staging|local); when
    unset the prod defaults are used. Endpoints can be overridden via
    SAIL_SCHEDULER_URL, SAIL_IMAGEBUILDER_URL, and SAIL_API_URL.
    SAIL_SCHEDULER_URL and SAIL_IMAGEBUILDER_URL must be set together since
    they are deployed as a pair. In prod/dev/staging the REST API and the
    sailbox worker ingress are served from the same host, so SAIL_API_URL
    also drives the ingress URL; see from_env() for the local-mode
    exception.
    """

    def __init__(
        self,
        *,
        scheduler_url: str,
        imagebuilder_url: str,
        api_key: str,
        api_url: str,
        sailbox_ingress_url: str,
    ) -> None:
        self.scheduler_url = scheduler_url
        self.imagebuilder_url = imagebuilder_url
        self.api_key = api_key
        self.api_url = api_url
        self.sailbox_ingress_url = sailbox_ingress_url

    @classmethod
    def from_env(cls) -> Config:
        return cls._from_env(require_api_key=True)

    @classmethod
    def from_env_optional_api_key(cls) -> Config:
        """Load SDK config without requiring SAIL_API_KEY.

        This is intentionally separate from from_env() so existing Sailbox,
        App, and Image callers keep requiring an API key by default.
        """
        return cls._from_env(require_api_key=False)

    @classmethod
    def _from_env(cls, *, require_api_key: bool) -> Config:
        defaults = _ENV_DEFAULTS[_read_mode() or "prod"]

        scheduler_override = os.environ.get("SAIL_SCHEDULER_URL", "").strip()
        imagebuilder_override = os.environ.get("SAIL_IMAGEBUILDER_URL", "").strip()
        if bool(scheduler_override) != bool(imagebuilder_override):
            set_var, unset_var = (
                ("SAIL_SCHEDULER_URL", "SAIL_IMAGEBUILDER_URL")
                if scheduler_override
                else ("SAIL_IMAGEBUILDER_URL", "SAIL_SCHEDULER_URL")
            )
            raise ValueError(
                f"{set_var} is set but {unset_var} is not; "
                "set both to override together, or unset both to use mode defaults."
            )

        api_key = os.environ.get("SAIL_API_KEY", "")
        if require_api_key and not api_key:
            raise ValueError("SAIL_API_KEY must be set")

        api_url_override = os.environ.get("SAIL_API_URL", "").strip()

        # SAIL_API_URL also retargets the worker ingress, but only in modes
        # whose defaults already point both fields at the same host
        # (prod/dev/staging) -- so a self-hosted user can point at their
        # cluster with one env var. Local mode is the exception: its
        # defaults intentionally split api_url (remote dev API) from
        # sailbox_ingress_url (a tunnel running on your laptop, set up by
        # `just redeploy-sailbox-dev`). Pulling the ingress along with
        # SAIL_API_URL there would break listener polling against the
        # tunnel, so we leave it pinned to the local default. The
        # coupled-vs-split distinction is inferred from _ENV_DEFAULTS so a
        # future profile that diverges the two hosts gets this for free.
        if defaults.api_url == defaults.sailbox_ingress_url:
            sailbox_ingress_url = api_url_override or defaults.sailbox_ingress_url
        else:
            sailbox_ingress_url = defaults.sailbox_ingress_url

        return cls(
            scheduler_url=scheduler_override or defaults.scheduler_url,
            imagebuilder_url=imagebuilder_override or defaults.imagebuilder_url,
            api_key=api_key,
            api_url=api_url_override or defaults.api_url,
            sailbox_ingress_url=sailbox_ingress_url,
        )
