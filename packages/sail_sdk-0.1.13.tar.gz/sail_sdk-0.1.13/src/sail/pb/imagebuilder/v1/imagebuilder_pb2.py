"""Generated protocol buffer code."""

from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder

_runtime_version.ValidateProtobufRuntimeVersion(
    _runtime_version.Domain.PUBLIC, 6, 31, 1, "", "imagebuilder/v1/imagebuilder.proto"
)
_sym_db = _symbol_database.Default()
from ...image.v1 import image_pb2 as image_dot_v1_dot_image__pb2

DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(
    b'\n"imagebuilder/v1/imagebuilder.proto\x12\x0fimagebuilder.v1\x1a\x14image/v1/image.proto"7\n\x11BuildImageRequest\x12"\n\x05image\x18\x01 \x01(\x0b2\x13.image.v1.ImageSpec"i\n\x12BuildImageResponse\x12\x10\n\x08image_id\x18\x01 \x01(\t\x12*\n\x06status\x18\x02 \x01(\x0e2\x1a.image.v1.ImageBuildStatus\x12\x15\n\rerror_message\x18\x03 \x01(\t".\n\x1aGetImageBuildStatusRequest\x12\x10\n\x08image_id\x18\x01 \x01(\t"r\n\x1bGetImageBuildStatusResponse\x12\x10\n\x08image_id\x18\x01 \x01(\t\x12*\n\x06status\x18\x02 \x01(\x0e2\x1a.image.v1.ImageBuildStatus\x12\x15\n\rerror_message\x18\x03 \x01(\t2\xde\x01\n\x13ImageBuilderService\x12U\n\nBuildImage\x12".imagebuilder.v1.BuildImageRequest\x1a#.imagebuilder.v1.BuildImageResponse\x12p\n\x13GetImageBuildStatus\x12+.imagebuilder.v1.GetImageBuildStatusRequest\x1a,.imagebuilder.v1.GetImageBuildStatusResponseBLZJgithub.com/sailresearchco/sail/backend/internal/sailbox/imagebuilder/pb;pbb\x06proto3'
)
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(
    DESCRIPTOR, "imagebuilder.v1.imagebuilder_pb2", _globals
)
if not _descriptor._USE_C_DESCRIPTORS:
    _globals["DESCRIPTOR"]._loaded_options = None
    _globals["DESCRIPTOR"]._serialized_options = (
        b"ZJgithub.com/sailresearchco/sail/backend/internal/sailbox/imagebuilder/pb;pb"
    )
    _globals["_BUILDIMAGEREQUEST"]._serialized_start = 77
    _globals["_BUILDIMAGEREQUEST"]._serialized_end = 132
    _globals["_BUILDIMAGERESPONSE"]._serialized_start = 134
    _globals["_BUILDIMAGERESPONSE"]._serialized_end = 239
    _globals["_GETIMAGEBUILDSTATUSREQUEST"]._serialized_start = 241
    _globals["_GETIMAGEBUILDSTATUSREQUEST"]._serialized_end = 287
    _globals["_GETIMAGEBUILDSTATUSRESPONSE"]._serialized_start = 289
    _globals["_GETIMAGEBUILDSTATUSRESPONSE"]._serialized_end = 403
    _globals["_IMAGEBUILDERSERVICE"]._serialized_start = 406
    _globals["_IMAGEBUILDERSERVICE"]._serialized_end = 628
