from __future__ import annotations

import random
import sys
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import grpc
from sail._client import Client
from sail.errors import ImageBuildError
from sail.pb.image.v1 import image_pb2
from sail.pb.imagebuilder.v1 import imagebuilder_pb2

_IMAGEBUILDER_RETRY_DELAYS_SECONDS = (1.0, 2.0, 4.0)


@dataclass(frozen=True)
class ImageDefinition:
    _spec: image_pb2.ImageSpec
    _image_id: Optional[str] = field(default=None)
    _skip_imagebuilder_build: bool = field(default=False)

    def to_proto(self) -> image_pb2.ImageSpec:
        return self._spec

    def apt_install(self, *packages: str) -> ImageDefinition:
        cleaned = _clean_packages(packages, "apt_install")
        step = image_pb2.ImageBuildStep(
            apt_install=image_pb2.PackageInstall(packages=cleaned)
        )
        return self._append_step(step)

    def pip_install(self, *packages: str) -> ImageDefinition:
        cleaned = _clean_packages(packages, "pip_install")
        step = image_pb2.ImageBuildStep(
            pip_install=image_pb2.PackageInstall(packages=cleaned)
        )
        return self._append_step(step)

    def run_commands(self, *cmd: str) -> ImageDefinition:
        if not cmd:
            raise ValueError("run_commands requires at least one command")
        steps = []
        for entry in cmd:
            cleaned = entry.strip()
            if not cleaned:
                raise ValueError("run_commands commands must be non-empty")
            steps.append(
                image_pb2.ImageBuildStep(
                    run_command=image_pb2.RunCommand(command=cleaned)
                )
            )
        image = self
        for step in steps:
            image = image._append_step(step)
        return image

    def env(self, env: Dict[str, str]) -> ImageDefinition:
        if not env:
            raise ValueError("env requires at least one key")
        next_spec = image_pb2.ImageSpec()
        next_spec.CopyFrom(self._spec)
        _ensure_local_python_version(next_spec)
        for key, value in env.items():
            clean_key = key.strip()
            if not clean_key:
                raise ValueError("env keys must be non-empty")
            next_spec.env[clean_key] = value
        return ImageDefinition(next_spec)

    def build(self, *, timeout: int = 1800) -> ImageDefinition:
        if timeout <= 0:
            raise ValueError("timeout must be greater than 0")

        client = Client.get()
        spec = image_pb2.ImageSpec()
        spec.CopyFrom(self.to_proto())
        _ensure_local_python_version(spec)
        metadata = client.metadata()
        deadline = time.monotonic() + timeout
        resp = _build_image_with_socket_close_retries(
            client.imagebuilder_stub,
            spec,
            metadata,
            deadline,
        )
        image_id = resp.image_id

        while True:
            _raise_if_imagebuilder_deadline_exceeded(
                deadline, f"timed out waiting for image build {image_id}"
            )
            status = resp.status
            if status == image_pb2.IMAGE_BUILD_STATUS_READY:
                return ImageDefinition(spec, _image_id=image_id)
            if status == image_pb2.IMAGE_BUILD_STATUS_FAILED:
                raise ImageBuildError(resp.error_message or "image build failed")
            _sleep_until_imagebuilder_deadline(
                _next_build_poll_delay(),
                deadline,
                f"timed out waiting for image build {image_id}",
            )
            resp = _get_image_build_status_with_socket_close_retries(
                client.imagebuilder_stub,
                image_id,
                metadata,
                deadline,
            )

    def _ensure_built(self, *, timeout: int = 1800) -> ImageDefinition:
        if self._image_id is not None or self._skip_imagebuilder_build:
            return self
        return self.build(timeout=timeout)

    def _append_step(self, step: image_pb2.ImageBuildStep) -> ImageDefinition:
        next_spec = image_pb2.ImageSpec()
        next_spec.CopyFrom(self._spec)
        _ensure_local_python_version(next_spec)
        next_spec.build_steps.append(step)
        return ImageDefinition(next_spec)


def _clean_packages(packages: Tuple[str, ...], method: str) -> List[str]:
    if not packages:
        raise ValueError(f"{method} requires at least one package")
    cleaned: List[str] = []
    for package in packages:
        entry = package.strip()
        if not entry:
            raise ValueError(f"{method} packages must be non-empty")
        cleaned.append(entry)
    return cleaned


def _local_python_version() -> str:
    return f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"


def _ensure_local_python_version(spec: image_pb2.ImageSpec) -> None:
    if not spec.python_version:
        spec.python_version = _local_python_version()


def _next_build_poll_delay() -> float:
    return 1.0 + random.uniform(0.0, 0.25)


def _build_image_with_socket_close_retries(stub, spec, metadata, deadline):
    """Build an image, retrying only imagebuilder socket-close transport races."""
    timeout_message = "timed out waiting for image build to start"
    for delay in (*_IMAGEBUILDER_RETRY_DELAYS_SECONDS, None):
        _raise_if_imagebuilder_deadline_exceeded(deadline, timeout_message)
        try:
            return stub.BuildImage(
                imagebuilder_pb2.BuildImageRequest(image=spec),
                metadata=metadata,
            )
        except grpc.RpcError as exc:
            if delay is None or not _is_imagebuilder_socket_close(exc):
                raise
            _sleep_until_imagebuilder_deadline(delay, deadline, timeout_message)


def _get_image_build_status_with_socket_close_retries(
    stub, image_id, metadata, deadline
):
    """Fetch image build status, retrying only imagebuilder socket-close races."""
    timeout_message = f"timed out waiting for image build {image_id}"
    for delay in (*_IMAGEBUILDER_RETRY_DELAYS_SECONDS, None):
        _raise_if_imagebuilder_deadline_exceeded(deadline, timeout_message)
        try:
            return stub.GetImageBuildStatus(
                imagebuilder_pb2.GetImageBuildStatusRequest(image_id=image_id),
                metadata=metadata,
            )
        except grpc.RpcError as exc:
            if delay is None or not _is_imagebuilder_socket_close(exc):
                raise
            _sleep_until_imagebuilder_deadline(delay, deadline, timeout_message)


def _sleep_until_imagebuilder_deadline(
    delay: float, deadline: float, timeout_message: str
) -> None:
    """Sleep for at most the remaining imagebuilder timeout budget."""
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise TimeoutError(timeout_message)
    time.sleep(min(delay, remaining))
    _raise_if_imagebuilder_deadline_exceeded(deadline, timeout_message)


def _raise_if_imagebuilder_deadline_exceeded(
    deadline: float, timeout_message: str
) -> None:
    """Raise TimeoutError once imagebuilder build timeout budget is exhausted."""
    if time.monotonic() >= deadline:
        raise TimeoutError(timeout_message)


def _is_imagebuilder_socket_close(exc: grpc.RpcError) -> bool:
    """Return true for the transient imagebuilder socket-close errors we retry."""
    if exc.code() != grpc.StatusCode.UNAVAILABLE:
        return False
    details = (exc.details() or "").lower()
    return "socket closed" in details or "transport is closing" in details


class _ImageNamespace:
    @property
    def debian_amd64(self) -> ImageDefinition:
        return ImageDefinition(
            image_pb2.ImageSpec(
                base=image_pb2.BASE_IMAGE_DEBIAN,
                architecture=image_pb2.IMAGE_ARCHITECTURE_AMD64,
            ),
            _skip_imagebuilder_build=True,
        )

    @property
    def debian_amd(self) -> ImageDefinition:
        return self.debian_amd64

    @property
    def debian_arm64(self) -> ImageDefinition:
        return ImageDefinition(
            image_pb2.ImageSpec(
                base=image_pb2.BASE_IMAGE_DEBIAN,
                architecture=image_pb2.IMAGE_ARCHITECTURE_ARM64,
            ),
            _skip_imagebuilder_build=True,
        )

    @property
    def debian_arm(self) -> ImageDefinition:
        return self.debian_arm64


Image = _ImageNamespace()
