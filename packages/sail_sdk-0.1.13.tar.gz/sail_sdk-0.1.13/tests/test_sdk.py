from __future__ import annotations

import json
import sys
import threading
from base64 import b64encode
from concurrent import futures
from http.server import BaseHTTPRequestHandler, HTTPServer

import cloudpickle
import grpc
import pytest

from sail._client import Client
from sail._config import Config
from sail._http_client import HTTPClient
from sail.app import App
from sail.errors import (
    ImageBuildError,
    SailboxCreationError,
    SailboxExecAlreadyRunningError,
    SailboxExecutionError,
    SailboxFunctionError,
    SailboxFunctionSerializationError,
    SailboxExecRequestNotFoundError,
    SailboxTerminatedError,
)
from sail.function import SailFunction, function
from sail.image import Image, ImageDefinition
from sail.pb.image.v1 import image_pb2
from sail.pb.imagebuilder.v1 import imagebuilder_pb2, imagebuilder_pb2_grpc
from sail.pb.scheduler.v1 import scheduler_pb2, scheduler_pb2_grpc
from sail.pb.workerproxy.v1 import workerproxy_pb2, workerproxy_pb2_grpc
from sail.sailbox import (
    FUNCTION_RESULT_PREFIX,
    FUNCTION_RUNTIME_PREFIX,
    Sailbox,
    SailboxExecRequest,
)
from sail.sailbox import _REMOTE_FUNCTION_RUNTIME_READY


class FakeScheduler(scheduler_pb2_grpc.SchedulerServiceServicer):
    """In-process gRPC server that simulates the scheduler."""

    def __init__(
        self,
        *,
        worker_address: str,
        create_status: int = scheduler_pb2.SAILBOX_STATUS_RUNNING,
        error_message: str = "",
        terminate_error: tuple[grpc.StatusCode, str] | None = None,
        stop_error: tuple[grpc.StatusCode, str] | None = None,
        checkpoint_error: tuple[grpc.StatusCode, str] | None = None,
        start_error: tuple[grpc.StatusCode, str] | None = None,
        start_status: int = scheduler_pb2.SAILBOX_STATUS_RUNNING,
    ):
        self.worker_address = worker_address
        self.create_status = create_status
        self.error_message = error_message
        self.terminate_error = terminate_error
        self.stop_error = stop_error
        self.checkpoint_error = checkpoint_error
        self.start_error = start_error
        self.start_status = start_status
        self.last_metadata: dict[str, str] = {}
        self.last_create_request: scheduler_pb2.CreateSailboxRequest | None = None
        self.last_stop_request: scheduler_pb2.StopSailboxRequest | None = None
        self.last_checkpoint_request: scheduler_pb2.CheckpointSailboxRequest | None = (
            None
        )
        self.last_resume_request: scheduler_pb2.ResumeSailboxRequest | None = None

    def CreateSailbox(self, request, context):
        md = dict(context.invocation_metadata())
        self.last_metadata = md
        self.last_create_request = request
        return scheduler_pb2.CreateSailboxResponse(
            sailbox_id="sb-test-123",
            status=self.create_status,
            worker_address=(
                self.worker_address
                if self.create_status == scheduler_pb2.SAILBOX_STATUS_RUNNING
                else ""
            ),
            vm_id=(
                "vm-abc-123"
                if self.create_status == scheduler_pb2.SAILBOX_STATUS_RUNNING
                else ""
            ),
            exec_proxy_endpoint=self.worker_address,
            error_message=(
                self.error_message
                if self.create_status == scheduler_pb2.SAILBOX_STATUS_FAILED
                else ""
            ),
        )

    def GetSailboxStatus(self, request, context):
        md = dict(context.invocation_metadata())
        self.last_metadata = md
        return scheduler_pb2.GetSailboxStatusResponse(
            sailbox_id=request.sailbox_id,
            status=scheduler_pb2.SAILBOX_STATUS_RUNNING,
            worker_address="10.0.0.1:8732",
            vm_id="vm-abc-123",
        )

    def TerminateSailbox(self, request, context):
        if self.terminate_error is not None:
            context.abort(self.terminate_error[0], self.terminate_error[1])
        return scheduler_pb2.TerminateSailboxResponse(
            status=scheduler_pb2.SAILBOX_STATUS_TERMINATED,
        )

    def StopSailbox(self, request, context):
        self.last_stop_request = request
        if self.stop_error is not None:
            context.abort(self.stop_error[0], self.stop_error[1])
        status = scheduler_pb2.SAILBOX_STATUS_STOPPED
        if request.wake_on_traffic:
            status = scheduler_pb2.SAILBOX_STATUS_SLEEPING
        return scheduler_pb2.StopSailboxResponse(
            status=status,
        )

    def CheckpointSailbox(self, request, context):
        self.last_checkpoint_request = request
        if self.checkpoint_error is not None:
            context.abort(self.checkpoint_error[0], self.checkpoint_error[1])
        return scheduler_pb2.CheckpointSailboxResponse(
            status=scheduler_pb2.SAILBOX_STATUS_RUNNING,
            checkpoint_generation=1,
        )

    def ResumeSailbox(self, request, context):
        self.last_resume_request = request
        if self.start_error is not None:
            context.abort(self.start_error[0], self.start_error[1])
        return scheduler_pb2.ResumeSailboxResponse(
            resume_state=scheduler_pb2.SAILBOX_RESUME_STATE_RUNNING,
            status=self.start_status,
            worker_address=self.worker_address,
            worker_internal_address=self.worker_address,
            vm_id="vm-restored-123",
        )

    def GetVMStats(self, request, context):
        return scheduler_pb2.GetVMStatsResponse(vm_stats=[])


class FakeImagebuilder(imagebuilder_pb2_grpc.ImageBuilderServiceServicer):
    """In-process gRPC server that simulates the imagebuilder."""

    def __init__(self) -> None:
        self.last_metadata: dict[str, str] = {}
        self.last_build_request: imagebuilder_pb2.BuildImageRequest | None = None
        self.build_call_count = 0
        self.status_call_count = 0
        self.build_errors: list[tuple[grpc.StatusCode, str]] = []
        self.status_errors: list[tuple[grpc.StatusCode, str]] = []
        self.build_status_sequence: list[int] = [
            image_pb2.IMAGE_BUILD_STATUS_READY,
        ]
        self.build_error_message = ""
        self.image_id = "sha256:test-image"

    def _next_status(self) -> int:
        status = self.build_status_sequence[0]
        if len(self.build_status_sequence) > 1:
            self.build_status_sequence = self.build_status_sequence[1:]
        return status

    def BuildImage(self, request, context):
        self.build_call_count += 1
        self.last_metadata = dict(context.invocation_metadata())
        self.last_build_request = request
        if self.build_errors:
            code, details = self.build_errors.pop(0)
            context.abort(code, details)
        return imagebuilder_pb2.BuildImageResponse(
            image_id=self.image_id,
            status=self._next_status(),
            error_message=self.build_error_message,
        )

    def GetImageBuildStatus(self, request, context):
        self.status_call_count += 1
        self.last_metadata = dict(context.invocation_metadata())
        if self.status_errors:
            code, details = self.status_errors.pop(0)
            context.abort(code, details)
        return imagebuilder_pb2.GetImageBuildStatusResponse(
            image_id=request.image_id,
            status=self._next_status(),
            error_message=self.build_error_message,
        )


class FakeWorker(workerproxy_pb2_grpc.WorkerProxyServiceServicer):
    def __init__(
        self,
        *,
        exec_error=None,
        exec_errors=None,
        wait_error=None,
        wait_errors=None,
        wait_stdout="hi\n",
        wait_stdout_sequence=None,
        wait_stderr="",
        wait_stderr_sequence=None,
        wait_returncode=0,
        wait_returncode_sequence=None,
        listener_error=None,
        listener_statuses=None,
        listener_public_url: str | None = None,
    ):
        self.last_metadata: dict[str, str] = {}
        self.last_exec_request: workerproxy_pb2.ExecSailboxRequest | None = None
        self.exec_requests: list[workerproxy_pb2.ExecSailboxRequest] = []
        self.exec_error = exec_error
        self.exec_errors = list(exec_errors or [])
        self.wait_error = wait_error
        self.wait_errors = list(wait_errors or [])
        self.wait_call_count = 0
        self.wait_stdout = wait_stdout
        self.wait_stdout_sequence = list(wait_stdout_sequence or [])
        self.wait_stderr = wait_stderr
        self.wait_stderr_sequence = list(wait_stderr_sequence or [])
        self.wait_returncode = wait_returncode
        self.wait_returncode_sequence = list(wait_returncode_sequence or [])
        self.listener_error = listener_error
        self.network_requests: dict[str, workerproxy_pb2.NetworkRequest] = {}
        self.listener_statuses = list(
            listener_statuses or [workerproxy_pb2.LISTENER_ROUTE_STATUS_ACTIVE]
        )
        self.listener_public_url = listener_public_url
        self.listener_call_count = 0

    def ExecSailbox(self, request, context):
        self.last_metadata = dict(context.invocation_metadata())
        self.last_exec_request = request
        self.exec_requests.append(request)
        if self.exec_errors:
            code, details = self.exec_errors.pop(0)
            context.abort(code, details)
        if self.exec_error is not None:
            context.abort(self.exec_error[0], self.exec_error[1])
        return workerproxy_pb2.ExecSailboxResponse(exec_request_id="exec-123")

    def WaitSailboxExec(self, request, context):
        self.last_metadata = dict(context.invocation_metadata())
        self.wait_call_count += 1
        if self.wait_errors:
            code, details = self.wait_errors.pop(0)
            context.abort(code, details)
        if self.wait_error is not None:
            context.abort(self.wait_error[0], self.wait_error[1])
        stdout = (
            self.wait_stdout_sequence.pop(0)
            if self.wait_stdout_sequence
            else self.wait_stdout
        )
        stderr = (
            self.wait_stderr_sequence.pop(0)
            if self.wait_stderr_sequence
            else self.wait_stderr
        )
        returncode = (
            self.wait_returncode_sequence.pop(0)
            if self.wait_returncode_sequence
            else self.wait_returncode
        )
        return workerproxy_pb2.WaitSailboxExecResponse(
            exec_request_id=request.exec_request_id,
            status=workerproxy_pb2.SAILBOX_EXEC_STATUS_SUCCEEDED,
            stdout=stdout,
            stderr=stderr,
            return_code=returncode,
        )

    def CreateNetworkRequest(self, request, context):
        self.last_network_request = request
        req = workerproxy_pb2.NetworkRequest(
            request_id="nr-test-123",
            sailbox_id=request.sailbox_id,
            method=request.method,
            url=request.url,
            params=request.params,
            headers=request.headers,
            request_body=request.request_body,
            timeout_seconds=request.timeout_seconds,
            durability_mode=request.durability_mode,
            idempotency_key=request.idempotency_key,
            status=workerproxy_pb2.NETWORK_REQUEST_STATUS_COMPLETED,
            response_status_code=200,
            response_headers=[
                workerproxy_pb2.HTTPHeader(
                    name="Content-Type", value="application/json"
                )
            ],
            response_body=b'{"ok":true}',
        )
        self.network_requests[req.request_id] = req
        return workerproxy_pb2.CreateNetworkRequestResponse(request=req)

    def GetNetworkRequest(self, request, context):
        return workerproxy_pb2.GetNetworkRequestResponse(
            request=self.network_requests[request.request_id]
        )

    def WaitNetworkRequest(self, request, context):
        return workerproxy_pb2.WaitNetworkRequestResponse(
            request=self.network_requests[request.request_id]
        )

    def RetryNetworkRequest(self, request, context):
        original = self.network_requests[request.request_id]
        retried = workerproxy_pb2.NetworkRequest()
        retried.CopyFrom(original)
        retried.request_id = "nr-test-retry"
        self.network_requests[retried.request_id] = retried
        return workerproxy_pb2.RetryNetworkRequestResponse(request=retried)

    def CancelNetworkRequest(self, request, context):
        canceled = workerproxy_pb2.NetworkRequest(
            request_id=request.request_id,
            sailbox_id=request.sailbox_id,
            status=workerproxy_pb2.NETWORK_REQUEST_STATUS_CANCELED,
        )
        self.network_requests[request.request_id] = canceled
        return workerproxy_pb2.CancelNetworkRequestResponse(request=canceled)

    def GetListener(self, request, context):
        if self.listener_error is not None:
            context.abort(self.listener_error[0], self.listener_error[1])
        status = self.listener_statuses[
            min(self.listener_call_count, len(self.listener_statuses) - 1)
        ]
        self.listener_call_count += 1
        return workerproxy_pb2.GetListenerResponse(
            listener=workerproxy_pb2.Listener(
                guest_port=request.guest_port,
                public_url=(
                    self.listener_public_url
                    if self.listener_public_url is not None
                    else f"https://{request.sailbox_id}-{request.guest_port}.sandbox.test"
                ),
                protocol="http",
                route_status=status,
            )
        )

    def ListListeners(self, request, context):
        return workerproxy_pb2.ListListenersResponse(
            listeners=[
                workerproxy_pb2.Listener(
                    guest_port=3000,
                    public_url=f"https://{request.sailbox_id}-3000.sandbox.test",
                    protocol="http",
                    route_status=workerproxy_pb2.LISTENER_ROUTE_STATUS_ACTIVE,
                )
            ]
        )


def _start_server(servicer):
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=2))
    scheduler_pb2_grpc.add_SchedulerServiceServicer_to_server(servicer, server)
    port = server.add_insecure_port("localhost:0")
    server.start()
    return server, port


def _start_imagebuilder(servicer):
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=2))
    imagebuilder_pb2_grpc.add_ImageBuilderServiceServicer_to_server(servicer, server)
    port = server.add_insecure_port("localhost:0")
    server.start()
    return server, port


def _start_worker(worker):
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=2))
    port = server.add_insecure_port("localhost:0")
    workerproxy_pb2_grpc.add_WorkerProxyServiceServicer_to_server(worker, server)
    server.start()
    return server, port


# Config.from_env() raises when exactly one of SAIL_SCHEDULER_URL /
# SAIL_IMAGEBUILDER_URL is set, so every gRPC fixture must stub whichever
# URL it isn't actively serving. "localhost:0" is a bind-only sentinel that
# satisfies the both-or-neither rule without dialing a live endpoint.


@pytest.fixture()
def _stub_scheduler_env(monkeypatch):
    monkeypatch.setenv("SAIL_SCHEDULER_URL", "localhost:0")


@pytest.fixture()
def _stub_imagebuilder_env(monkeypatch):
    monkeypatch.setenv("SAIL_IMAGEBUILDER_URL", "localhost:0")


@pytest.fixture()
def fake_imagebuilder(monkeypatch, _stub_scheduler_env):
    """Start a fake imagebuilder and point the SDK at it."""
    servicer = FakeImagebuilder()
    server, port = _start_imagebuilder(servicer)
    monkeypatch.setenv("SAIL_IMAGEBUILDER_URL", f"localhost:{port}")
    monkeypatch.setenv("SAIL_API_KEY", "test_key_123")
    yield servicer
    server.stop(grace=0)


@pytest.fixture()
def fake_scheduler(monkeypatch, _stub_imagebuilder_env):
    """Start a fake scheduler that immediately returns RUNNING on first poll."""
    worker = FakeWorker()
    worker_server, worker_port = _start_worker(worker)

    servicer = FakeScheduler(worker_address=f"localhost:{worker_port}")
    server, port = _start_server(servicer)
    monkeypatch.setenv("SAIL_SCHEDULER_URL", f"localhost:{port}")
    monkeypatch.setenv("SAIL_API_KEY", "test_key_123")
    yield servicer, worker
    server.stop(grace=0)
    worker_server.stop(grace=0)


@pytest.fixture()
def fake_scheduler_and_imagebuilder(monkeypatch):
    """Start fake scheduler and imagebuilder endpoints for create-with-build tests."""
    worker = FakeWorker()
    worker_server, worker_port = _start_worker(worker)

    scheduler = FakeScheduler(worker_address=f"localhost:{worker_port}")
    scheduler_server, scheduler_port = _start_server(scheduler)

    imagebuilder = FakeImagebuilder()
    imagebuilder_server, imagebuilder_port = _start_imagebuilder(imagebuilder)

    monkeypatch.setenv("SAIL_SCHEDULER_URL", f"localhost:{scheduler_port}")
    monkeypatch.setenv("SAIL_IMAGEBUILDER_URL", f"localhost:{imagebuilder_port}")
    monkeypatch.setenv("SAIL_API_KEY", "test_key_123")
    yield scheduler, imagebuilder
    scheduler_server.stop(grace=0)
    imagebuilder_server.stop(grace=0)
    worker_server.stop(grace=0)


@pytest.fixture()
def worker_error_scheduler(monkeypatch, _stub_imagebuilder_env):
    worker = FakeWorker(
        exec_error=(
            grpc.StatusCode.FAILED_PRECONDITION,
            "another exec request is already running for this sailbox",
        ),
        wait_error=(grpc.StatusCode.NOT_FOUND, 'exec request "missing" not found'),
    )
    worker_server, worker_port = _start_worker(worker)

    servicer = FakeScheduler(worker_address=f"localhost:{worker_port}")
    server, port = _start_server(servicer)
    monkeypatch.setenv("SAIL_SCHEDULER_URL", f"localhost:{port}")
    monkeypatch.setenv("SAIL_API_KEY", "test_key_123")
    yield servicer, worker
    server.stop(grace=0)
    worker_server.stop(grace=0)


@pytest.fixture()
def missing_wait_scheduler(monkeypatch, _stub_imagebuilder_env):
    worker = FakeWorker(
        wait_error=(grpc.StatusCode.NOT_FOUND, 'exec request "missing" not found'),
    )
    worker_server, worker_port = _start_worker(worker)

    servicer = FakeScheduler(worker_address=f"localhost:{worker_port}")
    server, port = _start_server(servicer)
    monkeypatch.setenv("SAIL_SCHEDULER_URL", f"localhost:{port}")
    monkeypatch.setenv("SAIL_API_KEY", "test_key_123")
    yield servicer, worker
    server.stop(grace=0)
    worker_server.stop(grace=0)


@pytest.fixture()
def terminated_worker_scheduler(monkeypatch, _stub_imagebuilder_env):
    worker = FakeWorker(
        exec_error=(grpc.StatusCode.NOT_FOUND, "sailbox not found on this worker"),
    )
    worker_server, worker_port = _start_worker(worker)

    servicer = FakeScheduler(worker_address=f"localhost:{worker_port}")
    server, port = _start_server(servicer)
    monkeypatch.setenv("SAIL_SCHEDULER_URL", f"localhost:{port}")
    monkeypatch.setenv("SAIL_API_KEY", "test_key_123")
    yield servicer, worker
    server.stop(grace=0)
    worker_server.stop(grace=0)


@pytest.fixture()
def failing_scheduler(monkeypatch, _stub_imagebuilder_env):
    """Start a fake scheduler that returns FAILED."""
    servicer = FakeScheduler(
        worker_address="localhost:0",
        create_status=scheduler_pb2.SAILBOX_STATUS_FAILED,
        error_message="no capacity available",
    )
    server, port = _start_server(servicer)
    monkeypatch.setenv("SAIL_SCHEDULER_URL", f"localhost:{port}")
    monkeypatch.setenv("SAIL_API_KEY", "test_key_123")
    yield servicer
    server.stop(grace=0)


@pytest.fixture()
def already_terminated_scheduler(monkeypatch, _stub_imagebuilder_env):
    servicer = FakeScheduler(
        worker_address="localhost:0",
        terminate_error=(
            grpc.StatusCode.FAILED_PRECONDITION,
            "sailbox is SAILBOX_STATUS_TERMINATED and cannot be terminated",
        ),
    )
    server, port = _start_server(servicer)
    monkeypatch.setenv("SAIL_SCHEDULER_URL", f"localhost:{port}")
    monkeypatch.setenv("SAIL_API_KEY", "test_key_123")
    yield servicer
    server.stop(grace=0)


@pytest.fixture()
def terminated_resume_scheduler(monkeypatch, _stub_imagebuilder_env):
    servicer = FakeScheduler(
        worker_address="localhost:0",
        start_error=(
            grpc.StatusCode.FAILED_PRECONDITION,
            "sailbox sb-test-123 is SAILBOX_STATUS_TERMINATED and cannot be resumed",
        ),
    )
    server, port = _start_server(servicer)
    monkeypatch.setenv("SAIL_SCHEDULER_URL", f"localhost:{port}")
    monkeypatch.setenv("SAIL_API_KEY", "test_key_123")
    yield servicer
    server.stop(grace=0)


@pytest.fixture()
def missing_terminate_scheduler(monkeypatch, _stub_imagebuilder_env):
    servicer = FakeScheduler(
        worker_address="localhost:0",
        terminate_error=(grpc.StatusCode.NOT_FOUND, "sailbox not found"),
    )
    server, port = _start_server(servicer)
    monkeypatch.setenv("SAIL_SCHEDULER_URL", f"localhost:{port}")
    monkeypatch.setenv("SAIL_API_KEY", "test_key_123")
    yield servicer
    server.stop(grace=0)


@pytest.fixture(autouse=True)
def _reset_client():
    """Ensure the singleton client is reset between tests."""
    _REMOTE_FUNCTION_RUNTIME_READY.clear()
    yield
    Client.reset()
    HTTPClient.reset()
    _REMOTE_FUNCTION_RUNTIME_READY.clear()


# --- Sailbox.create ---


def test_create_returns_sailbox(fake_scheduler):
    fake_scheduler, _ = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    assert sb.sailbox_id == "sb-test-123"
    assert sb.name == "sandbox-1"
    assert sb.status == "running"
    assert sb.worker_address == fake_scheduler.worker_address
    assert sb.exec_endpoint == fake_scheduler.worker_address


def test_create_with_all_args(fake_scheduler):
    fake_scheduler, _ = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="my-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
        memory_mib=2048,
        cpu=2,
    )

    assert sb.sailbox_id == "sb-test-123"
    assert fake_scheduler.last_create_request.app_id == "app_test"
    assert fake_scheduler.last_create_request.cpu == 2
    assert fake_scheduler.last_create_request.memory_mib == 2048


def test_create_with_ingress_ports(fake_scheduler):
    fake_scheduler, _ = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="my-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
        ingress_ports=[3000, 8080],
    )

    assert sb.sailbox_id == "sb-test-123"
    assert list(fake_scheduler.last_create_request.ingress_ports) == [3000, 8080]


def test_create_with_disk_gib(fake_scheduler):
    fake_scheduler, _ = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="my-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
        disk_gib=8,
    )

    assert sb.sailbox_id == "sb-test-123"
    assert fake_scheduler.last_create_request.state_disk_size_gib == 8


def test_create_defaults_disk_gib_to_8(fake_scheduler):
    fake_scheduler, _ = fake_scheduler
    Sailbox.create(
        app=App(id="app_test", name="my-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    assert fake_scheduler.last_create_request.state_disk_size_gib == 8


def test_create_rejects_invalid_sizes(fake_scheduler):
    app = App(id="app_test", name="my-app", created_at=0)

    with pytest.raises(ValueError, match="cpu must be greater than 0"):
        Sailbox.create(app=app, image=Image.debian_amd64, name="sandbox-1", cpu=0)
    with pytest.raises(ValueError, match="memory_mib must be at least 1024"):
        Sailbox.create(
            app=app, image=Image.debian_amd64, name="sandbox-1", memory_mib=512
        )
    with pytest.raises(ValueError, match="memory_mib must be at most 65536"):
        Sailbox.create(
            app=app, image=Image.debian_amd64, name="sandbox-1", memory_mib=65537
        )
    with pytest.raises(ValueError, match="disk_gib must be greater than 0"):
        Sailbox.create(app=app, image=Image.debian_amd64, name="sandbox-1", disk_gib=0)
    with pytest.raises(ValueError, match="disk_gib must be at most 64"):
        Sailbox.create(app=app, image=Image.debian_amd64, name="sandbox-1", disk_gib=65)


def test_create_rejects_invalid_ingress_ports(fake_scheduler):
    app = App(id="app_test", name="my-app", created_at=0)

    with pytest.raises(ValueError, match="ingress_ports must be between 1 and 65535"):
        Sailbox.create(
            app=app,
            image=Image.debian_amd64,
            name="sandbox-1",
            ingress_ports=[0],
        )
    with pytest.raises(ValueError, match="reserved port 22"):
        Sailbox.create(
            app=app,
            image=Image.debian_amd64,
            name="sandbox-1",
            ingress_ports=[22],
        )
    with pytest.raises(ValueError, match="reserved port 10000"):
        Sailbox.create(
            app=app,
            image=Image.debian_amd64,
            name="sandbox-1",
            ingress_ports=[10000],
        )
    with pytest.raises(ValueError, match="ingress_ports must be unique"):
        Sailbox.create(
            app=app,
            image=Image.debian_amd64,
            name="sandbox-1",
            ingress_ports=[3000, 3000],
        )


def test_create_returns_running_without_polling(fake_scheduler):
    fake_scheduler, _ = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    assert sb.status == "running"


def test_create_failed_raises(failing_scheduler):
    with pytest.raises(SailboxCreationError, match="no capacity available"):
        Sailbox.create(
            app=App(id="app_test", name="test-app", created_at=0),
            image=Image.debian_amd64,
            name="sandbox-1",
        )


def test_create_serializes_debian_image(fake_scheduler):
    fake_scheduler, _ = fake_scheduler

    Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    assert fake_scheduler.last_create_request is not None
    assert fake_scheduler.last_create_request.image.base == image_pb2.BASE_IMAGE_DEBIAN


def test_create_requires_typed_image(fake_scheduler):
    with pytest.raises(TypeError, match="image must be a sail.Image value"):
        Sailbox.create(
            app=App(id="app_test", name="test-app", created_at=0),
            image="debian",  # type: ignore[arg-type]
            name="sandbox-1",
        )


def test_create_custom_image_builds_then_serializes_steps_and_env(
    fake_scheduler_and_imagebuilder, monkeypatch
):
    fake_scheduler, fake_imagebuilder = fake_scheduler_and_imagebuilder
    fake_imagebuilder.build_status_sequence = [
        image_pb2.IMAGE_BUILD_STATUS_QUEUED,
        image_pb2.IMAGE_BUILD_STATUS_BUILDING,
        image_pb2.IMAGE_BUILD_STATUS_READY,
    ]
    monkeypatch.setattr("sail.image.time.sleep", lambda _: None)
    monkeypatch.setattr("sail.image.random.uniform", lambda _a, _b: 0.0)

    image = (
        Image.debian_amd64.apt_install("git", "curl")
        .pip_install("numpy")
        .run_commands("echo ready", "touch /tmp/test")
        .env({"FOO": "bar", "HELLO": "world"})
    )
    Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=image,
        name="sandbox-1",
        image_build_timeout=5,
    )

    build_req = fake_imagebuilder.last_build_request
    assert build_req is not None
    assert len(build_req.image.build_steps) == 4
    assert (
        build_req.image.python_version
        == f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    )
    assert build_req.image.build_steps[0].apt_install.packages == ["git", "curl"]
    assert build_req.image.build_steps[1].pip_install.packages == ["numpy"]
    assert build_req.image.build_steps[2].run_command.command == "echo ready"
    assert build_req.image.build_steps[3].run_command.command == "touch /tmp/test"
    assert dict(build_req.image.env) == {"FOO": "bar", "HELLO": "world"}
    assert build_req.image.architecture == image_pb2.IMAGE_ARCHITECTURE_AMD64

    req = fake_scheduler.last_create_request
    assert req is not None
    assert len(req.image.build_steps) == 4
    assert (
        req.image.python_version
        == f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    )
    assert req.image.build_steps[0].apt_install.packages == ["git", "curl"]
    assert req.image.build_steps[1].pip_install.packages == ["numpy"]
    assert req.image.build_steps[2].run_command.command == "echo ready"
    assert req.image.build_steps[3].run_command.command == "touch /tmp/test"
    assert dict(req.image.env) == {"FOO": "bar", "HELLO": "world"}
    assert req.image.architecture == image_pb2.IMAGE_ARCHITECTURE_AMD64


def test_create_stock_image_skips_imagebuilder(fake_scheduler):
    fake_scheduler, _ = fake_scheduler

    Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_arm64,
        name="sandbox-1",
    )

    assert fake_scheduler.last_create_request is not None
    assert (
        fake_scheduler.last_create_request.image.architecture
        == image_pb2.IMAGE_ARCHITECTURE_ARM64
    )
    assert fake_scheduler.last_create_request.image.python_version == ""


def test_create_custom_image_preserves_arm64_architecture(
    fake_scheduler_and_imagebuilder, monkeypatch
):
    fake_scheduler, fake_imagebuilder = fake_scheduler_and_imagebuilder
    fake_imagebuilder.build_status_sequence = [image_pb2.IMAGE_BUILD_STATUS_READY]
    monkeypatch.setattr("sail.image.time.sleep", lambda _: None)

    Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_arm64.pip_install("numpy"),
        name="sandbox-1",
        image_build_timeout=5,
    )

    assert fake_imagebuilder.last_build_request is not None
    assert (
        fake_imagebuilder.last_build_request.image.architecture
        == image_pb2.IMAGE_ARCHITECTURE_ARM64
    )
    assert fake_scheduler.last_create_request is not None
    assert (
        fake_scheduler.last_create_request.image.architecture
        == image_pb2.IMAGE_ARCHITECTURE_ARM64
    )


def test_create_custom_image_build_failure_raises(
    fake_scheduler_and_imagebuilder,
):
    fake_scheduler, fake_imagebuilder = fake_scheduler_and_imagebuilder
    fake_imagebuilder.build_status_sequence = [image_pb2.IMAGE_BUILD_STATUS_FAILED]
    fake_imagebuilder.build_error_message = "apt-get failed"

    with pytest.raises(ImageBuildError, match="apt-get failed"):
        Sailbox.create(
            app=App(id="app_test", name="test-app", created_at=0),
            image=Image.debian_amd64.apt_install("git"),
            name="sandbox-1",
        )

    assert fake_scheduler.last_create_request is None


def test_create_wraps_imagebuilder_transport_errors(fake_scheduler, monkeypatch):
    monkeypatch.setenv("SAIL_IMAGEBUILDER_URL", "localhost:0")

    with pytest.raises(SailboxCreationError, match="failed to connect"):
        Sailbox.create(
            app=App(id="app_test", name="test-app", created_at=0),
            image=Image.debian_amd64.pip_install("numpy"),
            name="sandbox-1",
        )


def test_create_custom_image_polls_until_ready(
    fake_scheduler_and_imagebuilder, monkeypatch
):
    fake_scheduler, fake_imagebuilder = fake_scheduler_and_imagebuilder
    fake_imagebuilder.build_status_sequence = [
        image_pb2.IMAGE_BUILD_STATUS_QUEUED,
        image_pb2.IMAGE_BUILD_STATUS_BUILDING,
        image_pb2.IMAGE_BUILD_STATUS_READY,
    ]
    monkeypatch.setattr("sail.image.time.sleep", lambda _: None)
    monkeypatch.setattr("sail.image.random.uniform", lambda _a, _b: 0.0)

    Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64.pip_install("numpy"),
        name="sandbox-1",
        image_build_timeout=5,
    )

    assert fake_imagebuilder.last_build_request is not None
    assert fake_imagebuilder.last_build_request.image.build_steps[
        0
    ].pip_install.packages == ["numpy"]
    assert (
        fake_imagebuilder.last_build_request.image.architecture
        == image_pb2.IMAGE_ARCHITECTURE_AMD64
    )
    assert fake_scheduler.last_create_request is not None


def test_arm64_base_image_build_uses_arm64_architecture(fake_imagebuilder, monkeypatch):
    fake_imagebuilder.build_status_sequence = [image_pb2.IMAGE_BUILD_STATUS_READY]
    monkeypatch.setattr("sail.image.time.sleep", lambda _: None)

    Image.debian_arm64.pip_install("numpy").build(timeout=5)

    assert fake_imagebuilder.last_build_request is not None
    assert (
        fake_imagebuilder.last_build_request.image.architecture
        == image_pb2.IMAGE_ARCHITECTURE_ARM64
    )


def test_image_build_failure_raises(fake_imagebuilder):
    fake_imagebuilder.build_status_sequence = [image_pb2.IMAGE_BUILD_STATUS_FAILED]
    fake_imagebuilder.build_error_message = "apt-get failed"

    with pytest.raises(ImageBuildError, match="apt-get failed"):
        Image.debian_amd64.apt_install("git").build(timeout=5)


def test_image_build_retries_transient_build_socket_close(
    fake_imagebuilder, monkeypatch
):
    fake_imagebuilder.build_errors = [
        (
            grpc.StatusCode.UNAVAILABLE,
            "failed to connect to all addresses; last error: UNAVAILABLE: "
            "ipv4:127.0.0.1:443: Socket closed",
        )
    ]
    monkeypatch.setattr("sail.image.time.sleep", lambda _: None)

    image = Image.debian_arm64.pip_install("numpy").build(timeout=5)

    assert image._image_id == "sha256:test-image"
    assert fake_imagebuilder.build_call_count == 2


def test_image_build_retries_transient_status_socket_close(
    fake_imagebuilder, monkeypatch
):
    fake_imagebuilder.build_status_sequence = [
        image_pb2.IMAGE_BUILD_STATUS_QUEUED,
        image_pb2.IMAGE_BUILD_STATUS_READY,
    ]
    fake_imagebuilder.status_errors = [
        (
            grpc.StatusCode.UNAVAILABLE,
            "failed to connect to all addresses; last error: UNAVAILABLE: "
            "ipv4:127.0.0.1:443: Socket closed",
        )
    ]
    monkeypatch.setattr("sail.image.time.sleep", lambda _: None)
    monkeypatch.setattr("sail.image.random.uniform", lambda _a, _b: 0.0)

    image = Image.debian_amd64.pip_install("numpy").build(timeout=5)

    assert image._image_id == "sha256:test-image"
    assert fake_imagebuilder.status_call_count == 2


def test_image_build_retry_sleep_is_capped_by_timeout(fake_imagebuilder, monkeypatch):
    fake_imagebuilder.build_status_sequence = [
        image_pb2.IMAGE_BUILD_STATUS_QUEUED,
        image_pb2.IMAGE_BUILD_STATUS_READY,
    ]
    fake_imagebuilder.status_errors = [
        (
            grpc.StatusCode.UNAVAILABLE,
            "failed to connect to all addresses; last error: UNAVAILABLE: "
            "ipv4:127.0.0.1:443: Socket closed",
        )
    ]
    now = 100.0
    sleeps: list[float] = []

    def fake_monotonic():
        return now

    def fake_sleep(seconds):
        nonlocal now
        sleeps.append(seconds)
        now += seconds

    monkeypatch.setattr("sail.image.time.monotonic", fake_monotonic)
    monkeypatch.setattr("sail.image.time.sleep", fake_sleep)
    monkeypatch.setattr("sail.image.random.uniform", lambda _a, _b: 0.0)

    with pytest.raises(TimeoutError, match="timed out waiting for image build"):
        Image.debian_amd64.pip_install("numpy").build(timeout=1.25)

    assert sleeps == pytest.approx([1.0, 0.25])
    assert fake_imagebuilder.status_call_count == 1


def test_image_build_remains_public_api(fake_imagebuilder, monkeypatch):
    fake_imagebuilder.build_status_sequence = [
        image_pb2.IMAGE_BUILD_STATUS_QUEUED,
        image_pb2.IMAGE_BUILD_STATUS_BUILDING,
        image_pb2.IMAGE_BUILD_STATUS_READY,
    ]
    monkeypatch.setattr("sail.image.time.sleep", lambda _: None)
    monkeypatch.setattr("sail.image.random.uniform", lambda _a, _b: 0.0)

    image = Image.debian_amd64.pip_install("numpy").build(timeout=5)

    assert image._image_id == "sha256:test-image"
    assert fake_imagebuilder.last_build_request is not None
    assert fake_imagebuilder.last_build_request.image.build_steps[
        0
    ].pip_install.packages == ["numpy"]


# --- terminate ---


def test_terminate(fake_scheduler):
    _, _worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )
    # Should not raise.
    sb.terminate()


def test_terminate_already_terminated_is_noop(already_terminated_scheduler):
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    sb.terminate()


def test_terminate_missing_sailbox_is_noop(missing_terminate_scheduler):
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    sb.terminate()


# --- pause/resume ---


def test_pause_calls_scheduler(fake_scheduler):
    scheduler, _worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    sb.pause()

    assert scheduler.last_stop_request is not None
    assert scheduler.last_stop_request.sailbox_id == "sb-test-123"
    assert not scheduler.last_stop_request.wake_on_traffic
    assert sb.status == "paused"


def test_sleep_calls_scheduler_with_wake_on_traffic(fake_scheduler):
    scheduler, _worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    sb.sleep()

    assert scheduler.last_stop_request is not None
    assert scheduler.last_stop_request.sailbox_id == "sb-test-123"
    assert scheduler.last_stop_request.wake_on_traffic
    assert sb.status == "sleeping"


def test_exec_rejects_paused_handle(fake_scheduler):
    _scheduler, _worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    sb.pause()

    with pytest.raises(SailboxExecutionError, match="call resume\\(\\) before exec"):
        sb.exec("echo hi")


def test_checkpoint_calls_scheduler(fake_scheduler):
    scheduler, _worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    sb.checkpoint()

    assert scheduler.last_checkpoint_request is not None
    assert scheduler.last_checkpoint_request.sailbox_id == "sb-test-123"


def test_resume_calls_scheduler(fake_scheduler):
    scheduler, _worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    started = sb.resume()

    assert scheduler.last_resume_request is not None
    assert scheduler.last_resume_request.sailbox_id == "sb-test-123"
    assert started is sb
    assert started.status == "running"
    assert sb.status == "running"


def test_resume_terminated_sailbox_raises(terminated_resume_scheduler):
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    with pytest.raises(SailboxCreationError, match="cannot be resumed"):
        sb.resume()


# --- auth ---


def _function_success_stdout(value, *, stdout: str = "", stderr: str = "") -> str:
    envelope = {
        "ok": True,
        "result": b64encode(cloudpickle.dumps(value)).decode("ascii"),
        "stdout": stdout,
        "stderr": stderr,
    }
    return FUNCTION_RESULT_PREFIX + json.dumps(envelope, separators=(",", ":")) + "\n"


def _function_runtime_stdout(
    python: str = "/usr/local/bin/python3",
    *,
    version: str = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
) -> str:
    envelope = {"python": python, "version": version}
    return FUNCTION_RUNTIME_PREFIX + json.dumps(envelope, separators=(",", ":")) + "\n"


def _function_error_stdout(
    *,
    error_type: str = "ValueError",
    error_message: str = "bad value",
    stdout: str = "",
    stderr: str = "",
) -> str:
    envelope = {
        "ok": False,
        "error_type": error_type,
        "error_message": error_message,
        "traceback": "Traceback (most recent call last):\nValueError: bad value\n",
        "stdout": stdout,
        "stderr": stderr,
    }
    return FUNCTION_RESULT_PREFIX + json.dumps(envelope, separators=(",", ":")) + "\n"


def _function_test_image():
    image = Image.debian_amd64.run_commands("true")
    return ImageDefinition(image.to_proto(), _image_id="sha256:test-function-image")


def test_bearer_token_sent(fake_scheduler):
    fake_scheduler, _ = fake_scheduler
    Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    assert fake_scheduler.last_metadata.get("authorization") == "Bearer test_key_123"


def test_exec_and_wait(fake_scheduler):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    req = sb.exec("echo hi", timeout=5)
    result = req.wait()

    assert req.exec_request_id == "exec-123"
    assert worker.last_exec_request.argv == ["/bin/sh", "-lc", "echo hi"]
    assert worker.last_metadata.get("authorization") == "Bearer test_key_123"
    assert result.stdout == "hi\n"
    assert result.stderr == ""
    assert result.returncode == 0


def test_exec_retries_transient_accept_error_with_idempotency_key(
    fake_scheduler, monkeypatch
):
    _scheduler, worker = fake_scheduler
    monkeypatch.setattr("sail.sailbox.time.sleep", lambda _seconds: None)
    worker.exec_errors = [(grpc.StatusCode.UNAVAILABLE, "Endpoint closing")]
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    req = sb.exec("cat /tmp/progress.json", idempotency_key="poll-1")

    assert req.exec_request_id == "exec-123"
    assert req.idempotency_key == "poll-1"
    assert len(worker.exec_requests) == 2
    assert [request.idempotency_key for request in worker.exec_requests] == [
        "poll-1",
        "poll-1",
    ]


def test_exec_generates_idempotency_key(fake_scheduler):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    req = sb.exec("echo hi")

    assert req.idempotency_key.startswith("exec_")
    assert worker.last_exec_request.idempotency_key == req.idempotency_key


def test_wait_retries_transient_error(fake_scheduler, monkeypatch):
    _scheduler, worker = fake_scheduler
    monkeypatch.setattr("sail.sailbox.time.sleep", lambda _seconds: None)
    worker.wait_errors = [(grpc.StatusCode.UNAVAILABLE, "Endpoint closing")]
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    result = sb.exec("echo hi").wait()

    assert result.stdout == "hi\n"
    assert worker.wait_call_count == 2


def test_exec_without_timeout_sends_zero(fake_scheduler):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    req = sb.exec("echo hi")

    assert req.background is False
    assert worker.last_exec_request.timeout_seconds == 0


def test_background_exec_wraps_command(fake_scheduler):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    req = sb.exec("python3 -m http.server 3000", background=True)

    assert req.background is True
    assert worker.last_exec_request.timeout_seconds == 0
    assert worker.last_exec_request.argv == [
        "/bin/sh",
        "-lc",
        "nohup /bin/sh -lc 'python3 -m http.server 3000' </dev/null >/dev/null 2>&1 &",
    ]


def test_exec_supports_cwd(fake_scheduler):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    sb.exec("python3 -m http.server 3000", cwd="/srv/app")

    assert worker.last_exec_request.argv == [
        "/bin/sh",
        "-lc",
        "cd /srv/app && exec /bin/sh -lc 'python3 -m http.server 3000'",
    ]


def test_background_exec_supports_cwd(fake_scheduler):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    sb.exec("python3 -m http.server 3000", background=True, cwd="/srv/app")

    assert worker.last_exec_request.argv == [
        "/bin/sh",
        "-lc",
        "nohup /bin/sh -lc 'cd /srv/app && exec /bin/sh -lc '\"'\"'python3 -m http.server 3000'\"'\"'' </dev/null >/dev/null 2>&1 &",
    ]


def test_function_decorator_forms():
    @function
    def plain():
        return "plain"

    @function()
    def called():
        return "called"

    assert isinstance(plain, SailFunction)
    assert isinstance(called, SailFunction)
    assert plain() == "plain"
    assert called() == "called"


def test_function_exec_returns_value(fake_scheduler):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=_function_test_image(),
        name="sandbox-1",
    )
    worker.wait_stdout_sequence = [
        _function_runtime_stdout(),
        _function_success_stdout({"sum": 5}),
    ]

    @function()
    def add(x, y):
        return {"sum": x + y}

    result = sb.exec(add, 2, 3, timeout=5, idempotency_key="fn-add")

    assert result == {"sum": 5}
    assert len(worker.exec_requests) == 2
    assert "cloudpickle==3.1.2" in worker.exec_requests[0].argv[2]
    assert (
        f"target = '{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}'"
        in worker.exec_requests[0].argv[2]
    )
    assert "uv python install" not in worker.exec_requests[0].argv[2]
    assert worker.exec_requests[1].timeout_seconds == 5
    assert worker.exec_requests[1].idempotency_key == "fn-add"
    assert worker.exec_requests[1].argv[2].startswith("/usr/local/bin/python3 - <<")
    assert "__SAIL_FUNCTION_RESULT__" in worker.exec_requests[1].argv[2]


def test_function_exec_rejects_non_custom_image(fake_scheduler):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    @function()
    def add():
        return 1

    with pytest.raises(SailboxFunctionSerializationError, match="custom images"):
        sb.exec(add)
    assert worker.exec_requests == []


def test_function_exec_supports_args_and_kwargs(fake_scheduler):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=_function_test_image(),
        name="sandbox-1",
    )
    worker.wait_stdout_sequence = [
        _function_runtime_stdout(),
        _function_success_stdout("hello bob"),
    ]

    @function()
    def greet(name, *, prefix):
        return f"{prefix} {name}"

    assert sb.exec(greet, args=("bob",), kwargs={"prefix": "hello"}) == "hello bob"


def test_function_exec_caches_runtime_setup_per_sailbox(fake_scheduler):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=_function_test_image(),
        name="sandbox-1",
    )
    worker.wait_stdout_sequence = [
        _function_runtime_stdout(),
        _function_success_stdout(1),
        _function_success_stdout(2),
    ]

    @function()
    def value():
        return 1

    assert sb.exec(value) == 1
    assert sb.exec(value) == 2
    assert len(worker.exec_requests) == 3
    assert sum("cloudpickle==3.1.2" in req.argv[2] for req in worker.exec_requests) == 1


def test_function_exec_rejects_background(fake_scheduler):
    _scheduler, _worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=_function_test_image(),
        name="sandbox-1",
    )

    @function()
    def add():
        return 1

    with pytest.raises(ValueError, match="background=True"):
        sb.exec(add, background=True)


def test_function_exec_rejects_undecorated_callable(fake_scheduler):
    _scheduler, _worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    def add():
        return 1

    with pytest.raises(TypeError, match="@sail.function"):
        sb.exec(add)  # type: ignore[arg-type]


def test_function_exec_setup_failure_raises(fake_scheduler):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=_function_test_image(),
        name="sandbox-1",
    )
    worker.wait_returncode_sequence = [1]
    worker.wait_stderr_sequence = ["pip failed"]

    @function()
    def add():
        return 1

    with pytest.raises(SailboxFunctionSerializationError, match="pip failed"):
        sb.exec(add)


def test_function_exec_setup_failure_can_retry_with_fresh_idempotency_key(
    fake_scheduler,
):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=_function_test_image(),
        name="sandbox-1",
    )
    worker.wait_returncode_sequence = [1, 0, 0]
    worker.wait_stderr_sequence = ["pip failed", "", ""]
    worker.wait_stdout_sequence = [
        "",
        _function_runtime_stdout(),
        _function_success_stdout(1),
    ]

    @function()
    def add():
        return 1

    with pytest.raises(SailboxFunctionSerializationError, match="pip failed"):
        sb.exec(add)

    assert sb.exec(add) == 1
    setup_requests = [
        request
        for request in worker.exec_requests
        if "cloudpickle==3.1.2" in request.argv[2]
    ]
    assert len(setup_requests) == 2
    assert setup_requests[0].idempotency_key != setup_requests[1].idempotency_key
    assert all(
        request.idempotency_key.startswith("exec_") for request in setup_requests
    )


def test_function_exec_remote_exception_raises(fake_scheduler):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=_function_test_image(),
        name="sandbox-1",
    )
    worker.wait_stdout_sequence = [
        _function_runtime_stdout(),
        _function_error_stdout(stdout="before\n", stderr="warn\n"),
    ]

    @function()
    def bad():
        raise ValueError("bad value")

    with pytest.raises(SailboxFunctionError, match="ValueError: bad value") as exc:
        sb.exec(bad)

    assert exc.value.error_type == "ValueError"
    assert exc.value.stdout == "before\n"
    assert exc.value.stderr == "warn\n"
    assert "Traceback" in exc.value.traceback


def test_function_exec_invalid_envelope_raises(fake_scheduler):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=_function_test_image(),
        name="sandbox-1",
    )
    worker.wait_stdout_sequence = [_function_runtime_stdout(), "not an envelope\n"]
    worker.wait_stderr_sequence = ["", "ModuleNotFoundError: cloudpickle"]
    worker.wait_returncode_sequence = [0, 1]

    @function()
    def add():
        return 1

    with pytest.raises(
        SailboxFunctionSerializationError, match="valid result envelope"
    ):
        sb.exec(add)


def test_exec_already_running_raises(worker_error_scheduler):
    _scheduler, _worker = worker_error_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    with pytest.raises(SailboxExecAlreadyRunningError):
        sb.exec("echo hi", timeout=5)


def test_wait_missing_exec_request_raises(missing_wait_scheduler):
    _scheduler, _worker = missing_wait_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )
    req = sb.exec("echo hi", timeout=5)
    missing_req = SailboxExecRequest(
        sailbox_id=req.sailbox_id,
        exec_request_id="missing",
        exec_endpoint=req.exec_endpoint,
    )

    with pytest.raises(SailboxExecRequestNotFoundError):
        missing_req.wait()


def test_exec_on_terminated_sailbox_raises(terminated_worker_scheduler):
    _scheduler, _worker = terminated_worker_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    with pytest.raises(
        SailboxTerminatedError,
        match="this is likely because this Sailbox is no longer running",
    ):
        sb.exec("echo hi", timeout=5)


# --- config ---


def test_config_from_env(monkeypatch):
    monkeypatch.setenv("SAIL_SCHEDULER_URL", "scheduler.example.com:9090")
    monkeypatch.setenv("SAIL_IMAGEBUILDER_URL", "imagebuilder.example.com:9091")
    monkeypatch.setenv("SAIL_API_KEY", "key_abc")
    cfg = Config.from_env()
    assert cfg.scheduler_url == "scheduler.example.com:9090"
    assert cfg.imagebuilder_url == "imagebuilder.example.com:9091"
    assert cfg.api_key == "key_abc"


def test_config_rejects_scheduler_override_without_imagebuilder(monkeypatch):
    monkeypatch.setenv("SAIL_SCHEDULER_URL", "scheduler.example.com:9090")
    monkeypatch.delenv("SAIL_IMAGEBUILDER_URL", raising=False)
    monkeypatch.delenv("SAIL_MODE", raising=False)
    monkeypatch.setenv("SAIL_API_KEY", "key_abc")
    with pytest.raises(ValueError, match="SAIL_IMAGEBUILDER_URL"):
        Config.from_env()


def test_config_rejects_imagebuilder_override_without_scheduler(monkeypatch):
    monkeypatch.setenv("SAIL_IMAGEBUILDER_URL", "imagebuilder.example.com:9091")
    monkeypatch.delenv("SAIL_SCHEDULER_URL", raising=False)
    monkeypatch.delenv("SAIL_MODE", raising=False)
    monkeypatch.setenv("SAIL_API_KEY", "key_abc")
    with pytest.raises(ValueError, match="SAIL_SCHEDULER_URL"):
        Config.from_env()


def test_config_rejects_unrecognized_mode(monkeypatch):
    monkeypatch.setenv("SAIL_MODE", "deev")
    monkeypatch.setenv("SAIL_API_KEY", "key_abc")
    with pytest.raises(ValueError, match="SAIL_MODE"):
        Config.from_env()


def test_config_rejects_partial_override_with_mode_set(monkeypatch):
    """The both-or-neither rule applies regardless of SAIL_MODE."""
    monkeypatch.setenv("SAIL_SCHEDULER_URL", "scheduler.example.com:9090")
    monkeypatch.delenv("SAIL_IMAGEBUILDER_URL", raising=False)
    monkeypatch.setenv("SAIL_MODE", "dev")
    monkeypatch.setenv("SAIL_API_KEY", "key_abc")
    with pytest.raises(ValueError, match="SAIL_IMAGEBUILDER_URL"):
        Config.from_env()


def test_config_accepts_both_urls_overridden(monkeypatch):
    monkeypatch.setenv("SAIL_SCHEDULER_URL", "scheduler.example.com:9090")
    monkeypatch.setenv("SAIL_IMAGEBUILDER_URL", "imagebuilder.example.com:9091")
    monkeypatch.delenv("SAIL_MODE", raising=False)
    monkeypatch.setenv("SAIL_API_KEY", "key_abc")
    cfg = Config.from_env()
    assert cfg.scheduler_url == "scheduler.example.com:9090"
    assert cfg.imagebuilder_url == "imagebuilder.example.com:9091"


def test_config_defaults_to_prod(monkeypatch):
    monkeypatch.delenv("SAIL_SCHEDULER_URL", raising=False)
    monkeypatch.delenv("SAIL_IMAGEBUILDER_URL", raising=False)
    monkeypatch.delenv("SAIL_API_URL", raising=False)
    monkeypatch.setenv("SAIL_API_KEY", "key_abc")
    monkeypatch.delenv("SAIL_MODE", raising=False)
    cfg = Config.from_env()
    assert cfg.scheduler_url == "sailbox-scheduler.sailresearch.com:443"
    assert (
        cfg.imagebuilder_url == "sailbox-imagebuilder-dispatcher.sailresearch.com:443"
    )
    assert cfg.api_url == "https://api.sailresearch.com"
    assert cfg.sailbox_ingress_url == "https://api.sailresearch.com"


def test_config_uses_prod_mode_defaults(monkeypatch):
    monkeypatch.delenv("SAIL_SCHEDULER_URL", raising=False)
    monkeypatch.delenv("SAIL_IMAGEBUILDER_URL", raising=False)
    monkeypatch.delenv("SAIL_API_URL", raising=False)
    monkeypatch.setenv("SAIL_MODE", "prod")
    monkeypatch.setenv("SAIL_API_KEY", "key_abc")
    cfg = Config.from_env()
    assert cfg.scheduler_url == "sailbox-scheduler.sailresearch.com:443"
    assert (
        cfg.imagebuilder_url == "sailbox-imagebuilder-dispatcher.sailresearch.com:443"
    )
    assert cfg.api_url == "https://api.sailresearch.com"
    assert cfg.sailbox_ingress_url == "https://api.sailresearch.com"


def test_config_uses_dev_mode_defaults(monkeypatch):
    monkeypatch.delenv("SAIL_SCHEDULER_URL", raising=False)
    monkeypatch.delenv("SAIL_IMAGEBUILDER_URL", raising=False)
    monkeypatch.delenv("SAIL_API_URL", raising=False)
    monkeypatch.setenv("SAIL_MODE", "dev")
    monkeypatch.setenv("SAIL_API_KEY", "key_abc")
    cfg = Config.from_env()
    assert cfg.scheduler_url == "sailbox-scheduler.dev.sailresearch.com:443"
    assert (
        cfg.imagebuilder_url
        == "sailbox-imagebuilder-dispatcher.dev.sailresearch.com:443"
    )
    assert cfg.api_url == "https://dev.sailresearch.com"
    assert cfg.sailbox_ingress_url == "https://dev.sailresearch.com"


def test_config_uses_staging_mode_defaults(monkeypatch):
    monkeypatch.delenv("SAIL_SCHEDULER_URL", raising=False)
    monkeypatch.delenv("SAIL_IMAGEBUILDER_URL", raising=False)
    monkeypatch.delenv("SAIL_API_URL", raising=False)
    monkeypatch.setenv("SAIL_MODE", "staging")
    monkeypatch.setenv("SAIL_API_KEY", "key_abc")
    cfg = Config.from_env()
    assert cfg.scheduler_url == "sailbox-scheduler.staging.sailresearch.com:443"
    assert (
        cfg.imagebuilder_url
        == "sailbox-imagebuilder-dispatcher.staging.sailresearch.com:443"
    )
    assert cfg.api_url == "https://staging.sailresearch.com"
    assert cfg.sailbox_ingress_url == "https://staging.sailresearch.com"


def test_config_api_url_override_drives_ingress_when_coupled(monkeypatch):
    """In prod/dev/staging the API and ingress share a host, so a single
    SAIL_API_URL points both at a self-hosted cluster."""
    monkeypatch.delenv("SAIL_SCHEDULER_URL", raising=False)
    monkeypatch.setenv("SAIL_API_URL", "https://self-hosted.example.com")
    monkeypatch.setenv("SAIL_MODE", "dev")
    monkeypatch.setenv("SAIL_API_KEY", "key_abc")
    cfg = Config.from_env()
    assert cfg.api_url == "https://self-hosted.example.com"
    assert cfg.sailbox_ingress_url == "https://self-hosted.example.com"


def test_config_uses_local_mode_defaults(monkeypatch):
    monkeypatch.delenv("SAIL_SCHEDULER_URL", raising=False)
    monkeypatch.delenv("SAIL_IMAGEBUILDER_URL", raising=False)
    monkeypatch.delenv("SAIL_API_URL", raising=False)
    monkeypatch.setenv("SAIL_MODE", "local")
    monkeypatch.setenv("SAIL_API_KEY", "key_abc")
    cfg = Config.from_env()
    assert cfg.scheduler_url == "localhost:50051"
    assert cfg.imagebuilder_url == "localhost:50061"
    assert cfg.api_url == "https://dev.sailresearch.com"
    assert cfg.sailbox_ingress_url == "http://localhost:18080"


def test_config_local_mode_api_url_override_keeps_local_ingress(monkeypatch):
    monkeypatch.delenv("SAIL_SCHEDULER_URL", raising=False)
    monkeypatch.delenv("SAIL_IMAGEBUILDER_URL", raising=False)
    monkeypatch.setenv("SAIL_MODE", "local")
    monkeypatch.setenv("SAIL_API_URL", "https://remote-api.example.com")
    monkeypatch.setenv("SAIL_API_KEY", "key_abc")
    cfg = Config.from_env()
    assert cfg.api_url == "https://remote-api.example.com"
    assert cfg.sailbox_ingress_url == "http://localhost:18080"


def test_config_missing_key_raises(monkeypatch):
    monkeypatch.setenv("SAIL_SCHEDULER_URL", "host:1234")
    monkeypatch.setenv("SAIL_IMAGEBUILDER_URL", "host:5678")
    monkeypatch.delenv("SAIL_API_KEY", raising=False)
    with pytest.raises(ValueError, match="SAIL_API_KEY must be set"):
        Config.from_env()


# --- client singleton ---


def test_client_singleton(fake_scheduler):
    a = Client.get()
    b = Client.get()
    assert a is b

    Client.reset()
    assert Client._instance is None


class FakeAPIHandler(BaseHTTPRequestHandler):
    """HTTP handler that returns canned responses for /v1/apps/find."""

    server: HTTPServer
    response_status: int
    response_body: dict
    last_headers: dict
    last_body: dict

    def do_POST(self):
        content_length = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(content_length)) if content_length else {}
        self.server.last_headers = dict(self.headers)
        self.server.last_body = body

        status = self.server.response_status
        resp = json.dumps(self.server.response_body).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(resp)

    def log_message(self, format, *args):
        pass


@pytest.fixture()
def fake_api(monkeypatch, _stub_scheduler_env, _stub_imagebuilder_env):
    """Start a local HTTP server and configure SAIL_API_URL to point at it."""
    server = HTTPServer(("127.0.0.1", 0), FakeAPIHandler)
    server.response_status = 200
    server.response_body = {}
    server.last_headers = {}
    server.last_body = {}

    t = threading.Thread(target=server.serve_forever)
    t.daemon = True
    t.start()

    port = server.server_address[1]
    monkeypatch.setenv("SAIL_API_KEY", "test_key_456")
    monkeypatch.setenv("SAIL_API_URL", f"http://127.0.0.1:{port}")
    yield server
    server.shutdown()


@pytest.fixture(autouse=True)
def _reset_http_client():
    """Ensure the HTTP singleton is reset between tests."""
    yield
    HTTPClient.reset()


def test_app_find_existing(fake_api):
    fake_api.response_status = 200
    fake_api.response_body = {
        "id": "app_abc",
        "name": "my-app",
        "created_at": 1712102400,
    }

    app = App.find(name="my-app")

    assert app.id == "app_abc"
    assert app.name == "my-app"
    assert app.created_at == 1712102400


def test_app_find_mint_if_missing(fake_api):
    fake_api.response_status = 201
    fake_api.response_body = {
        "id": "app_new",
        "name": "new-app",
        "created_at": 1712102500,
    }

    app = App.find(name="new-app", mint_if_missing=True)

    assert app.id == "app_new"
    assert app.name == "new-app"
    assert fake_api.last_body == {"name": "new-app", "mint_if_missing": True}


def test_app_find_not_found(fake_api):
    fake_api.response_status = 404
    fake_api.response_body = {"error": {"message": "app not found"}}

    with pytest.raises(LookupError, match="not found"):
        App.find(name="missing-app")


def test_app_find_auth_header(fake_api):
    fake_api.response_status = 200
    fake_api.response_body = {"id": "app_x", "name": "x", "created_at": 0}

    App.find(name="x")

    assert fake_api.last_headers.get("Authorization") == "Bearer test_key_456"


def test_config_api_url_optional(monkeypatch):
    """Config provides a default API URL when none is set."""
    monkeypatch.setenv("SAIL_SCHEDULER_URL", "host:1234")
    monkeypatch.setenv("SAIL_IMAGEBUILDER_URL", "host:5678")
    monkeypatch.setenv("SAIL_API_KEY", "key_abc")
    monkeypatch.delenv("SAIL_MODE", raising=False)
    monkeypatch.delenv("SAIL_API_URL", raising=False)
    cfg = Config.from_env()
    assert cfg.api_url == "https://api.sailresearch.com"


def test_http_client_uses_default_api_url(monkeypatch):
    """HTTPClient falls back to the default API URL when none is set."""
    monkeypatch.setenv("SAIL_SCHEDULER_URL", "host:1234")
    monkeypatch.setenv("SAIL_IMAGEBUILDER_URL", "host:5678")
    monkeypatch.setenv("SAIL_API_KEY", "key_abc")
    monkeypatch.delenv("SAIL_MODE", raising=False)
    monkeypatch.delenv("SAIL_API_URL", raising=False)
    client = HTTPClient()
    assert client._config.api_url == "https://api.sailresearch.com"


def test_request_returns_response(fake_scheduler):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    op = sb.request(
        "POST",
        "https://example.com/api",
        json={"hello": "world"},
        idempotency_key="req-1",
    )
    assert op.id == "nr-test-123"
    assert op.status == "NETWORK_REQUEST_STATUS_COMPLETED"
    assert worker.last_network_request.idempotency_key == "req-1"

    refreshed = op.refresh()
    assert refreshed is op
    assert op.status == "NETWORK_REQUEST_STATUS_COMPLETED"
    assert op.response is not None
    assert op.response.json() == {"ok": True}
    assert refreshed.status == "NETWORK_REQUEST_STATUS_COMPLETED"
    assert refreshed.response is not None
    assert refreshed.response.json() == {"ok": True}

    completed = op.wait()
    assert completed is op
    assert op.status == "NETWORK_REQUEST_STATUS_COMPLETED"
    assert op.response is not None
    assert op.response.status_code == 200
    assert op.response.json() == {"ok": True}
    assert completed.status == "NETWORK_REQUEST_STATUS_COMPLETED"
    assert completed.response is not None
    assert completed.response.status_code == 200
    assert completed.response.json() == {"ok": True}


def test_request_cancel_returns_updated_handle(fake_scheduler):
    _scheduler, worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    op = sb.request("POST", "https://example.com/api", idempotency_key="req-2")
    canceled = op.cancel()

    assert canceled is op
    assert canceled.id == op.id
    assert canceled.status == "NETWORK_REQUEST_STATUS_CANCELED"
    assert canceled.response is None
    assert (
        worker.network_requests[op.id].status
        == workerproxy_pb2.NETWORK_REQUEST_STATUS_CANCELED
    )


def test_request_requires_idempotency_key(fake_scheduler):
    _scheduler, _worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    with pytest.raises(ValueError, match="idempotency_key must be non-empty"):
        sb.request("POST", "https://example.com/api")


def test_listener_lookup(fake_scheduler):
    _scheduler, _worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
        ingress_ports=[3000],
    )

    listener = sb.listener(3000)

    assert listener.port == 3000
    assert listener.url == "https://sb-test-123-3000.sandbox.test"


def test_listener_lookup_uses_ingress_url_fallback(monkeypatch, fake_scheduler):
    _scheduler, worker = fake_scheduler
    worker.listener_public_url = ""
    monkeypatch.setenv("SAIL_MODE", "local")
    Client.reset()
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
        ingress_ports=[3000],
    )

    listener = sb.listener(3000)

    assert listener.url == "http://localhost:18080/_sailbox/sb-test-123/3000"


def test_listener_lookup_not_found_has_actionable_error(fake_scheduler):
    _scheduler, worker = fake_scheduler
    worker.listener_error = (grpc.StatusCode.NOT_FOUND, "listener not found")
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
    )

    with pytest.raises(SailboxExecutionError, match=r"pass ingress_ports=\[3000\]"):
        sb.listener(3000)


def test_listener_status_fetches_latest_listener(fake_scheduler):
    _scheduler, worker = fake_scheduler
    worker.listener_statuses = [
        workerproxy_pb2.LISTENER_ROUTE_STATUS_PENDING,
        workerproxy_pb2.LISTENER_ROUTE_STATUS_ACTIVE,
    ]
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
        ingress_ports=[3000],
    )

    listener = sb.listener(3000)
    latest = listener.status()

    assert listener.route_status == "LISTENER_ROUTE_STATUS_PENDING"
    assert latest.route_status == "LISTENER_ROUTE_STATUS_ACTIVE"
    assert worker.listener_call_count == 2


def test_listener_wait_returns_active_listener(monkeypatch, fake_scheduler):
    _scheduler, worker = fake_scheduler
    monkeypatch.setattr(
        "sail.sailbox._listener_url_is_open", lambda *_args, **_kwargs: (True, "")
    )
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
        ingress_ports=[3000],
    )

    listener = sb.listener(3000).wait(timeout=1, poll_interval=0.01)

    assert listener.route_status == "LISTENER_ROUTE_STATUS_ACTIVE"
    assert worker.listener_call_count == 1


def test_listener_wait_polls_until_active(monkeypatch, fake_scheduler):
    _scheduler, worker = fake_scheduler
    worker.listener_statuses = [
        workerproxy_pb2.LISTENER_ROUTE_STATUS_PENDING,
        workerproxy_pb2.LISTENER_ROUTE_STATUS_PENDING,
        workerproxy_pb2.LISTENER_ROUTE_STATUS_ACTIVE,
    ]
    monkeypatch.setattr(
        "sail.sailbox._listener_url_is_open", lambda *_args, **_kwargs: (True, "")
    )
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
        ingress_ports=[3000],
    )
    monkeypatch.setattr("sail.sailbox.time.sleep", lambda _seconds: None)

    listener = sb.listener(3000).wait(timeout=1, poll_interval=0.01)

    assert listener.route_status == "LISTENER_ROUTE_STATUS_ACTIVE"
    assert worker.listener_call_count == 3


def test_listener_wait_times_out(monkeypatch, fake_scheduler):
    _scheduler, worker = fake_scheduler
    worker.listener_statuses = [workerproxy_pb2.LISTENER_ROUTE_STATUS_PENDING]
    monkeypatch.setattr(
        "sail.sailbox._listener_url_is_open", lambda *_args, **_kwargs: (True, "")
    )
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
        ingress_ports=[3000],
    )
    monkeypatch.setattr("sail.sailbox.time.sleep", lambda _seconds: None)

    with pytest.raises(
        TimeoutError, match="last status was LISTENER_ROUTE_STATUS_PENDING"
    ):
        sb.listener(3000).wait(timeout=0.01, poll_interval=0.01)


def test_listener_wait_polls_until_url_is_reachable(monkeypatch, fake_scheduler):
    _scheduler, worker = fake_scheduler
    probe_results = [
        (False, "HTTP 502: upstream unavailable"),
        (True, ""),
    ]
    monkeypatch.setattr(
        "sail.sailbox._listener_url_is_open",
        lambda *_args, **_kwargs: probe_results.pop(0),
    )
    monkeypatch.setattr("sail.sailbox.time.sleep", lambda _seconds: None)
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
        ingress_ports=[3000],
    )

    listener = sb.listener(3000).wait(timeout=1, poll_interval=0.01)

    assert listener.route_status == "LISTENER_ROUTE_STATUS_ACTIVE"
    assert worker.listener_call_count == 2
    assert probe_results == []


def test_listener_wait_validates_arguments(fake_scheduler):
    _scheduler, _worker = fake_scheduler
    sb = Sailbox.create(
        app=App(id="app_test", name="test-app", created_at=0),
        image=Image.debian_amd64,
        name="sandbox-1",
        ingress_ports=[3000],
    )
    listener = sb.listener(3000)

    with pytest.raises(ValueError, match="timeout must be positive"):
        listener.wait(timeout=0)
    with pytest.raises(ValueError, match="poll_interval must be positive"):
        listener.wait(poll_interval=0)


def test_sailbox_create_accepts_app_object(fake_scheduler):
    app = App(id="app_test", name="test-app", created_at=0)
    sb = Sailbox.create(app=app, image=Image.debian_amd64, name="sandbox-1")
    assert sb.sailbox_id == "sb-test-123"
