from __future__ import annotations

import gc
import io
import json
import threading
import time
import urllib.error
import weakref
from typing import Optional

import pytest

import sail
import sail._http_client as http_client_module
import sail.voyage as voyage_module
from sail._config import Config
from sail._http_client import HTTPClient

VOYAGE_ID = "voy_00000000-0000-0000-0000-000000000001"
ENV_VOYAGE_ID = "voy_00000000-0000-0000-0000-000000000002"


class FakeHTTPResponse:
    def __init__(self, *, status: int = 200, body: bytes = b'{"ok":true}') -> None:
        self.status = status
        self._body = body

    def read(self) -> bytes:
        return self._body

    def __enter__(self) -> "FakeHTTPResponse":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        return None


def make_config(*, api_key: str = "test_key_123") -> Config:
    return Config(
        scheduler_url="scheduler.example.com:443",
        imagebuilder_url="imagebuilder.example.com:443",
        api_key=api_key,
        api_url="https://api.example.com",
        sailbox_ingress_url="https://api.example.com",
    )


@pytest.fixture(autouse=True)
def reset_http_client() -> None:
    voyage_module._reset_for_tests()
    yield
    HTTPClient.reset()
    voyage_module._reset_for_tests()


def voyage_create_response(**overrides):
    data = {
        "id": VOYAGE_ID,
        "object": "sail.voyage",
        "status": "running",
        "name": "overnight eval",
        "sailbox_id": "sbx_default",
        "dashboard_url": "https://app.sailresearch.com/staging/voyages/" + VOYAGE_ID,
        "created_at": 1788200000,
    }
    data.update(overrides)
    return data


def voyage_detail_response(voyage_id: str = VOYAGE_ID, **overrides):
    data = voyage_create_response(id=voyage_id)
    data.update(
        {
            "metadata": {"source": "attach"},
            "started_at": 1788200000,
            "ended_at": None,
            "error": None,
        }
    )
    data.update(overrides)
    return data


class RecordingURLOpener:
    def __init__(self, responses):
        self.responses = list(responses)
        self.calls = []

    def __call__(self, req, **kwargs):
        self.calls.append((req, kwargs))
        if not self.responses:
            raise AssertionError("unexpected HTTP request")
        response = self.responses.pop(0)
        if isinstance(response, BaseException):
            raise response
        if callable(response):
            response = response(req, kwargs)
        status, body = response
        return FakeHTTPResponse(status=status, body=json.dumps(body).encode())


def install_recording_urlopen(monkeypatch, responses) -> RecordingURLOpener:
    opener = RecordingURLOpener(responses)
    monkeypatch.setattr(http_client_module.urllib.request, "urlopen", opener)
    return opener


def request_json(req):
    return json.loads(req.data.decode("utf-8"))


def make_voyage(
    *,
    voyage_id: str = VOYAGE_ID,
    client: Optional[HTTPClient] = None,
    start_background: bool = False,
    buffer_cap: int = 10_000,
    flush_interval: float = 1.0,
) -> sail.Voyage:
    return sail.Voyage(
        id=voyage_id,
        client=client or HTTPClient(make_config()),
        _start_background=start_background,
        _buffer_cap=buffer_cap,
        _flush_interval=flush_interval,
    )


def set_voyage_env(monkeypatch) -> None:
    monkeypatch.setenv("SAIL_API_KEY", "test_key_123")
    monkeypatch.setenv("SAIL_API_URL", "https://api.example.com")
    monkeypatch.delenv("SAIL_MODE", raising=False)
    monkeypatch.delenv("SAIL_VOYAGE_ID", raising=False)
    monkeypatch.delenv("SAILBOX_ID", raising=False)
    monkeypatch.delenv("SAIL_VOYAGE_DEBUG", raising=False)


def test_http_client_singleton_get_still_returns_client(monkeypatch):
    monkeypatch.setenv("SAIL_API_KEY", "key_abc")
    monkeypatch.delenv("SAIL_MODE", raising=False)
    monkeypatch.delenv("SAIL_API_URL", raising=False)

    a = HTTPClient.get()
    b = HTTPClient.get()

    assert a is b


def test_http_get_encodes_query(monkeypatch):
    calls = []

    def fake_urlopen(req):
        calls.append(req)
        return FakeHTTPResponse(body=b'{"result":"ok"}')

    monkeypatch.setattr(http_client_module.urllib.request, "urlopen", fake_urlopen)
    client = HTTPClient(make_config())

    status, data = client.get(
        "/v1/voyages",
        query={"limit": 10, "tag": ["alpha beta", "gamma"]},
    )

    assert status == 200
    assert data == {"result": "ok"}
    assert calls[0].full_url == (
        "https://api.example.com/v1/voyages?limit=10&tag=alpha+beta&tag=gamma"
    )
    assert calls[0].get_method() == "GET"


def test_http_post_merges_extra_headers_safely(monkeypatch):
    calls = []

    def fake_urlopen(req):
        calls.append(req)
        return FakeHTTPResponse()

    monkeypatch.setattr(http_client_module.urllib.request, "urlopen", fake_urlopen)
    client = HTTPClient(make_config(api_key="secret_key"))

    status, data = client.post(
        "/v1/voyages",
        {"name": "smoke"},
        headers={
            "Authorization": "Bearer attacker",
            "Content-Type": "text/plain",
            "X-Sail-Voyage-Id": "voy_00000000-0000-0000-0000-000000000000",
        },
    )

    assert status == 200
    assert data == {"ok": True}
    headers = {key.lower(): value for key, value in calls[0].header_items()}
    assert headers["authorization"] == "Bearer secret_key"
    assert headers["content-type"] == "application/json"
    assert headers["x-sail-voyage-id"] == "voy_00000000-0000-0000-0000-000000000000"


def test_http_timeout_passed_when_provided(monkeypatch):
    calls = []

    def fake_urlopen(req, **kwargs):
        calls.append((req, kwargs))
        return FakeHTTPResponse()

    monkeypatch.setattr(http_client_module.urllib.request, "urlopen", fake_urlopen)
    client = HTTPClient(make_config())

    client.get("/v1/voyages/voy_00000000-0000-0000-0000-000000000000", timeout=4.5)
    client.post("/v1/voyages", {"name": "timeout"}, timeout=8.0)

    assert calls[0][1] == {"timeout": 4.5}
    assert calls[1][1] == {"timeout": 8.0}


def test_http_timeout_omitted_by_default(monkeypatch):
    calls = []

    def fake_urlopen(req, **kwargs):
        calls.append((req, kwargs))
        return FakeHTTPResponse()

    monkeypatch.setattr(http_client_module.urllib.request, "urlopen", fake_urlopen)
    client = HTTPClient(make_config())

    client.post("/v1/voyages", {"name": "default-timeout"})

    assert calls[0][1] == {}


def test_config_optional_api_key_does_not_weaken_from_env(monkeypatch):
    monkeypatch.delenv("SAIL_API_KEY", raising=False)
    monkeypatch.delenv("SAIL_API_URL", raising=False)
    monkeypatch.delenv("SAIL_SCHEDULER_URL", raising=False)
    monkeypatch.delenv("SAIL_IMAGEBUILDER_URL", raising=False)
    monkeypatch.setenv("SAIL_MODE", "staging")

    with pytest.raises(ValueError, match="SAIL_API_KEY must be set"):
        Config.from_env()

    cfg = Config.from_env_optional_api_key()

    assert cfg.api_key == ""
    assert cfg.api_url == "https://staging.sailresearch.com"
    assert cfg.scheduler_url == "sailbox-scheduler.staging.sailresearch.com:443"


def test_config_from_env_still_requires_api_key_for_existing_callers(monkeypatch):
    monkeypatch.delenv("SAIL_API_KEY", raising=False)
    monkeypatch.delenv("SAIL_API_URL", raising=False)
    monkeypatch.delenv("SAIL_MODE", raising=False)

    with pytest.raises(ValueError, match="SAIL_API_KEY must be set"):
        Config.from_env()


def test_http_error_body_redacts_bearer_token(monkeypatch):
    api_key = "secret_token_123"

    def fake_urlopen(req):
        body = f"upstream saw Authorization: Bearer {api_key}".encode()
        raise urllib.error.HTTPError(
            req.full_url,
            500,
            "server error",
            {},
            io.BytesIO(body),
        )

    monkeypatch.setattr(http_client_module.urllib.request, "urlopen", fake_urlopen)
    client = HTTPClient(make_config(api_key=api_key))

    status, data = client.post("/v1/voyages", {"name": "redact"})

    assert status == 500
    message = data["error"]["message"]
    assert api_key not in message
    assert "Bearer [redacted]" in message


def test_http_json_error_body_redacts_bearer_token(monkeypatch):
    api_key = "secret_token_456"

    def fake_urlopen(req):
        body = json.dumps(
            {"error": {"message": f"bad bearer {api_key}", "token": api_key}}
        ).encode()
        raise urllib.error.HTTPError(
            req.full_url,
            401,
            "unauthorized",
            {},
            io.BytesIO(body),
        )

    monkeypatch.setattr(http_client_module.urllib.request, "urlopen", fake_urlopen)
    client = HTTPClient(make_config(api_key=api_key))

    status, data = client.get("/v1/voyages/voy_00000000-0000-0000-0000-000000000000")

    assert status == 401
    assert api_key not in json.dumps(data)
    assert data["error"]["token"] == "[redacted]"


def test_voyage_create_sends_post_and_sets_current(monkeypatch):
    set_voyage_env(monkeypatch)
    opener = install_recording_urlopen(
        monkeypatch,
        [
            (201, voyage_create_response()),
            (202, {"accepted": 1, "duplicate": 0, "status": "running"}),
        ],
    )

    voyage = sail.voyage.init(
        name="overnight eval",
        metadata={"suite": "smoke"},
    )

    assert isinstance(voyage, sail.Voyage)
    assert voyage.id == VOYAGE_ID
    assert sail.voyage.id() == VOYAGE_ID
    assert sail.voyage.dashboard_url() == (
        "https://app.sailresearch.com/staging/voyages/" + VOYAGE_ID
    )
    create_req, _ = opener.calls[0]
    assert create_req.get_method() == "POST"
    assert create_req.full_url == "https://api.example.com/v1/voyages"
    assert request_json(create_req) == {
        "name": "overnight eval",
        "metadata": {"suite": "smoke"},
    }
    assert voyage_module._buffered_events_for_tests(voyage) == []
    assert len(opener.calls) == 2
    voyage._stop_background_for_tests()


def test_voyage_create_uses_sailbox_id_default(monkeypatch):
    set_voyage_env(monkeypatch)
    monkeypatch.setenv("SAILBOX_ID", "sbx_env_default")
    opener = install_recording_urlopen(
        monkeypatch,
        [
            (201, voyage_create_response(sailbox_id="sbx_env_default")),
            (202, {"accepted": 1, "duplicate": 0, "status": "running"}),
        ],
    )

    voyage = sail.voyage.init(name="uses env sailbox")

    assert voyage.sailbox_id == "sbx_env_default"
    assert request_json(opener.calls[0][0]) == {
        "name": "uses env sailbox",
        "sailbox_id": "sbx_env_default",
    }
    voyage._stop_background_for_tests()


def test_voyage_create_metadata_must_be_json_object(monkeypatch):
    set_voyage_env(monkeypatch)
    opener = install_recording_urlopen(monkeypatch, [])

    with pytest.raises(ValueError, match="metadata must be a JSON object"):
        sail.voyage.init(metadata=["not", "an", "object"])  # type: ignore[arg-type]

    assert opener.calls == []


@pytest.mark.parametrize("value", [float("nan"), float("inf"), -float("inf")])
def test_voyage_create_metadata_rejects_non_finite_floats(monkeypatch, value):
    set_voyage_env(monkeypatch)
    opener = install_recording_urlopen(monkeypatch, [])

    with pytest.raises(ValueError, match="metadata must be JSON serializable"):
        sail.voyage.init(metadata={"value": value})

    assert opener.calls == []


def test_voyage_create_emits_started_once(monkeypatch):
    set_voyage_env(monkeypatch)
    opener = install_recording_urlopen(
        monkeypatch,
        [
            (201, voyage_create_response()),
            (202, {"accepted": 1, "duplicate": 0, "status": "running"}),
        ],
    )

    voyage = sail.voyage.init(name="auto-start")

    assert len(opener.calls) == 2
    start_req, start_kwargs = opener.calls[1]
    assert start_req.get_method() == "POST"
    assert start_req.full_url == (
        "https://api.example.com/v1/voyages/" + VOYAGE_ID + "/events"
    )
    assert (
        0 < start_kwargs["timeout"] <= voyage_module._BACKGROUND_FLUSH_TIMEOUT_SECONDS
    )
    body = request_json(start_req)
    assert len(body["events"]) == 1
    assert body["events"][0]["sequence_id"] == 1
    assert body["events"][0]["source"] == "sdk"
    assert body["events"][0]["kind"] == "voyage.started"
    assert body["events"][0]["level"] == "info"
    assert body["events"][0]["occurred_at"]


def test_voyage_create_started_validation_failure_does_not_lose_current(monkeypatch):
    set_voyage_env(monkeypatch)
    monkeypatch.setenv("SAIL_AGENT_ID", "a" * 129)
    opener = install_recording_urlopen(
        monkeypatch,
        [(201, voyage_create_response())],
    )

    voyage = sail.voyage.init(name="bad agent env")

    assert voyage.id == VOYAGE_ID
    assert sail.voyage.id() == VOYAGE_ID
    assert len(opener.calls) == 1
    assert voyage_module._buffered_events_for_tests(voyage) == []
    voyage._stop_background_for_tests()


def test_voyage_started_delivery_failure_does_not_lose_current(monkeypatch):
    set_voyage_env(monkeypatch)
    opener = install_recording_urlopen(
        monkeypatch,
        [
            (201, voyage_create_response()),
            (500, {"error": {"message": "append failed"}}),
        ],
    )

    voyage = sail.voyage.init(name="start failure")

    try:
        assert voyage.id == VOYAGE_ID
        assert sail.voyage.id() == VOYAGE_ID
        assert len(opener.calls) == 2
        assert [
            event["kind"] for event in voyage_module._buffered_events_for_tests(voyage)
        ] == ["voyage.started"]
    finally:
        voyage._stop_background_for_tests()


def test_voyage_attach_by_param_gets_existing_voyage(monkeypatch):
    set_voyage_env(monkeypatch)
    opener = install_recording_urlopen(
        monkeypatch,
        [(200, voyage_detail_response())],
    )

    voyage = sail.voyage.init(voyage_id=VOYAGE_ID)

    assert voyage.id == VOYAGE_ID
    assert voyage.metadata == {"source": "attach"}
    assert sail.voyage.id() == VOYAGE_ID
    assert len(opener.calls) == 1
    req, _ = opener.calls[0]
    assert req.get_method() == "GET"
    assert req.full_url == "https://api.example.com/v1/voyages/" + VOYAGE_ID


def test_voyage_attach_auto_sequence_uses_non_overlapping_range(monkeypatch):
    set_voyage_env(monkeypatch)
    monkeypatch.setattr(voyage_module.secrets, "randbelow", lambda span: 12345)
    opener = install_recording_urlopen(
        monkeypatch,
        [
            (200, voyage_detail_response()),
            (202, {"accepted": 1, "duplicate": 0, "status": "running"}),
        ],
    )

    voyage = sail.voyage.init(voyage_id=VOYAGE_ID)
    voyage.event("child.started")
    voyage.flush()

    body = request_json(opener.calls[1][0])
    assert body["events"][0]["sequence_id"] == (
        voyage_module._ATTACHED_SEQUENCE_ID_START_MIN + 12346
    )
    voyage._stop_background_for_tests()


def test_voyage_attach_auto_sequence_stays_js_safe(monkeypatch):
    set_voyage_env(monkeypatch)
    monkeypatch.setattr(
        voyage_module.secrets,
        "randbelow",
        lambda span: span - 1,
    )
    opener = install_recording_urlopen(
        monkeypatch,
        [
            (200, voyage_detail_response()),
            (202, {"accepted": 1, "duplicate": 0, "status": "running"}),
        ],
    )

    voyage = sail.voyage.init(voyage_id=VOYAGE_ID)
    voyage.event("child.started")
    voyage.flush()

    body = request_json(opener.calls[1][0])
    assert body["events"][0]["sequence_id"] <= voyage_module._MAX_JS_SAFE_SEQUENCE_ID
    voyage._stop_background_for_tests()


def test_voyage_attach_auto_sequence_uses_random_component(monkeypatch):
    set_voyage_env(monkeypatch)
    random_values = iter([111, 222])
    monkeypatch.setattr(
        voyage_module.secrets,
        "randbelow",
        lambda span: next(random_values),
    )
    opener = install_recording_urlopen(
        monkeypatch,
        [
            (200, voyage_detail_response()),
            (202, {"accepted": 1, "duplicate": 0, "status": "running"}),
            (200, voyage_detail_response()),
            (202, {"accepted": 1, "duplicate": 0, "status": "running"}),
        ],
    )

    first = sail.voyage.init(voyage_id=VOYAGE_ID)
    first.event("child.started")
    first.flush()
    second = sail.voyage.init(voyage_id=VOYAGE_ID)
    second.event("child.started")
    second.flush()

    first_body = request_json(opener.calls[1][0])
    second_body = request_json(opener.calls[3][0])
    assert first_body["events"][0]["sequence_id"] == (
        voyage_module._ATTACHED_SEQUENCE_ID_START_MIN + 112
    )
    assert second_body["events"][0]["sequence_id"] == (
        voyage_module._ATTACHED_SEQUENCE_ID_START_MIN + 223
    )
    first._stop_background_for_tests()
    second._stop_background_for_tests()


def test_voyage_attach_by_env_gets_existing_voyage(monkeypatch):
    set_voyage_env(monkeypatch)
    monkeypatch.setenv("SAIL_VOYAGE_ID", ENV_VOYAGE_ID)
    opener = install_recording_urlopen(
        monkeypatch,
        [(200, voyage_detail_response(voyage_id=ENV_VOYAGE_ID))],
    )

    voyage = sail.voyage.init()

    assert voyage.id == ENV_VOYAGE_ID
    assert sail.voyage.id() == ENV_VOYAGE_ID
    assert len(opener.calls) == 1
    req, _ = opener.calls[0]
    assert req.get_method() == "GET"
    assert req.full_url == "https://api.example.com/v1/voyages/" + ENV_VOYAGE_ID


def test_voyage_attach_param_precedes_env(monkeypatch):
    set_voyage_env(monkeypatch)
    monkeypatch.setenv("SAIL_VOYAGE_ID", ENV_VOYAGE_ID)
    opener = install_recording_urlopen(
        monkeypatch,
        [(200, voyage_detail_response(voyage_id=VOYAGE_ID))],
    )

    voyage = sail.voyage.init(voyage_id=VOYAGE_ID)

    assert voyage.id == VOYAGE_ID
    assert opener.calls[0][0].full_url == (
        "https://api.example.com/v1/voyages/" + VOYAGE_ID
    )


def test_voyage_attach_not_found_raises(monkeypatch):
    set_voyage_env(monkeypatch)
    install_recording_urlopen(
        monkeypatch,
        [(404, {"error": {"message": "voyage not found"}})],
    )

    with pytest.raises(sail.VoyageNotFoundError, match="voyage not found"):
        sail.voyage.init(voyage_id=VOYAGE_ID)

    assert sail.voyage.id() is None


def test_voyage_missing_api_key_returns_noop_without_network(monkeypatch):
    monkeypatch.delenv("SAIL_API_KEY", raising=False)
    monkeypatch.setenv("SAIL_API_URL", "https://api.example.com")
    monkeypatch.setenv("SAIL_VOYAGE_ID", VOYAGE_ID)

    def fail_urlopen(req, **kwargs):
        raise AssertionError("NoopVoyage must not make network calls")

    monkeypatch.setattr(http_client_module.urllib.request, "urlopen", fail_urlopen)

    voyage = sail.voyage.init()

    assert voyage.id is None
    assert sail.voyage.id() is None
    assert sail.voyage.dashboard_url() is None
    assert voyage.headers({"Existing": "1"}) == {"Existing": "1"}
    assert sail.voyage.headers({"Existing": "1"}) == {"Existing": "1"}
    assert sail.voyage.headers() == {}
    voyage.event("planner.started")
    voyage.flush()
    assert list(voyage_module._live_voyages) == []


@pytest.mark.parametrize(
    ("env_name", "env_value"),
    [
        ("SAIL_MODE", "bogus"),
        ("SAIL_SCHEDULER_URL", "scheduler.example.com:443"),
    ],
)
def test_voyage_missing_api_key_noops_before_config_validation(
    monkeypatch, env_name, env_value
):
    monkeypatch.delenv("SAIL_API_KEY", raising=False)
    monkeypatch.delenv("SAIL_IMAGEBUILDER_URL", raising=False)
    monkeypatch.setenv(env_name, env_value)

    def fail_urlopen(req, **kwargs):
        raise AssertionError("NoopVoyage must not make network calls")

    monkeypatch.setattr(http_client_module.urllib.request, "urlopen", fail_urlopen)

    voyage = sail.voyage.init()

    assert voyage.id is None
    assert sail.voyage.id() is None


def test_voyage_missing_api_key_debug_warns(monkeypatch):
    monkeypatch.delenv("SAIL_API_KEY", raising=False)
    monkeypatch.setenv("SAIL_VOYAGE_DEBUG", "1")

    with pytest.warns(RuntimeWarning, match="SAIL_API_KEY is not set"):
        sail.voyage.init()


def test_voyage_headers_merge_without_authorization(monkeypatch):
    set_voyage_env(monkeypatch)
    install_recording_urlopen(
        monkeypatch,
        [
            (201, voyage_create_response()),
            (202, {"accepted": 1, "duplicate": 0, "status": "running"}),
        ],
    )

    voyage = sail.voyage.init(name="headers")

    assert voyage.headers() == {voyage_module.VOYAGE_ID_HEADER: VOYAGE_ID}
    merged = voyage.headers(
        {
            "Accept": "application/json",
            "Authorization": "Bearer caller",
            "x-sail-voyage-id": "voy_lowercase_old",
            voyage_module.VOYAGE_ID_HEADER: "voy_old",
        }
    )
    assert merged == {
        "Accept": "application/json",
        "Authorization": "Bearer caller",
        voyage_module.VOYAGE_ID_HEADER: VOYAGE_ID,
    }
    module_headers = sail.voyage.headers()
    assert module_headers == {voyage_module.VOYAGE_ID_HEADER: VOYAGE_ID}
    assert "Authorization" not in module_headers
    voyage._stop_background_for_tests()


def test_voyage_module_event_enqueues_on_current_voyage(monkeypatch):
    set_voyage_env(monkeypatch)
    opener = install_recording_urlopen(
        monkeypatch,
        [
            (201, voyage_create_response()),
            (202, {"accepted": 1, "duplicate": 0, "status": "running"}),
            (202, {"accepted": 1, "duplicate": 0, "status": "running"}),
        ],
    )

    voyage = sail.voyage.init(name="module event")
    sail.voyage.event("planner.started", message="planning")
    sail.voyage.flush()

    start_events = request_json(opener.calls[1][0])["events"]
    planner_events = request_json(opener.calls[2][0])["events"]
    assert [event["kind"] for event in start_events] == ["voyage.started"]
    assert [event["kind"] for event in planner_events] == ["planner.started"]
    assert planner_events[0]["message"] == "planning"
    voyage._stop_background_for_tests()


def test_voyage_event_assigns_increasing_sequence_ids():
    voyage = make_voyage()

    voyage.event("planner.started")
    voyage.event("planner.completed")
    voyage.event("manual.sequence", sequence_id=10)
    voyage.event("after.manual")

    events = voyage_module._buffered_events_for_tests(voyage)
    assert [event["sequence_id"] for event in events] == [1, 2, 10, 11]


def test_voyage_event_sequence_ids_are_unique_across_threads():
    voyage = make_voyage()

    def emit_events():
        for _ in range(50):
            voyage.event("thread.event")

    threads = [threading.Thread(target=emit_events) for _ in range(8)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()

    events = voyage_module._buffered_events_for_tests(voyage)
    sequence_ids = [event["sequence_id"] for event in events]
    assert len(sequence_ids) == 400
    assert sorted(sequence_ids) == list(range(1, 401))


@pytest.mark.parametrize(
    ("call", "error_type", "message"),
    [
        (lambda voyage: voyage.event(""), ValueError, "kind must be non-empty"),
        (
            lambda voyage: voyage.event("x" * 129),
            ValueError,
            "kind must be at most 128 characters",
        ),
        (
            lambda voyage: voyage.event("bad\x00kind"),
            ValueError,
            "kind must not contain NUL bytes",
        ),
        (
            lambda voyage: voyage.event("kind", level="verbose"),
            ValueError,
            "level must be one of",
        ),
        (
            lambda voyage: voyage.event("kind", message="bad\x00message"),
            ValueError,
            "message must not contain NUL bytes",
        ),
        (
            lambda voyage: voyage.event("kind", message="x" * 4097),
            ValueError,
            "message must be at most 4096 bytes",
        ),
        (
            lambda voyage: voyage.event("kind", payload=["not", "object"]),
            ValueError,
            "payload must be a JSON object",
        ),
        (
            lambda voyage: voyage.event("kind", payload={"bad": object()}),
            ValueError,
            "payload must be JSON serializable",
        ),
        (
            lambda voyage: voyage.event("kind", payload={"bad": "nul\x00value"}),
            ValueError,
            "payload must not contain NUL bytes",
        ),
        (
            lambda voyage: voyage.event("kind", payload={"bad\x00key": "value"}),
            ValueError,
            "payload must not contain NUL bytes",
        ),
        (
            lambda voyage: voyage.event("kind", payload={"large": "x" * 65536}),
            ValueError,
            "payload exceeds 64 KiB",
        ),
        (
            lambda voyage: voyage.event("kind", agent_id="a" * 129),
            ValueError,
            "agent_id must be at most 128 characters",
        ),
        (
            lambda voyage: voyage.event("kind", span_id=b"x"),
            TypeError,
            "span_id must be a string",
        ),
        (
            lambda voyage: voyage.event("kind", occurred_at=123),
            TypeError,
            "occurred_at must be a string",
        ),
        (
            lambda voyage: voyage.event("kind", occurred_at="not-a-date"),
            ValueError,
            "occurred_at must be an RFC3339 timestamp",
        ),
        (
            lambda voyage: voyage.event(
                "kind",
                occurred_at="2026-05-04T10:00:00+05:30:30",
            ),
            ValueError,
            "occurred_at must be an RFC3339 timestamp",
        ),
        (
            lambda voyage: voyage.event(
                "kind",
                occurred_at="2026-05-04T10:00:00+05:60",
            ),
            ValueError,
            "occurred_at must be an RFC3339 timestamp",
        ),
        (
            lambda voyage: voyage.event(
                "kind",
                occurred_at="2026-05-04T10:00:00+24:00",
            ),
            ValueError,
            "occurred_at must be an RFC3339 timestamp",
        ),
        (
            lambda voyage: voyage.event(
                "kind",
                occurred_at="2026-05-04T10:00:00",
            ),
            ValueError,
            "occurred_at must include a timezone",
        ),
        (
            lambda voyage: voyage.event("kind", sequence_id=0),
            ValueError,
            "sequence_id must be a positive integer",
        ),
        (
            lambda voyage: voyage.event(
                "kind",
                sequence_id=voyage_module._MAX_SEQUENCE_ID + 1,
            ),
            ValueError,
            "sequence_id must be at most 9223372036854775807",
        ),
        (
            lambda voyage: voyage.event("kind", sequence_id=True),
            TypeError,
            "sequence_id must be an integer",
        ),
    ],
)
def test_voyage_event_validates_local_inputs(call, error_type, message):
    voyage = make_voyage()

    with pytest.raises(error_type, match=message):
        call(voyage)

    assert voyage_module._buffered_events_for_tests(voyage) == []


def test_voyage_event_normalizes_valid_occurred_at():
    voyage = make_voyage()

    voyage.event("kind", occurred_at="2026-05-04T10:00:00Z")
    voyage.event("kind", occurred_at="2026-05-04T10:00:00+05:30")

    events = voyage_module._buffered_events_for_tests(voyage)
    assert events[0]["occurred_at"] == "2026-05-04T10:00:00+00:00"
    assert events[1]["occurred_at"] == "2026-05-04T10:00:00+05:30"


def test_voyage_event_rejects_duplicate_buffered_sequence_id():
    voyage = make_voyage()

    voyage.event("manual.one", sequence_id=10)

    with pytest.raises(ValueError, match="sequence_id duplicates"):
        voyage.event("manual.duplicate", sequence_id=10)

    events = voyage_module._buffered_events_for_tests(voyage)
    assert [event["kind"] for event in events] == ["manual.one"]


def test_voyage_event_auto_sequence_id_does_not_exceed_js_safe_range():
    voyage = make_voyage()

    voyage.event("manual.max", sequence_id=voyage_module._MAX_JS_SAFE_SEQUENCE_ID)

    with pytest.raises(
        ValueError,
        match="automatic sequence_id must be at most 9007199254740991",
    ):
        voyage.event("auto.after-max")

    events = voyage_module._buffered_events_for_tests(voyage)
    assert [event["sequence_id"] for event in events] == [
        voyage_module._MAX_JS_SAFE_SEQUENCE_ID
    ]


@pytest.mark.parametrize(
    "field",
    ["agent_id", "agent_name", "agent_role", "span_id", "parent_span_id", "error_type"],
)
def test_voyage_event_rejects_non_string_optional_labels(field):
    voyage = make_voyage()

    with pytest.raises(TypeError, match=f"{field} must be a string"):
        voyage.event("kind", **{field: b"x"})

    assert voyage_module._buffered_events_for_tests(voyage) == []


@pytest.mark.parametrize(
    "field",
    ["agent_id", "agent_name", "agent_role", "span_id", "parent_span_id", "error_type"],
)
def test_voyage_event_rejects_nul_optional_labels(field):
    voyage = make_voyage()

    with pytest.raises(ValueError, match=f"{field} must not contain NUL bytes"):
        voyage.event("kind", **{field: "bad\x00value"})

    assert voyage_module._buffered_events_for_tests(voyage) == []


def test_voyage_event_rejects_sequence_id_in_inflight_flush(monkeypatch):
    voyage = make_voyage()
    voyage.event("manual.one", sequence_id=10)

    def fake_urlopen(req, **kwargs):
        with pytest.raises(ValueError, match="sequence_id duplicates"):
            voyage.event("manual.duplicate", sequence_id=10)
        return FakeHTTPResponse(
            status=202,
            body=json.dumps(
                {"accepted": 1, "duplicate": 0, "status": "running"}
            ).encode(),
        )

    monkeypatch.setattr(http_client_module.urllib.request, "urlopen", fake_urlopen)

    voyage.flush()

    assert voyage_module._buffered_events_for_tests(voyage) == []


def test_voyage_payload_limit_matches_http_json_encoding():
    voyage = make_voyage()
    payload = {f"k{idx}": "x" for idx in range(4800)}

    compact_size = len(json.dumps(payload, separators=(",", ":")).encode("utf-8"))
    default_size = len(json.dumps(payload).encode("utf-8"))
    assert compact_size <= 64 * 1024
    assert default_size > 64 * 1024

    with pytest.raises(ValueError, match="payload exceeds 64 KiB"):
        voyage.event("payload.too_large", payload=payload)

    assert voyage_module._buffered_events_for_tests(voyage) == []


@pytest.mark.parametrize("value", [float("nan"), float("inf"), -float("inf")])
def test_voyage_payload_rejects_non_finite_floats(value):
    voyage = make_voyage()

    with pytest.raises(ValueError, match="payload must be JSON serializable"):
        voyage.event("payload.non_finite", payload={"value": value})

    assert voyage_module._buffered_events_for_tests(voyage) == []


def test_voyage_event_snapshots_payload_before_buffering(monkeypatch):
    opener = install_recording_urlopen(
        monkeypatch,
        [(202, {"accepted": 1, "duplicate": 0, "status": "running"})],
    )
    voyage = make_voyage()
    payload = {"nested": {"value": 1}, "items": [1, 2]}

    voyage.event("payload.snapshot", payload=payload)
    payload["nested"]["value"] = 2
    payload["items"].append(3)
    payload["bad"] = object()
    voyage.flush()

    event = request_json(opener.calls[0][0])["events"][0]
    assert event["payload"] == {"nested": {"value": 1}, "items": [1, 2]}


def test_voyage_event_uses_env_agent_defaults_and_explicit_overrides(monkeypatch):
    monkeypatch.setenv("SAIL_AGENT_ID", "agent_env")
    monkeypatch.setenv("SAIL_AGENT_NAME", "Env Agent")
    monkeypatch.setenv("SAIL_AGENT_ROLE", "planner")
    voyage = make_voyage()

    voyage.event("env.event")
    voyage.event(
        "explicit.event",
        agent_id="agent_explicit",
        agent_name="Explicit Agent",
        agent_role="executor",
    )

    events = voyage_module._buffered_events_for_tests(voyage)
    assert events[0]["agent_id"] == "agent_env"
    assert events[0]["agent_name"] == "Env Agent"
    assert events[0]["agent_role"] == "planner"
    assert events[1]["agent_id"] == "agent_explicit"
    assert events[1]["agent_name"] == "Explicit Agent"
    assert events[1]["agent_role"] == "executor"


def test_voyage_span_success_emits_started_and_completed():
    voyage = make_voyage()

    with voyage.span("call model", span_id="span_call") as span:
        assert span.span_id == "span_call"

    events = voyage_module._buffered_events_for_tests(voyage)
    assert [event["kind"] for event in events] == ["span.started", "span.completed"]
    assert [event["span_id"] for event in events] == ["span_call", "span_call"]
    assert [event["message"] for event in events] == ["call model", "call model"]
    assert "parent_span_id" not in events[0]
    assert "parent_span_id" not in events[1]


def test_voyage_span_rejects_nul_span_name_before_buffering():
    voyage = make_voyage()

    with pytest.raises(ValueError, match="span name must not contain NUL bytes"):
        with voyage.span("bad\x00span"):
            pass

    assert voyage_module._buffered_events_for_tests(voyage) == []


def test_voyage_span_failure_emits_failed_and_reraises():
    voyage = make_voyage()

    with pytest.raises(RuntimeError, match="boom"):
        with voyage.span("failing work", span_id="span_fail"):
            raise RuntimeError("boom")

    events = voyage_module._buffered_events_for_tests(voyage)
    assert [event["kind"] for event in events] == ["span.started", "span.failed"]
    assert events[1]["level"] == "error"
    assert events[1]["span_id"] == "span_fail"
    assert events[1]["error_type"] == "RuntimeError"
    assert events[1]["message"] == "boom"


def test_voyage_span_failure_truncates_large_exception_message():
    voyage = make_voyage()

    with pytest.raises(RuntimeError, match="large failure"):
        with voyage.span("failing work", span_id="span_fail"):
            raise RuntimeError("large failure " + ("x" * 5000))

    events = voyage_module._buffered_events_for_tests(voyage)
    assert [event["kind"] for event in events] == ["span.started", "span.failed"]
    assert events[1]["error_type"] == "RuntimeError"
    assert len(events[1]["message"].encode("utf-8")) <= 4096
    assert events[1]["message"].endswith("... [truncated]")


def test_voyage_nested_spans_and_events_stamp_parent_span_id():
    voyage = make_voyage()

    with voyage.span("parent", span_id="span_parent"):
        voyage.event("inside.parent")
        with voyage.span("child", span_id="span_child"):
            voyage.event("inside.child")

    events = voyage_module._buffered_events_for_tests(voyage)
    assert [event["kind"] for event in events] == [
        "span.started",
        "inside.parent",
        "span.started",
        "inside.child",
        "span.completed",
        "span.completed",
    ]
    assert events[0]["span_id"] == "span_parent"
    assert "parent_span_id" not in events[0]
    assert events[1]["span_id"] == "span_parent"
    assert "parent_span_id" not in events[1]
    assert events[2]["span_id"] == "span_child"
    assert events[2]["parent_span_id"] == "span_parent"
    assert events[3]["span_id"] == "span_child"
    assert events[3]["parent_span_id"] == "span_parent"
    assert events[4]["span_id"] == "span_child"
    assert events[4]["parent_span_id"] == "span_parent"
    assert events[5]["span_id"] == "span_parent"


def test_voyage_agent_context_applies_metadata_and_explicit_event_overrides(
    monkeypatch,
):
    monkeypatch.setenv("SAIL_AGENT_ID", "agent_env")
    monkeypatch.setenv("SAIL_AGENT_NAME", "Env Agent")
    monkeypatch.setenv("SAIL_AGENT_ROLE", "planner")
    voyage = make_voyage()

    with voyage.agent("agent_solver", name="Solver", role="executor"):
        voyage.event("agent.context")
        voyage.event(
            "agent.explicit",
            agent_id="agent_explicit",
            agent_name="Explicit",
            agent_role="reviewer",
        )

    events = voyage_module._buffered_events_for_tests(voyage)
    assert events[0]["agent_id"] == "agent_solver"
    assert events[0]["agent_name"] == "Solver"
    assert events[0]["agent_role"] == "executor"
    assert events[1]["agent_id"] == "agent_explicit"
    assert events[1]["agent_name"] == "Explicit"
    assert events[1]["agent_role"] == "reviewer"


def test_voyage_agent_id_override_does_not_inherit_context_labels():
    voyage = make_voyage()

    with voyage.agent("agent_outer", name="Outer", role="planner"):
        voyage.event("inner.id.only", agent_id="agent_inner")
        voyage.event("outer.same.id", agent_id="agent_outer")

    events = voyage_module._buffered_events_for_tests(voyage)
    assert events[0]["agent_id"] == "agent_inner"
    assert "agent_name" not in events[0]
    assert "agent_role" not in events[0]
    assert events[1]["agent_id"] == "agent_outer"
    assert events[1]["agent_name"] == "Outer"
    assert events[1]["agent_role"] == "planner"


def test_voyage_agent_context_is_scoped_to_voyage_id():
    first = make_voyage(voyage_id=VOYAGE_ID)
    second = make_voyage(
        voyage_id=ENV_VOYAGE_ID,
        client=HTTPClient(make_config(api_key="second_key")),
    )

    with first.agent("agent_first", name="First", role="planner"):
        second.event("second.plain")
        with second.agent("agent_second", name="Second", role="executor"):
            first.event("first.still_first")
            second.event("second.agent")
        first.event("first.agent")

    first_events = voyage_module._buffered_events_for_tests(first)
    second_events = voyage_module._buffered_events_for_tests(second)
    assert [event["kind"] for event in first_events] == [
        "first.still_first",
        "first.agent",
    ]
    for event in first_events:
        assert event["agent_id"] == "agent_first"
        assert event["agent_name"] == "First"
        assert event["agent_role"] == "planner"
    assert [event["kind"] for event in second_events] == [
        "second.plain",
        "second.agent",
    ]
    assert "agent_id" not in second_events[0]
    assert second_events[1]["agent_id"] == "agent_second"
    assert second_events[1]["agent_name"] == "Second"
    assert second_events[1]["agent_role"] == "executor"


def test_voyage_agent_context_suppresses_env_defaults(monkeypatch):
    monkeypatch.setenv("SAIL_AGENT_NAME", "Env Agent")
    monkeypatch.setenv("SAIL_AGENT_ROLE", "planner")
    voyage = make_voyage()

    with voyage.agent("agent_solver"):
        voyage.event("agent.context")

    events = voyage_module._buffered_events_for_tests(voyage)
    assert events[0]["agent_id"] == "agent_solver"
    assert "agent_name" not in events[0]
    assert "agent_role" not in events[0]


def test_voyage_span_agent_alias_applies_to_span_body():
    voyage = make_voyage()

    with voyage.span(
        "solve task",
        agent_id="agent_1",
        name="solver",
        role="executor",
        span_id="span_solver",
    ):
        voyage.event("inside.solver")

    events = voyage_module._buffered_events_for_tests(voyage)
    assert [event["kind"] for event in events] == [
        "span.started",
        "inside.solver",
        "span.completed",
    ]
    for event in events:
        assert event["agent_id"] == "agent_1"
        assert event["agent_name"] == "solver"
        assert event["agent_role"] == "executor"
        assert event["span_id"] == "span_solver"


def test_voyage_span_agent_context_applies_to_started_event_without_outer_agent_leak():
    voyage = make_voyage()

    with voyage.agent("agent_outer", name="Outer", role="planner"):
        with voyage.span(
            "solve task",
            agent_id="agent_inner",
            span_id="span_inner",
        ):
            voyage.event("inside.inner")

    events = voyage_module._buffered_events_for_tests(voyage)
    assert [event["kind"] for event in events] == [
        "span.started",
        "inside.inner",
        "span.completed",
    ]
    for event in events:
        assert event["agent_id"] == "agent_inner"
        assert "agent_name" not in event
        assert "agent_role" not in event


def test_voyage_span_restating_active_agent_preserves_labels():
    voyage = make_voyage()

    with voyage.agent("agent_solver", name="Solver", role="executor"):
        with voyage.span(
            "solve task",
            agent_id="agent_solver",
            span_id="span_solver",
        ):
            voyage.event("inside.solver")

    events = voyage_module._buffered_events_for_tests(voyage)
    assert [event["kind"] for event in events] == [
        "span.started",
        "inside.solver",
        "span.completed",
    ]
    for event in events:
        assert event["agent_id"] == "agent_solver"
        assert event["agent_name"] == "Solver"
        assert event["agent_role"] == "executor"


def test_voyage_span_agent_context_suppresses_env_defaults(monkeypatch):
    monkeypatch.setenv("SAIL_AGENT_NAME", "Env Agent")
    monkeypatch.setenv("SAIL_AGENT_ROLE", "planner")
    voyage = make_voyage()

    with voyage.span("solve task", agent_id="agent_inner", span_id="span_inner"):
        voyage.event("inside.inner")

    events = voyage_module._buffered_events_for_tests(voyage)
    assert [event["kind"] for event in events] == [
        "span.started",
        "inside.inner",
        "span.completed",
    ]
    for event in events:
        assert event["agent_id"] == "agent_inner"
        assert "agent_name" not in event
        assert "agent_role" not in event


def test_voyage_span_agent_name_and_role_apply_to_body_without_agent_id(monkeypatch):
    monkeypatch.setenv("SAIL_AGENT_ID", "agent_env")
    voyage = make_voyage()

    with voyage.span(
        "solve task",
        name="Solver",
        role="executor",
        span_id="span_solver",
    ):
        voyage.event("inside.solver")

    events = voyage_module._buffered_events_for_tests(voyage)
    assert [event["kind"] for event in events] == [
        "span.started",
        "inside.solver",
        "span.completed",
    ]
    for event in events:
        assert "agent_id" not in event
        assert event["agent_name"] == "Solver"
        assert event["agent_role"] == "executor"


def test_voyage_span_context_is_scoped_to_voyage_instance():
    first = make_voyage()
    second = make_voyage(
        voyage_id=ENV_VOYAGE_ID,
        client=HTTPClient(make_config(api_key="second_key")),
    )

    with first.span("first span", span_id="span_first"):
        second.event("second.event")

    first_events = voyage_module._buffered_events_for_tests(first)
    second_events = voyage_module._buffered_events_for_tests(second)
    assert [event["kind"] for event in first_events] == [
        "span.started",
        "span.completed",
    ]
    assert [event["kind"] for event in second_events] == ["second.event"]
    assert "span_id" not in second_events[0]
    assert "parent_span_id" not in second_events[0]


def test_voyage_span_start_failure_resets_span_agent_context():
    voyage = make_voyage()

    with pytest.raises(ValueError, match="message must be at most 4096 bytes"):
        with voyage.span(
            "bad start",
            agent_id="agent_inner",
            message="x" * 4097,
        ):
            pass
    voyage.event("after.failure")

    events = voyage_module._buffered_events_for_tests(voyage)
    assert [event["kind"] for event in events] == ["after.failure"]
    assert "agent_id" not in events[0]


def test_voyage_span_accepts_keyword_name_for_span_name():
    voyage = make_voyage()

    with voyage.span(name="keyword span", span_id="span_keyword"):
        pass

    events = voyage_module._buffered_events_for_tests(voyage)
    assert [event["message"] for event in events] == [
        "keyword span",
        "keyword span",
    ]


def test_voyage_error_helper_enqueues_error_event():
    voyage = make_voyage()

    voyage.error("tool_error", message="tool failed", payload={"tool": "browser"})

    events = voyage_module._buffered_events_for_tests(voyage)
    assert len(events) == 1
    assert events[0]["kind"] == "voyage.error"
    assert events[0]["level"] == "error"
    assert events[0]["error_type"] == "tool_error"
    assert events[0]["message"] == "tool failed"
    assert events[0]["payload"] == {"tool": "browser"}


def test_voyage_module_span_and_complete_flush_current(monkeypatch):
    opener = install_recording_urlopen(
        monkeypatch,
        [(202, {"accepted": 3, "duplicate": 0, "status": "completed"})],
    )
    voyage = make_voyage()
    voyage_module._set_current(voyage)

    with sail.voyage.span("module span", span_id="span_module"):
        pass
    sail.voyage.complete(message="done")

    body = request_json(opener.calls[0][0])
    assert [event["kind"] for event in body["events"]] == [
        "span.started",
        "span.completed",
        "voyage.completed",
    ]
    assert body["events"][2]["message"] == "done"
    assert voyage.status == "completed"
    assert voyage_module._buffered_events_for_tests(voyage) == []


def test_voyage_fail_flushes_terminal_event(monkeypatch):
    opener = install_recording_urlopen(
        monkeypatch,
        [(202, {"accepted": 1, "duplicate": 0, "status": "failed"})],
    )
    voyage = make_voyage()

    voyage.fail(
        error_type="harness_error",
        message="failed overnight",
        payload={"suite": "nightly"},
    )

    body = request_json(opener.calls[0][0])
    assert len(body["events"]) == 1
    assert body["events"][0]["kind"] == "voyage.failed"
    assert body["events"][0]["level"] == "error"
    assert body["events"][0]["error_type"] == "harness_error"
    assert body["events"][0]["message"] == "failed overnight"
    assert body["events"][0]["payload"] == {"suite": "nightly"}
    assert voyage.status == "failed"
    assert voyage_module._buffered_events_for_tests(voyage) == []


def test_voyage_complete_requeues_terminal_event_on_flush_failure(monkeypatch):
    opener = install_recording_urlopen(monkeypatch, [urllib.error.URLError("offline")])
    voyage = make_voyage()

    with pytest.raises(sail.VoyageError, match="offline"):
        voyage.complete(message="done")

    assert len(opener.calls) == 1
    events = voyage_module._buffered_events_for_tests(voyage)
    assert [event["kind"] for event in events] == ["voyage.completed"]


def test_voyage_noop_span_agent_and_terminal_helpers_do_not_call_network(monkeypatch):
    monkeypatch.delenv("SAIL_API_KEY", raising=False)
    monkeypatch.setenv("SAIL_API_URL", "https://api.example.com")

    def fail_urlopen(req, **kwargs):
        raise AssertionError("NoopVoyage must not make network calls")

    monkeypatch.setattr(http_client_module.urllib.request, "urlopen", fail_urlopen)

    voyage = sail.voyage.init()
    with sail.voyage.agent("agent_noop", name="Noop", role="executor"):
        with sail.voyage.span("noop span"):
            sail.voyage.event("noop.event")
    sail.voyage.error("noop_error")
    sail.voyage.complete()
    sail.voyage.fail()
    voyage.error("noop_error")
    voyage.complete()
    voyage.fail()

    assert voyage.id is None
    assert list(voyage_module._live_voyages) == []


@pytest.mark.parametrize(
    ("call", "error_type", "message"),
    [
        (lambda voyage: voyage.span(), TypeError, "span name is required"),
        (lambda voyage: voyage.span(""), ValueError, "span name must be non-empty"),
        (
            lambda voyage: voyage.agent(""),
            ValueError,
            "agent_id must be non-empty",
        ),
        (
            lambda voyage: voyage.fail(error_type=""),
            ValueError,
            "error_type must be non-empty",
        ),
    ],
)
def test_voyage_span_agent_and_terminal_helpers_validate_inputs(
    call,
    error_type,
    message,
):
    voyage = make_voyage()

    with pytest.raises(error_type, match=message):
        call(voyage)

    assert voyage_module._buffered_events_for_tests(voyage) == []


def test_voyage_event_does_not_raise_network_errors(monkeypatch):
    opener = install_recording_urlopen(
        monkeypatch,
        [urllib.error.URLError("offline")],
    )
    voyage = make_voyage()

    voyage.event("planner.started")

    assert opener.calls == []
    assert [
        event["kind"] for event in voyage_module._buffered_events_for_tests(voyage)
    ] == ["planner.started"]


def test_voyage_flush_raises_delivery_errors_and_requeues(monkeypatch):
    opener = install_recording_urlopen(
        monkeypatch,
        [urllib.error.URLError("offline")],
    )
    voyage = make_voyage()
    voyage.event("planner.started")

    with pytest.raises(sail.VoyageError, match="offline"):
        voyage.flush()

    assert len(opener.calls) == 1
    assert [
        event["kind"] for event in voyage_module._buffered_events_for_tests(voyage)
    ] == ["planner.started"]


def test_voyage_background_flush_failure_requeues_without_raising(monkeypatch):
    install_recording_urlopen(monkeypatch, [urllib.error.URLError("offline")])
    voyage = make_voyage()
    voyage.event("planner.started")

    delivered = voyage_module._flush_one_background_batch_for_tests(voyage)

    assert delivered is False
    assert [
        event["kind"] for event in voyage_module._buffered_events_for_tests(voyage)
    ] == ["planner.started"]


def test_voyage_background_flush_uses_finite_http_timeout(monkeypatch):
    opener = install_recording_urlopen(
        monkeypatch,
        [(202, {"accepted": 1, "duplicate": 0, "status": "running"})],
    )
    voyage = make_voyage()
    voyage.event("planner.started")

    delivered = voyage_module._flush_one_background_batch_for_tests(voyage)

    assert delivered is True
    assert opener.calls[0][1] == {
        "timeout": voyage_module._BACKGROUND_FLUSH_TIMEOUT_SECONDS
    }


def test_voyage_background_thread_does_not_keep_discarded_voyage_alive():
    voyage = make_voyage(start_background=True, flush_interval=0.01)
    voyage_ref = weakref.ref(voyage)
    thread = voyage._background_thread
    assert thread is not None

    del voyage
    for _ in range(50):
        gc.collect()
        if voyage_ref() is None:
            break
        time.sleep(0.01)
    thread.join(timeout=1.0)
    gc.collect()

    assert voyage_ref() is None
    assert not thread.is_alive()
    assert list(voyage_module._live_voyages) == []


def test_voyage_flush_caps_batches_at_256(monkeypatch):
    opener = install_recording_urlopen(
        monkeypatch,
        [
            (202, {"accepted": 256, "duplicate": 0, "status": "running"}),
            (202, {"accepted": 44, "duplicate": 0, "status": "running"}),
        ],
    )
    voyage = make_voyage()
    for idx in range(300):
        voyage.event("batch.event", payload={"idx": idx})

    voyage.flush()

    assert len(opener.calls) == 2
    assert len(request_json(opener.calls[0][0])["events"]) == 256
    assert len(request_json(opener.calls[1][0])["events"]) == 44


def test_voyage_flush_does_not_hold_buffer_lock_during_network_io(monkeypatch):
    batches = []
    voyage = make_voyage()
    injected = False

    def fake_urlopen(req, **kwargs):
        nonlocal injected
        batches.append(request_json(req)["events"])
        if not injected:
            injected = True
            voyage.event("flush.concurrent")
        return FakeHTTPResponse(
            status=202,
            body=json.dumps(
                {"accepted": 1, "duplicate": 0, "status": "running"}
            ).encode(),
        )

    monkeypatch.setattr(http_client_module.urllib.request, "urlopen", fake_urlopen)

    voyage.event("flush.started")
    voyage.flush(timeout=1.0)

    assert [[event["kind"] for event in batch] for batch in batches] == [
        ["flush.started"],
        ["flush.concurrent"],
    ]


def test_voyage_flush_lock_allows_only_one_network_flush():
    voyage = make_voyage()
    voyage.event("planner.started")
    voyage._flush_lock.acquire()
    try:
        with pytest.raises(sail.VoyageError, match="timed out waiting"):
            voyage.flush(timeout=0.01)
    finally:
        voyage._flush_lock.release()


def test_voyage_atexit_helper_flushes_live_voyages(monkeypatch):
    opener = install_recording_urlopen(
        monkeypatch,
        [(202, {"accepted": 1, "duplicate": 0, "status": "running"})],
    )
    voyage = make_voyage(start_background=True, flush_interval=999.0)
    voyage.event("planner.started")

    voyage_module._flush_live_voyages(timeout_per_voyage=1.0)

    assert len(opener.calls) == 1
    assert request_json(opener.calls[0][0])["events"][0]["kind"] == "planner.started"
    voyage._stop_background_for_tests()


def test_voyage_buffer_preserves_lifecycle_events_when_full():
    voyage = make_voyage(buffer_cap=2)

    voyage.event("voyage.started")
    voyage.event("work.old")
    voyage.event("work.new")

    events = voyage_module._buffered_events_for_tests(voyage)
    assert [event["kind"] for event in events] == ["voyage.started", "work.new"]

    voyage.event("voyage.completed")
    events = voyage_module._buffered_events_for_tests(voyage)
    assert [event["kind"] for event in events] == [
        "voyage.started",
        "voyage.completed",
    ]

    with pytest.raises(sail.VoyageError, match="cannot preserve terminal event"):
        voyage.event("voyage.failed")

    voyage.event("work.after-terminal")
    events = voyage_module._buffered_events_for_tests(voyage)
    assert [event["kind"] for event in events] == [
        "voyage.started",
        "voyage.completed",
    ]


def test_voyage_flush_emits_dropped_event_notice(monkeypatch):
    opener = install_recording_urlopen(
        monkeypatch,
        [
            (202, {"accepted": 2, "duplicate": 0, "status": "running"}),
            (202, {"accepted": 1, "duplicate": 0, "status": "running"}),
        ],
    )
    voyage = make_voyage(buffer_cap=2)
    voyage.event("voyage.started")
    voyage.event("work.old")
    voyage.event("work.new")

    voyage.flush()

    first_batch = request_json(opener.calls[0][0])["events"]
    second_batch = request_json(opener.calls[1][0])["events"]
    assert [event["kind"] for event in first_batch] == ["voyage.started", "work.new"]
    assert second_batch[0]["kind"] == "sdk.events_dropped"
    assert second_batch[0]["level"] == "warn"
    assert second_batch[0]["payload"] == {"dropped": 1}


def test_voyage_drop_notice_ignores_invalid_agent_env(monkeypatch):
    monkeypatch.setenv("SAIL_AGENT_ID", "agent_" + ("x" * 129))
    opener = install_recording_urlopen(
        monkeypatch,
        [
            (202, {"accepted": 2, "duplicate": 0, "status": "running"}),
            (202, {"accepted": 1, "duplicate": 0, "status": "running"}),
        ],
    )
    voyage = make_voyage(buffer_cap=2)
    voyage.event("voyage.started", agent_id="agent_ok")
    voyage.event("work.old", agent_id="agent_ok")
    voyage.event("work.new", agent_id="agent_ok")

    voyage.flush()

    notice = request_json(opener.calls[1][0])["events"][0]
    assert notice["kind"] == "sdk.events_dropped"
    assert "agent_id" not in notice
    assert "agent_name" not in notice
    assert "agent_role" not in notice


def test_voyage_flush_skips_dropped_event_notice_when_sequence_ids_exhausted(
    monkeypatch,
):
    opener = install_recording_urlopen(
        monkeypatch,
        [(202, {"accepted": 1, "duplicate": 0, "status": "running"})],
    )
    voyage = make_voyage(buffer_cap=1)
    voyage.event("work.old", sequence_id=voyage_module._MAX_SEQUENCE_ID - 1)
    voyage.event("work.max", sequence_id=voyage_module._MAX_SEQUENCE_ID)

    voyage.flush()

    assert len(opener.calls) == 1
    batch = request_json(opener.calls[0][0])["events"]
    assert [event["kind"] for event in batch] == ["work.max"]
    assert voyage_module._buffered_events_for_tests(voyage) == []
