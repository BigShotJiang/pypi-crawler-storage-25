# CoreTx Connect

Give your AI assistant persistent memory that survives across conversations, sessions, and devices.

CoreTx Connect is a lightweight MCP server (~450 lines, zero dependencies) that stores knowledge objects (KOs) via the CoreTx API. Your assistant captures decisions, facts, preferences, and insights as you work, and retrieves them automatically in future sessions.

**What changes**: Your AI remembers what you discussed last week. It recalls architectural decisions from three months ago. It knows your preferences without being told again. When context compaction would normally erase critical details, KOs preserve them.

## Quick Start

### Claude Desktop (automatic setup)

```bash
# 1. Install
pip install coretx

# 2. Run setup (writes Claude Desktop config automatically)
coretx setup <your-api-key>

# 3. Restart Claude Desktop
```

### Claude Code (CLI)

```bash
# 1. Install
pip install coretx

# 2. Add to Claude Code
claude mcp add --transport stdio ko-memory -- coretx serve

# 3. Set your key (add to your shell profile for persistence)
export CORETX_API_KEY=npub_sk_xxx

# 4. Verify everything works
coretx --test
```

The `--test` command checks API connectivity, writes and reads a test KO, and confirms your setup is working.

### Getting an API key

You can create your own API key at [praxis.coretx.ai](https://praxis.coretx.ai) under API Keys, or use `coretx init` to create an account and key from the terminal.

## How It Works

When you start a conversation, your assistant calls `ko_context` to load relevant knowledge from previous sessions. As you work, it proactively captures decisions, facts, and insights via `ko_write`. These KOs persist server-side and are available in every future session, on any device, with any AI provider.

```
You: "Let's use PostgreSQL on Supabase for the database"
  -> ko_write(subject='database', predicate='decided as', object_value='PostgreSQL on Supabase')

[Three weeks later, new session]

Assistant calls ko_context -> loads the database decision automatically
You: "What database are we using?"
  -> Already knows: PostgreSQL on Supabase
```

## Tools

### Cloud tools (persistent, require API key)

| Tool | What it does |
|------|-------------|
| `ko_write` | Store a knowledge object. Called proactively by the assistant. |
| `ko_read` | Retrieve a specific KO by subject + predicate. |
| `ko_search` | Search KOs by keyword or natural language. |
| `ko_list` | List recent KOs, optionally filtered by project. |
| `ko_delete` | Delete a KO by subject + predicate. |
| `ko_context` | Load session-start context (pinned + recent + relevant KOs). |
| `ko_stats` | Get store statistics (total KOs, projects, pinned count). |
| `ko_share` | Share KOs with another CoreTx user by email or ORCID. |

### Local tools (session-scoped, no API key needed)

| Tool | What it does |
|------|-------------|
| `ko_set_context` | Set project/goal for smarter retrieval. |
| `ko_working_memory` | Ephemeral scratch memory (auto-expires after 1 hour). |
| `ko_todos` | Task tracking within the session. |

## CLI Commands

### Bootstrap (cold start from Claude Code history)

If you have existing Claude Code sessions, bootstrap your knowledge store from them:

```bash
coretx bootstrap --dry-run    # preview what would be extracted
coretx bootstrap              # extract and write KOs
coretx bootstrap --path /custom/logs/path
```

This scans your Claude Code JSONL logs (`~/.claude/projects/`) and extracts decisions, facts, problems, and preferences as KOs. Projects are inferred from directory names.

### Reclassify (organize unassigned KOs)

If you have KOs without a project, classify them based on your existing project keywords:

```bash
coretx reclassify --dry-run   # preview classifications
coretx reclassify             # apply classifications
```

### Other commands

```bash
coretx --test      # verify API connectivity
coretx --version   # show version
coretx setup <key> # configure Claude Desktop
```

## Environment Variables

| Variable | Required | Default |
|----------|----------|---------|
| `CORETX_API_KEY` | Yes (for cloud tools) | -- |
| `CORETX_API_URL` | No | `https://api.coretx.ai` |

## Troubleshooting

**"CORETX_API_KEY not set"** — Make sure your API key is set via the `setup` command or in your environment.

**Server not appearing in Claude Desktop** — Restart Claude Desktop after running `setup`.

**"HTTP 401" errors** — Your API key is invalid or expired. Ask your team lead for a new one.

**Wrong Python version** — Re-run `coretx setup <key>` — it uses the correct Python automatically.

## Team Setup

Each team member needs their own API key. KOs are per-user and private by default. To share knowledge across the team, use `ko_share` with a colleague's email or ORCID.

```bash
# Each team member runs:
pip install coretx
claude mcp add --transport stdio ko-memory -- coretx serve
export CORETX_API_KEY=npub_sk_xxx  # their own key
coretx --test
```

## Architecture

- **Local server**: MCP over stdio for Claude Code / Desktop
- **Remote server**: Streamable HTTP for claude.ai browser (`coretx-remote`)
- **Storage**: All persistent state at `api.coretx.ai` (no local database)
- **Auth**: Bearer token (`npub_sk_*` API keys), OAuth 2.1 for browser
- **Signing**: Ed25519 client-side signing (local server only)
- **Server name**: `ko-memory`
