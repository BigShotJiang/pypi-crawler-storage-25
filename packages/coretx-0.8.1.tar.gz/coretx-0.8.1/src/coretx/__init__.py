"""CoreTx — structured memory for AI that persists, attributes, and connects."""
from importlib.metadata import version as _version
try:
    __version__ = _version("coretx")
except Exception:
    try:
        __version__ = _version("coretx-connect")
    except Exception:
        __version__ = "0.0.0"
