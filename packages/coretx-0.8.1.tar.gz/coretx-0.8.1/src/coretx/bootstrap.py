"""
Bootstrap KOs from Claude Code JSONL session logs.

Scans ~/.claude/projects/ for historical conversations and extracts
decisions, facts, preferences, and problems as KOs. Solves the cold
start problem for new users who have Claude Code history.

Two extraction modes:
1. LLM extraction (when ANTHROPIC_API_KEY is set): Uses Haiku to parse
   conversation chunks into structured KOs. Catches ~95% of knowledge.
2. Regex fallback (no API key): Pattern matching for explicit phrases.
   Catches ~30% but costs nothing.

Usage:
    coretx-connect bootstrap           # extract and write KOs
    coretx-connect bootstrap --dry-run # show what would be written
    coretx-connect bootstrap --path /custom/path
"""

from __future__ import annotations

import json
import os
import re
import sys
import urllib.request
from pathlib import Path
from typing import Any

from coretx.server import _api_get, _api_post, API_KEY


DEFAULT_LOG_DIR = Path.home() / ".claude" / "projects"

# ─── Regex patterns (fallback when no API key) ───────────────────

DECISION_PATTERNS = [
    re.compile(r"(?:let's go with|we should|the plan is|I've decided|we're going to|decided to|approved|rejected)\s+(.{10,200})", re.I),
]

FACT_PATTERNS = [
    re.compile(r"(?:the (?:API|database|server|service) (?:is at|uses|runs on|is))\s+(.{5,200})", re.I),
    re.compile(r"(?:deployed (?:at|to))\s+(https?://\S+)", re.I),
    re.compile(r"(?:version|v)\s*(\d+\.\d+(?:\.\d+)?)", re.I),
]

PROBLEM_PATTERNS = [
    re.compile(r"(?:the (?:bug|issue|problem) is)\s+(.{10,200})", re.I),
    re.compile(r"(?:doesn't work|is broken|fails? (?:with|because|when))\s+(.{10,200})", re.I),
]

PREFERENCE_PATTERNS = [
    re.compile(r"(?:I prefer|always use|never do|from now on)\s+(.{5,200})", re.I),
]


# ─── LLM Extraction ─────────────────────────────────────────────

EXTRACTION_PROMPT = """Extract knowledge claims from this conversation between a user and an AI assistant.
Each claim is a single declarative sentence that stands alone.

Return ONLY a valid JSON array. Each element:
{{
  "subject": "<2-5 word topic label>",
  "predicate": "<claim type: decided as, rule is, finding is, status is, architecture is, located at, problem is, preference is>",
  "object_value": "<FULL CLAIM as a complete standalone sentence. Include specifics: names, numbers, paths. 1-2 sentences.>",
  "ko_type": "<insight|method|problem|hypothesis|finding|connection|negative_result>",
  "memory_type": "<episodic|semantic>",
  "pinned": false,
  "tags": ["<1-3 tags>"]
}}

RULES:
- object_value must be a COMPLETE SENTENCE readable without context
- Semantic = stable knowledge (conventions, architecture, decisions). Episodic = session-specific.
- Set pinned=true ONLY for critical constraints ("never do X", "always use Y")
- Skip: greetings, debugging dead-ends, file reads, tool call outputs, code blocks
- Extract ALL genuine decisions, facts, findings, problems, and preferences
- BAD: {{"subject":"auth","predicate":"uses","object_value":"cookies"}}
- GOOD: {{"subject":"auth system","predicate":"architecture is","object_value":"Authentication uses HMAC-SHA256 signed HttpOnly cookies with 30-day expiry, replacing the previous localStorage approach."}}

Conversation:
{text}"""


def _llm_extract_chunk(chunk: str, api_key: str) -> list[dict]:
    """Extract KOs from a conversation chunk using Haiku."""
    prompt = EXTRACTION_PROMPT.format(text=chunk[:12000])

    try:
        body = json.dumps({
            "model": "claude-haiku-4-20250514",
            "max_tokens": 4000,
            "messages": [{"role": "user", "content": prompt}],
        }).encode()

        req = urllib.request.Request(
            "https://api.anthropic.com/v1/messages",
            data=body,
            headers={
                "Content-Type": "application/json",
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01",
            },
        )
        with urllib.request.urlopen(req, timeout=60) as resp:
            result = json.loads(resp.read())
            text = result["content"][0]["text"]
            # Extract JSON array from response
            start = text.find("[")
            end = text.rfind("]") + 1
            if start >= 0 and end > start:
                kos = json.loads(text[start:end])
                # Validate
                valid = []
                for ko in kos:
                    if isinstance(ko, dict) and ko.get("subject") and ko.get("predicate") and ko.get("object_value"):
                        if len(ko["object_value"]) > 15:
                            valid.append(ko)
                return valid
    except Exception as e:
        print(f"  LLM extraction failed: {e}", file=sys.stderr)

    return []


def _chunk_transcript(text: str, max_chars: int = 10000) -> list[str]:
    """Split transcript into chunks at user message boundaries."""
    # Split at "Human:" or user message markers
    parts = re.split(r'\n(?=(?:Human|User|assistant|human):)', text)

    chunks = []
    current = ""
    for part in parts:
        if len(current) + len(part) > max_chars and current:
            chunks.append(current)
            current = part
        else:
            current += "\n" + part if current else part

    if current.strip():
        chunks.append(current)

    return chunks if chunks else [text[:max_chars]]


# ─── JSONL Parsing ───────────────────────────────────────────────

def _extract_project_from_dir(dirname: str) -> str:
    """Extract project name from JSONL directory name."""
    path = dirname.replace("-", "/")
    parts = path.rstrip("/").split("/")
    return parts[-1] if parts else ""


def _parse_jsonl_to_text(filepath: Path) -> str:
    """Parse JSONL into a readable transcript for LLM extraction."""
    lines = []
    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    record = json.loads(line)
                except json.JSONDecodeError:
                    continue

                role = record.get("type", "")
                message = record.get("message", {})
                content = message.get("content", "")
                if isinstance(content, list):
                    content = " ".join(
                        block.get("text", "") for block in content
                        if isinstance(block, dict) and block.get("type") == "text"
                    )
                if not isinstance(content, str) or len(content) < 10:
                    continue

                if role == "assistant":
                    lines.append(f"Assistant: {content}")
                elif role == "human" or role == "user":
                    lines.append(f"Human: {content}")
    except Exception as e:
        print(f"  Error reading {filepath}: {e}", file=sys.stderr)

    return "\n\n".join(lines)


def _scan_jsonl_regex(filepath: Path) -> list[dict]:
    """Scan a JSONL file using regex patterns (fallback mode)."""
    found = []
    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    record = json.loads(line)
                except json.JSONDecodeError:
                    continue

                if record.get("type") != "assistant":
                    continue

                message = record.get("message", {})
                content = message.get("content", "")
                if isinstance(content, list):
                    content = " ".join(
                        block.get("text", "") for block in content
                        if isinstance(block, dict) and block.get("type") == "text"
                    )
                if not isinstance(content, str) or len(content) < 20:
                    continue

                timestamp = record.get("timestamp", "")

                for pattern in DECISION_PATTERNS:
                    match = pattern.search(content)
                    if match:
                        found.append({
                            "subject": match.group(1)[:80].strip().rstrip("."),
                            "predicate": "decided as",
                            "object_value": match.group(0)[:300].strip(),
                            "ko_type": "insight",
                            "memory_type": "semantic",
                            "tags": ["bootstrap"],
                            "timestamp": timestamp,
                        })

                for pattern in FACT_PATTERNS:
                    match = pattern.search(content)
                    if match:
                        found.append({
                            "subject": match.group(0)[:80].strip().rstrip("."),
                            "predicate": "established as",
                            "object_value": match.group(0)[:300].strip(),
                            "ko_type": "insight",
                            "memory_type": "semantic",
                            "tags": ["bootstrap"],
                            "timestamp": timestamp,
                        })

                for pattern in PROBLEM_PATTERNS:
                    match = pattern.search(content)
                    if match:
                        found.append({
                            "subject": match.group(1)[:80].strip().rstrip("."),
                            "predicate": "problem is",
                            "object_value": match.group(0)[:300].strip(),
                            "ko_type": "problem",
                            "tags": ["bootstrap"],
                            "timestamp": timestamp,
                        })

                for pattern in PREFERENCE_PATTERNS:
                    match = pattern.search(content)
                    if match:
                        found.append({
                            "subject": match.group(1)[:80].strip().rstrip("."),
                            "predicate": "preference is",
                            "object_value": match.group(0)[:300].strip(),
                            "ko_type": "insight",
                            "memory_type": "semantic",
                            "pinned": True,
                            "tags": ["bootstrap"],
                            "timestamp": timestamp,
                        })

    except Exception as e:
        print(f"  Error reading {filepath}: {e}", file=sys.stderr)

    return found


# ─── Main Bootstrap ──────────────────────────────────────────────

def bootstrap(log_dir: Path = DEFAULT_LOG_DIR, dry_run: bool = False) -> dict:
    """Scan Claude Code logs and extract KOs.

    Uses LLM extraction when ANTHROPIC_API_KEY is set, falls back to regex.

    Returns: {"sessions": N, "extracted": N, "written": N, "skipped": N, "mode": "llm"|"regex"}
    """
    if not log_dir.exists():
        print(f"Log directory not found: {log_dir}", file=sys.stderr)
        return {"sessions": 0, "extracted": 0, "written": 0, "skipped": 0, "mode": "none"}

    anthropic_key = os.environ.get("ANTHROPIC_API_KEY", "")
    use_llm = bool(anthropic_key)

    if use_llm:
        print("Using LLM extraction (Haiku). Higher quality, ~$0.01/session.")
    else:
        print("No ANTHROPIC_API_KEY found. Using regex fallback (lower quality).")
        print("Set ANTHROPIC_API_KEY for 3x better extraction.\n")

    # Fetch existing KOs for dedup
    existing_subjects = set()
    if not dry_run and API_KEY:
        result = _api_get("list", {"limit": 500})
        for ko in result.get("kos", result.get("results", [])):
            existing_subjects.add(ko.get("subject", "").lower())

    sessions = 0
    extracted = 0
    written = 0
    skipped = 0

    for project_dir in sorted(log_dir.iterdir()):
        if not project_dir.is_dir():
            continue

        project = _extract_project_from_dir(project_dir.name)
        jsonl_files = list(project_dir.glob("*.jsonl"))

        for jsonl_file in jsonl_files:
            sessions += 1

            if use_llm:
                # LLM mode: parse to text, chunk, extract per chunk
                transcript = _parse_jsonl_to_text(jsonl_file)
                if len(transcript) < 100:
                    continue

                chunks = _chunk_transcript(transcript)
                found = []
                for i, chunk in enumerate(chunks):
                    chunk_kos = _llm_extract_chunk(chunk, anthropic_key)
                    for ko in chunk_kos:
                        ko["tags"] = ko.get("tags", [])
                        if "bootstrap" not in ko["tags"]:
                            ko["tags"].append("bootstrap")
                    found.extend(chunk_kos)
                    if len(chunks) > 1:
                        sys.stderr.write(f"  Chunk {i+1}/{len(chunks)}: {len(chunk_kos)} KOs\n")
            else:
                # Regex mode
                found = _scan_jsonl_regex(jsonl_file)

            extracted += len(found)

            for ko in found:
                # Dedup
                subject = ko.get("subject", "")
                if subject.lower() in existing_subjects:
                    skipped += 1
                    continue

                ko["project"] = project

                if dry_run:
                    ko_type = ko.get("ko_type", "insight")
                    pinned = " [PINNED]" if ko.get("pinned") else ""
                    mem_type = ko.get("memory_type", "episodic")
                    print(f"  [{project}] {ko_type}/{mem_type}{pinned}: {subject[:60]} ({ko.get('predicate', '?')})")
                    if ko.get("object_value"):
                        print(f"    → {ko['object_value'][:120]}")
                    written += 1
                else:
                    result = _api_post({
                        "action": "write",
                        "subject": ko.get("subject", ""),
                        "predicate": ko.get("predicate", ""),
                        "object_value": ko.get("object_value", ""),
                        "ko_type": ko.get("ko_type", "insight"),
                        "memory_type": ko.get("memory_type", "episodic"),
                        "project": project,
                        "tags": ko.get("tags", []),
                        "pinned": ko.get("pinned", False),
                        "confidence": ko.get("confidence"),
                        "visibility": "private",
                    })
                    if "error" not in result and result.get("action") != "gated":
                        written += 1
                        existing_subjects.add(subject.lower())
                    elif result.get("action") == "gated":
                        skipped += 1  # Filtered by write gate
                    else:
                        skipped += 1

            if found:
                print(f"  {jsonl_file.name}: {len(found)} extracted")

    return {
        "sessions": sessions,
        "extracted": extracted,
        "written": written,
        "skipped": skipped,
        "mode": "llm" if use_llm else "regex",
    }


def main():
    dry_run = "--dry-run" in sys.argv
    log_path = DEFAULT_LOG_DIR

    for i, arg in enumerate(sys.argv):
        if arg == "--path" and i + 1 < len(sys.argv):
            log_path = Path(sys.argv[i + 1])

    if "--help" in sys.argv or "-h" in sys.argv:
        print("coretx-connect bootstrap [--dry-run] [--path PATH]")
        print("  Scan Claude Code logs and extract KOs for cold start.")
        print(f"  Default path: {DEFAULT_LOG_DIR}")
        print("\n  Set ANTHROPIC_API_KEY for LLM extraction (3x better quality).")
        print("  Without it, uses regex fallback.")
        return

    if not API_KEY and not dry_run:
        print("CORETX_API_KEY not set. Use --dry-run to preview without writing.", file=sys.stderr)
        sys.exit(1)

    print(f"Scanning {log_path}...")
    if dry_run:
        print("(dry run -- nothing will be written)\n")

    stats = bootstrap(log_path, dry_run=dry_run)

    mode_str = "LLM (Haiku)" if stats["mode"] == "llm" else "regex fallback"
    print(f"\nDone ({mode_str}). Scanned {stats['sessions']} sessions, "
          f"extracted {stats['extracted']} candidates, "
          f"wrote {stats['written']} KOs, "
          f"skipped {stats['skipped']} (duplicates/gated/errors).")


if __name__ == "__main__":
    main()
