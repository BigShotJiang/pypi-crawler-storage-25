"""
Ed25519 cryptographic signing for Knowledge Objects.

Client-side signing: the private key never leaves the user's device.
CoreTx stores the signature + public key for independent verification.

Canonicalization produces identical bytes in Python and TypeScript
so signatures are cross-platform verifiable.
"""

from __future__ import annotations

import base64
import hashlib
import json
import os
from pathlib import Path

# cryptography is an optional dependency — signing degrades gracefully
try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import (
        Ed25519PrivateKey,
        Ed25519PublicKey,
    )
    from cryptography.hazmat.primitives import serialization
    HAS_CRYPTO = True
except ImportError:
    HAS_CRYPTO = False

DEFAULT_KEY_PATH = Path.home() / ".coretx" / "signing.key"


# ─── Canonicalization ─────────────────────────────────────────

def canonicalize_ko(
    subject: str,
    object_value: str,
    ko_type: str,
    timestamp: str,
    visibility: str = "private",
) -> str:
    """
    Produce a canonical JSON string for signing.
    Rules: sorted keys, compact separators, UTF-8.
    Must produce identical output to the TypeScript canonicalizeKO().

    Visibility is included so that changing a KO's visibility after
    signing invalidates the signature.
    """
    canonical = {
        "content": object_value or "",
        "ko_type": ko_type or "insight",
        "subject": subject or "",
        "timestamp": timestamp,
        "visibility": visibility or "private",
    }
    return json.dumps(canonical, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


# ─── Key Management ───────────────────────────────────────────

def load_or_create_key(path: Path | str = DEFAULT_KEY_PATH) -> "Ed25519PrivateKey":
    """Load an Ed25519 private key from PEM file, or generate and save one."""
    if not HAS_CRYPTO:
        raise ImportError("cryptography package required for signing")

    path = Path(path)

    if path.exists():
        pem_data = path.read_bytes()
        return serialization.load_pem_private_key(pem_data, password=None)  # type: ignore[return-value]

    # Generate new keypair
    private_key = Ed25519PrivateKey.generate()

    # Ensure directory exists
    path.parent.mkdir(parents=True, exist_ok=True)

    # Write PEM with restrictive permissions
    pem_data = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    path.write_bytes(pem_data)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass  # Windows doesn't support Unix permissions

    return private_key


def get_public_key_b64(private_key: "Ed25519PrivateKey") -> str:
    """Extract the raw 32-byte public key and base64-encode it."""
    pub_bytes = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    return base64.b64encode(pub_bytes).decode("ascii")


# ─── Signing ──────────────────────────────────────────────────

def sign_ko(private_key: "Ed25519PrivateKey", canonical: str) -> str:
    """
    Sign the SHA-256 hash of a canonical KO string.
    Returns base64-encoded 64-byte Ed25519 signature.

    Matches the TypeScript implementation:
      sha256(canonical) -> Ed25519.sign(hash) -> base64
    """
    message_hash = hashlib.sha256(canonical.encode("utf-8")).digest()
    signature = private_key.sign(message_hash)
    return base64.b64encode(signature).decode("ascii")


def verify_signature(
    public_key_b64: str,
    signature_b64: str,
    canonical: str,
) -> bool:
    """Verify an Ed25519 signature against a public key."""
    if not HAS_CRYPTO:
        return False
    try:
        pub_bytes = base64.b64decode(public_key_b64)
        public_key = Ed25519PublicKey.from_public_bytes(pub_bytes)
        signature = base64.b64decode(signature_b64)
        message_hash = hashlib.sha256(canonical.encode("utf-8")).digest()
        public_key.verify(signature, message_hash)
        return True
    except Exception:
        return False
