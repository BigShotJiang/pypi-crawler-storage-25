from dataclasses import dataclass, field
from typing import List

import numpy as np
from scipy.integrate import cumulative_trapezoid as cumtrapz
from scipy.integrate import quad
from scipy.special import erf

from NeSST.collisions import *
from NeSST.constants import *
from NeSST.endf_interface import retrieve_total_cross_section_from_ENDF_file
from NeSST.utils import *


@dataclass
class LOS_material_component:
    number_fraction: float
    A: float
    ENDF_file: str


@dataclass
class LOS_material:
    density: float
    ntot: float = field(init=False)
    mavg: float = field(init=False)
    length: float
    components: List[LOS_material_component]

    def __post_init__(self):
        self.mavg = 0.0
        for comp in self.components:
            self.mavg += comp.number_fraction * comp.A
        self.mavg *= sc.atomic_mass
        self.ntot = self.density / self.mavg


def get_LOS_attenuation(LOS_materials: List[LOS_material]):
    tau_interp_list = []
    for LOS_material in LOS_materials:
        ntot_barn = 1e-28 * LOS_material.ntot
        L = LOS_material.length
        for LOS_component in LOS_material.components:
            ncomp = ntot_barn * LOS_component.number_fraction
            E, sigma_tot = retrieve_total_cross_section_from_ENDF_file(LOS_component.ENDF_file)
            tau_interp = interpolate_1d(E, L * ncomp * sigma_tot, method="linear")
            tau_interp_list.append(tau_interp)

    def LOS_attenuation(E):
        total_tau = tau_interp_list[0](E)
        for i in range(1, len(tau_interp_list)):
            total_tau += tau_interp_list[i](E)
        transmission = np.exp(-total_tau)
        return transmission

    return LOS_attenuation


def get_power_law_NLO(p, Enorm=E0_DT):
    A = mat_dict["H"].sigma(Enorm) * Enorm**p

    def power_law_NLO(E):
        return mat_dict["H"].sigma(E) * E**p / A

    return power_law_NLO


def get_Verbinski_NLO(Enorm=E0_DT):
    """
    Using equation (3) from

    Qi Tang, Zifeng Song, Pinyang Liu, Bo Yu, Jiamin Yang,
    Calibration of the sensitivity of the bibenzyl-based scintillation detector to 1–5 MeV neutrons,
    Nuclear Instruments and Methods in Physics Research Section A: Accelerators, Spectrometers, Detectors and Associated Equipment,
    Volume 1068,
    2024,
    169779,
    ISSN 0168-9002,
    https://doi.org/10.1016/j.nima.2024.169779.
    """
    V_E, V_L = np.loadtxt(data_dir + "VerbinskiLproton.csv", delimiter=",", unpack=True)
    cumulative_L = cumtrapz(y=np.insert(V_L, 0, 0.0), x=np.insert(V_E, 0, 0.0))
    L_integral = interpolate_1d(np.insert(V_E, 0, 0.0) * 1e6, np.insert(cumulative_L, 0, 0.0), method="cubic")

    def Verbinski_NLO(E):
        return mat_dict["H"].sigma(E) * L_integral(E) / E

    A = Verbinski_NLO(Enorm)

    def norm_Verbinski_NLO(E):
        return Verbinski_NLO(E) / A

    return norm_Verbinski_NLO


def get_BirksBetheBloch_NLO(akB, Enorm=E0_DT):
    r"""
    akB in eV

    Combining:
    kB in m/eV
    a in eV^2/m
    Bethe-Bloch formula for stopping power:
        dE/dx = a/E

    Birks relation for light response:
        dL/dx \propto (dEdx)/(1+kB (dE/dx))

    Using equation (3), (7) from

    Qi Tang, Zifeng Song, Pinyang Liu, Bo Yu, Jiamin Yang,
    Calibration of the sensitivity of the bibenzyl-based scintillation detector to 1–5 MeV neutrons,
    Nuclear Instruments and Methods in Physics Research Section A: Accelerators, Spectrometers, Detectors and Associated Equipment,
    Volume 1068,
    2024,
    169779,
    ISSN 0168-9002,
    https://doi.org/10.1016/j.nima.2024.169779.
    """

    def BirksBetheBloch_NLO(E):
        L_integral = 0.5 * E**2 - akB * E - akB * (akB + E) * np.log(1.0 + E / akB)
        return mat_dict["H"].sigma(E) * L_integral / E

    A = BirksBetheBloch_NLO(Enorm)

    def norm_BirksBetheBloch_NLO(E):
        return BirksBetheBloch_NLO(E) / A

    return norm_BirksBetheBloch_NLO


def get_BirksBethe_NLO(akB, excitation_energy, mp=sc.m_p, Enorm=E0_DT):
    r"""
    akB in eV

    Combining:
    kB in m/eV
    a in eV^2/m

    I = excitation_energy in eV

    Bethe formula for stopping power:
        dE/dx = a/E * ln(4 me E / mp I)

    Birks relation for light response:
        dL/dx \propto (dEdx)/(1+kB (dE/dx))

    Using equation (3), (7) from

    Qi Tang, Zifeng Song, Pinyang Liu, Bo Yu, Jiamin Yang,
    Calibration of the sensitivity of the bibenzyl-based scintillation detector to 1–5 MeV neutrons,
    Nuclear Instruments and Methods in Physics Research Section A: Accelerators, Spectrometers, Detectors and Associated Equipment,
    Volume 1068,
    2024,
    169779,
    ISSN 0168-9002,
    https://doi.org/10.1016/j.nima.2024.169779.
    """
    Istar = excitation_energy * mp / sc.m_e / 4.0

    def kB_dEdx(Ep):
        Ep_lim = max([Ep, np.e * Istar])
        return akB / Ep_lim * np.log(Ep_lim / Istar)

    def dLdE(Ep):
        return 1.0 / (1.0 + kB_dEdx(Ep))

    def L(Ep):
        return quad(dLdE, 0.0, Ep)[0]

    def L_integral_scalar(En):
        return quad(L, 0.0, En)[0]

    L_integral = np.vectorize(L_integral_scalar)

    def BirksBethe_NLO(E):
        return mat_dict["H"].sigma(E) * L_integral(E) / E

    A = BirksBethe_NLO(Enorm)

    def norm_BirksBethe_NLO(E):
        return BirksBethe_NLO(E) / A

    return norm_BirksBethe_NLO, kB_dEdx, L


def get_unity_sensitivity():
    def unity_sensitivity(En):
        return np.ones_like(En)

    return unity_sensitivity


def combine_detector_sensitivities(model_list):
    def total_sensitivity(E):
        sensitivity = model_list[0](E)
        for i in range(1, len(model_list)):
            sensitivity *= model_list[i](E)
        return sensitivity

    return total_sensitivity


def top_hat(scint_thickness):
    """
    Return a function  R_base(t_detected, En)  that creates the
    normalised top-hat transit matrix for *this* scintillator thickness.
    """

    def _top_hat_matrix(t_detected, t_transit):
        """NxN top-hat response, normalised row-wise."""
        tt_d, tt_a = np.meshgrid(t_detected, t_detected, indexing="ij")
        _, tt_t = np.meshgrid(t_detected, t_transit, indexing="ij")

        R = np.eye(t_detected.size) + np.heaviside(tt_d - tt_a, 0.0) - np.heaviside(tt_d - (tt_a + tt_t), 1.0)

        row_sum = R.sum(axis=1, keepdims=True)
        row_sum[row_sum == 0] = 1  # avoid div-by-zero
        return R / row_sum

    def base(t_detected, En):
        vn = Ekin_2_beta(En, Mn) * c
        t_transit = scint_thickness / vn
        return _top_hat_matrix(t_detected, t_transit)

    return base


def inversegaussian_nIRF(
    scint_thickness, ni_scin=8.79e28, CH_ratio=8 / 18, E_lower=0.05e6, E_upper=25.0e6, NE_interp=1000
):
    if scint_thickness != 10e-2 or ni_scin != 8.79e28:
        raise NotImplementedError("Current inverse gaussian nIRF fit coefficients for 8.79e28 1/m^3 and 10cm only!")

    E_range = np.linspace(E_lower, E_upper, NE_interp)
    sig_H = mat_dict["H"].sigma_tot(E_range)
    sig_C = mat_dict["C12"].sigma_tot(E_range)

    def sig_CH(E):
        sig_barns = CH_ratio * np.interp(E, E_range, sig_C) + (1 - CH_ratio) * np.interp(E, E_range, sig_H)
        return sig_barns * 1e-28

    def IGtail_nIRF_bestfit_coeffs(En):
        """
        Best fit coefficients as a function of neutron energy

        NB these are specific to a scintillator geometry
        For different geometry you must re-perform MCNP/Geant/Scintillator1DMonteCarlo sims

        Analysis performed by A. Crilly, 2025
        """
        E_MeV = En / 1e6
        f = 0.46 * np.ones_like(E_MeV)
        A = 0.25 * np.ones_like(E_MeV)

        mu_inverse_ns = [
            0.45918122858399824,
            0.6557307634639333,
            0.8333427566991481,
            0.8986859864960112,
            1.146202470556479,
            1.2341761264319626,
            1.2686641782526762,
            2.8986506749332044,
            1.4799758893943886,
            2.3823877852359687,
            3.84910816578929,
            3.1966724468523355,
            4.284122083989886,
            3.452849096581845,
            4.838842934652534,
            9.999999999999998,
        ]

        lamb_inverse_ns = [
            0.7552223497006166,
            1.0369636485550817,
            1.1703584280444446,
            1.4085037422394058,
            1.445604993812616,
            1.464511388605816,
            1.6795667261078404,
            1.3844968569428273,
            1.7564016389637123,
            1.6801129259460668,
            1.6345197013154014,
            1.7884346810613823,
            1.7955059618288889,
            1.8762280752322453,
            1.9247350785402442,
            1.8572104736139436,
        ]
        Egrid = 1.0 + np.arange(len(mu_inverse_ns))

        mu = np.interp(E_MeV, Egrid, mu_inverse_ns) * 1e9
        lamb = np.interp(E_MeV, Egrid, lamb_inverse_ns) * 1e9
        return f, A, mu, lamb

    def base(t_detected, En):
        vn = Ekin_2_beta(En, Mn) * c
        t_transit = scint_thickness / vn

        tt_d, tt_a = np.meshgrid(t_detected, t_detected, indexing="ij")
        _, tt_t = np.meshgrid(t_detected, t_transit, indexing="ij")

        f, A, mu, lamb = IGtail_nIRF_bestfit_coeffs(En)

        top_hat_mat = np.eye(t_detected.size) + np.heaviside(tt_d - tt_a, 0.0) - np.heaviside(tt_d - (tt_a + tt_t), 1.0)
        exp_E_arg = f * vn * ni_scin * sig_CH(En)
        main_response = np.exp(-(tt_d - tt_a) * exp_E_arg[None, :]) * top_hat_mat

        t_shift = tt_d - (tt_a + tt_t)
        tail_hat = np.heaviside(t_shift, 0.5)
        t_shift[t_shift < 0.0] = 0.0
        prefactor = lamb / mu
        t_coeff = 2 * mu**2 / lamb
        exp_arg = prefactor[None, :] * (1 - np.sqrt(1 + t_coeff[None, :] * t_shift))
        tail_response = tail_hat * A[None, :] * np.exp(exp_arg)

        R = main_response + tail_response

        row_sum = R.sum(axis=1, keepdims=True)
        row_sum[row_sum == 0] = 1  # avoid div-by-zero
        return R / row_sum

    return base


def decaying_gaussian_kernel(FWHM, tau, shift_sigma=2.0):
    """Single exponential tail multiplied by Gaussian."""
    sig = FWHM / 2.355
    shift_t = shift_sigma * sig

    def kernel(t):
        t_shift = t - shift_t
        erf_arg = (t_shift - sig**2 / tau) / np.sqrt(2 * sig**2)
        g = np.exp(-t_shift / tau) * np.exp(0.5 * sig**2 / tau**2)
        g *= (1 + erf(erf_arg)) / (2 * tau)
        g[t < 0] = 0
        return g / np.trapezoid(g, x=t)

    return kernel


def double_decay_gaussian_kernel(FWHM, taus, frac, shift_sigma=2.0):
    """Weighted sum of two decaying-Gaussian components."""
    k1 = decaying_gaussian_kernel(FWHM, taus[0], shift_sigma)
    k2 = decaying_gaussian_kernel(FWHM, taus[1], shift_sigma)

    def kernel(t):
        out = frac * k1(t) + (1 - frac) * k2(t)
        return out / np.trapezoid(out, x=t)

    return kernel


def gated_decaying_gaussian_kernel(sig, tau, shift_t, sig_turnon):
    """Exponentially decaying Gaussian with logistic gate."""

    def gate(x):
        g = np.where(x > 0, 2 / (1 + np.exp(-x)) - 1, 0)
        return g

    def kernel(t):
        t_shift = t - shift_t
        erf_arg = (t_shift - sig**2 / tau) / np.sqrt(2 * sig**2)
        g = np.exp(-t_shift / tau) * np.exp(0.5 * sig**2 / tau**2)
        g *= (1 + erf(erf_arg)) / (2 * tau)
        g *= gate(t / sig_turnon)
        return g / np.trapezoid(g, x=t)

    return kernel


def t_gaussian_kernel(FWHM, peak_pos):
    """t·Gaussian (often used for leading-edge shaping)."""
    sig = FWHM / 2.355
    mu = (peak_pos**2 - sig**2) / peak_pos

    def kernel(t):
        g = t * np.exp(-0.5 * ((t - mu) / sig) ** 2)
        g[t < 0] = 0
        return g / np.trapezoid(g, x=t)

    return kernel


def make_transit_time_IRF(thickness, kernel_fn, base_matrix_fn=None):
    """
    Parameters
    ----------
    thickness : float
        Sets the detector thickness
    kernel_fn : callable(t) -> 1-D array
        Builds the convolution kernel on the *same* time grid.
    base_matrix_fn : callable(thickness) -> callable(t_detected, En) -> 2-D array  [optional]
        Anything that returns an (N×N) response matrix *before* filtering.
        If omitted, we fall back to the canonical top-hat.
    """
    # Fallback to the usual top-hat if the caller doesn't supply one
    if base_matrix_fn is None:
        base_matrix_fn = top_hat(thickness)
    else:
        base_matrix_fn = base_matrix_fn(thickness)

    def irf(t_detected, En):
        Rbase = base_matrix_fn(t_detected, En)
        kernel = kernel_fn(t_detected - 0.5 * (t_detected[-1] + t_detected[0]))

        Rconv = np.apply_along_axis(lambda m: np.convolve(m, kernel, mode="same"), axis=0, arr=Rbase)

        row_sum = Rconv.sum(axis=1, keepdims=True)
        row_sum[row_sum == 0] = 1
        return Rconv / row_sum

    return irf


class nToF:
    def __init__(
        self,
        distance,
        sensitivity,
        instrument_response_function,
        normtime_start=5.0,
        normtime_end=20.0,
        normtime_N=2048,
        detector_normtime=None,
    ):
        self.distance = distance
        self.sensitivity = sensitivity
        self.instrument_response_function = instrument_response_function

        if detector_normtime is None:
            self.detector_normtime = np.linspace(normtime_start, normtime_end, normtime_N)
        else:
            self.detector_normtime = detector_normtime
        self.detector_time = self.detector_normtime * self.distance / c
        # Init instrument response values
        self.compute_instrument_response()

    def compute_instrument_response(self):
        self.En_det = beta_2_Ekin(1.0 / self.detector_normtime, Mn)

        self.dEdt = Jacobian_dEdnorm_t(self.En_det, Mn)
        self.sens = self.sensitivity(self.En_det)
        self.R = self.instrument_response_function(self.detector_time, self.En_det)

    def get_dNdt(self, En, dNdE):
        dNdE_interp = np.interp(self.En_det, En, dNdE, left=0.0, right=0.0)
        return dNdE_interp * self.dEdt

    def get_signal(self, En, dNdE):
        dNdt = self.get_dNdt(En, dNdE)

        return self.detector_time, self.detector_normtime, np.matmul(self.R, self.sens * dNdt)

    def get_signal_no_IRF(self, En, dNdE):
        dNdt = self.get_dNdt(En, dNdE)

        return self.detector_time, self.detector_normtime, dNdt
