"""
FLAML Random Forest portfolio data.

Extracted verbatim from microsoft/FLAML (MIT license):
  flaml/default/rf/binary.json

1-NN algorithm (from FLAML's README):
  1. Compute query meta-features:
       [NumberOfInstances, NumberOfFeatures, NumberOfClasses,
        PercentageOfNumericFeatures]
  2. Normalize: q_norm = (q - center) / scale
  3. Find neighbor with smallest squared Euclidean distance to q_norm
  4. Use that neighbor's choice[0] as the portfolio index

The portfolio entry at that index contains the hyperparameters that FLAML
meta-learned to work best for datasets similar to the query.

Note: FLAML uses the key "max_leaves"; sklearn's RandomForestClassifier uses
"max_leaf_nodes". The caller in params.py maps the key accordingly.
"""

# ---------------------------------------------------------------------------
# Binary classification  (NumberOfClasses = 2)
# ---------------------------------------------------------------------------
BINARY = {
    "preprocessing": {
        "center": [18000.0, 28.0, 2.0, 0.7565217391304347],
        "scale": [42124.0, 130.0, 1.0, 0.5714285714285715],
    },
    "portfolio": [
        {  # 0 – Amazon_employee_access
            "n_estimators": 501,
            "max_features": 0.24484242524861066,
            "max_leaves": 1156,
            "criterion": "entropy",
        },
        {  # 1 – kc1
            "n_estimators": 356,
            "max_features": 0.1,
            "max_leaves": 102,
            "criterion": "gini",
        },
        {  # 2 – Helena
            "n_estimators": 1000,
            "max_features": 0.1779692423238241,
            "max_leaves": 7499,
            "criterion": "gini",
        },
        {  # 3 – default fallback (empty)
        },
    ],
    "neighbors": [
        {
            "features": [
                1.196467571930491,
                1.0923076923076922,
                0.0,
                0.4260869565217391,
            ],
            "choice": [0, 3],
        },
        {
            "features": [
                11.096856898680088,
                -0.16153846153846155,
                0.0,
                -0.5739130434782609,
            ],
            "choice": [2, 0, 1, 3],
        },
        {
            "features": [
                8.658152122305575,
                0.38461538461538464,
                0.0,
                -0.7405797101449274,
            ],
            "choice": [2, 0, 3],
        },
        {
            "features": [
                0.27281359794891274,
                -0.14615384615384616,
                0.0,
                -1.3239130434782607,
            ],
            "choice": [2, 0, 3],
        },
        {
            "features": [
                -0.4125676573924604,
                -0.1076923076923077,
                0.0,
                -0.5739130434782609,
            ],
            "choice": [2, 1, 0, 3],
        },
        {
            "features": [0.6409647706770487, 1.5538461538461539, 0.0, 0.0],
            "choice": [1, 0, 2, 3],
        },
        {
            "features": [
                2.3515573069983855,
                0.16923076923076924,
                0.0,
                0.4260869565217391,
            ],
            "choice": [2, 0, 3],
        },
        {
            "features": [
                0.6162045389801538,
                -0.1076923076923077,
                0.0,
                -0.5739130434782609,
            ],
            "choice": [0, 2, 1, 3],
        },
        {
            "features": [
                0.5386240622922799,
                -0.09230769230769231,
                0.0,
                -0.5582880434782608,
            ],
            "choice": [0, 2, 3],
        },
        {
            "features": [
                -0.41133320672300827,
                -0.18461538461538463,
                0.0,
                0.4260869565217391,
            ],
            "choice": [1, 2, 0, 3],
        },
        {
            "features": [
                -0.31155635742094767,
                12.36923076923077,
                0.0,
                0.3865087169129372,
            ],
            "choice": [0, 2, 1, 3],
        },
        {
            "features": [
                -0.40594435476213087,
                -0.06153846153846154,
                0.0,
                -0.7114130434782607,
            ],
            "choice": [0, 2, 3],
        },
        {
            "features": [0.0, 32.83076923076923, 0.0, 0.4260869565217391],
            "choice": [0, 2, 3],
        },
        {
            "features": [1.6675766783781218, 0.0, 0.0, 0.4260869565217391],
            "choice": [2, 0, 3],
        },
        {
            "features": [
                -0.36356946158959264,
                0.8923076923076924,
                0.0,
                -1.2266908212560386,
            ],
            "choice": [2, 0, 3],
        },
        {
            "features": [
                -0.38225239768303104,
                -0.05384615384615385,
                0.0,
                0.4260869565217391,
            ],
            "choice": [3],
        },
        {
            "features": [
                -0.3590352293229513,
                0.06153846153846154,
                0.0,
                -1.3239130434782607,
            ],
            "choice": [0, 3],
        },
        {
            "features": [
                0.3090399772101415,
                0.6923076923076923,
                0.0,
                -0.003997789240972687,
            ],
            "choice": [0, 2, 3],
        },
        {
            "features": [
                -0.3118649700883107,
                -0.17692307692307693,
                0.0,
                0.4260869565217391,
            ],
            "choice": [2, 0, 3],
        },
        {"features": [0.0, 32.83076923076923, 0.0, 0.4260869565217391], "choice": [3]},
        {
            "features": [
                -0.3178473079479632,
                -0.06153846153846154,
                0.0,
                0.4260869565217391,
            ],
            "choice": [0, 3],
        },
    ],
}
