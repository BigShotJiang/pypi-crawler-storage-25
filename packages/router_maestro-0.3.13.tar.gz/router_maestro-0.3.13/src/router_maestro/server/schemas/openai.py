"""OpenAI-compatible API schemas."""

from typing import Any

from pydantic import BaseModel, Field


class ChatMessageFunction(BaseModel):
    """Function details in a tool call."""

    name: str
    arguments: str


class ChatMessageToolCall(BaseModel):
    """A tool call in an assistant message."""

    id: str
    type: str = "function"
    function: ChatMessageFunction


class ChatMessage(BaseModel):
    """A message in the chat."""

    role: str
    content: str | list | None = None
    tool_calls: list[ChatMessageToolCall] | None = None
    tool_call_id: str | None = None


class ChatCompletionRequest(BaseModel):
    """Request for chat completion."""

    model: str
    messages: list[ChatMessage]
    temperature: float = Field(default=1.0, ge=0, le=2)
    max_tokens: int | None = None
    stream: bool = False
    top_p: float | None = None
    frequency_penalty: float | None = None
    presence_penalty: float | None = None
    stop: list[str] | str | None = None
    user: str | None = None
    tools: list[dict[str, Any]] | None = None
    tool_choice: str | dict[str, Any] | None = None
    # OpenAI-style reasoning effort: "low" | "medium" | "high"
    # Router-Maestro additionally accepts "xhigh" (downgraded for upstream).
    reasoning_effort: str | None = None
    # Anthropic-style passthrough; some SDKs forward {"type": "...", "budget_tokens": N}
    thinking: dict[str, Any] | None = None


class ChatCompletionChoice(BaseModel):
    """A choice in the chat completion response."""

    index: int
    message: ChatMessage
    finish_reason: str | None


class ChatCompletionUsage(BaseModel):
    """Token usage information."""

    prompt_tokens: int
    completion_tokens: int
    total_tokens: int
    prompt_tokens_details: dict[str, Any] | None = None
    completion_tokens_details: dict[str, Any] | None = None


class ChatCompletionResponse(BaseModel):
    """Response from chat completion."""

    id: str
    object: str = "chat.completion"
    created: int
    model: str
    choices: list[ChatCompletionChoice]
    usage: ChatCompletionUsage | None = None


class ChatCompletionChunkDelta(BaseModel):
    """Delta in a streaming chunk."""

    role: str | None = None
    content: str | None = None
    tool_calls: list[dict[str, Any]] | None = None


class ChatCompletionChunkChoice(BaseModel):
    """A choice in a streaming chunk."""

    index: int
    delta: ChatCompletionChunkDelta
    finish_reason: str | None = None


class ChatCompletionChunk(BaseModel):
    """A chunk in streaming response."""

    id: str
    object: str = "chat.completion.chunk"
    created: int
    model: str
    choices: list[ChatCompletionChunkChoice]
    usage: ChatCompletionUsage | None = None


class ModelObject(BaseModel):
    """A model object."""

    id: str
    object: str = "model"
    created: int = 0
    owned_by: str
    max_prompt_tokens: int | None = None
    max_output_tokens: int | None = None
    max_context_window_tokens: int | None = None
    supports_thinking: bool | None = None
    supports_vision: bool | None = None


class ModelList(BaseModel):
    """List of models."""

    object: str = "list"
    data: list[ModelObject]


class ErrorDetail(BaseModel):
    """Error detail."""

    message: str
    type: str
    code: str | None = None


class ErrorResponse(BaseModel):
    """Error response."""

    error: ErrorDetail
