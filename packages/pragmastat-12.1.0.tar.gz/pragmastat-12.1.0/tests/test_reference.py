import json
from pathlib import Path

import pytest

from pragmastat import (
    DISPARITY_UNIT,
    NUMBER_UNIT,
    RATIO_UNIT,
    Additive,
    Exp,
    Measurement,
    MeasurementUnit,
    Metric,
    Multiplic,
    Power,
    Rng,
    Sample,
    Threshold,
    Uniform,
    center,
    center_bounds,
    compare1,
    compare2,
    disparity,
    ratio,
    ratio_bounds,
    shift,
    shift_bounds,
    spread,
    spread_bounds,
)
from pragmastat.assumptions import AssumptionError
from pragmastat.estimators import (
    _avg_spread as avg_spread,
)
from pragmastat.estimators import (
    _avg_spread_bounds as avg_spread_bounds,
)
from pragmastat.estimators import (
    disparity_bounds,
)
from pragmastat.pairwise_margin import pairwise_margin
from pragmastat.signed_rank_margin import signed_rank_margin


def _assert_violation(err: AssumptionError, expected: dict, context: str = "") -> None:
    """Assert that an AssumptionError has the expected violation fields."""
    assert err.violation is not None, f"Expected violation, got message-only error: {err}{context}"
    assert err.violation.id.value == expected["id"], (
        f"Expected error id '{expected['id']}', got '{err.violation.id.value}'{context}"
    )
    if "subject" in expected:
        assert err.violation.subject == expected["subject"], (
            f"Expected error subject '{expected['subject']}', got '{err.violation.subject}'{context}"
        )


def find_repo_root():
    """Find the repository root by looking for CITATION.cff file."""
    current_dir = Path(__file__).parent
    while current_dir != current_dir.parent:
        if (current_dir / "CITATION.cff").exists():
            return current_dir
        current_dir = current_dir.parent
    raise RuntimeError("Could not find repository root (CITATION.cff not found)")


def _call_estimator(estimator_func, test_case, is_two_sample):
    """Build Sample objects and call the estimator."""
    sx = Sample(test_case["input"]["x"])
    if is_two_sample:
        sy = Sample(test_case["input"]["y"], _subject="y")
        return estimator_func(sx, sy)
    return estimator_func(sx)


def _call_two_sample_bounds(bounds_func, test_case, **kwargs):
    """Build Sample objects and call a two-sample bounds estimator."""
    sx = Sample(test_case["input"]["x"])
    sy = Sample(test_case["input"]["y"], _subject="y")
    return bounds_func(sx, sy, test_case["input"]["misrate"], **kwargs)


def run_reference_tests(estimator_name, estimator_func, is_two_sample=False):
    """Run reference tests against JSON data files."""
    repo_root = find_repo_root()
    test_data_dir = repo_root / "tests" / estimator_name

    json_files = list(test_data_dir.glob("*.json"))
    assert len(json_files) > 0, f"No JSON test files found in {test_data_dir}"

    for json_file in json_files:
        with open(json_file, "r") as f:
            test_case = json.load(f)

        if "expected_error" in test_case:
            expected_error = test_case["expected_error"]
            with pytest.raises(AssumptionError) as exc_info:
                _call_estimator(estimator_func, test_case, is_two_sample)
            _assert_violation(exc_info.value, expected_error, f" for {json_file.name}")
            continue

        expected_output = test_case["output"]
        actual_result = _call_estimator(estimator_func, test_case, is_two_sample)
        actual_output = actual_result.value

        assert abs(actual_output - expected_output) < 1e-9, (
            f"Failed for test file: {json_file.name}, expected: {expected_output}, got: {actual_output}"
        )


def _parse_sample_values(raw_values):
    """Convert JSON values (which may contain 'NaN', 'Infinity', '-Infinity') to floats."""
    result = []
    for v in raw_values:
        if isinstance(v, str):
            if v == "NaN":
                result.append(float("nan"))
            elif v == "Infinity":
                result.append(float("inf"))
            elif v == "-Infinity":
                result.append(float("-inf"))
            else:
                result.append(float(v))
        else:
            result.append(float(v))
    return result


def run_distribution_tests(dist_name, dist_factory):
    """Run distribution reference tests against JSON data files."""
    repo_root = find_repo_root()
    test_data_dir = repo_root / "tests" / "distributions" / dist_name

    json_files = list(test_data_dir.glob("*.json"))
    assert len(json_files) > 0, f"No JSON test files found in {test_data_dir}"

    for json_file in json_files:
        with open(json_file, "r") as f:
            test_case = json.load(f)

        input_data = test_case["input"]
        expected = test_case["output"]
        rng = Rng(input_data["seed"])
        dist = dist_factory(input_data)
        actual = [dist.sample(rng) for _ in range(input_data["count"])]

        assert len(actual) == len(expected), f"Length mismatch for {json_file.name}: {len(actual)} vs {len(expected)}"
        for i, (act, exp) in enumerate(zip(actual, expected)):
            assert abs(act - exp) < 1e-12, f"Failed for {json_file.name}, index {i}: expected {exp}, got {act}"


class TestReference:
    def test_center_reference(self):
        run_reference_tests("center", center)

    def test_spread_reference(self):
        run_reference_tests("spread", spread)

    def test_shift_reference(self):
        run_reference_tests("shift", shift, is_two_sample=True)

    def test_ratio_reference(self):
        run_reference_tests("ratio", ratio, is_two_sample=True)

    def test_avg_spread_reference(self):
        run_reference_tests("avg-spread", avg_spread, is_two_sample=True)

    def test_disparity_reference(self):
        run_reference_tests("disparity", disparity, is_two_sample=True)

    def test_pairwise_margin_reference(self):
        """Test pairwise_margin against reference data."""
        repo_root = find_repo_root()
        test_data_dir = repo_root / "tests" / "pairwise-margin"

        json_files = list(test_data_dir.glob("*.json"))
        assert len(json_files) > 0, f"No JSON test files found in {test_data_dir}"

        for json_file in json_files:
            with open(json_file, "r") as f:
                test_case = json.load(f)

            n = test_case["input"]["n"]
            m = test_case["input"]["m"]
            misrate = test_case["input"]["misrate"]

            # Handle error test cases
            if "expected_error" in test_case:
                expected_error = test_case["expected_error"]
                with pytest.raises(AssumptionError) as exc_info:
                    pairwise_margin(n, m, misrate)
                _assert_violation(exc_info.value, expected_error, f" for {json_file.name}")
                continue

            expected_output = test_case["output"]
            actual_output = pairwise_margin(n, m, misrate)

            assert actual_output == expected_output, (
                f"Failed for test file: {json_file.name}, expected: {expected_output}, got: {actual_output}"
            )

    def test_shift_bounds_reference(self):
        """Test shift_bounds against reference data."""
        repo_root = find_repo_root()
        test_data_dir = repo_root / "tests" / "shift-bounds"

        json_files = list(test_data_dir.glob("*.json"))
        assert len(json_files) > 0, f"No JSON test files found in {test_data_dir}"

        for json_file in json_files:
            with open(json_file, "r") as f:
                test_case = json.load(f)

            input_x = test_case["input"]["x"]
            input_y = test_case["input"]["y"]
            misrate = test_case["input"]["misrate"]

            # Handle error test cases
            if "expected_error" in test_case:
                expected_error = test_case["expected_error"]
                with pytest.raises(AssumptionError) as exc_info:
                    _call_two_sample_bounds(shift_bounds, test_case)
                _assert_violation(exc_info.value, expected_error, f" for {json_file.name}")
                continue

            expected_lower = test_case["output"]["lower"]
            expected_upper = test_case["output"]["upper"]

            result = shift_bounds(Sample(input_x), Sample(input_y, _subject="y"), misrate)

            assert abs(result.lower - expected_lower) < 1e-9, (
                f"Failed lower bound for test file: {json_file.name}, expected: {expected_lower}, got: {result.lower}"
            )
            assert abs(result.upper - expected_upper) < 1e-9, (
                f"Failed upper bound for test file: {json_file.name}, expected: {expected_upper}, got: {result.upper}"
            )

    def test_ratio_bounds_reference(self):
        """Test ratio_bounds against reference data."""
        repo_root = find_repo_root()
        test_data_dir = repo_root / "tests" / "ratio-bounds"

        if not test_data_dir.exists():
            pytest.skip("ratio-bounds test data directory not found")

        json_files = list(test_data_dir.glob("*.json"))
        assert len(json_files) > 0, f"No JSON test files found in {test_data_dir}"

        for json_file in json_files:
            with open(json_file, "r") as f:
                test_case = json.load(f)

            input_x = test_case["input"]["x"]
            input_y = test_case["input"]["y"]
            misrate = test_case["input"]["misrate"]

            # Handle error test cases
            if "expected_error" in test_case:
                expected_error = test_case["expected_error"]
                with pytest.raises(AssumptionError) as exc_info:
                    _call_two_sample_bounds(ratio_bounds, test_case)
                _assert_violation(exc_info.value, expected_error, f" for {json_file.name}")
                continue

            expected_lower = test_case["output"]["lower"]
            expected_upper = test_case["output"]["upper"]

            result = ratio_bounds(Sample(input_x), Sample(input_y, _subject="y"), misrate)

            assert abs(result.lower - expected_lower) < 1e-9, (
                f"Failed lower bound for test file: {json_file.name}, expected: {expected_lower}, got: {result.lower}"
            )
            assert abs(result.upper - expected_upper) < 1e-9, (
                f"Failed upper bound for test file: {json_file.name}, expected: {expected_upper}, got: {result.upper}"
            )

    def test_rng_uniform_reference(self):
        """Test Rng uniform_float() against reference data."""
        repo_root = find_repo_root()
        test_data_dir = repo_root / "tests" / "rng"

        json_files = [f for f in test_data_dir.glob("*.json") if f.name.startswith("uniform-seed-")]
        assert len(json_files) > 0, f"No uniform seed test files found in {test_data_dir}"

        for json_file in json_files:
            with open(json_file, "r") as f:
                test_case = json.load(f)

            seed = test_case["input"]["seed"]
            count = test_case["input"]["count"]
            expected = test_case["output"]

            rng = Rng(seed)
            actual = [rng.uniform_float() for _ in range(count)]

            assert len(actual) == len(expected), (
                f"Length mismatch for {json_file.name}: {len(actual)} vs {len(expected)}"
            )
            for i, (act, exp) in enumerate(zip(actual, expected)):
                assert abs(act - exp) < 1e-15, f"Failed for {json_file.name}, index {i}: expected {exp}, got {act}"

    def test_rng_uniform_int_reference(self):
        """Test Rng uniform_int() against reference data."""
        repo_root = find_repo_root()
        test_data_dir = repo_root / "tests" / "rng"

        json_files = [f for f in test_data_dir.glob("*.json") if f.name.startswith("uniform-int-")]
        assert len(json_files) > 0, f"No uniform int test files found in {test_data_dir}"

        for json_file in json_files:
            with open(json_file, "r") as f:
                test_case = json.load(f)

            seed = test_case["input"]["seed"]
            min_val = test_case["input"]["min"]
            max_val = test_case["input"]["max"]
            count = test_case["input"]["count"]
            expected = test_case["output"]

            rng = Rng(seed)
            actual = [rng.uniform_int(min_val, max_val) for _ in range(count)]

            assert actual == expected, f"Failed for {json_file.name}: expected {expected}, got {actual}"

    def test_rng_string_seed_reference(self):
        """Test Rng with string seeds against reference data."""
        repo_root = find_repo_root()
        test_data_dir = repo_root / "tests" / "rng"

        json_files = [f for f in test_data_dir.glob("*.json") if f.name.startswith("uniform-string-")]
        assert len(json_files) > 0, f"No string seed test files found in {test_data_dir}"

        for json_file in json_files:
            with open(json_file, "r") as f:
                test_case = json.load(f)

            seed = test_case["input"]["seed"]
            count = test_case["input"]["count"]
            expected = test_case["output"]

            rng = Rng(seed)
            actual = [rng.uniform_float() for _ in range(count)]

            assert len(actual) == len(expected), (
                f"Length mismatch for {json_file.name}: {len(actual)} vs {len(expected)}"
            )
            for i, (act, exp) in enumerate(zip(actual, expected)):
                assert abs(act - exp) < 1e-15, f"Failed for {json_file.name}, index {i}: expected {exp}, got {act}"

    def test_rng_uniform_float_range_reference(self):
        """Test Rng uniform_float_range() against reference data."""
        repo_root = find_repo_root()
        test_data_dir = repo_root / "tests" / "rng"

        json_files = [f for f in test_data_dir.glob("*.json") if f.name.startswith("uniform-range-")]
        assert len(json_files) > 0, f"No uniform range test files found in {test_data_dir}"

        for json_file in json_files:
            with open(json_file, "r") as f:
                test_case = json.load(f)

            seed = test_case["input"]["seed"]
            min_val = test_case["input"]["min"]
            max_val = test_case["input"]["max"]
            count = test_case["input"]["count"]
            expected = test_case["output"]

            rng = Rng(seed)
            actual = [rng.uniform_float_range(min_val, max_val) for _ in range(count)]

            assert len(actual) == len(expected), (
                f"Length mismatch for {json_file.name}: {len(actual)} vs {len(expected)}"
            )
            for i, (act, exp) in enumerate(zip(actual, expected)):
                assert abs(act - exp) < 1e-12, f"Failed for {json_file.name}, index {i}: expected {exp}, got {act}"

    def test_rng_uniform_bool_reference(self):
        """Test Rng uniform_bool() against reference data."""
        repo_root = find_repo_root()
        test_data_dir = repo_root / "tests" / "rng"

        json_files = [f for f in test_data_dir.glob("*.json") if f.name.startswith("uniform-bool-seed-")]
        assert len(json_files) > 0, f"No uniform bool test files found in {test_data_dir}"

        for json_file in json_files:
            with open(json_file, "r") as f:
                test_case = json.load(f)

            seed = test_case["input"]["seed"]
            count = test_case["input"]["count"]
            expected = test_case["output"]

            rng = Rng(seed)
            actual = [rng.uniform_bool() for _ in range(count)]

            assert actual == expected, f"Failed for {json_file.name}: expected {expected}, got {actual}"

    def test_shuffle_reference(self):
        """Test Rng shuffle() against reference data."""
        repo_root = find_repo_root()
        test_data_dir = repo_root / "tests" / "shuffle"

        json_files = list(test_data_dir.glob("*.json"))
        assert len(json_files) > 0, f"No shuffle test files found in {test_data_dir}"

        for json_file in json_files:
            with open(json_file, "r") as f:
                test_case = json.load(f)

            seed = test_case["input"]["seed"]
            x = test_case["input"]["x"]
            expected = test_case["output"]

            rng = Rng(seed)
            actual = rng.shuffle(x)

            assert len(actual) == len(expected), (
                f"Length mismatch for {json_file.name}: {len(actual)} vs {len(expected)}"
            )
            for i, (act, exp) in enumerate(zip(actual, expected)):
                assert abs(act - exp) < 1e-15, f"Failed for {json_file.name}, index {i}: expected {exp}, got {act}"

    def test_sample_reference(self):
        """Test Rng sample() against reference data."""
        repo_root = find_repo_root()
        test_data_dir = repo_root / "tests" / "sample"

        json_files = list(test_data_dir.glob("*.json"))
        assert len(json_files) > 0, f"No sample test files found in {test_data_dir}"

        for json_file in json_files:
            with open(json_file, "r") as f:
                test_case = json.load(f)

            seed = test_case["input"]["seed"]
            x = test_case["input"]["x"]
            k = test_case["input"]["k"]
            expected = test_case["output"]

            rng = Rng(seed)
            actual = rng.sample(x, k)

            assert len(actual) == len(expected), (
                f"Length mismatch for {json_file.name}: {len(actual)} vs {len(expected)}"
            )
            for i, (act, exp) in enumerate(zip(actual, expected)):
                assert abs(act - exp) < 1e-15, f"Failed for {json_file.name}, index {i}: expected {exp}, got {act}"

    def test_resample_reference(self):
        """Test Rng resample() against reference data."""
        repo_root = find_repo_root()
        test_data_dir = repo_root / "tests" / "resample"

        json_files = list(test_data_dir.glob("*.json"))
        assert len(json_files) > 0, f"No resample test files found in {test_data_dir}"

        for json_file in json_files:
            with open(json_file, "r") as f:
                test_case = json.load(f)

            seed = test_case["input"]["seed"]
            x = test_case["input"]["x"]
            k = test_case["input"]["k"]
            expected = test_case["output"]

            rng = Rng(seed)
            actual = rng.resample(x, k)

            assert len(actual) == len(expected), (
                f"Length mismatch for {json_file.name}: {len(actual)} vs {len(expected)}"
            )
            for i, (act, exp) in enumerate(zip(actual, expected)):
                assert abs(act - exp) < 1e-15, f"Failed for {json_file.name}, index {i}: expected {exp}, got {act}"

    def test_uniform_distribution_reference(self):
        run_distribution_tests(
            "uniform",
            lambda input_data: Uniform(input_data["min"], input_data["max"]),
        )

    def test_additive_distribution_reference(self):
        run_distribution_tests(
            "additive",
            lambda input_data: Additive(input_data["mean"], input_data["stdDev"]),
        )

    def test_multiplic_distribution_reference(self):
        run_distribution_tests(
            "multiplic",
            lambda input_data: Multiplic(input_data["logMean"], input_data["logStdDev"]),
        )

    def test_exp_distribution_reference(self):
        run_distribution_tests(
            "exp",
            lambda input_data: Exp(input_data["rate"]),
        )

    def test_power_distribution_reference(self):
        run_distribution_tests(
            "power",
            lambda input_data: Power(input_data["min"], input_data["shape"]),
        )

    def test_sample_negative_k_raises(self):
        """Test that sample with negative k raises ValueError."""
        rng = Rng("test-sample-validation")
        with pytest.raises(ValueError):
            rng.sample([1, 2, 3], -1)

    def test_signed_rank_margin_reference(self):
        """Test signed_rank_margin against reference data."""
        repo_root = find_repo_root()
        test_data_dir = repo_root / "tests" / "signed-rank-margin"

        json_files = list(test_data_dir.glob("*.json"))
        assert len(json_files) > 0, f"No JSON test files found in {test_data_dir}"

        for json_file in json_files:
            with open(json_file, "r") as f:
                test_case = json.load(f)

            n = test_case["input"]["n"]
            misrate = test_case["input"]["misrate"]

            # Handle error test cases
            if "expected_error" in test_case:
                expected_error = test_case["expected_error"]
                with pytest.raises(AssumptionError) as exc_info:
                    signed_rank_margin(n, misrate)
                _assert_violation(exc_info.value, expected_error, f" for {json_file.name}")
                continue

            expected_output = test_case["output"]

            actual_output = signed_rank_margin(n, misrate)

            assert actual_output == expected_output, (
                f"Failed for test file: {json_file.name}, expected: {expected_output}, got: {actual_output}"
            )

    def test_center_bounds_reference(self):
        """Test center_bounds against reference data."""
        repo_root = find_repo_root()
        test_data_dir = repo_root / "tests" / "center-bounds"

        json_files = list(test_data_dir.glob("*.json"))
        assert len(json_files) > 0, f"No JSON test files found in {test_data_dir}"

        for json_file in json_files:
            with open(json_file, "r") as f:
                test_case = json.load(f)

            input_x = test_case["input"]["x"]
            misrate = test_case["input"]["misrate"]

            # Handle error test cases
            if "expected_error" in test_case:
                expected_error = test_case["expected_error"]
                with pytest.raises(AssumptionError) as exc_info:
                    center_bounds(Sample(input_x), misrate)
                _assert_violation(exc_info.value, expected_error, f" for {json_file.name}")
                continue

            expected_lower = test_case["output"]["lower"]
            expected_upper = test_case["output"]["upper"]

            result = center_bounds(Sample(input_x), misrate)

            assert abs(result.lower - expected_lower) < 1e-9, (
                f"Failed lower bound for test file: {json_file.name}, expected: {expected_lower}, got: {result.lower}"
            )
            assert abs(result.upper - expected_upper) < 1e-9, (
                f"Failed upper bound for test file: {json_file.name}, expected: {expected_upper}, got: {result.upper}"
            )

    def test_spread_bounds_reference(self):
        """Test spread_bounds against reference data."""
        repo_root = find_repo_root()
        test_data_dir = repo_root / "tests" / "spread-bounds"

        json_files = list(test_data_dir.glob("*.json"))
        assert len(json_files) > 0, f"No JSON test files found in {test_data_dir}"

        for json_file in json_files:
            with open(json_file, "r") as f:
                test_case = json.load(f)

            input_x = test_case["input"]["x"]
            misrate = test_case["input"]["misrate"]
            seed = test_case["input"].get("seed")

            # Handle error test cases
            if "expected_error" in test_case:
                expected_error = test_case["expected_error"]
                with pytest.raises(AssumptionError) as exc_info:
                    spread_bounds(Sample(input_x), misrate, seed=seed)
                _assert_violation(exc_info.value, expected_error, f" for {json_file.name}")
                continue

            expected_lower = test_case["output"]["lower"]
            expected_upper = test_case["output"]["upper"]

            result = spread_bounds(Sample(input_x), misrate, seed=seed)

            assert abs(result.lower - expected_lower) < 1e-9, (
                f"Failed lower bound for test file: {json_file.name}, expected: {expected_lower}, got: {result.lower}"
            )
            assert abs(result.upper - expected_upper) < 1e-9, (
                f"Failed upper bound for test file: {json_file.name}, expected: {expected_upper}, got: {result.upper}"
            )

    def test_avg_spread_bounds_reference(self):
        """Test avg_spread_bounds against reference data."""
        repo_root = find_repo_root()
        test_data_dir = repo_root / "tests" / "avg-spread-bounds"

        if not test_data_dir.exists():
            pytest.skip("avg-spread-bounds test data directory not found")

        json_files = list(test_data_dir.glob("*.json"))
        assert len(json_files) > 0, f"No JSON test files found in {test_data_dir}"

        for json_file in json_files:
            with open(json_file, "r") as f:
                test_case = json.load(f)

            input_x = test_case["input"]["x"]
            input_y = test_case["input"]["y"]
            misrate = test_case["input"]["misrate"]
            seed = test_case["input"].get("seed")

            # Handle error test cases
            if "expected_error" in test_case:
                expected_error = test_case["expected_error"]
                with pytest.raises(AssumptionError) as exc_info:
                    _call_two_sample_bounds(avg_spread_bounds, test_case, seed=seed)
                _assert_violation(exc_info.value, expected_error, f" for {json_file.name}")
                continue

            expected_lower = test_case["output"]["lower"]
            expected_upper = test_case["output"]["upper"]

            result = avg_spread_bounds(Sample(input_x), Sample(input_y, _subject="y"), misrate, seed=seed)

            assert abs(result.lower - expected_lower) < 1e-9, (
                f"Failed lower bound for test file: {json_file.name}, expected: {expected_lower}, got: {result.lower}"
            )
            assert abs(result.upper - expected_upper) < 1e-9, (
                f"Failed upper bound for test file: {json_file.name}, expected: {expected_upper}, got: {result.upper}"
            )

    def test_disparity_bounds_reference(self):
        """Test disparity_bounds against reference data."""
        repo_root = find_repo_root()
        test_data_dir = repo_root / "tests" / "disparity-bounds"

        if not test_data_dir.exists():
            pytest.skip("disparity-bounds test data directory not found")

        json_files = list(test_data_dir.glob("*.json"))
        assert len(json_files) > 0, f"No JSON test files found in {test_data_dir}"

        for json_file in json_files:
            with open(json_file, "r") as f:
                test_case = json.load(f)

            input_x = test_case["input"]["x"]
            input_y = test_case["input"]["y"]
            misrate = test_case["input"]["misrate"]
            seed = test_case["input"].get("seed")

            # Handle error test cases
            if "expected_error" in test_case:
                expected_error = test_case["expected_error"]
                with pytest.raises(AssumptionError) as exc_info:
                    _call_two_sample_bounds(disparity_bounds, test_case, seed=seed)
                _assert_violation(exc_info.value, expected_error, f" for {json_file.name}")
                continue

            expected_lower = test_case["output"]["lower"]
            expected_upper = test_case["output"]["upper"]

            result = disparity_bounds(Sample(input_x), Sample(input_y, _subject="y"), misrate, seed=seed)

            assert abs(result.lower - expected_lower) < 1e-9, (
                f"Failed lower bound for test file: {json_file.name}, expected: {expected_lower}, got: {result.lower}"
            )
            assert abs(result.upper - expected_upper) < 1e-9, (
                f"Failed upper bound for test file: {json_file.name}, expected: {expected_upper}, got: {result.upper}"
            )


class TestSampleConstruction:
    """Tests from tests/sample-construction/ cross-language test data."""

    def test_valid_single(self):
        s = Sample([42.0])
        assert s.size == 1
        assert s.is_weighted is False

    def test_valid_multiple(self):
        s = Sample([1.0, 2.0, 3.0, 4.0, 5.0])
        assert s.size == 5
        assert s.is_weighted is False

    def test_valid_weighted(self):
        s = Sample([1.0, 2.0, 3.0], weights=[0.5, 0.3, 0.2])
        assert s.size == 3
        assert s.is_weighted is True

    def test_error_empty(self):
        with pytest.raises(AssumptionError) as exc_info:
            Sample([])
        assert exc_info.value.violation is not None
        assert exc_info.value.violation.id.value == "validity"
        assert exc_info.value.violation.subject == "x"

    def test_error_nan(self):
        with pytest.raises(AssumptionError) as exc_info:
            Sample([1.0, float("nan"), 3.0])
        assert exc_info.value.violation is not None
        assert exc_info.value.violation.id.value == "validity"
        assert exc_info.value.violation.subject == "x"

    def test_error_inf(self):
        with pytest.raises(AssumptionError) as exc_info:
            Sample([1.0, float("inf"), 3.0])
        assert exc_info.value.violation is not None
        assert exc_info.value.violation.id.value == "validity"
        assert exc_info.value.violation.subject == "x"

    def test_error_neg_inf(self):
        with pytest.raises(AssumptionError) as exc_info:
            Sample([1.0, float("-inf"), 3.0])
        assert exc_info.value.violation is not None
        assert exc_info.value.violation.id.value == "validity"
        assert exc_info.value.violation.subject == "x"


class TestUnitPropagation:
    """Tests from tests/unit-propagation/ cross-language test data."""

    def test_center_preserves_unit(self):
        s = Sample([1, 2, 3, 4, 5], unit=NUMBER_UNIT)
        result = center(s)
        assert isinstance(result, Measurement)
        assert abs(result.value - 3) < 1e-9
        assert result.unit == NUMBER_UNIT

    def test_spread_preserves_unit(self):
        s = Sample([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], unit=NUMBER_UNIT)
        result = spread(s)
        assert isinstance(result, Measurement)
        assert result.unit == NUMBER_UNIT

    def test_shift_preserves_unit(self):
        sx = Sample([1, 2, 3, 4, 5], unit=NUMBER_UNIT)
        sy = Sample([6, 7, 8, 9, 10], unit=NUMBER_UNIT)
        result = shift(sx, sy)
        assert isinstance(result, Measurement)
        assert result.unit == NUMBER_UNIT

    def test_ratio_returns_ratio_unit(self):
        sx = Sample([1, 2, 3, 4, 5], unit=NUMBER_UNIT)
        sy = Sample([6, 7, 8, 9, 10], unit=NUMBER_UNIT)
        result = ratio(sx, sy)
        assert isinstance(result, Measurement)
        assert result.unit == RATIO_UNIT

    def test_disparity_returns_disparity_unit(self):
        sx = Sample([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], unit=NUMBER_UNIT)
        sy = Sample([11, 12, 13, 14, 15, 16, 17, 18, 19, 20], unit=NUMBER_UNIT)
        result = disparity(sx, sy)
        assert isinstance(result, Measurement)
        assert result.unit == DISPARITY_UNIT

    def test_weighted_rejected(self):
        s = Sample([1, 2, 3], weights=[0.5, 0.3, 0.2])
        with pytest.raises(AssumptionError, match="weighted samples are not supported"):
            center(s)


class TestCompare1:
    """Tests from tests/compare1/ cross-language test data."""

    def test_compare1_reference(self):
        """Test compare1 against reference data."""
        repo_root = find_repo_root()
        test_data_dir = repo_root / "tests" / "compare1"

        json_files = list(test_data_dir.glob("*.json"))
        assert len(json_files) > 0, f"No JSON test files found in {test_data_dir}"

        for json_file in json_files:
            with open(json_file, "r") as f:
                test_case = json.load(f)

            input_data = test_case["input"]
            x_values = input_data["x"]
            seed = input_data.get("seed")
            thresholds_data = input_data["thresholds"]

            # Build thresholds
            thresholds = []
            for t_data in thresholds_data:
                metric = Metric(t_data["metric"])
                thresholds.append(Threshold(metric, t_data["value"], t_data["misrate"]))

            # Handle error test cases
            if "expected_error" in test_case:
                expected_error = test_case["expected_error"]
                # Sample creation itself may raise AssumptionError (e.g., empty x)
                with pytest.raises(AssumptionError) as exc_info:  # noqa: PT012
                    sx = Sample(x_values)
                    compare1(sx, thresholds, seed=seed)
                _assert_violation(exc_info.value, expected_error, f" for {json_file.name}")
                continue

            # Normal test case
            expected_projections = test_case["output"]["projections"]

            sx = Sample(x_values)
            projections = compare1(sx, thresholds, seed=seed)

            assert len(projections) == len(expected_projections), (
                f"Projection count mismatch for {json_file.name}: {len(projections)} vs {len(expected_projections)}"
            )

            for i, (actual, expected) in enumerate(zip(projections, expected_projections)):
                context = f" for {json_file.name}, projection {i}"
                assert abs(actual.estimate.value - expected["estimate"]) < 1e-9, (
                    f"Estimate mismatch{context}: expected {expected['estimate']}, got {actual.estimate.value}"
                )
                assert abs(actual.bounds.lower - expected["lower"]) < 1e-9, (
                    f"Lower bound mismatch{context}: expected {expected['lower']}, got {actual.bounds.lower}"
                )
                assert abs(actual.bounds.upper - expected["upper"]) < 1e-9, (
                    f"Upper bound mismatch{context}: expected {expected['upper']}, got {actual.bounds.upper}"
                )
                assert actual.verdict.value == expected["verdict"], (
                    f"Verdict mismatch{context}: expected {expected['verdict']}, got {actual.verdict.value}"
                )

    def test_compare1_supports_measurement_threshold_units(self):
        ms = MeasurementUnit("ms", "Time", "ms", "Millisecond", 1_000_000)
        ns = MeasurementUnit("ns", "Time", "ns", "Nanosecond", 1)
        sx = Sample(list(range(1, 11)), unit=ms)
        thresholds = [Threshold(Metric.CENTER, Measurement(3_000_000, ns), 0.05)]

        [projection] = compare1(sx, thresholds)

        assert abs(projection.estimate.value - 5.5) < 1e-9
        assert projection.estimate.unit == ms
        assert projection.bounds.unit == ms
        assert projection.verdict.value == "greater"


class TestCompare2:
    """Tests from tests/compare2/ cross-language test data."""

    def test_compare2_reference(self):
        """Test compare2 against reference data."""
        repo_root = find_repo_root()
        test_data_dir = repo_root / "tests" / "compare2"

        json_files = list(test_data_dir.glob("*.json"))
        assert len(json_files) > 0, f"No JSON test files found in {test_data_dir}"

        for json_file in json_files:
            with open(json_file, "r") as f:
                test_case = json.load(f)

            input_data = test_case["input"]
            x_values = input_data["x"]
            y_values = input_data["y"]
            seed = input_data.get("seed")
            thresholds_data = input_data["thresholds"]

            # Build thresholds
            thresholds = []
            for t_data in thresholds_data:
                metric = Metric(t_data["metric"])
                thresholds.append(Threshold(metric, t_data["value"], t_data["misrate"]))

            # Handle error test cases
            if "expected_error" in test_case:
                expected_error = test_case["expected_error"]
                # Sample creation itself may raise AssumptionError (e.g., empty x or y)
                with pytest.raises(AssumptionError) as exc_info:  # noqa: PT012
                    sx = Sample(x_values)
                    sy = Sample(y_values, _subject="y")
                    compare2(sx, sy, thresholds, seed=seed)
                _assert_violation(exc_info.value, expected_error, f" for {json_file.name}")
                continue

            # Normal test case
            expected_projections = test_case["output"]["projections"]

            sx = Sample(x_values)
            sy = Sample(y_values, _subject="y")
            projections = compare2(sx, sy, thresholds, seed=seed)

            assert len(projections) == len(expected_projections), (
                f"Projection count mismatch for {json_file.name}: {len(projections)} vs {len(expected_projections)}"
            )

            for i, (actual, expected) in enumerate(zip(projections, expected_projections)):
                context = f" for {json_file.name}, projection {i}"
                assert abs(actual.estimate.value - expected["estimate"]) < 1e-9, (
                    f"Estimate mismatch{context}: expected {expected['estimate']}, got {actual.estimate.value}"
                )
                assert abs(actual.bounds.lower - expected["lower"]) < 1e-9, (
                    f"Lower bound mismatch{context}: expected {expected['lower']}, got {actual.bounds.lower}"
                )
                assert abs(actual.bounds.upper - expected["upper"]) < 1e-9, (
                    f"Upper bound mismatch{context}: expected {expected['upper']}, got {actual.bounds.upper}"
                )
                assert actual.verdict.value == expected["verdict"], (
                    f"Verdict mismatch{context}: expected {expected['verdict']}, got {actual.verdict.value}"
                )

    def test_compare2_supports_measurement_threshold_units(self):
        ms = MeasurementUnit("ms", "Time", "ms", "Millisecond", 1_000_000)
        ns = MeasurementUnit("ns", "Time", "ns", "Nanosecond", 1)
        sx = Sample(list(range(1, 31)), unit=ms)
        sy = Sample([value * 1_000_000 for value in range(21, 51)], unit=ns, _subject="y")
        thresholds = [Threshold(Metric.SHIFT, Measurement(-14, ms), 0.05)]

        [projection] = compare2(sx, sy, thresholds)

        assert abs(projection.estimate.value + 20_000_000) < 1e-9
        assert projection.estimate.unit == ns
        assert projection.bounds.unit == ns
        assert projection.verdict.value == "less"
