"""Owner-aligned operator projections and shared surface wording for CSR-6."""

from __future__ import annotations

from dataclasses import dataclass
import re

from packages.context import ContextAssemblyResult
from packages.contracts import (
    CloneIdentityRecord,
    GoalNode,
    MemoryRecord,
    ProcedureCandidate,
    ProcedureRecord,
    RelationshipMemoryRecord,
    UserCardRecord,
    VerificationBundle,
)


@dataclass(frozen=True, slots=True)
class ProfileOperatorSurface:
    session_id: str
    profile_id: str
    profile_mode: str
    identity: CloneIdentityRecord
    user: UserCardRecord
    relationship: RelationshipMemoryRecord
    provenance: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class WorkOperatorSurface:
    session_id: str
    active_goal_id: str | None
    active_goal_reason: str
    wake_action: str
    wake_factors: tuple[str, ...]
    goal_graph_revision: str | None
    goals: tuple[GoalNode, ...]


@dataclass(frozen=True, slots=True)
class MemoryOperatorDetail:
    memory: MemoryRecord
    state: str | None
    lineage: str | None


@dataclass(frozen=True, slots=True)
class MemorySearchHit:
    memory: MemoryRecord
    score: float
    reasons: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class MemoryOperatorSurface:
    session_id: str
    memories: tuple[MemoryOperatorDetail, ...]
    search_query: str | None = None
    search_hits: tuple[MemorySearchHit, ...] = ()
    scope_reason: str = ""


@dataclass(frozen=True, slots=True)
class ProcedureOperatorDetail:
    procedure: ProcedureRecord
    verification: VerificationBundle | None = None


@dataclass(frozen=True, slots=True)
class ProcedureOperatorSurface:
    session_id: str
    profile_id: str
    procedures: tuple[ProcedureOperatorDetail, ...]
    candidates: tuple[ProcedureCandidate, ...] = ()


@dataclass(frozen=True, slots=True)
class AuditSurface:
    session_id: str
    active_goal_id: str | None
    active_goal_reason: str
    recalled_memory_ids: tuple[str, ...]
    retrieval_requests: tuple[str, ...]
    procedure_overlay_lines: tuple[str, ...]
    procedure_overlay_reason: str
    source_trace: tuple[str, ...]
    rendered_prompt: str


def build_profile_operator_surface(
    *,
    session_id: str,
    profile_id: str,
    profile_mode: str,
    identity: CloneIdentityRecord,
    user: UserCardRecord,
    relationship: RelationshipMemoryRecord,
    provenance: tuple[str, ...] = (),
) -> ProfileOperatorSurface:
    return ProfileOperatorSurface(
        session_id=session_id,
        profile_id=profile_id,
        profile_mode=profile_mode,
        identity=identity,
        user=user,
        relationship=relationship,
        provenance=provenance or ("ProfileGraph.identity", "ProfileGraph.user", "ProfileGraph.relationship"),
    )


def build_work_operator_surface(
    *,
    session_id: str,
    active_goal_id: str | None,
    active_goal_reason: str,
    wake_action: str,
    wake_factors: tuple[str, ...],
    goal_graph_revision: str | None,
    goals: tuple[GoalNode, ...],
) -> WorkOperatorSurface:
    return WorkOperatorSurface(
        session_id=session_id,
        active_goal_id=active_goal_id,
        active_goal_reason=active_goal_reason,
        wake_action=wake_action,
        wake_factors=wake_factors,
        goal_graph_revision=goal_graph_revision,
        goals=goals,
    )


def build_memory_operator_surface(
    *,
    session_id: str,
    memories: tuple[MemoryOperatorDetail, ...],
    search_query: str | None = None,
    search_hits: tuple[MemorySearchHit, ...] = (),
    scope_reason: str = "",
) -> MemoryOperatorSurface:
    return MemoryOperatorSurface(
        session_id=session_id,
        memories=memories,
        search_query=search_query,
        search_hits=search_hits,
        scope_reason=scope_reason,
    )


def build_procedure_operator_surface(
    *,
    session_id: str,
    profile_id: str,
    procedures: tuple[ProcedureOperatorDetail, ...],
    candidates: tuple[ProcedureCandidate, ...] = (),
) -> ProcedureOperatorSurface:
    return ProcedureOperatorSurface(
        session_id=session_id,
        profile_id=profile_id,
        procedures=procedures,
        candidates=candidates,
    )


def build_audit_surface(
    *,
    session_id: str,
    active_goal_id: str | None,
    active_goal_reason: str,
    context_result: ContextAssemblyResult,
) -> AuditSurface:
    procedure_overlay_reason = next(
        (
            trace.reason
            for trace in context_result.source_trace
            if trace.layer_name == "procedure_overlay"
        ),
        "no procedure overlay was needed",
    )
    retrieval_requests = tuple(
        f"{request.request_id}: {', '.join(request.memory_ids) or 'none'} | {request.reason}"
        for request in context_result.plan.retrieval_requests
    )
    procedure_overlay_lines = (
        context_result.frame.procedure_overlay.content
        if context_result.frame is not None
        else ("no active procedure overlay",)
    )
    return AuditSurface(
        session_id=session_id,
        active_goal_id=active_goal_id,
        active_goal_reason=active_goal_reason,
        recalled_memory_ids=context_result.retrieved_memory_ids,
        retrieval_requests=retrieval_requests,
        procedure_overlay_lines=procedure_overlay_lines,
        procedure_overlay_reason=procedure_overlay_reason,
        source_trace=tuple(trace.describe() for trace in context_result.source_trace),
        rendered_prompt=context_result.rendered_prompt,
    )


def library_procedure_overlays(
    *,
    goals: tuple[GoalNode, ...],
    procedures: tuple[ProcedureRecord, ...],
    limit: int = 2,
) -> tuple[str, ...]:
    goal_ids = {goal.goal_id for goal in goals}
    goal_tokens = {
        token
        for goal in goals
        for token in _tokenize(f"{goal.title} {' '.join(goal.evidence_refs)}")
    }
    ranked: list[tuple[float, ProcedureRecord]] = []
    for procedure in procedures:
        if procedure.status not in {"active", "verified", "promoted"}:
            continue
        score = 0.0
        procedure_tokens = _tokenize(f"{procedure.title} {procedure.summary} {' '.join(procedure.trigger_refs)}")
        trigger_goal_ids = {
            trigger.split(":", 1)[1]
            for trigger in procedure.trigger_refs
            if trigger.startswith("goal:") and ":" in trigger
        }
        if goal_ids and goal_ids.intersection(trigger_goal_ids):
            score += 2.5
        if goal_tokens and goal_tokens.intersection(procedure_tokens):
            score += 1.0
        if score > 0.0:
            ranked.append((score, procedure))
    ranked.sort(key=lambda item: (-item[0], item[1].procedure_id))
    overlays: list[str] = []
    for _, procedure in ranked[:limit]:
        step_preview = "; ".join(step.instruction for step in procedure.steps[:2]) or procedure.summary
        overlays.append(
            f"procedure.{procedure.procedure_id}: {procedure.title} | "
            f"verified={procedure.verification_bundle_id or 'missing'} | "
            f"{_compact_text(step_preview, limit=360)}"
        )
    return tuple(overlays)


def render_profile_lines(surface: ProfileOperatorSurface) -> tuple[str, ...]:
    return (
        f"profile_id: {surface.profile_id}",
        f"profile_mode: {surface.profile_mode}",
        f"identity_display_name: {surface.identity.display_name}",
        f"identity_preset: {surface.identity.personality_preset}",
        f"identity_initiative: {surface.identity.initiative}",
        f"user_preferred_name: {surface.user.preferred_name or '<empty>'}",
        f"user_shared_preferences: {', '.join(surface.user.shared_preferences) or '<empty>'}",
        f"relationship_notes: {', '.join(surface.relationship.continuity_notes) or '<empty>'}",
        f"provenance: {', '.join(surface.provenance)}",
    )


def render_work_lines(surface: WorkOperatorSurface) -> tuple[str, ...]:
    goal_lines = tuple(
        f"{goal.goal_id} | {goal.status} | {goal.priority} | {goal.title}"
        for goal in surface.goals
    ) or ("<empty>",)
    return (
        f"active_goal_id: {surface.active_goal_id or '<none>'}",
        f"active_goal_reason: {surface.active_goal_reason}",
        f"wake_action: {surface.wake_action}",
        f"wake_factors: {', '.join(surface.wake_factors) or '<none>'}",
        f"goal_graph_revision: {surface.goal_graph_revision or '<none>'}",
        "goals:",
        *tuple(f"- {line}" for line in goal_lines),
    )


def render_memory_lines(surface: MemoryOperatorSurface) -> tuple[str, ...]:
    lines: list[str] = []
    for item in surface.memories:
        lines.append(
            f"{item.memory.memory_id} | state={item.state or 'active'} | lineage={item.lineage or 'none'} | "
            f"tags={', '.join(item.memory.tags) or 'none'} | {item.memory.kind} | {item.memory.content}"
        )
    if not lines:
        lines.append("<empty>")
    if surface.search_query is not None:
        lines.extend(("", f"search_query: {surface.search_query}", f"scope_reason: {surface.scope_reason or '<none>'}"))
        for hit in surface.search_hits:
            lines.append(
                f"- {hit.memory.memory_id} | score={hit.score:.2f} | reasons={'; '.join(hit.reasons) or '<none>'} | {hit.memory.content}"
            )
    return tuple(lines)


def render_procedure_lines(surface: ProcedureOperatorSurface) -> tuple[str, ...]:
    lines = [f"profile_id: {surface.profile_id}", f"candidate_count: {len(surface.candidates)}", f"procedure_count: {len(surface.procedures)}"]
    if surface.candidates:
        lines.append("candidates:")
        lines.extend(
            f"- {candidate.candidate_id} | support={len(candidate.source_evidence_ids)} | confidence={candidate.confidence:.2f} | {candidate.title}"
            for candidate in surface.candidates
        )
    if surface.procedures:
        lines.append("procedures:")
        lines.extend(
            f"- {detail.procedure.procedure_id} | {detail.procedure.status} | verification={detail.procedure.verification_bundle_id or 'missing'} | skill={detail.procedure.skill_id or 'none'} | {detail.procedure.title}"
            for detail in surface.procedures
        )
    if len(lines) == 3:
        lines.append("<empty>")
    return tuple(lines)


def render_audit_lines(surface: AuditSurface) -> tuple[str, ...]:
    lines = [
        f"active_goal_id: {surface.active_goal_id or '<none>'}",
        f"active_goal_reason: {surface.active_goal_reason}",
        f"recalled_memory_ids: {', '.join(surface.recalled_memory_ids) or '<none>'}",
        f"procedure_overlay_reason: {surface.procedure_overlay_reason}",
        "procedure_overlay:",
        *tuple(f"- {line}" for line in (surface.procedure_overlay_lines or ("no active procedure overlay",))),
        "retrieval_requests:",
        *tuple(f"- {line}" for line in (surface.retrieval_requests or ("none",))),
        "source_trace:",
        *tuple(f"- {line}" for line in surface.source_trace),
    ]
    return tuple(lines)


def _tokenize(text: str) -> set[str]:
    return {token for token in re.findall(r"[A-Za-z0-9_]+", text.lower()) if token}


def _compact_text(text: str, *, limit: int) -> str:
    normalized = " ".join(text.split()).strip()
    if len(normalized) <= limit:
        return normalized
    return normalized[: max(0, limit - 1)].rstrip() + "…"


__all__ = [
    "AuditSurface",
    "MemoryOperatorDetail",
    "MemoryOperatorSurface",
    "MemorySearchHit",
    "ProcedureOperatorDetail",
    "ProcedureOperatorSurface",
    "ProfileOperatorSurface",
    "WorkOperatorSurface",
    "build_audit_surface",
    "build_memory_operator_surface",
    "build_procedure_operator_surface",
    "build_profile_operator_surface",
    "build_work_operator_surface",
    "library_procedure_overlays",
    "render_audit_lines",
    "render_memory_lines",
    "render_procedure_lines",
    "render_profile_lines",
    "render_work_lines",
]
