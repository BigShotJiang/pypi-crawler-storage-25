from __future__ import annotations

from collections.abc import Iterable, Sequence
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
import shlex
import shutil
import sys
import threading
import time

from packages.learning import LearningRuntime
from packages.operator import (
    MemoryOperatorDetail,
    ProcedureOperatorDetail,
    build_audit_surface,
    build_memory_operator_surface,
    build_procedure_operator_surface,
    build_profile_operator_surface,
    build_work_operator_surface,
    render_audit_lines,
    render_memory_lines,
    render_procedure_lines,
    render_profile_lines,
    render_work_lines,
)

from .runtime import CliRuntime, CloneSummary
from .shell_stack import (
    Application,
    BeforeInput,
    Buffer,
    BufferControl,
    Completion,
    Completer,
    Condition,
    ConditionalContainer,
    Console,
    Dimension,
    FileHistory,
    FormattedText,
    FormattedTextControl,
    HSplit,
    KeyBindings,
    Layout,
    PROMPT_TOOLKIT_AVAILABLE,
    Panel,
    RICH_AVAILABLE,
    Style,
    Text,
    Window,
    has_completions,
)
from .shell_ui import (
    BRAND_ACCENT,
    BRAND_ACCENT_STRONG,
    BRAND_DARK,
    BRAND_LIGHT,
    BRAND_MUTED,
    compact_line,
    display_path,
)

DEFAULT_OBSERVE_REFRESH_SECONDS = 2.0
DEFAULT_OBSERVE_PAGE = "overview"
_MAX_SECTION_LINE_LENGTH = 220
_PAGE_JUMP_STEP = 18
_CLONE_PREVIEW_LIMIT = 18
_MEMORY_PREVIEW_LIMIT = 10
_OBSERVE_BANNER_MIN_WIDTH = 72
_OBSERVE_BANNER_MAX_WIDTH = 108


@dataclass(frozen=True, slots=True)
class ObservePageSpec:
    page_id: str
    title: str
    shortcut: str
    summary: str


_OBSERVE_PAGES: tuple[ObservePageSpec, ...] = (
    ObservePageSpec("overview", "Overview", "1", "Entry page with runtime, readiness, and quick guidance."),
    ObservePageSpec("readiness", "Readiness", "2", "Provider, voice, and security checks in one place."),
    ObservePageSpec("profile", "Profile surface", "3", "Identity, user, and relationship continuity."),
    ObservePageSpec("work", "Work surface", "4", "Active goals, wake posture, and graph state."),
    ObservePageSpec("memory", "Memory surface", "5", "Durable memories and their current state."),
    ObservePageSpec("procedure", "Procedure surface", "6", "Verified procedures, candidates, and overlay readiness."),
    ObservePageSpec("audit", "Audit surface", "7", "SessionFrame recall reasons and procedure overlays."),
    ObservePageSpec("clones", "Clone focus", "8", "Known clones, session counts, and focus switching hints."),
)
_PAGE_BY_ID = {page.page_id: page for page in _OBSERVE_PAGES}


@dataclass(frozen=True, slots=True)
class ObserveSnapshot:
    captured_at: datetime
    display_name: str
    profile_mode: str
    provider_id: str
    model_id: str
    provider_status: str
    voice_status: str
    security_status: str
    clone_count: int
    latest_clone_id: str | None
    latest_session_id: str | None
    session_status: str | None
    state_dir: Path
    profile_dir: Path
    database_path: Path
    runtime_lines: tuple[str, ...]
    readiness_lines: tuple[str, ...]
    provider_check_lines: tuple[str, ...]
    voice_check_lines: tuple[str, ...]
    security_check_lines: tuple[str, ...]
    profile_lines: tuple[str, ...]
    work_lines: tuple[str, ...]
    memory_lines: tuple[str, ...]
    procedure_lines: tuple[str, ...]
    audit_lines: tuple[str, ...]
    clone_lines: tuple[str, ...]


@dataclass(slots=True)
class ObserveSurfaceState:
    runtime: CliRuntime
    refresh_seconds: float
    page_id: str = DEFAULT_OBSERVE_PAGE
    focus_clone_id: str | None = None
    show_help: bool = False
    scroll_offset: int = 0
    status_message: str = "Observe ready. Type /help for page, clone, and scroll commands."
    activity_log: list[str] = field(default_factory=list)
    _snapshot: ObserveSnapshot | None = None
    _captured_monotonic: float = 0.0
    _snapshot_lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    def note(self, message: str) -> None:
        normalized = compact_line(message, limit=180)
        self.status_message = normalized
        timestamp = datetime.now().astimezone().strftime("%H:%M:%S")
        self.activity_log.append(f"[{timestamp}] {normalized}")
        if len(self.activity_log) > 12:
            del self.activity_log[:-12]

    def invalidate_snapshot(self) -> None:
        with self._snapshot_lock:
            self._snapshot = None
            self._captured_monotonic = 0.0

    def current_snapshot(self) -> ObserveSnapshot:
        with self._snapshot_lock:
            snapshot = self._snapshot
        if snapshot is not None:
            return snapshot
        return self.refresh_snapshot(force=True)

    def refresh_snapshot(self, *, force: bool = False) -> ObserveSnapshot:
        now = time.monotonic()
        with self._snapshot_lock:
            snapshot = self._snapshot
            captured = self._captured_monotonic
            target_clone_id = self.focus_clone_id
            if (
                not force
                and snapshot is not None
                and (now - captured) < self.refresh_seconds
            ):
                return snapshot
        refreshed = build_observe_snapshot(self.runtime, clone_id=target_clone_id)
        missing_clone_id: str | None = None
        if target_clone_id is not None:
            known_clone_ids = {clone.clone_id for clone in self.runtime.list_clones(limit=128)}
            if target_clone_id not in known_clone_ids:
                missing_clone_id = target_clone_id
                refreshed = build_observe_snapshot(self.runtime)
        with self._snapshot_lock:
            current_focus = self.focus_clone_id
            current_snapshot = self._snapshot
            if current_focus != target_clone_id:
                return current_snapshot if current_snapshot is not None else refreshed
            if missing_clone_id is not None:
                self.focus_clone_id = None
            self._snapshot = refreshed
            self._captured_monotonic = time.monotonic()
        if missing_clone_id is not None:
            self.note(f"Clone `{missing_clone_id}` no longer exists. Observe is following the latest active session instead.")
        return refreshed

    def select_page(self, page_id: str) -> bool:
        resolved = _resolve_page_id(page_id)
        if resolved is None:
            return False
        self.page_id = resolved
        self.scroll_offset = 0
        self.note(f"Switched to {page_title(resolved)}.")
        return True

    def cycle_page(self, step: int) -> None:
        page_ids = [page.page_id for page in _OBSERVE_PAGES]
        current_index = page_ids.index(self.page_id)
        self.page_id = page_ids[(current_index + step) % len(page_ids)]
        self.scroll_offset = 0
        self.note(f"Switched to {page_title(self.page_id)}.")

    def follow_clone(self, clone_id: str | None) -> None:
        normalized = (clone_id or "").strip() or None
        if normalized is None:
            self.focus_clone_id = None
            self.scroll_offset = 0
            self.invalidate_snapshot()
            self.note("Observe is now following the latest active session.")
            return
        clones = self.runtime.list_clones(limit=128)
        if not any(clone.clone_id == normalized for clone in clones):
            self.note(f"Unknown clone `{normalized}`. Open the Clone focus page to inspect available clone ids.")
            return
        self.focus_clone_id = normalized
        self.scroll_offset = 0
        self.invalidate_snapshot()
        self.note(f"Observe is now focused on clone `{normalized}`.")

    def scroll(self, amount: int) -> None:
        if amount == 0:
            return
        total_lines = len(current_page_lines(self.current_snapshot(), self.page_id, activity_log=tuple(self.activity_log)))
        max_offset = max(0, total_lines - 1)
        self.scroll_offset = max(0, min(max_offset, self.scroll_offset + amount))

    def scroll_to_top(self) -> None:
        self.scroll_offset = 0
        self.note("Returned to the top of the current page.")

    def scroll_to_bottom(self) -> None:
        total_lines = len(current_page_lines(self.current_snapshot(), self.page_id, activity_log=tuple(self.activity_log)))
        self.scroll_offset = max(0, total_lines - 1)
        self.note("Jumped to the bottom of the current page.")


def _observe_app_available() -> bool:
    if not PROMPT_TOOLKIT_AVAILABLE:
        return False
    return not any(
        component is None
        for component in (
            Application,
            BeforeInput,
            Buffer,
            BufferControl,
            Condition,
            ConditionalContainer,
            Dimension,
            FormattedTextControl,
            HSplit,
            KeyBindings,
            Layout,
            Style,
            Window,
        )
    )


def _normalize_lines(lines: Iterable[str]) -> tuple[str, ...]:
    normalized = [compact_line(str(line), limit=_MAX_SECTION_LINE_LENGTH) for line in lines if str(line).strip()]
    return tuple(normalized)


def _render_check_lines(checks: object) -> tuple[str, ...]:
    if not isinstance(checks, (list, tuple)):
        return ()
    lines: list[str] = []
    for entry in checks:
        if not isinstance(entry, dict):
            continue
        check = str(entry.get("check") or "check")
        status = str(entry.get("status") or "unknown")
        summary = compact_line(str(entry.get("summary") or ""), limit=132)
        lines.append(f"{check} · {status}" + (f" · {summary}" if summary else ""))
    return tuple(lines)


def _clone_timestamp(value: datetime) -> str:
    return value.astimezone().strftime("%Y-%m-%d %H:%M")


def _build_clone_lines(clones: Sequence[CloneSummary], *, focused_clone_id: str | None) -> tuple[str, ...]:
    if not clones:
        return (
            "No clones yet. Run `aegis born`, `aegis clone`, or `aegis grow` to seed the runtime thread.",
        )
    lines: list[str] = []
    for clone in clones[:_CLONE_PREVIEW_LIMIT]:
        marker = "→" if focused_clone_id == clone.clone_id else " "
        lines.append(
            f"{marker} {clone.clone_id} | {clone.latest_status} | sessions={clone.session_count} | "
            f"updated={_clone_timestamp(clone.updated_at)} | session={clone.latest_session_id[:8]}"
        )
    return tuple(lines)


def _resolve_focus_session(runtime: CliRuntime, *, clone_id: str | None):
    normalized_clone_id = (clone_id or "").strip() or None
    if normalized_clone_id is not None:
        session = runtime.latest_session_for_clone(normalized_clone_id)
        if session is not None:
            return session
    return runtime.latest_session()


def build_observe_snapshot(runtime: CliRuntime, *, clone_id: str | None = None) -> ObserveSnapshot:
    latest_session = _resolve_focus_session(runtime, clone_id=clone_id)
    clones = runtime.list_clones(limit=32)
    provider = dict(runtime.provider_summary())
    provider_doctor = runtime.provider_doctor()
    current_profile = runtime.current_profile()
    active_profile_id = latest_session.profile_id if latest_session is not None else current_profile.state.profile_id
    voice_doctor = runtime.voice_doctor(profile_id=active_profile_id)
    security_doctor = runtime.security_doctor()

    display_name = current_profile.state.display_name or "Aegis"
    profile_mode = current_profile.state.mode or "companion"
    latest_clone_id: str | None = None
    latest_session_id: str | None = None
    session_status: str | None = None
    runtime_lines = [
        f"profile · {display_name} · mode {profile_mode}",
        f"provider · {provider.get('provider_id') or '<unset>'} · model {provider.get('default_model') or '<unset>'}",
        f"paths · state {display_path(runtime.paths.state_dir)} · profile {display_path(runtime.paths.profile_dir)}",
        f"database · {display_path(runtime.paths.database_path)}",
        f"clones · {len(clones)} known · {', '.join(clone.clone_id for clone in clones[:6]) or 'none'}",
    ]
    profile_lines = _normalize_lines(
        render_profile_lines(
            build_profile_operator_surface(
                session_id=latest_session.session_id if latest_session is not None else "<none>",
                profile_id=active_profile_id,
                profile_mode=profile_mode,
                identity=runtime.inspect_identity(profile_id=active_profile_id),
                user=runtime.inspect_user(profile_id=active_profile_id),
                relationship=runtime.inspect_relationship(profile_id=active_profile_id),
            )
        )
    )

    if latest_session is None:
        work_lines = ("No active session yet. Run `aegis born`, `aegis clone`, or `aegis grow` first.",)
        memory_lines = ("No durable memory surface is available until a session exists.",)
        procedure_lines = ("No procedure surface is available until a session exists.",)
        audit_lines = ("No SessionFrame audit is available until a session exists.",)
    else:
        latest_session_id = latest_session.session_id
        latest_clone_id = runtime.clone_id_for_session(latest_session)
        session_status = latest_session.status
        continuity = runtime.inspect_continuity(session_id=latest_session.session_id)
        growth = runtime.inspect_growth(session_id=latest_session.session_id)
        display_name = continuity.profile.state.display_name or display_name
        profile_mode = continuity.profile.state.mode or profile_mode
        runtime_lines.extend(
            [
                f"session · {latest_session.session_id[:8]} · clone {latest_clone_id} · status {latest_session.status}",
                f"continuity · {compact_line(continuity.continuity_summary, limit=132)}",
                f"wake · {continuity.wake_action} · {compact_line(continuity.wake_summary, limit=132)}",
                f"growth · {growth.stage.title} · Lv.{growth.level} · progress {growth.progress_percent}%",
                f"voice binding · {continuity.voice_identity_binding or '<unset>'}",
            ]
        )
        graph = runtime.repository.load_work_graph(latest_session.session_id)
        work_lines = _normalize_lines(
            render_work_lines(
                build_work_operator_surface(
                    session_id=latest_session.session_id,
                    active_goal_id=graph.active_goal_id if graph is not None else None,
                    active_goal_reason=continuity.wake_summary,
                    wake_action=continuity.wake_action,
                    wake_factors=continuity.wake_factors,
                    goal_graph_revision=graph.revision_id if graph is not None else None,
                    goals=graph.goals if graph is not None else (),
                )
            )
        )
        memory_details = tuple(
            MemoryOperatorDetail(
                memory=memory,
                state=runtime.memory_state(memory.memory_id),
                lineage=runtime.memory_lineage(memory.memory_id),
            )
            for memory in runtime.inspect_memories(latest_session.session_id)[:_MEMORY_PREVIEW_LIMIT]
        )
        memory_lines = _normalize_lines(
            render_memory_lines(
                build_memory_operator_surface(
                    session_id=latest_session.session_id,
                    memories=memory_details,
                )
            )
        )
        learning = LearningRuntime(runtime.repository)
        procedure_library = runtime.repository.load_procedure_library(active_profile_id)
        procedure_details = tuple(
            ProcedureOperatorDetail(
                procedure=procedure,
                verification=(
                    runtime.repository.load_verification_bundle(procedure.verification_bundle_id)
                    if procedure.verification_bundle_id is not None
                    else None
                ),
            )
            for procedure in (procedure_library.procedures if procedure_library is not None else ())
        )
        procedure_candidates = learning.list_procedure_candidates(
            profile_id=active_profile_id,
            session_id=latest_session.session_id,
        )
        procedure_lines = _normalize_lines(
            render_procedure_lines(
                build_procedure_operator_surface(
                    session_id=latest_session.session_id,
                    profile_id=active_profile_id,
                    procedures=procedure_details,
                    candidates=procedure_candidates,
                )
            )
        )
        audit_lines = _normalize_lines(
            render_audit_lines(
                build_audit_surface(
                    session_id=latest_session.session_id,
                    active_goal_id=graph.active_goal_id if graph is not None else None,
                    active_goal_reason=continuity.wake_summary,
                    context_result=runtime.inspect_context_frame(latest_session.session_id),
                )
            )
        )

    provider_check_lines = _render_check_lines(provider_doctor.get("checks"))
    voice_check_lines = _render_check_lines(voice_doctor.get("checks"))
    security_check_lines = _render_check_lines(security_doctor.get("checks"))
    readiness_lines = (
        f"provider · {provider_doctor.get('status') or 'unknown'}",
        *provider_check_lines,
        "",
        f"voice · {voice_doctor.get('status') or 'unknown'}",
        *voice_check_lines,
        "",
        f"security · {security_doctor.get('status') or 'unknown'}",
        *security_check_lines,
    )
    focused_clone_id = latest_clone_id or ((clone_id or "").strip() or None)
    clone_lines = _build_clone_lines(clones, focused_clone_id=focused_clone_id)

    return ObserveSnapshot(
        captured_at=datetime.now().astimezone(),
        display_name=display_name,
        profile_mode=profile_mode,
        provider_id=str(provider.get("provider_id") or "<unset>"),
        model_id=str(provider.get("default_model") or "<unset>"),
        provider_status=str(provider_doctor.get("status") or "unknown"),
        voice_status=str(voice_doctor.get("status") or "unknown"),
        security_status=str(security_doctor.get("status") or "unknown"),
        clone_count=len(clones),
        latest_clone_id=latest_clone_id,
        latest_session_id=latest_session_id,
        session_status=session_status,
        state_dir=runtime.paths.state_dir,
        profile_dir=runtime.paths.profile_dir,
        database_path=runtime.paths.database_path,
        runtime_lines=_normalize_lines(runtime_lines),
        readiness_lines=_normalize_lines(readiness_lines),
        provider_check_lines=provider_check_lines,
        voice_check_lines=voice_check_lines,
        security_check_lines=security_check_lines,
        profile_lines=profile_lines,
        work_lines=work_lines,
        memory_lines=memory_lines,
        procedure_lines=procedure_lines,
        audit_lines=audit_lines,
        clone_lines=clone_lines,
    )


def page_title(page_id: str) -> str:
    page = _PAGE_BY_ID.get(page_id)
    return page.title if page is not None else "Observe"


def _resolve_page_id(page_id: str | None) -> str | None:
    if page_id is None:
        return None
    normalized = page_id.strip().lower()
    if normalized in _PAGE_BY_ID:
        return normalized
    for page in _OBSERVE_PAGES:
        if normalized == page.shortcut.lower() or normalized == page.title.lower():
            return page.page_id
    return None


def _section_lines(title: str, lines: Sequence[str]) -> tuple[str, ...]:
    return (title, *tuple(lines), "")


def _preview_section_lines(
    title: str,
    lines: Sequence[str],
    *,
    page_id: str,
    limit: int,
) -> tuple[str, ...]:
    non_empty = [line for line in lines if line]
    preview = non_empty[:limit]
    rendered = [title, *preview]
    remaining = max(0, len(non_empty) - len(preview))
    if remaining > 0:
        rendered.append(f"… open `/page {page_id}` for {remaining} more line(s).")
    rendered.append("")
    return tuple(rendered)


def _overview_lines(snapshot: ObserveSnapshot, *, activity_log: Sequence[str]) -> tuple[str, ...]:
    hero_lines = [
        "Aegis Observe",
        "Overview of the runtime thread. Open a page below when you want the full surface.",
        f"captured_at: {snapshot.captured_at.isoformat(timespec='seconds')}",
        f"display_name: {snapshot.display_name} · mode: {snapshot.profile_mode}",
        f"focus_clone: {snapshot.latest_clone_id or '<none>'} · focus_session: {snapshot.latest_session_id or '<none>'}",
        f"session_status: {snapshot.session_status or '<none>'}",
        f"provider: {snapshot.provider_id} · model: {snapshot.model_id}",
        f"readiness: provider={snapshot.provider_status} · voice={snapshot.voice_status} · security={snapshot.security_status}",
        "",
        "Pages",
    ]
    hero_lines.extend(
        f"{page.shortcut}. {page.title} — {page.summary}" for page in _OBSERVE_PAGES
    )
    hero_lines.extend(
        (
            "",
            "Commands",
            "/page <id> · /clone <id> · /latest · /refresh · /top · /bottom · /scroll <n> · /help · /quit",
            "",
        )
    )
    if activity_log:
        hero_lines.extend(("Recent activity", *activity_log[-5:], ""))
    return tuple(
        hero_lines
        + list(_preview_section_lines("Readiness", snapshot.readiness_lines, page_id="readiness", limit=6))
        + list(_preview_section_lines("Runtime inventory", snapshot.runtime_lines, page_id="readiness", limit=4))
        + list(_preview_section_lines("Profile surface", snapshot.profile_lines, page_id="profile", limit=3))
        + list(_preview_section_lines("Work surface", snapshot.work_lines, page_id="work", limit=4))
        + list(_preview_section_lines("Memory surface", snapshot.memory_lines, page_id="memory", limit=3))
        + list(_preview_section_lines("Procedure surface", snapshot.procedure_lines, page_id="procedure", limit=3))
        + list(_preview_section_lines("Audit surface", snapshot.audit_lines, page_id="audit", limit=3))
    )


def current_page_lines(
    snapshot: ObserveSnapshot,
    page_id: str,
    *,
    activity_log: Sequence[str] = (),
) -> tuple[str, ...]:
    if page_id == "overview":
        return _overview_lines(snapshot, activity_log=activity_log)
    if page_id == "readiness":
        return (
            f"Readiness for {snapshot.display_name}",
            f"captured_at: {snapshot.captured_at.isoformat(timespec='seconds')}",
            "",
            *snapshot.readiness_lines,
        )
    if page_id == "profile":
        return (
            f"Profile surface for {snapshot.display_name}",
            f"focus_clone: {snapshot.latest_clone_id or '<none>'}",
            "",
            *snapshot.profile_lines,
        )
    if page_id == "work":
        return (
            f"Work surface for {snapshot.latest_clone_id or snapshot.display_name}",
            f"focus_session: {snapshot.latest_session_id or '<none>'}",
            "",
            *snapshot.work_lines,
        )
    if page_id == "memory":
        return (
            f"Memory surface for {snapshot.latest_clone_id or snapshot.display_name}",
            f"focus_session: {snapshot.latest_session_id or '<none>'}",
            "",
            *snapshot.memory_lines,
        )
    if page_id == "procedure":
        return (
            f"Procedure surface for {snapshot.latest_clone_id or snapshot.display_name}",
            f"focus_session: {snapshot.latest_session_id or '<none>'}",
            "",
            *snapshot.procedure_lines,
        )
    if page_id == "audit":
        return (
            f"Audit surface for {snapshot.latest_clone_id or snapshot.display_name}",
            f"focus_session: {snapshot.latest_session_id or '<none>'}",
            "",
            *snapshot.audit_lines,
        )
    if page_id == "clones":
        return (
            "Clone focus",
            "Use `/clone <id>` to follow a named clone, or `/latest` to return to the newest session.",
            "",
            *snapshot.clone_lines,
        )
    return (
        "Observe",
        "Unknown page. Use `/page overview` or `/help`.",
    )


def _visible_page_lines(lines: Sequence[str], *, scroll_offset: int) -> tuple[str, ...]:
    if scroll_offset <= 0:
        return tuple(lines)
    visible = [f"↑ {scroll_offset} earlier line(s) hidden above", ""]
    visible.extend(lines[scroll_offset:])
    return tuple(visible)


def render_observe_view(snapshot: ObserveSnapshot, *, page_id: str = DEFAULT_OBSERVE_PAGE):
    resolved_page = _resolve_page_id(page_id) or DEFAULT_OBSERVE_PAGE
    lines = current_page_lines(snapshot, resolved_page)
    if not RICH_AVAILABLE or Panel is None or Text is None:
        return "\n".join(lines)
    body = Text()
    for line in lines:
        style = f"bold {BRAND_ACCENT}" if line in {
            "Aegis Observe",
            "Pages",
            "Commands",
            "Recent activity",
            "Readiness",
            "Runtime inventory",
            "Profile surface",
            "Work surface",
            "Memory surface",
            "Procedure surface",
            "Audit surface",
            "Clone focus",
        } else BRAND_LIGHT
        body.append(f"{line}\n", style=style)
    return Panel(
        body,
        title=f"[bold {BRAND_ACCENT}] 🧠 Aegis Observe · {page_title(resolved_page)} [/bold {BRAND_ACCENT}]",
        subtitle=f"[bold {BRAND_LIGHT}]Here with you, built to stay.[/bold {BRAND_LIGHT}]",
        border_style=BRAND_ACCENT,
        padding=(1, 2),
    )


class ObserveCommandCompleter(Completer):
    _COMMANDS = (
        "/page",
        "/clone",
        "/latest",
        "/refresh",
        "/help",
        "/top",
        "/bottom",
        "/scroll",
        "/quit",
        "/next",
        "/prev",
    )

    def __init__(self, state: ObserveSurfaceState) -> None:
        self._state = state

    def get_completions(self, document, _complete_event):
        text = document.text_before_cursor.lstrip()
        if not text:
            for command in self._COMMANDS:
                yield Completion(command, start_position=0, display=command)
            return
        parts = text.split()
        if not parts:
            return
        head = parts[0]
        if len(parts) == 1 and not text.endswith(" "):
            for command in self._COMMANDS:
                if command.startswith(head):
                    yield Completion(command, start_position=-len(head), display=command)
            for page in _OBSERVE_PAGES:
                if page.page_id.startswith(head.lstrip("/")):
                    yield Completion(page.page_id, start_position=-len(head), display=page.page_id)
            return
        if head in {"/page", "page"}:
            tail = parts[-1] if not text.endswith(" ") else ""
            for page in _OBSERVE_PAGES:
                if page.page_id.startswith(tail):
                    yield Completion(page.page_id, start_position=-len(tail), display=page.page_id)
            return
        if head in {"/clone", "clone"}:
            snapshot = self._state.current_snapshot()
            tail = parts[-1] if not text.endswith(" ") else ""
            for line in snapshot.clone_lines:
                clone_id = line.split("|", 1)[0].replace("→", "").strip()
                if clone_id.startswith(tail):
                    yield Completion(clone_id, start_position=-len(tail), display=clone_id)


def _observe_banner_width() -> int:
    columns = shutil.get_terminal_size((100, 24)).columns
    return max(_OBSERVE_BANNER_MIN_WIDTH, min(_OBSERVE_BANNER_MAX_WIDTH, max(72, columns - 6)))


def _center_banner_line(value: str, *, width: int) -> str:
    trimmed = compact_line(value, limit=width)
    return trimmed.center(width)


def _observe_auto_refresh_interval(refresh_seconds: float) -> float:
    return max(0.5, float(refresh_seconds))


def _observe_prompt_style():
    if Style is None:
        return None
    return Style.from_dict(
        {
            "": f"fg:{BRAND_LIGHT}",
            "observe-header-kicker": f"fg:{BRAND_ACCENT} bold",
            "observe-header-title": f"fg:{BRAND_LIGHT} bold",
            "observe-header-copy": f"fg:{BRAND_MUTED}",
            "observe-header-meta": f"fg:{BRAND_ACCENT_STRONG} bold",
            "observe-header-detail": f"fg:{BRAND_MUTED}",
            "observe-nav-title": f"fg:{BRAND_ACCENT} bold",
            "observe-nav-active": f"fg:{BRAND_ACCENT_STRONG} bold",
            "observe-nav": f"fg:{BRAND_LIGHT}",
            "observe-nav-muted": f"fg:{BRAND_MUTED}",
            "observe-page-title": f"fg:{BRAND_ACCENT} bold",
            "observe-page-body": f"fg:{BRAND_LIGHT}",
            "observe-page-muted": f"fg:{BRAND_MUTED}",
            "observe-status-label": f"bg:#1b2029 fg:{BRAND_ACCENT} bold",
            "observe-status-value": f"bg:#1b2029 fg:{BRAND_LIGHT}",
            "observe-status-muted": f"bg:#1b2029 fg:{BRAND_MUTED}",
            "observe-divider": f"fg:{BRAND_DARK}",
            "observe-input-prefix": f"fg:{BRAND_ACCENT_STRONG} bold",
            "observe-help-title": f"fg:{BRAND_ACCENT} bold",
            "observe-help-body": f"fg:{BRAND_LIGHT}",
            "observe-help-muted": f"fg:{BRAND_MUTED}",
            "completion-menu": "bg:#1b2029",
            "completion-menu.completion": f"bg:#1b2029 fg:{BRAND_LIGHT}",
            "completion-menu.completion.current": f"bg:#2a3343 fg:{BRAND_ACCENT_STRONG} bold",
            "completion-menu.meta.completion": f"bg:#1b2029 fg:{BRAND_MUTED}",
            "completion-menu.meta.completion.current": f"bg:#2a3343 fg:{BRAND_LIGHT}",
        }
    )


def _header_fragments(state: ObserveSurfaceState) -> FormattedText:
    snapshot = state.current_snapshot()
    focus_clone = snapshot.latest_clone_id or state.focus_clone_id or "<latest>"
    focus_session = snapshot.latest_session_id[:8] if snapshot.latest_session_id else "<none>"
    width = _observe_banner_width()
    display_name = compact_line(snapshot.display_name or "Aegis", limit=28)
    model_id = compact_line(snapshot.model_id, limit=max(24, width - 28))
    lines = (
        ("class:observe-header-kicker", _center_banner_line("AEGIS // observe", width=width)),
        ("class:observe-header-title", _center_banner_line("Here with you, built to stay.", width=width)),
        (
            "class:observe-header-copy",
            _center_banner_line("Persistent memory · long-horizon decisions · long context", width=width),
        ),
        (
            "class:observe-header-meta",
            _center_banner_line(f"Aegis Observe · {display_name} · {page_title(state.page_id)}", width=width),
        ),
        (
            "class:observe-header-detail",
            _center_banner_line(
                f"focus {focus_clone} · session {focus_session} · provider {snapshot.provider_id} · model {model_id}",
                width=width,
            ),
        ),
    )
    fragments: list[tuple[str, str]] = []
    for index, (style, line) in enumerate(lines):
        fragments.append((style, line))
        if index < len(lines) - 1:
            fragments.append(("", "\n"))
    return FormattedText(fragments)


def _navigation_fragments(state: ObserveSurfaceState) -> FormattedText:
    snapshot = state.current_snapshot()
    focus_clone = snapshot.latest_clone_id or state.focus_clone_id or "<latest>"
    fragments: list[tuple[str, str]] = [("class:observe-nav-title", "Pages ")]
    for index, page in enumerate(_OBSERVE_PAGES):
        if index:
            fragments.append(("class:observe-nav-muted", " · "))
        style = "class:observe-nav-active" if state.page_id == page.page_id else "class:observe-nav"
        fragments.append((style, f"[{page.shortcut}] {page.title}"))
    fragments.extend(
        [
            ("", "\n"),
            ("class:observe-nav-muted", f"clone {focus_clone} · "),
            ("class:observe-nav-muted", f"clones {snapshot.clone_count} known · "),
            ("class:observe-nav-muted", "use /page, /clone, PgUp/PgDn, or /help"),
        ]
    )
    return FormattedText(fragments)


def _content_fragments(state: ObserveSurfaceState) -> FormattedText:
    snapshot = state.current_snapshot()
    page_lines = current_page_lines(snapshot, state.page_id, activity_log=tuple(state.activity_log))
    visible_lines = _visible_page_lines(page_lines, scroll_offset=state.scroll_offset)
    fragments: list[tuple[str, str]] = []
    for index, line in enumerate(visible_lines):
        if index == 0:
            fragments.append(("class:observe-page-title", f"{line}\n"))
            continue
        if not line:
            fragments.append(("", "\n"))
            continue
        style = "class:observe-page-muted" if line.startswith("↑ ") else "class:observe-page-body"
        fragments.append((style, f"{line}\n"))
    return FormattedText(fragments)


def _help_fragments(_state: ObserveSurfaceState) -> FormattedText:
    lines = (
        "Command sheet",
        "/page <id>      switch to overview/readiness/profile/work/memory/procedure/audit/clones",
        "/clone <id>     follow a named clone from the clone focus page",
        "/latest         follow the latest active session again",
        "/refresh        force a new snapshot now",
        "/top /bottom    jump to the top or bottom of the page",
        "/scroll <n>     move the page by n lines (negative numbers go up)",
        "/next /prev     switch pages without typing the page id",
        "/help           toggle this command sheet",
        "/quit           leave observe",
        "",
        "Keys: PageUp/PageDown scroll · Ctrl-N/Ctrl-P pages · Ctrl-R refresh · F1 help · Ctrl-C exit",
    )
    fragments: list[tuple[str, str]] = []
    for index, line in enumerate(lines):
        style = "class:observe-help-title" if index == 0 else "class:observe-help-body"
        if line.startswith("Keys:"):
            style = "class:observe-help-muted"
        fragments.append((style, f"{line}\n"))
    return FormattedText(fragments)


def _status_fragments(state: ObserveSurfaceState) -> FormattedText:
    snapshot = state.current_snapshot()
    total_lines = len(current_page_lines(snapshot, state.page_id, activity_log=tuple(state.activity_log)))
    focus_clone = snapshot.latest_clone_id or state.focus_clone_id or "<latest>"
    fragments: list[tuple[str, str]] = [
        ("class:observe-status-label", " observe "),
        ("class:observe-status-value", f" {page_title(state.page_id)} "),
        ("class:observe-status-muted", " · "),
        ("class:observe-status-label", " clone "),
        ("class:observe-status-value", f" {focus_clone} "),
        ("class:observe-status-muted", " · "),
        ("class:observe-status-label", " scroll "),
        ("class:observe-status-value", f" {state.scroll_offset}/{max(0, total_lines - 1)} "),
        ("class:observe-status-muted", " · "),
        ("class:observe-status-label", " refresh "),
        ("class:observe-status-value", f" {state.refresh_seconds:.1f}s "),
        ("class:observe-status-muted", f" · {state.status_message}"),
    ]
    return FormattedText(fragments)


def _divider_window() -> Window:
    return Window(
        FormattedTextControl(
            lambda: [("class:observe-divider", "─" * max(24, shutil.get_terminal_size((100, 24)).columns - 1))]
        ),
        height=1,
        dont_extend_height=True,
    )


def _execute_observe_command(
    state: ObserveSurfaceState,
    command: str,
    *,
    application,
) -> None:
    raw = command.strip()
    if not raw:
        state.note("Type /help to see observe commands.")
        return
    try:
        parts = shlex.split(raw)
    except ValueError as error:
        state.note(f"Could not parse command: {error}.")
        return
    if not parts:
        state.note("Type /help to see observe commands.")
        return
    head = parts[0].lower()
    args = parts[1:]
    normalized_head = head[1:] if head.startswith("/") else head

    if normalized_head in {page.page_id for page in _OBSERVE_PAGES}:
        state.select_page(normalized_head)
        return
    if normalized_head == "page":
        if not args:
            state.note("Use `/page overview|readiness|profile|work|memory|procedure|audit|clones`.")
            return
        if not state.select_page(args[0]):
            state.note(f"Unknown page `{args[0]}`.")
        return
    if normalized_head == "clone":
        if not args:
            state.note("Use `/clone <id>` to focus a clone or open the Clone focus page for candidates.")
            return
        state.follow_clone(args[0])
        if state.focus_clone_id == args[0].strip():
            state.refresh_snapshot(force=True)
        return
    if normalized_head == "latest":
        state.follow_clone(None)
        state.refresh_snapshot(force=True)
        return
    if normalized_head in {"refresh", "r"}:
        state.refresh_snapshot(force=True)
        state.note("Refreshed the observe snapshot.")
        return
    if normalized_head == "help":
        state.show_help = not state.show_help
        state.note("Toggled the command sheet.")
        return
    if normalized_head == "top":
        state.scroll_to_top()
        return
    if normalized_head == "bottom":
        state.scroll_to_bottom()
        return
    if normalized_head == "scroll":
        if not args:
            state.note("Use `/scroll <n>` with a positive or negative integer.")
            return
        try:
            amount = int(args[0])
        except ValueError:
            state.note(f"`{args[0]}` is not an integer line offset.")
            return
        state.scroll(amount)
        state.note(f"Scrolled {amount} line(s).")
        return
    if normalized_head == "next":
        state.cycle_page(1)
        return
    if normalized_head == "prev":
        state.cycle_page(-1)
        return
    if normalized_head in {"quit", "exit", "q"}:
        application.exit(result=0)
        return
    state.note(f"Unknown command `{raw}`. Type /help for the observe command sheet.")


def _run_interactive_observe_surface(
    runtime: CliRuntime,
    *,
    refresh_seconds: float,
    page_id: str,
    clone_id: str | None,
) -> int:
    state = ObserveSurfaceState(
        runtime=runtime,
        refresh_seconds=max(0.5, float(refresh_seconds)),
        page_id=_resolve_page_id(page_id) or DEFAULT_OBSERVE_PAGE,
        focus_clone_id=(clone_id or "").strip() or None,
    )
    state.note("Observe opened. Use /page, /clone, /help, and /refresh from the input rail below.")
    state.refresh_snapshot(force=True)

    buffer = Buffer(
        multiline=False,
        completer=ObserveCommandCompleter(state),
        complete_while_typing=True,
        history=FileHistory(str(runtime.paths.state_dir / "observe-history.txt")) if FileHistory is not None else None,
    )
    input_control = BufferControl(
        buffer=buffer,
        input_processors=[BeforeInput("observe › ", style="class:observe-input-prefix")],
        focus_on_click=True,
        focusable=True,
    )
    input_window = Window(
        input_control,
        wrap_lines=False,
        dont_extend_height=True,
        height=Dimension(min=1, preferred=1, max=1),
    )

    header_window = Window(
        FormattedTextControl(lambda: _header_fragments(state)),
        height=5,
        dont_extend_height=True,
    )
    navigation_window = Window(
        FormattedTextControl(lambda: _navigation_fragments(state)),
        height=Dimension(min=2, preferred=2, max=3),
        dont_extend_height=True,
        wrap_lines=True,
    )
    content_window = Window(
        FormattedTextControl(lambda: _content_fragments(state)),
        wrap_lines=True,
        always_hide_cursor=True,
    )
    help_window = ConditionalContainer(
        content=Window(
            FormattedTextControl(lambda: _help_fragments(state)),
            height=Dimension(min=6, preferred=8, max=10),
            dont_extend_height=True,
            wrap_lines=True,
        ),
        filter=Condition(lambda: state.show_help),
    )
    status_window = Window(
        FormattedTextControl(lambda: _status_fragments(state)),
        height=1,
        dont_extend_height=True,
    )

    command_palette = None
    if has_completions is not None:
        from .shell_stack import CompletionsMenu

        if CompletionsMenu is not None:
            command_palette = ConditionalContainer(
                content=CompletionsMenu(max_height=6, scroll_offset=1),
                filter=has_completions,
            )

    def _refocus_input(event) -> None:
        event.app.layout.focus(input_control)

    def _submit(event) -> None:
        text = buffer.text
        if text:
            buffer.append_to_history()
        buffer.text = ""
        _execute_observe_command(state, text, application=event.app)
        _refocus_input(event)
        event.app.invalidate()

    bindings = KeyBindings()

    @bindings.add("enter")
    def _enter(event) -> None:
        _submit(event)

    @bindings.add("c-c")
    def _interrupt(event) -> None:
        event.app.exit(result=0)

    @bindings.add("c-d")
    def _eof(event) -> None:
        event.app.exit(result=0)

    @bindings.add("c-r")
    def _refresh(event) -> None:
        state.refresh_snapshot(force=True)
        state.note("Refreshed the observe snapshot.")
        _refocus_input(event)
        event.app.invalidate()

    @bindings.add("f1")
    def _help(event) -> None:
        state.show_help = not state.show_help
        state.note("Toggled the command sheet.")
        _refocus_input(event)
        event.app.invalidate()

    @bindings.add("c-n")
    def _next_page(event) -> None:
        state.cycle_page(1)
        _refocus_input(event)
        event.app.invalidate()

    @bindings.add("c-p")
    def _prev_page(event) -> None:
        state.cycle_page(-1)
        _refocus_input(event)
        event.app.invalidate()

    @bindings.add("pageup")
    def _page_up(event) -> None:
        state.scroll(-_PAGE_JUMP_STEP)
        _refocus_input(event)
        event.app.invalidate()

    @bindings.add("pagedown")
    def _page_down(event) -> None:
        state.scroll(_PAGE_JUMP_STEP)
        _refocus_input(event)
        event.app.invalidate()

    @bindings.add("home")
    def _home(event) -> None:
        state.scroll_to_top()
        _refocus_input(event)
        event.app.invalidate()

    @bindings.add("end")
    def _end(event) -> None:
        state.scroll_to_bottom()
        _refocus_input(event)
        event.app.invalidate()

    help_divider = ConditionalContainer(
        content=_divider_window(),
        filter=Condition(lambda: state.show_help),
    )
    body_children = [header_window, _divider_window(), navigation_window, help_divider, help_window]
    if command_palette is not None:
        body_children.append(command_palette)
    body_children.extend(
        [
            _divider_window(),
            content_window,
            _divider_window(),
            status_window,
            _divider_window(),
            input_window,
        ]
    )
    layout = Layout(HSplit(body_children), focused_element=input_control)
    application = Application(
        layout=layout,
        key_bindings=bindings,
        style=_observe_prompt_style(),
        full_screen=True,
        mouse_support=True,
        refresh_interval=_observe_auto_refresh_interval(state.refresh_seconds),
    )
    stop_event = threading.Event()

    def _refresh_snapshot_loop() -> None:
        interval = _observe_auto_refresh_interval(state.refresh_seconds)
        while not stop_event.wait(interval):
            try:
                state.refresh_snapshot(force=True)
                application.invalidate()
            except Exception:
                return

    refresher = threading.Thread(target=_refresh_snapshot_loop, name="observe-refresh", daemon=True)
    refresher.start()
    try:
        application.run()
    finally:
        stop_event.set()
        refresher.join(timeout=1)
    return 0


def run_observe_surface(
    runtime: CliRuntime,
    *,
    once: bool = False,
    refresh_seconds: float = DEFAULT_OBSERVE_REFRESH_SECONDS,
    page_id: str = DEFAULT_OBSERVE_PAGE,
    clone_id: str | None = None,
) -> int:
    resolved_page = _resolve_page_id(page_id) or DEFAULT_OBSERVE_PAGE
    console = Console(highlight=False, soft_wrap=True)
    snapshot = build_observe_snapshot(runtime, clone_id=clone_id)
    if once or not sys.stdin.isatty() or not sys.stdout.isatty() or not _observe_app_available():
        console.print(render_observe_view(snapshot, page_id=resolved_page))
        return 0

    exit_code = _run_interactive_observe_surface(
        runtime,
        refresh_seconds=refresh_seconds,
        page_id=resolved_page,
        clone_id=clone_id,
    )
    if RICH_AVAILABLE and Panel is not None and Text is not None:
        console.print(
            Panel(
                Text(
                    "Observe closed. Re-enter with `aegis observe`, or use `aegis observe --page memory --once` for a single focused snapshot.",
                    style=BRAND_LIGHT,
                ),
                title=f"[bold {BRAND_ACCENT}] Observe closed [/bold {BRAND_ACCENT}]",
                border_style=BRAND_DARK,
                padding=(0, 2),
            )
        )
    else:
        console.print("Observe closed.")
    return exit_code


__all__ = [
    "DEFAULT_OBSERVE_PAGE",
    "DEFAULT_OBSERVE_REFRESH_SECONDS",
    "ObservePageSpec",
    "ObserveSnapshot",
    "ObserveSurfaceState",
    "build_observe_snapshot",
    "current_page_lines",
    "page_title",
    "render_observe_view",
    "run_observe_surface",
]
