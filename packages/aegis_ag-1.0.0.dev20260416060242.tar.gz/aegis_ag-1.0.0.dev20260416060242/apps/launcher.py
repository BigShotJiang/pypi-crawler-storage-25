"""Shared launcher for editable installs and checkout-backed wrappers."""

from __future__ import annotations

import json
from pathlib import Path
import sys
from typing import Final

from apps.cli.__main__ import main as cli_main
from apps.gateway.__main__ import command_main as gateway_command_main
from apps.runtime_layout import default_cli_state_dir, default_gateway_state_dir, default_profile_dir
from packages.state import CLONE_FILENAME, DEFAULT_CLONE_TEXT

DEFAULT_PROFILE_MANIFEST: Final[dict[str, object]] = {
    "profile_id": "profile-local",
    "display_name": "Aegis",
    "mode": "companion",
    "preferences": [
        "tone:grounded",
        "memory:durable",
        "identity:aegis",
    ],
    "companion": {
        "personality_preset": "companion",
        "personality": [
            "warm",
            "present",
            "grounded",
        ],
        "initiative": "gentle",
        "notes": [
            "protect continuity",
            "carry the durable thread",
        ],
    },
    "enabled_capabilities": [
        "cli.primary",
    ],
}


def _ensure_profile_bundle(profile_dir: Path) -> None:
    profile_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = profile_dir / "profile.json"
    clone_path = profile_dir / CLONE_FILENAME
    if not manifest_path.exists():
        manifest_path.write_text(
            json.dumps(DEFAULT_PROFILE_MANIFEST, indent=2) + "\n",
            encoding="utf-8",
        )
    if not clone_path.exists():
        clone_path.write_text(DEFAULT_CLONE_TEXT, encoding="utf-8")

def main(argv: list[str] | None = None) -> int:
    resolved_argv = list(sys.argv[1:] if argv is None else argv)
    state_dir = default_cli_state_dir()
    profile_dir = default_profile_dir()
    gateway_state_dir = default_gateway_state_dir()
    state_dir.mkdir(parents=True, exist_ok=True)
    _ensure_profile_bundle(profile_dir)
    if resolved_argv and resolved_argv[0] in {"gateway", "im"}:
        return gateway_command_main(
            resolved_argv[1:],
            default_profile_dir=profile_dir,
            default_state_dir=gateway_state_dir,
            default_control_profile_dir=profile_dir,
            default_control_state_dir=state_dir,
        )
    forwarded = [
        "--state-dir",
        str(state_dir),
        "--profile-dir",
        str(profile_dir),
        *resolved_argv,
    ]
    return cli_main(forwarded)


if __name__ == "__main__":
    raise SystemExit(main())
