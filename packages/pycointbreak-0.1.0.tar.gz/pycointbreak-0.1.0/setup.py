"""
setup.py for pycointbreak
=========================

A Python library implementing the Hassler & Breitung (2006)
residual-based LM test against fractional cointegration and the
Rodrigues, Sibbertsen & Voges (2019) supremum tests for breaks in
the cointegrating relationship.

Author: Dr. Merwan Roudane  <merwanroudane920@gmail.com>
GitHub: https://github.com/merwanroudane/pycointbreak
"""
from setuptools import find_packages, setup

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="pycointbreak",
    version="0.1.0",
    author="Dr. Merwan Roudane",
    author_email="merwanroudane920@gmail.com",
    description=(
        "Tests for breaks in fractional cointegration "
        "(Hassler & Breitung 2006; Rodrigues, Sibbertsen & Voges 2019)."
    ),
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/merwanroudane/pycointbreak",
    project_urls={
        "Bug Tracker": "https://github.com/merwanroudane/pycointbreak/issues",
        "Source": "https://github.com/merwanroudane/pycointbreak",
    },
    packages=find_packages(exclude=("tests*", "examples*")),
    python_requires=">=3.10",
    install_requires=[
        "numpy>=1.22",
        "pandas>=1.4",
        "scipy>=1.8",
        "statsmodels>=0.13",
        "matplotlib>=3.5",
        "seaborn>=0.12",
    ],
    extras_require={
        "examples": ["yfinance>=0.2"],
        "dev": ["pytest>=7.0", "pytest-cov>=4.0"],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Scientific/Engineering :: Mathematics",
        "Topic :: Scientific/Engineering :: Information Analysis",
    ],
    keywords=[
        "econometrics",
        "fractional cointegration",
        "structural breaks",
        "time series",
        "Hassler-Breitung",
        "Rodrigues-Sibbertsen-Voges",
        "long memory",
        "LM test",
    ],
    license="MIT",
    include_package_data=True,
)
