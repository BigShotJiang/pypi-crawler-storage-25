"""
Pretty reporting helpers
========================

Build paper-style tables (à la Table 7 of RSV2019) from
:class:`HBResult` and :class:`RSVResult` objects.

Supported output formats:

* ``"text"``  — plain ASCII, suitable for the console / log files
* ``"markdown"`` — GitHub-flavoured markdown
* ``"latex"`` — LaTeX ``tabular`` ready for academic papers
* ``"html"``  — a self-contained HTML table

Author
------
Dr. Merwan Roudane  <merwanroudane920@gmail.com>
GitHub: https://github.com/merwanroudane/pycointbreak
"""
from __future__ import annotations

from typing import Iterable, Mapping, Optional, Union

import numpy as np
import pandas as pd

from .hassler_breitung import HBResult
from .rsv_tests import RSVResult


# ---------------------------------------------------------------------------
# Aggregation
# ---------------------------------------------------------------------------
def battery_to_dataframe(
    battery: Mapping[str, RSVResult],
    hb: Optional[HBResult] = None,
    label: Optional[str] = None,
) -> pd.DataFrame:
    """Build a paper-style row of statistics from a battery of RSV
    tests (and optionally a HB full-sample test).

    Columns mimic Table 7 of RSV2019:
    ``T_HB | T_S* | T_If(λ0) | T_Ib(λ0) | T_R(λ0)``.

    Bold cells in the paper correspond to entries that exceed the 5%
    critical value — here we add a ``*`` decoration in the textual
    rendering.

    Parameters
    ----------
    battery : Mapping[str, RSVResult]
        Output of :func:`pycointbreak.rsv_tests.rsv_battery`.
    hb : HBResult, optional
        Full-sample Hassler-Breitung result. If provided, a column
        ``T_HB`` with the squared HB statistic is prepended.
    label : str, optional
        Row label (e.g. country name). Defaults to ``"series"``.

    Returns
    -------
    pandas.DataFrame
        Single-row DataFrame with the test values and rejection
        markers in ``.attrs['reject']``.
    """
    row: dict[str, float] = {}
    reject: dict[str, bool] = {}

    if hb is not None:
        row["T_HB"] = float(hb.t_stat) ** 2
        # The HB test is one-sided in t (rejects negative), but for the
        # purposes of the joint Table 7 we report t^2 since that's the
        # chi-squared analogue used in the sup-tests.
        reject["T_HB"] = bool(hb.reject.get(0.05, False))

    name_map = {
        "T_S_star": "T_S*",
        "T_If": "T_If(lam0)",
        "T_Ib": "T_Ib(lam0)",
        "T_R": "T_R(lam0)",
        "T_R_star": "T_R*(lam0)",
        "T_S": "T_S",
    }
    for k, res in battery.items():
        col = name_map.get(k, k)
        row[col] = float(res.statistic)
        reject[col] = bool(res.reject.get(0.05, False))

    df = pd.DataFrame([row], index=[label or "series"])
    df.attrs["reject"] = reject
    return df


def combine_results(
    items: Iterable[tuple[str, Mapping[str, RSVResult], Optional[HBResult]]],
) -> pd.DataFrame:
    """Stack many battery results vertically to produce a multi-series
    table.

    Parameters
    ----------
    items : iterable of (label, battery, hb_or_None)
        One tuple per series / country / pair.

    Returns
    -------
    pandas.DataFrame
        Multi-row DataFrame with rejection flags in ``.attrs['reject']``
        (dict of dicts).
    """
    rows: list[pd.DataFrame] = []
    all_reject: dict[str, dict[str, bool]] = {}
    for label, battery, hb in items:
        row = battery_to_dataframe(battery, hb=hb, label=label)
        rows.append(row)
        all_reject[label] = row.attrs.get("reject", {})
    df = pd.concat(rows, axis=0)
    df.attrs["reject"] = all_reject
    return df


# ---------------------------------------------------------------------------
# Rendering
# ---------------------------------------------------------------------------
def _format_cell(value: float, reject: bool, decorator: str = "*") -> str:
    if np.isnan(value):
        return "  —"
    s = f"{value:8.3f}"
    if reject:
        s = s.strip() + decorator
    return s


def render_table(
    df: pd.DataFrame,
    fmt: str = "text",
    title: Optional[str] = None,
    decorator: str = "*",
) -> str:
    """Render a results DataFrame as a paper-style table.

    Parameters
    ----------
    df : pandas.DataFrame
        Output of :func:`battery_to_dataframe` or
        :func:`combine_results`.
    fmt : {'text', 'markdown', 'latex', 'html'}
        Output format.
    title : str, optional
        Caption / title.
    decorator : str, default ``'*'``
        String appended to cells where H0 is rejected at 5%.
    """
    reject_map = df.attrs.get("reject", {})
    is_multi = isinstance(reject_map, dict) and (
        len(reject_map) > 0
        and isinstance(next(iter(reject_map.values())), dict)
    )

    # Build a formatted display DataFrame using object dtype so that
    # we can store strings without a dtype-conflict.
    disp = pd.DataFrame(
        index=df.index, columns=df.columns, dtype=object
    )
    for ridx in df.index:
        for col in df.columns:
            val = df.loc[ridx, col]
            rj = (
                reject_map.get(ridx, {}).get(col, False)
                if is_multi
                else reject_map.get(col, False)
            )
            disp.loc[ridx, col] = _format_cell(val, bool(rj), decorator)

    if fmt == "text":
        head = f"\n{title}\n" + "=" * max(60, len(title or "")) if title else ""
        body = disp.to_string()
        legend = (
            f"\nNote: '{decorator}' marks rejection of H0 at the 5% level"
            " using critical values from Table 1 of Rodrigues, Sibbertsen"
            " & Voges (2019)."
        )
        return f"{head}\n{body}{legend}"
    elif fmt == "markdown":
        head = f"### {title}\n\n" if title else ""
        body = disp.to_markdown()
        legend = (
            f"\n\n*Note: `{decorator}` marks rejection at the 5% level"
            " (critical values: Rodrigues, Sibbertsen & Voges, 2019,"
            " Table 1).*"
        )
        return f"{head}{body}{legend}"
    elif fmt == "latex":
        head = ""
        if title:
            head = (
                "\\begin{table}[h]\n"
                f"\\caption{{{title}}}\n"
                "\\centering\n"
            )
        body = disp.to_latex(escape=False)
        foot = (
            ""
            if not title
            else "\\end{table}\n"
        )
        legend = (
            "% '*' marks rejection at the 5% level (RSV2019 Table 1).\n"
        )
        return head + body + foot + legend
    elif fmt == "html":
        css = """<style>
        table.pycb { border-collapse: collapse; font-family:
            'Helvetica Neue', Arial, sans-serif; }
        table.pycb th, table.pycb td { border-bottom: 1px solid #ccc;
            padding: 6px 12px; text-align: right; }
        table.pycb th { background: #f3f3f3; }
        table.pycb caption { font-weight: bold; padding-bottom: 6px; }
        .rej { color: #b00020; font-weight: 700; }
        </style>"""
        cap = f"<caption>{title}</caption>" if title else ""
        rows_html = []
        for ridx in disp.index:
            cells = "".join(f"<td>{disp.loc[ridx, c]}</td>" for c in disp.columns)
            rows_html.append(f"<tr><th>{ridx}</th>{cells}</tr>")
        header = (
            "<tr><th></th>" + "".join(f"<th>{c}</th>" for c in disp.columns) + "</tr>"
        )
        legend = (
            "<p><em>Note: ‘*’ marks rejection at the 5% level"
            " (RSV2019 Table 1).</em></p>"
        )
        return (
            css
            + f"<table class='pycb'>{cap}{header}"
            + "".join(rows_html)
            + "</table>"
            + legend
        )
    else:
        raise ValueError(f"Unknown fmt '{fmt}'.")
