"""
Critical values for the Hassler-Breitung (2006) and
Rodrigues-Sibbertsen-Voges (2019) tests
=====================================================

* Hassler-Breitung (HB) one-sided LM-type test: under H0 the statistic
  is asymptotically :math:`\\mathcal{N}(0,1)` (Proposition 1 / 3 / 4 of
  HB2006). The test rejects H0 (no fractional cointegration) for
  *significantly negative* values of the t-statistic (see eq. (4) and
  the text just below it).

* RSV (2019) supremum statistics: under H0 they converge to
  :math:`\\sup_{\\lambda \\in \\Lambda}\\chi^2_1` (Theorem 2). Exact
  small-sample critical values for ``T = 250`` and ``T = 500`` and
  bandwidth ``lambda_0 = 0.5`` are tabulated in Table 1 of RSV2019.

Author
------
Dr. Merwan Roudane  <merwanroudane920@gmail.com>
"""
from __future__ import annotations

from typing import Literal

import numpy as np
from scipy import stats

# ---------------------------------------------------------------------------
# Hassler-Breitung (2006) — standard normal one-sided lower-tail
# ---------------------------------------------------------------------------
HB_CRITICAL_VALUES = {
    0.01: float(stats.norm.ppf(0.01)),   # -2.326
    0.05: float(stats.norm.ppf(0.05)),   # -1.645
    0.10: float(stats.norm.ppf(0.10)),   # -1.282
}


def hb_critical_value(alpha: float = 0.05) -> float:
    """One-sided lower-tail standard-normal critical value.

    Parameters
    ----------
    alpha : float, default ``0.05``
        Significance level.

    Returns
    -------
    float
        :math:`z_{\\alpha} = \\Phi^{-1}(\\alpha)`.
    """
    return float(stats.norm.ppf(alpha))


def hb_pvalue(t_stat: float) -> float:
    """One-sided lower-tail p-value for the HB t-statistic.

    Parameters
    ----------
    t_stat : float
        Hassler-Breitung t-statistic.

    Returns
    -------
    float
        :math:`p = \\Phi(t)`.
    """
    return float(stats.norm.cdf(t_stat))


# ---------------------------------------------------------------------------
# Rodrigues, Sibbertsen, Voges (2019), Table 1, lambda_0 = 0.5
# ---------------------------------------------------------------------------
# Order: { test: { T : { alpha : critical_value } } }
RSV_TABLE1 = {
    "T_S_star": {
        250: {0.01: 9.438, 0.05: 5.960, 0.10: 4.470},
        500: {0.01: 8.888, 0.05: 5.737, 0.10: 4.381},
    },
    "T_If": {
        250: {0.01: 7.722, 0.05: 4.458, 0.10: 3.130},
        500: {0.01: 7.387, 0.05: 4.293, 0.10: 3.000},
    },
    "T_Ib": {
        250: {0.01: 7.699, 0.05: 4.471, 0.10: 3.133},
        500: {0.01: 7.405, 0.05: 4.296, 0.10: 3.006},
    },
    "T_R": {
        250: {0.01: 7.172, 0.05: 4.112, 0.10: 2.867},
        500: {0.01: 6.862, 0.05: 3.955, 0.10: 2.767},
    },
}

TestName = Literal["T_S_star", "T_If", "T_Ib", "T_R"]


def rsv_critical_value(
    test: TestName,
    T: int,
    alpha: float = 0.05,
) -> float:
    """Look up (or interpolate) a critical value from Table 1 of RSV2019.

    For ``T`` between 250 and 500 a linear interpolation in ``1/T`` is
    used (small-sample size effects of this order). Outside the
    range ``[250, 500]`` the nearest tabulated value is returned.

    Parameters
    ----------
    test : {'T_S_star', 'T_If', 'T_Ib', 'T_R'}
        Name of the test statistic.
    T : int
        Sample size.
    alpha : float, default ``0.05``
        Significance level. One of ``{0.01, 0.05, 0.10}``.

    Returns
    -------
    float
        Critical value at the requested level.
    """
    if test not in RSV_TABLE1:
        raise KeyError(f"Unknown test '{test}'. Known: {list(RSV_TABLE1)}.")
    if alpha not in (0.01, 0.05, 0.10):
        raise ValueError("alpha must be one of {0.01, 0.05, 0.10}.")

    cv250 = RSV_TABLE1[test][250][alpha]
    cv500 = RSV_TABLE1[test][500][alpha]
    if T <= 250:
        return cv250
    if T >= 500:
        return cv500
    # Linear in 1/T
    w = (1.0 / T - 1.0 / 250.0) / (1.0 / 500.0 - 1.0 / 250.0)
    return float(cv250 + w * (cv500 - cv250))


# ---------------------------------------------------------------------------
# Asymptotic critical values via sup chi^2 simulation
# ---------------------------------------------------------------------------
def simulate_sup_chi2_cv(
    lam0: float = 0.5,
    kind: Literal["incremental_forward", "incremental_backward", "rolling", "split"] = "incremental_forward",
    n_grid: int = 1000,
    n_sim: int = 50_000,
    rng: np.random.Generator | None = None,
) -> dict[float, float]:
    """Asymptotic critical values via Monte Carlo on the limit
    sup-:math:`\\chi^2_1` distribution.

    Under H0 (Theorem 2 of RSV2019),

    .. math::

        \\mathcal{T}_K(\\lambda_1, \\lambda_2) \\;\\Rightarrow\\;
        \\sup_{(\\lambda_1, \\lambda_2) \\in \\Lambda_K}\\chi^2_1.

    A degenerate but useful empirical approximation is to discretise
    :math:`\\Lambda_K` and draw iid :math:`\\chi^2_1` over the grid.
    This produces conservative upper bounds because the actual limit
    process on :math:`\\Lambda_K` is *not* independent at each
    breakpoint. Use only as a sanity check; prefer
    :func:`rsv_critical_value` for ``T <= 500``.

    Parameters
    ----------
    lam0 : float, default 0.5
        Trimming parameter.
    kind : str
        Type of supremum set (forward / backward incremental, rolling,
        split).
    n_grid : int, default 1000
        Number of grid points on [0, 1].
    n_sim : int, default 50000
        Monte Carlo replications.
    rng : numpy.random.Generator, optional
        RNG; created if None.

    Returns
    -------
    dict
        Dictionary ``{alpha: critical_value}`` for ``alpha`` in
        ``{0.01, 0.05, 0.10}``.
    """
    rng = np.random.default_rng() if rng is None else rng
    if kind == "split":
        n_pts = 2
    elif kind == "incremental_forward":
        n_pts = max(2, int((1.0 - lam0) * n_grid))
    elif kind == "incremental_backward":
        n_pts = max(2, int((1.0 - lam0) * n_grid))
    elif kind == "rolling":
        n_pts = max(2, int((1.0 - lam0) * n_grid))
    else:
        raise ValueError(f"Unknown kind '{kind}'.")

    sample = rng.chisquare(df=1, size=(n_sim, n_pts))
    sup = sample.max(axis=1)
    return {
        0.10: float(np.quantile(sup, 0.90)),
        0.05: float(np.quantile(sup, 0.95)),
        0.01: float(np.quantile(sup, 0.99)),
    }


def bootstrap_rsv_cv(
    T: int = 500,
    d: float = 1.0,
    kind: str = "T_If",
    lam0: float = 0.5,
    n_grid: int = 80,
    include_const: bool = True,
    n_sim: int = 1000,
    alphas: tuple[float, ...] = (0.01, 0.05, 0.10),
    rho: float = 0.0,
    seed: int | None = None,
    n_jobs: int = 1,
) -> dict[float, float]:
    """Parametric-bootstrap critical values for an RSV sup-test
    calibrated to the user's actual configuration.

    Simulates the H0 DGP (no fractional cointegration) ``n_sim`` times
    with the same ``(T, d, lam0, n_grid, ...)`` as the empirical test,
    computes the chosen sup statistic, and returns the empirical
    quantiles.

    This is the preferred way to obtain size-controlled critical
    values when the tabulated values of Table 1 of RSV2019 do not
    apply (e.g., very different ``T``, ``lam0``, ``n_grid``, or
    when ``d`` is far from 1).

    Parameters
    ----------
    T : int
    d : float
    kind : str
        One of the test kinds accepted by
        :func:`pycointbreak.rsv_tests.rsv_sup_test`.
    lam0 : float
    n_grid : int
    include_const : bool
    n_sim : int
        Number of Monte Carlo replications. ``1000`` is usually
        sufficient for the 5% level; use ``5000`` for the 1% level.
    alphas : tuple of float
    rho : float
        Correlation between regressor and error in the H0 DGP.
    seed : int, optional

    Returns
    -------
    dict
        ``{alpha : critical_value}``.

    Notes
    -----
    This is computationally expensive: ``n_sim = 1000`` with
    ``T = 500`` and ``n_grid = 80`` takes about 30-60 seconds on a
    modern laptop, depending on ``kind``.

    Examples
    --------
    >>> # Calibrate critical values to your data
    >>> cv = bootstrap_rsv_cv(T=1000, d=1.0, kind='T_If', n_sim=500)
    >>> # then compare your test statistic to cv[0.05]
    """
    # Import lazily to avoid a circular import.
    from .rsv_tests import rsv_sup_test
    from .simulate import simulate_rsv_dgp

    rng = np.random.default_rng(seed)
    sups = np.empty(n_sim, dtype=float)
    seeds = rng.integers(0, 2**31 - 1, size=n_sim)
    for i in range(n_sim):
        y, x = simulate_rsv_dgp(T=T, d=d, b=0.0, rho=rho, seed=int(seeds[i]))
        res = rsv_sup_test(
            y, x, d=d, kind=kind, lam0=lam0, n_grid=n_grid,
            include_const=include_const, alphas=(0.05,),
        )
        sups[i] = res.statistic

    return {a: float(np.quantile(sups, 1.0 - a)) for a in alphas}
