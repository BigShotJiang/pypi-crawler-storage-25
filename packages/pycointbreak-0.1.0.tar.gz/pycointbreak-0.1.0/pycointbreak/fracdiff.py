"""
Fractional differencing operators
=================================

Implements the truncated (Type II) fractional difference operator

    .. math::
        \\Delta_+^d x_t = \\sum_{j=0}^{t-1} \\pi_j(d)\\, x_{t-j},
        \\qquad \\pi_0(d) = 1,\\quad
        \\pi_j(d) = \\frac{j-d-1}{j}\\,\\pi_{j-1}(d)

as used in Hassler & Breitung (2006, eq. on p. 10 / Remark D) and
Rodrigues, Sibbertsen & Voges (2019, Assumption 2).

This is the convention required by both the Hassler-Breitung (HB)
LM test for fractional cointegration and the Rodrigues-Sibbertsen-Voges
(RSV) tests for breaks in fractional cointegration implemented in this
package.

Author
------
Dr. Merwan Roudane  <merwanroudane920@gmail.com>
GitHub: https://github.com/merwanroudane/pycointbreak
"""
from __future__ import annotations

from typing import Union

import numpy as np
import pandas as pd

ArrayLike = Union[np.ndarray, pd.Series, pd.DataFrame, list]


# ---------------------------------------------------------------------------
# Binomial / hyperbolic coefficients of the fractional difference filter
# ---------------------------------------------------------------------------
def frac_coefs(d: float, n: int) -> np.ndarray:
    """Return the first ``n`` coefficients :math:`\\pi_0, \\dots, \\pi_{n-1}`
    of the expansion :math:`(1-L)^d = \\sum_{j=0}^{\\infty} \\pi_j L^j`.

    The recursion used is numerically stable:

        :math:`\\pi_0 = 1`,
        :math:`\\pi_j = \\dfrac{j - d - 1}{j}\\,\\pi_{j-1}`.

    Parameters
    ----------
    d : float
        Order of fractional differencing. ``d`` may be any real number.
    n : int
        Number of coefficients to return (must be a positive integer).

    Returns
    -------
    numpy.ndarray
        Array of length ``n`` containing the fractional differencing
        coefficients.

    Examples
    --------
    >>> import numpy as np
    >>> from pycointbreak.fracdiff import frac_coefs
    >>> np.round(frac_coefs(1.0, 5), 4)
    array([ 1., -1.,  0.,  0.,  0.])
    >>> np.round(frac_coefs(0.5, 5), 4)
    array([ 1.    , -0.5   , -0.125 , -0.0625, -0.0391])
    """
    if n <= 0:
        raise ValueError("n must be a positive integer.")

    pi = np.empty(int(n), dtype=float)
    pi[0] = 1.0
    for j in range(1, int(n)):
        pi[j] = pi[j - 1] * (j - d - 1.0) / j
    return pi


# ---------------------------------------------------------------------------
# Truncated (Type II) fractional differencing
# ---------------------------------------------------------------------------
def fdiff(x: ArrayLike, d: float) -> np.ndarray:
    """Apply the truncated fractional difference operator
    :math:`\\Delta_+^d` to a univariate or multivariate series.

    For a series :math:`\\{x_t\\}_{t=1}^{T}` the operator is

    .. math::

        \\Delta_+^d x_t \\;=\\; \\sum_{j=0}^{t-1} \\pi_j(d)\\, x_{t-j},
        \\qquad t = 1, \\ldots, T,

    which corresponds to **Type II** fractional integration (zero
    pre-sample values, see Marinucci & Robinson, 1999). This is the
    convention used by Hassler & Breitung (2006) and Rodrigues,
    Sibbertsen & Voges (2019).

    Parameters
    ----------
    x : array_like, shape (T,) or (T, m)
        Input time series. ``pandas`` objects preserve their index in the
        return value when a ``pandas`` object is provided.
    d : float
        Order of fractional differencing. ``d = 1`` gives the first
        difference ``x_t - x_{t-1}`` with leading element ``x_1``.

    Returns
    -------
    numpy.ndarray or pandas.Series or pandas.DataFrame
        Fractionally differenced series with the same shape and (if
        applicable) index/columns as the input.

    Notes
    -----
    The implementation uses an :math:`O(T^2)` convolution which is
    sufficient for the sample sizes encountered in practice
    (``T <= 10000``). For very large ``T`` an FFT-based convolution
    could be used.

    Examples
    --------
    >>> import numpy as np
    >>> from pycointbreak.fracdiff import fdiff
    >>> x = np.array([1.0, 3.0, 6.0, 10.0])
    >>> np.round(fdiff(x, 1.0), 4)
    array([1., 2., 3., 4.])
    """
    is_series = isinstance(x, pd.Series)
    is_frame = isinstance(x, pd.DataFrame)
    arr = np.asarray(x, dtype=float)
    if arr.ndim == 1:
        out = _fdiff_1d(arr, d)
        if is_series:
            return pd.Series(out, index=x.index, name=x.name)
        return out
    elif arr.ndim == 2:
        out = np.column_stack([_fdiff_1d(arr[:, j], d) for j in range(arr.shape[1])])
        if is_frame:
            return pd.DataFrame(out, index=x.index, columns=x.columns)
        return out
    raise ValueError("x must be 1- or 2-dimensional.")


def _fdiff_1d(x: np.ndarray, d: float) -> np.ndarray:
    T = x.size
    pi = frac_coefs(d, T)
    out = np.empty(T, dtype=float)
    for t in range(T):
        # Δ^d_+ x_t = sum_{j=0}^{t} pi_j * x_{t-j}
        out[t] = np.dot(pi[: t + 1], x[t::-1])
    return out


# ---------------------------------------------------------------------------
# Drift correction term used by Hassler & Breitung (2006, Remark D)
# ---------------------------------------------------------------------------
def drift_regressor(d: float, T: int) -> np.ndarray:
    """Return the cumulative drift regressor
    :math:`\\left(\\sum_{i=0}^{t}\\delta_i\\right)_{t=1}^{T}`
    used by Hassler & Breitung (2006, Remark D) to account for a
    constant when :math:`d \\ne 1`.

    With :math:`\\delta_0=1` and
    :math:`\\delta_i = ((i-d-1)/i)\\delta_{i-1}` the partial sum
    :math:`\\sum_{i=0}^{t} \\delta_i` is exactly the fractional
    differencing operator applied to a unit constant.

    Parameters
    ----------
    d : float
        Order of fractional differencing.
    T : int
        Sample size.

    Returns
    -------
    numpy.ndarray
        Vector of length ``T`` containing the drift regressor.
    """
    return fdiff(np.ones(int(T), dtype=float), d)


# ---------------------------------------------------------------------------
# Harmonic-weighted running sum  x*_{t-1} = sum_{j=1}^{t-1} j^{-1} x_{t-j}
# ---------------------------------------------------------------------------
def harmonic_running_sum(x: ArrayLike) -> np.ndarray:
    """Compute the harmonic-weighted running sum (eq. 3 of Hassler &
    Breitung, 2006):

    .. math::

        x^{*}_{t-1} \\;=\\; \\sum_{j=1}^{t-1} \\frac{x_{t-j}}{j},
        \\qquad t = 2, \\ldots, T,

    with :math:`x^{*}_{0} := 0`.

    This is the key building block of the Robinson (1991) /
    Breitung & Hassler (2002) LM statistic for fractional integration
    used by both the Hassler-Breitung (2006) test and the
    Rodrigues-Sibbertsen-Voges (2019) tests.

    Parameters
    ----------
    x : array_like, shape (T,)
        Input series :math:`x_1, \\ldots, x_T`. In Python indexing the
        first element ``x[0]`` corresponds to :math:`x_1`.

    Returns
    -------
    numpy.ndarray
        Array of length ``T`` whose entry at Python position
        :math:`s = t-1` (for :math:`t = 1, \\ldots, T`) equals
        :math:`x^{*}_{t-1}`. The first entry equals zero by convention
        (:math:`x^{*}_{0} = 0`).

    Notes
    -----
    Indexing convention used internally (with :math:`s = t-1`):

    .. math::

        x^{*}_{s} \\;=\\; \\sum_{j=1}^{s} \\frac{1}{j}\\, x[s-j],
        \\qquad s = 1, \\ldots, T-1,

    which is exactly eq. (3) of Hassler & Breitung (2006) shifted by
    one index to match 0-based Python arrays.

    Examples
    --------
    >>> import numpy as np
    >>> from pycointbreak.fracdiff import harmonic_running_sum
    >>> x = np.array([1.0, 2.0, 4.0, 8.0])
    >>> harmonic_running_sum(x)
    array([0.        , 1.        , 2.5       , 5.33333333])
    """
    x = np.asarray(x, dtype=float).ravel()
    T = x.size
    out = np.zeros(T, dtype=float)
    for s in range(1, T):
        # out[s] = x*_s = sum_{j=1}^{s} (1/j) * x[s-j]
        # j = 1 -> x[s-1], j = 2 -> x[s-2], ..., j = s -> x[0]
        inv_j = 1.0 / np.arange(1, s + 1, dtype=float)
        out[s] = np.dot(inv_j, x[s - 1::-1])
    return out
