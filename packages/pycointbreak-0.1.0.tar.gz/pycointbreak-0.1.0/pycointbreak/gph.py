"""
Geweke & Porter-Hudak (1983) log-periodogram estimator of the
fractional integration parameter d
==================================

Used by Hassler & Breitung (2006, Sec. 5, last paragraph) when the
order of integration of the regressors is unknown.

The estimator regresses the log-periodogram on
:math:`-2\\log|1 - e^{-i\\omega_j}|` over the lowest
:math:`M \\le T/2` Fourier frequencies.

Author
------
Dr. Merwan Roudane  <merwanroudane920@gmail.com>
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

ArrayLike = np.ndarray


@dataclass
class GPHResult:
    """Container for GPH log-periodogram regression results."""

    d_hat: float
    se: float
    M: int
    T: int
    intercept: float

    def __repr__(self) -> str:  # pragma: no cover
        return (
            f"GPHResult(d_hat={self.d_hat:.4f}, se={self.se:.4f}, "
            f"M={self.M}, T={self.T})"
        )


def gph(x, M: int | None = None, power: float = 0.5) -> GPHResult:
    """Geweke & Porter-Hudak (1983) log-periodogram estimator of *d*.

    Estimates :math:`d` from the regression

    .. math::

        \\log I(\\omega_j) \\;=\\; c \\;-\\; d \\, \\log\\!\\left|
        1 - e^{-i\\omega_j}\\right|^{2} \\;+\\; u_j,
        \\qquad j = 1, \\ldots, M,

    where :math:`I(\\omega_j)` is the periodogram at Fourier frequency
    :math:`\\omega_j = 2\\pi j / T` and ``M`` is the bandwidth.

    Parameters
    ----------
    x : array_like, shape (T,)
        Time series.
    M : int, optional
        Bandwidth (number of low Fourier frequencies). If ``None`` the
        default ``M = floor(T**power)`` is used, with ``power = 0.5``
        (a common choice). Hassler & Breitung (2006) use
        :math:`M \\le T/2`.
    power : float, default ``0.5``
        Exponent of the default bandwidth :math:`M = \\lfloor T^{p}
        \\rfloor`. Ignored when ``M`` is given.

    Returns
    -------
    GPHResult
        Object with ``d_hat``, ``se``, ``M``, ``T``, ``intercept``.

    References
    ----------
    Geweke, J. and Porter-Hudak, S. (1983). The Estimation and
    Application of Long Memory Time Series Models. *Journal of Time
    Series Analysis*, 4, 221-238.

    Examples
    --------
    >>> import numpy as np
    >>> rng = np.random.default_rng(0)
    >>> from pycointbreak.fracdiff import fdiff
    >>> z = fdiff(rng.standard_normal(1000), -0.3)  # I(0.3) process
    >>> res = gph(z)
    >>> abs(res.d_hat - 0.3) < 0.2
    True
    """
    x = np.asarray(x, dtype=float).ravel()
    T = x.size
    if M is None:
        M = int(np.floor(T**power))
    M = max(2, min(int(M), T // 2 - 1))

    # Periodogram via FFT
    x_dm = x - x.mean()
    fx = np.fft.fft(x_dm)
    pgm = (np.abs(fx) ** 2) / (2.0 * np.pi * T)

    j = np.arange(1, M + 1)
    omega = 2.0 * np.pi * j / T
    # log |1 - exp(-i omega_j)|^2 = log(2 - 2*cos(omega_j))
    log_kernel = np.log(2.0 - 2.0 * np.cos(omega))
    y = np.log(pgm[1 : M + 1])

    X = np.column_stack([np.ones(M), -log_kernel])
    coefs, *_ = np.linalg.lstsq(X, y, rcond=None)
    intercept, d_hat = coefs

    # Asymptotic GPH s.e. : pi / sqrt(24 M) * 1/sd(log_kernel)... but
    # the classical asymptotic variance is pi^2 / 6 for the regression
    # residuals; we use the OLS s.e. from the regression.
    resid = y - X @ coefs
    sigma2 = float(np.dot(resid, resid) / max(M - 2, 1))
    XtX_inv = np.linalg.inv(X.T @ X)
    se = float(np.sqrt(sigma2 * XtX_inv[1, 1]))

    return GPHResult(
        d_hat=float(d_hat),
        se=se,
        M=int(M),
        T=int(T),
        intercept=float(intercept),
    )
