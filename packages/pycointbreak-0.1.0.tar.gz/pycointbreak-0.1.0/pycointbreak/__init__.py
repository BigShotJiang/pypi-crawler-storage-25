"""
pycointbreak — A Python library for testing breaks in fractional
cointegration relationships
================================================================

Implements:

* The **Hassler & Breitung (2006)** residual-based LM-type test
  against fractional cointegration (eqs. 12–14 and 17–18).
* The **Rodrigues, Sibbertsen & Voges (2019)** supremum tests for
  *breaks* in the cointegrating relationship — split sample,
  forward / backward incremental, and rolling (eqs. 5–15).
* The RSV (2019) **break-point estimator** (eq. 19), with both
  forward and reverse residual scans (Theorem 3 / Remark 3.3).

Author
------
Dr. Merwan Roudane
Email: merwanroudane920@gmail.com
GitHub: https://github.com/merwanroudane/pycointbreak

References
----------
Hassler, U. and Breitung, J. (2006). A Residual-Based LM Type Test
Against Fractional Cointegration. *Econometric Theory*, 22(6),
1091-1111.

Rodrigues, P. M. M., Sibbertsen, P. and Voges, M. (2019).
Testing for breaks in the cointegrating relationship: On the
stability of government bond markets' equilibrium. Discussion
Paper 656.
"""

__version__ = "0.1.0"
__author__ = "Dr. Merwan Roudane"
__email__ = "merwanroudane920@gmail.com"
__url__ = "https://github.com/merwanroudane/pycointbreak"

from .breakpoint import BreakPointResult, estimate_break_point
from .critical_values import (
    HB_CRITICAL_VALUES,
    RSV_TABLE1,
    bootstrap_rsv_cv,
    hb_critical_value,
    hb_pvalue,
    rsv_critical_value,
    simulate_sup_chi2_cv,
)
from .fracdiff import (
    drift_regressor,
    fdiff,
    frac_coefs,
    harmonic_running_sum,
)
from .gph import GPHResult, gph
from .hassler_breitung import HBResult, hassler_breitung_test
from .reporting import (
    battery_to_dataframe,
    combine_results,
    render_table,
)
from .rsv_tests import RSVResult, rsv_battery, rsv_sup_test
from .simulate import (
    frac_integrate,
    simulate_hb_dgp,
    simulate_rsv_dgp,
    simulate_segmented_cointegration,
)

# Plotting is a soft dependency — only re-exported if matplotlib is
# importable.
try:  # pragma: no cover
    from .plots import (
        plot_breakpoint_objective,
        plot_residual_diagnostics,
        plot_rsv_battery,
        plot_rsv_profile,
        plot_series_with_breaks,
        plot_split_heatmap,
        set_style,
    )
except ImportError:  # pragma: no cover
    pass


__all__ = [
    # version / metadata
    "__version__",
    "__author__",
    "__email__",
    "__url__",
    # main tests
    "hassler_breitung_test",
    "rsv_sup_test",
    "rsv_battery",
    "estimate_break_point",
    # result classes
    "HBResult",
    "RSVResult",
    "BreakPointResult",
    "GPHResult",
    # building blocks
    "fdiff",
    "frac_coefs",
    "harmonic_running_sum",
    "drift_regressor",
    "frac_integrate",
    "gph",
    # critical values
    "hb_critical_value",
    "hb_pvalue",
    "rsv_critical_value",
    "simulate_sup_chi2_cv",
    "bootstrap_rsv_cv",
    "HB_CRITICAL_VALUES",
    "RSV_TABLE1",
    # simulation
    "simulate_rsv_dgp",
    "simulate_segmented_cointegration",
    "simulate_hb_dgp",
    # reporting
    "battery_to_dataframe",
    "combine_results",
    "render_table",
    # plotting (re-exported only if matplotlib is installed)
    "plot_series_with_breaks",
    "plot_rsv_profile",
    "plot_rsv_battery",
    "plot_breakpoint_objective",
    "plot_residual_diagnostics",
    "plot_split_heatmap",
    "set_style",
]


def cite() -> str:
    """Return a BibTeX-formatted citation for the library and the two
    underlying papers."""
    return r"""
@software{Roudane_pycointbreak_2024,
  author  = {Roudane, Merwan},
  title   = {pycointbreak: Python tools for fractional cointegration
             tests with breaks},
  year    = {2024},
  url     = {https://github.com/merwanroudane/pycointbreak},
  version = {""" + __version__ + r"""}
}

@article{HasslerBreitung2006,
  author  = {Hassler, Uwe and Breitung, J{\"o}rg},
  title   = {A Residual-Based {LM} Type Test Against Fractional
             Cointegration},
  journal = {Econometric Theory},
  volume  = {22},
  number  = {6},
  pages   = {1091--1111},
  year    = {2006}
}

@techreport{RodriguesSibbertsenVoges2019,
  author      = {Rodrigues, Paulo M. M. and Sibbertsen, Philipp and
                 Voges, Michelle},
  title       = {Testing for breaks in the cointegrating relationship:
                 On the stability of government bond markets'
                 equilibrium},
  institution = {Hannover Economic Papers (HEP)},
  number      = {656},
  year        = {2019}
}
""".strip() + "\n"


def help_text() -> str:
    """Return a one-screen orientation guide."""
    return r"""
================================================================
  pycointbreak — Quickstart
================================================================
  Author : Dr. Merwan Roudane <merwanroudane920@gmail.com>
  GitHub : https://github.com/merwanroudane/pycointbreak
  Version: """ + __version__ + r"""

  Implements:
    - Hassler & Breitung (2006) LM test for no fractional
      cointegration.
    - Rodrigues, Sibbertsen & Voges (2019) supremum tests for
      breaks in the cointegrating relationship.
    - Break-point estimator (RSV2019 eq. 19).

  Typical workflow
  ----------------
  >>> import numpy as np
  >>> from pycointbreak import (
  ...     simulate_segmented_cointegration,
  ...     hassler_breitung_test,
  ...     rsv_battery,
  ...     estimate_break_point,
  ...     plot_rsv_battery,
  ...     plot_series_with_breaks,
  ...     plot_breakpoint_objective,
  ...     render_table, battery_to_dataframe,
  ... )

  >>> # 1. Get / simulate two I(d) series.
  >>> y, x = simulate_segmented_cointegration(
  ...     T=500, d=1.0, b=0.4, break_frac=0.5,
  ...     regime="coint_then_spurious", seed=1)

  >>> # 2. Full-sample HB test.
  >>> hb = hassler_breitung_test(y, x, d=1.0, p=1)
  >>> print(hb.summary())

  >>> # 3. RSV battery of sup-tests for breaks.
  >>> bat = rsv_battery(y, x, d=1.0)
  >>> for k, r in bat.items():
  ...     print(r.summary())

  >>> # 4. Pretty Table 7-style summary.
  >>> df = battery_to_dataframe(bat, hb=hb, label="y on x")
  >>> print(render_table(df, fmt="text",
  ...                    title="Tests for segmented cointegration"))

  >>> # 5. Estimate the break date.
  >>> bp = estimate_break_point(y, x, d=1.0, direction="auto")
  >>> print(bp.summary())

  >>> # 6. Plots.
  >>> plot_series_with_breaks({"y": y, "x": x}, {"break": bp.obs})
  >>> plot_rsv_battery(bat)
  >>> plot_breakpoint_objective(bp)
================================================================
""".strip()


def about() -> None:  # pragma: no cover
    """Print library metadata and author info."""
    print(help_text())
