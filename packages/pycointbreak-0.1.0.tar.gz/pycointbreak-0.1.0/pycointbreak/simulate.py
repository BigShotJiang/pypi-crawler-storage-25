"""
Data-generating processes for Monte Carlo studies
=================================================

Implements the DGPs used in:

* Hassler & Breitung (2006), Section 5, eqs. (19)-(20) — bivariate
  fractional model with a Gaussian VAR(1) on the differences.
* Rodrigues, Sibbertsen & Voges (2019), Section 4, eqs. (21)-(23)
  — including the regime-change designs of Experiments 2 and 3.

These DGPs are useful for both teaching and reproducing the
Monte Carlo tables of either paper.

Author
------
Dr. Merwan Roudane  <merwanroudane920@gmail.com>
"""
from __future__ import annotations

from typing import Literal, Optional

import numpy as np

from .fracdiff import fdiff


# ---------------------------------------------------------------------------
# Inverse Type-II fractional integration  (1 - L)^{-d} x_t
# ---------------------------------------------------------------------------
def frac_integrate(x: np.ndarray, d: float) -> np.ndarray:
    """Apply the inverse truncated fractional difference operator
    :math:`(1 - L)^{-d}` to a series, i.e. fractionally integrate of
    order :math:`d`.

    This is implemented as :math:`\\Delta_+^{-d}` using the same
    Type-II truncated convolution.
    """
    return fdiff(x, -d)


# ---------------------------------------------------------------------------
# RSV (2019) DGP, eqs. (21)-(23)
# ---------------------------------------------------------------------------
def simulate_rsv_dgp(
    T: int = 500,
    d: float = 1.0,
    b: float = 0.4,
    rho: float = 0.0,
    seed: Optional[int] = None,
) -> tuple[np.ndarray, np.ndarray]:
    """RSV (2019) Experiment 1 DGP — constant cointegration over the
    whole sample (eqs. 21-23 of RSV2019).

    .. math::

        y_t = x_t + e_t, \\quad
        x_t = x_{t-1} + v_t, \\quad
        (1 - L)^{1 - b}\\, e_t = a_t,

    with :math:`(v_t, a_t)' \\sim \\mathrm{iid}\\,
    \\mathcal{N}(0, \\Sigma)` and
    :math:`\\Sigma = \\begin{pmatrix}1 & \\rho \\\\ \\rho & 1\\end{pmatrix}`.

    Parameters
    ----------
    T : int, default 500
    d : float, default 1.0
        Order of integration of the variables. When ``d = 1`` the
        DGP is the one of RSV (2019). For general ``d`` we replace
        the unit-root recursion ``x_t = x_{t-1} + v_t`` with the
        fractional integration :math:`(1 - L)^{-d} v_t`.
    b : float, default 0.4
        Cointegration strength :math:`b`. ``b = 0`` corresponds to
        no cointegration; ``b > 0`` to fractional cointegration.
    rho : float, default 0.0
        Contemporaneous correlation between :math:`v_t` and
        :math:`a_t`. ``rho != 0`` makes the regressor endogenous.
    seed : int, optional

    Returns
    -------
    y : numpy.ndarray, shape (T,)
    x : numpy.ndarray, shape (T,)
    """
    rng = np.random.default_rng(seed)
    cov = np.array([[1.0, rho], [rho, 1.0]])
    eps = rng.multivariate_normal(mean=np.zeros(2), cov=cov, size=T)
    v = eps[:, 0]
    a = eps[:, 1]

    if abs(d - 1.0) < 1e-10:
        x = np.cumsum(v)
    else:
        x = frac_integrate(v, d)

    e = frac_integrate(a, d - b)  # (1 - L)^{-(d - b)} a_t = I(d - b)
    y = x + e
    return y, x


def simulate_segmented_cointegration(
    T: int = 500,
    d: float = 1.0,
    b: float = 0.4,
    break_frac: float = 0.5,
    regime: Literal[
        "spurious_then_coint", "coint_then_spurious"
    ] = "spurious_then_coint",
    rho: float = 0.0,
    seed: Optional[int] = None,
) -> tuple[np.ndarray, np.ndarray]:
    """Generate a bivariate series with a SINGLE break in the
    cointegration strength.

    Reproduces Experiments 2 and 3 of RSV2019 (eqs. 28-29).

    Parameters
    ----------
    T : int
    d : float
    b : float
        Cointegration strength in the cointegrated regime.
    break_frac : float in (0, 1)
        Fraction at which the break occurs.
    regime : {'spurious_then_coint', 'coint_then_spurious'}
        Direction of the break.
    rho : float, default 0.0
    seed : int, optional

    Returns
    -------
    y : numpy.ndarray, shape (T,)
    x : numpy.ndarray, shape (T,)
    """
    rng = np.random.default_rng(seed)
    cov = np.array([[1.0, rho], [rho, 1.0]])
    eps = rng.multivariate_normal(mean=np.zeros(2), cov=cov, size=T)
    v = eps[:, 0]
    a = eps[:, 1]

    if abs(d - 1.0) < 1e-10:
        x = np.cumsum(v)
    else:
        x = frac_integrate(v, d)

    b_t = np.zeros(T)
    cut = int(np.floor(break_frac * T))
    if regime == "spurious_then_coint":
        b_t[cut:] = b
    elif regime == "coint_then_spurious":
        b_t[:cut] = b
    else:
        raise ValueError(f"Unknown regime '{regime}'.")

    # Build e_t segment by segment with the regime-specific exponent.
    e = np.zeros(T)
    if regime == "spurious_then_coint":
        # Segment 1: I(d) noise.
        e[:cut] = frac_integrate(a[:cut], d)
        # Segment 2: I(d - b) noise.
        e[cut:] = frac_integrate(a[cut:], d - b)
    else:  # coint_then_spurious
        e[:cut] = frac_integrate(a[:cut], d - b)
        e[cut:] = frac_integrate(a[cut:], d)

    y = x + e
    return y, x


# ---------------------------------------------------------------------------
# Convenience: HB (2006) DGP, Section 5
# ---------------------------------------------------------------------------
def simulate_hb_dgp(
    T: int = 500,
    d: float = 1.0,
    b: float = 0.0,
    rho: float = 0.0,
    seed: Optional[int] = None,
) -> tuple[np.ndarray, np.ndarray]:
    """HB (2006) bivariate DGP (eq. 19):

    .. math::

        y_{1,t} = y_{2,t} + z_t, \\quad
        \\Delta^d y_{2,t} \\sim \\mathcal{N}(0,1), \\quad
        \\Delta^{d-b} z_t \\sim \\mathcal{N}(0,1),

    with correlation :math:`\\rho` between the two innovations.

    This is equivalent to :func:`simulate_rsv_dgp` but kept as a
    distinct name for clarity when reproducing HB2006 tables.
    """
    return simulate_rsv_dgp(T=T, d=d, b=b, rho=rho, seed=seed)
