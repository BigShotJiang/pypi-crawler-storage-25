"""
Rodrigues, Sibbertsen & Voges (2019) tests for breaks in the
fractional cointegrating relationship
===========================================================

Implements eqs. (5)-(15) of:

    Rodrigues, P. M. M., Sibbertsen, P. and Voges, M. (2019).
    Testing for breaks in the cointegrating relationship: On the
    stability of government bond markets' equilibrium. Discussion
    Paper 656.

The building block is the Hassler-Breitung (2006) t-statistic
applied to a subsample :math:`[\\lfloor\\lambda_1 T\\rfloor + 1,
\\lfloor\\lambda_2 T\\rfloor]` (eq. 5):

.. math::

    t(\\hat e(\\lambda_1, \\lambda_2)) \\;=\\;
    \\frac{\\sqrt{\\lfloor\\lambda_2 T\\rfloor - \\lfloor\\lambda_1 T\\rfloor}
        \\sum_{t=\\lfloor\\lambda_1 T\\rfloor + 1}^{\\lfloor\\lambda_2 T\\rfloor}
        \\hat e_t(\\lambda_1, \\lambda_2)\\, \\hat e^{*}_{t-1}(\\lambda_1, \\lambda_2)}
    {\\sqrt{\\sum \\hat e^{*\\,2}_{t-1}(\\lambda_1, \\lambda_2)}
        \\sqrt{(T-1)^{-1}\\sum \\hat e_t^{2}(\\lambda_1, \\lambda_2)}}.

The supremum statistics (eqs. 10-15) are:

* ``T_S``       : split sample :math:`\\Lambda_S = \\{(0, 1/2),
  (1/2, 1)\\}`
* ``T_S_star``  : :math:`\\Lambda_S \\cup \\{(0, 1)\\}` — also
  includes the full sample (Davidson & Monticini, 2010)
* ``T_If``      : forward incremental
  :math:`\\Lambda_{0f} = \\{(0, s) : s \\in [\\lambda_0, 1]\\}`
* ``T_Ib``      : backward incremental
  :math:`\\Lambda_{0b} = \\{(s, 1) : s \\in [0, 1 - \\lambda_0]\\}`
* ``T_R``       : rolling
  :math:`\\Lambda_{0R} = \\{(s, s + \\lambda_0) : s \\in
  [0, 1 - \\lambda_0]\\}`
* ``T_R_star``  : :math:`\\Lambda_{0R} \\cup \\{(0, 1)\\}`

Under H0 (Theorem 2), each statistic converges to
:math:`\\sup_{\\lambda \\in \\Lambda_K} \\chi^2_1`.

Author
------
Dr. Merwan Roudane  <merwanroudane920@gmail.com>
GitHub: https://github.com/merwanroudane/pycointbreak
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal, Optional, Union

import numpy as np
import pandas as pd

from .critical_values import rsv_critical_value, simulate_sup_chi2_cv
from .fracdiff import drift_regressor, fdiff, harmonic_running_sum

ArrayLike = Union[np.ndarray, pd.Series, pd.DataFrame]


# ---------------------------------------------------------------------------
# Result container
# ---------------------------------------------------------------------------
@dataclass
class RSVResult:
    """Result of a single RSV supremum test.

    Attributes
    ----------
    name : str
        Identifier (``T_S``, ``T_S_star``, ``T_If``, ``T_Ib``, ``T_R``).
    statistic : float
        Supremum of squared t-statistics.
    argmax : tuple of float
        Pair :math:`(\\lambda_1^*, \\lambda_2^*)` at which the supremum
        is attained.
    argmax_obs : tuple of int
        Same as ``argmax`` but expressed in observation indices.
    grid : list of tuple
        The set :math:`\\Lambda_K` evaluated (each entry is
        :math:`(\\lambda_1, \\lambda_2)`).
    t2_path : numpy.ndarray
        :math:`t^{2}` evaluated at every grid point — useful for
        plotting the rejection profile.
    critical_values : dict
        ``{alpha : cv}`` from Table 1 of RSV2019.
    reject : dict
        ``{alpha : bool}`` rejection indicators.
    T : int
        Sample size.
    lam0 : float
        Trimming parameter.
    d : float
        Order of fractional integration used.
    include_const : bool
        Whether a constant was included in the cointegrating regression.
    n_regressors : int
    """

    name: str
    statistic: float
    argmax: tuple
    argmax_obs: tuple
    grid: list
    t2_path: np.ndarray
    critical_values: dict
    reject: dict
    T: int
    lam0: float
    d: float
    include_const: bool
    n_regressors: int
    extra: dict = field(default_factory=dict)

    def summary(self) -> str:
        lines = []
        lines.append("=" * 70)
        lines.append(f"  RSV (2019) sup test :  {self.name}")
        lines.append("=" * 70)
        lines.append(
            f"  Trimming lambda_0       : {self.lam0:.3f}      "
            f"Sample T = {self.T}    d = {self.d:.3f}"
        )
        lines.append(
            f"  Statistic               : {self.statistic: .4f}"
        )
        lines.append(
            f"  argmax (lambda_1, lambda_2): ({self.argmax[0]:.3f}, "
            f"{self.argmax[1]:.3f})     obs ({self.argmax_obs[0]}, "
            f"{self.argmax_obs[1]})"
        )
        lines.append("-" * 70)
        lines.append("  Critical values (Table 1, RSV 2019):")
        for a, cv in self.critical_values.items():
            mark = "  REJECT H0" if self.reject[a] else "  fail to reject"
            lines.append(f"    {int(a*100):>3d}%   {cv: .4f}   {mark}")
        lines.append("=" * 70)
        return "\n".join(lines)

    def __repr__(self) -> str:  # pragma: no cover
        return (
            f"RSVResult(name={self.name}, statistic={self.statistic:.4f}, "
            f"argmax={self.argmax}, T={self.T})"
        )

    def to_dataframe(self) -> pd.DataFrame:
        return pd.DataFrame(
            {
                "test": [self.name],
                "statistic": [self.statistic],
                "argmax_lam1": [self.argmax[0]],
                "argmax_lam2": [self.argmax[1]],
                "T": [self.T],
                "lam0": [self.lam0],
                "d": [self.d],
                "cv_5%": [self.critical_values.get(0.05, np.nan)],
                "reject_5%": [self.reject.get(0.05, False)],
            }
        )


# ---------------------------------------------------------------------------
# Internal: build OLS residuals from the cointegrating regression
# ---------------------------------------------------------------------------
def _ols_residuals(
    y1: np.ndarray,
    y2: np.ndarray,
    include_const: bool,
) -> np.ndarray:
    """Return OLS residuals :math:`\\hat e_t = y_{1,t} - \\hat\\alpha -
    \\hat\\beta' y_{2,t}` (eq. 24 of RSV2019)."""
    T = y1.size
    if include_const:
        X = np.column_stack([np.ones(T), y2])
    else:
        X = y2
    beta, *_ = np.linalg.lstsq(X, y1, rcond=None)
    return y1 - X @ beta


# ---------------------------------------------------------------------------
# Internal: HB sub-sample t-statistic (eq. 5 of RSV2019)
# ---------------------------------------------------------------------------
def _hb_subsample_tstat(
    y1: np.ndarray,
    y2: np.ndarray,
    d: float,
    lam1: float,
    lam2: float,
    T: int,
    include_const: bool = True,
) -> tuple[float, int, int]:
    """t(ê(λ1, λ2)) — RSV (2019) sub-sample HB t-statistic.

    Implements the "sub-sample based residuals" interpretation of
    eq. (5): for each (λ_1, λ_2) the cointegrating regression is
    **re-estimated** on the sub-sample
    :math:`(\\lfloor\\lambda_1 T\\rfloor, \\lfloor\\lambda_2 T\\rfloor]`,
    then the standard Hassler-Breitung (2006) t-statistic
    (eq. 14 of HB2006, equivalently eq. 4 of RSV2019) is applied to
    the resulting sub-sample residuals.

    This satisfies the orthogonality constraints
    :math:`\\sum \\hat e_t = 0` and :math:`\\sum \\hat e_t y_{2,t} = 0`
    **on the sub-sample**, ensuring that under H0 the sub-sample
    statistic is asymptotically :math:`\\mathcal{N}(0, 1)`. Hence
    :math:`t^{2}` is :math:`\\chi^2_1`, and the supremum over
    :math:`\\Lambda_K` converges to :math:`\\sup \\chi^2_1` as in
    Theorem 2 of RSV2019.

    The factor :math:`\\sqrt{n}` shown in eq. (5) of RSV2019, combined
    with the full-sample variance :math:`1/(T-1)`, would make the
    statistic :math:`O_p(\\sqrt{T})` under H0, contradicting Theorem
    2; we interpret this as a typesetting artefact and apply the
    standard HB statistic with sub-sample variance :math:`1/(n-1)`
    (the formulation used implicitly by Davidson & Monticini, 2010).

    Returns ``(t_stat, t1, t2)``.
    """
    t1 = int(np.floor(lam1 * T))
    t2 = int(np.floor(lam2 * T))
    n = t2 - t1
    if n < 10:
        return 0.0, t1, t2

    # Sub-sample DIFFERENCED regression (HB2006 eq. 12, RSV2019 eq. 3)
    # — fractionally difference y1 and y2 on the sub-sample, then run
    # OLS to obtain residuals that satisfy the orthogonality
    # constraints of the differenced regression. Per HB2006
    # Proposition 3 this avoids the spurious-regression bias of running
    # OLS on the levels and gives an N(0, 1) limit.
    d_y1 = fdiff(y1[t1:t2], d)
    d_y2_raw = fdiff(y2[t1:t2], d)
    if d_y2_raw.ndim == 1:
        d_y2_raw = d_y2_raw.reshape(-1, 1)

    if include_const and abs(d - 1.0) > 1e-10:
        # Cumulative drift regressor (HB2006 Remark D).
        from .fracdiff import drift_regressor
        drift = drift_regressor(d, n).reshape(-1, 1)
        X = np.hstack([drift, d_y2_raw])
    else:
        X = d_y2_raw

    beta, *_ = np.linalg.lstsq(X, d_y1, rcond=None)
    e_diff = d_y1 - X @ beta
    e_star = harmonic_running_sum(e_diff)

    num = float(np.sum(e_diff[1:] * e_star[1:]))
    denom_left = float(np.sqrt(np.sum(e_star[1:] ** 2)))
    sigma2 = float(np.sum(e_diff**2) / max(n - 1, 1))
    denom_right = float(np.sqrt(sigma2))
    denom = denom_left * denom_right
    if denom < 1e-300:
        return 0.0, t1, t2
    return float(num / denom), t1, t2


def _hb_subsample_tstat_from_e(
    e: np.ndarray,
    d: float,
    lam1: float,
    lam2: float,
    T: int,
) -> tuple[float, int, int]:
    """t(ê(λ1, λ2)) — Hassler-Breitung t-statistic on a sub-sample,
    used as the building block of the RSV (2019) sup tests.

    Eq. (5) of RSV (2019) as literally typeset reads

    .. math::

        \\frac{\\sqrt{n}\\;\\sum \\hat e_t\\hat e^{*}_{t-1}}
        {\\sqrt{\\sum \\hat e^{*\\,2}_{t-1}}\\;
         \\sqrt{(T-1)^{-1}\\sum \\hat e_t^{2}}},
        \\qquad n = \\lfloor\\lambda_2 T\\rfloor - \\lfloor\\lambda_1 T\\rfloor,

    but with the sub-sample residual variance replaced by the full-
    sample :math:`1/(T-1)` and an extra :math:`\\sqrt{n}` factor the
    statistic is :math:`O_p(\\sqrt{T})` under H0, which is incompatible
    with the :math:`\\sup\\chi^2_1` limit stated in Theorem 2.

    The correct, asymptotically :math:`\\mathcal{N}(0,1)` form on the
    sub-sample (Proposition 3 of HB2006 applied to the sub-sample of
    length :math:`n`, see also Davidson & Monticini, 2010, §3) is the
    standard HB t-statistic with **sub-sample** variance:

    .. math::

        t(\\hat e(\\lambda_1, \\lambda_2))
        \\;=\\;
        \\frac{\\sum_{t}\\hat e_t\\hat e^{*}_{t-1}}
        {\\sqrt{\\sum_{t}\\hat e^{*\\,2}_{t-1}}\\;
         \\sqrt{(n-1)^{-1}\\sum_{t}\\hat e_t^{2}}}.

    This implementation uses the corrected form: applying
    :math:`\\Delta_+^{d}` on the sub-sample, then running the HB iid
    statistic, so that under H0 ``t^2`` is :math:`\\chi^2_1` per
    Theorem 2 and the tabulated critical values of Table 1 of
    RSV2019 are the correct reference.

    Returns ``(t_stat, t1, t2)`` where ``t1 = floor(lam1*T)`` and
    ``t2 = floor(lam2*T)``.
    """
    t1 = int(np.floor(lam1 * T))
    t2 = int(np.floor(lam2 * T))
    n = t2 - t1
    if n < 5:
        # Sub-sample too small to compute a meaningful statistic.
        return 0.0, t1, t2

    # IMPORTANT: ``e`` arriving here is the full-sample series of
    # fractionally differenced residuals (already Δ^d_+ applied).
    # Differencing once on the full sample and then slicing avoids the
    # boundary effect that would otherwise pollute every sub-sample
    # with a leading O_p(sqrt(T)) initial level term.
    sub_diff = e[t1:t2]
    e_star = harmonic_running_sum(sub_diff)

    num = float(np.sum(sub_diff[1:] * e_star[1:]))
    denom_left = float(np.sqrt(np.sum(e_star[1:] ** 2)))
    sigma2 = float(np.sum(sub_diff**2) / max(n - 1, 1))
    denom_right = float(np.sqrt(sigma2))
    denom = denom_left * denom_right
    if denom < 1e-300:
        return 0.0, t1, t2
    return float(num / denom), t1, t2


# ---------------------------------------------------------------------------
# Internal: index sets (eqs. 6-9 of RSV2019)
# ---------------------------------------------------------------------------
def _grid_split(include_full: bool) -> list[tuple[float, float]]:
    base = [(0.0, 0.5), (0.5, 1.0)]
    if include_full:
        base.append((0.0, 1.0))
    return base


def _grid_incremental_forward(
    lam0: float, n_grid: int
) -> list[tuple[float, float]]:
    return [(0.0, s) for s in np.linspace(lam0, 1.0, n_grid)]


def _grid_incremental_backward(
    lam0: float, n_grid: int
) -> list[tuple[float, float]]:
    return [(s, 1.0) for s in np.linspace(0.0, 1.0 - lam0, n_grid)]


def _grid_rolling(
    lam0: float, n_grid: int, include_full: bool = False
) -> list[tuple[float, float]]:
    g = [(s, s + lam0) for s in np.linspace(0.0, 1.0 - lam0, n_grid)]
    if include_full:
        g.append((0.0, 1.0))
    return g


# ---------------------------------------------------------------------------
# Public API — main entry point
# ---------------------------------------------------------------------------
TestKind = Literal["T_S", "T_S_star", "T_If", "T_Ib", "T_R", "T_R_star"]


def rsv_sup_test(
    y1: ArrayLike,
    y2: ArrayLike,
    d: float = 1.0,
    kind: TestKind = "T_If",
    lam0: float = 0.5,
    n_grid: int = 200,
    include_const: bool = True,
    alphas: tuple[float, ...] = (0.01, 0.05, 0.10),
) -> RSVResult:
    """One RSV (2019) supremum test for breaks in fractional
    cointegration.

    Parameters
    ----------
    y1 : array_like, shape (T,)
        Scalar :math:`I(d)` series.
    y2 : array_like, shape (T,) or (T, m)
        :math:`I(d)` regressor(s).
    d : float, default 1.0
        Order of fractional integration of the variables.
    kind : {'T_S', 'T_S_star', 'T_If', 'T_Ib', 'T_R', 'T_R_star'}
        Test statistic to compute (see module docstring).
    lam0 : float, default 0.5
        Trimming parameter. Davidson & Monticini (2010) and RSV
        suggest ``lam0 = 0.5`` (also tabulated in Table 1).
    n_grid : int, default 200
        Number of grid points on :math:`[0, 1]` for the incremental
        and rolling statistics.
    include_const : bool, default True
        Whether to include a constant in the cointegrating regression.
    alphas : tuple of float
        Levels for which to look up critical values from Table 1.

    Returns
    -------
    RSVResult
        Test result with the supremum statistic, its argmax (in both
        :math:`\\lambda` units and observation indices), the entire
        :math:`t^{2}` profile (useful for plotting), and critical
        values from Table 1.
    """
    y1_arr = np.asarray(y1, dtype=float).ravel()
    y2_arr = np.atleast_2d(np.asarray(y2, dtype=float))
    if y2_arr.shape[0] != y1_arr.size:
        y2_arr = y2_arr.T
    m = y2_arr.shape[1]
    T = y1_arr.size

    # --- Build the grid -----------------------------------------------
    if kind == "T_S":
        grid = _grid_split(include_full=False)
    elif kind == "T_S_star":
        grid = _grid_split(include_full=True)
    elif kind == "T_If":
        grid = _grid_incremental_forward(lam0, n_grid)
    elif kind == "T_Ib":
        grid = _grid_incremental_backward(lam0, n_grid)
    elif kind == "T_R":
        grid = _grid_rolling(lam0, n_grid, include_full=False)
    elif kind == "T_R_star":
        grid = _grid_rolling(lam0, n_grid, include_full=True)
    else:
        raise ValueError(f"Unknown test kind '{kind}'.")

    # --- Compute t^2 at every grid point ------------------------------
    t2_path = np.empty(len(grid), dtype=float)
    pairs_obs = []
    for k, (a, b) in enumerate(grid):
        t_stat, t1_obs, t2_obs = _hb_subsample_tstat(
            y1_arr, y2_arr, d, a, b, T, include_const=include_const
        )
        t2_path[k] = t_stat * t_stat
        pairs_obs.append((t1_obs, t2_obs))

    # Take the supremum
    k_star = int(np.argmax(t2_path))
    statistic = float(t2_path[k_star])
    argmax = grid[k_star]
    argmax_obs = pairs_obs[k_star]

    # --- Critical values ----------------------------------------------
    cv: dict[float, float] = {}
    reject: dict[float, bool] = {}
    cv_key = "T_S_star" if kind in ("T_S", "T_S_star") else (
        "T_If" if kind == "T_If" else (
            "T_Ib" if kind == "T_Ib" else "T_R"
        )
    )
    # T_S uses T_S_star table as a conservative reference.
    for a in alphas:
        try:
            cv[a] = rsv_critical_value(cv_key, T, alpha=a)
        except (KeyError, ValueError):
            cv[a] = float("nan")
        reject[a] = statistic > cv[a] if not np.isnan(cv[a]) else False

    return RSVResult(
        name=kind,
        statistic=statistic,
        argmax=(float(argmax[0]), float(argmax[1])),
        argmax_obs=(int(argmax_obs[0]), int(argmax_obs[1])),
        grid=grid,
        t2_path=t2_path,
        critical_values=cv,
        reject=reject,
        T=int(T),
        lam0=float(lam0),
        d=float(d),
        include_const=bool(include_const),
        n_regressors=int(m),
        extra={},
    )


# ---------------------------------------------------------------------------
# Run a battery of RSV tests in one call
# ---------------------------------------------------------------------------
def rsv_battery(
    y1: ArrayLike,
    y2: ArrayLike,
    d: float = 1.0,
    lam0: float = 0.5,
    n_grid: int = 200,
    include_const: bool = True,
    alphas: tuple[float, ...] = (0.01, 0.05, 0.10),
    tests: tuple[TestKind, ...] = ("T_S_star", "T_If", "T_Ib", "T_R"),
) -> dict[str, RSVResult]:
    """Run a battery of RSV supremum tests on the same regression.

    Returns a dict ``{test_name : RSVResult}``.

    This mirrors Table 7 of RSV2019.

    Examples
    --------
    >>> import numpy as np
    >>> from pycointbreak.simulate import simulate_segmented_cointegration
    >>> y1, y2 = simulate_segmented_cointegration(
    ...     T=500, d=1.0, b=0.4, break_frac=0.5, regime="spurious_then_coint",
    ...     seed=1)
    >>> battery = rsv_battery(y1, y2, d=1.0)
    >>> sorted(battery)
    ['T_If', 'T_Ib', 'T_R', 'T_S_star']
    """
    y1_arr = np.asarray(y1, dtype=float).ravel()
    y2_arr = np.atleast_2d(np.asarray(y2, dtype=float))
    if y2_arr.shape[0] != y1_arr.size:
        y2_arr = y2_arr.T

    out: dict[str, RSVResult] = {}
    for tk in tests:
        out[tk] = rsv_sup_test(
            y1=y1_arr,
            y2=y2_arr,
            d=d,
            kind=tk,
            lam0=lam0,
            n_grid=n_grid,
            include_const=include_const,
            alphas=alphas,
        )
    return out
