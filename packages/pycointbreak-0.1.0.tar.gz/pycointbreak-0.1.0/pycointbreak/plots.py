"""
Beautiful visualisations for pycointbreak
=========================================

All plotting helpers return a matplotlib ``Figure`` so the caller can
further customise, save (``fig.savefig(...)``), or display the result.

Style is set with a light seaborn theme; the function
:func:`set_style` lets users switch theme without altering global
matplotlib state.

Author
------
Dr. Merwan Roudane  <merwanroudane920@gmail.com>
GitHub: https://github.com/merwanroudane/pycointbreak
"""
from __future__ import annotations

from typing import Iterable, Mapping, Optional, Sequence, Union

import numpy as np
import pandas as pd

try:  # Soft dependencies — only required for plotting.
    import matplotlib.pyplot as plt
    import matplotlib.dates as mdates
    from matplotlib.figure import Figure
    import seaborn as sns
    _HAS_MPL = True
except ImportError:  # pragma: no cover
    _HAS_MPL = False
    Figure = object  # type: ignore

from .breakpoint import BreakPointResult
from .hassler_breitung import HBResult
from .rsv_tests import RSVResult


def _ensure_mpl():  # pragma: no cover
    if not _HAS_MPL:
        raise ImportError(
            "matplotlib and seaborn are required for plotting. "
            "Install them with `pip install matplotlib seaborn`."
        )


def set_style(
    theme: str = "whitegrid",
    palette: str = "deep",
    context: str = "notebook",
    font_scale: float = 1.0,
) -> None:
    """Configure the default seaborn / matplotlib style for the library.

    Parameters
    ----------
    theme : str
        seaborn style: ``'whitegrid'``, ``'darkgrid'``, ``'ticks'``,
        etc.
    palette : str
    context : str
        ``'paper'``, ``'notebook'``, ``'talk'``, ``'poster'``.
    font_scale : float
    """
    _ensure_mpl()
    sns.set_theme(
        style=theme, palette=palette, context=context, font_scale=font_scale
    )


# ---------------------------------------------------------------------------
# 1. Series with shaded breaks
# ---------------------------------------------------------------------------
def plot_series_with_breaks(
    series: Mapping[str, Union[pd.Series, np.ndarray]],
    breaks: Optional[Mapping[str, Union[int, pd.Timestamp]]] = None,
    title: str = "Time series with estimated breaks",
    ylabel: str = "Value",
    xlabel: str = "Time",
    figsize: tuple[float, float] = (12, 5),
    palette: str = "deep",
    annotate: bool = True,
) -> Figure:
    """Plot one or more time series with optional vertical lines / shaded
    regions marking estimated break dates.

    Reproduces the style of Figure 1 of RSV2019.

    Parameters
    ----------
    series : Mapping[name, Series or array]
        Each entry is plotted as a separate line. ``pandas.Series`` with
        a DatetimeIndex are preferred for nice x-axis formatting.
    breaks : Mapping[name, int or pandas.Timestamp], optional
        Estimated break location per series. ``int`` is treated as an
        observation index; ``Timestamp`` is plotted on the date axis.
    title, ylabel, xlabel : str
    figsize : tuple
    palette : str
    annotate : bool
        Whether to annotate the break with its label.
    """
    _ensure_mpl()
    set_style(palette=palette)
    fig, ax = plt.subplots(figsize=figsize)
    colors = sns.color_palette(palette, n_colors=max(3, len(series)))

    for i, (name, s) in enumerate(series.items()):
        if isinstance(s, np.ndarray):
            s = pd.Series(s, name=name)
        s.plot(ax=ax, color=colors[i], lw=1.6, label=name, alpha=0.9)

    if breaks:
        for name, bk in breaks.items():
            if isinstance(bk, (pd.Timestamp, np.datetime64)):
                ax.axvline(
                    bk, color="firebrick", ls="--", lw=1.1, alpha=0.7
                )
                if annotate:
                    ax.annotate(
                        name,
                        xy=(bk, ax.get_ylim()[1]),
                        xycoords="data",
                        xytext=(4, -10),
                        textcoords="offset points",
                        fontsize=9,
                        color="firebrick",
                    )
            else:
                ax.axvline(
                    int(bk), color="firebrick", ls="--", lw=1.1, alpha=0.7
                )
                if annotate:
                    ax.text(
                        int(bk),
                        ax.get_ylim()[1],
                        f" {name}",
                        color="firebrick",
                        fontsize=9,
                        va="top",
                    )

    ax.set_title(title, fontsize=13, weight="bold", pad=12)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.legend(loc="best", frameon=True)
    ax.grid(True, alpha=0.3)

    # Nice date formatter if the x-axis is date-like.
    if any(
        isinstance(s, pd.Series) and isinstance(s.index, pd.DatetimeIndex)
        for s in series.values()
    ):
        ax.xaxis.set_major_locator(mdates.AutoDateLocator())
        ax.xaxis.set_major_formatter(mdates.ConciseDateFormatter(ax.xaxis.get_major_locator()))

    fig.tight_layout()
    return fig


# ---------------------------------------------------------------------------
# 2. RSV sequential profile (t^2 curve along the supremum index set)
# ---------------------------------------------------------------------------
def plot_rsv_profile(
    result: RSVResult,
    alpha: float = 0.05,
    figsize: tuple[float, float] = (11, 5),
    title: Optional[str] = None,
) -> Figure:
    """Plot the t² profile of an RSV (2019) supremum test along its
    index set, with the rejection threshold drawn as a horizontal
    line and the argmax highlighted.
    """
    _ensure_mpl()
    set_style()
    fig, ax = plt.subplots(figsize=figsize)

    grid = np.array(result.grid)
    # Use the midpoint of each pair as the x-coordinate, which is
    # natural for rolling tests and also works for incrementals.
    x = 0.5 * (grid[:, 0] + grid[:, 1])
    ax.plot(x, result.t2_path, color="steelblue", lw=2, label=r"$t^{2}(\hat e)$")

    cv = result.critical_values.get(alpha, None)
    if cv is not None and not np.isnan(cv):
        ax.axhline(cv, color="firebrick", ls="--", lw=1.2,
                   label=f"{int(alpha*100)}% critical value = {cv:.3f}")

    # Highlight the argmax
    k_star = int(np.argmax(result.t2_path))
    ax.plot(x[k_star], result.t2_path[k_star], "o", ms=10, color="darkorange",
            label=f"sup = {result.statistic:.3f} at "
                  f"(λ1, λ2) = ({result.argmax[0]:.2f}, {result.argmax[1]:.2f})")

    ax.set_xlabel(r"Break-point fraction (midpoint of $\lambda_1, \lambda_2$)")
    ax.set_ylabel(r"$t^{2}$ statistic")
    ax.set_title(
        title or f"RSV (2019) {result.name} profile  (T = {result.T}, d = {result.d:.2f})",
        fontsize=12, weight="bold", pad=10,
    )
    ax.legend(loc="best", frameon=True)
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    return fig


# ---------------------------------------------------------------------------
# 3. Battery of profiles in one figure
# ---------------------------------------------------------------------------
def plot_rsv_battery(
    battery: Mapping[str, RSVResult],
    alpha: float = 0.05,
    figsize: tuple[float, float] = (12, 8),
    title: str = "RSV (2019) sup-test battery",
) -> Figure:
    """Plot the t² profiles of every test in a battery on a 2×2 grid."""
    _ensure_mpl()
    set_style()
    items = list(battery.items())
    n = len(items)
    ncols = 2 if n > 1 else 1
    nrows = int(np.ceil(n / ncols))
    fig, axes = plt.subplots(nrows, ncols, figsize=figsize, squeeze=False)

    for ax, (name, res) in zip(axes.flat, items):
        grid = np.array(res.grid)
        x = 0.5 * (grid[:, 0] + grid[:, 1])
        ax.plot(x, res.t2_path, color="steelblue", lw=1.8)
        cv = res.critical_values.get(alpha, None)
        if cv is not None and not np.isnan(cv):
            ax.axhline(cv, color="firebrick", ls="--", lw=1.0)
        k_star = int(np.argmax(res.t2_path))
        ax.plot(x[k_star], res.t2_path[k_star], "o", color="darkorange", ms=8)
        ax.set_title(f"{name}  (sup = {res.statistic:.3f})", fontsize=11)
        ax.grid(True, alpha=0.3)

    # Hide unused axes
    for ax in axes.flat[n:]:
        ax.axis("off")

    fig.suptitle(title, fontsize=14, weight="bold")
    fig.tight_layout(rect=(0, 0, 1, 0.96))
    return fig


# ---------------------------------------------------------------------------
# 4. Break-point objective function
# ---------------------------------------------------------------------------
def plot_breakpoint_objective(
    result: BreakPointResult,
    figsize: tuple[float, float] = (10, 4.5),
    title: Optional[str] = None,
) -> Figure:
    """Plot the eq. (19) objective along the τ grid."""
    _ensure_mpl()
    set_style()
    fig, ax = plt.subplots(figsize=figsize)
    ax.plot(result.tau_grid, result.objective, color="steelblue", lw=1.8)
    ax.axvline(
        result.tau_hat,
        color="darkorange",
        ls="--",
        lw=1.3,
        label=fr"$\hat\tau$ = {result.tau_hat:.3f}",
    )
    ax.set_xlabel(r"$\tau$")
    ax.set_ylabel(r"$[\tau T]^{-2\hat d}\, \sum_{t=1}^{[\tau T]} \hat e_t^{2}$")
    ax.set_title(
        title or f"Break-point objective ({result.direction})",
        fontsize=12, weight="bold",
    )
    ax.legend(loc="best", frameon=True)
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    return fig


# ---------------------------------------------------------------------------
# 5. Diagnostic dashboard — residuals + ACF + density
# ---------------------------------------------------------------------------
def plot_residual_diagnostics(
    residuals: np.ndarray,
    lags: int = 30,
    figsize: tuple[float, float] = (12, 7),
    title: str = "Residual diagnostics",
) -> Figure:
    """Diagnostic dashboard for the OLS / HB regression residuals."""
    _ensure_mpl()
    set_style()
    from statsmodels.graphics.tsaplots import plot_acf

    fig = plt.figure(figsize=figsize)
    gs = fig.add_gridspec(2, 2, hspace=0.35, wspace=0.25)
    ax1 = fig.add_subplot(gs[0, :])
    ax2 = fig.add_subplot(gs[1, 0])
    ax3 = fig.add_subplot(gs[1, 1])

    ax1.plot(residuals, color="steelblue", lw=1.0)
    ax1.axhline(0, color="black", lw=0.5)
    ax1.set_title("Residual series", fontsize=11, weight="bold")
    ax1.grid(True, alpha=0.3)

    plot_acf(residuals, lags=lags, ax=ax2)
    ax2.set_title("ACF", fontsize=11, weight="bold")

    sns.histplot(residuals, kde=True, color="steelblue", ax=ax3)
    ax3.set_title("Density", fontsize=11, weight="bold")

    fig.suptitle(title, fontsize=14, weight="bold")
    fig.tight_layout(rect=(0, 0, 1, 0.96))
    return fig


# ---------------------------------------------------------------------------
# 6. Heatmap of split-sample t^2 for a (λ1, λ2) grid
# ---------------------------------------------------------------------------
def plot_split_heatmap(
    y1,
    y2,
    d: float = 1.0,
    n_grid: int = 50,
    lam0: float = 0.1,
    include_const: bool = True,
    figsize: tuple[float, float] = (8, 6.5),
    title: str = r"$t^{2}(\hat e(\lambda_1, \lambda_2))$ heatmap",
) -> Figure:
    """2-D heatmap of the sub-sample t² statistic over a grid of
    :math:`(\\lambda_1, \\lambda_2)` pairs with
    :math:`\\lambda_2 - \\lambda_1 \\ge \\lambda_0`.
    """
    _ensure_mpl()
    set_style()
    from .rsv_tests import _hb_subsample_tstat, _ols_residuals  # type: ignore

    y1_arr = np.asarray(y1, dtype=float).ravel()
    y2_arr = np.atleast_2d(np.asarray(y2, dtype=float))
    if y2_arr.shape[0] != y1_arr.size:
        y2_arr = y2_arr.T
    e = _ols_residuals(y1_arr, y2_arr, include_const=include_const)
    T = e.size

    lams = np.linspace(0.0, 1.0, n_grid)
    Z = np.full((n_grid, n_grid), np.nan)
    for i, l1 in enumerate(lams):
        for j, l2 in enumerate(lams):
            if l2 - l1 >= lam0:
                tstat, *_ = _hb_subsample_tstat(e, d, l1, l2, T)
                Z[i, j] = tstat ** 2

    fig, ax = plt.subplots(figsize=figsize)
    im = ax.imshow(
        Z,
        origin="lower",
        extent=(0, 1, 0, 1),
        aspect="auto",
        cmap="viridis",
    )
    fig.colorbar(im, ax=ax, label=r"$t^{2}$")
    ax.set_xlabel(r"$\lambda_2$")
    ax.set_ylabel(r"$\lambda_1$")
    ax.set_title(title, fontsize=12, weight="bold")
    fig.tight_layout()
    return fig
