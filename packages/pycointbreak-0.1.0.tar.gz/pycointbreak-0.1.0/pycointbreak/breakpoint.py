"""
Break-point estimator
=====================

Implements eq. (19) of Rodrigues, Sibbertsen & Voges (2019):

.. math::

    \\hat\\tau \\;=\\; \\arg\\inf_{\\tau \\in \\Delta}
    [\\tau T]^{-2\\hat d}\\sum_{t=1}^{[\\tau T]}\\hat e_t^{\\,2}(\\tau),
    \\qquad \\Delta = (\\delta, 1 - \\delta),

with :math:`0 < \\delta < 0.5`. By Theorem 3, when the break is from
cointegration to no cointegration, :math:`\\hat\\tau \\to \\tau_0`.

By Remark 3.3 the same estimator applied to the reversed residual
series can be used when the break is from no cointegration to
cointegration.

Author
------
Dr. Merwan Roudane  <merwanroudane920@gmail.com>
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Literal, Optional, Union

import numpy as np
import pandas as pd

ArrayLike = Union[np.ndarray, pd.Series, pd.DataFrame]


@dataclass
class BreakPointResult:
    """Result of the RSV2019 break-point estimator.

    Attributes
    ----------
    tau_hat : float
        Break fraction in [0, 1].
    obs : int
        Observation index of the estimated break (``int(tau_hat * T)``).
    date : pandas.Timestamp or None
        Calendar date of the break if the input series carried a
        DatetimeIndex.
    delta : float
        Trimming parameter used.
    direction : str
        Either 'forward' (cointegrated -> spurious) or 'backward'
        (spurious -> cointegrated).
    objective : numpy.ndarray
        The objective ``[tauT]^{-2d} * SSR(tau)`` evaluated along the
        full grid (useful for plotting).
    tau_grid : numpy.ndarray
        Grid of break fractions on which the objective was evaluated.
    T : int
    d : float
    """

    tau_hat: float
    obs: int
    date: Optional[pd.Timestamp]
    delta: float
    direction: str
    objective: np.ndarray
    tau_grid: np.ndarray
    T: int
    d: float

    def summary(self) -> str:
        lines = []
        lines.append("=" * 70)
        lines.append("  RSV (2019) break-point estimator")
        lines.append("=" * 70)
        lines.append(f"  Direction               : {self.direction}")
        lines.append(f"  Trimming delta          : {self.delta:.3f}")
        lines.append(f"  Fractional order d      : {self.d:.3f}")
        lines.append(f"  Sample size T           : {self.T}")
        lines.append("-" * 70)
        lines.append(f"  tau_hat                 : {self.tau_hat:.4f}")
        lines.append(f"  Observation             : {self.obs}")
        if self.date is not None:
            lines.append(f"  Estimated break date    : {self.date.date()}")
        lines.append("=" * 70)
        return "\n".join(lines)

    def __repr__(self) -> str:  # pragma: no cover
        return (
            f"BreakPointResult(tau_hat={self.tau_hat:.3f}, obs={self.obs}, "
            f"direction={self.direction})"
        )


# ---------------------------------------------------------------------------
# Internal: OLS residuals
# ---------------------------------------------------------------------------
def _ols_residuals_for_breakpoint(
    y1: np.ndarray,
    y2: np.ndarray,
    include_const: bool,
) -> np.ndarray:
    T = y1.size
    if include_const:
        X = np.column_stack([np.ones(T), y2])
    else:
        X = y2
    beta, *_ = np.linalg.lstsq(X, y1, rcond=None)
    return y1 - X @ beta


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------
def estimate_break_point(
    y1: ArrayLike,
    y2: ArrayLike,
    d: float = 1.0,
    delta: float = 0.05,
    direction: Literal["forward", "backward", "auto"] = "auto",
    include_const: bool = True,
    residuals: Optional[np.ndarray] = None,
    index: Optional[pd.DatetimeIndex] = None,
) -> BreakPointResult:
    """Estimate the break fraction :math:`\\tau_0` per eq. (19) of
    RSV2019.

    Parameters
    ----------
    y1 : array_like, shape (T,)
        Scalar :math:`I(d)` series.
    y2 : array_like, shape (T,) or (T, m)
        :math:`I(d)` regressor(s).
    d : float, default 1.0
        Fractional integration order. By Theorem 3, ``d`` need only be
        consistently estimated.
    delta : float, default 0.05
        Trimming parameter :math:`0 < \\delta < 0.5`. RSV2019 (last
        paragraph of Sec. 4) recommend a small :math:`\\delta`.
    direction : {'forward', 'backward', 'auto'}, default 'auto'
        ``'forward'`` corresponds to a break from cointegration to no
        cointegration (Theorem 3). ``'backward'`` (Remark 3.3) applies
        the estimator to the reversed residual series, suitable for a
        break from no cointegration to cointegration. ``'auto'``
        evaluates both and returns the lower objective value.
    include_const : bool, default True
        Whether to include a constant in the cointegrating regression.
    residuals : array_like, optional
        Pre-computed OLS residuals (overrides ``y1``, ``y2``).
    index : pandas.DatetimeIndex, optional
        If given, used to map the estimated observation index to a
        calendar date.

    Returns
    -------
    BreakPointResult
    """
    if residuals is None:
        y1_arr = np.asarray(y1, dtype=float).ravel()
        y2_arr = np.atleast_2d(np.asarray(y2, dtype=float))
        if y2_arr.shape[0] != y1_arr.size:
            y2_arr = y2_arr.T
        if isinstance(y1, pd.Series) and index is None:
            if isinstance(y1.index, pd.DatetimeIndex):
                index = y1.index
        e = _ols_residuals_for_breakpoint(y1_arr, y2_arr, include_const)
    else:
        e = np.asarray(residuals, dtype=float).ravel()

    T = e.size
    if not 0.0 < delta < 0.5:
        raise ValueError("delta must be in (0, 0.5).")

    t_lo = int(np.ceil(delta * T))
    t_hi = int(np.floor((1.0 - delta) * T))
    if t_hi <= t_lo + 1:
        raise ValueError(
            "Sample too small for the requested delta — reduce delta."
        )

    def _forward_obj(e_local: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        tau_grid = np.arange(t_lo, t_hi + 1) / T
        obj = np.empty(tau_grid.size, dtype=float)
        # Cumulative sum of squared residuals — O(T) total.
        csum_sq = np.cumsum(e_local**2)
        for k, tt in enumerate(np.arange(t_lo, t_hi + 1)):
            ssr = csum_sq[tt - 1]
            scale = float(tt) ** (-2.0 * d)
            obj[k] = scale * ssr
        return tau_grid, obj

    def _do(direction_label: str, e_local: np.ndarray):
        tau_grid, obj = _forward_obj(e_local)
        k_star = int(np.argmin(obj))
        tau_hat = float(tau_grid[k_star])
        obs = int(tau_hat * T)
        date = None
        if index is not None:
            # For backward, the optimum was found on the reversed
            # series, so the calendar position is T - obs (clipped).
            obs_for_date = obs if direction_label == "forward" else max(
                0, T - obs - 1
            )
            try:
                date = index[obs_for_date]
            except IndexError:
                date = None
        return tau_hat, obs, date, tau_grid, obj

    if direction == "forward":
        tau_hat, obs, date, grid, obj = _do("forward", e)
    elif direction == "backward":
        tau_hat, obs, date, grid, obj = _do("backward", e[::-1])
    elif direction == "auto":
        fwd = _do("forward", e)
        bwd = _do("backward", e[::-1])
        # Pick the one with lower objective at its argmin.
        if fwd[4].min() <= bwd[4].min():
            tau_hat, obs, date, grid, obj = fwd
            direction = "forward"
        else:
            tau_hat, obs, date, grid, obj = bwd
            direction = "backward"
    else:
        raise ValueError(f"Unknown direction '{direction}'.")

    return BreakPointResult(
        tau_hat=tau_hat,
        obs=obs,
        date=date,
        delta=float(delta),
        direction=direction,
        objective=obj,
        tau_grid=grid,
        T=int(T),
        d=float(d),
    )
