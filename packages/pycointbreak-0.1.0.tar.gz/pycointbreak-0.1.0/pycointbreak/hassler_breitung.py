"""
Hassler & Breitung (2006) residual-based LM-type test against
fractional cointegration
=============================================================

Implements both the iid case (eqs. 12-14) and the AR(p)-corrected
case (eqs. 17-18) of:

    Hassler, U. and Breitung, J. (2006). A Residual-Based LM Type
    Test Against Fractional Cointegration. *Econometric Theory*,
    22(6), 1091-1111.

Model
-----
For an :math:`m`-dimensional :math:`I(d)` regressor
:math:`y_{2,t}` and a scalar :math:`I(d)` series :math:`y_{1,t}`,

.. math::

    y_{1,t} \\;=\\; y_{2,t}'\\beta + z_t,
    \\qquad z_t \\sim I(d - b),\\quad b \\ge 0.

The null hypothesis is :math:`H_0 : b = 0` (no fractional
cointegration) tested against :math:`H_1 : b > 0`.

Test procedure
--------------
1. Apply :math:`\\Delta_+^d` to both sides (eq. 12 / 17) — optionally
   augment with the drift term :math:`\\sum_{i=0}^{t}\\delta_i` when a
   constant is present and :math:`d \\ne 1` (Remark D).
2. OLS to obtain residuals :math:`\\hat x_t` (or :math:`\\hat \\eta_t`
   with AR(p) augmentation).
3. Compute :math:`\\hat x^{*}_{t-1} = \\sum_{j=1}^{t-1} \\hat x_{t-j}/j`.
4. Run the auxiliary regression and compute the t-statistic
   :math:`t_\\phi`; under H0, :math:`t_\\phi \\to \\mathcal{N}(0,1)`.

Author
------
Dr. Merwan Roudane  <merwanroudane920@gmail.com>
GitHub: https://github.com/merwanroudane/pycointbreak
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Union

import numpy as np
import pandas as pd

from .critical_values import hb_critical_value, hb_pvalue
from .fracdiff import drift_regressor, fdiff, harmonic_running_sum

ArrayLike = Union[np.ndarray, pd.Series, pd.DataFrame]


# ---------------------------------------------------------------------------
# Result container
# ---------------------------------------------------------------------------
@dataclass
class HBResult:
    """Result of a Hassler-Breitung test.

    Attributes
    ----------
    t_stat : float
        Test statistic. Under H0: ``t_stat -> N(0, 1)``.
    p_value : float
        Lower-tail p-value :math:`\\Phi(t)`.
    critical_values : dict
        ``{alpha : z_alpha}`` for ``alpha`` in ``{0.01, 0.05, 0.10}``.
    reject : dict
        ``{alpha : bool}`` indicating rejection of H0 at each level.
    d : float
        Order of fractional integration used for the test.
    p : int
        Lag length of the AR(p) augmentation (``p = 0`` for the iid
        variant).
    T : int
        Effective sample size used in the test regression.
    method : str
        Either ``'iid'`` or ``'AR(p)'``.
    include_const : bool
        Whether a constant (drift) was included.
    beta_hat : numpy.ndarray
        OLS slope estimate(s) from the differenced cointegrating
        regression.
    residuals : numpy.ndarray
        Residuals used in the auxiliary regression
        (:math:`\\hat x_t` or :math:`\\hat \\eta_t`).
    phi_hat : float
        OLS estimate of :math:`\\phi` in the auxiliary regression.
    n_regressors : int
        Number of regressors in the cointegrating regression.
    """

    t_stat: float
    p_value: float
    critical_values: dict
    reject: dict
    d: float
    p: int
    T: int
    method: str
    include_const: bool
    beta_hat: np.ndarray
    residuals: np.ndarray
    phi_hat: float
    n_regressors: int
    name: str = "Hassler-Breitung (2006)"
    extra: dict = field(default_factory=dict)

    # ------------------------------------------------------------------
    def summary(self) -> str:
        """Return a paper-style text summary."""
        lines = []
        lines.append("=" * 70)
        lines.append(f"  {self.name} -- LM test for no fractional cointegration")
        lines.append("=" * 70)
        lines.append(f"  H0 : b = 0   (no cointegration)")
        lines.append(f"  H1 : b > 0   (fractional cointegration)")
        lines.append("-" * 70)
        lines.append(f"  Method                  : {self.method}")
        lines.append(f"  Fractional order  d     : {self.d:.4f}")
        lines.append(f"  AR augmentation   p     : {self.p}")
        lines.append(f"  Constant in regression  : {self.include_const}")
        lines.append(f"  Regressors        m     : {self.n_regressors}")
        lines.append(f"  Effective sample  T     : {self.T}")
        lines.append("-" * 70)
        lines.append(f"  t_phi                   : {self.t_stat: .4f}")
        lines.append(f"  phi_hat                 : {self.phi_hat: .4f}")
        lines.append(f"  p-value (one-sided)     : {self.p_value: .4f}")
        lines.append("  Critical values         :")
        for a, cv in self.critical_values.items():
            mark = "  REJECT H0" if self.reject[a] else "  fail to reject"
            lines.append(f"    {int(a*100):>3d}%   {cv: .4f}   {mark}")
        lines.append("=" * 70)
        lines.append("  Reject for SIGNIFICANTLY NEGATIVE values of t_phi.")
        lines.append("=" * 70)
        return "\n".join(lines)

    def __repr__(self) -> str:  # pragma: no cover
        return (
            f"HBResult(t_stat={self.t_stat:.4f}, p={self.p_value:.4f}, "
            f"d={self.d:.3f}, p={self.p}, T={self.T})"
        )

    def to_dataframe(self) -> pd.DataFrame:
        """One-row pandas summary suitable for stacking across tests."""
        return pd.DataFrame(
            {
                "test": [self.name],
                "method": [self.method],
                "d": [self.d],
                "p": [self.p],
                "T": [self.T],
                "t_stat": [self.t_stat],
                "p_value": [self.p_value],
                "phi_hat": [self.phi_hat],
                "cv_5%": [self.critical_values[0.05]],
                "reject_5%": [self.reject[0.05]],
            }
        )


# ---------------------------------------------------------------------------
# Internal: OLS helper that returns coefs and residuals
# ---------------------------------------------------------------------------
def _ols(y: np.ndarray, X: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    y = np.asarray(y, dtype=float).ravel()
    X = np.atleast_2d(np.asarray(X, dtype=float))
    if X.shape[0] != y.size:
        X = X.T
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    resid = y - X @ beta
    return beta, resid


# ---------------------------------------------------------------------------
# Step 1: differenced cointegrating regression (eq. 12 / 17 of HB2006)
# ---------------------------------------------------------------------------
def _diff_cointegrating_regression(
    y1: np.ndarray,
    y2: np.ndarray,
    d: float,
    include_const: bool,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Apply Δ^d_+ to both sides and run OLS.

    Returns ``(d_y1, d_y2, beta_hat, x_hat)``.

    If ``include_const`` is True and ``d != 1`` the cumulative drift
    regressor :math:`\\sum_{i=0}^{t}\\delta_i` is added as an
    additional column (Remark D of HB2006). If ``d == 1`` the
    constant is annihilated by differencing and no extra regressor
    is needed.
    """
    d_y1 = fdiff(y1, d)
    d_y2 = fdiff(y2, d)
    if d_y2.ndim == 1:
        d_y2 = d_y2.reshape(-1, 1)

    if include_const:
        if abs(d - 1.0) < 1e-10:
            # Constant is removed by Δ^1.
            X = d_y2
        else:
            drift = drift_regressor(d, d_y1.size).reshape(-1, 1)
            X = np.column_stack([drift, d_y2])
    else:
        X = d_y2

    beta_hat, x_hat = _ols(d_y1, X)
    return d_y1, d_y2, beta_hat, x_hat


# ---------------------------------------------------------------------------
# Step 2: iid auxiliary regression (eq. 14)
# ---------------------------------------------------------------------------
def _hb_iid(
    x_hat: np.ndarray,
) -> tuple[float, float, int]:
    """Compute the HB t-statistic in the iid case (eq. 14 of HB2006):

    .. math::

        t_\\phi(\\hat x) \\;=\\; \\frac{\\sum \\hat x_t \\hat x^{*}_{t-1}}
        {\\sqrt{\\sum (\\hat x^{*}_{t-1})^{2}}\\;
         \\sqrt{(T-1)^{-1}\\sum \\hat x_t^{2}}}.

    Returns ``(t_stat, phi_hat, T_eff)``.
    """
    x = np.asarray(x_hat, dtype=float).ravel()
    T = x.size
    x_star = harmonic_running_sum(x)  # x*_{t-1} stored at index t-1

    # Sum from t = 2 to T (paper) -> Python indices 1..T-1
    num = float(np.sum(x[1:] * x_star[1:]))
    denom_left = float(np.sqrt(np.sum(x_star[1:] ** 2)))
    sigma2_hat = float(np.sum(x**2) / (T - 1))
    denom_right = float(np.sqrt(sigma2_hat))
    t_stat = num / (denom_left * denom_right + 1e-300)

    # OLS phi estimate (paper variance estimator under H0 in the
    # studentisation, but the point estimate is the usual OLS).
    phi_hat = num / (float(np.sum(x_star[1:] ** 2)) + 1e-300)
    return float(t_stat), float(phi_hat), int(T)


# ---------------------------------------------------------------------------
# Step 2 (alt): AR(p)-augmented auxiliary regression (eq. 18 of HB2006)
# ---------------------------------------------------------------------------
def _hb_arp(
    d_y1: np.ndarray,
    d_y2: np.ndarray,
    eta_hat: np.ndarray,
    p: int,
) -> tuple[float, float, int]:
    """Compute the AR(p)-corrected HB statistic.

    Equation (18) of HB2006:

    .. math::

        \\hat\\eta_t \\;=\\; \\tilde\\phi\\,\\hat\\eta^{*}_{t-1}
        \\;+\\; \\sum_{i=1}^{p}\\tilde\\psi_i\\,\\Delta^d y_{1,t-i}
        \\;+\\; \\sum_{i=0}^{p}\\tilde\\theta_i'\\,\\Delta^d y_{2,t-i}
        \\;+\\; \\tilde e_t,

    where :math:`\\hat\\eta^{*}_{t-1} = \\sum_{j=1}^{t-p-1}
    j^{-1}\\hat\\eta_{t-j}` and ``eta_hat`` are the OLS residuals from
    the AR(p)-augmented cointegrating regression in differences
    (eq. 17).

    Returns ``(t_stat, phi_hat, T_eff)``.
    """
    eta = np.asarray(eta_hat, dtype=float).ravel()
    T = eta.size
    eta_star = harmonic_running_sum(eta)

    # Build the regression on [eta*_{t-1}, lagged Δ^d y_{1,t-i},
    # lagged Δ^d y_{2,t-i}].
    if p < 0:
        raise ValueError("p must be >= 0.")

    d_y1 = np.asarray(d_y1, dtype=float).ravel()
    d_y2 = np.atleast_2d(np.asarray(d_y2, dtype=float))
    if d_y2.shape[0] != T:
        d_y2 = d_y2.T

    # Effective regression starts at t = p + 1 (Python index p) so all
    # lags exist.
    start = p + 1
    end = T  # inclusive of T-1 in Python indexing
    n_eff = end - start

    cols: list[np.ndarray] = [eta_star[start:end]]
    for i in range(1, p + 1):
        cols.append(d_y1[start - i : end - i])
    for i in range(0, p + 1):
        cols.append(d_y2[start - i : end - i, :])

    # Stack columns: cols may contain 1-D arrays and 2-D blocks
    blocks = []
    for c in cols:
        c = np.atleast_2d(c)
        if c.shape[0] != n_eff:
            c = c.T
        blocks.append(c)
    X = np.hstack(blocks)

    y = eta[start:end]
    beta, resid = _ols(y, X)
    phi_hat = float(beta[0])

    # Studentisation under H0 (Remark F): sigma2_hat = T^{-1} sum eta^2
    # (we use the effective T = n_eff). The numerator/denominator in
    # the t-stat are exactly the OLS t-ratio with this variance.
    sigma2_hat = float(np.sum(eta**2) / T)

    # XtX inverse for s.e. of phi_hat
    XtX_inv = np.linalg.inv(X.T @ X)
    var_phi = sigma2_hat * XtX_inv[0, 0]
    t_stat = phi_hat / float(np.sqrt(var_phi) + 1e-300)
    return float(t_stat), float(phi_hat), int(n_eff)


# ---------------------------------------------------------------------------
# Public API: hassler_breitung_test
# ---------------------------------------------------------------------------
def hassler_breitung_test(
    y1: ArrayLike,
    y2: ArrayLike,
    d: float = 1.0,
    p: int = 0,
    include_const: bool = True,
    alphas: tuple[float, ...] = (0.01, 0.05, 0.10),
) -> HBResult:
    """Hassler & Breitung (2006) test for no fractional cointegration.

    Tests :math:`H_0 : b = 0` against :math:`H_1 : b > 0` in the model
    :math:`y_{1,t} = y_{2,t}'\\beta + z_t,\\; z_t \\sim I(d-b)`.

    The test statistic is asymptotically :math:`\\mathcal{N}(0, 1)`
    under H0 (Propositions 3 and 4 of HB2006). The test is one-sided:
    H0 is rejected for *significantly negative* values of ``t_stat``.

    Parameters
    ----------
    y1 : array_like, shape (T,)
        Scalar :math:`I(d)` series.
    y2 : array_like, shape (T,) or (T, m)
        :math:`m`-dimensional :math:`I(d)` regressor.
    d : float, default 1.0
        Order of fractional integration. Must be known a priori (or
        estimated, e.g., with :func:`pycointbreak.gph.gph`; see
        Remark E and Sec. 5 of HB2006).
    p : int, default 0
        Order of the AR(p) augmentation. ``p = 0`` corresponds to
        eq. (14) (iid case); ``p >= 1`` to eq. (18) (serial
        correlation correction).
    include_const : bool, default True
        Whether ``y_1`` and ``y_2`` evolve around possibly different
        levels (see Remark D). If True and ``d != 1`` the cumulative
        drift regressor :math:`\\sum\\delta_i` is added; if
        ``d == 1`` the constant is absorbed by differencing and no
        extra column is needed.
    alphas : tuple of float
        Significance levels for which to report critical values.

    Returns
    -------
    HBResult
        Test result with attributes ``t_stat``, ``p_value``,
        ``critical_values``, ``reject``, ``residuals``, ``beta_hat``,
        and the helper method :meth:`HBResult.summary`.

    Examples
    --------
    >>> import numpy as np
    >>> rng = np.random.default_rng(7)
    >>> T = 500
    >>> # Two independent I(1) series — no cointegration.
    >>> e1 = rng.standard_normal(T); e2 = rng.standard_normal(T)
    >>> y2 = np.cumsum(e1); y1 = np.cumsum(e2)
    >>> res = hassler_breitung_test(y1, y2, d=1.0)
    >>> bool(res.reject[0.05])  # doctest: +SKIP
    False
    """
    y1 = np.asarray(y1, dtype=float).ravel()
    y2 = np.atleast_2d(np.asarray(y2, dtype=float))
    if y2.shape[0] != y1.size:
        y2 = y2.T
    if y2.shape[0] != y1.size:
        raise ValueError("y1 and y2 must have the same length T.")
    T_total = y1.size
    m = y2.shape[1]

    d_y1, d_y2, beta_hat, x_hat = _diff_cointegrating_regression(
        y1, y2, d=d, include_const=include_const
    )

    if p == 0:
        t_stat, phi_hat, T_eff = _hb_iid(x_hat)
        method = "iid (eq. 14)"
        residuals = x_hat
    else:
        t_stat, phi_hat, T_eff = _hb_arp(d_y1, d_y2, x_hat, p)
        method = f"AR({p}) (eq. 18)"
        residuals = x_hat

    p_value = hb_pvalue(t_stat)
    cv = {a: hb_critical_value(a) for a in alphas}
    reject = {a: t_stat < cv[a] for a in alphas}

    return HBResult(
        t_stat=t_stat,
        p_value=p_value,
        critical_values=cv,
        reject=reject,
        d=float(d),
        p=int(p),
        T=int(T_eff),
        method=method,
        include_const=bool(include_const),
        beta_hat=np.asarray(beta_hat, dtype=float),
        residuals=residuals,
        phi_hat=float(phi_hat),
        n_regressors=int(m),
        extra={"T_total": int(T_total)},
    )


# ---------------------------------------------------------------------------
# Convenience: t-statistic only, useful for the sup-statistics of RSV
# ---------------------------------------------------------------------------
def hb_tstat_on_residuals(
    x_hat: np.ndarray,
) -> float:
    """Compute the HB iid t-statistic directly from a residual vector.

    Used internally by the RSV (2019) supremum tests, which apply the
    HB statistic to subsamples of OLS residuals.

    Parameters
    ----------
    x_hat : array_like
        Residual vector (already differenced and projected as in
        eqs. 12-13 of HB2006).

    Returns
    -------
    float
        The HB t-statistic.
    """
    t_stat, _, _ = _hb_iid(x_hat)
    return t_stat
