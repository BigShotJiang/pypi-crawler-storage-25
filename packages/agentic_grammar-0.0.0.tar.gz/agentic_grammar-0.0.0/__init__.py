# -*- coding: utf-8 -*-
"""agentic-grammar modules."""