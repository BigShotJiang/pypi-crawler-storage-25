import sys

# Block only when pip tries to build a wheel for installation.
# Allow `uv build --sdist` (called with 'sdist') so we can publish.
if "bdist_wheel" in sys.argv or "install" in sys.argv:
    sys.stderr.write(
        "\n"
        "ERROR: 'agenteye' is not available on public PyPI.\n"
        "AgentEye is an enterprise product and is distributed privately.\n"
        "Please contact support@exosphere.host for access.\n"
        "\n"
    )
    sys.exit(1)

from setuptools import setup

setup()
