import os
from mcp.server.fastmcp import FastMCP
from citekit import CiteKitClient

mcp = FastMCP("squadco-docs")

# Package root directory
PACKAGE_DIR = os.path.dirname(os.path.abspath(__file__))

# Initialize CiteKit (v0.2.1+ handles all path logic natively)
client = CiteKitClient(base_dir=PACKAGE_DIR, storage_dir=".resource_maps")

@mcp.tool()
def list_docs() -> str:
    """List all available SquadCo API documentation modules."""
    return "Available documentation IDs:\n" + "\n".join(client.list_maps())

@mcp.tool()
def search_docs(query: str) -> str:
    """Search documentation nodes across all resources for specific features or keywords."""
    try:
        results = client.search(query, limit=15)
        if not results:
            return f"No documentation sections found matching '{query}'."
        
        output = ["### Search Results"]
        for res in results:
            output.append(f"- **{res.resource_id}** -> `[{res.node.id}]` {res.node.title}\n  _{res.node.summary}_")
        return "\n\n".join(output)
    except Exception:
        # Minimal fallback for older environments
        return "Search failed. Please ensure CiteKit is updated."

@mcp.tool()
def get_doc_structure(doc_id: str) -> str:
    """Retrieve the hierarchical structure of a specific document."""
    doc_map = client.get_map(doc_id)
    lines = [f"Structure for '{doc_id}':"]
    for node in doc_map.nodes:
        lines.append(f"- [{node.id}] {node.title}")
        for sub in node.children: lines.append(f"  - [{sub.id}] {sub.title}")
    return "\n".join(lines)

@mcp.tool()
def resolve_section(doc_id: str, section_id: str) -> str:
    """Fetch the precise technical content of a specific documentation node."""
    try:
        # Native v0.2.1 resolution handles path-joining and line-slicing
        evidence = client.resolve(doc_id, section_id)
        
        if evidence.output_path and os.path.exists(evidence.output_path):
            with open(evidence.output_path, "r", encoding="utf-8") as f:
                return f"## {evidence.node.title} (Source: {doc_id})\n\n{f.read()}"
        
        return f"Error: Failed to resolve {doc_id}/{section_id}"
    except Exception as e:
        return f"Resolution error: {str(e)}"

def main():
    mcp.run()

if __name__ == "__main__":
    main()
