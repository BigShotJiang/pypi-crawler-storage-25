"""Mixin tests."""
