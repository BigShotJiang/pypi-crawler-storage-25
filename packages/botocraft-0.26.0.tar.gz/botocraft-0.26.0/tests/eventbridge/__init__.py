"""EventBridge tests."""
