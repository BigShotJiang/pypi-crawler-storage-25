"""Rules as regards queries."""
