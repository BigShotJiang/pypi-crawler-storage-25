"""Tests for crewai-wzrd velocity tool — mocked, no network or crewai dep."""

from __future__ import annotations

import sys
import types
from unittest.mock import MagicMock, patch

import pytest

# Stub crewai so import works without the heavy dep
_crewai = types.ModuleType("crewai")
_crewai_tools = types.ModuleType("crewai.tools")
_crewai_tools.BaseTool = type("BaseTool", (), {})  # type: ignore[assignment]
sys.modules.setdefault("crewai", _crewai)
sys.modules.setdefault("crewai.tools", _crewai_tools)

from crewai_wzrd import WzrdVelocityTool  # noqa: E402
import crewai_wzrd as mod  # noqa: E402

MOCK_SIGNAL = {
    "models": [
        {"model": "qwen/qwen3-32b", "score": 0.92, "trend": "surging", "confidence": "normal", "platform": "openrouter"},
        {"model": "meta-llama/llama-4-scout", "score": 0.78, "trend": "accelerating", "confidence": "normal", "platform": "openrouter"},
        {"model": "google/gemini-2.5-pro", "score": 0.55, "trend": "stable", "confidence": "normal", "platform": "openrouter"},
        {"model": "old/stale-model", "score": 0.30, "trend": "cooling", "confidence": "low", "platform": "openrouter"},
    ],
    "generated_at": "2026-04-03T00:00:00Z",
}

EMPTY_SIGNAL: dict = {}


@pytest.fixture(autouse=True)
def _clear_cache():
    mod._cache.clear()
    yield
    mod._cache.clear()


class TestRanking:
    def test_surging_ranks_first(self):
        ranked = mod._rank(MOCK_SIGNAL)
        assert ranked[0]["model"] == "qwen/qwen3-32b"

    def test_cooling_ranks_last(self):
        ranked = mod._rank(MOCK_SIGNAL)
        assert ranked[-1]["model"] == "old/stale-model"

    def test_empty_signal_returns_empty(self):
        assert mod._rank({}) == []
        assert mod._rank({"models": []}) == []

    def test_insufficient_confidence_scores_zero(self):
        signal = {"models": [
            {"model": "a", "score": 0.9, "trend": "surging", "confidence": "insufficient"},
            {"model": "b", "score": 0.1, "trend": "stable", "confidence": "normal"},
        ]}
        ranked = mod._rank(signal)
        assert ranked[0]["model"] == "b"


class TestDetectCapability:
    def test_code_keywords(self):
        assert mod._detect_capability("Write some Python code") == "code"
        assert mod._detect_capability("debug this function") == "code"

    def test_reasoning_keywords(self):
        assert mod._detect_capability("analyze the math problem") == "reasoning"

    def test_vision_keywords(self):
        assert mod._detect_capability("describe this image") == "vision"

    def test_no_match_returns_none(self):
        assert mod._detect_capability("hello world") is None


class TestFetch:
    @patch("crewai_wzrd.httpx.get")
    def test_success(self, mock_get):
        mock_get.return_value = MagicMock(status_code=200, json=lambda: MOCK_SIGNAL)
        mock_get.return_value.raise_for_status = MagicMock()
        result = mod._fetch()
        assert result["models"][0]["model"] == "qwen/qwen3-32b"

    @patch("crewai_wzrd.httpx.get")
    def test_network_error_returns_empty(self, mock_get):
        mock_get.side_effect = Exception("timeout")
        assert mod._fetch() == {}

    @patch("crewai_wzrd.httpx.get")
    def test_cache_hit(self, mock_get):
        mock_get.return_value = MagicMock(status_code=200, json=lambda: MOCK_SIGNAL)
        mock_get.return_value.raise_for_status = MagicMock()
        mod._fetch()
        mod._fetch()
        assert mock_get.call_count == 1

    @patch("crewai_wzrd.httpx.get")
    def test_capability_param_in_url(self, mock_get):
        mock_get.return_value = MagicMock(status_code=200, json=lambda: MOCK_SIGNAL)
        mock_get.return_value.raise_for_status = MagicMock()
        mod._fetch("code")
        url = mock_get.call_args[0][0]
        assert "capability=code" in url


class TestToolRun:
    @patch("crewai_wzrd.httpx.get")
    def test_run_returns_recommendation(self, mock_get):
        mock_get.return_value = MagicMock(status_code=200, json=lambda: MOCK_SIGNAL)
        mock_get.return_value.raise_for_status = MagicMock()
        tool = WzrdVelocityTool()
        result = tool._run("Write a Python sort function")
        assert "qwen/qwen3-32b" in result
        assert "surging" in result

    @patch("crewai_wzrd.httpx.get")
    def test_run_with_no_signal(self, mock_get):
        mock_get.side_effect = Exception("down")
        tool = WzrdVelocityTool()
        result = tool._run("anything")
        assert "default model" in result.lower()

    @patch("crewai_wzrd.httpx.get")
    def test_run_cooling_model_warns(self, mock_get):
        cooling_signal = {"models": [
            {"model": "slow/model", "score": 0.3, "trend": "cooling", "confidence": "normal", "platform": "x"},
        ], "generated_at": "2026-04-03T00:00:00Z"}
        mock_get.return_value = MagicMock(status_code=200, json=lambda: cooling_signal)
        mock_get.return_value.raise_for_status = MagicMock()
        tool = WzrdVelocityTool()
        result = tool._run("test task")
        assert "cooling" in result
