"""WZRD Velocity Tool for CrewAI.

Gives agents real-time model velocity data for informed model selection.
Free tier, no auth required. Signals cached 60s.

    from crewai_wzrd import WzrdVelocityTool
    agent = Agent(role="...", tools=[WzrdVelocityTool()])
"""
from __future__ import annotations

import time
import threading
from typing import Any, Dict, List, Optional, Tuple, Type

import httpx
from crewai.tools import BaseTool
from pydantic import BaseModel, Field

__all__ = ["WzrdVelocityTool"]
__version__ = "0.1.0"

MOMENTUM_URL = "https://api.twzrd.xyz/v1/signals/momentum"
CACHE_TTL = 60

TREND_BOOST = {
    "surging": 3.0, "accelerating": 2.0, "stable": 0.0,
    "insufficient_history": 0.0, "decelerating": -1.0, "cooling": -2.0,
}
CONFIDENCE_WEIGHT = {"normal": 1.0, "low": 0.5, "insufficient": 0.0}

CAPABILITY_KEYWORDS = {
    "code": ["code", "programming", "implement", "debug", "refactor", "develop"],
    "reasoning": ["reason", "logic", "math", "analyz", "think", "plan", "deduc"],
    "chat": ["chat", "conversation", "write", "draft", "summariz", "explain"],
    "vision": ["image", "vision", "picture", "screenshot", "visual", "diagram"],
}

_cache_lock = threading.Lock()
_cache: Dict[str, Tuple[float, Dict[str, Any]]] = {}


def _fetch(capability: Optional[str] = None) -> Dict[str, Any]:
    url = MOMENTUM_URL + (f"?capability={capability}" if capability else "")
    now = time.monotonic()
    with _cache_lock:
        cached = _cache.get(url)
        if cached and (now - cached[0]) < CACHE_TTL:
            return cached[1]
    try:
        r = httpx.get(url, timeout=5.0)
        r.raise_for_status()
        data = r.json()
    except Exception:
        return {}
    if not isinstance(data, dict) or not isinstance(data.get("models"), list):
        return {}
    with _cache_lock:
        _cache[url] = (now, data)
    return data


def _rank(signal: Dict[str, Any]) -> List[Dict[str, Any]]:
    scored: List[Tuple[float, int, Dict[str, Any]]] = []
    for i, m in enumerate(signal.get("models", [])):
        cw = CONFIDENCE_WEIGHT.get(m.get("confidence", "insufficient"), 0.0)
        s = TREND_BOOST.get(m.get("trend", "stable"), 0.0) * cw
        s += min(max(m.get("score", 0.0), 0.0), 1.0) * 0.3 * cw
        scored.append((s, i, m))
    scored.sort(key=lambda x: (x[0], -x[1]), reverse=True)
    return [x[2] for x in scored]


def _detect_capability(task: str) -> Optional[str]:
    lower = task.lower()
    for cap, keywords in CAPABILITY_KEYWORDS.items():
        if any(kw in lower for kw in keywords):
            return cap
    return None


def _format_model(m: Dict[str, Any], rank: int) -> str:
    trend = m.get("trend", "unknown")
    score = m.get("score", 0.0)
    conf = m.get("confidence", "unknown")
    return f"  {rank}. {m.get('model', '?')} - trend: {trend}, score: {score:.2f}, confidence: {conf}"


class WzrdVelocityInput(BaseModel):
    task_description: str = Field(
        description="What the agent needs to accomplish (e.g. 'generate Python code', 'fast reasoning task')"
    )


class WzrdVelocityTool(BaseTool):
    """Query WZRD velocity signals to pick the best AI model for a task."""

    name: str = "wzrd_velocity"
    description: str = (
        "Get real-time AI model velocity rankings from the WZRD oracle. "
        "Input a task description and receive the top models with trend data "
        "and a recommendation. Use this before selecting which model to call."
    )
    args_schema: Type[BaseModel] = WzrdVelocityInput

    def _run(self, task_description: str) -> str:
        capability = _detect_capability(task_description)
        signal = _fetch(capability)
        if not signal:
            return "WZRD signal unavailable. Proceed with your default model."

        ranked = _rank(signal)
        if not ranked:
            return "No models in signal response. Proceed with your default model."

        top3 = ranked[:3]
        cap_label = f" (capability: {capability})" if capability else ""
        lines = [f"WZRD Velocity Signal{cap_label}", "Top models by momentum:"]
        for i, m in enumerate(top3, 1):
            lines.append(_format_model(m, i))

        best = top3[0]
        trend = best.get("trend", "stable")
        if trend in ("surging", "accelerating"):
            rec = f"Recommended: {best['model']} - momentum is {trend}."
        elif trend in ("decelerating", "cooling"):
            rec = f"Top-ranked is {best['model']} but momentum is {trend}. Consider #{2} if available."
        else:
            rec = f"Recommended: {best['model']} - momentum is stable."
        lines.append(rec)

        if signal.get("generated_at"):
            lines.append(f"Signal timestamp: {signal['generated_at']}")
        return "\n".join(lines)
