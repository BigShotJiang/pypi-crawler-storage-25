# crewai-wzrd

WZRD velocity signal tool for CrewAI. Gives agents real-time model momentum data for task-aware model selection.

Free tier. No auth required. Signals cached 60s.

## Install

```bash
pip install crewai-wzrd
```

## Usage

```python
from crewai import Agent, Task, Crew
from crewai_wzrd import WzrdVelocityTool

researcher = Agent(
    role="Model Selection Specialist",
    tools=[WzrdVelocityTool()],
    goal="Pick the best AI model for each task using real-time velocity data"
)

task = Task(
    description="Find the fastest model for code generation right now",
    agent=researcher,
    expected_output="Model name with supporting velocity data"
)

crew = Crew(agents=[researcher], tasks=[task])
result = crew.kickoff()
```

The tool auto-detects capability from the task description (code, reasoning, chat, vision) and filters signals accordingly.

## What it returns

```
WZRD Velocity Signal (capability: code)
Top models by momentum:
  1. deepseek/deepseek-coder-v2 - trend: surging, score: 0.87, confidence: normal
  2. anthropic/claude-3.5-sonnet - trend: accelerating, score: 0.82, confidence: normal
  3. openai/gpt-4o - trend: stable, score: 0.79, confidence: normal
Recommended: deepseek/deepseek-coder-v2 - momentum is surging.
Signal timestamp: 2026-04-02T12:00:00Z
```

## Links

- [WZRD Protocol](https://twzrd.xyz)
- [Signal API docs](https://api.twzrd.xyz/v1/signals/momentum)
