"""
Authentication module for Asana MCP server.

Generated: 2026-05-11 23:03:37 UTC
Generator: MCP Blacksmith v1.1.0 (https://mcpblacksmith.com)

This module contains:
1. Authentication class implementations (OAuth2)
2. Operation-to-auth requirements mapping (OPERATION_AUTH_MAP)
"""

from __future__ import annotations

import asyncio
import base64
import collections
import hashlib
import json
import logging
import os
import re
import ssl
import time
import webbrowser
from pathlib import Path
from urllib.parse import urlparse

from authlib.common.security import generate_token
from authlib.integrations.httpx_client import OAuth2Client

logger = logging.getLogger(__name__)

__all__ = [
    "OAuth2Auth",
    "BearerTokenAuth",
    "OPERATION_AUTH_MAP",
]

# ============================================================================
# Callback Port Configuration
# ============================================================================

# OAuth2/OIDC callback server ports (configured in .env)
# Each auth scheme uses a different port to avoid conflicts when multiple
# schemes are active simultaneously (e.g., OAuth2 + OIDC).
OAUTH2_CALLBACK_PORT = int(os.environ.get("OAUTH2_CALLBACK_PORT", 9400))

# ============================================================================
# Authentication Classes
# ============================================================================

class OAuth2Auth:
    """
    OAuth 2.0 authentication for Asana.

    Flow: authorizationCode
    Uses: authlib for OAuth2 protocol handling

    NOTE: Access tokens are obtained automatically through OAuth2 flow.
    By default they are sent as "Authorization: Bearer <token>", but some
    providers use a custom header instead.

    Configuration (environment variables):
        - OAUTH2_CLIENT_ID: OAuth2 client ID (required)
        - OAUTH2_CLIENT_SECRET: OAuth2 client secret (required)
        - OAUTH2_SCOPES: Comma-separated scopes (required)

    Redirect URI:
        - Default: http://localhost:<OAUTH2_CALLBACK_PORT>/callback
        - Configured via OAUTH2_CALLBACK_PORT in .env (default: 9400)        - Must match redirect URI in your OAuth application configuration
    Token Storage:
        Location: ./tokens/oauth2_tokens.json
        Permissions: 0o600 (owner read/write only)
        Format: JSON with access_token, refresh_token, expires_at

    URLs:
        Authorization URL: https://app.asana.com/-/oauth_authorize
        Token URL: https://app.asana.com/-/oauth_token
        Refresh URL: https://app.asana.com/-/oauth_token

    Available Scopes (configure via OAUTH2_SCOPES):
        - attachments:read
        - attachments:write
        - attachments:delete
        - custom_fields:read
        - custom_fields:write
        - goals:read
        - openid
        - email
        - profile
        - jobs:read
        - ooo_entries:read
        - ooo_entries:write
        - ooo_entries:delete
        - portfolios:read
        - portfolios:write
        - project_portfolio_settings:read
        - project_portfolio_settings:write
        - project_templates:read
        - projects:read
        - projects:write
        - projects:delete
        - roles:read
        - roles:write
        - roles:delete
        - stories:read
        - stories:write
        - tags:read
        - tags:write
        - task_custom_types:read
        - task_templates:read
        - tasks:read
        - tasks:write
        - tasks:delete
        - team_memberships:read
        - teams:read
        - time_tracking_categories:read
        - time_tracking_categories:write
        - time_tracking_categories:delete
        - time_tracking_entries:read
        - timesheet_approval_statuses:read
        - timesheet_approval_statuses:write
        - users:read
        - webhooks:read
        - webhooks:write
        - webhooks:delete
        - workspaces:read
        - workspaces.typeahead:read
        - default
    """

    def __init__(self):
        """Initialize OAuth2 authentication with authlib."""
        # Store flow type for lifecycle management
        self.flow_type = "authorizationCode"

        # Load configuration from environment
        self.client_id = os.getenv("OAUTH2_CLIENT_ID", "").strip()
        self.client_secret = os.getenv("OAUTH2_CLIENT_SECRET", "").strip()
        self.access_token_header_name = "Authorization"
        self.access_token_header_prefix = "Bearer" if self.access_token_header_name == "Authorization" else None

        # Validate required credentials
        if not self.client_id or not self.client_secret:
            raise ValueError(
                "OAUTH2_CLIENT_ID and OAUTH2_CLIENT_SECRET must be set. "
                "Leave empty in .env to disable OAuth2."
            )

        # Detect common placeholder patterns
        placeholders = ["placeholder", "your-", "example", "change-me", "todo"]
        if any(p in self.client_id.lower() for p in placeholders):
            raise ValueError(
                f"OAUTH2_CLIENT_ID appears to be a placeholder ({self.client_id[:20]}...). "
                "Please set real credentials or leave empty to disable OAuth2."
            )
        if any(p in self.client_secret.lower() for p in placeholders):
            raise ValueError(
                "OAUTH2_CLIENT_SECRET appears to be a placeholder. "
                "Please set real credentials or leave empty to disable OAuth2."
            )

        # Parse scopes from environment (required)
        scopes_env = os.getenv("OAUTH2_SCOPES", "").strip()
        self.scopes = [s.strip() for s in scopes_env.split(",") if s.strip()]
        self.extra_scope_params = {}
        # Redirect URI for authorization flows
        self.callback_port = int(os.getenv("OAUTH2_CALLBACK_PORT", "9400"))
        self.tls_cert_file = ""
        self.tls_key_file = ""
        self.redirect_uri = self._build_callback_redirect_uri()

        # OAuth2 token URL (required for all flows that fetch tokens)
        self.token_url = self._resolve_url_template("https://app.asana.com/-/oauth_token")
        self.auth_url = self._resolve_url_template("https://app.asana.com/-/oauth_authorize")
        self.refresh_url = self._resolve_url_template("https://app.asana.com/-/oauth_token")

        # Token storage (secure file-based, unique per scheme)
        self.token_dir = Path(__file__).parent / "tokens"
        self.token_file = self.token_dir / "oauth2_tokens.json"
        self.client: OAuth2Client | None = None
        self.token: dict | None = None
        self._auth_lock = asyncio.Lock()  # Prevents concurrent auth flows (dual browser tabs)

        # Load existing token if available
        self._load_token()

    def _load_token(self) -> None:
        """Load saved token from disk."""
        if self.token_file.exists():
            try:
                data = json.loads(self.token_file.read_text())
                if data.get("access_token"):
                    self.token = data
            except (json.JSONDecodeError, IOError):
                pass

    def _save_token(self, token: dict) -> None:
        """Save token to disk with restricted permissions."""
        normalized = dict(token)
        # Only set expires_at when expires_in is positive. A value of 0 (some
        # providers return this for non-expiring tokens) would otherwise mark
        # the token as immediately expired on every request.
        if "expires_at" not in normalized:
            expires_in = normalized.get("expires_in")
            if isinstance(expires_in, (int, float)) and expires_in > 0:
                normalized["expires_at"] = time.time() + int(expires_in)
        self.token_dir.mkdir(parents=True, exist_ok=True)
        self.token_file.write_text(json.dumps(normalized, indent=2))
        self.token_file.chmod(0o600)
        self.token = normalized

    def _create_client(self) -> OAuth2Client:
        """Create authlib OAuth2Client."""
        return OAuth2Client(
            client_id=self.client_id,
            client_secret=self.client_secret,
            token_endpoint_auth_method="client_secret_post",
        )

    def _resolve_url_template(self, url: str | None) -> str:
        """Resolve {server_var} placeholders from SERVER_* environment variables."""
        if not url or "{" not in url:
            return url or ""
        replacements: dict[str, str] = {}
        for var_name in re.findall(r"\{([^}]+)\}", url):
            env_var = "SERVER_" + re.sub(r"[^A-Za-z0-9_]", "_", var_name).upper()
            raw_value = os.getenv(env_var, "").strip()
            replacements[var_name] = self._resolve_template_host_value(url, var_name, env_var, raw_value)
        return url.format_map(collections.defaultdict(str, replacements))

    def _resolve_template_host_value(
        self,
        url: str,
        var_name: str,
        env_var: str,
        raw_value: str,
    ) -> str:
        """Normalize and validate env values used inside the URL host."""
        parsed_template = urlparse(url)
        template_host = parsed_template.hostname or parsed_template.netloc or ""
        token = "{" + var_name + "}"
        if not raw_value:
            if token in template_host:
                logger.warning(
                    "%s is blank; OAuth URL template %r still requires placeholder %s. "
                    "Authorization may fail until this server variable is configured.",
                    env_var,
                    url,
                    var_name,
                )
            return ""
        if token not in template_host:
            return raw_value

        prefix, _, suffix = template_host.partition(token)
        parsed_value = urlparse(raw_value)
        host = parsed_value.hostname or raw_value

        if host:
            host_matches = (not prefix or host.startswith(prefix)) and (not suffix or host.endswith(suffix))
            if host_matches:
                start = len(prefix)
                end = len(host) - len(suffix) if suffix else len(host)
                extracted = host[start:end].strip(".")
                if extracted:
                    return extracted

        looks_like_urlish_value = bool(
            parsed_value.scheme
            or parsed_value.netloc
            or parsed_value.path.strip("/") != raw_value.strip("/")
            or "/" in raw_value
            or "." in raw_value
        )
        if looks_like_urlish_value:
            raise ValueError(
                f"{env_var} must contain only the value for '{var_name}' in {url!r}, "
                f"not {raw_value!r}."
            )
        return raw_value

    def _build_callback_redirect_uri(self, port: int | None = None) -> str:
        """Build the local callback redirect URI."""
        default_scheme = "https" if False else "http"
        callback_port = port or self.callback_port
        default_port = 443 if default_scheme == "https" else 80
        netloc = "localhost" if callback_port == default_port else f"localhost:{callback_port}"
        return f"{default_scheme}://{netloc}/callback"

    def _build_callback_ssl_context(self, redirect_uri: str) -> ssl.SSLContext | None:
        """Create TLS context for HTTPS localhost callbacks when configured."""
        parsed = urlparse(redirect_uri)
        if parsed.scheme != "https":
            return None
        if not self.tls_cert_file:
            raise ValueError(
                "HTTPS OAuth2 redirect URI requires a TLS certificate file."
            )

        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        try:
            if self.tls_key_file:
                context.load_cert_chain(self.tls_cert_file, self.tls_key_file)
            else:
                context.load_cert_chain(self.tls_cert_file)
        except OSError as exc:
            raise ValueError(
                f"Failed to load OAuth2 callback TLS certificate for {redirect_uri}: {exc}"
            ) from exc
        return context

    def _is_token_expired(self) -> bool:
        """Check if current token is expired or about to expire."""
        if not self.token:
            return False  # Caller handles missing token separately
        expires_at = self.token.get("expires_at")
        if expires_at is None:
            return False  # No expiry info — assume valid
        return time.time() > (expires_at - 300)  # 5-minute buffer

    async def _refresh_token(self) -> bool:
        """Try to refresh the access token using the refresh token."""
        if not self.token or not self.token.get("refresh_token"):
            return False
        if not self.token_url:
            return False

        loop = asyncio.get_running_loop()
        refresh_token_val = self.token["refresh_token"]

        for auth_method in ("client_secret_post", "client_secret_basic"):
            try:
                client = OAuth2Client(
                    client_id=self.client_id,
                    client_secret=self.client_secret,
                    token_endpoint_auth_method=auth_method,
                )
                new_token = await loop.run_in_executor(
                    None,
                    lambda c=client: c.refresh_token(
                        self.token_url,
                        refresh_token=refresh_token_val,
                    ),
                )
                if new_token and new_token.get("access_token"):
                    self._save_token(dict(new_token))
                    return True
            except Exception as exc:
                err = str(exc).lower()
                if auth_method == "client_secret_post" and ("invalid_client" in err or "401" in err):
                    continue
                logger.debug("Token refresh failed (%s): %s", auth_method, exc)
                break
        return False

    async def authorize(self, port: int | None = None) -> dict:
        """
        Run OAuth2 authorization code flow with async local callback server.

        Starts an asyncio TCP server on localhost to receive the callback,
        opens the browser to the authorization URL, and waits for the user
        to authorize. Retries up to 5 adjacent ports if the primary port is in use.

        Args:
            port: Local callback server port (default: from OAUTH2_CALLBACK_PORT env or 9400)

        Returns:
            OAuth2 token dict with access_token, refresh_token, etc.

        Raises:
            ValueError: If authorization fails or is denied
            TimeoutError: If user doesn't complete authorization in 120 seconds
        """
        import errno
        import html as _html
        import urllib.parse

        redirect_template = self._build_callback_redirect_uri()
        parsed_redirect = urlparse(redirect_template)
        callback_host = parsed_redirect.hostname or "localhost"
        callback_path = parsed_redirect.path or "/callback"
        callback_ssl = self._build_callback_ssl_context(redirect_template)
        base_port = port or parsed_redirect.port or self.callback_port

        # PKCE
        code_verifier = generate_token(48)
        code_challenge = base64.urlsafe_b64encode(
            hashlib.sha256(code_verifier.encode()).digest()
        ).rstrip(b"=").decode()
        state = generate_token(30)

        callback_done: asyncio.Event = asyncio.Event()
        result: dict = {}

        async def _handle_connection(
            reader: asyncio.StreamReader, writer: asyncio.StreamWriter
        ) -> None:
            try:
                request_line = (await reader.readline()).decode(errors="replace").strip()
                while True:
                    line = await reader.readline()
                    if not line or line == b"\r\n":
                        break

                path = request_line.split(" ", 2)[1] if request_line.startswith("GET ") else ""
                parsed = urllib.parse.urlparse(path)
                params = urllib.parse.parse_qs(parsed.query)

                if parsed.path == callback_path and ("code" in params or "error" in params):
                    if "error" in params:
                        result["error"] = params["error"][0]
                        result["error_description"] = params.get("error_description", [""])[0]
                        status = "400 Bad Request"
                        title = "Authorization failed"
                        body = f"<p style='color:#ff8787'>{_html.escape(result.get('error_description') or result['error'])}</p>"
                    else:
                        cb_state = params.get("state", [None])[0]
                        if cb_state != state:
                            result["error"] = "state_mismatch"
                            result["error_description"] = "OAuth2 state parameter mismatch (possible CSRF)"
                            status = "400 Bad Request"
                            title = "Authorization failed"
                            body = "<p style='color:#ff8787'>State mismatch — possible CSRF attack.</p>"
                        else:
                            result["code"] = params["code"][0]
                            status = "200 OK"
                            title = "Authorization successful"
                            body = "<p>You can close this window.</p>"
                    callback_done.set()
                else:
                    status, title, body = "200 OK", "Please wait\u2026", ""

                html = (
                    "<!DOCTYPE html><html lang='en'><head><meta charset='UTF-8'>"
                    "<meta name='viewport' content='width=device-width,initial-scale=1'>"
                    f"<title>{title}</title>"
                    "<style>*{margin:0;padding:0;box-sizing:border-box}"
                    "body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;"
                    "background:#1a1a1a;color:#e8e8e8;display:flex;align-items:center;"
                    "justify-content:center;min-height:100vh}"
                    ".card{background:#242424;border:1px solid #333;border-radius:16px;"
                    "padding:48px 40px;text-align:center;max-width:420px;width:90%;"
                    "box-shadow:0 8px 32px rgba(0,0,0,.4)}"
                    ".logo{width:64px;height:64px;margin-bottom:32px;border-radius:12px}"
                    "h1{font-size:28px;font-weight:600;margin-bottom:10px}"
                    "p{font-size:15px;color:#888;line-height:1.5}"
                    ".footer{margin-top:32px;padding-top:20px;border-top:1px solid #333}"
                    ".footer a{color:#ff5722;text-decoration:none;font-size:13px}</style>"
                    "</head><body><div class='card'>"
                    "<img src='https://wjxawmrpsfuivlicnepc.supabase.co/storage/v1/object/public/newsletter/logo-blacksmith.png'"
                    " alt='MCP Blacksmith' class='logo'>"
                    f"<h1>{title}</h1>{body}"
                    "<div class='footer'><a href='https://mcpblacksmith.com'>mcpblacksmith.com</a></div>"
                    "</div></body></html>"
                )
                payload = html.encode()
                response = (
                    f"HTTP/1.1 {status}\r\n"
                    "Content-Type: text/html; charset=utf-8\r\n"
                    f"Content-Length: {len(payload)}\r\n"
                    "Connection: close\r\n\r\n"
                ).encode() + payload
                writer.write(response)
                await writer.drain()
            finally:
                writer.close()
                await writer.wait_closed()

        # Bind to port with retry on EADDRINUSE
        bound_port = base_port
        server = None
        for attempt in range(5):
            try:
                server = await asyncio.start_server(
                    _handle_connection,
                    callback_host,
                    base_port + attempt,
                    ssl=callback_ssl,
                )
                bound_port = base_port + attempt
                break
            except OSError as exc:
                if exc.errno != errno.EADDRINUSE or attempt == 4:
                    raise
        if server is None:
            raise OSError(f"Could not bind to any port in range {base_port}–{base_port + 4}")

        redirect_uri = self._build_callback_redirect_uri(port=bound_port)

        auth_params = {
            "response_type": "code",
            "client_id": self.client_id,
            "redirect_uri": redirect_uri,
            "scope": " ".join(self.scopes),
            "state": state,
            "code_challenge": code_challenge,
            "code_challenge_method": "S256",
        }
        for _param_name, _scopes in self.extra_scope_params.items():
            if _scopes:
                auth_params[_param_name] = " ".join(_scopes)
        auth_url = f"{self.auth_url}?{urllib.parse.urlencode(auth_params)}"

        async with server:
            logger.info("OAuth2 callback server listening on port %d", bound_port)
            print(f"\nAuthorize this application:\n\n  {auth_url}\n")
            webbrowser.open(auth_url)
            try:
                await asyncio.wait_for(callback_done.wait(), timeout=120)
            except asyncio.TimeoutError:
                raise TimeoutError(
                    "Authorization timed out (120s). "
                    "Please try again and complete authorization in the browser."
                )

        if "error" in result:
            raise ValueError(
                f"Authorization denied: {result['error']} — {result.get('error_description', '')}"
            )
        if "code" not in result:
            raise ValueError("Authorization failed: no code received after callback")

        # Token exchange with client_secret_post / client_secret_basic fallback
        loop = asyncio.get_running_loop()
        token = None
        last_exc: Exception | None = None

        for auth_method in ("client_secret_post", "client_secret_basic"):
            try:
                client = OAuth2Client(
                    client_id=self.client_id,
                    client_secret=self.client_secret,
                    token_endpoint_auth_method=auth_method,
                )
                token = await loop.run_in_executor(
                    None,
                    lambda c=client: c.fetch_token(
                        self.token_url,
                        code=result["code"],
                        redirect_uri=redirect_uri,
                        code_verifier=code_verifier,
                    ),
                )
                break
            except Exception as exc:
                last_exc = exc
                err = str(exc).lower()
                if auth_method == "client_secret_post" and ("invalid_client" in err or "401" in err):
                    continue
                raise

        if not token or not token.get("access_token"):
            raise ValueError(
                "Token exchange failed — no access_token received"
                + (f": {last_exc}" if last_exc else "")
            )

        # Scope validation — warn only, don't fail
        returned_scope = token.get("scope", "")
        if returned_scope:
            missing = set(self.scopes) - set(returned_scope.split())
            if missing:
                logger.warning(
                    "OAuth2 provider returned fewer scopes than requested. "
                    "Missing: %s. Some API operations may fail.",
                    ", ".join(sorted(missing)),
                )

        self._save_token(dict(token))
        return dict(token)

    async def get_auth_headers(self) -> dict:
        """
        Get authorization headers for API requests.

        Handles token lifecycle:
        1. If no token, trigger authorization flow
        2. If token expired, try refresh first
        3. If refresh fails, re-authorize

        Returns:
            Dict with authentication header for the provider
        """
        # Serialize auth flow — prevent duplicate browser tabs from concurrent calls
        async with self._auth_lock:
            # Re-check after acquiring lock (another call may have completed auth)
            if not self.token:
                await self.authorize()

            # Token expired — try refresh, then re-authorize
            # elif: skip expiry check if authorize() just ran above (prevents double browser tab)
            elif self._is_token_expired():
                if not await self._refresh_token():
                    await self.authorize()

        if not self.token or not self.token.get("access_token"):
            raise ValueError("Failed to obtain access token after authorization attempt")

        access_token = self.token["access_token"]
        if self.access_token_header_prefix:
            return {
                self.access_token_header_name: (
                    f"{self.access_token_header_prefix} {access_token}"
                )
            }
        return {self.access_token_header_name: access_token}

    def get_auth_params(self) -> dict:
        """OAuth2 uses headers, not query params."""
        return {}

class BearerTokenAuth:
    """
    Bearer token authentication for Asana.

    Configuration:
        Provide the raw token in the environment variable.
        The authorization scheme prefix is automatically inserted.
    """

    def __init__(self, env_var: str = "BEARER_TOKEN", token_format: str = "Bearer"):
        """Initialize bearer token authentication from environment variable.

        Args:
            env_var: Environment variable name containing the bearer token.
            token_format: Authorization scheme prefix (e.g., 'Bearer').
        """
        self.token_format = token_format
        self.token = os.getenv(env_var, "").strip()

        # Check for empty token
        if not self.token:
            raise ValueError(
                f"{env_var} environment variable not set. "
                "Leave empty in .env to disable Bearer Token auth."
            )

        # Detect common placeholder patterns
        placeholders = ["placeholder", "your-", "example", "change-me", "todo", "sk_test_placeholder"]
        token_lower = self.token.lower()

        if any(p in token_lower for p in placeholders):
            raise ValueError(
                f"Bearer token appears to be a placeholder ({self.token[:20]}...). "
                "Please set a real token or leave empty to disable Bearer Token auth."
            )

    def get_auth_headers(self) -> dict[str, str]:
        """Get authentication headers for API requests."""
        return {
            'Authorization': f'{self.token_format} {self.token}'
        }


# ============================================================================
# Operation Auth Requirements Map
# ============================================================================

"""
Operation-to-authentication requirements mapping.

This dictionary defines which authentication schemes are required for each operation,
using OR/AND relationships (outer list = OR, inner list = AND).
"""
OPERATION_AUTH_MAP: dict[str, list[list[str]]] = {
    "list_access_requests": [["oauth2"], ["personalAccessToken"]],
    "request_access": [["oauth2"], ["personalAccessToken"]],
    "approve_access_request": [["oauth2"], ["personalAccessToken"]],
    "reject_access_request": [["oauth2"], ["personalAccessToken"]],
    "get_allocation": [["oauth2"], ["personalAccessToken"]],
    "update_allocation": [["oauth2"], ["personalAccessToken"]],
    "delete_allocation": [["oauth2"], ["personalAccessToken"]],
    "list_allocations": [["oauth2"], ["personalAccessToken"]],
    "create_allocation": [["oauth2"], ["personalAccessToken"]],
    "get_attachment": [["oauth2"], ["personalAccessToken"]],
    "delete_attachment": [["oauth2"], ["personalAccessToken"]],
    "list_attachments": [["oauth2"], ["personalAccessToken"]],
    "upload_attachment": [["oauth2"], ["personalAccessToken"]],
    "list_audit_log_events": [["oauth2"], ["personalAccessToken"]],
    "list_budgets": [["oauth2"], ["personalAccessToken"]],
    "create_budget": [["oauth2"], ["personalAccessToken"]],
    "get_budget": [["oauth2"], ["personalAccessToken"]],
    "update_budget": [["oauth2"], ["personalAccessToken"]],
    "delete_budget": [["oauth2"], ["personalAccessToken"]],
    "list_project_custom_field_settings": [["oauth2"], ["personalAccessToken"]],
    "list_portfolio_custom_field_settings": [["oauth2"], ["personalAccessToken"]],
    "list_goal_custom_field_settings": [["oauth2"], ["personalAccessToken"]],
    "list_team_custom_field_settings": [["oauth2"], ["personalAccessToken"]],
    "create_custom_field": [["oauth2"], ["personalAccessToken"]],
    "get_custom_field": [["oauth2"], ["personalAccessToken"]],
    "update_custom_field": [["oauth2"], ["personalAccessToken"]],
    "delete_custom_field": [["oauth2"], ["personalAccessToken"]],
    "list_workspace_custom_fields": [["oauth2"], ["personalAccessToken"]],
    "create_enum_option": [["oauth2"], ["personalAccessToken"]],
    "reorder_enum_option": [["oauth2"], ["personalAccessToken"]],
    "update_enum_option": [["oauth2"], ["personalAccessToken"]],
    "list_custom_types": [["oauth2"], ["personalAccessToken"]],
    "get_custom_type": [["oauth2"], ["personalAccessToken"]],
    "list_resource_events": [["oauth2"], ["personalAccessToken"]],
    "export_graph": [["oauth2"], ["personalAccessToken"]],
    "create_resource_export": [["oauth2"], ["personalAccessToken"]],
    "get_goal_relationship": [["oauth2"], ["personalAccessToken"]],
    "update_goal_relationship": [["oauth2"], ["personalAccessToken"]],
    "list_goal_relationships": [["oauth2"], ["personalAccessToken"]],
    "add_goal_supporting_relationship": [["oauth2"], ["personalAccessToken"]],
    "remove_goal_supporting_relationship": [["oauth2"], ["personalAccessToken"]],
    "get_goal": [["oauth2"], ["personalAccessToken"]],
    "update_goal": [["oauth2"], ["personalAccessToken"]],
    "delete_goal": [["oauth2"], ["personalAccessToken"]],
    "list_goals": [["oauth2"], ["personalAccessToken"]],
    "create_goal": [["oauth2"], ["personalAccessToken"]],
    "set_goal_metric": [["oauth2"], ["personalAccessToken"]],
    "update_goal_metric_value": [["oauth2"], ["personalAccessToken"]],
    "add_goal_followers": [["oauth2"], ["personalAccessToken"]],
    "remove_goal_followers": [["oauth2"], ["personalAccessToken"]],
    "list_parent_goals": [["oauth2"], ["personalAccessToken"]],
    "add_custom_field_to_goal": [["oauth2"], ["personalAccessToken"]],
    "remove_custom_field_from_goal": [["oauth2"], ["personalAccessToken"]],
    "get_job": [["oauth2"], ["personalAccessToken"]],
    "list_memberships": [["oauth2"], ["personalAccessToken"]],
    "create_membership": [["oauth2"], ["personalAccessToken"]],
    "get_membership": [["oauth2"], ["personalAccessToken"]],
    "update_membership": [["oauth2"], ["personalAccessToken"]],
    "delete_membership": [["oauth2"], ["personalAccessToken"]],
    "create_organization_export": [["oauth2"], ["personalAccessToken"]],
    "get_organization_export": [["oauth2"], ["personalAccessToken"]],
    "list_portfolio_memberships": [["oauth2"], ["personalAccessToken"]],
    "get_portfolio_membership": [["oauth2"], ["personalAccessToken"]],
    "list_portfolio_memberships_for_portfolio": [["oauth2"], ["personalAccessToken"]],
    "list_portfolios": [["oauth2"], ["personalAccessToken"]],
    "create_portfolio": [["oauth2"], ["personalAccessToken"]],
    "get_portfolio": [["oauth2"], ["personalAccessToken"]],
    "update_portfolio": [["oauth2"], ["personalAccessToken"]],
    "delete_portfolio": [["oauth2"], ["personalAccessToken"]],
    "list_portfolio_items": [["oauth2"], ["personalAccessToken"]],
    "add_portfolio_item": [["oauth2"], ["personalAccessToken"]],
    "remove_portfolio_item": [["oauth2"], ["personalAccessToken"]],
    "add_custom_field_to_portfolio": [["oauth2"], ["personalAccessToken"]],
    "remove_portfolio_custom_field": [["oauth2"], ["personalAccessToken"]],
    "add_portfolio_members": [["oauth2"], ["personalAccessToken"]],
    "remove_portfolio_members": [["oauth2"], ["personalAccessToken"]],
    "duplicate_portfolio": [["oauth2"], ["personalAccessToken"]],
    "get_project_brief": [["oauth2"], ["personalAccessToken"]],
    "update_project_brief": [["oauth2"], ["personalAccessToken"]],
    "delete_project_brief": [["oauth2"], ["personalAccessToken"]],
    "create_project_brief": [["oauth2"], ["personalAccessToken"]],
    "get_project_membership": [["oauth2"], ["personalAccessToken"]],
    "list_project_memberships": [["oauth2"], ["personalAccessToken"]],
    "get_project_portfolio_setting": [["oauth2"], ["personalAccessToken"]],
    "update_project_portfolio_setting": [["oauth2"], ["personalAccessToken"]],
    "list_project_portfolio_settings": [["oauth2"], ["personalAccessToken"]],
    "get_project_status": [["oauth2"], ["personalAccessToken"]],
    "delete_project_status": [["oauth2"], ["personalAccessToken"]],
    "list_project_statuses": [["oauth2"], ["personalAccessToken"]],
    "create_project_status": [["oauth2"], ["personalAccessToken"]],
    "get_project_template": [["oauth2"], ["personalAccessToken"]],
    "delete_project_template": [["oauth2"], ["personalAccessToken"]],
    "list_project_templates": [["oauth2"], ["personalAccessToken"]],
    "list_team_project_templates": [["oauth2"], ["personalAccessToken"]],
    "create_project_from_template": [["oauth2"], ["personalAccessToken"]],
    "list_projects": [["oauth2"], ["personalAccessToken"]],
    "create_project": [["oauth2"], ["personalAccessToken"]],
    "get_project": [["oauth2"], ["personalAccessToken"]],
    "update_project": [["oauth2"], ["personalAccessToken"]],
    "delete_project": [["oauth2"], ["personalAccessToken"]],
    "duplicate_project": [["oauth2"], ["personalAccessToken"]],
    "list_task_projects": [["oauth2"], ["personalAccessToken"]],
    "create_team_project": [["oauth2"], ["personalAccessToken"]],
    "list_workspace_projects": [["oauth2"], ["personalAccessToken"]],
    "create_project_in_workspace": [["oauth2"], ["personalAccessToken"]],
    "search_projects": [["oauth2"], ["personalAccessToken"]],
    "add_custom_field_to_project": [["oauth2"], ["personalAccessToken"]],
    "remove_custom_field_from_project": [["oauth2"], ["personalAccessToken"]],
    "get_project_task_counts": [["oauth2"], ["personalAccessToken"]],
    "add_project_members": [["oauth2"], ["personalAccessToken"]],
    "remove_project_members": [["oauth2"], ["personalAccessToken"]],
    "add_project_followers": [["oauth2"], ["personalAccessToken"]],
    "remove_project_followers": [["oauth2"], ["personalAccessToken"]],
    "save_project_as_template": [["oauth2"], ["personalAccessToken"]],
    "list_rates": [["oauth2"], ["personalAccessToken"]],
    "create_rate": [["oauth2"], ["personalAccessToken"]],
    "get_rate": [["oauth2"], ["personalAccessToken"]],
    "update_rate": [["oauth2"], ["personalAccessToken"]],
    "delete_rate": [["oauth2"], ["personalAccessToken"]],
    "list_reactions": [["oauth2"], ["personalAccessToken"]],
    "get_section": [["oauth2"], ["personalAccessToken"]],
    "update_section": [["oauth2"], ["personalAccessToken"]],
    "delete_section": [["oauth2"], ["personalAccessToken"]],
    "list_project_sections": [["oauth2"], ["personalAccessToken"]],
    "create_section": [["oauth2"], ["personalAccessToken"]],
    "add_task_to_section": [["oauth2"], ["personalAccessToken"]],
    "reorder_section": [["oauth2"], ["personalAccessToken"]],
    "get_status_update": [["oauth2"], ["personalAccessToken"]],
    "delete_status_update": [["oauth2"], ["personalAccessToken"]],
    "list_status_updates": [["oauth2"], ["personalAccessToken"]],
    "create_status_update": [["oauth2"], ["personalAccessToken"]],
    "get_story": [["oauth2"], ["personalAccessToken"]],
    "update_story": [["oauth2"], ["personalAccessToken"]],
    "delete_story": [["oauth2"], ["personalAccessToken"]],
    "list_task_stories": [["oauth2"], ["personalAccessToken"]],
    "add_task_comment": [["oauth2"], ["personalAccessToken"]],
    "list_tags": [["oauth2"], ["personalAccessToken"]],
    "create_tag": [["oauth2"], ["personalAccessToken"]],
    "get_tag": [["oauth2"], ["personalAccessToken"]],
    "update_tag": [["oauth2"], ["personalAccessToken"]],
    "delete_tag": [["oauth2"], ["personalAccessToken"]],
    "list_task_tags": [["oauth2"], ["personalAccessToken"]],
    "list_workspace_tags": [["oauth2"], ["personalAccessToken"]],
    "create_tag_in_workspace": [["oauth2"], ["personalAccessToken"]],
    "list_task_templates": [["oauth2"], ["personalAccessToken"]],
    "get_task_template": [["oauth2"], ["personalAccessToken"]],
    "delete_task_template": [["oauth2"], ["personalAccessToken"]],
    "instantiate_task_from_template": [["oauth2"], ["personalAccessToken"]],
    "list_tasks": [["oauth2"], ["personalAccessToken"]],
    "create_task": [["oauth2"], ["personalAccessToken"]],
    "get_task": [["oauth2"], ["personalAccessToken"]],
    "update_task": [["oauth2"], ["personalAccessToken"]],
    "delete_task": [["oauth2"], ["personalAccessToken"]],
    "duplicate_task": [["oauth2"], ["personalAccessToken"]],
    "list_project_tasks": [["oauth2"], ["personalAccessToken"]],
    "list_section_tasks": [["oauth2"], ["personalAccessToken"]],
    "list_tasks_by_tag": [["oauth2"], ["personalAccessToken"]],
    "list_user_task_list_tasks": [["oauth2"], ["personalAccessToken"]],
    "list_subtasks": [["oauth2"], ["personalAccessToken"]],
    "create_subtask": [["oauth2"], ["personalAccessToken"]],
    "set_task_parent": [["oauth2"], ["personalAccessToken"]],
    "list_task_dependencies": [["oauth2"], ["personalAccessToken"]],
    "add_task_dependencies": [["oauth2"], ["personalAccessToken"]],
    "remove_task_dependencies": [["oauth2"], ["personalAccessToken"]],
    "list_task_dependents": [["oauth2"], ["personalAccessToken"]],
    "add_task_dependents": [["oauth2"], ["personalAccessToken"]],
    "remove_task_dependents": [["oauth2"], ["personalAccessToken"]],
    "add_task_to_project": [["oauth2"], ["personalAccessToken"]],
    "remove_task_from_project": [["oauth2"], ["personalAccessToken"]],
    "add_task_tag": [["oauth2"], ["personalAccessToken"]],
    "remove_task_tag": [["oauth2"], ["personalAccessToken"]],
    "add_task_followers": [["oauth2"], ["personalAccessToken"]],
    "remove_task_followers": [["oauth2"], ["personalAccessToken"]],
    "get_task_by_custom_id": [["oauth2"], ["personalAccessToken"]],
    "search_tasks": [["oauth2"], ["personalAccessToken"]],
    "get_team_membership": [["oauth2"], ["personalAccessToken"]],
    "list_team_memberships": [["oauth2"], ["personalAccessToken"]],
    "list_team_memberships_for_team": [["oauth2"], ["personalAccessToken"]],
    "list_user_team_memberships": [["oauth2"], ["personalAccessToken"]],
    "create_team": [["oauth2"], ["personalAccessToken"]],
    "get_team": [["oauth2"], ["personalAccessToken"]],
    "update_team": [["oauth2"], ["personalAccessToken"]],
    "list_workspace_teams": [["oauth2"], ["personalAccessToken"]],
    "list_user_teams": [["oauth2"], ["personalAccessToken"]],
    "add_team_member": [["oauth2"], ["personalAccessToken"]],
    "remove_team_member": [["oauth2"], ["personalAccessToken"]],
    "get_time_period": [["oauth2"], ["personalAccessToken"]],
    "list_time_periods": [["oauth2"], ["personalAccessToken"]],
    "list_task_time_tracking_entries": [["oauth2"], ["personalAccessToken"]],
    "create_time_entry": [["oauth2"], ["personalAccessToken"]],
    "get_time_tracking_entry": [["oauth2"], ["personalAccessToken"]],
    "update_time_tracking_entry": [["oauth2"], ["personalAccessToken"]],
    "delete_time_tracking_entry": [["oauth2"], ["personalAccessToken"]],
    "list_time_tracking_entries": [["oauth2"], ["personalAccessToken"]],
    "get_timesheet_approval_status": [["oauth2"], ["personalAccessToken"]],
    "update_timesheet_approval_status": [["oauth2"], ["personalAccessToken"]],
    "list_timesheet_approval_statuses": [["oauth2"], ["personalAccessToken"]],
    "create_timesheet_approval_status": [["oauth2"], ["personalAccessToken"]],
    "search_workspace_typeahead": [["oauth2"], ["personalAccessToken"]],
    "get_user_task_list": [["oauth2"], ["personalAccessToken"]],
    "get_user_task_list_by_user": [["oauth2"], ["personalAccessToken"]],
    "list_users": [["oauth2"], ["personalAccessToken"]],
    "get_user": [["oauth2"], ["personalAccessToken"]],
    "update_user": [["oauth2"], ["personalAccessToken"]],
    "list_user_favorites": [["oauth2"], ["personalAccessToken"]],
    "list_team_members": [["oauth2"], ["personalAccessToken"]],
    "list_workspace_users": [["oauth2"], ["personalAccessToken"]],
    "get_workspace_user": [["oauth2"], ["personalAccessToken"]],
    "update_workspace_user": [["oauth2"], ["personalAccessToken"]],
    "get_webhook": [["oauth2"], ["personalAccessToken"]],
    "delete_webhook": [["oauth2"], ["personalAccessToken"]],
    "get_workspace_membership": [["oauth2"], ["personalAccessToken"]],
    "list_user_workspace_memberships": [["oauth2"], ["personalAccessToken"]],
    "list_workspace_memberships": [["oauth2"], ["personalAccessToken"]],
    "list_workspaces": [["oauth2"], ["personalAccessToken"]],
    "get_workspace": [["oauth2"], ["personalAccessToken"]],
    "update_workspace": [["oauth2"], ["personalAccessToken"]],
    "add_workspace_user": [["oauth2"], ["personalAccessToken"]],
    "remove_workspace_user": [["oauth2"], ["personalAccessToken"]],
    "list_workspace_events": [["oauth2"], ["personalAccessToken"]]
}
