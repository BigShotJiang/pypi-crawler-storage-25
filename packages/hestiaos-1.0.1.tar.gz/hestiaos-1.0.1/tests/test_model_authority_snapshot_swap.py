import pytest
import yaml
import time
import os
from pathlib import Path
from core.model_authority import ModelAuthority
from core.invariants.ir import CanonIR

@pytest.fixture
def temp_canon():
    """Erstellt eine temporäre canon.yaml für den Test."""
    path = Path("core/invariants/test_canon.yaml")
    original_path = ModelAuthority._config_path
    
    # Backup und Path-Swap
    ModelAuthority._config_path = path
    
    initial_data = {
        "version": "1.0",
        "model_authority": {
            "roles": {
                "mediator": "test-mediator-v1",
                "thinking": "test-thinking-v1",
                "expert": "test-expert-v1",
                "primary": "test-primary-v1"
            }
        }
    }
    
    with open(path, 'w') as f:
        yaml.dump(initial_data, f)
    
    yield path
    
    # Cleanup
    if path.exists():
        os.remove(path)
    ModelAuthority._config_path = original_path

def test_atomic_snapshot_swap(temp_canon):
    """
    Beweist: Atomicity, Visibility Consistency und No Partial State Exposure.
    """
    authority = ModelAuthority()
    authority.reload() # Initialer Load
    
    s1 = authority.snapshot
    assert isinstance(s1, CanonIR)
    assert s1.model_roles["mediator"] == "test-mediator-v1"
    
    # 1. ÄNDERUNG VORBEREITEN
    new_data = {
        "version": "2.0",
        "model_authority": {
            "roles": {
                "mediator": "test-mediator-v2",
                "thinking": "test-thinking-v2",
                "expert": "test-expert-v2",
                "primary": "test-primary-v2"
            }
        }
    }
    
    with open(temp_canon, 'w') as f:
        yaml.dump(new_data, f)
        
    # 2. RELOAD (Atomarer Swap)
    authority.reload()
    s2 = authority.snapshot
    
    # ASSERTION: Identität hat sich geändert
    assert s2.get_snapshot_id() != s1.get_snapshot_id()
    assert s2.digest != s1.digest
    assert s2.version == "2.0"
    
    # 3. VERIFIKATION: Keine Teilzustände (Visibility Consistency)
    # Wir prüfen 1000x schnell hintereinander, ob wir jemals einen Mix sehen
    for _ in range(1000):
        current = authority.snapshot
        # Entweder wir sehen v2 (nach Swap) oder v1 (wenn wir davor wären)
        # In diesem synchronen Test sehen wir nach reload() NUR v2.
        assert current.model_roles["mediator"] == "test-mediator-v2"
        assert current.get_snapshot_id() == s2.get_snapshot_id()

def test_resilience_on_corrupted_yaml(temp_canon):
    """
    Beweist: System bleibt stabil bei korrupter YAML (Fallback-Snapshot).
    """
    authority = ModelAuthority()
    authority.reload()
    s_valid = authority.snapshot
    
    # YAML korrumpieren (ungültiges Format)
    with open(temp_canon, 'w') as f:
        f.write("model_authority: { roles: [ kaputt") 
        
    # Reload sollte nicht crashen, sondern auf Fallback swappen oder alten behalten
    # In unserer aktuellen Implementierung (ModelAuthority._load_registry) 
    # wird bei Exception ein Fallback erzeugt.
    authority.reload()
    s_fallback = authority.snapshot
    
    assert s_fallback.get_snapshot_id() != s_valid.get_snapshot_id()
    assert s_fallback.version == "fallback"
    assert "primary" in s_fallback.model_roles

def test_determinism_hash_consistency(temp_canon):
    """
    Beweist: Gleicher Inhalt erzeugt gleichen Digest.
    """
    authority = ModelAuthority()
    
    # Erster Durchgang
    authority.reload()
    d1 = authority.snapshot.digest
    
    # Zweiter Durchgang (Inhalt identisch)
    authority.reload()
    d2 = authority.snapshot.digest
    
    assert d1 == d2
