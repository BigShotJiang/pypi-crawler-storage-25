"""
INV-G3-CAT: Causal Attribution Test (Explainability)
Verifiziert die Zerlegung der Governance-Entscheidungen in G2 und G3 Anteile.
"""

import pytest
from core.governance.causal_kernel import CausalImpactReport
from core.governance.dsgk_decision import build_decision
from core.bootstrap.control_plane import CanonicalState, SystemCondition, SystemSignals
from core.bootstrap.models import BootState
from core.bootstrap.arbitrator import SystemArbitrator, ArbitrationResult
from core.processing.network_error_classifier import CircuitState

def test_causal_attribution_decomposition():
    """Prüft ob der Performance-Verlust korrekt attribuiert wird."""
    arb = SystemArbitrator(g3_active=True)
    decision = build_decision(violations=[], policy="core.test.v1")
    signals = SystemSignals(boot_state=BootState.READY, db_ready=True, migrations_ok=True)
    state = CanonicalState(condition=SystemCondition.GREEN, priority_vector=[0,0,0,0,0], signals=signals)
    
    # 0.4 Risk -> Damping Penalty = 0.4 * 0.4 = 0.16
    report = CausalImpactReport(risk_projection=0.4, confidence=1.0)
    
    outcome = arb.arbitrate(
        dsgk=decision,
        control_state=state,
        circuit_state=CircuitState.CLOSED,
        drift_vector=None,
        causal_report=report
    )
    
    # Check Attribution Dictionary
    attr = outcome.attribution
    assert attr["base_policy_factor"] == 1.0
    assert attr["causal_damping_penalty"] == pytest.approx(0.16)
    assert attr["risk_projection"] == 0.4
    assert "causal_hard_penalty" not in attr
    
    # Verifikation der mathematischen Kopplung
    # 1.0 * (1.0 - 0.16) = 0.84
    assert outcome.performance_factor == pytest.approx(0.84)

def test_causal_attribution_hard_override():
    """Prüft die Attribution bei einem Hard Override (G3.2)."""
    arb = SystemArbitrator(g3_active=True)
    decision = build_decision(violations=[], policy="core.test.v1")
    signals = SystemSignals(boot_state=BootState.READY, db_ready=True, migrations_ok=True)
    state = CanonicalState(condition=SystemCondition.GREEN, priority_vector=[0,0,0,0,0], signals=signals)
    
    # 0.6 Risk -> Hard Override Threshold (0.5)
    # Damping Penalty = 0.6 * 0.4 = 0.24
    report = CausalImpactReport(risk_projection=0.6, confidence=1.0)
    
    outcome = arb.arbitrate(
        dsgk=decision,
        control_state=state,
        causal_report=report
    )
    
    attr = outcome.attribution
    assert outcome.result == ArbitrationResult.THROTTLE
    assert attr["causal_hard_penalty"] == 0.5
    assert attr["causal_damping_penalty"] == pytest.approx(0.24)
    
    # PF = 1.0 * (1.0 - 0.24) = 0.76
    assert outcome.performance_factor == pytest.approx(0.76)

def test_attribution_explainability_message():
    """Prüft ob die Attribution für den User/Operator sichtbar ist."""
    # Aktuell via Dictionary, später via Message-Formatierung
    arb = SystemArbitrator(g3_active=True)
    decision = build_decision(violations=[], policy="core.test.v1")
    report = CausalImpactReport(risk_projection=0.8, confidence=1.0)
    
    signals = SystemSignals(boot_state=BootState.READY, db_ready=True, migrations_ok=True)
    state = CanonicalState(condition=SystemCondition.GREEN, priority_vector=[0,0,0,0,0], signals=signals)
    outcome = arb.arbitrate(dsgk=decision, control_state=state, causal_report=report)
    
    assert outcome.causal_report is not None
    assert "Risk Projection 0.80" in outcome.message
    assert outcome.attribution["risk_projection"] == 0.8
