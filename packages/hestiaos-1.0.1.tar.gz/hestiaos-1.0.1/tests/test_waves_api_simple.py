# tests/test_waves_api_simple.py
import pytest
from fastapi.testclient import TestClient
from fastapi import FastAPI
from api.routers.waves import router

# Create a minimal app for testing
app = FastAPI()
app.include_router(router)

client = TestClient(app)


def test_create_wave_missing_tenant_header():
    """Test that missing X-Tenant-Id header returns 400."""
    response = client.post("/api/waves", json={
        "request_id": "test123"
    })
    assert response.status_code == 400
    assert "X-Tenant-Id header is required" in response.json()["detail"]


def test_create_wave_success():
    """Test successful wave creation."""
    response = client.post(
        "/api/waves",
        json={
            "request_id": "test-request-1",
            "created_by_hint": "test-user"
        },
        headers={"X-Tenant-Id": "tenant-a"}
    )
    assert response.status_code == 200
    data = response.json()
    assert data["tenant_id"] == "tenant-a"
    assert data["request_id"] == "test-request-1"
    assert data["created_by"] == "test-user"  # Uses created_by_hint
    assert data["state"] == "CREATED"
    assert data["is_immutable"] is False
    wave_id = data["wave_id"]
    assert isinstance(wave_id, str) and len(wave_id) > 0


def test_create_wave_without_hint():
    """Test wave creation without created_by_hint uses default."""
    response = client.post(
        "/api/waves",
        json={},
        headers={"X-Tenant-Id": "tenant-b"}
    )
    assert response.status_code == 200
    data = response.json()
    assert data["tenant_id"] == "tenant-b"
    # Default from get_created_by dependency
    assert "user@" in data["created_by"]
    assert data["request_id"] is None


def test_get_wave_success():
    """Test retrieving a wave."""
    # First create a wave
    create_response = client.post(
        "/api/waves",
        json={"request_id": "get-test"},
        headers={"X-Tenant-Id": "tenant-c"}
    )
    wave_id = create_response.json()["wave_id"]
    
    # Then get it
    response = client.get(
        f"/api/waves/{wave_id}",
        headers={"X-Tenant-Id": "tenant-c"}
    )
    assert response.status_code == 200
    data = response.json()
    assert data["wave_id"] == wave_id
    assert data["tenant_id"] == "tenant-c"
    assert data["request_id"] == "get-test"


def test_get_wave_wrong_tenant():
    """Test that getting a wave with wrong tenant returns 404."""
    # Create wave in tenant-a
    create_response = client.post(
        "/api/waves",
        json={},
        headers={"X-Tenant-Id": "tenant-a"}
    )
    wave_id = create_response.json()["wave_id"]
    
    # Try to get with tenant-b
    response = client.get(
        f"/api/waves/{wave_id}",
        headers={"X-Tenant-Id": "tenant-b"}
    )
    assert response.status_code == 404
    assert "Wave not found" in response.json()["detail"]


def test_get_wave_nonexistent():
    """Test getting a non-existent wave."""
    response = client.get(
        "/api/waves/nonexistent-id",
        headers={"X-Tenant-Id": "tenant-a"}
    )
    assert response.status_code == 404


def test_get_wave_missing_tenant_header():
    """Test getting a wave without tenant header."""
    response = client.get("/api/waves/some-id")
    assert response.status_code == 400


def test_list_waves_tenant_isolation():
    """Test that list only returns waves for the requesting tenant."""
    # Create waves in tenant-a
    for i in range(2):
        client.post(
            "/api/waves",
            json={"request_id": f"tenant-a-{i}"},
            headers={"X-Tenant-Id": "tenant-a"}
        )
    
    # Create wave in tenant-b
    client.post(
        "/api/waves",
        json={"request_id": "tenant-b-0"},
        headers={"X-Tenant-Id": "tenant-b"}
    )
    
    # List waves for tenant-a
    response = client.get(
        "/api/waves",
        headers={"X-Tenant-Id": "tenant-a"}
    )
    assert response.status_code == 200
    data = response.json()
    assert len(data["waves"]) == 2
    for wave in data["waves"]:
        assert wave["tenant_id"] == "tenant-a"
        assert "tenant-a-" in wave["request_id"]
    
    # List waves for tenant-b
    response = client.get(
        "/api/waves",
        headers={"X-Tenant-Id": "tenant-b"}
    )
    assert response.status_code == 200
    data = response.json()
    assert len(data["waves"]) == 1
    assert data["waves"][0]["tenant_id"] == "tenant-b"
    assert data["waves"][0]["request_id"] == "tenant-b-0"


def test_list_waves_empty():
    """Test listing waves for a tenant with no waves."""
    response = client.get(
        "/api/waves",
        headers={"X-Tenant-Id": "empty-tenant"}
    )
    assert response.status_code == 200
    data = response.json()
    assert data["waves"] == []


def test_list_waves_missing_tenant_header():
    """Test listing waves without tenant header."""
    response = client.get("/api/waves")
    assert response.status_code == 400