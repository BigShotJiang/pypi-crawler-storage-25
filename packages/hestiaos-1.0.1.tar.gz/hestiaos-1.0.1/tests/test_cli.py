"""
CLI-Tests für HestiaOS — Typer CliRunner + gemockter Client.

Testet:
- --help für alle Commands
- run-Command (mit/ohne GovernanceBlock)
- trace-Command (gefunden/nicht gefunden)
- health-Command
- --json Output
- Exit-Codes
"""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from hestiaos.cli import app

runner = CliRunner()


# ── Fixtures ──────────────────────────────────────────────────────────────

@pytest.fixture
def mock_client() -> MagicMock:
    """Erzeugt einen gemockten Client mit allen nötigen Return-Werten."""
    client = MagicMock()

    # client.run() — RunResponse-ähnliches Objekt
    run_result = MagicMock()
    run_result.result = "processed: hello"
    run_result.trace_id = "trace-123"
    run_result.output = "Hello, world!"
    run_result.mode = "ALLOW"
    run_result.budget = 0.8
    run_result.latency_ms = 42.0
    client.run.return_value = run_result

    # client.governance.trace() — gibt ein echtes dict zurück (wie das echte SDK)
    client.governance.trace.return_value = {
        "trace_id": "trace-abc",
        "decision": "ALLOW",
        "latency_ms": 12.3,
    }

    # client.system.status() — SystemStatus-ähnliches Objekt
    status_result = MagicMock()
    status_result.status = "healthy"
    status_result.version = "0.1.0"
    status_result.uptime_seconds = 3600.0
    client.system.status.return_value = status_result

    return client


# ── Tests: --help ─────────────────────────────────────────────────────────

class TestCliHelp:
    """Testet die --help Ausgabe für alle Commands."""

    def test_main_help(self) -> None:
        """hestiaos --help zeigt alle Commands und globalen Optionen."""
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0
        assert "HestiaOS CLI" in result.stdout
        assert "run" in result.stdout
        assert "trace" in result.stdout
        assert "health" in result.stdout
        assert "--base-url" in result.stdout
        assert "--api-key" in result.stdout
        assert "--json" in result.stdout

    def test_run_help(self) -> None:
        """hestiaos run --help zeigt Argumente."""
        result = runner.invoke(app, ["run", "--help"])
        assert result.exit_code == 0
        assert "INPUT_TEXT" in result.stdout

    def test_trace_help(self) -> None:
        """hestiaos trace --help zeigt Argumente."""
        result = runner.invoke(app, ["trace", "--help"])
        assert result.exit_code == 0
        assert "TRACE_ID" in result.stdout

    def test_health_help(self) -> None:
        """hestiaos health --help zeigt Optionen."""
        result = runner.invoke(app, ["health", "--help"])
        assert result.exit_code == 0


# ── Tests: run ────────────────────────────────────────────────────────────

class TestCliRun:
    """Testet den run-Command."""

    def test_run_success(self, mock_client: MagicMock) -> None:
        """run-Command gibt alle Felder aus."""
        with patch("hestiaos.cli.Client", return_value=mock_client):
            result = runner.invoke(app, ["run", "hello"])

        assert result.exit_code == 0
        assert "result: processed: hello" in result.stdout
        assert "trace_id: trace-123" in result.stdout
        assert "output: Hello, world!" in result.stdout
        assert "mode: ALLOW" in result.stdout
        assert "budget: 0.8" in result.stdout
        assert "latency_ms: 42.0" in result.stdout

    def test_run_json_output(self, mock_client: MagicMock) -> None:
        """--json gibt JSON aus."""
        with patch("hestiaos.cli.Client", return_value=mock_client):
            result = runner.invoke(app, ["--json", "run", "hello"])

        assert result.exit_code == 0
        import json
        data = json.loads(result.stdout)
        assert data["result"] == "processed: hello"
        assert data["trace_id"] == "trace-123"
        assert data["mode"] == "ALLOW"
        assert data["latency_ms"] == 42.0

    def test_run_governance_block(self, mock_client: MagicMock) -> None:
        """GovernanceBlock → Exit-Code 1 + Fehlermeldung auf stderr."""
        from hestiaos import GovernanceBlock

        mock_client.run.side_effect = GovernanceBlock("Blocked by policy")
        with patch("hestiaos.cli.Client", return_value=mock_client):
            result = runner.invoke(app, ["run", "dangerous"])

        assert result.exit_code == 1
        assert "GOVERNANCE_BLOCK" in result.stderr

    def test_run_missing_argument(self) -> None:
        """Fehlendes input_text → Exit-Code 2 (Typer-Usage-Error)."""
        result = runner.invoke(app, ["run"])
        assert result.exit_code == 2


# ── Tests: trace ──────────────────────────────────────────────────────────

class TestCliTrace:
    """Testet den trace-Command."""

    def test_trace_found(self, mock_client: MagicMock) -> None:
        """Vorhandener Trace gibt Daten aus."""
        with patch("hestiaos.cli.Client", return_value=mock_client):
            result = runner.invoke(app, ["trace", "trace-abc"])

        assert result.exit_code == 0
        assert "trace_id: trace-abc" in result.stdout
        assert "decision: ALLOW" in result.stdout

    def test_trace_not_found(self, mock_client: MagicMock) -> None:
        """Nicht gefundener Trace → Exit-Code 1 + Fehlermeldung auf stderr."""
        mock_client.governance.trace.return_value = None
        with patch("hestiaos.cli.Client", return_value=mock_client):
            result = runner.invoke(app, ["trace", "unknown"])

        assert result.exit_code == 1
        assert "not found" in result.stderr

    def test_trace_json(self, mock_client: MagicMock) -> None:
        """trace --json gibt JSON aus."""
        with patch("hestiaos.cli.Client", return_value=mock_client):
            result = runner.invoke(app, ["--json", "trace", "trace-abc"])

        assert result.exit_code == 0
        import json
        data = json.loads(result.stdout)
        assert data["trace_id"] == "trace-abc"
        assert data["decision"] == "ALLOW"
        assert data["latency_ms"] == 12.3


# ── Tests: health ─────────────────────────────────────────────────────────

class TestCliHealth:
    """Testet den health-Command."""

    def test_health_success(self, mock_client: MagicMock) -> None:
        """health gibt Status-Daten aus."""
        with patch("hestiaos.cli.Client", return_value=mock_client):
            result = runner.invoke(app, ["health"])

        assert result.exit_code == 0
        assert "status: healthy" in result.stdout
        assert "version: 0.1.0" in result.stdout
        assert "uptime_seconds: 3600.0" in result.stdout

    def test_health_json(self, mock_client: MagicMock) -> None:
        """health --json gibt JSON aus."""
        with patch("hestiaos.cli.Client", return_value=mock_client):
            result = runner.invoke(app, ["--json", "health"])

        assert result.exit_code == 0
        import json
        data = json.loads(result.stdout)
        assert data["status"] == "healthy"
        assert data["version"] == "0.1.0"
        assert data["uptime_seconds"] == 3600.0


# ── Tests: globale Optionen ──────────────────────────────────────────────

class TestCliGlobalOptions:
    """Testet globale Optionen."""

    def test_custom_base_url(self, mock_client: MagicMock) -> None:
        """--base-url wird an Client-Konstruktor übergeben."""
        with patch("hestiaos.cli.Client", return_value=mock_client) as mock_cls:
            runner.invoke(app, ["--base-url", "http://custom:9000", "health"])

        mock_cls.assert_called_once_with(
            base_url="http://custom:9000",
            api_key=None,
        )

    def test_api_key(self, mock_client: MagicMock) -> None:
        """--api-key wird an Client-Konstruktor übergeben."""
        with patch("hestiaos.cli.Client", return_value=mock_client) as mock_cls:
            runner.invoke(app, ["--api-key", "secret-123", "health"])

        mock_cls.assert_called_once_with(
            base_url="http://localhost:8000",
            api_key="secret-123",
        )
