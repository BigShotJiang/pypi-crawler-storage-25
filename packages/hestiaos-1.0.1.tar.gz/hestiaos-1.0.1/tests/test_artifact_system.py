"""
Tests für das HestiaOS Artifact System (Phase 1 MVP).

Testet:
    - Artifact-Datenmodell (models.py)
    - SQLite-Storage (store.py)
    - Service-Layer (service.py)
    - Manager-Fassade (manager.py)
    - Business-Workflows (Idea → Spec → Tasks)
"""

import pytest
from datetime import datetime, timezone
from core.artifact import ArtifactManager, Artifact, ArtifactType, ArtifactStatus


# =============================================================================
# Fixtures
# =============================================================================

@pytest.fixture
def mgr():
    """Erstelle einen ArtifactManager mit In-Memory SQLite."""
    return ArtifactManager(":memory:")


# =============================================================================
# Datenmodell-Tests
# =============================================================================

class TestArtifactModel:
    def test_create_minimal_artifact(self):
        """Ein Artifact mit minimalen Feldern erstellen."""
        now = datetime.now(timezone.utc)
        art = Artifact(
            id="test_001",
            type=ArtifactType.IDEA,
            title="Test Idee",
            content="Das ist ein Test",
        )
        assert art.id == "test_001"
        assert art.type == ArtifactType.IDEA
        assert art.title == "Test Idee"
        assert art.content == "Das ist ein Test"
        assert art.status == ArtifactStatus.DRAFT
        assert art.owner == "default"
        assert art.tags == []
        assert art.dependencies == []
        assert art.parent_id is None
        assert art.progress == 0.0

    def test_artifact_to_dict(self):
        """Artifact in Dictionary serialisieren."""
        art = Artifact(
            id="test_002",
            type=ArtifactType.TASK,
            title="Task Test",
            content="Task Beschreibung",
            status=ArtifactStatus.ACTIVE,
            tags=["backend", "api"],
            dependencies=["dep_001"],
            progress=0.5,
        )
        d = art.to_dict()
        assert d["id"] == "test_002"
        assert d["type"] == "task"
        assert d["title"] == "Task Test"
        assert d["status"] == "active"
        assert "api" in d["tags"]
        assert "dep_001" in d["dependencies"]
        assert d["progress"] == 0.5

    def test_artifact_from_dict(self):
        """Artifact aus Dictionary deserialisieren."""
        data = {
            "id": "test_003",
            "type": "decision",
            "title": "Entscheidung",
            "content": "Wir nutzen SQLite",
            "status": "done",
            "created_at": "2026-01-01T00:00:00+00:00",
            "updated_at": "2026-01-02T00:00:00+00:00",
            "tags": ["architektur"],
            "owner": "admin",
            "progress": 1.0,
        }
        art = Artifact.from_dict(data)
        assert art.id == "test_003"
        assert art.type == ArtifactType.DECISION
        assert art.status == ArtifactStatus.DONE
        assert art.owner == "admin"
        assert art.progress == 1.0

    def test_artifact_repr(self):
        """Artifact-Repräsentation."""
        art = Artifact(id="test_004", type=ArtifactType.PROJECT, title="Mein Projekt")
        r = repr(art)
        assert "test_004" in r
        assert "project" in r
        assert "Mein Projekt" in r


# =============================================================================
# CRUD-Tests
# =============================================================================

class TestArtifactCRUD:
    def test_create_and_get(self, mgr):
        """Artifact erstellen und abrufen."""
        art = mgr.create_artifact(
            type=ArtifactType.IDEA,
            title="Meine Idee",
            content="Inhalt der Idee",
        )
        assert art.id is not None
        assert art.title == "Meine Idee"

        fetched = mgr.get_artifact(art.id)
        assert fetched is not None
        assert fetched.id == art.id
        assert fetched.title == "Meine Idee"

    def test_get_nonexistent(self, mgr):
        """Nicht-existierendes Artifact gibt None zurück."""
        assert mgr.get_artifact("nonexistent") is None

    def test_update(self, mgr):
        """Artifact aktualisieren."""
        art = mgr.create_artifact(
            type=ArtifactType.TASK,
            title="Original Titel",
            content="Original Inhalt",
            status=ArtifactStatus.ACTIVE,
        )
        art.title = "Neuer Titel"
        art.content = "Neuer Inhalt"
        art.status = ArtifactStatus.DONE
        updated = mgr.update_artifact(art)
        assert updated is not None
        assert updated.title == "Neuer Titel"
        assert updated.content == "Neuer Inhalt"
        assert updated.status == ArtifactStatus.DONE

    def test_update_fields(self, mgr):
        """Einzelne Felder aktualisieren."""
        art = mgr.create_artifact(
            type=ArtifactType.TASK,
            title="Task",
            content="Beschreibung",
        )
        updated = mgr.update_artifact_fields(
            art.id,
            title="Neuer Task",
            status=ArtifactStatus.ACTIVE,
            progress=0.75,
        )
        assert updated is not None
        assert updated.title == "Neuer Task"
        assert updated.status == ArtifactStatus.ACTIVE
        assert updated.progress == 0.75

    def test_delete(self, mgr):
        """Artifact löschen."""
        art = mgr.create_artifact(
            type=ArtifactType.IDEA,
            title="Zu löschen",
        )
        assert mgr.delete_artifact(art.id) is True
        assert mgr.get_artifact(art.id) is None
        assert mgr.delete_artifact("nonexistent") is False

    def test_list_empty(self, mgr):
        """Leere Liste bei neuem Manager."""
        assert mgr.list_artifacts() == []

    def test_list_with_data(self, mgr):
        """Liste mit mehreren Artifacts."""
        mgr.create_artifact(type=ArtifactType.IDEA, title="Idee 1")
        mgr.create_artifact(type=ArtifactType.TASK, title="Task 1")
        mgr.create_artifact(type=ArtifactType.TASK, title="Task 2")
        mgr.create_artifact(type=ArtifactType.DECISION, title="Decision 1")

        all_arts = mgr.list_artifacts()
        assert len(all_arts) == 4

        tasks = mgr.list_artifacts(type_filter=ArtifactType.TASK)
        assert len(tasks) == 2

        ideas = mgr.list_artifacts(type_filter=ArtifactType.IDEA)
        assert len(ideas) == 1


# =============================================================================
# Business-Workflow-Tests
# =============================================================================

class TestBusinessWorkflows:
    def test_create_idea(self, mgr):
        """Eine Idee erfassen."""
        art = mgr.create_idea("Ich will ein AI-gestütztes PM-System bauen")
        assert art.type == ArtifactType.IDEA
        assert art.status == ArtifactStatus.DRAFT
        assert "AI-gestütztes" in art.title

    def test_promote_idea_to_spec(self, mgr):
        """Idee → Spec Promotion."""
        idea = mgr.create_idea("Ein neues Feature")
        spec = mgr.promote_to_spec(idea.id)
        assert spec is not None
        assert spec.type == ArtifactType.SPEC
        assert spec.parent_id == idea.id

        # Idee sollte jetzt done sein
        updated_idea = mgr.get_artifact(idea.id)
        assert updated_idea.status == ArtifactStatus.DONE

    def test_promote_none_idea(self, mgr):
        """Promotion einer nicht-existierenden Idee."""
        assert mgr.promote_to_spec("nonexistent") is None

    def test_split_into_tasks(self, mgr):
        """Spec → Tasks aufteilen."""
        idea = mgr.create_idea("Ein Projekt")
        spec = mgr.promote_to_spec(idea.id)
        tasks = mgr.split_into_tasks(spec.id, [
            "Datenmodell definieren",
            "API-Endpunkte implementieren",
            "Tests schreiben",
        ])
        assert len(tasks) == 3
        for t in tasks:
            assert t.type == ArtifactType.TASK
            assert t.parent_id == spec.id

        # Spec sollte jetzt active sein
        updated_spec = mgr.get_artifact(spec.id)
        assert updated_spec.status == ArtifactStatus.ACTIVE

    def test_complete_artifact(self, mgr):
        """Artifact als erledigt markieren."""
        art = mgr.create_artifact(
            type=ArtifactType.TASK,
            title="Task erledigen",
            status=ArtifactStatus.ACTIVE,
        )
        completed = mgr.complete_artifact(art.id)
        assert completed.status == ArtifactStatus.DONE
        assert completed.progress == 1.0

    def test_block_artifact(self, mgr):
        """Artifact als blockiert markieren."""
        art = mgr.create_artifact(
            type=ArtifactType.TASK,
            title="Blockierter Task",
            status=ArtifactStatus.ACTIVE,
        )
        blocked = mgr.block_artifact(art.id, "Warte auf API-Key")
        assert blocked.status == ArtifactStatus.BLOCKED
        assert "BLOCKED" in blocked.content


# =============================================================================
# Linking-Tests
# =============================================================================

class TestLinking:
    def test_link_artifacts(self, mgr):
        """Zwei Artifacts verlinken."""
        a = mgr.create_artifact(type=ArtifactType.TASK, title="Task A")
        b = mgr.create_artifact(type=ArtifactType.TASK, title="Task B")
        assert mgr.link_artifacts(a.id, b.id) is True
        updated = mgr.get_artifact(a.id)
        assert b.id in updated.dependencies

    def test_unlink_artifacts(self, mgr):
        """Verlinkung entfernen."""
        a = mgr.create_artifact(type=ArtifactType.TASK, title="Task A")
        b = mgr.create_artifact(type=ArtifactType.TASK, title="Task B")
        mgr.link_artifacts(a.id, b.id)
        assert mgr.unlink_artifacts(a.id, b.id) is True
        updated = mgr.get_artifact(a.id)
        assert b.id not in updated.dependencies

    def test_link_nonexistent(self, mgr):
        """Verlinkung mit nicht-existierendem Artifact."""
        a = mgr.create_artifact(type=ArtifactType.TASK, title="Task A")
        assert mgr.link_artifacts(a.id, "nonexistent") is False


# =============================================================================
# Query & Aggregation-Tests
# =============================================================================

class TestQueries:
    def test_idea_inbox(self, mgr):
        """Ideen-Inbox zeigt nur Draft-Ideen."""
        mgr.create_idea("Idee 1")
        mgr.create_idea("Idee 2")
        mgr.create_artifact(type=ArtifactType.TASK, title="Task")
        inbox = mgr.get_idea_inbox()
        assert len(inbox) == 2
        assert all(a.type == ArtifactType.IDEA for a in inbox)

    def test_active_tasks(self, mgr):
        """Aktive Tasks filtern."""
        mgr.create_artifact(
            type=ArtifactType.TASK, title="Active Task",
            status=ArtifactStatus.ACTIVE,
        )
        mgr.create_artifact(
            type=ArtifactType.TASK, title="Done Task",
            status=ArtifactStatus.DONE,
        )
        active = mgr.get_active_tasks()
        assert len(active) == 1
        assert active[0].title == "Active Task"

    def test_task_board(self, mgr):
        """Task-Board gruppiert nach Status."""
        mgr.create_artifact(type=ArtifactType.TASK, title="Active", status=ArtifactStatus.ACTIVE)
        mgr.create_artifact(type=ArtifactType.TASK, title="Blocked", status=ArtifactStatus.BLOCKED)
        mgr.create_artifact(type=ArtifactType.TASK, title="Done", status=ArtifactStatus.DONE)
        board = mgr.get_task_board()
        assert len(board["active"]) == 1
        assert len(board["blocked"]) == 1
        assert len(board["done"]) == 1

    def test_search(self, mgr):
        """Volltextsuche in title und content."""
        mgr.create_artifact(type=ArtifactType.IDEA, title="KI-Assistent", content="Ein AI-Tool")
        mgr.create_artifact(type=ArtifactType.TASK, title="Datenbank", content="SQLite Setup")
        results = mgr.list_artifacts(search="KI")
        assert len(results) == 1
        assert results[0].title == "KI-Assistent"

    def test_stats(self, mgr):
        """System-Statistiken."""
        mgr.create_artifact(type=ArtifactType.IDEA, title="I1")
        mgr.create_artifact(type=ArtifactType.TASK, title="T1", status=ArtifactStatus.ACTIVE)
        mgr.create_artifact(type=ArtifactType.TASK, title="T2", status=ArtifactStatus.DONE)
        mgr.create_artifact(type=ArtifactType.DECISION, title="D1")
        stats = mgr.get_stats()
        assert stats["total"] == 4
        assert stats["ideas"] == 1
        assert stats["tasks"] == 2
        assert stats["decisions"] == 1
        assert stats["active"] == 1
        assert stats["done"] == 1

    def test_timeline(self, mgr):
        """Timeline ist chronologisch."""
        mgr.create_artifact(type=ArtifactType.IDEA, title="Ältere Idee")
        mgr.create_artifact(type=ArtifactType.TASK, title="Neuerer Task")
        timeline = mgr.get_timeline()
        assert len(timeline) == 2


# =============================================================================
# Integration-Tests (vollständiger Workflow)
# =============================================================================

class TestIntegration:
    def test_full_idea_to_project_workflow(self, mgr):
        """Vollständiger Workflow: Idee → Spec → Tasks → Projekt."""
        # 1. Idee erfassen
        idea = mgr.create_idea("Baue ein Dashboard für HestiaOS Metriken")
        assert idea.type == ArtifactType.IDEA

        # 2. Projekt erstellen
        project = mgr.create_artifact(
            type=ArtifactType.PROJECT,
            title="HestiaOS Dashboard",
            content="Ein Echtzeit-Dashboard für System-Metriken",
            tags=["dashboard", "monitoring"],
        )

        # 3. Idee → Spec promovieren
        spec = mgr.promote_to_spec(idea.id)
        assert spec.type == ArtifactType.SPEC

        # 4. Spec als Kind des Projekts setzen (parent_id)
        mgr.update_artifact_fields(spec.id, parent_id=project.id)

        # 5. Spec → Tasks aufteilen (Tasks werden Kinder des Spec)
        tasks = mgr.split_into_tasks(spec.id, [
            "API-Endpunkte für Metriken definieren",
            "Frontend-Komponente für Charts bauen",
            "WebSocket-Integration für Echtzeitdaten",
            "Tests und Dokumentation",
        ])
        assert len(tasks) == 4

        # 6. Tasks bearbeiten
        mgr.update_artifact_fields(tasks[0].id, status=ArtifactStatus.ACTIVE)
        mgr.update_artifact_fields(tasks[1].id, status=ArtifactStatus.ACTIVE)
        mgr.update_artifact_fields(tasks[2].id, status=ArtifactStatus.ACTIVE)
        mgr.complete_artifact(tasks[2].id)

        # 7. Projekt-Übersicht prüfen
        # get_project_overview zeigt Kinder des Projekts (Specs + Tasks mit parent_id=project)
        # Tasks sind Kinder des Spec, nicht direkt des Projekts
        overview = mgr.get_project_overview(project.id)
        assert overview["project"]["title"] == "HestiaOS Dashboard"
        assert len(overview["specs"]) == 1  # Spec ist Kind des Projekts
        assert len(overview["tasks"]) == 0  # Tasks sind Kinder des Spec, nicht des Projekts

        # 8. Spec-Übersicht prüfen (zeigt die Tasks)
        spec_overview = mgr.get_project_overview(spec.id)
        assert len(spec_overview["tasks"]) == 4
        assert spec_overview["stats"]["done_tasks"] == 1
        assert spec_overview["stats"]["active_tasks"] == 2

        # 9. Task-Board prüfen
        board = mgr.get_task_board()
        assert len(board["active"]) >= 2
        assert len(board["done"]) >= 1

        # 10. Statistiken prüfen
        stats = mgr.get_stats()
        assert stats["total"] >= 6  # idea + spec + project + 4 tasks
        assert stats["ideas"] == 1
        assert stats["projects"] == 1

    def test_multiple_independent_ideas(self, mgr):
        """Mehrere unabhängige Ideen parallel verwalten."""
        idee1 = mgr.create_idea("KI-gestützte Code-Reviews")
        idee2 = mgr.create_idea("Automatische Deployment-Pipelines")
        idee3 = mgr.create_idea("Dokumentations-Generator")

        inbox = mgr.get_idea_inbox()
        assert len(inbox) == 3

        # Eine Idee promovieren
        spec = mgr.promote_to_spec(idee2.id)
        assert spec is not None

        # Inbox sollte jetzt nur noch 2 haben
        inbox = mgr.get_idea_inbox()
        assert len(inbox) == 2

    def test_complex_dependency_graph(self, mgr):
        """Komplexe Abhängigkeiten zwischen Tasks."""
        # Tasks erstellen
        t1 = mgr.create_artifact(type=ArtifactType.TASK, title="Setup", status=ArtifactStatus.DONE)
        t2 = mgr.create_artifact(type=ArtifactType.TASK, title="Datenbank", status=ArtifactStatus.DONE)
        t3 = mgr.create_artifact(type=ArtifactType.TASK, title="API", status=ArtifactStatus.ACTIVE)
        t4 = mgr.create_artifact(type=ArtifactType.TASK, title="Frontend", status=ArtifactStatus.BLOCKED)
        t5 = mgr.create_artifact(type=ArtifactType.TASK, title="Tests", status=ArtifactStatus.DRAFT)

        # Abhängigkeiten: t3 → t1, t2; t4 → t3; t5 → t3, t4
        mgr.link_artifacts(t3.id, t1.id)
        mgr.link_artifacts(t3.id, t2.id)
        mgr.link_artifacts(t4.id, t3.id)
        mgr.link_artifacts(t5.id, t3.id)
        mgr.link_artifacts(t5.id, t4.id)

        # Prüfen
        t3_fetched = mgr.get_artifact(t3.id)
        assert t1.id in t3_fetched.dependencies
        assert t2.id in t3_fetched.dependencies

        t5_fetched = mgr.get_artifact(t5.id)
        assert t3.id in t5_fetched.dependencies
        assert t4.id in t5_fetched.dependencies
