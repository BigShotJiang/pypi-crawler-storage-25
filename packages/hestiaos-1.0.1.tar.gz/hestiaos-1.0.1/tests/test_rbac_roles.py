#!/usr/bin/env python3
"""
Test RBAC Role Definitions and Management.
"""

import unittest
import tempfile
import json
from pathlib import Path
from datetime import datetime, timedelta

from core.rbac_system import (
    Role, Permission, RoleDefinition, UserContext, RBACManager, get_rbac_manager
)


class TestRBACRoles(unittest.TestCase):
    """Test RBAC role definitions and management."""
    
    def setUp(self):
        """Set up test environment."""
        self.rbac = RBACManager()
    
    def test_role_enum_values(self):
        """Test that role enum values are correct."""
        self.assertEqual(Role.GUEST, "guest")
        self.assertEqual(Role.VIEWER, "viewer")
        self.assertEqual(Role.OPERATOR, "operator")
        self.assertEqual(Role.ADMIN, "admin")
        self.assertEqual(Role.SYSTEM, "system")
        self.assertEqual(Role.SERVICE, "service")
    
    def test_permission_enum_values(self):
        """Test that permission enum values are correct."""
        self.assertEqual(Permission.READ, "read")
        self.assertEqual(Permission.WRITE, "write")
        self.assertEqual(Permission.EXECUTE, "execute")
        self.assertEqual(Permission.DELETE, "delete")
        self.assertEqual(Permission.ADMIN, "admin")
    
    def test_default_roles_exist(self):
        """Test that default roles are initialized."""
        self.assertIn(Role.GUEST, self.rbac.role_definitions)
        self.assertIn(Role.VIEWER, self.rbac.role_definitions)
        self.assertIn(Role.OPERATOR, self.rbac.role_definitions)
        self.assertIn(Role.ADMIN, self.rbac.role_definitions)
        self.assertIn(Role.SYSTEM, self.rbac.role_definitions)
        self.assertIn(Role.SERVICE, self.rbac.role_definitions)
    
    def test_role_permissions(self):
        """Test that roles have appropriate permissions."""
        # GUEST should have basic read permissions
        guest_role = self.rbac.role_definitions[Role.GUEST]
        self.assertIn(Permission.READ, guest_role.permissions)
        self.assertIn(Permission.VIEW_LOGS, guest_role.permissions)
        self.assertIn(Permission.VIEW_METRICS, guest_role.permissions)
        self.assertNotIn(Permission.WRITE, guest_role.permissions)
        self.assertNotIn(Permission.ADMIN, guest_role.permissions)
        
        # VIEWER should inherit from GUEST and have additional permissions
        viewer_role = self.rbac.role_definitions[Role.VIEWER]
        self.assertIn(Permission.READ, viewer_role.permissions)
        self.assertIn(Permission.VIEW_CONSCIOUSNESS, viewer_role.permissions)
        self.assertIn(Permission.AUDIT, viewer_role.permissions)
        
        # OPERATOR should have write and execute permissions
        operator_role = self.rbac.role_definitions[Role.OPERATOR]
        self.assertIn(Permission.WRITE, operator_role.permissions)
        self.assertIn(Permission.EXECUTE, operator_role.permissions)
        self.assertIn(Permission.START_STOP, operator_role.permissions)
        
        # ADMIN should have all permissions
        admin_role = self.rbac.role_definitions[Role.ADMIN]
        self.assertIn(Permission.ADMIN, admin_role.permissions)
        self.assertIn(Permission.MANAGE_USERS, admin_role.permissions)
        self.assertIn(Permission.MANAGE_ROLES, admin_role.permissions)
    
    def test_role_inheritance(self):
        """Test role inheritance relationships."""
        viewer_role = self.rbac.role_definitions[Role.VIEWER]
        self.assertIn(Role.GUEST, viewer_role.inherits_from)
        
        operator_role = self.rbac.role_definitions[Role.OPERATOR]
        self.assertIn(Role.VIEWER, operator_role.inherits_from)
        
        admin_role = self.rbac.role_definitions[Role.ADMIN]
        self.assertIn(Role.OPERATOR, admin_role.inherits_from)
    
    def test_role_definition_methods(self):
        """Test RoleDefinition methods."""
        test_role = RoleDefinition(
            name=Role.GUEST,
            description="Test role",
            permissions={Permission.READ, Permission.VIEW_LOGS}
        )
        
        self.assertTrue(test_role.has_permission(Permission.READ))
        self.assertFalse(test_role.has_permission(Permission.WRITE))
        
        self.assertTrue(test_role.can_perform("read"))
        self.assertFalse(test_role.can_perform("write"))
        self.assertTrue(test_role.can_perform("view_logs"))
    
    def test_add_remove_role_definition(self):
        """Test adding and removing custom role definitions."""
        # Create a custom role
        custom_role = "custom_role"
        custom_def = RoleDefinition(
            name=custom_role,
            description="Custom test role",
            permissions={Permission.READ, Permission.WRITE}
        )
        
        # Add the custom role
        self.rbac.add_role_definition(custom_def)

        self.assertIn(custom_role, self.rbac.role_definitions)
        
        # Remove the custom role
        self.rbac.remove_role_definition(custom_role)
        self.assertNotIn(custom_role, self.rbac.role_definitions)
    
    def test_singleton_manager(self):
        """Test that get_rbac_manager returns a singleton."""
        manager1 = get_rbac_manager()
        manager2 = get_rbac_manager()
        
        self.assertIs(manager1, manager2)
    
    def test_manager_with_config(self):
        """Test RBAC manager with configuration file."""
        # Create a temporary config file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            policies = [
                {
                    "resource": "/api/admin/*",
                    "action": "*",
                    "roles": ["admin"],
                    "effect": "allow"
                },
                {
                    "resource": "/api/public/*",
                    "action": "*",
                    "roles": ["*"],
                    "effect": "allow"
                }
            ]
            json.dump(policies, f)
            config_path = Path(f.name)
        
        try:
            # Create manager with config
            rbac_with_config = RBACManager(config_path)
            self.assertEqual(len(rbac_with_config.policies), 2)
        finally:
            # Clean up
            config_path.unlink()


class TestUserContext(unittest.TestCase):
    """Test UserContext functionality."""
    
    def test_user_context_creation(self):
        """Test creating a user context."""
        context = UserContext(
            user_id="test_user_123",
            username="testuser",
            roles=[Role.VIEWER, Role.OPERATOR],
            permissions={Permission.READ, Permission.WRITE},
            session_id="session_123",
            authenticated_at=datetime.now()
        )
        
        self.assertEqual(context.user_id, "test_user_123")
        self.assertEqual(context.username, "testuser")
        self.assertIn(Role.VIEWER, context.roles)
        self.assertIn(Role.OPERATOR, context.roles)
        self.assertIn(Permission.READ, context.permissions)
        self.assertIn(Permission.WRITE, context.permissions)
    
    def test_user_context_methods(self):
        """Test UserContext methods."""
        context = UserContext(
            user_id="test_user",
            username="testuser",
            roles=[Role.VIEWER],
            permissions={Permission.READ},
            session_id="session_123",
            authenticated_at=datetime.now()
        )
        
        self.assertTrue(context.has_role(Role.VIEWER))
        self.assertFalse(context.has_role(Role.ADMIN))
        
        self.assertTrue(context.has_permission(Permission.READ))
        self.assertFalse(context.has_permission(Permission.WRITE))
    
    def test_session_expiration(self):
        """Test session expiration logic."""
        # Create expired session
        expired_time = datetime.now() - timedelta(hours=2)
        context = UserContext(
            user_id="test_user",
            username="testuser",
            roles=[Role.VIEWER],
            permissions={Permission.READ},
            session_id="session_123",
            authenticated_at=expired_time,
            expires_at=expired_time + timedelta(hours=1)  # Expired 1 hour ago
        )
        
        self.assertTrue(context.is_expired())
        
        # Create non-expired session
        future_time = datetime.now() + timedelta(hours=1)
        context_future = UserContext(
            user_id="test_user",
            username="testuser",
            roles=[Role.VIEWER],
            permissions={Permission.READ},
            session_id="session_456",
            authenticated_at=datetime.now(),
            expires_at=future_time
        )
        
        self.assertFalse(context_future.is_expired())
        
        # Test session with no expiration
        context_no_expiry = UserContext(
            user_id="test_user",
            username="testuser",
            roles=[Role.VIEWER],
            permissions={Permission.READ},
            session_id="session_789",
            authenticated_at=datetime.now(),
            expires_at=None
        )
        
        self.assertFalse(context_no_expiry.is_expired())


if __name__ == "__main__":
    unittest.main()