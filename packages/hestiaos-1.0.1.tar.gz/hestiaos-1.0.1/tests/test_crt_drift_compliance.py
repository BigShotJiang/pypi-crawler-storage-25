"""
Tests für CI-CRT-014: Policy Drift Detection.

Testet den PolicyDriftVisitor und check_policy_drift_compliance()
aus scripts/check_crt_compliance.py.

Phase 1 (Exploration): Nur Drift A + B, nur Logging (WARN), kein Fail.

Test-Kategorien:
1. Positive Tests: Erlaubte Muster (KEIN Drift)
2. Negative Tests: Drift A (Policy Feedback) — VERBOTEN
3. Negative Tests: Drift B (Policy State) — VERBOTEN
4. Edge Cases
"""

import ast
import pytest
from pathlib import Path
from typing import List

from scripts.check_crt_compliance import (
    PolicyDriftVisitor,
    check_policy_drift_compliance,
    REPO_ROOT,
)


# =============================================================================
# Hilfsfunktionen
# =============================================================================


def _parse_source(source: str) -> ast.AST:
    """Parst Python-Quellcode in einen AST."""
    return ast.parse(source)


def _run_visitor(source: str, verbose: bool = False) -> List[str]:
    """Führt PolicyDriftVisitor auf einem Quellcode-Snippet aus.

    Returns:
        List[str]: Warnungen (leer = kein Drift gefunden)
    """
    tree = _parse_source(source)
    visitor = PolicyDriftVisitor(Path("test_snippet.py"), verbose)
    visitor.visit(tree)
    return visitor.warnings


# =============================================================================
# Positive Tests: Erlaubte Muster (KEIN Drift)
# =============================================================================


class TestPositiveDriftA:
    """Positive Tests für Drift A: Erlaubte Termination + Side Effects."""

    def test_direct_return_execution_blocked(self):
        """Direktes return ExecutionBlocked nach if not allow()."""
        source = """
async def execute():
    allowed = await provider.allow("tool", {})
    if not allowed:
        return {"success": False, "error": "ExecutionBlocked", "content": None}
"""
        warnings = _run_visitor(source)
        assert len(warnings) == 0, f"Erwartet 0 Warnungen, erhalten: {warnings}"

    def test_raise_execution_blocked(self):
        """raise ExecutionBlocked nach if not allow()."""
        source = """
async def execute():
    allowed = await provider.allow("tool", {})
    if not allowed:
        raise ExecutionBlocked("blocked")
"""
        warnings = _run_visitor(source)
        assert len(warnings) == 0, f"Erwartet 0 Warnungen, erhalten: {warnings}"

    def test_trace_and_return(self):
        """trace_policy_decision + return ExecutionBlocked."""
        source = """
async def execute():
    allowed = await provider.allow("tool", {})
    if not allowed:
        trace_policy_decision("tool", False, "provider", "session_1")
        return {"success": False, "error": "ExecutionBlocked", "content": None}
"""
        warnings = _run_visitor(source)
        assert len(warnings) == 0, f"Erwartet 0 Warnungen, erhalten: {warnings}"

    def test_log_and_return(self):
        """logging + return ExecutionBlocked."""
        source = """
async def execute():
    allowed = await provider.allow("tool", {})
    if not allowed:
        logger.warning("Policy denied tool execution")
        return {"success": False, "error": "ExecutionBlocked", "content": None}
"""
        warnings = _run_visitor(source)
        assert len(warnings) == 0, f"Erwartet 0 Warnungen, erhalten: {warnings}"

    def test_multi_log_and_return(self):
        """Mehrere logging/trace-Aufrufe + return."""
        source = """
async def execute():
    allowed = await provider.allow("tool", {})
    if not allowed:
        logger.warning("Policy denied")
        logger.info("Session: %s", session_id)
        trace_policy_decision("tool", False, "provider", "session_1")
        return {"success": False, "error": "ExecutionBlocked", "content": None}
"""
        warnings = _run_visitor(source)
        assert len(warnings) == 0, f"Erwartet 0 Warnungen, erhalten: {warnings}"

    def test_allow_path_legitimate(self):
        """allow()-Pfad (True) ist immer legitim."""
        source = """
async def execute():
    allowed = await provider.allow("tool", {})
    if allowed:
        result = await execute_tool("tool", {})
        return {"success": True, "content": result}
"""
        warnings = _run_visitor(source)
        assert len(warnings) == 0, f"Erwartet 0 Warnungen, erhalten: {warnings}"

    def test_sync_allow(self):
        """Sync allow() ohne await."""
        source = """
def execute():
    allowed = provider.allow("tool", {})
    if not allowed:
        return {"success": False, "error": "ExecutionBlocked", "content": None}
"""
        warnings = _run_visitor(source)
        assert len(warnings) == 0, f"Erwartet 0 Warnungen, erhalten: {warnings}"

    def test_print_debug(self):
        """print() ist erlaubter Side Effect."""
        source = """
async def execute():
    allowed = await provider.allow("tool", {})
    if not allowed:
        print("Policy denied tool")
        return {"success": False, "error": "ExecutionBlocked", "content": None}
"""
        warnings = _run_visitor(source)
        assert len(warnings) == 0, f"Erwartet 0 Warnungen, erhalten: {warnings}"



class TestPositiveDriftB:
    """Positive Tests für Drift B: Keine Persistierung von allow()-Ergebnissen."""

    def test_no_state_write(self):
        """Keine State-Writes nach allow()."""
        source = """
async def execute():
    allowed = await provider.allow("tool", {})
    if not allowed:
        return {"success": False, "error": "ExecutionBlocked", "content": None}
"""
        warnings = _run_visitor(source)
        assert len(warnings) == 0, f"Erwartet 0 Warnungen, erhalten: {warnings}"

    def test_allow_result_not_used(self):
        """allow()-Ergebnis wird nicht persistiert (nur im Denial-Check verwendet)."""
        source = """
async def execute():
    decision = await provider.allow("tool", {})
    if not decision:
        return {"success": False, "error": "ExecutionBlocked", "content": None}
"""
        warnings = _run_visitor(source)
        assert len(warnings) == 0, f"Erwartet 0 Warnungen, erhalten: {warnings}"


# =============================================================================
# Negative Tests: Drift A — Policy Feedback (VERBOTEN)
# =============================================================================


class TestNegativeDriftA:
    """Negative Tests für Drift A: Verbotene Reaktionen auf Policy-Denial."""

    def test_retry_alternative_tool(self):
        """Retry mit alternativem Tool nach Denial — VERBOTEN."""
        source = """
async def execute():
    allowed = await provider.allow("tool", {})
    if not allowed:
        result = await execute_tool("other_tool", {})
        return {"success": True, "content": result}
"""
        warnings = _run_visitor(source)
        assert len(warnings) > 0, "Erwartet Drift A Warnung für Retry mit alternativem Tool"
        assert "Drift A" in warnings[0], f"Erwartet 'Drift A' in Warnung: {warnings[0]}"

    def test_fallback_tool(self):
        """Fallback auf anderen Tool-Typ nach Denial — VERBOTEN."""
        source = """
async def execute():
    allowed = await provider.allow("tool", {})
    if not allowed:
        return await execute_fallback_tool("tool", {})
"""
        warnings = _run_visitor(source)
        assert len(warnings) > 0, "Erwartet Drift A Warnung für Fallback"
        assert "Drift A" in warnings[0]

    def test_state_mutation(self):
        """State-Mutation nach Denial — VERBOTEN."""
        source = """
async def execute():
    allowed = await provider.allow("tool", {})
    if not allowed:
        self.retry_count += 1
        return {"success": False, "error": "ExecutionBlocked", "content": None}
"""
        warnings = _run_visitor(source)
        assert len(warnings) > 0, "Erwartet Drift A Warnung für State-Mutation"
        assert "Drift A" in warnings[0]

    def test_callback_notify(self):
        """Callback/Event auslösen nach Denial — VERBOTEN."""
        source = """
async def execute():
    allowed = await provider.allow("tool", {})
    if not allowed:
        notify_admin("Policy denied tool")
        return {"success": False, "error": "ExecutionBlocked", "content": None}
"""
        warnings = _run_visitor(source)
        assert len(warnings) > 0, "Erwartet Drift A Warnung für Callback"
        assert "Drift A" in warnings[0]

    def test_complex_block_with_forbidden(self):
        """Komplexer Block: logging + trace + verbotene Aktion."""
        source = """
async def execute():
    allowed = await provider.allow("tool", {})
    if not allowed:
        trace_policy_decision("tool", False, "provider", "session_1")
        logger.warning("Policy denied")
        self.metrics.record_denial("tool")
        return {"success": False, "error": "ExecutionBlocked", "content": None}
"""
        warnings = _run_visitor(source)
        assert len(warnings) > 0, "Erwartet Drift A Warnung für verbotene Aktion nach logging"
        assert "Drift A" in warnings[0]

    def test_return_non_execution_blocked(self):
        """Return ohne ExecutionBlocked — VERDÄCHTIG."""
        source = """
async def execute():
    allowed = await provider.allow("tool", {})
    if not allowed:
        return {"success": False, "error": "SomeOtherError", "content": None}
"""
        warnings = _run_visitor(source)
        assert len(warnings) > 0, "Erwartet Drift A Warnung für return ohne ExecutionBlocked"

    def test_raise_non_execution_blocked(self):
        """raise ohne ExecutionBlocked — VERDÄCHTIG."""
        source = """
async def execute():
    allowed = await provider.allow("tool", {})
    if not allowed:
        raise ValueError("not allowed")
"""
        warnings = _run_visitor(source)
        assert len(warnings) > 0, "Erwartet Drift A Warnung für raise ohne ExecutionBlocked"

    def test_pass_only_non_terminal(self):
        """A3: pass-only Denial-Block (nicht terminal)."""
        source = """
async def execute():
    allowed = await provider.allow("tool", {})
    if not allowed:
        pass
"""
        warnings = _run_visitor(source)
        assert len(warnings) > 0, (
            "Erwarte A3-Warnung: pass-only Denial-Block ist nicht terminal"
        )
        assert any("A3" in w or "Non-Terminating" in w for w in warnings), (
            f"Erwarte A3-spezifische Warnung, erhalten: {warnings}"
        )


# =============================================================================
# Negative Tests: Drift B — Policy State (VERBOTEN)
# =============================================================================


class TestNegativeDriftB:
    """Negative Tests für Drift B: Verbotene Persistierung von allow()-Ergebnissen."""

    def test_self_attribute_write(self):
        """allow()-Ergebnis in self.* speichern — VERBOTEN."""
        source = """
async def execute():
    decision = await provider.allow("tool", {})
    self.last_policy_decision = decision
    if not decision:
        return {"success": False, "error": "ExecutionBlocked", "content": None}
"""
        warnings = _run_visitor(source)
        assert len(warnings) > 0, "Erwartet Drift B Warnung für self.* Zuweisung"
        assert "Drift B" in warnings[0], f"Erwartet 'Drift B' in Warnung: {warnings[0]}"

    def test_metadata_dict_write(self):
        """allow()-Ergebnis in metadata[...] speichern — VERBOTEN."""
        source = """
async def execute():
    decision = await provider.allow("tool", {})
    metadata["policy_blocked"] = decision
    if not decision:
        return {"success": False, "error": "ExecutionBlocked", "content": None}
"""
        warnings = _run_visitor(source)
        assert len(warnings) > 0, "Erwartet Drift B Warnung für metadata[...] Zuweisung"
        assert "Drift B" in warnings[0]

    def test_cache_dict_write(self):
        """allow()-Ergebnis in cache[...] speichern — VERBOTEN."""
        source = """
async def execute():
    decision = await provider.allow("tool", {})
    cache["last_policy"] = decision
    if not decision:
        return {"success": False, "error": "ExecutionBlocked", "content": None}
"""
        warnings = _run_visitor(source)
        assert len(warnings) > 0, "Erwartet Drift B Warnung für cache[...] Zuweisung"
        assert "Drift B" in warnings[0]

    def test_context_dict_write(self):
        """allow()-Ergebnis in context[...] speichern — VERBOTEN."""
        source = """
async def execute():
    decision = await provider.allow("tool", {})
    context["policy_decision"] = decision
    if not decision:
        return {"success": False, "error": "ExecutionBlocked", "content": None}
"""
        warnings = _run_visitor(source)
        assert len(warnings) > 0, "Erwartet Drift B Warnung für context[...] Zuweisung"
        assert "Drift B" in warnings[0]

    def test_sync_allow_self_write(self):
        """Sync allow()-Ergebnis in self.* speichern — VERBOTEN."""
        source = """
def execute():
    decision = provider.allow("tool", {})
    self.policy_state = decision
    if not decision:
        return {"success": False, "error": "ExecutionBlocked", "content": None}
"""
        warnings = _run_visitor(source)
        assert len(warnings) > 0, "Erwartet Drift B Warnung für sync allow() self.* Zuweisung"
        assert "Drift B" in warnings[0]


# =============================================================================
# Edge Cases
# =============================================================================


class TestEdgeCases:
    """Edge Cases für CI-CRT-014."""

    def test_allow_in_loop(self):
        """allow() in Schleife — nur letzte Zuweisung zählt."""
        source = """
async def execute():
    for tool in tools:
        decision = await provider.allow(tool, {})
        if not decision:
            return {"success": False, "error": "ExecutionBlocked", "content": None}
    return {"success": True, "content": "all_allowed"}
"""
        warnings = _run_visitor(source)
        assert len(warnings) == 0, f"Erwartet 0 Warnungen, erhalten: {warnings}"

    def test_nested_if_else(self):
        """Verschachteltes if/else — else-Zweig ist Denial-Pfad."""
        source = """
async def execute():
    decision = await provider.allow("tool", {})
    if decision:
        result = await execute_tool("tool", {})
        return {"success": True, "content": result}
    else:
        return {"success": False, "error": "ExecutionBlocked", "content": None}
"""
        warnings = _run_visitor(source)
        assert len(warnings) == 0, f"Erwartet 0 Warnungen für else-Zweig, erhalten: {warnings}"

    def test_decision_is_false_pattern(self):
        """if decision is False: Pattern."""
        source = """
async def execute():
    decision = await provider.allow("tool", {})
    if decision is False:
        return {"success": False, "error": "ExecutionBlocked", "content": None}
"""
        warnings = _run_visitor(source)
        assert len(warnings) == 0, f"Erwartet 0 Warnungen für 'is False' Pattern, erhalten: {warnings}"

    def test_decision_equals_false_pattern(self):
        """if decision == False: Pattern."""
        source = """
async def execute():
    decision = await provider.allow("tool", {})
    if decision == False:
        return {"success": False, "error": "ExecutionBlocked", "content": None}
"""
        warnings = _run_visitor(source)
        assert len(warnings) == 0, f"Erwartet 0 Warnungen für '== False' Pattern, erhalten: {warnings}"

    def test_binary_flag_allowed(self):
        """Binary Flag in metadata ist erlaubt (kein Drift B in Phase 1)."""
        source = """
async def execute():
    decision = await provider.allow("tool", {})
    if not decision:
        metadata["blocked"] = True
        return {"success": False, "error": "ExecutionBlocked", "content": None}
"""
        warnings = _run_visitor(source)
        # In Phase 1: metadata["blocked"] = True ist ein Binary Flag (erlaubt)
        # Aber Drift B erkennt metadata[...] = decision — hier ist der Wert True, nicht decision
        # Also KEINE Warnung
        assert len(warnings) == 0, f"Erwartet 0 Warnungen für Binary Flag, erhalten: {warnings}"

    def test_empty_source(self):
        """Leere Datei — keine Warnungen."""
        source = ""
        warnings = _run_visitor(source)
        assert len(warnings) == 0

    def test_no_allow_call(self):
        """Kein allow()-Aufruf — keine Warnungen."""
        source = """
async def execute():
    result = await execute_tool("tool", {})
    return {"success": True, "content": result}
"""
        warnings = _run_visitor(source)
        assert len(warnings) == 0

    def test_syntax_error_graceful(self):
        """Syntaxfehler — keine Exception."""
        source = "def broken(::"
        # Sollte keine Exception werfen
        try:
            tree = ast.parse(source)
            visitor = PolicyDriftVisitor(Path("broken.py"), False)
            visitor.visit(tree)
        except SyntaxError:
            pass  # Erwartet

    def test_allow_in_different_function(self):
        """allow() in einer anderen Funktion — kein Denial-Check im Kontext."""
        source = """
async def check():
    decision = await provider.allow("tool", {})
    return decision

async def execute():
    result = await execute_tool("tool", {})
    return {"success": True, "content": result}
"""
        warnings = _run_visitor(source)
        # allow() wird erkannt, aber es gibt keinen if not allow() im Code
        assert len(warnings) == 0


# =============================================================================
# Gap-Analyse: Bekannte Lücken in Phase 1
# =============================================================================
# Diese Tests dokumentieren, was Phase 1 NICHT erkennt.
# Sie sind als "expected failure" markiert, um den Gap bewusst zu machen.
# Sobald eine Lücke geschlossen wird, kann der Test auf "erwartet erkannt"
# umgestellt werden.
# =============================================================================


class TestGapAnalysis:
    """Dokumentierte Lücken und behobene Lücken in Phase 1 (Exploration).

    A1 (Negations-Tracking) und B3 (Transitives Assignment) wurden in Phase 1
    als Hotfix nachgerüstet (Tier 1 laut Gap-Priorisierung).
    A2 (Delegation) bleibt bewusst offen — erfordert CFG/Call Graph.
    D1 (Zeitliche Kopplung) bleibt bewusst offen — binary flags sind erlaubt.
    """

    def test_gap_indirect_drift_via_negation(self):
        """A1: Indirekter Drift via Negation — BEHOBEN.

        allowed = await provider.allow(...)
        blocked = not allowed  ← jetzt in _allow_derived_vars
        if blocked:
            fallback()         ← jetzt als Drift A erkannt

        Status: BEHOBEN via Negations-Tracking in visit_Assign
        """
        source = """
async def execute():
    allowed = await provider.allow("tool", {})
    blocked = not allowed
    if blocked:
        return await execute_fallback_tool("tool", {})
"""
        warnings = _run_visitor(source)
        # BEHOBEN: blocked wird via _allow_derived_vars erkannt
        assert len(warnings) > 0
        assert any("Drift A" in w for w in warnings)

    def test_gap_delegation_to_denial_handler(self):
        """A2: Delegation an denial handler — AKZEPTIERTE LÜCKE.

        if not await provider.allow(...):
            return handle_denial()  ← Funktion könnte illegal sein

        Status: NICHT erkannt — kein interprocedural analysis
        Fix: Würde CFG oder Dataflow-Analyse erfordern (Phase 2/3)
        """
        source = """
async def execute():
    if not await provider.allow("tool", {}):
        return await handle_denial()
"""
        warnings = _run_visitor(source)
        # Kein Drift (handle_denial() ist ein erlaubter Call)
        assert len(warnings) == 0

    def test_gap_split_assignment(self):
        """B3: Split Assignment — BEHOBEN.

        decision = await provider.allow(...)
        x = decision           ← jetzt in _allow_result_vars (transitives Tracking)
        self.y = x             ← jetzt als Drift B erkannt

        Status: BEHOBEN via Forward Data Flow in visit_Assign
        """
        source = """
async def execute():
    decision = await provider.allow("tool", {})
    x = decision
    self.y = x
"""
        warnings = _run_visitor(source)
        # BEHOBEN: x wird via transitives Assignment in _allow_result_vars aufgenommen
        assert len(warnings) > 0
        assert any("Drift B" in w for w in warnings)

    def test_gap_temporal_coupling(self):
        """D1: Zeitliche Kopplung (Drift D) — AKZEPTIERTE LÜCKE.

        self.denied = True  ← im Denial-Block
        ...
        if self.denied:     ← später, in anderem Kontext
            adapt_behavior()

        Status: NICHT erkannt — binary flags sind erlaubt (kein allow()-Ergebnis)
        Bewertung: Das ist KEIN Bug — binary flags sind laut ADR-006 explizit erlaubt.
        Drift D (Behavioral Branching) ist Phase 2/3.
        """
        source = """
async def execute():
    if not await provider.allow("tool", {}):
        self.denied = True
        return {"success": False, "error": "ExecutionBlocked", "content": None}

async def later():
    if self.denied:
        return await execute_alternative("tool", {})
"""
        warnings = _run_visitor(source)
        # Kein Drift (self.denied = True ist binary flag, kein allow()-Ergebnis)
        assert len(warnings) == 0

    def test_gap_negation_chain(self):
        """A1c: Mehrstufige Negations-Kette — BEHOBEN.

        allowed = await provider.allow(...)
        blocked = not allowed
        flag = blocked            ← chain tracking via _allow_derived_vars
        if flag:
            fallback()            ← muss als Drift A erkannt werden

        Status: BEHOBEN via Chain-Tracking in visit_Assign
        """
        source = """
async def execute():
    allowed = await provider.allow("tool", {})
    blocked = not allowed
    flag = blocked
    if flag:
        return await execute_fallback_tool("tool", {})
"""
        warnings = _run_visitor(source)
        # BEHOBEN: flag wird via Chain-Tracking in _allow_derived_vars aufgenommen
        assert len(warnings) > 0
        assert any("Drift A" in w for w in warnings)

    def test_gap_boolean_expression(self):
        """A1d: Boolean Expression — BEHOBEN.

        blocked = not allowed or some_condition
        if blocked:
            fallback()

        Status: BEHOBEN via Boolean Expression Tracking
        """
        source = """
async def execute():
    allowed = await provider.allow("tool", {})
    blocked = not allowed or some_condition
    if blocked:
        return await execute_fallback_tool("tool", {})
"""
        warnings = _run_visitor(source)
        # BEHOBEN: blocked wird via _contains_allow_reference als derived erkannt
        assert len(warnings) > 0
        assert any("Drift A" in w for w in warnings)

    def test_gap_tuple_assignment(self):
        """B3b: Tuple Assignment — BEHOBEN.

        x, y = decision, something_else
        self.z = x

        Status: BEHOBEN via Tuple-Destructuring in visit_Assign
        """
        source = """
async def execute():
    decision = await provider.allow("tool", {})
    x, y = decision, something_else
    self.z = x
"""
        warnings = _run_visitor(source)
        # BEHOBEN: x wird via Tuple-Destructuring in _allow_result_vars aufgenommen
        assert len(warnings) > 0
        assert any("Drift B" in w for w in warnings)


# =============================================================================
# Integrationstest: check_policy_drift_compliance() auf core/
# =============================================================================


class TestIntegration:
    """Integrationstest: check_policy_drift_compliance() auf core/."""

    def test_core_directory_no_drift(self):
        """check_policy_drift_compliance() auf core/ — 0 Warnungen erwartet."""
        n_warnings, warnings, drift_entries = check_policy_drift_compliance(verbose=False)
        assert n_warnings == 0, (
            f"Erwartet 0 Drift-Warnungen in core/, erhalten: {n_warnings}\n"
            + "\n".join(warnings[:5])
        )
