#!/usr/bin/env python3
"""
Test KPI metrics collection for HestiaOS Kids.
"""

import asyncio
import sys
from datetime import datetime

# Add the core directory to the path
sys.path.insert(0, '.')

from core.experimentation.metrics_collector import (
    ExperimentMetricsCollector,
    KPIMetrics
)


async def test_kpi_metrics_collection():
    """Test KPI metrics collection functionality."""
    print("🧪 Testing KPI metrics collection...")
    
    # Create metrics collector
    collector = ExperimentMetricsCollector()
    
    # Create KPI metrics
    kpi_metrics = KPIMetrics(
        intent_accuracy=0.85,
        response_fit=0.72,
        continuation_rate=0.42,
        policy_violations=0,
        refusal_quality=0.8,
        latency=1.5,
        token_usage=245
    )
    
    # Test KPI collection
    success = await collector.collect_kpi_metrics(
        kpi_metrics=kpi_metrics,
        persona="Erklärbär",
        variant="A",
        experiment_id="test_experiment_1",
        metadata={"test_run": True, "timestamp": datetime.utcnow().isoformat()}
    )
    
    assert success, "KPI metrics collection failed"
    print("✅ KPI metrics collection successful")
    
    # Test response fit calculation
    response_text = "Zuerst öffne die App. Dann klicke auf Einstellungen. Anschließend wähle den gewünschten Modus."
    response_fit = collector.calculate_response_fit(
        response_text=response_text,
        expected_tone="explainer",
        expected_structure="step_by_step",
        expected_verbosity=30
    )
    
    print(f"📊 Response fit score: {response_fit:.2f}")
    assert 0.0 <= response_fit <= 1.0, "Response fit score out of range"
    
    # Test intent accuracy calculation
    intent_accuracy = collector.calculate_intent_accuracy(
        detected_intent="app_navigation",
        expected_intent="app_navigation"
    )
    assert intent_accuracy == 1.0, "Intent accuracy should be 1.0 for matching intents"
    
    intent_accuracy_mismatch = collector.calculate_intent_accuracy(
        detected_intent="app_navigation",
        expected_intent="file_management"
    )
    assert intent_accuracy_mismatch == 0.0, "Intent accuracy should be 0.0 for mismatched intents"
    
    # Test refusal quality calculation
    refusal_quality = collector.calculate_refusal_quality(
        refusal_text="Das kann ich leider nicht tun, aber ich kann dir bei etwas anderem helfen.",
        has_explanation=True,
        has_friendly_tone=True,
        has_alternative=True
    )
    print(f"📊 Refusal quality score: {refusal_quality:.2f}")
    assert refusal_quality == 1.0, "Refusal quality should be 1.0 for perfect refusal"
    
    # Test aggregated metrics retrieval
    aggregated_metrics = await collector.get_aggregated_metrics()
    print(f"📈 Total aggregated metrics: {len(aggregated_metrics)}")
    
    # Check that KPI metrics were recorded
    kpi_metric_count = sum(1 for metric in aggregated_metrics 
                          if metric.get('category') == 'kpi')
    print(f"📊 KPI metrics recorded: {kpi_metric_count}")
    
    # Test stats
    stats = collector.stats
    print(f"📊 Metrics collected: {stats['metrics_collected']}")
    assert stats['metrics_collected'] > 0, "Should have collected at least one metric"
    
    print("✅ All KPI tests passed!")
    return True


async def test_response_fit_heuristics():
    """Test response fit heuristic calculations."""
    print("\n🧪 Testing response fit heuristics...")
    
    collector = ExperimentMetricsCollector()
    
    # Test tone alignment
    simple_text = "Das ist einfach und verständlich erklärt."
    simple_score = collector._calculate_tone_alignment(simple_text, "simple")
    print(f"📊 Simple tone score: {simple_score:.2f}")
    assert simple_score > 0.5, "Simple tone should score well"
    
    friendly_text = "Hallo! Gerne helfe ich dir weiter. Bitte schön!"
    friendly_score = collector._calculate_tone_alignment(friendly_text, "friendly")
    print(f"📊 Friendly tone score: {friendly_score:.2f}")
    assert friendly_score > 0.5, "Friendly tone should score well"
    
    # Test structure score
    step_text = "1. Zuerst öffne die App. 2. Dann klicke auf Einstellungen. 3. Anschließend wähle den Modus."
    step_score = collector._calculate_structure_score(step_text, "step_by_step")
    print(f"📊 Step-by-step structure score: {step_score:.2f}")
    assert step_score > 0.5, "Step-by-step structure should score well"
    
    bullet_text = "• Erster Punkt\n• Zweiter Punkt\n• Dritter Punkt"
    bullet_score = collector._calculate_structure_score(bullet_text, "bullet_points")
    print(f"📊 Bullet points structure score: {bullet_score:.2f}")
    assert bullet_score > 0.5, "Bullet points structure should score well"
    
    # Test verbosity score
    short_text = "Kurze Antwort."
    long_text = "Dies ist eine sehr ausführliche Antwort mit vielen Details und Erklärungen, die deutlich über das notwendige Maß hinausgeht."
    
    short_score = collector._calculate_verbosity_score(short_text, 10)
    long_score = collector._calculate_verbosity_score(long_text, 10)
    
    print(f"📊 Short text verbosity score: {short_score:.2f}")
    print(f"📊 Long text verbosity score: {long_score:.2f}")
    
    # Short text should have lower deviation from target 10
    assert short_score < long_score, "Short text should have better verbosity score for target 10"
    
    print("✅ All heuristic tests passed!")


async def main():
    """Run all KPI tests."""
    print("🚀 Starting KPI metrics tests...")
    
    try:
        await test_kpi_metrics_collection()
        await test_response_fit_heuristics()
        
        print("\n🎉 All KPI tests completed successfully!")
        return 0
        
    except Exception as e:
        print(f"\n❌ Test failed with error: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)