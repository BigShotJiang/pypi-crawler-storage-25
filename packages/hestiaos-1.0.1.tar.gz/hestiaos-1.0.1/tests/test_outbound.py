#!/usr/bin/env python3
"""
Isolated Outbound Test (Task 8)
Send a single test message "HestiaOS Test" to the configured Nextcloud Talk room.
"""
import asyncio
import httpx
import sys
import os
import json
from datetime import datetime

sys.path.insert(0, os.getcwd())

async def send_test_message():
    """Send a test message to Nextcloud Talk and show the API response."""
    print("=== Isolated Outbound Test (Task 8) ===\n")
    
    # Load configuration
    try:
        from core.config.legacy_adapter import LegacyConfigManager as ConfigManager
        cm = ConfigManager()
        nc_config = cm.get("nextcloud", {})
        
        if not nc_config:
            print("❌ Nextcloud configuration not found")
            return False
            
        url = nc_config.get("url", "").rstrip("/")
        user = nc_config.get("user", "")
        password = nc_config.get("password", "")
        rooms = nc_config.get("rooms", [])
        
        if not all([url, user, password]):
            print("❌ Missing required configuration (url, user, or password)")
            return False
            
        if not rooms:
            print("❌ No rooms configured")
            return False
            
        # Use first room token
        room_token = rooms[0] if isinstance(rooms[0], str) else rooms[0].get("token", rooms[0])
        print(f"Configuration loaded:")
        print(f"  URL: {url}")
        print(f"  User: {user}")
        print(f"  Room Token: {room_token}")
        print(f"  Password: {'*' * len(password)} (length: {len(password)})\n")
        
    except Exception as e:
        print(f"❌ Error loading configuration: {e}")
        return False
    
    # Prepare the test message
    test_message = "HestiaOS Test - Outbound verification at " + datetime.now().strftime("%H:%M:%S")
    
    # OCS API endpoint
    endpoint = f"{url}/ocs/v1.php/apps/spreed/api/v1/chat/{room_token}"
    
    headers = {
        "OCS-APIRequest": "true",
        "Accept": "application/json",
        "Content-Type": "application/json"
    }
    
    print(f"Sending test message to Nextcloud Talk...")
    print(f"  Endpoint: {endpoint}")
    print(f"  Message: '{test_message}'")
    
    try:
        async with httpx.AsyncClient(timeout=30.0, verify=False) as client:
            # First, let's check the room info
            print("\n1. Checking room info...")
            room_info_resp = await client.get(
                f"{url}/ocs/v1.php/apps/spreed/api/v1/rooms/{room_token}",
                headers={"OCS-APIRequest": "true", "Accept": "application/json"},
                auth=(user, password)
            )
            print(f"   Room info status: {room_info_resp.status_code}")
            if room_info_resp.status_code == 200:
                room_data = room_info_resp.json()
                room_name = room_data.get("ocs", {}).get("data", {}).get("displayName", "Unknown")
                print(f"   Room name: {room_name}")
            else:
                print(f"   Room info error: {room_info_resp.text[:100]}")
            
            # Send the test message
            print("\n2. Sending test message...")
            start_time = datetime.now()
            response = await client.post(
                endpoint,
                headers=headers,
                auth=(user, password),
                json={"message": test_message}
            )
            end_time = datetime.now()
            response_time = (end_time - start_time).total_seconds()
            
            print(f"   Response Status: {response.status_code}")
            print(f"   Response Time: {response_time:.2f} seconds")
            
            if response.status_code in [200, 201]:
                print("   ✅ Message sent successfully!")
                
                # Parse response
                try:
                    response_data = response.json()
                    print(f"   Response JSON: {json.dumps(response_data, indent=2)}")
                    
                    # Check for message ID
                    message_id = response_data.get("ocs", {}).get("data", {}).get("id")
                    if message_id:
                        print(f"   ✅ Message ID: {message_id}")
                    else:
                        print("   ⚠️  No message ID in response")
                        
                except Exception as e:
                    print(f"   ⚠️  Could not parse JSON response: {e}")
                    print(f"   Raw response: {response.text[:200]}")
                    
            else:
                print(f"   ❌ Failed to send message")
                print(f"   Error response: {response.text[:200]}")
                
            # Verify by fetching recent messages
            print("\n3. Verifying message was posted...")
            chat_resp = await client.get(
                f"{url}/ocs/v1.php/apps/spreed/api/v1/chat/{room_token}?limit=5",
                headers={"OCS-APIRequest": "true", "Accept": "application/json"},
                auth=(user, password)
            )
            
            if chat_resp.status_code == 200:
                chat_data = chat_resp.json()
                messages = chat_data.get("ocs", {}).get("data", [])
                print(f"   Found {len(messages)} recent messages")
                
                # Look for our test message
                found = False
                for msg in messages[:3]:  # Check most recent 3 messages
                    if test_message in msg.get("message", ""):
                        found = True
                        actor = msg.get("actorDisplayName", msg.get("actorId", "Unknown"))
                        msg_time = msg.get("timestamp", "")
                        print(f"   ✅ Found our test message!")
                        print(f"      Actor: {actor}")
                        print(f"      Time: {msg_time}")
                        print(f"      Message: '{msg.get('message', '')[:50]}...'")
                        break
                        
                if not found:
                    print("   ⚠️  Test message not found in recent messages (may be delayed)")
            else:
                print(f"   ⚠️  Could not verify: {chat_resp.status_code}")
                
            return response.status_code in [200, 201]
            
    except httpx.TimeoutException:
        print("❌ Request timed out after 30 seconds")
        return False
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        return False

async def test_plugin_outbound():
    """Test using the plugin directly"""
    print("\n=== Testing via Plugin Interface ===\n")
    
    try:
        from plugins.nextcloud_talk import NextcloudTalkPlugin
        
        plugin = NextcloudTalkPlugin()
        
        # Initialize plugin
        loop = asyncio.get_event_loop()
        await plugin.initialize()
        
        if not plugin.enabled:
            print("❌ Plugin not enabled")
            return False
            
        print(f"Plugin initialized:")
        print(f"  Server: {plugin.server_url}")
        print(f"  User: {plugin.username}")
        print(f"  Rooms: {list(plugin.rooms.keys())}")
        
        # Send test message using plugin
        test_message = "HestiaOS Plugin Test - " + datetime.now().strftime("%H:%M:%S")
        room_token = list(plugin.rooms.keys())[0]
        
        print(f"\nSending via plugin to room {room_token}...")
        success = await plugin._send_message(room_token, test_message)
        
        if success:
            print("✅ Plugin sent message successfully")
        else:
            print("❌ Plugin failed to send message")
            
        return success
        
    except Exception as e:
        print(f"❌ Plugin test error: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    print("=" * 60)
    print("Nextcloud Talk Outbound Test - Task 8")
    print("=" * 60)
    
    # Run both tests
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    
    print("\n[Test 1: Direct API Call]")
    api_success = loop.run_until_complete(send_test_message())
    
    print("\n[Test 2: Plugin Interface]")
    plugin_success = loop.run_until_complete(test_plugin_outbound())
    
    print("\n" + "=" * 60)
    print("Test Summary:")
    print(f"  Direct API: {'✅ PASS' if api_success else '❌ FAIL'}")
    print(f"  Plugin Interface: {'✅ PASS' if plugin_success else '❌ FAIL'}")
    
    if api_success and plugin_success:
        print("\n🎉 All outbound tests passed! Messages should appear in Nextcloud Talk.")
    else:
        print("\n⚠️  Some tests failed. Check configuration and network connectivity.")
    print("=" * 60)