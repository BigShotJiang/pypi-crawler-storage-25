#!/usr/bin/env python3
"""
Test Tool Result Budgeting implementation.

Tests the ToolResultBudgetManager class and its integration with
ToolExecutor and ToolGovernor.
"""

import pytest
import asyncio
import json
from unittest.mock import MagicMock, AsyncMock, patch
from datetime import datetime

# Import the budget manager
try:
    from core.tool_execution.budget_manager import (
        ToolResultBudgetManager,
        BudgetConfig,
        BudgetStrategy,
        ContentType,
        BudgetUsage
    )
    HAS_BUDGET_MANAGER = True
except ImportError as e:
    HAS_BUDGET_MANAGER = False
    pytest.skip(f"Budget manager not available: {e}", allow_module_level=True)


class TestToolResultBudgetManager:
    """Test the ToolResultBudgetManager class."""
    
    def test_budget_config_defaults(self):
        """Test default configuration."""
        config = BudgetConfig()
        assert config.default_max_tokens == 4000
        assert config.default_strategy == BudgetStrategy.TRUNCATE
        assert config.enforce_budget == True
        
    def test_budget_config_tool_overrides(self):
        """Test tool-specific configuration overrides."""
        config = BudgetConfig(
            tool_overrides={
                "read_file": {"max_tokens": 1000, "strategy": BudgetStrategy.REJECT},
                "write_file": {"max_tokens": 2000},
            }
        )
        
        read_config = config.get_tool_config("read_file")
        assert read_config["max_tokens"] == 1000
        assert read_config["strategy"] == BudgetStrategy.REJECT
        
        write_config = config.get_tool_config("write_file")
        assert write_config["max_tokens"] == 2000
        assert write_config["strategy"] == BudgetStrategy.TRUNCATE  # Default
        
        unknown_config = config.get_tool_config("unknown_tool")
        assert unknown_config["max_tokens"] == 4000  # Default
    
    def test_count_tokens(self):
        """Test token counting."""
        manager = ToolResultBudgetManager()
        
        # Test with string
        text = "Hello world"
        tokens = manager.count_tokens(text)
        assert tokens > 0
        
        # Test with dict
        data = {"key": "value", "list": [1, 2, 3]}
        tokens = manager.count_tokens(data)
        assert tokens > 0
        
        # Test with list
        tokens = manager.count_tokens([1, 2, 3, 4, 5])
        assert tokens > 0
    
    @pytest.mark.asyncio
    async def test_apply_budget_within_limit(self):
        """Test applying budget to result within token limit."""
        manager = ToolResultBudgetManager(
            BudgetConfig(default_max_tokens=10000)  # High limit
        )
        
        small_result = {"status": "success", "data": "Small result"}
        budgeted_result, usage = await manager.apply_budget(
            tool_name="test_tool",
            result=small_result,
            arguments={"param": "value"}
        )
        
        assert budgeted_result == small_result  # No change
        assert usage.original_tokens == usage.final_tokens
        assert usage.reduction_percent == 0.0
        assert not usage.was_truncated
    
    @pytest.mark.asyncio
    async def test_apply_budget_exceeds_limit_truncate(self):
        """Test truncation when result exceeds token limit."""
        manager = ToolResultBudgetManager(
            BudgetConfig(default_max_tokens=10)  # Very low limit
        )
        
        # Create a large result
        large_result = {"data": "This is a very long text that should exceed the token limit " * 10}
        budgeted_result, usage = await manager.apply_budget(
            tool_name="test_tool",
            result=large_result,
            arguments={}
        )
        
        assert usage.original_tokens > usage.final_tokens
        assert usage.reduction_percent > 0.0
        assert usage.was_truncated
        assert usage.strategy_used == BudgetStrategy.TRUNCATE
        
        # Result should be different (truncated)
        assert budgeted_result != large_result
    
    @pytest.mark.asyncio
    async def test_apply_budget_exceeds_limit_reject(self):
        """Test rejection strategy when result exceeds limit."""
        manager = ToolResultBudgetManager(
            BudgetConfig(
                default_max_tokens=10,
                default_strategy=BudgetStrategy.REJECT
            )
        )
        
        large_result = {"data": "Very long text " * 20}
        budgeted_result, usage = await manager.apply_budget(
            tool_name="test_tool",
            result=large_result,
            arguments={}
        )
        
        assert usage.was_truncated
        assert usage.strategy_used == BudgetStrategy.REJECT
        # Should return error object
        assert "error" in budgeted_result
        assert "Result exceeds budget" in budgeted_result.get("error", "")
    
    @pytest.mark.asyncio
    async def test_deterministic_caching(self):
        """Test deterministic caching of tool results."""
        manager = ToolResultBudgetManager(
            BudgetConfig(enforce_deterministic=True)
        )
        
        tool_name = "deterministic_tool"
        arguments = {"param": "value", "nested": {"key": "val"}}
        result = {"output": "result data"}
        
        # First execution
        budgeted_result1, usage1 = await manager.apply_budget(
            tool_name=tool_name,
            result=result,
            arguments=arguments
        )
        
        # Second execution with same arguments (should hit cache)
        budgeted_result2, usage2 = await manager.apply_budget(
            tool_name=tool_name,
            result=result,  # Same result
            arguments=arguments  # Same arguments
        )
        
        # Check that cache was used
        assert usage2.metadata.get("cache_hit", False) == True
        # Final tokens should be the same
        assert usage2.final_tokens == usage1.final_tokens
    
    @pytest.mark.asyncio
    async def test_get_usage_stats(self):
        """Test usage statistics collection."""
        manager = ToolResultBudgetManager()
        
        # Execute some tools
        for i in range(3):
            await manager.apply_budget(
                tool_name="tool_a",
                result={"data": f"result {i}"},
                arguments={"index": i}
            )
        
        for i in range(2):
            await manager.apply_budget(
                tool_name="tool_b",
                result={"data": "large result " * 100},
                arguments={}
            )
        
        # Get stats for tool_a
        stats_a = await manager.get_usage_stats("tool_a")
        assert stats_a["tool_name"] == "tool_a"
        assert stats_a["total_executions"] == 3
        
        # Get aggregate stats
        all_stats = await manager.get_usage_stats()
        assert all_stats["total_tools"] >= 2
        assert all_stats["total_executions"] == 5


class TestToolExecutorIntegration:
    """Test integration with ToolExecutor."""
    
    @pytest.mark.asyncio
    async def test_tool_executor_with_budget_manager(self):
        """Test that ToolExecutor applies budget management."""
        # Mock ToolManager
        mock_tool_manager = MagicMock()
        mock_tool_manager.execute_tool = AsyncMock(return_value={
            "success": True,
            "data": "This is a test result " * 1000,  # Large result
            "execution_time": 0.1
        })
        
        # Import and create ToolExecutor with budget manager
        from core.tool_executor import ToolExecutor
        from core.tool_execution.budget_manager import ToolResultBudgetManager
        
        budget_manager = ToolResultBudgetManager(
            BudgetConfig(default_max_tokens=100)  # Low limit to force truncation
        )
        
        executor = ToolExecutor(
            tool_manager=mock_tool_manager,
            budget_manager=budget_manager
        )
        
        # Execute a tool
        result = await executor.execute(
            tool_name="test_tool",
            arguments={"param": "value"},
            context={"session_id": "test_session"}
        )
        
        # Check that result has budget metadata
        assert "metadata" in result
        assert "budget_usage" in result["metadata"]
        budget_usage = result["metadata"]["budget_usage"]
        
        # Should have been truncated
        assert budget_usage["was_truncated"] == True
        assert budget_usage["reduction_percent"] > 0.0
    
    @pytest.mark.asyncio
    async def test_tool_executor_without_budget_manager(self):
        """Test ToolExecutor works without budget manager (backward compatibility)."""
        # Mock ToolManager
        mock_tool_manager = MagicMock()
        mock_tool_manager.execute_tool = AsyncMock(return_value={
            "success": True,
            "data": "Test result",
            "execution_time": 0.1
        })
        
        from core.tool_executor import ToolExecutor
        
        # Create executor without budget manager
        executor = ToolExecutor(tool_manager=mock_tool_manager)
        
        # Should work normally
        result = await executor.execute(
            tool_name="test_tool",
            arguments={},
            context={"session_id": "test"}
        )
        
        assert result["success"] == True
        # No budget metadata expected
        assert "metadata" not in result or "budget_usage" not in result.get("metadata", {})


class TestToolGovernorIntegration:
    """Test integration with ToolGovernor."""
    
    @pytest.mark.asyncio
    async def test_tool_governor_with_budget_manager(self):
        """Test that ToolGovernor applies budget management."""
        # Mock MCPGateway
        mock_gateway = MagicMock()
        mock_gateway._execute_local_tool = AsyncMock(return_value={
            "success": True,
            "data": "Large tool result " * 1000,
            "execution_time": 0.2
        })
        
        # Mock session state
        mock_session_state = MagicMock()
        mock_session_state.session_id = "test_session"
        mock_session_state.tenant_id = "test_tenant"
        mock_session_state.role = MagicMock()
        mock_session_state.role.name = "user"
        mock_session_state.capabilities = []
        
        # Import and create ToolGovernor with budget manager
        from core.routing.tool_governor import ToolGovernor
        from core.tool_execution.budget_manager import ToolResultBudgetManager, BudgetConfig
        
        budget_manager = ToolResultBudgetManager(
            BudgetConfig(default_max_tokens=100)  # Low limit
        )
        
        governor = ToolGovernor(
            mcp_gateway=mock_gateway,
            budget_manager=budget_manager
        )
        
        # Register an internal tool
        governor.internal_tools["test_tool"] = {"name": "test_tool"}
        
        # Execute tool
        result = await governor.execute_tool(
            tool_name="test_tool",
            arguments={"param": "value"},
            session_state=mock_session_state
        )
        
        # Check budget metadata
        assert "metadata" in result
        assert "budget_usage" in result["metadata"]
        assert result["metadata"]["budget_usage"]["was_truncated"] == True


if __name__ == "__main__":
    # Run tests
    import sys
    sys.exit(pytest.main([__file__, "-v"]))