"""
Tests für das Execution Graph IR (Intermediate Representation) Modul.

Testet:
- core/ir/models.py — Datenmodelle (ExecutionNode, ExecutionEdge, ExecutionGraphIR, GraphDiff)
- core/ir/builder.py — IRBuilder (from_nodes_and_edges, merge, add_node, add_edge, cycle detection)
- core/ir/diff.py — IRDiffEngine (compare, drift_score)
- core/ir/identity.py — IdentityGenerator, IdentityNormalizer
"""

import sys
import os
import pytest
from datetime import datetime, timezone
from dataclasses import FrozenInstanceError

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from core.ir.models import (
    NodeType,
    EdgeType,
    DiffType,
    ExecutionNode,
    ExecutionEdge,
    ExecutionGraphIR,
    DiffEntry,
    GraphDiff,
)
from core.ir.builder import IRBuilder
from core.ir.diff import IRDiffEngine
from core.ir.identity import IdentityGenerator, IdentityNormalizer


# =============================================================================
# Fixtures
# =============================================================================

@pytest.fixture
def builder():
    return IRBuilder()


@pytest.fixture
def diff_engine():
    return IRDiffEngine()


@pytest.fixture
def ts():
    return datetime.now(timezone.utc).isoformat()


# =============================================================================
# MODELS — ExecutionNode
# =============================================================================

class TestExecutionNode:
    def test_create_minimal(self):
        node = ExecutionNode(node_id="test:1", node_type=NodeType.STATE, label="Test")
        assert node.node_id == "test:1"
        assert node.node_type == NodeType.STATE
        assert node.label == "Test"
        assert node.metadata == {}
        assert node.timestamp is None
        assert node.duration_ms == 0
        assert node.success is True

    def test_create_full(self):
        node = ExecutionNode(
            node_id="test:full",
            node_type=NodeType.COMPONENT,
            label="Full Component",
            metadata={"version": "1.0", "author": "test"},
            timestamp="2025-01-01T00:00:00",
            duration_ms=1500,
            success=True,
        )
        assert node.node_id == "test:full"
        assert node.metadata["version"] == "1.0"
        assert node.duration_ms == 1500
        assert node.success is True

    def test_immutable(self):
        node = ExecutionNode(node_id="test:imm", node_type=NodeType.DECISION, label="Imm")
        with pytest.raises(FrozenInstanceError):
            node.node_id = "changed"

    def test_all_node_types(self):
        for nt in NodeType:
            node = ExecutionNode(node_id=f"test:{nt.value}", node_type=nt, label=nt.value)
            assert node.node_type == nt

    def test_to_dict(self):
        node = ExecutionNode(
            node_id="n:1", node_type=NodeType.STATE, label="Test",
            metadata={"key": "val"}, timestamp="2025-01-01T00:00:00",
            duration_ms=100, success=True,
        )
        d = node.to_dict()
        assert d["node_id"] == "n:1"
        assert d["node_type"] == "state"
        assert d["label"] == "Test"
        assert d["metadata"]["key"] == "val"
        assert d["duration_ms"] == 100

    def test_from_dict(self):
        data = {
            "node_id": "n:1",
            "node_type": "state",
            "label": "Test",
            "metadata": {"key": "val"},
            "timestamp": "2025-01-01T00:00:00",
            "duration_ms": 100,
            "success": True,
        }
        node = ExecutionNode.from_dict(data)
        assert node.node_id == "n:1"
        assert node.node_type == NodeType.STATE
        assert node.duration_ms == 100


# =============================================================================
# MODELS — ExecutionEdge
# =============================================================================

class TestExecutionEdge:
    def test_create_minimal(self):
        edge = ExecutionEdge(source_id="src:1", target_id="tgt:1", edge_type=EdgeType.SEQUENCE)
        assert edge.source_id == "src:1"
        assert edge.target_id == "tgt:1"
        assert edge.edge_type == EdgeType.SEQUENCE
        assert edge.metadata == {}
        assert edge.weight == 1.0

    def test_create_with_weight(self):
        edge = ExecutionEdge(
            source_id="a", target_id="b",
            edge_type=EdgeType.DEPENDENCY,
            weight=0.75,
            metadata={"critical": True},
        )
        assert edge.weight == 0.75
        assert edge.metadata["critical"] is True

    def test_immutable(self):
        edge = ExecutionEdge(source_id="s", target_id="t", edge_type=EdgeType.CAUSALITY)
        with pytest.raises(FrozenInstanceError):
            edge.source_id = "changed"

    def test_to_dict_from_dict(self):
        edge = ExecutionEdge(
            source_id="a", target_id="b", edge_type=EdgeType.COMPOSITION,
            weight=0.5, metadata={"key": "val"},
        )
        d = edge.to_dict()
        restored = ExecutionEdge.from_dict(d)
        assert restored.source_id == edge.source_id
        assert restored.target_id == edge.target_id
        assert restored.edge_type == edge.edge_type
        assert restored.weight == edge.weight


# =============================================================================
# MODELS — ExecutionGraphIR
# =============================================================================

class TestExecutionGraphIR:
    def test_empty_graph(self, ts):
        graph = ExecutionGraphIR(graph_id="empty", source="test", timestamp=ts)
        assert graph.node_count == 0
        assert graph.edge_count == 0
        assert graph.entry_points == []
        assert graph.has_cycles is False
        assert graph.content_hash is not None

    def test_single_node_graph(self, ts):
        node = ExecutionNode(node_id="n:1", node_type=NodeType.STATE, label="Start")
        graph = ExecutionGraphIR(
            graph_id="single", source="test", timestamp=ts,
            nodes={"n:1": node},
        )
        assert graph.node_count == 1

    def test_graph_with_edges(self, ts):
        nodes = {
            "n:1": ExecutionNode(node_id="n:1", node_type=NodeType.STATE, label="A"),
            "n:2": ExecutionNode(node_id="n:2", node_type=NodeType.STATE, label="B"),
        }
        edges = [ExecutionEdge(source_id="n:1", target_id="n:2", edge_type=EdgeType.SEQUENCE)]
        graph = ExecutionGraphIR(
            graph_id="edge_test", source="test", timestamp=ts,
            nodes=nodes, edges=edges,
        )
        assert graph.node_count == 2
        assert graph.edge_count == 1

    def test_get_node(self, ts):
        nodes = {
            "n:1": ExecutionNode(node_id="n:1", node_type=NodeType.STATE, label="A"),
            "n:2": ExecutionNode(node_id="n:2", node_type=NodeType.DECISION, label="B"),
        }
        graph = ExecutionGraphIR(graph_id="get", source="test", timestamp=ts, nodes=nodes)
        assert graph.get_node("n:2") is not None
        assert graph.get_node("n:2").label == "B"
        assert graph.get_node("nonexistent") is None

    def test_get_edges_from_to(self, ts):
        nodes = {
            "n:1": ExecutionNode(node_id="n:1", node_type=NodeType.STATE, label="A"),
            "n:2": ExecutionNode(node_id="n:2", node_type=NodeType.STATE, label="B"),
            "n:3": ExecutionNode(node_id="n:3", node_type=NodeType.STATE, label="C"),
        }
        edges = [
            ExecutionEdge(source_id="n:1", target_id="n:2", edge_type=EdgeType.SEQUENCE),
            ExecutionEdge(source_id="n:1", target_id="n:3", edge_type=EdgeType.SEQUENCE),
            ExecutionEdge(source_id="n:2", target_id="n:3", edge_type=EdgeType.DEPENDENCY),
        ]
        graph = ExecutionGraphIR(graph_id="edges", source="test", timestamp=ts, nodes=nodes, edges=edges)
        assert len(graph.get_edges_from("n:1")) == 2
        assert len(graph.get_edges_to("n:3")) == 2
        assert len(graph.get_edges_from("n:3")) == 0

    def test_get_successors_predecessors(self, ts):
        nodes = {
            "n:1": ExecutionNode(node_id="n:1", node_type=NodeType.STATE, label="A"),
            "n:2": ExecutionNode(node_id="n:2", node_type=NodeType.STATE, label="B"),
        }
        edges = [ExecutionEdge(source_id="n:1", target_id="n:2", edge_type=EdgeType.SEQUENCE)]
        graph = ExecutionGraphIR(graph_id="succ", source="test", timestamp=ts, nodes=nodes, edges=edges)
        assert graph.get_successors("n:1") == ["n:2"]
        assert graph.get_predecessors("n:2") == ["n:1"]

    def test_to_dict_from_dict_roundtrip(self, ts):
        nodes = {
            "n:1": ExecutionNode(node_id="n:1", node_type=NodeType.STATE, label="A",
                                  metadata={"key": "val"}, duration_ms=500, success=True),
            "n:2": ExecutionNode(node_id="n:2", node_type=NodeType.COMPONENT, label="B"),
        }
        edges = [ExecutionEdge(source_id="n:1", target_id="n:2", edge_type=EdgeType.SEQUENCE)]
        graph = ExecutionGraphIR(graph_id="rt", source="test", timestamp=ts, nodes=nodes, edges=edges)
        d = graph.to_dict()
        restored = ExecutionGraphIR.from_dict(d)
        assert restored.graph_id == graph.graph_id
        assert restored.node_count == graph.node_count
        assert restored.edge_count == graph.edge_count
        assert restored.content_hash == graph.content_hash
        assert restored.get_node("n:2") is not None

    def test_content_hash_changes_on_modification(self, ts):
        nodes_a = {"n:1": ExecutionNode(node_id="n:1", node_type=NodeType.STATE, label="A")}
        nodes_b = {"n:1": ExecutionNode(node_id="n:1", node_type=NodeType.STATE, label="B")}
        g_a = ExecutionGraphIR(graph_id="a", source="test", timestamp=ts, nodes=nodes_a)
        g_b = ExecutionGraphIR(graph_id="b", source="test", timestamp=ts, nodes=nodes_b)
        assert g_a.content_hash != g_b.content_hash


# =============================================================================
# MODELS — GraphDiff
# =============================================================================

class TestGraphDiff:
    def test_empty_diff(self):
        diff = GraphDiff(source_graph_id="g1", target_graph_id="g2", drift_score=0.0, entries=[])
        assert diff.drift_score == 0.0
        assert diff.has_changes is False
        assert diff.added_nodes == []
        assert diff.removed_nodes == []
        assert diff.modified_nodes == []

    def test_diff_with_entries(self):
        entries = [
            DiffEntry(diff_type=DiffType.NODE_ADDED, node_id="n:new",
                      description="Node added"),
            DiffEntry(diff_type=DiffType.NODE_REMOVED, node_id="n:old",
                      description="Node removed"),
        ]
        diff = GraphDiff(source_graph_id="g1", target_graph_id="g2", drift_score=0.5, entries=entries)
        assert diff.has_changes is True
        assert len(diff.added_nodes) == 1
        assert diff.added_nodes[0].node_id == "n:new"
        assert len(diff.removed_nodes) == 1
        assert diff.removed_nodes[0].node_id == "n:old"


# =============================================================================
# BUILDER — IRBuilder
# =============================================================================

class TestIRBuilder:
    def test_from_nodes_and_edges_basic(self, builder):
        nodes = [
            ExecutionNode(node_id="n:1", node_type=NodeType.STATE, label="A"),
            ExecutionNode(node_id="n:2", node_type=NodeType.STATE, label="B"),
        ]
        edges = [ExecutionEdge(source_id="n:1", target_id="n:2", edge_type=EdgeType.SEQUENCE)]
        graph = builder.from_nodes_and_edges(nodes, edges, source="test", graph_id="g1")
        assert graph.node_count == 2
        assert graph.edge_count == 1

    def test_strict_missing_target(self, builder):
        nodes = [ExecutionNode(node_id="n:1", node_type=NodeType.STATE, label="A")]
        edges = [ExecutionEdge(source_id="n:1", target_id="n:missing", edge_type=EdgeType.SEQUENCE)]
        with pytest.raises(ValueError, match="Edge target.*not found"):
            builder.from_nodes_and_edges(nodes, edges, source="test", graph_id="g2", strict=True)

    def test_non_strict_missing_target(self, builder):
        nodes = [ExecutionNode(node_id="n:1", node_type=NodeType.STATE, label="A")]
        edges = [ExecutionEdge(source_id="n:1", target_id="n:missing", edge_type=EdgeType.SEQUENCE)]
        graph = builder.from_nodes_and_edges(nodes, edges, source="test", graph_id="g3", strict=False)
        assert graph.node_count == 1
        assert graph.edge_count == 0

    def test_non_strict_missing_source(self, builder):
        nodes = [ExecutionNode(node_id="n:1", node_type=NodeType.STATE, label="A")]
        edges = [ExecutionEdge(source_id="n:missing", target_id="n:1", edge_type=EdgeType.SEQUENCE)]
        graph = builder.from_nodes_and_edges(nodes, edges, source="test", graph_id="g4", strict=False)
        assert graph.node_count == 1
        assert graph.edge_count == 0

    def test_empty_graph(self, builder):
        graph = builder.empty(source="test", graph_id="empty")
        assert graph.node_count == 0
        assert graph.edge_count == 0

    def test_add_node(self, builder):
        base = builder.empty(source="test", graph_id="add")
        node = ExecutionNode(node_id="n:1", node_type=NodeType.STATE, label="New")
        graph = builder.add_node(base, node)
        assert graph.node_count == 1
        assert graph.get_node("n:1") is not None
        assert base.node_count == 0

    def test_add_edge(self, builder):
        nodes = [
            ExecutionNode(node_id="n:1", node_type=NodeType.STATE, label="A"),
            ExecutionNode(node_id="n:2", node_type=NodeType.STATE, label="B"),
        ]
        base = builder.from_nodes_and_edges(nodes, [], source="test", graph_id="add_edge")
        edge = ExecutionEdge(source_id="n:1", target_id="n:2", edge_type=EdgeType.SEQUENCE)
        graph = builder.add_edge(base, edge)
        assert graph.edge_count == 1

    def test_remove_node(self, builder):
        nodes = [
            ExecutionNode(node_id="n:1", node_type=NodeType.STATE, label="A"),
            ExecutionNode(node_id="n:2", node_type=NodeType.STATE, label="B"),
        ]
        edges = [ExecutionEdge(source_id="n:1", target_id="n:2", edge_type=EdgeType.SEQUENCE)]
        base = builder.from_nodes_and_edges(nodes, edges, source="test", graph_id="rm")
        graph = builder.remove_node(base, "n:1")
        assert graph.node_count == 1
        assert graph.edge_count == 0

    def test_cycle_detection(self, builder):
        nodes = [
            ExecutionNode(node_id="n:1", node_type=NodeType.STATE, label="A"),
            ExecutionNode(node_id="n:2", node_type=NodeType.STATE, label="B"),
            ExecutionNode(node_id="n:3", node_type=NodeType.STATE, label="C"),
        ]
        edges = [
            ExecutionEdge(source_id="n:1", target_id="n:2", edge_type=EdgeType.SEQUENCE),
            ExecutionEdge(source_id="n:2", target_id="n:3", edge_type=EdgeType.SEQUENCE),
            ExecutionEdge(source_id="n:3", target_id="n:1", edge_type=EdgeType.SEQUENCE),
        ]
        graph = builder.from_nodes_and_edges(nodes, edges, source="test", graph_id="cycle")
        assert graph.has_cycles is True

    def test_no_cycle_dag(self, builder):
        nodes = [
            ExecutionNode(node_id="n:1", node_type=NodeType.STATE, label="A"),
            ExecutionNode(node_id="n:2", node_type=NodeType.STATE, label="B"),
            ExecutionNode(node_id="n:3", node_type=NodeType.STATE, label="C"),
        ]
        edges = [
            ExecutionEdge(source_id="n:1", target_id="n:2", edge_type=EdgeType.SEQUENCE),
            ExecutionEdge(source_id="n:2", target_id="n:3", edge_type=EdgeType.SEQUENCE),
        ]
        graph = builder.from_nodes_and_edges(nodes, edges, source="test", graph_id="dag")
        assert graph.has_cycles is False

    def test_merge_first_wins(self, builder):
        nodes_a = [ExecutionNode(node_id="n:1", node_type=NodeType.STATE, label="FromA")]
        nodes_b = [ExecutionNode(node_id="n:1", node_type=NodeType.STATE, label="FromB")]
        g_a = builder.from_nodes_and_edges(nodes_a, [], source="a", graph_id="a")
        g_b = builder.from_nodes_and_edges(nodes_b, [], source="b", graph_id="b")
        merged = builder.merge([g_a, g_b], source="merge", graph_id="m1",
                               conflict_strategy="first_wins")
        assert merged.get_node("n:1").label == "FromA"

    def test_merge_last_wins(self, builder):
        nodes_a = [ExecutionNode(node_id="n:1", node_type=NodeType.STATE, label="FromA")]
        nodes_b = [ExecutionNode(node_id="n:1", node_type=NodeType.STATE, label="FromB")]
        g_a = builder.from_nodes_and_edges(nodes_a, [], source="a", graph_id="a")
        g_b = builder.from_nodes_and_edges(nodes_b, [], source="b", graph_id="b")
        merged = builder.merge([g_a, g_b], source="merge", graph_id="m2",
                               conflict_strategy="last_wins")
        assert merged.get_node("n:1").label == "FromB"

    def test_node_id_conflict_different_type(self, builder):
        nodes = [
            ExecutionNode(node_id="n:1", node_type=NodeType.STATE, label="A"),
            ExecutionNode(node_id="n:1", node_type=NodeType.COMPONENT, label="B"),
        ]
        with pytest.raises(ValueError, match="Node-ID-Konflikt"):
            builder.from_nodes_and_edges(nodes, [], source="test", graph_id="conflict")


# =============================================================================
# DIFF — IRDiffEngine
# =============================================================================

class TestIRDiffEngine:
    def test_identical_graphs(self, builder, diff_engine):
        nodes = [ExecutionNode(node_id="n:1", node_type=NodeType.STATE, label="A")]
        g1 = builder.from_nodes_and_edges(nodes, [], source="test", graph_id="g1")
        g2 = builder.from_nodes_and_edges(nodes, [], source="test", graph_id="g2")
        diff = diff_engine.compare(g1, g2)
        assert diff.drift_score == 0.0
        assert diff.has_changes is False

    def test_added_node(self, builder, diff_engine):
        nodes1 = [ExecutionNode(node_id="n:1", node_type=NodeType.STATE, label="A")]
        nodes2 = [
            ExecutionNode(node_id="n:1", node_type=NodeType.STATE, label="A"),
            ExecutionNode(node_id="n:2", node_type=NodeType.STATE, label="B"),
        ]
        g1 = builder.from_nodes_and_edges(nodes1, [], source="test", graph_id="g1")
        g2 = builder.from_nodes_and_edges(nodes2, [], source="test", graph_id="g2")
        diff = diff_engine.compare(g1, g2)
        assert diff.drift_score > 0.0
        assert len(diff.added_nodes) == 1
        assert diff.added_nodes[0].node_id == "n:2"

    def test_removed_node(self, builder, diff_engine):
        nodes1 = [
            ExecutionNode(node_id="n:1", node_type=NodeType.STATE, label="A"),
            ExecutionNode(node_id="n:2", node_type=NodeType.STATE, label="B"),
        ]
        nodes2 = [ExecutionNode(node_id="n:1", node_type=NodeType.STATE, label="A")]
        g1 = builder.from_nodes_and_edges(nodes1, [], source="test", graph_id="g1")
        g2 = builder.from_nodes_and_edges(nodes2, [], source="test", graph_id="g2")
        diff = diff_engine.compare(g1, g2)
        assert diff.drift_score > 0.0
        assert len(diff.removed_nodes) == 1
        assert diff.removed_nodes[0].node_id == "n:2"

    def test_modified_node(self, builder, diff_engine):
        nodes1 = [ExecutionNode(node_id="n:1", node_type=NodeType.STATE, label="A")]
        nodes2 = [ExecutionNode(node_id="n:1", node_type=NodeType.STATE, label="B")]
        g1 = builder.from_nodes_and_edges(nodes1, [], source="test", graph_id="g1")
        g2 = builder.from_nodes_and_edges(nodes2, [], source="test", graph_id="g2")
        diff = diff_engine.compare(g1, g2)
        assert diff.drift_score > 0.0
        assert len(diff.modified_nodes) == 1
        assert diff.modified_nodes[0].node_id == "n:1"

    def test_added_edge(self, builder, diff_engine):
        nodes = [
            ExecutionNode(node_id="n:1", node_type=NodeType.STATE, label="A"),
            ExecutionNode(node_id="n:2", node_type=NodeType.STATE, label="B"),
        ]
        g1 = builder.from_nodes_and_edges(nodes, [], source="test", graph_id="g1")
        edges = [ExecutionEdge(source_id="n:1", target_id="n:2", edge_type=EdgeType.SEQUENCE)]
        g2 = builder.from_nodes_and_edges(nodes, edges, source="test", graph_id="g2")
        diff = diff_engine.compare(g1, g2)
        assert diff.drift_score > 0.0

    def test_drift_score_range(self, builder, diff_engine):
        nodes1 = [ExecutionNode(node_id="n:1", node_type=NodeType.STATE, label="A")]
        nodes2 = [
            ExecutionNode(node_id=f"n:{i}", node_type=NodeType.STATE, label=f"Node{i}")
            for i in range(10)
        ]
        g1 = builder.from_nodes_and_edges(nodes1, [], source="test", graph_id="g1")
        g2 = builder.from_nodes_and_edges(nodes2, [], source="test", graph_id="g2")
        diff = diff_engine.compare(g1, g2)
        assert 0.0 <= diff.drift_score <= 1.0

    def test_content_hash_diff(self, builder, diff_engine):
        nodes1 = [ExecutionNode(node_id="n:1", node_type=NodeType.STATE, label="A")]
        nodes2 = [ExecutionNode(node_id="n:1", node_type=NodeType.STATE, label="B")]
        g1 = builder.from_nodes_and_edges(nodes1, [], source="test", graph_id="g1")
        g2 = builder.from_nodes_and_edges(nodes2, [], source="test", graph_id="g2")
        diff = diff_engine.compare(g1, g2)
        content_hash_entries = [e for e in diff.entries if e.diff_type == DiffType.CONTENT_HASH_CHANGED]
        assert len(content_hash_entries) > 0


# =============================================================================
# IDENTITY — IdentityGenerator & IdentityNormalizer
# =============================================================================

class TestIdentityGenerator:
    def test_for_document(self):
        id1 = IdentityGenerator.for_document("project_work/roadmap.md")
        id2 = IdentityGenerator.for_document("project_work/roadmap.md")
        assert id1 == id2
        assert id1.startswith("doc:")
        assert "roadmap" in id1

    def test_for_roadmap(self):
        rid = IdentityGenerator.for_roadmap("Governance Evolution")
        assert rid.startswith("roadmap:")
        assert "governance" in rid

    def test_for_rule(self):
        rid = IdentityGenerator.for_rule("ADR-Gesetz")
        assert rid.startswith("rule:")
        assert "adr" in rid

    def test_for_phase(self):
        pid = IdentityGenerator.for_phase("Phase 1: VDP Hardening")
        assert pid.startswith("phase:")
        assert "phase_1" in pid

    def test_for_milestone(self):
        mid = IdentityGenerator.for_milestone("IR Implementierung")
        assert mid.startswith("milestone:")
        assert "ir" in mid

    def test_for_state(self):
        sid = IdentityGenerator.for_state("Boot State")
        assert sid.startswith("state:")

    def test_for_component(self):
        cid = IdentityGenerator.for_component("SyncEngine")
        assert cid.startswith("component:")

    def test_content_hash(self):
        h1 = IdentityGenerator.content_hash("Hello World")
        h2 = IdentityGenerator.content_hash("Hello World")
        h3 = IdentityGenerator.content_hash("Different Content")
        assert h1 == h2
        assert h1 != h3
        assert len(h1) == 16

    def test_for_transition(self):
        tid = IdentityGenerator.for_transition("init_persistence")
        assert tid.startswith("transition:")

    def test_for_decision(self):
        did = IdentityGenerator.for_decision("allow_access")
        assert did.startswith("decision:")

    def test_for_trace(self):
        tid = IdentityGenerator.for_trace("cmd_001")
        assert tid.startswith("trace:")


class TestIdentityNormalizer:
    def test_normalize_id(self):
        result = IdentityNormalizer.normalize_id("Phase 1: VDP Hardening")
        assert ":" in result
        assert result == "phase_1:_vdp_hardening"

    def test_extract_prefix(self):
        assert IdentityNormalizer.extract_prefix("doc:roadmap") == "doc"
        assert IdentityNormalizer.extract_prefix("invalid") is None

    def test_extract_name(self):
        assert IdentityNormalizer.extract_name("doc:roadmap") == "roadmap"

    def test_is_valid_id(self):
        assert IdentityNormalizer.is_valid_id("doc:roadmap") is True
        assert IdentityNormalizer.is_valid_id("invalid") is False
        assert IdentityNormalizer.is_valid_id("") is False

    def test_prefix_to_node_type(self):
        assert IdentityNormalizer.prefix_to_node_type("doc") == "DOCUMENT"
        assert IdentityNormalizer.prefix_to_node_type("roadmap") == "ROADMAP"
        assert IdentityNormalizer.prefix_to_node_type("rule") == "RULE"
        assert IdentityNormalizer.prefix_to_node_type("unknown") is None

    def test_is_valid_id_with_path(self):
        assert IdentityNormalizer.is_valid_id("doc:architecture/runtime_modes") is True


# =============================================================================
# INTEGRATION — Builder + Diff + Identity
# =============================================================================

class TestIRIntegration:
    def test_builder_diff_roundtrip(self, builder, diff_engine):
        nodes1 = [ExecutionNode(node_id="n:1", node_type=NodeType.STATE, label="A")]
        g1 = builder.from_nodes_and_edges(nodes1, [], source="test", graph_id="g1")
        node2 = ExecutionNode(node_id="n:2", node_type=NodeType.STATE, label="B")
        g2 = builder.add_node(g1, node2)
        diff = diff_engine.compare(g1, g2)
        assert diff.has_changes is True
        assert len(diff.added_nodes) == 1
        assert diff.added_nodes[0].node_id == "n:2"

    def test_identity_builder_integration(self, builder):
        doc_id = IdentityGenerator.for_document("project_work/roadmap.md")
        phase_id = IdentityGenerator.for_phase("Phase 1")
        nodes = [
            ExecutionNode(node_id=doc_id, node_type=NodeType.DOCUMENT, label="Roadmap"),
            ExecutionNode(node_id=phase_id, node_type=NodeType.PHASE, label="Phase 1"),
        ]
        edges = [ExecutionEdge(source_id=doc_id, target_id=phase_id, edge_type=EdgeType.COMPOSITION)]
        graph = builder.from_nodes_and_edges(nodes, edges, source="test", graph_id="identity_test")
        assert graph.node_count == 2
        assert graph.edge_count == 1
        assert graph.has_cycles is False

    def test_snapshot_roundtrip(self, builder):
        nodes = [
            ExecutionNode(node_id="n:1", node_type=NodeType.STATE, label="A",
                          metadata={"key": "value"}, duration_ms=100, success=True),
            ExecutionNode(node_id="n:2", node_type=NodeType.DECISION, label="B"),
        ]
        edges = [ExecutionEdge(source_id="n:1", target_id="n:2", edge_type=EdgeType.SEQUENCE,
                               weight=0.5, metadata={"critical": True})]
        original = builder.from_nodes_and_edges(nodes, edges, source="test", graph_id="snap")
        data = original.to_dict()
        restored = ExecutionGraphIR.from_dict(data)
        assert original.graph_id == restored.graph_id
        assert original.node_count == restored.node_count
        assert original.edge_count == restored.edge_count
        assert original.content_hash == restored.content_hash
        orig_node = original.get_node("n:1")
        rest_node = restored.get_node("n:1")
        assert orig_node.metadata == rest_node.metadata
        assert orig_node.duration_ms == rest_node.duration_ms
        assert orig_node.success == rest_node.success
