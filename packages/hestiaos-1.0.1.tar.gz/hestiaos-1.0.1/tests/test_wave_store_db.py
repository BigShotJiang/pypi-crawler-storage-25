"""
Tests for WaveStore with SQLite database backend.
"""
import pytest
import tempfile
import os
from datetime import datetime
from uuid import uuid4

from core.protocol.wave import Wave, WaveState
from core.protocol.wave_store import WaveStore


@pytest.fixture
def temp_db():
    """Create a temporary database for testing."""
    with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
        db_path = f.name
    yield db_path
    # Cleanup
    if os.path.exists(db_path):
        os.unlink(db_path)


@pytest.fixture
def wave_store(temp_db):
    """Create a WaveStore instance with temporary database."""
    return WaveStore(db_path=temp_db)


@pytest.fixture
def sample_wave():
    """Create a sample wave for testing."""
    return Wave(
        tenant_id="test-tenant",
        created_by="test-user",
        flags={"purpose": "test"},
        approvals={}
    )


class TestWaveStoreDatabase:
    """Test WaveStore with SQLite database."""
    
    def test_init_creates_tables(self, temp_db):
        """Test that WaveStore initializes database tables."""
        store = WaveStore(db_path=temp_db)
        
        # Verify tables exist by trying to insert data
        wave = Wave(tenant_id="t1", created_by="u1")
        store.create_wave(wave)
        
        # Should not raise any errors
        assert True
    
    def test_create_wave(self, wave_store, sample_wave):
        """Test creating a wave in the database."""
        created_wave = wave_store.create_wave(sample_wave)
        
        # Verify wave was created
        assert created_wave.wave_id == sample_wave.wave_id
        assert created_wave.tenant_id == "test-tenant"
        assert created_wave.state == WaveState.CREATED
        
        # Verify can retrieve it
        retrieved = wave_store.get_wave(created_wave.wave_id)
        assert retrieved is not None
        assert retrieved.wave_id == created_wave.wave_id
        assert retrieved.tenant_id == created_wave.tenant_id
    
    def test_get_wave_with_tenant_validation(self, wave_store, sample_wave):
        """Test retrieving a wave with tenant validation."""
        created_wave = wave_store.create_wave(sample_wave)
        
        # Should find with correct tenant
        retrieved = wave_store.get_wave(created_wave.wave_id, tenant_id="test-tenant")
        assert retrieved is not None
        
        # Should not find with wrong tenant
        not_found = wave_store.get_wave(created_wave.wave_id, tenant_id="wrong-tenant")
        assert not_found is None
    
    def test_update_wave(self, wave_store, sample_wave):
        """Test updating a wave's state."""
        created_wave = wave_store.create_wave(sample_wave)
        
        # Transition state
        created_wave.transition(WaveState.PROPAGATION_PENDING)
        created_wave.approve("propagation", actor="admin")
        
        # Update in database
        updated_wave = wave_store.update_wave(created_wave)
        
        # Verify update
        assert updated_wave.state == WaveState.PROPAGATION_PENDING
        assert "propagation" in updated_wave.approvals
        
        # Verify retrieval reflects update
        retrieved = wave_store.get_wave(created_wave.wave_id)
        assert retrieved.state == WaveState.PROPAGATION_PENDING
        assert "propagation" in retrieved.approvals
    
    def test_update_wave_tenant_mismatch(self, wave_store, sample_wave):
        """Test that updating with wrong tenant fails."""
        created_wave = wave_store.create_wave(sample_wave)
        
        # Try to update with modified tenant (should fail)
        created_wave.tenant_id = "wrong-tenant"
        created_wave.transition(WaveState.PROPAGATION_PENDING)
        
        with pytest.raises(ValueError, match="not found or tenant mismatch"):
            wave_store.update_wave(created_wave)
    
    def test_list_waves(self, wave_store):
        """Test listing waves for a tenant."""
        tenant_id = "tenant-a"
        
        # Create multiple waves for tenant-a
        for i in range(3):
            wave = Wave(tenant_id=tenant_id, created_by=f"user-{i}")
            wave_store.create_wave(wave)
        
        # Create waves for different tenant
        other_wave = Wave(tenant_id="tenant-b", created_by="user-x")
        wave_store.create_wave(other_wave)
        
        # List waves for tenant-a
        waves = wave_store.list_waves(tenant_id=tenant_id)
        assert len(waves) == 3
        for wave in waves:
            assert wave.tenant_id == tenant_id
        
        # List with state filter
        waves = wave_store.list_waves(tenant_id=tenant_id, state=WaveState.CREATED)
        assert len(waves) == 3
        
        # List for tenant-b
        waves = wave_store.list_waves(tenant_id="tenant-b")
        assert len(waves) == 1
        assert waves[0].tenant_id == "tenant-b"
    
    def test_list_waves_pagination(self, wave_store):
        """Test pagination in list_waves."""
        tenant_id = "tenant-pagination"
        
        # Create 5 waves
        for i in range(5):
            wave = Wave(tenant_id=tenant_id, created_by=f"user-{i}")
            wave_store.create_wave(wave)
        
        # Get first 2
        page1 = wave_store.list_waves(tenant_id=tenant_id, limit=2, offset=0)
        assert len(page1) == 2
        
        # Get next 2
        page2 = wave_store.list_waves(tenant_id=tenant_id, limit=2, offset=2)
        assert len(page2) == 2
        
        # Get remaining 1
        page3 = wave_store.list_waves(tenant_id=tenant_id, limit=2, offset=4)
        assert len(page3) == 1
        
        # Verify all waves are distinct
        all_waves = page1 + page2 + page3
        wave_ids = {w.wave_id for w in all_waves}
        assert len(wave_ids) == 5
    
    def test_delete_wave(self, wave_store, sample_wave):
        """Test deleting a wave."""
        created_wave = wave_store.create_wave(sample_wave)
        
        # Should be able to delete CREATED wave
        deleted = wave_store.delete_wave(created_wave.wave_id, tenant_id="test-tenant")
        assert deleted is True
        
        # Verify wave is gone
        retrieved = wave_store.get_wave(created_wave.wave_id)
        assert retrieved is None
    
    def test_delete_wave_wrong_tenant(self, wave_store, sample_wave):
        """Test that deleting with wrong tenant fails."""
        created_wave = wave_store.create_wave(sample_wave)
        
        # Wrong tenant should not delete
        deleted = wave_store.delete_wave(created_wave.wave_id, tenant_id="wrong-tenant")
        assert deleted is False
        
        # Wave should still exist
        retrieved = wave_store.get_wave(created_wave.wave_id)
        assert retrieved is not None
    
    def test_delete_immutable_wave(self, wave_store, sample_wave):
        """Test that immutable waves cannot be deleted."""
        created_wave = wave_store.create_wave(sample_wave)
        
        # Transition to COMMITTED (immutable)
        created_wave.transition(WaveState.PROPAGATION_PENDING)
        created_wave.approve("propagation", actor="admin")
        created_wave.transition(WaveState.PROPAGATED)
        created_wave.transition(WaveState.SYNC_PENDING)
        created_wave.approve("synchronization", actor="admin")
        created_wave.transition(WaveState.COMMITTED)
        
        wave_store.update_wave(created_wave)
        
        # Should not be able to delete COMMITTED wave
        deleted = wave_store.delete_wave(created_wave.wave_id, tenant_id="test-tenant")
        assert deleted is False
        
        # Wave should still exist
        retrieved = wave_store.get_wave(created_wave.wave_id)
        assert retrieved is not None
        assert retrieved.state == WaveState.COMMITTED
    
    def test_get_wave_events(self, wave_store, sample_wave):
        """Test retrieving audit trail for a wave."""
        created_wave = wave_store.create_wave(sample_wave)
        
        # Make some state transitions
        created_wave.transition(WaveState.PROPAGATION_PENDING)
        created_wave.approve("propagation", actor="admin")
        wave_store.update_wave(created_wave)
        
        created_wave.transition(WaveState.PROPAGATED)
        wave_store.update_wave(created_wave)
        
        # Get events
        events = wave_store.get_wave_events(created_wave.wave_id)
        
        # Should have at least 3 events: CREATED, STATE_CHANGE (twice)
        assert len(events) >= 3
        
        # Verify event types
        event_types = {e["event_type"] for e in events}
        assert "CREATED" in event_types
        assert "STATE_CHANGE" in event_types
        
        # Verify event data
        for event in events:
            assert "event_data" in event
            assert isinstance(event["event_data"], dict)
    
    def test_get_wave_stats(self, wave_store):
        """Test getting wave statistics."""
        tenant_id = "stats-tenant"
        
        # Create waves in different states
        for i in range(3):
            wave = Wave(tenant_id=tenant_id, created_by=f"user-{i}")
            wave_store.create_wave(wave)
        
        # Transition some waves
        waves = wave_store.list_waves(tenant_id=tenant_id)
        
        if len(waves) >= 2:
            # Transition first wave
            waves[0].transition(WaveState.PROPAGATION_PENDING)
            waves[0].approve("propagation", actor="admin")
            wave_store.update_wave(waves[0])
            
            # Transition second wave
            waves[1].transition(WaveState.PROPAGATION_PENDING)
            waves[1].approve("propagation", actor="admin")
            waves[1].transition(WaveState.PROPAGATED)
            wave_store.update_wave(waves[1])
        
        # Get stats
        stats = wave_store.get_wave_stats(tenant_id)
        
        # Verify stats structure
        assert "total" in stats
        assert "by_state" in stats
        assert "recent_7_days" in stats
        assert stats["tenant_id"] == tenant_id
        
        # Verify counts
        assert stats["total"] >= 3
        assert isinstance(stats["by_state"], dict)
        
        # CREATED state should be in stats
        assert WaveState.CREATED.value in stats["by_state"]
    
    def test_singleton_pattern(self, temp_db):
        """Test the get_wave_store singleton function."""
        from core.protocol.wave_store import get_wave_store
        
        # First call should create instance
        store1 = get_wave_store(db_path=temp_db)
        assert store1 is not None
        
        # Second call should return same instance
        store2 = get_wave_store(db_path=temp_db)
        assert store2 is store1
        
        # Different db_path should create new instance
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
            other_db = f.name
            store3 = get_wave_store(db_path=other_db)
            assert store3 is not store1
            
            # Cleanup
            os.unlink(other_db)


if __name__ == "__main__":
    # Run tests directly for debugging
    import sys
    sys.exit(pytest.main([__file__, "-v"]))