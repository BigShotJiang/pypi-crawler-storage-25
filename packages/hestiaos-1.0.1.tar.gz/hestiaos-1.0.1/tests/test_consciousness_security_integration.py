import unittest
import asyncio
import json
import os
from datetime import datetime
from unittest.mock import AsyncMock, MagicMock, patch

from core.consciousness import ConsciousnessProtocol, ConsciousnessLevel, AwarenessState, ConsciousnessRole
from core.agent_communication import AgentCommunicationClient, AgentRole, MessageType, AgentMessage
from core.consciousness_security import ConsciousnessPermission
from core.consciousness_audit import consciousness_audit

class TestConsciousnessSecurityIntegration(unittest.TestCase):
    def setUp(self):
        self.agent_id = "test_agent"
        self.agent_role = AgentRole.ORCHESTRATOR
        self.comm_client = MagicMock(spec=AgentCommunicationClient)
        self.comm_client.agent_id = self.agent_id
        self.comm_client.agent_role = self.agent_role
        self.comm_client.register_handler = AsyncMock()
        self.comm_client.broadcast = AsyncMock()
        self.comm_client.send_message = AsyncMock()
        
        self.protocol = ConsciousnessProtocol(self.agent_id, self.agent_role, self.comm_client)

    def test_initialization_security(self):
        """Verify that security components are initialized"""
        self.assertIsNotNone(self.protocol.rbac)
        self.assertIsNotNone(self.protocol.encryption)
        self.assertIsNotNone(self.protocol.audit)
        self.assertIsNotNone(self.protocol.security_context)
        self.assertEqual(self.protocol.security_context.agent_id, self.agent_id)

    async def async_test_encryption_announce(self):
        """Verify that consciousness announcement is encrypted"""
        await self.protocol.announce_consciousness()
        
        # Check broadcast call
        self.comm_client.broadcast.assert_called_once()
        args, kwargs = self.comm_client.broadcast.call_args
        payload = kwargs.get('payload') or args[1]
        
        encrypted_state = payload.get("consciousness")
        self.assertIsInstance(encrypted_state, str)
        
        # Verify decryption works
        decrypted = self.protocol.encryption.decrypt_identity_data(encrypted_state)
        self.assertIsNotNone(decrypted)
        self.assertEqual(decrypted['agent_id'], self.agent_id)

    def test_encryption_announce(self):
        asyncio.run(self.async_test_encryption_announce())

    async def async_test_rbac_update_awareness_denied(self):
        """Verify that RBAC blocks awareness update if permission is missing"""
        # Mock RBAC to deny permission
        with patch.object(self.protocol.rbac, 'check_permission', return_value=False):
            await self.protocol.update_awareness(AwarenessState.HYPERFOCUS)
            
            # Broadcast should NOT be called
            self.comm_client.broadcast.assert_not_called()
            
            # Audit should log failure
            # We can't easily check the log file here without disk IO but we know log_operation was called
            # (In a real test we might mock the audit logger)

    def test_rbac_update_awareness_denied(self):
        asyncio.run(self.async_test_rbac_update_awareness_denied())

    async def async_test_rbac_update_awareness_allowed(self):
        """Verify that RBAC allows awareness update if permission is present"""
        # System role has all permissions by default in our implementation
        await self.protocol.update_awareness(AwarenessState.AWAKE)
        
        # Broadcast SHOULD be called
        self.comm_client.broadcast.assert_called_once()

    def test_rbac_update_awareness_allowed(self):
        asyncio.run(self.async_test_rbac_update_awareness_allowed())

    async def async_test_encryption_sync_context(self):
        """Verify that context sync is encrypted"""
        test_context = {"key": "secret_value"}
        await self.protocol.sync_context(test_context, recipients=["other_agent"])
        
        self.comm_client.send_message.assert_called()
        args, kwargs = self.comm_client.send_message.call_args
        payload = kwargs.get('payload')
        
        encrypted_context = payload.get("context")
        self.assertIsInstance(encrypted_context, str)
        
        # Verify decryption
        decrypted = self.protocol.encryption.decrypt_context_item(encrypted_context)
        self.assertEqual(decrypted, test_context)

    def test_encryption_sync_context(self):
        asyncio.run(self.async_test_encryption_sync_context())

    async def async_test_audit_logging(self):
        """Verify that operations are logged to audit"""
        with patch.object(self.protocol.audit, 'log_operation') as mock_log:
            await self.protocol.elevate_consciousness(ConsciousnessLevel.COLLECTIVE)
            
            # Use assert_any_call because elevate_consciousness calls announce_consciousness
            # which ALSO logs an operation.
            mock_log.assert_any_call(
                "elevate_consciousness", self.agent_id, self.agent_role.value,
                self.protocol.security_context.session_id, True, unittest.mock.ANY
            )

    def test_audit_logging(self):
        asyncio.run(self.async_test_audit_logging())

if __name__ == "__main__":
    unittest.main()
