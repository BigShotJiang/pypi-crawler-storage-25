#!/usr/bin/env python3
"""
Test the output sanitization with real examples.
Tests both Structured Output primary path and PatternMatcher fallback.
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.output_filter import create_output_filter
from core.contracts.response_contract import OutputChannel

def test_real_examples():
    """Test with real examples from the UI problem."""
    print("=" * 80)
    print("Output Sanitization Test - Real Examples")
    print("=" * 80)
    
    # Create output filter with structured output enabled
    output_filter = create_output_filter(
        debug_mode=False,
        strict_mode=True,
        enable_structured_output=True
    )
    
    # Example 1: Mixed reasoning and response (informal English)
    example1 = """Okay, the user greeted me with "Hallo". This is a simple greeting in German.
I should respond politely in German as well.
Hallo! Ich bin HestiaOS, Ihr persönlicher Assistent. Wie kann ich Ihnen helfen?"""
    
    print("\nExample 1: Mixed reasoning and response (informal English)")
    print("Input:")
    print(example1)
    print("\nProcessing...")
    
    contract1 = output_filter.filter(example1)
    display1 = output_filter.get_display_output(contract1)
    
    print(f"Response Channel: {contract1.get_channel(OutputChannel.RESPONSE)}")
    print(f"Reasoning Channel: {contract1.get_channel(OutputChannel.REASONING)}")
    print(f"Display Output (UI): {display1}")
    
    # Check that reasoning is filtered out
    assert "Okay, the user greeted me" not in display1, "Reasoning leaked into UI!"
    assert "Hallo! Ich bin HestiaOS" in display1, "Response not found!"
    print("✓ Reasoning correctly filtered, only response shown")
    
    # Example 2: XML tags (claude style)
    example2 = """<thinking>
The user asked about the weather. I need to check the current weather API.
But first I should acknowledge the question.
</thinking>
The current weather in Berlin is 15°C with partial clouds."""
    
    print("\n" + "=" * 80)
    print("Example 2: XML tags (claude style)")
    print("Input:")
    print(example2)
    print("\nProcessing...")
    
    contract2 = output_filter.filter(example2)
    display2 = output_filter.get_display_output(contract2)
    
    print(f"Response Channel: {contract2.get_channel(OutputChannel.RESPONSE)}")
    print(f"Reasoning Channel: {contract2.get_channel(OutputChannel.REASONING)}")
    print(f"Display Output (UI): {display2}")
    
    # Check that XML thinking is filtered out
    assert "<thinking>" not in display2, "XML thinking tag leaked!"
    assert "The current weather in Berlin" in display2, "Response not found!"
    print("✓ XML thinking correctly filtered")
    
    # Example 3: JSON structured output (primary path should handle this)
    example3 = """{
  "version": "1.0",
  "channels": [
    {
      "channel": "reasoning",
      "content": "This is a test of structured output. The user asked for a simple greeting."
    },
    {
      "channel": "response", 
      "content": "Hello! This is a structured response.",
      "metadata": {"confidence": 0.95}
    }
  ]
}"""
    
    print("\n" + "=" * 80)
    print("Example 3: JSON structured output")
    print("Input:")
    print(example3)
    print("\nProcessing...")
    
    contract3 = output_filter.filter(example3)
    display3 = output_filter.get_display_output(contract3)
    
    print(f"Response Channel: {contract3.get_channel(OutputChannel.RESPONSE)}")
    print(f"Reasoning Channel: {contract3.get_channel(OutputChannel.REASONING)}")
    print(f"Display Output (UI): {display3}")
    
    # Check that structured output was processed correctly
    assert "Hello! This is a structured response." in display3, "Structured response not found!"
    assert "This is a test of structured output" not in display3, "Reasoning leaked from structured output!"
    print("✓ Structured output correctly processed")
    
    # Example 4: No reasoning, just response
    example4 = "Hallo! Ich bin HestiaOS, Ihr persönlicher Assistent."
    
    print("\n" + "=" * 80)
    print("Example 4: Pure response (no reasoning)")
    print("Input:")
    print(example4)
    print("\nProcessing...")
    
    contract4 = output_filter.filter(example4)
    display4 = output_filter.get_display_output(contract4)
    
    print(f"Response Channel: {contract4.get_channel(OutputChannel.RESPONSE)}")
    print(f"Reasoning Channel: {contract4.get_channel(OutputChannel.REASONING)}")
    print(f"Display Output (UI): {display4}")
    
    assert display4 == example4, "Pure response corrupted!"
    print("✓ Pure response preserved correctly")
    
    # Print metrics
    print("\n" + "=" * 80)
    print("Metrics:")
    metrics = output_filter.get_metrics()
    for key, value in metrics.items():
        print(f"  {key}: {value}")
    
    print("\n" + "=" * 80)
    print("All tests passed! ✓")
    return True

def test_debug_mode():
    """Test that debug mode shows reasoning."""
    print("\n" + "=" * 80)
    print("Debug Mode Test")
    print("=" * 80)
    
    output_filter_debug = create_output_filter(
        debug_mode=True,
        strict_mode=True,
        enable_structured_output=True
    )
    
    example = """Okay, the user greeted me with "Hallo".
Hallo! Ich bin HestiaOS."""
    
    contract = output_filter_debug.filter(example)
    display = output_filter_debug.get_display_output(contract)
    
    print(f"Debug Display Output: {display}")
    
    # In debug mode, reasoning might be included in display
    # (depends on ResponseContract.get_display_output implementation)
    print("✓ Debug mode test completed")
    
    return True

if __name__ == "__main__":
    try:
        test_real_examples()
        test_debug_mode()
        print("\n" + "=" * 80)
        print("SUCCESS: All output sanitization tests passed!")
        sys.exit(0)
    except Exception as e:
        print(f"\nERROR: Test failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)