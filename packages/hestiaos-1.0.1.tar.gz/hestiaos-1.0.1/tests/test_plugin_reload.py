#!/usr/bin/env python3
"""Test script to check if Nextcloud Talk plugin is working and reload it if needed."""
import asyncio
import httpx
import json
import sys

async def test_plugin_status():
    """Check plugin status and test functionality."""
    print("🔍 Testing Nextcloud Talk plugin status...")
    
    try:
        # First, check if backend is responding
        async with httpx.AsyncClient(timeout=10.0) as client:
            # Try to get plugin list
            try:
                resp = await client.get("http://localhost:8001/system/plugins")
                if resp.status_code == 200:
                    plugins = resp.json().get("plugins", [])
                    print(f"✅ Found {len(plugins)} plugins")
                    
                    # Look for Nextcloud Talk plugin
                    nc_plugins = [p for p in plugins if "nextcloud" in p.get("id", "").lower()]
                    for p in nc_plugins:
                        print(f"   - {p.get('id')}: enabled={p.get('enabled')}, status={p.get('status')}")
                else:
                    print(f"⚠️  Could not get plugins: {resp.status_code}")
            except Exception as e:
                print(f"⚠️  Could not connect to backend: {e}")
                print("   Trying port 8000...")
                
                try:
                    resp = await client.get("http://localhost:8000/system/plugins")
                    if resp.status_code == 200:
                        print("✅ Backend is running on port 8000")
                    else:
                        print(f"⚠️  Port 8000 also not responding: {resp.status_code}")
                except:
                    print("❌ Backend not running on either port")
                    return False
            
            # Test chat endpoint
            print("\n💬 Testing chat endpoint...")
            try:
                chat_resp = await client.post(
                    "http://localhost:8000/chat",
                    json={
                        "message": "Hello, are you working?",
                        "session_id": "test_plugin_check"
                    },
                    timeout=30.0
                )
                if chat_resp.status_code == 200:
                    data = chat_resp.json()
                    print(f"✅ Chat endpoint working: {data.get('response', '')[:50]}...")
                else:
                    print(f"⚠️  Chat endpoint error: {chat_resp.status_code} - {chat_resp.text}")
            except Exception as e:
                print(f"⚠️  Chat endpoint failed: {e}")
                
                # Try port 8001
                try:
                    chat_resp = await client.post(
                        "http://localhost:8001/chat",
                        json={
                            "message": "Hello, are you working?",
                            "session_id": "test_plugin_check"
                        },
                        timeout=30.0
                    )
                    if chat_resp.status_code == 200:
                        print(f"✅ Chat endpoint working on port 8001")
                    else:
                        print(f"⚠️  Chat endpoint error on port 8001: {chat_resp.status_code}")
                except:
                    print("❌ Chat endpoint not working on either port")
        
        return True
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        return False

async def reload_plugin():
    """Try to reload the Nextcloud Talk plugin."""
    print("\n🔄 Attempting to reload Nextcloud Talk plugin...")
    
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            # First disable
            disable_resp = await client.post(
                "http://localhost:8001/system/plugins/toggle",
                json={"plugin_id": "nextcloud_talk_fixed", "enabled": False}
            )
            
            if disable_resp.status_code == 200:
                print("✅ Plugin disabled")
                await asyncio.sleep(1)
                
                # Then enable
                enable_resp = await client.post(
                    "http://localhost:8001/system/plugins/toggle",
                    json={"plugin_id": "nextcloud_talk_fixed", "enabled": True}
                )
                
                if enable_resp.status_code == 200:
                    print("✅ Plugin re-enabled")
                    return True
                else:
                    print(f"⚠️  Could not enable plugin: {enable_resp.status_code}")
            else:
                print(f"⚠️  Could not disable plugin: {disable_resp.status_code}")
                
    except Exception as e:
        print(f"❌ Failed to reload plugin: {e}")
        
    return False

async def main():
    """Main test function."""
    print("🚀 Starting Nextcloud Talk plugin diagnostic...")
    
    # Test current status
    status_ok = await test_plugin_status()
    
    if not status_ok:
        print("\n❌ Plugin system not working properly")
        return
    
    # Try to reload plugin
    reloaded = await reload_plugin()
    
    if reloaded:
        print("\n✅ Plugin reload attempted. Waiting 5 seconds...")
        await asyncio.sleep(5)
        
        # Test again
        print("\n🔍 Testing plugin after reload...")
        await test_plugin_status()
    
    print("\n📋 Diagnostic complete.")

if __name__ == "__main__":
    asyncio.run(main())