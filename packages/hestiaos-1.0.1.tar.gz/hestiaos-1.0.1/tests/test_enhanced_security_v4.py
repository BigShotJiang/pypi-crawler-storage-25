import unittest
import threading
import asyncio
from concurrent.futures import ThreadPoolExecutor
from core.rbac_system import get_rbac_manager, Role, Permission
from core.consciousness_security import ConsciousnessEncryption
from cryptography.fernet import Fernet
from datetime import datetime

class TestEnhancedSecurity(unittest.TestCase):
    def setUp(self):
        self.rbac = get_rbac_manager()
        self.encryption = ConsciousnessEncryption(master_key=Fernet.generate_key())

    def test_context_local_security(self):
        """Verify that security context is local to the current thread/task."""
        def run_in_thread(user_id, session_id):
            context = self.rbac.create_user_context(
                user_id=user_id,
                username=user_id,
                roles=[Role.OPERATOR],
                session_id=session_id
            )
            self.rbac.set_current_context(context)
            # Verify it's set for this thread
            self.assertEqual(self.rbac.get_current_context().user_id, user_id)
            return self.rbac.get_current_context().user_id

        with ThreadPoolExecutor(max_workers=2) as executor:
            future1 = executor.submit(run_in_thread, "user1", "sess1")
            future2 = executor.submit(run_in_thread, "user2", "sess2")
            
            self.assertEqual(future1.result(), "user1")
            self.assertEqual(future2.result(), "user2")
        
        # Main thread should still be None
        self.assertIsNone(self.rbac.get_current_context())

    def test_tenant_specific_encryption(self):
        """Verify that encryption is tenant-aware."""
        data = {"secret": "hello"}
        
        # Encrypt for Tenant A
        enc_a = self.encryption.encrypt_identity_data(data, tenant_id="tenant_a")
        
        # Encrypt for Tenant B
        enc_b = self.encryption.encrypt_identity_data(data, tenant_id="tenant_b")
        
        # Ciphertexts should be different
        self.assertNotEqual(enc_a, enc_b)
        
        # Decrypt with correct tenant
        dec_a = self.encryption.decrypt_identity_data(enc_a, tenant_id="tenant_a")
        self.assertEqual(dec_a["secret"], "hello")
        
        # Decrypt with WRONG tenant should fail
        dec_a_wrong = self.encryption.decrypt_identity_data(enc_a, tenant_id="tenant_b")
        self.assertIsNone(dec_a_wrong)

    def test_system_tenant_inheritance(self):
        """Verify that system tenant has special access."""
        sys_context = self.rbac.create_user_context(
            user_id="sys",
            username="System",
            roles=[Role.SYSTEM],
            tenant_id="system",
            session_id="sys_sess"
        )
        
        # Should be able to access Tenant A resource
        self.assertTrue(self.rbac.validate_access(
            "sys_sess", 
            Permission.READ, 
            resource="test", 
            tenant_id="tenant_a"
        ))

if __name__ == "__main__":
    unittest.main()
