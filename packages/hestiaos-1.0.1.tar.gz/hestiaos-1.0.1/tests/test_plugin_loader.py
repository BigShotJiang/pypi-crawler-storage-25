from core.plugin_manager import RobustPluginManager
from core.config import config_manager
import asyncio

async def main():
    print("Initializing RobustPluginManager...")
    pm = RobustPluginManager()
    
    print("Discovering plugins...")
    await pm.discover_plugins()
    
    print("Loading plugins...")
    await pm.load_plugins()
    
    talk = pm.plugins.get("nextcloud_talk")
    if talk:
        print("SUCCESS: nextcloud_talk plugin found and loaded.")
        tools = talk.get_tools()
        tool_names = [t["function"]["name"] for t in tools]
        print(f"Registered Tools: {tool_names}")
        
        # Verify endpoint in memory
        print(f"Active Server URL: {talk.server_url}")
    else:
        print("ERROR: nextcloud_talk plugin NOT found in active plugins.")
        print(f"Active Plugins: {list(pm.plugins.keys())}")

if __name__ == "__main__":
    asyncio.run(main())
