"""
Tests for Refined Embeddings & Multimodal RAG Foundation.

Tests both Community Edition (simple) and Business/Science Edition (governed)
wrappers, as well as the shared core components.

Core Principle: INDEX ≠ MEMORY ≠ Knowledge
"""

import pytest
import numpy as np
from unittest.mock import Mock, patch, AsyncMock
import tempfile
import os

from core.embedding_foundation import (
    EmbeddingFoundation,
    EmbeddingRequest,
    BatchEmbeddingRequest,
    Modality,
    create_embedding_foundation,
)
from core.vector_index import VectorIndex, VectorMetadata
from core.rag_foundation import RAGFoundation, ContextPacket
from core.embedding_service_simple import (
    SimpleEmbeddingService,
    SimpleEmbeddingConfig,
    SimpleEmbeddingRequest,
    create_simple_embedding_service,
)
from core.embedding_service_governed import (
    GovernedEmbeddingService,
    GovernedEmbeddingConfig,
    EmbeddingServiceRequest,
    create_governed_embedding_service,
)


class TestEmbeddingFoundation:
    """Tests for the shared embedding foundation."""
    
    def test_create_embedding_foundation(self):
        """Test creating embedding foundation with default configuration."""
        foundation = create_embedding_foundation()
        assert isinstance(foundation, EmbeddingFoundation)
        assert foundation.max_embedding_dim == 768
    
    def test_embedding_request_validation(self):
        """Test embedding request validation."""
        request = EmbeddingRequest(
            content_ref="test.txt",
            modality=Modality.TEXT,
            metadata={"source": "test"}
        )
        assert request.content_ref == "test.txt"
        assert request.modality == Modality.TEXT
        assert request.metadata["source"] == "test"
    
    @patch('core.embedding_foundation.SentenceTransformer')
    def test_text_embedding_mock(self, mock_sentence_transformer):
        """Test text embedding with mocked model."""
        # Mock the sentence transformer
        mock_model = Mock()
        mock_model.encode.return_value = np.random.rand(384)
        mock_sentence_transformer.return_value = mock_model
        
        foundation = EmbeddingFoundation()
        
        # Test text embedding
        request = EmbeddingRequest(
            content_ref="test.txt",
            modality=Modality.TEXT,
            metadata={"text": "This is a test document for embedding."}
        )
        
        result = foundation.embed(request)
        
        assert result.embedding is not None
        assert len(result.embedding) == 384
        assert result.embedding_dim == 384
        assert result.model_used == "sentence-transformers/all-MiniLM-L6-v2"
        assert result.content_ref == "test.txt"
        assert result.modality == Modality.TEXT
    
    def test_batch_embedding_request(self):
        """Test batch embedding request creation."""
        requests = [
            EmbeddingRequest(content_ref="doc1.txt", modality=Modality.TEXT),
            EmbeddingRequest(content_ref="doc2.txt", modality=Modality.TEXT),
        ]
        batch_request = BatchEmbeddingRequest(requests=requests)
        
        assert len(batch_request.requests) == 2
        assert batch_request.requests[0].content_ref == "doc1.txt"
        assert batch_request.requests[1].content_ref == "doc2.txt"


class TestVectorIndex:
    """Tests for the pure vector index (no raw data storage)."""
    
    def test_vector_metadata_validation(self):
        """Test vector metadata validation."""
        metadata = VectorMetadata(
            content_ref="doc123",
            modality="text",
            embedding_dim=384,
            model_used="test-model",
            custom_metadata={"author": "test"}
        )
        
        assert metadata.content_ref == "doc123"
        assert metadata.modality == "text"
        assert metadata.embedding_dim == 384
        assert metadata.model_used == "test-model"
        assert metadata.custom_metadata["author"] == "test"
        assert metadata.created_at is not None
    
    def test_vector_index_add_and_search(self):
        """Test adding vectors to index and searching."""
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp:
            db_path = tmp.name
        
        try:
            index = VectorIndex(backend="sqlite", db_path=db_path)
            
            # Create test embedding
            test_embedding = np.random.rand(384).astype(np.float32)
            
            # Add vector
            metadata = VectorMetadata(
                content_ref="test_doc",
                modality="text",
                embedding_dim=384,
                model_used="test-model",
                custom_metadata={"source": "test"}
            )
            
            vector_id = index.add_vector(test_embedding, metadata)
            assert vector_id is not None
            
            # Search for similar vector (should find itself)
            results = index.search(
                query_embedding=test_embedding,
                modality="text",
                limit=5,
                similarity_threshold=0.5
            )
            
            assert len(results) >= 1
            assert results[0].vector_id == vector_id
            assert results[0].similarity_score >= 0.99  # Should be very similar to itself
            
            # Test get_stats
            stats = index.get_stats()
            assert stats["total_vectors"] >= 1
            assert "text" in stats["vectors_by_modality"]
            
            # Test clear_vectors
            cleared = index.clear_vectors(modality="text")
            assert cleared >= 1
            
            # Verify cleared
            stats_after = index.get_stats()
            assert stats_after["total_vectors"] == 0
            
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)
    
    def test_vector_index_no_raw_data_rule(self):
        """Test that vector index doesn't store raw content."""
        index = VectorIndex(backend="memory")
        
        # Create metadata with content that looks like raw data
        metadata = VectorMetadata(
            content_ref="doc:123",
            modality="text",
            embedding_dim=384,
            model_used="test-model",
            custom_metadata={
                "title": "Test Document",
                # This should be allowed - it's metadata, not raw content
                "summary": "This is a summary",
                # This should NOT contain the actual document text
            }
        )
        
        test_embedding = np.random.rand(384).astype(np.float32)
        vector_id = index.add_vector(test_embedding, metadata)
        
        # Verify we can retrieve the metadata
        retrieved = index.get_vector(vector_id)
        assert retrieved is not None
        assert retrieved.metadata.content_ref == "doc:123"
        assert retrieved.metadata.custom_metadata["title"] == "Test Document"
        
        # The metadata should NOT contain the actual document text
        # (this is enforced by the developer, not the index)


class TestRAGFoundation:
    """Tests for the multimodal RAG foundation."""
    
    def test_context_packet_creation(self):
        """Test context packet creation."""
        packet = ContextPacket(
            query="test query",
            snippets=[],
            total_snippets=0
        )
        
        assert packet.query == "test query"
        assert len(packet.snippets) == 0
        assert packet.total_snippets == 0
        assert packet.retrieved_at is not None
    
    @patch('core.rag_foundation.EmbeddingFoundation')
    @patch('core.rag_foundation.VectorIndex')
    def test_rag_retrieval_mock(self, mock_vector_index, mock_embedding_foundation):
        """Test RAG retrieval with mocked components."""
        # Mock embedding foundation
        mock_foundation = Mock()
        mock_foundation.embed.return_value.embedding = np.random.rand(384)
        mock_foundation.embed.return_value.embedding_dim = 384
        
        # Mock vector index
        mock_index = Mock()
        mock_index.search.return_value = [
            Mock(
                vector_id="vec1",
                similarity_score=0.85,
                metadata=VectorMetadata(
                    content_ref="doc1",
                    modality="text",
                    embedding_dim=384,
                    model_used="test-model",
                    custom_metadata={"source": "test"}
                )
            )
        ]
        
        rag = RAGFoundation(
            embedding_foundation=mock_foundation,
            vector_index=mock_index
        )
        
        # Mock content loader
        with patch('core.rag_foundation.ContentLoader') as mock_loader:
            mock_loader_instance = Mock()
            mock_loader_instance.load_content.return_value = "This is the content of document 1."
            mock_loader.return_value = mock_loader_instance
            
            # Test retrieval
            context = rag.retrieve_context(
                query="test query",
                modality="text",
                max_snippets=3,
                max_tokens_per_snippet=100
            )
            
            assert context.query == "test query"
            assert len(context.snippets) == 1
            assert context.snippets[0].content_ref == "doc1"
            assert context.snippets[0].text == "This is the content of document 1."
            assert context.snippets[0].similarity_score == 0.85
            assert context.total_snippets == 1


class TestSimpleEmbeddingService:
    """Tests for Community Edition simple embedding service."""
    
    def test_simple_service_creation(self):
        """Test creating simple embedding service."""
        config = SimpleEmbeddingConfig(
            max_embedding_dim=512,
            enable_vision=False,
            enable_audio=False
        )
        
        service = create_simple_embedding_service(config=config)
        assert isinstance(service, SimpleEmbeddingService)
        assert service.config.max_embedding_dim == 512
        assert not service.config.enable_vision
        assert not service.config.enable_audio
    
    @patch('core.embedding_service_simple.EmbeddingFoundation')
    @patch('core.embedding_service_simple.VectorIndex')
    def test_simple_embedding(self, mock_vector_index, mock_embedding_foundation):
        """Test simple embedding with mocked components."""
        # Mock embedding foundation
        mock_foundation = Mock()
        mock_foundation.embed.return_value.embedding = np.random.rand(384)
        mock_foundation.embed.return_value.embedding_dim = 384
        mock_foundation.embed.return_value.model_used = "test-model"
        mock_foundation.embed.return_value.created_at = "2024-01-01T00:00:00"
        
        # Mock vector index
        mock_index = Mock()
        mock_index.add_vector.return_value = "vec_123"
        
        service = SimpleEmbeddingService(
            embedding_foundation=mock_foundation,
            vector_index=mock_index
        )
        
        # Test embedding
        request = SimpleEmbeddingRequest(
            content_ref="test.txt",
            modality="text",
            metadata={"author": "test"}
        )
        
        response = service.embed(request)
        
        assert response.vector_id == "vec_123"
        assert len(response.embedding) == 384
        assert response.modality == "text"
        assert response.content_ref == "test.txt"
        assert response.embedding_dim == 384
        assert response.model_used == "test-model"
        
        # Verify vector index was called with correct metadata
        mock_index.add_vector.assert_called_once()
        call_args = mock_index.add_vector.call_args
        metadata = call_args[1]['metadata']
        assert metadata.content_ref == "test.txt"
        assert metadata.modality == "text"
        assert metadata.embedding_dim == 384
        assert metadata.model_used == "test-model"
        assert metadata.custom_metadata["author"] == "test"
    
    def test_simple_service_modality_validation(self):
        """Test modality validation in simple service."""
        config = SimpleEmbeddingConfig(enable_vision=False, enable_audio=False)
        service = SimpleEmbeddingService(config=config)
        
        # Text should work
        text_request = SimpleEmbeddingRequest(content_ref="test.txt", modality="text")
        
        with patch.object(service.embedding_foundation, 'embed'):
            # Should not raise for text
            try:
                service.embed(text_request)
            except ValueError:
                pytest.fail("Text modality should be supported")
        
        # Vision should fail when disabled
        vision_request = SimpleEmbeddingRequest(content_ref="test.jpg", modality="image")
        
        with pytest.raises(ValueError, match="Vision embedding not enabled"):
            service.embed(vision_request)
        
        # Audio should fail when disabled
        audio_request = SimpleEmbeddingRequest(content_ref="test.wav", modality="audio")
        
        with pytest.raises(ValueError, match="Audio embedding not enabled"):
            service.embed(audio_request)
    
    @patch('core.embedding_service_simple.VectorIndex')
    def test_simple_search(self, mock_vector_index):
        """Test search functionality in simple service."""
        # Mock vector index search results
        mock_index = Mock()
        mock_index.search.return_value = [
            Mock(
                vector_id="vec1",
                similarity_score=0.92,
                metadata=VectorMetadata(
                    content_ref="doc1",
                    modality="text",
                    embedding_dim=384,
                    model_used="test-model",
                    custom_metadata={"source": "test"},
                    created_at="2024-01-01T00:00:00"
                )
            )
        ]
        
        service = SimpleEmbeddingService(vector_index=mock_index)
        
        # Mock embed method to return a test embedding
        with patch.object(service, 'embed') as mock_embed:
            mock_embed.return_value.embedding = np.random.rand(384)
            
            results = service.search(
                query="test query",
                modality="text",
                limit=5,
                similarity_threshold=0.7
            )
            
            assert len(results) == 1
            assert results[0]["vector_id"] == "vec1"
            assert results[0]["content_ref"] == "doc1"
            assert results[0]["similarity_score"] == 0.92
            assert results[0]["modality"] == "text"
    
    def test_simple_service_stats(self):
        """Test getting statistics from simple service."""
        service = SimpleEmbeddingService()
        
        with patch.object(service.vector_index, 'get_stats') as mock_stats:
            mock_stats.return_value = {
                "total_vectors": 42,
                "vectors_by_modality": {"text": 42}
            }
            
            stats = service.get_stats()
            
            assert stats["service"] == "simple_embedding_service"
            assert stats["vector_store_backend"] == "sqlite"
            assert stats["max_embedding_dim"] == 768
            assert stats["capabilities"]["text"] is True
            assert stats["vector_store"]["total_vectors"] == 42


class TestGovernedEmbeddingService:
    """Tests for Business/Science Edition governed embedding service."""
    
    def test_governed_service_creation(self):
        """Test creating governed embedding service."""
        config = GovernedEmbeddingConfig(
            max_requests_per_minute=30,
            max_batch_size=64,
            allowed_scopes=["project"],
            global_indexing_approved=False,
            risk_class="MEDIUM"
        )
        
        # Mock MCP governance engine
        with patch('core.embedding_service_governed.get_mcp_governance_engine') as mock_governance:
            mock_engine = Mock()
            mock_governance.return_value = mock_engine
            
            service = create_governed_embedding_service(config=config)
            assert isinstance(service, GovernedEmbeddingService)
            assert service.config.max_requests_per_minute == 30
            assert service.config.max_batch_size == 64
            assert service.config.allowed_scopes == ["project"]
            assert not service.config.global_indexing_approved
    
    @patch('core.embedding_service_governed.MCPGovernanceEngine')
    @patch('core.embedding_service_governed.RequestContext')
    def test_governed_embedding_with_scope_check(self, mock_request_context, mock_governance_engine):
        """Test governed embedding with scope enforcement."""
        # Mock governance engine
        mock_governance = Mock()
        mock_governance.check_permission.return_value = True
        mock_governance.record_audit_event = Mock()
        
        # Mock request context
        mock_context = Mock()
        mock_context.scope = "project"
        mock_context.trace_id = "trace_123"
        mock_context.user_id = "user_123"
        
        mock_request_context.get_current_request_context.return_value = mock_context
        
        service = GovernedEmbeddingService(
            config=GovernedEmbeddingConfig(allowed_scopes=["project", "agent"]),
            governance_engine=mock_governance
        )
        
        # Mock embedding foundation and vector index
        with patch.object(service, 'embedding_foundation') as mock_foundation:
            mock_foundation.embed.return_value.embedding = np.random.rand(384)
            mock_foundation.embed.return_value.embedding_dim = 384
            mock_foundation.embed.return_value.model_used = "test-model"
            
            with patch.object(service, 'vector_index') as mock_index:
                mock_index.add_vector.return_value = "vec_123"
                
                # Test embedding with allowed scope
                request = EmbeddingServiceRequest(
                    content_ref="test.txt",
                    modality="text",
                    scope="project",
                    metadata={"author": "test"}
                )
                
                response = service.embed_governed(request)
                
                assert response.vector_id == "vec_123"
                assert response.scope == "project"
                assert response.trace_id == "trace_123"
                
                # Verify governance checks were called
                mock_governance.check_permission.assert_called()
                mock_governance.record_audit_event.assert_called()
    
    @patch('core.embedding_service_governed.MCPGovernanceEngine')
    @patch('core.embedding_service_governed.RequestContext')
    def test_governed_embedding_scope_denied(self, mock_request_context, mock_governance_engine):
        """Test governed embedding with scope denial."""
        # Mock governance engine
        mock_governance = Mock()
        mock_governance.check_permission.return_value = False  # Deny permission
        mock_governance.record_audit_event = Mock()
        
        # Mock request context
        mock_context = Mock()
        mock_context.scope = "global"  # Not in allowed scopes
        mock_context.trace_id = "trace_123"
        
        mock_request_context.get_current_request_context.return_value = mock_context
        
        service = GovernedEmbeddingService(
            config=GovernedEmbeddingConfig(allowed_scopes=["project", "agent"]),
            governance_engine=mock_governance
        )
        
        # Test embedding with denied scope
        request = EmbeddingServiceRequest(
            content_ref="test.txt",
            modality="text",
            scope="global",  # Not allowed
            metadata={"author": "test"}
        )
        
        with pytest.raises(PermissionError, match="Scope 'global' not allowed"):
            service.embed_governed(request)
        
        # Verify governance checks were called
        mock_governance.check_permission.assert_called()
        mock_governance.record_audit_event.assert_called()
    
    @patch('core.embedding_service_governed.MCPGovernanceEngine')
    def test_governed_service_rate_limiting(self, mock_governance_engine):
        """Test rate limiting in governed service."""
        # Mock governance engine
        mock_governance = Mock()
        mock_governance.check_permission.return_value = True
        mock_governance.record_audit_event = Mock()
        
        service = GovernedEmbeddingService(
            config=GovernedEmbeddingConfig(max_requests_per_minute=2, max_batch_size=10),
            governance_engine=mock_governance
        )
        
        # Mock embedding foundation and vector index
        with patch.object(service, 'embedding_foundation') as mock_foundation:
            mock_foundation.embed.return_value.embedding = np.random.rand(384)
            mock_foundation.embed.return_value.embedding_dim = 384
            
            with patch.object(service, 'vector_index') as mock_index:
                mock_index.add_vector.return_value = "vec_123"
                
                # Mock request context
                with patch('core.embedding_service_governed.get_current_request_context') as mock_context:
                    mock_context.return_value.scope = "project"
                    mock_context.return_value.trace_id = "trace_123"
                    
                    # Make first request (should succeed)
                    request1 = EmbeddingServiceRequest(
                        content_ref="test1.txt",
                        modality="text",
                        scope="project"
                    )
                    
                    response1 = service.embed_governed(request1)
                    assert response1.vector_id == "vec_123"
                    
                    # Make second request (should succeed)
                    request2 = EmbeddingServiceRequest(
                        content_ref="test2.txt",
                        modality="text",
                        scope="project"
                    )
                    
                    response2 = service.embed_governed(request2)
                    assert response2.vector_id == "vec_123"
                    
                    # Make third request (should be rate limited)
                    request3 = EmbeddingServiceRequest(
                        content_ref="test3.txt",
                        modality="text",
                        scope="project"
                    )
                    
                    # Note: In a real test, we'd need to simulate time passing
                    # For now, we'll just verify the rate limiting logic exists
                    # by checking that the service tracks request counts
                    assert hasattr(service, '_request_counts')
    
    def test_governed_service_firewall_enforcement(self):
        """Test that governed service enforces memory API firewall."""
        service = GovernedEmbeddingService()
        
        # The service should NOT have access to memory APIs
        # This is enforced by the architecture, not runtime checks
        assert not hasattr(service, 'store_memory')
        assert not hasattr(service, 'search_memories')
        assert not hasattr(service, 'get_memory')
        
        # The service should only have embedding and vector index methods
        assert hasattr(service, 'embed_governed')
        assert hasattr(service, 'embed_batch_governed')
        assert hasattr(service, 'search_governed')
        assert hasattr(service, 'get_stats')


class TestEditionComparison:
    """Tests comparing Community Edition vs Business/Science Edition."""
    
    def test_edition_differences(self):
        """Test key differences between editions."""
        # Community Edition (simple)
        ce_service = SimpleEmbeddingService()
        ce_config = ce_service.config
        
        # Business/Science Edition (governed)
        with patch('core.embedding_service_governed.get_mcp_governance_engine'):
            be_service = GovernedEmbeddingService()
            be_config = be_service.config
        
        # Key differences:
        # 1. Governance: BE has it, CE doesn't
        assert hasattr(be_service, 'governance_engine')
        assert not hasattr(ce_service, 'governance_engine')
        
        # 2. Rate limiting: BE has config, CE doesn't
        assert hasattr(be_config, 'max_requests_per_minute')
        assert hasattr(be_config, 'max_batch_size')
        # CE config doesn't have these fields
        assert not hasattr(ce_config, 'max_requests_per_minute')
        assert not hasattr(ce_config, 'max_batch_size')
        
        # 3. Scope enforcement: BE has it, CE doesn't
        assert hasattr(be_config, 'allowed_scopes')
        assert hasattr(be_config, 'global_indexing_approved')
        assert not hasattr(ce_config, 'allowed_scopes')
        assert not hasattr(ce_config, 'global_indexing_approved')
        
        # 4. Risk class: BE has it, CE doesn't
        assert hasattr(be_config, 'risk_class')
        assert not hasattr(ce_config, 'risk_class')
        
        # 5. Both enforce "no raw data" rule architecturally
        # (This is tested in the vector index tests)
    
    def test_shared_core_components(self):
        """Test that both editions use the same shared core."""
        # Both editions should use the same embedding foundation
        ce_service = SimpleEmbeddingService()
        be_service = GovernedEmbeddingService()
        
        assert isinstance(ce_service.embedding_foundation, EmbeddingFoundation)
        assert isinstance(be_service.embedding_foundation, EmbeddingFoundation)
        
        # Both editions should use the same vector index
        assert isinstance(ce_service.vector_index, VectorIndex)
        assert isinstance(be_service.vector_index, VectorIndex)
        
        # Both editions should use the same RAG foundation
        assert isinstance(ce_service.rag_foundation, RAGFoundation)
        assert isinstance(be_service.rag_foundation, RAGFoundation)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])