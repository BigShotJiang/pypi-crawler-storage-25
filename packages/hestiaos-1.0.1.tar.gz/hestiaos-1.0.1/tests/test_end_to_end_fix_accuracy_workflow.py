#!/usr/bin/env python3
"""
End-to-End Fix Accuracy Measurement Workflow Test

Tests the complete workflow from code analysis to fix generation to accuracy measurement.
This validates that all components work together correctly.
"""
import asyncio
import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from core.capabilities.code_analysis import CodeAnalysisCapability
from core.capabilities.ast_fix_engine import ASTFixEngine
from core.capabilities.pr_auditor import PRAuditorCapability, AutoFix, FixType, FixConfidence
from core.capabilities.fix_accuracy_measurement import FixAccuracyMeasurementCapability
from core.capability_registry.initializer import initialize_default_registry


async def test_code_analysis_to_fix_generation():
    """Test the workflow: code analysis → fix generation → accuracy measurement."""
    print("=== End-to-End Fix Accuracy Measurement Workflow Test ===")
    print("Testing: Code Analysis → AST Fix Engine → Accuracy Measurement")
    
    # Initialize capabilities
    code_analyzer = CodeAnalysisCapability()
    fix_engine = ASTFixEngine()
    accuracy_measurer = FixAccuracyMeasurementCapability()
    
    # Test code with security vulnerabilities
    vulnerable_code = '''import os

def insecure_function():
    # Hardcoded password
    password = "secret123"
    
    # Dangerous eval
    user_input = input("Enter command: ")
    eval(user_input)
    
    # Shell injection risk
    filename = input("Enter filename: ")
    os.system(f"cat {filename}")
    
    return password
'''
    
    print("\n1. Analyzing vulnerable code...")
    analysis_result = await code_analyzer.analyze_file("test.py", vulnerable_code)
    
    print(f"   Security issues found: {len(analysis_result.get('security_issues', []))}")
    print(f"   Quality issues found: {len(analysis_result.get('quality_issues', []))}")
    print(f"   Security score: {analysis_result.get('security_score', 0):.2f}")
    print(f"   Quality score: {analysis_result.get('quality_score', 0):.2f}")
    
    # Generate mock bandit findings based on the vulnerable code
    # Line numbers in the vulnerable code:
    # Line 4: password = "secret123" (B105)
    # Line 8: eval(user_input) (B307) - actually line 8 in the code snippet
    # Line 11: os.system(f"cat {filename}") (B602) - actually line 11
    bandit_findings = [
        {"test_id": "B105", "line_number": 4, "issue_text": "Hardcoded password string"},
        {"test_id": "B307", "line_number": 8, "issue_text": "Use of eval detected"},
        {"test_id": "B602", "line_number": 11, "issue_text": "Possible shell injection"}
    ]
    
    # Generate fixes using AST fix engine
    print("\n2. Generating fixes with AST fix engine...")
    fixes = fix_engine.generate_fixes("test.py", vulnerable_code, bandit_findings)
    
    print(f"   Fixes generated: {len(fixes)}")
    for i, fix in enumerate(fixes):
        print(f"   Fix {i+1}: {fix.fix_type.value} - {fix.description}")
    
    # Apply fixes
    if fixes:
        fixed_code, applied_fixes = fix_engine.apply_fixes(vulnerable_code, fixes)
        print(f"\n3. Applied {len(applied_fixes)} fixes")
        
        # Create AutoFix objects for accuracy measurement
        auto_fixes = []
        for i, (fix, result) in enumerate(zip(fixes, applied_fixes)):
            if result.get("applied", False):
                auto_fix = AutoFix(
                    fix_id=f"fix-{i}",
                    issue_id=f"issue-{i}",
                    fix_type=FixType.SECURITY if "security" in fix.description.lower() else FixType.QUALITY,
                    confidence=FixConfidence.HIGH if fix.confidence.value == "high" else FixConfidence.MEDIUM,
                    description=fix.description,
                    file_path="test.py",
                    old_code=fix.old_code,
                    new_code=fix.new_code,
                    reasoning=f"AST-based fix for {fix.description}"
                )
                auto_fixes.append((vulnerable_code, fixed_code, auto_fix))
        
        # Measure fix accuracy
        print("\n4. Measuring fix accuracy...")
        if auto_fixes:
            batch = await accuracy_measurer.measure_batch_accuracy(auto_fixes)
            
            print(f"   Batch ID: {batch.batch_id}")
            print(f"   Total fixes measured: {batch.summary['total_fixes']}")
            print(f"   Average overall score: {batch.summary['average_overall_score']:.2f}")
            print(f"   Success rate: {batch.summary['success_rate']:.2%}")
            
            print("\n   Dimension scores:")
            for dimension, score in batch.summary['dimension_scores'].items():
                print(f"     {dimension}: {score:.2f}")
            
            # Calculate performance metrics
            print("\n5. Calculating performance metrics...")
            metrics = await accuracy_measurer.calculate_performance_metrics(
                time_period="week",
                lookback_days=7
            )
            
            print(f"   Time period: {metrics.time_period}")
            print(f"   Total fixes analyzed: {metrics.total_fixes}")
            print(f"   Successful fixes: {metrics.successful_fixes}")
            print(f"   Failed fixes: {metrics.failed_fixes}")
            print(f"   Average accuracy: {metrics.average_accuracy:.2f}")
            
            return {
                "analysis_result": analysis_result,
                "fixes_generated": len(fixes),
                "fixes_applied": len(applied_fixes),
                "accuracy_measurement": batch.summary,
                "performance_metrics": metrics.to_dict()
            }
        else:
            print("   No fixes were successfully applied")
            return None
    else:
        print("   No fixes generated")
        return None


async def test_capability_registry_integration():
    """Test that all capabilities are properly registered in the capability registry."""
    print("\n=== Capability Registry Integration Test ===")
    
    # Initialize registry
    registry = initialize_default_registry()
    stats = registry.get_registry_stats()
    
    print(f"Total capabilities registered: {stats.total_capabilities}")
    print(f"Total providers registered: {stats.total_providers}")
    
    # Check for specific capabilities
    required_capabilities = [
        "code_analysis",
        "ast_fix_engine", 
        "pr_auditor",
        "fix_accuracy_measurement",
        "auto_pr_generator",
        "tool_orchestrator"
    ]
    
    print("\nChecking required capabilities:")
    all_present = True
    for cap_id in required_capabilities:
        if cap_id in registry.capabilities:
            cap = registry.capabilities[cap_id]
            print(f"  ✓ {cap.name} ({cap_id}) - {cap.capability_type.value}")
        else:
            print(f"  ✗ {cap_id} - NOT FOUND")
            all_present = False
    
    # Check dependency graph
    print("\nCapability dependency graph:")
    graph_data = registry.graph.to_networkx_format()
    print(f"  Nodes: {len(graph_data['nodes'])}")
    print(f"  Edges: {len(graph_data['edges'])}")
    
    # Check specific dependencies
    print("\nKey dependencies:")
    key_dependencies = [
        ("pr_auditor", ["code_analysis", "git_repository"]),
        ("fix_accuracy_measurement", ["ast_fix_engine", "pr_auditor"]),
        ("auto_pr_generator", ["pr_auditor", "git_repository", "fix_accuracy_measurement"])
    ]
    
    for cap_id, expected_deps in key_dependencies:
        if cap_id in registry.capabilities:
            cap = registry.capabilities[cap_id]
            actual_deps = list(cap.depends_on)
            print(f"  {cap_id}: depends on {actual_deps}")
            for dep in expected_deps:
                if dep in actual_deps:
                    print(f"    ✓ {dep}")
                else:
                    print(f"    ✗ {dep} (missing)")
    
    return {
        "all_capabilities_present": all_present,
        "total_capabilities": stats.total_capabilities,
        "total_providers": stats.total_providers,
        "graph_nodes": len(graph_data['nodes']),
        "graph_edges": len(graph_data['edges'])
    }


async def test_workflow_with_realistic_scenario():
    """Test a realistic scenario with multiple file types and issues."""
    print("\n=== Realistic Scenario Test ===")
    
    # Create test files with different types of issues
    test_files = [
        {
            "name": "security_issues.py",
            "content": '''import subprocess
import os

def process_user_data():
    # Hardcoded credentials
    db_password = "SuperSecret123!"
    
    # Command injection
    user_input = input("Enter command: ")
    subprocess.call(user_input, shell=True)
    
    # Insecure deserialization
    import pickle
    data = input("Enter data: ")
    obj = pickle.loads(data.encode())
    
    return db_password
'''
        },
        {
            "name": "quality_issues.py",
            "content": '''def poorly_written_function(x, y, z):
    # Too many parameters
    # No type hints
    # No docstring
    result = 0
    for i in range(100):
        for j in range(100):
            for k in range(100):
                result += i * j * k
    return result

class BadClass:
    def __init__(self):
        self.data = None
    
    def method1(self):
        pass
    
    def method2(self):
        pass
    
    # Many similar methods without clear purpose
    def method3(self):
        pass
'''
        }
    ]
    
    # Initialize capabilities
    code_analyzer = CodeAnalysisCapability()
    fix_engine = ASTFixEngine()
    accuracy_measurer = FixAccuracyMeasurementCapability()
    
    all_results = []
    
    for test_file in test_files:
        print(f"\nAnalyzing {test_file['name']}...")
        
        # Analyze file
        analysis = await code_analyzer.analyze_file(test_file['name'], test_file['content'])
        
        # Generate mock bandit findings based on the file content
        bandit_findings = []
        if "security_issues.py" in test_file['name']:
            bandit_findings = [
                {"test_id": "B105", "line_number": 5, "issue_text": "Hardcoded password string"},
                {"test_id": "B602", "line_number": 9, "issue_text": "Possible shell injection"},
                {"test_id": "B301", "line_number": 13, "issue_text": "Pickle deserialization"}
            ]
        elif "quality_issues.py" in test_file['name']:
            # Quality issues don't have Bandit findings, but we can still test
            bandit_findings = []
        
        # Generate fixes
        fixes = fix_engine.generate_fixes(test_file['name'], test_file['content'], bandit_findings)
        
        # Apply fixes
        if fixes:
            fixed_code, applied_fixes = fix_engine.apply_fixes(test_file['content'], fixes)
            
            # Create AutoFix objects for accuracy measurement
            auto_fixes = []
            for i, (fix, result) in enumerate(zip(fixes, applied_fixes)):
                if result.get("applied", False):
                    auto_fix = AutoFix(
                        fix_id=f"{test_file['name']}-fix-{i}",
                        issue_id=f"{test_file['name']}-issue-{i}",
                        fix_type=FixType.SECURITY if "security" in fix.description.lower() else FixType.QUALITY,
                        confidence=FixConfidence.HIGH if fix.confidence.value == "high" else FixConfidence.MEDIUM,
                        description=fix.description,
                        file_path=test_file['name'],
                        old_code=fix.old_code,
                        new_code=fix.new_code,
                        reasoning=f"AST-based fix for {fix.description}"
                    )
                    auto_fixes.append((test_file['content'], fixed_code, auto_fix))
            
            # Measure accuracy
            if auto_fixes:
                batch = await accuracy_measurer.measure_batch_accuracy(auto_fixes)
                
                file_result = {
                    "file": test_file['name'],
                    "analysis": {
                        "security_issues": len(analysis.get('security_issues', [])),
                        "quality_issues": len(analysis.get('quality_issues', [])),
                        "security_score": analysis.get('security_score', 0),
                        "quality_score": analysis.get('quality_score', 0)
                    },
                    "fixes": {
                        "generated": len(fixes),
                        "applied": len(applied_fixes),
                        "accuracy": batch.summary['average_overall_score']
                    }
                }
                all_results.append(file_result)
                
                print(f"  Security issues: {file_result['analysis']['security_issues']}")
                print(f"  Quality issues: {file_result['analysis']['quality_issues']}")
                print(f"  Fixes applied: {file_result['fixes']['applied']}")
                print(f"  Fix accuracy: {file_result['fixes']['accuracy']:.2f}")
    
    return all_results


async def main():
    """Run all end-to-end tests."""
    print("End-to-End Fix Accuracy Measurement Workflow Tests")
    print("=" * 60)
    
    try:
        # Test 1: Basic workflow
        print("\n" + "=" * 60)
        workflow_result = await test_code_analysis_to_fix_generation()
        
        # Test 2: Capability registry integration (skip if there's an error)
        print("\n" + "=" * 60)
        try:
            registry_result = await test_capability_registry_integration()
        except Exception as e:
            print(f"Warning: Capability registry integration test failed: {e}")
            print("Skipping registry test and continuing...")
            registry_result = {"all_capabilities_present": False, "error": str(e)}
        
        # Test 3: Realistic scenario
        print("\n" + "=" * 60)
        scenario_results = await test_workflow_with_realistic_scenario()
        
        # Summary
        print("\n" + "=" * 60)
        print("TEST SUMMARY")
        print("=" * 60)
        
        if workflow_result:
            print("✓ Basic workflow test PASSED")
            print(f"  Fixes generated: {workflow_result['fixes_generated']}")
            print(f"  Fixes applied: {workflow_result['fixes_applied']}")
            print(f"  Average accuracy: {workflow_result['accuracy_measurement']['average_overall_score']:.2f}")
        else:
            print("✗ Basic workflow test FAILED")
        
        if registry_result['all_capabilities_present']:
            print("✓ Capability registry integration test PASSED")
            print(f"  Total capabilities: {registry_result['total_capabilities']}")
            print(f"  Total providers: {registry_result['total_providers']}")
        else:
            print("✗ Capability registry integration test FAILED")
        
        if scenario_results:
            print("✓ Realistic scenario test PASSED")
            total_files = len(scenario_results)
            total_fixes = sum(r['fixes']['applied'] for r in scenario_results)
            avg_accuracy = sum(r['fixes']['accuracy'] for r in scenario_results) / total_files
            print(f"  Files analyzed: {total_files}")
            print(f"  Total fixes applied: {total_fixes}")
            print(f"  Average accuracy across files: {avg_accuracy:.2f}")
        else:
            print("✗ Realistic scenario test FAILED")
        
        print("\n" + "=" * 60)
        print("All end-to-end tests completed!")
        
        return True
        
    except Exception as e:
        print(f"\nError during end-to-end tests: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)