import asyncio
import sys
from pathlib import Path
from datetime import datetime

# Add project root to sys.path
sys.path.append(str(Path(__file__).parent.parent))

from core.orchestrator import Orchestrator
from tests.conftest import MockBackendRouter
from core.llm_engine import LLMEngine
from core.context_manager import ContextManager
from core.tool_executor import ToolExecutor # analyzer: ignore
from core.tool_manager import ToolManager # analyzer: ignore # analyzer: ignore
from core.memory import memory
from core.identity import HardwareIdentity
import os

# Set DEBUG mode for logging
os.environ["DEBUG_MODE"] = "True"

async def main():
    # Force log level to DEBUG
    import logging
    logging.getLogger("CORE01").setLevel(logging.DEBUG)
    
    print("🧪 Testing Ghost Writer Trigger Logic...")
    
    # 1. Setup Mock Components
    llm = LLMEngine("http://localhost:11434")
    cm = ContextManager()
    tm = ToolManager()
    te = ToolExecutor(tm) # analyzer: ignore
    
    # Register Obsidian plugin for the test
    await te.load_plugins()
    
    orchestrator = Orchestrator(
        llm_engine=llm,
        context_manager=cm,
        tool_executor=te,
        models_config={},
        backend_router=MockBackendRouter()
    )
    
    gw = orchestrator.ghost_writer
    session_id = "test_ghost_session"
    
    # Pre-load some conversation history so summarization has content
    memory.store_conversation(session_id, "Wie plane ich eine Reise zum Mars?", 
                             "Eine Reise zum Mars erfordert sorgfältige Planung in Bezug auf Treibstoff, Vorräte und Strahlungsschutz.")
    memory.store_conversation(session_id, "Welche Rakete eignet sich am besten?", 
                             "Das Starship von SpaceX ist derzeit die vielversprechendste Option für bemannte Mars-Missionen.")

    # 2. Simulate 0 tokens (check delta logic)
    print("\nCheck 1: Base state (Should NOT trigger)")
    await gw._check_session(session_id, is_idle=True)
    
    # 3. Simulate Some Tokens (e.g. 100)
    print("\nCheck 2: Small delta (Should NOT trigger on idle)")
    memory.log_token_usage(session_id, "test-model", "ollama", 50, 50)
    await gw._check_session(session_id, is_idle=True)
    
    # 4. Simulate > 500 Tokens Delta
    print("\nCheck 3: >500 Tokens + Idle (Should TRIGGER)")
    memory.log_token_usage(session_id, "test-model", "ollama", 250, 300) # Total now 650
    # We need to mock the LLM response for the summary to avoid actual ollama calls in some environments,
    # but here we'll let it try since we are on the system.
    # Note: If ollama is down, this might fail, but the LOGS will show the trigger.
    
    # We'll monkey-patch _analyze_conversation to skip the actual LLM call for the test if needed,
    # but let's see if it works naturally first.
    
    await gw._check_session(session_id, is_idle=True)
    
    # 5. Simulate 85% Threshold (16384 * 0.85 = 13926)
    print("\nCheck 4: 85% Threshold (Should TRIGGER even if not idle)")
    memory.log_token_usage(session_id, "test-model", "ollama", 7000, 7000) # Total now 14650
    await gw._check_session(session_id, is_idle=False)

    print("\n✅ Verification script finished.")

if __name__ == "__main__":
    asyncio.run(main())
