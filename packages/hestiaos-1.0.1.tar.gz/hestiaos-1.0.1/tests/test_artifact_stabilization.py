"""
Tests für die Stabilisierungsschicht des Artifact Systems.

Testet:
    - State Machine (formale Transition-Validierung)
    - Event Log (append-only Audit Trail)
    - Graph Query Layer (Abhängigkeitsanalyse, kritischer Pfad)
"""

import pytest
from datetime import datetime, timezone
from core.artifact.models import Artifact, ArtifactType, ArtifactStatus
from core.artifact.state_machine import (
    validate_transition,
    validate_transition_or_raise,
    TransitionError,
    get_allowed_transitions,
    get_transition_graph,
)
from core.artifact.event_log import ArtifactEventLog
from core.artifact.graph import ArtifactGraph, GraphScope
from core.artifact.store import ArtifactStore


# =============================================================================
# Fixtures
# =============================================================================

@pytest.fixture
def store():
    """Erstelle einen In-Memory Store."""
    return ArtifactStore(":memory:")


@pytest.fixture
def store():
    """Erstelle einen In-Memory Store (Connection-Owner)."""
    return ArtifactStore(":memory:")


@pytest.fixture
def event_log(store):
    """Erstelle einen Event Log mit shared Connection vom Store."""
    return ArtifactEventLog(store.conn)


@pytest.fixture
def graph(store):
    """Erstelle einen ArtifactGraph mit In-Memory Store."""
    return ArtifactGraph(store)


@pytest.fixture
def sample_artifact(store):
    """Erstelle ein Beispiel-Artifact im Store."""
    art = Artifact(
        id="art_001",
        type=ArtifactType.TASK,
        title="Test Task",
        content="Test",
        status=ArtifactStatus.DRAFT,
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    return store.create(art)


# =============================================================================
# State Machine Tests
# =============================================================================

class TestStateMachine:
    """Tests für die formale Transition-Validierung."""

    def test_valid_transition(self):
        """Erlaubte Transition wird akzeptiert."""
        assert validate_transition(
            ArtifactType.TASK, ArtifactStatus.DRAFT, ArtifactStatus.ACTIVE
        ) is True

    def test_invalid_transition(self):
        """Ungültige Transition wird abgelehnt."""
        assert validate_transition(
            ArtifactType.IDEA, ArtifactStatus.DRAFT, ArtifactStatus.ACTIVE
        ) is False

    def test_archived_is_final(self):
        """Archivierte Artifacts haben keine erlaubten Transitionen."""
        for art_type in ArtifactType:
            assert validate_transition(
                art_type, ArtifactStatus.ARCHIVED, ArtifactStatus.DRAFT
            ) is False
            assert validate_transition(
                art_type, ArtifactStatus.ARCHIVED, ArtifactStatus.ACTIVE
            ) is False
            assert validate_transition(
                art_type, ArtifactStatus.ARCHIVED, ArtifactStatus.DONE
            ) is False
            assert validate_transition(
                art_type, ArtifactStatus.ARCHIVED, ArtifactStatus.BLOCKED
            ) is False

    def test_validate_or_raise_valid(self):
        """validate_transition_or_raise wirft keine Exception bei gültiger Transition."""
        # Sollte ohne Exception durchlaufen
        validate_transition_or_raise(
            ArtifactType.TASK, ArtifactStatus.ACTIVE, ArtifactStatus.DONE
        )

    def test_validate_or_raise_invalid(self):
        """validate_transition_or_raise wirft TransitionError bei ungültiger Transition."""
        with pytest.raises(TransitionError) as exc_info:
            validate_transition_or_raise(
                ArtifactType.IDEA, ArtifactStatus.DRAFT, ArtifactStatus.ACTIVE
            )
        assert "Ungültige Transition" in str(exc_info.value)
        assert "idea" in str(exc_info.value)
        assert "draft" in str(exc_info.value)
        assert "active" in str(exc_info.value)

    def test_idea_transitions(self):
        """Idea-spezifische Transitionen."""
        # Draft → Done (promote to spec) ist erlaubt
        assert validate_transition(
            ArtifactType.IDEA, ArtifactStatus.DRAFT, ArtifactStatus.DONE
        ) is True
        # Draft → Archived (verwerfen) ist erlaubt
        assert validate_transition(
            ArtifactType.IDEA, ArtifactStatus.DRAFT, ArtifactStatus.ARCHIVED
        ) is True
        # Draft → Active ist NICHT erlaubt
        assert validate_transition(
            ArtifactType.IDEA, ArtifactStatus.DRAFT, ArtifactStatus.ACTIVE
        ) is False

    def test_spec_transitions(self):
        """Spec-spezifische Transitionen."""
        # Draft → Active ist erlaubt
        assert validate_transition(
            ArtifactType.SPEC, ArtifactStatus.DRAFT, ArtifactStatus.ACTIVE
        ) is True
        # Active → Blocked ist erlaubt
        assert validate_transition(
            ArtifactType.SPEC, ArtifactStatus.ACTIVE, ArtifactStatus.BLOCKED
        ) is True
        # Blocked → Active (entblockt) ist erlaubt
        assert validate_transition(
            ArtifactType.SPEC, ArtifactStatus.BLOCKED, ArtifactStatus.ACTIVE
        ) is True
        # Active → Done ist erlaubt
        assert validate_transition(
            ArtifactType.SPEC, ArtifactStatus.ACTIVE, ArtifactStatus.DONE
        ) is True

    def test_task_transitions(self):
        """Task-spezifische Transitionen."""
        # Draft → Active ist erlaubt
        assert validate_transition(
            ArtifactType.TASK, ArtifactStatus.DRAFT, ArtifactStatus.ACTIVE
        ) is True
        # Active → Blocked ist erlaubt
        assert validate_transition(
            ArtifactType.TASK, ArtifactStatus.ACTIVE, ArtifactStatus.BLOCKED
        ) is True
        # Active → Done ist erlaubt
        assert validate_transition(
            ArtifactType.TASK, ArtifactStatus.ACTIVE, ArtifactStatus.DONE
        ) is True
        # Blocked → Active (entblockt) ist erlaubt
        assert validate_transition(
            ArtifactType.TASK, ArtifactStatus.BLOCKED, ArtifactStatus.ACTIVE
        ) is True
        # Done → Active (wiedereröffnet) ist erlaubt
        assert validate_transition(
            ArtifactType.TASK, ArtifactStatus.DONE, ArtifactStatus.ACTIVE
        ) is True

    def test_decision_transitions(self):
        """Decision-spezifische Transitionen."""
        # Draft → Done (Entscheidung getroffen) ist erlaubt
        assert validate_transition(
            ArtifactType.DECISION, ArtifactStatus.DRAFT, ArtifactStatus.DONE
        ) is True
        # Draft → Active ist NICHT erlaubt
        assert validate_transition(
            ArtifactType.DECISION, ArtifactStatus.DRAFT, ArtifactStatus.ACTIVE
        ) is False

    def test_get_allowed_transitions(self):
        """get_allowed_transitions gibt korrekte Liste zurück."""
        allowed = get_allowed_transitions(
            ArtifactType.TASK, ArtifactStatus.ACTIVE
        )
        assert "done" in allowed
        assert "blocked" in allowed
        assert "archived" in allowed
        assert "draft" not in allowed

    def test_get_allowed_transitions_archived(self):
        """Archivierte Artifacts haben leere Liste."""
        allowed = get_allowed_transitions(
            ArtifactType.TASK, ArtifactStatus.ARCHIVED
        )
        assert allowed == []

    def test_get_transition_graph(self):
        """get_transition_graph gibt vollständigen Graphen zurück."""
        graph = get_transition_graph()
        assert "task" in graph
        assert "idea" in graph
        assert "spec" in graph
        assert "decision" in graph
        assert "project" in graph
        assert "code" in graph

        # Task-ACTIVE sollte done, blocked, archived erlauben
        assert "done" in graph["task"]["active"]
        assert "blocked" in graph["task"]["active"]
        assert "archived" in graph["task"]["active"]

    def test_unknown_type_transition(self):
        """Unbekannter Typ wird als ungültig behandelt."""
        # Für nicht-definierte Kombinationen sollte False zurückkommen
        assert validate_transition(
            ArtifactType.TASK, ArtifactStatus.DRAFT, ArtifactStatus.BLOCKED
        ) is False


# =============================================================================
# Event Log Tests
# =============================================================================

class TestEventLog:
    """Tests für den append-only Event Log."""

    def test_record_event(self, event_log):
        """Ein Event aufzeichnen."""
        event_id = event_log.record_event(
            artifact_id="art_001",
            event_type="status_changed",
            from_status="draft",
            to_status="active",
            source="cli",
            reason="Task gestartet",
        )
        assert event_id > 0

    def test_record_creation(self, event_log):
        """Erstellungs-Event aufzeichnen."""
        art = Artifact(
            id="art_001",
            type=ArtifactType.IDEA,
            title="Test Idee",
            status=ArtifactStatus.DRAFT,
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        )
        event_id = event_log.record_creation(art, source="cli")
        assert event_id > 0

    def test_record_status_change(self, event_log):
        """Statusänderungs-Event aufzeichnen."""
        art = Artifact(
            id="art_001",
            type=ArtifactType.TASK,
            title="Test Task",
            status=ArtifactStatus.ACTIVE,
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        )
        event_id = event_log.record_status_change(
            art, ArtifactStatus.DRAFT, source="cli", reason="In Arbeit"
        )
        assert event_id > 0

    def test_record_deletion(self, event_log):
        """Lösch-Event aufzeichnen."""
        event_id = event_log.record_deletion(
            "art_001", source="cli", reason="Nicht mehr benötigt"
        )
        assert event_id > 0

    def test_get_events_by_artifact(self, event_log):
        """Events nach Artifact-ID filtern."""
        event_log.record_event("art_001", "created")
        event_log.record_event("art_001", "status_changed")
        event_log.record_event("art_002", "created")

        events = event_log.get_events(artifact_id="art_001")
        assert len(events) == 2

    def test_get_events_by_type(self, event_log):
        """Events nach Typ filtern."""
        event_log.record_event("art_001", "created")
        event_log.record_event("art_002", "created")
        event_log.record_event("art_001", "status_changed")

        events = event_log.get_events(event_type="created")
        assert len(events) == 2

    def test_get_events_by_source(self, event_log):
        """Events nach Quelle filtern."""
        event_log.record_event("art_001", "created", source="cli")
        event_log.record_event("art_002", "created", source="agent")
        event_log.record_event("art_003", "created", source="cli")

        events = event_log.get_events(source="cli")
        assert len(events) == 2

    def test_get_artifact_timeline(self, event_log):
        """Timeline eines Artifacts abrufen."""
        event_log.record_event("art_001", "created")
        event_log.record_event("art_001", "status_changed",
                               from_status="draft", to_status="active")
        event_log.record_event("art_001", "status_changed",
                               from_status="active", to_status="done")

        timeline = event_log.get_artifact_timeline("art_001")
        assert len(timeline) == 3

    def test_get_recent_events(self, event_log):
        """Letzte Events systemweit abrufen."""
        for i in range(5):
            event_log.record_event(f"art_{i:03d}", "created")

        recent = event_log.get_recent_events(limit=3)
        assert len(recent) == 3

    def test_count_events(self, event_log):
        """Events zählen."""
        event_log.record_event("art_001", "created")
        event_log.record_event("art_001", "status_changed")
        event_log.record_event("art_002", "created")

        assert event_log.count_events() == 3
        assert event_log.count_events(artifact_id="art_001") == 2

    def test_events_are_append_only(self, event_log):
        """Events sind append-only (einmal geschrieben, nie geändert)."""
        event_log.record_event("art_001", "created",
                               metadata={"version": 1})
        event_log.record_event("art_001", "updated",
                               metadata={"version": 2})

        events = event_log.get_events(artifact_id="art_001")
        assert len(events) == 2
        # Das erste Event sollte unverändert sein
        assert events[1]["metadata"] == '{"version": 1}'

    def test_event_with_metadata(self, event_log):
        """Events mit Metadaten aufzeichnen."""
        event_log.record_event(
            "art_001", "status_changed",
            from_status="draft", to_status="active",
            metadata={"reason": "Sprint gestartet", "sprint": "S2"},
        )
        events = event_log.get_events(artifact_id="art_001")
        assert len(events) == 1
        import json
        meta = json.loads(events[0]["metadata"])
        assert meta["reason"] == "Sprint gestartet"
        assert meta["sprint"] == "S2"

    def test_event_with_progress(self, event_log):
        """Events mit Fortschrittsänderung aufzeichnen."""
        event_log.record_event(
            "art_001", "progress_updated",
            from_progress=0.0, to_progress=0.5,
        )
        events = event_log.get_events(artifact_id="art_001")
        assert events[0]["from_progress"] == 0.0
        assert events[0]["to_progress"] == 0.5


# =============================================================================
# Graph Query Layer Tests
# =============================================================================

class TestArtifactGraph:
    """Tests für den Graph Query Layer."""

    def test_get_dependency_graph(self, graph, store):
        """Abhängigkeitsgraph erstellen."""
        t1 = store.create(Artifact(
            id="t1", type=ArtifactType.TASK, title="Task 1",
            status=ArtifactStatus.DONE,
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        ))
        t2 = store.create(Artifact(
            id="t2", type=ArtifactType.TASK, title="Task 2",
            status=ArtifactStatus.ACTIVE, dependencies=["t1"],
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        ))

        # GLOBAL scope, da Artifacts direkt via store.create() ohne parent_id erstellt wurden
        dep_graph = graph.get_dependency_graph("t2", scope=GraphScope.GLOBAL)
        assert len(dep_graph["nodes"]) == 2
        assert len(dep_graph["edges"]) == 1
        assert dep_graph["edges"][0]["from"] == "t2"
        assert dep_graph["edges"][0]["to"] == "t1"

    def test_find_blockers(self, graph, store):
        """Blockierende Artifacts finden."""
        t1 = store.create(Artifact(
            id="t1", type=ArtifactType.TASK, title="Setup",
            status=ArtifactStatus.DRAFT,  # Nicht done → blocker
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        ))
        t2 = store.create(Artifact(
            id="t2", type=ArtifactType.TASK, title="API",
            status=ArtifactStatus.BLOCKED, dependencies=["t1"],
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        ))

        blockers = graph.find_blockers("t2")
        assert len(blockers) == 1
        assert blockers[0].id == "t1"

    def test_find_blockers_no_blockers(self, graph, store):
        """Keine Blocker wenn alle dependencies done sind."""
        t1 = store.create(Artifact(
            id="t1", type=ArtifactType.TASK, title="Setup",
            status=ArtifactStatus.DONE,
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        ))
        t2 = store.create(Artifact(
            id="t2", type=ArtifactType.TASK, title="API",
            status=ArtifactStatus.ACTIVE, dependencies=["t1"],
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        ))

        blockers = graph.find_blockers("t2")
        assert blockers == []

    def test_find_blocked_by(self, graph, store):
        """Finde Artifacts, die von einem bestimmten blockiert werden."""
        t1 = store.create(Artifact(
            id="t1", type=ArtifactType.TASK, title="Setup",
            status=ArtifactStatus.DRAFT,
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        ))
        t2 = store.create(Artifact(
            id="t2", type=ArtifactType.TASK, title="API",
            status=ArtifactStatus.BLOCKED, dependencies=["t1"],
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        ))

        blocked = graph.find_blocked_by("t1")
        assert len(blocked) == 1
        assert blocked[0].id == "t2"

    def test_get_critical_path(self, graph, store):
        """Kritischen Pfad berechnen."""
        # Kette: t1 → t2 → t3 → t4
        t1 = store.create(Artifact(
            id="t1", type=ArtifactType.TASK, title="Setup",
            status=ArtifactStatus.DONE,
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        ))
        t2 = store.create(Artifact(
            id="t2", type=ArtifactType.TASK, title="Datenbank",
            status=ArtifactStatus.ACTIVE, dependencies=["t1"],
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        ))
        t3 = store.create(Artifact(
            id="t3", type=ArtifactType.TASK, title="API",
            status=ArtifactStatus.DRAFT, dependencies=["t2"],
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        ))
        t4 = store.create(Artifact(
            id="t4", type=ArtifactType.TASK, title="Frontend",
            status=ArtifactStatus.DRAFT, dependencies=["t3"],
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        ))

        # Projekt als Root
        project = store.create(Artifact(
            id="proj_1", type=ArtifactType.PROJECT, title="Projekt",
            status=ArtifactStatus.ACTIVE,
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        ))

        critical = graph.get_critical_path("proj_1")
        # Der kritische Pfad sollte die längste Kette sein
        assert len(critical) > 0

    def test_topological_sort(self, graph, store):
        """Topologische Sortierung (Kahn's Algorithmus)."""
        project = store.create(Artifact(
            id="proj_1", type=ArtifactType.PROJECT, title="Projekt",
            status=ArtifactStatus.ACTIVE,
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        ))
        t1 = store.create(Artifact(
            id="t1", type=ArtifactType.TASK, title="Setup",
            status=ArtifactStatus.DONE, parent_id="proj_1",
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        ))
        t2 = store.create(Artifact(
            id="t2", type=ArtifactType.TASK, title="Datenbank",
            status=ArtifactStatus.ACTIVE, parent_id="proj_1",
            dependencies=["t1"],
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        ))
        t3 = store.create(Artifact(
            id="t3", type=ArtifactType.TASK, title="API",
            status=ArtifactStatus.DRAFT, parent_id="proj_1",
            dependencies=["t2"],
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        ))

        sorted_arts = graph.topological_sort("proj_1")
        # t1 sollte vor t2 kommen, t2 vor t3
        ids = [a.id for a in sorted_arts]
        assert ids.index("t1") < ids.index("t2")
        assert ids.index("t2") < ids.index("t3")

    def test_analyze_impact(self, graph, store):
        """Impact-Analyse durchführen."""
        t1 = store.create(Artifact(
            id="t1", type=ArtifactType.TASK, title="Setup",
            status=ArtifactStatus.DRAFT,
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        ))
        t2 = store.create(Artifact(
            id="t2", type=ArtifactType.TASK, title="API",
            status=ArtifactStatus.BLOCKED, dependencies=["t1"],
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        ))

        impact = graph.analyze_impact("t1")
        assert impact["artifact"]["id"] == "t1"
        assert len(impact["direct_dependents"]) == 1
        assert impact["direct_dependents"][0]["id"] == "t2"

    def test_get_project_health(self, graph, store):
        """Projekt-Gesundheit berechnen."""
        project = store.create(Artifact(
            id="proj_1", type=ArtifactType.PROJECT, title="Projekt",
            status=ArtifactStatus.ACTIVE,
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        ))
        t1 = store.create(Artifact(
            id="t1", type=ArtifactType.TASK, title="Setup",
            status=ArtifactStatus.DONE, parent_id="proj_1",
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        ))
        t2 = store.create(Artifact(
            id="t2", type=ArtifactType.TASK, title="API",
            status=ArtifactStatus.ACTIVE, parent_id="proj_1",
            dependencies=["t1"],
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        ))

        health = graph.get_project_health("proj_1")
        assert health["total_artifacts"] >= 3
        assert health["tasks"]["total"] == 2
        assert health["tasks"]["done"] == 1
        assert health["tasks"]["active"] == 1
        assert health["progress"] == 0.5

    def test_detect_cycles(self, graph, store):
        """Zykluserkennung."""
        project = store.create(Artifact(
            id="proj_1", type=ArtifactType.PROJECT, title="Projekt",
            status=ArtifactStatus.ACTIVE,
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        ))
        t1 = store.create(Artifact(
            id="t1", type=ArtifactType.TASK, title="Task 1",
            status=ArtifactStatus.DRAFT, parent_id="proj_1",
            dependencies=["t2"],
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        ))
        t2 = store.create(Artifact(
            id="t2", type=ArtifactType.TASK, title="Task 2",
            status=ArtifactStatus.DRAFT, parent_id="proj_1",
            dependencies=["t1"],
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        ))

        health = graph.get_project_health("proj_1")
        assert health["has_cycles"] is True

    def test_nonexistent_artifact(self, graph):
        """Nicht-existierendes Artifact im Graph."""
        assert graph.get_dependency_graph("nonexistent") == {"nodes": [], "edges": []}
        assert graph.find_blockers("nonexistent") == []
        assert graph.find_blocked_by("nonexistent") == []
        assert graph.get_critical_path("nonexistent") == []
        assert graph.analyze_impact("nonexistent") == {}

    def test_recursive_blockers(self, graph, store):
        """Rekursive Blocker-Suche."""
        # t1 → t2 → t3 (t1 blockiert t2, t2 blockiert t3)
        t1 = store.create(Artifact(
            id="t1", type=ArtifactType.TASK, title="Root Blocker",
            status=ArtifactStatus.DRAFT,
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        ))
        t2 = store.create(Artifact(
            id="t2", type=ArtifactType.TASK, title="Mid",
            status=ArtifactStatus.BLOCKED, dependencies=["t1"],
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        ))
        t3 = store.create(Artifact(
            id="t3", type=ArtifactType.TASK, title="Leaf",
            status=ArtifactStatus.BLOCKED, dependencies=["t2"],
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        ))

        blockers = graph.find_blockers("t3")
        assert len(blockers) == 2  # t1 und t2
        blocker_ids = {b.id for b in blockers}
        assert "t1" in blocker_ids
        assert "t2" in blocker_ids
