#!/usr/bin/env python3
"""Test the full output pipeline including OutputFilter and Structured Output."""

import sys
sys.path.insert(0, '.')

from core.output_filter import OutputFilter
from core.processing.response_processor import ResponseContractProcessor
from core.contracts.response_contract import OutputChannel
from core.processing.structured_orchestrator_integration import StructuredOrchestratorIntegration, StructuredOutputConfig
from core.contracts.structured_schema import StructuredOutput, OutputChannel as StructuredOutputChannel

def test_output_filter():
    """Test OutputFilter with various reasoning patterns."""
    print("=" * 80)
    print("OutputFilter Tests")
    print("=" * 80)
    
    filter = OutputFilter(debug_mode=False, strict_mode=True)
    
    # Test 1: Qwen-style reasoning
    raw_text1 = """Thinking: I need to analyze the user's question about the capital of France. 
The capital of France is Paris, which is located in northern France.
Final Answer: Paris"""
    
    contract1 = filter.filter(raw_text1)
    display1 = filter.get_display_output(contract1)
    print(f"Test 1 - Qwen-style reasoning:")
    print(f"  Raw: {raw_text1[:80]}...")
    print(f"  Display: {display1}")
    print(f"  Is valid: {filter.is_valid(contract1)}")
    print()
    
    # Test 2: German reasoning
    raw_text2 = """Überlegung: Der Benutzer fragt nach der Hauptstadt von Deutschland.
Ich muss sicherstellen, dass ich die korrekte Antwort gebe.
Die Hauptstadt von Deutschland ist Berlin.
Antwort: Berlin"""
    
    contract2 = filter.filter(raw_text2)
    display2 = filter.get_display_output(contract2)
    print(f"Test 2 - German reasoning:")
    print(f"  Raw: {raw_text2[:80]}...")
    print(f"  Display: {display2}")
    print(f"  Is valid: {filter.is_valid(contract2)}")
    print()
    
    # Test 3: Debug mode (should show reasoning)
    filter_debug = OutputFilter(debug_mode=True, strict_mode=True)
    contract3 = filter_debug.filter(raw_text1)
    display3 = filter_debug.get_display_output(contract3)
    print(f"Test 3 - Debug mode:")
    print(f"  Display: {display3[:100]}...")
    print()

def test_structured_output_integration():
    """Test StructuredOrchestratorIntegration with reasoning detection."""
    print("=" * 80)
    print("StructuredOrchestratorIntegration Tests")
    print("=" * 80)
    
    from core.processing.structured_orchestrator_integration import ValidationMode
    
    config = StructuredOutputConfig(
        enabled=True,
        mode=ValidationMode.STRICT,
        orchestrator_mode="auto",
        feature_flags={"reasoning_detection": True}
    )
    
    integration = StructuredOrchestratorIntegration(config=config)
    
    # Test 1: Raw text with reasoning
    raw_text1 = """Thinking: The user asked about the capital of Italy. I know it's Rome.
Final Answer: Rome"""
    
    try:
        result1 = integration.process_output(raw_text1)
        print(f"Test 1 - Structured output processing:")
        print(f"  Raw: {raw_text1}")
        print(f"  Result type: {type(result1)}")
        print(f"  Version: {result1.version}")
        print(f"  Channels: {len(result1.channels)}")
        
        for channel in result1.channels:
            print(f"    - {channel.channel}: {channel.content[:50]}...")
        print()
    except Exception as e:
        print(f"  Error: {e}")
        print()
    
    # Test 2: JSON-structured output (Phase 9.2 style)
    json_text2 = '{"version": "1.0", "channels": [{"channel": "reasoning", "content": "Thinking about it...", "metadata": {}}, {"channel": "response", "content": "The answer is Paris", "metadata": {"confidence": 0.95}}]}'
    
    try:
        result2 = integration.process_output(json_text2)
        print(f"Test 2 - JSON structured output:")
        print(f"  Raw: {json_text2[:80]}...")
        print(f"  Result type: {type(result2)}")
        print(f"  Version: {result2.version}")
        
        for channel in result2.channels:
            print(f"    - {channel.channel}: {channel.content[:50]}...")
        print()
    except Exception as e:
        print(f"  Error: {e}")
        print()

def test_real_world_scenarios():
    """Test real-world scenarios that might cause issues."""
    print("=" * 80)
    print("Real-World Scenario Tests")
    print("=" * 80)
    
    processor = ResponseContractProcessor(strict_mode=True)
    
    # Scenario 1: Multiple reasoning blocks
    raw_text1 = """Thinking: Let me analyze this step by step.
First, I need to understand the question.
The question is about the capital of France.

Thinking: Now I recall that Paris is the capital.
I should provide a clear answer.

Final Answer: The capital of France is Paris."""
    
    contract1 = processor.process(raw_text1)
    print(f"Scenario 1 - Multiple reasoning blocks:")
    print(f"  Reasoning: {contract1.get_channel(OutputChannel.REASONING)[:100]}...")
    print(f"  Response: {contract1.get_channel(OutputChannel.RESPONSE)}")
    print(f"  Display: {contract1.get_display_output(debug_mode=False)}")
    print()
    
    # Scenario 2: No clear answer marker (just reasoning)
    raw_text2 = """I think the answer might be Paris, but I'm not completely sure.
Let me double-check my facts.
Actually, yes, Paris is definitely the capital of France."""
    
    contract2 = processor.process(raw_text2)
    print(f"Scenario 2 - No clear markers:")
    print(f"  Reasoning: {contract1.get_channel(OutputChannel.REASONING)}")
    print(f"  Response: {contract2.get_channel(OutputChannel.RESPONSE)}")
    print(f"  Display: {contract2.get_display_output(debug_mode=False)}")
    print()
    
    # Scenario 3: Mixed languages
    raw_text3 = """Thinking: Der Benutzer fragt nach der Hauptstadt von Frankreich.
Ich weiß, dass Paris die Hauptstadt ist.
Response: Paris ist die Hauptstadt von Frankreich."""
    
    contract3 = processor.process(raw_text3)
    print(f"Scenario 3 - Mixed languages:")
    print(f"  Reasoning: {contract3.get_channel(OutputChannel.REASONING)}")
    print(f"  Response: {contract3.get_channel(OutputChannel.RESPONSE)}")
    print(f"  Display: {contract3.get_display_output(debug_mode=False)}")
    print()

if __name__ == "__main__":
    print("Full Output Pipeline Test Suite")
    print("=" * 80)
    print()
    
    test_output_filter()
    test_structured_output_integration()
    test_real_world_scenarios()
    
    print("=" * 80)
    print("All tests completed.")