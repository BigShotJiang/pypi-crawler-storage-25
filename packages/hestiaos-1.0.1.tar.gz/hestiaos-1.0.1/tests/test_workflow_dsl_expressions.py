"""
Tests for Workflow DSL — expressions.py (Expression Engine).
"""

import pytest

from core.workflow_dsl.expressions import (
    ExpressionEngine,
    ExpressionError,
    ContextNode,
    ALLOWED_ROOTS,
    MAX_DEPTH,
)


class TestContextNode:
    def test_scalar_value(self):
        node = ContextNode(value=42, path="test", depth=0)
        assert node.value == 42
        assert node.path == "test"
        assert node._depth == 0

    def test_dict_access(self):
        node = ContextNode(value={"a": {"b": 1}}, path="root", depth=0)
        child = node.get("a")
        assert child.value == {"b": 1}
        assert child.path == "root.a"
        assert child._depth == 1

    def test_dict_key_not_found(self):
        node = ContextNode(value={"a": 1}, path="root", depth=0)
        with pytest.raises(ExpressionError, match="not found"):
            node.get("b")

    def test_list_access(self):
        node = ContextNode(value=[10, 20, 30], path="root", depth=0)
        child = node.get("1")
        assert child.value == 20
        assert child.path == "root[1]"

    def test_list_index_out_of_range(self):
        node = ContextNode(value=[10, 20], path="root", depth=0)
        with pytest.raises(ExpressionError, match="Cannot access index"):
            node.get("5")

    def test_non_container_access_raises(self):
        node = ContextNode(value=42, path="root", depth=0)
        with pytest.raises(ExpressionError, match="Cannot access key"):
            node.get("anything")

    def test_depth_limit(self):
        node = ContextNode(
            value={"a": {"b": {"c": {"d": {"e": {"f": 1}}}}}},
            path="root",
            depth=5,
        )
        with pytest.raises(ExpressionError, match="Maximum depth"):
            node.get("a")

    def test_repr(self):
        node = ContextNode(value="hello", path="test.path", depth=2)
        r = repr(node)
        assert "test.path" in r
        assert "depth=2" in r


class TestExpressionEngine:
    def setup_method(self):
        self.engine = ExpressionEngine()
        self.context = {
            "trigger": {
                "payload": {"code": "print('hello')", "language": "python"},
                "type": "webhook",
                "source": "gitlab",
                "correlation_id": "abc-123",
                "timestamp": "2025-01-01T00:00:00",
                "metadata": {},
                "workflow_name": "code_review",
            },
            "steps": {"step_1": {"result": "analysis complete"}},
            "config": {"model": "gpt-4", "temperature": 0.7},
            "env": {"HOME": "/home/user", "USER": "admin"},
            "workflow": {
                "name": "code_review",
                "version": "1.0.0",
                "description": "Code review pipeline",
            },
        }

    def test_no_expression_returns_original(self):
        result = self.engine.resolve("hello world", self.context)
        assert result == "hello world"

    def test_pure_expression_preserves_type(self):
        result = self.engine.resolve("${trigger.type}", self.context)
        assert result == "webhook"
        assert isinstance(result, str)

    def test_pure_expression_nested(self):
        result = self.engine.resolve("${trigger.payload.language}", self.context)
        assert result == "python"

    def test_pure_expression_float(self):
        result = self.engine.resolve("${config.temperature}", self.context)
        assert result == 0.7
        assert isinstance(result, float)

    def test_mixed_content(self):
        result = self.engine.resolve(
            "Model: ${config.model}, Lang: ${trigger.payload.language}",
            self.context,
        )
        assert result == "Model: gpt-4, Lang: python"

    def test_unknown_root_raises(self):
        with pytest.raises(ExpressionError, match="not allowed"):
            self.engine.resolve("${unknown.key}", self.context)

    def test_disallowed_sub_path_raises(self):
        with pytest.raises(ExpressionError, match="not allowed"):
            self.engine.resolve("${trigger.secret}", self.context)

    def test_env_whitelist(self):
        result = self.engine.resolve("${env.USER}", self.context)
        assert result == "admin"

    def test_env_disallowed_key_raises(self):
        with pytest.raises(ExpressionError, match="not allowed"):
            self.engine.resolve("${env.AWS_SECRET_KEY}", self.context)

    def test_workflow_fields(self):
        result = self.engine.resolve("${workflow.name}", self.context)
        assert result == "code_review"

    def test_steps_access(self):
        result = self.engine.resolve("${steps.step_1.result}", self.context)
        assert result == "analysis complete"

    def test_resolve_all(self):
        mapping = {"model": "${config.model}", "lang": "${trigger.payload.language}"}
        result = self.engine.resolve_all(mapping, self.context)
        assert result == {"model": "gpt-4", "lang": "python"}

    def test_resolve_all_error_propagates(self):
        mapping = {"bad": "${unknown.root}"}
        with pytest.raises(ExpressionError, match="Failed to resolve 'bad'"):
            self.engine.resolve_all(mapping, self.context)

    def test_validate_expression_valid(self):
        assert self.engine.validate_expression("${trigger.type}") is True
        assert self.engine.validate_expression("${config.model}") is True
        assert self.engine.validate_expression("${env.HOME}") is True

    def test_validate_expression_invalid_format(self):
        with pytest.raises(ExpressionError, match="Invalid expression format"):
            self.engine.validate_expression("trigger.type")

    def test_validate_expression_empty(self):
        with pytest.raises(ExpressionError, match="Empty expression"):
            self.engine.validate_expression("${}")

    def test_validate_expression_unknown_root(self):
        with pytest.raises(ExpressionError, match="Unknown root"):
            self.engine.validate_expression("${evil.code}")

    def test_validate_expression_exceeds_depth(self):
        shallow = ExpressionEngine(max_depth=2)
        with pytest.raises(ExpressionError, match="exceeds max depth"):
            shallow.validate_expression("${trigger.payload.code.test}")

    def test_path_traversal_attempt(self):
        with pytest.raises(ExpressionError, match="not allowed|not found"):
            self.engine.resolve("${trigger.payload.__init__}", self.context)

    def test_missing_key_in_context(self):
        with pytest.raises(ExpressionError, match="not found"):
            self.engine.resolve("${trigger.payload.nonexistent}", self.context)

    def test_custom_max_depth(self):
        shallow = ExpressionEngine(max_depth=2)
        with pytest.raises(ExpressionError, match="exceeds maximum depth"):
            shallow.resolve("${trigger.payload.code.test}", self.context)
