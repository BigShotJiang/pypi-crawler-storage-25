import asyncio
import unittest
from unittest.mock import MagicMock, patch
from plugins.mem0_unified import Mem0UnifiedPlugin
from core.embedding_service import embedding_service

class TestMem0Embedding(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        await embedding_service.startup()
        self.plugin = Mem0UnifiedPlugin()
        # Mock initialization status if needed, but LicenseManager should work
        self.plugin._initialized = True
        self.plugin._mode = "api"
        self.plugin.client = MagicMock()

    async def asyncTearDown(self):
        await embedding_service.shutdown()

    async def test_store_memory_generates_embedding(self):
        content = "HestiaOS is a sovereign AI OS."
        metadata = {"category": "test"}
        
        # Mock the store_api to return success
        with patch.object(self.plugin, '_store_api', return_value=True):
            success = await self.plugin.store_memory(content, metadata)
            
            self.assertTrue(success)
            # Check if embedding and hash were added to metadata
            self.assertIn("embedding_768", metadata)
            self.assertIn("embedding_hash", metadata)
            self.assertEqual(len(metadata["embedding_768"]), 768)
            print("Verified: store_memory generated 768-dim embedding metadata.")

    async def test_get_embedding_tool(self):
        text = "Hello world"
        result = await self.plugin.execute("get_embedding", {"text": text}, {})
        
        self.assertTrue(result["success"])
        self.assertEqual(len(result["embedding"]), 768)
        print("Verified: get_embedding tool returned 768-dim embedding.")

if __name__ == "__main__":
    unittest.main()
