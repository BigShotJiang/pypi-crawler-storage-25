#!/usr/bin/env python3
"""
Simple test for KPI metrics functionality.
"""

import sys
from datetime import datetime

# Add the core directory to the path
sys.path.insert(0, '.')

from core.experimentation.metrics_collector import (
    KPIMetrics,
    ExperimentMetricsCollector
)


def test_kpi_metrics_dataclass():
    """Test KPIMetrics dataclass."""
    print("🧪 Testing KPIMetrics dataclass...")
    
    kpi = KPIMetrics(
        intent_accuracy=0.85,
        response_fit=0.72,
        continuation_rate=0.42,
        policy_violations=0,
        refusal_quality=0.8,
        latency=1.5,
        token_usage=245
    )
    
    # Test to_dict method
    kpi_dict = kpi.to_dict()
    assert kpi_dict["intent_accuracy"] == 0.85
    assert kpi_dict["response_fit"] == 0.72
    assert kpi_dict["continuation_rate"] == 0.42
    assert kpi_dict["policy_violations"] == 0
    assert kpi_dict["refusal_quality"] == 0.8
    assert kpi_dict["latency"] == 1.5
    assert kpi_dict["token_usage"] == 245
    
    print("✅ KPIMetrics dataclass test passed!")
    return True


def test_response_fit_calculation():
    """Test response fit calculation."""
    print("\n🧪 Testing response fit calculation...")
    
    collector = ExperimentMetricsCollector()
    
    # Test with step-by-step explainer text
    response_text = "Zuerst öffne die App. Dann klicke auf Einstellungen. Anschließend wähle den gewünschten Modus."
    
    response_fit = collector.calculate_response_fit(
        response_text=response_text,
        expected_tone="explainer",
        expected_structure="step_by_step",
        expected_verbosity=30
    )
    
    print(f"📊 Response fit score: {response_fit:.2f}")
    assert 0.0 <= response_fit <= 1.0, "Response fit score out of range"
    
    # Test individual heuristic functions
    tone_score = collector._calculate_tone_alignment(response_text, "explainer")
    print(f"📊 Tone alignment score: {tone_score:.2f}")
    assert 0.0 <= tone_score <= 1.0
    
    structure_score = collector._calculate_structure_score(response_text, "step_by_step")
    print(f"📊 Structure score: {structure_score:.2f}")
    assert 0.0 <= structure_score <= 1.0
    
    verbosity_score = collector._calculate_verbosity_score(response_text, 30)
    print(f"📊 Verbosity score: {verbosity_score:.2f}")
    assert 0.0 <= verbosity_score <= 1.0
    
    print("✅ Response fit calculation test passed!")
    return True


def test_intent_accuracy():
    """Test intent accuracy calculation."""
    print("\n🧪 Testing intent accuracy calculation...")
    
    collector = ExperimentMetricsCollector()
    
    # Test matching intents
    accuracy_match = collector.calculate_intent_accuracy(
        detected_intent="app_navigation",
        expected_intent="app_navigation"
    )
    assert accuracy_match == 1.0, "Matching intents should have accuracy 1.0"
    
    # Test mismatched intents
    accuracy_mismatch = collector.calculate_intent_accuracy(
        detected_intent="app_navigation",
        expected_intent="file_management"
    )
    assert accuracy_mismatch == 0.0, "Mismatched intents should have accuracy 0.0"
    
    print("✅ Intent accuracy test passed!")
    return True


def test_refusal_quality():
    """Test refusal quality calculation."""
    print("\n🧪 Testing refusal quality calculation...")
    
    collector = ExperimentMetricsCollector()
    
    # Test perfect refusal
    perfect_quality = collector.calculate_refusal_quality(
        refusal_text="Das kann ich leider nicht tun, aber ich kann dir bei etwas anderem helfen.",
        has_explanation=True,
        has_friendly_tone=True,
        has_alternative=True
    )
    assert perfect_quality == 1.0, "Perfect refusal should have quality 1.0"
    
    # Test partial refusal
    partial_quality = collector.calculate_refusal_quality(
        refusal_text="Nein.",
        has_explanation=False,
        has_friendly_tone=False,
        has_alternative=False
    )
    assert partial_quality == 0.0, "Poor refusal should have quality 0.0"
    
    # Test medium refusal
    medium_quality = collector.calculate_refusal_quality(
        refusal_text="Das kann ich nicht tun.",
        has_explanation=True,
        has_friendly_tone=True,
        has_alternative=False
    )
    assert medium_quality == 2/3, "Medium refusal should have quality 2/3"
    
    print(f"📊 Perfect refusal quality: {perfect_quality:.2f}")
    print(f"📊 Partial refusal quality: {partial_quality:.2f}")
    print(f"📊 Medium refusal quality: {medium_quality:.2f}")
    
    print("✅ Refusal quality test passed!")
    return True


def test_heuristic_functions():
    """Test individual heuristic functions."""
    print("\n🧪 Testing heuristic functions...")
    
    collector = ExperimentMetricsCollector()
    
    # Test tone alignment
    simple_text = "Das ist einfach und verständlich erklärt."
    simple_score = collector._calculate_tone_alignment(simple_text, "simple")
    print(f"📊 Simple tone score: {simple_score:.2f}")
    assert simple_score > 0.0
    
    friendly_text = "Hallo! Gerne helfe ich dir weiter. Bitte schön!"
    friendly_score = collector._calculate_tone_alignment(friendly_text, "friendly")
    print(f"📊 Friendly tone score: {friendly_score:.2f}")
    assert friendly_score > 0.0
    
    # Test structure score
    step_text = "1. Zuerst öffne die App. 2. Dann klicke auf Einstellungen. 3. Anschließend wähle den Modus."
    step_score = collector._calculate_structure_score(step_text, "step_by_step")
    print(f"📊 Step-by-step structure score: {step_score:.2f}")
    assert step_score > 0.0
    
    bullet_text = "• Erster Punkt\n• Zweiter Punkt\n• Dritter Punkt"
    bullet_score = collector._calculate_structure_score(bullet_text, "bullet_points")
    print(f"📊 Bullet points structure score: {bullet_score:.2f}")
    assert bullet_score > 0.0
    
    # Test verbosity score
    short_text = "Kurze Antwort."
    long_text = "Dies ist eine sehr ausführliche Antwort mit vielen Details und Erklärungen, die deutlich über das notwendige Maß hinausgeht."
    
    short_score = collector._calculate_verbosity_score(short_text, 10)
    long_score = collector._calculate_verbosity_score(long_text, 10)
    
    print(f"📊 Short text verbosity score: {short_score:.2f}")
    print(f"📊 Long text verbosity score: {long_score:.2f}")
    
    print("✅ Heuristic functions test passed!")
    return True


def main():
    """Run all KPI tests."""
    print("🚀 Starting KPI metrics tests...")
    
    try:
        test_kpi_metrics_dataclass()
        test_response_fit_calculation()
        test_intent_accuracy()
        test_refusal_quality()
        test_heuristic_functions()
        
        print("\n🎉 All KPI tests completed successfully!")
        print("\n📋 Summary of implemented KPI functions:")
        print("  • KPIMetrics dataclass with 7 core metrics")
        print("  • Response fit composite heuristic (tone + structure + verbosity)")
        print("  • Intent accuracy calculation")
        print("  • Refusal quality scoring")
        print("  • Tone alignment detection (simple, friendly, professional, explainer)")
        print("  • Structure scoring (step-by-step, bullet points, freeform)")
        print("  • Verbosity scoring based on token count deviation")
        print("  • KPI metrics registration in default metrics")
        
        return 0
        
    except Exception as e:
        print(f"\n❌ Test failed with error: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)