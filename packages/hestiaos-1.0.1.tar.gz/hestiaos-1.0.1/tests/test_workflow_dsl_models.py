"""
Tests for Workflow DSL — models.py (Pydantic Contract Layer).
"""

import pytest
from datetime import datetime
from pydantic import ValidationError

from core.workflow_dsl.models import (
    StepType,
    TriggerType,
    RetryConfig,
    ErrorHandlingConfig,
    ResourceBudget,
    TriggerConfig,
    StepDefinition,
    WorkflowDefinition,
    WorkflowMetadata,
)


class TestStepType:
    def test_values(self):
        assert StepType.LLM == "llm"
        assert StepType.TOOL == "tool"
        assert StepType.CONDITION == "condition"
        assert StepType.SUBWORKFLOW == "subworkflow"
        assert StepType.TRANSFORM == "transform"


class TestTriggerType:
    def test_values(self):
        assert TriggerType.WEBHOOK == "webhook"
        assert TriggerType.EVENT == "event"
        assert TriggerType.SCHEDULE == "schedule"
        assert TriggerType.MANUAL == "manual"


class TestRetryConfig:
    def test_defaults(self):
        config = RetryConfig()
        assert config.max_retries == 2
        assert config.delay_seconds == 1.0
        assert config.backoff_multiplier == 2.0

    def test_custom_values(self):
        config = RetryConfig(max_retries=5, delay_seconds=0.5, backoff_multiplier=3.0)
        assert config.max_retries == 5
        assert config.delay_seconds == 0.5
        assert config.backoff_multiplier == 3.0


class TestErrorHandlingConfig:
    def test_defaults(self):
        config = ErrorHandlingConfig()
        assert config.max_retries == 2
        assert config.on_failure == "fail"
        assert config.notification is None

    def test_custom_values(self):
        config = ErrorHandlingConfig(
            max_retries=3, on_failure="notify", notification={"webhook": "http://..."}
        )
        assert config.max_retries == 3
        assert config.on_failure == "notify"
        assert config.notification == {"webhook": "http://..."}


class TestResourceBudget:
    def test_defaults(self):
        budget = ResourceBudget()
        assert budget.max_steps == 50
        assert budget.max_depth == 10
        assert budget.max_concurrency == 5
        assert budget.max_execution_seconds == 300

    def test_custom_values(self):
        budget = ResourceBudget(
            max_steps=10, max_depth=3, max_concurrency=2, max_execution_seconds=60
        )
        assert budget.max_steps == 10
        assert budget.max_depth == 3
        assert budget.max_concurrency == 2
        assert budget.max_execution_seconds == 60


class TestTriggerConfig:
    def test_minimal(self):
        config = TriggerConfig(type=TriggerType.WEBHOOK)
        assert config.type == TriggerType.WEBHOOK
        assert config.config == {}

    def test_with_config(self):
        config = TriggerConfig(
            type=TriggerType.EVENT,
            config={"event_type": "code_review.completed", "filter": {"project": "hestia"}},
        )
        assert config.type == TriggerType.EVENT
        assert config.config["event_type"] == "code_review.completed"


class TestStepDefinition:
    def test_minimal(self):
        step = StepDefinition(id="step_1", name="Test Step", type=StepType.LLM)
        assert step.id == "step_1"
        assert step.name == "Test Step"
        assert step.type == StepType.LLM
        assert step.config == {}
        assert step.inputs == {}
        assert step.outputs == {}
        assert step.branches is None
        assert step.retry is None
        assert step.timeout_seconds == 30

    def test_id_empty_raises(self):
        with pytest.raises(ValidationError, match="must not be empty"):
            StepDefinition(id="", name="Test", type=StepType.LLM)

    def test_id_invalid_chars_raises(self):
        with pytest.raises(ValidationError, match="invalid characters"):
            StepDefinition(id="step with spaces", name="Test", type=StepType.LLM)

    def test_id_valid_with_special_chars(self):
        step = StepDefinition(id="step-1_test", name="Test", type=StepType.LLM)
        assert step.id == "step-1_test"

    def test_branches_valid_keys(self):
        step = StepDefinition(
            id="cond_1",
            name="Condition",
            type=StepType.CONDITION,
            branches={
                "pass": [StepDefinition(id="on_pass", name="On Pass", type=StepType.LLM)],
                "fail": [StepDefinition(id="on_fail", name="On Fail", type=StepType.TOOL)],
            },
        )
        assert "pass" in step.branches
        assert "fail" in step.branches

    def test_branches_invalid_key_raises(self):
        with pytest.raises(ValidationError, match="invalid"):
            StepDefinition(
                id="cond_1",
                name="Condition",
                type=StepType.CONDITION,
                branches={
                    "maybe": [StepDefinition(id="on_maybe", name="On Maybe", type=StepType.LLM)]
                },
            )

    def test_with_retry(self):
        step = StepDefinition(
            id="step_1",
            name="Test",
            type=StepType.TOOL,
            retry=RetryConfig(max_retries=3, delay_seconds=2.0),
        )
        assert step.retry.max_retries == 3
        assert step.retry.delay_seconds == 2.0


class TestWorkflowDefinition:
    def _make_step(self, step_id: str, step_type: StepType = StepType.LLM) -> StepDefinition:
        return StepDefinition(id=step_id, name=step_id, type=step_type)

    def test_minimal(self):
        wf = WorkflowDefinition(
            name="test_workflow",
            version="1.0.0",
            steps=[self._make_step("step_1")],
        )
        assert wf.name == "test_workflow"
        assert wf.version == "1.0.0"
        assert len(wf.steps) == 1
        assert wf.triggers == []
        assert wf.description is None
        assert wf.error_handling is None
        assert wf.config is None
        assert wf.resource_budget is None

    def test_name_empty_raises(self):
        with pytest.raises(ValidationError, match="must not be empty"):
            WorkflowDefinition(name="", version="1.0.0", steps=[self._make_step("s1")])

    def test_name_invalid_chars_raises(self):
        with pytest.raises(ValidationError, match="invalid characters"):
            WorkflowDefinition(
                name="test workflow!", version="1.0.0", steps=[self._make_step("s1")]
            )

    def test_version_invalid_semver_raises(self):
        with pytest.raises(ValidationError, match="SemVer"):
            WorkflowDefinition(name="test", version="1.0", steps=[self._make_step("s1")])

    def test_version_valid_semver(self):
        wf = WorkflowDefinition(name="test", version="2.3.4", steps=[self._make_step("s1")])
        assert wf.version == "2.3.4"

    def test_duplicate_step_ids_raises(self):
        with pytest.raises(ValidationError, match="Duplicate"):
            WorkflowDefinition(
                name="test",
                version="1.0.0",
                steps=[self._make_step("s1"), self._make_step("s1")],
            )

    def test_with_triggers(self):
        wf = WorkflowDefinition(
            name="test",
            version="1.0.0",
            steps=[self._make_step("s1")],
            triggers=[
                TriggerConfig(type=TriggerType.WEBHOOK),
                TriggerConfig(type=TriggerType.EVENT, config={"event_type": "test"}),
            ],
        )
        assert len(wf.triggers) == 2

    def test_with_error_handling(self):
        wf = WorkflowDefinition(
            name="test",
            version="1.0.0",
            steps=[self._make_step("s1")],
            error_handling=ErrorHandlingConfig(max_retries=5, on_failure="notify"),
        )
        assert wf.error_handling.max_retries == 5

    def test_with_resource_budget(self):
        wf = WorkflowDefinition(
            name="test",
            version="1.0.0",
            steps=[self._make_step("s1")],
            resource_budget=ResourceBudget(max_steps=10),
        )
        assert wf.resource_budget.max_steps == 10

    def test_get_resource_budget_default(self):
        wf = WorkflowDefinition(name="test", version="1.0.0", steps=[self._make_step("s1")])
        budget = wf.get_resource_budget()
        assert budget.max_steps == 50

    def test_get_resource_budget_custom(self):
        wf = WorkflowDefinition(
            name="test",
            version="1.0.0",
            steps=[self._make_step("s1")],
            resource_budget=ResourceBudget(max_steps=5),
        )
        budget = wf.get_resource_budget()
        assert budget.max_steps == 5


class TestWorkflowMetadata:
    def test_minimal(self):
        meta = WorkflowMetadata(name="test", version="1.0.0")
        assert meta.name == "test"
        assert meta.version == "1.0.0"
        assert meta.description is None
        assert meta.trigger_types == []
        assert meta.step_count == 0
        assert isinstance(meta.created_at, datetime)
        assert isinstance(meta.updated_at, datetime)

    def test_full(self):
        meta = WorkflowMetadata(
            name="test",
            version="2.0.0",
            description="A test workflow",
            trigger_types=["webhook", "manual"],
            step_count=5,
        )
        assert meta.description == "A test workflow"
        assert meta.trigger_types == ["webhook", "manual"]
        assert meta.step_count == 5
