"""
Contract-Tests für die zwei EventBus-Varianten im System.

Stellt sicher, dass die Async-Boundary-Contracts eingehalten werden:
- EventBusAdapter (sync, fire-and-forget) → publish() gibt None zurück
- Legacy EventBus (async) → publish() gibt Coroutine zurück

CI-CRT-ASYNC: Async Boundary Contract Enforcement

HINWEIS: Die Adapter-Tests können die Klasse nicht direkt importieren (zirkulärer Import
über core.agent.event_bus → core.orchestrator.kernel → core.event_bus.__init__).
Stattdessen wird die Klasse per AST analysiert oder als Text geparst.
"""
import ast
import asyncio
from pathlib import Path
from unittest.mock import MagicMock

import pytest


# ---------------------------------------------------------------------------
# AST-basierte Analyse (kein Import nötig)
# ---------------------------------------------------------------------------

def _parse_source(file_path: str) -> ast.Module:
    """Parst eine Python-Datei und gibt den AST zurück."""
    source = Path(file_path).read_text()
    return ast.parse(source)


def _is_async_def(tree: ast.Module, class_name: str, method_name: str) -> bool:
    """Prüft, ob eine Methode in einer Klasse als async def definiert ist."""
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef) and node.name == class_name:
            for item in node.body:
                if isinstance(item, ast.FunctionDef) and item.name == method_name:
                    return False  # sync def
                if isinstance(item, ast.AsyncFunctionDef) and item.name == method_name:
                    return True   # async def
    raise ValueError(f"Method {class_name}.{method_name} not found in AST")


# ---------------------------------------------------------------------------
# Tests: EventBusAdapter Contract
# ---------------------------------------------------------------------------

class TestEventBusAdapterContract:
    """Contract: EventBusAdapter.publish() ist sync (fire-and-forget)."""

    ADAPTER_PATH = "core/adapters/event_bus_adapter.py"

    @pytest.fixture(scope="class")
    def adapter_ast(self):
        return _parse_source(self.ADAPTER_PATH)

    def test_publish_is_sync_def(self, adapter_ast):
        """EventBusAdapter.publish() MUSS als sync def (nicht async def) definiert sein."""
        is_async = _is_async_def(adapter_ast, "EventBusAdapter", "publish")
        assert not is_async, (
            "EventBusAdapter.publish() is defined as 'async def', but it should be 'def' (sync). "
            "This is a contract violation: the adapter is the fire-and-forget boundary, "
            "and callers call it without await."
        )

    def test_subscribe_is_sync_def(self, adapter_ast):
        """EventBusAdapter.subscribe() MUSS als sync def definiert sein."""
        is_async = _is_async_def(adapter_ast, "EventBusAdapter", "subscribe")
        assert not is_async, (
            "EventBusAdapter.subscribe() is defined as 'async def', but it should be 'def' (sync)."
        )

    def test_unsubscribe_is_sync_def(self, adapter_ast):
        """EventBusAdapter.unsubscribe() MUSS als sync def definiert sein."""
        is_async = _is_async_def(adapter_ast, "EventBusAdapter", "unsubscribe")
        assert not is_async, (
            "EventBusAdapter.unsubscribe() is defined as 'async def', but it should be 'def' (sync)."
        )


# ---------------------------------------------------------------------------
# Tests: Legacy EventBus Contract
# ---------------------------------------------------------------------------

class TestLegacyEventBusContract:
    """Contract: Legacy EventBus.publish() ist async (gibt Coroutine zurück)."""

    LEGACY_PATH = "core/event_bus.py"

    @pytest.fixture(scope="class")
    def legacy_ast(self):
        return _parse_source(self.LEGACY_PATH)

    def test_publish_is_async_def(self, legacy_ast):
        """Legacy EventBus.publish() MUSS als async def definiert sein."""
        is_async = _is_async_def(legacy_ast, "EventBus", "publish")
        assert is_async, (
            "Legacy EventBus.publish() is defined as 'def' (sync), but it should be 'async def'. "
            "This is a contract violation: the legacy bus is the async boundary, "
            "and callers use await or create_task on its return value."
        )

    def test_subscribe_is_sync_def(self, legacy_ast):
        """Legacy EventBus.subscribe() MUSS als sync def definiert sein (Callback-Registrierung)."""
        is_async = _is_async_def(legacy_ast, "EventBus", "subscribe")
        assert not is_async, (
            "Legacy EventBus.subscribe() is async, but it should be sync."
        )

    def test_unsubscribe_is_sync_def(self, legacy_ast):
        """Legacy EventBus.unsubscribe() MUSS als sync def definiert sein."""
        is_async = _is_async_def(legacy_ast, "EventBus", "unsubscribe")
        assert not is_async, (
            "Legacy EventBus.unsubscribe() is async, but it should be sync."
        )


# ---------------------------------------------------------------------------
# Tests: Adapter kapselt Async komplett selbst (kein Return-Type-Zwang)
# ---------------------------------------------------------------------------

class TestEventBusAdapterAsyncEncapsulation:
    """Testet, dass der Adapter Async komplett selbst kapselt.

    Der Adapter darf NICHT vom Return-Type des Busses abhängen:
    - Wenn bus.publish() eine Coroutine zurückgibt → schedulen
    - Wenn bus.publish() None zurückgibt → nichts tun (sync bus)
    - Wenn bus.publish() einen anderen Typ zurückgibt → warning loggen, nicht crashen
    """

    @pytest.fixture
    def adapter(self):
        """Erzeugt eine EventBusAdapter-Instanz mit Mock-Bus."""
        # Wir können EventBusAdapter nicht direkt importieren (zirkulär).
        # Stattdessen testen wir die Logik isoliert.
        return None

    # ------------------------------------------------------------------
    # Isolierte Tests der publish-Logik (Reimplementierung)
    # ------------------------------------------------------------------

    @staticmethod
    def _adapter_publish_logic(bus_publish_result, has_event_loop=True):
        """
        Reimplementierung der publish()-Logik aus EventBusAdapter.
        Testet das Verhalten bei verschiedenen Return-Typen.
        """
        import asyncio

        result = bus_publish_result

        if asyncio.iscoroutine(result):
            # Coroutine → schedulen
            if has_event_loop:
                try:
                    loop = asyncio.get_event_loop()
                    if loop.is_running():
                        loop.create_task(result)
                        return "scheduled"
                    else:
                        asyncio.run(result)
                        return "run"
                except RuntimeError:
                    asyncio.run(result)
                    return "run_fallback"
            else:
                asyncio.run(result)
                return "run_no_loop"
        elif result is None:
            # None → sync bus, nichts tun
            return "none_ignored"
        else:
            # Weder Coroutine noch None → warning, nicht crashen
            return f"unexpected_{type(result).__name__}_warned"

    def test_coroutine_is_scheduled(self):
        """Coroutine-Rückgabe wird im Event-Loop gescheduled."""
        async def fake_coro():
            return None
        result = self._adapter_publish_logic(fake_coro(), has_event_loop=True)
        # Kann "scheduled" oder "run" sein, je nach Loop-Status
        assert result in ("scheduled", "run", "run_fallback")

    def test_none_is_ignored(self):
        """None-Rückgabe wird ignoriert (sync bus)."""
        result = self._adapter_publish_logic(None)
        assert result == "none_ignored", (
            f"Expected 'none_ignored', got '{result}'. "
            "Adapter should handle sync bus without crashing."
        )

    def test_string_is_warned_not_crashed(self):
        """String-Rückgabe wird gewarnt, nicht gecrasht."""
        result = self._adapter_publish_logic("unexpected")
        assert "unexpected" in result and "warned" in result, (
            f"Expected warning for string, got '{result}'. "
            "Adapter should not crash on unexpected return types."
        )

    def test_int_is_warned_not_crashed(self):
        """Int-Rückgabe wird gewarnt, nicht gecrasht."""
        result = self._adapter_publish_logic(42)
        assert "unexpected" in result and "warned" in result

    def test_dict_is_warned_not_crashed(self):
        """Dict-Rückgabe wird gewarnt, nicht gecrasht."""
        result = self._adapter_publish_logic({"key": "value"})
        assert "unexpected" in result and "warned" in result

    def test_list_is_warned_not_crashed(self):
        """List-Rückgabe wird gewarnt, nicht gecrasht."""
        result = self._adapter_publish_logic([1, 2, 3])
        assert "unexpected" in result and "warned" in result

    def test_bool_is_warned_not_crashed(self):
        """Bool-Rückgabe wird gewarnt, nicht gecrasht."""
        result = self._adapter_publish_logic(True)
        assert "unexpected" in result and "warned" in result
