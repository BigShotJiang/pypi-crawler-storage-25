"""
Tests für die ArtifactTransformationEngine.

Testet:
    - TransformationRegistry (registrieren, abfragen, listen)
    - IdeaToSpecTransformer (IDEA → SPEC)
    - SpecToTaskGraphTransformer (SPEC → TASK-Graph)
    - MergeArtifactsTransformer (mehrere Artifacts → eines)
    - ArtifactTransformationEngine (Orchestrierung)
    - Fehlerfälle (PreconditionError, unbekannter Transformer)
"""

import pytest
from datetime import datetime, timezone

from core.artifact.models import Artifact, ArtifactType, ArtifactStatus
from core.artifact.store import ArtifactStore
from core.artifact.event_log import ArtifactEventLog
from core.artifact.service import ArtifactService
from core.artifact.graph import GraphScope
from core.artifact.transformation import (
    ArtifactTransformationEngine,
    Transformer,
    TransformationType,
    TransformationContext,
    TransformationResult,
    TransformationError,
    PreconditionError,
    TransformationRegistry,
    IdeaToSpecTransformer,
    SpecToTaskGraphTransformer,
    MergeArtifactsTransformer,
)


# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def store():
    s = ArtifactStore(":memory:")
    yield s
    s.close()


@pytest.fixture
def event_log(store):
    return ArtifactEventLog(store.conn)


@pytest.fixture
def service(store, event_log):
    return ArtifactService(store, event_log)


@pytest.fixture
def engine(service):
    eng = ArtifactTransformationEngine(service)
    eng.register_defaults()
    return eng


@pytest.fixture
def sample_idea(service):
    return service.create_artifact(
        type=ArtifactType.IDEA,
        title="KI-gestützte Code-Review",
        content="Ein System, das automatisch Code-Reviews durchführt "
                "und Verbesserungsvorschläge macht.",
        tags=["ai", "code-review", "automation"],
    )


@pytest.fixture
def sample_spec(service, sample_idea):
    """Erzeuge ein SPEC aus einer IDEA, ohne promote_to_spec zu verwenden
    (da dieses complete_artifact aufruft und bei bereits DONE scheitert)."""
    # IDEA direkt auf DONE setzen
    service.update_artifact_fields(
        sample_idea.id,
        status=ArtifactStatus.DONE,
    )
    # SPEC direkt erstellen
    return service.create_artifact(
        type=ArtifactType.SPEC,
        title=f"Spec: {sample_idea.title}",
        content=sample_idea.content,
        tags=sample_idea.tags,
        parent_id=sample_idea.id,
        dependencies=[sample_idea.id],
    )


# =============================================================================
# Tests: TransformationRegistry
# =============================================================================


class TestTransformationRegistry:
    """Tests für die Transformation Registry."""

    def test_register_and_get(self):
        """Transformer registrieren und abrufen."""
        registry = TransformationRegistry()
        transformer = IdeaToSpecTransformer()
        registry.register(transformer)

        retrieved = registry.get(TransformationType.IDEA_TO_SPEC)
        assert retrieved is transformer

    def test_get_by_name(self):
        """Transformer anhand des Namens abrufen."""
        registry = TransformationRegistry()
        registry.register(IdeaToSpecTransformer())

        retrieved = registry.get_by_name("idea_to_spec")
        assert retrieved is not None
        assert retrieved.transformation_type == TransformationType.IDEA_TO_SPEC

    def test_get_by_name_not_found(self):
        """Unbekannter Name gibt None zurück."""
        registry = TransformationRegistry()
        assert registry.get_by_name("nonexistent") is None

    def test_list_types(self):
        """Alle registrierten Typen listen."""
        registry = TransformationRegistry()
        registry.register(IdeaToSpecTransformer())
        registry.register(SpecToTaskGraphTransformer())

        types = registry.list_types()
        assert TransformationType.IDEA_TO_SPEC in types
        assert TransformationType.SPEC_TO_TASK_GRAPH in types

    def test_list_names(self):
        """Alle registrierten Namen listen."""
        registry = TransformationRegistry()
        registry.register(IdeaToSpecTransformer())

        names = registry.list_names()
        assert "idea_to_spec" in names

    def test_duplicate_registration_raises(self):
        """Doppelte Registrierung wirft ValueError."""
        registry = TransformationRegistry()
        registry.register(IdeaToSpecTransformer())

        with pytest.raises(ValueError, match="bereits registriert"):
            registry.register(IdeaToSpecTransformer())

    def test_unregister(self):
        """Transformer entfernen."""
        registry = TransformationRegistry()
        registry.register(IdeaToSpecTransformer())
        registry.unregister(TransformationType.IDEA_TO_SPEC)
        assert registry.get(TransformationType.IDEA_TO_SPEC) is None


# =============================================================================
# Tests: IdeaToSpecTransformer
# =============================================================================


class TestIdeaToSpecTransformer:
    """Tests für IDEA → SPEC Transformation."""

    def test_idea_to_spec_basic(self, engine, sample_idea):
        """IDEA in SPEC transformieren."""
        result = engine.transform(
            sample_idea.id,
            "idea_to_spec",
            scope=GraphScope.PROJECT,
        )

        assert result.success
        assert result.primary is not None
        assert result.primary.type == ArtifactType.SPEC
        assert result.primary.title == sample_idea.title
        assert result.primary.content == sample_idea.content
        assert result.transformation_type == "idea_to_spec"
        assert result.source_id == sample_idea.id

    def test_idea_to_spec_marks_idea_done(self, engine, sample_idea):
        """Quell-IDEA wird auf DONE gesetzt."""
        result = engine.transform(sample_idea.id, "idea_to_spec")

        idea = engine.service.get_artifact(sample_idea.id)
        assert idea is not None
        assert idea.status == ArtifactStatus.DONE

    def test_idea_to_spec_spec_has_correct_type(self, engine, sample_idea):
        """Das erzeugte SPEC hat den richtigen Typ."""
        result = engine.transform(sample_idea.id, "idea_to_spec")
        assert result.primary.type == ArtifactType.SPEC

    def test_idea_to_spec_archived_idea_raises(self, engine, sample_idea):
        """ARCHIVED IDEA kann nicht transformiert werden."""
        engine.service.update_artifact_fields(
            sample_idea.id,
            status=ArtifactStatus.ARCHIVED,
        )

        with pytest.raises(PreconditionError, match="ARCHIVED"):
            engine.transform(sample_idea.id, "idea_to_spec")

    def test_idea_to_spec_wrong_type_raises(self, engine, service):
        """Nicht-IDEA Artifact kann nicht transformiert werden."""
        task = service.create_artifact(
            type=ArtifactType.TASK,
            title="Task",
            content="Beschreibung",
        )

        with pytest.raises(PreconditionError, match="kein IDEA"):
            engine.transform(task.id, "idea_to_spec")

    def test_idea_to_spec_affected_ids(self, engine, sample_idea):
        """affected_ids enthält Quelle und Ziel."""
        result = engine.transform(sample_idea.id, "idea_to_spec")
        assert sample_idea.id in result.affected_ids
        assert result.primary.id in result.affected_ids


# =============================================================================
# Tests: SpecToTaskGraphTransformer
# =============================================================================


class TestSpecToTaskGraphTransformer:
    """Tests für SPEC → TASK-Graph Transformation."""

    def test_spec_to_tasks_basic(self, engine, sample_spec):
        """SPEC in Tasks transformieren."""
        result = engine.transform(
            sample_spec.id,
            "spec_to_task_graph",
            task_descriptions=[
                "Datenmodell entwerfen",
                "API-Endpunkte implementieren",
                "Tests schreiben",
            ],
        )

        assert result.success
        assert len(result.secondary) == 3
        assert all(t.type == ArtifactType.TASK for t in result.secondary)
        assert result.secondary[0].title == "Datenmodell entwerfen"

    def test_spec_to_tasks_default_count(self, engine, sample_spec):
        """Standard-Anzahl Tasks (3) wenn keine descriptions."""
        result = engine.transform(
            sample_spec.id,
            "spec_to_task_graph",
            task_count=3,
        )

        assert len(result.secondary) == 3

    def test_spec_to_tasks_sets_spec_active(self, engine, sample_spec):
        """SPEC wird auf ACTIVE gesetzt."""
        result = engine.transform(
            sample_spec.id,
            "spec_to_task_graph",
            task_descriptions=["Task 1", "Task 2"],
        )

        spec = engine.service.get_artifact(sample_spec.id)
        assert spec is not None
        assert spec.status == ArtifactStatus.ACTIVE

    def test_spec_to_tasks_archived_raises(self, engine, sample_spec):
        """ARCHIVED SPEC kann nicht transformiert werden."""
        engine.service.update_artifact_fields(
            sample_spec.id,
            status=ArtifactStatus.ARCHIVED,
        )

        with pytest.raises(PreconditionError, match="ARCHIVED"):
            engine.transform(
                sample_spec.id,
                "spec_to_task_graph",
                task_descriptions=["Task 1"],
            )

    def test_spec_to_tasks_wrong_type_raises(self, engine, service):
        """Nicht-SPEC Artifact kann nicht transformiert werden."""
        idea = service.create_artifact(
            type=ArtifactType.IDEA,
            title="Idea",
            content="Beschreibung",
        )

        with pytest.raises(PreconditionError, match="kein SPEC"):
            engine.transform(idea.id, "spec_to_task_graph")

    def test_spec_to_tasks_affected_ids(self, engine, sample_spec):
        """affected_ids enthält SPEC und alle Tasks."""
        result = engine.transform(
            sample_spec.id,
            "spec_to_task_graph",
            task_descriptions=["Task 1", "Task 2"],
        )

        assert sample_spec.id in result.affected_ids
        for t in result.secondary:
            assert t.id in result.affected_ids


# =============================================================================
# Tests: MergeArtifactsTransformer
# =============================================================================


class TestMergeArtifactsTransformer:
    """Tests für Merge-Transformation."""

    def test_merge_two_artifacts(self, engine, service):
        """Zwei Artifacts mergen."""
        a1 = service.create_artifact(
            type=ArtifactType.IDEA,
            title="Erste Idee",
            content="Inhalt 1",
            tags=["tag1"],
        )
        a2 = service.create_artifact(
            type=ArtifactType.IDEA,
            title="Zweite Idee",
            content="Inhalt 2",
            tags=["tag2"],
        )

        result = engine.transform(
            a1.id,
            "merge_artifacts",
            related_ids=[a2.id],
        )

        assert result.success
        assert result.primary is not None
        assert result.primary.type == ArtifactType.IDEA
        assert "Erste Idee" in result.primary.title
        assert "Zweite Idee" in result.primary.title

    def test_merge_combines_content(self, engine, service):
        """Merge kombiniert Inhalte."""
        a1 = service.create_artifact(
            type=ArtifactType.IDEA,
            title="Idea 1",
            content="Content A",
        )
        a2 = service.create_artifact(
            type=ArtifactType.IDEA,
            title="Idea 2",
            content="Content B",
        )

        result = engine.transform(
            a1.id,
            "merge_artifacts",
            related_ids=[a2.id],
        )

        assert "Content A" in result.primary.content
        assert "Content B" in result.primary.content

    def test_merge_combines_tags(self, engine, service):
        """Merge kombiniert Tags (dedupliziert)."""
        a1 = service.create_artifact(
            type=ArtifactType.IDEA,
            title="Idea 1",
            content="Content",
            tags=["ai", "test"],
        )
        a2 = service.create_artifact(
            type=ArtifactType.IDEA,
            title="Idea 2",
            content="Content",
            tags=["ai", "automation"],
        )

        result = engine.transform(
            a1.id,
            "merge_artifacts",
            related_ids=[a2.id],
        )

        merged_tags = set(result.primary.tags)
        assert "ai" in merged_tags
        assert "test" in merged_tags
        assert "automation" in merged_tags

    def test_merge_requires_at_least_two(self, engine, service):
        """Merge mit nur einem Artifact schlägt fehl."""
        a1 = service.create_artifact(
            type=ArtifactType.IDEA,
            title="Single",
            content="Allein",
        )

        with pytest.raises(PreconditionError, match="mindestens 2"):
            engine.transform(a1.id, "merge_artifacts")

    def test_merge_different_types_raises(self, engine, service):
        """Merge unterschiedlicher Typen schlägt fehl."""
        a1 = service.create_artifact(
            type=ArtifactType.IDEA,
            title="Idea",
            content="Idea Content",
        )
        a2 = service.create_artifact(
            type=ArtifactType.TASK,
            title="Task",
            content="Task Content",
        )

        with pytest.raises(PreconditionError, match="Typ"):
            engine.transform(
                a1.id,
                "merge_artifacts",
                related_ids=[a2.id],
            )

    def test_merge_archived_raises(self, engine, service):
        """Merge mit ARCHIVED Artifact schlägt fehl."""
        a1 = service.create_artifact(
            type=ArtifactType.IDEA,
            title="Idea 1",
            content="Content",
        )
        a2 = service.create_artifact(
            type=ArtifactType.IDEA,
            title="Idea 2",
            content="Content",
        )
        service.update_artifact_fields(
            a2.id,
            status=ArtifactStatus.ARCHIVED,
        )

        with pytest.raises(PreconditionError, match="ARCHIVED"):
            engine.transform(
                a1.id,
                "merge_artifacts",
                related_ids=[a2.id],
            )


# =============================================================================
# Tests: ArtifactTransformationEngine
# =============================================================================


class TestArtifactTransformationEngine:
    """Tests für die Engine-Orchestrierung."""

    def test_unknown_transformer_raises(self, engine, sample_idea):
        """Unbekannter Transformer wirft Fehler."""
        with pytest.raises(TransformationError, match="Kein Transformer"):
            engine.transform(sample_idea.id, "nonexistent")

    def test_nonexistent_artifact_raises(self, engine):
        """Nicht-existierendes Artifact wirft Fehler."""
        with pytest.raises(TransformationError, match="nicht gefunden"):
            engine.transform("nonexistent", "idea_to_spec")

    def test_list_transformations(self, engine):
        """Verfügbare Transformationen listen."""
        transformations = engine.list_transformations()
        assert "idea_to_spec" in transformations
        assert "spec_to_task_graph" in transformations
        assert "merge_artifacts" in transformations

    def test_can_transform_valid(self, engine, sample_idea):
        """can_transform erkennt gültige Transformation."""
        assert engine.can_transform(sample_idea, "idea_to_spec")

    def test_can_transform_invalid(self, engine, service):
        """can_transform erkennt ungültige Transformation."""
        task = service.create_artifact(
            type=ArtifactType.TASK,
            title="Task",
            content="Content",
        )
        assert not engine.can_transform(task, "idea_to_spec")

    def test_can_transform_unknown(self, engine, sample_idea):
        """can_transform mit unbekanntem Namen gibt False."""
        assert not engine.can_transform(sample_idea, "nonexistent")

    def test_custom_transformer(self, engine, service):
        """Benutzerdefinierten Transformer registrieren und nutzen."""
        class UppercaseTitleTransformer(Transformer):
            @property
            def transformation_type(self):
                return TransformationType.PROMOTE_DECISION

            def transform(self, ctx, service):
                updated = service.update_artifact_fields(
                    ctx.source.id,
                    title=ctx.source.title.upper(),
                )
                return TransformationResult(
                    primary=updated,
                    transformation_type=self.transformation_type.value,
                    source_id=ctx.source.id,
                    success=True,
                    message=f"Title uppercased",
                    affected_ids=[ctx.source.id],
                )

        engine.register(UppercaseTitleTransformer())

        idea = service.create_artifact(
            type=ArtifactType.IDEA,
            title="test idea",
            content="content",
        )

        result = engine.transform(idea.id, "promote_decision")
        assert result.success
        assert result.primary.title == "TEST IDEA"

    def test_full_idea_to_task_pipeline(self, engine, sample_idea):
        """Vollständige Pipeline: IDEA → SPEC → Tasks."""
        # Schritt 1: IDEA → SPEC
        spec_result = engine.transform(sample_idea.id, "idea_to_spec")
        assert spec_result.success
        spec = spec_result.primary

        # Schritt 2: SPEC → Tasks
        task_result = engine.transform(
            spec.id,
            "spec_to_task_graph",
            task_descriptions=[
                "Anforderungsanalyse",
                "Design erstellen",
                "Implementierung",
                "Tests",
                "Dokumentation",
            ],
        )
        assert task_result.success
        assert len(task_result.secondary) == 5

        # Prüfe: Alle Tasks sind Children des SPEC
        for task in task_result.secondary:
            assert task.parent_id == spec.id

    def test_engine_uses_service_layer(self, engine, sample_idea):
        """Engine verwendet ausschließlich Service-Layer (kein direkter Store)."""
        result = engine.transform(sample_idea.id, "idea_to_spec")

        # Prüfe: Event Log wurde geschrieben
        events = engine.service.event_log.get_artifact_timeline(sample_idea.id)
        assert len(events) >= 1  # Mindestens creation + status_change


# =============================================================================
# Tests: Edge Cases
# =============================================================================


class TestTransformationEdgeCases:
    """Tests für Grenzfälle."""

    def test_idea_already_done(self, engine, service):
        """Bereits DONE IDEA kann trotzdem transformiert werden."""
        idea = service.create_artifact(
            type=ArtifactType.IDEA,
            title="Fertige Idee",
            content="Content",
            status=ArtifactStatus.DONE,
        )

        result = engine.transform(idea.id, "idea_to_spec")
        assert result.success
        assert result.primary.type == ArtifactType.SPEC

    def test_spec_already_active(self, engine, service):
        """Bereits ACTIVE SPEC kann trotzdem transformiert werden."""
        idea = service.create_artifact(
            type=ArtifactType.IDEA,
            title="Idea",
            content="Content",
        )
        # IDEA direkt auf DONE setzen, SPEC direkt erstellen
        service.update_artifact_fields(idea.id, status=ArtifactStatus.DONE)
        spec = service.create_artifact(
            type=ArtifactType.SPEC,
            title=f"Spec: {idea.title}",
            content=idea.content,
        )
        service.update_artifact_fields(spec.id, status=ArtifactStatus.ACTIVE)

        result = engine.transform(
            spec.id,
            "spec_to_task_graph",
            task_descriptions=["Task 1"],
        )
        assert result.success
        assert len(result.secondary) == 1

    def test_merge_with_three_artifacts(self, engine, service):
        """Merge von 3 Artifacts."""
        arts = []
        for i in range(3):
            art = service.create_artifact(
                type=ArtifactType.IDEA,
                title=f"Idea {i}",
                content=f"Content {i}",
            )
            arts.append(art)

        result = engine.transform(
            arts[0].id,
            "merge_artifacts",
            related_ids=[arts[1].id, arts[2].id],
        )
        assert result.success
        assert "Idea 0" in result.primary.title
        assert "Idea 1" in result.primary.title
        assert "Idea 2" in result.primary.title

    def test_transformation_error_message(self, engine):
        """TransformationError enthält aussagekräftige Nachricht."""
        with pytest.raises(TransformationError) as exc_info:
            engine.transform("nonexistent", "idea_to_spec")

        assert "nicht gefunden" in str(exc_info.value)
        assert exc_info.value.transformation_type == "idea_to_spec"
        assert exc_info.value.source_id == "nonexistent"
