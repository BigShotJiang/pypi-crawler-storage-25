#!/usr/bin/env python3
"""
Direct test of vLLM service to see if it's returning actual content.
"""

import asyncio
import aiohttp
import json
import sys

async def test_vllm_direct():
    """Test vLLM service directly."""
    print("🧪 Testing vLLM service directly...")
    
    vllm_url = "http://localhost:8001"
    
    # Test 1: Check health
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{vllm_url}/health", timeout=2) as response:
                if response.status == 200:
                    print("✅ vLLM health check passed")
                else:
                    print(f"⚠️ vLLM health check returned status {response.status}")
    except Exception as e:
        print(f"❌ vLLM health check failed: {e}")
        return False
    
    # Test 2: Check models
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{vllm_url}/models", timeout=2) as response:
                if response.status == 200:
                    models_data = await response.json()
                    print(f"✅ vLLM models: {models_data}")
                else:
                    print(f"⚠️ vLLM models endpoint returned status {response.status}")
    except Exception as e:
        print(f"❌ vLLM models check failed: {e}")
        return False
    
    # Test 3: Send a direct chat completion request
    print("\n🧪 Testing vLLM chat completion...")
    
    payload = {
        "model": "Qwen/Qwen2.5-1.5B-Instruct",
        "messages": [
            {"role": "system", "content": "You are a helpful AI assistant."},
            {"role": "user", "content": "Hello, can you help me?"}
        ],
        "stream": False,
        "max_tokens": 100
    }
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(f"{vllm_url}/v1/chat/completions", 
                                   json=payload, 
                                   timeout=10) as response:
                if response.status == 200:
                    result = await response.json()
                    print(f"✅ vLLM chat completion successful")
                    
                    # Check if we got actual content
                    if "choices" in result and len(result["choices"]) > 0:
                        choice = result["choices"][0]
                        if "message" in choice and "content" in choice["message"]:
                            content = choice["message"]["content"]
                            print(f"📝 Response content: {content[:200]}...")
                            if content.strip():
                                print("✅ vLLM is returning actual content")
                                return True
                            else:
                                print("⚠️ vLLM returned empty content")
                                return False
                        else:
                            print(f"⚠️ Unexpected response format: {result}")
                            return False
                    else:
                        print(f"⚠️ No choices in response: {result}")
                        return False
                else:
                    print(f"❌ vLLM chat completion failed with status {response.status}")
                    error_text = await response.text()
                    print(f"   Error: {error_text[:200]}")
                    return False
    except Exception as e:
        print(f"❌ vLLM chat completion failed: {e}")
        return False

async def test_backend_client_integration():
    """Test BackendClient integration with vLLM."""
    print("\n🧪 Testing BackendClient integration...")
    
    # Import after checking vLLM is working
    sys.path.insert(0, ".")
    
    from core.routing.backend_client import BackendClient
    from unittest.mock import Mock
    
    # Create a mock llm_engine that calls vLLM directly
    mock_llm_engine = Mock()
    
    async def mock_call_vllm(model, messages, tools=None, options=None, timeout=None):
        # Simulate what vLLM should return
        yield {"choices": [{"delta": {"content": "Hello! I'm here to help."}}]}
        yield {"choices": [{"delta": {"content": " How can I assist you today?"}}]}
    
    mock_llm_engine.call_vllm = mock_call_vllm
    
    # Create BackendClient
    client = BackendClient(llm_engine=mock_llm_engine)
    
    # Create a mock selection
    mock_selection = Mock()
    mock_selection.backend_id = "expert_gpu"
    mock_selection.backend_type = Mock()
    mock_selection.backend_type.value = "vllm"
    mock_selection.model = "Qwen/Qwen2.5-1.5B-Instruct"
    
    # Test the call
    messages = [
        {"role": "system", "content": "You are a helpful AI assistant."},
        {"role": "user", "content": "Hello, can you help me?"}
    ]
    
    print("   Testing BackendClient.call()...")
    chunks = []
    async for chunk in client.call(mock_selection, messages, "test_trace"):
        chunks.append(chunk)
        print(f"   Received chunk: {chunk}")
    
    if chunks:
        print(f"✅ BackendClient received {len(chunks)} chunks")
        
        # Check if chunks have content
        content_chunks = [c for c in chunks if c.get("content")]
        if content_chunks:
            print(f"✅ {len(content_chunks)} chunks have actual content")
            return True
        else:
            print("⚠️ Chunks don't have content field")
            return False
    else:
        print("❌ No chunks received from BackendClient")
        return False

async def main():
    """Run all tests."""
    print("🚀 Testing vLLM Integration & Empty Response Prevention")
    print("=" * 60)
    
    # Test 1: Direct vLLM service
    test1_passed = await test_vllm_direct()
    
    # Test 2: BackendClient integration
    test2_passed = await test_backend_client_integration()
    
    print("\n" + "=" * 60)
    print("📋 TEST SUMMARY")
    print(f"  Test 1 (Direct vLLM): {'✅ PASS' if test1_passed else '❌ FAIL'}")
    print(f"  Test 2 (BackendClient): {'✅ PASS' if test2_passed else '❌ FAIL'}")
    
    if test1_passed and test2_passed:
        print("\n🎉 vLLM integration is working correctly!")
        print("   If you're still seeing '[Routing to expert_gpu...]' repeated,")
        print("   check the orchestrator's response handling logic.")
        return True
    else:
        print("\n⚠️ Some tests failed. Check the logs above.")
        return False

if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)