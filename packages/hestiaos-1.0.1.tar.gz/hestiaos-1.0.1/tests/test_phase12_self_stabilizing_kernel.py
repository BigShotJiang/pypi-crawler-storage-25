#!/usr/bin/env python3
"""
Phase 12 — Self-Stabilizing Kernel: 16 Tests.

Test-Aufteilung:
  P0-1: SnapshotManager (4 Tests)
  P0-2: Identity Migration (4 Tests)
  P1-3: Trust Dampening (4 Tests)
  P1-4: System Health + Circuit Breaker (4 Tests)
"""

import json
import os
import time
import tempfile
import pytest
from typing import Dict, Any

from core.skills.snapshot_manager import SnapshotManager, create_snapshot_manager
from core.skills.identity_migration import (
    VersionedIdentity,
    MigrationRecord,
    MigrationTable,
    compute_confidence_inertia_alpha,
    apply_confidence_inertia,
    compute_versioned_id,
    parse_qualified_id,
    bump_version_tag,
)
from core.skills.trust_dampening import (
    TrustDampeningConfig,
    HysteresisController,
    OscillationDetector,
    TrustDirection,
)
from core.skills.system_health import (
    HealthDimensions,
    compute_shf_score,
    CircuitBreaker,
    CircuitBreakerState,
    SystemHealthMonitor,
)


# ═══════════════════════════════════════════════════════════════
# P0-1: SnapshotManager (4 Tests)
# ═══════════════════════════════════════════════════════════════


class TestSnapshotManager:
    """4 Tests für SnapshotManager + Single-File Commit."""

    def test_take_and_recover_snapshot(self, tmp_path):
        """Test 1: Snapshot erstellen und wiederherstellen."""
        sm = SnapshotManager(snapshot_dir=str(tmp_path), snapshot_interval=1, max_snapshots=5)
        skills_data = {"skill_1": {"name": "test", "confidence": 0.8}}
        failures_data = {"pattern_1": {"cause": "timeout"}}

        path = sm.take_snapshot(skills_data, failures_data, metadata={"version": "1.0"})
        assert os.path.exists(path)

        recovered = sm.recover_latest()
        assert recovered is not None
        assert recovered["skills"] == skills_data
        assert recovered["failures"] == failures_data
        assert recovered["metadata"]["version"] == "1.0"

    def test_snapshot_interval_trigger(self, tmp_path):
        """Test 2: Snapshot wird nur alle N Commits ausgelöst."""
        sm = SnapshotManager(snapshot_dir=str(tmp_path), snapshot_interval=3, max_snapshots=5)

        assert sm.should_snapshot() is False
        sm.increment_commits()  # 1
        assert sm.should_snapshot() is False
        sm.increment_commits()  # 2
        assert sm.should_snapshot() is False
        sm.increment_commits()  # 3
        assert sm.should_snapshot() is True

        sm.reset_commit_counter()
        assert sm.should_snapshot() is False

    def test_max_snapshots_pruning(self, tmp_path):
        """Test 3: Maximal 5 Snapshots, alte werden gelöscht."""
        sm = SnapshotManager(snapshot_dir=str(tmp_path), snapshot_interval=1, max_snapshots=3)

        for i in range(5):
            sm.take_snapshot(
                {"i": i}, {},
                metadata={"iteration": i},
            )
            time.sleep(0.01)  # Sicherstellen, dass Timestamps unterschiedlich sind

        snapshots = sm.list_snapshots()
        assert len(snapshots) <= 3

    def test_single_file_atomic_commit(self, tmp_path):
        """Test 4: Single-File Commit erzeugt valides JSON mit skills + failures."""
        sm = SnapshotManager(snapshot_dir=str(tmp_path), snapshot_interval=1, max_snapshots=5)
        skills = {"a": {"value": 1}}
        failures = {"b": {"value": 2}}

        path = sm.take_snapshot(skills, failures)

        with open(path, "r") as f:
            data = json.load(f)

        assert data["type"] == "skill_store_snapshot"
        assert data["version"] == 1
        assert data["skills"] == skills
        assert data["failures"] == failures
        assert "timestamp" in data


# ═══════════════════════════════════════════════════════════════
# P0-2: Identity Migration (4 Tests)
# ═══════════════════════════════════════════════════════════════


class TestIdentityMigration:
    """4 Tests für Identity Versioning + Migration Table + Confidence Inertia."""

    def test_versioned_identity_qualified_id(self):
        """Test 5: VersionedIdentity erzeugt korrekte qualified_id."""
        vid = VersionedIdentity(canonical_id="abc123", version_tag=1)
        assert vid.qualified_id == "abc123::v1"

        vid2 = VersionedIdentity(canonical_id="abc123", version_tag=2)
        assert vid2.qualified_id == "abc123::v2"

    def test_migration_table_record_and_history(self, tmp_path):
        """Test 6: Migration Table zeichnet Migrationen auf und gibt History zurück."""
        table_path = os.path.join(str(tmp_path), "migrations.json")
        mt = MigrationTable(path=table_path)

        mt.record_migration(MigrationRecord(
            from_id="abc::v1",
            to_id="abc::v2",
            reason="skill_evolution",
            confidence_before=0.3,
            confidence_after=0.6,
            alpha=0.5,
        ))

        history = mt.get_history("abc::v2")
        assert len(history) == 1
        assert history[0].from_id == "abc::v1"
        assert history[0].to_id == "abc::v2"
        assert history[0].alpha == 0.5

    def test_confidence_inertia_alpha_same_intent(self):
        """Test 7: Gleicher Intent + gleiche Tools → α nahe 1.0."""
        old = {"intent_signature": "create_file", "tool_sequence": ["bash", "bash"]}
        new = {"intent_signature": "create_file", "tool_sequence": ["bash", "bash"]}
        alpha = compute_confidence_inertia_alpha(old, new)
        assert alpha == 1.0  # semantic=1.0, structural=1.0 → (1.0*0.5 + 1.0*0.5) = 1.0

    def test_confidence_inertia_alpha_different_tools(self):
        """Test 8: Gleicher Intent, andere Tools → α < 1.0."""
        old = {"intent_signature": "create_file", "tool_sequence": ["bash", "kubectl"]}
        new = {"intent_signature": "create_file", "tool_sequence": ["bash", "docker"]}
        alpha = compute_confidence_inertia_alpha(old, new)
        # semantic=1.0, structural=1/3 ≈ 0.333 → (1.0*0.5 + 0.333*0.5) = 0.666
        assert 0.6 < alpha < 0.7

        # Confidence Inertia anwenden
        new_confidence = apply_confidence_inertia(
            old_confidence=0.8,
            new_baseline=0.5,
            alpha=alpha,
        )
        expected = alpha * 0.8 + (1 - alpha) * 0.5
        assert abs(new_confidence - expected) < 0.001


# ═══════════════════════════════════════════════════════════════
# P1-3: Trust Dampening (4 Tests)
# ═══════════════════════════════════════════════════════════════


class TestTrustDampening:
    """4 Tests für Hysteresis + Oscillation Detector."""

    def test_hysteresis_should_degrade_immediately(self):
        """Test 9: 1 katastrophaler Fehler → sofortige Degradation."""
        controller = HysteresisController(TrustDampeningConfig(hysteresis_down=1))
        assert controller.should_degrade("skill_1", catastrophic_failures=1) is True
        assert controller.should_degrade("skill_1", catastrophic_failures=0) is False

    def test_hysteresis_should_recover_after_threshold(self):
        """Test 10: Recovery erst nach N Erfolgen + Observation Window + Cooldown."""
        controller = HysteresisController(TrustDampeningConfig(
            hysteresis_up=3,
            observation_window=3,
            cooldown_hours=0,  # Kein Cooldown für Test
        ))

        # Noch nicht genug Executions
        assert controller.should_recover("skill_1") is False

        # Genug Executions + Erfolge
        controller.record_execution("skill_1", success=True)
        controller.record_execution("skill_1", success=True)
        controller.record_execution("skill_1", success=True)

        assert controller.should_recover("skill_1") is True

    def test_oscillation_detector_count(self):
        """Test 11: Oszillations-Detektor erkennt up→down→up Muster.

        count_oscillations verwendet Sliding Window über 3 Events:
        UP→DOWN→UP→DOWN→UP ergibt 3 Zyklen (i=0: UP→DOWN→UP, i=1: DOWN→UP→DOWN, i=2: UP→DOWN→UP).
        """
        detector = OscillationDetector(max_oscillations=2)

        detector.record_change("s1", TrustDirection.UP, "guided", "autonomous")
        detector.record_change("s1", TrustDirection.DOWN, "autonomous", "guided")
        detector.record_change("s1", TrustDirection.UP, "guided", "autonomous")

        assert detector.count_oscillations("s1") == 1

        # Zweiten Zyklus → insgesamt 3 Sliding-Window-Matches
        detector.record_change("s1", TrustDirection.DOWN, "autonomous", "guided")
        detector.record_change("s1", TrustDirection.UP, "guided", "autonomous")

        assert detector.count_oscillations("s1") == 3
        assert detector.is_oscillating("s1") is True

    def test_cooldown_remaining(self):
        """Test 12: Cooldown wird nach Trust-Änderung aktiviert."""
        controller = HysteresisController(TrustDampeningConfig(
            hysteresis_up=1,
            observation_window=1,
            cooldown_hours=24,
        ))

        controller.record_execution("s1", success=True)
        controller.record_trust_change("s1", TrustDirection.UP)

        remaining = controller.get_cooldown_remaining("s1")
        assert remaining > 0  # Cooldown aktiv

        # Cooldown mit 0h → sofort abgelaufen
        controller2 = HysteresisController(TrustDampeningConfig(
            hysteresis_up=1,
            observation_window=1,
            cooldown_hours=0,
        ))
        controller2.record_execution("s2", success=True)
        controller2.record_trust_change("s2", TrustDirection.UP)
        assert controller2.get_cooldown_remaining("s2") == 0.0


# ═══════════════════════════════════════════════════════════════
# P1-4: System Health + Circuit Breaker (4 Tests)
# ═══════════════════════════════════════════════════════════════


class TestSystemHealth:
    """4 Tests für SHF + Circuit Breaker."""

    def test_shf_score_zero_for_healthy(self):
        """Test 13: SHF = 0 bei gesundem System."""
        dims = HealthDimensions(drift=0.0, instability=0.0, fragmentation=0.0)
        score = compute_shf_score(dims)
        assert score == 0.0

    def test_shf_score_one_for_critical(self):
        """Test 14: SHF = 1 bei maximaler Belastung."""
        dims = HealthDimensions(drift=1.0, instability=1.0, fragmentation=1.0)
        score = compute_shf_score(dims)
        assert score == 1.0

    def test_circuit_breaker_green_yellow_red(self):
        """Test 15: Circuit Breaker durchläuft GREEN → YELLOW → RED."""
        cb = CircuitBreaker(required_recovery=2)

        # GREEN: SHF < 0.3
        assert cb.state == CircuitBreakerState.GREEN
        cb.update(0.2)
        assert cb.state == CircuitBreakerState.GREEN

        # YELLOW: SHF >= 0.3
        cb.update(0.5)
        assert cb.state == CircuitBreakerState.YELLOW
        assert cb.is_restricted() is True
        assert cb.is_blocked() is False

        # RED: SHF >= 0.7
        cb.update(0.8)
        assert cb.state == CircuitBreakerState.RED
        assert cb.is_blocked() is True

    def test_circuit_breaker_recovery_red_to_green(self):
        """Test 16: Circuit Breaker erholt sich von RED → YELLOW → GREEN."""
        cb = CircuitBreaker(required_recovery=2)

        # In RED treiben
        cb.update(0.8)
        assert cb.state == CircuitBreakerState.RED

        # Recovery: SHF < 0.3 für N Checks
        cb.update(0.2)  # recovery_counter = 1
        assert cb.state == CircuitBreakerState.RED  # Noch nicht genug

        cb.update(0.2)  # recovery_counter = 2
        assert cb.state == CircuitBreakerState.YELLOW  # RED → YELLOW

        cb.update(0.2)  # recovery_counter = 1 (YELLOW)
        assert cb.state == CircuitBreakerState.YELLOW

        cb.update(0.2)  # recovery_counter = 2
        assert cb.state == CircuitBreakerState.GREEN  # YELLOW → GREEN
        assert cb.is_blocked() is False
        assert cb.is_restricted() is False
