import subprocess
import json
import os
import time
from pathlib import Path
from core.cli.ticketing import TicketStatus

CLI_EXEC = ["python3", "-m", "core.cli.main"]
AUDIT_FILE = "logs/audit.json"
TICKETS_FILE = "logs/tickets.json"

def run_cli(args):
    """Run CLI command and return parsed JSON result"""
    cmd = CLI_EXEC + args
    res = subprocess.run(cmd, capture_output=True, text=True, env={**os.environ, "PYTHONPATH": "."})
    if res.returncode != 0:
        print(f"   ⚠️ CLI Error [rc={res.returncode}]: {res.stderr}")
    return res.stdout.strip(), res.returncode

def test_audit_trail():
    print("🧪 Testing Audit Trail...")
    # Trigger a command
    run_cli(["monitor"])
    
    # Check audit log
    if os.path.exists(AUDIT_FILE):
        with open(AUDIT_FILE, "r") as f:
            lines = f.readlines()
            last_entry = json.loads(lines[-1].strip())
            assert "event_type" in last_entry
            assert last_entry["payload"]["command"] == "monitor"
        print("✅ Pass: CLI actions are audited.")
    else:
        print("❌ Fail: audit.json not found.")

def test_state_machine_enforcement():
    print("🧪 Testing State Machine Enforcement...")
    # 1. Get a ticket
    stdout, rc = run_cli(["tickets", "list"])
    if not stdout:
        print("   ⚠️ Empty ticket list, triggering doctor to create one...")
        run_cli(["doctor", "--fix"])
        stdout, rc = run_cli(["tickets", "list"])
    
    try:
        data = json.loads(stdout)
        tickets = data["data"] # v2 returns tickets array directly under data
        if not tickets:
            print("   ⚠️ No tickets found after doctor --fix.")
            return

        ticket_id = tickets[0]["id"]
        current_status = tickets[0]["status"]
        
        # 2. Try illegal transition
        if current_status == "NEW":
            print(f"   > Attempting illegal transition: NEW -> CLOSED")
            stdout, rc = run_cli(["tickets", "close", ticket_id])
            res = json.loads(stdout)
            assert res["status"] == "error"
            assert res["error"]["code"] == "INVALID_STATE_TRANSITION"
            print("✅ Pass: Illegal transition blocked.")
    except Exception as e:
        print(f"❌ Fail: {e}")
        print(f"Raw Output: {stdout}")

def test_schema_v2_migration():
    print("🧪 Testing Schema v2 Migration...")
    if os.path.exists(TICKETS_FILE):
        with open(TICKETS_FILE, "r") as f:
            data = json.load(f)
            assert data["schema_version"] == 2
            assert isinstance(data["tickets"], list)
        print("✅ Pass: Ticket store is using v2 schema.")

if __name__ == "__main__":
    print("🚀 Starting HestiaOS CLI V8 Validation\n")
    test_audit_trail()
    test_state_machine_enforcement()
    test_schema_v2_migration()
    print("\n🏁 Build v8 Validation Complete.")
