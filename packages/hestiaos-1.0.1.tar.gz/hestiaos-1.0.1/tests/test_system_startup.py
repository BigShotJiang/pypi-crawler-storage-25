#!/usr/bin/env python3
"""
HestiaOS End-to-End System Startup Test Suite.
Verifies all components are available and healthy after startup.
"""
import httpx
import pytest
import time
import asyncio

BACKEND_URL = "http://localhost:8000"
GATEWAY_URL = "http://localhost:8090"
EGL_DASHBOARD_URL = f"{BACKEND_URL}/egl/dashboard"

@pytest.mark.asyncio
async def test_backend_health():
    """Verify backend health endpoint."""
    async with httpx.AsyncClient() as client:
        try:
            response = await client.get(f"{BACKEND_URL}/health", timeout=5.0)
            assert response.status_code == 200
            assert "ok" in response.text.lower()
        except Exception as e:
            pytest.fail(f"Backend health check failed: {e}")

@pytest.mark.asyncio
async def test_egl_dashboard_accessibility():
    """Verify EGL Dashboard is accessible."""
    # Use follow_redirects=True to handle potential trailing slash redirects (307)
    async with httpx.AsyncClient(follow_redirects=True) as client:
        try:
            response = await client.get(EGL_DASHBOARD_URL, timeout=5.0)
            assert response.status_code == 200
            assert "EGL Compliance Dashboard" in response.text
        except Exception as e:
            pytest.fail(f"EGL Dashboard accessibility failed: {e}")

@pytest.mark.asyncio
async def test_egl_compliance_metrics():
    """Verify EGL compliance metrics API."""
    async with httpx.AsyncClient() as client:
        try:
            response = await client.get(f"{BACKEND_URL}/egl/dashboard/compliance", timeout=5.0)
            assert response.status_code == 200
            data = response.json()
            assert "overall" in data
            assert "components" in data
            assert 0 <= data["overall"] <= 100
        except Exception as e:
            pytest.fail(f"EGL compliance metrics failed: {e}")

@pytest.mark.asyncio
async def test_mcp_gateway_health():
    """Verify MCP Gateway health endpoint."""
    async with httpx.AsyncClient() as client:
        try:
            # Note: MCP SSE gateway health endpoint check
            response = await client.get(f"{GATEWAY_URL}/health", timeout=5.0)
            assert response.status_code == 200
            # Accept both 'healthy' and 'ok' status
            status = response.json().get("status")
            assert status in ["healthy", "ok"]
        except Exception as e:
            pytest.fail(f"MCP Gateway health check failed: {e}")

if __name__ == "__main__":
    # For manual running
    import sys
    import os
    
    print("=== HestiaOS E2E Startup Verification ===")
    print(f"🔍 Testing Backend: {BACKEND_URL}")
    print(f"🔍 Testing Gateway: {GATEWAY_URL}")
    
    # We use pytest to run the suite if called directly
    os.system(f"pytest {__file__}")
