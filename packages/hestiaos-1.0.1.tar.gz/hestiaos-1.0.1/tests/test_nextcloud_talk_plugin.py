import sys
import os
import unittest
from unittest.mock import MagicMock, patch, AsyncMock
import asyncio

# Setup path
sys.path.append(os.getcwd())

from plugins.nextcloud_talk import NextcloudTalkPlugin

class TestNextcloudTalkPlugin(unittest.TestCase):
    def setUp(self):
        self.plugin = NextcloudTalkPlugin()
        self.plugin.server_url = "https://cloud.example.com"
        self.plugin.username = "bot"
        self.plugin.password = "pass"
        self.plugin.rooms = {
            "token1": {"alias": "general", "allow_tools": True, "last_id": 0},
            "token2": {"alias": "alerts", "allow_tools": False, "last_id": 0}
        }

    def test_get_tools(self):
        tools = self.plugin.get_tools()
        self.assertEqual(len(tools), 2)
        tool_names = [t["function"]["name"] for t in tools]
        self.assertIn("send_talk_message", tool_names)
        self.assertIn("list_talk_rooms", tool_names)

    @patch("httpx.AsyncClient.post")
    async def test_send_message_by_alias(self, mock_post):
        mock_post.return_value = MagicMock(status_code=201)
        success = await self.plugin._send_message("general", "Hello")
        self.assertTrue(success)
        # Check if it resolved 'general' to 'token1'
        args, kwargs = mock_post.call_args
        self.assertIn("token1", args[0])

    async def test_execute_list_rooms(self):
        result = await self.plugin.execute("list_talk_rooms", {}, {})
        self.assertTrue(result["success"])
        self.assertEqual(len(result["rooms"]), 2)
        self.assertEqual(result["rooms"][0]["alias"], "general")

def run_tests():
    # Helper to run async tests in unittest
    suite = unittest.TestLoader().loadTestsFromTestCase(TestNextcloudTalkPlugin)
    
    # Simple runner for async methods
    async def run_async_test(test_method):
        await test_method
        
    loop = asyncio.get_event_loop()
    
    # We'll just run them manually for simplicity in this script
    test = TestNextcloudTalkPlugin()
    test.setUp()
    
    print("Testing get_tools...")
    test.test_get_tools()
    
    print("Testing send_message_by_alias...")
    loop.run_until_complete(test.test_send_message_by_alias())
    
    print("Testing execute_list_rooms...")
    loop.run_until_complete(test.test_execute_list_rooms())
    
    print("ALL TESTS PASSED")
    with open("tests/test_result.txt", "w") as f:
        f.write("PASSED")

if __name__ == "__main__":
    run_tests()
