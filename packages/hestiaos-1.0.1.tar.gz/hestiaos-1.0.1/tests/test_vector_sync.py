"""
Tests for Cross-Node Vector Sync
"""

import pytest
import asyncio
from unittest.mock import MagicMock, AsyncMock

from core.vector_sync import VectorSyncManager
from core.agent_communication import AgentMessage, MessageType, Priority, AgentRole

class TestVectorSync:
    
    @pytest.mark.asyncio
    async def test_broadcast_memory(self):
        """Test that broadcasting a memory calls the communication client's broadcast method."""
        comm_client = MagicMock()
        comm_client.broadcast = AsyncMock()
        
        vsm = VectorSyncManager(agent_id="agent_a", comm_client=comm_client)
        
        await vsm.broadcast_memory(content="Synchronized knowledge")
        
        assert comm_client.broadcast.called
        args, kwargs = comm_client.broadcast.call_args
        assert kwargs["message_type"] == MessageType.NOTIFICATION
        assert kwargs["payload"]["content"] == "Synchronized knowledge"
        assert kwargs["payload"]["origin_agent"] == "agent_a"
        assert "sync_id" in kwargs["payload"]

    @pytest.mark.asyncio
    async def test_handle_incoming_sync(self):
        """Test that incoming sync messages are stored in the memory plugin."""
        comm_client = MagicMock()
        vsm = VectorSyncManager(agent_id="agent_b", comm_client=comm_client)
        
        # Mock memory plugin
        memory_plugin = MagicMock()
        memory_plugin.store_memory = AsyncMock()
        vsm.memory_plugin = memory_plugin
        
        # Create a sync message
        sync_payload = {
            "message_type": "vector_sync",
            "sync_id": "sync_123",
            "origin_agent": "agent_a",
            "content": "Peer knowledge",
            "metadata": {"test": True}
        }
        message = AgentMessage(
            sender_id="agent_a",
            sender_role=AgentRole.ORCHESTRATOR,
            message_type=MessageType.NOTIFICATION,
            payload=sync_payload
        )
        
        await vsm.handle_incoming_sync(message)
        
        assert memory_plugin.store_memory.called
        args, kwargs = memory_plugin.store_memory.call_args
        assert args[0] == "Peer knowledge"
        
    @pytest.mark.asyncio
    async def test_echo_prevention(self):
        """Test that the manager doesn't process sync messages it sent or already processed."""
        comm_client = MagicMock()
        vsm = VectorSyncManager(agent_id="agent_a", comm_client=comm_client)
        
        memory_plugin = MagicMock()
        memory_plugin.store_memory = AsyncMock()
        vsm.memory_plugin = memory_plugin
        
        # 1. Message from self
        self_message = AgentMessage(
            sender_id="agent_a",
            sender_role=AgentRole.ORCHESTRATOR,
            message_type=MessageType.NOTIFICATION,
            payload={"message_type": "vector_sync", "sync_id": "s1", "origin_agent": "agent_a"}
        )
        await vsm.handle_incoming_sync(self_message)
        assert not memory_plugin.store_memory.called
        
        # 2. Duplicate message
        vsm.processed_sync_ids.add("s2")
        dup_message = AgentMessage(
            sender_id="agent_b",
            sender_role=AgentRole.ORCHESTRATOR,
            message_type=MessageType.NOTIFICATION,
            payload={"message_type": "vector_sync", "sync_id": "s2", "origin_agent": "agent_b"}
        )
        await vsm.handle_incoming_sync(dup_message)
        assert not memory_plugin.store_memory.called
