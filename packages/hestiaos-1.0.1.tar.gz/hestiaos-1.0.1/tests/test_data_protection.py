"""
Tests for the Data Protection System.
"""

import pytest
import json
from unittest.mock import Mock, patch, MagicMock

from core.data_protection import (
    DataProtectionManager,
    DataClassification,
    DataCategory,
    ProtectionRule,
    ProtectedData,
    get_data_protection_manager
)
from core.rbac_system import Permission


@pytest.fixture
def mock_rbac():
    """Mock RBAC manager."""
    with patch('core.data_protection.get_rbac_manager') as mock_get:
        mock_manager = Mock()
        mock_get.return_value = mock_manager
        yield mock_manager


@pytest.fixture
def mock_encryption():
    """Mock encryption manager."""
    with patch('core.data_protection.get_encryption_manager') as mock_get:
        mock_manager = Mock()
        mock_get.return_value = mock_manager
        yield mock_manager


@pytest.fixture
def mock_tenant():
    """Mock tenant manager."""
    with patch('core.data_protection.get_tenant_manager') as mock_get:
        mock_manager = Mock()
        mock_get.return_value = mock_manager
        yield mock_manager


@pytest.fixture
def data_protection_manager(mock_rbac, mock_encryption, mock_tenant):
    """Create data protection manager with mocked dependencies."""
    return DataProtectionManager()


class TestDataProtectionManager:
    """Test DataProtectionManager functionality."""
    
    def test_initialization(self, data_protection_manager):
        """Test that data protection manager initializes correctly."""
        assert data_protection_manager is not None
        assert len(data_protection_manager.rules) > 0
        
        # Check that default rules are loaded
        assert DataCategory.CREDENTIALS in data_protection_manager.rules
        assert DataCategory.API_KEYS in data_protection_manager.rules
        assert DataCategory.USER_PROFILE in data_protection_manager.rules
    
    def test_get_rule(self, data_protection_manager):
        """Test getting protection rule."""
        # Get existing rule
        rule = data_protection_manager.get_rule(DataCategory.CREDENTIALS)
        assert rule is not None
        assert rule.category == DataCategory.CREDENTIALS
        assert rule.classification == DataClassification.SECRET
        assert rule.encryption_required is True
        
        # Get rule by string
        rule_str = data_protection_manager.get_rule("credentials")
        assert rule_str is not None
        assert rule_str.category == DataCategory.CREDENTIALS
        
        # Get non-existent rule
        rule_none = data_protection_manager.get_rule("nonexistent")
        assert rule_none is None
    
    def test_protect_data_with_encryption(self, data_protection_manager, mock_encryption):
        """Test protecting data with encryption."""
        # Mock encryption
        mock_encryption.keys = {"aes_tenant_default": Mock()}
        mock_encryption.encrypt_aes.return_value = b"encrypted_data"
        
        # Protect sensitive data
        sensitive_data = {"password": "secret123"}
        protected = data_protection_manager.protect_data(
            data=sensitive_data,
            category=DataCategory.CREDENTIALS,
            tenant_id="default",
            session_id="test_session"
        )
        
        assert protected is not None
        assert protected.category == DataCategory.CREDENTIALS
        assert protected.classification == DataClassification.SECRET
        assert protected.tenant_id == "default"
        assert protected.encrypted is True
        assert protected.encrypted_data is not None
        assert protected.data is None  # Plaintext data should be removed
        
        # Verify encryption was called
        mock_encryption.encrypt_aes.assert_called_once()
    
    def test_protect_data_without_encryption(self, data_protection_manager):
        """Test protecting data without encryption."""
        # Protect non-sensitive data
        public_data = {"metric": "cpu_usage", "value": 75}
        protected = data_protection_manager.protect_data(
            data=public_data,
            category=DataCategory.METRICS,
            tenant_id="default"
        )
        
        assert protected is not None
        assert protected.category == DataCategory.METRICS
        assert protected.classification == DataClassification.PUBLIC
        assert protected.encrypted is False
        assert protected.data == public_data  # Plaintext data should be preserved
        assert protected.encrypted_data is None
    
    def test_access_data_with_authorization(self, data_protection_manager, mock_rbac, mock_tenant):
        """Test accessing protected data with proper authorization."""
        # Mock RBAC validation
        mock_user_context = Mock()
        mock_user_context.tenant_id = "default"
        mock_rbac.get_user_context.return_value = mock_user_context
        mock_rbac.validate_access.return_value = True
        
        # Mock tenant validation
        mock_tenant.validate_tenant_access.return_value = True
        
        # Create protected data (not encrypted for simplicity)
        protected = ProtectedData(
            data={"api_key": "test_key"},
            classification=DataClassification.SECRET,
            category=DataCategory.API_KEYS,
            tenant_id="default",
            encrypted=False
        )
        
        # Access the data
        result = data_protection_manager.access_data(
            protected=protected,
            session_id="authorized_session",
            required_permission=Permission.DECRYPT
        )
        
        assert result is not None
        assert result["api_key"] == "test_key"
        
        # Verify RBAC check was performed
        mock_rbac.validate_access.assert_called_once()
    
    def test_access_data_unauthorized(self, data_protection_manager, mock_rbac, mock_tenant):
        """Test accessing protected data without authorization."""
        # Mock RBAC to deny access
        mock_user_context = Mock()
        mock_user_context.tenant_id = "default"
        mock_rbac.get_user_context.return_value = mock_user_context
        mock_rbac.validate_access.return_value = False
        
        # Mock tenant validation
        mock_tenant.validate_tenant_access.return_value = True
        
        # Create protected data
        protected = ProtectedData(
            data={"api_key": "test_key"},
            classification=DataClassification.SECRET,
            category=DataCategory.API_KEYS,
            tenant_id="default",
            encrypted=False
        )
        
        # Try to access the data
        result = data_protection_manager.access_data(
            protected=protected,
            session_id="unauthorized_session",
            required_permission=Permission.DECRYPT
        )
        
        assert result is None  # Should be denied
        
        # Verify RBAC check was performed
        mock_rbac.validate_access.assert_called_once()
    
    def test_access_data_tenant_mismatch(self, data_protection_manager, mock_rbac, mock_tenant):
        """Test accessing data from different tenant."""
        # Mock RBAC
        mock_user_context = Mock()
        mock_user_context.tenant_id = "tenant_a"
        mock_rbac.get_user_context.return_value = mock_user_context
        
        # Mock tenant validation to deny cross-tenant access
        mock_tenant.validate_tenant_access.return_value = False
        
        # Create protected data for different tenant
        protected = ProtectedData(
            data={"data": "sensitive"},
            classification=DataClassification.CONFIDENTIAL,
            category=DataCategory.USER_PROFILE,
            tenant_id="tenant_b",  # Different tenant
            encrypted=False
        )
        
        # Try to access the data
        result = data_protection_manager.access_data(
            protected=protected,
            session_id="cross_tenant_session"
        )
        
        assert result is None  # Should be denied due to tenant mismatch
        
        # Verify tenant validation was called
        mock_tenant.validate_tenant_access.assert_called_once_with("tenant_a", "tenant_b")
    
    def test_access_encrypted_data(self, data_protection_manager, mock_rbac, mock_tenant, mock_encryption):
        """Test accessing encrypted data."""
        # Mock RBAC and tenant validation
        mock_user_context = Mock()
        mock_user_context.tenant_id = "default"
        mock_rbac.get_user_context.return_value = mock_user_context
        mock_rbac.validate_access.return_value = True
        mock_tenant.validate_tenant_access.return_value = True
        
        # Mock decryption
        decrypted_json = json.dumps({"data": {"password": "secret123"}}).encode()
        mock_encryption.decrypt_aes.return_value = decrypted_json
        
        # Create encrypted protected data
        protected = ProtectedData(
            data=None,
            classification=DataClassification.SECRET,
            category=DataCategory.CREDENTIALS,
            tenant_id="default",
            encrypted=True,
            encryption_key_id="aes_tenant_default",
            encrypted_data="encrypted_hex_data"
        )
        
        # Access the data
        result = data_protection_manager.access_data(
            protected=protected,
            session_id="authorized_session"
        )
        
        assert result is not None
        assert result["password"] == "secret123"
        
        # Verify decryption was called
        mock_encryption.decrypt_aes.assert_called_once()
    
    def test_add_and_remove_rule(self, data_protection_manager):
        """Test adding and removing protection rules."""
        # Create a custom rule
        custom_rule = ProtectionRule(
            category=DataCategory.CONVERSATION,
            classification=DataClassification.RESTRICTED,
            encryption_required=True,
            rbac_permission=Permission.READ,
            tenant_isolation=True,
            audit_logging=True,
            retention_days=365
        )
        
        # Add the rule
        data_protection_manager.add_rule(custom_rule)
        
        # Verify it was added
        retrieved_rule = data_protection_manager.get_rule(DataCategory.CONVERSATION)
        assert retrieved_rule is not None
        assert retrieved_rule.classification == DataClassification.RESTRICTED
        assert retrieved_rule.encryption_required is True
        
        # Remove the rule
        data_protection_manager.remove_rule(DataCategory.CONVERSATION)
        
        # Verify it was removed (should fall back to default)
        default_rule = data_protection_manager.get_rule(DataCategory.CONVERSATION)
        assert default_rule is not None
        assert default_rule.classification == DataClassification.INTERNAL  # Default
    
    def test_list_rules(self, data_protection_manager):
        """Test listing all protection rules."""
        rules = data_protection_manager.list_rules()
        
        assert isinstance(rules, list)
        assert len(rules) > 0
        
        # Check that all rules have required attributes
        for rule in rules:
            assert hasattr(rule, 'category')
            assert hasattr(rule, 'classification')
            assert hasattr(rule, 'encryption_required')
    
    def test_classify_data(self, data_protection_manager, mock_encryption):
        """Test classify_data convenience method."""
        # Mock encryption
        mock_encryption.keys = {"aes_tenant_default": Mock()}
        mock_encryption.encrypt_aes.return_value = b"encrypted_data"
        
        # Classify and protect data
        sensitive_data = {"credit_card": "1234-5678-9012-3456"}
        protected = data_protection_manager.classify_data(
            data=sensitive_data,
            category=DataCategory.CREDENTIALS,
            auto_protect=True,
            tenant_id="default",
            session_id="test_session"
        )
        
        assert protected is not None
        assert protected.category == DataCategory.CREDENTIALS
        assert protected.classification == DataClassification.SECRET
        assert protected.encrypted is True


class TestProtectionRule:
    """Test ProtectionRule functionality."""
    
    def test_rule_creation(self):
        """Test creating a protection rule."""
        rule = ProtectionRule(
            category=DataCategory.USER_PROFILE,
            classification=DataClassification.CONFIDENTIAL,
            encryption_required=True,
            rbac_permission=Permission.READ,
            tenant_isolation=True,
            audit_logging=True,
            retention_days=180
        )
        
        assert rule.category == DataCategory.USER_PROFILE
        assert rule.classification == DataClassification.CONFIDENTIAL
        assert rule.encryption_required is True
        assert rule.rbac_permission == Permission.READ
        assert rule.tenant_isolation is True
        assert rule.audit_logging is True
        assert rule.retention_days == 180
    
    def test_rule_to_dict(self):
        """Test converting rule to dictionary."""
        rule = ProtectionRule(
            category=DataCategory.API_KEYS,
            classification=DataClassification.SECRET,
            rbac_permission=Permission.DECRYPT
        )
        
        rule_dict = rule.to_dict()
        
        assert isinstance(rule_dict, dict)
        assert rule_dict["category"] == "api_keys"
        assert rule_dict["classification"] == "secret"
        assert rule_dict["rbac_permission"] == "decrypt"
        assert rule_dict["encryption_required"] is True  # Default
        assert rule_dict["tenant_isolation"] is True  # Default
    
    def test_rule_from_dict(self):
        """Test creating rule from dictionary."""
        rule_dict = {
            "category": "wave_data",
            "classification": "restricted",
            "encryption_required": True,
            "rbac_permission": "read",
            "tenant_isolation": True,
            "audit_logging": True,
            "retention_days": 365
        }
        
        rule = ProtectionRule.from_dict(rule_dict)
        
        assert rule.category == DataCategory.WAVE_DATA
        assert rule.classification == DataClassification.RESTRICTED
        assert rule.encryption_required is True
        assert rule.rbac_permission == Permission.READ
        assert rule.tenant_isolation is True
        assert rule.audit_logging is True
        assert rule.retention_days == 365


class TestProtectedData:
    """Test ProtectedData functionality."""
    
    def test_protected_data_creation(self):
        """Test creating protected data."""
        protected = ProtectedData(
            data={"name": "John Doe", "email": "john@example.com"},
            classification=DataClassification.CONFIDENTIAL,
            category=DataCategory.USER_PROFILE,
            tenant_id="tenant_123",
            encrypted=False,
            metadata={"source": "registration_form", "timestamp": "2024-01-01"}
        )
        
        assert protected.data["name"] == "John Doe"
        assert protected.classification == DataClassification.CONFIDENTIAL
        assert protected.category == DataCategory.USER_PROFILE
        assert protected.tenant_id == "tenant_123"
        assert protected.encrypted is False
        assert protected.metadata["source"] == "registration_form"
    
    def test_protected_data_to_dict(self):
        """Test converting protected data to dictionary."""
        protected = ProtectedData(
            data={"password": "secret"},
            classification=DataClassification.SECRET,
            category=DataCategory.CREDENTIALS,
            tenant_id="default",
            encrypted=True,
            encryption_key_id="aes_tenant_default",
            encrypted_data="encrypted_hex_string",
            metadata={"created_by": "system"}
        )
        
        protected_dict = protected.to_dict()
        
        assert isinstance(protected_dict, dict)
        assert protected_dict["classification"] == "secret"
        assert protected_dict["category"] == "credentials"
        assert protected_dict["tenant_id"] == "default"
        assert protected_dict["encrypted"] is True
        assert protected_dict["encryption_key_id"] == "aes_tenant_default"
        assert protected_dict["encrypted_data"] == "encrypted_hex_string"
        assert protected_dict["metadata"]["created_by"] == "system"
        assert protected_dict["data"] is None  # Should be None when encrypted


class TestSingleton:
    """Test singleton pattern for data protection manager."""
    
    def test_singleton(self):
        """Test that get_data_protection_manager returns a singleton."""
        with patch('core.data_protection.DataProtectionManager') as MockManager:
            mock_instance = Mock()
            MockManager.return_value = mock_instance
            
            manager1 = get_data_protection_manager()
            manager2 = get_data_protection_manager()
            
            assert manager1 is manager2
            MockManager.assert_called_once()  # Should only be instantiated once