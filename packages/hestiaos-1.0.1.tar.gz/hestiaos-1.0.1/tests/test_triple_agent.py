"""
tests/test_triple_agent.py
Fixed for Issue #31 — was a manual script with `def test_stream(message, label):`
but no pytest parametrize decorator, so pytest reported 'fixture message not found'.

Converted to a proper parametrized pytest test that skips if the API is not running.
"""
import pytest
import requests


API_URL = "http://localhost:8000/chat/stream"


def _is_api_running() -> bool:
    try:
        requests.get("http://localhost:8000/health", timeout=1)
        return True
    except Exception:
        return False


STREAM_TEST_CASES = [
    ("Hello, who are you?", "Simple Greeting"),
    (
        "Write a Python function for binary search and explain the time complexity.",
        "Complex Technical Task",
    ),
]


@pytest.mark.parametrize("message,label", STREAM_TEST_CASES)
@pytest.mark.skipif(not _is_api_running(), reason="API server not running on localhost:8000")
def test_stream(message: str, label: str):
    """
    Integration test: stream a chat response from the API.
    Skipped automatically when the API server is not available.
    """
    print(f"\n--- TEST: {label} ---")
    print(f"Query: {message}")

    with requests.post(
        API_URL,
        json={"message": message, "use_tools": True},
        stream=True,
        timeout=30,
    ) as r:
        assert r.status_code == 200, f"Unexpected status: {r.status_code}"

        msg_buffer = ""
        for line in r.iter_lines():
            if line:
                decoded = line.decode("utf-8")
                if decoded.startswith("data: "):
                    json_str = decoded[6:]
                    if json_str == "[DONE]":
                        break
                    import json
                    try:
                        data = json.loads(json_str)
                        if "content" in data:
                            msg_buffer += data["content"]
                    except json.JSONDecodeError:
                        pass

        print(f"\nResponse ({len(msg_buffer)} chars)")
        assert len(msg_buffer) > 0, "Expected non-empty response from API"
