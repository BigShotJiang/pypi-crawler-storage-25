"""
Tests für die GraphQueryEngine.

Testet:
- GraphQuery-Erstellung und Serialisierung
- execute() mit verschiedenen Filtern
- find_path() Pfad-Traversal
- get_violation_chain() Kausal-Ketten
- get_intent_coverage() Coverage-Mapping
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import pytest
from datetime import datetime, timezone
from typing import Dict, List

from core.ir.models import (
    ExecutionGraphIR, ExecutionNode, ExecutionEdge,
    NodeType, EdgeType, GraphScope,
)
from core.ir.query_engine import GraphQueryEngine, GraphQuery, QueryResult


# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def sample_graph() -> ExecutionGraphIR:
    """Erzeuge einen Beispiel-Graphen für Tests."""
    nodes: Dict[str, ExecutionNode] = {
        # Intent Layer
        "v1": ExecutionNode(
            node_id="v1", node_type=NodeType.VISION,
            label="HestiaOS Vision", scope=GraphScope.INTENT,
            timestamp="2026-01-01T00:00:00+00:00",
        ),
        "i1": ExecutionNode(
            node_id="i1", node_type=NodeType.INTENT,
            label="Runtime Contract Analysis", scope=GraphScope.INTENT,
            timestamp="2026-01-15T00:00:00+00:00",
        ),
        "i2": ExecutionNode(
            node_id="i2", node_type=NodeType.INTENT,
            label="Governance Replay", scope=GraphScope.INTENT,
            timestamp="2026-02-01T00:00:00+00:00",
        ),
        "a1": ExecutionNode(
            node_id="a1", node_type=NodeType.ADR,
            label="ADR-017: Runtime Contract Format", scope=GraphScope.INTENT,
            timestamp="2026-01-20T00:00:00+00:00",
        ),
        "c1": ExecutionNode(
            node_id="c1", node_type=NodeType.CONSTRAINT,
            label="No circular dependencies", scope=GraphScope.GOVERNANCE,
        ),
        # Architecture Layer
        "cap1": ExecutionNode(
            node_id="cap1", node_type=NodeType.CAPABILITY,
            label="contract_analysis", scope=GraphScope.ARCHITECTURE,
        ),
        "comp1": ExecutionNode(
            node_id="comp1", node_type=NodeType.COMPONENT,
            label="RuntimeContractAnalyzer", scope=GraphScope.RUNTIME,
        ),
        # Runtime Layer
        "viol1": ExecutionNode(
            node_id="viol1", node_type=NodeType.VIOLATION,
            label="ADR-017 Violation", scope=GraphScope.RUNTIME,
            timestamp="2026-03-01T00:00:00+00:00",
        ),
        "drift1": ExecutionNode(
            node_id="drift1", node_type=NodeType.DRIFT_NODE,
            label="Contract Drift Detected", scope=GraphScope.RUNTIME,
            timestamp="2026-03-15T00:00:00+00:00",
        ),
        # Execution Layer
        "t1": ExecutionNode(
            node_id="t1", node_type=NodeType.TASK,
            label="Implement Contract Analyzer", scope=GraphScope.EXECUTION,
        ),
    }

    edges: List[ExecutionEdge] = [
        # Intent → Architecture
        ExecutionEdge(source_id="i1", target_id="cap1", edge_type=EdgeType.SATISFIES),
        ExecutionEdge(source_id="i1", target_id="a1", edge_type=EdgeType.REFERENCE),
        ExecutionEdge(source_id="i2", target_id="a1", edge_type=EdgeType.REFERENCE),
        # Architecture → Runtime
        ExecutionEdge(source_id="cap1", target_id="comp1", edge_type=EdgeType.IMPLEMENTS),
        # Runtime Violations
        ExecutionEdge(source_id="viol1", target_id="a1", edge_type=EdgeType.VIOLATES),
        ExecutionEdge(source_id="drift1", target_id="comp1", edge_type=EdgeType.DEVIATES),
        # Intent → Execution
        ExecutionEdge(source_id="i1", target_id="t1", edge_type=EdgeType.DERIVES),
        # Governance
        ExecutionEdge(source_id="c1", target_id="t1", edge_type=EdgeType.BLOCKS),
    ]

    return ExecutionGraphIR(
        graph_id="test_graph",
        source="pytest",
        timestamp=datetime.now(timezone.utc).isoformat(),
        nodes=nodes,
        edges=edges,
    )


# =============================================================================
# GraphQuery Tests
# =============================================================================


class TestGraphQuery:
    """Tests für die GraphQuery-Dataclass."""

    def test_create_query(self):
        """Erstelle eine einfache Query."""
        query = GraphQuery(
            select=["violation", "drift"],
            where=[("severity", "eq", "high")],
        )
        assert "violation" in query.select
        assert "drift" in query.select
        assert len(query.where) == 1

    def test_query_serialization(self):
        """Teste Serialisierung/Deserialisierung."""
        query = GraphQuery(
            select=["violation"],
            where=[("node_type", "eq", "violation")],
            traverse="intent->adr",
            since="2026-01-01T00:00:00+00:00",
            group_by="scope",
        )
        data = query.to_dict()
        restored = GraphQuery.from_dict(data)
        assert restored.select == query.select
        assert restored.traverse == query.traverse
        assert restored.since == query.since
        assert restored.group_by == query.group_by

    def test_query_empty(self):
        """Leere Query = alle Nodes."""
        query = GraphQuery()
        assert query.select == []
        assert query.where == []


# =============================================================================
# GraphQueryEngine Tests
# =============================================================================


class TestGraphQueryEngine:
    """Tests für die GraphQueryEngine."""

    def test_execute_all(self, sample_graph):
        """execute() ohne Filter gibt alle Nodes zurück."""
        engine = GraphQueryEngine()
        query = GraphQuery()
        result = engine.execute(query, sample_graph)
        assert result.total_count == len(sample_graph.nodes)
        assert result.query is not None

    def test_execute_select_violations(self, sample_graph):
        """Filtere nach VIOLATION-Nodes."""
        engine = GraphQueryEngine()
        query = GraphQuery(select=["violation"])
        result = engine.execute(query, sample_graph)
        assert result.total_count == 1
        assert result.nodes[0].node_id == "viol1"

    def test_execute_select_intents(self, sample_graph):
        """Filtere nach INTENT-Nodes."""
        engine = GraphQueryEngine()
        query = GraphQuery(select=["intent"])
        result = engine.execute(query, sample_graph)
        assert result.total_count == 2
        node_ids = {n.node_id for n in result.nodes}
        assert "i1" in node_ids
        assert "i2" in node_ids

    def test_execute_select_multiple_types(self, sample_graph):
        """Filtere nach mehreren NodeTypes."""
        engine = GraphQueryEngine()
        query = GraphQuery(select=["violation", "drift"])
        result = engine.execute(query, sample_graph)
        assert result.total_count == 2

    def test_execute_where_eq(self, sample_graph):
        """Filtere mit where-Bedingung (eq)."""
        engine = GraphQueryEngine()
        query = GraphQuery(
            where=[("node_id", "eq", "i1")]
        )
        result = engine.execute(query, sample_graph)
        assert result.total_count == 1
        assert result.nodes[0].node_id == "i1"

    def test_execute_where_contains(self, sample_graph):
        """Filtere mit where-Bedingung (contains)."""
        engine = GraphQueryEngine()
        query = GraphQuery(
            where=[("label", "contains", "Contract")]
        )
        result = engine.execute(query, sample_graph)
        assert result.total_count >= 2  # i1 + cap1 + viol1 + drift1

    def test_execute_where_neq(self, sample_graph):
        """Filtere mit where-Bedingung (neq)."""
        engine = GraphQueryEngine()
        query = GraphQuery(
            where=[("node_type", "neq", "violation")]
        )
        result = engine.execute(query, sample_graph)
        # Alle außer viol1
        assert result.total_count == len(sample_graph.nodes) - 1

    def test_execute_with_since(self, sample_graph):
        """Filtere mit since (Timestamp)."""
        engine = GraphQueryEngine()
        query = GraphQuery(
            since="2026-02-01T00:00:00+00:00"
        )
        result = engine.execute(query, sample_graph)
        # i2 (2026-02-01), viol1 (2026-03-01), drift1 (2026-03-15)
        assert result.total_count >= 3

    def test_execute_with_group_by(self, sample_graph):
        """Gruppiere nach scope."""
        engine = GraphQueryEngine()
        query = GraphQuery(group_by="scope")
        result = engine.execute(query, sample_graph)
        assert result.grouped is not None
        # Es sollte mehrere Gruppen geben
        assert len(result.grouped) >= 3  # intent, runtime, governance, architecture, execution

    def test_execute_with_traverse(self, sample_graph):
        """Pfad-Traversal: intent -> adr."""
        engine = GraphQueryEngine()
        query = GraphQuery(traverse="intent->adr")
        result = engine.execute(query, sample_graph)
        # Sollte i1, i2, a1 enthalten (auf Pfaden zwischen INTENT und ADR)
        assert result.total_count >= 1

    def test_find_path_intent_to_adr(self, sample_graph):
        """Finde Pfade von INTENT zu ADR."""
        engine = GraphQueryEngine()
        paths = engine.find_path(NodeType.INTENT, NodeType.ADR, sample_graph)
        # i1 -> a1, i2 -> a1
        assert len(paths) >= 2

    def test_find_path_no_path(self, sample_graph):
        """Kein Pfad zwischen nicht verbundenen Types."""
        engine = GraphQueryEngine()
        paths = engine.find_path(NodeType.VISION, NodeType.DRIFT_NODE, sample_graph)
        assert len(paths) == 0  # Keine direkte Verbindung

    def test_find_path_with_max_depth(self, sample_graph):
        """Pfad-Suche mit max_depth."""
        engine = GraphQueryEngine()
        paths = engine.find_path(NodeType.INTENT, NodeType.COMPONENT, sample_graph, max_depth=5)
        # i1 -> cap1 -> comp1
        assert len(paths) >= 1

    def test_get_violation_chain(self, sample_graph):
        """Ermittle Kausal-Kette einer Violation."""
        engine = GraphQueryEngine()
        chain = engine.get_violation_chain("viol1", sample_graph)
        assert len(chain) >= 1
        # Erster Node sollte viol1 sein
        assert chain[0].node_id == "viol1"

    def test_get_violation_chain_nonexistent(self, sample_graph):
        """Nicht-existente Violation gibt leere Kette."""
        engine = GraphQueryEngine()
        chain = engine.get_violation_chain("nonexistent", sample_graph)
        assert len(chain) == 0

    def test_get_violation_chain_wrong_type(self, sample_graph):
        """Node ist keine Violation."""
        engine = GraphQueryEngine()
        chain = engine.get_violation_chain("i1", sample_graph)
        assert len(chain) == 0

    def test_get_intent_coverage(self, sample_graph):
        """Ermittle Coverage eines Intents."""
        engine = GraphQueryEngine()
        coverage = engine.get_intent_coverage("i1", sample_graph)
        assert "intent_id" in coverage
        assert coverage["intent_id"] == "i1"
        # i1 hat: capabilities, adrs, tasks
        assert len(coverage["capabilities"]) >= 1
        assert len(coverage["adrs"]) >= 1
        assert len(coverage["compiled_tasks"]) >= 1

    def test_get_intent_coverage_nonexistent(self, sample_graph):
        """Nicht-existenter Intent."""
        engine = GraphQueryEngine()
        coverage = engine.get_intent_coverage("nonexistent", sample_graph)
        assert "error" in coverage

    def test_get_intent_coverage_wrong_type(self, sample_graph):
        """Node ist kein Intent."""
        engine = GraphQueryEngine()
        coverage = engine.get_intent_coverage("viol1", sample_graph)
        assert "error" in coverage

    def test_execution_time_ms(self, sample_graph):
        """execute() liefert execution_time_ms."""
        engine = GraphQueryEngine()
        query = GraphQuery(select=["violation"])
        result = engine.execute(query, sample_graph)
        assert result.execution_time_ms >= 0

    def test_query_result_serialization(self, sample_graph):
        """QueryResult serialisieren."""
        engine = GraphQueryEngine()
        query = GraphQuery(select=["violation"])
        result = engine.execute(query, sample_graph)
        data = result.to_dict()
        assert "nodes" in data
        assert "total_count" in data
        assert data["total_count"] == 1

    def test_where_metadata_field(self, sample_graph):
        """Filtere nach metadata-Feld."""
        engine = GraphQueryEngine()
        # Füge Node mit metadata hinzu
        node = ExecutionNode(
            node_id="meta_test", node_type=NodeType.INTENT,
            label="Meta Test", scope=GraphScope.INTENT,
            metadata={"custom_field": "custom_value"},
        )
        graph = ExecutionGraphIR(
            graph_id="meta_test",
            source="pytest",
            timestamp=datetime.now(timezone.utc).isoformat(),
            nodes={"meta_test": node},
        )
        query = GraphQuery(
            where=[("metadata.custom_field", "eq", "custom_value")]
        )
        result = engine.execute(query, graph)
        assert result.total_count == 1

    def test_where_in_operator(self, sample_graph):
        """Filtere mit in-Operator."""
        engine = GraphQueryEngine()
        query = GraphQuery(
            where=[("node_type", "in", ["intent", "adr"])]
        )
        result = engine.execute(query, sample_graph)
        assert result.total_count == 3  # i1, i2, a1
