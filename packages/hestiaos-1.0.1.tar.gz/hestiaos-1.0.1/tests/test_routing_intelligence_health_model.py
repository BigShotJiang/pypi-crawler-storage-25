"""
CI-CRT-033: Backend Health Model — Tests.

Testet das BackendHealthModel, BackendHealthScore und HealthSignal:
1. BackendHealthScore: weighted_score Berechnung, to_dict()
2. HealthSignal: Erzeugung, Typen
3. BackendHealthModel: Signal Recording, Score Computation, Event Bus Integration
4. Global Singleton: get_health_model(), reset_health_model()
"""

import pytest
import time
from unittest.mock import AsyncMock, patch, MagicMock

from core.routing_intelligence.health_model import (
    BackendHealthModel,
    BackendHealthScore,
    HealthSignal,
    HealthSignalType,
    get_health_model,
    reset_health_model,
)
from core.backend.router_base import BackendStatus, EVENT_ROUTING_DECISION


# ============================================================================
# BackendHealthScore
# ============================================================================


class TestBackendHealthScore:
    """Tests für den BackendHealthScore Dataclass."""

    def test_default_score(self):
        """Default-Score ist 1.0 (perfekt)."""
        score = BackendHealthScore(backend_id="test_backend")
        assert score.backend_id == "test_backend"
        assert score.availability_score == 1.0
        assert score.latency_score == 1.0
        assert score.error_score == 1.0
        assert score.cost_score == 1.0
        assert score.weighted_score == 1.0
        assert score.signal_count == 0

    def test_compute_weighted_default_weights(self):
        """compute_weighted() mit Default-Gewichtung (balanced)."""
        score = BackendHealthScore(
            backend_id="test",
            availability_score=0.8,
            latency_score=0.6,
            error_score=0.9,
            cost_score=0.5,
        )
        weighted = score.compute_weighted()
        # 0.40*0.8 + 0.25*0.6 + 0.25*0.9 + 0.10*0.5
        expected = 0.40 * 0.8 + 0.25 * 0.6 + 0.25 * 0.9 + 0.10 * 0.5
        assert abs(weighted - expected) < 0.001
        assert abs(score.weighted_score - expected) < 0.001

    def test_compute_weighted_custom_weights(self):
        """compute_weighted() mit benutzerdefinierter Gewichtung."""
        score = BackendHealthScore(
            backend_id="test",
            availability_score=1.0,
            latency_score=0.5,
            error_score=0.5,
            cost_score=0.5,
            weights={"availability": 0.7, "latency": 0.1, "error": 0.1, "cost": 0.1},
        )
        weighted = score.compute_weighted()
        expected = 0.7 * 1.0 + 0.1 * 0.5 + 0.1 * 0.5 + 0.1 * 0.5
        assert abs(weighted - expected) < 0.001

    def test_all_zeros(self):
        """Alle Scores auf 0.0 → weighted_score = 0.0."""
        score = BackendHealthScore(
            backend_id="dead_backend",
            availability_score=0.0,
            latency_score=0.0,
            error_score=0.0,
            cost_score=0.0,
        )
        assert score.compute_weighted() == 0.0

    def test_all_ones(self):
        """Alle Scores auf 1.0 → weighted_score = 1.0."""
        score = BackendHealthScore(
            backend_id="perfect_backend",
            availability_score=1.0,
            latency_score=1.0,
            error_score=1.0,
            cost_score=1.0,
        )
        assert score.compute_weighted() == 1.0

    def test_to_dict(self):
        """to_dict() serialisiert korrekt."""
        score = BackendHealthScore(
            backend_id="test",
            availability_score=0.8,
            latency_score=0.6,
            error_score=0.9,
            cost_score=0.5,
            signal_count=42,
        )
        score.compute_weighted()
        d = score.to_dict()

        assert d["backend_id"] == "test"
        assert d["availability_score"] == 0.8
        assert d["latency_score"] == 0.6
        assert d["error_score"] == 0.9
        assert d["cost_score"] == 0.5
        assert d["signal_count"] == 42
        assert "weighted_score" in d
        assert "last_updated" in d


# ============================================================================
# HealthSignal
# ============================================================================


class TestHealthSignal:
    """Tests für den HealthSignal Dataclass."""

    def test_minimal_signal(self):
        """HealthSignal mit minimalen Feldern."""
        signal = HealthSignal(
            backend_id="test",
            signal_type=HealthSignalType.AVAILABILITY,
            value=1.0,
        )
        assert signal.backend_id == "test"
        assert signal.signal_type == HealthSignalType.AVAILABILITY
        assert signal.value == 1.0
        assert signal.timestamp > 0
        assert signal.metadata == {}

    def test_signal_with_metadata(self):
        """HealthSignal mit Metadaten."""
        signal = HealthSignal(
            backend_id="test",
            signal_type=HealthSignalType.ERROR,
            value=0.0,
            metadata={"error": "timeout", "trace_id": "abc123"},
        )
        assert signal.metadata["error"] == "timeout"
        assert signal.metadata["trace_id"] == "abc123"

    def test_all_signal_types(self):
        """Alle HealthSignalType-Werte sind nutzbar."""
        for signal_type in HealthSignalType:
            signal = HealthSignal(
                backend_id="test",
                signal_type=signal_type,
                value=0.5,
            )
            assert signal.signal_type == signal_type


# ============================================================================
# BackendHealthModel
# ============================================================================


class TestBackendHealthModel:
    """Tests für das BackendHealthModel."""

    @pytest.mark.asyncio
    async def test_record_signal(self):
        """record_signal() zeichnet ein Signal auf und erzeugt Score."""
        model = BackendHealthModel(window_size=10, decay_hours=24)

        signal = HealthSignal(
            backend_id="test_backend",
            signal_type=HealthSignalType.AVAILABILITY,
            value=1.0,
        )
        await model.record_signal(signal)

        score = await model.get_score("test_backend")
        assert score is not None
        assert score.backend_id == "test_backend"
        assert score.availability_score == 1.0
        assert score.signal_count == 1

    @pytest.mark.asyncio
    async def test_record_health_check_healthy(self):
        """record_health_check() mit HEALTHY → availability_score = 1.0."""
        model = BackendHealthModel(window_size=10)
        await model.record_health_check("backend_a", BackendStatus.HEALTHY)

        score = await model.get_score("backend_a")
        assert score is not None
        assert score.availability_score == 1.0

    @pytest.mark.asyncio
    async def test_record_health_check_unhealthy(self):
        """record_health_check() mit UNHEALTHY → availability_score = 0.0."""
        model = BackendHealthModel(window_size=10)
        await model.record_health_check("backend_a", BackendStatus.UNHEALTHY)

        score = await model.get_score("backend_a")
        assert score is not None
        assert score.availability_score == 0.0

    @pytest.mark.asyncio
    async def test_record_health_check_degraded(self):
        """record_health_check() mit DEGRADED → availability_score = 0.5."""
        model = BackendHealthModel(window_size=10)
        await model.record_health_check("backend_a", BackendStatus.DEGRADED)

        score = await model.get_score("backend_a")
        assert score is not None
        assert score.availability_score == 0.5

    @pytest.mark.asyncio
    async def test_record_latency_fast(self):
        """record_latency() mit 50ms → latency_score nahe 1.0."""
        model = BackendHealthModel(window_size=10)
        await model.record_latency("backend_a", 50)

        score = await model.get_score("backend_a")
        assert score is not None
        assert score.latency_score > 0.9

    @pytest.mark.asyncio
    async def test_record_latency_slow(self):
        """record_latency() mit 10000ms → latency_score = 0.0."""
        model = BackendHealthModel(window_size=10)
        await model.record_latency("backend_a", 10000)

        score = await model.get_score("backend_a")
        assert score is not None
        assert score.latency_score == 0.0

    @pytest.mark.asyncio
    async def test_record_error(self):
        """record_error() → error_score = 0.0."""
        model = BackendHealthModel(window_size=10)
        await model.record_error("backend_a", "connection refused")

        score = await model.get_score("backend_a")
        assert score is not None
        assert score.error_score == 0.0

    @pytest.mark.asyncio
    async def test_record_success(self):
        """record_success() → error_score = 1.0."""
        model = BackendHealthModel(window_size=10)
        await model.record_success("backend_a")

        score = await model.get_score("backend_a")
        assert score is not None
        assert score.error_score == 1.0

    @pytest.mark.asyncio
    async def test_record_cost_zero(self):
        """record_cost() mit 0 → cost_score = 1.0."""
        model = BackendHealthModel(window_size=10)
        await model.record_cost("backend_a", 0)

        score = await model.get_score("backend_a")
        assert score is not None
        assert score.cost_score == 1.0

    @pytest.mark.asyncio
    async def test_record_cost_high(self):
        """record_cost() mit hohen Kosten → cost_score nahe 0.0."""
        model = BackendHealthModel(window_size=10)
        await model.record_cost("backend_a", 100000)

        score = await model.get_score("backend_a")
        assert score is not None
        assert score.cost_score < 0.1

    @pytest.mark.asyncio
    async def test_get_all_scores(self):
        """get_all_scores() gibt alle Scores zurück."""
        model = BackendHealthModel(window_size=10)
        await model.record_health_check("backend_a", BackendStatus.HEALTHY)
        await model.record_health_check("backend_b", BackendStatus.UNHEALTHY)

        scores = await model.get_all_scores()
        assert len(scores) == 2
        assert "backend_a" in scores
        assert "backend_b" in scores

    @pytest.mark.asyncio
    async def test_get_score_unknown(self):
        """get_score() für unbekanntes Backend → None."""
        model = BackendHealthModel(window_size=10)
        score = await model.get_score("nonexistent")
        assert score is None

    @pytest.mark.asyncio
    async def test_sliding_window(self):
        """Sliding Window begrenzt die Anzahl der Signale."""
        model = BackendHealthModel(window_size=5)
        for i in range(10):
            await model.record_health_check("backend_a", BackendStatus.HEALTHY)

        score = await model.get_score("backend_a")
        assert score is not None
        assert score.signal_count <= 5  # Window Size

    @pytest.mark.asyncio
    async def test_multiple_signal_types(self):
        """Mehrere Signal-Typen für ein Backend → korrekte Sub-Scores."""
        model = BackendHealthModel(window_size=100)
        await model.record_health_check("backend_a", BackendStatus.HEALTHY)  # avail=1.0
        await model.record_latency("backend_a", 100)  # latency ~1.0
        await model.record_success("backend_a")  # error=1.0
        await model.record_cost("backend_a", 100)  # cost=100 → 1.0-100/(100+1000)=~0.909

        score = await model.get_score("backend_a")
        assert score is not None
        assert score.availability_score == 1.0
        assert score.latency_score > 0.9
        assert score.error_score == 1.0
        assert 0.8 < score.cost_score < 1.0

    @pytest.mark.asyncio
    async def test_set_weights(self):
        """set_weights() ändert die Gewichtung."""
        model = BackendHealthModel(window_size=10)
        model.set_weights({"availability": 0.8, "latency": 0.1, "error": 0.05, "cost": 0.05})

        await model.record_health_check("backend_a", BackendStatus.HEALTHY)
        score = await model.get_score("backend_a")
        assert score is not None
        assert score.weights["availability"] == 0.8

    @pytest.mark.asyncio
    async def test_get_diagnostics(self):
        """get_diagnostics() gibt vollständige Diagnose zurück."""
        model = BackendHealthModel(window_size=10)
        await model.record_health_check("backend_a", BackendStatus.HEALTHY)

        diag = await model.get_diagnostics()
        assert "scores" in diag
        assert "signal_counts" in diag
        assert "config" in diag
        assert "timestamp" in diag
        assert diag["config"]["window_size"] == 10

    @pytest.mark.asyncio
    async def test_event_bus_subscription(self):
        """subscribe_to_events() registriert Handler am Event Bus."""
        import sys
        from unittest.mock import MagicMock

        model = BackendHealthModel(window_size=10)

        # Erstelle Mock-Event-Bus und platziere ihn in sys.modules
        # (umgeht den circular import in core/event_bus/__init__.py)
        mock_event_bus = MagicMock()
        mock_event_bus.subscribe = MagicMock()
        mock_event_bus_module = MagicMock()
        mock_event_bus_module.event_bus = mock_event_bus
        sys.modules["core.event_bus"] = mock_event_bus_module

        try:
            model.subscribe_to_events()
            mock_event_bus.subscribe.assert_called_once_with(
                EVENT_ROUTING_DECISION, model._event_handler
            )
        finally:
            # Cleanup
            sys.modules.pop("core.event_bus", None)

    @pytest.mark.asyncio
    async def test_event_bus_unsubscription(self):
        """unsubscribe_from_events() entfernt Handler."""
        import sys
        from unittest.mock import MagicMock

        model = BackendHealthModel(window_size=10)

        mock_event_bus = MagicMock()
        mock_event_bus.subscribe = MagicMock()
        mock_event_bus.unsubscribe = MagicMock()
        mock_event_bus_module = MagicMock()
        mock_event_bus_module.event_bus = mock_event_bus
        sys.modules["core.event_bus"] = mock_event_bus_module

        try:
            model.subscribe_to_events()
            model.unsubscribe_from_events()
            mock_event_bus.unsubscribe.assert_called_once()
        finally:
            sys.modules.pop("core.event_bus", None)

    @pytest.mark.asyncio
    async def test_handle_routing_decision_fallback(self):
        """RoutingDecision mit fallback → error signal für fallback_chain, kein success für fallback."""
        model = BackendHealthModel(window_size=10)

        await model._handle_routing_decision({
            "trace_id": "trace-1",
            "selected_backend": "fallback_cpu",
            "reason": "fallback_backend_selected",
            "fallback_used": True,
            "fallback_chain": ["preferred_gpu", "community_cpu"],
            "candidate_backends": ["preferred_gpu"],
        })

        # preferred_gpu sollte error-Signal haben
        score_preferred = await model.get_score("preferred_gpu")
        assert score_preferred is not None
        assert score_preferred.error_score == 0.0

        # community_cpu sollte error-Signal haben
        score_community = await model.get_score("community_cpu")
        assert score_community is not None
        assert score_community.error_score == 0.0

        # fallback_cpu hat kein Signal (nur selected, aber fallback_used=True → kein success)
        score_fallback = await model.get_score("fallback_cpu")
        assert score_fallback is None

    @pytest.mark.asyncio
    async def test_handle_routing_decision_no_backend(self):
        """RoutingDecision ohne selected_backend → error für alle Kandidaten."""
        model = BackendHealthModel(window_size=10)

        await model._handle_routing_decision({
            "trace_id": "trace-2",
            "selected_backend": None,
            "reason": "no_healthy_backend",
            "fallback_used": True,
            "fallback_chain": ["gpu1", "gpu2"],
            "candidate_backends": ["gpu1", "gpu2", "cpu1"],
        })

        for bid in ["gpu1", "gpu2", "cpu1"]:
            score = await model.get_score(bid)
            assert score is not None, f"{bid} should have a score"
            assert score.error_score == 0.0, f"{bid} should have error_score=0.0"

    @pytest.mark.asyncio
    async def test_handle_routing_decision_success(self):
        """RoutingDecision mit Erfolg (kein Fallback) → success signal."""
        model = BackendHealthModel(window_size=10)

        await model._handle_routing_decision({
            "trace_id": "trace-3",
            "selected_backend": "expert_gpu",
            "reason": "preferred_backend_healthy",
            "fallback_used": False,
            "fallback_chain": [],
            "candidate_backends": ["expert_gpu"],
        })

        score = await model.get_score("expert_gpu")
        assert score is not None
        assert score.error_score == 1.0


# ============================================================================
# Global Singleton
# ============================================================================


class TestHealthModelSingleton:
    """Tests für das globale Singleton."""

    def setup_method(self):
        reset_health_model()

    def test_get_health_model_returns_instance(self):
        """get_health_model() gibt eine BackendHealthModel-Instanz zurück."""
        model = get_health_model()
        assert isinstance(model, BackendHealthModel)

    def test_get_health_model_singleton(self):
        """get_health_model() gibt immer dieselbe Instanz zurück."""
        model1 = get_health_model()
        model2 = get_health_model()
        assert model1 is model2

    def test_reset_health_model(self):
        """reset_health_model() setzt die Instanz zurück."""
        model1 = get_health_model()
        reset_health_model()
        model2 = get_health_model()
        assert model1 is not model2
