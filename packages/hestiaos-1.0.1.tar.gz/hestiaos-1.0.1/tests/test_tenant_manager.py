"""
Tests for the Tenant Management System.
"""

import pytest
import tempfile
import json
from pathlib import Path
from datetime import datetime

from core.tenant_manager import (
    TenantManager,
    Tenant,
    TenantStatus,
    TenantTier,
    TenantConfig,
    get_tenant_manager
)


@pytest.fixture
def temp_storage():
    """Create temporary storage for tenant tests."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield Path(tmpdir)


@pytest.fixture
def tenant_manager(temp_storage):
    """Create tenant manager with temporary storage."""
    return TenantManager(temp_storage)


class TestTenantManager:
    """Test TenantManager functionality."""
    
    def test_initialization(self, tenant_manager):
        """Test that tenant manager initializes correctly."""
        assert tenant_manager is not None
        assert "default" in tenant_manager.tenants
        assert tenant_manager.tenants["default"].name == "Default Tenant"
        assert tenant_manager.tenants["default"].tier == TenantTier.ENTERPRISE
    
    def test_create_tenant(self, tenant_manager):
        """Test creating a new tenant."""
        tenant = tenant_manager.create_tenant(
            name="Test Tenant",
            description="Test description",
            tier=TenantTier.BASIC,
            contact_email="test@example.com",
            contact_name="Test User"
        )
        
        assert tenant is not None
        assert tenant.tenant_id.startswith("tenant_")
        assert tenant.name == "Test Tenant"
        assert tenant.tier == TenantTier.BASIC
        assert tenant.status == TenantStatus.ACTIVE
        assert tenant.contact_email == "test@example.com"
        assert tenant.contact_name == "Test User"
        
        # Verify tenant was saved
        assert tenant.tenant_id in tenant_manager.tenants
    
    def test_get_tenant(self, tenant_manager):
        """Test retrieving a tenant."""
        # Create a tenant
        tenant = tenant_manager.create_tenant(name="Test Tenant")
        
        # Retrieve it
        retrieved = tenant_manager.get_tenant(tenant.tenant_id)
        
        assert retrieved is not None
        assert retrieved.tenant_id == tenant.tenant_id
        assert retrieved.name == "Test Tenant"
    
    def test_get_nonexistent_tenant(self, tenant_manager):
        """Test retrieving a non-existent tenant."""
        retrieved = tenant_manager.get_tenant("nonexistent")
        assert retrieved is None
    
    def test_update_tenant(self, tenant_manager):
        """Test updating a tenant."""
        # Create a tenant
        tenant = tenant_manager.create_tenant(name="Original Name")
        
        # Update it
        updated = tenant_manager.update_tenant(
            tenant.tenant_id,
            name="Updated Name",
            description="Updated description"
        )
        
        assert updated is not None
        assert updated.name == "Updated Name"
        assert updated.description == "Updated description"
        assert updated.updated_at > tenant.updated_at
        
        # Verify the update persisted
        retrieved = tenant_manager.get_tenant(tenant.tenant_id)
        assert retrieved.name == "Updated Name"
    
    def test_delete_tenant_soft(self, tenant_manager):
        """Test soft deleting a tenant."""
        # Create a tenant
        tenant = tenant_manager.create_tenant(name="To Delete")
        
        # Soft delete it
        result = tenant_manager.delete_tenant(tenant.tenant_id, hard_delete=False)
        assert result is True
        
        # Verify it's marked as deleted
        deleted_tenant = tenant_manager.get_tenant(tenant.tenant_id)
        assert deleted_tenant is not None
        assert deleted_tenant.status == TenantStatus.DELETED
        assert deleted_tenant.deleted_at is not None
    
    def test_delete_tenant_hard(self, tenant_manager):
        """Test hard deleting a tenant."""
        # Create a tenant
        tenant = tenant_manager.create_tenant(name="To Delete Hard")
        
        # Hard delete it
        result = tenant_manager.delete_tenant(tenant.tenant_id, hard_delete=True)
        assert result is True
        
        # Verify it's gone
        deleted_tenant = tenant_manager.get_tenant(tenant.tenant_id)
        assert deleted_tenant is None
    
    def test_cannot_delete_default_tenant(self, tenant_manager):
        """Test that default tenant cannot be deleted."""
        result = tenant_manager.delete_tenant("default", hard_delete=True)
        assert result is False
        
        # Verify default tenant still exists
        default_tenant = tenant_manager.get_tenant("default")
        assert default_tenant is not None
    
    def test_list_tenants(self, tenant_manager):
        """Test listing tenants with filters."""
        # Create multiple tenants with different statuses
        tenant1 = tenant_manager.create_tenant(name="Active Tenant", tier=TenantTier.BASIC)
        tenant2 = tenant_manager.create_tenant(name="Another Active", tier=TenantTier.PROFESSIONAL)
        
        # Delete one
        tenant_manager.delete_tenant(tenant2.tenant_id, hard_delete=False)
        
        # List all (excluding deleted)
        all_tenants = tenant_manager.list_tenants()
        tenant_ids = [t.tenant_id for t in all_tenants]
        
        assert "default" in tenant_ids
        assert tenant1.tenant_id in tenant_ids
        assert tenant2.tenant_id not in tenant_ids  # Deleted, so excluded by default
        
        # List including deleted
        all_including_deleted = tenant_manager.list_tenants(include_deleted=True)
        tenant_ids_all = [t.tenant_id for t in all_including_deleted]
        assert tenant2.tenant_id in tenant_ids_all
        
        # List by tier
        basic_tenants = tenant_manager.list_tenants(tier=TenantTier.BASIC)
        assert len(basic_tenants) >= 1  # At least tenant1
        assert all(t.tier == TenantTier.BASIC for t in basic_tenants)
    
    def test_validate_tenant_access(self, tenant_manager):
        """Test tenant access validation."""
        # Same tenant - allowed
        assert tenant_manager.validate_tenant_access("tenant_a", "tenant_a") is True
        
        # System tenant can access any tenant
        assert tenant_manager.validate_tenant_access("system", "tenant_a") is True
        assert tenant_manager.validate_tenant_access("system", "tenant_b") is True
        
        # Different tenants - denied by default
        assert tenant_manager.validate_tenant_access("tenant_a", "tenant_b") is False
        
        # Non-existent target tenant
        assert tenant_manager.validate_tenant_access("tenant_a", "nonexistent") is False
    
    def test_get_tenant_stats(self, tenant_manager):
        """Test getting tenant statistics."""
        stats = tenant_manager.get_tenant_stats("default")
        
        assert stats is not None
        assert "tenant_id" in stats
        assert stats["tenant_id"] == "default"
        assert "name" in stats
        assert "tier" in stats
        assert "status" in stats
        assert "config" in stats
    
    def test_increment_api_calls(self, tenant_manager):
        """Test incrementing API call counter."""
        # Create a tenant
        tenant = tenant_manager.create_tenant(name="API Test")
        initial_calls = tenant.total_api_calls
        
        # Increment
        tenant_manager.increment_api_calls(tenant.tenant_id, 5)
        
        # Verify
        updated_tenant = tenant_manager.get_tenant(tenant.tenant_id)
        assert updated_tenant.total_api_calls == initial_calls + 5
    
    def test_check_tenant_limits(self, tenant_manager):
        """Test checking tenant limits."""
        # Create a basic tenant with low limits
        tenant = tenant_manager.create_tenant(
            name="Limit Test",
            tier=TenantTier.FREE
        )
        
        # Free tier has max_users = 3, max_concurrent_sessions = 2
        # Set user count to exceed limit
        tenant.user_count = 4
        tenant.active_session_count = 3
        tenant_manager.tenants[tenant.tenant_id] = tenant
        
        # Check limits
        limit_check = tenant_manager.check_tenant_limits(tenant.tenant_id)
        
        assert "within_limits" in limit_check
        assert "exceeded_limits" in limit_check
        assert "warnings" in limit_check
        
        # Should have exceeded user and session limits
        assert "max_users" in limit_check["exceeded_limits"]
        assert "max_concurrent_sessions" in limit_check["exceeded_limits"]
        assert limit_check["within_limits"] is False


class TestTenantConfig:
    """Test TenantConfig functionality."""
    
    def test_config_creation(self):
        """Test creating a tenant config."""
        config = TenantConfig(
            max_users=50,
            max_storage_mb=5120,
            max_api_calls_per_day=10000,
            max_concurrent_sessions=20,
            allow_custom_roles=True,
            allow_plugin_management=True,
            allowed_models=["model1", "model2"],
            restricted_tools=["dangerous_tool"],
            data_retention_days=180
        )
        
        assert config.max_users == 50
        assert config.max_storage_mb == 5120
        assert config.max_api_calls_per_day == 10000
        assert config.max_concurrent_sessions == 20
        assert config.allow_custom_roles is True
        assert config.allow_plugin_management is True
        assert "model1" in config.allowed_models
        assert "dangerous_tool" in config.restricted_tools
        assert config.data_retention_days == 180
    
    def test_config_to_dict(self):
        """Test converting config to dictionary."""
        config = TenantConfig(max_users=25)
        config_dict = config.to_dict()
        
        assert isinstance(config_dict, dict)
        assert config_dict["max_users"] == 25
        assert "max_storage_mb" in config_dict
        assert "allowed_models" in config_dict
    
    def test_config_from_dict(self):
        """Test creating config from dictionary."""
        config_dict = {
            "max_users": 30,
            "max_storage_mb": 2048,
            "max_api_calls_per_day": 5000,
            "max_concurrent_sessions": 10,
            "allow_custom_roles": False,
            "allow_plugin_management": False,
            "allowed_models": ["qwen2.5:7b"],
            "restricted_tools": [],
            "data_retention_days": 90
        }
        
        config = TenantConfig.from_dict(config_dict)
        
        assert config.max_users == 30
        assert config.max_storage_mb == 2048
        assert config.max_api_calls_per_day == 5000
        assert config.max_concurrent_sessions == 10
        assert config.allow_custom_roles is False
        assert config.allow_plugin_management is False
        assert config.allowed_models == ["qwen2.5:7b"]
        assert config.data_retention_days == 90


class TestTenantSerialization:
    """Test tenant serialization and deserialization."""
    
    def test_tenant_to_dict(self):
        """Test converting tenant to dictionary."""
        config = TenantConfig(max_users=10)
        tenant = Tenant(
            tenant_id="test_123",
            name="Test Tenant",
            description="Test description",
            status=TenantStatus.ACTIVE,
            tier=TenantTier.BASIC,
            contact_email="test@example.com",
            contact_name="Test User",
            config=config
        )
        
        tenant_dict = tenant.to_dict()
        
        assert isinstance(tenant_dict, dict)
        assert tenant_dict["tenant_id"] == "test_123"
        assert tenant_dict["name"] == "Test Tenant"
        assert tenant_dict["status"] == "active"
        assert tenant_dict["tier"] == "basic"
        assert tenant_dict["contact_email"] == "test@example.com"
        assert "config" in tenant_dict
        assert tenant_dict["config"]["max_users"] == 10
    
    def test_tenant_from_dict(self):
        """Test creating tenant from dictionary."""
        tenant_dict = {
            "tenant_id": "test_456",
            "name": "From Dict Tenant",
            "description": "Created from dict",
            "status": "active",
            "tier": "professional",
            "contact_email": "dict@example.com",
            "contact_name": "Dict User",
            "config": {
                "max_users": 50,
                "max_storage_mb": 5120,
                "max_api_calls_per_day": 10000,
                "max_concurrent_sessions": 20,
                "allow_custom_roles": True,
                "allow_plugin_management": True,
                "allowed_models": ["model1", "model2"],
                "restricted_tools": ["tool1"],
                "data_retention_days": 180
            },
            "created_at": "2024-01-01T12:00:00",
            "updated_at": "2024-01-02T12:00:00",
            "deleted_at": None,
            "user_count": 5,
            "active_session_count": 2,
            "total_api_calls": 1000
        }
        
        tenant = Tenant.from_dict(tenant_dict)
        
        assert tenant.tenant_id == "test_456"
        assert tenant.name == "From Dict Tenant"
        assert tenant.status == TenantStatus.ACTIVE
        assert tenant.tier == TenantTier.PROFESSIONAL
        assert tenant.contact_email == "dict@example.com"
        assert tenant.config.max_users == 50
        assert isinstance(tenant.created_at, datetime)
        assert tenant.user_count == 5
        assert tenant.active_session_count == 2
        assert tenant.total_api_calls == 1000


class TestSingleton:
    """Test singleton pattern for tenant manager."""
    
    def test_singleton(self, temp_storage):
        """Test that get_tenant_manager returns a singleton."""
        manager1 = get_tenant_manager(temp_storage)
        manager2 = get_tenant_manager(temp_storage)
        
        assert manager1 is manager2
        
        # Different storage paths should create different instances
        with tempfile.TemporaryDirectory() as other_tmpdir:
            manager3 = get_tenant_manager(Path(other_tmpdir))
            assert manager3 is not manager1