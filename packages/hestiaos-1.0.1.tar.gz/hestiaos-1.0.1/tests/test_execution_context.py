import pytest
import time
from core.context import ExecutionContext, generate_trace_id

def test_trace_id_generation():
    """Verify trace IDs are generated with proper format: hestia_<timestamp>_<uuid_short>."""
    trace_id = generate_trace_id("hestia")
    assert trace_id.startswith("hestia_")
    parts = trace_id.split("_")
    assert len(parts) == 3
    # Timestamp part should be an integer
    assert int(parts[1]) > 0
    # Unique part should be 8 hex characters
    assert len(parts[2]) == 8

def test_mode_validation():
    """Verify system defaults to community if invalid mode is provided."""
    ctx = ExecutionContext(session_id="test", mode="invalid-mode")
    assert ctx.mode == "community"
    
    ctx2 = ExecutionContext.from_request({"session_id": "test", "mode": "business"})
    assert ctx2.mode == "business"

def test_flat_metadata_validation():
    """Verify that nested metadata raises ValueError."""
    with pytest.raises(ValueError) as excinfo:
        ExecutionContext(session_id="test", metadata={"nested": {"key": "value"}})
    assert "nested structure" in str(excinfo.value)
    
    # Flat metadata should pass
    ctx = ExecutionContext(session_id="test", metadata={"key1": "value1", "key2": 123})
    assert ctx.metadata["key1"] == "value1"

def test_mode_instructions():
    """Verify mode-specific instructions are generated correctly."""
    business_ctx = ExecutionContext(session_id="test", mode="business")
    assert "BUSINESS mode" in business_ctx.get_mode_instructions()
    assert "high-assurance" in business_ctx.get_mode_instructions().lower()
    
    community_ctx = ExecutionContext(session_id="test", mode="community")
    assert "experimental tools" in community_ctx.get_mode_instructions()

def test_mode_restrictions():
    """Verify mode restrictions are correctly applied."""
    business_ctx = ExecutionContext(session_id="test", mode="business")
    assert "experimental" in business_ctx.get_mode_restrictions()
    assert "community_only" in business_ctx.get_mode_restrictions()
    
    science_ctx = ExecutionContext(session_id="test", mode="science")
    assert "experimental" in science_ctx.get_mode_restrictions()
    
    community_ctx = ExecutionContext(session_id="test", mode="community")
    assert len(community_ctx.get_mode_restrictions()) == 0

def test_from_request_factory():
    """Verify factory correctly maps fields."""
    req = {
        "session_id": "s1",
        "tenant_id": "t1",
        "mode": "science",
        "user_id": "u1",
        "request_id": "r1",
        "metadata": {"source": "api"}
    }
    ctx = ExecutionContext.from_request(req)
    assert ctx.session_id == "s1"
    assert ctx.tenant_id == "t1"
    assert ctx.mode == "science"
    assert ctx.user_id == "u1"
    assert ctx.request_id == "r1"
    assert ctx.metadata["source"] == "api"
    assert ctx.trace_id.startswith("hestia_")
