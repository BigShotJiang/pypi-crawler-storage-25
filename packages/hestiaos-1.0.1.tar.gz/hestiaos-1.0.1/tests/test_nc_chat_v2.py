import asyncio
import httpx
from core.config import config_manager

async def test_chat():
    nc_config = config_manager.get("nextcloud", {})
    url = nc_config.get("url", "").rstrip("/")
    user = nc_config.get("user", "")
    password = nc_config.get("password", "")
    token = "6mvoe63h"
    
    headers = {"OCS-APIRequest": "true", "Accept": "application/json"}
    auth = (user, password)
    
    # Try fetching messages
    ep = f"{url}/ocs/v2.php/apps/spreed/api/v1/chat/{token}?format=json"
    async with httpx.AsyncClient(timeout=10.0) as client:
        resp = await client.get(ep, headers=headers, auth=auth)
        print(f"Chat check Status: {resp.status_code}")
        print(f"Chat check Body: {resp.text[:500]}")

if __name__ == "__main__":
    asyncio.run(test_chat())
