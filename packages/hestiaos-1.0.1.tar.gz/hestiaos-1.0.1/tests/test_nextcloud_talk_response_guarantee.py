#!/usr/bin/env python3
"""
Test for Nextcloud Talk response guarantee fix.
Verifies that @hestia mentions always get a response within 30 seconds.
"""

import asyncio
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from unittest.mock import Mock, patch, AsyncMock
from plugins.nextcloud_talk import NextcloudTalkPlugin


async def test_mention_guarantees_response():
    """Test that @hestia mentions guarantee a response is sent."""
    print("🧪 Testing Nextcloud Talk response guarantee for mentions...")
    
    # Create plugin instance
    plugin = NextcloudTalkPlugin()
    
    # Mock configuration
    plugin.enabled = True
    plugin.server_url = "https://nextcloud.example.com"
    plugin.username = "testuser"
    plugin.password = "testpass"
    plugin.verify_ssl = False
    plugin.rooms = {
        "test_token": {
            "alias": "test_room",
            "allow_tools": True,
            "last_id": 0,
            "api_version": "v2"
        }
    }
    
    # Mock the _send_message method to track calls
    send_calls = []
    async def mock_send_message(room_identifier, message):
        send_calls.append({
            "room": room_identifier,
            "message": message,
            "timestamp": asyncio.get_event_loop().time()
        })
        return True
    
    plugin._send_message = mock_send_message
    
    # Mock the HTTP client to simulate API responses
    mock_response = Mock()
    mock_response.status_code = 200
    mock_response.json.return_value = {"response": ""}  # Empty response
    
    with patch('httpx.AsyncClient.post', new_callable=AsyncMock) as mock_post:
        mock_post.return_value = mock_response
        
        # Test 1: @hestia hallo with empty API response
        print("  Testing @hestia hallo with empty API response...")
        await plugin._handle_incoming("test_token", "user123", "@hestia hallo")
        
        # Wait a bit for async processing
        await asyncio.sleep(0.1)
        
        # Verify that _send_message was called (should send fallback "Hallo 👋")
        assert len(send_calls) > 0, "FAIL: _send_message was not called for mention!"
        print(f"  ✓ _send_message called {len(send_calls)} times")
        
        # Check that we got a response (either actual or fallback)
        first_call = send_calls[0]
        assert "test_token" in first_call["room"], f"FAIL: Wrong room: {first_call['room']}"
        print(f"  ✓ Response sent to correct room: {first_call['room']}")
        
        # The message should be either the fallback or some response
        assert first_call["message"], f"FAIL: Empty message sent: {first_call['message']}"
        print(f"  ✓ Non-empty message sent: '{first_call['message'][:50]}...'")
        
        # Reset for next test
        send_calls.clear()
        
        # Test 2: @hestia hallo with actual API response
        print("  Testing @hestia hallo with actual API response...")
        mock_response.json.return_value = {"response": "Hallo! Wie kann ich helfen?"}
        
        await plugin._handle_incoming("test_token", "user123", "@hestia hallo")
        await asyncio.sleep(0.1)
        
        assert len(send_calls) > 0, "FAIL: No response sent for mention with API response"
        print(f"  ✓ _send_message called with actual response")
        
        # Check the response contains the expected text
        assert "Hallo" in send_calls[0]["message"] or "helfen" in send_calls[0]["message"]
        print(f"  ✓ Correct response content: '{send_calls[0]['message'][:50]}...'")
        
        # Reset for next test
        send_calls.clear()
        
        # Test 3: Non-mention message (should not trigger response)
        print("  Testing non-mention message (should not respond)...")
        await plugin._handle_incoming("test_token", "user123", "just a regular message")
        await asyncio.sleep(0.1)
        
        assert len(send_calls) == 0, f"FAIL: Response sent for non-mention: {send_calls}"
        print("  ✓ No response sent for non-mention (correct)")
        
        # Test 4: Command (should trigger response)
        print("  Testing command /help (should respond)...")
        mock_response.json.return_value = {"response": "Help information here"}
        
        await plugin._handle_incoming("test_token", "user123", "/help")
        await asyncio.sleep(0.1)
        
        assert len(send_calls) > 0, "FAIL: No response sent for command"
        print(f"  ✓ Command triggered response")
    
    print("✅ All mention response guarantee tests passed!")
    return True


async def test_timeout_handling():
    """Test that timeout handling sends intermediate messages."""
    print("\n🧪 Testing timeout handling with intermediate messages...")
    
    plugin = NextcloudTalkPlugin()
    plugin.enabled = True
    plugin.rooms = {
        "timeout_token": {
            "alias": "timeout_room",
            "allow_tools": True,
            "last_id": 0,
            "api_version": "v2"
        }
    }
    
    send_calls = []
    async def mock_send_message(room_identifier, message):
        send_calls.append({
            "room": room_identifier,
            "message": message,
            "timestamp": asyncio.get_event_loop().time()
        })
        return True
    
    plugin._send_message = mock_send_message
    
    # Mock a slow API response (will timeout)
    async def slow_post(*args, **kwargs):
        await asyncio.sleep(12.0)  # Longer than 10s timeout
        mock_resp = Mock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"response": "Too late response"}
        return mock_resp
    
    with patch('httpx.AsyncClient.post', new_callable=AsyncMock) as mock_post:
        mock_post.side_effect = slow_post
        
        start_time = asyncio.get_event_loop().time()
        await plugin._handle_incoming("timeout_token", "user123", "@hestia slow request")
        
        # Wait for processing
        await asyncio.sleep(0.5)
        
        # Should have at least the [processing…] message
        assert len(send_calls) >= 1, f"FAIL: No timeout messages sent: {send_calls}"
        
        # Check for [processing…] message
        processing_messages = [c for c in send_calls if "[processing…]" in c["message"]]
        assert len(processing_messages) > 0, f"FAIL: No [processing…] message: {send_calls}"
        print(f"  ✓ Intermediate [processing…] message sent after timeout")
        
        # Check timing (should be around 10 seconds, but we can't test exact timing in unit test)
        print(f"  ✓ Timeout handling works (sent {len(send_calls)} messages)")
    
    print("✅ Timeout handling tests passed!")
    return True


async def main():
    """Run all tests."""
    print("=" * 60)
    print("Nextcloud Talk Response Guarantee Verification")
    print("=" * 60)
    
    try:
        await test_mention_guarantees_response()
        await test_timeout_handling()
        
        print("\n" + "=" * 60)
        print("✅ ALL VERIFICATION TESTS PASSED!")
        print("=" * 60)
        print("\nSummary:")
        print("1. @hestia mentions guarantee a response (even if API returns empty)")
        print("2. Fallback message 'Hallo 👋' sent for empty responses")
        print("3. Timeout handling sends [processing…] after 10 seconds")
        print("4. Non-mention messages correctly ignored")
        print("5. Commands (/help) trigger responses")
        
        return 0
        
    except AssertionError as e:
        print(f"\n❌ TEST FAILED: {e}")
        import traceback
        traceback.print_exc()
        return 1
    except Exception as e:
        print(f"\n❌ UNEXPECTED ERROR: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)