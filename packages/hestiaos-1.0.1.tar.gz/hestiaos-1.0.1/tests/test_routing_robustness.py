import asyncio
import json
import pytest
from unittest.mock import MagicMock, AsyncMock

from core.orchestrator import Orchestrator
from tests.conftest import MockBackendRouter
from core.context import ExecutionContext
from enterprise.egl.backend_router import BackendSelection, BackendType

@pytest.mark.asyncio
async def test_multi_agent_fallback_robustness():
    """
    Verifies that Orchestrator correctly falls back to alternate agents
    when the primary selection fails.
    """
    
    # 1. Setup Mocks
    mock_llm = MagicMock()
    mock_context_manager = MagicMock()
    mock_tool_executor = MagicMock()
    
    # Mock context
    mock_context_manager.load_context = AsyncMock(return_value={"chat_history": []})
    mock_context_manager.is_stepwise_enabled = MagicMock(return_value=False)
    
    # Initialize Orchestrator
    orchestrator = Orchestrator(
        llm_engine=mock_llm,
        context_manager=mock_context_manager,
        tool_executor=mock_tool_executor,
        models_config={"expert": {"name": "test-model"}},
        backend_router=MockBackendRouter()
    )
    
    # Mock classifier to recommend multiple agents
    orchestrator.task_classifier.classify = MagicMock()
    orchestrator.task_classifier.get_recommended_agents = MagicMock(return_value=["openclaw_agent", "expert_gpu"])
    
    # Mock BackendClient calls
    execution_record = []

    async def mock_call(selection, messages, tools=None):
        execution_record.append(selection.backend_id)
        if selection.backend_id == "openclaw_agent":
            raise ConnectionError("OpenClaw is down!")
        
        # Expert GPU succeeds
        yield "Fallback success!"

    orchestrator.backend_client.call = mock_call
    
    # 2. Execution
    context = ExecutionContext(session_id="test-session", tenant_id="test-tenant", mode="community")
    tokens = []
    
    async for chunk in orchestrator.process_message("Complex task", context):
        if chunk.startswith("data:"):
            try:
                data = json.loads(chunk[5:].strip())
                if data.get("type") == "token":
                    tokens.append(data["content"])
            except: pass
            
    # 3. Validation
    full_response = "".join(tokens)
    print(f"\nExecution Record: {execution_record}")
    print(f"Captured Response: {full_response}")
    
    # Verify fallback happened
    assert "openclaw_agent" in execution_record
    assert "expert_gpu" in execution_record
    assert "Fallback success!" in full_response
    assert "[Routing to expert_gpu...]" in full_response

if __name__ == "__main__":
    asyncio.run(test_multi_agent_fallback_robustness())
