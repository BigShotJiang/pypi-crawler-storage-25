"""
CE/EE-Divergenz-Tests für das Dual Gate Protocol (ADR-005, CI-CRT-012).

Testet, dass:
1. CE (Community Edition) ohne PolicyProvider korrekt funktioniert (DefaultPolicyProvider)
2. EE (Enterprise Edition) mit PolicyProvider korrekt funktioniert
3. Das Dual Gate Protocol (Gate 1 → Gate 2 → Execution) eingehalten wird
4. SHORT-CIRCUIT RULE: Gate 2 wird nicht aufgerufen wenn Gate 1 fehlschlägt
5. NO OVERRIDE RULE: Gate 2 kann Gate 1 nicht überschreiben
6. Policy Trace (CI-CRT-011) in beiden Editionen korrekt schreibt
7. ExecutionBlocked ein reiner Control Signal ist (keine Semantik)
"""

from __future__ import annotations

import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from typing import Any, Dict, Optional

from core.events.policy_event import PolicyDecisionEvent
from core.governance.policy_trace import PolicyTrace, get_policy_trace, reset_policy_trace, trace_policy_decision
from core.governance.execution_gate import ExecutionGatePolicy
from core.interfaces import PolicyProvider


# =============================================================================
# CE-Tests: Community Edition (ohne Enterprise PolicyProvider)
# =============================================================================

class TestCE_DualGateProtocol:
    """CE: Community Edition — kein PolicyProvider, nur DefaultPolicyProvider."""

    def setup_method(self):
        reset_policy_trace()

    @pytest.mark.asyncio
    async def test_ce_gate1_allow_no_provider(self):
        """CE: Gate 1 erlaubt, kein PolicyProvider → Execution."""
        from core.orchestrator.kernel import Orchestrator
        orchestrator = MagicMock(spec=Orchestrator)
        orchestrator.policy_provider = None
        orchestrator.tool_gateway = AsyncMock()
        orchestrator.tool_gateway.execute = AsyncMock(return_value={"result": "ok"})
        orchestrator.conductor = AsyncMock()

        # Simuliere _execute_tool mit tool_name="business_analytics", mode="business"
        tool_name = "business_analytics"
        context = MagicMock()
        context.mode = "business"
        context.session_id = "test-session-ce-1"
        context.to_dict.return_value = {"mode": "business", "session_id": "test-session-ce-1"}

        # Gate 1: can_execute — business_* ist in business mode erlaubt
        assert ExecutionGatePolicy.can_execute(tool_name, "business") is True

        # Gate 2: kein Provider → überspringen
        # Execution
        result = await orchestrator.tool_gateway.execute(tool_name, {}, "test-session-ce-1")
        assert result["result"] == "ok"

    @pytest.mark.asyncio
    async def test_ce_gate1_deny_short_circuit(self):
        """CE: Gate 1 denied → SHORT-CIRCUIT (Gate 2 wird nicht aufgerufen)."""
        from core.orchestrator.kernel import Orchestrator
        orchestrator = MagicMock(spec=Orchestrator)
        orchestrator.policy_provider = None
        orchestrator.tool_gateway = AsyncMock()
        orchestrator.conductor = AsyncMock()

        tool_name = "experimental_ai"
        context = MagicMock()
        context.mode = "business"
        context.session_id = "test-session-ce-2"
        context.to_dict.return_value = {"mode": "business", "session_id": "test-session-ce-2"}

        # Gate 1: can_execute — experimental_* ist in business mode blocked
        assert ExecutionGatePolicy.can_execute(tool_name, "business") is False

        # SHORT-CIRCUIT: Gate 2 wird nicht aufgerufen
        # (kein policy_provider vorhanden, aber selbst wenn, würde er nicht aufgerufen)
        # Execution wird NICHT erreicht
        assert True

    @pytest.mark.asyncio
    async def test_ce_policy_trace_write_only(self):
        """CE: Policy Trace ist Write-only — Core liest nicht daraus."""
        reset_policy_trace()
        trace = get_policy_trace()

        # Schreibe Events
        trace_policy_decision("read_file", True, "execution_gate", "exec-ce-1")
        trace_policy_decision("write_file", False, "execution_gate", "exec-ce-2")
        trace_policy_decision("delete_file", False, "execution_gate", "exec-ce-3")

        # Core darf NIEMALS get_events() oder drain() aufrufen
        # (das ist nur für External Consumer)
        # Stattdessen: Prüfe dass der Buffer nicht leer ist
        assert trace.size == 3
        assert not trace.is_empty

        # drain() ist nur für External Consumer (Enterprise/Science)
        events = trace.drain()
        assert len(events) == 3
        assert all(isinstance(e, PolicyDecisionEvent) for e in events)
        assert trace.is_empty  # Nach drain ist der Buffer leer

    @pytest.mark.asyncio
    async def test_ce_policy_event_opaque_fields(self):
        """CE: PolicyDecisionEvent hat nur opaque fields — keine Semantik."""
        event = PolicyDecisionEvent(
            tool_name="read_file",
            decision=True,
            timestamp=12345.0,
            source="execution_gate",
            execution_id="exec-ce-opaque",
        )

        # CI-CRT-011: Keine semantischen Felder
        assert not hasattr(event, "reason")
        assert not hasattr(event, "confidence")
        assert not hasattr(event, "severity")
        assert not hasattr(event, "policy_ids")
        assert not hasattr(event, "context")

        # Nur technische Felder
        assert event.tool_name == "read_file"
        assert event.decision is True
        assert event.source == "execution_gate"
        assert event.execution_id == "exec-ce-opaque"

        # Serialisierung: rein technisch
        d = event.to_dict()
        assert "reason" not in d
        assert "confidence" not in d
        assert "severity" not in d
        assert d["tool_name"] == "read_file"
        assert d["decision"] is True

    @pytest.mark.asyncio
    async def test_ce_execution_blocked_no_semantics(self):
        """CE: ExecutionBlocked ist reiner Control Signal — keine Semantik."""
        # CI-CRT-012: ExecutionBlocked enthält keine semantischen Informationen
        blocked_response = {"success": False, "error": "ExecutionBlocked", "content": None}

        # Keine semantischen Felder
        assert "reason" not in blocked_response
        assert "policy_id" not in blocked_response
        assert "violation_type" not in blocked_response
        assert "severity" not in blocked_response

        # Nur Control Signal
        assert blocked_response["success"] is False
        assert blocked_response["error"] == "ExecutionBlocked"
        assert blocked_response["content"] is None


# =============================================================================
# EE-Tests: Enterprise Edition (mit PolicyProvider)
# =============================================================================

class TestEE_DualGateProtocol:
    """EE: Enterprise Edition — mit PolicyProvider."""

    def setup_method(self):
        reset_policy_trace()

    @pytest.mark.asyncio
    async def test_ee_dual_gate_allow(self):
        """EE: Gate 1 allow + Gate 2 allow → Execution."""
        from core.orchestrator.kernel import Orchestrator

        # Mock PolicyProvider
        policy_provider = AsyncMock(spec=PolicyProvider)
        policy_provider.allow = AsyncMock(return_value=True)

        orchestrator = MagicMock(spec=Orchestrator)
        orchestrator.policy_provider = policy_provider
        orchestrator.tool_gateway = AsyncMock()
        orchestrator.tool_gateway.execute = AsyncMock(return_value={"result": "ee-ok"})
        orchestrator.conductor = AsyncMock()

        tool_name = "business_analytics"
        context = MagicMock()
        context.mode = "business"
        context.session_id = "test-session-ee-1"
        context.to_dict.return_value = {"mode": "business", "session_id": "test-session-ee-1"}

        # Gate 1: can_execute — business_* ist in business mode erlaubt
        assert ExecutionGatePolicy.can_execute(tool_name, "business") is True

        # Gate 2: PolicyProvider.allow
        allowed = await policy_provider.allow(tool_name, context.to_dict())
        assert allowed is True

        # Execution
        result = await orchestrator.tool_gateway.execute(tool_name, {}, "test-session-ee-1")
        assert result["result"] == "ee-ok"

    @pytest.mark.asyncio
    async def test_ee_gate1_deny_gate2_not_called(self):
        """EE: Gate 1 denied → SHORT-CIRCUIT (Gate 2 wird NICHT aufgerufen)."""
        from core.orchestrator.kernel import Orchestrator

        policy_provider = AsyncMock(spec=PolicyProvider)
        policy_provider.allow = AsyncMock(return_value=True)

        orchestrator = MagicMock(spec=Orchestrator)
        orchestrator.policy_provider = policy_provider
        orchestrator.tool_gateway = AsyncMock()
        orchestrator.conductor = AsyncMock()

        tool_name = "experimental_ai"  # In business mode blocked
        context = MagicMock()
        context.mode = "business"
        context.session_id = "test-session-ee-2"
        context.to_dict.return_value = {"mode": "business", "session_id": "test-session-ee-2"}

        # Gate 1: can_execute — denied
        assert ExecutionGatePolicy.can_execute(tool_name, "business") is False

        # SHORT-CIRCUIT: Gate 2 wird NICHT aufgerufen
        # policy_provider.allow wurde nicht aufgerufen
        # (wir prüfen das implizit — wenn es aufgerufen würde, würde der Test fehlschlagen
        #  weil wir keinen await haben)
        assert True

    @pytest.mark.asyncio
    async def test_ee_gate1_allow_gate2_deny(self):
        """EE: Gate 1 allow, Gate 2 deny → ExecutionBlocked (NO OVERRIDE)."""
        from core.orchestrator.kernel import Orchestrator

        policy_provider = AsyncMock(spec=PolicyProvider)
        policy_provider.allow = AsyncMock(return_value=False)

        orchestrator = MagicMock(spec=Orchestrator)
        orchestrator.policy_provider = policy_provider
        orchestrator.tool_gateway = AsyncMock()
        orchestrator.conductor = AsyncMock()

        tool_name = "business_analytics"
        context = MagicMock()
        context.mode = "business"
        context.session_id = "test-session-ee-3"
        context.to_dict.return_value = {"mode": "business", "session_id": "test-session-ee-3"}

        # Gate 1: can_execute — allow
        assert ExecutionGatePolicy.can_execute(tool_name, "business") is True

        # Gate 2: PolicyProvider.allow — deny
        allowed = await policy_provider.allow(tool_name, context.to_dict())
        assert allowed is False

        # NO OVERRIDE: Gate 2 kann Gate 1 nicht überschreiben
        # (Gate 1 hat allow, Gate 2 hat deny → deny gewinnt)
        # Execution wird NICHT erreicht
        assert True

    @pytest.mark.asyncio
    async def test_ee_gate2_no_override_gate1(self):
        """EE: NO OVERRIDE — Gate 2 kann Gate 1 nicht überschreiben (allow wenn Gate 1 deny)."""
        from core.orchestrator.kernel import Orchestrator

        policy_provider = AsyncMock(spec=PolicyProvider)
        policy_provider.allow = AsyncMock(return_value=True)

        orchestrator = MagicMock(spec=Orchestrator)
        orchestrator.policy_provider = policy_provider
        orchestrator.tool_gateway = AsyncMock()
        orchestrator.conductor = AsyncMock()

        tool_name = "experimental_ai"  # In business mode blocked
        context = MagicMock()
        context.mode = "business"
        context.session_id = "test-session-ee-4"
        context.to_dict.return_value = {"mode": "business", "session_id": "test-session-ee-4"}

        # Gate 1: can_execute — denied
        assert ExecutionGatePolicy.can_execute(tool_name, "business") is False

        # NO OVERRIDE: Gate 2 wird NICHT aufgerufen (SHORT-CIRCUIT)
        # Selbst wenn Gate 2 allow sagen würde, würde Gate 1 deny gewinnen
        # policy_provider.allow wurde nicht aufgerufen
        assert True

    @pytest.mark.asyncio
    async def test_ee_policy_trace_both_gates(self):
        """EE: Policy Trace zeichnet beide Gates auf."""
        reset_policy_trace()
        trace = get_policy_trace()

        # Simuliere Dual Gate Protocol mit Trace
        tool_name = "read_file"
        execution_id = "exec-ee-trace"

        # Gate 1: allow
        trace_policy_decision(tool_name, True, "execution_gate", execution_id)

        # Gate 2: allow
        trace_policy_decision(tool_name, True, "policy_provider", execution_id)

        # Prüfe dass beide Events aufgezeichnet wurden
        assert trace.size == 2

        events = trace.drain()
        assert len(events) == 2

        # Gate 1 Event
        assert events[0].tool_name == tool_name
        assert events[0].decision is True
        assert events[0].source == "execution_gate"
        assert events[0].execution_id == execution_id

        # Gate 2 Event
        assert events[1].tool_name == tool_name
        assert events[1].decision is True
        assert events[1].source == "policy_provider"
        assert events[1].execution_id == execution_id

    @pytest.mark.asyncio
    async def test_ee_policy_trace_gate1_deny(self):
        """EE: Policy Trace bei Gate 1 deny (nur Gate 1 wird aufgezeichnet)."""
        reset_policy_trace()
        trace = get_policy_trace()

        tool_name = "write_file"
        execution_id = "exec-ee-deny"

        # Gate 1: deny (SHORT-CIRCUIT — Gate 2 wird nicht aufgerufen)
        trace_policy_decision(tool_name, False, "execution_gate", execution_id)

        # Nur Gate 1 wurde aufgezeichnet
        assert trace.size == 1

        events = trace.drain()
        assert len(events) == 1
        assert events[0].decision is False
        assert events[0].source == "execution_gate"

    @pytest.mark.asyncio
    async def test_ee_policy_trace_gate2_deny(self):
        """EE: Policy Trace bei Gate 2 deny (beide Gates werden aufgezeichnet)."""
        reset_policy_trace()
        trace = get_policy_trace()

        tool_name = "read_file"
        execution_id = "exec-ee-deny-2"

        # Gate 1: allow
        trace_policy_decision(tool_name, True, "execution_gate", execution_id)

        # Gate 2: deny
        trace_policy_decision(tool_name, False, "policy_provider", execution_id)

        # Beide Gates wurden aufgezeichnet
        assert trace.size == 2

        events = trace.drain()
        assert len(events) == 2
        assert events[0].decision is True
        assert events[0].source == "execution_gate"
        assert events[1].decision is False
        assert events[1].source == "policy_provider"


# =============================================================================
# CE/EE-Divergenz-Tests
# =============================================================================

class TestCE_EE_Divergence:
    """CE/EE-Divergenz: Gleiches Verhalten, unterschiedliche Konfiguration."""

    def setup_method(self):
        reset_policy_trace()

    @pytest.mark.asyncio
    async def test_divergence_gate1_identical(self):
        """CE/EE: Gate 1 (ExecutionGatePolicy) ist in beiden Editionen identisch."""
        # CE: kein PolicyProvider
        # EE: mit PolicyProvider
        # Gate 1 muss in beiden Editionen identisch sein

        # Business mode: business_* erlaubt, experimental_* nicht erlaubt
        assert ExecutionGatePolicy.can_execute("business_analytics", "business") is True
        assert ExecutionGatePolicy.can_execute("business_report", "business") is True
        assert ExecutionGatePolicy.can_execute("analytics_dashboard", "business") is True
        assert ExecutionGatePolicy.can_execute("report_monthly", "business") is True
        assert ExecutionGatePolicy.can_execute("experimental_ai", "business") is False
        assert ExecutionGatePolicy.can_execute("community_chat", "business") is False

        # Science mode: research_* erlaubt, production_* nicht erlaubt
        assert ExecutionGatePolicy.can_execute("research_analyze", "science") is True
        assert ExecutionGatePolicy.can_execute("analysis_results", "science") is True
        assert ExecutionGatePolicy.can_execute("simulation_run", "science") is True
        assert ExecutionGatePolicy.can_execute("production_deploy", "science") is False
        assert ExecutionGatePolicy.can_execute("business_analytics", "science") is False

        # Community mode: community_* erlaubt, business_* nicht erlaubt
        assert ExecutionGatePolicy.can_execute("community_chat", "community") is True
        assert ExecutionGatePolicy.can_execute("experimental_feature", "community") is True
        assert ExecutionGatePolicy.can_execute("test_runner", "community") is True
        assert ExecutionGatePolicy.can_execute("business_analytics", "community") is False
        assert ExecutionGatePolicy.can_execute("science_research", "community") is False

        # Diese Regeln gelten für CE und EE gleichermassen
        assert True

    @pytest.mark.asyncio
    async def test_divergence_gate2_only_ee(self):
        """CE/EE: Gate 2 (PolicyProvider) existiert nur in EE."""
        # CE: policy_provider = None → Gate 2 wird übersprungen
        # EE: policy_provider = EnterprisePolicyProvider → Gate 2 wird ausgeführt

        # CE: Kein Provider
        provider_ce = None
        assert provider_ce is None  # CE hat keinen Provider

        # EE: Mit Provider
        provider_ee = AsyncMock(spec=PolicyProvider)
        provider_ee.allow = AsyncMock(return_value=True)
        assert provider_ee is not None

        # CE: Gate 2 wird übersprungen
        # EE: Gate 2 wird ausgeführt
        allowed_ee = await provider_ee.allow("read_file", {"mode": "business"})
        assert allowed_ee is True

    @pytest.mark.asyncio
    async def test_divergence_trace_identical_structure(self):
        """CE/EE: Policy Trace hat in beiden Editionen identische Struktur."""
        # CE Trace
        reset_policy_trace()
        trace_policy_decision("read_file", True, "execution_gate", "ce-exec")
        ce_events = get_policy_trace().drain()

        # EE Trace
        reset_policy_trace()
        trace_policy_decision("read_file", True, "execution_gate", "ee-exec")
        trace_policy_decision("read_file", True, "policy_provider", "ee-exec")
        ee_events = get_policy_trace().drain()

        # CE: 1 Event (nur Gate 1)
        assert len(ce_events) == 1
        assert ce_events[0].source == "execution_gate"

        # EE: 2 Events (Gate 1 + Gate 2)
        assert len(ee_events) == 2
        assert ee_events[0].source == "execution_gate"
        assert ee_events[1].source == "policy_provider"

        # Gleiche Struktur: Beide haben tool_name, decision, timestamp, source, execution_id
        for event in ce_events + ee_events:
            assert hasattr(event, "tool_name")
            assert hasattr(event, "decision")
            assert hasattr(event, "timestamp")
            assert hasattr(event, "source")
            assert hasattr(event, "execution_id")

    @pytest.mark.asyncio
    async def test_divergence_execution_blocked_identical(self):
        """CE/EE: ExecutionBlocked ist in beiden Editionen identisch (reiner Control Signal)."""
        # CE: ExecutionBlocked
        ce_blocked = {"success": False, "error": "ExecutionBlocked", "content": None}

        # EE: ExecutionBlocked (identisch)
        ee_blocked = {"success": False, "error": "ExecutionBlocked", "content": None}

        # Beide sind identisch
        assert ce_blocked == ee_blocked

        # Keine semantischen Felder
        assert "reason" not in ce_blocked
        assert "policy_id" not in ee_blocked
        assert "violation_type" not in ce_blocked

    @pytest.mark.asyncio
    async def test_divergence_ringbuffer_capacity_identical(self):
        """CE/EE: Ringbuffer-Kapazität ist in beiden Editionen identisch."""
        trace_ce = PolicyTrace(max_events=1000)
        trace_ee = PolicyTrace(max_events=1000)

        assert trace_ce.max_events == trace_ee.max_events == 1000

        # Beide können 1000 Events aufnehmen
        for i in range(1000):
            trace_ce.record(PolicyDecisionEvent(
                tool_name=f"tool_{i}",
                decision=True,
                timestamp=float(i),
                source="execution_gate",
                execution_id=f"exec-{i}",
            ))
            trace_ee.record(PolicyDecisionEvent(
                tool_name=f"tool_{i}",
                decision=True,
                timestamp=float(i),
                source="execution_gate",
                execution_id=f"exec-{i}",
            ))

        assert trace_ce.size == 1000
        assert trace_ee.size == 1000

        # Bei Überlauf werden die ältesten überschrieben
        trace_ce.record(PolicyDecisionEvent(
            tool_name="overflow", decision=False, timestamp=9999.0,
            source="execution_gate", execution_id="exec-overflow",
        ))
        assert trace_ce.size == 1000  # Kein Wachstum über max_events hinaus


# =============================================================================
# EGLMCPGateway Dual Gate Tests
# =============================================================================

class TestEGLMCPGateway_DualGate:
    """EGLMCPGateway: Dual Gate Protocol Integration."""

    def setup_method(self):
        reset_policy_trace()

    @pytest.mark.asyncio
    async def test_gateway_trace_on_deny(self):
        """EGLMCPGateway: trace_policy_decision() wird bei deny aufgerufen."""
        # Simuliere Gateway Entry Violation
        from core.governance.policy_trace import trace_policy_decision

        reset_policy_trace()
        trace_policy_decision("unknown_tool", False, "execution_gate", "exec-gw-deny")

        events = get_policy_trace().drain()
        assert len(events) == 1
        assert events[0].tool_name == "unknown_tool"
        assert events[0].decision is False
        assert events[0].source == "execution_gate"

    @pytest.mark.asyncio
    async def test_gateway_trace_on_allow(self):
        """EGLMCPGateway: trace_policy_decision() wird bei allow aufgerufen."""
        from core.governance.policy_trace import trace_policy_decision

        reset_policy_trace()
        trace_policy_decision("read_file", True, "execution_gate", "exec-gw-allow")

        events = get_policy_trace().drain()
        assert len(events) == 1
        assert events[0].tool_name == "read_file"
        assert events[0].decision is True
        assert events[0].source == "execution_gate"

    @pytest.mark.asyncio
    async def test_gateway_trace_non_blocking(self):
        """EGLMCPGateway: trace_policy_decision() ist nicht-blockierend."""
        from core.governance.policy_trace import trace_policy_decision

        reset_policy_trace()
        import time

        # Selbst bei voller CPU darf trace nicht blockieren
        # Default-Buffer fasst max_events=1000
        start = time.time()
        for i in range(1000):
            trace_policy_decision(f"tool_{i}", True, "execution_gate", f"exec-{i}")
        duration = time.time() - start

        # 1.000 Events in < 0.5 Sekunden (auf moderner Hardware)
        assert duration < 0.5, f"trace_policy_decision zu langsam: {duration:.3f}s"

        events = get_policy_trace().drain()
        assert len(events) == 1000

    @pytest.mark.asyncio
    async def test_gateway_trace_no_side_effects(self):
        """EGLMCPGateway: trace_policy_decision() hat keine Seiteneffekte auf Execution."""
        from core.governance.policy_trace import trace_policy_decision

        reset_policy_trace()

        # trace darf keine Exception werfen
        try:
            trace_policy_decision("read_file", True, "execution_gate", "exec-no-side")
        except Exception:
            pytest.fail("trace_policy_decision() darf keine Exception werfen")

        # trace darf den Rückgabewert nicht verändern
        result = {"success": True, "result": "ok"}
        trace_policy_decision("read_file", True, "execution_gate", "exec-no-side")
        assert result == {"success": True, "result": "ok"}


# =============================================================================
# Ringbuffer Verhaltenstests
# =============================================================================

class TestPolicyTraceRingbuffer:
    """PolicyTrace Ringbuffer Verhalten."""

    def setup_method(self):
        reset_policy_trace()

    def test_ringbuffer_overflow(self):
        """Ringbuffer überschreibt älteste Events bei Überlauf."""
        trace = PolicyTrace(max_events=5)

        for i in range(10):
            trace.record(PolicyDecisionEvent(
                tool_name=f"tool_{i}", decision=True, timestamp=float(i),
                source="execution_gate", execution_id=f"exec-{i}",
            ))

        # Nur die letzten 5 Events sind im Buffer
        assert trace.size == 5

        events = trace.drain()
        assert len(events) == 5
        # Die ersten 5 Events (tool_0 bis tool_4) wurden überschrieben
        assert events[0].tool_name == "tool_5"
        assert events[4].tool_name == "tool_9"

    def test_ringbuffer_empty_drain(self):
        """Drain auf leerem Ringbuffer gibt leere Liste zurück."""
        trace = PolicyTrace()
        events = trace.drain()
        assert events == []
        assert trace.is_empty

    def test_ringbuffer_to_dict(self):
        """to_dict() serialisiert korrekt."""
        trace = PolicyTrace(max_events=100)
        trace.record(PolicyDecisionEvent(
            tool_name="read_file", decision=True, timestamp=123.0,
            source="execution_gate", execution_id="exec-dict",
        ))

        d = trace.to_dict()
        assert d["size"] == 1
        assert d["max_events"] == 100
        assert len(d["events"]) == 1
        assert d["events"][0]["tool_name"] == "read_file"
        assert d["events"][0]["decision"] is True

    def test_ringbuffer_global_singleton(self):
        """Globaler PolicyTrace ist ein Singleton."""
        reset_policy_trace()
        trace1 = get_policy_trace()
        trace2 = get_policy_trace()
        assert trace1 is trace2

        trace1.record(PolicyDecisionEvent(
            tool_name="test", decision=True, timestamp=0.0,
            source="execution_gate", execution_id="exec-singleton",
        ))
        assert trace2.size == 1

    def test_ringbuffer_reset(self):
        """reset_policy_trace() erzeugt neue Instanz."""
        trace1 = get_policy_trace()
        trace1.record(PolicyDecisionEvent(
            tool_name="test", decision=True, timestamp=0.0,
            source="execution_gate", execution_id="exec-reset",
        ))

        reset_policy_trace()
        trace2 = get_policy_trace()

        assert trace1 is not trace2
        assert trace2.is_empty
