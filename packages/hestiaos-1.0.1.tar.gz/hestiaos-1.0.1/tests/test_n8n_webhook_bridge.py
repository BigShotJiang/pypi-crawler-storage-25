"""
Tests für die n8n Webhook Bridge.

Testet:
    - Event Contract (4 Standard-Events)
    - Event Envelope (einheitliches Payload-Format)
    - Payload-Factory-Funktionen
    - N8NWebhookBridge (Installation, Event-Handling, Fire-and-Forget)
    - Idempotency (event_id UUID)
    - Fehlerisolation (n8n down → Core bleibt stabil)
"""

import pytest
import uuid
import json
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch

from core.integration.n8n.webhook_bridge import (
    N8NWebhookBridge,
    N8NEventType,
    create_envelope,
    artifact_created_payload,
    violation_emitted_payload,
    decision_made_payload,
    transformation_completed_payload,
)


# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def mock_event_bus():
    """Ein gemockter Event Bus mit subscribe/publish."""
    bus = MagicMock()
    bus.subscribe = AsyncMock()
    bus.unsubscribe = MagicMock()
    bus.publish = AsyncMock()
    return bus


@pytest.fixture
def webhook_url():
    return "http://localhost:5678/webhook/hestia"


@pytest.fixture
def bridge(mock_event_bus, webhook_url):
    return N8NWebhookBridge(
        webhook_url=webhook_url,
        event_bus=mock_event_bus,
        timeout=1,
    )


# =============================================================================
# Tests: Event Contract
# =============================================================================


class TestN8NEventType:
    """Tests für den Event Contract."""

    def test_all_returns_four_events(self):
        """Es gibt genau 4 Standard-Events."""
        events = N8NEventType.all()
        assert len(events) == 4
        assert N8NEventType.ARTIFACT_CREATED in events
        assert N8NEventType.VIOLATION_EMITTED in events
        assert N8NEventType.DECISION_MADE in events
        assert N8NEventType.TRANSFORMATION_COMPLETED in events

    def test_event_names_are_strings(self):
        """Event-Namen sind lesbare Strings."""
        assert N8NEventType.ARTIFACT_CREATED == "artifact_created"
        assert N8NEventType.VIOLATION_EMITTED == "violation_emitted"
        assert N8NEventType.DECISION_MADE == "decision_made"
        assert N8NEventType.TRANSFORMATION_COMPLETED == "transformation_completed"


# =============================================================================
# Tests: Event Envelope
# =============================================================================


class TestCreateEnvelope:
    """Tests für den einheitlichen Event-Envelope."""

    def test_envelope_has_required_fields(self):
        """Envelope enthält alle Pflichtfelder."""
        envelope = create_envelope(
            event_type="artifact_created",
            artifact_id="art_001",
            payload={"key": "value"},
        )

        assert "event_type" in envelope
        assert "event_id" in envelope
        assert "timestamp" in envelope
        assert "artifact_id" in envelope
        assert "correlation_id" in envelope
        assert "payload" in envelope

    def test_envelope_event_id_is_uuid(self):
        """event_id ist ein gültiges UUID."""
        envelope = create_envelope(
            event_type="artifact_created",
            artifact_id="art_001",
            payload={},
        )

        # Sollte kein Fehler sein
        uuid.UUID(envelope["event_id"])

    def test_envelope_timestamp_is_iso8601(self):
        """timestamp ist ISO-8601."""
        envelope = create_envelope(
            event_type="artifact_created",
            artifact_id="art_001",
            payload={},
        )

        # Sollte parsed werden können
        datetime.fromisoformat(envelope["timestamp"])

    def test_envelope_with_correlation_id(self):
        """correlation_id wird korrekt gesetzt."""
        envelope = create_envelope(
            event_type="artifact_created",
            artifact_id="art_001",
            payload={},
            correlation_id="chain_123",
        )

        assert envelope["correlation_id"] == "chain_123"

    def test_envelope_without_correlation_id(self):
        """Ohne correlation_id ist es ein leerer String."""
        envelope = create_envelope(
            event_type="artifact_created",
            artifact_id="art_001",
            payload={},
        )

        assert envelope["correlation_id"] == ""

    def test_envelope_payload_is_preserved(self):
        """Payload wird unverändert übernommen."""
        payload = {"artifact_type": "idea", "title": "Test"}
        envelope = create_envelope(
            event_type="artifact_created",
            artifact_id="art_001",
            payload=payload,
        )

        assert envelope["payload"] == payload


# =============================================================================
# Tests: Payload Factories
# =============================================================================


class TestPayloadFactories:
    """Tests für die Payload-Factory-Funktionen."""

    def test_artifact_created_payload(self):
        """artifact_created Payload hat alle Felder."""
        payload = artifact_created_payload(
            artifact_id="art_001",
            artifact_type="idea",
            title="Meine Idee",
            status="draft",
            source="cli",
        )

        assert payload["artifact_type"] == "idea"
        assert payload["title"] == "Meine Idee"
        assert payload["status"] == "draft"
        assert payload["source"] == "cli"

    def test_artifact_created_payload_extra(self):
        """Extra-Felder werden durchgereicht."""
        payload = artifact_created_payload(
            artifact_id="art_001",
            artifact_type="idea",
            title="Test",
            status="draft",
            tags=["ai", "test"],
        )

        assert payload["tags"] == ["ai", "test"]

    def test_violation_emitted_payload(self):
        """violation_emitted Payload hat alle Felder."""
        payload = violation_emitted_payload(
            artifact_id="art_001",
            violation_type="policy_reject",
            reason="Nicht autorisiert",
            severity="critical",
        )

        assert payload["violation_type"] == "policy_reject"
        assert payload["reason"] == "Nicht autorisiert"
        assert payload["severity"] == "critical"

    def test_violation_emitted_default_severity(self):
        """Default severity ist 'warning'."""
        payload = violation_emitted_payload(
            artifact_id="art_001",
            violation_type="policy_reject",
            reason="Test",
        )

        assert payload["severity"] == "warning"

    def test_decision_made_payload(self):
        """decision_made Payload hat alle Felder."""
        payload = decision_made_payload(
            artifact_id="art_001",
            decision="Python + FastAPI",
            rationale="Beste Performance",
        )

        assert payload["decision"] == "Python + FastAPI"
        assert payload["rationale"] == "Beste Performance"

    def test_transformation_completed_payload(self):
        """transformation_completed Payload hat alle Felder."""
        payload = transformation_completed_payload(
            artifact_id="art_001",
            transformation_name="idea_to_spec",
            result_type="spec",
            success=True,
        )

        assert payload["transformation_name"] == "idea_to_spec"
        assert payload["result_type"] == "spec"
        assert payload["success"] is True


# =============================================================================
# Tests: N8NWebhookBridge
# =============================================================================


class TestN8NWebhookBridge:
    """Tests für die Webhook Bridge."""

    @pytest.mark.asyncio
    async def test_install_subscribes_to_all_events(self, bridge, mock_event_bus):
        """install() subscribed mit subscriber_id, event_types und callback."""
        await bridge.install()

        mock_event_bus.subscribe.assert_called_once()
        call_kwargs = mock_event_bus.subscribe.call_args[1]
        assert call_kwargs["subscriber_id"] == "n8n_webhook_bridge"
        assert call_kwargs["event_types"] == N8NEventType.all()
        assert callable(call_kwargs["callback"])

    @pytest.mark.asyncio
    async def test_install_sets_installed_flag(self, bridge):
        """install() setzt installed-Flag."""
        assert not bridge.is_installed
        await bridge.install()
        assert bridge.is_installed

    @pytest.mark.asyncio
    async def test_install_idempotent(self, bridge, mock_event_bus):
        """Mehrfaches install() subscribed nur einmal."""
        await bridge.install()
        await bridge.install()

        # Zweiter Aufruf wird wegen _installed-Flag ignoriert
        mock_event_bus.subscribe.assert_called_once()

    @pytest.mark.asyncio
    async def test_uninstall_removes_subscriptions(self, bridge, mock_event_bus):
        """uninstall() entfernt alle Subscriptions."""
        await bridge.install()
        bridge.uninstall()

        assert mock_event_bus.unsubscribe.call_count == 4
        assert not bridge.is_installed

    def test_uninstall_without_install(self, bridge, mock_event_bus):
        """uninstall() ohne vorheriges install() ist safe."""
        bridge.uninstall()
        assert mock_event_bus.unsubscribe.call_count == 0

    @pytest.mark.asyncio
    async def test_handle_event_creates_envelope(self, bridge):
        """_handle_event() erzeugt einen korrekten Envelope."""
        with patch.object(bridge, "_send", AsyncMock()) as mock_send:
            payload = {
                "event_type": "artifact_created",
                "artifact_id": "art_001",
                "correlation_id": "chain_123",
                "payload": {"artifact_type": "idea", "title": "Test"},
            }

            await bridge._handle_event(payload)

            mock_send.assert_called_once()
            envelope = mock_send.call_args[0][0]

            assert envelope["event_type"] == "artifact_created"
            assert envelope["artifact_id"] == "art_001"
            assert envelope["correlation_id"] == "chain_123"
            assert envelope["payload"]["artifact_type"] == "idea"

    @pytest.mark.asyncio
    async def test_handle_event_without_correlation(self, bridge):
        """_handle_event() ohne correlation_id."""
        with patch.object(bridge, "_send", AsyncMock()) as mock_send:
            payload = {
                "event_type": "artifact_created",
                "artifact_id": "art_001",
                "payload": {},
            }

            await bridge._handle_event(payload)

            envelope = mock_send.call_args[0][0]
            assert envelope["correlation_id"] == ""

    @pytest.mark.asyncio
    async def test_send_success(self, bridge):
        """_send() bei erfolgreichem HTTP-POST."""
        with patch("aiohttp.ClientSession") as mock_session_cls:
            # aiohttp.ClientSession is an async context manager.
            # __aenter__ returns the session itself.
            mock_session = MagicMock()
            mock_session_cls.return_value.__aenter__ = AsyncMock(
                return_value=mock_session
            )
            mock_session_cls.return_value.__aexit__ = AsyncMock(return_value=None)

            # session.post() returns an async response context manager
            mock_response = MagicMock()
            mock_response.status = 200
            mock_response.__aenter__ = AsyncMock(return_value=mock_response)
            mock_response.__aexit__ = AsyncMock(return_value=None)

            mock_session.post.return_value = mock_response

            envelope = create_envelope(
                event_type="artifact_created",
                artifact_id="art_001",
                payload={},
            )

            await bridge._send(envelope)

            mock_session.post.assert_called_once_with(
                bridge.webhook_url,
                json=envelope,
                headers={
                    "Content-Type": "application/json",
                    "X-Event-ID": envelope["event_id"],
                },
            )

    @pytest.mark.asyncio
    async def test_send_non_200_logged_not_raised(self, bridge):
        """Nicht-200 Status wird geloggt, nicht propagiert."""
        with patch("aiohttp.ClientSession") as mock_session_cls:
            mock_session = MagicMock()
            mock_session_cls.return_value.__aenter__ = AsyncMock(
                return_value=mock_session
            )
            mock_session_cls.return_value.__aexit__ = AsyncMock(return_value=None)

            mock_response = MagicMock()
            mock_response.status = 500
            mock_response.__aenter__ = AsyncMock(return_value=mock_response)
            mock_response.__aexit__ = AsyncMock(return_value=None)

            mock_session.post.return_value = mock_response

            envelope = create_envelope(
                event_type="artifact_created",
                artifact_id="art_001",
                payload={},
            )

            # Sollte keine Exception werfen
            await bridge._send(envelope)

    @pytest.mark.asyncio
    async def test_send_connection_error_logged_not_raised(self, bridge):
        """Connection-Error wird geloggt, nicht propagiert."""
        with patch("aiohttp.ClientSession") as mock_session_cls:
            mock_session = MagicMock()
            mock_session_cls.return_value.__aenter__ = AsyncMock(
                return_value=mock_session
            )
            mock_session_cls.return_value.__aexit__ = AsyncMock(return_value=None)
            mock_session.post.side_effect = Exception("Connection refused")

            envelope = create_envelope(
                event_type="artifact_created",
                artifact_id="art_001",
                payload={},
            )

            # Sollte keine Exception werfen (fire-and-forget)
            await bridge._send(envelope)

    @pytest.mark.asyncio
    async def test_send_missing_aiohttp(self, bridge):
        """Fehlendes aiohttp wird geloggt, nicht propagiert."""
        with patch.dict("sys.modules", {"aiohttp": None}):
            with patch("builtins.__import__", side_effect=ImportError):
                envelope = create_envelope(
                    event_type="artifact_created",
                    artifact_id="art_001",
                    payload={},
                )

                # Sollte keine Exception werfen
                await bridge._send(envelope)

    # ------------------------------------------------------------------
    # Tests: Manuelle Event-Trigger
    # ------------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_emit_artifact_created(self, bridge, mock_event_bus):
        """emit_artifact_created published das richtige Event."""
        await bridge.emit_artifact_created(
            artifact_id="art_001",
            artifact_type="idea",
            title="Test",
            status="draft",
            source="cli",
            correlation_id="chain_123",
        )

        mock_event_bus.publish.assert_called_once()
        call_args = mock_event_bus.publish.call_args[0]
        assert call_args[0] == "artifact_created"
        assert call_args[1]["artifact_id"] == "art_001"
        assert call_args[1]["correlation_id"] == "chain_123"

    @pytest.mark.asyncio
    async def test_emit_violation(self, bridge, mock_event_bus):
        """emit_violation published das richtige Event."""
        await bridge.emit_violation(
            artifact_id="art_001",
            violation_type="policy_reject",
            reason="Nicht autorisiert",
            severity="critical",
        )

        mock_event_bus.publish.assert_called_once()
        call_args = mock_event_bus.publish.call_args[0]
        assert call_args[0] == "violation_emitted"

    @pytest.mark.asyncio
    async def test_emit_decision(self, bridge, mock_event_bus):
        """emit_decision published das richtige Event."""
        await bridge.emit_decision(
            artifact_id="art_001",
            decision="Python + FastAPI",
            rationale="Beste Performance",
        )

        mock_event_bus.publish.assert_called_once()
        call_args = mock_event_bus.publish.call_args[0]
        assert call_args[0] == "decision_made"

    @pytest.mark.asyncio
    async def test_emit_transformation(self, bridge, mock_event_bus):
        """emit_transformation published das richtige Event."""
        await bridge.emit_transformation(
            artifact_id="art_001",
            transformation_name="idea_to_spec",
            result_type="spec",
            success=True,
        )

        mock_event_bus.publish.assert_called_once()
        call_args = mock_event_bus.publish.call_args[0]
        assert call_args[0] == "transformation_completed"

    # ------------------------------------------------------------------
    # Tests: Integration (Event Bus → Bridge → Webhook)
    # ------------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_full_event_flow(self, bridge, mock_event_bus):
        """Vollständiger Event-Flow: Bridge installed, Event published, Webhook called."""
        with patch.object(bridge, "_send", AsyncMock()) as mock_send:
            await bridge.install()

            # Simuliere, dass der Event Bus den Handler aufruft
            payload = {
                "event_type": "artifact_created",
                "artifact_id": "art_001",
                "payload": {"artifact_type": "idea", "title": "Test"},
            }
            await bridge._handle_event(payload)

            mock_send.assert_called_once()

    @pytest.mark.asyncio
    async def test_core_stable_when_n8n_down(self, bridge):
        """Wenn n8n down ist, bleibt der Core stabil."""
        # Simuliere n8n down
        with patch("aiohttp.ClientSession") as mock_session_cls:
            mock_session = MagicMock()
            mock_session_cls.return_value.__aenter__ = AsyncMock(
                return_value=mock_session
            )
            mock_session_cls.return_value.__aexit__ = AsyncMock(return_value=None)
            mock_session.post.side_effect = Exception("Connection refused")

            envelope = create_envelope(
                event_type="artifact_created",
                artifact_id="art_001",
                payload={},
            )

            # Sollte KEINE Exception werfen
            await bridge._send(envelope)

    def test_webhook_url_strips_trailing_slash(self, mock_event_bus):
        """Trailing Slash wird entfernt."""
        bridge = N8NWebhookBridge(
            webhook_url="http://localhost:5678/webhook/hestia/",
            event_bus=mock_event_bus,
        )

        assert bridge.webhook_url == "http://localhost:5678/webhook/hestia"
