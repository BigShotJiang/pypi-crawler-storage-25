import asyncio
import unittest
from datetime import datetime
from core.observability.consciousness_metrics import ConsciousnessMetricsCollector
from core.consciousness_enterprise_integration import (
    ConsciousnessEnterpriseManager, 
    IntegrationConfig, 
    IntegrationType, 
    IntegrationStatus
)

class TestEnterpriseExport(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.metrics = ConsciousnessMetricsCollector(agent_id="test_agent")
        self.manager = ConsciousnessEnterpriseManager(agent_id="test_agent", metrics_collector=self.metrics)

    async def test_configuration_and_health(self):
        config = IntegrationConfig(
            type=IntegrationType.MONITORING,
            endpoint="http://localhost:9090",
            interval_seconds=1
        )
        self.manager.configure_integration(config)
        self.assertEqual(len(self.manager.integrations), 1)
        
        # Test health check simulation
        await self.manager._check_health(IntegrationType.MONITORING, config)
        status = self.manager.status_reports[IntegrationType.MONITORING]
        # In simulation, it can be CONNECTED or DEGRADED based on random.random()
        self.assertIn(status.status, [IntegrationStatus.CONNECTED, IntegrationStatus.DEGRADED])
        self.assertGreaterEqual(status.latency_ms, 0)
        self.assertIsNotNone(status.last_check)

    async def test_export_logic(self):
        config = IntegrationConfig(
            type=IntegrationType.MONITORING,
            endpoint="http://localhost:9090"
        )
        self.manager.configure_integration(config)
        # Record a metric to ensure there's data
        self.metrics.record_value("awareness_level", 4.2)
        
        success = await self.manager.export_consciousness_metrics(IntegrationType.MONITORING)
        self.assertTrue(success)

    async def test_manager_lifecycle(self):
        config = IntegrationConfig(
            type=IntegrationType.LOGGING,
            endpoint="http://localhost:8080",
            interval_seconds=0.1
        )
        self.manager.configure_integration(config)
        
        # Start manager
        await self.manager.start()
        self.assertTrue(self.manager._running)
        self.assertEqual(len(self.manager._tasks), 1)
        
        # Wait for at least one loop
        await asyncio.sleep(0.2)
        
        # Stop manager
        await self.manager.stop()
        self.assertFalse(self.manager._running)
        self.assertEqual(len(self.manager._tasks), 0)

if __name__ == '__main__':
    unittest.main()
