"""
Tests for Invariant Canon Consumers.

Covers:
  - Policy Registry Consumer: IR → PolicyRegistry registration
  - Self-Test Consumer: IR → test specs, coverage validation
  - CI Drift Consumer: IR → drift scanner config (integration)
"""

import os
import sys
import pytest
from typing import Dict, Any, List

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from core.invariants.consumers.policy_registry import (
    _make_policy_function,
    get_ir_policy_summary,
)
from core.invariants.consumers.self_test import (
    get_test_specs,
    get_suite_config,
    validate_test_coverage,
    get_ir_test_summary,
)
from core.invariants.consumers.ci_drift import get_drift_config
from core.invariants.ir import PolicyNode, PredicateAST, CanonIR


# =========================================================================
# 1. Policy Registry Consumer Tests
# =========================================================================

class TestPolicyRegistryConsumer:
    """Verify that the Policy Registry consumer generates correct policies."""

    def test_make_policy_function_returns_callable(self):
        """_make_policy_function should return a callable."""
        node = PolicyNode(
            id="pol.test.1",
            name="Test Policy",
            type="security",
            severity="fatal",
            description="A test policy",
            condition=PredicateAST(op="EQ", key="action", value="write"),
        )
        fn = _make_policy_function(node)
        assert callable(fn)
        assert fn.__name__.startswith("ir_policy_")

    def test_make_policy_function_evaluates_correctly(self):
        """The generated function should evaluate the predicate correctly."""
        node = PolicyNode(
            id="pol.test.2",
            name="Test Policy",
            type="security",
            severity="fatal",
            description="Deny write actions",
            condition=PredicateAST(op="EQ", key="action", value="write"),
        )
        fn = _make_policy_function(node)
        assert fn({"action": "write"}) is True
        assert fn({"action": "read"}) is False

    def test_make_policy_function_complex_condition(self):
        """Complex nested predicates should work in generated functions."""
        node = PolicyNode(
            id="pol.test.3",
            name="Complex Policy",
            type="security",
            severity="fatal",
            description="Complex condition",
            condition=PredicateAST(
                op="AND",
                args=[
                    PredicateAST(op="EQ", key="role", value="admin"),
                    PredicateAST(op="NOT", args=[
                        PredicateAST(op="EQ", key="action", value="delete")
                    ]),
                ]
            ),
        )
        fn = _make_policy_function(node)
        assert fn({"role": "admin", "action": "write"}) is True
        assert fn({"role": "admin", "action": "delete"}) is False
        assert fn({"role": "user", "action": "write"}) is False

    def test_make_policy_function_fails_closed(self):
        """If evaluation raises, the function should return False (fail closed)."""
        node = PolicyNode(
            id="pol.test.4",
            name="Failing Policy",
            type="security",
            severity="fatal",
            description="Policy with broken condition",
            condition=PredicateAST(op="UNKNOWN_OP"),
        )
        fn = _make_policy_function(node)
        # Should return False instead of crashing
        assert fn({}) is False

    def test_get_ir_policy_summary_returns_list(self):
        """get_ir_policy_summary should return a list of policy dicts."""
        summary = get_ir_policy_summary()
        assert isinstance(summary, list)
        if summary:
            entry = summary[0]
            assert "id" in entry
            assert "type" in entry
            assert "severity" in entry
            assert "source" in entry
            assert entry["source"] == "invariant_canon"


# =========================================================================
# 2. Self-Test Consumer Tests
# =========================================================================

class TestSelfTestConsumer:
    """Verify that the Self-Test consumer generates correct test specs."""

    def test_get_test_specs_returns_list(self):
        """get_test_specs should return a list of test spec dicts."""
        specs = get_test_specs()
        assert isinstance(specs, list)
        if specs:
            entry = specs[0]
            assert "id" in entry
            assert "suite" in entry
            assert "name" in entry

    def test_get_suite_config_existing(self):
        """get_suite_config should return config for existing suites."""
        config = get_suite_config("memory")
        if config is not None:
            assert config["name"] == "memory"
            assert config["test_count"] > 0
            assert len(config["tests"]) == config["test_count"]

    def test_get_suite_config_nonexistent(self):
        """get_suite_config should return None for unknown suites."""
        config = get_suite_config("nonexistent_suite_xyz")
        assert config is None

    def test_validate_test_coverage_returns_report(self):
        """validate_test_coverage should return a coverage report."""
        report = validate_test_coverage()
        assert "total_specs" in report
        assert "implemented" in report
        assert "missing" in report
        assert "coverage_pct" in report
        assert 0 <= report["coverage_pct"] <= 100

    def test_get_ir_test_summary_returns_summary(self):
        """get_ir_test_summary should return a complete summary."""
        summary = get_ir_test_summary()
        assert "total_tests" in summary
        assert "suites" in summary
        assert "coverage" in summary


# =========================================================================
# 3. CI Drift Consumer Integration Tests
# =========================================================================

class TestCIDriftConsumerIntegration:
    """Verify CI Drift consumer integration with real canon.yaml."""

    def test_drift_config_has_all_keys(self):
        """The drift config should contain all expected keys."""
        config = get_drift_config()
        expected_keys = [
            "SCORING_PATTERNS", "SECURITY_PATTERNS", "GOVERNANCE_PATTERNS",
            "LOOP_PATTERNS", "ALLOWED_PATHS",
            "SCORING_ALLOWED_LAYERS", "SECURITY_ALLOWED_LAYERS",
            "GOVERNANCE_ALLOWED_LAYERS", "LOOP_ALLOWED_LAYERS",
        ]
        for key in expected_keys:
            assert key in config, f"Missing key: {key}"

    def test_drift_config_patterns_are_lists(self):
        """All pattern fields should be lists."""
        config = get_drift_config()
        for key in ["SCORING_PATTERNS", "SECURITY_PATTERNS", "GOVERNANCE_PATTERNS"]:
            assert isinstance(config[key], list), f"{key} is not a list"

    def test_drift_config_allowed_paths_are_lists(self):
        """Allowed paths should be a list."""
        config = get_drift_config()
        assert isinstance(config["ALLOWED_PATHS"], list)

    def test_drift_config_layer_mapping(self):
        """Layer-specific allowed lists should be derived from boundaries."""
        config = get_drift_config()
        # Memory layer allows cosine_similarity
        assert "core/memory/" in config["SCORING_ALLOWED_LAYERS"]
        # CLI layer does NOT allow cosine_similarity
        assert "core/cli/" not in config["SCORING_ALLOWED_LAYERS"]


# =========================================================================
# 4. Cross-Consumer Consistency Tests
# =========================================================================

class TestCrossConsumerConsistency:
    """Verify that all consumers agree on the same IR."""

    def test_policy_and_drift_share_governance_patterns(self):
        """Policies and drift config should reference consistent patterns."""
        drift_config = get_drift_config()
        policy_summary = get_ir_policy_summary()

        # If there are security policies, there should be security patterns
        security_policies = [p for p in policy_summary if p["type"] == "security"]
        if security_policies:
            assert len(drift_config["SECURITY_PATTERNS"]) > 0

    def test_test_specs_reference_existing_invariants(self):
        """Test specs should reference invariants that exist in the IR."""
        from core.invariants.manager import get_invariant_manager
        manager = get_invariant_manager()
        ir = manager.get_ir()

        invariant_ids = {inv.id for inv in ir.invariants}
        specs = get_test_specs()

        # Check that test names are related to existing invariants
        for spec in specs:
            test_name = spec["name"]
            # Test names should contain parts of invariant IDs
            matched = False
            for inv_id in invariant_ids:
                if test_name.replace("_", ".") in inv_id or any(
                    part in test_name for part in inv_id.split(".")
                ):
                    matched = True
                    break
            # Not all tests need to match invariants (some test policies or boundaries)
            # So we just check that the test has a valid structure
            assert spec["id"].startswith("test.")
