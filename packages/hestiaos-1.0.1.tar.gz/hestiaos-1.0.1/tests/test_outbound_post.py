#!/usr/bin/env python3
"""
Minimal outbound test for Nextcloud Talk integration.
Tests ONLY the POST back to Nextcloud Talk API (outbound path).
No plugin imports, no orchestrator logic.
"""
import asyncio
import httpx
import json
import sys
from datetime import datetime

async def test_outbound_post():
    """Test sending a message directly to Nextcloud Talk API"""
    print("🔍 Testing Outbound POST to Nextcloud Talk")
    print("=" * 60)
    
    # Configuration from user.yml
    server_url = "https://cloud.walter-consult.com"
    username = "HestiaOS"
    password = "3kUqYk$7~EUNWHDE%C3%"
    token = "6mvoe63h"
    verify_ssl = True
    
    # Test message with timestamp to identify it
    timestamp = datetime.now().strftime("%H:%M:%S")
    test_message = f"[Test from HestiaOS at {timestamp}] This is a direct outbound test."
    
    # Endpoint as used in plugins/nextcloud_talk.py _send_message()
    endpoint = f"{server_url}/ocs/v1.php/apps/spreed/api/v1/chat/{token}"
    
    # Headers as used in the plugin
    headers = {
        "OCS-APIRequest": "true",
        "Accept": "application/json",
        "Content-Type": "application/json"
    }
    
    print(f"📤 Sending test message to Nextcloud Talk...")
    print(f"   Server: {server_url}")
    print(f"   Room token: {token}")
    print(f"   Message: '{test_message}'")
    print(f"   Endpoint: {endpoint}")
    
    try:
        async with httpx.AsyncClient(timeout=30.0, verify=verify_ssl) as client:
            resp = await client.post(
                endpoint,
                headers=headers,
                auth=(username, password),
                json={"message": test_message}
            )
            
            print(f"\n📥 Response received:")
            print(f"   Status code: {resp.status_code}")
            print(f"   Content-Type: {resp.headers.get('content-type', 'unknown')}")
            
            # Try to parse response
            try:
                if resp.headers.get('content-type', '').lower().startswith('application/json'):
                    data = resp.json()
                    print(f"   Response is JSON")
                    
                    # Check OCS metadata
                    ocs_meta = data.get('ocs', {}).get('meta', {})
                    ocs_status = ocs_meta.get('status', 'unknown')
                    ocs_statuscode = ocs_meta.get('statuscode', 'unknown')
                    ocs_message = ocs_meta.get('message', '')
                    
                    print(f"   OCS Status: {ocs_status}")
                    print(f"   OCS Status code: {ocs_statuscode}")
                    if ocs_message:
                        print(f"   OCS Message: {ocs_message}")
                    
                    # Check if successful
                    if resp.status_code in [200, 201] and ocs_status == "ok":
                        print(f"\n✅ SUCCESS: Message sent to Nextcloud Talk!")
                        print(f"   The message should appear in the Talk room.")
                        
                        # Get message ID if available
                        ocs_data = data.get('ocs', {}).get('data', {})
                        if isinstance(ocs_data, dict):
                            message_id = ocs_data.get('id')
                            if message_id:
                                print(f"   Message ID: {message_id}")
                        
                        return True
                    else:
                        print(f"\n❌ FAILED: OCS status not 'ok'")
                        return False
                        
                else:
                    # Not JSON, show raw response
                    print(f"   Response is not JSON")
                    print(f"   Raw response (first 500 chars):")
                    print(f"   {resp.text[:500]}")
                    
                    # Check if it's XML
                    if '<?xml' in resp.text[:100].lower():
                        print(f"   Response appears to be XML")
                        # Try to extract error from XML
                        import re
                        error_match = re.search(r'<message>(.*?)</message>', resp.text, re.IGNORECASE)
                        if error_match:
                            print(f"   XML Error message: {error_match.group(1)}")
                    
                    return False
                    
            except json.JSONDecodeError as e:
                print(f"   Failed to parse JSON: {e}")
                print(f"   Raw response: {resp.text[:500]}")
                return False
                
    except httpx.TimeoutException:
        print(f"\n❌ TIMEOUT: Request to Nextcloud Talk timed out after 30s")
        return False
    except httpx.RequestError as e:
        print(f"\n❌ REQUEST ERROR: {e}")
        return False
    except Exception as e:
        print(f"\n❌ UNEXPECTED ERROR: {e}")
        import traceback
        traceback.print_exc()
        return False

async def test_inbound_polling():
    """Test that we can poll messages from the room"""
    print("\n" + "=" * 60)
    print("🔍 Testing Inbound Polling from Nextcloud Talk")
    print("=" * 60)
    
    server_url = "https://cloud.walter-consult.com"
    username = "HestiaOS"
    password = "3kUqYk$7~EUNWHDE%C3%"
    token = "6mvoe63h"
    verify_ssl = True
    
    # Endpoint for polling (as used in _check_room)
    endpoint = f"{server_url}/ocs/v1.php/apps/spreed/api/v1/chat/{token}"
    headers = {
        "OCS-APIRequest": "true",
        "Accept": "application/json"
    }
    params = {
        "lookIntoFuture": 0,
        "limit": 10,
        "format": "json"
    }
    
    print(f"📥 Polling messages from room {token}...")
    
    try:
        async with httpx.AsyncClient(timeout=10.0, verify=verify_ssl) as client:
            resp = await client.get(
                endpoint,
                headers=headers,
                auth=(username, password),
                params=params
            )
            
            print(f"   Status code: {resp.status_code}")
            
            if resp.status_code == 200:
                data = resp.json()
                ocs_meta = data.get('ocs', {}).get('meta', {})
                
                if ocs_meta.get('status') == 'ok':
                    messages = data.get('ocs', {}).get('data', [])
                    print(f"✅ Successfully polled {len(messages)} messages")
                    
                    if messages:
                        print(f"   Latest messages:")
                        for msg in messages[-3:]:  # Show last 3
                            actor = msg.get('actorId', 'unknown')
                            msg_id = msg.get('id', 0)
                            msg_text = msg.get('message', '')[:50]
                            timestamp = msg.get('timestamp', 0)
                            print(f"     - ID {msg_id}: {actor}: '{msg_text}...'")
                    
                    return True
                else:
                    print(f"❌ OCS status failure: {ocs_meta.get('statuscode')} - {ocs_meta.get('message')}")
                    return False
            else:
                print(f"❌ HTTP error: {resp.status_code}")
                print(f"   Response: {resp.text[:200]}")
                return False
                
    except Exception as e:
        print(f"❌ Polling test failed: {e}")
        return False

async def test_full_flow_simulation():
    """Simulate the full flow without actual plugin"""
    print("\n" + "=" * 60)
    print("🔍 Simulating Full Message Flow")
    print("=" * 60)
    
    print("1. User sends '@hestia test' in Nextcloud Talk")
    print("2. Plugin polls and receives message (inbound)")
    print("3. Plugin processes message and calls HestiaOS API")
    print("4. HestiaOS generates response")
    print("5. Plugin sends response back to Talk (outbound)")
    print("6. Response appears in Talk UI")
    
    print("\n✅ Based on logs analysis:")
    print("   - Step 1-3: CONFIRMED (logs show messages received and processed)")
    print("   - Step 4: CONFIRMED (API responds successfully)")
    print("   - Step 5: PARTIALLY CONFIRMED (logs show 'Response sent')")
    print("   - Step 6: UNCONFIRMED (need visual verification in Talk UI)")
    
    print("\n🎯 CRITICAL ISSUE IDENTIFIED:")
    print("   The logs show 'tool_execution_timeout' errors.")
    print("   This means Step 4 (HestiaOS processing) sometimes takes >300s.")
    print("   When this happens, the user sees NO RESPONSE (silent failure).")
    
    print("\n💡 ROOT CAUSE:")
    print("   The plugin's _handle_incoming() has a 30s timeout for API calls,")
    print("   but the orchestrator/agent may have longer internal timeouts.")
    print("   When tool execution times out after 300s, the plugin has already")
    print("   given up (after 30s), but no error message is sent to the user.")
    
    return True

async def main():
    """Run all outbound tests"""
    print("🚀 Nextcloud Talk Outbound Path Verification")
    print("=" * 60)
    
    results = {}
    
    # Run tests
    results['outbound_post'] = await test_outbound_post()
    results['inbound_polling'] = await test_inbound_polling()
    results['flow_analysis'] = await test_full_flow_simulation()
    
    # Summary
    print("\n" + "=" * 60)
    print("📊 VERIFICATION SUMMARY")
    print("=" * 60)
    
    for test_name, passed in results.items():
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"{test_name:20} {status}")
    
    # Critical findings
    print("\n🔍 CRITICAL FINDINGS:")
    print("-" * 40)
    
    if results['outbound_post']:
        print("✅ Outbound POST works technically")
        print("   Messages CAN be sent to Nextcloud Talk API")
    else:
        print("❌ Outbound POST FAILS")
        print("   This is the root cause - messages aren't reaching Talk")
    
    if results['inbound_polling']:
        print("✅ Inbound polling works")
        print("   Plugin can receive messages from Talk")
    
    print("\n🎯 CONFIRMED ISSUE (from logs):")
    print("   'tool_execution_timeout' errors cause silent failures")
    print("   Users see NO RESPONSE when processing takes >300s")
    
    print("\n🚀 RECOMMENDED FIXES:")
    print("1. Add timeout feedback in _handle_incoming():")
    print("   - Send 'Processing timeout' message after 30s")
    print("   - Don't rely on orchestrator timeout (300s)")
    print("2. Verify outbound POST success:")
    print("   - Check OCS status code is 'ok'")
    print("   - Log message ID if available")
    print("3. Add end-to-end verification:")
    print("   - After sending, poll to confirm message appears")
    
    print("\n📋 NEXT STEPS:")
    print("1. Manually test: Send '@hestia hi' in Nextcloud Talk")
    print("2. Check if response appears within 30 seconds")
    print("3. If not, check logs for timeout errors")
    
    return results['outbound_post']  # Most critical test

if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)