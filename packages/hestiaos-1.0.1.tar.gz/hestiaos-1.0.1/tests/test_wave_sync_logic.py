import unittest
import json
import sys
import os
from unittest.mock import MagicMock, AsyncMock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.wave_engine import wave_engine, WaveStatus

class TestWaveSyncLogic(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        # Reset wave engine state for each test
        wave_engine.waves = {}
        wave_engine.llm_engine = MagicMock()
        wave_engine.llm_engine.call_ollama = MagicMock()

    async def test_weighted_merge_no_conflicts(self):
        # Setup mock wave with partial results
        wave_id = "test-wave-1"
        wave_engine.waves[wave_id] = {
            "wave_id": wave_id,
            "status": WaveStatus.PENDING_SYNCHRONIZATION,
            "partial_results": {
                "CORE01-REASONING": {
                    "content": {"summary": "S1", "decisions": {"action": "allow"}, "confidence": 0.9}
                },
                "CORE01-WORKER": {
                    "content": {"summary": "S2", "decisions": {"action": "allow"}, "confidence": 0.8}
                }
            }
        }
        
        # Mock Expert Unifier response
        async def mock_generator(*args, **kwargs):
            yield {"choices": [{"delta": {"content": "Final Unified Result"}}]}
        
        wave_engine.llm_engine.call_ollama.side_effect = mock_generator

        result = await wave_engine.synchronize(wave_id, "admin")
        
        self.assertEqual(result, "Final Unified Result")
        self.assertEqual(wave_engine.waves[wave_id]["conflict_score"], 0.0)
        self.assertEqual(wave_engine.waves[wave_id]["status"], WaveStatus.COMMITTED)

    async def test_weighted_merge_with_conflicts(self):
        # Setup mock wave with conflicting decisions
        wave_id = "test-wave-2"
        wave_engine.waves[wave_id] = {
            "wave_id": wave_id,
            "status": WaveStatus.PENDING_SYNCHRONIZATION,
            "partial_results": {
                "CORE01-REASONING": {
                    "content": {"summary": "S1", "decisions": {"action": "allow"}, "confidence": 1.0}
                },
                "CORE01-WORKER": {
                    "content": {"summary": "S2", "decisions": {"action": "block"}, "confidence": 0.5}
                }
            }
        }
        
        # Mock Expert Unifier response
        async def mock_generator(*args, **kwargs):
            # Check if the prompt contains the conflict info
            prompt = args[0] if len(args) > 0 else kwargs.get('messages', [{}])[0].get('content', '')
            if 'action' in prompt and 'allow' in prompt and 'block' in prompt:
                yield {"choices": [{"delta": {"content": "Resolved Conflict Result"}}]}
            else:
                yield {"choices": [{"delta": {"content": "Failed to see conflict"}}]}
        
        wave_engine.llm_engine.call_ollama.side_effect = mock_generator

        result = await wave_engine.synchronize(wave_id, "admin")
        
        self.assertEqual(result, "Resolved Conflict Result")
        # 1 conflict in 1 decision = 1.0 score
        self.assertEqual(wave_engine.waves[wave_id]["conflict_score"], 1.0)

if __name__ == "__main__":
    unittest.main()
