"""
Tests für den Artifact API Gateway Router (Phase 5).

Testet den REST-Adapter als dünnen Command-Adapter über ArtifactManager.
Importiert den Router direkt aus core.artifact.api (keine Side-Effect-Imports).

Keine Business-Logik-Tests — nur Request/Response-Mapping und Fehlerbehandlung.
"""
import pytest
from fastapi.testclient import TestClient
from fastapi import FastAPI

from core.artifact.api import router


# ---------------------------------------------------------------------------
# Test-App mit Artifact-Router (ohne Side-Effects)
#
# Jeder Test bekommt einen frischen ArtifactManager mit :memory:-DB,
# damit Tests isoliert sind und keine Daten von vorherigen Tests sehen.
# ---------------------------------------------------------------------------

from core.artifact import ArtifactManager


@pytest.fixture
def app():
    """Erstelle eine minimale Test-App mit dem Artifact-Router."""
    app = FastAPI()
    # Frischen ArtifactManager mit :memory:-DB setzen
    app.state.artifact_manager = ArtifactManager(db_path=":memory:")
    app.include_router(router)
    return app


@pytest.fixture
def client(app):
    """TestClient für die Test-App."""
    return TestClient(app)


# ---------------------------------------------------------------------------
# CRUD Endpoint Tests
# ---------------------------------------------------------------------------

class TestCreateArtifact:
    """POST /api/artifacts"""

    def test_create_artifact_success(self, client):
        """Erfolgreiches Erstellen eines Artifacts."""
        response = client.post("/api/artifacts", json={
            "type": "idea",
            "title": "My Idea",
            "content": "Idea content",
            "tags": ["test"],
        })
        assert response.status_code == 200
        data = response.json()
        assert data["title"] == "My Idea"
        assert data["type"] == "idea"
        assert data["status"] == "draft"
        # ID wird vom Service generiert mit Typ-Prefix (z.B. idea_xxx)
        assert data["id"].startswith("idea_") or data["id"].startswith("art_")

    def test_create_artifact_missing_type(self, client):
        """Fehlender 'type' Field → 422."""
        response = client.post("/api/artifacts", json={"title": "No Type"})
        assert response.status_code == 422

    def test_create_artifact_missing_title(self, client):
        """Fehlender 'title' Field → 422."""
        response = client.post("/api/artifacts", json={"type": "idea"})
        assert response.status_code == 422

    def test_create_artifact_invalid_type(self, client):
        """Ungültiger 'type' → 422."""
        response = client.post("/api/artifacts", json={
            "type": "invalid_type",
            "title": "Bad Type",
        })
        assert response.status_code == 422

    def test_create_artifact_with_all_fields(self, client):
        """Erstellen mit allen optionalen Feldern."""
        response = client.post("/api/artifacts", json={
            "type": "task",
            "title": "Complex Task",
            "content": "Task details",
            "status": "active",
            "parent_id": "art_000",
            "dependencies": ["art_001"],
            "owner": "alice",
            "tags": ["backend", "urgent"],
            "acceptance_criteria": "Must be done",
            "assigned_model": "gpt-4",
            "progress": 0.5,
        })
        assert response.status_code == 200
        data = response.json()
        assert data["type"] == "task"
        assert data["status"] == "active"
        assert data["parent_id"] == "art_000"
        assert data["dependencies"] == ["art_001"]
        assert data["owner"] == "alice"
        assert data["tags"] == ["backend", "urgent"]
        assert data["acceptance_criteria"] == "Must be done"
        assert data["assigned_model"] == "gpt-4"
        assert data["progress"] == 0.5


class TestListArtifacts:
    """GET /api/artifacts"""

    def test_list_empty(self, client):
        """Leere Liste."""
        response = client.get("/api/artifacts")
        assert response.status_code == 200
        assert response.json() == []

    def test_list_with_data(self, client):
        """Liste mit Artifacts."""
        client.post("/api/artifacts", json={"type": "idea", "title": "Idea 1"})
        client.post("/api/artifacts", json={"type": "idea", "title": "Idea 2"})
        client.post("/api/artifacts", json={"type": "task", "title": "Task 1"})
        response = client.get("/api/artifacts")
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 3

    def test_list_filter_by_type(self, client):
        """Filter nach Typ."""
        client.post("/api/artifacts", json={"type": "idea", "title": "Idea"})
        client.post("/api/artifacts", json={"type": "task", "title": "Task"})
        response = client.get("/api/artifacts?type=idea")
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 1
        assert data[0]["type"] == "idea"

    def test_list_filter_by_status(self, client):
        """Filter nach Status."""
        client.post("/api/artifacts", json={"type": "idea", "title": "Draft Idea"})
        client.post("/api/artifacts", json={
            "type": "task", "title": "Active Task", "status": "active"
        })
        response = client.get("/api/artifacts?status=draft")
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 1
        assert data[0]["status"] == "draft"

    def test_list_search(self, client):
        """Volltext-Suche."""
        client.post("/api/artifacts", json={
            "type": "idea", "title": "AI Project", "content": "Build an AI system"
        })
        client.post("/api/artifacts", json={
            "type": "task", "title": "Setup CI", "content": "Configure pipeline"
        })
        response = client.get("/api/artifacts?search=AI")
        assert response.status_code == 200
        data = response.json()
        assert len(data) >= 1


class TestGetArtifact:
    """GET /api/artifacts/{id}"""

    def test_get_existing(self, client):
        """Holen eines existierenden Artifacts."""
        create_resp = client.post("/api/artifacts", json={
            "type": "idea", "title": "My Idea"
        })
        art_id = create_resp.json()["id"]
        response = client.get(f"/api/artifacts/{art_id}")
        assert response.status_code == 200
        assert response.json()["id"] == art_id

    def test_get_nonexistent(self, client):
        """Nicht-existierendes Artifact → 404."""
        response = client.get("/api/artifacts/nonexistent")
        assert response.status_code == 404


class TestUpdateArtifact:
    """PUT /api/artifacts/{id}"""

    def test_update_title(self, client):
        """Titel aktualisieren."""
        create_resp = client.post("/api/artifacts", json={
            "type": "idea", "title": "Original"
        })
        art_id = create_resp.json()["id"]
        response = client.put(f"/api/artifacts/{art_id}", json={
            "title": "Updated Title"
        })
        assert response.status_code == 200
        assert response.json()["title"] == "Updated Title"

    def test_update_nonexistent(self, client):
        """Nicht-existierendes Artifact updaten → 404."""
        response = client.put("/api/artifacts/nonexistent", json={"title": "New"})
        assert response.status_code == 404

    def test_update_empty_body(self, client):
        """Leerer Body → 422."""
        create_resp = client.post("/api/artifacts", json={
            "type": "idea", "title": "Test"
        })
        art_id = create_resp.json()["id"]
        response = client.put(f"/api/artifacts/{art_id}", json={})
        assert response.status_code == 422


class TestDeleteArtifact:
    """DELETE /api/artifacts/{id}"""

    def test_delete_existing(self, client):
        """Löschen eines existierenden Artifacts."""
        create_resp = client.post("/api/artifacts", json={
            "type": "idea", "title": "To Delete"
        })
        art_id = create_resp.json()["id"]
        response = client.delete(f"/api/artifacts/{art_id}")
        assert response.status_code == 200
        assert response.json()["status"] == "deleted"
        # Verify it's gone
        get_resp = client.get(f"/api/artifacts/{art_id}")
        assert get_resp.status_code == 404

    def test_delete_nonexistent(self, client):
        """Nicht-existierendes Artifact löschen → 404."""
        response = client.delete("/api/artifacts/nonexistent")
        assert response.status_code == 404


# ---------------------------------------------------------------------------
# Business Workflow Endpoint Tests
# ---------------------------------------------------------------------------

class TestBusinessWorkflows:
    """POST /api/artifacts/{id}/promote, /split, /complete, /block"""

    def test_promote_idea_to_spec(self, client):
        """IDEA → SPEC Promotion."""
        create_resp = client.post("/api/artifacts", json={
            "type": "idea", "title": "Promotable Idea"
        })
        art_id = create_resp.json()["id"]
        response = client.post(f"/api/artifacts/{art_id}/promote")
        assert response.status_code == 200
        data = response.json()
        assert data["type"] == "spec"

    def test_promote_nonexistent(self, client):
        """Nicht-existierendes Artifact promoten → 400."""
        response = client.post("/api/artifacts/nonexistent/promote")
        assert response.status_code == 400

    def test_split_into_tasks(self, client):
        """SPEC → Tasks Splitting."""
        # Create idea and promote
        idea_resp = client.post("/api/artifacts", json={
            "type": "idea", "title": "Split Test"
        })
        spec_resp = client.post(f"/api/artifacts/{idea_resp.json()['id']}/promote")
        spec_id = spec_resp.json()["id"]
        # Split
        response = client.post(f"/api/artifacts/{spec_id}/split", json={
            "tasks": ["Task 1", "Task 2", "Task 3"]
        })
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 3
        assert all(t["type"] == "task" for t in data)

    def test_split_missing_tasks(self, client):
        """Fehlende 'tasks' Liste → 422."""
        create_resp = client.post("/api/artifacts", json={
            "type": "idea", "title": "Test"
        })
        art_id = create_resp.json()["id"]
        response = client.post(f"/api/artifacts/{art_id}/split", json={})
        assert response.status_code == 422

    def test_complete_artifact(self, client):
        """Artifact als DONE markieren."""
        create_resp = client.post("/api/artifacts", json={
            "type": "task", "title": "Completable Task", "status": "active"
        })
        art_id = create_resp.json()["id"]
        response = client.post(f"/api/artifacts/{art_id}/complete")
        assert response.status_code == 200
        assert response.json()["status"] == "done"

    def test_block_artifact(self, client):
        """Artifact blockieren."""
        create_resp = client.post("/api/artifacts", json={
            "type": "task", "title": "Blockable Task", "status": "active"
        })
        art_id = create_resp.json()["id"]
        response = client.post(f"/api/artifacts/{art_id}/block", json={
            "reason": "Waiting for dependency"
        })
        assert response.status_code == 200
        assert response.json()["status"] == "blocked"


# ---------------------------------------------------------------------------
# Linking Endpoint Tests
# ---------------------------------------------------------------------------

class TestLinking:
    """POST/DELETE /api/artifacts/{source_id}/link/{target_id}"""

    def test_link_artifacts(self, client):
        """Zwei Artifacts verknüpfen."""
        a1 = client.post("/api/artifacts", json={"type": "task", "title": "A1"}).json()
        a2 = client.post("/api/artifacts", json={"type": "task", "title": "A2"}).json()
        response = client.post(f"/api/artifacts/{a1['id']}/link/{a2['id']}")
        assert response.status_code == 200
        assert response.json()["status"] == "linked"

    def test_unlink_artifacts(self, client):
        """Verknüpfung entfernen."""
        a1 = client.post("/api/artifacts", json={"type": "task", "title": "A1"}).json()
        a2 = client.post("/api/artifacts", json={"type": "task", "title": "A2"}).json()
        client.post(f"/api/artifacts/{a1['id']}/link/{a2['id']}")
        response = client.delete(f"/api/artifacts/{a1['id']}/link/{a2['id']}")
        assert response.status_code == 200
        assert response.json()["status"] == "unlinked"


# ---------------------------------------------------------------------------
# Graph & Analysis Endpoint Tests
# ---------------------------------------------------------------------------

class TestGraphAnalysis:
    """GET /api/artifacts/{id}/graph, /blockers, /blocked-by, etc."""

    def test_dependency_graph(self, client):
        """Abhängigkeitsgraph abrufen."""
        a1 = client.post("/api/artifacts", json={"type": "task", "title": "Root"}).json()
        response = client.get(f"/api/artifacts/{a1['id']}/graph")
        assert response.status_code == 200
        data = response.json()
        assert "nodes" in data
        assert "edges" in data

    def test_find_blockers(self, client):
        """Blocker finden."""
        a1 = client.post("/api/artifacts", json={"type": "task", "title": "Task"}).json()
        response = client.get(f"/api/artifacts/{a1['id']}/blockers")
        assert response.status_code == 200
        assert isinstance(response.json(), list)

    def test_find_blocked_by(self, client):
        """Blockierte Artifacts finden."""
        a1 = client.post("/api/artifacts", json={"type": "task", "title": "Task"}).json()
        response = client.get(f"/api/artifacts/{a1['id']}/blocked-by")
        assert response.status_code == 200
        assert isinstance(response.json(), list)

    def test_critical_path(self, client):
        """Kritischer Pfad."""
        a1 = client.post("/api/artifacts", json={"type": "project", "title": "Proj"}).json()
        response = client.get(f"/api/artifacts/{a1['id']}/critical-path")
        assert response.status_code == 200
        assert isinstance(response.json(), list)

    def test_topological_sort(self, client):
        """Topologische Sortierung."""
        a1 = client.post("/api/artifacts", json={"type": "project", "title": "Proj"}).json()
        response = client.get(f"/api/artifacts/{a1['id']}/topological-sort")
        assert response.status_code == 200
        assert isinstance(response.json(), list)

    def test_analyze_impact(self, client):
        """Impact-Analyse."""
        a1 = client.post("/api/artifacts", json={"type": "task", "title": "Task"}).json()
        response = client.get(f"/api/artifacts/{a1['id']}/impact")
        assert response.status_code == 200
        data = response.json()
        # analyze_impact gibt Dict mit "artifact"-Key zurück
        assert "artifact" in data or "direct_dependents" in data or "all_downstream" in data

    def test_project_health(self, client):
        """Projekt-Gesundheit."""
        a1 = client.post("/api/artifacts", json={"type": "project", "title": "Proj"}).json()
        response = client.get(f"/api/artifacts/{a1['id']}/health")
        assert response.status_code == 200
        data = response.json()
        # get_project_health gibt Dict mit "total_artifacts"-Key zurück
        assert "total_artifacts" in data or "tasks" in data or "progress" in data

    def test_invalid_scope_returns_422(self, client):
        """Ungültiger GraphScope → 422."""
        a1 = client.post("/api/artifacts", json={"type": "task", "title": "T"}).json()
        response = client.get(f"/api/artifacts/{a1['id']}/graph?scope=INVALID")
        assert response.status_code == 422


# ---------------------------------------------------------------------------
# Transformation Endpoint Tests
# ---------------------------------------------------------------------------

class TestTransformations:
    """POST /api/artifacts/{id}/transform/{name}"""

    def test_idea_to_spec_transformation(self, client):
        """IDEA → SPEC via Transformation."""
        idea = client.post("/api/artifacts", json={
            "type": "idea", "title": "Transformable Idea"
        }).json()
        response = client.post(f"/api/artifacts/{idea['id']}/transform/idea_to_spec")
        assert response.status_code == 200
        data = response.json()
        assert data["success"] is True
        assert data["primary"]["type"] == "spec"

    def test_unknown_transformation(self, client):
        """Unbekannte Transformation → 400."""
        idea = client.post("/api/artifacts", json={
            "type": "idea", "title": "Test"
        }).json()
        response = client.post(f"/api/artifacts/{idea['id']}/transform/unknown")
        assert response.status_code == 400

    def test_can_transform(self, client):
        """Prüfung ob Transformation anwendbar."""
        idea = client.post("/api/artifacts", json={
            "type": "idea", "title": "Test"
        }).json()
        response = client.get(f"/api/artifacts/{idea['id']}/can-transform/idea_to_spec")
        assert response.status_code == 200
        data = response.json()
        assert data["can_transform"] is True

    def test_can_transform_invalid(self, client):
        """Prüfung für nicht anwendbare Transformation."""
        task = client.post("/api/artifacts", json={
            "type": "task", "title": "Test", "status": "active"
        }).json()
        response = client.get(f"/api/artifacts/{task['id']}/can-transform/idea_to_spec")
        assert response.status_code == 200
        data = response.json()
        assert data["can_transform"] is False

    def test_list_transformations(self, client):
        """Verfügbare Transformationen auflisten."""
        response = client.get("/api/artifacts/transformations")
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
        assert "idea_to_spec" in data


# ---------------------------------------------------------------------------
# Replay / Event Log Endpoint Tests
# ---------------------------------------------------------------------------

class TestReplayAndEvents:
    """POST /api/artifacts/replay/rebuild, GET /api/artifacts/{id}/history, etc."""

    def test_rebuild_graph(self, client):
        """Graph-Rekonstruktion aus Event Log."""
        client.post("/api/artifacts", json={"type": "idea", "title": "R1"})
        client.post("/api/artifacts", json={"type": "task", "title": "R2"})
        response = client.post("/api/artifacts/replay/rebuild")
        assert response.status_code == 200
        data = response.json()
        assert data["artifact_count"] >= 2

    def test_get_artifact_history(self, client):
        """Event-Historie eines Artifacts."""
        art = client.post("/api/artifacts", json={
            "type": "idea", "title": "Historical"
        }).json()
        response = client.get(f"/api/artifacts/{art['id']}/history")
        assert response.status_code == 200
        data = response.json()
        assert len(data) >= 1
        assert data[0]["artifact_id"] == art["id"]

    def test_get_events(self, client):
        """Letzte Events abrufen."""
        client.post("/api/artifacts", json={"type": "idea", "title": "E1"})
        response = client.get("/api/artifacts/events")
        assert response.status_code == 200
        data = response.json()
        assert len(data) >= 1

    def test_get_stats(self, client):
        """System-Statistiken."""
        response = client.get("/api/artifacts/stats")
        assert response.status_code == 200
        data = response.json()
        assert "total" in data

    def test_get_event_statistics(self, client):
        """Event-Statistiken."""
        response = client.get("/api/artifacts/event-stats")
        assert response.status_code == 200
        data = response.json()
        assert "total_events" in data

    def test_get_lifecycle(self, client):
        """Lebenszyklus eines Artifacts."""
        art = client.post("/api/artifacts", json={
            "type": "idea", "title": "Lifecycle Test"
        }).json()
        response = client.get(f"/api/artifacts/{art['id']}/lifecycle")
        assert response.status_code == 200
        data = response.json()
        assert "artifact_id" in data or "status_sequence" in data or "created_at" in data


# ---------------------------------------------------------------------------
# State Machine Endpoint Tests
# ---------------------------------------------------------------------------

class TestStateMachine:
    """GET /api/artifacts/state-machine/transitions, /{id}/allowed-transitions"""

    def test_get_transition_graph(self, client):
        """Vollständiger Transitionsgraph."""
        response = client.get("/api/artifacts/state-machine/transitions")
        assert response.status_code == 200
        data = response.json()
        assert "idea" in data or "task" in data or "spec" in data

    def test_get_allowed_transitions(self, client):
        """Erlaubte Transitionen für ein Artifact."""
        art = client.post("/api/artifacts", json={
            "type": "idea", "title": "Transition Test"
        }).json()
        response = client.get(f"/api/artifacts/{art['id']}/allowed-transitions")
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)

    def test_get_allowed_transitions_nonexistent(self, client):
        """Nicht-existierendes Artifact → 404."""
        response = client.get("/api/artifacts/nonexistent/allowed-transitions")
        assert response.status_code == 404


# ---------------------------------------------------------------------------
# Dashboard Endpoint Tests
# ---------------------------------------------------------------------------

class TestDashboard:
    """GET /api/artifacts/dashboard/*"""

    def test_idea_inbox(self, client):
        """Ideen-Inbox."""
        client.post("/api/artifacts", json={"type": "idea", "title": "Inbox Idea"})
        response = client.get("/api/artifacts/dashboard/idea-inbox")
        assert response.status_code == 200
        data = response.json()
        assert len(data) >= 1

    def test_task_board(self, client):
        """Task-Board."""
        client.post("/api/artifacts", json={
            "type": "task", "title": "Board Task", "status": "active"
        })
        response = client.get("/api/artifacts/dashboard/task-board")
        assert response.status_code == 200
        data = response.json()
        assert "draft" in data or "active" in data or "done" in data

    def test_active_tasks(self, client):
        """Aktive Tasks."""
        client.post("/api/artifacts", json={
            "type": "task", "title": "Active T", "status": "active"
        })
        response = client.get("/api/artifacts/dashboard/active-tasks")
        assert response.status_code == 200
        data = response.json()
        assert len(data) >= 1

    def test_project_overview(self, client):
        """Projekt-Übersicht."""
        proj = client.post("/api/artifacts", json={
            "type": "project", "title": "Overview Project"
        }).json()
        response = client.get(f"/api/artifacts/dashboard/project/{proj['id']}")
        assert response.status_code == 200
        data = response.json()
        assert "project" in data or "tasks" in data or "progress" in data


# ---------------------------------------------------------------------------
# Violation Endpoint Tests
# ---------------------------------------------------------------------------

class TestViolations:
    """POST /api/artifacts/violations"""

    def test_record_violation(self, client):
        """Policy-Verletzung aufzeichnen."""
        response = client.post("/api/artifacts/violations", json={
            "violation_type": "policy",
            "layer": "api",
            "reason": "Test violation",
            "severity": "warning",
        })
        assert response.status_code == 200
        data = response.json()
        # Violation erzeugt ein Artifact vom Typ "violation"
        assert data["type"] == "violation"

    def test_record_violation_minimal(self, client):
        """Minimale Violation (nur Pflichtfelder)."""
        response = client.post("/api/artifacts/violations", json={
            "artifact_id": "art_001",
            "rule_id": "rule_001",
            "message": "Minimal",
        })
        assert response.status_code == 200


# ---------------------------------------------------------------------------
# Error Handling Tests
# ---------------------------------------------------------------------------

class TestErrorHandling:
    """Fehlerbehandlung des Routers."""

    def test_404_json(self, client):
        """Nicht-existierende Route → 404."""
        response = client.get("/api/artifacts/nonexistent-route")
        assert response.status_code == 404

    def test_method_not_allowed(self, client):
        """Falsche HTTP-Methode → 405."""
        response = client.put("/api/artifacts")
        assert response.status_code == 405

    def test_invalid_json_body(self, client):
        """Ungültiger JSON-Body → 422."""
        response = client.post("/api/artifacts", json={"type": "idea"})
        assert response.status_code == 422  # missing title
