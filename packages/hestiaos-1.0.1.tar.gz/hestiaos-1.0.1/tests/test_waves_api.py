"""
Test suite for Waves API with AppFactory pattern.

These tests use the AppFactory with start_agents=False to avoid
side-effects and ensure testability without running actual agents.
"""
import pytest
from fastapi.testclient import TestClient
from unittest.mock import Mock, patch, AsyncMock
import tempfile
import os

from api.factory import create_app
from core.protocol.wave import Wave, WaveState


@pytest.fixture
def test_client():
    """Create a test client with start_agents=False."""
    app = create_app(start_agents=False)
    return TestClient(app)


@pytest.fixture
def mock_wave_store():
    """Create a mock WaveStore for testing."""
    with patch('api.routers.waves.get_wave_store') as mock_get_store:
        mock_store = Mock()
        mock_get_store.return_value = mock_store
        yield mock_store


class TestWavesAPI:
    """Test cases for Waves API endpoints."""
    
    def test_create_wave_success(self, test_client, mock_wave_store):
        """Test successful wave creation."""
        # Mock wave data
        mock_wave = Wave(
            wave_id="test-wave-123",
            tenant_id="test-tenant",
            description="Test wave",
            checkpoint="initial-checkpoint",
            actor="test-user",
            flags={"priority": "high"},
            state=WaveState.CREATED,
            created_at=1234567890.0,
            updated_at=1234567890.0,
        )
        mock_wave_store.create_wave.return_value = mock_wave
        mock_wave_store.get_wave_events.return_value = []
        
        # Make request
        response = test_client.post(
            "/api/waves/waves",
            json={
                "tenant_id": "test-tenant",
                "description": "Test wave",
                "checkpoint": "initial-checkpoint",
                "actor": "test-user",
                "flags": {"priority": "high"}
            },
            headers={"X-Tenant-Id": "test-tenant"}
        )
        
        # Assertions
        assert response.status_code == 201
        data = response.json()
        assert data["wave_id"] == "test-wave-123"
        assert data["tenant_id"] == "test-tenant"
        assert data["description"] == "Test wave"
        assert data["state"] == "CREATED"
        assert data["checkpoint"] == "initial-checkpoint"
        assert data["actor"] == "test-user"
        assert data["flags"] == {"priority": "high"}
        
        # Verify store was called
        mock_wave_store.create_wave.assert_called_once()
        created_wave = mock_wave_store.create_wave.call_args[0][0]
        assert created_wave.tenant_id == "test-tenant"
        assert created_wave.description == "Test wave"
    
    def test_create_wave_missing_tenant_header(self, test_client):
        """Test wave creation without X-Tenant-Id header."""
        response = test_client.post(
            "/api/waves/waves",
            json={
                "tenant_id": "test-tenant",
                "description": "Test wave",
                "checkpoint": "initial-checkpoint",
                "actor": "test-user"
            }
        )
        
        assert response.status_code == 400
        assert "X-Tenant-Id header is required" in response.json()["detail"]
    
    def test_create_wave_tenant_mismatch(self, test_client):
        """Test wave creation with tenant ID mismatch."""
        response = test_client.post(
            "/api/waves/waves",
            json={
                "tenant_id": "different-tenant",
                "description": "Test wave",
                "checkpoint": "initial-checkpoint",
                "actor": "test-user"
            },
            headers={"X-Tenant-Id": "test-tenant"}
        )
        
        assert response.status_code == 400
        assert "Tenant ID in request does not match" in response.json()["detail"]
    
    def test_get_wave_success(self, test_client, mock_wave_store):
        """Test successful wave retrieval."""
        # Mock wave data
        mock_wave = Wave(
            wave_id="test-wave-123",
            tenant_id="test-tenant",
            description="Test wave",
            checkpoint="initial-checkpoint",
            actor="test-user",
            flags={},
            state=WaveState.CREATED,
            created_at=1234567890.0,
            updated_at=1234567890.0,
        )
        mock_wave_store.get_wave.return_value = mock_wave
        mock_wave_store.get_wave_events.return_value = []
        
        # Make request
        response = test_client.get(
            "/api/waves/waves/test-wave-123",
            headers={"X-Tenant-Id": "test-tenant"}
        )
        
        # Assertions
        assert response.status_code == 200
        data = response.json()
        assert data["wave_id"] == "test-wave-123"
        assert data["tenant_id"] == "test-tenant"
        
        # Verify store was called with correct parameters
        mock_wave_store.get_wave.assert_called_once_with(
            "test-wave-123", "test-tenant"
        )
    
    def test_get_wave_not_found(self, test_client, mock_wave_store):
        """Test wave retrieval for non-existent wave."""
        mock_wave_store.get_wave.return_value = None
        
        response = test_client.get(
            "/api/waves/waves/non-existent",
            headers={"X-Tenant-Id": "test-tenant"}
        )
        
        assert response.status_code == 404
        assert "Wave not found" in response.json()["detail"]
    
    def test_list_waves_success(self, test_client, mock_wave_store):
        """Test successful wave listing."""
        # Mock waves data
        mock_waves = [
            Wave(
                wave_id=f"wave-{i}",
                tenant_id="test-tenant",
                description=f"Wave {i}",
                checkpoint=f"checkpoint-{i}",
                actor="test-user",
                flags={},
                state=WaveState.CREATED,
                created_at=1234567890.0 + i,
                updated_at=1234567890.0 + i,
            )
            for i in range(3)
        ]
        mock_wave_store.list_waves.return_value = mock_waves
        mock_wave_store.get_wave_events.return_value = []
        
        # Make request
        response = test_client.get(
            "/api/waves/waves",
            headers={"X-Tenant-Id": "test-tenant"},
            params={"page": 1, "page_size": 20}
        )
        
        # Assertions
        assert response.status_code == 200
        data = response.json()
        assert len(data["waves"]) == 3
        assert data["total"] == 3
        assert data["page"] == 1
        assert data["page_size"] == 20
        
        # Verify store was called
        mock_wave_store.list_waves.assert_called_once_with(
            "test-tenant", None
        )
    
    def test_list_waves_with_state_filter(self, test_client, mock_wave_store):
        """Test wave listing with state filter."""
        mock_wave_store.list_waves.return_value = []
        
        response = test_client.get(
            "/api/waves/waves",
            headers={"X-Tenant-Id": "test-tenant"},
            params={"state": "CREATED"}
        )
        
        assert response.status_code == 200
        mock_wave_store.list_waves.assert_called_once_with(
            "test-tenant", WaveState.CREATED
        )
    
    def test_update_wave_success(self, test_client, mock_wave_store):
        """Test successful wave update."""
        # Mock existing wave
        existing_wave = Wave(
            wave_id="test-wave-123",
            tenant_id="test-tenant",
            description="Old description",
            checkpoint="old-checkpoint",
            actor="test-user",
            flags={"old": "flag"},
            state=WaveState.CREATED,
            created_at=1234567890.0,
            updated_at=1234567890.0,
        )
        
        # Mock updated wave
        updated_wave = Wave(
            wave_id="test-wave-123",
            tenant_id="test-tenant",
            description="New description",
            checkpoint="new-checkpoint",
            actor="test-user",
            flags={"new": "flag"},
            state=WaveState.CREATED,
            created_at=1234567890.0,
            updated_at=1234567891.0,  # Updated timestamp
        )
        
        mock_wave_store.get_wave.return_value = existing_wave
        mock_wave_store.update_wave.return_value = updated_wave
        mock_wave_store.get_wave_events.return_value = []
        
        # Make request
        response = test_client.put(
            "/api/waves/waves/test-wave-123",
            json={
                "description": "New description",
                "checkpoint": "new-checkpoint",
                "flags": {"new": "flag"}
            },
            headers={"X-Tenant-Id": "test-tenant"}
        )
        
        # Assertions
        assert response.status_code == 200
        data = response.json()
        assert data["description"] == "New description"
        assert data["checkpoint"] == "new-checkpoint"
        assert data["flags"] == {"new": "flag"}
        
        # Verify store was called
        mock_wave_store.update_wave.assert_called_once()
        updated_wave_arg = mock_wave_store.update_wave.call_args[0][0]
        assert updated_wave_arg.description == "New description"
        assert updated_wave_arg.checkpoint == "new-checkpoint"
        assert updated_wave_arg.flags == {"new": "flag"}
    
    def test_delete_wave_success(self, test_client, mock_wave_store):
        """Test successful wave deletion."""
        # Mock wave in CREATED state (deletable)
        mock_wave = Wave(
            wave_id="test-wave-123",
            tenant_id="test-tenant",
            description="Test wave",
            checkpoint="checkpoint",
            actor="test-user",
            flags={},
            state=WaveState.CREATED,
            created_at=1234567890.0,
            updated_at=1234567890.0,
        )
        
        mock_wave_store.get_wave.return_value = mock_wave
        mock_wave_store.delete_wave.return_value = True
        
        # Make request
        response = test_client.delete(
            "/api/waves/waves/test-wave-123",
            headers={"X-Tenant-Id": "test-tenant"}
        )
        
        # Assertions
        assert response.status_code == 204
        
        # Verify store was called
        mock_wave_store.delete_wave.assert_called_once_with(
            "test-wave-123", "test-tenant"
        )
    
    def test_delete_wave_in_wrong_state(self, test_client, mock_wave_store):
        """Test deletion of wave in non-deletable state."""
        # Mock wave in PROPAGATED state (not deletable)
        mock_wave = Wave(
            wave_id="test-wave-123",
            tenant_id="test-tenant",
            description="Test wave",
            checkpoint="checkpoint",
            actor="test-user",
            flags={},
            state=WaveState.PROPAGATED,
            created_at=1234567890.0,
            updated_at=1234567890.0,
        )
        
        mock_wave_store.get_wave.return_value = mock_wave
        
        # Make request
        response = test_client.delete(
            "/api/waves/waves/test-wave-123",
            headers={"X-Tenant-Id": "test-tenant"}
        )
        
        # Assertions
        assert response.status_code == 400
        assert "Cannot delete wave in state PROPAGATED" in response.json()["detail"]
        mock_wave_store.delete_wave.assert_not_called()
    
    def test_get_wave_events_success(self, test_client, mock_wave_store):
        """Test successful retrieval of wave events."""
        # Mock wave
        mock_wave = Wave(
            wave_id="test-wave-123",
            tenant_id="test-tenant",
            description="Test wave",
            checkpoint="checkpoint",
            actor="test-user",
            flags={},
            state=WaveState.CREATED,
            created_at=1234567890.0,
            updated_at=1234567890.0,
        )
        
        # Mock events
        mock_events = [
            {
                "id": 1,
                "wave_id": "test-wave-123",
                "event_type": "CREATED",
                "timestamp": "2024-01-01T00:00:00Z",
                "actor": "test-user",
                "details": {"description": "Wave created"}
            }
        ]
        
        mock_wave_store.get_wave.return_value = mock_wave
        mock_wave_store.get_wave_events.return_value = mock_events
        
        # Make request
        response = test_client.get(
            "/api/waves/waves/test-wave-123/events",
            headers={"X-Tenant-Id": "test-tenant"},
            params={"limit": 10}
        )
        
        # Assertions
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 1
        assert data[0]["event_type"] == "CREATED"
        
        # Verify store was called
        mock_wave_store.get_wave_events.assert_called_once_with(
            "test-wave-123", 10
        )
    
    def test_get_wave_stats_success(self, test_client, mock_wave_store):
        """Test successful retrieval of wave statistics."""
        # Mock stats
        mock_stats = {
            "total_waves": 5,
            "by_state": {"CREATED": 3, "PROPAGATED": 2},
            "active_waves": 3,
            "avg_lifetime_hours": 12.5
        }
        
        mock_wave_store.get_wave_stats.return_value = mock_stats
        
        # Make request
        response = test_client.get(
            "/api/waves/waves/stats",
            headers={"X-Tenant-Id": "test-tenant"}
        )
        
        # Assertions
        assert response.status_code == 200
        data = response.json()
        assert data["total_waves"] == 5
        assert data["by_state"] == {"CREATED": 3, "PROPAGATED": 2}
        assert data["active_waves"] == 3
        assert data["avg_lifetime_hours"] == 12.5
        
        # Verify store was called
        mock_wave_store.get_wave_stats.assert_called_once_with("test-tenant")


class TestWavesAPIWithRealDatabase:
    """Integration tests with real SQLite database."""
    
    @pytest.fixture
    def temp_db_client(self):
        """Create test client with temporary database."""
        import tempfile
        import os
        
        # Create temporary database file
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp:
            db_path = tmp.name
        
        try:
            # Patch get_wave_store to use temporary database
            with patch('api.routers.waves.get_wave_store') as mock_get_store:
                from core.protocol.wave_store import WaveStore
                wave_store = WaveStore(db_path=db_path)
                mock_get_store.return_value = wave_store
                
                app = create_app(start_agents=False)
                client = TestClient(app)
                yield client
        finally:
            # Clean up temporary database
            if os.path.exists(db_path):
                os.unlink(db_path)
    
    def test_create_and_retrieve_wave_integration(self, temp_db_client):
        """Integration test: create wave and retrieve it."""
        # Create wave
        create_response = temp_db_client.post(
            "/api/waves/waves",
            json={
                "tenant_id": "integration-tenant",
                "description": "Integration test wave",
                "checkpoint": "integration-checkpoint",
                "actor": "integration-user",
                "flags": {"test": "integration"}
            },
            headers={"X-Tenant-Id": "integration-tenant"}
        )
        
        assert create_response.status_code == 201
        wave_data = create_response.json()
        wave_id = wave_data["wave_id"]
        
        # Retrieve wave
        get_response = temp_db_client.get(
            f"/api/waves/waves/{wave_id}",
            headers={"X-Tenant-Id": "integration-tenant"}
        )
        
        assert get_response.status_code == 200
        retrieved_data = get_response.json()
        
        # Verify data matches
        assert retrieved_data["wave_id"] == wave_id
        assert retrieved_data["tenant_id"] == "integration-tenant"
        assert retrieved_data["description"] == "Integration test wave"
        assert retrieved_data["checkpoint"] == "integration-checkpoint"
        assert retrieved_data["actor"] == "integration-user"
        assert retrieved_data["flags"] == {"test": "integration"}
        assert retrieved_data["state"] == "CREATED"


class TestWaveTransitionEndpoints:
    """Test cases for wave state transition endpoints."""
    
    def test_approve_wave_success(self, test_client, mock_wave_store):
        """Test successful wave approval."""
        # Mock wave in CREATED state
        mock_wave = Wave(
            wave_id="test-wave-123",
            tenant_id="test-tenant",
            description="Test wave",
            checkpoint="old-checkpoint",
            actor="creator",
            flags={},
            state=WaveState.CREATED,
            created_at=1234567890.0,
            updated_at=1234567890.0,
        )
        
        # Mock updated wave after approval
        updated_wave = Wave(
            wave_id="test-wave-123",
            tenant_id="test-tenant",
            description="Test wave",
            checkpoint="new-checkpoint",
            actor="creator",
            flags={},
            state=WaveState.PROPAGATION_PENDING,
            created_at=1234567890.0,
            updated_at=1234567891.0,
        )
        
        mock_wave_store.get_wave.return_value = mock_wave
        mock_wave_store.update_wave.return_value = updated_wave
        mock_wave_store.get_wave_events.return_value = []
        
        # Make request
        response = test_client.post(
            "/api/waves/waves/test-wave-123/approve",
            json={
                "new_state": "PROPAGATION_PENDING",  # Will be ignored by approve endpoint
                "actor": "approver",
                "reason": "Looks good",
                "checkpoint": "new-checkpoint"
            },
            headers={"X-Tenant-Id": "test-tenant"}
        )
        
        # Assertions
        assert response.status_code == 200
        data = response.json()
        assert data["state"] == "PROPAGATION_PENDING"
        assert data["checkpoint"] == "new-checkpoint"
        
        # Verify store was called
        mock_wave_store.get_wave.assert_called_once_with("test-wave-123", "test-tenant")
        mock_wave_store.update_wave.assert_called_once()
    
    def test_approve_wave_wrong_state(self, test_client, mock_wave_store):
        """Test approving wave in wrong state."""
        # Mock wave already in PROPAGATION_PENDING state
        mock_wave = Wave(
            wave_id="test-wave-123",
            tenant_id="test-tenant",
            description="Test wave",
            checkpoint="checkpoint",
            actor="creator",
            flags={},
            state=WaveState.PROPAGATION_PENDING,
            created_at=1234567890.0,
            updated_at=1234567890.0,
        )
        
        mock_wave_store.get_wave.return_value = mock_wave
        
        # Make request
        response = test_client.post(
            "/api/waves/waves/test-wave-123/approve",
            json={
                "actor": "approver",
                "reason": "Looks good"
            },
            headers={"X-Tenant-Id": "test-tenant"}
        )
        
        # Assertions
        assert response.status_code == 400
        assert "Cannot approve wave in state PROPAGATION_PENDING" in response.json()["detail"]
        mock_wave_store.update_wave.assert_not_called()
    
    def test_commit_wave_success(self, test_client, mock_wave_store):
        """Test successful wave commit."""
        # Mock wave in SYNC_PENDING state
        mock_wave = Wave(
            wave_id="test-wave-123",
            tenant_id="test-tenant",
            description="Test wave",
            checkpoint="checkpoint",
            actor="creator",
            flags={},
            state=WaveState.SYNC_PENDING,
            created_at=1234567890.0,
            updated_at=1234567890.0,
        )
        
        # Mock updated wave after commit
        updated_wave = Wave(
            wave_id="test-wave-123",
            tenant_id="test-tenant",
            description="Test wave",
            checkpoint="checkpoint",
            actor="creator",
            flags={},
            state=WaveState.COMMITTED,
            created_at=1234567890.0,
            updated_at=1234567891.0,
        )
        
        mock_wave_store.get_wave.return_value = mock_wave
        mock_wave_store.update_wave.return_value = updated_wave
        mock_wave_store.get_wave_events.return_value = []
        
        # Make request
        response = test_client.post(
            "/api/waves/waves/test-wave-123/commit",
            json={
                "actor": "committer",
                "reason": "All synced"
            },
            headers={"X-Tenant-Id": "test-tenant"}
        )
        
        # Assertions
        assert response.status_code == 200
        data = response.json()
        assert data["state"] == "COMMITTED"
        
        # Verify store was called
        mock_wave_store.update_wave.assert_called_once()
    
    def test_commit_wave_wrong_state(self, test_client, mock_wave_store):
        """Test committing wave in wrong state."""
        # Mock wave in CREATED state (cannot commit)
        mock_wave = Wave(
            wave_id="test-wave-123",
            tenant_id="test-tenant",
            description="Test wave",
            checkpoint="checkpoint",
            actor="creator",
            flags={},
            state=WaveState.CREATED,
            created_at=1234567890.0,
            updated_at=1234567890.0,
        )
        
        mock_wave_store.get_wave.return_value = mock_wave
        
        # Make request
        response = test_client.post(
            "/api/waves/waves/test-wave-123/commit",
            json={
                "actor": "committer",
                "reason": "All synced"
            },
            headers={"X-Tenant-Id": "test-tenant"}
        )
        
        # Assertions
        assert response.status_code == 400
        assert "Cannot commit wave in state CREATED" in response.json()["detail"]
        mock_wave_store.update_wave.assert_not_called()
    
    def test_abort_wave_success(self, test_client, mock_wave_store):
        """Test successful wave abortion."""
        # Mock wave in PROPAGATION_PENDING state
        mock_wave = Wave(
            wave_id="test-wave-123",
            tenant_id="test-tenant",
            description="Test wave",
            checkpoint="checkpoint",
            actor="creator",
            flags={},
            state=WaveState.PROPAGATION_PENDING,
            created_at=1234567890.0,
            updated_at=1234567890.0,
        )
        
        # Mock updated wave after abort
        updated_wave = Wave(
            wave_id="test-wave-123",
            tenant_id="test-tenant",
            description="Test wave",
            checkpoint="checkpoint",
            actor="creator",
            flags={},
            state=WaveState.ABORTED,
            created_at=1234567890.0,
            updated_at=1234567891.0,
        )
        
        mock_wave_store.get_wave.return_value = mock_wave
        mock_wave_store.update_wave.return_value = updated_wave
        mock_wave_store.get_wave_events.return_value = []
        
        # Make request
        response = test_client.post(
            "/api/waves/waves/test-wave-123/abort",
            json={
                "actor": "aborter",
                "reason": "Cancelled by user"
            },
            headers={"X-Tenant-Id": "test-tenant"}
        )
        
        # Assertions
        assert response.status_code == 200
        data = response.json()
        assert data["state"] == "ABORTED"
        
        # Verify store was called
        mock_wave_store.update_wave.assert_called_once()
    
    def test_abort_wave_already_aborted(self, test_client, mock_wave_store):
        """Test aborting wave that's already aborted."""
        # Mock wave already in ABORTED state
        mock_wave = Wave(
            wave_id="test-wave-123",
            tenant_id="test-tenant",
            description="Test wave",
            checkpoint="checkpoint",
            actor="creator",
            flags={},
            state=WaveState.ABORTED,
            created_at=1234567890.0,
            updated_at=1234567890.0,
        )
        
        mock_wave_store.get_wave.return_value = mock_wave
        
        # Make request
        response = test_client.post(
            "/api/waves/waves/test-wave-123/abort",
            json={
                "actor": "aborter",
                "reason": "Cancelled by user"
            },
            headers={"X-Tenant-Id": "test-tenant"}
        )
        
        # Assertions
        assert response.status_code == 400
        assert "Cannot abort wave in state ABORTED" in response.json()["detail"]
        mock_wave_store.update_wave.assert_not_called()
    
    def test_generic_transition_success(self, test_client, mock_wave_store):
        """Test successful generic state transition."""
        # Mock wave in PROPAGATION_PENDING state
        mock_wave = Wave(
            wave_id="test-wave-123",
            tenant_id="test-tenant",
            description="Test wave",
            checkpoint="old-checkpoint",
            actor="creator",
            flags={},
            state=WaveState.PROPAGATION_PENDING,
            created_at=1234567890.0,
            updated_at=1234567890.0,
        )
        
        # Mock updated wave after transition
        updated_wave = Wave(
            wave_id="test-wave-123",
            tenant_id="test-tenant",
            description="Test wave",
            checkpoint="new-checkpoint",
            actor="creator",
            flags={},
            state=WaveState.PROPAGATED,
            created_at=1234567890.0,
            updated_at=1234567891.0,
        )
        
        mock_wave_store.get_wave.return_value = mock_wave
        mock_wave_store.update_wave.return_value = updated_wave
        mock_wave_store.get_wave_events.return_value = []
        
        # Make request
        response = test_client.post(
            "/api/waves/waves/test-wave-123/transition",
            json={
                "new_state": "PROPAGATED",
                "actor": "transitioner",
                "reason": "Propagation complete",
                "checkpoint": "new-checkpoint"
            },
            headers={"X-Tenant-Id": "test-tenant"}
        )
        
        # Assertions
        assert response.status_code == 200
        data = response.json()
        assert data["state"] == "PROPAGATED"
        assert data["checkpoint"] == "new-checkpoint"
        
        # Verify store was called
        mock_wave_store.update_wave.assert_called_once()
    
    def test_generic_transition_invalid(self, test_client, mock_wave_store):
        """Test invalid state transition."""
        # Mock wave in CREATED state
        mock_wave = Wave(
            wave_id="test-wave-123",
            tenant_id="test-tenant",
            description="Test wave",
            checkpoint="checkpoint",
            actor="creator",
            flags={},
            state=WaveState.CREATED,
            created_at=1234567890.0,
            updated_at=1234567890.0,
        )
        
        mock_wave_store.get_wave.return_value = mock_wave
        
        # Make request with invalid transition (CREATED → COMMITTED)
        response = test_client.post(
            "/api/waves/waves/test-wave-123/transition",
            json={
                "new_state": "COMMITTED",  # Invalid: cannot skip intermediate states
                "actor": "transitioner",
                "reason": "Invalid transition"
            },
            headers={"X-Tenant-Id": "test-tenant"}
        )
        
        # Assertions
        assert response.status_code == 400
        assert "Invalid state transition" in response.json()["detail"]
        mock_wave_store.update_wave.assert_not_called()