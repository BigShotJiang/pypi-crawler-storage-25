"""
Phase 10 — Skill Self-Improvement Loop (v7)
============================================
56 Unit-Tests für die "Safe Operational Memory Architecture".

Test-Kategorien:
  - Concurrency Tests (4)
  - Intent Signature Tests (5)
  - Tool-Specific Fingerprinter Tests (6)
  - Failure Cause Tests (5)
  - Version Binding Tests (3)
  - Replay Determinism Tests (3)
  - Skill Registry Tests (5)
  - Failure Registry Tests (4)
  - Hybrid Matcher Tests (4)
  - Safety Filter Tests (3)
  - Cooldown Policy Tests (2)
  - Skill Distillation Tests (2)
  - Factory Function Tests (10)
"""

import json
import os
import time
import asyncio
import tempfile
import pytest
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
from dataclasses import dataclass, field

# ──────────────────────────────────────────────
# Concurrency Tests (4)
# ──────────────────────────────────────────────

class TestPendingMatchManagerConcurrency:
    """4 Concurrency Tests für PendingMatchManager."""

    @pytest.mark.asyncio
    async def test_concurrent_set_and_get_valid(self):
        """Test 1: Gleichzeitiges Set und GetValid."""
        from core.skills.pending_match import PendingMatchManager, PendingSkillMatch

        mgr = PendingMatchManager()

        async def set_task(session_id: str, skill_id: str):
            match = PendingSkillMatch(skill_id=skill_id, session_id=session_id)
            await mgr.set(session_id, match)
            return skill_id

        async def get_task(session_id: str):
            return await mgr.get_valid(session_id)

        session = "test_concurrent_001"
        # Concurrent set
        tasks = [set_task(session, f"skill_{i}") for i in range(5)]
        results = await asyncio.gather(*tasks)
        assert len(results) == 5

        # Concurrent get
        get_tasks = [get_task(session) for _ in range(5)]
        reads = await asyncio.gather(*get_tasks)
        assert all(len(r) == 5 for r in reads)

    @pytest.mark.asyncio
    async def test_concurrent_invalidate_all(self):
        """Test 2: Gleichzeitiges Invalidieren aller Matches."""
        from core.skills.pending_match import PendingMatchManager, PendingSkillMatch

        mgr = PendingMatchManager()
        session = "test_concurrent_002"

        for i in range(3):
            match = PendingSkillMatch(skill_id=f"skill_{i}", session_id=session)
            await mgr.set(session, match)

        await mgr.invalidate_all(session)
        valid = await mgr.get_valid(session)
        assert len(valid) == 0

    @pytest.mark.asyncio
    async def test_concurrent_cleanup_expired(self):
        """Test 3: Cleanup abgelaufener Matches."""
        from core.skills.pending_match import PendingMatchManager, PendingSkillMatch

        mgr = PendingMatchManager()
        session = "test_concurrent_003"

        for i in range(3):
            match = PendingSkillMatch(
                skill_id=f"skill_{i}",
                session_id=session,
                ttl_seconds=0,  # Immediate expiry
            )
            await mgr.set(session, match)

        await asyncio.sleep(0.1)
        await mgr.cleanup_expired()
        valid = await mgr.get_valid(session)
        assert len(valid) == 0

    @pytest.mark.asyncio
    async def test_concurrent_get_stats(self):
        """Test 4: Stats unter Concurrency."""
        from core.skills.pending_match import PendingMatchManager, PendingSkillMatch

        mgr = PendingMatchManager()
        session = "test_concurrent_004"

        for i in range(3):
            match = PendingSkillMatch(skill_id=f"skill_{i}", session_id=session)
            await mgr.set(session, match)

        stats = await mgr.get_stats()
        assert stats["active_sessions"] >= 1
        assert stats["total_pending"] >= 3


# ──────────────────────────────────────────────
# Intent Signature Tests (5)
# ──────────────────────────────────────────────

class TestIntentSignature:
    """5 Tests für Deterministic Intent Signature."""

    def test_extract_intent_components_consistency(self):
        """Test 1: Gleicher Input → gleiche Komponenten."""
        from core.skills.intent_signature import extract_intent_components

        msg = "create a new python file in the project"
        comp1 = extract_intent_components(msg)
        comp2 = extract_intent_components(msg)
        assert comp1 == comp2
        # extract_intent_components returns sorted lists, not sets
        assert "create" in comp1["verbs"]

    def test_intent_signature_normalization(self):
        """Test 2: Normalisierung von Verb-Varianten."""
        from core.skills.intent_signature import extract_intent_components

        comp1 = extract_intent_components("create a file")
        comp2 = extract_intent_components("add a file")
        comp3 = extract_intent_components("generate a file")
        # Alle sollten "create" enthalten
        assert "create" in comp1["verbs"]
        assert "create" in comp2["verbs"]
        assert "create" in comp3["verbs"]

    def test_intent_signature_scope_detection(self):
        """Test 3: Scope-Erkennung aus der Message."""
        from core.skills.intent_signature import extract_intent_components

        comp = extract_intent_components("delete the file /etc/config.yaml")
        assert "delete" in comp["verbs"]

    def test_compute_intent_signature(self):
        """Test 4: compute_intent_signature erzeugt konsistenten String."""
        from core.skills.intent_signature import compute_intent_signature

        sig1 = compute_intent_signature("create a python file")
        sig2 = compute_intent_signature("add a python file")
        assert sig1 == sig2
        assert isinstance(sig1, str)

    def test_intents_match(self):
        """Test 5: intents_match erkennt gleiche Intents."""
        from core.skills.intent_signature import intents_match

        # intents_match takes two message strings, not signatures
        assert intents_match("create a file", "add a file")
        assert not intents_match("create a file", "delete a file")


# ──────────────────────────────────────────────
# Tool-Specific Fingerprinter Tests (6)
# ──────────────────────────────────────────────

class TestToolFingerprinters:
    """6 Tests für Tool-spezifische Parameter-Fingerprinter."""

    def test_bash_fingerprinter_destructive(self):
        """Test 1: Bash-Fingerprinter erkennt destruktive Befehle."""
        from core.skills.fingerprint import BashFingerprinter
        from core.skills import EnvironmentScope

        fp = BashFingerprinter()
        result = fp.fingerprint(
            {"command": "rm -rf /tmp/test"},
            EnvironmentScope.LOCAL,
        )
        assert result.has_destructive_flags

    def test_bash_fingerprinter_safe(self):
        """Test 2: Bash-Fingerprinter erkennt sichere Befehle."""
        from core.skills.fingerprint import BashFingerprinter
        from core.skills import EnvironmentScope

        fp = BashFingerprinter()
        result = fp.fingerprint(
            {"command": "ls -la /home/user"},
            EnvironmentScope.LOCAL,
        )
        assert not result.has_destructive_flags

    def test_k8s_fingerprinter_namespace(self):
        """Test 3: K8s-Fingerprinter extrahiert Namespace."""
        from core.skills.fingerprint import K8sFingerprinter
        from core.skills import EnvironmentScope

        fp = K8sFingerprinter()
        result = fp.fingerprint(
            {"namespace": "production", "resource": "deployment"},
            EnvironmentScope.LOCAL,
        )
        assert result.parameter_shapes is not None

    def test_docker_fingerprinter_force(self):
        """Test 4: Docker-Fingerprinter erkennt force-Flags."""
        from core.skills.fingerprint import DockerFingerprinter
        from core.skills import EnvironmentScope

        fp = DockerFingerprinter()
        result = fp.fingerprint(
            {"command": "rmi", "force": True, "image": "test:latest"},
            EnvironmentScope.LOCAL,
        )
        assert result.has_destructive_flags

    def test_terraform_fingerprinter_plan(self):
        """Test 5: Terraform-Fingerprinter erkennt plan vs apply."""
        from core.skills.fingerprint import TerraformFingerprinter
        from core.skills import EnvironmentScope

        fp = TerraformFingerprinter()
        result = fp.fingerprint(
            {"command": "plan", "directory": "/infra"},
            EnvironmentScope.LOCAL,
        )
        assert not result.has_destructive_flags

    def test_fingerprinter_registry_defaults(self):
        """Test 6: FingerprinterRegistry hat Defaults."""
        from core.skills.fingerprint import FingerprinterRegistry

        registry = FingerprinterRegistry()
        assert "bash" in registry._fingerprinters
        assert "kubectl" in registry._fingerprinters
        assert "docker" in registry._fingerprinters
        assert "terraform" in registry._fingerprinters


# ──────────────────────────────────────────────
# Failure Cause Tests (5)
# ──────────────────────────────────────────────

class TestFailureClassifier:
    """5 Tests für Failure Cause Classification."""

    def test_classify_transient(self):
        """Test 1: Transiente Fehler (Timeout, Rate Limit)."""
        from core.skills.failure_classifier import FailureClassifier, FailureCause

        cause = FailureClassifier.classify(
            error_message="Request timed out after 30s",
        )
        assert cause == FailureCause.TRANSIENT

    def test_classify_logic_error(self):
        """Test 2: Logikfehler (Syntax, Validation)."""
        from core.skills.failure_classifier import FailureClassifier, FailureCause

        cause = FailureClassifier.classify(
            error_message="invalid syntax in script.py",
        )
        # Default fallback is LOGIC_ERROR when no patterns match
        assert cause == FailureCause.LOGIC_ERROR

    def test_classify_catastrophic(self):
        """Test 3: Katastrophale Fehler (Data Loss, Security)."""
        from core.skills.failure_classifier import FailureClassifier, FailureCause

        cause = FailureClassifier.classify(
            error_message="Data loss detected: all records deleted",
        )
        assert cause == FailureCause.CATASTROPHIC

    def test_failure_pattern_causes_filter(self):
        """Test 4: Nur LOGIC_ERROR/SAFETY_VIOLATION/CATASTROPHIC erzeugen Patterns."""
        from core.skills.failure_classifier import FAILURE_PATTERN_CAUSES, FailureCause

        assert FailureCause.LOGIC_ERROR in FAILURE_PATTERN_CAUSES
        assert FailureCause.SAFETY_VIOLATION in FAILURE_PATTERN_CAUSES
        assert FailureCause.CATASTROPHIC in FAILURE_PATTERN_CAUSES
        assert FailureCause.TRANSIENT not in FAILURE_PATTERN_CAUSES

    def test_classify_unknown_fallback(self):
        """Test 5: Unbekannte Fehler → LOGIC_ERROR (Default)."""
        from core.skills.failure_classifier import FailureClassifier, FailureCause

        cause = FailureClassifier.classify(
            error_message="Some random unknown error occurred",
        )
        # Default fallback is LOGIC_ERROR (not TRANSIENT)
        assert cause == FailureCause.LOGIC_ERROR


# ──────────────────────────────────────────────
# Version Binding Tests (3)
# ──────────────────────────────────────────────

class TestVersionBinding:
    """3 Tests für ToolVersionConstraint + RuntimeEnvironmentSignature."""

    def test_tool_version_constraint_satisfied(self):
        """Test 1: Version Constraint wird erfüllt."""
        from core.skills.version_binding import ToolVersionConstraint

        constraint = ToolVersionConstraint(
            tool_name="bash",
            version_spec=">=4.0.0,<5.0.0",
        )
        assert constraint.matches("4.2.0")

    def test_tool_version_constraint_not_satisfied(self):
        """Test 2: Version Constraint wird nicht erfüllt."""
        from core.skills.version_binding import ToolVersionConstraint

        constraint = ToolVersionConstraint(
            tool_name="bash",
            version_spec=">=5.0.0,<6.0.0",
        )
        assert not constraint.matches("4.2.0")

    def test_runtime_environment_signature(self):
        """Test 3: RuntimeEnvironmentSignature erzeugt konsistente Signatur."""
        from core.skills.version_binding import RuntimeEnvironmentSignature

        sig = RuntimeEnvironmentSignature(
            os_type="linux",
            os_version="6.17",
            python_version="3.12",
        )
        assert sig.os_type == "linux"
        assert sig.python_version == "3.12"
        compatible, reasons = sig.is_compatible(sig)
        assert compatible
        assert len(reasons) == 0


# ──────────────────────────────────────────────
# Replay Determinism Tests (3)
# ──────────────────────────────────────────────

class TestReplayDeterminism:
    """3 Tests für Skill Replay Determinism Contract."""

    def test_validation_report_creation(self):
        """Test 1: ValidationReport Erzeugung."""
        from core.skills.sandbox import ValidationReport

        report = ValidationReport(
            skill_id="test_001",
            skill_name="test_skill",
            environment_scope=None,
        )
        assert report.skill_id == "test_001"
        assert report.skill_name == "test_skill"
        assert len(report.checks) == 0

    def test_validation_report_passed(self):
        """Test 2: ValidationReport passed Status."""
        from core.skills.sandbox import ValidationReport

        report = ValidationReport(
            skill_id="test_002",
            skill_name="test_skill",
            environment_scope=None,
        )
        assert not report.passed  # No checks yet

    def test_skill_sandbox_validate(self):
        """Test 3: SkillSandbox.validate_skill() mit bekanntem Skill."""
        from core.skills.sandbox import SkillSandbox
        from core.skills import SkillRegistryEntry, EnvironmentScope, SkillTrustLevel

        sandbox = SkillSandbox()
        entry = SkillRegistryEntry(
            skill_id="test_001",
            skill_name="test_skill",
            description="A test skill",
            tool_sequence=["bash", "bash"],
            environment_scopes=[EnvironmentScope.LOCAL],
            trust_level=SkillTrustLevel.PASSIVE,
            domains=["general"],
            confidence_history=[0.5],
            created_at=datetime.now(),
            updated_at=datetime.now(),
        )
        report = sandbox.validate_skill(entry)
        assert report is not None
        assert report.skill_name == "test_skill"


# ──────────────────────────────────────────────
# Skill Registry Tests (5)
# ──────────────────────────────────────────────

class TestSkillRegistry:
    """5 Tests für die Living Skill Registry."""

    def _make_candidate(self, name="test_skill", desc="A test skill",
                        tools=None, trace="trace_001",
                        domains=None):
        """Helper: Erzeugt einen SkillCandidate mit Minimal-Config."""
        from core.skills import SkillCandidate, SideEffectClass, EnvironmentScope
        from core.skills.intent_signature import compute_intent_signature

        intent_sig = compute_intent_signature(f"create {name}")
        return SkillCandidate(
            skill_name=name,
            description=desc,
            tool_sequence=tools or ["bash"],
            intent_signature=intent_sig,
            side_effect_class=SideEffectClass.READ_ONLY,
            environment_scope=EnvironmentScope.LOCAL,
            parameter_fingerprint="bash:ls",
            worthiness_score=0.8,
            trace_id=trace,
            success_attributions=[],
            tool_version_constraints=[],
            runtime_signature=None,
            domains=domains or ["general"],
        )

    def test_register_and_get_skill(self):
        """Test 1: Skill registrieren und abrufen."""
        from core.skills.skill_registry import SkillRegistry
        from core.skills import SuccessAttribution

        registry = SkillRegistry(registry_path=None)
        candidate = self._make_candidate()
        skill_id = registry.register_skill(candidate)
        assert skill_id is not None
        retrieved = registry.get(skill_id)
        assert retrieved is not None
        assert retrieved.skill_name == "test_skill"

    def test_register_duplicate_skill(self):
        """Test 2: Duplikat-Erkennung (gleicher intent_signature)."""
        from core.skills.skill_registry import SkillRegistry

        registry = SkillRegistry(registry_path=None)
        candidate = self._make_candidate(name="dup_skill", trace="trace_002")
        skill_id1 = registry.register_skill(candidate)
        skill_id2 = registry.register_skill(candidate)
        assert skill_id1 == skill_id2  # Dedup via canonical_id
        assert len(registry.get_all()) == 1

    def test_confirm_skill_usage(self):
        """Test 3: update_confidence erhöht Confidence."""
        from core.skills.skill_registry import SkillRegistry
        from core.skills import SuccessAttribution

        registry = SkillRegistry(registry_path=None)
        candidate = self._make_candidate(name="confidence_test", trace="trace_003")
        skill_id = registry.register_skill(candidate)
        assert skill_id is not None
        attr = SuccessAttribution(
            tool_exit_code=True,
            no_rollback=True,
            user_confirmation=True,
            downstream_validation=True,
            no_corrections=True,
            duration_budget=True,
            token_budget=True,
        )
        registry.update_confidence(skill_id, attr)
        updated = registry.get(skill_id)
        assert updated is not None

    def test_record_skill_non_usage(self):
        """Test 4: add_execution_record mit fehlgeschlagener Execution."""
        from core.skills.skill_registry import SkillRegistry
        from core.skills import ExecutionRecord

        registry = SkillRegistry(registry_path=None)
        candidate = self._make_candidate(name="non_usage_test", trace="trace_004")
        skill_id = registry.register_skill(candidate)
        assert skill_id is not None
        registry.add_execution_record(skill_id, ExecutionRecord(tool_name="bash", success=False))
        updated = registry.get(skill_id)
        assert updated is not None

    def test_list_skills_empty(self):
        """Test 5: Leere Registry."""
        from core.skills.skill_registry import SkillRegistry

        registry = SkillRegistry(registry_path=None)
        skills = registry.get_all()
        assert len(skills) == 0


# ──────────────────────────────────────────────
# Failure Registry Tests (4)
# ──────────────────────────────────────────────

class TestFailureRegistry:
    """4 Tests für die Failure Pattern Registry."""

    def test_record_and_find_pattern(self):
        """Test 1: Failure Pattern aufzeichnen und finden."""
        from core.skills.failure_registry import FailurePatternRegistry
        from core.skills import FailureCause, EnvironmentScope

        registry = FailurePatternRegistry(patterns_path=None)
        registry.record_failure(
            tool_sequence=["bash", "python"],
            error_message="Syntax error in script",
            cause=FailureCause.LOGIC_ERROR,
            scope=EnvironmentScope.LOCAL,
        )
        patterns = registry.find_matching_patterns(
            tool_sequence=["bash", "python", "docker"],
            scope=EnvironmentScope.LOCAL,
        )
        assert len(patterns) > 0

    def test_catastrophic_penalty(self):
        """Test 2: Catastrophic Penalty Formula (0.5^count)."""
        from core.skills.failure_registry import FailurePatternRegistry
        from core.skills import FailureCause, FailureSeverity, EnvironmentScope

        registry = FailurePatternRegistry(patterns_path=None)
        # Use different tool_sequences to avoid dedup via _find_similar
        sequences = [
            ["bash", "python"],
            ["docker", "kubectl"],
            ["terraform", "python"],
        ]
        for i, seq in enumerate(sequences):
            registry.record_failure(
                tool_sequence=seq,
                error_message=f"Data loss #{i}",
                cause=FailureCause.CATASTROPHIC,
                scope=EnvironmentScope.LOCAL,
                severity=FailureSeverity.CATASTROPHIC,
            )
        penalty = registry.get_catastrophic_penalty(
            tool_sequence=["bash", "python", "docker", "kubectl", "terraform"],
            scope=EnvironmentScope.LOCAL,
        )
        assert penalty == pytest.approx(0.5 ** 3)

    def test_deprecate_pattern(self):
        """Test 3: Pattern deprecate (3 Assertions: Rückgabe, Mutation, Matching)."""
        from core.skills.failure_registry import FailurePatternRegistry
        from core.skills import FailureCause, EnvironmentScope

        registry = FailurePatternRegistry(patterns_path=None)
        pattern = registry.record_failure(
            tool_sequence=["bash", "python"],
            error_message="Test error",
            cause=FailureCause.LOGIC_ERROR,
            scope=EnvironmentScope.LOCAL,
        )
        assert pattern is not None, "record_failure muss ein Pattern zurückgeben"

        # Assertion 1: deprecate_pattern gibt True zurück
        result = registry.deprecate_pattern(pattern.pattern_id)
        assert result is True, "deprecate_pattern muss True zurückgeben"

        # Assertion 2: Das Pattern-Objekt wurde mutiert
        assert pattern.deprecated is True, "pattern.deprecated muss True sein"
        assert pattern.deprecation_reason == "manual"

        # Assertion 3: find_matching_patterns schließt deprecated Patterns aus
        patterns_after = registry.find_matching_patterns(
            tool_sequence=["bash", "python", "docker"],
            scope=EnvironmentScope.LOCAL,
        )
        assert len(patterns_after) == 0, (
            f"deprecated Pattern darf nicht gematcht werden, "
            f"gefunden: {len(patterns_after)}"
        )

    def test_prune_old_patterns(self):
        """Test 4: Alte Patterns werden geprunt."""
        from core.skills.failure_registry import FailurePatternRegistry
        from core.skills import FailureCause, EnvironmentScope

        registry = FailurePatternRegistry(patterns_path=None)
        registry.record_failure(
            tool_sequence=["bash", "python"],
            error_message="Old error",
            cause=FailureCause.LOGIC_ERROR,
            scope=EnvironmentScope.LOCAL,
        )
        pruned = registry.prune_old_patterns(max_age_days=0)
        assert pruned >= 0


# ──────────────────────────────────────────────
# Hybrid Matcher Tests (4)
# ──────────────────────────────────────────────

class TestHybridMatcher:
    """4 Tests für Two-Phase Hybrid Matching."""

    def test_match_intent_returns_result(self):
        """Test 1: match_intent gibt IntentMatchResult zurück."""
        from core.skills.matcher import HybridMatcher
        from core.skills.skill_registry import SkillRegistry
        from core.skills import EnvironmentScope

        registry = SkillRegistry(registry_path=None)
        matcher = HybridMatcher(skill_registry=registry)
        result = matcher.match_intent(
            user_message="create a file",
            scope=EnvironmentScope.LOCAL,
        )
        assert result is not None
        assert hasattr(result, 'has_matching_skills')

    def test_match_execution_returns_result(self):
        """Test 2: match_execution gibt ExecutionMatchResult zurück."""
        from core.skills.matcher import HybridMatcher
        from core.skills.skill_registry import SkillRegistry
        from core.skills import EnvironmentScope

        registry = SkillRegistry(registry_path=None)
        matcher = HybridMatcher(skill_registry=registry)
        result = matcher.match_execution(
            tool_sequence=["bash", "bash"],
            parameters={},
            scope=EnvironmentScope.LOCAL,
            intent_signature="",
        )
        assert result is not None
        assert hasattr(result, 'matches')

    def test_lcs_sequence_similarity(self):
        """Test 3: LCS-basierte Sequenz-Ähnlichkeit."""
        from core.skills.matcher import HybridMatcher
        from core.skills.skill_registry import SkillRegistry

        matcher = HybridMatcher(skill_registry=SkillRegistry(registry_path=None))
        similarity = matcher._compute_sequence_score(
            ["bash", "k8s", "docker"],
            ["bash", "docker"],
        )
        assert 0 < similarity <= 1.0

    def test_trust_level_determination(self):
        """Test 4: Trust Level wird korrekt bestimmt."""
        from core.skills.matcher import HybridMatcher
        from core.skills.skill_registry import SkillRegistry
        from core.skills import SkillTrustLevel, SkillRegistryEntry, EnvironmentScope

        matcher = HybridMatcher(skill_registry=SkillRegistry(registry_path=None))
        entry = SkillRegistryEntry(
            skill_id="test_001",
            skill_name="test",
            description="",
            tool_sequence=["bash"],
            environment_scopes=[EnvironmentScope.LOCAL],
            trust_level=SkillTrustLevel.GUIDED,
            domains=["general"],
            confidence_history=[0.8],
            created_at=datetime.now(),
            updated_at=datetime.now(),
        )
        trust = matcher._determine_trust_level(entry, 0.8, EnvironmentScope.LOCAL)
        assert trust == SkillTrustLevel.GUIDED


# ──────────────────────────────────────────────
# Safety Filter Tests (3)
# ──────────────────────────────────────────────

class TestSafetyFilter:
    """3 Tests für den Safety Filter."""

    def test_blocked_domain_detected(self):
        """Test 1: HARD_BLOCK_DOMAINS werden erkannt."""
        from core.skills.safety_filter import SafetyFilter
        from core.skills import SkillMatch, SkillTrustLevel, SideEffectClass, EnvironmentScope

        sf = SafetyFilter()
        match = SkillMatch(
            skill_id="malicious_001",
            confidence=0.9,
            trust_level=SkillTrustLevel.GUIDED,
            match_type="execution",
            tool_sequence_score=0.9,
            fingerprint_score=0.8,
            domain_score=0.7,
        )
        result = sf.check_skill_match(
            match=match,
            side_effect_class=SideEffectClass.SECURITY_MUTATION,
            environment_scope=EnvironmentScope.LOCAL,
            domain="system",
        )
        assert not result.allowed

    def test_safe_domain_allowed(self):
        """Test 2: Sichere Domains sind erlaubt."""
        from core.skills.safety_filter import SafetyFilter
        from core.skills import SkillMatch, SkillTrustLevel, SideEffectClass, EnvironmentScope

        sf = SafetyFilter()
        match = SkillMatch(
            skill_id="safe_001",
            confidence=0.9,
            trust_level=SkillTrustLevel.PASSIVE,
            match_type="execution",
            tool_sequence_score=0.9,
            fingerprint_score=0.8,
            domain_score=0.7,
        )
        result = sf.check_skill_match(
            match=match,
            side_effect_class=SideEffectClass.READ_ONLY,
            environment_scope=EnvironmentScope.LOCAL,
            domain="general",
        )
        assert result.allowed

    def test_empty_domains_allowed(self):
        """Test 3: Leere Domains sind erlaubt."""
        from core.skills.safety_filter import SafetyFilter
        from core.skills import SkillMatch, SkillTrustLevel, SideEffectClass, EnvironmentScope

        sf = SafetyFilter()
        match = SkillMatch(
            skill_id="empty_001",
            confidence=0.9,
            trust_level=SkillTrustLevel.PASSIVE,
            match_type="execution",
            tool_sequence_score=0.9,
            fingerprint_score=0.8,
            domain_score=0.7,
        )
        result = sf.check_skill_match(
            match=match,
            side_effect_class=SideEffectClass.READ_ONLY,
            environment_scope=EnvironmentScope.LOCAL,
            domain=None,
        )
        assert result.allowed


# ──────────────────────────────────────────────
# Cooldown Policy Tests (2)
# ──────────────────────────────────────────────

class TestCooldownPolicy:
    """2 Tests für SkillCooldownPolicy."""

    def test_check_cooldown_new_skill(self):
        """Test 1: Neuer Skill ist nicht ready (zu wenige Executions)."""
        from core.skills.cooldown import SkillCooldownPolicy, check_cooldown
        from core.skills import SkillTrustLevel, SkillRegistryEntry, EnvironmentScope, ExecutionRecord
        import time

        policy = SkillCooldownPolicy(
            min_guided_executions=5,
            min_age_hours=24,
        )
        entry = SkillRegistryEntry(
            skill_id="new_001",
            skill_name="new_skill",
            description="Brand new skill",
            tool_sequence=["bash"],
            environment_scopes=[EnvironmentScope.LOCAL],
            trust_level=SkillTrustLevel.PASSIVE,
            domains=["general"],
            confidence_history=[0.5],
            created_at=datetime.now(),
            updated_at=datetime.now(),
        )
        is_ready, reasons = check_cooldown(entry, policy)
        assert not is_ready
        assert len(reasons) > 0

    def test_check_cooldown_young_skill(self):
        """Test 2: Zu junger Skill ist nicht ready."""
        from core.skills.cooldown import SkillCooldownPolicy, check_cooldown
        from core.skills import SkillTrustLevel, SkillRegistryEntry, EnvironmentScope, ExecutionRecord
        import time

        policy = SkillCooldownPolicy(
            min_guided_executions=5,
            min_age_hours=24,
        )
        entry = SkillRegistryEntry(
            skill_id="young_001",
            skill_name="young_skill",
            description="Very young skill",
            tool_sequence=["bash"],
            environment_scopes=[EnvironmentScope.LOCAL],
            trust_level=SkillTrustLevel.GUIDED,
            domains=["general"],
            confidence_history=[0.5],
            execution_history=[],
            created_at=datetime.now(),
            updated_at=datetime.now(),
        )
        is_ready, reasons = check_cooldown(entry, policy)
        assert not is_ready


# ──────────────────────────────────────────────
# Skill Distillation Tests (2)
# ──────────────────────────────────────────────

class TestSkillDistillation:
    """2 Tests für Skill Distillation Engine."""

    def test_distill_successful_trace(self):
        """Test 1: distill() erzeugt SkillCandidate bei erfolgreichem Trace."""
        from core.skills.skill_distiller import SkillDistiller
        from core.skills import SessionTrace, SuccessAttribution, SideEffectClass, EnvironmentScope, ExecutionRecord

        distiller = SkillDistiller(worthiness_threshold=0.0)
        trace = SessionTrace(
            session_id="test_session",
            user_message="create a file",
            scope=EnvironmentScope.LOCAL,
            started_at=datetime.now(),
            completed_at=datetime.now(),
            execution_records=[
                ExecutionRecord(tool_name="bash", success=True),
            ],
            total_tool_calls=1,
            retry_count=0,
            user_corrections=0,
            self_recovery_count=0,
            expert_delegation_count=0,
            rollback_count=0,
            total_duration_ms=100,
            total_token_cost=50,
            success_rate=1.0,
            success_attribution=SuccessAttribution(
                tool_exit_code=True,
                no_rollback=True,
                user_confirmation=True,
                downstream_validation=True,
                no_corrections=True,
                duration_budget=True,
                token_budget=True,
            ),
            completed_successfully=True,
            tool_sequence=["bash"],
            parameter_fingerprints=["bash:ls"],
        )
        candidate = distiller.distill(trace)
        assert candidate is not None
        assert candidate.skill_name is not None

    def test_distill_failed_trace(self):
        """Test 2: Fehlgeschlagener Trace erzeugt keinen Candidate."""
        from core.skills.skill_distiller import SkillDistiller
        from core.skills import SessionTrace, SuccessAttribution, EnvironmentScope

        distiller = SkillDistiller(worthiness_threshold=0.0)
        trace = SessionTrace(
            session_id="empty_session",
            user_message="",
            scope=EnvironmentScope.LOCAL,
            started_at=datetime.now(),
            completed_at=datetime.now(),
            execution_records=[],
            total_tool_calls=0,
            retry_count=0,
            user_corrections=0,
            self_recovery_count=0,
            expert_delegation_count=0,
            rollback_count=0,
            total_duration_ms=0,
            total_token_cost=0,
            success_rate=0.0,
            success_attribution=SuccessAttribution(),
        )
        candidate = distiller.distill(trace)
        assert candidate is None


# ──────────────────────────────────────────────
# Factory Function Tests (10)
# ──────────────────────────────────────────────

class TestFactoryFunctions:
    """10 Tests für Factory Functions (DI)."""

    def test_create_skill_registry(self):
        """Test 1: create_skill_registry()."""
        from core.skills import create_skill_registry
        registry = create_skill_registry(registry_path=None)
        assert registry is not None
        assert hasattr(registry, 'register_skill')
        assert hasattr(registry, 'get')

    def test_create_failure_registry(self):
        """Test 2: create_failure_registry()."""
        from core.skills import create_failure_registry
        registry = create_failure_registry(patterns_path=None)
        assert registry is not None
        assert hasattr(registry, 'record_failure')
        assert hasattr(registry, 'find_matching_patterns')

    def test_create_matcher(self):
        """Test 3: create_matcher()."""
        from core.skills import create_matcher, create_skill_registry
        registry = create_skill_registry(registry_path=None)
        matcher = create_matcher(skill_registry=registry)
        assert matcher is not None
        assert hasattr(matcher, 'match_intent')
        assert hasattr(matcher, 'match_execution')

    def test_create_sandbox(self):
        """Test 4: create_sandbox()."""
        from core.skills import create_sandbox
        sandbox = create_sandbox()
        assert sandbox is not None
        assert hasattr(sandbox, 'validate_skill')

    def test_create_diff_viewer(self):
        """Test 5: create_diff_viewer()."""
        from core.skills import create_diff_viewer
        viewer = create_diff_viewer()
        assert viewer is not None
        assert hasattr(viewer, 'create_diff')

    def test_create_exporter(self):
        """Test 6: create_exporter()."""
        from core.skills import create_exporter, create_skill_registry
        registry = create_skill_registry(registry_path=None)
        exporter = create_exporter(skill_registry=registry)
        assert exporter is not None
        assert hasattr(exporter, 'export_skill_md')

    def test_create_safety_filter(self):
        """Test 7: create_safety_filter()."""
        from core.skills import create_safety_filter
        sf = create_safety_filter()
        assert sf is not None
        assert hasattr(sf, 'check_skill_match')

    def test_create_distiller(self):
        """Test 8: create_distiller()."""
        from core.skills import create_distiller
        distiller = create_distiller()
        assert distiller is not None
        assert hasattr(distiller, 'distill')

    def test_create_pending_match_manager(self):
        """Test 9: create_pending_match_manager()."""
        from core.skills import create_pending_match_manager
        mgr = create_pending_match_manager(ttl_seconds=60)
        assert mgr is not None
        assert hasattr(mgr, 'set')
        assert hasattr(mgr, 'get_valid')
        assert hasattr(mgr, 'invalidate_all')

    def test_create_cooldown_policy(self):
        """Test 10: create_cooldown_policy()."""
        from core.skills import create_cooldown_policy
        policy = create_cooldown_policy(
            min_guided_executions=5,
            min_age_hours=24,
        )
        assert policy is not None
        assert hasattr(policy, 'to_dict')


# ═══════════════════════════════════════════════════════════════
# Phase 11: Operational Consistency Layer (16 Tests)
# ═══════════════════════════════════════════════════════════════


class TestCanonicalSkillIdentity:
    """4 Tests für Canonical Skill Identity (P0-2)."""

    def test_compute_canonical_id_deterministic(self):
        """Test 1: Gleiche Parameter → gleiche canonical_id."""
        from core.skills.skill_identity import compute_canonical_skill_id

        id1 = compute_canonical_skill_id(
            intent_signature="abc123",
            tool_sequence=["bash", "python"],
            side_effect_class="write_local",
            environment_scope="local",
        )
        id2 = compute_canonical_skill_id(
            intent_signature="abc123",
            tool_sequence=["bash", "python"],
            side_effect_class="write_local",
            environment_scope="local",
        )
        assert id1 == id2
        assert len(id1) == 32  # SHA256 truncated

    def test_compute_canonical_id_different_intent(self):
        """Test 2: Unterschiedlicher Intent → unterschiedliche canonical_id."""
        from core.skills.skill_identity import compute_canonical_skill_id

        id1 = compute_canonical_skill_id(
            intent_signature="abc123",
            tool_sequence=["bash"],
            side_effect_class="read_only",
            environment_scope="local",
        )
        id2 = compute_canonical_skill_id(
            intent_signature="def456",
            tool_sequence=["bash"],
            side_effect_class="read_only",
            environment_scope="local",
        )
        assert id1 != id2

    def test_compute_canonical_id_different_tools(self):
        """Test 3: Unterschiedliche Tools → unterschiedliche canonical_id."""
        from core.skills.skill_identity import compute_canonical_skill_id

        id1 = compute_canonical_skill_id(
            intent_signature="abc",
            tool_sequence=["bash"],
            side_effect_class="read_only",
            environment_scope="local",
        )
        id2 = compute_canonical_skill_id(
            intent_signature="abc",
            tool_sequence=["python"],
            side_effect_class="read_only",
            environment_scope="local",
        )
        assert id1 != id2

    def test_create_skill_identity_dedup(self):
        """Test 4: create_skill_identity erkennt Duplikate."""
        from core.skills.skill_identity import create_skill_identity

        existing = {
            "skill-1": {
                "canonical_id": "a" * 32,
                "lineage_id": "lineage-1",
            }
        }
        identity = create_skill_identity(
            intent_signature="test",
            tool_sequence=["bash"],
            side_effect_class="read_only",
            environment_scope="local",
            existing_skills=existing,
        )
        # Da canonical_id anders ist, wird neues Identity erzeugt
        assert identity.canonical_id != "a" * 32
        assert identity.lineage_id is not None


class TestUnitOfWork:
    """4 Tests für Transactional Persistence (P0-1)."""

    def test_uow_commit_and_rollback(self, tmp_path):
        """Test 5: Commit und Rollback funktionieren."""
        from core.skills.unit_of_work import SkillMemoryUnitOfWork

        skills_file = tmp_path / "skills.json"
        failure_file = tmp_path / "failures.json"
        skills_file.write_text('{"skills": {}, "metadata": {}}')
        failure_file.write_text('{"patterns": []}')

        skills_data = {"skills": {}, "metadata": {}}
        failure_data = {"patterns": []}

        # Commit Test
        uow = SkillMemoryUnitOfWork(
            skills_path=str(skills_file),
            failure_path=str(failure_file),
            skills_data=skills_data,
            failure_data=failure_data,
        )
        with uow:
            skills_data["skills"]["test-1"] = {"name": "test"}
            uow.commit()

        assert skills_file.exists()
        content = skills_file.read_text()
        assert "test-1" in content

        # Rollback Test (kein commit → rollback)
        skills_data2 = {"skills": {}, "metadata": {}}
        failure_data2 = {"patterns": []}
        uow2 = SkillMemoryUnitOfWork(
            skills_path=str(skills_file),
            failure_path=str(failure_file),
            skills_data=skills_data2,
            failure_data=failure_data2,
        )
        with uow2:
            skills_data2["skills"]["rollback-test"] = {"name": "rollback"}
            # Kein commit → automatischer Rollback

        # Datei sollte unverändert sein
        content2 = skills_file.read_text()
        assert "rollback-test" not in content2

    def test_uow_rollback_on_exception(self, tmp_path):
        """Test 6: Exception führt zu automatischem Rollback."""
        from core.skills.unit_of_work import SkillMemoryUnitOfWork

        skills_file = tmp_path / "skills.json"
        failure_file = tmp_path / "failures.json"
        skills_file.write_text('{"skills": {}, "metadata": {}}')
        failure_file.write_text('{"patterns": []}')

        skills_data = {"skills": {}, "metadata": {}}
        failure_data = {"patterns": []}

        try:
            uow = SkillMemoryUnitOfWork(
                skills_path=str(skills_file),
                failure_path=str(failure_file),
                skills_data=skills_data,
                failure_data=failure_data,
            )
            with uow:
                skills_data["skills"]["crash-test"] = {"name": "crash"}
                raise ValueError("Simulierter Crash")
        except ValueError:
            pass

        # Datei sollte unverändert sein
        content = skills_file.read_text()
        assert "crash-test" not in content

    def test_uow_file_lock(self, tmp_path):
        """Test 7: FileLock kann erworben und freigegeben werden."""
        from core.skills.unit_of_work import FileLock

        lock_path = tmp_path / "test.lock"
        lock = FileLock(str(lock_path))

        lock.acquire()
        # Lock ist erworben
        lock.release()
        # Lock ist freigegeben → kein Fehler
        assert True

    def test_uow_wal_recovery(self, tmp_path):
        """Test 8: WriteAheadLog Recovery funktioniert."""
        from core.skills.unit_of_work import WriteAheadLog

        wal_path = tmp_path / "test.wal"
        skills_tmp = tmp_path / "skills_tmp.json"
        failure_tmp = tmp_path / "failure_tmp.json"
        skills_target = tmp_path / "skills_target.json"
        failure_target = tmp_path / "failure_target.json"

        # Schreibe Temp-Dateien
        skills_tmp.write_text('{"skills": {"test": {}}}')
        failure_tmp.write_text('{"patterns": []}')

        # Schreibe WAL "prepared"
        wal = WriteAheadLog(str(wal_path))
        wal.write(
            state="prepared",
            skills_tmp=str(skills_tmp),
            failure_tmp=str(failure_tmp),
            skills_target=str(skills_target),
            failure_target=str(failure_target),
        )

        # Recovery durchführen
        WriteAheadLog.recover(str(wal_path))

        # Nach Recovery sollten die Target-Dateien existieren
        assert skills_target.exists()
        assert failure_target.exists()
        # WAL sollte gelöscht sein
        assert not wal_path.exists()


class TestFailureDecay:
    """4 Tests für Failure Pattern Decay (P1-3)."""

    def test_decay_config_exists(self):
        """Test 9: Decay Config existiert für alle Severities."""
        from core.skills.failure_decay import FAILURE_DECAY_CONFIG
        from core.skills import FailureSeverity

        for severity in FailureSeverity:
            assert severity in FAILURE_DECAY_CONFIG
            config = FAILURE_DECAY_CONFIG[severity]
            assert "ttl_days" in config
            assert "decay_start_days" in config
            assert "half_life_days" in config

    def test_decay_mixin_age_days(self):
        """Test 10: DecayMixin berechnet age_days korrekt."""
        from core.skills.failure_decay import DecayMixin
        import time

        class MockPattern(DecayMixin):
            def __init__(self):
                self.created_at = time.time() - 86400 * 10  # 10 Tage alt
                self.last_seen_at = time.time()
                self.severity = "minor"
                self.confidence_decay_score = 1.0
                self.occurrence_count = 1

        pattern = MockPattern()
        assert 9.0 < pattern.age_days < 11.0

    def test_decay_mixin_compute_score(self):
        """Test 11: DecayScore wird korrekt berechnet."""
        from core.skills.failure_decay import DecayMixin, FAILURE_DECAY_CONFIG
        from core.skills import FailureSeverity
        import time

        class MockPattern(DecayMixin):
            def __init__(self):
                self.created_at = time.time() - 86400 * 100  # 100 Tage alt
                self.last_seen_at = time.time() - 86400 * 60  # 60 Tage nicht gesehen
                self.severity = FailureSeverity.MODERATE
                self.confidence_decay_score = 1.0
                self.occurrence_count = 1

        pattern = MockPattern()
        score = pattern.compute_decay_score()

        # MODERATE: decay_start=30d, half_life=45d
        # 60 - 30 = 30 Tage decay_age
        # 30 / 45 = 0.67 half_lives
        # 1.0 * (0.5 ^ 0.67) ≈ 0.63
        assert 0.5 < score < 0.8

    def test_apply_decay_to_patterns(self):
        """Test 12: apply_decay_to_patterns entfernt verfallene Patterns."""
        from core.skills.failure_decay import apply_decay_to_patterns, DecayMixin
        from core.skills import FailureSeverity
        import time

        class MockPattern(DecayMixin):
            def __init__(self, age_days: float, last_seen_days: float):
                self.created_at = time.time() - 86400 * age_days
                self.last_seen_at = time.time() - 86400 * last_seen_days
                self.severity = FailureSeverity.MINOR
                self.confidence_decay_score = 1.0
                self.occurrence_count = 1

        # MINOR: ttl=30d → 40d nicht gesehen → expired
        expired_pattern = MockPattern(age_days=50, last_seen_days=40)
        # MINOR: ttl=30d → 5d nicht gesehen → nicht expired
        active_pattern = MockPattern(age_days=10, last_seen_days=5)

        patterns = {
            "expired-1": expired_pattern,
            "active-1": active_pattern,
        }

        expired = apply_decay_to_patterns(patterns)

        assert "expired-1" in expired
        assert "active-1" not in expired
        assert "active-1" in patterns
        assert "expired-1" not in patterns


class TestTrustRegression:
    """4 Tests für Trust Regression Path (P1-4)."""

    def test_regression_map(self):
        """Test 13: Regression Map ist korrekt definiert."""
        from core.skills.trust_regression import TrustRegressor
        from core.skills import SkillTrustLevel

        assert TrustRegressor.REGRESSION_MAP[SkillTrustLevel.AUTONOMOUS] == SkillTrustLevel.GUIDED
        assert TrustRegressor.REGRESSION_MAP[SkillTrustLevel.GUIDED] == SkillTrustLevel.PASSIVE
        assert TrustRegressor.REGRESSION_MAP[SkillTrustLevel.PASSIVE] == SkillTrustLevel.PASSIVE

    def test_should_regress_catastrophic(self):
        """Test 14: Catastrophic Failure → sofortige Regression."""
        from core.skills.trust_regression import TrustRegressor, RegressionTrigger
        from core.skills import SkillTrustLevel

        class MockSkillEntry:
            trust_level = SkillTrustLevel.AUTONOMOUS
            force_downgrade = False
            version_mismatch = False
            environment_changed = False
            cooldown_violation = False

        regressor = TrustRegressor()
        trigger = regressor.should_regress(
            skill_entry=MockSkillEntry(),
            recent_failures=[
                {"success": False, "severity": "catastrophic"},
            ],
        )
        assert trigger == RegressionTrigger.CATASTROPHIC_FAILURE

    def test_should_regress_consecutive_failures(self):
        """Test 15: 3+ Consecutive Failures → Regression."""
        from core.skills.trust_regression import TrustRegressor, RegressionTrigger
        from core.skills import SkillTrustLevel

        class MockSkillEntry:
            trust_level = SkillTrustLevel.GUIDED
            force_downgrade = False
            version_mismatch = False
            environment_changed = False
            cooldown_violation = False

        regressor = TrustRegressor()
        trigger = regressor.should_regress(
            skill_entry=MockSkillEntry(),
            recent_failures=[
                {"success": False, "severity": "minor"},
                {"success": False, "severity": "minor"},
                {"success": False, "severity": "minor"},
                {"success": True, "severity": "none"},
                {"success": True, "severity": "none"},
            ],
        )
        assert trigger == RegressionTrigger.CONSECUTIVE_FAILURES

    def test_apply_regression(self):
        """Test 16: apply_regression ändert trust_level und zeichnet Event auf."""
        from core.skills.trust_regression import TrustRegressor, RegressionTrigger
        from core.skills import SkillTrustLevel

        class MockSkillEntry:
            def __init__(self):
                self.trust_level = SkillTrustLevel.AUTONOMOUS
                self.skill_id = "test-skill-123"
                self.regression_events = []

        regressor = TrustRegressor()
        entry = MockSkillEntry()

        new_level = regressor.apply_regression(
            skill_entry=entry,
            trigger=RegressionTrigger.CATASTROPHIC_FAILURE,
        )

        assert new_level == SkillTrustLevel.GUIDED
        assert entry.trust_level == SkillTrustLevel.GUIDED
        assert len(regressor.get_regression_history()) == 1
        assert len(regressor.get_regression_history(skill_id="test-skill-123")) == 1
        assert len(regressor.get_regression_history(skill_id="other-skill")) == 0
