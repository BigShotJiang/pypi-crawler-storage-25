#!/usr/bin/env python3
"""
Phase 7 Validation: In-Process Swarming with Micro-Agents.

Tests all 7 core components from Roo's Phase 7 implementation:
1. Agent Runtime Contract (immutable snapshots, context isolation)
2. Shared Memory Layer (inter-agent communication)
3. 10ms Tick Execution Loop (backpressure, preemption)
4. Event Bus (28 event types, guaranteed delivery)
5. Agent Lifecycle State Machine (14 states, guarded transitions)
6. Gateway Integration (agent-aware routing)
7. In-Process Swarming Manager (micro-agent collaboration)
"""

import asyncio
import time
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

PASS = 0
FAIL = 0

def report(name, ok, detail=""):
    global PASS, FAIL
    if ok:
        PASS += 1
        print(f"  ✅ {name}")
    else:
        FAIL += 1
        print(f"  ❌ {name} — {detail}")


async def test_agent_context():
    """Test 1: Agent Runtime Contract — immutable snapshots & context isolation."""
    print("\n═══ Test 1: Agent Runtime Contract ═══")
    from core.agent.agent_context import (
        AgentContext, AgentRole, AgentState,
        ContextSnapshot, SharedMemoryLayer, create_agent_context
    )

    # 1a. Factory function
    ctx = create_agent_context("test-agent-1", AgentRole.EXECUTOR, {"task": "validate"})
    report("create_agent_context returns AgentContext", isinstance(ctx, AgentContext))
    report("Initial state is CREATED", ctx.state == AgentState.CREATED)

    # 1b. Immutable snapshot
    snap = ctx.snapshot
    report("Snapshot is frozen dataclass", isinstance(snap, ContextSnapshot))
    try:
        snap.agent_id = "tampered"
        report("Snapshot immutability enforced", False, "mutation succeeded")
    except Exception:
        report("Snapshot immutability enforced", True)

    # 1c. State transitions
    ok = await ctx.transition_to(AgentState.INITIALIZING, "test")
    report("CREATED → INITIALIZING valid", ok)
    bad = await ctx.transition_to(AgentState.COMPLETED, "skip")
    report("INITIALIZING → COMPLETED rejected", not bad)

    # 1d. Shared memory
    mem = SharedMemoryLayer()
    await mem.set("key1", "value1")
    val = await mem.get("key1")
    report("SharedMemoryLayer get/set works", val == "value1")

    # 1e. Optimistic concurrency
    _, v = await mem.get_with_version("key1")
    ok_write = await mem.set("key1", "v2", expected_version=v)
    bad_write = await mem.set("key1", "v3", expected_version=0)  # stale version
    report("Optimistic concurrency control works", ok_write and not bad_write)

    # 1f. Child context
    child = await ctx.create_child_context("child-1", AgentRole.SPECIALIST)
    report("Child context inherits shared memory", child._shared_memory is ctx._shared_memory)
    report("Child execution depth = parent + 1", child.execution_depth == ctx.execution_depth + 1)


async def test_event_bus():
    """Test 2: Event Bus — 28 event types, pub/sub, backpressure."""
    print("\n═══ Test 2: Event Bus (28 Event Types) ═══")
    from core.agent.event_bus import EventBus, EventType, Event

    # 2a. All 28 event types exist
    report("28 event types defined", len(EventType) == 28, f"found {len(EventType)}")

    # 2b. Event creation
    evt = Event(event_type=EventType.AGENT_CREATED, payload={"id": "a1"}, source="test")
    report("Event serializes to dict", "event_type" in evt.to_dict())
    report("Event serializes to JSON", '"agent_created"' in evt.to_json())

    # 2c. Pub/Sub
    bus = EventBus(max_queue_size=100)
    received = []

    async def handler(e: Event):
        received.append(e)

    await bus.start()
    await bus.subscribe("test-sub", EventType.AGENT_CREATED, handler)
    await bus.publish(EventType.AGENT_CREATED, {"test": True}, source="validator")
    await asyncio.sleep(0.2)  # let worker process
    report("Event delivered to subscriber", len(received) >= 1)

    # 2d. Metrics
    metrics = bus.get_metrics()
    report("Metrics tracking active", metrics["events_published"] > 0)

    await bus.stop()


async def test_scheduler():
    """Test 3: 10ms Tick Scheduler — backpressure, agent execution."""
    print("\n═══ Test 3: 10ms Tick Scheduler ═══")
    from core.agent.agent_scheduler import AgentScheduler
    from core.agent.agent_context import create_agent_context, AgentRole, AgentState

    scheduler = AgentScheduler(tick_duration_ms=10, max_concurrent_agents=5)
    await scheduler.start()

    report("Scheduler starts successfully", scheduler._is_running)
    report("Tick duration is 10ms", scheduler.tick_duration == 0.01)

    # Schedule a simple agent — note: scheduler internally manages state transitions
    # via context.execute(), so agent must start in CREATED state
    result_holder = {}

    async def simple_task(ctx):
        result_holder["executed"] = True
        return "done"

    ctx = create_agent_context("sched-agent-1", AgentRole.EXECUTOR)
    ok = await scheduler.schedule_agent("sched-agent-1", ctx, simple_task, priority=5)
    report("Agent scheduled successfully", ok)

    # Wait for execution
    await asyncio.sleep(0.5)
    
    # The scheduler picks up the agent and runs it through execute()
    report("Scheduled agent was executed", result_holder.get("executed", False))

    # Metrics
    metrics = scheduler.get_metrics()
    report("Scheduler metrics available", metrics["tick_count"] > 0)

    status = scheduler.get_status()
    report("Scheduler status comprehensive", "backpressure_level" in status)

    await scheduler.stop()
    report("Scheduler stops cleanly", not scheduler._is_running)


async def test_state_machine():
    """Test 4: Agent Lifecycle State Machine — 14 states, guarded transitions."""
    print("\n═══ Test 4: State Machine (14 States) ═══")
    from core.agent.state_machine import (
        AgentStateMachine, create_agent_state_machine,
        register_state_machine, get_state_machine, get_all_state_machines
    )
    from core.agent.agent_context import AgentState

    # 4a. Creation
    sm = create_agent_state_machine("sm-test-1")
    report("State machine created", isinstance(sm, AgentStateMachine))
    report("Initial state is CREATED", sm.current_state == AgentState.CREATED)

    # 4b. Valid transitions
    ok = await sm.transition_to(AgentState.INITIALIZING, reason="test")
    report("CREATED → INITIALIZING valid", ok)
    ok2 = await sm.transition_to(AgentState.READY, reason="test")
    report("INITIALIZING → READY valid", ok2)

    # 4c. Invalid transition rejected
    bad = await sm.transition_to(AgentState.ARCHIVED, reason="skip")
    report("READY → ARCHIVED rejected", not bad)

    # 4d. History tracking
    history = sm.get_transition_history()
    report("Transition history recorded", len(history) >= 2)

    # 4e. Registry
    register_state_machine(sm)
    found = get_state_machine("sm-test-1")
    report("State machine registry works", found is not None)

    all_sms = get_all_state_machines()
    report("get_all_state_machines returns data", len(all_sms) > 0)


async def test_gateway_integration():
    """Test 5: Gateway Integration — bridge, routing, swarming manager."""
    print("\n═══ Test 5: Gateway Integration ═══")
    from core.agent.gateway_integration import (
        get_agent_gateway_bridge,
        get_swarming_manager,
        AgentGatewayBridge,
        InProcessSwarmingManager
    )

    # 5a. Bridge instantiation
    bridge = get_agent_gateway_bridge()
    report("Gateway bridge instantiated", isinstance(bridge, AgentGatewayBridge))

    # 5b. Swarming manager
    swarm = get_swarming_manager()
    report("Swarming manager instantiated", isinstance(swarm, InProcessSwarmingManager))

    # 5c. Bridge is singleton
    bridge2 = get_agent_gateway_bridge()
    report("Gateway bridge is singleton", bridge is bridge2)

    swarm2 = get_swarming_manager()
    report("Swarming manager is singleton", swarm is swarm2)


async def test_full_agent_lifecycle():
    """Test 6: Full agent lifecycle — creation through completion."""
    print("\n═══ Test 6: Full Agent Lifecycle E2E ═══")
    from core.agent.agent_context import (
        AgentContext, AgentRole, AgentState, create_agent_context, SharedMemoryLayer
    )

    shared_mem = SharedMemoryLayer()
    ctx = create_agent_context("lifecycle-1", AgentRole.EXECUTOR, {"job": "e2e"}, shared_mem)

    execution_log = []

    async def tracked_task(agent_ctx):
        execution_log.append("executing")
        await agent_ctx.shared_set("result", "computed")
        # Yield and resume
        await agent_ctx.yield_execution("checkpoint")
        execution_log.append("yielded")
        await agent_ctx.resume_execution()
        execution_log.append("resumed")
        return "success"

    result = await ctx.execute(tracked_task)
    report("Full lifecycle completed", result == "success")
    report("Final state is COMPLETED", ctx.state == AgentState.COMPLETED)
    report("Yield/resume occurred", "yielded" in execution_log and "resumed" in execution_log)

    # Check shared memory was written
    val = await shared_mem.get("result")
    report("Shared memory persists across lifecycle", val == "computed")

    stats = ctx.get_execution_stats()
    report("Execution stats available", stats["duration_seconds"] is not None)


async def test_swarming_collaboration():
    """Test 7: In-Process Swarming — multi-agent collaboration."""
    print("\n═══ Test 7: In-Process Swarming ═══")
    from core.agent.agent_context import SharedMemoryLayer, create_agent_context, AgentRole

    shared = SharedMemoryLayer()
    agents_completed = []

    async def agent_work(ctx, agent_name):
        await ctx.shared_set(f"{agent_name}_status", "working")
        await asyncio.sleep(0.05)  # Simulate work
        await ctx.shared_set(f"{agent_name}_status", "done")
        agents_completed.append(agent_name)
        return f"{agent_name} finished"

    # Spawn 3 micro-agents with shared memory
    contexts = [
        create_agent_context(f"swarm-{i}", AgentRole.SPECIALIST, shared_memory=shared)
        for i in range(3)
    ]

    # Run concurrently (in-process swarming)
    tasks = [
        ctx.execute(lambda c, name=f"agent-{i}": agent_work(c, name))
        for i, ctx in enumerate(contexts)
    ]
    results = await asyncio.gather(*tasks, return_exceptions=True)

    successful = [r for r in results if not isinstance(r, Exception)]
    report("All 3 swarm agents completed", len(successful) == 3)
    report("All agents share memory layer", all(c._shared_memory is shared for c in contexts))

    # Check shared memory has all agent statuses
    statuses = []
    for i in range(3):
        s = await shared.get(f"agent-{i}_status")
        statuses.append(s)
    report("Shared memory reflects all agent states", all(s == "done" for s in statuses))


async def main():
    print("=" * 60)
    print("  PHASE 7 VALIDATION: In-Process Swarming Architecture")
    print("=" * 60)

    await test_agent_context()
    await test_event_bus()
    await test_scheduler()
    await test_state_machine()
    await test_gateway_integration()
    await test_full_agent_lifecycle()
    await test_swarming_collaboration()

    print("\n" + "=" * 60)
    total = PASS + FAIL
    print(f"  RESULTS: {PASS}/{total} passed, {FAIL} failed")
    if FAIL == 0:
        print("  ✅ PHASE 7 FULLY VALIDATED")
    else:
        print("  ⚠️  SOME TESTS FAILED — review above")
    print("=" * 60)

    return FAIL == 0


if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)