#!/usr/bin/env python3
"""
Test vLLM integration with orchestrator.
This script tests that the orchestrator can properly communicate with vLLM backend.
"""

import asyncio
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.llm_engine import LLMEngine
from core.orchestrator import Orchestrator
from core.context import ExecutionContext
from core.routing.backend_client import BackendClient
from enterprise.egl.backend_router import EGLBackendRouter, BackendSelection, BackendType
from tests.conftest import MockBackendRouter
from unittest.mock import Mock, AsyncMock
import json

async def test_backend_client_vllm():
    """Test that BackendClient can call vLLM correctly."""
    print("🧪 Testing BackendClient vLLM integration...")
    
    # Create a mock LLM engine
    mock_engine = Mock(spec=LLMEngine)
    
    # Mock the call_vllm method to return test data
    async def mock_call_vllm(model, messages, tools=None, options=None, timeout=None):
        # Simulate vLLM streaming response
        test_chunks = [
            {"choices": [{"delta": {"content": "Hello"}}]},
            {"choices": [{"delta": {"content": " world"}}]},
            {"choices": [{"delta": {"content": "!"}}]}
        ]
        for chunk in test_chunks:
            yield chunk
            await asyncio.sleep(0.01)
    
    mock_engine.call_vllm = mock_call_vllm
    
    # Create BackendClient
    client = BackendClient(llm_engine=mock_engine)
    
    # Create a mock selection
    selection = Mock()
    selection.backend_id = "expert_gpu"
    selection.backend_type = BackendType.VLLM
    selection.model = "Qwen/Qwen2.5-7B-Instruct"
    selection.endpoint = "http://127.0.0.1:8001/v1"
    
    # Test the call
    messages = [{"role": "user", "content": "Say hello"}]
    trace_id = "test-trace-123"
    
    chunks = []
    async for chunk in client.call(selection, messages, trace_id):
        chunks.append(chunk)
    
    print(f"✅ BackendClient returned {len(chunks)} chunks")
    print(f"   Chunks: {chunks}")
    
    # Verify we got the expected chunks
    assert len(chunks) == 3, f"Expected 3 chunks, got {len(chunks)}"
    assert chunks[0]["choices"][0]["delta"]["content"] == "Hello"
    
    return True

async def test_orchestrator_vllm_flow():
    """Test orchestrator's vLLM integration flow."""
    print("\n🧪 Testing orchestrator vLLM flow...")
    
    # Create mock components
    mock_llm_engine = Mock(spec=LLMEngine)
    mock_context_manager = Mock()
    mock_tool_executor = Mock()
    
    # Mock context manager methods
    mock_context_manager.load_context = AsyncMock(return_value={
        "chat_history": []
    })
    mock_context_manager.is_stepwise_enabled = Mock(return_value=False)
    
    # Mock tool executor
    mock_tool_executor.execute = AsyncMock(return_value={"success": True, "content": "Tool executed"})
    
    # Create orchestrator
    orchestrator = Orchestrator(
        llm_engine=mock_llm_engine,
        context_manager=mock_context_manager,
        tool_executor=mock_tool_executor,
        models_config={},
        backend_router=MockBackendRouter()
    )
    
    # Mock the backend router to return vLLM selection
    mock_selection = Mock()
    mock_selection.backend_id = "expert_gpu"
    mock_selection.backend_type = BackendType.VLLM
    mock_selection.model = "Qwen/Qwen2.5-7B-Instruct"
    mock_selection.endpoint = "http://127.0.0.1:8001/v1"
    
    orchestrator.backend_router.select_backend = AsyncMock(return_value=mock_selection)
    
    # Mock the backend client
    mock_backend_client = Mock()
    
    async def mock_call(selection, messages, trace_id):
        # Simulate vLLM response
        yield "Hello"
        yield " world"
        yield "!"
    
    mock_backend_client.call = mock_call
    orchestrator.backend_client = mock_backend_client
    
    # Create execution context
    context = ExecutionContext(
        session_id="test-session",
        tenant_id="business",
        mode="business",
        trace_id="test-trace-123"
    )
    
    # Test process_message
    user_message = "Say hello"
    
    # We'll just test that it doesn't crash
    try:
        response_chunks = []
        async for chunk in orchestrator.process_message(user_message, context):
            response_chunks.append(chunk)
        
        print(f"✅ Orchestrator processed message without errors")
        print(f"   Generated {len(response_chunks)} SSE chunks")
        
        # Check that we got some response
        assert len(response_chunks) > 0, "No response generated"
        
        return True
    except Exception as e:
        print(f"❌ Orchestrator failed: {e}")
        import traceback
        traceback.print_exc()
        return False

async def test_real_vllm_connection():
    """Test actual connection to vLLM service."""
    print("\n🧪 Testing real vLLM connection...")
    
    try:
        import aiohttp
        import asyncio
        
        vllm_url = "http://127.0.0.1:8001/v1/models"
        
        async with aiohttp.ClientSession() as session:
            try:
                async with session.get(vllm_url, timeout=2) as response:
                    if response.status == 200:
                        data = await response.json()
                        print(f"✅ vLLM service is reachable at {vllm_url}")
                        print(f"   Available models: {data.get('data', [])}")
                        return True
                    else:
                        print(f"⚠️  vLLM returned status {response.status}")
                        return False
            except asyncio.TimeoutError:
                print("❌ vLLM connection timeout - service may not be running")
                return False
            except Exception as e:
                print(f"❌ vLLM connection error: {e}")
                return False
    except ImportError:
        print("⚠️  aiohttp not available, skipping real connection test")
        return None

async def main():
    """Run all tests."""
    print("🚀 Starting vLLM integration tests...")
    
    # Test 1: BackendClient vLLM integration
    test1_passed = await test_backend_client_vllm()
    
    # Test 2: Orchestrator vLLM flow
    test2_passed = await test_orchestrator_vllm_flow()
    
    # Test 3: Real vLLM connection (optional)
    test3_result = await test_real_vllm_connection()
    
    # Summary
    print("\n" + "="*50)
    print("TEST SUMMARY:")
    print(f"  BackendClient vLLM integration: {'✅ PASS' if test1_passed else '❌ FAIL'}")
    print(f"  Orchestrator vLLM flow: {'✅ PASS' if test2_passed else '❌ FAIL'}")
    
    if test3_result is not None:
        print(f"  Real vLLM connection: {'✅ PASS' if test3_result else '❌ FAIL'}")
    else:
        print(f"  Real vLLM connection: ⚠️  SKIPPED")
    
    all_passed = test1_passed and test2_passed
    if test3_result is not None:
        all_passed = all_passed and test3_result
    
    if all_passed:
        print("\n🎉 All tests passed! vLLM integration is working.")
    else:
        print("\n⚠️  Some tests failed. Check the logs above.")
    
    return all_passed

if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)