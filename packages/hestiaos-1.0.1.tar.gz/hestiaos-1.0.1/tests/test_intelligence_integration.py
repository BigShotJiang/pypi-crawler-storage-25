import asyncio
import pytest
import logging
from unittest.mock import MagicMock, patch

# Logging konfigurieren
logging.basicConfig(level=logging.INFO)

from core.intelligence.manager import IntelligenceManager
from core.intelligence.sources.base import RawSignal, DataSource
from core.ir.models import ExecutionGraphIR, NodeType, EdgeType
from core.scheduler.cron_intelligence import CronJob

class MockSource(DataSource):
    @property
    def name(self) -> str:
        return "mock_source"
        
    def fetch(self):
        return [
            RawSignal(
                source="mock_source",
                title="Breakthrough in Autonomous Agents",
                description="New research shows how agents can govern themselves using HestiaOS.",
                url="https://example.com/agents",
                timestamp="2026-05-07T12:00:00Z",
                metadata={}
            )
        ]

class MockContainer:
    def __init__(self, graph):
        self.graph = graph

@pytest.mark.asyncio
async def test_intelligence_full_pipeline_integration():
    """
    Testet den vollständigen Durchlauf: 
    Source -> Analyzer -> Compiler -> IR Integration.
    """
    # 1. Setup Graph und AppState
    from core.ir.models import ExecutionNode, NodeType, GraphScope
    
    agent_cap = ExecutionNode(
        node_id="capability:agent",
        node_type=NodeType.CAPABILITY,
        label="Agentic Reasoning",
        scope=GraphScope.ARCHITECTURE
    )
    
    graph = ExecutionGraphIR(
        graph_id="test_intel_graph",
        source="integration_test",
        timestamp="2026-05-07T12:00:00Z",
        nodes={"capability:agent": agent_cap}
    )
    
    app_state = MagicMock()
    app_state.container = MockContainer(graph)
    
    # 2. Manager initialisieren
    manager = IntelligenceManager(app_state=app_state)
    
    # 3. Mock Source injizieren (via Patching des _get_source_instance)
    with patch.object(manager, '_get_source_instance', return_value=MockSource()):
        # Erstelle einen Test-Job
        job = CronJob(
            name="test_intel_job",
            cron_expr="* * * * *",
            handler=manager._external_source_handler,
            metadata={"source": "mock_source"}
        )
        
        # 4. Handler direkt ausführen
        result = await manager._external_source_handler(job)
        
        # 5. Verifikation
        assert result["status"] == "success"
        assert result["signals_count"] == 1
        assert result["relevant_count"] == 1
        assert result["tickets_created"] == 1
        
        # 6. IR-Graph Prüfung
        # Wir müssen den Graphen aus dem app_state holen, da er im Manager aktualisiert wurde
        graph = app_state.container.graph
        
        # Prüfe ob Signal-Node existiert
        signal_nodes = [n for n in graph.nodes.values() if n.node_type == NodeType.INTELLIGENCE_SIGNAL]
        assert len(signal_nodes) == 1
        assert "Breakthrough in Autonomous Agents" in signal_nodes[0].label
        
        # Prüfe ob Ticket-Node existiert (via Edges)
        derives_edges = [e for e in graph.edges if e.edge_type == EdgeType.DERIVES]
        assert len(derives_edges) == 1
        
        ticket_id = derives_edges[0].target_id
        assert ticket_id.startswith("INTEL-")
        
        print(f"\n✅ Integration Test Successful!")
        print(f"   Created Node: {signal_nodes[0].node_id} ({signal_nodes[0].label})")
        print(f"   Created Edge: {derives_edges[0].source_id} --[DERIVES]--> {derives_edges[0].target_id}")

if __name__ == "__main__":
    asyncio.run(test_intelligence_full_pipeline_integration())
