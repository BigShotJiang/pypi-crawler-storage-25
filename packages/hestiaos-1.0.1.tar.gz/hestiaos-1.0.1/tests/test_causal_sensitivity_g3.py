"""
INV-G3-CST: Causal Sensitivity Test (Actor Transition)
Verifiziert die deterministische Entscheidungsänderung durch kausale Signale.
"""

import pytest
from core.governance.causal_kernel import causal_kernel, CausalImpactReport, CausalBias
from core.governance.dsgk_decision import build_decision
from core.bootstrap.control_plane import CanonicalState, SystemCondition, SystemSignals
from core.bootstrap.models import BootState
from core.bootstrap.arbitrator import SystemArbitrator, ArbitrationResult
from core.processing.network_error_classifier import CircuitState

def test_causal_actor_phase_transition():
    """Beweist den Übergang vom Observer zum Actor."""
    arb = SystemArbitrator(g3_active=False)
    
    # 1. Baseline: High Risk, but G3 is OFF
    # Ein normalerweise erlaubter Command
    decision = build_decision(violations=[], risk_score=0.1, policy="core.test.v1")
    signals = SystemSignals(boot_state=BootState.READY, db_ready=True, migrations_ok=True)
    state = CanonicalState(condition=SystemCondition.GREEN, priority_vector=[0,0,0,0,0], signals=signals)
    
    # Simuliertes hohes Risiko aus G3
    high_risk_report = CausalImpactReport(risk_projection=0.9, confidence=1.0)
    
    # Durchlauf mit G3 OFF
    outcome_off = arb.arbitrate(
        dsgk=decision,
        control_state=state,
        circuit_state=CircuitState.CLOSED,
        drift_vector=None,
        causal_report=high_risk_report
    )
    
    assert outcome_off.result == ArbitrationResult.ALLOW
    assert outcome_off.authority == "KERNEL"
    
    # 2. Perturbation: G3 is ON
    arb.g3_active = True
    outcome_on = arb.arbitrate(
        dsgk=decision,
        control_state=state,
        circuit_state=CircuitState.CLOSED,
        drift_vector=None,
        causal_report=high_risk_report
    )
    
    # Erwarteter Phase Transition: ALLOW -> THROTTLE
    assert outcome_on.result == ArbitrationResult.THROTTLE
    assert outcome_on.authority == "CAUSAL_GOVERNANCE"
    assert outcome_on.reason == "HIGH_PROJECTED_RISK"
    assert "Causal Override" in outcome_on.message

def test_causal_sensitivity_threshold():
    """Prüft ob der Arbitrator unterhalb des Schwellenwerts stabil bleibt."""
    arb = SystemArbitrator(g3_active=True)
    decision = build_decision(violations=[], policy="core.test.v1")
    signals = SystemSignals(boot_state=BootState.READY, db_ready=True, migrations_ok=True)
    state = CanonicalState(condition=SystemCondition.GREEN, priority_vector=[0,0,0,0,0], signals=signals)
    
    # Risiko unter Schwellenwert (0.3 < 0.5)
    low_risk_report = CausalImpactReport(risk_projection=0.3, confidence=1.0)
    
    outcome = arb.arbitrate(
        dsgk=decision,
        control_state=state,
        circuit_state=CircuitState.CLOSED,
        drift_vector=None,
        causal_report=low_risk_report
    )
    
    assert outcome.result == ArbitrationResult.ALLOW
    assert outcome.authority == "KERNEL"

def test_causal_determinism_replay():
    """Prüft die deterministische Wiederholbarkeit der Entscheidung."""
    arb = SystemArbitrator(g3_active=True)
    decision = build_decision(violations=[], policy="core.test.v1")
    signals = SystemSignals(boot_state=BootState.READY, db_ready=True, migrations_ok=True)
    state = CanonicalState(condition=SystemCondition.GREEN, priority_vector=[0,0,0,0,0], signals=signals)
    report = CausalImpactReport(risk_projection=0.7, confidence=1.0)
    
    outcomes = [
        arb.arbitrate(dsgk=decision, control_state=state, causal_report=report).result
        for _ in range(10)
    ]
    
    assert all(res == ArbitrationResult.THROTTLE for res in outcomes)

def test_causal_monotonicity_and_smooth_degradation():
    """INV-G3-005: risk ↑ → performance ↓ (Monotonie)."""
    arb = SystemArbitrator(g3_active=True)
    decision = build_decision(violations=[], policy="core.test.v1")
    signals = SystemSignals(boot_state=BootState.READY, db_ready=True, migrations_ok=True)
    state = CanonicalState(condition=SystemCondition.GREEN, priority_vector=[0,0,0,0,0], signals=signals)
    
    # Test-Sequenz mit steigendem Risiko (alle unterhalb des 0.5 Thresholds)
    risks = [0.0, 0.1, 0.2, 0.3, 0.4]
    outcomes = [
        arb.arbitrate(dsgk=decision, control_state=state, causal_report=CausalImpactReport(risk_projection=r))
        for r in risks
    ]
    
    perf_factors = [o.performance_factor for o in outcomes]
    
    # 1. Monotonie-Check
    for i in range(len(perf_factors) - 1):
        assert perf_factors[i+1] < perf_factors[i], f"Monotonie verletzt bei risk={risks[i+1]}"
    
    # 2. Safety Separation Check (Decision must stay ALLOW)
    assert all(o.result == ArbitrationResult.ALLOW for o in outcomes)
    
    # 3. Smoothness Check (keine massiven Sprünge bei kleinen Risikodifferenzen)
    # λ=0.4 → Δrisk=0.1 sollte Δpf=0.04 entsprechen
    for i in range(len(perf_factors) - 1):
        diff = perf_factors[i] - perf_factors[i+1]
        assert 0.03 < diff < 0.05, f"Smoothness verletzt bei risk={risks[i+1]}"

def test_causal_boundary_persistence():
    """Prüft ob der Hard Threshold (0.5) trotz Damping korrekt umschaltet."""
    arb = SystemArbitrator(g3_active=True)
    decision = build_decision(violations=[], policy="core.test.v1")
    signals = SystemSignals(boot_state=BootState.READY, db_ready=True, migrations_ok=True)
    state = CanonicalState(condition=SystemCondition.GREEN, priority_vector=[0,0,0,0,0], signals=signals)
    
    # Knapp unter dem Limit
    o_low = arb.arbitrate(dsgk=decision, control_state=state, causal_report=CausalImpactReport(risk_projection=0.49))
    # Knapp über dem Limit
    o_high = arb.arbitrate(dsgk=decision, control_state=state, causal_report=CausalImpactReport(risk_projection=0.51))
    
    assert o_low.result == ArbitrationResult.ALLOW
    assert o_high.result == ArbitrationResult.THROTTLE
