"""
Drift-Injection Suite für CI-CRT-014: Policy Drift Detection.

Systematischer Fuzzing-Ansatz:
1. Definiere Drift-Templates (Drift A + B Varianten)
2. Injiziere sie in "sauberen" Code
3. Prüfe, ob der Detector sie erkennt
4. Generiere Confidence-Report

Phase 2a: Shadow Mode — Validierung vor HARD-Enforcement.
"""

import ast
import json
import itertools
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple, Any, Callable

from scripts.check_crt_compliance import (
    PolicyDriftVisitor,
    REPO_ROOT,
)


# =============================================================================
# Template-System: Code-Generatoren für Drift-Varianten
# =============================================================================

# Basis-Template: Sauberer Code ohne Drift
CLEAN_TEMPLATE = """
async def execute():
    allowed = await provider.allow("tool", {{context}})
    if not allowed:
        {{denial_body}}
    return {{allow_body}}
"""

# Basis-Template: Sync allow()
CLEAN_TEMPLATE_SYNC = """
def execute():
    allowed = provider.allow("tool", {{context}})
    if not allowed:
        {{denial_body}}
    return {{allow_body}}
"""

# Basis-Template: Mit Negation (A1)
CLEAN_TEMPLATE_NEGATION = """
async def execute():
    allowed = await provider.allow("tool", {{context}})
    blocked = not allowed
    if blocked:
        {{denial_body}}
    return {{allow_body}}
"""

# Basis-Template: Mit Chain (A1c)
CLEAN_TEMPLATE_CHAIN = """
async def execute():
    allowed = await provider.allow("tool", {{context}})
    blocked = not allowed
    flag = blocked
    if flag:
        {{denial_body}}
    return {{allow_body}}
"""

# Basis-Template: Mit Boolean Expression (A1d)
CLEAN_TEMPLATE_BOOLEAN = """
async def execute():
    allowed = await provider.allow("tool", {{context}})
    blocked = not allowed or some_condition
    if blocked:
        {{denial_body}}
    return {{allow_body}}
"""

# Basis-Template: Mit Split Assignment (B3)
CLEAN_TEMPLATE_SPLIT = """
async def execute():
    decision = await provider.allow("tool", {{context}})
    x = decision
    if not x:
        {{denial_body}}
    return {{allow_body}}
"""

# Basis-Template: Mit Tuple Assignment (B3b)
CLEAN_TEMPLATE_TUPLE = """
async def execute():
    decision = await provider.allow("tool", {{context}})
    x, y = decision, something
    if not x:
        {{denial_body}}
    return {{allow_body}}
"""


# =============================================================================
# Drift A — Templates (Policy Feedback)
# =============================================================================

DRIFT_A_VARIANTS: Dict[str, str] = {
    # Direkte Verstöße
    "retry_same_tool": """
        result = await execute_tool("tool", {})
        return {"success": True, "content": result}
    """,
    "retry_alternative_tool": """
        result = await execute_tool("other_tool", {})
        return {"success": True, "content": result}
    """,
    "fallback_tool": """
        result = await fallback_execute("tool", {})
        return {"success": True, "content": result}
    """,
    "state_mutation": """
        self.retry_count += 1
        return {"success": False, "error": "ExecutionBlocked", "content": None}
    """,
    "callback_notify": """
        await notify_admin("Policy denied tool")
        return {"success": False, "error": "ExecutionBlocked", "content": None}
    """,
    "complex_forbidden": """
        logger.warning("Policy denied")
        result = await execute_tool("other_tool", {})
        return {"success": True, "content": result}
    """,
    "return_non_execution_blocked": """
        return {"success": False, "error": "SomeOtherError", "content": None}
    """,
    "raise_non_execution_blocked": """
        raise SomeOtherError("not allowed")
    """,
    "return_none": """
        return None
    """,
    "return_empty_dict": """
        return {}
    """,
    "return_string": """
        return "blocked"
    """,
    "return_bool": """
        return False
    """,
    "raise_generic": """
        raise Exception("blocked")
    """,
    "call_external_api": """
        await external_api.notify("denied")
        return {"success": False, "error": "ExecutionBlocked", "content": None}
    """,
    "write_to_database": """
        await db.save({"status": "denied"})
        return {"success": False, "error": "ExecutionBlocked", "content": None}
    """,
    "modify_global_state": """
        global_state.denied_count += 1
        return {"success": False, "error": "ExecutionBlocked", "content": None}
    """,
    "yield_value": """
        yield "blocked"
    """,
    "send_message": """
        await websocket.send({"type": "denied"})
        return {"success": False, "error": "ExecutionBlocked", "content": None}
    """,
    "increment_counter": """
        counter += 1
        return {"success": False, "error": "ExecutionBlocked", "content": None}
    """,
    "delegate_to_handler": """
        return handle_denial()
    """,
    "return_function_call": """
        return process_denial()
    """,
    "conditional_retry": """
        if retry_count < 3:
            result = await execute_tool("tool", {})
            return {"success": True, "content": result}
        return {"success": False, "error": "ExecutionBlocked", "content": None}
    """,
    "loop_retry": """
        for i in range(3):
            result = await execute_tool("tool", {})
            if result["success"]:
                return result
        return {"success": False, "error": "ExecutionBlocked", "content": None}
    """,
    "async_generator_yield": """
        async for item in async_fallback():
            yield item
    """,
    "context_manager_alternative": """
        async with alternative_session() as session:
            result = await session.execute("tool", {})
            return {"success": True, "content": result}
    """,
    "set_timeout_retry": """
        await asyncio.sleep(1)
        result = await execute_tool("tool", {})
        return {"success": True, "content": result}
    """,
    "cache_and_retry": """
        cached = cache.get("tool_result")
        if cached:
            return {"success": True, "content": cached}
        result = await execute_tool("tool", {})
        return {"success": True, "content": result}
    """,
    "event_emit": """
        await event_bus.emit("tool_denied", {"tool": "tool"})
        return {"success": False, "error": "ExecutionBlocked", "content": None}
    """,
    "metric_record": """
        metrics.record("tool_denied", 1)
        return {"success": False, "error": "ExecutionBlocked", "content": None}
    """,
}


# =============================================================================
# Drift B — Templates (Policy State)
# =============================================================================

DRIFT_B_VARIANTS: Dict[str, str] = {
    # Direkte State Writes
    "self_attribute_write": """
        decision = await provider.allow("tool", {})
        self.last_decision = decision
        if not decision:
            return {"success": False, "error": "ExecutionBlocked", "content": None}
    """,
    "metadata_dict_write": """
        decision = await provider.allow("tool", {})
        metadata["allowed"] = decision
        if not decision:
            return {"success": False, "error": "ExecutionBlocked", "content": None}
    """,
    "cache_dict_write": """
        decision = await provider.allow("tool", {})
        cache["decision"] = decision
        if not decision:
            return {"success": False, "error": "ExecutionBlocked", "content": None}
    """,
    "context_dict_write": """
        decision = await provider.allow("tool", {})
        context["allowed"] = decision
        if not decision:
            return {"success": False, "error": "ExecutionBlocked", "content": None}
    """,
    "state_dict_write": """
        decision = await provider.allow("tool", {})
        state["policy"] = decision
        if not decision:
            return {"success": False, "error": "ExecutionBlocked", "content": None}
    """,
    "store_dict_write": """
        decision = await provider.allow("tool", {})
        store["allowed"] = decision
        if not decision:
            return {"success": False, "error": "ExecutionBlocked", "content": None}
    """,
    # Indirekte State Writes (B3)
    "split_self_write": """
        decision = await provider.allow("tool", {})
        x = decision
        self.cached = x
        if not decision:
            return {"success": False, "error": "ExecutionBlocked", "content": None}
    """,
    "split_metadata_write": """
        decision = await provider.allow("tool", {})
        x = decision
        metadata["cached"] = x
        if not decision:
            return {"success": False, "error": "ExecutionBlocked", "content": None}
    """,
    "tuple_self_write": """
        decision = await provider.allow("tool", {})
        x, y = decision, something
        self.cached = x
        if not decision:
            return {"success": False, "error": "ExecutionBlocked", "content": None}
    """,
    "tuple_metadata_write": """
        decision = await provider.allow("tool", {})
        x, y = decision, something
        metadata["cached"] = x
        if not decision:
            return {"success": False, "error": "ExecutionBlocked", "content": None}
    """,
    # Sync allow() Varianten
    "sync_self_write": """
        decision = provider.allow("tool", {})
        self.last_decision = decision
        if not decision:
            return {"success": False, "error": "ExecutionBlocked", "content": None}
    """,
    "sync_metadata_write": """
        decision = provider.allow("tool", {})
        metadata["allowed"] = decision
        if not decision:
            return {"success": False, "error": "ExecutionBlocked", "content": None}
    """,
    # Negation + State Write (A1 + B kombiniert)
    "negation_self_write": """
        allowed = await provider.allow("tool", {})
        blocked = not allowed
        self.is_blocked = blocked
        if blocked:
            return {"success": False, "error": "ExecutionBlocked", "content": None}
    """,
    "negation_metadata_write": """
        allowed = await provider.allow("tool", {})
        blocked = not allowed
        metadata["blocked"] = blocked
        if blocked:
            return {"success": False, "error": "ExecutionBlocked", "content": None}
    """,
    # Boolean Expression + State Write (A1d + B kombiniert)
    "boolean_self_write": """
        allowed = await provider.allow("tool", {})
        blocked = not allowed or some_condition
        self.is_blocked = blocked
        if blocked:
            return {"success": False, "error": "ExecutionBlocked", "content": None}
    """,
    "boolean_metadata_write": """
        allowed = await provider.allow("tool", {})
        blocked = not allowed or some_condition
        metadata["blocked"] = blocked
        if blocked:
            return {"success": False, "error": "ExecutionBlocked", "content": None}
    """,
}


# =============================================================================
# "Almost Clean" — Subtile Drift-Varianten (Phase 2d)
# =============================================================================

ALMOST_CLEAN_VARIANTS: Dict[str, Tuple[str, bool]] = {
    # (code, is_drift) — is_drift=True bedeutet: sollte erkannt werden
    "clean_log_and_return": (
        """
async def execute():
    allowed = await provider.allow("tool", {})
    if not allowed:
        logger.warning("Policy denied")
        return {"success": False, "error": "ExecutionBlocked", "content": None}
    return {"success": True, "content": result}
""",
        False,
    ),
    "subtle_drift_log_and_retry": (
        """
async def execute():
    allowed = await provider.allow("tool", {})
    if not allowed:
        logger.warning("Policy denied")
        result = await execute_tool("other_tool", {})
        return {"success": True, "content": result}
    return {"success": True, "content": result}
""",
        True,
    ),
    "clean_trace_and_return": (
        """
async def execute():
    allowed = await provider.allow("tool", {})
    if not allowed:
        trace_policy_decision("tool", False, "provider", "session_1")
        return {"success": False, "error": "ExecutionBlocked", "content": None}
    return {"success": True, "content": result}
""",
        False,
    ),
    "subtle_drift_trace_and_fallback": (
        """
async def execute():
    allowed = await provider.allow("tool", {})
    if not allowed:
        trace_policy_decision("tool", False, "provider", "session_1")
        result = await fallback_execute("tool", {})
        return {"success": True, "content": result}
    return {"success": True, "content": result}
""",
        True,
    ),
    "clean_pass_only": (
        """
async def execute():
    allowed = await provider.allow("tool", {})
    if not allowed:
        pass
    return {"success": True, "content": result}
""",
        # ❌ A3 (Non-Terminating Denial): pass ist nicht terminal.
        # Auch wenn nach dem if-Block nur ein return kommt — AST kann nicht
        # beweisen, dass dieser Pfad nur bei allowed=True erreicht wird.
        # Konservative Regel: Nur return/raise im Denial-Block ist terminal.
        True,
    ),
    "subtle_drift_pass_and_continue": (
        """
async def execute():
    allowed = await provider.allow("tool", {})
    if not allowed:
        pass
    result = await execute_tool("tool", {})
    return {"success": True, "content": result}
""",
        # ✅ A3 (Non-Terminating Denial): pass ist nicht terminal → Execution
        # läuft weiter → execute_tool() wird trotz Denial ausgeführt.
        True,
    ),
    "clean_print_and_return": (
        """
async def execute():
    allowed = await provider.allow("tool", {})
    if not allowed:
        print("Denied")
        return {"success": False, "error": "ExecutionBlocked", "content": None}
    return {"success": True, "content": result}
""",
        False,
    ),
    "subtle_drift_print_and_continue": (
        """
async def execute():
    allowed = await provider.allow("tool", {})
    if not allowed:
        print("Denied")
    result = await execute_tool("tool", {})
    return {"success": True, "content": result}
""",
        # ✅ A3 (Non-Terminating Denial): print ist erlaubter Side Effect,
        # aber kein return/raise → Block ist nicht terminal → Execution
        # läuft weiter → execute_tool() wird trotz Denial ausgeführt.
        True,
    ),
    "clean_raise_execution_blocked": (
        """
async def execute():
    allowed = await provider.allow("tool", {})
    if not allowed:
        raise ExecutionBlocked("blocked")
    return {"success": True, "content": result}
""",
        False,
    ),
    "subtle_drift_raise_and_log": (
        """
async def execute():
    allowed = await provider.allow("tool", {})
    if not allowed:
        logger.warning("Denied")
        raise ExecutionBlocked("blocked")
    return {"success": True, "content": result}
""",
        False,  # raise ExecutionBlocked ist Termination — erlaubt
    ),
    "subtle_drift_log_and_state_write": (
        """
async def execute():
    allowed = await provider.allow("tool", {})
    if not allowed:
        logger.warning("Denied")
        self.denied_count += 1
        return {"success": False, "error": "ExecutionBlocked", "content": None}
    return {"success": True, "content": result}
""",
        True,  # self.denied_count += 1 ist Drift A (State Mutation im Denial-Block)
    ),
    "subtle_drift_binary_flag_denial": (
        """
async def execute():
    allowed = await provider.allow("tool", {})
    if not allowed:
        metadata["blocked"] = True
        return {"success": False, "error": "ExecutionBlocked", "content": None}
    return {"success": True, "content": result}
""",
        False,  # Binary Flag ist erlaubt (kein allow()-Ergebnis)
    ),

    # =========================================================================
    # Phase 2d — Adversarial Calibration Packs
    # =========================================================================
    #
    # Drei fokussierte Packs, die die Entscheidungsgrenze des Detektors
    # kalibrieren. Keine "Variantenexplosion" — nur semantisch relevante
    # Grenzfälle.
    #
    # Pack 1: A3 Boundary — Non-Termination jenseits von `pass`
    # Pack 2: Return Semantics — success/error-Feld-Semantik
    # Pack 3: B Drift Isolation — State Write + Termination Ordering
    # =========================================================================

    # -------------------------------------------------------------------------
    # Pack 1: A3 Boundary (4 Fälle)
    # -------------------------------------------------------------------------
    # Ziel: Validieren, dass alle syntaktischen Formen von Non-Termination
    # korrekt als A3 erkannt werden. A3 = "Denial-Block terminiert nicht den
    # Control Flow". Jede Form von "kein return/raise" ist A3, unabhängig
    # vom konkreten Statement-Typ.
    # -------------------------------------------------------------------------

    "a3_sleep_only": (
        """
async def execute():
    allowed = await provider.allow("tool", {})
    if not allowed:
        await asyncio.sleep(1)
    return {"success": True, "content": result}
""",
        # A3: sleep ist kein return/raise → non-terminal
        True,
    ),
    "a3_ellipsis_only": (
        """
async def execute():
    allowed = await provider.allow("tool", {})
    if not allowed:
        ...
    return {"success": True, "content": result}
""",
        # A3: Ellipsis ist syntaktischer No-Op → non-terminal
        True,
    ),
    "a3_docstring_only": (
        """
async def execute():
    allowed = await provider.allow("tool", {})
    if not allowed:
        \"\"\"This should not happen.\"\"\"
    return {"success": True, "content": result}
""",
        # A3: Docstring ist Expr-Statement ohne Effekt → non-terminal
        True,
    ),
    "a3_logging_only": (
        """
async def execute():
    allowed = await provider.allow("tool", {})
    if not allowed:
        logger.warning("Policy denied tool")
    return {"success": True, "content": result}
""",
        # A3: logging ist erlaubter Side Effect, aber kein return/raise
        # → non-terminal. Logging allein terminiert nicht.
        True,
    ),

    # -------------------------------------------------------------------------
    # Pack 2: Return Semantics (4 Fälle)
    # -------------------------------------------------------------------------
    # Ziel: Validieren, dass die Return-Shape-Logik korrekt ist.
    # Nur `success=False + error=ExecutionBlocked` ist terminal.
    # Abweichungen in success/error-Feldern müssen als A3 erkannt werden.
    # -------------------------------------------------------------------------

    "return_success_false_no_error": (
        """
async def execute():
    allowed = await provider.allow("tool", {})
    if not allowed:
        return {"success": False}
    return {"success": True, "content": result}
""",
        # CLEAN: success=False ohne error-Key ist terminal-äquivalent.
        # Der Detector erlaubt success=False + (error=ExecutionBlocked ODER kein error-Key).
        False,
    ),
    "return_success_false_other_error": (
        """
async def execute():
    allowed = await provider.allow("tool", {})
    if not allowed:
        return {"success": False, "error": "RateLimitExceeded"}
    return {"success": True, "content": result}
""",
        # A3: success=False + error != ExecutionBlocked → kein terminaler
        # Denial-Block. Andere Errors sind Policy-Feedback.
        True,
    ),
    "return_success_true_with_error": (
        """
async def execute():
    allowed = await provider.allow("tool", {})
    if not allowed:
        return {"success": True, "error": "ExecutionBlocked"}
    return {"success": True, "content": result}
""",
        # A3: success=True + error → widersprüchlich, kein sauberer
        # Denial-Block. success=True bedeutet "Erfolg", kein Denial.
        True,
    ),
    "return_execution_blocked_canonical": (
        """
async def execute():
    allowed = await provider.allow("tool", {})
    if not allowed:
        return ExecutionBlocked
    return {"success": True, "content": result}
""",
        # CLEAN: return ExecutionBlocked (Name-Referenz) ist terminal.
        # Wird durch `isinstance(stmt.value, ast.Name)` erkannt.
        False,
    ),

    # -------------------------------------------------------------------------
    # Pack 3: B Drift Isolation (3 Fälle)
    # -------------------------------------------------------------------------
    # Ziel: Validieren, dass B-Drift (State Write) orthogonal zu A-Drift
    # (Termination) funktioniert. State Write + terminal return = B Drift,
    # aber A sauber. State Write ohne return = B + A3.
    # -------------------------------------------------------------------------

    "b_drift_state_write_before_return": (
        """
async def execute():
    allowed = await provider.allow("tool", {})
    if not allowed:
        self.last_denied = allowed
        return {"success": False, "error": "ExecutionBlocked", "content": None}
    return {"success": True, "content": result}
""",
        # B Drift: self.last_denied = allowed persistiert allow()-Resultat.
        # A ist sauber (terminal return). B und A sind orthogonal.
        True,
    ),
    "b_drift_state_write_after_return": (
        """
async def execute():
    allowed = await provider.allow("tool", {})
    if not allowed:
        return {"success": False, "error": "ExecutionBlocked", "content": None}
        self.last_denied = allowed
    return {"success": True, "content": result}
""",
        # B Drift: self.last_denied = allowed persistiert allow()-Resultat.
        # Auch wenn es Dead Code (nach return) ist — der Detektor hat kein
        # CFG-Bewusstsein und erkennt den Assign trotzdem als Drift B.
        # Das ist eine bekannte AST-Limitation (Phase 3/CFG).
        True,
    ),
    "b_drift_chained_from_decision_var": (
        """
async def execute():
    decision = await provider.allow("tool", {})
    if not decision:
        self.denied_tools.append("tool")
        return {"success": False, "error": "ExecutionBlocked", "content": None}
    return {"success": True, "content": result}
""",
        # Drift A (A3): self.denied_tools.append("tool") ist kein erlaubtes
        # Statement im Denial-Block. append() ist weder terminal (return/raise)
        # noch ein erlaubter Side Effect (logging/print/trace).
        # Zusätzlich: decision ist allow()-Resultat → potentiell B Drift,
        # aber der Detektor erkennt nur direkte Assigns als B Drift.
        # append() ist ein Methodenaufruf → wird als A3 (non-terminal) erkannt.
        True,
    ),
}


# =============================================================================
# Test-Runner
# =============================================================================


def _render_template(template: str, denial_body: str,
                     context: str = "{}", allow_body: str = "None") -> str:
    """Setzt ein Template mit Drift-Body zusammen."""
    code = template.replace("{{denial_body}}", denial_body.strip())
    code = code.replace("{{context}}", context)
    code = code.replace("{{allow_body}}", allow_body)
    return code


def _run_detector(source: str) -> Tuple[List[str], List[Dict[str, Any]]]:
    """Führt PolicyDriftVisitor auf Quellcode aus und gibt Warnungen + Drift-Einträge zurück.

    Bettet den Code in eine async def Funktion ein, falls er nicht bereits
    in einer Funktion ist. Dadurch wird sichergestellt, dass:
    - Einrückung korrekt ist
    - `await` auf Funktionsebene erlaubt ist
    - `return` und `yield` korrekt funktionieren
    """
    # Nur einbetten, wenn der Code nicht bereits in einer Funktion ist
    # (erkannt an "def " oder "async def " am Zeilenanfang)
    if "def " not in source and "async def " not in source:
        source = "async def _injected():\n" + source

    try:
        tree = ast.parse(source)
    except SyntaxError:
        return ["[SYNTAX ERROR]"], []

    visitor = PolicyDriftVisitor(Path("injection_test.py"), verbose=False)
    visitor.visit(tree)
    return visitor.warnings, visitor.drift_entries


def _classify_drift(entries: List[Dict[str, Any]]) -> Tuple[int, int]:
    """Klassifiziert Drift-Einträge in A und B."""
    drift_a = sum(1 for e in entries if e.get("drift_type") == "A")
    drift_b = sum(1 for e in entries if e.get("drift_type") == "B")
    return drift_a, drift_b


# =============================================================================
# Injection Test: Drift A Varianten
# =============================================================================

def test_drift_a_injection_all_variants():
    """Testet ALLE Drift A Varianten gegen den Detector.

    Erwartung: Jede Variante muss erkannt werden (≥1 Drift A Warning).
    """
    results: Dict[str, bool] = {}
    failures: List[str] = []

    for variant_name, denial_body in DRIFT_A_VARIANTS.items():
        source = _render_template(CLEAN_TEMPLATE, denial_body)
        warnings, entries = _run_detector(source)
        drift_a, drift_b = _classify_drift(entries)

        detected = drift_a > 0
        results[variant_name] = detected
        if not detected:
            failures.append(f"  ❌ {variant_name}: NICHT erkannt (0 Drift A)")

    total = len(results)
    detected_count = sum(1 for v in results.values() if v)
    print(f"\n  Drift A Injection: {detected_count}/{total} erkannt")
    for f in failures:
        print(f)

    # Mindestanforderung: ≥80% Detection Rate für Drift A
    rate = detected_count / total if total > 0 else 0
    assert rate >= 0.80, (
        f"Detection Rate zu niedrig: {rate:.0%} ({detected_count}/{total})\n"
        f"Nicht erkannt:\n" + "\n".join(failures)
    )


def test_drift_a_injection_retry_variants():
    """Fokussierter Test: Alle Retry-Varianten müssen erkannt werden."""
    retry_variants = {
        k: v for k, v in DRIFT_A_VARIANTS.items()
        if "retry" in k or "fallback" in k or "alternative" in k
    }
    failures = []
    for name, body in retry_variants.items():
        source = _render_template(CLEAN_TEMPLATE, body)
        _, entries = _run_detector(source)
        drift_a, _ = _classify_drift(entries)
        if drift_a == 0:
            failures.append(name)

    assert len(failures) == 0, (
        f"Retry-Varianten nicht erkannt: {failures}"
    )


def test_drift_a_injection_non_termination_variants():
    """Fokussierter Test: Non-Termination (return/raise ohne ExecutionBlocked)."""
    non_term_variants = {
        k: v for k, v in DRIFT_A_VARIANTS.items()
        if "non_execution" in k or "none" in k or "empty" in k
        or "string" in k or "bool" in k or "generic" in k
    }
    failures = []
    for name, body in non_term_variants.items():
        source = _render_template(CLEAN_TEMPLATE, body)
        _, entries = _run_detector(source)
        drift_a, _ = _classify_drift(entries)
        if drift_a == 0:
            failures.append(name)

    assert len(failures) == 0, (
        f"Non-Termination-Varianten nicht erkannt: {failures}"
    )


# =============================================================================
# Injection Test: Drift B Varianten
# =============================================================================

def test_drift_b_injection_all_variants():
    """Testet ALLE Drift B Varianten gegen den Detector.

    Erwartung: Jede Variante muss erkannt werden (≥1 Drift B Warning).
    """
    results: Dict[str, bool] = {}
    failures: List[str] = []

    for variant_name, source_template in DRIFT_B_VARIANTS.items():
        source = source_template.replace("{{context}}", "{}")
        warnings, entries = _run_detector(source)
        drift_a, drift_b = _classify_drift(entries)

        detected = drift_b > 0
        results[variant_name] = detected
        if not detected:
            failures.append(f"  ❌ {variant_name}: NICHT erkannt (0 Drift B)")

    total = len(results)
    detected_count = sum(1 for v in results.values() if v)
    print(f"\n  Drift B Injection: {detected_count}/{total} erkannt")
    for f in failures:
        print(f)

    # Mindestanforderung: ≥80% Detection Rate für Drift B
    rate = detected_count / total if total > 0 else 0
    assert rate >= 0.80, (
        f"Detection Rate zu niedrig: {rate:.0%} ({detected_count}/{total})\n"
        f"Nicht erkannt:\n" + "\n".join(failures)
    )


def test_drift_b_injection_direct_writes():
    """Fokussierter Test: Direkte State Writes (self.*, metadata[...], etc.)."""
    direct_writes = {
        k: v for k, v in DRIFT_B_VARIANTS.items()
        if k.startswith("self_") or k.startswith("metadata_")
        or k.startswith("cache_") or k.startswith("context_")
        or k.startswith("state_") or k.startswith("store_")
    }
    failures = []
    for name, source_template in direct_writes.items():
        source = source_template.replace("{{context}}", "{}")
        _, entries = _run_detector(source)
        _, drift_b = _classify_drift(entries)
        if drift_b == 0:
            failures.append(name)

    assert len(failures) == 0, (
        f"Direkte State Writes nicht erkannt: {failures}"
    )


def test_drift_b_injection_split_writes():
    """Fokussierter Test: Split Assignment (B3) — indirekte State Writes."""
    split_writes = {
        k: v for k, v in DRIFT_B_VARIANTS.items()
        if "split" in k or "tuple" in k
    }
    failures = []
    for name, source_template in split_writes.items():
        source = source_template.replace("{{context}}", "{}")
        _, entries = _run_detector(source)
        _, drift_b = _classify_drift(entries)
        if drift_b == 0:
            failures.append(name)

    assert len(failures) == 0, (
        f"Split Assignment Writes nicht erkannt: {failures}"
    )


# =============================================================================
# Injection Test: Template-Varianten (Negation, Chain, Boolean, Split, Tuple)
# =============================================================================

def test_drift_a_across_templates():
    """Testet Drift A Erkennung über verschiedene Code-Strukturen hinweg.

    Der gleiche Drift (z.B. retry) muss in allen Templates erkannt werden.
    """
    templates = {
        "direct": CLEAN_TEMPLATE,
        "negation": CLEAN_TEMPLATE_NEGATION,
        "chain": CLEAN_TEMPLATE_CHAIN,
        "boolean": CLEAN_TEMPLATE_BOOLEAN,
        "split": CLEAN_TEMPLATE_SPLIT,
        "tuple": CLEAN_TEMPLATE_TUPLE,
    }

    #代表性 Drift A Varianten
    test_drifts = {
        "retry": DRIFT_A_VARIANTS["retry_same_tool"],
        "fallback": DRIFT_A_VARIANTS["fallback_tool"],
        "state_mutation": DRIFT_A_VARIANTS["state_mutation"],
        "non_execution_blocked": DRIFT_A_VARIANTS["return_non_execution_blocked"],
    }

    failures: List[str] = []
    for template_name, template in templates.items():
        for drift_name, drift_body in test_drifts.items():
            source = _render_template(template, drift_body)
            _, entries = _run_detector(source)
            drift_a, _ = _classify_drift(entries)
            if drift_a == 0:
                failures.append(f"{template_name}/{drift_name}")

    assert len(failures) == 0, (
        f"Drift A nicht in allen Templates erkannt:\n" + "\n".join(failures)
    )


def test_drift_b_across_templates():
    """Testet Drift B Erkennung über verschiedene Code-Strukturen hinweg."""
    templates = {
        "direct": CLEAN_TEMPLATE,
        "negation": CLEAN_TEMPLATE_NEGATION,
        "chain": CLEAN_TEMPLATE_CHAIN,
        "boolean": CLEAN_TEMPLATE_BOOLEAN,
        "split": CLEAN_TEMPLATE_SPLIT,
        "tuple": CLEAN_TEMPLATE_TUPLE,
    }

    # Drift B Varianten, die in verschiedenen Templates funktionieren
    test_drifts = {
        "self_write": """
        decision = await provider.allow("tool", {})
        self.last_decision = decision
        if not decision:
            return {"success": False, "error": "ExecutionBlocked", "content": None}
        """,
        "metadata_write": """
        decision = await provider.allow("tool", {})
        metadata["allowed"] = decision
        if not decision:
            return {"success": False, "error": "ExecutionBlocked", "content": None}
        """,
    }

    failures: List[str] = []
    for template_name, template in templates.items():
        for drift_name, drift_body in test_drifts.items():
            source = _render_template(template, drift_body)
            _, entries = _run_detector(source)
            _, drift_b = _classify_drift(entries)
            if drift_b == 0:
                failures.append(f"{template_name}/{drift_name}")

    assert len(failures) == 0, (
        f"Drift B nicht in allen Templates erkannt:\n" + "\n".join(failures)
    )


# =============================================================================
# "Almost Clean" Tests (Phase 2d)
# =============================================================================

def test_almost_clean_variants():
    """Testet subtile Drift-Varianten gegen "sauberen" Code.

    Validiert:
    1. Clean Code → keine False Positives
    2. Subtle Drift → Detection
    """
    false_positives: List[str] = []
    false_negatives: List[str] = []

    for name, (source, is_drift) in ALMOST_CLEAN_VARIANTS.items():
        warnings, entries = _run_detector(source)
        has_drift = len(warnings) > 0

        if is_drift and not has_drift:
            false_negatives.append(name)
        elif not is_drift and has_drift:
            false_positives.append(name)

    print(f"\n  Almost Clean: {len(ALMOST_CLEAN_VARIANTS)} Varianten")
    if false_positives:
        print(f"  ⚠️  False Positives: {false_positives}")
    if false_negatives:
        print(f"  ⚠️  False Negatives: {false_negatives}")

    # Clean Code muss 0 False Positives haben
    assert len(false_positives) == 0, (
        f"False Positives auf sauberem Code:\n" + "\n".join(false_positives)
    )

    # Subtle Drift muss erkannt werden
    assert len(false_negatives) == 0, (
        f"False Negatives (subtle Drift nicht erkannt):\n" + "\n".join(false_negatives)
    )


# =============================================================================
# Confidence Report Generator
# =============================================================================

def generate_confidence_report() -> Dict[str, Any]:
    """Generiert einen strukturierten Confidence-Report.

    Misst:
    - Detection Rate für Drift A (alle Varianten)
    - Detection Rate für Drift B (alle Varianten)
    - Template-Coverage (Drift A + B über alle Templates)
    - Almost-Clean Accuracy (0 FP, 0 FN)
    - Gesamt-Confidence-Score
    """
    report: Dict[str, Any] = {
        "tool": "test_crt_drift_injection.py",
        "phase": "2a (Shadow Mode Validation)",
        "timestamp": None,  # Wird vom Test-Runner gesetzt
        "metrics": {},
        "details": {},
        "verdict": None,
    }

    # --- Drift A Detection Rate ---
    drift_a_results: Dict[str, bool] = {}
    for variant_name, denial_body in DRIFT_A_VARIANTS.items():
        source = _render_template(CLEAN_TEMPLATE, denial_body)
        _, entries = _run_detector(source)
        drift_a, _ = _classify_drift(entries)
        drift_a_results[variant_name] = drift_a > 0

    drift_a_total = len(drift_a_results)
    drift_a_detected = sum(1 for v in drift_a_results.values() if v)
    drift_a_rate = drift_a_detected / drift_a_total if drift_a_total > 0 else 0.0

    report["metrics"]["drift_a_detection_rate"] = round(drift_a_rate, 4)
    report["metrics"]["drift_a_detected"] = drift_a_detected
    report["metrics"]["drift_a_total"] = drift_a_total
    report["details"]["drift_a_failures"] = [
        k for k, v in drift_a_results.items() if not v
    ]

    # --- Drift B Detection Rate ---
    drift_b_results: Dict[str, bool] = {}
    for variant_name, source_template in DRIFT_B_VARIANTS.items():
        source = source_template.replace("{{context}}", "{}")
        _, entries = _run_detector(source)
        _, drift_b = _classify_drift(entries)
        drift_b_results[variant_name] = drift_b > 0

    drift_b_total = len(drift_b_results)
    drift_b_detected = sum(1 for v in drift_b_results.values() if v)
    drift_b_rate = drift_b_detected / drift_b_total if drift_b_total > 0 else 0.0

    report["metrics"]["drift_b_detection_rate"] = round(drift_b_rate, 4)
    report["metrics"]["drift_b_detected"] = drift_b_detected
    report["metrics"]["drift_b_total"] = drift_b_total
    report["details"]["drift_b_failures"] = [
        k for k, v in drift_b_results.items() if not v
    ]

    # --- Template Coverage ---
    templates = {
        "direct": CLEAN_TEMPLATE,
        "negation": CLEAN_TEMPLATE_NEGATION,
        "chain": CLEAN_TEMPLATE_CHAIN,
        "boolean": CLEAN_TEMPLATE_BOOLEAN,
        "split": CLEAN_TEMPLATE_SPLIT,
        "tuple": CLEAN_TEMPLATE_TUPLE,
    }

    template_coverage: Dict[str, Dict[str, Any]] = {}
    for t_name, template in templates.items():
        a_ok = 0
        a_total = 0
        for d_name, d_body in DRIFT_A_VARIANTS.items():
            a_total += 1
            source = _render_template(template, d_body)
            _, entries = _run_detector(source)
            drift_a, _ = _classify_drift(entries)
            if drift_a > 0:
                a_ok += 1

        template_coverage[t_name] = {
            "drift_a_rate": round(a_ok / a_total, 4) if a_total > 0 else 0.0,
            "drift_a_ok": a_ok,
            "drift_a_total": a_total,
        }

    report["details"]["template_coverage"] = template_coverage

    # --- Almost Clean Accuracy ---
    fp_count = 0
    fn_count = 0
    for name, (source, is_drift) in ALMOST_CLEAN_VARIANTS.items():
        warnings, _ = _run_detector(source)
        has_drift = len(warnings) > 0
        if is_drift and not has_drift:
            fn_count += 1
        elif not is_drift and has_drift:
            fp_count += 1

    almost_clean_total = len(ALMOST_CLEAN_VARIANTS)
    almost_clean_ok = almost_clean_total - fp_count - fn_count
    report["metrics"]["almost_clean_accuracy"] = round(
        almost_clean_ok / almost_clean_total, 4
    ) if almost_clean_total > 0 else 0.0
    report["metrics"]["false_positives"] = fp_count
    report["metrics"]["false_negatives"] = fn_count

    # --- Gesamt-Confidence-Score ---
    # Gewichtung: Drift A 35%, Drift B 35%, Template Coverage 20%, Almost Clean 10%
    avg_template_coverage = (
        sum(t["drift_a_rate"] for t in template_coverage.values()) / len(template_coverage)
        if template_coverage else 0.0
    )

    confidence = (
        drift_a_rate * 0.35
        + drift_b_rate * 0.35
        + avg_template_coverage * 0.20
        + (almost_clean_ok / almost_clean_total if almost_clean_total > 0 else 0.0) * 0.10
    )

    report["metrics"]["confidence_score"] = round(confidence, 4)

    # --- Verdict ---
    if confidence >= 0.95:
        report["verdict"] = "HARD-READY"
        report["verdict_reason"] = (
            f"Confidence {confidence:.1%} ≥ 95%. "
            f"Drift A: {drift_a_rate:.0%}, Drift B: {drift_b_rate:.0%}, "
            f"Template Coverage: {avg_template_coverage:.0%}, "
            f"Almost Clean: {almost_clean_ok}/{almost_clean_total}"
        )
    elif confidence >= 0.85:
        report["verdict"] = "SHADOW-OK"
        report["verdict_reason"] = (
            f"Confidence {confidence:.1%} ≥ 85%. "
            f"Geeignet für Shadow Mode, aber noch nicht HARD-ready."
        )
    else:
        report["verdict"] = "NEEDS-IMPROVEMENT"
        report["verdict_reason"] = (
            f"Confidence {confidence:.1%} < 85%. "
            f"Detector needs improvement before Shadow Mode."
        )

    return report


# =============================================================================
# CLI: Confidence Report Runner
# =============================================================================

def run_confidence_report(output_path: Optional[str] = None) -> Dict[str, Any]:
    """Führt die komplette Injection Suite aus und generiert einen Confidence-Report.

    Args:
        output_path: Optionaler Pfad für JSON-Export

    Returns:
        Dict mit Confidence-Report
    """
    import datetime

    report = generate_confidence_report()
    report["timestamp"] = datetime.datetime.now().isoformat()

    print("=" * 60)
    print("CI-CRT-014 — Drift Injection Confidence Report")
    print("=" * 60)
    print(f"Phase: {report['phase']}")
    print(f"Timestamp: {report['timestamp']}")
    print()

    # Drift A
    print(f"Drift A Detection Rate: {report['metrics']['drift_a_detected']}/{report['metrics']['drift_a_total']} "
          f"({report['metrics']['drift_a_detection_rate']:.1%})")
    if report['details']['drift_a_failures']:
        print(f"  ⚠️  Nicht erkannt: {', '.join(report['details']['drift_a_failures'])}")
    print()

    # Drift B
    print(f"Drift B Detection Rate: {report['metrics']['drift_b_detected']}/{report['metrics']['drift_b_total']} "
          f"({report['metrics']['drift_b_detection_rate']:.1%})")
    if report['details']['drift_b_failures']:
        print(f"  ⚠️  Nicht erkannt: {', '.join(report['details']['drift_b_failures'])}")
    print()

    # Template Coverage
    print("Template Coverage (Drift A):")
    for t_name, t_data in report['details']['template_coverage'].items():
        print(f"  {t_name}: {t_data['drift_a_ok']}/{t_data['drift_a_total']} ({t_data['drift_a_rate']:.1%})")
    print()

    # Almost Clean
    print(f"Almost Clean Accuracy: {report['metrics']['almost_clean_accuracy']:.1%}")
    print(f"  False Positives: {report['metrics']['false_positives']}")
    print(f"  False Negatives: {report['metrics']['false_negatives']}")
    print()

    # Gesamt
    print(f"Confidence Score: {report['metrics']['confidence_score']:.1%}")
    print(f"Verdict: {report['verdict']}")
    print(f"Reason: {report['verdict_reason']}")
    print("=" * 60)

    # Export
    if output_path:
        out = Path(output_path)
        out.write_text(json.dumps(report, indent=2), encoding="utf-8")
        print(f"\nReport exported: {output_path}")

    return report


if __name__ == "__main__":
    import sys

    output = sys.argv[1] if len(sys.argv) > 1 else None
    run_confidence_report(output)