import asyncio
import json
import httpx
from core.routing.mcp_gateway import create_mcp_gateway, ClientSessionState
from core.rbac_system import Role

async def test_memory_flow():
    print("🚀 Starting MCP Memory Integration Test (Interface Contract v1.0.0)...")
    
    # 1. Initialize Gateway
    gateway = create_mcp_gateway()
    
    # 2. Register a test session
    session_id = "test_memory_session_v1_0_0"
    session = await gateway.register_client(
        session_id=session_id,
        tenant_id="test_tenant",
        role=Role.ADMIN,
        capabilities=["EXECUTE_TOOLS"]
    )
    
    # 3. Test memory.store
    print("📝 Testing memory.store...")
    store_args = {
        "content": "Antigravity is the advanced AI agent for HestiaOS.",
        "metadata": {
            "agent_id": "antigravity-01",
            "category": "system_info",
            "tenant_id": "test_tenant"
        },
        "correlation_id": "test-corr-123"
    }
    
    # Call the handler via the dispatcher (simulating actual MCP call)
    store_result = await gateway._handle_memory_store(store_args, session)
    print(f"Result: {store_result[0].text}")
    
    if "Successfully stored" not in store_result[0].text:
        print("❌ memory.store failed")
        return

    # 4. Test memory.get (Wait a brief moment for indexing)
    await asyncio.sleep(2)
    print("🔍 Testing memory.get...")
    get_args = {
        "query": "Who is Antigravity?",
        "limit": 3,
        "correlation_id": "test-corr-456"
    }
    get_result = await gateway._handle_memory_get(get_args, session)
    print(f"Result: {get_result[0].text}")
    
    if "Antigravity" in get_result[0].text:
        print("✅ memory.get successful and content retrieved!")
    else:
        print(f"❌ memory.get failed or content mismatch. Expected 'Antigravity', got '{get_result[0].text}'")

    # 5. Check Telemetry
    metrics = gateway.telemetry.calculate_metrics()
    basic_metrics = metrics.get("basic_metrics", {})
    mem_ops = basic_metrics.get("memory_operations", 0)
    print(f"📊 Telemetry - Memory Operations recorded: {mem_ops}")
    
    if mem_ops >= 2:
        print("✅ Telemetry integration verified!")
    else:
        print("❌ Telemetry failed to record operations")

    # Cleanup
    await gateway.shutdown()
    print("🏁 Test finished.")

if __name__ == "__main__":
    asyncio.run(test_memory_flow())
