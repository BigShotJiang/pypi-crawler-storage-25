# tests/test_wave.py
import pytest
from core.protocol.wave import Wave, WaveState

def test_wave_happy_path():
    w = Wave(tenant_id="t1", created_by="chris")
    w.transition(WaveState.PROPAGATION_PENDING)
    w.approve("propagation", actor="admin")
    w.transition(WaveState.PROPAGATED)
    w.transition(WaveState.SYNC_PENDING)
    w.approve("synchronization", actor="admin")
    w.transition(WaveState.COMMITTED)
    assert w.state == WaveState.COMMITTED
    assert "propagation" in w.approvals
    assert "synchronization" in w.approvals

def test_wave_invalid_transition_raises():
    w = Wave()
    with pytest.raises(ValueError):
        w.transition(WaveState.COMMITTED)