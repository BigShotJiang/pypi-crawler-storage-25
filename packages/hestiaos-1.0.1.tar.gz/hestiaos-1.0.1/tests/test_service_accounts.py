"""
Unit tests for Service Accounts Vault implementation.
"""

import pytest
from datetime import datetime
from unittest.mock import Mock, MagicMock

from core.vault.service_accounts import (
    ServiceAccount,
    ServiceAccountSecret,
    ServiceAccountCreateRequest,
    ServiceAccountUpdateRequest,
    ServiceAccountStatus,
    Provider,
    AuthType,
    AuditEvent,
    AuditEventType
)
from core.vault.storage import InMemoryServiceAccountStorage
from core.vault.manager import ServiceAccountManager
from core.rbac_system import Role


class TestServiceAccountModel:
    """Test service account domain models."""
    
    def test_service_account_creation(self):
        """Test creating a service account."""
        account = ServiceAccount(
            id="test-id",
            tenant_id="tenant-1",
            name="test-account",
            provider=Provider.GITLAB,
            auth_type=AuthType.BEARER,
            secret_ref="secret-ref"
        )
        
        assert account.id == "test-id"
        assert account.tenant_id == "tenant-1"
        assert account.name == "test-account"
        assert account.provider == Provider.GITLAB
        assert account.auth_type == AuthType.BEARER
        assert account.status == ServiceAccountStatus.ACTIVE
        assert isinstance(account.created_at, datetime)
    
    def test_service_account_to_dict(self):
        """Test converting service account to dictionary."""
        account = ServiceAccount(
            id="test-id",
            tenant_id="tenant-1",
            name="test-account",
            provider=Provider.N8N,
            auth_type=AuthType.API_KEY,
            secret_ref="secret-ref"
        )
        
        data = account.to_dict()
        
        assert data["id"] == "test-id"
        assert data["tenant_id"] == "tenant-1"
        assert data["name"] == "test-account"
        assert data["provider"] == "n8n"
        assert data["auth_type"] == "api_key"
        assert data["status"] == "active"
    
    def test_service_account_from_dict(self):
        """Test creating service account from dictionary."""
        data = {
            "id": "test-id",
            "tenant_id": "tenant-1",
            "name": "test-account",
            "provider": "gitlab",
            "auth_type": "bearer",
            "secret_ref": "secret-ref",
            "allowed_scopes": ["read", "write"],
            "created_by": "admin",
            "created_at": "2024-01-01T00:00:00",
            "status": "active"
        }
        
        account = ServiceAccount.from_dict(data)
        
        assert account.id == "test-id"
        assert account.tenant_id == "tenant-1"
        assert account.name == "test-account"
        assert account.provider == Provider.GITLAB
        assert account.auth_type == AuthType.BEARER
        assert account.allowed_scopes == ["read", "write"]
        assert account.created_by == "admin"
        assert account.status == ServiceAccountStatus.ACTIVE


class TestInMemoryStorage:
    """Test in-memory storage implementation."""
    
    @pytest.fixture
    def storage(self):
        return InMemoryServiceAccountStorage()
    
    def test_create_and_get_account(self, storage):
        """Test creating and retrieving an account."""
        account = ServiceAccount(
            id="test-id",
            tenant_id="tenant-1",
            name="test-account",
            provider=Provider.GITLAB,
            auth_type=AuthType.BEARER,
            secret_ref="secret-ref"
        )
        
        # Create account
        created = storage.create_account(account)
        assert created.id == "test-id"
        
        # Get account
        retrieved = storage.get_account("tenant-1", "test-id")
        assert retrieved is not None
        assert retrieved.name == "test-account"
        
        # Non-existent account
        assert storage.get_account("tenant-1", "non-existent") is None
        assert storage.get_account("tenant-2", "test-id") is None
    
    def test_tenant_isolation(self, storage):
        """Test that tenants are isolated."""
        # Create account in tenant-1
        account1 = ServiceAccount(
            id="acc-1",
            tenant_id="tenant-1",
            name="account-1",
            provider=Provider.GITLAB,
            auth_type=AuthType.BEARER,
            secret_ref="secret-1"
        )
        storage.create_account(account1)
        
        # Create account in tenant-2
        account2 = ServiceAccount(
            id="acc-2",
            tenant_id="tenant-2",
            name="account-2",
            provider=Provider.N8N,
            auth_type=AuthType.API_KEY,
            secret_ref="secret-2"
        )
        storage.create_account(account2)
        
        # Verify isolation
        tenant1_accounts = storage.list_accounts("tenant-1")
        assert len(tenant1_accounts) == 1
        assert tenant1_accounts[0].id == "acc-1"
        
        tenant2_accounts = storage.list_accounts("tenant-2")
        assert len(tenant2_accounts) == 1
        assert tenant2_accounts[0].id == "acc-2"
        
        # Cross-tenant access should fail
        assert storage.get_account("tenant-1", "acc-2") is None
        assert storage.get_account("tenant-2", "acc-1") is None
    
    def test_list_accounts_filtered(self, storage):
        """Test listing accounts with provider filter."""
        # Create accounts with different providers
        accounts = [
            ServiceAccount(
                id=f"acc-{i}",
                tenant_id="tenant-1",
                name=f"account-{i}",
                provider=Provider.GITLAB if i % 2 == 0 else Provider.N8N,
                auth_type=AuthType.BEARER,
                secret_ref=f"secret-{i}"
            )
            for i in range(5)
        ]
        
        for account in accounts:
            storage.create_account(account)
        
        # List all accounts
        all_accounts = storage.list_accounts("tenant-1")
        assert len(all_accounts) == 5
        
        # List GitLab accounts only
        gitlab_accounts = storage.list_accounts("tenant-1", Provider.GITLAB)
        assert len(gitlab_accounts) == 3  # 0, 2, 4 are GitLab
        
        # List n8n accounts only
        n8n_accounts = storage.list_accounts("tenant-1", Provider.N8N)
        assert len(n8n_accounts) == 2  # 1, 3 are n8n
    
    def test_update_account(self, storage):
        """Test updating an account."""
        account = ServiceAccount(
            id="test-id",
            tenant_id="tenant-1",
            name="original-name",
            provider=Provider.GITLAB,
            auth_type=AuthType.BEARER,
            secret_ref="secret-ref"
        )
        storage.create_account(account)
        
        # Update name and status
        updated = storage.update_account(
            "tenant-1", "test-id",
            name="updated-name",
            status=ServiceAccountStatus.DISABLED
        )
        
        assert updated is not None
        assert updated.name == "updated-name"
        assert updated.status == ServiceAccountStatus.DISABLED
        
        # Verify update persisted
        retrieved = storage.get_account("tenant-1", "test-id")
        assert retrieved.name == "updated-name"
        assert retrieved.status == ServiceAccountStatus.DISABLED
    
    def test_set_and_get_secret(self, storage):
        """Test setting and getting secrets."""
        # Create account first
        account = ServiceAccount(
            id="test-id",
            tenant_id="tenant-1",
            name="test-account",
            provider=Provider.GITLAB,
            auth_type=AuthType.BEARER,
            secret_ref="secret-ref"
        )
        storage.create_account(account)
        
        # Set secret
        secret = ServiceAccountSecret(
            ciphertext=b"encrypted-data",
            nonce=b"test-nonce"
        )
        success = storage.set_secret("tenant-1", "test-id", secret)
        assert success is True
        
        # Get secret
        retrieved = storage.get_secret("tenant-1", "test-id")
        assert retrieved is not None
        assert retrieved.ciphertext == b"encrypted-data"
        assert retrieved.nonce == b"test-nonce"
        
        # Non-existent secret
        assert storage.get_secret("tenant-1", "non-existent") is None
        assert storage.get_secret("tenant-2", "test-id") is None
    
    def test_audit_events(self, storage):
        """Test audit event logging."""
        # Log events
        event1 = AuditEvent(
            event_type=AuditEventType.SERVICE_ACCOUNT_CREATED,
            tenant_id="tenant-1",
            service_account_id="acc-1",
            provider=Provider.GITLAB,
            actor="admin"
        )
        
        event2 = AuditEvent(
            event_type=AuditEventType.SERVICE_ACCOUNT_SECRET_SET,
            tenant_id="tenant-1",
            service_account_id="acc-1",
            actor="admin"
        )
        
        storage.log_audit_event(event1)
        storage.log_audit_event(event2)
        
        # Get events
        events = storage.get_audit_events("tenant-1")
        assert len(events) == 2
        assert events[0].event_type == AuditEventType.SERVICE_ACCOUNT_SECRET_SET
        assert events[1].event_type == AuditEventType.SERVICE_ACCOUNT_CREATED
        
        # Tenant isolation for audit events
        assert len(storage.get_audit_events("tenant-2")) == 0


class TestServiceAccountManager:
    """Test service account manager with RBAC."""
    
    @pytest.fixture
    def mock_storage(self):
        return Mock(spec=InMemoryServiceAccountStorage)
    
    @pytest.fixture
    def mock_rbac(self):
        rbac = Mock()
        return rbac
    
    @pytest.fixture
    def manager(self, mock_storage, mock_rbac):
        return ServiceAccountManager(mock_storage, mock_rbac)
    
    def test_create_account_admin_success(self, manager, mock_storage):
        """Test admin successfully creating an account."""
        # Setup
        request = ServiceAccountCreateRequest(
            name="test-account",
            provider=Provider.GITLAB,
            auth_type=AuthType.BEARER
        )
        
        mock_account = Mock(spec=ServiceAccount)
        mock_account.id = "generated-id"
        mock_account.tenant_id = "tenant-1"
        mock_storage.create_account.return_value = mock_account
        
        # Execute
        result = manager.create_account(
            tenant_id="tenant-1",
            request=request,
            actor="admin-user",
            actor_role=Role.ADMIN
        )
        
        # Verify
        assert result == mock_account
        mock_storage.create_account.assert_called_once()
    
    def test_create_account_operator_denied(self, manager):
        """Test operator being denied when creating account."""
        request = ServiceAccountCreateRequest(
            name="test-account",
            provider=Provider.GITLAB,
            auth_type=AuthType.BEARER
        )
        
        # Execute & Verify
        with pytest.raises(PermissionError, match="Only ADMIN or SYSTEM roles can create service accounts"):
            manager.create_account(
                tenant_id="tenant-1",
                request=request,
                actor="operator-user",
                actor_role=Role.OPERATOR
            )
    
    def test_get_account_rbac_enforcement(self, manager, mock_storage):
        """Test RBAC enforcement for getting accounts."""
        # Setup
        mock_account = Mock(spec=ServiceAccount)
        mock_account.tenant_id = "tenant-1"
        mock_storage.get_account.return_value = mock_account
        
        # Test ADMIN can get account
        result = manager.get_account(
            tenant_id="tenant-1",
            account_id="test-id",
            actor="admin-user",
            actor_role=Role.ADMIN
        )
        assert result == mock_account
        
        # Test OPERATOR can get account in same tenant
        result = manager.get_account(
            tenant_id="tenant-1",
            account_id="test-id",
            actor="operator-user",
            actor_role=Role.OPERATOR
        )
        assert result == mock_account
        
        # Test VIEWER cannot get account
        with pytest.raises(PermissionError, match="Insufficient permissions to view service accounts"):
            manager.get_account(
                tenant_id="tenant-1",
                account_id="test-id",
                actor="viewer-user",
                actor_role=Role.VIEWER
            )
    
    def test_tenant_boundary_violation(self, manager, mock_storage):
        """Test operator trying to access account from different tenant."""
        # Setup - account belongs to tenant-2 but operator is from tenant-1
        mock_account = Mock(spec=ServiceAccount)
        mock_account.tenant_id = "tenant-2"  # Different tenant!
        mock_storage.get_account.return_value = mock_account
        
        # Execute & Verify
        with pytest.raises(PermissionError, match="Cross-tenant access not allowed"):
            manager.get_account(
                tenant_id="tenant-1",  # Operator's tenant
                account_id="test-id",
                actor="operator-user",
                actor_role=Role.OPERATOR
            )
        
        # Verify audit event was logged
        assert mock_storage.log_audit_event.called
    
    def test_set_secret_rbac(self, manager, mock_storage):
        """Test RBAC enforcement for setting secrets."""
        # Setup
        mock_account = Mock(spec=ServiceAccount)
        mock_storage.get_account.return_value = mock_account
        mock_storage.set_secret.return_value = True
        
        # Test ADMIN can set secret
        success = manager.set_secret(
            tenant_id="tenant-1",
            account_id="test-id",
            secret_data="test-secret",
            actor="admin-user",
            actor_role=Role.ADMIN
        )
        assert success is True
        
        # Test OPERATOR cannot set secret
        with pytest.raises(PermissionError, match="Only ADMIN or SYSTEM roles can set service account secrets"):
            manager.set_secret(
                tenant_id="tenant-1",
                account_id="test-id",
                secret_data="test-secret",
                actor="operator-user",
                actor_role=Role.OPERATOR
            )
    
    def test_get_secret_for_tool(self, manager, mock_storage):
        """Test getting secret for tool execution."""
        # Setup
        mock_account = Mock(spec=ServiceAccount)
        mock_account.id = "acc-1"
        mock_account.status = ServiceAccountStatus.ACTIVE
        
        # Mock storage as EncryptedStorageAdapter
        from core.vault.crypto_adapter import EncryptedStorageAdapter
        mock_storage.__class__ = EncryptedStorageAdapter
        
        # Mock get_secret to return tuple (plaintext, encrypted_secret)
        mock_storage.list_accounts.return_value = [mock_account]
        mock_storage.get_secret.return_value = ("decrypted-secret-123", Mock())
        
        # Execute
        result = manager.get_secret_for_tool(
            tenant_id="tenant-1",
            provider=Provider.GITLAB,
            tool_name="gitlab.create_issue",
            sandbox_level="restricted"
        )
        
        # Verify
        assert result is not None
        account, secret = result
        assert account == mock_account
        assert secret == "decrypted-secret-123"
        
        # Verify audit event was logged
        assert mock_storage.log_audit_event.called
    
    def test_get_secret_for_tool_no_active_account(self, manager, mock_storage):
        """Test getting secret when no active account exists."""
        # Setup - no active accounts
        mock_account = Mock(spec=ServiceAccount)
        mock_account.status = ServiceAccountStatus.DISABLED  # Inactive!
        
        mock_storage.list_accounts.return_value = [mock_account]
        
        # Execute
        result = manager.get_secret_for_tool(
            tenant_id="tenant-1",
            provider=Provider.GITLAB,
            tool_name="gitlab.create_issue",
            sandbox_level="restricted"
        )
        
        # Verify
        assert result is None