import pytest
import asyncio
from pathlib import Path
from unittest.mock import MagicMock, AsyncMock
from datetime import datetime

from core.workflow import WorkflowManager, WorkflowPhase
from core.curiosity import AdaptiveCuriosity
from core.ralph_manager import RalphLoopManager

@pytest.mark.asyncio
async def test_curiosity_gamma_adjustment():
    """Verify that Gamma adjusts correctly based on workflow phase"""
    wm = WorkflowManager(agent_id="test_agent")
    curiosity = AdaptiveCuriosity(agent_id="test_agent", workflow_manager=wm)
    
    # Test IDEATION
    wm.set_phase(WorkflowPhase.IDEATION)
    gamma_ideation = curiosity.update_gamma()
    assert 0.8 <= gamma_ideation <= 1.0
    
    # Test IMPLEMENTATION
    wm.set_phase(WorkflowPhase.IMPLEMENTATION)
    gamma_impl = curiosity.update_gamma()
    assert 0.0 <= gamma_impl <= 0.3
    
    # Test System Load Impact
    wm.set_phase(WorkflowPhase.IDEATION)
    gamma_high_load = curiosity.update_gamma(system_load=90.0)
    assert gamma_high_load < gamma_ideation # Should be reduced by load

@pytest.mark.asyncio
async def test_ralph_curiosity_integration(tmp_path):
    """Verify RalphLoopManager uses curiosity to trigger exploration"""
    wm = WorkflowManager(agent_id="curious_ralph")
    # Force high gamma for testing
    curiosity = AdaptiveCuriosity(agent_id="curious_ralph", workflow_manager=wm)
    curiosity.gamma = 1.0 # Force exploration
    
    # Mock Bridge
    mock_bridge = AsyncMock()
    mock_bridge.process.return_value = {"success": True, "text": "Exploration result: Insight found!"}
    
    loop_path = tmp_path / "ralph_loop"
    loop_path.mkdir()
    (loop_path / "PRD.md").write_text("## Task 1: Test Phase\nDo something.")
    
    # Patch get_bridge to return our mock
    import core.ralph_manager
    core.ralph_manager.get_bridge = lambda: mock_bridge
    
    ralph = RalphLoopManager(loop_path=loop_path, workflow_manager=wm, curiosity=curiosity)
    
    # Run one iteration
    # Since we forced gamma=1.0, it MUST call explore_phase
    # We'll mock read_phase and logic_phase to control the loop
    ralph.read_phase = AsyncMock(return_value={
        "next_task": {"id": 1, "description": "Test Task"},
        "completed_ids": []
    })
    ralph.logic_phase = AsyncMock(return_value={"action": "STOP", "reason": "Test finished"})
    
    await ralph.run_loop(iterations=1)
    
    # Verify exploration notes were created
    notes_file = loop_path / "exploration_notes.md"
    assert notes_file.exists()
    assert "Exploration result: Insight found!" in notes_file.read_text()
    
    # Verify phases were tracked
    assert wm.current_phase == WorkflowPhase.IDLE # Resets at end
    assert len(wm.phase_history) > 0
    phases_visited = [p["phase"] for p in wm.phase_history]
    assert WorkflowPhase.IDEATION.value in phases_visited
