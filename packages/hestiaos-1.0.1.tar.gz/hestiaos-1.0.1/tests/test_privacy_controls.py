#!/usr/bin/env python3
"""
Tests for the Privacy Controls System (Phase 3 of Security, RBAC & Privacy #82)
"""

import unittest
import tempfile
import os
import json
from pathlib import Path
from datetime import datetime, timedelta
from unittest.mock import patch, MagicMock

from core.privacy_controls import (
    DataCategory,
    RetentionPolicy,
    ConsentType,
    PrivacyLevel,
    DataClassification,
    ConsentRecord,
    PrivacyAuditLog,
    PrivacyManager,
    get_privacy_manager
)


class TestDataClassification(unittest.TestCase):
    """Test DataClassification class."""
    
    def test_classification_creation(self):
        """Test creating a data classification."""
        classification = DataClassification(
            category=DataCategory.IDENTIFIABLE,
            privacy_level=PrivacyLevel.SECRET,
            retention_policy=RetentionPolicy.LONG_TERM,
            encryption_required=True,
            anonymization_required=True,
            access_logging_required=True,
            tags=["pii", "gdpr"]
        )
        
        self.assertEqual(classification.category, DataCategory.IDENTIFIABLE)
        self.assertEqual(classification.privacy_level, PrivacyLevel.SECRET)
        self.assertEqual(classification.retention_policy, RetentionPolicy.LONG_TERM)
        self.assertTrue(classification.encryption_required)
        self.assertTrue(classification.anonymization_required)
        self.assertTrue(classification.access_logging_required)
        self.assertEqual(classification.tags, ["pii", "gdpr"])
    
    def test_to_dict_and_from_dict(self):
        """Test serialization and deserialization."""
        original = DataClassification(
            category=DataCategory.CHAT,
            privacy_level=PrivacyLevel.CONFIDENTIAL,
            retention_policy=RetentionPolicy.SHORT_TERM,
            encryption_required=False,
            anonymization_required=True,
            access_logging_required=False,
            tags=["communication", "test"]
        )
        
        data = original.to_dict()
        restored = DataClassification.from_dict(data)
        
        self.assertEqual(restored.category, original.category)
        self.assertEqual(restored.privacy_level, original.privacy_level)
        self.assertEqual(restored.retention_policy, original.retention_policy)
        self.assertEqual(restored.encryption_required, original.encryption_required)
        self.assertEqual(restored.anonymization_required, original.anonymization_required)
        self.assertEqual(restored.access_logging_required, original.access_logging_required)
        self.assertEqual(restored.tags, original.tags)


class TestConsentRecord(unittest.TestCase):
    """Test ConsentRecord class."""
    
    def test_consent_creation(self):
        """Test creating a consent record."""
        now = datetime.now()
        expires = now + timedelta(days=30)
        
        record = ConsentRecord(
            consent_id="test_consent_123",
            user_id="user123",
            consent_type=ConsentType.DATA_PROCESSING,
            granted=True,
            granted_at=now,
            expires_at=expires,
            purpose="AI model training",
            data_categories=[DataCategory.BEHAVIORAL, DataCategory.DEMOGRAPHIC],
            metadata={"source": "web_form"}
        )
        
        self.assertEqual(record.consent_id, "test_consent_123")
        self.assertEqual(record.user_id, "user123")
        self.assertEqual(record.consent_type, ConsentType.DATA_PROCESSING)
        self.assertTrue(record.granted)
        self.assertEqual(record.granted_at, now)
        self.assertEqual(record.expires_at, expires)
        self.assertEqual(record.purpose, "AI model training")
        self.assertEqual(record.data_categories, [DataCategory.BEHAVIORAL, DataCategory.DEMOGRAPHIC])
        self.assertEqual(record.metadata, {"source": "web_form"})
    
    def test_consent_validity(self):
        """Test consent validity checks."""
        now = datetime.now()
        
        # Valid consent (granted, not expired)
        valid_record = ConsentRecord(
            consent_id="valid",
            user_id="user1",
            consent_type=ConsentType.DATA_COLLECTION,
            granted=True,
            granted_at=now - timedelta(days=1),
            expires_at=now + timedelta(days=29)
        )
        self.assertTrue(valid_record.is_valid())
        
        # Not granted
        not_granted = ConsentRecord(
            consent_id="not_granted",
            user_id="user1",
            consent_type=ConsentType.DATA_COLLECTION,
            granted=False,
            granted_at=now,
            expires_at=now + timedelta(days=30)
        )
        self.assertFalse(not_granted.is_valid())
        
        # Expired
        expired = ConsentRecord(
            consent_id="expired",
            user_id="user1",
            consent_type=ConsentType.DATA_COLLECTION,
            granted=True,
            granted_at=now - timedelta(days=31),
            expires_at=now - timedelta(days=1)
        )
        self.assertFalse(expired.is_valid())
        
        # No expiration (valid indefinitely)
        indefinite = ConsentRecord(
            consent_id="indefinite",
            user_id="user1",
            consent_type=ConsentType.DATA_COLLECTION,
            granted=True,
            granted_at=now - timedelta(days=100),
            expires_at=None
        )
        self.assertTrue(indefinite.is_valid())
    
    def test_to_dict_and_from_dict(self):
        """Test serialization and deserialization."""
        now = datetime.now()
        expires = now + timedelta(days=30)
        
        original = ConsentRecord(
            consent_id="test_serialization",
            user_id="user456",
            consent_type=ConsentType.DATA_SHARING,
            granted=True,
            granted_at=now,
            expires_at=expires,
            purpose="Third-party analytics",
            data_categories=[DataCategory.BEHAVIORAL],
            metadata={"version": "1.0"}
        )
        
        data = original.to_dict()
        restored = ConsentRecord.from_dict(data)
        
        self.assertEqual(restored.consent_id, original.consent_id)
        self.assertEqual(restored.user_id, original.user_id)
        self.assertEqual(restored.consent_type, original.consent_type)
        self.assertEqual(restored.granted, original.granted)
        self.assertEqual(restored.granted_at.replace(microsecond=0), 
                        original.granted_at.replace(microsecond=0))
        self.assertEqual(restored.expires_at.replace(microsecond=0) if restored.expires_at else None,
                        original.expires_at.replace(microsecond=0) if original.expires_at else None)
        self.assertEqual(restored.purpose, original.purpose)
        self.assertEqual(restored.data_categories, original.data_categories)
        self.assertEqual(restored.metadata, original.metadata)


class TestPrivacyAuditLog(unittest.TestCase):
    """Test PrivacyAuditLog class."""
    
    def test_audit_log_creation(self):
        """Test creating an audit log entry."""
        now = datetime.now()
        
        log = PrivacyAuditLog(
            log_id="audit_123",
            timestamp=now,
            user_id="admin",
            action="data_access",
            resource_type="user_profile",
            resource_id="profile_789",
            data_category=DataCategory.IDENTIFIABLE,
            privacy_level=PrivacyLevel.CONFIDENTIAL,
            justification="User requested their own data",
            success=True,
            metadata={"ip_address": "192.168.1.1"}
        )
        
        self.assertEqual(log.log_id, "audit_123")
        self.assertEqual(log.timestamp, now)
        self.assertEqual(log.user_id, "admin")
        self.assertEqual(log.action, "data_access")
        self.assertEqual(log.resource_type, "user_profile")
        self.assertEqual(log.resource_id, "profile_789")
        self.assertEqual(log.data_category, DataCategory.IDENTIFIABLE)
        self.assertEqual(log.privacy_level, PrivacyLevel.CONFIDENTIAL)
        self.assertEqual(log.justification, "User requested their own data")
        self.assertTrue(log.success)
        self.assertEqual(log.metadata, {"ip_address": "192.168.1.1"})
    
    def test_to_dict(self):
        """Test audit log serialization."""
        now = datetime.now()
        
        log = PrivacyAuditLog(
            log_id="audit_test",
            timestamp=now,
            user_id="user1",
            action="delete",
            resource_type="chat_message",
            resource_id="msg_123",
            data_category=DataCategory.CHAT,
            privacy_level=PrivacyLevel.INTERNAL,
            justification="GDPR right to be forgotten",
            success=True
        )
        
        data = log.to_dict()
        
        self.assertEqual(data["log_id"], "audit_test")
        self.assertEqual(data["user_id"], "user1")
        self.assertEqual(data["action"], "delete")
        self.assertEqual(data["resource_type"], "chat_message")
        self.assertEqual(data["resource_id"], "msg_123")
        self.assertEqual(data["data_category"], "chat")
        self.assertEqual(data["privacy_level"], "internal")
        self.assertEqual(data["justification"], "GDPR right to be forgotten")
        self.assertTrue(data["success"])


class TestPrivacyManager(unittest.TestCase):
    """Test PrivacyManager class."""
    
    def setUp(self):
        """Set up test environment."""
        # Create temporary config file
        self.temp_dir = tempfile.mkdtemp()
        self.config_path = Path(self.temp_dir) / "privacy_test.yaml"
        
        # Clear singleton instance
        if hasattr(get_privacy_manager, "_instance"):
            delattr(get_privacy_manager, "_instance")
    
    def tearDown(self):
        """Clean up test environment."""
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)
        
        # Clear singleton instance
        if hasattr(get_privacy_manager, "_instance"):
            delattr(get_privacy_manager, "_instance")
    
    def test_initialization(self):
        """Test PrivacyManager initialization."""
        manager = PrivacyManager(self.config_path)
        
        # Should have default classification rules
        self.assertIn("identity_data", manager.classification_rules)
        self.assertIn("consciousness_data", manager.classification_rules)
        self.assertIn("chat_data", manager.classification_rules)
        
        # Should have default retention periods
        self.assertEqual(manager.default_retention_days[RetentionPolicy.SHORT_TERM], 30)
        self.assertEqual(manager.default_retention_days[RetentionPolicy.MEDIUM_TERM], 90)
        self.assertEqual(manager.default_retention_days[RetentionPolicy.LONG_TERM], 365)
    
    def test_classify_data_exact_match(self):
        """Test data classification with exact match."""
        manager = PrivacyManager(self.config_path)
        
        # Add a test classification rule
        test_rule = DataClassification(
            category=DataCategory.SYSTEM,
            privacy_level=PrivacyLevel.INTERNAL,
            retention_policy=RetentionPolicy.MEDIUM_TERM,
            encryption_required=False,
            anonymization_required=False,
            access_logging_required=True,
            tags=["test"]
        )
        manager.classification_rules["test_data_type"] = test_rule
        
        classification = manager.classify_data("test_data_type")
        
        self.assertIsNotNone(classification)
        self.assertEqual(classification.category, DataCategory.SYSTEM)
        self.assertEqual(classification.privacy_level, PrivacyLevel.INTERNAL)
    
    def test_classify_data_pattern_match(self):
        """Test data classification with pattern matching."""
        manager = PrivacyManager(self.config_path)
        
        # Should match "identity_data" rule for "user_identity"
        classification = manager.classify_data("user_identity")
        
        self.assertIsNotNone(classification)
        self.assertEqual(classification.category, DataCategory.IDENTIFIABLE)
        self.assertEqual(classification.privacy_level, PrivacyLevel.SECRET)
    
    def test_classify_data_content_based(self):
        """Test content-based data classification."""
        manager = PrivacyManager(self.config_path)
        
        # Content with email should classify as identifiable
        content_with_email = {"email": "test@example.com", "name": "Test User"}
        classification = manager.classify_data("unknown_type", content_with_email)
        
        self.assertIsNotNone(classification)
        self.assertEqual(classification.category, DataCategory.IDENTIFIABLE)
        
        # Content with consciousness indicators
        content_with_consciousness = {"state": "consciousness_level_5", "awareness": "high"}
        classification = manager.classify_data("unknown_type", content_with_consciousness)
        
        self.assertIsNotNone(classification)
        self.assertEqual(classification.category, DataCategory.CONSCIOUSNESS)
    
    def test_classify_data_default(self):
        """Test default classification for unknown data types."""
        manager = PrivacyManager(self.config_path)
        
        classification = manager.classify_data("completely_unknown_type_xyz")
        
        self.assertIsNotNone(classification)
        self.assertEqual(classification.category, DataCategory.SYSTEM)
        self.assertEqual(classification.privacy_level, PrivacyLevel.INTERNAL)
        self.assertIn("unclassified", classification.tags)
    
    def test_record_and_check_consent(self):
        """Test recording and checking consent."""
        manager = PrivacyManager(self.config_path)
        
        # Record consent
        consent_id = manager.record_consent(
            user_id="test_user",
            consent_type=ConsentType.DATA_PROCESSING,
            granted=True,
            purpose="AI training",
            data_categories=[DataCategory.BEHAVIORAL],
            expires_in_days=30
        )
        
        self.assertIsNotNone(consent_id)
        self.assertIn(consent_id, manager.consent_records)
        
        # Check consent (should be valid)
        has_consent = manager.check_consent(
            user_id="test_user",
            consent_type=ConsentType.DATA_PROCESSING,
            data_category=DataCategory.BEHAVIORAL
        )
        self.assertTrue(has_consent)
        
        # Check consent for different category (should fail)
        has_consent = manager.check_consent(
            user_id="test_user",
            consent_type=ConsentType.DATA_PROCESSING,
            data_category=DataCategory.IDENTIFIABLE
        )
        self.assertFalse(has_consent)
        
        # Check consent for different user (should fail)
        has_consent = manager.check_consent(
            user_id="different_user",
            consent_type=ConsentType.DATA_PROCESSING
        )
        self.assertFalse(has_consent)
    
    def test_enforce_retention_policy(self):
        """Test retention policy enforcement."""
        manager = PrivacyManager(self.config_path)
        
        now = datetime.now()
        
        # Test IMMEDIATE policy
        should_retain = manager.enforce_retention_policy(
            data_type="test_immediate",
            created_at=now
        )
        # Default classification returns True, but we can test with a custom rule
        test_rule = DataClassification(
            category=DataCategory.SYSTEM,
            privacy_level=PrivacyLevel.INTERNAL,
            retention_policy=RetentionPolicy.IMMEDIATE,
            encryption_required=False,
            anonymization_required=False,
            access_logging_required=False
        )
        manager.classification_rules["test_immediate"] = test_rule
        
        should_retain = manager.enforce_retention_policy("test_immediate", now)
        self.assertFalse(should_retain)
        
        # Test INDEFINITE policy
        test_rule = DataClassification(
            category=DataCategory.MODEL,
            privacy_level=PrivacyLevel.INTERNAL,
            retention_policy=RetentionPolicy.INDEFINITE,
            encryption_required=False,
            anonymization_required=False,
            access_logging_required=False
        )
        manager.classification_rules["test_indefinite"] = test_rule
        
        should_retain = manager.enforce_retention_policy("test_indefinite", now - timedelta(days=1000))
        self.assertTrue(should_retain)
        
        # Test SHORT_TERM policy (30 days)
        test_rule = DataClassification(
            category=DataCategory.CHAT,
            privacy_level=PrivacyLevel.CONFIDENTIAL,
            retention_policy=RetentionPolicy.SHORT_TERM,
            encryption_required=True,
            anonymization_required=True,
            access_logging_required=True
        )
        manager.classification_rules["test_short_term"] = test_rule
        
        # Data created 20 days ago (should retain)
        should_retain = manager.enforce_retention_policy(
            "test_short_term",
            now - timedelta(days=20)
        )
        self.assertTrue(should_retain)
        
        # Data created 40 days ago (should not retain)
        should_retain = manager.enforce_retention_policy(
            "test_short_term",
            now - timedelta(days=40)
        )
        self.assertFalse(should_retain)
    
    def test_anonymize_data(self):
        """Test data anonymization."""
        manager = PrivacyManager(self.config_path)
        
        # Test data with PII
        original_data = {
            "email": "john.doe@example.com",
            "name": "John Doe",
            "age": 30,
            "location": "Berlin",
            "phone": "+49 123 456789",
            "user_id": "user_12345",
            "non_pii_field": "some_value"
        }
        
        # Create a classification that requires anonymization
        test_rule = DataClassification(
            category=DataCategory.IDENTIFIABLE,
            privacy_level=PrivacyLevel.SECRET,
            retention_policy=RetentionPolicy.LONG_TERM,
            encryption_required=True,
            anonymization_required=True,
            access_logging_required=True
        )
        manager.classification_rules["test_pii_data"] = test_rule
        
        anonymized = manager.anonymize_data(original_data, "test_pii_data")
        
        # PII fields should be anonymized
        self.assertNotEqual(anonymized["email"], "john.doe@example.com")
        self.assertTrue(anonymized["email"].startswith("anon_"))
        self.assertNotEqual(anonymized["name"], "John Doe")
        self.assertTrue(anonymized["name"].startswith("anon_") or anonymized["name"] == "[ANONYMIZED]")
        self.assertNotEqual(anonymized["phone"], "+49 123 456789")
        self.assertNotEqual(anonymized["user_id"], "user_12345")
        
        # Non-PII fields should remain unchanged
        self.assertEqual(anonymized["age"], 30)
        self.assertEqual(anonymized["location"], "Berlin")
        self.assertEqual(anonymized["non_pii_field"], "some_value")
        
        # Test data without anonymization requirement
        test_rule_no_anon = DataClassification(
            category=DataCategory.SYSTEM,
            privacy_level=PrivacyLevel.INTERNAL,
            retention_policy=RetentionPolicy.SHORT_TERM,
            encryption_required=False,
            anonymization_required=False,
            access_logging_required=False
        )
        manager.classification_rules["test_no_anon"] = test_rule_no_anon
        
        not_anonymized = manager.anonymize_data(original_data, "test_no_anon")
        self.assertEqual(not_anonymized["email"], "john.doe@example.com")
        self.assertEqual(not_anonymized["name"], "John Doe")
    
    def test_validate_privacy_compliance(self):
        """Test privacy compliance validation."""
        manager = PrivacyManager(self.config_path)
        
        # Record consent first
        manager.record_consent(
            user_id="compliant_user",
            consent_type=ConsentType.DATA_PROCESSING,
            granted=True,
            purpose="Testing",
            data_categories=[DataCategory.IDENTIFIABLE],
            expires_in_days=30
        )
        
        # Test compliant operation with consent
        compliant, reason = manager.validate_privacy_compliance(
            operation="read",
            data_type="identity_data",
            user_id="compliant_user",
            data={"email": "test@example.com"}
        )
        
        self.assertTrue(compliant)
        self.assertIn("compliant", reason.lower())
        
        # Test non-compliant operation (no consent)
        compliant, reason = manager.validate_privacy_compliance(
            operation="process",
            data_type="identity_data",
            user_id="user_without_consent",
            data={"email": "test@example.com"}
        )
        
        self.assertFalse(compliant)
        self.assertIn("no valid consent", reason.lower())
        
        # Test deletion (should always be allowed)
        compliant, reason = manager.validate_privacy_compliance(
            operation="delete",
            data_type="identity_data",
            user_id="any_user",
            data={"email": "test@example.com"}
        )
        
        self.assertTrue(compliant)
        self.assertIn("deletion allowed", reason.lower())
    
    def test_audit_logging(self):
        """Test audit logging functionality."""
        manager = PrivacyManager(self.config_path)
        
        # Log some audit events
        manager._log_audit(
            user_id="test_user",
            action="data_access",
            resource_type="user_profile",
            resource_id="profile_123",
            data_category=DataCategory.IDENTIFIABLE,
            privacy_level=PrivacyLevel.CONFIDENTIAL,
            justification="User requested access",
            success=True
        )
        
        manager._log_audit(
            user_id="admin",
            action="config_update",
            resource_type="privacy_settings",
            resource_id="settings_456",
            justification="Updated retention policies",
            success=True
        )
        
        # Get all logs
        all_logs = manager.get_audit_logs()
        self.assertEqual(len(all_logs), 2)
        
        # Filter by user
        user_logs = manager.get_audit_logs(user_id="test_user")
        self.assertEqual(len(user_logs), 1)
        self.assertEqual(user_logs[0].user_id, "test_user")
        
        # Filter by action
        action_logs = manager.get_audit_logs(action="config_update")
        self.assertEqual(len(action_logs), 1)
        self.assertEqual(action_logs[0].action, "config_update")
        
        # Filter by resource type
        resource_logs = manager.get_audit_logs(resource_type="user_profile")
        self.assertEqual(len(resource_logs), 1)
        self.assertEqual(resource_logs[0].resource_type, "user_profile")
    
    def test_export_consent_report(self):
        """Test consent report export."""
        manager = PrivacyManager(self.config_path)
        
        # Record multiple consents for a user
        manager.record_consent(
            user_id="report_user",
            consent_type=ConsentType.DATA_COLLECTION,
            granted=True,
            purpose="Analytics",
            expires_in_days=30
        )
        
        manager.record_consent(
            user_id="report_user",
            consent_type=ConsentType.DATA_SHARING,
            granted=False,
            purpose="Third-party marketing",
            expires_in_days=30
        )
        
        # Export report
        report = manager.export_consent_report("report_user")
        
        self.assertEqual(report["user_id"], "report_user")
        self.assertEqual(report["total_consents"], 2)
        self.assertEqual(report["valid_consents"], 1)  # Only one granted consent
        
        # Check report structure
        self.assertIn("exported_at", report)
        self.assertIn("consents", report)
        self.assertEqual(len(report["consents"]), 2)
        
        # Test export for user with no consents
        empty_report = manager.export_consent_report("non_existent_user")
        self.assertEqual(empty_report["user_id"], "non_existent_user")
        self.assertEqual(empty_report["total_consents"], 0)
        self.assertEqual(empty_report["valid_consents"], 0)
        self.assertEqual(len(empty_report["consents"]), 0)
    
    def test_singleton_pattern(self):
        """Test get_privacy_manager singleton."""
        manager1 = get_privacy_manager(self.config_path)
        manager2 = get_privacy_manager(self.config_path)
        
        self.assertIs(manager1, manager2)
        
        # Clear singleton and test with different config
        delattr(get_privacy_manager, "_instance")
        
        different_config = Path(self.temp_dir) / "different_config.yaml"
        manager3 = get_privacy_manager(different_config)
        
        self.assertIsNot(manager1, manager3)


class TestPrivacyIntegration(unittest.TestCase):
    """Integration tests for privacy controls."""
    
    def test_privacy_with_rbac_integration(self):
        """Test integration between privacy controls and RBAC."""
        # This test would require both systems to be available
        # For now, just verify imports work
        from core.privacy_controls import PrivacyManager
        from core.rbac_system import RBACManager
        
        self.assertTrue(True)  # Placeholder for actual integration test
    
    def test_privacy_with_encryption_integration(self):
        """Test integration between privacy controls and encryption."""
        # This test would verify that privacy classifications
        # properly trigger encryption requirements
        from core.privacy_controls import PrivacyManager, DataClassification
        from core.encryption_system import EncryptionManager
        
        self.assertTrue(True)  # Placeholder for actual integration test


def run_tests():
    """Run all privacy control tests."""
    import sys
    
    # Create test suite
    suite = unittest.TestSuite()
    
    # Add test classes
    suite.addTest(unittest.makeSuite(TestDataClassification))
    suite.addTest(unittest.makeSuite(TestConsentRecord))
    suite.addTest(unittest.makeSuite(TestPrivacyAuditLog))
    suite.addTest(unittest.makeSuite(TestPrivacyManager))
    suite.addTest(unittest.makeSuite(TestPrivacyIntegration))
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    # Return exit code
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    sys.exit(run_tests())