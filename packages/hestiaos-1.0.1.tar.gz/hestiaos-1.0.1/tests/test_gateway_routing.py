#!/usr/bin/env python3
"""
Test script for Bifrost gateway routing configuration.
Validates the gateway configuration in user.yml and tests routing logic.
"""

import yaml
import random
import sys
from pathlib import Path

def load_config():
    """Load and parse the user.yml configuration"""
    config_path = Path("config/user.yml")
    if not config_path.exists():
        print(f"❌ Config file not found: {config_path}")
        return None
    
    with open(config_path, 'r') as f:
        try:
            config = yaml.safe_load(f)
            return config
        except yaml.YAMLError as e:
            print(f"❌ Error parsing YAML: {e}")
            return None

def test_gateway_config(config):
    """Test if gateway configuration is properly set up"""
    print("🔍 Testing gateway configuration...")
    
    if "gateway" not in config:
        print("❌ No 'gateway' section found in config")
        return False
    
    gateway = config["gateway"]
    
    # Check required sections
    required_sections = ["bifrost_migration", "endpoints", "routing"]
    for section in required_sections:
        if section not in gateway:
            print(f"❌ Missing required section: gateway.{section}")
            return False
    
    # Test endpoints
    endpoints = gateway["endpoints"]
    if "litellm" not in endpoints:
        print("❌ Missing litellm endpoint")
        return False
    
    if "bifrost" not in endpoints:
        print("❌ Missing bifrost endpoint")
        return False
    
    litellm_endpoint = endpoints["litellm"]
    bifrost_endpoint = endpoints["bifrost"]
    
    print(f"✅ LiteLLM endpoint: {litellm_endpoint.get('url', 'N/A')}")
    print(f"✅ Bifrost endpoint: {bifrost_endpoint.get('url', 'N/A')}")
    print(f"✅ Bifrost migration enabled: {gateway['bifrost_migration'].get('enabled', False)}")
    print(f"✅ Traffic percentage: {gateway['bifrost_migration'].get('traffic_percentage', 0)}%")
    
    return True

def simulate_routing(config, num_requests=10):
    """Simulate routing decisions based on configuration"""
    print(f"\n🎯 Simulating {num_requests} routing decisions...")
    
    gateway = config["gateway"]
    migration = gateway["bifrost_migration"]
    routing = gateway["routing"]
    
    enabled = migration.get("enabled", False)
    traffic_percentage = migration.get("traffic_percentage", 0)
    
    routing_stats = {"litellm": 0, "bifrost": 0, "fallback": 0}
    
    for i in range(num_requests):
        # Simulate different request types
        request = {
            "model": random.choice(["gpt-3.5-turbo", "qwen2.5:7b", "granite-micro", "llama3.2:3b"]),
            "random_value": random.random() * 100
        }
        
        target = routing.get("default", "litellm")
        
        # Apply routing rules
        for rule in routing.get("rules", []):
            condition = rule.get("condition", "")
            
            # Simple condition evaluation (simplified)
            if "gateway.bifrost_migration.enabled == true" in condition:
                if not enabled:
                    continue
            
            if "random() < gateway.bifrost_migration.traffic_percentage / 100" in condition:
                if random.random() < (traffic_percentage / 100):
                    target = rule.get("target", target)
                    break
            
            if "request.model contains 'gpt'" in condition and "gpt" in request["model"]:
                target = rule.get("target", target)
                break
            
            if "request.model contains 'qwen'" in condition and "qwen" in request["model"]:
                target = rule.get("target", target)
                break
        
        routing_stats[target] += 1
        
        if i < 3:  # Show first 3 decisions
            print(f"  Request {i+1}: model='{request['model']}' -> {target}")
    
    print(f"\n📊 Routing statistics:")
    print(f"  LiteLLM: {routing_stats['litellm']} requests ({routing_stats['litellm']/num_requests*100:.1f}%)")
    print(f"  Bifrost: {routing_stats['bifrost']} requests ({routing_stats['bifrost']/num_requests*100:.1f}%)")
    
    return routing_stats

def test_config_validation():
    """Test that the configuration is valid for the llama_stack_plugin"""
    print("\n🔧 Testing configuration compatibility...")
    
    config = load_config()
    if not config:
        return False
    
    # Check that openai_api_base still exists (for backward compatibility)
    if "openai_api_base" not in config:
        print("⚠️  openai_api_base not found in config (may break existing code)")
    
    # Check that gateway endpoints are valid URLs
    gateway = config.get("gateway", {})
    endpoints = gateway.get("endpoints", {})
    
    for name, endpoint in endpoints.items():
        url = endpoint.get("url", "")
        if url and ("http://" in url or "https://" in url):
            print(f"✅ Endpoint '{name}' has valid URL: {url}")
        else:
            print(f"⚠️  Endpoint '{name}' has invalid URL: {url}")
    
    return True

def main():
    """Main test function"""
    print("🚀 Bifrost Gateway Configuration Test")
    print("=" * 50)
    
    # Load configuration
    config = load_config()
    if not config:
        sys.exit(1)
    
    # Test gateway configuration
    if not test_gateway_config(config):
        print("\n❌ Gateway configuration test failed")
        sys.exit(1)
    
    # Simulate routing
    simulate_routing(config)
    
    # Test configuration validation
    test_config_validation()
    
    print("\n" + "=" * 50)
    print("✅ All tests completed successfully!")
    print("\n📋 Summary:")
    print("  - Gateway configuration is properly structured")
    print("  - Routing logic can be simulated")
    print("  - Configuration is compatible with existing system")
    print("\n⚠️  Note: Bifrost binary is currently crashing (SIGSEGV)")
    print("  This needs to be resolved before enabling Bifrost routing.")

if __name__ == "__main__":
    main()