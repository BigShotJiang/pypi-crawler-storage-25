#!/usr/bin/env python3
"""
Test script to check which backend endpoints are available.
Helps determine if system is using Ollama or vLLM.
"""

import asyncio
import aiohttp
import json
from typing import Dict, List, Optional

async def test_endpoint(url: str, name: str) -> Dict:
    """Test if a backend endpoint is available."""
    try:
        timeout = aiohttp.ClientTimeout(total=5)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            # Try different endpoints
            endpoints_to_test = [
                f"{url}/api/tags",  # Ollama
                f"{url}/v1/models",  # OpenAI/vLLM
                f"{url}/health",     # Health check
                url,                 # Root
            ]
            
            for endpoint in endpoints_to_test:
                try:
                    async with session.get(endpoint) as response:
                        if response.status == 200:
                            content_type = response.headers.get('Content-Type', '')
                            data = await response.text()
                            
                            # Try to parse JSON
                            try:
                                json_data = json.loads(data)
                                return {
                                    "name": name,
                                    "url": url,
                                    "status": "online",
                                    "endpoint": endpoint,
                                    "content_type": content_type,
                                    "is_json": True,
                                    "data_sample": str(json_data)[:200] + "..." if len(str(json_data)) > 200 else str(json_data)
                                }
                            except:
                                return {
                                    "name": name,
                                    "url": url,
                                    "status": "online",
                                    "endpoint": endpoint,
                                    "content_type": content_type,
                                    "is_json": False,
                                    "data_sample": data[:200] + "..." if len(data) > 200 else data
                                }
                except:
                    continue
            
            # If we get here, no endpoint worked
            return {
                "name": name,
                "url": url,
                "status": "offline",
                "error": "No endpoint responded with 200"
            }
            
    except Exception as e:
        return {
            "name": name,
            "url": url,
            "status": "error",
            "error": str(e)
        }

async def test_tool_calling(url: str, name: str) -> Optional[Dict]:
    """Test if backend supports tool calling."""
    try:
        timeout = aiohttp.ClientTimeout(total=10)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            
            # Test with a simple tool calling request
            payload = {
                "model": "test",
                "messages": [{"role": "user", "content": "Hello"}],
                "tools": [
                    {
                        "type": "function",
                        "function": {
                            "name": "get_weather",
                            "description": "Get weather for a location",
                            "parameters": {
                                "type": "object",
                                "properties": {
                                    "location": {"type": "string"}
                                }
                            }
                        }
                    }
                ],
                "tool_choice": "auto"
            }
            
            # Try OpenAI-compatible endpoint
            endpoint = f"{url}/v1/chat/completions"
            
            try:
                async with session.post(endpoint, json=payload) as response:
                    if response.status == 200:
                        data = await response.json()
                        return {
                            "name": name,
                            "endpoint": endpoint,
                            "supports_tool_calling": True,
                            "response": data
                        }
                    else:
                        return {
                            "name": name,
                            "endpoint": endpoint,
                            "supports_tool_calling": False,
                            "error": f"HTTP {response.status}"
                        }
            except:
                # Try Ollama endpoint
                endpoint = f"{url}/api/chat"
                try:
                    async with session.post(endpoint, json=payload) as response:
                        if response.status == 200:
                            data = await response.json()
                            return {
                                "name": name,
                                "endpoint": endpoint,
                                "supports_tool_calling": True,
                                "response": data
                            }
                        else:
                            return {
                                "name": name,
                                "endpoint": endpoint,
                                "supports_tool_calling": False,
                                "error": f"HTTP {response.status}"
                            }
                except Exception as e:
                    return {
                        "name": name,
                        "endpoint": endpoint,
                        "supports_tool_calling": False,
                        "error": str(e)
                    }
                
    except Exception as e:
        return {
            "name": name,
            "error": str(e),
            "supports_tool_calling": False
        }

async def main():
    """Test all potential backend endpoints."""
    print("🔍 Testing Backend Endpoints")
    print("=" * 60)
    
    # Common backend endpoints to test
    endpoints = [
        {"url": "http://localhost:11434", "name": "Ollama (Default)"},
        {"url": "http://localhost:8000/v1", "name": "vLLM Primary (8000)"},
        {"url": "http://localhost:8001/v1", "name": "vLLM Fallback (8001)"},
        {"url": "http://localhost:9000/v1", "name": "vLLM Science (9000)"},
        {"url": "http://127.0.0.1:8001/v1", "name": "vLLM Localhost"},
        {"url": "http://localhost:8080", "name": "LlamaStack"},
        {"url": "http://localhost:4001/v1", "name": "OpenAI Compatible"},
    ]
    
    # Test connectivity
    print("\n📡 Testing Connectivity:")
    connectivity_results = []
    
    for endpoint in endpoints:
        result = await test_endpoint(endpoint["url"], endpoint["name"])
        connectivity_results.append(result)
        
        status_icon = "✅" if result["status"] == "online" else "❌"
        print(f"  {status_icon} {endpoint['name']:25} {endpoint['url']}")
        if result["status"] == "online":
            print(f"     Endpoint: {result.get('endpoint', 'N/A')}")
            if result.get('is_json'):
                print(f"     JSON Response: {result.get('data_sample', 'N/A')}")
    
    # Test tool calling on online endpoints
    print("\n🛠️  Testing Tool Calling Support:")
    tool_calling_results = []
    
    for endpoint in endpoints:
        # Only test if endpoint is online
        online = any(r["name"] == endpoint["name"] and r["status"] == "online" for r in connectivity_results)
        if online:
            result = await test_tool_calling(endpoint["url"], endpoint["name"])
            tool_calling_results.append(result)
            
            if result and result.get("supports_tool_calling"):
                print(f"  ✅ {endpoint['name']:25} Supports tool calling")
                print(f"     Endpoint: {result.get('endpoint', 'N/A')}")
            else:
                print(f"  ❌ {endpoint['name']:25} No tool calling support")
                if result and "error" in result:
                    print(f"     Error: {result['error']}")
    
    # Analyze results
    print("\n📊 Analysis:")
    print("=" * 60)
    
    # Find which backend is likely being used
    ollama_online = any(r["name"] == "Ollama (Default)" and r["status"] == "online" for r in connectivity_results)
    vllm_online = any("vLLM" in r["name"] and r["status"] == "online" for r in connectivity_results)
    
    if ollama_online and not vllm_online:
        print("• System is likely using Ollama backend")
        print("• vLLM endpoints not detected")
        print("• Tool calling may be limited with Ollama models")
        
    elif vllm_online and not ollama_online:
        print("• System is likely using vLLM backend")
        print("• Ollama endpoint not detected")
        
    elif ollama_online and vllm_online:
        print("• Both Ollama and vLLM backends available")
        print("• Need to check which one is configured")
        
    else:
        print("• No LLM backends detected online")
        print("• Check if services are running")
    
    # Check tool calling support
    tool_support = any(r.get("supports_tool_calling") for r in tool_calling_results)
    if tool_support:
        print("• At least one backend supports tool calling")
    else:
        print("• No backends support tool calling (may cause issues)")
    
    # Recommendations
    print("\n💡 Recommendations:")
    print("=" * 60)
    
    if not tool_support:
        print("1. ❌ CRITICAL: No backend supports tool calling")
        print("   • This explains 'konnte ich die benötigten Werkzeuge nicht aktivieren'")
        print("   • Need to configure vLLM with tool calling support")
    
    if ollama_online and not vllm_online:
        print("2. ⚠️  System using Ollama, not vLLM")
        print("   • For enterprise (GitLab stable), should use vLLM")
        print("   • Update configuration to use vLLM endpoints")
    
    if vllm_online:
        print("3. ✅ vLLM available")
        print("   • Configure system to use vLLM for Business/Science modes")
        print("   • Update LLMEngine to call vLLM endpoint")
    
    print("\n4. 🔧 Implementation steps:")
    print("   • Update LLMEngine to support multiple backends")
    print("   • Integrate EGL Backend Router for mode-based selection")
    print("   • Configure vLLM as default for Business/Science modes")
    print("   • Test tool calling with vLLM backend")

if __name__ == "__main__":
    asyncio.run(main())