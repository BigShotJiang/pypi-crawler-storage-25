import pytest
import asyncio
import json
from unittest.mock import MagicMock, AsyncMock
from core.orchestrator import Orchestrator
from tests.conftest import MockBackendRouter
from core.context import ExecutionContext

@pytest.fixture
def mock_components():
    llm_engine = MagicMock()
    llm_engine.call_ollama = AsyncMock()
    llm_engine.call_gemini = AsyncMock()
    llm_engine.ensure_model = AsyncMock(return_value=True)
    
    tool_gateway = MagicMock()
    tool_gateway.get_tools_dict.return_value = {}
    tool_gateway.stream_execute = AsyncMock()
    
    memory_coordinator = MagicMock()
    memory_coordinator.store = AsyncMock()
    memory_coordinator.search = AsyncMock(return_value=[])
    
    context_manager = MagicMock()
    context_manager.get_pending_tool_call.return_value = None
    
    observability = MagicMock()
    observability.start_trace.return_value = ("trace_123", "span_123")
    
    workflow_manager = MagicMock()
    
    return {
        "llm_engine": llm_engine,
        "tool_gateway": tool_gateway,
        "memory_coordinator": memory_coordinator,
        "context_manager": context_manager,
        "observability": observability,
        "workflow_manager": workflow_manager,
        "prompts": {"mediator": "Mediator Prompt", "expert": "Expert Prompt"},
        "models": {"mediator": {"name": "mediator-model"}, "expert": {"name": "expert-model"}}
    }

@pytest.mark.asyncio
async def test_business_mode_behavioral_injection(mock_components):
    """Verify that BUSINESS mode injects correct behavioral instructions."""
    orch = Orchestrator(
        llm_engine=mock_components["llm_engine"],
        context_manager=mock_components["context_manager"],
        tool_executor=mock_components["tool_gateway"],
        models_config=mock_components["models"],
        observability=mock_components["observability"],
        memory_coordinator=mock_components["memory_coordinator"],
        workflow_manager=mock_components["workflow_manager"],
        backend_router=MockBackendRouter()
    )
    orch.prompts = mock_components["prompts"]
    
    context = ExecutionContext(
        session_id="test_session",
        tenant_id="test_tenant",
        mode="business",
        trace_id="hestia_test_trace"
    )
    
    # Mock call_ollama to return a simple generator
    async def mock_ollama_stream(*args, **kwargs):
        yield {"choices": [{"delta": {"content": "Hello Business"}}]}
    
    mock_components["llm_engine"].call_ollama.side_effect = mock_ollama_stream
    
    # We test _run_local_expert directly as it's the core injection point
    messages = [{"role": "system", "content": "Initial Prompt"}]
    
    gen = orch._run_local_expert(
        messages=messages,
        use_tools=False,
        context=context,
        model_name="test-model"
    )
    
    responses = []
    async for chunk in gen:
        responses.append(chunk)

    # Check call_ollama arguments
    called_args, called_kwargs = mock_components["llm_engine"].call_ollama.call_args
    sent_messages = called_kwargs["messages"]
    system_message = sent_messages[0]["content"]
    
    assert "[GOVERNANCE CONTEXT]" in system_message
    assert "System Mode: BUSINESS" in system_message
    assert "Prioritize high-assurance results" in system_message
    assert "Trace ID: hestia_test_trace" in system_message

@pytest.mark.asyncio
async def test_science_mode_behavioral_injection(mock_components):
    """Verify that SCIENCE mode injects correct behavioral instructions."""
    orch = Orchestrator(
        llm_engine=mock_components["llm_engine"],
        context_manager=mock_components["context_manager"],
        tool_executor=mock_components["tool_gateway"],
        models_config=mock_components["models"],
        observability=mock_components["observability"],
        memory_coordinator=mock_components["memory_coordinator"],
        workflow_manager=mock_components["workflow_manager"],
        backend_router=MockBackendRouter()
    )
    orch.prompts = mock_components["prompts"]
    
    context = ExecutionContext(
        session_id="science_session",
        tenant_id="lab_01",
        mode="science",
        trace_id="hestia_sci_trace"
    )
    
    messages = [{"role": "system", "content": "Initial Science Prompt"}]
    
    # Mock call_ollama
    async def mock_ollama_stream(*args, **kwargs):
        yield {"choices": [{"delta": {"content": "Affirmative Lab 01"}}]}
    mock_components["llm_engine"].call_ollama.side_effect = mock_ollama_stream
    
    async for _ in orch._run_local_expert(messages, False, context, "test-model"):
        pass

    called_args, called_kwargs = mock_components["llm_engine"].call_ollama.call_args
    system_message = called_kwargs["messages"][0]["content"]
    
    assert "System Mode: SCIENCE" in system_message
    assert "Prioritize reproducibility, data integrity" in system_message
    assert "Tenant ID: lab_01" in system_message

if __name__ == "__main__":
    pytest.main([__file__])
