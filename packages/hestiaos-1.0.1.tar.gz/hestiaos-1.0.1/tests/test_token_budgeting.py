import pytest
import asyncio
from unittest.mock import MagicMock, AsyncMock
from core.memory_coordinator import MemoryCoordinator

@pytest.mark.asyncio
async def test_memory_budget_and_threshold():
    # Mock adapter and embedding service
    coordinator = MemoryCoordinator()
    coordinator.adapter = AsyncMock()
    
    from datetime import datetime
    now_iso = datetime.now().isoformat()
    
    # Mock candidates
    # One high relevance, one low relevance, one high relevance but large
    candidates = [
        {"content": "Match 1", "similarity": 0.9, "embedding": [1.0, 0.0, 0.0], "created_at": now_iso},
        {"content": "Low relevance", "similarity": 0.1, "embedding": [0.0, 0.0, 1.0], "created_at": now_iso},
        {"content": "A" * 5000, "similarity": 0.8, "embedding": [0.8, 0.2, 0.0], "created_at": now_iso} # Too big
    ]
    coordinator.adapter.get.return_value = candidates
    
    # Mock embedding service
    from core.embedding_service import embedding_service
    embedding_service.generate_embedding = AsyncMock(return_value=[1.0, 0.0, 0.0])
    
    # Mock cosine_similarity and other utils if necessary, 
    # but here we'll just check if the logic in retrieve_context filters correctly.
    
    context = await coordinator.retrieve_context("test prompt", limit=10)
    
    # Results should:
    # 1. Exclude "Low relevance" (score 0.1 < 0.4)
    # 2. Include "Match 1"
    # 3. Exclude the very long one if it exceeds budget
    # Wait, in our implementation we process in order of rank_score.
    
    episodic = context["episodic"]
    assert len(episodic) >= 1
    assert any(m["content"] == "Match 1" for m in episodic)
    assert not any(m["content"] == "Low relevance" for m in episodic)
    assert not any(len(m["content"]) > 4000 for m in episodic) # The 5000 char one should be truncated
