"""
CE Bootstrap Script Test — Startet CE-Server als Subprocess.

Testet:
- Server startet auf konfiguriertem Port
- Health Check via HTTP
- CE-spezifische Response
- Server stoppt sauber

CI-CRT-013 (behavioral): CE Operational Compliance.
  - CE-Prozess startet und stoppt sauber
  - Health Check via HTTP erfolgreich

Usage:
    pytest tests/test_ce_bootstrap_script.py -v

    # Nur wenn live_api Marker gesetzt:
    pytest tests/test_ce_bootstrap_script.py -v -m live_api
"""

from __future__ import annotations

import os
import sys
import time
import signal
import subprocess
import pytest

# Dieser Test benötigt einen laufenden Server — nur mit live_api Marker
pytestmark = pytest.mark.live_api


@pytest.fixture(scope="module")
def ce_server_port():
    """Port für CE-Server (zufällig, um Konflikte zu vermeiden)."""
    return 19876  # Fester Port für Test-Isolation


@pytest.fixture(scope="module")
def ce_server_process(ce_server_port):
    """Startet CE-Server als Subprocess.

    CI-CRT-013: CE-Prozess startet sauber.
    """
    script_path = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "scripts",
        "ce_bootstrap.py",
    )

    env = os.environ.copy()
    env["PYTHONPATH"] = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    proc = subprocess.Popen(
        [sys.executable, script_path, "--port", str(ce_server_port), "--host", "127.0.0.1"],
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )

    # Warte auf Server-Start (max 10 Sekunden)
    max_wait = 10
    started = False
    for _ in range(max_wait * 2):
        time.sleep(0.5)
        if proc.poll() is not None:
            # Prozess beendet — Fehler
            stdout, stderr = proc.communicate()
            pytest.fail(
                f"CE-Server konnte nicht starten.\n"
                f"stdout: {stdout.decode()}\n"
                f"stderr: {stderr.decode()}"
            )
        # Prüfe, ob Port belegt ist (Server läuft)
        import socket
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if s.connect_ex(("127.0.0.1", ce_server_port)) == 0:
                started = True
                break

    if not started:
        proc.kill()
        pytest.fail(f"CE-Server nicht innerhalb von {max_wait}s gestartet")

    yield proc

    # Sauberer Stop
    proc.send_signal(signal.SIGINT)
    try:
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait()


class TestCE_BootstrapScript:
    """CE Bootstrap Script — Server starten, Health Check, sauberer Stop."""

    def test_ce_server_health_check(self, ce_server_process, ce_server_port):
        """GET /health → 200 OK mit CE-Feldern.

        CI-CRT-013: Health Check via HTTP erfolgreich.
        """
        import http.client

        conn = http.client.HTTPConnection("127.0.0.1", ce_server_port, timeout=5)
        conn.request("GET", "/health")
        response = conn.getresponse()

        assert response.status == 200, f"Health Check fehlgeschlagen: {response.status}"

        import json
        data = json.loads(response.read().decode())

        assert data["status"] == "ok"
        assert data["edition"] == "ce"
        assert data["policy_provider"] == "DefaultPolicyProvider"
        assert data["enterprise"] is False
        assert data["science"] is False

        conn.close()

    def test_ce_server_root_not_found(self, ce_server_process, ce_server_port):
        """GET / → 404 (kein Root-Endpoint in CE).

        CI-CRT-013: CE hat nur definierte Endpoints.
        """
        import http.client

        conn = http.client.HTTPConnection("127.0.0.1", ce_server_port, timeout=5)
        conn.request("GET", "/")
        response = conn.getresponse()

        # CE hat keinen Root-Endpoint → 404
        assert response.status == 404

        conn.close()

    def test_ce_server_no_enterprise_endpoints(self, ce_server_process, ce_server_port):
        """Enterprise-Endpoints sind in CE nicht verfügbar.

        CI-CRT-003: Kein Enterprise in CE.
        """
        import http.client

        enterprise_endpoints = ["/egl", "/enterprise", "/admin", "/license"]
        for endpoint in enterprise_endpoints:
            conn = http.client.HTTPConnection("127.0.0.1", ce_server_port, timeout=5)
            conn.request("GET", endpoint)
            response = conn.getresponse()
            # Sollte 404 sein (nicht 200 oder 500)
            assert response.status == 404, \
                f"Enterprise-Endpoint '{endpoint}' in CE verfügbar (Status {response.status})"
            conn.close()

    def test_ce_server_stops_cleanly(self, ce_server_process, ce_server_port):
        """CE-Server stoppt sauber nach SIGINT.

        CI-CRT-013: CE-Prozess stoppt sauber.
        """
        import socket

        # Server läuft noch
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            assert s.connect_ex(("127.0.0.1", ce_server_port)) == 0, \
                "Server läuft nicht mehr vor Test-Ende"

        # Prozess wird durch Fixture-Teardown beendet
        # Hier prüfen wir nur, dass der Prozess noch läuft
        assert ce_server_process.poll() is None, \
            "CE-Server-Prozess ist vorzeitig beendet"
