"""
Tests für OrchestratorExecutionAdapter (Phase C2.2)

Testet die vollständige Ablösung von DefaultAntigravityAdapter durch
OrchestratorExecutionAdapter mit IntentOrchestrator-Pipeline,
CapabilityEngine, IREventRouter und TemporalVibeManager.

HINWEIS: Wir importieren ExecutionRequest/ExecutionResult/ExecutionStrategy/TaskType
direkt aus der Datei (nicht über das Package), um den Package-Import von
core.antigravity.__init__ zu vermeiden, der core.logger benötigt (nicht existent).

Test-Strategie:
1. Direkte Strategie (DIRECT) — Tool-Ausführung ohne semantische Interpretation
2. Semantische Strategie (SEMANTIC) — IR-basiertes Routing via IREventRouter
3. Vibe-Coding-Strategie (VIBE_CODING) — Mit TemporalVibeManager-Snapshots
4. Hybride Strategie (HYBRID) — Fallback semantic → direct
5. Metriken — Tasks executed/succeeded/failed tracking
6. TaskType → Strategie-Mapping
7. Provider-Registrierung und -Empfehlungen
8. Shutdown-Verhalten
9. Kompatibilitäts-Bridge (AntigravityToOrchestratorBridge)
10. Factory-Funktion (create_orchestrator_adapter)
"""

import asyncio
import sys
import importlib.util
from typing import Dict, Any, Optional, List
from datetime import datetime

import pytest

# ── Direkter Import aus der Datei (vermeidet Package-__init__) ────

# Lade pipeline.py zuerst und registriere in sys.modules,
# damit execution_adapter.py das bereits geladene Modul wiederverwendet
import sys
_PIPELINE_MODULE_NAME = "pipeline_module"
_pipeline_spec = importlib.util.spec_from_file_location(
    _PIPELINE_MODULE_NAME,
    "core/orchestrator/pipeline.py",
)
_pipeline_mod = importlib.util.module_from_spec(_pipeline_spec)
sys.modules[_PIPELINE_MODULE_NAME] = _pipeline_mod
_pipeline_spec.loader.exec_module(_pipeline_mod)

# Lade execution_adapter.py aus orchestrator direkt als Modul
_orch_adapter_spec = importlib.util.spec_from_file_location(
    "orchestrator_execution_adapter_module",
    "core/orchestrator/execution_adapter.py",
)
_orch_adapter = importlib.util.module_from_spec(_orch_adapter_spec)
_orch_adapter_spec.loader.exec_module(_orch_adapter)

OrchestratorExecutionAdapter = _orch_adapter.OrchestratorExecutionAdapter
AntigravityToOrchestratorBridge = _orch_adapter.AntigravityToOrchestratorBridge
create_orchestrator_adapter = _orch_adapter.create_orchestrator_adapter
TASK_TYPE_TO_STRATEGY = _orch_adapter.TASK_TYPE_TO_STRATEGY
TASK_TYPE_TO_REQUIRED_CAPABILITIES = _orch_adapter.TASK_TYPE_TO_REQUIRED_CAPABILITIES
ExecutionRequest = _orch_adapter.ExecutionRequest
ExecutionResult = _orch_adapter.ExecutionResult
ExecutionStrategy = _orch_adapter.ExecutionStrategy
TaskType = _orch_adapter.TaskType

# pipeline.py wurde bereits oben geladen (pipeline_module in sys.modules)
_pipeline = sys.modules[_PIPELINE_MODULE_NAME]
IntentOrchestrator = _pipeline.IntentOrchestrator
StepType = _pipeline.StepType
PipelineStep = _pipeline.PipelineStep

# Lade capability_engine.py direkt als Modul
_CAP_MODULE_NAME = "capability_engine_module"
_cap_spec = importlib.util.spec_from_file_location(
    _CAP_MODULE_NAME,
    "core/ir/capability_engine.py",
)
_cap = importlib.util.module_from_spec(_cap_spec)
sys.modules[_CAP_MODULE_NAME] = _cap
_cap_spec.loader.exec_module(_cap)

CapabilityEngine = _cap.CapabilityEngine
Capability = _cap.Capability
CapabilityStatus = _cap.CapabilityStatus

# Lade ir_event_router.py direkt als Modul
_ROUTER_MODULE_NAME = "ir_event_router_module"
_router_spec = importlib.util.spec_from_file_location(
    _ROUTER_MODULE_NAME,
    "core/ir/ir_event_router.py",
)
_router = importlib.util.module_from_spec(_router_spec)
sys.modules[_ROUTER_MODULE_NAME] = _router
_router_spec.loader.exec_module(_router)

IREventRouter = _router.IREventRouter

# Lade temporal_vibe.py direkt als Modul
_VIBE_MODULE_NAME = "temporal_vibe_module"
_vibe_spec = importlib.util.spec_from_file_location(
    _VIBE_MODULE_NAME,
    "core/vibe/temporal_vibe.py",
)
_vibe = importlib.util.module_from_spec(_vibe_spec)
sys.modules[_VIBE_MODULE_NAME] = _vibe
_vibe_spec.loader.exec_module(_vibe)

TemporalVibeManager = _vibe.TemporalVibeManager
VibeSnapshot = _vibe.VibeSnapshot


# ── Fixtures ──────────────────────────────────────────────────────


@pytest.fixture
def capability_engine():
    """CapabilityEngine mit Test-Capabilities."""
    engine = CapabilityEngine()

    # Capabilities registrieren
    engine.register_many([
        Capability(
            capability_id="audio.synthesis",
            name="Audio Synthesis",
            description="Generate audio via synthesis",
            status=CapabilityStatus.IMPLEMENTED,
            styles=("ambient",),
        ),
        Capability(
            capability_id="audio.playback",
            name="Audio Playback",
            description="Play back audio",
            status=CapabilityStatus.IMPLEMENTED,
            styles=("neutral",),
        ),
        Capability(
            capability_id="pattern.generation",
            name="Pattern Generation",
            description="Generate musical patterns",
            status=CapabilityStatus.IMPLEMENTED,
            styles=("techno",),
        ),
        Capability(
            capability_id="session.control",
            name="Session Control",
            description="Control audio sessions",
            status=CapabilityStatus.IMPLEMENTED,
            styles=("neutral",),
        ),
        Capability(
            capability_id="vibe.transition",
            name="Vibe Transition",
            description="Transition between vibe states",
            status=CapabilityStatus.IMPLEMENTED,
            styles=("ambient",),
        ),
    ])

    # Provider registrieren (Liste von Capability-Namen als Strings)
    engine.register_provider_capabilities(
        "audio_mcp",
        ["audio.synthesis", "audio.playback"],
        styles=["ambient", "neutral"],
    )
    engine.register_provider_capabilities(
        "pattern_provider",
        ["pattern.generation"],
        styles=["techno"],
    )
    engine.register_provider_capabilities(
        "session_manager",
        ["session.control"],
        styles=["neutral"],
    )

    return engine


@pytest.fixture
def vibe_manager():
    """TemporalVibeManager für Test-Sessions."""
    return TemporalVibeManager()


@pytest.fixture
def event_router(capability_engine):
    """IREventRouter mit synchronisiertem IR-Graph."""
    router = IREventRouter(capability_engine=capability_engine)
    router.sync_graph()
    return router


@pytest.fixture
def orchestrator(capability_engine, event_router, vibe_manager):
    """IntentOrchestrator mit allen Komponenten."""
    return IntentOrchestrator(
        capability_engine=capability_engine,
        event_router=event_router,
        temporal_vibe_manager=vibe_manager,
    )


@pytest.fixture
def adapter(orchestrator, capability_engine, event_router, vibe_manager):
    """OrchestratorExecutionAdapter mit allen Komponenten."""
    return OrchestratorExecutionAdapter(
        orchestrator=orchestrator,
        capability_engine=capability_engine,
        event_router=event_router,
        vibe_manager=vibe_manager,
    )


# ── Test 1: DIRECT Strategy ───────────────────────────────────────


@pytest.mark.asyncio
async def test_direct_strategy(adapter):
    """Teste direkte Tool-Ausführung (DIRECT)."""
    await adapter.initialize()

    request = ExecutionRequest(
        task_id="test_direct_001",
        task_type=TaskType.SESSION_MANAGEMENT,
        description="Start audio session",
        session_id="session_direct_001",
        context={
            "tool_name": "session_manager",
            "tool_args": {"action": "start", "type": "audio"},
        },
        strategy=ExecutionStrategy.DIRECT,
    )

    result = await adapter.execute_task(request)

    assert result.success, f"Direct execution failed: {result.error_message}"
    assert result.task_id == "test_direct_001"
    assert result.plugin_used is not None
    assert result.execution_time >= 0.0


# ── Test 2: SEMANTIC Strategy ─────────────────────────────────────


@pytest.mark.asyncio
async def test_semantic_strategy(adapter):
    """Teste semantische Interpretation + IR-basiertes Routing (SEMANTIC)."""
    await adapter.initialize()

    request = ExecutionRequest(
        task_id="test_semantic_001",
        task_type=TaskType.AUDIO_GENERATION,
        description="Generate ambient audio",
        session_id="session_semantic_001",
        context={
            "style": "ambient",
            "required_capabilities": ["audio.synthesis"],
        },
        strategy=ExecutionStrategy.SEMANTIC,
    )

    result = await adapter.execute_task(request)

    assert result.success, f"Semantic execution failed: {result.error_message}"
    assert result.task_id == "test_semantic_001"
    assert result.plugin_used is not None
    assert result.execution_time >= 0.0

    # Prüfe Metriken
    if result.metrics:
        assert "strategy" in result.metrics
        assert result.metrics["strategy"] == "semantic"


# ── Test 3: VIBE_CODING Strategy ──────────────────────────────────


@pytest.mark.asyncio
async def test_vibe_coding_strategy(adapter, vibe_manager):
    """Teste Vibe-Coding mit TemporalVibeManager-Snapshots (VIBE_CODING)."""
    await adapter.initialize()

    # Zuerst Vibe-Session erstellen (ambient ist in CapabilityEngine registriert)
    await vibe_manager.create_session(
        session_id="session_vibe_001",
        initial_state={"style": "ambient", "energy": 0.7},
    )

    request = ExecutionRequest(
        task_id="test_vibe_001",
        task_type=TaskType.VIBE_TRANSITION,
        description="Transition to ambient vibe",
        session_id="session_vibe_001",
        context={
            "style": "ambient",
            "vibe_updates": {"style": "ambient", "energy": 0.8},
        },
        strategy=ExecutionStrategy.VIBE_CODING,
    )

    result = await adapter.execute_task(request)

    assert result.success, f"Vibe coding execution failed: {result.error_message}"
    assert result.task_id == "test_vibe_001"
    assert result.execution_time >= 0.0

    # Prüfe, ob Vibe-State aktualisiert wurde
    current_state = await vibe_manager.get_current_state("session_vibe_001")
    assert current_state is not None
    assert current_state.style is not None


# ── Test 4: HYBRID Strategy ───────────────────────────────────────


@pytest.mark.asyncio
async def test_hybrid_strategy(adapter):
    """Teste hybride Ausführung mit Fallback (HYBRID)."""
    await adapter.initialize()

    # Request ohne gültige Capabilities — sollte auf DIRECT fallen
    request = ExecutionRequest(
        task_id="test_hybrid_001",
        task_type=TaskType.PARAMETER_CONTROL,
        description="Set volume to 80%",
        session_id="session_hybrid_001",
        context={
            "tool_name": "parameter_control",
            "tool_args": {"parameter": "volume", "value": 80},
            "style": "unknown_style_that_wont_match",
        },
        strategy=ExecutionStrategy.HYBRID,
    )

    result = await adapter.execute_task(request)

    # HYBRID sollte immer erfolgreich sein (Fallback zu DIRECT)
    assert result.success, f"Hybrid execution failed: {result.error_message}"
    assert result.task_id == "test_hybrid_001"
    assert result.execution_time >= 0.0


# ── Test 5: Metriken ──────────────────────────────────────────────


@pytest.mark.asyncio
async def test_metrics_tracking(adapter):
    """Teste Metrik-Tracking nach mehreren Task-Ausführungen."""
    await adapter.initialize()

    # Führe mehrere Tasks aus
    tasks = [
        ExecutionRequest(
            task_id=f"metrics_test_{i}",
            task_type=TaskType.SESSION_MANAGEMENT,
            description=f"Test task {i}",
            session_id="session_metrics_001",
            context={"tool_name": f"tool_{i}", "tool_args": {}},
            strategy=ExecutionStrategy.DIRECT,
        )
        for i in range(3)
    ]

    for task in tasks:
        await adapter.execute_task(task)

    # Metriken abrufen
    metrics = await adapter.get_metrics()

    assert metrics["tasks_executed"] >= 3
    assert metrics["tasks_succeeded"] >= 0
    assert metrics["tasks_failed"] >= 0
    assert metrics["total_execution_time"] >= 0.0
    assert metrics["average_execution_time"] >= 0.0
    assert metrics["success_rate"] >= 0.0
    assert "strategies_used" in metrics
    assert metrics["strategies_used"].get("direct", 0) >= 3


# ── Test 6: TaskType → Strategie Mapping ──────────────────────────


@pytest.mark.asyncio
async def test_task_type_strategy_mapping(adapter):
    """Teste korrektes TaskType → Strategie Mapping."""
    await adapter.initialize()

    # Prüfe alle TaskTypes
    for task_type in TaskType:
        strategy = adapter.get_strategy_for_task_type(task_type)
        assert strategy in ExecutionStrategy, (
            f"TaskType {task_type} mapped to invalid strategy {strategy}"
        )

    # Prüfe spezifische Mappings
    assert adapter.get_strategy_for_task_type(TaskType.AUDIO_GENERATION) == ExecutionStrategy.SEMANTIC
    assert adapter.get_strategy_for_task_type(TaskType.SESSION_MANAGEMENT) == ExecutionStrategy.DIRECT
    assert adapter.get_strategy_for_task_type(TaskType.VIBE_TRANSITION) == ExecutionStrategy.VIBE_CODING

    # Prüfe Capability-Mapping
    audio_caps = adapter.get_required_capabilities(TaskType.AUDIO_GENERATION)
    assert "audio.synthesis" in audio_caps
    assert "audio.playback" in audio_caps

    session_caps = adapter.get_required_capabilities(TaskType.SESSION_MANAGEMENT)
    assert "session.control" in session_caps


# ── Test 7: Provider-Registrierung und -Empfehlungen ──────────────


@pytest.mark.asyncio
async def test_provider_registration_and_recommendations(adapter):
    """Teste Provider-Registrierung und Empfehlungen."""
    await adapter.initialize()

    # Provider-Capabilities registrieren
    await adapter.register_provider_capabilities(
        provider_id="test_provider",
        capabilities=[
            {"name": "audio.synthesis", "style": "ambient", "energy": 0.6},
            {"name": "pattern.generation", "style": "techno", "energy": 0.9},
        ],
    )

    # Empfehlungen abrufen
    recommendations = await adapter.get_recommended_providers(
        intent="Generate ambient music",
        style="ambient",
        session_id="session_rec_001",
    )

    # CapabilityEngine.get_provider_recommendations gibt eine Liste zurück
    assert isinstance(recommendations, list)
    assert len(recommendations) > 0


# ── Test 8: Shutdown-Verhalten ────────────────────────────────────


@pytest.mark.asyncio
async def test_shutdown_behavior(adapter):
    """Teste sauberes Herunterfahren des Adapters."""
    await adapter.initialize()

    # Vor Shutdown
    metrics_before = await adapter.get_metrics()
    assert metrics_before is not None

    # Shutdown
    await adapter.shutdown()

    # Nach Shutdown sollten keine Fehler auftreten
    metrics_after = await adapter.get_metrics()
    assert metrics_after is not None


# ── Test 9: Kompatibilitäts-Bridge ────────────────────────────────


@pytest.mark.asyncio
async def test_compatibility_bridge(adapter):
    """Teste AntigravityToOrchestratorBridge (Kompatibilitäts-Layer)."""
    await adapter.initialize()

    bridge = AntigravityToOrchestratorBridge(adapter)

    # Bridge sollte alle Protocol-Methoden delegieren
    await bridge.initialize()

    strategies = await bridge.get_available_strategies()
    assert ExecutionStrategy.DIRECT in strategies
    assert ExecutionStrategy.SEMANTIC in strategies
    assert ExecutionStrategy.VIBE_CODING in strategies
    assert ExecutionStrategy.HYBRID in strategies

    task_types = await bridge.get_supported_task_types()
    assert TaskType.AUDIO_GENERATION in task_types
    assert TaskType.SESSION_MANAGEMENT in task_types

    # Task über Bridge ausführen
    request = ExecutionRequest(
        task_id="bridge_test_001",
        task_type=TaskType.SESSION_MANAGEMENT,
        description="Bridge test execution",
        session_id="session_bridge_001",
        context={"tool_name": "test_tool", "tool_args": {}},
        strategy=ExecutionStrategy.DIRECT,
    )

    result = await bridge.execute_task(request)
    assert result.success, f"Bridge execution failed: {result.error_message}"

    metrics = await bridge.get_metrics()
    assert metrics["tasks_executed"] >= 1

    await bridge.shutdown()


# ── Test 10: Factory-Funktion ─────────────────────────────────────


@pytest.mark.asyncio
async def test_factory_function(capability_engine, event_router, vibe_manager):
    """Teste create_orchestrator_adapter Factory-Funktion."""
    orchestrator = IntentOrchestrator(
        capability_engine=capability_engine,
        event_router=event_router,
        temporal_vibe_manager=vibe_manager,
    )

    adapter = await create_orchestrator_adapter(
        orchestrator=orchestrator,
        capability_engine=capability_engine,
        event_router=event_router,
        vibe_manager=vibe_manager,
        config={
            "provider_capabilities": {
                "factory_provider": [
                    {"name": "audio.synthesis", "style": "ambient", "energy": 0.5},
                ],
            },
        },
    )

    assert adapter is not None
    assert isinstance(adapter, OrchestratorExecutionAdapter)

    # Prüfe, ob initialisiert
    strategies = await adapter.get_available_strategies()
    assert len(strategies) >= 3

    # Task ausführen
    request = ExecutionRequest(
        task_id="factory_test_001",
        task_type=TaskType.AUDIO_GENERATION,
        description="Factory test",
        session_id="session_factory_001",
        context={"style": "ambient"},
        strategy=ExecutionStrategy.SEMANTIC,
    )

    result = await adapter.execute_task(request)
    assert result is not None

    await adapter.shutdown()


# ── Main ──────────────────────────────────────────────────────────


async def main():
    """Führe alle Tests manuell aus."""
    print("=" * 60)
    print("Phase C2.2: OrchestratorExecutionAdapter Tests")
    print("=" * 60)

    # Komponenten erstellen
    engine = CapabilityEngine()
    engine.register_many([
        Capability("audio.synthesis", "Audio Synthesis", "desc", CapabilityStatus.IMPLEMENTED, metadata={"style": "ambient"}),
        Capability("audio.playback", "Audio Playback", "desc", CapabilityStatus.IMPLEMENTED, metadata={"style": "neutral"}),
        Capability("pattern.generation", "Pattern Generation", "desc", CapabilityStatus.IMPLEMENTED, metadata={"style": "techno"}),
        Capability("session.control", "Session Control", "desc", CapabilityStatus.IMPLEMENTED, metadata={"style": "neutral"}),
        Capability("vibe.transition", "Vibe Transition", "desc", CapabilityStatus.IMPLEMENTED, metadata={"style": "ambient"}),
    ])
    engine.register_provider_capabilities("audio_mcp", [
        {"name": "audio.synthesis", "style": "ambient", "energy": 0.5},
        {"name": "audio.playback", "style": "neutral", "energy": 0.5},
    ])
    engine.register_provider_capabilities("pattern_provider", [
        {"name": "pattern.generation", "style": "techno", "energy": 0.8},
    ])

    vibe_mgr = TemporalVibeManager()
    router = IREventRouter(capability_engine=engine)
    router.sync_graph()
    orch = IntentOrchestrator(
        capability_engine=engine,
        event_router=router,
        vibe_manager=vibe_mgr,
    )

    adapter = OrchestratorExecutionAdapter(
        orchestrator=orch,
        capability_engine=engine,
        event_router=router,
        vibe_manager=vibe_mgr,
    )
    await adapter.initialize()

    tests = [
        ("DIRECT Strategy", test_direct_strategy, [adapter]),
        ("SEMANTIC Strategy", test_semantic_strategy, [adapter]),
        ("VIBE_CODING Strategy", test_vibe_coding_strategy, [adapter, vibe_mgr]),
        ("HYBRID Strategy", test_hybrid_strategy, [adapter]),
        ("Metrics Tracking", test_metrics_tracking, [adapter]),
        ("TaskType → Strategy Mapping", test_task_type_strategy_mapping, [adapter]),
        ("Provider Registration", test_provider_registration_and_recommendations, [adapter]),
        ("Shutdown Behavior", test_shutdown_behavior, [adapter]),
        ("Compatibility Bridge", test_compatibility_bridge, [adapter]),
        ("Factory Function", test_factory_function, [engine, router, vibe_mgr]),
    ]

    passed = 0
    failed = 0

    for name, test_func, args in tests:
        try:
            await test_func(*args)
            print(f"  ✅ {name}")
            passed += 1
        except Exception as e:
            print(f"  ❌ {name}: {e}")
            import traceback
            traceback.print_exc()
            failed += 1

    print(f"\n{'=' * 60}")
    print(f"Ergebnis: {passed}/{passed + failed} bestanden")
    if failed > 0:
        print(f"⚠️  {failed} Tests fehlgeschlagen")
    print(f"{'=' * 60}")

    await adapter.shutdown()
    return passed == (passed + failed)


if __name__ == "__main__":
    asyncio.run(main())
