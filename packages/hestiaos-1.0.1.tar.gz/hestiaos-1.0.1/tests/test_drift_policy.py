"""
Tests für die DriftPolicyEngine (reine Logik, keine Mocks).

Testet:
    - DriftLevel Enum
    - evaluate() mit Standard-Thresholds
    - evaluate() mit benutzerdefinierten Thresholds
    - update_threshold() zur Laufzeit
    - thresholds-Property
    - Grenzfälle (Boundaries)
    - Fehlerfälle (negative Werte)
"""

import pytest
from core.governance.drift_policy import DriftLevel, DriftPolicyEngine, DEFAULT_THRESHOLDS


class TestDriftLevel:
    """Tests für das DriftLevel Enum."""

    def test_values(self):
        assert DriftLevel.CLEAN.value == 0
        assert DriftLevel.WARNING.value == 1
        assert DriftLevel.DEGRADED.value == 2
        assert DriftLevel.BREAKER.value == 3

    def test_ordering(self):
        """DriftLevel muss aufsteigend sein: CLEAN < WARNING < DEGRADED < BREAKER."""
        assert DriftLevel.CLEAN.value < DriftLevel.WARNING.value
        assert DriftLevel.WARNING.value < DriftLevel.DEGRADED.value
        assert DriftLevel.DEGRADED.value < DriftLevel.BREAKER.value


class TestDriftPolicyEngineDefaults:
    """Tests mit Standard-Thresholds: WARNING=10, DEGRADED=100, BREAKER=500."""

    def setup_method(self):
        self.engine = DriftPolicyEngine()

    def test_clean_at_zero(self):
        """evaluate(0) → CLEAN"""
        assert self.engine.evaluate(0) == DriftLevel.CLEAN

    def test_clean_below_warning(self):
        """evaluate(9) → CLEAN (unter WARNING-Schwelle)"""
        assert self.engine.evaluate(9) == DriftLevel.CLEAN

    def test_warning_at_exact_boundary(self):
        """evaluate(10) → WARNING (exakte Grenze: counter >= threshold → WARNING)"""
        assert self.engine.evaluate(10) == DriftLevel.WARNING

    def test_warning_above_boundary(self):
        """evaluate(11) → WARNING"""
        assert self.engine.evaluate(11) == DriftLevel.WARNING

    def test_warning_at_99(self):
        """evaluate(99) → WARNING (knapp unter DEGRADED)"""
        assert self.engine.evaluate(99) == DriftLevel.WARNING

    def test_degraded_at_100(self):
        """evaluate(100) → DEGRADED (exakte Grenze: counter >= threshold → DEGRADED)"""
        assert self.engine.evaluate(100) == DriftLevel.DEGRADED

    def test_degraded_above_boundary(self):
        """evaluate(101) → DEGRADED"""
        assert self.engine.evaluate(101) == DriftLevel.DEGRADED

    def test_degraded_at_499(self):
        """evaluate(499) → DEGRADED (knapp unter BREAKER)"""
        assert self.engine.evaluate(499) == DriftLevel.DEGRADED

    def test_breaker_at_500(self):
        """evaluate(500) → BREAKER (exakte Grenze: counter >= threshold → BREAKER)"""
        assert self.engine.evaluate(500) == DriftLevel.BREAKER

    def test_breaker_above_boundary(self):
        """evaluate(501) → BREAKER"""
        assert self.engine.evaluate(501) == DriftLevel.BREAKER

    def test_breaker_high_value(self):
        """evaluate(10000) → BREAKER (deutlich über Schwelle)"""
        assert self.engine.evaluate(10000) == DriftLevel.BREAKER

    def test_negative_counter(self):
        """evaluate(-1) → CLEAN (negative Werte sind unter jeder Schwelle)"""
        assert self.engine.evaluate(-1) == DriftLevel.CLEAN


class TestDriftPolicyEngineCustomThresholds:
    """Tests mit benutzerdefinierten Thresholds."""

    def test_custom_all_levels(self):
        """Alle Thresholds überschrieben."""
        engine = DriftPolicyEngine(thresholds={
            DriftLevel.WARNING: 5,
            DriftLevel.DEGRADED: 20,
            DriftLevel.BREAKER: 50,
        })
        assert engine.evaluate(4) == DriftLevel.CLEAN
        assert engine.evaluate(5) == DriftLevel.WARNING
        assert engine.evaluate(6) == DriftLevel.WARNING
        assert engine.evaluate(19) == DriftLevel.WARNING
        assert engine.evaluate(20) == DriftLevel.DEGRADED
        assert engine.evaluate(21) == DriftLevel.DEGRADED
        assert engine.evaluate(49) == DriftLevel.DEGRADED
        assert engine.evaluate(50) == DriftLevel.BREAKER
        assert engine.evaluate(51) == DriftLevel.BREAKER

    def test_custom_partial_thresholds(self):
        """Nur ein Threshold überschrieben, andere fallen auf Default zurück."""
        engine = DriftPolicyEngine(thresholds={
            DriftLevel.BREAKER: 100,
        })
        assert engine.thresholds[DriftLevel.WARNING] == DEFAULT_THRESHOLDS[DriftLevel.WARNING]
        assert engine.thresholds[DriftLevel.DEGRADED] == DEFAULT_THRESHOLDS[DriftLevel.DEGRADED]
        assert engine.thresholds[DriftLevel.BREAKER] == 100

    def test_custom_empty_dict(self):
        """Leeres Dict → alle Thresholds bleiben auf Default."""
        engine = DriftPolicyEngine(thresholds={})
        for level, expected in DEFAULT_THRESHOLDS.items():
            assert engine.thresholds[level] == expected


class TestDriftPolicyEngineThresholdsProperty:
    """Tests für die thresholds-Property."""

    def test_returns_copy(self):
        """thresholds muss eine Kopie zurückgeben, nicht das originale Dict."""
        engine = DriftPolicyEngine()
        t = engine.thresholds
        t[DriftLevel.WARNING] = 999
        # Das Original darf nicht verändert sein
        assert engine.thresholds[DriftLevel.WARNING] == DEFAULT_THRESHOLDS[DriftLevel.WARNING]

    def test_default_values(self):
        """Standard-Thresholds müssen DEFAULT_THRESHOLDS entsprechen."""
        engine = DriftPolicyEngine()
        for level, expected in DEFAULT_THRESHOLDS.items():
            assert engine.thresholds[level] == expected


class TestDriftPolicyEngineUpdateThreshold:
    """Tests für update_threshold()."""

    def test_update_warning(self):
        engine = DriftPolicyEngine()
        engine.update_threshold(DriftLevel.WARNING, 25)
        assert engine.thresholds[DriftLevel.WARNING] == 25
        # evaluate muss neuen Threshold verwenden
        assert engine.evaluate(24) == DriftLevel.CLEAN
        assert engine.evaluate(25) == DriftLevel.WARNING
        assert engine.evaluate(26) == DriftLevel.WARNING

    def test_update_degraded(self):
        engine = DriftPolicyEngine()
        engine.update_threshold(DriftLevel.DEGRADED, 50)
        assert engine.thresholds[DriftLevel.DEGRADED] == 50
        assert engine.evaluate(49) == DriftLevel.WARNING
        assert engine.evaluate(50) == DriftLevel.DEGRADED
        assert engine.evaluate(51) == DriftLevel.DEGRADED

    def test_update_breaker(self):
        engine = DriftPolicyEngine()
        engine.update_threshold(DriftLevel.BREAKER, 200)
        assert engine.thresholds[DriftLevel.BREAKER] == 200
        assert engine.evaluate(199) == DriftLevel.DEGRADED
        assert engine.evaluate(200) == DriftLevel.BREAKER
        assert engine.evaluate(201) == DriftLevel.BREAKER

    def test_update_negative_raises(self):
        """Negative Thresholds müssen einen ValueError werfen."""
        engine = DriftPolicyEngine()
        with pytest.raises(ValueError, match="non-negative"):
            engine.update_threshold(DriftLevel.WARNING, -5)

    def test_update_zero_allowed(self):
        """Threshold = 0 ist erlaubt (bedeutet: alles >= 0 ist dieser Level)."""
        engine = DriftPolicyEngine()
        engine.update_threshold(DriftLevel.WARNING, 0)
        assert engine.thresholds[DriftLevel.WARNING] == 0
        # counter >= 0 → WARNING (da 0 >= 0)
        assert engine.evaluate(0) == DriftLevel.WARNING


class TestDriftPolicyEngineIntegration:
    """Integrationstests: mehrere evaluate()-Aufrufe in Folge."""

    def test_increasing_counter(self):
        """Simuliert steigenden Counter über Zeit."""
        engine = DriftPolicyEngine()
        assert engine.evaluate(0) == DriftLevel.CLEAN
        assert engine.evaluate(5) == DriftLevel.CLEAN
        assert engine.evaluate(10) == DriftLevel.WARNING
        assert engine.evaluate(15) == DriftLevel.WARNING
        assert engine.evaluate(50) == DriftLevel.WARNING
        assert engine.evaluate(100) == DriftLevel.DEGRADED
        assert engine.evaluate(150) == DriftLevel.DEGRADED
        assert engine.evaluate(300) == DriftLevel.DEGRADED
        assert engine.evaluate(500) == DriftLevel.BREAKER
        assert engine.evaluate(600) == DriftLevel.BREAKER

    def test_reset_counter(self):
        """Counter wird zurückgesetzt → CLEAN."""
        engine = DriftPolicyEngine()
        assert engine.evaluate(600) == DriftLevel.BREAKER
        assert engine.evaluate(0) == DriftLevel.CLEAN
