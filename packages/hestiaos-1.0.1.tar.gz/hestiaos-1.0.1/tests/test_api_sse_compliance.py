import json
import pytest
import asyncio
from httpx import AsyncClient, ASGITransport
from api.main import app

@pytest.mark.asyncio
async def test_api_sse_compliance():
    """
    Verifies that the /chat/stream endpoint returns valid SSE formatted JSON.
    Uses AsyncClient to avoid 'no running event loop' errors.
    """
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        # 1. Start a streaming request
        response = await ac.post(
            "/chat/stream",
            json={
                "message": "Hello, compliance test!",
                "use_tools": False,
                "session_id": "test_sse_session"
            },
            headers={"X-Tenant-Id": "community-test"},
            timeout=30.0
        )
        
        assert response.status_code == 200
        assert "text/event-stream" in response.headers["content-type"]
        
        # 2. Parse the stream
        data_found = False
        tokens_found = False
        
        # httpx allows iterating over lines
        async for line in response.aiter_lines():
            if line.startswith("data: "):
                payload = line[6:].strip()
                if payload == "[DONE]":
                    continue
                
                data_found = True
                try:
                    data = json.loads(payload)
                    assert "type" in data
                    if data["type"] == "token":
                        tokens_found = True
                except json.JSONDecodeError:
                    pytest.fail(f"Invalid JSON payload in SSE stream: {payload}")
                    
        assert data_found, "No data events found in SSE stream"

if __name__ == "__main__":
    # Standard pytest run
    import sys
    sys.exit(pytest.main([__file__]))
