#!/usr/bin/env python3
"""
Test script for canary routing and shadow mode testing.
Validates that the gateway abstraction layer correctly routes traffic
between LiteLLM and Bifrost based on configuration.
"""
import asyncio
import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from core.gateway.factory import GatewayFactory
from core.config import config_manager
from core.observability.logger import system_logger

async def test_gateway_health():
    """Test health checks for both gateways."""
    print("=== Testing Gateway Health ===")
    
    # Create gateway instance
    gateway = GatewayFactory.create_gateway()
    
    # Check health
    health = await gateway.health()
    print(f"Primary Health: {health.get('primary', {}).get('healthy', False)}")
    if 'fallback' in health:
        print(f"Fallback Health: {health.get('fallback', {}).get('healthy', False)}")
    
    return health.get('primary', {}).get('healthy', False)

async def test_shadow_mode():
    """Test shadow mode execution."""
    print("\n=== Testing Shadow Mode ===")
    
    # Get migration config
    migration_conf = config_manager.get("gateway.bifrost_migration", {})
    enabled = migration_conf.get("enabled", False)
    traffic_percentage = migration_conf.get("traffic_percentage", 0)
    
    print(f"Shadow Mode Enabled: {enabled}")
    print(f"Traffic Percentage: {traffic_percentage}%")
    
    if enabled:
        print("✓ Shadow mode is active - 10% of requests will be duplicated to Bifrost")
        print("  Responses will be compared for quality assurance")
    else:
        print("✗ Shadow mode is disabled")
    
    return enabled

async def test_chat_completion():
    """Test a simple chat completion through the gateway."""
    print("\n=== Testing Chat Completion ===")
    
    gateway = GatewayFactory.create_gateway()
    
    messages = [
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": "Hello, what is 2+2?"}
    ]
    
    try:
        result = await gateway.chat_completion(messages, model="gpt-3.5-turbo", timeout=10)
        
        if result.get("success"):
            content = result["data"]["choices"][0]["message"]["content"]
            print(f"✓ Chat completion successful")
            print(f"  Response: {content[:100]}...")
            print(f"  Model used: {result['data'].get('model', 'unknown')}")
        else:
            print(f"✗ Chat completion failed: {result.get('error', 'Unknown error')}")
            
        return result.get("success", False)
    except Exception as e:
        print(f"✗ Exception during chat completion: {e}")
        return False

async def test_model_listing():
    """Test model listing from gateway."""
    print("\n=== Testing Model Listing ===")
    
    gateway = GatewayFactory.create_gateway()
    
    try:
        models = await gateway.list_models()
        print(f"✓ Retrieved {len(models)} models")
        if models:
            print(f"  Sample models: {models[:5]}")
        return True
    except Exception as e:
        print(f"✗ Failed to list models: {e}")
        return False

async def main():
    """Run all tests."""
    print("HestiaOS Gateway Canary Routing Test")
    print("=" * 50)
    
    # Reload config to ensure latest changes
    config_manager.reload()
    
    # Run tests
    health_ok = await test_gateway_health()
    shadow_enabled = await test_shadow_mode()
    chat_ok = await test_chat_completion()
    models_ok = await test_model_listing()
    
    # Summary
    print("\n" + "=" * 50)
    print("TEST SUMMARY:")
    print(f"  Gateway Health: {'✓ PASS' if health_ok else '✗ FAIL'}")
    print(f"  Shadow Mode: {'✓ ENABLED' if shadow_enabled else '✗ DISABLED'}")
    print(f"  Chat Completion: {'✓ PASS' if chat_ok else '✗ FAIL'}")
    print(f"  Model Listing: {'✓ PASS' if models_ok else '✗ FAIL'}")
    
    # Check Bifrost status
    print("\nBifrost Status Check:")
    try:
        import requests
        bifrost_health = requests.get("http://localhost:4002/health", timeout=5)
        if bifrost_health.status_code == 200:
            print(f"  ✓ Bifrost is running on port 4002")
        else:
            print(f"  ✗ Bifrost health check failed: {bifrost_health.status_code}")
    except Exception as e:
        print(f"  ✗ Bifrost not reachable: {e}")
    
    # Check LiteLLM status
    print("\nLiteLLM Status Check:")
    try:
        import requests
        litellm_health = requests.get("http://localhost:4001/health", timeout=5)
        if litellm_health.status_code == 200:
            print(f"  ✓ LiteLLM is running on port 4001")
        else:
            print(f"  ✗ LiteLLM health check failed: {litellm_health.status_code}")
    except Exception as e:
        print(f"  ✗ LiteLLM not reachable: {e}")
    
    print("\nCanary Routing Status: ACTIVE")
    print("Traffic is being routed with:")
    print("  - Primary: LiteLLM (port 4001)")
    print("  - Fallback: Bifrost (port 4002)")
    print("  - Shadow Mode: 10% of requests duplicated to Bifrost")
    print("  - Automatic failover on primary failure")

if __name__ == "__main__":
    asyncio.run(main())