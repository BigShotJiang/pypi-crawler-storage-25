"""
Unit tests for the RALPH Test-Orchestrator.

Tests cover:
- Test analysis and dependency detection
- Parallel test execution
- Failure analysis and flake detection
- Test improvement suggestions
"""

import pytest
import sys
import os
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock

# Add project root to path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

# Import the module to test
from mcp_servers.ralph_test_orchestrator import (
    analyze_tests,
    execute_tests_parallel,
    analyze_test_failures,
    improve_tests,
    _parse_affected_modules,
    _find_related_tests,
    _build_dependency_graph,
    _group_for_parallel_execution,
    _detect_flake,
    _identify_root_cause,
    _suggest_fix
)

class TestRALPHTestOrchestrator:
    """Test suite for RALPH Test-Orchestrator functions."""
    
    def test_parse_affected_modules(self):
        """Test parsing affected modules from code changes."""
        # Test with git diff format
        diff = """diff --git a/core/agent.py b/core/agent.py
index abc123..def456 100644
--- a/core/agent.py
+++ b/core/agent.py
@@ -1,5 +1,5 @@
 class Agent:
-    def old_method(self):
+    def new_method(self):
         pass
"""
        modules = _parse_affected_modules(diff)
        assert "core.agent" in modules
        
        # Test with modified line format
        changes = "modified: core/agent.py\nmodified: tests/test_agent.py"
        modules = _parse_affected_modules(changes)
        assert "core.agent" in modules
        assert "tests.test_agent" in modules
        
        # Test with test files
        changes = "test_agent.py test_communication.py"
        modules = _parse_affected_modules(changes)
        assert "test_agent" in modules
        assert "test_communication" in modules
    
    @patch('pathlib.Path.exists')
    @patch('pathlib.Path.rglob')
    def test_find_related_tests(self, mock_rglob, mock_exists):
        """Test finding related tests for affected modules."""
        mock_exists.return_value = True
        mock_rglob.return_value = [
            Path("tests/test_agent.py"),
            Path("tests/test_communication.py"),
            Path("tests/test_orchestrator.py")
        ]
        
        affected_modules = ["core.agent", "core.communication"]
        test_files = _find_related_tests(affected_modules)
        
        # Should find test files containing module names
        assert any("test_agent" in str(f) for f in test_files)
        assert any("test_communication" in str(f) for f in test_files)
    
    def test_build_dependency_graph(self):
        """Test building dependency graph between tests."""
        test_files = [
            "tests/test_agent.py",
            "tests/test_communication.py",
            "tests/test_orchestrator.py",
            "integration/test_integration.py"
        ]
        
        graph = _build_dependency_graph(test_files)
        
        # Tests in same directory should have dependencies
        assert "tests/test_agent.py" in graph
        assert "tests/test_communication.py" in graph["tests/test_agent.py"]
        
        # Tests in different directories should not have dependencies
        assert "integration/test_integration.py" not in graph["tests/test_agent.py"]
    
    def test_group_for_parallel_execution(self):
        """Test grouping tests for parallel execution."""
        dependency_graph = {
            "test1.py": ["test2.py"],
            "test2.py": ["test1.py"],
            "test3.py": [],
            "test4.py": []
        }
        
        groups = _group_for_parallel_execution(dependency_graph)
        
        # test1 and test2 should be in different groups (they depend on each other)
        # test3 and test4 can be in same group (no dependencies)
        assert len(groups) >= 2
        
        # Verify no test appears in multiple groups
        all_tests = [test for group in groups for test in group]
        assert len(all_tests) == len(set(all_tests))
    
    def test_detect_flake(self):
        """Test flake detection in test output."""
        # Flake indicators
        flake_outputs = [
            "Connection refused",
            "Timeout exceeded",
            "temporarily unavailable",
            "race condition detected",
            "intermittent failure",
            "random test failure",
            "This is a flake",
            "network error occurred"
        ]
        
        for output in flake_outputs:
            assert _detect_flake(output) is True
        
        # Non-flake failures
        non_flake_outputs = [
            "AssertionError: expected 2 but got 3",
            "ImportError: No module named 'missing'",
            "ValueError: Invalid input",
            "TypeError: unsupported operand type"
        ]
        
        for output in non_flake_outputs:
            assert _detect_flake(output) is False
    
    def test_identify_root_cause(self):
        """Test identifying root cause of test failures."""
        test_cases = [
            ("AssertionError: expected True but got False", "Assertion failure"),
            ("ImportError: No module named 'missing'", "Import error"),
            ("Fixture 'missing_fixture' not found", "Missing fixture"),
            ("Timeout: Test took longer than 30 seconds", "Timeout"),
            ("PermissionError: [Errno 13] Permission denied", "Permission error"),
            ("MemoryError: Out of memory", "Memory issue"),
            ("Race condition detected", "Race condition"),
            ("Some unknown error", "Unknown error")
        ]
        
        for output, expected_cause in test_cases:
            assert _identify_root_cause(output) == expected_cause
    
    def test_suggest_fix(self):
        """Test suggesting fixes based on root cause."""
        test_cases = [
            ("Assertion failure", "Check test expectations and actual values"),
            ("Import error", "Verify imports and module structure"),
            ("Missing fixture", "Create missing fixture or update test setup"),
            ("Timeout", "Increase timeout or optimize test performance"),
            ("Permission error", "Check file permissions and access rights"),
            ("Memory issue", "Optimize memory usage or add cleanup"),
            ("Race condition", "Add synchronization or make test deterministic"),
            ("Unknown error", "Review test output for specific error details"),
            ("Non-existent cause", "Review test implementation")
        ]
        
        for root_cause, expected_suggestion in test_cases:
            suggestion = _suggest_fix(root_cause, "test output")
            assert expected_suggestion in suggestion
    
    @patch('mcp_servers.ralph_test_orchestrator._parse_affected_modules')
    @patch('mcp_servers.ralph_test_orchestrator._find_related_tests')
    @patch('mcp_servers.ralph_test_orchestrator._build_dependency_graph')
    @patch('mcp_servers.ralph_test_orchestrator._group_for_parallel_execution')
    def test_analyze_tests(self, mock_group, mock_graph, mock_find, mock_parse):
        """Test the main analyze_tests function."""
        # Mock the helper functions
        mock_parse.return_value = ["core.agent", "core.communication"]
        mock_find.return_value = ["tests/test_agent.py", "tests/test_communication.py"]
        mock_graph.return_value = {
            "tests/test_agent.py": ["tests/test_communication.py"],
            "tests/test_communication.py": ["tests/test_agent.py"]
        }
        mock_group.return_value = [
            ["tests/test_agent.py"],
            ["tests/test_communication.py"]
        ]
        
        code_changes = "modified: core/agent.py"
        result = analyze_tests(code_changes)
        
        assert "affected_modules" in result
        assert "test_files" in result
        assert "dependency_graph" in result
        assert "parallel_groups" in result
        assert "total_tests" in result
        assert result["total_tests"] == 2
    
    @patch('concurrent.futures.ThreadPoolExecutor')
    @patch('mcp_servers.ralph_test_orchestrator._run_single_test')
    def test_execute_tests_parallel(self, mock_run, mock_executor):
        """Test parallel test execution."""
        # Mock test execution
        mock_run.return_value = {
            "test_file": "tests/test_agent.py",
            "status": "PASSED",
            "duration": 1.5,
            "output": "Test passed",
            "returncode": 0
        }
        
        # Mock executor
        mock_future = Mock()
        mock_future.result.return_value = mock_run.return_value
        mock_executor.return_value.__enter__.return_value.submit.return_value = mock_future
        mock_executor.return_value.__enter__.return_value.__exit__ = Mock()
        
        test_plan = {
            "test_files": ["tests/test_agent.py", "tests/test_communication.py"],
            "parallel_groups": [["tests/test_agent.py"], ["tests/test_communication.py"]]
        }
        
        result = execute_tests_parallel(test_plan)
        
        assert "results" in result
        assert "summary" in result
        assert result["summary"]["total"] == 2
        assert result["summary"]["passed"] == 2
    
    def test_analyze_test_failures(self):
        """Test failure analysis."""
        test_results = {
            "results": [
                {
                    "test_file": "tests/test_agent.py",
                    "status": "FAILED",
                    "output": "AssertionError: expected True but got False"
                },
                {
                    "test_file": "tests/test_communication.py",
                    "status": "FAILED",
                    "output": "Connection refused"
                },
                {
                    "test_file": "tests/test_orchestrator.py",
                    "status": "PASSED",
                    "output": "Test passed"
                }
            ]
        }
        
        result = analyze_test_failures(test_results)
        
        assert "analysis" in result
        assert "summary" in result
        assert result["summary"]["total_failures"] == 2
        
        # Check analysis details
        analysis = result["analysis"]
        assert len(analysis) == 2
        
        # First failure should be real bug (assertion failure)
        assert analysis[0]["is_flake"] is False
        assert analysis[0]["root_cause"] == "Assertion failure"
        
        # Second failure should be flake (connection issue)
        assert analysis[1]["is_flake"] is True
        assert analysis[1]["retry_recommended"] is True
    
    def test_improve_tests(self):
        """Test test improvement suggestions."""
        failures = [
            {
                "test_file": "tests/test_agent.py",
                "root_cause": "Missing fixture",
                "is_flake": False
            },
            {
                "test_file": "tests/test_communication.py",
                "root_cause": "Timeout",
                "is_flake": False
            },
            {
                "test_file": "tests/test_flaky.py",
                "root_cause": "Race condition",
                "is_flake": True
            }
        ]
        
        result = improve_tests(failures)
        
        assert "improvements" in result
        assert "summary" in result
        assert result["summary"]["total_improvements"] == 3
        
        # Check improvement actions
        improvements = result["improvements"]
        actions = [i["action"] for i in improvements]
        assert "created_fixture" in actions
        assert "adjusted_timeout" in actions
        assert "added_flake_handling" in actions

class TestIntegration:
    """Integration tests for the complete workflow."""
    
    def test_complete_workflow(self):
        """Test the complete RALPH workflow."""
        # This is a high-level integration test
        code_changes = "modified: core/agent.py\nmodified: tests/test_agent.py"
        
        # Step 1: Analyze tests
        test_plan = analyze_tests(code_changes)
        assert "test_files" in test_plan
        
        # Step 2: Execute tests (mocked)
        with patch('mcp_servers.ralph_test_orchestrator._run_single_test') as mock_run:
            mock_run.return_value = {
                "test_file": "tests/test_agent.py",
                "status": "PASSED",
                "duration": 1.0,
                "output": "Test passed",
                "returncode": 0
            }
            
            test_results = execute_tests_parallel(test_plan)
            assert "results" in test_results
        
        # Step 3: Analyze failures (with simulated failures)
        test_results_with_failures = {
            "results": [
                {
                    "test_file": "tests/test_agent.py",
                    "status": "FAILED",
                    "output": "AssertionError"
                }
            ]
        }
        
        failure_analysis = analyze_test_failures(test_results_with_failures)
        assert "analysis" in failure_analysis
        
        # Step 4: Improve tests
        if failure_analysis.get("analysis"):
            improvements = improve_tests(failure_analysis["analysis"])
            assert "improvements" in improvements

class TestPerformance:
    """Performance-related tests."""
    
    def test_parallelization_efficiency(self):
        """Test that parallelization groups are created efficiently."""
        # Create a large dependency graph
        test_files = [f"tests/test_{i}.py" for i in range(10)]
        dependency_graph = {}
        
        # Create some dependencies (every other test depends on the next)
        for i, test_file in enumerate(test_files):
            dependencies = []
            if i % 2 == 0 and i + 1 < len(test_files):
                dependencies.append(test_files[i + 1])
            dependency_graph[test_file] = dependencies
        
        groups = _group_for_parallel_execution(dependency_graph)
        
        # Should have multiple groups for parallel execution
        assert len(groups) > 1
        
        # No test should be in multiple groups
        all_tests = [test for group in groups for test in group]
        assert len(all_tests) == len(set(all_tests))
        assert len(all_tests) == len(test_files)

if __name__ == "__main__":
    pytest.main([__file__, "-v"])