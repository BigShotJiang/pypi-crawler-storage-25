"""
P0.1 — API Contract Freeze: v1 Endpoint Contract Tests.

Testet die drei neuen v1-Endpoints via ASGITransport (kein TestClient,
da starlette 0.27.0 + httpx 0.28.1 einen Version-Mismatch haben).

Anti-Leak Contract:
- Keine internen Typen in Responses: DSGKDecision, CommandTrace, ArbitrationResult,
  DriftVector, SystemMode (als Enum), DecisionType (als Enum)
- Keine core.governance.* oder core.bootstrap.* Pfade in Responses
- RunResponse: result ist "ALLOW" | "THROTTLE" | "BLOCK" (String, nicht DecisionType)
- RunResponse: KEIN reason-Feld (Review-Fix R3)
- TraceResponse: flat dict mit reason, risk_score, policy, violations

P0.3 — Internal Adapter Layer:
- trace_id kommt aus dem Kernel (nicht aus HTTP/uuid)
- ALLOW_WITH_WARNINGS → ALLOW (nicht THROTTLE)
- Kein blanket except Exception — nur DSGKError
"""

from __future__ import annotations

import json
import re
import time
from pathlib import Path
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
from core.governance.command_processor import DSGKError
import pytest
from httpx import ASGITransport

# ── Projekt-Root ────────────────────────────────────────────────
ROOT = Path(__file__).parent.parent


# ── Hilfsfunktionen ─────────────────────────────────────────────


def _assert_no_internal_types(
    response_data: dict | list | str | int | float | bool | None,
    path: str = "",
) -> None:
    """Rekursive Prüfung: Keine internen Typen in der Response.

    Forbidden Patterns (Anti-Leak Contract):
    - DSGKDecision, CommandTrace, ArbitrationResult, DriftVector
    - <SystemMode., <DecisionType. (Enum-Repräsentationen)
    - core.governance., core.bootstrap. (Python-Pfade)
    """
    forbidden_patterns = [
        r"DSGKDecision",
        r"CommandTrace",
        r"ArbitrationResult",
        r"DriftVector",
        r"<SystemMode\.",
        r"<DecisionType\.",
        r"core\.governance\.",
        r"core\.bootstrap\.",
    ]

    if isinstance(response_data, dict):
        for key, value in response_data.items():
            new_path = f"{path}.{key}" if path else key
            _assert_no_internal_types(value, new_path)
    elif isinstance(response_data, list):
        for i, item in enumerate(response_data):
            _assert_no_internal_types(item, f"{path}[{i}]")
    elif isinstance(response_data, str):
        for pattern in forbidden_patterns:
            if re.search(pattern, response_data):
                raise AssertionError(
                    f"ANTI-LEAK-VERLETZUNG: Pfad '{path}' enthält "
                    f"verbotenes Pattern '{pattern}': {response_data!r}"
                )


def _assert_run_response_shape(data: dict) -> None:
    """Prüft die RunResponse-Struktur (Anti-Leak Contract)."""
    # Pflichtfelder
    assert "result" in data, "RunResponse muss 'result' enthalten"
    assert data["result"] in ("ALLOW", "THROTTLE", "BLOCK"), (
        f"result muss 'ALLOW'|'THROTTLE'|'BLOCK' sein, ist {data['result']!r}"
    )
    assert "trace_id" in data, "RunResponse muss 'trace_id' enthalten"
    assert isinstance(data["trace_id"], str), "trace_id muss str sein"
    assert "latency_ms" in data, "RunResponse muss 'latency_ms' enthalten"
    assert isinstance(data["latency_ms"], (int, float)), "latency_ms muss Zahl sein"

    # Review-Fix R3: KEIN reason-Feld
    assert "reason" not in data, (
        "Review-Fix R3: RunResponse darf KEIN 'reason'-Feld enthalten"
    )

    # Anti-Leak: Keine internen Typen
    _assert_no_internal_types(data)


def _assert_trace_response_shape(data: dict) -> None:
    """Prüft die TraceResponse-Struktur (Anti-Leak Contract)."""
    # Pflichtfelder
    assert "trace_id" in data, "TraceResponse muss 'trace_id' enthalten"
    assert isinstance(data["trace_id"], str)
    assert "decision" in data, "TraceResponse muss 'decision' enthalten"
    assert data["decision"] in ("ALLOW", "THROTTLE", "BLOCK")
    assert "reason" in data, "TraceResponse muss 'reason' enthalten"
    assert isinstance(data["reason"], str)
    assert "risk_score" in data, "TraceResponse muss 'risk_score' enthalten"
    assert isinstance(data["risk_score"], (int, float))
    assert "policy" in data, "TraceResponse muss 'policy' enthalten"
    assert isinstance(data["policy"], str)
    assert "violations" in data, "TraceResponse muss 'violations' enthalten"
    assert isinstance(data["violations"], list)
    assert "latency_ms" in data, "TraceResponse muss 'latency_ms' enthalten"
    assert isinstance(data["latency_ms"], (int, float))

    # violations sind flache dicts, keine Violation-Objekte
    for v in data["violations"]:
        assert isinstance(v, dict), "Jede violation muss ein dict sein"
        assert "reason" in v, "violation muss 'reason' haben"
        assert "severity" in v, "violation muss 'severity' haben"

    # Anti-Leak: Keine internen Typen
    _assert_no_internal_types(data)


# ── Fixtures ────────────────────────────────────────────────────


@pytest.fixture
def app():
    """Erzeugt die FastAPI-App (ohne Agent-Start)."""
    from api.factory import create_app
    return create_app(start_agents=False)


@pytest.fixture
async def async_client(app):
    """AsyncClient via ASGITransport (kein TestClient)."""
    transport = ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        yield client


# ═════════════════════════════════════════════════════════════════
# TestV1Health
# ═════════════════════════════════════════════════════════════════


class TestV1Health:
    """GET /api/v1/health — Health-Check Endpoint."""

    @pytest.mark.asyncio
    async def test_health_returns_ok(self, async_client: httpx.AsyncClient) -> None:
        """Health-Endpoint gibt 200 + status=OK zurück."""
        resp = await async_client.get("/api/v1/health")
        assert resp.status_code == 200, f"Erwartet 200, erhalten {resp.status_code}"
        data = resp.json()
        assert data["status"] == "OK", f"status sollte 'OK' sein, ist {data['status']!r}"

    @pytest.mark.asyncio
    async def test_health_no_internal_leaks(self, async_client: httpx.AsyncClient) -> None:
        """Health-Response enthält keine internen Typen."""
        resp = await async_client.get("/api/v1/health")
        data = resp.json()
        _assert_no_internal_types(data)

    @pytest.mark.asyncio
    async def test_health_uptime_increases(self, async_client: httpx.AsyncClient) -> None:
        """uptime_seconds sollte zwischen zwei Aufrufen steigen."""
        resp1 = await async_client.get("/api/v1/health")
        data1 = resp1.json()
        time.sleep(0.01)
        resp2 = await async_client.get("/api/v1/health")
        data2 = resp2.json()
        assert data2["uptime_seconds"] >= data1["uptime_seconds"], (
            "uptime_seconds sollte nicht fallen"
        )


# ═════════════════════════════════════════════════════════════════
# TestV1Run
# ═════════════════════════════════════════════════════════════════


# Der Mock-Pfad muss auf das Modul zeigen, in dem process_command AUFGERUFEN wird.
# v1_adapter.py importiert process_command auf Modulebene (from ... import).
# Daher muss der Patch auf api.adapters.v1_adapter.process_command gehen,
# nicht auf core.governance.command_processor.process_command.
MOCK_PROCESS_COMMAND = "api.adapters.v1_adapter.process_command"

# Mock-Pfad für CommandTraceStore (lazy import in v1_adapter.py → get_trace())
MOCK_TRACE_STORE_GET = "api.adapters.v1_adapter.CommandTraceStore.get"


def _make_mock_trace(
    trace_id: str = "trace_001",
    dsgk_decision: str = "ALLOW",
    reason: str = "OK",
    risk_score: float = 0.0,
    policy: str = "default",
    violations: list | None = None,
    output: str | None = None,
    budget: float = 1.0,
    mode: str | None = None,
    timestamp: str = "",
    latency_ms: float = 0.0,
) -> MagicMock:
    """Erzeugt einen standardisierten Mock-CommandTrace.

    P0.3: trace_id wird explizit gesetzt (kommt aus dem Kernel).
    mode=None wird akzeptiert (Adapter mapped zu "normal").
    """
    mock_trace = MagicMock()
    mock_trace.trace_id = trace_id
    mock_trace.dsgk_decision = dsgk_decision
    mock_trace.reason = reason
    mock_trace.risk_score = risk_score
    mock_trace.policy = policy
    mock_trace.violations = violations or []
    mock_trace.output = output
    mock_trace.budget = budget
    mock_trace.mode = mode
    mock_trace.timestamp = timestamp
    mock_trace.latency_ms = latency_ms
    return mock_trace


class TestV1Run:
    """POST /api/v1/run — Governance-geguardete Execution."""

    @pytest.mark.asyncio
    async def test_run_allow_returns_200(self, async_client: httpx.AsyncClient) -> None:
        """ALLOW-Entscheidung → 200 OK."""
        with patch(MOCK_PROCESS_COMMAND) as mock_process:
            mock_process.return_value = _make_mock_trace(
                trace_id="trace_allow_001",
                dsgk_decision="ALLOW",
                reason="OK",
                risk_score=0.1,
            )

            resp = await async_client.post(
                "/api/v1/run",
                json={"command": "test", "input": "hello"},
            )
            assert resp.status_code == 200, f"Erwartet 200, erhalten {resp.status_code}"
            data = resp.json()
            assert data["result"] == "ALLOW"

    @pytest.mark.asyncio
    async def test_run_throttle_returns_200(self, async_client: httpx.AsyncClient) -> None:
        """ALLOW_WITH_WARNINGS → ALLOW (Throttle wird über mode+budget gesteuert)."""
        with patch(MOCK_PROCESS_COMMAND) as mock_process:
            mock_process.return_value = _make_mock_trace(
                trace_id="trace_throttle_001",
                dsgk_decision="ALLOW_WITH_WARNINGS",
                reason="Rate limit approach",
                risk_score=0.5,
                policy="rate_limiter",
            )

            resp = await async_client.post(
                "/api/v1/run",
                json={"command": "test", "input": "hello"},
            )
            assert resp.status_code == 200, f"Erwartet 200, erhalten {resp.status_code}"
            data = resp.json()
            # P0.3: ALLOW_WITH_WARNINGS → ALLOW (nicht THROTTLE)
            assert data["result"] == "ALLOW"

    @pytest.mark.asyncio
    async def test_run_block_returns_403(self, async_client: httpx.AsyncClient) -> None:
        """BLOCK-Entscheidung → 403 Forbidden."""
        with patch(MOCK_PROCESS_COMMAND) as mock_process:
            mock_process.return_value = _make_mock_trace(
                trace_id="trace_block_001",
                dsgk_decision="BLOCK",
                reason="Policy violation",
                risk_score=0.9,
                policy="security_policy",
                violations=[{"reason": "高危操作", "severity": "CRITICAL"}],
            )

            resp = await async_client.post(
                "/api/v1/run",
                json={"command": "test", "input": "malicious"},
            )
            assert resp.status_code == 403, f"Erwartet 403, erhalten {resp.status_code}"
            data = resp.json()
            assert "detail" in data

    @pytest.mark.asyncio
    async def test_run_no_internal_leaks_on_allow(
        self, async_client: httpx.AsyncClient
    ) -> None:
        """ALLOW-Response enthält keine internen Typen."""
        with patch(MOCK_PROCESS_COMMAND) as mock_process:
            mock_process.return_value = _make_mock_trace(
                trace_id="trace_clean_001",
                dsgk_decision="ALLOW",
            )

            resp = await async_client.post(
                "/api/v1/run",
                json={"command": "test", "input": "clean"},
            )
            data = resp.json()
            _assert_no_internal_types(data)

    @pytest.mark.asyncio
    async def test_run_no_internal_leaks_on_block(
        self, async_client: httpx.AsyncClient
    ) -> None:
        """BLOCK-Response (403) enthält keine internen Typen."""
        with patch(MOCK_PROCESS_COMMAND) as mock_process:
            mock_process.return_value = _make_mock_trace(
                trace_id="trace_block_002",
                dsgk_decision="BLOCK",
                reason="Blocked",
                risk_score=0.9,
                policy="block_policy",
                violations=[{"reason": "test", "severity": "HIGH"}],
            )

            resp = await async_client.post(
                "/api/v1/run",
                json={"command": "test", "input": "bad"},
            )
            data = resp.json()
            _assert_no_internal_types(data)

    @pytest.mark.asyncio
    async def test_run_no_reason_field(self, async_client: httpx.AsyncClient) -> None:
        """Review-Fix R3: RunResponse hat KEIN reason-Feld."""
        with patch(MOCK_PROCESS_COMMAND) as mock_process:
            mock_process.return_value = _make_mock_trace(
                trace_id="trace_nr_001",
                dsgk_decision="ALLOW",
                reason="OK",
            )

            resp = await async_client.post(
                "/api/v1/run",
                json={"command": "test", "input": "x"},
            )
            data = resp.json()
            assert "reason" not in data, (
                "Review-Fix R3: RunResponse darf KEIN 'reason'-Feld enthalten"
            )

    @pytest.mark.asyncio
    async def test_run_invalid_input_returns_422(
        self, async_client: httpx.AsyncClient
    ) -> None:
        """Ungültiger Input-Typ → 422 Unprocessable Entity."""
        resp = await async_client.post(
            "/api/v1/run",
            json={"input": 123},  # input muss str sein, nicht int
        )
        assert resp.status_code == 422, f"Erwartet 422, erhalten {resp.status_code}"

    @pytest.mark.asyncio
    async def test_run_missing_input_returns_422(
        self, async_client: httpx.AsyncClient
    ) -> None:
        """Fehlendes input-Feld → 422."""
        resp = await async_client.post(
            "/api/v1/run",
            json={"command": "test"},  # input fehlt
        )
        assert resp.status_code == 422, f"Erwartet 422, erhalten {resp.status_code}"

    @pytest.mark.asyncio
    async def test_run_returns_trace_id(self, async_client: httpx.AsyncClient) -> None:
        """RunResponse enthält trace_id (vom Kernel)."""
        with patch(MOCK_PROCESS_COMMAND) as mock_process:
            mock_process.return_value = _make_mock_trace(
                trace_id="trace_tid_001",
                dsgk_decision="ALLOW",
            )

            resp = await async_client.post(
                "/api/v1/run",
                json={"command": "test", "input": "x"},
            )
            data = resp.json()
            assert isinstance(data["trace_id"], str), "trace_id muss ein String sein"
            assert len(data["trace_id"]) > 0, "trace_id darf nicht leer sein"

    @pytest.mark.asyncio
    async def test_run_returns_latency(self, async_client: httpx.AsyncClient) -> None:
        """RunResponse enthält latency_ms > 0."""
        with patch(MOCK_PROCESS_COMMAND) as mock_process:
            mock_process.return_value = _make_mock_trace(
                trace_id="trace_lat_001",
                dsgk_decision="ALLOW",
            )

            resp = await async_client.post(
                "/api/v1/run",
                json={"command": "test", "input": "x"},
            )
            data = resp.json()
            assert data["latency_ms"] >= 0, "latency_ms sollte >= 0 sein"

    @pytest.mark.asyncio
    async def test_run_internal_error_returns_500(
        self, async_client: httpx.AsyncClient
    ) -> None:
        """Interner Fehler in process_command → 500."""
        with patch(MOCK_PROCESS_COMMAND) as mock_process:
            mock_process.side_effect = DSGKError("Unerwarteter Fehler")

            resp = await async_client.post(
                "/api/v1/run",
                json={"command": "test", "input": "x"},
            )
            assert resp.status_code == 500, f"Erwartet 500, erhalten {resp.status_code}"


# ═════════════════════════════════════════════════════════════════
# TestV1Trace
# ═════════════════════════════════════════════════════════════════


class TestV1Trace:
    """GET /api/v1/trace/{trace_id} — Trace abrufen."""

    @pytest.mark.asyncio
    async def test_trace_not_found_returns_404(
        self, async_client: httpx.AsyncClient
    ) -> None:
        """Nicht-existierende trace_id → 404."""
        resp = await async_client.get("/api/v1/trace/nonexistent_123")
        assert resp.status_code == 404, f"Erwartet 404, erhalten {resp.status_code}"

    @pytest.mark.asyncio
    async def test_trace_no_internal_leaks_on_404(
        self, async_client: httpx.AsyncClient
    ) -> None:
        """404-Response enthält keine internen Typen."""
        resp = await async_client.get("/api/v1/trace/nonexistent_456")
        data = resp.json()
        _assert_no_internal_types(data)

    @pytest.mark.asyncio
    async def test_trace_found_returns_200(
        self, async_client: httpx.AsyncClient
    ) -> None:
        """Vorhandener Trace → 200 + korrekte Struktur."""
        trace_id = "trace_found_001"
        mock_trace = _make_mock_trace(
            trace_id=trace_id,
            dsgk_decision="ALLOW",
            reason="OK",
            timestamp="2026-01-01T00:00:00",
            latency_ms=42.0,
        )

        with patch(MOCK_TRACE_STORE_GET, return_value=mock_trace):
            resp = await async_client.get(f"/api/v1/trace/{trace_id}")
            assert resp.status_code == 200, f"Erwartet 200, erhalten {resp.status_code}"
            data = resp.json()
            _assert_trace_response_shape(data)
            assert data["trace_id"] == trace_id

    @pytest.mark.asyncio
    async def test_trace_no_internal_leaks_on_found(
        self, async_client: httpx.AsyncClient
    ) -> None:
        """Trace-Response enthält keine internen Typen."""
        trace_id = "trace_clean_002"
        mock_trace = _make_mock_trace(
            trace_id=trace_id,
            dsgk_decision="ALLOW",
            reason="OK",
            timestamp="2026-01-01T00:00:00",
            latency_ms=42.0,
        )

        with patch(MOCK_TRACE_STORE_GET, return_value=mock_trace):
            resp = await async_client.get(f"/api/v1/trace/{trace_id}")
            data = resp.json()
            _assert_no_internal_types(data)

    @pytest.mark.asyncio
    async def test_trace_with_violations(
        self, async_client: httpx.AsyncClient
    ) -> None:
        """Trace mit Violations → violations sind flache dicts."""
        trace_id = "trace_viol_001"
        mock_trace = _make_mock_trace(
            trace_id=trace_id,
            dsgk_decision="BLOCK",
            reason="Policy violation",
            risk_score=0.9,
            policy="strict_policy",
            violations=[
                {"reason": "Hohes Risiko", "severity": "CRITICAL"},
                {"reason": "Nicht authorisiert", "severity": "HIGH"},
            ],
            timestamp="2026-01-01T00:00:00",
            latency_ms=42.0,
        )

        with patch(MOCK_TRACE_STORE_GET, return_value=mock_trace):
            resp = await async_client.get(f"/api/v1/trace/{trace_id}")
            data = resp.json()
            assert len(data["violations"]) == 2
            for v in data["violations"]:
                assert isinstance(v, dict)
                assert "reason" in v
                assert "severity" in v
            _assert_no_internal_types(data)


# ═════════════════════════════════════════════════════════════════
# TestAntiLeakContract (Meta-Tests)
# ═════════════════════════════════════════════════════════════════


class TestAntiLeakContract:
    """Meta-Tests: Der Anti-Leak Checker selbst funktioniert korrekt."""

    def test_forbidden_pattern_detection(self) -> None:
        """Der Checker erkennt verbotene Patterns."""
        with pytest.raises(AssertionError, match="ANTI-LEAK-VERLETZUNG"):
            _assert_no_internal_types(
                {"decision": "<DecisionType.ALLOW: 'ALLOW'>"}
            )

        with pytest.raises(AssertionError, match="ANTI-LEAK-VERLETZUNG"):
            _assert_no_internal_types(
                {"trace": "core.governance.command_trace.CommandTrace"}
            )

    def test_clean_data_passes(self) -> None:
        """Saubere Daten lösen keine Anti-Leak-Warnung aus."""
        clean = {
            "decision": "ALLOW",
            "trace_id": "abc123",
            "latency_ms": 42.0,
            "reason": "OK",
            "risk_score": 0.0,
            "policy": "default",
            "violations": [
                {"reason": "test", "severity": "LOW"}
            ],
        }
        # Sollte keine Exception werfen
        _assert_no_internal_types(clean)
        _assert_trace_response_shape(clean)
