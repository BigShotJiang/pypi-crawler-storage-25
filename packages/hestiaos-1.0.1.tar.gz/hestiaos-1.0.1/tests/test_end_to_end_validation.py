#!/usr/bin/env python3
"""
End-to-end validation test for HestiaOS with vLLM backend.
Tests the complete flow from API request to LLM response.
"""
import asyncio
import aiohttp
import json
import sys
from typing import Dict, Any

async def test_vllm_direct() -> bool:
    """Test direct connection to vLLM server."""
    try:
        async with aiohttp.ClientSession() as session:
            # Test models endpoint
            async with session.get("http://127.0.0.1:8001/v1/models", timeout=5) as response:
                if response.status == 200:
                    data = await response.json()
                    print(f"✅ vLLM server responding with models: {data.get('data', [])}")
                    return True
                else:
                    print(f"❌ vLLM server returned status {response.status}")
                    return False
    except Exception as e:
        print(f"❌ vLLM server not reachable: {e}")
        return False

async def test_api_chat_endpoint() -> bool:
    """Test the HestiaOS API chat endpoint."""
    try:
        async with aiohttp.ClientSession() as session:
            payload = {
                "message": "Hello, can you tell me what time it is?",
                "session_id": "test_session",
                "mode": "business"
            }
            
            async with session.post(
                "http://127.0.0.1:8000/chat",
                json=payload,
                timeout=30
            ) as response:
                if response.status == 200:
                    data = await response.json()
                    print(f"✅ API endpoint responding with status 200")
                    
                    # Check response structure
                    if "response" in data:
                        response_text = data["response"]
                        print(f"   Response: {response_text[:100]}...")
                        
                        # Check for routing messages (should not be repeated)
                        if "[Routing to" in response_text:
                            routing_count = response_text.count("[Routing to")
                            if routing_count > 1:
                                print(f"⚠️  Warning: Found {routing_count} routing messages (should be 1)")
                            else:
                                print(f"✅ Single routing message detected")
                        
                        # Check for actual LLM content
                        if len(response_text.strip()) > 50 and not response_text.startswith("[Routing to"):
                            print(f"✅ Contains substantial LLM-generated content")
                            return True
                        else:
                            print(f"⚠️  Response may be incomplete or only routing info")
                            return False
                    else:
                        print(f"❌ No 'response' field in API response")
                        return False
                else:
                    print(f"❌ API endpoint returned status {response.status}")
                    return False
    except Exception as e:
        print(f"❌ API endpoint test failed: {e}")
        return False

async def test_streaming_endpoint() -> bool:
    """Test the streaming endpoint."""
    try:
        async with aiohttp.ClientSession() as session:
            payload = {
                "message": "What is 2+2?",
                "session_id": "test_stream",
                "mode": "business"
            }
            
            async with session.post(
                "http://127.0.0.1:8000/chat/stream",
                json=payload,
                timeout=30
            ) as response:
                if response.status == 200:
                    print(f"✅ Streaming endpoint responding with status 200")
                    
                    # Read streaming response
                    chunks = []
                    async for line in response.content:
                        if line:
                            line = line.decode('utf-8').strip()
                            if line.startswith('data: '):
                                chunk = line[6:]
                                if chunk:
                                    chunks.append(chunk)
                    
                    if chunks:
                        print(f"✅ Received {len(chunks)} streaming chunks")
                        # Check for duplicate routing messages
                        routing_chunks = [c for c in chunks if "[Routing to" in c]
                        if len(routing_chunks) > 1:
                            print(f"⚠️  Warning: Found {len(routing_chunks)} routing chunks in stream")
                        return True
                    else:
                        print(f"❌ No streaming chunks received")
                        return False
                else:
                    print(f"❌ Streaming endpoint returned status {response.status}")
                    return False
    except Exception as e:
        print(f"❌ Streaming endpoint test failed: {e}")
        return False

async def test_orchestrator_integration() -> bool:
    """Test orchestrator integration with scheduler."""
    try:
        # Import orchestrator components
        sys.path.insert(0, '.')
        from core.orchestrator import Orchestrator
        from core.scheduler import MultiAgentScheduler
        from core.task_classifier import TaskClassifier
        
        # Create test components
        scheduler = MultiAgentScheduler("config/agents.yaml")
        classifier = TaskClassifier("config/agents.yaml")
        
        # Test scheduler initialization
        await scheduler._ensure_initialized()
        print(f"✅ Scheduler initialized with {len(scheduler.agents)} agents")
        
        # Test task classification
        result = classifier.classify("What is the weather today?")
        print(f"✅ Task classifier working: {result.categories}")
        
        # Test agent selection
        agents = await scheduler.select_agent(
            user_message="What is the weather today?",
            context={"complexity": "low"}
        )
        print(f"✅ Scheduler selected agent: {agents.agent_id if agents else 'None'}")
        
        return True
    except Exception as e:
        print(f"❌ Orchestrator integration test failed: {e}")
        return False

async def main():
    """Run all validation tests."""
    print("=" * 60)
    print("HestiaOS End-to-End Validation Test")
    print("=" * 60)
    
    results = {}
    
    # Wait for vLLM server to be ready
    print("\n1. Testing vLLM server connection...")
    vllm_ready = False
    for i in range(10):  # Try for up to 30 seconds
        vllm_ready = await test_vllm_direct()
        if vllm_ready:
            break
        print(f"   Waiting for vLLM server... ({i+1}/10)")
        await asyncio.sleep(3)
    
    results["vllm_server"] = vllm_ready
    
    if not vllm_ready:
        print("❌ vLLM server not ready after 30 seconds. Please check vllm_server.log")
        print("   You may need to wait longer for model loading.")
        return False
    
    # Test API endpoints
    print("\n2. Testing API chat endpoint...")
    results["api_chat"] = await test_api_chat_endpoint()
    
    print("\n3. Testing streaming endpoint...")
    results["api_stream"] = await test_streaming_endpoint()
    
    print("\n4. Testing orchestrator integration...")
    results["orchestrator"] = await test_orchestrator_integration()
    
    # Summary
    print("\n" + "=" * 60)
    print("VALIDATION RESULTS")
    print("=" * 60)
    
    all_passed = True
    for test_name, passed in results.items():
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"{test_name:20} {status}")
        if not passed:
            all_passed = False
    
    print("\n" + "=" * 60)
    if all_passed:
        print("🎉 ALL TESTS PASSED! HestiaOS is working correctly.")
        return True
    else:
        print("⚠️  Some tests failed. Check the logs above for details.")
        return False

if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)