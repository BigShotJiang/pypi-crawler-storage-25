import unittest
from core.governance.dsgk_core import DSGKReasoner, Fact, HardInvariant
from core.governance.semantic_schemas import EffectType, ExecutionContext

class TestTenantIsolation(unittest.TestCase):
    def setUp(self):
        # Setup Invariants
        self.invariants = [
            # Global invariant: No direct DB access for anyone except 'system'
            HardInvariant(
                id="inv_global_db",
                tier="agent",
                forbidden_effects={EffectType.DB_WRITE},
                tenant_id="system",
                description="Global: Agents cannot write to DB directly."
            ),
            # Tenant A invariant: No HTTP calls
            HardInvariant(
                id="inv_tenant_a_http",
                tier="agent",
                forbidden_effects={EffectType.HTTP_CALL},
                tenant_id="tenant_a",
                description="Tenant A: No external HTTP calls allowed."
            ),
            # Tenant B invariant: No Secrets access
            HardInvariant(
                id="inv_tenant_b_secrets",
                tier="agent",
                forbidden_effects={EffectType.DB_READ}, # Using DB_READ as proxy for secrets
                tenant_id="tenant_b",
                description="Tenant B: No secrets retrieval allowed."
            )
        ]
        
        self.tier_mapping = {
            "agent": [".*agent.*", "user"]
        }
        
        self.reasoner = DSGKReasoner(self.invariants, self.tier_mapping)

    def test_global_invariant_applied_to_all(self):
        # Fact from Tenant A trying to DB_WRITE
        fact_a = Fact(
            actor="user",
            predicate=EffectType.DB_WRITE,
            target="database",
            context=ExecutionContext.API_REQUEST,
            tenant_id="tenant_a"
        )
        
        violations = self.reasoner.evaluate([fact_a])
        self.assertTrue(any(v.rule_id == "inv_global_db" for v in violations))

        # Fact from Tenant B trying to DB_WRITE
        fact_b = Fact(
            actor="user",
            predicate=EffectType.DB_WRITE,
            target="database",
            context=ExecutionContext.API_REQUEST,
            tenant_id="tenant_b"
        )
        
        violations = self.reasoner.evaluate([fact_b])
        self.assertTrue(any(v.rule_id == "inv_global_db" for v in violations))

    def test_tenant_specific_isolation(self):
        # Fact from Tenant A trying to do HTTP_CALL (Forbidden for A)
        fact_a = Fact(
            actor="user",
            predicate=EffectType.HTTP_CALL,
            target="http://api.example.com",
            context=ExecutionContext.API_REQUEST,
            tenant_id="tenant_a"
        )
        
        violations_a = self.reasoner.evaluate([fact_a])
        self.assertTrue(any(v.rule_id == "inv_tenant_a_http" for v in violations_a))

        # Fact from Tenant B trying to do HTTP_CALL (Allowed for B, as it's not in B's invariants)
        fact_b = Fact(
            actor="user",
            predicate=EffectType.HTTP_CALL,
            target="http://api.example.com",
            context=ExecutionContext.API_REQUEST,
            tenant_id="tenant_b"
        )
        
        violations_b = self.reasoner.evaluate([fact_b])
        self.assertFalse(any(v.rule_id == "inv_tenant_a_http" for v in violations_b))
        self.assertEqual(len(violations_b), 0)

    def test_tenant_b_restricted_secrets(self):
        # Fact from Tenant B trying to DB_READ (Forbidden for B)
        fact_b = Fact(
            actor="user",
            predicate=EffectType.DB_READ,
            target="vault/secret",
            context=ExecutionContext.API_REQUEST,
            tenant_id="tenant_b"
        )
        
        violations_b = self.reasoner.evaluate([fact_b])
        self.assertTrue(any(v.rule_id == "inv_tenant_b_secrets" for v in violations_b))

        # Fact from Tenant A trying to DB_READ (Allowed for A)
        fact_a = Fact(
            actor="user",
            predicate=EffectType.DB_READ,
            target="vault/secret",
            context=ExecutionContext.API_REQUEST,
            tenant_id="tenant_a"
        )
        
        violations_a = self.reasoner.evaluate([fact_a])
        self.assertFalse(any(v.rule_id == "inv_tenant_b_secrets" for v in violations_a))

if __name__ == "__main__":
    unittest.main()
