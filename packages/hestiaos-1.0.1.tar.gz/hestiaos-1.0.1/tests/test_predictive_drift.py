"""
Tests für die PredictiveDriftEngine.

Testet:
- DriftPrediction-Erstellung und Serialisierung
- predict() mit Graph-Diffs
- what_if() Simulation
- get_risk_profile() für CompiledTickets
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import pytest
from datetime import datetime, timezone
from typing import Dict, List

from core.ir.models import (
    ExecutionGraphIR, ExecutionNode, ExecutionEdge,
    NodeType, EdgeType, GraphScope,
)
from core.ir.predictive_drift import (
    PredictiveDriftEngine, DriftPrediction, DriftSeverity,
)
from core.ir.delta_analyzer import CompiledTicket, TicketType, RiskLevel


# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def base_graph() -> ExecutionGraphIR:
    """Basis-Graph für Drift-Tests."""
    nodes: Dict[str, ExecutionNode] = {
        "a1": ExecutionNode(
            node_id="a1", node_type=NodeType.ADR,
            label="ADR-017: Runtime Contract Format",
            scope=GraphScope.INTENT,
        ),
        "a2": ExecutionNode(
            node_id="a2", node_type=NodeType.ADR,
            label="ADR-018: Governance Protocol",
            scope=GraphScope.INTENT,
        ),
        "c1": ExecutionNode(
            node_id="c1", node_type=NodeType.CONSTRAINT,
            label="No circular dependencies",
            scope=GraphScope.GOVERNANCE,
        ),
        "cap1": ExecutionNode(
            node_id="cap1", node_type=NodeType.CAPABILITY,
            label="contract_analysis",
            scope=GraphScope.ARCHITECTURE,
        ),
        "comp1": ExecutionNode(
            node_id="comp1", node_type=NodeType.COMPONENT,
            label="RuntimeContractAnalyzer",
            scope=GraphScope.RUNTIME,
        ),
        "i1": ExecutionNode(
            node_id="i1", node_type=NodeType.INTENT,
            label="Runtime Contract Analysis",
            scope=GraphScope.INTENT,
        ),
    }

    edges: List[ExecutionEdge] = [
        ExecutionEdge(source_id="i1", target_id="cap1", edge_type=EdgeType.SATISFIES),
        ExecutionEdge(source_id="i1", target_id="a1", edge_type=EdgeType.REFERENCE),
        ExecutionEdge(source_id="cap1", target_id="comp1", edge_type=EdgeType.IMPLEMENTS),
        ExecutionEdge(source_id="a1", target_id="c1", edge_type=EdgeType.REFERENCE),
    ]

    return ExecutionGraphIR(
        graph_id="base_graph",
        source="pytest",
        timestamp=datetime.now(timezone.utc).isoformat(),
        nodes=nodes,
        edges=edges,
    )


@pytest.fixture
def modified_graph(base_graph: ExecutionGraphIR) -> ExecutionGraphIR:
    """Graph mit einer Änderung (ADR entfernt)."""
    new_nodes = dict(base_graph.nodes)
    # Entferne a1 (ADR-017)
    del new_nodes["a1"]

    new_edges = [
        e for e in base_graph.edges
        if e.source_id != "a1" and e.target_id != "a1"
    ]

    return ExecutionGraphIR(
        graph_id="modified_graph",
        source="pytest",
        timestamp=datetime.now(timezone.utc).isoformat(),
        nodes=new_nodes,
        edges=new_edges,
    )


@pytest.fixture
def graph_with_violation(base_graph: ExecutionGraphIR) -> ExecutionGraphIR:
    """Graph mit einer neuen VIOLATES-Edge."""
    new_edges = list(base_graph.edges)
    new_edges.append(
        ExecutionEdge(
            source_id="comp1", target_id="a1",
            edge_type=EdgeType.VIOLATES,
        )
    )

    return ExecutionGraphIR(
        graph_id="graph_with_violation",
        source="pytest",
        timestamp=datetime.now(timezone.utc).isoformat(),
        nodes=dict(base_graph.nodes),
        edges=new_edges,
    )


# =============================================================================
# DriftPrediction Tests
# =============================================================================


class TestDriftPrediction:
    """Tests für die DriftPrediction-Dataclass."""

    def test_create_prediction(self):
        """Erstelle eine einfache Prediction."""
        pred = DriftPrediction(
            probability=0.75,
            affected_adrs=["ADR-017"],
            affected_constraints=["No circular deps"],
            affected_components=["RuntimeContractAnalyzer"],
            severity=DriftSeverity.HIGH,
            reasoning="Test reasoning",
        )
        assert pred.probability == 0.75
        assert len(pred.affected_adrs) == 1
        assert pred.severity == DriftSeverity.HIGH

    def test_default_values(self):
        """Default-Werte sind korrekt."""
        pred = DriftPrediction()
        assert pred.probability == 0.0
        assert pred.affected_adrs == []
        assert pred.severity == DriftSeverity.LOW
        assert pred.reasoning == ""

    def test_serialization(self):
        """Teste Serialisierung/Deserialisierung."""
        pred = DriftPrediction(
            probability=0.8,
            affected_adrs=["ADR-017"],
            severity=DriftSeverity.CRITICAL,
            reasoning="Critical drift detected",
        )
        data = pred.to_dict()
        restored = DriftPrediction.from_dict(data)
        assert restored.probability == pred.probability
        assert restored.affected_adrs == pred.affected_adrs
        assert restored.severity == pred.severity
        assert restored.reasoning == pred.reasoning


# =============================================================================
# PredictiveDriftEngine Tests
# =============================================================================


class TestPredictiveDriftEngine:
    """Tests für die PredictiveDriftEngine."""

    def test_predict_no_changes(self, base_graph):
        """predict() ohne Änderungen gibt leere Liste."""
        engine = PredictiveDriftEngine()
        predictions = engine.predict(base_graph, base_graph)
        assert len(predictions) == 0

    def test_predict_node_removal(self, base_graph, modified_graph):
        """predict() erkennt Node-Entfernung."""
        engine = PredictiveDriftEngine()
        predictions = engine.predict(modified_graph, base_graph)
        # Sollte mindestens eine Prediction für die entfernte ADR geben
        assert len(predictions) >= 1
        # Mindestens eine Prediction sollte das Constraint c1 betreffen
        # (a1 -> c1 REFERENCE-Edge im base_graph)
        constraint_affected = any(
            "c1" in p.affected_constraints for p in predictions
        )
        assert constraint_affected

    def test_predict_violation_edge(self, base_graph, graph_with_violation):
        """predict() erkennt neue VIOLATES-Edge."""
        engine = PredictiveDriftEngine()
        predictions = engine.predict(graph_with_violation, base_graph)
        # Sollte eine Prediction für die kritische Edge geben
        assert len(predictions) >= 1
        # Mindestens eine sollte CRITICAL severity haben
        critical = any(p.severity == DriftSeverity.CRITICAL for p in predictions)
        assert critical

    def test_predict_probability_range(self, base_graph, modified_graph):
        """Wahrscheinlichkeiten sind im Bereich 0.0 - 1.0."""
        engine = PredictiveDriftEngine()
        predictions = engine.predict(modified_graph, base_graph)
        for pred in predictions:
            assert 0.0 <= pred.probability <= 1.0

    def test_predict_reasoning_not_empty(self, base_graph, modified_graph):
        """Reasoning ist nicht leer bei Änderungen."""
        engine = PredictiveDriftEngine()
        predictions = engine.predict(modified_graph, base_graph)
        for pred in predictions:
            assert pred.reasoning, f"Reasoning should not be empty for {pred}"

    def test_what_if(self, base_graph):
        """what_if() simuliert einen Intent."""
        engine = PredictiveDriftEngine()
        predictions = engine.what_if(
            "Add runtime contract analysis for governance replay",
            base_graph,
        )
        # Sollte Predictions zurückgeben (auch wenn hypothetisch)
        assert isinstance(predictions, list)

    def test_what_if_empty_intent(self, base_graph):
        """what_if() mit leerem Intent."""
        engine = PredictiveDriftEngine()
        predictions = engine.what_if("", base_graph)
        assert isinstance(predictions, list)

    def test_get_risk_profile_implementation_gap(self):
        """Risikoprofil für IMPLEMENTATION_GAP."""
        engine = PredictiveDriftEngine()
        ticket = CompiledTicket(
            ticket_id="TASK-0001",
            ticket_type=TicketType.IMPLEMENTATION_GAP,
            title="Implement Contract Analyzer",
            affected_components=["core/contracts"],
            risk=RiskLevel.HIGH,
        )
        profile = engine.get_risk_profile(ticket)
        assert profile.probability > 0
        assert profile.severity in (DriftSeverity.LOW, DriftSeverity.MEDIUM,
                                     DriftSeverity.HIGH, DriftSeverity.CRITICAL)

    def test_get_risk_profile_governance_violation(self):
        """Risikoprofil für GOVERNANCE_VIOLATION (höheres Risiko)."""
        engine = PredictiveDriftEngine()
        ticket = CompiledTicket(
            ticket_id="TASK-0002",
            ticket_type=TicketType.GOVERNANCE_VIOLATION,
            title="Fix governance violation",
            affected_components=["core/governance"],
            risk=RiskLevel.CRITICAL,
        )
        profile = engine.get_risk_profile(ticket)
        # GOVERNANCE_VIOLATION hat Basis-Risiko 0.8
        assert profile.probability >= 0.5

    def test_get_risk_profile_coverage_gap(self):
        """Risikoprofil für COVERAGE_GAP (niedrigeres Risiko)."""
        engine = PredictiveDriftEngine()
        ticket = CompiledTicket(
            ticket_id="TASK-0003",
            ticket_type=TicketType.COVERAGE_GAP,
            title="Add test coverage",
            risk=RiskLevel.LOW,
        )
        profile = engine.get_risk_profile(ticket)
        # COVERAGE_GAP hat Basis-Risiko 0.2
        assert profile.probability <= 0.3

    def test_get_risk_profile_with_capabilities(self):
        """Risikoprofil mit Capabilities."""
        engine = PredictiveDriftEngine()
        ticket = CompiledTicket(
            ticket_id="TASK-0004",
            ticket_type=TicketType.IMPLEMENTATION_GAP,
            title="Add contract analysis",
            required_capabilities=["contract_analysis"],
            affected_components=["core/contracts"],
            risk=RiskLevel.MEDIUM,
        )
        profile = engine.get_risk_profile(ticket)
        assert "contract_analysis" in profile.reasoning

    def test_predict_consolidation(self, base_graph, modified_graph):
        """predict() konsolidiert ähnliche Predictions."""
        engine = PredictiveDriftEngine()
        predictions = engine.predict(modified_graph, base_graph)
        # Keine Duplikate mit gleichen ADRs/Constraints
        seen_keys = set()
        for pred in predictions:
            key = (tuple(sorted(pred.affected_adrs)),
                   tuple(sorted(pred.affected_constraints)))
            assert key not in seen_keys, f"Duplicate prediction for {key}"
            seen_keys.add(key)

    def test_predict_severity_mapping(self, base_graph, modified_graph):
        """Severity wird korrekt gemappt."""
        engine = PredictiveDriftEngine()
        predictions = engine.predict(modified_graph, base_graph)
        for pred in predictions:
            assert pred.severity in (
                DriftSeverity.LOW, DriftSeverity.MEDIUM,
                DriftSeverity.HIGH, DriftSeverity.CRITICAL,
            )

    def test_predict_edge_addition_critical(self, base_graph):
        """Neue VIOLATES-Edge ist immer CRITICAL."""
        engine = PredictiveDriftEngine()
        # Erzeuge Graph mit neuer VIOLATES-Edge
        new_edges = list(base_graph.edges) + [
            ExecutionEdge(
                source_id="comp1", target_id="a1",
                edge_type=EdgeType.VIOLATES,
            )
        ]
        viol_graph = ExecutionGraphIR(
            graph_id="viol_graph",
            source="pytest",
            timestamp=datetime.now(timezone.utc).isoformat(),
            nodes=dict(base_graph.nodes),
            edges=new_edges,
        )
        predictions = engine.predict(viol_graph, base_graph)
        critical_preds = [p for p in predictions if p.severity == DriftSeverity.CRITICAL]
        assert len(critical_preds) >= 1
