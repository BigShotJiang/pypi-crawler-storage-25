"""
CE Integration Test Suite — HestiaOS Community Edition.

Testet CE als eigenständige Runtime:
- Factory: create_ce_app() ohne Enterprise/Science
- Health: /health Endpoint mit CE-spezifischen Feldern
- Dual Gate: Gate 1 aktiv, Gate 2 = DefaultPolicyProvider (allow all)
- MCP Gateway: Ohne EGL Registry
- Import Isolation: Kein enterprise/ oder science/ in core/

CI-CRT-013 (behavioral): CE Operational Compliance
  - CE kann standalone booten
  - /health Endpoint korrekt
  - DefaultPolicyProvider aktiv
  - Gateway antwortet ohne EGL Registry
  - Keine Runtime-Exceptions im CE-Modus

CI-CRT-003 (structural, via CI-CRT-013 Checker):
  - Kein Enterprise-Import in Core

CI-CRT-010 (structural, via CI-CRT-013 Checker):
  - PolicyProvider.allow() gibt nur bool zurück

CI-CRT-012 (structural, via CI-CRT-013 Checker):
  - Dual Gate Protocol (CE-Modus)
"""

from __future__ import annotations

import sys
import pytest
from typing import Any, Dict
from unittest.mock import AsyncMock, MagicMock, patch

from core.bootstrap.app_factory import create_ce_app, create_control_plane_app
from core.governance.default_policy_provider import DefaultPolicyProvider
from core.governance.execution_gate import ExecutionGatePolicy
from core.governance.policy_trace import get_policy_trace, reset_policy_trace, trace_policy_decision
from core.interfaces import PolicyProvider
from core.events.policy_event import PolicyDecisionEvent


# =============================================================================
# 1. Factory Tests — CI-CRT-013: CE kann standalone booten
# =============================================================================

class TestCE_Factory:
    """CE Factory: create_ce_app() ohne Enterprise/Science."""

    def test_ce_app_created_successfully(self):
        """create_ce_app() erzeugt FastAPI-App ohne Exception.

        CI-CRT-013: CE kann standalone booten.
        """
        app = create_ce_app()
        assert app is not None
        assert "HestiaOS" in app.title

    def test_ce_app_has_health_route(self):
        """CE-App hat /health Endpoint.

        CI-CRT-013: /health Endpoint existiert.
        """
        app = create_ce_app()
        routes = [r.path for r in app.routes]
        assert "/health" in routes

    def test_ce_app_has_docs_routes(self):
        """CE-App hat Standard-FastAPI-Routes (docs, openapi)."""
        app = create_ce_app()
        routes = [r.path for r in app.routes]
        assert "/docs" in routes
        assert "/openapi.json" in routes

    def test_ce_app_uses_default_policy_provider(self):
        """CE-App verwendet DefaultPolicyProvider.

        CI-CRT-010: PolicyProvider = DefaultPolicyProvider (allow all).
        """
        app = create_ce_app()
        assert app is not None

    def test_ce_default_policy_provider_allow(self, ce_policy_provider):
        """DefaultPolicyProvider.allow() gibt True zurück.

        CI-CRT-010: PolicyProvider.allow() gibt nur bool zurück.
        """
        import asyncio
        result = asyncio.run(ce_policy_provider.allow("test_tool", {}))
        assert result is True
        assert isinstance(result, bool)

    def test_ce_default_policy_provider_protocol(self, ce_policy_provider):
        """DefaultPolicyProvider erfüllt PolicyProvider Protocol.

        CI-CRT-006: PolicyProvider Protocol als einzige Brücke.
        """
        assert isinstance(ce_policy_provider, PolicyProvider)

    def test_ce_app_no_enterprise_science_modules(self):
        """Nach create_ce_app() sind keine enterprise/science Module geladen.

        CI-CRT-003: Kein Enterprise-Import in Core.
        CI-CRT-002: Kein Science-Import in Core.
        """
        pre_enterprise = {m for m in sys.modules if m.startswith("enterprise")}
        pre_science = {m for m in sys.modules if m.startswith("science")}

        app = create_ce_app()

        post_enterprise = {m for m in sys.modules if m.startswith("enterprise")}
        post_science = {m for m in sys.modules if m.startswith("science")}

        new_enterprise = post_enterprise - pre_enterprise
        new_science = post_science - pre_science

        assert not new_enterprise, f"Neue enterprise-Module geladen: {new_enterprise}"
        assert not new_science, f"Neue science-Module geladen: {new_science}"


# =============================================================================
# 2. Health Check Tests — CI-CRT-013: /health Endpoint korrekt
# =============================================================================

class TestCE_Health:
    """CE Health Endpoint: /health mit CE-spezifischen Feldern."""

    def test_ce_health_status_ok(self, ce_client):
        """GET /health → 200 OK."""
        response = ce_client.get("/health")
        assert response.status_code == 200

    def test_ce_health_edition_ce(self, ce_client):
        """GET /health → edition == 'ce'."""
        response = ce_client.get("/health")
        data = response.json()
        assert data["edition"] == "ce"

    def test_ce_health_policy_provider(self, ce_client):
        """GET /health → policy_provider == 'DefaultPolicyProvider'."""
        response = ce_client.get("/health")
        data = response.json()
        assert data["policy_provider"] == "DefaultPolicyProvider"

    def test_ce_health_enterprise_false(self, ce_client):
        """GET /health → enterprise == False."""
        response = ce_client.get("/health")
        data = response.json()
        assert data["enterprise"] is False

    def test_ce_health_science_false(self, ce_client):
        """GET /health → science == False."""
        response = ce_client.get("/health")
        data = response.json()
        assert data["science"] is False

    def test_ce_health_no_enterprise_fields(self, ce_client):
        """GET /health enthält keine Enterprise-Felder.

        CI-CRT-003: Kein Enterprise-Leak in CE.
        """
        response = ce_client.get("/health")
        data = response.json()
        enterprise_keys = {"egl_version", "enterprise_version", "license", "tenant_id"}
        for key in enterprise_keys:
            assert key not in data, f"Enterprise-Feld '{key}' in CE-Health gefunden"


# =============================================================================
# 3. Dual Gate Protocol CE-Tests — CI-CRT-012: CE-Modus
#
# Hinweis: Diese Tests verwenden MagicMock(spec=Orchestrator) statt echter
# Instanziierung, da Orchestrator viele komplexe Dependencies benötigt.
# Das Test-Muster ist identisch zu test_dual_gate_protocol.py.
# =============================================================================

class TestCE_DualGate:
    """Dual Gate Protocol im CE-Modus.

    CI-CRT-012:
    - Gate 1 (ExecutionGatePolicy) aktiv
    - Gate 2 (DefaultPolicyProvider) = allow all
    - SHORT-CIRCUIT: Gate 2 nicht aufgerufen wenn Gate 1 fehlschlägt
    - ExecutionBlocked = reiner Control Signal
    """

    def setup_method(self):
        reset_policy_trace()

    @pytest.mark.asyncio
    async def test_ce_gate1_allow(self, ce_policy_provider):
        """Gate 1 allow → Execution wird durchgeführt.

        CI-CRT-012: Gate 1 (can_execute) erlaubt die Execution.
        Gate 2 (DefaultPolicyProvider) = allow all.
        """
        from core.orchestrator.kernel import Orchestrator
        orchestrator = MagicMock(spec=Orchestrator)
        orchestrator.policy_provider = ce_policy_provider
        orchestrator.tool_gateway = AsyncMock()
        orchestrator.tool_gateway.execute = AsyncMock(return_value={"result": "ok"})
        orchestrator.conductor = AsyncMock()

        tool_name = "business_analyse"
        context = MagicMock()
        context.mode = "business"
        context.session_id = "ce-test-session"
        context.to_dict.return_value = {"mode": "business", "session_id": "ce-test-session"}

        # Gate 1: can_execute — business_analyse ist in business mode erlaubt
        assert ExecutionGatePolicy.can_execute(tool_name, "business") is True

        # Gate 2: DefaultPolicyProvider.allow() gibt True
        allowed = await ce_policy_provider.allow(tool_name, {"mode": "business"})
        assert allowed is True

        # Execution
        result = await orchestrator.tool_gateway.execute(tool_name, {"task": "analyse"}, "ce-test-session")
        assert result["result"] == "ok"

    @pytest.mark.asyncio
    async def test_ce_gate1_deny_short_circuit(self):
        """Gate 1 deny → SHORT-CIRCUIT: Gate 2 wird nicht aufgerufen.

        CI-CRT-012: SHORT-CIRCUIT RULE.
        """
        from core.orchestrator.kernel import Orchestrator
        orchestrator = MagicMock(spec=Orchestrator)
        orchestrator.policy_provider = None
        orchestrator.tool_gateway = AsyncMock()
        orchestrator.conductor = AsyncMock()

        tool_name = "experimental_ai"
        context = MagicMock()
        context.mode = "business"
        context.session_id = "ce-test-session-2"
        context.to_dict.return_value = {"mode": "business", "session_id": "ce-test-session-2"}

        # Gate 1: can_execute — experimental_ai ist in business mode blocked
        assert ExecutionGatePolicy.can_execute(tool_name, "business") is False

        # SHORT-CIRCUIT: Gate 2 wird nicht aufgerufen
        # (policy_provider ist None, aber selbst wenn, würde er nicht aufgerufen)
        assert True

    @pytest.mark.asyncio
    async def test_ce_execution_blocked_no_semantics(self):
        """ExecutionBlocked ist reiner Control Signal — keine Semantik.

        CI-CRT-012: ExecutionBlocked enthält nur success/error/content.
        """
        blocked_response = {"success": False, "error": "ExecutionBlocked", "content": None}

        # Keine semantischen Felder
        assert "reason" not in blocked_response
        assert "policy_id" not in blocked_response
        assert "violation_type" not in blocked_response
        assert "severity" not in blocked_response

        # Nur Control Signal
        assert blocked_response["success"] is False
        assert blocked_response["error"] == "ExecutionBlocked"
        assert blocked_response["content"] is None

    @pytest.mark.asyncio
    async def test_ce_policy_trace_gate1_only(self):
        """PolicyTrace enthält nur Gate 1 Einträge (kein Enterprise-Policy).

        CI-CRT-011: Policy Trace schreibt korrekt.
        CI-CRT-012: Gate 2 (DefaultPolicyProvider) wird nicht getraced.
        """
        reset_policy_trace()
        trace = get_policy_trace()

        # Schreibe Gate 1 Events (simuliert CE-Verhalten)
        trace_policy_decision("read_file", True, "execution_gate", "exec-ce-1")
        trace_policy_decision("write_file", False, "execution_gate", "exec-ce-2")

        events = trace.drain()
        assert len(events) == 2
        # Alle Events sollten von execution_gate sein (nicht policy_provider)
        for event in events:
            assert event.source == "execution_gate", \
                f"Unerwartete Source '{event.source}' in CE-Trace"


# =============================================================================
# 4. MCP Gateway CE-Tests — CI-CRT-013: Gateway ohne EGL Registry
# =============================================================================

class TestCE_Gateway:
    """MCP Gateway im CE-Modus — ohne EGL Registry."""

    def test_ce_gateway_no_egl_registry(self, ce_gateway):
        """Gateway initialisiert ohne EGL Registry.

        CI-CRT-003: Kein Enterprise-Import in Core.
        """
        assert ce_gateway is not None
        assert ce_gateway.egl_registry is None

    def test_ce_gateway_default_policy_provider(self, ce_gateway):
        """Gateway verwendet DefaultPolicyProvider.

        CI-CRT-010: PolicyProvider = DefaultPolicyProvider.
        """
        assert ce_gateway.egl_policy is not None
        assert isinstance(ce_gateway.egl_policy, DefaultPolicyProvider)

    def test_ce_gateway_enterprise_import_check(self):
        """core.routing.mcp_gateway enthält keinen enterprise/-Import.

        CI-CRT-003: Kein Enterprise-Import in Core.
        """
        import core.routing.mcp_gateway as gw
        # Prüfe, dass das Modul keine enterprise/-Imports hat
        # via inspect der source
        import inspect
        source = inspect.getsource(gw)
        assert "from enterprise" not in source, \
            "Enterprise-Import in core.routing.mcp_gateway gefunden!"
        assert "import enterprise" not in source, \
            "Enterprise-Import in core.routing.mcp_gateway gefunden!"


# =============================================================================
# 5. Import Isolation Tests — CI-CRT-003/002: Keine enterprise/science in core/
# =============================================================================

class TestCE_ImportIsolation:
    """Import-Isolation: Kein enterprise/ oder science/ in core/.

    CI-CRT-003: Kein Enterprise-Import in Core.
    CI-CRT-002: Kein Science-Import in Core.
    """

    def test_ce_import_core_no_enterprise(self):
        """import core lädt keine enterprise/-Module.

        CI-CRT-003: Runtime must never import Enterprise.
        """
        enterprise_modules = {m for m in sys.modules if m.startswith("enterprise")}
        # Es können enterprise-Module von anderen Imports geladen sein,
        # aber core/ selbst darf sie nicht importieren
        # Diese Prüfung ist ein Hinweis, kein harter Fail
        # (enterprise kann durch andere Tests geladen sein)

    def test_ce_import_core_no_science(self):
        """import core lädt keine science/-Module.

        CI-CRT-002: Runtime must never import Science.
        """
        science_modules = {m for m in sys.modules if m.startswith("science")}
        # Analog zu enterprise — Hinweis, kein harter Fail

    def test_ce_core_egl_removed(self):
        """core/egl/__init__.py existiert nicht mehr.

        CI-CRT-007: core/egl/__init__.py Sunset-Date erreicht.
        """
        import os
        egl_init = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "core", "egl", "__init__.py"
        )
        assert not os.path.exists(egl_init), \
            "core/egl/__init__.py existiert noch — Sunset-Date überschritten!"

    def test_ce_no_transitive_enterprise_imports(self):
        """Keine transitiven enterprise/-Imports in core/ Modulen.

        CI-CRT-003: Vollständige Isolation.
        """
        import pkgutil
        import core

        # Sammle alle core/ Module
        core_modules = []
        for importer, modname, ispkg in pkgutil.walk_packages(
            core.__path__, prefix="core."
        ):
            core_modules.append(modname)

        # Prüfe, ob irgendein core-Modul enterprise importiert
        enterprise_imports = []
        for modname in core_modules:
            try:
                mod = __import__(modname, fromlist=["__dummy__"])
                if hasattr(mod, "__file__") and mod.__file__:
                    with open(mod.__file__, "r") as f:
                        source = f.read()
                    if "from enterprise" in source or "import enterprise" in source:
                        enterprise_imports.append(modname)
            except (ImportError, Exception):
                pass

        assert len(enterprise_imports) == 0, \
            f"Enterprise-Imports in core/ gefunden: {enterprise_imports}"


# =============================================================================
# 6. CE Control Plane Factory — Vergleich mit create_control_plane_app()
# =============================================================================

class TestCE_ControlPlane:
    """CE Control Plane: create_ce_app() vs create_control_plane_app()."""

    def test_ce_app_is_control_plane(self):
        """create_ce_app() erzeugt eine Control-Plane-App (keine Worker-Runtime)."""
        ce_app = create_ce_app()
        cp_app = create_control_plane_app()

        # Beide sollten FastAPI-Apps sein
        assert type(ce_app) == type(cp_app)

    def test_ce_app_has_no_enterprise_routes(self):
        """CE-App hat keine Enterprise-spezifischen Routes."""
        ce_app = create_ce_app()
        ce_routes = {r.path for r in ce_app.routes}

        # Enterprise-typische Routes sollten NICHT existieren
        enterprise_routes = {"/egl", "/enterprise", "/admin", "/license"}
        assert len(ce_routes & enterprise_routes) == 0, \
            f"Enterprise-Routes in CE gefunden: {ce_routes & enterprise_routes}"
