#!/usr/bin/env python3
"""Integration test for CachedHSPMiddlewareV2."""

import asyncio
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from typing import Dict, Any
from datetime import datetime
import uuid

from core.hsp.middleware_cached_v2 import CachedHSPMiddlewareV2
from core.hsp.schemas import HSPRequestSchema, HSPDecision, HSPDecisionOutcome
from core.hsp.tracing import HSPTraceSystem


class MockEGLClient:
    """Mock EGL client for testing."""
    
    async def evaluate(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Mock EGL evaluation."""
        await asyncio.sleep(0.01)  # Simulate some processing
        return {
            "decision": HSPDecisionOutcome.ALLOW,
            "reason": "Mock EGL decision",
            "confidence": 0.95,
            "policy_ids": ["mock_policy_1"],
            "constraints": {},
            "transformations": {}
        }


class MockPolicyStore:
    """Mock policy store for testing."""
    
    async def get_policies(self, context: Dict[str, Any]) -> list:
        """Mock policy retrieval."""
        return [
            {
                "id": "mock_policy_1",
                "name": "Test Policy",
                "conditions": {"always": True},
                "action": "allow"
            }
        ]


class MockPipeline:
    """Mock HSP pipeline for testing."""
    
    def __init__(self):
        self.execution_count = 0
    
    async def execute(self, hsp_request: HSPRequestSchema) -> HSPDecision:
        """Mock pipeline execution."""
        self.execution_count += 1
        await asyncio.sleep(0.02)  # Simulate pipeline processing
        
        return HSPDecision(
            outcome=HSPDecisionOutcome.ALLOW,
            trace_id=str(uuid.uuid4()),
            request_id=hsp_request.request_id,
            timestamp=datetime.now(),
            reason=f"Pipeline decision #{self.execution_count}",
            confidence=0.9,
            policy_ids=["test_policy"],
            constraints={},
            transformations={},
            metadata={"pipeline_execution": True}
        )


async def test_middleware_v2_basic():
    """Test basic middleware v2 functionality."""
    print("Testing CachedHSPMiddlewareV2 basic functionality...")
    
    # Create mock components
    egl_client = MockEGLClient()
    policy_store = MockPolicyStore()
    trace_system = HSPTraceSystem()
    
    # Create middleware with cache v2
    middleware = CachedHSPMiddlewareV2(
        egl_client=egl_client,
        policy_store=policy_store,
        trace_system=trace_system,
        config={
            "cache": {
                "default_ttl_seconds": 60,
                "max_size": 1000,
                "enable_semantic_equivalence": True,
                "semantic_normalization_level": "strict",
                "enable_del": True,
                "require_hsp_approval": True,
                "bypass_on_governance_failure": False  # Enable cache for testing
            }
        }
    )
    
    # Inject mock pipeline
    mock_pipeline = MockPipeline()
    middleware.pipeline = mock_pipeline
    
    # Create mock request
    class MockRequest:
        method = "POST"
        url = type('obj', (object,), {'path': '/api/test'})()
        client = type('obj', (object,), {'host': '127.0.0.1'})()
        headers = {"user-agent": "TestClient/1.0"}
    
    mock_request = MockRequest()
    
    # Test 1: First request (should miss cache)
    print("\nTest 1: First request (cache miss)")
    context1 = {
        "user_id": "user_123",
        "project_id": "project_456",
        "action": "read",
        "resource": "file.txt"
    }
    
    decision1 = await middleware.intercept_request(mock_request, context1)
    print(f"  Decision: {decision1.outcome}")
    print(f"  Pipeline executions: {mock_pipeline.execution_count}")
    print(f"  Cache hits: {middleware.cache_hits}, misses: {middleware.cache_misses}")
    
    # Test 2: Same request (should hit cache)
    print("\nTest 2: Same request (cache hit)")
    decision2 = await middleware.intercept_request(mock_request, context1)
    print(f"  Decision: {decision2.outcome}")
    print(f"  Pipeline executions: {mock_pipeline.execution_count} (should be same)")
    print(f"  Cache hits: {middleware.cache_hits}, misses: {middleware.cache_misses}")
    
    # Test 3: Request with different ephemeral field (should hit via semantic equivalence)
    print("\nTest 3: Request with different ephemeral field (semantic hit)")
    context3 = context1.copy()
    context3["timestamp"] = datetime.now().isoformat()  # Add ephemeral field
    context3["request_id"] = str(uuid.uuid4())  # Add another ephemeral field
    
    decision3 = await middleware.intercept_request(mock_request, context3)
    print(f"  Decision: {decision3.outcome}")
    print(f"  Pipeline executions: {mock_pipeline.execution_count} (should still be same)")
    print(f"  Cache hits: {middleware.cache_hits}, misses: {middleware.cache_misses}")
    print(f"  Semantic equivalence hits: {middleware.semantic_equivalence_hits}")
    
    # Test 4: Different request (should miss cache)
    print("\nTest 4: Different request (cache miss)")
    context4 = {
        "user_id": "user_789",  # Different user
        "project_id": "project_456",
        "action": "write",  # Different action
        "resource": "file.txt"
    }
    
    decision4 = await middleware.intercept_request(mock_request, context4)
    print(f"  Decision: {decision4.outcome}")
    print(f"  Pipeline executions: {middleware.pipeline.execution_count}")
    print(f"  Cache hits: {middleware.cache_hits}, misses: {middleware.cache_misses}")
    
    # Test 5: Get performance metrics
    print("\nTest 5: Performance metrics")
    metrics = middleware.get_performance_metrics()
    print(f"  Total requests: {metrics['total_requests']}")
    print(f"  Hit rate: {metrics['hit_rate']:.2%}")
    print(f"  Semantic hit rate: {metrics['semantic_hit_rate']:.2%}")
    print(f"  Miss reasons: {metrics['miss_reasons']}")
    
    # Test 6: Get cache stats
    print("\nTest 6: Cache statistics")
    cache_stats = await middleware.get_cache_stats()
    print(f"  Cache layer stats: {list(cache_stats['cache_v2_stats'].keys())}")
    
    # Verify results
    assert mock_pipeline.execution_count == 2, f"Expected 2 pipeline executions, got {mock_pipeline.execution_count}"
    assert middleware.cache_hits >= 2, f"Expected at least 2 cache hits, got {middleware.cache_hits}"
    assert middleware.cache_misses == 2, f"Expected 2 cache misses, got {middleware.cache_misses}"
    assert middleware.semantic_equivalence_hits >= 1, f"Expected at least 1 semantic hit, got {middleware.semantic_equivalence_hits}"
    
    print("\n✅ All basic tests passed!")
    return True


async def test_middleware_v2_observability():
    """Test observability features."""
    print("\n\nTesting CachedHSPMiddlewareV2 observability...")
    
    # Create middleware
    egl_client = MockEGLClient()
    policy_store = MockPolicyStore()
    trace_system = HSPTraceSystem()
    
    middleware = CachedHSPMiddlewareV2(
        egl_client=egl_client,
        policy_store=policy_store,
        trace_system=trace_system,
        config={"cache": {"enable_semantic_equivalence": True}}
    )
    
    mock_pipeline = MockPipeline()
    middleware.pipeline = mock_pipeline
    
    class MockRequest:
        method = "GET"
        url = type('obj', (object,), {'path': '/api/observability'})()
        client = type('obj', (object,), {'host': '127.0.0.1'})()
        headers = {"user-agent": "TestClient/1.0"}
    
    mock_request = MockRequest()
    
    # Make several requests with variations
    contexts = [
        {"user": "alice", "action": "read", "resource": "doc1"},
        {"user": "alice", "action": "read", "resource": "doc1", "timestamp": "2024-01-01"},  # Ephemeral
        {"user": "alice", "action": "read", "resource": "doc2"},  # Different resource
        {"user": "bob", "action": "read", "resource": "doc1"},  # Different user
        {"user": "alice", "action": "write", "resource": "doc1"},  # Different action
    ]
    
    for i, context in enumerate(contexts, 1):
        await middleware.intercept_request(mock_request, context)
        print(f"  Request {i}: context={context}")
    
    # Check observability metrics
    metrics = middleware.get_performance_metrics()
    
    print(f"\nObservability results:")
    print(f"  Total requests: {metrics['total_requests']}")
    print(f"  Hit rate: {metrics['hit_rate']:.2%}")
    print(f"  Unique cache keys: {metrics['key_distribution_summary']['unique_keys']}")
    print(f"  Miss reasons: {metrics['miss_reasons']}")
    
    # Verify we have some distribution data
    assert metrics['key_distribution_summary']['unique_keys'] > 0, "Should have unique keys"
    assert len(metrics['miss_reasons']) > 0, "Should have miss reasons recorded"
    
    print("✅ Observability tests passed!")
    return True


async def main():
    """Run all tests."""
    print("=" * 60)
    print("CachedHSPMiddlewareV2 Integration Tests")
    print("=" * 60)
    
    try:
        success1 = await test_middleware_v2_basic()
        success2 = await test_middleware_v2_observability()
        
        if success1 and success2:
            print("\n" + "=" * 60)
            print("🎉 All integration tests passed successfully!")
            print("=" * 60)
            return 0
        else:
            print("\n❌ Some tests failed!")
            return 1
            
    except Exception as e:
        print(f"\n❌ Error during testing: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)