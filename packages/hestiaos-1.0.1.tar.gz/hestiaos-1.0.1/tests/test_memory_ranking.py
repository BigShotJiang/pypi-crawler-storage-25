"""
Test: Hybrid Ranking, Query Processing, Session Awareness, Dedup, Schema Versioning

Lädt CoreMemory via importlib mit vorherigem CORE01-Setup.
"""
import importlib.util
import sys
import os
import tempfile
import json
from pathlib import Path

# ── CORE01 zuerst laden (wird von memory.py am Ende benötigt) ────
identity_spec = importlib.util.spec_from_file_location(
    "brain.identity",
    os.path.join(os.path.dirname(__file__), "..", "brain", "identity.py"),
)
identity_module = importlib.util.module_from_spec(identity_spec)
sys.modules["brain.identity"] = identity_module
identity_spec.loader.exec_module(identity_module)
CORE01 = identity_module.CORE01

# storage_path auf temp umbiegen, damit memory = CoreMemory() nicht /data braucht
CORE01.storage_path = tempfile.mkdtemp(prefix="hestia_test_")

# ── core.db_capabilities vorladen (wird von brain.memory importiert) ──
db_caps_spec = importlib.util.spec_from_file_location(
    "core.db_capabilities",
    os.path.join(os.path.dirname(__file__), "..", "core", "db_capabilities.py"),
)
db_caps_module = importlib.util.module_from_spec(db_caps_spec)
sys.modules["core.db_capabilities"] = db_caps_module
db_caps_spec.loader.exec_module(db_caps_module)

# ── CoreMemory direkt laden (ohne brain/__init__.py) ──────────────
SPEC = importlib.util.spec_from_file_location(
    "brain.memory",
    os.path.join(os.path.dirname(__file__), "..", "brain", "memory.py"),
)
memory_module = importlib.util.module_from_spec(SPEC)
memory_module.CORE01 = CORE01
sys.modules["brain.memory"] = memory_module
SPEC.loader.exec_module(memory_module)
CoreMemory = memory_module.CoreMemory


def create_memory(tmp_dir: str) -> CoreMemory:
    """Erzeugt eine frische CoreMemory-Instanz mit temporärem DB-Pfad."""
    db_path = os.path.join(tmp_dir, "test_memory.db")
    mem = CoreMemory(db_path=db_path)
    return mem


# ═══════════════════════════════════════════════════════════════════
# Tests
# ═══════════════════════════════════════════════════════════════════

def test_schema_versioning():
    """PRIO 5: Schema-Version wird beim ersten Start gespeichert."""
    with tempfile.TemporaryDirectory() as tmp:
        mem = create_memory(tmp)
        stats = mem.get_statistics()
        assert "schema_version" in stats, f"schema_version fehlt: {stats}"
        assert stats["schema_version"] == 1, f"Version != 1: {stats}"
        print(f"  ✓ Schema Version: {stats['schema_version']}")


def test_fts5_availability():
    """Prüft ob FTS5 verfügbar ist (oder LIKE-Fallback)."""
    with tempfile.TemporaryDirectory() as tmp:
        mem = create_memory(tmp)
        stats = mem.get_statistics()
        assert "fts5_available" in stats
        status = "✅ verfügbar" if stats["fts5_available"] else "⚠️ LIKE-Fallback"
        print(f"  ✓ FTS5: {status}")


def test_store_and_search_memory():
    """Basis: Memory speichern und suchen (Abwärtskompatibilität)."""
    with tempfile.TemporaryDirectory() as tmp:
        mem = create_memory(tmp)
        mem.store_memory("HestiaOS ist ein Multi-Agent-System", "general")
        mem.store_memory("RALPH loops ermöglichen rekursive Aufgaben", "technical")
        results = mem.search_memories("HestiaOS")
        assert len(results) >= 1, f"Keine Ergebnisse: {results}"
        print(f"  ✓ Memory-Suche: {len(results)} Treffer")


def test_hybrid_ranking():
    """
    PRIO 1: Hybrid Ranking testen.
    """
    with tempfile.TemporaryDirectory() as tmp:
        mem = create_memory(tmp)
        for i in range(5):
            mem.store_observation(
                session_id="test-session",
                type="note",
                title=f"Hybrid Ranking Test {i}",
                narrative="Dies ist ein Test für das hybride Ranking-System mit BM25 und Recency",
            )
        results = mem.search_observations("Hybrid Ranking Test")
        assert len(results) >= 1, f"Keine Ergebnisse: {results}"
        if "hybrid_score" in results[0]:
            print(f"  ✓ Hybrid Score vorhanden: {results[0]['hybrid_score']:.4f}")
        else:
            print(f"  ⚠ Kein hybrid_score (FTS5 nicht verfügbar)")
        print(f"  ✓ {len(results)} Ergebnisse für Hybrid-Ranking")


def test_query_normalization():
    """
    PRIO 2: Query Processing.
    """
    with tempfile.TemporaryDirectory() as tmp:
        mem = create_memory(tmp)
        mem.store_observation(
            session_id="test-session",
            type="note",
            title="Query Normalization",
            narrative="Dies ist ein wichtiger Test für die Query-Verarbeitung",
        )
        results = mem.search_observations("DIES ist ein wichtiger TEST")
        assert len(results) >= 1, f"Stopword-Filter entfernt zu viel: {results}"
        print(f"  ✓ Query-Normalisierung: {len(results)} Treffer")


def test_session_awareness():
    """
    PRIO 3: Session Awareness.
    """
    with tempfile.TemporaryDirectory() as tmp:
        mem = create_memory(tmp)
        mem.store_observation(
            session_id="current-session",
            type="note",
            title="Session Awareness Test",
            narrative="Dieser Eintrag ist in der aktuellen Session",
        )
        mem.store_observation(
            session_id="other-session",
            type="note",
            title="Session Awareness Test",
            narrative="Dieser Eintrag ist in einer anderen Session",
        )
        boosted = mem.search_observations(
            "Session Awareness Test",
            boost_current_session="current-session",
        )
        assert len(boosted) >= 1, f"Keine geboosteten Ergebnisse: {boosted}"
        print(f"  ✓ Session Boost: {len(boosted)} Ergebnisse")
        if boosted:
            top_session = boosted[0].get("session_id", "")
            print(f"  ✓ Top-Ergebnis Session: {top_session}")


def test_dedup_merge():
    """
    PRIO 4: Dedup / Merge.
    """
    with tempfile.TemporaryDirectory() as tmp:
        mem = create_memory(tmp)
        mem.store_observation(
            session_id="dedup-session",
            type="note",
            title="Dedup Test Eintrag",
            narrative="Erster Inhalt",
            facts=["Fakt 1"],
        )
        mem.store_observation(
            session_id="dedup-session",
            type="note",
            title="Dedup Test Eintrag",
            narrative="Zweiter Inhalt (angereichert)",
            facts=["Fakt 2"],
        )
        results = mem.get_observations_by_session("dedup-session")
        assert len(results) == 1, (
            f"Dedup fehlgeschlagen: {len(results)} Einträge statt 1"
        )
        merged = results[0]
        print(f"  ✓ Dedup: {len(results)} Eintrag (erwartet)")
        print(f"  ✓ Gemerged Narrative: {merged.get('narrative', '')[:50]}...")
        print(f"  ✓ Gemerged Facts: {merged.get('facts', [])}")


def test_column_weights():
    """
    PRIO 1b: Column Weights.
    """
    with tempfile.TemporaryDirectory() as tmp:
        mem = create_memory(tmp)
        mem.store_observation(
            session_id="col-session",
            type="note",
            title="Spezifisches Schlüsselwort im Titel",
            narrative="Irgendein Text",
        )
        mem.store_observation(
            session_id="col-session",
            type="note",
            title="Beliebiger Titel",
            narrative="Irgendein Text",
            facts=["Spezifisches Schlüsselwort in facts"],
        )
        results = mem.search_observations("Spezifisches Schlüsselwort")
        assert len(results) >= 1, f"Keine Ergebnisse: {results}"
        if len(results) >= 2:
            top_title = results[0].get("title", "")
            print(f"  ✓ Top-Ergebnis: '{top_title}'")
            print(f"  ✓ Column Weights wirken (Titel > Facts)")
        else:
            print(f"  ⚠ Nur 1 Treffer (FTS5 ggf. nicht verfügbar)")
        print(f"  ✓ {len(results)} Ergebnisse")


def test_recency_score():
    """PRIO 1: Recency-Score Berechnung."""
    from datetime import datetime, timedelta
    import datetime as dt_mod
    now = dt_mod.datetime.now(dt_mod.timezone.utc).isoformat()
    score_now = CoreMemory._compute_recency_score(now)
    assert 0.9 <= score_now <= 1.0, f"Score für 'jetzt' zu niedrig: {score_now}"
    old = (dt_mod.datetime.now(dt_mod.timezone.utc) - timedelta(days=7)).isoformat()
    score_old = CoreMemory._compute_recency_score(old)
    assert 0.4 <= score_old <= 0.6, f"Score für 7 Tage falsch: {score_old}"
    very_old = (dt_mod.datetime.now(dt_mod.timezone.utc) - timedelta(days=30)).isoformat()
    score_very_old = CoreMemory._compute_recency_score(very_old)
    assert score_very_old < 0.2, f"Score für 30 Tage zu hoch: {score_very_old}"
    print(f"  ✓ Recency: jetzt={score_now:.4f}, 7d={score_old:.4f}, 30d={score_very_old:.4f}")


def test_access_score():
    """PRIO 1: Access-Score Berechnung."""
    score_0 = CoreMemory._compute_access_score(0)
    assert score_0 == 0.0, f"Access 0 sollte 0 sein: {score_0}"
    score_1 = CoreMemory._compute_access_score(1)
    assert score_1 == 0.5, f"Access 1 sollte 0.5 sein: {score_1}"
    score_10 = CoreMemory._compute_access_score(10)
    assert abs(score_10 - 0.909) < 0.01, f"Access 10 falsch: {score_10}"
    print(f"  ✓ Access: 0={score_0}, 1={score_1}, 10={score_10:.4f}")


def test_hybrid_score_formula():
    """
    PRIO 1: Hybrid-Score Formel: BM25*0.6 + Recency*0.25 + Access*0.15.
    Nutzt eine Instanz, da _compute_hybrid_score eine Instanz-Methode ist.
    """
    with tempfile.TemporaryDirectory() as tmp:
        mem = create_memory(tmp)
        score = mem._compute_hybrid_score(0.8, "2026-05-04T12:00:00", 5)
        # bm25=0.8, recency~0.5 (7 Tage alt), access=1-1/6=0.833
        # Wir prüfen nur, dass der Score im erwarteten Bereich liegt
        assert 0.5 <= score <= 1.0, f"Hybrid Score ausserhalb Bereich: {score}"
        print(f"  ✓ Hybrid Score (mit BM25): {score:.4f}")

        # Ohne BM25 (LIKE-Fallback)
        score_no_bm25 = mem._compute_hybrid_score(None, "2026-05-04T12:00:00", 5)
        assert 0.3 <= score_no_bm25 <= 0.8, f"Hybrid Score (ohne BM25) ausserhalb: {score_no_bm25}"
        print(f"  ✓ Hybrid Score (ohne BM25): {score_no_bm25:.4f}")


def test_normalize_tokens():
    """PRIO 2: Token-Normalisierung entfernt Stopwords."""
    tokens = CoreMemory._normalize_tokens("der die das ein wichtiger test und oder")
    assert "der" not in tokens, f"Stopword 'der' nicht entfernt: {tokens}"
    assert "die" not in tokens, f"Stopword 'die' nicht entfernt: {tokens}"
    assert "das" not in tokens, f"Stopword 'das' nicht entfernt: {tokens}"
    assert "wichtiger" in tokens, f"'wichtiger' fehlt: {tokens}"
    assert "test" in tokens, f"'test' fehlt: {tokens}"
    print(f"  ✓ Tokens: {tokens}")


def test_sanitize_fts_query():
    """
    PRIO 2: FTS-Query wird korrekt bereinigt.
    Hinweis: _sanitize_fts_query lowercased + fügt Prefix-Wildcards hinzu.
    """
    query = CoreMemory._sanitize_fts_query("der HestiaOS Test und")
    # Stopwords entfernt, lowercased, Wildcards für >2 Zeichen
    assert "der" not in query, f"Stopword 'der' in Query: {query}"
    assert "und" not in query, f"Stopword 'und' in Query: {query}"
    # "hestiaos" (lowercased) mit Wildcard
    assert "hestiaos" in query.lower(), f"'hestiaos' fehlt: {query}"
    assert "test" in query.lower(), f"'test' fehlt: {query}"
    print(f"  ✓ Sanitized Query: '{query}'")


def test_statistics():
    """Vollständige Statistiken prüfen."""
    with tempfile.TemporaryDirectory() as tmp:
        mem = create_memory(tmp)
        stats = mem.get_statistics()
        required_keys = [
            "total_memories", "total_observations", "recent_conversations",
            "total_tokens", "schema_version", "fts5_available",
        ]
        for key in required_keys:
            assert key in stats, f"Statistik '{key}' fehlt: {stats}"
        print(f"  ✓ Statistiken: {json.dumps(stats, default=str)}")


def test_export_to_json():
    """Export-Funktionalität prüfen."""
    with tempfile.TemporaryDirectory() as tmp:
        mem = create_memory(tmp)
        mem.store_memory("Export Test", "general")
        export_path = os.path.join(tmp, "export.json")
        mem.export_to_json(export_path)
        assert os.path.exists(export_path), "Export-Datei nicht erstellt"
        with open(export_path) as f:
            data = json.load(f)
        assert "memories" in data, "Export enthält keine memories"
        print(f"  ✓ Export: {export_path}")


# ═══════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    tests = [
        ("Schema Versioning", test_schema_versioning),
        ("FTS5 Availability", test_fts5_availability),
        ("Store & Search Memory", test_store_and_search_memory),
        ("Recency Score", test_recency_score),
        ("Access Score", test_access_score),
        ("Hybrid Score Formula", test_hybrid_score_formula),
        ("Token Normalization", test_normalize_tokens),
        ("Query Sanitization", test_sanitize_fts_query),
        ("Hybrid Ranking", test_hybrid_ranking),
        ("Query Normalization", test_query_normalization),
        ("Session Awareness", test_session_awareness),
        ("Dedup / Merge", test_dedup_merge),
        ("Column Weights", test_column_weights),
        ("Statistics", test_statistics),
        ("Export JSON", test_export_to_json),
    ]

    passed = 0
    failed = 0
    print("═" * 60)
    print("  CoreMemory Ranking & Relevance Tests")
    print("═" * 60)
    print()

    for name, func in tests:
        try:
            func()
            print(f"  ✅ {name}")
            passed += 1
        except Exception as e:
            print(f"  ❌ {name}: {e}")
            failed += 1
        print()

    print("═" * 60)
    print(f"  Ergebnis: {passed}/{len(tests)} bestanden, {failed} fehlgeschlagen")
    print("═" * 60)

    sys.exit(1 if failed > 0 else 0)
