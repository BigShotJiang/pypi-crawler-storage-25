import unittest
import os
import shutil
from pathlib import Path
from core.security_vault import SecurityVault

class TestSecurityVault(unittest.TestCase):
    def setUp(self):
        self.test_dir = Path("/tmp/hestia_vault_test")
        if self.test_dir.exists():
            shutil.rmtree(self.test_dir)
        self.test_dir.mkdir(parents=True)
        self.vault = SecurityVault(vault_dir=self.test_dir)

    def tearDown(self):
        if self.test_dir.exists():
            shutil.rmtree(self.test_dir)

    def test_multi_tenant_isolation(self):
        tenant_a = "tenant-a"
        tenant_b = "tenant-b"
        data = "confidential intelligence"

        # Encrypt with A
        encrypted_a = self.vault.encrypt(tenant_a, data)
        # Encrypt with B
        encrypted_b = self.vault.encrypt(tenant_b, data)

        self.assertNotEqual(encrypted_a, encrypted_b)

        # Decrypt with A
        decrypted_a = self.vault.decrypt(tenant_a, encrypted_a)
        self.assertEqual(decrypted_a, data)

        # Attempt decrypt A with B's key (should fail if we tried to use the wrong key/cipher)
        # However, the vault.decrypt() takes tenant_id, so it picks the correct key.
        # To test isolation, we ensure keys are different.
        key_a = self.vault.get_or_create_tenant_key(tenant_a)
        key_b = self.vault.get_or_create_tenant_key(tenant_b)
        self.assertNotEqual(key_a, key_b)

    def test_persistence(self):
        tenant_id = "persistent-tenant"
        data = "don't forget this"
        
        encrypted = self.vault.encrypt(tenant_id, data)
        
        # Create a new vault instance pointing to same dir
        new_vault = SecurityVault(vault_dir=self.test_dir)
        decrypted = new_vault.decrypt(tenant_id, encrypted)
        self.assertEqual(decrypted, data)

if __name__ == "__main__":
    unittest.main()
