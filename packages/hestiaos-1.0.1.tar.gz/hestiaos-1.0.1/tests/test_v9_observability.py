import subprocess
import json
import os
import time
from pathlib import Path

CLI_EXEC = ["python3", "-m", "core.cli.main"]
AUDIT_FILE = "logs/audit.json"

def run_cli(args):
    cmd = CLI_EXEC + args
    res = subprocess.run(cmd, capture_output=True, text=True, env={**os.environ, "PYTHONPATH": "."})
    return res.stdout.strip(), res.returncode

def test_audit_analytics():
    print("🧪 Testing Audit Analytics (&/ logs audit --stats)...")
    stdout, rc = run_cli(["logs", "audit", "--stats"])
    
    try:
        data = json.loads(stdout)
        assert data["status"] == "success"
        stats = data["data"]
        assert "total_events" in stats
        assert "event_types" in stats
        print(f"   > Total Events: {stats['total_events']}")
        print("✅ Pass: Audit analytics accessible via CLI.")
    except Exception as e:
        print(f"❌ Fail: {e}")
        print(f"Raw: {stdout}")

def test_audit_query():
    print("🧪 Testing Audit Query (&/ logs audit --tail 5)...")
    stdout, rc = run_cli(["logs", "audit", "--tail", "5"])
    
    try:
        data = json.loads(stdout)
        events = data["data"]["events"]
        assert isinstance(events, list)
        assert len(events) <= 5
        print(f"   > Retrieved {len(events)} events.")
        print("✅ Pass: Audit query works.")
    except Exception as e:
        print(f"❌ Fail: {e}")

def test_error_taxonomy():
    print("🧪 Testing Error Taxonomy (Invalid Transition)...")
    # Trigger an error: Try to close a NEW ticket (assumes one exists)
    stdout, rc = run_cli(["tickets", "list"])
    tickets = json.loads(stdout)["data"]
    if tickets:
        ticket_id = tickets[0]["id"]
        # Try illegal transition
        print(f"   > Attempting illegal transition on {ticket_id} (status={tickets[0]['status']})...")
        stdout, rc = run_cli(["tickets", "close", ticket_id])
        res = json.loads(stdout)
        
        # Check for error
        if res["status"] == "error":
            code = res["error"]["code"]
            msg = res["error"]["message"]
            print(f"   > Error Code received: {code}")
            print(f"   > Error Message: {msg}")
            assert code == "INVALID_STATE_TRANSITION"
            print("✅ Pass: Standardized error code returned.")
        else:
            print(f"❌ Fail: Expected error status, got {res['status']}")
            print(f"Raw: {stdout}")
            assert False

def test_escalation_integration():
    print("🧪 Testing Escalation Integration...")
    # 1. Ensure we have a fresh ticket in FAILED state
    # We'll use a unique description to identify it
    unique_id = f"TEST-ESC-{int(time.time())}"
    
    # We can't easily injection a FAILED ticket via CLI doctor, 
    # so we'll just pick ANY ticket and force it to FAILED if possible, 
    # but the cleanest way is to use a known one.
    
    # Let's create a ticket via a small hack or just use the first available and RESOLVE it if needed.
    # Actually, the most reliable way to test THIS is to ensure the transition from NEW -> IN_PROGRESS -> FAILED -> ESCALATED works.
    
    # Get a NEW ticket
    stdout, rc = run_cli(["tickets", "list"])
    tickets = json.loads(stdout)["data"]
    new_tickets = [t for t in tickets if t["status"] == "NEW"]
    
    if not new_tickets:
        print("   ⚠️ No NEW tickets found to test escalation. Running doctor...")
        run_cli(["doctor", "--fix"])
        stdout, rc = run_cli(["tickets", "list"])
        new_tickets = [t for t in json.loads(stdout)["data"] if t["status"] == "NEW"]

    if new_tickets:
        ticket_id = new_tickets[0]["id"]
        print(f"   > Using ticket {ticket_id} for lifecycle test...")
        
        # Standardized Lifecycle Test: ESCALATE
        # (We escalate NEW directly to ensure side-effects are triggered)
        print(f"   > Escalating ticket {ticket_id}...")
        run_cli(["tickets", "escalate", ticket_id])
        
        # Check audit log for escalation routing event
        stdout, rc = run_cli(["logs", "audit", "--tail", "15"])
        events = json.loads(stdout)["data"]["events"]
        
        # Look for the event
        routing_event = next((e for e in events if e["event_type"] == "escalation_routing" and e["payload"].get("id") == ticket_id), None)
        
        if routing_event:
            print(f"   > Escalation routed successfully to: {routing_event['payload'].get('channel')}")
            print("✅ Pass: Escalation router triggered and audited.")
        else:
            print("❌ Fail: escalation_routing event NOT found in audit trail.")
            # Print last events for debug
            print("   > Last Event Types: " + ", ".join([e["event_type"] for e in events[-5:]]))
    else:
        print("⏭️ Skip: No suitable tickets for escalation test.")

if __name__ == "__main__":
    print("🚀 Starting HestiaOS CLI V9 Validation\n")
    test_audit_analytics()
    test_audit_query()
    test_error_taxonomy()
    test_escalation_integration()
    print("\n🏁 Build v9 Validation Complete.")
