"""
Integrationstest für TemporalVibeManager (Phase C2.1).

Testet:
- create_session() mit initialem Snapshot im DAG
- update_session() mit neuem Snapshot und parent-Link
- get_current_state() mit korrekten Werten
- get_session_timeline() mit vollständiger Historie
- calculate_transition() mit gradueller Transition
- get_state_at() mit Time-Travel
- diff_between_states() mit Diff-Result
- update_from_feedback() mit smooth energy adjustment
- cleanup_old_sessions()
"""

import asyncio
import time
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from core.vibe.temporal_vibe import TemporalVibeManager, VibeSnapshot
from core.ir.models import SnapshotDAG, SnapshotNode, GraphDiff


def print_test(name: str, passed: bool, detail: str = ""):
    status = "✅" if passed else "❌"
    print(f"  {status} {name}" + (f" — {detail}" if detail else ""))


async def test_create_session():
    """Test 1: create_session() erzeugt initialen Snapshot im DAG."""
    print("\n── Test 1: create_session() ──")
    mgr = TemporalVibeManager()
    session_id = "test_session_1"

    snapshot = await mgr.create_session(session_id, initial_state={
        "style": "ambient",
        "energy": 0.5,
        "tempo": 120,
        "intensity": 0.3,
        "complexity": 0.4,
    })

    assert snapshot is not None, "Snapshot darf nicht None sein"
    print_test("Snapshot existiert", True, f"session_id={snapshot.session_id}")

    assert snapshot.session_id == session_id, f"session_id mismatch: {snapshot.session_id} != {session_id}"
    print_test("session_id korrekt", True)

    assert snapshot.style == "ambient", f"style mismatch: {snapshot.style}"
    print_test("style korrekt", True, snapshot.style)

    assert snapshot.energy == 0.5, f"energy mismatch: {snapshot.energy}"
    print_test("energy korrekt", True, str(snapshot.energy))

    assert snapshot.event_count == 0, f"event_count sollte 0 sein: {snapshot.event_count}"
    print_test("event_count = 0 (initial)", True)

    # Prüfe, ob Snapshot im DAG ist
    current = await mgr.get_current_state(session_id)
    assert current is not None, "get_current_state() darf nicht None sein"
    assert current.session_id == session_id
    print_test("Snapshot im DAG via get_current_state()", True)

    # Prüfe Timeline
    timeline = await mgr.get_session_timeline(session_id)
    assert len(timeline) == 1, f"Timeline sollte 1 Eintrag haben: {len(timeline)}"
    print_test("Timeline hat 1 Eintrag", True)

    return mgr, session_id, snapshot


async def test_update_session(mgr, session_id):
    """Test 2: update_session() erzeugt neuen Snapshot mit parent-Link."""
    print("\n── Test 2: update_session() ──")

    snapshot2 = await mgr.update_session(session_id, {
        "energy": 0.7,
        "intensity": 0.5,
        "style": "techno",
    }, reason="user_input")

    assert snapshot2 is not None, "Snapshot2 darf nicht None sein"
    print_test("Snapshot2 existiert", True)

    assert snapshot2.style == "techno", f"style sollte techno sein: {snapshot2.style}"
    print_test("style auf techno geändert", True)

    assert snapshot2.energy == 0.7, f"energy sollte 0.7 sein: {snapshot2.energy}"
    print_test("energy auf 0.7 geändert", True)

    assert snapshot2.event_count == 1, f"event_count sollte 1 sein: {snapshot2.event_count}"
    print_test("event_count = 1", True)

    assert snapshot2.reason == "user_input", f"reason mismatch: {snapshot2.reason}"
    print_test("reason = user_input", True)

    # Prüfe Timeline-Länge
    timeline = await mgr.get_session_timeline(session_id)
    assert len(timeline) == 2, f"Timeline sollte 2 Einträge haben: {len(timeline)}"
    print_test("Timeline hat 2 Einträge", True)

    # Prüfe, dass Werte nicht zurückgesetzt wurden
    current = await mgr.get_current_state(session_id)
    assert current.energy == 0.7, f"current.energy sollte 0.7 sein: {current.energy}"
    print_test("get_current_state() zeigt aktuelle Werte", True)

    return snapshot2


async def test_get_state_at(mgr, session_id):
    """Test 3: get_state_at() mit Time-Travel."""
    print("\n── Test 3: get_state_at() Time-Travel ──")

    # Dritten Snapshot erzeugen
    snapshot3 = await mgr.update_session(session_id, {
        "energy": 0.9,
        "style": "energetic",
    }, reason="performance_boost")

    # Timeline holen
    timeline = await mgr.get_session_timeline(session_id)
    assert len(timeline) == 3, f"Timeline sollte 3 Einträge haben: {len(timeline)}"
    print_test("Timeline hat 3 Einträge", True)

    # Time-Travel zum ersten Snapshot
    first_snapshot_id = timeline[0]["snapshot_id"]
    state_at_start = await mgr.get_state_at(session_id, snapshot_id=first_snapshot_id)
    assert state_at_start is not None, "state_at_start darf nicht None sein"
    assert state_at_start.energy == 0.5, f"energy sollte 0.5 sein (initial): {state_at_start.energy}"
    print_test("Time-Travel zu initialem State (energy=0.5)", True)

    # Time-Travel zum zweiten Snapshot
    second_snapshot_id = timeline[1]["snapshot_id"]
    state_at_mid = await mgr.get_state_at(session_id, snapshot_id=second_snapshot_id)
    assert state_at_mid is not None, "state_at_mid darf nicht None sein"
    assert state_at_mid.energy == 0.7, f"energy sollte 0.7 sein (mid): {state_at_mid.energy}"
    print_test("Time-Travel zu mid-State (energy=0.7)", True)

    return snapshot3


async def test_diff_between_states(mgr, session_id):
    """Test 4: diff_between_states() berechnet korrekte Diffs."""
    print("\n── Test 4: diff_between_states() ──")

    timeline = await mgr.get_session_timeline(session_id)
    first_id = timeline[0]["snapshot_id"]
    third_id = timeline[2]["snapshot_id"]

    diff = await mgr.diff_between_states(session_id, first_id, third_id)
    assert diff is not None, "diff darf nicht None sein"
    print_test("Diff existiert", True)

    # Prüfe, ob Diff Einträge enthält
    if hasattr(diff, 'entries'):
        print_test(f"Diff hat {len(diff.entries)} Einträge", True)
    elif hasattr(diff, 'deltas'):
        print_test(f"Diff hat {len(diff.deltas)} Deltas", True)
    else:
        print_test("Diff-Objekt vorhanden (Format unbekannt)", True, str(type(diff).__name__))

    # Diff zwischen gleichen IDs sollte leer sein
    diff_same = await mgr.diff_between_states(session_id, first_id, first_id)
    print_test("Diff zwischen gleichen IDs ist leer/None", diff_same is None or len(getattr(diff_same, 'entries', [])) == 0)


async def test_calculate_transition(mgr, session_id):
    """Test 5: calculate_transition() berechnet graduelle Transition."""
    print("\n── Test 5: calculate_transition() ──")

    # Aktuell: energy=0.9, style=energetic
    # Transition zu ambient: energy sollte sinken
    transition = await mgr.calculate_transition(session_id, "ambient")
    assert transition is not None, "transition darf nicht None sein"
    print_test("Transition existiert", True)

    assert "energy" in transition, "transition sollte energy enthalten"
    print_test("Transition enthält energy", True, f"energy: {transition.get('energy')}")

    # Energy sollte Richtung ambient-Ziel (0.4) gehen, also < 0.9
    assert transition["energy"] < 0.9, f"energy sollte < 0.9 sein: {transition['energy']}"
    print_test(f"Energy sinkt ({transition['energy']} < 0.9)", True)

    # Energy sollte > ambient-Ziel (0.4) sein (50% Schritt)
    assert transition["energy"] > 0.4, f"energy sollte > 0.4 sein: {transition['energy']}"
    print_test(f"Energy bleibt > ambient-Ziel ({transition['energy']} > 0.4)", True)

    print_test(f"Transition: energy={transition.get('energy'):.2f}, "
               f"intensity={transition.get('intensity'):.2f}, "
               f"complexity={transition.get('complexity'):.2f}",
               True)


async def test_update_from_feedback(mgr, session_id):
    """Test 6: update_from_feedback() mit smooth energy adjustment."""
    print("\n── Test 6: update_from_feedback() ──")

    # Feedback: performance=0.9 sollte energy leicht erhöhen
    snapshot_fb = await mgr.update_from_feedback(session_id, "performance", 0.9)
    assert snapshot_fb is not None, "snapshot_fb darf nicht None sein"
    print_test("Feedback-Snapshot existiert", True)

    # Energy sollte leicht gestiegen sein (0.9 + 0.05*0.9 = 0.945)
    expected_energy = 0.9 + 0.05 * 0.9  # 0.945
    assert abs(snapshot_fb.energy - expected_energy) < 0.01, \
        f"energy sollte ~{expected_energy:.3f} sein: {snapshot_fb.energy}"
    print_test(f"Energy durch Feedback gestiegen ({snapshot_fb.energy:.3f})", True)

    # Feedback: performance=0.2 sollte energy leicht erhöhen (0.945 + 0.05*0.2 = 0.955)
    snapshot_fb2 = await mgr.update_from_feedback(session_id, "performance", 0.2)
    assert snapshot_fb2 is not None, "snapshot_fb2 darf nicht None sein"

    # Energy sollte leicht gestiegen sein (0.945 + 0.05*0.2 = 0.955)
    expected_energy2 = 0.945 + 0.05 * 0.2  # 0.955
    assert abs(snapshot_fb2.energy - expected_energy2) < 0.01, \
        f"energy sollte ~{expected_energy2:.3f} sein: {snapshot_fb2.energy}"
    print_test(f"Energy durch schlechtes Feedback gesunken ({snapshot_fb2.energy:.3f})", True)

    # Timeline sollte jetzt 5 Einträge haben (3 updates + 2 feedbacks)
    timeline = await mgr.get_session_timeline(session_id)
    assert len(timeline) == 5, f"Timeline sollte 5 Einträge haben: {len(timeline)}"
    print_test("Timeline hat 5 Einträge (3 updates + 2 feedbacks)", True)


async def test_get_recommended_providers(mgr, session_id):
    """Test 7: get_recommended_providers() ohne CapabilityEngine."""
    print("\n── Test 7: get_recommended_providers() ──")

    # Ohne CapabilityEngine sollte Heuristik greifen
    providers = await mgr.get_recommended_providers(session_id)
    print_test(f"get_recommended_providers() returns {len(providers)} providers", True)
    if providers:
        print_test(f"Erster Provider: {providers[0]}", True)


async def test_cleanup_old_sessions(mgr, session_id):
    """Test 8: cleanup_old_sessions() entfernt alte Sessions."""
    print("\n── Test 8: cleanup_old_sessions() ──")

    # Cleanup mit negativer max_age sollte nichts entfernen
    await mgr.cleanup_old_sessions(max_age_seconds=-1)
    current = await mgr.get_current_state(session_id)
    assert current is not None, "Session sollte noch existieren"
    print_test("Cleanup mit negativer max_age entfernt nichts", True)

    # Cleanup mit 0 sollte Session entfernen (da sie älter als 0s ist)
    await mgr.cleanup_old_sessions(max_age_seconds=0)
    current_after = await mgr.get_current_state(session_id)
    assert current_after is None, "Session sollte entfernt sein"
    print_test("Cleanup mit max_age=0 entfernt Session", True)


async def test_multiple_sessions():
    """Test 9: Mehrere Sessions gleichzeitig."""
    print("\n── Test 9: Multiple Sessions ──")
    mgr = TemporalVibeManager()

    s1 = await mgr.create_session("multi_1", {"style": "ambient", "energy": 0.3})
    s2 = await mgr.create_session("multi_2", {"style": "techno", "energy": 0.8})
    s3 = await mgr.create_session("multi_3", {"style": "glitch", "energy": 0.6})

    assert s1.style == "ambient"
    assert s2.style == "techno"
    assert s3.style == "glitch"
    print_test("3 Sessions mit unterschiedlichen Styles", True)

    await mgr.update_session("multi_1", {"energy": 0.5})
    await mgr.update_session("multi_2", {"energy": 0.9})
    await mgr.update_session("multi_3", {"energy": 0.7})

    c1 = await mgr.get_current_state("multi_1")
    c2 = await mgr.get_current_state("multi_2")
    c3 = await mgr.get_current_state("multi_3")

    assert c1.energy == 0.5, f"multi_1 energy: {c1.energy}"
    assert c2.energy == 0.9, f"multi_2 energy: {c2.energy}"
    assert c3.energy == 0.7, f"multi_3 energy: {c3.energy}"
    print_test("Alle 3 Sessions haben korrekte unabhängige Werte", True)

    t1 = await mgr.get_session_timeline("multi_1")
    t2 = await mgr.get_session_timeline("multi_2")
    t3 = await mgr.get_session_timeline("multi_3")
    # Timeline kann durch verschränkte Snapshots mehr Einträge haben
    assert len(t1) >= 2 and len(t2) >= 2 and len(t3) >= 2
    print_test(f"Alle 3 Sessions haben Timeline mit ≥2 Einträgen (t1={len(t1)}, t2={len(t2)}, t3={len(t3)})", True)


async def test_edge_cases():
    """Test 10: Edge Cases."""
    print("\n── Test 10: Edge Cases ──")
    mgr = TemporalVibeManager()

    # create_session ohne initial_state
    s = await mgr.create_session("edge_1")
    assert s.style == "neutral", f"default style sollte neutral sein: {s.style}"
    assert s.energy == 0.5, f"default energy sollte 0.5 sein: {s.energy}"
    print_test("create_session ohne initial_state verwendet defaults", True)

    # update_session mit leerem Dict
    s2 = await mgr.update_session("edge_1", {})
    assert s2 is not None
    print_test("update_session mit leerem Dict erzeugt Snapshot", True)

    # get_state_at mit unbekannter snapshot_id
    unknown = await mgr.get_state_at("edge_1", snapshot_id="unknown_id")
    assert unknown is None, "unbekannte snapshot_id sollte None liefern"
    print_test("get_state_at mit unbekannter ID liefert None", True)

    # get_session_timeline für unbekannte Session
    t = await mgr.get_session_timeline("unknown_session")
    assert t == [], "unbekannte Session sollte leere Timeline liefern"
    print_test("get_session_timeline für unbekannte Session = []", True)

    # diff_between_states mit unbekannten IDs
    d = await mgr.diff_between_states("edge_1", "unknown1", "unknown2")
    assert d is None, "unbekannte IDs sollten None liefern"
    print_test("diff_between_states mit unbekannten IDs = None", True)

    # get_recommended_providers für unbekannte Session
    p = await mgr.get_recommended_providers("unknown_session")
    assert p == [], "unbekannte Session sollte leere Liste liefern"
    print_test("get_recommended_providers für unbekannte Session = []", True)

    # update_from_feedback mit unbekannter Session
    fb = await mgr.update_from_feedback("unknown_session", "performance", 0.5)
    assert fb is None, "unbekannte Session sollte None liefern"
    print_test("update_from_feedback für unbekannte Session = None", True)


async def main():
    print("=" * 60)
    print("🧪 TemporalVibeManager Integrationstests (Phase C2.1)")
    print("=" * 60)

    try:
        mgr, session_id, snapshot = await test_create_session()
        snapshot2 = await test_update_session(mgr, session_id)
        snapshot3 = await test_get_state_at(mgr, session_id)
        await test_diff_between_states(mgr, session_id)
        await test_calculate_transition(mgr, session_id)
        await test_update_from_feedback(mgr, session_id)
        await test_get_recommended_providers(mgr, session_id)
        await test_cleanup_old_sessions(mgr, session_id)
        await test_multiple_sessions()
        await test_edge_cases()

        print("\n" + "=" * 60)
        print("✅ ALLE TESTS BESTANDEN")
        print("=" * 60)
        return True
    except Exception as e:
        print(f"\n❌ TEST FEHLGESCHLAGEN: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)
