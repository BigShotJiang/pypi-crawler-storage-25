import asyncio
import httpx
from core.config import config_manager
from core.observability.logger import system_logger

async def test_connection():
    nc_config = config_manager.get("nextcloud", {})
    url = nc_config.get("url", "").rstrip("/")
    user = nc_config.get("user", "")
    password = nc_config.get("password", "")
    
    room_token = "6mvoe63h"
    
    endpoint = f"{url}/ocs/v1.php/apps/spreed/api/v1/chat/{room_token}"
    headers = {
        "OCS-APIRequest": "true",
        "Accept": "application/json"
    }
    auth = (user, password)
    
    with open("tests/nc_test_result.txt", "w") as f:
        f.write(f"Testing connection to {url} as {user} for room {room_token}...\n")
        try:
            async with httpx.AsyncClient(timeout=10.0, verify=False) as client:
                resp = await client.get(endpoint, headers=headers, auth=auth)
                f.write(f"Status Code: {resp.status_code}\n")
                f.write(f"Content-Type: {resp.headers.get('content-type')}\n")
                if resp.status_code == 200:
                    f.write("Connection SUCCESSFUL\n")
                    try:
                        data = resp.json()
                        messages = data.get("ocs", {}).get("data", [])
                        f.write(f"Found {len(messages)} messages.\n")
                    except Exception as json_err:
                        f.write(f"JSON Parse Error: {json_err}\n")
                        f.write(f"Raw Response (first 100 chars): {resp.text[:100]}\n")
                else:
                    f.write(f"Connection FAILED: {resp.text}\n")
        except Exception as e:
            f.write(f"Error: {e}\n")

if __name__ == "__main__":
    asyncio.run(test_connection())
