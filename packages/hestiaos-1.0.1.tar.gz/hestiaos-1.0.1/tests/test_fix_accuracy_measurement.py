#!/usr/bin/env python3
"""
Test script for Fix Accuracy & Success Rate Measurement Capability.
"""
import asyncio
import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from core.capabilities.fix_accuracy_measurement import (
    FixAccuracyMeasurementCapability, MeasurementDimension, MeasurementMethod
)
from core.capabilities.pr_auditor import AutoFix, FixType, FixConfidence


async def test_single_fix_measurement():
    """Test measuring accuracy of a single fix."""
    print("=== Testing Single Fix Measurement ===")
    
    capability = FixAccuracyMeasurementCapability()
    
    # Create a test fix
    original_code = '''def insecure_function():
    password = "secret123"
    eval("print(password)")
    return password
'''
    
    fixed_code = '''def secure_function():
    import os
    password = os.getenv("PASSWORD", "default")
    # eval removed for security
    print("Password accessed")
    return password
'''
    
    fix = AutoFix(
        fix_id="test-fix-1",
        issue_id="test-issue-1",
        fix_type=FixType.SECURITY,
        confidence=FixConfidence.HIGH,
        description="Fix security vulnerabilities",
        file_path="test.py",
        old_code='password = "secret123"',
        new_code='password = os.getenv("PASSWORD", "default")',
        reasoning="Hardcoded passwords and eval are security risks"
    )
    
    # Measure fix accuracy
    measurement = await capability.measure_fix_accuracy(
        original_code, fixed_code, fix
    )
    
    print(f"Fix ID: {measurement.fix_id}")
    print(f"Fix Type: {measurement.fix_type}")
    print(f"Overall Score: {measurement.overall_score:.2f}")
    print(f"Confidence: {measurement.confidence:.2f}")
    
    print("\nDimension Scores:")
    for dimension, score in measurement.dimensions.items():
        print(f"  {dimension.value}: {score:.2f}")
    
    print("\nMeasurement Methods Used:")
    for method, data in measurement.methods.items():
        print(f"  {method.value}: {data.get('result', 'N/A')}")
    
    return measurement


async def test_batch_measurement():
    """Test measuring accuracy of a batch of fixes."""
    print("\n=== Testing Batch Measurement ===")
    
    capability = FixAccuracyMeasurementCapability()
    
    # Create test fixes
    test_fixes = [
        (
            'password = "secret123"',
            'password = os.getenv("PASSWORD")',
            AutoFix(
                fix_id="test-fix-1",
                issue_id="test-issue-1",
                fix_type=FixType.SECURITY,
                confidence=FixConfidence.HIGH,
                description="Fix hardcoded password",
                file_path="test.py",
                old_code='password = "secret123"',
                new_code='password = os.getenv("PASSWORD")',
                reasoning="Test fix"
            )
        ),
        (
            'def long_function(): pass',
            'def refactored_function(): pass',
            AutoFix(
                fix_id="test-fix-2",
                issue_id="test-issue-2",
                fix_type=FixType.QUALITY,
                confidence=FixConfidence.MEDIUM,
                description="Refactor long function",
                file_path="test.py",
                old_code='def long_function(): pass',
                new_code='def refactored_function(): pass',
                reasoning="Test fix"
            )
        ),
        (
            'import os\nos.system("rm -rf /")',
            'import subprocess\nsubprocess.run(["ls"], check=True)',
            AutoFix(
                fix_id="test-fix-3",
                issue_id="test-issue-3",
                fix_type=FixType.SECURITY,
                confidence=FixConfidence.LOW,
                description="Fix dangerous system call",
                file_path="test.py",
                old_code='os.system("rm -rf /")',
                new_code='subprocess.run(["ls"], check=True)',
                reasoning="Test fix"
            )
        )
    ]
    
    # Measure batch accuracy
    batch = await capability.measure_batch_accuracy(test_fixes)
    
    print(f"Batch ID: {batch.batch_id}")
    print(f"Total Fixes: {batch.summary['total_fixes']}")
    print(f"Average Overall Score: {batch.summary['average_overall_score']:.2f}")
    print(f"Success Rate: {batch.summary['success_rate']:.2%}")
    
    print("\nDimension Averages:")
    for dimension, score in batch.summary['dimension_scores'].items():
        print(f"  {dimension}: {score:.2f}")
    
    print("\nFix Type Distribution:")
    for fix_type, stats in batch.summary['fix_type_distribution'].items():
        print(f"  {fix_type}: {stats['count']} fixes, "
              f"avg score: {stats['average_score']:.2f}, "
              f"success rate: {stats['success_rate']:.2%}")
    
    return batch


async def test_performance_metrics():
    """Test calculating performance metrics."""
    print("\n=== Testing Performance Metrics ===")
    
    capability = FixAccuracyMeasurementCapability()
    
    # First add some measurements
    test_fixes = [
        (
            'x = 1',
            'x = 2',
            AutoFix(
                fix_id="test-fix-perf-1",
                issue_id="test-issue-perf-1",
                fix_type=FixType.QUALITY,
                confidence=FixConfidence.MEDIUM,
                description="Test fix",
                file_path="test.py",
                old_code='x = 1',
                new_code='x = 2',
                reasoning="Test"
            )
        )
    ]
    
    await capability.measure_batch_accuracy(test_fixes)
    
    # Calculate performance metrics
    metrics = await capability.calculate_performance_metrics(
        time_period="week",
        lookback_days=7
    )
    
    print(f"Time Period: {metrics.time_period}")
    print(f"Date Range: {metrics.start_date.date()} to {metrics.end_date.date()}")
    print(f"Total Fixes: {metrics.total_fixes}")
    print(f"Successful Fixes: {metrics.successful_fixes}")
    print(f"Failed Fixes: {metrics.failed_fixes}")
    print(f"Success Rate: {metrics.successful_fixes / metrics.total_fixes:.2%}" if metrics.total_fixes > 0 else "Success Rate: N/A")
    print(f"Average Accuracy: {metrics.average_accuracy:.2f}")
    
    print("\nDimension Scores:")
    for dimension, score in metrics.dimension_scores.items():
        print(f"  {dimension.value}: {score:.2f}")
    
    print("\nTrend Data Points:", len(metrics.trend_data))
    if metrics.trend_data:
        print(f"Latest: {metrics.trend_data[-1]['date']} - "
              f"{metrics.trend_data[-1]['fix_count']} fixes, "
              f"score: {metrics.trend_data[-1]['average_score']:.2f}")
    
    return metrics


async def test_capability_integration():
    """Test the complete capability integration."""
    print("\n=== Testing Capability Integration ===")
    
    capability = FixAccuracyMeasurementCapability()
    
    # Test the capability's own test method
    result = await capability.test_capability()
    
    print(f"Test Success: {result['success']}")
    if result['success']:
        print(f"Batch Summary: {result['batch_summary']}")
        print(f"Performance Metrics Calculated: Yes")
        print(f"Capability Metadata: {result['capability_metadata']['name']} v{result['capability_metadata']['version']}")
    else:
        print(f"Error: {result['error']}")
    
    return result


async def main():
    """Run all tests."""
    print("Fix Accuracy & Success Rate Measurement Capability Tests")
    print("=" * 60)
    
    try:
        # Test 1: Single fix measurement
        measurement = await test_single_fix_measurement()
        
        # Test 2: Batch measurement
        batch = await test_batch_measurement()
        
        # Test 3: Performance metrics
        metrics = await test_performance_metrics()
        
        # Test 4: Capability integration
        integration_result = await test_capability_integration()
        
        print("\n" + "=" * 60)
        print("All tests completed successfully!")
        
        # Summary
        print("\nSummary:")
        print(f"- Single fix measurement: {measurement.overall_score:.2f} overall score")
        print(f"- Batch measurement: {batch.summary['average_overall_score']:.2f} average score")
        print(f"- Performance metrics: {metrics.total_fixes} fixes analyzed")
        print(f"- Capability integration: {'SUCCESS' if integration_result['success'] else 'FAILED'}")
        
        return True
        
    except Exception as e:
        print(f"\nError during tests: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)