import pytest
from fastapi.testclient import TestClient
from unittest.mock import MagicMock, patch
from api.app import app
from core.rbac_system import Role, Permission, UserContext
from datetime import datetime

client = TestClient(app)

@pytest.fixture
def mock_rbac():
    with patch("api.dependencies.get_rbac_manager") as mock:
        manager = MagicMock()
        mock.return_value = manager
        yield manager

def test_config_no_headers():
    """Verify that missing headers result in 422 Unprocessable Entity."""
    response = client.get("/system/config")
    assert response.status_code == 422

def test_config_invalid_session(mock_rbac):
    """Verify that an invalid session results in 401 Unauthorized."""
    mock_rbac.get_user_context.return_value = None
    
    response = client.get(
        "/system/config",
        headers={"X-Tenant-ID": "test", "X-Session-ID": "invalid"}
    )
    assert response.status_code == 401
    assert response.json()["detail"] == "Invalid session"

def test_config_tenant_mismatch(mock_rbac):
    """Verify that a tenant mismatch results in 403 Forbidden."""
    mock_rbac.get_user_context.return_value = UserContext(
        user_id="user1", username="User 1", roles=[Role.ADMIN],
        permissions={Permission.READ}, authenticated_at=datetime.now(),
        tenant_id="tenant_a", session_id="sess1", expires_at=datetime.max
    )
    
    response = client.get(
        "/system/config",
        headers={"X-Tenant-ID": "tenant_b", "X-Session-ID": "sess1"}
    )
    assert response.status_code == 403
    assert response.json()["detail"] == "Tenant access denied"

def test_config_permission_denied(mock_rbac):
    """Verify that missing required permission results in 403 Forbidden."""
    mock_rbac.get_user_context.return_value = UserContext(
        user_id="user1", username="User 1", roles=[Role.GUEST],
        permissions=set(), authenticated_at=datetime.now(),
        tenant_id="tenant_a", session_id="sess1", expires_at=datetime.max
    )
    # Role.GUEST does not have Permission.READ usually for /system/config
    mock_rbac.validate_access.return_value = False
    
    response = client.get(
        "/system/config",
        headers={"X-Tenant-ID": "tenant_a", "X-Session-ID": "sess1"}
    )
    assert response.status_code == 403
    assert "Missing permission" in response.json()["detail"]

def test_config_allowed(mock_rbac):
    """Verify that valid session with permission results in 200 OK."""
    mock_rbac.get_user_context.return_value = UserContext(
        user_id="user1", username="User 1", roles=[Role.ADMIN],
        permissions={Permission.READ}, authenticated_at=datetime.now(),
        tenant_id="tenant_a", session_id="sess1", expires_at=datetime.max
    )
    mock_rbac.validate_access.return_value = True
    
    # Mock the actual endpoint logic to avoid dependency issues with agent
    with patch("api.routers.system.get_config") as mock_get_config:
        mock_get_config.return_value = {"config": "lite"}
        response = client.get(
            "/system/config",
            headers={"X-Tenant-ID": "tenant_a", "X-Session-ID": "sess1"}
        )
        assert response.status_code == 200
