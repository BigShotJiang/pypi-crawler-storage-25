#!/usr/bin/env python3
"""
Simple test for tombstoning functionality.
"""

import asyncio
import sys
import os

# Add core to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

async def test_tombstone_simple():
    """Simple test for tombstoning."""
    try:
        from core.tool_execution.budget_manager import (
            ToolResultBudgetManager, BudgetConfig
        )
    except ImportError as e:
        print(f"❌ Cannot import budget manager: {e}")
        return False
    
    print("🧪 Simple tombstoning test...")
    
    # Create budget manager
    config = BudgetConfig(
        enable_tombstoning=True,
        fallback_strategy="empty_result"
    )
    manager = ToolResultBudgetManager(config)
    
    # Record a tombstone
    tool_name = "failing_tool"
    arguments = {"input": "test"}
    
    print("1. Recording tombstone...")
    tombstone = manager.record_tombstone(
        tool_name=tool_name,
        error_type="RuntimeError",
        error_message="Tool crashed",
        arguments=arguments
    )
    
    print(f"   Tombstone recorded: {tombstone.error_type}")
    
    # Check tombstone
    print("2. Checking tombstone...")
    check = manager.check_tombstone(tool_name, arguments)
    assert check is not None, "Tombstone should be found"
    print(f"   Tombstone found: {check.error_type}")
    
    # Test apply_budget with tombstoned tool
    print("3. Testing apply_budget...")
    result, usage = await manager.apply_budget(
        tool_name=tool_name,
        result={"original": "result"},
        arguments=arguments
    )
    
    print(f"   Result: {result}")
    print(f"   Metadata: {usage.metadata}")
    
    # Check that it was marked as tombstoned
    assert usage.metadata.get("tombstoned") == True, "Should be marked as tombstoned"
    assert "error" in result, "Should return error structure"
    
    print("✅ Simple tombstoning test passed!")
    return True

async def main():
    """Run simple test."""
    try:
        success = await test_tombstone_simple()
        if success:
            print("\n==========================================")
            print("✅ Tombstoning is working correctly!")
            print("   - Tombstone recording works")
            print("   - Tombstone checking works")
            print("   - Fallback results are returned")
            print("   - Metadata includes tombstone info")
            print("==========================================")
            return True
        else:
            print("\n❌ Tombstoning test failed.")
            return False
    except Exception as e:
        print(f"❌ Test failed with exception: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)