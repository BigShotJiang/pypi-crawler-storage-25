"""
Tests for Workflow DSL — context.py (ExecutionContext + WorkflowEvent).
"""

import pytest
from datetime import datetime

from core.workflow_dsl.context import (
    ExecutionContext,
    ExecutionStatus,
    StepTrace,
    WorkflowEvent,
)


class TestExecutionStatus:
    def test_values(self):
        assert ExecutionStatus.PENDING == "pending"
        assert ExecutionStatus.RUNNING == "running"
        assert ExecutionStatus.COMPLETED == "completed"
        assert ExecutionStatus.FAILED == "failed"
        assert ExecutionStatus.CANCELLED == "cancelled"
        assert ExecutionStatus.TIMEOUT == "timeout"


class TestStepTrace:
    def test_minimal(self):
        trace = StepTrace(
            step_id="s1",
            step_name="Step 1",
            step_type="llm",
            status=ExecutionStatus.RUNNING,
            started_at=datetime.utcnow(),
        )
        assert trace.step_id == "s1"
        assert trace.step_name == "Step 1"
        assert trace.status == ExecutionStatus.RUNNING
        assert trace.completed_at is None
        assert trace.duration_seconds is None
        assert trace.error is None
        assert trace.retry_attempt == 0


class TestWorkflowEvent:
    def test_minimal(self):
        event = WorkflowEvent(
            type="webhook",
            payload={"key": "value"},
            source="gitlab",
            correlation_id="abc-123",
        )
        assert event.type == "webhook"
        assert event.payload == {"key": "value"}
        assert event.source == "gitlab"
        assert event.correlation_id == "abc-123"
        assert event.workflow_name is None
        assert event.metadata == {}

    def test_full(self):
        event = WorkflowEvent(
            type="event_bus",
            payload={"event": "test"},
            source="system",
            correlation_id="xyz",
            workflow_name="test_workflow",
            metadata={"event_type": "test.event"},
        )
        assert event.workflow_name == "test_workflow"
        assert event.metadata == {"event_type": "test.event"}


class TestExecutionContext:
    def _make_event(self) -> WorkflowEvent:
        return WorkflowEvent(
            type="webhook",
            payload={"code": "test"},
            source="test",
            correlation_id="corr-1",
        )

    def test_minimal(self):
        event = self._make_event()
        ctx = ExecutionContext(
            run_id="run-1",
            workflow_name="test",
            version="1.0.0",
            workflow_definition={"name": "test"},
            trigger_event=event,
        )
        assert ctx.run_id == "run-1"
        assert ctx.workflow_name == "test"
        assert ctx.status == ExecutionStatus.PENDING
        assert ctx.steps_executed == 0
        assert ctx.current_depth == 0
        assert ctx.trace == []
        assert ctx.step_outputs == {}

    def test_record_step_start(self):
        ctx = ExecutionContext(
            run_id="run-1",
            workflow_name="test",
            version="1.0.0",
            workflow_definition={},
            trigger_event=self._make_event(),
        )
        trace = ctx.record_step_start("s1", "Step 1", "llm")
        assert trace.step_id == "s1"
        assert trace.step_name == "Step 1"
        assert trace.status == ExecutionStatus.RUNNING
        assert ctx.steps_executed == 1
        assert len(ctx.trace) == 1

    def test_record_step_complete(self):
        ctx = ExecutionContext(
            run_id="run-1",
            workflow_name="test",
            version="1.0.0",
            workflow_definition={},
            trigger_event=self._make_event(),
        )
        trace = ctx.record_step_start("s1", "Step 1", "llm")
        ctx.record_step_complete(trace, {"result": "ok"})
        assert trace.status == ExecutionStatus.COMPLETED
        assert trace.completed_at is not None
        assert trace.duration_seconds is not None
        assert trace.duration_seconds >= 0
        assert ctx.step_outputs["s1"] == {"result": "ok"}

    def test_record_step_error(self):
        ctx = ExecutionContext(
            run_id="run-1",
            workflow_name="test",
            version="1.0.0",
            workflow_definition={},
            trigger_event=self._make_event(),
        )
        trace = ctx.record_step_start("s1", "Step 1", "llm")
        ctx.record_step_error(trace, "Something went wrong", retry_attempt=1)
        assert trace.status == ExecutionStatus.FAILED
        assert trace.error == "Something went wrong"
        assert trace.retry_attempt == 1

    def test_to_dict(self):
        event = self._make_event()
        ctx = ExecutionContext(
            run_id="run-1",
            workflow_name="test",
            version="1.0.0",
            workflow_definition={"name": "test"},
            trigger_event=event,
            config={"model": "gpt-4"},
            status=ExecutionStatus.RUNNING,
        )
        trace = ctx.record_step_start("s1", "Step 1", "llm")
        ctx.record_step_complete(trace, {"result": "ok"})

        d = ctx.to_dict()
        assert d["run_id"] == "run-1"
        assert d["workflow_name"] == "test"
        assert d["version"] == "1.0.0"
        assert d["status"] == "running"
        assert d["steps_executed"] == 1
        assert len(d["trace"]) == 1
        assert d["trace"][0]["step_id"] == "s1"
        assert d["trace"][0]["status"] == "completed"
        assert d["trigger_event"]["type"] == "webhook"
        assert d["config"] == {"model": "gpt-4"}
