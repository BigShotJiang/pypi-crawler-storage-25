"""
Test-Fixtures für CI-CRT-014: Policy Drift Detection.

Diese Datei enthält Python-Code-Snippets, die vom PolicyDriftVisitor
geparst werden. Sie dienen als Positive/Negative Tests für Drift A + B.

NICHT direkt ausführen — wird von test_crt_drift_compliance.py importiert.
"""

# =============================================================================
# Positive Tests: Erlaubte Muster (KEIN Drift)
# =============================================================================


def positive_termination_direct_return():
    """Drift A: Direktes return ExecutionBlocked nach if not allow()."""
    allowed = await provider.allow("tool", {})
    if not allowed:
        return {"success": False, "error": "ExecutionBlocked", "content": None}


def positive_termination_raise():
    """Drift A: raise ExecutionBlocked nach if not allow()."""
    allowed = await provider.allow("tool", {})
    if not allowed:
        raise ExecutionBlocked("blocked")


def positive_termination_trace_and_return():
    """Drift A: trace_policy_decision + return ExecutionBlocked."""
    allowed = await provider.allow("tool", {})
    if not allowed:
        trace_policy_decision("tool", False, "provider", "session_1")
        return {"success": False, "error": "ExecutionBlocked", "content": None}


def positive_termination_log_and_return():
    """Drift A: logging + return ExecutionBlocked."""
    allowed = await provider.allow("tool", {})
    if not allowed:
        logger.warning("Policy denied tool execution")
        return {"success": False, "error": "ExecutionBlocked", "content": None}


def positive_termination_multi_log():
    """Drift A: Mehrere logging-Aufrufe + return."""
    allowed = await provider.allow("tool", {})
    if not allowed:
        logger.warning("Policy denied")
        logger.info("Session: %s", session_id)
        trace_policy_decision("tool", False, "provider", "session_1")
        return {"success": False, "error": "ExecutionBlocked", "content": None}


def positive_allow_path_legitimate():
    """Drift A: allow()-Pfad (True) ist immer legitim."""
    allowed = await provider.allow("tool", {})
    if allowed:
        # Jeder Code im allow()-Pfad ist legitim
        result = await execute_tool("tool", {})
        return {"success": True, "content": result}


def positive_transition_guard_excluded():
    """TransitionGuardResult.allow() wird NICHT als Drift erkannt."""
    result = TransitionGuardResult.allow()
    if not result:
        return {"success": False, "error": "Blocked"}


def positive_sync_allow():
    """Drift A: Sync allow() ohne await."""
    allowed = provider.allow("tool", {})
    if not allowed:
        return {"success": False, "error": "ExecutionBlocked", "content": None}


def positive_print_debug():
    """Drift A: print() ist erlaubter Side Effect."""
    allowed = await provider.allow("tool", {})
    if not allowed:
        print("Policy denied tool")
        return {"success": False, "error": "ExecutionBlocked", "content": None}


# =============================================================================
# Negative Tests: Drift A — Policy Feedback (VERBOTEN)
# =============================================================================


def negative_drift_a_retry():
    """Drift A: Retry nach Denial — VERBOTEN."""
    allowed = await provider.allow("tool", {})
    if not allowed:
        # ❌ Drift A: Alternative Aktion statt Termination
        result = await execute_tool("other_tool", {})
        return {"success": True, "content": result}


def negative_drift_a_alternative_tool():
    """Drift A: Alternative Tool-Ausführung nach Denial — VERBOTEN."""
    allowed = await provider.allow("tool", {})
    if not allowed:
        # ❌ Drift A: Fallback auf anderen Tool-Typ
        return await execute_fallback_tool("tool", {})


def negative_drift_a_state_mutation():
    """Drift A: State-Mutation nach Denial — VERBOTEN."""
    allowed = await provider.allow("tool", {})
    if not allowed:
        # ❌ Drift A: State ändern statt terminieren
        self.retry_count += 1
        return {"success": False, "error": "ExecutionBlocked", "content": None}


def negative_drift_a_callback():
    """Drift A: Callback/Event auslösen nach Denial — VERBOTEN."""
    allowed = await provider.allow("tool", {})
    if not allowed:
        # ❌ Drift A: Event auslösen statt terminieren
        notify_admin("Policy denied tool")
        return {"success": False, "error": "ExecutionBlocked", "content": None}


def negative_drift_a_complex_block():
    """Drift A: Komplexer Block mit verbotener Aktion."""
    allowed = await provider.allow("tool", {})
    if not allowed:
        trace_policy_decision("tool", False, "provider", "session_1")
        logger.warning("Policy denied")
        # ❌ Drift A: Nach logging + trace kommt eine verbotene Aktion
        self.metrics.record_denial("tool")
        return {"success": False, "error": "ExecutionBlocked", "content": None}


# =============================================================================
# Negative Tests: Drift B — Policy State (VERBOTEN)
# =============================================================================


def negative_drift_b_self_attribute():
    """Drift B: allow()-Ergebnis in self.* speichern — VERBOTEN."""
    decision = await provider.allow("tool", {})
    # ❌ Drift B: Persistierung in self.last_policy_decision
    self.last_policy_decision = decision
    if not decision:
        return {"success": False, "error": "ExecutionBlocked", "content": None}


def negative_drift_b_metadata_dict():
    """Drift B: allow()-Ergebnis in metadata[...] speichern — VERBOTEN."""
    decision = await provider.allow("tool", {})
    # ❌ Drift B: Persistierung in metadata
    metadata["policy_blocked"] = decision
    if not decision:
        return {"success": False, "error": "ExecutionBlocked", "content": None}


def negative_drift_b_cache_dict():
    """Drift B: allow()-Ergebnis in cache[...] speichern — VERBOTEN."""
    decision = await provider.allow("tool", {})
    # ❌ Drift B: Persistierung in cache
    cache["last_policy"] = decision
    if not decision:
        return {"success": False, "error": "ExecutionBlocked", "content": None}


def negative_drift_b_context_dict():
    """Drift B: allow()-Ergebnis in context[...] speichern — VERBOTEN."""
    decision = await provider.allow("tool", {})
    # ❌ Drift B: Persistierung in context
    context["policy_decision"] = decision
    if not decision:
        return {"success": False, "error": "ExecutionBlocked", "content": None}


def negative_drift_b_sync_allow():
    """Drift B: Sync allow()-Ergebnis in self.* speichern — VERBOTEN."""
    decision = provider.allow("tool", {})
    # ❌ Drift B: Persistierung in self.policy_state
    self.policy_state = decision
    if not decision:
        return {"success": False, "error": "ExecutionBlocked", "content": None}


# =============================================================================
# Edge Cases
# =============================================================================


def edge_case_allow_in_loop():
    """Edge Case: allow() in Schleife — nur letzte Zuweisung zählt."""
    for tool in tools:
        decision = await provider.allow(tool, {})
        if not decision:
            return {"success": False, "error": "ExecutionBlocked", "content": None}
    return {"success": True, "content": "all_allowed"}


def edge_case_nested_if():
    """Edge Case: Verschachteltes if — äußeres if ist kein Denial-Check."""
    decision = await provider.allow("tool", {})
    if decision:
        result = await execute_tool("tool", {})
        return {"success": True, "content": result}
    else:
        # else-Zweig ist der Denial-Pfad
        return {"success": False, "error": "ExecutionBlocked", "content": None}


def edge_case_binary_flag_allowed():
    """Edge Case: Binary Flag in metadata ist erlaubt (Drift C, nicht Phase 1)."""
    decision = await provider.allow("tool", {})
    if not decision:
        # Binary Flag: metadata["blocked"] = True ist erlaubt
        metadata["blocked"] = True
        return {"success": False, "error": "ExecutionBlocked", "content": None}
