"""
CI-CRT-035: Decision Scoring Pipeline — Tests.

Testet die DecisionScoringPipeline, ScoredBackendSelection und OverrideHook:
1. ScoredBackendSelection: Dataclass, to_backend_selection(), to_dict()
2. OverrideHook: evaluate() Interface
3. DecisionScoringPipeline: augment(), augment_selection(), _rank_backends()
4. Integration: Pipeline + Health Model + Policy Engine
"""

import pytest
import time
from unittest.mock import AsyncMock, patch, MagicMock

from core.routing_intelligence.scoring_pipeline import (
    DecisionScoringPipeline,
    ScoredBackendSelection,
    OverrideHook,
)
from core.routing_intelligence.health_model import BackendHealthScore
from core.routing_intelligence.policy_engine import (
    RoutingPolicy,
    PolicyDecision,
    PolicyRule,
)
from core.backend.router_base import (
    RouterContext,
    BackendSelection,
    BackendType,
)


# ============================================================================
# ScoredBackendSelection
# ============================================================================


class TestScoredBackendSelection:
    """Tests für den ScoredBackendSelection Dataclass."""

    def test_minimal_selection(self):
        """ScoredBackendSelection mit minimalen Feldern."""
        sel = ScoredBackendSelection(
            backend_id="test_gpu",
            backend_type=BackendType.OLLAMA,
            endpoint="http://localhost:11434",
            model="llama3",
        )
        assert sel.backend_id == "test_gpu"
        assert sel.backend_type == BackendType.OLLAMA
        assert sel.endpoint == "http://localhost:11434"
        assert sel.model == "llama3"
        assert sel.health_score == 0.5  # default
        assert sel.policy == "balanced"  # default
        assert sel.policy_score == 0.5  # default
        assert sel.all_scores == {}

    def test_full_selection(self):
        """ScoredBackendSelection mit allen Feldern."""
        sel = ScoredBackendSelection(
            backend_id="expert_gpu",
            backend_type=BackendType.VLLM,
            endpoint="http://gpu:8000",
            model="mixtral",
            fallback_used=True,
            fallback_chain=["cpu1", "cpu2"],
            health_score=0.85,
            policy="latency_optimized",
            policy_score=0.92,
            all_scores={"expert_gpu": 0.85, "cpu1": 0.45, "cpu2": 0.30},
        )
        assert sel.fallback_used is True
        assert sel.fallback_chain == ["cpu1", "cpu2"]
        assert sel.health_score == 0.85
        assert sel.policy == "latency_optimized"
        assert sel.policy_score == 0.92
        assert sel.all_scores["expert_gpu"] == 0.85

    def test_to_backend_selection(self):
        """to_backend_selection() konvertiert zurück zu BackendSelection."""
        scored = ScoredBackendSelection(
            backend_id="test_gpu",
            backend_type=BackendType.OLLAMA,
            endpoint="http://localhost:11434",
            model="llama3",
            fallback_used=True,
            fallback_chain=["cpu"],
            health_score=0.9,
            policy="balanced",
            policy_score=0.8,
        )
        bs = scored.to_backend_selection()

        assert isinstance(bs, BackendSelection)
        assert bs.backend_id == "test_gpu"
        assert bs.backend_type == BackendType.OLLAMA
        assert bs.endpoint == "http://localhost:11434"
        assert bs.model == "llama3"
        assert bs.fallback_used is True
        assert bs.fallback_chain == ["cpu"]

        # Intelligence-Felder sind nicht in BackendSelection
        assert not hasattr(bs, 'health_score')

    def test_to_dict(self):
        """to_dict() serialisiert korrekt."""
        sel = ScoredBackendSelection(
            backend_id="test_gpu",
            backend_type=BackendType.OLLAMA,
            endpoint="http://localhost:11434",
            model="llama3",
            health_score=0.85,
            policy="balanced",
            policy_score=0.75,
            all_scores={"test_gpu": 0.85},
        )
        d = sel.to_dict()

        assert d["backend_id"] == "test_gpu"
        assert d["backend_type"] == "ollama"
        assert d["health_score"] == 0.85
        assert d["policy"] == "balanced"
        assert d["policy_score"] == 0.75
        assert d["all_scores"]["test_gpu"] == 0.85
        assert "selection_time" in d
        assert "augmentation_time" in d


# ============================================================================
# OverrideHook
# ============================================================================


class TestOverrideHook:
    """Tests für den OverrideHook."""

    @pytest.mark.asyncio
    async def test_default_evaluate_returns_none(self):
        """Default evaluate() gibt None zurück (kein Override)."""
        hook = OverrideHook()
        result = await hook.evaluate(
            context=MagicMock(),
            candidates={},
            policy_decision=MagicMock(),
        )
        assert result is None

    @pytest.mark.asyncio
    async def test_custom_hook(self):
        """Benutzerdefinierter Hook kann Override zurückgeben."""

        class ForceGPUHook(OverrideHook):
            async def evaluate(self, context, candidates, policy_decision):
                return {
                    "override_backend_id": "forced_gpu",
                    "override_reason": "manual_override",
                }

        hook = ForceGPUHook()
        result = await hook.evaluate(
            context=MagicMock(),
            candidates={},
            policy_decision=MagicMock(),
        )
        assert result is not None
        assert result["override_backend_id"] == "forced_gpu"
        assert result["override_reason"] == "manual_override"


# ============================================================================
# DecisionScoringPipeline
# ============================================================================


class FakeHealthScore:
    """Minimaler HealthScore-Mock für Tests."""
    def __init__(self, availability=1.0, latency=1.0, error=1.0, cost=1.0):
        self.availability_score = availability
        self.latency_score = latency
        self.error_score = error
        self.cost_score = cost
        self.weighted_score = 0.0
        self.backend_id = "test"
        self.signal_count = 0
        self.last_updated = time.time()
        self.weights = {"availability": 0.4, "latency": 0.25, "error": 0.25, "cost": 0.10}

    def compute_weighted(self):
        self.weighted_score = (
            0.4 * self.availability_score
            + 0.25 * self.latency_score
            + 0.25 * self.error_score
            + 0.10 * self.cost_score
        )
        return self.weighted_score


class TestDecisionScoringPipeline:
    """Tests für die DecisionScoringPipeline."""

    @pytest.mark.asyncio
    async def test_augment_with_scores(self):
        """augment() mit Scores → korrekte ScoredBackendSelection."""
        pipeline = DecisionScoringPipeline()

        ctx = RouterContext(
            candidate_agents=["gpu_a", "gpu_b"],
            execution_state={"mode": "business"},
            trace_id="trace-1",
            task_type="code_gen",
        )

        scores = {
            "gpu_a": FakeHealthScore(availability=1.0, latency=0.9, error=1.0, cost=0.3),
            "gpu_b": FakeHealthScore(availability=0.5, latency=0.3, error=0.6, cost=0.8),
        }
        for s in scores.values():
            s.compute_weighted()

        result = await pipeline.augment(ctx, scores)

        assert isinstance(result, ScoredBackendSelection)
        assert result.backend_id == "gpu_a"  # gpu_a hat bessere Scores
        assert result.health_score > 0.5
        assert result.policy == "reliability_optimized"  # business mode
        assert "gpu_a" in result.all_scores
        assert "gpu_b" in result.all_scores

    @pytest.mark.asyncio
    async def test_augment_empty_scores(self):
        """augment() ohne Scores → Default-Werte."""
        pipeline = DecisionScoringPipeline()

        ctx = RouterContext(
            candidate_agents=["gpu"],
            execution_state={"mode": "community"},
            trace_id="trace-1",
            task_type="chat",
        )

        result = await pipeline.augment(ctx, {})
        assert isinstance(result, ScoredBackendSelection)
        assert result.health_score == 0.5  # default
        assert result.all_scores == {}

    @pytest.mark.asyncio
    async def test_augment_selection(self):
        """augment_selection() reichert bestehende Selection an."""
        pipeline = DecisionScoringPipeline()

        ctx = RouterContext(
            candidate_agents=["test_gpu"],
            execution_state={"mode": "community"},
            trace_id="trace-1",
            task_type="chat",
        )

        selection = BackendSelection(
            backend_id="test_gpu",
            backend_type=BackendType.OLLAMA,
            endpoint="http://localhost:11434",
            model="llama3",
        )

        result = await pipeline.augment_selection(ctx, selection)

        assert isinstance(result, ScoredBackendSelection)
        assert result.backend_id == "test_gpu"
        assert result.backend_type == BackendType.OLLAMA
        assert result.endpoint == "http://localhost:11434"
        assert result.model == "llama3"
        assert result.policy == "cost_optimized"  # community mode

    @pytest.mark.asyncio
    async def test_override_hook(self):
        """Override-Hook kann die Entscheidung überschreiben."""

        class ForceBackendHook(OverrideHook):
            async def evaluate(self, context, candidates, policy_decision):
                return {
                    "override_backend_id": "forced_backend",
                    "override_reason": "test_override",
                }

        pipeline = DecisionScoringPipeline()
        pipeline.register_override_hook(ForceBackendHook())

        ctx = RouterContext(
            candidate_agents=["gpu_a"],
            execution_state={"mode": "business"},
            trace_id="trace-1",
            task_type="code_gen",
        )

        scores = {
            "gpu_a": FakeHealthScore(availability=1.0, latency=1.0, error=1.0, cost=1.0),
            "forced_backend": FakeHealthScore(availability=0.5, latency=0.5, error=0.5, cost=0.5),
        }
        for s in scores.values():
            s.compute_weighted()

        result = await pipeline.augment(ctx, scores)
        assert result.backend_id == "forced_backend"

    @pytest.mark.asyncio
    async def test_multiple_override_hooks(self):
        """Mehrere Override-Hooks: erster gewinnt."""

        class FirstHook(OverrideHook):
            async def evaluate(self, context, candidates, policy_decision):
                return {"override_backend_id": "first", "override_reason": "first"}

        class SecondHook(OverrideHook):
            async def evaluate(self, context, candidates, policy_decision):
                return {"override_backend_id": "second", "override_reason": "second"}

        pipeline = DecisionScoringPipeline()
        pipeline.register_override_hook(FirstHook())
        pipeline.register_override_hook(SecondHook())

        ctx = RouterContext(
            candidate_agents=["gpu"],
            execution_state={"mode": "business"},
            trace_id="trace-1",
            task_type="code_gen",
        )

        result = await pipeline.augment(ctx, {})
        assert result.backend_id == "first"

    @pytest.mark.asyncio
    async def test_unregister_override_hook(self):
        """unregister_override_hook() entfernt einen Hook."""

        class TestHook(OverrideHook):
            async def evaluate(self, context, candidates, policy_decision):
                return {"override_backend_id": "test", "override_reason": "test"}

        pipeline = DecisionScoringPipeline()
        hook = TestHook()
        pipeline.register_override_hook(hook)
        pipeline.unregister_override_hook(hook)

        ctx = RouterContext(
            candidate_agents=["gpu"],
            execution_state={"mode": "business"},
            trace_id="trace-1",
            task_type="code_gen",
        )

        result = await pipeline.augment(ctx, {})
        # Kein Override mehr → default Verhalten
        assert result is not None

    def test_rank_backends(self):
        """_rank_backends() sortiert absteigend nach gewichtetem Score."""
        pipeline = DecisionScoringPipeline()

        scores = {
            "best": FakeHealthScore(availability=1.0, latency=1.0, error=1.0, cost=1.0),
            "medium": FakeHealthScore(availability=0.6, latency=0.6, error=0.6, cost=0.6),
            "worst": FakeHealthScore(availability=0.2, latency=0.2, error=0.2, cost=0.2),
        }
        for s in scores.values():
            s.compute_weighted()

        weights = {"availability": 0.4, "latency": 0.25, "error": 0.25, "cost": 0.10}
        ranked = pipeline._rank_backends(scores, weights)

        assert len(ranked) == 3
        assert ranked[0][0] == "best"
        assert ranked[1][0] == "medium"
        assert ranked[2][0] == "worst"
        assert ranked[0][1] > ranked[1][1] > ranked[2][1]

    @pytest.mark.asyncio
    async def test_get_diagnostics(self):
        """get_diagnostics() gibt Diagnose-Informationen zurück."""
        pipeline = DecisionScoringPipeline()
        diag = await pipeline.get_diagnostics()

        assert "override_hooks" in diag
        assert "policy_engine" in diag
        assert "health_model" in diag
        assert "timestamp" in diag
