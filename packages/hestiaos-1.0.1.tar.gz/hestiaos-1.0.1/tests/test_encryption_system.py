#!/usr/bin/env python3
"""
Tests for the Encryption System (Phase 2 of Security, RBAC & Privacy #82)
"""

import unittest
import tempfile
import os
import json
from pathlib import Path
from datetime import datetime, timedelta

from core.encryption_system import EncryptionManager, EncryptionKey, get_encryption_manager


class TestEncryptionKey(unittest.TestCase):
    """Test EncryptionKey class."""
    
    def test_key_creation(self):
        """Test creating an encryption key."""
        key = EncryptionKey(
            key_id="test_key",
            key_type="aes",
            key_data=b"test_key_data_32_bytes_123456789012",
            created_at=datetime.now()
        )
        
        self.assertEqual(key.key_id, "test_key")
        self.assertEqual(key.key_type, "aes")
        self.assertEqual(key.key_data, b"test_key_data_32_bytes_123456789012")
        self.assertFalse(key.is_expired())
    
    def test_key_expiration(self):
        """Test key expiration logic."""
        # Key with past expiration
        key = EncryptionKey(
            key_id="expired_key",
            key_type="aes",
            key_data=b"test",
            created_at=datetime.now(),
            expires_at=datetime.now() - timedelta(days=1)
        )
        self.assertTrue(key.is_expired())
        
        # Key with future expiration
        key = EncryptionKey(
            key_id="valid_key",
            key_type="aes",
            key_data=b"test",
            created_at=datetime.now(),
            expires_at=datetime.now() + timedelta(days=1)
        )
        self.assertFalse(key.is_expired())
        
        # Key without expiration
        key = EncryptionKey(
            key_id="no_expiry_key",
            key_type="aes",
            key_data=b"test",
            created_at=datetime.now()
        )
        self.assertFalse(key.is_expired())


class TestEncryptionManager(unittest.TestCase):
    """Test EncryptionManager class."""
    
    def setUp(self):
        """Set up test environment."""
        # Create temporary directory for key storage
        self.temp_dir = tempfile.mkdtemp()
        self.config_path = Path(self.temp_dir)
        self.manager = EncryptionManager(self.config_path)
    
    def tearDown(self):
        """Clean up test environment."""
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_initialization(self):
        """Test that EncryptionManager initializes with default keys."""
        # Check that default keys are created
        self.assertIn("aes_context_master", self.manager.keys)
        self.assertIn("rsa_identity_master_public", self.manager.keys)
        self.assertIn("rsa_identity_master_private", self.manager.keys)
        self.assertIn("fernet_general", self.manager.keys)
        
        # Check key types
        self.assertEqual(self.manager.keys["aes_context_master"].key_type, "aes")
        self.assertEqual(self.manager.keys["rsa_identity_master_public"].key_type, "rsa_public")
        self.assertEqual(self.manager.keys["rsa_identity_master_private"].key_type, "rsa_private")
        self.assertEqual(self.manager.keys["fernet_general"].key_type, "fernet")
    
    def test_aes_encryption_decryption(self):
        """Test AES encryption and decryption."""
        test_data = b"Test data for AES encryption 12345"
        
        # Encrypt
        encrypted = self.manager.encrypt_aes(test_data)
        self.assertIsInstance(encrypted, bytes)
        self.assertGreater(len(encrypted), len(test_data))  # Should be longer due to IV
        
        # Decrypt
        decrypted = self.manager.decrypt_aes(encrypted)
        self.assertEqual(decrypted, test_data)
    
    def test_rsa_encryption_decryption(self):
        """Test RSA encryption and decryption."""
        test_data = b"Test data for RSA"
        
        # Encrypt with public key
        encrypted = self.manager.encrypt_rsa(test_data)
        self.assertIsInstance(encrypted, bytes)
        
        # Decrypt with private key
        decrypted = self.manager.decrypt_rsa(encrypted)
        self.assertEqual(decrypted, test_data)
    
    def test_rsa_large_data_hybrid_encryption(self):
        """Test RSA hybrid encryption for large data."""
        # Create data larger than RSA can handle directly (190 bytes)
        test_data = b"X" * 500  # 500 bytes
        
        # Encrypt with public key (should use hybrid encryption)
        encrypted = self.manager.encrypt_rsa(test_data)
        self.assertIsInstance(encrypted, bytes)
        self.assertTrue(encrypted.startswith(b"HYBRID:"))
        
        # Decrypt with private key
        decrypted = self.manager.decrypt_rsa(encrypted)
        self.assertEqual(decrypted, test_data)
    
    def test_fernet_encryption_decryption(self):
        """Test Fernet encryption and decryption."""
        test_data = b"Test data for Fernet encryption"
        
        # Encrypt
        encrypted = self.manager.encrypt_fernet(test_data)
        self.assertIsInstance(encrypted, bytes)
        
        # Decrypt
        decrypted = self.manager.decrypt_fernet(encrypted)
        self.assertEqual(decrypted, test_data)
    
    def test_context_data_encryption(self):
        """Test context data encryption (AES)."""
        test_context = {
            "user_id": "test_user",
            "session_id": "test_session_123",
            "timestamp": datetime.now().isoformat(),
            "data": {"key": "value", "nested": {"inner": "data"}}
        }
        
        # Encrypt
        encrypted_str = self.manager.encrypt_context_data(test_context)
        self.assertIsInstance(encrypted_str, str)
        
        # Decrypt
        decrypted_context = self.manager.decrypt_context_data(encrypted_str)
        self.assertIsNotNone(decrypted_context)
        self.assertEqual(decrypted_context["user_id"], test_context["user_id"])
        self.assertEqual(decrypted_context["session_id"], test_context["session_id"])
        self.assertEqual(decrypted_context["data"], test_context["data"])
    
    def test_identity_data_encryption(self):
        """Test identity data encryption (RSA)."""
        test_identity = {
            "user_id": "test_user",
            "email": "user@example.com",
            "permissions": ["read", "write"],
            "metadata": {"created": datetime.now().isoformat()}
        }
        
        # Encrypt
        encrypted_str = self.manager.encrypt_identity_data(test_identity)
        self.assertIsInstance(encrypted_str, str)
        
        # Decrypt
        decrypted_identity = self.manager.decrypt_identity_data(encrypted_str)
        self.assertIsNotNone(decrypted_identity)
        self.assertEqual(decrypted_identity["user_id"], test_identity["user_id"])
        self.assertEqual(decrypted_identity["email"], test_identity["email"])
        self.assertEqual(decrypted_identity["permissions"], test_identity["permissions"])
    
    def test_generate_key_pair(self):
        """Test generating new RSA key pairs."""
        key_id = "test_key_pair"
        
        # Generate key pair
        public_id, private_id = self.manager.generate_key_pair(key_id)
        
        self.assertEqual(public_id, f"{key_id}_public")
        self.assertEqual(private_id, f"{key_id}_private")
        
        # Check keys were added
        self.assertIn(public_id, self.manager.keys)
        self.assertIn(private_id, self.manager.keys)
        
        # Test encryption/decryption with new key pair
        test_data = b"Test data for new key pair"
        encrypted = self.manager.encrypt_rsa(test_data, public_key_id=public_id)
        decrypted = self.manager.decrypt_rsa(encrypted, private_key_id=private_id)
        self.assertEqual(decrypted, test_data)
    
    def test_get_public_key_pem(self):
        """Test getting public key in PEM format."""
        pem = self.manager.get_public_key_pem()
        self.assertIsInstance(pem, bytes)
        self.assertTrue(pem.startswith(b"-----BEGIN PUBLIC KEY-----"))
    
    def test_key_rotation(self):
        """Test key rotation functionality."""
        # Test AES key rotation
        initial_aes_key = self.manager.keys["aes_context_master"].key_data
        success = self.manager.rotate_keys("aes")
        self.assertTrue(success)
        
        # Check that key was rotated (should be different)
        rotated_aes_key = self.manager.keys["aes_context_master"].key_data
        self.assertNotEqual(initial_aes_key, rotated_aes_key)
        
        # Test that encryption still works with rotated key
        test_data = b"Test data after rotation"
        encrypted = self.manager.encrypt_aes(test_data)
        decrypted = self.manager.decrypt_aes(encrypted)
        self.assertEqual(decrypted, test_data)


class TestSingletonPattern(unittest.TestCase):
    """Test singleton pattern for EncryptionManager."""
    
    def test_get_encryption_manager(self):
        """Test that get_encryption_manager returns singleton instance."""
        manager1 = get_encryption_manager()
        manager2 = get_encryption_manager()
        
        # Should be the same instance
        self.assertIs(manager1, manager2)
        
        # Should have default keys
        self.assertIn("aes_context_master", manager1.keys)


if __name__ == "__main__":
    unittest.main()